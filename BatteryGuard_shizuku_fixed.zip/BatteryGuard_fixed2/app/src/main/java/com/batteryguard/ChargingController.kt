package com.batteryguard

import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File

/**
 * Charging control via:
 *   1. Root (su)
 *   2. Shizuku API — uses Shizuku.newProcess() which tunnels through the
 *      Shizuku binder service running as the privileged shell user.
 *      Requires ShizukuProvider in the manifest + permission granted in Shizuku app.
 *   3. Fallback: loud alert notification only
 */
object ChargingController {

    private const val TAG = "ChargingController"

    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",
        "/sys/class/power_supply/battery/input_suspend",
        "/sys/class/power_supply/batt_drv/charge_disable",
        "/sys/class/power_supply/battery/stop_charging",
        "/sys/class/power_supply/battery/inhibit_charge",
        "/sys/class/power_supply/battery/charge_control_limit_max"
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    fun availableMethod(): Method = when {
        isRooted()         -> Method.ROOT
        isShizukuGranted() -> Method.SHIZUKU
        else               -> Method.NONE
    }

    fun disableCharging(): Boolean = run(buildCmds(enable = false))
    fun enableCharging():  Boolean = run(buildCmds(enable = true))

    private fun buildCmds(enable: Boolean): String {
        val v    = if (enable) "1" else "0"
        val cmds = mutableListOf<String>()
        for (node in CHARGING_NODES) {
            cmds += "[ -f \$node ] && echo $v > \$node || true".replace("\$node", node)
        }
        if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
        else        cmds += "dumpsys battery set status 1 2>/dev/null || true"
        return cmds.joinToString(" ; ")
    }

    private fun run(cmd: String): Boolean {
        return when (availableMethod()) {
            Method.ROOT    -> execRoot(cmd)
            Method.SHIZUKU -> execShizuku(cmd)
            Method.NONE    -> false
        }
    }

    // ── Root ──────────────────────────────────────────────────────────────────

    private fun execRoot(cmd: String): Boolean {
        return try {
            val p    = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val exit = p.waitFor()
            Log.d(TAG, "root exec exit=$exit")
            exit == 0
        } catch (e: Exception) {
            Log.e(TAG, "root exec failed: ${e.message}")
            false
        }
    }

    // ── Shizuku ───────────────────────────────────────────────────────────────

    /**
     * Runs commands through Shizuku.newProcess().
     * Shizuku spawns a `sh` process as the privileged shell user;
     * we pipe commands to stdin and wait for it to exit.
     */
    private fun execShizuku(cmd: String): Boolean {
        return try {
            val process = Shizuku.newProcess(arrayOf("sh"), null, null)
            process.outputStream.use { stdin ->
                stdin.write("$cmd\nexit\n".toByteArray())
                stdin.flush()
            }
            val exit = process.waitFor()
            Log.d(TAG, "shizuku exec exit=$exit")
            exit == 0
        } catch (e: Exception) {
            Log.e(TAG, "shizuku exec failed: ${e.message}")
            false
        }
    }

    // ── Shizuku detection ─────────────────────────────────────────────────────

    /** True if the Shizuku service is alive and bound to this app. */
    fun isShizukuAvailable(): Boolean {
        return try { Shizuku.pingBinder() } catch (_: Exception) { false }
    }

    /** True if the user has granted this app permission inside the Shizuku app. */
    fun isShizukuGranted(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }

    // ── Root detection ────────────────────────────────────────────────────────

    fun isRooted(): Boolean = listOf(
        "/system/bin/su", "/system/xbin/su",
        "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
    ).any { File(it).exists() }
}
