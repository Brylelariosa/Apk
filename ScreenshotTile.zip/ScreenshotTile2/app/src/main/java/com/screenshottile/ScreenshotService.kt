package com.screenshottile

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import java.io.OutputStream

class ScreenshotService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA        = "data"
        private const val CHANNEL_ID      = "screenshot_tile_channel"
        private const val NOTIFICATION_ID = 42
        private const val TAG             = "ScreenshotService"
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay?   = null
    private var imageReader: ImageReader?          = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)

        if (resultCode != Activity.RESULT_OK || data == null) {
            Log.e(TAG, "Invalid projection data — aborting")
            stopSelf()
            return START_NOT_STICKY
        }

        val mgr = getSystemService(MediaProjectionManager::class.java)
        mediaProjection = mgr.getMediaProjection(resultCode, data)

        // Delay so PermissionActivity fully disappears before we capture
        mainHandler.postDelayed({ startCapture() }, 600)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        releaseResources()
        super.onDestroy()
    }

    // ── Capture ──────────────────────────────────────────────────────────────

    private fun startCapture() {
        val wm = getSystemService(android.view.WindowManager::class.java)
        val (width, height, density) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), resources.displayMetrics.densityDpi)
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
        }

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenshotCapture",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        // Give VirtualDisplay a moment to render the first frame
        mainHandler.postDelayed({ grabFrame(width, height) }, 300)
    }

    private fun grabFrame(width: Int, height: Int, retries: Int = 0) {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage()
            if (image == null) {
                if (retries < 5) {
                    mainHandler.postDelayed({ grabFrame(width, height, retries + 1) }, 150)
                } else {
                    showToast("Screenshot failed: no frame captured")
                    stopSelf()
                }
                return
            }

            val plane      = image.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * width
            val fullBmp    = Bitmap.createBitmap(
                width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888
            )
            fullBmp.copyPixelsFromBuffer(plane.buffer)

            val bmp = Bitmap.createBitmap(fullBmp, 0, 0, width, height)
            fullBmp.recycle()

            saveToGallery(bmp)

        } catch (e: Exception) {
            Log.e(TAG, "Capture error", e)
            showToast("Screenshot failed: ${e.message}")
            stopSelf()
        } finally {
            image?.close()
        }
    }

    // ── Save ─────────────────────────────────────────────────────────────────

    private fun saveToGallery(bitmap: Bitmap) {
        val filename = "Screenshot_${System.currentTimeMillis()}.png"
        var stream: OutputStream? = null
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Screenshots")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Failed to create MediaStore entry")

            stream = contentResolver.openOutputStream(uri)
                ?: throw Exception("Failed to open output stream")

            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.flush()

            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)

            showToast("Screenshot saved!")
        } catch (e: Exception) {
            Log.e(TAG, "Save error", e)
            showToast("Save failed: ${e.message}")
        } finally {
            stream?.close()
            bitmap.recycle()
            stopSelf()
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun releaseResources() {
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        virtualDisplay   = null
        imageReader      = null
        mediaProjection  = null
    }

    private fun showToast(msg: String) =
        mainHandler.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    private fun createNotificationChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "Screenshot Tile",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Active while taking a screenshot" }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification =
        Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Taking screenshot…")
            .setSmallIcon(R.drawable.ic_screenshot)
            .setOngoing(true)
            .build()
}
