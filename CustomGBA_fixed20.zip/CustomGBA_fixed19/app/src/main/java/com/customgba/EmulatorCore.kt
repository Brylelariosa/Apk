package com.customgba

import android.view.Surface

class EmulatorCore {
    var onFrameReady: (() -> Unit)? = null

    fun setLogPath(path: String) = nativeSetLogPath(path)
    fun init()                   = nativeInit()
    fun loadROM(path: String): Boolean = nativeLoadROM(path)
    fun setSurface(s: Surface?)  = nativeSetSurface(s)
    fun start()                  = nativeStart()
    fun stop()                   = nativeStop()
    fun pause(p: Boolean)        = nativePause(p)
    fun setKeys(k: Int)          = nativeSetKeys(k)
    fun reset()                  = nativeReset()
    fun saveState(path: String)  = nativeSaveState(path)
    fun loadState(path: String)  = nativeLoadState(path)
    fun getDebugInfo(): String   = nativeGetDebugInfo()

    @Suppress("unused") // called from C++
    fun onFrameReady() { onFrameReady?.invoke() }

    private external fun nativeSetLogPath(path: String)
    private external fun nativeInit()
    private external fun nativeLoadROM(path: String): Boolean
    private external fun nativeSetSurface(s: Surface?)
    private external fun nativeStart()
    private external fun nativeStop()
    private external fun nativePause(p: Boolean)
    private external fun nativeSetKeys(k: Int)
    private external fun nativeReset()
    private external fun nativeSaveState(path: String): Boolean
    private external fun nativeLoadState(path: String): Boolean
    private external fun nativeGetDebugInfo(): String

    companion object {
        init { System.loadLibrary("customgba-core") }
    }
}
