#pragma once
#include "types.h"
#include "memory.h"
#include "cpu.h"
#include "ppu.h"
#include "apu_dma_timer.h"
#include <functional>

struct GBA {
    Memory mem;
    ARM7TDMI cpu;
    PPU      ppu;
    APU      apu;
    DMA      dma;
    Timers   timers;

    bool running    = false;
    bool frameReady = false;

    std::function<void(const u32*, int, int)> onFrameReady;
    std::function<void(const float*, int)>    onAudioReady;

    void init() {
        mem.init();
        cpu.init(this);
        ppu.init(&mem);
        apu.init(&mem);
        dma.init(&mem);
        timers.init(&mem);

        // ── Wire Direct Sound FIFO path ──────────────────────────────────────
        // Memory → APU: 32-bit writes at FIFO addresses push PCM into FIFOs
        mem.onFifoAWrite = [this](u32 val) { apu.fifoA.push(val); };
        mem.onFifoBWrite = [this](u32 val) { apu.fifoB.push(val); };
        // Memory → APU: SOUNDCNT_H writes configure / reset FIFOs
        mem.onSoundCntHWrite = [this](u16 val) { apu.writeSoundCntH(val); };

        // Timers → APU: overflow clocks the FIFO and advances the read pointer
        timers.onTimerOverflow = [this](int n) {
            apu.clockFifoOnTimerOverflow(n);
        };

        // APU → DMA: when FIFO drops to ≤16 samples, trigger refill
        apu.onFifoANeedsDma = [this]() {
            // DMA channels 1 and 2 can be configured as FIFO-A feeder
            for (int n = 1; n <= 2; n++) {
                u32 base = 0x040000B0 + n * 12;
                u16 ctrl = mem.read16(base + 10);
                if (!(ctrl & (1 << 15))) continue;       // not enabled
                if (((ctrl >> 12) & 3) != 3) continue;   // not Sound FIFO timing
                u32 dst = mem.read32(base + 4) & 0x0FFFFFFF;
                if (dst == 0x040000A0) { dma.triggerFifo(n, 0x040000A0); break; }
            }
        };
        apu.onFifoBNeedsDma = [this]() {
            for (int n = 1; n <= 2; n++) {
                u32 base = 0x040000B0 + n * 12;
                u16 ctrl = mem.read16(base + 10);
                if (!(ctrl & (1 << 15))) continue;
                if (((ctrl >> 12) & 3) != 3) continue;
                u32 dst = mem.read32(base + 4) & 0x0FFFFFFF;
                if (dst == 0x040000A4) { dma.triggerFifo(n, 0x040000A4); break; }
            }
        };

        // PPU callbacks — pass correct trigger flag so DMA timing=1/2 fires
        ppu.onVBlank = [this]() {
            dma.step(/*vblank=*/true, /*hblank=*/false);   // timing=1 DMA fires here
            frameReady = true;
            if (onFrameReady) onFrameReady(ppu.framebuffer, GBA_W, GBA_H);
        };
        ppu.onHBlank = [this]() {
            dma.step(/*vblank=*/false, /*hblank=*/true);   // timing=2 DMA fires here
        };

        // APU → JNI audio output
        apu.onSamplesReady = [this](float* buf, int frames) {
            if (onAudioReady) onAudioReady(buf, frames);
        };
    }

    bool loadROM(const u8* data, size_t size) {
        if (!mem.loadROM(data, size)) return false;
        cpu.reset();
        return true;
    }

    void setKeys(u16 keyState) {
        mem.keyState = keyState & 0x03FF;
        mem.write16(REG_KEYINPUT, mem.keyState);
    }

    void runFrame() {
        frameReady = false;
        int frameCycles = CYCLES_PER_FRAME;
        while (frameCycles > 0 && !frameReady) {
            int c = cpu.step();
            ppu.step(c);
            apu.step(c);
            timers.step(c);
            frameCycles -= c;
        }
    }
};
