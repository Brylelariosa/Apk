#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <functional>

using u8  = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;
using s8  = int8_t;
using s16 = int16_t;
using s32 = int32_t;
using s64 = int64_t;

// ── GBA Screen ───────────────────────────────────────────────────────────────
static constexpr int GBA_W          = 240;
static constexpr int GBA_H          = 160;
static constexpr int GBA_PIXELS     = GBA_W * GBA_H;

// ── Clock ────────────────────────────────────────────────────────────────────
static constexpr u32 GBA_CPU_HZ     = 16777216;   // ~16.78 MHz
static constexpr int CYCLES_PER_DOT = 4;
static constexpr int DOTS_PER_LINE  = 308;         // 240 visible + 68 HBlank
static constexpr int LINES_PER_FRAME= 228;         // 160 visible + 68 VBlank
static constexpr int CYCLES_PER_LINE= DOTS_PER_LINE  * CYCLES_PER_DOT;
static constexpr int CYCLES_PER_FRAME=LINES_PER_FRAME * CYCLES_PER_LINE;

// ── Memory map ───────────────────────────────────────────────────────────────
static constexpr u32 BIOS_START  = 0x00000000;
static constexpr u32 BIOS_SIZE   = 0x4000;       // 16 KB
static constexpr u32 EWRAM_START = 0x02000000;
static constexpr u32 EWRAM_SIZE  = 0x40000;      // 256 KB
static constexpr u32 IWRAM_START = 0x03000000;
static constexpr u32 IWRAM_SIZE  = 0x8000;       // 32 KB
static constexpr u32 IO_START    = 0x04000000;
static constexpr u32 IO_SIZE     = 0x400;
static constexpr u32 PAL_START   = 0x05000000;
static constexpr u32 PAL_SIZE    = 0x400;        // 1 KB palette
static constexpr u32 VRAM_START  = 0x06000000;
static constexpr u32 VRAM_SIZE   = 0x18000;      // 96 KB
static constexpr u32 OAM_START   = 0x07000000;
static constexpr u32 OAM_SIZE    = 0x400;        // 1 KB
static constexpr u32 ROM_START   = 0x08000000;
static constexpr u32 ROM_SIZE    = 0x2000000;    // up to 32 MB

// ── I/O Register addresses ───────────────────────────────────────────────────
static constexpr u32 REG_DISPCNT  = 0x04000000;
static constexpr u32 REG_DISPSTAT = 0x04000004;
static constexpr u32 REG_VCOUNT   = 0x04000006;
static constexpr u32 REG_BG0CNT   = 0x04000008;
static constexpr u32 REG_BG1CNT   = 0x0400000A;
static constexpr u32 REG_BG2CNT   = 0x0400000C;
static constexpr u32 REG_BG3CNT   = 0x0400000E;
static constexpr u32 REG_BG0HOFS  = 0x04000010;
static constexpr u32 REG_BG0VOFS  = 0x04000012;
static constexpr u32 REG_BG1HOFS  = 0x04000014;
static constexpr u32 REG_BG1VOFS  = 0x04000016;
static constexpr u32 REG_BG2HOFS  = 0x04000018;
static constexpr u32 REG_BG2VOFS  = 0x0400001A;
static constexpr u32 REG_BG3HOFS  = 0x0400001C;
static constexpr u32 REG_BG3VOFS  = 0x0400001E;
static constexpr u32 REG_WIN0H    = 0x04000040;
static constexpr u32 REG_WIN1H    = 0x04000042;
static constexpr u32 REG_WIN0V    = 0x04000044;
static constexpr u32 REG_WIN1V    = 0x04000046;
static constexpr u32 REG_WININ    = 0x04000048;
static constexpr u32 REG_WINOUT   = 0x0400004A;
static constexpr u32 REG_BLDCNT   = 0x04000050;
static constexpr u32 REG_BLDALPHA = 0x04000052;
static constexpr u32 REG_BLDY     = 0x04000054;
static constexpr u32 REG_KEYINPUT = 0x04000130;
static constexpr u32 REG_KEYCNT   = 0x04000132;
static constexpr u32 REG_IE       = 0x04000200;
static constexpr u32 REG_IF       = 0x04000202;
static constexpr u32 REG_IME      = 0x04000208;
static constexpr u32 REG_HALTCNT  = 0x04000301;

// Interrupt bits
static constexpr u16 IRQ_VBLANK  = (1 << 0);
static constexpr u16 IRQ_HBLANK  = (1 << 1);
static constexpr u16 IRQ_VCOUNT  = (1 << 2);
static constexpr u16 IRQ_TIMER0  = (1 << 3);
static constexpr u16 IRQ_TIMER1  = (1 << 4);
static constexpr u16 IRQ_TIMER2  = (1 << 5);
static constexpr u16 IRQ_TIMER3  = (1 << 6);
static constexpr u16 IRQ_DMA0    = (1 << 8);
static constexpr u16 IRQ_DMA1    = (1 << 9);
static constexpr u16 IRQ_DMA2    = (1 << 10);
static constexpr u16 IRQ_DMA3    = (1 << 11);
static constexpr u16 IRQ_KEYPAD  = (1 << 12);
