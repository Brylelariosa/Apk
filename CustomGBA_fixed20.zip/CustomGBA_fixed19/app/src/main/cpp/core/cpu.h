#pragma once
#include "types.h"

// Forward declarations
struct Memory;
struct GBA;

// ── CPU modes ────────────────────────────────────────────────────────────────
enum class CpuMode : u8 {
    USR = 0x10, FIQ = 0x11, IRQ = 0x12,
    SVC = 0x13, ABT = 0x17, UND = 0x1B, SYS = 0x1F
};

// ── CPSR flags ───────────────────────────────────────────────────────────────
static constexpr u32 FLAG_N = (1u << 31);  // Negative
static constexpr u32 FLAG_Z = (1u << 30);  // Zero
static constexpr u32 FLAG_C = (1u << 29);  // Carry
static constexpr u32 FLAG_V = (1u << 28);  // Overflow
static constexpr u32 FLAG_I = (1u << 7);   // IRQ disable
static constexpr u32 FLAG_F = (1u << 6);   // FIQ disable
static constexpr u32 FLAG_T = (1u << 5);   // THUMB mode

struct ARM7TDMI {
    // ── Registers ────────────────────────────────────────────────────────────
    u32  r[16];       // R0-R15 (R13=SP, R14=LR, R15=PC)
    u32  cpsr;
    u32  spsr;

    // Banked registers for each mode
    u32  r8_fiq,  r9_fiq,  r10_fiq, r11_fiq, r12_fiq;
    u32  r13_fiq, r14_fiq, spsr_fiq;
    u32  r13_svc, r14_svc, spsr_svc;
    u32  r13_abt, r14_abt, spsr_abt;
    u32  r13_irq, r14_irq, spsr_irq;
    u32  r13_und, r14_und, spsr_und;

    // ── State ─────────────────────────────────────────────────────────────────
    GBA* gba;
    int  cycles;      // Cycles consumed this step
    bool halted;
    bool stopped;

    // HLE BIOS IRQ dispatch state
    bool irqHandlerPending = false;
    u32  irqReturnCPSR     = 0;
    u32  irqReturnPC       = 0;

    // ── Diagnostics (written by emu thread, read in onFrameReady) ─────────────
    int  swiCallCount      = 0;
    u32  lastSwiNum        = 0xFF;
    // Ring buffer of last 8 SWI calls (for overlay history)
    static constexpr int SWI_HIST = 8;
    u32  swiHistory[SWI_HIST] = {};
    int  swiHistHead       = 0;
    int  totalIRQs         = 0;
    int  vblankIRQs        = 0;
    // DISPCNT change tracking
    u16  lastDispcnt       = 0xFFFF; // sentinel "never seen"
    int  dispcntChanges    = 0;

    // ── Init ──────────────────────────────────────────────────────────────────
    void init(GBA* g);
    void reset();

    // ── Step ──────────────────────────────────────────────────────────────────
    int  step();      // Returns cycles consumed

    // ── Interrupts ────────────────────────────────────────────────────────────
    void requestIRQ();

    // ── Helpers ───────────────────────────────────────────────────────────────
    bool thumbMode() const { return (cpsr & FLAG_T) != 0; }
    CpuMode mode()   const { return static_cast<CpuMode>(cpsr & 0x1F); }

    void setFlag(u32 flag, bool v) {
        if (v) cpsr |= flag; else cpsr &= ~flag;
    }
    bool getFlag(u32 flag) const { return (cpsr & flag) != 0; }

    void setMode(CpuMode m);
    void switchMode(CpuMode newMode);

    u32& PC() { return r[15]; }
    u32& SP() { return r[13]; }
    u32& LR() { return r[14]; }

    // ── ARM instruction execution ──────────────────────────────────────────────
    void executeARM(u32 instr);
    void executeTHUMB(u16 instr);

    // ARM instruction handlers
    void armDataProcessing(u32 instr);
    void armMultiply(u32 instr);
    void armMultiplyLong(u32 instr);
    void armSingleDataTransfer(u32 instr);
    void armBlockDataTransfer(u32 instr);
    void armBranch(u32 instr);
    void armBranchExchange(u32 instr);
    void armSWP(u32 instr);
    void armSWI(u32 instr);
    void armMRS(u32 instr);
    void armMSR(u32 instr);
    void armHalfwordTransfer(u32 instr);

    // THUMB instruction handlers
    void thumbMoveShiftedReg(u16 instr);
    void thumbAddSub(u16 instr);
    void thumbMovCmpAddSubImm(u16 instr);
    void thumbALU(u16 instr);
    void thumbHiRegOps(u16 instr);
    void thumbPCRelLoad(u16 instr);
    void thumbLoadStoreReg(u16 instr);
    void thumbLoadStoreImm(u16 instr);
    void thumbLoadStoreHalf(u16 instr);
    void thumbSPRelLoadStore(u16 instr);
    void thumbLoadAddress(u16 instr);
    void thumbAddOffsetSP(u16 instr);
    void thumbPushPop(u16 instr);
    void thumbMultiLoadStore(u16 instr);
    void thumbConditionalBranch(u16 instr);
    void thumbSWI(u16 instr);
    void thumbUnconditionalBranch(u16 instr);
    void thumbLongBranchLink(u16 instr);

    // ── Barrel shifter ────────────────────────────────────────────────────────
    u32 barrelShift(u32 val, u32 shiftType, u32 shiftAmt, bool& carry, bool regShift = false);
    u32 applyShiftImm(u32 instr, bool& carry);
    u32 applyShiftReg(u32 instr, bool& carry);

    // ── Condition check ───────────────────────────────────────────────────────
    bool checkCondition(u32 cond) const;

    // ── Memory helpers ────────────────────────────────────────────────────────
    u8  read8(u32 addr);
    u16 read16(u32 addr);
    u32 read32(u32 addr);
    void write8(u32 addr, u8  val);
    void write16(u32 addr, u16 val);
    void write32(u32 addr, u32 val);
    void biosHLE(u32 swiNum);

    // ── Overflow / carry helpers ──────────────────────────────────────────────
    static bool addOverflow(u32 a, u32 b, u32 res) {
        return (~(a ^ b) & (a ^ res)) >> 31;
    }
    static bool subOverflow(u32 a, u32 b, u32 res) {
        return ((a ^ b) & (a ^ res)) >> 31;
    }
};
