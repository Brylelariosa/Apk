#pragma once
#include "types.h"
#include "memory.h"
#include <cstring>
#include <functional>
#include <algorithm>
#include <cmath>

// ─────────────────────────────────────────────────────────────────────────────
// APU - Audio Processing Unit
// Includes: PSG (Square x2, Noise) + Direct Sound FIFO A/B
// ─────────────────────────────────────────────────────────────────────────────
struct APU {
    Memory* mem;
    static constexpr int SAMPLE_RATE  = 32768;
    static constexpr int BUFFER_SIZE  = 2048;

    float  sampleBuffer[BUFFER_SIZE*2] = {};
    int    samplePos = 0;
    int    cycles    = 0;
    int    cyclesPerSample;

    // PSG channels
    struct Sq {
        bool  enabled = false;
        u8    duty    = 2;
        int   period  = 0, timer  = 0, lenTimer = 0;
        bool  lenEnable = false;
        int   volume = 0, envTimer = 0, envPeriod = 0;
        bool  envAdd = false;
        int   pos = 0;
        float sample = 0;
    } sq1, sq2;

    struct Noise {
        bool  enabled = false;
        u16   lfsr = 0x7FFF;
        int   volume = 0, timer = 0, period = 0, lenTimer = 0;
        bool  lenEnable = false, shortMode = false;
        float sample = 0;
    } noise;

    // ── Direct Sound FIFO (Channels A & B) ──────────────────────────────────
    // Each FIFO holds 32 signed-8-bit samples filled by DMA (timing=3=Sound
    // FIFO) and drained one sample per timer tick.  This is the primary audio
    // path for GBA games (m4a / MusicPlayerAdvance).
    struct DirectSound {
        static constexpr int FIFO_SIZE = 32;
        int8_t buf[FIFO_SIZE] = {};
        int head = 0, tail = 0, count = 0;

        float currentSample = 0.0f;
        int   timerSelect   = 0;     // 0=Timer0, 1=Timer1
        bool  rightEnable   = false;
        bool  leftEnable    = false;
        float volume        = 0.5f;  // 0.5=50%, 1.0=100%

        // Debug counters
        int totalPushes = 0;  // 32-bit push() calls
        int totalPops   = 0;  // individual sample clocks
        int overflows   = 0;  // samples dropped (FIFO full)
        int dmaRequests = 0;  // DMA-needed signals emitted

        void push(u32 data) {
            for (int i = 0; i < 4; i++) {
                int8_t s = (int8_t)((data >> (i * 8)) & 0xFF);
                if (count < FIFO_SIZE) {
                    buf[tail] = s;
                    tail = (tail + 1) % FIFO_SIZE;
                    count++;
                } else {
                    overflows++;
                }
            }
            totalPushes++;
        }

        void clock() {
            if (count > 0) {
                currentSample = buf[head] / 128.0f;
                head = (head + 1) % FIFO_SIZE;
                count--;
                totalPops++;
            }
        }

        bool needsDma() const { return count <= 16; }

        void reset() {
            head = tail = count = 0;
            currentSample = 0.0f;
            memset(buf, 0, sizeof(buf));
        }
    } fifoA, fifoB;

    // GBA wires these to DMA::triggerFifo()
    std::function<void()> onFifoANeedsDma;
    std::function<void()> onFifoBNeedsDma;

    std::function<void(float*, int)> onSamplesReady;

    void init(Memory* m) {
        mem = m;
        cyclesPerSample = GBA_CPU_HZ / SAMPLE_RATE;
        memset(sampleBuffer, 0, sizeof(sampleBuffer));
    }

    void step(int cpuCycles) {
        cycles += cpuCycles;
        while (cycles >= cyclesPerSample) {
            cycles -= cyclesPerSample;
            generateSample();
        }
    }

    // Called by Timers when timerNum overflows
    void clockFifoOnTimerOverflow(int timerNum) {
        u16 sndH = (u16)mem->io[0x82] | ((u16)mem->io[0x83] << 8);
        if (((sndH >> 10) & 1) == timerNum) {
            fifoA.clock();
            if (fifoA.needsDma()) {
                fifoA.dmaRequests++;
                if (onFifoANeedsDma) onFifoANeedsDma();
            }
        }
        if (((sndH >> 14) & 1) == timerNum) {
            fifoB.clock();
            if (fifoB.needsDma()) {
                fifoB.dmaRequests++;
                if (onFifoBNeedsDma) onFifoBNeedsDma();
            }
        }
    }

    void writeSoundCntH(u16 val) {
        fifoA.volume      = (val >> 2) & 1 ? 1.0f : 0.5f;
        fifoB.volume      = (val >> 3) & 1 ? 1.0f : 0.5f;
        fifoA.rightEnable = (val >> 8)  & 1;
        fifoA.leftEnable  = (val >> 9)  & 1;
        fifoA.timerSelect = (val >> 10) & 1;
        if (val & (1 << 11)) fifoA.reset();
        fifoB.rightEnable = (val >> 12) & 1;
        fifoB.leftEnable  = (val >> 13) & 1;
        fifoB.timerSelect = (val >> 14) & 1;
        if (val & (1 << 15)) fifoB.reset();
    }

    void generateSample() {
        float left  = 0.0f;
        float right = 0.0f;

        u8 nr51 = mem->io[0x25];
        u8 nr50 = mem->io[0x24];
        float masterL = ((nr50 >> 4) & 7) / 7.0f;
        float masterR = ((nr50 >> 0) & 7) / 7.0f;

        tickSq(sq1);
        if ((nr51 >> 4) & 1) left  += sq1.sample * 0.25f;
        if ((nr51 >> 0) & 1) right += sq1.sample * 0.25f;
        tickSq(sq2);
        if ((nr51 >> 5) & 1) left  += sq2.sample * 0.25f;
        if ((nr51 >> 1) & 1) right += sq2.sample * 0.25f;
        tickNoise();
        if ((nr51 >> 7) & 1) left  += noise.sample * 0.25f;
        if ((nr51 >> 3) & 1) right += noise.sample * 0.25f;

        left  *= masterL;
        right *= masterR;

        // Direct Sound – the primary audio path for GBA games
        u8 sndX = mem->io[0x84];
        if (sndX & 0x80) {
            if (fifoA.leftEnable)  left  += fifoA.currentSample * fifoA.volume;
            if (fifoA.rightEnable) right += fifoA.currentSample * fifoA.volume;
            if (fifoB.leftEnable)  left  += fifoB.currentSample * fifoB.volume;
            if (fifoB.rightEnable) right += fifoB.currentSample * fifoB.volume;
        }

        constexpr float GAIN = 0.75f;
        sampleBuffer[samplePos*2  ] = std::max(-1.0f, std::min(1.0f, left))  * GAIN;
        sampleBuffer[samplePos*2+1] = std::max(-1.0f, std::min(1.0f, right)) * GAIN;
        samplePos++;
        if (samplePos >= BUFFER_SIZE) {
            if (onSamplesReady) onSamplesReady(sampleBuffer, BUFFER_SIZE);
            samplePos = 0;
        }
    }

    static constexpr int DUTY_TABLE[4][8] = {
        {0,0,0,0,0,0,0,1},{1,0,0,0,0,0,0,1},{1,0,0,0,0,0,1,1},{0,1,1,1,1,1,1,0}
    };
    void tickSq(Sq& sq) {
        if (!sq.enabled) { sq.sample=0; return; }
        if (--sq.timer <= 0) { sq.pos=(sq.pos+1)&7; sq.timer=sq.period; }
        sq.sample = DUTY_TABLE[sq.duty][sq.pos] ? sq.volume/15.0f : -sq.volume/15.0f;
    }
    void tickNoise() {
        if (!noise.enabled) { noise.sample=0; return; }
        if (--noise.timer <= 0) {
            noise.timer = noise.period;
            bool xb = (noise.lfsr & 1) ^ ((noise.lfsr >> 1) & 1);
            noise.lfsr >>= 1;
            if (xb) noise.lfsr |= 0x4000;
            if (noise.shortMode && xb) noise.lfsr |= 0x40;
        }
        noise.sample = (noise.lfsr & 1) ? noise.volume/15.0f : -noise.volume/15.0f;
    }
};



// ─────────────────────────────────────────────────────────────────────────────
// DMA Controller
// ─────────────────────────────────────────────────────────────────────────────
struct DMA {
    Memory* mem;

    struct Channel {
        u32  src, dst, count;
        u16  ctrl;
        bool active = false;
    } ch[4];

    void init(Memory* m) { mem=m; memset(ch,0,sizeof(ch)); }

    // Returns false if the channel should not run (safety guard)
    bool trigger(int n) {
        u32 base = 0x040000B0 + n*12;
        ch[n].src   = mem->read32(base+0) & 0x0FFFFFFF;
        ch[n].dst   = mem->read32(base+4) & 0x0FFFFFFF;
        ch[n].count = mem->read16(base+8);
        ch[n].ctrl  = mem->read16(base+10);

        // ── Safety guards ─────────────────────────────────────────────────────
        // 1. Never execute a DMA with count=0 in the IO register.
        //    The GBA spec says count=0 means max (0x4000/0x10000) but ONLY
        //    when the DMA is deliberately triggered with count already set to 0.
        //    Triggering a channel whose count hasn't been written yet (count=0
        //    because IO is zeroed at boot) causes a massive garbage transfer.
        if (ch[n].count == 0) {
            ch[n].active = false;
            return false;
        }
        // 2. Guard the BIOS communication area (0x03FFFF00-0x03FFFFFF) from
        //    being overwritten by a stray DMA. This area contains the IRQ
        //    handler pointer at 0x03FFFFFC which must not be clobbered.
        //    Legitimate DMA destinations are EWRAM, VRAM, OAM, or palette.
        u32 dstBase = ch[n].dst & 0xFF000000;
        bool dstOk = (dstBase == 0x02000000 ||  // EWRAM
                      dstBase == 0x03000000 ||   // IWRAM (upper half guarded below)
                      dstBase == 0x05000000 ||   // Palette
                      dstBase == 0x06000000 ||   // VRAM
                      dstBase == 0x07000000);    // OAM
        // Within IWRAM, block the top 256 bytes (0x03007F00-0x03007FFF and
        // their mirrors) — stack + BIOS comm area live there.
        if (dstBase == 0x03000000) {
            u32 off = (ch[n].dst - 0x03000000) & 0x7FFF;
            if (off >= 0x7F00) dstOk = false;
        }
        if (!dstOk) {
            ch[n].active = false;
            return false;
        }

        ch[n].active = true;
        return true;
    }

    // Sound-FIFO DMA: 4 words (16 bytes) → fifoAddr
    void triggerFifo(int n, u32 fifoAddr) {
        u32 base = 0x040000B0 + n*12;
        u16 ctrl = mem->read16(base + 10);
        if (!(ctrl & (1 << 15))) return;

        u32 src = mem->read32(base + 0) & 0x0FFFFFFF;
        int srcInc = (ctrl >> 7) & 3;

        for (int i = 0; i < 4; i++) {
            u32 word = mem->read32(src);
            mem->write32(fifoAddr, word); // Memory routes this to APU FIFO
            if (srcInc == 0)      src += 4;
            else if (srcInc == 1) src -= 4;
        }
        if (srcInc != 2) {
            mem->write8(base+0, src & 0xFF);
            mem->write8(base+1, (src >> 8)  & 0xFF);
            mem->write8(base+2, (src >> 16) & 0xFF);
            mem->write8(base+3, (src >> 24) & 0xFF);
        }
        if (ctrl & (1 << 14)) mem->raiseIRQ(IRQ_DMA0 << n);
    }

    // Call with the appropriate flag from PPU callbacks:
    //   step(true,  false)  → called by onVBlank  (timing=1 channels fire)
    //   step(false, true)   → called by onHBlank  (timing=2 channels fire)
    //   step(false, false)  → called by runFrame  (timing=0 immediate only)
    void step(bool vblank = false, bool hblank = false) {
        for (int n = 0; n < 4; n++) {
            u32 base = 0x040000B0 + n * 12;
            u16 ctrl = mem->read16(base + 10);
            if (!(ctrl & (1 << 15))) continue;          // channel not enabled

            u32 timing = (ctrl >> 12) & 3;
            if (timing == 3) continue;                  // Sound FIFO — triggerFifo() only

            // Only fire a channel when the correct trigger event arrives
            if (timing == 0 && !ch[n].active) { if (!trigger(n)) continue; }          // immediate
            else if (timing == 1 && vblank)   { if (!trigger(n)) continue; }          // VBlank
            else if (timing == 2 && hblank && n < 4) { if (!trigger(n)) continue; }   // HBlank
            // timing==3 already skipped above

            if (!ch[n].active) continue;

            bool word    = (ctrl >> 10) & 1;
            int  dstInc  = (ctrl >>  5) & 3;
            int  srcInc  = (ctrl >>  7) & 3;
            u32  dstStep = word ? 4 : 2;
            u32  srcStep = word ? 4 : 2;

            for (u32 i = 0; i < ch[n].count; i++) {
                if (word) mem->write32(ch[n].dst, mem->read32(ch[n].src));
                else      mem->write16(ch[n].dst, mem->read16(ch[n].src));
                if (srcInc == 0) ch[n].src += srcStep;
                else if (srcInc == 1) ch[n].src -= srcStep;
                if (dstInc == 0) ch[n].dst += dstStep;
                else if (dstInc == 1) ch[n].dst -= dstStep;
                // dstInc==2 = fixed, dstInc==3 = reload (handled on re-trigger)
            }

            if (ctrl & (1 << 14)) mem->raiseIRQ(IRQ_DMA0 << n);

            // Repeat flag: if set, keep active for next trigger; else disable channel
            if (ctrl & (1 << 9)) {
                // Reload destination if dstInc==3
                if (((ctrl >> 5) & 3) == 3) {
                    ch[n].dst = mem->read32(base + 4) & 0x0FFFFFFF;
                }
                ch[n].active = false;   // wait for next trigger event
            } else {
                mem->write16(base + 10, ctrl & ~(1 << 15));  // disable
                ch[n].active = false;
            }
        }
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// Timer Controller
// ─────────────────────────────────────────────────────────────────────────────
struct Timers {
    Memory* mem;

    struct Timer {
        u16  counter = 0, reload = 0;
        bool enable = false, cascade = false, irq = false;
        int  prescaler = 1, cycles = 0;
        bool overflow = false;
        int  totalOverflows = 0; // debug
    } t[4];

    static constexpr int PRESCALERS[4] = {1, 64, 256, 1024};

    // GBA wires this to apu.clockFifoOnTimerOverflow(n)
    std::function<void(int)> onTimerOverflow;

    void init(Memory* m) { mem=m; memset(t,0,sizeof(t)); }

    void step(int cpuCycles) {
        for (int n=0;n<4;n++) {
            u32 base = 0x04000100 + n*4;
            u16 ctrl = mem->io[(base+2)-0x04000000];
            t[n].enable    = (ctrl >> 7) & 1;
            t[n].cascade   = (ctrl >> 2) & 1;
            t[n].irq       = (ctrl >> 6) & 1;
            t[n].prescaler = PRESCALERS[ctrl & 3];
            t[n].reload    = mem->io[(base)-0x04000000] | (mem->io[(base+1)-0x04000000]<<8);

            if (!t[n].enable || t[n].cascade) continue;
            t[n].overflow = false;
            t[n].cycles += cpuCycles;
            while (t[n].cycles >= t[n].prescaler) {
                t[n].cycles -= t[n].prescaler;
                t[n].counter++;
                if (t[n].counter == 0) {
                    t[n].counter = t[n].reload;
                    t[n].overflow = true;
                    t[n].totalOverflows++;
                    if (t[n].irq) mem->raiseIRQ(IRQ_TIMER0 << n);
                    if (onTimerOverflow) onTimerOverflow(n);
                    // Cascade
                    if (n < 3 && t[n+1].cascade && t[n+1].enable) {
                        t[n+1].counter++;
                        if (t[n+1].counter == 0) {
                            t[n+1].counter = t[n+1].reload;
                            t[n+1].totalOverflows++;
                            if (t[n+1].irq) mem->raiseIRQ(IRQ_TIMER0 << (n+1));
                            if (onTimerOverflow) onTimerOverflow(n+1);
                        }
                    }
                }
            }
            mem->io[(base)-0x04000000]   = t[n].counter & 0xFF;
            mem->io[(base+1)-0x04000000] = t[n].counter >> 8;
        }
    }
};
