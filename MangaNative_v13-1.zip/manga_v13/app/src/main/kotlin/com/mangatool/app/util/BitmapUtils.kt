package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

object BitmapUtils {

    /**
     * 3-thread dispatcher for all bitmap work.
     * Dispatchers.IO allows 64 threads — that many simultaneous decodes thrashes
     * the CPU and spikes GC. 3 threads pipelines decodes smoothly.
     */
    val decodeDispatcher = Executors.newFixedThreadPool(3).asCoroutineDispatcher()

    // ── File path API — always prefer these ──────────────────────────────────
    // BitmapFactory.decodeFile() streams from the file descriptor and does NOT
    // allocate a ByteArray for the whole file. Only the decoded pixel data hits
    // the heap. This is the main reason ImageItem.data was replaced with filePath.

    /** Decode pixel dimensions without loading any pixel data. */
    fun decodeDimensions(filePath: String): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        return opts.outWidth to opts.outHeight
    }

    /**
     * Decode a thumbnail ≤ [maxPx] using RGB_565 (half the RAM of ARGB_8888).
     * Manga pages are JPEGs with no alpha — identical visual quality at 2× cache density.
     */
    fun decodeThumbnail(filePath: String, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeFile(filePath, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /** Decode at full resolution for preview or merge compositing. */
    fun decodeFull(filePath: String): Bitmap? = BitmapFactory.decodeFile(filePath)

    // ── ByteArray overload — for Uri streams only ─────────────────────────────
    // MergeImagePickerActivity reads thumbnails from content:// URIs before images
    // are imported (so there's no temp file yet). This overload keeps that path
    // working without touching the main filePath API.

    fun decodeThumbnail(bytes: ByteArray, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }
}
