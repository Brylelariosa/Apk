package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.*

class ImageThumbAdapter(
    private val items: List<Any>,   // List<ImageItem> or List<List<ImageItem>> (merge pairs)
    private val isMerge: Boolean,
    private val isRtl: Boolean,
    private val onItemClick: (Int) -> Unit,
    private val onItemLongClick: ((ImageItem) -> Unit)? = null
) : RecyclerView.Adapter<ImageThumbAdapter.VH>() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image: ImageView = v.findViewById(R.id.thumb_image)
        val overlay: View    = v.findViewById(R.id.thumb_overlay)
        var job: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (isMerge) R.layout.item_thumb_merge else R.layout.item_thumb
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.job?.cancel()
        holder.image.setImageBitmap(null)
        holder.overlay.visibility = View.GONE

        holder.itemView.setOnClickListener { onItemClick(position) }

        if (!isMerge) {
            val img = items[position] as ImageItem
            holder.overlay.visibility = if (img.userDeleted) View.VISIBLE else View.GONE
            holder.itemView.setOnLongClickListener {
                onItemLongClick?.invoke(img)
                true
            }
            val cacheKey = "th_${img.originalIdx}_${AppState.groups.hashCode()}"
            val cached = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                holder.image.setImageBitmap(cached)
                return
            }
            holder.job = scope.launch {
                val bm: Bitmap? = withContext(Dispatchers.IO) {
                    BitmapUtils.decodeThumbnail(img.data, 300)
                }
                if (bm != null) {
                    AppState.thumbCache.put(cacheKey, bm)
                    holder.image.setImageBitmap(bm)
                }
            }
        } else {
            @Suppress("UNCHECKED_CAST")
            val pair = items[position] as List<ImageItem>
            val cacheKey = "mg_${pair.map{it.originalIdx}}_${isRtl}"
            val cached = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                holder.image.setImageBitmap(cached)
                return
            }
            holder.job = scope.launch {
                val bm: Bitmap? = withContext(Dispatchers.IO) {
                    ImageMerger.mergeThumbnail(pair, isRtl, 500)
                }
                if (bm != null) {
                    AppState.thumbCache.put(cacheKey, bm)
                    holder.image.setImageBitmap(bm)
                }
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        super.onViewRecycled(holder)
    }

    fun destroy() = scope.cancel()
}
