package com.mangatool.app.adapter

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.databinding.ItemAppPickerBinding

data class AppPickerItem(
    val label: String,
    val icon: Drawable?,
    val packageName: String?,   // null = "Files App" (ACTION_OPEN_DOCUMENT)
    val activityName: String?   // null = "Files App"
)

class AppPickerAdapter(
    private val items: List<AppPickerItem>,
    private val onItemClick: (AppPickerItem) -> Unit
) : RecyclerView.Adapter<AppPickerAdapter.VH>() {

    inner class VH(val b: ItemAppPickerBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: AppPickerItem) {
            b.tvAppName.text = item.label
            if (item.icon != null) b.ivAppIcon.setImageDrawable(item.icon)
            else b.ivAppIcon.setImageResource(android.R.drawable.ic_menu_upload)
            b.root.setOnClickListener { onItemClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemAppPickerBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) =
        holder.bind(items[position])
}
