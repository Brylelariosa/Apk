package com.mangatool.app

import android.graphics.Bitmap
import android.util.LruCache
import com.mangatool.app.model.ImageGroup

object AppState {
    val groups: MutableList<ImageGroup> = mutableListOf()
    var currentMode: String = "extract"   // "extract" or "merge"
    var minSizeKb: Int = 40
    var excludeGifs: Boolean = true
    var reverseOrder: Boolean = false
    var rtlMode: Boolean = false

    // LRU bitmap cache (use 1/8 of heap for thumbnails)
    val thumbCache: LruCache<String, Bitmap> = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap) =
            value.byteCount / 1024
    }

    fun reset() {
        groups.clear()
        thumbCache.evictAll()
    }

    fun applyFilters() {
        groups.forEach { group ->
            val valid = mutableListOf<com.mangatool.app.model.ImageItem>()
            val filtered = mutableListOf<com.mangatool.app.model.ImageItem>()
            val minBytes = minSizeKb * 1024

            group.allImages.forEach { img ->
                val reason = when {
                    img.userDeleted -> "Manually Deleted"
                    img.forceKeep  -> null
                    img.size < minBytes -> "Too Small (${img.size / 1024}KB)"
                    excludeGifs && img.ext.equals("gif", true) -> "GIF Excluded"
                    else -> null
                }
                if (reason != null) filtered.add(img.copy(filterReason = reason))
                else valid.add(img)
            }

            if (reverseOrder) valid.reverse()
            group.displayImages = valid.mapIndexed { i, img ->
                img.copy(name = "${(i + 1).toString().padStart(3, '0')}.${img.ext}")
            }
            group.filteredImages = filtered
        }
    }
}
