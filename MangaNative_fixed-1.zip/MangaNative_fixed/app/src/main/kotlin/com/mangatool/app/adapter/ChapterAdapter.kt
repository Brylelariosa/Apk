package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger

class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    private val expandedMain     = mutableSetOf<Int>()
    private val expandedFiltered = mutableSetOf<Int>()
    private val thumbAdapters    = mutableMapOf<Int, ImageThumbAdapter>()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val filteredCount:   TextView    = v.findViewById(R.id.filtered_count)
        val arrow:           TextView    = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   TextView    = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        return VH(v)
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group    = groups[position]
        val isMerge  = AppState.currentMode == "merge"
        val isExpMain = position in expandedMain
        val isExpFilt = position in expandedFiltered

        // ── Header info ──────────────────────────────────────────────────────
        holder.name.text  = group.groupName
        holder.count.text = "${group.displayImages.size} images"
        holder.arrow.text = if (isExpMain) "▲" else "▼"

        // Filtered badge
        val fCount = group.filteredImages.size
        if (!isMerge && fCount > 0) {
            holder.filteredCount.visibility = View.VISIBLE
            holder.filteredCount.text = "⚠ $fCount filtered"
        } else {
            holder.filteredCount.visibility = View.GONE
        }

        // ── Main grid toggle ─────────────────────────────────────────────────
        holder.removeBtn.setOnClickListener { onGroupRemove(position) }

        holder.header.setOnClickListener {
            if (position in expandedMain) {
                expandedMain.remove(position)
                thumbAdapters.remove(position)?.destroy()
                holder.grid.adapter = null
                holder.grid.visibility = View.GONE
            } else {
                expandedMain.add(position)
                populateMainGrid(holder, position, group)
                holder.grid.visibility = View.VISIBLE
            }
            holder.arrow.text = if (position in expandedMain) "▲" else "▼"
        }

        if (isExpMain) {
            populateMainGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            holder.grid.visibility = View.GONE
        }

        // ── Filtered section ─────────────────────────────────────────────────
        if (!isMerge && fCount > 0) {
            holder.filteredSection.visibility = View.VISIBLE
            holder.filteredLabel.text = "🚫 ${fCount} filtered out — tap to review"
            holder.filteredArrow.text = if (isExpFilt) "▲" else "▼"

            holder.filteredHeader.setOnClickListener {
                if (position in expandedFiltered) {
                    expandedFiltered.remove(position)
                    holder.filteredGrid.adapter = null
                    holder.filteredGrid.visibility = View.GONE
                } else {
                    expandedFiltered.add(position)
                    populateFilteredGrid(holder, position, group)
                    holder.filteredGrid.visibility = View.VISIBLE
                }
                holder.filteredArrow.text = if (position in expandedFiltered) "▲" else "▼"
            }

            if (isExpFilt) {
                populateFilteredGrid(holder, position, group)
                holder.filteredGrid.visibility = View.VISIBLE
            } else {
                holder.filteredGrid.visibility = View.GONE
            }
        } else {
            holder.filteredSection.visibility = View.GONE
        }
    }

    // ── Main image grid ───────────────────────────────────────────────────────
    private fun populateMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == "merge"
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages)
                               else group.displayImages
        val cols = if (isMerge) 2 else 3
        val adapter = ImageThumbAdapter(
            items, isMerge, AppState.rtlMode,
            onItemClick  = { idx -> onImageClick(position, idx) },
            onItemLongClick = onImageLongClick
        )
        thumbAdapters[position]?.destroy()
        thumbAdapters[position] = adapter
        holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols)
        holder.grid.adapter = adapter
    }

    // ── Filtered image grid ───────────────────────────────────────────────────
    private fun populateFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val adapter = FilteredThumbAdapter(group.filteredImages) { img ->
            // Restore: mark forceKeep, re-apply filters
            img.forceKeep   = true
            img.userDeleted = false
            onImageRestore?.invoke(img)
        }
        holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3)
        holder.filteredGrid.adapter = adapter
    }

    fun destroy() {
        thumbAdapters.values.forEach { it.destroy() }
        thumbAdapters.clear()
    }

    override fun onViewRecycled(holder: VH) {
        holder.grid.adapter = null
        super.onViewRecycled(holder)
    }
}

// ── Filtered thumbnail adapter ────────────────────────────────────────────────
class FilteredThumbAdapter(
    private val items: List<ImageItem>,
    private val onRestore: (ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val restore: ImageButton = v.findViewById(R.id.btn_restore)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_thumb_filtered, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text  = img.filterReason ?: "Filtered"
        holder.image.setImageBitmap(null)

        val cacheKey = "filt_${img.originalIdx}"
        val cached = AppState.thumbCache.get(cacheKey)
        if (cached != null) {
            holder.image.setImageBitmap(cached)
        } else {
            holder.image.tag = cacheKey
            Thread {
                val bmp = BitmapUtils.decodeThumbnail(img.data, 200)
                if (bmp != null) {
                    AppState.thumbCache.put(cacheKey, bmp)
                    if (holder.image.tag == cacheKey) {
                        holder.image.post { holder.image.setImageBitmap(bmp) }
                    }
                }
            }.start()
        }

        holder.restore.setOnClickListener { onRestore(img) }
    }
}
