package com.mangatool.app

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.mangatool.app.adapter.PreviewPagerAdapter
import com.mangatool.app.databinding.ActivityImagePreviewBinding
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImagePreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GROUP_IDX  = "group_idx"
        const val EXTRA_IMAGE_IDX  = "image_idx"
        const val EXTRA_IS_MERGE   = "is_merge"
    }

    private lateinit var b: ActivityImagePreviewBinding
    private var groupIdx = 0
    private var isMerge  = false
    private var pagerAdapter: PreviewPagerAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityImagePreviewBinding.inflate(layoutInflater)
        setContentView(b.root)

        groupIdx = intent.getIntExtra(EXTRA_GROUP_IDX, 0)
        isMerge  = intent.getBooleanExtra(EXTRA_IS_MERGE, false)
        val startIdx = intent.getIntExtra(EXTRA_IMAGE_IDX, 0)

        val group = AppState.groups.getOrNull(groupIdx) ?: run { finish(); return }

        // Build the list of preview items
        b.previewLoading.visibility = View.VISIBLE
        lifecycleScope.launch {
            val items: List<Any> = withContext(Dispatchers.IO) {
                if (isMerge) {
                    ImageMerger.pairImages(group.displayImages).map { pair ->
                        ImageMerger.merge(pair, AppState.rtlMode) ?: pair[0].data
                    }
                } else {
                    group.displayImages.map { it.data }
                }
            }
            b.previewLoading.visibility = View.GONE
            pagerAdapter = PreviewPagerAdapter(items)
            b.viewPager.adapter = pagerAdapter
            b.viewPager.setCurrentItem(startIdx, false)
            updateCounter(startIdx, items.size)

            b.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateCounter(position, items.size)
                    updateDeleteBtn(position)
                }
            })
            updateDeleteBtn(startIdx)
        }

        b.closeBtn.setOnClickListener { finish() }
        b.prevBtn.setOnClickListener { b.viewPager.currentItem -= 1 }
        b.nextBtn.setOnClickListener { b.viewPager.currentItem += 1 }

        b.deleteBtn.setOnClickListener {
            val pos = b.viewPager.currentItem
            if (!isMerge) {
                val img = group.displayImages.getOrNull(pos) ?: return@setOnClickListener
                val orig = group.allImages.find { it.originalIdx == img.originalIdx }
                orig?.userDeleted = true
                orig?.forceKeep  = false
                AppState.applyFilters()
                Toast.makeText(this, "Image deleted", Toast.LENGTH_SHORT).show()
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    private fun updateCounter(pos: Int, total: Int) {
        b.previewCounter.text = "${pos + 1} / $total"
    }

    private fun updateDeleteBtn(pos: Int) {
        // Only show delete in extract mode
        b.deleteBtn.visibility = if (isMerge) View.GONE else View.VISIBLE
    }

    override fun onDestroy() {
        pagerAdapter?.destroy()
        super.onDestroy()
    }
}
