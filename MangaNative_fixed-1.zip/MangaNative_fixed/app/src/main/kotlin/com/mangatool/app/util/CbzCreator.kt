package com.mangatool.app.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object CbzCreator {

    data class Progress(val message: String, val percent: Int)

    /**
     * Write all groups to a single CBZ in Downloads.
     * Returns the URI of the saved file so callers can share/open it.
     */
    fun create(
        context: Context,
        groups: List<ImageGroup>,
        filename: String = "Manga_Batch.cbz",
        isMerge: Boolean = false,
        isRtl: Boolean = false,
        onProgress: (Progress) -> Unit
    ): Uri {
        val (outStream, savedUri) = openOutputStream(context, filename)
            ?: throw IllegalStateException("Cannot open output stream")

        ZipOutputStream(outStream.buffered()).use { zip ->
            var totalImages = 0
            groups.forEach { g ->
                totalImages += if (isMerge) ImageMerger.pairImages(g.displayImages).size
                               else g.displayImages.size
            }
            var done = 0

            groups.forEach { group ->
                val safeName = group.groupName.replace(Regex("[\\\\/:*?\"<>|]"), "_")

                if (isMerge) {
                    val pairs = ImageMerger.pairImages(group.displayImages)
                    pairs.forEachIndexed { i, pair ->
                        onProgress(Progress("Merging ${group.groupName} ($i/${pairs.size})",
                            (done * 100) / totalImages))
                        val bm = ImageMerger.merge(pair, isRtl)
                        if (bm != null) {
                            val bytes = bitmapToJpegBytes(bm)
                            bm.recycle()
                            val entryName = "$safeName/${(i + 1).toString().padStart(4, '0')}.jpg"
                            zip.putNextEntry(ZipEntry(entryName))
                            zip.write(bytes)
                            zip.closeEntry()
                        }
                        done++
                    }
                } else {
                    group.displayImages.forEachIndexed { i, img ->
                        if (i % 20 == 0) onProgress(Progress(
                            "Compressing ${group.groupName} ($i/${group.displayImages.size})",
                            (done * 100) / totalImages))
                        val entryName = "$safeName/${img.name}"
                        zip.putNextEntry(ZipEntry(entryName))
                        zip.write(img.data)
                        zip.closeEntry()
                        done++
                    }
                }
            }
        }

        onProgress(Progress("Done!", 100))
        return savedUri
    }

    private fun bitmapToJpegBytes(bm: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bm.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return out.toByteArray()
    }

    /**
     * Returns (OutputStream, shareable Uri) pair.
     * On Android Q+ we use MediaStore so the URI stays valid for sharing.
     * On older Android we write to the public Downloads dir and wrap via FileProvider.
     */
    private fun openOutputStream(context: Context, filename: String): Pair<OutputStream, Uri>? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver
                .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            val stream = context.contentResolver.openOutputStream(uri) ?: return null

            val wrappedStream = object : OutputStream() {
                override fun write(b: Int) = stream.write(b)
                override fun write(b: ByteArray, off: Int, len: Int) = stream.write(b, off, len)
                override fun flush() = stream.flush()
                override fun close() {
                    stream.close()
                    cv.clear()
                    cv.put(MediaStore.Downloads.IS_PENDING, 0)
                    context.contentResolver.update(uri, cv, null, null)
                }
            }
            wrappedStream to uri
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val file = File(dir, filename)
            val uri = FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            file.outputStream() to uri
        }
    }
}
