package com.mangatool.app.model

data class ImageItem(
    val originalIdx: Int,
    val data: ByteArray,
    val ext: String,
    val size: Int,
    var name: String = "",
    var userDeleted: Boolean = false,
    var forceKeep: Boolean = false,
    var filterReason: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ImageItem) return false
        return originalIdx == other.originalIdx
    }
    override fun hashCode() = originalIdx
}

data class ImageGroup(
    val groupName: String,
    val allImages: MutableList<ImageItem> = mutableListOf(),
    var displayImages: List<ImageItem> = emptyList(),
    var filteredImages: List<ImageItem> = emptyList()
)
