package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.mangatool.app.adapter.AppPickerAdapter
import com.mangatool.app.adapter.AppPickerItem
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetAppPickerBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var isProcessing = false

    // ── File pickers ──────────────────────────────────────────────────────────
    // ACTION_OPEN_DOCUMENT (Files app, scoped storage)
    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data)
    }

    // ACTION_GET_CONTENT (any app chooser)
    private val getContentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data)
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, "Storage permission needed", Toast.LENGTH_LONG).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        setupControls()
        setupActionBar()
        setMode("extract")   // sets tab styling + shows correct UI
        refreshUI()
    }

    // ── UI setup ──────────────────────────────────────────────────────────────
    private fun setupControls() {
        b.tabExtract.setOnClickListener { setMode("extract") }
        b.tabMerge.setOnClickListener   { setMode("merge") }

        b.settingsToggle.setOnClickListener {
            val v = b.settingsPanel
            v.visibility = if (v.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.applyFilters(); refreshChapterList() }
        })

        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleRtl.isChecked     = AppState.rtlMode

        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;    AppState.applyFilters(); refreshChapterList() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c;   AppState.applyFilters(); refreshChapterList() }
        b.toggleRtl.setOnCheckedChangeListener     { _, c -> AppState.rtlMode = c;        AppState.applyFilters(); refreshChapterList() }

        b.dropZone.setOnClickListener { showFileManagerChooser() }
        b.chapterList.layoutManager = LinearLayoutManager(this)
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener  { showFileManagerChooser() }
        b.btnDownload.setOnClickListener { startDownload() }
        b.btnViewAll.setOnClickListener  { openAllPhotos() }
        b.btnReset.setOnClickListener {
            chapterAdapter?.destroy()
            chapterAdapter = null
            b.chapterList.adapter = null
            AppState.reset()
            refreshUI()
        }
    }

    // ── Mode ──────────────────────────────────────────────────────────────────
    private fun setMode(mode: String) {
        AppState.currentMode = mode
        // Tab styling: filled = active, outlined = inactive
        b.tabExtract.setBackgroundResource(0)
        b.tabMerge.setBackgroundResource(0)
        if (mode == "extract") {
            b.tabExtract.alpha = 1f
            b.tabMerge.alpha   = 0.5f
        } else {
            b.tabExtract.alpha = 0.5f
            b.tabMerge.alpha   = 1f
        }
        b.rtlRow.visibility = if (mode == "merge") View.VISIBLE else View.GONE
        AppState.applyFilters()
        refreshChapterList()
    }

    private fun updateSizeLabel() { b.sizeLabel.text = "${AppState.minSizeKb} KB" }

    // ── Refresh UI ────────────────────────────────────────────────────────────
    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        b.dropZone.visibility   = if (hasGroups) View.GONE else View.VISIBLE
        b.chapterList.visibility= if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility  = if (hasGroups) View.VISIBLE else View.GONE

        if (hasGroups) {
            val totalImgs     = AppState.groups.sumOf { it.displayImages.size }
            val totalFiltered = AppState.groups.sumOf { it.filteredImages.size }
            val totalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
            val sizeStr = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb}KB"
            val filteredStr = if (totalFiltered > 0) "  ⚠ $totalFiltered filtered" else ""
            b.statsText.text = "${AppState.groups.size} files · $totalImgs imgs · $sizeStr$filteredStr"
            b.btnDownload.text = "Download CBZ (~$sizeStr)"
            b.btnViewAll.text = "View All $totalImgs Photos →"
        }
    }

    private fun refreshChapterList() {
        chapterAdapter?.destroy()
        chapterAdapter = ChapterAdapter(
            groups       = AppState.groups,
            onImageClick = { gIdx, iIdx ->
                val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, iIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == "merge")
                }
                previewLauncher.launch(intent)
            },
            onGroupRemove = { idx ->
                AppState.groups.removeAt(idx)
                AppState.applyFilters()
                refreshChapterList()
                refreshUI()
            },
            onImageLongClick = { img ->
                img.userDeleted = true; img.forceKeep = false
                AppState.applyFilters(); refreshChapterList()
            },
            onImageRestore = { img ->
                img.forceKeep = true; img.userDeleted = false
                AppState.applyFilters(); refreshChapterList()
            }
        )
        b.chapterList.adapter = chapterAdapter
        refreshUI()
    }

    // ── File manager chooser ──────────────────────────────────────────────────
    private fun showFileManagerChooser() {
        // Build a probe intent to find every app that can pick files
        val probe = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        val pm = packageManager
        val resolvedApps: List<ResolveInfo> = pm.queryIntentActivities(probe, 0)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        // Build picker items: real apps first, then a dedicated "Files App" entry
        val items = mutableListOf<AppPickerItem>()

        // Always add Files App (ACTION_OPEN_DOCUMENT) as first option
        items.add(
            AppPickerItem(
                label        = "Files App\n(Recommended)",
                icon         = ContextCompat.getDrawable(this, android.R.drawable.ic_menu_manage),
                packageName  = null,
                activityName = null
            )
        )

        // Add every installed app that handles the intent
        for (info in resolvedApps) {
            val pkgName = info.activityInfo.packageName
            // Skip our own app
            if (pkgName == packageName) continue
            items.add(
                AppPickerItem(
                    label        = info.loadLabel(pm).toString(),
                    icon         = info.loadIcon(pm),
                    packageName  = pkgName,
                    activityName = info.activityInfo.name
                )
            )
        }

        // Build the bottom sheet
        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheetBinding = BottomSheetAppPickerBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)

        val adapter = AppPickerAdapter(items) { item ->
            dialog.dismiss()
            if (item.packageName == null) {
                openDocumentPicker()       // Files App
            } else {
                launchSpecificApp(item)    // targeted app
            }
        }
        sheetBinding.rvApps.layoutManager = GridLayoutManager(this, 4)
        sheetBinding.rvApps.adapter = adapter

        sheetBinding.tvCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun launchSpecificApp(item: AppPickerItem) {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "image/jpeg", "image/png", "image/webp", "image/gif",
                "multipart/related", "message/rfc822", "application/octet-stream"
            ))
            addCategory(Intent.CATEGORY_OPENABLE)
            if (item.packageName != null && item.activityName != null) {
                component = ComponentName(item.packageName, item.activityName)
            }
        }
        getContentLauncher.launch(intent)
    }

    private fun openDocumentPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "image/jpeg", "image/png", "image/webp", "image/gif",
                "multipart/related", "message/rfc822", "application/octet-stream"
            ))
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        openDocLauncher.launch(intent)
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount)
                .map { data.clipData!!.getItemAt(it).uri }
            data?.data != null -> listOf(data.data!!)
            else -> emptyList()
        }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    // ── File processing ───────────────────────────────────────────────────────
    private fun processFiles(uris: List<Uri>) {
        if (isProcessing) return
        isProcessing = true
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility = View.GONE
        b.actionBar.visibility = View.GONE

        lifecycleScope.launch {
            val looseImages = mutableListOf<ImageItem>()

            uris.forEachIndexed { i, uri ->
                withContext(Dispatchers.Main) {
                    b.progressStatus.text = "Reading ${i + 1}/${uris.size}…"
                    b.progressBar.progress = (i * 100) / uris.size
                }

                val name = getFileName(uri).lowercase()
                val data: ByteArray? = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull()
                }
                if (data == null) return@forEachIndexed

                when {
                    name.endsWith(".mhtml") || name.endsWith(".mht") -> {
                        val group = withContext(Dispatchers.IO) {
                            MhtmlParser.parse(data, getFileName(uri))
                        }
                        if (group != null) AppState.groups.add(group)
                    }
                    name.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)")) -> {
                        val ext = name.substringAfterLast('.')
                        looseImages.add(ImageItem(looseImages.size, data, ext, data.size))
                    }
                }
            }

            if (looseImages.isNotEmpty()) {
                AppState.groups.add(
                    ImageGroup("Loose Images ${AppState.groups.size + 1}")
                        .also { it.allImages.addAll(looseImages) }
                )
            }

            AppState.applyFilters()
            isProcessing = false
            b.progressArea.visibility = View.GONE
            refreshChapterList()
        }
    }

    private fun getFileName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            it.moveToFirst()
            if (idx >= 0) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"
    }

    // ── Download ──────────────────────────────────────────────────────────────
    private fun startDownload() {
        if (AppState.groups.isEmpty()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        val isMerge = AppState.currentMode == "merge"

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                CbzCreator.create(
                    context    = this@MainActivity,
                    groups     = AppState.groups,
                    isMerge    = isMerge,
                    isRtl      = AppState.rtlMode,
                    onProgress = { p ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            b.progressStatus.text  = p.message
                            b.progressBar.progress = p.percent
                        }
                    }
                )
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    b.btnDownload.text        = "✅ Saved to Downloads!"
                    Toast.makeText(this@MainActivity, "Saved to Downloads!", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── View All Photos ───────────────────────────────────────────────────────
    private fun openAllPhotos() {
        if (AppState.groups.isEmpty()) return
        startActivity(Intent(this, AllPhotosActivity::class.java))
    }

    // ── Preview result ────────────────────────────────────────────────────────
    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            AppState.applyFilters()
            refreshChapterList()
        }
    }
}
