package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.mangatool.app.model.ImageItem

object ImageMerger {

    /**
     * Merge a pair of images (1 or 2) into a single Bitmap.
     * @param isRtl  true = right page on left side (manga reading order)
     */
    fun merge(pair: List<ImageItem>, isRtl: Boolean): Bitmap? {
        val bm1 = BitmapUtils.decodeFull(pair[0].data) ?: return null
        val bm2 = if (pair.size > 1) BitmapUtils.decodeFull(pair[1].data) else null

        if (bm2 == null) return bm1

        val w = bm1.width + bm2.width
        val h = maxOf(bm1.height, bm2.height)
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)

        if (isRtl) {
            canvas.drawBitmap(bm2, 0f, 0f, null)
            canvas.drawBitmap(bm1, bm2.width.toFloat(), 0f, null)
        } else {
            canvas.drawBitmap(bm1, 0f, 0f, null)
            canvas.drawBitmap(bm2, bm1.width.toFloat(), 0f, null)
        }

        bm1.recycle()
        bm2.recycle()
        return result
    }

    /**
     * Merge thumbnail (fast — decodes at reduced size for gallery preview).
     */
    fun mergeThumbnail(pair: List<ImageItem>, isRtl: Boolean, maxPx: Int = 400): Bitmap? {
        val bm1 = BitmapUtils.decodeThumbnail(pair[0].data, maxPx) ?: return null
        val bm2 = if (pair.size > 1) BitmapUtils.decodeThumbnail(pair[1].data, maxPx) else null

        if (bm2 == null) return bm1

        val w = bm1.width + bm2.width
        val h = maxOf(bm1.height, bm2.height)
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)

        if (isRtl) {
            canvas.drawBitmap(bm2, 0f, 0f, null)
            canvas.drawBitmap(bm1, bm2.width.toFloat(), 0f, null)
        } else {
            canvas.drawBitmap(bm1, 0f, 0f, null)
            canvas.drawBitmap(bm2, bm1.width.toFloat(), 0f, null)
        }

        bm1.recycle()
        bm2.recycle()
        return result
    }

    /** Split display images into pairs. */
    fun pairImages(images: List<ImageItem>): List<List<ImageItem>> =
        images.chunked(2)
}
