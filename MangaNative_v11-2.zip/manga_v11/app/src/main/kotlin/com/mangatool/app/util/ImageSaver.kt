package com.mangatool.app.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import java.io.ByteArrayOutputStream
import java.io.File

object ImageSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val uris: List<Uri>, val folderName: String)

    // ── Cache hygiene ─────────────────────────────────────────────────────────
    /**
     * Delete the entire share_temp cache. Call:
     *  - on app start (onCreate)
     *  - after the share intent is sent
     *  - when the user resets
     * This prevents the cache from growing indefinitely across sessions.
     */
    fun clearShareCache(context: Context) {
        File(context.cacheDir, "share_temp").deleteRecursively()
    }

    /** Returns human-readable size of the share cache, e.g. "12 MB". */
    fun shareCacheSize(context: Context): String {
        val bytes = File(context.cacheDir, "share_temp")
            .walkTopDown().filter { it.isFile }.sumOf { it.length() }
        return when {
            bytes > 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
            bytes > 1024      -> "${bytes / 1024} KB"
            else              -> "$bytes B"
        }
    }

    // ── Save merged images as individual JPEGs in a named folder ──────────────
    fun saveMergeAsImages(
        context: Context,
        groups: List<ImageGroup>,
        folderName: String,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val uris = mutableListOf<Uri>()
        val safe = folderName.sanitize()
        var total = groups.sumOf { ImageMerger.pairImages(it.displayImages).size }.coerceAtLeast(1)
        var done  = 0

        groups.forEach { group ->
            val pairs = ImageMerger.pairImages(group.displayImages)
            pairs.forEachIndexed { i, pair ->
                onProgress(Progress("Merging ${group.groupName} (${i + 1}/${pairs.size})", (done * 100) / total))
                val swapped = group.pairSwaps.contains(i)
                val bm = ImageMerger.merge(pair, swapped) ?: run { done++; return@forEachIndexed }
                val bytes = bm.toJpegBytes(92); bm.recycle()
                val filename = "${(done + 1).toString().padStart(4, '0')}.jpg"
                val uri = saveBytesToDownloads(context, bytes, filename, "image/jpeg", safe)
                if (uri != null) uris.add(uri)
                done++
            }
        }

        onProgress(Progress("Done! ${uris.size} images saved", 100))
        return SaveResult(uris, safe)
    }

    // ── Save extracted images as a folder in Downloads ────────────────────────
    fun saveExtractAsFolder(
        context: Context,
        groups: List<ImageGroup>,
        folderName: String,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val uris  = mutableListOf<Uri>()
        val safe  = folderName.sanitize()
        val total = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
        var done  = 0

        groups.forEach { group ->
            val groupSafe = group.groupName.sanitize()
            group.displayImages.forEachIndexed { i, img ->
                if (i % 10 == 0) onProgress(Progress(
                    "Saving ${group.groupName} (${i + 1}/${group.displayImages.size})", (done * 100) / total))
                val subfolder = if (groups.size > 1) "$safe/$groupSafe" else safe
                val uri = saveBytesToDownloads(context, img.data, img.name, mimeForExt(img.ext), subfolder)
                if (uri != null) uris.add(uri)
                done++
            }
        }

        onProgress(Progress("Done! ${uris.size} images saved", 100))
        return SaveResult(uris, safe)
    }

    // ── Build share URIs (temp cache, no gallery save) ────────────────────────
    /**
     * Encodes images as JPEG into a *session-unique* subdirectory so that
     * concurrent or back-to-back shares never collide or accumulate.
     *
     * The caller MUST call [clearShareCache] after startActivity() so the
     * temp files don't pile up. Session dirs are also cleaned on app start.
     *
     * @param groups     Which groups to include (pass a single-element list for per-chapter share)
     * @param isMerge    True when in Merge mode
     */
    fun buildShareUris(
        context: Context,
        groups: List<ImageGroup>,
        isMerge: Boolean,
        onProgress: (Progress) -> Unit
    ): List<Uri> {
        // Session-unique dir so parallel shares never clobber each other
        val sessionDir = File(context.cacheDir, "share_temp/${System.currentTimeMillis()}").also {
            it.mkdirs()
        }
        val uris = mutableListOf<Uri>()
        var idx  = 0

        if (isMerge) {
            val total = groups.sumOf { ImageMerger.pairImages(it.displayImages).size }.coerceAtLeast(1)
            groups.forEach { group ->
                val pairs = ImageMerger.pairImages(group.displayImages)
                pairs.forEachIndexed { i, pair ->
                    onProgress(Progress("Preparing ${i + 1}/$total…", (idx * 100) / total))
                    val swapped = group.pairSwaps.contains(i)
                    val bm = ImageMerger.merge(pair, swapped) ?: run { idx++; return@forEachIndexed }
                    val file = File(sessionDir, "${(idx + 1).toString().padStart(4, '0')}.jpg")
                    file.writeBytes(bm.toJpegBytes(92)); bm.recycle()
                    uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                    idx++
                }
            }
        } else {
            val total = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
            groups.forEach { group ->
                group.displayImages.forEach { img ->
                    if (idx % 10 == 0) onProgress(Progress("Preparing ${idx + 1}/$total…", (idx * 100) / total))
                    val ext = img.ext.lowercase()
                    val file = File(sessionDir, "${(idx + 1).toString().padStart(4, '0')}.jpg")
                    if (ext == "jpg" || ext == "jpeg") {
                        file.writeBytes(img.data)
                    } else {
                        val bm = BitmapUtils.decodeFull(img.data)
                        if (bm != null) { file.writeBytes(bm.toJpegBytes(92)); bm.recycle() }
                        else file.writeBytes(img.data)
                    }
                    uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                    idx++
                }
            }
        }

        onProgress(Progress("Ready", 100))
        return uris
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun saveBytesToDownloads(
        ctx: Context, bytes: ByteArray, filename: String, mime: String, subfolder: String
    ): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$subfolder")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
                ctx.contentResolver.update(uri, cv, null, null)
            }
            uri
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), subfolder
            ).also { it.mkdirs() }
            val file = File(dir, filename)
            runCatching { file.writeBytes(bytes) }
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        }
    }

    private fun mimeForExt(ext: String) = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/*"
    }

    fun Bitmap.toJpegBytes(quality: Int = 92): ByteArray {
        val out = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, quality, out)
        return out.toByteArray()
    }

    private fun Bitmap.toPngBytes(): ByteArray {
        val out = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.PNG, 0, out)
        return out.toByteArray()
    }

    private fun String.sanitize() =
        replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "MIE_Export" }
}
