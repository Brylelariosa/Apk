package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.adapter.AppPickerAdapter
import com.mangatool.app.adapter.AppPickerItem
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetAppPickerBinding
import com.mangatool.app.databinding.BottomSheetSavedBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var chapterTouchHelper: ItemTouchHelper? = null
    private var processingJob: Job? = null

    // ── File pickers ───────────────────────────────────────────────────────────
    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data) }

    private val getContentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data) }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, getString(R.string.permission_storage_needed), Toast.LENGTH_LONG).show()
    }

    private val mergePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uriStrings = result.data?.getStringArrayListExtra(MergeImagePickerActivity.RESULT_URIS)
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) processFiles(uris)
        }
    }

    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) { AppState.applyFilters(); refreshChapterList() }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.init(this)
        AppState.minSizeKb    = Prefs.minSizeKb
        AppState.excludeGifs  = Prefs.excludeGifs
        AppState.reverseOrder = Prefs.reverseOrder

        // Clear stale share cache from previous sessions — prevents piling up
        ImageSaver.clearShareCache(this)

        setupTabs()
        setupControls()
        setupActionBar()
        setupDragToReorder()
        applyMode(AppMode.EXTRACT)
        handleIncomingShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIncomingShareIntent(intent) }
    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); AppState.trimThumbCache(level) }
    override fun onDestroy() { processingJob?.cancel(); super.onDestroy() }

    // ── Incoming share ─────────────────────────────────────────────────────────
    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) { processFiles(uris); setIntent(Intent(Intent.ACTION_MAIN)) }
    }

    // ── Tabs ───────────────────────────────────────────────────────────────────
    private fun setupTabs() {
        b.tabExtract.setOnClickListener { applyMode(AppMode.EXTRACT) }
        b.tabMerge.setOnClickListener   { applyMode(AppMode.MERGE) }
    }

    private fun applyMode(mode: AppMode) {
        AppState.currentMode = mode
        val active   = 0xFFFFFFFF.toInt()
        val inactive = 0xFF9090B0.toInt()
        if (mode == AppMode.EXTRACT) {
            b.tabExtract.setBackgroundResource(R.drawable.bg_tab_active); b.tabExtract.setTextColor(active)
            b.tabMerge.setBackgroundResource(android.R.color.transparent); b.tabMerge.setTextColor(inactive)
        } else {
            b.tabMerge.setBackgroundResource(R.drawable.bg_tab_active); b.tabMerge.setTextColor(active)
            b.tabExtract.setBackgroundResource(android.R.color.transparent); b.tabExtract.setTextColor(inactive)
        }
        b.settingsToggle.visibility = if (mode == AppMode.EXTRACT) View.VISIBLE else View.GONE
        if (mode != AppMode.EXTRACT) b.settingsPanel.visibility = View.GONE
        AppState.applyFilters(); refreshChapterList()
    }

    // ── Controls ───────────────────────────────────────────────────────────────
    private fun setupControls() {
        b.settingsToggle.setOnClickListener {
            b.settingsPanel.visibility = if (b.settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; Prefs.minSizeKb = v; updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.applyFilters(); refreshChapterList() }
        })
        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;  Prefs.excludeGifs = c;  AppState.applyFilters(); refreshChapterList() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c; Prefs.reverseOrder = c; AppState.applyFilters(); refreshChapterList() }
        b.dropZone.setOnClickListener { showFileManagerChooser() }
        b.chapterList.layoutManager = LinearLayoutManager(this)
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener     { showFileManagerChooser() }
        b.btnDownload.setOnClickListener    { startSave(asCbz = false) }
        b.btnSaveCbz.setOnClickListener     { startSave(asCbz = true) }
        b.btnShareDirect.setOnClickListener { startShareAll() }
        b.btnViewAll.setOnClickListener     { openAllPhotos() }
        b.btnReset.setOnClickListener {
            chapterAdapter?.destroy(); chapterAdapter = null
            b.chapterList.adapter = null
            AppState.reset()
            ImageSaver.clearShareCache(this)
            refreshChapterList()
        }
    }

    private fun setupDragToReorder() {
        val callback = object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                val f = from.adapterPosition; val t = to.adapterPosition
                if (f < 0 || t < 0) return false
                Collections.swap(AppState.groups, f, t); chapterAdapter?.notifyItemMoved(f, t); return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
            override fun isLongPressDragEnabled() = false
        }
        chapterTouchHelper = ItemTouchHelper(callback).also { it.attachToRecyclerView(b.chapterList) }
    }

    private fun updateSizeLabel() { b.sizeLabel.text = getString(R.string.size_kb, AppState.minSizeKb) }

    // ── Refresh UI ─────────────────────────────────────────────────────────────
    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        val isMerge   = AppState.currentMode == AppMode.MERGE

        b.dropZone.visibility    = if (hasGroups) View.GONE  else View.VISIBLE
        b.chapterList.visibility = if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility   = if (hasGroups) View.VISIBLE else View.GONE
        b.mergeTip.visibility    = if (isMerge && hasGroups) View.VISIBLE else View.GONE

        if (hasGroups) {
            b.btnDownload.text = if (isMerge) "💾 Save Images" else "📁 Save Folder"
            b.btnSaveCbz.visibility = if (isMerge) View.GONE else View.VISIBLE
        }

        if (isMerge && hasGroups) {
            val totalImages = AppState.groups.sumOf { it.displayImages.size }
            b.mergeImageCount.text = getString(R.string.merge_image_count, totalImages, (totalImages + 1) / 2)
        }

        b.btnAddMore.text = if (isMerge) getString(R.string.btn_add_images) else getString(R.string.btn_add_more)

        if (hasGroups) {
            val totalImgs     = AppState.groups.sumOf { it.displayImages.size }
            val totalFiltered = AppState.groups.sumOf { it.filteredImages.size }
            val totalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
            val sizeStr       = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb} KB"
            b.statsText.text = if (isMerge) {
                getString(R.string.stats_merge, AppState.groups.size, totalImgs, (totalImgs + 1) / 2, sizeStr)
            } else {
                if (totalFiltered > 0) getString(R.string.stats_extract_filtered, AppState.groups.size, totalImgs, sizeStr, totalFiltered)
                else getString(R.string.stats_extract, AppState.groups.size, totalImgs, sizeStr)
            }
        }
    }

    private fun refreshChapterList() {
        chapterAdapter?.destroy()
        chapterAdapter = ChapterAdapter(
            groups            = AppState.groups,
            onImageClick      = { gIdx, iIdx ->
                previewLauncher.launch(Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, iIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == AppMode.MERGE)
                })
            },
            onGroupRemove     = { idx -> AppState.groups.removeAt(idx); AppState.applyFilters(); refreshChapterList() },
            // ── Per-chapter share ──────────────────────────────────────────────
            onGroupShare      = { idx -> shareGroup(idx) },
            // ── Per-chapter rename ─────────────────────────────────────────────
            onGroupRename     = { idx -> renameGroup(idx) },
            onImageLongClick  = { img -> img.userDeleted = true; img.forceKeep = false; AppState.applyFilters(); refreshChapterList() },
            onImageRestore    = { img -> img.forceKeep = true; img.userDeleted = false; AppState.applyFilters(); refreshChapterList() },
            onFilteredPreview = { gIdx, filtIdx ->
                previewLauncher.launch(Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, filtIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_FILTERED, true)
                })
            },
            onBatchRestore    = { gIdx ->
                AppState.groups.getOrNull(gIdx)?.allImages?.forEach { if (!it.userDeleted) it.forceKeep = true }
                AppState.applyFilters(); refreshChapterList()
                Toast.makeText(this, getString(R.string.toast_restored_all), Toast.LENGTH_SHORT).show()
            }
        )
        b.chapterList.adapter = chapterAdapter
        chapterAdapter?.touchHelper = chapterTouchHelper
        refreshUI()
    }

    // ── Per-chapter share ──────────────────────────────────────────────────────
    private fun shareGroup(groupIdx: Int) {
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val isMerge = AppState.currentMode == AppMode.MERGE

        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(
                    context    = this@MainActivity,
                    groups     = listOf(group),  // only this chapter
                    isMerge    = isMerge,
                    onProgress = { p -> lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }}
                )
            }.onSuccess { uris ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    showSavedSheet(
                        title     = "Share "${group.groupName}"",
                        subtitle  = "${uris.size} image${if (uris.size == 1) "" else "s"} ready",
                        shareUris = uris,
                        saveFirst = false   // share-only sheet
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Per-chapter rename ─────────────────────────────────────────────────────
    private fun renameGroup(groupIdx: Int) {
        val group = AppState.groups.getOrNull(groupIdx) ?: return
        val input = EditText(this).apply {
            setText(group.groupName); setSelection(0, group.groupName.length)
            hint = "Chapter name"; setPadding(48, 24, 48, 8)
        }
        AlertDialog.Builder(this).setTitle("Rename chapter").setView(input)
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString().trim().ifBlank { group.groupName }
                // ImageGroup is a data class — replace in list
                AppState.groups[groupIdx] = group.copy(groupName = newName)
                refreshChapterList()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ── File manager chooser ───────────────────────────────────────────────────
    private fun showFileManagerChooser() {
        if (AppState.currentMode == AppMode.MERGE) {
            mergePickerLauncher.launch(Intent(this, MergeImagePickerActivity::class.java)); return
        }
        val pm = packageManager
        val probeGet = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val probeDoc = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val blocked = setOf("com.android.providers.media","com.android.providers.media.photopicker",
            "com.android.photopicker","com.google.android.providers.media",
            "com.google.android.apps.nbu.files", packageName)
        val seen = mutableSetOf<String>(); val items = mutableListOf<AppPickerItem>()
        fun addApp(pkg: String, actName: String?, actionType: String) {
            if (pkg in blocked || !seen.add(pkg)) return
            runCatching {
                val info = pm.getApplicationInfo(pkg, 0)
                val icon = runCatching { if (actName != null) pm.getActivityIcon(ComponentName(pkg, actName)) else pm.getApplicationIcon(info) }.getOrElse { pm.getApplicationIcon(info) }
                items.add(AppPickerItem(pm.getApplicationLabel(info).toString(), icon, pkg, actName, actionType))
            }
        }
        pm.queryIntentActivities(probeGet, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }.forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "GET_CONTENT") }
        pm.queryIntentActivities(probeDoc, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }.forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "OPEN_DOCUMENT") }
        listOf("ru.zdevs.zarchiver","com.amaze.filemanager","com.ghisler.android.TotalCommander","com.estrongs.android.pop","nextapp.fx","com.cxinventor.file.explorer","com.sec.android.app.myfiles","com.mi.android.globalFileExplorer","com.asus.filemanager","com.coloros.filemanager","com.rhmsoft.fm")
            .forEach { pkg -> if (pm.getLaunchIntentForPackage(pkg) != null) addApp(pkg, null, "GET_CONTENT") }

        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet = BottomSheetAppPickerBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvPickerTitle.text = getString(R.string.picker_title)
        sheet.tvSubtitle.text   = getString(R.string.picker_subtitle)
        sheet.rvApps.layoutManager = GridLayoutManager(this, 4)
        sheet.rvApps.adapter = AppPickerAdapter(items) { item -> dialog.dismiss(); launchAppOrGuide(item) }
        sheet.tvCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun launchAppOrGuide(item: AppPickerItem) {
        if (item.packageName == "ru.zdevs.zarchiver") {
            packageManager.getLaunchIntentForPackage("ru.zdevs.zarchiver")?.let {
                startActivity(it)
                Snackbar.make(b.root, getString(R.string.zarchiver_hint), Snackbar.LENGTH_LONG)
                    .setBackgroundTint(0xFF7C3AED.toInt()).setTextColor(0xFFFFFFFF.toInt()).show()
            }; return
        }
        val action = if (item.actionType == "OPEN_DOCUMENT") Intent.ACTION_OPEN_DOCUMENT else Intent.ACTION_GET_CONTENT
        val intent = Intent(action).apply {
            type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg","image/png","image/webp","image/gif","multipart/related","message/rfc822","application/octet-stream"))
            addCategory(Intent.CATEGORY_OPENABLE)
            if (item.packageName != null && item.activityName != null) component = ComponentName(item.packageName, item.activityName)
            else if (item.packageName != null) setPackage(item.packageName)
        }
        val launcher = if (item.actionType == "OPEN_DOCUMENT") openDocLauncher else getContentLauncher
        runCatching { launcher.launch(intent) }.onFailure {
            runCatching { launcher.launch(Intent(action).apply { type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addCategory(Intent.CATEGORY_OPENABLE); if (item.packageName != null) setPackage(item.packageName) }) }
                .onFailure { getContentLauncher.launch(Intent.createChooser(Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addCategory(Intent.CATEGORY_OPENABLE) }, getString(R.string.picker_open_files))) }
        }
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount).map { data.clipData!!.getItemAt(it).uri }
            data?.data != null     -> listOf(data.data!!)
            else                   -> emptyList()
        }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    // ── File processing ────────────────────────────────────────────────────────
    private fun processFiles(uris: List<Uri>) {
        processingJob?.cancel()
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility     = View.GONE
        b.actionBar.visibility    = View.GONE

        processingJob = lifecycleScope.launch {
            val looseImages  = mutableListOf<ImageItem>()
            var duplicateCount = 0

            uris.forEachIndexed { i, uri ->
                withContext(Dispatchers.Main) {
                    b.progressStatus.text  = getString(R.string.reading_file, i + 1, uris.size)
                    b.progressBar.progress = (i * 100) / uris.size
                }
                val uriStr = uri.toString()
                if (!AppState.seenUris.add(uriStr)) { duplicateCount++; return@forEachIndexed }
                val name  = getFileName(uri).lowercase()
                val data: ByteArray? = withContext(Dispatchers.IO) { runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull() }
                if (data == null) return@forEachIndexed
                when {
                    name.endsWith(".mhtml") || name.endsWith(".mht") -> {
                        val group = withContext(Dispatchers.IO) { MhtmlParser.parse(data, getFileName(uri)) }
                        if (group != null) AppState.groups.add(group)
                    }
                    name.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)")) -> {
                        looseImages.add(ImageItem(looseImages.size, data, name.substringAfterLast('.'), data.size))
                    }
                }
            }

            if (looseImages.isNotEmpty()) {
                val n = AppState.groups.size + 1
                val label = when {
                    AppState.currentMode == AppMode.MERGE -> "Merge Group $n (${looseImages.size} images)"
                    uris.size == 1 -> getFileName(uris[0]).substringBeforeLast('.').ifBlank { "Images $n" }
                    else -> "Images $n (${looseImages.size})"
                }
                AppState.groups.add(ImageGroup(label).also { it.allImages.addAll(looseImages) })
            }

            AppState.applyFilters()
            b.progressArea.visibility = View.GONE
            refreshChapterList()

            if (duplicateCount > 0) {
                Snackbar.make(b.root, getString(R.string.toast_duplicate_skipped, duplicateCount), Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(0xFF21262D.toInt()).setTextColor(0xFFF0F6FC.toInt()).show()
            }
        }
    }

    private fun getFileName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"

    // ── Save ───────────────────────────────────────────────────────────────────
    private fun startSave(asCbz: Boolean) {
        if (AppState.groups.isEmpty()) return
        checkWritePermission { showSaveDialog(asCbz) }
    }

    private fun showSaveDialog(asCbz: Boolean) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val default = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Manga_Batch"
        val title   = if (isMerge) "Name your image folder" else if (asCbz) "Save as CBZ" else "Name your folder"
        val input   = EditText(this).apply { setText(default); setSelection(0, default.length); hint = "Name"; setPadding(48,24,48,8) }
        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton(getString(R.string.btn_save)) { _, _ ->
                val raw = input.text.toString().trim().replace(Regex("""[\\/:*?"<>|]"""), "_").ifBlank { default }
                when {
                    isMerge -> performSaveMergeImages(raw)
                    asCbz   -> performSaveCbz(if (raw.endsWith(".cbz", true)) raw else "$raw.cbz")
                    else    -> performSaveFolder(raw)
                }
            }
            .setNegativeButton(getString(R.string.btn_cancel), null).show()
    }

    private fun performSaveFolder(folderName: String) = doSave {
        ImageSaver.saveExtractAsFolder(this, AppState.groups, folderName) { p ->
            lifecycleScope.launch(Dispatchers.Main) { b.progressStatus.text = p.message; b.progressBar.progress = p.percent }
        }
    }

    private fun performSaveCbz(filename: String) = doSave {
        val uri = CbzCreator.create(this, AppState.groups, filename, false) { p ->
            lifecycleScope.launch(Dispatchers.Main) { b.progressStatus.text = p.message; b.progressBar.progress = p.percent }
        }
        ImageSaver.SaveResult(listOf(uri), filename)
    }

    private fun performSaveMergeImages(folderName: String) = doSave {
        ImageSaver.saveMergeAsImages(this, AppState.groups, folderName) { p ->
            lifecycleScope.launch(Dispatchers.Main) { b.progressStatus.text = p.message; b.progressBar.progress = p.percent }
        }
    }

    private fun doSave(block: suspend () -> ImageSaver.SaveResult) {
        b.btnDownload.isEnabled = false; b.btnSaveCbz.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { block() }
                .onSuccess { result ->
                    withContext(Dispatchers.Main) {
                        b.progressArea.visibility = View.GONE
                        b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                        showSavedSheet("Saved!", "${result.uris.size} files · ${result.folderName}", result.uris, saveFirst = true)
                    }
                }
                .onFailure { e ->
                    withContext(Dispatchers.Main) {
                        b.progressArea.visibility = View.GONE
                        b.btnDownload.isEnabled = true; b.btnSaveCbz.isEnabled = true
                        Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                    }
                }
        }
    }

    // ── Share all (no save) ────────────────────────────────────────────────────
    private fun startShareAll() {
        if (AppState.groups.isEmpty()) return
        b.btnShareDirect.isEnabled = false
        b.progressArea.visibility  = View.VISIBLE
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(this@MainActivity, AppState.groups, AppState.currentMode == AppMode.MERGE) { p ->
                    lifecycleScope.launch(Dispatchers.Main) { b.progressStatus.text = p.message; b.progressBar.progress = p.percent }
                }
            }.onSuccess { uris ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    showSavedSheet("Share All", "${uris.size} images ready", uris, saveFirst = false)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE; b.btnShareDirect.isEnabled = true
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Share sheet ────────────────────────────────────────────────────────────
    private fun showSavedSheet(title: String, subtitle: String, shareUris: List<Uri>, saveFirst: Boolean) {
        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet = BottomSheetSavedBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)

        sheet.tvSavedTitle.text    = title
        sheet.tvSavedFilename.text = subtitle

        val fbPkg = "com.facebook.katana"
        val waPkg = "com.whatsapp"
        sheet.btnShareFacebook.alpha = if (isAppInstalled(fbPkg)) 1f else 0.35f
        sheet.btnShareWhatsapp.alpha = if (isAppInstalled(waPkg)) 1f else 0.35f

        sheet.btnShareFacebook.setOnClickListener { dialog.dismiss(); launchShare(shareUris, fbPkg) }
        sheet.btnShareWhatsapp.setOnClickListener { dialog.dismiss(); launchShare(shareUris, waPkg) }

        // Open in reader — only when a single CBZ was saved
        sheet.btnOpenReader.visibility = if (saveFirst && shareUris.size == 1) View.VISIBLE else View.GONE
        sheet.btnOpenReader.setOnClickListener {
            dialog.dismiss()
            runCatching { startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(shareUris[0], "application/x-cbz"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
                .onFailure { Toast.makeText(this, "No CBZ reader installed", Toast.LENGTH_SHORT).show() }
        }

        sheet.btnShare.setOnClickListener { dialog.dismiss(); launchShare(shareUris) }
        sheet.btnDone.setOnClickListener  { dialog.dismiss() }
        dialog.setOnDismissListener {
            // Clean up temp share files whenever the sheet closes
            ImageSaver.clearShareCache(this)
        }
        dialog.show()
    }

    private fun launchShare(uris: List<Uri>, targetPackage: String? = null) {
        if (uris.isEmpty()) return
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply { type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, uris[0]); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply { type = "image/jpeg"; putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        if (targetPackage != null) {
            intent.setPackage(targetPackage)
            runCatching { startActivity(intent) }.onFailure { startActivity(Intent.createChooser(intent.apply { `package` = null }, "Share via…")) }
        } else {
            startActivity(Intent.createChooser(intent, "Share images via…"))
        }
    }

    private fun isAppInstalled(pkg: String) = runCatching { packageManager.getApplicationInfo(pkg, 0); true }.getOrDefault(false)
    private fun checkWritePermission(onGranted: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else onGranted()
    }
    private fun openAllPhotos() { if (AppState.groups.isNotEmpty()) startActivity(Intent(this, AllPhotosActivity::class.java)) }
}
