# ☁️ Cloud File Manager — Android App

A full-featured **Google Drive file manager** app for Android. Both phones share the same files via the signed-in Google account.

---

## ✅ Features

| Feature | Details |
|---|---|
| 📁 Browse | Navigate folders just like a file manager |
| ⬆️ Upload | Upload any file from your phone to Drive |
| ⬇️ Download | Download & open any Drive file |
| 📁 New Folder | Create folders anywhere |
| 📄 New Text File | Create & edit `.txt` files with built-in editor |
| 📋 Copy | Copy files within Drive (no re-upload) |
| ✂️ Move | Move files between folders (instant, no re-upload) |
| 🗜️ Compress | Select files → zip them → upload as `.zip` |
| 📦 Extract | Long-press a `.zip` → extract files to current folder |
| 🗑️ Delete | Delete files/folders from Drive |
| ✏️ Rename | Rename any file or folder |
| 🔄 Multi-select | Long-press to select multiple items for bulk ops |
| 🔃 Pull to refresh | Swipe down to refresh file list |

---

## 🚀 Setup (Required — Do This First)

### 1. Google Cloud Console

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project (or use existing)
3. Go to **APIs & Services → Library**
4. Search and **Enable** `Google Drive API`

### 2. Create OAuth Credentials

1. Go to **APIs & Services → Credentials**
2. Click **+ CREATE CREDENTIALS → OAuth 2.0 Client ID**
3. Application type: **Android**
4. Package name: `com.cloudfilemanager`
5. SHA-1 fingerprint of your **debug keystore**:
   ```bash
   keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
   ```
6. Click **Create**

### 3. OAuth Consent Screen

1. Go to **APIs & Services → OAuth consent screen**
2. Choose **External**
3. Fill in App name, support email
4. Add scope: `https://www.googleapis.com/auth/drive`
5. Add your Gmail as a **test user**

### 4. Build the App

Push this zip to your GitHub repo — the `build.yml` will auto-build the APK via GitHub Actions.

Or build locally:
```bash
./gradlew assembleDebug
```

---

## 📱 Both Phones — Same Files

Any phone that signs in with the **same Google account** will see the **same Drive files**. Files are always synced through Google Drive — nothing stored locally.

---

## 📂 Project Structure

```
app/src/main/java/com/cloudfilemanager/
├── App.kt                  Application class
├── SignInActivity.kt       Google Sign-In screen
├── MainActivity.kt         File manager UI + all operations
├── DriveServiceHelper.kt   All Google Drive API calls
├── FileAdapter.kt          RecyclerView adapter
├── FileItem.kt             File data model
└── ZipHelper.kt            Compress / Extract logic
```

---

## 🔧 Troubleshooting

| Problem | Fix |
|---|---|
| Sign-in fails (code 10) | SHA-1 fingerprint not registered in Cloud Console |
| Sign-in fails (code 12500) | OAuth consent screen not configured |
| "Access blocked" | Add your Google account as a test user |
| Files not showing | Check Drive API is enabled in Cloud Console |

---

## 📦 Package Info

- **Package:** `com.cloudfilemanager`
- **Min SDK:** 26 (Android 8.0)
- **Target SDK:** 34 (Android 14)
