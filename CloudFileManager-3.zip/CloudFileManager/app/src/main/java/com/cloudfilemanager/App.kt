package com.cloudfilemanager

import androidx.multidex.MultiDexApplication

class App : MultiDexApplication()
