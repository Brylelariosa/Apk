package com.cloudfilemanager

import android.content.Context
import android.net.Uri
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.ByteArrayContent
import com.google.api.client.http.InputStreamContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class DriveServiceHelper(private val context: Context) {

    private var driveService: Drive? = null

    fun initWithAccount(account: GoogleSignInAccount) {
        val credential = GoogleAccountCredential.usingOAuth2(
            context, listOf(DriveScopes.DRIVE)
        )
        credential.selectedAccount = account.account
        driveService = Drive.Builder(
            NetHttpTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("CloudFileManager").build()
    }

    private fun drive() = driveService ?: throw IllegalStateException("Drive not initialized")

    // ──────────────── LIST ────────────────
    suspend fun listFiles(folderId: String = "root"): List<FileItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<FileItem>()
        var pageToken: String? = null
        do {
            val resp = drive().files().list()
                .setQ("'$folderId' in parents and trashed = false")
                .setSpaces("drive")
                .setFields("nextPageToken, files(id, name, mimeType, size, modifiedTime, parents)")
                .setOrderBy("folder,name")
                .setPageToken(pageToken)
                .execute()
            resp.files?.forEach { f ->
                result.add(
                    FileItem(
                        id = f.id ?: "",
                        name = f.name ?: "",
                        mimeType = f.mimeType ?: "",
                        size = f.getSize() ?: 0L,
                        modifiedTime = f.modifiedTime?.toString()?.take(10) ?: "",
                        parentId = folderId
                    )
                )
            }
            pageToken = resp.nextPageToken
        } while (pageToken != null)
        result
    }

    // ──────────────── CREATE FOLDER ────────────────
    suspend fun createFolder(name: String, parentId: String): FileItem = withContext(Dispatchers.IO) {
        val meta = DriveFile().apply {
            this.name = name
            mimeType = FileItem.FOLDER_MIME_TYPE
            parents = listOf(parentId)
        }
        val created = drive().files().create(meta).setFields("id, name, mimeType").execute()
        FileItem(id = created.id, name = created.name, mimeType = created.mimeType, parentId = parentId)
    }

    // ──────────────── CREATE TEXT FILE ────────────────
    suspend fun createTextFile(name: String, content: String, parentId: String): FileItem = withContext(Dispatchers.IO) {
        val safeName = if (name.endsWith(".txt")) name else "$name.txt"
        val meta = DriveFile().apply {
            this.name = safeName
            mimeType = "text/plain"
            parents = listOf(parentId)
        }
        val bytes = content.toByteArray(Charsets.UTF_8)
        val mediaContent = ByteArrayContent("text/plain", bytes)
        val created = drive().files().create(meta, mediaContent)
            .setFields("id, name, mimeType, size").execute()
        FileItem(
            id = created.id,
            name = created.name,
            mimeType = created.mimeType,
            size = created.getSize() ?: bytes.size.toLong(),
            parentId = parentId
        )
    }

    // ──────────────── READ TEXT FILE ────────────────
    suspend fun readTextFile(fileId: String): String = withContext(Dispatchers.IO) {
        val out = ByteArrayOutputStream()
        drive().files().get(fileId).executeMediaAndDownloadTo(out)
        out.toString(Charsets.UTF_8.name())
    }

    // ──────────────── UPDATE TEXT FILE ────────────────
    suspend fun updateTextFile(fileId: String, content: String): Unit = withContext(Dispatchers.IO) {
        val bytes = content.toByteArray(Charsets.UTF_8)
        val mediaContent = ByteArrayContent("text/plain", bytes)
        drive().files().update(fileId, null, mediaContent).execute()
    }

    // ──────────────── UPLOAD FILE ────────────────
    suspend fun uploadFile(name: String, uri: Uri, parentId: String, onProgress: (Int) -> Unit = {}): FileItem = withContext(Dispatchers.IO) {
        val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"
        val meta = DriveFile().apply {
            this.name = name
            parents = listOf(parentId)
        }
        val inputStream = context.contentResolver.openInputStream(uri)!!
        val mediaContent = InputStreamContent(mimeType, inputStream)
        val req = drive().files().create(meta, mediaContent)
            .setFields("id, name, mimeType, size")
        req.mediaHttpUploader?.also { uploader ->
            uploader.isDirectUploadEnabled = total < 5 * 1024 * 1024
            uploader.setProgressListener { onProgress((it.progress * 100).toInt()) }
        }
        val created = req.execute()
        FileItem(
            id = created.id,
            name = created.name,
            mimeType = created.mimeType,
            size = created.getSize() ?: 0L,
            parentId = parentId
        )
    }

    // ──────────────── DOWNLOAD FILE ────────────────
    suspend fun downloadFile(item: FileItem, onProgress: (Int) -> Unit = {}): File = withContext(Dispatchers.IO) {
        val dir = context.cacheDir
        val outFile = File(dir, item.name)
        val req = drive().files().get(item.id)
        val totalSize = item.size.takeIf { it > 0 } ?: 1L
        var downloaded = 0L
        FileOutputStream(outFile).use { fos ->
            req.executeMediaAndDownloadTo(fos)
        }
        onProgress(100)
        outFile
    }

    // ──────────────── DELETE ────────────────
    suspend fun deleteFile(fileId: String): Unit = withContext(Dispatchers.IO) {
        drive().files().delete(fileId).execute()
    }

    // ──────────────── RENAME ────────────────
    suspend fun renameFile(fileId: String, newName: String): Unit = withContext(Dispatchers.IO) {
        val meta = DriveFile().apply { name = newName }
        drive().files().update(fileId, meta).execute()
    }

    // ──────────────── MOVE ────────────────
    suspend fun moveFile(fileId: String, currentParentId: String, newParentId: String): Unit = withContext(Dispatchers.IO) {
        drive().files().update(fileId, null)
            .setAddParents(newParentId)
            .setRemoveParents(currentParentId)
            .setFields("id, parents")
            .execute()
    }

    // ──────────────── COPY ────────────────
    suspend fun copyFile(fileId: String, name: String, parentId: String): FileItem = withContext(Dispatchers.IO) {
        val meta = DriveFile().apply {
            this.name = "Copy of $name"
            parents = listOf(parentId)
        }
        val copied = drive().files().copy(fileId, meta).setFields("id, name, mimeType, size").execute()
        FileItem(
            id = copied.id,
            name = copied.name,
            mimeType = copied.mimeType,
            size = copied.getSize() ?: 0L,
            parentId = parentId
        )
    }

    // ──────────────── COMPRESS (download → zip → upload) ────────────────
    suspend fun compressFiles(items: List<FileItem>, zipName: String, parentId: String, onStatus: (String) -> Unit = {}): FileItem = withContext(Dispatchers.IO) {
        val cacheDir = context.cacheDir
        val zipFile = File(cacheDir, zipName)
        val downloadedFiles = mutableListOf<File>()

        items.forEach { item ->
            if (!item.isFolder) {
                onStatus("Downloading ${item.name}…")
                val local = downloadFile(item)
                downloadedFiles.add(local)
            }
        }

        onStatus("Compressing…")
        ZipHelper.zipFiles(downloadedFiles, zipFile)

        onStatus("Uploading $zipName…")
        val uri = Uri.fromFile(zipFile)
        val meta = DriveFile().apply {
            this.name = zipName
            mimeType = "application/zip"
            parents = listOf(parentId)
        }
        val inputStream = zipFile.inputStream()
        val mediaContent = InputStreamContent("application/zip", inputStream)
        val created = drive().files().create(meta, mediaContent)
            .setFields("id, name, mimeType, size").execute()

        // Cleanup
        downloadedFiles.forEach { it.delete() }
        zipFile.delete()

        FileItem(
            id = created.id,
            name = created.name,
            mimeType = created.mimeType,
            size = created.getSize() ?: 0L,
            parentId = parentId
        )
    }

    // ──────────────── EXTRACT (download zip → extract → upload files) ────────────────
    suspend fun extractZip(item: FileItem, parentId: String, onStatus: (String) -> Unit = {}): List<FileItem> = withContext(Dispatchers.IO) {
        onStatus("Downloading ${item.name}…")
        val zipFile = downloadFile(item)
        val extractDir = File(context.cacheDir, "extracted_${System.currentTimeMillis()}")

        onStatus("Extracting…")
        ZipHelper.unzipFile(zipFile, extractDir)

        val uploaded = mutableListOf<FileItem>()
        val allFiles = extractDir.walkTopDown().filter { it.isFile }.toList()
        allFiles.forEach { f ->
            onStatus("Uploading ${f.name}…")
            val meta = DriveFile().apply {
                name = f.name
                parents = listOf(parentId)
            }
            val mime = "application/octet-stream"
            val mediaContent = InputStreamContent(mime, f.inputStream())
            val created = drive().files().create(meta, mediaContent)
                .setFields("id, name, mimeType, size").execute()
            uploaded.add(FileItem(
                id = created.id,
                name = created.name,
                mimeType = created.mimeType,
                size = created.getSize() ?: 0L,
                parentId = parentId
            ))
        }

        // Cleanup
        zipFile.delete()
        extractDir.deleteRecursively()
        uploaded
    }

    // ──────────────── GET FILE INFO ────────────────
    suspend fun getFileName(folderId: String): String = withContext(Dispatchers.IO) {
        if (folderId == "root") return@withContext "My Drive"
        drive().files().get(folderId).setFields("name").execute().name ?: folderId
    }
}
