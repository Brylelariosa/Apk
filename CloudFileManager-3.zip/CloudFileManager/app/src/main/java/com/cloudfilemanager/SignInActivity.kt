package com.cloudfilemanager

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.google.api.services.drive.DriveScopes

class SignInActivity : AppCompatActivity() {

    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var progressBar: ProgressBar
    private lateinit var signInButton: SignInButton

    companion object {
        private const val RC_SIGN_IN = 9001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in)

        progressBar = findViewById(R.id.progressBar)
        signInButton = findViewById(R.id.signInButton)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE))
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Auto-sign in if already authenticated
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if (account != null && account.grantedScopes.any { it.scopeUri == DriveScopes.DRIVE }) {
            navigateToMain(account)
            return
        }

        signInButton.setSize(SignInButton.SIZE_WIDE)
        signInButton.setOnClickListener {
            progressBar.visibility = View.VISIBLE
            signInButton.isEnabled = false
            startActivityForResult(googleSignInClient.signInIntent, RC_SIGN_IN)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                navigateToMain(account)
            } catch (e: ApiException) {
                progressBar.visibility = View.GONE
                signInButton.isEnabled = true
                Toast.makeText(this, "Sign-in failed (code ${e.statusCode})\nCheck README for setup.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun navigateToMain(account: GoogleSignInAccount) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}
