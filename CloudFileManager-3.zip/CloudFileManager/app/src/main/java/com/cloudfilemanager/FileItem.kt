package com.cloudfilemanager

data class FileItem(
    val id: String,
    val name: String,
    val mimeType: String,
    val size: Long = 0L,
    val modifiedTime: String = "",
    val parentId: String = "root"
) {
    val isFolder: Boolean get() = mimeType == FOLDER_MIME_TYPE
    val isZip: Boolean get() = mimeType == "application/zip" || name.endsWith(".zip", true)

    val displaySize: String get() {
        if (isFolder) return ""
        return when {
            size < 1024 -> "$size B"
            size < 1024 * 1024 -> "${size / 1024} KB"
            size < 1024 * 1024 * 1024 -> "${size / (1024 * 1024)} MB"
            else -> "${size / (1024 * 1024 * 1024)} GB"
        }
    }

    companion object {
        const val FOLDER_MIME_TYPE = "application/vnd.google-apps.folder"
    }
}
