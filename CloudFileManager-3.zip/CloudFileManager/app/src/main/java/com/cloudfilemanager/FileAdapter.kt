package com.cloudfilemanager

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class FileAdapter(
    private val onItemClick: (FileItem) -> Unit,
    private val onItemLongClick: (FileItem, View) -> Unit,
    private val onSelectionChanged: (Int) -> Unit
) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    private val items = mutableListOf<FileItem>()
    private val selected = mutableSetOf<String>()
    var selectionMode = false
        private set

    fun setItems(newItems: List<FileItem>) {
        items.clear()
        items.addAll(newItems)
        selected.clear()
        selectionMode = false
        notifyDataSetChanged()
    }

    fun getSelectedItems(): List<FileItem> = items.filter { it.id in selected }

    fun clearSelection() {
        selected.clear()
        selectionMode = false
        notifyDataSetChanged()
        onSelectionChanged(0)
    }

    inner class FileViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: MaterialCardView = view.findViewById(R.id.cardView)
        val icon: ImageView = view.findViewById(R.id.fileIcon)
        val name: TextView = view.findViewById(R.id.fileName)
        val detail: TextView = view.findViewById(R.id.fileDetail)
        val checkbox: CheckBox = view.findViewById(R.id.checkbox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return FileViewHolder(v)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val item = items[position]
        val isSelected = item.id in selected

        holder.name.text = item.name
        holder.detail.text = buildString {
            if (item.displaySize.isNotEmpty()) append(item.displaySize)
            if (item.modifiedTime.isNotEmpty()) {
                if (isNotEmpty()) append("  •  ")
                append(item.modifiedTime)
            }
        }

        // Icon based on type
        holder.icon.setImageResource(getIconRes(item))

        // Selection mode UI
        if (selectionMode) {
            holder.checkbox.visibility = View.VISIBLE
            holder.checkbox.isChecked = isSelected
            holder.card.setCardBackgroundColor(
                if (isSelected) Color.parseColor("#E8F0FE") else Color.WHITE
            )
        } else {
            holder.checkbox.visibility = View.GONE
            holder.card.setCardBackgroundColor(Color.WHITE)
        }

        holder.itemView.setOnClickListener {
            if (selectionMode) {
                toggleSelection(item)
            } else {
                onItemClick(item)
            }
        }

        holder.itemView.setOnLongClickListener {
            if (!selectionMode) {
                selectionMode = true
                toggleSelection(item)
            } else {
                onItemLongClick(item, holder.itemView)
            }
            true
        }
    }

    private fun toggleSelection(item: FileItem) {
        if (item.id in selected) selected.remove(item.id)
        else selected.add(item.id)
        notifyItemChanged(items.indexOf(item))
        onSelectionChanged(selected.size)
        if (selected.isEmpty()) {
            selectionMode = false
            notifyDataSetChanged()
        }
    }

    private fun getIconRes(item: FileItem): Int = when {
        item.isFolder -> R.drawable.ic_folder
        item.mimeType.startsWith("image/") -> R.drawable.ic_image
        item.mimeType.startsWith("video/") -> R.drawable.ic_video
        item.mimeType.startsWith("audio/") -> R.drawable.ic_audio
        item.mimeType == "application/pdf" -> R.drawable.ic_pdf
        item.mimeType == "text/plain" -> R.drawable.ic_text
        item.isZip -> R.drawable.ic_zip
        item.mimeType.contains("word") || item.name.endsWith(".docx") || item.name.endsWith(".doc") -> R.drawable.ic_doc
        item.mimeType.contains("sheet") || item.name.endsWith(".xlsx") || item.name.endsWith(".xls") -> R.drawable.ic_sheet
        else -> R.drawable.ic_file
    }

    override fun getItemCount() = items.size
}
