package com.cloudfilemanager

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FileAdapter
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var emptyView: TextView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var fab: FloatingActionButton
    private lateinit var selectionBar: LinearLayout
    private lateinit var selectionCount: TextView
    private lateinit var driveHelper: DriveServiceHelper

    // Folder navigation back stack: Pair(folderId, folderName)
    private val folderStack = ArrayDeque<Pair<String, String>>()
    private val currentFolderId get() = folderStack.lastOrNull()?.first ?: "root"
    private val currentFolderName get() = folderStack.lastOrNull()?.second ?: "My Drive"

    // Clipboard for copy/move
    private var clipboard: Pair<FileItem, Boolean>? = null // item, isCut

    private val pickFileLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { handleUpload(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupDrive()
        setupViews()
        loadFiles()
    }

    private fun setupDrive() {
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if (account == null) {
            startActivity(Intent(this, SignInActivity::class.java))
            finish()
            return
        }
        driveHelper = DriveServiceHelper(this)
        driveHelper.initWithAccount(account)
    }

    private fun setupViews() {
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "My Drive"

        recyclerView = findViewById(R.id.recyclerView)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        emptyView = findViewById(R.id.emptyView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        fab = findViewById(R.id.fab)
        selectionBar = findViewById(R.id.selectionBar)
        selectionCount = findViewById(R.id.selectionCount)

        adapter = FileAdapter(
            onItemClick = { item -> handleItemClick(item) },
            onItemLongClick = { item, view -> showContextMenu(item, view) },
            onSelectionChanged = { count -> updateSelectionBar(count) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        swipeRefresh.setOnRefreshListener { loadFiles() }
        fab.setOnClickListener { showFabMenu() }

        // Selection bar buttons
        findViewById<ImageButton>(R.id.btnDelete).setOnClickListener { deleteSelected() }
        findViewById<ImageButton>(R.id.btnCopy).setOnClickListener { copySelected() }
        findViewById<ImageButton>(R.id.btnCut).setOnClickListener { cutSelected() }
        findViewById<ImageButton>(R.id.btnCompress).setOnClickListener { compressSelected() }
        findViewById<ImageButton>(R.id.btnCloseSelection).setOnClickListener { adapter.clearSelection() }
    }

    // ──────────────── LOAD FILES ────────────────
    private fun loadFiles() {
        showLoading(true)
        lifecycleScope.launch {
            runCatching {
                driveHelper.listFiles(currentFolderId)
            }.onSuccess { files ->
                swipeRefresh.isRefreshing = false
                showLoading(false)
                adapter.setItems(files)
                emptyView.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
                supportActionBar?.title = currentFolderName
                supportActionBar?.setDisplayHomeAsUpEnabled(folderStack.size > 1)
            }.onFailure { e ->
                swipeRefresh.isRefreshing = false
                showLoading(false)
                showError("Failed to load: ${e.message}")
            }
        }
    }

    // ──────────────── NAVIGATION ────────────────
    private fun handleItemClick(item: FileItem) {
        if (item.isFolder) {
            folderStack.addLast(item.id to item.name)
            loadFiles()
        } else if (item.mimeType == "text/plain") {
            openTextEditor(item)
        } else {
            confirmDownload(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        if (folderStack.size > 1) {
            folderStack.removeLast()
            loadFiles()
            return true
        }
        return super.onSupportNavigateUp()
    }

    override fun onBackPressed() {
        if (adapter.selectionMode) {
            adapter.clearSelection()
        } else if (folderStack.size > 1) {
            folderStack.removeLast()
            loadFiles()
        } else {
            super.onBackPressed()
        }
    }

    // ──────────────── FAB MENU ────────────────
    private fun showFabMenu() {
        val options = mutableListOf("📁  New Folder", "📄  New Text File", "⬆️  Upload File")
        if (clipboard != null) {
            val label = if (clipboard!!.second) "✂️  Paste (Move)" else "📋  Paste (Copy)"
            options.add(label)
        }
        AlertDialog.Builder(this)
            .setTitle("Create / Upload")
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> showCreateFolderDialog()
                    1 -> showCreateTextFileDialog()
                    2 -> pickFileLauncher.launch("*/*")
                    3 -> pasteItem()
                }
            }.show()
    }

    // ──────────────── CREATE FOLDER ────────────────
    private fun showCreateFolderDialog() {
        showInputDialog("New Folder", "Folder name", "") { name ->
            if (name.isBlank()) return@showInputDialog
            lifecycleScope.launch {
                showStatus("Creating folder…")
                runCatching { driveHelper.createFolder(name.trim(), currentFolderId) }
                    .onSuccess { loadFiles() }
                    .onFailure { showError("Failed: ${it.message}") }
                hideStatus()
            }
        }
    }

    // ──────────────── CREATE TEXT FILE ────────────────
    private fun showCreateTextFileDialog() {
        showInputDialog("New Text File", "File name (e.g. notes.txt)", "") { name ->
            if (name.isBlank()) return@showInputDialog
            showTextEditorDialog(null, name.trim(), "")
        }
    }

    private fun openTextEditor(item: FileItem) {
        showLoading(true)
        lifecycleScope.launch {
            runCatching { driveHelper.readTextFile(item.id) }
                .onSuccess { content ->
                    showLoading(false)
                    showTextEditorDialog(item, item.name, content)
                }
                .onFailure {
                    showLoading(false)
                    showError("Cannot open file")
                }
        }
    }

    private fun showTextEditorDialog(item: FileItem?, name: String, initialContent: String) {
        val layout = layoutInflater.inflate(R.layout.dialog_text_editor, null)
        val titleView = layout.findViewById<TextView>(R.id.editorTitle)
        val editText = layout.findViewById<EditText>(R.id.editorContent)
        titleView.text = name
        editText.setText(initialContent)
        editText.requestFocus()

        AlertDialog.Builder(this)
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val content = editText.text.toString()
                lifecycleScope.launch {
                    showStatus("Saving…")
                    runCatching {
                        if (item == null) {
                            driveHelper.createTextFile(name, content, currentFolderId)
                        } else {
                            driveHelper.updateTextFile(item.id, content)
                        }
                    }.onSuccess { loadFiles() }
                        .onFailure { showError("Save failed: ${it.message}") }
                    hideStatus()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ──────────────── UPLOAD ────────────────
    private fun handleUpload(uri: Uri) {
        val name = getFileName(uri) ?: "upload_${System.currentTimeMillis()}"
        lifecycleScope.launch {
            showStatus("Uploading $name…")
            runCatching { driveHelper.uploadFile(name, uri, currentFolderId) { p -> showStatus("Uploading $name… $p%") } }
                .onSuccess {
                    hideStatus()
                    loadFiles()
                    snack("Uploaded: $name")
                }
                .onFailure {
                    hideStatus()
                    showError("Upload failed: ${it.message}")
                }
        }
    }

    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        if (result == null) result = uri.lastPathSegment
        return result
    }

    // ──────────────── DOWNLOAD ────────────────
    private fun confirmDownload(item: FileItem) {
        AlertDialog.Builder(this)
            .setTitle("Download")
            .setMessage("Download \"${item.name}\" (${item.displaySize})?")
            .setPositiveButton("Download") { _, _ ->
                lifecycleScope.launch {
                    showStatus("Downloading ${item.name}…")
                    runCatching { driveHelper.downloadFile(item) { p -> showStatus("Downloading… $p%") } }
                        .onSuccess { file ->
                            hideStatus()
                            shareFile(item, file)
                        }
                        .onFailure {
                            hideStatus()
                            showError("Download failed: ${it.message}")
                        }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun shareFile(item: FileItem, file: java.io.File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, item.mimeType.ifEmpty { "*/*" })
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(intent, "Open with"))
        } catch (e: Exception) {
            snack("File saved to cache: ${file.absolutePath}")
        }
    }

    // ──────────────── CONTEXT MENU ────────────────
    private fun showContextMenu(item: FileItem, anchor: View) {
        val options = mutableListOf("✏️  Rename", "📋  Copy", "✂️  Move (Cut)", "🗑️  Delete")
        if (item.isZip) options.add("📦  Extract Here")
        if (!item.isFolder) options.add("⬇️  Download / Open")

        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options.toTypedArray()) { _, which ->
                val label = options[which]
                when {
                    label.contains("Rename") -> showRenameDialog(item)
                    label.contains("Copy") -> { clipboard = item to false; snack("\"${item.name}\" copied. Tap FAB → Paste.") }
                    label.contains("Move") -> { clipboard = item to true; snack("\"${item.name}\" cut. Tap FAB → Paste.") }
                    label.contains("Delete") -> confirmDelete(listOf(item))
                    label.contains("Extract") -> extractItem(item)
                    label.contains("Download") -> confirmDownload(item)
                }
            }.show()
    }

    // ──────────────── RENAME ────────────────
    private fun showRenameDialog(item: FileItem) {
        showInputDialog("Rename", "New name", item.name) { newName ->
            if (newName.isBlank()) return@showInputDialog
            lifecycleScope.launch {
                showStatus("Renaming…")
                runCatching { driveHelper.renameFile(item.id, newName.trim()) }
                    .onSuccess { loadFiles() }
                    .onFailure { showError("Rename failed: ${it.message}") }
                hideStatus()
            }
        }
    }

    // ──────────────── DELETE ────────────────
    private fun confirmDelete(items: List<FileItem>) {
        val msg = if (items.size == 1) "Delete \"${items[0].name}\"?" else "Delete ${items.size} items?"
        AlertDialog.Builder(this)
            .setTitle("Delete")
            .setMessage(msg)
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    items.forEach { item ->
                        showStatus("Deleting ${item.name}…")
                        runCatching { driveHelper.deleteFile(item.id) }
                            .onFailure { showError("Failed to delete ${item.name}: ${it.message}") }
                    }
                    hideStatus()
                    adapter.clearSelection()
                    loadFiles()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ──────────────── COPY / CUT ────────────────
    private fun copySelected() {
        val items = adapter.getSelectedItems()
        if (items.isEmpty()) return
        if (items.size == 1) {
            clipboard = items[0] to false
            snack("\"${items[0].name}\" copied. Tap FAB → Paste.")
        } else {
            snack("Select one item at a time for copy")
        }
        adapter.clearSelection()
    }

    private fun cutSelected() {
        val items = adapter.getSelectedItems()
        if (items.isEmpty()) return
        if (items.size == 1) {
            clipboard = items[0] to true
            snack("\"${items[0].name}\" cut. Tap FAB → Paste.")
        } else {
            snack("Select one item at a time for move")
        }
        adapter.clearSelection()
    }

    private fun pasteItem() {
        val (item, isCut) = clipboard ?: return
        lifecycleScope.launch {
            showStatus(if (isCut) "Moving ${item.name}…" else "Copying ${item.name}…")
            runCatching {
                if (isCut) {
                    driveHelper.moveFile(item.id, item.parentId, currentFolderId)
                } else {
                    driveHelper.copyFile(item.id, item.name, currentFolderId)
                }
            }.onSuccess {
                clipboard = null
                hideStatus()
                loadFiles()
                snack(if (isCut) "Moved!" else "Copied!")
            }.onFailure {
                hideStatus()
                showError("Paste failed: ${it.message}")
            }
        }
    }

    // ──────────────── COMPRESS ────────────────
    private fun compressSelected() {
        val items = adapter.getSelectedItems().filter { !it.isFolder }
        if (items.isEmpty()) {
            snack("Select files to compress (folders not supported)")
            return
        }
        showInputDialog("Compress", "ZIP file name", "archive.zip") { name ->
            val zipName = if (name.endsWith(".zip")) name else "$name.zip"
            adapter.clearSelection()
            lifecycleScope.launch {
                runCatching {
                    driveHelper.compressFiles(items, zipName, currentFolderId) { status -> showStatus(status) }
                }.onSuccess {
                    hideStatus()
                    loadFiles()
                    snack("Compressed: $zipName")
                }.onFailure {
                    hideStatus()
                    showError("Compress failed: ${it.message}")
                }
            }
        }
    }

    // ──────────────── EXTRACT ────────────────
    private fun extractItem(item: FileItem) {
        AlertDialog.Builder(this)
            .setTitle("Extract")
            .setMessage("Extract \"${item.name}\" to current folder?")
            .setPositiveButton("Extract") { _, _ ->
                lifecycleScope.launch {
                    runCatching {
                        driveHelper.extractZip(item, currentFolderId) { status -> showStatus(status) }
                    }.onSuccess {
                        hideStatus()
                        loadFiles()
                        snack("Extracted ${it.size} file(s)")
                    }.onFailure {
                        hideStatus()
                        showError("Extract failed: ${it.message}")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ──────────────── SELECTION BAR ────────────────
    private fun updateSelectionBar(count: Int) {
        if (count > 0) {
            selectionBar.visibility = View.VISIBLE
            selectionCount.text = "$count selected"
            fab.hide()
        } else {
            selectionBar.visibility = View.GONE
            fab.show()
        }
    }

    private fun deleteSelected() {
        val items = adapter.getSelectedItems()
        if (items.isNotEmpty()) confirmDelete(items)
    }

    // ──────────────── TOOLBAR MENU ────────────────
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_sign_out -> {
                signOut()
                true
            }
            R.id.action_refresh -> {
                loadFiles()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun signOut() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
        val client = com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(this, gso)
        client.signOut().addOnCompleteListener {
            startActivity(Intent(this, SignInActivity::class.java))
            finish()
        }
    }

    // ──────────────── HELPERS ────────────────
    private fun showInputDialog(title: String, hint: String, prefill: String, onConfirm: (String) -> Unit) {
        val editText = EditText(this).apply {
            this.hint = hint
            setText(prefill)
            setPadding(48, 24, 48, 8)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(editText)
            .setPositiveButton("OK") { _, _ -> onConfirm(editText.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
        editText.postDelayed({
            editText.requestFocus()
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            imm.showSoftInput(editText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }, 100)
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        if (show) emptyView.visibility = View.GONE
    }

    private fun showStatus(msg: String) {
        runOnUiThread {
            statusText.text = msg
            statusText.visibility = View.VISIBLE
        }
    }

    private fun hideStatus() {
        runOnUiThread { statusText.visibility = View.GONE }
    }

    private fun showError(msg: String) {
        runOnUiThread { snack(msg) }
    }

    private fun snack(msg: String) {
        Snackbar.make(recyclerView, msg, Snackbar.LENGTH_LONG).show()
    }
}
