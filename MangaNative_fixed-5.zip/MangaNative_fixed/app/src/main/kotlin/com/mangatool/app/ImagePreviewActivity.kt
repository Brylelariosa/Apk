package com.mangatool.app

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.viewpager2.widget.ViewPager2
import com.mangatool.app.adapter.PreviewPagerAdapter
import com.mangatool.app.databinding.ActivityImagePreviewBinding
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImagePreviewActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GROUP_IDX   = "group_idx"
        const val EXTRA_IMAGE_IDX   = "image_idx"
        const val EXTRA_IS_MERGE    = "is_merge"
        const val EXTRA_IS_FILTERED = "is_filtered"
    }

    private lateinit var b: ActivityImagePreviewBinding
    private var groupIdx   = 0
    private var isMerge    = false
    private var isFiltered = false
    private var pagerAdapter: PreviewPagerAdapter? = null

    // Tracks originalIdx parallel to pager items so we know which image to delete/restore
    private val originalIdxList = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityImagePreviewBinding.inflate(layoutInflater)
        setContentView(b.root)

        groupIdx   = intent.getIntExtra(EXTRA_GROUP_IDX, 0)
        isMerge    = intent.getBooleanExtra(EXTRA_IS_MERGE, false)
        isFiltered = intent.getBooleanExtra(EXTRA_IS_FILTERED, false)
        val startIdx = intent.getIntExtra(EXTRA_IMAGE_IDX, 0)

        val group = AppState.groups.getOrNull(groupIdx) ?: run { finish(); return }

        b.previewLoading.visibility = View.VISIBLE
        lifecycleScope.launch {
            val items: List<Any> = withContext(Dispatchers.IO) {
                when {
                    isFiltered -> {
                        originalIdxList.clear()
                        group.filteredImages.map { img ->
                            originalIdxList.add(img.originalIdx)
                            img.data
                        }
                    }
                    isMerge -> {
                        ImageMerger.pairImages(group.displayImages).map { pair ->
                            ImageMerger.merge(pair, AppState.rtlMode) ?: pair[0].data
                        }
                    }
                    else -> {
                        originalIdxList.clear()
                        group.displayImages.map { img ->
                            originalIdxList.add(img.originalIdx)
                            img.data
                        }
                    }
                }
            }

            b.previewLoading.visibility = View.GONE
            pagerAdapter = PreviewPagerAdapter(items)
            b.viewPager.adapter = pagerAdapter
            b.viewPager.setCurrentItem(startIdx.coerceAtMost((items.size - 1).coerceAtLeast(0)), false)
            updateCounter()
            updateActionBtn()

            b.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateCounter()
                    updateActionBtn()
                }
            })
        }

        b.closeBtn.setOnClickListener { setResult(RESULT_OK); finish() }
        b.prevBtn.setOnClickListener  { b.viewPager.currentItem -= 1 }
        b.nextBtn.setOnClickListener  { b.viewPager.currentItem += 1 }
        b.deleteBtn.setOnClickListener { handleAction() }
    }

    private fun handleAction() {
        val adapter = pagerAdapter ?: return
        val pos     = b.viewPager.currentItem
        val group   = AppState.groups.getOrNull(groupIdx) ?: return

        if (isFiltered) {
            // Restore the image
            val origIdx = originalIdxList.getOrNull(pos) ?: return
            val orig    = group.allImages.find { it.originalIdx == origIdx } ?: return
            orig.forceKeep   = true
            orig.userDeleted = false
            AppState.applyFilters()
            originalIdxList.removeAt(pos)
            adapter.removeAt(pos)
            setResult(RESULT_OK)

            if (adapter.itemCount == 0) {
                Toast.makeText(this, "All images restored ✓", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                b.viewPager.setCurrentItem(pos.coerceAtMost(adapter.itemCount - 1), false)
                updateCounter()
                Toast.makeText(this, "Restored ✓", Toast.LENGTH_SHORT).show()
            }
        } else if (!isMerge) {
            // Delete the image
            val origIdx = originalIdxList.getOrNull(pos) ?: return
            val orig    = group.allImages.find { it.originalIdx == origIdx } ?: return
            orig.userDeleted = true
            orig.forceKeep   = false
            AppState.applyFilters()
            originalIdxList.removeAt(pos)
            adapter.removeAt(pos)
            setResult(RESULT_OK)

            if (adapter.itemCount == 0) {
                Toast.makeText(this, "No more images", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                b.viewPager.setCurrentItem(pos.coerceAtMost(adapter.itemCount - 1), false)
                updateCounter()
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateCounter() {
        val adapter = pagerAdapter ?: return
        b.previewCounter.text = "${b.viewPager.currentItem + 1} / ${adapter.itemCount}"
    }

    private fun updateActionBtn() {
        when {
            isMerge    -> b.deleteBtn.visibility = View.GONE
            isFiltered -> {
                b.deleteBtn.visibility = View.VISIBLE
                b.deleteBtn.text = "↩  Restore Image"
                b.deleteBtn.backgroundTintList =
                    android.content.res.ColorStateList.valueOf(0xFF16A34A.toInt())
            }
            else -> {
                b.deleteBtn.visibility = View.VISIBLE
                b.deleteBtn.text = "🗑  Delete Image"
                b.deleteBtn.backgroundTintList =
                    android.content.res.ColorStateList.valueOf(0xFFEF4444.toInt())
            }
        }
    }

    override fun onDestroy() {
        pagerAdapter?.destroy()
        super.onDestroy()
    }
}
