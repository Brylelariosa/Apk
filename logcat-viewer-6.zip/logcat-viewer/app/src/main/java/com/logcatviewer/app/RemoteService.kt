package com.logcatviewer.app

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * Shizuku UserService — runs in a privileged shell process.
 * Shizuku spawns this as a separate process with shell (uid=2000) privileges,
 * so Runtime.exec() commands here have the permissions needed to call pm grant.
 */
class RemoteService : IRemoteService.Stub() {

    override fun grantReadLogs(packageName: String): Int {
        return try {
            val process = Runtime.getRuntime().exec(
                arrayOf("pm", "grant", packageName, "android.permission.READ_LOGS")
            )
            process.waitFor()
        } catch (e: Exception) {
            -1
        }
    }
}
