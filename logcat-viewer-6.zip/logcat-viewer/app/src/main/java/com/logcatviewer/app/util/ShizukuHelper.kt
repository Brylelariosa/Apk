package com.logcatviewer.app.util

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import com.logcatviewer.app.IRemoteService
import com.logcatviewer.app.RemoteService
import rikka.shizuku.Shizuku

private const val TAG = "ShizukuHelper"
private const val SHIZUKU_CODE = 1001

object ShizukuHelper {

    val isAvailable: Boolean
        get() = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    val hasShizukuPermission: Boolean
        get() = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

    fun requestShizukuPermission() {
        if (!isAvailable || Shizuku.isPreV11()) return
        Shizuku.requestPermission(SHIZUKU_CODE)
    }

    /**
     * Binds a Shizuku UserService (runs as shell uid) and calls pm grant.
     * [callback] is invoked with true on success, false on failure.
     */
    fun grantReadLogsPermission(packageName: String, callback: (Boolean) -> Unit) {
        if (!isAvailable || !hasShizukuPermission) {
            callback(false)
            return
        }

        val serviceArgs = Shizuku.UserServiceArgs(
            ComponentName(packageName, RemoteService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("remote_service")
            .debuggable(false)
            .version(1)

        val connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                try {
                    val service = IRemoteService.Stub.asInterface(binder)
                    val exitCode = service.grantReadLogs(packageName)
                    Log.d(TAG, "grantReadLogs exit code: $exitCode")
                    callback(exitCode == 0)
                } catch (e: Exception) {
                    Log.e(TAG, "grantReadLogs failed", e)
                    callback(false)
                } finally {
                    runCatching { Shizuku.unbindUserService(serviceArgs, this, true) }
                }
            }

            override fun onServiceDisconnected(name: ComponentName) {
                Log.w(TAG, "UserService disconnected unexpectedly")
                callback(false)
            }
        }

        try {
            Shizuku.bindUserService(serviceArgs, connection)
        } catch (e: Exception) {
            Log.e(TAG, "bindUserService failed", e)
            callback(false)
        }
    }

    fun hasReadLogsPermission(packageName: String, pm: PackageManager): Boolean =
        pm.checkPermission("android.permission.READ_LOGS", packageName) ==
                PackageManager.PERMISSION_GRANTED

    fun addBinderReceivedListener(l: Shizuku.OnBinderReceivedListener) =
        Shizuku.addBinderReceivedListenerSticky(l)

    fun removeBinderReceivedListener(l: Shizuku.OnBinderReceivedListener) =
        Shizuku.removeBinderReceivedListener(l)

    fun addBinderDeadListener(l: Shizuku.OnBinderDeadListener) =
        Shizuku.addBinderDeadListener(l)

    fun removeBinderDeadListener(l: Shizuku.OnBinderDeadListener) =
        Shizuku.removeBinderDeadListener(l)

    fun addPermissionResultListener(l: Shizuku.OnRequestPermissionResultListener) =
        Shizuku.addRequestPermissionResultListener(l)

    fun removePermissionResultListener(l: Shizuku.OnRequestPermissionResultListener) =
        Shizuku.removeRequestPermissionResultListener(l)
}
