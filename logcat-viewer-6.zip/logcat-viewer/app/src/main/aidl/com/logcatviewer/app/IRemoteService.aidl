package com.logcatviewer.app;

interface IRemoteService {
    /** Runs: pm grant <packageName> android.permission.READ_LOGS
     *  Returns 0 on success, non-zero on failure. */
    int grantReadLogs(String packageName);
}
