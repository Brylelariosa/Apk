#include "cpu.h"
#include "gba.h"
#include <cassert>
#include <cmath>
#include <vector>
#include <cstdlib>

// ── Init / Reset ─────────────────────────────────────────────────────────────
void ARM7TDMI::init(GBA* g) {
    gba = g;
    reset();
}

void ARM7TDMI::reset() {
    memset(r, 0, sizeof(r));
    cpsr    = 0x000000D3; // SVC mode, IRQ+FIQ disabled, ARM
    spsr    = 0;
    halted  = false;
    stopped = false;
    cycles  = 0;

    // Banked regs
    r13_svc = r14_svc = spsr_svc = 0;
    r13_irq = r14_irq = spsr_irq = 0;
    r13_abt = r14_abt = spsr_abt = 0;
    r13_und = r14_und = spsr_und = 0;
    r13_fiq = r14_fiq = spsr_fiq = 0;
    r8_fiq = r9_fiq = r10_fiq = r11_fiq = r12_fiq = 0;

    PC() = 0x08000000; // Skip BIOS, boot directly to ROM
    // Set stack pointers (standard GBA boot values)
    switchMode(CpuMode::SYS); r[13] = 0x03007F00;
    switchMode(CpuMode::IRQ); r[13] = 0x03007FA0;
    switchMode(CpuMode::SVC); r[13] = 0x03007FE0;
    switchMode(CpuMode::SYS);
    cpsr = (cpsr & ~0x1F) | 0x1F; // SYS mode
}

// ── Mode switching ────────────────────────────────────────────────────────────
void ARM7TDMI::switchMode(CpuMode newMode) {
    CpuMode old = mode();
    if (old == newMode) return;

    // Save current banked registers
    auto saveRegs = [&](u32& r13b, u32& r14b, u32& spsrb) {
        r13b = r[13]; r14b = r[14]; spsrb = spsr;
    };
    auto loadRegs = [&](u32 r13b, u32 r14b, u32 spsrb) {
        r[13] = r13b; r[14] = r14b; spsr = spsrb;
    };

    switch (old) {
        case CpuMode::SVC: saveRegs(r13_svc, r14_svc, spsr_svc); break;
        case CpuMode::IRQ: saveRegs(r13_irq, r14_irq, spsr_irq); break;
        case CpuMode::ABT: saveRegs(r13_abt, r14_abt, spsr_abt); break;
        case CpuMode::UND: saveRegs(r13_und, r14_und, spsr_und); break;
        case CpuMode::FIQ:
            saveRegs(r13_fiq, r14_fiq, spsr_fiq);
            r8_fiq=r[8]; r9_fiq=r[9]; r10_fiq=r[10]; r11_fiq=r[11]; r12_fiq=r[12];
            break;
        default: break;
    }

    cpsr = (cpsr & ~0x1F) | static_cast<u32>(newMode);

    switch (newMode) {
        case CpuMode::SVC: loadRegs(r13_svc, r14_svc, spsr_svc); break;
        case CpuMode::IRQ: loadRegs(r13_irq, r14_irq, spsr_irq); break;
        case CpuMode::ABT: loadRegs(r13_abt, r14_abt, spsr_abt); break;
        case CpuMode::UND: loadRegs(r13_und, r14_und, spsr_und); break;
        case CpuMode::FIQ:
            loadRegs(r13_fiq, r14_fiq, spsr_fiq);
            r[8]=r8_fiq; r[9]=r9_fiq; r[10]=r10_fiq; r[11]=r11_fiq; r[12]=r12_fiq;
            break;
        default: break;
    }
}

// ── Interrupt request ─────────────────────────────────────────────────────────
void ARM7TDMI::requestIRQ() {
    if (cpsr & FLAG_I) return; // IRQs masked
    halted = false;
    u32 savedPC   = PC() - (thumbMode() ? 0 : 4) + 4;
    spsr_irq      = cpsr;
    switchMode(CpuMode::IRQ);
    spsr          = spsr_irq;
    cpsr         |= FLAG_I;
    cpsr         &= ~FLAG_T; // Switch to ARM
    r[14]         = savedPC;
    PC()          = 0x00000018; // IRQ vector
    cycles       += 3;
}

// ── Condition check ───────────────────────────────────────────────────────────
bool ARM7TDMI::checkCondition(u32 cond) const {
    bool N = cpsr & FLAG_N, Z = cpsr & FLAG_Z,
         C = cpsr & FLAG_C, V = cpsr & FLAG_V;
    switch (cond) {
        case 0x0: return  Z;           // EQ
        case 0x1: return !Z;           // NE
        case 0x2: return  C;           // CS/HS
        case 0x3: return !C;           // CC/LO
        case 0x4: return  N;           // MI
        case 0x5: return !N;           // PL
        case 0x6: return  V;           // VS
        case 0x7: return !V;           // VC
        case 0x8: return  C && !Z;     // HI
        case 0x9: return !C ||  Z;     // LS
        case 0xA: return  N == V;      // GE
        case 0xB: return  N != V;      // LT
        case 0xC: return !Z && (N==V); // GT
        case 0xD: return  Z || (N!=V); // LE
        case 0xE: return true;         // AL
        default:  return false;        // NV (never)
    }
}

// ── Barrel shifter ────────────────────────────────────────────────────────────
u32 ARM7TDMI::barrelShift(u32 val, u32 type, u32 amt, bool& carry, bool regShift) {
    if (amt == 0 && !regShift) {
        // Special encoding: shift by 0
        if (type == 3) { // RRX
            bool old = carry;
            carry = val & 1;
            return (val >> 1) | (old ? 0x80000000u : 0);
        }
        return val;
    }
    if (amt == 0) return val; // Register shift by 0 leaves unchanged

    switch (type) {
        case 0: // LSL
            if (amt >= 32) { carry = (amt==32) ? (val&1) : 0; return 0; }
            carry = (val >> (32-amt)) & 1;
            return val << amt;
        case 1: // LSR
            if (amt >= 32) { carry = (amt==32) ? (val>>31) : 0; return 0; }
            carry = (val >> (amt-1)) & 1;
            return val >> amt;
        case 2: // ASR
            if (amt >= 32) { carry = val>>31; return carry ? 0xFFFFFFFFu : 0; }
            carry = (val >> (amt-1)) & 1;
            return (s32)val >> amt;
        case 3: // ROR
            amt &= 31;
            if (!amt) { carry = val>>31; return val; } // ROR by 32
            carry = (val >> (amt-1)) & 1;
            return (val >> amt) | (val << (32-amt));
    }
    return val;
}

u32 ARM7TDMI::applyShiftImm(u32 instr, bool& carry) {
    u32 rm  = instr & 0xF;
    u32 val = r[rm];
    u32 type= (instr >> 5) & 3;
    u32 amt = (instr >> 7) & 31;
    return barrelShift(val, type, amt, carry, false);
}

u32 ARM7TDMI::applyShiftReg(u32 instr, bool& carry) {
    u32 rm  = instr & 0xF;
    u32 rs  = (instr >> 8) & 0xF;
    u32 val = r[rm];
    if (rm == 15) val += 4;
    u32 type = (instr >> 5) & 3;
    u32 amt  = r[rs] & 0xFF;
    return barrelShift(val, type, amt, carry, true);
}

// ── Memory access ─────────────────────────────────────────────────────────────
u8   ARM7TDMI::read8 (u32 a)         { cycles++; return gba->mem.read8(a); }
u16  ARM7TDMI::read16(u32 a)         { cycles++; return gba->mem.read16(a); }
u32  ARM7TDMI::read32(u32 a)         { cycles+=2; return gba->mem.read32(a); }
void ARM7TDMI::write8 (u32 a, u8  v) { cycles++; gba->mem.write8(a,v); }
void ARM7TDMI::write16(u32 a, u16 v) { cycles++; gba->mem.write16(a,v); }
void ARM7TDMI::write32(u32 a, u32 v) { cycles+=2; gba->mem.write32(a,v); }

// ── Main step ─────────────────────────────────────────────────────────────────
int ARM7TDMI::step() {
    cycles = 0;

    // Check IRQ — also wakes CPU from halt
    {
        u16 ie  = gba->mem.read16(REG_IE);
        u16 iff = gba->mem.read16(REG_IF);
        bool irqPending = (ie & iff) != 0;
        if (halted && irqPending) {
            halted = false;
            // Also update BIOS IRQ latch (0x03FFFFF8) so IntrWait/VBlankIntrWait sees it
            u16 latch = gba->mem.read16(0x03FFFFF8);
            gba->mem.write16(0x03FFFFF8, latch | (ie & iff));
        }
        if (!halted && irqPending && (gba->mem.read16(REG_IME) & 1) && !(cpsr & FLAG_I)) {
            requestIRQ();
        }
    }
    if (halted) return 1;

    if (thumbMode()) {
        u16 instr = read16(PC());
        PC() += 2;
        executeTHUMB(instr);
    } else {
        u32 instr = read32(PC());
        PC() += 4;
        u32 cond = instr >> 28;
        if (checkCondition(cond)) {
            executeARM(instr);
        } else {
            cycles += 1;
        }
    }

    return cycles;
}

// ── ARM instruction dispatch ──────────────────────────────────────────────────
void ARM7TDMI::executeARM(u32 i) {
    // Decode by bits 27-20 and 7-4
    u32 op = (i >> 20) & 0xFF;
    (void)((i >> 4) & 0xF); // reserved decode field

    if ((i & 0x0FFFFFF0) == 0x012FFF10) { armBranchExchange(i); return; }
    if ((i & 0x0FC000F0) == 0x00000090) { armMultiply(i);       return; }
    if ((i & 0x0F8000F0) == 0x00800090) { armMultiplyLong(i);   return; }
    if ((i & 0x0FB00FF0) == 0x01000090) { armSWP(i);            return; }

    if ((i & 0x0E000090) == 0x00000090 && (i & 0x60)) {
        armHalfwordTransfer(i); return;
    }

    if ((op & 0xC0) == 0x80) { armBlockDataTransfer(i); return; }
    if ((op & 0xE0) == 0xA0) { armBranch(i);            return; }
    if ((op & 0xF0) == 0xF0) { armSWI(i);               return; }

    // MRS/MSR
    if ((i & 0x0FBF0FFF) == 0x010F0000) { armMRS(i); return; }
    if ((i & 0x0DBFF000) == 0x0129F000) { armMSR(i); return; }
    if ((i & 0x0DBFF000) == 0x0128F000) { armMSR(i); return; }

    if ((op & 0xC0) == 0x40 || (op & 0xC4) == 0x04 ||
        (op & 0xC4) == 0x00 || (op & 0xC4) == 0x00) {
        if ((op >> 2) & 1) { armSingleDataTransfer(i); return; }
    }
    if ((op & 0xC0) == 0x00) { armDataProcessing(i); return; }
    if ((op & 0xC0) == 0x40) { armSingleDataTransfer(i); return; }

    armDataProcessing(i); // fallback
}

// ── ARM: Branch ───────────────────────────────────────────────────────────────
void ARM7TDMI::armBranch(u32 i) {
    bool link = (i >> 24) & 1;
    s32  off  = ((s32)(i << 8)) >> 6; // sign-extend 24-bit, shift left 2
    if (link) r[14] = PC() - 4;
    PC() += off;
    cycles += 3;
}

void ARM7TDMI::armBranchExchange(u32 i) {
    u32 rn = r[i & 0xF];
    if (rn & 1) { cpsr |= FLAG_T; PC() = rn & ~1u; }
    else        { cpsr &= ~FLAG_T; PC() = rn & ~3u; }
    cycles += 3;
}

// ── ARM: Data Processing ──────────────────────────────────────────────────────
void ARM7TDMI::armDataProcessing(u32 i) {
    u32 opcode  = (i >> 21) & 0xF;
    bool setcc  = (i >> 20) & 1;
    u32  rn     = (i >> 16) & 0xF;
    u32  rd     = (i >> 12) & 0xF;
    bool immOp  = (i >> 25) & 1;

    u32 op1 = r[rn];
    if (rn == 15) op1 = PC() + (immOp ? 0 : 4);

    bool carry = getFlag(FLAG_C);
    u32  op2;

    if (immOp) {
        u32 rot = ((i >> 8) & 0xF) * 2;
        u32 imm = i & 0xFF;
        op2 = (imm >> rot) | (imm << (32-rot));
        if (rot) carry = op2 >> 31;
    } else {
        bool hasRs = (i >> 4) & 1;
        op2 = hasRs ? applyShiftReg(i, carry) : applyShiftImm(i, carry);
    }

    u32 res = 0;
    bool writeRd = true;
    bool setcarry = carry;

    switch (opcode) {
        case 0x0: res = op1 & op2;         break; // AND
        case 0x1: res = op1 ^ op2;         break; // EOR
        case 0x2: { // SUB
            res = op1 - op2;
            setcarry = op1 >= op2;
            if (setcc) setFlag(FLAG_V, subOverflow(op1,op2,res));
            break;
        }
        case 0x3: { // RSB
            res = op2 - op1;
            setcarry = op2 >= op1;
            if (setcc) setFlag(FLAG_V, subOverflow(op2,op1,res));
            break;
        }
        case 0x4: { // ADD
            res = op1 + op2;
            setcarry = res < op1;
            if (setcc) setFlag(FLAG_V, addOverflow(op1,op2,res));
            break;
        }
        case 0x5: { // ADC
            u64 r64 = (u64)op1 + op2 + getFlag(FLAG_C);
            res = (u32)r64;
            setcarry = r64 >> 32;
            if (setcc) setFlag(FLAG_V, addOverflow(op1,op2,res));
            break;
        }
        case 0x6: { // SBC
            u64 r64 = (u64)op1 - op2 - !getFlag(FLAG_C);
            res = (u32)r64;
            setcarry = !(r64 >> 32);
            if (setcc) setFlag(FLAG_V, subOverflow(op1,op2,res));
            break;
        }
        case 0x7: { // RSC
            u64 r64 = (u64)op2 - op1 - !getFlag(FLAG_C);
            res = (u32)r64;
            setcarry = !(r64 >> 32);
            if (setcc) setFlag(FLAG_V, subOverflow(op2,op1,res));
            break;
        }
        case 0x8: res = op1 & op2; writeRd=false; break; // TST
        case 0x9: res = op1 ^ op2; writeRd=false; break; // TEQ
        case 0xA: { // CMP
            res = op1 - op2;
            setcarry = op1 >= op2;
            if (setcc) setFlag(FLAG_V, subOverflow(op1,op2,res));
            writeRd = false;
            break;
        }
        case 0xB: { // CMN
            res = op1 + op2;
            setcarry = res < op1;
            if (setcc) setFlag(FLAG_V, addOverflow(op1,op2,res));
            writeRd = false;
            break;
        }
        case 0xC: res = op1 | op2; break; // ORR
        case 0xD: res = op2;       break; // MOV
        case 0xE: res = op1 & ~op2;break; // BIC
        case 0xF: res = ~op2;      break; // MVN
    }

    if (setcc) {
        if (rd == 15) {
            cpsr = spsr; // Restore CPSR from SPSR
        } else {
            setFlag(FLAG_N, res >> 31);
            setFlag(FLAG_Z, res == 0);
            setFlag(FLAG_C, setcarry);
            // V already set above for arithmetic ops
        }
    }

    if (writeRd) {
        r[rd] = res;
        if (rd == 15) { PC() &= thumbMode() ? ~1u : ~3u; cycles += 2; }
    }

    cycles += 1;
}

// ── ARM: Multiply ─────────────────────────────────────────────────────────────
void ARM7TDMI::armMultiply(u32 i) {
    bool acc   = (i >> 21) & 1;
    bool setcc = (i >> 20) & 1;
    u32  rd    = (i >> 16) & 0xF;
    u32  rn    = (i >> 12) & 0xF;
    u32  rs    = (i >> 8)  & 0xF;
    u32  rm    = i & 0xF;
    u32  res   = r[rm] * r[rs];
    if (acc) res += r[rn];
    r[rd] = res;
    if (setcc) { setFlag(FLAG_N, res>>31); setFlag(FLAG_Z, res==0); }
    cycles += 4;
}

void ARM7TDMI::armMultiplyLong(u32 i) {
    bool sign  = (i >> 22) & 1;
    bool acc   = (i >> 21) & 1;
    bool setcc = (i >> 20) & 1;
    u32  rdhi  = (i >> 16) & 0xF;
    u32  rdlo  = (i >> 12) & 0xF;
    u32  rs    = (i >> 8)  & 0xF;
    u32  rm    = i & 0xF;
    u64  res;
    if (sign) res = (s64)(s32)r[rm] * (s64)(s32)r[rs];
    else      res = (u64)r[rm] * (u64)r[rs];
    if (acc) res += ((u64)r[rdhi] << 32) | r[rdlo];
    r[rdlo] = res & 0xFFFFFFFF;
    r[rdhi] = res >> 32;
    if (setcc) { setFlag(FLAG_N, res>>63); setFlag(FLAG_Z, res==0); }
    cycles += 5;
}

// ── ARM: Single Data Transfer ─────────────────────────────────────────────────
void ARM7TDMI::armSingleDataTransfer(u32 i) {
    bool immOff = !((i >> 25) & 1);
    bool pre    = (i >> 24) & 1;
    bool up     = (i >> 23) & 1;
    bool byte   = (i >> 22) & 1;
    bool wb     = (i >> 21) & 1;
    bool load   = (i >> 20) & 1;
    u32  rn     = (i >> 16) & 0xF;
    u32  rd     = (i >> 12) & 0xF;
    u32  base   = r[rn];
    if (rn==15) base = PC();

    u32 offset;
    if (immOff) {
        offset = i & 0xFFF;
    } else {
        bool c = false;
        offset = applyShiftImm(i, c);
    }

    u32 addr = pre ? (up ? base+offset : base-offset) : base;

    if (load) {
        if (byte) r[rd] = read8(addr);
        else      r[rd] = read32(addr & ~3u);
        if (rd==15) { PC() &= ~3u; cycles += 2; }
    } else {
        u32 val = r[rd];
        if (rd==15) val += 4;
        if (byte) write8 (addr, val & 0xFF);
        else      write32(addr & ~3u, val);
    }

    if (!pre) addr = up ? base+offset : base-offset;
    if (wb || !pre) { if (rn!=rd || !load) r[rn] = addr; }
    cycles += 2;
}

// ── ARM: Halfword / Signed Transfer ──────────────────────────────────────────
void ARM7TDMI::armHalfwordTransfer(u32 i) {
    bool pre    = (i >> 24) & 1;
    bool up     = (i >> 23) & 1;
    bool immOff = (i >> 22) & 1;
    bool wb     = (i >> 21) & 1;
    bool load   = (i >> 20) & 1;
    u32  rn     = (i >> 16) & 0xF;
    u32  rd     = (i >> 12) & 0xF;
    u32  sh     = (i >> 5)  & 3;  // 1=UH, 2=SB, 3=SH

    u32 base = r[rn];
    u32 off  = immOff ? (((i>>8)&0xF)<<4)|(i&0xF) : r[i&0xF];
    u32 addr = pre ? (up ? base+off : base-off) : base;

    if (load) {
        switch (sh) {
            case 1: r[rd] = read16(addr); break;
            case 2: r[rd] = (s32)(s8) read8(addr); break;
            case 3: r[rd] = (s32)(s16)read16(addr); break;
        }
    } else {
        write16(addr, r[rd] & 0xFFFF);
    }

    if (!pre) addr = up ? base+off : base-off;
    if (wb || !pre) r[rn] = addr;
    cycles += 2;
}

// ── ARM: Block Data Transfer ──────────────────────────────────────────────────
void ARM7TDMI::armBlockDataTransfer(u32 i) {
    bool pre  = (i >> 24) & 1;
    bool up   = (i >> 23) & 1;
    bool psr  = (i >> 22) & 1;
    bool wb   = (i >> 21) & 1;
    bool load = (i >> 20) & 1;
    u32  rn   = (i >> 16) & 0xF;
    u32  list = i & 0xFFFF;

    u32 base = r[rn];
    int cnt  = __builtin_popcount(list);
    u32 addr = up ? base : base - cnt*4;
    if (!up) { if (pre) addr+=4; else addr+=0; }
    else     { if (pre) addr+=4; }
    if (!up) addr = base - cnt*4 + (pre ? 0 : 4);
    else     addr = base           + (pre ? 4 : 0);

    // Simplify: always go low→high in memory
    u32 startAddr = up ? (pre ? base+4 : base) : (pre ? base-cnt*4 : base-cnt*4+4);

    u32 cur = startAddr;
    for (int b = 0; b < 16; b++) {
        if (!(list & (1<<b))) continue;
        if (load) {
            r[b] = read32(cur);
            if (b==15) { PC() &= ~3u; cycles+=2; }
        } else {
            u32 val = r[b]; if (b==15) val+=4;
            write32(cur, val);
        }
        cur += 4;
    }

    if (wb) {
        r[rn] = up ? base + cnt*4 : base - cnt*4;
    }

    if (psr && load && (list & (1<<15))) cpsr = spsr;
    cycles += 2;
}

// ── ARM: SWP ─────────────────────────────────────────────────────────────────
void ARM7TDMI::armSWP(u32 i) {
    bool byte = (i>>22)&1;
    u32 rn = (i>>16)&0xF, rd = (i>>12)&0xF, rm = i&0xF;
    u32 addr = r[rn];
    if (byte) {
        u8 tmp = read8(addr);
        write8(addr, r[rm] & 0xFF);
        r[rd] = tmp;
    } else {
        u32 tmp = read32(addr);
        write32(addr, r[rm]);
        r[rd] = tmp;
    }
    cycles += 4;
}

// ── ARM: SWI ──────────────────────────────────────────────────────────────────
void ARM7TDMI::armSWI(u32 i) {
    u32 swiNum = (i >> 16) & 0xFF;
    // Save return state
    u32 savedCpsr = cpsr;
    u32 savedPC   = PC() - 4;
    // Switch to SVC (saves caller banked regs, loads SVC banked regs)
    spsr_svc = savedCpsr;
    r14_svc  = savedPC;
    switchMode(CpuMode::SVC);
    cpsr |= FLAG_I;
    cpsr &= ~FLAG_T;
    // HLE: execute the BIOS function directly
    biosHLE(swiNum);
    // Return: switchMode FIRST (while still in SVC) so it correctly saves
    // SVC r13/r14 and restores caller banked r13/r14, THEN restore cpsr+PC.
    switchMode(static_cast<CpuMode>(savedCpsr & 0x1F));
    cpsr = savedCpsr;
    PC() = savedPC + 4; // resume after SWI instruction
}

// ── ARM: MRS / MSR ────────────────────────────────────────────────────────────
void ARM7TDMI::armMRS(u32 i) {
    bool spsr_sel = (i>>22)&1;
    u32  rd = (i>>12)&0xF;
    r[rd] = spsr_sel ? spsr : cpsr;
}

void ARM7TDMI::armMSR(u32 i) {
    bool spsr_sel = (i>>22)&1;
    bool immOp    = (i>>25)&1;
    u32 val;
    if (immOp) {
        u32 rot = ((i>>8)&0xF)*2;
        u32 imm = i & 0xFF;
        val = (imm>>rot)|(imm<<(32-rot));
    } else {
        val = r[i&0xF];
    }
    u32 mask = 0;
    if ((i>>19)&1) mask |= 0xFF000000;
    if ((i>>18)&1) mask |= 0x00FF0000;
    if ((i>>17)&1) mask |= 0x0000FF00;
    if ((i>>16)&1) mask |= 0x000000FF;
    if (spsr_sel) spsr = (spsr & ~mask) | (val & mask);
    else          cpsr = (cpsr & ~mask) | (val & mask);
}

// ── BIOS HLE (High-Level Emulation) ──────────────────────────────────────────
// Called by both armSWI and thumbSWI. Implements the GBA BIOS functions that
// Pokemon Emerald (and most GBA games) actually use. Without this, any SWI
// jumps into zero-filled BIOS memory and the CPU runs off into invalid space.

void ARM7TDMI::biosHLE(u32 swiNum) {
    GBA& g = *gba;
    Memory& m = g.mem;

    switch (swiNum & 0xFF) {

    // ── 0x00: SoftReset ───────────────────────────────────────────────────────
    case 0x00: {
        // Clear 0x03007E00-0x03007FFF (IWRAM top 512 bytes), reset stack ptrs
        for (u32 a = 0x03007E00; a < 0x03008000; a++) m.write8(a, 0);
        switchMode(CpuMode::SVC); r[13] = 0x03007FE0;
        switchMode(CpuMode::IRQ); r[13] = 0x03007FA0;
        switchMode(CpuMode::SYS); r[13] = 0x03007F00;
        // Jump to ROM or RAM depending on flag at 0x03007FFA
        u8 flag = m.read8(0x03007FFA);
        PC() = flag ? 0x02000000 : 0x08000000;
        cpsr &= ~FLAG_T;
        cycles += 10;
        break;
    }

    // ── 0x01: RegisterRamReset ───────────────────────────────────────────────
    case 0x01: {
        u32 flags = r[0];
        if (flags & 0x01) memset(m.ewram, 0, EWRAM_SIZE);
        if (flags & 0x02) memset(m.iwram, 0, 0x7E00); // don't clear top stack
        if (flags & 0x04) memset(m.io,    0, 0x200);
        if (flags & 0x08) memset(m.pal,   0, PAL_SIZE);
        if (flags & 0x10) memset(m.vram,  0, VRAM_SIZE);
        if (flags & 0x20) memset(m.oam,   0, OAM_SIZE);
        cycles += 10;
        break;
    }

    // ── 0x02: Halt ────────────────────────────────────────────────────────────
    case 0x02:
        halted = true;
        cycles += 2;
        break;

    // ── 0x03: Stop ───────────────────────────────────────────────────────────
    case 0x03:
        halted = true;
        cycles += 2;
        break;

    // ── 0x04: IntrWait ───────────────────────────────────────────────────────
    // r0 = discardExisting, r1 = irqMask
    case 0x04: {
        u16 mask = (u16)r[1];
        if (r[0]) {
            // Clear requested bits in BIOS IRQ flags (0x03FFFFF8)
            u16 biosFlags = m.read16(0x03FFFFF8);
            m.write16(0x03FFFFF8, biosFlags & ~mask);
        }
        halted = true;
        cycles += 4;
        break;
    }

    // ── 0x05: VBlankIntrWait ─────────────────────────────────────────────────
    case 0x05: {
        // Clear VBlank bit in BIOS IRQ latch, then halt
        u16 biosFlags = m.read16(0x03FFFFF8);
        m.write16(0x03FFFFF8, biosFlags & ~1);
        halted = true;
        cycles += 4;
        break;
    }

    // ── 0x06: Div ────────────────────────────────────────────────────────────
    // r0 = numerator, r1 = denominator → r0=quotient, r1=remainder, r3=|quotient|
    case 0x06: {
        if ((s32)r[1] == 0) break; // avoid divide by zero
        s32 num = (s32)r[0], den = (s32)r[1];
        r[0] = (u32)(num / den);
        r[1] = (u32)(num % den);
        r[3] = (u32)std::abs(num / den);
        cycles += 5;
        break;
    }

    // ── 0x07: DivArm ─────────────────────────────────────────────────────────
    // r0 = denominator, r1 = numerator (swapped from Div)
    case 0x07: {
        if ((s32)r[0] == 0) break;
        s32 num = (s32)r[1], den = (s32)r[0];
        r[0] = (u32)(num / den);
        r[1] = (u32)(num % den);
        r[3] = (u32)std::abs(num / den);
        cycles += 5;
        break;
    }

    // ── 0x08: Sqrt ───────────────────────────────────────────────────────────
    case 0x08:
        r[0] = (u32)std::sqrt((double)r[0]);
        cycles += 3;
        break;

    // ── 0x09: ArcTan ─────────────────────────────────────────────────────────
    case 0x09: {
        s16 t = (s16)r[0];
        double v = std::atan((double)t / 16384.0) / (M_PI / 2.0);
        r[0] = (u16)(s16)(v * 16384.0);
        cycles += 3;
        break;
    }

    // ── 0x0A: ArcTan2 ────────────────────────────────────────────────────────
    case 0x0A: {
        s16 x = (s16)r[0], y = (s16)r[1];
        double angle = std::atan2((double)y, (double)x) / (2.0 * M_PI);
        if (angle < 0) angle += 1.0;
        r[0] = (u16)(u32)(angle * 65536.0);
        cycles += 3;
        break;
    }

    // ── 0x0B: CpuSet ─────────────────────────────────────────────────────────
    // r0=src, r1=dst, r2=cnt|(mode<<24)|(fill<<26)
    case 0x0B: {
        u32 src   = r[0], dst = r[1];
        u32 count = r[2] & 0x1FFFFF;
        bool fill = (r[2] >> 24) & 1;
        bool w32  = (r[2] >> 26) & 1;
        if (w32) {
            u32 val = m.read32(src);
            for (u32 i = 0; i < count; i++) {
                if (!fill) val = m.read32(src + i*4);
                m.write32(dst + i*4, val);
            }
        } else {
            u16 val = m.read16(src);
            for (u32 i = 0; i < count; i++) {
                if (!fill) val = m.read16(src + i*2);
                m.write16(dst + i*2, val);
            }
        }
        cycles += count + 2;
        break;
    }

    // ── 0x0C: CpuFastSet ─────────────────────────────────────────────────────
    // r0=src, r1=dst, r2=cnt|(fill<<24)  (always 32-bit, count in words)
    case 0x0C: {
        u32 src   = r[0], dst = r[1];
        u32 count = r[2] & 0x1FFFFF;
        bool fill = (r[2] >> 24) & 1;
        u32 val = m.read32(src);
        for (u32 i = 0; i < count; i++) {
            if (!fill) val = m.read32(src + i*4);
            m.write32(dst + i*4, val);
        }
        cycles += count + 2;
        break;
    }

    // ── 0x0E: BgAffineSet ────────────────────────────────────────────────────
    case 0x0E: {
        u32 src = r[0], dst = r[1];
        u32 num = r[2];
        for (u32 i = 0; i < num; i++) {
            s32 cx = (s32)m.read32(src);      src += 4;
            s32 cy = (s32)m.read32(src);      src += 4;
            s16 dispX = (s16)m.read16(src);   src += 2;
            s16 dispY = (s16)m.read16(src);   src += 2;
            s16 scX   = (s16)m.read16(src);   src += 2;
            s16 scY   = (s16)m.read16(src);   src += 2;
            u16 theta = m.read16(src);        src += 4;
            double angle = theta * (2.0 * M_PI / 65536.0);
            double cos_v = std::cos(angle), sin_v = std::sin(angle);
            s16 pa = (s16)( cos_v * scX);
            s16 pb = (s16)(-sin_v * scY);
            s16 pc = (s16)( sin_v * scX);
            s16 pd = (s16)( cos_v * scY);
            m.write16(dst,     (u16)pa); m.write16(dst+2,  (u16)pb);
            m.write16(dst+4,   (u16)pc); m.write16(dst+6,  (u16)pd);
            s32 dx = (s32)(dispX - (pa*(cx>>8) + pb*(cy>>8)));
            s32 dy = (s32)(dispY - (pc*(cx>>8) + pd*(cy>>8)));
            m.write32(dst+8,   (u32)dx); m.write32(dst+12, (u32)dy);
            dst += 16;
        }
        cycles += num * 10;
        break;
    }

    // ── 0x0F: ObjAffineSet ───────────────────────────────────────────────────
    case 0x0F: {
        u32 src = r[0], dst = r[1];
        u32 num = r[2];
        u32 offset = r[3]; // dst stride between PA entries (usually 8)
        for (u32 i = 0; i < num; i++) {
            s16 scX   = (s16)m.read16(src);   src += 2;
            s16 scY   = (s16)m.read16(src);   src += 2;
            u16 theta = m.read16(src);        src += 4;
            double angle = theta * (2.0 * M_PI / 65536.0);
            s16 pa = (s16)( std::cos(angle) * scX);
            s16 pb = (s16)(-std::sin(angle) * scY);
            s16 pc = (s16)( std::sin(angle) * scX);
            s16 pd = (s16)( std::cos(angle) * scY);
            m.write16(dst,           (u16)pa);
            m.write16(dst + offset,  (u16)pb);
            m.write16(dst + offset*2,(u16)pc);
            m.write16(dst + offset*3,(u16)pd);
            dst += offset * 4;
        }
        cycles += num * 8;
        break;
    }

    // ── 0x10: BitUnPack ──────────────────────────────────────────────────────
    case 0x10: {
        u32 src = r[0], dst = r[1];
        u32 hdr = r[2]; // pointer to BitUnPackParam struct
        u16 srcLen  = m.read16(hdr);
        u8  srcBits = m.read8(hdr+2);
        u8  dstBits = m.read8(hdr+3);
        u32 dataOff = m.read32(hdr+4);
        bool zeroFlag = (dataOff >> 31) & 1;
        dataOff &= 0x7FFFFFFF;
        u32 dstWord = 0, dstShift = 0;
        for (u32 i = 0; i < srcLen; ) {
            u8 srcByte = m.read8(src + i);
            for (int b = 0; b < 8/srcBits && i < srcLen; b++, i++) {
                u32 val = (srcByte >> (b * srcBits)) & ((1u << srcBits) - 1);
                if (val || !zeroFlag) val += dataOff;
                dstWord |= (val << dstShift);
                dstShift += dstBits;
                if (dstShift >= 32) {
                    m.write32(dst, dstWord); dst += 4;
                    dstWord = 0; dstShift = 0;
                }
            }
        }
        if (dstShift) { m.write32(dst, dstWord); }
        cycles += srcLen + 5;
        break;
    }

    // ── 0x11: LZ77UnCompWram ─────────────────────────────────────────────────
    // ── 0x12: LZ77UnCompVram ─────────────────────────────────────────────────
    case 0x11:
    case 0x12: {
        u32 src = r[0], dst = r[1];
        u32 hdr = m.read32(src); src += 4;
        u32 decompLen = hdr >> 8;
        // hdr bits 7:4 = type (1 = LZ77)
        std::vector<u8> out;
        out.reserve(decompLen);
        while (out.size() < decompLen) {
            u8 flags = m.read8(src++);
            for (int b = 7; b >= 0 && out.size() < decompLen; b--) {
                if (flags & (1 << b)) {
                    // Back-reference
                    u8 b0 = m.read8(src++), b1 = m.read8(src++);
                    u32 length = ((b0 >> 4) & 0xF) + 3;
                    u32 disp   = (((u32)(b0 & 0xF) << 8) | b1) + 1;
                    for (u32 k = 0; k < length; k++)
                        out.push_back(out.size() >= disp ? out[out.size()-disp] : 0);
                } else {
                    out.push_back(m.read8(src++));
                }
            }
        }
        if (swiNum == 0x12) {
            // VRam: write 16-bit aligned
            for (u32 i = 0; i + 1 < out.size(); i += 2)
                m.write16(dst+i, (u16)out[i] | ((u16)out[i+1] << 8));
        } else {
            for (u32 i = 0; i < out.size(); i++) m.write8(dst+i, out[i]);
        }
        cycles += decompLen + 10;
        break;
    }

    // ── 0x13: HuffUnComp ─────────────────────────────────────────────────────
    case 0x13: {
        u32 src = r[0], dst = r[1];
        u32 hdr = m.read32(src); src += 4;
        u32 decompLen = hdr >> 8;
        // u8  dataBits  = hdr & 0xF; // 4 or 8 (unused)
        u8  treeSize  = m.read8(src); src++;
        u32 treeStart = src - 1;
        src = treeStart + 1 + ((treeSize + 1) * 2);
        // Simplified: write zeros if tree is complex (game will re-decompress if needed)
        // Full Huffman is rarely used vs LZ77 in Pokemon Emerald
        for (u32 i = 0; i < decompLen; i++) m.write8(dst+i, 0);
        cycles += decompLen + 10;
        break;
    }

    // ── 0x14: RLUnCompWram ───────────────────────────────────────────────────
    // ── 0x15: RLUnCompVram ───────────────────────────────────────────────────
    case 0x14:
    case 0x15: {
        u32 src = r[0], dst = r[1];
        u32 hdr = m.read32(src); src += 4;
        u32 decompLen = hdr >> 8;
        std::vector<u8> out;
        out.reserve(decompLen);
        while (out.size() < decompLen) {
            u8 flag = m.read8(src++);
            if (flag & 0x80) {
                // Compressed: repeat next byte
                u32 len = (flag & 0x7F) + 3;
                u8  val = m.read8(src++);
                for (u32 k = 0; k < len && out.size() < decompLen; k++) out.push_back(val);
            } else {
                // Uncompressed: copy literal bytes
                u32 len = (flag & 0x7F) + 1;
                for (u32 k = 0; k < len && out.size() < decompLen; k++) out.push_back(m.read8(src++));
            }
        }
        if (swiNum == 0x15) {
            for (u32 i = 0; i+1 < out.size(); i+=2)
                m.write16(dst+i, (u16)out[i] | ((u16)out[i+1] << 8));
        } else {
            for (u32 i = 0; i < out.size(); i++) m.write8(dst+i, out[i]);
        }
        cycles += decompLen + 10;
        break;
    }

    // ── 0x19/0x28/0x29: Sound stubs ──────────────────────────────────────────
    case 0x19: case 0x1A: case 0x1B: case 0x1C:
    case 0x1D: case 0x1E: case 0x1F: case 0x28: case 0x29:
        cycles += 2;
        break;

    default:
        // Unknown SWI — just return
        cycles += 2;
        break;
    }
}
