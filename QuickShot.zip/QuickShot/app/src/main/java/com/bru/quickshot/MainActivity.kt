package com.bru.quickshot

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bru.quickshot.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnEnable.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        val enabled = isServiceEnabled()

        if (enabled) {
            binding.statusIcon.text = "✅"
            binding.statusTitle.text = "QuickShot is Active"
            binding.statusSubtitle.text =
                "Pull down the notification shade and tap the notification to take a screenshot anytime."
            binding.btnEnable.visibility = View.GONE
            binding.cardStatus.setCardBackgroundColor(getColor(R.color.status_active_bg))
        } else {
            binding.statusIcon.text = "⚠️"
            binding.statusTitle.text = "Service Not Enabled"
            binding.statusSubtitle.text =
                "Tap the button below, find \"QuickShot\" in the list, and turn it on."
            binding.btnEnable.visibility = View.VISIBLE
            binding.cardStatus.setCardBackgroundColor(getColor(R.color.status_inactive_bg))
        }
    }

    private fun isServiceEnabled(): Boolean {
        val component = ComponentName(this, ScreenshotService::class.java)
        val flat = component.flattenToString()

        val enabled = try {
            Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
        } catch (e: Exception) {
            return false
        } ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(flat, ignoreCase = true)) return true
        }
        return false
    }
}
