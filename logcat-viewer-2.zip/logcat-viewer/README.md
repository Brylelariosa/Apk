# Logcat Viewer

A modern Android logcat viewer built with Kotlin + Jetpack Compose, using **Shizuku** to grant `READ_LOGS` without a PC.

## Features
- 🔴 **Live logcat stream** with start/stop control
- 🔍 **Search** across tags and messages
- 📦 **Package / Tag filter** with active chip display
- 📜 **Auto-scroll** toggle
- 🗑️ **Clear logs** button
- 💾 **Export & share** logs as `.txt`
- 🌑 Dark IDE-style theme with color-coded log levels

## Setup

### Requirements
- Android 8.0+ (API 26)
- [Shizuku](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api) installed and running

### First Launch
1. Enable **Developer Options → Wireless Debugging** on your device
2. Open Shizuku → tap **Start via Wireless Debugging**
3. Open Logcat Viewer → tap **Step 1** to allow Shizuku API access
4. Tap **Step 2** to auto-grant `READ_LOGS`
5. Logs start streaming immediately ✅

## Building

```bash
./gradlew assembleDebug
```

APK output: `app/build/outputs/apk/debug/`

## GitHub Actions CI

### Debug builds
Triggered automatically on every push to `main`/`master`. APK uploaded as artifact.

### Release builds
Triggered on any `v*` tag push (e.g. `git tag v1.0.0 && git push --tags`).

Add these **Repository Secrets** in GitHub Settings → Secrets:

| Secret | Description |
|---|---|
| `KEYSTORE_BASE64` | Base64-encoded `.jks` keystore file |
| `KEYSTORE_PASSWORD` | Keystore password |
| `KEY_ALIAS` | Key alias |
| `KEY_PASSWORD` | Key password |

Generate a keystore:
```bash
keytool -genkeypair -v -keystore keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias mykey
# Encode it:
base64 -i keystore.jks | pbcopy   # macOS
base64 keystore.jks               # Linux → paste into KEYSTORE_BASE64 secret
```

## Architecture

```
app/
├── data/
│   ├── LogEntry.kt        # Data model + LogLevel enum
│   └── LogcatReader.kt    # Coroutine Flow logcat stream
├── util/
│   ├── ShizukuHelper.kt   # Shizuku permission + pm grant
│   └── LogExporter.kt     # Save & share log files
├── ui/
│   ├── theme/Theme.kt     # Dark Material3 theme
│   └── LogcatScreen.kt    # Full Compose UI
├── LogcatViewModel.kt     # StateFlow + filtering logic
└── MainActivity.kt        # Shizuku lifecycle listeners
```
