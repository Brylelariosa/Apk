package com.logcatviewer.app.data

import androidx.compose.ui.graphics.Color

data class LogEntry(
    val id: Long,
    val timestamp: String,
    val pid: String,
    val tid: String,
    val level: LogLevel,
    val tag: String,
    val message: String,
    val raw: String
)

enum class LogLevel(val char: Char, val color: Color) {
    VERBOSE('V', Color(0xFFAAAAAA)),
    DEBUG('D',   Color(0xFF6897BB)),
    INFO('I',    Color(0xFF6A8759)),
    WARNING('W', Color(0xFFBBB529)),
    ERROR('E',   Color(0xFFFF6B68)),
    FATAL('F',   Color(0xFFFF0000)),
    SILENT('S',  Color(0xFF888888));

    companion object {
        fun fromChar(c: Char): LogLevel =
            entries.firstOrNull { it.char == c.uppercaseChar() } ?: VERBOSE
    }
}
