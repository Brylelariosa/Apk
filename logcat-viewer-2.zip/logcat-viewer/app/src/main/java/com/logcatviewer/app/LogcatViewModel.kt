package com.logcatviewer.app

import android.app.Application
import android.content.pm.PackageManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.logcatviewer.app.data.LogEntry
import com.logcatviewer.app.data.LogLevel
import com.logcatviewer.app.data.LogcatReader
import com.logcatviewer.app.util.ShizukuHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LogcatUiState(
    val logs: List<LogEntry> = emptyList(),
    val filteredLogs: List<LogEntry> = emptyList(),
    val searchQuery: String = "",
    val packageFilter: String = "",
    val tagFilter: String = "",
    val autoScroll: Boolean = true,
    val isRunning: Boolean = false,
    val permissionState: PermissionState = PermissionState.UNKNOWN,
    val shizukuAvailable: Boolean = false,
)

enum class PermissionState { UNKNOWN, GRANTED, DENIED, REQUESTING }

class LogcatViewModel(app: Application) : AndroidViewModel(app) {

    private val reader = LogcatReader()
    private var readJob: Job? = null

    private val _uiState = MutableStateFlow(LogcatUiState())
    val uiState: StateFlow<LogcatUiState> = _uiState.asStateFlow()

    private val maxLogs = 5_000

    init {
        checkPermission()
    }

    fun checkPermission() {
        val ctx = getApplication<Application>()
        val hasPermission = ctx.checkSelfPermission("android.permission.READ_LOGS") ==
                PackageManager.PERMISSION_GRANTED
        val shizukuAvailable = ShizukuHelper.isAvailable
        _uiState.update {
            it.copy(
                permissionState = if (hasPermission) PermissionState.GRANTED else PermissionState.DENIED,
                shizukuAvailable = shizukuAvailable
            )
        }
        if (hasPermission && !_uiState.value.isRunning) startReading()
    }

    fun requestViaShizuku() {
        _uiState.update { it.copy(permissionState = PermissionState.REQUESTING) }
        viewModelScope.launch {
            val granted = ShizukuHelper.grantReadLogsPermission(
                getApplication<Application>().packageName
            )
            if (granted) {
                _uiState.update { it.copy(permissionState = PermissionState.GRANTED) }
                startReading()
            } else {
                _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            }
        }
    }

    fun requestShizukuApiPermission() {
        ShizukuHelper.requestShizukuPermission()
    }

    fun startReading() {
        if (readJob?.isActive == true) return
        readJob = viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true) }
            reader.readLogs()
                .catch { e ->
                    _uiState.update { it.copy(isRunning = false) }
                }
                .collect { entry ->
                    _uiState.update { state ->
                        val newLogs = (state.logs + entry).takeLast(maxLogs)
                        state.copy(
                            logs = newLogs,
                            filteredLogs = applyFilters(newLogs, state)
                        )
                    }
                }
        }
    }

    fun stopReading() {
        readJob?.cancel()
        _uiState.update { it.copy(isRunning = false) }
    }

    fun clearLogs() {
        _uiState.update { it.copy(logs = emptyList(), filteredLogs = emptyList()) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { state ->
            val updated = state.copy(searchQuery = query)
            updated.copy(filteredLogs = applyFilters(state.logs, updated))
        }
    }

    fun setPackageFilter(pkg: String) {
        _uiState.update { state ->
            val updated = state.copy(packageFilter = pkg)
            updated.copy(filteredLogs = applyFilters(state.logs, updated))
        }
    }

    fun setTagFilter(tag: String) {
        _uiState.update { state ->
            val updated = state.copy(tagFilter = tag)
            updated.copy(filteredLogs = applyFilters(state.logs, updated))
        }
    }

    fun toggleAutoScroll() {
        _uiState.update { it.copy(autoScroll = !it.autoScroll) }
    }

    fun setAutoScroll(value: Boolean) {
        _uiState.update { it.copy(autoScroll = value) }
    }

    private fun applyFilters(logs: List<LogEntry>, state: LogcatUiState): List<LogEntry> {
        return logs.filter { entry ->
            val matchesSearch = state.searchQuery.isEmpty() ||
                    entry.message.contains(state.searchQuery, ignoreCase = true) ||
                    entry.tag.contains(state.searchQuery, ignoreCase = true)

            val matchesTag = state.tagFilter.isEmpty() ||
                    entry.tag.contains(state.tagFilter, ignoreCase = true)

            // Package filter: match against tag or message (logcat doesn't always show package)
            val matchesPkg = state.packageFilter.isEmpty() ||
                    entry.tag.contains(state.packageFilter, ignoreCase = true) ||
                    entry.message.contains(state.packageFilter, ignoreCase = true)

            matchesSearch && matchesTag && matchesPkg
        }
    }

    override fun onCleared() {
        super.onCleared()
        readJob?.cancel()
    }
}
