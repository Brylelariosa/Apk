package com.logcatviewer.app.util

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku

private const val TAG = "ShizukuHelper"
private const val SHIZUKU_CODE = 1001

object ShizukuHelper {

    /** True if Shizuku binder is alive and we hold its permission */
    val isAvailable: Boolean
        get() = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    val hasShizukuPermission: Boolean
        get() = runCatching {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)

    /** Request the Shizuku API permission (shows Shizuku dialog) */
    fun requestShizukuPermission() {
        if (!isAvailable) return
        if (Shizuku.isPreV11()) {
            // Pre v11: use old permission model (not supported here)
            Log.w(TAG, "Shizuku pre-v11 not supported")
            return
        }
        Shizuku.requestPermission(SHIZUKU_CODE)
    }

    /**
     * Use Shizuku shell to grant READ_LOGS to our own package.
     * Returns true on success.
     */
    fun grantReadLogsPermission(packageName: String): Boolean {
        if (!isAvailable || !hasShizukuPermission) return false
        return try {
            val process = Shizuku.newProcess(
                arrayOf("pm", "grant", packageName, "android.permission.READ_LOGS"),
                null, "/"
            )
            val exitCode = process.waitFor()
            Log.d(TAG, "pm grant exit code: $exitCode")
            exitCode == 0
        } catch (e: Exception) {
            Log.e(TAG, "Failed to grant READ_LOGS", e)
            false
        }
    }

    /** Check if app currently holds READ_LOGS */
    fun hasReadLogsPermission(context: Context): Boolean =
        context.checkSelfPermission("android.permission.READ_LOGS") ==
                PackageManager.PERMISSION_GRANTED

    fun addBinderReceivedListener(listener: Shizuku.OnBinderReceivedListener) {
        Shizuku.addBinderReceivedListenerSticky(listener)
    }

    fun removeBinderReceivedListener(listener: Shizuku.OnBinderReceivedListener) {
        Shizuku.removeBinderReceivedListener(listener)
    }

    fun addBinderDeadListener(listener: Shizuku.OnBinderDeadListener) {
        Shizuku.addBinderDeadListener(listener)
    }

    fun removeBinderDeadListener(listener: Shizuku.OnBinderDeadListener) {
        Shizuku.removeBinderDeadListener(listener)
    }

    fun addPermissionResultListener(listener: Shizuku.OnRequestPermissionResultListener) {
        Shizuku.addRequestPermissionResultListener(listener)
    }

    fun removePermissionResultListener(listener: Shizuku.OnRequestPermissionResultListener) {
        Shizuku.removeRequestPermissionResultListener(listener)
    }
}
