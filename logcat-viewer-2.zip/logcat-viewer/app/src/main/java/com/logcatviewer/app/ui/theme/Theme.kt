package com.logcatviewer.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6897BB),
    onPrimary = Color.White,
    background = Color(0xFF1E1E1E),
    surface = Color(0xFF2B2B2B),
    onSurface = Color(0xFFD4D4D4),
    onBackground = Color(0xFFD4D4D4),
    surfaceVariant = Color(0xFF3C3F41),
)

@Composable
fun LogcatViewerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}
