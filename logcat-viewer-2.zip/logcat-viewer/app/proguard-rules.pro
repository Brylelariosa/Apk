# Shizuku
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }

# Keep the app classes
-keep class com.logcatviewer.app.** { *; }
