package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class ScreenshotAccessibilityService : AccessibilityService() {

    companion object {
        const val ACTION_TAKE_SCREENSHOT = "com.screenshottile.TAKE_SCREENSHOT"

        // Tile service checks this to know if we're running
        @Volatile var instance: ScreenshotAccessibilityService? = null
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == ACTION_TAKE_SCREENSHOT) captureScreen()
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val filter = IntentFilter(ACTION_TAKE_SCREENSHOT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    // ── Screenshot ────────────────────────────────────────────────────────────

    fun captureScreen() {
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    // Copy off the hardware buffer immediately — it's recycled after this callback
                    val bmp = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    result.hardwareBuffer.close()
                    if (bmp != null) saveToGallery(bmp)
                    else toast("Screenshot failed: empty frame")
                }
                override fun onFailure(errorCode: Int) {
                    toast("Screenshot failed (code $errorCode)")
                }
            }
        )
    }

    // ── Save ──────────────────────────────────────────────────────────────────

    private fun saveToGallery(bitmap: Bitmap) {
        val filename = "Screenshot_${System.currentTimeMillis()}.png"
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Screenshots")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("MediaStore insert returned null")

            contentResolver.openOutputStream(uri)!!.use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }

            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)

            toast("Screenshot saved!")
        } catch (e: Exception) {
            toast("Save failed: ${e.message}")
        } finally {
            bitmap.recycle()
        }
    }

    private fun toast(msg: String) =
        mainHandler.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
}
