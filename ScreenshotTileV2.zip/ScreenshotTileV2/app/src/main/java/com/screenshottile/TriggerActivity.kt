package com.screenshottile

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/**
 * Completely transparent, zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this runs,
 * so we just wait a beat for the animation to finish, then capture.
 */
class TriggerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val service = ScreenshotAccessibilityService.instance
        if (service == null) {
            finish()
            return
        }
        // 250 ms is enough for the QS collapse animation to complete
        Handler(Looper.getMainLooper()).postDelayed({
            service.captureScreen()
            finish()
        }, 250)
    }
}
