#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <memory>

#include "core/Renderer.h"
#include "core/World.h"
#include "core/Camera.h"
#include "core/Input.h"
#include "core/BlockDefs.h"
#include "core/MathUtils.h"

#define LOG_TAG "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── Game state (single global instance is fine for a game) ───────────────────
static std::unique_ptr<Renderer> g_renderer;
static std::unique_ptr<World>    g_world;
static std::unique_ptr<Camera>   g_camera;
static std::unique_ptr<Input>    g_input;

static int   g_width  = 1;
static int   g_height = 1;
static long  g_lastNs = 0;
static bool  g_inited = false;

static float g_velY      = 0.f;        // vertical velocity for gravity
static bool  g_onGround  = false;
static uint8_t g_hotbar[9] = {
    BLOCK_GRASS, BLOCK_DIRT, BLOCK_STONE,
    BLOCK_SAND,  BLOCK_LOG,  BLOCK_LEAVES,
    BLOCK_GLOWSTONE, BLOCK_LAVA, BLOCK_SNOW
};
static int g_hotbarSel = 0;

// ── Time helper ───────────────────────────────────────────────────────────────
static long nowNs() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000L + ts.tv_nsec;
}

// ── Physics helpers ───────────────────────────────────────────────────────────
static bool solidAt(const World* w, float x, float y, float z) {
    return blockSolid(w->getBlock((int)floorf(x),(int)floorf(y),(int)floorf(z)));
}

static bool playerOnGround(const World* w, Vec3 pos) {
    float feet = pos.y - 1.8f;
    for (float dx : {-0.3f, 0.3f})
        for (float dz : {-0.3f, 0.3f})
            if (solidAt(w, pos.x+dx, feet-0.05f, pos.z+dz)) return true;
    return false;
}

static Vec3 collideMove(const World* w, Vec3 pos, Vec3 delta) {
    // Simple AABB sweep (axis-separated)
    const float EY = 1.8f;   // eye height

    // Move X
    Vec3 np = {pos.x+delta.x, pos.y, pos.z};
    float sx = delta.x > 0 ? 0.3f : -0.3f;
    if (solidAt(w,np.x+sx,pos.y-EY+0.1f,pos.z)  ||
        solidAt(w,np.x+sx,pos.y-EY+1.0f,pos.z)  ||
        solidAt(w,np.x+sx,pos.y,         pos.z))
        delta.x = 0;

    // Move Z
    np = {pos.x, pos.y, pos.z+delta.z};
    float sz = delta.z > 0 ? 0.3f : -0.3f;
    if (solidAt(w,pos.x,pos.y-EY+0.1f,np.z+sz) ||
        solidAt(w,pos.x,pos.y-EY+1.0f,np.z+sz) ||
        solidAt(w,pos.x,pos.y,         np.z+sz))
        delta.z = 0;

    // Move Y
    np = {pos.x, pos.y+delta.y, pos.z};
    if (delta.y < 0) {
        float fy = pos.y - EY + delta.y;
        bool blocked = false;
        for (float dx : {-0.3f,0.3f}) for (float dz : {-0.3f,0.3f})
            if (solidAt(w,pos.x+dx,fy,pos.z+dz)) blocked=true;
        if (blocked) { delta.y=0; g_velY=0; }
    } else if (delta.y > 0) {
        if (solidAt(w,pos.x,pos.y+delta.y+0.1f,pos.z)) { delta.y=0; g_velY=0; }
    }

    return pos + delta;
}

// ── Per-frame game tick ───────────────────────────────────────────────────────
static void gameTick(float dt) {
    if (!g_world || !g_camera || !g_input) return;

    // Clamp dt to avoid spiral of death
    if (dt > 0.1f) dt = 0.1f;

    // --- Camera look from touch drag (0.003 rad/pixel is comfortable) ---
    float dx = g_input->consumeDX() * -0.003f;
    float dy = g_input->consumeDY() * -0.003f;
    g_camera->rotate(dx, dy);

    // --- Movement ---
    Vec3 mov = g_input->getMovement();     // x=strafe, z=forward in local space
    float speed = 5.5f;
    Vec3 fwd = g_camera->getForward();
    Vec3 rgt = g_camera->getRight();
    // Project onto horizontal plane
    fwd.y = 0; fwd = normalize(fwd);
    rgt.y = 0; rgt = normalize(rgt);

    Vec3 movWorld = rgt * (mov.x * speed * dt)
                  + fwd * (-mov.z * speed * dt);  // z+ = finger down = walk backward

    // --- Gravity & jump ---
    g_onGround = playerOnGround(g_world.get(), g_camera->getPosition());
    g_velY -= 20.f * dt;       // gravity 20 m/s²
    if (g_onGround && g_velY < 0) g_velY = 0;

    if (g_input->isJumpPressed()) {
        if (g_onGround) g_velY = 9.f;
        g_input->clearActions();
    }

    movWorld.y = g_velY * dt;

    Vec3 newPos = collideMove(g_world.get(), g_camera->getPosition(), movWorld);
    g_camera->setPosition(newPos);

    // --- Block place / break ---
    if (g_input->isPlacePressed() || g_input->isBreakPressed()) {
        Vec3 eye = g_camera->getPosition();
        Vec3 dir = g_camera->getForward();
        Vec3 hitPos, hitNorm;
        if (g_world->raycast(eye, dir, 6.f, hitPos, hitNorm)) {
            if (g_input->isBreakPressed()) {
                g_world->setBlock((int)hitPos.x,(int)hitPos.y,(int)hitPos.z, BLOCK_AIR);
            } else {
                Vec3 placePos = hitPos + hitNorm;
                g_world->setBlock((int)placePos.x,(int)placePos.y,(int)placePos.z,
                                  g_hotbar[g_hotbarSel]);
            }
        }
        g_input->clearActions();
    }

    // --- Streaming: update chunks around player ---
    Vec3 pos = g_camera->getPosition();
    g_world->update(pos.x, pos.z, /*renderDist=*/5, g_renderer->getMVPLoc());
}

// ═════════════════════════════════════════════════════════════════════════════
// JNI entry points (names must match Java native declarations exactly)
// ═════════════════════════════════════════════════════════════════════════════
extern "C" {

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit");
    g_renderer = std::make_unique<Renderer>();
    g_world    = std::make_unique<World>(12345u);
    g_camera   = std::make_unique<Camera>();
    g_input    = std::make_unique<Input>();

    if (!g_renderer->init()) {
        LOGE("Renderer init failed");
        return;
    }
    g_lastNs = nowNs();
    g_inited = true;
    LOGI("nativeInit complete");
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    g_width  = w;
    g_height = h;
    if (g_renderer) g_renderer->resize(w, h);
    if (g_camera)   g_camera->updateProjection((float)w/(float)h);
    if (g_input)    g_input->setScreenSize((float)w,(float)h);
    LOGI("nativeResize %d x %d", w, h);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (!g_inited) return;

    // ── Delta time ───────────────────────────────────────────────────────────
    long now = nowNs();
    float dt  = (float)(now - g_lastNs) * 1e-9f;
    g_lastNs  = now;

    // ── Game tick ────────────────────────────────────────────────────────────
    gameTick(dt);

    // ── Render 3D world ──────────────────────────────────────────────────────
    g_renderer->beginFrame();

    glUseProgram(g_renderer->getWorldProg());
    Mat4 vp = g_camera->getViewProjection();
    g_world->renderAll(g_renderer->getMVPLoc(), vp.m);

    // ── Render HUD ───────────────────────────────────────────────────────────
    g_renderer->renderHUD(
        (float)g_width, (float)g_height,
        g_input->joyCurrentX(), g_input->joyCurrentY(),
        g_input->joyActive(),
        g_input->joyStartX(),  g_input->joyStartY()
    );
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchDown(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchDown(id, x, y);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchMove(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchMove(id, x, y);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchUp(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchUp(id, x, y);
}

} // extern "C"
