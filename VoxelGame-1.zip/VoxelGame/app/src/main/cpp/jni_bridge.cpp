#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <memory>
#include <string>

#include "core/CrashReporter.h"
#include "core/Renderer.h"
#include "core/World.h"
#include "core/Camera.h"
#include "core/Input.h"
#include "core/BlockDefs.h"
#include "core/MathUtils.h"

#define LOG_TAG "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── State ─────────────────────────────────────────────────────────────────────
static std::unique_ptr<Renderer> g_renderer;
static std::unique_ptr<World>    g_world;
static std::unique_ptr<Camera>   g_camera;
static std::unique_ptr<Input>    g_input;

static int   g_width=1, g_height=1;
static long  g_lastNs=0;
static bool  g_inited=false;
static std::string g_errorMsg;
static bool  g_showError=false;

// Physics
static float g_velY=0.f, g_velX=0.f, g_velZ=0.f;
static bool  g_onGround=false;

// Break
static int   g_breakX=-99999, g_breakY=-99999, g_breakZ=-99999;
static float g_breakProgress=0.f;
static const float BREAK_TIME = 0.7f;

// Settings – panel coords match Renderer exactly
static bool  g_settingsOpen = false;
static int   g_renderDist   = 4;

// Panel geometry (computed in nativeResize, matches Renderer draw calls)
static float g_panelX=0, g_panelY=0, g_panelW=360, g_panelH=180;
static float g_btnMinusX=0, g_btnPlusX=0, g_btnBtnY=0;

static void recomputePanelGeometry(float sw, float sh) {
    g_panelW = 360; g_panelH = 180;
    g_panelX = (sw - g_panelW) * 0.5f;
    g_panelY = (sh - g_panelH) * 0.5f;
    g_btnBtnY  = g_panelY + g_panelH * 0.72f;
    g_btnMinusX = g_panelX + 70.f;
    g_btnPlusX  = g_panelX + g_panelW - 70.f;
}

// FPS
static float g_fpsTimer=0.f;
static int   g_fpsFrames=0, g_fpsDisplay=0;

// Loading
static int  g_loadFrame=0;
static bool g_everHadChunks=false;

// Hotbar
static uint8_t g_hotbar[9]={
    BLOCK_GRASS,BLOCK_DIRT,BLOCK_STONE,
    BLOCK_SAND,BLOCK_LOG,BLOCK_LEAVES,
    BLOCK_GLOWSTONE,BLOCK_LAVA,BLOCK_SNOW
};
static int g_hotbarSel=0;
static char g_crashPath[512]={};

// ── Helpers ───────────────────────────────────────────────────────────────────
static long nowNs(){
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts);
    return ts.tv_sec*1000000000L+ts.tv_nsec;
}
static bool solidAt(const World* w,float x,float y,float z){
    return blockSolid(w->getBlock((int)floorf(x),(int)floorf(y),(int)floorf(z)));
}
static bool onGround(const World* w,Vec3 pos){
    float feet=pos.y-1.85f;
    for(float dx:{-0.28f,0.28f}) for(float dz:{-0.28f,0.28f})
        if(solidAt(w,pos.x+dx,feet,pos.z+dz)) return true;
    return false;
}
static Vec3 collide(const World* w,Vec3 pos,Vec3 d){
    const float EY=1.8f;
    float sx=d.x>0?.29f:-.29f;
    if(solidAt(w,pos.x+d.x+sx,pos.y-EY+.1f,pos.z)||
       solidAt(w,pos.x+d.x+sx,pos.y-EY+.9f,pos.z)||
       solidAt(w,pos.x+d.x+sx,pos.y-.1f,pos.z)) d.x=0;
    float sz=d.z>0?.29f:-.29f;
    if(solidAt(w,pos.x,pos.y-EY+.1f,pos.z+d.z+sz)||
       solidAt(w,pos.x,pos.y-EY+.9f,pos.z+d.z+sz)||
       solidAt(w,pos.x,pos.y-.1f,pos.z+d.z+sz)) d.z=0;
    if(d.y<0){
        bool bl=false;
        for(float ddx:{-.28f,.28f}) for(float ddz:{-.28f,.28f})
            if(solidAt(w,pos.x+ddx,pos.y-EY+d.y,pos.z+ddz)) bl=true;
        if(bl){d.y=0;g_velY=0;}
    }
    if(d.y>0&&solidAt(w,pos.x,pos.y+d.y+.05f,pos.z)){d.y=0;g_velY=0;}
    return pos+d;
}

// ── Settings panel touch test (called from nativeTouchDown directly) ──────────
// Returns: 0=not panel, 1=minus, 2=plus, 3=gear, 4=background(close)
static int hitSettingsArea(float x, float y) {
    float sw=(float)g_width, sh=(float)g_height;
    // Gear button
    if (x > sw-70.f && y < 70.f) return 3;
    if (!g_settingsOpen) return 0;
    // Minus button
    float dx1=x-g_btnMinusX, dy1=y-g_btnBtnY;
    if (dx1*dx1+dy1*dy1 < 55.f*55.f) return 1;
    // Plus button
    float dx2=x-g_btnPlusX,  dy2=y-g_btnBtnY;
    if (dx2*dx2+dy2*dy2 < 55.f*55.f) return 2;
    // Inside panel background = do nothing (don't close)
    if (x>=g_panelX && x<=g_panelX+g_panelW &&
        y>=g_panelY && y<=g_panelY+g_panelH) return 0;
    // Outside panel = close
    return 4;
}

static void renderError(){
    static int f=0; f++;
    float r=((f/20)%2==0)?.85f:.45f;
    glClearColor(r,.03f,.03f,1.f);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
}

// ── Game tick (only runs when settings closed) ────────────────────────────────
static void gameTick(float dt){
    if(!g_world||!g_camera||!g_input) return;
    if(dt>0.05f) dt=0.05f;   // cap at 50ms — prevents huge jumps after stutter

    g_fpsTimer+=dt; g_fpsFrames++;
    if(g_fpsTimer>=0.5f){
        g_fpsDisplay=(int)(g_fpsFrames/g_fpsTimer+.5f);
        g_fpsTimer=0; g_fpsFrames=0;
    }

    // Look — apply rotation BEFORE movement so direction is fresh this frame
    float dyaw   = g_input->consumeDX() * -0.0025f;
    float dpitch = g_input->consumeDY() *  0.0025f;
    g_camera->rotate(dyaw, dpitch);

    // Move
    Vec3 mov=g_input->getMovement();
    Vec3 fwd=g_camera->getForward(); fwd.y=0; fwd=normalize(fwd);
    Vec3 rgt=g_camera->getRight();   rgt.y=0; rgt=normalize(rgt);
    Vec3 movW=rgt*(mov.x*5.5f*dt)+fwd*(-mov.z*5.5f*dt);

    g_onGround=onGround(g_world.get(),g_camera->getPosition());
    g_velY-=22.f*dt;
    if(g_onGround&&g_velY<0.f) g_velY=0.f;
    if(g_input->isJumpPressed()&&g_onGround) g_velY=9.5f;
    movW.y=g_velY*dt;

    g_camera->setPosition(collide(g_world.get(),g_camera->getPosition(),movW));

    // Raycast
    Vec3 eye=g_camera->getPosition(), dir=g_camera->getForward();
    Vec3 hitPos,hitNorm;
    bool hasTarget=g_world->raycast(eye,dir,6.f,hitPos,hitNorm);

    // Place
    if(g_input->isPlacePressed()&&hasTarget){
        int px=(int)floorf(hitPos.x+hitNorm.x+.5f);
        int py=(int)floorf(hitPos.y+hitNorm.y+.5f);
        int pz=(int)floorf(hitPos.z+hitNorm.z+.5f);
        Vec3 ep=g_camera->getPosition();
        bool inside=(px==(int)floorf(ep.x)&&pz==(int)floorf(ep.z))&&
                    (py==(int)floorf(ep.y)||py==(int)floorf(ep.y)-1||py==(int)floorf(ep.y)-2);
        if(!inside) g_world->setBlock(px,py,pz,g_hotbar[g_hotbarSel]);
    }

    // Break (hold)
    if(g_input->isBreakHeld()&&hasTarget){
        int hx=(int)floorf(hitPos.x),hy=(int)floorf(hitPos.y),hz=(int)floorf(hitPos.z);
        if(hx==g_breakX&&hy==g_breakY&&hz==g_breakZ){
            g_breakProgress+=dt/BREAK_TIME;
            if(g_breakProgress>=1.f){
                g_world->setBlock(hx,hy,hz,BLOCK_AIR);
                g_breakProgress=0.f; g_breakX=g_breakY=g_breakZ=-99999;
            }
        } else {
            g_breakX=hx; g_breakY=hy; g_breakZ=hz; g_breakProgress=0.f;
        }
    } else { g_breakProgress=0.f; g_breakX=g_breakY=g_breakZ=-99999; }

    g_input->clearActions();
    g_world->update(eye.x,eye.z,g_renderDist);
}

// ═══════════════════════════════════════════════════════════════════════════════
extern "C" {

JNIEXPORT jstring JNICALL
Java_com_voxel_game_GameRenderer_nativeSetup(JNIEnv* env,jobject,jstring jDir){
    const char* dir=env->GetStringUTFChars(jDir,nullptr);
    snprintf(g_crashPath,sizeof(g_crashPath),"%s/crash.txt",dir);
    env->ReleaseStringUTFChars(jDir,dir);
    installCrashHandler(g_crashPath);
    std::string rep=loadAndClearCrashReport(g_crashPath);
    return env->NewStringUTF(rep.empty()?"":rep.c_str());
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeInit(JNIEnv*,jobject){
    LOGI("nativeInit");
    const char* glv=(const char*)glGetString(GL_VERSION);
    LOGI("GL: %s",glv?glv:"null");
    if(!glv){g_errorMsg="OpenGL ES unavailable.";g_showError=true;return;}
    try {
        g_renderer=std::make_unique<Renderer>();
        if(!g_renderer->init()){g_errorMsg="Shader compile failed.";g_showError=true;return;}
        g_world  =std::make_unique<World>(12345u);
        g_camera =std::make_unique<Camera>();
        g_input  =std::make_unique<Input>();
        g_camera->setPosition({8.f,100.f,8.f});
        g_velY=0.f; g_lastNs=nowNs(); g_inited=true;
        LOGI("nativeInit OK");
    } catch(const std::exception& e){
        g_errorMsg=std::string("Init exception: ")+e.what(); g_showError=true;
    } catch(...){g_errorMsg="Unknown init exception";g_showError=true;}
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeResize(JNIEnv*,jobject,jint w,jint h){
    g_width=w; g_height=h;
    if(g_renderer) g_renderer->resize(w,h);
    if(g_camera)   g_camera->updateProjection((float)w/(float)h);
    if(g_input)    g_input->setScreenSize((float)w,(float)h);
    recomputePanelGeometry((float)w,(float)h);
    LOGI("resize %dx%d panelX=%.0f btnMinus=%.0f btnPlus=%.0f btnY=%.0f",
         w,h,g_panelX,g_btnMinusX,g_btnPlusX,g_btnBtnY);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeRender(JNIEnv*,jobject){
    if(g_showError){renderError();return;}
    if(!g_inited) return;

    long now=nowNs();
    float dt=(float)(now-g_lastNs)*1e-9f;
    g_lastNs=now;

    if(!g_settingsOpen) gameTick(dt);

    g_renderer->beginFrame();

    size_t ready=g_world->chunkCount();
    if(!g_everHadChunks){
        if(ready>=2) g_everHadChunks=true;
        else{
            g_loadFrame++;
            g_renderer->renderLoading((float)g_width,(float)g_height,g_loadFrame);
            return;
        }
    }

    glUseProgram(g_renderer->getWorldProg());
    Mat4 vp=g_camera->getViewProjection();
    g_world->renderAll(g_renderer->getMVPLoc(),vp.m);

    g_renderer->renderHUD(
        (float)g_width,(float)g_height,
        g_input->joyBaseX(), g_input->joyBaseY(),
        g_input->joyThumbX(),g_input->joyThumbY(),
        g_input->joyActive(),
        g_breakProgress,
        g_fpsDisplay,
        g_renderDist,
        g_settingsOpen
    );
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchDown(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(!g_input) return;
    int hit=hitSettingsArea(x,y);
    if(hit==3){ g_settingsOpen=!g_settingsOpen; return; }          // gear toggle
    if(hit==1){ g_renderDist=std::max(g_renderDist-1,2); return; } // minus
    if(hit==2){ g_renderDist=std::min(g_renderDist+1,24); return; }// plus
    if(hit==4){ g_settingsOpen=false; return; }                     // close
    if(g_settingsOpen) return;                                      // eat other taps
    g_input->onTouchDown(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchMove(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(g_input&&!g_settingsOpen) g_input->onTouchMove(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchUp(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(g_input) g_input->onTouchUp(id,x,y);
}

} // extern "C"
