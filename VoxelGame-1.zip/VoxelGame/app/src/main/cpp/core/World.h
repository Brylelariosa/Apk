#pragma once
#include "Chunk.h"
#include "Noise.h"
#include "MathUtils.h"
#include <unordered_map>
#include <memory>
#include <cstdint>

struct ChunkKey {
    int x, z;
    bool operator==(const ChunkKey& o) const { return x==o.x && z==o.z; }
};
struct ChunkHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int64_t>()(((int64_t)k.x<<32)|(uint32_t)k.z);
    }
};

class World {
public:
    explicit World(uint32_t seed = 42);

    uint8_t  getBlock(int x, int y, int z) const;
    void     setBlock(int x, int y, int z, uint8_t type);

    // Returns chunk, creating and generating it if needed
    Chunk*   getOrCreate(int cx, int cz);
    Chunk*   getChunk(int cx, int cz) const;

    // Load/unload chunks around player; rebuild dirty meshes
    void     update(float px, float pz, int renderDist, GLint mvpLoc);

    // Render all loaded chunks
    void     renderAll(GLint mvpLoc, const float* vp) const;

    // DDA raycast; returns true and fills hitPos (block coords) + hitNormal
    bool     raycast(Vec3 origin, Vec3 dir, float maxDist,
                     Vec3& hitPos, Vec3& hitNormal) const;

private:
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkHash> chunks;
    Noise    noise;
    uint32_t seed;

    void generateChunk(Chunk* c);
    void placeTree(Chunk* c, int lx, int y, int lz);
};
