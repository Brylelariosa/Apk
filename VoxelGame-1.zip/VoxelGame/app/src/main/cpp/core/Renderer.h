#pragma once
#include <GLES3/gl3.h>

class Renderer {
public:
    Renderer() = default;
    ~Renderer();

    bool init();
    void resize(int w, int h);
    void beginFrame();

    GLint  getMVPLoc()   const { return mvpLoc; }
    GLuint getWorldProg()const { return worldProg; }

    // Draw 2D HUD overlay
    void renderHUD(float sw, float sh,
                   float joyX, float joyY,
                   bool  joyActive, float joyStartX, float joyStartY);

private:
    GLuint worldProg = 0;
    GLuint hudProg   = 0;
    GLint  mvpLoc    = -1;

    // HUD geometry
    GLuint hudVAO = 0, hudVBO = 0;
    GLint  hudOrthoLoc=-1, hudColorLoc=-1;

    int    screenW=1, screenH=1;

    static GLuint compileShader(GLenum type, const char* src);
    static GLuint linkProgram(GLuint vert, GLuint frag);

    void buildHudBuffers();
    void drawCircle(float cx, float cy, float r, float a, bool filled,
                    float red, float green, float blue);
    void drawLine(float x0,float y0,float x1,float y1,
                  float red,float green,float blue);
};
