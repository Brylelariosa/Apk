#include "World.h"
#include "BlockDefs.h"
#include <cmath>
#include <cstdlib>
#include <android/log.h>

#define LOG_TAG "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

World::World(uint32_t s) : noise(s), seed(s) {}

// ── Block access ──────────────────────────────────────────────────────────────
uint8_t World::getBlock(int x, int y, int z) const {
    if (y<0||y>=CH) return 0;
    int cx = (x<0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z<0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it==chunks.end()) return 0;
    int lx = x - cx*CW;
    int lz = z - cz*CD;
    return it->second->getBlock(lx, y, lz);
}

void World::setBlock(int x, int y, int z, uint8_t type) {
    if (y<0||y>=CH) return;
    int cx = (x<0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z<0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it==chunks.end()) return;
    int lx = x - cx*CW;
    int lz = z - cz*CD;
    it->second->setBlock(lx, y, lz, type);
    // Also dirty adjacent chunks at borders
    if (lx==0)     { auto n=chunks.find({cx-1,cz}); if(n!=chunks.end()) n->second->markDirty(); }
    if (lx==CW-1)  { auto n=chunks.find({cx+1,cz}); if(n!=chunks.end()) n->second->markDirty(); }
    if (lz==0)     { auto n=chunks.find({cx,cz-1}); if(n!=chunks.end()) n->second->markDirty(); }
    if (lz==CD-1)  { auto n=chunks.find({cx,cz+1}); if(n!=chunks.end()) n->second->markDirty(); }
}

// ── Chunk access ──────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    auto it = chunks.find({cx,cz});
    return (it!=chunks.end()) ? it->second.get() : nullptr;
}

Chunk* World::getOrCreate(int cx, int cz) {
    auto it = chunks.find({cx,cz});
    if (it!=chunks.end()) return it->second.get();
    auto c = std::make_unique<Chunk>(cx, cz);
    generateChunk(c.get());
    Chunk* ptr = c.get();
    chunks[{cx,cz}] = std::move(c);
    return ptr;
}

// ── Terrain generation ────────────────────────────────────────────────────────
void World::generateChunk(Chunk* c) {
    const int wx0 = c->getChunkX() * CW;
    const int wz0 = c->getChunkZ() * CD;

    // Temperature / moisture for biome selection
    float tempOff  = noise.noise2D(wx0/300.f + 500, wz0/300.f) * 0.5f + 0.5f;
    float moistOff = noise.noise2D(wx0/300.f + 200, wz0/300.f + 200) * 0.5f + 0.5f;

    for (int lx=0; lx<CW; lx++) {
        for (int lz=0; lz<CD; lz++) {
            float wx = (float)(wx0+lx), wz = (float)(wz0+lz);

            // Height from fractal noise
            float h  = noise.fbm(wx/120.f, wz/120.f, 6);
            float h2 = noise.fbm(wx/40.f + 7, wz/40.f + 3, 4) * 0.3f;
            int   height = 60 + (int)((h + h2) * 30.f);
            height = std::max(2, std::min(CH-2, height));

            // Temperature / moisture at this column
            float temp  = tempOff  + noise.noise2D(wx/80.f,  wz/80.f)  * 0.15f;
            float moist = moistOff + noise.noise2D(wx/80.f+100, wz/80.f+100) * 0.15f;

            // Choose surface block
            uint8_t surface = BLOCK_GRASS;
            uint8_t sub     = BLOCK_DIRT;
            if (height <= 61)           { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp > 0.65f)      { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp < 0.35f)      { surface=BLOCK_SNOW; }
            else if (height > 90)       { surface=BLOCK_SNOW; }

            for (int y=0; y<=height; y++) {
                uint8_t type;
                if (y == height)            type = surface;
                else if (y >= height-3)     type = sub;
                else                        type = BLOCK_STONE;

                // Ore veins
                if (type == BLOCK_STONE) {
                    float ore = noise.noise3D(wx/8.f, (float)y/8.f, wz/8.f);
                    if (ore > 0.45f && y < 30)      type = BLOCK_COAL;
                    else if (ore > 0.47f && y < 50) type = BLOCK_IRON;
                    else if (ore > 0.48f && y < 20) type = BLOCK_GLOWSTONE;
                }

                c->setBlock(lx, y, lz, type);
            }

            // Water fill to sea level
            for (int y=height+1; y<=60; y++) c->setBlock(lx,y,lz,BLOCK_WATER);

            // Trees on grass (avoid borders for simplicity)
            if (surface==BLOCK_GRASS && lx>=2&&lx<=CW-3&&lz>=2&&lz<=CD-3) {
                uint32_t rng = (uint32_t)((wx0+lx)*73856093 ^ (wz0+lz)*19349663 ^ seed);
                rng = rng*1664525u+1013904223u;
                if ((rng % 50) == 0) {
                    placeTree(c, lx, height+1, lz);
                }
            }
        }
    }
    c->markDirty();
}

void World::placeTree(Chunk* c, int lx, int y, int lz) {
    // Trunk
    for (int i=0;i<5;i++) c->setBlock(lx, y+i, lz, BLOCK_LOG);
    // Leaf canopy
    for (int dy=3;dy<=5;dy++) {
        int r = (dy<5) ? 2 : 1;
        for (int dx=-r;dx<=r;dx++)
            for (int dz=-r;dz<=r;dz++)
                if (abs(dx)+abs(dz) <= r+1)
                    c->setBlock(lx+dx, y+dy, lz+dz, BLOCK_LEAVES);
    }
}

// ── Update / Render ───────────────────────────────────────────────────────────
void World::update(float px, float pz, int renderDist, GLint mvpLoc) {
    int pcx = (int)floorf(px / CW);
    int pcz = (int)floorf(pz / CD);

    // Ensure all chunks in range exist
    for (int dx=-renderDist; dx<=renderDist; dx++)
        for (int dz=-renderDist; dz<=renderDist; dz++)
            if (dx*dx+dz*dz <= renderDist*renderDist)
                getOrCreate(pcx+dx, pcz+dz);

    // Build world-block query for cross-chunk boundary faces
    auto worldGet = [this](int x, int y, int z) -> uint8_t {
        return getBlock(x, y, z);
    };

    // Rebuild dirty chunks and upload
    for (auto& [key, chunk] : chunks) {
        if (chunk->isDirty()) {
            chunk->buildMesh(worldGet);
        }
        if (!chunk->hasGpu() && !chunk->isDirty()) {
            chunk->uploadMesh();
        }
    }

    // Unload far chunks
    const int maxDist = renderDist + 3;
    for (auto it = chunks.begin(); it != chunks.end(); ) {
        int dx = it->first.x - pcx;
        int dz = it->first.z - pcz;
        if (dx*dx + dz*dz > maxDist*maxDist) it = chunks.erase(it);
        else ++it;
    }
}

void World::renderAll(GLint mvpLoc, const float* vp) const {
    for (auto& [key, chunk] : chunks) {
        chunk->render(mvpLoc, vp);
    }
}

// ── DDA Raycast ───────────────────────────────────────────────────────────────
bool World::raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const {
    dir = normalize(dir);
    int bx=(int)floorf(origin.x);
    int by=(int)floorf(origin.y);
    int bz=(int)floorf(origin.z);

    int sx = (dir.x>0)?1:-1, sy=(dir.y>0)?1:-1, sz=(dir.z>0)?1:-1;
    float dx = (dir.x!=0)?fabsf(1.f/dir.x):1e30f;
    float dy = (dir.y!=0)?fabsf(1.f/dir.y):1e30f;
    float dz = (dir.z!=0)?fabsf(1.f/dir.z):1e30f;

    auto frac = [](float v) { return v - floorf(v); };
    float tx = (dir.x>0) ? (1.f-frac(origin.x))*dx : frac(origin.x)*dx;
    float ty = (dir.y>0) ? (1.f-frac(origin.y))*dy : frac(origin.y)*dy;
    float tz = (dir.z>0) ? (1.f-frac(origin.z))*dz : frac(origin.z)*dz;

    Vec3 normal{};
    for (int steps=0; steps<256; steps++) {
        if (getBlock(bx,by,bz) != 0) {
            hitPos    = {(float)bx,(float)by,(float)bz};
            hitNormal = normal;
            return true;
        }
        float tmin = std::min({tx,ty,tz});
        if (tmin > maxDist) break;
        if (tx<=ty && tx<=tz) { tx+=dx; bx+=sx; normal={-(float)sx,0,0}; }
        else if(ty<=tz)       { ty+=dy; by+=sy; normal={0,-(float)sy,0}; }
        else                  { tz+=dz; bz+=sz; normal={0,0,-(float)sz}; }
    }
    return false;
}
