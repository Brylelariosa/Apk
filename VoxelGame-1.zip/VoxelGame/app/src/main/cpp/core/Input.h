#pragma once
#include "MathUtils.h"

// Maps multi-touch pointers to virtual controls:
//   Left  half of screen → virtual joystick (movement)
//   Right half of screen → look drag + action buttons
//
// Button layout (right side, same positions as HUD circles):
//   JUMP  : top button  (bx, by-100)
//   PLACE : left button (bx-100, by)
//   BREAK : right button(bx+100, by)

struct TouchPointer {
    int   id       = -1;
    float startX   = 0, startY = 0;
    float currentX = 0, currentY = 0;
    bool  active   = false;
};

enum class ButtonId { NONE, JUMP, PLACE, BREAK };

class Input {
public:
    static constexpr int MAX_TOUCH = 10;
    static constexpr float JOY_RADIUS   = 80.f;
    static constexpr float BTN_RADIUS   = 55.f;

    void setScreenSize(float w, float h);

    void onTouchDown(int id, float x, float y);
    void onTouchMove(int id, float x, float y);
    void onTouchUp  (int id, float x, float y);

    // Movement joystick: -1..1 on each axis
    Vec3   getMovement() const;   // x=strafe, z=forward

    // Look delta (pixels) since last call — consumed on read
    float  consumeDX();
    float  consumeDY();

    bool   isJumpPressed()   const { return jumpPressed; }
    bool   isPlacePressed()  const { return placePressed; }
    bool   isBreakPressed()  const { return breakPressed; }
    void   clearActions()          { jumpPressed=placePressed=breakPressed=false; }

    // HUD info for rendering
    bool  joyActive()  const { return joyPtrIdx >= 0; }
    float joyCurrentX()const { return joyPtrIdx>=0?ptrs[joyPtrIdx].currentX:0; }
    float joyCurrentY()const { return joyPtrIdx>=0?ptrs[joyPtrIdx].currentY:0; }
    float joyStartX()  const { return joyPtrIdx>=0?ptrs[joyPtrIdx].startX:0; }
    float joyStartY()  const { return joyPtrIdx>=0?ptrs[joyPtrIdx].startY:0; }

private:
    float sw = 1, sh = 1;
    TouchPointer ptrs[MAX_TOUCH];
    int   joyPtrIdx  = -1;   // index in ptrs[] for movement joystick
    int   lookPtrIdx = -1;   // index in ptrs[] for camera look
    float lookDX = 0, lookDY = 0;
    bool  jumpPressed  = false;
    bool  placePressed = false;
    bool  breakPressed = false;

    int   findSlot(int id) const;
    int   allocSlot(int id, float x, float y);
    void  freeSlot(int id);
    ButtonId hitButton(float x, float y) const;
};
