#include "Renderer.h"
#include <cmath>
#include <cstring>
#include <android/log.h>

#define LOG_TAG "VoxelRenderer"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

// ── World shader ─────────────────────────────────────────────────────────────
static const char* WORLD_VERT = R"(#version 300 es
precision mediump float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aColor;
layout(location=2) in float aLight;
uniform mat4 uMVP;
out vec3 vColor;
out float vFog;
void main(){
    vec4 pos = uMVP * vec4(aPos,1.0);
    gl_Position = pos;
    float dist = pos.z;
    vFog  = clamp((dist - 60.0) / 120.0, 0.0, 1.0);
    vColor = aColor * aLight;
}
)";

static const char* WORLD_FRAG = R"(#version 300 es
precision mediump float;
in vec3  vColor;
in float vFog;
out vec4 fragColor;
const vec3 SKY = vec3(0.53, 0.81, 0.98);
void main(){
    vec3 col = mix(vColor, SKY, vFog);
    fragColor = vec4(col, 1.0);
}
)";

// ── HUD shader ───────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
precision mediump float;
layout(location=0) in vec2 aPos;
uniform mat4 uOrtho;
void main(){
    gl_Position = uOrtho * vec4(aPos, 0.0, 1.0);
}
)";

static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main(){ fragColor = uColor; }
)";

// ── Shader utilities ──────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512]; glGetShaderInfoLog(s, 512, nullptr, buf);
        LOGE("Shader compile error: %s", buf);
    }
    return s;
}

GLuint Renderer::linkProgram(GLuint vert, GLuint frag) {
    GLuint p = glCreateProgram();
    glAttachShader(p, vert); glAttachShader(p, frag);
    glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[512]; glGetProgramInfoLog(p, 512, nullptr, buf);
        LOGE("Program link error: %s", buf);
    }
    glDeleteShader(vert); glDeleteShader(frag);
    return p;
}

// ── Init ──────────────────────────────────────────────────────────────────────
bool Renderer::init() {
    LOGI("GL Vendor:   %s", glGetString(GL_VENDOR));
    LOGI("GL Renderer: %s", glGetString(GL_RENDERER));
    LOGI("GL Version:  %s", glGetString(GL_VERSION));

    worldProg = linkProgram(compileShader(GL_VERTEX_SHADER,   WORLD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, WORLD_FRAG));
    hudProg   = linkProgram(compileShader(GL_VERTEX_SHADER,   HUD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));

    mvpLoc       = glGetUniformLocation(worldProg, "uMVP");
    hudOrthoLoc  = glGetUniformLocation(hudProg,   "uOrtho");
    hudColorLoc  = glGetUniformLocation(hudProg,   "uColor");

    glGenVertexArrays(1, &hudVAO);
    glGenBuffers(1, &hudVBO);
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferData(GL_ARRAY_BUFFER, 256 * 2 * sizeof(float), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
    glBindVertexArray(0);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    return (worldProg && hudProg);
}

void Renderer::resize(int w, int h) {
    screenW = w; screenH = h;
    glViewport(0, 0, w, h);
    LOGI("Viewport %d x %d", w, h);
}

void Renderer::beginFrame() {
    glClearColor(0.53f, 0.81f, 0.98f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

Renderer::~Renderer() {
    if (worldProg) glDeleteProgram(worldProg);
    if (hudProg)   glDeleteProgram(hudProg);
    if (hudVAO)    glDeleteVertexArrays(1, &hudVAO);
    if (hudVBO)    glDeleteBuffers(1, &hudVBO);
}

// ── HUD helpers ───────────────────────────────────────────────────────────────
static void buildOrtho(float l,float r,float b,float t, float* m) {
    // 4x4 column-major ortho
    memset(m,0,64);
    m[0]=2/(r-l); m[5]=2/(t-b); m[10]=-1;
    m[12]=-(r+l)/(r-l); m[13]=-(t+b)/(t-b); m[15]=1;
}

void Renderer::drawCircle(float cx,float cy,float radius,float alpha,
                           bool filled,float red,float green,float blue) {
    const int N = 32;
    float pts[N*2];
    for (int i=0;i<N;i++) {
        float a = 6.2831853f * i / N;
        pts[i*2]   = cx + cosf(a)*radius;
        pts[i*2+1] = cy + sinf(a)*radius;
    }
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(pts), pts);
    glUniform4f(hudColorLoc, red, green, blue, alpha);
    glDrawArrays(filled ? GL_TRIANGLE_FAN : GL_LINE_LOOP, 0, N);
    glBindVertexArray(0);
}

void Renderer::drawLine(float x0,float y0,float x1,float y1,
                         float red,float green,float blue) {
    float pts[4] = {x0,y0,x1,y1};
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(pts), pts);
    glUniform4f(hudColorLoc, red, green, blue, 1.f);
    glDrawArrays(GL_LINES, 0, 2);
    glBindVertexArray(0);
}

void Renderer::renderHUD(float sw, float sh,
                          float joyX, float joyY,
                          bool  joyActive, float joyStartX, float joyStartY) {
    // Switch to 2-D
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glUseProgram(hudProg);
    float ortho[16];
    buildOrtho(0,sw,sh,0, ortho);   // top-left origin
    glUniformMatrix4fv(hudOrthoLoc, 1, GL_FALSE, ortho);

    // Crosshair at screen centre
    float cx=sw*0.5f, cy=sh*0.5f, cs=20.f;
    drawLine(cx-cs,cy, cx+cs,cy, 1,1,1);
    drawLine(cx,cy-cs, cx,cy+cs, 1,1,1);

    // Virtual joystick (left side)
    if (joyActive) {
        // Base ring
        drawCircle(joyStartX, joyStartY, 80.f, 0.35f, false, 1,1,1);
        // Thumb dot
        drawCircle(joyX, joyY, 30.f, 0.5f, true, 0.8f,0.8f,0.8f);
    } else {
        // Ghost indicator bottom-left
        drawCircle(sw*0.15f, sh*0.80f, 80.f, 0.18f, false, 1,1,1);
    }

    // Right-side action buttons  (jump / place / break)
    float bx = sw*0.88f, by = sh*0.75f;
    drawCircle(bx,      by-100.f, 42.f, 0.4f, true,  0.2f,0.8f,0.2f); // Jump
    drawCircle(bx-100.f,by,       42.f, 0.4f, true,  0.8f,0.4f,0.1f); // Place
    drawCircle(bx+100.f,by,       42.f, 0.4f, true,  0.8f,0.1f,0.1f); // Break

    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}
