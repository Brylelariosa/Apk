#include "Input.h"
#include <cmath>

void Input::setScreenSize(float w, float h) {
    sw = w; sh = h;
    fixedJoyX = w * 0.14f;
    fixedJoyY = h * 0.78f;
}

// ── Slot management ───────────────────────────────────────────────────────────
int Input::findSlot(int id) const {
    for (int i = 0; i < MAX_TOUCH; i++)
        if (ptrs[i].active && ptrs[i].id == id) return i;
    return -1;
}
int Input::allocSlot(int id, float x, float y) {
    for (int i = 0; i < MAX_TOUCH; i++) {
        if (!ptrs[i].active) { ptrs[i]={id,x,y,x,y,true}; return i; }
    }
    return -1;
}
void Input::freeSlot(int id) {
    int i = findSlot(id);
    if (i < 0) return;
    if (i == joyPtrIdx)  joyPtrIdx  = -1;
    if (i == lookPtrIdx) lookPtrIdx = -1;
    ptrs[i].active = false;
}

// ── Button hit-test ───────────────────────────────────────────────────────────
// NOTE: Settings panel buttons are NOT handled here — they are tested
// directly in jni_bridge with the exact same coordinates used by the renderer,
// so they can never go out of sync.
ButtonId Input::hitButton(float x, float y) const {
    auto d2 = [&](float cx, float cy) {
        float dx=x-cx, dy=y-cy; return dx*dx+dy*dy;
    };
    float r2 = BTN_RADIUS * BTN_RADIUS;
    // Only test game buttons when on the right side
    if (x > sw * 0.45f) {
        if (d2(sw*0.84f, sh*0.68f) < r2) return ButtonId::JUMP;
        if (d2(sw*0.74f, sh*0.78f) < r2) return ButtonId::PLACE;
        if (d2(sw*0.94f, sh*0.78f) < r2) return ButtonId::BREAK;
        // Gear button: top-right 70x70 zone
        if (x > sw-70.f && y < 70.f)     return ButtonId::SETTINGS_PLUS;
    }
    return ButtonId::NONE;
}

void Input::onTouchDown(int id, float x, float y) {
    ButtonId btn = hitButton(x, y);
    switch (btn) {
        case ButtonId::JUMP:           jumpPressed    = true; return;
        case ButtonId::PLACE:          placePressed   = true; return;
        case ButtonId::BREAK:          breakPtrId     = id;   return;
        case ButtonId::SETTINGS_PLUS:  settingsPlusTap= true; return;
        default: break;
    }
    int slot = allocSlot(id, x, y);
    if (slot < 0) return;
    if (x < sw * 0.5f) { if (joyPtrIdx  < 0) joyPtrIdx  = slot; }
    else               { if (lookPtrIdx < 0) lookPtrIdx = slot; }
}

void Input::onTouchMove(int id, float x, float y) {
    int slot = findSlot(id);
    if (slot < 0) return;
    float prevX = ptrs[slot].currentX;
    float prevY = ptrs[slot].currentY;
    ptrs[slot].currentX = x;
    ptrs[slot].currentY = y;
    if (slot == lookPtrIdx) {
        // Clamp per-event delta to 80px to prevent giant jumps from stutter
        float dx = x - prevX, dy = y - prevY;
        if (dx >  80.f) dx =  80.f;
        if (dx < -80.f) dx = -80.f;
        if (dy >  80.f) dy =  80.f;
        if (dy < -80.f) dy = -80.f;
        lookDX += dx;
        lookDY += dy;
    }
}

void Input::onTouchUp(int id, float x, float y) {
    if (id == breakPtrId) breakPtrId = -1;
    freeSlot(id);
}

float Input::joyThumbX() const {
    if (joyPtrIdx < 0) return fixedJoyX;
    float dx=ptrs[joyPtrIdx].currentX-fixedJoyX, dy=ptrs[joyPtrIdx].currentY-fixedJoyY;
    float mag=sqrtf(dx*dx+dy*dy);
    if (mag > JOY_RADIUS) dx=dx/mag*JOY_RADIUS;
    return fixedJoyX+dx;
}
float Input::joyThumbY() const {
    if (joyPtrIdx < 0) return fixedJoyY;
    float dx=ptrs[joyPtrIdx].currentX-fixedJoyX, dy=ptrs[joyPtrIdx].currentY-fixedJoyY;
    float mag=sqrtf(dx*dx+dy*dy);
    if (mag > JOY_RADIUS) dy=dy/mag*JOY_RADIUS;
    return fixedJoyY+dy;
}

Vec3 Input::getMovement() const {
    if (joyPtrIdx < 0) return {0,0,0};
    float dx=(joyThumbX()-fixedJoyX)/JOY_RADIUS;
    float dz=(joyThumbY()-fixedJoyY)/JOY_RADIUS;
    float mag=sqrtf(dx*dx+dz*dz);
    if (mag>1.f){dx/=mag;dz/=mag;}
    return {dx,0,dz};
}

float Input::consumeDX() { float v=lookDX; lookDX=0; return v; }
float Input::consumeDY() { float v=lookDY; lookDY=0; return v; }
