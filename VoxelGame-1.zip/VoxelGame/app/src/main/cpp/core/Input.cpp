#include "Input.h"
#include <cmath>
#include <cstring>

void Input::setScreenSize(float w, float h) {
    sw = w; sh = h;
}

// ── Slot management ───────────────────────────────────────────────────────────
int Input::findSlot(int id) const {
    for (int i=0;i<MAX_TOUCH;i++)
        if (ptrs[i].active && ptrs[i].id==id) return i;
    return -1;
}

int Input::allocSlot(int id, float x, float y) {
    for (int i=0;i<MAX_TOUCH;i++) {
        if (!ptrs[i].active) {
            ptrs[i] = {id, x, y, x, y, true};
            return i;
        }
    }
    return -1; // all slots full
}

void Input::freeSlot(int id) {
    int i = findSlot(id);
    if (i<0) return;
    if (i==joyPtrIdx)  joyPtrIdx  = -1;
    if (i==lookPtrIdx) lookPtrIdx = -1;
    ptrs[i].active = false;
}

// ── Button hit-test ───────────────────────────────────────────────────────────
ButtonId Input::hitButton(float x, float y) const {
    float bx = sw*0.88f, by = sh*0.75f;
    auto dist2 = [&](float cx, float cy) {
        float dx=x-cx, dy=y-cy; return dx*dx+dy*dy;
    };
    float r2 = BTN_RADIUS * BTN_RADIUS;
    if (dist2(bx,       by-100.f) < r2) return ButtonId::JUMP;
    if (dist2(bx-100.f, by      ) < r2) return ButtonId::PLACE;
    if (dist2(bx+100.f, by      ) < r2) return ButtonId::BREAK;
    return ButtonId::NONE;
}

// ── Touch events ─────────────────────────────────────────────────────────────
void Input::onTouchDown(int id, float x, float y) {
    // Check buttons first (right side only)
    if (x > sw * 0.5f) {
        ButtonId btn = hitButton(x, y);
        if (btn == ButtonId::JUMP)  { jumpPressed  = true; return; }
        if (btn == ButtonId::PLACE) { placePressed = true; return; }
        if (btn == ButtonId::BREAK) { breakPressed = true; return; }
    }

    int slot = allocSlot(id, x, y);
    if (slot < 0) return;

    if (x < sw * 0.5f) {
        // Left side → joystick
        if (joyPtrIdx < 0) joyPtrIdx = slot;
    } else {
        // Right side (non-button) → look
        if (lookPtrIdx < 0) lookPtrIdx = slot;
    }
}

void Input::onTouchMove(int id, float x, float y) {
    int slot = findSlot(id);
    if (slot < 0) return;

    float prevX = ptrs[slot].currentX;
    float prevY = ptrs[slot].currentY;
    ptrs[slot].currentX = x;
    ptrs[slot].currentY = y;

    if (slot == lookPtrIdx) {
        lookDX += x - prevX;
        lookDY += y - prevY;
    }
}

void Input::onTouchUp(int id, float x, float y) {
    freeSlot(id);
}

// ── Queries ───────────────────────────────────────────────────────────────────
Vec3 Input::getMovement() const {
    if (joyPtrIdx < 0) return {0,0,0};
    const auto& p = ptrs[joyPtrIdx];
    float dx = (p.currentX - p.startX) / JOY_RADIUS;
    float dz = (p.currentY - p.startY) / JOY_RADIUS;
    // Clamp to unit circle
    float mag = sqrtf(dx*dx+dz*dz);
    if (mag > 1.f) { dx/=mag; dz/=mag; }
    return {dx, 0, dz};
}

float Input::consumeDX() { float v=lookDX; lookDX=0; return v; }
float Input::consumeDY() { float v=lookDY; lookDY=0; return v; }
