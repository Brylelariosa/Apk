package com.voxel.game;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.Log;
import android.widget.Toast;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {

    private static final String TAG = "VoxelRenderer";

    static {
        try {
            System.loadLibrary("voxelgame");
            Log.i(TAG, "Native library loaded OK");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "FAILED to load native library: " + e.getMessage());
            // Can't show a dialog here (no Activity context yet), but we log it.
        }
    }

    // ── Native methods ────────────────────────────────────────────────────────
    /** Must be called before GL surface is created. Returns previous crash report or "". */
    private native String nativeSetup(String filesDir);
    private native void nativeInit();
    private native void nativeResize(int width, int height);
    private native void nativeRender();
    private native void   nativeTouchDown(int id, float x, float y);
    private native void   nativeTouchMove(int id, float x, float y);
    private native void   nativeTouchUp  (int id, float x, float y);
    public  native String nativeGetDebugLog();
    public  native void   nativeFlushDebugLog();

    // ── State ─────────────────────────────────────────────────────────────────
    private final Context context;
    private String lastCrashReport = null;

    public GameRenderer(Context ctx, String filesDir) {
        this.context = ctx;
        try {
            String report = nativeSetup(filesDir);
            if (report != null && !report.isEmpty()) {
                lastCrashReport = report;
                Log.e(TAG, "Previous crash report loaded:\n" + report);
            }
        } catch (UnsatisfiedLinkError e) {
            lastCrashReport = "Library load failed:\n" + e.getMessage()
                + "\n\nThe .so file could not be loaded."
                + "\nThis usually means the APK was built for a different ABI than your device."
                + "\nYour device ABI: " + System.getProperty("os.arch");
            Log.e(TAG, lastCrashReport);
        }
    }

    /** Call from Activity after creation to show any pending crash dialog. */
    public void showPendingCrashDialog() {
        if (lastCrashReport == null || lastCrashReport.isEmpty()) return;
        final String report = lastCrashReport;
        lastCrashReport = null;

        if (context instanceof android.app.Activity) {
            ((android.app.Activity) context).runOnUiThread(() -> {
                new AlertDialog.Builder(context)
                    .setTitle("⚠️ Previous Crash Report")
                    .setMessage(report)
                    .setPositiveButton("Copy & Close", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager)
                            context.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("crash", report));
                        Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Dismiss", null)
                    .setCancelable(false)
                    .show();
            });
        }
    }

    // ── GLSurfaceView.Renderer ────────────────────────────────────────────────
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        Log.i(TAG, "onSurfaceCreated");
        nativeInit();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        Log.i(TAG, "onSurfaceChanged " + width + "x" + height);
        nativeResize(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        nativeRender();
        // Check if user tapped COPY DEBUG in settings panel
        String pending = nativeGetPendingDebugCopy();
        if (pending != null && !pending.isEmpty()) {
            final String log = pending;
            if (context instanceof android.app.Activity) {
                ((android.app.Activity) context).runOnUiThread(() -> {
                    android.content.ClipboardManager cm =
                        (android.content.ClipboardManager)
                        ((android.app.Activity) context).getSystemService(
                            android.content.Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("VoxelDebug", log));
                    android.widget.Toast.makeText(context,
                        "Debug log copied! (" + log.length() + " chars)",
                        android.widget.Toast.LENGTH_SHORT).show();
                });
            }
        }
    }

    // ── Touch forwarding ──────────────────────────────────────────────────────
    public void touchDown(int id, float x, float y) { nativeTouchDown(id, x, y); }
    public void touchMove(int id, float x, float y) { nativeTouchMove(id, x, y); }
    public void touchUp  (int id, float x, float y) { nativeTouchUp  (id, x, y); }
}
