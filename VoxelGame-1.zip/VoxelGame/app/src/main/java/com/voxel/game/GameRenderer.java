package com.voxel.game;

import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameRenderer implements GLSurfaceView.Renderer {
    static {
        System.loadLibrary("voxelgame");
    }

    private native void nativeInit();
    private native void nativeResize(int width, int height);
    private native void nativeRender();
    private native void nativeTouchDown(int id, float x, float y);
    private native void nativeTouchMove(int id, float x, float y);
    private native void nativeTouchUp(int id, float x, float y);

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        nativeInit();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        nativeResize(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        nativeRender();
    }

    public void touchDown(int id, float x, float y) { nativeTouchDown(id, x, y); }
    public void touchMove(int id, float x, float y) { nativeTouchMove(id, x, y); }
    public void touchUp(int id, float x, float y)   { nativeTouchUp(id, x, y); }
}
