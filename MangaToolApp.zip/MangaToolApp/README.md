# Manga Tool — Android APK Builder

Build the APK **free in the cloud** using GitHub. No Android Studio needed.

---

## How to Get Your APK (5 steps, ~5 minutes)

### Step 1 — Create a free GitHub account
Go to https://github.com and sign up (it is free)

### Step 2 — Create a new repository
1. Click the + button top right → New repository
2. Name it anything e.g. manga-tool
3. Click Create repository

### Step 3 — Upload these files
1. On your new repo page click "uploading an existing file"
2. Drag ALL files and folders from this zip into the upload box
3. Click Commit changes

### Step 4 — Watch it build
1. Click the Actions tab at the top
2. You will see "Build APK" running (yellow circle = building, ~3 mins)
3. Wait for the green checkmark

### Step 5 — Download your APK
1. Click the finished green build
2. Scroll to the bottom → Artifacts → click MangaTool-APK
3. Unzip the download → inside is app-debug.apk

---

## Install on Your Phone
1. Copy app-debug.apk to your Android phone
2. Tap it to install
3. If blocked: Settings → Install unknown apps → Allow

---

## App Features
- Tap to pick .mhtml or image files
- Extracts images in the background (no freezing)
- ZIP saves to your Downloads folder
- Dark mode, image viewer, merge mode all work
- Fully offline, no internet needed
- Works on Android 7.0 and higher
