package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.OutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // File chooser launcher
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results: Array<Uri>? = when {
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { data.clipData!!.getItemAt(it).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    // Storage permission launcher (for Android < 10)
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            Toast.makeText(this, "Storage permission needed to save files", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        setupWebView()

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false

        // Enable hardware acceleration for better performance
        webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)

        // Add JS interface for download handling
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                // Inject download interceptor after page loads
                injectDownloadInterceptor()
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                // Let the WebView handle file:// and about: URLs
                if (url.startsWith("file://") || url.startsWith("about:")) {
                    return false
                }
                // Open external URLs in browser
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val intent = fileChooserParams.createIntent().apply {
                    // Allow multiple files
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "multipart/related",
                        "message/rfc822",
                        "application/octet-stream",
                        "image/jpeg",
                        "image/png",
                        "image/webp"
                    ))
                }
                fileChooserLauncher.launch(intent)
                return true
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                // Log JS console messages for debugging
                android.util.Log.d("MangaTool-JS",
                    "${consoleMessage.message()} -- From line ${consoleMessage.lineNumber()} of ${consoleMessage.sourceId()}")
                return true
            }
        }

        // Handle blob URL downloads
        webView.setDownloadListener { url, _, _, mimeType, _ ->
            if (url.startsWith("blob:")) {
                // Use JS bridge to fetch blob data
                webView.evaluateJavascript("""
                    (function() {
                        fetch('$url')
                            .then(r => r.blob())
                            .then(blob => {
                                const reader = new FileReader();
                                reader.onloadend = function() {
                                    const base64 = reader.result.split(',')[1];
                                    AndroidBridge.onBlobReady(base64, blob.type, 'download.zip');
                                };
                                reader.readAsDataURL(blob);
                            });
                    })();
                """.trimIndent(), null)
            }
        }
    }

    private fun injectDownloadInterceptor() {
        // Override the downloadBlob function to use our Android bridge instead
        webView.evaluateJavascript("""
            (function() {
                // Override the download function used by the app
                var _originalDownloadBlob = window.downloadBlob;
                
                // Patch downloadBlob if it exists globally, or intercept anchor clicks
                function patchDownloadBlob() {
                    if (typeof downloadBlob === 'function') {
                        window.__originalDownloadBlob = downloadBlob;
                    }
                }
                
                // Intercept all <a download> clicks  
                document.addEventListener('click', function(e) {
                    var el = e.target;
                    // Walk up to find anchor element
                    while (el && el.tagName !== 'A') el = el.parentElement;
                    if (el && el.hasAttribute('download') && el.href && el.href.startsWith('blob:')) {
                        e.preventDefault();
                        e.stopPropagation();
                        var blobUrl = el.href;
                        var filename = el.getAttribute('download') || 'download.zip';
                        fetch(blobUrl).then(function(r) { return r.blob(); }).then(function(blob) {
                            var reader = new FileReader();
                            reader.onloadend = function() {
                                var base64 = reader.result.split(',')[1];
                                AndroidBridge.onBlobReady(base64, blob.type, filename);
                            };
                            reader.readAsDataURL(blob);
                        });
                    }
                }, true);
                
                console.log('Android download interceptor installed');
            })();
        """.trimIndent(), null)
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun onBlobReady(base64Data: String, mimeType: String, filename: String) {
            // Request permission if needed (Android < 10)
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                if (ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    runOnUiThread {
                        Toast.makeText(this@MainActivity,
                            "Please grant storage permission and try again",
                            Toast.LENGTH_LONG).show()
                    }
                    return
                }
            }

            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val savedFilename = if (filename.isNotEmpty()) filename else "MangaTool_output.zip"

                val outputStream: OutputStream?
                val savedUri: Uri?

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Android 10+ — use MediaStore Downloads
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, savedFilename)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifEmpty { "application/zip" })
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val resolver = contentResolver
                    savedUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                    outputStream = savedUri?.let { resolver.openOutputStream(it) }
                    outputStream?.use { it.write(bytes) }

                    // Mark as complete
                    contentValues.clear()
                    contentValues.put(MediaStore.Downloads.IS_PENDING, 0)
                    savedUri?.let { resolver.update(it, contentValues, null, null) }
                } else {
                    // Android 9 and below — write to Downloads folder directly
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                    )
                    downloadsDir.mkdirs()
                    val file = java.io.File(downloadsDir, savedFilename)
                    file.outputStream().use { it.write(bytes) }
                    savedUri = Uri.fromFile(file)
                }

                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "✅ Saved to Downloads: $savedFilename",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this@MainActivity,
                        "❌ Save failed: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                android.util.Log.e("MangaTool", "Download error", e)
            }
        }

        @JavascriptInterface
        fun showToast(message: String) {
            runOnUiThread {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
