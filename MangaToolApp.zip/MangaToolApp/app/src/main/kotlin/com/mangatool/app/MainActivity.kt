package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results: Array<Uri>? = when {
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { data.clipData!!.getItemAt(it).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, "Storage permission needed to save files", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)
        setupWebView()
        webView.loadUrl("file:///android_asset/index.html")
    }

    fun launchFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "multipart/related", "message/rfc822",
                "application/octet-stream", "image/jpeg", "image/png", "image/webp"
            ))
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        fileChooserLauncher.launch(Intent.createChooser(intent, "Select MHTML or Images"))
    }

    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true
        settings.databaseEnabled = true
        webView.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                injectDownloadInterceptor()
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file://") || url.startsWith("about:")) return false
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                launchFilePicker()
                return true
            }
            override fun onConsoleMessage(msg: ConsoleMessage): Boolean {
                android.util.Log.d("MangaTool-JS", "${msg.message()} -- line ${msg.lineNumber()}")
                return true
            }
        }

        webView.setDownloadListener { url, _, _, mimeType, _ ->
            if (url.startsWith("blob:")) {
                webView.evaluateJavascript("""
                    (function(){fetch('$url').then(r=>r.blob()).then(blob=>{
                        var rd=new FileReader();
                        rd.onloadend=function(){AndroidBridge.onBlobReady(rd.result.split(',')[1],blob.type,'Manga_Batch.cbz');};
                        rd.readAsDataURL(blob);
                    });})();
                """.trimIndent(), null)
            }
        }
    }

    private fun injectDownloadInterceptor() {
        webView.evaluateJavascript("""
            (function(){
                document.addEventListener('click',function(e){
                    var el=e.target;
                    while(el&&el.tagName!=='A') el=el.parentElement;
                    if(el&&el.hasAttribute('download')&&el.href&&el.href.startsWith('blob:')){
                        e.preventDefault(); e.stopPropagation();
                        var fn=el.getAttribute('download')||'Manga_Batch.cbz';
                        fetch(el.href).then(function(r){return r.blob();}).then(function(blob){
                            var rd=new FileReader();
                            rd.onloadend=function(){AndroidBridge.onBlobReady(rd.result.split(',')[1],blob.type,fn);};
                            rd.readAsDataURL(blob);
                        });
                    }
                },true);
            })();
        """.trimIndent(), null)
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun openFilePicker() {
            // Called from JS drop zone / Add More button
            runOnUiThread {
                // Inject a fake file input click so WebChromeClient.onShowFileChooser fires
                // giving us a proper ValueCallback to fulfil
                webView.evaluateJavascript(
                    "(function(){ document.getElementById('file-input').click(); })();", null
                )
            }
        }

        @JavascriptInterface
        fun onBlobReady(base64Data: String, mimeType: String, filename: String) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                if (ContextCompat.checkSelfPermission(this@MainActivity,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    runOnUiThread { Toast.makeText(this@MainActivity, "Grant storage permission and try again", Toast.LENGTH_LONG).show() }
                    return
                }
            }
            try {
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val name = filename.ifEmpty { "MangaTool_output.cbz" }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, name)
                        put(MediaStore.Downloads.MIME_TYPE, mimeType.ifEmpty { "application/zip" })
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    uri?.let { contentResolver.openOutputStream(it) }?.use { it.write(bytes) }
                    cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
                    uri?.let { contentResolver.update(it, cv, null, null) }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    dir.mkdirs()
                    java.io.File(dir, name).outputStream().use { it.write(bytes) }
                }
                runOnUiThread { Toast.makeText(this@MainActivity, "✅ Saved to Downloads: $name", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "❌ Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }

        @JavascriptInterface
        fun showToast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
