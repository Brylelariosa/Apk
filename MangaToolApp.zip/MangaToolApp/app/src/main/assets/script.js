// --- MAIN THREAD ---
let currentMode = 'extract';
let rawGroups = []; 
let activeUrls = []; 
let worker = null;
let processingQueue = [];
let queueIndex = 0;
let looseImagesBuffer = [];
let dataTransferred = false;
let corruptCount = 0; 

// Selection Mode State
let isSelectMode = false;
let selectedItems = new Set();

// Modal State
let currentModalImage = null; 
let currentModalGroup = null;
let currentModalList = []; 
let currentModalIndex = -1; 

const els = {
    drop: document.getElementById('drop-zone'),
    input: document.getElementById('file-input'),
    progress: document.getElementById('progress-area'),
    bar: document.getElementById('progress-bar'),
    status: document.getElementById('status-text'),
    percent: document.getElementById('percent-text'),
    list: document.getElementById('chapter-list'),
    
    // Action Bars
    actionBar: document.getElementById('action-bar'),
    selectionBar: document.getElementById('selection-bar'),
    selectCount: document.getElementById('select-count'),
    badge: document.getElementById('img-count-badge'),
    
    canvas: document.getElementById('merge-canvas'),
    settingsExtract: document.getElementById('settings-extract'),
    settingsMerge: document.getElementById('settings-merge'),
    
    // Buttons
    downloadBtn: document.getElementById('download-btn'),
    addMoreBtn: document.getElementById('add-more-btn'),
    selectModeBtn: document.getElementById('select-mode-btn'),
    deleteSelectedBtn: document.getElementById('delete-selected-btn'),
    cancelSelectBtn: document.getElementById('cancel-select-btn'),
    
    // Modal
    modal: document.getElementById('img-modal'),
    modalImg: document.getElementById('modal-img'),
    modalActions: document.getElementById('modal-actions'),
    modalReason: document.getElementById('modal-reason'),
    modalRestoreBtn: document.getElementById('modal-restore-btn'),
    modalDeleteBtn: document.getElementById('modal-delete-btn'),

    // Settings
    sizeFilter: document.getElementById('size-filter'),
    noGifs: document.getElementById('no-gifs'),
    reverse: document.getElementById('reverse-sort')
};

if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(err => console.error("SW Fail:", err));
}

function init() {
    try {
        // Inline worker as Blob so it works with file:// URLs on Android WebView
        const workerCode = `self.onmessage = function(e) {
    const { type } = e.data;
    if (type === 'extractOne') extractSingleMhtml(e.data);
    if (type === 'zip') createZip(e.data);
};

// --- HELPER: Find a byte sequence in a Uint8Array ---
function findSequence(buffer, sequence, fromIndex) {
    for (let i = fromIndex; i < buffer.length; i++) {
        if (buffer[i] === sequence[0]) {
            let match = true;
            for (let j = 1; j < sequence.length; j++) {
                if (buffer[i + j] !== sequence[j]) {
                    match = false;
                    break;
                }
            }
            if (match) return i;
        }
    }
    return -1;
}

function decodeQuotedPrintable(str) {
    return str.replace(/=[\\r\\n]+/g, "").replace(/=[0-9A-F]{2}/gi, function(v){
        return String.fromCharCode(parseInt(v.substr(1), 16));
    });
}

function extractSingleMhtml({ buffer, filename }) {
    try {
        const data = new Uint8Array(buffer);
        const decoder = new TextDecoder("utf-8");
        const encoder = new TextEncoder();
        let extracted = [];

        // 1. BOUNDARY DETECTION (Scan only the first 4KB to save memory)
        const headerText = decoder.decode(data.slice(0, 4096));
        let boundaryString = null;
        
        const bMatch = headerText.match(/boundary="?([^";\\s]+)"?/i);
        if (bMatch) boundaryString = bMatch[1];
        else {
            const match = headerText.match(/^--[a-fA-F0-9\\-]+(\\r?\\n|$)/m);
            if(match) boundaryString = match[0].trim().replace(/^--/, '');
        }

        if (!boundaryString) throw new Error("No boundary found");

        // Convert boundary to bytes for binary search
        const boundaryBytes = encoder.encode("--" + boundaryString);
        
        // 2. BINARY PARSING LOOP
        let currentIndex = 0;
        let partIdx = 0;

        while (currentIndex < data.length) {
            // Find start of next boundary
            const boundaryIndex = findSequence(data, boundaryBytes, currentIndex);
            if (boundaryIndex === -1) break; // No more parts

            // If we have a previous start, the data is between \`currentIndex\` and \`boundaryIndex\`
            if (currentIndex > 0) {
                // This chunk contains Headers + \\r\\n\\r\\n + Body
                const chunkStart = currentIndex;
                const chunkEnd = boundaryIndex;
                
                // Search for Header/Body separator (\\r\\n\\r\\n or \\n\\n) within this chunk
                // We limit header search to first 2KB of the chunk to avoid scanning the whole image
                const maxHeaderCheck = Math.min(chunkEnd, chunkStart + 2048);
                let bodyStart = -1;
                
                // Look for \\r\\n\\r\\n (13, 10, 13, 10)
                const dblCrLf = findSequence(data.subarray(chunkStart, maxHeaderCheck), new Uint8Array([13,10,13,10]), 0);
                if (dblCrLf !== -1) bodyStart = chunkStart + dblCrLf + 4;
                else {
                    // Fallback: Look for \\n\\n (10, 10)
                    const dblLf = findSequence(data.subarray(chunkStart, maxHeaderCheck), new Uint8Array([10,10]), 0);
                    if (dblLf !== -1) bodyStart = chunkStart + dblLf + 2;
                }

                if (bodyStart !== -1 && bodyStart < chunkEnd) {
                    // Decode Headers ONLY
                    const headers = decoder.decode(data.subarray(chunkStart, bodyStart));
                    const typeMatch = headers.match(/Content-Type:\\s*image\\/(jpeg|png|gif|webp)/i);
                    const encodingMatch = headers.match(/Content-Transfer-Encoding:\\s*(base64|quoted-printable)/i);

                    if (typeMatch) {
                        const ext = typeMatch[1] === 'jpeg' ? 'jpg' : typeMatch[1];
                        const rawBody = data.subarray(bodyStart, chunkEnd);
                        
                        let finalBytes;

                        // Handle Encoding
                        if (encodingMatch) {
                            const enc = encodingMatch[1].toLowerCase();
                            if (enc === 'base64') {
                                const b64Str = decoder.decode(rawBody).replace(/[\\r\\n\\t\\s]+/g, "");
                                const bin = atob(b64Str);
                                finalBytes = new Uint8Array(bin.length);
                                for (let i = 0; i < bin.length; i++) finalBytes[i] = bin.charCodeAt(i);
                            } else if (enc === 'quoted-printable') {
                                const qpStr = decoder.decode(rawBody);
                                const clean = decodeQuotedPrintable(qpStr);
                                finalBytes = new Uint8Array(clean.length);
                                for (let i = 0; i < clean.length; i++) finalBytes[i] = clean.charCodeAt(i);
                            }
                        } 
                        
                        // If no encoding (binary), use raw bytes directly
                        if (!finalBytes) {
                             finalBytes = rawBody.slice(); 
                        }

                        if (finalBytes && finalBytes.length > 100) {
                             extracted.push({ 
                                 sortKey: String(partIdx).padStart(8, '0'), 
                                 data: finalBytes, 
                                 ext, 
                                 size: finalBytes.length 
                             });
                        }
                    }
                }
            }
            
            partIdx++;
            // Move index past the current boundary
            currentIndex = boundaryIndex + boundaryBytes.length;
        }

        // --- 3. SMART NATURAL SORTING ---
        extracted.sort((a, b) => {
            return a.sortKey.localeCompare(b.sortKey, undefined, { numeric: true, sensitivity: 'base' });
        });

        const finalImages = extracted.map((item, i) => ({ 
            originalIdx: i,
            data: item.data, 
            ext: item.ext, 
            size: item.size 
        }));

        // --- 4. SMART RENAME LOGIC (Updated for Padding) ---
        let baseName = filename.replace(/\\.mhtml?/i, "");
        baseName = baseName.replace(/_/g, " "); 
        baseName = baseName.replace(/\\+/g, " "); 
        baseName = baseName.replace(/\\[.*?\\]|\\(.*?\\)/g, ""); 
        baseName = baseName.replace(/\\b(read manga online|read online|manga)\\b/gi, ""); 
        baseName = baseName.replace(/\\s+/g, " ").trim(); 

        const nameMatch = baseName.match(/^(.*?)(\\b(?:chapter|ch\\.?|no\\.?|c\\.?|vol\\.?|volume|#)\\s*[\\d\\.]+|\\b\\d+)(.*)$/i);
        
        if (nameMatch) {
            const prefix = nameMatch[1].trim();
            let numberPart = nameMatch[2].trim();
            const suffix = nameMatch[3].trim();

            // --- PADDING MODIFICATION ---
            // Finds the digit sequence inside "Chapter 1" or "Vol 5" and pads it.
            // "Chapter 1" -> "Chapter 001"
            // "5" -> "005"
            // "1110" -> "1110" (ignores because it's already long enough)
            numberPart = numberPart.replace(/(\\d+)/, (match) => {
                return match.padStart(3, '0');
            });
            // ----------------------------

            const cleanPrefix = prefix.replace(/[-_]$/, "").trim();
            
            if(cleanPrefix) {
                baseName = \`\${numberPart} - \${cleanPrefix} \${suffix}\`.trim();
            } else {
                baseName = \`\${numberPart} \${suffix}\`.trim();
            }
        }

        baseName = baseName.replace(/\\s+-\\s*$/, "").replace(/\\s+/g, " ").trim();

        const group = finalImages.length > 0 ? { groupName: baseName, allImages: finalImages } : null;
        self.postMessage({ type: 'extractDone', group: group });
        
    } catch(e) {
        console.error(e);
        self.postMessage({ type: 'status', text: "Error parsing file", percent: 0 });
    }
}

// 5. ASYNC ZIP CREATION
async function createZip({ groups, extType }) {
    try {
        const crcTable = new Int32Array(256);
        for(let i=0; i<256; i++){let c=i; for(let k=0; k<8; k++) c=((c&1)?(0xEDB88320^(c>>>1)):(c>>>1)); crcTable[i]=c;}
        const crc32 = d => {let c=-1; for(let i=0;i<d.length;i++) c=(c>>>8)^crcTable[(c^d[i])&0xFF]; return (c^-1)>>>0;};

        const parts = [], cd = []; 
        let offset = 0; 
        const enc = new TextEncoder();

        let totalFiles = 0;
        groups.forEach(g => totalFiles += g.images.length);
        let processed = 0;

        if (totalFiles === 0) throw new Error("No images to zip");

        for(const group of groups) {
            // Ensure folder name is safe
            const cleanGroupName = group.groupName.replace(/[\\\\/:*?"<>|]/g, "_");
            const folderName = cleanGroupName + "/";

            for(const img of group.images) {
                processed++;

                if(processed % 20 === 0) {
                     self.postMessage({ type: 'status', text: "Compressing...", percent: (processed/totalFiles)*100 });
                     await new Promise(r => setTimeout(r, 5)); 
                }

                const path = folderName + img.name;
                const n = enc.encode(path); 
                const cr = crc32(img.data);

                const h = new Uint8Array(30+n.length); const v=new DataView(h.buffer);
                v.setUint32(0,0x04034b50,true); v.setUint16(4,10,true); v.setUint16(6,0,true); v.setUint16(8,0,true);
                v.setUint32(14,cr,true); v.setUint32(18,img.data.length,true); v.setUint32(22,img.data.length,true);
                v.setUint16(26,n.length,true); v.setUint16(28,0,true); h.set(n,30); 

                parts.push(h); parts.push(img.data);

                const c = new Uint8Array(46+n.length); const cv=new DataView(c.buffer);
                cv.setUint32(0,0x02014b50,true); cv.setUint16(4,10,true); cv.setUint16(6,10,true);
                cv.setUint16(8,0,true); cv.setUint16(10,0,true); cv.setUint32(16,cr,true);
                cv.setUint32(20,img.data.length,true); cv.setUint32(24,img.data.length,true);
                cv.setUint16(28,n.length,true); cv.setUint16(30,0,true); cv.setUint16(32,0,true);
                cv.setUint32(42,offset,true); c.set(n,46); 

                cd.push(c); offset += h.length + img.data.length;
            }
        }

        const cdLen = cd.reduce((a,c)=>a+c.length,0);
        const eocd = new Uint8Array(22); const ev=new DataView(eocd.buffer);
        ev.setUint32(0,0x06054b50,true); ev.setUint16(8,processed,true);
        ev.setUint16(10,processed,true); ev.setUint32(12,cdLen,true); ev.setUint32(16,offset,true);

        const blob = new Blob([...parts, ...cd, eocd], {type: 'application/zip'});
        self.postMessage({ type: 'zipDone', blob, filename: \`Manga_Batch.\${extType}\` });

    } catch(err) {
        self.postMessage({ type: 'error', text: err.message });
    }
    }
`;
        // Use data: URL instead of blob: URL — Android WebView blocks blob: workers
        const workerUrl = 'data:application/javascript;charset=utf-8,' + encodeURIComponent(workerCode);
        worker = new Worker(workerUrl);
        worker.onmessage = handleWorkerMsg;
        worker.onerror = (e) => {
            alert("Worker Failed: " + (e.message || "Unknown error"));
            els.downloadBtn.disabled = false;
            els.progress.style.display = 'none';
        };
    } catch (err) { alert("Could not start worker: " + err.message); }
    loadConfig();
}

function loadConfig() {
    const saved = JSON.parse(localStorage.getItem('manga-tool-cfg') || '{}');
    if(saved.minSize) els.sizeFilter.value = saved.minSize;
    if(saved.noGifs !== undefined) els.noGifs.checked = saved.noGifs;
    if(saved.reverse !== undefined) els.reverse.checked = saved.reverse;
    if(saved.rtl !== undefined) document.getElementById('rtl-mode').checked = saved.rtl;
    if(saved.theme) document.documentElement.setAttribute('data-theme', saved.theme);
    updateSizeLabel();
}

window.saveConfig = function() {
    localStorage.setItem('manga-tool-cfg', JSON.stringify({
        minSize: els.sizeFilter.value,
        noGifs: els.noGifs.checked,
        reverse: els.reverse.checked,
        rtl: document.getElementById('rtl-mode').checked,
        theme: document.documentElement.getAttribute('data-theme')
    }));
    updateSizeLabel();
};

window.triggerRefilter = function() {
    if(dataTransferred) return;
    saveConfig();
    applyFiltersToAll();
    clearAndRender();
};

function updateSizeLabel() { document.getElementById('size-val').innerText = els.sizeFilter.value + " KB"; }

// --- FILE HANDLING ---
els.drop.onclick = () => els.input.click();
els.addMoreBtn.onclick = () => { if(!dataTransferred) els.input.click(); };
els.input.onchange = () => { if(els.input.files.length) handleFiles(els.input.files); els.input.value = ''; };

els.drop.ondragover = (e) => { e.preventDefault(); els.drop.style.borderColor = 'var(--primary)'; };
els.drop.ondragleave = (e) => { e.preventDefault(); els.drop.style.borderColor = 'var(--drop-border)'; };
els.drop.ondrop = (e) => { e.preventDefault(); els.drop.style.borderColor = 'var(--drop-border)'; if(e.dataTransfer.files.length) handleFiles(e.dataTransfer.files); };

async function handleFiles(files) {
    if(dataTransferred) { if(confirm("Reload to process new files?")) location.reload(); return; }
    if(isSelectMode) els.cancelSelectBtn.click(); // Reset selection mode if dragging new files
    
    resetCorruptState();
    els.drop.style.display = 'none';
    els.progress.style.display = 'block';
    els.actionBar.style.display = 'none';
    processingQueue = Array.from(files); 
    queueIndex = 0;
    looseImagesBuffer = [];
    processNextFile();
}

async function processNextFile() {
    if (queueIndex >= processingQueue.length) {
        if (looseImagesBuffer.length > 0) {
            const looseCandidates = looseImagesBuffer.map((img, i) => ({ originalIdx: i, data: img.data, ext: img.ext, size: img.data.length }));
            rawGroups.push({ groupName: "Loose Images " + (rawGroups.length+1), allImages: looseCandidates });
        }
        finishProcessing();
        return;
    }

    const file = processingQueue[queueIndex];
    const pct = Math.round((queueIndex / processingQueue.length) * 100);
    updateProgress(`Reading ${queueIndex + 1}/${processingQueue.length}: ${file.name}`, pct);

    const name = file.name.toLowerCase();
    if (name.endsWith('.mhtml') || name.endsWith('.mht')) {
        try {
            const buf = await file.arrayBuffer();
            worker.postMessage({ type: 'extractOne', buffer: buf, filename: file.name }, [buf]); 
        } catch (err) { queueIndex++; processNextFile(); }
    } else if (name.match(/\.(jpg|jpeg|png|webp)$/)) {
        try {
            const buf = await file.arrayBuffer();
            looseImagesBuffer.push({ name: file.name, data: new Uint8Array(buf), ext: name.split('.').pop() });
        } catch (e) {}
        queueIndex++; processNextFile(); 
    } else { queueIndex++; processNextFile(); }
}

function handleWorkerMsg(e) {
    const { type, text, percent, group, blob, filename } = e.data;
    if(type === 'status') { updateProgress(text, percent); }
    else if(type === 'error') {
        alert("Worker Error: " + text);
        els.downloadBtn.disabled = false;
        els.progress.style.display = 'none';
    }
    else if (type === 'extractDone') {
        if (group) rawGroups.push(group);
        queueIndex++; processNextFile();
    }
    else if (type === 'zipDone') {
        downloadBlob(blob, filename);
        els.downloadBtn.disabled = true;
        els.downloadBtn.innerText = "Complete! (Reload to start over)";
        updateProgress("Download Ready", 100);
        dataTransferred = true;
        document.querySelectorAll('.chapter-item').forEach(el => el.style.opacity = '0.5');
    }
}

function updateProgress(text, pct) { els.status.innerText = text; els.bar.style.width = pct + "%"; els.percent.innerText = Math.round(pct) + "%"; }

function finishProcessing() {
    els.progress.style.display = 'none';
    els.actionBar.style.display = 'flex';
    applyFiltersToAll();
    clearAndRender();
}

// --- FILTERING LOGIC ---
function applyFiltersToAll() {
    const minSize = parseInt(els.sizeFilter.value) * 1024;
    const noGifs = els.noGifs.checked;
    const reverse = els.reverse.checked;

    rawGroups.forEach(group => {
        const valid = [];
        const filtered = [];

        group.allImages.forEach(img => {
            let reason = null;
            if (img.userDeleted) reason = "Manually Deleted";
            else if (img.forceKeep) reason = null; 
            else {
                if (img.size < minSize) reason = `Too Small (${Math.round(img.size/1024)}KB)`;
                else if (noGifs && img.ext.toLowerCase() === 'gif') reason = "GIF Excluded";
            }

            if (reason) filtered.push({ ...img, reason });
            else valid.push(img);
        });

        if (reverse) valid.reverse();
        group.displayImages = valid.map((img, i) => ({ ...img, name: `${String(i+1).padStart(3, '0')}.${img.ext}` }));
        group.filteredList = filtered;
    });
    updateBadge();
}

function updateBadge() {
    let totalImages = 0, totalSize = 0;
    rawGroups.forEach(g => { totalImages += g.displayImages.length; g.displayImages.forEach(img => totalSize += img.size); });
    els.badge.style.display = 'inline-block';
    els.badge.innerText = `${rawGroups.length} Files / ${totalImages} imgs`;
    if (!els.downloadBtn.disabled && !dataTransferred) { els.downloadBtn.innerText = `Download All (~${formatBytes(totalSize)})`; }
}

function formatBytes(bytes, decimals = 1) {
    if (!+bytes) return '0 B';
    const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(decimals < 0 ? 0 : decimals))} ${sizes[i]}`;
}

// --- RENDER LOGIC ---
function clearAndRender() {
    // Remember open chapters to restore them
    const expandedIndices = new Set();
    els.list.querySelectorAll('.chapter-item').forEach((item, idx) => {
        const body = item.querySelector('.chapter-body');
        if (body && body.classList.contains('expanded')) expandedIndices.add(idx);
    });

    els.list.innerHTML = '';
    rawGroups.forEach((group, idx) => {
        const item = document.createElement('div');
        item.className = 'chapter-item';
        
        const head = document.createElement('div');
        head.className = 'chapter-head';
        head.innerHTML = `<span>${group.groupName}</span> <span style="font-size:0.8em; color:var(--text-sub)">${group.displayImages.length} images</span>`;
        
        const removeBtn = document.createElement('span');
        removeBtn.innerHTML = " &times;";
        removeBtn.style.color = "var(--danger)";
        removeBtn.style.marginLeft = "10px";
        removeBtn.onclick = (e) => {
            e.stopPropagation();
            if(dataTransferred) return;
            rawGroups.splice(idx, 1);
            applyFiltersToAll(); 
            clearAndRender();
        };
        head.appendChild(removeBtn);

        const body = document.createElement('div');
        body.className = 'chapter-body';

        head.onclick = () => toggleChapter(body, group);
        item.appendChild(head);
        item.appendChild(body);

        els.list.appendChild(item);
        if (expandedIndices.has(idx)) toggleChapter(body, group); // Automatically reopen
    });
}

async function toggleChapter(container, group) {
    if (dataTransferred) return;
    if (container.classList.contains('expanded')) {
        container.classList.remove('expanded');
        container.innerHTML = ''; 
        return;
    }

    container.classList.add('expanded');
    container.innerHTML = '<div style="padding:10px; text-align:center">Generating previews...</div>';
    await new Promise(r => setTimeout(r, 10));

    const grid = document.createElement('div');
    grid.className = currentMode === 'extract' ? 'gallery-grid' : 'gallery-grid merge-mode';
    const isRTL = document.getElementById('rtl-mode').checked;

    const items = currentMode === 'extract' ? group.displayImages : pairImages(group.displayImages);
    const limit = Math.min(items.length, 40);

    for(let i=0; i<limit; i++) {
        let url; let context = null;
        if(currentMode === 'extract') {
            const img = items[i];
            url = URL.createObjectURL(new Blob([img.data], {type: 'image/'+img.ext}));
            context = { imgObject: group.allImages[img.originalIdx], group: group, isNormal: true };
        } else { url = await createMergedUrl(items[i], isRTL); }
        activeUrls.push(url);
        addToGrid(grid, url, currentMode !== 'extract', context);
    }

    if(items.length > limit) {
        const moreContainer = document.createElement('div');
        moreContainer.style.gridColumn = "1/-1";
        moreContainer.style.textAlign = "center";
        moreContainer.style.padding = "20px";

        const loadMoreBtn = document.createElement('button');
        loadMoreBtn.className = "btn btn-secondary"; 
        loadMoreBtn.innerText = `Load remaining ${items.length - limit} pages`;
        loadMoreBtn.style.width = "auto";
        
        loadMoreBtn.onclick = async () => {
            loadMoreBtn.innerText = "Loading..."; loadMoreBtn.disabled = true;
            await new Promise(r => setTimeout(r, 50));

            for(let i=limit; i<items.length; i++) {
                let url; let context = null;
                if(currentMode === 'extract') {
                    const img = items[i];
                    url = URL.createObjectURL(new Blob([img.data], {type: 'image/'+img.ext}));
                    context = { imgObject: group.allImages[img.originalIdx], group: group, isNormal: true };
                } else { url = await createMergedUrl(items[i], isRTL); }
                activeUrls.push(url);
                addToGrid(grid, url, currentMode !== 'extract', context);
            }
            moreContainer.remove(); 
        };
        moreContainer.appendChild(loadMoreBtn);
        grid.appendChild(moreContainer);
    }

    container.innerHTML = '';
    container.appendChild(grid);

    if (group.filteredList && group.filteredList.length > 0) {
        const filterSection = document.createElement('div');
        filterSection.className = 'filtered-section';
        const toggle = document.createElement('div');
        toggle.className = 'filtered-toggle';
        toggle.innerText = `⚠️ Show ${group.filteredList.length} filtered images`;
        const listGrid = document.createElement('div');
        listGrid.className = 'filtered-grid';
        listGrid.style.display = 'none';

        group.filteredList.forEach((f) => {
            const url = URL.createObjectURL(new Blob([f.data], {type: 'image/'+f.ext}));
            activeUrls.push(url);
            const div = document.createElement('div');
            div.className = 'filtered-item';
            div.innerHTML = `<img src="${url}" loading="lazy"><div class="filter-reason">${f.reason}</div>`;
            div.onclick = () => openModal(url, { imgObject: group.allImages[f.originalIdx], reason: f.reason, group: group, isNormal: false }, listGrid);
            listGrid.appendChild(div);
        });

        toggle.onclick = () => {
            const isHidden = listGrid.style.display === 'none';
            listGrid.style.display = isHidden ? 'grid' : 'none';
            toggle.innerText = isHidden ? `⚠️ Hide ${group.filteredList.length} filtered images` : `⚠️ Show ${group.filteredList.length} filtered images`;
        };
        filterSection.appendChild(toggle); filterSection.appendChild(listGrid); container.appendChild(filterSection);
    }
}

function pairImages(images) {
    const pairs = [];
    for(let i=0; i<images.length; i+=2) pairs.push(images.slice(i, i+2)); 
    return pairs;
}

// --- SELECT MODE LOGIC ---
els.selectModeBtn.onclick = () => {
    isSelectMode = true;
    selectedItems.clear();
    els.actionBar.style.display = 'none';
    els.selectionBar.style.display = 'flex';
    els.selectCount.innerText = "0 Selected";
};

els.cancelSelectBtn.onclick = () => {
    isSelectMode = false;
    selectedItems.clear();
    els.selectionBar.style.display = 'none';
    els.actionBar.style.display = 'flex';
    document.querySelectorAll('.gallery-item.selected').forEach(el => el.classList.remove('selected'));
};

els.deleteSelectedBtn.onclick = () => {
    if (selectedItems.size === 0) { els.cancelSelectBtn.click(); return; }
    selectedItems.forEach(imgObj => {
        imgObj.userDeleted = true;
        imgObj.forceKeep = false;
    });
    applyFiltersToAll();
    els.cancelSelectBtn.click(); // Turns off select mode automatically
    clearAndRender();
};

function addToGrid(grid, url, isMerge, imgContext = null) {
    const div = document.createElement('div');
    div.className = `gallery-item ${isMerge?'merge-item':''}`;
    div.innerHTML = `<img src="${url}" loading="lazy">`;
    
    // Check if it should be pre-selected (if scrolling in select mode)
    if (isSelectMode && imgContext && selectedItems.has(imgContext.imgObject)) div.classList.add('selected');

    div.onclick = () => {
        if (isSelectMode && imgContext && imgContext.isNormal) {
            if (selectedItems.has(imgContext.imgObject)) {
                selectedItems.delete(imgContext.imgObject);
                div.classList.remove('selected');
            } else {
                selectedItems.add(imgContext.imgObject);
                div.classList.add('selected');
            }
            els.selectCount.innerText = `${selectedItems.size} Selected`;
        } else if (!isSelectMode) {
            openModal(url, imgContext, grid);
        }
    };
    grid.appendChild(div);
}

// --- SAFE BITMAP GENERATOR (Error Handling) ---
async function safeGetBitmap(data) {
    try { return await createImageBitmap(new Blob([data])); } 
    catch (e) {
        corruptCount++; showCorruptWarning();
        const cvs = document.createElement('canvas'); cvs.width = 800; cvs.height = 1100;
        const ctx = cvs.getContext('2d'); ctx.fillStyle = "#fee2e2"; ctx.fillRect(0,0,cvs.width,cvs.height);
        ctx.strokeStyle = "#ef4444"; ctx.lineWidth = 15; ctx.strokeRect(20,20,cvs.width-40,cvs.height-40);
        ctx.fillStyle = "#b91c1c"; ctx.font = "bold 60px sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
        ctx.fillText("CORRUPT IMAGE", cvs.width/2, cvs.height/2);
        return await createImageBitmap(cvs);
    }
}
function showCorruptWarning() {
    let el = document.getElementById('corrupt-warn-msg');
    if(!el) {
        el = document.createElement('div'); el.id = 'corrupt-warn-msg';
        el.style.cssText = 'color:var(--danger); background:var(--warning-bg); padding:12px; border-radius:8px; margin-top:15px; text-align:center; font-weight:bold; border:1px solid var(--warning-text);';
        els.progress.appendChild(el);
    }
    el.innerText = `⚠️ Warning: ${corruptCount} corrupt image(s) replaced with placeholders.`;
    el.style.display = 'block';
}
function resetCorruptState() { corruptCount = 0; const el = document.getElementById('corrupt-warn-msg'); if(el) el.style.display = 'none'; }

async function createMergedUrl(pair, isRTL) {
    const ctx = els.canvas.getContext('2d');
    const b1 = await safeGetBitmap(pair[0].data);
    let b2 = pair[1] ? await safeGetBitmap(pair[1].data) : null;

    if(!b2) {
        els.canvas.width = b1.width; els.canvas.height = b1.height; ctx.drawImage(b1, 0, 0);
    } else {
        els.canvas.width = b1.width + b2.width; els.canvas.height = Math.max(b1.height, b2.height);
        ctx.fillStyle="#fff"; ctx.fillRect(0,0,els.canvas.width,els.canvas.height);
        if(isRTL) { ctx.drawImage(b2, 0, 0); ctx.drawImage(b1, b2.width, 0); } 
        else { ctx.drawImage(b1, 0, 0); ctx.drawImage(b2, b1.width, 0); }
    }
    return new Promise(r => els.canvas.toBlob(blob => r(URL.createObjectURL(blob)), 'image/jpeg', 0.85));
}

// --- MODAL LOGIC ---
function openModal(src, restoreContext = null, sourceGrid = null) {
    if(dataTransferred) return;
    els.modalImg.src = src; els.modal.style.display = 'flex';
    document.body.classList.add('no-scroll');

    if (sourceGrid) {
        const imgs = sourceGrid.querySelectorAll('img');
        currentModalList = Array.from(imgs).map(img => img.src);
        currentModalIndex = currentModalList.indexOf(src);
    } else { currentModalList = []; currentModalIndex = -1; }
    
    document.querySelector('.modal-prev').style.display = currentModalList.length > 1 ? 'flex' : 'none';
    document.querySelector('.modal-next').style.display = currentModalList.length > 1 ? 'flex' : 'none';

    if (restoreContext && els.modalActions) {
        currentModalImage = restoreContext.imgObject;
        currentModalGroup = restoreContext.group;
        els.modalActions.style.display = 'flex';
        
        if (restoreContext.isNormal) {
            els.modalReason.innerText = "Current Image";
            els.modalRestoreBtn.style.display = 'none';
            els.modalDeleteBtn.style.display = 'inline-block';
        } else {
            els.modalReason.innerText = `Filtered: ${restoreContext.reason}`;
            els.modalRestoreBtn.style.display = 'inline-block';
            els.modalDeleteBtn.style.display = 'none';
        }
    } else {
        currentModalImage = null; currentModalGroup = null;
        if(els.modalActions) els.modalActions.style.display = 'none';
    }
}

window.changeModalImage = function(direction) {
    if (currentModalList.length <= 1) return;
    currentModalIndex += direction;
    if (currentModalIndex < 0) currentModalIndex = currentModalList.length - 1; 
    if (currentModalIndex >= currentModalList.length) currentModalIndex = 0;
    els.modalImg.src = currentModalList[currentModalIndex];
    if(els.modalActions) els.modalActions.style.display = 'none';
};

// Modal Buttons
if(els.modalRestoreBtn) {
    els.modalRestoreBtn.onclick = () => {
        if (currentModalImage && currentModalGroup) {
            currentModalImage.forceKeep = true; currentModalImage.userDeleted = false;
            applyFiltersToAll(); closeModal(); clearAndRender();
        }
    };
}

if(els.modalDeleteBtn) {
    els.modalDeleteBtn.onclick = () => {
        if (currentModalImage && currentModalGroup) {
            // Hide image briefly for seamless transition feel
            els.modalImg.style.opacity = '0';
            
            currentModalImage.userDeleted = true;
            currentModalImage.forceKeep = false;
            applyFiltersToAll();
            
            let targetIndex = currentModalIndex;
            clearAndRender(); // Rebuilds the background DOM

            const groupImages = currentModalGroup.displayImages;
            if (groupImages.length > 0) {
                if (targetIndex >= groupImages.length) targetIndex = groupImages.length - 1; 
                
                // Wait briefly for the UI to reconstruct the chapter folders
                setTimeout(() => {
                    const groupDomIndex = rawGroups.indexOf(currentModalGroup);
                    const allChapterItems = els.list.querySelectorAll('.chapter-item');
                    if (groupDomIndex !== -1 && allChapterItems[groupDomIndex]) {
                        const newSourceGrid = allChapterItems[groupDomIndex].querySelector('.gallery-grid');
                        if (newSourceGrid) {
                            const imageElements = newSourceGrid.querySelectorAll('.gallery-item');
                            if (imageElements[targetIndex]) {
                                imageElements[targetIndex].click(); // Simulate clicking the next image!
                                els.modalImg.style.opacity = '1';
                                return; // Success!
                            }
                        }
                    }
                    closeModal(); els.modalImg.style.opacity = '1';
                }, 60);
            } else {
                closeModal(); els.modalImg.style.opacity = '1';
            }
        }
    };
}

document.querySelector('.close-modal').onclick = closeModal;
els.modal.onclick = (e) => { if(e.target === els.modal) closeModal(); };
function closeModal() { els.modal.style.display = 'none'; document.body.classList.remove('no-scroll'); currentModalList = []; }

document.onkeydown = (e) => {
    if(els.modal.style.display === 'flex') {
        if (e.key === 'Escape') closeModal();
        if (e.key === 'ArrowLeft')  { e.preventDefault(); window._animateSlide ? window._animateSlide(-1) : changeModalImage(-1); }
        if (e.key === 'ArrowRight') { e.preventDefault(); window._animateSlide ? window._animateSlide(1)  : changeModalImage(1);  }
    }
};

(function initSwipe() {
    const SWIPE_THRESHOLD = 50, SWIPE_MAX_VERT = 100, ANIM_DURATION = 300;
    let touchStartX = 0, touchStartY = 0, isDragging = false;

    function showSwipeHint() {
        if (currentModalList.length <= 1) return;
        let hint = document.getElementById('swipe-hint');
        if (!hint) {
            hint = document.createElement('div'); hint.id = 'swipe-hint';
            hint.style.cssText = `position:absolute; bottom:80px; left:50%; transform:translateX(-50%); background:rgba(0,0,0,0.55); color:white; padding:8px 18px; border-radius:30px; font-size:0.82rem; font-weight:600; pointer-events:none; display:flex; align-items:center; gap:8px; white-space:nowrap; backdrop-filter:blur(6px); border:1px solid rgba(255,255,255,0.15); transition: opacity 0.4s ease;`;
            hint.innerHTML = '👈 Swipe to navigate 👉'; els.modal.appendChild(hint);
        }
        hint.style.opacity = '1'; clearTimeout(hint._fadeTimer);
        hint._fadeTimer = setTimeout(() => { hint.style.opacity = '0'; }, 1800);
    }

    function animateSlide(direction) {
        const img = els.modalImg;
        const outX = direction > 0 ? '-60px' : '60px', inX = direction > 0 ? '60px' : '-60px';
        img.style.transition = `transform ${ANIM_DURATION}ms ease, opacity ${ANIM_DURATION}ms ease`;
        img.style.transform = `translateX(${outX})`; img.style.opacity = '0';
        setTimeout(() => {
            changeModalImage(direction);
            img.style.transition = 'none'; img.style.transform = `translateX(${inX})`; img.style.opacity = '0';
            void img.offsetWidth;
            img.style.transition = `transform ${ANIM_DURATION}ms ease, opacity ${ANIM_DURATION}ms ease`;
            img.style.transform = 'translateX(0)'; img.style.opacity = '1';
        }, ANIM_DURATION);
    }

    els.modal.addEventListener('touchstart', (e) => {
        if (currentModalList.length <= 1) return;
        touchStartX = e.changedTouches[0].clientX; touchStartY = e.changedTouches[0].clientY;
        isDragging = true; els.modalImg.style.transition = 'none';
    }, { passive: true });

    els.modal.addEventListener('touchmove', (e) => {
        if (!isDragging || currentModalList.length <= 1) return;
        els.modalImg.style.transform = `translateX(${(e.changedTouches[0].clientX - touchStartX) * 0.3}px)`;
    }, { passive: true });

    els.modal.addEventListener('touchend', (e) => {
        if (!isDragging) return; isDragging = false;
        const dx = e.changedTouches[0].clientX - touchStartX, dy = e.changedTouches[0].clientY - touchStartY;
        els.modalImg.style.transition = `transform ${ANIM_DURATION}ms ease, opacity ${ANIM_DURATION}ms ease`;
        els.modalImg.style.transform = 'translateX(0)'; els.modalImg.style.opacity = '1';
        if (Math.abs(dx) > SWIPE_THRESHOLD && Math.abs(dy) < SWIPE_MAX_VERT) animateSlide(dx < 0 ? 1 : -1);
    }, { passive: true });

    window._animateSlide = animateSlide;
    const _origOpenModal = openModal;
    window.openModal = function(...args) { _origOpenModal(...args); setTimeout(showSwipeHint, 200); };
})();

// --- DOWNLOAD ---
els.downloadBtn.onclick = async () => {
    if(!rawGroups.length || dataTransferred) return;
    els.downloadBtn.disabled = true; els.downloadBtn.innerText = "Packing Data..."; els.progress.style.display = 'block';

    let finalGroups = []; const transferBuffers = [];

    if(currentMode === 'merge') {
        updateProgress("Merging images for export...", 0);
        const isRTL = document.getElementById('rtl-mode').checked; resetCorruptState(); 

        for(let i=0; i<rawGroups.length; i++) {
            const g = rawGroups[i], pairs = pairImages(g.displayImages), mergedImages = [];
            for(let j=0; j<pairs.length; j++) {
                if(j%5===0) updateProgress(`Merging ${g.groupName} (${j}/${pairs.length})`, (i/rawGroups.length)*100);
                const url = await createMergedUrl(pairs[j], isRTL), res = await fetch(url), blob = await res.blob(), buf = await blob.arrayBuffer();
                transferBuffers.push(buf); mergedImages.push({ name: `page_${String(j).padStart(4,'0')}.jpg`, data: new Uint8Array(buf), ext: 'jpg' });
                URL.revokeObjectURL(url); 
            }
            finalGroups.push({ groupName: g.groupName, images: mergedImages });
        }
    } else {
        updateProgress("Preparing data transfer...", 90);
        finalGroups = rawGroups.map(g => ({
            groupName: g.groupName,
            images: g.displayImages.map(img => {
                if(img.data.buffer) transferBuffers.push(img.data.buffer);
                return { name: img.name, data: img.data, ext: img.ext };
            })
        }));
    }

    updateProgress("Sending to Worker...", 95);
    worker.postMessage({ type: 'zip', groups: finalGroups, extType: 'cbz' }, transferBuffers);
};

window.setMode = (mode) => {
    if(dataTransferred) return;
    currentMode = mode;
    document.querySelectorAll('.mode-tab').forEach(b => b.classList.remove('active'));
    document.getElementById(`tab-${mode}`).classList.add('active');
    els.settingsExtract.classList.toggle('hidden', mode !== 'extract');
    els.settingsMerge.classList.toggle('hidden', mode === 'extract');
    if(isSelectMode) els.cancelSelectBtn.click();
    clearAndRender();
};

document.getElementById('reset-btn').onclick = () => { activeUrls.forEach(u => URL.revokeObjectURL(u)); location.reload(); };
document.getElementById('theme-toggle').onclick = () => {
    const html = document.documentElement;
    html.setAttribute('data-theme', html.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
    saveConfig();
};
function downloadBlob(blob, name) {
    const a = document.createElement('a'), url = URL.createObjectURL(blob);
    a.href = url; a.download = name; a.click(); setTimeout(()=>URL.revokeObjectURL(url), 1000);
}

init();
