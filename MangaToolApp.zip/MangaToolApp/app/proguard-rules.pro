# Keep WebView JavaScript interface methods
-keepclassmembers class com.mangatool.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
