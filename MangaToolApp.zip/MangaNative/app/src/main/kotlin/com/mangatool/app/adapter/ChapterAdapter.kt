package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.ImageMerger

class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    private val expanded = mutableSetOf<Int>()
    private val thumbAdapters = mutableMapOf<Int, ImageThumbAdapter>()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView      = v.findViewById(R.id.chapter_name)
        val count: TextView     = v.findViewById(R.id.chapter_count)
        val arrow: TextView     = v.findViewById(R.id.chapter_arrow)
        val removeBtn: ImageButton = v.findViewById(R.id.chapter_remove)
        val header: View        = v.findViewById(R.id.chapter_header)
        val grid: RecyclerView  = v.findViewById(R.id.chapter_grid)
        val filteredRow: View   = v.findViewById(R.id.filtered_row)
        val filteredCount: TextView = v.findViewById(R.id.filtered_count)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chapter, parent, false)
        return VH(v)
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group = groups[position]
        val isExpanded = position in expanded
        val isMerge = AppState.currentMode == "merge"

        holder.name.text  = group.groupName
        holder.count.text = "${group.displayImages.size} images"
        holder.arrow.text = if (isExpanded) "▲" else "▼"

        // Filtered row — only show in extract mode
        val fCount = group.filteredImages.size
        if (!isMerge && fCount > 0) {
            holder.filteredRow.visibility = View.VISIBLE
            holder.filteredCount.text = "⚠ $fCount filtered"
        } else {
            holder.filteredRow.visibility = View.GONE
        }

        holder.removeBtn.setOnClickListener { onGroupRemove(position) }

        holder.header.setOnClickListener {
            if (isExpanded) {
                expanded.remove(position)
                thumbAdapters.remove(position)?.destroy()
                holder.grid.adapter = null
                holder.grid.visibility = View.GONE
            } else {
                expanded.add(position)
                populateGrid(holder, position, group)
                holder.grid.visibility = View.VISIBLE
            }
            holder.arrow.text = if (position in expanded) "▲" else "▼"
        }

        if (isExpanded) {
            populateGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            holder.grid.visibility = View.GONE
        }
    }

    private fun populateGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == "merge"
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages)
                               else group.displayImages
        val cols = if (isMerge) 2 else 3
        val adapter = ImageThumbAdapter(
            items, isMerge, AppState.rtlMode,
            onItemClick = { idx -> onImageClick(position, idx) },
            onItemLongClick = onImageLongClick
        )
        thumbAdapters[position]?.destroy()
        thumbAdapters[position] = adapter
        holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols)
        holder.grid.adapter = adapter
    }

    fun collapseAll() {
        expanded.clear()
        thumbAdapters.values.forEach { it.destroy() }
        thumbAdapters.clear()
        notifyDataSetChanged()
    }

    override fun onViewRecycled(holder: VH) {
        holder.grid.adapter = null
        super.onViewRecycled(holder)
    }
}
