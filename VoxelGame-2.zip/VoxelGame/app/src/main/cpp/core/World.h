#pragma once
#include "Chunk.h"
#include "Noise.h"
#include "MathUtils.h"
#include <unordered_map>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <vector>
#include <cstdint>

struct ChunkKey {
    int x, z;
    bool operator==(const ChunkKey& o) const { return x==o.x && z==o.z; }
};
struct ChunkHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int64_t>()(((int64_t)k.x<<32)|(uint32_t)k.z);
    }
};

class World {
public:
    explicit World(uint32_t seed = 42);
    ~World();

    uint8_t getBlock(int x, int y, int z) const;
    // Like getBlock but treats unloaded chunks as solid below y=100
    // Used by collision so player never falls through ungenerated terrain
    bool    blockSolidForCollision(int x, int y, int z) const;
    void    setBlock(int x, int y, int z, uint8_t type);
    Chunk*  getChunk(int cx, int cz) const;

    void    update(float px, float pz, int renderDist);
    void    renderAll(GLint mvpLoc, const float* vp) const;

    size_t  chunkCount() const { return chunks.size(); }
    bool    raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const;

private:
    // GL-thread-only chunk map
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkHash> chunks;
    // Tracks which chunks need remeshing after block edits (avoids full scan)
    std::vector<ChunkKey> dirtyChunks;

    // Worker thread
    std::thread              worker;
    bool                     workerRunning{false};  // protected by reqMutex
    std::condition_variable  reqCV;

    std::mutex               reqMutex;
    std::vector<ChunkKey>    requested;
    std::vector<ChunkKey>    inFlight;

    struct BuiltChunk {
        int cx, cz;
        std::unique_ptr<Chunk> chunk;
    };
    std::mutex               resMutex;
    std::vector<BuiltChunk>  results;

    Noise    noise;
    uint32_t seed;

    void    workerMain();
    void    generateAndMesh(int cx, int cz);
    void    generateChunk(Chunk* c);
    void    placeTree(Chunk* c, int lx, int y, int lz, float wx, float wz);

    uint8_t workerGetBlock(int x, int y, int z,
        const std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash>& local) const;
};
