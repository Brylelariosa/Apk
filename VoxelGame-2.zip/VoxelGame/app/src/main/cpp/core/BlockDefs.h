#pragma once
#include <cstdint>

enum BlockType : uint8_t {
    BLOCK_AIR    = 0,
    BLOCK_GRASS  = 1,
    BLOCK_DIRT   = 2,
    BLOCK_STONE  = 3,
    BLOCK_SAND   = 4,
    BLOCK_GRAVEL = 5,
    BLOCK_LOG    = 6,
    BLOCK_LEAVES = 7,
    BLOCK_SNOW   = 8,
    BLOCK_WATER  = 9,
    BLOCK_LAVA   = 10,
    BLOCK_COAL   = 11,
    BLOCK_IRON   = 12,
    BLOCK_GLOWSTONE = 13,
    BLOCK_COUNT
};

struct BlockInfo {
    float r, g, b;       // side face colour
    float tr, tg, tb;    // top face colour
    bool  solid;
    bool  transparent;
    bool  emissive;
};

// Table indexed by BlockType
inline const BlockInfo BLOCKS[BLOCK_COUNT] = {
    /* AIR       */ {0,0,0,               0,0,0,               false, true,  false},
    /* GRASS     */ {0.56f,0.36f,0.15f,   0.30f,0.68f,0.18f,  true,  false, false},
    /* DIRT      */ {0.56f,0.36f,0.15f,   0.56f,0.36f,0.15f,  true,  false, false},
    /* STONE     */ {0.50f,0.50f,0.50f,   0.50f,0.50f,0.50f,  true,  false, false},
    /* SAND      */ {0.85f,0.80f,0.50f,   0.85f,0.80f,0.50f,  true,  false, false},
    /* GRAVEL    */ {0.46f,0.44f,0.43f,   0.46f,0.44f,0.43f,  true,  false, false},
    /* LOG       */ {0.36f,0.22f,0.10f,   0.50f,0.45f,0.30f,  true,  false, false},
    /* LEAVES    */ {0.15f,0.45f,0.10f,   0.15f,0.45f,0.10f,  false, true,  false},
    /* SNOW      */ {0.90f,0.90f,0.95f,   0.96f,0.96f,1.00f,  true,  false, false},
    /* WATER     */ {0.03f,0.18f,0.62f,   0.05f,0.28f,0.72f,  false, false, false},
    /* LAVA      */ {0.90f,0.30f,0.05f,   0.95f,0.50f,0.05f,  true,  false, true },
    /* COAL      */ {0.28f,0.28f,0.28f,   0.28f,0.28f,0.28f,  true,  false, false},
    /* IRON      */ {0.62f,0.55f,0.48f,   0.62f,0.55f,0.48f,  true,  false, false},
    /* GLOWSTONE */ {0.90f,0.80f,0.40f,   0.95f,0.90f,0.50f,  true,  false, true },
};

inline bool blockSolid(uint8_t t) {
    return t > 0 && t < BLOCK_COUNT && BLOCKS[t].solid;
}
inline bool blockOpaque(uint8_t t) {
    return t > 0 && t < BLOCK_COUNT && !BLOCKS[t].transparent;
}
