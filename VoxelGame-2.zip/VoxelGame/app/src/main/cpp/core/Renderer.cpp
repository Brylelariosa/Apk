#include "Renderer.h"
#include <cmath>
#include <cstring>
#include <cstdio>
#include <android/log.h>

#define LOG_TAG "VoxelRenderer"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

// ── World shader ──────────────────────────────────────────────────────────────
static const char* WORLD_VERT = R"(#version 300 es
precision mediump float;
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aColor;
layout(location=2) in float aLight;
uniform mat4 uMVP;
out vec3  vColor;
out float vFog;
void main(){
    vec4 pos = uMVP * vec4(aPos, 1.0);
    gl_Position = pos;
    vFog   = clamp((length(pos.xyz) - 60.0) / 160.0, 0.0, 1.0);
    vColor = aColor * aLight;
}
)";
static const char* WORLD_FRAG = R"(#version 300 es
precision mediump float;
in vec3  vColor;
in float vFog;
out vec4 fragColor;
const vec3 SKY = vec3(0.53, 0.81, 0.98);
void main(){
    fragColor = vec4(mix(vColor, SKY, vFog), 1.0);
}
)";

// ── HUD shader ────────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
precision mediump float;
layout(location=0) in vec2 aPos;
uniform mat4 uOrtho;
void main(){ gl_Position = uOrtho * vec4(aPos, 0.0, 1.0); }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
uniform vec4 uColor;
out vec4 fragColor;
void main(){ fragColor = uColor; }
)";

// ── Shader helpers ────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s,512,nullptr,b); LOGE("Shader: %s",b); }
    return s;
}
GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { char b[512]; glGetProgramInfoLog(p,512,nullptr,b); LOGE("Link: %s",b); }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

bool Renderer::init() {
    LOGI("GL: %s | %s", glGetString(GL_VENDOR), glGetString(GL_RENDERER));
    worldProg = linkProgram(compileShader(GL_VERTEX_SHADER,   WORLD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, WORLD_FRAG));
    hudProg   = linkProgram(compileShader(GL_VERTEX_SHADER,   HUD_VERT),
                            compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    mvpLoc      = glGetUniformLocation(worldProg, "uMVP");
    hudOrthoLoc = glGetUniformLocation(hudProg,   "uOrtho");
    hudColorLoc = glGetUniformLocation(hudProg,   "uColor");

    glGenVertexArrays(1, &hudVAO);
    glGenBuffers(1, &hudVBO);
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    // 512 vec2 vertices = 1024 floats worth of scratch space
    glBufferData(GL_ARRAY_BUFFER, 1024 * sizeof(float), nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, nullptr);
    glBindVertexArray(0);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    return (worldProg != 0 && hudProg != 0);
}

void Renderer::resize(int w, int h) {
    screenW = w; screenH = h;
    glViewport(0, 0, w, h);
}

void Renderer::beginFrame() {
    glClearColor(0.53f, 0.81f, 0.98f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

Renderer::~Renderer() {
    if (worldProg) glDeleteProgram(worldProg);
    if (hudProg)   glDeleteProgram(hudProg);
    if (hudVAO)    glDeleteVertexArrays(1, &hudVAO);
    if (hudVBO)    glDeleteBuffers(1, &hudVBO);
}

// ── Low-level submit helper ───────────────────────────────────────────────────
void Renderer::submitAndDraw(const float* pts, int count, GLenum mode,
                              float r, float g, float b, float a) {
    glBindVertexArray(hudVAO);
    glBindBuffer(GL_ARRAY_BUFFER, hudVBO);
    glBufferSubData(GL_ARRAY_BUFFER, 0, count * 2 * sizeof(float), pts);
    glUniform4f(hudColorLoc, r, g, b, a);
    glDrawArrays(mode, 0, count);
    glBindVertexArray(0);
}

void Renderer::drawLine(float x0, float y0, float x1, float y1,
                         float r, float g, float b, float a) {
    float pts[4] = {x0, y0, x1, y1};
    submitAndDraw(pts, 2, GL_LINES, r, g, b, a);
}

void Renderer::drawRect(float x, float y, float w, float h,
                         float r, float g, float b, float a) {
    float pts[12] = {
        x,   y,   x+w, y,   x+w, y+h,
        x,   y,   x+w, y+h, x,   y+h
    };
    submitAndDraw(pts, 6, GL_TRIANGLES, r, g, b, a);
}

void Renderer::drawCircle(float cx, float cy, float radius,
                           float r, float g, float b, float a, bool filled) {
    const int N = 40;
    float pts[N * 2];
    for (int i = 0; i < N; i++) {
        float ang = 6.2831853f * i / N;
        pts[i*2]   = cx + cosf(ang) * radius;
        pts[i*2+1] = cy + sinf(ang) * radius;
    }
    submitAndDraw(pts, N, filled ? GL_TRIANGLE_FAN : GL_LINE_LOOP, r, g, b, a);
}

void Renderer::drawArc(float cx, float cy, float radius,
                        float startAngle, float endAngle,
                        float r, float g, float b, float) {
    if (endAngle <= startAngle) return;
    const int N = 48;
    float pts[N * 2];
    int   count = 0;
    for (int i = 0; i <= N; i++) {
        float t   = startAngle + (endAngle - startAngle) * i / N;
        pts[count++] = cx + cosf(t) * radius;
        pts[count++] = cy + sinf(t) * radius;
    }
    submitAndDraw(pts, count/2, GL_LINE_STRIP, r, g, b, 1.f);
}

// ── 7-Segment digit renderer ──────────────────────────────────────────────────
// Each char cell is (scale*5) wide × (scale*9) tall.
// Segments A-G:
//   A=top, B=top-right, C=bot-right, D=bottom, E=bot-left, F=top-left, G=middle
static const uint8_t SEG7[10] = {
    0b0111111,  // 0: ABCDEF
    0b0000110,  // 1: BC
    0b1011011,  // 2: ABDEG (A,B,D,E,G)
    0b1001111,  // 3: ABCDG
    0b1100110,  // 4: BCFG
    0b1101101,  // 5: ACDFG
    0b1111101,  // 6: ACDEFG
    0b0000111,  // 7: ABC
    0b1111111,  // 8: all
    0b1101111,  // 9: ABCDFG
};

void Renderer::drawDigit(int digit, float x, float y, float s,
                          float r, float g, float b) {
    if (digit < 0 || digit > 9) return;
    uint8_t segs = SEG7[digit];
    float w = s * 4.f, h = s * 4.f;   // half height

    // Segment endpoints
    struct Seg { float x0,y0,x1,y1; };
    Seg S[7] = {
        {x+s,   y,     x+w-s, y    },  // A top
        {x+w,   y+s,   x+w,   y+h-s},  // B top-right
        {x+w,   y+h+s, x+w,   y+2*h-s},// C bot-right
        {x+s,   y+2*h, x+w-s, y+2*h},  // D bottom
        {x,     y+h+s, x,     y+2*h-s},// E bot-left
        {x,     y+s,   x,     y+h-s},  // F top-left
        {x+s,   y+h,   x+w-s, y+h  },  // G middle
    };
    for (int i = 0; i < 7; i++) {
        if (segs & (1 << i)) {
            float pts[4] = {S[i].x0, S[i].y0, S[i].x1, S[i].y1};
            submitAndDraw(pts, 2, GL_LINES, r, g, b, 1.f);
        }
    }
}

void Renderer::drawNumber(int num, float x, float y, float scale,
                           float r, float g, float b) {
    if (num < 0) num = 0;
    char buf[8]; snprintf(buf, 8, "%d", num);
    float charW = scale * 6.f;
    for (int i = 0; buf[i]; i++) {
        drawDigit(buf[i] - '0', x + i * charW, y, scale, r, g, b);
    }
}

// ── Static ortho matrix ───────────────────────────────────────────────────────
static void buildOrtho(float l, float r, float b, float t, float* m) {
    memset(m, 0, 64);
    m[0]=2/(r-l); m[5]=2/(t-b); m[10]=-1;
    m[12]=-(r+l)/(r-l); m[13]=-(t+b)/(t-b); m[15]=1;
}

// ── Main HUD ──────────────────────────────────────────────────────────────────
void Renderer::renderHUD(
    float sw, float sh,
    float joyBaseX, float joyBaseY,
    float joyThumbX, float joyThumbY,
    bool  joyActive,
    float breakProgress,
    int   fps,
    int   renderDist)
{
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glUseProgram(hudProg);
    float ortho[16];
    buildOrtho(0, sw, sh, 0, ortho);   // top-left origin
    glUniformMatrix4fv(hudOrthoLoc, 1, GL_FALSE, ortho);
    glLineWidth(3.f);

    // ── Crosshair ─────────────────────────────────────────────────────────────
    float cx = sw * 0.5f, cy = sh * 0.5f, cs = 22.f;
    drawLine(cx-cs, cy,  cx+cs, cy,  1,1,1);
    drawLine(cx,  cy-cs, cx,  cy+cs, 1,1,1);

    // ── Break progress arc (around crosshair) ─────────────────────────────────
    if (breakProgress > 0.f) {
        float endAng = -1.5707f + breakProgress * 6.2831853f;
        drawArc(cx, cy, cs + 12.f, -1.5707f, endAng, 1.f, 0.3f, 0.1f);
    }

    // ── Joystick (always visible) ─────────────────────────────────────────────
    float jAlpha = joyActive ? 0.65f : 0.28f;
    // Base ring
    drawCircle(joyBaseX, joyBaseY, Input::JOY_RADIUS, 1,1,1, jAlpha, false);
    // Inner ring guide
    drawCircle(joyBaseX, joyBaseY, Input::JOY_RADIUS * 0.35f, 1,1,1, jAlpha*0.5f, false);
    // Thumb
    float tAlpha = joyActive ? 0.80f : 0.35f;
    drawCircle(joyThumbX, joyThumbY, 34.f, 0.85f, 0.85f, 0.90f, tAlpha, true);
    drawCircle(joyThumbX, joyThumbY, 34.f, 1.f,   1.f,   1.f,   tAlpha, false);

    // ── Action buttons (right side) ───────────────────────────────────────────
    // JUMP (green)
    drawCircle(sw*0.84f, sh*0.68f, 54.f, 0.15f, 0.80f, 0.15f, 0.55f, true);
    drawCircle(sw*0.84f, sh*0.68f, 54.f, 0.40f, 1.00f, 0.40f, 0.80f, false);
    // PLACE (orange)
    drawCircle(sw*0.74f, sh*0.78f, 54.f, 0.85f, 0.45f, 0.10f, 0.55f, true);
    drawCircle(sw*0.74f, sh*0.78f, 54.f, 1.00f, 0.70f, 0.30f, 0.80f, false);
    // BREAK (red)
    drawCircle(sw*0.94f, sh*0.78f, 54.f, 0.80f, 0.10f, 0.10f, 0.55f, true);
    drawCircle(sw*0.94f, sh*0.78f, 54.f, 1.00f, 0.30f, 0.30f, 0.80f, false);

    // Label lines inside buttons (J / P / B style dashes)
    // JUMP: two tick marks = "^"
    drawLine(sw*0.84f-10, sh*0.68f+8, sw*0.84f,    sh*0.68f-8, 1,1,1);
    drawLine(sw*0.84f,    sh*0.68f-8, sw*0.84f+10, sh*0.68f+8, 1,1,1);
    // PLACE: "+" symbol
    drawLine(sw*0.74f-14, sh*0.78f, sw*0.74f+14, sh*0.78f, 1,1,1);
    drawLine(sw*0.74f, sh*0.78f-14, sw*0.74f, sh*0.78f+14, 1,1,1);
    // BREAK: "x" symbol
    drawLine(sw*0.94f-12, sh*0.78f-12, sw*0.94f+12, sh*0.78f+12, 1,1,1);
    drawLine(sw*0.94f+12, sh*0.78f-12, sw*0.94f-12, sh*0.78f+12, 1,1,1);

    // ── FPS counter (top-left) ────────────────────────────────────────────────
    float fpsColor[3] = {0.2f, 1.0f, 0.2f};
    if (fps < 45) { fpsColor[0]=1.f; fpsColor[1]=0.8f; fpsColor[2]=0.1f; }
    if (fps < 25) { fpsColor[0]=1.f; fpsColor[1]=0.2f; fpsColor[2]=0.1f; }

    // Semi-transparent background
    drawRect(8, 8, 130, 38, 0, 0, 0, 0.45f);
    // "FPS" label
    glLineWidth(2.f);
    // Draw "FPS:" as simple tick marks then the number
    drawNumber(fps, 16, 14, 3.f, fpsColor[0], fpsColor[1], fpsColor[2]);

    // ── Settings panel (top-right): render distance ───────────────────────────
    float px = sw - 200.f, py = 8.f;
    drawRect(px, py, 192, 52, 0, 0, 0, 0.50f);

    // "DIST:" in 7-seg
    glLineWidth(2.f);
    drawNumber(renderDist, px + 80, py + 8, 3.f, 0.9f, 0.9f, 0.9f);

    // [-] button
    float mx = sw * 0.86f, my = sh * 0.06f;
    float px2 = sw * 0.96f, py2 = sh * 0.06f;
    drawRect(mx-32, my-32, 64, 64, 0, 0, 0, 0.45f);
    drawRect(px2-32, py2-32, 64, 64, 0, 0, 0, 0.45f);
    drawCircle(mx,  my,  30.f, 0.5f, 0.5f, 0.5f, 0.70f, false);
    drawCircle(px2, py2, 30.f, 0.5f, 0.5f, 0.5f, 0.70f, false);
    glLineWidth(3.f);
    drawLine(mx-12, my, mx+12, my, 1,1,1);            // minus
    drawLine(px2-12,py2, px2+12,py2, 1,1,1);           // plus horizontal
    drawLine(px2,py2-12, px2, py2+12, 1,1,1);          // plus vertical

    // "DIST" label above the -/+ buttons
    drawRect(mx-50, my-55, 100, 22, 0, 0, 0, 0.45f);
    // Render "D" "I" "S" "T" as line-segments
    float lx = mx - 44, ly = my - 52;
    // D: vertical + right arc approximation
    drawLine(lx, ly, lx, ly+16, 0.8f,0.8f,0.8f);
    drawLine(lx, ly, lx+10, ly+2, 0.8f,0.8f,0.8f);
    drawLine(lx+10, ly+2, lx+10, ly+14, 0.8f,0.8f,0.8f);
    drawLine(lx, ly+16, lx+10, ly+14, 0.8f,0.8f,0.8f);
    lx+=14;
    // I
    drawLine(lx, ly, lx, ly+16, 0.8f,0.8f,0.8f);
    lx+=10;
    // S
    drawLine(lx+8,ly,    lx,   ly,    0.8f,0.8f,0.8f);
    drawLine(lx,  ly,    lx,   ly+8,  0.8f,0.8f,0.8f);
    drawLine(lx,  ly+8,  lx+8, ly+8,  0.8f,0.8f,0.8f);
    drawLine(lx+8,ly+8,  lx+8, ly+16, 0.8f,0.8f,0.8f);
    drawLine(lx+8,ly+16, lx,   ly+16, 0.8f,0.8f,0.8f);
    lx+=12;
    // T
    drawLine(lx, ly, lx+8, ly, 0.8f,0.8f,0.8f);
    drawLine(lx+4, ly, lx+4, ly+16, 0.8f,0.8f,0.8f);

    glLineWidth(1.f);
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
}
