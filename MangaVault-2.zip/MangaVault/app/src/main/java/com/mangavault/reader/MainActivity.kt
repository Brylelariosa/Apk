package com.mangavault.reader

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("manga_prefs", Context.MODE_PRIVATE) }

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val files = listMHtmlFiles(uri)
            webView.post {
                webView.evaluateJavascript("window.onFolderPicked($files)", null)
            }
        } else {
            webView.post {
                webView.evaluateJavascript("window.onFolderPicked(null)", null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Show any unhandled crash inside the WebView so user can read it on device
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            val msg = throwable.stackTraceToString().take(3000)
                .replace("&", "&amp;").replace("<", "&lt;")
            try {
                webView.post {
                    webView.loadData(
                        "<html><body style='background:#000;color:#f55;font-family:monospace;padding:16px;white-space:pre-wrap'>CRASH:\n$msg</body></html>",
                        "text/html", "UTF-8"
                    )
                }
            } catch (_: Exception) {}
        }

        try { makeFullscreen() } catch (_: Exception) {}

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setSupportZoom(false)
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = false
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    val desc = if (Build.VERSION.SDK_INT >= 23) error.description else "load error"
                    view.loadData(
                        "<html><body style='background:#000;color:#f55;font-family:monospace;padding:16px'>WebView error: $desc</body></html>",
                        "text/html", "UTF-8"
                    )
                }
            }
        }

        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleBack && window.handleBack()") { result ->
            if (result == "null" || result == "false") super.onBackPressed()
        }
    }

    private fun makeFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.apply {
                hide(
                    android.view.WindowInsets.Type.statusBars() or
                    android.view.WindowInsets.Type.navigationBars()
                )
                systemBarsBehavior =
                    android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        }
    }

    private fun listMHtmlFiles(treeUri: Uri): JSONArray {
        val result = JSONArray()
        return try {
            val dir = DocumentFile.fromTreeUri(this, treeUri) ?: return result
            dir.listFiles()
                .filter { it.isFile && (it.name?.endsWith(".mhtml", true) == true || it.name?.endsWith(".mht", true) == true) }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name ?: "" })
                .forEach { file ->
                    val obj = JSONObject()
                    obj.put("uri", file.uri.toString())
                    obj.put("name", cleanName(file.name ?: "Unknown"))
                    result.put(obj)
                }
            result
        } catch (_: Exception) { result }
    }

    private fun cleanName(filename: String): String =
        filename.replace(Regex("\\.(mhtml|mht)$", RegexOption.IGNORE_CASE), "")
            .replace(Regex("[-_]+"), " ").trim()

    private fun parseMHTML(content: String): List<String> {
        val bMatch = Regex("""boundary=(?:"([^"]+)"|([^\s;\r\n]+))""", RegexOption.IGNORE_CASE)
            .find(content) ?: return emptyList()
        val boundary = bMatch.groupValues[1].ifEmpty { bMatch.groupValues[2] }
        val images = mutableListOf<String>()
        for (part in content.split("--$boundary")) {
            if (!part.contains(Regex("""Content-Type:\s*image/""", RegexOption.IGNORE_CASE))) continue
            var sepIdx = part.indexOf("\r\n\r\n")
            val sepLen = if (sepIdx != -1) 4 else { sepIdx = part.indexOf("\n\n"); 2 }
            if (sepIdx == -1) continue
            val headers = part.substring(0, sepIdx)
            val body = part.substring(sepIdx + sepLen).replace(Regex("""[\r\n\t ]"""), "").trim()
            if (body.length < 10) continue
            val ct = Regex("""Content-Type:\s*(image/[^\r\n;]+)""", RegexOption.IGNORE_CASE)
                .find(headers)?.groupValues?.get(1)?.trim() ?: "image/jpeg"
            images.add("data:$ct;base64,$body")
        }
        return images
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun pickFolder() {
            try { folderPicker.launch(null) } catch (e: Exception) {
                webView.post {
                    webView.evaluateJavascript(
                        "window.showError && window.showError('${e.message?.replace("'", "\\'")}')", null
                    )
                }
            }
        }

        @JavascriptInterface
        fun readManga(uriString: String): String {
            return try {
                val uri = Uri.parse(uriString)
                val sb = StringBuilder()
                contentResolver.openInputStream(uri)?.use { input ->
                    BufferedReader(InputStreamReader(input, "UTF-8"), 65536).use { reader ->
                        var line = reader.readLine()
                        while (line != null) { sb.append(line).append('\n'); line = reader.readLine() }
                    }
                }
                val arr = JSONArray()
                parseMHTML(sb.toString()).forEach { arr.put(it) }
                arr.toString()
            } catch (_: Exception) { "[]" }
        }

        @JavascriptInterface
        fun saveProgress(key: String, value: String) {
            try { prefs.edit().putString("prog_$key", value).apply() } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun loadProgress(key: String): String =
            try { prefs.getString("prog_$key", "") ?: "" } catch (_: Exception) { "" }

        @JavascriptInterface
        fun loadAllProgress(): String {
            return try {
                val obj = JSONObject()
                prefs.all.forEach { (k, v) ->
                    if (k.startsWith("prog_") && v is String) obj.put(k.removePrefix("prog_"), v)
                }
                obj.toString()
            } catch (_: Exception) { "{}" }
        }

        @JavascriptInterface
        fun clearProgress(key: String) {
            try { prefs.edit().remove("prog_$key").apply() } catch (_: Exception) {}
        }
    }
}
