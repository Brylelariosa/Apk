# Add project specific ProGuard rules here.
-keep class com.goblobin.nodebuster.** { *; }
