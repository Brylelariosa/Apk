#include "Renderer.h"
#include <android/log.h>
#include <cmath>
#include <cstring>
#include <cstdio>

#define TAG "NB_Rend"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char* VS = R"glsl(
attribute vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
)glsl";

static const char* FS = R"glsl(
precision mediump float;
uniform vec4 uColor;
void main() { gl_FragColor = uColor; }
)glsl";

static GLuint compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(s,512,nullptr,b); LOGE("%s",b); }
    return s;
}

static const uint8_t SEGS[10] = {
    0b1111110,0b0110000,0b1101101,0b1111001,0b0110011,
    0b1011011,0b1011111,0b1110000,0b1111111,0b1111011
};

void Renderer::init() {
    GLuint vs = compileShader(GL_VERTEX_SHADER, VS);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, FS);
    m_prog = glCreateProgram();
    glAttachShader(m_prog, vs); glAttachShader(m_prog, fs);
    glLinkProgram(m_prog);
    glDeleteShader(vs); glDeleteShader(fs);
    m_aPos = glGetAttribLocation(m_prog,  "aPos");
    m_uCol = glGetUniformLocation(m_prog, "uColor");
    LOGI("Renderer init OK");
}

void Renderer::resize(int w, int h) {
    m_screenW = w; m_screenH = h;
    glViewport(0, 0, w, h);
    m_worldW = WORLD_H * ((float)w / (float)h);
}

void Renderer::beginFrame() {
    glClearColor(0.03f, 0.03f, 0.06f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(m_prog);
    glEnableVertexAttribArray(m_aPos);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void Renderer::endFrame() {
    glDisableVertexAttribArray(m_aPos);
}

void Renderer::drawQuadNDC(float x1, float y1, float x2, float y2,
                             float r, float g, float b, float a) {
    float v[] = { x1,y1, x2,y1, x1,y2,  x2,y1, x2,y2, x1,y2 };
    glUniform4f(m_uCol, r, g, b, a);
    glVertexAttribPointer(m_aPos, 2, GL_FLOAT, GL_FALSE, 0, v);
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

void Renderer::drawRect(float x, float y, float w, float h,
                         float r, float g, float b, float a) {
    drawQuadNDC(toNdcX(x), toNdcY(y+h), toNdcX(x+w), toNdcY(y), r, g, b, a);
}

void Renderer::drawRectBorder(float x, float y, float w, float h, float t,
                               float r, float g, float b, float a) {
    drawRect(x,       y,       w, t, r,g,b,a);
    drawRect(x,       y+h-t,   w, t, r,g,b,a);
    drawRect(x,       y,       t, h, r,g,b,a);
    drawRect(x+w-t,   y,       t, h, r,g,b,a);
}

void Renderer::drawCircle(float cx, float cy, float radius,
                           float r, float g, float b, float a) {
    const int SEG = 28;
    float verts[SEG*6];
    float rx = radius / m_worldW * 2.f;
    float ry = radius / WORLD_H  * 2.f;
    float ncx = toNdcX(cx), ncy = toNdcY(cy);
    int vi = 0;
    for (int i = 0; i < SEG; ++i) {
        float a0 = 2.f * M_PI * i       / SEG;
        float a1 = 2.f * M_PI * (i + 1) / SEG;
        verts[vi++]=ncx; verts[vi++]=ncy;
        verts[vi++]=ncx+cosf(a0)*rx; verts[vi++]=ncy+sinf(a0)*ry;
        verts[vi++]=ncx+cosf(a1)*rx; verts[vi++]=ncy+sinf(a1)*ry;
    }
    glUniform4f(m_uCol, r, g, b, a);
    glVertexAttribPointer(m_aPos, 2, GL_FLOAT, GL_FALSE, 0, verts);
    glDrawArrays(GL_TRIANGLES, 0, SEG*3);
}

void Renderer::drawCircleBorder(float cx, float cy, float radius, float thick,
                                 float r, float g, float b, float a) {
    drawCircle(cx, cy, radius,       r, g, b, a);
    drawCircle(cx, cy, radius-thick, 0.03f, 0.03f, 0.06f, 1.f);
}

void Renderer::drawHexagon(float cx, float cy, float radius,
                            float r, float g, float b, float a) {
    const int N = 6;
    float verts[N*6];
    float rx = radius / m_worldW * 2.f;
    float ry = radius / WORLD_H  * 2.f;
    float ncx = toNdcX(cx), ncy = toNdcY(cy);
    int vi = 0;
    for (int i = 0; i < N; ++i) {
        float a0 = (M_PI / 6.f) + 2.f * M_PI * i       / N;
        float a1 = (M_PI / 6.f) + 2.f * M_PI * (i + 1) / N;
        verts[vi++]=ncx; verts[vi++]=ncy;
        verts[vi++]=ncx+cosf(a0)*rx; verts[vi++]=ncy+sinf(a0)*ry;
        verts[vi++]=ncx+cosf(a1)*rx; verts[vi++]=ncy+sinf(a1)*ry;
    }
    glUniform4f(m_uCol, r, g, b, a);
    glVertexAttribPointer(m_aPos, 2, GL_FLOAT, GL_FALSE, 0, verts);
    glDrawArrays(GL_TRIANGLES, 0, N*3);
}

void Renderer::drawBar(float x, float y, float w, float h, float fill,
                        float br, float bg, float bb,
                        float fr, float fg, float fb) {
    drawRect(x, y, w,        h, br, bg, bb);
    if (fill > 0.f)
        drawRect(x, y, w*fill, h, fr, fg, fb);
}

void Renderer::drawDigit(int d, float x, float y, float ch,
                          float r, float g, float b) {
    if (d < 0 || d > 9) return;
    uint8_t mask = SEGS[d];
    float t = ch*0.12f, hw = ch*0.55f, mh = ch*0.5f;
    if (mask&0b1000000) drawRect(x+t,      y,           hw-2*t, t, r,g,b);
    if (mask&0b0100000) drawRect(x+hw-t,   y+t,         t, mh-t, r,g,b);
    if (mask&0b0010000) drawRect(x+hw-t,   y+mh,        t, mh-t, r,g,b);
    if (mask&0b0001000) drawRect(x+t,      y+ch-t,      hw-2*t, t, r,g,b);
    if (mask&0b0000100) drawRect(x,        y+mh,        t, mh-t, r,g,b);
    if (mask&0b0000010) drawRect(x,        y+t,         t, mh-t, r,g,b);
    if (mask&0b0000001) drawRect(x+t,      y+mh-t/2.f, hw-2*t, t, r,g,b);
}

void Renderer::drawNumber(long n, float x, float y, float ch,
                           float r, float g, float b) {
    if (n < 0) n = 0;
    char buf[32]; snprintf(buf, sizeof(buf), "%ld", n);
    float cw = ch * 0.7f;
    for (int i = 0; buf[i]; ++i) {
        drawDigit(buf[i]-'0', x + i*cw, y, ch, r, g, b);
    }
}
