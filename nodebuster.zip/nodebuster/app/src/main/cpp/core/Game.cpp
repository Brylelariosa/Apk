#include "Game.h"
#include <android/log.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cmath>

#define TAG "NB_Game"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static const float DT = 1.f / 60.f;

// ─────────────────────────────────────────────────────────────
Game& Game::get() { static Game g; return g; }

// ─────────────────────────────────────────────────────────────
//  Persistence
// ─────────────────────────────────────────────────────────────
void Game::loadSave() {
    FILE* f = fopen(m_savePath.c_str(), "rb");
    if (!f) return;
    SaveData tmp{};
    if (fread(&tmp, sizeof(tmp), 1, f) == 1 && tmp.magic == 0xAB020002u)
        m_save = tmp;
    fclose(f);
    LOGI("Loaded: lv=%d pts=%d nodeLv=%d", m_save.level, m_save.upgradePoints, m_save.currentLevel);
}

void Game::writeSave() {
    FILE* f = fopen(m_savePath.c_str(), "wb");
    if (f) { fwrite(&m_save, sizeof(m_save), 1, f); fclose(f); }
}

// ─────────────────────────────────────────────────────────────
//  Derived stat computation
// ─────────────────────────────────────────────────────────────
void Game::recomputeStats() {
    const int* s = m_save.skillLevels;
    m_attackPower    = 8.f   * powf(1.35f, (float)s[0]);
    m_attackInterval = 1.4f  * powf(0.82f, (float)s[1]);
    m_hitsPerAttack  = 1     + s[2];
    m_resourceMult   = 1.f   * powf(1.30f, (float)s[3]);
    m_xpMult         = 1.f   * powf(1.30f, (float)s[4]);
    m_critChance     = 0.05f + s[5] * 0.07f;
    m_boostCoolMult  = 1.f   * powf(0.80f, (float)s[6]);
    m_chainHits      =         s[7];
    m_shieldBypass   = 0.f   + s[8] * 0.15f;
    m_boost.maxCool  = 12.f * m_boostCoolMult;
}

// ─────────────────────────────────────────────────────────────
//  Init / resize
// ─────────────────────────────────────────────────────────────
void Game::init(const char* savePath, int w, int h) {
    srand((unsigned)time(nullptr));
    m_savePath = savePath;
    loadSave();
    recomputeStats();
    m_rend.init();
    m_rend.resize(w, h);
    m_screen = Screen::SKILL_TREE;
}

void Game::resize(int w, int h) { m_rend.resize(w, h); }

// ─────────────────────────────────────────────────────────────
//  Node building
// ─────────────────────────────────────────────────────────────
void Game::buildNode() {
    float W = m_rend.worldW(), H = Renderer::WORLD_H;
    bool boss = (m_nodeIndex == m_nodesInLevel);
    int  lv   = m_save.currentLevel;

    m_node = Node{};
    m_node.cx = W * 0.5f;
    m_node.cy = H * 0.44f;
    m_node.alive = true;
    m_node.isBoss = boss;
    m_node.pulseT = 0.f;

    float baseHp = (50.f + lv * 30.f) * (float)m_nodeIndex;
    if (boss) {
        m_node.radius    = 3.0f + lv * 0.08f;
        m_node.maxHp     = baseHp * 4.f;
        m_node.maxShield = baseHp * 0.8f;
        m_node.shape     = NodeShape::HEX;
        m_node.r = 0.9f; m_node.g = 0.2f; m_node.b = 0.9f;
        m_node.resourceReward = (20 + lv * 8) * 3;
        m_node.xpReward       = (15 + lv * 5) * 3;
    } else {
        int type = (m_nodeIndex + lv) % 4;
        switch (type) {
            case 0: m_node.shape=NodeShape::CIRCLE;  m_node.r=0.2f; m_node.g=0.6f; m_node.b=1.0f; break;
            case 1: m_node.shape=NodeShape::SQUARE;  m_node.r=0.3f; m_node.g=1.0f; m_node.b=0.5f; break;
            case 2: m_node.shape=NodeShape::DIAMOND; m_node.r=1.0f; m_node.g=0.7f; m_node.b=0.1f; break;
            case 3: m_node.shape=NodeShape::HEX;     m_node.r=0.8f; m_node.g=0.3f; m_node.b=0.3f; break;
        }
        m_node.radius    = 1.6f + lv * 0.04f;
        m_node.maxHp     = baseHp;
        m_node.maxShield = baseHp * (0.1f + lv * 0.015f);
        m_node.resourceReward = 8 + lv * 3;
        m_node.xpReward       = 5 + lv * 2;
    }
    m_node.hp     = m_node.maxHp;
    m_node.shield = m_node.maxShield;
    LOGI("Node %d/%d built  hp=%.0f  boss=%d", m_nodeIndex, m_nodesInLevel, m_node.maxHp, (int)boss);
}

// ─────────────────────────────────────────────────────────────
//  Level / screen transitions
// ─────────────────────────────────────────────────────────────
void Game::startLevel(int lv) {
    m_save.currentLevel = lv;
    m_nodesInLevel = 4 + lv / 2;   // more nodes as levels rise
    m_nodeIndex    = 1;
    m_projs.clear();
    m_floats.clear();
    m_autoTimer = 0.f;
    buildNode();
    m_screen = Screen::PLAYING;
}

void Game::startSkillTree() {
    m_screen = Screen::SKILL_TREE;
    m_projs.clear();
}

// ─────────────────────────────────────────────────────────────
//  Attack logic
// ─────────────────────────────────────────────────────────────
void Game::attackNode(float power, bool /*fromTap*/) {
    if (!m_node.alive) return;

    float W = m_rend.worldW(), H = Renderer::WORLD_H;
    // spawn projectile from bottom-center
    float ox = W * 0.5f, oy = H * 0.85f;
    bool  boost = m_boost.active;

    for (int h = 0; h < m_hitsPerAttack; ++h) {
        bool  crit   = ((float)rand() / RAND_MAX) < m_critChance;
        float offX   = (h - m_hitsPerAttack / 2) * 0.4f;
        Projectile p;
        p.x = ox + offX;   p.y = oy;
        p.tx = m_node.cx + offX * 0.3f;
        p.ty = m_node.cy;
        p.t = 0.f;
        p.power = power * (boost ? 2.5f : 1.f) * (crit ? m_critMult : 1.f);
        p.crit  = crit;
        p.chain = m_chainHits;
        p.alive = true;
        m_projs.push_back(p);
    }
}

void Game::dealDamage(float rawPower, bool crit, int /*chain*/) {
    if (!m_node.alive) return;

    // Shield absorbs damage first (bypass reduces shield effectiveness)
    float bypassFactor = m_shieldBypass;   // fraction that ignores shield
    float hpDmg     = rawPower * bypassFactor;
    float shieldDmg = rawPower * (1.f - bypassFactor);

    float actualShieldDmg = std::min(m_node.shield, shieldDmg);
    m_node.shield -= actualShieldDmg;
    // Overflow shield damage passes to HP
    float overflow = shieldDmg - actualShieldDmg;
    m_node.hp -= (hpDmg + overflow);

    // Floating text
    FloatText ft;
    ft.x    = m_node.cx + ((float)rand()/RAND_MAX - 0.5f) * m_node.radius;
    ft.y    = m_node.cy - m_node.radius * 0.5f;
    ft.vy   = -2.5f;
    ft.value= (long)rawPower;
    ft.crit = crit;
    ft.life = crit ? 1.5f : 1.0f;
    ft.alive= true;
    m_floats.push_back(ft);

    if (m_node.hp <= 0.f) {
        m_node.hp = 0.f;
        onNodeDead();
    }
}

void Game::onNodeDead() {
    m_node.alive = false;
    // Award resources & XP
    int res = (int)(m_node.resourceReward * m_resourceMult);
    int xp  = (int)(m_node.xpReward       * m_xpMult);
    awardXP(xp);
    m_save.totalResources  += res;
    m_save.totalNodesbusted++;
    writeSave();

    // Floating "+RES" text
    FloatText ft;
    ft.x = m_node.cx; ft.y = m_node.cy;
    ft.vy = -3.5f; ft.value = res; ft.life = 2.f; ft.crit = true; ft.alive = true;
    m_floats.push_back(ft);

    LOGI("Node dead. res=%d xp=%d totalBusted=%lld", res, xp, (long long)m_save.totalNodesbusted);
    advanceNode();
}

void Game::advanceNode() {
    if (m_nodeIndex >= m_nodesInLevel) {
        // Level complete!
        m_levelClearT = 0.f;
        m_screen = Screen::LEVEL_CLEAR;
        if (m_save.currentLevel < 20) m_save.currentLevel++;
        writeSave();
    } else {
        m_nodeIndex++;
        buildNode();
    }
}

void Game::awardXP(int v) {
    m_save.xp += v;
    int64_t need = (int64_t)m_save.level * 120;
    while (m_save.xp >= need) {
        m_save.xp -= need;
        m_save.level++;
        m_save.upgradePoints++;
        need = (int64_t)m_save.level * 120;
        LOGI("Level up! lv=%d pts=%d", m_save.level, m_save.upgradePoints);
    }
}

// ─────────────────────────────────────────────────────────────
//  Touch input
// ─────────────────────────────────────────────────────────────
void Game::onTouch(float sx, float sy, int sw, int sh) {
    float wx = (sx / sw) * m_rend.worldW();
    float wy = (sy / sh) * Renderer::WORLD_H;

    // ── Skill tree screen ────────────────────────────────────
    if (m_screen == Screen::SKILL_TREE) {
        // Skill nodes
        for (int i = 0; i < NUM_SKILLS; ++i) {
            float nx, ny, nw, nh;
            skillRect(i, nx, ny, nw, nh);
            if (wx>=nx && wx<=nx+nw && wy>=ny && wy<=ny+nh) {
                int lvl = m_save.skillLevels[i];
                if (lvl < SKILL_DEFS[i].maxLvl && m_save.upgradePoints >= SKILL_DEFS[i].cost) {
                    m_save.upgradePoints -= SKILL_DEFS[i].cost;
                    m_save.skillLevels[i]++;
                    recomputeStats();
                    writeSave();
                }
                return;
            }
        }
        // Play button
        float W = m_rend.worldW(), H = Renderer::WORLD_H;
        float bx=W*0.2f, by=H*0.88f, bw=W*0.6f, bh=H*0.075f;
        if (wx>=bx && wx<=bx+bw && wy>=by && wy<=by+bh) {
            startLevel(m_save.currentLevel);
        }
        return;
    }

    // ── Level clear screen ───────────────────────────────────
    if (m_screen == Screen::LEVEL_CLEAR) {
        startSkillTree();
        return;
    }

    // ── Playing screen ───────────────────────────────────────
    if (m_screen == Screen::PLAYING) {
        m_touching = true;
        float W = m_rend.worldW(), H = Renderer::WORLD_H;

        // Boost button (bottom-right)
        float bbx = W - 2.6f, bby = H - 2.0f;
        if (wx>=bbx && wy>=bby && boostAvailable()) {
            m_boost.active   = true;
            m_boost.duration = m_boost.maxDur;
            m_boost.cooldown = m_boost.maxCool;
            return;
        }

        // Tap on node = manual hit
        float dx = wx - m_node.cx, dy = wy - m_node.cy;
        float tapR = m_node.radius * 1.5f;
        if (dx*dx + dy*dy < tapR*tapR && m_node.alive) {
            attackNode(m_attackPower * 1.5f, true);
        }
    }
}

void Game::onTouchRelease() { m_touching = false; }

// ─────────────────────────────────────────────────────────────
//  Update
// ─────────────────────────────────────────────────────────────
void Game::update() {
    if (m_screen == Screen::PLAYING)    updatePlaying();
    if (m_screen == Screen::LEVEL_CLEAR) {
        m_levelClearT += DT;
        if (m_levelClearT > 3.0f) startSkillTree();
    }
}

void Game::updatePlaying() {
    // Auto-attack timer
    m_autoTimer += DT;
    if (m_autoTimer >= m_attackInterval && m_node.alive) {
        m_autoTimer = 0.f;
        attackNode(m_attackPower, false);
    }

    // Boost tick
    if (m_boost.active) {
        m_boost.duration -= DT;
        if (m_boost.duration <= 0.f) { m_boost.active = false; m_boost.duration = 0.f; }
    } else if (m_boost.cooldown > 0.f) {
        m_boost.cooldown -= DT;
        if (m_boost.cooldown < 0.f) m_boost.cooldown = 0.f;
    }

    // Shield regen (slow, only for boss)
    if (m_node.alive && m_node.isBoss && m_node.shield < m_node.maxShield) {
        m_node.shield += m_node.maxShield * 0.008f * DT * 60.f;
        m_node.shield = std::min(m_node.shield, m_node.maxShield);
    }

    // Node pulse animation
    m_node.pulseT += DT * 2.5f;

    // Move projectiles
    for (auto& p : m_projs) {
        if (!p.alive) continue;
        p.t += DT * 3.5f;
        if (p.t >= 1.f) {
            p.alive = false;
            if (m_node.alive) dealDamage(p.power, p.crit, p.chain);
        }
    }

    // Float texts
    for (auto& ft : m_floats) {
        if (!ft.alive) continue;
        ft.y   += ft.vy * DT;
        ft.life -= DT;
        if (ft.life <= 0.f) ft.alive = false;
    }

    // Purge dead
    m_projs.erase(std::remove_if(m_projs.begin(), m_projs.end(),
        [](const Projectile& p){ return !p.alive; }), m_projs.end());
    m_floats.erase(std::remove_if(m_floats.begin(), m_floats.end(),
        [](const FloatText& f){ return !f.alive; }), m_floats.end());
}

// ─────────────────────────────────────────────────────────────
//  Skill grid layout  (3 cols × 3 rows)
// ─────────────────────────────────────────────────────────────
void Game::skillRect(int i, float& ox, float& oy, float& ow, float& oh) const {
    float W = m_rend.worldW();
    float pad = W * 0.035f;
    float topY = Renderer::WORLD_H * 0.12f;
    float botY = Renderer::WORLD_H * 0.85f;
    int   cols = 3, rows = 3;
    float totalW = W - 2.f * pad;
    float totalH = botY - topY;
    ow = (totalW - pad * (cols - 1)) / cols;
    oh = (totalH - pad * (rows - 1)) / rows;
    int col = i % cols, row = i / cols;
    ox = pad + col * (ow + pad);
    oy = topY + row * (oh + pad);
}

// ─────────────────────────────────────────────────────────────
//  Render
// ─────────────────────────────────────────────────────────────
void Game::render() {
    m_rend.beginFrame();
    switch (m_screen) {
        case Screen::PLAYING:     renderPlaying();    break;
        case Screen::SKILL_TREE:  renderSkillTree();  break;
        case Screen::LEVEL_CLEAR: renderPlaying();
                                  renderLevelClear(); break;
    }
    m_rend.endFrame();
}

// ── Playing screen ───────────────────────────────────────────
void Game::renderPlaying() {
    float W = m_rend.worldW(), H = Renderer::WORLD_H;

    // ── Background grid ──────────────────────────────────────
    for (int i = 1; i < 8; ++i) {
        float gx = (float)i / 8.f * W;
        m_rend.drawRect(gx, 0, 0.02f, H, 0.1f,0.1f,0.2f, 0.25f);
    }
    for (int i = 1; i < 12; ++i) {
        float gy = (float)i / 12.f * H;
        m_rend.drawRect(0, gy, W, 0.02f, 0.1f,0.1f,0.2f, 0.25f);
    }

    // ── Node ────────────────────────────────────────────────
    if (m_node.alive || m_screen == Screen::LEVEL_CLEAR) {
        float pulse = sinf(m_node.pulseT) * 0.08f;
        float r = m_node.r, g = m_node.g, b = m_node.b;

        // Glow ring
        m_rend.drawCircle(m_node.cx, m_node.cy, m_node.radius + 0.5f + pulse,
                          r*0.4f, g*0.4f, b*0.4f, 0.35f);

        // Shield ring (if any)
        if (m_node.shield > 0.f) {
            float sf = m_node.shield / m_node.maxShield;
            m_rend.drawCircleBorder(m_node.cx, m_node.cy,
                                    m_node.radius + 0.25f, 0.2f,
                                    0.4f, 0.7f, 1.f, sf * 0.7f);
        }

        // Core shape
        switch (m_node.shape) {
            case NodeShape::CIRCLE:
                m_rend.drawCircle(m_node.cx, m_node.cy, m_node.radius + pulse, r, g, b);
                m_rend.drawCircle(m_node.cx, m_node.cy, m_node.radius*0.6f,    r*0.6f,g*0.6f,b*0.6f);
                break;
            case NodeShape::HEX:
                m_rend.drawHexagon(m_node.cx, m_node.cy, m_node.radius + pulse, r, g, b);
                m_rend.drawHexagon(m_node.cx, m_node.cy, m_node.radius*0.55f,   r*0.5f,g*0.5f,b*0.5f);
                break;
            case NodeShape::SQUARE: {
                float s = m_node.radius + pulse;
                m_rend.drawRect(m_node.cx-s, m_node.cy-s, s*2,s*2, r,g,b);
                m_rend.drawRect(m_node.cx-s*0.5f, m_node.cy-s*0.5f, s,s, r*0.5f,g*0.5f,b*0.5f);
                break;
            }
            case NodeShape::DIAMOND: {
                // Draw as rotated-square look using two overlapping quads
                float s = m_node.radius + pulse;
                m_rend.drawHexagon(m_node.cx, m_node.cy, s, r,g,b); // approximate
                m_rend.drawCircle(m_node.cx, m_node.cy, s*0.5f, r*0.6f,g*0.6f,b*0.6f);
                break;
            }
        }

        // Boss crown indicator
        if (m_node.isBoss) {
            m_rend.drawCircle(m_node.cx, m_node.cy - m_node.radius - 0.7f, 0.25f,
                              1.f, 0.85f, 0.1f);
        }

        // HP bar (below node)
        float bw = m_node.radius * 2.8f;
        float bx = m_node.cx - bw * 0.5f;
        float by = m_node.cy + m_node.radius + 0.4f;
        float hp_fill = m_node.hp / m_node.maxHp;
        m_rend.drawBar(bx, by,   bw, 0.28f, hp_fill,
                       0.2f,0.05f,0.05f, r*0.8f,g*0.8f,b*0.8f);
        m_rend.drawRectBorder(bx, by, bw, 0.28f, 0.04f, 0.8f,0.8f,0.9f, 0.4f);

        // Shield bar (if any)
        if (m_node.maxShield > 0.f) {
            float sf = m_node.shield / m_node.maxShield;
            m_rend.drawBar(bx, by+0.34f, bw, 0.18f, sf,
                           0.1f,0.1f,0.2f, 0.3f,0.6f,1.f);
        }
    }

    // ── Projectiles ──────────────────────────────────────────
    for (auto& p : m_projs) {
        if (!p.alive) continue;
        float px = p.x + (p.tx - p.x) * p.t;
        float py = p.y + (p.ty - p.y) * p.t;
        float pr = p.crit ? 0.22f : 0.14f;
        if (p.crit)
            m_rend.drawCircle(px, py, pr + 0.1f, 1.f,0.6f,0.1f, 0.5f);
        m_rend.drawCircle(px, py, pr,
            p.crit ? 1.f : 0.5f,
            p.crit ? 0.9f: 0.95f,
            p.crit ? 0.1f: 1.f);
    }

    // ── Floating damage numbers ──────────────────────────────
    for (auto& ft : m_floats) {
        if (!ft.alive) continue;
        float alpha = ft.life > 0.5f ? 1.f : ft.life / 0.5f;
        float ch = ft.crit ? 0.6f : 0.38f;
        float fr = ft.crit ? 1.f : 0.9f;
        float fg = ft.crit ? 0.8f : 0.9f;
        float fb = ft.crit ? 0.1f : 0.9f;
        (void)alpha;
        m_rend.drawNumber(ft.value, ft.x - (long)ft.value > 9 ? 0.5f : 0.25f,
                          ft.y, ch, fr, fg, fb);
    }

    // ── Shooter (player icon at bottom) ──────────────────────
    float W2 = W * 0.5f;
    m_rend.drawCircle(W2, H*0.85f, 0.45f, 0.3f,0.9f,1.0f);
    m_rend.drawRect(W2-0.08f, H*0.85f-0.65f, 0.16f, 0.55f, 0.3f,0.9f,1.0f);

    // ── Boost button (bottom-right) ──────────────────────────
    float bbx = W - 2.4f, bby = H - 1.85f;
    float br, bg, bb;
    if (m_boost.active)       { br=1.f; bg=0.7f; bb=0.0f; }
    else if (boostAvailable()) { br=0.2f; bg=1.f; bb=0.5f; }
    else                      { br=0.3f; bg=0.3f; bb=0.35f;}
    m_rend.drawCircle(bbx + 0.9f, bby + 0.9f, 0.95f, br*0.3f, bg*0.3f, bb*0.3f);
    m_rend.drawCircle(bbx + 0.9f, bby + 0.9f, 0.75f, br, bg, bb);
    // Boost cooldown arc (just a bar)
    if (!m_boost.active && m_boost.cooldown > 0.f) {
        float cf = 1.f - m_boost.cooldown / m_boost.maxCool;
        m_rend.drawBar(bbx, bby + 1.9f, 1.8f, 0.18f, cf,
                       0.1f,0.1f,0.15f, 0.2f,0.8f,0.4f);
    }

    // ── HUD ──────────────────────────────────────────────────
    renderHUD();
}

void Game::renderHUD() {
    float W = m_rend.worldW(), H = Renderer::WORLD_H;

    // HP → here it's really a progress bar showing node index
    // Top strip: level | node progress | xp
    m_rend.drawRect(0, 0, W, H*0.085f, 0.05f,0.05f,0.1f);

    // Player level (left)
    m_rend.drawNumber(m_save.level, 0.25f, H*0.008f, H*0.065f, 0.9f,0.9f,0.3f);

    // XP bar (centre)
    float xpW = W * 0.45f;
    float xpX = (W - xpW) * 0.5f;
    int64_t need = (int64_t)m_save.level * 120;
    float xpFill = need > 0 ? (float)m_save.xp / need : 1.f;
    m_rend.drawBar(xpX, H*0.012f, xpW, H*0.06f, xpFill,
                   0.08f,0.08f,0.2f, 0.25f,0.35f,0.95f);
    m_rend.drawRectBorder(xpX, H*0.012f, xpW, H*0.06f, 0.03f,
                          0.4f,0.5f,0.9f, 0.5f);

    // Upgrade points (right)
    if (m_save.upgradePoints > 0)
        m_rend.drawNumber(m_save.upgradePoints, W - 1.4f, H*0.008f, H*0.065f, 0.3f,1.f,0.5f);

    // Node progress dots at bottom
    float dotR = 0.22f;
    float startX = (W - (m_nodesInLevel * (dotR*2.5f))) * 0.5f;
    for (int i = 1; i <= m_nodesInLevel; ++i) {
        float dx = startX + i * (dotR*2.5f);
        float dy = H - 0.55f;
        bool  done = (i < m_nodeIndex) || !m_node.alive;
        bool  cur  = (i == m_nodeIndex) && m_node.alive;
        bool  boss = (i == m_nodesInLevel);
        float dr = boss ? 0.9f : (done ? 0.3f : 0.5f);
        float dg = boss ? 0.2f : (done ? 0.9f : 0.5f);
        float db = boss ? 0.9f : (done ? 0.4f : 0.5f);
        m_rend.drawCircle(dx, dy, cur ? dotR*1.5f : dotR, dr, dg, db);
    }
}

// ── Skill tree ────────────────────────────────────────────────
void Game::renderSkillTree() {
    float W = m_rend.worldW(), H = Renderer::WORLD_H;

    // Subtle grid
    for (int i=1;i<10;++i) {
        m_rend.drawRect((float)i/10.f*W, 0, 0.02f, H, 0.12f,0.12f,0.22f, 0.3f);
        m_rend.drawRect(0, (float)i/10.f*H, W, 0.02f, 0.12f,0.12f,0.22f, 0.3f);
    }

    // Top bar
    m_rend.drawRect(0, 0, W, H*0.10f, 0.06f,0.06f,0.12f);
    m_rend.drawRect(W*0.1f, H*0.015f, W*0.8f, 0.04f, 0.25f,0.45f,0.9f);
    m_rend.drawRect(W*0.1f, H*0.073f, W*0.8f, 0.04f, 0.25f,0.45f,0.9f);
    // Level left, pts right
    m_rend.drawNumber(m_save.level,          0.25f, H*0.012f, H*0.068f, 0.9f,0.9f,0.3f);
    m_rend.drawNumber(m_save.upgradePoints,  W*0.62f, H*0.012f, H*0.068f, 0.3f,1.f,0.5f);

    // Skill nodes
    static const float SR[] = {1.f,0.4f,0.9f,0.2f,0.3f,1.f,0.5f,0.8f,0.3f};
    static const float SG[] = {0.4f,0.9f,0.3f,1.f,0.6f,0.5f,0.9f,0.4f,0.8f};
    static const float SB[] = {0.4f,0.3f,0.9f,0.5f,1.f,0.3f,0.2f,1.f,0.5f};

    for (int i = 0; i < NUM_SKILLS; ++i) {
        float nx, ny, nw, nh;
        skillRect(i, nx, ny, nw, nh);

        int  lvl    = m_save.skillLevels[i];
        int  maxL   = SKILL_DEFS[i].maxLvl;
        int  cost   = SKILL_DEFS[i].cost;
        bool afford = (m_save.upgradePoints >= cost) && (lvl < maxL);
        bool maxed  = (lvl >= maxL);

        float bgr = maxed ? 0.08f : (afford ? 0.08f : 0.07f);
        float bgg = maxed ? 0.18f : (afford ? 0.12f : 0.08f);
        float bgb = maxed ? 0.08f : (afford ? 0.20f : 0.12f);
        m_rend.drawRect(nx, ny, nw, nh, bgr, bgg, bgb);
        m_rend.drawRectBorder(nx, ny, nw, nh, 0.05f,
            maxed ? SR[i]*0.5f : (afford ? SR[i] : 0.25f),
            maxed ? SG[i]*0.5f : (afford ? SG[i] : 0.3f),
            maxed ? SB[i]*0.5f : (afford ? SB[i] : 0.35f));

        // Level pips
        float pipW = (nw - 0.3f) / maxL - 0.08f;
        float pipH = nh * 0.09f;
        for (int p = 0; p < maxL; ++p) {
            float px = nx + 0.15f + p*(pipW+0.08f);
            float py = ny + nh*0.055f;
            m_rend.drawRect(px, py, pipW, pipH,
                p < lvl ? SR[i] : 0.2f,
                p < lvl ? SG[i] : 0.25f,
                p < lvl ? SB[i] : 0.3f);
        }

        // Icon circle
        float icx = nx + nw*0.2f, icy = ny + nh*0.55f, icr = nh*0.22f;
        m_rend.drawCircle(icx, icy, icr+0.07f, SR[i]*0.3f, SG[i]*0.3f, SB[i]*0.3f, 0.5f);
        m_rend.drawCircle(icx, icy, icr, SR[i], SG[i], SB[i]);

        // Cost badge (bottom right)
        if (!maxed) {
            m_rend.drawNumber(cost, nx+nw*0.74f, ny+nh*0.73f, nh*0.18f,
                afford ? 0.3f:0.6f, afford ? 1.f:0.4f, afford ? 0.5f:0.4f);
        }
    }

    // Play / resume button
    float bx=W*0.2f, by=H*0.88f, bw=W*0.6f, bh=H*0.075f;
    m_rend.drawRect(bx, by, bw, bh, 0.08f, 0.40f, 0.15f);
    m_rend.drawRectBorder(bx, by, bw, bh, 0.05f, 0.2f, 1.f, 0.4f);
    // Level number inside button
    m_rend.drawNumber(m_save.currentLevel, bx+bw*0.44f, by+bh*0.15f, bh*0.65f, 0.4f, 1.f, 0.6f);

    // Stats strip at bottom
    m_rend.drawRect(0, H*0.965f, W, H*0.035f, 0.05f,0.05f,0.1f);
    m_rend.drawNumber((long)m_save.totalNodesbusted, 0.2f, H*0.967f, H*0.027f, 0.5f,0.5f,0.7f);
    m_rend.drawNumber((long)m_save.totalResources,   W*0.5f, H*0.967f, H*0.027f, 0.5f,0.7f,0.5f);
}

// ── Level clear banner ────────────────────────────────────────
void Game::renderLevelClear() {
    float W = m_rend.worldW(), H = Renderer::WORLD_H;
    m_rend.drawRect(0, 0, W, H, 0,0,0, 0.55f);
    float bw=W*0.7f, bh=H*0.16f;
    float bx=(W-bw)*0.5f, by=H*0.40f;
    m_rend.drawRect(bx, by, bw, bh, 0.06f,0.35f,0.12f, 0.92f);
    m_rend.drawRectBorder(bx, by, bw, bh, 0.07f, 0.2f, 1.f, 0.4f);
    // Level number
    m_rend.drawNumber(m_save.currentLevel - 1, bx+bw*0.42f, by+bh*0.12f, bh*0.72f, 0.5f,1.f,0.6f);
    // Tap hint line
    m_rend.drawRect((W-bw*0.6f)*0.5f, by+bh+0.5f, bw*0.6f, 0.05f, 0.3f,0.8f,0.4f, 0.5f);
}
