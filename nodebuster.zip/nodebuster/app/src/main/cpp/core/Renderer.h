#pragma once
#include <GLES2/gl2.h>

class Renderer {
public:
    static constexpr float WORLD_H = 20.0f;

    void init();
    void resize(int screenW, int screenH);
    void beginFrame();
    void endFrame();

    void drawRect      (float x, float y, float w, float h,
                        float r, float g, float b, float a = 1.f);
    void drawRectBorder(float x, float y, float w, float h, float thick,
                        float r, float g, float b, float a = 1.f);
    void drawCircle    (float cx, float cy, float radius,
                        float r, float g, float b, float a = 1.f);
    void drawCircleBorder(float cx, float cy, float radius, float thick,
                          float r, float g, float b, float a = 1.f);
    void drawBar       (float x, float y, float w, float h, float fill,
                        float br, float bg, float bb,
                        float fr, float fg, float fb);
    void drawHexagon   (float cx, float cy, float radius,
                        float r, float g, float b, float a = 1.f);
    void drawNumber    (long n, float x, float y, float charH,
                        float r, float g, float b);

    float worldW() const { return m_worldW; }
    float worldH() const { return WORLD_H;  }

private:
    inline float toNdcX(float gx) const { return (gx / m_worldW) * 2.f - 1.f; }
    inline float toNdcY(float gy) const { return 1.f - (gy / WORLD_H) * 2.f; }

    void drawQuadNDC(float x1, float y1, float x2, float y2,
                     float r, float g, float b, float a);
    void drawDigit(int d, float x, float y, float h,
                   float r, float g, float b);

    GLuint m_prog  = 0;
    GLint  m_aPos  = -1;
    GLint  m_uCol  = -1;

    int   m_screenW = 1, m_screenH = 1;
    float m_worldW  = WORLD_H;
};
