#pragma once
#include "Renderer.h"
#include <vector>
#include <string>
#include <cstdint>
#include <cmath>

// ─────────────────────────────────────────────────────────────
//  Persistent save  (written to disk on every meaningful event)
// ─────────────────────────────────────────────────────────────
static constexpr int NUM_SKILLS = 9;

struct SaveData {
    uint32_t magic           = 0xAB020002u;
    int      level           = 1;          // player level
    int64_t  xp              = 0;          // xp toward next level
    int      upgradePoints   = 0;          // spendable skill pts
    int      skillLevels[NUM_SKILLS] = {}; // 0-based per skill
    int      currentLevel    = 1;          // node-level progress (1-20)
    int64_t  totalNodesbusted= 0;
    int64_t  totalResources  = 0;          // lifetime resources collected
};

// ─────────────────────────────────────────────────────────────
//  Skill table
// ─────────────────────────────────────────────────────────────
struct SkillDef { const char* id; int maxLvl; int cost; };
static const SkillDef SKILL_DEFS[NUM_SKILLS] = {
    { "PWR", 6, 1 },   // 0 – click / auto-attack power
    { "SPD", 5, 1 },   // 1 – auto-attack speed
    { "MLT", 4, 2 },   // 2 – hits per attack
    { "RES", 5, 1 },   // 3 – resource multiplier
    { "XPB", 4, 1 },   // 4 – xp multiplier
    { "CRT", 4, 2 },   // 5 – critical hit chance
    { "CDR", 3, 1 },   // 6 – boost cooldown reduction
    { "ARC", 3, 2 },   // 7 – chain hits (piercing arcs)
    { "SHD", 3, 1 },   // 8 – node-HP shield bypass %
};

// ─────────────────────────────────────────────────────────────
//  Node types
// ─────────────────────────────────────────────────────────────
enum class NodeShape { CIRCLE, HEX, SQUARE, DIAMOND };

struct Node {
    float    cx, cy;           // centre in world units
    float    radius;           // visual radius
    float    hp, maxHp;
    float    shield;           // current shield hp (regenerates)
    float    maxShield;
    NodeShape shape;
    bool     isBoss;
    bool     alive = true;
    float    pulseT = 0.f;     // animation timer
    float    r, g, b;          // colour
    int      resourceReward;
    int      xpReward;
};

// ─────────────────────────────────────────────────────────────
//  Projectile (auto-fire visual effect only)
// ─────────────────────────────────────────────────────────────
struct Projectile {
    float x, y, tx, ty;   // start, target
    float t = 0.f;         // 0→1 travel progress
    float power;           // damage it will deal on arrival
    bool  alive = true;
    bool  crit  = false;
    int   chain = 0;       // remaining chain hits
};

// ─────────────────────────────────────────────────────────────
//  Floating damage number
// ─────────────────────────────────────────────────────────────
struct FloatText {
    float x, y, vy;
    long  value;
    float life = 1.2f;
    bool  crit = false;
    bool  alive = true;
};

// ─────────────────────────────────────────────────────────────
//  Boost bar
// ─────────────────────────────────────────────────────────────
struct Boost {
    float cooldown  = 0.f;   // seconds remaining on cooldown
    float maxCool   = 12.f;
    float duration  = 0.f;   // seconds remaining active
    float maxDur    = 4.f;
    bool  active    = false;
};

// ─────────────────────────────────────────────────────────────
//  Screen states
// ─────────────────────────────────────────────────────────────
enum class Screen { SKILL_TREE, PLAYING, LEVEL_CLEAR };

// ─────────────────────────────────────────────────────────────
//  Game singleton
// ─────────────────────────────────────────────────────────────
class Game {
public:
    static Game& get();

    void init  (const char* savePath, int w, int h);
    void resize(int w, int h);
    void update();
    void render();
    void onTouch(float sx, float sy, int sw, int sh);
    void onTouchRelease();

private:
    Renderer    m_rend;
    std::string m_savePath;
    SaveData    m_save;

    // ── Derived stats (from skills) ──────────────────────────
    float m_attackPower;    // base damage per hit
    float m_attackInterval; // seconds between auto-attacks
    int   m_hitsPerAttack;
    float m_resourceMult;
    float m_xpMult;
    float m_critChance;     // 0–1
    float m_critMult = 2.5f;
    float m_boostCoolMult;
    int   m_chainHits;
    float m_shieldBypass;   // fraction bypassed

    void recomputeStats();

    // ── Persistence ──────────────────────────────────────────
    void loadSave();
    void writeSave();

    // ── Session state ────────────────────────────────────────
    Screen  m_screen      = Screen::SKILL_TREE;
    float   m_autoTimer   = 0.f;
    float   m_levelClearT = 0.f;
    bool    m_touching    = false;

    Node    m_node;         // one node on screen at a time
    int     m_nodeIndex;    // which node in the level (1-based)
    int     m_nodesInLevel; // total nodes this level (last = boss)

    std::vector<Projectile> m_projs;
    std::vector<FloatText>  m_floats;
    Boost   m_boost;

    // ── Helpers ──────────────────────────────────────────────
    void buildNode();
    void attackNode(float power, bool fromTap);
    void dealDamage(float rawPower, bool crit, int chain);
    void onNodeDead();
    void advanceNode();
    void startLevel(int lv);
    void startSkillTree();
    void awardXP(int v);

    void updatePlaying();
    void renderPlaying();
    void renderSkillTree();
    void renderHUD();
    void renderLevelClear();

    void skillRect(int i, float& x, float& y, float& w, float& h) const;
    bool boostAvailable() const { return !m_boost.active && m_boost.cooldown <= 0.f; }
};
