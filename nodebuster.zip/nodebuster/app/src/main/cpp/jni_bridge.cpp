#include <jni.h>
#include "core/Game.h"

extern "C" {

JNIEXPORT void JNICALL
Java_com_goblobin_nodebuster_GameBridge_init(JNIEnv* env, jobject /*obj*/,
                                              jstring savePath) {
    const char* path = env->GetStringUTFChars(savePath, nullptr);
    Game::get().init(path, 1, 1);
    env->ReleaseStringUTFChars(savePath, path);
}

JNIEXPORT void JNICALL
Java_com_goblobin_nodebuster_GameBridge_resize(JNIEnv* /*env*/, jobject /*obj*/,
                                                jint w, jint h) {
    Game::get().resize(w, h);
}

JNIEXPORT void JNICALL
Java_com_goblobin_nodebuster_GameBridge_update(JNIEnv* /*env*/, jobject /*obj*/) {
    Game::get().update();
}

JNIEXPORT void JNICALL
Java_com_goblobin_nodebuster_GameBridge_render(JNIEnv* /*env*/, jobject /*obj*/) {
    Game::get().render();
}

JNIEXPORT void JNICALL
Java_com_goblobin_nodebuster_GameBridge_onTouch(JNIEnv* /*env*/, jobject /*obj*/,
                                                  jfloat x, jfloat y,
                                                  jint sw, jint sh) {
    Game::get().onTouch(x, y, sw, sh);
}

JNIEXPORT void JNICALL
Java_com_goblobin_nodebuster_GameBridge_onTouchRelease(JNIEnv* /*env*/, jobject /*obj*/) {
    Game::get().onTouchRelease();
}

} // extern "C"
