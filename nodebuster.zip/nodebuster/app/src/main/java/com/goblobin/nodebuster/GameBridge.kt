package com.goblobin.nodebuster

/**
 * JNI bridge to the native game engine.
 * All GL calls must originate from the GL thread.
 */
object GameBridge {

    init {
        System.loadLibrary("nodebuster")
    }

    /** Called once on GL context creation. savePath = writable file for persistence. */
    external fun init(savePath: String)

    /** Called when surface dimensions change. */
    external fun resize(width: Int, height: Int)

    /** Advance game logic one frame (called from GL thread). */
    external fun update()

    /** Render one frame (called from GL thread after update). */
    external fun render()

    /** Touch down / move event in screen pixels. */
    external fun onTouch(x: Float, y: Float, screenW: Int, screenH: Int)

    /** Touch released. */
    external fun onTouchRelease()
}
