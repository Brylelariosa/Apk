package com.goblobin.nodebuster

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class GameView(context: Context, private val savePath: String) : GLSurfaceView(context) {

    private val renderer = GameRenderer(savePath)

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                queueEvent {
                    GameBridge.onTouch(
                        event.x, event.y,
                        renderer.surfaceWidth, renderer.surfaceHeight
                    )
                }
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                queueEvent { GameBridge.onTouchRelease() }
                true
            }
            else -> false
        }
    }
}

class GameRenderer(private val savePath: String) : GLSurfaceView.Renderer {

    @Volatile var surfaceWidth  = 1
    @Volatile var surfaceHeight = 1

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GameBridge.init(savePath)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth  = width
        surfaceHeight = height
        GameBridge.resize(width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GameBridge.update()
        GameBridge.render()
    }
}
