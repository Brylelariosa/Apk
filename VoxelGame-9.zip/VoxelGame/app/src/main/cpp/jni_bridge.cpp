#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <memory>
#include <string>

#include "core/CrashReporter.h"
#include "core/Renderer.h"
#include "core/World.h"
#include "core/Camera.h"
#include "core/Input.h"
#include "core/BlockDefs.h"
#include "core/MathUtils.h"

#define LOG_TAG "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── Game state ────────────────────────────────────────────────────────────────
static std::unique_ptr<Renderer> g_renderer;
static std::unique_ptr<World>    g_world;
static std::unique_ptr<Camera>   g_camera;
static std::unique_ptr<Input>    g_input;

static int   g_width  = 1, g_height = 1;
static long  g_lastNs = 0;
static bool  g_inited = false;
static int   g_loadFrame = 0;
static int   g_chunksReady = 0;

// Error overlay
static std::string g_errorMsg;          // non-empty = show error screen
static bool        g_showError = false;

// Physics
static float g_velY     = 0.f;
static bool  g_onGround = false;

// Block breaking
static Vec3  g_breakTarget   = {-9999, -9999, -9999};
static float g_breakProgress = 0.f;
static const float BREAK_TIME = 0.6f;

// Settings
static int g_renderDist = 3;  // start low, player can increase with + button

// FPS
static float g_fpsTimer   = 0.f;
static int   g_fpsFrames  = 0;
static int   g_fpsDisplay = 0;

// Hotbar
static uint8_t g_hotbar[9] = {
    BLOCK_GRASS, BLOCK_DIRT, BLOCK_STONE,
    BLOCK_SAND,  BLOCK_LOG,  BLOCK_LEAVES,
    BLOCK_GLOWSTONE, BLOCK_LAVA, BLOCK_SNOW
};
static int g_hotbarSel = 0;

// Crash report path (set from Java)
static char g_crashPath[512] = {};

// ── Time ──────────────────────────────────────────────────────────────────────
static long nowNs() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000L + ts.tv_nsec;
}

// ── Physics ───────────────────────────────────────────────────────────────────
static bool solidAt(const World* w, float x, float y, float z) {
    return blockSolid(w->getBlock((int)floorf(x), (int)floorf(y), (int)floorf(z)));
}
static bool playerOnGround(const World* w, Vec3 pos) {
    float feet = pos.y - 1.85f;
    for (float dx : {-0.28f, 0.28f})
        for (float dz : {-0.28f, 0.28f})
            if (solidAt(w, pos.x+dx, feet, pos.z+dz)) return true;
    return false;
}
static Vec3 collideMove(const World* w, Vec3 pos, Vec3 delta) {
    const float EY = 1.8f;
    float sx = delta.x > 0 ? 0.3f : -0.3f;
    Vec3 nx = {pos.x+delta.x, pos.y, pos.z};
    if (solidAt(w,nx.x+sx,pos.y-EY+0.1f,pos.z)||
        solidAt(w,nx.x+sx,pos.y-EY+0.9f,pos.z)||
        solidAt(w,nx.x+sx,pos.y-0.1f,   pos.z)) delta.x=0;
    float sz = delta.z > 0 ? 0.3f : -0.3f;
    if (solidAt(w,pos.x,pos.y-EY+0.1f,pos.z+delta.z+sz)||
        solidAt(w,pos.x,pos.y-EY+0.9f,pos.z+delta.z+sz)||
        solidAt(w,pos.x,pos.y-0.1f,   pos.z+delta.z+sz)) delta.z=0;
    if (delta.y < 0) {
        bool blocked=false;
        for (float ddx:{-0.28f,0.28f}) for(float ddz:{-0.28f,0.28f})
            if (solidAt(w,pos.x+ddx,pos.y-EY+delta.y,pos.z+ddz)) blocked=true;
        if (blocked){delta.y=0;g_velY=0;}
    }
    if (delta.y > 0 && solidAt(w,pos.x,pos.y+delta.y+0.05f,pos.z)){delta.y=0;g_velY=0;}
    return pos+delta;
}

// ── Render a full-screen red error overlay (no world needed) ──────────────────
static void renderErrorScreen(const std::string& msg) {
    glClearColor(0.12f, 0.02f, 0.02f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // We can't draw text without a font, so we just flash magenta/red
    // so the user knows something went wrong, then log the message.
    LOGE("=== VOXEL ERROR SCREEN ===\n%s", msg.c_str());
    // Alternate red/dark every 30 frames so it's obviously an error state
    static int frame = 0;
    frame++;
    if ((frame / 30) % 2 == 0) {
        glClearColor(0.85f, 0.05f, 0.05f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT);
    }
}

// ── Game tick ─────────────────────────────────────────────────────────────────
static void gameTick(float dt) {
    if (!g_world || !g_camera || !g_input) return;
    if (dt > 0.1f) dt = 0.1f;

    g_fpsTimer  += dt;
    g_fpsFrames += 1;
    if (g_fpsTimer >= 0.5f) {
        g_fpsDisplay = (int)(g_fpsFrames / g_fpsTimer + 0.5f);
        g_fpsTimer = 0; g_fpsFrames = 0;
    }

    if (g_input->isSettingsPlusTap())  g_renderDist = std::min(g_renderDist+1, 32);
    if (g_input->isSettingsMinusTap()) g_renderDist = std::max(g_renderDist-1, 2);

    float dx = g_input->consumeDX() * -0.003f;
    float dy = g_input->consumeDY() *  0.003f;
    g_camera->rotate(dx, dy);

    Vec3 mov = g_input->getMovement();
    float speed = 5.5f;
    Vec3 fwd = g_camera->getForward(); fwd.y=0; fwd=normalize(fwd);
    Vec3 rgt = g_camera->getRight();   rgt.y=0; rgt=normalize(rgt);
    Vec3 movWorld = rgt*(mov.x*speed*dt) + fwd*(-mov.z*speed*dt);

    g_onGround = playerOnGround(g_world.get(), g_camera->getPosition());
    g_velY -= 22.f*dt;
    if (g_onGround && g_velY < 0.f) g_velY = 0.f;
    if (g_input->isJumpPressed() && g_onGround) g_velY = 9.5f;
    movWorld.y = g_velY*dt;

    Vec3 newPos = collideMove(g_world.get(), g_camera->getPosition(), movWorld);
    g_camera->setPosition(newPos);

    Vec3 eye=g_camera->getPosition(), dir=g_camera->getForward();
    Vec3 hitPos, hitNorm;
    bool hasTarget = g_world->raycast(eye, dir, 6.5f, hitPos, hitNorm);

    if (g_input->isPlacePressed() && hasTarget) {
        Vec3 placePos = hitPos+hitNorm;
        int px=(int)placePos.x, py=(int)placePos.y, pz=(int)placePos.z;
        Vec3 ep=g_camera->getPosition();
        int ex=(int)floorf(ep.x), ey=(int)floorf(ep.y), ez=(int)floorf(ep.z);
        if (!(px==ex&&(py==ey||py==ey-1)&&pz==ez))
            g_world->setBlock(px, py, pz, g_hotbar[g_hotbarSel]);
    }

    if (g_input->isBreakHeld() && hasTarget) {
        int hx=(int)floorf(hitPos.x),hy=(int)floorf(hitPos.y),hz=(int)floorf(hitPos.z);
        int tx=(int)g_breakTarget.x, ty=(int)g_breakTarget.y, tz=(int)g_breakTarget.z;
        if (hx==tx&&hy==ty&&hz==tz) {
            g_breakProgress += dt/BREAK_TIME;
            if (g_breakProgress >= 1.f) {
                g_world->setBlock(hx,hy,hz,BLOCK_AIR);
                g_breakProgress=0; g_breakTarget={-9999,-9999,-9999};
            }
        } else {
            g_breakTarget={(float)hx,(float)hy,(float)hz};
            g_breakProgress=0;
        }
    } else { g_breakProgress=0; g_breakTarget={-9999,-9999,-9999}; }

    g_input->clearActions();

    Vec3 pos=g_camera->getPosition();
    g_world->update(pos.x, pos.z, g_renderDist);
}

// ═════════════════════════════════════════════════════════════════════════════
// JNI
// ═════════════════════════════════════════════════════════════════════════════
extern "C" {

// Called FIRST from Java before the GL surface is created.
// Installs crash handler and checks for a previous crash report.
JNIEXPORT jstring JNICALL
Java_com_voxel_game_GameRenderer_nativeSetup(JNIEnv* env, jobject,
                                              jstring jFilesDir) {
    const char* dir = env->GetStringUTFChars(jFilesDir, nullptr);
    snprintf(g_crashPath, sizeof(g_crashPath), "%s/crash.txt", dir);
    env->ReleaseStringUTFChars(jFilesDir, dir);

    // Install crash handler
    installCrashHandler(g_crashPath);
    LOGI("nativeSetup: crash path = %s", g_crashPath);

    // Check for a previous crash report
    std::string report = loadAndClearCrashReport(g_crashPath);
    if (!report.empty()) {
        LOGE("Previous crash found:\n%s", report.c_str());
        return env->NewStringUTF(report.c_str());
    }
    return env->NewStringUTF("");
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit — GL context ready");

    // Check GL version first
    const char* glVer = (const char*)glGetString(GL_VERSION);
    LOGI("GL_VERSION: %s", glVer ? glVer : "null");
    if (!glVer) {
        g_errorMsg = "GL_VERSION is null — OpenGL ES not available on this device.";
        g_showError = true;
        LOGE("%s", g_errorMsg.c_str());
        return;
    }

    g_renderer = std::make_unique<Renderer>();
    if (!g_renderer->init()) {
        g_errorMsg = "Renderer::init() failed — shader compile error. Check logcat.";
        g_showError = true;
        LOGE("%s", g_errorMsg.c_str());
        return;
    }
    LOGI("Renderer OK");

    g_world  = std::make_unique<World>(12345u);
    g_camera = std::make_unique<Camera>();
    g_input  = std::make_unique<Input>();

    g_camera->setPosition({8.f, 100.f, 8.f});
    g_velY   = 0.f;
    g_lastNs = nowNs();
    g_inited = true;
    LOGI("nativeInit complete — all systems go");
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    g_width=w; g_height=h;
    if (g_renderer) g_renderer->resize(w, h);
    if (g_camera)   g_camera->updateProjection((float)w/(float)h);
    if (g_input)    g_input->setScreenSize((float)w,(float)h);
    LOGI("nativeResize %d x %d", w, h);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (g_showError) {
        renderErrorScreen(g_errorMsg);
        return;
    }
    if (!g_inited) return;

    long now=nowNs();
    float dt=(float)(now-g_lastNs)*1e-9f;
    g_lastNs=now;

    gameTick(dt);

    g_renderer->beginFrame();

    // Count ready chunks — show loading screen until at least 4 are ready
    // so the player never stares at a plain blue screen
    g_chunksReady = (int)g_world->chunkCount();

    if (g_chunksReady < 4) {
        g_loadFrame++;
        g_renderer->renderLoading((float)g_width, (float)g_height, g_loadFrame);
        return;
    }

    glUseProgram(g_renderer->getWorldProg());
    Mat4 vp=g_camera->getViewProjection();
    g_world->renderAll(g_renderer->getMVPLoc(), vp.m);

    g_renderer->renderHUD(
        (float)g_width, (float)g_height,
        g_input->joyBaseX(),  g_input->joyBaseY(),
        g_input->joyThumbX(), g_input->joyThumbY(),
        g_input->joyActive(),
        g_breakProgress,
        g_fpsDisplay,
        g_renderDist
    );
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchDown(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchDown(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchMove(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchMove(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchUp(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchUp(id,x,y);
}

} // extern "C"
