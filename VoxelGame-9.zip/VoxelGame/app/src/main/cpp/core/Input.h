#pragma once
#include "MathUtils.h"

enum class ButtonId {
    NONE, JUMP, PLACE, BREAK,
    SETTINGS_PLUS, SETTINGS_MINUS
};

struct TouchPointer {
    int   id       = -1;
    float startX   = 0, startY = 0;
    float currentX = 0, currentY = 0;
    bool  active   = false;
};

class Input {
public:
    static constexpr int   MAX_TOUCH  = 10;
    static constexpr float JOY_RADIUS = 90.f;
    static constexpr float BTN_RADIUS = 65.f;
    static constexpr float SMALL_BTN  = 45.f;

    void setScreenSize(float w, float h);

    void onTouchDown(int id, float x, float y);
    void onTouchMove(int id, float x, float y);
    void onTouchUp  (int id, float x, float y);

    Vec3  getMovement() const;        // x=strafe, z=fwd (-1..1)
    float consumeDX();
    float consumeDY();

    bool isJumpPressed()      const { return jumpPressed;     }
    bool isPlacePressed()     const { return placePressed;    }
    bool isBreakHeld()        const { return breakPtrId >= 0; }
    bool isSettingsPlusTap()  const { return settingsPlusTap; }
    bool isSettingsMinusTap() const { return settingsMinusTap;}

    void clearActions() {
        jumpPressed = placePressed = false;
        settingsPlusTap = settingsMinusTap = false;
    }

    // Joystick HUD — always at fixed position
    float joyBaseX()  const { return fixedJoyX; }
    float joyBaseY()  const { return fixedJoyY; }
    bool  joyActive() const { return joyPtrIdx >= 0; }
    float joyThumbX() const;
    float joyThumbY() const;

private:
    float sw = 1, sh = 1;
    float fixedJoyX = 0, fixedJoyY = 0;

    TouchPointer ptrs[MAX_TOUCH];
    int   joyPtrIdx   = -1;
    int   lookPtrIdx  = -1;
    int   breakPtrId  = -1;   // pointer ID (not slot) of finger on BREAK button
    float lookDX = 0, lookDY = 0;

    bool jumpPressed     = false;
    bool placePressed    = false;
    bool settingsPlusTap = false;
    bool settingsMinusTap= false;

    int      findSlot(int id) const;
    int      allocSlot(int id, float x, float y);
    void     freeSlot(int id);
    ButtonId hitButton(float x, float y) const;
};
