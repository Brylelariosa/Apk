#include "World.h"
#include "BlockDefs.h"
#include <cmath>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)

// ── Constructor / Destructor ──────────────────────────────────────────────────
World::World(uint32_t s) : noise(s), seed(s) {
    workerRunning = true;
    worker = std::thread(&World::workerMain, this);
    LOGI("World created, worker thread started");
}

World::~World() {
    workerRunning = false;
    if (worker.joinable()) worker.join();
}

// ── Block access (GL thread) ──────────────────────────────────────────────────
uint8_t World::getBlock(int x, int y, int z) const {
    if (y < 0 || y >= CH) return 0;
    int cx = (x < 0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z < 0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return 0;
    return it->second->getBlock(x - cx*CW, y, z - cz*CD);
}

void World::setBlock(int x, int y, int z, uint8_t type) {
    if (y < 0 || y >= CH) return;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return;
    it->second->setBlock(x-cx*CW, y, z-cz*CD, type);
    // dirty neighbours
    auto dirty = [&](int ncx, int ncz){
        auto n = chunks.find({ncx,ncz});
        if (n != chunks.end()) n->second->markDirty();
    };
    int lx = x-cx*CW, lz = z-cz*CD;
    if (lx==0)    dirty(cx-1,cz);
    if (lx==CW-1) dirty(cx+1,cz);
    if (lz==0)    dirty(cx,cz-1);
    if (lz==CD-1) dirty(cx,cz+1);
}

Chunk* World::getChunk(int cx, int cz) const {
    auto it = chunks.find({cx,cz});
    return it != chunks.end() ? it->second.get() : nullptr;
}

// ── Worker thread: generate + mesh chunks ────────────────────────────────────
void World::workerMain() {
    while (workerRunning) {
        ChunkKey key{0,0};
        bool hasWork = false;
        {
            std::lock_guard<std::mutex> lk(reqMutex);
            if (!requested.empty()) {
                key = requested.back();
                requested.pop_back();
                inFlight.push_back(key);
                hasWork = true;
            }
        }
        if (hasWork) {
            generateAndMesh(key.x, key.z);
            std::lock_guard<std::mutex> lk(reqMutex);
            inFlight.erase(std::remove_if(inFlight.begin(), inFlight.end(),
                [&](const ChunkKey& k){ return k.x==key.x && k.z==key.z; }),
                inFlight.end());
        } else {
            // nothing to do — sleep briefly to avoid busy-spin
            struct timespec ts{0, 2000000}; // 2ms
            nanosleep(&ts, nullptr);
        }
    }
}

// Worker thread only — has its own local chunk map for cross-chunk meshing
uint8_t World::workerGetBlock(int x, int y, int z,
    const std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash>& local) const
{
    if (y < 0 || y >= CH) return 0;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = local.find({cx,cz});
    if (it == local.end()) return 0;
    return it->second->getBlock(x-cx*CW, y, z-cz*CD);
}

void World::generateAndMesh(int cx, int cz) {
    // Build a small local map with this chunk + its 4 neighbours
    // so the mesh builder can query boundary blocks correctly.
    std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash> local;

    auto makeChunk = [&](int ncx, int ncz) {
        auto c = std::make_unique<Chunk>(ncx, ncz);
        generateChunk(c.get());
        local[{ncx,ncz}] = std::move(c);
    };
    makeChunk(cx,   cz  );
    makeChunk(cx-1, cz  );
    makeChunk(cx+1, cz  );
    makeChunk(cx,   cz-1);
    makeChunk(cx,   cz+1);

    // Mesh only the centre chunk
    auto worldGet = [&](int x, int y, int z) -> uint8_t {
        return workerGetBlock(x, y, z, local);
    };
    local[{cx,cz}]->buildMesh(worldGet);

    // Hand the finished chunk to GL thread via results queue
    std::lock_guard<std::mutex> lk(resMutex);
    results.push_back({cx, cz, std::move(local[{cx,cz}])});
}

// ── Terrain generation ────────────────────────────────────────────────────────
void World::generateChunk(Chunk* c) {
    const int wx0 = c->getChunkX()*CW;
    const int wz0 = c->getChunkZ()*CD;
    float tempOff  = noise.noise2D(wx0/300.f+500, wz0/300.f)*0.5f+0.5f;

    for (int lx = 0; lx < CW; lx++) {
        for (int lz = 0; lz < CD; lz++) {
            float wx = (float)(wx0+lx), wz = (float)(wz0+lz);
            float h  = noise.fbm(wx/120.f, wz/120.f, 5);   // 5 octaves (was 6)
            float h2 = noise.fbm(wx/40.f+7, wz/40.f+3, 3)*0.3f;
            int height = 60 + (int)((h+h2)*28.f);
            height = std::max(2, std::min(CH-2, height));

            float temp = tempOff + noise.noise2D(wx/80.f, wz/80.f)*0.15f;

            uint8_t surface = BLOCK_GRASS, sub = BLOCK_DIRT;
            if      (height <= 61)  { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp > 0.65f)  { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp < 0.35f)  { surface=BLOCK_SNOW; }
            else if (height > 90)   { surface=BLOCK_SNOW; }

            for (int y = 0; y <= height; y++) {
                uint8_t type;
                if      (y == height)        type = surface;
                else if (y >= height-3)      type = sub;
                else                         type = BLOCK_STONE;

                if (type == BLOCK_STONE) {
                    float ore = noise.noise3D(wx/8.f,(float)y/8.f,wz/8.f);
                    if      (ore>0.45f && y<30) type=BLOCK_COAL;
                    else if (ore>0.47f && y<50) type=BLOCK_IRON;
                    else if (ore>0.48f && y<20) type=BLOCK_GLOWSTONE;
                }
                c->setBlock(lx, y, lz, type);
            }
            for (int y = height+1; y <= 60; y++)
                c->setBlock(lx, y, lz, BLOCK_WATER);

            if (surface==BLOCK_GRASS && lx>=2&&lx<=CW-3&&lz>=2&&lz<=CD-3) {
                uint32_t rng=(uint32_t)((wx0+lx)*73856093^(wz0+lz)*19349663^seed);
                rng=rng*1664525u+1013904223u;
                if ((rng%50)==0) placeTree(c,lx,height+1,lz);
            }
        }
    }
    c->markDirty();
}

void World::placeTree(Chunk* c, int lx, int y, int lz) {
    for (int i=0;i<5;i++) c->setBlock(lx,y+i,lz,BLOCK_LOG);
    for (int dy=3;dy<=5;dy++) {
        int r=(dy<5)?2:1;
        for (int dx=-r;dx<=r;dx++)
            for (int dz=-r;dz<=r;dz++)
                if (abs(dx)+abs(dz)<=r+1)
                    c->setBlock(lx+dx,y+dy,lz+dz,BLOCK_LEAVES);
    }
}

// ── Update (GL thread) ────────────────────────────────────────────────────────
void World::update(float px, float pz, int renderDist) {
    int pcx = (int)floorf(px/CW);
    int pcz = (int)floorf(pz/CD);

    // 1. Collect which keys are needed
    std::vector<ChunkKey> needed;
    for (int dx=-renderDist;dx<=renderDist;dx++)
        for (int dz=-renderDist;dz<=renderDist;dz++)
            if (dx*dx+dz*dz <= renderDist*renderDist)
                needed.push_back({pcx+dx, pcz+dz});

    // 2. Queue missing chunks (not in main map, not already requested/in-flight)
    {
        std::lock_guard<std::mutex> lk(reqMutex);
        for (auto& k : needed) {
            if (chunks.find(k) != chunks.end()) continue;
            bool alreadyQueued = false;
            for (auto& r : requested) if (r.x==k.x&&r.z==k.z){alreadyQueued=true;break;}
            for (auto& r : inFlight)  if (r.x==k.x&&r.z==k.z){alreadyQueued=true;break;}
            if (!alreadyQueued) {
                // sort by distance so worker does nearest first
                int d = (k.x-pcx)*(k.x-pcx)+(k.z-pcz)*(k.z-pcz);
                auto pos = std::lower_bound(requested.begin(), requested.end(), k,
                    [&](const ChunkKey& a, const ChunkKey& b_unused){
                        int da=(a.x-pcx)*(a.x-pcx)+(a.z-pcz)*(a.z-pcz);
                        return da > d; // larger distance at back
                    });
                requested.insert(pos, k);
            }
        }
    }

    // 3. Collect finished chunks from worker, upload GPU (max 4 per frame)
    {
        std::lock_guard<std::mutex> lk(resMutex);
        int uploaded = 0;
        while (!results.empty() && uploaded < 4) {
            auto& r = results.back();
            r.chunk->uploadMesh();
            chunks[{r.cx, r.cz}] = std::move(r.chunk);
            results.pop_back();
            uploaded++;
        }
    }

    // 4. Re-mesh dirty chunks (block place/break), max 1 per frame on GL thread
    {
        auto worldGet=[this](int x,int y,int z)->uint8_t{return getBlock(x,y,z);};
        int rebuilt=0;
        for (auto& [key,chunk]:chunks) {
            if (chunk->isDirty() && rebuilt<1) {
                chunk->buildMesh(worldGet);
                chunk->uploadMesh();
                rebuilt++;
            }
        }
    }

    // 5. Unload far chunks
    const int maxDist = renderDist+3;
    for (auto it=chunks.begin();it!=chunks.end();) {
        int dx=it->first.x-pcx, dz=it->first.z-pcz;
        if (dx*dx+dz*dz > maxDist*maxDist) it=chunks.erase(it);
        else ++it;
    }
}

void World::renderAll(GLint mvpLoc, const float* vp) const {
    for (auto& [key,chunk]:chunks)
        chunk->render(mvpLoc, vp);
}

// ── DDA Raycast ───────────────────────────────────────────────────────────────
bool World::raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const {
    dir = normalize(dir);
    int bx=(int)floorf(origin.x),by=(int)floorf(origin.y),bz=(int)floorf(origin.z);
    int sx=(dir.x>0)?1:-1, sy=(dir.y>0)?1:-1, sz=(dir.z>0)?1:-1;
    float ddx=(dir.x!=0)?fabsf(1.f/dir.x):1e30f;
    float ddy=(dir.y!=0)?fabsf(1.f/dir.y):1e30f;
    float ddz=(dir.z!=0)?fabsf(1.f/dir.z):1e30f;
    auto frac=[](float v){return v-floorf(v);};
    float tx=(dir.x>0)?(1.f-frac(origin.x))*ddx:frac(origin.x)*ddx;
    float ty=(dir.y>0)?(1.f-frac(origin.y))*ddy:frac(origin.y)*ddy;
    float tz=(dir.z>0)?(1.f-frac(origin.z))*ddz:frac(origin.z)*ddz;
    Vec3 normal{};
    for (int i=0;i<256;i++) {
        if (getBlock(bx,by,bz)!=0){hitPos={(float)bx,(float)by,(float)bz};hitNormal=normal;return true;}
        float tmin=std::min({tx,ty,tz});
        if (tmin>maxDist) break;
        if (tx<=ty&&tx<=tz){tx+=ddx;bx+=sx;normal={-(float)sx,0,0};}
        else if(ty<=tz)    {ty+=ddy;by+=sy;normal={0,-(float)sy,0};}
        else               {tz+=ddz;bz+=sz;normal={0,0,-(float)sz};}
    }
    return false;
}
