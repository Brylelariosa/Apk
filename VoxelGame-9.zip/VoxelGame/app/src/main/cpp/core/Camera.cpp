#include "Camera.h"
#include <cmath>
#include <algorithm>

static constexpr float PI   = 3.14159265f;
static constexpr float HALF = PI * 0.5f;

Camera::Camera() {
    yaw   = 0.f;
    pitch = 0.f;
    pos   = {8.f, 80.f, 8.f};
    proj  = mat4Identity();
    rebuildView();
}

void Camera::rotate(float dyaw, float dpitch) {
    yaw   += dyaw;
    pitch += dpitch;
    pitch  = std::max(-HALF + 0.01f, std::min(HALF - 0.01f, pitch));
    rebuildView();
}

Vec3 Camera::getForward() const {
    return {
        cosf(pitch)*sinf(yaw),
       -sinf(pitch),
        cosf(pitch)*cosf(yaw)
    };
}

Vec3 Camera::getRight() const {
    return normalize(cross(getForward(), {0,1,0}));
}

void Camera::rebuildView() {
    Vec3 fwd = getForward();
    Vec3 target = pos + fwd;
    view = mat4LookAt(pos, target, {0,1,0});
}

void Camera::updateProjection(float aspect) {
    proj = mat4Perspective(PI/3.f, aspect, 0.1f, 300.f);
    rebuildView();
}
