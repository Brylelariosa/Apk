#pragma once
#include "MathUtils.h"

class Camera {
public:
    Camera();
    void setPosition(Vec3 p)    { pos = p; }
    Vec3 getPosition() const    { return pos; }
    void move(Vec3 delta)       { pos += delta; }

    // Rotate by angles in radians
    void rotate(float dyaw, float dpitch);

    Vec3 getForward() const;
    Vec3 getRight()   const;
    Vec3 getUp()      const { return {0,1,0}; }

    void   updateProjection(float aspect);
    Mat4   getViewProjection() const { return proj * view; }
    Mat4   getView()           const { return view; }

private:
    Vec3  pos{};
    float yaw   = 0.f;     // horizontal rotation (around Y)
    float pitch = 0.f;     // vertical   rotation (around X)
    Mat4  view{};
    Mat4  proj{};

    void rebuildView();
};
