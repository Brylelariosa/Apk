package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChapterAdapter(
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onGroupShare: (groupIdx: Int) -> Unit,
    private val onGroupRename: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null,
    private val onFilteredPreview: ((groupIdx: Int, filteredImageIdx: Int) -> Unit)? = null,
    private val onBatchRestore: ((groupIdx: Int) -> Unit)? = null
) : ListAdapter<ImageGroup, ChapterAdapter.VH>(DiffCallback()) {

    private val expandedMain     = mutableSetOf<Int>()
    private val expandedFiltered = mutableSetOf<Int>()
    private val thumbAdapters    = mutableMapOf<Int, ImageThumbAdapter>()
    private val filteredAdapters = mutableMapOf<Int, FilteredThumbAdapter>()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    var touchHelper: ItemTouchHelper? = null

    class DiffCallback : DiffUtil.ItemCallback<ImageGroup>() {
        override fun areItemsTheSame(oldItem: ImageGroup, newItem: ImageGroup): Boolean =
            oldItem.groupName == newItem.groupName
        override fun areContentsTheSame(oldItem: ImageGroup, newItem: ImageGroup): Boolean =
            oldItem == newItem
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover:           ImageView   = v.findViewById(R.id.chapter_cover)
        val numBadge:        TextView    = v.findViewById(R.id.chapter_num_badge)
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val filteredCount:   TextView    = v.findViewById(R.id.filtered_count)
        val arrow:           TextView    = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val shareBtn:        View         = v.findViewById(R.id.chapter_share)
        val dragHandle:      TextView    = v.findViewById(R.id.drag_handle)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   TextView    = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
        val btnRestoreAll:   Button      = v.findViewById(R.id.btn_restore_all)
        var coverJob: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = getItem(position)
        val isMerge = AppState.currentMode == AppMode.MERGE
        val isExpanded = position in expandedMain

        // ── Number badge ──────────────────────────────────────────────────────
        holder.numBadge.text = "${position + 1}"

        // ── Cover thumbnail (first image, loaded async) ───────────────────────
        holder.coverJob?.cancel()
        holder.cover.setImageBitmap(null)
        val coverImg = group.displayImages.firstOrNull()
        if (coverImg != null) {
            val cacheKey = "cover_${position}_${coverImg.originalIdx}"
            val cached = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                holder.cover.setImageBitmap(cached)
            } else {
                holder.coverJob = scope.launch {
                    val bm = withContext(Dispatchers.IO) {
                        runCatching { BitmapUtils.decodeThumbnail(coverImg.data, 100) }.getOrNull()
                    }
                    if (bm != null) {
                        AppState.thumbCache.put(cacheKey, bm)
                        holder.cover.setImageBitmap(bm)
                    }
                }
            }
        }

        // ── Name + count ──────────────────────────────────────────────────────
        holder.name.text = group.groupName

        if (isMerge) {
            val pairs = (group.displayImages.size + 1) / 2
            holder.count.text = "${group.displayImages.size} images · $pairs pairs"
            holder.dragHandle.visibility = View.GONE
            holder.filteredCount.visibility = View.GONE
            holder.filteredSection.visibility = View.GONE
            holder.removeBtn.visibility = if (itemCount > 1) View.VISIBLE else View.GONE
        } else {
            holder.dragHandle.visibility = View.VISIBLE
            holder.removeBtn.visibility  = View.VISIBLE
            holder.count.text = "${group.displayImages.size} images"
            val fCount = group.filteredImages.size
            holder.filteredCount.visibility = if (fCount > 0) View.VISIBLE else View.GONE
            if (fCount > 0) holder.filteredCount.text = "⚠ $fCount filtered"
        }

        holder.arrow.text = if (isExpanded) "▲" else "▼"

        // ── Drag to reorder ───────────────────────────────────────────────────
        holder.dragHandle.setOnTouchListener { _, event ->
            if (!isMerge && event.actionMasked == MotionEvent.ACTION_DOWN) touchHelper?.startDrag(holder)
            false
        }

        // ── Per-chapter actions ───────────────────────────────────────────────
        holder.removeBtn.setOnClickListener { onGroupRemove(position) }
        holder.shareBtn.setOnClickListener  { onGroupShare(position) }
        holder.name.setOnLongClickListener  { onGroupRename(position); true }

        // ── Expand / collapse ─────────────────────────────────────────────────
        holder.header.setOnClickListener {
            if (position in expandedMain) {
                expandedMain.remove(position)
                thumbAdapters.remove(position)?.destroy()
                holder.grid.adapter = null
                holder.grid.visibility = View.GONE
            } else {
                expandedMain.add(position)
                populateMainGrid(holder, position, group)
                holder.grid.visibility = View.VISIBLE
            }
            holder.arrow.text = if (position in expandedMain) "▲" else "▼"
        }

        if (isExpanded) {
            populateMainGrid(holder, position, group); holder.grid.visibility = View.VISIBLE
        } else {
            holder.grid.visibility = View.GONE
        }

        // ── Filtered section ──────────────────────────────────────────────────
        if (!isMerge && group.filteredImages.isNotEmpty()) {
            holder.filteredSection.visibility = View.VISIBLE
            holder.filteredLabel.text = "${group.filteredImages.size} filtered — tap to review"
            holder.filteredArrow.text = if (position in expandedFiltered) "▲" else "▼"
            holder.btnRestoreAll.setOnClickListener { onBatchRestore?.invoke(position) }
            holder.filteredHeader.setOnClickListener {
                if (position in expandedFiltered) {
                    expandedFiltered.remove(position)
                    filteredAdapters.remove(position)?.destroy()
                    holder.filteredGrid.adapter = null
                    holder.filteredGrid.visibility = View.GONE
                } else {
                    expandedFiltered.add(position)
                    populateFilteredGrid(holder, position, group)
                    holder.filteredGrid.visibility = View.VISIBLE
                }
                holder.filteredArrow.text = if (position in expandedFiltered) "▲" else "▼"
            }
            if (position in expandedFiltered) {
                populateFilteredGrid(holder, position, group); holder.filteredGrid.visibility = View.VISIBLE
            } else {
                holder.filteredGrid.visibility = View.GONE
            }
        } else {
            holder.filteredSection.visibility = View.GONE
        }
    }

    private fun populateMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages) else group.displayImages
        val cols = if (isMerge) 2 else 3
        val adapter = ImageThumbAdapter(
            items, isMerge,
            group       = if (isMerge) group else null,
            groupIdx    = position,
            onItemClick = { idx -> onImageClick(position, idx) },
            onItemLongClick = onImageLongClick,
            onSwapChanged   = null
        )
        thumbAdapters[position]?.destroy()
        thumbAdapters[position] = adapter
        holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols)
        holder.grid.adapter = adapter
    }

    private fun populateFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val adapter = FilteredThumbAdapter(
            items     = group.filteredImages,
            groupIdx  = position,
            onPreview = { filtIdx -> onFilteredPreview?.invoke(position, filtIdx) },
            onRestore = { img -> img.forceKeep = true; img.userDeleted = false; onImageRestore?.invoke(img) }
        )
        filteredAdapters[position]?.destroy()
        filteredAdapters[position] = adapter
        holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3)
        holder.filteredGrid.adapter = adapter
    }

    fun destroy() {
        scope.cancel()
        thumbAdapters.values.forEach { it.destroy() }; thumbAdapters.clear()
        filteredAdapters.values.forEach { it.destroy() }; filteredAdapters.clear()
    }

    override fun onViewRecycled(holder: VH) {
        holder.coverJob?.cancel()
        holder.grid.adapter = null
        super.onViewRecycled(holder)
    }
}

// ── Filtered thumbnail adapter ─────────────────────────────────────────────────
class FilteredThumbAdapter(
    private val items: List<com.mangatool.app.model.ImageItem>,
    private val groupIdx: Int = 0,
    private val onPreview: (Int) -> Unit,
    private val onRestore: (com.mangatool.app.model.ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val preview: View      = v.findViewById(R.id.btn_preview)
        val restore: View      = v.findViewById(R.id.btn_restore)
        var job:     Job?      = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_thumb_filtered, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text = img.filterReason ?: "Filtered"
        holder.image.setImageBitmap(null); holder.job?.cancel()
        val cacheKey = "filt_${groupIdx}_${img.originalIdx}"
        val cached = AppState.thumbCache.get(cacheKey)
        if (cached != null) {
            holder.image.setImageBitmap(cached)
        } else {
            holder.job = scope.launch {
                val bm = withContext(Dispatchers.IO) { BitmapUtils.decodeThumbnail(img.data, 200) }
                if (bm != null) { AppState.thumbCache.put(cacheKey, bm); holder.image.setImageBitmap(bm) }
            }
        }
        holder.itemView.setOnClickListener { onPreview(position) }
        holder.preview.setOnClickListener  { onPreview(position) }
        holder.restore.setOnClickListener  { onRestore(img) }
    }

    override fun onViewRecycled(holder: VH) { holder.job?.cancel(); super.onViewRecycled(holder) }
    fun destroy() = scope.cancel()
}
