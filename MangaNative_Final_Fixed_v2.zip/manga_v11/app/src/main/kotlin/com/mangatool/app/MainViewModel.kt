package com.mangatool.app

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val _currentMode = MutableStateFlow(AppState.currentMode)
    val currentMode: StateFlow<AppMode> = _currentMode.asStateFlow()

    private val _groups = MutableStateFlow<List<ImageGroup>>(emptyList())
    val groups: StateFlow<List<ImageGroup>> = _groups.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    init {
        refreshGroups()
    }

    fun setMode(mode: AppMode) {
        AppState.currentMode = mode
        _currentMode.value = mode
        refreshGroups()
    }

    fun refreshGroups() {
        AppState.applyFilters()
        _groups.value = AppState.groups.toList()
    }

    fun updateFilters(minSizeKb: Int, excludeGifs: Boolean, reverseOrder: Boolean) {
        AppState.minSizeKb = minSizeKb
        AppState.excludeGifs = excludeGifs
        AppState.reverseOrder = reverseOrder
        
        Prefs.minSizeKb = minSizeKb
        Prefs.excludeGifs = excludeGifs
        Prefs.reverseOrder = reverseOrder
        
        refreshGroups()
    }

    fun removeGroup(group: ImageGroup) {
        AppState.groups.remove(group)
        refreshGroups()
    }

    fun setProcessing(processing: Boolean) {
        _isProcessing.value = processing
    }
}
