package com.mangatool.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.activityViewModels
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.mangatool.app.databinding.BottomSheetFiltersBinding
import com.mangatool.app.util.Prefs

class FiltersBottomSheet : BottomSheetDialogFragment() {

    private var _binding: BottomSheetFiltersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetFiltersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupUI()
    }

    private fun setupUI() {
        // Initial values
        binding.sizeSlider.progress = Prefs.minSizeKb
        binding.sizeLabel.text = "${Prefs.minSizeKb} KB"
        binding.toggleGifs.isChecked = Prefs.excludeGifs
        binding.toggleReverse.isChecked = Prefs.reverseOrder

        // Listeners
        binding.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.sizeLabel.text = "$progress KB"
                updateFilters()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.toggleGifs.setOnCheckedChangeListener { _, _ -> updateFilters() }
        binding.toggleReverse.setOnCheckedChangeListener { _, _ -> updateFilters() }

        // Folder labels
        updateFolderLabels()

        binding.btnSetExtractFolder.setOnClickListener { /* Handle in Activity */ }
        binding.btnSetMergeFolder.setOnClickListener { /* Handle in Activity */ }
        
        binding.btnClearExtractFolder.setOnClickListener {
            Prefs.extractFolderUri = null
            Prefs.extractFolderName = null
            updateFolderLabels()
        }
        binding.btnClearMergeFolder.setOnClickListener {
            Prefs.mergeFolderUri = null
            Prefs.mergeFolderName = null
            updateFolderLabels()
        }
    }

    private fun updateFilters() {
        viewModel.updateFilters(
            binding.sizeSlider.progress,
            binding.toggleGifs.isChecked,
            binding.toggleReverse.isChecked
        )
    }

    private fun updateFolderLabels() {
        binding.tvExtractFolderName.text = Prefs.extractFolderName ?: "Not set — asks each time"
        binding.btnClearExtractFolder.visibility = if (Prefs.extractFolderName != null) View.VISIBLE else View.GONE

        binding.tvMergeFolderName.text = Prefs.mergeFolderName ?: "Not set — asks each time"
        binding.btnClearMergeFolder.visibility = if (Prefs.mergeFolderName != null) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
