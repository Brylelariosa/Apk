package com.mangatool.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r -> if (r.resultCode == Activity.RESULT_OK) handlePickResult(r.data) }

    private val mergePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uriStrings = r.data?.getStringArrayListExtra(MergeImagePickerActivity.RESULT_URIS)
            val folderName = r.data?.getStringExtra(MergeImagePickerActivity.RESULT_FOLDER_NAME) ?: ""
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) processFiles(uris, folderName)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        
        // Fix overlapping with system bars
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
            insets
        }

        Prefs.init(this)
        ImageSaver.clearShareCache(this)

        setupUI()
        observeViewModel()
        handleIncomingShareIntent(intent)
    }

    private fun setupUI() {
        setSupportActionBar(b.toolbar)
        
        b.viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int = 2
            override fun createFragment(position: Int) = GroupListFragment()
        }

        TabLayoutMediator(b.tabLayout, b.viewPager) { tab, position ->
            tab.text = if (position == 0) "Extract" else "Merger"
        }.attach()

        b.tabLayout.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab?) {
                viewModel.setMode(if (tab?.position == 0) AppMode.EXTRACT else AppMode.MERGE)
            }
            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
        })

        b.btnFilters.setOnClickListener {
            FiltersBottomSheet().show(supportFragmentManager, "filters")
        }

        b.fabAdd.setOnClickListener {
            if (viewModel.currentMode.value == AppMode.EXTRACT) {
                pickFiles()
            } else {
                mergePickerLauncher.launch(Intent(this, MergeImagePickerActivity::class.java))
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.isProcessing.collect { isProcessing ->
                    b.progressBar.visibility = if (isProcessing) View.VISIBLE else View.GONE
                    b.fabAdd.isEnabled = !isProcessing
                }
            }
        }
    }

    private fun pickFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "text/html", "application/zip", "application/x-cbz"))
        }
        openDocLauncher.launch(intent)
    }

    private fun handlePickResult(data: Intent?) {
        val uris = mutableListOf<Uri>()
        data?.clipData?.let { cd ->
            for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
        } ?: data?.data?.let { uris.add(it) }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    private fun processFiles(uris: List<Uri>, folderName: String = "") {
        viewModel.setProcessing(true)
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                uris.forEach { uri ->
                    val name = runCatching {
                        androidx.documentfile.provider.DocumentFile.fromSingleUri(this@MainActivity, uri)?.name
                    }.getOrNull() ?: uri.lastPathSegment ?: "Unknown"
                    
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@forEach
                    
                    if (name.endsWith(".mhtml", true) || name.endsWith(".mht", true)) {
                        MhtmlParser.parse(bytes, name)?.let { AppState.groups.add(it) }
                    } else if (name.endsWith(".zip", true) || name.endsWith(".cbz", true)) {
                        parseZip(bytes, name)?.let { AppState.groups.add(it) }
                    } else if (viewModel.currentMode.value == AppMode.MERGE) {
                        // For merge mode, add individual images to a group
                        val group = AppState.mergeGroups.find { it.groupName == folderName } 
                            ?: ImageGroup(groupName = folderName.ifBlank { "Merged Group" }).also { AppState.mergeGroups.add(it) }
                        
                        val ext = name.substringAfterLast('.', "jpg")
                        val (w, h) = BitmapUtils.decodeDimensions(bytes)
                        group.allImages.add(ImageItem(
                            originalIdx = group.allImages.size,
                            data = bytes,
                            ext = ext,
                            size = bytes.size,
                            width = w,
                            height = h
                        ))
                    }
                }
            }
            viewModel.refreshGroups()
            viewModel.setProcessing(false)
        }
    }

    private fun parseZip(data: ByteArray, filename: String): ImageGroup? {
        val extracted = mutableListOf<ImageItem>()
        ZipInputStream(data.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val ext = entry.name.substringAfterLast('.', "").lowercase()
                    if (ext in listOf("jpg", "jpeg", "png", "webp", "gif")) {
                        val bytes = zis.readBytes()
                        val (w, h) = BitmapUtils.decodeDimensions(bytes)
                        extracted.add(ImageItem(
                            originalIdx = extracted.size,
                            data = bytes,
                            ext = if (ext == "jpeg") "jpg" else ext,
                            size = bytes.size,
                            width = w,
                            height = h
                        ))
                    }
                }
                entry = zis.nextEntry
            }
        }
        if (extracted.isEmpty()) return null
        return ImageGroup(groupName = filename.substringBeforeLast('.')).apply {
            allImages.addAll(extracted)
        }
    }

    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) {
            processFiles(uris)
            setIntent(Intent(Intent.ACTION_MAIN))
        }
    }
}
