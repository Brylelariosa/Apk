package rikka.shizuku

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Parcel
import android.os.Process
import android.util.Log

/**
 * Self-contained Shizuku client — mirrors the public API of the official
 * rikka.shizuku:api library so all existing imports work unchanged.
 *
 * Communicates with the Shizuku service via raw binder transactions.
 * IShizukuService transaction codes (stable since Shizuku v11):
 *   1  = attachApplication
 *   3  = newProcess
 *  13  = checkPermission
 *  14  = requestPermission  (fires the in-app grant dialog)
 */
object Shizuku {

    private const val TAG = "Shizuku"
    private const val INTERFACE = "moe.shizuku.server.IShizukuService"
    private const val PERM = "moe.shizuku.manager.permission.API_V23"

    // ── Listener registry ─────────────────────────────────────────────────────

    fun interface OnRequestPermissionResultListener {
        fun onRequestPermissionResult(requestCode: Int, grantResult: Int)
    }

    private val permListeners = mutableListOf<OnRequestPermissionResultListener>()

    fun addRequestPermissionResultListener(l: OnRequestPermissionResultListener) {
        if (!permListeners.contains(l)) permListeners.add(l)
    }

    fun removeRequestPermissionResultListener(l: OnRequestPermissionResultListener) {
        permListeners.remove(l)
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /** Returns true if the Shizuku service binder is reachable. */
    fun pingBinder(): Boolean = getBinder() != null

    /** Returns PERMISSION_GRANTED or PERMISSION_DENIED. */
    fun checkSelfPermission(): Int {
        val binder = getBinder() ?: return PackageManager.PERMISSION_DENIED
        return try {
            val data  = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken(INTERFACE)
                data.writeString(PERM)
                data.writeInt(Process.myPid())
                data.writeInt(Process.myUid())
                data.writeStrongBinder(null)          // token (optional)
                binder.transact(13, data, reply, 0)
                reply.readException()
                reply.readInt()
            } finally { data.recycle(); reply.recycle() }
        } catch (e: Exception) {
            Log.w(TAG, "checkSelfPermission: ${e.message}")
            PackageManager.PERMISSION_DENIED
        }
    }

    /**
     * Asks Shizuku to show its permission-grant dialog.
     * The result is delivered to all registered listeners.
     */
    fun requestPermission(requestCode: Int) {
        val binder = getBinder()
        if (binder == null) {
            // Not running — notify listeners immediately with deny
            permListeners.forEach { it.onRequestPermissionResult(requestCode, PackageManager.PERMISSION_DENIED) }
            return
        }
        try {
            val data  = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken(INTERFACE)
                data.writeInt(requestCode)
                binder.transact(14, data, reply, 0)
                reply.readException()
                // Shizuku will call back asynchronously; poll result once after short delay
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    val result = checkSelfPermission()
                    permListeners.forEach { it.onRequestPermissionResult(requestCode, result) }
                }, 1500)
            } finally { data.recycle(); reply.recycle() }
        } catch (e: Exception) {
            Log.e(TAG, "requestPermission: ${e.message}")
            permListeners.forEach { it.onRequestPermissionResult(requestCode, PackageManager.PERMISSION_DENIED) }
        }
    }

    /**
     * Runs a privileged shell command via the Shizuku service.
     * Returns a Process whose exit code you can inspect.
     */
    fun newProcess(cmd: Array<String>, env: Array<String>?, dir: String?): Process {
        val binder = getBinder() ?: throw IllegalStateException("Shizuku not available")
        // Transaction 3 = newProcess(String[] cmd, String[] env, String dir)
        val data  = Parcel.obtain()
        val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(INTERFACE)
            data.writeStringArray(cmd)
            if (env != null) data.writeStringArray(env) else data.writeInt(-1)
            data.writeString(dir)
            binder.transact(3, data, reply, 0)
            reply.readException()
            // Shizuku returns 3 ParcelFileDescriptors: stdin, stdout, stderr
            // Wrap them in a real Process for easy waitFor()
            ShizukuProcess(reply)
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    private fun getBinder(): IBinder? = try {
        val sm  = Class.forName("android.os.ServiceManager")
        val get = sm.getMethod("getService", String::class.java)
        get.invoke(null, "shizuku") as? IBinder
    } catch (e: Exception) { null }
}
