package com.logcatviewer.app

import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.OutputStream

private const val TAG = "RemoteService"

/**
 * Runs inside a Shizuku UserService as shell uid (2000).
 * Shell always has READ_LOGS, so logcat here always works.
 */
class RemoteService : IRemoteService.Stub() {

    @Volatile private var logcatProcess: Process? = null

    override fun grantReadLogs(packageName: String): Int {
        return try {
            val p = Runtime.getRuntime().exec(
                arrayOf("pm", "grant", packageName, "android.permission.READ_LOGS")
            )
            p.waitFor()
        } catch (e: Exception) {
            Log.e(TAG, "grantReadLogs failed", e)
            -1
        }
    }

    override fun startLogcat(writeFd: ParcelFileDescriptor) {
        stopLogcat() // stop any existing stream
        Thread {
            var out: OutputStream? = null
            try {
                val process = Runtime.getRuntime().exec(
                    arrayOf("logcat", "-v", "threadtime", "*:V")
                )
                logcatProcess = process
                out = ParcelFileDescriptor.AutoCloseOutputStream(writeFd)
                // Pipe logcat stdout → writeFd; blocks until process dies
                process.inputStream.copyTo(out, 8192)
            } catch (e: Exception) {
                Log.e(TAG, "logcat stream error", e)
            } finally {
                runCatching { out?.close() }
                runCatching { writeFd.close() }
            }
        }.apply { isDaemon = true; start() }
    }

    override fun stopLogcat() {
        runCatching { logcatProcess?.destroy() }
        logcatProcess = null
    }
}
