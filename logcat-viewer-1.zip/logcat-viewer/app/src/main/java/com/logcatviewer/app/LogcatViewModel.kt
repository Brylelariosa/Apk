package com.logcatviewer.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.logcatviewer.app.data.LogEntry
import com.logcatviewer.app.data.LogcatReader
import com.logcatviewer.app.util.ShizukuHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LogcatUiState(
    val logs: List<LogEntry> = emptyList(),
    val filteredLogs: List<LogEntry> = emptyList(),
    val searchQuery: String = "",
    val packageFilter: String = "",
    val tagFilter: String = "",
    val autoScroll: Boolean = true,
    val isRunning: Boolean = false,
    val permissionState: PermissionState = PermissionState.UNKNOWN,
    val shizukuAvailable: Boolean = false,
    val errorMessage: String? = null,
)

enum class PermissionState { UNKNOWN, GRANTED, DENIED, REQUESTING }

class LogcatViewModel(app: Application) : AndroidViewModel(app) {

    private val reader = LogcatReader()
    private var readJob: Job? = null
    private val maxLogs = 5_000

    private val _uiState = MutableStateFlow(LogcatUiState())
    val uiState: StateFlow<LogcatUiState> = _uiState.asStateFlow()

    init {
        checkAndBind()
    }

    fun checkAndBind() {
        val shizukuAvailable = ShizukuHelper.isAvailable
        _uiState.update { it.copy(shizukuAvailable = shizukuAvailable) }

        if (!shizukuAvailable) {
            _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            return
        }

        if (!ShizukuHelper.hasShizukuPermission) {
            _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            return
        }

        // Shizuku is ready — bind the UserService
        _uiState.update { it.copy(permissionState = PermissionState.REQUESTING) }
        ShizukuHelper.bindService(getApplication<Application>().packageName) { svc ->
            if (svc != null) {
                _uiState.update { it.copy(permissionState = PermissionState.GRANTED, errorMessage = null) }
                startReading()
            } else {
                _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            }
        }
    }

    fun requestShizukuApiPermission() {
        ShizukuHelper.requestShizukuPermission()
    }

    fun requestViaShizuku() {
        _uiState.update { it.copy(permissionState = PermissionState.REQUESTING) }
        ShizukuHelper.grantReadLogsPermission(getApplication<Application>().packageName) { granted ->
            if (granted) {
                // Re-bind now that we have the grant
                checkAndBind()
            } else {
                _uiState.update { it.copy(permissionState = PermissionState.DENIED) }
            }
        }
    }

    fun startReading() {
        if (readJob?.isActive == true) return
        val pfd = ShizukuHelper.openLogcatPipe(getApplication<Application>().packageName)
        if (pfd == null) {
            _uiState.update {
                it.copy(
                    isRunning = false,
                    errorMessage = "Could not open logcat pipe. Is Shizuku running?"
                )
            }
            return
        }
        readJob = viewModelScope.launch {
            _uiState.update { it.copy(isRunning = true, errorMessage = null) }
            reader.readFromPipe(pfd)
                .catch { e ->
                    _uiState.update { it.copy(isRunning = false, errorMessage = e.message) }
                }
                .collect { entry ->
                    _uiState.update { state ->
                        val newLogs = (state.logs + entry).takeLast(maxLogs)
                        state.copy(
                            logs = newLogs,
                            filteredLogs = applyFilters(newLogs, state)
                        )
                    }
                }
            _uiState.update { it.copy(isRunning = false) }
        }
    }

    fun stopReading() {
        ShizukuHelper.stopLogcat()
        readJob?.cancel()
        _uiState.update { it.copy(isRunning = false) }
    }

    fun clearLogs() {
        _uiState.update { it.copy(logs = emptyList(), filteredLogs = emptyList()) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { state ->
            val updated = state.copy(searchQuery = query)
            updated.copy(filteredLogs = applyFilters(state.logs, updated))
        }
    }

    fun setPackageFilter(pkg: String) {
        _uiState.update { state ->
            val updated = state.copy(packageFilter = pkg)
            updated.copy(filteredLogs = applyFilters(state.logs, updated))
        }
    }

    fun setTagFilter(tag: String) {
        _uiState.update { state ->
            val updated = state.copy(tagFilter = tag)
            updated.copy(filteredLogs = applyFilters(state.logs, updated))
        }
    }

    fun toggleAutoScroll() {
        _uiState.update { it.copy(autoScroll = !it.autoScroll) }
    }

    fun setAutoScroll(value: Boolean) {
        _uiState.update { it.copy(autoScroll = value) }
    }

    private fun applyFilters(logs: List<LogEntry>, state: LogcatUiState): List<LogEntry> {
        return logs.filter { entry ->
            val matchesSearch = state.searchQuery.isEmpty() ||
                    entry.message.contains(state.searchQuery, ignoreCase = true) ||
                    entry.tag.contains(state.searchQuery, ignoreCase = true)
            val matchesTag = state.tagFilter.isEmpty() ||
                    entry.tag.contains(state.tagFilter, ignoreCase = true)
            // Package filter: match tag OR message (logcat shows tags, not package names)
            val matchesPkg = state.packageFilter.isEmpty() ||
                    entry.tag.contains(state.packageFilter, ignoreCase = true) ||
                    entry.message.contains(state.packageFilter, ignoreCase = true) ||
                    entry.pid.contains(state.packageFilter, ignoreCase = true)
            matchesSearch && matchesTag && matchesPkg
        }
    }

    override fun onCleared() {
        super.onCleared()
        ShizukuHelper.stopLogcat()
        ShizukuHelper.unbindService()
        readJob?.cancel()
    }
}
