package com.logcatviewer.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.logcatviewer.app.LogcatUiState
import com.logcatviewer.app.LogcatViewModel
import com.logcatviewer.app.PermissionState
import com.logcatviewer.app.data.LogEntry
import com.logcatviewer.app.util.LogExporter
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogcatScreen(viewModel: LogcatViewModel) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showFilterSheet by remember { mutableStateOf(false) }

    if (state.permissionState != PermissionState.GRANTED) {
        PermissionScreen(
            state = state,
            onRequestShizukuApi = { viewModel.requestShizukuApiPermission() },
            onGrantViaShizuku = { viewModel.requestViaShizuku() }
        )
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Logcat Viewer",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                actions = {
                    // Auto-scroll toggle
                    IconButton(onClick = { viewModel.toggleAutoScroll() }) {
                        Icon(
                            imageVector = if (state.autoScroll) Icons.Default.ArrowDownward
                                         else Icons.Default.PauseCircle,
                            contentDescription = "Auto-scroll",
                            tint = if (state.autoScroll) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                    }
                    // Filter
                    IconButton(onClick = { showFilterSheet = true }) {
                        Icon(Icons.Default.FilterList, contentDescription = "Filter")
                    }
                    // Export
                    IconButton(onClick = {
                        coroutineScope.launch {
                            val uri = LogExporter.exportToFile(context, state.filteredLogs)
                            uri?.let { LogExporter.shareLog(context, it) }
                        }
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Export")
                    }
                    // Clear
                    IconButton(onClick = { viewModel.clearLogs() }) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear")
                    }
                    // Start/Stop
                    IconButton(onClick = {
                        if (state.isRunning) viewModel.stopReading()
                        else viewModel.startReading()
                    }) {
                        Icon(
                            imageVector = if (state.isRunning) Icons.Default.Stop
                                         else Icons.Default.PlayArrow,
                            contentDescription = if (state.isRunning) "Stop" else "Start",
                            tint = if (state.isRunning) Color(0xFFFF6B68)
                                   else Color(0xFF6A8759)
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search bar
            SearchBar(
                query = state.searchQuery,
                onQueryChange = { viewModel.setSearchQuery(it) }
            )

            // Active filters chips
            ActiveFilterChips(state = state, viewModel = viewModel)

            // Status bar
            StatusBar(state = state)

            // Error banner
            state.errorMessage?.let { err ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF5C1A1A))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null,
                        tint = Color(0xFFFF6B68), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(err, color = Color(0xFFFF6B68),
                        style = MaterialTheme.typography.labelSmall)
                }
            }

            // Log list
            LogList(
                logs = state.filteredLogs,
                autoScroll = state.autoScroll,
                onScrolledUp = { viewModel.setAutoScroll(false) }
            )
        }
    }

    if (showFilterSheet) {
        FilterBottomSheet(
            state = state,
            onDismiss = { showFilterSheet = false },
            onPackageFilter = { viewModel.setPackageFilter(it) },
            onTagFilter = { viewModel.setTagFilter(it) }
        )
    }
}

@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        placeholder = { Text("Search logs...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(8.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
        ),
        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp)
    )
}

@Composable
private fun ActiveFilterChips(state: LogcatUiState, viewModel: LogcatViewModel) {
    if (state.packageFilter.isEmpty() && state.tagFilter.isEmpty()) return
    Row(
        modifier = Modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (state.packageFilter.isNotEmpty()) {
            FilterChip(
                selected = true,
                onClick = { viewModel.setPackageFilter("") },
                label = { Text("pkg: ${state.packageFilter}") },
                trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp)) }
            )
        }
        if (state.tagFilter.isNotEmpty()) {
            FilterChip(
                selected = true,
                onClick = { viewModel.setTagFilter("") },
                label = { Text("tag: ${state.tagFilter}") },
                trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp)) }
            )
        }
    }
}

@Composable
private fun StatusBar(state: LogcatUiState) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "${state.filteredLogs.size} / ${state.logs.size} lines",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(
                        if (state.isRunning) Color(0xFF6A8759) else Color(0xFF888888),
                        shape = RoundedCornerShape(50)
                    )
            )
            Text(
                text = if (state.isRunning) "Live" else "Stopped",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}

@Composable
private fun LogList(
    logs: List<LogEntry>,
    autoScroll: Boolean,
    onScrolledUp: () -> Unit
) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size, autoScroll) {
        if (autoScroll && logs.isNotEmpty()) {
            listState.scrollToItem(logs.size - 1)
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 2.dp)
    ) {
        items(logs, key = { it.id }) { entry ->
            LogRow(entry)
        }
    }
}

@Composable
private fun LogRow(entry: LogEntry) {
    SelectionContainer {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 8.dp, vertical = 1.dp),
        ) {
            // Level badge
            Text(
                text = entry.level.char.toString(),
                color = entry.level.color,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.padding(end = 6.dp)
            )
            // Tag
            Text(
                text = "${entry.tag}: ",
                color = entry.level.color.copy(alpha = 0.85f),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.sp,
            )
            // Message
            Text(
                text = entry.message,
                color = MaterialTheme.colorScheme.onBackground,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterBottomSheet(
    state: LogcatUiState,
    onDismiss: () -> Unit,
    onPackageFilter: (String) -> Unit,
    onTagFilter: (String) -> Unit
) {
    var pkg by remember { mutableStateOf(state.packageFilter) }
    var tag by remember { mutableStateOf(state.tagFilter) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Filter Logs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = pkg,
                onValueChange = { pkg = it },
                label = { Text("Package name") },
                placeholder = { Text("e.g. com.example.app") },
                supportingText = { Text("Matches tag or message — not the package name directly", style = MaterialTheme.typography.labelSmall) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Android, contentDescription = null) }
            )

            OutlinedTextField(
                value = tag,
                onValueChange = { tag = it },
                label = { Text("Tag filter") },
                placeholder = { Text("e.g. MainActivity") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Label, contentDescription = null) }
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        onPackageFilter("")
                        onTagFilter("")
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Clear") }

                Button(
                    onClick = {
                        onPackageFilter(pkg)
                        onTagFilter(tag)
                        onDismiss()
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Apply") }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun PermissionScreen(
    state: LogcatUiState,
    onRequestShizukuApi: () -> Unit,
    onGrantViaShizuku: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .wrapContentHeight(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Default.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(48.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    "READ_LOGS Permission Required",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "This app needs the READ_LOGS permission to capture logcat output. " +
                    "Grant it automatically using Shizuku — no PC needed.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )

                if (!state.shizukuAvailable) {
                    Text(
                        "⚠ Shizuku not detected. Please start Shizuku via Wireless Debugging first.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFBBB529)
                    )
                } else {
                    Button(
                        onClick = onRequestShizukuApi,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Step 1 — Allow Shizuku API Access")
                    }

                    Button(
                        onClick = onGrantViaShizuku,
                        modifier = Modifier.fillMaxWidth(),
                        enabled = state.permissionState != PermissionState.REQUESTING
                    ) {
                        if (state.permissionState == PermissionState.REQUESTING) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text("Step 2 — Grant READ_LOGS via Shizuku")
                    }
                }
            }
        }
    }
}
