package com.logcatviewer.app;

interface IRemoteService {
    /** Grant READ_LOGS to the given package. Returns 0 on success. */
    int grantReadLogs(String packageName);

    /** Start streaming logcat into writeFd. The caller reads from the read end. */
    void startLogcat(in ParcelFileDescriptor writeFd);

    /** Stop the running logcat stream. */
    void stopLogcat();
}
