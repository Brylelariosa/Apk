package com.batteryguard

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class BatteryService : Service() {

    companion object {
        const val CHANNEL_PERSISTENT = "bg_persistent"
        const val CHANNEL_ALERT      = "bg_alert"
        const val NOTIF_PERSISTENT   = 1
        const val NOTIF_ALERT        = 2
        const val ACTION_UPDATE_UI   = "com.batteryguard.UPDATE_UI"
    }

    private var batteryReceiver: BroadcastReceiver? = null
    private var lastAlertPercent = -1

    override fun onCreate() {
        super.onCreate()
        createChannels()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_PERSISTENT, buildPersistentNotif("Monitoring battery…", 0),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_PERSISTENT, buildPersistentNotif("Monitoring battery…", 0))
        }
        registerBatteryReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        batteryReceiver?.let { unregisterReceiver(it) }
    }

    private fun registerBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val info    = PowerReader.read(context)
                val prefs   = getSharedPreferences("settings", MODE_PRIVATE)
                val threshold = prefs.getInt("threshold", 100)

                val direction = if (info.isCharging) "▲" else "▼"
                val wStr = if (info.watts >= 0.05) " · ${info.wattsStr}" else ""
                val notifText = "${info.percent}%  ·  ${if (info.isCharging) "Charging" else "Battery"}$wStr"
                updatePersistentNotif(notifText, info.percent)
                sendBroadcast(Intent(ACTION_UPDATE_UI))

                if (info.isCharging && info.percent >= threshold && lastAlertPercent != info.percent) {
                    lastAlertPercent = info.percent
                    handleThresholdReached(info)
                } else if (info.percent < threshold - 5) {
                    lastAlertPercent = -1
                    ChargingController.enableCharging()
                }
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun handleThresholdReached(info: PowerReader.PowerInfo) {
        val wStr = if (info.watts >= 0.05) " (${info.wattsStr})" else ""
        val success = ChargingController.disableCharging()
        val method  = ChargingController.availableMethod()
        when {
            success -> sendAlert(
                "🔋 Charging stopped at ${info.percent}%$wStr",
                "Battery Guard automatically stopped charging to protect your battery life.",
                loud = false
            )
            method == ChargingController.Method.NONE -> sendAlert(
                "⚠️ Battery full at ${info.percent}%$wStr — Unplug now!",
                "Please unplug your charger. Enable root or Shizuku for automatic control.",
                loud = true
            )
            else -> sendAlert(
                "⚠️ Limit reached at ${info.percent}%",
                "Auto-stop attempted but failed. Please unplug manually.",
                loud = true
            )
        }
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PERSISTENT, "Battery Monitor", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Shows live battery status" }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Charging Alerts", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = "Alerts when charging threshold is reached"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 400, 150, 400, 150, 400)
                }
        )
    }

    private fun buildPersistentNotif(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_PERSISTENT)
            .setContentTitle("Battery Guard")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(100, progress, false)
            .build()
    }

    private fun updatePersistentNotif(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_PERSISTENT, buildPersistentNotif(text, progress))
    }

    private fun sendAlert(title: String, body: String, loud: Boolean) {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)

        if (loud) {
            val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(sound)
            builder.setVibrate(longArrayOf(0, 600, 200, 600, 200, 600))
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 200, 600), -1))
            }
        }
        getSystemService(NotificationManager::class.java).notify(NOTIF_ALERT, builder.build())
    }
}
