package com.batteryguard

import android.content.pm.PackageManager
import android.util.Log
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * Charging control via:
 *   1. Root (su)
 *   2. Shizuku rish shell — Shizuku installs a privileged shell binary at
 *      /data/user/0/moe.shizuku.privileged.api/files/rish
 *      Apps that hold moe.shizuku.manager.permission.API_V23 can exec it directly.
 *      No library or binder needed — just exec the binary.
 *   3. Fallback: loud alert notification only
 */
object ChargingController {

    private const val TAG = "ChargingController"

    // Shizuku's rish binary — privileged shell, works once permission is granted
    private val RISH_PATHS = listOf(
        "/data/user/0/moe.shizuku.privileged.api/files/rish",
        "/data/data/moe.shizuku.privileged.api/files/rish"
    )

    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",        // Qualcomm / most common
        "/sys/class/power_supply/battery/input_suspend",           // OnePlus / Oppo
        "/sys/class/power_supply/batt_drv/charge_disable",         // Google Pixel
        "/sys/class/power_supply/battery/stop_charging",           // Samsung
        "/sys/class/power_supply/battery/inhibit_charge",
        "/sys/class/power_supply/battery/charge_control_limit_max"
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    fun availableMethod(): Method = when {
        isRooted()         -> Method.ROOT
        isShizukuGranted() -> Method.SHIZUKU
        else               -> Method.NONE
    }

    fun disableCharging(): Boolean = run(buildCmds(enable = false))
    fun enableCharging():  Boolean = run(buildCmds(enable = true))

    private fun buildCmds(enable: Boolean): List<String> {
        val v    = if (enable) "1" else "0"
        val cmds = mutableListOf<String>()
        for (node in CHARGING_NODES) {
            cmds += "[ -f $node ] && echo $v > $node || true"
        }
        if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
        else        cmds += "dumpsys battery set status 1 2>/dev/null || true"
        return cmds
    }

    private fun run(cmds: List<String>): Boolean {
        val cmd = cmds.joinToString(" ; ")
        return when (availableMethod()) {
            Method.ROOT    -> exec(arrayOf("su",   "-c", cmd))
            Method.SHIZUKU -> exec(arrayOf(getRishPath()!!, "-c", cmd))
            Method.NONE    -> false
        }
    }

    private fun exec(args: Array<String>): Boolean {
        return try {
            val p    = Runtime.getRuntime().exec(args)
            val exit = p.waitFor()
            Log.d(TAG, "exec ${args[0]} exit=$exit")
            exit == 0
        } catch (e: Exception) {
            Log.e(TAG, "exec failed: ${e.message}")
            false
        }
    }

    // ── Shizuku detection ─────────────────────────────────────────────────────

    fun isShizukuAvailable(): Boolean = getRishPath() != null

    fun isShizukuGranted(): Boolean {
        val rish = getRishPath() ?: return false
        return try {
            // Try running a harmless command; exit 0 means we have access
            val p = Runtime.getRuntime().exec(arrayOf(rish, "-c", "echo ok"))
            val out = BufferedReader(InputStreamReader(p.inputStream)).readLine()
            p.waitFor() == 0 && out?.trim() == "ok"
        } catch (e: Exception) { false }
    }

    private fun getRishPath(): String? =
        RISH_PATHS.firstOrNull { File(it).exists() }

    // ── Root detection ────────────────────────────────────────────────────────

    fun isRooted(): Boolean = listOf(
        "/system/bin/su", "/system/xbin/su",
        "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
    ).any { File(it).exists() }
}
