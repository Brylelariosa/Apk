package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory

object BitmapUtils {

    /** Decode just the pixel dimensions without loading the full bitmap. */
    fun decodeDimensions(data: ByteArray): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        return opts.outWidth to opts.outHeight
    }

    /**
     * Decode a thumbnail at most [maxPx] wide/tall.
     *
     * Strategy:
     *  1. Use inSampleSize to decode to ~2× the target (power-of-2 step keeps it fast).
     *  2. Then scale precisely to ≤ maxPx with bilinear filtering (filter=true) so the
     *     result is smooth and high-quality — no blocky nearest-neighbour artefacts.
     *
     * This gives lossless-looking thumbnails (no JPEG re-compression) that are both
     * fast to decode and visually sharp.
     */
    fun decodeThumbnail(data: ByteArray, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        // Step 1 — coarse decode: stop one step early so rough >= 2× target
        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeByteArray(data, 0, data.size,
            BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null

        // Step 2 — precise bilinear scale down to ≤ maxPx
        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough          // already small enough, skip extra alloc

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)   // true = bilinear
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /** Decode at full resolution (for preview). */
    fun decodeFull(data: ByteArray): Bitmap? =
        BitmapFactory.decodeByteArray(data, 0, data.size)
}
