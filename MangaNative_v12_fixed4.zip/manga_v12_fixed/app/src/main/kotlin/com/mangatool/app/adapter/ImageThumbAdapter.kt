package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.*

class ImageThumbAdapter(
    private val items: List<Any>,
    private val isMerge: Boolean,
    /** The group this adapter belongs to — used to read/write pairSwaps */
    private val group: ImageGroup? = null,
    /** Stable group index used to namespace thumbnail cache keys across groups */
    private val groupIdx: Int = 0,
    private val onItemClick: (Int) -> Unit,
    private val onItemLongClick: ((ImageItem) -> Unit)? = null,
    /** Called when a swap is toggled so the parent can refresh */
    private val onSwapChanged: (() -> Unit)? = null
) : RecyclerView.Adapter<ImageThumbAdapter.VH>() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    init { setHasStableIds(true) }

    override fun getItemId(position: Int): Long = when (val item = items[position]) {
        is ImageItem         -> item.originalIdx.toLong()
        is List<*>           -> (item.firstOrNull() as? ImageItem)?.originalIdx?.toLong()
                                    ?: position.toLong()
        else                 -> position.toLong()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        // Shared (both modes)
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val overlay: View      = v.findViewById(R.id.thumb_overlay)
        val dims:    TextView? = v.findViewById(R.id.thumb_dims)

        // Merge-only
        val thumbLeft:  ImageView? = v.findViewById(R.id.thumb_left)
        val thumbRight: ImageView? = v.findViewById(R.id.thumb_right)
        val btnSwap:    Button?    = v.findViewById(R.id.btn_swap)

        var jobLeft:  Job? = null
        var jobRight: Job? = null
        var job:      Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (isMerge) R.layout.item_thumb_merge else R.layout.item_thumb
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.job?.cancel()
        holder.jobLeft?.cancel()
        holder.jobRight?.cancel()
        holder.image.setImageBitmap(null)
        holder.overlay.visibility = View.GONE
        holder.dims?.visibility = View.GONE

        // Use bindingAdapterPosition so the index is always fresh even after
        // notifyItemMoved/Removed calls that would make the captured `position` stale.
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onItemClick(pos)
        }

        if (!isMerge) {
            // ── Extract mode ──────────────────────────────────────────────
            val img = items[position] as ImageItem
            holder.overlay.visibility = if (img.userDeleted) View.VISIBLE else View.GONE

            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }

            holder.itemView.setOnLongClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) onItemLongClick?.invoke(items[pos] as ImageItem)
                true
            }

            val cacheKey = "th_${groupIdx}_${img.originalIdx}"
            val cached: Bitmap? = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                holder.image.setImageBitmap(cached); return
            }
            holder.job = scope.launch {
                val bm: Bitmap? = withContext(Dispatchers.IO) {
                    BitmapUtils.decodeThumbnail(img.data, 300)
                }
                if (bm != null) {
                    AppState.thumbCache.put(cacheKey, bm)
                    holder.image.setImageBitmap(bm)
                }
            }

        } else {
            // ── Merge mode ────────────────────────────────────────────────
            @Suppress("UNCHECKED_CAST")
            val pair = items[position] as List<ImageItem>
            val swapped = group?.pairSwaps?.contains(position) == true

            val leftImg  = if (swapped && pair.size > 1) pair[1] else pair[0]
            val rightImg = if (swapped && pair.size > 1) pair[0] else if (pair.size > 1) pair[1] else null

            // Load LEFT thumbnail
            holder.thumbLeft?.setImageBitmap(null)
            val keyLeft = "thl_${groupIdx}_${leftImg.originalIdx}"
            val cachedLeft: Bitmap? = AppState.thumbCache.get(keyLeft)
            if (cachedLeft != null) {
                holder.thumbLeft?.setImageBitmap(cachedLeft)
            } else {
                holder.jobLeft = scope.launch {
                    val bm = withContext(Dispatchers.IO) {
                        BitmapUtils.decodeThumbnail(leftImg.data, 300)
                    }
                    if (bm != null) {
                        AppState.thumbCache.put(keyLeft, bm)
                        holder.thumbLeft?.setImageBitmap(bm)
                    }
                }
            }

            // Load RIGHT thumbnail
            holder.thumbRight?.setImageBitmap(null)
            if (rightImg != null) {
                val keyRight = "thr_${groupIdx}_${rightImg.originalIdx}"
                val cachedRight: Bitmap? = AppState.thumbCache.get(keyRight)
                if (cachedRight != null) {
                    holder.thumbRight?.setImageBitmap(cachedRight)
                } else {
                    holder.jobRight = scope.launch {
                        val bm = withContext(Dispatchers.IO) {
                            BitmapUtils.decodeThumbnail(rightImg.data, 300)
                        }
                        if (bm != null) {
                            AppState.thumbCache.put(keyRight, bm)
                            holder.thumbRight?.setImageBitmap(bm)
                        }
                    }
                }
            }

            // Swap button
            holder.btnSwap?.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (group != null && pos != RecyclerView.NO_ID.toInt()) {
                    @Suppress("UNCHECKED_CAST")
                    val curPair = items[pos] as List<ImageItem>
                    if (group.pairSwaps.contains(pos)) group.pairSwaps.remove(pos)
                    else group.pairSwaps.add(pos)
                    AppState.thumbCache.remove("mg_${curPair.map { it.originalIdx }}_false")
                    AppState.thumbCache.remove("mg_${curPair.map { it.originalIdx }}_true")
                    notifyItemChanged(pos)
                    onSwapChanged?.invoke()
                }
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        holder.jobLeft?.cancel()
        holder.jobRight?.cancel()
        super.onViewRecycled(holder)
    }

    fun destroy() = scope.cancel()
}
