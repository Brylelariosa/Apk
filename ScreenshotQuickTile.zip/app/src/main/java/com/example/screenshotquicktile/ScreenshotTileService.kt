package com.example.screenshotquicktile

import android.service.quicksettings.TileService
import android.content.Intent

class ScreenshotTileService : TileService() {

    override fun onClick() {
        super.onClick()
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivityAndCollapse(i)
    }
}
