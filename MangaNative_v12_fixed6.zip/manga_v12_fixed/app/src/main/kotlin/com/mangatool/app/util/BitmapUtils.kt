package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

object BitmapUtils {

    /**
     * Limited-concurrency dispatcher for ALL bitmap operations.
     *
     * Dispatchers.IO allows 64 concurrent threads. With 300+ images all decoding
     * simultaneously that thrashes the CPU, spikes GC, and freezes the UI thread.
     * Bitmap decoding is CPU-bound work — 3 threads matches most device core counts
     * and pipelines decodes smoothly without overwhelming the scheduler.
     */
    val decodeDispatcher = Executors.newFixedThreadPool(3).asCoroutineDispatcher()

    /** Decode just the pixel dimensions without loading the full bitmap. */
    fun decodeDimensions(data: ByteArray): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        return opts.outWidth to opts.outHeight
    }

    /**
     * Decode a thumbnail at most [maxPx] wide/tall.
     *
     * Uses RGB_565 (2 bytes/pixel) instead of ARGB_8888 (4 bytes/pixel) —
     * manga pages are JPEGs with no transparency so we get identical visual
     * quality at half the memory cost, doubling effective cache capacity.
     *
     * Strategy:
     *  1. inSampleSize coarse decode to ~2× target
     *  2. Bilinear createScaledBitmap for a precise, smooth final size
     */
    fun decodeThumbnail(data: ByteArray, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        // Coarse decode: stop one step early so rough bitmap is >= 2× target
        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeByteArray(data, 0, data.size,
            BitmapFactory.Options().apply {
                inSampleSize      = sample
                inPreferredConfig = Bitmap.Config.RGB_565   // half the memory of ARGB_8888
            }) ?: return null

        // Precise bilinear scale down to ≤ maxPx
        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /** Decode at full resolution (for preview). */
    fun decodeFull(data: ByteArray): Bitmap? =
        BitmapFactory.decodeByteArray(data, 0, data.size)
}
