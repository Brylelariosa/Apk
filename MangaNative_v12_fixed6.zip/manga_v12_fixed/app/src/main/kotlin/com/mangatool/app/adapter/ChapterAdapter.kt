package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onGroupShare: (groupIdx: Int) -> Unit,
    private val onGroupRename: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null,
    private val onFilteredPreview: ((groupIdx: Int, filteredImageIdx: Int) -> Unit)? = null,
    private val onBatchRestore: ((groupIdx: Int) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    private val expandedMain     = mutableSetOf<Int>()
    private val expandedFiltered = mutableSetOf<Int>()
    // Thumb adapters are NEVER destroyed on scroll — only on explicit remove/update.
    // This keeps in-flight coroutines alive and the LRU cache hot.
    private val thumbAdapters    = mutableMapOf<Int, ImageThumbAdapter>()
    private val filteredAdapters = mutableMapOf<Int, FilteredThumbAdapter>()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    var touchHelper: ItemTouchHelper? = null

    // Shared RecycledViewPool — ViewHolder inflation is amortised across all
    // chapter grids instead of each grid paying the full inflation cost separately.
    private val sharedThumbPool = RecyclerView.RecycledViewPool().also {
        it.setMaxRecycledViews(0, 24)   // keep 24 thumb VHs ready
    }

    init { setHasStableIds(true) }
    override fun getItemId(position: Int) = position.toLong()

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover:           ImageView   = v.findViewById(R.id.chapter_cover)
        val numBadge:        TextView    = v.findViewById(R.id.chapter_num_badge)
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val filteredCount:   TextView    = v.findViewById(R.id.filtered_count)
        val arrow:           TextView    = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val shareBtn:        View        = v.findViewById(R.id.chapter_share)
        val dragHandle:      TextView    = v.findViewById(R.id.drag_handle)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   TextView    = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
        val btnRestoreAll:   Button      = v.findViewById(R.id.btn_restore_all)
        var coverJob: Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        return VH(v)
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = groups[position]
        val isMerge = AppState.currentMode == AppMode.MERGE
        val isExpanded = position in expandedMain

        // ── Number badge ──────────────────────────────────────────────────────
        holder.numBadge.text = "${position + 1}"

        // ── Cover thumbnail (first image, loaded async) ───────────────────────
        val coverImg = group.displayImages.firstOrNull()
        if (coverImg != null) {
            val cacheKey = "cover_${position}_${coverImg.originalIdx}"
            val cached = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                // Already cached — set immediately, no flicker, no job needed
                holder.coverJob?.cancel()
                holder.cover.setImageBitmap(cached)
            } else {
                // Not cached — blank first then load async with limited dispatcher
                holder.coverJob?.cancel()
                holder.cover.setImageBitmap(null)
                holder.coverJob = scope.launch {
                    val bm = withContext(BitmapUtils.decodeDispatcher) {
                        runCatching { BitmapUtils.decodeThumbnail(coverImg.data, 160) }.getOrNull()
                    }
                    if (bm != null && isActive) {
                        AppState.thumbCache.put(cacheKey, bm)
                        holder.cover.setImageBitmap(bm)
                    }
                }
            }
        } else {
            holder.coverJob?.cancel()
            holder.cover.setImageBitmap(null)
        }

        // ── Name + count ──────────────────────────────────────────────────────
        holder.name.text = group.groupName

        if (isMerge) {
            val pairs = (group.displayImages.size + 1) / 2
            holder.count.text = "${group.displayImages.size} images · $pairs pairs"
            holder.dragHandle.visibility = View.GONE
            holder.filteredCount.visibility = View.GONE
            holder.filteredSection.visibility = View.GONE
            holder.removeBtn.visibility = if (groups.size > 1) View.VISIBLE else View.GONE
        } else {
            holder.dragHandle.visibility = View.VISIBLE
            holder.removeBtn.visibility  = View.VISIBLE
            holder.count.text = "${group.displayImages.size} images"
            val fCount = group.filteredImages.size
            holder.filteredCount.visibility = if (fCount > 0) View.VISIBLE else View.GONE
            if (fCount > 0) holder.filteredCount.text = "⚠ $fCount filtered"
        }

        holder.arrow.text = if (isExpanded) "▲" else "▼"

        // ── Drag to reorder ───────────────────────────────────────────────────
        holder.dragHandle.setOnTouchListener { _, event ->
            if (!isMerge && event.actionMasked == MotionEvent.ACTION_DOWN) touchHelper?.startDrag(holder)
            false
        }

        // ── Per-chapter actions — use bindingAdapterPosition to avoid stale pos ──
        holder.removeBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRemove(pos)
        }
        holder.shareBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupShare(pos)
        }
        holder.name.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
            true
        }

        // ── Expand / collapse ─────────────────────────────────────────────────
        holder.header.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups[pos]
            if (pos in expandedMain) {
                expandedMain.remove(pos)
                holder.grid.adapter = null
                holder.grid.visibility = View.GONE
            } else {
                expandedMain.add(pos)
                attachMainGrid(holder, pos, grp)
                holder.grid.visibility = View.VISIBLE
            }
            holder.arrow.text = if (pos in expandedMain) "▲" else "▼"
        }

        if (isExpanded) {
            attachMainGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            holder.grid.visibility = View.GONE
        }

        // ── Filtered section ──────────────────────────────────────────────────
        if (!isMerge && group.filteredImages.isNotEmpty()) {
            holder.filteredSection.visibility = View.VISIBLE
            holder.filteredLabel.text = "${group.filteredImages.size} filtered — tap to review"
            holder.filteredArrow.text = if (position in expandedFiltered) "▲" else "▼"
            holder.btnRestoreAll.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) onBatchRestore?.invoke(pos)
            }
            holder.filteredHeader.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
                val grp = groups[pos]
                if (pos in expandedFiltered) {
                    expandedFiltered.remove(pos)
                    filteredAdapters.remove(pos)?.destroy()
                    holder.filteredGrid.adapter = null
                    holder.filteredGrid.visibility = View.GONE
                } else {
                    expandedFiltered.add(pos)
                    attachFilteredGrid(holder, pos, grp)
                    holder.filteredGrid.visibility = View.VISIBLE
                }
                holder.filteredArrow.text = if (pos in expandedFiltered) "▲" else "▼"
            }
            if (position in expandedFiltered) {
                attachFilteredGrid(holder, position, group)
                holder.filteredGrid.visibility = View.VISIBLE
            } else {
                holder.filteredGrid.visibility = View.GONE
            }
        } else {
            holder.filteredSection.visibility = View.GONE
        }
    }

    /**
     * Attach the main thumb grid to [holder].
     *
     * KEY CHANGE: reuses the existing [ImageThumbAdapter] for [position] if one
     * already exists. Creating a new adapter destroys the coroutine scope, cancels
     * all in-flight thumbnail loads, and forces every visible thumbnail to reload
     * from scratch — that is the primary cause of scroll lag with 10+ MHTMLs.
     */
    private fun attachMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages) else group.displayImages
        val cols = if (isMerge) 2 else 3

        val adapter = thumbAdapters.getOrPut(position) {
            ImageThumbAdapter(
                items, isMerge,
                group           = if (isMerge) group else null,
                groupIdx        = position,
                onItemClick     = { idx -> onImageClick(position, idx) },
                onItemLongClick = onImageLongClick,
                onSwapChanged   = null
            )
        }

        // Only set a new LayoutManager if the grid doesn't have one yet
        if (holder.grid.layoutManager == null) {
            holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols)
        }
        holder.grid.setHasFixedSize(true)
        holder.grid.setRecycledViewPool(sharedThumbPool)
        holder.grid.setItemViewCacheSize(12)
        // Only set adapter if it changed (avoids a full rebind on every scroll)
        if (holder.grid.adapter !== adapter) {
            holder.grid.adapter = adapter
        }
    }

    private fun attachFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val adapter = filteredAdapters.getOrPut(position) {
            FilteredThumbAdapter(
                items     = group.filteredImages,
                groupIdx  = position,
                onPreview = { filtIdx -> onFilteredPreview?.invoke(position, filtIdx) },
                onRestore = { img -> img.forceKeep = true; img.userDeleted = false; onImageRestore?.invoke(img) }
            )
        }
        if (holder.filteredGrid.layoutManager == null) {
            holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3)
        }
        holder.filteredGrid.setHasFixedSize(true)
        holder.filteredGrid.setItemViewCacheSize(8)
        if (holder.filteredGrid.adapter !== adapter) {
            holder.filteredGrid.adapter = adapter
        }
    }

    /**
     * Notify that image dims changed for a specific item inside a group's thumb adapter.
     * Much cheaper than a full update() — only the one cell that got dims redraws.
     */
    fun notifyImageDimsChanged(groupIdx: Int, displayIdx: Int) {
        // Use PAYLOAD_DIMS so onBindViewHolder only updates the dims badge
        // without cancelling the in-flight thumbnail decode job.
        thumbAdapters[groupIdx]?.notifyItemChanged(displayIdx, ImageThumbAdapter.PAYLOAD_DIMS)
    }

    /**
     * Lightweight refresh: updates chapter-row metadata (name, count, cover) without
     * touching the thumb adapters or their coroutine scopes. Safe to call frequently.
     */
    fun update() {
        notifyDataSetChanged()
    }

    fun destroy() {
        scope.cancel()
        thumbAdapters.values.forEach { it.destroy() }; thumbAdapters.clear()
        filteredAdapters.values.forEach { it.destroy() }; filteredAdapters.clear()
    }

    override fun onViewRecycled(holder: VH) {
        holder.coverJob?.cancel()
        // Do NOT null out holder.grid.adapter here — the adapter lives in thumbAdapters
        // and will be reattached on the next bind. Nulling it forces a full rebind.
        super.onViewRecycled(holder)
    }
}

// ── Filtered thumbnail adapter ─────────────────────────────────────────────────
class FilteredThumbAdapter(
    private val items: List<com.mangatool.app.model.ImageItem>,
    private val groupIdx: Int = 0,
    private val onPreview: (Int) -> Unit,
    private val onRestore: (com.mangatool.app.model.ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val preview: View      = v.findViewById(R.id.btn_preview)
        val restore: View      = v.findViewById(R.id.btn_restore)
        var job:     Job?      = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_thumb_filtered, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text = img.filterReason ?: "Filtered"
        holder.image.setImageBitmap(null); holder.job?.cancel()
        val cacheKey = "filt_${groupIdx}_${img.originalIdx}"
        val cached = AppState.thumbCache.get(cacheKey)
        if (cached != null) {
            holder.image.setImageBitmap(cached)
        } else {
            holder.job = scope.launch {
                val bm = withContext(Dispatchers.IO) { BitmapUtils.decodeThumbnail(img.data, 200) }
                if (bm != null) { AppState.thumbCache.put(cacheKey, bm); holder.image.setImageBitmap(bm) }
            }
        }
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.preview.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.restore.setOnClickListener  { onRestore(img) }
    }

    override fun onViewRecycled(holder: VH) { holder.job?.cancel(); super.onViewRecycled(holder) }
    fun destroy() = scope.cancel()
}
