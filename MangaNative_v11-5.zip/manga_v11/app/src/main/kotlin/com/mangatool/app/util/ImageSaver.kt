package com.mangatool.app.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import java.io.ByteArrayOutputStream
import java.io.File
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers

object ImageSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val uris: List<Uri>, val folderName: String)

    // ── Cache hygiene ─────────────────────────────────────────────────────────
    /**
     * Delete the entire share_temp cache. Call:
     *  - on app start (onCreate)
     *  - after the share intent is sent
     *  - when the user resets
     * This prevents the cache from growing indefinitely across sessions.
     */
    fun clearShareCache(context: Context) {
        File(context.cacheDir, "share_temp").deleteRecursively()
    }

    /** Returns human-readable size of the share cache, e.g. "12 MB". */
    fun shareCacheSize(context: Context): String {
        val bytes = File(context.cacheDir, "share_temp")
            .walkTopDown().filter { it.isFile }.sumOf { it.length() }
        return when {
            bytes > 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
            bytes > 1024      -> "${bytes / 1024} KB"
            else              -> "$bytes B"
        }
    }

    // ── Save merged images as individual JPEGs in a named folder ──────────────
    fun saveMergeAsImages(
        context: Context,
        groups: List<ImageGroup>,
        folderName: String,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val uris = mutableListOf<Uri>()
        val safe = folderName.sanitize()
        var total = groups.sumOf { ImageMerger.pairImages(it.displayImages).size }.coerceAtLeast(1)
        var done  = 0

        groups.forEach { group ->
            val pairs = ImageMerger.pairImages(group.displayImages)
            pairs.forEachIndexed { i, pair ->
                onProgress(Progress("Merging ${group.groupName} (${i + 1}/${pairs.size})", (done * 100) / total))
                val swapped = group.pairSwaps.contains(i)
                val bm = ImageMerger.merge(pair, swapped) ?: run { done++; return@forEachIndexed }
                val bytes = bm.toJpegBytes(92); bm.recycle()
                val filename = "${(done + 1).toString().padStart(4, '0')}.jpg"
                val uri = saveBytesToDownloads(context, bytes, filename, "image/jpeg", safe)
                if (uri != null) uris.add(uri)
                done++
            }
        }

        onProgress(Progress("Done! ${uris.size} images saved", 100))
        return SaveResult(uris, safe)
    }

    // ── Save extracted images as a folder in Downloads ────────────────────────
    fun saveExtractAsFolder(
        context: Context,
        groups: List<ImageGroup>,
        folderName: String,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val uris  = mutableListOf<Uri>()
        val safe  = folderName.sanitize()
        val total = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
        var done  = 0

        groups.forEach { group ->
            val groupSafe = group.groupName.sanitize()
            group.displayImages.forEachIndexed { i, img ->
                if (i % 10 == 0) onProgress(Progress(
                    "Saving ${group.groupName} (${i + 1}/${group.displayImages.size})", (done * 100) / total))
                val subfolder = if (groups.size > 1) "$safe/$groupSafe" else safe
                val uri = saveBytesToDownloads(context, img.data, img.name, mimeForExt(img.ext), subfolder)
                if (uri != null) uris.add(uri)
                done++
            }
        }

        onProgress(Progress("Done! ${uris.size} images saved", 100))
        return SaveResult(uris, safe)
    }

    // ── Build share URIs (temp cache, no gallery save) ────────────────────────
    /**
     * Writes images to cache in PARALLEL — all files are written at the same
     * time instead of one by one. This is why ZArchiver feels instant: its files
     * are already on disk. We replicate that by parallelising the disk writes.
     *
     * JPEG originals: zero re-encode, just a byte copy (fastest possible).
     * PNG/WEBP: decoded + re-encoded in parallel across CPU cores.
     * Merged bitmaps: merged + encoded in parallel.
     */
    suspend fun buildShareUris(
        context: Context,
        groups: List<ImageGroup>,
        isMerge: Boolean,
        onProgress: (Progress) -> Unit
    ): List<Uri> = coroutineScope {
        val sessionDir = File(context.cacheDir, "share_temp/${System.currentTimeMillis()}").also { it.mkdirs() }
        val authority  = "${context.packageName}.fileprovider"

        if (isMerge) {
            data class PairTask(val groupRef: com.mangatool.app.model.ImageGroup, val pairIdx: Int, val pair: List<com.mangatool.app.model.ImageItem>)
            val tasks = mutableListOf<PairTask>()
            groups.forEach { group -> ImageMerger.pairImages(group.displayImages).forEachIndexed { i, pair -> tasks.add(PairTask(group, i, pair)) } }
            val total = tasks.size.coerceAtLeast(1)
            onProgress(Progress("Preparing 0/$total…", 0))

            val deferreds = tasks.mapIndexed { idx, task ->
                async(Dispatchers.IO) {
                    val swapped = task.groupRef.pairSwaps.contains(task.pairIdx)
                    val bm = ImageMerger.merge(task.pair, swapped) ?: return@async null
                    val file = File(sessionDir, "${(idx + 1).toString().padStart(4, '0')}.jpg")
                    file.writeBytes(bm.toJpegBytes(92)); bm.recycle()
                    onProgress(Progress("Preparing ${idx + 1}/$total…", ((idx + 1) * 100) / total))
                    file
                }
            }
            deferreds.awaitAll()
                .filterNotNull()
                .map { FileProvider.getUriForFile(context, authority, it) }

        } else {
            val allImages = groups.flatMap { it.displayImages }
            val total     = allImages.size.coerceAtLeast(1)
            onProgress(Progress("Preparing 0/$total…", 0))

            val deferreds = allImages.mapIndexed { idx, img ->
                async(Dispatchers.IO) {
                    val file = File(sessionDir, "${(idx + 1).toString().padStart(4, '0')}.jpg")
                    val ext  = img.ext.lowercase()
                    if (ext == "jpg" || ext == "jpeg") {
                        file.writeBytes(img.data)
                    } else {
                        val bm = BitmapUtils.decodeFull(img.data)
                        if (bm != null) { file.writeBytes(bm.toJpegBytes(92)); bm.recycle() }
                        else file.writeBytes(img.data)
                    }
                    onProgress(Progress("Preparing ${idx + 1}/$total…", ((idx + 1) * 100) / total))
                    file
                }
            }
            deferreds.awaitAll()
                .map { FileProvider.getUriForFile(context, authority, it) }
        }.also { onProgress(Progress("Ready", 100)) }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun saveBytesToDownloads(
        ctx: Context, bytes: ByteArray, filename: String, mime: String, subfolder: String
    ): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$subfolder")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
                ctx.contentResolver.update(uri, cv, null, null)
            }
            uri
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), subfolder
            ).also { it.mkdirs() }
            val file = File(dir, filename)
            runCatching { file.writeBytes(bytes) }
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        }
    }

    private fun mimeForExt(ext: String) = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/*"
    }

    private fun Bitmap.toPngBytes(): ByteArray {
        val out = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.PNG, 0, out)
        return out.toByteArray()
    }

    private fun String.sanitize() =
        replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "MIE_Export" }
}

// Top-level extensions shared by ImageSaver and FolderSaver
fun android.graphics.Bitmap.toJpegBytes(quality: Int = 92): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, out)
    return out.toByteArray()
}

// Extension: save into a user-chosen folder (ACTION_OPEN_DOCUMENT_TREE URI)
object FolderSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val count: Int, val folderName: String)

    /** Save extract groups into a user-picked folder tree URI. */
    fun saveExtractToTree(
        context: Context,
        treeUri: android.net.Uri,
        groups: List<com.mangatool.app.model.ImageGroup>,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val root = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Cannot open folder")
        val total = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
        var done  = 0

        groups.forEach { group ->
            // If multiple groups, create a sub-folder per group
            val dir = if (groups.size > 1) {
                root.findFile(group.groupName.sanitize())
                    ?: root.createDirectory(group.groupName.sanitize())
                    ?: root
            } else root

            group.displayImages.forEachIndexed { i, img ->
                if (i % 10 == 0) onProgress(Progress(
                    "Saving ${group.groupName} (${i + 1}/${group.displayImages.size})",
                    (done * 100) / total
                ))
                val mime = when (img.ext.lowercase()) {
                    "jpg", "jpeg" -> "image/jpeg"
                    "png"  -> "image/png"
                    "webp" -> "image/webp"
                    else   -> "image/jpeg"
                }
                val file = dir.createFile(mime, img.name.substringBeforeLast('.'))
                file?.let {
                    context.contentResolver.openOutputStream(it.uri)?.use { out -> out.write(img.data) }
                }
                done++
            }
        }

        onProgress(Progress("Done! $done images saved", 100))
        val folderName = root.name ?: "Selected folder"
        return SaveResult(done, folderName)
    }

    /** Save merged image pairs into a user-picked folder tree URI.
     *  Each photo is saved as: photoName_0001.jpg, photoName_0002.jpg …
     *  Full quality JPEG (92) — no resize, no downscale. */
    fun saveMergeToTree(
        context: Context,
        treeUri: android.net.Uri,
        groups: List<com.mangatool.app.model.ImageGroup>,
        photoName: String = "Merged",
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val root = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Cannot open folder")
        val total = groups.sumOf { ImageMerger.pairImages(it.displayImages).size }.coerceAtLeast(1)
        val safeName = photoName.replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "Merged" }
        var done  = 0

        groups.forEach { group ->
            val pairs = ImageMerger.pairImages(group.displayImages)
            pairs.forEachIndexed { i, pair ->
                onProgress(Progress("Merging (${i + 1}/${pairs.size})", (done * 100) / total))
                val swapped = group.pairSwaps.contains(i)
                val bm = ImageMerger.merge(pair, swapped) ?: run { done++; return@forEachIndexed }
                // Full quality JPEG — no quality loss
                val bytes = bm.toJpegBytes(92); bm.recycle()
                // Name: "Chapter1_0001", "Chapter1_0002", …
                val filename = "${safeName}_${(done + 1).toString().padStart(4, '0')}"
                val file = root.createFile("image/jpeg", filename)
                file?.let {
                    context.contentResolver.openOutputStream(it.uri)?.use { out -> out.write(bytes) }
                }
                done++
            }
        }

        onProgress(Progress("Done! $done photos saved", 100))
        return SaveResult(done, root.name ?: "Selected folder")
    }

    private fun String.sanitize() = replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "MIE" }
}
