package com.gary.lightbrowser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private WebView webView;
    private EditText urlBar;
    private ProgressBar progressBar;
    private ImageButton btnBack, btnForward, btnRefresh, btnHome;

    private static final String HOME_URL = "https://lite.duckduckgo.com/lite/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView     = findViewById(R.id.webview);
        urlBar      = findViewById(R.id.url_bar);
        progressBar = findViewById(R.id.progress_bar);
        btnBack     = findViewById(R.id.btn_back);
        btnForward  = findViewById(R.id.btn_forward);
        btnRefresh  = findViewById(R.id.btn_refresh);
        btnHome     = findViewById(R.id.btn_home);

        setupWebView();
        setupControls();

        // Handle VIEW intent (clicked a link from another app)
        Intent intent = getIntent();
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            loadUrl(intent.getData().toString());
        } else if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            loadUrl(HOME_URL);
        }
    }

    // ────────────────────────────────────────────────────────────────────────
    //  WebView setup — tuned for low-end hardware
    // ────────────────────────────────────────────────────────────────────────
    private void setupWebView() {
        WebSettings s = webView.getSettings();

        s.setJavaScriptEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setDomStorageEnabled(false);          // saves RAM
        s.setDatabaseEnabled(false);
        s.setGeolocationEnabled(false);

        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        // Prefer mobile / lite pages to save data & speed up rendering
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 4.4; LightBrowser) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/52.0.2743.98 Mobile Safari/537.36"
        );

        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setScrollbarFadingEnabled(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                urlBar.setText(url);
                progressBar.setVisibility(View.VISIBLE);
                updateNavButtons();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                urlBar.setText(url);
                progressBar.setVisibility(View.GONE);
                updateNavButtons();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep non-http in external apps
                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) {}
                    return true;
                }
                return false;   // load normally
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progressBar.setProgress(p);
                if (p == 100) progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                // Show title in URL bar when page finishes loading
            }
        });
    }

    // ────────────────────────────────────────────────────────────────────────
    //  Controls
    // ────────────────────────────────────────────────────────────────────────
    private void setupControls() {
        urlBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean go = actionId == EditorInfo.IME_ACTION_GO;
                boolean enter = event != null
                        && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                        && event.getAction() == KeyEvent.ACTION_DOWN;
                if (go || enter) {
                    loadUrl(urlBar.getText().toString().trim());
                    hideKeyboard();
                    return true;
                }
                return false;
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (webView.canGoBack()) webView.goBack();
            }
        });

        btnForward.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (webView.canGoForward()) webView.goForward();
            }
        });

        btnRefresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                webView.reload();
            }
        });

        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                loadUrl(HOME_URL);
            }
        });
    }

    // ────────────────────────────────────────────────────────────────────────
    //  URL / search resolution
    // ────────────────────────────────────────────────────────────────────────
    private void loadUrl(String input) {
        if (input == null || input.isEmpty()) return;
        String url;
        if (input.startsWith("http://") || input.startsWith("https://")) {
            url = input;
        } else if (input.contains(".") && !input.contains(" ")) {
            url = "https://" + input;
        } else {
            // Treat as search query — DuckDuckGo Lite is light on RAM
            url = "https://lite.duckduckgo.com/lite/?q=" + Uri.encode(input);
        }
        webView.loadUrl(url);
        urlBar.setText(url);
        urlBar.clearFocus();
    }

    private void updateNavButtons() {
        btnBack.setAlpha(webView.canGoBack() ? 1.0f : 0.3f);
        btnForward.setAlpha(webView.canGoForward() ? 1.0f : 0.3f);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    // ────────────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ────────────────────────────────────────────────────────────────────────
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        webView.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        webView.stopLoading();
        webView.destroy();
        super.onDestroy();
    }
}
