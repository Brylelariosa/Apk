package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.format.Field
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.table.format.PointerKind
import dev.hexmaniac.core.text.PcsTable

/** One selectable value of a [FieldEditor.Choice]. */
class ChoiceEntry(val value: Long, val name: String)

/** What a screen needs to let the user change one value, and the value's current state. */
sealed class FieldEditor {
    /** A plain number; [hex] numbers are typed in hexadecimal. */
    class Number(val current: Long, val min: Long, val max: Long, val hex: Boolean) : FieldEditor() {
        /** The number typed by the user; "0x" and "$" prefixes are accepted, hex fields take hex digits. */
        fun parse(text: String): Long? {
            val t = text.trim()
            if (t.isEmpty()) return null
            val digits = t.removePrefix("0x").removePrefix("0X").removePrefix("$")
            val isHex = hex || digits.length != t.length
            return if (isHex) digits.toLongOrNull(16) else t.toLongOrNull()
        }
    }

    /** A value picked from named entries; [min]..[max] is the range of numbers the field can hold. */
    class Choice(val entries: List<ChoiceEntry>, val current: Long, val min: Long, val max: Long) : FieldEditor()

    class Flag(val on: Boolean) : FieldEditor()

    /** Fixed width text; the encoded text, with its end mark, must fit into [maxBytes]. */
    class Text(val current: String, val maxBytes: Int) : FieldEditor()

    /** Text a pointer leads to; it can be replaced by text that fits into [capacity] bytes (end mark included). */
    class PointedText(val current: String, val capacity: Int) : FieldEditor()

    /** A pointer; [current] is the file offset it leads to, or -1 when it is null or not a pointer. */
    class Address(val current: Int, val romSize: Int) : FieldEditor()

    /** A set of flags; [selected] are the indexes of the bits that are set. */
    class Bits(val names: List<String>, val selected: Set<Int>) : FieldEditor()

    class Color(val current: String) : FieldEditor()

    /** A pointer to a nested table, which can be opened. */
    class OpenTable(val path: TablePath) : FieldEditor()
}

/** A change to the ROM: bytes to overwrite, and the size the ROM must have beforehand. */
class EditPlan(val label: String, val writes: List<ByteWrite>, val minimumSize: Int = 0) {
    /** Performs the change as one undoable step. */
    fun applyTo(document: RomDocument) {
        document.edit(label) {
            if (minimumSize > document.rom.size) document.resize(minimumSize, label)
            for (write in writes) document.write(write.offset, write.bytes, label)
        }
    }
}

class ByteWrite(val offset: Int, val bytes: ByteArray)

/** The outcome of asking for a change: a plan that can be applied, or the reason it cannot be done. */
sealed class EditResult {
    class Ready(val plan: EditPlan) : EditResult()
    class Rejected(val message: String) : EditResult()
}

/** Works out the editors for fields and the byte changes that edits cause. It never modifies the ROM itself. */
internal class FieldWriter(
    private val rom: RomData,
    private val pcs: PcsTable,
    private val gameCode: String,
    private val catalog: TableCatalog,
    private val reader: FieldReader,
) {
    fun editorFor(table: TableLocation, row: Int, index: Int, asAddress: Boolean): FieldEditor {
        val field = catalog.concreteField(table, row, index)
        val rowStart = table.rowStart(row)
        val raw = reader.raw(field, rowStart)
        return when (field.kind) {
            FieldKind.NUMBER, FieldKind.RECORD -> numberEditor(field, raw)
            FieldKind.SIGNED -> FieldEditor.Number(Values.toSigned(raw, field.size), minValue(field), maxValue(field), false)
            FieldKind.HEX -> FieldEditor.Number(raw, 0, maxValue(field), true)
            FieldKind.FLAG -> FieldEditor.Flag(raw != 0L)
            FieldKind.TEXT -> FieldEditor.Text(Texts.editable(catalog.readText(rowStart, field)).orEmpty(), field.size)
            FieldKind.POINTER -> pointerEditor(table, row, index, field, rowStart, asAddress)
            FieldKind.BITS -> bitsEditor(field, raw)
            FieldKind.COLOR -> FieldEditor.Color(Colors.hex(raw.toInt()))
        }
    }

    private fun numberEditor(field: Field, raw: Long): FieldEditor {
        val name = field.enumName
        if (name != null && name.toIntOrNull() == null) {
            val entries = ArrayList<ChoiceEntry>()
            catalog.options(name).forEachIndexed { i, option -> if (option != null) entries.add(ChoiceEntry(i.toLong() + field.enumOffset, option)) }
            if (entries.isNotEmpty()) return FieldEditor.Choice(entries, raw, 0, maxValue(field))
        }
        return FieldEditor.Number(raw, 0, maxValue(field), false)
    }

    private fun pointerEditor(table: TableLocation, row: Int, index: Int, field: Field, rowStart: Int, asAddress: Boolean): FieldEditor {
        val at = rowStart + field.offset
        val target = rom.pointerTarget(at)
        val kind = field.pointer?.kind
        if (!asAddress && target >= 0) {
            if (kind == PointerKind.TABLE) catalog.child(table, row, index)?.let { return FieldEditor.OpenTable(it.path) }
            if (kind == PointerKind.TEXT) return pointedTextEditor(field, rowStart, target)
        }
        return FieldEditor.Address(target, rom.size)
    }

    private fun pointedTextEditor(field: Field, rowStart: Int, target: Int): FieldEditor {
        val text = Texts.editable(catalog.readText(rowStart, field)).orEmpty()
        val length = pcs.readStringLength(rom.bytes, target, true, MAX_TEXT_BYTES)
        return FieldEditor.PointedText(text, maxOf(length, 0))
    }

    private fun bitsEditor(field: Field, raw: Long): FieldEditor {
        val known = field.bitSource?.let { catalog.options(it) }.orEmpty()
        val count = if (known.isEmpty()) minOf(field.size * 8, 8) else minOf(known.size, field.size * 8)
        val names = List(count) { known.getOrNull(it) ?: "Bit $it" }
        val selected = (0 until count).filter { (raw ushr it) and 1L != 0L }.toSet()
        return FieldEditor.Bits(names, selected)
    }

    // ---- writing ----

    fun setNumber(table: TableLocation, row: Int, index: Int, value: Long): EditResult {
        val field = catalog.concreteField(table, row, index)
        if (field.kind != FieldKind.NUMBER && field.kind != FieldKind.SIGNED && field.kind != FieldKind.HEX &&
            field.kind != FieldKind.FLAG && field.kind != FieldKind.RECORD
        ) {
            return EditResult.Rejected("This value is not a number.")
        }
        val low = if (field.kind == FieldKind.SIGNED) minValue(field) else 0L
        val high = maxValue(field)
        if (value < low || value > high) return EditResult.Rejected("Enter a value from $low to $high.")
        val stored = if (field.kind == FieldKind.SIGNED) value and ((1L shl field.width) - 1) else value
        return writeBits(table, row, field, stored)
    }

    fun setBits(table: TableLocation, row: Int, index: Int, selected: Set<Int>): EditResult {
        val field = catalog.concreteField(table, row, index)
        if (field.kind != FieldKind.BITS) return EditResult.Rejected("This value is not a set of flags.")
        val editor = bitsEditor(field, 0) as FieldEditor.Bits
        val known = editor.names.size
        val knownMask = if (known >= 64) -1L else (1L shl known) - 1
        var chosen = 0L
        for (bit in selected) if (bit in 0 until known) chosen = chosen or (1L shl bit)
        val old = reader.raw(field, table.rowStart(row))
        return writeBits(table, row, field, (old and knownMask.inv()) or chosen)
    }

    fun setColor(table: TableLocation, row: Int, index: Int, text: String): EditResult {
        val field = catalog.concreteField(table, row, index)
        if (field.kind != FieldKind.COLOR) return EditResult.Rejected("This value is not a colour.")
        val color = Colors.parse(text) ?: return EditResult.Rejected("Enter a colour as six hex digits, like #FF8000.")
        return writeBits(table, row, field, color.toLong())
    }

    /** Writes [value] into the field's bits, keeping the other bits of a packed integer as they are. */
    private fun writeBits(table: TableLocation, row: Int, field: Field, value: Long): EditResult {
        val at = table.rowStart(row) + field.offset
        val whole = if (field.isSlice) {
            val mask = ((1L shl field.width) - 1) shl field.shift
            (Values.readUnsigned(rom, at, field.size) and mask.inv()) or ((value shl field.shift) and mask)
        } else {
            value
        }
        return ready(label(table, row, field), at, Values.toBytes(whole, field.size))
    }

    fun setText(table: TableLocation, row: Int, index: Int, text: String): EditResult {
        val field = catalog.concreteField(table, row, index)
        val encoded = pcs.encode(text, gameCode)
        if (encoded.hasBadCharacters) return EditResult.Rejected("The text has characters the game cannot display.")
        val rowStart = table.rowStart(row)
        if (field.kind == FieldKind.TEXT) return setFixedText(table, row, field, rowStart, encoded.bytes)
        if (field.kind == FieldKind.POINTER && field.pointer?.kind == PointerKind.TEXT) {
            return setPointedText(table, row, field, rowStart, encoded.bytes)
        }
        return EditResult.Rejected("This value is not text.")
    }

    private fun setFixedText(table: TableLocation, row: Int, field: Field, rowStart: Int, encoded: ByteArray): EditResult {
        val at = rowStart + field.offset
        if (field.size == 1) {
            if (encoded.size != 2) return EditResult.Rejected("This field holds exactly one character.")
            return ready(label(table, row, field), at, byteArrayOf(encoded[0]))
        }
        if (encoded.size > field.size) {
            return EditResult.Rejected("The text needs ${encoded.size} bytes but the field holds ${field.size}, including the end mark.")
        }
        val bytes = ByteArray(field.size)
        System.arraycopy(encoded, 0, bytes, 0, encoded.size)
        return ready(label(table, row, field), at, bytes)
    }

    private fun setPointedText(table: TableLocation, row: Int, field: Field, rowStart: Int, encoded: ByteArray): EditResult {
        val target = rom.pointerTarget(rowStart + field.offset)
        if (target < 0) return EditResult.Rejected("The pointer does not lead to text. Set its address first.")
        val capacity = pcs.readStringLength(rom.bytes, target, true, MAX_TEXT_BYTES)
        if (capacity < 1) return EditResult.Rejected("The data the pointer leads to is not text.")
        if (encoded.size > capacity) {
            return EditResult.Rejected("The text needs ${encoded.size} bytes but only $capacity are available at its current place.")
        }
        return ready(label(table, row, field), target, encoded)
    }

    fun setAddress(table: TableLocation, row: Int, index: Int, text: String): EditResult {
        val field = catalog.concreteField(table, row, index)
        if (field.kind != FieldKind.POINTER) return EditResult.Rejected("This value is not a pointer.")
        val trimmed = text.trim()
        val word: Long
        if (trimmed.isEmpty() || trimmed.equals("null", ignoreCase = true)) {
            word = 0L
        } else {
            val address = HexText.parseAddress(trimmed) ?: return EditResult.Rejected("Enter an address in hexadecimal.")
            if (address >= rom.size) return EditResult.Rejected("That address is past the end of the ROM.")
            word = Values.POINTER_BASE or address.toLong()
        }
        return ready(label(table, row, field), table.rowStart(row) + field.offset, Values.toBytes(word, 4))
    }

    private fun ready(label: String, offset: Int, bytes: ByteArray): EditResult =
        EditResult.Ready(EditPlan(label, listOf(ByteWrite(offset, bytes))))

    private fun label(table: TableLocation, row: Int, field: Field): String {
        val where = table.path.steps.joinToString("") { "[${it.row}]" }
        return "Edit ${table.name}$where[$row].${field.label}"
    }

    private fun maxValue(field: Field): Long = if (field.kind == FieldKind.SIGNED) (1L shl (field.width - 1)) - 1 else (1L shl field.width) - 1

    private fun minValue(field: Field): Long = -(1L shl (field.width - 1))

    private companion object {
        const val MAX_TEXT_BYTES = 4096
    }
}
