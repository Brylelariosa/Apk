package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.format.Field
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.table.format.FormatException
import dev.hexmaniac.core.table.format.FormatParser
import dev.hexmaniac.core.table.format.LengthSpec
import dev.hexmaniac.core.table.format.PointerKind
import dev.hexmaniac.core.table.format.Schema
import dev.hexmaniac.core.table.format.TableFormat
import dev.hexmaniac.core.text.PcsTable

/**
 * The tables, lists and constants of one game as they are in one ROM image: finds where every table starts
 * (following the pointers named by the reference data), decides how many rows it has and names its values.
 *
 * A catalog reads the ROM lazily and remembers what it found, so it describes the ROM as it was when the
 * catalog was made; build a new one after the ROM changes.
 */
internal class TableCatalog(
    private val rom: RomData,
    private val pcs: PcsTable,
    private val gameCode: String,
    private val data: GameData,
) : OptionSource {

    private class Definition(val name: String, val start: Int, val format: String)

    private val definitions: Map<String, Definition> = findDefinitions()
    private val starts: IntArray = definitions.values.map { it.start }.distinct().sorted().toIntArray()
    private val lists: Map<String, List<String?>> = data.metadata.lists.associate { it.name to it.items }
    private val constants: Map<String, Int> = readConstants()
    private val parser = FormatParser { optionCount(it) }
    private val scanner = RowScanner(rom, pcs, this)

    private val formats = HashMap<String, TableFormat?>()
    private val resolved = HashMap<String, TableLocation?>()
    private val resolving = HashSet<String>()
    private val optionCache = HashMap<String, List<String?>>()

    /** How often a table was asked for while it was being worked out; answers found then may be incomplete. */
    private var cycleHits = 0

    /** Names of every table defined for this game and found in this ROM, resolved or not. */
    val names: Collection<String> get() = definitions.keys

    // ---- finding tables ----

    private fun findDefinitions(): Map<String, Definition> {
        val found = LinkedHashMap<String, Definition>()
        for (table in data.tables) {
            if (table.pointerAddress < 0 || table.pointerAddress + 4 > rom.size) continue
            val word = rom.readWord(table.pointerAddress).toLong() and 0xFFFFFFFFL
            val start = word - Values.POINTER_BASE - table.offset
            if (start < 0 || start > rom.size) continue
            found[table.name] = Definition(table.name, start.toInt(), table.format)
        }
        for (anchor in data.metadata.anchors) {
            if (!anchor.format.trimStart('^').startsWith("[")) continue
            if (anchor.address < 0 || anchor.address > rom.size) continue
            found[anchor.name] = Definition(anchor.name, anchor.address, anchor.format)
        }
        return found
    }

    /** A constant is only believed when every place that stores it agrees. */
    private fun readConstants(): Map<String, Int> {
        val result = HashMap<String, Int>()
        for ((name, group) in data.constants.groupBy { it.name }) {
            if (group.any { c -> c.addresses.any { it < 0 || it + c.size > rom.size } }) continue
            val values = ArrayList<Int>()
            for (c in group) {
                for (address in c.addresses) {
                    val raw = Values.readUnsigned(rom, address, c.size).toInt()
                    values.add((raw - c.addOffset) / c.multiplier)
                }
            }
            if (values.isNotEmpty() && values.all { it == values[0] }) result[name] = values[0]
        }
        return result
    }

    private fun nextStartAfter(start: Int): Int {
        var low = 0
        var high = starts.size
        while (low < high) {
            val mid = (low + high) ushr 1
            if (starts[mid] > start) high = mid else low = mid + 1
        }
        return if (low < starts.size) starts[low] else rom.size
    }

    // ---- options ----

    override fun optionCount(name: String): Int? {
        name.toIntOrNull()?.let { return it }
        lists[name]?.let { return it.size }
        return location(name)?.rowCount
    }

    override fun isList(name: String): Boolean = lists.containsKey(name)

    /**
     * The names of the values called [name]: a fixed list, or the name of every row of the table of that name (see
     * [ownNames]). Values without a name are null. Empty when [name] is unknown.
     */
    fun options(name: String): List<String?> {
        optionCache[name]?.let { return it }
        val cyclesBefore = cycleHits
        val built = buildOptions(name)
        if (cycleHits == cyclesBefore) optionCache[name] = built
        return built
    }

    private fun buildOptions(name: String): List<String?> {
        name.toIntOrNull()?.let { count -> return List(count.coerceIn(0, MAX_NUMERIC_OPTIONS)) { it.toString() } }
        lists[name]?.let { return it }
        val table = location(name) ?: return emptyList()
        return ownNames(table.start, table.schema, table.rowCount)
    }

    /**
     * What the rows of a table are called by their own content: the first value that is text, or that is a number
     * with names (a table of move numbers is named after the moves). Empty when there is no such value.
     */
    private fun ownNames(start: Int, schema: Schema, rows: Int): List<String?> {
        val field = schema.fields.firstOrNull { it.group == null && (isText(it) || hasNames(it)) } ?: return emptyList()
        return List(rows) { row -> nameOf(start + row * schema.rowSize, field) }
    }

    private fun nameOf(rowStart: Int, field: Field): String? {
        if (isText(field)) return Texts.cleaned(readText(rowStart, field))
        val position = Values.fieldValue(rom, rowStart, field) - field.enumOffset
        if (position < 0 || position > Int.MAX_VALUE) return null
        return options(field.enumName ?: return null).getOrNull(position.toInt())
    }

    private fun hasNames(field: Field): Boolean {
        val name = field.enumName ?: return false
        return field.kind == FieldKind.NUMBER && name.toIntOrNull() == null
    }

    private fun isText(field: Field) =
        field.kind == FieldKind.TEXT || (field.kind == FieldKind.POINTER && field.pointer?.kind == PointerKind.TEXT)

    /** Text of a text field or of the text a pointer field leads to; null when the pointer is not usable. */
    fun readText(rowStart: Int, field: Field): String? {
        val at = rowStart + field.offset
        if (field.kind == FieldKind.TEXT) return pcs.decode(rom.bytes, at, field.size, gameCode)
        val target = rom.pointerTarget(at)
        if (target < 0) return null
        return pcs.decode(rom.bytes, target, MAX_POINTED_TEXT, gameCode)
    }

    /** What row [row] of [table] is called, or null when it has no name. */
    fun rowLabel(table: TableLocation, row: Int): String? = table.labels.getOrNull(row - table.labelBegin)

    // ---- table lookup ----

    fun location(name: String): TableLocation? {
        if (resolved.containsKey(name)) return resolved[name]
        val definition = definitions[name] ?: return null
        if (!resolving.add(name)) {
            cycleHits++
            return null
        }
        try {
            val location = resolve(definition)
            resolved[name] = location
            return location
        } finally {
            resolving.remove(name)
        }
    }

    private fun parse(definition: Definition): TableFormat? {
        if (formats.containsKey(definition.name)) return formats[definition.name]
        val format = try {
            parser.parse(definition.format)
        } catch (e: FormatException) {
            null
        }
        formats[definition.name] = format
        return format
    }

    private fun resolve(definition: Definition): TableLocation? {
        val format = parse(definition) ?: return null
        val start = definition.start
        val counted = countRows(format, start, null) ?: return null
        val (rows, trailing) = counted
        val fit = fittingRows(start, format, rows, trailing)
        if (fit <= 0) return null
        val labels = rowLabels(start, format, fit)
        return TableLocation(TablePath(definition.name), start, format, fit, trailing, labels.names, labels.begin)
    }

    /**
     * The row count of a table at [start] and the length of its end code, or null when it cannot be known.
     * [parent] is the row holding the pointer for nested tables; it supplies counts stored next to the pointer.
     */
    private fun countRows(format: TableFormat, start: Int, parent: ParentRow?): Pair<Int, Int>? {
        val schema = format.schema
        return when (val spec = format.length) {
            is LengthSpec.Fixed -> spec.count to 0
            is LengthSpec.Auto -> scanner.countAuto(start, schema, nextStartAfter(start)) to 0
            is LengthSpec.FromName -> countFromName(spec)?.let { it to 0 }
            is LengthSpec.EndCode -> {
                val count = scanner.countUntil(start, schema, spec.code)
                if (count < 0) null else count to spec.code.size
            }
            is LengthSpec.FromField -> parent?.let { storedCount(it, spec.field) }?.let { it to 0 }
            is LengthSpec.Unsupported -> null
        }
    }

    private class ParentRow(val table: TableLocation, val rowStart: Int, val fieldIndex: Int)

    private fun storedCount(parent: ParentRow, fieldName: String): Int? {
        val schema = parent.table.schema
        val field = schema.siblingFor(parent.fieldIndex, fieldName) ?: return null
        if (field.kind == FieldKind.TEXT || field.kind == FieldKind.POINTER || field.kind == FieldKind.BITS) return null
        val value = Values.readUnsigned(rom, parent.rowStart + field.offset, field.size)
        return maxOf(1L, value).coerceAtMost(MAX_STORED_COUNT.toLong()).toInt()
    }

    /** Row count named by a table (plus margins), a list or a constant. Null when the name is not known. */
    private fun countFromName(spec: LengthSpec.FromName): Int? {
        location(spec.name)?.let { return (it.rowCount + spec.begin + spec.end).takeIf { n -> n >= 1 } }
        lists[spec.name]?.let { return it.size.takeIf { n -> n >= 1 } }
        constants[spec.name]?.let { return it.takeIf { n -> n >= 1 } }
        return null
    }

    private fun fittingRows(start: Int, format: TableFormat, rows: Int, trailing: Int): Int {
        val available = rom.size - start - trailing
        if (available < 0) return 0
        return minOf(rows.toLong(), (available / format.schema.rowSize).toLong()).toInt()
    }

    // ---- labels ----

    private class Labels(val names: List<String?>, val begin: Int)

    /**
     * Names for the rows of a table: the names of the table whose length it follows, or else its own.
     * A table that follows a longer one by a margin (`names-1`) skips the first names.
     */
    private fun rowLabels(start: Int, format: TableFormat, rows: Int): Labels {
        val spec = format.length
        if (spec is LengthSpec.FromName) {
            val source = options(spec.name)
            if (source.isNotEmpty()) return Labels(source, spec.begin)
        }
        return Labels(ownNames(start, format.schema, rows), 0)
    }

    // ---- nested tables ----

    /** The table that row [row] of [parent] points to through the pointer field [fieldIndex], or null. */
    fun child(parent: TableLocation, row: Int, fieldIndex: Int): TableLocation? {
        val field = parent.schema.fields.getOrNull(fieldIndex) ?: return null
        val concrete = concreteField(parent, row, fieldIndex)
        val spec = concrete.pointer ?: return null
        if (concrete.kind != FieldKind.POINTER || spec.kind != PointerKind.TABLE) return null
        val format = spec.table ?: return null
        val rowStart = parent.rowStart(row)
        val target = rom.pointerTarget(rowStart + field.offset)
        if (target < 0) return null
        val (rows, trailing) = countRows(format, target, ParentRow(parent, rowStart, fieldIndex)) ?: return null
        val fit = fittingRows(target, format, rows, trailing)
        if (fit <= 0) return null
        val path = parent.path.child(row, fieldIndex)
        return TableLocation(path, target, format, fit, trailing, emptyList(), 0)
    }

    /**
     * The field as it applies to this row: a record field (whose type depends on another field) becomes a number
     * with the right names, or a pointer.
     */
    fun concreteField(table: TableLocation, row: Int, fieldIndex: Int): Field {
        val field = table.schema.fields[fieldIndex]
        val record = field.record ?: return field
        val match = table.schema.siblingFor(fieldIndex, record.matchField) ?: return field.asNumber()
        val value = Values.readUnsigned(rom, table.rowStart(row) + match.offset, match.size).toInt()
        val case = record.cases[value] ?: return field.asNumber()
        if (case.startsWith("<") && case.endsWith(">")) {
            val inner = case.substring(1, case.length - 1)
            return field.copy(kind = FieldKind.POINTER, size = 4, pointer = dev.hexmaniac.core.table.format.PointerSpec(inner, parser))
        }
        return field.copy(kind = FieldKind.NUMBER, enumName = case, record = null)
    }

    private fun Field.asNumber(): Field = copy(kind = FieldKind.NUMBER, record = null)

    private companion object {
        const val MAX_NUMERIC_OPTIONS = 100_000
        const val MAX_POINTED_TEXT = 4096
        const val MAX_STORED_COUNT = 100_000
    }
}

/** Helpers for turning decoded PCS text into the plain strings shown to people. */
internal object Texts {
    /** The text without the quotes around it, with its line breaks: what a person edits. Null stays null. */
    fun editable(text: String?): String? {
        if (text == null) return null
        var t = text
        if (t.startsWith("\"")) t = t.substring(1)
        if (t.endsWith("\"")) t = t.substring(0, t.length - 1)
        return t.replace("\r", "")
    }

    /** The text for one line of a list: no quotes, line breaks turned into spaces. Null stays null. */
    fun cleaned(text: String?): String? = editable(text)?.replace('\n', ' ')?.trim()
}
