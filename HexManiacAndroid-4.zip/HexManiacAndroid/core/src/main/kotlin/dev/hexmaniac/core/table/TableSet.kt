package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.text.PcsTable

/**
 * The data tables of one game as they are in one ROM: the browsing and editing API of the table screens.
 *
 * A table is named by a [TablePath]; [locate] finds it in the ROM. Nothing here changes the ROM: the `set...`
 * functions return an [EditResult] whose plan the caller applies to its document, and after any change to the
 * ROM (an applied plan, an undo, an edit in the hex view) the caller must call [invalidate].
 */
class TableSet(
    private val rom: RomData,
    private val pcs: PcsTable,
    private val gameCode: String,
    private val data: GameData,
) {
    private var catalog = TableCatalog(rom, pcs, gameCode, data)
    private var reader = FieldReader(rom, catalog)
    private var writer = FieldWriter(rom, pcs, gameCode, catalog, reader)

    /** Forgets everything read from the ROM so far. */
    fun invalidate() {
        catalog = TableCatalog(rom, pcs, gameCode, data)
        reader = FieldReader(rom, catalog)
        writer = FieldWriter(rom, pcs, gameCode, catalog, reader)
    }

    /** All tables that were found in the ROM, grouped under the headings of the reference data. */
    fun sections(): List<TableSection> {
        val entries = HashMap<String, TableEntry>()
        for (name in catalog.names) {
            val table = catalog.location(name) ?: continue
            entries[name] = TableEntry(name, table.rowCount, table.rowSize, table.start)
        }
        val used = HashSet<String>()
        val sections = ArrayList<TableSection>()
        for (group in data.metadata.groups) {
            val tables = group.tables.mapNotNull { entries[it.substringBefore('|')] }.filter { used.add(it.name) }
            if (tables.isNotEmpty()) sections.add(TableSection(group.name, tables))
        }
        val others = entries.values.filter { it.name !in used }.sortedBy { it.name }
        if (others.isNotEmpty()) sections.add(TableSection(OTHER_TABLES, others))
        return sections
    }

    /** The table [path] names as it is now, or null when it cannot be found any more. */
    fun locate(path: TablePath): TableLocation? {
        var table = catalog.location(path.root) ?: return null
        for (step in path.steps) table = catalog.child(table, step.row, step.fieldIndex) ?: return null
        return table
    }

    /** What row [row] is called (a name from the game's lists), or null. */
    fun rowLabel(table: TableLocation, row: Int): String? = catalog.rowLabel(table, row)

    /** Every value of a row, in the order of the table definition. */
    fun fields(table: TableLocation, row: Int): List<FieldView> =
        table.schema.fields.indices.map { reader.view(table, row, it) }

    fun field(table: TableLocation, row: Int, index: Int): FieldView = reader.view(table, row, index)

    /** A short line describing the row for lists: its first few values, leaving out unused and padding fields. */
    fun preview(table: TableLocation, row: Int, maxParts: Int = 3): String {
        val label = rowLabel(table, row)
        val parts = ArrayList<String>()
        for (index in table.schema.fields.indices) {
            if (parts.size >= maxParts) break
            val name = table.schema.fields[index].name
            if (isFiller(name)) continue
            val view = reader.view(table, row, index)
            if (view.kind == FieldKind.BITS || view.kind == FieldKind.COLOR) continue
            if (view.text.isEmpty() || view.text == label) continue
            if (view.kind == FieldKind.FLAG && view.flag != true) continue
            parts.add(if (view.kind == FieldKind.FLAG) view.label else "${view.label} ${view.text}")
        }
        return parts.joinToString("   ")
    }

    private fun isFiller(name: String): Boolean {
        val lower = name.lowercase()
        return lower.startsWith("unused") || lower.startsWith("padding") || lower.startsWith("unknown")
    }

    // ---- editing ----

    fun editorFor(table: TableLocation, row: Int, index: Int, asAddress: Boolean = false): FieldEditor =
        writer.editorFor(table, row, index, asAddress)

    fun setNumber(table: TableLocation, row: Int, index: Int, value: Long): EditResult =
        writer.setNumber(table, row, index, value)

    fun setText(table: TableLocation, row: Int, index: Int, text: String): EditResult =
        writer.setText(table, row, index, text)

    fun setAddress(table: TableLocation, row: Int, index: Int, text: String): EditResult =
        writer.setAddress(table, row, index, text)

    fun setBits(table: TableLocation, row: Int, index: Int, selected: Set<Int>): EditResult =
        writer.setBits(table, row, index, selected)

    fun setColor(table: TableLocation, row: Int, index: Int, text: String): EditResult =
        writer.setColor(table, row, index, text)

    companion object {
        const val OTHER_TABLES = "Other tables"
    }
}
