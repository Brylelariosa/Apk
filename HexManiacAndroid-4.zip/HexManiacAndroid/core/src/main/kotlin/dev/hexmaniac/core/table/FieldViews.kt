package dev.hexmaniac.core.table

import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.format.Field
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.table.format.PointerKind

/** How one value of one row is shown. */
class FieldView(
    /** Position of the field in the table's schema; with the row it identifies the value. */
    val index: Int,
    /** The field's own name; for a part of a packed value, the name of the part. */
    val name: String,
    /** Name of the packed value this field is a part of, or null for ordinary fields. */
    val group: String?,
    /** File offset of the bytes that hold the value (the parts of a packed value share their bytes). */
    val offset: Int,
    /** Number of bytes at [offset]. */
    val size: Int,
    /** The value as text: a name, a number, the decoded text, an address. */
    val text: String,
    /** Smaller text shown next to [text], such as the number behind a name or the address behind a text pointer. */
    val note: String?,
    /** What the field really is: record fields are shown as the type they have in this row. */
    val kind: FieldKind,
    /** The nested table a pointer field leads to, when there is one. */
    val opens: TablePath?,
    /** File offset a pointer field leads to, or -1. */
    val target: Int,
    /** For single bit fields, whether the bit is set. */
    val flag: Boolean?,
    /** True when [text] is an address (a pointer that is not shown through what it leads to). */
    val isAddress: Boolean = false,
) {
    /** Name with its group in front ("evs.hp"), for lists that do not show groups as headings. */
    val label: String get() = if (group == null) name else "$group.$name"
}

/** Turns the bytes of a row into [FieldView]s. */
internal class FieldReader(private val rom: RomData, private val catalog: TableCatalog) {

    fun view(table: TableLocation, row: Int, index: Int): FieldView {
        val field = catalog.concreteField(table, row, index)
        val rowStart = table.rowStart(row)
        return when (field.kind) {
            FieldKind.NUMBER -> number(index, field, rowStart)
            FieldKind.SIGNED -> plain(index, field, rowStart, Values.toSigned(raw(field, rowStart), field.size).toString())
            FieldKind.HEX -> plain(index, field, rowStart, HexText.hex(raw(field, rowStart).toInt(), field.size * 2))
            FieldKind.FLAG -> {
                val on = raw(field, rowStart) != 0L
                make(index, field, rowStart, if (on) "On" else "Off", flag = on)
            }
            FieldKind.TEXT -> plain(index, field, rowStart, Texts.cleaned(catalog.readText(rowStart, field)).orEmpty())
            FieldKind.POINTER -> pointer(table, row, index, field, rowStart)
            FieldKind.BITS -> bits(index, field, rowStart)
            FieldKind.COLOR -> plain(index, field, rowStart, Colors.hex(raw(field, rowStart).toInt()))
            FieldKind.RECORD -> plain(index, field, rowStart, raw(field, rowStart).toString())
        }
    }

    /** The unsigned value of a field; for a slice of a packed integer, just the bits of the slice. */
    fun raw(field: Field, rowStart: Int): Long = Values.fieldValue(rom, rowStart, field)

    private fun make(
        index: Int,
        field: Field,
        rowStart: Int,
        text: String,
        note: String? = null,
        opens: TablePath? = null,
        target: Int = -1,
        flag: Boolean? = null,
        address: Boolean = false,
    ) = FieldView(index, field.name, field.group, rowStart + field.offset, field.size, text, note, field.kind, opens, target, flag, address)

    private fun plain(index: Int, field: Field, rowStart: Int, text: String) = make(index, field, rowStart, text)

    private fun number(index: Int, field: Field, rowStart: Int): FieldView {
        val value = raw(field, rowStart)
        val name = field.enumName
        if (name != null && name.toIntOrNull() == null) {
            val position = value - field.enumOffset
            val option = if (position in 0..Int.MAX_VALUE) catalog.options(name).getOrNull(position.toInt()) else null
            if (option != null) return make(index, field, rowStart, option, note = value.toString())
        }
        return plain(index, field, rowStart, value.toString())
    }

    private fun pointer(table: TableLocation, row: Int, index: Int, field: Field, rowStart: Int): FieldView {
        val at = rowStart + field.offset
        val word = rom.readWord(at)
        val target = rom.pointerTarget(at)
        val address = when {
            word == 0 -> "null"
            target >= 0 -> HexText.hex(target, 6)
            else -> HexText.hex(word, 8)
        }
        val spec = field.pointer
        if (target < 0 || spec == null) {
            return make(index, field, rowStart, address, note = if (word != 0) "not in the ROM" else null, target = target, address = true)
        }
        return when (spec.kind) {
            PointerKind.TEXT -> {
                val text = Texts.cleaned(catalog.readText(rowStart, field)).orEmpty()
                make(index, field, rowStart, text, note = address, target = target)
            }
            PointerKind.TABLE -> {
                val child = catalog.child(table, row, index)
                val summary = child?.let { "${it.rowCount} ${if (it.rowCount == 1) "row" else "rows"}" } ?: address
                make(index, field, rowStart, summary, note = address, opens = child?.path, target = target, address = child == null)
            }
            PointerKind.SPECIAL -> make(index, field, rowStart, address, note = spec.special, target = target, address = true)
            PointerKind.PLAIN -> make(index, field, rowStart, address, target = target, address = true)
        }
    }

    private fun bits(index: Int, field: Field, rowStart: Int): FieldView {
        val value = raw(field, rowStart)
        val names = field.bitSource?.let { catalog.options(it) }.orEmpty()
        val selected = ArrayList<String>()
        var unknown = false
        for (bit in 0 until field.size * 8) {
            if ((value ushr bit) and 1L == 0L) continue
            val name = names.getOrNull(bit)
            if (name == null) unknown = true else selected.add(name)
        }
        val text = when {
            value == 0L -> "none"
            selected.isEmpty() -> HexText.hex(value.toInt(), field.size * 2)
            unknown -> selected.joinToString(", ") + ", ..."
            else -> selected.joinToString(", ")
        }
        return plain(index, field, rowStart, text)
    }
}

/** GBA 15 bit colours. */
internal object Colors {
    /** "#RRGGBB" for the colour stored in [value] (5 bits per channel, red lowest). */
    fun hex(value: Int): String {
        val r = scale(value and 31)
        val g = scale((value shr 5) and 31)
        val b = scale((value shr 10) and 31)
        return "#" + HexText.hex(r, 2) + HexText.hex(g, 2) + HexText.hex(b, 2)
    }

    /** The stored colour for "#RRGGBB" or "RRGGBB"; null when the text is not a colour. */
    fun parse(text: String): Int? {
        val digits = text.trim().removePrefix("#")
        if (digits.length != 6 || !digits.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
        val rgb = digits.toInt(16)
        val r = shrink((rgb shr 16) and 0xFF)
        val g = shrink((rgb shr 8) and 0xFF)
        val b = shrink(rgb and 0xFF)
        return r or (g shl 5) or (b shl 10)
    }

    private fun scale(channel: Int) = channel * 255 / 31

    private fun shrink(channel: Int) = (channel * 31 + 127) / 255
}
