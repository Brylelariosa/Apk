# HexManiac for Android

Android remake of HexManiacAdvance (GBA ROM hex and table editor), version 0.3.0.
One universal APK (no ABI or density splits, no native code), dark Material look, ASCII-only interface.

Build it with the "Build APK" GitHub Actions workflow: zip this folder, push the zip to `uploads/`, download the APK
artifact. Locally: `./gradlew assembleDebug` (or `assembleRelease`).

## What works

- Open a ROM through the system file picker (any `.gba`, up to 64 MB). Save in place or "Save as". Every opened ROM is
  copied to app-private storage first (the last three backups are kept).
- Hex dump drawn on a canvas: address column, column header, groups of four bytes, optional text column in the game's
  character set (PCS), pointers tinted, `00` and `FF` dimmed, merged selection highlight, current row highlight.
  The number of bytes per row follows the screen width (4, 8, 12, ... up to 32). Pinch to zoom (9 to 26 sp, remembered),
  drag the right edge to fast-scroll (a bubble shows the address).
- Tap selects a byte, double-tap follows a pointer, long-press edits the selected bytes. The bar under the dump has
  `-1`, `+1`, `Word` (resize the selection), `Edit`, `Follow` and `Back` (history of followed pointers).
- Go to (offset or an `08xxxxxx` pointer), Find (hex with `??` wildcards, or `"text"` in the game's character set),
  Find next (wraps around).
- Undo and redo with labelled steps, unsaved-changes guard on open and on exit.
- IPS and UPS patches: apply (UPS also removes), create against an original ROM.
- ROM info: title, game code, language and version, size, CRC-32.

### Tables

The Tables button in the action bar opens the data tables of the game (English Ruby, Sapphire, FireRed, LeafGreen and
Emerald, using the reference data of HexManiacAdvance). Other ROMs still open in the hex view; the Tables button then
says that no table definitions exist for them.

- Table list: every table that was found in the ROM, under the headings of the reference data, with a search box.
  Long-press a table to open it or to show its first row in the hex view.
- Row list: each row with its name from the game's lists (Pokemon, moves, items, ...) and a short summary of its
  values. The search box matches the row number, the name and (up to 2000 rows) the summary.
- Row editor: all values of a row, names with the number behind them, packed values under a heading of their own.
  Tap to edit: numbers (decimal, or hex with `0x`), names from a searchable list (with a "Number..." escape),
  on/off flags, sets of flags such as TM compatibility, text, pointers as addresses, GBA colours. Pointers to other
  tables (learnsets, evolutions, ...) open that table. Previous and Next step through the rows.
- Edits are checked by the engine before anything is written: ranges, text that must fit where it is, addresses inside
  the ROM. Each accepted edit is one undo step, shared with the hex view, and the Save button works from there too.
- Long-press a value for more: edit a pointer as an address, show the value or its target in the hex view.
  "Show in hex" closes the browser and selects those bytes.

## APK size

- R8 shrinking, optimization and obfuscation plus resource shrinking, in the debug build as well as the release build
  (the workflow builds whichever the signing secrets allow, and both are small). Debug keeps names (`-dontobfuscate`).
- No AndroidX or AppCompat: the app uses the framework `Activity`, the framework action bar, programmatic views and
  vector drawables. The only libraries are the Kotlin standard library (shrunk by R8) and the `core` module.
- Only the data files the app reads are packaged (`shippedData` in `core/build.gradle.kts`, kept in step with
  `hma/index.txt`). Add a file there when the feature that needs it lands.
- Kotlin's generated null-check calls are switched off, and build-time metadata is excluded from the APK.
- No ABI splits: there is no native code, so there is nothing to split.

## Layout

```
core/   pure Kotlin/JVM engine, no Android classes, unit tested (./gradlew :core:test)
  rom/    RomData, RomDocument (undo/redo), header + game detection, search, hex text, RomInfo, OffsetHistory
  text/   PCS text codec (decoder, encoder, reference parser, macros)
  patch/  IPS, UPS, CRC-32, Patches facade
  io/     ResourceSource (class-path access to the data files in src/main/resources/hma)
  table/  table engine: format DSL parser (format/), reference data and metadata TOML (data/), table catalog
          (lengths, names, nested tables), field views and field editing plans, TableSet facade
app/    thin Android shell (./gradlew :app:testDebugUnitTest runs the layout tests)
  MainActivity    wiring: menu, dialogs, flows (open, save, find, patch, ...)
  session/        RomSession: the open document, its Uri, pointer history, last search; SessionStore, RomSaver
  tables/         table browser: TablesActivity hosts a stack of pages (table list, row list, row editor),
                  FieldEditors turns the engine's editor descriptions into dialogs
  io/             RomFiles (storage access framework I/O), Backups
  ui/             HexView (canvas) + HexGeometry (pure layout maths, unit tested), InfoPanel, ActionRow,
                  EmptyState, Dialogs, PickerDialog, SearchList, list rows, BusyRunner (background work with a
                  spinner), HexPalette, ViewSettings
```

Rules that keep the engine portable: `core` uses only Java 8 library APIs (it runs on Android API 24+), never touches
`android.*`, and reads its data files through `ResourceSource`. The app only draws and forwards input. All screen
geometry lives in `HexGeometry`, which has no Android dependency either.

## Build matrix

Gradle 8.6, AGP 8.4.2, Kotlin 2.0.21, JDK 17, compileSdk/targetSdk 34, minSdk 24.

The workflow replaces `gradle/wrapper/gradle-wrapper.jar` with the one from the Gradle 8.6.0 tag, and that jar has no
`Main-Class` entry. The `gradlew` and `gradlew.bat` scripts in this project therefore start the wrapper with
`-classpath gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain` instead of `-jar`.

## Next steps

Text repointing with a free-space search (so longer text fits), French, Italian, German and Spanish reference data,
LZ77 sprites and palettes, script viewer, tables whose length comes from a tilemap.

## Credits

Based on HexManiacAdvance by haven1433 (MIT). Toolbar icons are Material Icons (Apache 2.0). See `NOTICE.md`.
