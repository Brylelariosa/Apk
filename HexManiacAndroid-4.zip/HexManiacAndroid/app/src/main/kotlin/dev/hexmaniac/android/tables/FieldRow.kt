package dev.hexmaniac.android.tables

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.TypefaceSpan
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.MATCH
import dev.hexmaniac.android.ui.WRAP
import dev.hexmaniac.android.ui.dp
import dev.hexmaniac.core.table.FieldView
import dev.hexmaniac.core.table.format.FieldKind

/**
 * One value of a table row: its name above, its value below, and on the right whatever shows what a tap does (a
 * switch for a flag, an arrow for a nested table, a swatch for a colour).
 */
class FieldRow(context: Context) : LinearLayout(context) {
    private val name = TextView(context)
    private val value = TextView(context)
    private val swatch = View(context)
    private val arrow = ImageView(context)
    private val toggle = Switch(context)

    private val primary = context.getColor(R.color.text_primary)
    private val dim = context.getColor(R.color.text_dim)
    private val emptyText = context.getString(R.string.field_empty)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = context.dp(56)
        setBackgroundResource(R.drawable.bg_action)

        name.textSize = 12f
        name.setTextColor(context.getColor(R.color.text_secondary))
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        value.textSize = 16f
        value.maxLines = 3
        value.ellipsize = TextUtils.TruncateAt.END

        val texts = LinearLayout(context)
        texts.orientation = VERTICAL
        texts.addView(name, LayoutParams(MATCH, WRAP))
        texts.addView(value, LayoutParams(MATCH, WRAP))
        addView(texts, LayoutParams(0, WRAP, 1f))

        swatch.setBackgroundResource(R.drawable.bg_swatch)
        swatch.background = swatch.background.mutate()
        val swatchParams = LayoutParams(context.dp(28), context.dp(28))
        swatchParams.leftMargin = context.dp(12)
        addView(swatch, swatchParams)

        arrow.setImageResource(R.drawable.ic_chevron)
        val arrowParams = LayoutParams(WRAP, WRAP)
        arrowParams.leftMargin = context.dp(8)
        addView(arrow, arrowParams)

        // The row is the touch target, so the switch only shows the state.
        toggle.isClickable = false
        toggle.isFocusable = false
        val toggleParams = LayoutParams(WRAP, WRAP)
        toggleParams.leftMargin = context.dp(8)
        addView(toggle, toggleParams)
    }

    /** Shows [field]; [indented] moves the row in under the heading of the packed value it belongs to. */
    fun bind(field: FieldView, indented: Boolean) {
        setPadding(context.dp(if (indented) 32 else 16), context.dp(9), context.dp(16), context.dp(9))
        name.text = field.name

        val text = SpannableStringBuilder()
        val isFlag = field.kind == FieldKind.FLAG
        when {
            isFlag -> text.appendColored(field.text, if (field.flag == true) primary else dim)
            field.text.isEmpty() -> text.appendColored(emptyText, dim)
            else -> text.appendColored(field.text, primary)
        }
        val note = field.note
        if (!note.isNullOrEmpty() && !isFlag) {
            val start = text.length
            text.append("   ").append(note)
            text.setSpan(ForegroundColorSpan(dim), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text.setSpan(TypefaceSpan("monospace"), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text.setSpan(RelativeSizeSpan(0.78f), start, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        value.text = text
        value.typeface = if (field.isAddress || field.kind == FieldKind.HEX || field.kind == FieldKind.COLOR) Typeface.MONOSPACE else Typeface.DEFAULT

        if (field.kind == FieldKind.COLOR) {
            (swatch.background as? GradientDrawable)?.setColor(colorOf(field.text))
            swatch.visibility = VISIBLE
        } else {
            swatch.visibility = GONE
        }
        arrow.visibility = if (field.opens != null) VISIBLE else GONE
        toggle.visibility = if (isFlag) VISIBLE else GONE
        toggle.isChecked = field.flag == true
    }

    private fun SpannableStringBuilder.appendColored(text: CharSequence, color: Int): SpannableStringBuilder {
        val start = length
        append(text)
        setSpan(ForegroundColorSpan(color), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return this
    }

    private fun colorOf(hex: String): Int = try {
        Color.parseColor(hex)
    } catch (e: IllegalArgumentException) {
        Color.TRANSPARENT
    }
}
