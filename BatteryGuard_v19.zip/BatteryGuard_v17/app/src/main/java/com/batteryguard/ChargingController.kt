package com.batteryguard

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ChargingController {

    private const val TAG = "ChargingController"

    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",
        "/sys/class/power_supply/battery/input_suspend",
        "/sys/class/power_supply/batt_drv/charge_disable",
        "/sys/class/power_supply/battery/stop_charging",
        "/sys/class/power_supply/battery/inhibit_charge",
        "/sys/class/power_supply/battery/charge_control_limit_max"
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    // Single-thread executor so charging commands never run concurrently
    private val executor = Executors.newSingleThreadExecutor()

    /**
     * Cached result of a real `su -c id` exec.
     * null  = not yet verified (file-based fallback used)
     * true  = root confirmed
     * false = root not available
     */
    @Volatile private var rootConfirmed: Boolean? = null

    // ── Root detection ────────────────────────────────────────────────────────

    /**
     * Returns true if root is available.
     * Uses the [rootConfirmed] cached exec result once [verifyRootInBackground]
     * has finished; falls back to a quick su-binary file-existence check.
     */
    fun isRooted(): Boolean {
        rootConfirmed?.let { return it }
        return listOf(
            "/system/bin/su", "/system/xbin/su",
            "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
        ).any { File(it).exists() }
    }

    /**
     * Confirms root by running `su -c id` on the background executor and caching
     * the result in [rootConfirmed]. Call once from a background context
     * (e.g. BatteryService.onCreate) so the UI thread is never blocked.
     */
    fun verifyRootInBackground() {
        executor.submit {
            rootConfirmed = try {
                val p        = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val out      = p.inputStream.bufferedReader().readText()
                val finished = p.waitFor(3, TimeUnit.SECONDS)
                finished && out.contains("uid=0")
            } catch (e: Exception) {
                Log.d(TAG, "root verify: ${e.message}")
                false
            }
        }
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun availableMethod(): Method = when {
        isRooted()         -> Method.ROOT
        isShizukuGranted() -> Method.SHIZUKU
        else               -> Method.NONE
    }

    /** Fires off a disable command in the background; calls [onResult] with success flag. */
    fun disableCharging(context: android.content.Context? = null, onResult: (Boolean) -> Unit = {}) {
        executor.submit {
            onResult(runCmd(buildCmd(enable = false, context = context)))
        }
    }

    /** Fires off an enable command in the background; calls [onResult] with success flag. */
    fun enableCharging(context: android.content.Context? = null, onResult: (Boolean) -> Unit = {}) {
        executor.submit {
            onResult(runCmd(buildCmd(enable = true, context = context)))
        }
    }

    /**
     * Runs `dumpsys battery reset` to clear any stuck/overridden battery stats.
     * Calls [onResult] with true on success, false on failure, null if no privilege.
     */
    fun fixBatteryReading(onResult: (Boolean?) -> Unit) {
        if (availableMethod() == Method.NONE) {
            onResult(null)
            return
        }
        executor.submit {
            onResult(runCmd("dumpsys battery reset 2>/dev/null"))
        }
    }

    /**
     * Starts a node scan on NodeScanner's own dedicated thread (not the executor).
     * [onProgress] and [onDone] are called on that background thread — callers
     * must post to main thread when updating UI.
     */
    fun scanForNode(
        context: android.content.Context,
        onProgress: (String) -> Unit,
        onDone: (NodeScanner.ScanResult) -> Unit
    ) {
        NodeScanner.scanAsync(context, onProgress, onDone)
    }

    // ── Command building ──────────────────────────────────────────────────────

    /**
     * Builds the shell command to enable or disable charging.
     *
     * Priority:
     *  1. A node discovered by [NodeScanner] and saved in SharedPreferences
     *     (most reliable — verified live on this specific device).
     *  2. The hardcoded list of known nodes (broad compatibility fallback).
     */
    fun buildCmd(enable: Boolean, context: android.content.Context? = null): String {
        // Check for a previously discovered node
        if (context != null) {
            val prefs = context.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
            val node        = prefs.getString("discovered_node",        null)
            val disableVal  = prefs.getString("discovered_disable_val", null)
            val enableVal   = prefs.getString("discovered_enable_val",  null)
            if (node != null && disableVal != null && enableVal != null) {
                val v    = if (enable) enableVal else disableVal
                val cmds = mutableListOf("echo $v > $node")
                if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
                return cmds.joinToString(" ; ")
            }
        }
        // Fallback: try all known nodes
        val v    = if (enable) "1" else "0"
        val cmds = mutableListOf<String>()
        for (node in CHARGING_NODES) {
            cmds += "[ -f $node ] && echo $v > $node || true"
        }
        if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
        return cmds.joinToString(" ; ")
    }

    /**
     * Package-internal shell exec for use by [NodeScanner].
     * Routes through the same root/Shizuku path as all other commands —
     * never calls Runtime.exec("su") directly.
     */
    internal fun execCmd(cmd: String): Boolean = when (availableMethod()) {
        Method.ROOT    -> execRoot(cmd)
        Method.SHIZUKU -> execShizuku(cmd)
        Method.NONE    -> false
    }

    private fun runCmd(cmd: String): Boolean {
        return when (availableMethod()) {
            Method.ROOT    -> execRoot(cmd)
            Method.SHIZUKU -> execShizuku(cmd)
            Method.NONE    -> false
        }
    }

    // ── Root exec ─────────────────────────────────────────────────────────────

    private fun execRoot(cmd: String): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            // waitFor(long, TimeUnit) avoids hanging forever if su stalls
            val finished = p.waitFor(10, TimeUnit.SECONDS)
            if (!finished) {
                p.destroyForcibly()
                Log.w(TAG, "root exec timed out: $cmd")
            }
            finished && p.exitValue() == 0
        } catch (e: Exception) {
            Log.e(TAG, "root exec failed: ${e.message}")
            false
        }
    }

    // ── Shizuku UserService ───────────────────────────────────────────────────

    /**
     * Binds ChargeService via Shizuku on the background executor thread (never
     * the main looper) so CountDownLatch.await() cannot deadlock.
     */
    private fun execShizuku(cmd: String): Boolean {
        var result = false
        val latch  = CountDownLatch(1)

        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                try {
                    val exitCode = IChargeService.Stub.asInterface(binder).exec(cmd)
                    result = (exitCode == 0)
                    Log.d(TAG, "shizuku exec exit=$exitCode")
                } catch (e: Exception) {
                    Log.e(TAG, "shizuku call failed: ${e.message}")
                } finally {
                    try { Shizuku.unbindUserService(ChargeService.ARGS, this, true) } catch (_: Exception) {}
                    latch.countDown()
                }
            }
            override fun onServiceDisconnected(name: ComponentName) {
                latch.countDown()
            }
        }

        return try {
            Shizuku.bindUserService(ChargeService.ARGS, conn)
            latch.await(15, TimeUnit.SECONDS)
            result
        } catch (e: Exception) {
            Log.e(TAG, "shizuku bind failed: ${e.message}")
            false
        }
    }

    // ── Shizuku status ────────────────────────────────────────────────────────

    fun isShizukuAvailable(): Boolean =
        try { Shizuku.pingBinder() } catch (_: Exception) { false }

    fun isShizukuGranted(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }
}
