package com.batteryguard

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.batteryguard.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val PERM_NOTIF   = 100
    private val PERM_SHIZUKU = 101

    private val uiReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            refreshBatteryCard()
            refreshPrivilegeCard()
        }
    }

    private val shizukuPermListener =
        Shizuku.OnRequestPermissionResultListener { _, result ->
            val ok = result == PackageManager.PERMISSION_GRANTED
            Toast.makeText(
                this,
                if (ok) "✓ Shizuku access granted — auto-stop enabled!"
                else "Shizuku permission denied",
                Toast.LENGTH_SHORT
            ).show()
            refreshPrivilegeCard()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Shizuku.addRequestPermissionResultListener(shizukuPermListener)
        requestNotifPermission()
        setupThresholdSlider()
        setupButtons()
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(uiReceiver, IntentFilter(BatteryService.ACTION_UPDATE_UI))
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(uiReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermListener)
    }

    private fun setupButtons() {
        binding.btnStart.setOnClickListener    { startGuard() }
        binding.btnStop.setOnClickListener     { stopGuard()  }
        binding.btnShizuku.setOnClickListener  {
            if (!ChargingController.isShizukuAvailable()) {
                Toast.makeText(this,
                    "Shizuku not running — install & start the Shizuku app first",
                    Toast.LENGTH_LONG).show()
            } else {
                ChargingController.requestShizukuPermission(PERM_SHIZUKU)
            }
        }
    }

    private fun startGuard() {
        val i = Intent(this, BatteryService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
        prefs().edit().putBoolean("service_running", true).apply()
        refreshServiceState()
        Toast.makeText(this, "Battery Guard started", Toast.LENGTH_SHORT).show()
    }

    private fun stopGuard() {
        stopService(Intent(this, BatteryService::class.java))
        prefs().edit().putBoolean("service_running", false).apply()
        refreshServiceState()
        Toast.makeText(this, "Service stopped", Toast.LENGTH_SHORT).show()
    }

    private fun setupThresholdSlider() {
        val saved = prefs().getInt("threshold", 100)
        binding.seekbarThreshold.progress = saved - 80
        binding.tvThresholdValue.text = "$saved%"
        binding.seekbarThreshold.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, u: Boolean) {
                    val t = 80 + p
                    binding.tvThresholdValue.text = "$t%"
                    prefs().edit().putInt("threshold", t).apply()
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
    }

    private fun refreshBatteryCard() {
        val batt    = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level   = batt.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale   = batt.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status  = batt.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val voltage = batt.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)   // mV
        val percent = level * 100 / scale
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                       status == BatteryManager.BATTERY_STATUS_FULL

        binding.tvBatteryPercent.text = "$percent%"
        binding.progressBattery.progress = percent

        // Watts calculation
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val currentUa = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // currentUa is in µA; some devices return mA — detect by magnitude
        val currentMa = when {
            currentUa == Long.MIN_VALUE -> 0L
            Math.abs(currentUa) > 100_000 -> currentUa / 1000L  // µA → mA
            else -> currentUa                                     // already mA
        }
        val voltageMv = voltage.toLong()
        val watts = if (voltageMv > 0 && currentMa != 0L)
            Math.abs(voltageMv * currentMa) / 1_000_000.0
        else 0.0

        val wattsText = if (watts > 0.05) String.format("%.1fW", watts) else "—"
        val colorRes = when {
            percent >= 80 -> android.R.color.holo_green_light
            percent >= 40 -> android.R.color.holo_orange_light
            else          -> android.R.color.holo_red_light
        }
        val color = ContextCompat.getColor(this, colorRes)
        binding.tvBatteryPercent.setTextColor(color)
        binding.progressBattery.progressTintList =
            android.content.res.ColorStateList.valueOf(color)

        binding.tvChargingStatus.text = when {
            charging && percent >= 100 -> "🔋 Full"
            charging                   -> "⚡ Charging"
            else                       -> "🔋 On Battery"
        }
        binding.tvWatts.text = if (charging && watts > 0.05)
            "$wattsText  •  ${String.format("%.0f", Math.abs(currentMa.toDouble()))}mA  •  ${voltageMv}mV"
        else if (!charging && watts > 0.05)
            "Discharging $wattsText"
        else
            "${voltageMv}mV"
    }

    private fun refreshPrivilegeCard() {
        val method       = ChargingController.availableMethod()
        val shizukuAvail = ChargingController.isShizukuAvailable()

        when (method) {
            ChargingController.Method.ROOT -> {
                binding.tvPrivilegeStatus.text = "✓ Root detected — auto-control active"
                binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.SHIZUKU -> {
                binding.tvPrivilegeStatus.text = "✓ Shizuku active — auto-control enabled"
                binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.NONE -> {
                if (shizukuAvail) {
                    binding.tvPrivilegeStatus.text = "Shizuku running — tap to grant access"
                    binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_light))
                    binding.btnShizuku.text = "Grant Shizuku Permission"
                } else {
                    binding.tvPrivilegeStatus.text = "No root / Shizuku — alert-only mode"
                    binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
                    binding.btnShizuku.text = "Install Shizuku App"
                }
                binding.btnShizuku.visibility = View.VISIBLE
            }
        }
    }

    private fun refreshServiceState() {
        val running = prefs().getBoolean("service_running", false)
        binding.tvServiceStatus.text = if (running) "Active" else "Stopped"
        val color = if (running)
            ContextCompat.getColor(this, android.R.color.holo_green_light)
        else
            ContextCompat.getColor(this, android.R.color.holo_red_light)
        binding.tvServiceStatus.setTextColor(color)
        binding.btnStart.isEnabled = !running
        binding.btnStop.isEnabled  = running
    }

    private fun prefs() = getSharedPreferences("settings", MODE_PRIVATE)

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS), PERM_NOTIF)
        }
    }
}
