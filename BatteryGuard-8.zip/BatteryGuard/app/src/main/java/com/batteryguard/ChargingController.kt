package com.batteryguard

import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File

object ChargingController {

    private const val TAG = "ChargingController"

    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",
        "/sys/class/power_supply/battery/charge_control_limit_max",
        "/sys/class/power_supply/battery/input_suspend",
        "/sys/class/power_supply/batt_drv/charge_disable",
        "/sys/class/power_supply/battery/stop_charging",
        "/sys/class/power_supply/battery/inhibit_charge"
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    fun availableMethod(): Method = when {
        isRooted()         -> Method.ROOT
        isShizukuGranted() -> Method.SHIZUKU
        else               -> Method.NONE
    }

    fun disableCharging(): Boolean = runCmds(buildCmds(false))
    fun enableCharging(): Boolean  = runCmds(buildCmds(true))

    private fun buildCmds(enable: Boolean): List<String> {
        val v    = if (enable) "1" else "0"
        val cmds = CHARGING_NODES.filter { File(it).exists() }.map { "echo $v > $it" }.toMutableList()
        if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
        else        cmds += "dumpsys battery set status 1 2>/dev/null || true"
        return cmds
    }

    private fun runCmds(cmds: List<String>): Boolean {
        if (cmds.isEmpty()) return false
        val cmd = cmds.joinToString(" ; ")
        return when (availableMethod()) {
            Method.ROOT    -> execRoot(cmd)
            Method.SHIZUKU -> execShizuku(cmd)
            Method.NONE    -> false
        }
    }

    private fun execRoot(cmd: String) = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
    } catch (e: Exception) { Log.e(TAG, "root: ${e.message}"); false }

    private fun execShizuku(cmd: String): Boolean {
        return try {
            // Cast to java.lang.Process to access waitFor() — avoids android.os.Process ambiguity
            val process: java.lang.Process = Shizuku.newProcess(arrayOf("sh", "-c", cmd), null, null)
            process.waitFor() == 0
        } catch (e: Exception) {
            Log.e(TAG, "shizuku: ${e.message}")
            false
        }
    }

    fun isShizukuAvailable(): Boolean = try { Shizuku.pingBinder() } catch (e: Exception) { false }

    fun isShizukuGranted(): Boolean = try {
        isShizukuAvailable() &&
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) { false }

    fun requestShizukuPermission(requestCode: Int) {
        try {
            if (isShizukuAvailable()) Shizuku.requestPermission(requestCode)
        } catch (e: Exception) { Log.e(TAG, "requestShizuku: ${e.message}") }
    }

    private fun isRooted() = listOf(
        "/system/bin/su", "/system/xbin/su",
        "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
    ).any { File(it).exists() }
}
