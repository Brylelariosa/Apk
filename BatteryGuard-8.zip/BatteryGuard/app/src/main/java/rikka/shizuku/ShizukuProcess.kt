package rikka.shizuku

import android.os.ParcelFileDescriptor
import android.os.Parcel
import java.io.InputStream
import java.io.OutputStream

/**
 * Wraps the three ParcelFileDescriptors returned by Shizuku's newProcess
 * into a standard java.lang.Process so callers can use .waitFor() normally.
 * Explicitly extends java.lang.Process to avoid clash with android.os.Process.
 */
internal class ShizukuProcess(reply: Parcel) : java.lang.Process() {

    private val stdinPfd:  ParcelFileDescriptor?
    private val stdoutPfd: ParcelFileDescriptor?
    private val stderrPfd: ParcelFileDescriptor?

    init {
        stdinPfd  = readPfd(reply)
        stdoutPfd = readPfd(reply)
        stderrPfd = readPfd(reply)
    }

    private fun readPfd(p: Parcel): ParcelFileDescriptor? = try {
        if (p.dataAvail() > 0) ParcelFileDescriptor.CREATOR.createFromParcel(p) else null
    } catch (_: Exception) { null }

    override fun getOutputStream(): OutputStream =
        stdinPfd?.let { ParcelFileDescriptor.AutoCloseOutputStream(it) }
            ?: OutputStream.nullOutputStream()

    override fun getInputStream(): InputStream =
        stdoutPfd?.let { ParcelFileDescriptor.AutoCloseInputStream(it) }
            ?: InputStream.nullInputStream()

    override fun getErrorStream(): InputStream =
        stderrPfd?.let { ParcelFileDescriptor.AutoCloseInputStream(it) }
            ?: InputStream.nullInputStream()

    override fun waitFor(): Int {
        return try {
            getInputStream().use { it.readBytes() }
            0
        } catch (_: Exception) { 1 }
    }

    override fun exitValue(): Int = 0

    override fun destroy() {
        try { stdinPfd?.close()  } catch (_: Exception) {}
        try { stdoutPfd?.close() } catch (_: Exception) {}
        try { stderrPfd?.close() } catch (_: Exception) {}
    }
}
