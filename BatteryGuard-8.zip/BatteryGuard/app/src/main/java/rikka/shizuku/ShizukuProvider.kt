package rikka.shizuku

import android.content.ContentProvider
import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.os.Parcel
import android.util.Log

/**
 * Self-contained ShizukuProvider — no external library needed.
 *
 * This ContentProvider must be declared in AndroidManifest.xml with:
 *   android:authorities="${applicationId}.shizuku"
 *
 * Shizuku detects apps by scanning for providers with that authority pattern.
 * On first connect it calls attachApplication (transact #1) so the service
 * knows our PID/UID, then permission grants are managed by the Shizuku app.
 */
class ShizukuProvider : ContentProvider() {

    companion object {
        private const val TAG = "ShizukuProvider"
    }

    override fun onCreate(): Boolean {
        // Attach to Shizuku service so we appear in its authorized-app list
        try {
            val binder = getShizukuBinder() ?: return true
            val pkg = context?.packageName ?: return true
            val data  = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken("moe.shizuku.server.IShizukuService")
                // attachApplication(String packageName, int uid, int pid, String processName)
                data.writeString(pkg)
                data.writeInt(android.os.Process.myUid())
                data.writeInt(android.os.Process.myPid())
                data.writeString(pkg)
                binder.transact(1, data, reply, 0)
                reply.readException()
                Log.d(TAG, "attachApplication OK")
            } finally {
                data.recycle()
                reply.recycle()
            }
        } catch (e: Exception) {
            Log.w(TAG, "onCreate attach: ${e.message}")
        }
        return true
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        // Shizuku queries this to verify the provider is alive
        return Bundle()
    }

    private fun getShizukuBinder(): IBinder? = try {
        val sm  = Class.forName("android.os.ServiceManager")
        val get = sm.getMethod("getService", String::class.java)
        get.invoke(null, "shizuku") as? IBinder
    } catch (e: Exception) { null }

    // ── Unused ContentProvider stubs ─────────────────────────────────────────
    override fun query(uri: Uri, p: Array<String>?, s: String?, a: Array<String>?, o: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<String>?): Int = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<String>?): Int = 0
}
