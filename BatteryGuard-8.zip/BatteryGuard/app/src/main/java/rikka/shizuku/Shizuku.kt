package rikka.shizuku

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.Parcel
import android.util.Log

/**
 * Self-contained Shizuku client. Mirrors the public API of rikka.shizuku:api.
 * Uses explicit java.lang.Process to avoid clash with android.os.Process.
 */
object Shizuku {

    private const val TAG = "Shizuku"
    private const val INTERFACE = "moe.shizuku.server.IShizukuService"
    private const val PERM = "moe.shizuku.manager.permission.API_V23"

    // ── Listener registry ─────────────────────────────────────────────────────

    fun interface OnRequestPermissionResultListener {
        fun onRequestPermissionResult(requestCode: Int, grantResult: Int)
    }

    private val permListeners = mutableListOf<OnRequestPermissionResultListener>()

    fun addRequestPermissionResultListener(l: OnRequestPermissionResultListener) {
        if (!permListeners.contains(l)) permListeners.add(l)
    }

    fun removeRequestPermissionResultListener(l: OnRequestPermissionResultListener) {
        permListeners.remove(l)
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun pingBinder(): Boolean = getBinder() != null

    fun checkSelfPermission(): Int {
        val binder = getBinder() ?: return PackageManager.PERMISSION_DENIED
        return try {
            val data  = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken(INTERFACE)
                data.writeString(PERM)
                data.writeInt(android.os.Process.myPid())
                data.writeInt(android.os.Process.myUid())
                data.writeStrongBinder(null)
                binder.transact(13, data, reply, 0)
                reply.readException()
                reply.readInt()
            } finally { data.recycle(); reply.recycle() }
        } catch (e: Exception) {
            Log.w(TAG, "checkSelfPermission: ${e.message}")
            PackageManager.PERMISSION_DENIED
        }
    }

    fun requestPermission(requestCode: Int) {
        val binder = getBinder()
        if (binder == null) {
            permListeners.forEach { it.onRequestPermissionResult(requestCode, PackageManager.PERMISSION_DENIED) }
            return
        }
        try {
            val data  = Parcel.obtain()
            val reply = Parcel.obtain()
            try {
                data.writeInterfaceToken(INTERFACE)
                data.writeInt(requestCode)
                binder.transact(14, data, reply, 0)
                reply.readException()
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    val result = checkSelfPermission()
                    permListeners.forEach { it.onRequestPermissionResult(requestCode, result) }
                }, 1500)
            } finally { data.recycle(); reply.recycle() }
        } catch (e: Exception) {
            Log.e(TAG, "requestPermission: ${e.message}")
            permListeners.forEach { it.onRequestPermissionResult(requestCode, PackageManager.PERMISSION_DENIED) }
        }
    }

    /**
     * Returns java.lang.Process explicitly to avoid Kotlin resolving
     * the return type as android.os.Process (which has no waitFor).
     */
    fun newProcess(cmd: Array<String>, env: Array<String>?, dir: String?): java.lang.Process {
        val binder = getBinder() ?: throw IllegalStateException("Shizuku not available")
        val data  = Parcel.obtain()
        val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(INTERFACE)
            data.writeStringArray(cmd)
            if (env != null) data.writeStringArray(env) else data.writeInt(-1)
            data.writeString(dir)
            binder.transact(3, data, reply, 0)
            reply.readException()
            ShizukuProcess(reply)
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    private fun getBinder(): IBinder? = try {
        val sm  = Class.forName("android.os.ServiceManager")
        val get = sm.getMethod("getService", String::class.java)
        get.invoke(null, "shizuku") as? IBinder
    } catch (e: Exception) { null }
}
