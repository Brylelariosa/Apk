#pragma once
#include "types.h"
#include "memory.h"
#include "cpu.h"
#include "ppu.h"
#include "apu_dma_timer.h"
#include <functional>

struct GBA {
    Memory mem;
    ARM7TDMI cpu;
    PPU      ppu;
    APU      apu;
    DMA      dma;
    Timers   timers;

    bool running    = false;
    bool frameReady = false;

    std::function<void(const u32*, int, int)> onFrameReady;
    std::function<void(const float*, int)>    onAudioReady;

    void init() {
        mem.init();
        cpu.init(this);
        ppu.init(&mem);
        apu.init(&mem);
        dma.init(&mem);
        timers.init(&mem);

        ppu.onVBlank = [this]() {
            dma.step(); // DMA can trigger on VBlank
            frameReady = true;
            if (onFrameReady) onFrameReady(ppu.framebuffer, GBA_W, GBA_H);
        };
        ppu.onHBlank = [this]() {
            dma.step(); // DMA on HBlank too
        };
        apu.onSamplesReady = [this](float* buf, int frames) {
            if (onAudioReady) onAudioReady(buf, frames);
        };
    }

    bool loadROM(const u8* data, size_t size) {
        if (!mem.loadROM(data, size)) return false;
        cpu.reset();
        return true;
    }

    void setKeys(u16 keys) {
        mem.keyState = ~keys & 0x03FF; // GBA keys are active-low
        mem.write16(REG_KEYINPUT, mem.keyState);
    }

    // Run exactly one frame worth of cycles
    void runFrame() {
        frameReady = false;
        int frameCycles = CYCLES_PER_FRAME;

        while (frameCycles > 0 && !frameReady) {
            int c = cpu.step();
            ppu.step(c);
            apu.step(c);
            timers.step(c);
            frameCycles -= c;
        }
    }
};
