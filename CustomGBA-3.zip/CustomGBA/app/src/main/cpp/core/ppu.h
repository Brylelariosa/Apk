#pragma once
#include "types.h"
#include "memory.h"
#include <cstring>
#include <functional>

struct PPU {
    Memory* mem;
    u32 framebuffer[GBA_PIXELS] = {};  // RGBA8888
    int scanline   = 0;
    int dotCycles  = 0;
    bool vblank    = false;
    bool hblank    = false;

    std::function<void()> onVBlank;
    std::function<void()> onHBlank;
    std::function<void()> onVCount;

    void init(Memory* m) {
        mem = m;
        memset(framebuffer, 0, sizeof(framebuffer));
        scanline  = 0;
        dotCycles = 0;
    }

    // Called every CPU cycle
    void step(int cpuCycles) {
        dotCycles += cpuCycles;

        while (dotCycles >= CYCLES_PER_DOT) {
            dotCycles -= CYCLES_PER_DOT;
            tick();
        }
    }

    void tick() {
        u16& dispstat = *(u16*)(mem->io + (REG_DISPSTAT & 0xFFF));
        u16& vcount   = *(u16*)(mem->io + (REG_VCOUNT   & 0xFFF));

        // We track dot position as (scanline * DOTS_PER_LINE + dot)
        // but simplified: render at start of each scanline
        static int dot = 0;
        dot++;

        if (dot == 1 && scanline < GBA_H) {
            // HBlank flag clear at start
            dispstat &= ~2;
            renderScanline(scanline);
        }

        if (dot == 241) { // Start of HBlank
            dispstat |= 2;
            hblank = true;
            if (dispstat & (1<<4)) mem->raiseIRQ(IRQ_HBLANK);
            if (onHBlank) onHBlank();
        }

        if (dot >= DOTS_PER_LINE) {
            dot = 0;
            scanline++;
            if (scanline >= LINES_PER_FRAME) scanline = 0;
            vcount = scanline;

            // VCount match
            u8 lyc = (dispstat >> 8) & 0xFF;
            if (scanline == lyc) {
                dispstat |= 4;
                if (dispstat & (1<<5)) mem->raiseIRQ(IRQ_VCOUNT);
                if (onVCount) onVCount();
            } else {
                dispstat &= ~4;
            }

            if (scanline == GBA_H) {
                // Enter VBlank
                dispstat |= 1;
                vblank = true;
                if (dispstat & (1<<3)) mem->raiseIRQ(IRQ_VBLANK);
                if (onVBlank) onVBlank();
            } else if (scanline == 0) {
                dispstat &= ~1;
                vblank = false;
            }
        }
    }

    void renderScanline(int y) {
        u16 dispcnt = mem->read16(REG_DISPCNT);
        u32 mode    = dispcnt & 7;
        bool bg0en  = (dispcnt >> 8)  & 1;
        bool bg1en  = (dispcnt >> 9)  & 1;
        bool bg2en  = (dispcnt >> 10) & 1;
        bool bg3en  = (dispcnt >> 11) & 1;
        bool objen  = (dispcnt >> 12) & 1;

        // Line buffer: RGBA (backdrop = first palette entry)
        u32 line[GBA_W];
        u16 bgcol = mem->read16(PAL_START);
        u32 backdrop = gba15toRGBA(bgcol);
        for (int x=0;x<GBA_W;x++) line[x] = backdrop;

        switch (mode) {
            case 0:
                if (bg3en) renderBGMode0(3, y, line);
                if (bg2en) renderBGMode0(2, y, line);
                if (bg1en) renderBGMode0(1, y, line);
                if (bg0en) renderBGMode0(0, y, line);
                break;
            case 1:
                if (bg2en) renderBGMode2Affine(2, y, line);
                if (bg1en) renderBGMode0(1, y, line);
                if (bg0en) renderBGMode0(0, y, line);
                break;
            case 2:
                if (bg3en) renderBGMode2Affine(3, y, line);
                if (bg2en) renderBGMode2Affine(2, y, line);
                break;
            case 3: renderMode3(y, line); break;
            case 4: renderMode4(y, line); break;
            case 5: renderMode5(y, line); break;
        }

        if (objen) renderSprites(y, line);

        memcpy(&framebuffer[y * GBA_W], line, GBA_W * sizeof(u32));
    }

    // ── GBA 15-bit color to RGBA ──────────────────────────────────────────────
    static u32 gba15toRGBA(u16 c) {
        u8 r = ((c >>  0) & 0x1F) * 255 / 31;
        u8 g = ((c >>  5) & 0x1F) * 255 / 31;
        u8 b = ((c >> 10) & 0x1F) * 255 / 31;
        return (0xFF << 24) | (b << 16) | (g << 8) | r;
    }

    // ── Mode 3: 240x160 16-bit direct color ──────────────────────────────────
    void renderMode3(int y, u32* line) {
        for (int x=0;x<GBA_W;x++) {
            u32 addr = VRAM_START + (y*GBA_W+x)*2;
            u16 col  = mem->read16(addr);
            line[x]  = gba15toRGBA(col);
        }
    }

    // ── Mode 4: 240x160 8-bit paletted (2 pages) ─────────────────────────────
    void renderMode4(int y, u32* line) {
        u16 dispcnt = mem->read16(REG_DISPCNT);
        u32 base    = (dispcnt & (1<<4)) ? 0xA000 : 0x0000;
        for (int x=0;x<GBA_W;x++) {
            u8  idx  = mem->vram[base + y*GBA_W + x];
            u16 col  = mem->read16(PAL_START + idx*2);
            if (idx == 0) continue; // transparent
            line[x]  = gba15toRGBA(col);
        }
    }

    // ── Mode 5: 160x128 16-bit direct (2 pages) ──────────────────────────────
    void renderMode5(int y, u32* line) {
        u16 dispcnt = mem->read16(REG_DISPCNT);
        if (y >= 128) return;
        u32 base = (dispcnt & (1<<4)) ? 0xA000 : 0x0000;
        for (int x=0;x<160;x++) {
            u32 addr = base + (y*160+x)*2;
            u16 col  = (u16)mem->vram[addr] | ((u16)mem->vram[addr+1]<<8);
            line[x]  = gba15toRGBA(col);
        }
    }

    // ── Mode 0/1: Tiled background ────────────────────────────────────────────
    void renderBGMode0(int bgn, int y, u32* line) {
        u32 cntAddr = REG_BG0CNT + bgn*2;
        u16 cnt     = mem->read16(cntAddr);
        u16 hofs    = mem->read16(REG_BG0HOFS + bgn*4) & 0x1FF;
        u16 vofs    = mem->read16(REG_BG0VOFS + bgn*4) & 0x1FF;

        u32 tileBase  = ((cnt >>  2) & 0x3) * 0x4000;
        u32 mapBase   = ((cnt >>  8) & 0x1F)* 0x800;
        bool color256 = (cnt >> 7) & 1;
        u32  mapSize  = (cnt >> 14) & 3;  // 0=32x32 1=64x32 2=32x64 3=64x64
        int  mapW     = (mapSize & 1) ? 64 : 32; // in tiles
        int  mapH     = (mapSize & 2) ? 64 : 32;

        int ty = (y + vofs) & (mapH*8 - 1);

        for (int x=0;x<GBA_W;x++) {
            int tx = (x + hofs) & (mapW*8 - 1);

            // Find screen block
            int scx = tx/256, scy = ty/256;
            int scOff = (mapSize==1) ? scx*0x800 :
                        (mapSize==2) ? scy*0x800 :
                        (mapSize==3) ? (scy*2+scx)*0x800 : 0;

            int tileX = (tx%256)/8, tileY = (ty%256)/8;
            u32 mapAddr = mapBase + scOff + (tileY*32+tileX)*2;
            u16 entry = (u16)mem->vram[mapAddr] | ((u16)mem->vram[mapAddr+1]<<8);

            u32 tileNum = entry & 0x3FF;
            bool hflip  = (entry >> 10) & 1;
            bool vflip  = (entry >> 11) & 1;
            u32  pal    = (entry >> 12) & 0xF;

            int px = tx % 8, py = ty % 8;
            if (hflip) px = 7 - px;
            if (vflip) py = 7 - py;

            u8 palIdx;
            if (color256) {
                u32 tileAddr = tileBase + tileNum*64 + py*8 + px;
                palIdx = tileAddr < VRAM_SIZE ? mem->vram[tileAddr] : 0;
                if (palIdx == 0) continue;
                u16 col = mem->read16(PAL_START + palIdx*2);
                line[x] = gba15toRGBA(col);
            } else {
                u32 tileAddr = tileBase + tileNum*32 + py*4 + px/2;
                u8  byte = tileAddr < VRAM_SIZE ? mem->vram[tileAddr] : 0;
                palIdx = (px&1) ? byte>>4 : byte&0xF;
                if (palIdx == 0) continue;
                u16 col = mem->read16(PAL_START + (pal*16+palIdx)*2);
                line[x] = gba15toRGBA(col);
            }
        }
    }

    // ── Mode 1/2: Affine (rotation/scale) background ─────────────────────────
    void renderBGMode2Affine(int bgn, int y, u32* line) {
        u32 cntAddr = REG_BG0CNT + bgn*2;
        u16 cnt     = mem->read16(cntAddr);
        u32 tileBase= ((cnt >>  2) & 0x3) * 0x4000;
        u32 mapBase = ((cnt >>  8) & 0x1F)* 0x800;
        bool wrap   = (cnt >> 13) & 1;
        u32  sz     = (cnt >> 14) & 3;   // 0=128 1=256 2=512 3=1024
        int  mapPx  = 128 << sz;

        // Affine params (BG2: 0x28, BG3: 0x38)
        u32 base = bgn==2 ? 0x04000028 : 0x04000038;
        s16 pa = (s16)mem->read16(base+0);
        s16 pb = (s16)mem->read16(base+2);
        s16 pc = (s16)mem->read16(base+4);
        s16 pd = (s16)mem->read16(base+6);
        s32 x0 = (s32)mem->read32(base+8);
        s32 y0 = (s32)mem->read32(base+12);

        for (int x=0;x<GBA_W;x++) {
            s32 tx = (x0 + pa*x + pb*y) >> 8;
            s32 ty = (y0 + pc*x + pd*y) >> 8;
            if (!wrap) {
                if (tx<0||ty<0||tx>=mapPx||ty>=mapPx) continue;
            } else {
                tx = ((tx % mapPx) + mapPx) % mapPx;
                ty = ((ty % mapPx) + mapPx) % mapPx;
            }
            int tilesPerRow = mapPx/8;
            u32 mapAddr = mapBase + (ty/8)*tilesPerRow + (tx/8);
            u8  tileNum = mapAddr < VRAM_SIZE ? mem->vram[mapAddr] : 0;
            u32 tileAddr= tileBase + tileNum*64 + (ty%8)*8 + (tx%8);
            u8  palIdx  = tileAddr < VRAM_SIZE ? mem->vram[tileAddr] : 0;
            if (palIdx==0) continue;
            u16 col = mem->read16(PAL_START + palIdx*2);
            line[x] = gba15toRGBA(col);
        }
    }

    // ── Sprite (OBJ) rendering ────────────────────────────────────────────────
    void renderSprites(int y, u32* line) {
        u16 dispcnt = mem->read16(REG_DISPCNT);
        bool map1D  = (dispcnt >> 6) & 1;

        for (int s=127;s>=0;s--) {
            u32 oamBase = OAM_START + s*8;
            u16 attr0 = mem->read16(oamBase+0);
            u16 attr1 = mem->read16(oamBase+2);
            u16 attr2 = mem->read16(oamBase+4);

            if ((attr0 >> 8) == 0b11) continue; // disabled

            int sy    = attr0 & 0xFF; if (sy >= 160) sy -= 256;
            int sx    = attr1 & 0x1FF; if (sx >= 240) sx -= 512;
            bool hflip= (attr1 >> 12) & 1;
            bool vflip= (attr1 >> 13) & 1;

            u32 shape = (attr0 >> 14) & 3;
            u32 size  = (attr1 >> 14) & 3;

            static const int widths [3][4] = {{8,16,32,64},{16,32,32,64},{8, 8,16,32}};
            static const int heights[3][4] = {{8,16,32,64},{8,8,16,32}, {16,32,32,64}};
            if (shape==3) continue;
            int sw = widths [shape][size];
            int sh = heights[shape][size];

            if (y < sy || y >= sy+sh) continue;

            int py = y - sy;
            if (vflip) py = sh-1-py;

            u32 tileNum  = attr2 & 0x3FF;
            u32 palNum   = (attr2 >> 12) & 0xF;
            bool col256  = (attr0 >> 13) & 1;

            for (int px=0;px<sw;px++) {
                int x = sx + px;
                if (x<0||x>=GBA_W) continue;

                int tpx = px; if (hflip) tpx = sw-1-px;
                int tx = tpx % 8, ty = py % 8;
                int toffX = tpx/8, toffY = py/8;

                u32 tileIdx;
                if (map1D) tileIdx = tileNum + toffY*(sw/8) + toffX;
                else       tileIdx = tileNum + toffY*32     + toffX;

                if (!col256) tileIdx = tileNum + toffY*(col256?8:32) + toffX;

                u8 palIdx;
                if (col256) {
                    u32 tileAddr = 0x10000 + (col256 ? tileIdx*64 : tileIdx*32) + ty*8 + tx;
                    palIdx = tileAddr < VRAM_SIZE ? mem->vram[tileAddr] : 0;
                    if (palIdx==0) continue;
                    u16 col = mem->read16(PAL_START + 0x200 + palIdx*2);
                    line[x] = gba15toRGBA(col);
                } else {
                    u32 tileAddr = 0x10000 + tileIdx*32 + ty*4 + tx/2;
                    u8  byte = tileAddr < VRAM_SIZE ? mem->vram[tileAddr] : 0;
                    palIdx = (tx&1) ? byte>>4 : byte&0xF;
                    if (palIdx==0) continue;
                    u16 col = mem->read16(PAL_START + 0x200 + (palNum*16+palIdx)*2);
                    line[x] = gba15toRGBA(col);
                }
            }
        }
    }
};
