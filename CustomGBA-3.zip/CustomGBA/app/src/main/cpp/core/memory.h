#pragma once
#include "types.h"
#include <vector>
#include <cstring>

struct Memory {
    u8 bios [BIOS_SIZE]  = {};
    u8 ewram[EWRAM_SIZE] = {};
    u8 iwram[IWRAM_SIZE] = {};
    u8 io   [IO_SIZE]    = {};
    u8 pal  [PAL_SIZE]   = {};
    u8 vram [VRAM_SIZE]  = {};
    u8 oam  [OAM_SIZE]   = {};
    std::vector<u8> rom;

    // Key state (active-low: 0=pressed)
    u16 keyState = 0x03FF;

    void init() {
        memset(ewram,0,sizeof(ewram));
        memset(iwram,0,sizeof(iwram));
        memset(io,0,sizeof(io));
        memset(pal,0,sizeof(pal));
        memset(vram,0,sizeof(vram));
        memset(oam,0,sizeof(oam));
        // Default IO values
        write16(REG_KEYINPUT, 0x03FF);
        write16(REG_DISPCNT, 0x0080);
    }

    bool loadROM(const u8* data, size_t size) {
        if (!data || size == 0) return false;
        rom.assign(data, data+size);
        return true;
    }

    // ── Read helpers ─────────────────────────────────────────────────────────
    u8 read8(u32 addr) const {
        addr &= 0x0FFFFFFF;
        if (addr < BIOS_SIZE)               return bios[addr];
        if (addr >= 0x02000000 && addr < 0x02000000+EWRAM_SIZE*4)
            return ewram[(addr-0x02000000) % EWRAM_SIZE];
        if (addr >= 0x03000000 && addr < 0x03000000+IWRAM_SIZE*8)
            return iwram[(addr-0x03000000) % IWRAM_SIZE];
        if (addr >= 0x04000000 && addr < 0x04000000+IO_SIZE)
            return readIO8(addr);
        if (addr >= 0x05000000 && addr < 0x05000000+PAL_SIZE*2)
            return pal[(addr-0x05000000) % PAL_SIZE];
        if (addr >= 0x06000000 && addr < 0x06000000+VRAM_SIZE+0x8000)
            return vram[(addr-0x06000000) % VRAM_SIZE];
        if (addr >= 0x07000000 && addr < 0x07000000+OAM_SIZE*8)
            return oam[(addr-0x07000000) % OAM_SIZE];
        if (addr >= 0x08000000) {
            u32 off = addr - 0x08000000;
            if (off < rom.size()) return rom[off];
        }
        return 0xFF;
    }

    u16 read16(u32 addr) const {
        addr &= ~1u;
        return (u16)read8(addr) | ((u16)read8(addr+1) << 8);
    }

    u32 read32(u32 addr) const {
        addr &= ~3u;
        return (u32)read16(addr) | ((u32)read16(addr+2) << 16);
    }

    // ── Write helpers ────────────────────────────────────────────────────────
    void write8(u32 addr, u8 val) {
        addr &= 0x0FFFFFFF;
        if (addr >= 0x02000000 && addr < 0x02000000+EWRAM_SIZE*4)
            { ewram[(addr-0x02000000) % EWRAM_SIZE] = val; return; }
        if (addr >= 0x03000000 && addr < 0x03000000+IWRAM_SIZE*8)
            { iwram[(addr-0x03000000) % IWRAM_SIZE] = val; return; }
        if (addr >= 0x04000000 && addr < 0x04000000+IO_SIZE)
            { writeIO8(addr, val); return; }
        if (addr >= 0x05000000 && addr < 0x05000000+PAL_SIZE*2)
            { pal[(addr-0x05000000) % PAL_SIZE] = val; return; }
        if (addr >= 0x06000000 && addr < 0x06000000+VRAM_SIZE+0x8000)
            { vram[(addr-0x06000000) % VRAM_SIZE] = val; return; }
        if (addr >= 0x07000000 && addr < 0x07000000+OAM_SIZE*8)
            { oam[(addr-0x07000000) % OAM_SIZE] = val; return; }
    }

    void write16(u32 addr, u16 val) {
        addr &= ~1u;
        write8(addr,   val & 0xFF);
        write8(addr+1, val >> 8);
    }

    void write32(u32 addr, u32 val) {
        addr &= ~3u;
        write16(addr,   val & 0xFFFF);
        write16(addr+2, val >> 16);
    }

    // ── IO register read ──────────────────────────────────────────────────────
    u8 readIO8(u32 addr) const {
        u32 off = addr - 0x04000000;
        if (off == (REG_KEYINPUT & 0xFFF))   return keyState & 0xFF;
        if (off == (REG_KEYINPUT & 0xFFF)+1) return keyState >> 8;
        if (off < IO_SIZE) return io[off];
        return 0;
    }

    // ── IO register write ─────────────────────────────────────────────────────
    void writeIO8(u32 addr, u8 val) {
        u32 off = addr - 0x04000000;
        if (off < IO_SIZE) io[off] = val;

        // IF register - writing clears bits
        if (addr == REG_IF)   io[off] &= ~val;
        if (addr == REG_IF+1) io[off] &= ~val;
    }

    // ── IO convenience ────────────────────────────────────────────────────────
    u16 ioRead16(u32 addr) const {
        return (u16)readIO8(addr) | ((u16)readIO8(addr+1) << 8);
    }
    void ioWrite16(u32 addr, u16 val) {
        writeIO8(addr,   val & 0xFF);
        writeIO8(addr+1, val >> 8);
    }

    void raiseIRQ(u16 bits) {
        u16 iff = read16(REG_IF) | bits;
        write16(REG_IF, iff);
    }
};
