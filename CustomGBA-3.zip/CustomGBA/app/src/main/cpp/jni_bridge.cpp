#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <memory>
#include <fstream>
#include <vector>
#include "core/gba.h"

#define TAG "CustomGBA"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─── EGL state ───────────────────────────────────────────────────────────────
struct EGLCtx {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    GLuint tex=0, prog=0, vbo=0;
};

// ─── OpenSL state ────────────────────────────────────────────────────────────
struct AudioCtx {
    SLObjectItf engine=nullptr, mix=nullptr, player=nullptr;
    SLPlayItf play=nullptr;
    SLAndroidSimpleBufferQueueItf bq=nullptr;
    static constexpr int NUM_BUFS=4, BUF_FRAMES=2048;
    float bufs[NUM_BUFS][BUF_FRAMES*2]={};
    int   bufIdx=0;
};

// ─── Global state ────────────────────────────────────────────────────────────
static struct {
    std::unique_ptr<GBA> gba;
    std::mutex           mu;
    std::thread          emuThread;
    std::atomic<bool>    running{false};
    std::atomic<bool>    paused {false};
    ANativeWindow*       window = nullptr;
    EGLCtx               egl;
    AudioCtx             audio;
    JavaVM*              jvm    = nullptr;
    jobject              cbObj  = nullptr;
    jmethodID            cbMID  = nullptr;
} G;

// ─── Shaders ─────────────────────────────────────────────────────────────────
static const char* VS = R"(attribute vec4 p;attribute vec2 u;varying vec2 v;
void main(){gl_Position=p;v=u;})";
static const char* FS = R"(precision mediump float;uniform sampler2D t;varying vec2 v;
void main(){gl_FragColor=texture2D(t,v);})";

static GLuint makeShader(GLenum type, const char* src) {
    GLuint s=glCreateShader(type);
    glShaderSource(s,1,&src,nullptr);
    glCompileShader(s);
    return s;
}

// ─── EGL init ─────────────────────────────────────────────────────────────────
static void eglInit(ANativeWindow* win, EGLCtx& e) {
    e.display=eglGetDisplay(EGL_DEFAULT_DISPLAY);
    eglInitialize(e.display,nullptr,nullptr);
    const EGLint a[]={EGL_SURFACE_TYPE,EGL_WINDOW_BIT,EGL_RENDERABLE_TYPE,
                      EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,
                      EGL_BLUE_SIZE,8,EGL_NONE};
    EGLConfig cfg; EGLint n;
    eglChooseConfig(e.display,a,&cfg,1,&n);
    const EGLint ca[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE};
    e.context=eglCreateContext(e.display,cfg,EGL_NO_CONTEXT,ca);
    e.surface=eglCreateWindowSurface(e.display,cfg,win,nullptr);
    eglMakeCurrent(e.display,e.surface,e.surface,e.context);

    GLuint vs=makeShader(GL_VERTEX_SHADER,VS);
    GLuint fs=makeShader(GL_FRAGMENT_SHADER,FS);
    e.prog=glCreateProgram();
    glAttachShader(e.prog,vs); glAttachShader(e.prog,fs);
    glLinkProgram(e.prog);
    glDeleteShader(vs); glDeleteShader(fs);

    // Full-screen quad, flipped vertically for GBA orientation
    static const float q[]={
        -1,-1,0,1,  1,-1,1,1,  -1,1,0,0,
         1,-1,1,1, -1, 1,0,0,   1,1,1,0};
    glGenBuffers(1,&e.vbo);
    glBindBuffer(GL_ARRAY_BUFFER,e.vbo);
    glBufferData(GL_ARRAY_BUFFER,sizeof(q),q,GL_STATIC_DRAW);

    glGenTextures(1,&e.tex);
    glBindTexture(GL_TEXTURE_2D,e.tex);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,GBA_W,GBA_H,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
}

static void eglRender(EGLCtx& e, ANativeWindow* win, const u32* fb) {
    if (e.display==EGL_NO_DISPLAY||!win) return;
    glViewport(0,0,ANativeWindow_getWidth(win),ANativeWindow_getHeight(win));
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(e.prog);
    glBindBuffer(GL_ARRAY_BUFFER,e.vbo);
    GLint ap=glGetAttribLocation(e.prog,"p"), au=glGetAttribLocation(e.prog,"u");
    glEnableVertexAttribArray(ap);
    glVertexAttribPointer(ap,2,GL_FLOAT,GL_FALSE,4*4,0);
    glEnableVertexAttribArray(au);
    glVertexAttribPointer(au,2,GL_FLOAT,GL_FALSE,4*4,(void*)(8));
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D,e.tex);
    glTexSubImage2D(GL_TEXTURE_2D,0,0,0,GBA_W,GBA_H,GL_RGBA,GL_UNSIGNED_BYTE,fb);
    glUniform1i(glGetUniformLocation(e.prog,"t"),0);
    glDrawArrays(GL_TRIANGLES,0,6);
    eglSwapBuffers(e.display,e.surface);
}

static void eglDestroy(EGLCtx& e) {
    if (e.display==EGL_NO_DISPLAY) return;
    eglMakeCurrent(e.display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
    if (e.tex)  glDeleteTextures(1,&e.tex);
    if (e.prog) glDeleteProgram(e.prog);
    if (e.vbo)  glDeleteBuffers(1,&e.vbo);
    eglDestroyContext(e.display,e.context);
    eglDestroySurface(e.display,e.surface);
    eglTerminate(e.display);
    e.display=EGL_NO_DISPLAY;
}

// ─── Audio callback ───────────────────────────────────────────────────────────
static void audioCallback(SLAndroidSimpleBufferQueueItf, void*) {
    auto& a = G.audio;
    memset(a.bufs[a.bufIdx%AudioCtx::NUM_BUFS], 0, sizeof(a.bufs[0]));
    (*a.bq)->Enqueue(a.bq, a.bufs[a.bufIdx%AudioCtx::NUM_BUFS],
                     AudioCtx::BUF_FRAMES*8);
    a.bufIdx++;
}

static void audioInit(AudioCtx& a) {
    slCreateEngine(&a.engine,0,nullptr,0,nullptr,nullptr);
    (*a.engine)->Realize(a.engine,SL_BOOLEAN_FALSE);
    SLEngineItf eng; (*a.engine)->GetInterface(a.engine,SL_IID_ENGINE,&eng);
    (*eng)->CreateOutputMix(eng,&a.mix,0,nullptr,nullptr);
    (*a.mix)->Realize(a.mix,SL_BOOLEAN_FALSE);
    SLDataLocator_AndroidSimpleBufferQueue lbq={SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE,AudioCtx::NUM_BUFS};
    SLDataFormat_PCM fmt={SL_DATAFORMAT_PCM,2,SL_SAMPLINGRATE_32,
        SL_PCMSAMPLEFORMAT_FIXED_16,SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_LEFT|SL_SPEAKER_FRONT_RIGHT,SL_BYTEORDER_LITTLEENDIAN};
    SLDataSource src={&lbq,&fmt};
    SLDataLocator_OutputMix lm={SL_DATALOCATOR_OUTPUTMIX,a.mix};
    SLDataSink sink={&lm,nullptr};
    const SLInterfaceID ids[]={SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[]={SL_BOOLEAN_TRUE};
    (*eng)->CreateAudioPlayer(eng,&a.player,&src,&sink,1,ids,req);
    (*a.player)->Realize(a.player,SL_BOOLEAN_FALSE);
    (*a.player)->GetInterface(a.player,SL_IID_PLAY,&a.play);
    (*a.player)->GetInterface(a.player,SL_IID_ANDROIDSIMPLEBUFFERQUEUE,&a.bq);
    (*a.bq)->RegisterCallback(a.bq,audioCallback,nullptr);
    memset(a.bufs,0,sizeof(a.bufs));
    for (int i=0;i<AudioCtx::NUM_BUFS;i++)
        (*a.bq)->Enqueue(a.bq,a.bufs[i],AudioCtx::BUF_FRAMES*8);
    (*a.play)->SetPlayState(a.play,SL_PLAYSTATE_PLAYING);
}

// ─── Emulator thread ─────────────────────────────────────────────────────────
static void emuLoop() {
    JNIEnv* env;
    G.jvm->AttachCurrentThread(&env, nullptr);

    eglInit(G.window, G.egl);
    audioInit(G.audio);

    G.gba->onFrameReady = [&](const u32* fb, int w, int h) {
        eglRender(G.egl, G.window, fb);
        if (G.cbObj && G.cbMID) env->CallVoidMethod(G.cbObj, G.cbMID);
    };
    G.gba->onAudioReady = [&](const float* buf, int frames) {
        // Convert float to s16 and enqueue
        auto& a = G.audio;
        int idx = a.bufIdx % AudioCtx::NUM_BUFS;
        int16_t* dst = reinterpret_cast<int16_t*>(a.bufs[idx]);
        int n = frames * 2;
        for (int i=0;i<n;i++)
            dst[i] = (int16_t)(buf[i] * 32767.0f);
        (*a.bq)->Enqueue(a.bq, a.bufs[idx], n*2);
        a.bufIdx++;
    };

    while (G.running) {
        if (G.paused) { std::this_thread::sleep_for(std::chrono::milliseconds(16)); continue; }
        std::lock_guard<std::mutex> lk(G.mu);
        if (G.gba) G.gba->runFrame();
    }

    eglDestroy(G.egl);
    if (G.audio.player) { (*G.audio.player)->Destroy(G.audio.player); }
    if (G.audio.mix)    { (*G.audio.mix)->Destroy(G.audio.mix); }
    if (G.audio.engine) { (*G.audio.engine)->Destroy(G.audio.engine); }
    G.jvm->DetachCurrentThread();
}

// ─── JNI exports ─────────────────────────────────────────────────────────────
extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    G.jvm = vm;
    LOGI("Custom GBA emulator JNI loaded");
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeInit(JNIEnv* env, jobject thiz) {
    G.gba = std::make_unique<GBA>();
    G.gba->init();
    G.cbObj = env->NewGlobalRef(thiz);
    jclass cls = env->GetObjectClass(thiz);
    G.cbMID = env->GetMethodID(cls, "onFrameReady", "()V");
    LOGI("GBA system initialized");
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeLoadROM(JNIEnv* env, jobject, jstring jpath) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    std::ifstream f(path, std::ios::binary);
    env->ReleaseStringUTFChars(jpath, path);
    if (!f) return JNI_FALSE;
    std::vector<u8> data((std::istreambuf_iterator<char>(f)), {});
    std::lock_guard<std::mutex> lk(G.mu);
    bool ok = G.gba->loadROM(data.data(), data.size());
    LOGI("ROM load %s (%zu bytes)", ok?"OK":"FAILED", data.size());
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetSurface(JNIEnv* env, jobject, jobject surf) {
    G.window = surf ? ANativeWindow_fromSurface(env, surf) : nullptr;
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeStart(JNIEnv*, jobject) {
    if (G.running) return;
    G.running = true;
    G.paused  = false;
    G.emuThread = std::thread(emuLoop);
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeStop(JNIEnv*, jobject) {
    G.running = false;
    if (G.emuThread.joinable()) G.emuThread.join();
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativePause(JNIEnv*, jobject, jboolean p) {
    G.paused = (p==JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetKeys(JNIEnv*, jobject, jint keys) {
    std::lock_guard<std::mutex> lk(G.mu);
    if (G.gba) G.gba->setKeys((u16)keys);
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeReset(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lk(G.mu);
    if (G.gba) G.gba->cpu.reset();
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeSaveState(JNIEnv* env, jobject, jstring jpath) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lk(G.mu);
    if (!G.gba) { env->ReleaseStringUTFChars(jpath, path); return JNI_FALSE; }
    // Save: CPU regs + memory snapshot
    std::ofstream f(path, std::ios::binary);
    f.write((char*)G.gba->cpu.r, sizeof(G.gba->cpu.r));
    f.write((char*)&G.gba->cpu.cpsr, 4);
    f.write((char*)&G.gba->cpu.spsr, 4);
    f.write((char*)G.gba->mem.ewram, EWRAM_SIZE);
    f.write((char*)G.gba->mem.iwram, IWRAM_SIZE);
    f.write((char*)G.gba->mem.io,    IO_SIZE);
    f.write((char*)G.gba->mem.pal,   PAL_SIZE);
    f.write((char*)G.gba->mem.vram,  VRAM_SIZE);
    f.write((char*)G.gba->mem.oam,   OAM_SIZE);
    env->ReleaseStringUTFChars(jpath, path);
    return f.good() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeLoadState(JNIEnv* env, jobject, jstring jpath) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lk(G.mu);
    if (!G.gba) { env->ReleaseStringUTFChars(jpath, path); return JNI_FALSE; }
    std::ifstream f(path, std::ios::binary);
    f.read((char*)G.gba->cpu.r, sizeof(G.gba->cpu.r));
    f.read((char*)&G.gba->cpu.cpsr, 4);
    f.read((char*)&G.gba->cpu.spsr, 4);
    f.read((char*)G.gba->mem.ewram, EWRAM_SIZE);
    f.read((char*)G.gba->mem.iwram, IWRAM_SIZE);
    f.read((char*)G.gba->mem.io,    IO_SIZE);
    f.read((char*)G.gba->mem.pal,   PAL_SIZE);
    f.read((char*)G.gba->mem.vram,  VRAM_SIZE);
    f.read((char*)G.gba->mem.oam,   OAM_SIZE);
    env->ReleaseStringUTFChars(jpath, path);
    return f.good() ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
