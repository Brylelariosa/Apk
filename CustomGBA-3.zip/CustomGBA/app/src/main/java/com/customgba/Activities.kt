package com.customgba

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.customgba.databinding.ActivityMainBinding
import com.customgba.databinding.ActivityGameBinding
import java.io.File
import java.io.FileOutputStream

// ── GBA button bit positions ──────────────────────────────────────────────────
object GbaKeys {
    const val A      = 1 shl 0
    const val B      = 1 shl 1
    const val SELECT = 1 shl 2
    const val START  = 1 shl 3
    const val RIGHT  = 1 shl 4
    const val LEFT   = 1 shl 5
    const val UP     = 1 shl 6
    const val DOWN   = 1 shl 7
    const val R      = 1 shl 8
    const val L      = 1 shl 9
}

// ─────────────────────────────────────────────────────────────────────────────
class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val path = cacheUri(uri) ?: return@registerForActivityResult run {
            Toast.makeText(this,"Failed to read ROM",Toast.LENGTH_SHORT).show()
        }
        startActivity(Intent(this, GameActivity::class.java)
            .putExtra("rom", path))
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnLoad.setOnClickListener { picker.launch(arrayOf("*/*")) }
    }

    private fun cacheUri(uri: Uri): String? = try {
        val name = contentResolver.query(uri,null,null,null,null)?.use { c ->
            c.moveToFirst(); c.getString(c.getColumnIndex(OpenableColumns.DISPLAY_NAME))
        } ?: "rom.gba"
        val dest = File(cacheDir, name)
        contentResolver.openInputStream(uri)?.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        dest.absolutePath
    } catch (e: Exception) { null }
}

// ─────────────────────────────────────────────────────────────────────────────
class GameActivity : AppCompatActivity() {
    private lateinit var b: ActivityGameBinding
    private val core = EmulatorCore()
    private var keys = 0

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                        WindowManager.LayoutParams.FLAG_FULLSCREEN)
        b = ActivityGameBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.gameView.holder.addCallback(object: SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder)   { core.setSurface(h.surface) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder) { core.setSurface(null) }
        })

        val rom = intent.getStringExtra("rom") ?: run { finish(); return }
        if (!core.loadROM(rom)) { Toast.makeText(this,"Bad ROM",Toast.LENGTH_SHORT).show(); finish(); return }
        core.start()

        fun btn(v: View, bit: Int) = v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> keys = keys or bit
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> keys = keys and bit.inv()
            }
            core.setKeys(keys); true
        }

        btn(b.btnA,      GbaKeys.A)
        btn(b.btnB,      GbaKeys.B)
        btn(b.btnL,      GbaKeys.L)
        btn(b.btnR,      GbaKeys.R)
        btn(b.btnStart,  GbaKeys.START)
        btn(b.btnSelect, GbaKeys.SELECT)
        btn(b.btnUp,     GbaKeys.UP)
        btn(b.btnDown,   GbaKeys.DOWN)
        btn(b.btnLeft,   GbaKeys.LEFT)
        btn(b.btnRight,  GbaKeys.RIGHT)

        b.btnMenu.setOnClickListener {
            core.pause(true)
            AlertDialog.Builder(this)
                .setTitle("Custom GBA")
                .setItems(arrayOf("Save State","Load State","Reset","Quit")) { _, w ->
                    when(w) {
                        0 -> core.saveState(File(filesDir,"state0.gbs").absolutePath)
                        1 -> core.loadState(File(filesDir,"state0.gbs").absolutePath)
                        2 -> core.reset()
                        3 -> finish()
                    }
                    core.pause(false)
                }
                .setOnCancelListener { core.pause(false) }
                .show()
        }
    }

    override fun onPause()   { super.onPause();  core.pause(true)  }
    override fun onResume()  { super.onResume(); core.pause(false) }
    override fun onDestroy() { core.stop(); super.onDestroy() }
}
