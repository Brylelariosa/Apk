package com.customgba

import android.view.Surface

class EmulatorCore {
    var onFrameReady: (() -> Unit)? = null

    init { nativeInit() }

    fun loadROM(path: String): Boolean = nativeLoadROM(path)
    fun setSurface(s: Surface?)        = nativeSetSurface(s)
    fun start()                        = nativeStart()
    fun stop()                         = nativeStop()
    fun pause(p: Boolean)              = nativePause(p)
    fun setKeys(k: Int)                = nativeSetKeys(k)
    fun reset()                        = nativeReset()
    fun saveState(path: String)        = nativeSaveState(path)
    fun loadState(path: String)        = nativeLoadState(path)

    @Suppress("unused")
    fun onFrameReady() { onFrameReady?.invoke() }

    private external fun nativeInit()
    private external fun nativeLoadROM(path: String): Boolean
    private external fun nativeSetSurface(s: Surface?)
    private external fun nativeStart()
    private external fun nativeStop()
    private external fun nativePause(p: Boolean)
    private external fun nativeSetKeys(k: Int)
    private external fun nativeReset()
    private external fun nativeSaveState(path: String): Boolean
    private external fun nativeLoadState(path: String): Boolean

    companion object { init { System.loadLibrary("customgba-core") } }
}
