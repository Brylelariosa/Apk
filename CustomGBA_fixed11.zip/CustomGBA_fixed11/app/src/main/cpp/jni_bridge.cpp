#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <memory>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
#include <ctime>
#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
#include "core/gba.h"

#define TAG "CustomGBA"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────────
// File logger — writes every log line to a .txt on device storage
// Thread-safe, survives crashes via fflush after every write
// ─────────────────────────────────────────────────────────────────────────────
static std::string  g_logPath;
static FILE*        g_logFile  = nullptr;
static std::mutex   g_logMutex;

static std::string timestamp() {
    time_t now = time(nullptr);
    struct tm* t = localtime(&now);
    char buf[32];
    strftime(buf, sizeof(buf), "%H:%M:%S", t);
    return std::string(buf);
}

static void flog(const char* level, const char* fmt, ...) {
    char msg[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    // Logcat
    __android_log_print(ANDROID_LOG_INFO, TAG, "%s", msg);

    // File — fflush immediately so crash doesn't lose the line
    if (g_logFile) {
        std::lock_guard<std::mutex> lk(g_logMutex);
        fprintf(g_logFile, "[%s][%s] %s\n", timestamp().c_str(), level, msg);
        fflush(g_logFile);
    }
}

#define FLOG(level, ...) flog(level, __VA_ARGS__)
#define FL_INFO(...)  FLOG("INFO",  __VA_ARGS__)
#define FL_ERROR(...) FLOG("ERROR", __VA_ARGS__)
#define FL_WARN(...)  FLOG("WARN",  __VA_ARGS__)
#define FL_DEBUG(...) FLOG("DEBUG", __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────────
// Crash handler — writes signal info + backtrace to log file before dying
// ─────────────────────────────────────────────────────────────────────────────
static void crashHandler(int sig, siginfo_t* info, void* /*ctx*/) {
    const char* sigName = "UNKNOWN";
    switch(sig) {
        case SIGSEGV: sigName="SIGSEGV (Segfault)";  break;
        case SIGABRT: sigName="SIGABRT (Abort)";     break;
        case SIGFPE:  sigName="SIGFPE  (Math error)"; break;
        case SIGILL:  sigName="SIGILL  (Illegal instr)"; break;
        case SIGBUS:  sigName="SIGBUS  (Bus error)";  break;
    }

    // Write directly — can't use mutex in a signal handler safely
    if (g_logFile) {
        fprintf(g_logFile, "\n");
        fprintf(g_logFile, "══════════════════════════════════\n");
        fprintf(g_logFile, "  *** CRASH DETECTED ***\n");
        fprintf(g_logFile, "  Signal : %s (%d)\n", sigName, sig);
        if (info) {
            fprintf(g_logFile, "  Address: %p\n", info->si_addr);
            fprintf(g_logFile, "  Code   : %d\n", info->si_code);
        }
        fprintf(g_logFile, "══════════════════════════════════\n");
        fflush(g_logFile);
        fclose(g_logFile);
        g_logFile = nullptr;
    }

    // Re-raise so Android can also generate a tombstone
    signal(sig, SIG_DFL);
    raise(sig);
}

static void installCrashHandler() {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = crashHandler;
    sa.sa_flags     = SA_SIGINFO | SA_RESETHAND;
    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
    sigaction(SIGFPE,  &sa, nullptr);
    sigaction(SIGILL,  &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
    FL_INFO("[CRASH] Signal handlers installed");
}

// ─────────────────────────────────────────────────────────────────────────────
// EGL / Audio / GBA state
// ─────────────────────────────────────────────────────────────────────────────
struct EGLCtx {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    GLuint tex=0, prog=0, vbo=0;
    bool ok = false;
};

struct AudioCtx {
    SLObjectItf engine=nullptr, mix=nullptr, player=nullptr;
    SLPlayItf play=nullptr;
    SLAndroidSimpleBufferQueueItf bq=nullptr;
    static constexpr int NUM_BUFS=4, BUF_FRAMES=2048;
    float bufs[NUM_BUFS][BUF_FRAMES*2]={};
    int   bufIdx=0;
    bool  ok=false;
};

// Debug status — readable from Kotlin via nativeGetDebugInfo()
struct DebugStatus {
    // ROM
    std::string romTitle, romCode;
    size_t      romSize    = 0;
    bool        romLoaded  = false, romLogoOK = false;
    // EGL/Audio
    bool        eglOK = false, audioOK = false;
    std::string glRenderer, glVersion;
    // CPU
    bool        cpuHalted  = false;
    u32         cpuPC = 0, cpsr = 0;
    u32         r0=0, r1=0, r2=0, r3=0, r4=0, r5=0;
    // Frame counters
    int         frames = 0, renders = 0;
    // IRQ subsystem (sampled once per frame)
    u16         regIE = 0, regIF = 0, regIME = 0;
    u16         biosLatch  = 0;    // 0x03FFFFF8
    u32         irqVecAddr = 0;    // [0x03FFFFFC]
    int         irqCount   = 0;    // total HW IRQs dispatched
    int         vblankCount= 0;    // VBlank count
    int         swiCount   = 0;    // SWI calls
    u32         lastSWI    = 0xFF; // last SWI number
    int         dispcntChanges = 0;
    // SWI history ring buffer (last 8 calls)
    static constexpr int SWI_LOG_SIZE = 8;
    u32         swiLog[SWI_LOG_SIZE] = {};
    int         swiLogHead = 0;
    // PPU
    u16         dispcnt = 0, dispstat = 0;
    int         vcount  = 0;
    // ── Direct Sound FIFO debug (new) ────────────────────────────────────────
    int         fifoAPushes = 0, fifoAPops = 0, fifoAOverflows = 0, fifoADmaReqs = 0;
    int         fifoBPushes = 0, fifoBPops = 0, fifoBOverflows = 0, fifoBDmaReqs = 0;
    int         fifoACount  = 0, fifoBCount = 0;  // live fill levels
    int         fifoATimer  = 0, fifoBTimer = 0;  // timer select (0 or 1)
    bool        fifoARight  = false, fifoALeft = false;
    bool        fifoBRight  = false, fifoBLeft = false;
    float       fifoAVol    = 0.f,  fifoBVol  = 0.f;
    int         memFifoAWrites = 0, memFifoBWrites = 0; // raw 32-bit writes routed
    // ── Timer debug (new) ────────────────────────────────────────────────────
    int         timerOverflows[4] = {};  // total overflows per timer
    u16         timerCounters[4]  = {};  // live counter values
    u16         timerReloads[4]   = {};  // reload values (determines sample rate)
    bool        timerEnabled[4]   = {};
    // Error
    std::string lastError;
} g_dbg;

static struct {
    std::unique_ptr<GBA> gba;
    std::mutex           mu;
    std::thread          emuThread;
    std::atomic<bool>    running{false};
    std::atomic<bool>    paused {false};
    ANativeWindow*       window = nullptr;
    EGLCtx               egl;
    AudioCtx             audio;
    JavaVM*              jvm    = nullptr;
    jobject              cbObj  = nullptr;
    jmethodID            cbMID  = nullptr;
    std::atomic<int>     frameCount{0};
    std::atomic<int>     renderCount{0};
    // Key state: written from UI thread without holding G.mu to avoid 16ms freeze
    std::atomic<uint16_t> pendingKeys{0x03FF};  // all-released (active-low, 0x03FF = nothing pressed)
} G;

// ─────────────────────────────────────────────────────────────────────────────
// Shaders
// ─────────────────────────────────────────────────────────────────────────────
static const char* VS = R"(attribute vec4 p;attribute vec2 u;varying vec2 v;
void main(){gl_Position=p;v=u;})";
static const char* FS = R"(precision mediump float;uniform sampler2D t;varying vec2 v;
void main(){gl_FragColor=texture2D(t,v);})";

static GLuint makeShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok=0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512]; glGetShaderInfoLog(s, 512, nullptr, buf);
        FL_ERROR("[EGL] Shader FAILED: %s", buf);
        g_dbg.lastError = std::string("Shader fail: ") + buf;
    }
    return s;
}

// ─────────────────────────────────────────────────────────────────────────────
// EGL
// ─────────────────────────────────────────────────────────────────────────────
static bool eglInit(ANativeWindow* win, EGLCtx& e) {
    FL_INFO("[EGL] Init window=%p", win);
    if (!win) { FL_ERROR("[EGL] NULL window"); g_dbg.lastError="EGL: null window"; return false; }

    e.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (e.display==EGL_NO_DISPLAY) { FL_ERROR("[EGL] No display"); return false; }

    EGLint maj=0,min=0;
    if (!eglInitialize(e.display,&maj,&min)) {
        FL_ERROR("[EGL] Init failed 0x%x", eglGetError()); return false;
    }
    FL_INFO("[EGL] v%d.%d", maj, min);

    const EGLint a[]={EGL_SURFACE_TYPE,EGL_WINDOW_BIT,EGL_RENDERABLE_TYPE,
        EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_NONE};
    EGLConfig cfg; EGLint n=0;
    if (!eglChooseConfig(e.display,a,&cfg,1,&n)||n==0) {
        FL_ERROR("[EGL] ChooseConfig failed 0x%x", eglGetError());
        g_dbg.lastError="EGL: no config"; return false;
    }
    const EGLint ca[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE};
    e.context=eglCreateContext(e.display,cfg,EGL_NO_CONTEXT,ca);
    if (e.context==EGL_NO_CONTEXT) {
        FL_ERROR("[EGL] CreateContext failed 0x%x",eglGetError());
        g_dbg.lastError="EGL: no context"; return false;
    }
    e.surface=eglCreateWindowSurface(e.display,cfg,win,nullptr);
    if (e.surface==EGL_NO_SURFACE) {
        FL_ERROR("[EGL] CreateSurface failed 0x%x",eglGetError());
        g_dbg.lastError="EGL: no surface"; return false;
    }
    if (!eglMakeCurrent(e.display,e.surface,e.surface,e.context)) {
        FL_ERROR("[EGL] MakeCurrent failed 0x%x",eglGetError());
        g_dbg.lastError="EGL: makecurrent failed"; return false;
    }

    g_dbg.glRenderer = (const char*)glGetString(GL_RENDERER);
    g_dbg.glVersion  = (const char*)glGetString(GL_VERSION);
    FL_INFO("[EGL] GL: %s | %s", g_dbg.glRenderer.c_str(), g_dbg.glVersion.c_str());
    FL_INFO("[EGL] Window: %dx%d", ANativeWindow_getWidth(win), ANativeWindow_getHeight(win));

    GLuint vs=makeShader(GL_VERTEX_SHADER,VS), fs=makeShader(GL_FRAGMENT_SHADER,FS);
    e.prog=glCreateProgram();
    glAttachShader(e.prog,vs); glAttachShader(e.prog,fs); glLinkProgram(e.prog);
    GLint linked=0; glGetProgramiv(e.prog,GL_LINK_STATUS,&linked);
    if (!linked) {
        char buf[512]; glGetProgramInfoLog(e.prog,512,nullptr,buf);
        FL_ERROR("[EGL] Link failed: %s",buf);
        g_dbg.lastError=std::string("Shader link: ")+buf; return false;
    }
    glDeleteShader(vs); glDeleteShader(fs);

    static const float q[]={-1,-1,0,1, 1,-1,1,1, -1,1,0,0,
                              1,-1,1,1,-1, 1,0,0,  1,1,1,0};
    glGenBuffers(1,&e.vbo);
    glBindBuffer(GL_ARRAY_BUFFER,e.vbo);
    glBufferData(GL_ARRAY_BUFFER,sizeof(q),q,GL_STATIC_DRAW);

    glGenTextures(1,&e.tex);
    glBindTexture(GL_TEXTURE_2D,e.tex);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,GBA_W,GBA_H,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);

    e.ok = true;
    g_dbg.eglOK = true;
    FL_INFO("[EGL] Init OK");
    return true;
}

static void eglRender(EGLCtx& e, ANativeWindow* win, const u32* fb) {
    if (e.display==EGL_NO_DISPLAY||!win) {
        FL_WARN("[EGL] Render skipped display=%p win=%p",(void*)e.display,win);
        return;
    }
    glViewport(0,0,ANativeWindow_getWidth(win),ANativeWindow_getHeight(win));
    glClearColor(0,0,0,1); glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(e.prog);
    glBindBuffer(GL_ARRAY_BUFFER,e.vbo);
    GLint ap=glGetAttribLocation(e.prog,"p"), au=glGetAttribLocation(e.prog,"u");
    glEnableVertexAttribArray(ap);
    glVertexAttribPointer(ap,2,GL_FLOAT,GL_FALSE,4*4,0);
    glEnableVertexAttribArray(au);
    glVertexAttribPointer(au,2,GL_FLOAT,GL_FALSE,4*4,(void*)(8));
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D,e.tex);
    glTexSubImage2D(GL_TEXTURE_2D,0,0,0,GBA_W,GBA_H,GL_RGBA,GL_UNSIGNED_BYTE,fb);
    glUniform1i(glGetUniformLocation(e.prog,"t"),0);
    glDrawArrays(GL_TRIANGLES,0,6);
    GLenum err=glGetError();
    if (err!=GL_NO_ERROR) {
        FL_ERROR("[EGL] GL error 0x%x",err);
        g_dbg.lastError="GL error 0x"+std::to_string(err);
    }
    if (!eglSwapBuffers(e.display,e.surface))
        FL_ERROR("[EGL] SwapBuffers failed 0x%x",eglGetError());
    G.renderCount++;
    if (G.renderCount==1||G.renderCount%60==0)
        FL_INFO("[EGL] Rendered #%d",G.renderCount.load());
}

static void eglDestroy(EGLCtx& e) {
    FL_INFO("[EGL] Destroying");
    if (e.display==EGL_NO_DISPLAY) return;
    eglMakeCurrent(e.display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
    if (e.tex)  glDeleteTextures(1,&e.tex);
    if (e.prog) glDeleteProgram(e.prog);
    if (e.vbo)  glDeleteBuffers(1,&e.vbo);
    eglDestroyContext(e.display,e.context);
    eglDestroySurface(e.display,e.surface);
    eglTerminate(e.display);
    e.display=EGL_NO_DISPLAY; e.ok=false;
}

// ─────────────────────────────────────────────────────────────────────────────
// Audio
// ─────────────────────────────────────────────────────────────────────────────
static void audioCallback(SLAndroidSimpleBufferQueueItf,void*) {
    auto& a=G.audio;
    memset(a.bufs[a.bufIdx%AudioCtx::NUM_BUFS],0,sizeof(a.bufs[0]));
    (*a.bq)->Enqueue(a.bq,a.bufs[a.bufIdx%AudioCtx::NUM_BUFS],AudioCtx::BUF_FRAMES*8);
    a.bufIdx++;
}

static void audioInit(AudioCtx& a) {
    FL_INFO("[Audio] Init OpenSL ES");
    SLresult r=slCreateEngine(&a.engine,0,nullptr,0,nullptr,nullptr);
    if (r!=SL_RESULT_SUCCESS){FL_ERROR("[Audio] CreateEngine %d",r); return;}
    (*a.engine)->Realize(a.engine,SL_BOOLEAN_FALSE);
    SLEngineItf eng; (*a.engine)->GetInterface(a.engine,SL_IID_ENGINE,&eng);
    (*eng)->CreateOutputMix(eng,&a.mix,0,nullptr,nullptr);
    (*a.mix)->Realize(a.mix,SL_BOOLEAN_FALSE);
    SLDataLocator_AndroidSimpleBufferQueue lbq={SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE,AudioCtx::NUM_BUFS};
    SLDataFormat_PCM fmt={SL_DATAFORMAT_PCM,2,SL_SAMPLINGRATE_32,
        SL_PCMSAMPLEFORMAT_FIXED_16,SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_LEFT|SL_SPEAKER_FRONT_RIGHT,SL_BYTEORDER_LITTLEENDIAN};
    SLDataSource src={&lbq,&fmt};
    SLDataLocator_OutputMix lm={SL_DATALOCATOR_OUTPUTMIX,a.mix};
    SLDataSink sink={&lm,nullptr};
    const SLInterfaceID ids[]={SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[]={SL_BOOLEAN_TRUE};
    r=(*eng)->CreateAudioPlayer(eng,&a.player,&src,&sink,1,ids,req);
    if (r!=SL_RESULT_SUCCESS){FL_ERROR("[Audio] CreatePlayer %d",r); return;}
    (*a.player)->Realize(a.player,SL_BOOLEAN_FALSE);
    (*a.player)->GetInterface(a.player,SL_IID_PLAY,&a.play);
    (*a.player)->GetInterface(a.player,SL_IID_ANDROIDSIMPLEBUFFERQUEUE,&a.bq);
    (*a.bq)->RegisterCallback(a.bq,audioCallback,nullptr);
    memset(a.bufs,0,sizeof(a.bufs));
    for (int i=0;i<AudioCtx::NUM_BUFS;i++)
        (*a.bq)->Enqueue(a.bq,a.bufs[i],AudioCtx::BUF_FRAMES*8);
    r=(*a.play)->SetPlayState(a.play,SL_PLAYSTATE_PLAYING);
    a.ok=(r==SL_RESULT_SUCCESS);
    g_dbg.audioOK=a.ok;
    FL_INFO("[Audio] %s",a.ok?"OK":"FAILED");
}

// ─────────────────────────────────────────────────────────────────────────────
// ROM header dump
// ─────────────────────────────────────────────────────────────────────────────
static void dumpROMHeader(const std::vector<u8>& rom) {
    if (rom.size()<0xC0){FL_WARN("[ROM] Too small %zu bytes",rom.size()); return;}
    char title[13]={},code[5]={},maker[3]={};
    memcpy(title,rom.data()+0xA0,12);
    memcpy(code, rom.data()+0xAC,4);
    memcpy(maker,rom.data()+0xB0,2);
    u32 entry=rom[0]|(rom[1]<<8)|(rom[2]<<16)|(rom[3]<<24);
    bool logoOK=rom[0x04]==0x24&&rom[0x05]==0xFF&&rom[0x06]==0xAE&&rom[0x07]==0x51;
    g_dbg.romTitle   = title;
    g_dbg.romCode    = code;
    g_dbg.romSize    = rom.size();
    g_dbg.romLogoOK  = logoOK;
    FL_INFO("[ROM] ──────────────────────────────────");
    FL_INFO("[ROM] Size      : %zu bytes (%.2f MB)", rom.size(),rom.size()/1048576.0f);
    FL_INFO("[ROM] Title     : '%.12s'", title);
    FL_INFO("[ROM] Game Code : '%.4s'",  code);
    FL_INFO("[ROM] Maker     : '%.2s'",  maker);
    FL_INFO("[ROM] Entry     : 0x%08X",  entry);
    FL_INFO("[ROM] Fixed 0x96: 0x%02X %s", rom[0xB2], rom[0xB2]==0x96?"OK":"BAD");
    FL_INFO("[ROM] Logo      : %s",      logoOK?"PASS":"FAIL");
    FL_INFO("[ROM] Checksum  : 0x%02X",  rom[0xBD]);
    FL_INFO("[ROM] ──────────────────────────────────");
}

// ─────────────────────────────────────────────────────────────────────────────
// Emulator thread
// ─────────────────────────────────────────────────────────────────────────────
static void emuLoop() {
    FL_INFO("[EMU] Thread started");
    JNIEnv* env=nullptr;
    if (G.jvm->AttachCurrentThread(&env,nullptr)!=JNI_OK){
        FL_ERROR("[EMU] AttachCurrentThread FAILED"); return;
    }
    bool eglOK=eglInit(G.window,G.egl);
    FL_INFO("[EMU] EGL: %s",eglOK?"OK":"FAILED");
    audioInit(G.audio);

    G.gba->onFrameReady=[&](const u32* fb,int w,int h){
        G.frameCount++;
        auto& cpu = G.gba->cpu;
        auto& mem = G.gba->mem;

        // ── Populate rich debug snapshot ─────────────────────────────────────
        g_dbg.frames    = G.frameCount;
        g_dbg.renders   = G.renderCount;
        g_dbg.cpuPC     = cpu.r[15];
        g_dbg.cpsr      = cpu.cpsr;
        g_dbg.cpuHalted = cpu.halted;
        g_dbg.r0        = cpu.r[0];  g_dbg.r1 = cpu.r[1];
        g_dbg.r2        = cpu.r[2];  g_dbg.r3 = cpu.r[3];
        g_dbg.r4        = cpu.r[4];  g_dbg.r5 = cpu.r[5];
        // IRQ registers (read directly from IO array to avoid side effects)
        g_dbg.regIE     = mem.ioRead16(REG_IE);
        g_dbg.regIF     = mem.ioRead16(REG_IF);
        g_dbg.regIME    = mem.ioRead16(REG_IME);
        g_dbg.biosLatch = mem.read16(0x03FFFFF8);
        g_dbg.irqVecAddr= mem.read32(0x03FFFFFC);
        // PPU registers
        g_dbg.dispcnt   = mem.ioRead16(REG_DISPCNT);
        g_dbg.dispstat  = mem.ioRead16(REG_DISPSTAT);
        g_dbg.vcount    = mem.ioRead16(REG_VCOUNT);
        // CPU diagnostic counters from biosHLE/IRQ dispatch
        g_dbg.irqCount    = cpu.totalIRQs;
        g_dbg.vblankCount = cpu.vblankIRQs;
        g_dbg.swiCount    = cpu.swiCallCount;
        g_dbg.lastSWI     = cpu.lastSwiNum;
        // Copy SWI history ring buffer (last 8 calls, oldest → newest)
        for (int i = 0; i < DebugStatus::SWI_LOG_SIZE; i++) {
            int idx = (cpu.swiHistHead - DebugStatus::SWI_LOG_SIZE + i + cpu.SWI_HIST) % cpu.SWI_HIST;
            g_dbg.swiLog[i] = cpu.swiHistory[idx];
        }
        g_dbg.swiLogHead    = cpu.swiHistHead;
        g_dbg.dispcntChanges= cpu.dispcntChanges;

        // ── Direct Sound FIFO snapshot ────────────────────────────────────────
        auto& fa = G.gba->apu.fifoA;
        auto& fb = G.gba->apu.fifoB;
        g_dbg.fifoAPushes   = fa.totalPushes;
        g_dbg.fifoAPops     = fa.totalPops;
        g_dbg.fifoAOverflows= fa.overflows;
        g_dbg.fifoADmaReqs  = fa.dmaRequests;
        g_dbg.fifoACount    = fa.count;
        g_dbg.fifoATimer    = fa.timerSelect;
        g_dbg.fifoALeft     = fa.leftEnable;
        g_dbg.fifoARight    = fa.rightEnable;
        g_dbg.fifoAVol      = fa.volume;
        g_dbg.fifoBPushes   = fb.totalPushes;
        g_dbg.fifoBPops     = fb.totalPops;
        g_dbg.fifoBOverflows= fb.overflows;
        g_dbg.fifoBDmaReqs  = fb.dmaRequests;
        g_dbg.fifoBCount    = fb.count;
        g_dbg.fifoBTimer    = fb.timerSelect;
        g_dbg.fifoBLeft     = fb.leftEnable;
        g_dbg.fifoBRight    = fb.rightEnable;
        g_dbg.fifoBVol      = fb.volume;
        g_dbg.memFifoAWrites= mem.dbgFifoAWrites;
        g_dbg.memFifoBWrites= mem.dbgFifoBWrites;

        // ── Timer snapshot ────────────────────────────────────────────────────
        for (int ti = 0; ti < 4; ti++) {
            g_dbg.timerOverflows[ti] = G.gba->timers.t[ti].totalOverflows;
            g_dbg.timerCounters[ti]  = G.gba->timers.t[ti].counter;
            g_dbg.timerReloads[ti]   = G.gba->timers.t[ti].reload;
            g_dbg.timerEnabled[ti]   = G.gba->timers.t[ti].enable;
        }

        // ── Per-60-frame log ─────────────────────────────────────────────────
        if (G.frameCount == 1) FL_INFO("[EMU] *** FIRST FRAME *** %dx%d", w, h);
        if (G.frameCount % 60 == 0) {
            bool forcedBlank = (g_dbg.dispcnt >> 7) & 1;
            // Detect which execution phase the CPU is in for easier triage
            const char* phase = "ROM";
            u32 pc = cpu.r[15];
            if      (pc < 0x00004000) phase = "BIOS";
            else if (pc < 0x02000000) phase = "OPEN-BUS!"; // ← bad, should not happen
            else if (pc < 0x03000000) phase = "EWRAM";
            else if (pc < 0x04000000) phase = "IWRAM";
            else if (pc >= 0x08000000 && pc < 0x0E000000) phase = "ROM";
            else if (pc >= 0x04000000 && pc < 0x08000000) phase = "IO/VRAM!"; // very bad
            FL_INFO("[EMU] frame#%d PC=0x%08X [%s] CPSR=0x%08X halted=%d irqsPending=%d",
                G.frameCount.load(), cpu.r[15], phase, cpu.cpsr, cpu.halted,
                cpu.irqHandlerPending);
            FL_INFO("[FIFO] A: pushes=%d pops=%d ovfl=%d dmaReq=%d fill=%d  B: pushes=%d pops=%d ovfl=%d dmaReq=%d fill=%d",
                g_dbg.fifoAPushes, g_dbg.fifoAPops, g_dbg.fifoAOverflows, g_dbg.fifoADmaReqs, g_dbg.fifoACount,
                g_dbg.fifoBPushes, g_dbg.fifoBPops, g_dbg.fifoBOverflows, g_dbg.fifoBDmaReqs, g_dbg.fifoBCount);
            FL_INFO("[TMR] T0:en=%d ovfl=%d reload=0x%04X  T1:en=%d ovfl=%d reload=0x%04X",
                g_dbg.timerEnabled[0], g_dbg.timerOverflows[0], g_dbg.timerReloads[0],
                g_dbg.timerEnabled[1], g_dbg.timerOverflows[1], g_dbg.timerReloads[1]);
            FL_INFO("[PPU] DISPCNT=0x%04X mode=%d fblank=%d changes=%d DISPSTAT=0x%04X",
                g_dbg.dispcnt, g_dbg.dispcnt & 7, forcedBlank,
                cpu.dispcntChanges, g_dbg.dispstat);
            FL_INFO("[IRQ] IE=0x%04X IF=0x%04X IME=%d latch=0x%04X vec=0x%08X total=%d vbl=%d",
                g_dbg.regIE, g_dbg.regIF, g_dbg.regIME & 1,
                g_dbg.biosLatch, g_dbg.irqVecAddr,
                cpu.totalIRQs, cpu.vblankIRQs);
            FL_INFO("[SWI] total=%d last=0x%02X irqRet=%d retPC=0x%08X retCPSR=0x%08X",
                cpu.swiCallCount, cpu.lastSwiNum,
                cpu.irqHandlerPending, cpu.irqReturnPC, cpu.irqReturnCPSR);
            FL_INFO("[FIFO] A: mem=%d push=%d pop=%d ovfl=%d dmaReq=%d fill=%d | B: mem=%d push=%d pop=%d ovfl=%d dmaReq=%d fill=%d",
                g_dbg.memFifoAWrites, g_dbg.fifoAPushes, g_dbg.fifoAPops,
                g_dbg.fifoAOverflows, g_dbg.fifoADmaReqs, g_dbg.fifoACount,
                g_dbg.memFifoBWrites, g_dbg.fifoBPushes, g_dbg.fifoBPops,
                g_dbg.fifoBOverflows, g_dbg.fifoBDmaReqs, g_dbg.fifoBCount);
            FL_INFO("[TMR] T0:en=%d ovfl=%d rld=0x%04X | T1:en=%d ovfl=%d rld=0x%04X | T2:en=%d ovfl=%d | T3:en=%d ovfl=%d",
                (int)g_dbg.timerEnabled[0], g_dbg.timerOverflows[0], g_dbg.timerReloads[0],
                (int)g_dbg.timerEnabled[1], g_dbg.timerOverflows[1], g_dbg.timerReloads[1],
                (int)g_dbg.timerEnabled[2], g_dbg.timerOverflows[2],
                (int)g_dbg.timerEnabled[3], g_dbg.timerOverflows[3]);
        }

        eglRender(G.egl, G.window, fb);
        if (G.cbObj && G.cbMID) env->CallVoidMethod(G.cbObj, G.cbMID);
    };
    G.gba->onAudioReady=[&](const float* buf,int frames){
        auto& a=G.audio; if (!a.bq) return;
        int idx=a.bufIdx%AudioCtx::NUM_BUFS;
        int16_t* dst=reinterpret_cast<int16_t*>(a.bufs[idx]);
        for (int i=0;i<frames*2;i++) dst[i]=(int16_t)(buf[i]*32767.0f);
        (*a.bq)->Enqueue(a.bq,a.bufs[idx],frames*4);
        a.bufIdx++;
    };

    FL_INFO("[EMU] Entering main loop");
    int iter=0;
    auto frameStart = std::chrono::steady_clock::now();
    while (G.running) {
        if (G.paused){
            if (iter%200==0) FL_DEBUG("[EMU] Paused iter=%d",iter);
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
            iter++; continue;
        }

        {
            std::lock_guard<std::mutex> lk(G.mu);
            // EGL init (and window access) must also be under G.mu to avoid
            // racing with nativeSetSurface on the UI thread.
            if (!G.egl.ok && G.window) {
                FL_INFO("[EMU] Surface arrived late — retrying EGL (iter=%d)", iter);
                bool ok = eglInit(G.window, G.egl);
                FL_INFO("[EMU] EGL retry: %s", ok ? "OK — frames will now render!" : "FAILED again");
            }
            // Apply keys from UI thread without blocking that thread on G.mu
            if (G.gba) G.gba->setKeys(G.pendingKeys.load(std::memory_order_relaxed));
            if (G.gba) G.gba->runFrame();
            else FL_ERROR("[EMU] GBA is null!");
        }

        // ── Frame pacing: target ~59.7 fps (GBA actual rate) ─────────────────
        // Without this the app burns CPU and the OS kills us for ANR on slow devices.
        auto now = std::chrono::steady_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::microseconds>(now - frameStart).count();
        const long TARGET_US = 16742; // ~59.7 fps
        if (elapsed < TARGET_US) {
            std::this_thread::sleep_for(std::chrono::microseconds(TARGET_US - elapsed));
        }
        frameStart = std::chrono::steady_clock::now();

        iter++;
        if (iter==1)  FL_INFO("[EMU] First runFrame OK frames=%d",G.frameCount.load());
        if (iter==10) FL_INFO("[EMU] 10 iters frames=%d renders=%d",G.frameCount.load(),G.renderCount.load());
        if (iter%300==0)
            FL_INFO("[EMU] iter=%d frames=%d renders=%d halted=%d PC=0x%08X",
                iter,G.frameCount.load(),G.renderCount.load(),
                G.gba->cpu.halted,G.gba->cpu.r[15]);
    }
    FL_INFO("[EMU] Loop exited frames=%d renders=%d",G.frameCount.load(),G.renderCount.load());
    eglDestroy(G.egl);
    if (G.audio.player){(*G.audio.player)->Destroy(G.audio.player);G.audio.player=nullptr;}
    if (G.audio.mix)   {(*G.audio.mix)->Destroy(G.audio.mix);      G.audio.mix=nullptr;}
    if (G.audio.engine){(*G.audio.engine)->Destroy(G.audio.engine);G.audio.engine=nullptr;}
    G.jvm->DetachCurrentThread();
    FL_INFO("[EMU] Thread done");
}

// ─────────────────────────────────────────────────────────────────────────────
// JNI exports
// ─────────────────────────────────────────────────────────────────────────────
extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm,void*) {
    G.jvm=vm;
    LOGI("══ Custom GBA JNI loaded ══");
    return JNI_VERSION_1_6;
}

// Called first — sets up log file + crash handler
JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetLogPath(JNIEnv* env, jobject, jstring jpath) {
    const char* path=env->GetStringUTFChars(jpath,nullptr);
    g_logPath=path;
    env->ReleaseStringUTFChars(jpath,path);

    {
        std::lock_guard<std::mutex> lk(g_logMutex);
        if (g_logFile) fclose(g_logFile);
        g_logFile=fopen(g_logPath.c_str(),"a");
    }

    installCrashHandler();

    time_t now=time(nullptr);
    FL_INFO("══════════════════════════════════════");
    FL_INFO("  Custom GBA Debug Log");
    FL_INFO("  Started: %s", ctime(&now));
    FL_INFO("  Log path: %s", g_logPath.c_str());
    FL_INFO("══════════════════════════════════════");
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeInit(JNIEnv* env, jobject thiz) {
    FL_INFO("[INIT] nativeInit");
    G.gba=std::make_unique<GBA>();
    G.gba->init();
    G.cbObj=env->NewGlobalRef(thiz);
    jclass cls=env->GetObjectClass(thiz);
    G.cbMID=env->GetMethodID(cls,"onFrameReady","()V");
    G.frameCount=0; G.renderCount=0;
    FL_INFO("[INIT] Done cbMID=%p",(void*)G.cbMID);
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeLoadROM(JNIEnv* env, jobject, jstring jpath) {
    const char* path=env->GetStringUTFChars(jpath,nullptr);
    FL_INFO("[ROM] Loading: %s",path);
    std::ifstream f(path,std::ios::binary);
    if (!f){
        FL_ERROR("[ROM] Cannot open file");
        g_dbg.lastError="Cannot open ROM file";
        env->ReleaseStringUTFChars(jpath,path); return JNI_FALSE;
    }
    std::vector<u8> data((std::istreambuf_iterator<char>(f)),{});
    FL_INFO("[ROM] Read %zu bytes",data.size());
    env->ReleaseStringUTFChars(jpath,path);
    dumpROMHeader(data);
    std::lock_guard<std::mutex> lk(G.mu);
    bool ok=G.gba->loadROM(data.data(),data.size());
    g_dbg.romLoaded=ok;
    FL_INFO("[ROM] %s PC=0x%08X CPSR=0x%08X",
        ok?"LOADED":"FAILED",G.gba->cpu.r[15],G.gba->cpu.cpsr);
    if (!ok) g_dbg.lastError="ROM load failed";
    return ok?JNI_TRUE:JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetSurface(JNIEnv* env, jobject, jobject surf) {
    // Hold G.mu so the emu thread never reads G.window/G.egl mid-update.
    std::lock_guard<std::mutex> lk(G.mu);
    if (surf){
        G.window=ANativeWindow_fromSurface(env,surf);
        FL_INFO("[SURFACE] Set %p size=%dx%d",G.window,
            ANativeWindow_getWidth(G.window),ANativeWindow_getHeight(G.window));
        // If emu thread is already running but EGL never got a window,
        // the main loop's (!egl.ok && window) check will init EGL next frame.
        if (G.running && !G.egl.ok)
            FL_INFO("[SURFACE] Thread running, no EGL yet — loop will init on next frame");
    } else {
        FL_INFO("[SURFACE] Cleared — destroying EGL surface");
        eglDestroy(G.egl);
        if (G.window) { ANativeWindow_release(G.window); }
        G.window=nullptr;
    }
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeStart(JNIEnv*, jobject) {
    FL_INFO("[START] running=%d window=%p gba=%p",
        G.running.load(),G.window,G.gba.get());
    if (G.running){FL_WARN("[START] Already running"); return;}
    if (!G.window) FL_WARN("[START] No surface yet — rendering may fail");
    if (!G.gba)   {FL_ERROR("[START] GBA null!"); return;}
    G.running=true; G.paused=false;
    G.frameCount=0; G.renderCount=0;
    G.emuThread=std::thread(emuLoop);
    FL_INFO("[START] Thread launched");
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeStop(JNIEnv*, jobject) {
    FL_INFO("[STOP] frames=%d renders=%d",G.frameCount.load(),G.renderCount.load());
    G.running=false;
    if (G.emuThread.joinable()){G.emuThread.join(); FL_INFO("[STOP] Thread joined");}
    if (g_logFile){fflush(g_logFile); fclose(g_logFile); g_logFile=nullptr;}
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativePause(JNIEnv*, jobject, jboolean p) {
    G.paused=(p==JNI_TRUE);
    FL_INFO("[PAUSE] %d",G.paused.load());
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetKeys(JNIEnv*, jobject, jint keys) {
    // Write to atomic — NO mutex. G.mu is held for an entire frame (~16ms) by
    // the emu thread. Blocking the UI thread here causes ANR crashes and
    // button-press freezes. The emu thread reads pendingKeys at the top of each
    // frame loop instead, which is safe via relaxed atomics.
    G.pendingKeys.store((uint16_t)(~keys & 0x03FF), std::memory_order_relaxed);
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeReset(JNIEnv*, jobject) {
    FL_INFO("[RESET]");
    std::lock_guard<std::mutex> lk(G.mu);
    if (G.gba){
        G.gba->cpu.reset();
        G.frameCount=0; G.renderCount=0;
        FL_INFO("[RESET] PC=0x%08X",G.gba->cpu.r[15]);
    }
}

// Returns a multi-line debug string for the on-screen overlay
JNIEXPORT jstring JNICALL
Java_com_customgba_EmulatorCore_nativeGetDebugInfo(JNIEnv* env, jobject) {
    std::ostringstream ss;

    // ── Section 1: ROM + System ───────────────────────────────────────────────
    ss << "─── GBA DEBUG ───\n";
    ss << "ROM : ";
    if (g_dbg.romLoaded)
        ss << g_dbg.romTitle << "/" << g_dbg.romCode
           << " " << (g_dbg.romSize/1024) << "KB "
           << (g_dbg.romLogoOK?"LOGO:OK":"LOGO:FAIL");
    else ss << "NOT LOADED";
    ss << "\n";
    ss << "EGL:" << (g_dbg.eglOK?"OK":"FAIL")
       << " Audio:" << (g_dbg.audioOK?"OK":"FAIL")
       << " GL:" << g_dbg.glRenderer << "\n";

    // ── Section 2: Frames + VBlanks ──────────────────────────────────────────
    ss << "Frames:" << g_dbg.frames
       << " Rndr:"  << g_dbg.renders
       << " VBL:"   << g_dbg.vblankCount << "\n";

    // ── Section 3: CPU ────────────────────────────────────────────────────────
    ss << "PC:0x" << std::hex << std::setw(8) << std::setfill('0') << g_dbg.cpuPC;
    ss << " " << ((g_dbg.cpsr & (1<<5)) ? "THUMB" : "ARM  ");
    ss << " I:" << ((g_dbg.cpsr & (1<<7)) ? "mask" : "on  ");
    ss << " " << (g_dbg.cpuHalted ? "[HALT]" : "[RUN] ") << "\n";
    ss << "CPSR:0x" << std::hex << std::setw(8) << std::setfill('0') << g_dbg.cpsr
       << " mode=0x" << std::hex << (g_dbg.cpsr & 0x1F) << std::dec << "\n";

    // ── Section 4: PPU ────────────────────────────────────────────────────────
    bool fblank = (g_dbg.dispcnt >> 7) & 1;
    ss << "DISPCNT:0x" << std::hex << std::setw(4) << std::setfill('0') << g_dbg.dispcnt;
    ss << " mode=" << (g_dbg.dispcnt & 7);
    ss << (fblank ? " [FBLANK!]" : " [ACTIVE]") << "\n";
    ss << "DISPSTAT:0x" << std::hex << std::setw(4) << std::setfill('0') << g_dbg.dispstat
       << " vcount=" << std::dec << g_dbg.vcount << "\n";

    // ── Section 5: IRQ ────────────────────────────────────────────────────────
    ss << "IE:0x"  << std::hex << std::setw(4) << std::setfill('0') << g_dbg.regIE;
    ss << " IF:0x" << std::hex << std::setw(4) << std::setfill('0') << g_dbg.regIF;
    ss << " IME:" << (g_dbg.regIME & 1 ? "ON" : "off") << "\n";
    ss << "IRQ_VEC:0x" << std::hex << std::setw(8) << std::setfill('0') << g_dbg.irqVecAddr;
    ss << " IRQs:" << std::dec << g_dbg.irqCount << "\n";

    // ── Section 6: SWI history ────────────────────────────────────────────────
    ss << "SWIs:" << g_dbg.swiCount << " last:0x"
       << std::hex << g_dbg.lastSWI << std::dec;
    // Flag unknown SWI (not in our known set) for easy visibility
    bool knownSwi = false;
    static const u32 KNOWN[] = {0,1,2,3,4,5,6,7,8,9,0xA,0xB,0xC,0xD,0xE,
        0x10,0x11,0x12,0x13,0x14,0x15,0x19,0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,
        0x26,0x27,0x28,0x29,0x2A,0x62,0x63,0x64,0x65,0x66,0x67,0x68,0x69,
        0x6A,0x6B,0x6C,0x6D,0x6E,0x6F,0xFF};
    for (auto k : KNOWN) { if (g_dbg.lastSWI == k) { knownSwi=true; break; } }
    if (!knownSwi && g_dbg.lastSWI != 0xFF) ss << " [UNKNOWN_SWI!]";
    ss << "\n";
    ss << "SWI hist:";
    for (int i=0; i<DebugStatus::SWI_LOG_SIZE; i++)
        ss << "0x" << std::hex << g_dbg.swiLog[i] << " ";
    ss << std::dec << "\n";

    // ── Section 7: Direct Sound FIFO ─────────────────────────────────────────
    ss << "── FIFO (Direct Sound) ──\n";
    ss << "MemWrites A:" << g_dbg.memFifoAWrites << " B:" << g_dbg.memFifoBWrites << "\n";
    ss << "FIFO-A  fill:" << g_dbg.fifoACount
       << " push:" << g_dbg.fifoAPushes
       << " pop:"  << g_dbg.fifoAPops
       << " ovfl:" << g_dbg.fifoAOverflows
       << " dmaReq:" << g_dbg.fifoADmaReqs << "\n";
    ss << "       tmr:"  << g_dbg.fifoATimer
       << " L:" << g_dbg.fifoALeft << " R:" << g_dbg.fifoARight
       << " vol:" << g_dbg.fifoAVol;
    if (g_dbg.fifoAPushes == 0) ss << " [NO DATA — DMA not filling!]";
    ss << "\n";
    ss << "FIFO-B  fill:" << g_dbg.fifoBCount
       << " push:" << g_dbg.fifoBPushes
       << " pop:"  << g_dbg.fifoBPops
       << " ovfl:" << g_dbg.fifoBOverflows
       << " dmaReq:" << g_dbg.fifoBDmaReqs << "\n";
    ss << "       tmr:"  << g_dbg.fifoBTimer
       << " L:" << g_dbg.fifoBLeft << " R:" << g_dbg.fifoBRight
       << " vol:" << g_dbg.fifoBVol;
    if (g_dbg.fifoBPushes == 0) ss << " [NO DATA — DMA not filling!]";
    ss << "\n";

    // ── Section 8: Timers ─────────────────────────────────────────────────────
    ss << "── Timers ──\n";
    for (int i = 0; i < 4; i++) {
        ss << "T" << i << ":"
           << (g_dbg.timerEnabled[i] ? "ON " : "off")
           << " cnt:0x" << std::hex << std::setw(4) << std::setfill('0') << g_dbg.timerCounters[i]
           << " rld:0x" << std::setw(4) << g_dbg.timerReloads[i]
           << " ovfl:"  << std::dec << g_dbg.timerOverflows[i] << "\n";
    }
    // Estimate sample rate from timer driving FIFO-A
    {
        int ta = g_dbg.fifoATimer;
        if (g_dbg.timerEnabled[ta] && g_dbg.timerReloads[ta] > 0) {
            // Timer ticks at GBA_CPU_HZ / prescaler.  reload=0xFFFF-N means
            // overflow every (0x10000-reload) prescaler ticks.
            int period = 0x10000 - g_dbg.timerReloads[ta];
            if (period > 0) {
                int estHz = GBA_CPU_HZ / period;
                ss << "Est FIFO-A sample rate: ~" << estHz << " Hz\n";
            }
        }
    }

    // ── Section 9: Thread / Log status ───────────────────────────────────────
    ss << "Thread:" << (G.running ? "ALIVE" : "DEAD")
       << " Paused:" << (G.paused ? "YES" : "NO") << "\n";
    if (!g_dbg.lastError.empty())
        ss << "ERR:" << g_dbg.lastError << "\n";
    if (g_logFile) {
        auto pos = g_logPath.rfind('/');
        ss << "Log:" << g_logPath.substr(pos==std::string::npos?0:pos+1);
    }
    return env->NewStringUTF(ss.str().c_str());
}

Java_com_customgba_EmulatorCore_nativeSaveState(JNIEnv* env, jobject, jstring jpath) {
    const char* path=env->GetStringUTFChars(jpath,nullptr);
    std::lock_guard<std::mutex> lk(G.mu);
    if (!G.gba){env->ReleaseStringUTFChars(jpath,path); return JNI_FALSE;}
    std::ofstream f(path,std::ios::binary);
    f.write((char*)G.gba->cpu.r,     sizeof(G.gba->cpu.r));
    f.write((char*)&G.gba->cpu.cpsr, 4);
    f.write((char*)&G.gba->cpu.spsr, 4);
    f.write((char*)G.gba->mem.ewram, EWRAM_SIZE);
    f.write((char*)G.gba->mem.iwram, IWRAM_SIZE);
    f.write((char*)G.gba->mem.io,    IO_SIZE);
    f.write((char*)G.gba->mem.pal,   PAL_SIZE);
    f.write((char*)G.gba->mem.vram,  VRAM_SIZE);
    f.write((char*)G.gba->mem.oam,   OAM_SIZE);
    env->ReleaseStringUTFChars(jpath,path);
    bool ok=f.good(); FL_INFO("[STATE] Save %s",ok?"OK":"FAILED");
    return ok?JNI_TRUE:JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeLoadState(JNIEnv* env, jobject, jstring jpath) {
    const char* path=env->GetStringUTFChars(jpath,nullptr);
    std::lock_guard<std::mutex> lk(G.mu);
    if (!G.gba){env->ReleaseStringUTFChars(jpath,path); return JNI_FALSE;}
    std::ifstream f(path,std::ios::binary);
    f.read((char*)G.gba->cpu.r,      sizeof(G.gba->cpu.r));
    f.read((char*)&G.gba->cpu.cpsr,  4);
    f.read((char*)&G.gba->cpu.spsr,  4);
    f.read((char*)G.gba->mem.ewram,  EWRAM_SIZE);
    f.read((char*)G.gba->mem.iwram,  IWRAM_SIZE);
    f.read((char*)G.gba->mem.io,     IO_SIZE);
    f.read((char*)G.gba->mem.pal,    PAL_SIZE);
    f.read((char*)G.gba->mem.vram,   VRAM_SIZE);
    f.read((char*)G.gba->mem.oam,    OAM_SIZE);
    env->ReleaseStringUTFChars(jpath,path);
    bool ok=f.good();
    FL_INFO("[STATE] Load %s PC=0x%08X",ok?"OK":"FAILED",G.gba->cpu.r[15]);
    return ok?JNI_TRUE:JNI_FALSE;
}

} // extern "C"
