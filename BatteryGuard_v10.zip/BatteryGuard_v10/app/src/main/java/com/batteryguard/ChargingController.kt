package com.batteryguard

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object ChargingController {

    private const val TAG = "ChargingController"

    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",
        "/sys/class/power_supply/battery/input_suspend",
        "/sys/class/power_supply/batt_drv/charge_disable",
        "/sys/class/power_supply/battery/stop_charging",
        "/sys/class/power_supply/battery/inhibit_charge",
        "/sys/class/power_supply/battery/charge_control_limit_max"
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    // Single-thread executor so charging commands never run concurrently
    private val executor = Executors.newSingleThreadExecutor()

    fun availableMethod(): Method = when {
        isRooted()         -> Method.ROOT
        isShizukuGranted() -> Method.SHIZUKU
        else               -> Method.NONE
    }

    /** Fires off a disable command in the background; callback on result. */
    fun disableCharging(onResult: (Boolean) -> Unit = {}) {
        executor.submit {
            onResult(runCmd(buildCmd(enable = false)))
        }
    }

    /** Fires off an enable command in the background; callback on result. */
    fun enableCharging(onResult: (Boolean) -> Unit = {}) {
        executor.submit {
            onResult(runCmd(buildCmd(enable = true)))
        }
    }

    private fun buildCmd(enable: Boolean): String {
        val v    = if (enable) "1" else "0"
        val cmds = mutableListOf<String>()
        for (node in CHARGING_NODES) {
            cmds += "[ -f $node ] && echo $v > $node || true"
        }
        if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
        else        cmds += "dumpsys battery set status 1 2>/dev/null || true"
        return cmds.joinToString(" ; ")
    }

    private fun runCmd(cmd: String): Boolean {
        return when (availableMethod()) {
            Method.ROOT    -> execRoot(cmd)
            Method.SHIZUKU -> execShizuku(cmd)
            Method.NONE    -> false
        }
    }

    // ── Root ──────────────────────────────────────────────────────────────────

    private fun execRoot(cmd: String): Boolean {
        return try {
            Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
        } catch (e: Exception) {
            Log.e(TAG, "root exec failed: ${e.message}")
            false
        }
    }

    // ── Shizuku UserService ───────────────────────────────────────────────────

    /**
     * Binds ChargeService via Shizuku on a background thread (never the main looper),
     * so CountDownLatch.await() can't deadlock waiting for onServiceConnected.
     */
    private fun execShizuku(cmd: String): Boolean {
        var result = false
        val latch  = CountDownLatch(1)

        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                try {
                    val exitCode = IChargeService.Stub.asInterface(binder).exec(cmd)
                    result = (exitCode == 0)
                    Log.d(TAG, "shizuku exec exit=$exitCode")
                } catch (e: Exception) {
                    Log.e(TAG, "shizuku call failed: ${e.message}")
                } finally {
                    try { Shizuku.unbindUserService(ChargeService.ARGS, this, true) } catch (_: Exception) {}
                    latch.countDown()
                }
            }
            override fun onServiceDisconnected(name: ComponentName) {
                latch.countDown()
            }
        }

        return try {
            Shizuku.bindUserService(ChargeService.ARGS, conn)
            latch.await(15, TimeUnit.SECONDS)
            result
        } catch (e: Exception) {
            Log.e(TAG, "shizuku bind failed: ${e.message}")
            false
        }
    }

    // ── Detection ─────────────────────────────────────────────────────────────

    fun isShizukuAvailable(): Boolean =
        try { Shizuku.pingBinder() } catch (_: Exception) { false }

    fun isShizukuGranted(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }

    fun isRooted(): Boolean = listOf(
        "/system/bin/su", "/system/xbin/su",
        "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
    ).any { File(it).exists() }
}
