package com.batteryguard

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors

class BatteryService : Service() {

    companion object {
        const val CHANNEL_PERSISTENT = "bg_persistent"
        const val CHANNEL_ALERT      = "bg_alert"
        const val NOTIF_PERSISTENT   = 1
        const val NOTIF_ALERT        = 2
        const val ACTION_UPDATE_UI   = "com.batteryguard.UPDATE_UI"
        private const val POLL_MS    = 5_000L
    }

    private var batteryReceiver: BroadcastReceiver? = null
    private var lastAlertPercent = -1

    // Single background thread for all charging commands — never blocks the main thread
    private val chargeExecutor = Executors.newSingleThreadExecutor()

    private val handler = Handler(Looper.getMainLooper())
    private val pollRunnable = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, POLL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_PERSISTENT, buildPersistentNotif("Monitoring battery…", 0),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_PERSISTENT, buildPersistentNotif("Monitoring battery…", 0))
        }
        registerBatteryReceiver()
        handler.post(pollRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(pollRunnable)
        chargeExecutor.shutdown()
        batteryReceiver?.let { unregisterReceiver(it) }
    }

    private fun tick(): Unit {
        // UI + notification updates stay on main thread — fast, no blocking
        val info      = PowerReader.read(this)
        val threshold = getSharedPreferences("settings", MODE_PRIVATE).getInt("threshold", 100)

        val wStr      = if (info.watts >= 0.05) " · ${info.wattsStr}" else ""
        val statusStr = if (info.isCharging) "Charging" else "On Battery"
        updatePersistentNotif("${info.percent}%  ·  $statusStr$wStr", info.percent)
        sendBroadcast(Intent(ACTION_UPDATE_UI))

        // Charging commands go to background thread — Shizuku binder calls block, never deadlock
        if (info.isCharging && info.percent >= threshold && lastAlertPercent != info.percent) {
            lastAlertPercent = info.percent
            chargeExecutor.execute { handleThresholdReached(info); Unit }
        } else if (!info.isCharging && info.percent < threshold - 5 && lastAlertPercent != -1) {
            // Charger still plugged in but charging was stopped — re-enable once battery dips
            lastAlertPercent = -1
            chargeExecutor.execute { ChargingController.enableCharging(); Unit }
        }
    }

    private fun registerBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                handler.removeCallbacks(pollRunnable)
                tick()
                handler.postDelayed(pollRunnable, POLL_MS)
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun handleThresholdReached(info: PowerReader.PowerInfo): Unit {
        // Already on background thread — safe to call blocking Shizuku binder
        val wStr    = if (info.watts >= 0.05) " (${info.wattsStr})" else ""
        val success = ChargingController.disableCharging()
        val method  = ChargingController.availableMethod()
        if (success) {
            sendAlert(
                "🔋 Charging stopped at ${info.percent}%$wStr",
                "Battery Guard automatically stopped charging to protect your battery life.",
                loud = false
            )
        } else if (method == ChargingController.Method.NONE) {
            sendAlert(
                "⚠️ Battery full at ${info.percent}%$wStr — Unplug now!",
                "Please unplug your charger. Enable root or Shizuku for automatic control.",
                loud = true
            )
        } else {
            sendAlert(
                "⚠️ Limit reached at ${info.percent}%",
                "Auto-stop attempted but failed. Please unplug manually.",
                loud = true
            )
        }
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PERSISTENT, "Battery Monitor", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Shows live battery status" }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Charging Alerts", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = "Alerts when charging threshold is reached"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 400, 150, 400, 150, 400)
                }
        )
    }

    private fun buildPersistentNotif(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_PERSISTENT)
            .setContentTitle("Battery Guard")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(100, progress, false)
            .build()
    }

    private fun updatePersistentNotif(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_PERSISTENT, buildPersistentNotif(text, progress))
    }

    private fun sendAlert(title: String, body: String, loud: Boolean) {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)

        if (loud) {
            val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(sound)
            builder.setVibrate(longArrayOf(0, 600, 200, 600, 200, 600))
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 200, 600), -1))
            }
        }
        getSystemService(NotificationManager::class.java).notify(NOTIF_ALERT, builder.build())
    }
}
