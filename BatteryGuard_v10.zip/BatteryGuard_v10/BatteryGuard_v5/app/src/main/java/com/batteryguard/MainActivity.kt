package com.batteryguard

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.batteryguard.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Called by Shizuku after the user taps Allow/Deny in the Shizuku app
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Shizuku authorized ✓", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Shizuku permission denied", Toast.LENGTH_SHORT).show()
        }
        refreshPrivilegeCard()
    }

    private val uiReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            refreshBatteryCard()
            refreshPrivilegeCard()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)

        requestNotifPermission()
        setupThresholdSlider()
        setupButtons()
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(uiReceiver, IntentFilter(BatteryService.ACTION_UPDATE_UI), RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(uiReceiver, IntentFilter(BatteryService.ACTION_UPDATE_UI))
        }
        refreshBatteryCard()
        refreshPrivilegeCard()
        refreshServiceState()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(uiReceiver) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    private fun setupButtons() {
        binding.btnStart.setOnClickListener   { startGuard() }
        binding.btnStop.setOnClickListener    { stopGuard()  }
        binding.btnShizuku.setOnClickListener {
            when {
                !ChargingController.isShizukuAvailable() -> {
                    Toast.makeText(this,
                        "Shizuku not running — install & start the Shizuku app first",
                        Toast.LENGTH_LONG).show()
                }
                ChargingController.isShizukuGranted() -> {
                    Toast.makeText(this, "Shizuku is already authorized ✓", Toast.LENGTH_SHORT).show()
                }
                else -> {
                    // Triggers the Allow/Deny dialog inside the Shizuku app
                    Shizuku.requestPermission(1001)
                }
            }
        }
    }

    private fun startGuard() {
        val i = Intent(this, BatteryService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i)
        else startService(i)
        prefs().edit().putBoolean("service_running", true).apply()
        refreshServiceState()
        Toast.makeText(this, "Battery Guard started", Toast.LENGTH_SHORT).show()
    }

    private fun stopGuard() {
        stopService(Intent(this, BatteryService::class.java))
        prefs().edit().putBoolean("service_running", false).apply()
        refreshServiceState()
        Toast.makeText(this, "Service stopped", Toast.LENGTH_SHORT).show()
    }

    private fun setupThresholdSlider() {
        val saved = prefs().getInt("threshold", 100)
        binding.seekbarThreshold.progress = saved - 80
        binding.tvThresholdValue.text = "$saved%"
        binding.seekbarThreshold.setOnSeekBarChangeListener(
            object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, u: Boolean) {
                    val t = 80 + p
                    binding.tvThresholdValue.text = "$t%"
                    prefs().edit().putInt("threshold", t).apply()
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
    }

    private fun refreshBatteryCard() {
        val info = PowerReader.read(this)

        binding.tvBatteryPercent.text = "${info.percent}%"
        binding.progressBattery.progress = info.percent

        val colorRes = when {
            info.percent >= 80 -> android.R.color.holo_green_light
            info.percent >= 40 -> android.R.color.holo_orange_light
            else               -> android.R.color.holo_red_light
        }
        val color = ContextCompat.getColor(this, colorRes)
        binding.tvBatteryPercent.setTextColor(color)
        binding.progressBattery.progressTintList =
            android.content.res.ColorStateList.valueOf(color)

        binding.tvChargingStatus.text = when {
            info.isCharging && info.percent >= 100 -> "🔋 Full"
            info.isCharging                         -> "⚡ Charging"
            else                                    -> "🔋 On Battery"
        }

        // Watts row: show direction arrow + watt, current, voltage
        binding.tvWatts.text = when {
            info.isCharging && info.watts >= 0.05 ->
                "▲ ${info.wattsStr}  ·  ${info.currentStr}  ·  ${info.voltageStr}"
            !info.isCharging && info.watts >= 0.05 ->
                "▼ ${info.wattsStr}  ·  ${info.currentStr}  ·  ${info.voltageStr}"
            else ->
                info.voltageStr
        }
    }

    private fun refreshPrivilegeCard() {
        val method       = ChargingController.availableMethod()
        val shizukuAvail = ChargingController.isShizukuAvailable()

        when (method) {
            ChargingController.Method.ROOT -> {
                binding.tvPrivilegeStatus.text = "✓ Root — auto-control active"
                binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.SHIZUKU -> {
                binding.tvPrivilegeStatus.text = "✓ Shizuku — auto-control active"
                binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
                binding.btnShizuku.visibility = View.GONE
            }
            ChargingController.Method.NONE -> {
                if (shizukuAvail) {
                    binding.tvPrivilegeStatus.text = "Shizuku running but not authorized yet"
                    binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_light))
                    binding.btnShizuku.text = "How to authorize"
                } else {
                    binding.tvPrivilegeStatus.text = "No root / Shizuku — alert-only mode"
                    binding.tvPrivilegeStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_light))
                    binding.btnShizuku.text = "How to set up Shizuku"
                }
                binding.btnShizuku.visibility = View.VISIBLE
            }
        }
    }

    private fun refreshServiceState() {
        val running = prefs().getBoolean("service_running", false)
        binding.tvServiceStatus.text = if (running) "Active" else "Stopped"
        val color = if (running)
            ContextCompat.getColor(this, android.R.color.holo_green_light)
        else
            ContextCompat.getColor(this, android.R.color.holo_red_light)
        binding.tvServiceStatus.setTextColor(color)
        binding.btnStart.isEnabled = !running
        binding.btnStop.isEnabled  = running
    }

    private fun prefs() = getSharedPreferences("settings", MODE_PRIVATE)

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}
