package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.mangatool.app.adapter.AppPickerAdapter
import com.mangatool.app.adapter.AppPickerItem
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetAppPickerBinding
import com.mangatool.app.databinding.BottomSheetSavedBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.ImageSaver
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var chapterTouchHelper: ItemTouchHelper? = null
    private var processingJob: Job? = null

    // ── File pickers ───────────────────────────────────────────────────────────
    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data) }

    private val getContentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data) }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, getString(R.string.permission_storage_needed), Toast.LENGTH_LONG).show()
    }

    private val mergePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uriStrings = result.data?.getStringArrayListExtra(MergeImagePickerActivity.RESULT_URIS)
            val uris = uriStrings?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() } ?: emptyList()
            if (uris.isNotEmpty()) processFiles(uris)
        }
    }

    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) { AppState.applyFilters(); refreshChapterList() }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.init(this)
        AppState.minSizeKb    = Prefs.minSizeKb
        AppState.excludeGifs  = Prefs.excludeGifs
        AppState.reverseOrder = Prefs.reverseOrder
        setupTabs()
        setupControls()
        setupActionBar()
        setupDragToReorder()
        applyMode(AppMode.EXTRACT)
        handleIncomingShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingShareIntent(intent)
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        AppState.trimThumbCache(level)
    }

    override fun onDestroy() {
        processingJob?.cancel()
        super.onDestroy()
    }

    // ── Share intent handler ───────────────────────────────────────────────────
    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val uris = mutableListOf<Uri>()
        when (intent.action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uris.add(it) }
            }
            Intent.ACTION_SEND -> {
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }
        if (uris.isNotEmpty()) { processFiles(uris); setIntent(Intent(Intent.ACTION_MAIN)) }
    }

    // ── Tabs ───────────────────────────────────────────────────────────────────
    private fun setupTabs() {
        b.tabExtract.setOnClickListener { applyMode(AppMode.EXTRACT) }
        b.tabMerge.setOnClickListener   { applyMode(AppMode.MERGE) }
    }

    private fun applyMode(mode: AppMode) {
        AppState.currentMode = mode
        val active   = 0xFFFFFFFF.toInt()
        val inactive = 0xFF8B949E.toInt()
        if (mode == AppMode.EXTRACT) {
            b.tabExtract.setBackgroundResource(R.drawable.bg_tab_active)
            b.tabExtract.setTextColor(active)
            b.tabMerge.setBackgroundResource(android.R.color.transparent)
            b.tabMerge.setTextColor(inactive)
        } else {
            b.tabMerge.setBackgroundResource(R.drawable.bg_tab_active)
            b.tabMerge.setTextColor(active)
            b.tabExtract.setBackgroundResource(android.R.color.transparent)
            b.tabExtract.setTextColor(inactive)
        }
        b.settingsToggle.visibility = if (mode == AppMode.EXTRACT) View.VISIBLE else View.GONE
        if (mode != AppMode.EXTRACT) b.settingsPanel.visibility = View.GONE
        AppState.applyFilters()
        refreshChapterList()
    }

    // ── Controls ───────────────────────────────────────────────────────────────
    private fun setupControls() {
        b.settingsToggle.setOnClickListener {
            val v = b.settingsPanel
            v.visibility = if (v.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; Prefs.minSizeKb = v; updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.applyFilters(); refreshChapterList() }
        })
        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder
        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;  Prefs.excludeGifs = c;  AppState.applyFilters(); refreshChapterList() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c; Prefs.reverseOrder = c; AppState.applyFilters(); refreshChapterList() }
        b.dropZone.setOnClickListener { showFileManagerChooser() }
        b.chapterList.layoutManager = LinearLayoutManager(this)
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener  { showFileManagerChooser() }
        // Merge: primary = "Save as Images"; Extract: primary = "Save as Folder"
        b.btnDownload.setOnClickListener { startSave(asCbz = false) }
        // Extract: secondary CBZ button
        b.btnSaveCbz.setOnClickListener  { startSave(asCbz = true) }
        // Share without saving
        b.btnShareDirect.setOnClickListener { startShareDirect() }
        b.btnViewAll.setOnClickListener  { openAllPhotos() }
        b.btnReset.setOnClickListener {
            chapterAdapter?.destroy(); chapterAdapter = null
            b.chapterList.adapter = null
            AppState.reset(); refreshChapterList()
        }
    }

    private fun setupDragToReorder() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                val f = from.adapterPosition; val t = to.adapterPosition
                if (f < 0 || t < 0) return false
                Collections.swap(AppState.groups, f, t)
                chapterAdapter?.notifyItemMoved(f, t)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
            override fun isLongPressDragEnabled() = false
        }
        chapterTouchHelper = ItemTouchHelper(callback).also { it.attachToRecyclerView(b.chapterList) }
    }

    private fun updateSizeLabel() {
        b.sizeLabel.text = getString(R.string.size_kb, AppState.minSizeKb)
    }

    // ── Refresh UI ─────────────────────────────────────────────────────────────
    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        val isMerge   = AppState.currentMode == AppMode.MERGE

        b.dropZone.visibility    = if (hasGroups) View.GONE else View.VISIBLE
        b.chapterList.visibility = if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility   = if (hasGroups) View.VISIBLE else View.GONE
        b.mergeTip.visibility    = if (isMerge && hasGroups) View.VISIBLE else View.GONE

        // Button layout depends on mode
        if (hasGroups) {
            if (isMerge) {
                // Merge: "Save as Images" primary, no CBZ button, share direct visible
                b.btnDownload.text = "💾 Save Images"
                b.btnSaveCbz.visibility = View.GONE
            } else {
                // Extract: "Save as Folder" primary + "CBZ" secondary
                b.btnDownload.text = "📁 Save Folder"
                b.btnSaveCbz.visibility = View.VISIBLE
                b.btnSaveCbz.text = "CBZ"
            }
        }

        if (isMerge && hasGroups) {
            val totalImages = AppState.groups.sumOf { it.displayImages.size }
            val pairs = (totalImages + 1) / 2
            b.mergeImageCount.text = getString(R.string.merge_image_count, totalImages, pairs)
        }

        b.btnAddMore.text = if (isMerge) getString(R.string.btn_add_images) else getString(R.string.btn_add_more)

        if (hasGroups) {
            val totalImgs     = AppState.groups.sumOf { it.displayImages.size }
            val totalFiltered = AppState.groups.sumOf { it.filteredImages.size }
            val totalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
            val sizeStr       = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb} KB"
            b.statsText.text = if (isMerge) {
                val pairs = (totalImgs + 1) / 2
                getString(R.string.stats_merge, AppState.groups.size, totalImgs, pairs, sizeStr)
            } else {
                if (totalFiltered > 0)
                    getString(R.string.stats_extract_filtered, AppState.groups.size, totalImgs, sizeStr, totalFiltered)
                else
                    getString(R.string.stats_extract, AppState.groups.size, totalImgs, sizeStr)
            }
        }
    }

    private fun refreshChapterList() {
        chapterAdapter?.destroy()
        chapterAdapter = ChapterAdapter(
            groups            = AppState.groups,
            onImageClick      = { gIdx, iIdx ->
                val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, iIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == AppMode.MERGE)
                }
                previewLauncher.launch(intent)
            },
            onGroupRemove     = { idx -> AppState.groups.removeAt(idx); AppState.applyFilters(); refreshChapterList() },
            onImageLongClick  = { img -> img.userDeleted = true; img.forceKeep = false; AppState.applyFilters(); refreshChapterList() },
            onImageRestore    = { img -> img.forceKeep = true; img.userDeleted = false; AppState.applyFilters(); refreshChapterList() },
            onFilteredPreview = { gIdx, filtIdx ->
                val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, filtIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_FILTERED, true)
                }
                previewLauncher.launch(intent)
            },
            onBatchRestore    = { gIdx ->
                val group = AppState.groups.getOrNull(gIdx) ?: return@ChapterAdapter
                group.allImages.forEach { if (!it.userDeleted) it.forceKeep = true }
                AppState.applyFilters(); refreshChapterList()
                Toast.makeText(this, getString(R.string.toast_restored_all), Toast.LENGTH_SHORT).show()
            }
        )
        b.chapterList.adapter = chapterAdapter
        chapterAdapter?.touchHelper = chapterTouchHelper
        refreshUI()
    }

    // ── File manager chooser ───────────────────────────────────────────────────
    private fun showFileManagerChooser() {
        if (AppState.currentMode == AppMode.MERGE) {
            mergePickerLauncher.launch(Intent(this, MergeImagePickerActivity::class.java)); return
        }
        val pm = packageManager
        val probeGet = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val probeDoc = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        val blocked = setOf("com.android.providers.media", "com.android.providers.media.photopicker",
            "com.android.photopicker", "com.google.android.providers.media",
            "com.google.android.apps.nbu.files", packageName)
        val seen  = mutableSetOf<String>()
        val items = mutableListOf<AppPickerItem>()
        fun addApp(pkg: String, actName: String?, actionType: String) {
            if (pkg in blocked || !seen.add(pkg)) return
            runCatching {
                val info = pm.getApplicationInfo(pkg, 0)
                val icon = runCatching {
                    if (actName != null) pm.getActivityIcon(ComponentName(pkg, actName))
                    else pm.getApplicationIcon(info)
                }.getOrElse { pm.getApplicationIcon(info) }
                items.add(AppPickerItem(pm.getApplicationLabel(info).toString(), icon, pkg, actName, actionType))
            }
        }
        pm.queryIntentActivities(probeGet, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "GET_CONTENT") }
        pm.queryIntentActivities(probeDoc, 0).sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "OPEN_DOCUMENT") }
        listOf("ru.zdevs.zarchiver","com.amaze.filemanager","com.ghisler.android.TotalCommander",
            "com.estrongs.android.pop","nextapp.fx","com.cxinventor.file.explorer",
            "com.sec.android.app.myfiles","com.mi.android.globalFileExplorer",
            "com.asus.filemanager","com.coloros.filemanager","com.rhmsoft.fm")
            .forEach { pkg -> if (pm.getLaunchIntentForPackage(pkg) != null) addApp(pkg, null, "GET_CONTENT") }

        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet = BottomSheetAppPickerBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)
        sheet.tvPickerTitle.text = getString(R.string.picker_title)
        sheet.tvSubtitle.text   = getString(R.string.picker_subtitle)
        sheet.rvApps.layoutManager = GridLayoutManager(this, 4)
        sheet.rvApps.adapter = AppPickerAdapter(items) { item -> dialog.dismiss(); launchAppOrGuide(item) }
        sheet.tvCancel.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun launchAppOrGuide(item: AppPickerItem) {
        if (item.packageName == "ru.zdevs.zarchiver") {
            packageManager.getLaunchIntentForPackage("ru.zdevs.zarchiver")?.let {
                startActivity(it)
                Snackbar.make(b.root, getString(R.string.zarchiver_hint), Snackbar.LENGTH_LONG)
                    .setBackgroundTint(0xFF7C3AED.toInt()).setTextColor(0xFFFFFFFF.toInt()).show()
            }; return
        }
        val action = if (item.actionType == "OPEN_DOCUMENT") Intent.ACTION_OPEN_DOCUMENT else Intent.ACTION_GET_CONTENT
        val intent = Intent(action).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg","image/png","image/webp","image/gif",
                "multipart/related","message/rfc822","application/octet-stream"))
            addCategory(Intent.CATEGORY_OPENABLE)
            if (item.packageName != null && item.activityName != null)
                component = ComponentName(item.packageName, item.activityName)
            else if (item.packageName != null) setPackage(item.packageName)
        }
        val launcher = if (item.actionType == "OPEN_DOCUMENT") openDocLauncher else getContentLauncher
        runCatching { launcher.launch(intent) }.onFailure {
            runCatching {
                launcher.launch(Intent(action).apply {
                    type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (item.packageName != null) setPackage(item.packageName)
                })
            }.onFailure {
                getContentLauncher.launch(Intent.createChooser(
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"; putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); addCategory(Intent.CATEGORY_OPENABLE)
                    }, getString(R.string.picker_open_files)
                ))
            }
        }
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount).map { data.clipData!!.getItemAt(it).uri }
            data?.data != null     -> listOf(data.data!!)
            else                   -> emptyList()
        }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    // ── File processing ────────────────────────────────────────────────────────
    private fun processFiles(uris: List<Uri>) {
        processingJob?.cancel()
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility     = View.GONE
        b.actionBar.visibility    = View.GONE

        processingJob = lifecycleScope.launch {
            val looseImages  = mutableListOf<ImageItem>()
            var duplicateCount = 0

            uris.forEachIndexed { i, uri ->
                val uriStr = uri.toString()
                withContext(Dispatchers.Main) {
                    b.progressStatus.text  = getString(R.string.reading_file, i + 1, uris.size)
                    b.progressBar.progress = (i * 100) / uris.size
                }
                if (!AppState.seenUris.add(uriStr)) { duplicateCount++; return@forEachIndexed }

                val name  = getFileName(uri).lowercase()
                val data: ByteArray? = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull()
                }
                if (data == null) return@forEachIndexed

                when {
                    name.endsWith(".mhtml") || name.endsWith(".mht") -> {
                        val group = withContext(Dispatchers.IO) { MhtmlParser.parse(data, getFileName(uri)) }
                        if (group != null) AppState.groups.add(group)
                    }
                    name.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)")) -> {
                        val ext = name.substringAfterLast('.')
                        looseImages.add(ImageItem(looseImages.size, data, ext, data.size))
                    }
                }
            }

            if (looseImages.isNotEmpty()) {
                val groupNum = AppState.groups.size + 1
                val label = when {
                    AppState.currentMode == AppMode.MERGE ->
                        "Merge Group $groupNum (${looseImages.size} images)"
                    uris.size == 1 ->
                        getFileName(uris[0]).substringBeforeLast('.').ifBlank { "Images $groupNum" }
                    else ->
                        "Images $groupNum (${looseImages.size})"
                }
                AppState.groups.add(ImageGroup(label).also { it.allImages.addAll(looseImages) })
            }

            AppState.applyFilters()
            b.progressArea.visibility = View.GONE
            refreshChapterList()

            if (duplicateCount > 0) {
                Snackbar.make(b.root, getString(R.string.toast_duplicate_skipped, duplicateCount), Snackbar.LENGTH_SHORT)
                    .setBackgroundTint(0xFF21262D.toInt()).setTextColor(0xFFF0F6FC.toInt()).show()
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"
    }

    // ── Save flow ──────────────────────────────────────────────────────────────
    private fun startSave(asCbz: Boolean) {
        if (AppState.groups.isEmpty()) return
        checkWritePermission { showSaveDialog(asCbz) }
    }

    private fun showSaveDialog(asCbz: Boolean) {
        val isMerge   = AppState.currentMode == AppMode.MERGE
        val defaultName = if (AppState.groups.size == 1) AppState.groups[0].groupName else "Manga_Batch"

        val title = when {
            isMerge -> "Name your image folder"
            asCbz   -> "Save as CBZ archive"
            else    -> "Name your folder"
        }
        val hint = when {
            isMerge -> "Folder name for merged images"
            asCbz   -> "CBZ filename"
            else    -> "Folder name"
        }

        val input = EditText(this).apply {
            setText(defaultName); setSelection(0, defaultName.length)
            this.hint = hint; setPadding(48, 24, 48, 8)
        }

        AlertDialog.Builder(this).setTitle(title).setView(input)
            .setPositiveButton(getString(R.string.btn_save)) { _, _ ->
                val raw = input.text.toString().trim().replace(Regex("""[\\/:*?"<>|]"""), "_").ifBlank { defaultName }
                when {
                    isMerge -> performSaveMergeImages(raw)
                    asCbz   -> {
                        val name = if (raw.endsWith(".cbz", true)) raw else "$raw.cbz"
                        performSaveCbz(name)
                    }
                    else    -> performSaveFolder(raw)
                }
            }
            .setNegativeButton(getString(R.string.btn_cancel), null).show()
    }

    /** Extract mode → save as folder of individual image files */
    private fun performSaveFolder(folderName: String) {
        b.btnDownload.isEnabled   = false
        b.btnSaveCbz.isEnabled    = false
        b.progressArea.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.saveExtractAsFolder(
                    context    = this@MainActivity,
                    groups     = AppState.groups,
                    folderName = folderName,
                    onProgress = { p -> lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }}
                )
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    b.btnSaveCbz.isEnabled    = true
                    showSavedSheet(
                        title    = "Saved to Downloads/$folderName",
                        subtitle = "${result.uris.size} images  ·  ${result.folderName}",
                        shareUris = result.uris
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    b.btnSaveCbz.isEnabled    = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Extract mode → save as CBZ */
    private fun performSaveCbz(filename: String) {
        b.btnDownload.isEnabled   = false
        b.btnSaveCbz.isEnabled    = false
        b.progressArea.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                CbzCreator.create(
                    context    = this@MainActivity,
                    groups     = AppState.groups,
                    filename   = filename,
                    isMerge    = false,
                    onProgress = { p -> lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }}
                )
            }.onSuccess { uri ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    b.btnSaveCbz.isEnabled    = true
                    showSavedSheet(
                        title    = "Saved: $filename",
                        subtitle = "Downloads/$filename",
                        shareUris = listOf(uri)
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    b.btnSaveCbz.isEnabled    = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Merge mode → save as individual PNG images */
    private fun performSaveMergeImages(folderName: String) {
        b.btnDownload.isEnabled   = false
        b.progressArea.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.saveMergeAsImages(
                    context    = this@MainActivity,
                    groups     = AppState.groups,
                    folderName = folderName,
                    onProgress = { p -> lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }}
                )
            }.onSuccess { result ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    showSavedSheet(
                        title    = "Saved to Downloads/${result.folderName}",
                        subtitle = "${result.uris.size} merged images",
                        shareUris = result.uris
                    )
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(this@MainActivity, getString(R.string.toast_failed, e.message), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── Share directly (no save) ───────────────────────────────────────────────
    private fun startShareDirect() {
        if (AppState.groups.isEmpty()) return
        val isMerge = AppState.currentMode == AppMode.MERGE

        b.btnShareDirect.isEnabled = false
        b.progressArea.visibility  = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                ImageSaver.buildShareUris(
                    context    = this@MainActivity,
                    groups     = AppState.groups,
                    isMerge    = isMerge,
                    onProgress = { p -> lifecycleScope.launch(Dispatchers.Main) {
                        b.progressStatus.text  = p.message
                        b.progressBar.progress = p.percent
                    }}
                )
            }.onSuccess { uris ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility  = View.GONE
                    b.btnShareDirect.isEnabled = true
                    launchShareSheet(uris)
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility  = View.GONE
                    b.btnShareDirect.isEnabled = true
                    Toast.makeText(this@MainActivity, "Share failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun launchShareSheet(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val mime = if (uris.size == 1) "image/*" else "image/*"
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uris[0])
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = mime
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        startActivity(Intent.createChooser(intent, "Share images via…"))
    }

    // ── Saved bottom sheet ─────────────────────────────────────────────────────
    private fun showSavedSheet(title: String, subtitle: String, shareUris: List<Uri>) {
        val dialog = BottomSheetDialog(this, com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheet = BottomSheetSavedBinding.inflate(layoutInflater)
        dialog.setContentView(sheet.root)

        sheet.tvSavedTitle.text    = title
        sheet.tvSavedFilename.text = subtitle

        // Open in reader (only meaningful for single CBZ)
        sheet.btnOpenReader.visibility = if (shareUris.size == 1) View.VISIBLE else View.GONE
        sheet.btnOpenReader.setOnClickListener {
            dialog.dismiss()
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(shareUris[0], "application/x-cbz")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            runCatching { startActivity(intent) }.onFailure {
                Toast.makeText(this, "No CBZ reader installed", Toast.LENGTH_SHORT).show()
            }
        }

        // Share (files already saved)
        sheet.btnShare.setOnClickListener { dialog.dismiss(); launchShareSheet(shareUris) }

        // Done
        sheet.btnDone.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    // ── Misc ───────────────────────────────────────────────────────────────────
    private fun checkWritePermission(onGranted: () -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            onGranted()
        }
    }

    private fun openAllPhotos() {
        if (AppState.groups.isEmpty()) return
        startActivity(Intent(this, AllPhotosActivity::class.java))
    }
}
