package com.mangatool.app.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream

object ImageSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val uris: List<Uri>, val folderName: String)

    // ── Save merged images as individual PNGs in a named folder ───────────────
    fun saveMergeAsImages(
        context: Context,
        groups: List<ImageGroup>,
        folderName: String,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val uris = mutableListOf<Uri>()
        val safe = folderName.sanitize()

        var total = groups.sumOf { ImageMerger.pairImages(it.displayImages).size }
        if (total == 0) total = 1
        var done = 0

        groups.forEach { group ->
            val pairs = ImageMerger.pairImages(group.displayImages)
            pairs.forEachIndexed { i, pair ->
                onProgress(Progress(
                    "Merging ${group.groupName} (${i + 1}/${pairs.size})",
                    (done * 100) / total
                ))
                val swapped = group.pairSwaps.contains(i)
                val bm = ImageMerger.merge(pair, swapped) ?: run { done++; return@forEachIndexed }
                val bytes = bm.toPngBytes()
                bm.recycle()
                val filename = "${safe}_${(done + 1).toString().padStart(4, '0')}.png"
                val uri = savePngToDownloads(context, bytes, filename, safe)
                if (uri != null) uris.add(uri)
                done++
            }
        }

        onProgress(Progress("Done! ${uris.size} images saved", 100))
        return SaveResult(uris, safe)
    }

    // ── Save extracted images as a folder in Downloads ────────────────────────
    fun saveExtractAsFolder(
        context: Context,
        groups: List<ImageGroup>,
        folderName: String,
        onProgress: (Progress) -> Unit
    ): SaveResult {
        val uris = mutableListOf<Uri>()
        val safe = folderName.sanitize()

        val total = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
        var done = 0

        groups.forEach { group ->
            val groupSafe = group.groupName.sanitize()
            group.displayImages.forEachIndexed { i, img ->
                if (i % 10 == 0) onProgress(Progress(
                    "Saving ${group.groupName} (${i + 1}/${group.displayImages.size})",
                    (done * 100) / total
                ))
                val subfolder = if (groups.size > 1) "$safe/$groupSafe" else safe
                val filename = img.name  // already padded like 001.jpg
                val uri = saveBytesToDownloads(
                    context, img.data, filename,
                    mimeForExt(img.ext), subfolder
                )
                if (uri != null) uris.add(uri)
                done++
            }
        }

        onProgress(Progress("Done! ${uris.size} images saved", 100))
        return SaveResult(uris, safe)
    }

    // ── Write temp files to cache for share-without-saving ────────────────────
    /**
     * Writes all groups' images to app cache (NOT visible in gallery) and
     * returns a list of content:// URIs via FileProvider, suitable for
     * ACTION_SEND_MULTIPLE sharing to Facebook, WhatsApp, etc.
     */
    fun buildShareUris(
        context: Context,
        groups: List<ImageGroup>,
        isMerge: Boolean,
        onProgress: (Progress) -> Unit
    ): List<Uri> {
        val cacheDir = File(context.cacheDir, "share_temp").also {
            it.deleteRecursively(); it.mkdirs()
        }
        val uris = mutableListOf<Uri>()
        var idx = 0

        if (isMerge) {
            val total = groups.sumOf { ImageMerger.pairImages(it.displayImages).size }.coerceAtLeast(1)
            groups.forEach { group ->
                val pairs = ImageMerger.pairImages(group.displayImages)
                pairs.forEachIndexed { i, pair ->
                    onProgress(Progress("Preparing ${i + 1}/$total…", (idx * 100) / total))
                    val swapped = group.pairSwaps.contains(i)
                    val bm = ImageMerger.merge(pair, swapped) ?: run { idx++; return@forEachIndexed }
                    val bytes = bm.toPngBytes(); bm.recycle()
                    val file = File(cacheDir, "${(idx + 1).toString().padStart(4, '0')}.png")
                    file.writeBytes(bytes)
                    uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                    idx++
                }
            }
        } else {
            val total = groups.sumOf { it.displayImages.size }.coerceAtLeast(1)
            groups.forEach { group ->
                group.displayImages.forEach { img ->
                    if (idx % 10 == 0) onProgress(Progress("Preparing ${idx + 1}/$total…", (idx * 100) / total))
                    val file = File(cacheDir, "${(idx + 1).toString().padStart(4, '0')}.${img.ext}")
                    file.writeBytes(img.data)
                    uris.add(FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file))
                    idx++
                }
            }
        }

        onProgress(Progress("Ready to share", 100))
        return uris
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun savePngToDownloads(ctx: Context, bytes: ByteArray, filename: String, subfolder: String): Uri? =
        saveBytesToDownloads(ctx, bytes, filename, "image/png", subfolder)

    private fun saveBytesToDownloads(
        ctx: Context, bytes: ByteArray, filename: String,
        mime: String, subfolder: String
    ): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relPath = "${Environment.DIRECTORY_DOWNLOADS}/$subfolder"
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, filename)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, relPath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
            runCatching {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                cv.clear(); cv.put(MediaStore.Downloads.IS_PENDING, 0)
                ctx.contentResolver.update(uri, cv, null, null)
            }
            uri
        } else {
            val dir = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                subfolder
            ).also { it.mkdirs() }
            val file = File(dir, filename)
            runCatching { file.writeBytes(bytes) }
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        }
    }

    private fun mimeForExt(ext: String) = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/*"
    }

    private fun Bitmap.toPngBytes(): ByteArray {
        val out = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.PNG, 0, out)
        return out.toByteArray()
    }

    private fun String.sanitize() =
        replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "MIE_Export" }
}
