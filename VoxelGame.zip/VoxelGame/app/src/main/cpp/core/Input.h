#pragma once
#include "MathUtils.h"
#include <mutex>
#include <atomic>

enum class ButtonId {
    NONE, JUMP, PLACE, BREAK, SETTINGS_PLUS
};

struct TouchPointer {
    int   id       = -1;
    float startX   = 0, startY = 0;
    float currentX = 0, currentY = 0;
    bool  active   = false;
};

class Input {
public:
    static constexpr int   MAX_TOUCH  = 10;
    static constexpr float JOY_RADIUS = 90.f;
    static constexpr float BTN_RADIUS = 65.f;

    void setScreenSize(float w, float h);

    // Called from UI thread
    void onTouchDown(int id, float x, float y);
    void onTouchMove(int id, float x, float y);
    void onTouchUp  (int id, float x, float y);

    // Called from GL thread — thread-safe snapshots
    Vec3  getMovement()   const;
    float consumeDX();   // resets after read
    float consumeDY();

    bool isJumpPressed()     const { return jumpPressed.load();  }
    bool isPlacePressed()    const { return placePressed.load(); }
    bool isBreakHeld()       const { return breakHeld.load();    }
    bool isSettingsPlusTap() const { return settingsPlusTap.load(); }

    void clearActions() {
        jumpPressed.store(false);
        placePressed.store(false);
        settingsPlusTap.store(false);
        // breakHeld is NOT cleared here — it stays true while finger is down
    }

    float joyBaseX()  const { return fixedJoyX; }
    float joyBaseY()  const { return fixedJoyY; }
    bool  joyActive() const;
    float joyThumbX() const;
    float joyThumbY() const;

private:
    mutable std::mutex mtx;   // protects ptrs, joyPtrIdx, lookPtrIdx, lookAnchorX/Y

    float sw = 1, sh = 1;
    float fixedJoyX = 0, fixedJoyY = 0;

    TouchPointer ptrs[MAX_TOUCH];
    int   joyPtrIdx   = -1;
    int   lookPtrIdx  = -1;
    float lookAnchorX = -1.f;
    float lookAnchorY = -1.f;

    // Atomics so GL thread can read without holding the lock
    std::atomic<bool> jumpPressed{false};
    std::atomic<bool> placePressed{false};
    std::atomic<bool> breakHeld{false};
    std::atomic<int>  breakPtrId{-1};
    std::atomic<bool> settingsPlusTap{false};

    // Look delta — accumulated under lock, consumed atomically
    mutable std::mutex  deltaMtx;
    float lookDX = 0.f;
    float lookDY = 0.f;

    // Internal (call under mtx)
    int      findSlot_locked(int id) const;
    int      allocSlot_locked(int id, float x, float y);
    ButtonId hitButton(float x, float y) const;
};
