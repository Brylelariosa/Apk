#include "World.h"
#include "BlockDefs.h"
#include <cmath>
#include <algorithm>
#include <android/log.h>

#define LOG_TAG "VoxelWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

World::World(uint32_t s) : noise(s), seed(s) {
    workerRunning = true;
    worker = std::thread(&World::workerMain, this);
    LOGI("World created, worker started");
}

World::~World() {
    workerRunning = false;
    if (worker.joinable()) worker.join();
}

// ── Block access (GL thread) ──────────────────────────────────────────────────
uint8_t World::getBlock(int x, int y, int z) const {
    if (y < 0 || y >= CH) return 0;
    int cx = (x < 0) ? ((x+1)/CW)-1 : x/CW;
    int cz = (z < 0) ? ((z+1)/CD)-1 : z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return 0;
    return it->second->getBlock(x - cx*CW, y, z - cz*CD);
}

void World::setBlock(int x, int y, int z, uint8_t type) {
    if (y < 0 || y >= CH) return;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = chunks.find({cx,cz});
    if (it == chunks.end()) return;
    it->second->setBlock(x-cx*CW, y, z-cz*CD, type);
    auto tryDirty = [&](int ncx, int ncz) {
        auto n = chunks.find({ncx,ncz});
        if (n != chunks.end()) n->second->markDirty();
    };
    int lx = x-cx*CW, lz = z-cz*CD;
    if (lx==0)    tryDirty(cx-1,cz);
    if (lx==CW-1) tryDirty(cx+1,cz);
    if (lz==0)    tryDirty(cx,cz-1);
    if (lz==CD-1) tryDirty(cx,cz+1);
}

Chunk* World::getChunk(int cx, int cz) const {
    auto it = chunks.find({cx,cz});
    return it != chunks.end() ? it->second.get() : nullptr;
}

// ── Worker thread ─────────────────────────────────────────────────────────────
// CRITICAL: wrap everything in try/catch — any uncaught exception here
// causes std::terminate() → SIGABRT crash reported as "startup crash".
void World::workerMain() {
    LOGI("Worker thread started");
    while (workerRunning) {
        try {
            ChunkKey key{0,0};
            bool hasWork = false;
            {
                std::lock_guard<std::mutex> lk(reqMutex);
                if (!requested.empty()) {
                    key = requested.back();
                    requested.pop_back();
                    inFlight.push_back(key);
                    hasWork = true;
                }
            }
            if (hasWork) {
                generateAndMesh(key.x, key.z);
                {
                    std::lock_guard<std::mutex> lk(reqMutex);
                    inFlight.erase(
                        std::remove_if(inFlight.begin(), inFlight.end(),
                            [&](const ChunkKey& k){ return k.x==key.x && k.z==key.z; }),
                        inFlight.end());
                }
            } else {
                struct timespec ts{0, 4000000}; // 4ms sleep
                nanosleep(&ts, nullptr);
            }
        } catch (const std::exception& e) {
            LOGE("Worker exception: %s", e.what());
        } catch (...) {
            LOGE("Worker unknown exception");
        }
    }
    LOGI("Worker thread exited");
}

uint8_t World::workerGetBlock(int x, int y, int z,
    const std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash>& local) const
{
    if (y < 0 || y >= CH) return 0;
    int cx = (x<0)?((x+1)/CW)-1:x/CW;
    int cz = (z<0)?((z+1)/CD)-1:z/CD;
    auto it = local.find({cx,cz});
    if (it == local.end()) return 0;
    return it->second->getBlock(x-cx*CW, y, z-cz*CD);
}

void World::generateAndMesh(int cx, int cz) {
    // Build a local neighbourhood so boundary faces mesh correctly
    std::unordered_map<ChunkKey,std::unique_ptr<Chunk>,ChunkHash> local;
    for (int dx = -1; dx <= 1; dx++)
        for (int dz = -1; dz <= 1; dz++) {
            auto c = std::make_unique<Chunk>(cx+dx, cz+dz);
            generateChunk(c.get());
            local[{cx+dx, cz+dz}] = std::move(c);
        }

    auto worldGet = [&](int x, int y, int z) -> uint8_t {
        return workerGetBlock(x, y, z, local);
    };
    local[{cx,cz}]->buildMesh(worldGet);

    // Hand off to GL thread
    std::lock_guard<std::mutex> lk(resMutex);
    results.push_back({cx, cz, std::move(local[{cx,cz}])});
}

void World::generateChunk(Chunk* c) {
    const int wx0 = c->getChunkX()*CW;
    const int wz0 = c->getChunkZ()*CD;
    float tempBase = noise.noise2D(wx0/300.f+500.f, wz0/300.f)*0.5f+0.5f;

    for (int lx = 0; lx < CW; lx++) {
        for (int lz = 0; lz < CD; lz++) {
            float wx = (float)(wx0+lx), wz = (float)(wz0+lz);
            float h  = noise.fbm(wx/120.f, wz/120.f, 5);
            float h2 = noise.fbm(wx/40.f+7.f, wz/40.f+3.f, 3)*0.3f;
            int height = 60 + (int)((h+h2)*28.f);
            height = std::max(2, std::min(CH-2, height));

            float temp = tempBase + noise.noise2D(wx/80.f, wz/80.f)*0.15f;

            uint8_t surface = BLOCK_GRASS, sub = BLOCK_DIRT;
            if      (height <= 61)  { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp  > 0.65f) { surface=BLOCK_SAND; sub=BLOCK_SAND; }
            else if (temp  < 0.35f) { surface=BLOCK_SNOW; }
            else if (height > 90)   { surface=BLOCK_SNOW; }

            for (int y = 0; y <= height; y++) {
                uint8_t type;
                if      (y == height)    type = surface;
                else if (y >= height-3)  type = sub;
                else                     type = BLOCK_STONE;

                if (type == BLOCK_STONE) {
                    float ore = noise.noise3D(wx/8.f,(float)y/8.f,wz/8.f);
                    if      (ore > 0.45f && y < 30) type = BLOCK_COAL;
                    else if (ore > 0.47f && y < 50) type = BLOCK_IRON;
                    else if (ore > 0.48f && y < 20) type = BLOCK_GLOWSTONE;
                }
                c->setBlock(lx, y, lz, type);
            }
            for (int y = height+1; y <= 60; y++)
                c->setBlock(lx, y, lz, BLOCK_WATER);

            // Trees — only in safe inner zone to avoid boundary writes
            if (surface == BLOCK_GRASS && lx>=3 && lx<=CW-4 && lz>=3 && lz<=CD-4) {
                uint32_t rng = (uint32_t)((wx0+lx)*73856093u ^ (wz0+lz)*19349663u ^ seed);
                rng = rng*1664525u + 1013904223u;
                if ((rng % 60) == 0) placeTree(c, lx, height+1, lz);
            }
        }
    }
    c->markDirty();
}

void World::placeTree(Chunk* c, int lx, int y, int lz) {
    // Trunk
    int trunkH = 4 + (int)((noise.noise2D((float)lx*0.1f,(float)lz*0.1f)+1.f));
    for (int i = 0; i < trunkH; i++) c->setBlock(lx, y+i, lz, BLOCK_LOG);
    // Canopy — safe bounds only
    for (int dy = trunkH-2; dy <= trunkH+1; dy++) {
        int r = (dy < trunkH) ? 2 : 1;
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                if (abs(dx)+abs(dz) > r+1) continue;
                int bx = lx+dx, bz = lz+dz;
                if (bx>=0 && bx<CW && bz>=0 && bz<CD)
                    c->setBlock(bx, y+dy, bz, BLOCK_LEAVES);
            }
    }
}

// ── GL thread update ──────────────────────────────────────────────────────────
void World::update(float px, float pz, int renderDist) {
    int pcx = (int)floorf(px/CW);
    int pcz = (int)floorf(pz/CD);

    // Queue missing chunks (nearest first, cap at 32 queued at once)
    {
        std::lock_guard<std::mutex> lk(reqMutex);
        int queued = (int)(requested.size() + inFlight.size());
        for (int r = 0; r <= renderDist && queued < 32; r++) {
            for (int dx = -r; dx <= r && queued < 32; dx++) {
                for (int dz = -r; dz <= r && queued < 32; dz++) {
                    if (abs(dx) != r && abs(dz) != r) continue;
                    if (dx*dx+dz*dz > renderDist*renderDist) continue;
                    ChunkKey key{pcx+dx, pcz+dz};
                    if (chunks.find(key) != chunks.end()) continue;
                    bool already = false;
                    for (auto& k : requested) if (k.x==key.x&&k.z==key.z){already=true;break;}
                    for (auto& k : inFlight)  if (k.x==key.x&&k.z==key.z){already=true;break;}
                    if (!already) { requested.push_back(key); queued++; }
                }
            }
        }
    }

    // Pull finished chunks from worker — upload GPU (max 3 per frame)
    {
        std::lock_guard<std::mutex> lk(resMutex);
        int done = 0;
        while (!results.empty() && done < 3) {
            auto& r = results.back();
            r.chunk->uploadMesh();
            chunks[{r.cx, r.cz}] = std::move(r.chunk);
            results.pop_back();
            done++;
        }
    }

    // Rebuild dirty chunks (from block place/break) on GL thread.
    // This is safe: worker only writes to its own local chunk maps, never to `chunks`.
    // The GL thread is the sole writer to `chunks`.
    try {
        auto worldGet = [this](int x, int y, int z) -> uint8_t { return getBlock(x,y,z); };
        for (auto& [key, chunk] : chunks) {
            if (chunk->isDirty()) {
                chunk->buildMesh(worldGet);
                chunk->uploadMesh();
                break; // one per frame max
            }
        }
    } catch (...) { /* log but don't crash */ }

    // Unload far chunks
    const int maxDist = renderDist + 2;
    for (auto it = chunks.begin(); it != chunks.end(); ) {
        int dx = it->first.x-pcx, dz = it->first.z-pcz;
        if (dx*dx+dz*dz > maxDist*maxDist) it = chunks.erase(it);
        else ++it;
    }
}

void World::renderAll(GLint mvpLoc, const float* vp) const {
    for (auto& [key,chunk] : chunks)
        chunk->render(mvpLoc, vp);
}

// ── DDA Raycast ───────────────────────────────────────────────────────────────
bool World::raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const {
    dir = normalize(dir);
    int bx=(int)floorf(origin.x), by=(int)floorf(origin.y), bz=(int)floorf(origin.z);
    int sx=(dir.x>0)?1:-1, sy=(dir.y>0)?1:-1, sz=(dir.z>0)?1:-1;
    float ddx=(fabsf(dir.x)>1e-6f)?fabsf(1.f/dir.x):1e30f;
    float ddy=(fabsf(dir.y)>1e-6f)?fabsf(1.f/dir.y):1e30f;
    float ddz=(fabsf(dir.z)>1e-6f)?fabsf(1.f/dir.z):1e30f;
    auto frac=[](float v){return v-floorf(v);};
    float tx=(dir.x>0)?(1.f-frac(origin.x))*ddx:frac(origin.x)*ddx;
    float ty=(dir.y>0)?(1.f-frac(origin.y))*ddy:frac(origin.y)*ddy;
    float tz=(dir.z>0)?(1.f-frac(origin.z))*ddz:frac(origin.z)*ddz;
    Vec3 normal{};
    for (int i = 0; i < 200; i++) {
        if (getBlock(bx,by,bz) != 0) {
            hitPos    = {(float)bx, (float)by, (float)bz};
            hitNormal = normal;
            return true;
        }
        float tmin = std::min({tx,ty,tz});
        if (tmin > maxDist) break;
        if      (tx <= ty && tx <= tz) { tx+=ddx; bx+=sx; normal={-(float)sx,0,0}; }
        else if (ty <= tz)             { ty+=ddy; by+=sy; normal={0,-(float)sy,0}; }
        else                           { tz+=ddz; bz+=sz; normal={0,0,-(float)sz}; }
    }
    return false;
}
