#pragma once
#include <cstdint>
#include <vector>
#include <functional>
#include <GLES3/gl3.h>

// Chunk dimensions
static constexpr int CW = 16;   // width  (X)
static constexpr int CH = 128;  // height (Y)
static constexpr int CD = 16;   // depth  (Z)

// Vertex layout: pos(3f) + colour(3f) + light(1f)  = 7 floats = 28 bytes
struct Vertex {
    float x, y, z;
    float r, g, b;
    float light;
};

class Chunk {
public:
    Chunk(int cx, int cz);
    ~Chunk();

    uint8_t  getBlock(int x, int y, int z) const;
    void     setBlock(int x, int y, int z, uint8_t type);

    // Build CPU-side mesh (can run off GL thread)
    using GetBlock = std::function<uint8_t(int,int,int)>;
    void buildMesh(const GetBlock& world);

    // Upload built mesh to GPU (must run on GL thread)
    void uploadMesh();

    // Draw — MVP is the column-major matrix for the uniform
    void render(GLint mvpLoc, const float* mvp) const;

    int  getChunkX() const { return chunkX; }
    int  getChunkZ() const { return chunkZ; }
    bool isDirty()   const { return dirty; }
    bool hasGpu()    const { return gpuReady; }
    bool hasMesh()   const { return !vertData.empty() || idxData.empty(); }
    void markDirty()       { dirty = true; gpuReady = false; }
    void markClean()       { dirty = false; }

private:
    uint8_t blocks[CW][CH][CD]{};
    int chunkX, chunkZ;

    std::vector<float>    vertData;
    std::vector<uint32_t> idxData;

    GLuint vao = 0, vbo = 0, ebo = 0;
    int    indexCount = 0;
    bool   dirty    = true;
    bool   gpuReady = false;

    void addQuad(int dim, int dir, int faceSlice,
                 int u0, int v0, int wu, int wv,
                 uint8_t blockType);
};
