#include "Input.h"
#include <cmath>
#include <cstring>

void Input::setScreenSize(float w, float h) {
    sw = w; sh = h;
    // Joystick base: lower-left quadrant, fixed forever
    fixedJoyX = w * 0.14f;
    fixedJoyY = h * 0.78f;
}

// ── Slot management ───────────────────────────────────────────────────────────
int Input::findSlot(int id) const {
    for (int i = 0; i < MAX_TOUCH; i++)
        if (ptrs[i].active && ptrs[i].id == id) return i;
    return -1;
}
int Input::allocSlot(int id, float x, float y) {
    for (int i = 0; i < MAX_TOUCH; i++) {
        if (!ptrs[i].active) {
            ptrs[i] = {id, x, y, x, y, true};
            return i;
        }
    }
    return -1;
}
void Input::freeSlot(int id) {
    int i = findSlot(id);
    if (i < 0) return;
    if (i == joyPtrIdx)  joyPtrIdx  = -1;
    if (i == lookPtrIdx) lookPtrIdx = -1;
    ptrs[i].active = false;
}

// ── Button positions (mirror Renderer HUD layout) ─────────────────────────────
// Right-side action buttons
//   JUMP   : (sw*0.84, sh*0.68)
//   PLACE  : (sw*0.74, sh*0.78)
//   BREAK  : (sw*0.94, sh*0.78)
// Settings row (top-right)
//   MINUS  : (sw*0.86, sh*0.06)
//   PLUS   : (sw*0.96, sh*0.06)
ButtonId Input::hitButton(float x, float y) const {
    auto d2 = [&](float cx, float cy) {
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy;
    };

    // Action buttons
    float r2 = BTN_RADIUS * BTN_RADIUS;
    if (d2(sw*0.84f, sh*0.68f) < r2) return ButtonId::JUMP;
    if (d2(sw*0.74f, sh*0.78f) < r2) return ButtonId::PLACE;
    if (d2(sw*0.94f, sh*0.78f) < r2) return ButtonId::BREAK;

    // Gear / settings button: top-right corner 40x40 region
    if (x > sw-70 && y < 70) return ButtonId::SETTINGS_PLUS; // opens settings

    // Settings panel buttons (only relevant when panel is open, centred)
    float pw=360, ppx=(sw-pw)*0.5f;
    float btnY = sh*0.5f + 20 + sh*0.5f*0.5f; // approximate panel centre
    float leftX = ppx + 70, rightX = ppx + pw - 70;
    float sr2 = 55.f*55.f;
    if (d2(leftX,  btnY) < sr2) return ButtonId::SETTINGS_MINUS;
    if (d2(rightX, btnY) < sr2) return ButtonId::SETTINGS_PLUS;

    return ButtonId::NONE;
}

// ── Touch events ─────────────────────────────────────────────────────────────
void Input::onTouchDown(int id, float x, float y) {
    // Right side — check buttons first
    if (x > sw * 0.5f) {
        ButtonId btn = hitButton(x, y);
        switch (btn) {
            case ButtonId::JUMP:            jumpPressed    = true;  return;
            case ButtonId::PLACE:           placePressed   = true;  return;
            case ButtonId::BREAK:           breakPtrId     = id;    return;
            case ButtonId::SETTINGS_PLUS:   settingsPlusTap  = true; return;
            case ButtonId::SETTINGS_MINUS:  settingsMinusTap = true; return;
            default: break;
        }
    }

    int slot = allocSlot(id, x, y);
    if (slot < 0) return;

    if (x < sw * 0.5f) {
        if (joyPtrIdx < 0) joyPtrIdx = slot;
    } else {
        if (lookPtrIdx < 0) lookPtrIdx = slot;
    }
}

void Input::onTouchMove(int id, float x, float y) {
    int slot = findSlot(id);
    if (slot < 0) return;

    float prevX = ptrs[slot].currentX;
    float prevY = ptrs[slot].currentY;
    ptrs[slot].currentX = x;
    ptrs[slot].currentY = y;

    if (slot == lookPtrIdx) {
        lookDX += x - prevX;
        lookDY += y - prevY;
    }
}

void Input::onTouchUp(int id, float x, float y) {
    if (id == breakPtrId) breakPtrId = -1;
    freeSlot(id);
}

// ── Joystick thumb position (clamped to radius from fixed base) ───────────────
float Input::joyThumbX() const {
    if (joyPtrIdx < 0) return fixedJoyX;
    float dx = ptrs[joyPtrIdx].currentX - fixedJoyX;
    float dy = ptrs[joyPtrIdx].currentY - fixedJoyY;
    float mag = sqrtf(dx*dx + dy*dy);
    if (mag > JOY_RADIUS) dx = dx / mag * JOY_RADIUS;
    return fixedJoyX + dx;
}
float Input::joyThumbY() const {
    if (joyPtrIdx < 0) return fixedJoyY;
    float dx = ptrs[joyPtrIdx].currentX - fixedJoyX;
    float dy = ptrs[joyPtrIdx].currentY - fixedJoyY;
    float mag = sqrtf(dx*dx + dy*dy);
    if (mag > JOY_RADIUS) dy = dy / mag * JOY_RADIUS;
    return fixedJoyY + dy;
}

// ── Movement (from clamped thumb relative to fixed base) ─────────────────────
Vec3 Input::getMovement() const {
    if (joyPtrIdx < 0) return {0, 0, 0};
    float dx = (joyThumbX() - fixedJoyX) / JOY_RADIUS;
    float dz = (joyThumbY() - fixedJoyY) / JOY_RADIUS;
    float mag = sqrtf(dx*dx + dz*dz);
    if (mag > 1.f) { dx /= mag; dz /= mag; }
    return {dx, 0, dz};
}

float Input::consumeDX() { float v = lookDX; lookDX = 0; return v; }
float Input::consumeDY() { float v = lookDY; lookDY = 0; return v; }
