#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <memory>
#include <string>

#include "core/CrashReporter.h"
#include "core/Renderer.h"
#include "core/World.h"
#include "core/Camera.h"
#include "core/Input.h"
#include "core/BlockDefs.h"
#include "core/MathUtils.h"

#define LOG_TAG "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── Game state ────────────────────────────────────────────────────────────────
static std::unique_ptr<Renderer> g_renderer;
static std::unique_ptr<World>    g_world;
static std::unique_ptr<Camera>   g_camera;
static std::unique_ptr<Input>    g_input;

static int   g_width  = 1, g_height = 1;
static long  g_lastNs = 0;
static bool  g_inited = false;

// Error overlay
static std::string g_errorMsg;
static bool        g_showError = false;

// Physics
static float g_velY     = 0.f;
static bool  g_onGround = false;

// Block breaking
static int   g_breakX = -99999, g_breakY = -99999, g_breakZ = -99999;
static float g_breakProgress = 0.f;
static const float BREAK_TIME = 0.7f;

// Settings
static int  g_renderDist  = 4;
static bool g_settingsOpen = false;

// FPS
static float g_fpsTimer  = 0.f;
static int   g_fpsFrames = 0;
static int   g_fpsDisplay= 0;

// Loading: show spinner until first chunks arrive
static int   g_loadFrame   = 0;
static bool  g_everHadChunks = false;

// Hotbar
static uint8_t g_hotbar[9] = {
    BLOCK_GRASS, BLOCK_DIRT, BLOCK_STONE,
    BLOCK_SAND,  BLOCK_LOG,  BLOCK_LEAVES,
    BLOCK_GLOWSTONE, BLOCK_LAVA, BLOCK_SNOW
};
static int g_hotbarSel = 0;

static char g_crashPath[512] = {};

// ── Time ──────────────────────────────────────────────────────────────────────
static long nowNs() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000L + ts.tv_nsec;
}

// ── Physics ───────────────────────────────────────────────────────────────────
static bool solidAt(const World* w, float x, float y, float z) {
    return blockSolid(w->getBlock((int)floorf(x),(int)floorf(y),(int)floorf(z)));
}
static bool playerOnGround(const World* w, Vec3 pos) {
    float feet = pos.y - 1.85f;
    for (float dx : {-0.28f, 0.28f})
        for (float dz : {-0.28f, 0.28f})
            if (solidAt(w, pos.x+dx, feet, pos.z+dz)) return true;
    return false;
}
static Vec3 collideMove(const World* w, Vec3 pos, Vec3 delta) {
    const float EY = 1.8f;
    // X
    float sx = delta.x > 0 ? 0.29f : -0.29f;
    if (solidAt(w,pos.x+delta.x+sx, pos.y-EY+0.1f, pos.z) ||
        solidAt(w,pos.x+delta.x+sx, pos.y-EY+0.9f, pos.z) ||
        solidAt(w,pos.x+delta.x+sx, pos.y-0.1f,    pos.z))
        delta.x = 0;
    // Z
    float sz = delta.z > 0 ? 0.29f : -0.29f;
    if (solidAt(w,pos.x, pos.y-EY+0.1f, pos.z+delta.z+sz) ||
        solidAt(w,pos.x, pos.y-EY+0.9f, pos.z+delta.z+sz) ||
        solidAt(w,pos.x, pos.y-0.1f,    pos.z+delta.z+sz))
        delta.z = 0;
    // Y down
    if (delta.y < 0) {
        bool blocked = false;
        for (float ddx:{-0.28f,0.28f}) for(float ddz:{-0.28f,0.28f})
            if (solidAt(w,pos.x+ddx, pos.y-EY+delta.y, pos.z+ddz)) blocked=true;
        if (blocked) { delta.y=0; g_velY=0; }
    }
    // Y up
    if (delta.y > 0 && solidAt(w, pos.x, pos.y+delta.y+0.05f, pos.z))
        { delta.y=0; g_velY=0; }
    return pos + delta;
}

// ── Error screen ──────────────────────────────────────────────────────────────
static void renderErrorScreen() {
    static int f = 0; f++;
    float r = ((f/20)%2==0) ? 0.85f : 0.55f;
    glClearColor(r, 0.03f, 0.03f, 1.f);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    LOGE("Error screen: %s", g_errorMsg.c_str());
}

// ── Game tick ─────────────────────────────────────────────────────────────────
static void gameTick(float dt) {
    if (!g_world || !g_camera || !g_input) return;
    if (dt > 0.08f) dt = 0.08f;

    // FPS
    g_fpsTimer  += dt;
    g_fpsFrames += 1;
    if (g_fpsTimer >= 0.5f) {
        g_fpsDisplay = (int)(g_fpsFrames/g_fpsTimer + 0.5f);
        g_fpsTimer = 0; g_fpsFrames = 0;
    }

    // Settings toggle & render dist
    if (g_input->isSettingsPlusTap()) {
        if (g_settingsOpen) g_renderDist = std::min(g_renderDist+1, 24);
        else g_settingsOpen = true;
    }
    if (g_input->isSettingsMinusTap()) {
        if (g_settingsOpen) g_renderDist = std::max(g_renderDist-1, 2);
    }

    // Swallow all input while settings are open except the +/- buttons
    if (g_settingsOpen) {
        g_input->clearActions();
        return;
    }

    // Look (pitch fix: swipe down = look down)
    float dyaw   = g_input->consumeDX() * -0.003f;
    float dpitch = g_input->consumeDY() *  0.003f;
    g_camera->rotate(dyaw, dpitch);

    // Move
    Vec3 mov = g_input->getMovement();
    Vec3 fwd = g_camera->getForward(); fwd.y=0; fwd=normalize(fwd);
    Vec3 rgt = g_camera->getRight();   rgt.y=0; rgt=normalize(rgt);
    Vec3 movW = rgt*(mov.x*5.5f*dt) + fwd*(-mov.z*5.5f*dt);

    // Gravity + jump
    g_onGround = playerOnGround(g_world.get(), g_camera->getPosition());
    g_velY -= 22.f*dt;
    if (g_onGround && g_velY < 0.f) g_velY = 0.f;
    if (g_input->isJumpPressed() && g_onGround) g_velY = 9.5f;
    movW.y = g_velY*dt;

    g_camera->setPosition(collideMove(g_world.get(), g_camera->getPosition(), movW));

    // Raycast
    Vec3 eye = g_camera->getPosition();
    Vec3 dir = g_camera->getForward();
    Vec3 hitPos, hitNorm;
    bool hasTarget = g_world->raycast(eye, dir, 6.f, hitPos, hitNorm);

    // Place block — put it on the face the ray hit (hitPos + hitNorm)
    if (g_input->isPlacePressed() && hasTarget) {
        // hitPos is the block that was hit, hitNorm points away from it
        // so place position = hitPos + hitNorm (the empty block next to it)
        int px = (int)floorf(hitPos.x + hitNorm.x + 0.5f);
        int py = (int)floorf(hitPos.y + hitNorm.y + 0.5f);
        int pz = (int)floorf(hitPos.z + hitNorm.z + 0.5f);
        // Don't place inside player body (2 blocks tall at eye position)
        Vec3 ep = g_camera->getPosition();
        bool insidePlayer =
            (px==(int)floorf(ep.x) && pz==(int)floorf(ep.z)) &&
            (py==(int)floorf(ep.y) || py==(int)floorf(ep.y)-1 || py==(int)floorf(ep.y)-2);
        if (!insidePlayer)
            g_world->setBlock(px, py, pz, g_hotbar[g_hotbarSel]);
    }

    // Break (hold)
    if (g_input->isBreakHeld() && hasTarget) {
        int hx=(int)floorf(hitPos.x), hy=(int)floorf(hitPos.y), hz=(int)floorf(hitPos.z);
        if (hx==g_breakX && hy==g_breakY && hz==g_breakZ) {
            g_breakProgress += dt / BREAK_TIME;
            if (g_breakProgress >= 1.f) {
                g_world->setBlock(hx, hy, hz, BLOCK_AIR);
                g_breakProgress = 0.f;
                g_breakX = g_breakY = g_breakZ = -99999;
            }
        } else {
            g_breakX=hx; g_breakY=hy; g_breakZ=hz;
            g_breakProgress = 0.f;
        }
    } else {
        g_breakProgress = 0.f;
        g_breakX = g_breakY = g_breakZ = -99999;
    }

    g_input->clearActions();
    g_world->update(eye.x, eye.z, g_renderDist);
}

// ═════════════════════════════════════════════════════════════════════════════
extern "C" {

JNIEXPORT jstring JNICALL
Java_com_voxel_game_GameRenderer_nativeSetup(JNIEnv* env, jobject, jstring jDir) {
    const char* dir = env->GetStringUTFChars(jDir, nullptr);
    snprintf(g_crashPath, sizeof(g_crashPath), "%s/crash.txt", dir);
    env->ReleaseStringUTFChars(jDir, dir);
    installCrashHandler(g_crashPath);
    std::string report = loadAndClearCrashReport(g_crashPath);
    return env->NewStringUTF(report.empty() ? "" : report.c_str());
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit");
    const char* glv = (const char*)glGetString(GL_VERSION);
    LOGI("GL: %s", glv ? glv : "null");
    if (!glv) {
        g_errorMsg = "OpenGL ES unavailable on this device.";
        g_showError = true; return;
    }
    try {
        g_renderer = std::make_unique<Renderer>();
        if (!g_renderer->init()) {
            g_errorMsg = "Shader compile failed.";
            g_showError = true; return;
        }
        g_world  = std::make_unique<World>(12345u);
        g_camera = std::make_unique<Camera>();
        g_input  = std::make_unique<Input>();
        g_camera->setPosition({8.f, 100.f, 8.f});
        g_velY   = 0.f;
        g_lastNs = nowNs();
        g_inited = true;
        LOGI("nativeInit OK");
    } catch (const std::exception& e) {
        g_errorMsg = std::string("Init exception: ") + e.what();
        g_showError = true;
        LOGE("%s", g_errorMsg.c_str());
    } catch (...) {
        g_errorMsg = "Unknown init exception";
        g_showError = true;
    }
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    g_width=w; g_height=h;
    if (g_renderer) g_renderer->resize(w,h);
    if (g_camera)   g_camera->updateProjection((float)w/(float)h);
    if (g_input)    g_input->setScreenSize((float)w,(float)h);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (g_showError) { renderErrorScreen(); return; }
    if (!g_inited)   return;

    long now = nowNs();
    float dt = (float)(now-g_lastNs)*1e-9f;
    g_lastNs = now;

    gameTick(dt);

    g_renderer->beginFrame();

    // Show loading spinner until first batch of chunks is ready
    size_t ready = g_world->chunkCount();
    if (!g_everHadChunks) {
        if (ready >= 2) g_everHadChunks = true;
        else {
            g_loadFrame++;
            g_renderer->renderLoading((float)g_width,(float)g_height,g_loadFrame);
            return;
        }
    }

    // 3D world
    glUseProgram(g_renderer->getWorldProg());
    Mat4 vp = g_camera->getViewProjection();
    g_world->renderAll(g_renderer->getMVPLoc(), vp.m);

    // HUD + settings overlay
    g_renderer->renderHUD(
        (float)g_width, (float)g_height,
        g_input->joyBaseX(),  g_input->joyBaseY(),
        g_input->joyThumbX(), g_input->joyThumbY(),
        g_input->joyActive(),
        g_breakProgress,
        g_fpsDisplay,
        g_renderDist,
        g_settingsOpen
    );
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchDown(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(g_input) {
        // Tap anywhere outside buttons closes settings
        if (g_settingsOpen) {
            // Let input handle +/- buttons; they'll set the flags
            g_input->onTouchDown(id,x,y);
            // If neither settings button was tapped, close panel
            if (!g_input->isSettingsPlusTap() && !g_input->isSettingsMinusTap())
                g_settingsOpen = false;
            g_input->clearActions();
        } else {
            g_input->onTouchDown(id,x,y);
        }
    }
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchMove(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(g_input) g_input->onTouchMove(id,x,y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchUp(JNIEnv*,jobject,jint id,jfloat x,jfloat y){
    if(g_input) g_input->onTouchUp(id,x,y);
}

} // extern "C"
