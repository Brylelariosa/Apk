package com.steve.browser

/**
 * Opera-style Data Saver levels.
 *
 * OFF        – no restrictions, normal browsing
 * LOW        – aggressive caching + block tracking scripts only
 * MEDIUM     – LOW + block GIF/video autoplay, compress hint in UA
 * HIGH       – block ALL images + video + non-essential scripts
 * IMAGES_OFF – block ALL images only (text/JS still loads)
 */
enum class DataSaverLevel(val label: String, val emoji: String, val description: String) {
    OFF(
        label       = "Off",
        emoji       = "🌐",
        description = "No restrictions — normal browsing"
    ),
    LOW(
        label       = "Low",
        emoji       = "💾",
        description = "Aggressive cache • Block trackers/analytics"
    ),
    MEDIUM(
        label       = "Medium",
        emoji       = "💾💾",
        description = "Low + Block GIFs & auto-play video"
    ),
    HIGH(
        label       = "High",
        emoji       = "💾💾💾",
        description = "Block all images, video & heavy scripts"
    ),
    IMAGES_OFF(
        label       = "Images Off",
        emoji       = "🚫🖼️",
        description = "Block all images — text & video still load"
    );

    companion object {
        fun fromOrdinal(ord: Int) = entries.getOrElse(ord) { OFF }
    }

    /** Which MIME types to block for this level (in shouldInterceptRequest) */
    val blockedMimes: Set<String> get() = when (this) {
        OFF        -> emptySet()
        LOW        -> setOf("text/javascript") // handled via AdBlocker domain list
        MEDIUM     -> setOf("image/gif", "video/mp4", "video/webm", "video/ogg")
        HIGH       -> setOf(
            "image/jpeg","image/png","image/gif","image/webp",
            "image/svg+xml","image/avif","video/mp4","video/webm",
            "video/ogg","audio/mpeg","audio/ogg","font/woff2","font/woff"
        )
        IMAGES_OFF -> setOf(
            "image/jpeg","image/png","image/gif",
            "image/webp","image/svg+xml","image/avif"
        )
    }

    /** Whether to set WebSettings.blockNetworkImage = true */
    val blockNetworkImages: Boolean get() = this == HIGH || this == IMAGES_OFF

    /** WebSettings cacheMode for this level */
    val cacheMode: Int get() = when (this) {
        OFF        -> android.webkit.WebSettings.LOAD_DEFAULT
        LOW,
        MEDIUM     -> android.webkit.WebSettings.LOAD_CACHE_ELSE_NETWORK
        HIGH,
        IMAGES_OFF -> android.webkit.WebSettings.LOAD_CACHE_ELSE_NETWORK
    }

    val isActive: Boolean get() = this != OFF
}
