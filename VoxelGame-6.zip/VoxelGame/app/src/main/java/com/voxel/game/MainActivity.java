package com.voxel.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Toast;
import java.io.PrintWriter;
import java.io.StringWriter;

public class MainActivity extends Activity {

    private static final String TAG = "VoxelMain";
    private GameSurfaceView surfaceView;
    private GameRenderer    renderer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── Catch any unhandled Java exception and show it on screen ──────────
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            StringWriter sw = new StringWriter();
            throwable.printStackTrace(new PrintWriter(sw));
            final String trace = "Java crash on thread [" + thread.getName() + "]:\n" + sw;
            Log.e(TAG, trace);

            runOnUiThread(() -> {
                try {
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("⚠️ Java Crash")
                        .setMessage(trace)
                        .setPositiveButton("Copy", (d, w) -> {
                            ClipboardManager cm = (ClipboardManager)
                                getSystemService(Context.CLIPBOARD_SERVICE);
                            cm.setPrimaryClip(ClipData.newPlainText("crash", trace));
                            Toast.makeText(MainActivity.this, "Copied!", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Close", (d, w) -> finish())
                        .setCancelable(false)
                        .show();
                } catch (Exception ignored) { }
            });
        });

        // ── Window flags ──────────────────────────────────────────────────────
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        applyImmersive();

        // ── Create renderer (installs crash handler, checks for previous crash) ─
        String filesDir = getFilesDir().getAbsolutePath();
        Log.i(TAG, "App files dir: " + filesDir);

        try {
            renderer    = new GameRenderer(this, filesDir);
            surfaceView = new GameSurfaceView(this, renderer);
            setContentView(surfaceView);
        } catch (UnsatisfiedLinkError e) {
            showFatalError("Native library failed to load:\n\n" + e.getMessage()
                + "\n\nABI: " + Build.SUPPORTED_ABIS[0]);
            return;
        } catch (Exception e) {
            showFatalError("Startup exception:\n\n" + e.getMessage());
            return;
        }

        // Show any crash report from the previous run
        renderer.showPendingCrashDialog();
    }

    private void showFatalError(String msg) {
        Log.e(TAG, "FATAL: " + msg);
        new AlertDialog.Builder(this)
            .setTitle("⚠️ Fatal Error")
            .setMessage(msg)
            .setPositiveButton("Copy", (d, w) -> {
                ClipboardManager cm = (ClipboardManager)
                    getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("error", msg));
                Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Close", (d, w) -> finish())
            .setCancelable(false)
            .show();
    }

    private void applyImmersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController ctrl = getWindow().getInsetsController();
            if (ctrl != null) {
                ctrl.hide(WindowInsets.Type.systemBars());
                ctrl.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            //noinspection deprecation
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    @Override protected void onResume() { super.onResume(); if (surfaceView != null) surfaceView.onResume(); }
    @Override protected void onPause()  { super.onPause();  if (surfaceView != null) surfaceView.onPause();  }
}
