package com.mangatool.app.util

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        sp = context.getSharedPreferences("mie_prefs", Context.MODE_PRIVATE)
    }

    var minSizeKb: Int
        get() = sp.getInt("min_size_kb", 40)
        set(v) { sp.edit().putInt("min_size_kb", v).apply() }

    var excludeGifs: Boolean
        get() = sp.getBoolean("exclude_gifs", true)
        set(v) { sp.edit().putBoolean("exclude_gifs", v).apply() }

    var reverseOrder: Boolean
        get() = sp.getBoolean("reverse_order", false)
        set(v) { sp.edit().putBoolean("reverse_order", v).apply() }
}
