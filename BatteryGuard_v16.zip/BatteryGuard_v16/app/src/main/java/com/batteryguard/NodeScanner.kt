package com.batteryguard

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Scans the device's sysfs power-supply tree to find the correct charging
 * control node for this specific device.
 *
 * Strategy:
 *  1. List every subdirectory under /sys/class/power_supply/
 *  2. For each directory, look for files whose names match known patterns.
 *  3. For each candidate, determine whether "disable" means writing "0" or "1"
 *     (depends on the node semantics: charging_enabled → 0=off, input_suspend → 1=off).
 *  4. Read baseline current_now, write the disable value, wait 3 seconds,
 *     re-read current_now. If current dropped by ≥ 60 % → this node works.
 *  5. Always restore the enable value before moving on.
 *  6. Save the winning node + values to SharedPreferences so ChargingController
 *     can use it immediately and on every future boot.
 */
object NodeScanner {

    private const val TAG = "NodeScanner"

    // (filename-pattern) → Pair(disableValue, enableValue)
    // Order matters: more specific patterns first.
    private val PATTERNS = linkedMapOf(
        "charging_enabled"          to ("0" to "1"),
        "charger_enabled"           to ("0" to "1"),
        "charge_enabled"            to ("0" to "1"),
        "charger_enable"            to ("0" to "1"),
        "input_suspend"             to ("1" to "0"),
        "charge_disable"            to ("1" to "0"),
        "stop_charging"             to ("1" to "0"),
        "inhibit_charge"            to ("1" to "0"),
        "batt_ce_full"              to ("1" to "0"),
        "battery_charging_enabled"  to ("0" to "1"),
        "restrict_charging"         to ("1" to "0"),
        "charge_control_limit_max"  to ("0" to "100")   // write 0 = disable, 100 = enable
    )

    data class ScanResult(
        val node: String?,           // null if nothing found
        val disableValue: String?,
        val enableValue: String?,
        val allCandidates: List<String>,
        val log: List<String>
    )

    /**
     * Blocking — call only from a background thread (ChargingController.executor).
     *
     * @param context   used for PowerReader and SharedPreferences
     * @param onProgress called on the caller's thread with live log lines
     */
    fun scan(context: Context, onProgress: (String) -> Unit): ScanResult {
        val log = mutableListOf<String>()

        fun emit(line: String) {
            Log.d(TAG, line)
            log += line
            onProgress(line)
        }

        emit("── Starting node scan ──")

        // 1. Check we are currently charging
        val baseline = PowerReader.read(context)
        if (!baseline.isPlugged) {
            emit("⚠ Device is not plugged in.")
            emit("  Plug in the charger and try again.")
            return ScanResult(null, null, null, emptyList(), log)
        }
        val baselineMa = baseline.currentMa
        emit("📡 Baseline current: ${baseline.currentStr}  (${baseline.percent}%)")

        if (baselineMa < 50) {
            emit("⚠ Baseline current is very low (${baseline.currentStr}).")
            emit("  May already be nearly full — results may be unreliable.")
        }

        // 2. Discover all power_supply directories
        val psDirs = try {
            File("/sys/class/power_supply").listFiles()
                ?.filter { it.isDirectory || it.isSymlink() }
                ?: emptyList()
        } catch (e: Exception) {
            emit("✗ Cannot read /sys/class/power_supply: ${e.message}")
            return ScanResult(null, null, null, emptyList(), log)
        }

        emit("📂 Power supply dirs: ${psDirs.map { it.name }}")

        // 3. Build candidate list
        val candidates = mutableListOf<Triple<String, String, String>>() // (path, disableVal, enableVal)

        for (dir in psDirs) {
            for ((pattern, values) in PATTERNS) {
                val f = File(dir, pattern)
                if (f.exists()) {
                    candidates += Triple(f.absolutePath, values.first, values.second)
                    emit("  found: ${f.absolutePath}  (current value: ${readSysfs(f)})")
                }
            }
        }

        if (candidates.isEmpty()) {
            emit("✗ No known charging control nodes found on this device.")
            emit("  Your kernel may use a non-standard node name.")
            return ScanResult(null, null, null, emptyList(), log)
        }

        emit("🔍 Found ${candidates.size} candidate(s) — testing each…")

        // 4. Test each candidate
        for ((path, disableVal, enableVal) in candidates) {
            emit("")
            emit("▶ Testing: $path")
            emit("  write \"$disableVal\" to disable, \"$enableVal\" to re-enable")

            val writeOk = writeViaSh(path, disableVal)
            if (!writeOk) {
                emit("  ✗ Write failed (permission denied?)")
                continue
            }

            emit("  ⏳ Waiting 3 s to observe current change…")
            Thread.sleep(3_000)

            val after = PowerReader.read(context)
            val afterMa = after.currentMa
            emit("  Current after: ${after.currentStr}")

            // Restore immediately
            writeViaSh(path, enableVal)
            emit("  ↩ Restored \"$enableVal\"")

            // Evaluate: did current drop by ≥ 60 % ?
            val drop = if (baselineMa > 10) (baselineMa - afterMa) / baselineMa else 0.0
            emit("  Current drop: ${(drop * 100).toInt()}%")

            if (drop >= 0.60) {
                emit("")
                emit("✅ MATCH: $path")
                emit("   disable=\"$disableVal\"  enable=\"$enableVal\"")

                // Save to prefs
                context.getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
                    .putString("discovered_node",         path)
                    .putString("discovered_disable_val",  disableVal)
                    .putString("discovered_enable_val",   enableVal)
                    .apply()

                emit("💾 Node saved — Battery Guard will use it from now on.")
                return ScanResult(path, disableVal, enableVal, candidates.map { it.first }, log)
            } else {
                emit("  ✗ Current didn't drop enough — not the right node.")
            }
        }

        emit("")
        emit("✗ None of the ${candidates.size} candidate(s) reliably stopped charging.")
        emit("  Your device may require a custom kernel module or an unsupported method.")
        return ScanResult(null, null, null, candidates.map { it.first }, log)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun File.isSymlink(): Boolean = try {
        canonicalPath != absolutePath
    } catch (_: Exception) { false }

    private fun readSysfs(f: File): String = try {
        f.readText().trim()
    } catch (_: Exception) { "?" }

    /**
     * Writes [value] to [path] using a plain sh -c shell (no root).
     * ChargingController already handles root/Shizuku for the real disable/enable
     * commands; here we attempt a direct write first and fall back to
     * Runtime su if available.
     */
    private fun writeViaSh(path: String, value: String): Boolean {
        // Try direct write (works if app has shell/root already)
        return try {
            val p = Runtime.getRuntime().exec(
                if (ChargingController.isRooted())
                    arrayOf("su", "-c", "echo $value > $path")
                else
                    arrayOf("sh", "-c", "echo $value > $path")
            )
            p.waitFor(4, java.util.concurrent.TimeUnit.SECONDS)
            // Verify the value actually changed
            val written = readSysfs(File(path))
            written == value || written.trimStart('0').isEmpty() // handle "00" edge case
        } catch (e: Exception) {
            Log.e(TAG, "writeViaSh failed: ${e.message}")
            false
        }
    }
}
