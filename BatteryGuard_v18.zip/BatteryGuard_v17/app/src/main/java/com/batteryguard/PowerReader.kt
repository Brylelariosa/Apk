package com.batteryguard

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import java.io.File
import kotlin.math.abs

/**
 * Accurate battery power reading.
 *
 * Strategy (in priority order):
 *  1. Read current_now + voltage_now directly from sysfs — most accurate,
 *     bypasses BatteryManager unit/sign inconsistencies.
 *  2. BatteryManager.BATTERY_PROPERTY_CURRENT_NOW with automatic µA/mA detection.
 *  3. Estimate from voltage alone.
 *
 * Sign convention: positive = charging, negative = discharging.
 * Units: watts (W), milliamps (mA), millivolts (mV).
 */
object PowerReader {

    private const val TAG = "PowerReader"

    // sysfs paths for current (µA, sign varies by kernel)
    private val CURRENT_PATHS = listOf(
        "/sys/class/power_supply/battery/current_now",
        "/sys/class/power_supply/battery/BatteryAverageCurrent",
        "/sys/class/power_supply/battery/avg_current_now",
        "/sys/class/power_supply/batt_drv/current_now",
        // Additional paths found on Pixel, Samsung, and Qualcomm devices
        "/sys/class/power_supply/usb/current_now",
        "/sys/class/power_supply/main/current_now",
        "/sys/class/power_supply/pc_port/current_now",
        "/sys/class/power_supply/ac/current_now"
    )

    // sysfs paths for voltage (µV)
    private val VOLTAGE_PATHS = listOf(
        "/sys/class/power_supply/battery/voltage_now",
        "/sys/class/power_supply/battery/BatteryVoltage",
        "/sys/class/power_supply/batt_drv/voltage_now"
    )

    data class PowerInfo(
        val watts: Double,      // always positive (absolute power)
        val currentMa: Double,  // positive = charging, negative = discharging
        val voltageMv: Int,
        val isCharging: Boolean,
        val isPlugged: Boolean, // true whenever a charger is physically connected
        val percent: Int
    ) {
        val wattsStr: String get() = if (watts >= 0.05) String.format("%.1fW", watts) else "—"
        val currentStr: String get() = String.format("%.0fmA", abs(currentMa))
        val voltageStr: String get() = "${voltageMv}mV"
    }

    fun read(context: Context): PowerInfo {
        val intent  = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level   = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val scale   = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status  = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val percent = if (scale > 0) level * 100 / scale else 0
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                         status == BatteryManager.BATTERY_STATUS_FULL
        // EXTRA_PLUGGED is non-zero whenever a charger (USB, AC, wireless) is connected,
        // even if the kernel has blocked actual electron flow via sysfs.
        val isPlugged = plugged != 0

        // 1. Try sysfs voltage (µV → mV)
        val voltageMv = readSysfsLong(VOLTAGE_PATHS)
            ?.let { if (it > 10_000) it / 1000L else it }   // µV → mV
            ?.toInt()
            ?: (intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0)

        // 2. Try sysfs current (µA, sign varies)
        val rawSysfsCurrent = readSysfsLong(CURRENT_PATHS)
        val currentMa: Double

        if (rawSysfsCurrent != null) {
            // Detect unit: if absolute value > 100,000 it's µA, else mA
            val mA = if (abs(rawSysfsCurrent) > 100_000L)
                rawSysfsCurrent / 1000.0
            else
                rawSysfsCurrent.toDouble()

            // Normalise sign: positive = charging
            currentMa = when {
                isCharging && mA < 0 -> -mA   // kernel reports negative while charging → flip
                !isCharging && mA > 0 -> -mA  // kernel reports positive while discharging → flip
                else -> mA
            }
        } else {
            // 3. Fallback: BatteryManager API
            val bm  = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val raw = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            val mA  = when {
                raw == Long.MIN_VALUE -> 0.0
                abs(raw) > 100_000L -> raw / 1000.0
                else -> raw.toDouble()
            }
            currentMa = when {
                isCharging && mA < 0  -> -mA
                !isCharging && mA > 0 -> -mA
                else -> mA
            }
        }

        val watts = if (voltageMv > 0 && currentMa != 0.0)
            abs(voltageMv * currentMa) / 1_000_000.0
        else 0.0

        return PowerInfo(watts, currentMa, voltageMv, isCharging, isPlugged, percent)
    }

    private fun readSysfsLong(paths: List<String>): Long? {
        for (path in paths) {
            try {
                val f = File(path)
                if (!f.exists()) continue
                val text = f.readText().trim()
                return text.toLong()
            } catch (e: Exception) {
                Log.v(TAG, "sysfs $path: ${e.message}")
            }
        }
        return null
    }
}
