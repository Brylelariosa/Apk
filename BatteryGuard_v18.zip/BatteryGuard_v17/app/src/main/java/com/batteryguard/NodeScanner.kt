package com.batteryguard

import android.content.Context
import android.util.Log
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Scans the device's sysfs power-supply tree to find the correct charging
 * control node for this specific device.
 *
 * IMPORTANT SAFETY RULES:
 *  - Every write is wrapped in try/finally → restore is ALWAYS called even on crash.
 *  - All writes go through ChargingController.execCmd (root OR Shizuku) — never
 *    raw Runtime.exec("su") which would crash on Shizuku-only devices.
 *  - The scan runs on its own dedicated thread, NOT on ChargingController's
 *    single executor, so BatteryService keeps working during the scan.
 */
object NodeScanner {

    private const val TAG = "NodeScanner"

    // filename → Pair(disableValue, enableValue)
    // "disable" semantics differ per node: some use 0=off, some use 1=off.
    private val PATTERNS = linkedMapOf(
        "charging_enabled"         to ("0" to "1"),
        "charger_enabled"          to ("0" to "1"),
        "charge_enabled"           to ("0" to "1"),
        "charger_enable"           to ("0" to "1"),
        "battery_charging_enabled" to ("0" to "1"),
        "input_suspend"            to ("1" to "0"),
        "charge_disable"           to ("1" to "0"),
        "stop_charging"            to ("1" to "0"),
        "inhibit_charge"           to ("1" to "0"),
        "batt_ce_full"             to ("1" to "0"),
        "restrict_charging"        to ("1" to "0"),
        "charge_control_limit_max" to ("0" to "100"),
        // Samsung-specific nodes
        "batt_slate_mode"          to ("1" to "0"),
        "siop_level"               to ("0" to "100"),
        // Qualcomm / misc OEM nodes
        "usb_charger_enable"       to ("0" to "1"),
        "cp_charging_enable"       to ("0" to "1"),
        "enable"                   to ("0" to "1")
    )

    data class ScanResult(
        val node: String?,
        val disableValue: String?,
        val enableValue: String?,
        val allCandidates: List<String>,
        val log: List<String>
    )

    /**
     * Starts a scan on a dedicated background thread.
     * [onProgress] and [onDone] are called on that background thread —
     * callers must use runOnUiThread / handler.post when updating UI.
     */
    fun scanAsync(
        context: Context,
        onProgress: (String) -> Unit,
        onDone: (ScanResult) -> Unit
    ) {
        Thread({
            val result = scanBlocking(context, onProgress)
            onDone(result)
        }, "NodeScanner").start()
    }

    // ── Core scan logic ───────────────────────────────────────────────────────

    private fun scanBlocking(context: Context, emit: (String) -> Unit): ScanResult {

        emit("── Starting node scan ──")

        // 1. Require privilege
        val method = ChargingController.availableMethod()
        if (method == ChargingController.Method.NONE) {
            emit("✗ No root or Shizuku — cannot write sysfs nodes.")
            emit("  Grant access first, then try scanning again.")
            return ScanResult(null, null, null, emptyList(), emptyList())
        }
        emit("🔑 Privilege: $method")

        // 2. Require charger plugged in
        val baseline = PowerReader.read(context)
        if (!baseline.isPlugged) {
            emit("⚠ Charger is not plugged in.")
            emit("  Plug in the charger and tap Scan again.")
            return ScanResult(null, null, null, emptyList(), emptyList())
        }
        val baselineMa = baseline.currentMa
        emit("📡 Baseline current : ${baseline.currentStr}")
        emit("🔋 Baseline percent : ${baseline.percent}%")

        if (baselineMa < 30) {
            emit("⚠ Current is very low (${baseline.currentStr}).")
            emit("  Battery may be nearly full — drop detection may miss.")
        }

        // 3. Discover power_supply directories (symlinks included)
        val psRoot = File("/sys/class/power_supply")
        val psDirs: List<File> = try {
            (psRoot.listFiles() ?: emptyArray()).toList()
        } catch (e: Exception) {
            emit("✗ Cannot read /sys/class/power_supply: ${e.message}")
            return ScanResult(null, null, null, emptyList(), emptyList())
        }
        emit("📂 Found dirs: ${psDirs.map { it.name }}")

        // 4. Build candidate list — resolve symlinks before listing children
        val candidates = mutableListOf<Triple<String, String, String>>()
        for (dir in psDirs) {
            val resolved = try { dir.canonicalFile } catch (_: Exception) { dir }
            for ((pattern, values) in PATTERNS) {
                val f = File(resolved, pattern)
                if (f.exists()) {
                    val currentVal = readNode(f.absolutePath)
                    candidates += Triple(f.absolutePath, values.first, values.second)
                    emit("  candidate: ${f.absolutePath}  [now=$currentVal]")
                }
            }
        }

        if (candidates.isEmpty()) {
            emit("")
            emit("✗ No matching node names found on this device.")
            emit("  Listing all files under each power_supply dir for manual inspection:")
            for (dir in psDirs) {
                val resolved = try { dir.canonicalFile } catch (_: Exception) { dir }
                val files = try { resolved.listFiles()?.map { it.name } ?: emptyList() } catch (_: Exception) { emptyList() }
                emit("  ${dir.name}: $files")
            }
            return ScanResult(null, null, null, emptyList(), emptyList())
        }

        emit("🔍 Testing ${candidates.size} candidate(s)…")

        // 5. Test each candidate — ALWAYS restore in finally
        for ((path, disableVal, enableVal) in candidates) {
            emit("")
            emit("▶ $path")
            emit("  disable=\"$disableVal\"  enable=\"$enableVal\"")

            var wrote = false
            try {
                // Write disable value
                wrote = ChargingController.execCmd("echo $disableVal > $path")
                if (!wrote) {
                    // Some kernels return non-zero even on a successful sysfs write.
                    // Verify by reading the node back before giving up.
                    val readback = readNode(path)
                    if (readback == disableVal) {
                        emit("  ⚠ execCmd returned false but readback matches — proceeding")
                        wrote = true
                    } else {
                        emit("  ✗ Write failed (readback=$readback) — skipping")
                        continue
                    }
                }
                val writtenBack = readNode(path)
                emit("  ✓ Wrote disable value  [node now=$writtenBack]")

                // Wait for hardware to respond — 5 s gives sluggish drivers time to react
                emit("  ⏳ Waiting 5 s…")
                TimeUnit.SECONDS.sleep(5)

                val after = PowerReader.read(context)
                emit("  Current after : ${after.currentStr}")
                emit("  Plugged       : ${after.isPlugged}")
                emit("  Charging      : ${after.isCharging}")

                val drop = if (baselineMa > 10.0)
                    (baselineMa - after.currentMa) / baselineMa
                else 0.0
                emit("  Current drop  : ${(drop * 100).toInt()}%")

                // Match criteria — any one is sufficient:
                //  a) Relative current drop ≥ 40 % (was 55 %; lowered for devices that
                //     throttle rather than cut completely in the first few seconds).
                //  b) Absolute current fell below 50 mA while baseline was > 100 mA.
                //  c) Android BatteryManager stopped reporting Charging/Full while the
                //     charger cable is still physically connected — the most reliable
                //     signal on devices where sysfs current reads are unreliable.
                val matchByDrop     = drop >= 0.40
                val matchByAbsolute = baselineMa > 100 && after.currentMa < 50.0
                val matchByStatus   = after.isPlugged && !after.isCharging

                if (matchByDrop || matchByAbsolute || matchByStatus) {
                    val reason = when {
                        matchByDrop     -> "current drop ${(drop * 100).toInt()}%"
                        matchByAbsolute -> "current fell to ${after.currentStr}"
                        else            -> "BatteryManager status changed to not-charging"
                    }
                    // ── Found it ──
                    emit("")
                    emit("✅ MATCH: $path  ($reason)")
                    emit("   disable=\"$disableVal\"  enable=\"$enableVal\"")

                    // Restore before saving
                    ChargingController.execCmd("echo $enableVal > $path")
                    emit("  ↩ Restored \"$enableVal\"")

                    context.getSharedPreferences("settings", Context.MODE_PRIVATE)
                        .edit()
                        .putString("discovered_node",        path)
                        .putString("discovered_disable_val", disableVal)
                        .putString("discovered_enable_val",  enableVal)
                        .apply()

                    emit("💾 Saved to preferences.")
                    return ScanResult(path, disableVal, enableVal, candidates.map { it.first }, emptyList())
                }

                emit("  ✗ No match (drop=${(drop*100).toInt()}%, charging=${after.isCharging}) — not this node")

            } catch (e: InterruptedException) {
                emit("  ⚠ Scan interrupted")
                Log.w(TAG, "scan interrupted at $path")
            } catch (e: Exception) {
                emit("  ✗ Exception: ${e.message}")
                Log.e(TAG, "scan exception at $path", e)
            } finally {
                // ALWAYS restore — even if an exception was thrown above
                if (wrote) {
                    val restoreOk = ChargingController.execCmd("echo $enableVal > $path")
                    emit("  ↩ Restore \"$enableVal\" → ${if (restoreOk) "OK" else "FAILED"}")
                    if (!restoreOk) {
                        emit("  ⚠ Restore failed — run Fix Stuck Battery Reading to recover")
                    }
                }
            }
        }

        emit("")
        emit("✗ No working node found.")
        emit("  All ${candidates.size} candidate(s) tested — none stopped charging.")
        emit("  Listing raw node names again for manual review:")
        for ((path, _, _) in candidates) emit("  $path")

        return ScanResult(null, null, null, candidates.map { it.first }, emptyList())
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun readNode(path: String): String = try {
        File(path).readText().trim()
    } catch (_: Exception) { "?" }
}
