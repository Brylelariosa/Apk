package com.batteryguard

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class BatteryService : Service() {

    companion object {
        const val CHANNEL_PERSISTENT = "bg_persistent"
        const val CHANNEL_ALERT      = "bg_alert"
        const val NOTIF_PERSISTENT   = 1
        const val NOTIF_ALERT        = 2
        const val NOTIF_LOW_BATTERY  = 3
        const val ACTION_UPDATE_UI   = "com.batteryguard.UPDATE_UI"
        const val ACTION_SNOOZE      = "com.batteryguard.SNOOZE"
        private const val POLL_MS    = 5_000L
        private const val SNOOZE_MS  = 15 * 60 * 1_000L
    }

    private var batteryReceiver: BroadcastReceiver? = null
    private var lastLowAlertFired = false

    // ── Charger state machine ────────────────────────────────────────────────
    //
    // After sysfs disables charging, isPlugged stays TRUE (cable still in)
    // but isCharging may flip to false. We cannot rely on isCharging to
    // detect "was the charger physically pulled?" — only isPlugged is reliable.
    //
    // State:
    //   weDisabledCharging = false → normal operation, let Android control charging
    //   weDisabledCharging = true  → we wrote sysfs to stop charging;
    //                                 only re-enable on physical unplug+replug
    //
    @Volatile private var weDisabledCharging = false
    private var wasPlugged = false   // tracks EXTRA_PLUGGED across ticks

    @Volatile private var snoozedUntil = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val pollRunnable = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, POLL_MS)
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        prefs().edit().putBoolean("service_running", true).apply()

        createChannels()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_PERSISTENT,
                buildPersistentNotif(getString(R.string.notif_monitoring), 0),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_PERSISTENT,
                buildPersistentNotif(getString(R.string.notif_monitoring), 0))
        }

        // Seed wasPlugged from current state so the first tick doesn't
        // falsely fire a "just plugged in" or "just unplugged" event.
        wasPlugged = PowerReader.read(this).isPlugged

        registerBatteryReceiver()
        handler.post(pollRunnable)
        ChargingController.verifyRootInBackground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SNOOZE) {
            snoozedUntil = SystemClock.elapsedRealtime() + SNOOZE_MS
            getSystemService(NotificationManager::class.java).cancel(NOTIF_ALERT)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        // If we had disabled charging, restore it before the service goes away
        // so the user doesn't end up with a permanently unchargeable phone.
        if (weDisabledCharging) ChargingController.enableCharging(this)
        handler.removeCallbacks(pollRunnable)
        batteryReceiver?.let { unregisterReceiver(it) }
        prefs().edit().putBoolean("service_running", false).apply()
    }

    // ── Core poll loop ─────────────────────────────────────────────────────────

    private fun tick() {
        val info         = PowerReader.read(this)
        val prefs        = prefs()
        val threshold    = prefs.getInt("threshold",     100)
        val lowThreshold = prefs.getInt("low_threshold",  20)

        // Persistent notification
        val wStr      = if (info.watts >= 0.05) " · ${info.wattsStr}" else ""
        val statusStr = if (info.isCharging) "Charging" else "On Battery"
        updatePersistentNotif("${info.percent}%  ·  $statusStr$wStr", info.percent)
        sendBroadcast(Intent(ACTION_UPDATE_UI))

        // ── Charger plug/unplug edge detection ────────────────────────────────
        val justUnplugged = wasPlugged  && !info.isPlugged
        val justPluggedIn = !wasPlugged && info.isPlugged
        wasPlugged = info.isPlugged

        // ── Re-enable logic (must run BEFORE the disable logic below) ─────────
        if (weDisabledCharging) {
            when {
                justUnplugged -> {
                    // Physical unplug: restore sysfs so the NEXT plug-in charges normally.
                    weDisabledCharging = false
                    ChargingController.enableCharging(this)
                }
                justPluggedIn && info.percent < threshold -> {
                    // Replugged while below the limit (e.g. user swapped chargers) → re-enable
                    weDisabledCharging = false
                    ChargingController.enableCharging(this)
                }
                // Still plugged in and still at/above threshold → stay disabled, do nothing
            }
            // While weDisabledCharging, skip the disable-trigger block below
            // to avoid a re-fire loop.
        } else {
            // ── High-threshold disable trigger ────────────────────────────────
            val isSnoozed = SystemClock.elapsedRealtime() < snoozedUntil
            // Use isPlugged (physical connection) as the primary charge indicator
            // rather than isCharging, because after sysfs disables charging the OS
            // may still briefly report isCharging = true on some devices.
            if (!isSnoozed && info.isPlugged && info.percent >= threshold) {
                ChargingController.disableCharging(this) { success ->
                    handler.post {
                        if (success) {
                            weDisabledCharging = true
                        }
                        val wattStr = if (info.watts >= 0.05) " (${info.wattsStr})" else ""
                        if (success) {
                            sendHighAlert(
                                getString(R.string.alert_stopped_title, info.percent, wattStr),
                                getString(R.string.alert_stopped_body),
                                loud = false
                            )
                        } else if (ChargingController.availableMethod() == ChargingController.Method.NONE) {
                            sendHighAlert(
                                getString(R.string.alert_unplug_title, info.percent, wattStr),
                                getString(R.string.alert_unplug_body),
                                loud = true
                            )
                        } else {
                            sendHighAlert(
                                getString(R.string.alert_failed_title, info.percent),
                                getString(R.string.alert_failed_body),
                                loud = true
                            )
                        }
                    }
                }
            }
        }

        // ── Low battery alert ──────────────────────────────────────────────────
        if (!info.isCharging && !info.isPlugged && info.percent <= lowThreshold && !lastLowAlertFired) {
            lastLowAlertFired = true
            sendLowBatteryAlert(info.percent)
        } else if (info.percent > lowThreshold + 5) {
            lastLowAlertFired = false
        }
    }

    // ── Receiver ──────────────────────────────────────────────────────────────

    private fun registerBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                handler.removeCallbacks(pollRunnable)
                tick()
                handler.postDelayed(pollRunnable, POLL_MS)
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    // ── Notification helpers ───────────────────────────────────────────────────

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PERSISTENT,
                getString(R.string.notif_channel_persistent_name),
                NotificationManager.IMPORTANCE_LOW)
                .apply { description = getString(R.string.notif_channel_persistent_desc) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT,
                getString(R.string.notif_channel_alert_name),
                NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = getString(R.string.notif_channel_alert_desc)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 400, 150, 400, 150, 400)
                }
        )
    }

    private fun buildPersistentNotif(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_PERSISTENT)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(100, progress, false)
            .build()
    }

    private fun updatePersistentNotif(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_PERSISTENT, buildPersistentNotif(text, progress))
    }

    private fun sendHighAlert(title: String, body: String, loud: Boolean) {
        val tapPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(tapPi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)

        if (loud) {
            val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(sound)
            builder.setVibrate(longArrayOf(0, 600, 200, 600, 200, 600))

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION") getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 600, 200, 600), -1))
            }

            val snoozePi = PendingIntent.getService(
                this, 0,
                Intent(this, BatteryService::class.java).apply { action = ACTION_SNOOZE },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(
                NotificationCompat.Action(0, getString(R.string.btn_snooze), snoozePi)
            )
        }

        getSystemService(NotificationManager::class.java).notify(NOTIF_ALERT, builder.build())
    }

    private fun sendLowBatteryAlert(percent: Int) {
        val tapPi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val title = getString(R.string.alert_low_battery_title, percent)
        val body  = getString(R.string.alert_low_battery_body)
        val notif = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(tapPi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_LOW_BATTERY, notif)
    }

    private fun prefs() = getSharedPreferences("settings", MODE_PRIVATE)
}
