#include <jni.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <GLES2/gl2.h>
#include <EGL/egl.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <thread>
#include <mutex>
#include <atomic>
#include <memory>
#include <fstream>
#include <vector>
#include "core/gba.h"

#define TAG "CustomGBA"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__)

struct EGLCtx {
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    GLuint tex=0, prog=0, vbo=0;
};

struct AudioCtx {
    SLObjectItf engine=nullptr, mix=nullptr, player=nullptr;
    SLPlayItf play=nullptr;
    SLAndroidSimpleBufferQueueItf bq=nullptr;
    static constexpr int NUM_BUFS=4, BUF_FRAMES=2048;
    float bufs[NUM_BUFS][BUF_FRAMES*2]={};
    int   bufIdx=0;
};

static struct {
    std::unique_ptr<GBA> gba;
    std::mutex           mu;
    std::thread          emuThread;
    std::atomic<bool>    running{false};
    std::atomic<bool>    paused {false};
    ANativeWindow*       window = nullptr;
    EGLCtx               egl;
    AudioCtx             audio;
    JavaVM*              jvm    = nullptr;
    jobject              cbObj  = nullptr;
    jmethodID            cbMID  = nullptr;
    std::atomic<int>     frameCount{0};
    std::atomic<int>     renderCount{0};
} G;

// ─── Shaders ─────────────────────────────────────────────────────────────────
static const char* VS = R"(attribute vec4 p;attribute vec2 u;varying vec2 v;
void main(){gl_Position=p;v=u;})";
static const char* FS = R"(precision mediump float;uniform sampler2D t;varying vec2 v;
void main(){gl_FragColor=texture2D(t,v);})";

static GLuint makeShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512]; glGetShaderInfoLog(s, 512, nullptr, buf);
        LOGE("[EGL] Shader compile FAILED: %s", buf);
    } else {
        LOGD("[EGL] Shader compiled OK (type=%d)", type);
    }
    return s;
}

// ─── EGL ─────────────────────────────────────────────────────────────────────
static bool eglInit(ANativeWindow* win, EGLCtx& e) {
    LOGI("[EGL] Init start. window=%p", win);
    if (!win) { LOGE("[EGL] NULL window — skipping EGL init"); return false; }

    e.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (e.display == EGL_NO_DISPLAY) { LOGE("[EGL] eglGetDisplay FAILED"); return false; }

    EGLint major=0, minor=0;
    if (!eglInitialize(e.display, &major, &minor)) {
        LOGE("[EGL] eglInitialize FAILED err=0x%x", eglGetError()); return false;
    }
    LOGI("[EGL] EGL %d.%d", major, minor);

    const EGLint a[] = { EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
        EGL_RED_SIZE,8, EGL_GREEN_SIZE,8, EGL_BLUE_SIZE,8, EGL_NONE };
    EGLConfig cfg; EGLint n=0;
    if (!eglChooseConfig(e.display, a, &cfg, 1, &n) || n==0) {
        LOGE("[EGL] eglChooseConfig FAILED err=0x%x", eglGetError()); return false;
    }

    const EGLint ca[] = { EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE };
    e.context = eglCreateContext(e.display, cfg, EGL_NO_CONTEXT, ca);
    if (e.context == EGL_NO_CONTEXT) {
        LOGE("[EGL] eglCreateContext FAILED err=0x%x", eglGetError()); return false;
    }

    e.surface = eglCreateWindowSurface(e.display, cfg, win, nullptr);
    if (e.surface == EGL_NO_SURFACE) {
        LOGE("[EGL] eglCreateWindowSurface FAILED err=0x%x", eglGetError()); return false;
    }

    if (!eglMakeCurrent(e.display, e.surface, e.surface, e.context)) {
        LOGE("[EGL] eglMakeCurrent FAILED err=0x%x", eglGetError()); return false;
    }

    LOGI("[EGL] GL_RENDERER=%s GL_VERSION=%s",
         glGetString(GL_RENDERER), glGetString(GL_VERSION));
    LOGI("[EGL] Window %dx%d",
         ANativeWindow_getWidth(win), ANativeWindow_getHeight(win));

    GLuint vs = makeShader(GL_VERTEX_SHADER, VS);
    GLuint fs = makeShader(GL_FRAGMENT_SHADER, FS);
    e.prog = glCreateProgram();
    glAttachShader(e.prog, vs); glAttachShader(e.prog, fs);
    glLinkProgram(e.prog);
    GLint linked=0; glGetProgramiv(e.prog, GL_LINK_STATUS, &linked);
    if (!linked) {
        char buf[512]; glGetProgramInfoLog(e.prog, 512, nullptr, buf);
        LOGE("[EGL] Link FAILED: %s", buf); return false;
    }
    glDeleteShader(vs); glDeleteShader(fs);
    LOGD("[EGL] Shader program linked (prog=%u)", e.prog);

    static const float q[] = {
        -1,-1,0,1,  1,-1,1,1,  -1,1,0,0,
         1,-1,1,1, -1, 1,0,0,   1,1,1,0 };
    glGenBuffers(1, &e.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, e.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(q), q, GL_STATIC_DRAW);

    glGenTextures(1, &e.tex);
    glBindTexture(GL_TEXTURE_2D, e.tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, GBA_W, GBA_H,
                 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    LOGI("[EGL] Texture %dx%d OK (tex=%u)", GBA_W, GBA_H, e.tex);
    return true;
}

static void eglRender(EGLCtx& e, ANativeWindow* win, const u32* fb) {
    if (e.display == EGL_NO_DISPLAY || !win) {
        LOGW("[EGL] Render skipped display=%p win=%p", (void*)e.display, win);
        return;
    }
    glViewport(0, 0, ANativeWindow_getWidth(win), ANativeWindow_getHeight(win));
    glClearColor(0,0,0,1);
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(e.prog);
    glBindBuffer(GL_ARRAY_BUFFER, e.vbo);
    GLint ap = glGetAttribLocation(e.prog,"p"), au = glGetAttribLocation(e.prog,"u");
    glEnableVertexAttribArray(ap);
    glVertexAttribPointer(ap,2,GL_FLOAT,GL_FALSE,4*4,0);
    glEnableVertexAttribArray(au);
    glVertexAttribPointer(au,2,GL_FLOAT,GL_FALSE,4*4,(void*)(8));
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, e.tex);
    glTexSubImage2D(GL_TEXTURE_2D,0,0,0,GBA_W,GBA_H,GL_RGBA,GL_UNSIGNED_BYTE,fb);
    glUniform1i(glGetUniformLocation(e.prog,"t"), 0);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    GLenum err = glGetError();
    if (err != GL_NO_ERROR) LOGE("[EGL] GL error 0x%x", err);
    if (!eglSwapBuffers(e.display, e.surface))
        LOGE("[EGL] eglSwapBuffers FAILED 0x%x", eglGetError());
    G.renderCount++;
    if (G.renderCount==1 || G.renderCount%60==0)
        LOGI("[EGL] Rendered frame #%d", G.renderCount.load());
}

static void eglDestroy(EGLCtx& e) {
    LOGI("[EGL] Destroying");
    if (e.display == EGL_NO_DISPLAY) return;
    eglMakeCurrent(e.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (e.tex)  glDeleteTextures(1, &e.tex);
    if (e.prog) glDeleteProgram(e.prog);
    if (e.vbo)  glDeleteBuffers(1, &e.vbo);
    eglDestroyContext(e.display, e.context);
    eglDestroySurface(e.display, e.surface);
    eglTerminate(e.display);
    e.display = EGL_NO_DISPLAY;
}

// ─── Audio ────────────────────────────────────────────────────────────────────
static void audioCallback(SLAndroidSimpleBufferQueueItf, void*) {
    auto& a = G.audio;
    memset(a.bufs[a.bufIdx%AudioCtx::NUM_BUFS], 0, sizeof(a.bufs[0]));
    (*a.bq)->Enqueue(a.bq, a.bufs[a.bufIdx%AudioCtx::NUM_BUFS], AudioCtx::BUF_FRAMES*8);
    a.bufIdx++;
}

static void audioInit(AudioCtx& a) {
    LOGI("[Audio] Init OpenSL ES");
    SLresult r = slCreateEngine(&a.engine, 0, nullptr, 0, nullptr, nullptr);
    if (r != SL_RESULT_SUCCESS) { LOGE("[Audio] slCreateEngine FAILED %d", r); return; }
    (*a.engine)->Realize(a.engine, SL_BOOLEAN_FALSE);
    SLEngineItf eng;
    (*a.engine)->GetInterface(a.engine, SL_IID_ENGINE, &eng);
    (*eng)->CreateOutputMix(eng, &a.mix, 0, nullptr, nullptr);
    (*a.mix)->Realize(a.mix, SL_BOOLEAN_FALSE);
    SLDataLocator_AndroidSimpleBufferQueue lbq={SL_DATALOCATOR_ANDROIDSIMPLEBUFFERQUEUE,AudioCtx::NUM_BUFS};
    SLDataFormat_PCM fmt={SL_DATAFORMAT_PCM,2,SL_SAMPLINGRATE_32,
        SL_PCMSAMPLEFORMAT_FIXED_16,SL_PCMSAMPLEFORMAT_FIXED_16,
        SL_SPEAKER_FRONT_LEFT|SL_SPEAKER_FRONT_RIGHT,SL_BYTEORDER_LITTLEENDIAN};
    SLDataSource src={&lbq,&fmt};
    SLDataLocator_OutputMix lm={SL_DATALOCATOR_OUTPUTMIX,a.mix};
    SLDataSink sink={&lm,nullptr};
    const SLInterfaceID ids[]={SL_IID_ANDROIDSIMPLEBUFFERQUEUE};
    const SLboolean req[]={SL_BOOLEAN_TRUE};
    r = (*eng)->CreateAudioPlayer(eng, &a.player, &src, &sink, 1, ids, req);
    if (r != SL_RESULT_SUCCESS) { LOGE("[Audio] CreateAudioPlayer FAILED %d", r); return; }
    (*a.player)->Realize(a.player, SL_BOOLEAN_FALSE);
    (*a.player)->GetInterface(a.player, SL_IID_PLAY, &a.play);
    (*a.player)->GetInterface(a.player, SL_IID_ANDROIDSIMPLEBUFFERQUEUE, &a.bq);
    (*a.bq)->RegisterCallback(a.bq, audioCallback, nullptr);
    memset(a.bufs, 0, sizeof(a.bufs));
    for (int i=0;i<AudioCtx::NUM_BUFS;i++)
        (*a.bq)->Enqueue(a.bq, a.bufs[i], AudioCtx::BUF_FRAMES*8);
    r = (*a.play)->SetPlayState(a.play, SL_PLAYSTATE_PLAYING);
    LOGI("[Audio] %s", r==SL_RESULT_SUCCESS ? "Playing OK" : "SetPlayState FAILED");
}

// ─── ROM header dump ──────────────────────────────────────────────────────────
static void dumpROMHeader(const std::vector<u8>& rom) {
    if (rom.size() < 0xC0) {
        LOGW("[ROM] Too small for valid GBA header (%zu bytes)", rom.size()); return;
    }
    char title[13]={}, code[5]={}, maker[3]={};
    memcpy(title, rom.data()+0xA0, 12);
    memcpy(code,  rom.data()+0xAC, 4);
    memcpy(maker, rom.data()+0xB0, 2);
    u32 entry = rom[0]|(rom[1]<<8)|(rom[2]<<16)|(rom[3]<<24);
    bool logoOK = rom[0x04]==0x24 && rom[0x05]==0xFF &&
                  rom[0x06]==0xAE && rom[0x07]==0x51;
    LOGI("[ROM] ── Header ────────────────────────────");
    LOGI("[ROM] Size      : %zu bytes (%.2f MB)", rom.size(), rom.size()/1048576.0f);
    LOGI("[ROM] Title     : '%.12s'", title);
    LOGI("[ROM] Game Code : '%.4s'", code);
    LOGI("[ROM] Maker     : '%.2s'", maker);
    LOGI("[ROM] Entry     : 0x%08X", entry);
    LOGI("[ROM] Fixed 0x96: 0x%02X %s", rom[0xB2], rom[0xB2]==0x96?"OK":"BAD");
    LOGI("[ROM] Logo check: %s", logoOK?"PASS":"FAIL");
    LOGI("[ROM] Checksum  : 0x%02X", rom[0xBD]);
    LOGI("[ROM] ──────────────────────────────────────");
}

// ─── Emulator thread ─────────────────────────────────────────────────────────
static void emuLoop() {
    LOGI("[EMU] Thread started");
    JNIEnv* env = nullptr;
    if (G.jvm->AttachCurrentThread(&env, nullptr) != JNI_OK) {
        LOGE("[EMU] AttachCurrentThread FAILED"); return;
    }

    bool eglOK = eglInit(G.window, G.egl);
    LOGI("[EMU] EGL init: %s", eglOK ? "OK" : "FAILED");

    audioInit(G.audio);

    G.gba->onFrameReady = [&](const u32* fb, int w, int h) {
        G.frameCount++;
        if (G.frameCount==1) LOGI("[EMU] *** FIRST FRAME RENDERED *** (%dx%d)", w, h);
        if (G.frameCount%60==0)
            LOGI("[EMU] frame#%d PC=0x%08X CPSR=0x%08X halted=%d",
                 G.frameCount.load(),
                 G.gba->cpu.r[15], G.gba->cpu.cpsr,
                 G.gba->cpu.halted);
        eglRender(G.egl, G.window, fb);
        if (G.cbObj && G.cbMID) env->CallVoidMethod(G.cbObj, G.cbMID);
    };

    G.gba->onAudioReady = [&](const float* buf, int frames) {
        auto& a = G.audio;
        if (!a.bq) return;
        int idx = a.bufIdx % AudioCtx::NUM_BUFS;
        int16_t* dst = reinterpret_cast<int16_t*>(a.bufs[idx]);
        for (int i=0;i<frames*2;i++) dst[i]=(int16_t)(buf[i]*32767.0f);
        (*a.bq)->Enqueue(a.bq, a.bufs[idx], frames*4);
        a.bufIdx++;
    };

    LOGI("[EMU] Entering main loop...");
    int iter=0;
    while (G.running) {
        if (G.paused) {
            if (iter%200==0) LOGD("[EMU] Paused (iter=%d)", iter);
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
            iter++; continue;
        }
        {
            std::lock_guard<std::mutex> lk(G.mu);
            if (G.gba) G.gba->runFrame();
            else LOGE("[EMU] GBA null!");
        }
        iter++;
        if (iter==1)  LOGI("[EMU] First runFrame done. frameCount=%d", G.frameCount.load());
        if (iter==10) LOGI("[EMU] 10 frames done. frameCount=%d renderCount=%d",
                            G.frameCount.load(), G.renderCount.load());
        if (iter%300==0)
            LOGI("[EMU] iter=%d frames=%d renders=%d window=%p paused=%d",
                 iter, G.frameCount.load(), G.renderCount.load(),
                 G.window, G.paused.load());
    }

    LOGI("[EMU] Loop done. frames=%d renders=%d", G.frameCount.load(), G.renderCount.load());
    eglDestroy(G.egl);
    if (G.audio.player) { (*G.audio.player)->Destroy(G.audio.player); G.audio.player=nullptr; }
    if (G.audio.mix)    { (*G.audio.mix)->Destroy(G.audio.mix);       G.audio.mix=nullptr; }
    if (G.audio.engine) { (*G.audio.engine)->Destroy(G.audio.engine); G.audio.engine=nullptr; }
    G.jvm->DetachCurrentThread();
    LOGI("[EMU] Thread exited");
}

// ─── JNI exports ─────────────────────────────────────────────────────────────
extern "C" {

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    G.jvm = vm;
    LOGI("══ Custom GBA JNI loaded ══");
    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeInit(JNIEnv* env, jobject thiz) {
    LOGI("[INIT] nativeInit");
    G.gba = std::make_unique<GBA>();
    G.gba->init();
    G.cbObj = env->NewGlobalRef(thiz);
    jclass cls = env->GetObjectClass(thiz);
    G.cbMID = env->GetMethodID(cls, "onFrameReady", "()V");
    G.frameCount=0; G.renderCount=0;
    LOGI("[INIT] Done. cbMID=%p", (void*)G.cbMID);
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeLoadROM(JNIEnv* env, jobject, jstring jpath) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    LOGI("[ROM] Loading: %s", path);
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        LOGE("[ROM] Cannot open file!"); env->ReleaseStringUTFChars(jpath,path); return JNI_FALSE;
    }
    std::vector<u8> data((std::istreambuf_iterator<char>(f)),{});
    LOGI("[ROM] Read %zu bytes", data.size());
    env->ReleaseStringUTFChars(jpath, path);
    dumpROMHeader(data);
    std::lock_guard<std::mutex> lk(G.mu);
    bool ok = G.gba->loadROM(data.data(), data.size());
    LOGI("[ROM] %s — PC=0x%08X CPSR=0x%08X",
         ok?"LOADED OK":"FAILED", G.gba->cpu.r[15], G.gba->cpu.cpsr);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetSurface(JNIEnv* env, jobject, jobject surf) {
    if (surf) {
        G.window = ANativeWindow_fromSurface(env, surf);
        LOGI("[SURFACE] Set window=%p size=%dx%d",
             G.window, ANativeWindow_getWidth(G.window), ANativeWindow_getHeight(G.window));
    } else {
        LOGI("[SURFACE] Cleared");
        if (G.window) ANativeWindow_release(G.window);
        G.window = nullptr;
    }
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeStart(JNIEnv*, jobject) {
    LOGI("[START] running=%d window=%p gba=%p",
         G.running.load(), G.window, G.gba.get());
    if (G.running) { LOGW("[START] Already running"); return; }
    if (!G.window) LOGW("[START] No surface yet — rendering may fail");
    if (!G.gba)    { LOGE("[START] GBA null!"); return; }
    G.running=true; G.paused=false;
    G.frameCount=0; G.renderCount=0;
    G.emuThread = std::thread(emuLoop);
    LOGI("[START] Thread launched");
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeStop(JNIEnv*, jobject) {
    LOGI("[STOP] frames=%d renders=%d", G.frameCount.load(), G.renderCount.load());
    G.running = false;
    if (G.emuThread.joinable()) { G.emuThread.join(); LOGI("[STOP] Thread joined"); }
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativePause(JNIEnv*, jobject, jboolean p) {
    G.paused = (p==JNI_TRUE);
    LOGI("[PAUSE] paused=%d", G.paused.load());
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeSetKeys(JNIEnv*, jobject, jint keys) {
    std::lock_guard<std::mutex> lk(G.mu);
    if (G.gba) G.gba->setKeys((u16)keys);
}

JNIEXPORT void JNICALL
Java_com_customgba_EmulatorCore_nativeReset(JNIEnv*, jobject) {
    LOGI("[RESET] Resetting");
    std::lock_guard<std::mutex> lk(G.mu);
    if (G.gba) {
        G.gba->cpu.reset();
        G.frameCount=0; G.renderCount=0;
        LOGI("[RESET] PC=0x%08X", G.gba->cpu.r[15]);
    }
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeSaveState(JNIEnv* env, jobject, jstring jpath) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lk(G.mu);
    if (!G.gba) { env->ReleaseStringUTFChars(jpath,path); return JNI_FALSE; }
    std::ofstream f(path, std::ios::binary);
    f.write((char*)G.gba->cpu.r,     sizeof(G.gba->cpu.r));
    f.write((char*)&G.gba->cpu.cpsr, 4);
    f.write((char*)&G.gba->cpu.spsr, 4);
    f.write((char*)G.gba->mem.ewram, EWRAM_SIZE);
    f.write((char*)G.gba->mem.iwram, IWRAM_SIZE);
    f.write((char*)G.gba->mem.io,    IO_SIZE);
    f.write((char*)G.gba->mem.pal,   PAL_SIZE);
    f.write((char*)G.gba->mem.vram,  VRAM_SIZE);
    f.write((char*)G.gba->mem.oam,   OAM_SIZE);
    env->ReleaseStringUTFChars(jpath, path);
    bool ok = f.good(); LOGI("[STATE] Save %s", ok?"OK":"FAILED");
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_customgba_EmulatorCore_nativeLoadState(JNIEnv* env, jobject, jstring jpath) {
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    std::lock_guard<std::mutex> lk(G.mu);
    if (!G.gba) { env->ReleaseStringUTFChars(jpath,path); return JNI_FALSE; }
    std::ifstream f(path, std::ios::binary);
    f.read((char*)G.gba->cpu.r,      sizeof(G.gba->cpu.r));
    f.read((char*)&G.gba->cpu.cpsr,  4);
    f.read((char*)&G.gba->cpu.spsr,  4);
    f.read((char*)G.gba->mem.ewram,  EWRAM_SIZE);
    f.read((char*)G.gba->mem.iwram,  IWRAM_SIZE);
    f.read((char*)G.gba->mem.io,     IO_SIZE);
    f.read((char*)G.gba->mem.pal,    PAL_SIZE);
    f.read((char*)G.gba->mem.vram,   VRAM_SIZE);
    f.read((char*)G.gba->mem.oam,    OAM_SIZE);
    env->ReleaseStringUTFChars(jpath, path);
    bool ok=f.good();
    LOGI("[STATE] Load %s PC=0x%08X", ok?"OK":"FAILED", G.gba->cpu.r[15]);
    return ok ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
