package com.customgba

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.customgba.databinding.ActivityGameBinding
import com.customgba.databinding.ActivityMainBinding
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.*

// ── GBA buttons ───────────────────────────────────────────────────────────────
object GbaKeys {
    const val A      = 1 shl 0
    const val B      = 1 shl 1
    const val SELECT = 1 shl 2
    const val START  = 1 shl 3
    const val RIGHT  = 1 shl 4
    const val LEFT   = 1 shl 5
    const val UP     = 1 shl 6
    const val DOWN   = 1 shl 7
    const val R      = 1 shl 8
    const val L      = 1 shl 9
}

// ── ROM picker ────────────────────────────────────────────────────────────────
class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val path = cacheUri(uri) ?: return@registerForActivityResult run {
            Toast.makeText(this, "Failed to read ROM", Toast.LENGTH_SHORT).show()
        }
        startActivity(Intent(this, GameActivity::class.java).putExtra("rom", path))
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnLoad.setOnClickListener { picker.launch(arrayOf("*/*")) }
    }

    private fun cacheUri(uri: Uri): String? = try {
        val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
            c.moveToFirst()
            c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
        } ?: "rom.gba"
        val dest = File(cacheDir, name)
        contentResolver.openInputStream(uri)?.use { i ->
            FileOutputStream(dest).use { o -> i.copyTo(o) }
        }
        dest.absolutePath
    } catch (e: Exception) { null }
}

// ── Game screen ───────────────────────────────────────────────────────────────
class GameActivity : AppCompatActivity() {
    private lateinit var b: ActivityGameBinding
    private val core = EmulatorCore()
    private var keys = 0
    private lateinit var logFile: File

    private val handler = Handler(Looper.getMainLooper())
    private var debugVisible = true

    private val debugRunnable = object : Runnable {
        override fun run() {
            if (debugVisible) {
                b.tvDebug.text = core.getDebugInfo()
            }
            handler.postDelayed(this, 500)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        b = ActivityGameBinding.inflate(layoutInflater)
        setContentView(b.root)

        // ── Set up log file FIRST, before anything else ───────────────────
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        logFile = File(filesDir, "gba_debug_$ts.txt")
        core.setLogPath(logFile.absolutePath)
        core.init()

        // ── Java-side crash handler — writes to same log file ─────────────
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                logFile.appendText(
                    "\n══════════════════════════════════\n" +
                    "  *** JAVA CRASH ***\n" +
                    "  Thread: ${thread.name}\n" +
                    "  $sw\n" +
                    "══════════════════════════════════\n"
                )
            } catch (_: Exception) {}
            defaultHandler?.uncaughtException(thread, throwable)
        }

        // ── Tap game screen to toggle overlay ─────────────────────────────
        b.gameView.setOnClickListener { toggleDebug() }
        b.tvDebug.setOnClickListener  { toggleDebug() }

        // ── Surface callback ──────────────────────────────────────────────
        b.gameView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder)                    { core.setSurface(h.surface) }
            override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, h2: Int) {}
            override fun surfaceDestroyed(h: SurfaceHolder)                  { core.setSurface(null) }
        })

        // ── Load ROM ──────────────────────────────────────────────────────
        val rom = intent.getStringExtra("rom") ?: run { finish(); return }
        val loaded = core.loadROM(rom)
        if (!loaded) {
            b.tvDebug.text = "❌ ROM FAILED TO LOAD\n\nCheck log: ${logFile.name}\n(Menu → Share Log)"
            Toast.makeText(this, "ROM failed — see debug overlay", Toast.LENGTH_LONG).show()
            handler.post(debugRunnable)
            return
        }
        core.start()
        handler.post(debugRunnable)

        // ── Buttons ───────────────────────────────────────────────────────
        fun btn(v: View, bit: Int) = v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_POINTER_DOWN  -> keys = keys or bit
                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_POINTER_UP,
                MotionEvent.ACTION_CANCEL        -> keys = keys and bit.inv()
            }
            core.setKeys(keys)
            true
        }
        btn(b.btnA,      GbaKeys.A)
        btn(b.btnB,      GbaKeys.B)
        btn(b.btnL,      GbaKeys.L)
        btn(b.btnR,      GbaKeys.R)
        btn(b.btnStart,  GbaKeys.START)
        btn(b.btnSelect, GbaKeys.SELECT)
        btn(b.btnUp,     GbaKeys.UP)
        btn(b.btnDown,   GbaKeys.DOWN)
        btn(b.btnLeft,   GbaKeys.LEFT)
        btn(b.btnRight,  GbaKeys.RIGHT)

        // ── Menu ──────────────────────────────────────────────────────────
        b.btnMenu.setOnClickListener {
            core.pause(true)
            AlertDialog.Builder(this)
                .setTitle("Custom GBA")
                .setItems(arrayOf(
                    "Save State",
                    "Load State",
                    "Reset",
                    if (debugVisible) "Hide Debug" else "Show Debug",
                    "Share Log File",
                    "Quit"
                )) { _, which ->
                    when (which) {
                        0 -> {
                            val ok = core.saveState(File(filesDir, "state0.gbs").absolutePath)
                            Toast.makeText(this, if (ok) "Saved!" else "Save failed", Toast.LENGTH_SHORT).show()
                        }
                        1 -> {
                            val ok = core.loadState(File(filesDir, "state0.gbs").absolutePath)
                            Toast.makeText(this, if (ok) "Loaded!" else "No save found", Toast.LENGTH_SHORT).show()
                        }
                        2 -> core.reset()
                        3 -> toggleDebug()
                        4 -> shareLog()
                        5 -> finish()
                    }
                    core.pause(false)
                }
                .setOnCancelListener { core.pause(false) }
                .show()
        }
    }

    private fun toggleDebug() {
        debugVisible = !debugVisible
        b.tvDebug.visibility = if (debugVisible) View.VISIBLE else View.INVISIBLE
    }

    private fun shareLog() {
        if (!logFile.exists()) {
            Toast.makeText(this, "No log file yet", Toast.LENGTH_SHORT).show()
            return
        }
        // Copy to a shareable location
        val share = File(cacheDir, "gba_debug_share.txt")
        logFile.copyTo(share, overwrite = true)
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this, "${packageName}.provider", share
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Custom GBA Debug Log")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share Debug Log"))
    }

    override fun onPause()   { super.onPause();  core.pause(true);  handler.removeCallbacks(debugRunnable) }
    override fun onResume()  { super.onResume(); core.pause(false); handler.post(debugRunnable) }
    override fun onDestroy() { core.stop();      handler.removeCallbacks(debugRunnable); super.onDestroy() }
}
