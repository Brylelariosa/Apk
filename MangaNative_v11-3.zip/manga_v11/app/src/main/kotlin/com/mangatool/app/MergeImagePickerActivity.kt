package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.util.BitmapUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MergeImagePickerActivity : AppCompatActivity() {

    companion object {
        const val RESULT_URIS = "selected_uris"
    }

    private lateinit var albumsRecycler: RecyclerView
    private lateinit var photosRecycler: RecyclerView
    private lateinit var btnAdd: Button
    private lateinit var btnSelectAll: Button
    private lateinit var selectionBar: TextView
    private lateinit var tvCount: TextView
    private lateinit var tvTitle: TextView

    data class Album(
        val bucketId: Long,
        val bucketName: String,
        val count: Int,
        val thumbnailUri: Uri,
        val isAllPhotos: Boolean = false
    )

    data class DeviceImage(val uri: Uri, val id: Long, val bucketId: Long)

    private enum class ViewState { ALBUMS, PHOTOS }
    private var viewState = ViewState.ALBUMS

    private val allImages     = mutableListOf<DeviceImage>()
    private val currentPhotos = mutableListOf<DeviceImage>()
    private val albums        = mutableListOf<Album>()
    private val selectedUris  = linkedSetOf<String>()
    private var currentAlbum: Album? = null
    private var rangeAnchor: Int = -1

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) loadMedia()
        else tvCount.text = "Storage permission denied"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_merge_picker)

        albumsRecycler = findViewById(R.id.picker_albums)
        photosRecycler = findViewById(R.id.picker_grid)
        btnAdd         = findViewById(R.id.btn_add_selected)
        btnSelectAll   = findViewById(R.id.btn_select_all)
        selectionBar   = findViewById(R.id.tv_selection_bar)
        tvCount        = findViewById(R.id.tv_picker_count)
        tvTitle        = findViewById(R.id.tv_picker_title)

        findViewById<ImageButton>(R.id.btn_picker_back).setOnClickListener { handleBack() }
        btnAdd.setOnClickListener { returnSelected() }
        btnAdd.isEnabled = false
        btnSelectAll.setOnClickListener { toggleSelectAll() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { handleBack() }
        })

        checkAndLoad()
    }

    private fun handleBack() {
        when (viewState) {
            ViewState.ALBUMS -> finish()
            ViewState.PHOTOS -> showAlbumsView()
        }
    }

    private fun showAlbumsView() {
        viewState = ViewState.ALBUMS
        currentAlbum = null
        rangeAnchor = -1
        albumsRecycler.visibility = View.VISIBLE
        photosRecycler.visibility = View.GONE
        selectionBar.visibility   = View.GONE
        btnSelectAll.visibility   = View.GONE
        tvTitle.text = "Albums"
        tvCount.text = "${albums.size} albums"
    }

    private fun openAlbum(album: Album) {
        currentAlbum = album
        viewState = ViewState.PHOTOS
        rangeAnchor = -1

        currentPhotos.clear()
        currentPhotos.addAll(
            if (album.isAllPhotos) allImages
            else allImages.filter { it.bucketId == album.bucketId }
        )

        albumsRecycler.visibility = View.GONE
        photosRecycler.visibility = View.VISIBLE
        selectionBar.visibility   = View.VISIBLE
        btnSelectAll.visibility   = View.VISIBLE

        tvTitle.text = album.bucketName
        updateSelectAllLabel()
        refreshPhotosUI()
        setupPhotosGrid()
    }

    private fun checkAndLoad() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val ok = needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (ok) loadMedia() else permLauncher.launch(needed)
    }

    private fun loadMedia() {
        lifecycleScope.launch {
            tvCount.text = "Loading..."

            val images = withContext(Dispatchers.IO) {
                val result = mutableListOf<DeviceImage>()
                val proj = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.BUCKET_ID,
                    MediaStore.Images.Media.DATE_ADDED
                )
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    proj, null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { cursor ->
                    val idCol     = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                    while (cursor.moveToNext()) {
                        val id  = cursor.getLong(idCol)
                        val bId = cursor.getLong(bucketCol)
                        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                        result.add(DeviceImage(uri, id, bId))
                    }
                }
                result
            }

            allImages.clear()
            allImages.addAll(images)

            // Build albums from a second query that includes bucket names
            val bucketMap = withContext(Dispatchers.IO) {
                val map = linkedMapOf<Long, String>()
                val proj2 = arrayOf(
                    MediaStore.Images.Media.BUCKET_ID,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME
                )
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    proj2, null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { cursor ->
                    val bIdCol   = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                    val bNameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                    while (cursor.moveToNext()) {
                        val bId   = cursor.getLong(bIdCol)
                        val bName = cursor.getString(bNameCol) ?: "Unknown"
                        map.putIfAbsent(bId, bName)
                    }
                }
                map
            }

            albums.clear()
            if (allImages.isNotEmpty()) {
                albums.add(Album(-1L, "All Photos", allImages.size, allImages.first().uri, isAllPhotos = true))
            }
            bucketMap.forEach { (bId, bName) ->
                val photos = allImages.filter { it.bucketId == bId }
                if (photos.isNotEmpty()) {
                    albums.add(Album(bId, bName, photos.size, photos.first().uri))
                }
            }

            tvCount.text = "${albums.size} albums"
            setupAlbumsGrid()
        }
    }

    private fun setupAlbumsGrid() {
        val screenW  = resources.displayMetrics.widthPixels
        val cols     = if (screenW >= 900) 4 else 3
        val cellSize = (screenW - (cols + 1) * 6.dpToPx) / cols

        albumsRecycler.layoutManager = GridLayoutManager(this, cols)
        albumsRecycler.adapter = AlbumAdapter(cellSize)
    }

    inner class AlbumAdapter(private val cellSize: Int) : RecyclerView.Adapter<AlbumAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb:      ImageView = v.findViewById(R.id.album_thumb)
            val name:       TextView  = v.findViewById(R.id.album_name)
            val countBadge: TextView  = v.findViewById(R.id.album_count)
            val container:  View      = v.findViewById(R.id.album_thumb_container)
            var loadJob:    Job?      = null
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_album, parent, false)
            v.findViewById<View>(R.id.album_thumb_container).layoutParams =
                v.findViewById<View>(R.id.album_thumb_container).layoutParams.also { it.height = cellSize }
            return VH(v)
        }

        override fun getItemCount() = albums.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val album = albums[position]
            holder.name.text       = album.bucketName
            holder.countBadge.text = "${album.count}"

            // Set click listener FIRST — before any early return so recycled
            // views always have a fresh listener even when thumb is cached
            holder.itemView.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) openAlbum(albums[pos])
            }

            holder.thumb.setImageBitmap(null)
            holder.loadJob?.cancel()

            val cacheKey = "alb_${album.bucketId}"
            AppState.thumbCache.get(cacheKey)?.let {
                holder.thumb.setImageBitmap(it); return   // thumb cached, click already set above
            }
            holder.loadJob = lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    runCatching {
                        contentResolver.openInputStream(album.thumbnailUri)?.use { s ->
                            BitmapUtils.decodeThumbnail(s.readBytes(), 320)
                        }
                    }.getOrNull()
                }
                if (bmp != null) {
                    AppState.thumbCache.put(cacheKey, bmp)
                    holder.thumb.setImageBitmap(bmp)
                }
            }
        }

        override fun onViewRecycled(holder: VH) { holder.loadJob?.cancel(); super.onViewRecycled(holder) }
    }

    private fun setupPhotosGrid() {
        val cellSize = resources.displayMetrics.widthPixels / 3
        photosRecycler.layoutManager = GridLayoutManager(this, 3)
        photosRecycler.adapter = PickerAdapter(cellSize)
    }

    private fun toggleSelectAll() {
        val allSelected = currentPhotos.all { it.uri.toString() in selectedUris }
        if (allSelected) {
            currentPhotos.forEach { selectedUris.remove(it.uri.toString()) }
        } else {
            currentPhotos.forEach { selectedUris.add(it.uri.toString()) }
        }
        rangeAnchor = -1
        photosRecycler.adapter?.notifyDataSetChanged()
        refreshPhotosUI()
    }

    private fun updateSelectAllLabel() {
        val allSelected = currentPhotos.isNotEmpty() &&
                currentPhotos.all { it.uri.toString() in selectedUris }
        btnSelectAll.text = if (allSelected) "None" else "All"
    }

    private fun refreshPhotosUI() {
        val n       = selectedUris.size
        val inAlbum = currentPhotos.count { it.uri.toString() in selectedUris }
        btnAdd.isEnabled = n > 0
        btnAdd.text = if (n > 0) "Add $n image${if (n == 1) "" else "s"}" else "Add"
        selectionBar.text = when {
            n == 0      -> "Tap to select  \u00B7  long-press to range-select"
            inAlbum > 0 -> "$inAlbum selected here  \u00B7  $n total  \u00B7  long-press to range-select"
            else        -> "$n selected  \u00B7  long-press to range-select"
        }
        tvCount.text = "${currentPhotos.size} photos" +
                if (inAlbum > 0) "  \u00B7  $inAlbum selected" else ""
        updateSelectAllLabel()
    }

    private fun returnSelected() {
        if (selectedUris.isEmpty()) { finish(); return }
        setResult(Activity.RESULT_OK, Intent().apply {
            putStringArrayListExtra(RESULT_URIS, ArrayList(selectedUris))
        })
        finish()
    }

    inner class PickerAdapter(private val cellSize: Int) : RecyclerView.Adapter<PickerAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val image:   ImageView = v.findViewById(R.id.picker_thumb)
            val check:   View      = v.findViewById(R.id.picker_check)
            val overlay: View      = v.findViewById(R.id.picker_overlay)
            val badge:   TextView  = v.findViewById(R.id.picker_badge)
            var loadJob: Job?      = null
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_picker_thumb, parent, false)
            v.layoutParams = v.layoutParams.also { it.height = cellSize }
            return VH(v)
        }

        override fun getItemCount() = currentPhotos.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val img    = currentPhotos[position]
            val uriStr = img.uri.toString()
            val selected = uriStr in selectedUris

            holder.overlay.visibility = if (selected) View.VISIBLE else View.GONE
            holder.check.visibility   = if (selected) View.VISIBLE else View.GONE

            val selIdx = selectedUris.indexOf(uriStr)
            holder.badge.visibility = if (selIdx >= 0) View.VISIBLE else View.GONE
            if (selIdx >= 0) holder.badge.text = "${selIdx + 1}"

            holder.image.setImageBitmap(null)
            holder.loadJob?.cancel()

            val cacheKey = "pick_${img.id}"
            AppState.thumbCache.get(cacheKey)?.let {
                holder.image.setImageBitmap(it); return
            }
            holder.loadJob = lifecycleScope.launch {
                val bmp = withContext(Dispatchers.IO) {
                    runCatching {
                        contentResolver.openInputStream(img.uri)?.use { s ->
                            BitmapUtils.decodeThumbnail(s.readBytes(), 240)
                        }
                    }.getOrNull()
                }
                if (bmp != null) {
                    AppState.thumbCache.put(cacheKey, bmp)
                    holder.image.setImageBitmap(bmp)
                }
            }

            holder.itemView.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
                val img2   = currentPhotos[pos]
                val uriStr2 = img2.uri.toString()
                if (uriStr2 in selectedUris) selectedUris.remove(uriStr2)
                else selectedUris.add(uriStr2)
                rangeAnchor = pos
                notifyItemChanged(pos)
                refreshPhotosUI()
            }

            holder.itemView.setOnLongClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos == RecyclerView.NO_ID.toInt()) return@setOnLongClickListener true
                val uriStr2 = currentPhotos[pos].uri.toString()
                if (rangeAnchor < 0 || rangeAnchor == pos) {
                    rangeAnchor = pos
                    if (uriStr2 !in selectedUris) {
                        selectedUris.add(uriStr2)
                        notifyItemChanged(pos)
                    }
                } else {
                    val lo = minOf(rangeAnchor, pos)
                    val hi = maxOf(rangeAnchor, pos)
                    val anchorSelected = currentPhotos[rangeAnchor].uri.toString() in selectedUris
                    for (i in lo..hi) {
                        val u = currentPhotos[i].uri.toString()
                        if (anchorSelected) selectedUris.add(u) else selectedUris.remove(u)
                    }
                    notifyItemRangeChanged(lo, hi - lo + 1)
                    rangeAnchor = pos
                }
                refreshPhotosUI()
                true
            }
        }

        override fun onViewRecycled(holder: VH) { holder.loadJob?.cancel(); super.onViewRecycled(holder) }
    }

    private val Int.dpToPx get() = (this * resources.displayMetrics.density + 0.5f).toInt()
}

private fun <T> LinkedHashSet<T>.indexOf(element: T): Int {
    var i = 0; for (e in this) { if (e == element) return i; i++ }; return -1
}
