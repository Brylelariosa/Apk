#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <cmath>
#include <ctime>
#include <memory>

#include "core/Renderer.h"
#include "core/World.h"
#include "core/Camera.h"
#include "core/Input.h"
#include "core/BlockDefs.h"
#include "core/MathUtils.h"

#define LOG_TAG "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// ── Game state ────────────────────────────────────────────────────────────────
static std::unique_ptr<Renderer> g_renderer;
static std::unique_ptr<World>    g_world;
static std::unique_ptr<Camera>   g_camera;
static std::unique_ptr<Input>    g_input;

static int   g_width  = 1, g_height = 1;
static long  g_lastNs = 0;
static bool  g_inited = false;

// Physics
static float g_velY     = 0.f;
static bool  g_onGround = false;

// Block breaking (hold-to-break)
static Vec3  g_breakTarget   = {-9999, -9999, -9999};
static float g_breakProgress = 0.f;
static const float BREAK_TIME = 0.6f;   // seconds to break a block

// Settings
static int   g_renderDist = 5;          // default render distance in chunks

// FPS tracking
static float g_fpsTimer   = 0.f;
static int   g_fpsFrames  = 0;
static int   g_fpsDisplay = 0;

// Hotbar
static uint8_t g_hotbar[9] = {
    BLOCK_GRASS, BLOCK_DIRT, BLOCK_STONE,
    BLOCK_SAND,  BLOCK_LOG,  BLOCK_LEAVES,
    BLOCK_GLOWSTONE, BLOCK_LAVA, BLOCK_SNOW
};
static int g_hotbarSel = 0;

// ── Time ──────────────────────────────────────────────────────────────────────
static long nowNs() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000L + ts.tv_nsec;
}

// ── Physics helpers ───────────────────────────────────────────────────────────
static bool solidAt(const World* w, float x, float y, float z) {
    return blockSolid(w->getBlock((int)floorf(x), (int)floorf(y), (int)floorf(z)));
}

static bool playerOnGround(const World* w, Vec3 pos) {
    float feet = pos.y - 1.85f;
    for (float dx : {-0.28f, 0.28f})
        for (float dz : {-0.28f, 0.28f})
            if (solidAt(w, pos.x + dx, feet, pos.z + dz)) return true;
    return false;
}

static Vec3 collideMove(const World* w, Vec3 pos, Vec3 delta) {
    const float EY = 1.8f;

    // X
    float sx = delta.x > 0 ? 0.3f : -0.3f;
    Vec3 nx = {pos.x + delta.x, pos.y, pos.z};
    if (solidAt(w, nx.x+sx, pos.y - EY + 0.1f, pos.z) ||
        solidAt(w, nx.x+sx, pos.y - EY + 0.9f, pos.z) ||
        solidAt(w, nx.x+sx, pos.y - 0.1f,       pos.z))
        delta.x = 0;

    // Z
    float sz = delta.z > 0 ? 0.3f : -0.3f;
    Vec3 nz = {pos.x, pos.y, pos.z + delta.z};
    if (solidAt(w, pos.x, pos.y - EY + 0.1f, nz.z+sz) ||
        solidAt(w, pos.x, pos.y - EY + 0.9f, nz.z+sz) ||
        solidAt(w, pos.x, pos.y - 0.1f,       nz.z+sz))
        delta.z = 0;

    // Y down
    if (delta.y < 0) {
        float fy = pos.y - EY + delta.y;
        bool blocked = false;
        for (float ddx : {-0.28f, 0.28f})
            for (float ddz : {-0.28f, 0.28f})
                if (solidAt(w, pos.x+ddx, fy, pos.z+ddz)) blocked = true;
        if (blocked) { delta.y = 0; g_velY = 0; }
    }
    // Y up
    if (delta.y > 0) {
        if (solidAt(w, pos.x, pos.y + delta.y + 0.05f, pos.z)) {
            delta.y = 0; g_velY = 0;
        }
    }

    return pos + delta;
}

// ── Per-frame game tick ───────────────────────────────────────────────────────
static void gameTick(float dt) {
    if (!g_world || !g_camera || !g_input) return;
    if (dt > 0.1f) dt = 0.1f;

    // ── FPS counter ────────────────────────────────────────────────────────────
    g_fpsTimer  += dt;
    g_fpsFrames += 1;
    if (g_fpsTimer >= 0.5f) {
        g_fpsDisplay = (int)(g_fpsFrames / g_fpsTimer + 0.5f);
        g_fpsTimer   = 0.f;
        g_fpsFrames  = 0;
    }

    // ── Settings render distance buttons ──────────────────────────────────────
    if (g_input->isSettingsPlusTap())  g_renderDist = std::min(g_renderDist + 1, 32);
    if (g_input->isSettingsMinusTap()) g_renderDist = std::max(g_renderDist - 1, 2);

    // ── Camera look ────────────────────────────────────────────────────────────
    // FIX: removed negation on dy — dragging DOWN now looks DOWN (non-inverted)
    float dx = g_input->consumeDX() * -0.003f;   // yaw:   swipe right → turn right
    float dy = g_input->consumeDY() *  0.003f;   // pitch: swipe down  → look down ← FIXED
    g_camera->rotate(dx, dy);

    // ── Movement ───────────────────────────────────────────────────────────────
    Vec3 mov   = g_input->getMovement();
    float speed = 5.5f;
    Vec3 fwd   = g_camera->getForward(); fwd.y = 0; fwd = normalize(fwd);
    Vec3 rgt   = g_camera->getRight();   rgt.y = 0; rgt = normalize(rgt);

    Vec3 movWorld = rgt * (mov.x * speed * dt)
                  + fwd * (-mov.z * speed * dt);

    // ── Gravity & jump ─────────────────────────────────────────────────────────
    g_onGround = playerOnGround(g_world.get(), g_camera->getPosition());
    g_velY -= 22.f * dt;
    if (g_onGround && g_velY < 0.f) g_velY = 0.f;

    if (g_input->isJumpPressed()) {
        if (g_onGround) g_velY = 9.5f;
    }

    movWorld.y = g_velY * dt;
    Vec3 newPos = collideMove(g_world.get(), g_camera->getPosition(), movWorld);
    g_camera->setPosition(newPos);

    // ── Raycast target ─────────────────────────────────────────────────────────
    Vec3 eye = g_camera->getPosition();
    Vec3 dir = g_camera->getForward();
    Vec3 hitPos, hitNorm;
    bool hasTarget = g_world->raycast(eye, dir, 6.5f, hitPos, hitNorm);

    // ── Block PLACE ────────────────────────────────────────────────────────────
    if (g_input->isPlacePressed() && hasTarget) {
        Vec3 placePos = hitPos + hitNorm;
        int px2 = (int)placePos.x, py2 = (int)placePos.y, pz2 = (int)placePos.z;
        // Don't place inside player
        Vec3 playerPos = g_camera->getPosition();
        int epx = (int)floorf(playerPos.x), epy = (int)floorf(playerPos.y), epz = (int)floorf(playerPos.z);
        if (!(px2==epx && (py2==epy || py2==epy-1) && pz2==epz)) {
            g_world->setBlock(px2, py2, pz2, g_hotbar[g_hotbarSel]);
        }
    }

    // ── Block BREAK (hold-to-break) ────────────────────────────────────────────
    if (g_input->isBreakHeld() && hasTarget) {
        // Check if still looking at the same block
        int hx = (int)floorf(hitPos.x), hy = (int)floorf(hitPos.y), hz = (int)floorf(hitPos.z);
        int tx = (int)g_breakTarget.x, ty = (int)g_breakTarget.y, tz = (int)g_breakTarget.z;
        if (hx == tx && hy == ty && hz == tz) {
            g_breakProgress += dt / BREAK_TIME;
            if (g_breakProgress >= 1.f) {
                g_world->setBlock(hx, hy, hz, BLOCK_AIR);
                g_breakProgress = 0.f;
                g_breakTarget = {-9999, -9999, -9999};
            }
        } else {
            // Switched target — reset
            g_breakTarget   = {(float)hx, (float)hy, (float)hz};
            g_breakProgress = 0.f;
        }
    } else {
        g_breakProgress = 0.f;
        g_breakTarget   = {-9999, -9999, -9999};
    }

    g_input->clearActions();

    // ── Stream chunks ──────────────────────────────────────────────────────────
    Vec3 pos = g_camera->getPosition();
    g_world->update(pos.x, pos.z, g_renderDist, g_renderer->getMVPLoc());
}

// ═════════════════════════════════════════════════════════════════════════════
// JNI
// ═════════════════════════════════════════════════════════════════════════════
extern "C" {

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit");
    g_renderer = std::make_unique<Renderer>();
    g_world    = std::make_unique<World>(12345u);
    g_camera   = std::make_unique<Camera>();
    g_input    = std::make_unique<Input>();

    if (!g_renderer->init()) { LOGE("Renderer init failed"); return; }

    // Spawn high enough to clear any terrain
    g_camera->setPosition({8.f, 100.f, 8.f});
    g_velY     = 0.f;
    g_lastNs   = nowNs();
    g_inited   = true;
    LOGI("nativeInit complete");
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    g_width  = w; g_height = h;
    if (g_renderer) g_renderer->resize(w, h);
    if (g_camera)   g_camera->updateProjection((float)w / (float)h);
    if (g_input)    g_input->setScreenSize((float)w, (float)h);
    LOGI("nativeResize %d x %d", w, h);
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (!g_inited) return;

    long now = nowNs();
    float dt  = (float)(now - g_lastNs) * 1e-9f;
    g_lastNs  = now;

    gameTick(dt);

    g_renderer->beginFrame();

    // 3D world
    glUseProgram(g_renderer->getWorldProg());
    Mat4 vp = g_camera->getViewProjection();
    g_world->renderAll(g_renderer->getMVPLoc(), vp.m);

    // HUD
    g_renderer->renderHUD(
        (float)g_width, (float)g_height,
        g_input->joyBaseX(),  g_input->joyBaseY(),
        g_input->joyThumbX(), g_input->joyThumbY(),
        g_input->joyActive(),
        g_breakProgress,
        g_fpsDisplay,
        g_renderDist
    );
}

JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchDown(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchDown(id, x, y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchMove(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchMove(id, x, y);
}
JNIEXPORT void JNICALL
Java_com_voxel_game_GameRenderer_nativeTouchUp(JNIEnv*,jobject,jint id,jfloat x,jfloat y) {
    if (g_input) g_input->onTouchUp(id, x, y);
}

} // extern "C"
