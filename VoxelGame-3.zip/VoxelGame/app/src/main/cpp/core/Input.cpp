#include "Input.h"
#include <cmath>

void Input::setScreenSize(float w, float h) {
    sw = w; sh = h;
    fixedJoyX = w * 0.14f;
    fixedJoyY = h * 0.78f;
}

int Input::findSlot(int id) const {
    for (int i = 0; i < MAX_TOUCH; i++)
        if (ptrs[i].active && ptrs[i].id == id) return i;
    return -1;
}
int Input::allocSlot(int id, float x, float y) {
    for (int i = 0; i < MAX_TOUCH; i++)
        if (!ptrs[i].active) { ptrs[i]={id,x,y,x,y,true}; return i; }
    return -1;
}
void Input::freeSlot(int id) {
    int i = findSlot(id);
    if (i < 0) return;
    if (i == joyPtrIdx)  { joyPtrIdx  = -1; }
    if (i == lookPtrIdx) {
        lookPtrIdx = -1;
        // Reset anchor so no jump when a new finger lands
        lookAnchorX = -1; lookAnchorY = -1;
    }
    ptrs[i].active = false;
}

ButtonId Input::hitButton(float x, float y) const {
    auto d2=[&](float cx,float cy){float dx=x-cx,dy=y-cy;return dx*dx+dy*dy;};
    float r2 = BTN_RADIUS * BTN_RADIUS;
    if (x > sw * 0.45f) {
        if (d2(sw*0.84f,sh*0.68f)<r2) return ButtonId::JUMP;
        if (d2(sw*0.74f,sh*0.78f)<r2) return ButtonId::PLACE;
        if (d2(sw*0.94f,sh*0.78f)<r2) return ButtonId::BREAK;
        if (x > sw-70.f && y < 70.f)  return ButtonId::SETTINGS_PLUS;
    }
    return ButtonId::NONE;
}

void Input::onTouchDown(int id, float x, float y) {
    ButtonId btn = hitButton(x, y);
    switch (btn) {
        case ButtonId::JUMP:          jumpPressed    = true; return;
        case ButtonId::PLACE:         placePressed   = true; return;
        case ButtonId::BREAK:         breakPtrId     = id;   return;
        case ButtonId::SETTINGS_PLUS: settingsPlusTap= true; return;
        default: break;
    }
    int slot = allocSlot(id, x, y);
    if (slot < 0) return;
    if (x < sw * 0.5f) { if (joyPtrIdx  < 0) joyPtrIdx  = slot; }
    else {
        if (lookPtrIdx < 0) {
            lookPtrIdx  = slot;
            // Record where this finger started — first frame has zero delta
            lookAnchorX = x;
            lookAnchorY = y;
        }
    }
}

void Input::onTouchMove(int id, float x, float y) {
    int slot = findSlot(id);
    if (slot < 0) return;
    ptrs[slot].currentX = x;
    ptrs[slot].currentY = y;
    // NOTE: we do NOT accumulate delta here anymore.
    // consumeDX/DY computes delta from anchor each frame → no multi-event stacking.
}

void Input::onTouchUp(int id, float x, float y) {
    if (id == breakPtrId) breakPtrId = -1;
    freeSlot(id);
}

// ── Per-frame look delta (anchor-based, not event-based) ─────────────────────
// Returns the displacement of the look finger since last call, then resets.
float Input::consumeDX() {
    if (lookPtrIdx < 0 || lookAnchorX < 0) return 0;
    float d = ptrs[lookPtrIdx].currentX - lookAnchorX;
    lookAnchorX = ptrs[lookPtrIdx].currentX;  // advance anchor
    // Hard cap per frame to stop stutter spikes
    if (d >  60.f) d =  60.f;
    if (d < -60.f) d = -60.f;
    return d;
}
float Input::consumeDY() {
    if (lookPtrIdx < 0 || lookAnchorY < 0) return 0;
    float d = ptrs[lookPtrIdx].currentY - lookAnchorY;
    lookAnchorY = ptrs[lookPtrIdx].currentY;
    if (d >  60.f) d =  60.f;
    if (d < -60.f) d = -60.f;
    return d;
}

float Input::joyThumbX() const {
    if (joyPtrIdx < 0) return fixedJoyX;
    float dx=ptrs[joyPtrIdx].currentX-fixedJoyX, dy=ptrs[joyPtrIdx].currentY-fixedJoyY;
    float mag=sqrtf(dx*dx+dy*dy);
    if (mag>JOY_RADIUS) dx=dx/mag*JOY_RADIUS;
    return fixedJoyX+dx;
}
float Input::joyThumbY() const {
    if (joyPtrIdx < 0) return fixedJoyY;
    float dx=ptrs[joyPtrIdx].currentX-fixedJoyX, dy=ptrs[joyPtrIdx].currentY-fixedJoyY;
    float mag=sqrtf(dx*dx+dy*dy);
    if (mag>JOY_RADIUS) dy=dy/mag*JOY_RADIUS;
    return fixedJoyY+dy;
}

Vec3 Input::getMovement() const {
    if (joyPtrIdx < 0) return {0,0,0};
    float dx=(joyThumbX()-fixedJoyX)/JOY_RADIUS;
    float dz=(joyThumbY()-fixedJoyY)/JOY_RADIUS;
    float mag=sqrtf(dx*dx+dz*dz);
    if (mag>1.f){dx/=mag;dz/=mag;}
    return {dx,0,dz};
}
