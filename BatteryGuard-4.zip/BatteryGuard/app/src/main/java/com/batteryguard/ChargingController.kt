package com.batteryguard

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import java.io.File

/**
 * Charging control via Root, Shizuku (library-free binder reflection),
 * or fallback alert. No external Maven repos required.
 */
object ChargingController {

    private const val TAG        = "ChargingController"
    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    private val CHARGING_NODES = listOf(
        "/sys/class/power_supply/battery/charging_enabled",
        "/sys/class/power_supply/battery/charge_control_limit_max",
        "/sys/class/power_supply/battery/input_suspend",
        "/sys/class/power_supply/batt_drv/charge_disable",
        "/sys/class/power_supply/battery/stop_charging",
        "/sys/class/power_supply/battery/inhibit_charge"
    )

    enum class Method { ROOT, SHIZUKU, NONE }

    fun availableMethod(): Method = when {
        isRooted()         -> Method.ROOT
        isShizukuGranted() -> Method.SHIZUKU
        else               -> Method.NONE
    }

    fun disableCharging(): Boolean = run(buildCmds(false))
    fun enableCharging(): Boolean  = run(buildCmds(true))

    private fun buildCmds(enable: Boolean): List<String> {
        val v    = if (enable) "1" else "0"
        val cmds = CHARGING_NODES.filter { File(it).exists() }.map { "echo $v > $it" }.toMutableList()
        if (enable) cmds += "dumpsys battery reset 2>/dev/null || true"
        else        cmds += "dumpsys battery set status 1 2>/dev/null || true"
        return cmds
    }

    private fun run(cmds: List<String>): Boolean {
        if (cmds.isEmpty()) return false
        val cmd = cmds.joinToString(" ; ")
        return when (availableMethod()) {
            Method.ROOT    -> execRoot(cmd)
            Method.SHIZUKU -> execShizuku(cmd)
            Method.NONE    -> false
        }
    }

    // ── Root ─────────────────────────────────────────────────────────────────

    private fun execRoot(cmd: String) = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
    } catch (e: Exception) { false }

    // ── Shizuku (no library — pure binder + reflection) ─────────────────────

    private fun execShizuku(cmd: String): Boolean {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("sh", "-c",
                "content call --uri content://$SHIZUKU_PKG.shizuku --method exec" +
                " --arg 'sh' --extra cmd:s:\"$cmd\" 2>/dev/null"))
            proc.waitFor() == 0
        } catch (e: Exception) {
            Log.e(TAG, "shizuku exec: ${e.message}"); false
        }
    }

    fun isShizukuAvailable(): Boolean = try {
        val sm = Class.forName("android.os.ServiceManager")
        val checkService = sm.getMethod("checkService", String::class.java)
        checkService.invoke(null, "shizuku") != null
    } catch (e: Exception) { false }

    private fun isShizukuGranted(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            val sm     = Class.forName("android.os.ServiceManager")
            val getSvc = sm.getMethod("getService", String::class.java)
            val binder = getSvc.invoke(null, "shizuku") as? IBinder ?: return false
            val data   = android.os.Parcel.obtain()
            val reply  = android.os.Parcel.obtain()
            try {
                data.writeInterfaceToken("moe.shizuku.server.IShizukuService")
                data.writeString("moe.shizuku.manager.permission.API_V23")
                data.writeInt(android.os.Process.myPid())
                data.writeInt(android.os.Process.myUid())
                data.writeStrongBinder(null)
                binder.transact(13, data, reply, 0)
                reply.readException()
                reply.readInt() == PackageManager.PERMISSION_GRANTED
            } finally { data.recycle(); reply.recycle() }
        } catch (e: Exception) { false }
    }

    fun requestShizukuPermission(context: Context) {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
                ?: Intent(Intent.ACTION_VIEW).apply { `package` = SHIZUKU_PKG }
            context.startActivity(intent.apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
        } catch (e: Exception) { Log.e(TAG, "launch shizuku: ${e.message}") }
    }

    private fun isRooted() = listOf(
        "/system/bin/su", "/system/xbin/su",
        "/sbin/su", "/su/bin/su", "/magisk/.core/bin/su"
    ).any { File(it).exists() }
}
