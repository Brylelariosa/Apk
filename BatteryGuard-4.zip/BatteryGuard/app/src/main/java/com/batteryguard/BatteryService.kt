package com.batteryguard

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat

class BatteryService : Service() {

    companion object {
        const val CHANNEL_PERSISTENT = "bg_persistent"
        const val CHANNEL_ALERT      = "bg_alert"
        const val NOTIF_PERSISTENT   = 1
        const val NOTIF_ALERT        = 2

        const val ACTION_UPDATE_UI = "com.batteryguard.UPDATE_UI"
    }

    private var batteryReceiver: BroadcastReceiver? = null
    private var lastAlertPercent = -1

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(NOTIF_PERSISTENT, buildPersistentNotif("Monitoring battery…", 0))
        registerBatteryReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        batteryReceiver?.let { unregisterReceiver(it) }
    }

    private fun registerBatteryReceiver() {
        batteryReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val level  = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale  = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                if (scale <= 0) return

                val percent    = level * 100 / scale
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                                 status == BatteryManager.BATTERY_STATUS_FULL

                val prefs     = getSharedPreferences("settings", MODE_PRIVATE)
                val threshold = prefs.getInt("threshold", 100)

                val statusText = if (isCharging) "Charging" else "On Battery"
                updatePersistentNotif("$percent%  •  $statusText", percent)

                // Broadcast so MainActivity can refresh without polling
                sendBroadcast(Intent(ACTION_UPDATE_UI))

                if (isCharging && percent >= threshold && lastAlertPercent != percent) {
                    lastAlertPercent = percent
                    handleThresholdReached(percent)
                } else if (percent < threshold - 5) {
                    lastAlertPercent = -1
                    // Re-enable charging if it was disabled
                    ChargingController.enableCharging()
                }
            }
        }
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun handleThresholdReached(percent: Int) {
        val success = ChargingController.disableCharging()
        val method  = ChargingController.availableMethod()

        when {
            success -> sendAlert(
                "🔋 Charging stopped at $percent%",
                "Battery Guard automatically stopped charging to protect your battery.",
                loud = false
            )
            method == ChargingController.Method.NONE -> sendAlert(
                "⚠️ Battery at $percent% — Unplug now!",
                "Please unplug your charger to protect battery health. (Enable Shizuku or root for automatic control.)",
                loud = true
            )
            else -> sendAlert(
                "⚠️ Charging limit reached at $percent%",
                "Auto-stop attempted but failed. Please unplug manually.",
                loud = true
            )
        }
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PERSISTENT, "Battery Monitor", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Shows current battery status" }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "Charging Alerts", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    description = "Alerts when the charging threshold is reached"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 400, 150, 400, 150, 400)
                }
        )
    }

    private fun buildPersistentNotif(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_PERSISTENT)
            .setContentTitle("Battery Guard")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setProgress(100, progress, false)
            .build()
    }

    private fun updatePersistentNotif(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_PERSISTENT, buildPersistentNotif(text, progress))
    }

    private fun sendAlert(title: String, body: String, loud: Boolean) {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ALERT)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)

        if (loud) {
            val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            builder.setSound(sound)
            builder.setVibrate(longArrayOf(0, 600, 200, 600, 200, 600))

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 200, 600), -1))
            }
        }

        getSystemService(NotificationManager::class.java).notify(NOTIF_ALERT, builder.build())
    }
}
