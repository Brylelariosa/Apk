package com.voxel.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Build;
import android.view.KeyEvent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.View;
import android.widget.Toast;
import java.io.PrintWriter;
import java.io.StringWriter;

public class MainActivity extends Activity {
    private static final String TAG = "VoxelMain";
    private GameSurfaceView surfaceView;
    private GameRenderer    renderer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // ── Must be called BEFORE super.onCreate ─────────────────────────────
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        // ── Window flags — set ALL of them before setContentView ─────────────
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        );
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);

        // Extend into display cutout (notch/punch-hole)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        // Crash handler
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            StringWriter sw = new StringWriter();
            throwable.printStackTrace(new PrintWriter(sw));
            final String trace = "Java crash [" + thread.getName() + "]:\n" + sw;
            Log.e(TAG, trace);
            runOnUiThread(() -> {
                try {
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Crash").setMessage(trace)
                        .setPositiveButton("Copy", (d,w) -> {
                            ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE))
                                .setPrimaryClip(ClipData.newPlainText("crash", trace));
                            Toast.makeText(MainActivity.this,"Copied!",Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Close",(d,w)->finish()).setCancelable(false).show();
                } catch (Exception ignored) {}
            });
        });

        // Create renderer and surface view
        String filesDir = getFilesDir().getAbsolutePath();
        try {
            renderer    = new GameRenderer(this, filesDir);
            surfaceView = new GameSurfaceView(this, renderer);
        } catch (UnsatisfiedLinkError e) {
            showFatalError("Library load failed:\n" + e.getMessage()
                + "\nABI: " + Build.SUPPORTED_ABIS[0]);
            return;
        }

        setContentView(surfaceView);

        // ── Apply immersive AFTER setContentView so decor view exists ─────────
        applyImmersive();

        renderer.showPendingCrashDialog();
    }

    private void applyImmersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController ctrl = getWindow().getInsetsController();
            if (ctrl != null) {
                ctrl.hide(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout());
                ctrl.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
                      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                      | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                      | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    private void showFatalError(String msg) {
        Log.e(TAG, "FATAL: " + msg);
        new AlertDialog.Builder(this).setTitle("Fatal Error").setMessage(msg)
            .setPositiveButton("Copy", (d,w)->{
                ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE))
                    .setPrimaryClip(ClipData.newPlainText("err", msg));
                Toast.makeText(this,"Copied!",Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Close",(d,w)->finish()).setCancelable(false).show();
    }

    @Override protected void onResume() { super.onResume(); if(surfaceView!=null) surfaceView.onResume(); }
    @Override protected void onPause()  { super.onPause();  if(surfaceView!=null) surfaceView.onPause();  }

    /** Press Volume-Down to dump debug log to clipboard and show dialog */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && renderer != null) {
            showDebugLog();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void showDebugLog() {
        if (renderer == null) return;
        renderer.nativeFlushDebugLog();
        String log = renderer.nativeGetDebugLog();
        if (log == null || log.isEmpty()) log = "(No debug data yet — play for 2 seconds)";
        final String finalLog = log;
        runOnUiThread(() -> {
            // Copy to clipboard automatically
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("VoxelDebug", finalLog));

            new AlertDialog.Builder(this)
                .setTitle("📋 Debug Log (auto-copied)")
                .setMessage(finalLog.length() > 3000
                    ? finalLog.substring(finalLog.length() - 3000) + "\n[truncated]"
                    : finalLog)
                .setPositiveButton("Copy Again", (d, w) -> {
                    cm.setPrimaryClip(ClipData.newPlainText("VoxelDebug", finalLog));
                    Toast.makeText(this, "Copied!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Close", null)
                .show();
        });
    }
}
