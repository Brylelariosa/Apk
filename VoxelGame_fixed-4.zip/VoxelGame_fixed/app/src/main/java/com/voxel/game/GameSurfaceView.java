package com.voxel.game;

import android.content.Context;
import android.graphics.Insets;
import android.graphics.Rect;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.List;

public class GameSurfaceView extends GLSurfaceView {
    private final GameRenderer renderer;

    public GameSurfaceView(Context context, GameRenderer renderer) {
        super(context);
        this.renderer = renderer;
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Exclude the right 40% of screen from system gesture detection
            // so Android doesn't intercept touches on the game buttons
            int w = right - left, h = bottom - top;
            List<Rect> exclusions = new ArrayList<>();
            // Right half — where all action buttons live
            exclusions.add(new Rect(w / 2, 0, w, h));
            setSystemGestureExclusionRects(exclusions);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index  = event.getActionIndex();
        int id     = event.getPointerId(index);
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                renderer.touchDown(id, event.getX(index), event.getY(index));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++)
                    renderer.touchMove(event.getPointerId(i), event.getX(i), event.getY(i));
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                renderer.touchUp(id, event.getX(index), event.getY(index));
                break;
        }
        return true;
    }
}
