#pragma once
#include <GLES3/gl3.h>

class Renderer {
public:
    Renderer() = default;
    ~Renderer();

    bool init();
    void resize(int w, int h);
    void beginFrame();

    GLint  getMVPLoc()    const { return mvpLoc;    }
    GLuint getWorldProg() const { return worldProg; }

    // Full HUD: joystick, buttons, crosshair, FPS, break-progress, settings panel
    void renderLoading(float sw, float sh, int frame);
    void renderHUD(
        float sw, float sh,
        float joyBaseX, float joyBaseY,
        float joyThumbX, float joyThumbY,
        bool  joyActive,
        float breakProgress,
        int   fps,
        int   renderDist,
        bool  settingsOpen,
        int   hotbarSel,       // 0-8 selected slot
        const uint8_t* hotbarTypes // array of 9 BlockType values
    );

private:
    GLuint worldProg = 0;
    GLuint hudProg   = 0;
    GLint  mvpLoc      = -1;
    GLint  hudOrthoLoc = -1;
    GLint  hudColorLoc = -1;

    GLuint hudVAO = 0, hudVBO = 0;
    int    screenW = 1, screenH = 1;

    static GLuint compileShader(GLenum type, const char* src);
    static GLuint linkProgram(GLuint vert, GLuint frag);

    // Low-level draw helpers (submit to hudVBO and draw)
    void submitAndDraw(const float* pts, int count, GLenum mode,
                       float r, float g, float b, float a = 1.f);

    void drawCircle (float cx, float cy, float radius,
                     float r, float g, float b, float a, bool filled);
    void drawArc    (float cx, float cy, float radius,
                     float startAngle, float endAngle,
                     float r, float g, float b, float lw = 3.f);
    void drawLine   (float x0, float y0, float x1, float y1,
                     float r, float g, float b, float a = 1.f);
    void drawRect   (float x, float y, float w, float h,
                     float r, float g, float b, float a);

    // 7-segment digit (scale=pixel size, x/y = top-left)
    void drawDigit  (int digit, float x, float y, float scale,
                     float r, float g, float b);
    void drawNumber (int number, float x, float y, float scale,
                     float r, float g, float b);
    void drawLabel  (const char* text, float x, float y, float scale,
                     float r, float g, float b);  // digits+letters subset

    // Stroke font A-Z for hotbar block name labels
    void drawChar(char c, float x, float y, float scale,
                  float r, float g, float b, float a = 1.f);
    void drawText(const char* str, float x, float y, float scale,
                  float r, float g, float b, float a = 1.f);
};
