#pragma once
#include <string>
#include <vector>
#include <mutex>
#include <cstdio>
#include <ctime>
#include <android/log.h>

// DebugLog: thread-safe ring buffer + file writer
// Usage: DebugLog::get().record("Camera", "pos=%.1f,%.1f,%.1f shake=%.3f", x, y, z, s);
//        DebugLog::get().setPath("/data/data/com.voxel.game/files/debug.txt");
//        DebugLog::get().flush();  // write ring buffer to file

class DebugLog {
public:
    static constexpr int MAX_LINES = 200;
    static constexpr int MAX_LINE  = 256;

    static DebugLog& get() { static DebugLog inst; return inst; }

    void setPath(const char* p) {
        std::lock_guard<std::mutex> lk(mtx);
        path = p;
    }

    // Record a formatted entry — call from any thread
    void record(const char* tag, const char* fmt, ...) __attribute__((format(printf,3,4))) {
        char buf[MAX_LINE];
        va_list va; va_start(va, fmt);
        vsnprintf(buf, sizeof(buf), fmt, va);
        va_end(va);

        // Timestamp (ms since start)
        long ms = nowMs();
        char line[MAX_LINE + 64];
        snprintf(line, sizeof(line), "[%6ld][%-10s] %s", ms, tag, buf);

        __android_log_print(ANDROID_LOG_DEBUG, "VoxelDebug", "%s", line);

        std::lock_guard<std::mutex> lk(mtx);
        if ((int)ring.size() >= MAX_LINES) ring.erase(ring.begin());
        ring.emplace_back(line);
        dirty = true;
    }

    // Write all buffered lines to file — call from GL thread periodically
    void flush() {
        std::lock_guard<std::mutex> lk(mtx);
        if (!dirty || path.empty()) return;
        FILE* f = fopen(path.c_str(), "w");
        if (!f) return;
        for (auto& l : ring) { fputs(l.c_str(), f); fputc('\n', f); }
        fclose(f);
        dirty = false;
    }

    // Get last N lines as a single string (for on-screen display)
    std::string tail(int n = 10) const {
        std::lock_guard<std::mutex> lk(mtx);
        std::string out;
        int start = std::max(0, (int)ring.size() - n);
        for (int i = start; i < (int)ring.size(); i++) {
            out += ring[i] + "\n";
        }
        return out;
    }

    // Snapshot all lines as one string (for copy-to-clipboard)
    std::string all() const {
        std::lock_guard<std::mutex> lk(mtx);
        std::string out;
        for (auto& l : ring) { out += l + "\n"; }
        return out;
    }

    bool hasNew() const { return dirty; }

private:
    DebugLog() { startMs = nowMs(); }
    mutable std::mutex     mtx;
    std::vector<std::string> ring;
    std::string            path;
    bool                   dirty = false;
    long                   startMs;

    long nowMs() const {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        return ts.tv_sec * 1000L + ts.tv_nsec / 1000000L;
    }
};

// Convenience macro
#define DBGLOG(tag, ...) DebugLog::get().record(tag, __VA_ARGS__)
