#include "CrashReporter.h"
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <android/log.h>

// We need a simple async-signal-safe write — no malloc, no printf
static char g_crashPath[512] = {};

// Signal-safe integer → string
static void writeInt(int fd, long v) {
    char buf[32];
    int  len = 0;
    if (v < 0) { write(fd, "-", 1); v = -v; }
    if (v == 0) { write(fd, "0", 1); return; }
    while (v > 0) { buf[len++] = '0' + (v % 10); v /= 10; }
    // reverse
    for (int i = 0, j = len-1; i < j; i++, j--) {
        char t = buf[i]; buf[i] = buf[j]; buf[j] = t;
    }
    write(fd, buf, (size_t)len);
}

static void writeStr(int fd, const char* s) {
    if (s) write(fd, s, strlen(s));
}

static const char* sigName(int sig) {
    switch (sig) {
        case SIGSEGV: return "SIGSEGV (null/bad pointer)";
        case SIGABRT: return "SIGABRT (abort/assert)";
        case SIGBUS:  return "SIGBUS  (bus error)";
        case SIGFPE:  return "SIGFPE  (math error)";
        case SIGILL:  return "SIGILL  (illegal instruction)";
        default:      return "UNKNOWN SIGNAL";
    }
}

static void crashHandler(int sig, siginfo_t* info, void* /*ctx*/) {
    // Open crash file — O_CREAT|O_TRUNC, async-signal-safe
    int fd = open(g_crashPath, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (fd >= 0) {
        writeStr(fd, "=== VoxelGame Crash Report ===\n");
        writeStr(fd, "Signal: ");
        writeStr(fd, sigName(sig));
        writeStr(fd, "\nSignal number: ");
        writeInt(fd, sig);
        writeStr(fd, "\nFault address: 0x");

        // Hex address
        uintptr_t addr = (uintptr_t)(info ? info->si_addr : nullptr);
        char hex[20]; int hi = 0;
        for (int i = (int)(sizeof(uintptr_t)*2) - 1; i >= 0; i--) {
            int nibble = (int)((addr >> (i * 4)) & 0xF);
            hex[hi++] = nibble < 10 ? '0'+nibble : 'a'+(nibble-10);
        }
        hex[hi] = '\0';
        write(fd, hex, (size_t)hi);

        writeStr(fd, "\n\nThis crash happened during startup.\n");
        writeStr(fd, "Most likely cause: OpenGL ES not available,\n");
        writeStr(fd, "or device does not support OpenGL ES 3.0.\n");
        writeStr(fd, "\nPlease screenshot this and send to developer.\n");
        close(fd);
    }

    // Log to Android logcat too
    __android_log_print(ANDROID_LOG_FATAL, "VoxelCrash",
        "CRASH: signal %d (%s) at addr %p",
        sig, sigName(sig), info ? info->si_addr : nullptr);

    // Re-raise so system gets the original crash (generates tombstone)
    signal(sig, SIG_DFL);
    raise(sig);
}

void installCrashHandler(const char* crashFilePath) {
    strncpy(g_crashPath, crashFilePath, sizeof(g_crashPath) - 1);

    struct sigaction sa{};
    sa.sa_sigaction = crashHandler;
    sa.sa_flags     = SA_SIGINFO | SA_RESETHAND;
    sigemptyset(&sa.sa_mask);

    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
    sigaction(SIGFPE,  &sa, nullptr);
    sigaction(SIGILL,  &sa, nullptr);

    __android_log_print(ANDROID_LOG_INFO, "VoxelCrash",
        "Crash handler installed, report path: %s", crashFilePath);
}

std::string loadAndClearCrashReport(const char* crashFilePath) {
    FILE* f = fopen(crashFilePath, "r");
    if (!f) return {};

    fseek(f, 0, SEEK_END);
    long len = ftell(f);
    fseek(f, 0, SEEK_SET);

    if (len <= 0 || len > 4096) { fclose(f); remove(crashFilePath); return {}; }

    std::string result(len, '\0');
    fread(&result[0], 1, (size_t)len, f);
    fclose(f);
    remove(crashFilePath);   // delete so it only shows once
    return result;
}
