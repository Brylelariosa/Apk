#include "Chunk.h"
#include "BlockDefs.h"
#include <cstring>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "VoxelChunk"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

Chunk::Chunk(int cx, int cz) : chunkX(cx), chunkZ(cz) {
    memset(blocks, 0, sizeof(blocks));
}

Chunk::~Chunk() {
    if (vao) glDeleteVertexArrays(1, &vao);
    if (vbo) glDeleteBuffers(1, &vbo);
    if (ebo) glDeleteBuffers(1, &ebo);
}

uint8_t Chunk::getBlock(int x, int y, int z) const {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return 0;
    return blocks[bidx(x,y,z)];
}

void Chunk::setBlock(int x, int y, int z, uint8_t t) {
    if (x<0||x>=CW||y<0||y>=CH||z<0||z>=CD) return;
    blocks[bidx(x,y,z)] = t;
    // Update spans incrementally.
    // For colMaxY: if placing above current top, update directly.
    // If removing the top block, rescan the column (rare — only on break).
    uint8_t& top = colMaxY[x * CD + z];
    if (t != 0) {
        if (y > top) top = (uint8_t)y;
        yOccupied[y >> 6] |= (1ULL << (y & 63));
    } else {
        // Block removed — rescan this column and this Y slice
        uint8_t newTop = 0;
        for (int sy = 0; sy < CH; sy++)
            if (blocks[bidx(x,sy,z)] != 0 && sy > newTop) newTop = (uint8_t)sy;
        top = newTop;
        // Rescan the Y slice for occupancy
        bool anyInSlice = false;
        for (int sx = 0; sx < CW && !anyInSlice; sx++)
            for (int sz = 0; sz < CD && !anyInSlice; sz++)
                if (blocks[bidx(sx,y,sz)] != 0) anyInSlice = true;
        if (anyInSlice)
            yOccupied[y >> 6] |= (1ULL << (y & 63));
        else
            yOccupied[y >> 6] &= ~(1ULL << (y & 63));
    }
    dirty = true; gpuReady = false;
}

// ── Greedy Meshing ────────────────────────────────────────────────────────────
// For each of 6 face directions, sweep slices perpendicular to that axis.
// Within each slice build a 2-D face-presence mask, then greedily merge
// adjacent same-type cells into the largest possible rectangle.
//
// Dimension mapping:
//   dim=0 (X faces): slice=X, u=Y, v=Z   sizes: CW / CH / CD
//   dim=1 (Y faces): slice=Y, u=X, v=Z   sizes: CH / CW / CD
//   dim=2 (Z faces): slice=Z, u=X, v=Y   sizes: CD / CW / CH

static const int SIZES[3]  = {CW, CH, CD};
static const int UDIM[3]   = {1,  0,  0};
static const int VDIM[3]   = {2,  2,  1};

// Convert (dim, slice, u, v) to local block coords (lx,ly,lz)
static inline void toLocal(int dim, int s, int u, int v,
                            int& lx, int& ly, int& lz) {
    switch(dim) {
        case 0: lx=s; ly=u; lz=v; break;
        case 1: lx=u; ly=s; lz=v; break;
        default:lx=u; ly=v; lz=s; break;
    }
}

// Convert (dim, slice, u, v) to neighbour coords with offset dir
static inline void toNeighbour(int dim, int s, int dir, int u, int v,
                                int& nx, int& ny, int& nz) {
    toLocal(dim, s+dir, u, v, nx, ny, nz);
}

void Chunk::buildMesh(const GetBlock& world) {
    vertData.clear();
    idxData.clear();
    dirty    = false;
    gpuReady = false;

    const int wx0 = chunkX * CW;
    const int wz0 = chunkZ * CD;

    // Temporary mask (max possible slice = max(CW,CH,CD)^2 = 128*16 = 2048)
    uint8_t mask[CH * CD];

    // ── Global Y cap: highest occupied slice + 1 (for the face above the top block)
    // Avoids sweeping any Y level above the tallest block in this chunk.
    // Computed from yOccupied — a single bit scan, no block reads.
    int globalTopY = 0;
    for (int y = CH-1; y >= 0; y--) {
        if (sliceOccupied(y)) { globalTopY = y; break; }
    }
    const int yMax = globalTopY + 2;   // +2: face above top block + neighbour query

    for (int dim = 0; dim < 3; dim++) {
        // ── Dimension-specific size limits ────────────────────────────────────
        // For dim=1 (Y slices): cap sSize at yMax instead of CH=128.
        // For dim=0 (X slices, u=Y): cap uSize at yMax.
        // For dim=2 (Z slices, v=Y): cap vSize at yMax.
        // This is the core "vertical span" optimization: we never sweep
        // Y values above the tallest block, eliminating ~44% of mask work
        // on typical terrain (max height ~72-80, CH=128).
        const int sSize = (dim == 1) ? std::min(SIZES[dim], yMax) : SIZES[dim];
        const int uSize = (dim == 0) ? std::min(SIZES[UDIM[dim]], yMax) : SIZES[UDIM[dim]];
        const int vSize = (dim == 2) ? std::min(SIZES[VDIM[dim]], yMax) : SIZES[VDIM[dim]];

        for (int dir : {-1, 1}) {
            for (int slice = 0; slice < sSize; slice++) {

                // ── Per-slice occupancy early-exit ───────────────────────────
                // For dim=1 (Y faces): if neither this slice nor its neighbour
                // has any block, the mask will be all-zero. Skip both the mask
                // build and the greedy sweep entirely.
                if (dim == 1) {
                    int nb = slice + dir;
                    bool thisEmpty = !sliceOccupied(slice);
                    bool nbEmpty   = (nb < 0 || nb >= CH) ? true : !sliceOccupied(nb);
                    if (thisEmpty && nbEmpty) continue;
                }

                // ── Build face mask ──────────────────────────────────────────
                bool maskEmpty = true;

                for (int u = 0; u < uSize; u++) {
                    for (int v = 0; v < vSize; v++) {
                        int lx,ly,lz, nx,ny,nz;
                        toLocal(dim, slice, u, v, lx, ly, lz);

                        // Per-column span cap (dim=1 only, where slice=Y, lx=u, lz=v).
                        // If this Y slice is above the highest block in column (lx,lz),
                        // both cell and neighbour are guaranteed air — no face possible.
                        if (dim == 1 && slice > colTop(lx, lz)) {
                            mask[u*vSize+v] = 0;
                            continue;
                        }

                        uint8_t here = blocks[bidx(lx,ly,lz)];

                        toNeighbour(dim, slice, dir, u, v, nx, ny, nz);
                        uint8_t nb;
                        if (nx>=0&&nx<CW&&ny>=0&&ny<CH&&nz>=0&&nz<CD)
                            nb = blocks[bidx(nx,ny,nz)];
                        else
                            nb = world(wx0+nx, ny, wz0+nz);

                        bool isSharedBoundary = (dir == -1 && slice == 0);
                        bool nbOwns = isSharedBoundary && (nb != 0);
                        uint8_t val = (blockOpaque(here) && !blockOpaque(nb) && !nbOwns)
                                      ? here : 0;
                        mask[u*vSize+v] = val;
                        if (val) maskEmpty = false;
                    }
                }

                if (maskEmpty) continue;   // entire slice had no visible faces

                // ── Greedy sweep ─────────────────────────────────────────────
                bool done[CH*CD];
                memset(done, 0, (size_t)(uSize*vSize)*sizeof(bool));

                const int faceSlice = (dir==1) ? slice+1 : slice;

                for (int u = 0; u < uSize; u++) {
                    for (int v = 0; v < vSize; ) {
                        uint8_t type = mask[u*vSize+v];
                        if (!type || done[u*vSize+v]) { v++; continue; }

                        int wv = 1;
                        while (v+wv < vSize &&
                               mask[u*vSize+v+wv]==type &&
                               !done[u*vSize+v+wv]) wv++;

                        int wu = 1;
                        bool stop = false;
                        while (u+wu < uSize && !stop) {
                            for (int k=v; k<v+wv; k++) {
                                if (mask[(u+wu)*vSize+k]!=type || done[(u+wu)*vSize+k])
                                { stop=true; break; }
                            }
                            if (!stop) wu++;
                        }

                        for (int pu=u; pu<u+wu; pu++)
                            for (int pv=v; pv<v+wv; pv++)
                                done[pu*vSize+pv] = true;

                        addQuad(dim, dir, faceSlice, u, v, wu, wv, type);
                        v += wv;
                    }
                }
            }
        }
    }
}

void Chunk::addQuad(int dim, int dir,
                    int faceSlice, int u0, int v0, int wu, int wv,
                    uint8_t blockType) {
    const BlockInfo& bi = BLOCKS[blockType];
    const bool isTop    = (dim==1 && dir== 1);
    const bool isBot    = (dim==1 && dir==-1);

    float r = isTop ? bi.tr : bi.r;
    float g = isTop ? bi.tg : bi.g;
    float b = isTop ? bi.tb : bi.b;

    // Directional ambient shading (cheap but effective)
    float light = isTop  ? 1.00f :
                  isBot  ? 0.50f :
                  (dim==0)? 0.70f : 0.80f;

    if (bi.emissive) light = 1.0f;

    const int wx0 = chunkX * CW;
    const int wz0 = chunkZ * CD;

    // 4 corners:  (s, u0,      v0)
    //             (s, u0+wu,   v0)
    //             (s, u0+wu,   v0+wv)
    //             (s, u0,      v0+wv)
    struct C { int u, v; };
    C corners[4] = {{u0,v0},{u0+wu,v0},{u0+wu,v0+wv},{u0,v0+wv}};

    const uint32_t base = (uint32_t)(vertData.size() / 7);

    for (auto& c : corners) {
        float fx, fy, fz;
        switch(dim) {
            case 0: fx=(float)faceSlice; fy=(float)c.u; fz=(float)c.v; break;
            case 1: fx=(float)c.u;       fy=(float)faceSlice; fz=(float)c.v; break;
            default:fx=(float)c.u;       fy=(float)c.v; fz=(float)faceSlice; break;
        }
        fx += (float)wx0;
        fz += (float)wz0;
        vertData.push_back(fx);
        vertData.push_back(fy);
        vertData.push_back(fz);
        vertData.push_back(r);
        vertData.push_back(g);
        vertData.push_back(b);
        vertData.push_back(light);
    }

    // Y-axis (dim==1) quads have opposite vertex-winding to X/Z quads
    // because the U/V axes lie in the XZ plane (not XY or YZ).
    // Verified by cross-product: for dim==1 we must flip CCW/CW sense.
    bool normalWinding = (dir == 1) ^ (dim == 1);
    if (normalWinding) {
        idxData.push_back(base+0); idxData.push_back(base+1); idxData.push_back(base+2);
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+3);
    } else {
        idxData.push_back(base+0); idxData.push_back(base+2); idxData.push_back(base+1);
        idxData.push_back(base+0); idxData.push_back(base+3); idxData.push_back(base+2);
    }
}

// ── GPU Upload ────────────────────────────────────────────────────────────────
void Chunk::uploadMesh() {
    if (vertData.empty()) { indexCount=0; gpuReady=true; return; }

    if (!vao) {
        glGenVertexArrays(1, &vao);
        glGenBuffers(1, &vbo);
        glGenBuffers(1, &ebo);
    }

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(vertData.size()*sizeof(float)),
                 vertData.data(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 (GLsizeiptr)(idxData.size()*sizeof(uint32_t)),
                 idxData.data(), GL_STATIC_DRAW);

    const GLsizei stride = 7 * sizeof(float);
    // aPos   @ location 0
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,stride,(void*)0);
    // aColor @ location 1
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,stride,(void*)(3*sizeof(float)));
    // aLight @ location 2
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2,1,GL_FLOAT,GL_FALSE,stride,(void*)(6*sizeof(float)));

    glBindVertexArray(0);

    indexCount = (int)idxData.size();
    gpuReady   = true;

    // Free CPU-side data
    vertData.clear(); vertData.shrink_to_fit();
    idxData.clear();  idxData.shrink_to_fit();
}

void Chunk::render() const {
    if (!gpuReady || indexCount == 0) return;
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}
