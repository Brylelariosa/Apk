#pragma once
#include "Chunk.h"
#include "Noise.h"
#include "MathUtils.h"
#include <unordered_map>
#include <unordered_set>
#include <deque>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <vector>
#include <cstdint>
#include <climits>

struct ChunkKey {
    int x, z;
    bool operator==(const ChunkKey& o) const { return x==o.x && z==o.z; }
};
struct ChunkHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int64_t>()(((int64_t)k.x<<32)|(uint32_t)k.z);
    }
};

class World {
public:
    explicit World(uint32_t seed = 42);
    ~World();

    uint8_t getBlock(int x, int y, int z) const;
    // Like getBlock but treats unloaded chunks as solid below y=100
    // Used by collision so player never falls through ungenerated terrain
    bool    blockSolidForCollision(int x, int y, int z) const;
    void    setBlock(int x, int y, int z, uint8_t type);
    Chunk*  getChunk(int cx, int cz) const;

    // movDirX/Z: normalised player movement direction (0,0 = stationary).
    // Chunks in the forward half-space are prioritised in the load queue.
    void    update(float px, float pz, int renderDist,
                   float movDirX = 0.f, float movDirZ = 0.f);
    void    renderAll(GLint mvpLoc, const float* vp) const;

    size_t  chunkCount() const { return chunks.size(); }
    bool    raycast(Vec3 origin, Vec3 dir, float maxDist,
                    Vec3& hitPos, Vec3& hitNormal) const;

private:
    // ── GL-thread-only ────────────────────────────────────────────────────────
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkHash> chunks;
    std::vector<ChunkKey> dirtyChunks;
    std::unordered_set<ChunkKey, ChunkHash> pendingSet;  // O(1) "already queued?" check

    // ── Worker threads ────────────────────────────────────────────────────────
    std::vector<std::thread> workers;
    static constexpr int     NUM_WORKERS = 3;
    bool                     workerRunning{false};  // protected by reqMutex
    std::condition_variable  reqCV;
    std::mutex               reqMutex;
    std::deque<ChunkKey>     requested;    // deque: O(1) push_front AND push_back
    std::vector<ChunkKey>    inFlight;

    struct BuiltChunk { int cx, cz; std::unique_ptr<Chunk> chunk; };
    std::mutex               resMutex;
    std::vector<BuiltChunk>  results;

    // ── Terrain cache — the key optimisation ─────────────────────────────────
    // Stores terrain block data so each chunk column is generated exactly once.
    // Workers copy out what they need under the mutex (32KB memcpy ≈ 2µs),
    // then work on the local copy with no locks held.
    // Using value type (not shared_ptr) avoids atomic refcount thrashing
    // when 3 threads simultaneously read neighbour entries.
    struct TerrainEntry {
        uint8_t blocks[CW*CH*CD];
        bool ready = false;
    };
    mutable std::mutex terrainCacheMutex;
    std::unordered_map<ChunkKey, TerrainEntry, ChunkHash> terrainCache;

    // ── Queue-scan position tracking ─────────────────────────────────────────
    // The queue scan is O(renderDist²) — only run it when the player crosses
    // a chunk boundary or renderDist changes, not every frame.
    int  lastQueuePcx    = INT_MIN;
    int  lastQueuePcz    = INT_MIN;
    int  lastQueueRdist  = -1;

    Noise    noise;
    uint32_t seed;

    void    workerMain();
    void    generateAndMesh(int cx, int cz);
    void    generateTerrainInto(int cx, int cz, uint8_t* blocks);   // flat CW*CH*CD array
    bool    getTerrainCopy(int cx, int cz, uint8_t* out);            // true = cache hit
    void    placeTree(uint8_t* blocks, int lx, int y, int lz, float wx, float wz);
};
