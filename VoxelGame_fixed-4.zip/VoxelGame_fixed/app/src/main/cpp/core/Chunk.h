#pragma once
#include <cstdint>
#include <vector>
#include <functional>
#include <GLES3/gl3.h>

// Chunk dimensions
static constexpr int CW = 16;   // width  (X)
static constexpr int CH = 128;  // height (Y)
static constexpr int CD = 16;   // depth  (Z)
// Flat index — layout: X-major so Z is stride-1 (cache-friendly for mesher inner v loop)
// blocks[x][y][z]  →  blocks[x*CH*CD + y*CD + z]
static constexpr int CSIZE = CW * CH * CD;
static constexpr int bidx(int x, int y, int z) { return x*CH*CD + y*CD + z; }

class Chunk {
public:
    Chunk(int cx, int cz);
    ~Chunk();

    uint8_t  getBlock(int x, int y, int z) const;
    void     setBlock(int x, int y, int z, uint8_t type);

    // Build CPU-side mesh — safe to call from any thread
    using GetBlock = std::function<uint8_t(int,int,int)>;
    void buildMesh(const GetBlock& world);

    // Upload built mesh to GPU — must be called from GL thread
    void uploadMesh();

    // Draw — caller must set MVP uniform before calling renderAll()
    void render() const;

    int  getChunkX() const { return chunkX; }
    int  getChunkZ() const { return chunkZ; }
    bool isDirty()   const { return dirty;    }
    bool hasGpu()    const { return gpuReady; }
    // true when CPU mesh data is present (built but not yet uploaded)
    bool hasCpuMesh() const { return !vertData.empty(); }
    void markDirty()        { dirty = true; gpuReady = false; }
    // Copy flat terrain data directly into block array (worker thread safe).
    // Also computes per-column max-Y table and per-slice occupancy bitset
    // used by buildMesh() to skip empty regions without touching block data.
    void populate(const uint8_t* src) {
        memcpy(blocks, src, CSIZE);
        computeSpans();
        dirty = true; gpuReady = false;
    }
    const uint8_t* rawBlocks() const { return blocks; }

private:
    uint8_t  blocks[CSIZE]{};
    int      chunkX, chunkZ;

    // ── Novel: vertical span structures ──────────────────────────────────────
    // colMaxY[x*CD+z] = highest Y with a non-air block in column (x,z).
    // Defaults to 0 (empty column).  Used by buildMesh to skip empty Y range
    // per column individually — cuts inner-loop work by ~44% on average terrain.
    uint8_t  colMaxY[CW * CD]{};
    // yOccupied: 128-bit mask, one bit per Y slice. Bit Y set iff that slice
    // contains at least one non-air block.  Lets the outer slice loop skip
    // completely empty Y layers without a single block read.
    uint64_t yOccupied[2]{};  // [0]=Y0..63, [1]=Y64..127

    void computeSpans() {
        memset(colMaxY,   0, sizeof(colMaxY));
        memset(yOccupied, 0, sizeof(yOccupied));
        for (int x = 0; x < CW; x++) {
            for (int z = 0; z < CD; z++) {
                uint8_t top = 0;
                for (int y = 0; y < CH; y++) {
                    if (blocks[bidx(x,y,z)] != 0) {
                        if (y > top) top = (uint8_t)y;
                        // Mark Y slice occupied
                        yOccupied[y >> 6] |= (1ULL << (y & 63));
                    }
                }
                colMaxY[x * CD + z] = top;
            }
        }
    }
    // Returns the highest Y that needs meshing for column (x,z) — capped at CH-1
    int colTop(int x, int z) const {
        int t = (int)colMaxY[x * CD + z];
        return t < CH-1 ? t + 1 : CH-1;   // +1 for the face above the top block
    }
    // Returns true if Y slice `y` has any block (quick occupancy check)
    bool sliceOccupied(int y) const {
        return (yOccupied[y >> 6] >> (y & 63)) & 1;
    }

    std::vector<float>    vertData;
    std::vector<uint32_t> idxData;

    GLuint vao = 0, vbo = 0, ebo = 0;
    int    indexCount = 0;
    bool   dirty      = true;
    bool   gpuReady   = false;

    void addQuad(int dim, int dir, int faceSlice,
                 int u0, int v0, int wu, int wv,
                 uint8_t blockType);
};
