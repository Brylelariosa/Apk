#pragma once
#include <cstdint>

class Noise {
    int perm[512];
    static float fade(float t)              { return t*t*t*(t*(t*6-15)+10); }
    static float lerp(float t,float a,float b){ return a+t*(b-a); }
    static float grad(int h,float x,float y);
public:
    explicit Noise(uint32_t seed = 0);
    float noise2D(float x, float y) const;
    float fbm(float x, float y, int octaves=6, float lac=2.f, float gain=0.5f) const;
    float noise3D(float x, float y, float z) const;
};
