#include "Input.h"
#include <cmath>
#include <algorithm>

void Input::setScreenSize(float w, float h) {
    std::lock_guard<std::mutex> lk(mtx);
    sw = w; sh = h;
    fixedJoyX = w * 0.14f;
    fixedJoyY = h * 0.78f;
}

int Input::findSlot_locked(int id) const {
    for (int i = 0; i < MAX_TOUCH; i++)
        if (ptrs[i].active && ptrs[i].id == id) return i;
    return -1;
}

int Input::allocSlot_locked(int id, float x, float y) {
    for (int i = 0; i < MAX_TOUCH; i++)
        if (!ptrs[i].active) { ptrs[i] = {id,x,y,x,y,true}; return i; }
    return -1;
}

ButtonId Input::hitButton(float x, float y) const {
    // Called while mtx held — reads sw/sh safely
    auto d2 = [&](float cx, float cy){
        float dx=x-cx, dy=y-cy; return dx*dx+dy*dy;
    };
    float r2 = BTN_RADIUS * BTN_RADIUS;
    if (x > sw * 0.45f) {
        if (d2(sw*0.82f, sh*0.65f) < r2) return ButtonId::JUMP;
        if (d2(sw*0.72f, sh*0.77f) < r2) return ButtonId::PLACE;
        if (d2(sw*0.89f, sh*0.77f) < r2) return ButtonId::BREAK;
        // Gear button handled directly in nativeTouchDown — not via Input
    }
    return ButtonId::NONE;
}

void Input::onTouchDown(int id, float x, float y) {
    std::lock_guard<std::mutex> lk(mtx);

    ButtonId btn = hitButton(x, y);
    switch (btn) {
        case ButtonId::JUMP:          jumpPressed.store(true);     return;
        case ButtonId::PLACE:         placePressed.store(true);    return;
        case ButtonId::BREAK:         breakHeld.store(true); breakPtrId.store(id); return;
        default: break;
    }

    int slot = allocSlot_locked(id, x, y);
    if (slot < 0) return;

    if (x < sw * 0.5f) {
        if (joyPtrIdx < 0) joyPtrIdx = slot;
    } else {
        if (lookPtrIdx < 0) {
            lookPtrIdx  = slot;
            lookAnchorX = x;
            lookAnchorY = y;
        }
    }
}

void Input::onTouchMove(int id, float x, float y) {
    std::lock_guard<std::mutex> lk(mtx);
    int slot = findSlot_locked(id);
    if (slot < 0) return;
    ptrs[slot].currentX = x;
    ptrs[slot].currentY = y;
    // Accumulate look delta under lock so GL thread gets clean values
    if (slot == lookPtrIdx && lookAnchorX >= 0.f) {
        std::lock_guard<std::mutex> dlk(deltaMtx);
        float dx = x - lookAnchorX;
        float dy = y - lookAnchorY;
        // Clamp to ±60px per event to prevent stutter spikes
        dx = std::max(-60.f, std::min(60.f, dx));
        dy = std::max(-60.f, std::min(60.f, dy));
        lookDX += dx;
        lookDY += dy;
        lookAnchorX = x;
        lookAnchorY = y;
    }
}

void Input::onTouchUp(int id, float x, float y) {
    std::lock_guard<std::mutex> lk(mtx);
    // If this pointer ID matches the break pointer, release break
    if (breakPtrId.load() == id) {
        breakPtrId.store(-1);
        breakHeld.store(false);
    }
    int slot = findSlot_locked(id);
    if (slot < 0) return;
    if (slot == joyPtrIdx)  joyPtrIdx  = -1;
    if (slot == lookPtrIdx) { lookPtrIdx = -1; lookAnchorX = -1.f; lookAnchorY = -1.f; }
    ptrs[slot].active = false;
}

float Input::consumeDX() {
    std::lock_guard<std::mutex> lk(deltaMtx);
    float v = lookDX; lookDX = 0.f; return v;
}
float Input::consumeDY() {
    std::lock_guard<std::mutex> lk(deltaMtx);
    float v = lookDY; lookDY = 0.f; return v;
}

bool Input::joyActive() const {
    std::lock_guard<std::mutex> lk(mtx);
    return joyPtrIdx >= 0;
}
float Input::joyThumbX() const {
    std::lock_guard<std::mutex> lk(mtx);
    if (joyPtrIdx < 0) return fixedJoyX;
    float dx=ptrs[joyPtrIdx].currentX-fixedJoyX, dy=ptrs[joyPtrIdx].currentY-fixedJoyY;
    float mag=sqrtf(dx*dx+dy*dy);
    if (mag > JOY_RADIUS) dx = dx/mag*JOY_RADIUS;
    return fixedJoyX + dx;
}
float Input::joyThumbY() const {
    std::lock_guard<std::mutex> lk(mtx);
    if (joyPtrIdx < 0) return fixedJoyY;
    float dx=ptrs[joyPtrIdx].currentX-fixedJoyX, dy=ptrs[joyPtrIdx].currentY-fixedJoyY;
    float mag=sqrtf(dx*dx+dy*dy);
    if (mag > JOY_RADIUS) dy = dy/mag*JOY_RADIUS;
    return fixedJoyY + dy;
}

Vec3 Input::getMovement() const {
    std::lock_guard<std::mutex> lk(mtx);
    if (joyPtrIdx < 0) return {0,0,0};
    float dx = (ptrs[joyPtrIdx].currentX - fixedJoyX) / JOY_RADIUS;
    float dz = (ptrs[joyPtrIdx].currentY - fixedJoyY) / JOY_RADIUS;
    float mag = sqrtf(dx*dx+dz*dz);
    if (mag > 1.f) { dx/=mag; dz/=mag; }
    return {dx, 0, dz};
}
