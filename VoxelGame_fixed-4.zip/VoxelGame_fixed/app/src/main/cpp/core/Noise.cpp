#include "Noise.h"
#include <cmath>
#include <algorithm>
#include <numeric>

Noise::Noise(uint32_t seed) {
    for (int i=0;i<256;i++) perm[i]=i;
    // Fisher-Yates using LCG
    uint32_t s = seed ^ 0xDEADBEEF;
    for (int i=255;i>0;i--) {
        s = s*1664525u + 1013904223u;
        int j = (int)(s >> 16) % (i+1);
        std::swap(perm[i], perm[j]);
    }
    for (int i=0;i<256;i++) perm[256+i]=perm[i];
}

float Noise::grad(int h, float x, float y) {
    int hh = h & 3;
    float u = hh<2 ? x : y;
    float v = hh<2 ? y : x;
    return ((hh&1)?-u:u) + ((hh&2)?-v:v);
}

float Noise::noise2D(float x, float y) const {
    int X = (int)floorf(x) & 255;
    int Y = (int)floorf(y) & 255;
    x -= floorf(x); y -= floorf(y);
    float u = fade(x), v = fade(y);
    int a  = perm[X  ]+Y, aa = perm[a], ab = perm[a+1];
    int b  = perm[X+1]+Y, ba = perm[b], bb = perm[b+1];
    return lerp(v,
        lerp(u, grad(perm[aa],x,y),   grad(perm[ba],x-1,y)),
        lerp(u, grad(perm[ab],x,y-1), grad(perm[bb],x-1,y-1)));
}

float Noise::fbm(float x, float y, int octaves, float lac, float gain) const {
    float res=0, amp=0.5f, freq=1.f, maxAmp=0;
    for (int i=0;i<octaves;i++) {
        res    += noise2D(x*freq, y*freq) * amp;
        maxAmp += amp;
        freq   *= lac;
        amp    *= gain;
    }
    return res / maxAmp;
}

// Simple 3-D value noise used for caves
float Noise::noise3D(float x, float y, float z) const {
    // Project 3D to 2D slices
    return noise2D(x + z*31.7f, y + z*17.3f) * 0.5f
         + noise2D(x*1.3f, y*1.3f + z*13.f) * 0.5f;
}
