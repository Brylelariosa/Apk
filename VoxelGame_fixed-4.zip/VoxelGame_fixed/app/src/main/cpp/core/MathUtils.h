#pragma once
#include <cmath>
#include <algorithm>

// ── Vec3 ─────────────────────────────────────────────────────────────────────
struct Vec3 {
    float x = 0, y = 0, z = 0;
    Vec3() = default;
    Vec3(float x, float y, float z) : x(x), y(y), z(z) {}
    Vec3 operator+(const Vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    Vec3 operator*(float s)       const { return {x*s, y*s, z*s}; }
    Vec3 operator-()              const { return {-x, -y, -z}; }
    Vec3& operator+=(const Vec3& o) { x+=o.x; y+=o.y; z+=o.z; return *this; }
};

inline float dot(Vec3 a, Vec3 b)  { return a.x*b.x + a.y*b.y + a.z*b.z; }
inline Vec3  cross(Vec3 a, Vec3 b){ return {a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x}; }
inline float len(Vec3 v)          { return sqrtf(v.x*v.x + v.y*v.y + v.z*v.z); }
inline Vec3  normalize(Vec3 v)    { float l=len(v); return (l<1e-7f)?Vec3{}:v*(1.f/l); }

// ── Mat4 (column-major, like OpenGL) ─────────────────────────────────────────
struct Mat4 {
    float m[16]{};
    float& operator[](int i)       { return m[i]; }
    const float& operator[](int i) const { return m[i]; }
};

inline Mat4 mat4Identity() {
    Mat4 r; r[0]=r[5]=r[10]=r[15]=1.f; return r;
}

// C[col][row] = sum_k A[k][row] * B[col][k]
inline Mat4 operator*(const Mat4& A, const Mat4& B) {
    Mat4 C;
    for (int col=0;col<4;col++)
        for (int row=0;row<4;row++) {
            float s=0;
            for (int k=0;k<4;k++) s += A[k*4+row]*B[col*4+k];
            C[col*4+row]=s;
        }
    return C;
}

inline Mat4 mat4Perspective(float fovY, float aspect, float nearZ, float farZ) {
    float th = tanf(fovY*0.5f);
    Mat4 r;
    r[0]  =  1.f/(aspect*th);
    r[5]  =  1.f/th;
    r[10] = -(farZ+nearZ)/(farZ-nearZ);
    r[11] = -1.f;
    r[14] = -(2.f*farZ*nearZ)/(farZ-nearZ);
    return r;
}

inline Mat4 mat4LookAt(Vec3 eye, Vec3 center, Vec3 up) {
    Vec3 f = normalize(center-eye);
    Vec3 r = normalize(cross(f,up));
    Vec3 u = cross(r,f);
    Mat4 m;
    m[0]=r.x; m[4]=r.y; m[8] =r.z;
    m[1]=u.x; m[5]=u.y; m[9] =u.z;
    m[2]=-f.x;m[6]=-f.y;m[10]=-f.z;
    m[12]=-dot(r,eye); m[13]=-dot(u,eye); m[14]=dot(f,eye);
    m[15]=1.f;
    return m;
}

inline Mat4 mat4Ortho(float l, float r, float b, float t, float n, float f) {
    Mat4 m;
    m[0]=2/(r-l); m[5]=2/(t-b); m[10]=-2/(f-n);
    m[12]=-(r+l)/(r-l); m[13]=-(t+b)/(t-b); m[14]=-(f+n)/(f-n); m[15]=1;
    return m;
}
