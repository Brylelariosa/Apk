#pragma once
#include <string>

// Call once from nativeInit — installs SIGSEGV/SIGABRT/etc. handlers.
// On crash, writes a report to crashPath and re-raises the signal.
// Call loadCrashReport() on next launch to retrieve it.
void installCrashHandler(const char* crashFilePath);

// Returns empty string if no crash file, otherwise returns its contents
// and deletes the file so it only shows once.
std::string loadAndClearCrashReport(const char* crashFilePath);
