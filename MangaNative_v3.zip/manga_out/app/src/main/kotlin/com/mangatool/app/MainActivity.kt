package com.mangatool.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.mangatool.app.adapter.AppPickerAdapter
import com.mangatool.app.adapter.AppPickerItem
import com.mangatool.app.adapter.ChapterAdapter
import com.mangatool.app.databinding.ActivityMainBinding
import com.mangatool.app.databinding.BottomSheetAppPickerBinding
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.CbzCreator
import com.mangatool.app.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var chapterAdapter: ChapterAdapter? = null
    private var isProcessing = false
    private var chapterTouchHelper: ItemTouchHelper? = null

    // ── File pickers ──────────────────────────────────────────────────────────
    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data)
    }

    private val getContentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) handlePickResult(result.data)
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) Toast.makeText(this, "Storage permission needed", Toast.LENGTH_LONG).show()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        Prefs.init(this)
        AppState.minSizeKb   = Prefs.minSizeKb
        AppState.excludeGifs = Prefs.excludeGifs
        AppState.reverseOrder= Prefs.reverseOrder
        setupControls()
        setupActionBar()
        setupDragToReorder()
        setMode("extract")
        refreshUI()

        // Handle files shared FROM ZArchiver / other apps on launch
        handleIncomingShareIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Handle files shared FROM ZArchiver / other apps when app already running
        handleIncomingShareIntent(intent)
    }

    /**
     * Handles ACTION_SEND and ACTION_SEND_MULTIPLE intents from external apps
     * (e.g. ZArchiver "Open With"). This is the fix for ZArchiver multi-select.
     */
    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action ?: return
        val uris = mutableListOf<Uri>()

        when (action) {
            Intent.ACTION_SEND_MULTIPLE -> {
                // Multiple files shared — ZArchiver sends these via EXTRA_STREAM ArrayList
                @Suppress("UNCHECKED_CAST")
                val extras = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else
                    @Suppress("DEPRECATION")
                    intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                extras?.forEach { uri -> uris.add(uri) }
            }
            Intent.ACTION_SEND -> {
                // Single file shared
                val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                uri?.let { uris.add(it) }
            }
        }

        if (uris.isNotEmpty()) {
            processFiles(uris)
            // Clear the intent so rotating screen doesn't re-process
            setIntent(Intent(Intent.ACTION_MAIN))
        }
    }

    // ── UI setup ──────────────────────────────────────────────────────────────
    private fun setupControls() {
        b.tabExtract.setOnClickListener { setMode("extract") }
        b.tabMerge.setOnClickListener   { setMode("merge") }

        b.settingsToggle.setOnClickListener {
            val v = b.settingsPanel
            v.visibility = if (v.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        // Onboarding banner — show once on first install
        if (!Prefs.hasSeenOnboarding) {
            b.onboardingBanner.visibility = View.VISIBLE
        }
        b.onboardingDismiss.setOnClickListener {
            b.onboardingBanner.visibility = View.GONE
            Prefs.hasSeenOnboarding = true
        }

        b.sizeSlider.progress = AppState.minSizeKb
        updateSizeLabel()
        b.sizeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, v: Int, user: Boolean) {
                AppState.minSizeKb = v; Prefs.minSizeKb = v; updateSizeLabel()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { AppState.applyFilters(); refreshChapterList() }
        })

        b.toggleGifs.isChecked    = AppState.excludeGifs
        b.toggleReverse.isChecked = AppState.reverseOrder

        b.toggleGifs.setOnCheckedChangeListener    { _, c -> AppState.excludeGifs = c;  Prefs.excludeGifs = c;  AppState.applyFilters(); refreshChapterList() }
        b.toggleReverse.setOnCheckedChangeListener { _, c -> AppState.reverseOrder = c; Prefs.reverseOrder = c; AppState.applyFilters(); refreshChapterList() }

        b.dropZone.setOnClickListener { showFileManagerChooser() }
        b.chapterList.layoutManager = LinearLayoutManager(this)
    }

    private fun setupActionBar() {
        b.btnAddMore.setOnClickListener  { showFileManagerChooser() }
        b.btnDownload.setOnClickListener { startDownload() }
        b.btnViewAll.setOnClickListener  { openAllPhotos() }
        b.btnReset.setOnClickListener {
            chapterAdapter?.destroy()
            chapterAdapter = null
            b.chapterList.adapter = null
            AppState.reset()
            refreshUI()
        }
    }

    // ── Mode ──────────────────────────────────────────────────────────────────
    private fun setMode(mode: String) {
        AppState.currentMode = mode
        val activeColor   = 0xFFFFFFFF.toInt()
        val inactiveColor = 0xFF8B949E.toInt()
        if (mode == "extract") {
            b.tabExtract.setBackgroundResource(R.drawable.bg_tab_active)
            b.tabExtract.setTextColor(activeColor)
            b.tabMerge.setBackgroundResource(android.R.color.transparent)
            b.tabMerge.setTextColor(inactiveColor)
        } else {
            b.tabMerge.setBackgroundResource(R.drawable.bg_tab_active)
            b.tabMerge.setTextColor(activeColor)
            b.tabExtract.setBackgroundResource(android.R.color.transparent)
            b.tabExtract.setTextColor(inactiveColor)
        }
        b.mergeTip.visibility = if (mode == "merge") View.VISIBLE else View.GONE
        AppState.applyFilters()
        refreshChapterList()
    }

    private fun setupDragToReorder() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                rv: RecyclerView,
                from: RecyclerView.ViewHolder,
                to: RecyclerView.ViewHolder
            ): Boolean {
                val f = from.adapterPosition
                val t = to.adapterPosition
                if (f < 0 || t < 0) return false
                Collections.swap(AppState.groups, f, t)
                chapterAdapter?.notifyItemMoved(f, t)
                return true
            }
            override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
            override fun isLongPressDragEnabled() = false
        }
        chapterTouchHelper = ItemTouchHelper(callback)
        chapterTouchHelper?.attachToRecyclerView(b.chapterList)
    }

    private fun updateSizeLabel() { b.sizeLabel.text = "${AppState.minSizeKb} KB" }

    // ── Refresh UI ────────────────────────────────────────────────────────────
    private fun refreshUI() {
        val hasGroups = AppState.groups.isNotEmpty()
        b.dropZone.visibility    = if (hasGroups) View.GONE else View.VISIBLE
        b.chapterList.visibility = if (hasGroups) View.VISIBLE else View.GONE
        b.actionBar.visibility   = if (hasGroups) View.VISIBLE else View.GONE

        if (hasGroups) {
            val totalImgs     = AppState.groups.sumOf { it.displayImages.size }
            val totalFiltered = AppState.groups.sumOf { it.filteredImages.size }
            val totalKb       = AppState.groups.sumOf { g -> g.displayImages.sumOf { it.size.toLong() } } / 1024
            val sizeStr       = if (totalKb > 1024) "%.1f MB".format(totalKb / 1024.0) else "${totalKb} KB"
            val filteredStr   = if (totalFiltered > 0) "  ⚠ $totalFiltered filtered" else ""
            b.statsText.text   = "${AppState.groups.size} files · $totalImgs images · $sizeStr$filteredStr"
            b.btnDownload.text = "⬇ Save CBZ (~$sizeStr)"
        }
    }

    private fun refreshChapterList() {
        chapterAdapter?.destroy()
        chapterAdapter = ChapterAdapter(
            groups          = AppState.groups,
            onImageClick    = { gIdx, iIdx ->
                val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, iIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_MERGE, AppState.currentMode == "merge")
                }
                previewLauncher.launch(intent)
            },
            onGroupRemove   = { idx ->
                AppState.groups.removeAt(idx)
                AppState.applyFilters()
                refreshChapterList()
                refreshUI()
            },
            onImageLongClick = { img ->
                img.userDeleted = true; img.forceKeep = false
                AppState.applyFilters(); refreshChapterList()
            },
            onImageRestore  = { img ->
                img.forceKeep = true; img.userDeleted = false
                AppState.applyFilters(); refreshChapterList()
            },
            onFilteredPreview = { gIdx, filtIdx ->
                val intent = Intent(this, ImagePreviewActivity::class.java).apply {
                    putExtra(ImagePreviewActivity.EXTRA_GROUP_IDX, gIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IMAGE_IDX, filtIdx)
                    putExtra(ImagePreviewActivity.EXTRA_IS_FILTERED, true)
                }
                previewLauncher.launch(intent)
            },
            onBatchRestore  = { gIdx ->
                val group = AppState.groups.getOrNull(gIdx) ?: return@ChapterAdapter
                group.allImages.forEach { img ->
                    if (!img.userDeleted) { img.forceKeep = true }
                }
                AppState.applyFilters()
                refreshChapterList()
                Toast.makeText(this, "All images restored ✓", Toast.LENGTH_SHORT).show()
            }
        )
        b.chapterList.adapter = chapterAdapter
        chapterAdapter?.touchHelper = chapterTouchHelper
        refreshUI()
    }

    // ── File manager chooser ──────────────────────────────────────────────────
    private fun showFileManagerChooser() {
        val pm = packageManager

        val probeGetContent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        val probeOpenDoc = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }

        val seen  = mutableSetOf<String>()
        val items = mutableListOf<AppPickerItem>()

        fun addApp(pkg: String, actName: String?, actionType: String) {
            val key = "$pkg/$actName"
            if (pkg == packageName || !seen.add(key)) return
            runCatching {
                val info = pm.getApplicationInfo(pkg, 0)
                val icon = if (actName != null)
                    pm.getActivityIcon(ComponentName(pkg, actName))
                else
                    pm.getApplicationIcon(info)
                items.add(AppPickerItem(
                    label        = pm.getApplicationLabel(info).toString(),
                    icon         = icon,
                    packageName  = pkg,
                    activityName = actName,
                    actionType   = actionType
                ))
            }
        }

        pm.queryIntentActivities(probeGetContent, 0)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "GET_CONTENT") }

        pm.queryIntentActivities(probeOpenDoc, 0)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .forEach { addApp(it.activityInfo.packageName, it.activityInfo.name, "OPEN_DOCUMENT") }

        listOf(
            "ru.zdevs.zarchiver"                to "ZArchiver",
            "com.google.android.apps.nbu.files" to "Files",
            "com.amaze.filemanager"             to "Amaze",
            "com.ghisler.android.TotalCommander" to "Total Cmd",
            "com.estrongs.android.pop"           to "ES File",
            "nextapp.fx"                         to "FX File",
            "com.cxinventor.file.explorer"       to "CX Files",
            "com.sec.android.app.myfiles"        to "My Files",
            "com.mi.android.globalFileExplorer"  to "MI Files",
            "com.asus.filemanager"               to "ASUS Files",
            "com.coloros.filemanager"            to "Files",
            "com.rhmsoft.fm"                     to "File Manager+",
            "com.hmct.filemanager"               to "Files"
        ).forEach { (pkg, _) ->
            if (pm.getLaunchIntentForPackage(pkg) != null) addApp(pkg, null, "GET_CONTENT")
        }

        val dialog = BottomSheetDialog(this,
            com.google.android.material.R.style.Theme_Material3_Dark_BottomSheetDialog)
        val sheetBinding = BottomSheetAppPickerBinding.inflate(layoutInflater)
        dialog.setContentView(sheetBinding.root)

        // Show ZArchiver tip
        sheetBinding.tvPickerTitle.text = "Open file with…"

        val adapter = AppPickerAdapter(items) { item ->
            dialog.dismiss()
            launchSpecificApp(item)
        }
        sheetBinding.rvApps.layoutManager = GridLayoutManager(this, 4)
        sheetBinding.rvApps.adapter = adapter

        sheetBinding.tvCancel.text = "Cancel"
        sheetBinding.tvCancel.setTextColor(0xFFAAAAAA.toInt())
        sheetBinding.tvCancel.setOnClickListener { dialog.dismiss() }

        dialog.show()
    }

    private fun launchSpecificApp(item: AppPickerItem) {
        val action = if (item.actionType == "OPEN_DOCUMENT")
            Intent.ACTION_OPEN_DOCUMENT else Intent.ACTION_GET_CONTENT
        val intent = Intent(action).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "image/jpeg", "image/png", "image/webp", "image/gif",
                "multipart/related", "message/rfc822", "application/octet-stream"
            ))
            addCategory(Intent.CATEGORY_OPENABLE)
            if (item.packageName != null && item.activityName != null)
                component = ComponentName(item.packageName, item.activityName)
            else if (item.packageName != null)
                setPackage(item.packageName)
        }
        val launcher = if (item.actionType == "OPEN_DOCUMENT") openDocLauncher else getContentLauncher
        runCatching { launcher.launch(intent) }.onFailure {
            runCatching {
                launcher.launch(Intent(action).apply {
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addCategory(Intent.CATEGORY_OPENABLE)
                    if (item.packageName != null) setPackage(item.packageName)
                })
            }.onFailure {
                getContentLauncher.launch(Intent.createChooser(
                    Intent(Intent.ACTION_GET_CONTENT).apply {
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        addCategory(Intent.CATEGORY_OPENABLE)
                    }, "Open files with…"
                ))
            }
        }
    }

    private fun handlePickResult(data: Intent?) {
        val uris: List<Uri> = when {
            data?.clipData != null -> (0 until data.clipData!!.itemCount)
                .map { data.clipData!!.getItemAt(it).uri }
            data?.data != null -> listOf(data.data!!)
            else -> emptyList()
        }
        if (uris.isNotEmpty()) processFiles(uris)
    }

    // ── File processing ───────────────────────────────────────────────────────
    private fun processFiles(uris: List<Uri>) {
        if (isProcessing) return
        isProcessing = true
        b.progressArea.visibility = View.VISIBLE
        b.dropZone.visibility = View.GONE
        b.actionBar.visibility = View.GONE

        lifecycleScope.launch {
            val looseImages = mutableListOf<ImageItem>()

            uris.forEachIndexed { i, uri ->
                withContext(Dispatchers.Main) {
                    b.progressStatus.text = "Reading ${i + 1}/${uris.size}…"
                    b.progressBar.progress = (i * 100) / uris.size
                }

                val name = getFileName(uri).lowercase()
                val data: ByteArray? = withContext(Dispatchers.IO) {
                    runCatching { contentResolver.openInputStream(uri)?.readBytes() }.getOrNull()
                }
                if (data == null) return@forEachIndexed

                when {
                    name.endsWith(".mhtml") || name.endsWith(".mht") -> {
                        val group = withContext(Dispatchers.IO) {
                            MhtmlParser.parse(data, getFileName(uri))
                        }
                        if (group != null) AppState.groups.add(group)
                    }
                    name.matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)")) -> {
                        val ext = name.substringAfterLast('.')
                        looseImages.add(ImageItem(looseImages.size, data, ext, data.size))
                    }
                }
            }

            if (looseImages.isNotEmpty()) {
                AppState.groups.add(
                    ImageGroup("Loose Images ${AppState.groups.size + 1}")
                        .also { it.allImages.addAll(looseImages) }
                )
            }

            AppState.applyFilters()
            isProcessing = false
            b.progressArea.visibility = View.GONE
            refreshChapterList()
        }
    }

    private fun getFileName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        return cursor?.use {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            it.moveToFirst()
            if (idx >= 0) it.getString(idx) else "file"
        } ?: uri.lastPathSegment ?: "file"
    }

    // ── Download ──────────────────────────────────────────────────────────────
    private fun startDownload() {
        if (AppState.groups.isEmpty()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }

        val defaultName = if (AppState.groups.size == 1)
            AppState.groups[0].groupName
        else
            "Manga_Batch"

        val input = EditText(this).apply {
            setText(defaultName)
            setSelection(0, defaultName.length)
            hint = "CBZ filename"
            setPadding(48, 24, 48, 8)
        }
        AlertDialog.Builder(this)
            .setTitle("Save as…")
            .setMessage("Choose a name for the CBZ file")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val chosenName = input.text.toString().trim()
                    .replace(Regex("[\\\\/:*?\"<>|]"), "_")
                    .ifBlank { defaultName }
                val filename = if (chosenName.endsWith(".cbz", true)) chosenName else "$chosenName.cbz"
                performSave(filename)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performSave(filename: String) {
        b.btnDownload.isEnabled = false
        b.progressArea.visibility = View.VISIBLE
        val isMerge = AppState.currentMode == "merge"

        lifecycleScope.launch(Dispatchers.IO) {
            runCatching {
                CbzCreator.create(
                    context    = this@MainActivity,
                    groups     = AppState.groups,
                    filename   = filename,
                    isMerge    = isMerge,
                    onProgress = { p ->
                        lifecycleScope.launch(Dispatchers.Main) {
                            b.progressStatus.text  = p.message
                            b.progressBar.progress = p.percent
                        }
                    }
                )
            }.onSuccess {
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    b.btnDownload.text        = "✅ Saved!"
                    Toast.makeText(this@MainActivity, "Saved: $filename", Toast.LENGTH_LONG).show()
                }
            }.onFailure { e ->
                withContext(Dispatchers.Main) {
                    b.progressArea.visibility = View.GONE
                    b.btnDownload.isEnabled   = true
                    Toast.makeText(this@MainActivity, "Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ── View All Photos ───────────────────────────────────────────────────────
    private fun openAllPhotos() {
        if (AppState.groups.isEmpty()) return
        startActivity(Intent(this, AllPhotosActivity::class.java))
    }

    // ── Preview result ────────────────────────────────────────────────────────
    private val previewLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            AppState.applyFilters()
            refreshChapterList()
        }
    }
}
