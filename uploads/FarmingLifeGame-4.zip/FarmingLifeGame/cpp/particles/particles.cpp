#include "particles/particles.h"
namespace cf {
Particle* ParticleSystem::emit(Fx t, float x, float y, float vx, float vy, float life, u32 color, float gravity, bool screen) {
  if (live_ >= cap_) return nullptr;
  size_t n = pool_.size();
  for (size_t i = 0; i < n; ++i) {
    Particle& p = pool_[(size_t)(cursor_ + (int)i) % n];
    if (p.active) continue;
    cursor_ = (int)(((size_t)cursor_ + i + 1) % n);
    p = Particle(); p.active = true; p.type = t; p.x = x; p.y = y; p.vx = vx; p.vy = vy; p.life = p.maxLife = life; p.color = color; p.gravity = gravity; p.screen = screen;
    p.frame = (u8)(((int)(x * 7 + y * 13)) & 3); ++live_;
    return &p;
  }
  return nullptr;
}
void ParticleSystem::update(float dt, float vw, float vh) {
  live_ = 0;
  for (auto& p : pool_) {
    if (!p.active) continue;
    p.life -= dt;
    if (p.life <= 0) { p.active = false; continue; }
    p.vy += p.gravity * dt; p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.screen) {   // wrap weather particles around the view
      if (p.x < -8) p.x += vw + 16; if (p.x > vw + 8) p.x -= vw + 16;
      if (p.type == Fx::Snow || p.type == Fx::Leaf || p.type == Fx::Petal) { if (p.y > vh + 6) { p.y = -6; p.life = p.maxLife; } }
    }
    ++live_;
  }
}
void ParticleSystem::render(Renderer& r, float cx, float cy, bool reduced) const {
  SpriteBatch& b = r.batch;
  for (const Particle& p : pool_) {
    if (!p.active) continue;
    float x = p.screen ? p.x : p.x - cx, y = p.screen ? p.y : p.y - cy;
    float a = clampv(p.life / std::min(p.maxLife, 0.5f), 0.f, 1.f);
    const char* nm = nullptr; char buf[32];
    switch (p.type) {
      case Fx::Rain: nm = "fx_rain"; break; case Fx::RainHeavy: nm = "fx_rain_heavy"; break;
      case Fx::Snow: snprintf(buf, sizeof buf, "fx_snow_%d", p.frame % 3); nm = buf; break;
      case Fx::Leaf: snprintf(buf, sizeof buf, "fx_leaf_%d", p.frame & 3); nm = buf; break;
      case Fx::Petal: snprintf(buf, sizeof buf, "fx_petal_%d", p.frame & 1); nm = buf; break;
      case Fx::Dust: snprintf(buf, sizeof buf, "fx_dust_%d", p.frame % 3); nm = buf; break;
      case Fx::Sparkle: snprintf(buf, sizeof buf, "fx_sparkle_%d", (int)((1.f - p.life / p.maxLife) * 3) % 3); nm = buf; break;
      case Fx::Splash: snprintf(buf, sizeof buf, "fx_splash_%d", clampv((int)((1.f - p.life / p.maxLife) * 3), 0, 2)); nm = buf; break;
      case Fx::Ripple: snprintf(buf, sizeof buf, "fx_ripple_%d", clampv((int)((1.f - p.life / p.maxLife) * 4), 0, 3)); nm = buf; break;
      case Fx::Chip: snprintf(buf, sizeof buf, "fx_chip_%d", p.frame % 3); nm = buf; break;
      case Fx::Heart: nm = "fx_heart"; break; case Fx::Hit: snprintf(buf, sizeof buf, "fx_hit_%d", p.frame % 3); nm = buf; break;
      case Fx::Drop: nm = "fx_drop"; break; case Fx::Zzz: nm = "fx_zzz"; break; case Fx::Note: nm = "fx_note"; break; case Fx::Exclaim: nm = "fx_exclaim"; break;
      case Fx::Butterfly: snprintf(buf, sizeof buf, "fx_butterfly_%d_%d", p.frame % 3, ((int)(p.life * 8)) & 1); nm = buf; break;
      case Fx::Firefly: nm = "fx_firefly"; break;
      case Fx::Fog: nm = "fx_fog"; break;
    }
    if (reduced && (p.type == Fx::Sparkle || p.type == Fx::Hit)) continue;
    const Region& rg = Sprites::ui.get(nm);
    u32 c = p.color;
    if (p.type == Fx::Fog) c = col::withAlpha(c, std::min(1.f, a) * 0.55f);
    else if (p.type == Fx::Rain || p.type == Fx::RainHeavy || p.type == Fx::Snow) c = col::withAlpha(c, 0.9f);
    else c = col::withAlpha(c, a);
    b.region(rg, x, y, c, false, p.type == Fx::Fog ? p.size : 1.f, p.type == Fx::Fog ? p.size : 1.f);
  }
}
}  // namespace cf
