// Pooled particle system: fixed capacity, zero allocation during play.
#pragma once
#include "renderer/renderer.h"
namespace cf {
enum class Fx : u8 { Rain, RainHeavy, Snow, Leaf, Petal, Dust, Sparkle, Splash, Ripple, Chip, Heart, Hit, Drop, Butterfly, Firefly, Fog, Zzz, Note, Exclaim };
struct Particle { float x = 0, y = 0, vx = 0, vy = 0, life = 0, maxLife = 1, size = 1, gravity = 0, spin = 0; u32 color = kWhite; Fx type = Fx::Dust; u8 frame = 0; bool screen = false; bool active = false; };
class ParticleSystem {
 public:
  void setCapacity(int n) { cap_ = clampv(n, 0, (int)pool_.size()); }
  ParticleSystem() : pool_(1400) {}
  Particle* emit(Fx t, float x, float y, float vx, float vy, float life, u32 color = kWhite, float gravity = 0, bool screen = false);
  void update(float dt, float viewW, float viewH);
  void render(Renderer& r, float camX, float camY, bool reduced) const;
  int count() const { return live_; }
  void clear() { for (auto& p : pool_) p.active = false; live_ = 0; }
 private:
  std::vector<Particle> pool_; int cap_ = 600, live_ = 0, cursor_ = 0;
};
}  // namespace cf
