// Data-driven quest log: objectives are driven by gameplay events; rewards unlock recipes, items, friendship and story flags.
#include "game/game.h"

namespace cf {

QuestState* Game::questState(const std::string& id) {
  int q = C().quest(id); if (q < 0) return nullptr;
  for (auto& qs : s.quests) if (qs.def == q) return &qs;
  return nullptr;
}

bool Game::questAvailable(const QuestDef& q) const {
  for (auto& qs : s.quests) if (C().quests[(size_t)qs.def].id == q.id) return false;
  if (s.cal.totalDays() < q.minDay || !(q.seasons & (1 << s.cal.season))) return false;
  if (!q.after.empty()) { bool ok = false; for (auto& qs : s.quests) if (qs.done && C().quests[(size_t)qs.def].id == q.after) ok = true; if (!ok) return false; }
  if (!q.flag.empty() && !flag(q.flag)) return false;
  if (!q.needHearts.empty()) { int ni = C().npc(q.needHearts); if (ni < 0 || s.npcs[(size_t)ni].hearts() < q.needHeartsN) return false; }
  return true;
}

bool Game::questObjectiveDone(const QuestDef& q, const QuestState& qs, size_t i) const {
  const Objective& o = q.objs[i];
  if (o.type == "have") return s.pl.inv.count(C().item(o.arg)) >= o.count;
  if (o.type == "hearts") { int ni = C().npc(o.arg); return ni >= 0 && s.npcs[(size_t)ni].hearts() >= o.count; }
  if (o.type == "flag") return flag(o.arg);
  if (o.type == "mine") return qs.prog[i] >= 1;
  if (o.type == "deliver" || o.type == "talk" || o.type == "visit") return qs.prog[i] >= 1;
  return qs.prog[i] >= o.count;
}

void Game::updateQuests() {
  for (auto& q : C().quests) {
    if (!questAvailable(q)) continue;
    QuestState qs; qs.def = C().quest(q.id); qs.prog.assign(q.objs.size(), 0);
    s.quests.push_back(qs);
    if (!q.hidden) { toast("New quest: " + q.title, "ic_quest"); audio->play(Sfx::Chime, 0.8f); }
  }
  for (auto& qs : s.quests) {
    if (qs.done) continue;
    const QuestDef& q = C().quests[(size_t)qs.def];
    bool all = !q.objs.empty();
    bool needsDelivery = false;
    for (size_t i = 0; i < q.objs.size(); ++i) { if (!questObjectiveDone(q, qs, i)) all = false; if (q.objs[i].type == "deliver") needsDelivery = true; }
    (void)needsDelivery;
    if (all) { completeQuest(qs); break; }
  }
}

void Game::completeQuest(QuestState& qs) {
  const QuestDef& q = C().quests[(size_t)qs.def];
  qs.done = true;
  for (auto& r : q.rewards) {
    if (r.type == "money") addMoney(r.n);
    else if (r.type == "item") { ItemStack st; st.id = (u16)C().item(r.arg); st.count = (u16)std::max(1, r.n); if (st.id) giveItem(st); }
    else if (r.type == "friend") { int ni = C().npc(r.arg); if (ni >= 0) addFriendship(s.npcs[(size_t)ni], r.n); }
    else if (r.type == "flag") setFlag(r.arg);
    else if (r.type == "recipe") s.recipes.insert(r.arg);
    else if (r.type == "animal") {
      int ai = C().animal(r.arg); Map* fm = getMap("farm");
      if (ai >= 0 && fm) for (int k = 0; k < (int)fm->buildings.size(); ++k)
        if (C().buildings[(size_t)fm->buildings[(size_t)k].def].animals == C().animals[(size_t)ai].home) { s.pl.money += C().animals[(size_t)ai].price; buyAnimal(ai, k); break; }
    }
  }
  toast("Quest complete: " + q.title, "ic_check"); audio->play(Sfx::Confirm);
  if (!q.doneText.empty() && top() == St::Gameplay) {
    int ni = C().npc(q.giver);
    showDialogue(ni >= 0 ? C().npcs[(size_t)ni].name : "Quest complete", ni >= 0 ? "por_" + q.giver : "", "happy", q.doneText, {{299, "Wonderful!"}});
    dlg.npc = -1;
  }
}

void Game::tryDeliver(int ni) {
  NpcState& n = s.npcs[(size_t)ni]; const NpcDef& d = C().npcs[(size_t)n.def];
  for (auto& qs : s.quests) {
    if (qs.done) continue; const QuestDef& q = C().quests[(size_t)qs.def];
    for (size_t i = 0; i < q.objs.size(); ++i) {
      const Objective& o = q.objs[i];
      if (o.type != "deliver" || o.arg != d.id || qs.prog[i] >= 1) continue;
      int item = C().item(o.arg2);
      if (s.pl.inv.count(item) >= o.count) { s.pl.inv.remove(item, o.count); qs.prog[i] = 1; toast(fmt("Delivered %d %s", o.count, C().def(item).name.c_str()), "item_" + C().def(item).id); audio->play(Sfx::Confirm); updateQuests(); return; }
    }
  }
}

void Game::emitEvent(const std::string& type, const std::string& arg, int n) {
  s.counters["ev_" + type] += n;
  for (auto& qs : s.quests) {
    if (qs.done) continue; const QuestDef& q = C().quests[(size_t)qs.def];
    for (size_t i = 0; i < q.objs.size(); ++i) {
      const Objective& o = q.objs[i];
      bool match = false;
      if (o.type == type) {
        if (type == "mine") { if (atoi(arg.c_str()) >= atoi(o.arg.c_str())) qs.prog[i] = 1; continue; }
        match = o.arg.empty() || o.arg == "any" || o.arg == arg;
      } else if (type == "break" && o.type == "mine_rock") match = true;
      if (match) qs.prog[i] = std::min(qs.prog[i] + n, 9999);
    }
  }
  if (type != "visit" || true) updateQuests();
}
}  // namespace cf
