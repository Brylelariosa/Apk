// Conversation selection (data-driven lines with conditions), story events and dialogue flow.
#include "engine/log.h"
#include "game/game.h"

namespace cf {

std::string Game::pickLine(const NpcState& n, const std::string& tag) {
  const NpcDef& d = C().npcs[(size_t)n.def];
  int hearts = n.hearts(), wb = weatherBit(s.wx.today), dow = s.cal.dayOfWeek(), sea = s.cal.season;
  std::vector<const SayLine*> best, any;
  for (auto& l : C().says) {
    if (l.npc != d.id || l.tag != tag) continue;
    if (hearts < l.h0 || hearts > l.h1 || !(l.seasons & (1 << sea)) || !(l.days & (1 << dow))) continue;
    if (l.weather && !(l.weather & wb)) continue;
    if (!l.act.empty() && l.act != n.act) continue;
    if (!l.flag.empty() && !flag(l.flag)) continue;
    bool specific = !l.act.empty() || l.weather || l.seasons != 15 || l.days != 127 || !l.flag.empty();
    (specific ? best : any).push_back(&l);
  }
  const std::vector<const SayLine*>& pool = (!best.empty() && (any.empty() || rng.chance(0.65f))) ? best : any;
  if (pool.empty()) return tag == "greet" ? "Hello there!" : (tag == "again" ? "We've already chatted today, but it's always nice to see you." : "");
  return pool[(size_t)rng.range(0, (int)pool.size() - 1)]->text;
}

void Game::showDialogue(const std::string& speaker, const std::string& portrait, const std::string& expr, const std::string& text, const std::vector<std::pair<int, std::string>>& choices) {
  dlg.speaker = speaker; dlg.portrait = portrait; dlg.expr = expr.empty() ? "neutral" : expr;
  dlg.pages.clear();
  size_t st = 0;
  while (st <= text.size()) { size_t e = text.find("||", st); if (e == std::string::npos) e = text.size(); dlg.pages.push_back(text.substr(st, e - st)); st = e + 2; }
  dlg.page = 0; dlg.typeT = 0; dlg.choices.clear(); dlg.ids.clear();
  for (auto& c : choices) { dlg.ids.push_back(c.first); dlg.choices.push_back(c.second); }
  if (top() != St::Dialogue) push(St::Dialogue);
}

void Game::startTalk(int ni) {
  NpcState& n = s.npcs[(size_t)ni]; const NpcDef& d = C().npcs[(size_t)n.def];
  n.facing = dirFromVec(s.pl.pos.x - n.pos.x, s.pl.pos.y - n.pos.y); n.talkT = 2.f;
  dlg = Dialogue(); dlg.npc = ni; dlg.mode = 0; dlg.portrait = "por_" + d.id;
  audio->play(Sfx::Click, 0.7f);
  // story events first
  for (size_t ei = 0; ei < C().events.size(); ++ei) {
    const EventDef& e = C().events[ei];
    if (e.npc != d.id || n.hearts() < e.hearts || flag(e.setFlag) || (!e.flag.empty() && !flag(e.flag))) continue;
    dlg.mode = 1; dlg.ev = (int)ei; dlg.evLine = 0;
    const auto& ln = e.lines[0];
    showDialogue(ln.first == "you" ? s.pl.name : d.name, ln.first == "you" ? "" : "por_" + d.id, "neutral", ln.second);
    return;
  }
  bool first = !n.talked;
  std::string text = pickLine(n, first ? "greet" : "again");
  const ShopDef* sd = d.shop.empty() ? nullptr : &C().shops[(size_t)C().shop(d.shop)];
  if (n.dating == 2) { std::string sp = pickLine(n, "spouse"); if (!sp.empty()) text = sp; }
  if (d.bdaySeason == s.cal.season && d.bdayDay == s.cal.day) { std::string b = pickLine(n, "birthday"); if (!b.empty()) text = b; }
  if (first) { n.talked = true; addFriendship(n, 20); emitEvent("talk", d.id); s.counters["talks"]++; }
  std::vector<std::pair<int, std::string>> ch;
  if (sd) {
    bool open = shopOpen(*sd) && n.act == "shop";
    if (open) ch.push_back({1, d.shop == "smith" ? "Workshop" : "Shop"});
    else if (first || rng.chance(0.3f)) { std::string cl = pickLine(n, "closed"); if (!cl.empty() && !open) text += "||" + cl; }
  }
  if (const FestivalDef* fd = todaysFestival()) if (fd->host == d.id && !flag(fmt("fest_%s_y%d", fd->id.c_str(), s.cal.year))) ch.push_back({5, "Join the festival activity"});
  if (!n.gifted) ch.push_back({2, "Give a gift"});
  for (auto& qs : s.quests) if (!qs.done) { const QuestDef& q = C().quests[(size_t)qs.def]; for (size_t i = 0; i < q.objs.size(); ++i) if (q.objs[i].type == "deliver" && q.objs[i].arg == d.id && !questObjectiveDone(q, qs, i) && s.pl.inv.count(C().item(q.objs[i].arg2)) >= q.objs[i].count) { ch.push_back({3, "Hand over " + C().def(C().item(q.objs[i].arg2)).name}); i = q.objs.size(); } }
  ch.push_back({4, "Goodbye"});
  bool happy = n.hearts() >= 6;
  showDialogue(d.name, dlg.portrait, happy ? "happy" : "neutral", text, ch);
}

void Game::dialogueChoice(int id) {
  NpcState* n = dlg.npc >= 0 ? &s.npcs[(size_t)dlg.npc] : nullptr;
  if (id >= 300 && id <= 320) {    // mine lift
    pop(); if (id == 299) return;
    int fl = id - 300; enterMap(fmt("mine_%d", fl < 1 ? 1 : fl), "start"); return;
  }
  if (id == 299) { pop(); return; }
  if (!n) { pop(); return; }
  const NpcDef& d = C().npcs[(size_t)n->def];
  if (dlg.mode == 1 && id >= 10 && id < 20) {   // event answer
    const EventDef& e = C().events[(size_t)dlg.ev]; int a = id - 10;
    addFriendship(*n, e.deltas[(size_t)a]); setFlag(e.setFlag);
    dlg.mode = 0; dlg.choices.clear(); dlg.ids.clear(); dlg.pages = {e.replies[(size_t)a]}; dlg.page = 0; dlg.typeT = 0; dlg.expr = e.deltas[(size_t)a] >= 0 ? "happy" : "sad";
    dlg.ids.push_back(4); dlg.choices.push_back("Continue");
    fx.emit(Fx::Heart, n->pos.x, n->pos.y - 24, 0, -14, 1.f);
    return;
  }
  switch (id) {
    case 1: { int si = C().shop(d.shop); pop(); if (si >= 0) openShop(si, dlg.npc); break; }
    case 2: giftNpc = dlg.npc; pop(); push(St::Gift); break;
    case 3: pop(); tryDeliver(dlg.npc); break;
    case 5: pop(); startFestivalActivity(); break;
    default: pop(); break;
  }
}
}  // namespace cf
