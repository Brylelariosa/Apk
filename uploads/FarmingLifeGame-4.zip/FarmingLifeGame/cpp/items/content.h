// Data-driven content tables (items, crops, objects, animals, fish, recipes, npcs, dialogue, quests...). Loaded from assets/data/*.cfd.
#pragma once
#include <memory>
#include <unordered_map>
#include "engine/data_file.h"
#include "renderer/atlas.h"

namespace cf {

enum Season : int { Spring = 0, Summer = 1, Autumn = 2, Winter = 3 };
extern const char* const kSeasonNames[4];
extern const char* const kDayNames[7];
inline int seasonFromName(const std::string& s) { for (int i = 0; i < 4; ++i) if (s == kSeasonNames[i]) return i; return -1; }
int seasonMask(const std::vector<std::string>& names);   // bit per season; empty -> all

enum class Cat : u8 { Tool, Seed, Crop, Forage, Fish, Mineral, Material, Food, Product, Artisan, Placeable, Fertilizer, Feed, Gift, Quest, Misc };
enum class ToolType : u8 { None, Hoe, Can, Axe, Pick, Rod, Hammer, Shears };
enum class BuffType : u8 { None, Farm, Mine, Fish, Speed, Luck, Energy };
const char* buffName(BuffType b);

struct Buff { BuffType type = BuffType::None; int amount = 0; int minutes = 0; };

struct ItemDef {
  std::string id, name, desc, placeObj, tag;
  Cat cat = Cat::Misc;
  ToolType tool = ToolType::None;
  int sell = 0, buy = 0, stack = 99, energy = 0, health = 0;
  Buff buff;
  const Region* icon = nullptr;
  const Region* toolIcon[6] = {};
  bool edible() const { return energy > 0 || health > 0; }
};

struct ItemStack {
  u16 id = 0, count = 0;
  u8 quality = 0, tier = 0;
  u16 aux = 0;
  bool empty() const { return id == 0 || count == 0; }
  bool operator==(const ItemStack& o) const { return id == o.id && quality == o.quality && tier == o.tier; }
};

struct DropDef { int item = 0, mn = 1, mx = 1; float chance = 1.f; };

struct CropDef {
  std::string id;
  int item = 0, seed = 0, seasons = 15, days = 4, regrow = 0, yMin = 1, yMax = 1, thirst = 0, xp = 5;
  const Region* stage[6] = {};
  const Region* dead = nullptr;
};

enum class ObjKind : u8 { None, Tree, Stump, Log, Rock, Ore, Weed, Twig, Dig, Forage, Crop, Chest, Machine, Fence, Sprinkler, Scarecrow, Lamp, Bin,
                          Bed, Kitchen, Decor, Sign, Board, Lantern, Wisp, Ladder, Hole, Hazard, Treasure, Feeder, Collector, DecoTop, Floor, WallDeco, DecoWater };

struct ObjDef {
  std::string id, name, art;
  ObjKind kind = ObjKind::Decor;
  ToolType tool = ToolType::None;
  int tier = 0, hp = 1, fw = 1, fh = 1, shadow = 0;
  bool solid = false, seasonal = false, anyTool = false;
  std::vector<DropDef> drops;
  float lightR = 0; u32 lightCol = 0;
  const Region* spr[4] = {};
  int itemId = 0;        // placeable item that creates it (0 if none)
};

struct AnimalDef {
  std::string id, name, home, art;
  int price = 0, product = 0, interval = 1, adult = 3;
  bool shears = false;
  float speed = 16;
};

struct FishDef { int item = 0; std::string water; int seasons = 15, t0 = 360, t1 = 1560; std::string weather; float weight = 1, diff = 0.3f; };
struct ForageDef { int item = 0, seasons = 15; std::vector<std::string> maps; float weight = 1; bool sand = false; const Region* spr = nullptr; };

struct Ingredient { int item = 0; std::string group; int count = 1; };   // item>0 -> exact, group = "cat:fish"/"tag:veg"
struct RecipeDef { std::string id, station, unlock; int out = 0, outCount = 1; std::vector<Ingredient> in; };
struct ProcDef { std::string machine; std::vector<Ingredient> in; int out = 0, outCount = 1, minutes = 60; };

struct BuildingDef {
  std::string id, sprite;
  int w = 3, h = 3, door = 1, levels = 1, capacity[3] = {0, 0, 0};
  std::string animals;
  const Region* spr[4] = {};
};
struct UpgradeDef { std::string building; int level = 2, gold = 0, days = 2; std::vector<Ingredient> in; };
struct ToolUpDef { int tier = 1, gold = 0, days = 2; std::vector<Ingredient> in; };

struct ShopItem { int item = 0, price = 0, seasons = 15, minHearts = 0; };
struct ShopDef { std::string id, npc, kind, name; int open = 540, close = 1020; std::string closed; std::vector<ShopItem> stock; std::vector<std::string> animals; std::string bonusCat; float bonus = 1.f; };

struct SchedEntry { int t = 0; std::string map, at, rainAt, act; int days = 127, seasons = 15; };
struct NpcDef {
  std::string id, name, job, home, shop, bio;
  bool female = false, romance = false;
  int bdaySeason = 0, bdayDay = 1;
  std::vector<std::string> loves, likes, dislikes, hates;
  std::vector<SchedEntry> sched;
  const Region* spr[4][3][12] = {};     // [season][dir d/u/s][anim frames] resolved lazily by animation module (names)
  std::string portraitBase;
};

struct SayLine {
  std::string npc, tag, text, act, flag;
  int h0 = 0, h1 = 99, seasons = 15, days = 127, weather = 0;   // weather bits: 1 sun, 2 rain, 4 snow, 8 storm
};
struct EventDef {
  std::string id, npc, flag, setFlag, question;
  int hearts = 2;
  std::vector<std::pair<std::string, std::string>> lines;   // speaker id ("you" for player), text
  std::vector<std::string> answers, replies;
  std::vector<int> deltas;
};

struct Objective { std::string type, arg, arg2; int count = 1; };
struct QuestReward { std::string type, arg; int n = 0; };
struct QuestDef {
  std::string id, title, desc, giver, after, flag, doneText, startText;
  int minDay = 1, seasons = 15;
  std::string needHearts; int needHeartsN = 0;
  std::vector<Objective> objs;
  std::vector<QuestReward> rewards;
  bool hidden = false;
};

struct FestivalDef { std::string id, name, host, activity, text; int season = 0, day = 1; int prize = 0; std::string prizeItem; };

class Content {
 public:
  std::vector<ItemDef> items{ItemDef()};            // index 0 = "nothing"
  std::vector<CropDef> crops;
  std::vector<ObjDef> objs;
  std::vector<AnimalDef> animals;
  std::vector<FishDef> fish;
  std::vector<ForageDef> forage;
  std::vector<RecipeDef> recipes;
  std::vector<ProcDef> procs;
  std::vector<BuildingDef> buildings;
  std::vector<UpgradeDef> upgrades;
  std::vector<ToolUpDef> toolUps;
  std::vector<ShopDef> shops;
  std::vector<NpcDef> npcs;
  std::vector<SayLine> says;
  std::vector<EventDef> events;
  std::vector<QuestDef> quests;
  std::vector<FestivalDef> festivals;
  int forageObj = -1;                         // synthetic object def used for forage items
  std::vector<const Region*> forageSpr;      // indexed by item id (world-atlas sprite for forage objects)
  std::unordered_map<std::string, int> itemIdx, cropIdx, objIdx, animalIdx, buildingIdx, npcIdx, shopIdx, questIdx, recipeIdx, eventIdx;

  bool load();
  int item(const std::string& id) const { auto it = itemIdx.find(id); return it == itemIdx.end() ? 0 : it->second; }
  int crop(const std::string& id) const { auto it = cropIdx.find(id); return it == cropIdx.end() ? -1 : it->second; }
  int obj(const std::string& id) const { auto it = objIdx.find(id); return it == objIdx.end() ? -1 : it->second; }
  int animal(const std::string& id) const { auto it = animalIdx.find(id); return it == animalIdx.end() ? -1 : it->second; }
  int building(const std::string& id) const { auto it = buildingIdx.find(id); return it == buildingIdx.end() ? -1 : it->second; }
  int npc(const std::string& id) const { auto it = npcIdx.find(id); return it == npcIdx.end() ? -1 : it->second; }
  int shop(const std::string& id) const { auto it = shopIdx.find(id); return it == shopIdx.end() ? -1 : it->second; }
  int quest(const std::string& id) const { auto it = questIdx.find(id); return it == questIdx.end() ? -1 : it->second; }
  int recipe(const std::string& id) const { auto it = recipeIdx.find(id); return it == recipeIdx.end() ? -1 : it->second; }
  int cropOfSeed(int seedItem) const { for (size_t i = 0; i < crops.size(); ++i) if (crops[i].seed == seedItem) return (int)i; return -1; }
  int cropOfItem(int itemId) const { for (size_t i = 0; i < crops.size(); ++i) if (crops[i].item == itemId) return (int)i; return -1; }
  const ItemDef& def(int id) const { return items[(size_t)(id >= 0 && id < (int)items.size() ? id : 0)]; }
  const Region& icon(const ItemStack& s) const;
  Ingredient parseIngredient(const std::string& s) const;
  std::vector<Ingredient> parseIngredients(const std::string& s) const;
  bool matches(const Ingredient& g, int itemId) const;
 private:
  void loadItems(); void loadCrops(); void loadObjects(); void loadAnimals(); void loadFish(); void loadForage(); void loadRecipes();
  void loadBuildings(); void loadShops(); void loadNpcs(); void loadStory();
};
extern Content g_content;
inline const Content& C() { return g_content; }

int sellPrice(const ItemStack& s);          // quality multiplier applied
const char* qualityName(int q);
std::string clockString(int minutes);       // "6:00 AM"
}  // namespace cf
