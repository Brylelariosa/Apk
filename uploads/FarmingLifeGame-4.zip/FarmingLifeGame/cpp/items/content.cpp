#include "items/content.h"
#include "engine/log.h"

namespace cf {
Content g_content;
const char* const kSeasonNames[4] = {"spring", "summer", "autumn", "winter"};
const char* const kDayNames[7] = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"};

int seasonMask(const std::vector<std::string>& names) {
  if (names.empty()) return 15;
  int m = 0;
  for (auto& n : names) { int s = seasonFromName(n); if (s >= 0) m |= 1 << s; }
  return m ? m : 15;
}
const char* buffName(BuffType b) {
  switch (b) { case BuffType::Farm: return "Farming"; case BuffType::Mine: return "Mining"; case BuffType::Fish: return "Fishing"; case BuffType::Speed: return "Speed";
               case BuffType::Luck: return "Luck"; case BuffType::Energy: return "Energy"; default: return ""; }
}
static BuffType buffFromName(const std::string& s) {
  if (s == "farm") return BuffType::Farm; if (s == "mine") return BuffType::Mine; if (s == "fish") return BuffType::Fish;
  if (s == "speed") return BuffType::Speed; if (s == "luck") return BuffType::Luck; if (s == "energy") return BuffType::Energy;
  return BuffType::None;
}
const char* qualityName(int q) { static const char* n[4] = {"", "Fine", "Superb", "Radiant"}; return n[clampv(q, 0, 3)]; }
int sellPrice(const ItemStack& s) {
  static const float mul[4] = {1.f, 1.25f, 1.5f, 2.f};
  return (int)(C().def(s.id).sell * mul[clampv((int)s.quality, 0, 3)]);
}
std::string clockString(int m) {
  int h = (m / 60) % 24, mn = m % 60;
  int h12 = h % 12 == 0 ? 12 : h % 12;
  return fmt("%d:%02d %s", h12, mn, (h >= 12 && h < 24) ? "PM" : "AM");
}
static const Region* spr(const std::string& n) { return &Sprites::get(n); }

const Region& Content::icon(const ItemStack& s) const {
  const ItemDef& d = def(s.id);
  if (d.cat == Cat::Tool && d.toolIcon[clampv((int)s.tier, 0, 5)]) return *d.toolIcon[clampv((int)s.tier, 0, 5)];
  return d.icon ? *d.icon : Sprites::world.missing();
}
Ingredient Content::parseIngredient(const std::string& s) const {
  Ingredient g;
  auto p = splitString(s, ':');
  if (p.size() >= 3 && (p[0] == "cat" || p[0] == "tag")) { g.group = p[0] + ":" + p[1]; g.count = atoi(p[2].c_str()); }
  else if (!p.empty()) { g.item = item(p[0]); g.count = p.size() > 1 ? atoi(p[1].c_str()) : 1; if (!g.item) CF_LOGW("unknown ingredient item '%s'", p[0].c_str()); }
  return g;
}
std::vector<Ingredient> Content::parseIngredients(const std::string& s) const {
  std::vector<Ingredient> v;
  for (auto& p : splitString(s, ',')) v.push_back(parseIngredient(p));
  return v;
}
bool Content::matches(const Ingredient& g, int itemId) const {
  if (g.item) return g.item == itemId;
  const ItemDef& d = def(itemId);
  auto p = splitString(g.group, ':');
  if (p.size() < 2) return false;
  if (p[0] == "tag") return d.tag == p[1];
  static const char* cn[] = {"tool", "seed", "crop", "forage", "fish", "mineral", "material", "food", "product", "artisan", "placeable", "fertilizer", "feed", "gift", "quest", "misc"};
  return p[1] == cn[(int)d.cat];
}

static std::vector<DropDef> parseDrops(const Content& c, const std::string& s) {
  std::vector<DropDef> out;
  for (auto& part : splitString(s, ',')) {
    DropDef d;
    std::string body = part; size_t at = body.find('@');
    if (at != std::string::npos) { d.chance = (float)atof(body.substr(at + 1).c_str()); body = body.substr(0, at); }
    auto p = splitString(body, ':');
    if (p.size() < 2) continue;
    d.item = c.item(p[0]);
    auto r = splitString(p[1], '-');
    d.mn = atoi(r[0].c_str()); d.mx = r.size() > 1 ? atoi(r[1].c_str()) : d.mn;
    if (!d.item) CF_LOGW("unknown drop item '%s'", p[0].c_str());
    out.push_back(d);
  }
  return out;
}

void Content::loadItems() {
  static const std::unordered_map<std::string, Cat> cats = {{"tool", Cat::Tool}, {"seed", Cat::Seed}, {"crop", Cat::Crop}, {"forage", Cat::Forage}, {"fish", Cat::Fish}, {"mineral", Cat::Mineral},
      {"material", Cat::Material}, {"food", Cat::Food}, {"product", Cat::Product}, {"artisan", Cat::Artisan}, {"placeable", Cat::Placeable}, {"fertilizer", Cat::Fertilizer},
      {"feed", Cat::Feed}, {"gift", Cat::Gift}, {"quest", Cat::Quest}, {"misc", Cat::Misc}};
  static const std::unordered_map<std::string, ToolType> tools = {{"hoe", ToolType::Hoe}, {"can", ToolType::Can}, {"axe", ToolType::Axe}, {"pick", ToolType::Pick},
      {"rod", ToolType::Rod}, {"hammer", ToolType::Hammer}, {"shears", ToolType::Shears}};
  std::vector<Record> rec;
  loadDataFile("data/items.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "item") continue;
    ItemDef d;
    d.id = r.str("id"); d.name = r.str("name", d.id); d.desc = r.str("desc");
    auto ci = cats.find(r.str("cat", "misc")); d.cat = ci == cats.end() ? Cat::Misc : ci->second;
    auto ti = tools.find(r.str("tool")); d.tool = ti == tools.end() ? ToolType::None : ti->second;
    d.sell = r.integer("sell"); d.buy = r.integer("buy"); d.stack = r.integer("stack", 99);
    d.energy = r.integer("energy"); d.health = r.integer("health"); d.placeObj = r.str("place"); d.tag = r.str("tag");
    auto b = splitString(r.str("buff"), ':');
    if (b.size() == 3) { d.buff.type = buffFromName(b[0]); d.buff.amount = atoi(b[1].c_str()); d.buff.minutes = atoi(b[2].c_str()); }
    d.icon = spr("item_" + d.id);
    if (d.cat == Cat::Tool) for (int t = 0; t < 6; ++t) d.toolIcon[t] = spr(fmt("item_%s_%d", d.id.c_str(), t));
    itemIdx[d.id] = (int)items.size();
    items.push_back(d);
  }
}
void Content::loadCrops() {
  std::vector<Record> rec; loadDataFile("data/crops.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "crop") continue;
    CropDef c; c.id = r.str("id"); c.item = item(c.id); c.seed = item("seed_" + c.id);
    c.seasons = seasonMask(r.list("seasons")); c.days = r.integer("days", 4); c.regrow = r.integer("regrow");
    auto y = splitString(r.str("yield", "1-1"), '-'); c.yMin = atoi(y[0].c_str()); c.yMax = y.size() > 1 ? atoi(y[1].c_str()) : c.yMin;
    c.thirst = r.integer("thirst"); c.xp = r.integer("xp", 5);
    for (int s = 0; s < 6; ++s) c.stage[s] = spr(fmt("crop_%s_%d", c.id.c_str(), s));
    c.dead = spr("crop_" + c.id + "_dead");
    if (!c.item || !c.seed) CF_LOGW("crop %s missing item/seed", c.id.c_str());
    cropIdx[c.id] = (int)crops.size(); crops.push_back(c);
  }
}
void Content::loadObjects() {
  static const std::unordered_map<std::string, ObjKind> kinds = {{"tree", ObjKind::Tree}, {"stump", ObjKind::Stump}, {"log", ObjKind::Log}, {"rock", ObjKind::Rock}, {"ore", ObjKind::Ore},
      {"weed", ObjKind::Weed}, {"twig", ObjKind::Twig}, {"dig", ObjKind::Dig}, {"chest", ObjKind::Chest}, {"machine", ObjKind::Machine}, {"fence", ObjKind::Fence},
      {"sprinkler", ObjKind::Sprinkler}, {"scarecrow", ObjKind::Scarecrow}, {"lamp", ObjKind::Lamp}, {"bin", ObjKind::Bin}, {"bed", ObjKind::Bed}, {"kitchen", ObjKind::Kitchen},
      {"decor", ObjKind::Decor}, {"sign", ObjKind::Sign}, {"board", ObjKind::Board}, {"lantern", ObjKind::Lantern}, {"wisp", ObjKind::Wisp}, {"ladder", ObjKind::Ladder},
      {"hole", ObjKind::Hole}, {"hazard", ObjKind::Hazard}, {"treasure", ObjKind::Treasure}, {"feeder", ObjKind::Feeder}, {"collector", ObjKind::Collector},
      {"deco_top", ObjKind::DecoTop}, {"floor", ObjKind::Floor}, {"wall_deco", ObjKind::WallDeco}, {"deco_water", ObjKind::DecoWater}};
  static const std::unordered_map<std::string, ToolType> tools = {{"hoe", ToolType::Hoe}, {"axe", ToolType::Axe}, {"pick", ToolType::Pick}, {"hammer", ToolType::Hammer}, {"shears", ToolType::Shears}};
  std::vector<Record> rec; loadDataFile("data/objects.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "obj") continue;
    ObjDef d; d.id = r.str("id"); d.name = r.str("name", d.id); d.art = r.str("art", d.id);
    auto k = kinds.find(r.str("kind", "decor")); d.kind = k == kinds.end() ? ObjKind::Decor : k->second;
    std::string tl = r.str("tool"); d.anyTool = tl == "any"; auto t = tools.find(tl); d.tool = t == tools.end() ? ToolType::None : t->second;
    d.tier = r.integer("tier"); d.hp = r.integer("hp", 1); d.fw = r.integer("fw", 1); d.fh = r.integer("fh", 1);
    d.shadow = r.integer("shadow"); d.solid = r.flag("solid"); d.seasonal = r.flag("seasonal");
    d.drops = parseDrops(*this, r.str("drop"));
    auto l = splitString(r.str("light"), ':');
    if (l.size() == 2) { d.lightR = (float)atof(l[0].c_str()); int rgb = (int)strtol(l[1].c_str() + (l[1][0] == '#' ? 1 : 0), nullptr, 16); d.lightCol = col::rgba((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255); }
    for (int s = 0; s < 4; ++s) {
      std::string name = "o_" + d.art; if (d.seasonal) name += std::string("_") + kSeasonNames[s];
      if (d.art == "fence") name = "o_fence_0";
      d.spr[s] = spr(name);
    }
    objIdx[d.id] = (int)objs.size(); objs.push_back(d);
  }
  { ObjDef f; f.id = "_forage"; f.name = "Forage"; f.kind = ObjKind::Forage; f.hp = 1; forageObj = (int)objs.size(); objs.push_back(f); }
  for (size_t i = 1; i < items.size(); ++i) if (!items[i].placeObj.empty()) {
    int o = obj(items[i].placeObj); if (o >= 0) objs[(size_t)o].itemId = (int)i; else CF_LOGW("item %s places unknown object %s", items[i].id.c_str(), items[i].placeObj.c_str());
  }
}
void Content::loadAnimals() {
  std::vector<Record> rec; loadDataFile("data/animals.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "animal") continue;
    AnimalDef a; a.id = r.str("id"); a.name = r.str("name", a.id); a.home = r.str("home"); a.art = r.str("art", a.id);
    a.price = r.integer("price"); a.product = item(r.str("product")); a.interval = r.integer("interval", 1); a.adult = r.integer("adult", 3);
    a.shears = r.str("harvest") == "shears"; a.speed = r.num("speed", 16);
    animalIdx[a.id] = (int)animals.size(); animals.push_back(a);
  }
}
static int parseWindow(const std::string& s, int& t1) {
  auto p = splitString(s, '-'); if (p.size() != 2) { t1 = 1560; return 360; }
  t1 = parseClock(p[1]); return parseClock(p[0]);
}
void Content::loadFish() {
  std::vector<Record> rec; loadDataFile("data/fish.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "fish") continue;
    FishDef f; f.item = item(r.str("id")); f.water = r.str("water"); f.seasons = seasonMask(r.list("seasons"));
    f.t0 = parseWindow(r.str("time"), f.t1); f.weather = r.str("weather", "any"); f.weight = r.num("weight", 1); f.diff = r.num("diff", 0.3f);
    if (!f.item) CF_LOGW("fish item missing %s", r.str("id").c_str());
    fish.push_back(f);
  }
}
void Content::loadForage() {
  std::vector<Record> rec; loadDataFile("data/forage.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "forage") continue;
    ForageDef f; f.item = item(r.str("item")); f.seasons = seasonMask(r.list("seasons")); f.maps = r.list("maps"); f.weight = r.num("weight", 1); f.sand = r.str("terrain") == "sand";
    f.spr = spr("o_fg_" + r.str("item"));
    forage.push_back(f);
  }
  forageSpr.assign(items.size(), nullptr);
  for (size_t i = 1; i < items.size(); ++i) if (items[i].cat == Cat::Forage) forageSpr[i] = spr("o_fg_" + items[i].id);
}
void Content::loadRecipes() {
  std::vector<Record> rec; loadDataFile("data/recipes.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "recipe") continue;
    RecipeDef d; d.id = r.str("id"); d.station = r.str("station", "craft"); d.unlock = r.str("unlock", "default");
    auto o = splitString(r.str("out"), ':'); d.out = item(o[0]); d.outCount = o.size() > 1 ? atoi(o[1].c_str()) : 1;
    d.in = parseIngredients(r.str("in"));
    recipeIdx[d.id] = (int)recipes.size(); recipes.push_back(d);
  }
  rec.clear(); loadDataFile("data/machines.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "proc") continue;
    ProcDef p; p.machine = r.str("machine"); p.in = parseIngredients(r.str("in"));
    auto o = splitString(r.str("out"), ':'); p.out = item(o[0]); p.outCount = o.size() > 1 ? atoi(o[1].c_str()) : 1; p.minutes = r.integer("minutes", 60);
    procs.push_back(p);
  }
}
void Content::loadBuildings() {
  std::vector<Record> rec; loadDataFile("data/buildings.cfd", rec);
  for (auto& r : rec) {
    if (r.type == "building") {
      BuildingDef b; b.id = r.str("id"); b.sprite = r.str("sprite"); b.w = r.integer("w", 3); b.h = r.integer("h", 3); b.door = r.integer("door", 1); b.levels = r.integer("levels", 1);
      b.animals = r.str("animals"); auto cp = splitString(r.str("capacity"), ',');
      for (size_t i = 0; i < cp.size() && i < 3; ++i) b.capacity[i] = atoi(cp[i].c_str());
      for (int l = 0; l < 3; ++l) b.spr[l] = spr(fmt("%s_%d", b.sprite.c_str(), b.levels > 1 ? l + 1 : 0));
      if (b.levels <= 1) for (int l = 1; l < 3; ++l) b.spr[l] = b.spr[0];
      buildingIdx[b.id] = (int)buildings.size(); buildings.push_back(b);
    } else if (r.type == "upgrade") {
      UpgradeDef u; u.building = r.str("building"); u.level = r.integer("level", 2); u.gold = r.integer("gold"); u.days = r.integer("days", 2); u.in = parseIngredients(r.str("in")); upgrades.push_back(u);
    } else if (r.type == "toolup") {
      ToolUpDef u; u.tier = r.integer("tier", 1); u.gold = r.integer("gold"); u.days = r.integer("days", 2); u.in = parseIngredients(r.str("in")); toolUps.push_back(u);
    }
  }
}
void Content::loadShops() {
  std::vector<Record> rec; loadDataFile("data/shops.cfd", rec);
  for (auto& r : rec) {
    if (r.type == "shop") {
      ShopDef s; s.id = r.str("id"); s.npc = r.str("npc"); s.kind = r.str("kind", "general"); s.name = r.str("name", s.id);
      s.open = parseClock(r.str("open", "9:00")); s.close = parseClock(r.str("close", "17:00")); s.closed = r.str("closed");
      auto b = splitString(r.str("buybonus"), ':'); if (b.size() == 2) { s.bonusCat = b[0]; s.bonus = (float)atof(b[1].c_str()); }
      shopIdx[s.id] = (int)shops.size(); shops.push_back(s);
    }
  }
  for (auto& r : rec) {
    int si = shop(r.str("shop")); if (si < 0) continue;
    if (r.type == "shopitem") {
      ShopItem it; it.item = item(r.str("item")); it.price = r.integer("price", def(it.item).buy); it.seasons = seasonMask(r.list("season")); it.minHearts = r.integer("min_hearts");
      if (it.item) shops[(size_t)si].stock.push_back(it); else CF_LOGW("shop item missing %s", r.str("item").c_str());
    } else if (r.type == "shopanimal") shops[(size_t)si].animals.push_back(r.str("animal"));
  }
}
static int weatherBits(const std::string& s) {
  int m = 0; for (auto& p : splitString(s, ',')) { if (p == "sun") m |= 1; else if (p == "rain") m |= 2; else if (p == "snow") m |= 4; else if (p == "storm") m |= 8; }
  return m;
}
static int dayMask(const std::vector<std::string>& v) {
  if (v.empty()) return 127; int m = 0;
  for (auto& d : v) for (int i = 0; i < 7; ++i) if (d == kDayNames[i]) m |= 1 << i;
  return m ? m : 127;
}
void Content::loadNpcs() {
  std::vector<Record> rec; loadDataFile("data/npcs.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "npc") continue;
    NpcDef n; n.id = r.str("id"); n.name = r.str("name", n.id); n.job = r.str("job"); n.home = r.str("home"); n.shop = r.str("shop"); n.bio = r.str("bio");
    n.female = r.str("gender") == "f"; n.romance = r.flag("romance");
    auto b = splitString(r.str("bday", "spring:1"), ':'); n.bdaySeason = std::max(0, seasonFromName(b[0])); n.bdayDay = b.size() > 1 ? atoi(b[1].c_str()) : 1;
    n.loves = r.list("loves"); n.likes = r.list("likes"); n.dislikes = r.list("dislikes"); n.hates = r.list("hates");
    npcIdx[n.id] = (int)npcs.size(); npcs.push_back(n);
  }
  rec.clear(); loadDataFile("data/schedules.cfd", rec);
  for (auto& r : rec) {
    if (r.type != "sched") continue;
    int ni = npc(r.str("npc")); if (ni < 0) { CF_LOGW("schedule for unknown npc %s", r.str("npc").c_str()); continue; }
    SchedEntry e; e.t = parseClock(r.str("t", "6:00")); e.map = r.str("map", "village"); e.at = r.str("at"); e.rainAt = r.str("rain_at"); e.act = r.str("act", "idle");
    e.days = dayMask(r.list("days")); e.seasons = seasonMask(r.list("season"));
    npcs[(size_t)ni].sched.push_back(e);
  }
  for (auto& n : npcs) std::stable_sort(n.sched.begin(), n.sched.end(), [](const SchedEntry& a, const SchedEntry& b) { return a.t < b.t; });
}
void Content::loadStory() {
  std::vector<Record> rec; loadDataFile("data/dialogue.cfd", rec);
  for (auto& r : rec) {
    if (r.type == "say") {
      SayLine s; s.npc = r.str("npc"); s.tag = r.str("tag", "greet"); s.text = r.str("text"); s.act = r.str("act"); s.flag = r.str("flag");
      auto h = splitString(r.str("hearts", "0-99"), '-'); s.h0 = atoi(h[0].c_str()); s.h1 = h.size() > 1 ? atoi(h[1].c_str()) : s.h0;
      s.seasons = seasonMask(r.list("season")); s.days = dayMask(r.list("day")); s.weather = weatherBits(r.str("weather"));
      says.push_back(s);
    } else if (r.type == "event") {
      EventDef e; e.id = r.str("id"); e.npc = r.str("npc"); e.hearts = r.integer("hearts", 2); e.flag = r.str("need_flag"); e.setFlag = r.str("set_flag", e.id + "_done"); e.question = r.str("q");
      for (auto& ln : splitString(r.str("lines"), '~')) { size_t bar = ln.find('|'); if (bar != std::string::npos) e.lines.emplace_back(ln.substr(0, bar), ln.substr(bar + 1)); }
      for (int i = 1; i <= 3; ++i) {
        std::string a = r.str(fmt("a%d", i).c_str()); if (a.empty()) break;
        e.answers.push_back(a); e.replies.push_back(r.str(fmt("r%d", i).c_str())); e.deltas.push_back(r.integer(fmt("d%d", i).c_str()));
      }
      eventIdx[e.id] = (int)events.size(); events.push_back(e);
    }
  }
  rec.clear(); loadDataFile("data/festivals.cfd", rec); loadDataFile("data/quests.cfd", rec);
  for (auto& r : rec) {
    if (r.type == "quest") {
      QuestDef q; q.id = r.str("id"); q.title = r.str("title", q.id); q.desc = r.str("desc"); q.giver = r.str("giver"); q.after = r.str("after"); q.flag = r.str("flag");
      q.doneText = r.str("done"); q.startText = r.str("start_text"); q.minDay = r.integer("day", 1); q.seasons = seasonMask(r.list("season")); q.hidden = r.flag("hidden");
      auto h = splitString(r.str("hearts"), ':'); if (h.size() == 2) { q.needHearts = h[0]; q.needHeartsN = atoi(h[1].c_str()); }
      for (auto& o : splitString(r.str("obj"), ';')) {
        auto p = splitString(o, ':'); if (p.empty()) continue;
        Objective ob; ob.type = p[0];
        if (ob.type == "deliver") { ob.arg = p.size() > 1 ? p[1] : ""; ob.arg2 = p.size() > 2 ? p[2] : ""; ob.count = p.size() > 3 ? atoi(p[3].c_str()) : 1; }
        else { ob.arg = p.size() > 1 ? p[1] : ""; ob.count = p.size() > 2 ? atoi(p[2].c_str()) : 1; }
        q.objs.push_back(ob);
      }
      for (auto& rw : splitString(r.str("reward"), ',')) {
        auto p = splitString(rw, ':'); if (p.size() < 2) continue;
        QuestReward qr; qr.type = p[0]; qr.arg = p[1]; qr.n = p.size() > 2 ? atoi(p[2].c_str()) : (qr.type == "money" ? atoi(p[1].c_str()) : 1);
        q.rewards.push_back(qr);
      }
      questIdx[q.id] = (int)quests.size(); quests.push_back(q);
    } else if (r.type == "festival") {
      FestivalDef f; f.id = r.str("id"); f.name = r.str("name", f.id); f.host = r.str("host"); f.activity = r.str("activity"); f.text = r.str("text");
      f.season = std::max(0, seasonFromName(r.str("season"))); f.day = r.integer("day", 1); f.prize = r.integer("prize"); f.prizeItem = r.str("prize_item");
      festivals.push_back(f);
    }
  }
}

bool Content::load() {
  *this = Content();
  loadItems(); loadCrops(); loadObjects(); loadAnimals(); loadFish(); loadForage(); loadRecipes(); loadBuildings(); loadShops(); loadNpcs(); loadStory();
  CF_LOGI("content: %zu items, %zu crops, %zu objects, %zu animals, %zu fish, %zu recipes, %zu npcs, %zu quests, %zu dialogue lines",
          items.size(), crops.size(), objs.size(), animals.size(), fish.size(), recipes.size(), npcs.size(), quests.size(), says.size());
  return items.size() > 10 && !objs.empty();
}
}  // namespace cf
