// Player movement, collision, footsteps, warps and action animation timing.
#include "game/game.h"

namespace cf {

static float groundSpeed(Terrain t) { return t == Terrain::Path || t == Terrain::FloorWood || t == Terrain::FloorStone || t == Terrain::Bridge ? 1.0f : 0.94f; }

void Game::updatePlayer(float dt) {
  Player& p = s.pl; Map& m = map();
  p.happyT = std::max(0.f, p.happyT - dt);
  if (p.animKind) {
    p.animT += dt;
    if (!p.hitDone && p.animT >= p.animDur * 0.5f) { p.hitDone = true; applyAction(p.pending); }
    if (p.animT >= p.animDur) {
      p.animKind = 0; p.animT = 0;
      if (actionHeld && p.pending.act != Act::Eat && p.pending.act != Act::Fish) { ActionInfo a = resolveAction(); if (a.act == p.pending.act && a.tile == p.pending.tile) startAction(a); }
    }
    p.moving = false;
    return;
  }
  float mx = moveStick[0], my = moveStick[1], len = std::sqrt(mx * mx + my * my);
  p.moving = false;
  if (len > 0.14f) {
    float speed = 64.f * (1.f + 0.12f * p.buffAmount(BuffType::Speed)) * (p.energy <= 0 ? 0.7f : 1.f) * std::min(1.f, len);
    speed *= groundSpeed(m.terrain((int)(p.pos.x / kTile), (int)(p.pos.y / kTile)));
    float nx = mx / len, ny = my / len;
    Dir want = dirFromVec(nx, ny);
    if (want != p.facing) {   // hysteresis so diagonal drift does not flip the sprite
      bool horizP = p.facing == Dir::Left || p.facing == Dir::Right;
      float ax = std::fabs(nx), ay = std::fabs(ny);
      if ((horizP && ay > ax * 1.3f) || (!horizP && ax > ay * 1.3f) || (horizP == (want == Dir::Left || want == Dir::Right))) p.facing = want;
    }
    Vec2 np = p.pos;
    np.x += nx * speed * dt; if (collides(m, np)) np.x = p.pos.x;
    Vec2 tp = np; tp.y += ny * speed * dt; if (collides(m, tp)) tp.y = np.y;
    np = tp;
    np.x = clampv(np.x, 4.f, (float)m.w * kTile - 4.f); np.y = clampv(np.y, 4.f, (float)m.h * kTile - 3.f);
    if (std::fabs(np.x - p.pos.x) + std::fabs(np.y - p.pos.y) > 0.01f) p.moving = true;
    p.pos = np;
  }
  if (p.moving) {
    p.walkT += dt * 10.f; p.stepT += dt;   // 10 frames/s over the 6-frame cycle = one footfall every 0.3 s, matching the step sound
    if (p.stepT > 0.3f) {
      p.stepT = 0; audio->play(Sfx::Step, 0.35f, 0.9f + rng.f() * 0.25f);
      Terrain under = m.terrain((int)(p.pos.x / kTile), (int)(p.pos.y / kTile));
      if (settings.particles > 0 && under != Terrain::Path && under != Terrain::FloorWood && under != Terrain::FloorStone && under != Terrain::Bridge) {   // little puff at every footfall
        u32 dc = under == Terrain::Grass ? col::rgba(190, 215, 150, 120) : (under == Terrain::Sand ? col::rgba(240, 225, 170, 140) : col::rgba(190, 160, 120, 140));
        for (int i = 0; i < 2; ++i) fx.emit(Fx::Dust, p.pos.x + rng.rangef(-3, 3), p.pos.y - 1, rng.rangef(-6, 6), rng.rangef(-9, -4), 0.38f, dc);
      }
    }
  } else p.walkT = 0, p.stepT = 0.2f;
  // warps
  IVec2 t = playerTile();
  if (!fading) if (const Warp* w = m.warpAt(t.x, t.y)) {
    std::string to = w->toMap, tp = w->toPoint;
    if (to == "mine_1" && s.deepestMine >= 5) {
      std::vector<std::pair<int, std::string>> ch{{300, "Floor 1"}};
      for (int f = 5; f <= s.deepestMine && f <= 20; f += 5) ch.push_back({300 + f, fmt("Floor %d (elevator)", f)});
      ch.push_back({299, "Never mind"});
      s.pl.pos = s.pl.pos + Vec2(0, 10);
      showDialogue("Mine Lift", "", "", "The old lift creaks. Where to?", ch);
      return;
    }
    audio->play(Sfx::Door);
    if (to == "house") { enterMap("house", tp); }
    else enterMap(to, tp);
  }
}

}  // namespace cf
