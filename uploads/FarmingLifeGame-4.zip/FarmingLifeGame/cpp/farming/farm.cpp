// Soil, crops, sprinklers and daily growth.
#include "game/game.h"

namespace cf {

int Game::cropStage(const CropDef& c, const MapObject& o) const {
  if (o.state == 9) return 9;
  if (o.days >= c.days) return 5;
  if (o.aux & 0x80) return 4;
  return std::min(4, (int)o.days * 5 / std::max(1, c.days));
}

bool Game::tillTile(Map& m, int x, int y) {
  if (!m.canTill(x, y)) return false;
  m.at(x, y).flags = (u8)((m.at(x, y).flags | TF_Tilled) & ~TF_Watered);
  if (settings.particles) for (int i = 0; i < 3; ++i) fx.emit(Fx::Dust, x * kTile + 8 + rng.rangef(-4, 4), y * kTile + 10, rng.rangef(-10, 10), rng.rangef(-16, -6), 0.45f, col::rgba(150, 110, 70, 200));
  return true;
}

bool Game::plantSeed(Map& m, int x, int y, int cropIdx, int) {
  if (!m.inBounds(x, y) || !(m.at(x, y).flags & TF_Tilled) || m.objectAt(x, y) >= 0) return false;
  Tile& t = m.at(x, y);
  int fert = (t.flags & TF_Rich) ? 2 : (t.flags & TF_Fert) ? 1 : 0;
  t.flags &= (u8) ~(TF_Fert | TF_Rich);
  MapObject o; o.kind = ObjKind::Crop; o.def = (u16)cropIdx; o.x = (i16)x; o.y = (i16)y; o.aux = (u32)(fert << 2);
  return m.addObject(o) >= 0;
}

void Game::waterTile(Map& m, int x, int y) {
  if (!m.inBounds(x, y)) return;
  m.at(x, y).flags |= TF_Watered;
  if (settings.particles) for (int i = 0; i < 4; ++i) fx.emit(Fx::Drop, x * kTile + 8 + rng.rangef(-5, 5), y * kTile + 4, rng.rangef(-6, 6), rng.rangef(0, 20), 0.35f, kWhite, 120);
}

void Game::harvestCrop(Map& m, int oi) {
  MapObject o = m.objs[(size_t)oi]; const CropDef& c = C().crops[o.def];
  if (cropStage(c, o) < 5) return;
  int n = rng.range(c.yMin, c.yMax);
  int fert = (o.aux >> 2) & 3, lv = s.pl.level(0);
  float g = 0.03f + 0.035f * (float)lv + 0.12f * (float)fert + 0.03f * s.pl.buffAmount(BuffType::Luck);
  ItemStack st; st.id = (u16)c.item; st.count = (u16)n;
  float r = rng.f(); st.quality = (u8)(r < g * 0.4f ? 3 : r < g ? 2 : r < g * 2.2f ? 1 : 0);
  if (st.quality == 3 && fert < 2) st.quality = 2;
  if (!s.pl.inv.canAdd(st)) { toast("Inventory full."); audio->play(Sfx::Error); return; }
  giveItem(st);
  Vec2 at = tileCenter(o.x, o.y);
  audio->play(Sfx::Harvest);
  for (int i = 0; i < 5 && settings.particles; ++i) fx.emit(Fx::Sparkle, at.x + rng.rangef(-6, 6), at.y - 4, rng.rangef(-14, 14), rng.rangef(-30, -8), 0.6f);
  addXp(0, c.xp); s.counters["harvested"] += n; emitEvent("harvest", c.id, n);
  s.seenItems.insert(C().def(c.item).id);
  if (c.regrow > 0) { MapObject& ro = m.objs[(size_t)oi]; ro.days = (u16)std::max(0, c.days - c.regrow); ro.aux |= 0x80; ro.state = 4; }
  else m.removeObject(oi);
}

void Game::witherCrops(Map& m) {
  for (auto& o : m.objs) if (o.kind == ObjKind::Crop && !(C().crops[o.def].seasons & (1 << s.cal.season))) o.state = 9;
}

void Game::growCrops(Map& m, bool) {
  for (size_t i = 0; i < m.objs.size(); ++i) {
    MapObject& o = m.objs[i];
    if (o.kind != ObjKind::Crop || o.state == 9) continue;
    const CropDef& c = C().crops[o.def];
    bool wet = (m.at(o.x, o.y).flags & TF_Watered) != 0;
    int dry = (int)(o.aux & 3);
    if (wet) { dry = 0; if (o.days < c.days) { ++o.days; if (((o.aux >> 2) & 3) == 2 && rng.chance(0.25f)) ++o.days; } }
    else { ++dry; if (dry > c.thirst && dry >= 1 && c.thirst == 0) {} else if (o.days < c.days) ++o.days; if (dry >= 5) o.state = 9; }
    o.aux = (o.aux & ~3u) | (u32)std::min(dry, 3);
    if (o.state != 9) o.state = (u8)cropStage(c, o);
  }
  for (auto& t : m.tiles) t.flags &= (u8) ~TF_Watered;
}

void Game::waterAllRain() {
  for (auto& kv : s.maps) {
    Map& m = *kv.second; if (!m.outdoors) continue;
    for (auto& t : m.tiles) if (t.flags & TF_Tilled) t.flags |= TF_Watered;
  }
}

void Game::sprinklersWater() {
  for (auto& kv : s.maps) {
    Map& m = *kv.second;
    for (auto& o : m.objs) {
      if (o.kind != ObjKind::Sprinkler) continue;
      bool quality = objDef(o).id == "sprinkler_q";
      for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) {
        if ((dx || dy) && !quality && dx && dy) continue;
        if (!dx && !dy) continue;
        int x = o.x + dx, y = o.y + dy;
        if (m.inBounds(x, y) && (m.at(x, y).flags & TF_Tilled)) m.at(x, y).flags |= TF_Watered;
      }
    }
  }
}

void Game::crowsAttack() {
  Map* m = getMap("farm"); if (!m) return;
  std::vector<int> crops; for (size_t i = 0; i < m->objs.size(); ++i) if (m->objs[i].kind == ObjKind::Crop && m->objs[i].state != 9) crops.push_back((int)i);
  if (crops.size() < 6) return;
  if (!rng.chance(0.28f)) return;
  int idx = crops[(size_t)rng.range(0, (int)crops.size() - 1)]; MapObject o = m->objs[(size_t)idx];
  for (auto& sc : m->objs) if (sc.kind == ObjKind::Scarecrow && std::abs(sc.x - o.x) <= 9 && std::abs(sc.y - o.y) <= 9) return;
  m->removeObject(idx);
  summary.notes.push_back("A crow nibbled one of your crops. A scarecrow would help!");
}
}  // namespace cf
