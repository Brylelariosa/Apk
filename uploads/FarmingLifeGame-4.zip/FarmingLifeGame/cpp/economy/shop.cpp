#include "game/game.h"
namespace cf {
int Game::buyPrice(const ShopDef&, const ShopItem& it) const { return it.price; }
int Game::sellValue(const ShopDef* sd, const ItemStack& st) const {
  int v = sellPrice(st);
  if (sd && !sd->bonusCat.empty()) {
    static const char* cn[] = {"tool", "seed", "crop", "forage", "fish", "mineral", "material", "food", "product", "artisan", "placeable", "fertilizer", "feed", "gift", "quest", "misc"};
    if (sd->bonusCat == cn[(int)C().def(st.id).cat]) v = (int)((float)v * sd->bonus);
  }
  return v;
}
void Game::openShop(int si, int ni) { shopUi = ShopUI(); shopUi.shop = si; shopUi.npc = ni; push(St::Shop); audio->play(Sfx::Click); }
}  // namespace cf
