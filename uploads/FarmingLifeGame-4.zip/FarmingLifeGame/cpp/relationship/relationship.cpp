// Friendship, gifts, courtship.
#include "game/game.h"

namespace cf {

void Game::addFriendship(NpcState& n, int pts) {
  int before = n.hearts();
  n.friendship = clampv(n.friendship + pts, 0, 2500);
  if (n.hearts() > before) { toast(fmt("%s likes you more!", C().npcs[(size_t)n.def].name.c_str()), "ic_heart"); audio->play(Sfx::Chime); }
}

int Game::giftTaste(const NpcDef& d, int item) const {
  const ItemDef& it = C().def(item);
  static const char* cn[] = {"tool", "seed", "crop", "forage", "fish", "mineral", "material", "food", "product", "artisan", "placeable", "fertilizer", "feed", "gift", "quest", "misc"};
  std::string cat = std::string("cat:") + cn[(int)it.cat];
  auto in = [&](const std::vector<std::string>& v, bool exact) { for (auto& e : v) if (exact ? e == it.id : e == cat) return true; return false; };
  if (in(d.loves, true)) return 2; if (in(d.hates, true)) return -2; if (in(d.likes, true)) return 1; if (in(d.dislikes, true)) return -1;
  if (in(d.loves, false)) return 2; if (in(d.hates, false)) return -2; if (in(d.likes, false)) return 1; if (in(d.dislikes, false)) return -1;
  return 0;
}

void Game::giveGift(int ni, int slot) {
  NpcState& n = s.npcs[(size_t)ni]; const NpcDef& d = C().npcs[(size_t)n.def];
  ItemStack& st = s.pl.inv.slots[(size_t)slot]; if (st.empty()) return;
  const ItemDef& it = C().def(st.id);
  if (n.gifted) { showDialogue(d.name, "por_" + d.id, "neutral", "You've already given me something today."); return; }
  if (it.cat == Cat::Tool || it.cat == Cat::Quest) { toast("They wouldn't want that."); return; }
  std::string reply; std::string expr = "neutral"; int pts = 0;
  if (it.id == "bouquet") {
    if (!d.romance) { reply = "Flowers? That's very kind, but I'm not looking for romance."; pts = 20; }
    else if (n.hearts() < 6) { reply = "Oh... flowers! That's sweet. Maybe we should get to know each other better first."; pts = 20; expr = "happy"; }
    else if (n.dating == 0) { n.dating = 1; reply = "You're giving me flowers? ...Yes. I'd love to see where this goes."; pts = 100; expr = "happy"; setFlag("dating_" + d.id); toast(fmt("You're now courting %s!", d.name.c_str()), "ic_heart"); }
    else { reply = "More flowers! You really are sweet."; pts = 40; expr = "happy"; }
  } else if (it.id == "promise_ring") {
    if (n.dating == 1 && n.hearts() >= 10) { n.dating = 2; reply = "A promise ring... Yes! Let's build a home together. I'll be at the farmhouse mornings and evenings."; pts = 250; expr = "happy"; setFlag("married_" + d.id); toast(fmt("%s moved in with you!", d.name.c_str()), "ic_heart"); }
    else { reply = "That's a big step. I'm not ready for that yet."; pts = 0; }
  } else {
    int taste = giftTaste(d, st.id);
    static const int val[5] = {-40, -20, 20, 45, 80};
    pts = val[taste + 2];
    bool bday = d.bdaySeason == s.cal.season && d.bdayDay == s.cal.day;
    if (bday) pts *= 4;
    if (n.giftsWeek >= 2) pts = pts > 0 ? pts / 4 : pts;
    static const char* tags[5] = {"gift_hate", "gift_dislike", "gift_neutral", "gift_like", "gift_love"};
    reply = pickLine(n, tags[taste + 2]);
    expr = taste >= 1 ? "happy" : (taste < 0 ? "sad" : "neutral");
    if (bday) reply += "||(It's their birthday - the gift means extra!)";
  }
  n.gifted = true; ++n.giftsWeek;
  if (--st.count == 0) st = ItemStack();
  addFriendship(n, pts); emitEvent("gift", d.id); s.counters["gifts"]++;
  for (int i = 0; i < 3; ++i) fx.emit(pts >= 0 ? Fx::Heart : Fx::Hit, n.pos.x + rng.rangef(-6, 6), n.pos.y - 22, rng.rangef(-8, 8), -14, 0.9f);
  showDialogue(d.name, "por_" + d.id, expr, reply, {{4, "Thanks!"}});
  dlg.npc = ni;
}
}  // namespace cf
