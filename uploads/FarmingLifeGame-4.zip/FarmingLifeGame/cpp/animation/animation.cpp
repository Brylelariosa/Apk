#include "animation/animation.h"
#include <map>
#include "items/content.h"

namespace cf {
static CharAnim build(const std::string& id, const std::string& season, bool full) {
  CharAnim a; static const char* dn[3] = {"d", "u", "s"};
  auto g = [&](const std::string& n) { return &Sprites::get(n); };
  for (int d = 0; d < 3; ++d) {
    std::string p = "ch_" + id + "_" + season + "_" + dn[d] + "_";
    a.idle[d] = g(p + "idle_0");
    a.idle2[d] = Sprites::find(p + "idle_1");   // optional: only the player has a breathing frame
    for (int i = 0; i < 4; ++i) a.walk[d][i] = g(p + "walk_" + std::to_string(i));
    for (int i = 4; i < 6; ++i) a.walk[d][i] = Sprites::find(p + "walk_" + std::to_string(i));   // optional extra frames (6-frame cycle)
    for (int i = 0; i < 3; ++i) a.swing[d][i] = g(p + "swing_" + std::to_string(i));
    if (full) for (int i = 0; i < 2; ++i) { a.water[d][i] = g(p + "water_" + std::to_string(i)); a.fish[d][i] = g(p + "fish_" + std::to_string(i)); a.pick[d][i] = g(p + "pick_" + std::to_string(i)); }
  }
  for (int i = 0; i < 2; ++i) { a.talk[i] = g("ch_" + id + "_" + season + "_d_talk_" + std::to_string(i)); if (full) a.eat[i] = g("ch_" + id + "_" + season + "_d_eat_" + std::to_string(i)); }
  if (full) a.happy = g("ch_" + id + "_" + season + "_d_happy_0");
  a.walkN = (a.walk[0][5] && a.walk[1][5] && a.walk[2][5]) ? 6 : 4;
  return a;
}
const CharAnim& playerAnim(int look) {
  static CharAnim cache[2]; static bool built[2] = {false, false};
  int l = look & 1; if (!built[l]) { cache[l] = build(l ? "player1" : "player0", "all", true); built[l] = true; }
  return cache[l];
}
const CharAnim& npcAnim(int def, int season) {
  static std::map<int, CharAnim> cache;
  int key = def * 4 + (season & 3);
  auto it = cache.find(key);
  if (it == cache.end()) it = cache.emplace(key, build(C().npcs[(size_t)def].id, kSeasonNames[season & 3], false)).first;
  return it->second;
}
const AnimalAnim& animalAnim(const std::string& art) {
  static std::map<std::string, AnimalAnim> cache;
  auto it = cache.find(art);
  if (it == cache.end()) {
    AnimalAnim a; auto g = [&](const std::string& k, int i) { return &Sprites::get("an_" + art + "_" + k + "_" + std::to_string(i)); };
    for (int i = 0; i < 2; ++i) { a.idle[i] = g("idle", i); a.eat[i] = g("eat", i); a.sleep[i] = g("sleep", i); a.play[i] = g("play", i); }
    for (int i = 0; i < 4; ++i) a.walk[i] = g("walk", i);
    it = cache.emplace(art, a).first;
  }
  return it->second;
}
}  // namespace cf
