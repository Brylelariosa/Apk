// Villagers: schedules, tiered simulation (near = full, medium/far = reduced rate, other maps = abstract), pathing.
#include "engine/log.h"
#include "game/game.h"

namespace cf {

void Game::initNpcs() {
  s.npcs.clear();
  for (size_t i = 0; i < C().npcs.size(); ++i) {
    NpcState n; n.def = (int)i; n.inside = true; n.act = "inside"; n.map = "village";
    const NpcDef& d = C().npcs[i];
    for (auto& e : d.sched) if (e.act == "inside") { n.map = e.map; break; }
    if (Map* m = getMap(n.map)) {
      std::string at; for (auto& e : d.sched) if (e.act == "inside") { at = e.at; break; }
      const NamedPoint* p = m->point(at); IVec2 t = p ? p->pos : IVec2(m->w / 2, m->h / 2);
      n.pos = tileCenter(t.x, t.y); n.anchor = t;
    }
    n.tickPhase = (int)i * 5;
    s.npcs.push_back(n);
  }
}

const SchedEntry* Game::currentSched(const NpcState& n, bool& rain) const {
  const NpcDef& d = C().npcs[(size_t)n.def];
  const SchedEntry* best = nullptr; int dow = s.cal.dayOfWeek();
  for (auto& e : d.sched) {
    if (e.t > s.cal.minutes) break;
    if (!(e.days & (1 << dow)) || !(e.seasons & (1 << s.cal.season))) continue;
    best = &e;
  }
  rain = best && !best->rainAt.empty() && isWet(s.wx.today);
  return best;
}

bool Game::shopOpen(const ShopDef& sd) const {
  if (s.cal.minutes < sd.open || s.cal.minutes >= sd.close) return false;
  if (sd.closed.find(kDayNames[s.cal.dayOfWeek()]) != std::string::npos) return false;
  const FestivalDef* f = todaysFestival(); if (f) return false;
  return true;
}

static void setPos(Game& g, NpcState& n, const std::string& map, IVec2 t) { n.map = map; n.pos = g.tileCenter(t.x, t.y); }

void Game::npcMinute() {
  int minutes = s.cal.minutes;
  for (auto& n : s.npcs) {
    const NpcDef& d = C().npcs[(size_t)n.def];
    if (n.traveling) {
      n.travelLeft -= 10;
      if (n.travelLeft <= 0) {
        n.traveling = false; n.inside = false;
        Map* m = getMap(n.destMap);
        const NamedPoint* p = m ? m->point(n.destAt) : nullptr;
        if (p) { setPos(*this, n, n.destMap, p->pos); n.target = p->pos; n.anchor = p->pos; }
        n.hasTarget = false; n.path.clear();
      }
      continue;
    }
    // married villagers spend mornings and evenings in the farmhouse
    if (n.dating == 2) {
      bool home = minutes < 510 || (minutes >= 1110 && minutes < 1320);
      if (home) {
        Map* h = getMap("house"); const NamedPoint* p = h ? h->point(minutes < 510 ? "kitchen" : "storage") : nullptr;
        if (p) { n.map = "house"; n.pos = tileCenter(p->pos.x, p->pos.y); n.inside = false; n.act = "idle"; n.hasTarget = false; n.schedIdx = -5; n.facing = Dir::Down; continue; }
      } else if (n.schedIdx == -5) n.schedIdx = -2;
    }
    bool rain = false;
    const SchedEntry* e = currentSched(n, rain);
    SchedEntry fe; int key = 0;
    if (todaysFestival() && minutes >= 540 && minutes < 1020 && !C().npcs.empty()) {
      const FestivalDef* fd = todaysFestival();
      fe.t = 540; fe.map = "village"; fe.act = "idle"; fe.at = d.id == fd->host ? "fest_host" : std::string("fest_") + "abcd"[n.def % 4]; e = &fe; rain = false; key = -100 - n.def;
    } else if (e) key = (int)(e - &d.sched[0]) * 2 + (rain ? 1 : 0);
    if (!e) continue;
    if (key == n.schedIdx) continue;
    n.schedIdx = key;
    std::string at = rain ? e->rainAt : e->at;
    n.act = e->act;
    Map* tm = getMap(e->map); if (!tm) continue;
    const NamedPoint* p = tm->point(at); if (!p) { CF_LOGW("npc %s: unknown point %s on %s", d.id.c_str(), at.c_str(), e->map.c_str()); continue; }
    if (e->map != n.map) {   // cross-map trip: vanish for a while, then arrive
      n.traveling = true; n.travelLeft = 40; n.destMap = e->map; n.destAt = at; n.inside = false; n.hasTarget = false; continue;
    }
    bool visible = (n.map == s.curMap);
    n.anchor = p->pos;
    if (!visible) {   // abstract simulation: just jump to the scheduled state
      setPos(*this, n, n.map, p->pos); n.inside = e->act == "inside"; n.hasTarget = false; n.path.clear(); continue;
    }
    if (n.inside) { n.inside = false; }   // appears at the door tile (pos holds it)
    if (e->act == "inside" && n.inside) continue;
    n.target = p->pos; n.hasTarget = true; n.path.clear(); n.pathPos = 0;
  }
}

void Game::placeNpcsForMap(const std::string& id) {
  for (auto& n : s.npcs) {
    if (n.map != id) continue;
    n.path.clear(); n.pathPos = 0; n.moving = false;
    if (n.inside || n.traveling) continue;
    IVec2 t((int)(n.pos.x / kTile), (int)(n.pos.y / kTile));
    if (n.hasTarget && !(t == n.target) && n.act != "inside") { /* resume walking */ }
    else if (n.act == "inside") { n.inside = true; }
  }
}

int Game::npcAt(Vec2 p, float radius) const {
  int best = -1; float bd = radius;
  for (size_t i = 0; i < s.npcs.size(); ++i) {
    const NpcState& n = s.npcs[i];
    if (!npcIsPlaced(n)) continue;
    float dd = (n.pos + Vec2(0, -6) - p).len();
    if (dd < bd) { bd = dd; best = (int)i; }
  }
  return best;
}

void Game::updateNpcs(float dt) {
  static unsigned tick = 0; ++tick;
  int pathBudget = 2;
  IVec2 pt = playerTile();
  Map* mp = s.maps.count(s.curMap) ? s.maps[s.curMap].get() : nullptr; if (!mp) return;
  Map& m = *mp;
  for (auto& n : s.npcs) {
    if (n.map != s.curMap || n.inside || n.traveling) { n.moving = false; continue; }
    n.animT += dt; n.talkT = std::max(0.f, n.talkT - dt);
    int tx = (int)(n.pos.x / kTile), ty = (int)(n.pos.y / kTile);
    int dist = std::abs(tx - pt.x) + std::abs(ty - pt.y);
    unsigned period = dist < 18 ? 1u : (dist < 40 ? 4u : 16u);
    if ((tick + (unsigned)n.tickPhase) % period != 0) continue;
    float sdt = dt * (float)period;
    bool talking = top() == St::Dialogue && dlg.npc >= 0 && &s.npcs[(size_t)dlg.npc] == &n;
    if (talking) { n.moving = false; continue; }
    if (n.act == "wander" && !n.hasTarget) {
      n.wait -= sdt;
      if (n.wait <= 0) {
        n.wait = rng.rangef(5, 11);
        for (int k = 0; k < 8; ++k) { IVec2 c(n.anchor.x + rng.range(-3, 3), n.anchor.y + rng.range(-2, 2)); if (m.walkableTile(c.x, c.y)) { n.target = c; n.hasTarget = true; n.path.clear(); break; } }
      }
    }
    if (!n.hasTarget) { n.moving = false; continue; }
    IVec2 cur(tx, ty);
    if (cur == n.target) {
      n.hasTarget = false; n.moving = false;
      if (n.act == "inside") { n.inside = true; n.pos = tileCenter(n.target.x, n.target.y); }
      else if (n.act == "shop" || n.act == "idle") n.facing = Dir::Down;
      continue;
    }
    if (n.pathPos >= n.path.size() || n.path.empty()) {
      if (pathBudget <= 0) continue;
      --pathBudget;
      bool ok = findPath(m, cur, n.target, n.path, 4000); n.pathPos = 0;
      if (!ok && n.path.empty()) { n.pos = tileCenter(n.target.x, n.target.y); n.hasTarget = false; continue; }
      if (!ok) { n.hasTarget = false; }
    }
    if (n.pathPos < n.path.size()) {
      IVec2 nx = n.path[n.pathPos];
      if (m.tileBlocked(nx.x, nx.y) && !(nx == n.target)) { n.path.clear(); continue; }
      Vec2 goal = tileCenter(nx.x, nx.y), dv = goal - n.pos; float len = dv.len(), step = 27.f * sdt;
      if (len <= step) { n.pos = goal; ++n.pathPos; } else n.pos += dv * (step / len);
      n.facing = dirFromVec(dv.x, dv.y); n.moving = true;
    }
  }
}
}  // namespace cf
