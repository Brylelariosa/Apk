// Thin JNI bridge between the Java platform layer (Activity / GLSurfaceView / AudioTrack) and the native game.
#include <EGL/egl.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#include <jni.h>
#include <time.h>
#include <atomic>
#include <cstdio>
#include <memory>
#include "engine/app.h"
#include "renderer/gl_backend.h"

namespace {
class AndroidPlatform : public cf::Platform {
 public:
  AAssetManager* mgr = nullptr;
  std::string dir;
  std::atomic<int> vibrateMs{0};
  bool readAsset(const std::string& path, std::vector<cf::u8>& out) override {
    if (!mgr) return false;
    AAsset* a = AAssetManager_open(mgr, path.c_str(), AASSET_MODE_BUFFER);
    if (!a) return false;
    off_t len = AAsset_getLength(a);
    out.resize((size_t)len);
    int n = len > 0 ? AAsset_read(a, out.data(), (size_t)len) : 0;
    AAsset_close(a);
    return n == (int)len;
  }
  std::string dataDir() override { return dir; }
  void log(int level, const char* msg) override {
    __android_log_print(level == 0 ? ANDROID_LOG_INFO : (level == 1 ? ANDROID_LOG_WARN : ANDROID_LOG_ERROR), "Thistledown", "%s", msg);
  }
  double nowSeconds() override { timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return (double)ts.tv_sec + (double)ts.tv_nsec * 1e-9; }
  void vibrate(int ms) override { vibrateMs.store(ms); }
  size_t memoryUsageKB() override {
    FILE* f = fopen("/proc/self/statm", "r"); long a = 0, b = 0;
    if (f) { if (fscanf(f, "%ld %ld", &a, &b) != 2) b = 0; fclose(f); }
    return (size_t)b * 4;
  }
};

AndroidPlatform g_platform;
std::unique_ptr<cf::Application> g_app;
int g_lastSwap = -1;

std::string jstr(JNIEnv* env, jstring s) {
  if (!s) return "";
  const char* c = env->GetStringUTFChars(s, nullptr);
  std::string r = c ? c : "";
  if (c) env->ReleaseStringUTFChars(s, c);
  return r;
}
}  // namespace

#define JNI_FN(ret, name) extern "C" JNIEXPORT ret JNICALL Java_com_cozyfarm_thistledown_NativeBridge_##name

JNI_FN(void, nativeInit)(JNIEnv* env, jclass, jobject assetManager, jstring dataDir, jboolean debug, jfloat density, jfloat refreshHz) {
  g_platform.mgr = AAssetManager_fromJava(env, assetManager);
  g_platform.dir = jstr(env, dataDir);
  cf::setPlatform(&g_platform);
  g_app.reset(new cf::Application());
  if (!g_app->init(cf::createGlBackend(), &g_platform, 1280, 720, density, refreshHz, debug != JNI_FALSE)) {
    __android_log_print(ANDROID_LOG_ERROR, "Thistledown", "application init failed");
    g_app.reset();
  }
}

JNI_FN(void, nativeSurfaceCreated)(JNIEnv*, jclass) {
  if (!g_app) return;
  try { g_app->onSurfaceCreated(); } catch (...) { __android_log_print(ANDROID_LOG_ERROR, "Thistledown", "exception in surface created"); }
  g_lastSwap = -1;
}

JNI_FN(void, nativeSurfaceChanged)(JNIEnv*, jclass, jint w, jint h) { if (g_app) g_app->onSurfaceChanged(w, h); }
JNI_FN(void, nativeSetInsets)(JNIEnv*, jclass, jint l, jint t, jint r, jint b) { if (g_app) g_app->setInsets(l, t, r, b); }

JNI_FN(void, nativeFrame)(JNIEnv*, jclass) {
  if (!g_app) return;
  try {
    g_app->frame();
    int swap = g_app->swapInterval();
    if (swap != g_lastSwap) { eglSwapInterval(eglGetCurrentDisplay(), swap); g_lastSwap = swap; }
  } catch (...) { __android_log_print(ANDROID_LOG_ERROR, "Thistledown", "exception in frame"); }
}

JNI_FN(void, nativeTouch)(JNIEnv*, jclass, jint type, jint id, jfloat x, jfloat y) { if (g_app) g_app->touch(type, id, x, y); }
JNI_FN(void, nativeBack)(JNIEnv*, jclass) { if (g_app) g_app->back(); }
JNI_FN(void, nativePause)(JNIEnv*, jclass) { if (g_app) { try { g_app->pause(); } catch (...) {} } }
JNI_FN(void, nativeResume)(JNIEnv*, jclass) { if (g_app) g_app->resume(); }
JNI_FN(jint, nativePollVibrate)(JNIEnv*, jclass) { return g_platform.vibrateMs.exchange(0); }
JNI_FN(jboolean, nativeWantsExit)(JNIEnv*, jclass) { return (g_app && g_app->wantsExit()) ? JNI_TRUE : JNI_FALSE; }

JNI_FN(void, nativeFillAudio)(JNIEnv* env, jclass, jshortArray arr, jint frames) {
  jshort* p = env->GetShortArrayElements(arr, nullptr);
  if (!p) return;
  if (g_app) g_app->renderAudio((short*)p, frames); else for (int i = 0; i < frames; ++i) p[i] = 0;
  env->ReleaseShortArrayElements(arr, p, 0);
}
