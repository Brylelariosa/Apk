// Fishing: cast -> wait for bite -> reel minigame (hold to raise the bar, keep it on the fish).
#include "game/game.h"

namespace cf {

int Game::pickFish(const std::string& water) {
  int lv = s.pl.level(2); float luck = s.pl.buffAmount(BuffType::Luck);
  int minutes = s.cal.minutes; Weather w = s.wx.today;
  float total = 0; std::vector<std::pair<const FishDef*, float>> pool;
  for (auto& f : C().fish) {
    if (f.water != water || !(f.seasons & (1 << s.cal.season)) || minutes < f.t0 || minutes >= f.t1) continue;
    if (f.weather == "rain" && !isRainy(w)) continue;
    if (f.weather == "sun" && (w != Weather::Sunny && w != Weather::Cloudy)) continue;
    if (f.weather == "snow" && w != Weather::Snow) continue;
    float wt = f.weight * (f.diff > 0.5f ? 1.f + 0.1f * (float)lv + 0.1f * luck : 1.f);
    pool.push_back({&f, wt}); total += wt;
  }
  if (pool.empty() || rng.chance(0.1f)) return C().item(rng.chance(0.5f) ? "old_boot" : "tangled_weeds");
  float r = rng.f() * total;
  for (auto& pr : pool) { r -= pr.second; if (r <= 0) { fg.diff = pr.first->diff; return pr.first->item; } }
  fg.diff = pool.back().first->diff; return pool.back().first->item;
}

bool Game::startFishing(IVec2 water) {
  Player& p = s.pl;
  bool derby = fg.derby; float dt = fg.derbyT; int dc = fg.derbyCount;
  fg = FishingGame(); fg.derby = derby; fg.derbyT = dt; fg.derbyCount = dc;
  fg.phase = 1; fg.target = water;
  float mod = (isRainy(s.wx.today) ? 0.7f : 1.f) * (1.f - 0.05f * (float)p.level(2)) * (1.f - 0.15f * std::min(2.f, p.buffAmount(BuffType::Fish)));
  fg.waitT = rng.rangef(1.8f, 5.2f) * mod;
  p.animKind = 3; p.animT = 0; p.animDur = 9999.f; p.hitDone = true; p.facing = dirFromVec((float)water.x * kTile + 8 - p.pos.x, (float)water.y * kTile + 8 - p.pos.y);
  audio->play(Sfx::Cast);
  if (top() != St::Fishing) push(St::Fishing);
  return true;
}

void Game::updateFishing(float dt) {
  Player& p = s.pl;
  bool press = actionPressed;
  Vec2 bob = tileCenter(fg.target.x, fg.target.y);
  if (fg.derby) { fg.derbyT -= dt; if (fg.derbyT <= 0 && fg.phase != 3) { p.animKind = 0; fg.phase = 0; pop(); festivalState = 3; return; } }
  switch (fg.phase) {
    case 1:
      fg.t += dt; fg.waitT -= dt;
      if (rng.chance(0.015f)) fx.emit(Fx::Ripple, bob.x, bob.y, 0, 0, 0.7f);
      if (press && fg.t > 0.35f) { p.animKind = 0; fg.phase = 0; pop(); toast("You reeled in too early."); }
      if (fg.waitT <= 0) { fg.phase = 2; fg.bite = 0.9f; audio->play(Sfx::Splash); fx.emit(Fx::Exclaim, bob.x, bob.y - 14, 0, -6, 0.9f); for (int i = 0; i < 4; ++i) fx.emit(Fx::Splash, bob.x + rng.rangef(-5, 5), bob.y, 0, 0, 0.5f); if (settings.vibration) platform().vibrate(40); }
      break;
    case 2:
      fg.bite -= dt;
      if (press) {
        fg.fishItem = pickFish(map().waterTypeAt(fg.target.x, fg.target.y));
        const ItemDef& d = C().def(fg.fishItem);
        if (d.cat != Cat::Fish) { fg.phase = 4; fg.t = 0; fg.progress = 1.f; audio->play(Sfx::Pop); }
        else {
          fg.phase = 3; fg.progress = 0.3f; fg.bar = 0.5f; fg.barV = 0; fg.fishPos = 0.5f; fg.fishV = 0;
          fg.size = 0.24f + 0.03f * (float)p.inv.toolTier(ToolType::Rod) + 0.03f * std::min(3.f, p.buffAmount(BuffType::Fish)); fg.legendary = d.id == "golden_koi"; audio->play(Sfx::Reel);
        }
      } else if (fg.bite <= 0) { p.animKind = 0; fg.phase = 0; pop(); toast("It got away..."); }
      break;
    case 3: {
      bool hold = actionHeld;
      for (auto& q : in->p) if (q.down) hold = true;
      fg.barV += (hold ? 2.4f : -1.9f) * dt; fg.barV = clampv(fg.barV * (1.f - 1.5f * dt), -1.2f, 1.2f);
      fg.bar += fg.barV * dt;
      float lo = fg.size * 0.5f, hi = 1.f - fg.size * 0.5f;
      if (fg.bar < lo) { fg.bar = lo; fg.barV = std::max(0.f, -fg.barV * 0.3f); } if (fg.bar > hi) { fg.bar = hi; fg.barV = std::min(0.f, -fg.barV * 0.3f); }
      fg.waitT -= dt;
      if (fg.waitT <= 0) { fg.waitT = rng.rangef(0.35f, 0.9f) / (0.6f + fg.diff); fg.fishV = rng.rangef(-1.f, 1.f) * (0.35f + fg.diff * 0.9f); }
      fg.fishPos += fg.fishV * dt;
      if (fg.fishPos < 0.05f) { fg.fishPos = 0.05f; fg.fishV = std::fabs(fg.fishV); } if (fg.fishPos > 0.95f) { fg.fishPos = 0.95f; fg.fishV = -std::fabs(fg.fishV); }
      bool on = std::fabs(fg.fishPos - fg.bar) < fg.size * 0.5f + 0.02f;
      fg.progress += (on ? 0.3f : -0.2f * (0.6f + fg.diff)) * dt;
      if (!on && fg.progress < 0.12f) fg.t += dt; 
      if (fg.progress >= 1.f) { fg.phase = 4; fg.t = 0; audio->play(Sfx::Catch); }
      else if (fg.progress <= 0.f) { p.animKind = 0; fg.phase = 0; pop(); toast("The fish escaped!"); audio->play(Sfx::Error); }
      break;
    }
    case 4: {
      if (fg.t == 0.f) {
        ItemStack st; st.id = (u16)fg.fishItem; st.count = 1;
        const ItemDef& d = C().def(st.id);
        if (d.cat == Cat::Fish) {
          float g = 0.05f + 0.04f * (float)p.level(2) + (fg.t < 0.01f && fg.diff > 0 ? 0.0f : 0.f); st.quality = (u8)(rng.chance(g) ? (rng.chance(0.25f) ? 2 : 1) : 0);
          addXp(2, 6 + (int)(fg.diff * 10)); s.caught.insert(d.id); s.counters["caught"]++; emitEvent("catch", d.id); if (fg.derby) ++fg.derbyCount;
        }
        giveItem(st); s.seenItems.insert(d.id);
        if (d.id == "golden_koi" && !flag("crystal_lake_taken")) { setFlag("crystal_lake_taken"); ItemStack cr; cr.id = (u16)C().item("lantern_crystal"); cr.count = 1; giveItem(cr); toast("The koi dropped a glowing crystal!", "item_lantern_crystal"); audio->play(Sfx::Sparkle); }
      }
      fg.t += dt;
      if (fg.t > 1.5f || (press && fg.t > 0.5f)) { p.animKind = 0; fg.phase = 0; pop(); }
      break;
    }
    default: break;
  }
}
}  // namespace cf
