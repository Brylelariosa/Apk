// Map management, daily spawning of forage/weeds, warps and map transitions.
#include "engine/log.h"
#include "game/game.h"
#include "platform/platform.h"

namespace cf {

Map* Game::getMap(const std::string& id) {
  auto it = s.maps.find(id);
  if (it != s.maps.end()) return it->second.get();
  std::unique_ptr<Map> m(new Map());
  if (id.rfind("mine_", 0) == 0) {
    int floor = atoi(id.c_str() + 5);
    s.maps[id] = std::move(m);
    generateMine(floor);
    return s.maps[id].get();
  }
  std::string file = id == "house" ? fmt("house_%d", clampv(s.farmhouseLevel, 1, 3)) : id;
  std::vector<u8> bytes;
  if (!platform().readAsset("maps/" + file + ".map", bytes)) { CF_LOGE("map not found: %s", file.c_str()); return nullptr; }
  if (!m->loadFromText(std::string((const char*)bytes.data(), bytes.size()), file) || m->w <= 0) { CF_LOGE("map invalid: %s", file.c_str()); return nullptr; }
  m->id = id;
  Map* raw = m.get();
  s.maps[id] = std::move(m);
  populateMap(*raw);
  return raw;
}

static bool nearWarp(const Map& m, int x, int y) {
  for (auto& w : m.warps) if (x >= w.pos.x - 2 && x <= w.pos.x + w.w + 1 && y >= w.pos.y - 2 && y <= w.pos.y + w.h + 1) return true;
  return false;
}

void Game::populateMap(Map& m) {
  // runs when a map is first created and again every morning (forage respawn, weeds, quest collectibles)
  for (size_t i = 0; i < m.objs.size(); ++i) if (m.objs[i].kind == ObjKind::Forage || m.objs[i].kind == ObjKind::DecoTop) m.removeObject((int)i);
  if (m.id == "village" && todaysFestival()) {
    int bd = C().obj("bunting"), ls = C().obj("lantern_string");
    for (int x = 20; x <= 35; ++x) { int d = (x % 3 == 0 && ls >= 0) ? ls : bd; if (d < 0) continue; MapObject o; o.kind = ObjKind::DecoTop; o.def = (u16)d; o.x = (i16)x; o.y = 13; m.addObject(o); }
    for (int x = 22; x <= 33; x += 2) { int d = ls; if (d < 0) continue; MapObject o; o.kind = ObjKind::DecoTop; o.def = (u16)d; o.x = (i16)x; o.y = 24; m.addObject(o); }
  }
  Rng r((u64)Rng::hash((u32)s.seed, (u32)s.cal.totalDays(), (u32)std::hash<std::string>()(m.id)));
  int season = s.cal.season;
  if (m.outdoors && m.forageCount > 0 && !(season == Winter && m.id == "shore" && false)) {
    std::vector<const ForageDef*> cand;
    for (auto& f : C().forage) {
      if (!(f.seasons & (1 << season))) continue;
      bool ok = false; for (auto& mp : f.maps) if (mp == m.id) ok = true;
      if (ok) cand.push_back(&f);
    }
    for (int n = 0, tries = 0; n < m.forageCount && tries < m.forageCount * 30 && !cand.empty(); ++tries) {
      int x = r.range(1, m.w - 2), y = r.range(1, m.h - 2);
      Terrain t = m.terrain(x, y);
      if (m.tileBlocked(x, y) || m.objectAt(x, y) >= 0 || (m.at(x, y).flags & TF_Tilled) || nearWarp(m, x, y)) continue;
      float total = 0; for (auto* f : cand) if ((f->sand && t == Terrain::Sand) || (!f->sand && t == Terrain::Grass)) total += f->weight;
      if (total <= 0) continue;
      float pick = r.f() * total; const ForageDef* chosen = nullptr;
      for (auto* f : cand) { if (!((f->sand && t == Terrain::Sand) || (!f->sand && t == Terrain::Grass))) continue; pick -= f->weight; if (pick <= 0) { chosen = f; break; } }
      if (!chosen) continue;
      MapObject o; o.kind = ObjKind::Forage; o.def = (u16)C().forageObj; o.x = (i16)x; o.y = (i16)y; o.aux = (u32)chosen->item; o.hp = 1;
      if (m.addObject(o) >= 0) ++n;
    }
  }
  if (m.weeds && season != Winter) {   // weeds and tall grass creep back onto the farm
    int have = 0; for (auto& o : m.objs) if (o.kind == ObjKind::Weed) ++have;
    int wd = C().obj("weed"), tg = C().obj("tallgrass");
    const MapRegion* field = m.region("field"); const MapRegion* pasture = m.region("pasture");
    for (int n = 0, tries = 0; n < 5 && have < 70 && tries < 60; ++tries) {
      const MapRegion* rg = r.chance(0.7f) ? field : pasture; if (!rg) continue;
      int x = r.range(rg->x, rg->x + rg->w - 1), y = r.range(rg->y, rg->y + rg->h - 1);
      if (m.tileBlocked(x, y) || m.objectAt(x, y) >= 0 || (m.at(x, y).flags & TF_Tilled) || m.terrain(x, y) != Terrain::Grass) continue;
      int d = (rg == pasture || r.chance(0.3f)) ? tg : wd; if (d < 0) continue;
      MapObject o; o.kind = ObjKind::Weed; o.def = (u16)d; o.x = (i16)x; o.y = (i16)y; o.hp = 1;
      if (m.addObject(o) >= 0) { ++n; ++have; }
    }
  }
  if (m.id == "forest") {   // lantern wisp sparks (one-time collectibles)
    int wd = C().obj("wisp");
    for (int i = 1; i <= 3; ++i) {
      const NamedPoint* p = m.point(fmt("wisp_%d", i));
      if (!p || flag(fmt("wisp_%d_taken", i)) || wd < 0) continue;
      bool exists = false; for (auto& o : m.objs) if (o.kind == ObjKind::Wisp && o.x == p->pos.x && o.y == p->pos.y) exists = true;
      if (exists) continue;
      MapObject o; o.kind = ObjKind::Wisp; o.def = (u16)wd; o.x = (i16)p->pos.x; o.y = (i16)p->pos.y; o.aux = (u32)i;
      m.addObject(o);
    }
  }
}

void Game::fadeTo(std::function<void()> mid) { fadeCallback = std::move(mid); fading = true; fadeTarget = 1.f; }

void Game::enterMap(const std::string& id, const std::string& point, bool withFade) {
  auto doEnter = [this, id, point]() {
    Map* m = getMap(id);
    if (!m) { toast("The path is blocked."); return; }
    s.curMap = id; s.pl.map = id;
    const NamedPoint* p = m->point(point);
    IVec2 t = p ? p->pos : IVec2(m->w / 2, m->h / 2);
    if (!p && !m->points.empty()) t = m->points[0].pos;
    s.pl.pos = tileCenter(t.x, t.y);
    if (!m->walkableTile(t.x, t.y)) for (int d = 1; d < 4; ++d) for (int dy = -d; dy <= d; ++dy) for (int dx = -d; dx <= d; ++dx) if (m->walkableTile(t.x + dx, t.y + dy)) { s.pl.pos = tileCenter(t.x + dx, t.y + dy); d = 9; dy = 9; break; }
    cam.snap(s.pl.pos);
    placeNpcsForMap(id);
    fx.clear();
    hotbarOpen = false;
    emitEvent("visit", id);
    if (id.rfind("mine_", 0) == 0) { s.deepestMine = std::max(s.deepestMine, m->mineFloor); emitEvent("mine", std::to_string(m->mineFloor)); }
    setStatusMood();
  };
  if (withFade) fadeTo(doEnter); else doEnter();
}

bool Game::collides(const Map& m, Vec2 p) const {
  // player foot box 10x5 centred on p
  float hx = 4.5f, hy = 2.5f;
  int x0 = (int)std::floor((p.x - hx) / kTile), x1 = (int)std::floor((p.x + hx) / kTile);
  int y0 = (int)std::floor((p.y - hy) / kTile), y1 = (int)std::floor((p.y + hy) / kTile);
  for (int y = y0; y <= y1; ++y) for (int x = x0; x <= x1; ++x) if (m.tileBlocked(x, y)) return true;
  return false;
}

void Game::setStatusMood() {
  if (!audio) return;
  Mood md; const Map& m = map();
  md.season = s.cal.season; md.weather = (int)weather(); md.night = s.cal.daylight() < 0.35f; md.festival = todaysFestival() != nullptr && m.id == "village";
  md.indoors = m.indoor;
  md.place = m.id == "farm" ? 0 : m.id == "village" ? 1 : m.id == "forest" || m.id == "grove" ? 2 : m.id == "shore" ? 3 : m.mineFloor > 0 ? 4 : 5;
  audio->setMood(md);
}

void Game::addMoney(int n) { s.pl.money = std::max(0, s.pl.money + n); if (n > 0) { s.counters["earned"] += n; emitEvent("earn", "", n); } }
}  // namespace cf
