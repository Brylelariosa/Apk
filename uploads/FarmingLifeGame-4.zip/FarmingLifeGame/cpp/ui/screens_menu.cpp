// Pause-menu tabs: inventory, crafting/cooking, quests, friends, collection, skills.
#include "game/game.h"

namespace cf {
static Rect centered(Game& g, float w, float h) { Rect sf = g.ui.safe; w = std::min(w, sf.w); h = std::min(h, sf.h); return Rect(sf.x + (sf.w - w) * 0.5f, sf.y + (sf.h - h) * 0.5f, w, h); }

void Game::uiMenu() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 150));
  Rect p = centered(*this, ui.px(740), ui.px(336));
  ui.panel(p, 0);
  static const char* tabs[6] = {"Items", "Craft", "Quests", "Friends", "Collect", "Skills"};
  float cw = ui.px(36), tw = (p.w - ui.px(28) - cw) / 6.f, th = ui.px(34), ty = p.y + ui.px(8);
  for (int i = 0; i < 6; ++i) if (ui.tab(Rect(p.x + ui.px(12) + (float)i * tw, ty, tw - 2, th), tabs[i], menu.tab == i)) { menu.tab = i; menu.scroll = menu.scroll2 = 0; menu.sel = -1; menu.recipe = -1; audio->play(Sfx::Click, 0.6f); }
  if (ui.iconButton(Rect(p.right() - cw - ui.px(8), ty, cw, th), Sprites::ui.get("ui_close"))) { pop(); audio->play(Sfx::Back); return; }
  Rect body(p.x + ui.px(12), ty + th + ui.px(8), p.w - ui.px(24), p.bottom() - (ty + th + ui.px(8)) - ui.px(12));
  switch (menu.tab) {
    case 0: uiMenuInventory(body); break; case 1: uiMenuCraft(body); break; case 2: uiMenuQuests(body); break;
    case 3: uiMenuFriends(body); break; case 4: uiMenuCollection(body); break; default: uiMenuSkills(body); break;
  }
}

void Game::uiMenuInventory(Rect body) {
  Player& pl = s.pl; float detailW = ui.px(200), gap = ui.px(4);
  Rect grid(body.x, body.y, body.w - detailW - ui.px(10), body.h);
  float ss = std::min(ui.px(46), (grid.w - gap) / 8.f - gap);
  int cols = std::max(4, (int)((grid.w + gap) / (ss + gap)));
  int rows = (Inventory::kSlots + cols - 1) / cols;
  float content = (float)rows * (ss + gap);
  float y0 = grid.y - menu.scroll;
  ui.scrollBegin(grid, &menu.scroll, content);
  for (int i = 0; i < Inventory::kSlots; ++i) {
    Rect sl(grid.x + (float)(i % cols) * (ss + gap), y0 + (float)(i / cols) * (ss + gap), ss, ss);
    ui.stack(pl.inv.slots[(size_t)i], sl, i == menu.sel, true);
    if (i == pl.sel) r->batch.nine(Sprites::ui.get("ui_slot_sel"), 4, sl.x + 1, sl.y + 1, sl.w - 2, sl.h - 2, (float)ui.pk * 0.45f, col::rgba(120, 220, 120));
    if (ui.tapped(sl)) {
      if (menu.recipe >= 0 && menu.recipe != i) { std::swap(pl.inv.slots[(size_t)menu.recipe], pl.inv.slots[(size_t)i]); menu.recipe = -1; menu.sel = i; audio->play(Sfx::Pop, 0.6f); }
      else { menu.sel = i; audio->play(Sfx::Click, 0.5f); }
    }
  }
  ui.scrollEnd();
  Rect d(body.right() - detailW, body.y, detailW, body.h);
  ui.panel(d, 3);
  float x = d.x + ui.px(10), y = d.y + ui.px(8), w = d.w - ui.px(20);
  if (menu.sel >= 0 && !pl.inv.slots[(size_t)menu.sel].empty()) {
    ItemStack& st = pl.inv.slots[(size_t)menu.sel]; const ItemDef& def = C().def(st.id);
    ui.icon(C().icon(st), Rect(x, y, ui.px(40), ui.px(40)));
    float h = ui.paragraph(Rect(x + ui.px(46), y, w - ui.px(46), 100), def.name, ui.ink(), 0); y += std::max(ui.px(44), h + 4);
    std::string sub = def.cat == Cat::Tool ? fmt("Tier %d", st.tier) : (st.quality ? std::string(qualityName(st.quality)) + " quality" : "");
    if (!sub.empty()) { ui.text(sub, x, y, ui.inkSoft(), -1); y += ui.lineH(-1) + 2; }
    y += ui.paragraph(Rect(x, y, w, 300), def.desc, ui.inkSoft(), -1) + ui.px(4);
    if (def.sell > 0) { ui.text(fmt("Sells for %dg", sellPrice(st)), x, y, ui.ink(), -1); y += ui.lineH(-1) + 2; }
    if (def.edible()) { ui.text(fmt("Energy +%d  Health +%d", def.energy, def.health), x, y, ui.good(), -2); y += ui.lineH(-2) + 2; }
    if (def.cat == Cat::Tool && def.tool == ToolType::Can) { ui.text(fmt("Water: %d", st.aux), x, y, ui.ink(), -1); }
    float by = d.bottom() - ui.px(44) * 3 - ui.px(14), bh = ui.px(40);
    if (def.edible() && ui.button(Rect(x, by, w, bh), "Eat", 1)) { eatItem(menu.sel); }
    by += bh + ui.px(4);
    if (ui.button(Rect(x, by, w, bh), menu.recipe >= 0 ? "Pick a slot..." : "Move")) menu.recipe = menu.recipe >= 0 ? -1 : menu.sel;
    by += bh + ui.px(4);
    bool canTrash = def.cat != Cat::Tool && def.cat != Cat::Quest;
    if (ui.button(Rect(x, by, w, bh), "Trash", 2, canTrash)) { st = ItemStack(); menu.sel = -1; audio->play(Sfx::Back); }
  } else ui.paragraph(Rect(x, y, w, 200), "Tap an item for details. Slots 1-12 form your quick bar.", ui.inkSoft(), -1);
}

static void drawIngredients(Game& g, const std::vector<Ingredient>& in, float x, float& y, float w) {
  UI& ui = g.ui;
  for (auto& ing : in) {
    int have = ing.item ? g.s.pl.inv.count(ing.item) : g.s.pl.inv.countGroup(ing);
    std::string name = ing.item ? C().def(ing.item).name : (ing.group.size() > 4 ? "any " + ing.group.substr(4) : ing.group);
    if (ing.item) ui.icon(C().icon([&] { ItemStack st; st.id = (u16)ing.item; return st; }()), Rect(x, y, ui.px(22), ui.px(22)));
    ui.text(fmt("%s", name.c_str()), x + ui.px(26), y + ui.px(4), ui.ink(), -1);
    ui.textRight(fmt("%d/%d", have, ing.count), x + w, y + ui.px(4), have >= ing.count ? ui.good() : ui.bad(), -1);
    y += ui.px(25);
  }
}

void Game::uiMenuCraft(Rect body) {
  bool atKitchen = map().id == "house";
  float lw = ui.px(250);
  Rect sw(body.x, body.y, lw, ui.px(34));
  if (ui.tab(Rect(sw.x, sw.y, lw / 2 - 2, sw.h), "Crafting", menu.cookMode == 0)) { menu.cookMode = 0; menu.recipe = -1; menu.scroll = 0; }
  if (ui.tab(Rect(sw.x + lw / 2, sw.y, lw / 2 - 2, sw.h), "Cooking", menu.cookMode == 1)) { menu.cookMode = 1; menu.recipe = -1; menu.scroll = 0; }
  std::string station = menu.cookMode ? "cook" : "craft";
  Rect list(body.x, body.y + ui.px(40), lw, body.h - ui.px(40));
  std::vector<int> ok = unlockedRecipes(station); std::vector<int> locked;
  for (size_t i = 0; i < C().recipes.size(); ++i) if (C().recipes[i].station == station && !recipeUnlocked(C().recipes[i])) locked.push_back((int)i);
  float rh = ui.px(36), content = (float)(ok.size() + locked.size()) * rh;
  float y = list.y - menu.scroll;
  ui.scrollBegin(list, &menu.scroll, content);
  auto rowFor = [&](int ri, bool isLocked) {
    const RecipeDef& rc = C().recipes[(size_t)ri]; Rect rr(list.x, y, list.w - ui.px(4), rh - 3); y += rh;
    ui.panel(rr, 3, menu.recipe == ri ? col::rgba(255, 245, 190) : (isLocked ? col::rgba(190, 185, 175) : kWhite));
    ItemStack o; o.id = (u16)rc.out; ui.icon(C().icon(o), Rect(rr.x + 4, rr.y + 3, rr.h - 6, rr.h - 6), isLocked ? col::rgba(70, 70, 70) : kWhite);
    ui.text(isLocked ? "???" : C().def(rc.out).name, rr.x + rr.h + 4, rr.y + (rr.h - ui.lineH(-1)) * 0.5f, isLocked ? ui.inkSoft() : ui.ink(), -1);
    if (ui.tapped(rr)) { menu.recipe = ri; audio->play(Sfx::Click, 0.5f); }
  };
  for (int ri : ok) rowFor(ri, false);
  for (int ri : locked) rowFor(ri, true);
  ui.scrollEnd();
  Rect d(body.x + lw + ui.px(10), body.y, body.w - lw - ui.px(10), body.h);
  ui.panel(d, 3);
  if (menu.recipe >= 0) {
    const RecipeDef& rc = C().recipes[(size_t)menu.recipe]; bool unlocked = recipeUnlocked(rc);
    float x = d.x + ui.px(12), yy = d.y + ui.px(10), w = d.w - ui.px(24);
    ItemStack o; o.id = (u16)rc.out; const ItemDef& od = C().def(rc.out);
    if (unlocked) {
      ui.icon(C().icon(o), Rect(x, yy, ui.px(44), ui.px(44)));
      ui.text(fmt("%s x%d", od.name.c_str(), rc.outCount), x + ui.px(52), yy + ui.px(6), ui.ink()); yy += ui.px(50);
      yy += ui.paragraph(Rect(x, yy, w, 200), od.desc, ui.inkSoft(), -1) + ui.px(6);
      if (od.edible()) { ui.text(fmt("Energy +%d  Health +%d%s", od.energy, od.health, od.buff.type != BuffType::None ? fmt("  %s +%d", buffName(od.buff.type), od.buff.amount).c_str() : ""), x, yy, ui.good(), -1); yy += ui.lineH(-1) + ui.px(6); }
      ui.text("Needs", x, yy, ui.inkSoft(), -1); yy += ui.lineH(-1) + 2;
      drawIngredients(*this, rc.in, x, yy, w);
      bool station_ok = rc.station == "craft" || atKitchen;
      float bh = ui.px(42);
      if (!station_ok) ui.text("Cook in your farmhouse kitchen.", x, d.bottom() - bh - ui.px(32), ui.bad(), -1);
      if (ui.button(Rect(x, d.bottom() - bh - ui.px(10), w, bh), rc.station == "cook" ? "Cook" : "Craft", 1, canCraft(rc) && station_ok)) { craft(menu.recipe); }
    } else {
      ui.text("Locked recipe", x, yy, ui.ink()); yy += ui.lineH() + 6;
      auto p = splitString(rc.unlock, ':'); std::string hint = "Keep exploring...";
      if (p.size() >= 3 && p[0] == "hearts") { int ni = C().npc(p[1]); if (ni >= 0) hint = fmt("Reach %s hearts of friendship with %s.", p[2].c_str(), C().npcs[(size_t)ni].name.c_str()); }
      else if (p[0] == "quest") hint = "Complete a quest to learn this recipe.";
      ui.paragraph(Rect(x, yy, w, 200), hint, ui.inkSoft(), 0);
    }
  } else ui.paragraph(Rect(d.x + ui.px(12), d.y + ui.px(12), d.w - ui.px(24), 200), menu.cookMode && !atKitchen ? "Cooking is done in your farmhouse kitchen. You can browse recipes here." : "Pick a recipe to see what it needs.", ui.inkSoft(), -1);
}

void Game::uiMenuQuests(Rect body) {
  float y = body.y - menu.scroll; float total = 0;
  ui.scrollBegin(body, &menu.scroll, 3000.f);
  int done = 0;
  for (auto& qs : s.quests) if (qs.done) ++done;
  for (auto& qs : s.quests) {
    if (qs.done) continue; const QuestDef& q = C().quests[(size_t)qs.def]; if (q.hidden) continue;
    float h0 = y; Rect card(body.x, y, body.w - ui.px(6), 0);
    float cy = y + ui.px(8);
    ui.text(q.title, body.x + ui.px(12), cy, ui.ink(), 0); cy += ui.lineH() + 2;
    cy += ui.paragraph(Rect(body.x + ui.px(12), cy, body.w - ui.px(30), 300), q.desc, ui.inkSoft(), -1) + 4;
    for (size_t i = 0; i < q.objs.size(); ++i) {
      const Objective& o = q.objs[i]; bool dn = questObjectiveDone(q, qs, i);
      std::string label = o.type == "talk" ? "Talk to " + (C().npc(o.arg) >= 0 ? C().npcs[(size_t)C().npc(o.arg)].name : o.arg) : o.type == "have" ? fmt("Have %d %s", o.count, C().def(C().item(o.arg)).name.c_str())
        : o.type == "deliver" ? fmt("Give %d %s to %s", o.count, C().def(C().item(o.arg2)).name.c_str(), C().npc(o.arg) >= 0 ? C().npcs[(size_t)C().npc(o.arg)].name.c_str() : "?")
        : o.type == "mine" ? fmt("Reach mine floor %s", o.arg.c_str()) : o.type == "visit" ? "Visit " + o.arg : o.type == "flag" ? "Complete the story step" : fmt("%s %s %d", o.type.c_str(), o.arg == "any" ? "" : o.arg.c_str(), o.count);
      int cur = dn ? o.count : std::min(qs.prog[i], o.count);
      if (o.type == "have") cur = std::min(s.pl.inv.count(C().item(o.arg)), o.count);
      ui.text((dn ? "[x] " : "[ ] ") + label + ((o.count > 1 && o.type != "deliver" && o.type != "mine") ? fmt(" (%d/%d)", cur, o.count) : ""), body.x + ui.px(16), cy, dn ? ui.good() : ui.ink(), -1); cy += ui.lineH(-1) + 2;
    }
    card.h = cy - y + ui.px(6); ui.panel(card, 3, col::rgba(255, 255, 255, 0)); r->batch.flush();
    y = cy + ui.px(10); total += y - h0;
    (void)h0;
  }
  if (done == (int)s.quests.size() || s.quests.empty()) ui.text("No active quests. Explore, talk to villagers and check the notice board.", body.x + ui.px(8), y, ui.inkSoft(), -1);
  ui.text(fmt("Completed quests: %d", done), body.x + ui.px(8), y + ui.px(24), ui.inkSoft(), -1);
  ui.scrollEnd();
  (void)total;
}

void Game::uiMenuFriends(Rect body) {
  float rh = ui.px(56), y = body.y - menu.scroll;
  ui.scrollBegin(body, &menu.scroll, (float)C().npcs.size() * rh);
  for (size_t i = 0; i < s.npcs.size(); ++i) {
    NpcState& n = s.npcs[i]; const NpcDef& d = C().npcs[(size_t)n.def]; Rect rr(body.x, y, body.w - ui.px(6), rh - 4); y += rh;
    ui.panel(rr, 3);
    const Region* pr = Sprites::find("por_" + d.id + "_neutral");
    if (pr) { int sc = std::max(1, (int)((rr.h - 6) / (float)pr->h)); r->batch.regionRect(*pr, rr.x + 4, rr.y + 3, (float)(pr->w * sc), (float)(pr->h * sc)); }
    float x = rr.x + ui.px(62);
    ui.text(d.name + (n.dating == 2 ? "  (spouse)" : n.dating == 1 ? "  (dating)" : ""), x, rr.y + ui.px(5), ui.ink(), 0);
    ui.text(d.job + fmt(" - birthday %s %d", Calendar::seasonName(d.bdaySeason), d.bdayDay), x, rr.y + ui.px(5) + ui.lineH(), ui.inkSoft(), -2);
    float hs = ui.px(15); int hearts = n.hearts();
    for (int h = 0; h < 10; ++h) r->batch.regionRect(Sprites::ui.get(h < hearts ? "ic_heart" : "ic_heart_empty"), rr.right() - 10 * (hs + 2) - ui.px(6) + (float)h * (hs + 2), rr.y + (rr.h - hs) * 0.5f, hs, hs * 0.9f);
  }
  ui.scrollEnd();
}

void Game::uiMenuCollection(Rect body) {
  struct Sec { const char* title; Cat cat; };
  static const Sec secs[] = {{"Crops", Cat::Crop}, {"Fish", Cat::Fish}, {"Minerals", Cat::Mineral}, {"Forage", Cat::Forage}, {"Animal goods", Cat::Product}, {"Meals", Cat::Food}, {"Artisan goods", Cat::Artisan}};
  float ss = ui.px(34), gap = ui.px(4); int cols = std::max(4, (int)((body.w - ui.px(8)) / (ss + gap)));
  float y = body.y - menu.scroll;
  ui.scrollBegin(body, &menu.scroll, 3000.f);
  for (auto& sec : secs) {
    std::vector<int> ids; int seen = 0;
    for (size_t i = 1; i < C().items.size(); ++i) if (C().items[i].cat == sec.cat) { ids.push_back((int)i); if (s.seenItems.count(C().items[i].id)) ++seen; }
    ui.text(fmt("%s  %d/%d", sec.title, seen, (int)ids.size()), body.x + 4, y, ui.ink(), 0); y += ui.lineH() + 4;
    for (size_t k = 0; k < ids.size(); ++k) {
      Rect sl(body.x + 4 + (float)(k % (size_t)cols) * (ss + gap), y + (float)(k / (size_t)cols) * (ss + gap), ss, ss);
      bool got = s.seenItems.count(C().items[(size_t)ids[k]].id) > 0;
      r->batch.nine(Sprites::ui.get("ui_slot"), 4, sl.x, sl.y, sl.w, sl.h, std::max(1.f, sl.w / 20.f));
      ItemStack st; st.id = (u16)ids[k]; ui.icon(C().icon(st), sl.inset(sl.w * 0.12f), got ? kWhite : col::rgba(40, 34, 50, 200));
    }
    y += (float)((ids.size() + (size_t)cols - 1) / (size_t)cols) * (ss + gap) + ui.px(8);
  }
  std::string rt = fmt("Recipes learned: %zu", s.recipes.size()); ui.text(rt, body.x + 4, y, ui.ink(), 0);
  ui.scrollEnd();
}

void Game::uiMenuSkills(Rect body) {
  static const char* nm[4] = {"Farming", "Mining", "Fishing", "Foraging"};
  float y = body.y + ui.px(4), w = body.w * 0.5f - ui.px(16);
  for (int i = 0; i < 4; ++i) {
    int lv = s.pl.level(i), xp = s.pl.xp[i], lo = lv * lv * 40, hi = (lv + 1) * (lv + 1) * 40;
    ui.text(fmt("%s  Lv %d", nm[i], lv), body.x + ui.px(8), y, ui.ink(), 0); y += ui.lineH() + 3;
    ui.bar(Rect(body.x + ui.px(8), y, w, ui.px(12)), lv >= 10 ? 1.f : (float)(xp - lo) / (float)(hi - lo), col::rgba(110, 200, 90)); y += ui.px(26);
  }
  float x = body.x + body.w * 0.5f + ui.px(8); float yy = body.y + ui.px(4);
  std::string lines[] = {fmt("Days played: %d", s.cal.totalDays()), fmt("Gold earned: %d", counter("earned")), fmt("Crops harvested: %d", counter("harvested")), fmt("Fish caught: %d", counter("caught")),
                         fmt("Items shipped: %d", counter("shipped")), fmt("Rocks & ores mined: %d", counter("mined")), fmt("Forage picked: %d", counter("foraged")), fmt("Chats: %d  Gifts: %d", counter("talks"), counter("gifts")),
                         fmt("Deepest mine floor: %d", s.deepestMine), fmt("Play time: %d min", (int)(s.playSeconds / 60))};
  for (auto& l : lines) { ui.text(l, x, yy, ui.ink(), -1); yy += ui.lineH(-1) + ui.px(5); }
}
}  // namespace cf
