// Main menu, new game, pause, settings, credits, message/confirm popups, saving and day summary.
#include "game/game.h"

namespace cf {

static Rect centered(Game& g, float w, float h) { Rect sf = g.ui.safe; w = std::min(w, sf.w); h = std::min(h, sf.h); return Rect(sf.x + (sf.w - w) * 0.5f, sf.y + (sf.h - h) * 0.5f, w, h); }

void Game::uiMainMenu() {
  float sw = (float)r->screenW;
  // title
  float ty = ui.safe.y + ui.safe.h * 0.07f; int k = ui.k(3);
  std::string title = "Thistledown Vale";
  float tw = (float)r->font.textWidth(title, k);
  r->font.drawOutlined(r->batch, title, std::floor(sw * 0.5f - tw * 0.5f), std::floor(ty), k, col::rgba(255, 244, 200), col::rgba(92, 52, 28));
  ui.textCenter(Rect(0, ty + (float)r->font.lineHeight(k) + ui.px(2), sw, ui.lineH()), "a cozy farming life", col::rgba(255, 252, 235), 0, true);
  float bw = ui.px(230), bh = ui.px(46), gap = ui.px(8), x = ui.safe.x + (ui.safe.w - bw) * 0.5f;
  int n = hasSave() ? 5 : 4; float y = ui.safe.y + ui.safe.h * 0.5f - (float)n * (bh + gap) * 0.5f + ui.px(36);
  if (hasSave() && ui.button(Rect(x, y, bw, bh), "Continue", 1)) { if (!continueGame()) { msg.title = "Could not load"; msg.text = saveError; msg.back = St::MainMenu; push(St::Message); } audio->play(Sfx::Confirm); }
  if (hasSave()) y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "New Game", hasSave() ? 0 : 1)) { newName = "Sprout"; newLook = 0; editingName = false; setRoot(St::NewGame); audio->play(Sfx::Click); }
  y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Settings")) { settingsBack = St::MainMenu; settingsTab = 0; settingsScroll = 0; push(St::Settings); audio->play(Sfx::Click); }
  y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Credits")) { push(St::Credits); audio->play(Sfx::Click); }
  y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Exit", 2)) { wantsExit = true; platform().requestExit(); }
  ui.textCenter(Rect(0, ui.safe.bottom() - ui.lineH(-2) - 4, sw, ui.lineH(-2)), "Native C++ / OpenGL ES - no engine - works fully offline", col::rgba(255, 255, 255, 190), -2, true);
}

void Game::uiNewGame() {
  Rect p = centered(*this, ui.px(520), ui.px(300));
  ui.panel(p, 0);
  ui.textCenter(Rect(p.x, p.y + ui.px(8), p.w, ui.lineH(1)), "A new farmer arrives", ui.ink(), 1);
  if (!editingName) {
    float y = p.y + ui.px(52);
    ui.text("Name", p.x + ui.px(20), y + ui.px(10), ui.inkSoft(), -1);
    Rect nr(p.x + ui.px(100), y, ui.px(220), ui.px(40));
    ui.panel(nr, 3);
    ui.text(newName.empty() ? "(tap to type)" : newName, nr.x + ui.px(10), nr.y + (nr.h - ui.lineH()) * 0.5f, ui.ink());
    if (ui.tapped(nr)) { editingName = true; audio->play(Sfx::Click); }
    y += ui.px(56);
    ui.text("Look", p.x + ui.px(20), y + ui.px(36), ui.inkSoft(), -1);
    for (int i = 0; i < 2; ++i) {
      Rect lr(p.x + ui.px(100) + (float)i * ui.px(110), y, ui.px(96), ui.px(96));
      ui.panel(lr, newLook == i ? 2 : 3, newLook == i ? kWhite : col::rgba(220, 210, 190));
      const Region& rg = Sprites::world.get(fmt("ch_player%d_all_d_idle_0", i)); int sc = std::max(1, (int)(lr.w * 0.62f / (float)rg.h * 1.0f));
      r->batch.regionRect(rg, lr.x + (lr.w - (float)rg.w * (float)sc) * 0.5f, lr.y + (lr.h - (float)rg.h * (float)sc) * 0.5f, (float)rg.w * (float)sc, (float)rg.h * (float)sc);
      if (ui.tapped(lr)) { newLook = i; audio->play(Sfx::Click); }
    }
    float bw = ui.px(130), bh = ui.px(44);
    if (ui.button(Rect(p.x + ui.px(16), p.bottom() - bh - ui.px(12), bw, bh), "Back")) { setRoot(St::MainMenu); }
    if (ui.button(Rect(p.right() - bw - ui.px(16), p.bottom() - bh - ui.px(12), bw, bh), "Start!", 1)) { audio->play(Sfx::Confirm); newGame(newName, newLook); }
  } else {
    ui.panel(Rect(p.x + ui.px(20), p.y + ui.px(46), p.w - ui.px(40), ui.px(40)), 3);
    ui.text(newName + "_", p.x + ui.px(32), p.y + ui.px(46) + (ui.px(40) - ui.lineH()) * 0.5f, ui.ink());
    if (ui.osk(Rect(p.x + ui.px(14), p.y + ui.px(94), p.w - ui.px(28), p.h - ui.px(100)), &newName, 12)) editingName = false;
  }
}

void Game::uiPause() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 140));
  Rect p = centered(*this, ui.px(250), ui.px(330));
  ui.panel(p, 0);
  ui.textCenter(Rect(p.x, p.y + ui.px(8), p.w, ui.lineH(1)), "Paused", ui.ink(), 1);
  float bw = p.w - ui.px(40), bh = ui.px(42), gap = ui.px(8), x = p.x + ui.px(20), y = p.y + ui.px(48);
  if (ui.button(Rect(x, y, bw, bh), "Resume", 1)) { pop(); } y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Inventory & more")) { pop(); menu = MenuUI(); push(St::Menu); } y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Save game")) { push(St::Saving); savingDone = false; savingT = 0; } y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Settings")) { settingsBack = St::Pause; settingsTab = 0; settingsScroll = 0; push(St::Settings); } y += bh + gap;
  if (ui.button(Rect(x, y, bw, bh), "Quit to title", 2)) { confirm.text = "Save and return to the title screen?"; confirm.id = 2; push(St::Confirm); }
}

void Game::uiConfirm() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 140));
  Rect p = centered(*this, ui.px(300), ui.px(150));
  ui.panel(p, 2);
  ui.paragraph(Rect(p.x + ui.px(16), p.y + ui.px(16), p.w - ui.px(32), p.h - ui.px(70)), confirm.text, ui.ink());
  float bw = ui.px(110), bh = ui.px(42);
  if (ui.button(Rect(p.x + ui.px(20), p.bottom() - bh - ui.px(12), bw, bh), "Not yet")) pop();
  if (ui.button(Rect(p.right() - bw - ui.px(20), p.bottom() - bh - ui.px(12), bw, bh), "Yes", 1)) {
    int id = confirm.id; pop();
    if (id == 1) { while (top() != St::Gameplay && stack.size() > 1) pop(); push(St::Sleep); sleepDone = false; stateTime = 0; audio->play(Sfx::Confirm); }
    else if (id == 2) { saveGame(true); hasSession = false; s = Session(); fx.clear(); setRoot(St::MainMenu); }
  }
}

void Game::uiMessage() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 120));
  Rect p = centered(*this, ui.px(460), ui.px(260));
  ui.panel(p, 2);
  ui.textCenter(Rect(p.x, p.y + ui.px(10), p.w, ui.lineH(1)), msg.title, ui.ink(), 1);
  ui.paragraph(Rect(p.x + ui.px(20), p.y + ui.px(48), p.w - ui.px(40), p.h - ui.px(110)), msg.text, ui.ink(), 0);
  float bw = ui.px(130), bh = ui.px(42);
  if (ui.button(Rect(p.x + (p.w - bw) * 0.5f, p.bottom() - bh - ui.px(12), bw, bh), "OK", 1) || (stateTime > 0.3f && in->backPressed)) { pop(); }
}

void Game::uiSaving() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 100));
  if (!savingDone) { savingDone = true; saveGame(true); }
  Rect p = centered(*this, ui.px(210), ui.px(70));
  ui.panel(p, 2);
  int dots = ((int)(stateTime * 4)) % 4; std::string d(dots, '.');
  ui.textCenter(p, saveError.empty() ? "Saving" + d : "Save failed!", ui.ink());
  if (stateTime > 0.9f) { savingDone = false; if (top() == St::Saving) pop(); }
}

void Game::uiCredits() {
  Rect p = centered(*this, ui.px(520), ui.px(300));
  ui.panel(p, 0);
  ui.textCenter(Rect(p.x, p.y + ui.px(8), p.w, ui.lineH(1)), "Credits", ui.ink(), 1);
  ui.paragraph(Rect(p.x + ui.px(24), p.y + ui.px(48), p.w - ui.px(48), p.h - ui.px(110)),
    "Thistledown Vale - an original cozy farming and life-simulation RPG.\n\nWritten in native C++17 with a custom renderer, audio synthesiser, tile engine and save system. No game engine, no third-party assets: all pixel art, maps, music and sounds are generated procedurally by this project.\n\nThank you for playing!", ui.ink());
  float bw = ui.px(130), bh = ui.px(42);
  if (ui.button(Rect(p.x + (p.w - bw) * 0.5f, p.bottom() - bh - ui.px(12), bw, bh), "Back", 1)) setRoot(St::MainMenu);
}

void Game::uiSettings() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, settingsBack == St::MainMenu ? 90 : 150));
  Rect p = centered(*this, ui.px(560), ui.px(330));
  ui.panel(p, 0);
  ui.textCenter(Rect(p.x, p.y + ui.px(6), p.w, ui.lineH(1)), "Settings", ui.ink(), 1);
  static const char* tabs[4] = {"Graphics", "Audio", "Access", "Controls"};
  float tw = (p.w - ui.px(24)) / 4.f, ty = p.y + ui.px(8) + ui.lineH(1) + ui.px(4), th = ui.px(34);
  for (int i = 0; i < 4; ++i) if (ui.tab(Rect(p.x + ui.px(12) + (float)i * tw, ty, tw - 2, th), tabs[i], settingsTab == i)) { settingsTab = i; settingsScroll = 0; }
  Rect body(p.x + ui.px(14), ty + th + ui.px(6), p.w - ui.px(28), p.bottom() - (ty + th + ui.px(6)) - ui.px(58));
  float rowH = ui.px(40), y = body.y - settingsScroll, total = 0;
  ui.scrollBegin(body, &settingsScroll, 1000.f);
  auto row = [&](float h = 0) { Rect rr(body.x, y, body.w, h > 0 ? h : rowH); y += rr.h + ui.px(3); total += rr.h + ui.px(3); return rr; };
  auto stepper = [&](const char* label, int* v, int lo, int hi, const char* const* names) {
    Rect rr = row(); ui.text(label, rr.x + ui.px(8), rr.y + (rr.h - ui.lineH()) * 0.5f, ui.ink());
    float bw = ui.px(46); Rect m(rr.right() - bw * 2 - ui.px(120) - ui.px(8), rr.y + 2, bw, rr.h - 4), pl(rr.right() - bw - ui.px(4), rr.y + 2, bw, rr.h - 4);
    bool ch = false;
    if (ui.button(m, "-", 0, *v > lo)) { --*v; ch = true; } if (ui.button(pl, "+", 0, *v < hi)) { ++*v; ch = true; }
    ui.textCenter(Rect(m.right(), rr.y, pl.x - m.right(), rr.h), names ? names[*v - lo] : std::to_string(*v), ui.ink(), -1);
    return ch;
  };
  if (settingsTab == 0) {
    Rect rr = row(); ui.text("Quality preset", rr.x + ui.px(8), rr.y + (rr.h - ui.lineH(-1)) * 0.5f - ui.px(2), ui.ink(), -1);
    static const char* pn[4] = {"High", "Balanced", "Perf.", "Custom"};
    float bw = (rr.w - ui.px(180)) / 4.f;
    for (int i = 0; i < 4; ++i) { Rect b(rr.x + ui.px(150) + (float)i * bw, rr.y + 2, bw - 3, rr.h - 4); if (ui.button(b, pn[i], settings.preset == (Gfx)i ? 1 : 0)) { if (i < 3) settings.applyPreset((Gfx)i); else settings.preset = Gfx::Custom; } }
    bool ch = false;
    ch |= ui.toggle(row(), "Shadows", &settings.shadows); ch |= ui.toggle(row(), "Dynamic lighting", &settings.lighting);
    ch |= ui.toggle(row(), "Animated water", &settings.waterFx); ch |= ui.toggle(row(), "Swaying trees", &settings.treeSway);
    static const char* lv[4] = {"Off", "Low", "Medium", "High"};
    ch |= stepper("Particles", &settings.particles, 0, 3, lv); ch |= stepper("Weather density", &settings.weatherDensity, 0, 3, lv);
    bool f60 = settings.targetFps >= 60; if (ui.toggle(row(), "60 FPS (off = 30, saves battery)", &f60)) { settings.targetFps = f60 ? 60 : 30; ch = true; }
    static const char* zn[5] = {"Wide", "Normal", "Close", "Closer", "Closest"}; int z = settings.zoom + 1; if (stepper("Camera zoom", &z, 0, 4, zn)) { settings.zoom = z - 1; }
    if (ch) settings.preset = Gfx::Custom;
  } else if (settingsTab == 1) {
    ui.slider(row(ui.px(52)), "Music volume", &settings.music, 0.f, 1.f); ui.slider(row(ui.px(52)), "Effects volume", &settings.sfx, 0.f, 1.f);
    audio->setVolumes(settings.music, settings.sfx);
    Rect rr = row(); if (ui.button(Rect(rr.x + ui.px(8), rr.y + 2, ui.px(150), rr.h - 4), "Test sound")) audio->play(Sfx::Chime);
  } else if (settingsTab == 2) {
    ui.slider(row(ui.px(52)), "UI scale", &settings.uiScale, 0.8f, 1.5f);
    static const char* tn[3] = {"Small", "Medium", "Large"}; stepper("Text size", &settings.textSize, 0, 2, tn);
    ui.toggle(row(), "High contrast", &settings.highContrast); ui.toggle(row(), "Larger buttons", &settings.largeButtons);
    ui.toggle(row(), "Reduced motion", &settings.reducedMotion); ui.toggle(row(), "Vibration", &settings.vibration);
  } else {
    Rect rr = row();
    if (hasSession && settingsBack == St::Pause) { if (ui.button(Rect(rr.x + ui.px(8), rr.y + 2, rr.w - ui.px(16), rr.h - 4), "Customize HUD (move / resize / opacity)", 1)) { dragWhich = -1; push(St::CustomizeHud); } }
    else ui.text("Open Pause > Settings during a game to customize the HUD.", rr.x + ui.px(8), rr.y + ui.px(8), ui.inkSoft(), -1);
    rr = row(); if (ui.button(Rect(rr.x + ui.px(8), rr.y + 2, rr.w - ui.px(16), rr.h - 4), "Reset HUD layout", 2)) settings.resetHud();
    if (debugBuild) ui.toggle(row(), "Debug overlay", &settings.debugOverlay);
    row(); ui.text("Joystick: bottom-left. Action button: bottom-right.", body.x + ui.px(8), y - ui.px(34), ui.inkSoft(), -1);
  }
  ui.scrollEnd();
  (void)total;
  if (ui.button(Rect(p.x + (p.w - ui.px(140)) * 0.5f, p.bottom() - ui.px(50), ui.px(140), ui.px(42)), "Done", 1)) { saveSettings(); if (settingsBack == St::MainMenu) setRoot(St::MainMenu); else pop(); audio->play(Sfx::Back); }
}

void Game::uiDaySummary() {
  summaryT += ui.dt;
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 170));
  Rect p = centered(*this, ui.px(520), ui.px(330));
  ui.panel(p, 0);
  ui.textCenter(Rect(p.x, p.y + ui.px(8), p.w, ui.lineH(1)), fmt("%s, %s %d - Year %d", Calendar::kDayNamesPretty(s.cal.dayOfWeek()), Calendar::seasonName(s.cal.season), s.cal.day, s.cal.year), ui.ink(), 1);
  Rect body(p.x + ui.px(16), p.y + ui.px(48), p.w - ui.px(32), p.h - ui.px(112));
  float y = body.y - menu.scroll2;
  ui.scrollBegin(body, &menu.scroll2, 1000.f);
  if (!summary.sold.empty()) {
    ui.text("Shipped yesterday", body.x, y, ui.inkSoft(), -1); y += ui.lineH(-1) + 2;
    for (auto& pr : summary.sold) {
      ui.icon(C().icon(pr.first), Rect(body.x, y, ui.px(26), ui.px(26)));
      ui.text(fmt("%s x%d", C().def(pr.first.id).name.c_str(), pr.first.count), body.x + ui.px(32), y + ui.px(6), ui.ink(), -1);
      ui.textRight(fmt("%dg", pr.second), body.right() - ui.px(4), y + ui.px(6), ui.ink(), -1); y += ui.px(28);
    }
    ui.text(fmt("Total: %dg", summary.total), body.x, y + ui.px(2), ui.good(), 0); y += ui.lineH() + ui.px(8);
  }
  for (auto& n : summary.notes) { float h = ui.paragraph(Rect(body.x, y, body.w, 500), n, ui.ink(), -1); y += h + ui.px(4); }
  ui.scrollEnd();
  float bw = ui.px(180), bh = ui.px(44);
  if (ui.button(Rect(p.x + (p.w - bw) * 0.5f, p.bottom() - bh - ui.px(12), bw, bh), "A new day!", 1) && summaryT > 0.4f) {
    setRoot(St::Gameplay); push(St::Saving); savingDone = false; stateTime = 0; setStatusMood();
    toast(fmt("%s - %s", weatherName(s.wx.today), s.cal.timeString().c_str()), weatherIcon(s.wx.today));
  }
}
}  // namespace cf
