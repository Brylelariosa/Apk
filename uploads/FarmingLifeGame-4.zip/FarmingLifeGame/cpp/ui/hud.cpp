// In-game HUD: clock/weather/money, energy, item box + hotbar, virtual joystick and the contextual action button.
#include "animation/animation.h"
#include "game/game.h"

namespace cf {
namespace {
struct HudGeom { Vec2 joy; float joyR; Vec2 act; float actR; Rect item; Rect menu; };
HudGeom geom(Game& g) {
  UI& ui = g.ui; const Settings& st = g.settings; Rect sf = ui.safe; HudGeom h;
  auto at = [&](const HudElem& e) { return Vec2(sf.x + e.x * sf.w, sf.y + e.y * sf.h); };
  h.joy = at(st.joy); h.joyR = ui.px(54) * st.joy.scale;
  h.act = at(st.act); h.actR = ui.px(42) * st.act.scale;
  float is = ui.px(54) * st.itemBox.scale, ms = ui.px(48) * st.menu.scale;
  Vec2 ip = at(st.itemBox), mp = at(st.menu);
  h.item = Rect(ip.x - is * 0.5f, ip.y - is * 0.5f, is, is); h.menu = Rect(mp.x - ms * 0.5f, mp.y - ms * 0.5f, ms, ms);
  // keep everything fully on screen
  auto clampRect = [&](Rect& r) { r.x = clampv(r.x, sf.x, sf.right() - r.w); r.y = clampv(r.y, sf.y, sf.bottom() - r.h); };
  clampRect(h.item); clampRect(h.menu);
  h.joy.x = clampv(h.joy.x, sf.x + h.joyR, sf.right() - h.joyR); h.joy.y = clampv(h.joy.y, sf.y + h.joyR, sf.bottom() - h.joyR);
  h.act.x = clampv(h.act.x, sf.x + h.actR, sf.right() - h.actR); h.act.y = clampv(h.act.y, sf.y + h.actR, sf.bottom() - h.actR);
  return h;
}
}  // namespace

static void drawHudStatic(Game& g, const HudGeom& h, const ActionInfo* act, bool joyDown, Vec2 joyKnob) {
  UI& ui = g.ui; Renderer& r = *g.r; const Settings& st = g.settings; Session& s = g.s;
  // ---- status panel (top-left)
  float pad = ui.px(6), pw = ui.px(150), lh = ui.lineH(-1);
  Rect pr(ui.safe.x, ui.safe.y, pw, lh * 3 + pad * 2.6f + ui.px(8));
  ui.panel(pr, 1);
  float x = pr.x + pad, y = pr.y + pad;
  float is = lh * 1.25f;
  r.batch.regionRect(Sprites::ui.get(fmt("ic_s_%s", kSeasonNames[s.cal.season])), x, y - is * 0.1f, is, is);
  ui.text(g.s.cal.dateString(), x + is + pad, y, kWhite, -1);
  r.batch.regionRect(Sprites::ui.get(weatherIcon(g.weather())), pr.right() - is - pad, y - is * 0.1f, is, is);
  y += lh + pad * 0.3f;
  ui.text(s.cal.timeString(), x, y, col::rgba(255, 235, 170), 0);
  y += lh * 1.25f;
  r.batch.regionRect(Sprites::ui.get("ic_coin"), x, y, lh * 0.9f, lh * 0.9f);
  ui.text(std::to_string(s.pl.money), x + lh + pad * 0.5f, y, col::rgba(255, 224, 120), -1);
  // ---- energy / health bars
  Rect eb(pr.x, pr.bottom() + ui.px(4), pw, ui.px(11));
  ui.bar(eb, s.pl.energy / s.pl.maxEnergy, s.pl.energy < 25 ? col::rgba(230, 90, 60) : col::rgba(250, 205, 60));
  r.batch.regionRect(Sprites::ui.get("ic_bolt"), eb.x - ui.px(1), eb.y - ui.px(2), ui.px(10), ui.px(14));
  if (s.pl.health < s.pl.maxHealth) { Rect hb(eb.x, eb.bottom() + ui.px(3), pw, ui.px(9)); ui.bar(hb, s.pl.health / s.pl.maxHealth, col::rgba(230, 70, 80)); }
  float by = eb.bottom() + (s.pl.health < s.pl.maxHealth ? ui.px(16) : ui.px(5));
  for (auto& b : s.pl.buffs) { std::string t = fmt("%s +%d %dm", buffName(b.type), b.amount, b.minutes); ui.text(t, pr.x, by, col::rgba(255, 250, 200), -2, true); by += ui.lineH(-2); }
  const FestivalDef* fest = g.todaysFestival();
  if (fest && g.map().id == "village") ui.text(fest->name + "!", pr.x, by, col::rgba(255, 190, 220), -1, true);
  // ---- item box
  const ItemStack& sel = s.pl.inv.slots[(size_t)s.pl.sel];
  r.batch.setBlend(BlendMode::Alpha);
  u32 op = col::rgba(255, 255, 255, (int)(st.itemBox.opacity * 255));
  r.batch.nine(Sprites::ui.get("ui_panel"), 7, h.item.x, h.item.y, h.item.w, h.item.h, (float)ui.pk * 0.8f, op);
  if (!sel.empty()) ui.stack(sel, h.item.inset(h.item.w * 0.14f), false, true);
  else ui.textCenter(h.item, "-", ui.inkSoft());
  u32 mop = col::rgba(255, 255, 255, (int)(st.menu.opacity * 255));
  r.batch.nine(Sprites::ui.get("ui_button"), 5, h.menu.x, h.menu.y, h.menu.w, h.menu.h, (float)ui.pk, mop);
  ui.icon(Sprites::ui.get("ic_bag"), h.menu.inset(h.menu.w * 0.22f), col::rgba(58, 38, 24));
  // ---- joystick
  float jo = st.joy.opacity;
  r.batch.regionRect(Sprites::ui.get("ui_joy_base"), h.joy.x - h.joyR, h.joy.y - h.joyR, h.joyR * 2, h.joyR * 2, col::rgba(255, 255, 255, (int)(jo * 255)));
  float kr = h.joyR * 0.45f;
  Vec2 kp = joyDown ? joyKnob : h.joy;
  r.batch.regionRect(Sprites::ui.get("ui_joy_knob"), kp.x - kr, kp.y - kr, kr * 2, kr * 2, col::rgba(255, 255, 255, (int)(clampv(jo + 0.1f, 0.f, 1.f) * 255)));
  // ---- action button
  float ao = st.act.opacity; bool ready = act && act->act != Act::None;
  r.batch.regionRect(Sprites::ui.get("ui_action_btn"), h.act.x - h.actR, h.act.y - h.actR, h.actR * 2, h.actR * 2, ready ? col::rgba(255, 240, 190, (int)(ao * 255)) : col::rgba(255, 255, 255, (int)(ao * 120)));
  if (ready) {
    ui.icon(Sprites::get(act->icon.empty() ? "ac_use" : act->icon), Rect(h.act.x - h.actR * 0.62f, h.act.y - h.actR * 0.62f, h.actR * 1.24f, h.actR * 1.24f));
    float tw = ui.textW(act->label, -1);
    ui.rect(Rect(h.act.x - tw * 0.5f - ui.px(5), h.act.y + h.actR + ui.px(2), tw + ui.px(10), ui.lineH(-1) + ui.px(4)), col::rgba(20, 16, 30, 170));
    ui.text(act->label, h.act.x - tw * 0.5f, h.act.y + h.actR + ui.px(4), kWhite, -1);
  } else if (act && !act->label.empty()) ui.textCenter(Rect(h.act.x - h.actR, h.act.y + h.actR, h.actR * 2, ui.lineH(-1)), act->label, col::rgba(255, 220, 200), -1, true);
}

void Game::drawHud() {
  HudGeom h = geom(*this);
  bool interactive = top() == St::Gameplay && !fading;
  ActionInfo a;
  if (interactive) a = resolveAction();
  // ---- touch handling
  Pointer* joyP = nullptr;
  for (auto& p : in->p) if (p.owner == 1 && p.down) joyP = &p;
  Pointer* actP = nullptr;
  for (auto& p : in->p) if (p.owner == 2 && p.down) actP = &p;
  if (!interactive) { moveStick[0] = moveStick[1] = 0; actionHeld = false; }
  else {
    for (auto& p : in->p) {
      if (!p.pressed || p.claimed) continue;
      float dj = (p.pos - h.joy).len(), da = (p.pos - h.act).len();
      if (hotbarOpen) continue;
      if (!joyP && dj < h.joyR * 1.7f) { p.claimed = true; p.owner = 1; joyP = &p; }
      else if (!actP && da < h.actR * 1.35f) { p.claimed = true; p.owner = 2; actP = &p; actionPressed = true; if (settings.vibration) platform().vibrate(8); }
    }
    Vec2 knob = h.joy;
    if (joyP) {
      Vec2 d = joyP->pos - h.joy; float len = d.len(), lim = h.joyR;
      float nx = len > 0 ? d.x / len : 0, ny = len > 0 ? d.y / len : 0; float mag = std::min(1.f, len / lim);
      moveStick[0] = nx * mag; moveStick[1] = ny * mag; knob = h.joy + Vec2(nx, ny) * std::min(len, lim);
    } else { moveStick[0] = moveStick[1] = 0; }
    actionHeld = actP != nullptr;
    drawHudStatic(*this, h, &a, joyP != nullptr, knob);
    // item box / menu / hotbar
    if (ui.tapped(h.menu)) { menu = MenuUI(); push(St::Menu); audio->play(Sfx::Click); hotbarOpen = false; }
    else if (ui.tapped(h.item)) { hotbarOpen = !hotbarOpen; audio->play(Sfx::Click, 0.6f); }
    if (hotbarOpen) {
      float ss = std::min(ui.px(46), (ui.safe.w - ui.px(20)) / 12.4f), gap = ui.px(3);
      float total = 12 * (ss + gap); Rect bar(ui.safe.x + (ui.safe.w - total) * 0.5f, h.item.bottom() + ui.px(6), total, ss + gap * 2);
      ui.panel(bar.inset(-ui.px(4)), 1);
      for (int i = 0; i < Inventory::kHotbar; ++i) {
        Rect slot(bar.x + (float)i * (ss + gap), bar.y + gap, ss, ss);
        ui.stack(s.pl.inv.slots[(size_t)i], slot, i == s.pl.sel, true);
        if (ui.tapped(slot)) { s.pl.sel = i; hotbarOpen = false; audio->play(Sfx::Click, 0.6f); }
      }
      for (auto& p : in->p) if (p.pressed && !p.claimed && !bar.inset(-ui.px(8)).contains(p.pos) && !h.item.contains(p.pos)) hotbarOpen = false;
    }
    return;
  }
  drawHudStatic(*this, h, nullptr, false, h.joy);
}

void Game::uiCustomizeHud() {
  // Drag controls to move them; use the buttons to resize or change opacity.
  HudGeom h = geom(*this);
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(0, 0, 0, 90));
  drawHudStatic(*this, h, nullptr, false, h.joy);
  struct E { HudElem* e; Rect hit; const char* name; };
  E es[4] = {{&settings.joy, Rect(h.joy.x - h.joyR, h.joy.y - h.joyR, h.joyR * 2, h.joyR * 2), "Joystick"}, {&settings.act, Rect(h.act.x - h.actR, h.act.y - h.actR, h.actR * 2, h.actR * 2), "Action"},
             {&settings.itemBox, h.item, "Item"}, {&settings.menu, h.menu, "Menu"}};
  for (int i = 0; i < 4; ++i) {
    bool selected = dragWhich == i;
    r->batch.nine(Sprites::ui.get("ui_slot_sel"), 4, es[i].hit.x - 3, es[i].hit.y - 3, es[i].hit.w + 6, es[i].hit.h + 6, (float)ui.pk * 0.6f, selected ? kWhite : col::rgba(255, 255, 255, 120));
  }
  for (auto& p : in->p) {
    if (p.pressed && !p.claimed) for (int i = 0; i < 4; ++i) if (es[i].hit.inset(-ui.px(8)).contains(p.pos)) { dragWhich = i; p.owner = 77; p.claimed = true; }
    if (p.owner == 77 && p.down && dragWhich >= 0) {
      HudElem& e = *es[dragWhich].e;
      e.x = clampv((p.pos.x - ui.safe.x) / ui.safe.w, 0.04f, 0.96f); e.y = clampv((p.pos.y - ui.safe.y) / ui.safe.h, 0.06f, 0.94f);
    }
  }
  Rect panel(ui.safe.x + ui.safe.w * 0.5f - ui.px(170), ui.safe.y + ui.safe.h * 0.34f, ui.px(340), ui.px(150));
  ui.panel(panel, 0);
  float y = panel.y + ui.px(8);
  ui.textCenter(Rect(panel.x, y, panel.w, ui.lineH()), dragWhich >= 0 ? std::string("Selected: ") + es[dragWhich].name : "Drag a control to move it", ui.ink()); y += ui.lineH() + ui.px(6);
  if (dragWhich >= 0) {
    HudElem& e = *es[dragWhich].e; float bw = ui.px(76), bh = ui.px(40);
    ui.text("Size", panel.x + ui.px(12), y + ui.px(10), ui.ink(), -1);
    if (ui.button(Rect(panel.x + ui.px(100), y, bw, bh), "-")) e.scale = clampv(e.scale - 0.1f, 0.6f, 2.f);
    if (ui.button(Rect(panel.x + ui.px(100) + bw + ui.px(8), y, bw, bh), "+")) e.scale = clampv(e.scale + 0.1f, 0.6f, 2.f);
    y += bh + ui.px(6);
    ui.text("Opacity", panel.x + ui.px(12), y + ui.px(10), ui.ink(), -1);
    if (ui.button(Rect(panel.x + ui.px(100), y, bw, bh), "-")) e.opacity = clampv(e.opacity - 0.1f, 0.2f, 1.f);
    if (ui.button(Rect(panel.x + ui.px(100) + bw + ui.px(8), y, bw, bh), "+")) e.opacity = clampv(e.opacity + 0.1f, 0.2f, 1.f);
  }
  float bw = ui.px(104), bh = ui.px(42);
  if (ui.button(Rect(panel.x + ui.px(8), panel.bottom() - bh - ui.px(6), bw, bh), "Reset", 2)) { settings.resetHud(); dragWhich = -1; }
  if (ui.button(Rect(panel.right() - bw - ui.px(8), panel.bottom() - bh - ui.px(6), bw, bh), "Done", 1)) { saveSettings(); dragWhich = -1; pop(); }
}

void Game::uiToasts() {
  { St t = top(); if (t == St::Menu || t == St::Settings || t == St::NewGame || t == St::Pause || t == St::MainMenu || t == St::Credits || t == St::CustomizeHud) return; }
  float y = ui.safe.y + ui.px(8);
  float tw = ui.px(230);
  for (size_t i = 0; i < toasts.size(); ++i) {
    const Toast& t = toasts[toasts.size() - 1 - i];
    float a = clampv(std::min(t.t * 6.f, (3.6f - t.t) * 3.f), 0.f, 1.f);
    float w = std::max(tw, ui.textW(t.text, -1) + ui.px(46)), h = ui.px(30);
    float x = ui.safe.x + (ui.safe.w - w) * 0.5f, yy = y + (float)i * (h + ui.px(4)) - (1.f - a) * ui.px(8);
    r->batch.nine(Sprites::ui.get("ui_toast"), 3, x, yy, w, h, (float)ui.pk * 0.7f, col::rgba(255, 255, 255, (int)(a * 240)));
    float tx = x + ui.px(8);
    if (!t.icon.empty()) { const Region* rg = Sprites::find(t.icon); if (rg) { ui.icon(*rg, Rect(tx, yy + ui.px(3), h - ui.px(6), h - ui.px(6)), col::rgba(255, 255, 255, (int)(a * 255))); tx += h; } }
    ui.text(t.text, tx, yy + (h - ui.lineH(-1)) * 0.5f + ui.px(1), col::rgba(255, 246, 225, (int)(a * 255)), -1);
  }
}

void Game::uiDebug() {
  float y = ui.safe.y + ui.px(120);
  Player& p = s.pl; int npcCount = 0; for (auto& n : s.npcs) if (npcIsPlaced(n)) ++npcCount;
  std::string lines[] = {
    fmt("FPS %.0f  frame %.1fms", fps, frameMs), fmt("pos %.0f,%.0f  tile %d,%d  map %s", p.pos.x, p.pos.y, playerTile().x, playerTile().y, s.curMap.c_str()),
    fmt("day %d %s %s  %s", s.cal.day, Calendar::seasonName(s.cal.season), s.cal.timeString().c_str(), weatherName(s.wx.today)),
    fmt("npcs %d  animals %zu  objs %zu", npcCount, s.animals.size(), map().objs.size()),
    fmt("draws %d  quads %d  sprites %d", r->stats.drawCalls, r->stats.quads, r->stats.visibleSprites), fmt("particles %d  mem %zuMB", fx.count(), platform().memoryUsageKB() / 1024)};
  for (auto& l : lines) { ui.rect(Rect(ui.safe.x, y, ui.textW(l, -2) + 6, ui.lineH(-2) + 2), col::rgba(0, 0, 0, 160)); ui.text(l, ui.safe.x + 3, y + 1, col::rgba(160, 255, 160), -2); y += ui.lineH(-2) + 2; }
}
}  // namespace cf
