#include "ui/ui.h"

namespace cf {
void UI::begin(Renderer& rend, Input& input, const Settings& s, float dtSec, Rect safeArea) {
  r = &rend; in = &input; st = &s; dt = dtSec; time += dtSec; safe = safeArea;
  float scale = s.uiScale * (s.largeButtons ? 1.15f : 1.f);
  float fit = std::min(safeArea.h / 340.f, safeArea.w / 760.f);          // menus are designed for a 760x340 dp canvas
  dp = std::max(1.f, std::min(rend.density, fit) * scale);
  static const float tm[3] = {0.85f, 1.f, 1.3f};
  tk = std::max(2, roundi(13.f * dp * tm[clampv(s.textSize, 0, 2)] / 8.f));
  pk = std::max(2, roundi(dp * 1.25f));
  clipOn_ = false;
  bool any = false;
  for (auto& q : in->p) if (q.down || q.released) any = true;
  if (!any) dragging_ = false;
}
void UI::panel(const Rect& rc, int style, u32 tint) {
  static const char* nm[4] = {"ui_panel", "ui_panel_dark", "ui_dialog", "ui_panel_plain"};
  u32 c = tint;
  if (st->highContrast && style != 1) c = col::rgba(36, 32, 52);
  const Region& rg = Sprites::ui.get(nm[style & 3]);
  int border = style == 1 ? 5 : (style == 3 ? 3 : 7);
  r->batch.nine(rg, border, rc.x, rc.y, rc.w, rc.h, (float)(style == 1 ? std::max(2, pk - 1) : pk) * (style == 3 ? 0.8f : 1.f), c);
}
void UI::text(const std::string& s, float x, float y, u32 c, int rel, bool shadow) {
  r->font.draw(r->batch, s, std::floor(x), std::floor(y), k(rel), c, shadow ? col::rgba(0, 0, 0, 120) : 0);
}
void UI::textRight(const std::string& s, float xr, float y, u32 c, int rel, bool shadow) { text(s, xr - textW(s, rel), y, c, rel, shadow); }
void UI::textCenter(const Rect& rc, const std::string& s, u32 c, int rel, bool shadow) {
  float tw = textW(s, rel), th = (float)r->font.glyphHeight() * k(rel);
  text(s, rc.x + (rc.w - tw) * 0.5f, rc.y + (rc.h - th) * 0.5f, c, rel, shadow);
}
float UI::paragraph(const Rect& box, const std::string& s, u32 c, int rel, bool shadow) {
  std::vector<std::string> lines;
  r->font.wrap(s, (int)box.w, k(rel), lines);
  float y = box.y, lh = lineH(rel);
  for (auto& l : lines) { text(l, box.x, y, c, rel, shadow); y += lh; }
  return y - box.y;
}
void UI::icon(const Region& rg, const Rect& box, u32 tint) {
  int s = std::max(1, (int)std::floor(std::min(box.w / (float)rg.w, box.h / (float)rg.h)));
  float w = (float)(rg.w * s), h = (float)(rg.h * s);
  r->batch.regionRect(rg, std::floor(box.x + (box.w - w) * 0.5f), std::floor(box.y + (box.h - h) * 0.5f), w, h, tint);
}
void UI::stack(const ItemStack& s, const Rect& slot, bool selected, bool showCount) {
  r->batch.nine(Sprites::ui.get("ui_slot"), 4, slot.x, slot.y, slot.w, slot.h, std::max(1.f, slot.w / 20.f), st->highContrast ? col::rgba(70, 64, 90) : kWhite);
  if (!s.empty()) {
    icon(C().icon(s), slot.inset(slot.w * 0.1f));
    if (showCount && s.count > 1) { std::string n = std::to_string(s.count); text(n, slot.right() - textW(n, -1) - 2, slot.bottom() - lineH(-1) + 1, kWhite, -1, true); }
    if (s.quality > 0) {
      static const u32 qc[4] = {0, col::rgba(200, 210, 225), col::rgba(250, 200, 50), col::rgba(200, 120, 255)};
      const Region& star = Sprites::ui.get("ui_star"); float sz = slot.w * 0.28f;
      r->batch.regionRect(star, slot.x + 2, slot.bottom() - sz - 2, sz * 0.9f, sz, qc[s.quality & 3]);
    }
  }
  if (selected) r->batch.nine(Sprites::ui.get("ui_slot_sel"), 4, slot.x - 2, slot.y - 2, slot.w + 4, slot.h + 4, std::max(1.f, slot.w / 20.f), kWhite);
}
void UI::bar(const Rect& rc, float frac, u32 fill) {
  r->batch.nine(Sprites::ui.get("ui_bar_bg"), 3, rc.x, rc.y, rc.w, rc.h, std::max(1.f, rc.h / 8.f), kWhite);
  float w = (rc.w - 4) * clampv(frac, 0.f, 1.f);
  if (w > 2) r->batch.nine(Sprites::ui.get("ui_bar_fill"), 3, rc.x + 2, rc.y + 2, w, rc.h - 4, std::max(1.f, (rc.h - 4) / 8.f), fill);
}
bool UI::tapped(const Rect& rc) {
  for (auto& p : in->p) {
    if (!p.released || p.claimed || dragging_) continue;
    if (hit(rc, p.start) && hit(rc, p.pos) && p.travel < px(14)) return true;
  }
  return false;
}
bool UI::held(const Rect& rc) const {
  for (auto& p : in->p) if (p.down && !p.claimed && hit(rc, p.start) && hit(rc, p.pos)) return true;
  return false;
}
bool UI::button(const Rect& rc, const std::string& label, int style, bool enabled) {
  static const char* nm[5] = {"ui_button", "ui_button_green", "ui_button_red", "ui_button_off", "ui_button_down"};
  bool down = enabled && held(rc);
  const Region& rg = Sprites::ui.get(down ? "ui_button_down" : nm[enabled ? clampv(style, 0, 2) : 3]);
  r->batch.nine(rg, 5, rc.x, rc.y, rc.w, rc.h, (float)pk, st->highContrast && style == 0 && enabled ? col::rgba(120, 120, 150) : kWhite);
  u32 tc = !enabled ? col::rgba(130, 124, 112) : (style == 1 || style == 2 ? kWhite : (st->highContrast ? kWhite : col::rgba(58, 38, 24)));
  textCenter(Rect(rc.x, rc.y + (down ? px(1) : 0), rc.w, rc.h), label, tc, 0, style == 1 || style == 2);
  return enabled && tapped(rc);
}
bool UI::iconButton(const Rect& rc, const Region& rg, bool enabled, u32 tint) {
  bool down = enabled && held(rc);
  r->batch.nine(Sprites::ui.get(down ? "ui_button_down" : (enabled ? "ui_button" : "ui_button_off")), 5, rc.x, rc.y, rc.w, rc.h, (float)pk, kWhite);
  icon(rg, rc.inset(rc.w * 0.2f), enabled ? tint : col::rgba(150, 144, 130));
  return enabled && tapped(rc);
}
bool UI::tab(const Rect& rc, const std::string& label, bool selected) {
  r->batch.nine(Sprites::ui.get(selected ? "ui_tab_sel" : "ui_tab"), 5, rc.x, rc.y, rc.w, rc.h, (float)pk, st->highContrast && !selected ? col::rgba(90, 90, 120) : kWhite);
  textCenter(rc, label, selected || st->highContrast ? ink() : inkSoft(), -1);
  return tapped(rc);
}
bool UI::toggle(const Rect& rc, const std::string& label, bool* v) {
  float bs = std::min(rc.h, px(30));
  Rect box(rc.right() - bs - px(6), rc.y + (rc.h - bs) * 0.5f, bs, bs);
  text(label, rc.x + px(8), rc.y + (rc.h - (float)r->font.glyphHeight() * k()) * 0.5f, ink());
  r->batch.regionRect(Sprites::ui.get(*v ? "ui_check_on" : "ui_check_off"), box.x, box.y, box.w, box.h, kWhite);
  if (tapped(rc)) { *v = !*v; return true; }
  return false;
}
bool UI::slider(const Rect& rc, const std::string& label, float* v, float lo, float hi) {
  text(label, rc.x + px(8), rc.y + px(2), ink(), -1);
  Rect tr(rc.x + px(10), rc.y + rc.h * 0.62f, rc.w - px(20), px(8));
  r->batch.nine(Sprites::ui.get("ui_track"), 2, tr.x, tr.y - px(3), tr.w, tr.h + px(6), std::max(1.f, px(1.2f)), kWhite);
  float t = clampv((*v - lo) / (hi - lo), 0.f, 1.f);
  float kx = tr.x + tr.w * t, ks = px(22);
  r->batch.regionRect(Sprites::ui.get("ui_knob"), kx - ks * 0.5f, tr.y + tr.h * 0.5f - ks * 0.5f, ks, ks, kWhite);
  bool changed = false;
  for (auto& p : in->p) {
    if (!p.down || p.claimed) continue;
    Rect grab(rc.x, rc.y + rc.h * 0.35f, rc.w, rc.h * 0.65f);
    if (hit(grab, p.start)) { float nt = clampv((p.pos.x - tr.x) / tr.w, 0.f, 1.f); float nv = lo + (hi - lo) * nt; if (std::fabs(nv - *v) > 1e-4f) { *v = nv; changed = true; } p.owner = 99; }
  }
  return changed;
}
void UI::scrollBegin(const Rect& view, float* scroll, float contentH) {
  float maxS = std::max(0.f, contentH - view.h);
  for (auto& p : in->p) {
    if (!p.down || p.claimed) continue;
    if (view.contains(p.start) && p.travel > px(12)) { dragging_ = true; *scroll -= (p.pos.y - p.prev.y); }
  }
  *scroll = clampv(*scroll, 0.f, maxS);
  r->batch.flush();
  r->be->setScissor(true, (int)view.x, (int)view.y, (int)view.w, (int)view.h);
  clipOn_ = true; clip_ = view;
}
void UI::scrollEnd() { r->batch.flush(); r->be->setScissor(false, 0, 0, 0, 0); clipOn_ = false; }

bool UI::osk(const Rect& area, std::string* text, size_t maxLen) {
  static const char* rows[4] = {"1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm"};
  bool done = false;
  float bw = area.w / 10.5f, bh = std::min(px(44), area.h / 5.2f), gap = px(3);
  for (int ri = 0; ri < 4; ++ri) {
    std::string row = rows[ri];
    float rw = (float)row.size() * (bw + gap);
    float x0 = area.x + (area.w - rw) * 0.5f, y0 = area.y + ri * (bh + gap);
    for (size_t i = 0; i < row.size(); ++i) {
      char c = row[i]; if (shift_ && c >= 'a' && c <= 'z') c = (char)(c - 32);
      if (button(Rect(x0 + (float)i * (bw + gap), y0, bw, bh), std::string(1, c)) && text->size() < maxLen) *text += c;
    }
  }
  float y4 = area.y + 4 * (bh + gap), x = area.x + (area.w - 10 * (bw + gap)) * 0.5f;
  if (button(Rect(x, y4, bw * 1.5f, bh), "Aa", shift_ ? 1 : 0)) shift_ = !shift_;
  if (button(Rect(x + bw * 1.5f + gap, y4, bw * 4.f, bh), "space") && text->size() < maxLen) *text += ' ';
  if (button(Rect(x + bw * 5.5f + gap * 2, y4, bw * 2.f, bh), "<-", 2) && !text->empty()) text->pop_back();
  if (button(Rect(x + bw * 7.5f + gap * 3, y4, bw * 2.5f, bh), "OK", 1)) done = true;
  return done;
}
}  // namespace cf
