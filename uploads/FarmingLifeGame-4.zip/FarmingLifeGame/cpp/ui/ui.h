// Immediate-mode touch UI toolkit (panels, buttons, lists, sliders, on-screen keyboard).
#pragma once
#include "engine/settings.h"
#include "input/input.h"
#include "items/content.h"
#include "renderer/renderer.h"

namespace cf {
class UI {
 public:
  Renderer* r = nullptr; Input* in = nullptr; const Settings* st = nullptr;
  float dp = 2.f, time = 0, dt = 0;
  int tk = 3, pk = 3;
  Rect safe;                                   // safe area (px)
  void begin(Renderer& rend, Input& input, const Settings& s, float dtSec, Rect safeArea);
  float px(float d) const { return d * dp; }
  int k(int rel = 0) const { return std::max(2, tk + rel); }
  // palette
  u32 ink() const { return st->highContrast ? col::rgba(255, 255, 255) : col::rgba(58, 38, 24); }
  u32 inkSoft() const { return st->highContrast ? col::rgba(200, 200, 215) : col::rgba(110, 82, 58); }
  u32 light() const { return col::rgba(252, 246, 232); }
  u32 good() const { return col::rgba(70, 150, 60); }
  u32 bad() const { return col::rgba(200, 60, 50); }
  u32 gold() const { return col::rgba(240, 190, 40); }
  // drawing
  void panel(const Rect& rc, int style = 0, u32 tint = kWhite);
  void rect(const Rect& rc, u32 c) { r->batch.rect(rc.x, rc.y, rc.w, rc.h, c); }
  void text(const std::string& s, float x, float y, u32 c, int rel = 0, bool shadow = false);
  void textRight(const std::string& s, float xr, float y, u32 c, int rel = 0, bool shadow = false);
  void textCenter(const Rect& rc, const std::string& s, u32 c, int rel = 0, bool shadow = false);
  float textW(const std::string& s, int rel = 0) const { return (float)r->font.textWidth(s, k(rel)); }
  float lineH(int rel = 0) const { return (float)r->font.lineHeight(k(rel)); }
  float paragraph(const Rect& box, const std::string& s, u32 c, int rel = 0, bool shadow = false);   // returns height used
  void icon(const Region& rg, const Rect& box, u32 tint = kWhite);          // integer-scaled, centred
  void stack(const ItemStack& s, const Rect& slot, bool selected = false, bool showCount = true);
  void bar(const Rect& rc, float frac, u32 fill);
  // widgets
  bool button(const Rect& rc, const std::string& label, int style = 0, bool enabled = true);
  bool iconButton(const Rect& rc, const Region& rg, bool enabled = true, u32 tint = kWhite);
  bool tab(const Rect& rc, const std::string& label, bool selected);
  bool toggle(const Rect& rc, const std::string& label, bool* v);
  bool slider(const Rect& rc, const std::string& label, float* v, float lo, float hi);
  bool tapped(const Rect& rc);                  // released inside after pressing inside (no drag)
  bool held(const Rect& rc) const;
  bool slotTapped(const Rect& rc) { return tapped(rc); }
  Pointer* ptr() const { return in->freePointer(); }
  void scrollBegin(const Rect& view, float* scroll, float contentH);
  void scrollEnd();
  bool osk(const Rect& area, std::string* text, size_t maxLen);   // returns true when OK is pressed
  bool blockedByDrag() const { return dragging_; }
 private:
  bool hit(const Rect& rc, const Vec2& p) const { return rc.contains(p) && (!clipOn_ || clip_.contains(p)); }
  bool dragging_ = false, clipOn_ = false;
  Rect clip_;
  bool shift_ = false;
};
}  // namespace cf
