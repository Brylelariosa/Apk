// Dialogue, shop, chest, barn, gift, fishing and festival screens.
#include "animation/animation.h"
#include "game/game.h"

namespace cf {
static Rect centered(Game& g, float w, float h) { Rect sf = g.ui.safe; w = std::min(w, sf.w); h = std::min(h, sf.h); return Rect(sf.x + (sf.w - w) * 0.5f, sf.y + (sf.h - h) * 0.5f, w, h); }

void Game::uiDialogue() {
  Rect sf = ui.safe; float ph = ui.px(124);
  Rect box(sf.x + ui.px(10), sf.bottom() - ph - ui.px(8), sf.w - ui.px(20), ph);
  const Region* por = dlg.portrait.empty() ? nullptr : Sprites::find(dlg.portrait + "_" + dlg.expr);
  std::string full = dlg.page < (int)dlg.pages.size() ? dlg.pages[(size_t)dlg.page] : "";
  dlg.typeT += ui.dt * (settings.reducedMotion ? 9999.f : 55.f);
  int shown = std::min<int>((int)dlg.typeT, (int)full.size());
  bool complete = shown >= (int)full.size();
  bool lastPage = dlg.page + 1 >= (int)dlg.pages.size();
  // choices (right side, above the box)
  if (complete && lastPage && !dlg.choices.empty()) {
    float bw = ui.px(210), bh = ui.px(40), gap = ui.px(6);
    float y = box.y - (float)dlg.choices.size() * (bh + gap) - ui.px(4);
    for (size_t i = 0; i < dlg.choices.size(); ++i) {
      Rect b(box.right() - bw - ui.px(6), y + (float)i * (bh + gap), bw, bh);
      if (ui.button(b, dlg.choices[i], dlg.ids[i] == 4 || dlg.ids[i] == 299 ? 0 : 1)) { int id = dlg.ids[i]; audio->play(Sfx::Click); dialogueChoice(id); return; }
    }
  }
  ui.panel(box, 2);
  float x = box.x + ui.px(14);
  if (por) {
    int sc = std::max(1, (int)((ph - ui.px(24)) / (float)por->h));
    Rect pr(box.x + ui.px(10), box.y + ui.px(8), (float)(por->w * sc) + ui.px(6), (float)(por->h * sc) + ui.px(6));
    ui.panel(pr, 3);
    r->batch.regionRect(*por, pr.x + ui.px(3), pr.y + ui.px(3), (float)(por->w * sc), (float)(por->h * sc));
    x = pr.right() + ui.px(12);
  }
  if (!dlg.speaker.empty()) { ui.text(dlg.speaker, x, box.y + ui.px(8), col::rgba(150, 70, 40), 0); }
  std::vector<std::string> lines; r->font.wrap(full, (int)(box.right() - x - ui.px(14)), ui.k(), lines);
  float y = box.y + ui.px(8) + ui.lineH() + 2; int left = shown;
  for (auto& l : lines) { if (left <= 0) break; ui.text(l.substr(0, (size_t)std::min<int>((int)l.size(), left)), x, y, ui.ink()); left -= (int)l.size() + 1; y += ui.lineH(); }
  if (complete && (!lastPage || dlg.choices.empty() || dlg.mode == 1)) r->batch.regionRect(Sprites::ui.get("ui_arrow_d"), box.right() - ui.px(26), box.bottom() - ui.px(22) + std::sin(ui.time * 6.f) * 2.f, ui.px(14), ui.px(8), col::rgba(150, 70, 40));
  bool tap = false; for (auto& p : in->p) if (p.released && !p.claimed && p.travel < ui.px(14) && box.contains(p.pos) && !ui.blockedByDrag()) tap = true;
  if (tap && stateTime > 0.15f) {
    if (!complete) dlg.typeT = 9999.f;
    else if (!lastPage) { ++dlg.page; dlg.typeT = 0; audio->play(Sfx::Click, 0.4f); }
    else if (dlg.mode == 1 && dlg.ev >= 0) {
      const EventDef& e = C().events[(size_t)dlg.ev]; const NpcDef& d = C().npcs[(size_t)C().npc(e.npc)]; ++dlg.evLine;
      if (dlg.evLine < (int)e.lines.size()) { const auto& ln = e.lines[(size_t)dlg.evLine]; showDialogue(ln.first == "you" ? s.pl.name : d.name, ln.first == "you" ? "" : "por_" + d.id, "neutral", ln.second); }
      else if (!e.answers.empty() && dlg.choices.empty() && dlg.evLine == (int)e.lines.size()) { std::vector<std::pair<int, std::string>> ch; for (size_t i = 0; i < e.answers.size(); ++i) ch.push_back({10 + (int)i, e.answers[i]}); showDialogue(d.name, "por_" + d.id, "neutral", e.question, ch); }
      else { setFlag(e.setFlag); dlg.mode = 0; pop(); }
    } else if (dlg.choices.empty()) pop();
  }
}

void Game::uiGift() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 150));
  Rect p = centered(*this, ui.px(520), ui.px(300)); ui.panel(p, 0);
  const NpcDef& d = C().npcs[(size_t)s.npcs[(size_t)giftNpc].def];
  ui.textCenter(Rect(p.x, p.y + ui.px(8), p.w, ui.lineH(1)), "Give " + d.name + " a gift", ui.ink(), 1);
  float ss = ui.px(44), gap = ui.px(4); int cols = std::max(4, (int)((p.w - ui.px(30)) / (ss + gap)));
  Rect g(p.x + ui.px(14), p.y + ui.px(50), p.w - ui.px(28), p.h - ui.px(110));
  ui.scrollBegin(g, &menu.scroll, (float)((Inventory::kSlots + cols - 1) / cols) * (ss + gap));
  for (int i = 0; i < Inventory::kSlots; ++i) {
    Rect sl(g.x + (float)(i % cols) * (ss + gap), g.y - menu.scroll + (float)(i / cols) * (ss + gap), ss, ss);
    ui.stack(s.pl.inv.slots[(size_t)i], sl);
    if (!s.pl.inv.slots[(size_t)i].empty() && ui.tapped(sl)) { int ni = giftNpc; pop(); giveGift(ni, i); return; }
  }
  ui.scrollEnd();
  if (ui.button(Rect(p.x + (p.w - ui.px(140)) * 0.5f, p.bottom() - ui.px(50), ui.px(140), ui.px(42)), "Cancel")) pop();
}

// ------------------------------------------------------------------------------------------------ shop
void Game::uiShop() {
  const ShopDef& sd = C().shops[(size_t)shopUi.shop]; NpcState* npc = shopUi.npc >= 0 ? &s.npcs[(size_t)shopUi.npc] : nullptr;
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 150));
  Rect p = centered(*this, ui.px(740), ui.px(336)); ui.panel(p, 0);
  ui.text(sd.name, p.x + ui.px(16), p.y + ui.px(10), ui.ink(), 0);
  ui.icon(Sprites::ui.get("ic_coin"), Rect(p.right() - ui.px(150), p.y + ui.px(8), ui.px(20), ui.px(20)));
  ui.text(std::to_string(s.pl.money) + "g", p.right() - ui.px(124), p.y + ui.px(10), ui.ink(), 0);
  std::vector<std::string> tabs{"Buy", "Sell"};
  if (sd.kind == "ranch") tabs = {"Buy", "Animals", "Sell"}; if (sd.kind == "smith") tabs = {"Buy", "Tools", "Build", "Sell"};
  float tw = ui.px(96), ty = p.y + ui.px(40);
  for (size_t i = 0; i < tabs.size(); ++i) if (ui.tab(Rect(p.x + ui.px(14) + (float)i * (tw + 2), ty, tw, ui.px(32)), tabs[i], shopUi.tab == (int)i)) { shopUi.tab = (int)i; shopUi.sel = -1; shopUi.scroll = 0; shopUi.qty = 1; shopUi.note.clear(); }
  if (ui.iconButton(Rect(p.right() - ui.px(48), ty - ui.px(4), ui.px(38), ui.px(36)), Sprites::ui.get("ui_close"))) { pop(); return; }
  std::string tab = shopUi.tab < (int)tabs.size() ? tabs[(size_t)shopUi.tab] : "Buy";
  Rect body(p.x + ui.px(14), ty + ui.px(40), p.w - ui.px(28), p.bottom() - (ty + ui.px(40)) - ui.px(12));
  float lw = body.w * 0.52f; Rect list(body.x, body.y, lw, body.h), det(body.x + lw + ui.px(8), body.y, body.w - lw - ui.px(8), body.h);
  ui.panel(det, 3);
  float rh = ui.px(38), y = list.y - shopUi.scroll;
  int hearts = npc ? npc->hearts() : 0;
  // gather rows
  struct Row { int item = 0; int price = 0; int slot = -1; int idx = 0; std::string label, sub; bool ok = true; };
  std::vector<Row> rows;
  if (tab == "Buy") { int i = 0; for (auto& it : sd.stock) { if (!(it.seasons & (1 << s.cal.season)) || it.minHearts > hearts) continue; Row rw; rw.item = it.item; rw.price = buyPrice(sd, it); rw.idx = i++; rows.push_back(rw); } }
  else if (tab == "Sell") for (int i = 0; i < Inventory::kSlots; ++i) { const ItemStack& st = s.pl.inv.slots[(size_t)i]; if (st.empty()) continue; const ItemDef& d = C().def(st.id); if (d.sell <= 0 || d.cat == Cat::Tool || d.cat == Cat::Quest) continue; Row rw; rw.item = st.id; rw.slot = i; rw.price = sellValue(&sd, st); rw.idx = i; rows.push_back(rw); }
  else if (tab == "Animals") for (auto& an : sd.animals) { int ai = C().animal(an); if (ai < 0) continue; Row rw; rw.idx = ai; rw.price = C().animals[(size_t)ai].price; rw.label = C().animals[(size_t)ai].name; rows.push_back(rw); }
  else if (tab == "Tools") {
    static const ToolType order[] = {ToolType::Hoe, ToolType::Can, ToolType::Axe, ToolType::Pick, ToolType::Rod, ToolType::Hammer, ToolType::Shears};
    for (ToolType t : order) { int sl = s.pl.inv.findTool(t); if (sl < 0) continue; Row rw; rw.slot = sl; rw.idx = (int)t; rw.item = s.pl.inv.slots[(size_t)sl].id; int tier = s.pl.inv.slots[(size_t)sl].tier; for (auto& u : C().toolUps) if (u.tier == tier + 1) rw.price = u.gold; rw.ok = tier < 5; rows.push_back(rw); }
  } else if (tab == "Build") { if (Map* fm = getMap("farm")) for (size_t i = 0; i < fm->buildings.size(); ++i) { const BuildingDef& bd = C().buildings[(size_t)fm->buildings[i].def]; if (bd.levels <= 1) continue; Row rw; rw.idx = (int)i; rw.label = bd.id; rw.ok = fm->buildings[i].level < bd.levels; for (auto& u : C().upgrades) if (u.building == bd.id && u.level == fm->buildings[i].level + 1) rw.price = u.gold; rows.push_back(rw); } }
  ui.scrollBegin(list, &shopUi.scroll, (float)rows.size() * rh);
  for (size_t i = 0; i < rows.size(); ++i) {
    Rect rr(list.x, y + (float)i * rh, list.w - ui.px(4), rh - 3);
    bool selected = shopUi.sel == (int)i; ui.panel(rr, 3, selected ? col::rgba(255, 245, 190) : kWhite);
    std::string name = rows[i].label; ItemStack st; st.id = (u16)rows[i].item;
    if (name.empty()) name = C().def(rows[i].item).name;
    if (tab == "Tools") { st.tier = s.pl.inv.slots[(size_t)rows[i].slot].tier; name += fmt(" (tier %d)", st.tier); }
    if (rows[i].item) ui.icon(C().icon(st), Rect(rr.x + 3, rr.y + 2, rr.h - 4, rr.h - 4));
    else if (tab == "Animals") { const AnimalAnim& aa = animalAnim(C().animals[(size_t)rows[i].idx].art); ui.icon(*aa.idle[0], Rect(rr.x + 3, rr.y + 2, rr.h - 4, rr.h - 4)); }
    ui.text(name, rr.x + rr.h + 2, rr.y + (rr.h - ui.lineH(-1)) * 0.5f, ui.ink(), -1);
    if (rows[i].price > 0 || tab == "Buy") ui.textRight(fmt("%dg", rows[i].price), rr.right() - ui.px(6), rr.y + (rr.h - ui.lineH(-1)) * 0.5f, tab == "Buy" || tab == "Animals" ? (s.pl.money >= rows[i].price ? ui.ink() : ui.bad()) : ui.good(), -1);
    if (ui.tapped(rr)) { shopUi.sel = (int)i; shopUi.qty = 1; shopUi.note.clear(); audio->play(Sfx::Click, 0.5f); }
  }
  ui.scrollEnd();
  if (rows.empty()) ui.paragraph(Rect(list.x + 6, list.y + 6, list.w - 12, 100), tab == "Sell" ? "You have nothing this shop would buy." : "Nothing here right now.", ui.inkSoft(), -1);
  // ---- detail
  float x = det.x + ui.px(12), dy = det.y + ui.px(10), w = det.w - ui.px(24), bh = ui.px(42);
  if (shopUi.sel >= 0 && shopUi.sel < (int)rows.size()) {
    Row& rw = rows[(size_t)shopUi.sel];
    if (tab == "Buy" || tab == "Sell") {
      const ItemDef& d = C().def(rw.item); ItemStack st; st.id = (u16)rw.item;
      if (tab == "Sell") st = s.pl.inv.slots[(size_t)rw.slot];
      ui.icon(C().icon(st), Rect(x, dy, ui.px(40), ui.px(40)));
      ui.text(d.name, x + ui.px(48), dy + ui.px(10), ui.ink()); dy += ui.px(48);
      dy += ui.paragraph(Rect(x, dy, w, 120), d.desc, ui.inkSoft(), -1) + ui.px(6);
      int maxQ = tab == "Sell" ? st.count : 99; shopUi.qty = clampv(shopUi.qty, 1, std::max(1, maxQ));
      ui.text("Quantity", x, dy + ui.px(10), ui.ink(), -1);
      float qb = ui.px(40); Rect m1(x + ui.px(86), dy, qb, qb), qt(x + ui.px(86) + qb + ui.px(40), dy, ui.px(50), qb), p1(x + ui.px(86) + qb + ui.px(94), dy, qb, qb);
      if (ui.button(m1, "-")) shopUi.qty = std::max(1, shopUi.qty - 1); ui.textCenter(qt, std::to_string(shopUi.qty), ui.ink()); if (ui.button(p1, "+")) shopUi.qty = std::min(maxQ, shopUi.qty + 1);
      if (ui.button(Rect(p1.right() + ui.px(4), dy, qb + ui.px(8), qb), "x10")) shopUi.qty = std::min(maxQ, shopUi.qty + 10);
      dy += qb + ui.px(8);
      int total = rw.price * shopUi.qty; ui.text(fmt("Total: %dg", total), x, dy, ui.ink(), 0);
      Rect bb(x, det.bottom() - bh - ui.px(10), w, bh);
      if (tab == "Buy") {
        ItemStack bst; bst.id = (u16)rw.item; bst.count = (u16)shopUi.qty;
        if (ui.button(bb, "Buy", 1, s.pl.money >= total && s.pl.inv.canAdd(bst))) { s.pl.money -= total; giveItem(bst); audio->play(Sfx::Coin); shopUi.note = "Thank you!"; s.counters["spent"] += total; }
      } else if (ui.button(bb, "Sell", 1)) {
        ItemStack& slot = s.pl.inv.slots[(size_t)rw.slot]; int n = std::min<int>(shopUi.qty, slot.count);
        addMoney(rw.price * n); slot.count = (u16)(slot.count - n); if (!slot.count) { slot = ItemStack(); shopUi.sel = -1; } audio->play(Sfx::Coin); emitEvent("sell", C().def(rw.item).id, n);
      }
    } else if (tab == "Animals") {
      const AnimalDef& ad = C().animals[(size_t)rw.idx]; Map* fm = getMap("farm"); int fb = -1;
      if (fm) for (size_t i = 0; i < fm->buildings.size(); ++i) if (C().buildings[(size_t)fm->buildings[i].def].animals == ad.home) fb = (int)i;
      ui.text(ad.name, x, dy, ui.ink()); dy += ui.lineH() + 4;
      dy += ui.paragraph(Rect(x, dy, w, 150), fmt("Lives in the %s. Produces %s every %d day%s once grown (%d days). Keep it fed and happy for better quality!", ad.home.c_str(), C().def(ad.product).name.c_str(), ad.interval, ad.interval > 1 ? "s" : "", ad.adult), ui.inkSoft(), -1);
      if (fb >= 0) ui.text(fmt("%s space: %d/%d", ad.home.c_str(), animalsInBuilding(fb), buildingCapacity(fb)), x, dy + 4, ui.ink(), -1);
      if (ui.button(Rect(x, det.bottom() - bh - ui.px(10), w, bh), fmt("Buy for %dg", ad.price), 1, fb >= 0 && s.pl.money >= ad.price && animalsInBuilding(fb) < buildingCapacity(fb))) { if (buyAnimal(rw.idx, fb)) shopUi.note = "Welcome home!"; }
    } else if (tab == "Tools") {
      ItemStack& st = s.pl.inv.slots[(size_t)rw.slot]; const ToolUpDef* up = nullptr; for (auto& u : C().toolUps) if (u.tier == st.tier + 1) up = &u;
      ui.text(C().def(st.id).name, x, dy, ui.ink()); dy += ui.lineH() + 4;
      if (up) {
        ui.text(fmt("Upgrade to tier %d  (%d days)", up->tier, up->days), x, dy, ui.inkSoft(), -1); dy += ui.lineH(-1) + 6;
        ui.text(fmt("%dg", up->gold), x, dy, s.pl.money >= up->gold ? ui.ink() : ui.bad(), -1); dy += ui.lineH(-1) + 4;
        float yy = dy; for (auto& ing : up->in) { int have = s.pl.inv.count(ing.item); ui.text(fmt("%s %d/%d", C().def(ing.item).name.c_str(), have, ing.count), x, yy, have >= ing.count ? ui.good() : ui.bad(), -1); yy += ui.lineH(-1) + 3; }
        bool pend = false; for (auto& pu : s.pending) if (pu.kind == 0 && pu.a == rw.idx) pend = true;
        bool ok = !pend && s.pl.money >= up->gold && s.pl.inv.has(up->in);
        if (ui.button(Rect(x, det.bottom() - bh - ui.px(10), w, bh), pend ? "In progress" : "Upgrade", 1, ok)) {
          s.pl.money -= up->gold; s.pl.inv.take(up->in); PendingUp pu; pu.kind = 0; pu.a = rw.idx; pu.b = st.tier + 1; pu.days = up->days; s.pending.push_back(pu);
          st = ItemStack(); audio->play(Sfx::Coin); shopUi.note = fmt("Bram will have it ready in %d days.", up->days); shopUi.sel = -1;
        }
      } else ui.text("Fully upgraded!", x, dy, ui.good());
    } else if (tab == "Build") {
      Map* fm = getMap("farm"); BuildingInst& bi = fm->buildings[(size_t)rw.idx]; const BuildingDef& bd = C().buildings[(size_t)bi.def];
      ui.text(fmt("%s (level %d)", bd.id.c_str(), bi.level), x, dy, ui.ink()); dy += ui.lineH() + 4;
      const UpgradeDef* up = nullptr; for (auto& u : C().upgrades) if (u.building == bd.id && u.level == bi.level + 1) up = &u;
      if (up) {
        ui.text(fmt("Level %d - %d days of work", up->level, up->days), x, dy, ui.inkSoft(), -1); dy += ui.lineH(-1) + 6;
        ui.text(fmt("%dg", up->gold), x, dy, s.pl.money >= up->gold ? ui.ink() : ui.bad(), -1); dy += ui.lineH(-1) + 4;
        float yy = dy; for (auto& ing : up->in) { int have = s.pl.inv.count(ing.item); ui.text(fmt("%s %d/%d", C().def(ing.item).name.c_str(), have, ing.count), x, yy, have >= ing.count ? ui.good() : ui.bad(), -1); yy += ui.lineH(-1) + 3; }
        bool pend = false; for (auto& pu : s.pending) if (pu.kind == 1 && pu.a == rw.idx) pend = true;
        if (ui.button(Rect(x, det.bottom() - bh - ui.px(10), w, bh), pend ? "Under construction" : "Order upgrade", 1, !pend && s.pl.money >= up->gold && s.pl.inv.has(up->in))) {
          s.pl.money -= up->gold; s.pl.inv.take(up->in); PendingUp pu; pu.kind = 1; pu.a = rw.idx; pu.b = up->level; pu.days = up->days; s.pending.push_back(pu); bi.buildDays = up->days; audio->play(Sfx::Coin); shopUi.note = "Bram's crew gets to work!";
        }
      } else ui.text("Fully upgraded!", x, dy, ui.good());
    }
  } else ui.paragraph(Rect(x, dy, w, 200), tab == "Tools" ? "Choose a tool to upgrade. Bram keeps it for a couple of days, then it returns stronger." : (tab == "Build" ? "Barn, coop and farmhouse upgrades add room and comfort." : "Pick something from the list."), ui.inkSoft(), -1);
  if (!shopUi.note.empty()) ui.text(shopUi.note, det.x + ui.px(12), det.bottom() - bh - ui.px(34), ui.good(), -1);
}

// ------------------------------------------------------------------------------------------------ chest / shipping bin
void Game::uiChest() {
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 150));
  Rect p = centered(*this, ui.px(640), ui.px(336)); ui.panel(p, 0);
  Map& m = map(); ChestData* cd = nullptr;
  if (!chestUi.bin && chestUi.obj >= 0 && chestUi.obj < (int)m.objs.size()) { MapObject& o = m.objs[(size_t)chestUi.obj]; if (o.aux < m.chests.size()) { cd = &m.chests[o.aux]; if (cd->slots.size() < 24) cd->slots.resize(24); } }
  ui.text(chestUi.bin ? "Shipping bin - sold at dawn" : "Chest", p.x + ui.px(14), p.y + ui.px(10), ui.ink());
  if (ui.iconButton(Rect(p.right() - ui.px(48), p.y + ui.px(6), ui.px(38), ui.px(34)), Sprites::ui.get("ui_close"))) { pop(); return; }
  float ss = std::min(ui.px(42), (p.w - ui.px(40)) / 12.f - 4.f), gap = ui.px(4); int cols = 12;
  float y = p.y + ui.px(46);
  int total = 0;
  if (chestUi.bin) {
    for (auto& st : s.bin) total += sellPrice(st) * st.count;
    ui.text(fmt("Value: %dg", total), p.right() - ui.px(190), p.y + ui.px(12), ui.good(), -1);
    for (size_t i = 0; i < 24; ++i) {
      Rect sl(p.x + ui.px(14) + (float)(i % (size_t)cols) * (ss + gap), y + (float)(i / (size_t)cols) * (ss + gap), ss, ss);
      ItemStack st = i < s.bin.size() ? s.bin[i] : ItemStack(); ui.stack(st, sl);
      if (i < s.bin.size() && ui.tapped(sl)) { ItemStack back = s.bin[i]; if (s.pl.inv.canAdd(back)) { s.pl.inv.add(back); s.bin.erase(s.bin.begin() + (long)i); audio->play(Sfx::Pop, 0.6f); } break; }
    }
  } else if (cd) {
    for (int i = 0; i < 24; ++i) {
      Rect sl(p.x + ui.px(14) + (float)(i % cols) * (ss + gap), y + (float)(i / cols) * (ss + gap), ss, ss);
      ui.stack(cd->slots[(size_t)i], sl);
      if (!cd->slots[(size_t)i].empty() && ui.tapped(sl)) { ItemStack st = cd->slots[(size_t)i]; if (s.pl.inv.canAdd(st)) { s.pl.inv.add(st); cd->slots[(size_t)i] = ItemStack(); audio->play(Sfx::Pop, 0.6f); } }
    }
  }
  float y2 = y + 2 * (ss + gap) + ui.px(16);
  ui.text("Your pack (tap to move)", p.x + ui.px(14), y2, ui.inkSoft(), -1); y2 += ui.lineH(-1) + 4;
  for (int i = 0; i < Inventory::kSlots; ++i) {
    Rect sl(p.x + ui.px(14) + (float)(i % cols) * (ss + gap), y2 + (float)(i / cols) * (ss + gap), ss, ss);
    ItemStack& st = s.pl.inv.slots[(size_t)i]; ui.stack(st, sl, i == s.pl.sel);
    if (st.empty() || !ui.tapped(sl)) continue;
    const ItemDef& d = C().def(st.id);
    if (chestUi.bin) {
      if (d.sell <= 0 || d.cat == Cat::Tool || d.cat == Cat::Quest) { toast("That can't be sold."); continue; }
      bool merged = false; for (auto& b : s.bin) if (b == st) { b.count = (u16)(b.count + st.count); merged = true; break; }
      if (!merged) { if (s.bin.size() >= 24) { toast("The bin is full."); continue; } s.bin.push_back(st); }
      st = ItemStack(); audio->play(Sfx::Pop, 0.6f);
    } else if (cd) {
      if (d.cat == Cat::Tool && false) continue;
      bool placed = false;
      for (auto& sl2 : cd->slots) if (!sl2.empty() && sl2 == st && sl2.count + st.count <= 99) { sl2.count = (u16)(sl2.count + st.count); placed = true; break; }
      if (!placed) for (auto& sl2 : cd->slots) if (sl2.empty()) { sl2 = st; placed = true; break; }
      if (placed) { st = ItemStack(); audio->play(Sfx::Pop, 0.6f); } else toast("The chest is full.");
    }
  }
}

// ------------------------------------------------------------------------------------------------ barn / coop
void Game::uiAnimals() {
  Map* fm = getMap("farm");
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 150));
  Rect p = centered(*this, ui.px(620), ui.px(336)); ui.panel(p, 0);
  if (!fm || animalUi.building < 0 || animalUi.building >= (int)fm->buildings.size()) { pop(); return; }
  BuildingInst& b = fm->buildings[(size_t)animalUi.building]; const BuildingDef& bd = C().buildings[(size_t)b.def];
  ui.text(fmt("%s (level %d)  %d/%d animals", bd.animals == "barn" ? "Barn" : "Coop", b.level, animalsInBuilding(animalUi.building), buildingCapacity(animalUi.building)), p.x + ui.px(14), p.y + ui.px(10), ui.ink());
  if (ui.iconButton(Rect(p.right() - ui.px(48), p.y + ui.px(6), ui.px(38), ui.px(34)), Sprites::ui.get("ui_close"))) { pop(); return; }
  float y = p.y + ui.px(44);
  int slot = -1; for (int i = 0; i < Inventory::kSlots; ++i) if (C().def(s.pl.inv.slots[(size_t)i].id).cat == Cat::Feed && !s.pl.inv.slots[(size_t)i].empty()) { slot = i; break; }
  ui.icon(Sprites::ui.get("item_hay"), Rect(p.x + ui.px(14), y, ui.px(30), ui.px(30)));
  ui.text(fmt("Trough: %d hay (animals eat 1 each night)", hayStock[animalUi.building]), p.x + ui.px(50), y + ui.px(8), ui.ink(), -1);
  float bw = ui.px(84), bh = ui.px(34);
  if (ui.button(Rect(p.right() - bw * 2 - ui.px(20), y, bw, bh), "+1 hay", 0, slot >= 0)) { s.pl.inv.slots[(size_t)slot].count--; if (!s.pl.inv.slots[(size_t)slot].count) s.pl.inv.slots[(size_t)slot] = ItemStack(); hayStock[animalUi.building]++; audio->play(Sfx::Pop, 0.6f); }
  if (ui.button(Rect(p.right() - bw - ui.px(12), y, bw, bh), "+10 hay", 0, slot >= 0)) { for (int k = 0; k < 10; ++k) { int sl = -1; for (int i = 0; i < Inventory::kSlots; ++i) if (!s.pl.inv.slots[(size_t)i].empty() && C().def(s.pl.inv.slots[(size_t)i].id).cat == Cat::Feed) { sl = i; break; } if (sl < 0) break; if (--s.pl.inv.slots[(size_t)sl].count == 0) s.pl.inv.slots[(size_t)sl] = ItemStack(); hayStock[animalUi.building]++; } audio->play(Sfx::Pop, 0.6f); }
  y += ui.px(44);
  Rect list(p.x + ui.px(14), y, p.w - ui.px(28), p.bottom() - y - ui.px(12)); float rh = ui.px(46); int n = 0;
  ui.scrollBegin(list, &animalUi.scroll, (float)animalsInBuilding(animalUi.building) * rh);
  float yy = list.y - animalUi.scroll;
  for (size_t i = 0; i < s.animals.size(); ++i) {
    AnimalState& a = s.animals[i]; if (a.building != animalUi.building) continue;
    const AnimalDef& d = C().animals[(size_t)a.def]; Rect rr(list.x, yy + (float)n * rh, list.w - ui.px(4), rh - 4); ++n;
    ui.panel(rr, 3); ui.icon(*animalAnim(d.art).idle[0], Rect(rr.x + 4, rr.y + 3, rr.h - 6, rr.h - 6));
    ui.text(fmt("%s the %s%s", a.name.c_str(), d.name.c_str(), a.age < d.adult ? " (young)" : ""), rr.x + rr.h + 4, rr.y + ui.px(4), ui.ink(), -1);
    float bx = rr.x + rr.h + 4, by = rr.y + ui.px(4) + ui.lineH(-1) + 2, bw2 = ui.px(70);
    ui.bar(Rect(bx, by, bw2, ui.px(8)), a.hunger / 100.f, col::rgba(240, 170, 60)); ui.bar(Rect(bx + bw2 + 6, by, bw2, ui.px(8)), a.happiness / 100.f, col::rgba(240, 100, 150)); ui.bar(Rect(bx + (bw2 + 6) * 2, by, bw2, ui.px(8)), a.affection / 1000.f, col::rgba(230, 70, 80));
    ui.text("fed / happy / bond", bx + (bw2 + 6) * 3, by - 2, ui.inkSoft(), -2);
    if (a.product) { ui.icon(C().icon([&] { ItemStack st; st.id = (u16)d.product; return st; }()), Rect(rr.right() - ui.px(40), rr.y + 3, rr.h - 6, rr.h - 6)); }
  }
  ui.scrollEnd();
  if (n == 0) ui.text("No animals yet. Visit Hazel's ranch in the village!", list.x + 4, list.y + 4, ui.inkSoft(), -1);
}

// ------------------------------------------------------------------------------------------------ fishing minigame
void Game::uiFishing() {
  Rect sf = ui.safe;
  if (fg.phase == 1 || fg.phase == 2) {
    ui.rect(Rect(0, 0, (float)r->screenW, ui.px(48)), col::rgba(0, 0, 0, 120));
    ui.textCenter(Rect(0, 0, (float)r->screenW, ui.px(48)), fg.phase == 1 ? "Waiting for a bite..." : "A bite! Tap now!", fg.phase == 2 ? col::rgba(255, 240, 120) : kWhite, 1, true);
    if (fg.phase == 2) { float sz = ui.px(60) + std::sin(ui.time * 20.f) * ui.px(4); r->batch.regionRect(Sprites::ui.get("fx_exclaim"), (float)r->screenW * 0.5f - sz * 0.5f, sf.y + sf.h * 0.25f, sz, sz * 1.3f); }
  }
  if (fg.phase == 3) {
    Rect trk(sf.right() - ui.px(110), sf.y + ui.px(30), ui.px(48), sf.h - ui.px(90));
    ui.panel(trk.inset(-ui.px(8)), 1);
    r->batch.rect(trk.x, trk.y, trk.w, trk.h, col::rgba(40, 90, 140, 220));
    float zh = trk.h * fg.size, zy = trk.bottom() - fg.bar * trk.h - zh * 0.5f;
    r->batch.rect(trk.x, zy, trk.w, zh, col::rgba(120, 230, 120, 190));
    float fy = trk.bottom() - fg.fishPos * trk.h;
    ItemStack st; st.id = (u16)fg.fishItem; ui.icon(C().icon(st), Rect(trk.x + 2, fy - trk.w * 0.5f, trk.w - 4, trk.w - 4));
    Rect pb(trk.right() + ui.px(10), trk.y, ui.px(14), trk.h); r->batch.rect(pb.x, pb.y, pb.w, pb.h, col::rgba(20, 20, 30, 200));
    r->batch.rect(pb.x + 2, pb.bottom() - pb.h * clampv(fg.progress, 0.f, 1.f), pb.w - 4, pb.h * clampv(fg.progress, 0.f, 1.f), fg.progress > 0.66f ? col::rgba(100, 220, 100) : (fg.progress > 0.33f ? col::rgba(240, 210, 80) : col::rgba(230, 90, 70)));
    ui.text("Hold anywhere to raise the bar", sf.x + ui.px(12), sf.bottom() - ui.px(34), kWhite, 0, true);
  }
  if (fg.phase == 4) {
    Rect p = centered(*this, ui.px(260), ui.px(120)); ui.panel(p, 2);
    ItemStack st; st.id = (u16)fg.fishItem; ui.icon(C().icon(st), Rect(p.x + ui.px(14), p.y + ui.px(24), ui.px(60), ui.px(60)));
    ui.text(fg.progress >= 1.f && C().def(fg.fishItem).cat != Cat::Fish ? "You hooked..." : "You caught", p.x + ui.px(86), p.y + ui.px(24), ui.inkSoft(), -1);
    ui.paragraph(Rect(p.x + ui.px(86), p.y + ui.px(24) + ui.lineH(-1) + 4, p.w - ui.px(96), 60), C().def(fg.fishItem).name + "!", ui.ink(), 0);
  }
  // reel in early / cancel
  Rect cb(sf.x + ui.px(10), sf.y + ui.px(56), ui.px(100), ui.px(38));
  if ((fg.phase == 1) && ui.button(cb, "Reel in", 2)) { s.pl.animKind = 0; fg.phase = 0; pop(); return; }
  for (auto& q : in->p) if (q.pressed && !q.claimed && !cb.contains(q.pos)) actionPressed = true;
}

// ------------------------------------------------------------------------------------------------ festivals
void Game::startFestivalActivity() {
  const FestivalDef* f = todaysFestival(); if (!f) return;
  std::string done = fmt("fest_%s_y%d", f->id.c_str(), s.cal.year);
  if (flag(done)) { showDialogue("Festival", "", "", "You've already taken part today. Enjoy the festival!"); return; }
  festivalId = f->id; festScore = 0; festRound = 0; festT = 0; festMark = 0; festResult.clear();
  if (f->activity == "flowerhunt") {
    festPickups.clear(); Map& m = map(); const MapRegion* pl = m.region("plaza");
    for (int tries = 0; tries < 400 && festPickups.size() < 14; ++tries) {
      int x = pl ? rng.range(pl->x - 6, pl->x + pl->w + 6) : rng.range(8, 40), y = pl ? rng.range(pl->y - 4, pl->y + pl->h + 6) : rng.range(8, 30);
      if (m.walkableTile(x, y) && m.objectAt(x, y) < 0) festPickups.push_back(tileCenter(x, y));
    }
    festivalState = 2; festT = 70.f; toast("Collect as many blossoms as you can!", "item_daffodil");
  } else { festivalState = 1; push(St::Festival); }
}

void Game::updateFestival(float dt) {
  festT -= dt;
  for (size_t i = 0; i < festPickups.size();) {
    if ((festPickups[i] - s.pl.pos).len() < 11.f) { for (int k = 0; k < 4; ++k) fx.emit(Fx::Sparkle, festPickups[i].x, festPickups[i].y - 6, rng.rangef(-18, 18), rng.rangef(-30, -5), 0.6f); festPickups.erase(festPickups.begin() + (long)i); ++festScore; audio->play(Sfx::Pick); }
    else ++i;
  }
  if (festT <= 0 || festPickups.empty()) { festPickups.clear(); festivalState = 3; festPrize = 100 + festScore * 45; push(St::Festival); }
}

void Game::finishFestival() {
  const FestivalDef* f = todaysFestival(); if (!f) { festivalState = 0; return; }
  setFlag(fmt("fest_%s_y%d", f->id.c_str(), s.cal.year)); addMoney(festPrize);
  if (!f->prizeItem.empty() && festScore >= 5) { ItemStack st; st.id = (u16)C().item(f->prizeItem); st.count = 1; if (st.id) giveItem(st); }
  for (auto& n : s.npcs) if (n.map == "village") addFriendship(n, 10);
  emitEvent("festival", f->id); festivalState = 0; festivalId.clear();
}

void Game::uiFestival() {
  const FestivalDef* f = todaysFestival(); if (!f) { pop(); festivalState = 0; return; }
  ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 24, 130));
  Rect p = centered(*this, ui.px(500), ui.px(300)); ui.panel(p, 2);
  ui.textCenter(Rect(p.x, p.y + ui.px(8), p.w, ui.lineH(1)), f->name, ui.ink(), 1);
  float bw = ui.px(170), bh = ui.px(44);
  if (festivalState == 3) {
    ui.paragraph(Rect(p.x + ui.px(24), p.y + ui.px(56), p.w - ui.px(48), 160), festResult.empty() ? fmt("Time's up! You collected %d blossoms.\nPrize: %dg%s", festScore, festPrize, festScore >= 5 && !f->prizeItem.empty() ? " and a special gift!" : "") : festResult, ui.ink());
    if (ui.button(Rect(p.x + (p.w - bw) * 0.5f, p.bottom() - bh - ui.px(12), bw, bh), "Collect prize", 1)) { finishFestival(); pop(); audio->play(Sfx::Coin); }
    return;
  }
  if (f->activity == "lanterns") {
    ui.paragraph(Rect(p.x + ui.px(24), p.y + ui.px(48), p.w - ui.px(48), 60), "Release the paper lanterns! Tap when the glowing marker is in the golden zone. Eight lanterns - the closer, the brighter!", ui.ink(), -1);
    Rect bar(p.x + ui.px(30), p.y + ui.px(130), p.w - ui.px(60), ui.px(36)); r->batch.rect(bar.x, bar.y, bar.w, bar.h, col::rgba(40, 30, 70, 230));
    float zone = 0.14f - 0.006f * (float)festRound; r->batch.rect(bar.x + bar.w * (0.5f - zone * 0.5f), bar.y, bar.w * zone, bar.h, col::rgba(250, 210, 80, 230));
    festT += ui.dt * (1.1f + 0.14f * (float)festRound); float mk = std::fabs(std::fmod(festT, 2.f) - 1.f);
    r->batch.rect(bar.x + bar.w * mk - 3, bar.y - 6, 6, bar.h + 12, kWhite);
    ui.text(fmt("Lantern %d / 8   score %d", std::min(festRound + 1, 8), festScore), p.x + ui.px(30), bar.bottom() + ui.px(12), ui.ink());
    if (ui.button(Rect(p.x + (p.w - bw) * 0.5f, p.bottom() - bh - ui.px(12), bw, bh), "Release!", 1)) {
      float acc = 1.f - std::min(1.f, std::fabs(mk - 0.5f) / 0.5f); if (std::fabs(mk - 0.5f) < zone * 0.5f) acc = 1.f; festScore += (int)(acc * 10.f); ++festRound; audio->play(acc > 0.9f ? Sfx::Chime : Sfx::Click);
      for (int i = 0; i < 6; ++i) fx.emit(Fx::Sparkle, s.pl.pos.x + rng.rangef(-20, 20), s.pl.pos.y - 30, rng.rangef(-10, 10), -20, 0.8f);
      if (festRound >= 8) { festivalState = 3; festPrize = 80 + festScore * 7; festResult = fmt("All lanterns are floating up!\nScore: %d / 80\nPrize: %dg", festScore, festPrize); }
    }
  } else if (f->activity == "fair") {
    ui.paragraph(Rect(p.x + ui.px(24), p.y + ui.px(44), p.w - ui.px(48), 50), "Enter your finest produce, goods or catch! Higher value and quality impress the judge.", ui.ink(), -1);
    float ss = ui.px(40), gap = ui.px(4); int cols = std::max(6, (int)((p.w - ui.px(40)) / (ss + gap)));
    Rect g(p.x + ui.px(20), p.y + ui.px(100), p.w - ui.px(40), p.h - ui.px(150));
    ui.scrollBegin(g, &menu.scroll, (float)((Inventory::kSlots + cols - 1) / cols) * (ss + gap));
    for (int i = 0; i < Inventory::kSlots; ++i) {
      Rect sl(g.x + (float)(i % cols) * (ss + gap), g.y - menu.scroll + (float)(i / cols) * (ss + gap), ss, ss);
      ItemStack& st = s.pl.inv.slots[(size_t)i]; ui.stack(st, sl);
      Cat c = C().def(st.id).cat;
      if (!st.empty() && (c == Cat::Crop || c == Cat::Product || c == Cat::Artisan || c == Cat::Fish || c == Cat::Food) && ui.tapped(sl)) {
        int v = sellPrice(st) + rng.range(-15, 25); festScore = v;
        festPrize = v >= 220 ? 700 : (v >= 110 ? 350 : 120); const char* place = v >= 220 ? "FIRST place" : (v >= 110 ? "second place" : "third place");
        festResult = fmt("The judge examines your %s...\n%s! Prize: %dg", C().def(st.id).name.c_str(), place, festPrize); if (--st.count == 0) st = ItemStack();
        festivalState = 3; audio->play(Sfx::Chime);
      }
    }
    ui.scrollEnd();
  }
  if (ui.button(Rect(p.x + ui.px(12), p.bottom() - bh - ui.px(12), ui.px(90), bh), "Leave", 2)) { festivalState = 0; pop(); }
}
}  // namespace cf
