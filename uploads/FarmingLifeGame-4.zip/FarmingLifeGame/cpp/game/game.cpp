// Game lifecycle: state dispatch, fixed update, time/day cycle, inventory helpers, toasts, new game.
#include "engine/log.h"
#include "game/game.h"
#include "save/save.h"

namespace cf {

static std::string settingsPath() { return platform().dataDir() + "/settings.cfg"; }

bool Game::init() {
  if (!g_content.load()) { CF_LOGE("content failed to load"); return false; }
  if (FILE* f = fopen(settingsPath().c_str(), "rb")) {
    std::string txt; char buf[512]; size_t n; while ((n = fread(buf, 1, sizeof buf, f)) > 0) txt.append(buf, n); fclose(f);
    settings.parse(txt);
  } else settings.applyPreset(Gfx::Balanced);
  stack.clear(); stack.push_back(St::MainMenu);
  hasSession = false;
  return true;
}

void Game::saveSettings() {
  FILE* f = fopen((settingsPath() + ".tmp").c_str(), "wb"); if (!f) return;
  std::string t = settings.serialize(); fwrite(t.data(), 1, t.size(), f); fclose(f);
  rename((settingsPath() + ".tmp").c_str(), settingsPath().c_str());
}

void Game::toast(const std::string& text, const std::string& icon) {
  for (auto& t : toasts) if (t.text == text) { t.t = 0; return; }
  Toast t; t.text = text; t.icon = icon; toasts.push_back(t);
  if (toasts.size() > 5) toasts.erase(toasts.begin());
}

void Game::giveItem(ItemStack st, bool showToast) {
  if (st.empty()) return;
  const ItemDef& d = C().def(st.id);
  int n = st.count;
  int left = s.pl.inv.add(st);
  if (left > 0) { toast("Inventory full! Some items were lost.", "ic_lock"); audio->play(Sfx::Error); }
  if (showToast && n - left > 0) toast(fmt("+%d %s", n - left, d.name.c_str()), "item_" + d.id + (d.cat == Cat::Tool ? "_0" : ""));
  s.seenItems.insert(d.id);
  emitEvent("have", d.id, 0);
}

void Game::addXp(int skill, int n) {
  int before = s.pl.level(skill); s.pl.xp[skill] += n;
  if (s.pl.level(skill) > before) {
    static const char* nm[4] = {"Farming", "Mining", "Fishing", "Foraging"};
    toast(fmt("%s level %d!", nm[skill], s.pl.level(skill)), "ic_star"); audio->play(Sfx::Chime);
  }
}

void Game::onPause() {
  if (audio) audio->setPaused(true);
  if (hasSession && (top() == St::Gameplay || top() == St::Menu || top() == St::Pause || top() == St::Shop || top() == St::Chest || top() == St::Settings || top() == St::Animals)) saveGame(true);
}
void Game::onResume() { if (audio) audio->setPaused(false); if (in) in->releaseAll(); moveStick[0] = moveStick[1] = 0; actionHeld = false; }

Rect Game::contentRect() const {
  float m = ui.px(8);
  return Rect(safe.x + m, safe.y + m, safe.w - 2 * m, safe.h - 2 * m);
}

void Game::newGame(const std::string& name, int look) {
  fx.clear(); toasts.clear(); stack.clear();
  s = Session(); hasSession = true;
  s.seed = (int)(platform().nowSeconds() * 1000.0) ^ 0x5bd1e995;
  Rng wr((u64)s.seed);
  s.wx.today = Weather::Sunny; s.wx.tomorrow = rollWeather(wr, 0, 2);
  Player& p = s.pl; p.name = name.empty() ? "Sprout" : name; p.look = look; p.money = 800;
  static const char* tools[] = {"hoe", "can", "axe", "pick", "rod", "hammer", "shears"};
  for (const char* t : tools) { ItemStack st; st.id = (u16)C().item(t); st.count = 1; st.aux = (u16)(std::string(t) == "can" ? 20 : 0); p.inv.add(st); }
  auto give = [&](const char* id, int n) { ItemStack st; st.id = (u16)C().item(id); st.count = (u16)n; p.inv.add(st); };
  give("seed_turnip", 12); give("bread", 3); give("fertilizer", 3);
  p.sel = 7;
  for (int i = 0; i < 3; ++i) hayStock[i] = 0;
  getMap("farm");
  initNpcs();
  enterMap("farm", "spawn", false);
  cam.snap(p.pos);
  npcMinute(); updateQuests(); setFlag("started");
  setRoot(St::Gameplay);
  msg.title = "Welcome to Thistledown Vale";
  msg.text = "Your great-aunt Odalys left you her little farm at the edge of a quiet valley.\n\nThe village is a short walk east. Clear the fields, plant your first seeds, meet the neighbours - and ask around about the old Great Lantern in the village square. Nobody remembers when it last shone.";
  msg.back = St::Gameplay; push(St::Message);
}

// ------------------------------------------------------------------------------------------------ day cycle
void Game::newDay(bool passedOut) {
  summary = DaySummaryData(); summary.passedOut = passedOut;
  Player& p = s.pl;
  // 1) shipping bin pays out
  for (auto& st : s.bin) { int v = sellPrice(st) * st.count; summary.sold.push_back({st, v}); summary.total += v; s.counters["shipped"] += st.count; }
  s.bin.clear();
  if (summary.total > 0) addMoney(summary.total);
  // 2) overnight work
  int night = (1440 + kDayStart) - s.cal.minutes; if (night < 60) night = 360;
  tickMachines(night);
  for (auto& kv : s.maps) if (kv.second->mineFloor == 0) growCrops(*kv.second, false);
  animalsNewDay();
  crowsAttack();
  // 3) calendar and weather
  bool seasonChanged = s.cal.nextDay();
  Rng wr((u64)Rng::hash((u32)s.seed, (u32)s.cal.totalDays(), 99));
  s.wx.today = s.wx.tomorrow; s.wx.tomorrow = rollWeather(wr, s.cal.season, s.cal.totalDays() + 1);
  if (todaysFestival()) s.wx.today = Weather::Sunny;
  s.wx.intensity = 0;
  if (seasonChanged) {
    for (auto& kv : s.maps) witherCrops(*kv.second);
    summary.notes.push_back(fmt("A new season begins: %s! Crops that dislike it have withered.", Calendar::seasonName(s.cal.season)));
  }
  // 4) construction and tool upgrades
  for (size_t i = 0; i < s.pending.size();) {
    PendingUp& u = s.pending[i];
    if (--u.days > 0) { ++i; continue; }
    if (u.kind == 0) {
      static const char* tn[] = {"", "hoe", "can", "axe", "pick", "rod", "hammer", "shears"};
      ItemStack st; st.id = (u16)C().item(tn[u.a]); st.count = 1; st.tier = (u8)u.b;
      if (st.id == C().item("can")) { static const int cap[6] = {20, 35, 50, 70, 90, 120}; st.aux = (u16)cap[clampv(u.b, 0, 5)]; }
      if (p.inv.add(st)) { Map* fm = getMap("farm"); (void)fm; }
      summary.notes.push_back(fmt("Bram finished upgrading your %s!", C().def(st.id).name.c_str()));
    } else if (Map* fm = getMap("farm")) {
      if (u.a >= 0 && u.a < (int)fm->buildings.size()) {
        fm->buildings[(size_t)u.a].level = u.b; fm->buildings[(size_t)u.a].buildDays = 0;
        const BuildingDef& bd = C().buildings[(size_t)fm->buildings[(size_t)u.a].def];
        summary.notes.push_back(fmt("Your %s was upgraded to level %d!", bd.id.c_str(), u.b));
        if (bd.id == "farmhouse") { s.farmhouseLevel = u.b; Map* old = s.maps.count("house") ? s.maps["house"].get() : nullptr; std::vector<ChestData> keep; if (old) keep = old->chests; s.maps.erase("house"); Map* nh = getMap("house"); if (nh && !keep.empty() && !nh->chests.empty()) nh->chests[0] = keep[0]; }
      }
    }
    s.pending.erase(s.pending.begin() + (long)i);
  }
  // 5) morning
  if (isRainy(s.wx.today)) waterAllRain();
  sprinklersWater();
  for (auto it = s.maps.begin(); it != s.maps.end();) { if (it->second->mineFloor > 0) it = s.maps.erase(it); else ++it; }
  for (auto& kv : s.maps) populateMap(*kv.second);
  // 6) villagers
  bool monday = s.cal.dayOfWeek() == 0;
  for (auto& n : s.npcs) {
    n.talked = false; n.gifted = false; if (monday) n.giftsWeek = 0;
    n.schedIdx = -2; n.traveling = false; n.hasTarget = false; n.path.clear();
    const NpcDef& d = C().npcs[(size_t)n.def];
    for (auto& e : d.sched) if (e.act == "inside") { n.map = e.map; if (Map* m = getMap(e.map)) if (const NamedPoint* pt = m->point(e.at)) { n.pos = tileCenter(pt->pos.x, pt->pos.y); n.anchor = pt->pos; } break; }
    n.inside = true; n.act = "inside";
    if (d.bdaySeason == s.cal.season && d.bdayDay == s.cal.day) summary.notes.push_back(fmt("It's %s's birthday today!", d.name.c_str()));
  }
  // 7) player
  float restore = passedOut ? 0.6f : 1.f;
  if (passedOut) { int lost = std::min(500, p.money / 20); p.money -= lost; if (lost) summary.notes.push_back(fmt("You passed out and dropped %dg on the way home.", lost)); }
  p.energy = p.maxEnergy * restore; p.health = p.maxHealth; p.buffs.clear(); p.animKind = 0;
  s.cal.minutes = kDayStart;
  if (const FestivalDef* f = todaysFestival()) summary.notes.push_back("Today is " + f->name + "! Visit the village square.");
  summary.notes.push_back(fmt("Today's weather: %s. Tomorrow: %s.", weatherName(s.wx.today), weatherName(s.wx.tomorrow)));
  enterMap("house", "spawn", false);
  npcMinute();
  updateQuests();
  emitEvent("sleep", "");
}

// ------------------------------------------------------------------------------------------------ simulation tick
void Game::fixedUpdate(float dt) {
  if (!hasSession) return;
  St st = top();
  timeSec += 0.f;
  if (st == St::Fishing) { updateFishing(dt); actionPressed = false; fx.update(dt, viewSize().x, viewSize().y); return; }
  if (st != St::Gameplay) return;
  s.playSeconds += dt;
  Calendar& c = s.cal;
  if (!fading) {
    c.acc += dt * (1.f / 0.7f);
    while (c.acc >= 1.f) {
      c.acc -= 1.f; ++c.minutes;
      tickMachines(1);
      for (auto& b : s.pl.buffs) --b.minutes;
      s.pl.buffs.erase(std::remove_if(s.pl.buffs.begin(), s.pl.buffs.end(), [](const ActiveBuff& b) { return b.minutes <= 0; }), s.pl.buffs.end());
      if (c.minutes % 10 == 0) npcMinute();
      if (c.minutes % 30 == 0) setStatusMood();
      if (c.minutes == 1440) toast("It's midnight. You should head to bed soon...", "ic_s_winter");
      if (c.minutes == 1500) toast("You're getting very tired...", "ic_s_winter");
      if (c.minutes == 540 && todaysFestival() && map().id == "village") toast("The festival is underway! Talk to the host.", "ic_s_spring");
      if (c.minutes >= kDayEnd) { toast("You collapse from exhaustion..."); newDay(true); setRoot(St::Gameplay); push(St::DaySummary); summaryT = 0; return; }
    }
  }
  if (!fading) {
    if (actionPressed) { actionPressed = false; startAction(resolveAction()); }
    updatePlayer(dt);
    updateHazards(dt);
  }
  updateNpcs(dt);
  updateAnimals(dt);
  if (festivalState == 2) updateFestival(dt);
  Map& m = map();
  cam.update(dt, s.pl.pos + Vec2(0, -8), (float)m.w * kTile, (float)m.h * kTile, viewSize().x, viewSize().y, true);
  fx.setCapacity(settings.particleCap());
  fx.update(dt, viewSize().x, viewSize().y);
  updateWeatherFx(dt);
}

void Game::frame(float dt) {
  timeSec += dt; stateTime += dt;
  ui.begin(*r, *in, settings, dt, safe);
  if (fading) {
    if (fadeTarget > 0.5f) { fade += dt * 3.2f; if (fade >= 1.f) { fade = 1.f; fadeTarget = 0.f; auto cb = fadeCallback; fadeCallback = nullptr; if (cb) cb(); } }
    else { fade -= dt * 3.2f; if (fade <= 0.f) { fade = 0.f; fading = false; } }
  }
  for (auto& t : toasts) t.t += dt;
  toasts.erase(std::remove_if(toasts.begin(), toasts.end(), [](const Toast& t) { return t.t > 3.6f; }), toasts.end());
  r->beginFrame();
  St t = top();
  bool worldVisible = hasSession && t != St::MainMenu && t != St::NewGame && t != St::Credits && !(t == St::Settings && settingsBack == St::MainMenu);
  if (worldVisible) renderWorld(); else drawTitleBackdrop();
  r->beginUI();
  if (in->backPressed) {
    in->backPressed = false;
    switch (t) {
      case St::Gameplay: push(St::Pause); break;
      case St::MainMenu: wantsExit = true; break;
      case St::Menu: case St::Shop: case St::Chest: case St::Animals: case St::Gift: case St::Message: case St::Pause: case St::Confirm: pop(); break;
      case St::Settings: if (settingsBack == St::MainMenu) setRoot(St::MainMenu); else pop(); saveSettings(); break;
      case St::NewGame: case St::Credits: setRoot(St::MainMenu); break;
      case St::CustomizeHud: pop(); break;
      default: break;
    }
    t = top();
  }
  switch (t) {
    case St::MainMenu: uiMainMenu(); break;
    case St::NewGame: uiNewGame(); break;
    case St::Gameplay: drawHud(); break;
    case St::Menu: uiMenu(); break;
    case St::Dialogue: drawHud(); uiDialogue(); break;
    case St::Shop: uiShop(); break;
    case St::Fishing: uiFishing(); break;
    case St::Pause: drawHud(); uiPause(); break;
    case St::Settings: uiSettings(); break;
    case St::Saving: uiSaving(); break;
    case St::DaySummary: uiDaySummary(); break;
    case St::Chest: uiChest(); break;
    case St::Animals: uiAnimals(); break;
    case St::Message: uiMessage(); break;
    case St::CustomizeHud: uiCustomizeHud(); break;
    case St::Credits: uiCredits(); break;
    case St::Gift: uiGift(); break;
    case St::Festival: drawHud(); uiFestival(); break;
    case St::Confirm: uiConfirm(); break;
    case St::Sleep:
      ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(8, 8, 24));
      ui.textCenter(Rect(0, 0, (float)r->screenW, (float)r->screenH), "Zzz...", col::rgba(200, 210, 255), 2);
      if (stateTime > 1.2f && !sleepDone) { sleepDone = true; newDay(false); pop(); push(St::DaySummary); summaryT = 0; }
      break;
    default: break;
  }
  uiToasts();
  if (fade > 0.001f) ui.rect(Rect(0, 0, (float)r->screenW, (float)r->screenH), col::rgba(10, 8, 20, (int)(clampv(fade, 0.f, 1.f) * 255)));
  if (debugBuild && settings.debugOverlay) uiDebug();
  r->endFrame();
}
}  // namespace cf
