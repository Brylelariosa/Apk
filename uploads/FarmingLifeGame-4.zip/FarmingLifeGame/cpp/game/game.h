// Central game object: owns the session (everything that is saved), the state stack and all gameplay systems.
#pragma once
#include <functional>
#include <map>
#include <memory>
#include <set>
#include "audio/audio.h"
#include "calendar/calendar.h"
#include "camera/camera.h"
#include "engine/settings.h"
#include "input/input.h"
#include "inventory/inventory.h"
#include "map/pathfinding.h"
#include "map/tilemap.h"
#include "particles/particles.h"
#include "platform/platform.h"
#include "renderer/renderer.h"
#include "ui/ui.h"
#include "weather/weather.h"

namespace cf {
class SaveWriter; class SaveReader;

enum class St : u8 { Boot, MainMenu, NewGame, Gameplay, Menu, Dialogue, Shop, Fishing, Pause, Settings, Saving, DaySummary, Chest, Animals, Message, CustomizeHud, Credits, Gift, Festival, Sleep, Confirm };

enum class Act : u8 { None, Till, Plant, Water, Harvest, Chop, Mine, Cut, Dig, Talk, Pet, Collect, Feed, Open, Machine, Pick, Fish, Eat, Place, Pickup, Sleep, Cook, Ship, Read, Board, Ladder, Refill, Fertilize, Barn, Treasure, Shrine, Lantern, Hop, Enter };
struct ActionInfo {
  Act act = Act::None; IVec2 tile; int obj = -1, ent = -1; ToolType tool = ToolType::None; std::string label, icon;
};

struct ActiveBuff { BuffType type = BuffType::None; int amount = 0, minutes = 0; };

struct Player {
  std::string name = "Sprout", map = "farm";
  int look = 0;
  Vec2 pos; Dir facing = Dir::Down;
  float energy = 100, maxEnergy = 100, health = 100, maxHealth = 100;
  int money = 800, sel = 0;
  Inventory inv;
  int xp[4] = {0, 0, 0, 0};                    // farming, mining, fishing, foraging
  std::vector<ActiveBuff> buffs;
  // action animation
  int animKind = 0;                            // 0 none 1 swing 2 water 3 fish 4 pick 5 eat 6 happy
  float animT = 0, animDur = 0, walkT = 0, stepT = 0, happyT = 0;
  bool moving = false, hitDone = true;
  ActionInfo pending;
  int level(int skill) const { int x = xp[skill]; int lv = 0; while (lv < 10 && x >= (lv + 1) * (lv + 1) * 40) ++lv; return lv; }
  float buffAmount(BuffType t) const { float a = 0; for (auto& b : buffs) if (b.type == t) a += (float)b.amount; return a; }
};

struct NpcState {
  int def = 0; std::string map = "village"; Vec2 pos; Dir facing = Dir::Down; bool inside = true, traveling = false;
  int friendship = 0, giftsWeek = 0, dating = 0;
  bool talked = false, gifted = false;
  int schedIdx = -2, travelLeft = 0;
  std::string act = "inside", destMap, destAt;
  IVec2 anchor;
  IVec2 target; std::vector<IVec2> path; size_t pathPos = 0; bool hasTarget = false;
  float animT = 0, wait = 0, talkT = 0; bool moving = false; int tickPhase = 0;
  int hearts() const { return clampv(friendship / 250, 0, 10); }
};

struct AnimalState {
  int def = 0, building = 0;                    // building: index in farm.buildings
  std::string name;
  Vec2 pos; Dir facing = Dir::Right; bool inside = false;
  int hunger = 80, happiness = 70, health = 100, affection = 0, age = 0, personality = 0, daysSince = 0, quality = 0;
  bool product = false, petted = false, fed = false;
  int act = 0; float actT = 0; Vec2 dest; float animT = 0; bool moving = false;   // act: 0 wander 1 eat 2 sleep 3 play 4 approach
};

struct PendingUp { int kind = 0; int a = 0, b = 0, days = 0; };   // kind 0 tool (a=ToolType, b=tier), 1 building (a=index, b=level)
struct QuestState { int def = 0; std::vector<int> prog; bool done = false; };

struct Session {
  Calendar cal; WeatherState wx;
  Player pl;
  std::map<std::string, std::unique_ptr<Map>> maps;
  std::string curMap = "farm";
  std::vector<NpcState> npcs;
  std::vector<AnimalState> animals;
  std::vector<PendingUp> pending;
  std::vector<QuestState> quests;
  std::set<std::string> flags, recipes, seenItems, caught, minerals;
  std::map<std::string, int> counters;            // stats: harvested, caught, mined, earned, shipped...
  std::vector<ItemStack> bin;                     // shipping bin contents
  int seed = 1, deepestMine = 0, mailSeed = 0;
  int farmhouseLevel = 1;
  double playSeconds = 0;
};

struct Toast { std::string text; std::string icon; float t = 0; };
struct DaySummaryData { std::vector<std::pair<ItemStack, int>> sold; int total = 0; std::vector<std::string> notes; bool passedOut = false; };

class Game {
 public:
  // ---- services (set by Application)
  Renderer* r = nullptr; Input* in = nullptr; Audio* audio = nullptr; Settings settings; UI ui;
  Rect safe;                                   // screen safe area in px
  bool debugBuild = false; float fps = 0, frameMs = 0;

  // ---- lifecycle
  bool init();                                 // loads content; shows boot state
  void saveSettings();
  void drawTitleBackdrop();
  bool sleepDone = false;
  void updateWeatherFx(float dt);
  void fixedUpdate(float dt);                  // 60 Hz simulation tick
  void frame(float dt);                        // per-frame UI/render
  void onPause(); void onResume();
  bool wantsExit = false;
  St top() const { return stack.empty() ? St::Boot : stack.back(); }
  void push(St s) { stack.push_back(s); stateTime = 0; }
  void pop() { if (stack.size() > 1) stack.pop_back(); stateTime = 0; }
  void setRoot(St s) { stack.clear(); stack.push_back(s); stateTime = 0; }
  std::vector<St> stack;
  float stateTime = 0;

  // ---- session
  Session s; bool hasSession = false; std::string saveError;
  void newGame(const std::string& name, int look);
  bool continueGame();
  bool saveGame(bool quiet = false);
  bool hasSave() const;
  void serialize(SaveWriter& w); bool deserialize(SaveReader& rd);

  // ---- world
  Map& map() { return *s.maps[s.curMap]; }
  Map* getMap(const std::string& id);
  void enterMap(const std::string& id, const std::string& point, bool fade = true);
  void populateMap(Map& m);                    // daily forage/weeds/initial objects
  void generateMine(int floor);
  void newDay(bool passedOut);
  void startDayChores();
  Vec2 tileCenter(int x, int y) const { return Vec2((float)x * kTile + kTile * 0.5f, (float)y * kTile + kTile * 0.5f); }
  IVec2 playerTile() const { return IVec2((int)std::floor(s.pl.pos.x / kTile), (int)std::floor(s.pl.pos.y / kTile)); }
  bool collides(const Map& m, Vec2 p) const;
  int  seasonIdx() const { return s.cal.season; }
  Weather weather() { return map().indoor ? Weather::Cloudy : s.wx.today; }

  // ---- player & actions
  void updatePlayer(float dt);
  ActionInfo resolveAction();
  void startAction(const ActionInfo& a);
  void applyAction(const ActionInfo& a);       // effect at the hit frame
  bool spendEnergy(float e);
  void giveItem(ItemStack st, bool toast = true);
  void toast(const std::string& text, const std::string& icon = "");
  void addXp(int skill, int n);
  void consume(int slot);
  int  selectedToolSlot(ToolType t);
  void hurt(float hp);
  void emitEvent(const std::string& type, const std::string& arg, int n = 1);   // drives quests / counters
  float moveStick[2] = {0, 0}; bool actionHeld = false, actionPressed = false;

  // ---- farming
  bool tillTile(Map& m, int x, int y);
  bool plantSeed(Map& m, int x, int y, int cropIdx, int fert);
  void waterTile(Map& m, int x, int y);
  void harvestCrop(Map& m, int objIdx);
  void growCrops(Map& m, bool rained);
  int  cropStage(const CropDef& c, const MapObject& o) const;
  void breakObject(Map& m, int idx, bool byPlayer);
  void dropItems(const ObjDef& d, Vec2 at);

  // ---- machines, crafting, cooking
  bool canCraft(const RecipeDef& r) const;
  bool recipeUnlocked(const RecipeDef& r) const;
  bool craft(int recipeIdx);
  void useMachine(Map& m, int objIdx);
  void tickMachines(int minutes);
  void eatItem(int slot);
  void addBuff(const Buff& b);
  std::vector<int> unlockedRecipes(const std::string& station) const;

  // ---- animals & buildings
  void updateAnimals(float dt);
  void animalsNewDay();
  int  buildingCapacity(int farmBuilding) const;
  int  animalsInBuilding(int b) const;
  bool buyAnimal(int animalDef, int building);
  BuildingInst* farmBuilding(const std::string& id);
  void petAnimal(AnimalState& a);
  void collectAnimal(AnimalState& a);
  int hayStock[3] = {0, 0, 0};                 // per farm building index (barn, coop...)

  // ---- NPCs
  void initNpcs();
  void updateNpcs(float dt);
  void npcMinute();
  void placeNpcsForMap(const std::string& map);
  int  npcAt(Vec2 p, float radius) const;
  const SchedEntry* currentSched(const NpcState& n, bool& rainVariant) const;
  bool npcIsPlaced(const NpcState& n) const { return !n.inside && !n.traveling && n.map == s.curMap; }
  bool shopOpen(const ShopDef& sd) const;

  // ---- dialogue & relationships
  struct Dialogue { int npc = -1, ev = -1, evLine = 0, page = 0; std::string speaker, portrait, expr = "neutral"; std::vector<std::string> pages; std::vector<std::string> choices; std::vector<int> ids; float typeT = 0; int mode = 0; std::string after; } dlg;
  void startTalk(int npcIdx);
  void showDialogue(const std::string& speaker, const std::string& portrait, const std::string& expr, const std::string& text, const std::vector<std::pair<int, std::string>>& choices = {});
  void dialogueChoice(int id);
  std::string pickLine(const NpcState& n, const std::string& tag);
  void giveGift(int npcIdx, int slot);
  void addFriendship(NpcState& n, int pts);
  int  giftTaste(const NpcDef& d, int item) const;   // 2 love 1 like 0 neutral -1 dislike -2 hate
  int giftNpc = -1;

  // ---- quests
  void updateQuests();
  bool questAvailable(const QuestDef& q) const;
  bool questObjectiveDone(const QuestDef& q, const QuestState& qs, size_t i) const;
  void completeQuest(QuestState& qs);
  QuestState* questState(const std::string& id);
  bool flag(const std::string& f) const { return s.flags.count(f) > 0; }
  void setFlag(const std::string& f) { s.flags.insert(f); }
  int counter(const std::string& k) const { auto it = s.counters.find(k); return it == s.counters.end() ? 0 : it->second; }
  void tryDeliver(int npcIdx);

  // ---- economy
  struct ShopUI { int shop = 0, tab = 0, sel = -1, qty = 1; float scroll = 0; std::string note; int npc = -1; } shopUi;
  int buyPrice(const ShopDef& sd, const ShopItem& it) const;
  int sellValue(const ShopDef* sd, const ItemStack& st) const;
  void openShop(int shopIdx, int npcIdx);
  void addMoney(int n);

  // ---- fishing
  struct FishingGame { int phase = 0; float t = 0, waitT = 0, bite = 0, bar = 0.5f, barV = 0, fishPos = 0.5f, fishV = 0, progress = 0.3f, diff = 0.3f, size = 0.3f; int fishItem = 0; IVec2 target; bool legendary = false; bool derby = false; float derbyT = 0; int derbyCount = 0; } fg;
  bool startFishing(IVec2 water);
  void updateFishing(float dt);
  int  pickFish(const std::string& water);

  // ---- mine
  int  mineFloorOf(const Map& m) const { return m.mineFloor; }
  void useLadder();
  void updateHazards(float dt);
  float hazardCd = 0;
  void witherCrops(Map& m);
  void waterAllRain();
  void sprinklersWater();
  void crowsAttack();
  void autoCollect();
  void descendMine(int floor);

  // ---- menus & misc state
  struct MenuUI { int tab = 0; float scroll = 0, scroll2 = 0; int sel = -1, recipe = -1, cookMode = 0; std::string note; } menu;
  struct ChestUI { int obj = -1; bool bin = false; float scroll = 0; int sel = -1; } chestUi;
  struct AnimalUI { int building = 0; float scroll = 0; int sel = -1; } animalUi;
  struct MsgUI { std::string title, text; St back = St::Gameplay; } msg;
  struct ConfirmUI { std::string text; int id = 0; } confirm;
  DaySummaryData summary; float summaryT = 0;
  std::vector<Toast> toasts;
  std::string newName = "Sprout"; int newLook = 0; bool editingName = false;
  int settingsTab = 0; float settingsScroll = 0; St settingsBack = St::MainMenu; int pendingSlot = -1; float savingT = 0; bool savingDone = false;
  bool saveAfterSleep = false;
  float fade = 0, fadeTarget = 0; std::function<void()> fadeCallback; bool fading = false;
  void fadeTo(std::function<void()> mid);
  std::string festivalId; int festivalState = 0, festRound = 0, festPrize = 0; float festT = 0, festMark = 0; int festScore = 0; std::vector<Vec2> festPickups; std::string festResult;
  void finishFestival();
  void updateFestival(float dt);
  void startFestivalActivity();
  const FestivalDef* todaysFestival() const;

  // ---- rendering
  Camera cam; ParticleSystem fx;
  void renderWorld();
  void renderWeather(float dt);
  void drawHud();
  void updateFx(float dt);
  Vec2 viewSize() const { return Vec2((float)r->logicalW, (float)r->logicalH); }
  float timeSec = 0;
  std::vector<Light> lights;
  // HUD state
  bool hotbarOpen = false;

  // ---- screens (ui/*.cpp)
  void uiMainMenu(); void uiNewGame(); void uiPause(); void uiMenu(); void uiDialogue(); void uiShop(); void uiFishing(); void uiSettings(); void uiSaving();
  void uiDaySummary(); void uiChest(); void uiAnimals(); void uiMessage(); void uiCustomizeHud(); void uiCredits(); void uiGift(); void uiFestival(); void uiConfirm(); void uiToasts(); void uiDebug();
  void uiMenuInventory(Rect body); void uiMenuCraft(Rect body); void uiMenuQuests(Rect body); void uiMenuFriends(Rect body); void uiMenuCollection(Rect body); void uiMenuSkills(Rect body);
  void uiShopSmith(Rect body); void uiShopRanch(Rect body);
  void setStatusMood();
  Rect contentRect() const;
  Pointer* joyPtr = nullptr; Pointer* actPtr = nullptr; Vec2 joyCenter; float joyAmt[2] = {0, 0};
  Pointer* dragHud = nullptr; int dragWhich = -1;
  Rng rng{123};
};
}  // namespace cf
