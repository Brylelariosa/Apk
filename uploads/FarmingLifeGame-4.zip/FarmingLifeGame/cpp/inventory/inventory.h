#pragma once
#include "items/content.h"
namespace cf {
class Inventory {
 public:
  static constexpr int kSlots = 36, kHotbar = 12;
  std::vector<ItemStack> slots = std::vector<ItemStack>(kSlots);
  int count(int item) const { int n = 0; for (auto& s : slots) if (s.id == item) n += s.count; return n; }
  int countGroup(const Ingredient& g) const { int n = 0; for (auto& s : slots) if (!s.empty() && C().matches(g, s.id)) n += s.count; return n; }
  int add(ItemStack s);                                  // returns the number that did not fit
  bool canAdd(ItemStack s) const;
  bool remove(int item, int n);                          // removes n of an exact item (any quality, low quality first)
  bool removeGroup(const Ingredient& g, int n);
  bool has(const std::vector<Ingredient>& in) const;
  bool take(const std::vector<Ingredient>& in);          // consume (assumes has())
  bool hasTool(ToolType t) const { return findTool(t) >= 0; }
  int findTool(ToolType t) const;
  int toolTier(ToolType t) const { int i = findTool(t); return i < 0 ? 0 : slots[(size_t)i].tier; }
  int freeSlots() const { int n = 0; for (auto& s : slots) if (s.empty()) ++n; return n; }
};
}  // namespace cf
