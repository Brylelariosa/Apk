#include "inventory/inventory.h"
namespace cf {
int Inventory::add(ItemStack s) {
  if (s.empty()) return 0;
  int maxStack = C().def(s.id).stack;
  for (auto& t : slots) if (!t.empty() && t == s && t.count < maxStack) { int n = std::min<int>(maxStack - t.count, s.count); t.count = (u16)(t.count + n); s.count = (u16)(s.count - n); if (!s.count) return 0; }
  for (auto& t : slots) if (t.empty()) { int n = std::min<int>(maxStack, s.count); t = s; t.count = (u16)n; s.count = (u16)(s.count - n); if (!s.count) return 0; }
  return s.count;
}
bool Inventory::canAdd(ItemStack s) const {
  int maxStack = C().def(s.id).stack, room = 0;
  for (auto& t : slots) { if (t.empty()) room += maxStack; else if (t == s) room += maxStack - t.count; }
  return room >= s.count;
}
bool Inventory::remove(int item, int n) {
  if (count(item) < n) return false;
  for (int pass = 0; pass < 4 && n > 0; ++pass)
    for (auto& s : slots) if (s.id == item && s.quality == pass && n > 0) { int k = std::min<int>(n, s.count); s.count = (u16)(s.count - k); n -= k; if (!s.count) s = ItemStack(); }
  return true;
}
bool Inventory::removeGroup(const Ingredient& g, int n) {
  if (g.item) return remove(g.item, n);
  if (countGroup(g) < n) return false;
  for (auto& s : slots) if (!s.empty() && C().matches(g, s.id) && n > 0) { int k = std::min<int>(n, s.count); s.count = (u16)(s.count - k); n -= k; if (!s.count) s = ItemStack(); }
  return true;
}
bool Inventory::has(const std::vector<Ingredient>& in) const {
  for (auto& g : in) if ((g.item ? count(g.item) : countGroup(g)) < g.count) return false;
  return true;
}
bool Inventory::take(const std::vector<Ingredient>& in) {
  if (!has(in)) return false;
  for (auto& g : in) removeGroup(g, g.count);
  return true;
}
int Inventory::findTool(ToolType t) const {
  for (size_t i = 0; i < slots.size(); ++i) if (!slots[i].empty() && C().def(slots[i].id).tool == t) return (int)i;
  return -1;
}
}  // namespace cf
