// Cooking-specific helpers: the kitchen lives in the farmhouse; recipes unlock through friendship and quests.
#include "game/game.h"
namespace cf {
const FestivalDef* Game::todaysFestival() const {
  for (auto& f : C().festivals) if (f.season == s.cal.season && f.day == s.cal.day) return &f;
  return nullptr;
}
}  // namespace cf
