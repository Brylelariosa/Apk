// Contextual action resolution + tool effects. The action button asks resolveAction() what the player is facing.
#include "engine/log.h"
#include "game/game.h"

namespace cf {

static const float kToolCost[8] = {0, 3, 2, 4, 4, 2, 0, 2};   // index = ToolType

int Game::selectedToolSlot(ToolType t) { return s.pl.inv.findTool(t); }

bool Game::spendEnergy(float e) {
  Player& p = s.pl;
  if (p.energy <= 0.f && e > 0) { toast("You're exhausted! Eat or sleep."); audio->play(Sfx::Error); return false; }
  p.energy = std::max(0.f, p.energy - e);
  return true;
}

static float toolCost(Game& g, ToolType t) {
  float c = kToolCost[(int)t]; int tier = g.s.pl.inv.toolTier(t);
  c *= 1.f - 0.07f * (float)tier;
  if (t == ToolType::Hoe || t == ToolType::Can || t == ToolType::Shears) c *= 1.f - 0.25f * std::min(1.f, g.s.pl.buffAmount(BuffType::Farm) * 0.5f);
  if (t == ToolType::Pick || t == ToolType::Axe) c *= 1.f - 0.25f * std::min(1.f, g.s.pl.buffAmount(BuffType::Mine) * 0.5f);
  return std::max(0.5f, c);
}

static ActionInfo mk(Act a, IVec2 t, const char* label, const std::string& icon, ToolType tool = ToolType::None, int obj = -1, int ent = -1) {
  ActionInfo r; r.act = a; r.tile = t; r.label = label; r.icon = icon; r.tool = tool; r.obj = obj; r.ent = ent; return r;
}
static std::string toolIconName(Game& g, ToolType t) {
  static const char* n[8] = {"", "hoe", "can", "axe", "pick", "rod", "hammer", "shears"};
  return fmt("item_%s_%d", n[(int)t], g.s.pl.inv.toolTier(t));
}

ActionInfo Game::resolveAction() {
  Player& p = s.pl; Map& m = map();
  IVec2 pt = playerTile(), dv = dirVec(p.facing), ft(pt.x + dv.x, pt.y + dv.y);
  Vec2 front = p.pos + Vec2((float)dv.x * 11.f, (float)dv.y * 11.f - 4.f);
  const ItemStack& sel = p.inv.slots[(size_t)p.sel];
  const ItemDef& sd = C().def(sel.id);
  auto needTool = [&](ToolType t, Act a, const char* label, IVec2 tile, int obj) {
    if (!p.inv.hasTool(t)) return mk(Act::None, tile, "Need a tool", "ic_lock");
    return mk(a, tile, label, toolIconName(*this, t), t, obj);
  };
  // 1) villagers
  int ni = npcAt(front, 15.f);
  if (ni >= 0) return mk(Act::Talk, ft, "Talk", "ac_talk", ToolType::None, -1, ni);
  // 2) animals
  if (m.id == "farm") for (size_t i = 0; i < s.animals.size(); ++i) {
    AnimalState& a = s.animals[i]; if (a.inside) continue;
    if ((a.pos - front).len() < 14.f || (a.pos - p.pos).len() < 12.f) {
      const AnimalDef& d = C().animals[(size_t)a.def];
      if (a.product) { if (d.shears && !p.inv.hasTool(ToolType::Shears)) return mk(Act::None, ft, "Need shears", "ic_lock"); return mk(Act::Collect, ft, "Collect", d.shears ? toolIconName(*this, ToolType::Shears) : "ac_hand", ToolType::None, -1, (int)i); }
      if (sd.cat == Cat::Feed && a.hunger < 90) return mk(Act::Feed, ft, "Feed", "item_hay", ToolType::None, -1, (int)i);
      return mk(Act::Pet, ft, "Pet", "ac_hand", ToolType::None, -1, (int)i);
    }
  }
  // 3) objects (facing tile first, then the tile under the player for things you stand on)
  int oi = m.objectAt(ft.x, ft.y);
  if (oi < 0) { int o2 = m.objectAt(pt.x, pt.y); if (o2 >= 0 && (m.objs[(size_t)o2].kind == ObjKind::Forage || m.objs[(size_t)o2].kind == ObjKind::Wisp || m.objs[(size_t)o2].kind == ObjKind::Ladder || m.objs[(size_t)o2].kind == ObjKind::Hole)) { oi = o2; ft = pt; } }
  if (oi >= 0) {
    MapObject& o = m.objs[(size_t)oi]; const ObjDef* d = o.kind == ObjKind::Crop ? nullptr : &objDef(o);
    switch (o.kind) {
      case ObjKind::Tree: case ObjKind::Stump: case ObjKind::Log: case ObjKind::Twig: return needTool(ToolType::Axe, Act::Chop, o.kind == ObjKind::Tree ? "Chop" : "Chop", ft, oi);
      case ObjKind::Rock: case ObjKind::Ore: return needTool(ToolType::Pick, Act::Mine, "Mine", ft, oi);
      case ObjKind::Dig: return needTool(ToolType::Hoe, Act::Dig, "Dig", ft, oi);
      case ObjKind::Weed: {
        ToolType t = d->tool == ToolType::Shears ? ToolType::Shears : ToolType::Hoe;
        if (d->tool == ToolType::Shears && !p.inv.hasTool(t)) return mk(Act::None, ft, "Need shears", "ic_lock");
        if (!p.inv.hasTool(t)) t = p.inv.hasTool(ToolType::Axe) ? ToolType::Axe : ToolType::Pick;
        return mk(Act::Cut, ft, "Clear", toolIconName(*this, t), t, oi);
      }
      case ObjKind::Forage: return mk(Act::Pick, ft, "Pick up", "ac_hand", ToolType::None, oi);
      case ObjKind::Wisp: return mk(Act::Pick, ft, "Catch", "item_wisp_spark", ToolType::None, oi);
      case ObjKind::Crop: {
        const CropDef& c = C().crops[o.def];
        if (o.state >= 5) return mk(Act::Harvest, ft, "Harvest", "ac_hand", ToolType::None, oi);
        if (o.state == 9) return needTool(ToolType::Hoe, Act::Cut, "Clear", ft, oi);
        if (!(m.at(ft.x, ft.y).flags & TF_Watered) && !(isRainy(weather()) && m.outdoors)) return needTool(ToolType::Can, Act::Water, "Water", ft, oi);
        (void)c; return mk(Act::None, ft, "", "");
      }
      case ObjKind::Chest: case ObjKind::Collector: return mk(Act::Open, ft, "Open", "item_chest", ToolType::None, oi);
      case ObjKind::Machine: {
        if (o.state == 2) return mk(Act::Machine, ft, "Collect", "ac_hand", ToolType::None, oi);
        if (o.state == 1) return mk(Act::Machine, ft, "Check", "ac_use", ToolType::None, oi);
        return mk(Act::Machine, ft, "Use", "ac_use", ToolType::None, oi);
      }
      case ObjKind::Feeder: return sd.cat == Cat::Feed ? mk(Act::Machine, ft, "Refill", "item_hay", ToolType::None, oi) : mk(Act::Machine, ft, "Check", "ac_use", ToolType::None, oi);
      case ObjKind::Fence: case ObjKind::Sprinkler: case ObjKind::Scarecrow: case ObjKind::Lamp:
        if (sd.tool == ToolType::Hammer || p.inv.hasTool(ToolType::Hammer)) return needTool(ToolType::Hammer, Act::Pickup, "Pick up", ft, oi);
        return mk(Act::None, ft, "", "");
      case ObjKind::Bin: return mk(Act::Ship, ft, "Ship", "ac_ship", ToolType::None, oi);
      case ObjKind::Bed: return mk(Act::Sleep, ft, "Sleep", "ac_sleep", ToolType::None, oi);
      case ObjKind::Kitchen: return mk(Act::Cook, ft, "Cook", "ac_cook", ToolType::None, oi);
      case ObjKind::Sign: return d->id == "wisp_shrine" ? mk(Act::Shrine, ft, "Touch", "item_wisp_spark", ToolType::None, oi) : mk(Act::Read, ft, "Read", "ac_read", ToolType::None, oi);
      case ObjKind::Board: return mk(Act::Board, ft, "Read", "ic_quest", ToolType::None, oi);
      case ObjKind::Lantern: return mk(Act::Lantern, ft, "Examine", "ac_read", ToolType::None, oi);
      case ObjKind::Ladder: return mk(Act::Ladder, ft, o.state == 1 ? "Climb up" : "Descend", "ac_enter", ToolType::None, oi);
      case ObjKind::Treasure: return mk(Act::Treasure, ft, o.state ? "Empty" : "Open", "item_chest", ToolType::None, oi);
      default: break;
    }
  }
  // 4) barn / coop doors
  for (auto& b : m.buildings) {
    const BuildingDef& bd = C().buildings[(size_t)b.def];
    if (bd.animals.empty()) continue;
    if (ft.x == b.x + bd.door && ft.y == b.y) return mk(Act::Barn, ft, bd.animals == "barn" ? "Barn" : "Coop", "ac_enter");
  }
  // 5) ground interactions
  Terrain tt = m.terrain(ft.x, ft.y);
  if (terrainWater(tt)) {
    if (sd.tool == ToolType::Can || (!p.inv.hasTool(ToolType::Rod) && p.inv.hasTool(ToolType::Can))) return mk(Act::Refill, ft, "Refill", toolIconName(*this, ToolType::Can), ToolType::Can);
    if (p.inv.hasTool(ToolType::Rod)) return mk(Act::Fish, ft, "Fish", toolIconName(*this, ToolType::Rod), ToolType::Rod);
    return mk(Act::None, ft, "", "");
  }
  bool tilled = m.inBounds(ft.x, ft.y) && (m.at(ft.x, ft.y).flags & TF_Tilled);
  bool crowded = m.inBounds(ft.x, ft.y) && m.objectAt(ft.x, ft.y) >= 0;
  if (sd.cat == Cat::Seed && tilled && !crowded) {
    int ci = C().cropOfSeed(sel.id);
    if (ci >= 0 && !(C().crops[(size_t)ci].seasons & (1 << s.cal.season))) return mk(Act::None, ft, "Wrong season", "ic_lock");
    if (ci >= 0) return mk(Act::Plant, ft, "Plant", fmt("item_%s", sd.id.c_str()), ToolType::None);
  }
  if (sd.cat == Cat::Fertilizer && tilled && !crowded && !(m.at(ft.x, ft.y).flags & (TF_Fert | TF_Rich))) return mk(Act::Fertilize, ft, "Fertilize", fmt("item_%s", sd.id.c_str()));
  if (sd.cat == Cat::Placeable && !m.indoor && m.inBounds(ft.x, ft.y) && !m.tileBlocked(ft.x, ft.y) && !crowded && terrainWalkable(tt) && !m.warpAt(ft.x, ft.y))
    return mk(Act::Place, ft, "Place", fmt("item_%s", sd.id.c_str()));
  if (tilled && !crowded && !(m.at(ft.x, ft.y).flags & TF_Watered) && !(isRainy(weather()) && m.outdoors) && p.inv.hasTool(ToolType::Can) && sd.cat != Cat::Seed)
    return needTool(ToolType::Can, Act::Water, "Water", ft, -1);
  if (!tilled && m.canTill(ft.x, ft.y) && !(sd.cat == Cat::Food && false)) return needTool(ToolType::Hoe, Act::Till, "Till", ft, -1);
  if (sd.edible() && (sd.cat == Cat::Food || sd.cat == Cat::Crop || sd.cat == Cat::Forage || sd.cat == Cat::Fish || sd.cat == Cat::Product || sd.cat == Cat::Artisan))
    return mk(Act::Eat, ft, "Eat", fmt("item_%s", sd.id.c_str()));
  return mk(Act::None, ft, "", "");
}

void Game::startAction(const ActionInfo& a) {
  Player& p = s.pl;
  if (a.act == Act::None || p.animKind) return;
  // facing towards an entity
  if (a.ent >= 0 && a.act == Act::Talk) { const NpcState& n = s.npcs[(size_t)a.ent]; p.facing = dirFromVec(n.pos.x - p.pos.x, n.pos.y - p.pos.y); }
  bool instant = true; int kind = 0; float dur = 0.4f;
  switch (a.act) {
    case Act::Till: case Act::Chop: case Act::Mine: case Act::Cut: case Act::Dig: case Act::Pickup: instant = false; kind = 1; dur = 0.44f; break;
    case Act::Water: case Act::Refill: instant = false; kind = 2; dur = 0.55f; break;
    case Act::Fish: instant = false; kind = 3; dur = 0.5f; break;
    case Act::Harvest: case Act::Pick: instant = false; kind = 4; dur = 0.32f; break;
    case Act::Plant: case Act::Fertilize: case Act::Place: instant = false; kind = 4; dur = 0.28f; break;
    case Act::Eat: instant = false; kind = 5; dur = 0.7f; break;
    default: break;
  }
  if (instant) { applyAction(a); return; }
  float cost = 0;
  switch (a.act) {
    case Act::Till: case Act::Water: case Act::Chop: case Act::Mine: case Act::Cut: case Act::Dig: case Act::Fish: cost = toolCost(*this, a.tool == ToolType::None ? ToolType::Hoe : a.tool); break;
    case Act::Pickup: cost = 0.5f; break;
    default: break;
  }
  if (cost > 0 && !spendEnergy(cost)) return;
  dur *= 1.f - 0.08f * (float)(a.tool != ToolType::None ? p.inv.toolTier(a.tool) : 0) - 0.06f * std::min(2.f, p.buffAmount(BuffType::Speed));
  p.pending = a; p.animKind = kind; p.animT = 0; p.animDur = std::max(0.2f, dur); p.hitDone = false;
}

void Game::dropItems(const ObjDef& d, Vec2 at) {
  for (auto& dd : d.drops) {
    if (rng.f() > dd.chance) continue;
    int n = rng.range(dd.mn, dd.mx); if (n <= 0) continue;
    ItemStack st; st.id = (u16)dd.item; st.count = (u16)n;
    giveItem(st);
    if (settings.particles) fx.emit(Fx::Chip, at.x, at.y - 6, rng.rangef(-12, 12), rng.rangef(-30, -14), 0.4f, col::rgba(190, 170, 140), 120);
  }
}

void Game::breakObject(Map& m, int idx, bool byPlayer) {
  MapObject o = m.objs[(size_t)idx];
  const ObjDef& d = objDef(o);
  Vec2 at = tileCenter(o.x, o.y);
  if (byPlayer) {
    dropItems(d, at);
    if (o.kind == ObjKind::Rock || o.kind == ObjKind::Ore) { addXp(1, o.kind == ObjKind::Ore ? 4 : 1); emitEvent("break", d.id); s.counters["mined"]++; }
    if (o.kind == ObjKind::Tree || o.kind == ObjKind::Stump || o.kind == ObjKind::Log) { addXp(3, 1); emitEvent("chop", d.id); }
    if (o.kind == ObjKind::Ore && C().def(d.drops.empty() ? 0 : d.drops[0].item).cat == Cat::Mineral) s.minerals.insert(C().def(d.drops[0].item).id);
  }
  bool hidesLadder = o.kind == ObjKind::Rock && o.aux == 1 && m.mineFloor > 0;
  m.removeObject(idx);
  if (hidesLadder) { MapObject l; int ld = C().obj("ladder"); l.kind = ObjKind::Ladder; l.def = (u16)ld; l.x = o.x; l.y = o.y; m.addObject(l); toast("You found a ladder!"); audio->play(Sfx::Sparkle); }
  if (o.kind == ObjKind::Tree && byPlayer) {   // stump left behind
    int sd = C().obj("stump");
    if (sd >= 0 && rng.chance(0.55f)) { MapObject st; st.kind = ObjKind::Stump; st.def = (u16)sd; st.x = o.x; st.y = o.y; st.hp = (u16)C().objs[(size_t)sd].hp; m.addObject(st); }
    for (int i = 0; i < 6 && settings.particles; ++i) fx.emit(Fx::Leaf, at.x + rng.rangef(-10, 10), at.y - rng.rangef(10, 30), rng.rangef(-10, 10), rng.rangef(-5, 10), 0.9f, kWhite, 18);
  }
}

static std::vector<IVec2> areaTiles(int tier, Dir f, IVec2 t) {
  std::vector<IVec2> v{t};
  if (tier >= 2) { IVec2 d = dirVec(f); IVec2 side(d.y != 0 ? 1 : 0, d.x != 0 ? 1 : 0); v.push_back(IVec2(t.x + side.x, t.y + side.y)); v.push_back(IVec2(t.x - side.x, t.y - side.y)); }
  if (tier >= 4) { IVec2 d = dirVec(f); IVec2 side(d.y != 0 ? 1 : 0, d.x != 0 ? 1 : 0); for (int k = -1; k <= 1; ++k) v.push_back(IVec2(t.x + d.x + side.x * k, t.y + d.y + side.y * k)); }
  return v;
}

void Game::applyAction(const ActionInfo& a) {
  Player& p = s.pl; Map& m = map(); Vec2 at = tileCenter(a.tile.x, a.tile.y);
  int tier = a.tool != ToolType::None ? p.inv.toolTier(a.tool) : 0;
  switch (a.act) {
    case Act::Till: {
      int n = 0;
      for (IVec2 t : areaTiles(tier, p.facing, a.tile)) if (m.canTill(t.x, t.y)) { tillTile(m, t.x, t.y); ++n; }
      if (n) { audio->play(Sfx::Hoe); addXp(0, 1); emitEvent("till", "", n); }
      break;
    }
    case Act::Water: {
      int slot = selectedToolSlot(ToolType::Can); if (slot < 0) break;
      ItemStack& can = p.inv.slots[(size_t)slot];
      if (can.aux == 0) { toast("The can is empty. Refill it at water!", "item_can_0"); audio->play(Sfx::Error); break; }
      int n = 0;
      for (IVec2 t : areaTiles(tier, p.facing, a.tile)) {
        if (can.aux == 0) break;
        if (m.inBounds(t.x, t.y) && (m.at(t.x, t.y).flags & TF_Tilled) && !(m.at(t.x, t.y).flags & TF_Watered)) { waterTile(m, t.x, t.y); --can.aux; ++n; }
      }
      if (n) { audio->play(Sfx::Water); emitEvent("water", "", n); }
      break;
    }
    case Act::Refill: {
      int slot = selectedToolSlot(ToolType::Can); if (slot < 0) break;
      static const int cap[6] = {20, 35, 50, 70, 90, 120};
      s.pl.inv.slots[(size_t)slot].aux = (u16)cap[clampv((int)s.pl.inv.slots[(size_t)slot].tier, 0, 5)];
      audio->play(Sfx::Splash); toast("Watering can refilled.", "item_can_0");
      for (int i = 0; i < 5; ++i) fx.emit(Fx::Drop, at.x + rng.rangef(-5, 5), at.y, rng.rangef(-8, 8), rng.rangef(-30, -12), 0.5f, kWhite, 90);
      break;
    }
    case Act::Chop: case Act::Mine: case Act::Cut: case Act::Dig: case Act::Pickup: {
      int oi = m.objectAt(a.tile.x, a.tile.y); if (oi < 0) break;
      MapObject& o = m.objs[(size_t)oi];
      if (o.kind == ObjKind::Crop) { // clearing a dead plant
        m.removeObject(oi); audio->play(Sfx::Pop); break;
      }
      const ObjDef& d = objDef(o);
      if (a.act == Act::Pickup) {
        if (d.itemId) { ItemStack st; st.id = (u16)d.itemId; st.count = 1; if (!p.inv.canAdd(st)) { toast("Inventory full."); break; }
          if (o.kind == ObjKind::Chest || o.kind == ObjKind::Collector) { if (o.aux < m.chests.size()) { bool empty = true; for (auto& sl : m.chests[o.aux].slots) if (!sl.empty()) empty = false; if (!empty) { toast("Empty the chest first."); break; } } }
          giveItem(st, false); m.removeObject(oi); audio->play(Sfx::Pop); }
        break;
      }
      if (d.tier > tier) { toast(fmt("%s needs a stronger tool.", d.name.c_str()), "ic_lock"); audio->play(Sfx::Error); break; }
      int power = 1 + tier + (a.act == Act::Chop || a.act == Act::Mine ? (int)p.buffAmount(BuffType::Mine) / 2 : 0);
      if (a.act == Act::Cut || a.act == Act::Dig) power = 99;
      int hp = (int)o.hp - power;
      audio->play(a.act == Act::Mine ? Sfx::Mine : Sfx::Chop, 1.f, 0.9f + rng.f() * 0.2f);
      for (int i = 0; i < 4 && settings.particles; ++i) fx.emit(Fx::Chip, at.x, at.y - 4, rng.rangef(-24, 24), rng.rangef(-34, -8), 0.4f, a.act == Act::Mine ? col::rgba(190, 190, 205) : col::rgba(170, 120, 70), 140);
      if (settings.particles) fx.emit(Fx::Hit, at.x, at.y - 6, 0, 0, 0.18f);
      if (!settings.reducedMotion) cam.shake(o.kind == ObjKind::Tree ? 1.2f : 0.8f);
      if (hp <= 0) { breakObject(m, oi, true); } else o.hp = (u16)hp;
      break;
    }
    case Act::Plant: {
      ItemStack& st = p.inv.slots[(size_t)p.sel];
      int ci = C().cropOfSeed(st.id);
      if (ci >= 0 && plantSeed(m, a.tile.x, a.tile.y, ci, 0)) { if (--st.count == 0) st = ItemStack(); audio->play(Sfx::Pick); emitEvent("plant", C().crops[(size_t)ci].id); }
      break;
    }
    case Act::Fertilize: {
      ItemStack& st = p.inv.slots[(size_t)p.sel];
      m.at(a.tile.x, a.tile.y).flags |= C().def(st.id).id == "fertilizer_rich" ? TF_Rich : TF_Fert;
      if (--st.count == 0) st = ItemStack();
      audio->play(Sfx::Pick); for (int i = 0; i < 4; ++i) fx.emit(Fx::Dust, at.x + rng.rangef(-5, 5), at.y, rng.rangef(-6, 6), -10, 0.5f, col::rgba(120, 90, 50, 200));
      break;
    }
    case Act::Place: {
      ItemStack& st = p.inv.slots[(size_t)p.sel];
      int od = C().obj(C().def(st.id).placeObj); if (od < 0) break;
      MapObject o; o.kind = C().objs[(size_t)od].kind; o.def = (u16)od; o.x = (i16)a.tile.x; o.y = (i16)a.tile.y; o.hp = (u16)C().objs[(size_t)od].hp;
      if (o.kind == ObjKind::Chest || o.kind == ObjKind::Collector) o.aux = (u32)m.newChest();
      if (m.addObject(o) >= 0) { if (--st.count == 0) st = ItemStack(); audio->play(Sfx::Pop); if (o.kind == ObjKind::Fence) { /* neighbours re-evaluate at render */ } emitEvent("place", C().objs[(size_t)od].id); }
      break;
    }
    case Act::Harvest: { int oi = m.objectAt(a.tile.x, a.tile.y); if (oi >= 0) harvestCrop(m, oi); break; }
    case Act::Pick: {
      int oi = m.objectAt(a.tile.x, a.tile.y); if (oi < 0) break;
      MapObject o = m.objs[(size_t)oi];
      if (o.kind == ObjKind::Wisp) { m.removeObject(oi); setFlag(fmt("wisp_%u_taken", (unsigned)o.aux)); ItemStack st; st.id = (u16)C().item("wisp_spark"); st.count = 1; giveItem(st); audio->play(Sfx::Sparkle);
        for (int i = 0; i < 8; ++i) fx.emit(Fx::Sparkle, at.x, at.y - 6, rng.rangef(-20, 20), rng.rangef(-30, -5), 0.6f); break; }
      ItemStack st; st.id = (u16)o.aux; st.count = 1;
      int lv = p.level(3); float g = 0.04f + 0.04f * (float)lv; st.quality = (u8)(rng.chance(g) ? (rng.chance(0.3f) ? 2 : 1) : 0);
      if (!p.inv.canAdd(st)) { toast("Inventory full."); break; }
      m.removeObject(oi); giveItem(st); addXp(3, 2); emitEvent("forage", C().def(st.id).id); s.counters["foraged"]++; audio->play(Sfx::Pick);
      for (int i = 0; i < 3; ++i) fx.emit(Fx::Sparkle, at.x + rng.rangef(-4, 4), at.y - 6, rng.rangef(-8, 8), rng.rangef(-20, -6), 0.5f);
      break;
    }
    case Act::Eat: { eatItem(p.sel); break; }
    case Act::Fish: startFishing(a.tile); break;
    case Act::Talk: if (a.ent >= 0) startTalk(a.ent); break;
    case Act::Pet: if (a.ent >= 0) petAnimal(s.animals[(size_t)a.ent]); break;
    case Act::Collect: if (a.ent >= 0) collectAnimal(s.animals[(size_t)a.ent]); break;
    case Act::Feed: if (a.ent >= 0) { ItemStack& st = p.inv.slots[(size_t)p.sel]; AnimalState& an = s.animals[(size_t)a.ent]; if (st.id && C().def(st.id).cat == Cat::Feed) { an.hunger = std::min(100, an.hunger + 55); an.happiness = std::min(100, an.happiness + 6); an.fed = true; if (--st.count == 0) st = ItemStack(); fx.emit(Fx::Heart, an.pos.x, an.pos.y - 12, 0, -14, 0.8f); audio->play(Sfx::Eat, 0.7f); } } break;
    case Act::Open: { int oi = m.objectAt(a.tile.x, a.tile.y); if (oi >= 0) { chestUi = ChestUI(); chestUi.obj = oi; push(St::Chest); audio->play(Sfx::Click); } break; }
    case Act::Ship: { chestUi = ChestUI(); chestUi.bin = true; push(St::Chest); audio->play(Sfx::Click); break; }
    case Act::Machine: { int oi = m.objectAt(a.tile.x, a.tile.y); if (oi >= 0) useMachine(m, oi); break; }
    case Act::Sleep: { confirm.text = "Go to sleep and start a new day?"; confirm.id = 1; push(St::Confirm); break; }
    case Act::Cook: { menu = MenuUI(); menu.tab = 1; menu.cookMode = 1; push(St::Menu); break; }
    case Act::Read: {
      int oi = m.objectAt(a.tile.x, a.tile.y); std::string id = oi >= 0 ? objDef(m.objs[(size_t)oi]).id : "";
      msg.title = "Signpost"; msg.back = St::Gameplay;
      if (m.id == "farm") msg.text = "Brightbrook Farm\nNorth: Hollowood Forest\nEast: Thistledown village";
      else if (m.id == "forest") msg.text = "Hollowood Forest\nA huge old log blocks the eastern trail. Only a strong axe could split it.\nSomething hums on the other side...";
      else if (m.id == "village") msg.text = "Thistledown Village\nNorth: Hollowood Forest   South: Marlowe Shore\nEast: the old mine";
      else msg.text = "Welcome, traveller.";
      push(St::Message); break;
    }
    case Act::Board: { menu = MenuUI(); menu.tab = 2; push(St::Menu); break; }
    case Act::Lantern: {
      msg.title = "The Great Lantern"; msg.back = St::Gameplay;
      msg.text = flag("lantern_restored") ? "The Great Lantern glows warm and steady. Tiny wisps dance in its light."
                                          : "The Great Lantern is cold and dark. Three crystal sockets sit empty in its base.\nMaeve says wisp sparks and lantern crystals might wake it.";
      push(St::Message); break;
    }
    case Act::Barn: {
      for (size_t bi = 0; bi < m.buildings.size(); ++bi) { const BuildingDef& bd = C().buildings[(size_t)m.buildings[bi].def]; if (!bd.animals.empty() && a.tile.x == m.buildings[bi].x + bd.door && a.tile.y == m.buildings[bi].y) { animalUi = AnimalUI(); animalUi.building = (int)bi; push(St::Animals); audio->play(Sfx::Door); break; } }
      break;
    }
    case Act::Ladder: useLadder(); break;
    case Act::Treasure: {
      int oi = m.objectAt(a.tile.x, a.tile.y); if (oi < 0) break;
      MapObject& o = m.objs[(size_t)oi]; if (o.state) { toast("It's empty."); break; }
      o.state = 1; audio->play(Sfx::Sparkle);
      bool crystal = o.aux == 1;
      if (crystal) { ItemStack st; st.id = (u16)C().item("lantern_crystal"); st.count = 1; giveItem(st); setFlag("crystal_deep_taken"); }
      addMoney(rng.range(80, 250) + m.mineFloor * 20);
      const char* loot[] = {"iron_ore", "coal", "amethyst", "topaz", "gold_ore", "silver_ore"};
      ItemStack st; st.id = (u16)C().item(loot[rng.range(0, std::min(5, 1 + m.mineFloor / 4))]); st.count = (u16)rng.range(1, 3); giveItem(st);
      for (int i = 0; i < 10; ++i) fx.emit(Fx::Sparkle, at.x + rng.rangef(-8, 8), at.y - 6, rng.rangef(-20, 20), rng.rangef(-35, -8), 0.7f);
      break;
    }
    case Act::Shrine: {
      if (!flag("crystal_grove_taken")) {
        setFlag("crystal_grove_taken"); ItemStack st; st.id = (u16)C().item("lantern_crystal"); st.count = 1; giveItem(st); audio->play(Sfx::Sparkle);
        showDialogue("The Shrine", "", "", "The wisp shrine hums. A warm crystal rises from the stone and settles into your hands. It glows like a captured sunrise.");
        for (int i = 0; i < 14; ++i) fx.emit(Fx::Sparkle, at.x + rng.rangef(-12, 12), at.y - 10, rng.rangef(-20, 20), rng.rangef(-30, -5), 0.9f);
      } else showDialogue("The Shrine", "", "", "The shrine rests quietly. Little blue lights drift around it like sleepy fireflies.");
      break;
    }
    default: break;
  }
}
}  // namespace cf
