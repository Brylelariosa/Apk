// Game calendar and clock. A day runs 6:00 -> 26:00 (2 AM) in 20 "game hours".
#pragma once
#include "items/content.h"

namespace cf {
constexpr int kDayStart = 360, kDayEnd = 1560, kDaysPerSeason = 28;

struct Calendar {
  int year = 1, season = 0, day = 1, minutes = kDayStart;
  float acc = 0;                       // fractional game minutes
  int totalDays() const { return (year - 1) * 4 * kDaysPerSeason + season * kDaysPerSeason + day; }
  int dayOfWeek() const { return (totalDays() - 1) % 7; }         // 0 = Monday
  bool nextDay() {                                              // returns true when the season changed
    minutes = kDayStart; acc = 0; ++day;
    if (day > kDaysPerSeason) { day = 1; ++season; if (season > 3) { season = 0; ++year; } return true; }
    return false;
  }
  std::string timeString() const { return clockString(minutes); }
  std::string dateString() const { return fmt("%s %d", kDayNamesPretty(dayOfWeek()), day); }
  static const char* kDayNamesPretty(int d) { static const char* n[7] = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}; return n[d % 7]; }
  static const char* seasonName(int s) { static const char* n[4] = {"Spring", "Summer", "Autumn", "Winter"}; return n[s & 3]; }
  int sunrise() const { static const int v[4] = {320, 290, 340, 360}; return v[season]; }
  int sunset() const { static const int v[4] = {1170, 1230, 1110, 1050}; return v[season]; }
  // 0 = deep night, 1 = full daylight (smooth 90 minute dawn/dusk)
  float daylight() const {
    float m = (float)minutes;
    float rise = clampv((m - (float)sunrise()) / 70.f + 0.5f, 0.f, 1.f), set = clampv(((float)sunset() - m) / 90.f + 0.5f, 0.f, 1.f);
    return smooth01(std::min(rise, set));
  }
  float twilight() const {   // warm orange amount around sunrise/sunset
    float m = (float)minutes, a = 1.f - clampv(std::fabs(m - (float)sunset()) / 70.f, 0.f, 1.f), b = 1.f - clampv(std::fabs(m - (float)sunrise()) / 60.f, 0.f, 1.f);
    return std::max(a, b);
  }
};
}  // namespace cf
