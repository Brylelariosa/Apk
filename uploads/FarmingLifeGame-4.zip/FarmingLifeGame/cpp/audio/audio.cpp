#include "audio/audio.h"
#include <functional>
#include <cmath>

namespace cf {
static const float kPi = 3.14159265f;
float Audio::noise() { rng_ = rng_ * 1664525u + 1013904223u; return (float)((rng_ >> 9) & 0xFFFF) / 32768.f - 1.f; }

void Audio::synthAll() {
  const float R = (float)kRate;
  auto gen = [&](Sfx id, float dur, const std::function<float(float, float)>& f) {
    std::vector<short>& v = bank_[(int)id]; int n = (int)(dur * R); v.resize((size_t)n);
    for (int i = 0; i < n; ++i) { float t = (float)i / R, u = (float)i / (float)n; float x = f(t, u); v[(size_t)i] = (short)(clampv(x, -1.f, 1.f) * 30000.f); }
  };
  float lp = 0; auto lowpass = [&](float x, float a) { lp += a * (x - lp); return lp; };
  auto env = [](float u, float k) { return std::exp(-u * k); };
  gen(Sfx::Click, 0.05f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * 1500 * t) * env(u, 7); });
  gen(Sfx::Back, 0.09f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * (900 - 400 * u) * t) * env(u, 4); });
  gen(Sfx::Confirm, 0.16f, [&](float t, float u) { return 0.45f * std::sin(2 * kPi * (u < 0.5f ? 660.f : 880.f) * t) * env(std::fmod(u * 2, 1.f), 3); });
  gen(Sfx::Coin, 0.22f, [&](float t, float u) { float f = u < 0.35f ? 1318.f : 1760.f; return 0.4f * (std::sin(2 * kPi * f * t) + 0.3f * std::sin(4 * kPi * f * t)) * env(std::fmod(u * 2.86f, 1.f), 4) * (u < 0.35f ? 1.f : env(u - 0.35f, 6)); });
  gen(Sfx::Step, 0.07f, [&](float, float u) { lp = 0; return 0.35f * lowpass(noise(), 0.25f) * env(u, 6); });
  gen(Sfx::Hoe, 0.18f, [&](float t, float u) { return 0.6f * std::sin(2 * kPi * (110 - 50 * u) * t) * env(u, 6) + 0.3f * lowpass(noise(), 0.3f) * env(u, 9); });
  gen(Sfx::Water, 0.4f, [&](float t, float u) { return 0.35f * lowpass(noise(), 0.12f + 0.1f * std::sin(t * 30)) * std::sin(kPi * u); });
  gen(Sfx::Chop, 0.14f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * 200 * t) * env(u, 9) + 0.4f * noise() * env(u, 25); });
  gen(Sfx::Mine, 0.2f, [&](float t, float u) { return 0.3f * (std::sin(2 * kPi * 1850 * t) + std::sin(2 * kPi * 2490 * t)) * env(u, 9) + 0.35f * noise() * env(u, 40); });
  gen(Sfx::Harvest, 0.12f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * (400 + 600 * u) * t) * env(u, 3); });
  gen(Sfx::Pick, 0.1f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * 880 * t) * env(u, 6); });
  gen(Sfx::Splash, 0.3f, [&](float, float u) { return 0.5f * lowpass(noise(), 0.5f - 0.4f * u) * env(u, 3); });
  gen(Sfx::Cast, 0.25f, [&](float, float u) { return 0.4f * lowpass(noise(), 0.05f + 0.4f * u) * std::sin(kPi * u); });
  gen(Sfx::Reel, 0.25f, [&](float t, float u) { return (std::fmod(t * 24.f, 1.f) < 0.15f ? 0.4f : 0.f) * noise() * (1 - u); });
  gen(Sfx::Catch, 0.4f, [&](float t, float u) { static const float n[4] = {523.f, 659.f, 784.f, 1047.f}; int k = std::min(3, (int)(u * 4)); return 0.4f * std::sin(2 * kPi * n[k] * t) * env(std::fmod(u * 4, 1.f), 3); });
  gen(Sfx::Door, 0.3f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * 100 * t) * env(u, 7) + 0.15f * std::sin(2 * kPi * (320 - 100 * u) * t) * std::sin(kPi * u); });
  gen(Sfx::Error, 0.16f, [&](float t, float u) { return 0.3f * (std::sin(2 * kPi * 160 * t) > 0 ? 1.f : -1.f) * env(u, 4); });
  gen(Sfx::Eat, 0.3f, [&](float, float u) { float p = std::fmod(u * 3, 1.f); return 0.5f * lowpass(noise(), 0.35f) * (p < 0.4f ? 1 - p / 0.4f : 0.f); });
  gen(Sfx::Ladder, 0.3f, [&](float t, float u) { static const float n[3] = {440.f, 330.f, 262.f}; int k = std::min(2, (int)(u * 3)); return 0.4f * std::sin(2 * kPi * n[k] * t) * env(std::fmod(u * 3, 1.f), 4); });
  gen(Sfx::Pop, 0.07f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * (650 - 350 * u) * t) * env(u, 4); });
  gen(Sfx::Moo, 0.7f, [&](float t, float u) { float f = 120 - 25 * u + 3 * std::sin(t * 40); float saw = std::fmod(t * f, 1.f) * 2 - 1; return 0.5f * lowpass(saw, 0.07f) * std::sin(kPi * u); });
  gen(Sfx::Cluck, 0.22f, [&](float t, float u) { float k = std::fmod(u * 3, 1.f); return 0.4f * std::sin(2 * kPi * (800 - 300 * k) * t) * (k < 0.5f ? 1.f : 0.f) * (1 - u); });
  gen(Sfx::Baa, 0.5f, [&](float t, float u) { float f = 330 + 8 * std::sin(t * 55); float saw = std::fmod(t * f, 1.f) * 2 - 1; return 0.35f * lowpass(saw, 0.18f) * std::sin(kPi * u); });
  gen(Sfx::Quack, 0.3f, [&](float t, float u) { float k = std::fmod(u * 2, 1.f); float sq = std::sin(2 * kPi * 480 * t) > 0 ? 1.f : -1.f; return 0.28f * lowpass(sq, 0.2f) * (k < 0.55f ? 1.f : 0.f); });
  gen(Sfx::Squeak, 0.1f, [&](float t, float u) { return 0.35f * std::sin(2 * kPi * (1800 + 600 * u) * t) * env(u, 4); });
  gen(Sfx::Thunder, 1.9f, [&](float, float u) { return 0.8f * lowpass(noise(), 0.03f) * env(u, 2.2f) * (0.6f + 0.4f * std::sin(u * 40)); });
  gen(Sfx::Chime, 0.9f, [&](float t, float u) { return 0.28f * (std::sin(2 * kPi * 1047 * t) + 0.6f * std::sin(2 * kPi * 1568 * t) + 0.4f * std::sin(2 * kPi * 2093 * t)) * env(u, 4.5f); });
  gen(Sfx::Sparkle, 0.35f, [&](float t, float u) { static const float n[3] = {2093.f, 2637.f, 3136.f}; int k = std::min(2, (int)(u * 3)); return 0.25f * std::sin(2 * kPi * n[k] * t) * env(std::fmod(u * 3, 1.f), 5); });
  gen(Sfx::Hurt, 0.2f, [&](float t, float u) { return 0.5f * std::sin(2 * kPi * (150 - 70 * u) * t) * env(u, 5) + 0.3f * noise() * env(u, 12); });
}

void Audio::init() { std::lock_guard<std::mutex> l(m_); synthAll(); ready_ = true; }
void Audio::play(Sfx s, float vol, float pitch) {
  std::lock_guard<std::mutex> l(m_);
  if (!ready_ || paused_) return;
  const std::vector<short>& d = bank_[(int)s]; if (d.empty()) return;
  Voice* slot = nullptr; for (auto& v : voices_) if (!v.active) { slot = &v; break; }
  if (!slot) { slot = &voices_[0]; for (auto& v : voices_) if (v.pos > slot->pos) slot = &v; }
  slot->data = &d; slot->pos = 0; slot->step = pitch; slot->vol = vol; slot->active = true;
}
void Audio::setMood(const Mood& m) { std::lock_guard<std::mutex> l(m_); mood_ = m; }

void Audio::musicStep(int, float*) {}

int Audio::render(short* out, int frames) {
  std::lock_guard<std::mutex> l(m_);
  if (!ready_ || paused_) { memset(out, 0, sizeof(short) * (size_t)frames); return frames; }
  const float R = (float)kRate; const Mood& md = mood_;
  // ---- musical parameters from the mood
  static const float pent[2][5] = {{0, 2, 4, 7, 9}, {0, 3, 5, 7, 10}};
  static const float roots[4] = {261.63f, 293.66f, 220.f, 164.81f};
  bool minor = md.season >= 2 || md.night || md.place == 4;
  float root = roots[md.season & 3] * (md.place == 4 ? 0.5f : 1.f);
  float tempo = md.festival ? 124.f : (md.place == 4 ? 62.f : (md.place == 5 ? 76.f : 70.f + 8.f * (float)(md.season == 1) + 10.f * (float)(md.season == 0)));
  if (md.night) tempo *= 0.82f; if (md.weather == 2 || md.weather == 3 || md.weather == 4) tempo *= 0.88f;
  float density = md.festival ? 0.75f : (md.place == 4 ? 0.18f : (md.night ? 0.3f : (md.weather >= 2 && md.weather <= 4 ? 0.36f : 0.55f)));
  static const int prog[2][4] = {{0, 3, 4, 3}, {0, 2, 3, 4}};
  const int* pg = prog[minor ? 1 : 0];
  float tRain = (!md.indoors && (md.weather == 2 || md.weather == 3 || md.weather == 4)) ? (md.weather == 2 ? 0.35f : 0.6f) : 0.f;
  float tWind = (!md.indoors && (md.weather == 6 || md.weather == 4)) ? 0.5f : (md.place == 3 ? 0.15f : 0.f);
  float tBird = (!md.indoors && !md.night && md.weather <= 1 && md.season != 3 && md.place != 4) ? 0.25f : 0.f;
  float tCricket = (!md.indoors && md.night && md.season != 3 && md.weather <= 1) ? 0.12f : 0.f;
  for (int i = 0; i < frames; ++i) {
    // ----- smooth ambience levels
    curRain_ += (tRain - curRain_) * 0.0002f; curWind_ += (tWind - curWind_) * 0.0002f; curBird_ += (tBird - curBird_) * 0.0002f; curCricket_ += (tCricket - curCricket_) * 0.0002f;
    // ----- sequencer (eighth notes)
    beatT_ += (double)tempo / 30.0 / (double)R;
    if (beatT_ >= 1.0) {
      beatT_ -= 1.0; ++beat_; int e = beat_ & 7;
      if (e == 0) ++bar_;
      int chord = pg[(bar_ >> 0) & 3];
      auto semis = [&](int deg) { int o = deg / 5; int d = ((deg % 5) + 5) % 5; return pent[minor ? 1 : 0][d] + 12.f * (float)o; };
      if (e == 0 || e == 4) { bassFreq_ = root * 0.5f * std::pow(2.f, semis(chord) / 12.f); bassEnv_ = 1.f; }
      float r01 = (float)((rng_ = rng_ * 1664525u + 1013904223u) >> 8 & 0xFFFF) / 65535.f;
      if (r01 < density && (e % 2 == 0 || r01 < density * 0.5f)) {
        int deg = chord + (int)((rng_ >> 5) % 5) - 1 + 5; melodyFreq_ = root * std::pow(2.f, semis(deg) / 12.f); melodyEnv_ = 1.f;
      }
      for (int k = 0; k < 3; ++k) { padPhase_[k] = padPhase_[k]; }
      padLevel_ = 1.f;
    }
    float chordRoot = root * std::pow(2.f, (pent[minor ? 1 : 0][pg[bar_ & 3] % 5]) / 12.f);
    // ----- instruments
    float mel = 0, bass = 0, pad = 0;
    if (melodyEnv_ > 0.001f) { melodyPhase_ += melodyFreq_ / R; if (melodyPhase_ > 1) melodyPhase_ -= 1; float tri = 4.f * std::fabs(melodyPhase_ - 0.5f) - 1.f; mel = (0.6f * tri + 0.4f * std::sin(2 * kPi * melodyPhase_)) * melodyEnv_ * 0.16f; melodyEnv_ *= 0.99985f - 0.00008f * (float)(md.place == 4); }
    if (bassEnv_ > 0.001f) { bassPhase_ += bassFreq_ / R; if (bassPhase_ > 1) bassPhase_ -= 1; bass = std::sin(2 * kPi * bassPhase_) * bassEnv_ * 0.18f; bassEnv_ *= 0.99992f; }
    for (int k = 0; k < 3; ++k) { static const float ratio[3] = {1.f, 1.5f, 2.f}; padPhase_[k] += chordRoot * ratio[k] / R * (0.5f); if (padPhase_[k] > 1) padPhase_[k] -= 1; pad += std::sin(2 * kPi * padPhase_[k]) * 0.035f; }
    float music = (mel + bass + pad * (md.place == 4 ? 1.6f : 1.f)) * musicVol_;
    // ----- ambience
    float amb = 0;
    if (curRain_ > 0.002f) { float n = noise(); lp1_ += 0.35f * (n - lp1_); lp2_ += 0.06f * (n - lp2_); amb += (lp1_ * 0.55f + lp2_ * 0.9f) * curRain_ * 0.5f; }
    if (curWind_ > 0.002f) { float n = noise(); lpWind_ += 0.01f * (n - lpWind_); amb += lpWind_ * curWind_ * 3.5f * (0.6f + 0.4f * std::sin(beatT_ * 0.4f + bar_ * 0.7f)); }
    if (curBird_ > 0.002f) {
      birdT_ -= 1.f / R; if (birdT_ < 0) { birdT_ = 0.6f + (float)((rng_ = rng_ * 1664525u + 1013904223u) >> 8 & 0xFFFF) / 65535.f * 5.f; birdEnv_ = 1.f; birdFreq_ = 2200.f + (float)((rng_ >> 4) & 0x3FF); }
      if (birdEnv_ > 0.002f) { birdPh_ += (birdFreq_ + 900.f * std::sin(birdEnv_ * 30.f)) / R; amb += std::sin(2 * kPi * birdPh_) * birdEnv_ * curBird_ * 0.18f; birdEnv_ *= 0.9993f; }
    }
    if (curCricket_ > 0.002f) { cricketPh_ += 4300.f / R; if (cricketPh_ > 1) cricketPh_ -= 1; float g = std::fmod((float)beat_ * 0.05f + (float)i / R * 6.f, 1.f) < 0.45f ? 1.f : 0.f; amb += std::sin(2 * kPi * cricketPh_) * g * curCricket_ * 0.12f; }
    float mix = music + amb * musicVol_ * 1.3f;
    // ----- sfx voices
    for (auto& v : voices_) {
      if (!v.active) continue;
      size_t ip = (size_t)v.pos; if (ip + 1 >= v.data->size()) { v.active = false; continue; }
      float fr = v.pos - (float)ip; float smp = ((float)(*v.data)[ip] * (1.f - fr) + (float)(*v.data)[ip + 1] * fr) / 32768.f;
      mix += smp * v.vol * sfxVol_; v.pos += v.step;
    }
    mix = clampv(mix, -1.f, 1.f);
    out[i] = (short)(mix * 30000.f);
  }
  return frames;
}
}  // namespace cf
