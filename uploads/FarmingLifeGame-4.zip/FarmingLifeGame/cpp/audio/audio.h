// Software mixer with procedurally synthesised sound effects, ambience and generative music (no audio files needed).
#pragma once
#include <mutex>
#include "engine/types.h"
namespace cf {
enum class Sfx : u8 { Click, Back, Confirm, Coin, Step, Hoe, Water, Chop, Mine, Harvest, Pick, Splash, Cast, Reel, Catch, Door, Error, Eat, Ladder, Pop, Moo, Cluck, Baa, Quack, Squeak,
                      Thunder, Chime, Sparkle, Hurt, Count };
struct Mood { int season = 0; int weather = 0; bool night = false; int place = 0; bool festival = false; bool indoors = false; };   // place: 0 farm 1 village 2 forest 3 shore 4 mine 5 home
class Audio {
 public:
  static constexpr int kRate = 22050;
  void init();
  void play(Sfx s, float vol = 1.f, float pitch = 1.f);
  void setMood(const Mood& m);
  void setVolumes(float music, float sfx) { std::lock_guard<std::mutex> l(m_); musicVol_ = music; sfxVol_ = sfx; }
  void setPaused(bool p) { std::lock_guard<std::mutex> l(m_); paused_ = p; }
  int render(short* out, int frames);          // called from the audio thread
 private:
  struct Voice { const std::vector<short>* data = nullptr; float pos = 0, step = 1, vol = 0; bool active = false; };
  void synthAll();
  void musicStep(int frames, float* mix);
  float noise();
  std::mutex m_;
  std::vector<short> bank_[(int)Sfx::Count];
  Voice voices_[12];
  Mood mood_;
  bool ready_ = false, paused_ = false;
  float musicVol_ = 0.7f, sfxVol_ = 0.9f;
  // music generator state
  double beatT_ = 0; int beat_ = 0, bar_ = 0; float melodyPhase_ = 0, melodyFreq_ = 0, melodyEnv_ = 0, bassPhase_ = 0, bassFreq_ = 0, bassEnv_ = 0, padPhase_[3] = {0, 0, 0};
  float padLevel_ = 0, rainLevel_ = 0, windLevel_ = 0, lp1_ = 0, lp2_ = 0, lpWind_ = 0, birdT_ = 0, birdEnv_ = 0, birdFreq_ = 0, birdPh_ = 0, cricketPh_ = 0;
  u32 rng_ = 12345;
  float curRain_ = 0, curWind_ = 0, curBird_ = 0, curCricket_ = 0;
};
}  // namespace cf
