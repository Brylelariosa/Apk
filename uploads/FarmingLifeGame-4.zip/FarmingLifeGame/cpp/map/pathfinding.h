#pragma once
#include "map/tilemap.h"
namespace cf {
// 4-neighbour A* over walkable tiles. Returns false when no route (path left empty).
bool findPath(const Map& m, IVec2 from, IVec2 to, std::vector<IVec2>& path, int maxNodes = 5000);
}
