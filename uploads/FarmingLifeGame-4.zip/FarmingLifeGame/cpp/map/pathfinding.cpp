#include "map/pathfinding.h"
#include <queue>

namespace cf {
bool findPath(const Map& m, IVec2 from, IVec2 to, std::vector<IVec2>& path, int maxNodes) {
  path.clear();
  if (!m.inBounds(from.x, from.y) || !m.inBounds(to.x, to.y)) return false;
  if (from == to) return true;
  static thread_local std::vector<int> gCost, parent;
  static thread_local std::vector<u8> state;
  size_t n = (size_t)m.w * m.h;
  gCost.assign(n, 0); parent.assign(n, -1); state.assign(n, 0);
  struct Node { int f, idx; bool operator<(const Node& o) const { return f > o.f; } };
  std::priority_queue<Node> open;
  auto idx = [&](int x, int y) { return y * m.w + x; };
  auto heur = [&](int x, int y) { return (std::abs(x - to.x) + std::abs(y - to.y)) * 10; };
  int s = idx(from.x, from.y), g = idx(to.x, to.y);
  gCost[(size_t)s] = 0; state[(size_t)s] = 1; open.push({heur(from.x, from.y), s});
  static const int dx[4] = {1, -1, 0, 0}, dy[4] = {0, 0, 1, -1};
  int visited = 0; int bestIdx = s, bestH = heur(from.x, from.y);
  while (!open.empty() && visited < maxNodes) {
    Node cur = open.top(); open.pop();
    if (state[(size_t)cur.idx] == 2) continue;
    state[(size_t)cur.idx] = 2; ++visited;
    if (cur.idx == g) { bestIdx = g; break; }
    int cx = cur.idx % m.w, cy = cur.idx / m.w;
    int h0 = heur(cx, cy); if (h0 < bestH) { bestH = h0; bestIdx = cur.idx; }
    for (int d = 0; d < 4; ++d) {
      int nx = cx + dx[d], ny = cy + dy[d];
      if (!m.inBounds(nx, ny)) continue;
      int ni = idx(nx, ny);
      if (state[(size_t)ni] == 2) continue;
      if (m.tileBlocked(nx, ny) && ni != g) continue;
      int ng = gCost[(size_t)cur.idx] + 10;
      if (state[(size_t)ni] == 1 && ng >= gCost[(size_t)ni]) continue;
      gCost[(size_t)ni] = ng; parent[(size_t)ni] = cur.idx; state[(size_t)ni] = 1;
      open.push({ng + heur(nx, ny), ni});
    }
  }
  if (bestIdx != g) { /* partial path towards the closest reachable tile */ }
  for (int c = bestIdx; c != s && c >= 0; c = parent[(size_t)c]) path.push_back(IVec2(c % m.w, c / m.w));
  std::reverse(path.begin(), path.end());
  return bestIdx == g;
}
}  // namespace cf
