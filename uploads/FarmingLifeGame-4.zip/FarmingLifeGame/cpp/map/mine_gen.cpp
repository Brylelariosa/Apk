// Procedural mine floors: cellular-automata caves, ore tiers by depth, hazards, ladders, treasure and hidden rooms.
#include "engine/log.h"
#include "engine/rng.h"
#include "game/game.h"

namespace cf {
namespace {
struct Pick { const char* id; int w; };
}

void Game::generateMine(int floor) {
  const int W = 46, H = 34;
  Map& m = *s.maps[fmt("mine_%d", floor)];
  Rng r((u64)Rng::hash((u32)s.seed, (u32)floor, (u32)s.cal.totalDays()));
  std::vector<u8> wall; std::vector<int> region;
  for (int attempt = 0; attempt < 12; ++attempt) {
    wall.assign((size_t)W * H, 0);
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) wall[(size_t)y * W + x] = (x < 2 || y < 2 || x >= W - 2 || y >= H - 2) ? 1 : (r.f() < 0.45f);
    for (int it = 0; it < 4; ++it) {
      std::vector<u8> nw = wall;
      for (int y = 1; y < H - 1; ++y) for (int x = 1; x < W - 1; ++x) {
        int n = 0; for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) n += wall[(size_t)(y + dy) * W + x + dx];
        nw[(size_t)y * W + x] = n >= 5 ? 1 : 0;
      }
      wall = nw;
    }
    // largest connected floor region
    std::vector<int> id((size_t)W * H, -1); int best = -1, bestN = 0, cur = 0;
    for (int i = 0; i < W * H; ++i) {
      if (wall[(size_t)i] || id[(size_t)i] >= 0) continue;
      std::vector<int> st{i}; id[(size_t)i] = cur; int n = 0;
      while (!st.empty()) {
        int c = st.back(); st.pop_back(); ++n;
        int cx = c % W, cy = c / W; const int dx[4] = {1, -1, 0, 0}, dy[4] = {0, 0, 1, -1};
        for (int d = 0; d < 4; ++d) { int nx = cx + dx[d], ny = cy + dy[d]; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; int ni = ny * W + nx; if (!wall[(size_t)ni] && id[(size_t)ni] < 0) { id[(size_t)ni] = cur; st.push_back(ni); } }
      }
      if (n > bestN) { bestN = n; best = cur; }
      ++cur;
    }
    region.clear();
    for (int i = 0; i < W * H; ++i) { if (!wall[(size_t)i] && id[(size_t)i] != best) wall[(size_t)i] = 1; else if (!wall[(size_t)i]) region.push_back(i); }
    if (bestN > 380) break;
  }
  m.init(W, H); m.id = fmt("mine_%d", floor); m.mineFloor = floor; m.indoor = true; m.outdoors = false; m.dark = true; m.music = "mine";
  m.title = fmt("The Mine - Floor %d", floor);
  for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) { Tile& t = m.at(x, y); t.terrain = wall[(size_t)y * W + x] ? Terrain::CaveWall : Terrain::Cave; t.variant = (u8)(Rng::hash((u32)x, (u32)y, 5) & 3); }
  // start (far left) and ladder (farthest by BFS)
  int startI = region[0]; for (int i : region) if (i % W < startI % W) startI = i;
  std::vector<int> dist((size_t)W * H, -1); std::vector<int> q{startI}; dist[(size_t)startI] = 0; int far = startI;
  for (size_t qi = 0; qi < q.size(); ++qi) {
    int c = q[qi], cx = c % W, cy = c / W; const int dx[4] = {1, -1, 0, 0}, dy[4] = {0, 0, 1, -1};
    for (int d = 0; d < 4; ++d) { int nx = cx + dx[d], ny = cy + dy[d]; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; int ni = ny * W + nx; if (!wall[(size_t)ni] && dist[(size_t)ni] < 0) { dist[(size_t)ni] = dist[(size_t)c] + 1; q.push_back(ni); if (dist[(size_t)ni] > dist[(size_t)far]) far = ni; } }
  }
  IVec2 st(startI % W, startI / W), ex(far % W, far / W);
  m.points.push_back({"start", st}); m.points.push_back({"spawn", st});
  auto place = [&](const char* id, int x, int y, u32 aux = 0, int state = 0) {
    int d = C().obj(id); if (d < 0) return -1;
    MapObject o; o.kind = C().objs[(size_t)d].kind; o.def = (u16)d; o.x = (i16)x; o.y = (i16)y; o.hp = (u16)C().objs[(size_t)d].hp; o.aux = aux; o.state = (u8)state;
    return m.addObject(o);
  };
  place("ladder", st.x, st.y, 0, 1);                       // up
  bool hidden = r.chance(0.45f);
  if (hidden) place("cave_rock", ex.x, ex.y, 1); else place("ladder", ex.x, ex.y, 0, 0);
  if (hidden) { m.objs[(size_t)m.objectAt(ex.x, ex.y)].aux = 1; }   // rock hides the ladder
  auto freeTile = [&](int minDistStart) {
    for (int k = 0; k < 80; ++k) {
      int i = region[(size_t)r.range(0, (int)region.size() - 1)], x = i % W, y = i / W;
      if (m.objectAt(x, y) >= 0 || std::abs(x - st.x) + std::abs(y - st.y) < minDistStart) continue;
      return IVec2(x, y);
    }
    return IVec2(-1, -1);
  };
  // solid non-breakable decor (crystals, chests) only goes into open areas so it can never seal a corridor
  auto openTile = [&](int minDist) {
    for (int k = 0; k < 160; ++k) {
      IVec2 t = freeTile(minDist); if (t.x < 0) break;
      bool open = true;
      for (int dy = -1; dy <= 1 && open; ++dy) for (int dx = -1; dx <= 1; ++dx) if (m.terrain(t.x + dx, t.y + dy) != Terrain::Cave || ((dx || dy) && m.objectAt(t.x + dx, t.y + dy) >= 0)) { open = false; break; }
      if (open) return t;
    }
    return IVec2(-1, -1);
  };
  // resource tables by depth
  std::vector<Pick> tbl;
  if (floor <= 5) tbl = {{"cave_rock", 60}, {"ore_copper", 26}, {"gem_quartz", 5}, {"coal_node", floor >= 3 ? 5 : 0}, {"ore_iron", floor >= 4 ? 6 : 0}};
  else if (floor <= 10) tbl = {{"cave_rock", 42}, {"ore_copper", 10}, {"ore_iron", 22}, {"ore_silver", floor >= 8 ? 9 : 0}, {"coal_node", 9}, {"gem_quartz", 5}, {"gem_amethyst", 5}, {"gem_topaz", 4}};
  else if (floor <= 15) tbl = {{"cave_rock", 34}, {"ore_iron", 12}, {"ore_silver", 20}, {"ore_gold", 12}, {"coal_node", 6}, {"gem_amethyst", 6}, {"gem_topaz", 5}, {"gem_aqua", 6}, {"gem_ruby", 3}};
  else tbl = {{"cave_rock", 28}, {"ore_silver", 10}, {"ore_gold", 20}, {"ore_star", 12}, {"coal_node", 5}, {"gem_aqua", 7}, {"gem_ruby", 8}, {"gem_moon", 4}, {"gem_amethyst", 6}};
  int total = 0; for (auto& p : tbl) total += p.w;
  int nres = 20 + r.range(0, 10) + floor / 3;
  for (int i = 0; i < nres; ++i) {
    IVec2 t = freeTile(4); if (t.x < 0) break;
    int pick = r.range(1, total), acc = 0; const char* id = tbl[0].id;
    for (auto& p : tbl) { acc += p.w; if (pick <= acc) { id = p.id; break; } }
    place(id, t.x, t.y);
  }
  if (floor >= 3) for (int i = 0, n = 3 + r.range(0, 3); i < n; ++i) { IVec2 t = freeTile(6); if (t.x >= 0) place("spikes", t.x, t.y, 0, r.range(0, 1)); }
  if (floor >= 6) for (int i = 0, n = 1 + r.range(0, 2); i < n; ++i) { IVec2 t = freeTile(8); if (t.x >= 0) place("hole", t.x, t.y); }
  for (int i = 0; i < 5; ++i) { bool crystal = r.chance(0.5f); IVec2 t = crystal ? openTile(0) : freeTile(0); if (t.x >= 0) place(crystal ? "glow_crystal" : "torch_wall", t.x, t.y); }
  place("torch_wall", st.x + 1, st.y); place("torch_wall", st.x, st.y + 1);
  if (r.chance(0.18f) || (floor == 10 && !flag("crystal_deep_taken"))) {
    IVec2 t = openTile(10); if (t.x < 0) t = freeTile(10); if (t.x >= 0) place("mine_chest", t.x, t.y, floor == 10 && !flag("crystal_deep_taken") ? 1 : 0);
  }
  // hidden chamber behind a cracked wall
  if (floor >= 2 && r.chance(0.3f)) {
    for (int k = 0; k < 300; ++k) {
      int i = region[(size_t)r.range(0, (int)region.size() - 1)], x = i % W, y = i / W;
      if (x + 8 >= W - 2 || y < 4 || y + 3 >= H - 2 || m.objectAt(x, y) >= 0 || m.objectAt(x + 1, y) >= 0) continue;
      bool ok = true;
      for (int yy = y - 2; yy <= y + 2 && ok; ++yy) for (int xx = x + 1; xx <= x + 7; ++xx) if (m.terrain(xx, yy) != Terrain::CaveWall) { ok = false; break; }
      if (!ok) continue;
      for (int yy = y - 1; yy <= y + 1; ++yy) for (int xx = x + 3; xx <= x + 6; ++xx) m.at(xx, yy).terrain = Terrain::Cave;
      m.at(x + 1, y).terrain = Terrain::Cave; m.at(x + 2, y).terrain = Terrain::Cave;
      place("crack_wall", x + 1, y);
      place("mine_chest", x + 6, y, 0); place(floor >= 8 ? "gem_ruby" : "gem_amethyst", x + 4, y - 1); place("torch_wall", x + 3, y + 1);
      break;
    }
  }
}

void Game::useLadder() {
  Map& m = map(); IVec2 t = playerTile(); int fl = m.mineFloor;
  for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) {
    int oi = m.objectAt(t.x + dx, t.y + dy); if (oi < 0) continue;
    MapObject& o = m.objs[(size_t)oi];
    if (o.kind != ObjKind::Ladder) continue;
    if (o.state == 1) { if (fl <= 1) enterMap("village", "from_mine"); else descendMine(fl - 1); return; }
    descendMine(fl + 1); return;
  }
}
void Game::descendMine(int floor) {
  audio->play(Sfx::Ladder);
  if (floor > 1 && floor > s.deepestMine && floor % 5 == 0) toast(fmt("New depth reached: floor %d!", floor), "ic_s_autumn");
  s.maps.erase(fmt("mine_%d", floor));
  enterMap(fmt("mine_%d", floor), "start");
}
}  // namespace cf
