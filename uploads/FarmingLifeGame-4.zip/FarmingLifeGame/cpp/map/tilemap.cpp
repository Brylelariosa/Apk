#include "map/tilemap.h"
#include "engine/rng.h"
#include "engine/log.h"

namespace cf {
const ObjDef& objDef(const MapObject& o) { return C().objs[o.def < C().objs.size() ? o.def : 0]; }

void Map::init(int W, int H) {
  w = W; h = H;
  tiles.assign((size_t)W * H, Tile());
  objAt.assign((size_t)W * H, -1);
  solid.assign((size_t)W * H, 0);
  objs.clear(); freeList.clear();
}

static bool objSolid(const MapObject& o) {
  if (o.kind == ObjKind::Crop || o.kind == ObjKind::Forage) return false;
  return objDef(o).solid;
}

bool Map::tileBlocked(int x, int y) const {
  if (!inBounds(x, y)) return true;
  size_t i = (size_t)y * w + x;
  if (!terrainWalkable(tiles[i].terrain) || solid[i]) return true;
  int o = objAt[i];
  return o >= 0 && objSolid(objs[(size_t)o]);
}

static void footprint(const MapObject& o, int& x0, int& y0, int& fw, int& fh) {
  fw = 1; fh = 1;
  if (o.kind != ObjKind::Crop && o.kind != ObjKind::Forage) { const ObjDef& d = objDef(o); fw = d.fw; fh = d.fh; }
  x0 = o.x; y0 = o.y - fh + 1;
}

int Map::addObject(const MapObject& o) {
  int x0, y0, fw, fh; footprint(o, x0, y0, fw, fh);
  for (int yy = y0; yy < y0 + fh; ++yy)
    for (int xx = x0; xx < x0 + fw; ++xx)
      if (!inBounds(xx, yy) || objAt[(size_t)yy * w + xx] >= 0) return -1;
  int idx;
  if (!freeList.empty()) { idx = freeList.back(); freeList.pop_back(); objs[(size_t)idx] = o; }
  else { idx = (int)objs.size(); objs.push_back(o); }
  for (int yy = y0; yy < y0 + fh; ++yy)
    for (int xx = x0; xx < x0 + fw; ++xx) objAt[(size_t)yy * w + xx] = idx;
  return idx;
}

void Map::removeObject(int idx) {
  if (idx < 0 || idx >= (int)objs.size() || !objs[(size_t)idx].alive()) return;
  int x0, y0, fw, fh; footprint(objs[(size_t)idx], x0, y0, fw, fh);
  for (int yy = y0; yy < y0 + fh; ++yy)
    for (int xx = x0; xx < x0 + fw; ++xx) if (inBounds(xx, yy) && objAt[(size_t)yy * w + xx] == idx) objAt[(size_t)yy * w + xx] = -1;
  objs[(size_t)idx] = MapObject();
  freeList.push_back(idx);
}

void Map::rebuildObjIndex() {
  std::fill(objAt.begin(), objAt.end(), -1);
  freeList.clear();
  for (size_t i = 0; i < objs.size(); ++i) {
    if (!objs[i].alive()) { freeList.push_back((int)i); continue; }
    int x0, y0, fw, fh; footprint(objs[i], x0, y0, fw, fh);
    for (int yy = y0; yy < y0 + fh; ++yy)
      for (int xx = x0; xx < x0 + fw; ++xx) if (inBounds(xx, yy)) objAt[(size_t)yy * w + xx] = (int)i;
  }
}

const MapRegion* Map::regionAt(int x, int y, const char* prefix) const {
  size_t pl = strlen(prefix);
  for (auto& r : regions) if (r.contains(x, y) && r.name.compare(0, pl, prefix) == 0) return &r;
  return nullptr;
}
std::string Map::waterTypeAt(int x, int y) const {
  for (auto& r : regions) if (!r.water.empty() && r.contains(x, y)) return r.water;
  return "lake";
}
bool Map::canTill(int x, int y) const {
  if (!tillable || !inBounds(x, y)) return false;
  const Tile& t = at(x, y);
  if ((t.terrain != Terrain::Grass && t.terrain != Terrain::Dirt) || solid[(size_t)y * w + x]) return false;
  return objAt[(size_t)y * w + x] < 0;
}
void Map::markBuilding(const BuildingInst& b, bool on) {
  const BuildingDef& d = C().buildings[(size_t)b.def];
  for (int yy = b.y - d.h + 1; yy <= b.y; ++yy)
    for (int xx = b.x; xx < b.x + d.w; ++xx) if (inBounds(xx, yy)) solid[(size_t)yy * w + xx] = on ? 1 : 0;
}

bool Map::loadFromText(const std::string& text, const std::string& name) {
  size_t pos = 0; bool ok = false; int lineNo = 0;
  auto nextLine = [&](std::string& out) {
    if (pos >= text.size()) return false;
    size_t e = text.find('\n', pos); if (e == std::string::npos) e = text.size();
    out = text.substr(pos, e - pos); pos = e + 1; ++lineNo;
    if (!out.empty() && out.back() == '\r') out.pop_back();
    return true;
  };
  std::string line;
  while (nextLine(line)) {
    auto t = splitString(line, ' ');
    if (t.empty()) continue;
    if (t[0] == "map" && t.size() >= 4) { id = t[1]; init(atoi(t[2].c_str()), atoi(t[3].c_str())); ok = true; }
    else if (!ok) continue;
    else if (t[0] == "prop" && t.size() >= 3) {
      std::string v = line.substr(line.find(t[1]) + t[1].size() + 1);
      if (!v.empty() && v[0] == '"') v = v.substr(1, v.size() - 2);
      if (t[1] == "title") title = v; else if (t[1] == "music") music = v;
      else if (t[1] == "tillable") tillable = v == "1"; else if (t[1] == "indoor") indoor = v == "1";
      else if (t[1] == "outdoors") outdoors = v == "1"; else if (t[1] == "forage") forageCount = atoi(v.c_str());
      else if (t[1] == "weedspawn") weeds = v == "1"; else if (t[1] == "dark") dark = v == "1";
    } else if (t[0] == "terrain") {
      static const char* order = ".GDPSWOR" "FTCBLV";
      static const Terrain tmap[] = {Terrain::Void, Terrain::Grass, Terrain::Dirt, Terrain::Path, Terrain::Sand, Terrain::Water, Terrain::Deep, Terrain::Cliff,
                                     Terrain::FloorWood, Terrain::FloorStone, Terrain::Cave, Terrain::Bridge, Terrain::Wall, Terrain::CaveWall};
      for (int y = 0; y < h; ++y) {
        if (!nextLine(line)) break;
        for (int x = 0; x < w && x < (int)line.size(); ++x) {
          const char* p = strchr(order, line[(size_t)x]);
          Tile& tl = at(x, y);
          tl.terrain = p ? tmap[p - order] : Terrain::Void;
          tl.variant = (u8)(Rng::hash((u32)x, (u32)y, 77) & 3);
        }
      }
    } else if (t[0] == "obj" && t.size() >= 4) {
      int d = C().obj(t[1]);
      if (d < 0) { CF_LOGW("%s:%d unknown object %s", name.c_str(), lineNo, t[1].c_str()); continue; }
      MapObject o; o.kind = C().objs[(size_t)d].kind; o.def = (u16)d; o.x = (i16)atoi(t[2].c_str()); o.y = (i16)atoi(t[3].c_str()); o.hp = (u16)C().objs[(size_t)d].hp;
      if (o.kind == ObjKind::Chest) o.aux = (u32)newChest();
      addObject(o);
    } else if (t[0] == "building" && t.size() >= 5) {
      int d = C().building(t[1]);
      if (d < 0) { CF_LOGW("%s:%d unknown building %s", name.c_str(), lineNo, t[1].c_str()); continue; }
      BuildingInst b; b.def = d; b.x = atoi(t[2].c_str()); b.y = atoi(t[3].c_str()); b.level = atoi(t[4].c_str());
      markBuilding(b, true); buildings.push_back(b);
    } else if (t[0] == "point" && t.size() >= 4) points.push_back({t[1], IVec2(atoi(t[2].c_str()), atoi(t[3].c_str()))});
    else if (t[0] == "warp" && t.size() >= 7) {
      Warp wp; wp.pos = IVec2(atoi(t[1].c_str()), atoi(t[2].c_str())); wp.w = atoi(t[3].c_str()); wp.h = atoi(t[4].c_str()); wp.toMap = t[5]; wp.toPoint = t[6]; warps.push_back(wp);
    } else if (t[0] == "region" && t.size() >= 6) {
      MapRegion r; r.name = t[1]; r.x = atoi(t[2].c_str()); r.y = atoi(t[3].c_str()); r.w = atoi(t[4].c_str()); r.h = atoi(t[5].c_str());
      for (size_t i = 6; i < t.size(); ++i) { if (t[i].rfind("water=", 0) == 0) r.water = t[i].substr(6); if (t[i] == "tillable=1") r.tillable = true; }
      regions.push_back(r);
    } else if (t[0] == "end") break;
  }
  // a building door tile that carries a warp must stay walkable; other doors stay blocked
  for (auto& b : buildings) { const BuildingDef& d = C().buildings[(size_t)b.def]; int dx = b.x + d.door, dy = b.y; if (inBounds(dx, dy) && warpAt(dx, dy)) solid[(size_t)dy * w + dx] = 0; }
  return ok;
}
}  // namespace cf
