// Tile maps: terrain layer, object layer (trees, crops, machines...), buildings, warps, named points and regions.
#pragma once
#include <memory>
#include "items/content.h"

namespace cf {
enum class Terrain : u8 { Void, Grass, Dirt, Path, Sand, Water, Deep, Cliff, FloorWood, FloorStone, Cave, Bridge, Wall, CaveWall };
inline bool terrainWalkable(Terrain t) { return t == Terrain::Grass || t == Terrain::Dirt || t == Terrain::Path || t == Terrain::Sand || t == Terrain::FloorWood || t == Terrain::FloorStone || t == Terrain::Cave || t == Terrain::Bridge; }
inline bool terrainWater(Terrain t) { return t == Terrain::Water || t == Terrain::Deep; }
enum TileFlag : u8 { TF_Tilled = 1, TF_Watered = 2, TF_Fert = 4, TF_Rich = 8 };

struct Tile { Terrain terrain = Terrain::Void; u8 variant = 0, flags = 0, pad = 0; };

struct MapObject {
  ObjKind kind = ObjKind::None;
  u8 state = 0;
  u16 def = 0;          // index into Content::objs (or Content::crops for ObjKind::Crop)
  i16 x = 0, y = 0;     // anchor = bottom-left footprint tile
  u16 hp = 0, days = 0;
  u32 aux = 0;
  u16 aux2 = 0;
  bool alive() const { return kind != ObjKind::None; }
};

struct Warp { IVec2 pos; int w = 1, h = 1; std::string toMap, toPoint; };
struct NamedPoint { std::string name; IVec2 pos; };
struct MapRegion { std::string name; int x = 0, y = 0, w = 0, h = 0; std::string water; bool tillable = false; bool contains(int px, int py) const { return px >= x && py >= y && px < x + w && py < y + h; } };
struct BuildingInst { int def = 0, level = 1, x = 0, y = 0, buildDays = 0; };   // anchor = bottom-left tile
struct ChestData { std::vector<ItemStack> slots; };

class Map {
 public:
  std::string id, title, music = "farm";
  int w = 0, h = 0, mineFloor = 0;
  bool indoor = false, outdoors = true, tillable = false, dark = false, weeds = false;
  int forageCount = 0;
  std::vector<Tile> tiles;
  std::vector<MapObject> objs;
  std::vector<int> freeList, objAt;       // objAt: object index per tile or -1
  std::vector<u8> solid;                  // extra solid tiles (buildings)
  std::vector<Warp> warps;
  std::vector<NamedPoint> points;
  std::vector<MapRegion> regions;
  std::vector<BuildingInst> buildings;
  std::vector<ChestData> chests;

  void init(int W, int H);
  bool inBounds(int x, int y) const { return x >= 0 && y >= 0 && x < w && y < h; }
  Tile& at(int x, int y) { return tiles[(size_t)y * w + x]; }
  const Tile& at(int x, int y) const { return tiles[(size_t)y * w + x]; }
  Terrain terrain(int x, int y) const { return inBounds(x, y) ? at(x, y).terrain : Terrain::Void; }
  int objectAt(int x, int y) const { return inBounds(x, y) ? objAt[(size_t)y * w + x] : -1; }
  bool tileBlocked(int x, int y) const;             // terrain, objects and buildings
  bool walkableTile(int x, int y) const { return !tileBlocked(x, y); }
  int addObject(const MapObject& o);                // returns index or -1 (footprint blocked)
  void removeObject(int idx);
  const NamedPoint* point(const std::string& n) const { for (auto& p : points) if (p.name == n) return &p; return nullptr; }
  const MapRegion* region(const std::string& n) const { for (auto& r : regions) if (r.name == n) return &r; return nullptr; }
  const MapRegion* regionAt(int x, int y, const char* prefixOrEmpty = "") const;
  std::string waterTypeAt(int x, int y) const;
  const Warp* warpAt(int x, int y) const { for (auto& wp : warps) if (x >= wp.pos.x && y >= wp.pos.y && x < wp.pos.x + wp.w && y < wp.pos.y + wp.h) return &wp; return nullptr; }
  bool canTill(int x, int y) const;
  int newChest() { chests.emplace_back(); return (int)chests.size() - 1; }
  void markBuilding(const BuildingInst& b, bool on);
  bool loadFromText(const std::string& text, const std::string& name);
  void rebuildObjIndex();
};

const ObjDef& objDef(const MapObject& o);
}  // namespace cf
