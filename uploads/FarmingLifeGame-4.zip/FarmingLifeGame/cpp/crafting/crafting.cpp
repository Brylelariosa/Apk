// Crafting, machines (processing chains), recipes, eating and buffs.
#include "game/game.h"

namespace cf {

bool Game::recipeUnlocked(const RecipeDef& r) const {
  if (s.recipes.count(r.id) || r.unlock == "default") return true;
  auto p = splitString(r.unlock, ':');
  if (p.size() >= 3 && p[0] == "hearts") { int ni = C().npc(p[1]); if (ni >= 0) return s.npcs[(size_t)ni].hearts() >= atoi(p[2].c_str()); }
  if (p.size() >= 2 && p[0] == "quest") { for (auto& q : s.quests) if (q.done && C().quests[(size_t)q.def].id == p[1]) return true; return false; }
  if (p.size() >= 2 && p[0] == "flag") return flag(p[1]);
  return false;
}
bool Game::canCraft(const RecipeDef& r) const {
  ItemStack out; out.id = (u16)r.out; out.count = (u16)r.outCount;
  return s.pl.inv.has(r.in) && s.pl.inv.canAdd(out);
}
std::vector<int> Game::unlockedRecipes(const std::string& station) const {
  std::vector<int> v;
  for (size_t i = 0; i < C().recipes.size(); ++i) if (C().recipes[i].station == station && recipeUnlocked(C().recipes[i])) v.push_back((int)i);
  return v;
}
bool Game::craft(int ri) {
  const RecipeDef& r = C().recipes[(size_t)ri];
  if (!canCraft(r)) { audio->play(Sfx::Error); return false; }
  s.pl.inv.take(r.in);
  ItemStack out; out.id = (u16)r.out; out.count = (u16)r.outCount;
  giveItem(out);
  s.recipes.insert(r.id);
  audio->play(r.station == "cook" ? Sfx::Pop : Sfx::Mine, 0.8f);
  emitEvent(r.station == "cook" ? "cook" : "craft", r.id);
  return true;
}

void Game::addBuff(const Buff& b) {
  if (b.type == BuffType::None) return;
  for (auto& x : s.pl.buffs) if (x.type == b.type) { x.amount = std::max(x.amount, b.amount); x.minutes = std::max(x.minutes, b.minutes); return; }
  ActiveBuff a; a.type = b.type; a.amount = b.amount; a.minutes = b.minutes; s.pl.buffs.push_back(a);
}

void Game::eatItem(int slot) {
  ItemStack& st = s.pl.inv.slots[(size_t)slot]; if (st.empty()) return;
  const ItemDef& d = C().def(st.id);
  if (!d.edible()) { toast("You can't eat that."); return; }
  float mul = 1.f + 0.25f * st.quality;
  s.pl.energy = std::min(s.pl.maxEnergy, s.pl.energy + (float)d.energy * mul);
  s.pl.health = std::min(s.pl.maxHealth, s.pl.health + (float)d.health * mul);
  if (d.buff.type != BuffType::None) { addBuff(d.buff); toast(fmt("%s +%d for %d min", buffName(d.buff.type), d.buff.amount, d.buff.minutes), "item_" + d.id); }
  audio->play(Sfx::Eat);
  s.pl.animKind = 5;
  emitEvent("eat", d.id);
  if (--st.count == 0) st = ItemStack();
  for (int i = 0; i < 3; ++i) fx.emit(Fx::Heart, s.pl.pos.x + rng.rangef(-5, 5), s.pl.pos.y - 18, rng.rangef(-6, 6), -14, 0.8f);
}

void Game::tickMachines(int minutes) {
  for (auto& kv : s.maps) for (auto& o : kv.second->objs) {
    if (o.kind != ObjKind::Machine || o.state != 1) continue;
    o.days = (u16)std::max(0, (int)o.days - minutes);
    if (o.days == 0) o.state = 2;
  }
}

void Game::useMachine(Map& m, int oi) {
  MapObject& o = m.objs[(size_t)oi]; const ObjDef& d = objDef(o);
  Player& p = s.pl;
  if (o.kind == ObjKind::Feeder) {
    ItemStack& sel = p.inv.slots[(size_t)p.sel];
    if (!sel.empty() && C().def(sel.id).cat == Cat::Feed) { int add = std::min<int>(sel.count, 100 - (int)o.aux); if (add > 0) { o.aux += (u32)add; sel.count = (u16)(sel.count - add); if (!sel.count) sel = ItemStack(); toast(fmt("Auto-Feeder: %u hay stored", (unsigned)o.aux), "item_hay"); audio->play(Sfx::Pop); } else toast("The feeder is full."); }
    else toast(fmt("Auto-Feeder holds %u hay. Select hay to refill.", (unsigned)o.aux), "item_hay");
    return;
  }
  if (o.state == 2) {
    ItemStack st; st.id = (u16)(o.aux & 0xFFFF); st.count = (u16)(o.aux >> 16);
    if (!p.inv.canAdd(st)) { toast("Inventory full."); return; }
    giveItem(st); o.state = 0; o.aux = 0; audio->play(Sfx::Pop); emitEvent("machine", d.id); return;
  }
  if (o.state == 1) { toast(fmt("%s: about %d min left.", d.name.c_str(), (int)o.days), "ac_use"); return; }
  if (d.id == "seed_maker") {
    ItemStack& sel = p.inv.slots[(size_t)p.sel]; int ci = sel.empty() ? -1 : C().cropOfItem(sel.id);
    if (ci < 0) { toast("Select a crop to turn into seeds.", "item_seed_maker"); return; }
    o.aux = (u32)C().crops[(size_t)ci].seed | (2u << 16); o.state = 1; o.days = 20;
    if (--sel.count == 0) sel = ItemStack();
    audio->play(Sfx::Pop);
    return;
  }
  const ItemStack& sel = p.inv.slots[(size_t)p.sel];
  int pick = -1;
  for (size_t i = 0; i < C().procs.size(); ++i) {
    const ProcDef& pr = C().procs[i]; if (pr.machine != d.id || !p.inv.has(pr.in)) continue;
    if (pick < 0) pick = (int)i;
    if (!sel.empty() && !pr.in.empty() && C().matches(pr.in[0], sel.id)) { pick = (int)i; break; }
  }
  if (pick < 0) {
    std::string need;
    for (auto& pr : C().procs) if (pr.machine == d.id) { for (auto& g : pr.in) { if (!need.empty()) need += ", "; need += fmt("%d %s", g.count, g.item ? C().def(g.item).name.c_str() : g.group.c_str()); } break; }
    toast("Needs: " + need, "ac_use"); audio->play(Sfx::Error); return;
  }
  const ProcDef& pr = C().procs[(size_t)pick];
  p.inv.take(pr.in); o.aux = (u32)pr.out | ((u32)pr.outCount << 16); o.state = 1; o.days = (u16)pr.minutes; o.aux2 = (u16)(pick + 1);
  audio->play(Sfx::Pop); toast(fmt("%s started.", d.name.c_str()), "ac_use");
}
}  // namespace cf
