#include "weather/weather.h"
namespace cf {
const char* weatherName(Weather w) {
  static const char* n[8] = {"Sunny", "Cloudy", "Rainy", "Heavy rain", "Storm", "Foggy", "Windy", "Snowy"};
  return n[(int)w];
}
const char* weatherIcon(Weather w) {
  static const char* n[8] = {"ic_w_sunny", "ic_w_cloudy", "ic_w_rain", "ic_w_heavy", "ic_w_storm", "ic_w_fog", "ic_w_wind", "ic_w_snow"};
  return n[(int)w];
}
int weatherBit(Weather w) {
  switch (w) { case Weather::Snow: return 4; case Weather::Storm: return 8 | 2; case Weather::Rain: case Weather::HeavyRain: return 2; default: return 1; }
}
Weather rollWeather(Rng& rng, int season, int totalDay) {
  if (totalDay <= 2) return Weather::Sunny;                 // gentle start
  float r = rng.f();
  switch (season) {
    case Spring: return r < 0.42f ? Weather::Sunny : r < 0.62f ? Weather::Cloudy : r < 0.84f ? Weather::Rain : r < 0.9f ? Weather::Storm : r < 0.95f ? Weather::Wind : Weather::Fog;
    case Summer: return r < 0.55f ? Weather::Sunny : r < 0.7f ? Weather::Cloudy : r < 0.84f ? Weather::Rain : r < 0.92f ? Weather::Storm : r < 0.96f ? Weather::HeavyRain : Weather::Wind;
    case Autumn: return r < 0.35f ? Weather::Sunny : r < 0.55f ? Weather::Cloudy : r < 0.75f ? Weather::Rain : r < 0.82f ? Weather::HeavyRain : r < 0.92f ? Weather::Wind : Weather::Fog;
    default: return r < 0.3f ? Weather::Sunny : r < 0.5f ? Weather::Cloudy : r < 0.88f ? Weather::Snow : r < 0.94f ? Weather::Fog : Weather::Wind;
  }
}
}  // namespace cf
