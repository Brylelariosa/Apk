#pragma once
#include "engine/rng.h"
#include "items/content.h"

namespace cf {
enum class Weather : u8 { Sunny, Cloudy, Rain, HeavyRain, Storm, Fog, Wind, Snow };
inline bool isWet(Weather w) { return w == Weather::Rain || w == Weather::HeavyRain || w == Weather::Storm || w == Weather::Snow; }
inline bool isRainy(Weather w) { return w == Weather::Rain || w == Weather::HeavyRain || w == Weather::Storm; }
const char* weatherName(Weather w);
const char* weatherIcon(Weather w);
int weatherBit(Weather w);                         // 1 sun, 2 rain, 4 snow, 8 storm (dialogue conditions)
Weather rollWeather(Rng& rng, int season, int totalDay);

struct WeatherState {
  Weather today = Weather::Sunny, tomorrow = Weather::Sunny;
  float intensity = 0;          // smoothed visual strength 0..1
  float flash = 0, nextBolt = 6.f, wind = 0;
};
}  // namespace cf
