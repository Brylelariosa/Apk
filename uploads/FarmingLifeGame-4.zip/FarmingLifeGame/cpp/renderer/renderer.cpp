#include "renderer/renderer.h"
#include "engine/log.h"
#include "platform/platform.h"
#include "renderer/png_decoder.h"

namespace cf {

bool Renderer::loadAtlasIndexes() {
  bool ok = true;
  if (Sprites::world.size() == 0) ok &= Sprites::world.loadIndex("textures/atlas/world.atlas", 0);
  if (Sprites::ui.size() == 0) ok &= Sprites::ui.loadIndex("textures/atlas/ui.atlas", 1);
  return ok;
}

bool Renderer::init(Backend* b) {
  be = b;
  if (!loadAtlasIndexes()) return false;
  whiteWorld_ = &Sprites::world.get("white");
  whiteUi_ = &Sprites::ui.get("white");
  lightSprite_ = &Sprites::ui.get("fx_light");
  font.init(Sprites::ui);
  batch.init(be, atlasTex_, whiteWorld_, whiteUi_);
  return loadTextures();
}

bool Renderer::loadTextures() {
  Atlas* at[2] = {&Sprites::world, &Sprites::ui};
  bool ok = true;
  for (int i = 0; i < 2; ++i) {
    if (atlasTex_[i]) { be->destroyTexture(atlasTex_[i]); atlasTex_[i] = 0; }
    std::vector<u8> png, rgba; int w = 0, h = 0;
    if (platform().readAsset(at[i]->pngPath, png) && decodePng(png.data(), png.size(), w, h, rgba)) {
      if (w != at[i]->texW || h != at[i]->texH) CF_LOGW("atlas %s size mismatch (%dx%d vs %dx%d)", at[i]->pngPath.c_str(), w, h, at[i]->texW, at[i]->texH);
      atlasTex_[i] = be->createTexture(w, h, rgba.data(), false);
    } else {
      CF_LOGE("failed to load atlas texture %s", at[i]->pngPath.c_str());
      u8 px[16] = {255, 0, 255, 255, 0, 0, 0, 255, 0, 0, 0, 255, 255, 0, 255, 255};
      atlasTex_[i] = be->createTexture(2, 2, px, false);
      ok = false;
    }
  }
  targetsDirty_ = true;
  return ok;
}

void Renderer::contextLost() {
  atlasTex_[0] = atlasTex_[1] = worldTarget_ = lightTarget_ = 0;
  if (be) be->contextLost();
  targetsDirty_ = true;
}

int Renderer::autoPixelScale() const {
  return clampv(roundi((float)std::min(screenW, screenH) / 180.0f), 2, 8);
}

void Renderer::resize(int w, int h, float dens, int zoomOffset) {
  if (w == screenW && h == screenH && dens == density && zoomOffset == zoomOffset_ && !targetsDirty_) return;
  screenW = w; screenH = h; density = dens; zoomOffset_ = zoomOffset;
  pixelScale = clampv(autoPixelScale() + zoomOffset, 2, 10);
  logicalW = (w + pixelScale - 1) / pixelScale;
  logicalH = (h + pixelScale - 1) / pixelScale;
  targetsDirty_ = true;
}

void Renderer::recreateTargets() {
  if (worldTarget_) be->destroyTexture(worldTarget_);
  if (lightTarget_) be->destroyTexture(lightTarget_);
  worldTarget_ = lightTarget_ = 0;
  if (logicalW <= 0) return;
  worldTarget_ = be->createTarget(logicalW, logicalH, false);
  lightW_ = (logicalW + 1) / 2; lightH_ = (logicalH + 1) / 2;
  lightTarget_ = be->createTarget(lightW_, lightH_, true);
  CF_LOGI("render targets: world=%s light=%s logical=%dx%d scale=%d", worldTarget_ ? "fbo" : "direct",
          lightTarget_ ? "fbo" : "none", logicalW, logicalH, pixelScale);
  targetsDirty_ = false;
}

void Renderer::beginFrame() {
  if (targetsDirty_) recreateTargets();
  batch.resetStats();
  stats = RenderStats();
  be->setScissor(false, 0, 0, 0, 0);
  be->bindTarget(0, screenW, screenH);
  be->clear(0, 0, 0, 1);
}

void Renderer::beginWorld() {
  if (worldTarget_) { be->bindTarget(worldTarget_, logicalW, logicalH); batch.setScale(1.f); }
  else { be->bindTarget(0, screenW, screenH); batch.setScale((float)pixelScale); }
  be->clear(0.05f, 0.07f, 0.1f, 1);
  batch.setBlend(BlendMode::Alpha);
}

void Renderer::drawLighting(u32 ambient, const std::vector<Light>& lights, bool lightmap, bool glow) {
  batch.flush();
  float ar = (ambient & 255) / 255.f, ag = ((ambient >> 8) & 255) / 255.f, ab = ((ambient >> 16) & 255) / 255.f;
  if (lightmap && lightTarget_) {
    be->bindTarget(lightTarget_, lightW_, lightH_);
    be->clear(ar, ag, ab, 1);
    batch.setScale(0.5f);
    batch.setBlend(BlendMode::Add);
    for (const Light& l : lights) {
      float r = l.radius;
      batch.regionRect(*lightSprite_, l.x - r - camX_, l.y - r - camY_, r * 2, r * 2, l.color);
    }
    batch.flush();
    batch.setBlend(BlendMode::Alpha);
    // composite: multiply scene by the (upscaled, filtered) light map
    if (worldTarget_) { be->bindTarget(worldTarget_, logicalW, logicalH); batch.setScale(1.f); }
    else { be->bindTarget(0, screenW, screenH); batch.setScale((float)pixelScale); }
    batch.setBlend(BlendMode::Multiply);
    batch.rawQuad(lightTarget_, 0, 0, (float)logicalW * batch.scale(), (float)logicalH * batch.scale(), 0, 0, 1, 1, kWhite);
    batch.flush();
    batch.setBlend(BlendMode::Alpha);
  } else {
    batch.setBlend(BlendMode::Multiply);
    batch.rect(0, 0, (float)logicalW, (float)logicalH, col::rgba((int)(ar * 255), (int)(ag * 255), (int)(ab * 255), 255));
    batch.flush();
    if (glow) {
      batch.setBlend(BlendMode::Add);
      for (const Light& l : lights) {
        float r = l.radius;
        batch.regionRect(*lightSprite_, l.x - r - camX_, l.y - r - camY_, r * 2, r * 2, col::mul(l.color, 0.45f));
      }
      batch.flush();
    }
    batch.setBlend(BlendMode::Alpha);
  }
}

void Renderer::endWorld() {
  batch.flush();
  if (worldTarget_) {
    be->bindTarget(0, screenW, screenH);
    batch.setScale(1.f);
    batch.setBlend(BlendMode::None);
    batch.rawQuad(worldTarget_, 0, 0, (float)(logicalW * pixelScale), (float)(logicalH * pixelScale), 0, 0, 1, 1, kWhite);
    batch.flush();
    batch.setBlend(BlendMode::Alpha);
  }
}

void Renderer::beginUI() {
  batch.flush();
  be->bindTarget(0, screenW, screenH);
  batch.setScale(1.f);
  batch.setBlend(BlendMode::Alpha);
}

void Renderer::endFrame() {
  batch.flush();
  stats.drawCalls = batch.drawCalls; stats.quads = batch.quads;
}
}  // namespace cf
