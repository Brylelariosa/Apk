#include "renderer/atlas.h"
#include "engine/data_file.h"
#include "engine/log.h"
#include "platform/platform.h"

namespace cf {
Atlas Sprites::world;
Atlas Sprites::ui;

bool Atlas::loadIndex(const std::string& path, int atlasId) {
  std::vector<u8> bytes;
  if (!platform().readAsset(path, bytes)) { CF_LOGE("atlas index missing: %s", path.c_str()); return false; }
  id = atlasId; regions_.clear(); index_.clear(); missingIdx_ = -1;
  std::string text((const char*)bytes.data(), bytes.size());
  size_t pos = 0;
  while (pos < text.size()) {
    size_t e = text.find('\n', pos); if (e == std::string::npos) e = text.size();
    std::string line = text.substr(pos, e - pos); pos = e + 1;
    if (line.empty()) continue;
    auto t = splitString(line, ' ');
    if (t[0] == "#atlas" && t.size() >= 4) { pngPath = t[1]; texW = atoi(t[2].c_str()); texH = atoi(t[3].c_str()); continue; }
    if (t[0][0] == '#' || t.size() < 5) continue;
    Region r;
    r.x = atoi(t[1].c_str()); r.y = atoi(t[2].c_str()); r.w = atoi(t[3].c_str()); r.h = atoi(t[4].c_str());
    r.ax = t.size() > 5 ? (float)atof(t[5].c_str()) : 0.f; r.ay = t.size() > 6 ? (float)atof(t[6].c_str()) : 0.f;
    r.atlas = (u8)atlasId;
    if (texW > 0 && texH > 0) {
      r.u0 = (float)r.x / texW; r.v0 = (float)r.y / texH; r.u1 = (float)(r.x + r.w) / texW; r.v1 = (float)(r.y + r.h) / texH;
    }
    if (t[0] == "missing") missingIdx_ = (int)regions_.size();
    index_[t[0]] = (int)regions_.size();
    regions_.push_back(r);
  }
  if (texW <= 0 || regions_.empty()) { CF_LOGE("atlas index invalid: %s", path.c_str()); return false; }
  CF_LOGI("atlas %s: %zu regions, %dx%d", path.c_str(), regions_.size(), texW, texH);
  return true;
}
const Region* Atlas::find(const std::string& name) const {
  auto it = index_.find(name);
  return it == index_.end() ? nullptr : &regions_[(size_t)it->second];
}
const Region& Atlas::get(const std::string& name) {
  if (const Region* r = find(name)) return *r;
  if (missingHits_++ < 20) CF_LOGW("missing sprite: %s", name.c_str());
  return missing();
}
const Region& Sprites::get(const std::string& name) {
  if (const Region* r = find(name)) return *r;
  return world.get(name);   // logs + returns the missing sprite
}
}  // namespace cf
