#include "renderer/font.h"

namespace cf {
void Font::init(Atlas& ui) {
  for (int c = 32; c < 127; ++c) {
    glyph_[c] = ui.find("g_" + std::to_string(c));
  }
  for (int c = 0; c < 128; ++c) if (!glyph_[c]) glyph_[c] = glyph_[(int)'?'];
  if (glyph_[(int)'A']) glyphH_ = glyph_[(int)'A']->h;
}
static inline int safeChar(unsigned char c) { return (c >= 32 && c < 127) ? c : '?'; }

int Font::textWidth(const std::string& s, int k) const {
  int best = 0, cur = 0;
  for (unsigned char ch : s) {
    if (ch == '\n') { best = std::max(best, cur); cur = 0; continue; }
    const Region* g = glyph_[safeChar(ch)];
    cur += g ? (int)g->ax * k : 4 * k;
  }
  return std::max(best, cur);
}
void Font::drawRaw(SpriteBatch& b, const std::string& s, float x, float y, int k, u32 color) const {
  float cx = x, cy = y;
  for (unsigned char ch : s) {
    if (ch == '\n') { cx = x; cy += lineHeight(k); continue; }
    const Region* g = glyph_[safeChar(ch)];
    if (!g) { cx += 4 * k; continue; }
    if (ch != ' ') b.regionRect(*g, cx, cy, (float)(g->w * k), (float)(g->h * k), color);
    cx += g->ax * k;
  }
}
void Font::draw(SpriteBatch& b, const std::string& s, float x, float y, int k, u32 color, u32 shadow) const {
  if ((shadow >> 24) != 0) drawRaw(b, s, x + k, y + k, k, shadow);
  drawRaw(b, s, x, y, k, color);
}
void Font::drawOutlined(SpriteBatch& b, const std::string& s, float x, float y, int k, u32 color, u32 outline) const {
  drawRaw(b, s, x - k, y, k, outline); drawRaw(b, s, x + k, y, k, outline);
  drawRaw(b, s, x, y - k, k, outline); drawRaw(b, s, x, y + k, k, outline);
  drawRaw(b, s, x, y, k, color);
}
int Font::wrap(const std::string& s, int maxW, int k, std::vector<std::string>& lines) const {
  lines.clear();
  std::string line, word;
  auto flushWord = [&]() {
    if (word.empty()) return;
    std::string trial = line.empty() ? word : line + " " + word;
    if (!line.empty() && textWidth(trial, k) > maxW) { lines.push_back(line); line = word; }
    else line = trial;
    word.clear();
  };
  for (unsigned char ch : s) {
    if (ch == ' ') flushWord();
    else if (ch == '\n') { flushWord(); lines.push_back(line); line.clear(); }
    else word += (char)ch;
  }
  flushWord();
  if (!line.empty() || lines.empty()) lines.push_back(line);
  return (int)lines.size();
}
}  // namespace cf
