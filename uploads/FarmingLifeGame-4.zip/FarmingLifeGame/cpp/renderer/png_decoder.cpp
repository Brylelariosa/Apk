#include "renderer/png_decoder.h"
#include "engine/log.h"

namespace cf {
namespace {

struct BitReader {
  const u8* p; const u8* end; u64 buf = 0; int cnt = 0;
  void refill() { while (cnt <= 56 && p < end) { buf |= (u64)(*p++) << cnt; cnt += 8; } }
  u32 peek(int n) { if (cnt < n) refill(); return (u32)(buf & ((1ull << n) - 1)); }
  void drop(int n) { buf >>= n; cnt -= n; }
  u32 get(int n) { if (n == 0) return 0; u32 v = peek(n); drop(n); return v; }
};

struct Huff {
  std::vector<u16> table; int maxBits = 1;
  bool build(const u8* lens, int n) {
    int count[16] = {0};
    for (int i = 0; i < n; ++i) count[lens[i]]++;
    count[0] = 0;
    maxBits = 0;
    for (int l = 1; l < 16; ++l) if (count[l]) maxBits = l;
    if (maxBits == 0) { maxBits = 1; table.assign(2, 0); return true; }
    int left = 1;
    for (int l = 1; l < 16; ++l) { left <<= 1; left -= count[l]; if (left < 0) return false; }
    int next[16]; int code = 0;
    for (int b = 1; b < 16; ++b) { code = (code + count[b - 1]) << 1; next[b] = code; }
    table.assign((size_t)1 << maxBits, 0);
    for (int s = 0; s < n; ++s) {
      int len = lens[s]; if (!len) continue;
      int c = next[len]++;
      int rev = 0; for (int i = 0; i < len; ++i) rev |= ((c >> i) & 1) << (len - 1 - i);
      for (int i = rev; i < (1 << maxBits); i += (1 << len)) table[(size_t)i] = (u16)((s << 4) | len);
    }
    return true;
  }
  int decode(BitReader& br) const {
    u16 e = table[br.peek(maxBits)];
    int len = e & 15;
    if (!len) return -1;
    br.drop(len);
    return e >> 4;
  }
};

const u16 kLenBase[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
const u8 kLenExt[29] = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
const u16 kDistBase[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
const u8 kDistExt[30] = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};

bool inflateData(const u8* in, size_t n, u8* out, size_t outSize) {
  if (n < 6 || (in[0] & 15) != 8 || (in[1] & 32)) return false;
  BitReader br{in + 2, in + n};
  size_t op = 0;
  Huff lit, dist;
  for (;;) {
    u32 fin = br.get(1), type = br.get(2);
    if (type == 0) {
      br.drop(br.cnt & 7);
      u32 len = br.get(16), nlen = br.get(16);
      if ((len ^ 0xFFFFu) != nlen || op + len > outSize) return false;
      for (u32 i = 0; i < len; ++i) out[op++] = (u8)br.get(8);
    } else if (type == 1 || type == 2) {
      u8 lens[320];
      if (type == 1) {
        for (int i = 0; i < 144; ++i) lens[i] = 8;
        for (int i = 144; i < 256; ++i) lens[i] = 9;
        for (int i = 256; i < 280; ++i) lens[i] = 7;
        for (int i = 280; i < 288; ++i) lens[i] = 8;
        if (!lit.build(lens, 288)) return false;
        u8 dl[30]; for (int i = 0; i < 30; ++i) dl[i] = 5;
        if (!dist.build(dl, 30)) return false;
      } else {
        int hlit = (int)br.get(5) + 257, hdist = (int)br.get(5) + 1, hclen = (int)br.get(4) + 4;
        static const u8 order[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
        u8 cl[19] = {0};
        for (int i = 0; i < hclen; ++i) cl[order[i]] = (u8)br.get(3);
        Huff ch;
        if (!ch.build(cl, 19)) return false;
        int total = hlit + hdist, i = 0;
        while (i < total) {
          int s = ch.decode(br);
          if (s < 0 || br.cnt < 0) return false;
          if (s < 16) lens[i++] = (u8)s;
          else {
            int rep, val = 0;
            if (s == 16) { if (i == 0) return false; val = lens[i - 1]; rep = 3 + (int)br.get(2); }
            else if (s == 17) rep = 3 + (int)br.get(3);
            else rep = 11 + (int)br.get(7);
            if (i + rep > total) return false;
            while (rep--) lens[i++] = (u8)val;
          }
        }
        if (!lit.build(lens, hlit) || !dist.build(lens + hlit, hdist)) return false;
      }
      for (;;) {
        int s = lit.decode(br);
        if (s < 0 || br.cnt < 0) return false;
        if (s < 256) { if (op >= outSize) return false; out[op++] = (u8)s; }
        else if (s == 256) break;
        else {
          s -= 257; if (s >= 29) return false;
          size_t len = kLenBase[s] + br.get(kLenExt[s]);
          int ds = dist.decode(br);
          if (ds < 0 || ds >= 30) return false;
          size_t d = kDistBase[ds] + br.get(kDistExt[ds]);
          if (d > op || op + len > outSize) return false;
          const u8* src = out + op - d; u8* dst = out + op;
          for (size_t i = 0; i < len; ++i) dst[i] = src[i];
          op += len;
        }
      }
    } else return false;
    if (fin) break;
  }
  return op == outSize;
}

inline u32 be32(const u8* p) { return ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3]; }
}  // namespace

bool decodePng(const u8* d, size_t size, int& w, int& h, std::vector<u8>& rgba) {
  static const u8 sig[8] = {0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
  if (size < 33 || memcmp(d, sig, 8) != 0) { CF_LOGW("png: bad signature"); return false; }
  size_t pos = 8; int depth = 0, ctype = 0, interlace = 0; w = h = 0;
  std::vector<u8> idat, plte, trns;
  while (pos + 12 <= size) {
    u32 len = be32(d + pos); const u8* type = d + pos + 4; const u8* body = d + pos + 8;
    if (pos + 12 + len > size) break;
    if (!memcmp(type, "IHDR", 4) && len >= 13) {
      w = (int)be32(body); h = (int)be32(body + 4); depth = body[8]; ctype = body[9]; interlace = body[12];
    } else if (!memcmp(type, "IDAT", 4)) idat.insert(idat.end(), body, body + len);
    else if (!memcmp(type, "PLTE", 4)) plte.assign(body, body + len);
    else if (!memcmp(type, "tRNS", 4)) trns.assign(body, body + len);
    else if (!memcmp(type, "IEND", 4)) break;
    pos += 12 + len;
  }
  if (w <= 0 || h <= 0 || depth != 8 || interlace != 0 || w > 8192 || h > 8192) { CF_LOGW("png: unsupported format"); return false; }
  int ch = ctype == 6 ? 4 : ctype == 2 ? 3 : ctype == 0 ? 1 : ctype == 4 ? 2 : ctype == 3 ? 1 : 0;
  if (!ch) return false;
  size_t stride = (size_t)w * ch;
  std::vector<u8> raw((stride + 1) * (size_t)h);
  if (!inflateData(idat.data(), idat.size(), raw.data(), raw.size())) { CF_LOGW("png: inflate failed"); return false; }
  std::vector<u8> img(stride * (size_t)h);
  for (int y = 0; y < h; ++y) {
    int f = raw[(stride + 1) * (size_t)y];
    const u8* s = &raw[(stride + 1) * (size_t)y + 1];
    u8* o = &img[stride * (size_t)y];
    const u8* up = y ? o - stride : nullptr;
    for (size_t i = 0; i < stride; ++i) {
      int a = i >= (size_t)ch ? o[i - ch] : 0, b = up ? up[i] : 0, c = (up && i >= (size_t)ch) ? up[i - ch] : 0, v = s[i];
      switch (f) {
        case 0: break;
        case 1: v += a; break;
        case 2: v += b; break;
        case 3: v += (a + b) >> 1; break;
        case 4: { int p = a + b - c, pa = std::abs(p - a), pb = std::abs(p - b), pc = std::abs(p - c);
                  v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c); break; }
        default: return false;
      }
      o[i] = (u8)v;
    }
  }
  rgba.resize((size_t)w * h * 4);
  for (size_t i = 0, n = (size_t)w * h; i < n; ++i) {
    const u8* s = &img[i * ch]; u8* o = &rgba[i * 4];
    switch (ctype) {
      case 6: o[0] = s[0]; o[1] = s[1]; o[2] = s[2]; o[3] = s[3]; break;
      case 2: o[0] = s[0]; o[1] = s[1]; o[2] = s[2]; o[3] = 255; break;
      case 0: o[0] = o[1] = o[2] = s[0]; o[3] = 255; break;
      case 4: o[0] = o[1] = o[2] = s[0]; o[3] = s[1]; break;
      default: { size_t pi = s[0]; if (pi * 3 + 2 >= plte.size()) pi = 0;
                 o[0] = plte.size() >= 3 ? plte[pi * 3] : 0; o[1] = plte.size() >= 3 ? plte[pi * 3 + 1] : 0;
                 o[2] = plte.size() >= 3 ? plte[pi * 3 + 2] : 0; o[3] = s[0] < trns.size() ? trns[s[0]] : 255; }
    }
  }
  return true;
}
}  // namespace cf
