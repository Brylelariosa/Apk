#include "renderer/sprite_batch.h"

namespace cf {
void SpriteBatch::init(Backend* b, const TexHandle* atlasTex, const Region* ww, const Region* wu) {
  be_ = b; atlasTex_ = atlasTex; white_[0] = ww; white_[1] = wu;
  verts_.resize((size_t)kMaxQuads * 4);
  count_ = 0; curTex_ = 0;
}
void SpriteBatch::setBlend(BlendMode m) { if (m != blend_) { flush(); blend_ = m; } }
void SpriteBatch::flush() {
  if (count_ > 0 && be_) { be_->draw(curTex_, blend_, verts_.data(), count_); ++drawCalls; quads += count_; }
  count_ = 0;
}
void SpriteBatch::push(TexHandle tex, int atlas, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, u32 c) {
  if (tex != curTex_ || count_ >= kMaxQuads) { flush(); curTex_ = tex; }
  curAtlas_ = atlas;
  Vertex* v = &verts_[(size_t)count_ * 4];
  v[0] = {x0, y0, u0, v0, c}; v[1] = {x1, y0, u1, v0, c}; v[2] = {x1, y1, u1, v1, c}; v[3] = {x0, y1, u0, v1, c};
  ++count_;
}
void SpriteBatch::region(const Region& r, float x, float y, u32 c, bool flipX, float sx, float sy) {
  float w = r.w * sx * scale_, h = r.h * sy * scale_;
  float ox = (flipX ? (r.w - r.ax) : r.ax) * sx * scale_, oy = r.ay * sy * scale_;
  float x0 = std::floor(x * scale_ - ox + 0.5f), y0 = std::floor(y * scale_ - oy + 0.5f);
  float u0 = r.u0, u1 = r.u1; if (flipX) std::swap(u0, u1);
  push(atlasTex_[r.atlas], r.atlas, x0, y0, x0 + std::floor(w + 0.5f), y0 + std::floor(h + 0.5f), u0, r.v0, u1, r.v1, c);
}
void SpriteBatch::regionRect(const Region& r, float x, float y, float w, float h, u32 c, bool flipX) {
  float u0 = r.u0, u1 = r.u1; if (flipX) std::swap(u0, u1);
  float x0 = std::floor(x * scale_ + 0.5f), y0 = std::floor(y * scale_ + 0.5f);
  push(atlasTex_[r.atlas], r.atlas, x0, y0, x0 + std::floor(w * scale_ + 0.5f), y0 + std::floor(h * scale_ + 0.5f), u0, r.v0, u1, r.v1, c);
}
void SpriteBatch::regionPart(const Region& r, int sx, int sy, int sw, int sh, float x, float y, float w, float h, u32 c, bool flipX) {
  float iw = (r.u1 - r.u0) / (float)std::max(1, r.w), ih = (r.v1 - r.v0) / (float)std::max(1, r.h);
  float u0 = r.u0 + sx * iw, u1 = r.u0 + (sx + sw) * iw, v0 = r.v0 + sy * ih, v1 = r.v0 + (sy + sh) * ih;
  if (flipX) std::swap(u0, u1);
  float x0 = std::floor(x * scale_ + 0.5f), y0 = std::floor(y * scale_ + 0.5f);
  push(atlasTex_[r.atlas], r.atlas, x0, y0, x0 + std::floor(w * scale_ + 0.5f), y0 + std::floor(h * scale_ + 0.5f), u0, v0, u1, v1, c);
}
void SpriteBatch::rect(float x, float y, float w, float h, u32 c) {
  const Region& r = *white_[curAtlas_ ? 1 : 0];
  float cu = (r.u0 + r.u1) * 0.5f, cv = (r.v0 + r.v1) * 0.5f;
  float x0 = std::floor(x * scale_ + 0.5f), y0 = std::floor(y * scale_ + 0.5f);
  push(atlasTex_[r.atlas], r.atlas, x0, y0, x0 + std::floor(w * scale_ + 0.5f), y0 + std::floor(h * scale_ + 0.5f), cu, cv, cu, cv, c);
}
void SpriteBatch::rawQuad(TexHandle tex, float x, float y, float w, float h, float u0, float v0, float u1, float v1, u32 c) {
  push(tex, 1, x, y, x + w, y + h, u0, v0, u1, v1, c);
}
void SpriteBatch::nine(const Region& r, int b, float x, float y, float w, float h, float k, u32 c) {
  float bk = b * k;
  if (w < 2 * bk) bk = w * 0.5f;
  if (h < 2 * bk) bk = std::min(bk, h * 0.5f);
  int mw = r.w - 2 * b, mh = r.h - 2 * b;
  float cw = w - 2 * bk, ch = h - 2 * bk;
  regionPart(r, 0, 0, b, b, x, y, bk, bk, c);
  regionPart(r, b + mw, 0, b, b, x + w - bk, y, bk, bk, c);
  regionPart(r, 0, b + mh, b, b, x, y + h - bk, bk, bk, c);
  regionPart(r, b + mw, b + mh, b, b, x + w - bk, y + h - bk, bk, bk, c);
  if (cw > 0) { regionPart(r, b, 0, mw, b, x + bk, y, cw, bk, c); regionPart(r, b, b + mh, mw, b, x + bk, y + h - bk, cw, bk, c); }
  if (ch > 0) { regionPart(r, 0, b, b, mh, x, y + bk, bk, ch, c); regionPart(r, b + mw, b, b, mh, x + w - bk, y + bk, bk, ch, c); }
  if (cw > 0 && ch > 0) regionPart(r, b, b, mw, mh, x + bk, y + bk, cw, ch, c);
}
}  // namespace cf
