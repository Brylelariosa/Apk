// Frame orchestration: low-resolution world target (pixel-perfect upscale), lightmap, UI pass.
#pragma once
#include "renderer/font.h"

namespace cf {
struct Light { float x, y, radius; u32 color; };      // world-space light (pixels)

struct RenderStats { int drawCalls = 0, quads = 0, visibleSprites = 0; };

class Renderer {
 public:
  Backend* be = nullptr;
  SpriteBatch batch;
  Font font;
  RenderStats stats;
  int screenW = 0, screenH = 0, pixelScale = 3, logicalW = 0, logicalH = 0;
  float density = 2.f;

  static bool loadAtlasIndexes();              // parses the .atlas files (needs no GL); must run before Content::load
  bool init(Backend* b);                       // creates the batch + uploads textures; call once a context exists
  bool loadTextures();                         // (re)upload atlas PNGs - also used after a lost GL context
  void contextLost();                          // GPU handles are gone; textures must be reloaded
  void resize(int w, int h, float dens, int zoomOffset);
  int autoPixelScale() const;

  void beginFrame();
  void beginWorld();                           // switches to the logical-resolution world target
  void drawLighting(u32 ambient, const std::vector<Light>& lights, bool lightmap, bool glow);
  void endWorld();                             // upscales the world target to the screen
  void beginUI();
  void endFrame();
  bool worldTargetActive() const { return worldTarget_ != 0; }
  const Region& white() const { return *whiteUi_; }
  void setCameraOrigin(float x, float y) { camX_ = x; camY_ = y; }   // top-left of the world view (for lights)
 private:
  void recreateTargets();
  TexHandle atlasTex_[2] = {0, 0}, worldTarget_ = 0, lightTarget_ = 0;
  int lightW_ = 0, lightH_ = 0, zoomOffset_ = 0;
  const Region *whiteWorld_ = nullptr, *whiteUi_ = nullptr, *lightSprite_ = nullptr;
  bool targetsDirty_ = true;
  float camX_ = 0, camY_ = 0;
};
}  // namespace cf
