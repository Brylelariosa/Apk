#pragma once
#include <memory>
#include "renderer/backend.h"
namespace cf {
std::unique_ptr<Backend> createGlBackend();   // OpenGL ES 3.x context if available, 2.0-compatible feature subset
}
