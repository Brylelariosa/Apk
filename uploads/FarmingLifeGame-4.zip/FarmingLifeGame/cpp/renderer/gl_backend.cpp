// OpenGL ES backend. Uses only the ES 2.0 core feature subset so it runs on ES 3.x contexts and on older ES 2.0 GPUs.
#include <GLES2/gl2.h>
#include <unordered_map>
#include "engine/log.h"
#include "renderer/gl_backend.h"

namespace cf {
namespace {

const char* kVS =
    "attribute vec2 aPos;\n"
    "attribute vec2 aUV;\n"
    "attribute vec4 aCol;\n"
    "uniform vec2 uInvSize;\n"
    "uniform float uFlipV;\n"
    "varying vec2 vUV;\n"
    "varying vec4 vCol;\n"
    "void main() {\n"
    "  vUV = vec2(aUV.x, uFlipV > 0.5 ? 1.0 - aUV.y : aUV.y);\n"
    "  vCol = aCol;\n"
    "  gl_Position = vec4(aPos.x * uInvSize.x * 2.0 - 1.0, 1.0 - aPos.y * uInvSize.y * 2.0, 0.0, 1.0);\n"
    "}\n";
const char* kFS =
    "#ifdef GL_FRAGMENT_PRECISION_HIGH\n"
    "precision highp float;\n"
    "#else\n"
    "precision mediump float;\n"
    "#endif\n"
    "varying vec2 vUV;\n"
    "varying vec4 vCol;\n"
    "uniform sampler2D uTex;\n"
    "void main() { gl_FragColor = texture2D(uTex, vUV) * vCol; }\n";

class GlBackend : public Backend {
 public:
  const char* name() const override { return "gles"; }
  bool isES3() const override { return es3_; }

  bool init() override {
    const char* ver = (const char*)glGetString(GL_VERSION);
    es3_ = ver && strstr(ver, "OpenGL ES 3") != nullptr;
    CF_LOGI("GL_VERSION=%s RENDERER=%s", ver ? ver : "?", (const char*)glGetString(GL_RENDERER));
    GLuint vs = compile(GL_VERTEX_SHADER, kVS), fs = compile(GL_FRAGMENT_SHADER, kFS);
    if (!vs || !fs) return false;
    prog_ = glCreateProgram();
    glAttachShader(prog_, vs); glAttachShader(prog_, fs);
    glBindAttribLocation(prog_, 0, "aPos"); glBindAttribLocation(prog_, 1, "aUV"); glBindAttribLocation(prog_, 2, "aCol");
    glLinkProgram(prog_);
    GLint ok = 0; glGetProgramiv(prog_, GL_LINK_STATUS, &ok);
    glDeleteShader(vs); glDeleteShader(fs);
    if (!ok) {
      char log[512] = {0}; glGetProgramInfoLog(prog_, sizeof log, nullptr, log);
      CF_LOGE("shader link failed: %s", log);
      return false;
    }
    locInv_ = glGetUniformLocation(prog_, "uInvSize");
    locFlip_ = glGetUniformLocation(prog_, "uFlipV");
    GLint locTex = glGetUniformLocation(prog_, "uTex");
    glUseProgram(prog_);
    glUniform1i(locTex, 0);
    glGenBuffers(1, &vbo_); glGenBuffers(1, &ibo_);
    const int maxQuads = 4096;
    std::vector<unsigned short> idx((size_t)maxQuads * 6);
    for (int i = 0; i < maxQuads; ++i) {
      unsigned short b = (unsigned short)(i * 4);
      unsigned short* p = &idx[(size_t)i * 6];
      p[0] = b; p[1] = (unsigned short)(b + 1); p[2] = (unsigned short)(b + 2);
      p[3] = b; p[4] = (unsigned short)(b + 2); p[5] = (unsigned short)(b + 3);
    }
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(idx.size() * sizeof(unsigned short)), idx.data(), GL_STATIC_DRAW);
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glActiveTexture(GL_TEXTURE0);
    blendValid_ = false;
    return true;
  }
  void shutdown() override {
    for (auto& kv : targets_) { glDeleteFramebuffers(1, &kv.second); glDeleteTextures(1, (const GLuint*)&kv.first); }
    targets_.clear();
    if (prog_) glDeleteProgram(prog_);
    if (vbo_) glDeleteBuffers(1, &vbo_);
    if (ibo_) glDeleteBuffers(1, &ibo_);
    prog_ = vbo_ = ibo_ = 0;
  }
  void contextLost() override { targets_.clear(); prog_ = vbo_ = ibo_ = 0; blendValid_ = false; }

  TexHandle createTexture(int w, int h, const u8* rgba, bool linear) override {
    GLuint t = 0; glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D, t);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
    params(linear);
    return t;
  }
  TexHandle createTarget(int w, int h, bool linear) override {
    GLuint t = 0, fbo = 0;
    glGenTextures(1, &t);
    glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    params(linear);
    glGenFramebuffers(1, &fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, t, 0);
    GLenum st = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    if (st != GL_FRAMEBUFFER_COMPLETE) {
      CF_LOGW("framebuffer incomplete (0x%x) - falling back to direct rendering", (unsigned)st);
      glDeleteFramebuffers(1, &fbo); glDeleteTextures(1, &t);
      return 0;
    }
    targets_[t] = fbo;
    return t;
  }
  void destroyTexture(TexHandle t) override {
    if (!t) return;
    auto it = targets_.find(t);
    if (it != targets_.end()) { glDeleteFramebuffers(1, &it->second); targets_.erase(it); }
    GLuint g = t; glDeleteTextures(1, &g);
  }
  void bindTarget(TexHandle t, int w, int h) override {
    auto it = targets_.find(t);
    glBindFramebuffer(GL_FRAMEBUFFER, (t && it != targets_.end()) ? it->second : 0);
    glViewport(0, 0, w, h);
    curH_ = h;
    glUseProgram(prog_);
    glUniform2f(locInv_, 1.0f / (float)w, 1.0f / (float)h);
  }
  void clear(float r, float g, float b, float a) override {
    setScissorRaw(false);
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
  }
  void setScissor(bool on, int x, int y, int w, int h) override {
    if (on) glScissor(x, curH_ - (y + h), w, h);   // interface uses top-left origin
    setScissorRaw(on);
  }
  void draw(TexHandle tex, BlendMode bm, const Vertex* q, int n) override {
    if (n <= 0) return;
    setBlend(bm);
    glBindTexture(GL_TEXTURE_2D, tex);
    glUniform1f(locFlip_, targets_.count(tex) ? 1.0f : 0.0f);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)((size_t)n * 4 * sizeof(Vertex)), q, GL_STREAM_DRAW);
    glEnableVertexAttribArray(0); glEnableVertexAttribArray(1); glEnableVertexAttribArray(2);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void*)0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const void*)8);
    glVertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), (const void*)16);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
    glDrawElements(GL_TRIANGLES, n * 6, GL_UNSIGNED_SHORT, (const void*)0);
  }

 private:
  GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
      char log[512] = {0}; glGetShaderInfoLog(s, sizeof log, nullptr, log);
      CF_LOGE("shader compile failed: %s", log);
      glDeleteShader(s);
      return 0;
    }
    return s;
  }
  void params(bool linear) {
    GLint f = linear ? GL_LINEAR : GL_NEAREST;
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, f);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, f);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  }
  void setScissorRaw(bool on) {
    if (on != scissorOn_) { if (on) glEnable(GL_SCISSOR_TEST); else glDisable(GL_SCISSOR_TEST); scissorOn_ = on; }
  }
  void setBlend(BlendMode bm) {
    if (blendValid_ && bm == blend_) return;
    blend_ = bm; blendValid_ = true;
    switch (bm) {
      case BlendMode::None: glDisable(GL_BLEND); break;
      case BlendMode::Alpha: glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); break;
      case BlendMode::Add: glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE); break;
      case BlendMode::Multiply: glEnable(GL_BLEND); glBlendFunc(GL_DST_COLOR, GL_ZERO); break;
    }
  }
  bool es3_ = false, scissorOn_ = false, blendValid_ = false;
  BlendMode blend_ = BlendMode::Alpha;
  GLuint prog_ = 0, vbo_ = 0, ibo_ = 0;
  GLint locInv_ = -1, locFlip_ = -1;
  int curH_ = 0;
  std::unordered_map<GLuint, GLuint> targets_;   // render-target texture -> framebuffer
};
}  // namespace

std::unique_ptr<Backend> createGlBackend() { return std::unique_ptr<Backend>(new GlBackend()); }
}  // namespace cf
