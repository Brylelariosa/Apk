// Rendering backend interface. GL ES implementation lives in gl_backend.cpp; tools/hostcheck has a software one for tests.
#pragma once
#include "engine/types.h"

namespace cf {
using TexHandle = u32;
enum class BlendMode : u8 { Alpha, Add, Multiply, None };

struct Vertex { float x, y, u, v; u32 color; };   // 20 bytes; positions are in target pixels (y down)

class Backend {
 public:
  virtual ~Backend() {}
  virtual bool init() = 0;                                  // call with a current context
  virtual void shutdown() {}                                // release GPU objects (context still current)
  virtual void contextLost() {}                             // drop handles without GL calls
  virtual TexHandle createTexture(int w, int h, const u8* rgba, bool linear) = 0;
  virtual TexHandle createTarget(int w, int h, bool linear) = 0;   // 0 when render targets are unsupported
  virtual void destroyTexture(TexHandle t) = 0;
  virtual void bindTarget(TexHandle t, int w, int h) = 0;   // 0 = screen
  virtual void clear(float r, float g, float b, float a) = 0;
  virtual void draw(TexHandle tex, BlendMode bm, const Vertex* quads, int quadCount) = 0;  // 4 vertices per quad (TL,TR,BR,BL)
  virtual void setScissor(bool on, int x, int y, int w, int h) = 0;
  virtual const char* name() const = 0;
  virtual bool isES3() const { return false; }
};
}  // namespace cf
