// Bitmap font drawn from glyph regions "g_<ascii>" in the UI atlas (Region.ax stores the advance).
#pragma once
#include "renderer/sprite_batch.h"

namespace cf {
class Font {
 public:
  void init(Atlas& ui);
  int glyphHeight() const { return glyphH_; }
  int lineHeight(int k) const { return (glyphH_ + 1) * k; }
  int textWidth(const std::string& s, int k) const;                 // widest line, in pixels
  void draw(SpriteBatch& b, const std::string& s, float x, float y, int k, u32 color, u32 shadow = 0) const;
  void drawOutlined(SpriteBatch& b, const std::string& s, float x, float y, int k, u32 color, u32 outline) const;
  int wrap(const std::string& s, int maxW, int k, std::vector<std::string>& lines) const;  // returns line count
 private:
  const Region* glyph_[128] = {};
  int glyphH_ = 8;
  void drawRaw(SpriteBatch& b, const std::string& s, float x, float y, int k, u32 color) const;
};
}  // namespace cf
