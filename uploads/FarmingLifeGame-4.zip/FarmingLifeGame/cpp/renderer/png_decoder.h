// Minimal self-contained PNG decoder (8-bit gray/RGB/RGBA/palette, non-interlaced) so the game needs no image library.
#pragma once
#include "engine/types.h"
namespace cf {
bool decodePng(const u8* data, size_t size, int& w, int& h, std::vector<u8>& rgba);
}
