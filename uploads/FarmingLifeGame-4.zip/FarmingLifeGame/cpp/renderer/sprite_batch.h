// Batches textured quads; flushes when texture/blend mode changes or the buffer is full.
#pragma once
#include "renderer/atlas.h"

namespace cf {
class SpriteBatch {
 public:
  static constexpr int kMaxQuads = 4096;
  void init(Backend* b, const TexHandle* atlasTex, const Region* whiteWorld, const Region* whiteUi);
  void setScale(float s) { scale_ = s; }        // multiplies all incoming coordinates (world -> target pixels)
  float scale() const { return scale_; }
  void setBlend(BlendMode m);
  BlendMode blend() const { return blend_; }
  void flush();
  void resetStats() { drawCalls = 0; quads = 0; }

  // anchor placement: (x,y) is where region anchor lands; sx/sy extra scale factors
  void region(const Region& r, float x, float y, u32 color = kWhite, bool flipX = false, float sx = 1, float sy = 1);
  // stretch whole region into [x,y,w,h] (top-left based)
  void regionRect(const Region& r, float x, float y, float w, float h, u32 color = kWhite, bool flipX = false);
  // sub-rectangle of a region (source pixels relative to region origin) drawn at x,y (top-left) with size w,h
  void regionPart(const Region& r, int srcX, int srcY, int srcW, int srcH, float x, float y, float w, float h, u32 color = kWhite, bool flipX = false);
  void rect(float x, float y, float w, float h, u32 color);
  void nine(const Region& r, int border, float x, float y, float w, float h, float k, u32 color = kWhite);
  void rawQuad(TexHandle tex, float x, float y, float w, float h, float u0, float v0, float u1, float v1, u32 color);
  int drawCalls = 0, quads = 0;

 private:
  void push(TexHandle tex, int atlas, float x0, float y0, float x1, float y1, float u0, float v0, float u1, float v1, u32 c);
  Backend* be_ = nullptr;
  const TexHandle* atlasTex_ = nullptr;
  const Region* white_[2] = {nullptr, nullptr};
  std::vector<Vertex> verts_;
  int count_ = 0;
  TexHandle curTex_ = 0;
  int curAtlas_ = 1;
  BlendMode blend_ = BlendMode::Alpha;
  float scale_ = 1.f;
};
}  // namespace cf
