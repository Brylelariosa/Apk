// Core math / small value types shared by every module.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace cf {

using u8 = uint8_t;   using u16 = uint16_t; using u32 = uint32_t; using u64 = uint64_t;
using i8 = int8_t;    using i16 = int16_t;  using i32 = int32_t;  using i64 = int64_t;

constexpr int kTile = 16;  // world pixels per tile

template <class T> inline T clampv(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline float smooth01(float t) { t = clampv(t, 0.f, 1.f); return t * t * (3.f - 2.f * t); }
inline int roundi(float v) { return (int)std::floor(v + 0.5f); }

struct Vec2 {
  float x = 0, y = 0;
  Vec2() {}
  Vec2(float X, float Y) : x(X), y(Y) {}
  Vec2 operator+(Vec2 o) const { return {x + o.x, y + o.y}; }
  Vec2 operator-(Vec2 o) const { return {x - o.x, y - o.y}; }
  Vec2 operator*(float s) const { return {x * s, y * s}; }
  Vec2& operator+=(Vec2 o) { x += o.x; y += o.y; return *this; }
  float len2() const { return x * x + y * y; }
  float len() const { return std::sqrt(x * x + y * y); }
};

struct IVec2 {
  int x = 0, y = 0;
  IVec2() {}
  IVec2(int X, int Y) : x(X), y(Y) {}
  bool operator==(const IVec2& o) const { return x == o.x && y == o.y; }
  bool operator!=(const IVec2& o) const { return !(*this == o); }
};

struct Rect {
  float x = 0, y = 0, w = 0, h = 0;
  Rect() {}
  Rect(float X, float Y, float W, float H) : x(X), y(Y), w(W), h(H) {}
  float right() const { return x + w; }
  float bottom() const { return y + h; }
  bool contains(float px, float py) const { return px >= x && py >= y && px < x + w && py < y + h; }
  bool contains(Vec2 p) const { return contains(p.x, p.y); }
  bool intersects(const Rect& o) const { return x < o.x + o.w && o.x < x + w && y < o.y + o.h && o.y < y + h; }
  Vec2 center() const { return {x + w * 0.5f, y + h * 0.5f}; }
  Rect inset(float d) const { return {x + d, y + d, w - 2 * d, h - 2 * d}; }
};

// Packed colours are 0xAABBGGRR (bytes r,g,b,a in memory on little-endian) to match GL_UNSIGNED_BYTE attributes.
namespace col {
constexpr u32 rgba(int r, int g, int b, int a = 255) { return (u32)r | ((u32)g << 8) | ((u32)b << 16) | ((u32)a << 24); }
constexpr u32 White = 0xFFFFFFFFu;
inline u32 withAlpha(u32 c, float a) {
  u32 na = (u32)clampv((int)((float)(c >> 24) * a), 0, 255);
  return (c & 0x00FFFFFFu) | (na << 24);
}
inline u32 mul(u32 c, float k) {
  int r = clampv((int)((c & 255) * k), 0, 255), g = clampv((int)(((c >> 8) & 255) * k), 0, 255),
      b = clampv((int)(((c >> 16) & 255) * k), 0, 255);
  return (u32)r | ((u32)g << 8) | ((u32)b << 16) | (c & 0xFF000000u);
}
inline u32 lerp(u32 a, u32 b, float t) {
  auto ch = [&](int sh) { return (u32)clampv((int)(((a >> sh) & 255) * (1 - t) + ((b >> sh) & 255) * t + 0.5f), 0, 255); };
  return ch(0) | (ch(8) << 8) | (ch(16) << 16) | (ch(24) << 24);
}
}  // namespace col
constexpr u32 kWhite = 0xFFFFFFFFu;

enum class Dir : u8 { Down = 0, Up = 1, Left = 2, Right = 3 };
inline IVec2 dirVec(Dir d) {
  switch (d) { case Dir::Down: return {0, 1}; case Dir::Up: return {0, -1}; case Dir::Left: return {-1, 0}; default: return {1, 0}; }
}
inline Dir dirFromVec(float dx, float dy) {
  if (std::fabs(dx) > std::fabs(dy)) return dx < 0 ? Dir::Left : Dir::Right;
  return dy < 0 ? Dir::Up : Dir::Down;
}
inline Dir oppositeDir(Dir d) {
  switch (d) { case Dir::Down: return Dir::Up; case Dir::Up: return Dir::Down; case Dir::Left: return Dir::Right; default: return Dir::Left; }
}

inline std::string fmt(const char* f, ...) __attribute__((format(printf, 1, 2)));
inline std::string fmt(const char* f, ...) {
  char buf[512];
  va_list ap; va_start(ap, f);
  vsnprintf(buf, sizeof buf, f, ap);
  va_end(ap);
  return buf;
}
}  // namespace cf
