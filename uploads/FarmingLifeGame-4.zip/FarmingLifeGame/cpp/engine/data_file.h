// Tiny line-based data format (".cfd") used by all game content tables.
//   type key=value key="quoted value with spaces" key=a,b,c   # comment
// Used both by the C++ game and tools/gen_assets.py so art and data stay in sync.
#pragma once
#include "engine/types.h"

namespace cf {
struct Record {
  std::string type;
  std::vector<std::pair<std::string, std::string>> kv;
  int line = 0;
  const std::string* find(const char* key) const {
    for (auto& p : kv) if (p.first == key) return &p.second;
    return nullptr;
  }
  bool has(const char* key) const { return find(key) != nullptr; }
  std::string str(const char* key, const std::string& def = "") const { auto* v = find(key); return v ? *v : def; }
  int integer(const char* key, int def = 0) const { auto* v = find(key); return v && !v->empty() ? atoi(v->c_str()) : def; }
  float num(const char* key, float def = 0) const { auto* v = find(key); return v && !v->empty() ? (float)atof(v->c_str()) : def; }
  bool flag(const char* key, bool def = false) const { auto* v = find(key); return v ? (*v == "1" || *v == "true" || *v == "yes") : def; }
  std::vector<std::string> list(const char* key, char sep = ',') const;
};
std::vector<std::string> splitString(const std::string& s, char sep);
bool parseDataText(const std::string& text, std::vector<Record>& out, const char* name);
bool loadDataFile(const std::string& assetPath, std::vector<Record>& out);   // via Platform::readAsset
int parseClock(const std::string& s);   // "7:30" -> 450 minutes, "26:00" -> 1560; -1 on error
}  // namespace cf
