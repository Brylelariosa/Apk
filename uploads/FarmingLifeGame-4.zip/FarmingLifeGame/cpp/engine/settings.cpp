#include "engine/settings.h"
#include <sstream>
namespace cf {
void Settings::applyPreset(Gfx g) {
  preset = g;
  switch (g) {
    case Gfx::High: shadows = lighting = waterFx = treeSway = true; particles = 3; weatherDensity = 3; targetFps = 60; break;
    case Gfx::Balanced: shadows = lighting = waterFx = treeSway = true; particles = 2; weatherDensity = 2; targetFps = 60; break;
    case Gfx::Performance: shadows = false; lighting = false; waterFx = false; treeSway = false; particles = 1; weatherDensity = 1; targetFps = 30; break;
    default: break;
  }
}
std::string Settings::serialize() const {
  std::ostringstream o;
  o << "preset=" << (int)preset << "\nshadows=" << shadows << "\nlighting=" << lighting << "\nwaterFx=" << waterFx << "\ntreeSway=" << treeSway
    << "\nparticles=" << particles << "\nweather=" << weatherDensity << "\nfps=" << targetFps << "\nzoom=" << zoom << "\nuiScale=" << uiScale << "\ntextSize=" << textSize
    << "\ncontrast=" << highContrast << "\nlargeButtons=" << largeButtons << "\nreduced=" << reducedMotion << "\nvibration=" << vibration << "\ndebug=" << debugOverlay
    << "\nmusic=" << music << "\nsfx=" << sfx << "\n";
  auto h = [&](const char* n, const HudElem& e) { o << n << "=" << e.x << "," << e.y << "," << e.scale << "," << e.opacity << "\n"; };
  h("hudJoy", joy); h("hudAct", act); h("hudItem", itemBox); h("hudMenu", menu);
  return o.str();
}
void Settings::parse(const std::string& text) {
  std::istringstream in(text); std::string ln;
  auto hud = [](const std::string& v, HudElem& e) { float a, b, c, d; if (sscanf(v.c_str(), "%f,%f,%f,%f", &a, &b, &c, &d) == 4) { e.x = clampv(a, 0.f, 1.f); e.y = clampv(b, 0.f, 1.f); e.scale = clampv(c, 0.6f, 2.f); e.opacity = clampv(d, 0.2f, 1.f); } };
  while (std::getline(in, ln)) {
    size_t eq = ln.find('='); if (eq == std::string::npos) continue;
    std::string k = ln.substr(0, eq), v = ln.substr(eq + 1); int iv = atoi(v.c_str()); float fv = (float)atof(v.c_str());
    if (k == "preset") preset = (Gfx)clampv(iv, 0, 3); else if (k == "shadows") shadows = iv; else if (k == "lighting") lighting = iv; else if (k == "waterFx") waterFx = iv;
    else if (k == "treeSway") treeSway = iv; else if (k == "particles") particles = clampv(iv, 0, 3); else if (k == "weather") weatherDensity = clampv(iv, 0, 3);
    else if (k == "fps") targetFps = iv >= 60 ? 60 : 30; else if (k == "zoom") zoom = clampv(iv, -1, 3); else if (k == "uiScale") uiScale = clampv(fv, 0.7f, 1.6f);
    else if (k == "textSize") textSize = clampv(iv, 0, 2); else if (k == "contrast") highContrast = iv; else if (k == "largeButtons") largeButtons = iv;
    else if (k == "reduced") reducedMotion = iv; else if (k == "vibration") vibration = iv; else if (k == "debug") debugOverlay = iv;
    else if (k == "music") music = clampv(fv, 0.f, 1.f); else if (k == "sfx") sfx = clampv(fv, 0.f, 1.f);
    else if (k == "hudJoy") hud(v, joy); else if (k == "hudAct") hud(v, act); else if (k == "hudItem") hud(v, itemBox); else if (k == "hudMenu") hud(v, menu);
  }
}
}  // namespace cf
