// Application glue: owns renderer/input/audio/game and runs the fixed-timestep loop. Platform entry points drive it.
#pragma once
#include <memory>
#include "audio/audio.h"
#include "game/game.h"
#include "input/input.h"
#include "renderer/renderer.h"

namespace cf {
class Application {
 public:
  bool init(std::unique_ptr<Backend> backend, Platform* platform, int w, int h, float density, float refreshHz, bool debug);
  bool onSurfaceCreated();                       // GL context (re)created: initialises backend + textures
  void onSurfaceChanged(int w, int h);
  void setInsets(int l, int t, int r, int b) { insets_[0] = l; insets_[1] = t; insets_[2] = r; insets_[3] = b; }
  void frame();
  void touch(int type, int id, float x, float y) { input.pushEvent(type, id, x, y); }
  void back() { input.pushBack(); }
  void pause();
  void resume();
  int renderAudio(short* out, int frames) { return audio.render(out, frames); }
  bool wantsExit() const { return game.wantsExit; }
  int swapInterval() const;
  Game game; Renderer renderer; Input input; Audio audio;
 private:
  std::unique_ptr<Backend> backend_;
  Platform* plat_ = nullptr;
  int w_ = 1, h_ = 1, insets_[4] = {0, 0, 0, 0}; float density_ = 2.f, refresh_ = 60.f;
  double last_ = 0; float acc_ = 0, fpsAcc_ = 0; int fpsFrames_ = 0; bool rendererReady_ = false, contextEverCreated_ = false;
};
}  // namespace cf
