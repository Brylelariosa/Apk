// Small deterministic PCG32 random generator (no global state, cheap to copy/seed per system).
#pragma once
#include "engine/types.h"

namespace cf {
class Rng {
 public:
  explicit Rng(u64 seed = 0x853c49e6748fea9bULL) { reseed(seed); }
  void reseed(u64 seed) { state_ = 0; inc_ = (seed << 1u) | 1u; next(); state_ += seed ^ 0x9e3779b97f4a7c15ULL; next(); }
  u32 next() {
    u64 old = state_;
    state_ = old * 6364136223846793005ULL + inc_;
    u32 xs = (u32)(((old >> 18u) ^ old) >> 27u);
    u32 rot = (u32)(old >> 59u);
    return (xs >> rot) | (xs << ((~rot + 1u) & 31u));
  }
  float f() { return (float)(next() >> 8) * (1.0f / 16777216.0f); }               // [0,1)
  int range(int lo, int hi) { return hi <= lo ? lo : lo + (int)(next() % (u32)(hi - lo + 1)); }  // inclusive
  float rangef(float lo, float hi) { return lo + (hi - lo) * f(); }
  bool chance(float p) { return f() < p; }
  template <class T> const T& pick(const std::vector<T>& v) { return v[next() % v.size()]; }
  static u32 hash(u32 a, u32 b = 0, u32 c = 0) {
    u32 h = a * 0x9E3779B1u ^ (b + 0x7F4A7C15u) * 0x85EBCA6Bu ^ (c + 0x165667B1u) * 0xC2B2AE35u;
    h ^= h >> 15; h *= 0x2C1B3C6Du; h ^= h >> 12; h *= 0x297A2D39u; h ^= h >> 15;
    return h;
  }
  u64 state() const { return state_; }
 private:
  u64 state_ = 0, inc_ = 1;
};
}  // namespace cf
