#include "engine/app.h"
#include "engine/log.h"

namespace cf {
bool Application::init(std::unique_ptr<Backend> be, Platform* plat, int w, int h, float density, float refreshHz, bool debug) {
  backend_ = std::move(be); plat_ = plat; setPlatform(plat);
  w_ = w; h_ = h; density_ = density; refresh_ = refreshHz;
  game.r = &renderer; game.in = &input; game.audio = &audio; game.debugBuild = debug;
  if (!Renderer::loadAtlasIndexes()) { CF_LOGE("atlas indexes missing"); return false; }
  if (!game.init()) return false;
  audio.init(); audio.setVolumes(game.settings.music, game.settings.sfx);
  last_ = plat_->nowSeconds();
  return true;
}

bool Application::onSurfaceCreated() {
  if (contextEverCreated_) { renderer.contextLost(); }
  if (!backend_->init()) { CF_LOGE("backend init failed"); return false; }
  if (!rendererReady_) { rendererReady_ = renderer.init(backend_.get()); }
  else rendererReady_ = renderer.loadTextures();
  contextEverCreated_ = true;
  renderer.resize(w_, h_, density_, game.settings.zoom);
  last_ = plat_->nowSeconds();
  return rendererReady_;
}

void Application::onSurfaceChanged(int w, int h) { w_ = std::max(1, w); h_ = std::max(1, h); if (rendererReady_) renderer.resize(w_, h_, density_, game.settings.zoom); }

int Application::swapInterval() const { return std::max(1, (int)std::lround(refresh_ / (game.settings.targetFps >= 60 ? 60.f : 30.f))); }

void Application::pause() { game.onPause(); }
void Application::resume() { game.onResume(); last_ = plat_->nowSeconds(); acc_ = 0; }

void Application::frame() {
  if (!rendererReady_) return;
  double now = plat_->nowSeconds();
  float dt = (float)clampv(now - last_, 0.0, 0.1); last_ = now;
  renderer.resize(w_, h_, density_, game.settings.zoom);
  float m = 8.f * density_;
  game.safe = Rect((float)insets_[0] + m, (float)insets_[1] + m * 0.6f, (float)(w_ - insets_[0] - insets_[2]) - 2 * m, (float)(h_ - insets_[1] - insets_[3]) - m * 1.2f);
  input.beginFrame(dt);
  acc_ += dt; int steps = 0;
  while (acc_ >= 1.f / 60.f && steps < 5) { game.fixedUpdate(1.f / 60.f); acc_ -= 1.f / 60.f; ++steps; }
  if (steps == 5) acc_ = 0;
  game.frame(dt);
  input.endFrame();
  fpsAcc_ += dt; ++fpsFrames_;
  if (fpsAcc_ >= 0.5f) { game.fps = (float)fpsFrames_ / fpsAcc_; game.frameMs = 1000.f * fpsAcc_ / (float)fpsFrames_; fpsAcc_ = 0; fpsFrames_ = 0; }
  if (plat_->exitRequested) game.wantsExit = true;
}
}  // namespace cf
