#include "engine/log.h"
#include <cstdarg>
#include <cstdio>
#include "platform/platform.h"

namespace cf {
static Platform* g_platform = nullptr;
static int g_warns = 0;
void setPlatform(Platform* p) { g_platform = p; }
Platform& platform() { return *g_platform; }
int logWarnCount() { return g_warns; }
void resetLogCounters() { g_warns = 0; }

void logf(int level, const char* f, ...) {
  char buf[640];
  va_list ap; va_start(ap, f);
  vsnprintf(buf, sizeof buf, f, ap);
  va_end(ap);
  if (level >= 1) ++g_warns;
  if (g_platform) g_platform->log(level, buf); else fprintf(stderr, "[%d] %s\n", level, buf);
}
}  // namespace cf
