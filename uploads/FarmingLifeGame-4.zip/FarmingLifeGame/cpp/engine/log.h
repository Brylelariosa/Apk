#pragma once
#include "engine/types.h"
namespace cf {
void logf(int level, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
int logWarnCount();      // number of warnings+errors so far (used by tests)
void resetLogCounters();
}
#define CF_LOGI(...) ::cf::logf(0, __VA_ARGS__)
#define CF_LOGW(...) ::cf::logf(1, __VA_ARGS__)
#define CF_LOGE(...) ::cf::logf(2, __VA_ARGS__)
