#include "engine/data_file.h"
#include "engine/log.h"
#include "platform/platform.h"

namespace cf {

std::vector<std::string> splitString(const std::string& s, char sep) {
  std::vector<std::string> r;
  size_t st = 0;
  if (s.empty()) return r;
  for (size_t i = 0; i <= s.size(); ++i)
    if (i == s.size() || s[i] == sep) { r.push_back(s.substr(st, i - st)); st = i + 1; }
  return r;
}
std::vector<std::string> Record::list(const char* key, char sep) const {
  auto* v = find(key);
  return v ? splitString(*v, sep) : std::vector<std::string>();
}

int parseClock(const std::string& s) {
  size_t c = s.find(':');
  if (c == std::string::npos) return -1;
  return atoi(s.substr(0, c).c_str()) * 60 + atoi(s.substr(c + 1).c_str());
}

bool parseDataText(const std::string& text, std::vector<Record>& out, const char* name) {
  size_t pos = 0; int lineNo = 0; bool ok = true;
  while (pos <= text.size()) {
    size_t e = text.find('\n', pos);
    if (e == std::string::npos) e = text.size();
    std::string line = text.substr(pos, e - pos);
    pos = e + 1; ++lineNo;
    size_t i = 0, n = line.size();
    while (i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r')) ++i;
    if (i >= n || line[i] == '#') { if (e >= text.size()) break; continue; }
    Record rec; rec.line = lineNo;
    bool first = true;
    while (i < n) {
      while (i < n && (line[i] == ' ' || line[i] == '\t' || line[i] == '\r')) ++i;
      if (i >= n || line[i] == '#') break;
      std::string key, val;
      size_t st = i;
      while (i < n && line[i] != ' ' && line[i] != '\t' && line[i] != '=' && line[i] != '\r') ++i;
      key = line.substr(st, i - st);
      if (first) { rec.type = key; first = false; continue; }
      if (i < n && line[i] == '=') {
        ++i;
        if (i < n && line[i] == '"') {
          ++i;
          while (i < n && line[i] != '"') {
            if (line[i] == '\\' && i + 1 < n) {
              ++i;
              val += line[i] == 'n' ? '\n' : line[i];
            } else val += line[i];
            ++i;
          }
          if (i < n) ++i; else { CF_LOGW("%s:%d unterminated quote", name, lineNo); ok = false; }
        } else {
          size_t vs = i;
          while (i < n && line[i] != ' ' && line[i] != '\t' && line[i] != '\r') ++i;
          val = line.substr(vs, i - vs);
        }
      }
      rec.kv.emplace_back(key, val);
    }
    if (!rec.type.empty()) out.push_back(std::move(rec));
    if (e >= text.size()) break;
  }
  return ok;
}

bool loadDataFile(const std::string& assetPath, std::vector<Record>& out) {
  std::vector<u8> bytes;
  if (!platform().readAsset(assetPath, bytes)) { CF_LOGW("data file missing: %s", assetPath.c_str()); return false; }
  return parseDataText(std::string((const char*)bytes.data(), bytes.size()), out, assetPath.c_str());
}
}  // namespace cf
