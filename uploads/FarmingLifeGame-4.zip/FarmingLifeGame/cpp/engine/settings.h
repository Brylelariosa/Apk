#pragma once
#include "engine/types.h"
namespace cf {
enum class Gfx : u8 { High, Balanced, Performance, Custom };
struct HudElem { float x = 0.5f, y = 0.5f, scale = 1.f, opacity = 0.9f; };
struct Settings {
  Gfx preset = Gfx::Balanced;
  bool shadows = true, lighting = true, waterFx = true, treeSway = true;
  int particles = 2, weatherDensity = 2, targetFps = 60, zoom = 0;     // particles/weather 0..3
  float uiScale = 1.f; int textSize = 1;
  bool highContrast = false, largeButtons = false, reducedMotion = false, vibration = true, debugOverlay = false;
  float music = 0.7f, sfx = 0.9f;
  HudElem joy{0.12f, 0.74f, 1.f, 0.9f}, act{0.90f, 0.72f, 1.f, 0.9f}, itemBox{0.93f, 0.14f, 1.f, 1.f}, menu{0.82f, 0.14f, 1.f, 1.f};
  void applyPreset(Gfx g);
  void resetHud() { HudElem a, b, c, d; a = Settings().joy; b = Settings().act; c = Settings().itemBox; d = Settings().menu; joy = a; act = b; itemBox = c; menu = d; }
  std::string serialize() const;
  void parse(const std::string& text);
  int particleCap() const { static const int c[4] = {0, 250, 600, 1200}; return c[particles & 3]; }
};
}  // namespace cf
