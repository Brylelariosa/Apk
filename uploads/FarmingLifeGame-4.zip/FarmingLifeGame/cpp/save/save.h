// Versioned, checksummed binary save format with atomic writes and a rolling backup.
#pragma once
#include <unordered_map>
#include "items/content.h"

namespace cf {
constexpr u32 kSaveVersion = 1;

class SaveWriter {
 public:
  void wu8(u8 v) { body_.push_back(v); }
  void wbool(bool v) { wu8(v ? 1 : 0); }
  void wu16(u16 v) { wu8((u8)v); wu8((u8)(v >> 8)); }
  void wu32(u32 v) { wu16((u16)v); wu16((u16)(v >> 16)); }
  void wi32(int v) { wu32((u32)v); }
  void wf32(float v) { u32 b; memcpy(&b, &v, 4); wu32(b); }
  void wstr(const std::string& s);                 // interned in a string table
  void witem(const ItemStack& s);
  std::vector<u8> finish() const;                  // header + string table + body
 private:
  std::vector<u8> body_;
  std::vector<std::string> table_;
  std::unordered_map<std::string, u16> idx_;
};

class SaveReader {
 public:
  bool open(const std::vector<u8>& file);
  u32 version = 0;
  bool ok = true;
  u8 ru8() { if (pos_ >= end_) { ok = false; return 0; } return data_[pos_++]; }
  bool rbool() { return ru8() != 0; }
  u16 ru16() { u16 a = ru8(); u16 b = ru8(); return (u16)(a | (b << 8)); }
  u32 ru32() { u32 a = ru16(); u32 b = ru16(); return a | (b << 16); }
  int ri32() { return (int)ru32(); }
  float rf32() { u32 b = ru32(); float f; memcpy(&f, &b, 4); return f; }
  std::string rstr() { u16 i = ru16(); if (i >= table_.size()) { ok = false; return ""; } return table_[i]; }
  ItemStack ritem();
  bool eof() const { return pos_ >= end_; }
 private:
  std::vector<u8> data_;
  size_t pos_ = 0, end_ = 0;
  std::vector<std::string> table_;
};

u32 crc32(const u8* d, size_t n);
bool writeSaveFile(const std::string& dir, const std::string& name, const std::vector<u8>& bytes);   // tmp -> bak -> rename
bool readSaveFile(const std::string& dir, const std::string& name, std::vector<u8>& out);            // falls back to the backup
bool saveFileExists(const std::string& dir, const std::string& name);
}  // namespace cf
