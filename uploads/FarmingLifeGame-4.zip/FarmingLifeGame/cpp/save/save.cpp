#include "save/save.h"
#include <cstdio>
#include <unistd.h>
#include "engine/log.h"
#include "game/game.h"
#include "platform/platform.h"

namespace cf {

u32 crc32(const u8* d, size_t n) {
  u32 c = 0xFFFFFFFFu;
  for (size_t i = 0; i < n; ++i) { c ^= d[i]; for (int k = 0; k < 8; ++k) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1u))); }
  return ~c;
}

void SaveWriter::wstr(const std::string& s) {
  auto it = idx_.find(s);
  if (it == idx_.end()) { it = idx_.emplace(s, (u16)table_.size()).first; table_.push_back(s); }
  wu16(it->second);
}
void SaveWriter::witem(const ItemStack& s) {
  wstr(s.empty() ? "" : C().def(s.id).id); wu16(s.count); wu8(s.quality); wu8(s.tier); wu16(s.aux);
}
std::vector<u8> SaveWriter::finish() const {
  std::vector<u8> payload;
  auto p32 = [&](u32 v) { for (int i = 0; i < 4; ++i) payload.push_back((u8)(v >> (8 * i))); };
  p32((u32)table_.size());
  for (auto& s : table_) { u16 l = (u16)std::min<size_t>(s.size(), 65535); payload.push_back((u8)l); payload.push_back((u8)(l >> 8)); payload.insert(payload.end(), s.begin(), s.begin() + l); }
  payload.insert(payload.end(), body_.begin(), body_.end());
  std::vector<u8> out{'C', 'F', 'S', 'V'};
  auto o32 = [&](u32 v) { for (int i = 0; i < 4; ++i) out.push_back((u8)(v >> (8 * i))); };
  o32(kSaveVersion); o32((u32)payload.size()); o32(crc32(payload.data(), payload.size()));
  out.insert(out.end(), payload.begin(), payload.end());
  return out;
}
bool SaveReader::open(const std::vector<u8>& f) {
  if (f.size() < 16 || memcmp(f.data(), "CFSV", 4) != 0) return false;
  auto g32 = [&](size_t o) { return (u32)f[o] | ((u32)f[o + 1] << 8) | ((u32)f[o + 2] << 16) | ((u32)f[o + 3] << 24); };
  version = g32(4); u32 sz = g32(8), crc = g32(12);
  if (sz + 16 != f.size() || crc32(f.data() + 16, sz) != crc) return false;
  if (version == 0 || version > kSaveVersion) return false;
  data_.assign(f.begin() + 16, f.end()); pos_ = 0; end_ = data_.size();
  u32 n = ru32();
  for (u32 i = 0; i < n && ok; ++i) { u16 l = ru16(); std::string s; for (u16 k = 0; k < l && ok; ++k) s += (char)ru8(); table_.push_back(s); }
  return ok;
}
ItemStack SaveReader::ritem() {
  ItemStack s; std::string id = rstr(); s.count = ru16(); s.quality = ru8(); s.tier = ru8(); s.aux = ru16();
  s.id = id.empty() ? 0 : (u16)C().item(id);
  if (!s.id) s.count = 0;
  return s;
}

bool writeSaveFile(const std::string& dir, const std::string& name, const std::vector<u8>& bytes) {
  std::string base = dir + "/" + name, tmp = base + ".tmp", bak = base + ".bak", dat = base + ".dat";
  FILE* f = fopen(tmp.c_str(), "wb"); if (!f) { CF_LOGE("save: cannot open %s", tmp.c_str()); return false; }
  bool ok = fwrite(bytes.data(), 1, bytes.size(), f) == bytes.size();
  ok = ok && fflush(f) == 0; fsync(fileno(f)); fclose(f);
  if (!ok) { remove(tmp.c_str()); return false; }
  if (FILE* old = fopen(dat.c_str(), "rb")) { fclose(old); remove(bak.c_str()); rename(dat.c_str(), bak.c_str()); }
  if (rename(tmp.c_str(), dat.c_str()) != 0) { CF_LOGE("save: rename failed"); return false; }
  return true;
}
static bool slurp(const std::string& path, std::vector<u8>& out) {
  FILE* f = fopen(path.c_str(), "rb"); if (!f) return false;
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  out.resize((size_t)std::max(0L, n)); bool ok = n >= 0 && fread(out.data(), 1, out.size(), f) == out.size(); fclose(f); return ok;
}
bool readSaveFile(const std::string& dir, const std::string& name, std::vector<u8>& out) {
  std::string base = dir + "/" + name;
  SaveReader probe;
  if (slurp(base + ".dat", out) && probe.open(out)) return true;
  CF_LOGW("save: primary file unreadable, trying backup");
  SaveReader probe2;
  return slurp(base + ".bak", out) && probe2.open(out);
}
bool saveFileExists(const std::string& dir, const std::string& name) {
  for (const char* ext : {".dat", ".bak"}) { FILE* f = fopen((dir + "/" + name + ext).c_str(), "rb"); if (f) { fclose(f); return true; } }
  return false;
}

// ---------------------------------------------------------------------------------------------------------------- game state
void Game::serialize(SaveWriter& w) {
  w.wi32(s.seed); w.wstr(s.curMap); w.wf32((float)s.playSeconds); w.wi32(s.deepestMine); w.wi32(s.farmhouseLevel);
  w.wi32(s.cal.year); w.wi32(s.cal.season); w.wi32(s.cal.day); w.wi32(s.cal.minutes);
  w.wu8((u8)s.wx.today); w.wu8((u8)s.wx.tomorrow);
  for (int i = 0; i < 3; ++i) w.wi32(hayStock[i]);
  Player& p = s.pl;
  w.wstr(p.name); w.wi32(p.look); w.wf32(p.pos.x); w.wf32(p.pos.y); w.wu8((u8)p.facing); w.wf32(p.energy); w.wf32(p.health); w.wi32(p.money); w.wi32(p.sel);
  for (int i = 0; i < 4; ++i) w.wi32(p.xp[i]);
  w.wu16((u16)p.inv.slots.size()); for (auto& st : p.inv.slots) w.witem(st);
  w.wu16((u16)p.buffs.size()); for (auto& b : p.buffs) { w.wu8((u8)b.type); w.wi32(b.amount); w.wi32(b.minutes); }
  auto strSet = [&](const std::set<std::string>& v) { w.wu32((u32)v.size()); for (auto& e : v) w.wstr(e); };
  strSet(s.flags); strSet(s.recipes); strSet(s.seenItems); strSet(s.caught); strSet(s.minerals);
  w.wu32((u32)s.counters.size()); for (auto& kv : s.counters) { w.wstr(kv.first); w.wi32(kv.second); }
  w.wu16((u16)s.npcs.size());
  for (auto& n : s.npcs) {
    w.wstr(C().npcs[(size_t)n.def].id); w.wstr(n.map); w.wf32(n.pos.x); w.wf32(n.pos.y); w.wu8((u8)n.facing); w.wbool(n.inside); w.wbool(n.traveling);
    w.wi32(n.friendship); w.wi32(n.giftsWeek); w.wi32(n.dating); w.wbool(n.talked); w.wbool(n.gifted); w.wi32(n.schedIdx); w.wstr(n.act);
    w.wstr(n.destMap); w.wstr(n.destAt); w.wi32(n.travelLeft); w.wi32(n.anchor.x); w.wi32(n.anchor.y); w.wbool(n.hasTarget); w.wi32(n.target.x); w.wi32(n.target.y);
  }
  w.wu16((u16)s.animals.size());
  for (auto& a : s.animals) {
    w.wstr(C().animals[(size_t)a.def].id); w.wi32(a.building); w.wstr(a.name); w.wf32(a.pos.x); w.wf32(a.pos.y); w.wbool(a.inside);
    w.wi32(a.hunger); w.wi32(a.happiness); w.wi32(a.health); w.wi32(a.affection); w.wi32(a.age); w.wi32(a.personality); w.wi32(a.daysSince); w.wi32(a.quality);
    w.wbool(a.product); w.wbool(a.petted); w.wbool(a.fed);
  }
  w.wu16((u16)s.pending.size()); for (auto& pu : s.pending) { w.wi32(pu.kind); w.wi32(pu.a); w.wi32(pu.b); w.wi32(pu.days); }
  w.wu16((u16)s.quests.size());
  for (auto& q : s.quests) { w.wstr(C().quests[(size_t)q.def].id); w.wbool(q.done); w.wu16((u16)q.prog.size()); for (int v : q.prog) w.wi32(v); }
  w.wu16((u16)s.bin.size()); for (auto& st : s.bin) w.witem(st);
  std::vector<Map*> saved;
  for (auto& kv : s.maps) if (kv.second->mineFloor == 0) saved.push_back(kv.second.get());
  w.wu16((u16)saved.size());
  for (Map* m : saved) {
    w.wstr(m->id);
    w.wu16((u16)m->buildings.size()); for (auto& b : m->buildings) { w.wi32(b.level); w.wi32(b.buildDays); }
    std::vector<std::pair<u32, u8>> tl; for (size_t i = 0; i < m->tiles.size(); ++i) if (m->tiles[i].flags) tl.push_back({(u32)i, m->tiles[i].flags});
    w.wu32((u32)tl.size()); for (auto& t : tl) { w.wu32(t.first); w.wu8(t.second); }
    w.wu32((u32)m->chests.size());
    for (auto& c : m->chests) { w.wu16((u16)c.slots.size()); for (auto& st : c.slots) w.witem(st); }
    u32 n = 0; for (auto& o : m->objs) if (o.alive()) ++n;
    w.wu32(n);
    for (auto& o : m->objs) {
      if (!o.alive()) continue;
      w.wu8((u8)o.kind);
      w.wstr(o.kind == ObjKind::Crop ? C().crops[o.def].id : C().objs[o.def].id);
      w.wi32(o.x); w.wi32(o.y); w.wu16(o.hp); w.wu16(o.days); w.wu8(o.state); w.wu16(o.aux2);
      if (o.kind == ObjKind::Forage) w.wstr(C().def((int)o.aux).id);
      else if (o.kind == ObjKind::Machine) { w.wstr(C().def((int)(o.aux & 0xFFFF)).id); w.wu16((u16)(o.aux >> 16)); }
      else w.wu32(o.aux);
    }
  }
}

bool Game::deserialize(SaveReader& r) {
  s = Session();
  s.seed = r.ri32(); std::string cur = r.rstr(); s.playSeconds = r.rf32(); s.deepestMine = r.ri32(); s.farmhouseLevel = clampv(r.ri32(), 1, 3);
  s.cal.year = r.ri32(); s.cal.season = clampv(r.ri32(), 0, 3); s.cal.day = clampv(r.ri32(), 1, 28); s.cal.minutes = clampv(r.ri32(), kDayStart, kDayEnd);
  s.wx.today = (Weather)clampv((int)r.ru8(), 0, 7); s.wx.tomorrow = (Weather)clampv((int)r.ru8(), 0, 7);
  for (int i = 0; i < 3; ++i) hayStock[i] = r.ri32();
  Player& p = s.pl;
  p.name = r.rstr(); p.look = r.ri32(); p.pos.x = r.rf32(); p.pos.y = r.rf32(); p.facing = (Dir)clampv((int)r.ru8(), 0, 3);
  p.energy = r.rf32(); p.health = r.rf32(); p.money = r.ri32(); p.sel = clampv(r.ri32(), 0, 11);
  for (int i = 0; i < 4; ++i) p.xp[i] = r.ri32();
  u16 ns = r.ru16(); for (u16 i = 0; i < ns && r.ok; ++i) { ItemStack st = r.ritem(); if (i < p.inv.slots.size()) p.inv.slots[i] = st; }
  u16 nb = r.ru16(); for (u16 i = 0; i < nb && r.ok; ++i) { ActiveBuff b; b.type = (BuffType)r.ru8(); b.amount = r.ri32(); b.minutes = r.ri32(); p.buffs.push_back(b); }
  auto rdSet = [&](std::set<std::string>& v) { u32 n = r.ru32(); for (u32 i = 0; i < n && r.ok; ++i) v.insert(r.rstr()); };
  rdSet(s.flags); rdSet(s.recipes); rdSet(s.seenItems); rdSet(s.caught); rdSet(s.minerals);
  u32 nc = r.ru32(); for (u32 i = 0; i < nc && r.ok; ++i) { std::string k = r.rstr(); s.counters[k] = r.ri32(); }
  if (!r.ok) return false;
  initNpcs();
  u16 nn = r.ru16();
  for (u16 i = 0; i < nn && r.ok; ++i) {
    std::string id = r.rstr(); int ni = C().npc(id);
    NpcState tmp; std::string map = r.rstr(); tmp.pos.x = r.rf32(); tmp.pos.y = r.rf32(); tmp.facing = (Dir)clampv((int)r.ru8(), 0, 3); tmp.inside = r.rbool(); tmp.traveling = r.rbool();
    tmp.friendship = r.ri32(); tmp.giftsWeek = r.ri32(); tmp.dating = r.ri32(); tmp.talked = r.rbool(); tmp.gifted = r.rbool(); tmp.schedIdx = r.ri32(); tmp.act = r.rstr();
    tmp.destMap = r.rstr(); tmp.destAt = r.rstr(); tmp.travelLeft = r.ri32(); tmp.anchor.x = r.ri32(); tmp.anchor.y = r.ri32(); tmp.hasTarget = r.rbool(); tmp.target.x = r.ri32(); tmp.target.y = r.ri32();
    if (ni < 0) continue;
    NpcState& n = s.npcs[(size_t)ni]; int def = n.def; n = tmp; n.def = def; n.map = map;
  }
  u16 na = r.ru16();
  for (u16 i = 0; i < na && r.ok; ++i) {
    AnimalState a; std::string id = r.rstr(); a.building = r.ri32(); a.name = r.rstr(); a.pos.x = r.rf32(); a.pos.y = r.rf32(); a.inside = r.rbool();
    a.hunger = r.ri32(); a.happiness = r.ri32(); a.health = r.ri32(); a.affection = r.ri32(); a.age = r.ri32(); a.personality = r.ri32(); a.daysSince = r.ri32(); a.quality = r.ri32();
    a.product = r.rbool(); a.petted = r.rbool(); a.fed = r.rbool(); a.dest = a.pos;
    int ai = C().animal(id); if (ai >= 0) { a.def = ai; s.animals.push_back(a); }
  }
  u16 np = r.ru16(); for (u16 i = 0; i < np && r.ok; ++i) { PendingUp pu; pu.kind = r.ri32(); pu.a = r.ri32(); pu.b = r.ri32(); pu.days = r.ri32(); s.pending.push_back(pu); }
  u16 nq = r.ru16();
  for (u16 i = 0; i < nq && r.ok; ++i) {
    std::string id = r.rstr(); QuestState q; q.done = r.rbool(); u16 pn = r.ru16(); for (u16 k = 0; k < pn && r.ok; ++k) q.prog.push_back(r.ri32());
    int qi = C().quest(id); if (qi < 0) continue; q.def = qi; q.prog.resize(C().quests[(size_t)qi].objs.size(), 0); s.quests.push_back(q);
  }
  u16 nbin = r.ru16(); for (u16 i = 0; i < nbin && r.ok; ++i) { ItemStack st = r.ritem(); if (!st.empty()) s.bin.push_back(st); }
  u16 nm = r.ru16();
  for (u16 mi = 0; mi < nm && r.ok; ++mi) {
    std::string id = r.rstr();
    Map* m = getMap(id);
    u16 nbd = r.ru16(); std::vector<std::pair<int, int>> bl; for (u16 i = 0; i < nbd; ++i) { int lv = r.ri32(); int bd = r.ri32(); bl.push_back({lv, bd}); }
    if (m) for (size_t i = 0; i < bl.size() && i < m->buildings.size(); ++i) { m->buildings[i].level = clampv(bl[i].first, 1, 3); m->buildings[i].buildDays = bl[i].second; }
    u32 ntl = r.ru32(); std::vector<std::pair<u32, u8>> tl; for (u32 i = 0; i < ntl && r.ok; ++i) { u32 ix = r.ru32(); u8 fl = r.ru8(); tl.push_back({ix, fl}); }
    u32 nch = r.ru32(); std::vector<ChestData> chests(nch);
    for (u32 i = 0; i < nch && r.ok; ++i) { u16 sn = r.ru16(); for (u16 k = 0; k < sn && r.ok; ++k) chests[i].slots.push_back(r.ritem()); }
    u32 no = r.ru32(); std::vector<MapObject> objs;
    for (u32 i = 0; i < no && r.ok; ++i) {
      MapObject o; ObjKind kind = (ObjKind)r.ru8(); std::string did = r.rstr(); o.kind = kind; o.x = (i16)r.ri32(); o.y = (i16)r.ri32(); o.hp = r.ru16(); o.days = r.ru16(); o.state = r.ru8(); o.aux2 = r.ru16();
      if (kind == ObjKind::Forage) o.aux = (u32)C().item(r.rstr());
      else if (kind == ObjKind::Machine) { u32 it = (u32)C().item(r.rstr()); o.aux = it | ((u32)r.ru16() << 16); }
      else o.aux = r.ru32();
      int d = kind == ObjKind::Crop ? C().crop(did) : C().obj(did);
      if (d < 0 || (kind == ObjKind::Forage && !o.aux)) continue;
      o.def = (u16)d; objs.push_back(o);
    }
    if (!m) continue;
    for (auto& t : m->tiles) t.flags = 0;
    for (auto& t : tl) if (t.first < m->tiles.size()) m->tiles[t.first].flags = t.second;
    m->objs = objs; m->chests = chests; m->rebuildObjIndex();
  }
  if (!r.ok) return false;
  s.curMap = cur;
  if (s.curMap.rfind("mine_", 0) == 0) s.curMap = "farm";
  if (!getMap(s.curMap)) s.curMap = "farm";
  s.pl.map = s.curMap;
  hasSession = true;
  return true;
}

bool Game::hasSave() const { return saveFileExists(platform().dataDir(), "save1"); }

bool Game::saveGame(bool quiet) {
  if (!hasSession) return false;
  SaveWriter w; serialize(w);
  bool ok = writeSaveFile(platform().dataDir(), "save1", w.finish());
  if (!quiet) toast(ok ? "Game saved." : "Saving failed!", ok ? "ic_save" : "ic_lock");
  if (!ok) saveError = "Could not write the save file.";
  return ok;
}

bool Game::continueGame() {
  std::vector<u8> bytes;
  if (!readSaveFile(platform().dataDir(), "save1", bytes)) { saveError = "No readable save file."; return false; }
  SaveReader r; if (!r.open(bytes)) { saveError = "The save file is damaged."; return false; }
  fx.clear(); stack.clear();
  if (!deserialize(r)) { hasSession = false; saveError = "The save file could not be loaded."; CF_LOGE("save: deserialize failed"); return false; }
  cam.snap(s.pl.pos);
  placeNpcsForMap(s.curMap);
  updateQuests();
  setStatusMood();
  setRoot(St::Gameplay);
  return true;
}
}  // namespace cf
