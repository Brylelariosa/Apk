// Mine hazards: pulsing spike plates and loose holes.
#include "game/game.h"
namespace cf {
void Game::hurt(float hp) {
  Player& p = s.pl; p.health = std::max(0.f, p.health - hp);
  audio->play(Sfx::Hurt); if (!settings.reducedMotion) cam.shake(2.5f);
  if (settings.vibration) platform().vibrate(60);
  if (p.health <= 0) { toast("You blacked out..."); summary.notes.clear(); newDay(true); }
}
void Game::updateHazards(float dt) {
  hazardCd = std::max(0.f, hazardCd - dt);
  Map& m = map(); if (m.mineFloor <= 0) return;
  IVec2 t = playerTile(); int oi = m.objectAt(t.x, t.y); if (oi < 0) return;
  MapObject& o = m.objs[(size_t)oi];
  if (o.kind == ObjKind::Hazard) {
    bool active = (((int)(timeSec * 0.55f) + o.x + o.y) & 1) == 0;
    if (active && hazardCd <= 0) { hazardCd = 1.2f; hurt(9); toast("Spikes!", "ic_heart_empty"); }
  } else if (o.kind == ObjKind::Hole && !fading) {
    hurt(5); if (s.pl.health > 0) { toast("You fell through a hole!"); descendMine(m.mineFloor + 1); }
  }
}
}  // namespace cf
