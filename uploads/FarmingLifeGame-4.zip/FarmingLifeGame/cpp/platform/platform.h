// Thin platform abstraction. Android implements it in jni/, the host test harness in tools/hostcheck.
#pragma once
#include "engine/types.h"

namespace cf {
class Platform {
 public:
  virtual ~Platform() {}
  virtual bool readAsset(const std::string& path, std::vector<u8>& out) = 0;  // path relative to assets/
  virtual std::string dataDir() = 0;                                         // writable dir (no trailing slash)
  virtual void log(int level, const char* msg) = 0;                          // 0 info, 1 warn, 2 error
  virtual double nowSeconds() = 0;
  virtual void vibrate(int /*ms*/) {}
  virtual size_t memoryUsageKB() { return 0; }
  virtual void requestExit() { exitRequested = true; }
  bool exitRequested = false;
};
void setPlatform(Platform* p);
Platform& platform();
}  // namespace cf
