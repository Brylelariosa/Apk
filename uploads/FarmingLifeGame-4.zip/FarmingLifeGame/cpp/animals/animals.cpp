// Farm animals: behaviour, daily care, products, purchase.
#include "game/game.h"

namespace cf {

BuildingInst* Game::farmBuilding(const std::string& id) {
  Map* m = getMap("farm"); if (!m) return nullptr;
  for (auto& b : m->buildings) if (C().buildings[(size_t)b.def].id == id) return &b;
  return nullptr;
}
int Game::buildingCapacity(int fb) const {
  auto it = s.maps.find("farm"); if (it == s.maps.end() || fb < 0 || fb >= (int)it->second->buildings.size()) return 0;
  const BuildingInst& b = it->second->buildings[(size_t)fb]; const BuildingDef& d = C().buildings[(size_t)b.def];
  return d.capacity[clampv(b.level - 1, 0, 2)];
}
int Game::animalsInBuilding(int fb) const { int n = 0; for (auto& a : s.animals) if (a.building == fb) ++n; return n; }

bool Game::buyAnimal(int defIdx, int fb) {
  const AnimalDef& d = C().animals[(size_t)defIdx];
  Map* m = getMap("farm"); if (!m || fb < 0 || fb >= (int)m->buildings.size()) return false;
  if (animalsInBuilding(fb) >= buildingCapacity(fb)) { toast("That building is full. Upgrade it for more room."); audio->play(Sfx::Error); return false; }
  if (s.pl.money < d.price) { toast("Not enough gold."); audio->play(Sfx::Error); return false; }
  s.pl.money -= d.price;
  static const char* names[] = {"Clover", "Biscuit", "Pebble", "Maple", "Nugget", "Daisy", "Pip", "Willow", "Mocha", "Sunny", "Poppy", "Juniper", "Bramble", "Honey", "Ziggy", "Olive"};
  AnimalState a; a.def = defIdx; a.building = fb; a.name = names[(s.animals.size() * 7 + (size_t)defIdx * 3) % 16];
  const BuildingInst& b = m->buildings[(size_t)fb]; const BuildingDef& bd = C().buildings[(size_t)b.def];
  a.pos = tileCenter(b.x + bd.door, b.y + 1); a.dest = a.pos; a.personality = rng.range(0, 3); a.hunger = 70; a.happiness = 70; a.inside = false;
  if (isRainy(s.wx.today) || s.cal.season == Winter) a.inside = true;
  s.animals.push_back(a);
  emitEvent("buy_animal", d.id); audio->play(Sfx::Coin);
  toast(fmt("%s the %s joined the farm!", a.name.c_str(), d.name.c_str()), "ic_heart");
  return true;
}

void Game::petAnimal(AnimalState& a) {
  if (!a.petted) { a.petted = true; a.affection = std::min(1000, a.affection + 14); a.happiness = std::min(100, a.happiness + 8); s.counters["pets"]++; emitEvent("pet", C().animals[(size_t)a.def].id); }
  fx.emit(Fx::Heart, a.pos.x, a.pos.y - 14, 0, -16, 0.9f);
  const std::string& id = C().animals[(size_t)a.def].id;
  audio->play(id == "cow" ? Sfx::Moo : id == "sheep" || id == "goat" ? Sfx::Baa : id == "duck" ? Sfx::Quack : id == "rabbit" ? Sfx::Squeak : Sfx::Cluck, 0.8f);
}
void Game::collectAnimal(AnimalState& a) {
  const AnimalDef& d = C().animals[(size_t)a.def];
  ItemStack st; st.id = (u16)d.product; st.count = 1; st.quality = (u8)a.quality;
  if (!s.pl.inv.canAdd(st)) { toast("Inventory full."); return; }
  giveItem(st); a.product = false; a.daysSince = 0; addXp(3, 3);
  emitEvent("collect", d.id); audio->play(Sfx::Pop);
  fx.emit(Fx::Sparkle, a.pos.x, a.pos.y - 10, 0, -14, 0.6f);
}

void Game::autoCollect() {
  Map* m = getMap("farm"); if (!m) return;
  for (auto& a : s.animals) {
    if (!a.product) continue;
    for (auto& o : m->objs) {
      if (o.kind != ObjKind::Collector || std::abs(o.x - (int)(a.pos.x / kTile)) > 16 || std::abs(o.y - (int)(a.pos.y / kTile)) > 14 || o.aux >= m->chests.size()) continue;
      ItemStack st; st.id = (u16)C().animals[(size_t)a.def].product; st.count = 1; st.quality = (u8)a.quality;
      auto& slots = m->chests[o.aux].slots; if (slots.size() < 24) slots.resize(24);
      bool done = false;
      for (auto& sl : slots) if (!sl.empty() && sl == st && sl.count < 99) { ++sl.count; done = true; break; }
      if (!done) for (auto& sl : slots) if (sl.empty()) { sl = st; done = true; break; }
      if (done) { a.product = false; a.daysSince = 0; break; }
    }
  }
}

void Game::animalsNewDay() {
  Map* m = getMap("farm");
  for (size_t i = 0; i < s.animals.size();) {
    AnimalState& a = s.animals[i]; const AnimalDef& d = C().animals[(size_t)a.def];
    ++a.age; ++a.daysSince;
    bool ate = a.hunger >= 60 || a.fed;
    if (!ate && hayStock[a.building] > 0) { --hayStock[a.building]; ate = true; }
    if (!ate && m) for (auto& o : m->objs) if (o.kind == ObjKind::Feeder && o.aux > 0) { --o.aux; ate = true; break; }
    if (ate) { a.hunger = 100; a.health = std::min(100, a.health + 4); }
    else { a.hunger = std::max(0, a.hunger - 45); a.health -= 18; a.happiness = std::max(0, a.happiness - 14); }
    a.happiness = a.petted ? std::min(100, a.happiness + 3) : std::max(10, a.happiness - 3);
    if (a.age >= d.adult && ate && a.daysSince >= d.interval && !a.product) {
      a.product = true;
      float score = a.happiness * 0.5f + (float)a.affection * 0.05f + a.health * 0.3f;
      a.quality = score > 105.f ? 2 : score > 85.f ? 1 : 0;
    }
    a.petted = false; a.fed = false; a.hunger = std::max(a.hunger, ate ? 100 : a.hunger);
    if (a.health <= 0) { summary.notes.push_back(fmt("%s the %s ran away. Keep your animals fed!", a.name.c_str(), d.name.c_str())); s.animals.erase(s.animals.begin() + (long)i); continue; }
    ++i;
  }
  autoCollect();
}

static bool grassAt(Map& m, Vec2 p) { return m.terrain((int)(p.x / kTile), (int)(p.y / kTile)) == Terrain::Grass; }

void Game::updateAnimals(float dt) {
  if (s.curMap != "farm") return;
  Map& m = map(); const MapRegion* pasture = m.region("pasture"); if (!pasture) return;
  int minutes = s.cal.minutes;
  bool stay = isRainy(s.wx.today) || s.cal.season == Winter || minutes >= 1140 || minutes < 400;
  for (auto& a : s.animals) {
    const AnimalDef& d = C().animals[(size_t)a.def];
    const BuildingInst& b = m.buildings[(size_t)clampv(a.building, 0, (int)m.buildings.size() - 1)];
    Vec2 door = tileCenter(b.x + C().buildings[(size_t)b.def].door, b.y + 1);
    if (stay) {
      if (!a.inside) { a.dest = door; Vec2 dv = a.dest - a.pos; if (dv.len() < 5.f) { a.inside = true; } }
    } else if (a.inside) { a.inside = false; a.pos = door + Vec2(rng.rangef(-6, 6), 4); a.act = 0; a.actT = 0; }
    if (a.inside) continue;
    a.actT -= dt; a.animT += dt;
    if (a.actT <= 0) {
      float r = rng.f();
      if (stay) { a.act = 0; a.actT = 0.5f; }
      else if (r < 0.45f) { a.act = 0; a.dest = Vec2(rng.rangef((float)pasture->x + 1, (float)(pasture->x + pasture->w - 1)) * kTile, rng.rangef((float)pasture->y + 1, (float)(pasture->y + pasture->h - 1)) * kTile); a.actT = rng.rangef(3, 7); }
      else if (r < 0.65f && grassAt(m, a.pos)) { a.act = 1; a.actT = rng.rangef(2, 4); a.hunger = std::min(100, a.hunger + 10); }
      else if (r < 0.78f) { a.act = 3; a.actT = rng.rangef(1.2f, 2.5f); }
      else if (r < 0.88f && (minutes > 720 && minutes < 900)) { a.act = 2; a.actT = rng.rangef(4, 8); }
      else if (r < 0.95f && a.affection > 120 && (s.pl.pos - a.pos).len() < 120.f) { a.act = 4; a.dest = s.pl.pos + Vec2(rng.rangef(-14, 14), 12); a.actT = rng.rangef(2, 4); }
      else { a.act = 0; a.dest = a.pos; a.actT = rng.rangef(1, 3); }
    }
    a.moving = false;
    if (a.act == 0 || a.act == 4) {
      Vec2 dv = a.dest - a.pos; float len = dv.len();
      if (len > 2.f) {
        float sp = d.speed * dt; Vec2 np = a.pos + dv * (sp / len);
        int tx = (int)(np.x / kTile), ty = (int)(np.y / kTile);
        if (!m.tileBlocked(tx, ty) && (stay || pasture->contains(tx, ty) || a.act == 4)) { a.pos = np; a.moving = true; if (std::fabs(dv.x) > 0.5f) a.facing = dv.x < 0 ? Dir::Left : Dir::Right; }
        else a.actT = 0;
      } else a.actT = std::min(a.actT, 0.3f);
    }
    if (a.act == 3 && rng.chance(0.002f)) { const std::string& id = d.id; audio->play(id == "cow" ? Sfx::Moo : id == "sheep" || id == "goat" ? Sfx::Baa : id == "duck" ? Sfx::Quack : id == "rabbit" ? Sfx::Squeak : Sfx::Cluck, 0.35f); }
    if (a.act == 2 && settings.particles && rng.chance(0.02f)) fx.emit(Fx::Zzz, a.pos.x + 4, a.pos.y - 14, 3, -8, 1.2f);
  }
}
}  // namespace cf
