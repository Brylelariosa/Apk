#include "input/input.h"

namespace cf {
void Input::pushEvent(int type, int id, float x, float y) {
  std::lock_guard<std::mutex> l(m_);
  if (q_.size() < 512) q_.push_back({type, id, x, y});
}
void Input::beginFrame(float dt) {
  std::vector<Ev> evs;
  { std::lock_guard<std::mutex> l(m_); evs.swap(q_); backPressed = back_; back_ = false; }
  for (auto& q : p) if (q.down) q.heldFor += dt;
  for (const Ev& e : evs) {
    Pointer* slot = nullptr;
    for (auto& q : p) if (q.id == e.id && (q.down || q.released)) { slot = &q; break; }
    if (e.type == 0) {
      if (!slot) for (auto& q : p) if (!q.down && !q.released) { slot = &q; break; }
      if (!slot) continue;
      slot->id = e.id; slot->down = true; slot->pressed = true; slot->released = false; slot->claimed = false; slot->owner = 0;
      slot->pos = slot->start = slot->prev = Vec2(e.x, e.y); slot->travel = 0; slot->heldFor = 0;
    } else if (slot) {
      if (e.type == 1) { slot->prev = slot->pos; slot->pos = Vec2(e.x, e.y); slot->travel += (slot->pos - slot->prev).len(); }
      else { slot->pos = Vec2(e.x, e.y); slot->down = false; slot->released = true; }
    }
  }
}
void Input::endFrame() {
  for (auto& q : p) {
    q.pressed = false;
    if (q.released) { q.released = false; q.id = -1; q.claimed = false; q.owner = 0; }
    q.prev = q.pos;
  }
}
void Input::releaseAll() { for (auto& q : p) { if (q.down) { q.down = false; q.released = true; } } }
}  // namespace cf
