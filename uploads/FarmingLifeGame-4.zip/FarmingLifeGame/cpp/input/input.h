// Multitouch pointer tracking. Events arrive from the Android UI thread and are applied once per frame.
#pragma once
#include <mutex>
#include "engine/types.h"

namespace cf {
struct Pointer {
  int id = -1;
  bool down = false, pressed = false, released = false, claimed = false;
  Vec2 pos, start, prev;
  float travel = 0, heldFor = 0;
  int owner = 0;                           // which HUD control claimed it (0 none)
};

class Input {
 public:
  static constexpr int kMax = 6;
  void pushEvent(int type, int id, float x, float y);     // 0 down, 1 move, 2 up, 3 cancel; thread-safe
  void pushBack() { std::lock_guard<std::mutex> l(m_); back_ = true; }
  void beginFrame(float dt);
  void endFrame();
  void releaseAll();
  Pointer p[kMax];
  bool backPressed = false;
  Pointer* byId(int id) { for (auto& q : p) if (q.id == id && (q.down || q.released)) return &q; return nullptr; }
  Pointer* freePointer() { for (auto& q : p) if ((q.down || q.released) && !q.claimed) return &q; return nullptr; }
  bool anyDown() const { for (auto& q : p) if (q.down) return true; return false; }
 private:
  struct Ev { int type, id; float x, y; };
  std::mutex m_;
  std::vector<Ev> q_;
  bool back_ = false;
};
}  // namespace cf
