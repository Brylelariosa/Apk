#pragma once
#include "engine/types.h"
namespace cf {
class Camera {
 public:
  Vec2 pos;                // centre of view in world pixels
  float shakeAmp = 0, shakeT = 0;
  void snap(Vec2 p) { pos = p; }
  void shake(float amp) { shakeAmp = std::max(shakeAmp, amp); }
  // follow target with smoothing; clamps so that invalid map areas are never shown
  void update(float dt, Vec2 target, float mapW, float mapH, float viewW, float viewH, bool smooth);
  Vec2 topLeft(float viewW, float viewH, float mapW, float mapH) const;   // integer-snapped, includes shake
 private:
  Vec2 shakeOff_;
  static float clampAxis(float c, float map, float view) { return map <= view ? map * 0.5f : clampv(c, view * 0.5f, map - view * 0.5f); }
};
}  // namespace cf
