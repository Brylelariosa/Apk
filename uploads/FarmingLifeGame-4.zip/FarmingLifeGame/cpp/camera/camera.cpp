#include "camera/camera.h"
namespace cf {
void Camera::update(float dt, Vec2 target, float mw, float mh, float vw, float vh, bool smooth) {
  float k = smooth ? 1.f - std::exp(-dt * 8.f) : 1.f;
  pos.x += (target.x - pos.x) * k; pos.y += (target.y - pos.y) * k;
  pos.x = clampAxis(pos.x, mw, vw); pos.y = clampAxis(pos.y, mh, vh);
  if (shakeAmp > 0.05f) {
    shakeT += dt * 60.f;
    shakeOff_ = Vec2(std::sin(shakeT * 1.7f) * shakeAmp, std::cos(shakeT * 2.3f) * shakeAmp);
    shakeAmp *= std::exp(-dt * 7.f);
  } else { shakeAmp = 0; shakeOff_ = Vec2(); }
}
Vec2 Camera::topLeft(float vw, float vh, float mw, float mh) const {
  float cx = clampAxis(pos.x, mw, vw), cy = clampAxis(pos.y, mh, vh);
  return Vec2(std::floor(cx - vw * 0.5f + shakeOff_.x + 0.5f), std::floor(cy - vh * 0.5f + shakeOff_.y + 0.5f));
}
}  // namespace cf
