// Minimal GLES2 declarations used ONLY for host-side syntax checking of cpp/renderer/gl_backend.cpp.
// The real Android NDK headers are used for the APK build.
#pragma once
#include <stddef.h>
#include <stdint.h>
typedef unsigned int GLenum; typedef unsigned char GLboolean; typedef unsigned int GLbitfield;
typedef int GLint; typedef int GLsizei; typedef unsigned int GLuint; typedef float GLfloat; typedef char GLchar;
typedef unsigned char GLubyte; typedef ptrdiff_t GLsizeiptr; typedef ptrdiff_t GLintptr;
#define GL_FALSE 0
#define GL_TRUE 1
#define GL_TRIANGLES 4
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_BLEND 0x0BE2
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_ONE 1
#define GL_ZERO 0
#define GL_DST_COLOR 0x0306
#define GL_SCISSOR_TEST 0x0C11
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE0 0x84C0
#define GL_UNSIGNED_BYTE 0x1401
#define GL_UNSIGNED_SHORT 0x1403
#define GL_FLOAT 0x1406
#define GL_RGBA 0x1908
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_ARRAY_BUFFER 0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_STREAM_DRAW 0x88E0
#define GL_STATIC_DRAW 0x88E4
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_VERTEX_SHADER 0x8B31
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_FRAMEBUFFER 0x8D40
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_UNPACK_ALIGNMENT 0x0CF5
#define GL_VERSION 0x1F02
#define GL_RENDERER 0x1F01
#define GL_MAX_TEXTURE_SIZE 0x0D33
#define GL_NO_ERROR 0
#define GL_DEPTH_TEST 0x0B71
#define GL_CULL_FACE 0x0B44
#ifdef __cplusplus
extern "C" {
#endif
void glActiveTexture(GLenum); void glAttachShader(GLuint, GLuint); void glBindAttribLocation(GLuint, GLuint, const GLchar*);
void glBindBuffer(GLenum, GLuint); void glBindFramebuffer(GLenum, GLuint); void glBindTexture(GLenum, GLuint);
void glBlendFunc(GLenum, GLenum); void glBufferData(GLenum, GLsizeiptr, const void*, GLenum);
GLenum glCheckFramebufferStatus(GLenum); void glClear(GLbitfield); void glClearColor(GLfloat, GLfloat, GLfloat, GLfloat);
void glCompileShader(GLuint); GLuint glCreateProgram(void); GLuint glCreateShader(GLenum);
void glDeleteBuffers(GLsizei, const GLuint*); void glDeleteFramebuffers(GLsizei, const GLuint*); void glDeleteProgram(GLuint);
void glDeleteShader(GLuint); void glDeleteTextures(GLsizei, const GLuint*); void glDisable(GLenum);
void glDrawElements(GLenum, GLsizei, GLenum, const void*); void glEnable(GLenum); void glEnableVertexAttribArray(GLuint);
void glFramebufferTexture2D(GLenum, GLenum, GLenum, GLuint, GLint); void glGenBuffers(GLsizei, GLuint*);
void glGenFramebuffers(GLsizei, GLuint*); void glGenTextures(GLsizei, GLuint*); GLenum glGetError(void);
void glGetProgramiv(GLuint, GLenum, GLint*); void glGetShaderInfoLog(GLuint, GLsizei, GLsizei*, GLchar*);
void glGetShaderiv(GLuint, GLenum, GLint*); const GLubyte* glGetString(GLenum); GLint glGetUniformLocation(GLuint, const GLchar*);
void glGetIntegerv(GLenum, GLint*);
void glLinkProgram(GLuint); void glPixelStorei(GLenum, GLint); void glScissor(GLint, GLint, GLsizei, GLsizei);
void glShaderSource(GLuint, GLsizei, const GLchar* const*, const GLint*); void glTexImage2D(GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void*);
void glTexParameteri(GLenum, GLenum, GLint); void glUniform1f(GLint, GLfloat); void glUniform1i(GLint, GLint);
void glUniform2f(GLint, GLfloat, GLfloat); void glUseProgram(GLuint);
void glVertexAttribPointer(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*); void glViewport(GLint, GLint, GLsizei, GLsizei);
void glGetProgramInfoLog(GLuint, GLsizei, GLsizei*, GLchar*);
#ifdef __cplusplus
}
#endif
