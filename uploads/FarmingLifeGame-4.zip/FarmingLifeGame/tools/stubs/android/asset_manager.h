#pragma once
#include <sys/types.h>
#include <stddef.h>
struct AAssetManager; struct AAsset;
enum { AASSET_MODE_BUFFER = 3 };
#ifdef __cplusplus
extern "C" {
#endif
AAsset* AAssetManager_open(AAssetManager*, const char*, int); off_t AAsset_getLength(AAsset*); int AAsset_read(AAsset*, void*, size_t); void AAsset_close(AAsset*);
#ifdef __cplusplus
}
#endif
