// host-side syntax-check stub (real header comes from the NDK)
#pragma once
typedef void* EGLDisplay; typedef unsigned int EGLBoolean;
#ifdef __cplusplus
extern "C" {
#endif
EGLDisplay eglGetCurrentDisplay(void); EGLBoolean eglSwapInterval(EGLDisplay, int);
#ifdef __cplusplus
}
#endif
