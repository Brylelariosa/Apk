// minimal JNI declarations for host-side syntax checking only
#pragma once
#include <stdint.h>
typedef int32_t jint; typedef float jfloat; typedef unsigned char jboolean; typedef int16_t jshort;
class _jobject {}; typedef _jobject* jobject; typedef _jobject* jclass; typedef _jobject* jstring; typedef _jobject* jshortArray;
#define JNI_TRUE 1
#define JNI_FALSE 0
#define JNIEXPORT __attribute__((visibility("default")))
#define JNICALL
struct JNIEnv {
  const char* GetStringUTFChars(jstring, jboolean*); void ReleaseStringUTFChars(jstring, const char*);
  jshort* GetShortArrayElements(jshortArray, jboolean*); void ReleaseShortArrayElements(jshortArray, jshort*, jint);
};
