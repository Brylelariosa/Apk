#pragma once
#include <chrono>
#include <cstdio>
#include "platform/platform.h"
namespace cf {
class HostPlatform : public Platform {
 public:
  HostPlatform(std::string assets, std::string data) : assets_(std::move(assets)), data_(std::move(data)) {}
  bool readAsset(const std::string& path, std::vector<u8>& out) override {
    FILE* f = fopen((assets_ + "/" + path).c_str(), "rb"); if (!f) return false;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); out.resize((size_t)n);
    bool ok = fread(out.data(), 1, out.size(), f) == out.size(); fclose(f); return ok;
  }
  std::string dataDir() override { return data_; }
  void log(int level, const char* msg) override { if (verbose || level >= 1) fprintf(stderr, "[%s] %s\n", level == 0 ? "I" : level == 1 ? "W" : "E", msg); }
  double nowSeconds() override { return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count(); }
  size_t memoryUsageKB() override { FILE* f = fopen("/proc/self/statm", "r"); long a = 0, b = 0; if (f) { if (fscanf(f, "%ld %ld", &a, &b) != 2) b = 0; fclose(f); } return (size_t)b * 4; }
  bool verbose = false;
 private:
  std::string assets_, data_;
};
}  // namespace cf
