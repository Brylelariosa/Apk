// CPU rasteriser implementing cf::Backend: lets the full renderer/UI run headless on a PC for tests and screenshots.
#pragma once
#include <string>
#include <vector>
#include "renderer/backend.h"
namespace cf {
class SoftwareBackend : public Backend {
 public:
  const char* name() const override { return "software"; }
  bool init() override { if (tex_.empty()) tex_.emplace_back(); return true; }
  TexHandle createTexture(int w, int h, const u8* rgba, bool linear) override;
  TexHandle createTarget(int w, int h, bool linear) override;
  void destroyTexture(TexHandle t) override { if (t && t < tex_.size()) { tex_[t].px.clear(); tex_[t].px.shrink_to_fit(); } }
  void bindTarget(TexHandle t, int w, int h) override;
  void clear(float r, float g, float b, float a) override;
  void draw(TexHandle tex, BlendMode bm, const Vertex* q, int n) override;
  void setScissor(bool on, int x, int y, int w, int h) override { sc_ = on; sx_ = x; sy_ = y; sw_ = w; sh_ = h; }
  bool savePpm(const std::string& path) const;
  const std::vector<u8>& screenPixels() const { return screen_; }
  int screenW = 0, screenH = 0;
  bool allowTargets = true;
 private:
  struct Tex { int w = 0, h = 0; bool linear = false; std::vector<u8> px; };
  std::vector<Tex> tex_;
  std::vector<u8> screen_;
  int cur_ = 0, curW_ = 0, curH_ = 0; bool sc_ = false; int sx_ = 0, sy_ = 0, sw_ = 0, sh_ = 0;
  u8* target(int& w, int& h);
};
}  // namespace cf
