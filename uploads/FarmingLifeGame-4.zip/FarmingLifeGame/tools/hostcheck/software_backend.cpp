#include "software_backend.h"
#include <cmath>
#include <cstdio>

namespace cf {
TexHandle SoftwareBackend::createTexture(int w, int h, const u8* rgba, bool linear) {
  if (tex_.empty()) tex_.emplace_back();
  Tex t; t.w = w; t.h = h; t.linear = linear; t.px.assign(rgba, rgba + (size_t)w * h * 4);
  tex_.push_back(std::move(t)); return (TexHandle)(tex_.size() - 1);
}
TexHandle SoftwareBackend::createTarget(int w, int h, bool linear) {
  if (!allowTargets) return 0;
  if (tex_.empty()) tex_.emplace_back();
  Tex t; t.w = w; t.h = h; t.linear = linear; t.px.assign((size_t)w * h * 4, 0);
  tex_.push_back(std::move(t)); return (TexHandle)(tex_.size() - 1);
}
void SoftwareBackend::bindTarget(TexHandle t, int w, int h) {
  cur_ = (int)t; curW_ = w; curH_ = h;
  if (t == 0 && (screenW != w || screenH != h)) { screenW = w; screenH = h; screen_.assign((size_t)w * h * 4, 0); }
}
u8* SoftwareBackend::target(int& w, int& h) {
  if (cur_ == 0) { w = screenW; h = screenH; return screen_.data(); }
  Tex& t = tex_[(size_t)cur_]; w = t.w; h = t.h; return t.px.data();
}
void SoftwareBackend::clear(float r, float g, float b, float a) {
  int w, h; u8* p = target(w, h); if (!p) return;
  u8 c[4] = {(u8)(r * 255), (u8)(g * 255), (u8)(b * 255), (u8)(a * 255)};
  for (size_t i = 0, n = (size_t)w * h; i < n; ++i) memcpy(p + i * 4, c, 4);
}
void SoftwareBackend::draw(TexHandle th, BlendMode bm, const Vertex* q, int n) {
  int W, H; u8* dst = target(W, H); if (!dst || th >= tex_.size()) return;
  const Tex& tx = tex_[th];
  for (int i = 0; i < n; ++i) {
    const Vertex* v = q + i * 4;
    float x0 = v[0].x, y0 = v[0].y, x1 = v[2].x, y1 = v[2].y;
    float u0 = v[0].u, vv0 = v[0].v, u1 = v[2].u, vv1 = v[2].v;
    if (x1 <= x0 || y1 <= y0) continue;
    int ix0 = (int)std::ceil(x0 - 0.5f), ix1 = (int)std::ceil(x1 - 0.5f), iy0 = (int)std::ceil(y0 - 0.5f), iy1 = (int)std::ceil(y1 - 0.5f);
    int minx = 0, miny = 0, maxx = W, maxy = H;
    if (sc_) { minx = std::max(minx, sx_); miny = std::max(miny, sy_); maxx = std::min(maxx, sx_ + sw_); maxy = std::min(maxy, sy_ + sh_); }
    ix0 = std::max(ix0, minx); iy0 = std::max(iy0, miny); ix1 = std::min(ix1, maxx); iy1 = std::min(iy1, maxy);
    u32 c = v[0].color; float cr = (c & 255) / 255.f, cg = ((c >> 8) & 255) / 255.f, cb = ((c >> 16) & 255) / 255.f, ca = ((c >> 24) & 255) / 255.f;
    for (int y = iy0; y < iy1; ++y) {
      float fy = (y + 0.5f - y0) / (y1 - y0), vv = vv0 + (vv1 - vv0) * fy;
      for (int x = ix0; x < ix1; ++x) {
        float fx = (x + 0.5f - x0) / (x1 - x0), u = u0 + (u1 - u0) * fx;
        float sr, sg, sb, sa;
        if (!tx.linear) {
          int tx_ = clampv((int)std::floor(u * tx.w), 0, tx.w - 1), ty_ = clampv((int)std::floor(vv * tx.h), 0, tx.h - 1);
          const u8* p = &tx.px[((size_t)ty_ * tx.w + tx_) * 4]; sr = p[0] / 255.f; sg = p[1] / 255.f; sb = p[2] / 255.f; sa = p[3] / 255.f;
        } else {
          float gx = u * tx.w - 0.5f, gy = vv * tx.h - 0.5f; int x_0 = (int)std::floor(gx), y_0 = (int)std::floor(gy); float fx2 = gx - x_0, fy2 = gy - y_0;
          float acc[4] = {0, 0, 0, 0};
          for (int dy = 0; dy < 2; ++dy) for (int dx = 0; dx < 2; ++dx) {
            int px_ = clampv(x_0 + dx, 0, tx.w - 1), py_ = clampv(y_0 + dy, 0, tx.h - 1); float wgt = (dx ? fx2 : 1 - fx2) * (dy ? fy2 : 1 - fy2);
            const u8* p = &tx.px[((size_t)py_ * tx.w + px_) * 4]; for (int k = 0; k < 4; ++k) acc[k] += wgt * p[k] / 255.f;
          }
          sr = acc[0]; sg = acc[1]; sb = acc[2]; sa = acc[3];
        }
        sr *= cr; sg *= cg; sb *= cb; sa *= ca;
        u8* d = &dst[((size_t)y * W + x) * 4];
        float dr = d[0] / 255.f, dg = d[1] / 255.f, db = d[2] / 255.f, da = d[3] / 255.f, rr, rg, rb, ra;
        switch (bm) {
          case BlendMode::None: rr = sr; rg = sg; rb = sb; ra = 1; break;
          case BlendMode::Alpha: rr = sr * sa + dr * (1 - sa); rg = sg * sa + dg * (1 - sa); rb = sb * sa + db * (1 - sa); ra = sa + da * (1 - sa); break;
          case BlendMode::Add: rr = dr + sr * sa; rg = dg + sg * sa; rb = db + sb * sa; ra = da; break;
          default: rr = dr * sr; rg = dg * sg; rb = db * sb; ra = da; break;
        }
        d[0] = (u8)clampv((int)(rr * 255.f + 0.5f), 0, 255); d[1] = (u8)clampv((int)(rg * 255.f + 0.5f), 0, 255); d[2] = (u8)clampv((int)(rb * 255.f + 0.5f), 0, 255); d[3] = (u8)clampv((int)(ra * 255.f + 0.5f), 0, 255);
      }
    }
  }
}
bool SoftwareBackend::savePpm(const std::string& path) const {
  FILE* f = fopen(path.c_str(), "wb"); if (!f) return false;
  fprintf(f, "P6\n%d %d\n255\n", screenW, screenH);
  for (size_t i = 0, n = (size_t)screenW * screenH; i < n; ++i) fwrite(&screen_[i * 4], 1, 3, f);
  fclose(f); return true;
}
}  // namespace cf
