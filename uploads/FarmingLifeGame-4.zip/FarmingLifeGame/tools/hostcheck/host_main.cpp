// Headless smoke/regression test + screenshot generator for Thistledown Vale (runs the real game code with a software renderer).
#include <cstdio>
#include <cstdlib>
#include <memory>
#include "animation/animation.h"
#include "engine/app.h"
#include "engine/log.h"
#include "host_platform.h"
#include "save/save.h"
#include "software_backend.h"

using namespace cf;
static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { ++g_fail; fprintf(stderr, "  FAIL: "); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } } while (0)

static SoftwareBackend* g_sw = nullptr;
static Application* g_app = nullptr;
static std::string g_shots;

static void step(float seconds) { int n = (int)(seconds * 60); for (int i = 0; i < n; ++i) g_app->game.fixedUpdate(1.f / 60.f); }
static void setSafe() { float m = 8.f * 2.6f; g_app->game.safe = Rect(m, m * 0.6f, 1600 - 2 * m, 720 - m * 1.2f); }
static void render(const char* name = nullptr, int frames = 2) {
  setSafe();
  for (int i = 0; i < frames; ++i) { g_app->input.beginFrame(1.f / 60.f); g_app->game.frame(1.f / 60.f); g_app->input.endFrame(); }
  if (name && !g_shots.empty()) g_sw->savePpm(g_shots + "/" + name + ".ppm");
}
static void tap(float x, float y) { setSafe(); g_app->touch(0, 1, x, y); render(nullptr, 1); g_app->touch(2, 1, x, y); render(nullptr, 1); }
static int slotOf(Game& g, const char* id) { for (int i = 0; i < Inventory::kSlots; ++i) if (g.s.pl.inv.slots[(size_t)i].id == C().item(id)) return i; return -1; }
static void placeAt(Game& g, int tx, int ty, Dir d) { g.s.pl.pos = g.tileCenter(tx, ty); g.s.pl.facing = d; g.cam.snap(g.s.pl.pos); }
static void doAction(Game& g) { ActionInfo a = g.resolveAction(); g.startAction(a); step(1.2f); }
static bool reachable(Map& m, IVec2 a, IVec2 b) {   // terrain connectivity (rocks and ore can be mined through)
  std::vector<char> seen((size_t)m.w * m.h, 0); std::vector<IVec2> q{a}; seen[(size_t)a.y * m.w + a.x] = 1;
  for (size_t i = 0; i < q.size(); ++i) { static const int dx[4] = {1, -1, 0, 0}, dy[4] = {0, 0, 1, -1};
    for (int d = 0; d < 4; ++d) { int x = q[i].x + dx[d], y = q[i].y + dy[d]; if (!m.inBounds(x, y) || seen[(size_t)y * m.w + x] || m.terrain(x, y) != Terrain::Cave) continue; seen[(size_t)y * m.w + x] = 1; q.push_back(IVec2(x, y)); } }
  return seen[(size_t)b.y * m.w + b.x] != 0;
}

int main(int argc, char** argv) {
  std::string assets = argc > 1 ? argv[1] : "assets", shots = argc > 2 ? argv[2] : "";
  g_shots = shots;
  HostPlatform plat(assets, "/tmp/cf_test_data");
  std::system("mkdir -p /tmp/cf_test_data && rm -f /tmp/cf_test_data/save1.* /tmp/cf_test_data/settings.cfg");
  auto sw = std::unique_ptr<SoftwareBackend>(new SoftwareBackend()); g_sw = sw.get();
  Application app; g_app = &app;
  const int W = 1600, H = 720; float density = argc > 3 ? (float)atof(argv[3]) : 2.0f;
  printf("== boot\n");
  CHECK(app.init(std::move(sw), &plat, W, H, density, 60.f, true), "app init");
  CHECK(app.onSurfaceCreated(), "surface");
  app.onSurfaceChanged(W, H);
  Game& g = app.game;
  g.settings.debugOverlay = false;
  CHECK(logWarnCount() == 0, "warnings while loading content/atlases: %d", logWarnCount());
  render("01_main_menu", 3);

  printf("== new game + first day\n");
  g.newGame("Tester", 0);
  g.stack.clear(); g.stack.push_back(St::Gameplay);
  render("02_farm_morning", 3);
  CHECK(g.s.curMap == "farm", "starts on the farm");
  CHECK(g.s.pl.inv.count(C().item("seed_turnip")) == 12, "starting seeds");
  CHECK(g.s.cal.minutes == 360 && g.s.cal.day == 1, "calendar start");
  for (int look = 0; look < 2; ++look) {
    const CharAnim& pa = playerAnim(look);
    CHECK(pa.idle2[0] && pa.idle2[1] && pa.idle2[2], "player look %d has breathing idle frames", look);
    CHECK(pa.happy && pa.eat[0] && pa.talk[1] && pa.pick[2][1] && pa.swing[1][2], "player look %d has its action frames", look);
  }

  printf("== farming loop\n");
  Map& farm = g.map();
  placeAt(g, 12, 14, Dir::Down);
  g.s.pl.sel = slotOf(g, "hoe"); CHECK(g.resolveAction().act == Act::Till, "hoe on grass -> till (got %d)", (int)g.resolveAction().act);
  doAction(g);
  CHECK(farm.at(12, 15).flags & TF_Tilled, "tile tilled");
  g.s.pl.sel = slotOf(g, "seed_turnip");
  CHECK(g.resolveAction().act == Act::Plant, "seeds on tilled soil -> plant");
  doAction(g);
  int oi = farm.objectAt(12, 15);
  CHECK(oi >= 0 && farm.objs[(size_t)oi].kind == ObjKind::Crop, "crop planted");
  CHECK(g.resolveAction().act == Act::Water, "crop needs water -> water action (got %d)", (int)g.resolveAction().act);
  doAction(g);
  CHECK(farm.at(12, 15).flags & TF_Watered, "tile watered");
  render("03_crop_planted", 3);
  int stages[6] = {0};
  for (int day = 0; day < 5; ++day) {
    g.s.wx.today = Weather::Sunny;
    oi = farm.objectAt(12, 15);
    if (oi >= 0) { stages[day] = farm.objs[(size_t)oi].state; if (!(farm.at(12, 15).flags & TF_Watered)) { g.s.pl.sel = slotOf(g, "seed_turnip"); doAction(g); } }
    g.newDay(false); g.setRoot(St::Gameplay); g.enterMap("farm", "spawn", false); placeAt(g, 12, 14, Dir::Down);
    g.s.wx.today = Weather::Sunny;
    farm.at(12, 15).flags |= TF_Watered;
  }
  printf("   crop stages over days: %d %d %d %d %d\n", stages[0], stages[1], stages[2], stages[3], stages[4]);
  oi = farm.objectAt(12, 15);
  CHECK(oi >= 0 && farm.objs[(size_t)oi].state == 5, "turnip harvestable after 4+ watered days (state %d)", oi >= 0 ? farm.objs[(size_t)oi].state : -1);
  g.enterMap("farm", "spawn", false); placeAt(g, 12, 14, Dir::Down); g.s.pl.sel = slotOf(g, "seed_turnip");
  render("04_crop_ready", 3);
  int before = g.s.pl.inv.count(C().item("turnip"));
  CHECK(g.resolveAction().act == Act::Harvest, "ripe crop -> harvest");
  doAction(g);
  CHECK(g.s.pl.inv.count(C().item("turnip")) > before, "turnips harvested");
  // ship them, sleep, get paid
  int money = g.s.pl.money; ItemStack st; st.id = (u16)C().item("turnip"); st.count = (u16)g.s.pl.inv.count(st.id); g.s.pl.inv.remove(st.id, st.count); g.s.bin.push_back(st);
  g.newDay(false); g.setRoot(St::Gameplay);
  CHECK(g.s.curMap == "house", "wakes up in the farmhouse");
  CHECK(g.s.pl.money > money, "shipping bin paid out (%d -> %d)", money, g.s.pl.money);
  render("05_house_morning", 3);

  printf("== farmhouse upgrade stages (exterior + interior art, level 2 and 3)\n");
  for (int lv = 2; lv <= 3; ++lv) {
    Map* fm = g.getMap("farm");
    int hb = -1; for (size_t i = 0; i < fm->buildings.size(); ++i) if (C().buildings[(size_t)fm->buildings[i].def].id == "farmhouse") hb = (int)i;
    CHECK(hb >= 0, "farm has a farmhouse building");
    if (hb < 0) break;
    fm->buildings[(size_t)hb].level = lv; g.s.farmhouseLevel = lv; g.s.maps.erase("house");
    CHECK(C().buildings[(size_t)fm->buildings[(size_t)hb].def].spr[lv - 1] != nullptr, "farmhouse level %d sprite loaded", lv);
    g.enterMap("farm", "spawn", false); placeAt(g, fm->buildings[(size_t)hb].x + 2, fm->buildings[(size_t)hb].y + 1, Dir::Up);
    render(lv == 2 ? "05b_farmhouse_lv2" : "05d_farmhouse_lv3", 3);
    g.enterMap("house", "spawn", false);
    CHECK(g.map().id == "house" && g.map().w == 12 + 2 * (lv - 1), "level %d interior loads (%dx%d)", lv, g.map().w, g.map().h);
    render(lv == 2 ? "05c_house_lv2" : "05e_house_lv3", 3);
  }
  g.s.farmhouseLevel = 1; g.s.maps.erase("house");
  if (Map* fm = g.getMap("farm")) for (auto& bi : fm->buildings) if (C().buildings[(size_t)bi.def].id == "farmhouse") bi.level = 1;

  printf("== chop / mine / forage / clear\n");
  g.enterMap("farm", "spawn", false);
  g.map().objs.size();
  int ti = -1; for (size_t i = 0; i < farm.objs.size(); ++i) if (farm.objs[i].kind == ObjKind::Tree) { ti = (int)i; break; }
  CHECK(ti >= 0, "farm has trees");
  if (ti >= 0) { MapObject& t = farm.objs[(size_t)ti]; placeAt(g, t.x, t.y + 1, Dir::Up); g.s.pl.sel = slotOf(g, "axe"); CHECK(g.resolveAction().act == Act::Chop, "tree -> chop"); int w0 = g.s.pl.inv.count(C().item("wood")); for (int k = 0; k < 14 && farm.objectAt(t.x, t.y) >= 0 && farm.objs[(size_t)farm.objectAt(t.x, t.y)].kind == ObjKind::Tree; ++k) { g.s.pl.energy = 100; doAction(g); } CHECK(g.s.pl.inv.count(C().item("wood")) > w0, "wood gained from tree"); }

  printf("== save / load round trip\n");
  g.s.pl.money = 1234; g.s.cal.day = 9; g.setFlag("test_flag");
  CHECK(g.saveGame(true), "save written"); CHECK(g.saveGame(true), "second save (creates backup)");
  int d0 = g.s.cal.day, m0 = g.s.pl.money, tiles0 = 0; for (auto& t : farm.tiles) if (t.flags & TF_Tilled) ++tiles0;
  g.newGame("Other", 1); g.setRoot(St::Gameplay);
  CHECK(g.continueGame(), "continue loads the save");
  CHECK(g.s.cal.day == d0 && g.s.pl.money == m0 && g.flag("test_flag") && g.s.pl.name == "Tester", "state restored (day %d money %d)", g.s.cal.day, g.s.pl.money);
  int tiles1 = 0; for (auto& t : g.getMap("farm")->tiles) if (t.flags & TF_Tilled) ++tiles1;
  CHECK(tiles0 == tiles1, "tilled tiles restored (%d vs %d)", tiles0, tiles1);
  { std::vector<u8> bytes; readSaveFile("/tmp/cf_test_data", "save1", bytes); bytes[bytes.size() / 2] ^= 0xFF; FILE* f = fopen("/tmp/cf_test_data/save1.dat", "wb"); fwrite(bytes.data(), 1, bytes.size(), f); fclose(f); }
  CHECK(g.continueGame(), "corrupt primary save falls back to the backup"); resetLogCounters();

  printf("== touch controls\n");
  { g.enterMap("farm", "spawn", false); g.s.pl.sel = slotOf(g, "seed_turnip"); g.setRoot(St::Gameplay); step(0.2f);
    float sx = 16.f * 2.f * 0.0f, jx = 0.f; (void)sx; (void)jx;
    setSafe(); Rect sf = g.safe; float joyX = sf.x + 0.12f * sf.w, joyY = sf.y + 0.74f * sf.h;
    placeAt(g, 20, 12, Dir::Down); Vec2 p0 = g.s.pl.pos;
    g.in->pushEvent(0, 7, joyX, joyY); render(nullptr, 1); g.in->pushEvent(1, 7, joyX + 60, joyY); render(nullptr, 1);
    for (int i = 0; i < 30; ++i) { g.in->pushEvent(1, 7, joyX + 60, joyY); render(nullptr, 1); g.fixedUpdate(1.f / 60.f); g.fixedUpdate(1.f / 60.f); }
    CHECK(g.s.pl.pos.x > p0.x + 8.f, "virtual joystick moves the player (dx=%.1f)", g.s.pl.pos.x - p0.x);
    CHECK(g.s.pl.facing == Dir::Right, "joystick sets facing");
    g.in->pushEvent(2, 7, joyX + 60, joyY); render(nullptr, 2);
    CHECK(std::fabs(g.moveStick[0]) < 0.01f, "joystick released");
    float ax = sf.x + 0.90f * sf.w, ay = sf.y + 0.72f * sf.h;
    { int blocker = g.map().objectAt(20, 13); if (blocker >= 0) g.map().removeObject(blocker); }   // the world seed is time based: keep the target tile free
    placeAt(g, 20, 12, Dir::Down); g.s.pl.sel = slotOf(g, "hoe");
    g.in->pushEvent(0, 8, ax, ay); render(nullptr, 1); for (int i = 0; i < 90; ++i) g.fixedUpdate(1.f / 60.f); g.in->pushEvent(2, 8, ax, ay); render(nullptr, 2);
    CHECK(g.map().at(20, 13).flags & TF_Tilled, "action button tills the tile in front");
    // quick-bar: tap item box, pick slot 0
    float ix = sf.x + 0.93f * sf.w, iy = sf.y + 0.14f * sf.h; tap(ix, iy); CHECK(g.hotbarOpen, "item box opens the quick bar"); render("02b_hotbar", 2);
    g.hotbarOpen = false; }
  printf("== lifecycle\n");
  { g.onPause(); g.onResume(); for (int i = 0; i < 5; ++i) g_app->frame(); CHECK(true, "pause/resume/frame ok"); }

  printf("== village, npcs, weather, lighting\n");
  g.enterMap("village", "from_farm", false);
  g.s.cal.minutes = 12 * 60 + 10; g.s.cal.day = 3; g.s.wx.today = Weather::Sunny; g.npcMinute(); step(4); g.s.cal.minutes = 12 * 60 + 40; g.npcMinute(); step(30);
  int placed = 0; for (auto& n : g.s.npcs) if (g.npcIsPlaced(n)) ++placed;
  printf("   npcs visible in village at noon: %d\n", placed); CHECK(placed >= 2, "villagers walk around the village at noon");
  placeAt(g, 20, 19, Dir::Right); g.cam.snap(g.s.pl.pos);
  render("06_village_noon", 4);
  g.s.cal.minutes = 20 * 60 + 20; g.s.wx.today = Weather::Sunny; step(1); render("07_village_night", 3);
  g.s.cal.minutes = 14 * 60; g.s.wx.today = Weather::Rain; g.s.wx.intensity = 1; step(3); render("08_village_rain", 3);
  g.s.cal.season = 3; g.s.cal.minutes = 11 * 60; g.s.wx.today = Weather::Snow; for (auto& kv : g.s.maps) g.populateMap(*kv.second); step(4); render("09_village_winter_snow", 3);
  g.s.cal.season = 2; g.s.wx.today = Weather::Sunny; step(0.5f); render("10_village_autumn", 3);
  g.s.cal.season = 0; g.s.wx.today = Weather::Sunny; g.s.cal.minutes = 9 * 60; step(0.5f);

  printf("== dialogue, shop, menu screens\n");
  g.s.cal.day = 2;  // a Wednesday-ish day: shops open
  for (auto& n : g.s.npcs) if (C().npcs[(size_t)n.def].id == "pippa") { n.map = "village"; n.inside = false; n.act = "shop"; n.pos = g.tileCenter(10, 15); }
  g.s.cal.minutes = 10 * 60; placeAt(g, 10, 16, Dir::Up); g.cam.snap(g.s.pl.pos);
  ActionInfo ta = g.resolveAction(); CHECK(ta.act == Act::Talk, "facing Pippa -> talk (got %d)", (int)ta.act);
  g.startAction(ta); render(nullptr, 40); render("11_dialogue_pippa", 2);
  CHECK(g.top() == St::Dialogue, "dialogue open");
  g.dialogueChoice(1); render("12_shop_buy", 3);
  CHECK(g.top() == St::Shop, "shop open");
  g.shopUi.sel = 0; g.shopUi.qty = 3; render("13_shop_detail", 3); g.setRoot(St::Gameplay);
  g.menu = Game::MenuUI(); g.push(St::Menu); g.menu.sel = 0; render("14_menu_inventory", 3);
  g.menu.tab = 1; g.menu.recipe = 0; render("15_menu_craft", 3);
  g.menu.tab = 2; render("16_menu_quests", 3);
  g.menu.tab = 3; render("17_menu_friends", 3);
  g.menu.tab = 4; render("18_menu_collection", 3);
  g.menu.tab = 5; render("19_menu_skills", 3);
  g.setRoot(St::Gameplay); g.push(St::Pause); render("20_pause", 3);
  g.setRoot(St::Gameplay); g.settingsBack = St::Pause; g.settingsTab = 0; g.push(St::Settings); render("21_settings", 3);
  g.settingsTab = 2; render("22_settings_access", 3); g.setRoot(St::Gameplay);
  g.push(St::CustomizeHud); render("23_customize_hud", 3); g.setRoot(St::Gameplay);

  printf("== fishing\n");
  g.enterMap("shore", "from_village", false); g.s.cal.minutes = 9 * 60; g.s.wx.today = Weather::Sunny;
  { Map& sh = g.map(); IVec2 w(-1, -1); for (int y = 8; y < 20 && w.x < 0; ++y) for (int x = 6; x < 24; ++x) if (terrainWater(sh.terrain(x, y)) && sh.walkableTile(x + 1, y)) { w = IVec2(x, y); break; }
    CHECK(w.x >= 0, "found lake shore tile"); placeAt(g, w.x + 1, w.y, Dir::Left);
    g.s.pl.sel = slotOf(g, "rod"); ActionInfo fa = g.resolveAction(); CHECK(fa.act == Act::Fish, "rod facing water -> fish (got %d)", (int)fa.act);
    g.startAction(fa); step(0.7f); CHECK(g.top() == St::Fishing, "fishing state");
    render("24_fishing_wait", 3);
    for (int i = 0; i < 600 && g.top() == St::Fishing && g.fg.phase < 2; ++i) g.fixedUpdate(1.f / 60.f);
    CHECK(g.fg.phase == 2, "bite happens"); render("25_fishing_bite", 2);
    g.actionPressed = true; g.fixedUpdate(1.f / 60.f); if (g.fg.phase == 3) { render("26_fishing_reel", 3); for (int i = 0; i < 1800 && g.top() == St::Fishing; ++i) { g.actionHeld = (i / 20) % 2 == 0; g.fixedUpdate(1.f / 60.f); } g.actionHeld = false; }
    g.setRoot(St::Gameplay); g.s.pl.animKind = 0; }
  render("27_shore", 3);

  printf("== mine\n");
  { bool allOk = true; int ladders = 0;
    for (int fl = 1; fl <= 20; ++fl) { g.s.maps.erase(fmt("mine_%d", fl)); Map* m = g.getMap(fmt("mine_%d", fl)); if (!m) { allOk = false; break; }
      IVec2 st(-1, -1), ex(-1, -1); for (auto& o : m->objs) if (o.kind == ObjKind::Ladder) { if (o.state == 1) st = IVec2(o.x, o.y); else ex = IVec2(o.x, o.y); }
      if (ex.x < 0) { for (auto& o : m->objs) if (o.kind == ObjKind::Rock && o.aux == 1) ex = IVec2(o.x, o.y); }
      if (st.x < 0 || ex.x < 0 || !reachable(*m, st, ex)) { allOk = false; fprintf(stderr, "   floor %d: ladder unreachable (start %d,%d exit %d,%d)\n", fl, st.x, st.y, ex.x, ex.y); } else ++ladders; }
    CHECK(allOk, "all mine floors have a reachable ladder (%d/20)", ladders); }
  g.s.maps.erase("mine_1"); g.enterMap("mine_1", "start", false); render("28_mine_floor1", 4);
  g.s.maps.erase("mine_12"); g.enterMap("mine_12", "start", false); render("29_mine_floor12", 3);
  { Map& mm = g.map(); for (auto& o : mm.objs) if (o.kind == ObjKind::Ore || o.kind == ObjKind::Rock) { placeAt(g, o.x, o.y + 1, Dir::Up); break; } g.s.pl.sel = slotOf(g, "pick"); g.s.pl.energy = 100; ActionInfo ma = g.resolveAction(); printf("   mine action = %d\n", (int)ma.act); }

  printf("== animals + machines + festival + quests\n");
  g.enterMap("farm", "spawn", false); g.s.pl.money = 99999; g.s.cal.season = 0; g.s.cal.minutes = 10 * 60;
  CHECK(g.buyAnimal(C().animal("chicken"), 2), "buy chicken"); CHECK(g.buyAnimal(C().animal("cow"), 1), "buy cow"); CHECK(g.buyAnimal(C().animal("sheep"), 1), "buy sheep");
  for (auto& a : g.s.animals) { a.inside = false; a.age = 10; a.pos = g.tileCenter(33 + (int)(&a - &g.s.animals[0]), 14); a.dest = a.pos; }
  g.s.wx.today = Weather::Sunny; step(5); placeAt(g, 33, 16, Dir::Down); render("30_farm_animals", 3);
  for (int i = 0; i < 3; ++i) { g.newDay(false); g.setRoot(St::Gameplay); }
  int ready = 0; for (auto& a : g.s.animals) if (a.product) ++ready;
  CHECK(ready >= 2, "animals produced goods after a few days (%d ready)", ready);
  g.enterMap("farm", "spawn", false); for (auto& a : g.s.animals) { a.inside = false; a.pos = g.tileCenter(33, 14); }
  placeAt(g, 33, 15, Dir::Up); step(0.1f); ActionInfo aa = g.resolveAction(); printf("   animal action = %d\n", (int)aa.act);
  g.animalUi.building = 1; g.push(St::Animals); render("31_animals_ui", 3); g.setRoot(St::Gameplay);
  { ItemStack fur; fur.id = (u16)C().item("furnace"); fur.count = 1; g.giveItem(fur, false);
    ItemStack ore; ore.id = (u16)C().item("copper_ore"); ore.count = 10; g.giveItem(ore, false); ItemStack coal; coal.id = (u16)C().item("coal"); coal.count = 5; g.giveItem(coal, false);
    { Map& fm2 = g.map(); int o2 = fm2.objectAt(14, 21); if (o2 >= 0) fm2.removeObject(o2); fm2.at(14, 21).flags = 0; }
    placeAt(g, 14, 20, Dir::Down); g.s.pl.sel = slotOf(g, "furnace"); ActionInfo pa = g.resolveAction(); CHECK(pa.act == Act::Place, "placeable -> place (got %d)", (int)pa.act); doAction(g);
    int fi = g.map().objectAt(14, 21); CHECK(fi >= 0 && g.map().objs[(size_t)fi].kind == ObjKind::Machine, "furnace placed");
    if (fi >= 0) { g.s.pl.sel = slotOf(g, "copper_ore"); g.useMachine(g.map(), fi); CHECK(g.map().objs[(size_t)fi].state == 1, "furnace started"); g.tickMachines(200); CHECK(g.map().objs[(size_t)fi].state == 2, "furnace finished"); g.useMachine(g.map(), fi); CHECK(g.s.pl.inv.count(C().item("copper_bar")) >= 1, "copper bar produced"); } }
  g.s.cal.season = 0; g.s.cal.day = 13; g.s.cal.minutes = 11 * 60; g.enterMap("village", "from_farm", false); g.s.pl.pos = g.tileCenter(27, 21);
  for (auto& kv : g.s.maps) g.populateMap(*kv.second);
  g.npcMinute(); step(20); render("32_festival_day", 3);
  CHECK(g.todaysFestival() != nullptr, "festival on spring 13");
  g.festivalState = 0; g.startFestivalActivity(); step(1); render("33_festival_hunt", 3); g.festivalState = 0; g.festPickups.clear();
  int active = 0; for (auto& q : g.s.quests) if (!q.done) ++active; printf("   active quests: %d\n", active); CHECK(active >= 2, "starting quests are active");
  g.setFlag("lantern_restored");

  printf("== long simulation\n");
  g.newGame("Sim", 1); g.setRoot(St::Gameplay);
  for (int day = 0; day < 120; ++day) {
    Map& f = *g.getMap("farm");
    for (int k = 0; k < 6; ++k) { int x = 11 + k, y = 15; if (f.canTill(x, y)) g.tillTile(f, x, y);
      if ((f.at(x, y).flags & TF_Tilled) && f.objectAt(x, y) < 0) { int ci = C().crop(g.s.cal.season == 0 ? "turnip" : g.s.cal.season == 1 ? "tomato" : "pumpkin"); if (ci >= 0) g.plantSeed(f, x, y, ci, 0); }
      f.at(x, y).flags |= TF_Watered; }
    for (size_t i = 0; i < f.objs.size(); ++i) if (f.objs[i].kind == ObjKind::Crop && f.objs[i].state == 5) g.harvestCrop(f, (int)i);
    g.s.pl.energy = 100; g.s.cal.minutes = 20 * 60;
    g.newDay(day % 17 == 0); g.setRoot(St::Gameplay);
    if (day % 10 == 0) { g.npcMinute(); step(0.5f); g.saveGame(true); render(nullptr, 1); }
  }
  printf("   simulated %d days -> %s %d year %d, money %d, objects on farm %zu\n", 120, Calendar::seasonName(g.s.cal.season), g.s.cal.day, g.s.cal.year, g.s.pl.money, g.getMap("farm")->objs.size());
  CHECK(g.s.cal.year >= 2, "calendar rolled over into year 2");
  CHECK(g.continueGame(), "load after long simulation");

  printf("== performance probe\n");
  g.enterMap("village", "from_farm", false); g.s.cal.minutes = 12 * 60; g.s.wx.today = Weather::Rain; g.s.wx.intensity = 1; step(2);
  double t0 = plat.nowSeconds(); for (int i = 0; i < 600; ++i) g.fixedUpdate(1.f / 60.f); double t1 = plat.nowSeconds();
  printf("   fixedUpdate: %.3f ms/tick (village, rain, %zu npcs)\n", (t1 - t0) * 1000.0 / 600.0, g.s.npcs.size());
  render(nullptr, 5); printf("   draw calls %d, quads %d, visible sprites %d, particles %d\n", g.r->stats.drawCalls, g.r->stats.quads, g.r->stats.visibleSprites, g.fx.count());
  CHECK(logWarnCount() == 0, "warnings logged during the run: %d", logWarnCount());
  printf("\n%s (%d failures)\n", g_fail ? "FAILED" : "ALL CHECKS PASSED", g_fail);
  return g_fail;
}
