"""Interior furniture for the farmhouse (and the shared decor objects): bed, kitchen, table, chair, bookshelf, rug,
window, fireplace, plant, plus wall pictures and a bedside lamp table.

Every sprite keeps the size / anchor the previous art had, so objects.cfd footprints, maps and collision are
untouched.  Light comes from the top-left; sprites get the usual 1px selective outline at the end.
"""
import random
from .common import *

WHITE = (255, 255, 255, 255)

# wood ramp (highlight -> deep shade)
W_HI, W_LT, W_MD, W_DK, W_XD = hx('#e2b274'), hx('#c8924e'), hx('#a8703a'), hx('#7a5230'), hx('#573820')


def planks(cv, x0, y0, x1, y1, base=W_LT, seam=4):
    """Fill a rectangle with horizontal wood boards."""
    for i, y in enumerate(range(y0, y1 + 1)):
        k = (y - y0) % seam
        c = light(base, .16) if k == 0 else (dark(base, .22) if k == seam - 1 else base)
        cv.hline(x0, x1, y, c)


# ---------------------------------------------------------------- bed (32x40, anchor 16,39)
def bed():
    cv = Cv(32, 40)
    sheet, sheet_lo = hx('#f6eedb'), hx('#d8ccb2')
    quilt, quilt_hi, quilt_lo = hx('#4a78b0'), hx('#6c9bd0'), hx('#2f5a92')
    cv.rect(1, 9, 30, 38, W_DK)                                               # side rails
    cv.vline(1, 9, 38, W_MD); cv.vline(30, 9, 38, W_XD)
    cv.rect(4, 12, 27, 35, sheet)                                             # mattress
    cv.vline(27, 12, 35, sheet_lo)
    for x0 in (5, 17):                                                        # pillows
        cv.rect(x0, 13, x0 + 9, 19, WHITE)
        cv.hline(x0 + 1, x0 + 8, 20, hx('#cfcadf'))
        cv.vline(x0 + 9, 14, 19, hx('#e6e2f0')); cv.hline(x0, x0 + 9, 19, hx('#dcd8ea'))
        for (cx, cy) in ((x0, 13), (x0 + 9, 13)): cv.px(cx, cy, sheet)
        cv.px(x0 + 4, 15, hx('#e6e2f0')); cv.px(x0 + 5, 16, hx('#e6e2f0')); cv.px(x0 + 4, 17, hx('#e6e2f0'))
    cv.rect(4, 21, 27, 23, sheet); cv.hline(4, 27, 23, sheet_lo)               # folded-back sheet
    cv.hline(4, 27, 21, hx('#ffffff'))
    cv.rect(4, 24, 27, 35, quilt)                                             # quilt
    for y in range(24, 35):
        for x in range(4, 28):
            if (x + y) % 6 == 0 or (x - y) % 6 == 0:
                cv.px(x, y, quilt_hi)
    cv.vline(4, 24, 35, quilt_lo); cv.vline(27, 24, 35, quilt_lo); cv.hline(4, 27, 24, quilt_lo)
    cv.hline(4, 27, 34, quilt_lo)
    cv.rect(1, 1, 30, 10, W_MD)                                               # headboard
    cv.hline(1, 30, 1, W_HI); cv.hline(1, 30, 2, W_LT); cv.hline(1, 30, 10, W_DK)
    cv.rect(5, 4, 26, 9, W_LT)
    cv.hline(5, 26, 4, W_DK); cv.vline(5, 4, 9, W_DK); cv.hline(5, 26, 9, W_HI)
    for x in (11, 16, 21): cv.vline(x, 5, 8, W_MD)
    for x0 in (1, 27):                                                        # posts
        cv.rect(x0, 0, x0 + 3, 4, W_HI); cv.rect(x0, 5, x0 + 3, 10, W_LT)
        cv.hline(x0, x0 + 3, 4, W_MD); cv.px(x0, 0, W_MD); cv.px(x0 + 3, 0, W_MD)
    cv.rect(1, 31, 30, 38, W_MD)                                              # footboard
    cv.hline(1, 30, 31, W_HI); cv.hline(1, 30, 32, W_LT); cv.hline(1, 30, 38, W_XD)
    cv.rect(6, 34, 25, 36, W_LT); cv.hline(6, 25, 34, W_DK); cv.hline(6, 25, 36, W_HI)
    for x0 in (1, 27):
        cv.rect(x0, 29, x0 + 3, 38, W_LT); cv.rect(x0, 29, x0 + 3, 31, W_HI); cv.vline(x0 + 3, 31, 38, W_MD)
    return cv.outline()


# ---------------------------------------------------------------- kitchen (32x32, anchor 16,31)
def kitchen():
    cv = Cv(32, 32)
    tile, grout = hx('#f1ebde'), hx('#cfc6b2')
    cv.rect(0, 1, 31, 10, tile)                                               # backsplash
    for x in range(3, 32, 4): cv.vline(x, 1, 10, grout)
    for y in (4, 8): cv.hline(0, 31, y, grout)
    cv.rect(0, 11, 31, 13, hx('#e4dac4')); cv.hline(0, 31, 11, hx('#fbf6ea')); cv.hline(0, 31, 14, hx('#8f8269'))      # counter top + front edge
    cv.rect(0, 15, 31, 30, W_MD)                                              # cabinet carcase
    cv.hline(0, 31, 15, W_DK)
    cv.rect(2, 2, 14, 12, hx('#3a3a46')); cv.rect(2, 2, 14, 3, hx('#5a5a68'))  # stove hood-less cooktop block
    for (cx, cy) in ((5, 8), (11, 8)):                                        # burners
        cv.ell(cx - 2, cy - 1, cx + 2, cy + 2, hx('#22222c')); cv.ell(cx - 1, cy, cx + 1, cy + 1, hx('#7a7a88'))
    cv.rect(3, 3, 8, 7, hx('#c8803c')); cv.hline(3, 8, 3, hx('#e8a45a')); cv.hline(3, 8, 7, hx('#8a5424')); cv.px(5, 2, hx('#e8e0d0'))   # copper pot
    cv.rect(3, 15, 13, 30, hx('#6a6a78')); cv.rect(4, 17, 12, 28, hx('#8a8a98'))                              # oven
    cv.rect(5, 19, 11, 25, hx('#2a2a36')); cv.hline(5, 11, 19, hx('#4a4a58')); cv.px(6, 20, hx('#ffb060')); cv.px(7, 20, hx('#ff8a30'))
    cv.hline(4, 12, 17, hx('#d8dae4')); cv.hline(5, 11, 27, hx('#d8dae4'))
    cv.rect(16, 6, 29, 13, hx('#cdd2de')); cv.rect(17, 8, 28, 12, hx('#7c93aa')); cv.hline(17, 28, 8, hx('#a8bdd0'))     # sink basin
    cv.vline(22, 3, 8, hx('#8a96a8')); cv.vline(23, 3, 8, hx('#c8d2e0')); cv.hline(22, 25, 3, hx('#c8d2e0')); cv.px(25, 4, hx('#8a96a8'))   # tap
    for x0 in (16, 24):                                                       # cupboard doors
        cv.rect(x0, 17, x0 + 6, 29, W_LT); cv.rect(x0 + 1, 18, x0 + 5, 28, W_MD); cv.hline(x0 + 1, x0 + 5, 18, W_DK); cv.vline(x0 + 1, 18, 28, W_DK)
        cv.px(x0 + (5 if x0 == 16 else 1), 23, hx('#f2d890'))
    cv.hline(0, 31, 30, W_XD)
    return cv.outline()


# ---------------------------------------------------------------- table (32x24, anchor 16,23)
def table():
    cv = Cv(32, 24)
    for x0, x1 in ((3, 5), (26, 28)):                                         # legs
        cv.rect(x0, 15, x1, 22, W_MD); cv.vline(x0, 15, 22, W_LT); cv.vline(x1, 15, 22, W_DK)
    cv.rect(1, 4, 30, 12, hx('#f6eedd'))                                      # cloth top (checked)
    for y in range(4, 13):
        for x in range(1, 31):
            if ((x // 3) + (y // 3)) % 2 == 0: cv.px(x, y, hx('#e98172'))
    cv.hline(1, 30, 4, hx('#ffffff'))
    cv.rect(1, 13, 30, 16, hx('#e9dcc6'))                                     # cloth front fall
    for x in range(1, 31, 3): cv.rect(x, 13, x + 1, 16, hx('#d46a5c'))
    cv.hline(1, 30, 13, hx('#c4574a')); cv.hline(1, 30, 16, hx('#a8483c'))
    for x in range(2, 31, 4): cv.px(x, 17, hx('#a8483c'))                     # scalloped hem
    cv.rect(7, 1, 9, 6, hx('#4a78b0')); cv.hline(7, 9, 1, hx('#8ab4e0')); cv.px(8, 0, hx('#3f9a3a')); cv.px(6, 0, hx('#ff7a9a')); cv.px(10, 1, hx('#ffd23a'))   # vase + flowers
    cv.ell(18, 3, 25, 7, hx('#f2e6c8')); cv.ell(19, 4, 24, 6, hx('#fff8e4'))   # plate
    cv.ell(20, 1, 23, 4, hx('#d84a3a')); cv.px(21, 1, hx('#ff8a7a')); cv.px(22, 0, hx('#4a9a3a'))   # apple
    return cv.outline()


# ---------------------------------------------------------------- chair (16x20, anchor 8,19)
def chair():
    cv = Cv(16, 20)
    cv.rect(3, 13, 4, 18, W_DK); cv.rect(11, 13, 12, 18, W_DK); cv.vline(3, 13, 18, W_MD); cv.vline(11, 13, 18, W_MD)
    cv.rect(3, 1, 12, 9, W_MD)                                                # back frame
    cv.hline(3, 12, 1, W_HI)
    for x in (5, 7, 9): cv.rect(x, 3, x + 1, 8, W_LT); cv.vline(x, 3, 8, W_HI)
    cv.rect(2, 9, 13, 13, hx('#c8564a')); cv.hline(2, 13, 9, hx('#e8827a')); cv.hline(2, 13, 13, hx('#8a342e'))   # cushion
    cv.vline(13, 10, 12, hx('#a8443c')); cv.px(7, 11, hx('#e8827a')); cv.px(8, 11, hx('#e8827a'))
    cv.hline(3, 12, 14, W_XD)
    return cv.outline()


# ---------------------------------------------------------------- bookshelf (32x40, anchor 16,39)
def bookshelf():
    cv = Cv(32, 40)
    cv.rect(1, 1, 30, 38, W_MD)                                               # carcase
    cv.rect(0, 0, 31, 3, W_LT); cv.hline(0, 31, 0, W_HI); cv.hline(0, 31, 3, W_DK)    # cornice
    cv.rect(3, 5, 28, 34, hx('#4a3020'))
    cv.vline(3, 5, 34, hx('#35221a'))
    rng = random.Random('books')
    for k, y0 in enumerate((5, 15, 25)):
        base = y0 + 8
        cv.rect(3, base + 1, 28, base + 2, W_LT); cv.hline(3, 28, base + 1, W_HI); cv.hline(3, 28, base + 2, W_DK)
        x = 4
        while x < 26:
            w = rng.randint(2, 3)
            h = rng.randint(5, 8)
            c = hx(rng.choice(['#c0524a', '#4a7ab0', '#e8b030', '#5aa045', '#8a5ac0', '#e8e0d0', '#d8764a']))
            if rng.random() < .14 and x < 22:                                  # leaning book
                cv.poly([(x, base), (x + 1, base - h), (x + 3, base - h + 1), (x + 2, base)], c); x += 4; continue
            cv.rect(x, base - h, x + w - 1, base, c)
            cv.vline(x, base - h, base, light(c, .25)); cv.hline(x, x + w - 1, base - h + 2, dark(c, .25))
            x += w
        if k == 0:                                                             # a small potted fern on top shelf
            cv.rect(23, base - 3, 27, base, hx('#c4664a')); cv.ell(22, base - 8, 28, base - 3, hx('#4a9a3a')); cv.px(25, base - 7, hx('#7acb62'))
        if k == 2:
            cv.ell(20, base - 6, 24, base, hx('#e8e0d0')); cv.px(21, base - 4, WHITE); cv.hline(19, 25, base, hx('#a8a090'))   # jar
    cv.rect(3, 35, 28, 37, W_LT); cv.hline(3, 28, 35, W_HI)
    return cv.outline()


# ---------------------------------------------------------------- rug (48x32 floor decal, anchor 0,0)
def rug():
    cv = Cv(48, 32)
    cv.rect(2, 1, 45, 30, hx('#a8362f'))
    cv.rect(3, 2, 44, 29, hx('#f0d6a0'))
    cv.rect(5, 4, 42, 27, hx('#c8564a'))
    cv.rect(7, 6, 40, 25, hx('#e8c88a'))
    cv.hline(2, 45, 1, hx('#d4574a')); cv.hline(2, 45, 30, hx('#7a2622'))
    for x in range(8, 40, 4):                                                  # border motif
        cv.px(x, 5, hx('#a8362f')); cv.px(x + 1, 5, hx('#a8362f')); cv.px(x, 26, hx('#a8362f')); cv.px(x + 1, 26, hx('#a8362f'))
    cx, cy = 24, 16
    cv.poly([(cx - 10, cy), (cx, cy - 7), (cx + 10, cy), (cx, cy + 7)], hx('#c8564a'))
    cv.poly([(cx - 7, cy), (cx, cy - 4), (cx + 7, cy), (cx, cy + 4)], hx('#f0d6a0'))
    cv.poly([(cx - 3, cy), (cx, cy - 2), (cx + 3, cy), (cx, cy + 2)], hx('#4a78b0'))
    for y in range(3, 29, 2):                                                  # fringe on the short sides
        cv.px(0, y, hx('#f6ecd0')); cv.px(1, y, hx('#e0d2ae')); cv.px(46, y, hx('#e0d2ae')); cv.px(47, y, hx('#f6ecd0'))
    return cv


# ---------------------------------------------------------------- window (16x16)
def house_window():
    cv = Cv(16, 16)
    cv.rect(2, 1, 13, 12, hx('#fff4e0'))                                       # frame
    for y in range(2, 12): cv.hline(3, 12, y, mix(hx('#bfe6f6'), hx('#7ab6dc'), (y - 2) / 9.0))
    cv.vline(7, 2, 11, hx('#fff4e0')); cv.vline(8, 2, 11, hx('#e4d8c0')); cv.hline(3, 12, 6, hx('#fff4e0'))
    cv.px(5, 3, WHITE); cv.px(6, 3, WHITE); cv.px(5, 4, WHITE)
    rose, rose_hi, rose_lo = hx('#d96a78'), hx('#ef8f9a'), hx('#a8444f')        # curtains, tied back at the sides
    for x0, x1 in ((3, 4), (11, 12)):
        cv.rect(x0, 2, x1, 9, rose)
        cv.vline(x0, 2, 9, rose_hi); cv.vline(x1, 2, 9, rose_lo)
        cv.hline(x0, x1, 7, rose_lo)                                           # tie
        cv.hline(x0, x1, 2, rose_lo)
    cv.rect(1, 13, 14, 14, W_LT); cv.hline(1, 14, 13, W_HI); cv.hline(1, 14, 14, W_DK)  # sill
    cv.rect(9, 11, 11, 12, hx('#c4664a')); cv.px(10, 10, hx('#4a9a3a')); cv.px(9, 10, hx('#ff9ec0'))   # tiny pot
    return cv


# ---------------------------------------------------------------- fireplace (32x32, anchor 16,31)
def fireplace():
    cv = Cv(32, 32)
    rng = random.Random('hearth')
    cv.rect(1, 5, 30, 30, hx('#8e919c'))                                       # stone surround
    for y in range(6, 30, 4):
        off = ((y // 4) % 2) * 3
        for x in range(1 + off, 31, 6): cv.vline(x, y, y + 2, hx('#6f7380'))
        cv.hline(1, 30, y + 3, hx('#6f7380'))
    for y in range(5, 30, 4): cv.hline(2, 29, y, hx('#a6aab6'))
    cv.rect(0, 1, 31, 5, W_LT); cv.hline(0, 31, 1, W_HI); cv.hline(0, 31, 5, W_DK)    # mantel
    cv.rect(4, 0, 5, 0, hx('#f6ecd0')); cv.rect(4, 0, 5, 1, hx('#f6ecd0')); cv.px(4, -1, hx('#ffd23a'))
    cv.rect(26, 0, 27, 1, hx('#f6ecd0'))
    cv.rect(6, 10, 25, 30, hx('#1e1a22'))                                      # firebox
    cv.rect(7, 11, 24, 29, hx('#2a2530'))
    cv.poly([(9, 30), (16, 12), (23, 30)], hx('#ff8a2a')); cv.poly([(12, 30), (16, 17), (20, 30)], hx('#ffd84a')); cv.poly([(14, 30), (16, 22), (18, 30)], hx('#fff6c8'))
    cv.rect(8, 27, 23, 29, hx('#6e4a28')); cv.hline(8, 23, 27, hx('#a8703a')); cv.ell(7, 26, 11, 29, hx('#573820')); cv.ell(20, 26, 24, 29, hx('#573820'))   # logs
    for _ in range(6): cv.px(rng.randint(10, 21), rng.randint(24, 28), hx('#ffb040'))
    cv.rect(3, 8, 4, 30, hx('#a6aab6')); cv.rect(27, 8, 28, 30, hx('#6f7380'))
    cv.rect(2, 29, 29, 30, hx('#7a7e8a')); cv.hline(2, 29, 29, hx('#b4b8c4'))                                  # hearth stone
    return cv.outline()


# ---------------------------------------------------------------- plant (16x20, anchor 8,19)
def plant_pot():
    cv = Cv(16, 20)
    cv.rect(4, 12, 11, 18, hx('#c8664a')); cv.rect(3, 11, 12, 13, hx('#e0805a')); cv.hline(3, 12, 11, hx('#f0a07a'))
    cv.vline(11, 13, 18, hx('#a4503a')); cv.hline(4, 11, 18, hx('#8a3a2a')); cv.hline(5, 10, 15, hx('#a4503a'))
    leaves = [(8, 3, 3, 4, '#3f8a3a'), (4, 6, 3, 3, '#4a9a3a'), (12, 6, 3, 3, '#4a9a3a'), (8, 8, 4, 3, '#5ab04a'), (5, 9, 2, 2, '#3a7a32'), (11, 9, 2, 2, '#3a7a32')]
    for (cx, cy, rx, ry, c) in leaves: cv.ell(cx - rx, cy - ry, cx + rx, cy + ry, hx(c))
    for (x, y) in ((7, 2), (3, 5), (10, 5), (7, 7)): cv.px(x, y, hx('#8be06e'))
    cv.px(5, 4, hx('#ff9ec0')); cv.px(12, 4, hx('#ffd23a'))
    return cv.outline()


# ---------------------------------------------------------------- new decor
def wall_picture(kind):
    """Framed picture for the back wall (16x16, wall_deco).  kind: 'hills' | 'flowers'."""
    cv = Cv(16, 16)
    cv.rect(2, 3, 13, 12, W_DK); cv.hline(2, 13, 3, W_LT); cv.vline(2, 3, 12, W_MD)
    cv.rect(3, 4, 12, 11, hx('#f6eedd'))
    if kind == 'hills':
        for y in range(5, 11): cv.hline(4, 11, y, mix(hx('#bfe6f6'), hx('#f6e8c0'), (y - 5) / 5.0))
        cv.poly([(4, 10), (6, 7), (9, 10)], hx('#6aa85a')); cv.poly([(7, 10), (10, 6), (11, 10)], hx('#4f8f4a')); cv.hline(4, 11, 10, hx('#3f7a3a'))
        cv.px(10, 5, hx('#ffd23a'))
    else:
        cv.rect(4, 5, 11, 10, hx('#f0e6cc'))
        cv.vline(7, 6, 10, hx('#4a9a3a')); cv.vline(9, 7, 10, hx('#4a9a3a'))
        cv.px(7, 5, hx('#e85a7a')); cv.px(6, 6, hx('#e85a7a')); cv.px(8, 6, hx('#e85a7a')); cv.px(9, 6, hx('#ffd23a')); cv.px(10, 7, hx('#ffd23a')); cv.px(8, 7, hx('#ffd23a'))
    cv.hline(3, 12, 11, hx('#d8cdb4'))
    cv.px(7, 2, hx('#3a3a48')); cv.px(8, 2, hx('#3a3a48'))                     # hanging nail
    return cv


def side_table():
    """Bedside table with a small lamp (16x20, anchor 8,19)."""
    cv = Cv(16, 20)
    cv.rect(3, 11, 12, 13, W_LT); cv.hline(3, 12, 11, W_HI); cv.hline(3, 12, 13, W_DK)               # top
    cv.rect(4, 14, 11, 18, W_MD); cv.rect(5, 15, 10, 17, W_LT); cv.hline(5, 10, 15, W_DK); cv.px(8, 16, hx('#f2d890'))   # drawer
    cv.rect(4, 18, 5, 19, W_DK); cv.rect(10, 18, 11, 19, W_DK)
    cv.rect(7, 8, 8, 10, hx('#8a6a3a'))                                          # lamp stem
    cv.poly([(4, 8), (11, 8), (9, 2), (6, 2)], hx('#ffe9a8')); cv.hline(6, 9, 2, hx('#fff6d0')); cv.vline(10, 4, 8, hx('#e8c870'))
    return cv.outline()
