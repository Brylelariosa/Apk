"""Item icons (UI atlas, item_<id>) and crop growth sprites (world atlas, crop_<id>_<stage>)."""
import math, random
from .common import *
from . import objects as OBJ

TIERS = ['#a4a8b4', '#d8814e', '#b4c0d4', '#eef4ff', '#ffd23a', '#b88aff']
WOODC, WOODL, WOODD = hx('#9a6c3e'), hx('#b88850'), hx('#6a4526')


def tool_icon(tool, tier):
    cv = Cv(16, 16)
    t = hx(TIERS[tier]); td = shade(t, .7); tl = light(t, .45)
    if tool in ('hoe', 'axe', 'pick', 'hammer'):
        cv.line(3, 14, 11, 5, WOODC); cv.line(4, 14, 12, 5, WOODL)
    if tool == 'hoe':
        cv.poly([(9, 3), (14, 3), (14, 8), (12, 8), (12, 5), (10, 5)], t); cv.hline(9, 14, 3, tl); cv.vline(14, 4, 8, td)
    elif tool == 'axe':
        cv.poly([(7, 2), (13, 2), (14, 6), (13, 9), (9, 8), (10, 5)], t); cv.vline(13, 3, 8, tl); cv.hline(7, 12, 2, tl); cv.poly([(9, 8), (13, 9), (10, 6)], td)
    elif tool == 'pick':
        cv.poly([(4, 4), (8, 2), (13, 3), (15, 7), (13, 6), (9, 4), (6, 6)], t); cv.hline(8, 13, 2, tl); cv.px(15, 7, td); cv.px(4, 4, td)
    elif tool == 'hammer':
        cv.poly([(7, 2), (14, 4), (13, 8), (6, 6)], t); cv.line(7, 2, 14, 4, tl); cv.line(6, 6, 13, 8, td)
    elif tool == 'rod':
        cv.line(2, 14, 13, 2, WOODC); cv.line(3, 14, 14, 2, WOODL)
        cv.line(14, 2, 14, 9, hx('#e8e4d8')); cv.px(14, 10, t); cv.px(13, 10, t); cv.ell(1, 11, 4, 14, t); cv.px(2, 12, tl)
    elif tool == 'can':
        cv.rect(4, 7, 11, 13, t); cv.rect(4, 7, 11, 8, tl); cv.rect(4, 12, 11, 13, td); cv.line(11, 10, 14, 6, t); cv.rect(13, 5, 15, 6, td)
        cv.line(4, 8, 2, 10, td); cv.line(2, 10, 3, 12, td); cv.rect(5, 5, 10, 6, hx('#6ab8f0')); cv.hline(5, 10, 5, hx('#a8dcff'))
    elif tool == 'shears':
        cv.line(5, 2, 9, 9, t); cv.line(11, 2, 7, 9, t); cv.line(6, 2, 10, 9, tl); cv.px(8, 8, td)
        cv.ell(2, 9, 6, 14, WOODC); cv.ell(3, 10, 5, 13, (0, 0, 0, 0)); cv.ell(9, 9, 13, 14, WOODC); cv.ell(10, 10, 12, 13, (0, 0, 0, 0))
    if tier == 5:
        for (x, y) in [(2, 2), (14, 13), (1, 7)]: cv.px(x, y, hx('#e8d0ff'))
    return cv.outline()


def seedpack(c1, c2):
    cv = Cv(16, 16)
    a, b = hx(c1), hx(c2)
    cv.rect(3, 3, 12, 14, hx('#f4e8c8')); cv.rect(3, 3, 12, 5, hx('#d8c898')); cv.rect(4, 7, 11, 12, a)
    cv.rect(4, 7, 11, 7, light(a, .3)); cv.vline(8, 9, 12, b); cv.rect(6, 8, 7, 9, b); cv.rect(9, 8, 10, 9, b)
    cv.hline(3, 12, 14, hx('#a89870')); cv.px(5, 4, hx('#fff6dc'))
    return cv.outline()


def root_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    if shape == 'turnip':
        cv.ell(2, 5, 13, 14, hx('#f2ead8')); cv.ell(2, 5, 13, 9, a); cv.hline(4, 11, 9, mix(a, hx('#f2ead8'), .5)); cv.px(5, 8, light(a, .4)); cv.px(8, 14, hx('#c8bca4'))
    elif shape == 'radish':
        cv.ell(3, 5, 12, 13, a); cv.poly([(5, 11), (10, 11), (8, 15)], hx('#f2ead8')); cv.px(5, 7, light(a, .45)); cv.px(6, 6, light(a, .45))
    else:
        cv.poly([(3, 10), (6, 5), (13, 6), (14, 9), (9, 13), (4, 13)], a); cv.px(7, 7, light(a, .4)); cv.line(5, 9, 11, 8, shade(a, .8)); cv.px(12, 8, shade(a, .7))
    for (x0, x1, y1) in [(7, 4, 2), (8, 8, 1), (9, 12, 2)]:
        cv.line(x0, 5, x1, y1, b)
    cv.px(8, 3, light(b, .4))
    return cv.outline()


def tuber(c1, c2):
    cv = Cv(16, 16); a = hx(c1)
    cv.ell(2, 5, 13, 13, shade(a, .85)); cv.ell(2, 4, 12, 12, a); cv.ell(4, 5, 8, 8, light(a, .35))
    for (x, y) in [(5, 9), (9, 7), (10, 10), (7, 11)]: cv.px(x, y, shade(a, .6))
    return cv.outline()


def leafy(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.ell(1, 4, 14, 14, b); cv.ell(3, 3, 12, 12, a); cv.ell(4, 4, 9, 8, light(a, .35))
    cv.line(8, 3, 8, 12, shade(a, .78)); cv.line(5, 5, 6, 11, shade(a, .85)); cv.line(11, 5, 10, 11, shade(a, .85)); cv.hline(3, 12, 13, shade(b, .75))
    return cv.outline()


def berry_icon(shape, c1, c2):
    cv = Cv(16, 16); a, g = hx(c1), hx(c2)
    if shape == 'straw':
        cv.poly([(3, 5), (12, 5), (11, 10), (8, 14), (4, 10)], a); cv.hline(4, 11, 5, light(a, .3))
        for (x, y) in [(5, 7), (8, 7), (6, 10), (9, 10), (7, 12)]: cv.px(x, y, hx('#ffe9a0'))
        cv.poly([(5, 3), (8, 6), (11, 3), (8, 4)], g)
    elif shape == 'black' or shape == 'rasp':
        for (x, y) in [(5, 8), (9, 8), (7, 5), (7, 10), (11, 11), (4, 11)] if shape == 'rasp' else [(5, 8), (9, 8), (7, 5), (7, 11)]:
            cv.ell(x - 2, y - 2, x + 2, y + 2, a); cv.px(x - 1, y - 1, light(a, .4))
        cv.rect(7, 2, 8, 3, g); cv.hline(5, 10, 3, g)
    else:
        n = [(5, 9), (10, 9), (7, 5)] if shape == 'blue' else [(5, 10), (10, 10), (8, 6)]
        for (x, y) in n:
            cv.ell(x - 2, y - 2, x + 2, y + 2, a); cv.px(x - 1, y - 1, light(a, .45)); cv.px(x, y, shade(a, .7))
        cv.rect(7, 2, 8, 4, g)
    return cv.outline()


def round_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    if shape == 'tomato':
        cv.ell(2, 4, 13, 14, shade(a, .8)); cv.ell(2, 3, 12, 13, a); cv.px(5, 6, light(a, .5)); cv.px(6, 5, light(a, .5))
        cv.poly([(5, 3), (8, 5), (11, 3), (8, 2)], hx('#3f8f3a'))
    elif shape == 'melon':
        cv.ell(1, 4, 14, 14, shade(a, .75)); cv.ell(1, 3, 13, 13, a)
        for x in (4, 7, 10): cv.line(x, 4, x + 1, 13, shade(a, .72))
        cv.px(4, 6, light(a, .5)); cv.rect(7, 2, 8, 3, hx('#7a5a30'))
    elif shape == 'pepper':
        cv.poly([(4, 4), (11, 4), (12, 10), (9, 15), (6, 13), (4, 8)], a); cv.px(5, 6, light(a, .5)); cv.px(5, 7, light(a, .5))
        cv.rect(6, 2, 9, 4, hx('#3f8f3a')); cv.px(10, 1, hx('#3f8f3a'))
    elif shape == 'pumpkin':
        cv.ell(1, 4, 14, 14, shade(a, .78)); cv.ell(1, 4, 8, 14, a); cv.ell(7, 4, 14, 14, a); cv.ell(4, 4, 11, 14, light(a, .1))
        for x in (5, 8, 11): cv.line(x, 5, x, 13, shade(a, .7))
        cv.rect(7, 2, 8, 4, hx('#4f8f3a')); cv.px(9, 2, hx('#4f8f3a')); cv.px(4, 6, light(a, .5))
    else:
        cv.poly([(4, 4), (11, 4), (13, 10), (11, 14), (6, 14), (3, 9)], a); cv.px(5, 7, light(a, .5)); cv.px(5, 8, light(a, .4))
        cv.poly([(5, 3), (8, 6), (11, 3), (8, 2)], hx('#3f8f3a'))
    return cv.outline()


def cob_icon(c1, c2):
    cv = Cv(16, 16); a, g = hx(c1), hx(c2)
    cv.ell(5, 1, 10, 13, a)
    for y in range(3, 12, 2):
        for x in (6, 8): cv.px(x, y, shade(a, .78))
    cv.px(6, 3, light(a, .5))
    cv.poly([(3, 15), (4, 6), (8, 12)], g); cv.poly([(12, 15), (11, 6), (8, 12)], shade(g, .85)); cv.poly([(6, 15), (8, 8), (10, 15)], light(g, .1))
    return cv.outline()


def grain_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    for x, top in [(4, 4), (8, 2), (12, 4)]:
        cv.line(x, 15, x, top + 3, b)
        for k in range(4):
            cv.px(x - 1, top + k * 2 + 1, a); cv.px(x + 1, top + k * 2, a); cv.px(x, top + k * 2, light(a, .3))
    return cv.outline()


def herb_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    if shape == 'leek':
        cv.rect(6, 7, 9, 15, a); cv.vline(6, 7, 15, shade(a, .85)); cv.poly([(5, 8), (2, 1), (6, 2), (7, 7)], b); cv.poly([(10, 8), (14, 1), (10, 2), (8, 7)], shade(b, .9)); cv.rect(7, 2, 8, 8, light(b, .15))
    elif shape == 'fern':
        cv.line(8, 15, 8, 4, b)
        for y in range(5, 14, 2):
            cv.line(8, y, 8 - (y - 3) // 2 + 2, y - 2, a); cv.line(8, y, 8 + (y - 3) // 2 - 2, y - 2, a)
        cv.ell(7, 1, 10, 4, a); cv.px(9, 2, b)
    elif shape == 'basil':
        for (x, y, rx, ry) in [(5, 7, 3, 3), (10, 7, 3, 3), (8, 4, 3, 3), (7, 10, 3, 3), (11, 11, 2, 2)]: cv.ell(x - rx, y - ry, x + rx, y + ry, a); cv.px(x, y, b)
        cv.line(8, 15, 8, 9, b)
    else:
        for (x, y) in [(4, 6), (11, 6), (8, 3), (6, 11), (10, 11)]: cv.poly([(x - 3, y), (x, y - 3), (x + 3, y), (x, y + 3)], a); cv.px(x, y, light(a, .4))
        cv.ell(6, 7, 7, 8, hx('#d4263c')); cv.ell(9, 8, 10, 9, hx('#d4263c')); cv.px(8, 10, hx('#d4263c'))
    return cv.outline()


def flower_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.line(8, 15, 8, 8, hx('#4a9a3a')); cv.poly([(8, 13), (4, 10), (8, 11)], hx('#5ab04a'))
    if shape == 'daffodil':
        for k in range(6):
            ang = k * math.pi / 3; cv.ell(int(8 + math.cos(ang) * 3) - 1, int(5 + math.sin(ang) * 3) - 1, int(8 + math.cos(ang) * 3) + 1, int(5 + math.sin(ang) * 3) + 1, a)
        cv.ell(6, 3, 10, 7, b); cv.px(8, 5, shade(b, .7))
    elif shape == 'dandelion':
        cv.ell(4, 1, 12, 8, a); cv.ell(6, 3, 10, 6, b)
        for (x, y) in [(5, 2), (11, 3), (8, 1), (4, 6), (12, 6)]: cv.px(x, y, light(a, .4))
    elif shape == 'bell':
        cv.poly([(5, 2), (11, 2), (12, 9), (4, 9)], a); cv.hline(5, 11, 2, light(a, .5)); cv.line(5, 9, 3, 12, b); cv.line(11, 9, 13, 12, b); cv.line(8, 9, 8, 12, b)
    elif shape == 'sun':
        for k in range(8):
            ang = k * math.pi / 4; cv.ell(int(8 + math.cos(ang) * 5) - 1, int(6 + math.sin(ang) * 5) - 1, int(8 + math.cos(ang) * 5) + 1, int(6 + math.sin(ang) * 5) + 1, a)
        cv.ell(5, 3, 11, 9, b); cv.px(7, 5, light(b, .3))
    else:
        cv.poly([(6, 3), (10, 3), (11, 9), (5, 9)], a); cv.px(8, 10, b); cv.px(8, 11, b); cv.hline(6, 10, 3, b)
    return cv.outline()


def mushroom_icon(c1, c2):
    cv = Cv(16, 16); a, s = hx(c1), hx(c2)
    cv.rect(6, 8, 9, 14, s); cv.vline(6, 8, 14, shade(s, .85)); cv.ell(1, 2, 14, 10, a); cv.hline(2, 13, 9, shade(a, .75))
    for (x, y) in [(4, 5), (8, 4), (11, 6), (7, 7)]: cv.px(x, y, light(a, .6)); cv.px(x + 1, y, light(a, .6))
    return cv.outline()


def nut_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.ell(3, 5, 12, 14, a); cv.ell(2, 2, 13, 8, b); cv.hline(3, 12, 8, shade(b, .75)); cv.px(5, 10, light(a, .4)); cv.px(8, 2, shade(b, .6))
    return cv.outline()


def shell_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    if shape == 'scallop':
        cv.poly([(8, 14), (1, 6), (3, 2), (8, 1), (13, 2), (15, 6)], a)
        for x in (4, 6, 8, 10, 12): cv.line(8, 13, x, 3, b)
        cv.rect(6, 13, 9, 15, shade(a, .8))
    else:
        cv.poly([(2, 10), (6, 4), (13, 5), (14, 10), (9, 14), (4, 13)], a); cv.ell(7, 5, 13, 11, b); cv.ell(9, 7, 12, 10, shade(a, .85)); cv.line(3, 11, 8, 6, shade(a, .75))
        cv.px(13, 9, light(a, .5))
    return cv.outline()


def gem_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    if shape == 'crystal':
        cv.poly([(8, 1), (12, 5), (12, 12), (8, 15), (4, 12), (4, 5)], a); cv.poly([(8, 1), (12, 5), (8, 6)], b); cv.poly([(8, 6), (12, 5), (12, 12), (8, 15)], shade(a, .78)); cv.px(6, 6, (255, 255, 255, 255)); cv.px(6, 7, b)
    elif shape == 'cut':
        cv.poly([(4, 3), (11, 3), (14, 7), (8, 14), (2, 7)], a); cv.poly([(4, 3), (11, 3), (9, 7), (6, 7)], b); cv.poly([(6, 7), (9, 7), (8, 14)], shade(a, .8)); cv.px(5, 4, (255, 255, 255, 255))
    else:
        cv.ell(3, 3, 12, 12, a); cv.ell(4, 4, 8, 8, b); cv.px(5, 5, (255, 255, 255, 255)); cv.ell(7, 8, 12, 12, shade(a, .85))
    return cv.outline()


def ore_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    base = hx('#6d6680')
    cv.poly([(2, 12), (3, 6), (7, 3), (12, 4), (14, 9), (12, 13), (5, 14)], base); cv.poly([(3, 6), (7, 3), (12, 4), (8, 7)], light(base, .25))
    for (x, y) in [(5, 8), (9, 6), (11, 10), (7, 11), (4, 11)]:
        cv.px(x, y, a); cv.px(x + 1, y, a); cv.px(x, y + 1, shade(a, .8)); cv.px(x, y - 1, b)
    return cv.outline()


def bar_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.poly([(2, 10), (5, 5), (14, 5), (14, 11), (11, 13), (2, 13)], shade(a, .8)); cv.poly([(2, 10), (5, 5), (14, 5), (11, 8), (2, 10)], b)
    cv.rect(2, 10, 11, 13, a); cv.poly([(11, 8), (14, 5), (14, 11), (11, 13)], shade(a, .65)); cv.hline(3, 10, 10, light(a, .35)); cv.px(5, 6, (255, 255, 255, 255))
    return cv.outline()


def lump_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.poly([(2, 12), (3, 7), (7, 4), (12, 6), (14, 11), (11, 14), (4, 14)], a); cv.poly([(3, 7), (7, 4), (12, 6), (8, 8)], b)
    cv.px(6, 11, shade(a, .7)); cv.px(10, 11, shade(a, .7)); cv.px(8, 6, light(b, .5))
    return cv.outline()


FISH_SHAPES = {'slim': (1, 6, 12, 5), 'round': (2, 3, 11, 9), 'long': (1, 5, 12, 6), 'cat': (1, 4, 12, 7), 'koi': (1, 4, 12, 7)}


def fish_icon(shape, c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    if shape == 'eel':
        for i in range(14):
            y = 8 + int(math.sin(i * 0.7) * 3)
            cv.rect(1 + i, y, 1 + i, y + 2, a if i % 4 else shade(a, .85)); cv.px(1 + i, y + 2, b)
        cv.px(14, 8 + int(math.sin(13 * .7) * 3) + 1, (255, 255, 255, 255))
        return cv.outline()
    x0, y0, w, h = FISH_SHAPES[shape]
    cv.ell(x0 + 2, y0, x0 + w + 1, y0 + h, a)
    cv.poly([(x0 + 3, y0 + h // 2), (x0 - 1, y0 - 1), (x0 - 1, y0 + h + 1)], shade(a, .85))
    cv.ell(x0 + 4, y0 + h * 2 // 3, x0 + w - 1, y0 + h, b)
    cv.px(x0 + w - 1, y0 + h // 3, (255, 255, 255, 255)); cv.px(x0 + w, y0 + h // 3, hx('#1a1a2a'))
    cv.poly([(x0 + 6, y0), (x0 + 8, y0 - 2), (x0 + 9, y0)], shade(a, .8))
    if shape == 'cat': cv.line(x0 + w + 1, y0 + h // 2, x0 + w + 2, y0 + h // 2 + 2, hx('#2a2a2a')); cv.line(x0 + w + 1, y0 + h // 2 + 1, x0 + w + 3, y0 + h // 2 + 3, hx('#2a2a2a'))
    if shape == 'koi':
        for (x, y) in [(5, 6), (8, 8), (7, 5)]: cv.px(x, y, hx('#ff8a3a')); cv.px(x + 1, y, hx('#ff8a3a'))
        for (x, y) in [(4, 7), (10, 6)]: cv.px(x, y, (255, 255, 255, 255))
    cv.px(x0 + 5, y0 + 1, light(a, .4)); cv.px(x0 + 6, y0 + 1, light(a, .4))
    return cv.outline()


def food_icon(shape, c1, c2):
    cv = Cv(16, 16)
    a = hx(c1) if c1 else hx('#d8a860'); b = hx(c2) if c2 else hx('#8ac85a')
    if shape == 'bowl':
        cv.poly([(2, 8), (13, 8), (12, 13), (3, 13)], hx('#f4ecd8')); cv.rect(3, 12, 12, 13, hx('#c8b898')); cv.ell(2, 6, 13, 10, a)
        cv.px(5, 7, b); cv.px(8, 8, b); cv.px(10, 7, light(b, .3)); cv.px(6, 8, light(a, .4))
        cv.px(6, 3, (255, 255, 255, 140)); cv.px(7, 2, (255, 255, 255, 110)); cv.px(10, 3, (255, 255, 255, 140)); cv.px(9, 2, (255, 255, 255, 110))
    elif shape == 'plate':
        cv.ell(1, 6, 14, 13, hx('#f4ecd8')); cv.ell(2, 7, 13, 12, hx('#e0d4b8')); cv.ell(4, 7, 11, 12, a); cv.ell(6, 8, 9, 11, b)
    elif shape == 'bread':
        cv.poly([(1, 11), (2, 6), (6, 3), (11, 3), (14, 6), (15, 11), (13, 13), (3, 13)], hx('#d09048')); cv.poly([(2, 6), (6, 3), (11, 3), (14, 6), (8, 8)], hx('#e8b868'))
        for x in (5, 8, 11): cv.line(x, 5, x - 1, 8, hx('#a86a30'))
    elif shape == 'pie':
        cv.ell(1, 6, 14, 13, hx('#c8c0b0')); cv.ell(2, 4, 13, 11, a); cv.ell(4, 5, 11, 9, light(a, .2))
        for x in range(3, 13, 2): cv.px(x, 11, shade(a, .7)); cv.px(x, 5, shade(a, .85))
        cv.line(5, 7, 10, 8, shade(a, .75))
    elif shape == 'cake':
        cv.poly([(2, 6), (14, 6), (14, 13), (2, 13)], hx('#f6e8c8')); cv.rect(2, 9, 14, 9, a); cv.poly([(2, 6), (14, 6), (13, 4), (3, 4)], hx('#fff6e8'))
        cv.ell(6, 1, 10, 5, b); cv.px(7, 2, light(b, .5)); cv.hline(2, 14, 13, hx('#c8b898'))
    elif shape == 'cup':
        cv.ell(1, 11, 14, 14, hx('#c8c0b0')); cv.rect(3, 6, 11, 12, hx('#f4ecd8')); cv.ell(3, 5, 11, 8, a); cv.arc = None
        cv.line(12, 7, 14, 9, hx('#f4ecd8')); cv.px(14, 10, hx('#f4ecd8')); cv.px(5, 3, (255, 255, 255, 120)); cv.px(7, 2, (255, 255, 255, 120))
    else:
        cv.ell(1, 4, 14, 14, hx('#c89a58')); cv.ell(2, 3, 13, 12, hx('#e0b878')); cv.line(3, 7, 12, 7, hx('#a87a38')); cv.rect(6, 5, 9, 6, hx('#ffe680'))
    return cv.outline()


def product_icon(shape, c1):
    cv = Cv(16, 16); a = hx(c1)
    if shape == 'egg':
        cv.ell(4, 2, 11, 14, a); cv.ell(5, 3, 8, 8, light(a, .4)); cv.hline(6, 10, 13, shade(a, .85))
    elif shape == 'milk':
        cv.rect(5, 5, 10, 14, a); cv.rect(5, 5, 6, 14, light(a, .3)); cv.rect(6, 2, 9, 5, hx('#8a96a8')); cv.rect(5, 9, 10, 11, hx('#7ab8e8')); cv.hline(5, 10, 14, shade(a, .8))
    elif shape == 'wool':
        for (x, y, r) in [(5, 8, 4), (10, 8, 4), (8, 5, 4), (8, 10, 4)]: cv.ell(x - r, y - r, x + r, y + r, a)
        for (x, y) in [(5, 6), (9, 4), (11, 8), (7, 10)]: cv.px(x, y, shade(a, .85)); cv.px(x - 1, y - 1, light(a, .5))
    elif shape == 'cheese':
        cv.poly([(1, 12), (14, 12), (14, 7), (6, 3)], a); cv.poly([(6, 3), (14, 7), (14, 12), (13, 12), (13, 8)], shade(a, .8)) if False else None
        cv.poly([(1, 12), (14, 12), (14, 8), (1, 9)], shade(a, .9)); cv.hline(1, 14, 8, light(a, .35))
        for (x, y) in [(4, 10), (8, 11), (11, 9), (7, 7)]: cv.px(x, y, shade(a, .65)); cv.px(x + 1, y, shade(a, .75))
    else:
        cv.rect(3, 4, 12, 13, a); cv.ell(1, 3, 5, 13, light(a, .25)); cv.ell(2, 5, 4, 11, shade(a, .8))
        for y in (6, 8, 10, 12): cv.hline(6, 11, y, shade(a, .85))
    return cv.outline()


def jar_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.rect(3, 5, 12, 14, hx('#d8ecf4')); cv.rect(4, 7, 11, 13, a); cv.rect(4, 7, 11, 8, light(a, .3)); cv.rect(4, 12, 11, 13, b)
    cv.rect(3, 2, 12, 5, hx('#c8a050')); cv.hline(3, 12, 2, light(hx('#c8a050'), .4)); cv.px(5, 9, (255, 255, 255, 220)); cv.px(5, 10, (255, 255, 255, 180))
    return cv.outline()


def mat_icon(shape, c1, c2):
    cv = Cv(16, 16)
    if shape == 'log':
        cv.rect(2, 4, 13, 12, WOODC); cv.hline(2, 13, 4, WOODL); cv.hline(2, 13, 12, WOODD); cv.ell(1, 3, 6, 13, hx('#d9b37a')); cv.ell(3, 6, 4, 10, hx('#a87a42')); cv.vline(9, 6, 11, WOODD)
    elif shape == 'fiber':
        for x in range(3, 13, 2): cv.line(x, 14, x + (x % 3) - 1, 3, hx('#9ac860') if x % 4 else hx('#7aa848'))
        cv.hline(3, 12, 8, hx('#c8a050'))
    elif shape == 'hay':
        cv.rect(2, 5, 13, 13, hx('#e0c060')); cv.hline(2, 13, 5, hx('#f2dc84'))
        for x in range(3, 13, 3): cv.vline(x, 6, 13, hx('#c8a040'))
        cv.hline(2, 13, 8, hx('#a8802a')); [cv.px(x, 3, hx('#e0c060')) for x in (3, 6, 9, 12)]
    else:
        for (x, y, r) in [(5, 9, 4), (10, 8, 4), (8, 5, 3)]: cv.ell(x - r, y - r, x + r, y + r, hx(c1))
        for (x, y) in [(4, 8), (9, 6), (11, 9), (7, 10)]: cv.px(x, y, hx(c2))
    return cv.outline()


def bag_icon(c1, c2):
    cv = Cv(16, 16); a, b = hx(c1), hx(c2)
    cv.poly([(3, 5), (12, 5), (14, 13), (2, 13)], a); cv.rect(5, 2, 10, 5, shade(a, .85)); cv.hline(4, 11, 4, hx('#c8a050')); cv.rect(5, 8, 10, 11, b); cv.px(7, 9, a); cv.px(8, 10, a); cv.hline(2, 14, 13, shade(a, .7))
    return cv.outline()


def misc_icon(shape):
    cv = Cv(16, 16)
    if shape == 'boot':
        cv.poly([(4, 2), (9, 2), (9, 9), (14, 11), (14, 14), (3, 14), (3, 8)], hx('#7a5a3a')); cv.rect(3, 12, 14, 14, hx('#4a3426')); cv.hline(4, 9, 3, hx('#a8845a')); cv.px(5, 9, hx('#c8b898'))
    elif shape == 'bouquet':
        for (x, y, c) in [(5, 4, '#ff7a9a'), (10, 4, '#ffd23a'), (8, 2, '#fff0f4'), (7, 6, '#c070ff'), (11, 7, '#ff7a9a')]:
            cv.ell(x - 2, y - 2, x + 2, y + 2, hx(c)); cv.px(x, y, hx('#ffe680'))
        cv.poly([(4, 8), (12, 8), (9, 15), (7, 15)], hx('#e8d4a0')); cv.hline(5, 11, 11, hx('#e8402a')); cv.line(5, 8, 8, 14, hx('#c8b080'))
    elif shape == 'ring':
        cv.d.ellipse([3, 6, 12, 14], outline=hx('#ffd23a')); cv.d.ellipse([4, 7, 11, 13], outline=hx('#d8a82a')); cv.poly([(6, 3), (9, 3), (10, 6), (5, 6)], hx('#ff7a9a')); cv.px(6, 4, (255, 255, 255, 255))
    elif shape == 'spark':
        cv.poly([(8, 1), (10, 6), (15, 8), (10, 10), (8, 15), (6, 10), (1, 8), (6, 6)], hx('#9ad8ff')); cv.poly([(8, 4), (9, 7), (12, 8), (9, 9), (8, 12), (7, 9), (4, 8), (7, 7)], hx('#e8f8ff'))
    elif shape == 'key':
        cv.ell(2, 2, 8, 8, hx('#c8a050')); cv.ell(4, 4, 6, 6, (0, 0, 0, 0)); cv.rect(7, 6, 14, 7, hx('#c8a050')); cv.rect(11, 8, 12, 11, hx('#c8a050')); cv.rect(13, 8, 14, 10, hx('#c8a050')); cv.px(3, 3, hx('#f0d890'))
    elif shape == 'letter':
        cv.rect(1, 3, 14, 13, hx('#f4ecd8')); cv.line(1, 3, 7, 8, hx('#c8b898')); cv.line(14, 3, 8, 8, hx('#c8b898')); cv.ell(6, 7, 9, 10, hx('#d8402a'))
    else:
        cv.poly([(1, 3), (14, 2), (15, 13), (2, 14)], hx('#e8d4a0')); cv.line(3, 11, 7, 6, hx('#a8845a')); cv.line(7, 6, 10, 9, hx('#a8845a')); cv.line(10, 9, 13, 5, hx('#a8845a')); cv.px(13, 5, hx('#d8402a')); cv.px(12, 4, hx('#d8402a'))
    return cv.outline()


def machine_icon(kind):
    """Machine/placeable icons are the world sprite fitted into 16x16."""
    mapping = {'fence': lambda: OBJ.fence(10), 'chest': lambda: OBJ.machine('chest'), 'sprinkler': lambda: OBJ.sprinkler(False), 'sprinkler_q': lambda: OBJ.sprinkler(True),
               'scarecrow': OBJ.scarecrow, 'furnace': lambda: OBJ.machine('furnace'), 'press': lambda: OBJ.machine('press'), 'loom': lambda: OBJ.machine('loom'),
               'jar': lambda: OBJ.machine('jar_machine'), 'mayo': lambda: OBJ.machine('mayo'), 'seedmaker': lambda: OBJ.machine('seedmaker'), 'feeder': lambda: OBJ.machine('feeder'),
               'basket': lambda: OBJ.machine('basket'), 'lamp': lambda: OBJ.machine('lamp')}
    src = mapping[kind]()
    im = src.im
    bbox = im.getbbox() or (0, 0, 16, 16)
    im = im.crop(bbox)
    w, h = im.size
    if h > 16 or w > 16:
        s = min(16.0 / h, 16.0 / w)
        im = im.resize((max(1, int(w * s + 0.5)), max(1, int(h * s + 0.5))), Image.NEAREST)
    out = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    out.paste(im, ((16 - im.size[0]) // 2, 15 - im.size[1] + 1 if im.size[1] < 16 else 0), im)
    return Cv(16, 16, out)


def make_icon(it):
    kind, _, shape = it.get('icon', 'misc:boot').partition(':')
    c1, c2 = it.get('c1', '#c8c8c8'), it.get('c2', '#888888')
    if kind == 'seedpack': return seedpack(c1, c2)
    if kind == 'root': return root_icon(shape, c1, c2)
    if kind == 'tuber': return tuber(c1, c2)
    if kind == 'leafy': return leafy(c1, c2)
    if kind == 'berry': return berry_icon(shape, c1, c2)
    if kind == 'round': return round_icon(shape, c1, c2)
    if kind == 'cob': return cob_icon(c1, c2)
    if kind == 'grain': return grain_icon(c1, c2)
    if kind == 'herb': return herb_icon(shape, c1, c2)
    if kind == 'flower': return flower_icon(shape, c1, c2)
    if kind == 'mushroom': return mushroom_icon(c1, c2)
    if kind == 'nut': return nut_icon(c1, c2)
    if kind == 'shell': return shell_icon(shape, c1, c2)
    if kind == 'gem': return gem_icon(shape, c1, c2)
    if kind == 'ore': return ore_icon(c1, c2)
    if kind == 'bar': return bar_icon(c1, c2)
    if kind == 'lump': return lump_icon(c1, c2)
    if kind == 'fish': return fish_icon(shape, c1, c2)
    if kind == 'food': return food_icon(shape, it.get('c1'), it.get('c2'))
    if kind == 'product': return product_icon(shape, c1)
    if kind == 'jar': return jar_icon(c1, c2)
    if kind == 'mat': return mat_icon(shape, c1, c2)
    if kind == 'bag': return bag_icon(c1, c2)
    if kind == 'machine': return machine_icon(shape)
    if kind == 'misc': return misc_icon(shape)
    return misc_icon('boot')


# ---------------------------------------------------------------- crop growth sprites
def crop_sprite(art, c1, c2, stage, cid=''):
    cv = Cv(16, 16)
    p, l = hx(c1), hx(c2)
    ld, ll = shade(l, .78), light(l, .3)
    soil = hx('#5a3d26')
    if stage == 0:
        cv.ell(5, 11, 10, 14, hx('#7a5434')); cv.ell(6, 11, 9, 13, hx('#8a6040')); cv.px(7, 12, hx('#e8d8a8')); cv.px(8, 12, hx('#e8d8a8'))
        return cv.outline()
    if stage == 'dead':
        for (x0, y0, x1, y1) in [(8, 14, 8, 6), (8, 10, 5, 8), (8, 9, 11, 7)]: cv.line(x0, y0, x1, y1, hx('#8a6a3a'))
        cv.px(5, 8, hx('#6a4a2a')); cv.px(11, 7, hx('#6a4a2a')); cv.px(8, 5, hx('#6a4a2a'))
        return cv.outline()
    s = stage
    def leaves(n, h, spread):
        for i in range(n):
            t = (i + 0.5) / n * 2 - 1
            x1 = int(8 + t * spread); y1 = 14 - h + abs(int(t * 2))
            cv.line(8, 14, x1, y1, l); cv.px(x1, y1 - 1, ll)
            cv.px((8 + x1) // 2, (14 + y1) // 2 + 1, ld)
    if art == 'root':
        n, h, sp = [(0, 0, 0), (2, 3, 3), (3, 5, 4), (5, 7, 5), (5, 8, 6), (5, 8, 6)][s]
        leaves(n, h, sp)
        if s >= 4: cv.ell(5, 12, 10, 15, shade(p, .85)) if s == 4 else None
        if s == 5: cv.ell(5, 11, 10, 15, p); cv.px(6, 12, light(p, .5))
    elif art == 'tuber':
        n, h, sp = [(0, 0, 0), (2, 3, 3), (4, 5, 4), (5, 7, 5), (6, 9, 6), (6, 9, 6)][s]
        leaves(n, h, sp)
        if s >= 3:
            for (x, y) in [(5, 9), (8, 7), (11, 9)]: cv.px(x, y, l); cv.px(x + 1, y, ld)
        if s == 4:
            for (x, y) in [(6, 7), (10, 8), (8, 5)]: cv.px(x, y, hx('#ffffff')); cv.px(x, y + 1, hx('#ffe680'))
        if s == 5:
            for (x, y) in [(4, 14), (11, 14), (7, 15)]: cv.ell(x - 1, y - 1, x + 2, y + 1, p); cv.px(x, y - 1, light(p, .4))
    elif art == 'leafy':
        r = [0, 2, 3, 5, 6, 6][s]
        if s >= 1:
            cv.ell(8 - r - 1, 14 - r - 1, 8 + r + 1, 15, shade(l, .8)); cv.ell(8 - r, 14 - r - 1, 8 + r, 14, l)
            cv.line(8, 14, 8, 14 - r, ll) if s > 1 else None
            if s >= 3:
                cv.line(5, 13, 6, 14 - r + 2, ld); cv.line(11, 13, 10, 14 - r + 2, ld)
        if s == 4: cv.ell(6, 8, 10, 12, light(l, .25))
        if s == 5: cv.ell(4, 7, 11, 14, p); cv.ell(5, 7, 9, 11, light(p, .3)); cv.line(8, 7, 8, 13, shade(p, .8))
    elif art in ('bush', 'fruitbush'):
        n, h, sp = [(0, 0, 0), (2, 3, 3), (4, 5, 4), (6, 7, 5), (7, 9, 6), (7, 9, 6)][s]
        leaves(n, h, sp)
        if s >= 3:
            for (x, y) in [(4, 11), (8, 8), (12, 11), (6, 9), (10, 9)]: cv.rect(x, y, x + 1, y + 1, l)
        if s == 4:
            for (x, y) in [(5, 10), (10, 9), (8, 7)]: cv.px(x, y, hx('#ffffff')); cv.px(x + 1, y, hx('#fff0a0'))
        if s == 5:
            pts = [(5, 11), (10, 10), (8, 8), (12, 12), (4, 13)] if art == 'bush' else [(5, 11), (11, 11), (8, 9)]
            for (x, y) in pts:
                if art == 'bush': cv.ell(x - 1, y - 1, x + 1, y + 1, p); cv.px(x - 1, y - 1, light(p, .5))
                else: cv.rect(x - 1, y, x + 1, y + 3, p); cv.px(x - 1, y, light(p, .5)); cv.px(x, y - 1, l)
    elif art == 'vine':
        cv.line(4, 15, 4, 1, hx('#8a5a2e')) if s >= 2 else None
        n, h, sp = [(0, 0, 0), (2, 3, 3), (3, 6, 4), (4, 9, 5), (5, 12, 5), (5, 12, 5)][s]
        leaves(n, h, sp)
        if s >= 3:
            for (x, y) in [(10, 8), (6, 6), (11, 11)]: cv.ell(x - 1, y - 1, x + 1, y + 1, l)
        if s == 4:
            for (x, y) in [(10, 6), (7, 9)]: cv.px(x, y, hx('#ffd23a')); cv.px(x + 1, y, hx('#ffe680'))
        if s == 5:
            for (x, y) in [(10, 9), (6, 11), (11, 13), (8, 6)]: cv.ell(x - 2, y - 2, x + 1, y + 1, p); cv.px(x - 2, y - 2, light(p, .5)); cv.px(x - 1, y - 3, l)
    elif art == 'stalk':
        wheat = cid == 'wheat'
        hgt = [0, 4, 7, 11, 14, 15][s]
        n = 2 if s == 1 else (3 if s < 4 else 4)
        for i in range(n):
            x = 8 + (i - (n - 1) / 2.0) * 3
            x = int(x)
            cv.line(x, 15, x + (i % 2) * 1 - 0, 15 - hgt + (i % 2) * 2, l)
            if s >= 2:
                cv.line(x, 12, x - 2, 12 - 3, ld); cv.line(x, 9 if hgt > 9 else 11, x + 2, 6 if hgt > 9 else 8, ll)
        if s >= 4:
            tx = 8
            if wheat:
                for (x, y) in [(5, 2), (8, 1), (11, 3), (6, 5), (10, 6)]:
                    for k in range(3): cv.px(x, y + k, p if s == 5 else l)
            elif s == 5:
                cv.ell(9, 7, 12, 12, p); cv.px(10, 8, light(p, .5)); cv.poly([(12, 13), (13, 6), (10, 12)], l)
                cv.ell(3, 5, 6, 9, p); cv.px(4, 6, light(p, .5))
            else:
                for x in (4, 7, 11): cv.px(x, 1, hx('#e8d8a0')); cv.px(x, 2, hx('#c8b878'))
    elif art == 'gourd':
        n, h, sp = [(0, 0, 0), (2, 2, 3), (3, 3, 5), (4, 4, 6), (4, 4, 6), (4, 4, 6)][s]
        leaves(n, h, sp)
        if s >= 2:
            for (x, y) in [(3, 11), (12, 11)]: cv.ell(x - 2, y - 2, x + 2, y + 1, l)
        if s == 3: cv.px(11, 10, hx('#ffd23a')); cv.px(12, 10, hx('#ffe680'))
        if s == 4: cv.ell(6, 11, 10, 14, shade(l, .9)); cv.px(7, 11, ll)
        if s == 5:
            cv.ell(2, 7, 13, 15, shade(p, .78)); cv.ell(2, 6, 12, 14, p); cv.px(4, 8, light(p, .5)); cv.px(5, 7, light(p, .5))
            if cid == 'melon':
                for x in (5, 8, 11): cv.line(x, 7, x + 1, 14, shade(p, .72))
            else:
                for x in (5, 8, 10): cv.line(x, 7, x, 14, shade(p, .72))
                cv.rect(7, 4, 8, 6, hx('#4f8f3a'))
    return cv.outline()


def draw_item_icons(U, W):
    items = [r for r in load_data('items.cfd') if r['_type'] == 'item']
    for it in items:
        if it.get('icon', '').startswith('tool:'):
            tool = it['icon'].split(':')[1]
            for t in range(6):
                U.add('item_%s_%d' % (it['id'], t), tool_icon(tool, t), 0, 0)
            U.add('item_' + it['id'], tool_icon(tool, 0), 0, 0)
            continue
        cv = make_icon(it)
        U.add('item_' + it['id'], cv, 0, 0)
        if it.get('cat') == 'forage':
            W.add('o_fg_' + it['id'], cv, 8, 15)


def draw_crops(W):
    for c in [r for r in load_data('crops.cfd') if r['_type'] == 'crop']:
        for s in range(6):
            W.add('crop_%s_%d' % (c['id'], s), crop_sprite(c['art'], c['c1'], c['c2'], s, c['id']), 8, 15)
        W.add('crop_%s_dead' % c['id'], crop_sprite(c['art'], c['c1'], c['c2'], 'dead', c['id']), 8, 15)
