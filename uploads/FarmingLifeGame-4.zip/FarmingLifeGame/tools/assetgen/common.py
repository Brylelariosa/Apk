"""Shared pixel-art helpers for tools/gen_assets.py (original procedural art, no external assets)."""
import math, os, random, re
import numpy as np
from PIL import Image, ImageDraw

SEASONS = ['spring', 'summer', 'autumn', 'winter']
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
DATA = os.path.join(ROOT, 'assets', 'data')


def hx(s, a=255):
    s = s.lstrip('#')
    if len(s) == 3:
        s = ''.join(ch * 2 for ch in s)
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), a)


def shade(c, f):
    return (max(0, min(255, int(c[0] * f))), max(0, min(255, int(c[1] * f))), max(0, min(255, int(c[2] * f))), c[3] if len(c) > 3 else 255)


def mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3)) + (255,)


def light(c, t=0.25):
    return mix(c, (255, 250, 235, 255), t)


def dark(c, t=0.3):
    return mix(shade(c, 0.7), (35, 25, 60, 255), t)


def rim_dark(c):
    return mix(shade(c, 0.42), (25, 15, 45, 255), 0.3)


def rim_soft(c):
    """Gentler outline colour for nature sprites (dark green/brown instead of near-black)."""
    return mix(shade(c, 0.60), (22, 44, 34, 255), 0.25)


class Cv:
    """Tiny RGBA canvas wrapper over PIL with non-antialiased shape helpers."""

    def __init__(self, w, h, im=None):
        self.w, self.h = w, h
        self.im = im if im is not None else Image.new('RGBA', (w, h), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    def px(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.im.putpixel((int(x), int(y)), c)

    def get(self, x, y):
        if 0 <= x < self.w and 0 <= y < self.h:
            return self.im.getpixel((int(x), int(y)))
        return (0, 0, 0, 0)

    def rect(self, x0, y0, x1, y1, c):  # inclusive corners; empty rectangles are skipped
        if x1 < x0 or y1 < y0:
            return
        self.d.rectangle([x0, y0, x1, y1], fill=c)

    def ell(self, x0, y0, x1, y1, c):
        self.d.ellipse([x0, y0, x1, y1], fill=c)

    def line(self, x0, y0, x1, y1, c):
        self.d.line([x0, y0, x1, y1], fill=c)

    def poly(self, pts, c):
        self.d.polygon(pts, fill=c)

    def hline(self, x0, x1, y, c):
        self.d.line([x0, y, x1, y], fill=c)

    def vline(self, x, y0, y1, c):
        self.d.line([x, y0, x, y1], fill=c)

    def paste(self, other, x, y):
        im = other.im if isinstance(other, Cv) else other
        self.im.paste(im, (int(x), int(y)), im)

    def flip(self):
        return Cv(self.w, self.h, self.im.transpose(Image.FLIP_LEFT_RIGHT))

    def copy(self):
        return Cv(self.w, self.h, self.im.copy())

    def crop(self, x, y, w, h):
        return Cv(w, h, self.im.crop((x, y, x + w, y + h)))

    def outline(self, col=None, diag=False, soft=False):
        """1px selective outline around opaque pixels (colour = darkened neighbour) - result keeps canvas size."""
        a = np.array(self.im)
        alpha = a[..., 3] > 8
        out = a.copy()
        h, w = alpha.shape
        dirs = [(0, 1), (1, 0), (-1, 0), (0, -1)] + ([(1, 1), (-1, 1), (1, -1), (-1, -1)] if diag else [])
        ys, xs = np.nonzero(~alpha)
        for y, x in zip(ys, xs):
            for dx, dy in dirs:
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and alpha[ny, nx]:
                    out[y, x] = col if col else (rim_soft if soft else rim_dark)(tuple(a[ny, nx]))
                    break
        self.im = Image.fromarray(out)
        self.d = ImageDraw.Draw(self.im)
        return self

    def bevel(self, k=0.2):
        """Top-left rim light / bottom-right shade on silhouette edges."""
        a = np.array(self.im)
        alpha = a[..., 3] > 8
        out = a.copy()
        h, w = alpha.shape

        def op(x, y):
            return not (0 <= x < w and 0 <= y < h) or not alpha[y, x]

        for y in range(h):
            for x in range(w):
                if not alpha[y, x]:
                    continue
                c = tuple(int(v) for v in a[y, x])
                if op(x, y - 1) or op(x - 1, y):
                    out[y, x] = light(c, k)[:3] + (c[3],)
                elif op(x, y + 1) or op(x + 1, y):
                    out[y, x] = dark(c, k)[:3] + (c[3],)
        self.im = Image.fromarray(out)
        self.d = ImageDraw.Draw(self.im)
        return self

    def recolor(self, mapping):
        a = np.array(self.im)
        for src, dst in mapping.items():
            m = (a[..., 0] == src[0]) & (a[..., 1] == src[1]) & (a[..., 2] == src[2]) & (a[..., 3] > 0)
            a[m] = dst[:3] + (255,)
        self.im = Image.fromarray(a)
        self.d = ImageDraw.Draw(self.im)
        return self


def speckle(cv, x0, y0, x1, y1, colors, count, rng, size=1, wrap=False):
    for _ in range(count):
        x = rng.randint(x0, x1)
        y = rng.randint(y0, y1)
        c = rng.choice(colors)
        for dx in range(size):
            for dy in range(size):
                xx, yy = x + dx, y + dy
                if wrap:
                    xx, yy = xx % cv.w, yy % cv.h
                cv.px(xx, yy, c)


class Packer:
    PAD = 1

    def __init__(self, name, w, h):
        self.name, self.w, self.h = name, w, h
        self.items = []
        self.names = set()

    def add(self, name, cv, ax=None, ay=None):
        if name in self.names:
            raise ValueError('duplicate sprite ' + name)
        self.names.add(name)
        im = cv.im if isinstance(cv, Cv) else cv
        w, h = im.size
        if ax is None:
            ax = w / 2.0
        if ay is None:
            ay = h
        self.items.append((name, im, ax, ay))

    def pack(self):
        items = sorted(self.items, key=lambda t: (-t[1].size[1], -t[1].size[0], t[0]))
        atlas = Image.new('RGBA', (self.w, self.h), (0, 0, 0, 0))
        x = y = rowh = 0
        out = []
        P = self.PAD
        for name, im, ax, ay in items:
            w, h = im.size
            if x + w + 2 * P > self.w:
                x = 0
                y += rowh
                rowh = 0
            if y + h + 2 * P > self.h:
                raise OverflowError('%s atlas full at %s (%dx%d)' % (self.name, name, self.w, self.h))
            px, py = x + P, y + P
            atlas.paste(im, (px, py))
            # edge extrusion (prevents bleeding when sampling at fractional positions)
            if w and h:
                atlas.paste(im.crop((0, 0, w, 1)), (px, py - 1))
                atlas.paste(im.crop((0, h - 1, w, h)), (px, py + h))
                atlas.paste(im.crop((0, 0, 1, h)), (px - 1, py))
                atlas.paste(im.crop((w - 1, 0, w, h)), (px + w, py))
            out.append((name, px, py, w, h, ax, ay))
            x += w + 2 * P
            rowh = max(rowh, h + 2 * P)
        self.atlas = atlas
        self.entries = out
        self.used_h = y + rowh
        return self

    def write(self, png_path, index_path, rel_png):
        self.atlas.save(png_path, optimize=True)
        with open(index_path, 'w') as f:
            f.write('#atlas %s %d %d\n' % (rel_png, self.w, self.h))
            for name, x, y, w, h, ax, ay in sorted(self.entries):
                f.write('%s %d %d %d %d %g %g\n' % (name, x, y, w, h, ax, ay))


def parse_cfd(path):
    """Parses the same .cfd format the C++ game reads."""
    recs = []
    for ln in open(path, encoding='utf-8'):
        ln = ln.strip()
        if not ln or ln.startswith('#'):
            continue
        r = {'_type': ln.split()[0]}
        for m in re.finditer(r'(\w+)=(?:"((?:[^"\\]|\\.)*)"|(\S*))', ln):
            r[m.group(1)] = m.group(2) if m.group(2) is not None else m.group(3)
        recs.append(r)
    return recs


def load_data(name):
    return parse_cfd(os.path.join(DATA, name))
