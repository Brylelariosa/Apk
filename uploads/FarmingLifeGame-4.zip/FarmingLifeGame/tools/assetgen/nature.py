"""Nature sprites v2: trees built from shaded puffs (no confetti), clean grass tufts, bushes and reeds.
Imported by objects.py, which re-binds oak/pine/bush/weed/reeds to these versions."""
import math, random
from .common import *

WOOD, WOOD_L, WOOD_D = hx('#7a5230'), hx('#9a6c3e'), hx('#573820')

CANOPY = {   # lo, base, hi, hi2
    'spring': ('#3f9a3a', '#5cb844', '#86d460', '#b4ea8c'),
    'summer': ('#2a7a2e', '#3f9e3a', '#62bf4f', '#8ad870'),
    'autumn': ('#a8481e', '#d9792b', '#f0a040', '#f9cc66'),
}


def blob(cv, cx, cy, rx, ry, c):
    cv.ell(int(round(cx - rx)), int(round(cy - ry)), int(round(cx + rx)), int(round(cy + ry)), c)


def puff(cv, cx, cy, r, lo, base, hi):
    blob(cv, cx + .5, cy + .5, r, r * .92, lo)                       # shadow rim (bottom-right)
    blob(cv, cx - .5, cy - .5, r - 1.6, (r - 1.6) * .92, base)
    blob(cv, cx - r * .28, cy - r * .36, r * .52, r * .40, hi)       # light from the top-left


def blossom(cv, x, y):
    pink, deep = hx('#ffc6da'), hx('#ff9ec0')
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)): cv.px(x + dx, y + dy, pink)
    cv.px(x, y, hx('#ffffff')); cv.px(x + 1, y + 1, deep)


def spots(cv, rng, n, mind, box):
    pts = []
    for _ in range(n * 40):
        if len(pts) >= n: break
        x, y = rng.randint(box[0], box[2]), rng.randint(box[1], box[3])
        if cv.get(x, y)[3] and all((x - a) ** 2 + (y - b) ** 2 >= mind * mind for a, b in pts): pts.append((x, y))
    return pts


def oak(season):
    cv = Cv(32, 48)
    rng = random.Random('oak2' + season)
    # trunk with flared roots and bark lines
    cv.rect(13, 28, 18, 46, WOOD); cv.vline(13, 28, 46, WOOD_L); cv.vline(14, 30, 44, hx('#8a5f36')); cv.vline(18, 28, 46, WOOD_D); cv.vline(16, 33, 41, WOOD_D)
    cv.poly([(9, 47), (12, 42), (19, 42), (22, 47)], WOOD); cv.hline(9, 22, 47, WOOD_D); cv.px(10, 46, WOOD_L); cv.px(11, 45, WOOD_L); cv.px(21, 46, WOOD_D)
    if season == 'winter':
        br = hx('#6a4a30')
        for (a, b) in [((16, 30), (16, 18)), ((16, 24), (9, 15)), ((16, 22), (23, 13)), ((9, 15), (5, 8)), ((9, 15), (12, 6)), ((23, 13), (27, 8)), ((23, 13), (20, 5)), ((16, 18), (14, 10)), ((16, 18), (19, 9)), ((13, 27), (6, 22)), ((19, 27), (26, 21))]:
            cv.line(*a, *b, br)
        snow = (246, 250, 255, 255); sh = hx('#c4d8ea')
        for (x, y) in [(16, 17), (15, 17), (9, 14), (8, 14), (23, 12), (24, 12), (12, 5), (13, 5), (20, 4), (5, 7), (27, 7), (6, 21), (7, 21), (26, 20), (25, 20), (14, 9), (19, 8)]:
            cv.px(x, y, snow); cv.px(x, y + 1, sh)
        cv.ell(10, 43, 21, 47, snow); cv.hline(11, 20, 46, sh)
        return cv.outline(soft=True)
    lo, base, hi, hi2 = [hx(c) for c in CANOPY[season]]
    cv.rect(13, 29, 18, 33, WOOD_D); cv.hline(14, 17, 34, shade(WOOD, .8))      # canopy shadow on the trunk
    puffs = [(16, 9, 8), (8, 14, 7), (24, 14, 7), (16, 15, 10), (6, 21, 6), (26, 21, 6), (16, 22, 9), (10, 26, 6), (22, 26, 6)]
    for cx, cy, r in puffs: puff(cv, cx, cy, r, lo, base, hi)
    for cx, cy, r in puffs:                                                       # a few leaf clumps per puff
        for k in range(2):
            x = int(cx - r * .45 + rng.uniform(0, r * .7)); y = int(cy - r * .55 + rng.uniform(0, r * .4))
            if cv.get(x, y)[3] and cv.get(x + 2, y)[3]: cv.hline(x, x + 2, y, hi2); cv.px(x + 1, y + 1, hi)
        x = int(cx + r * .1 + rng.uniform(0, r * .5)); y = int(cy + r * .25 + rng.uniform(0, r * .3))
        if cv.get(x, y)[3] and cv.get(x + 2, y)[3]: cv.hline(x, x + 1, y, lo)
    if season == 'spring':
        for (x, y) in spots(cv, rng, 9, 5, (4, 3, 28, 30)): blossom(cv, x, y)
    elif season == 'autumn':
        for (x, y) in spots(cv, rng, 10, 4, (4, 3, 28, 30)):
            c = hx(rng.choice(['#c9372a', '#e8c030', '#b8431f']))
            cv.px(x, y, c); cv.px(x + 1, y, c); cv.px(x, y + 1, shade(c, .85)); cv.px(x + 1, y + 1, shade(c, .85))
    return cv.outline(soft=True)


def pine(season):
    cv = Cv(24, 40)
    rng = random.Random('pine2' + season)
    cv.rect(10, 33, 13, 39, WOOD); cv.vline(10, 33, 39, WOOD_L); cv.vline(13, 33, 39, WOOD_D)
    base, hi, lo = {'spring': ('#3f9158', '#5db06f', '#2a7048'), 'summer': ('#2f7a4a', '#4a9a5c', '#1f5c3a'),
                    'autumn': ('#3a7448', '#5a8f50', '#285a38'), 'winter': ('#2f7a4a', '#4a9a5c', '#1f5c3a')}[season]
    base, hi, lo = hx(base), hx(hi), hx(lo)
    tiers = [(12, 1, 15, 7), (12, 9, 25, 9), (12, 17, 35, 11)]
    for ax, ay, by, hw in tiers:
        cv.poly([(ax, ay), (ax + hw, by), (ax - hw, by)], lo)
        cv.poly([(ax, ay + 1), (ax + hw - 2, by - 1), (ax - hw + 1, by - 1)], base)
        cv.poly([(ax, ay + 2), (ax - 1, ay + 4), (ax - hw + 3, by - 2), (ax - 2, by - 4)], hi)
        for x in range(ax - hw + 1, ax + hw, 3):                                  # scalloped hem: boughs hang below the tier
            cv.px(x, by, lo); cv.px(x + 1, by, lo); cv.px(x, by - 1, base)
        for k in range(1, 4):
            y = ay + 2 + k * (by - ay) // 5; half = (y - ay) * hw // (by - ay)
            cv.hline(ax - half + 3, ax - half + 5, y, hi)                          # light on the left boughs
            cv.hline(ax + half - 6, ax + half - 4, y + 1, lo)
    if season == 'winter':
        snow = (246, 250, 255, 255); sh = hx('#c4d8ea')
        for ax, ay, by, hw in tiers:
            for y in range(ay + 1, by - 1):
                half = int((y - ay) * hw / (by - ay))
                if (y - ay) % 5 < 3: cv.hline(ax - half + 2, ax + half - 5, y, snow)
            cv.hline(ax - hw + 1, ax + hw - 3, by - 1, sh)
    return cv.outline(soft=True)


def bush(season):
    cv = Cv(16, 16)
    rng = random.Random('bush2' + season)
    lo, base, hi = {'spring': ('#3a8a3a', '#58b04a', '#86d466'), 'summer': ('#2a7a2e', '#3f9a3a', '#66bf50'),
                    'autumn': ('#8a4a1c', '#b8742a', '#e0a040'), 'winter': ('#6a5a40', '#8a7a5a', '#b0a07c')}[season]
    lo, base, hi = hx(lo), hx(base), hx(hi)
    for cx, cy, r in ((5.5, 10, 4.6), (10.5, 10, 4.6), (8, 8, 5.2)): puff(cv, cx, cy, r, lo, base, hi)
    hi2 = light(hi, .35)
    for (x, y) in ((5, 6), (9, 5), (3, 9), (11, 8)): cv.hline(x, x + 1, y, hi2)           # leaf clumps
    for (x, y) in ((7, 11), (11, 12), (4, 12)): cv.hline(x, x + 1, y, lo)
    if season == 'winter':                                                                # bare twigs so it does not read as a rock
        tw = hx('#5a4028')
        for (a, b2) in (((6, 6), (4, 2)), ((9, 6), (11, 2)), ((8, 5), (8, 1)), ((7, 6), (6, 3))): cv.line(*a, *b2, tw)
    if season == 'spring':
        for (x, y) in ((4, 9), (9, 6), (11, 10)): blossom(cv, x, y)
    if season == 'summer':
        for (x, y) in ((4, 10), (9, 7), (11, 11), (7, 11)): cv.px(x, y, hx('#e8334a')); cv.px(x, y + 1, hx('#a82038'))
    if season == 'winter':
        snow = (246, 250, 255, 255); sh = hx('#c4d8ea')
        cv.hline(4, 11, 5, snow); cv.hline(5, 10, 6, snow); cv.hline(5, 9, 7, sh); cv.px(12, 8, snow); cv.px(3, 8, snow)
    return cv.outline(soft=True)


def weed(season, tall=False):
    cv = Cv(16, 16)
    rng = random.Random('weed2%s%d' % (season, tall))
    pal = {'spring': ('#3f8a38', '#5ab04a', '#86d466', '#a6e47e'), 'summer': ('#2f7a2e', '#3f9a3a', '#62bf4f', '#86d86a'),
           'autumn': ('#8a7a30', '#a8a040', '#c8c060', '#e0d880'), 'winter': ('#7a6a48', '#9a8a60', '#c0b088', '#e0d4b0')}[season]
    d, m, l, t = [hx(c) for c in pal]
    cv.ell(2, 12, 13, 15, shade(d, .8)[:3] + (120,))                          # soft ground shadow
    n = 7 if tall else 5
    xs = [3 + i * (10 // (n - 1)) + rng.randint(-1, 1) for i in range(n)]
    order = sorted(range(n), key=lambda i: abs(xs[i] - 8), reverse=True)       # outer blades first, centre blades on top
    for i in order:
        x0 = xs[i]; hgt = rng.randint(9, 13) if tall else rng.randint(4, 8)
        lean = (x0 - 8) // 3 + rng.randint(-1, 1)
        for k in range(hgt + 1):
            tt = k / hgt
            x = x0 + int(round(lean * tt * tt * 2.2)); y = 14 - k
            col = d if tt < .3 else (m if tt < .75 else l)
            cv.px(x, y, col)
            if tt < .6: cv.px(x + 1, y, shade(col, 1.12))
        cv.px(x0 + int(round(lean * 2.2)), 14 - hgt, t)
        if tall and season == 'spring' and i in (1, 5): blossom_tip = (x0 + int(round(lean * 2.2)), 13 - hgt); cv.px(*blossom_tip, hx('#fff0f4')); cv.px(blossom_tip[0] + 1, blossom_tip[1], hx('#ffc6da'))
        if tall and season == 'autumn' and i in (2, 4): cv.px(x0 + int(round(lean * 2.2)), 13 - hgt, hx('#e8c050')); cv.px(x0 + int(round(lean * 2.2)), 12 - hgt, hx('#c89830'))
    if season == 'winter':
        for _ in range(5): cv.px(rng.randint(3, 12), rng.randint(8, 13), (246, 250, 255, 255))
    return cv.outline(soft=True)


def reeds(season):
    cv = Cv(16, 24)
    rng = random.Random('reeds2' + season)
    col = {'spring': '#5aa84a', 'summer': '#4a9a3a', 'autumn': '#b8a050', 'winter': '#a89868'}[season]
    c, cl, cd = hx(col), light(hx(col), .25), shade(hx(col), .75)
    cv.ell(1, 20, 14, 23, (30, 50, 30, 90))
    for i in range(6):
        x = 3 + i * 2; top = rng.randint(3, 10); lean = rng.choice([-1, 0, 0, 1])
        for k in range(22 - top):
            y = 22 - k; xx = x + int(round(lean * (k / max(1, 22 - top)) ** 2 * 2))
            cv.px(xx, y, cd if k < 5 else c); cv.px(xx + 1, y, cl) if k > 5 else None
        if i % 2 == 0:
            tx = x + int(round(lean * 2)); cv.rect(tx, top - 2, tx + 1, top + 3, hx('#7a4a2a')); cv.px(tx, top - 2, hx('#9a6a3a')); cv.px(tx + 1, top + 3, hx('#583418'))
    return cv.outline(soft=True)
