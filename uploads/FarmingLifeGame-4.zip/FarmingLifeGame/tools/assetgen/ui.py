"""Font, UI panels, icons and particle sprites -> UI atlas (and a few shared bits for the world atlas)."""
import math, random
from PIL import Image, ImageDraw
from .common import *

# 5x7 pixel font (column bytes, bit0 = top row; bit7 = descender row). Public-domain style LCD font, ASCII 32..126.
FONT = [
0x00,0x00,0x00,0x00,0x00, 0x00,0x00,0x5F,0x00,0x00, 0x00,0x07,0x00,0x07,0x00, 0x14,0x7F,0x14,0x7F,0x14,
0x24,0x2A,0x7F,0x2A,0x12, 0x23,0x13,0x08,0x64,0x62, 0x36,0x49,0x56,0x20,0x50, 0x00,0x08,0x07,0x03,0x00,
0x00,0x1C,0x22,0x41,0x00, 0x00,0x41,0x22,0x1C,0x00, 0x2A,0x1C,0x7F,0x1C,0x2A, 0x08,0x08,0x3E,0x08,0x08,
0x00,0x80,0x70,0x30,0x00, 0x08,0x08,0x08,0x08,0x08, 0x00,0x00,0x60,0x60,0x00, 0x20,0x10,0x08,0x04,0x02,
0x3E,0x51,0x49,0x45,0x3E, 0x00,0x42,0x7F,0x40,0x00, 0x72,0x49,0x49,0x49,0x46, 0x21,0x41,0x49,0x4D,0x33,
0x18,0x14,0x12,0x7F,0x10, 0x27,0x45,0x45,0x45,0x39, 0x3C,0x4A,0x49,0x49,0x31, 0x41,0x21,0x11,0x09,0x07,
0x36,0x49,0x49,0x49,0x36, 0x46,0x49,0x49,0x29,0x1E, 0x00,0x00,0x14,0x00,0x00, 0x00,0x40,0x34,0x00,0x00,
0x00,0x08,0x14,0x22,0x41, 0x14,0x14,0x14,0x14,0x14, 0x00,0x41,0x22,0x14,0x08, 0x02,0x01,0x59,0x09,0x06,
0x3E,0x41,0x5D,0x59,0x4E, 0x7C,0x12,0x11,0x12,0x7C, 0x7F,0x49,0x49,0x49,0x36, 0x3E,0x41,0x41,0x41,0x22,
0x7F,0x41,0x41,0x41,0x3E, 0x7F,0x49,0x49,0x49,0x41, 0x7F,0x09,0x09,0x09,0x01, 0x3E,0x41,0x41,0x51,0x73,
0x7F,0x08,0x08,0x08,0x7F, 0x00,0x41,0x7F,0x41,0x00, 0x20,0x40,0x41,0x3F,0x01, 0x7F,0x08,0x14,0x22,0x41,
0x7F,0x40,0x40,0x40,0x40, 0x7F,0x02,0x1C,0x02,0x7F, 0x7F,0x04,0x08,0x10,0x7F, 0x3E,0x41,0x41,0x41,0x3E,
0x7F,0x09,0x09,0x09,0x06, 0x3E,0x41,0x51,0x21,0x5E, 0x7F,0x09,0x19,0x29,0x46, 0x26,0x49,0x49,0x49,0x32,
0x03,0x01,0x7F,0x01,0x03, 0x3F,0x40,0x40,0x40,0x3F, 0x1F,0x20,0x40,0x20,0x1F, 0x3F,0x40,0x38,0x40,0x3F,
0x63,0x14,0x08,0x14,0x63, 0x03,0x04,0x78,0x04,0x03, 0x61,0x59,0x49,0x4D,0x43, 0x00,0x7F,0x41,0x41,0x00,
0x02,0x04,0x08,0x10,0x20, 0x00,0x41,0x41,0x7F,0x00, 0x04,0x02,0x01,0x02,0x04, 0x40,0x40,0x40,0x40,0x40,
0x00,0x03,0x07,0x08,0x00, 0x20,0x54,0x54,0x78,0x40, 0x7F,0x28,0x44,0x44,0x38, 0x38,0x44,0x44,0x44,0x28,
0x38,0x44,0x44,0x28,0x7F, 0x38,0x54,0x54,0x54,0x18, 0x00,0x08,0x7E,0x09,0x02, 0x18,0xA4,0xA4,0x9C,0x78,
0x7F,0x08,0x04,0x04,0x78, 0x00,0x44,0x7D,0x40,0x00, 0x20,0x40,0x40,0x3D,0x00, 0x7F,0x10,0x28,0x44,0x00,
0x00,0x41,0x7F,0x40,0x00, 0x7C,0x04,0x78,0x04,0x78, 0x7C,0x08,0x04,0x04,0x78, 0x38,0x44,0x44,0x44,0x38,
0xFC,0x18,0x24,0x24,0x18, 0x18,0x24,0x24,0x18,0xFC, 0x7C,0x08,0x04,0x04,0x08, 0x48,0x54,0x54,0x54,0x24,
0x04,0x04,0x3F,0x44,0x24, 0x3C,0x40,0x40,0x20,0x7C, 0x1C,0x20,0x40,0x20,0x1C, 0x3C,0x40,0x30,0x40,0x3C,
0x44,0x28,0x10,0x28,0x44, 0x4C,0x90,0x90,0x90,0x7C, 0x44,0x64,0x54,0x4C,0x44, 0x00,0x08,0x36,0x41,0x00,
0x00,0x00,0x7F,0x00,0x00, 0x00,0x41,0x36,0x08,0x00, 0x02,0x01,0x02,0x04,0x02,
]


def glyph(code):
    cols = FONT[(code - 32) * 5:(code - 32) * 5 + 5]
    cv = Cv(5, 8)
    for x, b in enumerate(cols):
        for y in range(8):
            if b & (1 << y):
                cv.px(x, y, (255, 255, 255, 255))
    return cv


def ascii_cv(rows, pal):
    h = len(rows)
    w = max(len(r) for r in rows)
    cv = Cv(w, h)
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in pal:
                cv.px(x, y, pal[ch])
    return cv


def rbox(w, h, fill, border, r=3, hi=None, lo=None, inner=None):
    cv = Cv(w, h)
    cv.d.rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=border)
    cv.d.rounded_rectangle([1, 1, w - 2, h - 2], radius=max(1, r - 1), fill=fill)
    if hi:
        cv.hline(r, w - r - 1, 1, hi)
        cv.vline(1, r, h - r - 1, hi)
    if lo:
        cv.hline(r, w - r - 1, h - 2, lo)
        cv.vline(w - 2, r, h - r - 1, lo)
    if inner:
        cv.d.rounded_rectangle([3, 3, w - 4, h - 4], radius=max(1, r - 2), outline=inner)
    return cv


W = (255, 255, 255, 255)


def draw_ui(P, rng):
    # ---------- basics
    P.add('white', Cv(2, 2, Image.new('RGBA', (2, 2), (255, 255, 255, 255))), 0, 0)
    chk = Cv(16, 16)
    for y in range(16):
        for x in range(16):
            chk.px(x, y, (255, 0, 255, 255) if ((x // 4) + (y // 4)) % 2 == 0 else (30, 0, 30, 255))
    P.add('missing', chk, 8, 16)
    # ---------- font
    for code in range(32, 127):
        g = glyph(code)
        if code == 32:
            P.add('g_32', Cv(1, 8), 4, 0)
            continue
        a = [x for x in range(5) if any(g.get(x, y)[3] for y in range(8))]
        x0, x1 = min(a), max(a)
        P.add('g_%d' % code, g.crop(x0, 0, x1 - x0 + 1, 8), x1 - x0 + 2, 0)
    # ---------- panels (nine-slice)
    P.add('ui_panel', rbox(24, 24, hx('#f7edd5'), hx('#5a3d26'), 4, hx('#fff8e6'), hx('#e2cf9f'), hx('#d9b27a')), 0, 0)
    P.add('ui_panel_dark', rbox(16, 16, (28, 22, 40, 205), (255, 255, 255, 60), 3), 0, 0)
    P.add('ui_panel_plain', rbox(16, 16, hx('#efe2c0'), hx('#8a6a45'), 2), 0, 0)
    P.add('ui_dialog', rbox(24, 24, hx('#fbf3dc'), hx('#4a2f1c'), 4, hx('#ffffff'), hx('#e0c994'), hx('#c9965a')), 0, 0)
    P.add('ui_button', rbox(16, 16, hx('#e8c27a'), hx('#5a3d26'), 3, hx('#fbe6b0'), hx('#c79a52')), 0, 0)
    P.add('ui_button_down', rbox(16, 16, hx('#c79a52'), hx('#5a3d26'), 3, hx('#a87d3e'), hx('#d8b070')), 0, 0)
    P.add('ui_button_green', rbox(16, 16, hx('#8fd06a'), hx('#2f5a2a'), 3, hx('#c8f0a8'), hx('#5aa045')), 0, 0)
    P.add('ui_button_red', rbox(16, 16, hx('#e98a78'), hx('#6a2a22'), 3, hx('#ffc4b8'), hx('#c25a48')), 0, 0)
    P.add('ui_button_off', rbox(16, 16, hx('#cfc8b8'), hx('#7a7468'), 3, hx('#e8e2d4'), hx('#aaa294')), 0, 0)
    P.add('ui_slot', rbox(20, 20, hx('#e6d2a6'), hx('#8a6a42'), 3, None, hx('#f4e6c2')), 0, 0)
    sel = Cv(20, 20)
    sel.d.rounded_rectangle([0, 0, 19, 19], radius=3, outline=hx('#ffcf40'))
    sel.d.rounded_rectangle([1, 1, 18, 18], radius=2, outline=hx('#fff0a0'))
    P.add('ui_slot_sel', sel, 0, 0)
    P.add('ui_tab', rbox(16, 16, hx('#d8bd86'), hx('#6a4a2e'), 3, hx('#ecd8a8'), None), 0, 0)
    P.add('ui_tab_sel', rbox(16, 16, hx('#f7edd5'), hx('#5a3d26'), 3, hx('#ffffff'), None), 0, 0)
    P.add('ui_bar_bg', rbox(8, 8, (40, 30, 30, 220), (255, 255, 255, 70), 2), 0, 0)
    P.add('ui_bar_fill', rbox(8, 8, (255, 255, 255, 255), (255, 255, 255, 255), 2, None, hx('#c8c8c8')), 0, 0)
    P.add('ui_toast', rbox(16, 16, (40, 28, 24, 225), hx('#e8c27a'), 3), 0, 0)
    # circles
    def disc(size, fill, ring=None, rw=2):
        cv = Cv(size, size)
        cv.ell(0, 0, size - 1, size - 1, ring or fill)
        if ring:
            cv.ell(rw, rw, size - 1 - rw, size - 1 - rw, fill)
        return cv
    P.add('ui_circle', disc(32, W), 0, 0)
    P.add('ui_ring', disc(64, (255, 255, 255, 0), (255, 255, 255, 255), 3), 0, 0)
    ring = disc(64, (255, 255, 255, 70), (255, 255, 255, 190), 3)
    P.add('ui_joy_base', ring, 0, 0)
    knob = disc(32, (255, 255, 255, 150), (255, 255, 255, 230), 2)
    P.add('ui_joy_knob', knob, 0, 0)
    btn = disc(48, (255, 255, 255, 110), (255, 255, 255, 235), 3)
    P.add('ui_action_btn', btn, 0, 0)
    P.add('ui_check_off', rbox(12, 12, hx('#fff6dc'), hx('#5a3d26'), 2), 0, 0)
    on = rbox(12, 12, hx('#8fd06a'), hx('#2f5a2a'), 2)
    for (x, y) in [(3, 6), (4, 7), (5, 8), (6, 7), (7, 6), (8, 5), (9, 4)]:
        on.px(x, y, W)
    P.add('ui_check_on', on, 0, 0)
    P.add('ui_knob', disc(12, hx('#e8c27a'), hx('#5a3d26'), 2), 0, 0)
    P.add('ui_track', rbox(8, 6, hx('#a8885a'), hx('#5a3d26'), 2), 0, 0)
    # arrows / close
    P.add('ui_arrow_l', ascii_cv(['...#', '..##', '.###', '####', '.###', '..##', '...#'], {'#': W}), 0, 0)
    P.add('ui_arrow_r', ascii_cv(['#...', '##..', '###.', '####', '###.', '##..', '#...'], {'#': W}), 0, 0)
    P.add('ui_arrow_u', ascii_cv(['...##...', '..####..', '.######.', '########'], {'#': W}), 0, 0)
    P.add('ui_arrow_d', ascii_cv(['########', '.######.', '..####..', '...##...'], {'#': W}), 0, 0)
    P.add('ui_close', ascii_cv(['##....##', '###..###', '.######.', '..####..', '..####..', '.######.', '###..###', '##....##'], {'#': W}), 0, 0)
    P.add('ui_star', ascii_cv(['...#...', '...#...', '..###..', '#######', '.#####.', '..###..', '.##.##.', '.#...#.'], {'#': W}), 0, 0)
    # ---------- small icons (white unless coloured)
    R, D, Pk = hx('#e8334a'), hx('#8a1a2a'), hx('#ff9aa8')
    P.add('ic_heart', ascii_cv(['.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'], {'#': R}).outline(D), 0, 0)
    P.add('ic_heart_empty', ascii_cv(['.##.##.', '#######', '#######', '.#####.', '..###..', '...#...'], {'#': hx('#6a5a62')}).outline(hx('#2a2024')), 0, 0)
    P.add('ic_heart_half', ascii_cv(['.##.##.', '###.###', '###.###', '.##.##.', '..#.#..', '...#...'], {'#': R}).outline(D), 0, 0)
    Y, Yd = hx('#ffd23a'), hx('#b8861a')
    P.add('ic_bolt', ascii_cv(['...##', '..##.', '.###.', '#####', '..##.', '.##..', '.#...'], {'#': Y}).outline(Yd), 0, 0)
    coin = Cv(10, 10)
    coin.ell(0, 0, 9, 9, Yd); coin.ell(1, 1, 8, 8, Y); coin.vline(5, 3, 6, Yd); coin.px(3, 2, light(Y, .6)); coin.px(2, 3, light(Y, .6))
    P.add('ic_coin', coin, 0, 0)
    clock = Cv(11, 11)
    clock.ell(0, 0, 10, 10, hx('#5a3d26')); clock.ell(1, 1, 9, 9, hx('#fff4d8')); clock.vline(5, 2, 5, hx('#3a2a1a')); clock.hline(5, 7, 5, hx('#3a2a1a'))
    P.add('ic_clock', clock, 0, 0)
    # weather
    def cloud(cv, ox, oy, col=hx('#f4f6fa'), sh=hx('#b8c4d4')):
        cv.ell(ox + 1, oy + 4, ox + 7, oy + 9, col); cv.ell(ox + 5, oy + 2, ox + 12, oy + 9, col); cv.ell(ox + 8, oy + 5, ox + 14, oy + 10, col)
        cv.hline(ox + 3, ox + 12, oy + 10, sh)
    def sun(cv, cx, cy, r=3):
        for a in range(8):
            ang = a * math.pi / 4
            cv.px(cx + round(math.cos(ang) * (r + 2)), cy + round(math.sin(ang) * (r + 2)), hx('#ffc93a'))
        cv.ell(cx - r, cy - r, cx + r, cy + r, hx('#ffd84a')); cv.px(cx - 1, cy - 1, hx('#fff4a0'))
    c = Cv(16, 16); sun(c, 8, 8, 3); P.add('ic_w_sunny', c.outline(), 0, 0)
    c = Cv(16, 16); sun(c, 5, 5, 2); cloud(c, 1, 4); P.add('ic_w_cloudy', c.outline(), 0, 0)
    c = Cv(16, 16); cloud(c, 1, 0, hx('#c8d2e0'), hx('#8a9ab0'))
    for (x, y) in [(4, 11), (8, 12), (12, 11), (6, 14)]: c.vline(x, y, y + 1, hx('#4aa3e8'))
    P.add('ic_w_rain', c.outline(), 0, 0)
    c = Cv(16, 16); cloud(c, 1, 0, hx('#a0aabc'), hx('#6a7a92'))
    for (x, y) in [(3, 11), (6, 11), (9, 11), (12, 11), (4, 14), (7, 14), (10, 14)]: c.vline(x, y, y + 1, hx('#3a8ae0'))
    P.add('ic_w_heavy', c.outline(), 0, 0)
    c = Cv(16, 16); cloud(c, 1, 0, hx('#8a94aa'), hx('#5a6a82'))
    for (x, y) in [(7, 10), (8, 11), (6, 12), (7, 13), (5, 14)]: c.px(x, y, hx('#ffe040')); c.px(x + 1, y, hx('#ffe040'))
    P.add('ic_w_storm', c.outline(), 0, 0)
    c = Cv(16, 16)
    for y in (3, 6, 9, 12): c.hline(2 + (y % 2) * 2, 13 - (y % 2) * 2, y, hx('#c8d0dc'))
    P.add('ic_w_fog', c.outline(), 0, 0)
    c = Cv(16, 16)
    for (y, x0, x1) in [(4, 2, 11), (8, 3, 13), (12, 2, 10)]: c.hline(x0, x1, y, hx('#c8e4f0'))
    c.px(11, 3, hx('#c8e4f0')); c.px(12, 4, hx('#c8e4f0')); c.px(13, 7, hx('#c8e4f0')); c.px(13, 9, hx('#c8e4f0'))
    P.add('ic_w_wind', c.outline(), 0, 0)
    c = Cv(16, 16)
    for (a, b) in [((8, 2), (8, 13)), ((2, 8), (13, 8)), ((3, 3), (12, 12)), ((12, 3), (3, 12))]: c.line(*a, *b, hx('#e8f6ff'))
    P.add('ic_w_snow', c.outline(hx('#4a7aa8')), 0, 0)
    # seasons
    c = Cv(16, 16); c.vline(8, 7, 13, hx('#4a9a3a')); c.ell(3, 3, 8, 8, hx('#7ad05a')); c.ell(8, 4, 13, 9, hx('#5ab84a')); P.add('ic_s_spring', c.outline(), 0, 0)
    c = Cv(16, 16); sun(c, 8, 8, 3); P.add('ic_s_summer', c.outline(), 0, 0)
    c = Cv(16, 16); c.ell(3, 3, 12, 12, hx('#e0782a')); c.poly([(8, 2), (13, 8), (8, 13), (3, 8)], hx('#e0782a')); c.line(8, 4, 8, 14, hx('#8a4a1a')); c.line(8, 9, 5, 6, hx('#8a4a1a')); c.line(8, 9, 11, 6, hx('#8a4a1a')); P.add('ic_s_autumn', c.outline(), 0, 0)
    c = Cv(16, 16)
    for (a, b) in [((8, 2), (8, 13)), ((2, 8), (13, 8)), ((3, 3), (12, 12)), ((12, 3), (3, 12))]: c.line(*a, *b, hx('#bfe6ff'))
    P.add('ic_s_winter', c.outline(hx('#3a6a98')), 0, 0)
    # action / menu glyphs (white, tinted at runtime)
    P.add('ac_talk', ascii_cv(['.#######.', '#.......#', '#.#.#.#.#', '#.......#', '.##...##.', '...#.#...', '....#....'], {'#': W}), 0, 0)
    P.add('ac_hand', ascii_cv(['..#.#.#...', '..#.#.#.#.', '#.#.#.#.#.', '#.#####.#.', '#########.', '.########.', '..#######.', '...#####..'], {'#': W}), 0, 0)
    P.add('ac_eat', ascii_cv(['#.#.#.#..', '#.#.#.#..', '#######..', '..###....', '..###....', '..###....', '..###....', '..###....'], {'#': W}), 0, 0)
    P.add('ac_sleep', ascii_cv(['#####....', '...#.....', '..#...###', '.#.....#.', '#####.#..', '.......##', '......###'], {'#': W}), 0, 0)
    P.add('ac_enter', ascii_cv(['..####..', '..#..#..', '#.#..#..', '###..#..', '###..#..', '#.#..#..', '..#..#..', '..####..'], {'#': W}), 0, 0)
    P.add('ac_ship', ascii_cv(['....#....', '...###...', '..#####..', '....#....', '#########', '#.......#', '#.......#', '#########'], {'#': W}), 0, 0)
    P.add('ac_cook', ascii_cv(['..#...#..', '...#.#...', '#########', '#########', '#.......#', '.#######.', '..#####..'], {'#': W}), 0, 0)
    P.add('ac_read', ascii_cv(['.########.', '#.#####..#', '#.......##', '#.####..##', '#.......##', '#.####..##', '#.......##', '.########.'], {'#': W}), 0, 0)
    P.add('ac_use', ascii_cv(['...##...', '.######.', '.##..##.', '##....##', '##....##', '.##..##.', '.######.', '...##...'], {'#': W}), 0, 0)
    P.add('ic_bag', ascii_cv(['..####..', '.#....#.', '.######.', '########', '#......#', '#.####.#', '#.####.#', '########'], {'#': W}), 0, 0)
    P.add('ic_quest', ascii_cv(['.########.', '#........#', '#.######.#', '#........#', '#.####...#', '#........#', '#.######.#', '.########.'], {'#': W}), 0, 0)
    P.add('ic_friends', ascii_cv(['.###..###.', '#####.####', '.###..###.', '..#....#..', '#####.####', '#####.####'], {'#': W}), 0, 0)
    P.add('ic_book', ascii_cv(['.#########', '#.#.....##', '#.#.###.##', '#.#.....##', '#.#.###.##', '#.#.....##', '#.#######.', '.#........'], {'#': W}), 0, 0)
    P.add('ic_gear', ascii_cv(['...##...', '.#.##.#.', '.######.', '###..###', '###..###', '.######.', '.#.##.#.', '...##...'], {'#': W}), 0, 0)
    P.add('ic_pause', ascii_cv(['###..###', '###..###', '###..###', '###..###', '###..###', '###..###'], {'#': W}), 0, 0)
    P.add('ic_save', ascii_cv(['########.', '#.####.##', '#.####.##', '#......##', '#.####.##', '#.####.##', '#########'], {'#': W}), 0, 0)
    P.add('ic_menu', ascii_cv(['########', '........', '########', '........', '########'], {'#': W}), 0, 0)
    P.add('ic_hammer', ascii_cv(['.#####..', '.######.', '.#####..', '...#....', '...#....', '...#....', '...#....'], {'#': W}), 0, 0)
    P.add('ic_lock', ascii_cv(['..####..', '.#....#.', '.#....#.', '########', '###..###', '###..###', '########'], {'#': W}), 0, 0)
    P.add('ic_check', ascii_cv(['......##', '.....##.', '#...##..', '##.##...', '.###....', '..#.....'], {'#': W}), 0, 0)
    P.add('ic_minus', ascii_cv(['######'], {'#': W}), 0, 0)
    P.add('ic_plus', ascii_cv(['..##..', '..##..', '######', '######', '..##..', '..##..'], {'#': W}), 0, 0)
    # ---------- fx (UI atlas; tinted at runtime)
    P.add('fx_rain', ascii_cv(['#', '#', '#', '#'], {'#': (210, 230, 255, 200)}), 0, 0)
    P.add('fx_rain_heavy', ascii_cv(['.#', '.#', '#.', '#.', '#.'], {'#': (200, 225, 255, 220)}), 0, 0)
    for i, rows in enumerate([['.#.', '#.#'], ['#...#', '.#.#.'], ['#.....#', '.#...#.']]):
        P.add('fx_splash_%d' % i, ascii_cv(rows, {'#': (225, 240, 255, 210)}), 0, 0)
    P.add('fx_snow_0', ascii_cv(['#'], {'#': W}), 0, 0)
    P.add('fx_snow_1', ascii_cv(['##', '##'], {'#': W}), 0, 0)
    P.add('fx_snow_2', ascii_cv(['.#.', '###', '.#.'], {'#': W}), 0, 0)
    for i, c in enumerate(['#e0782a', '#c8402a', '#e8b030', '#8aa83a']):
        P.add('fx_leaf_%d' % i, ascii_cv(['.#.', '###', '.#.'], {'#': hx(c)}), 0, 0)
    P.add('fx_petal_0', ascii_cv(['##', '#.'], {'#': hx('#ffc8d8')}), 0, 0)
    P.add('fx_petal_1', ascii_cv(['##', '##'], {'#': hx('#fff0f4')}), 0, 0)
    for i, rows in enumerate([['.##.', '####', '####', '.##.'], ['..#...', '.###..', '#####.', '.###..', '..#...'], ['..#.#..', '.#####.', '#######', '.#####.', '..#.#..']]):
        P.add('fx_dust_%d' % i, ascii_cv(rows, {'#': (230, 215, 190, 150)}), 0, 0)
    for i, rows in enumerate([['.#.', '###', '.#.'], ['..#..', '..#..', '#####', '..#..', '..#..'], ['#...#', '.#.#.', '..#..', '.#.#.', '#...#']]):
        P.add('fx_sparkle_%d' % i, ascii_cv(rows, {'#': hx('#fff6b0')}), 0, 0)
    P.add('fx_heart', ascii_cv(['.#.#.', '#####', '#####', '.###.', '..#..'], {'#': hx('#ff5a78')}).outline(hx('#8a1a2a')), 0, 0)
    ex = ascii_cv(['.#####.', '#######', '###.###', '###.###', '#######', '###.###', '.#####.'], {'#': hx('#fff8e0')}).outline(hx('#5a3d26'))
    ex.rect(3, 2, 4, 4, hx('#e8402a')); ex.rect(3, 6, 4, 6, hx('#e8402a'))
    ex = ascii_cv(['.#####.', '#######', '###.###', '###.###', '###.###', '#######', '###.###', '.#####.', '...#...'], {'#': hx('#fff8e0')}).outline(hx('#5a3d26'))
    for (x, y) in [(3, 2), (3, 3), (3, 4), (3, 6)]: ex.px(x, y + 1, hx('#e8402a'))
    P.add('fx_exclaim', ex, 4, 12)
    P.add('fx_zzz', ascii_cv(['#####..', '...#...', '..#..##', '.#...#.', '#####..'], {'#': hx('#e8f4ff')}).outline(hx('#4a6a98')), 0, 0)
    P.add('fx_note', ascii_cv(['..###', '..#.#', '..#..', '..#..', '###..', '###..'], {'#': hx('#fff0c0')}).outline(hx('#6a4a2a')), 0, 0)
    P.add('fx_ellipsis', ascii_cv(['#.#.#'], {'#': hx('#fff0c0')}), 0, 0)
    for i, col in enumerate(['#ffb0e0', '#ffe060', '#a0d8ff']):
        for f in range(2):
            b = Cv(7, 6)
            wy = 0 if f == 0 else 2
            b.rect(3, 1, 3, 4, hx('#3a2a2a'))
            b.poly([(0, 1 + wy // 2), (3, 2), (0, 4 - wy // 2)], hx(col)); b.poly([(6, 1 + wy // 2), (3, 2), (6, 4 - wy // 2)], hx(col))
            P.add('fx_butterfly_%d_%d' % (i, f), b, 3, 3)
    g = Cv(7, 7)
    for r, a in [(3, 40), (2, 110), (1, 255)]: g.ell(3 - r, 3 - r, 3 + r, 3 + r, (255, 250, 150, a))
    P.add('fx_firefly', g, 3, 3)
    for i in range(4):
        r = 2 + i * 2
        c = Cv(r * 2 + 3, r + 3)
        c.d.ellipse([0, 0, r * 2 + 2, r + 2], outline=(235, 245, 255, max(60, 230 - i * 55)))
        P.add('fx_ripple_%d' % i, c, c.w / 2.0, c.h / 2.0)
    for i in range(3):
        c = Cv(9, 9)
        for (a, b) in [((4, 0), (4, 8)), ((0, 4), (8, 4)), ((1, 1), (7, 7)), ((7, 1), (1, 7))][: 2 + i]: c.line(*a, *b, (255, 245, 210, 255))
        P.add('fx_hit_%d' % i, c, 4, 4)
    for i in range(3):
        c = Cv(3, 3); c.rect(0, 0, 1 + (i % 2), 1 + (i // 2 % 2), W)
        P.add('fx_chip_%d' % i, c, 1, 1)
    P.add('fx_drop', ascii_cv(['.#.', '###', '###', '.#.'], {'#': hx('#6ab8f0')}), 0, 0)
    # radial light (white, alpha = falloff)
    L = 64
    lt = Image.new('RGBA', (L, L))
    for y in range(L):
        for x in range(L):
            d = math.hypot(x - L / 2 + .5, y - L / 2 + .5) / (L / 2)
            a = max(0.0, 1.0 - d)
            a = a * a * (3 - 2 * a)
            lt.putpixel((x, y), (255, 255, 255, int(255 * a)))
    P.add('fx_light', Cv(L, L, lt), 32, 32)
    # soft fog puff
    F = Image.new('RGBA', (48, 24))
    for y in range(24):
        for x in range(48):
            d = math.hypot((x - 24) / 24.0, (y - 12) / 12.0)
            a = max(0.0, 1 - d)
            F.putpixel((x, y), (235, 240, 245, int(120 * a * a)))
    P.add('fx_fog', Cv(48, 24, F), 24, 12)
    # emote bubble backgrounds are in-game; vignette helper
    V = Image.new('RGBA', (32, 32))
    for y in range(32):
        for x in range(32):
            d = max(abs(x - 15.5), abs(y - 15.5)) / 16.0
            V.putpixel((x, y), (0, 0, 0, int(200 * max(0, (d - 0.55) / 0.45) ** 2)))
    P.add('fx_vignette', Cv(32, 32, V), 0, 0)
