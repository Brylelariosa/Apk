"""House and shop exteriors: front-facing, bottom-left anchored, composed from small parts.

house(wt, ht, ...) keeps the map contract of the old generator: the footprint is wt x ht tiles, `roof_extra` rows of
roof stand above it, and the door sits on the bottom row at tile column `doorcol` (14x24 px, x = doorcol*16 + 1),
so sprite sizes, collision and warps are unchanged.  Everything else is parts:

  textures   shingle_tex, clapboard_tex / log_tex / plaster_tex, stone_tex
  structure  paint_walls (+ corner trim, timber framing, eave shadow), paint_roof (ridge cap, hip lines, drip edge)
  openings   paint_window, paint_door, paint_hood, paint_portico, paint_awning
  roofline   paint_dormer, paint_chimney
  details    wall_lantern, pot, firewood, vine, sign_plaque   (passed to house() as `details` callables)

Light comes from the top-left; roofs are shaded in three vertical bands to match.
"""
import random
from PIL import Image, ImageDraw
from .common import *

DOOR_W, DOOR_H = 14, 24
GLASS_TOP, GLASS_BOT = hx('#b4e2f4'), hx('#6fb0d6')
WHITE = (255, 255, 255, 255)


# ---------------------------------------------------------------- geometry
class Geo:
    """Row/column landmarks of one house sprite."""

    def __init__(s, wt, ht, roof_extra, tall_roof, ridge):
        s.wt, s.ht = wt, ht
        s.W, s.H = wt * 16, ht * 16 + roof_extra
        s.eave = int(ht * 16 * 0.48) + roof_extra + tall_roof + 1      # first row below the roof
        s.top = roof_extra - 6                                          # ridge row
        s.inset = int(s.W * ridge)                                      # ridge indent on each side
        s.found = s.H - 5                                               # top of the stone foundation
        s.door_top = s.H - DOOR_H

    def roof_poly(s):
        return [(0, s.eave), (s.W - 1, s.eave), (s.W - 1 - s.inset, s.top), (s.inset, s.top)]

    def edge_x(s, y):
        """x of the roof's left slanted edge at row y."""
        t = (s.eave - y) / float(s.eave - s.top)
        return int(round(s.inset * max(0.0, min(1.0, t))))


def paste_poly(dst, tex, poly):
    mask = Image.new('L', (dst.w, dst.h), 0)
    ImageDraw.Draw(mask).polygon(poly, fill=255)
    dst.im.paste(tex.im, (0, 0), mask)


def darken(cv, x0, y0, x1, y1, f):
    """Multiply the opaque pixels of a rectangle by f."""
    for y in range(max(0, y0), min(cv.h - 1, y1) + 1):
        for x in range(max(0, x0), min(cv.w - 1, x1) + 1):
            c = cv.im.getpixel((x, y))
            if c[3]:
                cv.im.putpixel((x, y), shade(c, f))


# ---------------------------------------------------------------- textures
def shingle_tex(w, h, base, seed, rows=4, tile=8):
    """Rows of overlapping, round-bottomed shingles: lit top edge, shadowed lower edge, soft joints, tone variation."""
    cv = Cv(w, h)
    rng = random.Random(seed)
    b = hx(base)
    for ry in range(0, h + rows, rows):
        off = ((ry // rows) % 2) * (tile // 2)
        for x in range(-off, w, tile):
            c = shade(b, rng.choice([0.93, 1.0, 1.0, 1.07]))
            gap = dark(c, .34)
            for yy in range(rows):
                col = light(c, .22) if yy == 0 else (dark(c, .3) if yy == rows - 1 else c)
                cv.hline(max(x, 0), min(x + tile - 1, w - 1), ry + yy, col)
            for yy in range(rows - 1):
                cv.px(x, ry + yy, dark(c, .2))                           # joint between neighbouring shingles
            cv.px(x, ry + rows - 1, gap)                                   # round the lower corners
            cv.px(x + tile - 1, ry + rows - 1, gap)
            cv.px(x + tile - 1, ry + rows - 2, dark(c, .12))
    for x in range(w):                                                  # light bands (light from the top-left)
        f = 1.05 if x < w * 0.33 else (1.0 if x < w * 0.72 else 0.93)
        if f != 1.0:
            for y in range(h):
                c = cv.im.getpixel((x, y))
                cv.im.putpixel((x, y), shade(c, f))
    return cv


def clapboard_tex(w, h, base, seed, bh=4):
    cv = Cv(w, h)
    rng = random.Random(seed)
    b = hx(base)
    for y0 in range(0, h, bh):
        c = shade(b, rng.choice([0.97, 1.0, 1.03]))
        cv.rect(0, y0, w - 1, y0 + bh - 1, c)
        cv.hline(0, w - 1, y0, light(c, .14))
        cv.hline(0, w - 1, y0 + bh - 1, dark(c, .3))
        for _ in range(w // 30 + 1):                                    # butt joints / nail heads
            cv.px(rng.randint(2, w - 3), y0 + 1, dark(c, .16))
    return cv


def log_tex(w, h, base, seed, lh=5):
    cv = Cv(w, h)
    rng = random.Random(seed)
    b = hx(base)
    for y0 in range(0, h, lh):
        c = shade(b, rng.choice([0.95, 1.0, 1.05]))
        cv.rect(0, y0, w - 1, y0 + lh - 1, c)
        cv.hline(0, w - 1, y0, light(c, .2))
        cv.hline(0, w - 1, y0 + 1, light(c, .08))
        cv.hline(0, w - 1, y0 + lh - 2, dark(c, .16))
        cv.hline(0, w - 1, y0 + lh - 1, dark(c, .36))
        for _ in range(w // 14):                                        # grain flecks
            x = rng.randint(1, w - 4)
            cv.hline(x, x + rng.randint(1, 3), y0 + rng.randint(1, lh - 3), dark(c, .12))
    return cv


def plaster_tex(w, h, base, seed):
    cv = Cv(w, h)
    rng = random.Random(seed)
    b = hx(base)
    cv.rect(0, 0, w - 1, h - 1, b)
    for _ in range(w * h // 14):
        cv.px(rng.randint(0, w - 1), rng.randint(0, h - 1), light(b, .12) if rng.random() < .5 else shade(b, .95))
    return cv


def stone_tex(w, h, seed):
    cv = Cv(w, h)
    rng = random.Random(seed)
    mortar = hx('#6f7380')
    cv.rect(0, 0, w - 1, h - 1, mortar)
    x = 0
    while x < w:
        sw = rng.randint(5, 9)
        x0, x1 = x + 1, min(w - 1, x + sw - 1)
        c = shade(hx('#9a9eaa'), rng.choice([0.92, 1.0, 1.06]))
        if x1 >= x0:
            cv.rect(x0, 0, x1, h - 2, c)
            cv.hline(x0, x1, 0, light(c, .3))
            cv.hline(x0, x1, h - 2, dark(c, .2))
            cv.px(x0, 0, mortar)
            cv.px(x1, 0, mortar)                                        # rounded corners
        x += sw
    return cv


# ---------------------------------------------------------------- structure
def paint_walls(cv, g, a):
    style = a['wall_style']
    top = g.eave - 3                                                     # the first rows hide under the roof
    h = g.H - top
    if style == 'log':
        tex = log_tex(g.W - 4, h, a['wall'][0], a['seed'] + 'w')
    elif style == 'plaster':
        tex = plaster_tex(g.W - 4, h, a['wall'][0], a['seed'] + 'w')
    else:
        tex = clapboard_tex(g.W - 4, h, a['wall'][0], a['seed'] + 'w')
    cv.paste(tex, 2, top)
    if a['base']:
        cv.paste(stone_tex(g.W - 4, 5, a['seed'] + 'b'), 2, g.found)
    t = hx(a['trim'])
    if style == 'log':                                                   # protruding log ends at both corners
        lh = 5
        for i, y in enumerate(range(top, g.found, lh)):
            c = shade(hx(a['wall'][0]), 1.0 + 0.04 * ((i % 3) - 1))
            stagger = 1 if i % 2 else 0
            cv.rect(stagger, y, 2, y + lh - 2, light(c, .12))
            cv.rect(g.W - 3, y, g.W - 1 - stagger, y + lh - 2, light(c, .12))
            for x0 in (stagger, g.W - 3):
                cv.px(x0 + 1, y + 1, dark(c, .3))
            cv.hline(stagger, 2, y + lh - 1, dark(c, .4))
            cv.hline(g.W - 3, g.W - 1 - stagger, y + lh - 1, dark(c, .4))
    else:
        for x0 in (2, g.W - 4):                                          # corner boards
            cv.rect(x0, top, x0 + 1, g.found - 1, t)
            cv.vline(x0, top, g.found - 1, light(t, .25))
            cv.vline(x0 + 1, top, g.found - 1, shade(t, .82))
    shadow_y = g.eave + 1
    if style == 'plaster':                                               # half-timber: beam under the eave, plinth beam
        tc = hx(a['timber'] or '#7a4e2c')
        cv.rect(2, g.eave + 1, g.W - 3, g.eave + 2, tc)
        cv.hline(2, g.W - 3, g.eave + 1, light(tc, .2))
        cv.rect(2, g.found - 2, g.W - 3, g.found - 1, tc)
        for x0 in (2, g.W - 4):
            cv.rect(x0, top, x0 + 1, g.found - 1, tc)
            cv.vline(x0, top, g.found - 1, light(tc, .2))
        shadow_y = g.eave + 3
    for k, f in enumerate((0.58, 0.72, 0.86)):                           # eave shadow cast on the wall
        darken(cv, 2, shadow_y + k, g.W - 3, shadow_y + k, f)


def paint_roof(cv, g, a):
    base = a['roof'][0]
    paste_poly(cv, shingle_tex(g.W, g.H, base, a['seed'] + 'r'), g.roof_poly())
    b = hx(base)
    cv.hline(g.inset, g.W - 1 - g.inset, g.top, light(b, .55))           # ridge cap
    cv.hline(g.inset, g.W - 1 - g.inset, g.top + 1, light(b, .3))
    for y in range(g.top, g.eave):                                       # hip lines: lit on the left, shaded on the right
        xl = g.edge_x(y)
        xr = g.W - 1 - xl
        cv.px(xl, y, light(b, .38))
        cv.px(xl + 1, y, light(b, .16))
        cv.px(xr, y, dark(b, .4))
        cv.px(xr - 1, y, dark(b, .2))
    cv.hline(0, g.W - 1, g.eave - 2, dark(b, .22))                       # drip edge
    cv.hline(0, g.W - 1, g.eave - 1, dark(b, .42))
    cv.hline(0, g.W - 1, g.eave, dark(hx(a['roof'][1]), .5))


# ---------------------------------------------------------------- openings
def paint_window(cv, x, y, w, h, trim, shutter=None, box=False, curtains=None, rng=None):
    t = hx(trim)
    cv.rect(x - 1, y - 1, x + w, y + h, dark(t, .5))                     # recess shadow
    cv.rect(x, y, x + w - 1, y + h - 1, t)
    gx0, gy0, gx1, gy1 = x + 1, y + 1, x + w - 2, y + h - 2
    for yy in range(gy0, gy1 + 1):
        cv.hline(gx0, gx1, yy, mix(GLASS_TOP, GLASS_BOT, (yy - gy0) / float(max(1, gy1 - gy0))))
    cx, cy = x + w // 2, y + h // 2
    cv.vline(cx, gy0, gy1, t)
    cv.hline(gx0, gx1, cy, t)
    for (dx, dy) in ((1, 1), (2, 1), (1, 2)):
        cv.px(gx0 + dx, gy0 + dy, WHITE)                                 # glint
    if curtains:
        c = hx(curtains)
        for (ax, step) in ((gx0, 1), (gx1, -1)):
            cv.px(ax, gy0, c)
            cv.px(ax + step, gy0, c)
            cv.px(ax, gy0 + 1, shade(c, .85))
            cv.px(ax + step, gy0 + 1, shade(c, .85))
            cv.px(ax, gy0 + 2, shade(c, .8))
    cv.rect(x - 2, y + h, x + w + 1, y + h + 1, light(t, .1))            # sill
    cv.hline(x - 2, x + w + 1, y + h + 2, shade(t, .55))
    if shutter:
        s = hx(shutter)
        for sx in (x - 3, x + w + 1):
            cv.rect(sx, y - 1, sx + 1, y + h, s)
            cv.vline(sx, y - 1, y + h, light(s, .2))
            for k in range(1, h, 3):
                cv.hline(sx, sx + 1, y + k, dark(s, .3))
    if box:
        r = rng or random.Random(x * 7 + y)
        cv.rect(x - 2, y + h + 2, x + w + 1, y + h + 4, hx('#8a5a2e'))
        cv.hline(x - 2, x + w + 1, y + h + 2, hx('#b8823e'))
        cv.hline(x - 2, x + w + 1, y + h + 4, hx('#5e3c1e'))
        for i in range(x - 1, x + w + 1, 2):
            cv.px(i, y + h + 1, hx(r.choice(['#ff7a9a', '#ffd23a', '#fff0f4', '#c070ff', '#ff9a4a'])))
            cv.px(i + 1, y + h + 1, hx('#4a9a3a'))


def paint_door(cv, g, col, color, trim, style='panel', glass=False):
    x0, y0 = col * 16 + 1, g.door_top
    t, d = hx(trim), hx(color)
    cv.rect(x0 - 1, y0 - 2, x0 + DOOR_W, g.H - 1, t)
    cv.vline(x0 - 1, y0 - 2, g.H - 1, light(t, .2))
    cv.vline(x0 + DOOR_W, y0 - 2, g.H - 1, shade(t, .8))
    cv.rect(x0, y0, x0 + DOOR_W - 1, g.H - 1, d)
    if style == 'plank':
        for k in range(4):
            cv.vline(x0 + 1 + k * 3, y0, g.H - 1, light(d, .1))
            cv.vline(x0 + 3 + k * 3, y0, g.H - 1, dark(d, .3))
        for yy in (y0 + 4, g.H - 7):                                      # iron straps with rivets
            cv.rect(x0, yy, x0 + DOOR_W - 1, yy + 1, hx('#3a3a48'))
            cv.px(x0 + 1, yy, hx('#6a6a78'))
            cv.px(x0 + DOOR_W - 2, yy, hx('#6a6a78'))
        cv.px(x0 + DOOR_W - 4, y0 + 13, hx('#f2c548'))
        cv.px(x0 + DOOR_W - 4, y0 + 14, hx('#b88a28'))
    else:
        top_y = y0 + 2 + (7 if glass else 0)
        if glass:
            cv.rect(x0 + 2, y0 + 2, x0 + DOOR_W - 3, y0 + 7, t)
            cv.rect(x0 + 3, y0 + 3, x0 + DOOR_W - 4, y0 + 6, GLASS_TOP)
            cv.hline(x0 + 3, x0 + DOOR_W - 4, y0 + 6, GLASS_BOT)
            cv.px(x0 + 3, y0 + 3, WHITE)
        for (a0, a1) in ((x0 + 2, x0 + 5), (x0 + 8, x0 + 11)):
            cv.rect(a0, top_y, a1, y0 + 11, shade(d, .84))
            cv.hline(a0, a1, top_y, dark(d, .3))
            cv.vline(a0, top_y, y0 + 11, dark(d, .3))
            cv.rect(a0, y0 + 13, a1, g.H - 4, shade(d, .9))
            cv.hline(a0, a1, y0 + 13, dark(d, .3))
            cv.vline(a0, y0 + 13, g.H - 4, dark(d, .3))
        cv.vline(x0 + 6, y0, g.H - 1, dark(d, .3))
        cv.vline(x0 + 7, y0, g.H - 1, dark(d, .5))
        cv.px(x0 + 5, y0 + 12, hx('#ffd23a'))
        cv.px(x0 + 8, y0 + 12, hx('#ffd23a'))
    xs0, xs1 = x0 - 2, x0 + DOOR_W + 1                                   # stone step
    cv.rect(xs0, g.H - 3, xs1, g.H - 1, hx('#b4b8c4'))
    cv.hline(xs0, xs1, g.H - 3, hx('#dfe2ea'))
    cv.hline(xs0, xs1, g.H - 1, hx('#8a8e9a'))


def paint_hood(cv, g, col, a, wide=8):
    """Shed roof over the door, carried by two posts (the cottage porch)."""
    cx = col * 16 + 8
    x0, x1 = cx - DOOR_W // 2 - wide, cx + DOOR_W // 2 + wide
    y1 = g.door_top - 3
    y0 = y1 - 7
    paste_poly(cv, shingle_tex(g.W, g.H, a['roof'][0], a['seed'] + 'h'), [(x0 + 3, y0), (x1 - 3, y0), (x1, y1), (x0, y1)])
    b = hx(a['roof'][0])
    cv.hline(x0 + 3, x1 - 3, y0, light(b, .5))
    cv.hline(x0, x1, y1, dark(b, .5))
    cv.hline(x0, x1, y1 + 1, dark(hx(a['roof'][1]), .55))
    cv.hline(x0 + 1, x1 - 1, y1 + 2, shade(hx(a['wall'][0]), .6))
    t = hx(a['trim'])
    for px_ in (x0 + 2, x1 - 3):
        cv.rect(px_, y1 + 2, px_ + 1, g.H - 4, t)
        cv.vline(px_, y1 + 2, g.H - 4, light(t, .3))
        cv.vline(px_ + 1, y1 + 2, g.H - 4, shade(t, .78))
        cv.rect(px_ - 1, g.H - 4, px_ + 2, g.H - 3, hx('#9a9eaa'))


def paint_portico(cv, g, col, a):
    """Gabled entrance on two columns (the grand farmhouse)."""
    cx = col * 16 + 8
    x0, x1 = cx - 15, cx + 15
    base_y = g.door_top - 3
    apex = (cx, base_y - 13)
    t = hx(a['trim'])
    r0, r1 = hx(a['roof'][0]), hx(a['roof'][1])
    cv.poly([(x0 - 1, base_y), (x1 + 1, base_y), apex], dark(t, .08))
    cv.poly([(x0 + 2, base_y - 1), (x1 - 2, base_y - 1), (cx, apex[1] + 4)], hx(a['wall'][0]))      # gable infill
    cv.line(x0 - 1, base_y, apex[0], apex[1], r1)
    cv.line(x1 + 1, base_y, apex[0], apex[1], dark(r1, .3))
    cv.line(x0, base_y - 1, apex[0], apex[1] + 1, r0)
    cv.line(x1, base_y - 1, apex[0], apex[1] + 1, shade(r0, .85))
    cv.line(x0 + 1, base_y - 2, apex[0], apex[1] + 2, light(r0, .25))
    cv.ell(cx - 2, base_y - 8, cx + 2, base_y - 4, t)                                                 # round vent
    cv.px(cx, base_y - 6, hx('#7ab8d8'))
    cv.px(cx - 1, base_y - 6, hx('#a8dcf0'))
    cv.rect(x0, base_y, x1, base_y + 2, t)
    cv.hline(x0, x1, base_y, light(t, .3))
    cv.hline(x0, x1, base_y + 2, shade(t, .7))
    for px_ in (x0 + 1, x1 - 3):
        cv.rect(px_, base_y + 3, px_ + 2, g.H - 5, t)
        cv.vline(px_, base_y + 3, g.H - 5, light(t, .35))
        cv.vline(px_ + 2, base_y + 3, g.H - 5, shade(t, .72))
        cv.rect(px_ - 1, base_y + 3, px_ + 3, base_y + 4, light(t, .1))
        cv.rect(px_ - 1, g.H - 5, px_ + 3, g.H - 4, hx('#9a9eaa'))
        cv.rect(px_ - 1, g.H - 4, px_ + 3, g.H - 3, hx('#7a7e8a'))


def paint_awning(cv, g, cols):
    a1, a2 = hx(cols[0]), hx(cols[1])
    y0 = g.eave + 1
    for i in range(g.wt * 4):
        c = a1 if i % 2 == 0 else a2
        x = 2 + i * 4
        cv.rect(x, y0, x + 3, y0 + 8, c)
        cv.hline(x, x + 3, y0, light(c, .3))
        cv.hline(x + 1, x + 2, y0 + 9, c)                                # scalloped lower edge
    cv.hline(2, g.W - 3, y0 + 8, shade(a1, .7))
    darken(cv, 2, y0 + 10, g.W - 3, y0 + 10, .7)


# ---------------------------------------------------------------- roofline
def paint_chimney(cv, g, cx, kind='brick', bottom=None):
    """A chimney standing on the front slope: bricks / stones, lit left edge, stone cap, flashing at the foot."""
    w = 8
    x0 = cx - w // 2
    y_bot = bottom if bottom is not None else g.top + 14
    if kind == 'stone':
        main, mortar = hx('#9a9eaa'), hx('#6a6e7a')
    elif kind == 'iron':
        main, mortar = hx('#6a6e7a'), hx('#454854')
    else:
        main, mortar = hx('#b0553c'), hx('#7c3a28')
    for y in range(3, y_bot + 1):
        r = y // 3
        cv.hline(x0, x0 + w - 1, y, shade(main, 1.0 + 0.05 * (((r * 5 + y // 3) % 3) - 1)))
    for y in range(3, y_bot, 3):
        if y + 2 <= y_bot:
            cv.hline(x0, x0 + w - 1, y + 2, mortar)
        off = ((y // 3) % 2) * 4
        for x in range(x0 + off, x0 + w, 8):
            cv.vline(x, y, y + 1, mortar)
    cv.vline(x0, 3, y_bot, light(main, .3))
    cv.vline(x0 + w - 1, 3, y_bot, dark(main, .35))
    cv.vline(x0 + w - 2, 3, y_bot, dark(main, .15))
    cv.rect(x0 - 1, 0, x0 + w, 2, hx('#a2a6b1'))                         # cap
    cv.hline(x0 - 1, x0 + w, 0, hx('#d4d8e2'))
    cv.hline(x0 - 1, x0 + w, 2, hx('#6a6e7a'))
    cv.hline(x0 + 1, x0 + w - 2, 1, hx('#2a2530'))                        # flue
    cv.hline(x0 - 1, x0 + w, y_bot, hx('#5a5e6a'))                        # flashing
    cv.hline(x0, x0 + w - 1, y_bot + 1, hx('#3a3a48'))


def paint_dormer(cv, g, cx, base_y, a):
    """Gabled dormer window standing on the roof: wall + window below, small shingled gable above."""
    w, wh = 14, 9
    x0 = cx - w // 2
    wallc, t = hx(a['wall'][0]), hx(a['trim'])
    rc = hx(a['roof'][0])
    cv.rect(x0, base_y - wh, x0 + w - 1, base_y, wallc)
    cv.hline(x0, x0 + w - 1, base_y, dark(wallc, .3))
    cv.vline(x0, base_y - wh, base_y, t)
    cv.vline(x0 + w - 1, base_y - wh, base_y, shade(t, .8))
    paint_window(cv, cx - 3, base_y - wh + 2, 7, 6, a['trim'])
    apex = (cx, base_y - wh - 8)
    cv.poly([(x0 - 2, base_y - wh), (x0 + w + 1, base_y - wh), apex], shade(rc, 1.04))
    cv.poly([(x0 + 1, base_y - wh - 1), (x0 + w - 2, base_y - wh - 1), (cx, apex[1] + 3)], shade(rc, .92))
    cv.line(x0 - 2, base_y - wh, apex[0], apex[1], light(rc, .4))
    cv.line(x0 + w + 1, base_y - wh, apex[0], apex[1], dark(rc, .45))
    cv.hline(x0 - 2, x0 + w + 1, base_y - wh, dark(hx(a['roof'][1]), .4))
    cv.hline(x0 - 1, x0 + w, base_y - wh + 1, shade(wallc, .6))


# ---------------------------------------------------------------- details
def wall_lantern(cv, x, y):
    cv.vline(x + 1, y - 2, y - 1, hx('#3a3a48'))
    cv.rect(x, y, x + 2, y + 4, hx('#ffe08a'))
    cv.vline(x + 1, y + 1, y + 2, hx('#fff6d0'))
    cv.hline(x, x + 2, y - 1, hx('#3a3a48'))
    cv.hline(x, x + 2, y + 5, hx('#3a3a48'))


def pot(cv, x, y, flower='#ff7a9a'):
    cv.rect(x, y - 4, x + 4, y, hx('#c4664a'))
    cv.hline(x - 1, x + 5, y - 5, hx('#e0805a'))
    cv.hline(x, x + 4, y, hx('#8a3a2a'))
    cv.vline(x + 4, y - 4, y - 1, hx('#a4503a'))
    cv.ell(x - 1, y - 11, x + 5, y - 5, hx('#4a9a3a'))
    cv.px(x + 1, y - 8, hx(flower))
    cv.px(x + 3, y - 10, hx(flower))
    cv.px(x + 4, y - 7, hx('#fff0f4'))


def firewood(cv, x, y):
    for row, n in enumerate((3, 2)):
        for i in range(n):
            lx, ly = x + i * 4 + (2 if row else 0), y - 4 - row * 4
            cv.rect(lx, ly, lx + 3, ly + 3, hx('#a8703a'))
            cv.ell(lx, ly, lx + 3, ly + 3, hx('#c28f56'))
            cv.px(lx + 1, ly + 1, hx('#8a5a2e'))
    cv.hline(x - 1, x + 12, y, hx('#5e3c1e'))


def vine(cv, x, y0, y1, seed):
    rng = random.Random(seed)
    for y in range(y0, y1):
        if rng.random() < .8:
            cv.px(x + rng.randint(-1, 1), y, hx(rng.choice(['#3f8a3a', '#4a9a3a', '#5ab04a'])))
        if rng.random() < .25:
            cv.px(x + rng.choice([-2, 2]), y, hx('#ff9ec0'))


def sign_plaque(cv, kind, cx, y):
    cv.rect(cx - 7, y - 1, cx + 7, y + 9, hx('#5e3c1e'))
    cv.rect(cx - 6, y, cx + 6, y + 8, hx('#e8d4a0'))
    cv.hline(cx - 6, cx + 6, y, hx('#f6e8c0'))
    if kind == 'coin':
        cv.ell(cx - 3, y + 1, cx + 3, y + 7, hx('#d8a82a'))
        cv.ell(cx - 2, y + 2, cx + 2, y + 6, hx('#ffd23a'))
    elif kind == 'anvil':
        cv.rect(cx - 4, y + 2, cx + 4, y + 4, hx('#4a4a58'))
        cv.rect(cx - 2, y + 5, cx + 2, y + 7, hx('#3a3a48'))
        cv.px(cx + 5, y + 3, hx('#4a4a58'))
    elif kind == 'leaf':
        cv.ell(cx - 4, y + 1, cx + 4, y + 7, hx('#5ab04a'))
        cv.line(cx - 3, y + 6, cx + 3, y + 2, hx('#2a7a2e'))
    elif kind == 'fish':
        cv.ell(cx - 4, y + 2, cx + 3, y + 6, hx('#4a86c6'))
        cv.poly([(cx + 3, y + 4), (cx + 6, y + 1), (cx + 6, y + 7)], hx('#4a86c6'))
        cv.px(cx - 2, y + 3, WHITE)
    elif kind == 'cow':
        cv.rect(cx - 4, y + 2, cx + 3, y + 5, hx('#f4f1ea'))
        cv.rect(cx - 2, y + 3, cx, y + 4, hx('#3a3640'))
        cv.vline(cx - 3, y + 5, y + 7, hx('#3a3640'))
        cv.vline(cx + 2, y + 5, y + 7, hx('#3a3640'))
    elif kind == 'lantern':
        cv.rect(cx - 2, y + 1, cx + 2, y + 7, hx('#ffd23a'))
        cv.rect(cx - 1, y + 2, cx + 1, y + 6, hx('#fff6c8'))
        cv.hline(cx - 3, cx + 3, y, hx('#3a3a48'))


# ---------------------------------------------------------------- the house
def lantern_spot(wt, doorcol, entry, spans):
    """x for a 3px wall lantern beside the door, or None when no clear wall is left (small houses)."""
    dcx = doorcol * 16 + 8
    if entry != 'step':                                                  # between the door frame and the porch post
        return dcx + 9 if doorcol < wt - 1 else dcx - 11
    right = [a for a, b in spans if a > dcx + 7]
    if right and min(right) - (dcx + 8) >= 5:
        return dcx + 8 + (min(right) - (dcx + 8) - 3) // 2
    left = [b for a, b in spans if b < dcx - 8]
    if left and (dcx - 8) - max(left) >= 5:
        return dcx - 8 - ((dcx - 8) - max(left) + 3) // 2
    return None


def window_centres(wt, doorcol):
    if wt >= 5 and doorcol == 2:
        return [14, 66]                                                  # a symmetric pair around the door
    return [c * 16 + 8 for c in range(wt) if c != doorcol]


def house(wt, ht, wall=('#e6d2a4', '#cdb27c'), roof=('#b8503a', '#8a3a2a'), trim='#fff4e0', door_color='#8a4a2a', doorcol=1,
          wall_style='clapboard', timber=None, door_style='panel', door_glass=False, shutters=None, flowerbox=True, curtains=None,
          chimneys=(), entry='step', awning_cols=None, sign=None, lantern=True, base=True, dormers=(), details=(),
          roof_extra=12, ridge=0.2, tall_roof=0, seed='h'):
    """wall/roof = (main, dark) colours.  chimneys = [(x, kind, bottom_y|None)], dormers = [(x, base_y)],
    entry = 'step' | 'hood' | 'portico', details = [callable(cv, geo)]."""
    g = Geo(wt, ht, roof_extra, tall_roof, ridge)
    cv = Cv(g.W, g.H)
    a = dict(wall=wall, roof=roof, trim=trim, wall_style=wall_style, timber=timber, base=base, seed=seed)
    paint_walls(cv, g, a)
    paint_door(cv, g, doorcol, door_color, trim, door_style, door_glass)
    ww, wh = (11, 13) if wt >= 4 else (9, 9)
    wy = min(g.eave + (14 if awning_cols else 5), g.found - wh - 5)
    box = flowerbox and not awning_cols and wy + wh + 4 < g.found
    spans = []
    for i, cx in enumerate(window_centres(wt, doorcol)):
        paint_window(cv, cx - ww // 2, wy, ww, wh, trim, shutter=shutters, box=box, curtains=curtains, rng=random.Random(seed + str(i)))
        reach = ww // 2 + (3 if shutters else 1)
        spans.append((cx - reach, cx + reach))
    if awning_cols:
        paint_awning(cv, g, awning_cols)
    paint_roof(cv, g, a)
    for (cx, by) in dormers:
        paint_dormer(cv, g, cx, by, a)
    if entry == 'hood':
        paint_hood(cv, g, doorcol, a, wide=8 if wt >= 5 else 4)
    elif entry == 'portico':
        paint_portico(cv, g, doorcol, a)
    for (cx, kind, bottom) in chimneys:
        paint_chimney(cv, g, cx, kind, bottom)
    if lantern:
        lx = lantern_spot(wt, doorcol, entry, spans)
        if lx is not None:
            wall_lantern(cv, lx, g.door_top + 4)
    if sign:
        sign_plaque(cv, sign, doorcol * 16 + 8, g.door_top + (3 if awning_cols else 4))
    for d in details:
        d(cv, g)
    cv.outline()
    return cv
