"""Terrain art v2 - continuous fields instead of per-tile noise.

Grass, dirt, sand, cobblestone and water are drawn as one big *tileable* field (6x6 or 4x4 tiles) and cut into 16x16
tiles.  The renderer picks tile (x % N, y % N), so soft colour patches, ripples and cobbles flow across tile borders
and the 16px grid disappears.  Also here: the 47-case animated shoreline (bank + foam, rounded corners), deep-water
dither edges and soft grass fringes (grass overhanging dirt/path/sand with a gentle shadow on the ground).
"""
import math, random
import numpy as np
from PIL import Image
from .common import *

GRASS_N = 6          # grass field is GRASS_N x GRASS_N tiles
SOLID_N = 4          # dirt / sand / cobble fields
WATER_N = 4
WATER_FRAMES = 8     # water loops in 8 frames (cpp/game/render.cpp picks one from the clock)
SHORE_FRAMES = 4

GRASS = {
    'spring': dict(base='#7ac456', d1='#6bb44c', d2='#559f41', l1='#8cd466', l2='#aae07e', fl=['#ffffff', '#ffc2d8', '#fff08a', '#d8b8ff']),
    'summer': dict(base='#62b548', d1='#55a23f', d2='#418a34', l1='#74c653', l2='#90d86a', fl=['#fff08a', '#ffffff']),
    'autumn': dict(base='#b3ac4a', d1='#9f973f', d2='#837b34', l1='#c5bf5c', l2='#d6d173', fl=[]),
    'winter': dict(base='#e6f0f7', d1='#d3e3ef', d2='#b9d1e3', l1='#f3f9fd', l2='#ffffff', fl=[]),
}


# ---------------------------------------------------------------- tileable noise helpers
def pnoise(w, h, cell, rng):
    """Periodic value noise: w, h are multiples of `cell`, the result wraps seamlessly."""
    gx, gy = max(1, w // cell), max(1, h // cell)
    g = np.array([[rng.random() for _ in range(gx)] for _ in range(gy)])
    ys, xs = np.mgrid[0:h, 0:w]
    u, v = xs * gx / w, ys * gy / h
    x0, y0 = np.floor(u).astype(int), np.floor(v).astype(int)
    fx, fy = u - x0, v - y0
    fx, fy = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy)
    x0, y0, x1, y1 = x0 % gx, y0 % gy, (x0 + 1) % gx, (y0 + 1) % gy
    a = g[y0, x0] * (1 - fx) + g[y0, x1] * fx
    b = g[y1, x0] * (1 - fx) + g[y1, x1] * fx
    return a * (1 - fy) + b * fy


def fbm(w, h, rng, cells=(32, 16, 8), weights=(.5, .3, .2)):
    n = sum(wt * pnoise(w, h, c, rng) for c, wt in zip(cells, weights))
    return (n - n.min()) / (n.max() - n.min() + 1e-9)


def despeckle(lab, passes=2):
    """Remove 1px islands so colour patches read as clean clusters."""
    for _ in range(passes):
        up, dn, lf, rt = np.roll(lab, 1, 0), np.roll(lab, -1, 0), np.roll(lab, 1, 1), np.roll(lab, -1, 1)
        iso = (lab != up) & (lab != dn) & (lab != lf) & (lab != rt)
        lab = np.where(iso, up, lab)
    return lab


def scatter(rng, w, h, n, mind):
    pts, tries = [], 0
    while len(pts) < n and tries < n * 80:
        tries += 1
        x, y = rng.randrange(w), rng.randrange(h)
        if all(min(abs(x - px), w - abs(x - px)) ** 2 + min(abs(y - py), h - abs(y - py)) ** 2 >= mind * mind for px, py in pts):
            pts.append((x, y))
    return pts


class Field:
    """RGBA numpy canvas with wrap-around pixel writes."""

    def __init__(self, w, h):
        self.w, self.h = w, h
        self.a = np.zeros((h, w, 4), np.uint8)

    def put(self, x, y, c):
        self.a[y % self.h, x % self.w] = c

    def fill_labels(self, lab, pal):
        for k, c in pal.items():
            self.a[lab == k] = c

    def tiles(self, n):
        for ty in range(self.h // 16):
            for tx in range(self.w // 16):
                yield tx, ty, Cv(16, 16, Image.fromarray(self.a[ty * 16:ty * 16 + 16, tx * 16:tx * 16 + 16].copy(), 'RGBA'))


# ---------------------------------------------------------------- grass
def tuft(F, x, y, P, rng, big):
    d1, d2, l1, l2 = P['d1'], P['d2'], P['l1'], P['l2']
    lean = rng.choice([-1, 0, 0, 1])
    F.put(x, y, d2)
    F.put(x + lean, y - 1, l2)
    if big:
        F.put(x, y - 1, d1); F.put(x - 1, y, d1); F.put(x + 1, y, d1)
        F.put(x - 1, y - 1, l1); F.put(x + 1, y - 1, l1); F.put(x + lean, y - 2, l2)
    else:
        F.put(x + rng.choice([-1, 1]), y, d1)


def grass_field(season):
    P = {k: (hx(v) if isinstance(v, str) else [hx(c) for c in v]) for k, v in GRASS[season].items()}
    w = h = GRASS_N * 16
    rng = random.Random('gfield' + season)
    n = fbm(w, h, rng, (48, 24, 12, 6), (.34, .30, .22, .14))
    t1, t2 = np.percentile(n, [27, 76])
    lab = np.zeros((h, w), np.int8)
    lab[n < t1] = -1
    lab[n > t2] = 1
    lab = despeckle(lab, 3)
    F = Field(w, h)
    F.fill_labels(lab, {-1: P['d1'], 0: P['base'], 1: P['l1']})
    for (x, y) in scatter(rng, w, h, int(GRASS_N ** 2 * 1.5), 6):
        tuft(F, x, y, P, rng, rng.random() < 0.55)
    if season == 'spring':
        for (x, y) in scatter(rng, w, h, int(GRASS_N ** 2 * 0.40), 9):
            c = rng.choice(P['fl']); mid = hx('#f2c230') if c != hx('#fff08a') else hx('#f0a020')
            F.put(x, y, mid); F.put(x - 1, y, c); F.put(x + 1, y, c); F.put(x, y - 1, c); F.put(x, y + 1, P['d2']); F.put(x, y + 2, P['d2'])
    elif season == 'summer':
        for (x, y) in scatter(rng, w, h, int(GRASS_N ** 2 * 0.22), 10):
            F.put(x, y, hx('#f6c432')); F.put(x - 1, y, hx('#ffffff')); F.put(x + 1, y, hx('#ffffff')); F.put(x, y - 1, hx('#ffffff')); F.put(x, y + 1, hx('#e8e8f0')); F.put(x, y + 2, P['d2'])
    elif season == 'autumn':
        for (x, y) in scatter(rng, w, h, int(GRASS_N ** 2 * 0.9), 6):
            c = hx(rng.choice(['#d8782a', '#b8501e', '#e0a030', '#9a5a22']))
            F.put(x, y, c); F.put(x + 1, y, c); F.put(x + 1, y + 1, shade(c, .8))
    else:   # winter: sparkle + the odd frozen tuft poking out of the snow
        for (x, y) in scatter(rng, w, h, int(GRASS_N ** 2 * 1.2), 5):
            F.put(x, y, (255, 255, 255, 255)); F.put(x + 1, y, hx('#c9def0'))
        for (x, y) in scatter(rng, w, h, int(GRASS_N ** 2 * 0.25), 10):
            F.put(x, y, hx('#7a9a6a')); F.put(x, y - 1, hx('#92b080')); F.put(x + 1, y, hx('#6a8a5c'))
    return F


# ---------------------------------------------------------------- dirt
DIRT = {'spring': '#a8794d', 'summer': '#a67a4a', 'autumn': '#9a6e44', 'winter': '#a8928a'}


def dirt_field(season):
    base = hx(DIRT[season]); w = h = SOLID_N * 16
    rng = random.Random('dfield' + season)
    n = fbm(w, h, rng, (32, 16, 8), (.45, .35, .2))
    t1, t2 = np.percentile(n, [30, 80])
    lab = np.zeros((h, w), np.int8); lab[n < t1] = -1; lab[n > t2] = 1
    lab = despeckle(lab, 3)
    F = Field(w, h)
    F.fill_labels(lab, {-1: shade(base, .90), 0: base, 1: shade(base, 1.09)})
    for (x, y) in scatter(rng, w, h, 60, 4):
        F.put(x, y, shade(base, .80))
    for (x, y) in scatter(rng, w, h, 16, 8):          # pebbles: light top, shadow underneath
        F.put(x, y, shade(base, 1.28)); F.put(x + 1, y, shade(base, 1.16)); F.put(x, y + 1, shade(base, .70)); F.put(x + 1, y + 1, shade(base, .70))
    if season == 'winter':
        for (x, y) in scatter(rng, w, h, 40, 4): F.put(x, y, hx('#eaf2f8')); F.put(x + 1, y, hx('#d8e6f0'))
    return F


# ---------------------------------------------------------------- sand
def sand_field(season):
    base = hx('#ecd9a4'); w = h = SOLID_N * 16
    rng = random.Random('sfield' + season)
    warp = fbm(w, h, rng, (32, 16), (.6, .4))
    ys, xs = np.mgrid[0:h, 0:w]
    ripple = np.sin(2 * np.pi * (ys + 5 * warp) / 16.0)
    n = fbm(w, h, rng, (16, 8), (.6, .4))
    lab = np.zeros((h, w), np.int8)
    lab[ripple > 0.93] = -1; lab[(ripple < -0.95) & (n > .4)] = 1
    lab[n < .2] = -1
    lab = despeckle(lab, 2)
    F = Field(w, h)
    F.fill_labels(lab, {-1: hx('#dfcb92'), 0: base, 1: hx('#f6e9bf')})
    for (x, y) in scatter(rng, w, h, 34, 4): F.put(x, y, hx('#cdb57a'))
    for (x, y) in scatter(rng, w, h, 10, 9):
        F.put(x, y, hx('#fff6dc')); F.put(x + 1, y, hx('#e8d6a4')); F.put(x, y + 1, hx('#b89c62'))
    if season == 'winter':
        for (x, y) in scatter(rng, w, h, 30, 4): F.put(x, y, hx('#f4f8fb'))
    return F


# ---------------------------------------------------------------- cobblestone
def cobble_field(season):
    w = h = SOLID_N * 16
    rng = random.Random('cfield' + season)
    G = 8; cell = w / G
    seeds = [((i + .5) * cell + rng.uniform(-2.0, 2.0), (j + .5) * cell + rng.uniform(-2.0, 2.0)) for j in range(G) for i in range(G)]
    tones = [hx('#bfb39e'), hx('#b4a892'), hx('#c8bda8'), hx('#ab9f8a'), hx('#c2b6a0')]
    mortar = hx('#857965')
    ys, xs = np.mgrid[0:h, 0:w]
    px, py = xs + .5, ys + .5
    D = np.empty((len(seeds), h, w), np.float32)
    VX = np.empty_like(D); VY = np.empty_like(D)
    for k, (sx, sy) in enumerate(seeds):
        dx = px - sx; dx = (dx + w / 2) % w - w / 2
        dy = py - sy; dy = (dy + h / 2) % h - h / 2
        D[k] = np.hypot(dx, dy); VX[k], VY[k] = dx, dy
    order = np.argsort(D, axis=0)
    i1, i2 = order[0], order[1]
    d1 = np.take_along_axis(D, order[:1], 0)[0]; d2 = np.take_along_axis(D, order[1:2], 0)[0]
    vx = np.take_along_axis(VX, order[:1], 0)[0]; vy = np.take_along_axis(VY, order[:1], 0)[0]
    edge = d2 - d1
    F = Field(w, h)
    tone_of = [rng.choice(tones) for _ in seeds]
    for y in range(h):
        for x in range(w):
            c = tone_of[i1[y, x]]
            e = edge[y, x]
            if e < 1.25: col = mortar
            elif e < 2.9 and vx[y, x] + vy[y, x] < 0: col = light(c, .30)
            elif e < 2.9: col = shade(c, .82)
            else: col = c
            F.a[y, x] = col
    for (x, y) in scatter(rng, w, h, 30, 4):
        if F.a[y, x][0] != mortar[0]: F.put(x, y, shade(tuple(F.a[y, x]), .9))
    if season == 'winter':
        for y in range(h):
            for x in range(w):
                if edge[y, x] < 1.25 and rng.random() < .55: F.a[y, x] = hx('#e8f0f6')
        for (x, y) in scatter(rng, w, h, 26, 4): F.put(x, y, hx('#f6fafd')); F.put(x + 1, y, hx('#dce8f2'))
    elif season == 'autumn':
        for (x, y) in scatter(rng, w, h, 8, 9): F.put(x, y, hx('#d8782a')); F.put(x + 1, y, hx('#b8501e'))
    return F


# ---------------------------------------------------------------- water
WATER_PAL = {
    0: dict(base='#4aa5db', lo='#3f98d0', hi='#6bbfea', hi2='#b4e6fa'),
    1: dict(base='#2c74b4', lo='#2568a6', hi='#3f8ac8', hi2='#7fbfe8'),
}
_wthr = {}


def water_field(deep, frame):
    P = {k: hx(v) for k, v in WATER_PAL[deep].items()}
    w = h = WATER_N * 16
    rng = random.Random('wfield%d' % deep)
    nz = fbm(w, h, rng, (32, 16), (.6, .4))
    ys, xs = np.mgrid[0:h, 0:w]
    X, Y = xs / w, ys / h
    ph = 2 * math.pi * frame / WATER_FRAMES
    s = (.55 * np.sin(2 * np.pi * (1 * X + 5 * Y) + ph + 1.0) + .38 * np.sin(2 * np.pi * (2 * X - 3 * Y) - ph + 2.0)
         + .30 * np.sin(2 * np.pi * (3 * X + 8 * Y) + 2 * ph + .5) + .95 * (nz - .5))
    if deep not in _wthr:      # thresholds from frame 0 so that every frame uses the same cut-offs
        s0 = (.55 * np.sin(2 * np.pi * (1 * X + 5 * Y) + 1.0) + .38 * np.sin(2 * np.pi * (2 * X - 3 * Y) + 2.0)
              + .30 * np.sin(2 * np.pi * (3 * X + 8 * Y) + .5) + .95 * (nz - .5))
        _wthr[deep] = np.percentile(s0, [9, 86, 96.5]) if not deep else np.percentile(s0, [8, 90, 97.5])
    lo_t, hi_t, hi2_t = _wthr[deep]
    lab = np.zeros((h, w), np.int8)
    lab[s < lo_t] = -1; lab[s > hi_t] = 1; lab[s > hi2_t] = 2
    lab = despeckle(lab, 1)
    F = Field(w, h)
    F.fill_labels(lab, {-1: P['lo'], 0: P['base'], 1: P['hi'], 2: P['hi2']})
    srng = random.Random('wspark%d' % deep)
    for (x, y) in scatter(srng, w, h, 11 if not deep else 5, 8):      # twinkles: two frames each
        t0 = srng.randrange(WATER_FRAMES)
        d = (frame - t0) % WATER_FRAMES
        if d == 0: F.put(x, y, (255, 255, 255, 255))
        elif d == 1: F.put(x, y, P['hi2']); F.put(x - 1, y, P['hi']); F.put(x + 1, y, P['hi'])
    return F


# ---------------------------------------------------------------- shoreline autotile (47 cases)
BANK_DARK, BANK_MID = (50, 84, 62), (84, 126, 84)
N_, E_, S_, W_, NE_, SE_, SW_, NW_ = 1, 2, 4, 8, 16, 32, 64, 128


def normalize_mask(m):
    for d, (a, b) in ((NE_, (N_, E_)), (SE_, (S_, E_)), (SW_, (S_, W_)), (NW_, (N_, W_))):
        if m & (a | b): m &= ~d
    return m


def all_shore_masks():
    return sorted({normalize_mask(m) for m in range(256)} - {0})


def shore_sprite(mask, frame):
    """Bank (dark earth edge) + animated foam hugging the land, computed from a distance field so that corners round off."""
    land = np.zeros((48, 48), bool)
    def tile(tx, ty): land[ty * 16:ty * 16 + 16, tx * 16:tx * 16 + 16] = True
    if mask & N_: tile(1, 0)
    if mask & E_: tile(2, 1)
    if mask & S_: tile(1, 2)
    if mask & W_: tile(0, 1)
    if mask & NE_ or (mask & N_ and mask & E_): tile(2, 0)
    if mask & SE_ or (mask & S_ and mask & E_): tile(2, 2)
    if mask & SW_ or (mask & S_ and mask & W_): tile(0, 2)
    if mask & NW_ or (mask & N_ and mask & W_): tile(0, 0)
    # round the water's convex corners where two land sides meet (quarter-circle fill, radius 6)
    R = 6
    for (c, ox, oy, sx, sy) in ((N_ | W_, 0, 0, 1, 1), (N_ | E_, 15, 0, -1, 1), (S_ | W_, 0, 15, 1, -1), (S_ | E_, 15, 15, -1, -1)):
        if (mask & c) == c:
            for dy in range(R):
                for dx in range(R):
                    if math.hypot(dx + .5 - R, dy + .5 - R) > R:
                        land[16 + oy + sy * dy, 16 + ox + sx * dx] = True
    ys, xs = np.nonzero(land)
    cy, cx = np.mgrid[16:32, 16:32]
    dist = np.full((16, 16), 99.0)
    for ly, lx in zip(ys, xs):
        dist = np.minimum(dist, np.hypot(cx - lx, cy - ly))
    e = dist - .5
    rng = random.Random('foam%d' % mask)
    jit = (np.array([[rng.random() for _ in range(16)] for _ in range(16)]) - .5)
    cv = Cv(16, 16)
    ph = 2 * math.pi * frame / SHORE_FRAMES
    for y in range(16):
        for x in range(16):
            ee = e[y, x]
            if ee > 7: continue
            edge_out = 3.1 + .85 * math.sin(ph + .55 * (x + y)) + 1.1 * jit[y, x]
            if ee < 1.0: cv.px(x, y, BANK_DARK + (225,))
            elif ee < 2.0: cv.px(x, y, BANK_MID + (170,))
            elif ee < edge_out:
                a = 235 if ee < 2.7 else (170 if ee < edge_out - .6 else 95)
                cv.px(x, y, (240, 250, 255, a))
            elif ee < 6.0:
                cv.px(x, y, (24, 80, 120, int(46 * (1 - (ee - edge_out) / 3.0)) if ee - edge_out < 3.0 else 0))
    return cv


def deep_edge(direction):
    """Stepped gradient on a deep-water tile where it meets shallow water (shallow -> mid -> deep)."""
    cv = Cv(16, 16)
    mid = (62, 140, 200)
    for i in range(16):
        for d, a in enumerate([(mid + (205,)), (mid + (150,) if i % 2 == 0 else None), (mid + (95,) if i % 4 == 1 else None)]):
            if a is None: continue
            x, y = {'n': (i, d), 's': (i, 15 - d), 'w': (d, i), 'e': (15 - d, i)}[direction]
            cv.px(x, y, a)
    return cv


# ---------------------------------------------------------------- grass fringe (overhang onto dirt / path / sand)
def fringe(season, edge):
    g = {k: (hx(v) if isinstance(v, str) else v) for k, v in GRASS[season].items()}
    rng = random.Random('fr2%s%s' % (season, edge))
    shadow = (40, 24, 12, 70) if season != 'winter' else (90, 110, 130, 70)
    cv = Cv(16, 16)

    def put(a, b, c):    # a = along the edge, b = depth from the edge
        x, y = {'n': (a, b), 's': (a, 15 - b), 'w': (b, a), 'e': (15 - b, a)}[edge]
        cv.px(x, y, c)

    if len(edge) == 1:
        prof, cur = [], 2
        for x in range(16):
            cur = max(1, min(3, cur + rng.choice([-1, 0, 0, 1])))
            prof.append(cur)
        for a in range(16):
            dpt = prof[a] + (1 if a % 5 == 2 else 0)            # blade tips poke out here and there
            for b in range(dpt):
                if b == dpt - 1: c = g['d2'] if rng.random() < .6 else g['d1']
                elif b == dpt - 2 and dpt > 2: c = g['d1']
                else: c = g['l1'] if rng.random() < .22 else g['base']
                put(a, b, c)
            put(a, dpt, shadow)
            if prof[a] >= 3 and rng.random() < .5: put(a, dpt + 1, (shadow[0], shadow[1], shadow[2], 38))
    else:
        r = 5
        for b in range(r + 2):
            for a in range(r + 2):
                dd = math.hypot(a + .5, b + .5)
                x, y = (a if 'w' in edge else 15 - a), (b if 'n' in edge else 15 - b)
                if dd <= r - .4:
                    cv.px(x, y, g['d2'] if dd > r - 1.6 else (g['d1'] if dd > r - 2.4 else g['base']))
                elif dd <= r + .6:
                    cv.px(x, y, shadow)
    return cv


# ---------------------------------------------------------------- registration
def draw_terrain(W):
    for s in SEASONS:
        for tx, ty, cv in grass_field(s).tiles(GRASS_N): W.add('tg_%s_%d' % (s, ty * GRASS_N + tx), cv, 0, 0)
        for tx, ty, cv in dirt_field(s).tiles(SOLID_N): W.add('td_%s_%d' % (s, ty * SOLID_N + tx), cv, 0, 0)
        for tx, ty, cv in cobble_field(s).tiles(SOLID_N): W.add('tp_%s_%d' % (s, ty * SOLID_N + tx), cv, 0, 0)
        for tx, ty, cv in sand_field(s).tiles(SOLID_N): W.add('ts_%s_%d' % (s, ty * SOLID_N + tx), cv, 0, 0)
        for e in ['n', 'e', 's', 'w', 'ne', 'se', 'sw', 'nw']:
            W.add('fr_grass_%s_%s' % (s, e), fringe(s, e), 0, 0)
    for deep, nm in ((0, 'tw'), (1, 'tdw')):
        for f in range(WATER_FRAMES):
            for tx, ty, cv in water_field(deep, f).tiles(WATER_N): W.add('%s_%d_%d' % (nm, f, ty * WATER_N + tx), cv, 0, 0)
    for m in all_shore_masks():
        for f in range(SHORE_FRAMES):
            W.add('sh_%02x_%d' % (m, f), shore_sprite(m, f), 0, 0)
    for d in 'nesw':
        W.add('dp_' + d, deep_edge(d), 0, 0)
