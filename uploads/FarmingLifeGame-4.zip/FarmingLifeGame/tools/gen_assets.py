#!/usr/bin/env python3
"""Generates every original texture / map used by Thistledown Vale.
Run from anywhere:  python3 tools/gen_assets.py     (needs Pillow + numpy)
Outputs: assets/textures/atlas/{world,ui}.{png,atlas}, assets/maps/*.map, app/src/main/res/mipmap-*/ic_launcher.png
All art is procedural and original; replace any sprite by editing the atlas PNG or the generator functions."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image
from assetgen.common import *
from assetgen import tiles, objects, buildings, chars, items, ui, maps


def build_world(w, h):
    W = Packer('world', w, h)
    W.add('white', Cv(2, 2, Image.new('RGBA', (2, 2), (255, 255, 255, 255))), 0, 0)
    chk = Cv(16, 16)
    for y in range(16):
        for x in range(16):
            chk.px(x, y, (255, 0, 255, 255) if ((x // 4) + (y // 4)) % 2 == 0 else (30, 0, 30, 255))
    W.add('missing', chk, 8, 16)
    tiles.draw_tiles(W); objects.draw_objects(W); buildings.draw_buildings(W)
    chars.draw_characters(W); chars.draw_animals(W); items.draw_crops(W)
    return W


def launcher_icon(size):
    s = 64
    cv = Cv(s, s)
    for y in range(s):
        t = y / s
        cv.hline(0, s - 1, y, mix(hx('#ffd9a0'), hx('#8fd0f0'), 1 - min(1, t * 1.4)))
    cv.ell(40, 8, 58, 26, hx('#fff2b0')); cv.ell(43, 11, 55, 23, hx('#ffd84a'))
    cv.ell(-20, 38, 50, 90, hx('#6fbf55')); cv.ell(20, 44, 90, 96, hx('#58a845'))
    cv.ell(-6, 42, 30, 70, hx('#82cf62'))
    for x in range(0, s, 6): cv.vline(x + 2, 52, 63, hx('#3f8a3a')) if (x // 6) % 2 else None
    cv.rect(22, 30, 40, 44, hx('#e8d0a0')); cv.poly([(19, 31), (31, 19), (43, 31)], hx('#c0503a')); cv.rect(28, 36, 33, 44, hx('#7a4a2a')); cv.rect(24, 33, 26, 36, hx('#8fd0f0')); cv.rect(36, 33, 38, 36, hx('#8fd0f0'))
    cv.rect(36, 18, 39, 26, hx('#a8503a'))
    cv.outline(hx('#4a2f1c'))
    base = Image.new('RGBA', (s + 4, s + 4), (0, 0, 0, 0))
    bg = Image.new('RGBA', (s + 4, s + 4), (0, 0, 0, 0))
    mask = Image.new('L', (s + 4, s + 4), 0)
    from PIL import ImageDraw
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, s + 3, s + 3], radius=12, fill=255)
    bg.paste(hx('#3a2a1a'), (0, 0, s + 4, s + 4))
    out = Image.new('RGBA', (s + 4, s + 4), (0, 0, 0, 0)); out.paste(bg, (0, 0), mask)
    out.paste(cv.im, (2, 2), cv.im)
    return out.resize((size, size), Image.NEAREST if size % (s + 4) == 0 else Image.LANCZOS)


def main():
    rng = random.Random(7)
    atlas_dir = os.path.join(ROOT, 'assets', 'textures', 'atlas')
    os.makedirs(atlas_dir, exist_ok=True)
    W = U = None
    for (ww, wh) in [(1024, 1024), (2048, 1024)]:
        try:
            W = build_world(ww, wh)
            U = Packer('ui', 1024, 512)
            ui.draw_ui(U, rng); chars.draw_portraits(U); items.draw_item_icons(U, W)
            W.pack(); U.pack()
            break
        except OverflowError as e:
            print('retrying with a larger atlas:', e)
    W.write(os.path.join(atlas_dir, 'world.png'), os.path.join(atlas_dir, 'world.atlas'), 'textures/atlas/world.png')
    U.write(os.path.join(atlas_dir, 'ui.png'), os.path.join(atlas_dir, 'ui.atlas'), 'textures/atlas/ui.png')
    print('world atlas %dx%d: %d sprites, %d%% rows used' % (W.w, W.h, len(W.entries), 100 * W.used_h // W.h))
    print('ui atlas    %dx%d: %d sprites, %d%% rows used' % (U.w, U.h, len(U.entries), 100 * U.used_h // U.h))
    maps.write_all(os.path.join(ROOT, 'assets', 'maps'))
    res = os.path.join(ROOT, 'app', 'src', 'main', 'res')
    for d, sz in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
        os.makedirs(os.path.join(res, 'mipmap-' + d), exist_ok=True)
        launcher_icon(sz).save(os.path.join(res, 'mipmap-' + d, 'ic_launcher.png'))
    print('done')


if __name__ == '__main__':
    main()
