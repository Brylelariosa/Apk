# JNI entry points are looked up by name from native code.
-keep class com.cozyfarm.thistledown.NativeBridge { *; }
-keepclasseswithmembernames class * { native <methods>; }
-keep class com.cozyfarm.thistledown.MainActivity { *; }
