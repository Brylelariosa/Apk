package com.cozyfarm.thistledown;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;

/** GLSurfaceView that asks for an OpenGL ES 3.x context and falls back to 2.0; forwards touches to native code. */
final class GameSurfaceView extends GLSurfaceView {
    private static final int EGL_CONTEXT_CLIENT_VERSION = 0x3098;
    private final MainActivity activity;

    GameSurfaceView(MainActivity activity) {
        super(activity);
        this.activity = activity;
        setEGLContextClientVersion(2);
        setEGLContextFactory(new ContextFactory());
        setEGLConfigChooser(false);
        setPreserveEGLContextOnPause(true);
        setRenderer(new Renderer());
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    private static final class ContextFactory implements EGLContextFactory {
        @Override
        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig config) {
            int[] es3 = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL10.EGL_NONE};
            EGLContext ctx = egl.eglCreateContext(display, config, EGL10.EGL_NO_CONTEXT, es3);
            if (ctx == null || ctx == EGL10.EGL_NO_CONTEXT) {
                int[] es2 = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE};
                ctx = egl.eglCreateContext(display, config, EGL10.EGL_NO_CONTEXT, es2);
            }
            return ctx;
        }

        @Override
        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            egl.eglDestroyContext(display, context);
        }
    }

    private final class Renderer implements GLSurfaceView.Renderer {
        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            NativeBridge.nativeSurfaceCreated();
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            NativeBridge.nativeSurfaceChanged(width, height);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            NativeBridge.nativeFrame();
            int ms = NativeBridge.nativePollVibrate();
            if (ms > 0) activity.vibrate(ms);
            if (NativeBridge.nativeWantsExit()) activity.requestFinish();
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                NativeBridge.nativeTouch(0, e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    NativeBridge.nativeTouch(1, e.getPointerId(i), e.getX(i), e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                NativeBridge.nativeTouch(2, e.getPointerId(idx), e.getX(idx), e.getY(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    NativeBridge.nativeTouch(3, e.getPointerId(i), e.getX(i), e.getY(i));
                }
                break;
            default:
                break;
        }
        return true;
    }
}
