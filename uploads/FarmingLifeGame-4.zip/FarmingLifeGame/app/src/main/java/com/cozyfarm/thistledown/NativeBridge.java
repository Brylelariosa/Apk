package com.cozyfarm.thistledown;

import android.content.res.AssetManager;

/** JNI entry points. The whole game lives in native C++ (libthistledown.so); Java only hosts the window, input and audio output. */
final class NativeBridge {
    static {
        System.loadLibrary("thistledown");
    }

    private NativeBridge() {}

    static native void nativeInit(AssetManager assets, String dataDir, boolean debug, float density, float refreshHz);
    static native void nativeSurfaceCreated();
    static native void nativeSurfaceChanged(int width, int height);
    static native void nativeSetInsets(int left, int top, int right, int bottom);
    static native void nativeFrame();
    static native void nativeTouch(int type, int pointerId, float x, float y);
    static native void nativeBack();
    static native void nativePause();
    static native void nativeResume();
    static native int nativePollVibrate();
    static native boolean nativeWantsExit();
    static native void nativeFillAudio(short[] buffer, int frames);
}
