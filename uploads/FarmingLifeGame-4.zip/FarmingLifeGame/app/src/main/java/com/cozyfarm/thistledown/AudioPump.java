package com.cozyfarm.thistledown;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;

/** Streams PCM produced by the native software mixer into an AudioTrack (all synthesis happens in C++). */
final class AudioPump implements Runnable {
    private static final int RATE = 22050;
    private static final int FRAMES = 1024;
    private Thread thread;
    private volatile boolean running;

    synchronized void start() {
        if (running) return;
        running = true;
        thread = new Thread(this, "thistledown-audio");
        thread.setPriority(Thread.MAX_PRIORITY);
        thread.start();
    }

    synchronized void stop() {
        running = false;
        if (thread != null) {
            try {
                thread.join(800);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            thread = null;
        }
    }

    @Override
    public void run() {
        AudioTrack track = null;
        try {
            int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bytes = Math.max(min, FRAMES * 2 * 3);
            if (Build.VERSION.SDK_INT >= 23) {
                track = new AudioTrack.Builder()
                        .setAudioAttributes(new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build())
                        .setAudioFormat(new AudioFormat.Builder()
                                .setSampleRate(RATE)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .build())
                        .setBufferSizeInBytes(bytes)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build();
            } else {
                track = new AudioTrack(AudioManager.STREAM_MUSIC, RATE, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, bytes, AudioTrack.MODE_STREAM);
            }
            short[] buf = new short[FRAMES];
            track.play();
            while (running) {
                NativeBridge.nativeFillAudio(buf, FRAMES);
                track.write(buf, 0, FRAMES);
            }
        } catch (RuntimeException e) {
            // audio is optional: the game keeps running silently if the device refuses the stream
        } finally {
            if (track != null) {
                try {
                    track.stop();
                } catch (RuntimeException ignored) {
                    // already stopped
                }
                track.release();
            }
        }
    }
}
