package com.zipapkbuilder.feature.repo

import android.app.AlertDialog
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions

/**
 * The GitHub token currently in the token field, or — when it is empty — a "GitHub token needed"
 * popup saying why the action can't go on ([explanation]) and null. Every repo action starts
 * with this gate ([RepoSwitcher], [RepoCreator]), so it looks and reads the same wherever it
 * shows up. Main thread only: it may open a dialog.
 */
internal fun MainActivity.requireToken(explanation: String): String? {
    val token = etToken.text.toString().trim()
    if (token.isNotEmpty()) return token

    lateinit var dlg: AlertDialog
    val content = dialogWithActions(
        dialogMessage(explanation),
        DialogAction("OK", ButtonTone.PRIMARY, R.drawable.ic_check) { dlg.dismiss() }
    )
    dlg = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
        .setCustomTitle(dialogTitleBar("GitHub token needed", R.drawable.ic_key, ButtonTone.ORANGE) { dlg.dismiss() })
        .setView(content)
        .show()
    return null
}
