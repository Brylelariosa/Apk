package com.zipapkbuilder.core

/**
 * Groups log lines into fewer, bigger writes to the console. Every `appendLog` call becomes a
 * main-thread post that appends to — and re-lays-out — the console TextView, so a few hundred
 * one-line calls in a tight loop (one per extracted file) cost far more than the same text sent
 * in groups, and on a low-end phone that UI work is what the loop ends up waiting on.
 *
 * Not thread-safe: use one instance per producing thread, and call [flush] before logging
 * anything else from that thread so lines stay in order.
 */
class LogBatcher(
    private val sink: (String) -> Unit,
    private val batchSize: Int = 25
) {
    private val buffer = StringBuilder()
    private var pending = 0

    /** Queues [line]; sends the group once [batchSize] lines have piled up. */
    fun add(line: String) {
        if (pending > 0) buffer.append('\n')
        buffer.append(line)
        pending++
        if (pending >= batchSize) flush()
    }

    /** Sends whatever is queued, if anything. */
    fun flush() {
        if (pending == 0) return
        sink(buffer.toString())
        buffer.setLength(0)
        pending = 0
    }

    /** Sends [line] right away, after anything already queued — for status lines that must not wait. */
    fun now(line: String) {
        flush()
        sink(line)
    }
}
