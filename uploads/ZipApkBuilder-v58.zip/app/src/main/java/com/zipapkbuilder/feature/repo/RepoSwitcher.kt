package com.zipapkbuilder.feature.repo

import android.app.AlertDialog
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.dialogLoading
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions

/**
 * Lets the user switch which repo/branch the rest of the app targets, without
 * retyping it: [showSavedReposDialog] lists every repo the token can see (not
 * just ones used before — fetched live from GitHub, so it's never stale), and
 * [applySwitchRepo] resets every piece of per-repo session state (owner cache,
 * last build) so nothing from the previous repo leaks into the new one. The list's first row,
 * "New repository", opens [RepoCreator] — so creating a repo is reachable from every place that
 * can switch one (Settings, File manager, Artifacts).
 */
class RepoSwitcher(private val activity: MainActivity) {

    private companion object {
        /** Pages of 100 repos read for the picker (500 repos). */
        const val MAX_PAGES = 5
    }

    /** Switches the active repo/branch and clears all stale per-repo state. */
    fun applySwitchRepo(repo: String, branch: String, keepZip: Boolean = false) {
        activity.etRepo.setText(repo)
        activity.etBranch.setText(branch)
        activity.prefs.edit().putString(PrefKeys.PREF_REPO, repo).putString(PrefKeys.PREF_BRANCH, branch).apply()
        activity.lastOwner           = ""
        activity.lastRemotePath      = ""
        activity.lastFileSha         = null
        activity.lastRunId           = -1L
        activity.artifactDownloadUrl = null
        // selectedZipName is scoped to whatever repo/build session picked it — carrying it
        // over into a different repo was a real bug: it's used as the fallback name for a
        // downloaded build log whenever that specific run's own commit message doesn't carry
        // one (e.g. a workflow_dispatch-triggered run has no upload commit to read a name
        // from at all — see Formatters.extractZipNameFromRun), so a stale value here meant a
        // log downloaded from the *new* repo could still end up named after the *previous*
        // repo's last-picked ZIP.
        //
        // Until v57 only the name and the label were cleared and the picked file's Uri stayed
        // behind, so Upload & build right after a switch ran with an empty ZIP name. The whole
        // pick is cleared now. [keepZip] is for a brand-new repo (see RepoCreator): it has no
        // runs yet, so nothing stale can be named after the ZIP, and keeping the pick lets
        // "choose ZIP, create repo, Upload & build" work without choosing the ZIP twice.
        if (!keepZip) activity.clearSelectedZip()
        activity.buildFlowController.clearBuildState(activity.prefs)
        activity.mainHandler.post {
            activity.tvOwnerInfo.text = ""; activity.tvOwnerInfo.visibility = android.view.View.GONE
            activity.setStatus("Idle")
        }
        activity.appendLog("[ok] Switched to $repo @ $branch")
    }

    /**
     * Fetches all repos for the authenticated user from GitHub and shows a
     * picker. Tapping a repo immediately switches to it; the first row,
     * "New repository", opens [RepoCreator] instead. An account with no repos
     * still gets the picker (with just that row) rather than an error.
     */
    fun showSavedReposDialog() {
        val token = activity.requireToken("Enter your GitHub token first so your repositories can be fetched.")
            ?: return

        // Show a loading dialog while we fetch
        lateinit var loadingDlg: AlertDialog
        loadingDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Switch repository", R.drawable.ic_switch, ButtonTone.PRIMARY) { loadingDlg.dismiss() })
            .setView(activity.dialogLoading("Fetching your repositories…"))
            .setCancelable(true)
            .show()

        activity.bgExecutor.execute {
            try {
                // Repos the signed-in user owns, most recently updated first, up to
                // MAX_PAGES x 100. Collaborator and organisation repos are left out on purpose:
                // the rest of the app always uses the signed-in user as the owner, so picking
                // someone else's repo would have created a same-named repo on this account.
                val items = ArrayList<org.json.JSONObject>()
                var page = 1
                while (page <= MAX_PAGES) {
                    val url = "${GitHubApi.apiUserRepos()}?per_page=100&sort=updated&affiliation=owner&page=$page"
                    val (code, body) = GitHubApi.httpGet(token, url)
                    if (code != 200) {
                        if (page == 1) throw Exception("GitHub returned HTTP $code")
                        break
                    }
                    val arr = JSONArray(body)
                    for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
                    if (arr.length() < 100) break
                    page++
                }

                // Build display list
                data class RepoEntry(val fullName: String, val name: String, val defaultBranch: String, val private: Boolean)
                val repos = items.map { obj ->
                    RepoEntry(
                        fullName      = obj.getString("full_name"),
                        name          = obj.getString("name"),
                        defaultBranch = obj.optString("default_branch", "main"),
                        private       = obj.optBoolean("private", false)
                    )
                }
                val lockTint = 0xFFF5A623.toInt()
                val folderTint = 0xFF7C6BFF.toInt()
                // The first row is the way in to creating a repo (see RepoCreator); every row
                // after it is a repo, so a tapped position maps to repos[which - 1].
                val newRepoRow = IconMenuRow(
                    label = "New repository",
                    iconRes = R.drawable.ic_add,
                    iconTint = 0xFF2ECC71.toInt(),
                    subtitle = "Create one on GitHub and switch to it"
                )
                val rows = listOf(newRepoRow) + repos.map { r ->
                    IconMenuRow(
                        label = r.name,
                        iconRes = if (r.private) R.drawable.ic_lock else R.drawable.ic_folder,
                        iconTint = if (r.private) lockTint else folderTint,
                        subtitle = r.defaultBranch
                    )
                }

                activity.mainHandler.post {
                    // The fetch above can take a few seconds; if the user backed out of
                    // the app (or the Activity was otherwise torn down) in the meantime,
                    // don't touch loadingDlg or pop a new AlertDialog on a dead Activity.
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    loadingDlg.dismiss()
                    lateinit var dlgRepo: AlertDialog
                    dlgRepo = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setCustomTitle(activity.dialogTitleBar("Switch repository", R.drawable.ic_switch, ButtonTone.PRIMARY, subtitle = when (repos.size) {
                            0 -> "No repositories yet"
                            1 -> "1 repository"
                            else -> "${repos.size} repositories"
                        }) { dlgRepo.dismiss() })
                        .setAdapter(IconMenuAdapter(activity, rows)) { _, which ->
                            if (which == 0) {
                                activity.repoCreator.showCreateRepoDialog()
                            } else {
                                val picked = repos[which - 1]
                                applySwitchRepo(picked.name, picked.defaultBranch)
                            }
                        }
                        .show()
                    dlgRepo.listView?.setBackgroundColor(0xFF13162A.toInt())
                }
            } catch (e: Exception) {
                activity.mainHandler.post {
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    loadingDlg.dismiss()
                    lateinit var errDlg: AlertDialog
                    val content = activity.dialogWithActions(
                        activity.dialogMessage(e.message ?: "Unknown error"),
                        DialogAction("OK", ButtonTone.PRIMARY, R.drawable.ic_check) { errDlg.dismiss() }
                    )
                    errDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setCustomTitle(activity.dialogTitleBar("Could not fetch repositories", R.drawable.ic_warning, ButtonTone.RED) { errDlg.dismiss() })
                        .setView(content)
                        .show()
                }
            }
        }
    }
}
