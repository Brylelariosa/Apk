package com.zipapkbuilder.net

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Applies any number of file changes to one branch as a SINGLE commit through the Git Data API.
 *
 * Why not the Contents API: it commits one file per request, so changing 200 files is 200
 * sequential commits — and they cannot be parallelised either, because every commit moves the
 * branch tip and a concurrent write to the same branch is rejected. Building the tree ourselves
 * costs a fixed handful of requests however many files change:
 *
 *     read tip  →  (upload binary blobs, in parallel)  →  create tree  →  create commit  →  move ref
 *
 * Text files do not even need a blob request of their own: a tree entry may carry the file's text
 * inline ([Change.Text]) and GitHub writes the blob while creating the tree. Only binary files go
 * through [createBlob].
 *
 * Shared by [com.zipapkbuilder.feature.filemanager.ZipExtractController] (adds many files) and
 * [com.zipapkbuilder.feature.filemanager.FileOperationController] (removes many files), so the ref /
 * tree / commit plumbing exists once instead of once per feature.
 *
 * One instance per operation. [createBlob] may be called from several threads at once; every
 * request goes through [withRetry], and a rate-limit answer on any thread pauses all of them.
 *
 * [log] receives short `[retry]` notices — a long back-off with nothing on screen reads as a hang.
 */
class GitBatchCommit(
    private val token: String,
    private val owner: String,
    private val repo: String,
    private val branch: String,
    private val log: (String) -> Unit = {}
) {

    /** The branch tip commit and the root tree it points at. */
    data class Head(val commitSha: String, val treeSha: String)

    /** One file-like entry (blob, symlink or submodule) from a recursive tree listing. */
    data class TreeEntry(val path: String, val mode: String, val type: String)

    /** One path-level change applied on top of a base tree. */
    sealed class Change {
        abstract val path: String

        /** Rough request-size cost — only used to split a big batch into several tree requests. */
        abstract val weight: Int

        /** Create or overwrite [path] with UTF-8 [text]. GitHub stores the blob itself. */
        class Text(override val path: String, val text: String) : Change() {
            override val weight: Int get() = text.length + path.length + 64
        }

        /** Create or overwrite [path] with a blob already uploaded via [createBlob]. */
        class Blob(override val path: String, val sha: String) : Change() {
            override val weight: Int get() = path.length + 128
        }

        /** Remove the file at [path]. [mode]/[type] should be the entry's real ones (see [TreeEntry]). */
        class Delete(
            override val path: String,
            val mode: String = "100644",
            val type: String = "blob"
        ) : Change() {
            override val weight: Int get() = path.length + 128
        }
    }

    /** Epoch millis until which every thread sharing this instance holds off sending. */
    @Volatile private var pausedUntilMs = 0L

    // ── Reading ──────────────────────────────────────────────────────────────

    /** Reads the branch tip and the root tree it points at (fresh — never served from a cache). */
    fun readHead(): Head {
        val (refCode, refBody) = withRetry { GitHubApi.httpGet(token, GitHubApi.apiRefHeads(owner, repo, branch)) }
        if (refCode != 200) throw Exception("Could not read branch ref ($refCode)")
        val tipSha = JSONObject(refBody).getJSONObject("object").getString("sha")

        val (commitCode, commitBody) = withRetry { GitHubApi.httpGet(token, GitHubApi.apiCommit(owner, repo, tipSha)) }
        if (commitCode != 200) throw Exception("Could not read tip commit ($commitCode)")
        return Head(tipSha, JSONObject(commitBody).getJSONObject("tree").getString("sha"))
    }

    /**
     * Every file-like entry under [treeSha], all folders expanded, in ONE request — versus one
     * Contents-API listing per folder. Returns null when GitHub had to truncate the answer (past
     * ~100k entries / 7 MB): a partial list would silently skip files, so the caller has to take a
     * different route rather than act on it.
     */
    fun listEntries(treeSha: String): List<TreeEntry>? {
        val (code, body) = withRetry {
            GitHubApi.httpGet(token, GitHubApi.apiTree(owner, repo, treeSha, recursive = true))
        }
        if (code != 200) throw Exception("Could not list repository files ($code)")
        val json = JSONObject(body)
        if (json.optBoolean("truncated", false)) return null
        val arr = json.getJSONArray("tree")
        val out = ArrayList<TreeEntry>(arr.length())
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val type = e.getString("type")
            if (type != "tree") out.add(TreeEntry(e.getString("path"), e.getString("mode"), type))
        }
        return out
    }

    // ── Writing ──────────────────────────────────────────────────────────────

    /** Uploads [bytes] as a blob and returns its sha. Safe to call from several threads at once. */
    fun createBlob(bytes: ByteArray): String {
        val (code, resp) = withRetry { GitHubApi.httpPostBlob(token, GitHubApi.apiBlobs(owner, repo), bytes) }
        if (code !in 200..201) throw Exception("Blob creation failed ($code): ${resp.take(200)}")
        return JSONObject(resp).getString("sha")
    }

    /**
     * Applies [changes] on top of [head] as one commit and moves the branch to it; returns the new
     * commit's sha. A big batch is split into several tree requests chained through `base_tree` so
     * no single request body gets huge — the result is still one tree, one commit, one ref update.
     *
     * Not-a-fast-forward (the branch moved since [head] was read) surfaces as the ref-update error;
     * nothing is left half-applied, because nothing is visible until that last step succeeds.
     */
    fun commit(head: Head, message: String, changes: List<Change>): String {
        require(changes.isNotEmpty()) { "Nothing to commit" }
        val newTreeSha = buildTree(head.treeSha, changes)

        val commitBody = JSONObject().apply {
            put("message", message)
            put("tree", newTreeSha)
            put("parents", JSONArray().put(head.commitSha))
        }.toString()
        val (commitCode, commitResp) = withRetry {
            GitHubApi.httpPost(token, GitHubApi.apiCommits(owner, repo), commitBody)
        }
        if (commitCode !in 200..201) throw Exception("Commit failed ($commitCode): ${commitResp.take(300)}")
        val newCommitSha = JSONObject(commitResp).getString("sha")

        val refBody = JSONObject().apply { put("sha", newCommitSha); put("force", false) }.toString()
        val (refCode, refResp) = withRetry {
            GitHubApi.httpPatch(token, GitHubApi.apiRefsHeads(owner, repo, branch), refBody)
        }
        if (refCode !in 200..201) throw Exception("Ref update failed ($refCode): ${refResp.take(300)}")
        return newCommitSha
    }

    private fun buildTree(baseTreeSha: String, changes: List<Change>): String {
        var base = baseTreeSha
        var batch = JSONArray()
        var weight = 0
        for (change in changes) {
            if (batch.length() > 0 && (batch.length() >= MAX_TREE_ENTRIES || weight + change.weight > MAX_TREE_WEIGHT)) {
                base = postTree(base, batch)
                batch = JSONArray()
                weight = 0
            }
            batch.put(entryJson(change))
            weight += change.weight
        }
        if (batch.length() > 0) base = postTree(base, batch)
        return base
    }

    private fun entryJson(change: Change): JSONObject {
        val entry = JSONObject()
        entry.put("path", change.path)
        when (change) {
            is Change.Text -> {
                entry.put("mode", FILE_MODE)
                entry.put("type", "blob")
                entry.put("content", change.text)
            }
            is Change.Blob -> {
                entry.put("mode", FILE_MODE)
                entry.put("type", "blob")
                entry.put("sha", change.sha)
            }
            is Change.Delete -> {
                entry.put("mode", change.mode)
                entry.put("type", change.type)
                // JSONObject.NULL, not null: put(key, null) would drop the key, and a missing
                // "sha" means "keep this entry", not "delete it".
                entry.put("sha", JSONObject.NULL)
            }
        }
        return entry
    }

    private fun postTree(baseTreeSha: String, entries: JSONArray): String {
        val body = JSONObject().apply { put("base_tree", baseTreeSha); put("tree", entries) }.toString()
        val (code, resp) = withRetry { GitHubApi.httpPost(token, GitHubApi.apiTrees(owner, repo), body) }
        if (code !in 200..201) throw Exception("Tree creation failed ($code): ${resp.take(300)}")
        return JSONObject(resp).getString("sha")
    }

    // ── Retry / back-off ─────────────────────────────────────────────────────

    /**
     * Runs [send], retrying what is worth retrying: I/O failures (a mobile connection dropping
     * mid-request), 429/5xx, and GitHub's secondary rate limit (403 + Retry-After). Every request
     * this class makes is safe to repeat — blobs and trees are content-addressed, an extra commit
     * object is harmless until the ref moves, and re-sending the ref update to the sha it already
     * points at is a no-op.
     *
     * A primary-quota 403 is NOT retried: waiting seconds won't refill an hourly quota, so the
     * caller gets the response and reports it.
     */
    private fun withRetry(send: () -> GitHubApi.HttpResult): GitHubApi.HttpResult {
        var attempt = 0
        while (true) {
            attempt++
            waitOutPause()
            val result = try {
                send()
            } catch (e: IOException) {
                if (attempt >= MAX_ATTEMPTS) throw e
                pauseFor(backoffMs(attempt), "network error (${e.javaClass.simpleName})")
                continue
            }
            if (attempt >= MAX_ATTEMPTS || !isRetryable(result)) return result
            val waitMs = result.rateLimitInfo.retryAfterSeconds?.let { it * 1_000 } ?: backoffMs(attempt)
            pauseFor(waitMs, "GitHub answered ${result.code}")
        }
    }

    private fun isRetryable(r: GitHubApi.HttpResult): Boolean = when (r.code) {
        429, 500, 502, 503, 504 -> true
        403 -> r.rateLimitInfo.retryAfterSeconds != null ||
            r.body.contains("secondary rate limit", ignoreCase = true) ||
            r.body.contains("abuse", ignoreCase = true)
        else -> false
    }

    private fun backoffMs(attempt: Int): Long = (1_000L shl (attempt - 1)).coerceAtMost(15_000L)

    /** Makes every thread sharing this instance hold off for [ms] — parallel uploads must back off together. */
    private fun pauseFor(ms: Long, reason: String) {
        val clamped = ms.coerceIn(0L, MAX_PAUSE_MS)
        val until = System.currentTimeMillis() + clamped
        var extended = false
        synchronized(this) {
            if (until > pausedUntilMs) { pausedUntilMs = until; extended = true }
        }
        // Only the thread that actually extended the pause says so — four workers hitting the
        // same limit at once would otherwise print the same line four times.
        if (extended) log("[retry] $reason — retrying in ${(clamped + 999) / 1000}s")
    }

    private fun waitOutPause() {
        while (true) {
            val wait = pausedUntilMs - System.currentTimeMillis()
            if (wait <= 0) return
            Thread.sleep(wait)
        }
    }

    private companion object {
        const val FILE_MODE = "100644"
        const val MAX_ATTEMPTS = 4
        const val MAX_PAUSE_MS = 60_000L

        /** Per tree request: entry count and approximate body size (chars). Keeps each request
         *  small enough to finish well inside the HTTP read timeout on a slow connection. */
        const val MAX_TREE_ENTRIES = 1_000
        const val MAX_TREE_WEIGHT = 1_500_000
    }
}
