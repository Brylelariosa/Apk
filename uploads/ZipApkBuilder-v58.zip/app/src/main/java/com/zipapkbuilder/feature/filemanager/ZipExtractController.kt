package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.util.Base64
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.LogBatcher
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.BlobUploadPool
import com.zipapkbuilder.net.GitBatchCommit
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONObject
import com.zipapkbuilder.core.dialogChip
import com.zipapkbuilder.core.dialogStack

/**
 * Extracts a ZIP file already in the repo into real files and folders at the
 * same location, preserving the archive's own internal structure — instead
 * of a ZIP just sitting there as one opaque file, "Extract" recreates every
 * folder and file it contains as actual repo content, the way a desktop
 * "Extract Here" would.
 *
 * The whole extraction is ONE commit, built with the Git Data API through
 * [GitBatchCommit] rather than a Contents-API commit per file. What keeps it
 * fast is how little network it needs:
 *  - the ZIP itself comes down as raw bytes ([GitHubApi.fetchBlobRaw]), not
 *    a base64-in-JSON envelope;
 *  - text files are sent inline inside the tree request — no request each;
 *  - binary files upload as blobs on a few threads at once ([BlobUploadPool]);
 *  - then one tree, one commit, one ref update.
 * See [ZipTreePlanner] for how each entry is routed.
 *
 * The original ZIP is never touched — extraction only adds files. If it's
 * not needed anymore, delete it afterward via the browser's own Delete
 * action, same as any other file.
 */
class ZipExtractController(
    private val activity: MainActivity,
    private val refreshBrowser: (String, String, String, String, String) -> Unit
) {
    fun promptExtract(token: String, owner: String, repo: String, branch: String, item: RepoItem, currentPath: String) {
        lateinit var dlg: AlertDialog
        val body = activity.dialogStack(
            activity.dialogChip(
                item.name, R.drawable.ic_zip, ButtonTone.PRIMARY,
                meta = if (item.size > 0) Formatters.fmtBytes(item.size) else null
            ),
            activity.dialogMessage(
                "Every file and folder inside the ZIP will be added to this location, " +
                    "preserving its structure.\n\nThe ZIP itself won't be deleted — " +
                    "remove it afterward from this same menu if you don't need it anymore."
            )
        )
        val content = activity.dialogWithActions(
            body,
            DialogAction("Extract", ButtonTone.GREEN, R.drawable.ic_check) {
                dlg.dismiss()
                activity.setBusy(true)
                activity.appendLog("-------------------------------------")
                activity.bgExecutor.execute { extract(token, owner, repo, branch, item, currentPath) }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(activity.dialogTitleBar("Extract ZIP", R.drawable.ic_zip, ButtonTone.PRIMARY) { dlg.dismiss() })
            .setView(content)
            .show()
    }

    private fun extract(token: String, owner: String, repo: String, branch: String, item: RepoItem, currentPath: String) {
        val startedAt = System.currentTimeMillis()
        val committer = GitBatchCommit(token, owner, repo, branch) { activity.appendLog(it) }
        val pool = BlobUploadPool(committer)
        val log = LogBatcher({ activity.appendLog(it) })
        try {
            activity.appendLog("Extracting ${item.name} …")

            val zipBytes = fetchFileBytes(token, owner, repo, branch, item)
                ?: throw Exception("Could not read ${item.name} — it may be unavailable or an unexpected format.")

            val targetBase = if (currentPath.isEmpty()) "" else "$currentPath/"
            val plan = ZipTreePlanner(targetBase, committer, pool, log).plan(zipBytes)

            if (plan.skippedCount > 0) {
                activity.appendLog("[warn] Skipped ${plan.skippedCount} entr${if (plan.skippedCount == 1) "y" else "ies"} with an unusable path.")
            }
            if (plan.fileCount == 0) {
                activity.appendLog("[warn] No files found inside ${item.name} — nothing to extract.")
                return
            }

            activity.appendLog("Committing ${plan.changes.size} entries…")
            // Read the branch tip only now, after everything is uploaded, so the window in which
            // something else could move the branch (and fail the ref update) is as short as possible.
            committer.commit(committer.readHead(), "chore: extract ${item.name} [skip ci]", plan.changes)

            activity.appendLog(
                "[ok] Extracted ${plan.fileCount} file(s)" +
                    (if (plan.emptyDirCount > 0) " and ${plan.emptyDirCount} empty folder(s)" else "") +
                    " from ${item.name} in ${Formatters.fmtDuration(System.currentTimeMillis() - startedAt)}"
            )
        } catch (e: Exception) {
            log.flush()
            activity.appendLog("[error] Extract failed: ${Formatters.friendlyError(e)}")
        } finally {
            pool.close()
            activity.mainHandler.post {
                activity.setBusy(false)
                refreshBrowser(token, owner, repo, branch, currentPath)
            }
        }
    }

    /**
     * Fetches a repo file's raw bytes regardless of size. First choice is the blob's raw bytes
     * ([GitHubApi.fetchBlobRaw]) — no JSON envelope and no base64, so a third less to download and
     * nothing to decode afterwards; it has no size limit either. If that comes back empty for any
     * reason (or isn't a ZIP), this falls back to the older base64 routes: the Contents API's inline `content` (only
     * populated for files under [GitHubApi.CONTENTS_API_SIZE_LIMIT]) and then
     * [GitHubApi.fetchBlobBytes].
     */
    private fun fetchFileBytes(token: String, owner: String, repo: String, branch: String, item: RepoItem): ByteArray? {
        GitHubApi.fetchBlobRaw(token, owner, repo, item.sha)?.takeIf { looksLikeZip(it) }?.let { return it }

        if (item.size in 1 until GitHubApi.CONTENTS_API_SIZE_LIMIT) {
            val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path, branch))
            if (code == 200) {
                val content = JSONObject(body).optString("content", "")
                if (content.isNotEmpty()) return Base64.decode(content.replace("\n", ""), Base64.DEFAULT)
            }
        }
        return GitHubApi.fetchBlobBytes(token, owner, repo, item.sha)
    }

    /** True if [bytes] open with the ZIP signature `PK` — a cheap guard so a proxy's error page or
     *  an unexpected 200 body is never mistaken for the archive; it just sends [fetchFileBytes] on
     *  to its slower fallbacks. */
    private fun looksLikeZip(bytes: ByteArray): Boolean =
        bytes.size >= 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
}
