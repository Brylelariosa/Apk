package com.zipapkbuilder.core

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/**
 * Byte-level "is this really text?" check. `String(bytes, UTF_8)` never fails — it silently swaps
 * every invalid byte for U+FFFD — so using it to decide whether a file can travel as a JSON string
 * would corrupt any binary file that happens to be tried. This decoder REPORTs malformed input
 * instead, so a non-null result is guaranteed to re-encode to exactly the original bytes.
 */
object TextBytes {

    /**
     * [bytes] as a String if — and only if — they are well-formed UTF-8 with no NUL byte (a NUL is
     * the cheapest reliable sign of binary data, and not something a JSON text body should carry).
     * Returns null for anything else. An empty array decodes to "".
     */
    fun decodeUtf8OrNull(bytes: ByteArray): String? {
        if (bytes.any { it.toInt() == 0 }) return null
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes))
                .toString()
        } catch (_: CharacterCodingException) {
            null
        }
    }
}
