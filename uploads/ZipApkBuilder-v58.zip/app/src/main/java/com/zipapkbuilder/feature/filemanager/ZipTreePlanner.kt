package com.zipapkbuilder.feature.filemanager

import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.LogBatcher
import com.zipapkbuilder.core.TextBytes
import com.zipapkbuilder.net.BlobUploadPool
import com.zipapkbuilder.net.GitBatchCommit
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * Reads a ZIP and works out the git-tree changes that extracting it implies — no dialogs, no
 * branch/commit handling (that's [ZipExtractController] and [GitBatchCommit]). Single use: build
 * one per extraction and call [plan] once.
 *
 * Each file takes the cheapest route to becoming a blob:
 *  - empty files (and the `.gitkeep` that stands in for an empty folder) share ONE empty blob;
 *  - valid-UTF-8 text rides inside the tree request itself ([GitBatchCommit.Change.Text]) — no
 *    request of its own, which is nearly every file in a source project;
 *  - everything else (images, audio, jars, .so files…) is uploaded as a blob on [pool]'s threads
 *    while the rest of the archive is still being read.
 *
 * Only one archive entry's decompressed bytes are read at a time; text is kept (it is small, and
 * needed for the tree request), binary bytes are handed to [pool] and dropped.
 */
internal class ZipTreePlanner(
    private val targetBase: String,
    private val committer: GitBatchCommit,
    private val pool: BlobUploadPool,
    private val log: LogBatcher
) {

    /** What [plan] found. [changes] has exactly one entry per final repo path. */
    class Plan(
        val changes: List<GitBatchCommit.Change>,
        val fileCount: Int,
        val emptyDirCount: Int,
        val skippedCount: Int
    )

    /** A path's pending result: either a ready [change], or a [ticket] for a blob still uploading. */
    private class Slot(val change: GitBatchCommit.Change?, val ticket: Int)

    // Keyed by final repo path, so a second archive entry with the same name replaces the first
    // (as a real "extract, overwrite" would) instead of producing a duplicate tree entry, which
    // GitHub rejects.
    private val slots = LinkedHashMap<String, Slot>()
    private val dirsSeen = LinkedHashSet<String>()          // every folder the ZIP itself declares
    private val dirsWithContent = HashSet<String>()         // folders that ended up holding a real file
    private val emptyBlobSha: String by lazy(LazyThreadSafetyMode.NONE) { committer.createBlob(ByteArray(0)) }
    private var fileCount = 0
    private var skipped = 0
    private var uploads = 0
    private var inlineBytes = 0L

    fun plan(zipBytes: ByteArray): Plan {
        readEntries(zipBytes)

        // Preserve folders the ZIP declared but which ended up with no file inside them — git
        // never tracks empty directories, so without an explicit placeholder an empty folder from
        // the ZIP would silently vanish on extraction instead of being recreated.
        val emptyDirs = dirsSeen - dirsWithContent
        for (dir in emptyDirs) {
            val keep = "$dir/.gitkeep"
            slots[keep] = Slot(GitBatchCommit.Change.Blob(keep, emptyBlobSha), NO_TICKET)
        }
        log.flush()

        val shas = awaitUploads()
        val changes = slots.map { (path, slot) ->
            slot.change ?: GitBatchCommit.Change.Blob(path, shas[slot.ticket])
        }
        return Plan(changes, fileCount, emptyDirs.size, skipped)
    }

    private fun readEntries(zipBytes: ByteArray) {
        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val rel = cleanEntryName(entry.name)
                if (rel == null) {
                    // A bare "/" or "./" root entry is just noise; a name that tries to climb out
                    // of the target folder is worth telling the user about.
                    if (entry.name.contains("..")) skipped++
                } else if (entry.isDirectory) {
                    dirsSeen.add(targetBase + rel)
                } else {
                    addFile(targetBase + rel, rel, zis.readBytes())
                }
                entry = zis.nextEntry
            }
        }
    }

    private fun addFile(path: String, rel: String, bytes: ByteArray) {
        fileCount++
        log.add("  [$fileCount] $rel (${Formatters.fmtBytes(bytes.size.toLong())})")
        slots[path] = classify(path, bytes)

        // Mark every ancestor folder as "has real content" so the empty-folder pass doesn't also
        // add a redundant .gitkeep next to it. add() is false once an ancestor is already marked,
        // and its own ancestors are then marked too — so the walk can stop there.
        var parent = path.substringBeforeLast('/', "")
        while (parent.isNotEmpty() && dirsWithContent.add(parent)) {
            parent = parent.substringBeforeLast('/', "")
        }
    }

    private fun classify(path: String, bytes: ByteArray): Slot {
        if (bytes.isEmpty()) return Slot(GitBatchCommit.Change.Blob(path, emptyBlobSha), NO_TICKET)

        // Inline only modest text, and only up to a total cap: the text of every inlined file stays
        // in memory until the tree is built, so a huge text-only archive must not pile up forever.
        val canInline = bytes.size <= INLINE_FILE_MAX_BYTES && inlineBytes + bytes.size <= INLINE_TOTAL_MAX_BYTES
        val text = if (canInline) TextBytes.decodeUtf8OrNull(bytes) else null
        if (text != null) {
            inlineBytes += bytes.size
            return Slot(GitBatchCommit.Change.Text(path, text), NO_TICKET)
        }

        uploads++
        return Slot(null, pool.submit(bytes))
    }

    /** Waits for the binary uploads started while reading; their shas, indexed by ticket. */
    private fun awaitUploads(): List<String> {
        if (uploads == 0) return emptyList()
        log.now("Uploading $uploads binary file(s)…")
        return pool.awaitAll { done, total ->
            if (done == total || done % PROGRESS_EVERY == 0) log.now("  $done/$total uploaded")
        }
    }

    /**
     * Archive entry name → clean repo-relative path (`a/b/c.txt`): backslashes become slashes and
     * empty / `.` segments are dropped. Null when nothing usable is left, or when the name climbs
     * out with `..` — git rejects such a path, and failing the whole commit late is worse than
     * skipping one entry.
     */
    private fun cleanEntryName(raw: String): String? {
        val segments = raw.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
        if (segments.isEmpty() || segments.any { it == ".." }) return null
        return segments.joinToString("/")
    }

    private companion object {
        const val NO_TICKET = -1
        const val INLINE_FILE_MAX_BYTES = 512 * 1024
        const val INLINE_TOTAL_MAX_BYTES = 32L * 1024 * 1024
        const val PROGRESS_EVERY = 25
    }
}
