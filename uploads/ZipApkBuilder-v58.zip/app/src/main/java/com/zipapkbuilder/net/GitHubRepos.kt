package com.zipapkbuilder.net

import org.json.JSONException
import org.json.JSONObject

/**
 * Creating a repository on GitHub, in one place: the name rules, the request body, the response
 * parsing and the "is it usable yet" probe. Two callers share it —
 * [com.zipapkbuilder.feature.repo.RepoCreator] (the "New repository" dialog) and
 * [com.zipapkbuilder.feature.build.BuildFlowController.ensureRepo] (the silent create-on-first-build)
 * — so a repo is made the same way, and a failure reads the same way, whichever door it came in by.
 *
 * Stateless, like [GitHubApi], which it builds on. Same contract too: transport failures (no
 * network, timeout, TLS) propagate as exceptions for the caller to word; every HTTP *response*,
 * good or bad, comes back as a [CreateResult] instead.
 */
object GitHubRepos {

    /** What to create. [name] is validated by [create]; [description] is optional. */
    data class NewRepo(
        val name: String,
        val description: String = "",
        val isPrivate: Boolean = false
    )

    /**
     * The repository as GitHub reports it. Callers use these values, not what they asked for:
     * the name and default branch in the response are what every later request has to target.
     */
    data class CreatedRepo(
        val owner: String,
        val name: String,
        val defaultBranch: String,
        val isPrivate: Boolean,
        val htmlUrl: String
    ) {
        val fullName: String get() = "$owner/$name"
    }

    sealed interface CreateResult {
        data class Created(val repo: CreatedRepo) : CreateResult

        /**
         * Nothing was created. [message] is ready to show as-is. [isNameProblem] is true when the
         * name itself is at fault (invalid, or already taken), so a form can mark that field
         * instead of showing a general error.
         */
        data class Refused(val message: String, val isNameProblem: Boolean) : CreateResult
    }

    // ── Name rules ────────────────────────────────────────────────────────────

    /** GitHub's limit on a repository name's length. */
    const val MAX_NAME_LENGTH = 100

    private val NAME_CHARS = Regex("[A-Za-z0-9._-]+")

    /**
     * Why [raw] can't be a repository name, worded for the person typing it, or null when it
     * can. Pure — no network — so a form can run it on every keystroke. GitHub itself would
     * quietly rewrite some bad names (a space becomes a hyphen), and the app would then keep
     * talking to a repo name that does not exist; catching them here avoids that.
     * Whether the name is already *taken* is only known to GitHub (see [create]).
     */
    fun nameProblem(raw: String): String? {
        val name = raw.trim()
        return when {
            name.isEmpty() -> "Enter a repository name."
            name.length > MAX_NAME_LENGTH -> "Names can be at most $MAX_NAME_LENGTH characters."
            !NAME_CHARS.matches(name) -> "Use only letters, numbers, hyphens, underscores and dots."
            name == "." || name == ".." -> "\"$name\" isn't a valid name."
            name.endsWith(".git", ignoreCase = true) -> "A name can't end in .git."
            else -> null
        }
    }

    // ── Create ────────────────────────────────────────────────────────────────

    /**
     * Creates [request] under the account [token] belongs to (`POST /user/repos`). The repo is
     * created with `auto_init`, i.e. with a first commit, so its default branch exists and the
     * Contents / Git Data calls the rest of the app makes have something to write onto.
     *
     * Blocking network call — run it on a background thread. Throws on a transport failure.
     */
    fun create(token: String, request: NewRepo): CreateResult {
        val name = request.name.trim()
        nameProblem(name)?.let { return CreateResult.Refused(it, isNameProblem = true) }

        val payload = JSONObject().apply {
            put("name", name)
            put("private", request.isPrivate)
            put("auto_init", true)
            request.description.trim().takeIf { it.isNotEmpty() }?.let { put("description", it) }
        }.toString()

        val (code, body, rateLimit) = GitHubApi.httpPost(token, GitHubApi.apiUserRepos(), payload)
        return when (code) {
            200, 201 -> parseCreated(body)?.let { CreateResult.Created(it) }
                ?: CreateResult.Refused(
                    "GitHub answered with something unexpected. The repository may have been " +
                        "created — check your repository list.",
                    isNameProblem = false
                )
            // A token without the needed scope gets "not found" here rather than "forbidden".
            404 -> CreateResult.Refused(
                "Could not create the repository (404) — the token is probably missing the repo scope.",
                isNameProblem = false
            )
            422 -> refusedByValidation(body)
            401, 403, 429 -> CreateResult.Refused(
                GitHubApi.describeHttpError(code, body, rateLimit), isNameProblem = false
            )
            else -> CreateResult.Refused(
                "GitHub returned HTTP $code" + (messageOf(body)?.let { " — $it" } ?: ""),
                isNameProblem = false
            )
        }
    }

    /**
     * One probe of "can the rest of the app use this repo yet": its default branch exists. The
     * create call returns before the first commit that `auto_init` makes has necessarily landed,
     * and writing to a branch that isn't there yet fails. Callers poll this with their own
     * timing (see [com.zipapkbuilder.feature.build.BuildRetryManager]).
     */
    fun isReady(token: String, repo: CreatedRepo): Boolean =
        GitHubApi.httpGet(token, GitHubApi.apiRefHeads(repo.owner, repo.name, repo.defaultBranch)).code == 200

    // ── Response parsing ──────────────────────────────────────────────────────

    private fun parseCreated(body: String): CreatedRepo? = try {
        val json = JSONObject(body)
        val name = json.optString("name")
        val owner = json.optJSONObject("owner")?.optString("login").orEmpty()
        if (name.isEmpty() || owner.isEmpty()) null
        else CreatedRepo(
            owner = owner,
            name = name,
            defaultBranch = json.optString("default_branch").ifEmpty { "main" },
            isPrivate = json.optBoolean("private", false),
            htmlUrl = json.optString("html_url")
        )
    } catch (_: JSONException) {
        null
    }

    /**
     * A 422 carries `{"message": "Repository creation failed.", "errors": [{"field": "name",
     * "message": "name already exists on this account", …}]}`. An error on the `name` field is
     * reported as a name problem; anything else is joined into one line.
     */
    private fun refusedByValidation(body: String): CreateResult.Refused {
        val json = try { JSONObject(body) } catch (_: JSONException) { null }
        val errors = json?.optJSONArray("errors")

        var nameError: String? = null
        val otherErrors = mutableListOf<String>()
        if (errors != null) {
            for (i in 0 until errors.length()) {
                val error = errors.optJSONObject(i) ?: continue
                val message = error.optString("message").ifEmpty { error.optString("code") }
                if (message.isEmpty()) continue
                if (error.optString("field") == "name") {
                    if (nameError == null) nameError = message
                } else {
                    otherErrors += message
                }
            }
        }

        if (nameError != null) {
            val text = if (nameError.contains("already exists", ignoreCase = true)) {
                "You already have a repository with this name."
            } else {
                "GitHub rejected the name: $nameError"
            }
            return CreateResult.Refused(text, isNameProblem = true)
        }
        val detail = otherErrors.joinToString("; ").ifEmpty { json?.optString("message").orEmpty() }
        return CreateResult.Refused(
            "GitHub rejected the request (422)" + (if (detail.isNotEmpty()) " — $detail" else "") + ".",
            isNameProblem = false
        )
    }

    /** GitHub's own `message` field from an error body, or null when there isn't one. */
    private fun messageOf(body: String): String? = try {
        JSONObject(body).optString("message").takeIf { it.isNotEmpty() }
    } catch (_: JSONException) {
        null
    }
}
