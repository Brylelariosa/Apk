package com.zipapkbuilder.net

import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Uploads git blobs on a few threads at once. A blob request is almost all waiting on the
 * network (TLS round trip plus GitHub's own processing), so overlapping a handful of them cuts
 * the wall-clock time of "upload 200 images" by close to the thread count — while four in flight
 * is still well inside what GitHub tolerates (its secondary rate limit is handled by
 * [GitBatchCommit]'s back-off, which pauses every thread together).
 *
 * Memory is bounded: [submit] blocks once `threads * 2` uploads are queued or running, so a large
 * archive is never held in memory all at once, only the few files currently in flight.
 *
 * Use from ONE producer thread: [submit] for each file, then [awaitAll], then [close] (in a
 * `finally`; it cancels whatever is still queued if something failed).
 */
class BlobUploadPool(
    private val committer: GitBatchCommit,
    threads: Int = DEFAULT_THREADS
) : AutoCloseable {

    private val executor: ExecutorService = Executors.newFixedThreadPool(threads) { r ->
        Thread(r, "ZipApkBuilder-blob").apply { isDaemon = true }
    }
    private val slots = Semaphore(threads * 2)
    private val firstFailure = AtomicReference<Throwable?>(null)
    private val completed = AtomicInteger(0)
    private val queued = ArrayList<Future<String>>()

    /** Uploads finished so far (safe to read from any thread). */
    val completedCount: Int get() = completed.get()

    /**
     * Queues [bytes] for upload and returns its ticket — the position of its sha in [awaitAll]'s
     * result. Blocks while the queue is full. Throws right away if an earlier upload already
     * failed, instead of reading the rest of a big archive just to fail at the end.
     */
    fun submit(bytes: ByteArray): Int {
        rethrowFailure()
        slots.acquire()
        try {
            rethrowFailure()
        } catch (e: Exception) {
            slots.release()
            throw e
        }
        val future = try {
            executor.submit(Callable {
                try {
                    val sha = committer.createBlob(bytes)
                    completed.incrementAndGet()
                    sha
                } catch (t: Throwable) {
                    firstFailure.compareAndSet(null, t)
                    throw t
                } finally {
                    slots.release()
                }
            })
        } catch (e: Exception) {
            slots.release()
            throw e
        }
        queued.add(future)
        return queued.size - 1
    }

    /**
     * Waits for every queued upload and returns the blob shas, indexed by the tickets [submit]
     * handed out. [onProgress] gets `(done, total)` as results come in, in submission order.
     * Rethrows the first failure.
     */
    fun awaitAll(onProgress: (done: Int, total: Int) -> Unit = { _, _ -> }): List<String> {
        val shas = ArrayList<String>(queued.size)
        for ((index, future) in queued.withIndex()) {
            val sha = try {
                future.get()
            } catch (e: ExecutionException) {
                throw (e.cause as? Exception) ?: e
            }
            shas.add(sha)
            onProgress(index + 1, queued.size)
        }
        return shas
    }

    /** Cancels anything still queued and releases the threads. Safe to call more than once. */
    override fun close() {
        executor.shutdownNow()
    }

    private fun rethrowFailure() {
        val failure = firstFailure.get() ?: return
        throw (failure as? Exception) ?: Exception(failure.message ?: failure.javaClass.simpleName, failure)
    }

    companion object {
        /** Conservative on purpose — GitHub asks API clients not to hammer one account concurrently. */
        const val DEFAULT_THREADS = 4
    }
}
