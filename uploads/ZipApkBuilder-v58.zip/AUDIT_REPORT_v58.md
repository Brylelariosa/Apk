# Full Code Audit (v58)

A fresh read of v57: all 64 Kotlin files, the layouts and manifest, the Gradle files, and the two
workflow templates the app commits into a repo. The earlier audit reports were read first so this
is not a re-hash of them.

**How it was checked.** There is no Kotlin compiler or Android SDK in the authoring environment, so
nothing here was compiled. What was done instead:
- The two workflow YAMLs were parsed and every `run:` script was executed against fixtures
  (shallow clone with a raced remote, ZIPs with `__MACOSX` and `local.properties`, a mocked `gh`,
  `curl` and `jq`, and a real `keytool`). The keystore script was run with a hostile password
  (`p@ss"w$rd` followed by a backtick and `$(touch ...)`): no injection, no leak of the token or
  password in the output, and the generated keystore opens with that exact password.
- Every Kotlin file was checked for balanced brackets, every resource reference was resolved,
  and every signature the new code calls was looked up. Each diff was read line by line.
- Status below: **Fixed** (in v58), **Open** (not changed, with the reason).

---

## Security

### 1. Keystore workflow wrote the token, password and keystore into the Actions log — High — Fixed
`keystore.yml` put `${{ github.event.inputs.pat_token }}`, `${{ github.event.inputs.password }}`
and `${{ steps.gen.outputs.keystore_b64 }}` into `run:` scripts and `env:`. Actions prints a step's
script and env after expanding expressions, and `::add-mask::` only affects lines printed *after*
it, so all three appeared in clear text in the job log. The repo was public unless you chose
otherwise (see 2). The same pattern also meant a password with `"`, `$` or a backtick broke the
script (shell injection), and `$$` in a password expanded to a different PID in each step, so the
saved `STORE_PASSWORD` could differ from the keystore's real password.
Fix: template v2 is a single step that reads the inputs from `$GITHUB_EVENT_PATH` with `jq`, masks
them before anything else, and has no expression or step output that carries a secret. The app
also deletes the run when it finishes, because the dispatch inputs stay on the run.
**If you generated a keystore with v57 or older in a public repo:** treat that token, keystore
password and keystore as exposed — revoke the token, delete the old runs, generate a new keystore.

### 2. Auto-created repos were public — Medium — Fixed
Upload & build created a missing repo silently and publicly, so a mistyped name would publish the
project source. Now private. Public repos get unlimited free Actions minutes and private ones use
the plan's quota; use Settings > New repository to choose public.

### 3. Signing secrets spliced into the Gradle command line — Low — Fixed
`-Pandroid.injected.signing.store.password="${{ secrets.STORE_PASSWORD }}"` broke for passwords
with quotes or `$`. They now go through `env:`.

### 4. The token is still passed as a dispatch input — Low — Open
Needed because `GITHUB_TOKEN` cannot write repository secrets. Mitigated by 1. The real fix is to
generate the keystore on the runner as now but encrypt the secrets on the phone (libsodium sealed
box), which needs a crypto dependency and is too big to ship uncompiled.

---

## Bugs

### 5. Upload & build after switching repo ran with an empty ZIP name — High — Fixed
Known from v57: `applySwitchRepo` cleared the ZIP's name and label but not its Uri. It clears the
whole pick now; `keepZip = true` is used by New repository so "pick ZIP, create repo, build" works.

### 6. Repo picker could point at someone else's repo — Medium — Fixed
It listed `owner,collaborator` repos but the app always uses the signed-in user as the owner, so
picking a collaborator repo created a same-named repo on your account. It now lists repos you own
and reads up to 500 (it stopped at 100).

### 7. Workflow could build the wrong ZIP — Medium — Fixed
It took the ZIP with the newest file time after checkout, which for a fresh checkout is just the
alphabetically last one, and the clean-up only ran on success, so a failed build left its ZIP
behind for the next run to pick. v2 builds the ZIP added by the pushed commit, cleans up after
success and failure (as your pipeline already does), cannot fail the job from the clean-up, and
rebases before pushing.

### 8. `local.properties` from Android Studio breaks CI — Medium — Fixed
Its `sdk.dir` points at the author's machine; Gradle refuses to start. The workflow deletes it.

### 9. Keystore generation hard-coded `main` — Medium — Fixed
Used for the commit, the dispatch and the run lookup; a repo whose default branch is `master`
failed. Uses the default branch now.

### 10. ZIP names with spaces — Low — Fixed
The commit-message regex needed `\S+`, so a build log downloaded for such a run was named after
whatever ZIP was picked in the UI.

### 11. Activity recreated by dark-mode / fold / multi-window changes — Low — Fixed
`configChanges` lacked `uiMode|smallestScreenSize|screenLayout`. A scheduled dark mode flip during
a build recreated the Activity: picked ZIP lost, busy state lost. Added; the ZIP's Uri is also put
in the saved instance state and a running build re-enters the busy state.

### 12. Timeout showed "[error] Build " — Low — Fixed
No conclusion after 45 minutes printed an empty conclusion. It now says it timed out.

### 13. A build could not be stopped — Low — Fixed (feature below)

---

## Features and UI added

- **Cancel build**: red button with a confirmation while waiting for the run or running; calls
  `POST /actions/runs/{id}/cancel` (or looks the run up for 20 s if it had not started yet).
- **Live running time** in the status line.
- **Target row** (`repo @ branch`, tap to switch) on the main card; before, the target was only
  visible in Settings.
- **Settings > Update build workflow**, and a log hint when a repo's `build.yml` is older than the
  bundled one (it is never rewritten silently).
- **Pre-upload check** also warns when the ZIP has no `app/` module (the workflow takes the APK
  from `app/build/outputs/apk`).

---

## Open items and ideas

1. **Keep the picked ZIP across restarts.** `GetContent` gives no persistable permission; switching
   to `OpenDocument` + `takePersistableUriPermission` would let the label and Upload & build work
   after the app is reopened.
2. **Update the foreground notification without restarting the service.** `BuildTrackingService
   .updateStatus` calls `startForegroundService` again; from the background that can be refused on
   Android 12+ (it is caught, so the notification text just stops updating). Posting the same
   notification id directly avoids it.
3. **Delete old artifacts** (long-press a row in Artifacts, `DELETE .../artifacts/{id}`); they
   count against the repo's storage quota.
4. **Friendlier expired-artifact error.** `DownloadEngine.resolveGithubRedirect` ignores a 410
   (artifact expired after 30 days) and the download then fails with a bare HTTP 401.
5. **Preserve the executable bit** of `gradlew` in the tree commit (mode `100755`). The workflow's
   `chmod +x` covers it today.
6. **Tests.** There are none. The pure helpers (`Formatters`, `GitHubRepos.nameProblem`,
   `ZipTreePlanner.cleanEntryName`, `WorkflowTemplates.versionOf`) are cheap to cover and would
   have caught the regex bug above.
7. **Housekeeping:** `kapt.incremental.apt` in `gradle.properties` is unused; `allowBackup` is on
   (the app already copes with a token that can't be decrypted after a restore).
