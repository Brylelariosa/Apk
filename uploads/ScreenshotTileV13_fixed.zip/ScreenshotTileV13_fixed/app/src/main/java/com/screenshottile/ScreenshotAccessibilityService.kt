package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class ScreenshotAccessibilityService : AccessibilityService() {

    companion object {
        // @JvmField: direct field access — no synthetic getter/setter overhead
        @JvmField @Volatile var instance: ScreenshotAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    /**
     * Used by TriggerActivity when it has NO window focus (home screen / launcher /
     * menus). In that case TriggerActivity finishes itself first to remove its surface
     * from the composition stack, then calls this so the screenshot fires after the
     * surface teardown has settled. Without this, Android 12+ shows the preview
     * animation but suppresses the MediaStore file write because a non-system
     * Activity surface is still visible over the launcher.
     */
    fun scheduleScreenshot(delayMs: Long) {
        handler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        }, delayMs)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        instance = null
    }
}
