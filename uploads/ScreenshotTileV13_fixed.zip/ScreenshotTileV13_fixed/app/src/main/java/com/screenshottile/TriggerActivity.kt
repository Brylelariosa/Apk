package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this activity starts.
 *
 * TASK ISOLATION
 * --------------
 * android:taskAffinity="" in the manifest gives this activity its own anonymous
 * task. finishAndRemoveTask() at the end destroys it completely — it never lingers
 * in recents or re-surfaces when the user screenshots from another app.
 *
 * SCREENSHOT TIMING
 * -----------------
 * Primary:  onWindowFocusChanged(hasFocus=true) — fires once the panel animation
 *           is fully complete; most accurate trigger.
 * Fallback: onResume + 600 ms — for home screen / launcher / menus where Android
 *           does not grant focus to a translucent window overlaid on the launcher.
 * Both paths are guarded by screenshotTaken so only one fires.
 *
 * SAVE RELIABILITY — HOME SCREEN PATH
 * ------------------------------------
 * Problem: Android 12+ suppresses the MediaStore write when a non-system Activity
 * surface is visible in the layer stack over the launcher.
 * Old fix: finish() immediately → removes surface, but also kills process priority.
 * The screenshot then fires 300ms later in a low-priority process → MediaStore write
 * is cancelled intermittently → "saves sometimes, not sometimes".
 *
 * New fix: moveTaskToBack(true) instead of finishing.
 *   - Moves our task behind the launcher → surface is gone from the foreground
 *     composition stack, so Android 12+ won't suppress the write.
 *   - Process stays alive at background-but-not-dying priority → MediaStore write
 *     completes reliably.
 *   - finishAndRemoveTask() is called 1500 ms later once the write is done.
 *
 * SAVE RELIABILITY — IN-APP PATH
 * --------------------------------
 * finishAndRemoveTask() is delayed 1200 ms so the process stays at foreground
 * priority during the async MediaStore write. The preview thumbnail stays visible
 * for its full duration because the write completes before we exit.
 */
class TriggerActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private var screenshotTaken = false
    private var retryCount = 0
    private var screenshotRunnable: Runnable? = null
    private var finishRunnable: Runnable? = null

    private var hadWindowFocus = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(null)
        if (ScreenshotAccessibilityService.instance == null) { finishAndRemoveTask(); return }
    }

    override fun onResume() {
        super.onResume()
        if (!screenshotTaken && screenshotRunnable == null) {
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 600L)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !screenshotTaken) {
            hadWindowFocus = true
            // Hide nav bar at runtime — android:windowHideNavigation is not a
            // valid theme attribute and was removed from styles.xml.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.hide(WindowInsets.Type.navigationBars())
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE
                )
            }
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
            takeScreenshot()
        }
    }

    private fun takeScreenshot() {
        if (screenshotTaken) return

        val service = ScreenshotAccessibilityService.instance
        if (service == null) { finishAndRemoveTask(); return }

        if (!hadWindowFocus) {
            // HOME SCREEN / LAUNCHER / MENU PATH
            //
            // moveTaskToBack(true): moves our task behind the launcher so our
            // surface is no longer in the foreground composition stack.
            // Android 12+ will not suppress the MediaStore write.
            // The process stays alive → write completes reliably.
            //
            // scheduleScreenshot fires 350 ms later — enough time for the surface
            // to fully leave the composition stack on all devices.
            //
            // finishAndRemoveTask fires 1500 ms later — after the write is done.
            screenshotTaken = true
            moveTaskToBack(true)
            service.scheduleScreenshot(350L)
            val r = Runnable { finishAndRemoveTask() }
            finishRunnable = r
            handler.postDelayed(r, 1500L)
            return
        }

        // IN-APP PATH — focus was genuinely granted, fire immediately.
        val dispatched = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)

        if (!dispatched && retryCount < 1) {
            retryCount++
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 200L)
            return
        }

        screenshotTaken = true

        // 1200 ms keeps the process at foreground priority while the async
        // MediaStore write completes. Preview thumbnail shows its full duration.
        val r = Runnable { finishAndRemoveTask() }
        finishRunnable = r
        handler.postDelayed(r, 1200L)
    }

    override fun onPause() {
        super.onPause()
        if (!screenshotTaken) {
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        screenshotRunnable = null
        finishRunnable = null
    }
}
