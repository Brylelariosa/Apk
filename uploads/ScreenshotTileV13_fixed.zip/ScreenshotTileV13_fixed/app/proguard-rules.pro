# Framework entry points registered in AndroidManifest — R8 must not rename/remove them
-keep class com.screenshottile.ScreenshotTileService
-keep class com.screenshottile.ScreenshotAccessibilityService
-keep class com.screenshottile.TriggerActivity
-keep class com.screenshottile.MainActivity

# @JvmField companion accessed by name across classes — keep the field itself
-keepclassmembers class com.screenshottile.ScreenshotAccessibilityService {
    public static com.screenshottile.ScreenshotAccessibilityService instance;
}
