# Rubik AI Lab - NEXT TASK

Version 2.2 - 2026-10-22

## Do this next
1. Build v2.2 with CI (v2.1 was never rebuilt after run 1868 failed at PlayPage.kt, fixed in v2.1). If the Kotlin compile or R8 reports
   anything else, fix exactly the reported lines (nothing is compiled in the authoring sandbox). The CI builds
   assembleRelease when the keystore secrets exist, so R8 (minify + shrinkResources) runs too.
2. On the phone: Train tab -> pick a puzzle -> Start training; check the temperature chip and the live AI view; try Cool / Balanced / Fast.
3. Play tab (v2.2 visuals): on the 3x3 check the thin lines and that the dark pieces turn with their layer (try a face turn and
   a middle slice); on the Pyraminx check the shape, that a swipe on a tip sticker turns just the tip, and that a swipe on
   any other sticker turns the top two layers; confirm a drag that starts on the puzzle never spins the view, while a drag on
   the background (or "Rotate view") does. If the body colour looks too light or too dark, change BODY in PuzzleRenderer.kt.
4. Test tab: run a sweep on the held-out scrambles and on fresh ones; compare Learned AI with Baseline.

## Ideas, not started
- Continuous finger-following turns (current swipes trigger an animated turn).
- Megaminx / other shapes; a "train only while charging" option; per-puzzle hidden sizes in the settings.

## Rules
- Never touch GitHub. Never claim a test or build happened unless a tool confirmed it.
- Keep CI layout: app/src/main/cpp/jni_bridge.cpp and app/src/main/cpp/core/*.cpp (flat).
