// End-to-end host test of the engine: physical scrambles with ALL moves (including whole-puzzle
// reorienting ones) must be solved into a solved puzzle by the moves the engine returns.
#include <cstdio>
#include <cstring>
#include <vector>
#include "core/engine.h"

using namespace rubik;
static int g_fail = 0;
#define CHECK(c, ...) do { if (!(c)) { ++g_fail; printf("FAIL line %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

int main(int argc, char** argv) {
  int trainMs = argc > 1 ? atoi(argv[1]) : 8000;
  int only = argc > 2 ? atoi(argv[2]) : -1;
  int trials = argc > 3 ? atoi(argv[3]) : 60;
  for (int id : {(int)kCube2, (int)kCube3, (int)kPyraminx, (int)kSkewb}) {
    if (only >= 0 && id != only) continue;
    std::unique_ptr<Engine> e = Engine::create(id, 5);
    CHECK(e != nullptr, "engine for %d", id);
    if (!e) continue;
    const Puzzle& p = e->puzzle();
    TrainConfig cfg = e->config();
    cfg.threads = 1;
    e->configure(cfg);
    int elapsed = 0;
    while (elapsed < trainMs) { e->train(250); elapsed += 250; }
    TrainStats st = e->stats();
    printf("== %s trained %dms: iters=%d depth=%d acc=%.2f\n", p.name.c_str(), trainMs, st.iterations, st.depth, st.accuracy);

    Rng rng(99 + id);
    std::vector<uint8_t> s(p.stickers), t(p.stickers);
    int solvedL = 0, solvedB = 0, total = 0, badL = 0, badB = 0, reoriented = 0;
    SearchConfig sc; sc.maxExpansions = 20000; sc.lambda = 0.6f; sc.timeoutMs = 5000;
    for (int trial = 0; trial < trials; ++trial) {
      p.setSolved(s.data());
      int len = 3 + (int)rng.below(9);
      for (int k = 0; k < len; ++k) {
        int m = (int)rng.below((uint32_t)p.moves);   // ALL physical moves
        p.apply(s.data(), t.data(), m);
        s = t;
      }
      if (p.isSolved(s.data())) continue;
      ++total;
      if (p.needsCanon && p.canonRotation(s.data()) != 0) ++reoriented;
      for (int mode = 0; mode < 2; ++mode) {
        if (mode == 1 && len > 6) continue;
        SearchResult r = e->solve(mode, s.data(), sc);
        if (r.status == kSolved) {
          std::vector<uint8_t> u = s, v(p.stickers);
          for (uint8_t m : r.moves) { CHECK(m < p.moves, "move index"); p.apply(u.data(), v.data(), m); u = v; }
          bool ok = p.isSolved(u.data());
          if (mode == 0) { ++solvedL; if (!ok) ++badL; } else { ++solvedB; if (!ok) ++badB; }
        }
      }
    }
    printf("   physical scrambles: %d (reoriented frames: %d) | learned solved %d (bad %d) | baseline solved %d (bad %d)\n", total, reoriented, solvedL, badL, solvedB, badB);
    CHECK(badL == 0 && badB == 0, "a returned solution did not solve the puzzle");
    CHECK(solvedL >= total * 8 / 10, "learned solver solved too few (%d/%d)", solvedL, total);

    // estimate
    p.setSolved(s.data());
    CHECK(e->estimate(s.data()) == 0.0f, "estimate of solved state");

    // evaluate: held-out and fresh
    EvalResult a = e->evaluate(kLearnedMode, 8, 20, sc, 0);
    EvalResult b = e->evaluate(kLearnedMode, 8, 20, sc, 12345);
    printf("   evaluate depth 8: held-out %d/%d, fresh %d/%d\n", a.solved, a.total, b.solved, b.total);

    // checkpoint round trip
    const char* path = "/tmp/rubik_test_ckpt.bin";
    CHECK(e->save(path), "save");
    std::unique_ptr<Engine> e2 = Engine::create(id, 777);
    CHECK(e2->load(path), "load");
    TrainStats s2 = e2->stats();
    CHECK(s2.steps == st.steps && s2.depth == st.depth, "restored counters %lld vs %lld", (long long)s2.steps, (long long)st.steps);
    std::vector<uint8_t> probe(p.stickers);
    Rng r3(4);
    p.setSolved(probe.data());
    for (int k = 0; k < 9; ++k) { p.apply(probe.data(), t.data(), p.aiMoves[r3.below((uint32_t)p.aiMoves.size())]); probe = t; }
    CHECK(e->estimate(probe.data()) == e2->estimate(probe.data()), "restored net differs");
    // a checkpoint of another puzzle must be rejected
    std::unique_ptr<Engine> other = Engine::create(id == kCube3 ? (int)kSkewb : (int)kCube3, 1);
    CHECK(!other->load(path), "foreign checkpoint accepted");
    std::remove(path);
  }
  printf(g_fail ? "FAILED (%d)\n" : "ALL OK\n", g_fail);
  return g_fail ? 1 : 0;
}
