// Host benchmark: train a puzzle for N seconds, then measure solve rates on the held-out scrambles.
// usage: bench <puzzleId> <seconds> <threads> [maxDepth] [pool] [maxEpochs] [frontierMix] [fresh]
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "core/engine.h"

using namespace rubik;

int main(int argc, char** argv) {
  int id = argc > 1 ? atoi(argv[1]) : 1;
  int seconds = argc > 2 ? atoi(argv[2]) : 60;
  int threads = argc > 3 ? atoi(argv[3]) : 1;
  std::unique_ptr<Engine> e = Engine::create(id, 1);
  if (!e) { printf("engine unavailable\n"); return 1; }
  TrainConfig cfg = e->config();
  cfg.threads = threads;
  if (argc > 4) cfg.maxDepth = atoi(argv[4]);
  if (argc > 5) cfg.pool = atoi(argv[5]);
  if (argc > 6) cfg.maxEpochs = atoi(argv[6]);
  if (argc > 7) cfg.frontierMix = (float)atof(argv[7]);
  bool fresh = argc > 8 && atoi(argv[8]) != 0;
  e->configure(cfg);
  printf("puzzle %s: depth cap %d pool %d epochs %d..%d frontier %.2f threads %d\n", e->puzzle().name.c_str(), cfg.maxDepth, cfg.pool, cfg.minEpochs, cfg.maxEpochs, cfg.frontierMix, threads);
  auto t0 = std::chrono::steady_clock::now();
  int lastPrint = 0;
  for (;;) {
    TrainStats s = e->train(300);
    double el = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    if ((int)el / 15 > lastPrint) {
      lastPrint = (int)el / 15;
      printf("t=%3.0fs steps=%lld depth=%d iters=%d loss=%.3f acc=%.2f sps=%.0f phase=%d\n", el, (long long)s.steps, s.depth, s.iterations, s.loss, s.accuracy, s.samplesPerSec, s.phase);
      fflush(stdout);
    }
    if (el > seconds) break;
  }
  SearchConfig sc; sc.maxExpansions = 20000; sc.lambda = 0.6f; sc.timeoutMs = 20000;
  int top = e->puzzle().id == kPyraminx ? 12 : 14;
  std::vector<int> depths;
  if (getenv("DEPTHS")) { char* p = strdup(getenv("DEPTHS")); for (char* t = strtok(p, ","); t; t = strtok(nullptr, ",")) depths.push_back(atoi(t)); }
  else for (int d = 2; d <= top; d += 2) depths.push_back(d);
  for (int d : depths) {
    EvalResult r = e->evaluate(kLearnedMode, d, getenv("CASES") ? atoi(getenv("CASES")) : 40, sc, fresh ? 0xFEEDBEEFULL : 0);
    printf("depth %2d: solved %d/%d avgLen %.1f avgExp %.0f avgMs %.0f\n", d, r.solved, r.total, r.avgLength, r.avgExpanded, r.avgMs);
    fflush(stdout);
  }
  return 0;
}
