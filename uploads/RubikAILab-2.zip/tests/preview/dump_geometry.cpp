// Dumps the geometry of every puzzle (what the JNI layer exports) as a simple text file for the preview tool.
#include <cstdio>
#include "core/puzzle.h"
using namespace rubik;
int main(int argc, char** argv) {
  const int id = argc > 1 ? atoi(argv[1]) : 1;
  const Puzzle* p = puzzleById(id);
  if (!p) return 1;
  printf("name %s\nvalid %d\nstickers %d colors %d faces %d moves %d\n", p->name.c_str(), p->valid ? 1 : 0, p->stickers, p->colors, p->faces, p->moves);
  printf("style %f %f %f %f\n", p->radius, p->stickerInset, p->stickerLift, p->stickerRound);
  for (int i = 0; i < p->stickers; ++i) {
    printf("S %d", p->vcount[i]);
    for (int k = 0; k < 12; ++k) printf(" %f", p->verts[i * 12 + k]);
    for (int k = 0; k < 3; ++k) printf(" %f", p->normal[i * 3 + k]);
    for (int k = 0; k < 3; ++k) printf(" %f", p->centroid[i * 3 + k]);
    printf(" %d %d\n", p->solved[i], p->faceOf[i]);
  }
  for (int m = 0; m < p->moves; ++m) {
    const MoveInfo& mv = p->move[m];
    printf("M %s %f %f %f %f %f %f\n", mv.name.c_str(), mv.axis[0], mv.axis[1], mv.axis[2], mv.angleDeg, mv.lo, mv.hi);
  }
  for (int m = 0; m < p->moves; ++m) {
    printf("P");
    for (int i = 0; i < p->stickers; ++i) printf(" %d", p->perm[m][i]);
    printf("\n");
  }
  for (const BodyPiece& b : p->bodies) {
    printf("B %f %f %f %zu", b.cls[0], b.cls[1], b.cls[2], b.tris.size() / 12);
    for (float f : b.tris) printf(" %f", f);
    printf("\n");
  }
  printf("C %zu", p->core.size() / 12);
  for (float f : p->core) printf(" %f", f);
  printf("\n");
  return 0;
}
