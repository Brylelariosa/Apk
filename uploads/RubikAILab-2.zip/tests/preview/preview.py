#!/usr/bin/env python3
"""Software preview of the app's renderer (same camera, same shading, same mesh rules as PuzzleRenderer.kt and
StickerShape.kt), so the look of the puzzles can be checked without a phone.

  g++ -std=c++17 -O1 -Iapp/src/main/cpp tests/preview/dump_geometry.cpp app/src/main/cpp/core/puzzle.cpp -o /tmp/dump_geometry
  /tmp/dump_geometry 1 > /tmp/geo_1.txt            # puzzle id 0..5 = 2x2, 3x3, 4x4, 5x5, Pyraminx, Skewb
  python3 tests/preview/preview.py /tmp/geo_1.txt /tmp/out.png -35 28            # rest view (yaw pitch)
  python3 tests/preview/preview.py /tmp/geo_1.txt /tmp/turn.png -35 28 0 0.5     # move 0 half way through its turn
"""
import sys, math
import numpy as np
from PIL import Image

def load(path):
    g = dict(stickers=[], moves=[], perms=[], bodies=[], core=[])
    for line in open(path):
        t = line.split()
        if not t: continue
        if t[0] == 'name': g['name'] = ' '.join(t[1:])
        elif t[0] == 'style':
            v = list(map(float, t[1:]))
            g['radius'] = v[0]
            if len(v) >= 4: g['inset'], g['lift'], g['round'] = v[1], v[2], v[3]
            else: g['scale'], g['lift'] = v[1], v[2]
        elif t[0] == 'S':
            n = int(t[1]); v = list(map(float, t[2:2+12+3+3])); rest = list(map(int, t[2+18:2+20]))
            g['stickers'].append(dict(n=n, corners=np.array(v[:12]).reshape(4,3), normal=np.array(v[12:15]), centroid=np.array(v[15:18]), color=rest[0], face=rest[1]))
        elif t[0] == 'M':
            g['moves'].append(dict(name=t[1], axis=np.array(list(map(float, t[2:5]))), angle=float(t[5]), lo=float(t[6]), hi=float(t[7])))
        elif t[0] == 'P': g['perms'].append(np.array(list(map(int, t[1:]))))
        elif t[0] == 'B':
            c = np.array(list(map(float, t[1:4]))); k = int(t[4]); tr = np.array(list(map(float, t[5:5+12*k]))).reshape(k, 12)
            g['bodies'].append(dict(c=c, tris=tr))
        elif t[0] == 'C':
            k = int(t[1]); g['core'] = np.array(list(map(float, t[2:2+12*k]))).reshape(k, 12) if k else np.zeros((0,12))
    return g

PALETTE_CUBE = [(0.96,0.96,0.94),(0.80,0.09,0.12),(0.06,0.62,0.26),(0.98,0.80,0.08),(0.98,0.45,0.04),(0.08,0.30,0.82)]
PALETTE_PYRA = [(0.98,0.80,0.08),(0.08,0.30,0.82),(0.80,0.09,0.12),(0.06,0.62,0.26)]

def rot_matrix(angle_deg, ax):
    a = np.array(ax, dtype=float); a /= np.linalg.norm(a)
    th = math.radians(angle_deg); c, s = math.cos(th), math.sin(th)
    x, y, z = a
    R = np.array([[c+x*x*(1-c), x*y*(1-c)-z*s, x*z*(1-c)+y*s],
                  [y*x*(1-c)+z*s, c+y*y*(1-c), y*z*(1-c)-x*s],
                  [z*x*(1-c)-y*s, z*y*(1-c)+x*s, c+z*z*(1-c)]])
    M = np.eye(4); M[:3,:3] = R
    return M

def perspective(fovy, aspect, n, f):
    t = 1.0/math.tan(math.radians(fovy)/2)
    P = np.zeros((4,4)); P[0,0] = t/aspect; P[1,1] = t; P[2,2] = (f+n)/(n-f); P[2,3] = 2*f*n/(n-f); P[3,2] = -1
    return P

def camera(W, H, radius):
    aspect = W/H
    dist = radius*4.1/min(1.0, aspect)
    P = perspective(34.0, aspect, max(0.1, dist-radius*2.2), dist+radius*2.2)
    V = np.eye(4); V[2,3] = -dist
    return P @ V

def orbit(yaw, pitch):
    return rot_matrix(pitch, (1,0,0)) @ rot_matrix(yaw, (0,1,0))

def in_layer(g, mv, p, tol=1e-3):
    m = g['moves'][mv]; d = float(np.dot(p, m['axis']))
    return m['lo']-tol <= d <= m['hi']+tol

class Mesh:
    def __init__(self): self.v=[]; self.n=[]; self.c=[]
    def tri(self, a, b, c, n, col):
        self.v.append((a,b,c)); self.n.append(n); self.c.append(col)

def add_tris(mesh, tris, col):
    for t in tris:
        mesh.tri(t[0:3], t[3:6], t[6:9], t[9:12], col)

def add_sticker_old(mesh, g, i, color, palette, CUT=0.14):
    s = g['stickers'][i]; n = s['n']; nrm = s['normal']; c0 = s['centroid']
    cl = c0 + nrm*g['lift']; sc = g['scale']
    q = [cl + (s['corners'][k]-c0)*sc for k in range(n)]
    o = []
    for k in range(n):
        k1 = (k+1) % n
        o.append(q[k] + (q[k1]-q[k])*CUT)
        o.append(q[k1] + (q[k]-q[k1])*CUT)
    col = palette[color % len(palette)]
    for j in range(len(o)):
        mesh.tri(cl, o[j], o[(j+1)%len(o)], nrm, col)

def build(g, state, turning, palette, body_col, add_sticker=add_sticker_old):
    st, mv = Mesh(), Mesh()
    add_tris(st, g['core'], body_col)
    for b in g['bodies']:
        moving = turning >= 0 and in_layer(g, turning, b['c'])
        add_tris(mv if moving else st, b['tris'], body_col)
    for i, s in enumerate(g['stickers']):
        moving = turning >= 0 and in_layer(g, turning, s['centroid'])
        add_sticker(mv if moving else st, g, i, state[i], palette)
    return st, mv

def rasterize(meshes, VP, W, H, bg, ss=2, light=(0.35,0.8,0.6), amb=0.60, dif=0.50):
    Wc, Hc = W*ss, H*ss
    img = np.zeros((Hc, Wc, 3), dtype=np.float32); img[:] = bg
    zb = np.full((Hc, Wc), np.inf, dtype=np.float32)
    L = np.array(light, dtype=float); L /= np.linalg.norm(L)
    for mesh, M in meshes:
        if not mesh.v: continue
        MVP = VP @ M
        R = M[:3,:3]
        for (a,b,c), n, col in zip(mesh.v, mesh.n, mesh.c):
            nn = R @ np.array(n); nn /= max(1e-9, np.linalg.norm(nn))
            shade = amb + dif*max(0.0, float(np.dot(nn, L)))
            pts = np.array([a,b,c], dtype=float)
            h = np.hstack([pts, np.ones((3,1))]) @ MVP.T
            w = h[:,3]
            if np.any(w <= 1e-6): continue
            ndc = h[:,:3]/w[:,None]
            sx = (ndc[:,0]*0.5+0.5)*Wc; sy = (1-(ndc[:,1]*0.5+0.5))*Hc; sz = ndc[:,2]
            minx = int(max(0, math.floor(sx.min()))); maxx = int(min(Wc-1, math.ceil(sx.max())))
            miny = int(max(0, math.floor(sy.min()))); maxy = int(min(Hc-1, math.ceil(sy.max())))
            if minx > maxx or miny > maxy: continue
            x0,y0,x1,y1,x2,y2 = sx[0],sy[0],sx[1],sy[1],sx[2],sy[2]
            den = (y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
            if abs(den) < 1e-9: continue
            xs = np.arange(minx, maxx+1)+0.5; ys = np.arange(miny, maxy+1)+0.5
            X, Y = np.meshgrid(xs, ys)
            l0 = ((y1-y2)*(X-x2)+(x2-x1)*(Y-y2))/den
            l1 = ((y2-y0)*(X-x2)+(x0-x2)*(Y-y2))/den
            l2 = 1-l0-l1
            inside = (l0>=-1e-6)&(l1>=-1e-6)&(l2>=-1e-6)
            if not inside.any(): continue
            Z = l0*sz[0]+l1*sz[1]+l2*sz[2]
            sub = zb[miny:maxy+1, minx:maxx+1]
            ok = inside & (Z < sub) & (Z > -1) & (Z < 1)
            if not ok.any(): continue
            sub[ok] = Z[ok]
            img[miny:maxy+1, minx:maxx+1][ok] = np.array(col, dtype=np.float32)*shade
    img = np.clip(img, 0, 1)
    if ss > 1:
        img = img.reshape(H, ss, W, ss, 3).mean(axis=(1,3))
    return (img*255).astype(np.uint8)

def render(g, state, yaw, pitch, mv_index, frac, W=540, H=720, palette=None, body_col=(0.15,0.155,0.17), add_sticker=None, ss=2, light=(0.35,0.8,0.6), amb=0.60, dif=0.50):
    if add_sticker is None: add_sticker = add_sticker_new if 'inset' in g else add_sticker_old
    bg = (0.039, 0.047, 0.067)
    VP = camera(W, H, g['radius'])
    O = orbit(yaw, pitch)
    st, mv = build(g, state, mv_index, palette, body_col, add_sticker)
    meshes = [(st, O)]
    if mv_index >= 0:
        e = frac*frac*(3-2*frac)
        meshes.append((mv, O @ rot_matrix(g['moves'][mv_index]['angle']*e, g['moves'][mv_index]['axis'])))
    return rasterize(meshes, VP, W, H, bg, ss, light, amb, dif)

SEG = 3
def add_sticker_new(mesh, g, i, color, palette):
    """Port of PuzzleRenderer.addSticker: uniform dark margin, rounded corners, lifted off the piece."""
    s = g['stickers'][i]; n = s['n']; N = s['normal']
    P = [s['corners'][k] for k in range(n)]
    inset, rnd, lift = g['inset'], g['round'], g['lift']
    V = []
    for k in range(n):
        prev = P[(k-1) % n]; nxt = P[(k+1) % n]
        e1 = P[k]-prev; e1 = e1/np.linalg.norm(e1)
        e2 = nxt-P[k]; e2 = e2/np.linalg.norm(e2)
        in1 = np.cross(N, e1); in2 = np.cross(N, e2)
        den = max(0.2, 1.0 + float(np.dot(in1, in2)))
        V.append(P[k] + (in1+in2)*(inset/den))
    pts = []
    for k in range(n):
        a = V[(k-1) % n]-V[k]; b = V[(k+1) % n]-V[k]
        la = np.linalg.norm(a); lb = np.linalg.norm(b)
        cos_t = float(np.dot(a, b))/(la*lb)
        sin_t = math.sqrt(max(0.0, 1.0-cos_t*cos_t))
        d = rnd*(1.0+cos_t)/max(sin_t, 0.2)
        d = min(d, 0.45*min(la, lb))
        A = V[k] + a/la*d; B = V[k] + b/lb*d
        for j in range(SEG+1):
            t = j/SEG
            pts.append((1-t)*(1-t)*A + 2*t*(1-t)*V[k] + t*t*B)
    ctr = sum(V)/n + N*lift
    pts = [p + N*lift for p in pts]
    col = palette[color % len(palette)]
    for j in range(len(pts)):
        mesh.tri(ctr, pts[j], pts[(j+1) % len(pts)], N, col)

def apply_move(g, state, m):
    return state[g['perms'][m]]

if __name__ == '__main__':
    geo = load(sys.argv[1]); out = sys.argv[2]
    yaw = float(sys.argv[3]) if len(sys.argv) > 3 else -35
    pitch = float(sys.argv[4]) if len(sys.argv) > 4 else 28
    mvi = int(sys.argv[5]) if len(sys.argv) > 5 else -1
    frac = float(sys.argv[6]) if len(sys.argv) > 6 else 0.5
    pal = PALETTE_PYRA if 'Pyraminx' in geo['name'] else PALETTE_CUBE
    state = np.array([s['color'] for s in geo['stickers']])
    img = render(geo, state, yaw, pitch, mvi, frac, palette=pal)
    Image.fromarray(img).save(out)
