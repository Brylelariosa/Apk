#!/bin/sh
# Host tests of the native core. Usage: sh tests/run_host_tests.sh [full]
set -e
cd "$(dirname "$0")/.."
SRC=app/src/main/cpp
g++ -std=c++17 -O2 -Wall -Wextra -I$SRC tests/test_puzzle.cpp $SRC/core/puzzle.cpp $SRC/core/encoder.cpp -o /tmp/rubik_test_puzzle -pthread
/tmp/rubik_test_puzzle "$@"
g++ -std=c++17 -O3 -fno-math-errno -Wall -Wextra -I$SRC tests/test_engine.cpp $SRC/core/*.cpp -o /tmp/rubik_test_engine -pthread
/tmp/rubik_test_engine 6000
