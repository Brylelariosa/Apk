@rem Gradle start script for Windows (minimal launcher, see ./gradlew for details).
@echo off
setlocal

set "APP_HOME=%~dp0"
set "WRAPPER_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"

if exist "%WRAPPER_JAR%" (
    if defined JAVA_HOME (
        set "JAVACMD=%JAVA_HOME%\bin\java.exe"
    ) else (
        set "JAVACMD=java.exe"
    )
    "%JAVACMD%" -Xmx64m -Xms64m -Dorg.gradle.appname=gradlew -classpath "%WRAPPER_JAR%" org.gradle.wrapper.GradleWrapperMain %*
    exit /b %ERRORLEVEL%
)

where gradle >nul 2>nul
if %ERRORLEVEL% == 0 (
    echo gradle-wrapper.jar not found; using gradle from PATH 1>&2
    gradle %*
    exit /b %ERRORLEVEL%
)

echo ERROR: gradle\wrapper\gradle-wrapper.jar is missing and no gradle command was found. 1>&2
echo Install Gradle 8.6+ or run "gradle wrapper --gradle-version 8.6" once. 1>&2
exit /b 1
