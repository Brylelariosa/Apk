#include "net.h"

#include <cmath>
#include <cstring>

#if defined(__GNUC__) || defined(__clang__)
#define RUBIK_RESTRICT __restrict__
#else
#define RUBIK_RESTRICT
#endif

namespace rubik {

NetSpec::NetSpec(int features, int hidden1, int hidden2, int activeFeatures)
    : nFeat(features), h1(hidden1), h2(hidden2), active(activeFeatures > 0 ? activeFeatures : 1) {
  const bool sane = features > 0 && hidden1 > 0 && hidden1 <= kMaxH1 && hidden1 % 4 == 0 && hidden2 > 0 &&
                    hidden2 <= kMaxH2 && hidden2 % 4 == 0;
  if (!sane) {
    nFeat = 0;
    return;
  }
  int o = 0;
  offW1 = o;
  o += nFeat * h1;
  offB1 = o;
  o += h1;
  offW2 = o;
  o += h1 * h2;
  offB2 = o;
  o += h2;
  offW3 = o;
  o += h2;
  offB3 = o;
  o += 1;
  count = o;
}

void initParams(const NetSpec& sp, std::vector<float>& p, Rng& rng) {
  p.assign(static_cast<size_t>(sp.count), 0.f);
  // The first layer sums `active` rows, so scale rows by 1/sqrt(active).
  const float s1 = 0.67f / std::sqrt(static_cast<float>(sp.active));
  const float s2 = std::sqrt(2.0f / static_cast<float>(sp.h1));
  const float s3 = 0.02f;
  for (int i = 0; i < sp.nFeat * sp.h1; ++i) p[static_cast<size_t>(sp.offW1 + i)] = rng.gaussian() * s1;
  for (int i = 0; i < sp.h1 * sp.h2; ++i) p[static_cast<size_t>(sp.offW2 + i)] = rng.gaussian() * s2;
  for (int i = 0; i < sp.h2; ++i) p[static_cast<size_t>(sp.offW3 + i)] = rng.gaussian() * s3;
}

float forward(const NetSpec& sp, const float* RUBIK_RESTRICT p, const int* feats, int nf, Activations& a) {
  const int h1 = sp.h1;
  const int h2 = sp.h2;

  float* RUBIK_RESTRICT z1 = a.z1;
  const float* b1 = p + sp.offB1;
  for (int i = 0; i < h1; ++i) z1[i] = b1[i];
  for (int k = 0; k < nf; ++k) {
    const float* RUBIK_RESTRICT w = p + sp.offW1 + static_cast<size_t>(feats[k]) * static_cast<size_t>(h1);
    for (int i = 0; i < h1; ++i) z1[i] += w[i];
  }
  int na = 0;
  for (int i = 0; i < h1; ++i) {
    const float v = z1[i];
    a.a1[i] = v > 0.f ? v : 0.f;
    a.act[na] = i;
    na += v > 0.f ? 1 : 0;
  }
  a.nAct = na;

  float* RUBIK_RESTRICT z2 = a.z2;
  const float* b2 = p + sp.offB2;
  for (int j = 0; j < h2; ++j) z2[j] = b2[j];
  const float* w2 = p + sp.offW2;
  int t = 0;
  for (; t + 4 <= na; t += 4) {
    const int i0 = a.act[t];
    const int i1 = a.act[t + 1];
    const int i2 = a.act[t + 2];
    const int i3 = a.act[t + 3];
    const float x0 = a.a1[i0];
    const float x1 = a.a1[i1];
    const float x2 = a.a1[i2];
    const float x3 = a.a1[i3];
    const float* RUBIK_RESTRICT r0 = w2 + static_cast<size_t>(i0) * static_cast<size_t>(h2);
    const float* RUBIK_RESTRICT r1 = w2 + static_cast<size_t>(i1) * static_cast<size_t>(h2);
    const float* RUBIK_RESTRICT r2 = w2 + static_cast<size_t>(i2) * static_cast<size_t>(h2);
    const float* RUBIK_RESTRICT r3 = w2 + static_cast<size_t>(i3) * static_cast<size_t>(h2);
    for (int j = 0; j < h2; ++j) z2[j] += x0 * r0[j] + x1 * r1[j] + x2 * r2[j] + x3 * r3[j];
  }
  for (; t < na; ++t) {
    const int i0 = a.act[t];
    const float x0 = a.a1[i0];
    const float* RUBIK_RESTRICT r0 = w2 + static_cast<size_t>(i0) * static_cast<size_t>(h2);
    for (int j = 0; j < h2; ++j) z2[j] += x0 * r0[j];
  }

  const float* w3 = p + sp.offW3;
  float s0 = 0.f;
  float s1 = 0.f;
  float s2 = 0.f;
  float s3 = 0.f;
  for (int j = 0; j < h2; j += 4) {
    const float v0 = z2[j] > 0.f ? z2[j] : 0.f;
    const float v1 = z2[j + 1] > 0.f ? z2[j + 1] : 0.f;
    const float v2 = z2[j + 2] > 0.f ? z2[j + 2] : 0.f;
    const float v3 = z2[j + 3] > 0.f ? z2[j + 3] : 0.f;
    a.a2[j] = v0;
    a.a2[j + 1] = v1;
    a.a2[j + 2] = v2;
    a.a2[j + 3] = v3;
    s0 += v0 * w3[j];
    s1 += v1 * w3[j + 1];
    s2 += v2 * w3[j + 2];
    s3 += v3 * w3[j + 3];
  }
  return p[sp.offB3] + ((s0 + s1) + (s2 + s3));
}

void backward(const NetSpec& sp, const float* RUBIK_RESTRICT p, float* RUBIK_RESTRICT g, const int* feats, int nf,
              const Activations& a, float dOut) {
  const int h1 = sp.h1;
  const int h2 = sp.h2;

  g[sp.offB3] += dOut;
  const float* w3 = p + sp.offW3;
  float* gw3 = g + sp.offW3;
  float* gb2 = g + sp.offB2;
  float dz2[kMaxH2];
  for (int j = 0; j < h2; ++j) {
    gw3[j] += dOut * a.a2[j];
    const float d = a.z2[j] > 0.f ? dOut * w3[j] : 0.f;
    dz2[j] = d;
    gb2[j] += d;
  }

  float dz1[kMaxH1];
  for (int i = 0; i < h1; ++i) dz1[i] = 0.f;
  const float* w2 = p + sp.offW2;
  float* gw2 = g + sp.offW2;
  for (int t = 0; t < a.nAct; ++t) {
    const int i = a.act[t];
    const float x = a.a1[i];
    const float* RUBIK_RESTRICT row = w2 + static_cast<size_t>(i) * static_cast<size_t>(h2);
    float* RUBIK_RESTRICT grow = gw2 + static_cast<size_t>(i) * static_cast<size_t>(h2);
    float s0 = 0.f;
    float s1 = 0.f;
    float s2 = 0.f;
    float s3 = 0.f;
    for (int j = 0; j < h2; j += 4) {
      s0 += row[j] * dz2[j];
      s1 += row[j + 1] * dz2[j + 1];
      s2 += row[j + 2] * dz2[j + 2];
      s3 += row[j + 3] * dz2[j + 3];
      grow[j] += x * dz2[j];
      grow[j + 1] += x * dz2[j + 1];
      grow[j + 2] += x * dz2[j + 2];
      grow[j + 3] += x * dz2[j + 3];
    }
    dz1[i] = (s0 + s1) + (s2 + s3);
  }

  float* gb1 = g + sp.offB1;
  for (int i = 0; i < h1; ++i) gb1[i] += dz1[i];
  float* gw1 = g + sp.offW1;
  for (int k = 0; k < nf; ++k) {
    float* RUBIK_RESTRICT gr = gw1 + static_cast<size_t>(feats[k]) * static_cast<size_t>(h1);
    for (int i = 0; i < h1; ++i) gr[i] += dz1[i];
  }
}

float valueOf(const Model& m, const float* params, const uint8_t* state) {
  int feats[64];
  const int n = m.enc.encode(state, feats);
  if (n < 0) return 1.0e6f;  // not a valid arrangement of the pieces
  Activations act;
  const float v = forward(m.spec, params, feats, n, act) * kValueScale;
  return v > 0.f ? v : 0.f;
}

float estimateCost(const Model& m, const float* params, const uint8_t* state) {
  if (m.puzzle->isSolved(state)) return 0.f;
  return valueOf(m, params, state);
}

}  // namespace rubik
