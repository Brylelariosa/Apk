#pragma once
// Small deterministic random generator (SplitMix64). Identical results on every ABI.

#include <cmath>
#include <cstdint>

namespace rubik {

class Rng {
 public:
  explicit Rng(uint64_t seed = 0x9E3779B97F4A7C15ULL) { reseed(seed); }

  void reseed(uint64_t seed) {
    state_ = seed ^ 0xD1B54A32D192ED03ULL;
    next();
    next();
  }

  // Raw generator state, so a checkpoint can resume the exact random stream.
  uint64_t state() const { return state_; }
  void setState(uint64_t state) { state_ = state; }

  uint64_t next() {
    uint64_t z = (state_ += 0x9E3779B97F4A7C15ULL);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
  }

  // Uniform integer in [0, n). n must be > 0.
  uint32_t below(uint32_t n) {
    return static_cast<uint32_t>(((next() >> 32) * static_cast<uint64_t>(n)) >> 32);
  }

  // Uniform float in [0, 1).
  float uniform() { return static_cast<float>(next() >> 40) * (1.0f / 16777216.0f); }

  // Standard normal (Box-Muller).
  float gaussian() {
    float u1 = uniform();
    if (u1 < 1e-7f) u1 = 1e-7f;
    const float u2 = uniform();
    return std::sqrt(-2.0f * std::log(u1)) * std::cos(6.2831853f * u2);
  }

 private:
  uint64_t state_ = 0;
};

}  // namespace rubik
