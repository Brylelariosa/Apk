#pragma once
// Approximate value iteration trainer (DeepCubeA style, scaled down for a phone).
//
//   target(s) = 0                         if s is solved
//             = 1 + min_m J_target(m(s))  otherwise
//
// J is the value network. The learner never sees how a puzzle was scrambled, only the colours of the
// stickers: the training label of a state comes from the puzzle rules and the lagging target network,
// never from the scramble that produced it, so there is no "reverse the scramble" shortcut anywhere.
//
// Each training round works on a pool of random states:
//   1. fill: draw states, compute their targets once with the frozen target network (the expensive part,
//      one network evaluation per move);
//   2. fit: several epochs of minibatch Adam over that pool;
//   3. the target network is refreshed and the scramble depth range grows once the fit is good enough.
// Reusing every expensive target for several gradient steps is what keeps the phone cool.

#include <cstdint>
#include <cstdio>
#include <unordered_set>
#include <vector>

#include "net.h"
#include "rng.h"

namespace rubik {

// Random walk from the solved puzzle using the solver's moves (never undoes the previous move, never
// turns the same layer three times in a row). Returns the moves used in `moves` when it is not null.
void randomScramble(const Puzzle& puzzle, Rng& rng, int depth, uint8_t* out, int* moves = nullptr);

// Fixed, reproducible test scrambles (depth 1..kMaxDepth, kPerDepth each). Every test state with a
// scramble length of at least kMinExcludedDepth is excluded from the training distribution, whichever
// scramble depth would have produced it. Shallower test states are not excluded: the whole state space
// at those depths is tiny, so they only check that the model has not forgotten the basics.
class TestSet {
 public:
  static constexpr int kMaxDepth = 20;
  static constexpr int kPerDepth = 50;
  static constexpr int kMinExcludedDepth = 5;

  explicit TestSet(const Puzzle& puzzle);
  const uint8_t* state(int depth, int index) const;
  bool isHeldOut(uint64_t hash) const { return heldOut_.count(hash) != 0; }

 private:
  const Puzzle& puzzle_;
  std::vector<uint8_t> states_;
  std::unordered_set<uint64_t> heldOut_;
};

struct TrainConfig {
  int batch = 256;
  float lr = 1.0e-3f;
  int maxDepth = 12;
  int threads = 1;
  int startDepth = 3;
  int pool = 8192;               // states per round
  int minEpochs = 2;             // fit at least this many passes over the pool ...
  int maxEpochs = 4;             // ... and at most this many
  float accThreshold = 0.85f;    // fraction of states within 0.5 moves of their target
  float frontierMix = 0.3f;      // share of states drawn at the newest depths
};

struct TrainStats {
  int64_t steps = 0;
  int64_t samples = 0;
  int iterations = 0;
  int depth = 3;
  float loss = 0.0f;
  float mae = 0.0f;
  float accuracy = 0.0f;
  float samplesPerSec = 0.0f;
  float lr = 0.0f;
  int phase = 0;          // 0 = computing targets, 1 = fitting the network
  float progress = 0.0f;  // 0..1 within the current round
  int epoch = 0;
  int threads = 1;
  int batch = 256;
  int pool = 8192;
  int maxDepth = 12;
  int chunkSteps = 0;
};

class Trainer {
 public:
  Trainer(const Model* model, const TestSet* tests);

  void reset(uint64_t seed);
  void setConfig(const TrainConfig& cfg);
  const TrainConfig& config() const { return cfg_; }

  // Trains until the time budget is spent (at least one unit of work).
  TrainStats run(int budgetMs);
  TrainStats stats() const;

  const std::vector<float>& params() const { return net_; }

  bool save(std::FILE* f) const;
  bool load(std::FILE* f);

 private:
  struct Worker {
    std::vector<float> grad;
    Rng rng;
    double lossSum = 0.0;
    double absSum = 0.0;
    int hits = 0;
    int count = 0;
  };

  void step();
  void fillStep();
  void fitStep();
  void startFit();
  void endEpoch();
  void startFill();
  void sampleState(Rng& rng, uint8_t* out) const;
  void adamUpdate(const float* grad);
  void ensureWorkers(int threads);

  const Model* model_;
  const Puzzle* puzzle_;
  const TestSet* tests_;
  TrainConfig cfg_;
  Rng rng_;
  std::vector<float> net_;
  std::vector<float> target_;
  std::vector<float> m_;
  std::vector<float> v_;
  std::vector<Worker> workers_;
  int active_ = 1;

  // Current round.
  enum Phase { kFill = 0, kFit = 1 };
  Phase phase_ = kFill;
  std::vector<int> poolFeat_;
  std::vector<float> poolTgt_;
  std::vector<int> order_;
  int poolFill_ = 0;
  int cursor_ = 0;
  int epoch_ = 0;
  int epochHits_ = 0;
  int epochCount_ = 0;

  int64_t steps_ = 0;
  int64_t samples_ = 0;
  int64_t adamT_ = 0;
  int iterations_ = 0;
  int depth_ = 3;
  float emaLoss_ = 0.0f;
  float emaMae_ = 0.0f;
  float emaAcc_ = 0.0f;
  float samplesPerSec_ = 0.0f;
  int chunkSteps_ = 0;
};

}  // namespace rubik
