#pragma once
// Engine = trainer + held-out test scrambles + inference snapshot + search, for one puzzle.
//
// Threading: train/save/load/reset/configure are serialised by one mutex. solve/evaluate never touch
// the trainable network; they read an immutable snapshot that the trainer republishes after every
// training chunk, so searching while training is safe and lock-free on the hot path.
//
// Frames: puzzles whose solver moves cannot reorient the whole puzzle (2x2, 3x3 with slice turns, Skewb)
// are solved in a canonical frame. solve() takes the puzzle exactly as the player sees it, rotates it into
// the canonical frame, searches there and maps every move back to a move on the original puzzle. Only the
// sticker colours go in; nothing about how the puzzle was scrambled is ever available to the solver.

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

#include "net.h"
#include "search.h"
#include "trainer.h"

namespace rubik {

enum SolverMode {
  kLearnedMode = 0,
  kBaselineMode = 1,
};

struct EvalResult {
  int solved = 0;
  int total = 0;
  double avgLength = 0.0;    // over solved cases
  double avgExpanded = 0.0;  // over solved cases
  double avgMs = 0.0;        // over solved cases
  bool cancelled = false;
};

class Engine {
 public:
  // Returns nullptr when the puzzle has no learning solver.
  static std::unique_ptr<Engine> create(int puzzleId, uint64_t seed);

  const Puzzle& puzzle() const { return *puzzle_; }
  const Model& model() const { return *model_; }

  void reset(uint64_t seed);
  void configure(const TrainConfig& cfg);
  TrainConfig config();
  TrainStats train(int budgetMs);
  TrainStats stats();

  // `state` is the puzzle as the player sees it (puzzle().stickers colours).
  SearchResult solve(int mode, const uint8_t* state, const SearchConfig& cfg);
  // freshSeed == 0: the fixed held-out test scrambles. Otherwise new random scrambles made from that seed.
  EvalResult evaluate(int mode, int depth, int cases, const SearchConfig& cfg, uint64_t freshSeed);
  // The network's guess of how many moves are left (-1 when the state is invalid).
  float estimate(const uint8_t* state);
  void setCancel(bool cancel) { cancel_.store(cancel); }

  bool save(const char* path);
  bool load(const char* path);

 private:
  using Snapshot = std::shared_ptr<const std::vector<float>>;

  Engine() = default;
  void publish();
  Snapshot snapshot();

  const Puzzle* puzzle_ = nullptr;
  std::unique_ptr<Model> model_;
  std::unique_ptr<TestSet> tests_;
  std::unique_ptr<Trainer> trainer_;
  std::mutex trainMutex_;
  std::mutex snapMutex_;
  Snapshot snapshot_;
  std::atomic<bool> cancel_{false};
};

}  // namespace rubik
