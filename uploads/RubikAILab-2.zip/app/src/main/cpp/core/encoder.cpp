#include "encoder.h"

#include <cstring>

namespace rubik {

Encoder::Encoder(const Puzzle& p) : puzzle_(p) {
  if (!p.valid || !p.aiSupported) return;

  const int nClasses = p.classCount;
  classes_.assign(static_cast<size_t>(nClasses), Cls());
  std::vector<std::vector<int>> classSlots(static_cast<size_t>(nClasses));
  for (size_t s = 0; s < p.slots.size(); ++s) classSlots[static_cast<size_t>(p.slots[s].cls)].push_back(static_cast<int>(s));

  for (int c = 0; c < nClasses; ++c) {
    Cls& cl = classes_[static_cast<size_t>(c)];
    const std::vector<int>& members = classSlots[static_cast<size_t>(c)];
    cl.pieces = static_cast<int>(members.size());
    cl.k = p.slots[static_cast<size_t>(members[0])].n;
    std::memset(cl.pieceOfMask, 0xFF, sizeof(cl.pieceOfMask));
    std::memset(cl.ref, 0, sizeof(cl.ref));
    for (int pi = 0; pi < cl.pieces; ++pi) {
      const Slot& slot = p.slots[static_cast<size_t>(members[static_cast<size_t>(pi)])];
      int mask = 0;
      for (int k = 0; k < slot.n; ++k) mask |= 1 << p.solved[static_cast<size_t>(slot.stickers[k])];
      if (cl.pieceOfMask[mask] >= 0) return;  // two pieces of a class carry the same colours
      cl.pieceOfMask[mask] = static_cast<int8_t>(pi);
      int ref = 0;
      while (((mask >> ref) & 1) == 0) ++ref;
      cl.ref[pi] = static_cast<uint8_t>(ref);
    }
    for (int s : members) {
      if (!p.slotFixed[static_cast<size_t>(s)]) ++cl.nonFixed;
    }
  }

  int offset = 0;
  for (Cls& cl : classes_) {
    cl.offset = offset;
    offset += cl.nonFixed * cl.pieces * cl.k;
  }
  features_ = offset;

  std::vector<int> counter(static_cast<size_t>(nClasses), 0);
  for (size_t s = 0; s < p.slots.size(); ++s) {
    if (p.slotFixed[s]) continue;
    const Slot& slot = p.slots[s];
    Enc e;
    e.cls = slot.cls;
    e.local = counter[static_cast<size_t>(slot.cls)]++;
    e.n = slot.n;
    for (int k = 0; k < slot.n; ++k) e.st[k] = slot.stickers[k];
    slots_.push_back(e);
  }
  active_ = static_cast<int>(slots_.size());

  // Features of the solved puzzle, used to count misplaced pieces.
  int feats[64];
  ok_ = true;
  if (encode(p.solved.data(), feats) != active_) {
    ok_ = false;
    return;
  }
  for (int i = 0; i < active_; ++i) slots_[static_cast<size_t>(i)].solvedFeature = feats[i];

  // How many pieces of each class can one solver move change?
  for (int c = 0; c < nClasses; ++c) {
    int best = 1;
    for (int m : p.aiMoves) {
      const std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
      int touched = 0;
      for (size_t s = 0; s < p.slots.size(); ++s) {
        if (p.slots[s].cls != c || p.slotFixed[s]) continue;
        for (int k = 0; k < p.slots[s].n; ++k) {
          if (pm[static_cast<size_t>(p.slots[s].stickers[k])] != p.slots[s].stickers[k]) {
            ++touched;
            break;
          }
        }
      }
      if (touched > best) best = touched;
    }
    classes_[static_cast<size_t>(c)].maxMoved = best;
  }
}

int Encoder::encode(const uint8_t* s, int* out) const {
  int n = 0;
  for (const Enc& e : slots_) {
    const Cls& cl = classes_[static_cast<size_t>(e.cls)];
    int mask = 0;
    uint8_t c[3] = {0, 0, 0};
    for (int k = 0; k < e.n; ++k) {
      c[k] = s[e.st[k]];
      if (c[k] > 5) return -1;
      mask |= 1 << c[k];
    }
    const int piece = cl.pieceOfMask[mask];
    if (piece < 0) return -1;
    int ori = 0;
    if (e.n > 1) {
      const uint8_t ref = cl.ref[piece];
      ori = -1;
      for (int k = 0; k < e.n; ++k) {
        if (c[k] == ref) ori = k;
      }
      if (ori < 0) return -1;
    }
    out[n++] = cl.offset + (e.local * cl.pieces + piece) * cl.k + ori;
  }
  return n;
}

int Encoder::misplaced(const uint8_t* s, int* wrong) const {
  int feats[64];
  const int n = encode(s, feats);
  if (n < 0) return -1;
  for (size_t c = 0; c < classes_.size(); ++c) wrong[c] = 0;
  int total = 0;
  for (int i = 0; i < n; ++i) {
    if (feats[i] != slots_[static_cast<size_t>(i)].solvedFeature) {
      ++wrong[slots_[static_cast<size_t>(i)].cls];
      ++total;
    }
  }
  return total;
}

}  // namespace rubik
