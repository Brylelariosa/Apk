#include "engine.h"

#include <algorithm>
#include <cstdio>
#include <string>

namespace rubik {

std::unique_ptr<Engine> Engine::create(int puzzleId, uint64_t seed) {
  const Puzzle* pz = puzzleById(puzzleId);
  if (pz == nullptr || !pz->valid || !pz->aiSupported) return nullptr;
  std::unique_ptr<Engine> e(new Engine());
  e->puzzle_ = pz;
  e->model_.reset(new Model(*pz));
  if (!e->model_->ok()) return nullptr;
  e->tests_.reset(new TestSet(*pz));
  e->trainer_.reset(new Trainer(e->model_.get(), e->tests_.get()));
  e->trainer_->reset(seed);
  e->publish();
  return e;
}

void Engine::publish() {
  std::shared_ptr<std::vector<float>> copy = std::make_shared<std::vector<float>>(trainer_->params());
  const Snapshot frozen = copy;
  std::lock_guard<std::mutex> lock(snapMutex_);
  snapshot_ = frozen;
}

Engine::Snapshot Engine::snapshot() {
  std::lock_guard<std::mutex> lock(snapMutex_);
  return snapshot_;
}

void Engine::reset(uint64_t seed) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  trainer_->reset(seed);
  publish();
}

void Engine::configure(const TrainConfig& cfg) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  trainer_->setConfig(cfg);
}

TrainConfig Engine::config() {
  std::lock_guard<std::mutex> lock(trainMutex_);
  return trainer_->config();
}

TrainStats Engine::train(int budgetMs) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  const TrainStats s = trainer_->run(budgetMs);
  publish();
  return s;
}

TrainStats Engine::stats() {
  std::lock_guard<std::mutex> lock(trainMutex_);
  return trainer_->stats();
}

SearchResult Engine::solve(int mode, const uint8_t* state, const SearchConfig& cfgIn) {
  const Puzzle& pz = *puzzle_;
  SearchResult res;
  uint8_t canon[kMaxAiStickers];
  const uint8_t* start = state;
  int rot = 0;
  if (pz.needsCanon) {
    rot = pz.canonRotation(state);
    if (rot < 0) {
      res.status = kInvalid;
      return res;
    }
    pz.rotate(state, rot, canon);
    start = canon;
  }

  SearchConfig cfg = cfgIn;
  if (mode == kBaselineMode) {
    // Classic A* with an admissible heuristic: this is the conventional, non-learning reference.
    cfg.lambda = 1.0f;
    MisplacedHeuristic heuristic(*model_);
    res = solveWeightedAStar(*model_, start, heuristic, cfg, &cancel_);
  } else {
    const Snapshot snap = snapshot();
    NetHeuristic heuristic(*model_, snap->data());
    res = solveWeightedAStar(*model_, start, heuristic, cfg, &cancel_);
  }

  if (pz.needsCanon && res.status == kSolved) {
    for (uint8_t& m : res.moves) m = static_cast<uint8_t>(pz.conj[static_cast<size_t>(rot)][m]);
  }
  return res;
}

EvalResult Engine::evaluate(int mode, int depth, int cases, const SearchConfig& cfg, uint64_t freshSeed) {
  EvalResult result;
  const Puzzle& pz = *puzzle_;
  const int d = std::min(std::max(depth, 1), TestSet::kMaxDepth);
  const int n = freshSeed == 0 ? std::min(std::max(cases, 1), TestSet::kPerDepth) : std::min(std::max(cases, 1), 500);
  double sumLen = 0.0;
  double sumExpanded = 0.0;
  double sumMs = 0.0;
  uint8_t buf[kMaxAiStickers];
  for (int i = 0; i < n; ++i) {
    if (cancel_.load()) {
      result.cancelled = true;
      break;
    }
    const uint8_t* state = nullptr;
    if (freshSeed == 0) {
      state = tests_->state(d, i);
    } else {
      Rng rng(freshSeed + static_cast<uint64_t>(d) * 1000003ULL + static_cast<uint64_t>(i) * 7919ULL);
      for (int attempt = 0; attempt < 16; ++attempt) {
        randomScramble(pz, rng, d, buf);
        if (!pz.isSolved(buf)) break;
      }
      state = buf;
    }
    const SearchResult r = solve(mode, state, cfg);
    if (r.status == kCancelled) {
      result.cancelled = true;
      break;
    }
    ++result.total;
    if (r.status == kSolved) {
      ++result.solved;
      sumLen += static_cast<double>(r.moves.size());
      sumExpanded += static_cast<double>(r.expanded);
      sumMs += static_cast<double>(r.elapsedMs);
    }
  }
  if (result.solved > 0) {
    result.avgLength = sumLen / result.solved;
    result.avgExpanded = sumExpanded / result.solved;
    result.avgMs = sumMs / result.solved;
  }
  return result;
}

float Engine::estimate(const uint8_t* state) {
  const Puzzle& pz = *puzzle_;
  uint8_t canon[kMaxAiStickers];
  const uint8_t* s = state;
  if (pz.needsCanon) {
    const int rot = pz.canonRotation(state);
    if (rot < 0) return -1.0f;
    pz.rotate(state, rot, canon);
    s = canon;
  }
  int probe[64];
  if (model_->enc.encode(s, probe) < 0) return -1.0f;
  const Snapshot snap = snapshot();
  return estimateCost(*model_, snap->data(), s);
}

bool Engine::save(const char* path) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  const std::string tmp = std::string(path) + ".tmp";
  std::FILE* f = std::fopen(tmp.c_str(), "wb");
  if (f == nullptr) return false;
  bool ok = trainer_->save(f);
  ok = (std::fflush(f) == 0) && ok;
  ok = (std::fclose(f) == 0) && ok;
  if (!ok) {
    std::remove(tmp.c_str());
    return false;
  }
  if (std::rename(tmp.c_str(), path) != 0) {
    std::remove(tmp.c_str());
    return false;
  }
  return true;
}

bool Engine::load(const char* path) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  std::FILE* f = std::fopen(path, "rb");
  if (f == nullptr) return false;
  const bool ok = trainer_->load(f);
  std::fclose(f);
  if (ok) publish();
  return ok;
}

}  // namespace rubik
