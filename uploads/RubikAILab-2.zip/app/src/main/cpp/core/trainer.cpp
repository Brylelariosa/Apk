#include "trainer.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <numeric>
#include <thread>

namespace rubik {
namespace {

// Runs fn(0..threads-1), the first index on the calling thread.
template <typename F>
void parallelFor(int threads, F&& fn) {
  if (threads <= 1) {
    fn(0);
    return;
  }
  std::vector<std::thread> pool;
  pool.reserve(static_cast<size_t>(threads - 1));
  for (int t = 1; t < threads; ++t) pool.emplace_back([&fn, t]() { fn(t); });
  fn(0);
  for (std::thread& th : pool) th.join();
}

const char kMagic[4] = {'R', 'A', 'I', 'L'};
const char kEnd[4] = {'E', 'N', 'D', '!'};
const uint32_t kVersion = 3;  // 3: per-puzzle networks, round/pool state is not stored

template <typename T>
bool writeVal(std::FILE* f, const T& v) {
  return std::fwrite(&v, sizeof(T), 1, f) == 1;
}

template <typename T>
bool readVal(std::FILE* f, T& v) {
  return std::fread(&v, sizeof(T), 1, f) == 1;
}

bool writeVec(std::FILE* f, const std::vector<float>& v) {
  return std::fwrite(v.data(), sizeof(float), v.size(), f) == v.size();
}

bool readVec(std::FILE* f, std::vector<float>& v, size_t n) {
  v.assign(n, 0.0f);
  return std::fread(v.data(), sizeof(float), n, f) == n;
}

bool allFinite(const std::vector<float>& v) {
  for (float x : v) {
    if (!std::isfinite(x)) return false;
  }
  return true;
}

}  // namespace

void randomScramble(const Puzzle& pz, Rng& rng, int depth, uint8_t* out, int* movesOut) {
  pz.setSolved(out);
  uint8_t tmp[kMaxAiStickers];
  int prev = -1;
  int prev2 = -1;
  const uint32_t n = static_cast<uint32_t>(pz.aiMoves.size());
  for (int d = 0; d < depth; ++d) {
    int m = 0;
    do {
      m = pz.aiMoves[rng.below(n)];
    } while (prev >= 0 && (m == (prev ^ 1) || (m == prev && prev2 == prev)));
    pz.apply(out, tmp, m);
    std::memcpy(out, tmp, static_cast<size_t>(pz.stickers));
    if (movesOut != nullptr) movesOut[d] = m;
    prev2 = prev;
    prev = m;
  }
}

TestSet::TestSet(const Puzzle& pz) : puzzle_(pz) {
  const size_t stride = static_cast<size_t>(pz.stickers);
  states_.assign(static_cast<size_t>(kMaxDepth) * kPerDepth * stride, 0);
  for (int d = 1; d <= kMaxDepth; ++d) {
    for (int i = 0; i < kPerDepth; ++i) {
      uint8_t* dst = &states_[(static_cast<size_t>(d - 1) * kPerDepth + static_cast<size_t>(i)) * stride];
      Rng rng(0x7E575EEDULL + static_cast<uint64_t>(d) * 1000003ULL + static_cast<uint64_t>(i) * 7919ULL +
              static_cast<uint64_t>(pz.id) * 104729ULL);
      for (int attempt = 0; attempt < 16; ++attempt) {
        randomScramble(pz, rng, d, dst);
        if (!pz.isSolved(dst)) break;
      }
      if (d >= kMinExcludedDepth) heldOut_.insert(pz.hash(dst));
    }
  }
}

const uint8_t* TestSet::state(int depth, int index) const {
  const int d = std::min(std::max(depth, 1), kMaxDepth);
  const int i = std::min(std::max(index, 0), kPerDepth - 1);
  return &states_[(static_cast<size_t>(d - 1) * kPerDepth + static_cast<size_t>(i)) *
                  static_cast<size_t>(puzzle_.stickers)];
}

Trainer::Trainer(const Model* model, const TestSet* tests)
    : model_(model), puzzle_(model->puzzle), tests_(tests) {
  active_ = model->enc.active() > 0 ? model->enc.active() : 1;
  cfg_.maxDepth = puzzle_->defaultMaxDepth;
  reset(1);
}

void Trainer::reset(uint64_t seed) {
  rng_.reseed(seed);
  initParams(model_->spec, net_, rng_);
  target_ = net_;
  const size_t n = static_cast<size_t>(model_->spec.count);
  m_.assign(n, 0.0f);
  v_.assign(n, 0.0f);
  steps_ = 0;
  samples_ = 0;
  adamT_ = 0;
  iterations_ = 0;
  depth_ = std::min(cfg_.startDepth, cfg_.maxDepth);
  emaLoss_ = 0.0f;
  emaMae_ = 0.0f;
  emaAcc_ = 0.0f;
  samplesPerSec_ = 0.0f;
  chunkSteps_ = 0;
  startFill();
}

void Trainer::setConfig(const TrainConfig& in) {
  const int oldPool = cfg_.pool;
  const int oldBatch = cfg_.batch;
  cfg_ = in;
  cfg_.batch = std::min(std::max(cfg_.batch, 32), 2048);
  cfg_.pool = std::min(std::max(cfg_.pool, cfg_.batch * 4), 32768);
  cfg_.lr = std::min(std::max(cfg_.lr, 1.0e-5f), 1.0e-1f);
  cfg_.maxDepth = std::min(std::max(cfg_.maxDepth, 2), TestSet::kMaxDepth);
  cfg_.threads = std::min(std::max(cfg_.threads, 1), 8);
  cfg_.startDepth = std::min(std::max(cfg_.startDepth, 1), cfg_.maxDepth);
  cfg_.minEpochs = std::min(std::max(cfg_.minEpochs, 1), 16);
  cfg_.maxEpochs = std::min(std::max(cfg_.maxEpochs, cfg_.minEpochs), 32);
  cfg_.accThreshold = std::min(std::max(cfg_.accThreshold, 0.3f), 0.99f);
  cfg_.frontierMix = std::min(std::max(cfg_.frontierMix, 0.0f), 0.9f);
  depth_ = std::min(std::max(depth_, 1), cfg_.maxDepth);
  if (cfg_.pool != oldPool || cfg_.batch != oldBatch) startFill();
}

void Trainer::ensureWorkers(int threads) {
  if (static_cast<int>(workers_.size()) < threads) workers_.resize(static_cast<size_t>(threads));
}

void Trainer::sampleState(Rng& rng, uint8_t* out) const {
  for (int attempt = 0; attempt < 8; ++attempt) {
    int depth = 0;
    if (depth_ >= 2 && rng.uniform() < cfg_.frontierMix) {
      depth = depth_ - 1 + static_cast<int>(rng.below(2));
    } else {
      depth = static_cast<int>(rng.below(static_cast<uint32_t>(depth_ + 1)));
    }
    randomScramble(*puzzle_, rng, depth, out);
    if (!tests_->isHeldOut(puzzle_->hash(out))) return;  // held-out states never reach training, at any depth
  }
  puzzle_->setSolved(out);  // practically unreachable; keeps the held-out guarantee strict
}

void Trainer::adamUpdate(const float* g) {
  ++adamT_;
  const float b1 = 0.9f;
  const float b2 = 0.999f;
  const float eps = 1.0e-8f;
  const float c1 = 1.0f - std::pow(b1, static_cast<float>(adamT_));
  const float c2 = 1.0f - std::pow(b2, static_cast<float>(adamT_));
  const float lrT = cfg_.lr * std::sqrt(c2) / c1;
  float* p = net_.data();
  float* m = m_.data();
  float* v = v_.data();
  const int n = model_->spec.count;
  for (int i = 0; i < n; ++i) {
    const float gi = g[i];
    m[i] = b1 * m[i] + (1.0f - b1) * gi;
    v[i] = b2 * v[i] + (1.0f - b2) * gi * gi;
    p[i] -= lrT * m[i] / (std::sqrt(v[i]) + eps);
  }
}

void Trainer::startFill() {
  phase_ = kFill;
  poolFill_ = 0;
  cursor_ = 0;
  epoch_ = 0;
  epochHits_ = 0;
  epochCount_ = 0;
  const size_t P = static_cast<size_t>(cfg_.pool);
  poolTgt_.assign(P, 0.0f);
  poolFeat_.assign(P * static_cast<size_t>(active_), 0);
}

void Trainer::startFit() {
  phase_ = kFit;
  order_.resize(static_cast<size_t>(cfg_.pool));
  std::iota(order_.begin(), order_.end(), 0);
  for (size_t i = order_.size(); i > 1; --i) {
    const size_t j = rng_.below(static_cast<uint32_t>(i));
    std::swap(order_[i - 1], order_[j]);
  }
  cursor_ = 0;
  epoch_ = 0;
  epochHits_ = 0;
  epochCount_ = 0;
}

void Trainer::endEpoch() {
  const float acc = epochCount_ > 0 ? static_cast<float>(epochHits_) / static_cast<float>(epochCount_) : 0.0f;
  ++epoch_;
  emaAcc_ = acc;
  epochHits_ = 0;
  epochCount_ = 0;
  const bool learned = epoch_ >= cfg_.minEpochs && acc >= cfg_.accThreshold;
  const bool done = learned || epoch_ >= cfg_.maxEpochs;
  if (!done) {
    for (size_t i = order_.size(); i > 1; --i) {
      const size_t j = rng_.below(static_cast<uint32_t>(i));
      std::swap(order_[i - 1], order_[j]);
    }
    cursor_ = 0;
    return;
  }
  target_ = net_;
  ++iterations_;
  if (learned && depth_ < cfg_.maxDepth) ++depth_;
  startFill();
}

void Trainer::fillStep() {
  const int P = cfg_.pool;
  const int A = active_;
  const int threads = std::min(std::max(cfg_.threads, 1), 8);
  ensureWorkers(threads);
  const int chunk = std::min(P - poolFill_, 128 * threads);
  const uint64_t base = rng_.next();
  for (int t = 0; t < threads; ++t) workers_[static_cast<size_t>(t)].rng.reseed(base + 0x9E37ULL * static_cast<uint64_t>(t + 1));

  const Puzzle& pz = *puzzle_;
  const Model& model = *model_;
  const float* target = target_.data();
  const int fill0 = poolFill_;

  parallelFor(threads, [&](int t) {
    Worker& w = workers_[static_cast<size_t>(t)];
    const int a = static_cast<int>(static_cast<int64_t>(chunk) * t / threads);
    const int b = static_cast<int>(static_cast<int64_t>(chunk) * (t + 1) / threads);
    uint8_t s[kMaxAiStickers];
    uint8_t c[kMaxAiStickers];
    for (int k = a; k < b; ++k) {
      sampleState(w.rng, s);
      float tgt = 0.0f;
      if (!pz.isSolved(s)) {
        float best = 1.0e9f;
        for (int m : pz.aiMoves) {
          pz.apply(s, c, m);
          const float v = pz.isSolved(c) ? 0.0f : valueOf(model, target, c);
          if (v < best) best = v;
        }
        tgt = 1.0f + best;
      }
      int* f = &poolFeat_[static_cast<size_t>(fill0 + k) * static_cast<size_t>(A)];
      if (model.enc.encode(s, f) != A) {  // cannot happen for states reached by legal moves
        model.enc.encode(pz.solved.data(), f);
        tgt = 0.0f;
      }
      poolTgt_[static_cast<size_t>(fill0 + k)] = tgt;
    }
  });

  poolFill_ += chunk;
  if (poolFill_ >= P) startFit();
}

void Trainer::fitStep() {
  const int batch = cfg_.batch;
  const int A = active_;
  const int threads = std::min(std::max(cfg_.threads, 1), 8);
  ensureWorkers(threads);
  const size_t count = static_cast<size_t>(model_->spec.count);
  for (int t = 0; t < threads; ++t) {
    Worker& w = workers_[static_cast<size_t>(t)];
    if (w.grad.size() != count) {
      w.grad.assign(count, 0.0f);
    } else {
      std::fill(w.grad.begin(), w.grad.end(), 0.0f);
    }
    w.lossSum = 0.0;
    w.absSum = 0.0;
    w.hits = 0;
    w.count = 0;
  }

  const NetSpec& spec = model_->spec;
  const float* net = net_.data();
  const float invBatch = 1.0f / static_cast<float>(batch);
  const float delta = 2.0f;  // Huber threshold in moves
  const int first = cursor_;

  parallelFor(threads, [&](int t) {
    Worker& w = workers_[static_cast<size_t>(t)];
    const int b0 = static_cast<int>(static_cast<int64_t>(batch) * t / threads);
    const int b1 = static_cast<int>(static_cast<int64_t>(batch) * (t + 1) / threads);
    Activations act;
    for (int b = b0; b < b1; ++b) {
      const size_t idx = static_cast<size_t>(order_[static_cast<size_t>(first + b)]);
      const int* feats = &poolFeat_[idx * static_cast<size_t>(A)];
      const float tgt = poolTgt_[idx];
      const float out = forward(spec, net, feats, A, act);
      const float err = out * kValueScale - tgt;
      const float aerr = std::fabs(err);
      w.absSum += aerr;
      w.lossSum += aerr <= delta ? 0.5 * err * err : delta * (aerr - 0.5 * delta);
      if (aerr < 0.5f) ++w.hits;
      ++w.count;
      const float clipped = err > delta ? delta : (err < -delta ? -delta : err);
      backward(spec, net, w.grad.data(), feats, A, act, clipped * kValueScale * invBatch);
    }
  });

  std::vector<float>& g = workers_[0].grad;
  for (int t = 1; t < threads; ++t) {
    const std::vector<float>& o = workers_[static_cast<size_t>(t)].grad;
    for (size_t i = 0; i < count; ++i) g[i] += o[i];
  }
  float sq0 = 0.0f;
  float sq1 = 0.0f;
  float sq2 = 0.0f;
  float sq3 = 0.0f;
  size_t i = 0;
  for (; i + 4 <= count; i += 4) {
    sq0 += g[i] * g[i];
    sq1 += g[i + 1] * g[i + 1];
    sq2 += g[i + 2] * g[i + 2];
    sq3 += g[i + 3] * g[i + 3];
  }
  for (; i < count; ++i) sq0 += g[i] * g[i];
  const float norm = std::sqrt((sq0 + sq1) + (sq2 + sq3));
  const float clipNorm = 20.0f;
  if (std::isfinite(norm)) {
    if (norm > clipNorm) {
      const float scale = clipNorm / norm;
      for (float& x : g) x *= scale;
    }
    adamUpdate(g.data());
  }

  double loss = 0.0;
  double absErr = 0.0;
  int hits = 0;
  int n = 0;
  for (int t = 0; t < threads; ++t) {
    const Worker& w = workers_[static_cast<size_t>(t)];
    loss += w.lossSum;
    absErr += w.absSum;
    hits += w.hits;
    n += w.count;
  }
  if (n > 0) {
    const float bl = static_cast<float>(loss / n);
    const float bm = static_cast<float>(absErr / n);
    const float a = steps_ == 0 ? 1.0f : 0.1f;
    emaLoss_ += a * (bl - emaLoss_);
    emaMae_ += a * (bm - emaMae_);
    epochHits_ += hits;
    epochCount_ += n;
    // Live accuracy: running value inside the epoch, replaced by the exact epoch figure at its end.
    emaAcc_ += 0.1f * (static_cast<float>(hits) / static_cast<float>(n) - emaAcc_);
  }

  ++steps_;
  samples_ += batch;
  cursor_ += batch;
  if (cursor_ + batch > cfg_.pool) endEpoch();
}

void Trainer::step() {
  if (phase_ == kFill) {
    fillStep();
  } else {
    fitStep();
  }
}

TrainStats Trainer::run(int budgetMs) {
  const auto t0 = std::chrono::steady_clock::now();
  const int64_t startSamples = samples_;
  chunkSteps_ = 0;
  for (;;) {
    step();
    ++chunkSteps_;
    const auto now = std::chrono::steady_clock::now();
    if (std::chrono::duration_cast<std::chrono::milliseconds>(now - t0).count() >= budgetMs) break;
  }
  const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  samplesPerSec_ = sec > 0.0 ? static_cast<float>(static_cast<double>(samples_ - startSamples) / sec) : 0.0f;
  return stats();
}

TrainStats Trainer::stats() const {
  TrainStats s;
  s.steps = steps_;
  s.samples = samples_;
  s.iterations = iterations_;
  s.depth = depth_;
  s.loss = emaLoss_;
  s.mae = emaMae_;
  s.accuracy = emaAcc_;
  s.samplesPerSec = samplesPerSec_;
  s.lr = cfg_.lr;
  s.phase = phase_ == kFill ? 0 : 1;
  if (phase_ == kFill) {
    s.progress = cfg_.pool > 0 ? static_cast<float>(poolFill_) / static_cast<float>(cfg_.pool) : 0.0f;
  } else {
    const float e = static_cast<float>(epoch_) + (cfg_.pool > 0 ? static_cast<float>(cursor_) / static_cast<float>(cfg_.pool) : 0.0f);
    s.progress = std::min(1.0f, e / static_cast<float>(std::max(cfg_.maxEpochs, 1)));
  }
  s.epoch = epoch_;
  s.threads = cfg_.threads;
  s.batch = cfg_.batch;
  s.pool = cfg_.pool;
  s.maxDepth = cfg_.maxDepth;
  s.chunkSteps = chunkSteps_;
  return s;
}

bool Trainer::save(std::FILE* f) const {
  const NetSpec& sp = model_->spec;
  const uint32_t puzzleId = static_cast<uint32_t>(puzzle_->id);
  const uint32_t dims[4] = {static_cast<uint32_t>(sp.nFeat), static_cast<uint32_t>(sp.h1),
                            static_cast<uint32_t>(sp.h2), static_cast<uint32_t>(sp.count)};
  bool ok = std::fwrite(kMagic, 1, 4, f) == 4;
  ok = ok && writeVal(f, kVersion) && writeVal(f, puzzleId);
  ok = ok && std::fwrite(dims, sizeof(uint32_t), 4, f) == 4;
  ok = ok && writeVal(f, steps_) && writeVal(f, samples_) && writeVal(f, adamT_);
  ok = ok && writeVal(f, iterations_) && writeVal(f, depth_);
  ok = ok && writeVal(f, emaLoss_) && writeVal(f, emaMae_) && writeVal(f, emaAcc_);
  const uint64_t rngState = rng_.state();
  ok = ok && writeVal(f, rngState);
  ok = ok && writeVec(f, net_) && writeVec(f, target_) && writeVec(f, m_) && writeVec(f, v_);
  ok = ok && std::fwrite(kEnd, 1, 4, f) == 4;
  return ok;
}

bool Trainer::load(std::FILE* f) {
  const NetSpec& sp = model_->spec;
  char magic[4] = {0, 0, 0, 0};
  uint32_t version = 0;
  uint32_t puzzleId = 0;
  uint32_t dims[4] = {0, 0, 0, 0};
  if (std::fread(magic, 1, 4, f) != 4 || std::memcmp(magic, kMagic, 4) != 0) return false;
  if (!readVal(f, version) || version != kVersion) return false;
  if (!readVal(f, puzzleId) || puzzleId != static_cast<uint32_t>(puzzle_->id)) return false;
  if (std::fread(dims, sizeof(uint32_t), 4, f) != 4) return false;
  if (dims[0] != static_cast<uint32_t>(sp.nFeat) || dims[1] != static_cast<uint32_t>(sp.h1) ||
      dims[2] != static_cast<uint32_t>(sp.h2) || dims[3] != static_cast<uint32_t>(sp.count)) {
    return false;
  }

  int64_t steps = 0;
  int64_t samples = 0;
  int64_t adamT = 0;
  int iterations = 0;
  int depth = 0;
  float emaLoss = 0.0f;
  float emaMae = 0.0f;
  float emaAcc = 0.0f;
  uint64_t rngState = 0;
  std::vector<float> net;
  std::vector<float> target;
  std::vector<float> m;
  std::vector<float> v;
  const size_t n = static_cast<size_t>(sp.count);
  bool ok = readVal(f, steps) && readVal(f, samples) && readVal(f, adamT);
  ok = ok && readVal(f, iterations) && readVal(f, depth);
  ok = ok && readVal(f, emaLoss) && readVal(f, emaMae) && readVal(f, emaAcc);
  ok = ok && readVal(f, rngState);
  ok = ok && readVec(f, net, n) && readVec(f, target, n) && readVec(f, m, n) && readVec(f, v, n);
  char end[4] = {0, 0, 0, 0};
  ok = ok && std::fread(end, 1, 4, f) == 4 && std::memcmp(end, kEnd, 4) == 0;
  if (!ok) return false;
  if (!allFinite(net) || !allFinite(target) || !allFinite(m) || !allFinite(v)) return false;
  if (steps < 0 || samples < 0 || adamT < 0 || iterations < 0 || depth < 1) return false;

  net_.swap(net);
  target_.swap(target);
  m_.swap(m);
  v_.swap(v);
  steps_ = steps;
  samples_ = samples;
  adamT_ = adamT;
  iterations_ = iterations;
  depth_ = std::min(std::max(depth, 1), cfg_.maxDepth);
  emaLoss_ = emaLoss;
  emaMae_ = emaMae;
  emaAcc_ = emaAcc;
  rng_.setState(rngState);
  samplesPerSec_ = 0.0f;
  chunkSteps_ = 0;
  startFill();  // the pool of an interrupted round is not stored
  return true;
}

}  // namespace rubik
