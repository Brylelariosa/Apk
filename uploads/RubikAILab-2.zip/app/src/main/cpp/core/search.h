#pragma once
// Weighted A* search over puzzle states, with pluggable heuristics.
//
//   f(n) = lambda * g(n) + h(n)
//
// lambda = 1 is classic A*, smaller values trade solution length for speed (lambda = 0 is greedy).
// The search only ever sees the colours of the stickers: it has no idea how the puzzle was scrambled.

#include <atomic>
#include <cstdint>
#include <vector>

#include "net.h"

namespace rubik {

class Heuristic {
 public:
  virtual ~Heuristic() = default;
  virtual float estimate(const uint8_t* state) const = 0;
};

// Learned heuristic: the value network.
class NetHeuristic : public Heuristic {
 public:
  NetHeuristic(const Model& model, const float* params) : model_(model), params_(params) {}
  float estimate(const uint8_t* state) const override { return estimateCost(model_, params_, state); }

 private:
  const Model& model_;
  const float* params_;
};

// Conventional baseline (no learning): one move changes at most maxMoved(c) pieces of class c, so
// ceil(wrong pieces of c / maxMoved(c)) is an admissible lower bound; use the largest over all classes.
class MisplacedHeuristic : public Heuristic {
 public:
  explicit MisplacedHeuristic(const Model& model) : model_(model) {}
  float estimate(const uint8_t* state) const override;

 private:
  const Model& model_;
};

enum SearchStatus {
  kSolved = 0,
  kNodeLimit = 1,
  kTimeout = 2,
  kCancelled = 3,
  kInvalid = 4,
};

struct SearchConfig {
  int maxExpansions = 20000;
  int maxNodes = 400000;
  float lambda = 0.6f;
  int timeoutMs = 20000;
};

struct SearchResult {
  int status = kInvalid;
  int expanded = 0;
  int generated = 0;
  int elapsedMs = 0;
  std::vector<uint8_t> moves;  // move indices, in the order they must be applied
};

SearchResult solveWeightedAStar(const Model& model, const uint8_t* start, const Heuristic& heuristic,
                                const SearchConfig& cfg, const std::atomic<bool>* cancel);

}  // namespace rubik
