#include "puzzle.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <memory>
#include <mutex>
#include <numeric>

namespace rubik {
namespace {

struct V3 {
  float x, y, z;
};

inline V3 operator+(V3 a, V3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline V3 operator-(V3 a, V3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline V3 operator*(V3 a, float s) { return {a.x * s, a.y * s, a.z * s}; }
inline float dot(V3 a, V3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 cross(V3 a, V3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline float length(V3 a) { return std::sqrt(dot(a, a)); }

inline V3 unit(V3 a) {
  const float l = length(a);
  return l > 0.f ? a * (1.f / l) : a;
}

const float kMatchTol = 2.0e-3f;   // centre / normal matching
const float kLayerTol = 1.0e-3f;   // layer membership

// v rotated by angleDeg about the unit axis a (right-hand rule).
V3 rotateAbout(V3 a, float angleDeg, V3 v) {
  const double th = static_cast<double>(angleDeg) * 3.14159265358979323846 / 180.0;
  const float c = static_cast<float>(std::cos(th));
  const float s = static_cast<float>(std::sin(th));
  return v * c + cross(a, v) * s + a * (dot(a, v) * (1.f - c));
}

V3 centroidOf(const Puzzle& p, int i) {
  return {p.centroid[static_cast<size_t>(i * 3)], p.centroid[static_cast<size_t>(i * 3 + 1)],
          p.centroid[static_cast<size_t>(i * 3 + 2)]};
}

V3 normalOf(const Puzzle& p, int i) {
  return {p.normal[static_cast<size_t>(i * 3)], p.normal[static_cast<size_t>(i * 3 + 1)],
          p.normal[static_cast<size_t>(i * 3 + 2)]};
}

V3 vertexOf(const Puzzle& p, int i, int k) {
  const size_t o = static_cast<size_t>(i * 12 + k * 3);
  return {p.verts[o], p.verts[o + 1], p.verts[o + 2]};
}

V3 axisOf(const MoveInfo& m) { return {m.axis[0], m.axis[1], m.axis[2]}; }

bool inLayer(const MoveInfo& m, V3 point) {
  const float pr = dot(point, axisOf(m));
  return pr >= m.lo - kLayerTol && pr <= m.hi + kLayerTol;
}

// ------------------------------------------------------------------------------------------ building blocks

// Corners are counter-clockwise as seen from outside, so the first three give the outward normal.
void addSticker(Puzzle& p, int color, int face, const V3* v, int n) {
  V3 c = {0.f, 0.f, 0.f};
  for (int k = 0; k < 4; ++k) {
    const V3 q = v[k < n ? k : n - 1];
    p.verts.push_back(q.x);
    p.verts.push_back(q.y);
    p.verts.push_back(q.z);
  }
  for (int k = 0; k < n; ++k) c = c + v[k];
  c = c * (1.f / static_cast<float>(n));
  const V3 nrm = unit(cross(v[1] - v[0], v[2] - v[0]));
  p.vcount.push_back(static_cast<uint8_t>(n));
  p.normal.push_back(nrm.x);
  p.normal.push_back(nrm.y);
  p.normal.push_back(nrm.z);
  p.centroid.push_back(c.x);
  p.centroid.push_back(c.y);
  p.centroid.push_back(c.z);
  p.solved.push_back(static_cast<uint8_t>(color));
  p.faceOf.push_back(static_cast<uint8_t>(face));
  p.stickers += 1;
}

// Adds a clockwise / counter-clockwise pair of turns of one layer.
void addMovePair(Puzzle& p, const std::string& name, V3 axis, float stepDeg, float lo, float hi) {
  const int base = static_cast<int>(p.move.size());
  const V3 a = unit(axis);
  for (int dir = 0; dir < 2; ++dir) {
    MoveInfo m;
    m.axis[0] = a.x;
    m.axis[1] = a.y;
    m.axis[2] = a.z;
    m.angleDeg = dir == 0 ? -stepDeg : stepDeg;
    m.lo = lo;
    m.hi = hi;
    m.inverse = base + (1 - dir);
    m.name = dir == 0 ? name : name + "'";
    p.move.push_back(m);
  }
  p.moves = static_cast<int>(p.move.size());
}

// ------------------------------------------------------------------------------------------ solid pieces
//
// Every puzzle is cut into rigid pieces by the planes its moves turn about. A piece is one cell of that plane
// arrangement inside the outer solid, so it lies entirely inside or entirely outside every turning layer and
// therefore turns with a layer or stays put, never half of each. Cells are pulled half a gap away from every
// cut plane, so neighbours never touch while a layer turns, and their edges are chamfered a little so the
// pieces read as moulded plastic. All arithmetic is in double precision; only the result is stored as float.
namespace solid {

struct Vec {
  double x, y, z;
};

inline Vec operator+(Vec a, Vec b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline Vec operator-(Vec a, Vec b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline Vec operator*(Vec a, double s) { return {a.x * s, a.y * s, a.z * s}; }
inline double dotv(Vec a, Vec b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline Vec crossv(Vec a, Vec b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline double normv(Vec a) { return std::sqrt(dotv(a, a)); }
inline Vec unitv(Vec a) {
  const double l = normv(a);
  return l > 0.0 ? a * (1.0 / l) : a;
}

// The half-space dot(n, x) <= d, with |n| = 1.
struct Plane {
  Vec n;
  double d;
};

typedef std::vector<Vec> Poly;

const double kOn = 1.0e-9;  // a point closer than this to a plane lies on it

// Sutherland-Hodgman: the part of a convex polygon inside the half-space.
Poly clipPoly(const Poly& in, const Plane& pl) {
  Poly out;
  const size_t cnt = in.size();
  for (size_t i = 0; i < cnt; ++i) {
    const Vec a = in[i];
    const Vec b = in[(i + 1) % cnt];
    const double da = dotv(pl.n, a) - pl.d;
    const double db = dotv(pl.n, b) - pl.d;
    const int sa = da > kOn ? 1 : (da < -kOn ? -1 : 0);
    const int sb = db > kOn ? 1 : (db < -kOn ? -1 : 0);
    if (sa <= 0) out.push_back(a);
    if (sa * sb < 0) out.push_back(a + (b - a) * (da / (da - db)));
  }
  return out;
}

double polyArea(const Poly& p) {
  Vec s = {0.0, 0.0, 0.0};
  for (size_t i = 0; i < p.size(); ++i) s = s + crossv(p[i], p[(i + 1) % p.size()]);
  return 0.5 * normv(s);
}

void dropRepeats(Poly& p) {
  Poly q;
  for (const Vec& a : p) {
    if (q.empty() || normv(a - q.back()) > 1.0e-7) q.push_back(a);
  }
  while (q.size() > 1 && normv(q.front() - q.back()) <= 1.0e-7) q.pop_back();
  p.swap(q);
}

Vec polyCentre(const Poly& p) {
  Vec c = {0.0, 0.0, 0.0};
  for (const Vec& v : p) c = c + v;
  return p.empty() ? c : c * (1.0 / static_cast<double>(p.size()));
}

// A convex solid given by its half-spaces; faces[i] is the part of plane i that bounds it (empty if redundant),
// counter-clockwise seen from outside.
struct Convex {
  std::vector<Plane> hs;
  std::vector<Poly> faces;
};

Poly faceOf(const std::vector<Plane>& hs, size_t i) {
  const Plane& pl = hs[i];
  const Vec helper = std::fabs(pl.n.x) < 0.9 ? Vec{1.0, 0.0, 0.0} : Vec{0.0, 1.0, 0.0};
  const Vec u = unitv(crossv(pl.n, helper));
  const Vec v = crossv(pl.n, u);  // u x v = n, so the square below runs counter-clockwise seen from outside
  const Vec c = pl.n * pl.d;
  const double big = 64.0;
  Poly poly = {c - u * big - v * big, c + u * big - v * big, c + u * big + v * big, c - u * big + v * big};
  for (size_t j = 0; j < hs.size() && !poly.empty(); ++j) {
    if (j != i) poly = clipPoly(poly, hs[j]);
  }
  dropRepeats(poly);
  if (poly.size() < 3 || polyArea(poly) < 1.0e-7) poly.clear();
  return poly;
}

void buildFaces(Convex& s) {
  s.faces.assign(s.hs.size(), Poly());
  for (size_t i = 0; i < s.hs.size(); ++i) s.faces[i] = faceOf(s.hs, i);
}

Vec convexCentre(const Convex& s) {
  Vec c = {0.0, 0.0, 0.0};
  int n = 0;
  for (const Poly& f : s.faces) {
    for (const Vec& v : f) {
      c = c + v;
      ++n;
    }
  }
  return n > 0 ? c * (1.0 / static_cast<double>(n)) : c;
}

// Smallest and largest signed distance of the solid's corners from a plane.
void spread(const Convex& s, const Plane& pl, double* lo, double* hi) {
  *lo = 1.0e30;
  *hi = -1.0e30;
  for (const Poly& f : s.faces) {
    for (const Vec& v : f) {
      const double t = dotv(pl.n, v) - pl.d;
      if (t < *lo) *lo = t;
      if (t > *hi) *hi = t;
    }
  }
}

bool samePlane(const Plane& a, const Plane& b) {
  return normv(a.n - b.n) < 1.0e-6 && std::fabs(a.d - b.d) < 1.0e-6;
}

// The distinct planes that the moves turn about and that pass through the inside of the outer solid.
std::vector<Plane> cutPlanes(const Puzzle& p, const Convex& outer) {
  std::vector<Plane> cuts;
  for (const MoveInfo& m : p.move) {
    const Vec a = unitv(Vec{m.axis[0], m.axis[1], m.axis[2]});
    const double bounds[2] = {m.lo, m.hi};
    for (int k = 0; k < 2; ++k) {
      Plane pl = {a, bounds[k]};
      const double lead = std::fabs(a.x) > 1.0e-6 ? a.x : (std::fabs(a.y) > 1.0e-6 ? a.y : a.z);
      if (lead < 0.0) pl = {a * -1.0, -bounds[k]};  // one description per plane
      double lo = 0.0;
      double hi = 0.0;
      spread(outer, pl, &lo, &hi);
      if (!(lo < -1.0e-4 && hi > 1.0e-4)) continue;  // misses the solid (or only grazes it)
      bool known = false;
      for (const Plane& c : cuts) known = known || samePlane(c, pl);
      if (!known) cuts.push_back(pl);
    }
  }
  return cuts;
}

// Splits the outer solid by every cut plane, keeping `gap` between the two sides of each cut.
std::vector<Convex> cellsOf(const std::vector<Plane>& outerPlanes, const std::vector<Plane>& cuts, double gap) {
  std::vector<Convex> cells(1);
  cells[0].hs = outerPlanes;
  buildFaces(cells[0]);
  for (const Plane& cut : cuts) {
    std::vector<Convex> next;
    for (const Convex& c : cells) {
      double lo = 0.0;
      double hi = 0.0;
      spread(c, cut, &lo, &hi);
      if (lo < -1.0e-6 && hi > 1.0e-6) {
        Convex below = c;
        Convex above = c;
        below.hs.push_back({cut.n, cut.d - gap * 0.5});
        above.hs.push_back({cut.n * -1.0, -(cut.d + gap * 0.5)});
        buildFaces(below);
        buildFaces(above);
        next.push_back(below);
        next.push_back(above);
      } else {
        next.push_back(c);
      }
    }
    cells.swap(next);
  }
  return cells;
}

// Cuts a flat chamfer of width `c` along every edge of the solid.
void chamferEdges(Convex& s, double c) {
  const size_t n = s.hs.size();
  const Vec ctr = convexCentre(s);
  double inner = 1.0e30;  // distance from the centre to the nearest face
  for (size_t i = 0; i < n; ++i) {
    if (!s.faces[i].empty()) inner = std::min(inner, s.hs[i].d - dotv(s.hs[i].n, ctr));
  }
  c = std::min(c, 0.3 * inner);
  if (c < 1.0e-5) return;
  std::vector<Plane> extra;
  for (size_t i = 0; i < n; ++i) {
    if (s.faces[i].empty()) continue;
    for (size_t j = i + 1; j < n; ++j) {
      if (s.faces[j].empty()) continue;
      std::vector<Vec> shared;  // corners of face i that lie on plane j: the edge between the two faces
      for (const Vec& v : s.faces[i]) {
        if (std::fabs(dotv(s.hs[j].n, v) - s.hs[j].d) < 1.0e-7) shared.push_back(v);
      }
      if (shared.size() < 2) continue;
      Vec pa = shared[0];
      Vec pb = shared[0];
      double longest = 0.0;
      for (size_t a = 0; a < shared.size(); ++a) {
        for (size_t b = a + 1; b < shared.size(); ++b) {
          const double len = normv(shared[a] - shared[b]);
          if (len > longest) {
            longest = len;
            pa = shared[a];
            pb = shared[b];
          }
        }
      }
      if (longest < 1.0e-5) continue;
      const Vec bis = s.hs[i].n + s.hs[j].n;
      if (normv(bis) < 0.2) continue;  // nearly opposite faces: no real edge
      const Vec mid = (pa + pb) * 0.5;
      const Vec dir = unitv(pb - pa);
      Vec in = polyCentre(s.faces[i]) - mid;
      in = unitv(in - dir * dotv(in, dir));  // into face i, away from the edge
      const Vec nc = unitv(bis);
      extra.push_back({nc, dotv(nc, mid + in * c)});
    }
  }
  for (const Plane& pl : extra) s.hs.push_back(pl);
  buildFaces(s);
}

void emitTriangles(const Convex& s, BodyPiece& bp) {
  for (size_t i = 0; i < s.hs.size(); ++i) {
    const Poly& f = s.faces[i];
    if (f.size() < 3) continue;
    const Vec nrm = s.hs[i].n;
    for (size_t k = 1; k + 1 < f.size(); ++k) {
      const Vec* t[3] = {&f[0], &f[k], &f[k + 1]};
      for (int q = 0; q < 3; ++q) {
        bp.tris.push_back(static_cast<float>(t[q]->x));
        bp.tris.push_back(static_cast<float>(t[q]->y));
        bp.tris.push_back(static_cast<float>(t[q]->z));
      }
      bp.tris.push_back(static_cast<float>(nrm.x));
      bp.tris.push_back(static_cast<float>(nrm.y));
      bp.tris.push_back(static_cast<float>(nrm.z));
    }
  }
}

}  // namespace solid

// Fills p.bodies: one chamfered solid per piece of the puzzle, found by cutting the outer solid (given as its
// bounding planes) with every plane that a move turns about.
void addSolidBodies(Puzzle& p, const std::vector<solid::Plane>& outer, double gap, double chamfer) {
  solid::Convex root;
  root.hs = outer;
  solid::buildFaces(root);
  const std::vector<solid::Plane> cuts = solid::cutPlanes(p, root);
  std::vector<solid::Convex> cells = solid::cellsOf(outer, cuts, gap);
  for (solid::Convex& cell : cells) {
    BodyPiece bp;
    const solid::Vec ctr = solid::convexCentre(cell);  // decides which layers the piece is in
    bp.cls[0] = static_cast<float>(ctr.x);
    bp.cls[1] = static_cast<float>(ctr.y);
    bp.cls[2] = static_cast<float>(ctr.z);
    solid::chamferEdges(cell, chamfer);
    solid::emitTriangles(cell, bp);
    p.bodies.push_back(bp);
  }
}

// The six bounding planes of an axis-aligned cube of half-width h.
std::vector<solid::Plane> cubePlanes(double h) {
  std::vector<solid::Plane> out;
  for (int a = 0; a < 3; ++a) {
    for (int sgn = -1; sgn <= 1; sgn += 2) {
      solid::Vec n = {0.0, 0.0, 0.0};
      (a == 0 ? n.x : (a == 1 ? n.y : n.z)) = static_cast<double>(sgn);
      out.push_back({n, h});
    }
  }
  return out;
}

int findSticker(const Puzzle& p, V3 c, V3 n) {
  for (int j = 0; j < p.stickers; ++j) {
    if (length(centroidOf(p, j) - c) < kMatchTol && length(normalOf(p, j) - n) < kMatchTol) return j;
  }
  return -1;
}

// perm[m][j] = i means: after the move, position j shows what position i showed before.
bool buildPerms(Puzzle& p) {
  p.perm.assign(static_cast<size_t>(p.moves), std::vector<uint8_t>(static_cast<size_t>(p.stickers), 0));
  for (int m = 0; m < p.moves; ++m) {
    const MoveInfo& mv = p.move[static_cast<size_t>(m)];
    std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
    const V3 axis = axisOf(mv);
    std::vector<bool> inSet(static_cast<size_t>(p.stickers), false);
    std::vector<bool> hit(static_cast<size_t>(p.stickers), false);
    for (int i = 0; i < p.stickers; ++i) {
      pm[static_cast<size_t>(i)] = static_cast<uint8_t>(i);
      inSet[static_cast<size_t>(i)] = inLayer(mv, centroidOf(p, i));
    }
    for (int i = 0; i < p.stickers; ++i) {
      if (!inSet[static_cast<size_t>(i)]) continue;
      const V3 c2 = rotateAbout(axis, mv.angleDeg, centroidOf(p, i));
      const V3 n2 = rotateAbout(axis, mv.angleDeg, normalOf(p, i));
      const int j = findSticker(p, c2, n2);
      // The turning layer must be carried onto itself, one sticker per position.
      if (j < 0 || !inSet[static_cast<size_t>(j)] || hit[static_cast<size_t>(j)]) return false;
      hit[static_cast<size_t>(j)] = true;
      pm[static_cast<size_t>(j)] = static_cast<uint8_t>(i);
    }
  }
  return true;
}

void buildFaces(Puzzle& p) {
  p.faceBegin.assign(static_cast<size_t>(p.faces) + 1, 0);
  p.faceList.clear();
  for (int f = 0; f < p.faces; ++f) {
    p.faceBegin[static_cast<size_t>(f)] = static_cast<int>(p.faceList.size());
    for (int i = 0; i < p.stickers; ++i) {
      if (p.faceOf[static_cast<size_t>(i)] == f) p.faceList.push_back(i);
    }
  }
  p.faceBegin[static_cast<size_t>(p.faces)] = static_cast<int>(p.faceList.size());
}

// ------------------------------------------------------------------------------------------ cubes

const float kFaceNormal[6][3] = {{0, 1, 0}, {1, 0, 0}, {0, 0, 1}, {0, -1, 0}, {-1, 0, 0}, {0, 0, -1}};
const float kFaceUp[6][3] = {{0, 0, -1}, {0, 1, 0}, {0, 1, 0}, {0, 0, 1}, {0, 1, 0}, {0, 1, 0}};
const float kFaceRight[6][3] = {{1, 0, 0}, {0, 0, -1}, {1, 0, 0}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}};
const char kFaceName[7] = "URFDLB";

V3 faceVec(const float (*table)[3], int f) { return {table[f][0], table[f][1], table[f][2]}; }

void buildCube(Puzzle& p, int n) {
  p.id = n - 2;
  p.name = std::to_string(n) + "x" + std::to_string(n) + " Cube";
  p.shortName = std::to_string(n) + "x" + std::to_string(n);
  p.colors = 6;
  p.faces = 6;
  const float half = static_cast<float>(n) * 0.5f;
  const float mid = static_cast<float>(n - 1) * 0.5f;

  for (int f = 0; f < 6; ++f) {
    const V3 nrm = faceVec(kFaceNormal, f);
    const V3 up = faceVec(kFaceUp, f);
    const V3 right = faceVec(kFaceRight, f);
    for (int r = 0; r < n; ++r) {
      for (int c = 0; c < n; ++c) {
        const V3 ctr = nrm * half + right * (static_cast<float>(c) - mid) + up * (mid - static_cast<float>(r));
        const V3 corners[4] = {ctr - right * 0.5f - up * 0.5f, ctr + right * 0.5f - up * 0.5f,
                               ctr + right * 0.5f + up * 0.5f, ctr - right * 0.5f + up * 0.5f};
        addSticker(p, f, f, corners, 4);
      }
    }
  }

  // Face turns (the outer layer), then the inner slices counted from U, R and F.
  for (int f = 0; f < 6; ++f) {
    addMovePair(p, std::string(1, kFaceName[f]), faceVec(kFaceNormal, f), 90.f, half - 1.f, half + 0.01f);
  }
  for (int f = 0; f < 3; ++f) {
    for (int k = 1; k <= n - 2; ++k) {
      const float cc = half - static_cast<float>(k) - 0.5f;
      addMovePair(p, std::to_string(k + 1) + std::string(1, kFaceName[f]), faceVec(kFaceNormal, f), 90.f,
                  cc - 0.5f, cc + 0.5f);
    }
  }

  // Bodies: one chamfered block per cubie (the cells of the layer planes), a hair apart so layers turn freely.
  addSolidBodies(p, cubePlanes(static_cast<double>(half)), 0.010, 0.022);

  p.radius = half * 1.7320508f + 0.05f;
  p.stickerInset = 0.03f;   // dark margin around every sticker, in cubie widths
  p.stickerRound = 0.11f;   // corner radius of the coloured tile
  p.stickerLift = 0.006f;   // tile height above the block

  p.aiSupported = n <= 3;
  if (n == 2) {
    for (int m = 0; m < 6; ++m) p.aiMoves.push_back(m);  // U, R, F: the corner D-L-B never moves
    p.defaultMaxDepth = 12;
    p.hidden1 = 128;
    p.hidden2 = 64;
  } else if (n == 3) {
    for (int m = 0; m < 12; ++m) p.aiMoves.push_back(m);
    p.defaultMaxDepth = 16;
    p.hidden1 = 192;
    p.hidden2 = 96;
  }
}

// ------------------------------------------------------------------------------------------ Pyraminx

void buildPyraminx(Puzzle& p) {
  p.id = kPyraminx;
  p.name = "Pyraminx";
  p.shortName = "Pyraminx";
  p.colors = 4;
  p.faces = 4;
  const float R = 2.3f;
  const float rho = R * 0.94280904f;  // sqrt(8) / 3
  // 0 = U (top), 1 = L, 2 = R, 3 = B
  const V3 vert[4] = {{0.f, R, 0.f},
                      {-rho * 0.8660254f, -R / 3.f, rho * 0.5f},
                      {rho * 0.8660254f, -R / 3.f, rho * 0.5f},
                      {0.f, -R / 3.f, -rho}};
  // Face f lies opposite vertex f' where f' = {0, 1, 2, 3}[f]; face 3 is the front face (U, L, R).
  const int faceVerts[4][3] = {{1, 2, 3}, {0, 2, 3}, {0, 1, 3}, {0, 1, 2}};

  for (int f = 0; f < 4; ++f) {
    V3 p0 = vert[faceVerts[f][0]];
    V3 p1 = vert[faceVerts[f][1]];
    V3 p2 = vert[faceVerts[f][2]];
    if (dot(cross(p1 - p0, p2 - p0), p0 + p1 + p2) < 0.f) std::swap(p1, p2);  // counter-clockwise from outside
    auto Q = [&](int i, int j) { return p0 + (p1 - p0) * (static_cast<float>(i) / 3.f) + (p2 - p0) * (static_cast<float>(j) / 3.f); };
    for (int i = 0; i < 3; ++i) {
      for (int j = 0; i + j <= 2; ++j) {
        const V3 up[3] = {Q(i, j), Q(i + 1, j), Q(i, j + 1)};
        addSticker(p, f, f, up, 3);
        if (i + j <= 1) {
          const V3 down[3] = {Q(i + 1, j), Q(i + 1, j + 1), Q(i, j + 1)};
          addSticker(p, f, f, down, 3);
        }
      }
    }
  }

  const char* layerNames[4] = {"U", "L", "R", "B"};
  const char* tipNames[4] = {"u", "l", "r", "b"};
  for (int v = 0; v < 4; ++v) {
    addMovePair(p, layerNames[v], vert[v], 120.f, R / 9.f, R + 1.f);
    addMovePair(p, tipNames[v], vert[v], 120.f, 5.f * R / 9.f, R + 1.f);
  }

  // Bodies: the 15 real pieces (4 tips, 4 axial pieces, 6 edges and the hidden core), cut by the layer planes.
  std::vector<solid::Plane> faces;
  for (int f = 0; f < 4; ++f) {
    const V3 a0 = vert[faceVerts[f][0]];
    const V3 a1 = vert[faceVerts[f][1]];
    const V3 a2 = vert[faceVerts[f][2]];
    V3 nrm = unit(cross(a1 - a0, a2 - a0));
    if (dot(nrm, a0) < 0.f) nrm = nrm * -1.f;
    faces.push_back({{nrm.x, nrm.y, nrm.z}, static_cast<double>(dot(nrm, a0))});
  }
  addSolidBodies(p, faces, 0.020, 0.032);

  p.radius = R + 0.05f;
  p.stickerInset = 0.045f;
  p.stickerRound = 0.09f;
  p.stickerLift = 0.006f;
  p.aiSupported = true;
  for (int m = 0; m < p.moves; ++m) p.aiMoves.push_back(m);
  p.defaultMaxDepth = 11;
  p.hidden1 = 128;
  p.hidden2 = 64;
}

// ------------------------------------------------------------------------------------------ Skewb

void buildSkewb(Puzzle& p) {
  p.id = kSkewb;
  p.name = "Skewb";
  p.shortName = "Skewb";
  p.colors = 6;
  p.faces = 6;
  const float S = 1.5f;

  for (int f = 0; f < 6; ++f) {
    const V3 nrm = faceVec(kFaceNormal, f);
    const V3 up = faceVec(kFaceUp, f);
    const V3 right = faceVec(kFaceRight, f);
    auto P = [&](float a, float b) { return (nrm + right * a + up * b) * S; };
    const V3 diamond[4] = {P(1, 0), P(0, 1), P(-1, 0), P(0, -1)};
    addSticker(p, f, f, diamond, 4);
    const V3 t0[3] = {P(1, 1), P(0, 1), P(1, 0)};
    const V3 t1[3] = {P(-1, 1), P(-1, 0), P(0, 1)};
    const V3 t2[3] = {P(-1, -1), P(0, -1), P(-1, 0)};
    const V3 t3[3] = {P(1, -1), P(1, 0), P(0, -1)};
    addSticker(p, f, f, t0, 3);
    addSticker(p, f, f, t1, 3);
    addSticker(p, f, f, t2, 3);
    addSticker(p, f, f, t3, 3);
  }

  // The four corners the solver turns come first; the other four are their opposites.
  const int corners[8][3] = {{1, 1, 1},   {1, 1, -1},  {1, -1, 1},  {-1, 1, 1},
                             {-1, -1, -1}, {-1, -1, 1}, {-1, 1, -1}, {1, -1, -1}};
  for (int k = 0; k < 8; ++k) {
    std::string name;
    name += corners[k][1] > 0 ? 'U' : 'D';
    name += corners[k][0] > 0 ? 'R' : 'L';
    name += corners[k][2] > 0 ? 'F' : 'B';
    const V3 axis = {static_cast<float>(corners[k][0]), static_cast<float>(corners[k][1]),
                     static_cast<float>(corners[k][2])};
    addMovePair(p, name, axis, 120.f, 0.f, 100.f);
  }

  // Bodies: the 14 real pieces (6 centres and 8 corners), cut by the four planes through the middle.
  addSolidBodies(p, cubePlanes(static_cast<double>(S)), 0.016, 0.03);

  p.radius = S * 1.7320508f + 0.05f;
  p.stickerInset = 0.045f;
  p.stickerRound = 0.10f;
  p.stickerLift = 0.006f;
  p.aiSupported = true;
  for (int m = 0; m < 8; ++m) p.aiMoves.push_back(m);  // corners U-R-F, U-R-B, D-R-F, U-L-F; corner D-L-B never moves
  p.defaultMaxDepth = 12;
  p.hidden1 = 128;
  p.hidden2 = 64;
}

// ------------------------------------------------------------------------------------------ structure

struct UnionFind {
  std::vector<int> parent;
  explicit UnionFind(int n) : parent(static_cast<size_t>(n)) { std::iota(parent.begin(), parent.end(), 0); }
  int find(int a) {
    while (parent[static_cast<size_t>(a)] != a) {
      parent[static_cast<size_t>(a)] = parent[static_cast<size_t>(parent[static_cast<size_t>(a)])];
      a = parent[static_cast<size_t>(a)];
    }
    return a;
  }
  void unite(int a, int b) {
    a = find(a);
    b = find(b);
    if (a != b) parent[static_cast<size_t>(std::max(a, b))] = std::min(a, b);
  }
};

bool shareCorner(const Puzzle& p, int a, int b) {
  for (int i = 0; i < p.vcount[static_cast<size_t>(a)]; ++i) {
    for (int j = 0; j < p.vcount[static_cast<size_t>(b)]; ++j) {
      if (length(vertexOf(p, a, i) - vertexOf(p, b, j)) < 1.0e-3f) return true;
    }
  }
  return false;
}

// Pieces = groups of touching stickers that lie in exactly the same turning layers. Classes = pieces that
// can change places under the solver's moves. Fixed pieces never move under the solver's moves.
bool buildStructure(Puzzle& p) {
  const int S = p.stickers;
  std::vector<uint64_t> sig(static_cast<size_t>(S), 0);
  for (int i = 0; i < S; ++i) {
    for (int m = 0; m < p.moves; ++m) {
      if (inLayer(p.move[static_cast<size_t>(m)], centroidOf(p, i))) sig[static_cast<size_t>(i)] |= 1ULL << m;
    }
  }
  UnionFind uf(S);
  for (int i = 0; i < S; ++i) {
    for (int j = i + 1; j < S; ++j) {
      if (sig[static_cast<size_t>(i)] == sig[static_cast<size_t>(j)] && shareCorner(p, i, j)) uf.unite(i, j);
    }
  }
  p.slots.clear();
  p.slotOf.assign(static_cast<size_t>(S), -1);
  std::vector<int> compSlot(static_cast<size_t>(S), -1);
  for (int i = 0; i < S; ++i) {
    const int root = uf.find(i);
    if (compSlot[static_cast<size_t>(root)] < 0) {
      compSlot[static_cast<size_t>(root)] = static_cast<int>(p.slots.size());
      p.slots.push_back(Slot());
    }
    Slot& s = p.slots[static_cast<size_t>(compSlot[static_cast<size_t>(root)])];
    if (s.n >= 3) return false;
    s.stickers[s.n++] = i;
    p.slotOf[static_cast<size_t>(i)] = compSlot[static_cast<size_t>(root)];
  }

  const int nSlots = static_cast<int>(p.slots.size());
  UnionFind orbit(nSlots);
  for (int m : p.aiMoves) {
    const std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
    for (int i = 0; i < S; ++i) {
      if (pm[static_cast<size_t>(i)] != i) {
        orbit.unite(p.slotOf[static_cast<size_t>(i)], p.slotOf[pm[static_cast<size_t>(i)]]);
      }
    }
  }
  std::vector<int> classOfRoot(static_cast<size_t>(nSlots), -1);
  p.classCount = 0;
  for (int s = 0; s < nSlots; ++s) {
    const int root = orbit.find(s);
    if (classOfRoot[static_cast<size_t>(root)] < 0) classOfRoot[static_cast<size_t>(root)] = p.classCount++;
    p.slots[static_cast<size_t>(s)].cls = classOfRoot[static_cast<size_t>(root)];
  }
  // Pieces in one class must all have the same number of stickers.
  std::vector<int> classSize(static_cast<size_t>(p.classCount), -1);
  for (const Slot& s : p.slots) {
    int& sz = classSize[static_cast<size_t>(s.cls)];
    if (sz < 0) sz = s.n;
    if (sz != s.n) return false;
  }

  p.slotFixed.assign(static_cast<size_t>(nSlots), true);
  for (int m : p.aiMoves) {
    const std::vector<uint8_t>& pm = p.perm[static_cast<size_t>(m)];
    for (int i = 0; i < S; ++i) {
      if (pm[static_cast<size_t>(i)] != i) p.slotFixed[static_cast<size_t>(p.slotOf[static_cast<size_t>(i)])] = false;
    }
  }
  return true;
}

// ------------------------------------------------------------------------------------------ symmetry

bool buildRotations(Puzzle& p) {
  using Mat = std::array<int, 9>;
  const Mat identity = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  const Mat rx = {1, 0, 0, 0, 0, -1, 0, 1, 0};   // (x, y, z) -> (x, -z, y)
  const Mat ry = {0, 0, 1, 0, 1, 0, -1, 0, 0};   // (x, y, z) -> (z, y, -x)
  auto mul = [](const Mat& a, const Mat& b) {
    Mat r{};
    for (int i = 0; i < 3; ++i) {
      for (int j = 0; j < 3; ++j) {
        int s = 0;
        for (int k = 0; k < 3; ++k) s += a[static_cast<size_t>(i * 3 + k)] * b[static_cast<size_t>(k * 3 + j)];
        r[static_cast<size_t>(i * 3 + j)] = s;
      }
    }
    return r;
  };
  std::vector<Mat> group;
  group.push_back(identity);
  for (size_t at = 0; at < group.size(); ++at) {
    for (const Mat& g : {rx, ry}) {
      const Mat next = mul(g, group[at]);
      if (std::find(group.begin(), group.end(), next) == group.end()) group.push_back(next);
    }
  }
  if (group.size() != 24) return false;

  p.rotations.clear();
  for (const Mat& m : group) {
    std::vector<uint8_t> rot(static_cast<size_t>(p.stickers), 0);
    auto apply = [&m](V3 v) {
      return V3{static_cast<float>(m[0]) * v.x + static_cast<float>(m[1]) * v.y + static_cast<float>(m[2]) * v.z,
                static_cast<float>(m[3]) * v.x + static_cast<float>(m[4]) * v.y + static_cast<float>(m[5]) * v.z,
                static_cast<float>(m[6]) * v.x + static_cast<float>(m[7]) * v.y + static_cast<float>(m[8]) * v.z};
    };
    for (int j = 0; j < p.stickers; ++j) {
      const int i = findSticker(p, apply(centroidOf(p, j)), apply(normalOf(p, j)));
      if (i < 0) return false;
      rot[static_cast<size_t>(i)] = static_cast<uint8_t>(j);  // the sticker at j travels to i
    }
    p.rotations.push_back(rot);
  }

  // conj[r][m]: the physical move that, applied to the unrotated puzzle, matches solver move m applied to
  // the puzzle rotated by r. perm' = R o perm_m o R^-1 as index maps.
  p.conj.assign(p.rotations.size(), std::vector<int>(static_cast<size_t>(p.moves), -1));
  for (size_t r = 0; r < p.rotations.size(); ++r) {
    const std::vector<uint8_t>& rot = p.rotations[r];
    std::vector<int> inv(static_cast<size_t>(p.stickers), 0);
    for (int i = 0; i < p.stickers; ++i) inv[rot[static_cast<size_t>(i)]] = i;
    for (int m : p.aiMoves) {
      std::vector<uint8_t> target(static_cast<size_t>(p.stickers), 0);
      for (int j = 0; j < p.stickers; ++j) {
        target[static_cast<size_t>(j)] = rot[p.perm[static_cast<size_t>(m)][static_cast<size_t>(inv[static_cast<size_t>(j)])]];
      }
      int found = -1;
      for (int q = 0; q < p.moves; ++q) {
        if (p.perm[static_cast<size_t>(q)] == target) {
          found = q;
          break;
        }
      }
      if (found < 0) return false;
      p.conj[r][static_cast<size_t>(m)] = found;
    }
  }

  p.refStickers.clear();
  for (size_t s = 0; s < p.slots.size(); ++s) {
    if (!p.slotFixed[s]) continue;
    for (int k = 0; k < p.slots[s].n; ++k) p.refStickers.push_back(p.slots[s].stickers[k]);
  }
  return !p.refStickers.empty();
}

std::unique_ptr<Puzzle> build(int id) {
  std::unique_ptr<Puzzle> p(new Puzzle());
  switch (id) {
    case kCube2: buildCube(*p, 2); break;
    case kCube3: buildCube(*p, 3); break;
    case kCube4: buildCube(*p, 4); break;
    case kCube5: buildCube(*p, 5); break;
    case kPyraminx: buildPyraminx(*p); break;
    case kSkewb: buildSkewb(*p); break;
    default: return nullptr;
  }
  buildFaces(*p);
  bool ok = p->stickers <= kMaxStickers && p->moves <= kMaxMoves && buildPerms(*p);
  if (ok && p->aiSupported) {
    ok = p->stickers <= kMaxAiStickers && buildStructure(*p);
    p->needsCanon = static_cast<int>(p->aiMoves.size()) < p->moves;
    if (ok && p->needsCanon) ok = buildRotations(*p);
  }
  p->valid = ok;
  return p;
}

}  // namespace

// ------------------------------------------------------------------------------------------ Puzzle

bool Puzzle::aiMove(int m) const { return std::find(aiMoves.begin(), aiMoves.end(), m) != aiMoves.end(); }

void Puzzle::setSolved(uint8_t* s) const {
  for (int i = 0; i < stickers; ++i) s[i] = solved[static_cast<size_t>(i)];
}

bool Puzzle::isSolved(const uint8_t* s) const {
  for (int f = 0; f < faces; ++f) {
    const int b = faceBegin[static_cast<size_t>(f)];
    const int e = faceBegin[static_cast<size_t>(f) + 1];
    const uint8_t c = s[faceList[static_cast<size_t>(b)]];
    for (int k = b + 1; k < e; ++k) {
      if (s[faceList[static_cast<size_t>(k)]] != c) return false;
    }
  }
  return true;
}

void Puzzle::apply(const uint8_t* src, uint8_t* dst, int move) const {
  const uint8_t* pm = perm[static_cast<size_t>(move)].data();
  for (int i = 0; i < stickers; ++i) dst[i] = src[pm[i]];
}

uint64_t Puzzle::hash(const uint8_t* s) const {
  uint64_t h = 1469598103934665603ULL;
  for (int i = 0; i < stickers; ++i) {
    h ^= s[i];
    h *= 1099511628211ULL;
  }
  h ^= h >> 29;
  return h;
}

void Puzzle::rotate(const uint8_t* s, int r, uint8_t* out) const {
  if (rotations.empty()) {
    std::memcpy(out, s, static_cast<size_t>(stickers));
    return;
  }
  const uint8_t* rp = rotations[static_cast<size_t>(r)].data();
  for (int i = 0; i < stickers; ++i) out[i] = s[rp[i]];
}

int Puzzle::canonRotation(const uint8_t* s) const {
  if (!needsCanon) return 0;
  for (size_t r = 0; r < rotations.size(); ++r) {
    bool match = true;
    for (int i : refStickers) {
      if (s[rotations[r][static_cast<size_t>(i)]] != solved[static_cast<size_t>(i)]) {
        match = false;
        break;
      }
    }
    if (match) return static_cast<int>(r);
  }
  return -1;
}

const Puzzle* puzzleById(int id) {
  static std::mutex lock;
  static std::unique_ptr<Puzzle> cache[kPuzzleCount];
  if (id < 0 || id >= kPuzzleCount) return nullptr;
  std::lock_guard<std::mutex> guard(lock);
  if (!cache[id]) cache[id] = build(id);
  return cache[id].get();
}

}  // namespace rubik
