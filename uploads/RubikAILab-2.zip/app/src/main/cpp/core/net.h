#pragma once
// Value network: sparse piece features -> h1 -> h2 -> 1 (ReLU).
//
// The input has exactly one active feature per piece slot (see encoder.h), so the first layer is the
// sum of a few weight rows. The output is the estimated number of moves to the solved puzzle divided by
// kValueScale. All parameters live in one flat float array so copying, Adam updates and checkpoints are
// trivial. Sizes are chosen per puzzle at run time.

#include <cstdint>
#include <vector>

#include "encoder.h"
#include "puzzle.h"
#include "rng.h"

namespace rubik {

constexpr int kMaxH1 = 256;
constexpr int kMaxH2 = 128;
constexpr float kValueScale = 10.0f;

struct NetSpec {
  int nFeat = 0;
  int h1 = 0;
  int h2 = 0;
  int active = 1;  // active features per state (used for the initial weight scale)
  int offW1 = 0;   // [nFeat][h1]
  int offB1 = 0;   // [h1]
  int offW2 = 0;   // [h1][h2]
  int offB2 = 0;   // [h2]
  int offW3 = 0;   // [h2]
  int offB3 = 0;   // [1]
  int count = 0;   // total parameters

  NetSpec() = default;
  NetSpec(int features, int hidden1, int hidden2, int activeFeatures);
};

// Everything the learned solver needs for one puzzle.
struct Model {
  const Puzzle* puzzle;
  Encoder enc;
  NetSpec spec;

  explicit Model(const Puzzle& p) : puzzle(&p), enc(p), spec(enc.features(), p.hidden1, p.hidden2, enc.active()) {}
  bool ok() const { return enc.ok() && spec.nFeat > 0; }
};

struct Activations {
  float z1[kMaxH1];
  float a1[kMaxH1];
  float z2[kMaxH2];
  float a2[kMaxH2];
  int act[kMaxH1];  // indices of the positive first-layer units
  int nAct;
};

void initParams(const NetSpec& spec, std::vector<float>& params, Rng& rng);

// Returns the raw network output (before kValueScale).
float forward(const NetSpec& spec, const float* params, const int* feats, int nFeats, Activations& act);

// Accumulates d(loss)/d(params) into grad given d(loss)/d(raw output).
void backward(const NetSpec& spec, const float* params, float* grad, const int* feats, int nFeats,
              const Activations& act, float dOut);

// Estimated cost-to-go in moves for a state that is known not to be solved (never negative).
float valueOf(const Model& model, const float* params, const uint8_t* state);

// Same, but exactly 0 for a solved state.
float estimateCost(const Model& model, const float* params, const uint8_t* state);

}  // namespace rubik
