#pragma once
// Turns a puzzle state into sparse network input.
//
// Every piece position ("slot") that the solver's moves can change contributes exactly one active
// feature: "piece P sits in slot S with orientation O" (the NNUE trick: the first network layer is then
// a sum of a few weight rows). The pieces are found automatically from the puzzle geometry, so the same
// code serves the 2x2, the 3x3, the Pyraminx and the Skewb.
//
// Pieces of one orbit class (pieces that can swap places) are told apart by the set of colours they
// carry in the solved puzzle, so that set must be unique inside a class; the constructor reports it when
// it is not.

#include <cstdint>
#include <vector>

#include "puzzle.h"

namespace rubik {

class Encoder {
 public:
  explicit Encoder(const Puzzle& puzzle);

  bool ok() const { return ok_; }
  int features() const { return features_; }  // size of the one-hot input space
  int active() const { return active_; }      // active features per state

  // Writes one feature index per active slot. Returns active(), or -1 when the colours are not a valid
  // arrangement of the puzzle's pieces.
  int encode(const uint8_t* state, int* out) const;

  // Number of pieces not at home, per class (wrong[classes()]). Returns the total, -1 when invalid.
  int misplaced(const uint8_t* state, int* wrong) const;

  int classes() const { return static_cast<int>(classes_.size()); }

  // Largest number of pieces of the class that one solver move can change. At least 1.
  int maxMoved(int cls) const { return classes_[static_cast<size_t>(cls)].maxMoved; }

 private:
  struct Cls {
    int pieces = 0;     // slots (= pieces) in the class
    int k = 0;          // stickers per piece
    int nonFixed = 0;   // slots that take part in the encoding
    int offset = 0;     // first feature index
    int maxMoved = 1;
    int8_t pieceOfMask[64];
    uint8_t ref[64];    // reference colour of each piece (lowest colour of its solved set)
  };
  struct Enc {
    int cls = 0;
    int local = 0;      // index among the class's non-fixed slots
    int n = 0;
    int st[3] = {0, 0, 0};
    int solvedFeature = 0;
  };

  const Puzzle& puzzle_;
  bool ok_ = false;
  int features_ = 0;
  int active_ = 0;
  std::vector<Cls> classes_;
  std::vector<Enc> slots_;
};

}  // namespace rubik
