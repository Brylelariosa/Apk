package com.rubikailab.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import java.util.Locale

/**
 * Small line chart with a title and the latest value. Values are plotted left to right, oldest first.
 * The series (title, colour, fixed y range, decimals) can be swapped with [configure], so one chart can
 * show several measurements one after the other.
 */
class ChartView(context: Context, private val heightDp: Int) : View(context) {

    private var title = ""
    private var lineColor = Theme.ACCENT
    private var fixedMin: Float? = null
    private var fixedMax: Float? = null
    private var decimals = 2
    private var values = FloatArray(0)

    private val background = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        background.color = Theme.PANEL
        grid.color = Color.argb(36, 255, 255, 255)
        grid.strokeWidth = context.dpf(1f)
        line.style = Paint.Style.STROKE
        line.strokeWidth = context.dpf(2f)
        line.strokeJoin = Paint.Join.ROUND
        labelPaint.color = Theme.MUTED
        labelPaint.textSize = context.dpf(12f)
    }

    fun configure(title: String, lineColor: Int, fixedMin: Float?, fixedMax: Float?, decimals: Int) {
        this.title = title
        this.lineColor = lineColor
        this.fixedMin = fixedMin
        this.fixedMax = fixedMax
        this.decimals = decimals
        invalidate()
    }

    fun setValues(v: FloatArray) {
        values = v
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(getDefaultSize(suggestedMinimumWidth, widthMeasureSpec), context.dp(heightDp))
    }

    private fun format(v: Float): String = String.format(Locale.US, "%." + decimals + "f", v)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val radius = context.dpf(12f)
        canvas.drawRoundRect(0f, 0f, w, h, radius, radius, background)

        val pad = context.dpf(10f)
        val top = context.dpf(26f)
        val bottom = h - context.dpf(8f)
        val left = pad
        val right = w - pad

        labelPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(title, pad, context.dpf(18f), labelPaint)

        val n = values.size
        if (n == 0) {
            labelPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("no data yet", w - pad, context.dpf(18f), labelPaint)
            return
        }

        var lo = values[0]
        var hi = values[0]
        for (v in values) {
            if (v < lo) lo = v
            if (v > hi) hi = v
        }
        val fmin = fixedMin
        val fmax = fixedMax
        if (fmin != null) lo = fmin
        if (fmax != null) hi = fmax
        if (hi - lo < 1e-6f) hi = lo + 1f

        labelPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(format(values[n - 1]), w - pad, context.dpf(18f), labelPaint)

        for (i in 0..2) {
            val y = top + (bottom - top) * i / 2f
            canvas.drawLine(left, y, right, y, grid)
        }

        if (n < 2) return
        line.color = lineColor
        path.reset()
        for (i in 0 until n) {
            val x = left + (right - left) * i / (n - 1).toFloat()
            val t = ((values[i] - lo) / (hi - lo)).coerceIn(0f, 1f)
            val y = bottom - (bottom - top) * t
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, line)
    }
}
