package com.rubikailab.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock

/**
 * Training effort presets. Each preset is a temperature ceiling plus a cap on how much of the time the
 * CPU may be busy and on how many worker threads may run. The governor lowers the duty cycle whenever
 * the phone gets warmer than the ceiling, so "Fast" is never allowed to cook the phone.
 */
enum class TrainMode(
    val label: String,
    val tempLimitC: Float,
    val headroomLimit: Float,
    val maxDuty: Float,
    val threadCap: Int,
    val blurb: String
) {
    COOL("Cool", 37.0f, 0.70f, 0.60f, 1, "One thread, rests often. Stays cool, slower."),
    BALANCED("Balanced", 39.5f, 0.85f, 0.85f, 2, "Two threads, short rests. Warm at most."),
    FAST("Fast", 42.5f, 0.95f, 1.00f, 4, "All-out until the phone reaches 42 C, then it backs off.");

    companion object {
        fun fromOrdinal(value: Int): TrainMode {
            val all = values()
            return if (value in all.indices) all[value] else BALANCED
        }
    }
}

/**
 * Keeps training from overheating the phone. Every couple of seconds it reads the battery temperature
 * (all Android versions) and, where the system offers them, the thermal status and thermal headroom
 * (Android 10 / 11 and newer), and nudges the duty cycle: down when the phone is hotter than the preset's
 * ceiling, slowly up when it is comfortably below. The training loop then rests between short work
 * chunks so that its long-run busy share equals the duty.
 *
 * Thread-safe for one writer (the training loop) and any number of readers (the UI).
 */
class ThermalGovernor(context: Context) {
    private val app: Context = context.applicationContext
    private val power: PowerManager? = app.getSystemService(Context.POWER_SERVICE) as? PowerManager

    @Volatile
    var duty = 1f
        private set

    @Volatile
    var tempC = Float.NaN
        private set

    @Volatile
    var headroom = Float.NaN
        private set

    @Volatile
    var status = 0
        private set

    @Volatile
    var paused = false
        private set

    @Volatile
    var charging = false
        private set

    private var lastUpdate = 0L
    private var pausedUntil = 0L

    /** Starts a new session: begin at a moderate duty and let the measurements steer it. */
    fun reset(mode: TrainMode) {
        duty = mode.maxDuty * 0.8f
        lastUpdate = 0L
        pausedUntil = 0L
        paused = false
    }

    /** Re-reads the sensors (at most every [CONTROL_MS]) and returns the duty cycle to use now; 0 = rest. */
    fun update(mode: TrainMode): Float {
        val now = SystemClock.elapsedRealtime()
        if (lastUpdate != 0L && now - lastUpdate < CONTROL_MS) return if (paused) 0f else duty
        lastUpdate = now

        val t = readBatteryTemp()
        val h = readHeadroom()
        val s = readStatus()
        tempC = t
        headroom = h
        status = s

        if (s >= STATUS_SEVERE || (!t.isNaN() && t >= HARD_STOP_C)) pausedUntil = now + PAUSE_MS
        if (now < pausedUntil) {
            paused = true
            return 0f
        }
        paused = false

        var err = Float.NaN
        if (!t.isNaN()) err = (t - mode.tempLimitC) / 1.5f
        if (!h.isNaN()) {
            val eh = (h - mode.headroomLimit) / 0.1f
            if (err.isNaN() || eh > err) err = eh
        }
        var d = duty
        if (err.isNaN()) {
            d = mode.maxDuty * 0.7f // no sensor at all: stay conservative
        } else if (err > 0f) {
            d -= 0.06f * (1f + err)
        } else if (err < -0.4f) {
            d += 0.03f
        }
        duty = d.coerceIn(MIN_DUTY, mode.maxDuty)
        return duty
    }

    private fun readBatteryTemp(): Float {
        return try {
            val i: Intent? = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i == null) {
                Float.NaN
            } else {
                charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) > 0
                val raw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                if (raw == Int.MIN_VALUE || raw <= 0) Float.NaN else raw / 10f
            }
        } catch (t: Throwable) {
            Float.NaN
        }
    }

    private fun readStatus(): Int {
        if (Build.VERSION.SDK_INT < 29) return 0
        return try {
            power?.currentThermalStatus ?: 0
        } catch (t: Throwable) {
            0
        }
    }

    private fun readHeadroom(): Float {
        if (Build.VERSION.SDK_INT < 30) return Float.NaN
        return try {
            power?.getThermalHeadroom(10) ?: Float.NaN
        } catch (t: Throwable) {
            Float.NaN
        }
    }

    companion object {
        private const val CONTROL_MS = 2000L
        private const val PAUSE_MS = 20000L
        private const val MIN_DUTY = 0.10f
        private const val HARD_STOP_C = 45.0f
        private const val STATUS_SEVERE = 3
    }
}
