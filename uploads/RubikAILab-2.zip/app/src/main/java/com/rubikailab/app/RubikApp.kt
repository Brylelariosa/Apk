package com.rubikailab.app

import android.app.Application

/** Creates the native engine once per process, before any activity or service touches it. */
class RubikApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Lab.init(this)
    }
}
