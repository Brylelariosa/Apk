package com.rubikailab.app

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import com.rubikailab.app.core.EvalResult
import com.rubikailab.app.core.NativeBridge
import com.rubikailab.app.core.PuzzleCatalog
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.SolveResult
import com.rubikailab.app.core.SolveStatus
import com.rubikailab.app.core.SolverMode
import com.rubikailab.app.core.TrainStats
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Process-wide hub: one native learning engine per puzzle (created on demand and restored from its
 * checkpoint), user settings, the training history, and the asynchronous solve / benchmark helpers.
 *
 * Callbacks of the async helpers are delivered on the main thread.
 */
object Lab {
    private const val PREFS = "rubik_lab_v2"
    private const val FRONTIER_MIX = 0.3f
    private const val MAX_HISTORY = 600

    interface Listener {
        fun onStats(puzzle: Int, stats: TrainStats)
        fun onTrainingChanged()
    }

    private lateinit var app: Application
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val live: ExecutorService = Executors.newSingleThreadExecutor()
    private val engines = HashMap<Int, Long>()
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val histories = HashMap<Int, ArrayList<TrainStats>>()
    private val latest = HashMap<Int, TrainStats>()
    private var initialized = false

    lateinit var governor: ThermalGovernor
        private set

    /** Puzzle being trained right now, or -1. Written on the main thread, read by the training thread. */
    @Volatile
    var trainingPuzzle = -1
        private set

    val training: Boolean get() = trainingPuzzle >= 0

    @Synchronized
    fun init(application: Application) {
        if (initialized) return
        app = application
        prefs = application.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        governor = ThermalGovernor(application)
        NativeBridge.ensureLoaded()
        initialized = true
    }

    fun addListener(l: Listener) {
        listeners.addIfAbsent(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    // ---------------------------------------------------------------- settings

    var playPuzzle: Int
        get() = prefs.getInt("play_puzzle", Puzzles.CUBE3)
        set(v) {
            prefs.edit().putInt("play_puzzle", v).apply()
        }

    var trainPuzzle: Int
        get() = prefs.getInt("train_puzzle", Puzzles.CUBE3)
        set(v) {
            prefs.edit().putInt("train_puzzle", v).apply()
        }

    var trainMode: TrainMode
        get() = TrainMode.fromOrdinal(prefs.getInt("train_mode", TrainMode.BALANCED.ordinal))
        set(v) {
            prefs.edit().putInt("train_mode", v.ordinal).apply()
        }

    var batchSize: Int
        get() = prefs.getInt("batch", 256)
        set(v) {
            prefs.edit().putInt("batch", v).apply()
        }

    var learningRate: Float
        get() = prefs.getFloat("lr", 1.0e-3f)
        set(v) {
            prefs.edit().putFloat("lr", v).apply()
        }

    var poolSize: Int
        get() = prefs.getInt("pool", 8192)
        set(v) {
            prefs.edit().putInt("pool", v).apply()
        }

    var solverMode: Int
        get() = prefs.getInt("solver_mode", SolverMode.LEARNED)
        set(v) {
            prefs.edit().putInt("solver_mode", v).apply()
        }

    var maxExpansions: Int
        get() = prefs.getInt("max_expansions", 20000)
        set(v) {
            prefs.edit().putInt("max_expansions", v).apply()
        }

    var lambda: Float
        get() = prefs.getFloat("lambda", 0.6f)
        set(v) {
            prefs.edit().putFloat("lambda", v).apply()
        }

    var timeoutMs: Int
        get() = prefs.getInt("timeout_ms", 20000)
        set(v) {
            prefs.edit().putInt("timeout_ms", v).apply()
        }

    /** Whether the live practice view is on while the Train page is open. */
    var watchEnabled: Boolean
        get() = prefs.getBoolean("watch", true)
        set(v) {
            prefs.edit().putBoolean("watch", v).apply()
        }

    fun maxDepth(puzzle: Int): Int {
        val fallback = PuzzleCatalog.get(puzzle)?.defaultMaxDepth ?: 12
        return prefs.getInt("max_depth_" + puzzle, fallback)
    }

    fun setMaxDepth(puzzle: Int, value: Int) {
        prefs.edit().putInt("max_depth_" + puzzle, value).apply()
    }

    fun defaultScrambleLength(puzzle: Int): Int = when (puzzle) {
        Puzzles.CUBE2 -> 10
        Puzzles.CUBE3 -> 14
        Puzzles.CUBE4 -> 30
        Puzzles.CUBE5 -> 40
        else -> 10
    }

    fun scrambleLength(puzzle: Int): Int = prefs.getInt("scramble_" + puzzle, defaultScrambleLength(puzzle))

    fun setScrambleLength(puzzle: Int, value: Int) {
        prefs.edit().putInt("scramble_" + puzzle, value).apply()
    }

    fun threadsFor(mode: TrainMode): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        return minOf(mode.threadCap, maxOf(1, cores / 2))
    }

    // ---------------------------------------------------------------- saved benchmark lines

    private const val MAX_TEST_LINES = 60

    /** Benchmark result lines, newest first. */
    fun testLines(): List<String> {
        val raw = prefs.getString("test_log", "") ?: ""
        return if (raw.isEmpty()) ArrayList() else raw.split('\n')
    }

    fun addTestLine(line: String) {
        val lines = ArrayList<String>(testLines())
        lines.add(0, line)
        while (lines.size > MAX_TEST_LINES) lines.removeAt(lines.size - 1)
        prefs.edit().putString("test_log", lines.joinToString("\n")).apply()
    }

    fun clearTestLines() {
        prefs.edit().remove("test_log").apply()
    }

    // ---------------------------------------------------------------- personal bests

    fun bestMillis(puzzle: Int, scrambleLen: Int): Long = prefs.getLong("best_ms_" + puzzle + "_" + scrambleLen, 0L)

    fun bestMoves(puzzle: Int, scrambleLen: Int): Int = prefs.getInt("best_moves_" + puzzle + "_" + scrambleLen, 0)

    /** Stores the result if it beats the stored best for this puzzle and scramble length; true when it does. */
    fun recordSolve(puzzle: Int, scrambleLen: Int, millis: Long, moves: Int): Boolean {
        val best = bestMillis(puzzle, scrambleLen)
        if (best != 0L && millis >= best) return false
        prefs.edit()
            .putLong("best_ms_" + puzzle + "_" + scrambleLen, millis)
            .putInt("best_moves_" + puzzle + "_" + scrambleLen, moves)
            .apply()
        return true
    }

    // ---------------------------------------------------------------- engines

    private fun checkpointFile(puzzle: Int): File = File(app.filesDir, Puzzles.checkpointName(puzzle))

    /** The native engine of a puzzle, created (and restored from its checkpoint) on first use; 0 = no AI. */
    @Synchronized
    fun engine(puzzle: Int): Long {
        val existing = engines[puzzle]
        if (existing != null) return existing
        if (!Puzzles.aiSupported(puzzle) || !NativeBridge.ensureLoaded()) return 0L
        val handle = NativeBridge.nativeCreate(puzzle, System.nanoTime())
        if (handle == 0L) return 0L
        val file = checkpointFile(puzzle)
        if (file.exists()) NativeBridge.nativeLoad(handle, file.absolutePath)
        engines[puzzle] = handle
        applyConfig(puzzle, handle)
        synchronized(latest) { latest[puzzle] = TrainStats.decode(NativeBridge.nativeStats(handle)) }
        return handle
    }

    /** Pushes the current training settings of [puzzle] into its engine. */
    fun applyConfig(puzzle: Int, handle: Long) {
        if (handle == 0L) return
        NativeBridge.nativeConfigure(
            handle, batchSize, learningRate, maxDepth(puzzle), threadsFor(trainMode), poolSize, FRONTIER_MIX
        )
    }

    /** Creates the engine of a puzzle off the main thread and reports its stats to the listeners. */
    fun warmAsync(puzzle: Int) {
        worker.execute {
            val h = engine(puzzle)
            if (h != 0L) publish(puzzle, cachedStats(puzzle), false)
        }
    }

    fun cachedStats(puzzle: Int): TrainStats = synchronized(latest) { latest[puzzle] } ?: TrainStats.EMPTY

    fun history(puzzle: Int): List<TrainStats> = synchronized(histories) {
        ArrayList(histories[puzzle] ?: ArrayList<TrainStats>())
    }

    /** Records fresh stats (optionally into the chart history) and tells the listeners on the main thread. */
    fun publish(puzzle: Int, stats: TrainStats, addToHistory: Boolean) {
        synchronized(latest) { latest[puzzle] = stats }
        if (addToHistory) {
            synchronized(histories) {
                val list = histories.getOrPut(puzzle) { ArrayList() }
                list.add(stats)
                if (list.size > MAX_HISTORY) {
                    // Keep the shape of the whole run: drop every second point of the older half.
                    val kept = ArrayList<TrainStats>()
                    for (i in list.indices) {
                        if (i >= list.size / 2 || i % 2 == 0) kept.add(list[i])
                    }
                    list.clear()
                    list.addAll(kept)
                }
            }
        }
        main.post {
            for (l in listeners) l.onStats(puzzle, stats)
        }
    }

    // ---------------------------------------------------------------- training control

    fun startTraining(puzzle: Int) {
        if (training || !Puzzles.aiSupported(puzzle)) return
        trainingPuzzle = puzzle
        governor.reset(trainMode)
        TrainingService.start(app)
        notifyTrainingChanged()
    }

    fun stopTraining() {
        if (!training) return
        trainingPuzzle = -1
        notifyTrainingChanged()
    }

    private fun notifyTrainingChanged() {
        main.post {
            for (l in listeners) l.onTrainingChanged()
        }
    }

    /** Called by the service when its loop has ended for any reason. */
    fun trainingEnded() {
        if (trainingPuzzle >= 0) {
            trainingPuzzle = -1
            notifyTrainingChanged()
        }
    }

    fun saveCheckpoint(puzzle: Int): Boolean {
        val h = synchronized(this) { engines[puzzle] } ?: return false
        return NativeBridge.nativeSave(h, checkpointFile(puzzle).absolutePath)
    }

    fun saveAll() {
        val handles = synchronized(this) { HashMap(engines) }
        for ((puzzle, h) in handles) NativeBridge.nativeSave(h, checkpointFile(puzzle).absolutePath)
    }

    /** Forgets everything the AI of [puzzle] has learned. */
    fun resetModel(puzzle: Int) {
        if (trainingPuzzle == puzzle) stopTraining()
        worker.execute {
            val h = engine(puzzle)
            if (h != 0L) {
                NativeBridge.nativeReset(h, System.nanoTime())
                checkpointFile(puzzle).delete()
                synchronized(histories) { histories.remove(puzzle) }
                publish(puzzle, TrainStats.decode(NativeBridge.nativeStats(h)), false)
            }
        }
    }

    // ---------------------------------------------------------------- asynchronous solving

    /** Cancels any running solve or benchmark (the next one clears the flag again). */
    fun cancelWork() {
        val handles = synchronized(this) { ArrayList(engines.values) }
        for (h in handles) NativeBridge.nativeSetCancel(h, true)
    }

    /** Solves [state] with the solver chosen in the settings. The solver sees only the sticker colours. */
    fun solveAsync(puzzle: Int, state: ByteArray, callback: (SolveResult) -> Unit) {
        val mode = solverMode
        val expansions = maxExpansions
        val lam = lambda
        val timeout = timeoutMs
        worker.execute {
            val h = engine(puzzle)
            val result = if (h == 0L) {
                SolveResult.failed(SolveStatus.INVALID)
            } else {
                NativeBridge.nativeSetCancel(h, false)
                SolveResult.decode(NativeBridge.nativeSolve(h, mode, state, expansions, lam, timeout))
            }
            main.post { callback(result) }
        }
    }

    /** Small, quick solve for the live practice view; runs on its own thread so it never waits for the user's solves. */
    fun practiceSolveAsync(puzzle: Int, state: ByteArray, callback: (SolveResult) -> Unit) {
        live.execute {
            val h = engine(puzzle)
            val result = if (h == 0L) {
                SolveResult.failed(SolveStatus.INVALID)
            } else {
                SolveResult.decode(NativeBridge.nativeSolve(h, SolverMode.LEARNED, state, 4000, 0.6f, 2000))
            }
            main.post { callback(result) }
        }
    }

    /** The network's estimate of the moves left, or -1. Quick enough for the main thread. */
    fun estimate(puzzle: Int, state: ByteArray): Float {
        val h = synchronized(this) { engines[puzzle] } ?: return -1f
        return NativeBridge.nativeEstimate(h, state)
    }

    /**
     * Runs [cases] scrambles of one depth. fresh = false uses the fixed held-out scrambles (never used for
     * training); fresh = true makes brand-new random scrambles now. Either way the solver only gets colours.
     */
    fun evaluateAsync(puzzle: Int, depth: Int, cases: Int, fresh: Boolean, callback: (EvalResult) -> Unit) {
        val mode = solverMode
        val expansions = maxExpansions
        val lam = lambda
        val timeout = timeoutMs
        worker.execute {
            val h = engine(puzzle)
            val result = if (h == 0L) {
                EvalResult(0, 0, 0.0, 0.0, 0.0, true)
            } else {
                NativeBridge.nativeSetCancel(h, false)
                val seed = if (fresh) (System.nanoTime() or 1L) else 0L
                EvalResult.decode(
                    NativeBridge.nativeEvaluate(h, mode, depth, cases, expansions, lam, timeout, seed)
                )
            }
            main.post { callback(result) }
        }
    }
}
