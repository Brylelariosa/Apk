package com.rubikailab.app.ui

import android.content.Context
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.rubikailab.app.Lab
import com.rubikailab.app.R
import com.rubikailab.app.core.EvalResult
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.SolverMode
import java.util.Locale

/**
 * Tab 3: how good is the AI? Two kinds of test puzzles, both handed to the solver as sticker colours only:
 *  - held-out: a fixed set of scrambles (50 per depth) that is excluded from the training data, so they
 *    measure real generalisation;
 *  - fresh: brand-new random scrambles made right now.
 * The learned AI and the conventional baseline can be measured with the same search limits.
 */
class TestPage(context: Context) : PageView(context) {

    private val puzzleChip: TextView
    private val solverSeg: Segmented
    private val setSeg: Segmented
    private val depthStep: MiniStepper
    private val casesStep: MiniStepper
    private val runButton: Button
    private val sweepButton: Button
    private val cancelButton: Button
    private val statusView: TextView
    private val resultsView: TextView
    private val chart = ChartView(context, 88)

    private val sweepRates = ArrayList<Float>()
    private var puzzleId = -1
    private var running = false
    private var sweeping = false
    private var stopRequested = false

    init {
        // Header.
        val head = LinearLayout(context)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(context.dp(14), context.dp(8), context.dp(6), context.dp(2))
        head.addView(context.heading("Test the AI"), lp(0, WRAP, 1f))
        puzzleChip = context.chip("") { choosePuzzle() }
        puzzleChip.setEndIcon(R.drawable.ic_expand, 18, Theme.TEXT)
        head.addView(puzzleChip, LinearLayout.LayoutParams(WRAP, WRAP))
        head.addView(context.iconButton(R.drawable.ic_tune) { Dialogs.solverSettings(context) { } }, lp(context.dp(44), context.dp(44)))
        addView(head, lp(MATCH, WRAP))

        val note = context.muted(
            "Held-out puzzles were never used for training. Fresh ones are made right now. " +
                "Either way the solver only gets sticker colours, never the scramble."
        )
        note.textSize = 12f
        note.setPadding(context.dp(14), 0, context.dp(14), context.dp(6))
        addView(note, lp(MATCH, WRAP))

        // Options.
        solverSeg = Segmented(context, listOf("Learned AI", "Baseline"), if (Lab.solverMode == SolverMode.BASELINE) 1 else 0) { i ->
            Lab.solverMode = if (i == 1) SolverMode.BASELINE else SolverMode.LEARNED
        }
        setSeg = Segmented(context, listOf("Held-out", "Fresh"), 0) { }
        val segRow = LinearLayout(context)
        segRow.orientation = LinearLayout.HORIZONTAL
        segRow.setPadding(context.dp(10), 0, context.dp(10), 0)
        val sp1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        sp1.setMargins(context.dp(4), 0, context.dp(4), 0)
        segRow.addView(solverSeg, sp1)
        val sp2 = LinearLayout.LayoutParams(0, WRAP, 1f)
        sp2.setMargins(context.dp(4), 0, context.dp(4), 0)
        segRow.addView(setSeg, sp2)
        addView(segRow, lp(MATCH, WRAP))

        depthStep = MiniStepper(context, "Depth", DEPTH_LABELS, DEFAULT_DEPTH_INDEX) { }
        casesStep = MiniStepper(context, "Cases", CASE_LABELS, CASE_LABELS.size - 1) { }
        val stepRow = LinearLayout(context)
        stepRow.orientation = LinearLayout.HORIZONTAL
        stepRow.setPadding(context.dp(10), context.dp(8), context.dp(10), 0)
        val sp3 = LinearLayout.LayoutParams(0, WRAP, 1f)
        sp3.setMargins(context.dp(4), 0, context.dp(4), 0)
        stepRow.addView(depthStep, sp3)
        val sp4 = LinearLayout.LayoutParams(0, WRAP, 1f)
        sp4.setMargins(context.dp(4), 0, context.dp(4), 0)
        stepRow.addView(casesStep, sp4)
        addView(stepRow, lp(MATCH, WRAP))

        // Buttons.
        runButton = context.button("Run depth", true) { start(false) }
        sweepButton = context.button("Sweep 1 to N", false) { start(true) }
        cancelButton = context.button("Cancel", false) { cancel() }
        val btnRow = context.row(runButton, sweepButton, cancelButton)
        btnRow.setPadding(context.dp(7), context.dp(10), context.dp(7), 0)
        addView(btnRow, lp(MATCH, WRAP))

        statusView = context.muted("Ready.")
        statusView.textSize = 12.5f
        statusView.setPadding(context.dp(14), context.dp(8), context.dp(14), context.dp(4))
        addView(statusView, lp(MATCH, WRAP))

        val cp = LinearLayout.LayoutParams(MATCH, WRAP)
        cp.setMargins(context.dp(13), context.dp(4), context.dp(13), 0)
        chart.configure("Solved % by depth (this sweep)", Theme.GOOD, 0f, 100f, 0)
        addView(chart, cp)

        // Results: the only part of the page that scrolls.
        val results = LinearLayout(context)
        results.orientation = LinearLayout.VERTICAL
        results.background = context.rounded(Theme.PANEL, 14f)
        results.setPadding(context.dp(12), context.dp(8), context.dp(12), context.dp(8))
        val resHead = LinearLayout(context)
        resHead.orientation = LinearLayout.HORIZONTAL
        resHead.gravity = Gravity.CENTER_VERTICAL
        resHead.addView(context.label("Saved results, newest first", 13f, Theme.MUTED, true), lp(0, WRAP, 1f))
        resHead.addView(context.chip("Clear") { clearResults() }, LinearLayout.LayoutParams(WRAP, WRAP))
        results.addView(resHead, lp(MATCH, WRAP))
        resultsView = context.label("", 12.5f, Theme.TEXT, false)
        resultsView.setLineSpacing(0f, 1.1f)
        val scroll = ScrollView(context)
        scroll.addView(resultsView)
        val scp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        scp.topMargin = context.dp(6)
        results.addView(scroll, scp)
        val rp = LinearLayout.LayoutParams(MATCH, 0, 1f)
        rp.setMargins(context.dp(13), context.dp(8), context.dp(13), context.dp(10))
        addView(results, rp)

        refreshControls()
        showResults()
    }

    override fun onShow() {
        val id = if (Lab.training) Lab.trainingPuzzle else Lab.trainPuzzle
        if (id != puzzleId) {
            puzzleId = id
            sweepRates.clear()
            chart.setValues(FloatArray(0))
        }
        puzzleChip.text = Puzzles.title(puzzleId)
        solverSeg.select(if (Lab.solverMode == SolverMode.BASELINE) 1 else 0)
        Lab.warmAsync(puzzleId)
        refreshControls()
        showResults()
    }

    override fun onHide() {
        // A running benchmark keeps going in the background; its results are saved either way.
    }

    private fun choosePuzzle() {
        if (running) return
        Dialogs.choosePuzzle(context, puzzleId) { id ->
            if (id != puzzleId) {
                Lab.trainPuzzle = id
                puzzleId = id
                puzzleChip.text = Puzzles.title(id)
                sweepRates.clear()
                chart.setValues(FloatArray(0))
                Lab.warmAsync(id)
                refreshControls()
            }
        }
    }

    private fun refreshControls() {
        val supported = Puzzles.aiSupported(puzzleId)
        runButton.isEnabled = supported && !running
        sweepButton.isEnabled = supported && !running
        cancelButton.isEnabled = running
        solverSeg.setActive(!running)
        setSeg.setActive(!running)
        depthStep.setActive(!running)
        casesStep.setActive(!running)
        if (!supported && puzzleId >= 0) statusView.text = "The " + Puzzles.shortTitle(puzzleId) + " is play-only: there is no AI to test."
    }

    private fun start(sweep: Boolean) {
        if (running) return
        running = true
        sweeping = sweep
        stopRequested = false
        val maxDepth = DEPTH_VALUES[depthStep.index]
        if (sweep) {
            sweepRates.clear()
            chart.setValues(FloatArray(0))
        }
        refreshControls()
        runDepth(if (sweep) 1 else maxDepth, maxDepth)
    }

    private fun runDepth(depth: Int, lastDepth: Int) {
        val cases = CASE_VALUES[casesStep.index]
        val fresh = setSeg.index == 1
        val solverLabel = SolverMode.label(Lab.solverMode)
        val set = if (fresh) "fresh" else "held-out"
        statusView.text = "Testing depth " + depth + " of " + lastDepth + " (" + cases + " puzzles, " + set + ")..."
        Lab.evaluateAsync(puzzleId, depth, cases, fresh) { r ->
            onResult(depth, lastDepth, r, solverLabel, set)
        }
    }

    private fun onResult(depth: Int, lastDepth: Int, r: EvalResult, solverLabel: String, set: String) {
        if (r.total > 0) {
            val rate = 100f * r.solved / r.total
            sweepRates.add(rate)
            chart.setValues(sweepRates.toFloatArray())
            val line = Puzzles.shortTitle(puzzleId) + " " + solverLabel + ", " + set + ", depth " + depth + ": " +
                r.solved + "/" + r.total + " solved (" + String.format(Locale.US, "%.0f%%", rate) + ")" +
                if (r.solved > 0) {
                    ", avg " + String.format(Locale.US, "%.1f", r.avgLength) + " moves, " +
                        Format.compact(Math.round(r.avgExpanded)) + " nodes, " + Math.round(r.avgMs) + " ms"
                } else {
                    ""
                }
            Lab.addTestLine(line)
            showResults()
        }
        val more = sweeping && !stopRequested && !r.cancelled && depth < lastDepth
        if (more) {
            runDepth(depth + 1, lastDepth)
            return
        }
        running = false
        sweeping = false
        statusView.text = if (r.cancelled || stopRequested) "Cancelled." else "Done."
        refreshControls()
    }

    private fun cancel() {
        if (!running) return
        stopRequested = true
        Lab.cancelWork()
        statusView.text = "Cancelling..."
    }

    private fun clearResults() {
        Lab.clearTestLines()
        showResults()
    }

    private fun showResults() {
        val lines = Lab.testLines()
        resultsView.text = if (lines.isEmpty()) "No results yet. Run a depth or a sweep." else lines.joinToString("\n")
    }

    private companion object {
        val DEPTH_VALUES = intArrayOf(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18, 20)
        val DEPTH_LABELS = DEPTH_VALUES.map { it.toString() }
        const val DEFAULT_DEPTH_INDEX = 8
        val CASE_VALUES = intArrayOf(10, 20, 30, 50)
        val CASE_LABELS = CASE_VALUES.map { it.toString() }
    }
}
