package com.rubikailab.app.ui

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.rubikailab.app.Lab
import com.rubikailab.app.R
import com.rubikailab.app.core.PuzzleCatalog
import com.rubikailab.app.core.PuzzleModel
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.SolveResult
import com.rubikailab.app.core.SolveStatus
import com.rubikailab.app.core.SolverMode
import com.rubikailab.app.gl.PuzzleView
import java.util.Random

/**
 * Tab 1: play. The puzzle fills the screen; swipe on it to turn a layer, drag the background to look
 * around. Scramble mixes it up, the timer starts with your first move and stops when it is solved.
 * "AI solve" asks the learned solver, which only ever sees the sticker colours, never the scramble.
 */
class PlayPage(context: Context) : PageView(context) {

    private val uiHandler = Handler(Looper.getMainLooper())
    private val rng = Random()

    private var model: PuzzleModel? = null
    private var state = ByteArray(0)
    private var moveCount = 0
    private var armed = false // a scramble is on the puzzle and the timer waits for the first move
    private var timing = false
    private var startMs = 0L
    private var busy = false // an animated scramble or AI solution is playing: player input is ignored
    private var pendingMoves = 0
    private var scrambling = false
    private var aiPlaying = false
    private var solving = false // waiting for the solver
    private var scrambleLen = 0
    private var aiSummary = ""

    private val puzzleChip: TextView
    private val timerView: TextView
    private val movesView: TextView
    private val statusView: TextView
    private val orbitChip: TextView
    private val barScroll: HorizontalScrollView
    private val barText: TextView
    private val padBox: LinearLayout
    private val puzzleView: PuzzleView
    private val scrambleBtn: ActionButton
    private val resetBtn: ActionButton
    private val solveBtn: ActionButton
    private val padBtn: ActionButton

    init {
        // Top bar: puzzle picker, timer, move counter, settings.
        val top = LinearLayout(context)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(context.dp(10), context.dp(8), context.dp(6), context.dp(4))
        puzzleChip = context.chip("") { choosePuzzle() }
        puzzleChip.setEndIcon(R.drawable.ic_expand, 18, Theme.TEXT)
        top.addView(puzzleChip, LinearLayout.LayoutParams(WRAP, WRAP))
        top.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
        val timeBox = LinearLayout(context)
        timeBox.orientation = LinearLayout.VERTICAL
        timeBox.gravity = Gravity.END
        timerView = context.label("0:00.0", 20f, Theme.TEXT, true)
        movesView = context.label("0 moves", 12f, Theme.MUTED, false)
        timeBox.addView(timerView, LinearLayout.LayoutParams(WRAP, WRAP))
        timeBox.addView(movesView, LinearLayout.LayoutParams(WRAP, WRAP))
        top.addView(timeBox, LinearLayout.LayoutParams(WRAP, WRAP))
        top.addView(context.iconButton(R.drawable.ic_tune) { openSettings() }, lp(context.dp(44), context.dp(44)))
        addView(top, lp(MATCH, WRAP))

        // The puzzle with two overlays.
        val frame = FrameLayout(context)
        puzzleView = PuzzleView(context, { move -> onUserMove(move) }, { onMoveDone() })
        frame.addView(puzzleView, FrameLayout.LayoutParams(MATCH, MATCH))
        statusView = TextView(context)
        statusView.textSize = 13f
        statusView.setTextColor(Theme.TEXT)
        statusView.gravity = Gravity.CENTER
        statusView.setPadding(context.dp(14), context.dp(7), context.dp(14), context.dp(7))
        statusView.background = context.rounded(Theme.SCRIM, 16f)
        statusView.visibility = View.GONE
        val sp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        sp.topMargin = context.dp(6)
        sp.leftMargin = context.dp(10)
        sp.rightMargin = context.dp(10)
        frame.addView(statusView, sp)
        orbitChip = context.chip("Rotate view") { toggleOrbit() }
        val op = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
        op.setMargins(0, 0, context.dp(10), context.dp(8))
        frame.addView(orbitChip, op)
        val hint = context.muted("Swipe the puzzle to turn it")
        hint.textSize = 12f
        val hp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
        hp.setMargins(context.dp(12), 0, 0, context.dp(14))
        frame.addView(hint, hp)
        addView(frame, lp(MATCH, 0, 1f))

        // One-line strip for the scramble or the AI's solution.
        barText = context.label("", 13f, Theme.TEXT, false)
        barText.maxLines = 1
        barText.setSingleLine(true)
        barText.setPadding(context.dp(14), context.dp(6), context.dp(14), context.dp(6))
        barScroll = HorizontalScrollView(context)
        barScroll.isHorizontalScrollBarEnabled = false
        barScroll.addView(barText)
        barScroll.visibility = View.GONE
        addView(barScroll, lp(MATCH, WRAP))

        // Optional buttons for the face turns.
        padBox = LinearLayout(context)
        padBox.orientation = LinearLayout.VERTICAL
        padBox.setPadding(context.dp(8), context.dp(2), context.dp(8), context.dp(2))
        padBox.visibility = View.GONE
        addView(padBox, lp(MATCH, WRAP))

        // Main controls.
        val controls = LinearLayout(context)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.setPadding(context.dp(8), context.dp(4), context.dp(8), context.dp(8))
        scrambleBtn = ActionButton(context, R.drawable.ic_shuffle, "Scramble", false) { scramble() }
        resetBtn = ActionButton(context, R.drawable.ic_reset, "Reset", false) { reset() }
        solveBtn = ActionButton(context, R.drawable.ic_ai, "AI solve", true) { aiSolve() }
        padBtn = ActionButton(context, R.drawable.ic_pad, "Turn pad", false) { togglePad() }
        for (b in listOf(scrambleBtn, resetBtn, solveBtn, padBtn)) {
            val p = LinearLayout.LayoutParams(0, context.dp(58), 1f)
            p.setMargins(context.dp(4), 0, context.dp(4), 0)
            controls.addView(b, p)
        }
        addView(controls, lp(MATCH, WRAP))
    }

    // Declared after init on purpose: it reads timerView, which init assigns. Declared before init the
    // Kotlin compiler rejects it ("Variable 'timerView' must be initialized").
    private val ticker = object : Runnable {
        override fun run() {
            if (timing) {
                timerView.text = Format.duration(SystemClock.elapsedRealtime() - startMs)
                uiHandler.postDelayed(this, 100L)
            }
        }
    }

    // ---------------------------------------------------------------- puzzle loading

    private fun load(id: Int) {
        val m = PuzzleCatalog.get(id)
        if (m == null) {
            showStatus("The native library could not be loaded.")
            return
        }
        Lab.cancelWork()
        model = m
        state = m.solved()
        puzzleView.setPuzzle(m, state)
        puzzleView.renderer.speed = 1f
        busy = false
        pendingMoves = 0
        scrambling = false
        aiPlaying = false
        solving = false
        resetTimer()
        hideBar()
        puzzleChip.text = Puzzles.title(id)
        buildPad(m)
        solveBtn.isEnabled = m.aiSupported
        scrambleBtn.isEnabled = true
        showStatus(Puzzles.blurb(id) + ". Press Scramble, then solve it.")
    }

    private fun buildPad(m: PuzzleModel) {
        padBox.removeAllViews()
        val moves = m.padMoves
        if (moves.isEmpty()) {
            padBtn.visibility = View.GONE
            padBox.visibility = View.GONE
            return
        }
        padBtn.visibility = View.VISIBLE
        padBtn.setOn(padBox.visibility == View.VISIBLE)
        val perRow = 6
        var at = 0
        while (at < moves.size) {
            val line = LinearLayout(context)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until perRow) {
                if (at + k >= moves.size) break
                val move = moves[at + k]
                val c = context.chip(m.moveNames[move]) { onUserMove(move) }
                c.textSize = 14f
                val p = LinearLayout.LayoutParams(0, context.dp(38), 1f)
                p.setMargins(context.dp(3), context.dp(2), context.dp(3), context.dp(2))
                line.addView(c, p)
            }
            padBox.addView(line, lp(MATCH, WRAP))
            at += perRow
        }
    }

    // ---------------------------------------------------------------- playing

    private fun onUserMove(move: Int) {
        val m = model ?: return
        if (busy || solving) return
        state = m.apply(state, move)
        puzzleView.renderer.enqueue(move)
        moveCount++
        movesView.text = moveCount.toString() + (if (moveCount == 1) " move" else " moves")
        if (armed && !timing) {
            timing = true
            startMs = SystemClock.elapsedRealtime()
            uiHandler.post(ticker)
            statusView.visibility = View.GONE
        }
        if (m.isSolved(state) && timing) {
            val ms = SystemClock.elapsedRealtime() - startMs
            timing = false
            armed = false
            uiHandler.removeCallbacks(ticker)
            timerView.text = Format.duration(ms)
            val best = Lab.recordSolve(m.id, scrambleLen, ms, moveCount)
            val record = if (best) " New best!" else ""
            showStatus("Solved in " + Format.duration(ms) + ", " + moveCount + " moves." + record)
        }
    }

    /** Called when one animated turn has finished playing. */
    private fun onMoveDone() {
        if (pendingMoves <= 0) return
        pendingMoves--
        if (pendingMoves > 0) return
        busy = false
        puzzleView.renderer.speed = 1f
        scrambleBtn.isEnabled = true
        solveBtn.isEnabled = model?.aiSupported == true
        if (scrambling) {
            scrambling = false
            armed = true
            showStatus("Your turn. The timer starts with your first move.")
        } else if (aiPlaying) {
            aiPlaying = false
            showStatus(aiSummary)
        }
    }

    private fun scramble() {
        val m = model ?: return
        if (busy || solving) return
        Lab.cancelWork()
        val len = Lab.scrambleLength(m.id)
        val moves = m.scramble(rng, len)
        state = m.applyAll(m.solved(), moves)
        scrambleLen = len
        resetTimer()
        puzzleView.renderer.setState(m.solved())
        puzzleView.renderer.speed = 3.2f
        puzzleView.renderer.enqueueAll(moves)
        busy = true
        scrambling = true
        pendingMoves = moves.size
        scrambleBtn.isEnabled = false
        solveBtn.isEnabled = false
        showBar("Scramble (the AI never sees this): " + m.format(moves))
        showStatus("Scrambling...")
    }

    private fun reset() {
        val m = model ?: return
        Lab.cancelWork()
        state = m.solved()
        puzzleView.renderer.setState(state)
        puzzleView.renderer.speed = 1f
        busy = false
        pendingMoves = 0
        scrambling = false
        aiPlaying = false
        solving = false
        scrambleBtn.isEnabled = true
        solveBtn.isEnabled = m.aiSupported
        solveBtn.setLabel("AI solve")
        resetTimer()
        hideBar()
        showStatus("Solved puzzle. Press Scramble to start.")
    }

    private fun aiSolve() {
        val m = model ?: return
        if (busy || solving) return
        if (!m.aiSupported) {
            Toast.makeText(context, "The " + m.shortName + " is play-only: too many states to learn on a phone.", Toast.LENGTH_LONG).show()
            return
        }
        if (m.isSolved(state)) {
            showStatus("Already solved. Press Scramble first.")
            return
        }
        // An AI solution never counts as the player's time.
        armed = false
        timing = false
        uiHandler.removeCallbacks(ticker)
        solving = true
        solveBtn.isEnabled = false
        solveBtn.setLabel("Thinking")
        scrambleBtn.isEnabled = false
        showStatus("The AI is thinking. It sees only the colours.")
        val start = state.copyOf()
        Lab.solveAsync(m.id, start) { r -> onAiResult(m, start, r) }
    }

    private fun onAiResult(m: PuzzleModel, start: ByteArray, r: SolveResult) {
        solving = false
        solveBtn.setLabel("AI solve")
        solveBtn.isEnabled = m.aiSupported
        scrambleBtn.isEnabled = true
        if (model !== m || !state.contentEquals(start)) return // the puzzle was reset or changed meanwhile
        if (!r.solved) {
            val hint = if (Lab.solverMode == SolverMode.LEARNED) " Train this AI longer in the Train tab, or raise the node budget in settings." else ""
            showStatus(SolveStatus.label(r.status) + "." + hint)
            return
        }
        val finalState = m.applyAll(start, r.moves)
        if (!m.isSolved(finalState)) {
            showStatus("The returned moves do not solve the puzzle.")
            return
        }
        state = finalState
        aiSummary = SolverMode.label(Lab.solverMode) + " solved it in " + r.moves.size + " moves (" +
            Format.compact(r.expanded.toLong()) + " nodes, " + r.elapsedMs + " ms)."
        showBar("AI solution: " + m.format(r.moves))
        showStatus("The AI is solving it.")
        puzzleView.renderer.speed = 1.2f
        puzzleView.renderer.enqueueAll(r.moves)
        busy = true
        aiPlaying = true
        pendingMoves = r.moves.size
        scrambleBtn.isEnabled = false
        solveBtn.isEnabled = false
    }

    // ---------------------------------------------------------------- small helpers

    private fun resetTimer() {
        timing = false
        armed = false
        uiHandler.removeCallbacks(ticker)
        moveCount = 0
        timerView.text = "0:00.0"
        movesView.text = "0 moves"
    }

    private fun showStatus(text: String) {
        statusView.text = text
        statusView.visibility = View.VISIBLE
    }

    private fun showBar(text: String) {
        barText.text = text
        barScroll.scrollTo(0, 0)
        barScroll.visibility = View.VISIBLE
    }

    private fun hideBar() {
        barScroll.visibility = View.GONE
    }

    private fun togglePad() {
        val show = padBox.visibility != View.VISIBLE
        padBox.visibility = if (show) View.VISIBLE else View.GONE
        padBtn.setOn(show)
    }

    private fun toggleOrbit() {
        val on = !puzzleView.orbitMode
        puzzleView.orbitMode = on
        orbitChip.text = if (on) "Rotate view: on" else "Rotate view"
        orbitChip.background = context.chipBackground(on)
    }

    private fun choosePuzzle() {
        Dialogs.choosePuzzle(context, Lab.playPuzzle) { id ->
            if (id != Lab.playPuzzle) {
                Lab.playPuzzle = id
                load(id)
                Lab.warmAsync(id)
            }
        }
    }

    private fun openSettings() {
        val m = model ?: return
        Dialogs.playSettings(context, m.id) { }
    }

    override fun onShow() {
        val id = Lab.playPuzzle
        if (model?.id != id) load(id)
        puzzleView.onResume()
        if (timing) uiHandler.post(ticker)
        Lab.warmAsync(id)
    }

    override fun onHide() {
        puzzleView.onPause()
        uiHandler.removeCallbacks(ticker)
    }
}
