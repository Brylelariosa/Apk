package com.rubikailab.app.core

/**
 * JNI surface of the native library "rubikcore". Every external function maps 1:1 to
 * app/src/main/cpp/jni_bridge.cpp (same names, same argument order); the result array layouts are
 * documented there and decoded in Models.kt / Puzzle.kt.
 *
 * This must stay a Kotlin `object` in package com.rubikailab.app.core: the native side binds to
 * Java_com_rubikailab_app_core_NativeBridge_* and receives the singleton as its `jobject` argument.
 */
object NativeBridge {
    @Volatile
    private var loaded = false

    @Volatile
    var loadError: String? = null
        private set

    /** Loads the native library once. Returns false (and sets [loadError]) instead of crashing the app. */
    @Synchronized
    fun ensureLoaded(): Boolean {
        if (loaded) return true
        try {
            System.loadLibrary("rubikcore")
            loaded = true
            loadError = null
        } catch (t: Throwable) {
            loadError = t.message ?: t.javaClass.simpleName
        }
        return loaded
    }

    // ---------------------------------------------------------------- puzzle definitions

    external fun nativePuzzleCount(): Int

    /** int[13]: valid, stickers, colors, faces, moves, aiSupported, aiMoveCount, needsCanon, defaultMaxDepth, bodies, coreTriangles, hidden1, hidden2. */
    external fun nativePuzzleInfo(id: Int): IntArray

    /** [full name, short name, move names separated by spaces]. */
    external fun nativePuzzleStrings(id: Int): Array<String>

    /** [bounding radius, sticker inset (dark margin), sticker lift, sticker corner radius]. */
    external fun nativePuzzleStyle(id: Int): FloatArray

    /** stickers x 20 floats: corner count, 12 corner coordinates, normal, centroid, colour. */
    external fun nativePuzzleStickers(id: Int): FloatArray

    /** Face index of every sticker. */
    external fun nativePuzzleFaces(id: Int): IntArray

    /** moves x 8 floats: axis (3), signed angle in degrees, layer lo, layer hi, inverse move, solver flag. */
    external fun nativePuzzleMoves(id: Int): FloatArray

    /** moves x stickers ints: after move m the new sticker i holds the colour of old sticker table[m * stickers + i]. */
    external fun nativePuzzleMoveTable(id: Int): IntArray

    /** pieceCount, then per piece: class point (3), triangle count, 12 floats per triangle. */
    external fun nativePuzzleBodies(id: Int): FloatArray

    /** Static dark triangles, 12 floats each. */
    external fun nativePuzzleCore(id: Int): FloatArray

    // ---------------------------------------------------------------- learning engines (one per puzzle)

    /** Returns 0 when the puzzle has no learning solver. */
    external fun nativeCreate(puzzleId: Int, seed: Long): Long

    external fun nativeDestroy(handle: Long)

    external fun nativeReset(handle: Long, seed: Long)

    external fun nativeConfigure(
        handle: Long,
        batch: Int,
        learningRate: Float,
        maxDepth: Int,
        threads: Int,
        pool: Int,
        frontierMix: Float
    )

    /** Trains for about [budgetMs] milliseconds, returns double[17] (see TrainStats.decode). */
    external fun nativeTrain(handle: Long, budgetMs: Int): DoubleArray

    external fun nativeStats(handle: Long): DoubleArray

    /** mode: 0 = learned heuristic, 1 = conventional baseline. Returns int[5 + n] (see SolveResult.decode). */
    external fun nativeSolve(
        handle: Long,
        mode: Int,
        state: ByteArray,
        maxExpansions: Int,
        lambda: Float,
        timeoutMs: Int
    ): IntArray

    /**
     * Runs the scrambles of one depth, returns double[6] (see EvalResult.decode).
     * freshSeed 0 = the fixed held-out scrambles, anything else = new random scrambles made from that seed.
     */
    external fun nativeEvaluate(
        handle: Long,
        mode: Int,
        depth: Int,
        cases: Int,
        maxExpansions: Int,
        lambda: Float,
        timeoutMs: Int,
        freshSeed: Long
    ): DoubleArray

    /** The network's estimate of the moves left for [state], or -1 when the state is not valid. */
    external fun nativeEstimate(handle: Long, state: ByteArray): Float

    /** The cancel flag is sticky: it stays set until it is cleared with cancel = false. */
    external fun nativeSetCancel(handle: Long, cancel: Boolean)

    external fun nativeSave(handle: Long, path: String): Boolean

    external fun nativeLoad(handle: Long, path: String): Boolean
}
