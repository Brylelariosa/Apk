package com.rubikailab.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import com.rubikailab.app.core.NativeBridge
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.TrainStats

/**
 * Keeps training alive while the app is in the background.
 *
 * The loop works in short chunks and rests between them so that the CPU is busy only [ThermalGovernor.duty]
 * of the time; the governor lowers that share when the phone warms up. The thread runs at background
 * priority so it never makes the UI stutter, and the checkpoint is saved regularly and on every stop.
 */
class TrainingService : Service() {
    private var thread: Thread? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == ACTION_STOP) {
            Lab.stopTraining()
            return START_NOT_STICKY
        }
        enterForeground(buildNotification("Starting training"))
        val running = thread
        if (running == null || !running.isAlive) {
            val puzzle = Lab.trainingPuzzle
            if (puzzle < 0) {
                shutDown()
                return START_NOT_STICKY
            }
            acquireWakeLock()
            val t = Thread({ trainLoop(puzzle) }, "rubik-train")
            thread = t
            t.start()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Lab.stopTraining()
        releaseWakeLock()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- the loop

    private fun trainLoop(puzzle: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
        val handle = Lab.engine(puzzle)
        if (handle == 0L) {
            shutDown()
            return
        }
        var lastSave = SystemClock.elapsedRealtime()
        var lastNotify = 0L
        var lastHistory = 0L
        var lastConfig = ""
        try {
            while (Lab.trainingPuzzle == puzzle) {
                val mode = Lab.trainMode
                val config = Lab.batchSize.toString() + "|" + Lab.learningRate + "|" + Lab.maxDepth(puzzle) + "|" +
                    Lab.threadsFor(mode) + "|" + Lab.poolSize
                if (config != lastConfig) {
                    Lab.applyConfig(puzzle, handle)
                    lastConfig = config
                }

                val duty = Lab.governor.update(mode)
                if (duty <= 0f) {
                    // Too hot: rest completely until the governor lets training resume.
                    rest(1000L, puzzle)
                    val cached = Lab.cachedStats(puzzle)
                    Lab.publish(puzzle, cached, false)
                    continue
                }

                val t0 = SystemClock.elapsedRealtime()
                val stats = TrainStats.decode(NativeBridge.nativeTrain(handle, WORK_MS))
                val now = SystemClock.elapsedRealtime()
                val worked = now - t0
                val addHistory = now - lastHistory >= HISTORY_EVERY_MS
                if (addHistory) lastHistory = now
                Lab.publish(puzzle, stats, addHistory)

                if (now - lastSave >= SAVE_EVERY_MS) {
                    Lab.saveCheckpoint(puzzle)
                    lastSave = now
                }
                if (now - lastNotify >= NOTIFY_EVERY_MS) {
                    updateNotification(puzzle, stats)
                    lastNotify = now
                }

                // Busy share = worked / (worked + rest) = duty.
                val restMs = (worked.toFloat() * (1f - duty) / duty).toLong().coerceIn(0L, MAX_REST_MS)
                rest(restMs, puzzle)
            }
        } finally {
            Lab.saveCheckpoint(puzzle)
            shutDown()
        }
    }

    /** Sleeps in short slices so a stop request is noticed quickly. */
    private fun rest(ms: Long, puzzle: Int) {
        var left = ms
        while (left > 0L && Lab.trainingPuzzle == puzzle) {
            val slice = if (left > 100L) 100L else left
            try {
                Thread.sleep(slice)
            } catch (e: InterruptedException) {
                return
            }
            left -= slice
        }
    }

    private fun shutDown() {
        Lab.trainingEnded()
        releaseWakeLock()
        stopForeground(true)
        stopSelf()
    }

    // ---------------------------------------------------------------- wake lock

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RubikAILab:training")
            lock.setReferenceCounted(false)
            lock.acquire(WAKE_LOCK_MS)
            wakeLock = lock
        } catch (t: Throwable) {
            wakeLock = null
        }
    }

    private fun releaseWakeLock() {
        try {
            val lock = wakeLock
            if (lock != null && lock.isHeld) lock.release()
        } catch (t: Throwable) {
            // nothing to do
        }
        wakeLock = null
    }

    // ---------------------------------------------------------------- notification

    private fun enterForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Training", NotificationManager.IMPORTANCE_LOW))
            }
            builder = Notification.Builder(this, CHANNEL_ID)
        } else {
            builder = Notification.Builder(this)
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = Intent(this, TrainingService::class.java)
        stopIntent.action = ACTION_STOP
        val stop = PendingIntent.getService(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        builder.addAction(android.R.drawable.ic_media_pause, "Stop", stop)
        return builder
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Rubik AI Lab")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(puzzle: Int, s: TrainStats) {
        val gov = Lab.governor
        val temp = if (gov.tempC.isNaN()) "" else String.format(java.util.Locale.US, " | %.1f C", gov.tempC)
        val text = Puzzles.title(puzzle) + ": depth " + s.depth + ", round " + s.iterations + temp +
            " | " + Math.round(gov.duty * 100f) + "% effort"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        private const val CHANNEL_ID = "rubik_training"
        private const val NOTIFICATION_ID = 7
        private const val ACTION_STOP = "com.rubikailab.app.STOP_TRAINING"
        private const val WORK_MS = 250
        private const val MAX_REST_MS = 4000L
        private const val SAVE_EVERY_MS = 30000L
        private const val NOTIFY_EVERY_MS = 3000L
        private const val HISTORY_EVERY_MS = 1000L
        private const val WAKE_LOCK_MS = 3L * 60L * 60L * 1000L

        fun start(context: Context) {
            val i = Intent(context, TrainingService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }
}
