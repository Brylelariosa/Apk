package com.rubikailab.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.rubikailab.app.Lab
import com.rubikailab.app.R
import com.rubikailab.app.TrainMode
import com.rubikailab.app.core.PuzzleCatalog
import com.rubikailab.app.core.PuzzleModel
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.SolveResult
import com.rubikailab.app.core.TrainStats
import com.rubikailab.app.gl.PuzzleView
import java.util.Locale
import java.util.Random

/** Thin rounded progress bar. */
private class ProgressStrip(context: Context) : View(context) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    var progress: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    var color: Int = Theme.ACCENT
        set(value) {
            field = value
            invalidate()
        }

    init {
        track.color = Theme.PANEL_HI
    }

    override fun onDraw(canvas: Canvas) {
        val h = height.toFloat()
        val r = h / 2f
        canvas.drawRoundRect(0f, 0f, width.toFloat(), h, r, r, track)
        fill.color = color
        if (progress > 0.01f) canvas.drawRoundRect(0f, 0f, width.toFloat() * progress, h, r, r, fill)
    }
}

/** A value with a small caption underneath. */
private class StatCell(context: Context, caption: String) : LinearLayout(context) {
    private val value = context.label("-", 16f, Theme.TEXT, true)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        background = context.rounded(Theme.PANEL, 12f)
        setPadding(context.dp(4), context.dp(6), context.dp(4), context.dp(6))
        value.gravity = Gravity.CENTER
        value.maxLines = 1
        addView(value, LayoutParams(MATCH, WRAP))
        val c = context.label(caption, 11f, Theme.MUTED, false)
        c.gravity = Gravity.CENTER
        addView(c, LayoutParams(MATCH, WRAP))
    }

    fun set(text: String) {
        value.text = text
    }
}

/**
 * Tab 2: train the AI and watch it. The big view is the AI practising on fresh scrambles at the depth it is
 * currently training on: it only sees colours, searches with its learned estimate, and the puzzle then plays
 * the solution it found. Underneath: the round in progress, the key numbers, a chart, and the effort preset
 * that keeps the phone cool.
 */
class TrainPage(context: Context) : PageView(context), Lab.Listener {

    private val uiHandler = Handler(Looper.getMainLooper())
    private val rng = Random()

    private var model: PuzzleModel? = null
    private var puzzleId = -1
    private var seriesIndex = 0
    private var lastChartMs = 0L

    // Live practice.
    private enum class Phase { NEW, SCRAMBLING, THINKING, SOLVING, PAUSE }

    private var practicing = false
    private var phase = Phase.NEW
    private var pauseUntil = 0L
    private var practiceStart = ByteArray(0)
    private var practiceDepth = 0
    private val recent = ArrayList<Boolean>()
    private var estimateText = ""

    private val puzzleChip: TextView
    private val statusChip: TextView
    private val liveView: PuzzleView
    private val infoView: TextView
    private val watchChip: TextView
    private val roundText: TextView
    private val roundBar: ProgressStrip
    private val cellDepth: StatCell
    private val cellAcc: StatCell
    private val cellLoss: StatCell
    private val cellSpeed: StatCell
    private val chart: ChartView
    private val modeSeg: Segmented
    private val modeNote: TextView
    private val startBtn: ActionButton
    private val saveBtn: ActionButton
    private val settingsBtn: ActionButton

    private val tick = object : Runnable {
        override fun run() {
            if (!practicing) return
            practiceTick()
            uiHandler.postDelayed(this, 140L)
        }
    }

    init {
        // Header.
        val head = LinearLayout(context)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(context.dp(10), context.dp(8), context.dp(10), context.dp(4))
        puzzleChip = context.chip("") { choosePuzzle() }
        puzzleChip.setEndIcon(R.drawable.ic_expand, 18, Theme.TEXT)
        head.addView(puzzleChip, LinearLayout.LayoutParams(WRAP, WRAP))
        head.addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
        statusChip = context.label("Idle", 12.5f, Theme.MUTED, true)
        statusChip.setPadding(context.dp(12), context.dp(7), context.dp(12), context.dp(7))
        statusChip.background = context.rounded(Theme.PANEL, 16f)
        statusChip.setStartIcon(R.drawable.ic_thermo, 16, Theme.MUTED)
        head.addView(statusChip, LinearLayout.LayoutParams(WRAP, WRAP))
        addView(head, lp(MATCH, WRAP))

        // The practice view.
        val frame = FrameLayout(context)
        liveView = PuzzleView(context, { }, { })
        liveView.turnable = false
        frame.addView(liveView, FrameLayout.LayoutParams(MATCH, MATCH))
        infoView = TextView(context)
        infoView.textSize = 12.5f
        infoView.setTextColor(Theme.TEXT)
        infoView.setPadding(context.dp(12), context.dp(7), context.dp(12), context.dp(7))
        infoView.background = context.rounded(Theme.SCRIM, 14f)
        val ip = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
        ip.setMargins(context.dp(10), context.dp(6), context.dp(60), 0)
        frame.addView(infoView, ip)
        watchChip = context.chip("") { toggleWatch() }
        val wp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
        wp.setMargins(0, context.dp(6), context.dp(10), 0)
        frame.addView(watchChip, wp)
        addView(frame, lp(MATCH, 0, 1f))

        // Round progress.
        val round = LinearLayout(context)
        round.orientation = LinearLayout.VERTICAL
        round.setPadding(context.dp(14), context.dp(8), context.dp(14), context.dp(2))
        roundText = context.label("", 12f, Theme.MUTED, false)
        round.addView(roundText, LinearLayout.LayoutParams(MATCH, WRAP))
        roundBar = ProgressStrip(context)
        val rb = LinearLayout.LayoutParams(MATCH, context.dp(6))
        rb.topMargin = context.dp(4)
        round.addView(roundBar, rb)
        addView(round, lp(MATCH, WRAP))

        // Key numbers.
        val stats = LinearLayout(context)
        stats.orientation = LinearLayout.HORIZONTAL
        stats.setPadding(context.dp(10), context.dp(6), context.dp(10), context.dp(2))
        cellDepth = StatCell(context, "scramble depth")
        cellAcc = StatCell(context, "accuracy")
        cellLoss = StatCell(context, "loss")
        cellSpeed = StatCell(context, "samples/s")
        for (c in listOf(cellDepth, cellAcc, cellLoss, cellSpeed)) {
            val p = LinearLayout.LayoutParams(0, WRAP, 1f)
            p.setMargins(context.dp(3), 0, context.dp(3), 0)
            stats.addView(c, p)
        }
        addView(stats, lp(MATCH, WRAP))

        // Chart (tap to show the next measurement).
        chart = ChartView(context, 88)
        chart.setOnClickListener {
            seriesIndex = (seriesIndex + 1) % SERIES_COUNT
            lastChartMs = 0L
            refreshChart()
        }
        val cp = LinearLayout.LayoutParams(MATCH, WRAP)
        cp.setMargins(context.dp(13), context.dp(6), context.dp(13), 0)
        addView(chart, cp)

        // Effort preset.
        val modes = TrainMode.values()
        modeSeg = Segmented(context, modes.map { it.label }, Lab.trainMode.ordinal) { i ->
            Lab.trainMode = TrainMode.fromOrdinal(i)
            refreshMode()
        }
        val sp = LinearLayout.LayoutParams(MATCH, WRAP)
        sp.setMargins(context.dp(13), context.dp(8), context.dp(13), 0)
        addView(modeSeg, sp)
        modeNote = context.muted("")
        modeNote.textSize = 12f
        modeNote.gravity = Gravity.CENTER
        addView(modeNote, lp(MATCH, WRAP))

        // Controls.
        val controls = LinearLayout(context)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.setPadding(context.dp(8), context.dp(6), context.dp(8), context.dp(8))
        startBtn = ActionButton(context, R.drawable.ic_play, "Start training", true) { toggleTraining() }
        saveBtn = ActionButton(context, R.drawable.ic_save, "Save", false) { save() }
        settingsBtn = ActionButton(context, R.drawable.ic_tune, "Settings", false) { openSettings() }
        val weights = floatArrayOf(2f, 1f, 1f)
        val buttons = listOf(startBtn, saveBtn, settingsBtn)
        for (i in buttons.indices) {
            val p = LinearLayout.LayoutParams(0, context.dp(58), weights[i])
            p.setMargins(context.dp(4), 0, context.dp(4), 0)
            controls.addView(buttons[i], p)
        }
        addView(controls, lp(MATCH, WRAP))

        refreshMode()
    }

    // ---------------------------------------------------------------- puzzle and page lifecycle

    private fun load(id: Int) {
        val m = PuzzleCatalog.get(id)
        puzzleId = id
        model = m
        puzzleChip.text = Puzzles.title(id)
        stopPractice()
        if (m != null) liveView.setPuzzle(m, m.solved())
        recent.clear()
        estimateText = ""
        phase = Phase.NEW
        Lab.warmAsync(id)
        lastChartMs = 0L
        refreshChart()
        showStats(Lab.cachedStats(id))
        refreshControls()
        if (isShown) startPractice()
    }

    override fun onShow() {
        Lab.addListener(this)
        val id = if (Lab.training) Lab.trainingPuzzle else Lab.trainPuzzle
        if (id != puzzleId) load(id) else Lab.warmAsync(id)
        liveView.onResume()
        showStats(Lab.cachedStats(puzzleId))
        refreshControls()
        lastChartMs = 0L
        refreshChart()
        startPractice()
    }

    override fun onHide() {
        Lab.removeListener(this)
        stopPractice()
        liveView.onPause()
    }

    override fun onStats(puzzle: Int, stats: TrainStats) {
        if (puzzle != puzzleId) return
        showStats(stats)
        refreshChart()
    }

    override fun onTrainingChanged() {
        refreshControls()
        showStats(Lab.cachedStats(puzzleId))
    }

    // ---------------------------------------------------------------- numbers

    private fun showStats(s: TrainStats) {
        val untrained = s.steps <= 0L
        cellDepth.set(if (untrained) "-" else s.depth.toString() + " / " + s.maxDepth)
        cellAcc.set(if (untrained) "-" else Format.percent(s.accuracy))
        cellLoss.set(if (untrained) "-" else Format.fixed(s.loss, 3))
        cellSpeed.set(if (s.samplesPerSec <= 0.0) "-" else Format.compact(s.samplesPerSec.toLong()))
        val running = Lab.training && Lab.trainingPuzzle == puzzleId
        if (untrained && !running) {
            roundText.text = "Not trained yet. Press Start training."
            roundBar.progress = 0f
        } else {
            val what = if (s.phase == 0) "building targets" else "learning, pass " + (s.epoch + 1)
            roundText.text = "Round " + Format.count(s.iterations + 1) + ": " + what +
                "   (" + Format.compact(s.steps) + " steps)"
            roundBar.progress = s.progress.toFloat()
            roundBar.color = if (s.phase == 0) Theme.WARN else Theme.ACCENT
        }
        refreshHeat()
    }

    private fun refreshHeat() {
        val running = Lab.training && Lab.trainingPuzzle == puzzleId
        val gov = Lab.governor
        if (!running) {
            statusChip.text = "Idle"
            statusChip.setTextColor(Theme.MUTED)
            statusChip.setStartIcon(R.drawable.ic_thermo, 16, Theme.MUTED)
            return
        }
        val temp = if (gov.tempC.isNaN()) "" else String.format(Locale.US, "%.1f C  ", gov.tempC)
        val text: String
        val color: Int
        if (gov.paused) {
            text = temp + "cooling down"
            color = Theme.BAD
        } else {
            text = temp + Math.round(gov.duty * 100f) + "% effort"
            color = if (gov.duty < Lab.trainMode.maxDuty * 0.6f) Theme.WARN else Theme.GOOD
        }
        statusChip.text = text
        statusChip.setTextColor(color)
        statusChip.setStartIcon(R.drawable.ic_thermo, 16, color)
    }

    private fun refreshChart() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastChartMs < 900L) return
        lastChartMs = now
        val h = Lab.history(puzzleId)
        when (seriesIndex) {
            0 -> chart.configure("Loss (tap for next)", Theme.ACCENT, 0f, null, 3)
            1 -> chart.configure("Accuracy % (tap for next)", Theme.GOOD, 0f, 100f, 0)
            2 -> chart.configure("Scramble depth (tap for next)", Theme.WARN, 0f, null, 0)
            else -> chart.configure("Samples per second (tap for next)", Theme.ACCENT, 0f, null, 0)
        }
        chart.setValues(
            FloatArray(h.size) { i ->
                val s = h[i]
                when (seriesIndex) {
                    0 -> s.loss.toFloat()
                    1 -> (s.accuracy * 100.0).toFloat()
                    2 -> s.depth.toFloat()
                    else -> s.samplesPerSec.toFloat()
                }
            }
        )
    }

    private fun refreshMode() {
        val mode = Lab.trainMode
        modeSeg.select(mode.ordinal)
        modeNote.text = mode.blurb
    }

    private fun refreshControls() {
        val running = Lab.training
        val mine = running && Lab.trainingPuzzle == puzzleId
        startBtn.setLabel(if (mine) "Stop training" else "Start training")
        startBtn.setIcon(if (mine) R.drawable.ic_stop else R.drawable.ic_play)
        startBtn.isEnabled = !running || mine
        watchChip.text = if (Lab.watchEnabled) "Watching" else "Watch AI"
        watchChip.setStartIcon(R.drawable.ic_eye, 16, Theme.TEXT)
        watchChip.background = context.chipBackground(Lab.watchEnabled)
        refreshHeat()
    }

    // ---------------------------------------------------------------- buttons

    private fun toggleTraining() {
        if (Lab.training) {
            Lab.stopTraining()
        } else {
            if (!Puzzles.aiSupported(puzzleId)) {
                Toast.makeText(context, "This puzzle is play-only.", Toast.LENGTH_SHORT).show()
                return
            }
            Lab.trainPuzzle = puzzleId
            Lab.startTraining(puzzleId)
        }
        refreshControls()
    }

    private fun save() {
        val ok = Lab.saveCheckpoint(puzzleId)
        Toast.makeText(context, if (ok) "Saved." else "Nothing to save yet.", Toast.LENGTH_SHORT).show()
    }

    private fun choosePuzzle() {
        if (Lab.training) {
            Toast.makeText(context, "Stop training to switch puzzles.", Toast.LENGTH_SHORT).show()
            return
        }
        Dialogs.choosePuzzle(context, puzzleId) { id ->
            if (id != puzzleId) {
                Lab.trainPuzzle = id
                load(id)
            }
        }
    }

    private fun openSettings() {
        Dialogs.trainSettings(context, puzzleId) {
            showStats(Lab.cachedStats(puzzleId))
            refreshControls()
        }
    }

    private fun toggleWatch() {
        Lab.watchEnabled = !Lab.watchEnabled
        refreshControls()
        if (Lab.watchEnabled) startPractice() else stopPractice()
    }

    // ---------------------------------------------------------------- live practice

    private fun startPractice() {
        val m = model
        if (practicing) return
        if (m == null || !m.aiSupported || !Lab.watchEnabled) {
            infoView.text = if (m != null && !m.aiSupported) "Play-only puzzle: no AI to watch." else "Live view is off."
            return
        }
        practicing = true
        phase = Phase.NEW
        uiHandler.post(tick)
    }

    private fun stopPractice() {
        practicing = false
        uiHandler.removeCallbacks(tick)
        // A solve still in flight is ignored when it returns: its callback checks the phase.
        phase = Phase.NEW
    }

    private fun practiceTick() {
        val m = model ?: return
        val renderer = liveView.renderer
        when (phase) {
            Phase.NEW -> {
                val s = Lab.cachedStats(puzzleId)
                // Practise where the AI is training, but not absurdly deep while it is still weak.
                val top = maxOf(2, minOf(s.depth, PRACTICE_MAX_DEPTH))
                practiceDepth = maxOf(2, top - rng.nextInt(3))
                val moves = m.scramble(rng, practiceDepth, m.aiMoves)
                practiceStart = m.applyAll(m.solved(), moves)
                renderer.setState(m.solved())
                renderer.speed = 3.5f
                renderer.enqueueAll(moves)
                phase = Phase.SCRAMBLING
                setInfo("Scrambling: " + practiceDepth + " random turns")
            }
            Phase.SCRAMBLING -> {
                if (!renderer.isAnimating()) {
                    phase = Phase.THINKING
                    val guess = Lab.estimate(puzzleId, practiceStart)
                    estimateText = if (guess >= 0f) String.format(Locale.US, "AI guess: %.1f moves left", guess) else ""
                    setInfo("Thinking. It sees only the colours.")
                    val start = practiceStart
                    Lab.practiceSolveAsync(puzzleId, start) { r -> onPracticeResult(m, start, r) }
                }
            }
            Phase.THINKING -> {
                // waiting for the solver; onPracticeResult moves on
            }
            Phase.SOLVING -> {
                if (!renderer.isAnimating()) {
                    phase = Phase.PAUSE
                    pauseUntil = SystemClock.elapsedRealtime() + 1000L
                }
            }
            Phase.PAUSE -> {
                if (SystemClock.elapsedRealtime() >= pauseUntil) phase = Phase.NEW
            }
        }
    }

    private fun onPracticeResult(m: PuzzleModel, start: ByteArray, r: SolveResult) {
        if (!practicing || phase != Phase.THINKING || model !== m || !practiceStart.contentEquals(start)) return
        val ok = r.solved && m.isSolved(m.applyAll(start, r.moves))
        recent.add(ok)
        while (recent.size > RECENT_WINDOW) recent.removeAt(0)
        if (ok) {
            liveView.renderer.speed = 1.6f
            liveView.renderer.enqueueAll(r.moves)
            phase = Phase.SOLVING
            setInfo("Solved in " + r.moves.size + " moves (" + Format.compact(r.expanded.toLong()) + " nodes)")
        } else {
            phase = Phase.PAUSE
            pauseUntil = SystemClock.elapsedRealtime() + 1400L
            setInfo("Gave up on this one. Training makes it stronger.")
        }
    }

    private fun setInfo(line: String) {
        var wins = 0
        for (b in recent) {
            if (b) wins++
        }
        val tally = if (recent.isEmpty()) "" else "\nLast " + recent.size + ": " + wins + " solved"
        val guess = if (estimateText.isEmpty() || phase == Phase.NEW) "" else "\n" + estimateText
        infoView.text = line + guess + tally
    }

    private companion object {
        const val SERIES_COUNT = 4
        const val PRACTICE_MAX_DEPTH = 10
        const val RECENT_WINDOW = 30
    }
}
