package com.rubikailab.app.gl

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Outline of a coloured sticker tile. Pure geometry with no Android types.
 *
 * The sticker polygon (the full face of one piece) is pulled in by a fixed margin, so every dark line between
 * tiles is equally thick whatever the shape of the tile (square, triangle, diamond), and each corner is then
 * rounded with a short curve.
 */
object StickerShape {
    /** Straight pieces per rounded corner. */
    const val SEGMENTS = 3

    /**
     * Rounded outline of the sticker whose [n] corners (x, y, z each, counter-clockwise seen from outside) start at
     * [offset] in [corners]. The unit normal is ([nx], [ny], [nz]); every returned point is also moved [lift] along
     * it. Returns the outline as x, y, z triples, [SEGMENTS] + 1 points per corner.
     */
    fun outline(
        corners: FloatArray,
        offset: Int,
        n: Int,
        nx: Float,
        ny: Float,
        nz: Float,
        inset: Float,
        round: Float,
        lift: Float
    ): FloatArray {
        // 1. Pull every edge in by [inset]: a corner moves along the sum of the two inward edge normals.
        val v = FloatArray(n * 3)
        for (k in 0 until n) {
            val a = offset + ((k + n - 1) % n) * 3
            val b = offset + k * 3
            val c = offset + ((k + 1) % n) * 3
            var e1x = corners[b] - corners[a]
            var e1y = corners[b + 1] - corners[a + 1]
            var e1z = corners[b + 2] - corners[a + 2]
            val l1 = sqrt(e1x * e1x + e1y * e1y + e1z * e1z)
            if (l1 > 1.0e-9f) {
                e1x /= l1
                e1y /= l1
                e1z /= l1
            }
            var e2x = corners[c] - corners[b]
            var e2y = corners[c + 1] - corners[b + 1]
            var e2z = corners[c + 2] - corners[b + 2]
            val l2 = sqrt(e2x * e2x + e2y * e2y + e2z * e2z)
            if (l2 > 1.0e-9f) {
                e2x /= l2
                e2y /= l2
                e2z /= l2
            }
            // The inside is to the left of each edge seen from outside: normal x edge.
            val i1x = ny * e1z - nz * e1y
            val i1y = nz * e1x - nx * e1z
            val i1z = nx * e1y - ny * e1x
            val i2x = ny * e2z - nz * e2y
            val i2y = nz * e2x - nx * e2z
            val i2z = nx * e2y - ny * e2x
            val den = max(0.2f, 1f + i1x * i2x + i1y * i2y + i1z * i2z)
            val s = inset / den
            v[k * 3] = corners[b] + (i1x + i2x) * s
            v[k * 3 + 1] = corners[b + 1] + (i1y + i2y) * s
            v[k * 3 + 2] = corners[b + 2] + (i1z + i2z) * s
        }

        // 2. Round each corner: a quadratic curve between the two points where a circle of radius [round] would
        //    leave the edges, with the corner itself as the control point.
        val out = FloatArray(n * (SEGMENTS + 1) * 3)
        var w = 0
        for (k in 0 until n) {
            val p = ((k + n - 1) % n) * 3
            val q = k * 3
            val r = ((k + 1) % n) * 3
            val ax = v[p] - v[q]
            val ay = v[p + 1] - v[q + 1]
            val az = v[p + 2] - v[q + 2]
            val bx = v[r] - v[q]
            val by = v[r + 1] - v[q + 1]
            val bz = v[r + 2] - v[q + 2]
            val la = max(1.0e-6f, sqrt(ax * ax + ay * ay + az * az))
            val lb = max(1.0e-6f, sqrt(bx * bx + by * by + bz * bz))
            val cosT = (ax * bx + ay * by + az * bz) / (la * lb)
            val sinT = sqrt(max(0f, 1f - cosT * cosT))
            // Tangent length of a circle of radius [round] in a corner of this angle, kept clear of the neighbours.
            val d = min(round * (1f + cosT) / max(sinT, 0.2f), 0.45f * min(la, lb))
            val sx = v[q] + ax / la * d
            val sy = v[q + 1] + ay / la * d
            val sz = v[q + 2] + az / la * d
            val ex = v[q] + bx / lb * d
            val ey = v[q + 1] + by / lb * d
            val ez = v[q + 2] + bz / lb * d
            for (j in 0..SEGMENTS) {
                val t = j.toFloat() / SEGMENTS
                val u = 1f - t
                out[w] = u * u * sx + 2f * u * t * v[q] + t * t * ex + nx * lift
                out[w + 1] = u * u * sy + 2f * u * t * v[q + 1] + t * t * ey + ny * lift
                out[w + 2] = u * u * sz + 2f * u * t * v[q + 2] + t * t * ez + nz * lift
                w += 3
            }
        }
        return out
    }
}
