package com.rubikailab.app.ui

import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Colours of the dark UI (kept in sync with res/values/colors.xml). */
object Theme {
    val BG = Color.rgb(10, 12, 17)
    val NAV = Color.rgb(14, 17, 23)
    val PANEL = Color.rgb(20, 24, 33)
    val PANEL_HI = Color.rgb(32, 39, 54)
    val ACCENT = Color.rgb(124, 156, 255)
    val ACCENT_DIM = Color.rgb(64, 86, 160)
    val TEXT = Color.rgb(232, 236, 245)
    val MUTED = Color.rgb(140, 150, 170)
    val GOOD = Color.rgb(96, 205, 138)
    val WARN = Color.rgb(240, 182, 72)
    val BAD = Color.rgb(238, 104, 104)
    val SCRIM = Color.argb(150, 10, 12, 17)
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.rounded(fill: Int, radiusDp: Float): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(fill)
    d.cornerRadius = dpf(radiusDp)
    return d
}

fun Context.label(s: String, sizeSp: Float, textColor: Int, bold: Boolean): TextView {
    val tv = TextView(this)
    tv.text = s
    tv.textSize = sizeSp
    tv.setTextColor(textColor)
    if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
    return tv
}

fun Context.label(s: String): TextView = label(s, 14f, Theme.TEXT, false)

fun Context.heading(s: String): TextView = label(s, 16f, Theme.TEXT, true)

fun Context.muted(s: String): TextView = label(s, 13f, Theme.MUTED, false)

fun Context.button(text: String, primary: Boolean, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.setAllCaps(false)
    b.textSize = 14f
    b.stateListAnimator = null
    b.minHeight = 0
    b.minimumHeight = 0
    b.minWidth = 0
    b.minimumWidth = 0
    val base = if (primary) Theme.ACCENT_DIM else Theme.PANEL_HI
    val pressed = if (primary) Theme.ACCENT else Color.rgb(52, 62, 86)
    val states = StateListDrawable()
    states.addState(intArrayOf(-android.R.attr.state_enabled), rounded(Theme.PANEL, 10f))
    states.addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed, 10f))
    states.addState(intArrayOf(), rounded(base, 10f))
    b.background = states
    b.setTextColor(
        ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf(Theme.MUTED, Theme.TEXT)
        )
    )
    b.setPadding(dp(12), dp(10), dp(12), dp(10))
    b.setOnClickListener { onClick() }
    return b
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = rounded(Theme.PANEL, 14f)
    c.setPadding(dp(14), dp(12), dp(14), dp(12))
    return c
}

fun lp(w: Int, h: Int, weight: Float): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

/** Adds [child] to this vertical layout with a top margin in dp. */
fun LinearLayout.addTo(child: View, topDp: Int) {
    val p = LinearLayout.LayoutParams(MATCH, WRAP)
    p.topMargin = context.dp(topDp)
    addView(child, p)
}

/** A horizontal row of equally wide children. */
fun Context.row(vararg children: View): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    val gap = dp(3)
    for (c in children) {
        val p = LinearLayout.LayoutParams(0, WRAP, 1f)
        p.setMargins(gap, 0, gap, 0)
        r.addView(c, p)
    }
    return r
}

/**
 * Base class of the three tabs. A page is a vertical column that fills the screen; pages are laid out
 * so that every main control is visible without scrolling (long text lives in its own scroll area).
 */
open class PageView(context: Context) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        setBackgroundColor(Theme.BG)
    }

    /** The page became visible (or the app returned to the foreground with this page selected). */
    open fun onShow() {}

    /** The page was hidden (or the app left the foreground). */
    open fun onHide() {}
}

/** Small rounded text button, for toggles and menus. */
fun Context.chip(text: String, onClick: () -> Unit): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 12.5f
    t.setTextColor(Theme.TEXT)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(12), dp(7), dp(12), dp(7))
    t.background = chipBackground(false)
    t.isClickable = true
    t.setOnClickListener { onClick() }
    return t
}

fun Context.chipBackground(on: Boolean): StateListDrawable {
    val states = StateListDrawable()
    states.addState(intArrayOf(android.R.attr.state_pressed), rounded(Theme.ACCENT, 16f))
    states.addState(intArrayOf(), rounded(if (on) Theme.ACCENT_DIM else Theme.PANEL_HI, 16f))
    return states
}

/** Button with a vector icon above a short caption. */
class ActionButton(
    context: Context,
    iconRes: Int,
    text: String,
    private val primary: Boolean,
    onClick: () -> Unit
) : LinearLayout(context) {
    private val icon = ImageView(context)
    private val caption = TextView(context)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        icon.setImageResource(iconRes)
        icon.setColorFilter(Theme.TEXT)
        addView(icon, LayoutParams(context.dp(22), context.dp(22)))
        caption.text = text
        caption.textSize = 11f
        caption.setTextColor(Theme.TEXT)
        caption.gravity = Gravity.CENTER
        caption.maxLines = 1
        val cp = LayoutParams(WRAP, WRAP)
        cp.topMargin = context.dp(2)
        addView(caption, cp)
        setPadding(context.dp(4), context.dp(7), context.dp(4), context.dp(7))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        applyBackground(false)
    }

    private fun applyBackground(on: Boolean) {
        val base = if (primary || on) Theme.ACCENT_DIM else Theme.PANEL_HI
        val pressed = if (primary || on) Theme.ACCENT else Color.rgb(52, 62, 86)
        val states = StateListDrawable()
        states.addState(intArrayOf(-android.R.attr.state_enabled), context.rounded(Theme.PANEL, 12f))
        states.addState(intArrayOf(android.R.attr.state_pressed), context.rounded(pressed, 12f))
        states.addState(intArrayOf(), context.rounded(base, 12f))
        background = states
    }

    fun setLabel(text: String) {
        caption.text = text
    }

    fun setIcon(iconRes: Int) {
        icon.setImageResource(iconRes)
    }

    /** Shows the button as "on" (for toggles). */
    fun setOn(on: Boolean) {
        applyBackground(on)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = if (enabled) 1f else 0.4f
    }
}

/** Row of mutually exclusive options. */
class Segmented(
    context: Context,
    options: List<String>,
    startIndex: Int,
    private val onSelect: (Int) -> Unit
) : LinearLayout(context) {
    private val cells = ArrayList<TextView>()

    var index = startIndex.coerceIn(0, options.size - 1)
        private set

    private var active = true

    init {
        orientation = HORIZONTAL
        background = context.rounded(Theme.PANEL, 12f)
        setPadding(context.dp(3), context.dp(3), context.dp(3), context.dp(3))
        for (i in options.indices) {
            val t = TextView(context)
            t.text = options[i]
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setPadding(context.dp(6), context.dp(9), context.dp(6), context.dp(9))
            t.isClickable = true
            t.setOnClickListener {
                if (active && index != i) {
                    select(i)
                    onSelect(i)
                }
            }
            cells.add(t)
            addView(t, LayoutParams(0, WRAP, 1f))
        }
        refresh()
    }

    /** Moves the selection without calling the listener. */
    fun select(i: Int) {
        index = i.coerceIn(0, cells.size - 1)
        refresh()
    }

    fun setActive(on: Boolean) {
        active = on
        refresh()
    }

    private fun refresh() {
        for (i in cells.indices) {
            val on = i == index
            cells[i].setTextColor(if (!active && !on) Theme.MUTED else Theme.TEXT)
            cells[i].setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            cells[i].background = if (on) context.rounded(if (active) Theme.ACCENT_DIM else Theme.PANEL_HI, 9f) else null
        }
    }
}

/** "title - [-] value [+]" selector over a fixed list of options. */
class OptionStepper(
    context: Context,
    title: String,
    private val options: List<String>,
    startIndex: Int,
    private val onChange: (Int) -> Unit
) : LinearLayout(context) {

    var index = startIndex.coerceIn(0, options.size - 1)
        private set

    private val valueView: TextView
    private val minus: Button
    private val plus: Button
    private var active = true

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(context.label(title, 14f, Theme.MUTED, false), LayoutParams(0, WRAP, 1f))
        minus = context.button("-", false) { step(-1) }
        valueView = context.label(options[index], 15f, Theme.TEXT, true)
        valueView.gravity = Gravity.CENTER
        plus = context.button("+", false) { step(1) }
        addView(minus, LayoutParams(context.dp(44), context.dp(40)))
        addView(valueView, LayoutParams(context.dp(78), WRAP))
        addView(plus, LayoutParams(context.dp(44), context.dp(40)))
        refresh()
    }

    private fun step(delta: Int) {
        select(index + delta)
        onChange(index)
    }

    /** Moves the selection without calling the change listener. */
    fun select(i: Int) {
        index = i.coerceIn(0, options.size - 1)
        valueView.text = options[index]
        refresh()
    }

    fun setActive(on: Boolean) {
        active = on
        refresh()
    }

    private fun refresh() {
        minus.isEnabled = active && index > 0
        plus.isEnabled = active && index < options.size - 1
    }
}

/** Compact "[-] Depth 8 [+]" pill; the caption is part of the value so two fit side by side. */
class MiniStepper(
    context: Context,
    private val caption: String,
    private val options: List<String>,
    startIndex: Int,
    private val onChange: (Int) -> Unit
) : LinearLayout(context) {

    var index = startIndex.coerceIn(0, options.size - 1)
        private set

    private val valueView: TextView
    private val minus: TextView
    private val plus: TextView
    private var active = true

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        background = context.rounded(Theme.PANEL, 12f)
        minus = stepButton("-") { step(-1) }
        plus = stepButton("+") { step(1) }
        valueView = context.label("", 13f, Theme.TEXT, true)
        valueView.gravity = Gravity.CENTER
        valueView.maxLines = 1
        addView(minus, LayoutParams(context.dp(38), context.dp(40)))
        addView(valueView, LayoutParams(0, WRAP, 1f))
        addView(plus, LayoutParams(context.dp(38), context.dp(40)))
        refresh()
    }

    private fun stepButton(text: String, onClick: () -> Unit): TextView {
        val t = TextView(context)
        t.text = text
        t.textSize = 20f
        t.gravity = Gravity.CENTER
        t.setTextColor(Theme.ACCENT)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    private fun step(delta: Int) {
        if (!active) return
        select(index + delta)
        onChange(index)
    }

    fun select(i: Int) {
        index = i.coerceIn(0, options.size - 1)
        refresh()
    }

    fun setActive(on: Boolean) {
        active = on
        refresh()
    }

    private fun refresh() {
        valueView.text = caption + " " + options[index]
        minus.alpha = if (active && index > 0) 1f else 0.3f
        plus.alpha = if (active && index < options.size - 1) 1f else 0.3f
        valueView.alpha = if (active) 1f else 0.6f
    }
}

/** Shows a dark dialog around [content]. */
fun Context.showDialog(title: String, content: View, positive: String, onClose: (() -> Unit)?): AlertDialog {
    content.setPadding(dp(20), dp(8), dp(20), dp(4))
    val builder = AlertDialog.Builder(this)
    builder.setTitle(title)
    builder.setView(content)
    builder.setPositiveButton(positive) { _, _ -> onClose?.invoke() }
    val dialog = builder.create()
    dialog.show()
    dialog.window?.setBackgroundDrawable(rounded(Theme.PANEL, 18f))
    return dialog
}

/** Shows a list of choices; [onPick] gets the tapped index. */
fun Context.pickDialog(title: String, items: Array<String>, onPick: (Int) -> Unit) {
    val builder = AlertDialog.Builder(this)
    builder.setTitle(title)
    builder.setItems(items) { _, which -> onPick(which) }
    val dialog = builder.create()
    dialog.show()
    dialog.window?.setBackgroundDrawable(rounded(Theme.PANEL, 18f))
}

/** Round icon-only button (no caption). */
fun Context.iconButton(iconRes: Int, onClick: () -> Unit): ImageView {
    val v = ImageView(this)
    v.setImageResource(iconRes)
    v.setColorFilter(Theme.TEXT)
    v.setPadding(dp(10), dp(10), dp(10), dp(10))
    val states = StateListDrawable()
    states.addState(intArrayOf(android.R.attr.state_pressed), rounded(Theme.PANEL_HI, 14f))
    v.background = states
    v.isClickable = true
    v.setOnClickListener { onClick() }
    return v
}

/** Puts a small tinted vector icon after the text. */
fun TextView.setEndIcon(iconRes: Int, sizeDp: Int, tint: Int) {
    val d = context.getDrawable(iconRes)?.mutate() ?: return
    d.setTint(tint)
    val s = context.dp(sizeDp)
    d.setBounds(0, 0, s, s)
    setCompoundDrawables(null, null, d, null)
    compoundDrawablePadding = context.dp(4)
}

/** Puts a small tinted vector icon before the text. */
fun TextView.setStartIcon(iconRes: Int, sizeDp: Int, tint: Int) {
    val d = context.getDrawable(iconRes)?.mutate() ?: return
    d.setTint(tint)
    val s = context.dp(sizeDp)
    d.setBounds(0, 0, s, s)
    setCompoundDrawables(d, null, null, null)
    compoundDrawablePadding = context.dp(5)
}
