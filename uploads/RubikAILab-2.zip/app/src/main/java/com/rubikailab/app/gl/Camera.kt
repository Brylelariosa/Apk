package com.rubikailab.app.gl

import android.opengl.Matrix

/**
 * The one camera of the app. The renderer and the touch picking both use it, so what is drawn is
 * exactly what is hit. Everything is a pure function of plain numbers, so any thread may call it.
 */
object Camera {
    private const val FOV_DEGREES = 34f

    private fun distance(radius: Float, aspect: Float): Float = radius * 4.1f / minOf(1f, aspect)

    /** out = projection * view for a viewport of the given size showing a puzzle of the given radius. */
    fun projectionView(out: FloatArray, width: Int, height: Int, radius: Float) {
        val aspect = if (height > 0) width.toFloat() / height.toFloat() else 1f
        val dist = distance(radius, aspect)
        val proj = FloatArray(16)
        val view = FloatArray(16)
        Matrix.perspectiveM(proj, 0, FOV_DEGREES, aspect, maxOf(0.1f, dist - radius * 2.2f), dist + radius * 2.2f)
        Matrix.setLookAtM(view, 0, 0f, 0f, dist, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }

    /** The turn of the whole puzzle by the user's drag: pitch about x after yaw about y. */
    fun orbit(out: FloatArray, yaw: Float, pitch: Float) {
        Matrix.setIdentityM(out, 0)
        Matrix.rotateM(out, 0, pitch, 1f, 0f, 0f)
        Matrix.rotateM(out, 0, yaw, 0f, 1f, 0f)
    }
}
