package com.rubikailab.app.ui

import android.app.AlertDialog
import android.content.Context
import android.widget.LinearLayout
import android.widget.ScrollView
import com.rubikailab.app.Lab
import com.rubikailab.app.core.PuzzleCatalog
import com.rubikailab.app.core.Puzzles
import com.rubikailab.app.core.SolverMode
import java.util.Locale

/** The settings dialogs shared by the three tabs. */
object Dialogs {
    private val nodeOptions = intArrayOf(2000, 5000, 10000, 20000, 50000, 100000)
    private val weightOptions = floatArrayOf(0f, 0.2f, 0.4f, 0.6f, 0.8f, 1f)
    private val timeoutOptions = intArrayOf(2000, 5000, 10000, 20000, 60000)
    private val scrambleOptions = intArrayOf(3, 5, 8, 10, 12, 14, 16, 20, 25, 30, 40, 60)
    private val batchOptions = intArrayOf(64, 128, 256, 512)
    private val lrOptions = floatArrayOf(0.0003f, 0.0005f, 0.001f, 0.002f)
    private val depthOptions = intArrayOf(6, 8, 10, 12, 14, 16, 18, 20)
    private val poolOptions = intArrayOf(2048, 4096, 8192, 16384)

    /** Lets the player pick one of the puzzles. */
    fun choosePuzzle(context: Context, current: Int, onPick: (Int) -> Unit) {
        val items = Array(Puzzles.COUNT) { id ->
            val ai = if (Puzzles.aiSupported(id)) "AI + play" else "play only"
            Puzzles.title(id) + "   (" + ai + ")" + if (id == current) "   <" else ""
        }
        context.pickDialog("Choose a puzzle", items) { which -> onPick(which) }
    }

    private fun scroll(context: Context, body: LinearLayout): ScrollView {
        val sv = ScrollView(context)
        sv.addView(body)
        return sv
    }

    private fun addSolverControls(context: Context, body: LinearLayout) {
        body.addTo(context.heading("AI solver"), 0)
        body.addTo(
            context.muted(
                "Ranks states by w x (moves so far) + the AI's estimate. w = 1 is classic A*; a lower w is faster " +
                    "but gives longer solutions. The solver only ever sees the sticker colours."
            ),
            2
        )
        body.addTo(
            OptionStepper(
                context, "Solver", listOf("Learned", "Baseline"),
                if (Lab.solverMode == SolverMode.BASELINE) 1 else 0
            ) { i -> Lab.solverMode = if (i == 1) SolverMode.BASELINE else SolverMode.LEARNED },
            10
        )
        body.addTo(
            OptionStepper(
                context, "Node budget", nodeOptions.map { Format.compact(it.toLong()) },
                nearestIndex(nodeOptions, Lab.maxExpansions)
            ) { i -> Lab.maxExpansions = nodeOptions[i] },
            8
        )
        body.addTo(
            OptionStepper(
                context, "Weight w", weightOptions.map { String.format(Locale.US, "%.1f", it) },
                nearestIndex(weightOptions, Lab.lambda)
            ) { i -> Lab.lambda = weightOptions[i] },
            8
        )
        body.addTo(
            OptionStepper(
                context, "Time limit", timeoutOptions.map { (it / 1000).toString() + " s" },
                nearestIndex(timeoutOptions, Lab.timeoutMs)
            ) { i -> Lab.timeoutMs = timeoutOptions[i] },
            8
        )
    }

    /** Scramble length and solver limits (Play tab). */
    fun playSettings(context: Context, puzzle: Int, onChanged: () -> Unit) {
        val body = LinearLayout(context)
        body.orientation = LinearLayout.VERTICAL
        body.addTo(context.heading("Scramble"), 0)
        body.addTo(
            context.muted("How many random turns the Scramble button makes. Shorter scrambles are easier for the AI."),
            2
        )
        body.addTo(
            OptionStepper(
                context, "Turns", scrambleOptions.map { it.toString() },
                nearestIndex(scrambleOptions, Lab.scrambleLength(puzzle))
            ) { i -> Lab.setScrambleLength(puzzle, scrambleOptions[i]) },
            10
        )
        val spacer = LinearLayout(context)
        body.addTo(spacer, 14)
        addSolverControls(context, body)
        context.showDialog(Puzzles.title(puzzle) + " settings", scroll(context, body), "Done") { onChanged() }
    }

    /** Search limits only (Test tab). */
    fun solverSettings(context: Context, onChanged: () -> Unit) {
        val body = LinearLayout(context)
        body.orientation = LinearLayout.VERTICAL
        addSolverControls(context, body)
        context.showDialog("Search limits", scroll(context, body), "Done") { onChanged() }
    }

    /** Training hyper-parameters, model reset and an explanation of how the AI learns (Train tab). */
    fun trainSettings(context: Context, puzzle: Int, onChanged: () -> Unit) {
        val body = LinearLayout(context)
        body.orientation = LinearLayout.VERTICAL
        val model = PuzzleCatalog.get(puzzle)
        val defaultDepth = model?.defaultMaxDepth ?: 12

        body.addTo(context.heading("Training: " + Puzzles.title(puzzle)), 0)
        body.addTo(
            OptionStepper(
                context, "Hardest scramble", depthOptions.map { it.toString() },
                nearestIndex(depthOptions, Lab.maxDepth(puzzle))
            ) { i -> Lab.setMaxDepth(puzzle, depthOptions[i]) },
            10
        )
        body.addTo(
            context.muted("The scramble depth grows up to this limit while the AI keeps up (default " + defaultDepth + ")."),
            2
        )
        body.addTo(
            OptionStepper(
                context, "Batch size", batchOptions.map { it.toString() },
                nearestIndex(batchOptions, Lab.batchSize)
            ) { i -> Lab.batchSize = batchOptions[i] },
            10
        )
        body.addTo(
            OptionStepper(
                context, "Learning rate", lrOptions.map { String.format(Locale.US, "%.4f", it) },
                nearestIndex(lrOptions, Lab.learningRate)
            ) { i -> Lab.learningRate = lrOptions[i] },
            8
        )
        body.addTo(
            OptionStepper(
                context, "States per round", poolOptions.map { Format.compact(it.toLong()) },
                nearestIndex(poolOptions, Lab.poolSize)
            ) { i -> Lab.poolSize = poolOptions[i] },
            8
        )

        body.addTo(context.heading("How it learns"), 16)
        body.addTo(
            context.muted(
                "The AI only ever sees sticker colours. Each round it makes random puzzles, asks its own older self " +
                    "how far each neighbouring state is from solved, and trains itself to agree (value iteration). " +
                    "The scramble that made a puzzle is never used as a label, so there is no \"reverse the scramble\" " +
                    "shortcut. The Test tab checks it on held-out puzzles it has never trained on."
            ),
            4
        )

        body.addTo(
            context.button("Forget what this AI has learned", false) { confirmReset(context, puzzle, onChanged) },
            16
        )
        context.showDialog("Training settings", scroll(context, body), "Done") { onChanged() }
    }

    private fun confirmReset(context: Context, puzzle: Int, onChanged: () -> Unit) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Forget everything?")
        builder.setMessage("The " + Puzzles.shortTitle(puzzle) + " AI starts again from zero. Other puzzles are not touched.")
        builder.setPositiveButton("Forget") { _, _ ->
            Lab.resetModel(puzzle)
            onChanged()
        }
        builder.setNegativeButton("Keep", null)
        val dialog = builder.create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(context.rounded(Theme.PANEL, 18f))
    }
}
