# R8 rules for release builds (proguard-android-optimize.txt is applied first).

# JNI: the native library binds to these methods by name.
-keep class com.rubikailab.app.core.NativeBridge { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# Debug logging is stripped from release builds.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
}

-dontwarn javax.microedition.khronos.**
