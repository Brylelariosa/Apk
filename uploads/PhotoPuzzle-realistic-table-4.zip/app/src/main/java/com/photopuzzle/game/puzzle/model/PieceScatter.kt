package com.photopuzzle.game.puzzle.model

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Pours the pieces out onto the table as a heap, the way a box of puzzle pieces tips out: a
 * dense middle with a looser rim and the odd piece bounced away, pieces lying over each other
 * (later arrivals on top) and every piece turned a random way if rotation is part of the game.
 *
 * The heap is deep enough that you have to move pieces aside to reach the ones underneath, but
 * never so deep that a piece is buried: each one keeps a good part of itself in view. Pieces
 * fall in one after another from above the screen, fanning out from the middle as they land.
 */
internal object PieceScatter {

    /** How many pieces deep the heap is, on average (total piece area over the heap's area). */
    private const val DEPTH = 2.4f

    /** Spots tried for each piece before settling for the least bad one. */
    private const val CANDIDATES = 24

    /** Chance that a piece bounced away from the heap, and how much further out it went. */
    private const val STRAY_CHANCE = 0.10f
    private const val STRAY_SPREAD = 1.5f

    /** How high above the table the pieces start their fall, in piece sizes. */
    private const val DROP_HEIGHT = 1.8f

    fun scatter(
        game: PuzzleGame,
        random: Random,
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        windowTop: Float,
        rotatePieces: Boolean
    ) {
        val n = game.pieces.size
        val order = IntArray(n) { it }
        for (i in n - 1 downTo 1) {
            val j = random.nextInt(i + 1)
            val t = order[i]
            order[i] = order[j]
            order[j] = t
        }

        val cell = sqrt(game.cellWidth * game.cellHeight)
        val centerX = (left + right) * 0.5f
        val centerZ = (top + bottom) * 0.5f

        // The heap's size follows from the pieces' total area, but never beyond the free table.
        // It is a little longer front to back, which the tilted view squashes back to round.
        val heapRadius = sqrt(n * cell * cell * 1.25f / (PI.toFloat() * DEPTH))
        val spreadX = max(1f, min(heapRadius, (right - left) * 0.5f)) * 0.5f
        val spreadZ = max(1f, min(heapRadius * 1.12f, (bottom - top) * 0.5f)) * 0.5f

        val heap = PieceHeap(n, cell)
        val stagger = min(0.05f, 1.4f / n)

        for (k in 0 until n) {
            var bestX = centerX
            var bestZ = centerZ
            var bestShortfall = Int.MAX_VALUE
            for (attempt in 0 until CANDIDATES) {
                val spread = if (random.nextFloat() < STRAY_CHANCE) STRAY_SPREAD else 1f
                val cx = (centerX + gaussian(random) * spreadX * spread).coerceIn(left, right)
                val cz = (centerZ + gaussian(random) * spreadZ * spread).coerceIn(top, bottom)
                val shortfall = heap.shortfall(cx, cz)
                if (shortfall < bestShortfall) {
                    bestShortfall = shortfall
                    bestX = cx
                    bestZ = cz
                    if (shortfall == 0) break
                }
            }
            heap.add(bestX, bestZ)

            val piece = game.pieces[order[k]]
            piece.x = bestX
            piece.z = bestZ
            piece.angle = if (rotatePieces) (random.nextFloat() * 2f - 1f) * AngleMath.PI_F else 0f
        }

        // Later arrivals land on top of earlier ones ...
        game.groups.clear()
        for (k in 0 until n) game.groups.add(game.pieces[order[k]].group)

        // ... and the heap settles under its own weight: pieces lie flat on the table, lean on
        // the edges of the pieces below, or (on a pile too tall to lean on) slide off. This can
        // nudge pieces, so it happens before the pour is set up from where they really ended up.
        game.settlePile()

        for (k in 0 until n) {
            val piece = game.pieces[order[k]]
            piece.animX = (centerX - piece.x) + (random.nextFloat() - 0.5f) * spreadX
            piece.animZ = -((piece.z - windowTop) + game.minCell * (1f + random.nextFloat() * 1.5f))
            piece.animAngle = (random.nextFloat() - 0.5f) * 3f * AngleMath.PI_F
            piece.animDelay = k * stagger

            // Every piece starts its fall high up, and lands where the heap says it rests.
            val group = piece.group
            group.lift = group.restLift + DROP_HEIGHT * game.minCell
            group.liftVelocity = 0f
            group.tiltX = 0f
            group.tiltZ = 0f
        }
    }

    /** A bell-shaped random number around 0, cut off at two standard deviations. */
    private fun gaussian(random: Random): Float {
        val u1 = 1f - random.nextFloat() // in (0, 1], so the logarithm is finite
        val u2 = random.nextFloat()
        val g = sqrt(-2f * ln(u1)) * cos(2f * PI.toFloat() * u2)
        return g.coerceIn(-2f, 2f)
    }
}

/** Points sampled over each piece to judge how much of it is still in view. */
private const val HEAP_SAMPLES = 9

/** A buried piece must keep at least this many of its sample points uncovered. */
private const val HEAP_MIN_VISIBLE = 4

/** Sample points sit on a ring of this radius, in piece sizes; a piece covers [HEAP_REACH]. */
private const val HEAP_RING = 0.34f
private const val HEAP_REACH = 0.58f

/**
 * The pieces placed so far, and how much of each can still be seen from above. A piece is
 * judged by nine sample points (its middle and a ring around it); a piece dropped on top
 * covers every sample point within its reach.
 */
private class PieceHeap(count: Int, cell: Float) {
    private val xs = FloatArray(count)
    private val zs = FloatArray(count)
    private val inView = BooleanArray(count * HEAP_SAMPLES) { true }
    private val visible = IntArray(count) { HEAP_SAMPLES }
    private val offX = FloatArray(HEAP_SAMPLES)
    private val offZ = FloatArray(HEAP_SAMPLES)
    private val reachSquared: Float
    private val near: Float
    private var placed = 0

    init {
        val ring = HEAP_RING * cell
        for (s in 1 until HEAP_SAMPLES) {
            val a = (s - 1) * (PI.toFloat() / 4f)
            offX[s] = ring * cos(a)
            offZ[s] = ring * sin(a)
        }
        val reach = HEAP_REACH * cell
        reachSquared = reach * reach
        // Further than this from a piece's middle, a new piece cannot reach any sample point.
        near = reach + ring
    }

    /**
     * How many sample points a piece dropped at ([x], [z]) would hide beyond what the pieces
     * below can spare. Zero means it buries nothing.
     */
    fun shortfall(x: Float, z: Float): Int {
        var total = 0
        for (j in 0 until placed) {
            if (abs(x - xs[j]) > near || abs(z - zs[j]) > near) continue
            var remaining = visible[j]
            val base = j * HEAP_SAMPLES
            for (s in 0 until HEAP_SAMPLES) {
                if (!inView[base + s]) continue
                val dx = x - (xs[j] + offX[s])
                val dz = z - (zs[j] + offZ[s])
                if (dx * dx + dz * dz < reachSquared) remaining--
            }
            if (remaining < HEAP_MIN_VISIBLE) total += HEAP_MIN_VISIBLE - remaining
        }
        return total
    }

    /** Drops the next piece at ([x], [z]) on top of the others. */
    fun add(x: Float, z: Float) {
        for (j in 0 until placed) {
            if (abs(x - xs[j]) > near || abs(z - zs[j]) > near) continue
            val base = j * HEAP_SAMPLES
            for (s in 0 until HEAP_SAMPLES) {
                if (!inView[base + s]) continue
                val dx = x - (xs[j] + offX[s])
                val dz = z - (zs[j] + offZ[s])
                if (dx * dx + dz * dz < reachSquared) {
                    inView[base + s] = false
                    visible[j]--
                }
            }
        }
        xs[placed] = x
        zs[placed] = z
        placed++
    }
}
