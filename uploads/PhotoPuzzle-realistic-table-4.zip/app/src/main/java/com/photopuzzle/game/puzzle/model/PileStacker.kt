package com.photopuzzle.game.puzzle.model

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * The physics of the heap: simple, but enough to behave the way a pile of cardboard does.
 *
 * Groups are kept in order from the bottom of the heap to the top, and every group rests on the
 * ones before it. Where a group comes to rest is worked out in three steps:
 *
 *  * [surfaceAt] finds what lies under each of the group's load points: the table, or the top
 *    of another piece (which may itself lean).
 *  * [solvePose] finds the plane the group settles on, the lowest one that clears everything
 *    under it. If the group's centre of mass is over something solid that plane is flat; if the
 *    centre hangs beyond the edge, the group leans down towards the table.
 *  * [settle] lets a group that leans too steeply to stay put slide downhill until it lies flat
 *    or finds a hold. A piece on the edge of a low pile simply stays there, leaning like a plank
 *    against a step (one end on the table, the other up on the edge); the lean grows with the
 *    height of the pile, so on a tall pile it is too steep to hold and the piece slides off.
 *
 * Taking a piece out of the heap ([collapseAfterRemoval]) re-settles whatever touched it, so
 * the pile above it falls in.
 */
internal class PileStacker(private val game: PuzzleGame) {

    // Scratch space, reused so settling never allocates.
    private val centre = FloatArray(2)
    private var sampleDx = FloatArray(64)
    private var sampleDz = FloatArray(64)
    private var sampleH = FloatArray(64)
    private var sampleCount = 0
    private var flatnessBias = 0f
    private var lastSlopeZ = 0f

    private var oldX = FloatArray(16)
    private var oldZ = FloatArray(16)
    private var bestX = FloatArray(16)
    private var bestZ = FloatArray(16)

    private val dirty = DirtyField()

    // ---- settling ------------------------------------------------------------------------

    /** Settles every group from the bottom of the heap up (the opening pour). */
    fun settleAll() = settleFrom(0)

    /** Re-settles every group from [fromIndex] to the top, whether or not it looks affected. */
    fun settleFrom(fromIndex: Int) {
        var i = max(0, fromIndex)
        while (i < game.groups.size) {
            val group = game.groups[i]
            if (!group.held) settle(group, i)
            i++
        }
    }

    /**
     * [removed] has just been lifted out of the heap from position [index] and is now the held
     * group on top. Whatever touched it loses its support and settles again, and whatever
     * touched that, and so on up the heap: the pile collapses. Returns how many groups dropped
     * by a noticeable amount.
     */
    fun collapseAfterRemoval(removed: PieceGroup, index: Int): Int {
        dirty.clear()
        markDirty(removed)
        var dropped = 0
        var i = max(0, index)
        while (i < game.groups.size) {
            val group = game.groups[i]
            if (!group.held && dirty.touches(group)) {
                val heightBefore = group.restLift
                if (settle(group, i)) {
                    markDirtyAtOldSpot(group)
                    markDirty(group)
                    if (heightBefore - group.restLift > NOTICEABLE_DROP * game.thickness) dropped++
                }
            }
            i++
        }
        return dropped
    }

    private fun markDirty(group: PieceGroup) {
        for (i in 0 until group.pieces.size) {
            val p = group.pieces[i]
            dirty.add(p.x, p.z, p.shape.boundingRadius)
        }
    }

    /** Valid right after [settle] on the same group: where its pieces were before. */
    private fun markDirtyAtOldSpot(group: PieceGroup) {
        for (i in 0 until group.pieces.size) {
            dirty.add(oldX[i], oldZ[i], group.pieces[i].shape.boundingRadius)
        }
    }

    /**
     * Finds where the group at [index] comes to rest on the groups below it, sliding it
     * downhill first if it would not stay put. Returns true if it ended up anywhere other than
     * where it was (a different height, a different lean, or a different spot on the table).
     */
    private fun settle(group: PieceGroup, index: Int): Boolean {
        val pieces = group.pieces
        val count = pieces.size
        ensurePieceScratch(count)
        val wasLift = group.restLift
        val wasSlopeX = group.restSlopeX
        val wasSlopeZ = group.restSlopeZ
        for (i in 0 until count) {
            oldX[i] = pieces[i].x
            oldZ[i] = pieces[i].z
        }

        var bestSlope = Float.MAX_VALUE
        var slope = 0f
        var steps = 0
        var scale = 1f
        var havePrevious = false
        var previousX = 0f
        var previousZ = 0f
        while (true) {
            solvePose(group, index)
            slope = hypot(group.restSlopeX, group.restSlopeZ)
            if (slope < bestSlope - SLOPE_EPSILON * 0.5f) {
                bestSlope = slope
                for (i in 0 until count) {
                    bestX[i] = pieces[i].x
                    bestZ[i] = pieces[i].z
                }
            }
            if (slope <= FRICTION_SLOPE || steps >= MAX_SLIDE_STEPS) break

            val downX = -group.restSlopeX / slope
            val downZ = -group.restSlopeZ / slope
            if (havePrevious) {
                // Heading back where it came from means it overshot a hold: take smaller steps.
                scale = if (downX * previousX + downZ * previousZ < -0.2f) {
                    scale * SLIDE_SHRINK
                } else {
                    min(scale * SLIDE_GROW, SLIDE_SCALE_MAX)
                }
            }
            previousX = downX
            previousZ = downZ
            havePrevious = true

            val distance = game.minCell * (SLIDE_GAIN * slope).coerceIn(SLIDE_MIN, SLIDE_MAX) * scale
            game.translate(group, downX * distance, downZ * distance)
            game.keepOnTable(group)
            steps++
        }

        // The last spot can be worse than an earlier one (it bounced between two holds).
        if (slope > bestSlope + SLOPE_EPSILON * 0.5f) {
            for (i in 0 until count) {
                pieces[i].x = bestX[i]
                pieces[i].z = bestZ[i]
            }
            solvePose(group, index)
        }

        var moved = false
        for (i in 0 until count) {
            val p = pieces[i]
            if (abs(p.x - oldX[i]) > MOVED_EPSILON || abs(p.z - oldZ[i]) > MOVED_EPSILON) {
                moved = true
                break
            }
        }
        if (moved) {
            // It slid: the picture glides there from where it was seen instead of jumping.
            for (i in 0 until count) {
                val p = pieces[i]
                p.animX += oldX[i] - p.x
                p.animZ += oldZ[i] - p.z
            }
        }

        group.liftTarget = group.restLift
        group.tiltTargetX = group.restSlopeX
        group.tiltTargetZ = group.restSlopeZ
        group.supportY = group.restLift

        return moved ||
            abs(group.restLift - wasLift) > LIFT_EPSILON ||
            abs(group.restSlopeX - wasSlopeX) > SLOPE_EPSILON ||
            abs(group.restSlopeZ - wasSlopeZ) > SLOPE_EPSILON
    }

    private fun ensurePieceScratch(count: Int) {
        if (oldX.size >= count) return
        val size = max(count, oldX.size * 2)
        oldX = FloatArray(size)
        oldZ = FloatArray(size)
        bestX = FloatArray(size)
        bestZ = FloatArray(size)
    }

    // ---- hovering ------------------------------------------------------------------------

    /**
     * Height of the tallest thing under a held [group] (the table is 0): how high it has to
     * hover to carry over the heap without scraping it.
     */
    fun surfaceUnder(group: PieceGroup): Float {
        var end = game.groups.indexOf(group)
        if (end < 0) end = game.groups.size
        // Big groups only need a sparse check; a single piece gets the full one.
        val stride = if (group.pieces.size > HOVER_FULL_PIECES) 6 else 2
        var best = 0f
        for (i in 0 until group.pieces.size) {
            val piece = group.pieces[i]
            val c = cos(piece.angle)
            val s = sin(piece.angle)
            val points = piece.shape.loadPoints
            var k = 0
            while (k < points.size) {
                val lx = points[k]
                val lz = points[k + 1]
                val h = surfaceAt(piece.x + lx * c - lz * s, piece.z + lx * s + lz * c, end)
                if (h > best) best = h
                k += stride
            }
        }
        return best
    }

    // ---- the resting plane ---------------------------------------------------------------

    /**
     * Height of the highest surface under the table point ([x], [z]), counting only the groups
     * before index [end]. Where nothing is under it, that is the table: 0.
     */
    private fun surfaceAt(x: Float, z: Float, end: Int): Float {
        var best = 0f
        val groups = game.groups
        for (gi in 0 until end) {
            val group = groups[gi]
            val pieces = group.pieces
            for (pi in 0 until pieces.size) {
                val q = pieces[pi]
                val r = q.shape.boundingRadius
                val dx = x - q.x
                val dz = z - q.z
                if (dx > r || dx < -r || dz > r || dz < -r) continue
                if (dx * dx + dz * dz > r * r) continue
                val c = cos(q.angle)
                val s = sin(q.angle)
                if (!q.shape.contains(dx * c + dz * s, -dx * s + dz * c)) continue
                val top = group.restLift +
                    group.restSlopeX * (x - group.poseX) +
                    group.restSlopeZ * (z - group.poseZ) +
                    game.thickness
                if (top > best) best = top
            }
        }
        return best
    }

    /**
     * Works out the plane the group at [index] lies on and stores it as its rest pose.
     *
     * The group touches the heap wherever its plane meets the surface under a load point, and
     * gravity pulls its centre of mass as low as it will go. So the answer is the plane that
     * clears every load point with the lowest height at the centre of mass: with h the height
     * under each point, minimise the max of (h - a*dx - b*dz) over the slopes a and b. That
     * function is convex, so a ternary search over a, around a ternary search over b, finds it.
     */
    private fun solvePose(group: PieceGroup, index: Int) {
        val pieces = group.pieces
        game.centroid(group, centre)
        val cx = centre[0]
        val cz = centre[1]

        var wanted = 0
        for (i in 0 until pieces.size) wanted += pieces[i].shape.loadPoints.size / 2
        ensureSampleScratch(wanted)

        var n = 0
        var low = Float.MAX_VALUE
        var high = -Float.MAX_VALUE
        for (i in 0 until pieces.size) {
            val piece = pieces[i]
            val c = cos(piece.angle)
            val s = sin(piece.angle)
            val points = piece.shape.loadPoints
            var k = 0
            while (k < points.size) {
                val lx = points[k]
                val lz = points[k + 1]
                val wx = piece.x + lx * c - lz * s
                val wz = piece.z + lx * s + lz * c
                val h = surfaceAt(wx, wz, index)
                sampleDx[n] = wx - cx
                sampleDz[n] = wz - cz
                sampleH[n] = h
                if (h < low) low = h
                if (h > high) high = h
                n++
                k += 2
            }
        }
        sampleCount = n

        group.poseX = cx
        group.poseZ = cz

        // Everything under it is level: it simply lies flat on that.
        if (high - low < LEVEL_EPSILON) {
            group.restLift = high
            group.restSlopeX = 0f
            group.restSlopeZ = 0f
            return
        }

        flatnessBias = FLATNESS_BIAS * game.thickness
        var lo = -SLOPE_LIMIT
        var hi = SLOPE_LIMIT
        for (step in 0 until SEARCH_STEPS) {
            val m1 = lo + (hi - lo) / 3f
            val m2 = hi - (hi - lo) / 3f
            if (lowestCostForSlopeX(m1) <= lowestCostForSlopeX(m2)) hi = m2 else lo = m1
        }
        val slopeX = (lo + hi) * 0.5f
        lowestCostForSlopeX(slopeX)
        val slopeZ = lastSlopeZ

        group.restSlopeX = slopeX
        group.restSlopeZ = slopeZ
        group.restLift = planeHeight(slopeX, slopeZ)
    }

    /** Best cost over every slope along z for the given slope along x; leaves the best z in [lastSlopeZ]. */
    private fun lowestCostForSlopeX(slopeX: Float): Float {
        var lo = -SLOPE_LIMIT
        var hi = SLOPE_LIMIT
        for (step in 0 until SEARCH_STEPS) {
            val m1 = lo + (hi - lo) / 3f
            val m2 = hi - (hi - lo) / 3f
            if (cost(slopeX, m1) <= cost(slopeX, m2)) hi = m2 else lo = m1
        }
        lastSlopeZ = (lo + hi) * 0.5f
        return cost(slopeX, lastSlopeZ)
    }

    /** Height of the plane at the centre of mass if it just clears every load point. */
    private fun planeHeight(slopeX: Float, slopeZ: Float): Float {
        var top = -Float.MAX_VALUE
        for (i in 0 until sampleCount) {
            val v = sampleH[i] - slopeX * sampleDx[i] - slopeZ * sampleDz[i]
            if (v > top) top = v
        }
        return top
    }

    /** The plane height, plus a whisper of preference for flat when several lean equally well. */
    private fun cost(slopeX: Float, slopeZ: Float): Float =
        planeHeight(slopeX, slopeZ) + flatnessBias * (slopeX * slopeX + slopeZ * slopeZ)

    private fun ensureSampleScratch(count: Int) {
        if (sampleH.size >= count) return
        val size = max(count, sampleH.size * 2)
        sampleDx = FloatArray(size)
        sampleDz = FloatArray(size)
        sampleH = FloatArray(size)
    }

    // ---- which groups a change can reach -------------------------------------------------

    /** Discs on the table marking where something changed; a group touching one may need to settle again. */
    private class DirtyField {
        private var xs = FloatArray(32)
        private var zs = FloatArray(32)
        private var rs = FloatArray(32)
        private var count = 0

        fun clear() {
            count = 0
        }

        fun add(x: Float, z: Float, r: Float) {
            if (count == xs.size) {
                xs = xs.copyOf(count * 2)
                zs = zs.copyOf(count * 2)
                rs = rs.copyOf(count * 2)
            }
            xs[count] = x
            zs[count] = z
            rs[count] = r
            count++
        }

        fun touches(group: PieceGroup): Boolean {
            for (i in 0 until group.pieces.size) {
                val p = group.pieces[i]
                val pr = p.shape.boundingRadius
                for (k in 0 until count) {
                    val dx = p.x - xs[k]
                    val dz = p.z - zs[k]
                    val reach = pr + rs[k]
                    if (dx * dx + dz * dz < reach * reach) return true
                }
            }
            return false
        }
    }

    private companion object {
        /**
         * Steepest lean considered (height gained per unit moved). Keep it above
         * [FRICTION_SLOPE]: a lean cut off at this limit must still count as too steep to hold.
         */
        const val SLOPE_LIMIT = 0.6f

        /** Iterations of each ternary search; the slope is found to well under a thousandth. */
        const val SEARCH_STEPS = 18

        /** Pull towards flat, as a fraction of the thickness. */
        const val FLATNESS_BIAS = 0.05f

        /** Height differences below this count as level. */
        const val LEVEL_EPSILON = 0.01f

        /**
         * The steepest lean (rise over run) a group holds without sliding: friction's angle of
         * repose, tan 30 degrees, about right for cardboard on cardboard.
         *
         * A piece leaning on the edge of a pile rises about 0.18 per piece of pile height, so up
         * to a pile three pieces tall it stays where it was dropped ("/"), and on anything taller
         * the lean is too steep and it slides off. Lower this and piles shed pieces sooner (0.4
         * lets pieces lean on one or two pieces only); raise it towards [SLOPE_LIMIT] and taller
         * piles hold a lean.
         */
        const val FRICTION_SLOPE = 0.58f

        /** How far a group slides per step: gain * lean, held between the two limits, in cells. */
        const val SLIDE_GAIN = 0.6f
        const val SLIDE_MIN = 0.08f
        const val SLIDE_MAX = 0.25f

        /** Steps grow while heading steadily downhill and shrink when it doubles back. */
        const val SLIDE_GROW = 1.15f
        const val SLIDE_SHRINK = 0.5f
        const val SLIDE_SCALE_MAX = 2f
        const val MAX_SLIDE_STEPS = 16

        /** Smallest changes that count as "it moved" / "the height changed" / "the lean changed". */
        const val MOVED_EPSILON = 0.01f
        const val LIFT_EPSILON = 0.01f
        const val SLOPE_EPSILON = 0.002f

        /** Groups of up to this many pieces get the full hover check while held. */
        const val HOVER_FULL_PIECES = 6

        /** A fall of at least this fraction of a piece's thickness counts as a collapse. */
        const val NOTICEABLE_DROP = 0.25f
    }
}
