package com.hzcm.duelforge.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

/** Selection state while the player is choosing tributes for a pending Normal Summon / Set. */
data class TributeSelection(
    val card: CardInstance,
    val asSet: Boolean,
    val required: Int,
    val chosen: List<CardInstance> = emptyList()
)

/**
 * Wraps [GameEngine] for the UI. [com.hzcm.duelforge.model.GameState] is a plain mutable
 * class, not Compose state, so every action bumps [refresh] to force recomposition - the
 * UI then reads fresh values straight from `engine.state`.
 */
class GameViewModel(application: Application) : AndroidViewModel(application) {
    val engine: GameEngine = GameEngine(application.applicationContext)

    /** Bumped after every engine mutation; read (but ignored) by composables that should recompose. */
    var refresh by mutableIntStateOf(0)
        private set

    /** A card (hand, own field monster, or own Spell/Trap zone) the player has tapped. */
    var selectedCard by mutableStateOf<CardInstance?>(null)
        private set

    /** Non-null while the player is choosing tributes for [selectedCard]. */
    var tributeSelection by mutableStateOf<TributeSelection?>(null)
        private set

    /** The attacker chosen during the Battle Phase, awaiting a target tap or direct-attack confirmation. */
    var attackerSelection by mutableStateOf<CardInstance?>(null)

    /**
     * The card(s) the player has tapped to discard while a [DiscardRequest] is pending.
     * The player must pick exactly [DiscardRequest.count] cards before "Confirm" enables.
     */
    var discardChosen by mutableStateOf<List<CardInstance>>(emptyList())
        private set

    init {
        engine.startGame()
        refresh++
    }

    private fun bump() { refresh++ }

    // ------------------------------------------------------------------
    // Selection
    // ------------------------------------------------------------------

    fun clearSelection() {
        selectedCard = null
        tributeSelection = null
        attackerSelection = null
    }

    /** Tap on a card in the human player's hand. */
    fun onHandCardTapped(card: CardInstance) {
        if (tributeSelection != null) return
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    /** Tap on one of the human player's own field monsters. */
    fun onOwnMonsterTapped(card: CardInstance) {
        if (tributeSelection != null) {
            toggleTribute(card)
            return
        }
        if (engine.state.phase == Phase.BATTLE) {
            selectedCard = null
            attackerSelection = if (attackerSelection === card) null else card
            return
        }
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    /** Tap on one of the human player's own Spell/Trap zone cards. */
    fun onOwnSpellTrapTapped(card: CardInstance) {
        if (tributeSelection != null) return
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    /** Tap on an opponent's monster - if an attacker is selected and the attack is legal, declares it. */
    fun onOpponentMonsterTapped(card: CardInstance) {
        val attacker = attackerSelection ?: return
        if (!engine.canDeclareAttack(attacker, card)) return
        attackerSelection = null
        engine.declareAttack(attacker, card) { bump() }
        bump()
    }

    // ------------------------------------------------------------------
    // Summon / Set / Flip / Position
    // ------------------------------------------------------------------

    /** Begins Normal Summon (or Set, if [asSet]) for [selectedCard], opening tribute selection if needed. */
    fun beginSummon(asSet: Boolean) {
        val card = selectedCard ?: return
        val required = card.card.tributesRequired
        if (required > 0) {
            tributeSelection = TributeSelection(card, asSet, required)
            return
        }
        if (asSet) engine.setMonster(card, emptyList()) { bump() }
        else engine.normalSummon(card, emptyList()) { bump() }
        selectedCard = null
        bump()
    }

    private fun toggleTribute(card: CardInstance) {
        val sel = tributeSelection ?: return
        if (card.location != Location.MONSTER_ZONE || card.controller != PlayerId.PLAYER) return
        val chosen = sel.chosen.toMutableList()
        if (chosen.contains(card)) {
            chosen.remove(card)
        } else if (chosen.size < sel.required) {
            chosen.add(card)
        }
        tributeSelection = sel.copy(chosen = chosen)
    }

    fun confirmTributeSummon() {
        val sel = tributeSelection ?: return
        if (sel.chosen.size != sel.required) return
        if (sel.asSet) engine.setMonster(sel.card, sel.chosen) { bump() }
        else engine.normalSummon(sel.card, sel.chosen) { bump() }
        tributeSelection = null
        selectedCard = null
        bump()
    }

    fun cancelTributeSummon() {
        tributeSelection = null
    }

    /** Sets a Trap card face-down from hand. */
    fun setTrap() {
        val card = selectedCard ?: return
        engine.setSpellOrTrap(card) { bump() }
        selectedCard = null
        bump()
    }

    /** Activates a Normal/Quick-Play Spell from hand, or an Ignition/Quick effect on a field monster. */
    fun activateEffect(effect: CardEffect) {
        val card = selectedCard ?: return
        engine.activateEffect(card, effect) { bump() }
        selectedCard = null
        bump()
    }

    fun flipSummon() {
        val card = selectedCard ?: return
        engine.flipSummon(card) { bump() }
        selectedCard = null
        bump()
    }

    fun changeBattlePosition(newPosition: BattlePosition) {
        val card = selectedCard ?: return
        engine.changeBattlePosition(card, newPosition) { bump() }
        selectedCard = null
        bump()
    }

    // ------------------------------------------------------------------
    // Battle
    // ------------------------------------------------------------------

    fun declareDirectAttack() {
        val attacker = attackerSelection ?: return
        if (!engine.canDeclareAttack(attacker, null)) return
        attackerSelection = null
        engine.declareAttack(attacker, null) { bump() }
        bump()
    }

    // ------------------------------------------------------------------
    // Phase / priority
    // ------------------------------------------------------------------

    fun advancePhase() {
        clearSelection()
        engine.advancePhase()
        bump()
    }

    fun submitPriorityChoice(index: Int?) {
        engine.submitPriorityChoice(index)
        bump()
    }

    /** Toggle a card in/out of the pending discard selection. */
    fun onDiscardCardToggled(card: CardInstance) {
        val req = engine.state.pendingDiscard ?: return
        val chosen = discardChosen.toMutableList()
        if (chosen.contains(card)) chosen.remove(card)
        else if (chosen.size < req.count) chosen.add(card)
        discardChosen = chosen
    }

    /**
     * Confirm the player's chosen discard(s), send them to the GY, and resume
     * chain resolution. Only callable when [discardChosen].size == [DiscardRequest.count].
     */
    fun confirmDiscard() {
        val callback = engine.pendingDiscardResume ?: return
        val chosen   = discardChosen.toList()
        engine.state.pendingDiscard = null
        engine.pendingDiscardResume = null
        discardChosen = emptyList()
        chosen.forEach { engine.sendToGraveyard(it) }
        callback(chosen)
        // If the chain has more links left, continue resolving.
        if (engine.state.chain.isNotEmpty()) engine.resolveChain()
        bump()
    }

    /** Restarts the duel from scratch (used by the "New Duel" button after a game over). */
    fun restart() {
        clearSelection()
        engine.startGame()
        bump()
    }
}
