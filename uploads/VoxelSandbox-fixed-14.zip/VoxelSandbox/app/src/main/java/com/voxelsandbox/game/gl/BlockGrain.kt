package com.voxelsandbox.game.gl

/**
 * The per-block brightness variation ("grain") of the ground: each block of terrain is a touch brighter or
 * darker than its neighbours, by a hash of its position, so a field of one block type does not read as a flat
 * sheet. The voxel shader applies it to every block, and the distant-terrain shader applies the very same
 * numbers to its columns (per block of ground, not per column), so the two layers are equally grainy where
 * they overlap, and fade it out at the same distances.
 */
object BlockGrain {
    /** Blocks nearer than this get the full variation... */
    const val NEAR = 110.0f

    /** ...and past this none at all (a block is only a few pixels by then, and the mip chain averages it). */
    const val FAR = 170.0f

    /** How much the brightness may vary (a factor of 1 - range .. 1): solid ground, and leaves. */
    const val SOLID_RANGE = 0.06f
    const val LEAF_RANGE = 0.14f
}
