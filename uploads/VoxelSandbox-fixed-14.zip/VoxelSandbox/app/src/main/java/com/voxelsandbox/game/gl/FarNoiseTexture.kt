package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * A small tileable noise texture (one byte per texel) that the distant-terrain shader samples
 * by world position. It adds smooth, soft tonal variation to the flat palette colours of far
 * columns: because it is a function of the position in the world alone, it is anchored to the
 * ground (never moves with the camera), is identical for every level of detail, and its mip
 * chain fades it out by itself where it would only alias. Four octaves of periodic value
 * noise are baked in, so one fetch gives a multi-scale pattern.
 */
class FarNoiseTexture {
    private var textureId = 0

    /** Call from onSurfaceCreated (a new GL context needs a fresh texture). */
    fun upload() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UPLOAD_UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)

        val data = generate()
        val buf = ByteBuffer.allocateDirect(SIZE * SIZE).order(ByteOrder.nativeOrder())
        buf.put(data)
        buf.position(0)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, SIZE, SIZE, 0,
            GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    fun bind(unit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    /** Periodic value noise, summed over four octaves (4, 8, 16 and 32 lattice cells across
     *  the texture), stretched a little so the tonal range is worth having. */
    private fun generate(): ByteArray {
        val acc = FloatArray(SIZE * SIZE)
        val periods = intArrayOf(4, 8, 16, 32)
        val weights = floatArrayOf(0.46f, 0.30f, 0.16f, 0.08f)
        for (o in periods.indices) {
            val p = periods[o]
            val lattice = FloatArray(p * p)
            for (k in lattice.indices) lattice[k] = hash01(k % p, k / p, 101 + o)
            val cell = SIZE.toFloat() / p
            for (y in 0 until SIZE) {
                val fy = y / cell
                val y0 = fy.toInt()
                val ty = fy - y0
                val sy = ty * ty * (3f - 2f * ty)
                val ya = y0 % p
                val yb = (y0 + 1) % p
                for (x in 0 until SIZE) {
                    val fx = x / cell
                    val x0 = fx.toInt()
                    val tx = fx - x0
                    val sx = tx * tx * (3f - 2f * tx)
                    val xa = x0 % p
                    val xb = (x0 + 1) % p
                    val a = lattice[ya * p + xa]
                    val b = lattice[ya * p + xb]
                    val c = lattice[yb * p + xa]
                    val d = lattice[yb * p + xb]
                    val v = a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy
                    acc[y * SIZE + x] += v * weights[o]
                }
            }
        }
        val out = ByteArray(SIZE * SIZE)
        for (i in out.indices) {
            val v = ((acc[i] - 0.5f) * 1.7f + 0.5f).coerceIn(0f, 1f)
            out[i] = (v * 255f + 0.5f).toInt().toByte()
        }
        return out
    }

    private fun hash01(x: Int, y: Int, salt: Int): Float {
        var h = x * 73856093 xor y * 19349663 xor salt * 83492791
        h = h xor (h ushr 15)
        h *= 739982445
        h = h xor (h ushr 13)
        return ((h ushr 8) and 0xFFFF) / 65536f
    }

    companion object {
        /** Texels per side. One repeat covers 1024 blocks (see FAR_FRAGMENT). */
        const val SIZE = 128

        /** Texture unit used while uploading (any unit would do). */
        private const val UPLOAD_UNIT = 2
    }
}
