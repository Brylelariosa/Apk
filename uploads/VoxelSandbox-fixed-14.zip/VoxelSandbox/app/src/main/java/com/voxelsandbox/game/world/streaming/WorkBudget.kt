package com.voxelsandbox.game.world.streaming

import kotlin.math.max
import kotlin.math.min

/**
 * Adaptive work budgets: how much background and GPU-upload work to allow right now, chosen from
 * what the game is actually doing instead of from fixed constants or (as the old "smooth mode"
 * did) by shrinking the view distance.
 *
 *  - [activeWorkers]: how many streaming threads are awake. One is enough while the world is
 *    settled; more wake up as the backlog grows (fast flight), up to [maxWorkers]. When frames are
 *    already slow and the backlog is not an emergency, the thread count is held to half so the
 *    CPU (and the memory bus the GPU shares with it) is left to the render thread.
 *  - [uploadBytesPerFrame]: how much packed mesh data the GL thread may hand to the driver in one
 *    frame. A frame with time to spare takes a lot; a frame that is already late takes little (but
 *    never nothing: see RegionGpuStore).
 */
class WorkBudget(private val maxWorkers: Int) {
    @Volatile
    var activeWorkers: Int = max(1, min(2, maxWorkers))
        private set

    @Volatile
    private var frameMsAverage = 16f

    private var lastLowerCandidateMs = 0L

    /** Called by the GL thread once per frame with that frame's duration. */
    fun reportFrame(frameMs: Float) {
        val ms = if (frameMs < 1f) 1f else if (frameMs > 200f) 200f else frameMs
        frameMsAverage += (ms - frameMsAverage) * 0.06f
    }

    /** Called by the scheduler thread a few times a second. */
    fun update(backlog: Int, nowMs: Long) {
        var want = when {
            backlog <= 0 -> 1
            backlog < 6 -> 2
            else -> 2 + backlog / 10
        }
        if (want > maxWorkers) want = maxWorkers
        if (frameMsAverage > SLOW_FRAME_MS && backlog < EMERGENCY_BACKLOG) want = min(want, max(1, maxWorkers / 2))
        val current = activeWorkers
        if (want >= current) {
            activeWorkers = want
            lastLowerCandidateMs = nowMs
        } else if (nowMs - lastLowerCandidateMs > SHRINK_DELAY_MS) {
            activeWorkers = want
            lastLowerCandidateMs = nowMs
        }
    }

    /** Bytes of packed mesh data the GL thread may upload this frame (in addition to edits). */
    fun uploadBytesPerFrame(): Int = when {
        frameMsAverage < 13f -> 3_000_000
        frameMsAverage < 19f -> 1_800_000
        frameMsAverage < 28f -> 1_000_000
        else -> 600_000
    }

    /** Wall-clock budget (ns) for one frame's uploads; a second guard next to the byte budget. */
    fun uploadNanosPerFrame(): Long = if (frameMsAverage < 19f) 3_500_000L else 2_000_000L

    private companion object {
        const val SLOW_FRAME_MS = 33f
        const val EMERGENCY_BACKLOG = 40
        const val SHRINK_DELAY_MS = 600L
    }
}
