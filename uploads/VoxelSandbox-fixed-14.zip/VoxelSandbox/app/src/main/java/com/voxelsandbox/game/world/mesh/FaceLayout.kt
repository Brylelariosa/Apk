package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.world.Face

/**
 * The geometry of one block face, in one place: the mesher builds its quads from it, and the voxel shader
 * (which, for a face merged out of many blocks, has to work out where in a block's face a fragment is)
 * builds its lookup tables from it, so the two can never disagree about which way a texture runs.
 *
 * A face is a quad with four corners, v0..v3 ([CORNERS], in [Face] order: top, bottom, north, south, east,
 * west), wound counter-clockwise seen from outside (see MeshBuilder.quad for how the triangles are cut).
 * The corners double as the texture layout: the tile's left edge is v0 -> v1 and its rows run v1 -> v2 on the
 * top and the bottom (image row 0 first) and the other way round on the sides, where the first two corners
 * are the bottom edge and image row 0 is the top of the tile. That is what keeps grass fringes and bark
 * streaks the right way up on walls.
 */
object FaceLayout {
    /** Corner offsets (x, y, z for v0..v3) of each face's quad inside its block, in [Face] order. */
    val CORNERS: Array<IntArray> = arrayOf(
        intArrayOf(0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 1), // TOP
        intArrayOf(0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0), // BOTTOM
        intArrayOf(1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0), // NORTH
        intArrayOf(0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1), // SOUTH
        intArrayOf(1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1), // EAST
        intArrayOf(0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0)  // WEST
    )

    /** What a quad's corner is called in the vertex data: 0 = v0, 1 = v1 (the right-hand one of the first
     *  row), 2 = v3, 3 = v2: `code = (right ? 1 : 0) + (second row ? 2 : 0)` where the first row is v0 v1 and
     *  the second is v3 v2. [VERTEX_OF_CORNER] maps a code to the vertex. */
    val VERTEX_OF_CORNER = intArrayOf(0, 1, 3, 2)

    /**
     * How the mesher marks the right-hand corners of a quad in the first texture slot (the second row
     * is marked in the other slot, see ChunkMesher.emitCubeRect): [CORNER_U] is added to the face's
     * description. The description itself stays below it (12 bits).
     */
    const val CORNER_U = 8192f

    /** The unit vector (signed axis) along which the tile's columns run on face [face]: the direction in which
     *  the texture's u coordinate increases. */
    fun tileU(face: Int): IntArray {
        val v = CORNERS[face]
        return intArrayOf(v[3] - v[0], v[4] - v[1], v[5] - v[2])
    }

    /** The unit vector along which the tile's image rows advance (row 0 at the top of the tile) on face [face]. */
    fun tileV(face: Int): IntArray {
        val v = CORNERS[face]
        val sign = if (face < 2) 1 else -1
        return intArrayOf(sign * (v[6] - v[3]), sign * (v[7] - v[4]), sign * (v[8] - v[5]))
    }

    /** The outward normal of face [face]. */
    fun normal(face: Int): IntArray {
        val f = Face.ALL[face]
        return intArrayOf(f.dx, f.dy, f.dz)
    }

    /** For a corner (see [VERTEX_OF_CORNER]) of face [face]: which way from the centre of the quad it lies, as a
     *  vector of -1, 0 (along the normal) and +1. The shader moves a corner a hair's breadth along it. */
    fun cornerDirection(face: Int, code: Int): IntArray {
        val v = CORNERS[face]
        val k = VERTEX_OF_CORNER[code]
        val f = Face.ALL[face]
        val n = intArrayOf(f.dx, f.dy, f.dz)
        return IntArray(3) { axis -> if (n[axis] != 0) 0 else if (v[k * 3 + axis] == 1) 1 else -1 }
    }

    init {
        for (f in 0 until 6) {
            val n = normal(f)
            for (axis in listOf(tileU(f), tileV(f))) {
                check(axis.count { it != 0 } == 1 && axis.sumOf { it * it } == 1) { "tile axis of face $f is not a unit axis" }
                check(axis[0] * n[0] + axis[1] * n[1] + axis[2] * n[2] == 0) { "tile axis of face $f is not in its plane" }
            }
        }
    }
}
