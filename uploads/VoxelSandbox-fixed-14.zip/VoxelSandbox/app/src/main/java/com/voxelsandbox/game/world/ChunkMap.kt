package com.voxelsandbox.game.world

import java.util.concurrent.atomic.AtomicReferenceArray

/**
 * The world's chunk table: packed (chunkX, chunkZ) -> [Chunk]. It sits under every block lookup in
 * the game (physics, raycasts, the mesher's neighbour reads on several threads), so two properties
 * matter and the general-purpose `ConcurrentHashMap<Long, Chunk>` it replaces had neither:
 *
 *  - No boxing. A `Long` key had to be boxed for every single lookup (an allocation per block
 *    read once the key is outside the small-value cache), which is gigabytes of short-lived garbage
 *    over a play session.
 *  - A hash that spreads. `Long.hashCode()` is `x xor z` of the two halves, and the key packs the two
 *    chunk coordinates into the two halves, so every chunk with the same `cx xor cz` shared a hash:
 *    a ring of ~1100 chunks fell into a few dozen buckets of ~20 entries each.
 *
 * Reads are lock-free: the table is a volatile reference to an array of immutable entries, and a
 * slot is only ever replaced by another complete entry, so a reader sees an old state or a new state,
 * never a half-written one. Writes (adding and removing chunks: a few per frame at most, from the
 * scheduler and worker threads) take a lock. Removing leaves a tombstone (the key with no chunk) so
 * that probe sequences stay intact; tombstones are dropped when the table is rebuilt, which also
 * happens when it gets crowded (the table never holds more than half of its slots, tombstones
 * included, so a probe always ends at an empty slot).
 */
class ChunkMap(initialCapacity: Int = MIN_CAPACITY) {

    private class Entry(@JvmField val key: Long, @JvmField val chunk: Chunk?)

    @Volatile
    private var table = AtomicReferenceArray<Entry?>(capacityFor(initialCapacity))
    private val lock = Any()

    /** Slots in use, tombstones included (guarded by [lock]). */
    private var used = 0

    /** Number of chunks in the map. */
    @Volatile
    var size: Int = 0
        private set

    operator fun get(key: Long): Chunk? {
        val t = table
        val mask = t.length() - 1
        var i = slotOf(key, mask)
        while (true) {
            val e = t.get(i) ?: return null
            if (e.key == key) return e.chunk
            i = (i + 1) and mask
        }
    }

    fun containsKey(key: Long): Boolean = get(key) != null

    /** Adds or replaces the chunk for [key]. */
    fun put(key: Long, chunk: Chunk) {
        synchronized(lock) {
            if (used * 2 >= table.length()) rebuild(size + 1)
            val t = table
            val mask = t.length() - 1
            var i = slotOf(key, mask)
            while (true) {
                val e = t.get(i)
                if (e == null) {
                    t.set(i, Entry(key, chunk))
                    used++
                    size++
                    return
                }
                if (e.key == key) {
                    if (e.chunk == null) size++ // a tombstone coming back to life
                    t.set(i, Entry(key, chunk))
                    return
                }
                i = (i + 1) and mask
            }
        }
    }

    /** Removes and returns the chunk for [key] (null if there was none). */
    fun remove(key: Long): Chunk? {
        synchronized(lock) {
            val t = table
            val mask = t.length() - 1
            var i = slotOf(key, mask)
            while (true) {
                val e = t.get(i) ?: return null
                if (e.key == key) {
                    val old = e.chunk ?: return null
                    t.set(i, Entry(key, null))
                    size--
                    return old
                }
                i = (i + 1) and mask
            }
        }
    }

    /** The chunks as a read-only collection. It walks the table as it was when the call was made, so it
     *  never throws on concurrent changes (it may or may not show chunks added or removed meanwhile). */
    fun values(): Collection<Chunk> = object : AbstractCollection<Chunk>() {
        private val snapshot = table
        override val size: Int get() = this@ChunkMap.size
        override fun iterator(): Iterator<Chunk> = object : Iterator<Chunk> {
            private var index = 0
            private var nextChunk: Chunk? = advance()

            private fun advance(): Chunk? {
                while (index < snapshot.length()) {
                    val c = snapshot.get(index++)?.chunk
                    if (c != null) return c
                }
                return null
            }

            override fun hasNext(): Boolean = nextChunk != null

            override fun next(): Chunk {
                val c = nextChunk ?: throw NoSuchElementException()
                nextChunk = advance()
                return c
            }
        }
    }

    // ---- internals --------------------------------------------------------------------------

    /** Replaces the table by a fresh one sized for [liveCount] chunks (at most a quarter full), keeping
     *  only live chunks. Caller holds [lock]. Readers still walking the old table are unaffected. */
    private fun rebuild(liveCount: Int) {
        val old = table
        val fresh = AtomicReferenceArray<Entry?>(capacityFor(liveCount * 4))
        val mask = fresh.length() - 1
        var count = 0
        for (n in 0 until old.length()) {
            val e = old.get(n) ?: continue
            if (e.chunk == null) continue
            var i = slotOf(e.key, mask)
            while (fresh.get(i) != null) i = (i + 1) and mask
            fresh.set(i, e)
            count++
        }
        used = count
        size = count
        table = fresh
    }

    private companion object {
        const val MIN_CAPACITY = 1024

        fun capacityFor(wanted: Int): Int {
            var c = MIN_CAPACITY
            while (c < wanted && c < (1 shl 29)) c = c shl 1
            return c
        }

        /** Spreads the packed key (two chunk coordinates in the two halves of a Long, so neighbouring
         *  chunks differ only in low bits of either half) over the whole table. */
        fun slotOf(key: Long, mask: Int): Int {
            var h = key * -7046029254386353131L // 0x9E3779B97F4A7C15, the golden-ratio multiplier
            h = h xor (h ushr 29)
            h *= -4658895280553007687L
            return (h ushr 32).toInt() and mask
        }
    }
}
