package com.voxelsandbox.game.world.streaming

/**
 * Which snapshot of each region the GPU is showing (see [PackedRegion.sequence]), so a pack that
 * was overtaken on the way can be recognised and skipped instead of replacing a newer one.
 *
 * Without this, two packs of the same region racing through two worker threads could arrive in
 * either order. If the older one came last it would put a column back that had just been unloaded,
 * or remove one that had just been loaded, and the region would show that wrong picture until the
 * next change happened to trigger another pack: terrain that flashed away and came back.
 *
 * No GL in here: the GL thread asks [admit] before it uploads, and the policy can be tested on its own.
 * GL thread only.
 */
class RegionVersions {
    private val applied = HashMap<Long, Long>()
    private var newest = 0L
    private var pruneAt = PRUNE_AT

    /** Packs that were skipped because a newer one of the region had already been shown (statistics). */
    var rejected = 0L
        private set

    /**
     * True if a pack numbered [sequence] may be shown for [region] now: nothing newer has been shown.
     * When it returns true the pack counts as shown (it is recorded); on false the caller must drop it.
     */
    fun admit(region: Long, sequence: Long): Boolean {
        val shown = applied[region]
        if (shown != null && shown > sequence) {
            rejected++
            return false
        }
        applied[region] = sequence
        if (sequence > newest) newest = sequence
        if (applied.size > pruneAt) prune()
        return true
    }

    /** The GL context was lost or the world was replaced: nothing is on the GPU any more. */
    fun clear() {
        applied.clear()
        newest = 0L
    }

    val size: Int get() = applied.size

    /** Forgets regions whose last pack is so old that no pack still on its way can be older: a pack
     *  takes milliseconds to build, and this many numbers is minutes of packing. Keeps the table
     *  from growing with every region the player has ever flown over. */
    private fun prune() {
        val floor = newest - KEEP_SEQUENCES
        val it = applied.entries.iterator()
        while (it.hasNext()) if (it.next().value < floor) it.remove()
        pruneAt = maxOf(PRUNE_AT, applied.size * 2)
    }

    private companion object {
        const val PRUNE_AT = 4096
        const val KEEP_SEQUENCES = 100_000L
    }
}
