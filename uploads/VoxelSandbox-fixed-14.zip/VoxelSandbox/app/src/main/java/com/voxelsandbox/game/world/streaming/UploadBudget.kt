package com.voxelsandbox.game.world.streaming

/**
 * The one rule every per-frame GPU upload loop follows (chunk regions, distant-terrain tiles): another
 * upload goes ahead only while the frame's byte budget and time budget are not spent, **except that the
 * first one of a call always goes**. So a mesh bigger than the whole budget is slow (one per call), never
 * stuck in the queue for ever, and a frame with nothing waiting costs nothing.
 *
 * It is a pure function of numbers so the rule lives in one place and can be tested without a GL context.
 */
object UploadBudget {
    /**
     * @param uploadsSoFar uploads already done in this call
     * @param bytesSoFar bytes those uploads handed to the driver
     * @param nextBytes size of the upload being considered
     * @param byteBudget most bytes to hand over in this call
     * @param elapsedNs time since the call began
     * @param nanoBudget most time to spend in this call
     */
    fun admits(uploadsSoFar: Int, bytesSoFar: Long, nextBytes: Int, byteBudget: Int, elapsedNs: Long, nanoBudget: Long): Boolean =
        uploadsSoFar == 0 || (bytesSoFar + nextBytes <= byteBudget && elapsedNs <= nanoBudget)
}
