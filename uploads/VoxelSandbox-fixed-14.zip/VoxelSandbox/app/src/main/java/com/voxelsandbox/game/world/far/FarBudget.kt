package com.voxelsandbox.game.world.far

/**
 * Fits the distant-terrain tile plan into the GPU byte budget, and decides how far out the horizon
 * can reach when it does not all fit. Pure logic (no GL, no threads), so it can be tested alone.
 *
 * The plan is sorted by ([Entry.rank], [Entry.near]): the tiles the picture needs come first, nearest
 * first; then the optional finest ring; then the tiles that are only prefetched for where the player
 * is heading. Under budget pressure the plan is cut from the END, which is the right way round: the
 * prefetch goes first, then the finest ring, then the far end of the horizon. What is never cut is
 * the ground near the player.
 *
 * The cut is a *horizon* (a distance), not a list of individual tiles, and it has hysteresis: it
 * stays where it is while the budget allows anything between a 82 % and a 95 % fill, so a tile
 * arriving or leaving at the edge of the budget does not move it. Without that, the farthest tile
 * is built, the budget overflows, the tile is dropped, there is room again, it is built again, and
 * so on (and every such round used to pull the fog in for a moment, see GameRenderer).
 */
class FarBudget {
    /** One planned tile. [bytes] is its real size once it has been built, otherwise an estimate. */
    class Entry(
        @JvmField val key: Long,
        /** Distance from the player to the nearest point of the tile that is actually drawn. */
        @JvmField val near: Float,
        @JvmField val rank: Int,
        @JvmField val bytes: Int
    )

    /** [keep]: the tiles that may exist; [horizon]: the distance the required tiles reach (or
     *  [NO_LIMIT] when all of them fit). */
    class Fit(@JvmField val keep: HashSet<Long>, @JvmField val horizon: Float)

    private var horizon = NO_LIMIT

    fun reset() {
        horizon = NO_LIMIT
    }

    /** [entries] must be sorted by (rank, near). */
    fun fit(entries: List<Entry>, limitBytes: Long): Fit {
        val high = (limitBytes * FILL_HIGH).toLong()
        val low = (limitBytes * FILL_LOW).toLong()
        val reachHigh = reach(entries, high)
        val reachLow = reach(entries, low)
        // reachLow <= reachHigh: with less room the horizon is nearer. The horizon moves only when it
        // leaves that band.
        horizon = if (horizon < reachLow) reachLow else if (horizon > reachHigh) reachHigh else horizon

        val keep = HashSet<Long>(entries.size * 2)
        var used = 0L
        for (e in entries) {
            if (e.rank != RANK_REQUIRED) break
            if (e.near >= horizon) break
            used += e.bytes
            keep.add(e.key)
        }
        for (e in entries) {
            if (e.rank == RANK_REQUIRED) continue
            if (used + e.bytes > high) continue
            used += e.bytes
            keep.add(e.key)
        }
        return Fit(keep, horizon)
    }

    /** How far the required tiles reach before their cumulative size passes [allowed]. */
    private fun reach(entries: List<Entry>, allowed: Long): Float {
        var used = 0L
        for (e in entries) {
            if (e.rank != RANK_REQUIRED) break
            used += e.bytes
            if (used > allowed) return e.near
        }
        return NO_LIMIT
    }

    companion object {
        const val NO_LIMIT = Float.MAX_VALUE

        /** Tiles the picture needs: their visible part is inside the render distance and the band. */
        const val RANK_REQUIRED = 0

        /** The optional finest ring: improves ground that the level behind it already covers. */
        const val RANK_FINE = 1

        /** Tiles planned a little beyond their band, so they are there before the player arrives. */
        const val RANK_PREFETCH = 2

        /** The plan may fill up to this share of the budget; a horizon cut lifts only below the lower. */
        const val FILL_HIGH = 0.95
        const val FILL_LOW = 0.82

        /** Resident tiles are only evicted for the budget's sake above this share, down to the lower. */
        const val EVICT_ABOVE = 0.97
        const val EVICT_TO = 0.90
    }
}
