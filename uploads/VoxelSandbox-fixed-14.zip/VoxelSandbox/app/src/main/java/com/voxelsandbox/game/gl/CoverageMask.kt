package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Which chunk columns have their terrain on the GPU right now: one byte per column, in a square
 * that wraps around ([SIZE] columns a side, so the loaded area can be up to [SIZE] / 2 chunks in
 * radius before two columns share a cell, far more than the memory budget ever allows).
 *
 * The CPU keeps the bytes (cheap coverage scans without boxing a Long per lookup) and mirrors them
 * into an R8 texture, which the distant-terrain and water shaders read with `texelFetch`. That is
 * what lets them fill *exactly* the columns the voxel terrain is missing, and nothing else:
 *
 *  - the distant ground and sea are drawn wherever a column is not covered, however deep inside the
 *    voxel area it is (a chunk that is still loading, or was just unloaded), so there is never a
 *    hole through which the sky shows;
 *  - and they are *not* drawn where a column is covered, so the two layers never overlap into a
 *    darker or lighter patch.
 *
 * Before, the same question was answered with a circle: "everything up to the first missing chunk
 * is covered". One missing chunk then pulled that circle in over the whole area behind it, which
 * made lake surfaces vanish and the finest ring of distant terrain switch off and on.
 *
 * GL thread only.
 */
class CoverageMask {
    private val bytes = ByteArray(SIZE * SIZE)
    private val upload: ByteBuffer = ByteBuffer.allocateDirect(SIZE * SIZE).order(ByteOrder.nativeOrder())
    private var textureId = 0

    // Rows touched since the last [flush] (inclusive); minRow > maxRow = clean.
    private var minRow = Int.MAX_VALUE
    private var maxRow = -1
    private var needsFullUpload = true

    /** Number of covered columns (statistics). */
    var covered = 0
        private set

    fun isCovered(cx: Int, cz: Int): Boolean = bytes[index(cx, cz)].toInt() != 0

    fun set(cx: Int, cz: Int, value: Boolean) {
        val i = index(cx, cz)
        val v: Byte = if (value) 1 else 0
        if (bytes[i] == v) return
        bytes[i] = v
        covered += if (value) 1 else -1
        val row = i / SIZE
        if (row < minRow) minRow = row
        if (row > maxRow) maxRow = row
    }

    /** Forgets every column (the GL context was lost, or the world was reset). */
    fun clear() {
        java.util.Arrays.fill(bytes, 0.toByte())
        covered = 0
        needsFullUpload = true
    }

    /** Call from onSurfaceCreated: a new GL context needs a fresh texture. */
    fun init() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        upload.clear()
        upload.put(bytes)
        upload.position(0)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, SIZE, SIZE, 0,
            GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, upload
        )
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        needsFullUpload = false
        minRow = Int.MAX_VALUE
        maxRow = -1
    }

    /** Sends what changed since the last call to the GPU (only the rows that were touched). */
    fun flush() {
        if (textureId == 0) return
        val first: Int
        val last: Int
        if (needsFullUpload) {
            first = 0
            last = SIZE - 1
        } else if (maxRow >= 0) {
            first = minRow
            last = maxRow
        } else {
            return
        }
        upload.clear()
        upload.put(bytes, first * SIZE, (last - first + 1) * SIZE)
        upload.position(0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexSubImage2D(
            GLES30.GL_TEXTURE_2D, 0, 0, first, SIZE, last - first + 1,
            GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, upload
        )
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        needsFullUpload = false
        minRow = Int.MAX_VALUE
        maxRow = -1
    }

    /** Binds the mask to its texture unit ([UNIT]). */
    fun bind() {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + UNIT)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    /** The GL context was recreated: the old texture is gone, the bytes are rebuilt by the caller. */
    fun invalidateForContextLoss() {
        textureId = 0
        clear()
    }

    private fun index(cx: Int, cz: Int): Int = ((cz and MASK) shl SHIFT) or (cx and MASK)

    companion object {
        const val SHIFT = 8
        const val SIZE = 1 shl SHIFT
        private const val MASK = SIZE - 1

        /** Texture unit of the mask (0 = block atlas, 1 = water tile, 2 = far-terrain noise). */
        const val UNIT = 3
    }
}
