package com.voxelsandbox.game.gl

/**
 * The GLSL programs of everything that is not voxel-block geometry (that one has its own file, [VoxelShader]:
 * it is the only part that draws with the per-block texture lookup).
 *
 * Camera-relative positions. Vertex data holds world coordinates, but a float32 world coordinate
 * has only so many bits: at x = 20,000 the smallest step is 0.002 of a block, and the sums inside
 * `projection * view * position` (a translation of tens of thousands cancelling against the position)
 * lose even more, so far from the origin walls shimmer and the ground crawls. Every vertex shader
 * therefore subtracts `uCamOrigin`, the whole-block position of the eye (exact in float32), before
 * the matrix, and the matrix is built for an eye that is within one block of the origin. Everything
 * the vertex shader hands on that must stay a *world* position (the distance bands and clips, the
 * world-anchored grain) is still passed on unshifted; the rest are exact and tiny.
 *
 *  - [FAR_VERTEX]/[FAR_FRAGMENT]: the distant-terrain tiles: a circular clip around the
 *    player, a distance band per level of detail, and (close to the voxel area) the same
 *    per-block brightness grain the voxel shader applies, so flat LOD colour does not look
 *    like a different material next to textured blocks.
 *  - [WATER_VERTEX]/[WATER_FRAGMENT]: every water surface (voxel chunks and distant water).
 *    Pixel-art water: a small tiling tile sampled with nearest-texel filtering, scrolled by
 *    time and by the flow direction carried in the vertices. No lighting model at all: just
 *    tile colours, a depth tint, shoreline foam and fog.
 *  - [SKY_VERTEX]/[SKY_FRAGMENT]: a full-screen gradient with a sun, drawn first.
 *  - [CLOUD_VERTEX]/[CLOUD_FRAGMENT]: the blocky cloud layer.
 */
object Shaders {
    /** Blocks over which the distant ground's tonal patches grow from nothing (at the edge of the voxel terrain) to
     *  full strength, and that strength (see [FAR_FRAGMENT]). */
    private const val TONE_RAMP = 220.0f
    private const val TONE_STRENGTH = 0.20f

    /** uCenter: world X/Z the ring radii are measured from (the player).
     *  uBand: x = inner radius, y = outer radius of this level's ring (used by the fragment
     *  shader), z..w = the distance range over which the columns of this level slide to the
     *  heights of the next coarser level (aMorph, the height of the parent column).
     *
     *  The slide is a pure function of the vertex's distance from the player, so the mesh
     *  itself is static and cached; at w (the ring's outer edge) every vertex has reached its
     *  parent's height, which is exactly where the coarser level takes over. It replaces the
     *  old arrangement where the coarse level overlapped the fine one and was sunk by a
     *  distance-dependent amount, which made the ground heave as the player walked. */
    const val FAR_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;
layout(location = 3) in float aMorph;

uniform mat4 uViewProj;
uniform highp vec3 uCamOrigin;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;

out vec2 vTexCoord;
out float vShade;
out float vFogDist;
out highp vec3 vWorld;

void main() {
    highp float dist = length(aPosition.xz - uCenter);
    highp float m = smoothstep(uBand.z, uBand.w, dist);
    vec3 p = vec3(aPosition.x, mix(aPosition.y, aMorph, m), aPosition.z);
    gl_Position = uViewProj * vec4(p - uCamOrigin, 1.0);
    vTexCoord = aTexCoord;
    vShade = aShade;
    vFogDist = gl_Position.w;
    vWorld = p;
}
"""

    /** Where the distant ground is drawn:
     *   - uBand.xy = inner / outer radius (from uCenter, the eye) of this level's ring (see FAR_VERTEX),
     *     and uSkip = a ring of it that another level draws instead (x = y = 0: none). All the edges are
     *     cut with the same formula on the same world position, so neighbouring levels partition the
     *     ground exactly;
     *   - uVoxel.x = the radius inside which the voxel terrain stands alone: there the distant ground
     *     is drawn only in the chunk columns that have no terrain yet (uCover: one texel per column,
     *     see CoverageMask), so a chunk that is still loading, or was just unloaded, shows distant
     *     ground instead of a hole, and a loaded one never has a second surface under it. From that
     *     radius out, where the voxel terrain dissolves, the distant ground is always drawn behind it;
     *     uVoxel.y = the radius where the voxel terrain is gone.
     *
     *  Two kinds of variation are added to the flat palette colours, both functions of the world
     *  position alone (so they stay fixed to the ground and are identical at every level):
     *   - a grain: exactly the per-block brightness variation of the voxel terrain (same range, same
     *     fade, see [BlockGrain]), from a hash of the ground cell (2-D, offset by 0.37 so that vertical
     *     walls, which sit exactly on cell boundaries, are not decided by the last bit of an
     *     interpolated coordinate), so the two layers are equally grainy where they overlap;
     *   - soft tonal patches from a tileable noise texture (uNoise, one repeat = 1024 blocks;
     *     two taps at different scales and axes so the repeat never shows): far columns are flat
     *     palette colours and this is what breaks them up. The voxel terrain has no such patches, so
     *     they are zero at the edge of the voxel terrain and grow to full strength over [TONE_RAMP]
     *     blocks beyond it, measured from the eye (not along the view axis, so turning the camera never
     *     changes them). Before, they started 40 blocks from the eye and the distant ground next to the
     *     voxel terrain was up to 12 % darker or lighter than it, a ring all the way round.
     *  The hash is done on highp integers on purpose: mediump ints are 16 bit on some GPUs. */
    @JvmField
    val FAR_FRAGMENT: String = """#version 300 es
precision mediump float;
precision highp int;

#define GRAIN_NEAR ${BlockGrain.NEAR}
#define GRAIN_FAR ${BlockGrain.FAR}
#define GRAIN_RANGE ${BlockGrain.SOLID_RANGE}
#define TONE_RAMP $TONE_RAMP
#define TONE_STRENGTH $TONE_STRENGTH

in highp vec2 vTexCoord;
in float vShade;
in float vFogDist;
in highp vec3 vWorld;

uniform sampler2D uTexture;
uniform sampler2D uNoise;
uniform sampler2D uCover;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec2 uVoxel;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;
uniform highp vec2 uSkip;

out vec4 fragColor;

void main() {
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 >= uBand.y * uBand.y) discard;
    if (d2 >= uSkip.x * uSkip.x && d2 < uSkip.y * uSkip.y) discard;
    if (d2 < uVoxel.x * uVoxel.x &&
        texelFetch(uCover, ivec2(floor(vWorld.xz * 0.0625)) & 255, 0).r > 0.5) discard;

    vec3 shaded = texture(uTexture, vTexCoord).rgb * vShade;
    if (vFogDist < GRAIN_FAR) {
        highp vec2 q = floor(vWorld.xz + vec2(0.37));
        uvec2 u = uvec2(ivec2(q));
        uint h = (u.x * 73856093u) ^ (u.y * 19349663u);
        h ^= h >> 15u;
        h *= 739982445u;
        h ^= h >> 13u;
        float g = float((h >> 8u) & 255u) * (1.0 / 255.0);
        shaded *= 1.0 - GRAIN_RANGE * g * (1.0 - smoothstep(GRAIN_NEAR, GRAIN_FAR, vFogDist));
    }
    float n1 = texture(uNoise, vWorld.xz * 0.0009765625).r;
    float n2 = texture(uNoise, vWorld.zx * 0.0006105 + vec2(0.37, 0.61)).r;
    float tone = (n1 + n2) - 1.0;
    float k = smoothstep(uVoxel.y, uVoxel.y + TONE_RAMP, sqrt(d2)) * TONE_STRENGTH;
    shaded *= vec3(1.0 + tone * k * 1.15, 1.0 + tone * k, 1.0 + tone * k * 0.8);
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /**
     * Water vertex data (see ChunkMesher): position, then in the "uv" slots (x = depth of the
     * water below the vertex in blocks, or -1 for a side face; y = flow X) and in the shade
     * slot the flow Z. Flow is a vector of length 0..1 pointing the way the water runs.
     * There is no vertex swell any more: water is flat and animated by its texture only, like
     * the rest of the blocky world.
     */
    const val WATER_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aData;
layout(location = 2) in float aFlowZ;

uniform mat4 uViewProj;
uniform highp vec3 uCamOrigin;

out highp vec3 vWorld;
out highp vec3 vRel;
out float vDepth;
out vec2 vFlow;
out float vFogDist;

void main() {
    vRel = aPosition - uCamOrigin;
    gl_Position = uViewProj * vec4(vRel, 1.0);
    vWorld = aPosition;
    vDepth = aData.x;
    vFlow = vec2(aData.y, aFlowZ);
    vFogDist = gl_Position.w;
}
"""

    /** uBand / uSkip / uCover: same meaning as in FAR_FRAGMENT (the voxel water passes a band that spans
     *  everything). uSide says which of the two water layers is being drawn: +1 = the voxel chunks' water,
     *  -1 = the distant water, 0 = no seam. They meet at uVoxel.y, the radius (from the eye) where the
     *  voxel terrain is fully dissolved, over a seam SEAM_WIDTH (8) blocks wide: the voxel water fades out
     *  across it as the distant water fades in, in the proportions that keep the combined opacity what a
     *  single layer would have (so there is no lighter ring), and where a column has no voxel terrain the
     *  distant water is drawn whole. uWaterTex: the 16x16 pixel-art water tile (see WaterTexture),
     *  one repeat per block, drifting slowly (or with the flow). One texture fetch per pixel and
     *  no per-pixel trigonometry: water covers a large part of the screen over an ocean, and it
     *  is the one translucent layer, so it has to be cheap on weak GPUs.
     *
     *  The pattern is the same at every distance: the tile's own mip chain averages it away where
     *  it gets smaller than a pixel, and past 260 blocks nothing but the average colour is left.
     *  (Far away the fetch only ever touches the smallest mip levels, which cost next to
     *  nothing.) */
    const val WATER_FRAGMENT = """#version 300 es
precision mediump float;

#define SEAM_WIDTH 8.0

in highp vec3 vWorld;
in highp vec3 vRel;
in float vDepth;
in vec2 vFlow;
in float vFogDist;

uniform sampler2D uWaterTex;
uniform sampler2D uCover;
uniform highp float uTime;
uniform highp vec3 uEyeRel;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
uniform highp vec2 uVoxel;
uniform highp float uSide;
uniform highp vec2 uCenter;
uniform highp vec4 uBand;
uniform highp vec2 uSkip;

out vec4 fragColor;

void main() {
    highp vec2 db = vWorld.xz - uCenter;
    highp float d2 = dot(db, db);
    if (d2 < uBand.x * uBand.x || d2 >= uBand.y * uBand.y) discard;
    if (d2 >= uSkip.x * uSkip.x && d2 < uSkip.y * uSkip.y) discard;
    // The seam between the voxel water and the distant water: 0 inside, 1 beyond.
    highp float seam = clamp((sqrt(d2) - (uVoxel.y - SEAM_WIDTH)) * (1.0 / SEAM_WIDTH), 0.0, 1.0);
    bool columnLoaded = false;
    if (uSide < 0.0 && seam < 1.0) {
        columnLoaded = texelFetch(uCover, ivec2(floor(vWorld.xz * 0.0625)) & 255, 0).r > 0.5;
        if (columnLoaded && seam <= 0.0) discard;
    }

    // Tops are textured in world X/Z; side faces (depth marker -1) in (x + z, y) so a waterfall
    // gets tall streaks that run down the face.
    // (In camera-relative coordinates: the tile repeats once per block and the origin is a whole
    // number of blocks, so the pattern is the same as in world coordinates, with all the precision.)
    float side = step(vDepth, -0.5);
    highp vec2 p = mix(vRel.xz, vec2(vRel.x + vRel.z, vRel.y), side);
    // Running water carries the pattern along its flow; still water drifts very slowly. (All
    // rates are multiples of 1/1000 tile per second, so the drift wraps cleanly with uTime.)
    highp vec2 vel = mix(vFlow * 0.9 + vec2(0.037, 0.021), vec2(0.0, -0.9), side);
    highp vec2 uv = p - vel * uTime;

    // The tile's average colour; the pattern fades into it between 150 and 260 blocks, which is
    // where the mip chain has already averaged it away.
    float near = 1.0 - smoothstep(150.0, 260.0, vFogDist);
    vec3 col = mix(vec3(0.28, 0.50, 0.85), texture(uWaterTex, uv).rgb, near);

    // Depth tint: bright azure in the shallows, deep blue over deep water (saturates at 8
    // blocks, which is what lets the mesher merge flat deep water into big quads).
    float depthK = sqrt(clamp(max(vDepth, 0.0) / 8.0, 0.0, 1.0));
    col *= mix(vec3(1.10, 1.12, 1.0), vec3(0.62, 0.76, 0.94), depthK);
    col = mix(col, vec3(0.88, 0.95, 1.0), side * 0.12);

    // At grazing angles the surface mirrors the sky: tint towards the horizon colour and get
    // more opaque. Cheap (no pow) and it also calms the far ocean.
    highp vec3 toEye = uEyeRel - vRel;
    float cosT = abs(toEye.y) * inversesqrt(dot(toEye, toEye) + 0.0001);
    float f = 1.0 - cosT;
    f *= f;
    float fres = f * f * (1.0 - side);
    col = mix(col, uFogColor, fres * 0.45);

    // Opacity follows the length of the light path through the water: straight down over a
    // shallow shore you still see the sand, but a slanted view through even two or three
    // blocks of water is nearly opaque (so seabed steps never show as dark lines). Beyond
    // 300 blocks the sea is completely solid: whatever lies under it there is not drawn (or is
    // not meant to be seen), and a surface that is only 97 % opaque lets 3 % of every seam,
    // crack and stray triangle behind it through, which over a whole ocean is visible.
    float path = max(vDepth, 0.0) / max(cosT, 0.25);
    float alpha = 0.97 - 0.39 * exp(-0.55 * path);
    alpha = mix(alpha, 1.0, smoothstep(60.0, 300.0, vFogDist));
    alpha = mix(alpha, 0.80, side);
    alpha = clamp(alpha + fres * 0.15, 0.0, 1.0);
    if (uSide > 0.0) {
        alpha *= 1.0 - seam;
        if (alpha < 0.004) discard;
    } else if (columnLoaded) {
        // Fades in as the voxel layer above it (same surface) fades out, keeping the sum.
        alpha = 1.0 - (1.0 - alpha) / (1.0 - alpha * (1.0 - seam));
    }

    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(col, uFogColor, fogFactor), alpha);
}
"""

    /** The cloud mesh (see CloudRenderer): one tile of blocky clouds, drawn 3 x 3 times with
     *  instancing. aPos is tile-local; uOrigin is the X/Z of the first instance's tile and uBaseY the
     *  height of the cloud base, both relative to the camera origin (see the note at the top), so
     *  everything here, including uEye in the fragment shader, is camera-relative. */
    const val CLOUD_VERTEX = """#version 300 es
layout(location = 0) in vec3 aPos;
layout(location = 1) in float aShade;

uniform mat4 uViewProj;
uniform highp vec2 uOrigin;
uniform highp float uTile;
uniform highp float uBaseY;

out highp vec3 vWorld;
out float vShade;

void main() {
    float fx = float(gl_InstanceID % 3);
    float fz = float(gl_InstanceID / 3);
    highp vec3 p = vec3(uOrigin.x + fx * uTile + aPos.x, uBaseY + aPos.y, uOrigin.y + fz * uTile + aPos.z);
    vWorld = p;
    vShade = aShade;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    /** Clouds: baked per-vertex shade turned into a white-to-blue-grey colour, then dissolved
     *  into the sky gradient with distance (so no alpha blending and no visible far edge).
     *  uBand restricts which 3D distances from the eye are drawn: the far pass draws the far
     *  part of the sky, the voxel pass the near part (the two use different depth ranges). */
    const val CLOUD_FRAGMENT = """#version 300 es
precision highp float;

in highp vec3 vWorld;
in float vShade;

uniform highp vec3 uEye;
uniform highp float uRadius;
uniform highp vec2 uBand;
uniform vec3 uHorizon;
uniform vec3 uZenith;

out vec4 fragColor;

void main() {
    vec3 d = vWorld - uEye;
    float dist = length(d);
    if (dist < uBand.x || dist >= uBand.y || dist >= uRadius) discard;

    // Lit white on top and towards the sun, a cool blue-grey underneath and away from it.
    vec3 col = mix(vec3(0.50, 0.58, 0.74), vec3(1.0), clamp(vShade, 0.0, 1.0));

    // Distant clouds dissolve into the sky itself (the same gradient the sky pass draws), so
    // the edge of the cloud field is invisible without any alpha blending.
    float h = clamp(d.y / max(dist, 0.001), 0.0, 1.0);
    vec3 sky = mix(uHorizon, uZenith, sqrt(h));
    col = mix(col, sky, smoothstep(0.42 * uRadius, uRadius, dist));
    fragColor = vec4(col, 1.0);
}
"""

    /** One oversized triangle covering the screen; no vertex buffer needed. */
    const val SKY_VERTEX = """#version 300 es
out vec2 vNdc;

void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vNdc = corner * 2.0 - 1.0;
    gl_Position = vec4(vNdc, 1.0, 1.0);
}
"""

    /** uForward/uRight/uUp: the camera basis; uTan.x = tan(fovY / 2) * aspect, uTan.y = tan(fovY / 2).
     *  The sun terms only matter near the sun, so every other pixel skips their pow() calls
     *  (at 0.6 the skipped part of the glow is below 0.001, so there is no visible edge). */
    const val SKY_FRAGMENT = """#version 300 es
precision highp float;

in vec2 vNdc;

uniform vec3 uForward;
uniform vec3 uRight;
uniform vec3 uUp;
uniform vec2 uTan;
uniform vec3 uHorizon;
uniform vec3 uZenith;
uniform vec3 uSunDir;

out vec4 fragColor;

void main() {
    vec3 dir = normalize(uForward + uRight * (vNdc.x * uTan.x) + uUp * (vNdc.y * uTan.y));
    float h = clamp(dir.y, 0.0, 1.0);
    vec3 col = mix(uHorizon, uZenith, sqrt(h));
    float sd = dot(dir, uSunDir);
    if (sd > 0.6) {
        col += vec3(1.0, 0.90, 0.68) * (pow(sd, 1500.0) * 2.0 + pow(sd, 10.0) * 0.14);
    }
    fragColor = vec4(col, 1.0);
}
"""
}
