package com.voxelsandbox.game.world.streaming

import java.util.concurrent.locks.ReentrantLock

/**
 * A blocking min-priority queue whose waiting entries can be re-ranked.
 *
 * Why not java.util.concurrent.PriorityBlockingQueue: a chunk's priority depends on where the
 * player is and which way they are heading, and both change constantly while exploring. A
 * PriorityBlockingQueue fixes the order at insertion time, so after a few seconds of flight the
 * queue is ordered by where the player *was*: chunks now behind them still come first while the
 * ground in front waits. This queue can be re-ranked in one pass ([reprioritize]), merges a new
 * job into a waiting one with the same key ([submit]), and lets a job be pulled forward or
 * cancelled by key ([improve], [remove]).
 *
 * Ties are broken first-come-first-served. All operations take one short lock; the work done
 * under it is a few heap steps, so contention is negligible at the job rates involved (hundreds
 * per second).
 */
class JobQueue<J : JobQueue.Job> {
    abstract class Job {
        /** Smaller runs sooner. Change it only through the queue. */
        @JvmField var priority: Long = 0L

        internal var slot: Int = -1
        internal var seq: Long = 0L

        /** Identifies the work: two jobs with the same key are the same piece of work. */
        abstract val key: Long
    }

    private val lock = ReentrantLock()
    private val notEmpty = lock.newCondition()
    private var heap = arrayOfNulls<Job>(256)
    private var count = 0
    private var nextSeq = 0L
    private val byKey = HashMap<Long, J>()

    val size: Int
        get() {
            lock.lock()
            try {
                return count
            } finally {
                lock.unlock()
            }
        }

    /**
     * Adds [job]. If a job with the same key is already waiting, [merge] folds the new one into
     * it (typically OR-ing masks and keeping the smaller priority) and nothing is added; without
     * a [merge] the waiting job simply keeps the better of the two priorities.
     * Returns true when [job] itself was queued.
     */
    fun submit(job: J, merge: ((existing: J, incoming: J) -> Unit)? = null): Boolean {
        lock.lock()
        try {
            val existing = byKey[job.key]
            if (existing != null) {
                val before = existing.priority
                if (merge != null) merge(existing, job) else if (job.priority < existing.priority) existing.priority = job.priority
                if (existing.priority < before) siftUp(existing.slot) else if (existing.priority > before) siftDown(existing.slot)
                return false
            }
            job.seq = nextSeq++
            if (count == heap.size) heap = heap.copyOf(count * 2)
            heap[count] = job
            job.slot = count
            count++
            byKey[job.key] = job
            siftUp(job.slot)
            notEmpty.signal()
            return true
        } finally {
            lock.unlock()
        }
    }

    /** Blocks until a job is available and removes the most urgent one. */
    @Throws(InterruptedException::class)
    fun take(): J {
        lock.lockInterruptibly()
        try {
            while (count == 0) notEmpty.await()
            return removeAt(0)
        } finally {
            lock.unlock()
        }
    }

    fun poll(): J? {
        lock.lock()
        try {
            return if (count == 0) null else removeAt(0)
        } finally {
            lock.unlock()
        }
    }

    /** Removes the waiting job with this key, if any (a job that is already running is not here). */
    fun remove(key: Long): J? {
        lock.lock()
        try {
            val job = byKey[key] ?: return null
            return removeAt(job.slot)
        } finally {
            lock.unlock()
        }
    }

    /** True if a job with this key is waiting. */
    fun contains(key: Long): Boolean {
        lock.lock()
        try {
            return byKey.containsKey(key)
        } finally {
            lock.unlock()
        }
    }

    /** Pulls the waiting job with this key forward to at most [priority]. */
    fun improve(key: Long, priority: Long) {
        lock.lock()
        try {
            val job = byKey[key] ?: return
            if (priority < job.priority) {
                job.priority = priority
                siftUp(job.slot)
            }
        } finally {
            lock.unlock()
        }
    }

    /** Recomputes every waiting job's priority with [rank] and restores the order, in one pass. */
    fun reprioritize(rank: (J) -> Long) {
        lock.lock()
        try {
            @Suppress("UNCHECKED_CAST")
            for (i in 0 until count) {
                val job = heap[i] as J
                job.priority = rank(job)
            }
            for (i in count / 2 - 1 downTo 0) siftDown(i)
        } finally {
            lock.unlock()
        }
    }

    /** Number of waiting jobs matching [predicate] (for statistics). */
    fun countWhere(predicate: (J) -> Boolean): Int {
        lock.lock()
        try {
            var n = 0
            @Suppress("UNCHECKED_CAST")
            for (i in 0 until count) if (predicate(heap[i] as J)) n++
            return n
        } finally {
            lock.unlock()
        }
    }

    /** Calls [action] for every waiting job (under the lock: keep it short). */
    fun forEachWaiting(action: (J) -> Unit) {
        lock.lock()
        try {
            @Suppress("UNCHECKED_CAST")
            for (i in 0 until count) action(heap[i] as J)
        } finally {
            lock.unlock()
        }
    }

    fun clear() {
        lock.lock()
        try {
            for (i in 0 until count) {
                heap[i]?.slot = -1
                heap[i] = null
            }
            count = 0
            byKey.clear()
        } finally {
            lock.unlock()
        }
    }

    // ---- heap internals (lock held) ----

    private fun less(a: Job, b: Job): Boolean =
        if (a.priority != b.priority) a.priority < b.priority else a.seq < b.seq

    @Suppress("UNCHECKED_CAST")
    private fun removeAt(index: Int): J {
        val job = heap[index] as J
        val last = count - 1
        count = last
        if (index != last) {
            val moved = heap[last]!!
            heap[index] = moved
            moved.slot = index
            heap[last] = null
            siftDown(index)
            siftUp(moved.slot)
        } else {
            heap[last] = null
        }
        byKey.remove(job.key)
        job.slot = -1
        return job
    }

    private fun siftUp(start: Int) {
        var i = start
        val job = heap[i]!!
        while (i > 0) {
            val parent = (i - 1) ushr 1
            val p = heap[parent]!!
            if (!less(job, p)) break
            heap[i] = p
            p.slot = i
            i = parent
        }
        heap[i] = job
        job.slot = i
    }

    private fun siftDown(start: Int) {
        var i = start
        val job = heap[i]!!
        val half = count ushr 1
        while (i < half) {
            var child = 2 * i + 1
            var c = heap[child]!!
            val right = child + 1
            if (right < count && less(heap[right]!!, c)) {
                child = right
                c = heap[child]!!
            }
            if (!less(c, job)) break
            heap[i] = c
            c.slot = i
            i = child
        }
        heap[i] = job
        job.slot = i
    }
}
