package com.voxelsandbox.game.gl

import com.voxelsandbox.game.world.streaming.ColumnKeys
import com.voxelsandbox.game.world.streaming.DirectBufferPool
import com.voxelsandbox.game.world.streaming.PackedRegion
import com.voxelsandbox.game.world.streaming.ReadyRegions
import com.voxelsandbox.game.world.streaming.RegionUploadScheduler
import com.voxelsandbox.game.world.streaming.RegionVersions

/**
 * The GPU side of the voxel terrain: one buffer per REGION of columns (one draw call for up to
 * sixteen columns), plus the set of columns that are actually on screen.
 *
 * The data arrives already packed (see RegionPacker): the streaming threads do the concatenating
 * and index shifting, so what is left for the GL thread is one glBufferData per buffer. How much of
 * that to do in one frame is the caller's budget; regions are taken in order of how soon they are
 * needed (see [drain]).
 *
 * GL thread only, like everything that owns GL objects.
 */
class RegionGpuStore(
    /** Mirrors the covered columns for the shaders and for allocation-free coverage scans. */
    val coverage: CoverageMask = CoverageMask()
) {
    /** Opaque / cut-out / double-sided terrain of each region that has any, by region key. */
    val solid = HashMap<Long, ChunkGpuMesh>()

    /** The translucent water layer of each region that has any. */
    val water = HashMap<Long, ChunkGpuMesh>()

    /** Columns (packed, see [ColumnKeys.column]) whose terrain is on the GPU, including columns
     *  that have nothing to draw (open ocean): "accounted for", which is what the fog coverage
     *  scan needs. */
    private val covered = HashSet<Long>()

    private val scheduler = RegionUploadScheduler()

    /** Which snapshot of each region is on the GPU: a pack that was overtaken on its way is dropped. */
    private val versions = RegionVersions()

    /** Packs dropped because a newer one of their region had already been uploaded (statistics). */
    val stalePacksDropped: Long get() = versions.rejected

    /** Bytes and regions handed to the driver by the last [drain] (for the stats overlay). */
    val lastBytes: Int get() = scheduler.lastBytes
    val lastRegions: Int get() = scheduler.lastRegions

    fun isColumnCovered(column: Long): Boolean = covered.contains(column)

    fun forgetColumn(column: Long) {
        if (covered.remove(column)) coverage.set(ColumnKeys.columnX(column), ColumnKeys.columnZ(column), false)
    }

    /** The GL context was lost: every handle is meaningless, so drop them without deleting. */
    fun invalidateForContextLoss() {
        for (m in solid.values) m.invalidateForContextLoss()
        for (m in water.values) m.invalidateForContextLoss()
        solid.clear()
        water.clear()
        covered.clear()
        versions.clear()
        coverage.invalidateForContextLoss()
    }

    /**
     * Uploads packed regions from [ready] within this frame's budget, in the order
     * [RegionUploadScheduler] picks (edits first, then the ones needed soonest).
     * Returns the number of regions uploaded.
     */
    fun drain(
        ready: ReadyRegions,
        pool: DirectBufferPool,
        eyeX: Float,
        eyeZ: Float,
        lookX: Float,
        lookZ: Float,
        byteBudget: Int,
        nanoBudget: Long,
        startNs: Long
    ): Int = scheduler.drain(
        ready, { solid.containsKey(it) }, eyeX, eyeZ, lookX, lookZ, byteBudget, nanoBudget, startNs
    ) { apply(it, pool) }

    private fun apply(pack: PackedRegion, pool: DirectBufferPool) {
        val key = pack.key
        // Two packs of one region can finish in either order; the GPU only ever moves forward.
        if (!versions.admit(key, pack.sequence)) {
            pack.recycle(pool)
            return
        }
        val rx = ColumnKeys.regionX(key)
        val rz = ColumnKeys.regionZ(key)
        // The region's columns are replaced as a whole: those the new pack does not list are gone. (The
        // mask is only read by the draw calls of a later frame, so the two steps are never seen apart.)
        for (dz in 0 until ColumnKeys.REGION_SIZE) {
            for (dx in 0 until ColumnKeys.REGION_SIZE) {
                val cx = rx * ColumnKeys.REGION_SIZE + dx
                val cz = rz * ColumnKeys.REGION_SIZE + dz
                covered.remove(ColumnKeys.column(cx, cz))
                coverage.set(cx, cz, false)
            }
        }
        for (c in pack.columns) {
            covered.add(c)
            coverage.set(ColumnKeys.columnX(c), ColumnKeys.columnZ(c), true)
        }

        val s = pack.solid
        if (s != null) solid.getOrPut(key) { ChunkGpuMesh() }.uploadPacked(s) else solid.remove(key)?.dispose()
        val w = pack.water
        if (w != null) water.getOrPut(key) { ChunkGpuMesh() }.uploadPacked(w) else water.remove(key)?.dispose()

        pack.recycle(pool)
    }
}
