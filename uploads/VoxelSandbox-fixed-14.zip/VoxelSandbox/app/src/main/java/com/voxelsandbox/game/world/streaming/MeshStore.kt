package com.voxelsandbox.game.world.streaming

import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.ConcurrentHashMap

/**
 * The latest finished mesh of every sub-chunk of one chunk column: one slot per sub-chunk for
 * the opaque/cut-out terrain and one for the translucent water layer (null = nothing to draw
 * there). Immutable once published: an update builds a new [ColumnMesh], so a packing thread
 * reading one never sees a half-written column.
 */
class ColumnMesh(
    @JvmField val solid: Array<MeshData?>,
    @JvmField val water: Array<MeshData?>
)

/**
 * Thread-safe home of the CPU-side meshes of all loaded columns. Mesh workers write it, the
 * region packers read it, and it is what lets a region be rebuilt when one of its sixteen
 * columns changes without re-meshing the other fifteen (and what survives a lost GL context:
 * the CPU data is all still here, only the GPU copies are gone).
 *
 * A column is present from the moment its first mesh job finishes, even when it has nothing to
 * draw (a deep-sea column has no solid geometry at all): "present" is what the renderer uses
 * to know the column is accounted for, so an empty column is not mistaken for a hole.
 */
class MeshStore {
    private val columns = ConcurrentHashMap<Long, ColumnMesh>()

    fun get(columnKey: Long): ColumnMesh? = columns[columnKey]

    val size: Int get() = columns.size

    /**
     * Replaces the slots selected by [mask] (bit i = sub-chunk i) with [solid] / [water] and
     * leaves the others as they were. Calls for one column must not overlap (the scheduler
     * guarantees it: a column is never meshed by two workers at once).
     */
    fun update(columnKey: Long, mask: Int, solid: Array<MeshData?>, water: Array<MeshData?>) {
        val old = columns[columnKey]
        val newSolid = old?.solid?.copyOf() ?: arrayOfNulls<MeshData>(WorldConfig.SUBCHUNKS_PER_CHUNK)
        val newWater = old?.water?.copyOf() ?: arrayOfNulls<MeshData>(WorldConfig.SUBCHUNKS_PER_CHUNK)
        for (s in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
            if (mask and (1 shl s) == 0) continue
            newSolid[s] = solid[s]
            newWater[s] = water[s]
        }
        columns[columnKey] = ColumnMesh(newSolid, newWater)
    }

    fun remove(columnKey: Long) {
        columns.remove(columnKey)
    }

    fun clear() {
        columns.clear()
    }

    /** Every region that currently has at least one column (used to repack all of them). */
    fun regionKeys(): LongArray {
        val set = HashSet<Long>()
        for (k in columns.keys) set.add(ColumnKeys.regionOfColumn(k))
        val out = LongArray(set.size)
        var i = 0
        for (k in set) out[i++] = k
        return out
    }
}
