package com.voxelsandbox.game.gl

import kotlin.math.max
import kotlin.math.min

/**
 * Where the voxel terrain hands over to the distant terrain, and how far the fog reaches: the numbers
 * the renderer needs every frame, worked out from plain inputs (no GL, no threads, so the behaviour can
 * be tested on its own).
 *
 * The one rule behind all of it: **nothing a viewer can see may jump.** Every output is either a smooth
 * function of the eye position or is rate-limited, because a step of even a few blocks in the dissolve
 * ring, the fog or the clip radius is exactly what shows up as a ring that flashes, terrain that
 * disappears and comes back, or a horizon that breathes. The things that used to jump, and what
 * replaces them:
 *
 *  - The ring was centred on the middle of the player's *chunk*, so it moved 16 blocks sideways each
 *    time a chunk boundary was crossed. It is now centred on the eye (the renderer passes the eye), and
 *    its radius is a rate-limited follower of the nominal edge ([edge]).
 *  - The radius used to be tied to "everything up to the first missing chunk is loaded", which dives
 *    whenever one chunk anywhere is momentarily missing. That figure ([provenRadius]) now only decides
 *    what the CPU may skip (see [clipRadius]); what is drawn is decided per column by the coverage mask.
 *  - The fog used to shrink the instant the distant terrain's coverage dipped, even for a few
 *    milliseconds, and the whole scene seemed to pull in and push out. It now holds still for
 *    [HOLD_SECONDS] and, if the dip lasts, closes in smoothly.
 */
class Handover {
    /** How far the fog may reach (blocks): what is really there, capped by the render distance. */
    var fogCover = INITIAL_FOG
        private set

    /** Radius (blocks, from the eye) where the voxel terrain starts to dissolve, and how wide the
     *  dissolve is. [fadeWidth] is 0 when there is no distant terrain behind the voxel area. */
    var fadeStart = 0f
        private set
    var fadeWidth = 0f
        private set

    /** The radius where the voxel terrain is gone and the distant terrain stands alone. */
    val edge: Float get() = fadeStart + fadeWidth

    /** Radius around the eye inside which every column is known to have its terrain on the GPU, as far
     *  as the CPU can tell (see [update]). Nothing inside it needs the distant terrain. */
    var provenRadius = 0f
        private set

    /** What the CPU may skip drawing of the distant terrain: inside this circle around the eye the
     *  voxel terrain is complete and fully opaque. Never larger than [provenRadius] or [fadeStart]. */
    var clipRadius = 0f
        private set

    /** Where the finest ring of distant terrain is placed: the dissolve start of the *nominal* edge,
     *  which does not move while the voxel area is merely loading. */
    var ringReference = 0f
        private set

    /** Near plane for the distant-terrain depth range (see [update]). */
    var farNearPlane = FAR_NEAR_PLANE_MIN
        private set

    private var dipSeconds = 0f
    private var edgeKnown = false
    private var edgeRadius = 0f
    private var nearPlaneDwell = 0f

    /** Forgets everything (a new world, or the GL context was recreated): the next [update] starts
     *  from the nominal values instead of easing towards them. */
    fun reset() {
        fogCover = INITIAL_FOG
        dipSeconds = 0f
        edgeKnown = false
        nearPlaneDwell = 0f
        farNearPlane = FAR_NEAR_PLANE_MIN
    }

    /**
     * @param dt seconds since the last frame.
     * @param farOn the distant terrain is enabled in the settings.
     * @param farPass it is drawn this frame (not while the camera is under water).
     * @param renderBlocks the render distance in use (the selected one, or less under Automatic Render Distance).
     * @param nominalEdge blocks from the centre of the player's chunk to the edge of the voxel area once
     *   everything wanted is loaded.
     * @param eyeOffset distance (blocks) of the eye from the centre of its chunk, at most about 11.3.
     * @param provenChunks chunks (centre to centre) to the nearest chunk with no terrain on the GPU.
     * @param farCovered how far the distant terrain is complete (blocks); ignored when [farOn] is false.
     * @param detailFactor Automatic Render Distance's share of the voxel radius that is worth drawing
     *   (exactly 1 with the setting off).
     */
    fun update(
        dt: Float,
        farOn: Boolean,
        farPass: Boolean,
        renderBlocks: Float,
        nominalEdge: Float,
        eyeOffset: Float,
        provenChunks: Float,
        farCovered: Float,
        detailFactor: Float
    ) {
        updateFog(dt, farOn, renderBlocks, provenChunks, farCovered)

        // ---- the dissolve ring -----------------------------------------------------------------
        // The distant terrain behind the voxel area can only be trusted to be there when it has been
        // proven to reach past it; only then may Automatic Render Distance pull the ring in.
        val farCoversVoxelArea = farPass && farCovered > nominalEdge + FAR_PROOF_MARGIN
        val detailEdge = if (farCoversVoxelArea) nominalEdge * detailFactor else nominalEdge
        // The ring is centred on the eye, the loaded area on the middle of a chunk: pulling the nominal
        // edge in a little keeps the part of the ring that is not yet fully dissolved inside the loaded
        // area for almost every eye position (a chunk is up to 11 blocks off-centre).
        val targetEdge = max(0f, detailEdge - EDGE_INSET)
        val width = if (farPass) (targetEdge * 0.18f).coerceIn(FADE_MIN, FADE_MAX) else 0f

        if (!edgeKnown) {
            edgeRadius = targetEdge
            edgeKnown = true
        } else {
            val diff = targetEdge - edgeRadius
            val step = EDGE_RATE * dt
            edgeRadius += diff.coerceIn(-step, step)
        }
        fadeWidth = width
        fadeStart = max(0f, edgeRadius - width)
        ringReference = max(0f, targetEdge - width)

        // ---- what is certainly covered, around the eye -----------------------------------------
        // Every chunk closer than the first missing one is there; a point within 0.71 chunks of
        // a chunk centre is inside that chunk's square, and the eye is eyeOffset from the centre.
        provenRadius = max(0f, (provenChunks - PROVEN_INSET_CHUNKS) * CHUNK - eyeOffset)
        clipRadius = if (farPass) min(provenRadius, fadeStart) else provenRadius

        updateNearPlane(dt)
    }

    /** The fog reaches as far as there is something behind it, and moves like a camera would: it grows
     *  smoothly, ignores a dip that does not last, and closes in smoothly when one does. */
    private fun updateFog(dt: Float, farOn: Boolean, renderBlocks: Float, provenChunks: Float, farCovered: Float) {
        val nearBlocks = max(0f, provenChunks - 1.5f) * CHUNK
        val covered = if (farOn) max(nearBlocks, farCovered) else nearBlocks
        // A smaller render distance is a decision, not a dip: it applies at once.
        if (fogCover > renderBlocks) fogCover = renderBlocks
        val target = min(renderBlocks, covered)
        if (target >= fogCover) {
            dipSeconds = 0f
            fogCover += (target - fogCover) * min(1f, dt * FOG_GROW_RATE)
        } else if (target >= fogCover * (1f - DIP_TOLERANCE)) {
            dipSeconds = 0f
        } else {
            dipSeconds += dt
            if (dipSeconds >= HOLD_SECONDS) fogCover += (target - fogCover) * min(1f, dt * FOG_SHRINK_RATE)
        }
    }

    /** A nearer plane for the distant terrain when a hole near the player has to be filled, a farther one
     *  (more depth precision at a distance) when not. It comes in at once and goes back out only after
     *  it has been needed that far for a second, so the depth values of the distant terrain do not
     *  change from frame to frame. */
    private fun updateNearPlane(dt: Float) {
        val raw = max(FAR_NEAR_PLANE_MIN, (clipRadius - FAR_NEAR_INSET) * FAR_NEAR_FACTOR)
        if (raw <= farNearPlane) {
            farNearPlane = raw
            nearPlaneDwell = 0f
        } else if (raw > farNearPlane * 1.25f) {
            nearPlaneDwell += dt
            if (nearPlaneDwell >= NEAR_PLANE_DWELL) {
                farNearPlane = raw
                nearPlaneDwell = 0f
            }
        } else {
            nearPlaneDwell = 0f
        }
    }

    companion object {
        const val CHUNK = 16f

        const val INITIAL_FOG = 40f

        /** The fog ignores a dip in coverage that is smaller than this share... */
        private const val DIP_TOLERANCE = 0.02f

        /** ...and one that is gone again within this many seconds. */
        const val HOLD_SECONDS = 0.35f

        private const val FOG_GROW_RATE = 3f
        private const val FOG_SHRINK_RATE = 5f

        /** Width (blocks) of the voxel-to-distant-terrain dissolve: a fraction of the voxel radius, kept
         *  between these limits. It must exceed the gap between the proven coverage and the nominal edge
         *  (about one chunk) so the dissolve starts inside the covered area. */
        const val FADE_MIN = 28f
        const val FADE_MAX = 44f

        /** The dissolve ends this far inside the nominal edge (see [update]). */
        const val EDGE_INSET = 12f

        /** Most the ring's radius moves per second, in either direction. */
        const val EDGE_RATE = 120f

        /** The distant terrain must reach this far past the voxel area before Automatic Render Distance
         *  may pull the ring in. */
        private const val FAR_PROOF_MARGIN = 64f

        /** A point is inside the square of the nearest chunk centre, which is at most 0.71 chunks away. */
        const val PROVEN_INSET_CHUNKS = 0.75f

        /** Smallest near plane of the distant-terrain pass. The sea surface sits only an eighth of a
         *  block above the shallow ground under it, and depth precision at distance d is roughly
         *  d^2 / (near * 2^24): with a near plane of half a block that is already a whole block at
         *  3000 blocks, so the water and the ground fought for every pixel. With 12 it stays under 0.05. */
        const val FAR_NEAR_PLANE_MIN = 12f

        /** Safe near plane for ground at least `clipRadius` away: a visible fragment is at least
         *  cos(~64 degrees) ~ 0.43 of its distance away along the view axis, and at least
         *  `clipRadius - 11` blocks from the eye, hence 0.4 of that. */
        private const val FAR_NEAR_FACTOR = 0.4f
        private const val FAR_NEAR_INSET = 20f
        private const val NEAR_PLANE_DWELL = 1f
    }
}
