package com.voxelsandbox.game.world.generation

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Deterministic seeded 2D simplex noise (the classic, widely-known lattice-skewing
 * scheme: a generic decades-old algorithm with no relation to any specific game).
 * Simplex noise has no visible axis-aligned grain, which matters a lot for terrain:
 * ridges, coastlines and rivers built on it do not line up with the block grid.
 *
 * Everything the world looks like is derived from this plus the seed, so the same seed
 * always reproduces the same world.
 */
class NoiseGenerator(seed: Long) {
    private val perm = IntArray(512)

    init {
        val p = IntArray(256) { it }
        val rnd = Random(seed)
        for (i in 255 downTo 1) {
            val j = rnd.nextInt(i + 1)
            val tmp = p[i]; p[i] = p[j]; p[j] = tmp
        }
        for (i in 0 until 512) perm[i] = p[i and 255]
    }

    /** Single octave of simplex noise, normalised to roughly [-1, 1]. */
    fun noise2D(x: Double, y: Double): Double {
        val s = (x + y) * F2
        val i = fastFloor(x + s)
        val j = fastFloor(y + s)
        val t = (i + j) * G2
        val x0 = x - (i - t)
        val y0 = y - (j - t)
        val i1 = if (x0 > y0) 1 else 0
        val j1 = 1 - i1
        val x1 = x0 - i1 + G2
        val y1 = y0 - j1 + G2
        val x2 = x0 - 1.0 + 2.0 * G2
        val y2 = y0 - 1.0 + 2.0 * G2
        val ii = i and 255
        val jj = j and 255
        val g0 = perm[ii + perm[jj]] and 15
        val g1 = perm[ii + i1 + perm[jj + j1]] and 15
        val g2 = perm[ii + 1 + perm[jj + 1]] and 15
        return SCALE * (corner(x0, y0, g0) + corner(x1, y1, g1) + corner(x2, y2, g2))
    }

    /** Fractal Brownian motion: sums several octaves of the base noise for more
     *  natural-looking terrain (broad shapes + fine detail). Result is in ~[-1,1]. */
    fun fbm2D(x: Double, y: Double, octaves: Int, persistence: Double, lacunarity: Double): Double {
        var total = 0.0
        var freq = 1.0
        var amp = 1.0
        var maxAmp = 0.0
        for (o in 0 until octaves) {
            total += noise2D(x * freq, y * freq) * amp
            maxAmp += amp
            amp *= persistence
            freq *= lacunarity
        }
        return total / maxAmp
    }

    /** Ridged multifractal: sharp crests with broad valleys between them, the shape of
     *  real mountain ranges. Each octave's contribution is weighted by the previous one so
     *  crests stay detailed while valley floors stay smooth. Result is in ~[0, 1]. */
    fun ridged2D(x: Double, y: Double, octaves: Int, lacunarity: Double, gain: Double): Double {
        var total = 0.0
        var freq = 1.0
        var amp = 0.5
        var weight = 1.0
        var norm = 0.0
        for (o in 0 until octaves) {
            var n = 1.0 - abs(noise2D(x * freq, y * freq))
            n *= n
            total += n * amp * weight
            norm += amp
            weight = (n * gain).coerceIn(0.0, 1.0)
            freq *= lacunarity
            amp *= 0.5
        }
        return total / norm
    }

    /** Single octave of 3D simplex noise, normalised to roughly [-1, 1]. Used for caves and
     *  ore pockets. Same family as [noise2D] (no axis-aligned grain), 12 edge-midpoint gradients. */
    fun noise3D(xin: Double, yin: Double, zin: Double): Double {
        val s = (xin + yin + zin) * F3
        val i = fastFloor(xin + s)
        val j = fastFloor(yin + s)
        val k = fastFloor(zin + s)
        val t = (i + j + k) * G3
        val x0 = xin - (i - t)
        val y0 = yin - (j - t)
        val z0 = zin - (k - t)
        val i1: Int
        val j1: Int
        val k1: Int
        val i2: Int
        val j2: Int
        val k2: Int
        if (x0 >= y0) {
            if (y0 >= z0) {
                i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 1; k2 = 0
            } else if (x0 >= z0) {
                i1 = 1; j1 = 0; k1 = 0; i2 = 1; j2 = 0; k2 = 1
            } else {
                i1 = 0; j1 = 0; k1 = 1; i2 = 1; j2 = 0; k2 = 1
            }
        } else {
            if (y0 < z0) {
                i1 = 0; j1 = 0; k1 = 1; i2 = 0; j2 = 1; k2 = 1
            } else if (x0 < z0) {
                i1 = 0; j1 = 1; k1 = 0; i2 = 0; j2 = 1; k2 = 1
            } else {
                i1 = 0; j1 = 1; k1 = 0; i2 = 1; j2 = 1; k2 = 0
            }
        }
        val x1 = x0 - i1 + G3
        val y1 = y0 - j1 + G3
        val z1 = z0 - k1 + G3
        val x2 = x0 - i2 + 2.0 * G3
        val y2 = y0 - j2 + 2.0 * G3
        val z2 = z0 - k2 + 2.0 * G3
        val x3 = x0 - 1.0 + 3.0 * G3
        val y3 = y0 - 1.0 + 3.0 * G3
        val z3 = z0 - 1.0 + 3.0 * G3
        val ii = i and 255
        val jj = j and 255
        val kk = k and 255
        val gi0 = perm[ii + perm[jj + perm[kk]]] % 12
        val gi1 = perm[ii + i1 + perm[jj + j1 + perm[kk + k1]]] % 12
        val gi2 = perm[ii + i2 + perm[jj + j2 + perm[kk + k2]]] % 12
        val gi3 = perm[ii + 1 + perm[jj + 1 + perm[kk + 1]]] % 12
        return 32.0 * (corner3(x0, y0, z0, gi0) + corner3(x1, y1, z1, gi1) + corner3(x2, y2, z2, gi2) + corner3(x3, y3, z3, gi3))
    }

    private fun corner3(x: Double, y: Double, z: Double, g: Int): Double {
        var t = 0.6 - x * x - y * y - z * z
        if (t < 0.0) return 0.0
        t *= t
        return t * t * (G3X[g] * x + G3Y[g] * y + G3Z[g] * z)
    }

    private fun corner(x: Double, y: Double, g: Int): Double {
        var t = 0.5 - x * x - y * y
        if (t <= 0.0) return 0.0
        t *= t
        return t * t * (GX[g] * x + GY[g] * y)
    }

    private fun fastFloor(v: Double): Int {
        val i = v.toInt()
        return if (v < i) i - 1 else i
    }

    private companion object {
        val F2: Double = 0.5 * (sqrt(3.0) - 1.0)
        val G2: Double = (3.0 - sqrt(3.0)) / 6.0

        /** Scales the raw simplex sum so a single octave spans ~[-1, 1]. */
        const val SCALE = 99.0

        const val F3 = 1.0 / 3.0
        const val G3 = 1.0 / 6.0

        /** The 12 gradients of 3D simplex noise: midpoints of the edges of a cube. */
        val G3X = doubleArrayOf(1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 1.0, -1.0, 0.0, 0.0, 0.0, 0.0)
        val G3Y = doubleArrayOf(1.0, 1.0, -1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 1.0, -1.0, 1.0, -1.0)
        val G3Z = doubleArrayOf(0.0, 0.0, 0.0, 0.0, 1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, -1.0)

        /** 16 evenly spread unit gradients: avoids the diagonal bias of the usual 8/12. */
        val GX = DoubleArray(16) { cos((it + 0.5) * 2.0 * PI / 16.0) }
        val GY = DoubleArray(16) { sin((it + 0.5) * 2.0 * PI / 16.0) }
    }
}
