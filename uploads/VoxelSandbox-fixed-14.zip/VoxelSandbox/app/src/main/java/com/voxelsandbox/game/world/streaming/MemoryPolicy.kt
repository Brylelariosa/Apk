package com.voxelsandbox.game.world.streaming

import kotlin.math.max
import kotlin.math.min

/** What is known about memory at one moment. A negative figure means "not known". */
class MemoryReading(
    @JvmField val heapUsed: Long,
    @JvmField val heapMax: Long,
    @JvmField val systemAvailable: Long = -1L,
    @JvmField val systemThreshold: Long = -1L,
    @JvmField val systemLow: Boolean = false
) {
    /** Share of the Java heap limit in use (0 when unknown). Includes garbage not collected yet. */
    val heapFraction: Float get() = if (heapMax > 0L) heapUsed.toFloat() / heapMax.toFloat() else 0f
}

/** Where readings come from. The Android implementation adds the system's figures (see AndroidMemoryProbe). */
fun interface MemoryProbe {
    fun read(): MemoryReading
}

/** Heap-only probe: all that is known without a Context, which is what tests and tools use. */
object RuntimeMemoryProbe : MemoryProbe {
    override fun read(): MemoryReading {
        val rt = Runtime.getRuntime()
        return MemoryReading(rt.totalMemory() - rt.freeMemory(), rt.maxMemory())
    }
}

/**
 * How much of the chunk memory budget may be used right now (a factor from [FLOOR] to 1), worked out
 * from what is actually known about memory instead of from the OS's trim callbacks alone.
 *
 * The callbacks were the problem. Android reports RUNNING_CRITICAL when its own list of cached
 * processes is short, which says little about this app: on a 4 GB phone it arrived three times in
 * six minutes while the app's heap sat at 150-209 MB of 512 MB, the system had 600-960 MB free and its
 * low-memory flag was never set. Each one halved the loaded area for a minute and then grew it back
 * ten percent at a time: the whole ring of chunks shrank and re-grew, which is exactly what
 * "chunks disappear and come back" looks like.
 *
 * Now:
 *  - trim callbacks mostly just ask for caches to be dropped ([consumeTrimRequest]); they cost a
 *    little of the budget only when a reading confirms that the system really is tight, and a lot
 *    only once the process is in the background, where it can be killed and nobody is looking;
 *  - real evidence (the heap near its limit, the system's low-memory flag, an OutOfMemoryError)
 *    lowers the budget in proportion to how bad it is;
 *  - the factor never jumps: it moves down at most [SHED_PER_SECOND] and up at most [REGAIN_PER_SECOND]
 *    per second, and only starts to grow back once there has been room for [REGAIN_DELAY_MS]. The
 *    loaded area therefore recedes and returns slowly enough that the dissolve into the distant
 *    terrain absorbs it, instead of a ring snapping in by a third (the one exception is an
 *    OutOfMemoryError, which is an emergency and is applied at once).
 *
 * All times are passed in (milliseconds on any monotonic clock), so the policy is deterministic and
 * testable. Thread-safe: the OS callback, the scheduler and the workers all feed it.
 */
class MemoryPolicy {
    /** Share of the memory budget in use now, [FLOOR]..1. */
    @Volatile var factor = 1f
        private set

    private var reading: MemoryReading? = null

    // Recent heap readings (time, share of the limit): the lowest of them is the live data. A reading of
    // the heap includes garbage that has not been collected yet, which can sit 30-40% above the live
    // data between collections without any danger, so deciding on the latest reading would cut the
    // budget over garbage. The lowest reading of the last [LIVE_WINDOW_MS] is what is really held.
    private val heapTimes = LongArray(HEAP_SAMPLES)
    private val heapShares = FloatArray(HEAP_SAMPLES)
    private var heapCount = 0
    private var heapNext = 0
    private var oomUntilMs = 0L
    private var criticalUntilMs = 0L
    private var backgroundUntilMs = 0L
    private var growSinceMs = -1L
    private var lastUpdateMs = -1L
    private var trimWanted = false

    /** What the latest figures say the budget should be (before the rate limits): for diagnostics. */
    @Volatile var target = 1f
        private set

    /** Why the budget is below 1 right now (empty when it is not): for diagnostics. */
    @Volatile var reason: String = ""
        private set

    /** A new reading of memory, taken at [nowMs]. */
    @Synchronized fun onReading(r: MemoryReading, nowMs: Long) {
        reading = r
        heapTimes[heapNext] = nowMs
        heapShares[heapNext] = r.heapFraction
        heapNext = (heapNext + 1) % HEAP_SAMPLES
        if (heapCount < HEAP_SAMPLES) heapCount++
    }

    /** Share of the heap limit held by live data: the lowest heap reading of the last [LIVE_WINDOW_MS]. */
    private fun liveHeapShare(nowMs: Long, fallback: Float): Float {
        var lowest = Float.MAX_VALUE
        for (k in 0 until heapCount) {
            if (nowMs - heapTimes[k] > LIVE_WINDOW_MS) continue
            if (heapShares[k] < lowest) lowest = heapShares[k]
        }
        return if (lowest == Float.MAX_VALUE) fallback else lowest
    }

    /** The OS asked apps to give memory back ([level] is a ComponentCallbacks2 trim level). [r] is a reading
     *  taken at the same moment, or null if none could be taken. */
    @Synchronized fun onTrim(level: Int, r: MemoryReading?, nowMs: Long) {
        if (r != null) onReading(r, nowMs)
        if (level >= TRIM_RUNNING_LOW) trimWanted = true
        if (level >= TRIM_BACKGROUND) {
            // In the LRU list: killable, and not on screen. Shrinking costs nothing anyone can see.
            backgroundUntilMs = nowMs + BACKGROUND_HOLD_MS
        } else if (level >= TRIM_RUNNING_CRITICAL && level < TRIM_UI_HIDDEN) {
            // The app is in the foreground. Only a system that really is short of memory counts.
            val rd = r ?: reading
            if (rd != null && systemTight(rd)) criticalUntilMs = nowMs + TRIM_HOLD_MS
        }
    }

    /** A worker ran out of memory: the one case where waiting is not an option. */
    @Synchronized fun onOutOfMemory(nowMs: Long) {
        oomUntilMs = nowMs + OOM_HOLD_MS
        if (factor > OOM_FACTOR) factor = OOM_FACTOR
        growSinceMs = -1L
        trimWanted = true
    }

    /** True once after a request to drop caches (pooled buffers and the like). */
    @Synchronized fun consumeTrimRequest(): Boolean {
        val w = trimWanted
        trimWanted = false
        return w
    }

    /** Moves [factor] towards what the evidence calls for, within the rate limits. Call a few times a
     *  second. Returns the new factor. */
    @Synchronized fun update(nowMs: Long): Float {
        val dt = if (lastUpdateMs < 0L) 0f else ((nowMs - lastUpdateMs) / 1000f).coerceIn(0f, 1f)
        lastUpdateMs = nowMs

        var t = 1f
        var why = ""
        val r = reading
        if (r != null) {
            val live = liveHeapShare(nowMs, r.heapFraction)
            val h = heapTarget(live)
            if (h < t) { t = h; why = "live data fills " + percent(live) + " of the heap limit" }
            val s = systemTarget(r)
            if (s < t) { t = s; why = if (r.systemLow) "the system reports low memory" else "system memory is close to its low-memory threshold" }
        }
        if (nowMs < criticalUntilMs && CRITICAL_FACTOR < t) { t = CRITICAL_FACTOR; why = "the OS asked for memory back and the system is short of it" }
        if (nowMs < backgroundUntilMs && BACKGROUND_FACTOR < t) { t = BACKGROUND_FACTOR; why = "the app is in the background and can be killed" }
        if (nowMs < oomUntilMs && OOM_FACTOR < t) { t = OOM_FACTOR; why = "a worker ran out of memory" }
        target = t
        reason = if (t < 1f) why else ""

        val f = factor
        if (t < f) {
            growSinceMs = -1L
            factor = max(t, f - SHED_PER_SECOND * dt)
        } else if (t > f) {
            // Room to grow must last for a while before the budget is given back: a reading that
            // dips for a moment (the heap between two collections) is not the pressure having passed.
            if (growSinceMs < 0L) growSinceMs = nowMs
            if (nowMs - growSinceMs >= REGAIN_DELAY_MS) factor = min(t, f + REGAIN_PER_SECOND * dt)
        } else {
            growSinceMs = -1L
        }
        return factor
    }

    /** True when the system's own figures say it is short of memory (not merely that the OS sent a callback). */
    private fun systemTight(r: MemoryReading): Boolean {
        if (r.systemLow) return true
        return r.systemAvailable >= 0L && r.systemThreshold > 0L && r.systemAvailable < r.systemThreshold * TIGHT_MULTIPLE
    }

    private fun heapTarget(u: Float): Float {
        if (u <= HEAP_COMFORT) return 1f
        if (u >= HEAP_DANGER) return FLOOR
        return 1f - (u - HEAP_COMFORT) / (HEAP_DANGER - HEAP_COMFORT) * (1f - FLOOR)
    }

    private fun systemTarget(r: MemoryReading): Float {
        if (r.systemLow) return LOW_FACTOR
        if (r.systemAvailable >= 0L && r.systemThreshold > 0L && r.systemAvailable < r.systemThreshold * APPROACH_MULTIPLE) return APPROACHING_FACTOR
        return 1f
    }

    private fun percent(x: Float): String = (x * 100f + 0.5f).toInt().toString() + "%"

    companion object {
        // ComponentCallbacks2 trim levels (the values are part of the Android API).
        const val TRIM_RUNNING_MODERATE = 5
        const val TRIM_RUNNING_LOW = 10
        const val TRIM_RUNNING_CRITICAL = 15
        const val TRIM_UI_HIDDEN = 20
        const val TRIM_BACKGROUND = 40

        /** The heap's live share is the lowest reading within this window; readings come about once a second. */
        const val LIVE_WINDOW_MS = 20_000L
        private const val HEAP_SAMPLES = 64

        /** The budget never goes below this share, whatever the evidence. */
        const val FLOOR = 0.5f

        /** Nothing is cut while the heap is below this share of its limit; at [HEAP_DANGER] the budget is at [FLOOR]. */
        const val HEAP_COMFORT = 0.78f
        const val HEAP_DANGER = 0.93f

        const val LOW_FACTOR = 0.8f
        const val APPROACHING_FACTOR = 0.9f
        const val CRITICAL_FACTOR = 0.9f
        const val BACKGROUND_FACTOR = 0.6f
        const val OOM_FACTOR = 0.6f

        /** The system counts as "close to low" within this many multiples of its own threshold... */
        const val APPROACH_MULTIPLE = 1.5f

        /** ...and as tight, for a RUNNING_CRITICAL callback to count, within this many. */
        const val TIGHT_MULTIPLE = 3f

        const val OOM_HOLD_MS = 60_000L
        const val TRIM_HOLD_MS = 30_000L
        const val BACKGROUND_HOLD_MS = 120_000L

        /** Fastest the budget may fall / recover, as a share of the full budget per second. At the
         *  1260-chunk budget of a 512 MB heap that is about 38 chunks/s down and 13 chunks/s up. */
        const val SHED_PER_SECOND = 0.03f
        const val REGAIN_PER_SECOND = 0.01f

        /** Recovery starts once there has been room to grow for this long without a break. */
        const val REGAIN_DELAY_MS = 15_000L
    }
}
