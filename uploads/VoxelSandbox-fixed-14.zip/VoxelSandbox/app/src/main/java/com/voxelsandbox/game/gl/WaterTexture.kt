package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The water tile: 16x16 pixel art in a few close blues, in the same style as
 * the block textures. It is baked below (a palette plus 16 rows of palette digits), periodic in
 * both directions so the shader can scroll it freely, and very low in contrast (no bright flecks,
 * which read as rain streaks when seen at a slant) so that one repeat per block never reads as a grid. Its average colour is what the water shader fades to far
 * away (see Shaders.WATER_FRAGMENT).
 *
 * Nearest-texel magnification (crisp square pixels up close) with trilinear mip-mapping in the
 * distance, where the pattern smoothly averages out instead of aliasing.
 */
class WaterTexture {
    private var textureId = 0

    fun upload() {
        val ids = IntArray(1)
        GLES30.glGenTextures(1, ids, 0)
        textureId = ids[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)

        val buf = ByteBuffer.allocateDirect(SIZE * SIZE * 4).order(ByteOrder.nativeOrder())
        buf.put(generate())
        buf.position(0)
        GLES30.glTexImage2D(
            GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, SIZE, SIZE, 0,
            GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buf
        )
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
    }

    fun bind(unit: Int) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
    }

    /** RGBA bytes of the tile, row by row (alpha is always 255; the shader sets its own). */
    private fun generate(): ByteArray {
        val parts = PALETTE.split(' ')
        val r = IntArray(parts.size)
        val g = IntArray(parts.size)
        val b = IntArray(parts.size)
        for (i in parts.indices) {
            val rgb = parts[i].toInt(16)
            r[i] = (rgb shr 16) and 0xFF
            g[i] = (rgb shr 8) and 0xFF
            b[i] = rgb and 0xFF
        }
        val out = ByteArray(SIZE * SIZE * 4)
        for (i in 0 until SIZE * SIZE) {
            val ch = if (i < ROWS.length) ROWS[i] else '0'
            var d = if (ch <= '9') ch - '0' else ch - 'a' + 10
            if (d < 0 || d >= parts.size) d = 0
            out[i * 4] = r[d].toByte()
            out[i * 4 + 1] = g[d].toByte()
            out[i * 4 + 2] = b[d].toByte()
            out[i * 4 + 3] = 255.toByte()
        }
        return out
    }

    private companion object {
        const val SIZE = 16

        /** Blues, dark to light, as RRGGBB. */
        const val PALETTE = "4279d2 4980d7 5088db"

        /** SIZE * SIZE palette digits, row by row. */
        const val ROWS =
            "0010100000011100" +
            "1111110000001100" +
            "1111111000000000" +
            "1111110000001111" +
            "1111110000000111" +
            "1111110000000111" +
            "1111111100000001" +
            "1111211110000001" +
            "1111111111000001" +
            "1112211111100011" +
            "1112111111110111" +
            "1221211111111112" +
            "2222111111111112" +
            "1211111111111111" +
            "1111111000111111" +
            "1111110000000011"
    }
}
