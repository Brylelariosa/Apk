package com.voxelsandbox.game.gl

import android.opengl.GLES30

/**
 * The translucent, animated water pass. It owns the water program and its tile texture
 * and knows nothing about where the water meshes come from: GameRenderer (voxel chunks)
 * and FarTerrainRenderer (distant tiles) each call [begin], pick an area with
 * [useNearArea] / [useFarArea] + [setBand], draw their meshes, then call [end].
 *
 * Water is drawn after all opaque geometry, with blending on and depth writes off, so the
 * lake bed (or whatever lies behind) shows through according to the surface's opacity.
 *
 * The look matches the block textures: a 16x16 pixel-art water tile (see WaterTexture), one
 * repeat per block, drifting slowly or sliding along the flow direction stored in the
 * vertices, tinted by water depth and by the sky at grazing angles. It is the same pattern at
 * every distance (the tile's mip chain averages it away on its own), so water never "fills
 * in" as you walk up to it. That is also cheap: one texture fetch, no per-pixel trigonometry,
 * for the one big translucent layer that covers a lot of the screen over an ocean.
 */
class WaterRenderer {
    private lateinit var program: ShaderProgram
    private val texture = WaterTexture()

    private var uViewProj = 0
    private var uCamOrigin = 0
    private var uWaterTex = 0
    private var uTime = 0
    private var uEyeRel = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uCenter = 0
    private var uBand = 0
    private var uSkip = 0
    private var uVoxel = 0
    private var uSide = 0
    private var uCover = 0

    /** Call from onSurfaceCreated (a new GL context needs a fresh program and texture). */
    fun init() {
        program = ShaderProgram(Shaders.WATER_VERTEX, Shaders.WATER_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uCamOrigin = program.uniform("uCamOrigin")
        uWaterTex = program.uniform("uWaterTex")
        uTime = program.uniform("uTime")
        uEyeRel = program.uniform("uEyeRel")
        uFogColor = program.uniform("uFogColor")
        uFogStart = program.uniform("uFogStart")
        uFogEnd = program.uniform("uFogEnd")
        uCenter = program.uniform("uCenter")
        uBand = program.uniform("uBand")
        uSkip = program.uniform("uSkip")
        uVoxel = program.uniform("uVoxel")
        uSide = program.uniform("uSide")
        uCover = program.uniform("uCover")
        texture.upload()
    }

    /** Switches to the water program with this frame's shared uniforms and turns blending on. */
    fun begin(frame: FrameState) {
        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)
        GLES30.glUniform3f(uCamOrigin, frame.originX, frame.originY, frame.originZ)
        GLES30.glUniform1f(uTime, frame.textureTime)
        GLES30.glUniform3f(uEyeRel, frame.eyeRelX, frame.eyeRelY, frame.eyeRelZ)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        texture.bind(1)
        GLES30.glUniform1i(uWaterTex, 1)
        GLES30.glUniform1i(uCover, CoverageMask.UNIT) // the mask itself is bound once per frame (GameRenderer)
        GLES30.glUniform2f(uCenter, frame.eyeX, frame.eyeZ)
        GLES30.glUniform2f(uVoxel, frame.fadeStart, frame.fadeStart + frame.fadeWidth)
        GLES30.glUniform2f(uSkip, 0f, 0f)

        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
    }

    /**
     * Water in voxel chunks. With [seamWithFar] (the distant terrain is on) it fades out across the
     * seam where the distant water takes over (see [useFarArea] and Shaders.WATER_FRAGMENT); otherwise
     * (distant terrain off, or underwater) nothing is faded or clipped.
     */
    fun useNearArea(seamWithFar: Boolean) {
        GLES30.glUniform1f(uSide, if (seamWithFar) 1f else 0f)
        GLES30.glUniform4f(uBand, 0f, 1.0e9f, 0f, 0f)
        GLES30.glUniform2f(uSkip, 0f, 0f)
    }

    /** Distant water: kept out of the columns that have voxel terrain and faded in across the seam.
     *  Follow with [setBand] for each ring of detail. */
    fun useFarArea() {
        GLES30.glUniform1f(uSide, -1f)
    }

    /** Clips distant water to the ring [innerRadius, outerRadius) around the player, minus the ring
     *  [skipInner, skipOuter) that another level draws (both 0: none). */
    fun setBand(innerRadius: Float, outerRadius: Float, skipInner: Float = 0f, skipOuter: Float = 0f) {
        GLES30.glUniform4f(uBand, innerRadius, outerRadius, 0f, 0f)
        GLES30.glUniform2f(uSkip, skipInner, skipOuter)
    }

    /** Leaves GL in the state the opaque passes expect. */
    fun end() {
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }
}
