package com.voxelsandbox.game.world.streaming

import kotlin.math.sqrt

/**
 * Decides which of the packed regions waiting in [ReadyRegions] go to the GPU this frame, and in
 * what order. It knows nothing about GL (the caller supplies the `apply` that does the actual
 * upload), which keeps the policy in one place and testable without a device.
 *
 * Policy:
 *  - player edits (urgent) always go, first, whatever the budget says;
 *  - the rest go in order of how soon they are needed: nearest first, regions behind the camera a
 *    little later, and a region that has no terrain on screen yet counts as closer than it is (a
 *    hole is worse than a stale version of something that is already visible);
 *  - uploads stop once the frame's byte or time budget is spent, but the first one always goes, so
 *    a region bigger than the whole budget is slow, never stuck.
 */
class RegionUploadScheduler {
    /** Bytes and regions handed over by the last [drain] (for the stats overlay). */
    var lastBytes = 0
        private set
    var lastRegions = 0
        private set

    private var keyScratch = LongArray(0)
    private var scoreScratch = FloatArray(0)

    /**
     * [hasMesh] says whether a region already has terrain on the GPU; [apply] uploads one packed
     * region (and must recycle its buffers). Returns the number of regions uploaded.
     */
    fun drain(
        ready: ReadyRegions,
        hasMesh: (Long) -> Boolean,
        eyeX: Float,
        eyeZ: Float,
        lookX: Float,
        lookZ: Float,
        byteBudget: Int,
        nanoBudget: Long,
        startNs: Long,
        apply: (PackedRegion) -> Unit
    ): Int {
        lastBytes = 0
        lastRegions = 0
        if (ready.count == 0) return 0
        val keys = ready.keys()
        val n = keys.size
        if (n == 0) return 0

        for (i in 0 until n) {
            val pack = ready.peek(keys[i]) ?: continue
            if (!pack.urgent) continue
            val taken = ready.take(keys[i]) ?: continue
            lastBytes += taken.totalBytes
            lastRegions++
            apply(taken)
        }

        if (scoreScratch.size < n) {
            scoreScratch = FloatArray(n * 2)
            keyScratch = LongArray(n * 2)
        }
        var m = 0
        for (i in 0 until n) {
            val pack = ready.peek(keys[i]) ?: continue
            keyScratch[m] = keys[i]
            scoreScratch[m] = rank(keys[i], pack, hasMesh, eyeX, eyeZ, lookX, lookZ)
            m++
        }
        // Insertion sort: m is the number of regions waiting, a few dozen at most.
        for (i in 1 until m) {
            val k = keyScratch[i]
            val s = scoreScratch[i]
            var j = i - 1
            while (j >= 0 && scoreScratch[j] > s) {
                keyScratch[j + 1] = keyScratch[j]
                scoreScratch[j + 1] = scoreScratch[j]
                j--
            }
            keyScratch[j + 1] = k
            scoreScratch[j + 1] = s
        }

        for (i in 0 until m) {
            val pack = ready.peek(keyScratch[i]) ?: continue
            if (!UploadBudget.admits(lastRegions, lastBytes.toLong(), pack.totalBytes, byteBudget, System.nanoTime() - startNs, nanoBudget)) break
            val taken = ready.take(keyScratch[i]) ?: continue
            lastBytes += taken.totalBytes
            lastRegions++
            apply(taken)
        }
        return lastRegions
    }

    private fun rank(key: Long, pack: PackedRegion, hasMesh: (Long) -> Boolean, eyeX: Float, eyeZ: Float, lookX: Float, lookZ: Float): Float {
        val span = (ColumnKeys.REGION_SIZE * 16).toFloat()
        val cx = ColumnKeys.regionX(key) * span + span * 0.5f
        val cz = ColumnKeys.regionZ(key) * span + span * 0.5f
        val dx = cx - eyeX
        val dz = cz - eyeZ
        val d = sqrt(dx * dx + dz * dz)
        val cosLook = if (d > 1f) (dx * lookX + dz * lookZ) / d else 1f
        val behind = if (cosLook >= 0.3f) 0f else (0.3f - cosLook) / 1.3f
        var score = d * (1f + 0.6f * behind)
        if (pack.solid != null && !hasMesh(key)) score *= 0.6f
        return score
    }
}
