package com.voxelsandbox.game.world.streaming

/**
 * Packing of chunk-column and region coordinates into Longs, shared by the streaming threads
 * and the renderer so both mean the same thing by "column" and "region". A region is
 * [REGION_SIZE] x [REGION_SIZE] columns that share one GPU buffer (and so one draw call).
 */
object ColumnKeys {
    const val REGION_SHIFT = 2
    const val REGION_SIZE = 1 shl REGION_SHIFT

    fun column(cx: Int, cz: Int): Long = (cx.toLong() shl 32) or (cz.toLong() and 0xFFFFFFFFL)
    fun columnX(key: Long): Int = (key shr 32).toInt()
    fun columnZ(key: Long): Int = key.toInt()

    fun region(cx: Int, cz: Int): Long =
        ((cx shr REGION_SHIFT).toLong() shl 32) or ((cz shr REGION_SHIFT).toLong() and 0xFFFFFFFFL)

    fun regionX(key: Long): Int = (key shr 32).toInt()
    fun regionZ(key: Long): Int = key.toInt()

    /** The region a column belongs to. */
    fun regionOfColumn(columnKey: Long): Long = region(columnX(columnKey), columnZ(columnKey))
}
