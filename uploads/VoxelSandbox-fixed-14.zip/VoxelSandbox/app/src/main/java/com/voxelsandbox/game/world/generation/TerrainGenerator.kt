package com.voxelsandbox.game.world.generation

import com.voxelsandbox.game.world.BlockType
import com.voxelsandbox.game.world.Chunk
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.SubChunk
import com.voxelsandbox.game.world.WorldConfig
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** A good place to start a new world: dry, gentle ground well away from the shore. */
class SpawnPoint(val x: Int, val z: Int)

/**
 * Deterministic seeded terrain generator: the same (seed, chunkX, chunkZ) always
 * produces the same chunk, which is what lets SaveManager store only player-modified
 * chunks and regenerate everything else from the seed on load.
 *
 * The landscape itself lives in [TerrainShape] (height) and [Climate] (temperature,
 * humidity, surface type); this class turns those pure functions into blocks:
 * layered soil per surface type, plants, cacti and trees.
 *
 * Trees are placed without any neighbour coordination and still cross chunk borders
 * cleanly: every chunk independently evaluates the (pure, position-hashed) tree
 * candidates in its own area *plus a margin*, and writes only the tree blocks that fall
 * inside itself. A canopy that straddles a border is therefore assembled from the same
 * deterministic tree by both chunks, with no cross-chunk writes and no races. The
 * terrain height is a pure function of (x, z), so a chunk can also ask "how high is the
 * ground under that neighbouring tree" without the neighbour existing.
 */
class TerrainGenerator(private val seed: Long) {
    /** Temperature / humidity / surface type; also sampled by the distant-terrain builder. */
    val climate = Climate(seed)

    /** Land-form (height); also sampled directly by the distant-terrain builder. */
    val shape = TerrainShape(seed, climate)

    /** Tunnels, caverns and entrance ramps. */
    private val caves = CaveCarver(seed, shape)

    private val oreNoise = NoiseGenerator(mixSeed(seed, 20))
    private val lilyNoise = NoiseGenerator(mixSeed(seed, 21))
    private val seagrassNoise = NoiseGenerator(mixSeed(seed, 22))
    private val pocketNoise = NoiseGenerator(mixSeed(seed, 23))
    private val deepNoise = NoiseGenerator(mixSeed(seed, 24))
    private val seedMix: Int = seed.toInt() * 1274126177
    private val trees = TreeBuilder(seedMix)

    fun generate(pos: ChunkPos): Chunk {
        val chunk = Chunk(pos)
        val size = WorldConfig.CHUNK_SIZE
        val baseX = pos.x * size
        val baseZ = pos.z * size

        // Raw ground heights for the chunk plus a two-block border: one block so the slope of
        // edge columns is exact without needing the neighbouring chunks, one more so the
        // lone-bump filter below can look at the neighbours of those border columns.
        val r = size + 4
        val raw = IntArray(r * r)
        // The smooth base elevation of every sampled column comes out of the same pass as its
        // height (see TerrainShape.heightAndCoast), so the biome code below need not recompute it.
        val coast = DoubleArray(r * r)
        for (gz in 0 until r) {
            for (gx in 0 until r) {
                val i = gz * r + gx
                raw[i] = floor(
                    shape.heightAndCoast((baseX + gx - 2).toDouble(), (baseZ + gz - 2).toDouble(), 0, coast, i)
                ).toInt()
            }
        }
        val g = size + 2
        val heights = IntArray(g * g)
        for (gz in 0 until g) {
            for (gx in 0 until g) {
                val i = (gz + 1) * r + (gx + 1)
                heights[gz * g + gx] = despike(raw[i], raw[i - r], raw[i + 1], raw[i + r], raw[i - 1])
            }
        }

        val ground = IntArray(size * size)
        val underWater = BooleanArray(size * size)
        val rock = RockNoise(baseX, baseZ)
        for (lz in 0 until size) {
            for (lx in 0 until size) {
                val i = (lz + 1) * g + (lx + 1)
                val rise = max(abs(heights[i + 1] - heights[i - 1]), abs(heights[i + g] - heights[i - g]))
                fillColumn(chunk, lx, lz, baseX + lx, baseZ + lz, heights[i], rise * 0.5, rock, coast[(lz + 2) * r + (lx + 2)])
                ground[lz * size + lx] = heights[i]
                underWater[lz * size + lx] = heights[i] < WorldConfig.SEA_LEVEL
                chunk.heightMap[lz * size + lx] = heights[i].toShort()
            }
        }
        caves.carve(chunk, ground, underWater)
        chunk.caveMouth = caves.caveMouthNear(pos.x, pos.z)
        placeTrees(ChunkCanvas(chunk, baseX, baseZ), baseX, baseZ)
        return chunk
    }

    private fun rawHeight(wx: Int, wz: Int): Int = floor(shape.height(wx.toDouble(), wz.toDouble())).toInt()

    /** Removes a lone one-block bump (higher than all four neighbours by exactly one) or
     *  one-block pit, so flat country stays flat instead of being studded with single blocks. */
    private fun despike(c: Int, n: Int, e: Int, s: Int, w: Int): Int {
        val hi = max(max(n, e), max(s, w))
        val lo = minOf(minOf(n, e), minOf(s, w))
        if (c > hi && c - hi == 1) return hi
        if (c < lo && lo - c == 1) return lo
        return c
    }

    /** Y of the topmost solid block at (wx, wz). Pure function of position (it evaluates the
     *  same filtered height the chunk generator uses); the distant-terrain builder and the tree
     *  placement sample it directly without generating any chunk. */
    fun surfaceHeight(wx: Int, wz: Int): Int = despike(
        rawHeight(wx, wz), rawHeight(wx, wz - 1), rawHeight(wx + 1, wz), rawHeight(wx, wz + 1), rawHeight(wx - 1, wz)
    )

    /** Forest-ness in 0..1 (0 = open plains, 1 = dense forest). */
    fun forestFactor(wx: Int, wz: Int): Double = climate.forest(wx.toDouble(), wz.toDouble())

    // ---- Spawn ------------------------------------------------------------------------------

    /**
     * Searches outward from the origin, ring by ring, for the nearest pleasant spot to
     * start: dry gentle grassland with no water or cliff within a few blocks. Pure and
     * deterministic, so a world always starts in the same place for the same seed.
     */
    fun findSpawn(): SpawnPoint {
        for (ring in 0..SPAWN_MAX_RINGS) {
            val radius = ring * SPAWN_STEP
            val count = if (ring == 0) 1 else max(8, (2.0 * PI * radius / SPAWN_STEP).toInt())
            val phase = ring * 0.61
            for (k in 0 until count) {
                val a = phase + 2.0 * PI * k / count
                val x = (radius * cos(a)).roundToInt()
                val z = (radius * sin(a)).roundToInt()
                if (isGoodSpawn(x, z)) return SpawnPoint(x, z)
            }
        }
        return SpawnPoint(0, 0)
    }

    private fun isGoodSpawn(x: Int, z: Int): Boolean {
        val sea = WorldConfig.SEA_LEVEL
        val h = surfaceHeight(x, z)
        if (h < sea + 3 || h > sea + 24) return false
        var i = 0
        while (i < SPAWN_PROBES.size) {
            val h2 = surfaceHeight(x + SPAWN_PROBES[i], z + SPAWN_PROBES[i + 1])
            if (h2 < sea + 1 || abs(h2 - h) > 5) return false
            i += 2
        }
        return when (biomeAtGround(x, z, h)) {
            Biome.PLAINS, Biome.FOREST, Biome.BIRCH_FOREST, Biome.SAVANNA, Biome.TAIGA -> true
            else -> false
        }
    }

    // ---- Biomes -----------------------------------------------------------------------------

    /** Biome of dry ground at (wx, wz) whose top block is at [ground]. Measures the slope
     *  itself (four extra height samples), so use it for sparse queries only. */
    private fun biomeAtGround(wx: Int, wz: Int, ground: Int): Biome {
        val rise = max(
            abs(surfaceHeight(wx + 1, wz) - surfaceHeight(wx - 1, wz)),
            abs(surfaceHeight(wx, wz + 1) - surfaceHeight(wx, wz - 1))
        )
        val x = wx.toDouble()
        val z = wz.toDouble()
        return climate.biome(x, z, ground.toDouble(), rise * 0.5, shape.coastElevation(x, z))
    }

    /** The biome at column (wx, wz), water columns included. A pure function of position. */
    fun biomeAt(wx: Int, wz: Int): Biome {
        val h = surfaceHeight(wx, wz)
        if (h < WorldConfig.SEA_LEVEL) {
            return climate.waterBiome(
                wx.toDouble(), wz.toDouble(),
                (WorldConfig.SEA_LEVEL - h).toDouble(),
                shape.coastElevation(wx.toDouble(), wz.toDouble())
            )
        }
        return biomeAtGround(wx, wz, h)
    }

    private fun fillColumn(
        chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, slope: Double, rock: RockNoise, coastElev: Double
    ) {
        val sea = WorldConfig.SEA_LEVEL
        val x = wx.toDouble()
        val z = wz.toDouble()
        val h = height.toDouble()
        val humid = climate.humidity(x, z)

        var kind = SurfaceKind.GRASS
        var biome = Biome.PLAINS
        var topBlock = BlockType.GRASS
        var soilBlock = BlockType.DIRT
        var soilLayers = 3
        var strataBlock = BlockType.STONE
        var strataLayers = 0
        var swampWater = false

        if (height < sea) {
            // Sea / lake / river bed: sand in the shallows of warm water, gravel in the deep
            // and everywhere in cold water, mud (dirt) in the ponds of a swamp.
            val waterDepth = sea - height
            swampWater = waterDepth <= LILY_MAX_DEPTH &&
                climate.waterBiome(x, z, waterDepth.toDouble(), coastElev) == Biome.SWAMP
            val deep = waterDepth > 8
            val cold = climate.baseTemperature(x, z) < Climate.COLD
            topBlock = if (swampWater) BlockType.DIRT else if (deep || cold) BlockType.GRAVEL else BlockType.SAND
            soilBlock = topBlock
            soilLayers = 2
        } else {
            biome = climate.biome(x, z, h, slope, coastElev, climate.baseTemperature(x, z), humid)
            kind = climate.surfaceFor(biome, x, z, h, slope)
            when (kind) {
                SurfaceKind.GRASS -> {}
                SurfaceKind.DRY_GRASS -> topBlock = BlockType.DRY_GRASS
                SurfaceKind.DESERT -> {
                    topBlock = BlockType.SAND
                    soilBlock = BlockType.SAND
                    soilLayers = 3
                    strataBlock = BlockType.SANDSTONE
                    strataLayers = 4
                }
                SurfaceKind.BEACH -> {
                    topBlock = BlockType.SAND
                    soilBlock = BlockType.SAND
                    soilLayers = 2
                }
                SurfaceKind.SNOW -> topBlock = BlockType.SNOW
                SurfaceKind.SWAMP -> topBlock = BlockType.SWAMP_GRASS
                SurfaceKind.ROCK -> {
                    topBlock = BlockType.STONE
                    soilBlock = BlockType.STONE
                    soilLayers = 0
                }
                SurfaceKind.GRAVEL -> {
                    topBlock = BlockType.GRAVEL
                    soilBlock = BlockType.GRAVEL
                    soilLayers = 2
                }
            }
        }

        // The rock turns dark ("deep stone") towards the bottom, along a wavy boundary.
        val deepY = DEEP_STONE_Y + (deepNoise.noise2D(x * 0.045, z * 0.045) * 5.0).toInt()
        val topY = max(height, sea)
        // Written straight into the sub-chunk arrays (each one is fetched once per 16 layers):
        // this loop stores tens of thousands of blocks per chunk, and the generic setBlock path
        // (bounds checks, a volatile read and a volatile write per block) used to cost more than
        // the blocks themselves. Nothing but real blocks is written here, so the same sub-chunks
        // get their own arrays as before.
        val subs = chunk.subChunks
        var curSub = -1
        var cur: ByteArray = NO_BLOCKS
        for (y in 0..topY) {
            val block: BlockType = when {
                y > height -> BlockType.WATER // only below sea level (height < y <= sea)
                y == height -> topBlock
                y == 0 -> BlockType.DEEP_STONE
                else -> {
                    val depth = height - y
                    when {
                        depth <= soilLayers -> soilBlock
                        depth <= soilLayers + strataLayers -> strataBlock
                        else -> rockBlock(lx, y, lz, deepY, depth, rock)
                    }
                }
            }
            val sub = y shr 4
            if (sub != curSub) {
                curSub = sub
                cur = subs[sub].writableBlocks()
            }
            cur[SubChunk.index(lx, y and 15, lz)] = block.id
        }

        if (height >= sea && height + 2 < WorldConfig.WORLD_HEIGHT) {
            scatterPlants(chunk, lx, lz, wx, wz, height, kind, biome, humid)
        } else if (height < sea) {
            scatterWaterPlants(chunk, lx, lz, wx, wz, height, swampWater)
        }
    }

    /** The 3D noise behind coal veins and the gravel / dirt pockets, on a lattice of 2-block
     *  cells over the chunk. Index: (lz / 2 * 8 + lx / 2) * ORE_LEVELS + y / 2. A cell is only
     *  sampled (at its centre, both fields together) the first time a rock block asks for it, see
     *  [rockBlock]: veins and pockets are several blocks across, so a block just takes the value
     *  of its cell, and the cells above the ground, which nothing ever asks about, cost nothing. */
    private class RockNoise(val baseX: Int, val baseZ: Int) {
        val coal = FloatArray(ORE_CELLS * ORE_CELLS * ORE_LEVELS)
        val pocket = FloatArray(ORE_CELLS * ORE_CELLS * ORE_LEVELS)
        val sampled = BooleanArray(ORE_CELLS * ORE_CELLS * ORE_LEVELS)
    }

    /** Samples the ore and pocket noise at the centre of cell [k] (2x2x2 blocks) of [rock]. */
    private fun sampleRockCell(rock: RockNoise, k: Int) {
        val gy = k % ORE_LEVELS
        val cell = k / ORE_LEVELS
        val gx = cell % ORE_CELLS
        val gz = cell / ORE_CELLS
        val x = rock.baseX + gx * 2 + 1.0
        val z = rock.baseZ + gz * 2 + 1.0
        val y = gy * 2 + 1.0
        rock.coal[k] = oreNoise.noise3D(x * 0.17, y * 0.17, z * 0.17).toFloat()
        rock.pocket[k] = pocketNoise.noise3D(x * 0.06, y * 0.08, z * 0.06).toFloat()
        rock.sampled[k] = true
    }

    /**
     * One block of the rock under the soil: stone (dark "deep stone" below [deepY]), with
     * coal veins and pockets of gravel and dirt from the chunk's [RockNoise]. [depth] is the
     * distance below the surface; the top few layers and the bedrock row stay plain, and above
     * the foothills the rock is not worth the lookups.
     */
    private fun rockBlock(lx: Int, y: Int, lz: Int, deepY: Int, depth: Int, rock: RockNoise): BlockType {
        val stone = if (y < deepY) BlockType.DEEP_STONE else BlockType.STONE
        if (depth < 6 || y < 4 || y > ORE_MAX_Y) return stone
        val k = ((lz shr 1) * ORE_CELLS + (lx shr 1)) * ORE_LEVELS + (y shr 1)
        if (!rock.sampled[k]) sampleRockCell(rock, k)
        if (rock.coal[k] > COAL_THRESHOLD) return BlockType.COAL_ORE
        val pocket = rock.pocket[k]
        if (pocket > POCKET_THRESHOLD) return BlockType.GRAVEL
        if (pocket < -POCKET_THRESHOLD) return BlockType.DIRT
        return stone
    }

    /** Plants that live in the water of the column whose bed is at [height]: lily pads on the
     *  ponds of a swamp (and only there), seagrass meadows on the bed of every other body of
     *  water that is deep enough to cover them. */
    private fun scatterWaterPlants(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, swampWater: Boolean) {
        val sea = WorldConfig.SEA_LEVEL
        val depth = sea - height
        val x = wx.toDouble()
        val z = wz.toDouble()
        if (swampWater) {
            // lily pads float on the pond, in loose patches
            val patch = lilyNoise.noise2D(x * 0.07 + 13.0, z * 0.07 - 29.0)
            if (patch > 0.0 && ((hash3(wx, 11, wz) ushr 7) and 1) == 0) {
                chunk.setBlock(lx, sea + 1, lz, BlockType.LILY_PAD)
            }
            return
        }
        if (depth < SEAGRASS_MIN_DEPTH || depth > SEAGRASS_MAX_DEPTH) return
        val patch = seagrassNoise.noise2D(x * 0.045 + 3.0, z * 0.045 - 11.0)
        if (patch < 0.05) return
        val chance = if (patch > 0.45) 0.65 else 0.32
        val roll = ((hash3(wx, 23, wz) ushr 6) and 0xFF) / 256.0
        if (roll < chance) chunk.setBlock(lx, height + 1, lz, BlockType.SEAGRASS)
    }

    // ---- Ground cover ---------------------------------------------------------------------

    /** Grass tufts, flowers, dead bushes and cacti on top of the ground block. */
    private fun scatterPlants(chunk: Chunk, lx: Int, lz: Int, wx: Int, wz: Int, height: Int, kind: SurfaceKind, biome: Biome, humid: Double) {
        val bits = hash3(wx, 7, wz)
        val u = ((bits ushr 8) and 0xFFFF) / 65536.0
        val y = height + 1
        when (kind) {
            SurfaceKind.GRASS -> {
                val tufts = 0.10 + 0.14 * (humid + 1.0) * 0.5 // thicker in wet country
                val flowers = when (biome) {
                    Biome.PLAINS -> 0.035 // meadows are full of flowers
                    Biome.FOREST, Biome.BIRCH_FOREST -> 0.016
                    else -> 0.006
                }
                if (u < tufts) {
                    chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
                } else if (u < tufts + flowers) {
                    chunk.setBlock(lx, y, lz, if ((bits and 1) == 0) BlockType.POPPY else BlockType.DANDELION)
                }
            }
            SurfaceKind.DRY_GRASS -> {
                if (u < 0.09) {
                    chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
                } else if (u < 0.10) {
                    chunk.setBlock(lx, y, lz, BlockType.DEAD_BUSH)
                }
            }
            SurfaceKind.SWAMP -> {
                if (u < 0.26) chunk.setBlock(lx, y, lz, BlockType.TALL_GRASS)
            }
            SurfaceKind.DESERT -> {
                if (u < 0.012) {
                    chunk.setBlock(lx, y, lz, BlockType.DEAD_BUSH)
                } else if (u < 0.019) {
                    val cactusHeight = 1 + ((bits ushr 3) and 3) % 3
                    for (k in 0 until cactusHeight) chunk.setBlock(lx, y + k, lz, BlockType.CACTUS)
                }
            }
            else -> {}
        }
    }

    // ---- Trees ----------------------------------------------------------------------------

    private fun placeTrees(canvas: ChunkCanvas, baseX: Int, baseZ: Int) {
        val size = WorldConfig.CHUNK_SIZE
        val minCellX = Math.floorDiv(baseX - TREE_REACH, CELL)
        val maxCellX = Math.floorDiv(baseX + size - 1 + TREE_REACH, CELL)
        val minCellZ = Math.floorDiv(baseZ - TREE_REACH, CELL)
        val maxCellZ = Math.floorDiv(baseZ + size - 1 + TREE_REACH, CELL)

        for (cz in minCellZ..maxCellZ) {
            for (cx in minCellX..maxCellX) {
                // Deterministic per-4x4 cell: at most one tree candidate at a hash-chosen spot.
                val th = cellHash(cx, cz)
                val wx = cx * CELL + ((th ushr 8) and 3)
                val wz = cz * CELL + ((th ushr 10) and 3)
                if (wx < baseX - TREE_REACH || wx >= baseX + size + TREE_REACH) continue
                if (wz < baseZ - TREE_REACH || wz >= baseZ + size + TREE_REACH) continue

                val spot = treeSpot(cx, cz) ?: continue
                trees.grow(canvas, spot.species, spot.x, spot.z, spot.ground, spot.th)
            }
        }
    }

    /** A tree candidate that passed every check: where it stands and what it is. */
    class TreeSpot(val x: Int, val z: Int, val ground: Int, val species: TreeSpecies, val th: Int)

    /**
     * The tree (if any) of the 4x4 cell ([cx], [cz]) -- a pure function of the cell, used both
     * by the chunk generator and by the distant-terrain builder, so far-away trees stand exactly
     * where the real ones will grow.
     */
    fun treeSpot(cx: Int, cz: Int): TreeSpot? {
        val th = cellHash(cx, cz)
        val wx = cx * CELL + ((th ushr 8) and 3)
        val wz = cz * CELL + ((th ushr 10) and 3)
        val forest = forestFactor(wx, wz)
        val chance = 0.02 + 0.30 * forest * forest // sparse in open ground, thick in forests
        if ((th and 0xFF) >= (chance * 256.0).toInt()) return null // cheap early-out

        if (caves.nearMouth(wx.toDouble(), wz.toDouble())) return null // keep cave entrances clear

        // The ground under the trunk and the slope around it (which decides the biome) come from
        // the raw heights of a plus-shaped patch of up to 13 columns. surfaceHeight() and
        // biomeAtGround() would evaluate the height of 25 columns for the same answer (every one of
        // the four neighbouring surface heights re-samples its own four neighbours), and a column's
        // height is the most expensive thing in the generator, so each column of the patch is
        // sampled once. The centre column also hands over its base elevation (see
        // TerrainShape.heightAndCoast).
        val coastBox = DoubleArray(1)
        val c = floor(shape.heightAndCoast(wx.toDouble(), wz.toDouble(), 0, coastBox, 0)).toInt()
        val n = rawHeight(wx, wz - 1)
        val e = rawHeight(wx + 1, wz)
        val s = rawHeight(wx, wz + 1)
        val w = rawHeight(wx - 1, wz)
        val ground = despike(c, n, e, s, w)
        if (ground < WorldConfig.SEA_LEVEL) return null // shallows stay bare

        // The slope only matters on low ground right at the coast (the beach rule of
        // Climate.biome); everywhere else the other eight columns are not needed at all.
        var rise = 0
        if (climate.slopeMatters(ground.toDouble(), coastBox[0])) {
            val ne = rawHeight(wx + 1, wz - 1)
            val se = rawHeight(wx + 1, wz + 1)
            val nw = rawHeight(wx - 1, wz - 1)
            val sw = rawHeight(wx - 1, wz + 1)
            val ee = rawHeight(wx + 2, wz)
            val ww = rawHeight(wx - 2, wz)
            val ss = rawHeight(wx, wz + 2)
            val nn = rawHeight(wx, wz - 2)
            rise = max(
                abs(despike(e, ne, ee, se, c) - despike(w, nw, c, sw, ww)),
                abs(despike(s, c, se, ss, sw) - despike(n, nn, ne, c, nw))
            )
        }
        val biome = climate.biome(wx.toDouble(), wz.toDouble(), ground.toDouble(), rise * 0.5, coastBox[0])
        if (ground <= WorldConfig.SEA_LEVEL + 2 && biome != Biome.SWAMP) return null // so do beaches
        val density = treeDensity(biome)
        if (density <= 0.0 || (th and 0xFF) >= (chance * density * 256.0).toInt()) return null
        val species = pickSpecies(biome, ground, th) ?: return null
        return TreeSpot(wx, wz, ground, species, th)
    }

    /** Share of the forest-noise tree chance that survives in [biome] (0 = no trees). */
    fun treeDensity(biome: Biome): Double = when (biome) {
        Biome.FOREST, Biome.BIRCH_FOREST, Biome.TAIGA -> 1.0
        Biome.SNOWY_TAIGA -> 0.9
        Biome.MOUNTAINS -> 0.45
        Biome.SWAMP -> 0.55
        Biome.PLAINS -> 0.35
        Biome.SNOWY_PLAINS, Biome.SAVANNA -> 0.25
        else -> 0.0 // desert, shores, oceans, snowy peaks
    }

    /** Chance (0..1) that a 4x4 cell holds a tree, given the forest noise [forest] there. */
    fun treeChance(biome: Biome, forest: Double): Double = (0.02 + 0.30 * forest * forest) * treeDensity(biome)

    /** Which tree grows in [biome] for the hash roll in [th]. */
    private fun pickSpecies(biome: Biome, ground: Int, th: Int): TreeSpecies? {
        val roll = (th ushr 12) and 0xFF
        return when (biome) {
            Biome.FOREST -> if (roll < 200) TreeSpecies.OAK else TreeSpecies.BIRCH
            Biome.BIRCH_FOREST -> if (roll < 215) TreeSpecies.BIRCH else TreeSpecies.OAK
            Biome.PLAINS -> if (roll < 190) TreeSpecies.OAK else TreeSpecies.BIRCH
            Biome.SAVANNA -> TreeSpecies.OAK
            Biome.TAIGA -> if (roll < 235) TreeSpecies.SPRUCE else TreeSpecies.BIRCH
            Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS -> TreeSpecies.SPRUCE
            Biome.SWAMP -> TreeSpecies.OAK
            Biome.MOUNTAINS -> if (ground < WorldConfig.SEA_LEVEL + 55) TreeSpecies.SPRUCE else null
            else -> null
        }
    }

    private fun cellHash(x: Int, z: Int): Int {
        var h = x * 374761393 + z * 668265263 + seed.toInt() * 1274126177
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private fun hash3(x: Int, y: Int, z: Int): Int {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + seedMix
        h = (h xor (h ushr 13)) * -1028477387
        return h xor (h ushr 16)
    }

    private companion object {
        /** Placeholder for the "current sub-chunk array" before the first one is fetched. */
        val NO_BLOCKS = ByteArray(0)

        const val CELL = 4

        /** Widest a canopy ever reaches from its trunk, plus one block of slack. */
        const val TREE_REACH = 4

        /** Swamp ponds (and so lily pads) are at most this deep. */
        const val LILY_MAX_DEPTH = 5

        /** Seagrass grows on the bed where the water is between these depths. */
        const val SEAGRASS_MIN_DEPTH = 2
        const val SEAGRASS_MAX_DEPTH = 14

        /** Below about this Y the rock is dark deep stone; above ORE_MAX_Y no ore or pockets. */
        const val DEEP_STONE_Y = 24
        val ORE_MAX_Y: Int = WorldConfig.SEA_LEVEL + 30
        const val COAL_THRESHOLD = 0.84f
        const val POCKET_THRESHOLD = 0.78f

        /** Ore noise lattice: 8 x 8 cells of 2 blocks per chunk, ORE_LEVELS cells up to ORE_MAX_Y. */
        const val ORE_CELLS = 8
        const val ORE_LEVELS = 48

        const val SPAWN_STEP = 24
        const val SPAWN_MAX_RINGS = 120

        /** (dx, dz) pairs probed around a candidate spawn: all must be dry and level-ish. */
        val SPAWN_PROBES = intArrayOf(6, 0, -6, 0, 0, 6, 0, -6, 5, 5, -5, 5, 5, -5, -5, -5)
    }
}
