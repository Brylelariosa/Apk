package com.voxelsandbox.game.world

/**
 * Central sizing constants for the voxel world.
 *
 * The world is 256 blocks tall with sea level at 64. That is the vertical room a landscape
 * with real mountains and a real underground needs: ocean floors 40+ blocks under the
 * surface of the sea, 60 blocks of rock under the plains for cave systems to wind through,
 * and mountain ranges that climb 150+ blocks above the sea. Memory stays bounded because
 * (a) the mostly-empty upper sub-chunks of a chunk share one immutable all-air array and
 * (b) WorldManager caps how many chunks stay resident (see RESIDENT_BYTES_PER_CHUNK).
 */
object WorldConfig {
    const val CHUNK_SIZE = 16 // X/Z extent of a chunk
    const val SUBCHUNK_HEIGHT = 16
    const val SUBCHUNKS_PER_CHUNK = 16
    const val WORLD_HEIGHT = SUBCHUNK_HEIGHT * SUBCHUNKS_PER_CHUNK // 256

    const val SEA_LEVEL = 64

    const val BLOCKS_PER_SUBCHUNK = CHUNK_SIZE * SUBCHUNK_HEIGHT * CHUNK_SIZE // 4096
    const val BYTES_PER_CHUNK = CHUNK_SIZE * WORLD_HEIGHT * CHUNK_SIZE // 65536 (worst case)

    /**
     * Rough resident cost of one loaded chunk, used by WorldManager to turn the heap size
     * into a chunk budget. It covers the block data of the (typically 5-6) non-empty
     * sub-chunks plus the CPU-side mesh cache kept for every visible chunk, which is
     * several times larger than the raw blocks.
     */
    const val RESIDENT_BYTES_PER_CHUNK = 104 * 1024

    const val MAX_INTERACT_REACH = 6f

    /** Player falling below this Y (e.g. an unloaded/void column) is teleported back
     *  above the terrain rather than falling forever. */
    const val VOID_Y = -16f
}
