package com.voxelsandbox.game.world

import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.mesh.ChunkMesher
import com.voxelsandbox.game.world.mesh.MeshData
import com.voxelsandbox.game.world.streaming.ChunkPriority
import com.voxelsandbox.game.world.streaming.ColumnKeys
import com.voxelsandbox.game.world.streaming.DirectBufferPool
import com.voxelsandbox.game.world.streaming.JobPriority
import com.voxelsandbox.game.world.streaming.JobQueue
import com.voxelsandbox.game.world.streaming.MemoryPolicy
import com.voxelsandbox.game.world.streaming.MemoryProbe
import com.voxelsandbox.game.world.streaming.MeshStore
import com.voxelsandbox.game.world.streaming.ReadyRegions
import com.voxelsandbox.game.world.streaming.RegionPacker
import com.voxelsandbox.game.world.streaming.RuntimeMemoryProbe
import com.voxelsandbox.game.world.streaming.Viewpoint
import com.voxelsandbox.game.world.streaming.ViewpointTracker
import com.voxelsandbox.game.world.streaming.WorkBudget
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class ChunkStats(
    val loadedChunks: Int,
    val genQueueSize: Int,
    val meshQueueSize: Int,
    val chunkBudget: Int,
    /** Background-thread failures so far (generation, meshing, packing); 0 in a healthy run. */
    val failures: Int = 0,
    /** Chunks generated so far, and the column mesh jobs run for them: whole columns, and partial redos
     *  that rebuilt only some sub-chunks (those along an edge a late neighbour changed, or a player's edit).
     *  The generation halo (see [WorldManager]) is generated but never meshed, so a healthy stream runs one
     *  whole-column job per chunk of the ring, which is a little under one per generated chunk, and next to
     *  no partial redos (see [meshJobsPerChunk]). */
    val chunksGenerated: Long = 0L,
    val fullMeshJobs: Long = 0L,
    val partialMeshJobs: Long = 0L
) {
    /** Column mesh jobs (whole and partial) per generated chunk: about 0.9 with the halo (the halo chunks
     *  are generated and not meshed); before it the stream ran at 1.3 walking and 2.0 to 2.4 flying. */
    val meshJobsPerChunk: Float get() = if (chunksGenerated > 0L) (fullMeshJobs + partialMeshJobs).toFloat() / chunksGenerated else 0f
}

/**
 * Owns chunk lifecycle end-to-end: deciding which chunks should exist for the player's position
 * and render distance, generating and meshing them on background threads, packing the result
 * into upload buffers, and unloading chunks that fall out of range.
 *
 * Pipeline, per chunk:  generate -> (wait for the neighbours it is meshed against) -> mesh the
 * whole column in one job -> the column joins the [meshStore] -> its 4x4-column region is packed
 * into direct buffers -> the GL thread takes the packed region from [readyRegions] and uploads it.
 *
 * What makes terrain appear quickly while exploring:
 *  - One pool of worker threads takes the globally most urgent job, whatever its kind, from one
 *    queue ([JobQueue]). "Urgent" is [ChunkPriority]: nearest to the player first, ground in
 *    front of the camera and in the direction of travel before the rest, and the queue is
 *    re-ranked as the player moves (a plain priority queue keeps the order of the moment each
 *    job was queued, which is wrong within seconds of flying).
 *  - How many workers are awake follows the backlog and the frame pacing ([WorkBudget]).
 *  - A chunk is meshed once, after the neighbours it is generated against, instead of once now and
 *    again as each neighbour arrives. To make that true at the edge of the loaded area too, one extra
 *    ring is generated around it (the halo: the chunks that touch the ring from outside; block data
 *    only, never meshed or uploaded), so every chunk of the ring has all four neighbours. A neighbour
 *    that still arrives late (a failed generation, the memory budget) only redoes the sub-chunks that
 *    touch the shared edge ([Chunk.meshedWithNeighbors]). A chunk waiting for a neighbour that is
 *    queued pulls that neighbour forward, and waits longer when it is far from the player (the distant
 *    terrain shows there meanwhile).
 *  - A column is meshed in one job and handed over atomically, so a column never shows up
 *    half-built.
 *  - Packing the region buffers happens here, on the workers, not on the GL thread.
 *  - Nothing is lost silently: failures are logged and retried, and a column that cannot be
 *    built is accounted for as empty rather than leaving a permanent hole in the coverage.
 *
 * Player-driven edits (break/place) get top priority so they feel instant even while the
 * background streaming system is busy.
 *
 * GPU work cannot happen on these threads (only the GL thread owns the context), so finished work
 * is handed over through [readyRegions] / [pendingUnloads], which GameRenderer drains each frame.
 */
class WorldManager(
    private val world: World,
    private val generator: TerrainGenerator,
    private val atlas: TextureAtlas,
    private val savedChunkOverrides: Map<ChunkPos, ByteArray> = emptyMap()
) {
    // ---- jobs --------------------------------------------------------------------------

    private sealed class Work : JobQueue.Job()

    private class GenWork(val pos: ChunkPos, val speculative: Boolean) : Work() {
        override val key: Long = workKey(KIND_GEN, pos.x, pos.z)
    }

    private class MeshWork(val pos: ChunkPos, @JvmField var mask: Int, @JvmField var urgent: Boolean) : Work() {
        override val key: Long = workKey(KIND_MESH, pos.x, pos.z)
    }

    private class PackWork(val region: Long, @JvmField var urgent: Boolean) : Work() {
        override val key: Long = workKey(KIND_PACK, ColumnKeys.regionX(region), ColumnKeys.regionZ(region))
    }

    /** A region that has changed since it was last packed. */
    private class DirtyRegion(first: Long, last: Long, isUrgent: Boolean) {
        @Volatile @JvmField var firstNs: Long = first
        @Volatile @JvmField var lastNs: Long = last
        @Volatile @JvmField var urgent: Boolean = isUrgent
        @Volatile @JvmField var queued: Boolean = false
    }

    private val chunkStates = ConcurrentHashMap<ChunkPos, ChunkState>()
    private val queue = JobQueue<Work>()

    /** Regions being packed right now. A region is packed by one worker at a time: a second pack of it
     *  would only repeat the first one's work, and the older of two could finish last (the sequence
     *  numbers on the packs, see PackedRegion.sequence, make that harmless, but it is still wasted work). */
    private val packing = ConcurrentHashMap.newKeySet<Long>()

    /** Chunks that are generated but not yet meshed because a neighbour is still being made:
     *  column key -> when they started waiting. */
    private val waiting = ConcurrentHashMap<Long, Long>()
    private val dirtyRegions = ConcurrentHashMap<Long, DirtyRegion>()

    // One mesh job per column at a time: later requests for a column that is being meshed are
    // remembered and run when the current job finishes.
    private val meshLock = Any()
    private val activeMesh = HashSet<Long>()
    private val deferredMask = HashMap<Long, Int>()
    private val deferredUrgent = HashSet<Long>()

    // Held while a finished mesh is published or a column is unloaded, so an unload can never be
    // followed by a stale mesh of the same chunk reappearing in the store.
    private val storeLock = Any()

    private val genFailures = ConcurrentHashMap<ChunkPos, Int>()
    private val genRetryAtMs = ConcurrentHashMap<ChunkPos, Long>()
    private val meshFailures = ConcurrentHashMap<Long, Int>()

    // ---- failures -------------------------------------------------------------------------

    private val failureCounter = java.util.concurrent.atomic.AtomicInteger()
    private val generatedCounter = java.util.concurrent.atomic.AtomicLong()
    private val fullMeshCounter = java.util.concurrent.atomic.AtomicLong()
    private val partialMeshCounter = java.util.concurrent.atomic.AtomicLong()

    /** What the most recent background failure was, e.g. "gen: chunk (3, 4) failed (1): ...". */
    @Volatile var lastFailure: String? = null
        private set

    /** Counts a failure of a background job and reports it to the diagnostics log. The count and
     *  [lastFailure] are kept even when diagnostics are off, so a problem is never invisible. */
    private fun noteFailure(source: String, text: String, cause: Throwable? = null) {
        failureCounter.incrementAndGet()
        lastFailure = "$source: $text"
        DiagLog.error(source, text)
        // Running out of heap is the one failure that is not about the job: shrink what is kept loaded.
        if (cause is OutOfMemoryError) memoryPolicy.onOutOfMemory(System.currentTimeMillis())
    }

    // ---- hand-off to the renderer ---------------------------------------------------------

    /** CPU-side meshes of every loaded column; the source regions are packed from. */
    val meshStore = MeshStore()
    val bufferPool = DirectBufferPool()
    private val packer = RegionPacker(bufferPool)

    /** Packed regions waiting for the GL thread (GameRenderer.drainMeshUploads takes them). */
    val readyRegions = ReadyRegions(bufferPool)

    /** Chunks that were unloaded; the renderer forgets their coverage. */
    val pendingUnloads = LinkedBlockingQueue<ChunkPos>()

    /** What this device's heap can keep resident (see [computeChunkBudget]); fixed for the session. */
    private val baseChunkBudget: Int = computeChunkBudget()

    /** How much of that budget may be used right now: 1 normally, a little less while memory really
     *  is short (see [MemoryPolicy]). It moves slowly in both directions, so the loaded area recedes
     *  and returns gradually instead of snapping in and out. */
    private val memoryPolicy = MemoryPolicy()

    /** Where memory readings come from. The default sees the heap only; the activity installs one that
     *  also sees the system's figures (see AndroidMemoryProbe). */
    @Volatile var memoryProbe: MemoryProbe = RuntimeMemoryProbe

    /** Share of the chunk (and distant-terrain) memory budget in use right now (see [MemoryPolicy]). */
    val memoryFactor: Float get() = memoryPolicy.factor

    /** How many chunks may be meshed and shown right now: the memory budget, cut a little while memory is
     *  short. (The generation halo, one chunk wide, is on top of it: block data only, a few MB, and the
     *  per-chunk figure the budget is made from is larger than a chunk really costs.) Lowering it unloads
     *  the farthest chunks (the wanted set shrinks and everything outside it goes after a short
     *  hysteresis); it grows back slowly once memory is no longer short. */
    val maxLoadedChunks: Int
        get() = max(MIN_CHUNK_BUDGET, (baseChunkBudget * memoryPolicy.factor).toInt())

    /**
     * The OS is asking apps to give memory back (ComponentCallbacks2.onTrimMemory level). Cached
     * buffers are dropped; the loaded area is touched only if a fresh reading shows that memory really
     * is short, or the app is in the background (see [MemoryPolicy.onTrim]).
     */
    fun onMemoryPressure(level: Int) {
        val reading = try {
            memoryProbe.read()
        } catch (t: Throwable) {
            null
        }
        memoryPolicy.onTrim(level, reading, System.currentTimeMillis())
        DiagLog.note(
            "OS memory callback ($level): " + (if (reading != null) {
                "heap " + (reading.heapUsed shr 20) + "/" + (reading.heapMax shr 20) + " MB" +
                    (if (reading.systemAvailable >= 0L) ", system free " + (reading.systemAvailable shr 20) + " MB" else "") +
                    (if (reading.systemLow) ", system low" else "")
            } else "no reading")
        )
    }

    // ---- player state ---------------------------------------------------------------------

    private val viewTracker = ViewpointTracker()
    @Volatile private var renderDistance = 8
    @Volatile private var lastSchedCenter: ChunkPos? = null
    @Volatile private var lastSchedRadius: Int = -1
    @Volatile private var lastSchedLimit: Int = -1

    /** The chunks that are meshed and shown: the nearest [maxLoadedChunks] of the render disc, as of the
     *  scheduler's last pass. Replaced as a whole (never edited), so the workers can read it freely. */
    @Volatile private var meshRing: Set<ChunkPos> = emptySet()

    /** [meshRing] plus its halo: every chunk that touches it. The halo is generated, but not meshed, so
     *  that each chunk of the ring is meshed once, against neighbours that are really there, instead of
     *  against "solid" first and then again when the neighbour arrives (see [neighboursSettled]). */
    @Volatile private var genRing: Set<ChunkPos> = emptySet()

    /** Set by the engine every frame: is the player's eye in water / under the ground? The hidden
     *  geometry (deep sea floor, cave walls) is only meshed while the matching one is true. */
    @Volatile var playerUnderwater: Boolean = false
    @Volatile var playerUnderground: Boolean = false

    // The deep geometry stays wanted until this wall-clock time (a grace period after the player
    // leaves the water / the cave, so popping up for a moment does not throw it all away).
    @Volatile private var deepModeUntilMs = 0L
    @Volatile private var seabedModeUntilMs = 0L
    private var lastModeUnderground = false // scheduler thread only
    private var lastModeUnderwater = false

    // ---- threads --------------------------------------------------------------------------

    @Volatile private var running = false
    private val maxWorkers = max(2, min(MAX_WORKER_THREADS, Runtime.getRuntime().availableProcessors() - 2))
    private val budget = WorkBudget(maxWorkers)
    private val threads = ArrayList<Thread>()

    /** Streaming work is latency-tolerant, so these threads run just below background priority:
     *  still in the foreground cpu group (so they cannot be starved to a crawl) but with a much
     *  lower scheduling weight than the render and UI threads. */
    private fun runAsBackgroundWorker() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // Best effort only: if a ROM refuses the change the game just runs as before.
        }
    }

    fun start() {
        if (running) return
        running = true
        repeat(maxWorkers) { i ->
            Thread({ workerLoop(i) }, "voxel-worker-$i").apply { isDaemon = true; start() }.also { threads.add(it) }
        }
        Thread({ schedulerLoop() }, "voxel-scheduler").apply { isDaemon = true; start() }.also { threads.add(it) }
    }

    fun shutdown() {
        running = false
        threads.forEach { it.interrupt() }
        threads.clear()
        queue.clear()
        readyRegions.clear()
    }

    /** Cheap: just records the latest position/setting for the scheduler thread to pick up. Safe
     *  to call every frame from the game loop. [yawRad] is the camera's yaw (0 looks down -Z). */
    fun updatePlayerPosition(x: Float, z: Float, renderDistanceChunks: Int, yawRad: Float) {
        viewTracker.update(x, z, yawRad, System.nanoTime())
        // Any Int is survivable here: the radius is only ever used through the memory budget
        // (ChunkRing.offsets(radius, maxLoadedChunks)), but a wild value must not reach other maths.
        renderDistance = renderDistanceChunks.coerceIn(0, MAX_STREAM_RADIUS)
    }

    /** Called by the GL thread once per frame so the work budgets can follow the frame pacing. */
    fun reportFrameTime(frameMs: Float) = budget.reportFrame(frameMs)

    /** Bytes of packed mesh data the GL thread may upload this frame (see [WorkBudget]). */
    fun uploadBytesPerFrame(): Int = budget.uploadBytesPerFrame()
    fun uploadNanosPerFrame(): Long = budget.uploadNanosPerFrame()

    fun stats(): ChunkStats {
        val gen = queue.countWhere { it is GenWork }
        val rest = queue.size - gen
        return ChunkStats(
            world.chunkCount(), gen, max(0, rest), maxLoadedChunks, failureCounter.get(),
            generatedCounter.get(), fullMeshCounter.get(), partialMeshCounter.get()
        )
    }

    /** The full-detail chunk radius currently being maintained around the player. */
    val activeRadius: Int get() = renderDistance

    fun isChunkGenerated(pos: ChunkPos): Boolean = chunkStates[pos] == ChunkState.GENERATED

    /** Forces a chunk to the very front of the generation queue. Used once at world
     *  start/load so the spawn column is ready quickly instead of waiting its turn. */
    fun requestImmediateChunk(pos: ChunkPos) {
        // Until the game starts reporting the player's position, rank everything around the chunk
        // that was asked for (the spawn), not around the world origin.
        if (viewTracker.current === Viewpoint.ORIGIN) {
            viewTracker.update((pos.x + 0.5f) * WorldConfig.CHUNK_SIZE, (pos.z + 0.5f) * WorldConfig.CHUNK_SIZE, 0f, System.nanoTime())
        }
        if ((chunkStates[pos] ?: ChunkState.UNLOADED) == ChunkState.UNLOADED) {
            chunkStates[pos] = ChunkState.QUEUED
            queue.submit(GenWork(pos, false).also { it.priority = JobPriority.URGENT })
        }
    }

    // ---- edits ----------------------------------------------------------------------------

    /** Applies a player-driven block edit and schedules the minimal set of remeshes (this
     *  sub-chunk, plus neighbours across any boundary the edit touched) at top priority. */
    fun setBlockAndRemesh(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (!world.setBlock(x, y, z, type)) return false
        markDirtyAround(x, y, z)
        return true
    }

    // Batched edits (creative laser, fluids): the touched sub-chunks are collected per column
    // (each only once) and queued by [flushBatchedEdits]. Game thread only.
    private val batchDirty = HashMap<Long, Int>()

    /** Like [setBlockAndRemesh] but for thousands of edits in a row. */
    fun setBlockBatched(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (!world.setBlock(x, y, z, type)) return false
        noteBlockChanged(x, y, z)
        return true
    }

    /** Records that the block at (x, y, z) has just been changed (the caller already wrote it,
     *  e.g. the fluid simulator through World.setRaw) so that [flushBatchedEdits] will remesh the
     *  sub-chunk and any neighbour the change touches. Game thread only. */
    fun noteBlockChanged(x: Int, y: Int, z: Int) {
        val cs = WorldConfig.CHUNK_SIZE
        val sh = WorldConfig.SUBCHUNK_HEIGHT
        val cx = Math.floorDiv(x, cs)
        val cz = Math.floorDiv(z, cs)
        val lx = Math.floorMod(x, cs)
        val lz = Math.floorMod(z, cs)
        val subY = (y / sh).coerceIn(0, WorldConfig.SUBCHUNKS_PER_CHUNK - 1)
        val ly = y % sh
        addDirty(cx, cz, subY)
        if (lx == 0) addDirty(cx - 1, cz, subY)
        if (lx == cs - 1) addDirty(cx + 1, cz, subY)
        if (lz == 0) addDirty(cx, cz - 1, subY)
        if (lz == cs - 1) addDirty(cx, cz + 1, subY)
        if (ly == 0 && subY > 0) addDirty(cx, cz, subY - 1)
        if (ly == sh - 1 && subY < WorldConfig.SUBCHUNKS_PER_CHUNK - 1) addDirty(cx, cz, subY + 1)
    }

    private fun addDirty(cx: Int, cz: Int, subY: Int) {
        val key = ColumnKeys.column(cx, cz)
        batchDirty[key] = (batchDirty[key] ?: 0) or (1 shl subY)
    }

    /** Queues the remesh of everything touched by [setBlockBatched] / [noteBlockChanged] since the
     *  last flush. [priority] Long.MIN_VALUE (the default) means "urgent": the renderer uploads the
     *  result the very frame it arrives. The fluid simulator passes a normal priority instead, so a
     *  spreading flood never competes with the player's own edits and is batched like streaming. */
    fun flushBatchedEdits(priority: Long = Long.MIN_VALUE) {
        if (batchDirty.isEmpty()) return
        val urgent = priority == Long.MIN_VALUE
        for ((key, mask) in batchDirty) {
            val pos = ChunkPos(ColumnKeys.columnX(key), ColumnKeys.columnZ(key))
            if (chunkStates[pos] == ChunkState.GENERATED) requestMesh(pos, mask, urgent)
        }
        batchDirty.clear()
    }

    private fun markDirtyAround(x: Int, y: Int, z: Int) {
        val cx = Math.floorDiv(x, WorldConfig.CHUNK_SIZE)
        val cz = Math.floorDiv(z, WorldConfig.CHUNK_SIZE)
        val lx = Math.floorMod(x, WorldConfig.CHUNK_SIZE)
        val lz = Math.floorMod(z, WorldConfig.CHUNK_SIZE)
        val subY = (y / WorldConfig.SUBCHUNK_HEIGHT).coerceIn(0, WorldConfig.SUBCHUNKS_PER_CHUNK - 1)
        val ly = y % WorldConfig.SUBCHUNK_HEIGHT

        editMesh(cx, cz, subY)
        if (lx == 0) editMesh(cx - 1, cz, subY)
        if (lx == WorldConfig.CHUNK_SIZE - 1) editMesh(cx + 1, cz, subY)
        if (lz == 0) editMesh(cx, cz - 1, subY)
        if (lz == WorldConfig.CHUNK_SIZE - 1) editMesh(cx, cz + 1, subY)
        if (ly == 0 && subY > 0) editMesh(cx, cz, subY - 1)
        if (ly == WorldConfig.SUBCHUNK_HEIGHT - 1 && subY < WorldConfig.SUBCHUNKS_PER_CHUNK - 1) editMesh(cx, cz, subY + 1)
    }

    private fun editMesh(cx: Int, cz: Int, subY: Int) {
        val pos = ChunkPos(cx, cz)
        if (chunkStates[pos] == ChunkState.GENERATED) requestMesh(pos, 1 shl subY, true)
    }

    // ---- scheduler: decides the wanted chunk set and drives load/unload ---------------------

    private fun schedulerLoop() {
        runAsBackgroundWorker()
        var lastRebuildMs = 0L
        var lastRankMs = 0L
        var lastBudgetMs = 0L
        var lastMemoryMs = 0L
        var lastLoggedFactor = 1f
        var rankedAt: Viewpoint = viewTracker.current
        while (running) {
            try {
                val nowMs = System.currentTimeMillis()
                val view = viewTracker.current
                val center = ChunkPos.fromWorld(view.x, view.z)
                val radius = renderDistance

                // Re-run whenever EITHER the centre or the radius changes (changing the radius
                // while standing still, the normal way to change it, must take effect at once).
                // The periodic re-run is a safety net: any chunk whose generation failed or got
                // cancelled mid-flight is simply re-queued, so a hole can never be permanent.
                val underground = playerUnderground
                val underwater = playerUnderwater
                if (underground) deepModeUntilMs = nowMs + DEEP_GRACE_MS
                if (underwater) seabedModeUntilMs = nowMs + DEEP_GRACE_MS
                val modeChanged = underground != lastModeUnderground || underwater != lastModeUnderwater
                lastModeUnderground = underground
                lastModeUnderwater = underwater
                // The memory budget follows the evidence; a change in it moves the edge of the wanted set.
                if (nowMs - lastMemoryMs >= MEMORY_SAMPLE_MS) {
                    lastMemoryMs = nowMs
                    try {
                        memoryPolicy.onReading(memoryProbe.read(), nowMs)
                    } catch (t: Throwable) {
                        // A probe that fails just leaves the previous reading in place.
                    }
                }
                memoryPolicy.update(nowMs)
                if (memoryPolicy.consumeTrimRequest()) bufferPool.trim(POOL_KEEP_ON_TRIM)
                val limit = maxLoadedChunks
                val budgetMoved = limit != lastSchedLimit && nowMs - lastRebuildMs >= BUDGET_REBUILD_MS
                if (abs(memoryPolicy.factor - lastLoggedFactor) >= 0.05f) {
                    lastLoggedFactor = memoryPolicy.factor
                    DiagLog.note(
                        "chunk budget " + limit + " of " + baseChunkBudget + " (" + (memoryPolicy.factor * 100f).toInt() + "%)" +
                            (if (memoryPolicy.reason.isNotEmpty()) ": " + memoryPolicy.reason else ": memory no longer short")
                    )
                }

                if (center != lastSchedCenter || radius != lastSchedRadius || modeChanged || budgetMoved || nowMs - lastRebuildMs > REBUILD_INTERVAL_MS) {
                    lastSchedCenter = center
                    lastSchedRadius = radius
                    lastRebuildMs = nowMs
                    lastSchedLimit = limit
                    rebuildWantedSet(center, radius, view)
                }

                // Re-rank what is waiting once the player has moved or turned noticeably.
                if (nowMs - lastRankMs >= RERANK_MIN_INTERVAL_MS && needsRerank(rankedAt, view)) {
                    lastRankMs = nowMs
                    rankedAt = view
                    rerank(view)
                }

                releaseWaitingChunks(System.nanoTime())
                dispatchPacks(System.nanoTime())

                if (nowMs - lastBudgetMs >= 100L) {
                    lastBudgetMs = nowMs
                    budget.update(queue.size, nowMs)
                }
                Thread.sleep(TICK_MS)
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                noteFailure("scheduler", "tick failed: $t", t)
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    private fun needsRerank(old: Viewpoint, now: Viewpoint): Boolean {
        val dx = now.x - old.x
        val dz = now.z - old.z
        if (dx * dx + dz * dz > RERANK_MOVE_BLOCKS * RERANK_MOVE_BLOCKS) return true
        // Angle between the two look directions (they are unit vectors).
        val cos = now.lookX * old.lookX + now.lookZ * old.lookZ
        return cos < RERANK_TURN_COS
    }

    private fun rerank(view: Viewpoint) {
        queue.reprioritize { job -> rankOf(job, view) }
    }

    private fun rankOf(job: Work, view: Viewpoint): Long = when (job) {
        is GenWork -> {
            var p = ChunkPriority.score(job.pos.x, job.pos.z, view)
            // A generated chunk waiting for this one is meshed the moment this one is done, so
            // this one ranks just behind the waiting one.
            for (i in 0 until 4) {
                val nx = job.pos.x + SIDE_DX[i]
                val nz = job.pos.z + SIDE_DZ[i]
                if (waiting.containsKey(ColumnKeys.column(nx, nz))) {
                    val pull = ChunkPriority.score(nx, nz, view) + 1
                    if (pull < p) p = pull
                }
            }
            if (job.speculative) p + JobPriority.SPECULATIVE_BIAS else p
        }
        is MeshWork -> if (job.urgent) JobPriority.URGENT else ChunkPriority.score(job.pos.x, job.pos.z, view) + JobPriority.MESH_BIAS
        is PackWork -> if (job.urgent) JobPriority.URGENT else regionPriority(job.region, view)
    }

    private fun regionPriority(region: Long, view: Viewpoint): Long {
        val half = ColumnKeys.REGION_SIZE * 0.5f
        val cx = ColumnKeys.regionX(region) * ColumnKeys.REGION_SIZE + half
        val cz = ColumnKeys.regionZ(region) * ColumnKeys.REGION_SIZE + half
        return JobPriority.PACK_BIAS + ChunkPriority.scoreAt(cx, cz, view)
    }

    private fun rebuildWantedSet(center: ChunkPos, radius: Int, view: Viewpoint) {
        val limit = maxLoadedChunks // read once: the budget can change under memory pressure
        val offsets = ChunkRing.offsets(radius, limit)
        val cap = min(offsets.size, limit)
        val wanted = HashSet<ChunkPos>(cap * 2)
        for (i in 0 until cap) {
            val o = offsets[i]
            wanted.add(ChunkPos(center.x + o[0], center.z + o[1]))
        }

        // The halo: every chunk that touches the ring from outside. It is generated but not meshed, so
        // a chunk at the edge of the ring is meshed once, with all four neighbours really there, rather
        // than against "solid" first and then again as each neighbour arrives. It costs one extra ring
        // of block data (no meshes, nothing on the GPU) and moves with the player, so a chunk the ring
        // reaches has already been generated and only needs meshing.
        val halo = HashSet<ChunkPos>()
        for (pos in wanted) {
            for (i in 0 until 4) {
                val next = ChunkPos(pos.x + SIDE_DX[i], pos.z + SIDE_DZ[i])
                if (!wanted.contains(next)) halo.add(next)
            }
        }
        val ring = HashSet<ChunkPos>(wanted.size + halo.size)
        ring.addAll(wanted)
        ring.addAll(halo)
        // Published before anything is queued, so a worker that finishes a chunk already knows which
        // chunks are meant to exist and which of them are to be meshed.
        meshRing = wanted
        genRing = ring

        val nowMs = System.currentTimeMillis()
        // Nearest first, so the queue order of equal priorities follows the ring.
        for (i in 0 until cap) {
            val o = offsets[i]
            queueGeneration(ChunkPos(center.x + o[0], center.z + o[1]), false, view, nowMs)
        }
        for (pos in halo) queueGeneration(pos, false, view, nowMs)

        // The unload boundary must track whichever constraint is tighter right now: the radius
        // setting, or the memory budget cutting the wanted set off earlier. A little hysteresis
        // beyond the generated edge (the halo) avoids thrashing chunks right at the boundary in and
        // out of existence.
        val cutoffDistSq = if (cap > 0) {
            val o = offsets[cap - 1]
            (o[0] * o[0] + o[1] * o[1]).toLong()
        } else 0L
        val cutoffDist = sqrt(cutoffDistSq.toDouble())
        val hysteresisDist = cutoffDist + HALO_REACH + UNLOAD_HYSTERESIS
        val hysteresisDistSq = (hysteresisDist * hysteresisDist).toLong()

        // While the player is moving, start on the first rows of chunks just beyond the halo in the
        // direction of travel, so they already exist when the ring reaches them. They only run when
        // nothing more urgent is waiting and stay inside the hysteresis band.
        if (cap == offsets.size && view.speed >= LOOKAHEAD_MIN_SPEED) {
            var queued = 0
            val outer = cutoffDist + HALO_REACH + LOOKAHEAD_DEPTH
            val reach = ceilToInt(outer)
            for (dx in -reach..reach) {
                for (dz in -reach..reach) {
                    val d2 = dx * dx + dz * dz
                    if (d2 <= cutoffDistSq) continue
                    val d = sqrt(d2.toDouble())
                    if (d > outer) continue
                    val cosMove = (dx * view.dirX + dz * view.dirZ) / d
                    if (cosMove < LOOKAHEAD_CONE_COS) continue
                    val pos = ChunkPos(center.x + dx, center.z + dz)
                    if (ring.contains(pos)) continue
                    if (queueGeneration(pos, true, view, nowMs) && ++queued >= LOOKAHEAD_MAX_CHUNKS) break
                }
                if (queued >= LOOKAHEAD_MAX_CHUNKS) break
            }
        }

        val toUnload = ArrayList<ChunkPos>()
        for (pos in chunkStates.keys) {
            if (ring.contains(pos)) continue
            if (pos.distanceSquaredTo(center) > hysteresisDistSq) toUnload.add(pos)
        }
        for (pos in toUnload) unloadChunk(pos)

        // Chunks that were generated before the ring reached them (the halo, the look-ahead) are meshed
        // now. This is also the safety net for any chunk whose mesh was never requested.
        for (pos in wanted) {
            if (chunkStates[pos] != ChunkState.GENERATED) continue
            val chunk = world.getChunk(pos) ?: continue
            if (chunk.meshedWithNeighbors == Chunk.NEVER_MESHED && !queue.contains(workKey(KIND_MESH, pos.x, pos.z))) evaluateMesh(pos)
        }

        refreshDeepMeshing(center)
    }

    /** Queues the generation of [pos] unless it is already loaded or queued, or is backing off after a
     *  failure. True if it was queued. */
    private fun queueGeneration(pos: ChunkPos, speculative: Boolean, view: Viewpoint, nowMs: Long): Boolean {
        if ((chunkStates[pos] ?: ChunkState.UNLOADED) != ChunkState.UNLOADED) return false
        val retryAt = genRetryAtMs[pos]
        if (retryAt != null && nowMs < retryAt) return false
        chunkStates[pos] = ChunkState.QUEUED
        val priority = ChunkPriority.score(pos.x, pos.z, view)
        queue.submit(GenWork(pos, speculative).also { it.priority = if (speculative) priority + JobPriority.SPECULATIVE_BIAS else priority })
        return true
    }

    private fun ceilToInt(v: Double): Int {
        val i = v.toInt()
        return if (i < v) i + 1 else i
    }

    /**
     * The "deep" faces of a chunk cannot be seen from outside: the walls of caves, and the floor
     * of the sea under 10+ blocks of water (hidden by water that is 93% opaque by then). So they
     * are meshed only when they can matter -- cave walls while the player is underground, the sea
     * floor while the player is underwater, both only for chunks near the player (see [wantsDeep],
     * [wantsSeabed]) -- plus, always, for chunks with a cave mouth (so a distant cave entrance is
     * dark rock, not a see-through hole) and for chunks the player has edited. That keeps the whole
     * hidden underground and the deep ocean bed out of memory, off the GPU and out of the way of
     * the normal case of walking or flying over the surface. When the mode changes or the player
     * moves, this re-queues the chunks whose state is no longer right.
     */
    private fun refreshDeepMeshing(center: ChunkPos) {
        for (chunk in world.allChunks()) {
            val deepOff = chunk.deepCapable && wantsDeep(chunk) != chunk.deepIncluded
            val seabedOff = chunk.seabedCapable && wantsSeabed(chunk) != chunk.seabedIncluded
            if (!deepOff && !seabedOff) continue
            if (chunkStates[chunk.pos] != ChunkState.GENERATED) continue
            requestMesh(chunk.pos, FULL_MASK, false)
        }
    }

    /** Should [chunk]'s next mesh include its cave faces? Only underground (or just after), near
     *  the player, with some hysteresis so a chunk on the boundary does not flip back and forth. */
    private fun wantsDeep(chunk: Chunk): Boolean {
        if (chunk.caveMouth || chunk.hasPlayerEdits) return true
        if (System.currentTimeMillis() >= deepModeUntilMs) return false
        val center = lastSchedCenter ?: return false
        val r = if (chunk.deepIncluded) DEEP_KEEP_RADIUS else DEEP_RADIUS
        return chunk.pos.distanceSquaredTo(center) <= r.toLong() * r
    }

    /** Should [chunk]'s next mesh include the deep sea floor? Only while diving (or just after),
     *  right around the player: underwater the fog ends within about 26 blocks. */
    private fun wantsSeabed(chunk: Chunk): Boolean {
        if (chunk.hasPlayerEdits) return true
        if (System.currentTimeMillis() >= seabedModeUntilMs) return false
        val center = lastSchedCenter ?: return false
        val r = if (chunk.seabedIncluded) SEABED_KEEP_RADIUS else SEABED_RADIUS
        return chunk.pos.distanceSquaredTo(center) <= r.toLong() * r
    }

    private fun unloadChunk(pos: ChunkPos) {
        chunkStates[pos] = ChunkState.UNLOADING
        world.removeChunk(pos)
        chunkStates.remove(pos)
        queue.remove(workKey(KIND_GEN, pos.x, pos.z))
        queue.remove(workKey(KIND_MESH, pos.x, pos.z))
        val column = ColumnKeys.column(pos.x, pos.z)
        waiting.remove(column)
        meshFailures.remove(column)
        genFailures.remove(pos)
        genRetryAtMs.remove(pos)
        synchronized(storeLock) { meshStore.remove(column) }
        markRegionDirty(ColumnKeys.regionOfColumn(column), false)
        pendingUnloads.put(pos)
    }

    // ---- workers --------------------------------------------------------------------------

    private fun workerLoop(index: Int) {
        runAsBackgroundWorker()
        while (running) {
            if (index >= budget.activeWorkers) {
                try {
                    Thread.sleep(PARK_MS)
                } catch (e: InterruptedException) {
                    return
                }
                continue
            }
            val job = try {
                queue.take()
            } catch (e: InterruptedException) {
                return
            }
            try {
                when (job) {
                    is GenWork -> runGen(job)
                    is MeshWork -> runMesh(job)
                    is PackWork -> runPack(job)
                }
            } catch (t: Throwable) {
                noteFailure("worker", "${job.javaClass.simpleName} failed: $t", t)
            }
        }
    }

    // ---- generation -----------------------------------------------------------------------

    private fun runGen(job: GenWork) {
        val pos = job.pos
        if (chunkStates[pos] != ChunkState.QUEUED) return // cancelled/obsolete
        chunkStates[pos] = ChunkState.GENERATING

        val startNs = if (DiagLog.isActive()) System.nanoTime() else 0L
        val chunk = try {
            val override = savedChunkOverrides[pos]
            if (override != null) {
                Chunk(pos).apply {
                    deserializeBlocks(override)
                    hasPlayerEdits = true
                }
            } else {
                generator.generate(pos)
            }
        } catch (t: Throwable) {
            onGenerationFailed(pos, t)
            return
        }
        if (startNs != 0L) DiagLog.chunkGen((System.nanoTime() - startNs) / 1_000_000f)
        if (chunkStates[pos] != ChunkState.GENERATING) return // unloaded mid-generation

        installChunk(chunk)
    }

    private fun installChunk(chunk: Chunk) {
        val pos = chunk.pos
        world.putChunk(chunk)
        generatedCounter.incrementAndGet()
        chunkStates[pos] = ChunkState.GENERATED
        genFailures.remove(pos)
        genRetryAtMs.remove(pos)
        onChunkGenerated(pos)
    }

    /** A failed generation used to vanish without a trace and leave the chunk as a permanent hole
     *  (and, through the fog, shorten the whole view). Now it is logged and retried a few times,
     *  and if it keeps failing the chunk is replaced by an empty one so the area still counts as
     *  loaded. */
    private fun onGenerationFailed(pos: ChunkPos, t: Throwable) {
        val failures = (genFailures[pos] ?: 0) + 1
        genFailures[pos] = failures
        noteFailure("gen", "chunk (${pos.x}, ${pos.z}) failed ($failures): $t", t)
        if (failures >= MAX_ATTEMPTS) {
            if (chunkStates[pos] == ChunkState.GENERATING) installChunk(Chunk(pos))
            return
        }
        genRetryAtMs[pos] = System.currentTimeMillis() + 400L * failures
        chunkStates.remove(pos) // the next scheduler pass queues it again
    }

    private fun onChunkGenerated(pos: ChunkPos) {
        evaluateMesh(pos)
        // A neighbour that was meshed while this chunk was missing treated it as solid: the faces
        // along the shared edge need redoing, but only in the sub-chunks that touch that edge. One
        // that was meshed after this chunk was already there needs nothing; one still waiting for
        // this chunk can go now.
        for (i in 0 until 4) {
            val npos = ChunkPos(pos.x + SIDE_DX[i], pos.z + SIDE_DZ[i])
            if (chunkStates[npos] != ChunkState.GENERATED) continue
            val neighbour = world.getChunk(npos) ?: continue
            val bits = neighbour.meshedWithNeighbors
            if (bits == Chunk.NEVER_MESHED) {
                evaluateMesh(npos)
            } else {
                val towardsNew = OPPOSITE[i]
                if (bits and (1 shl towardsNew) == 0) {
                    val mask = boundaryMask(neighbour, towardsNew)
                    if (mask != 0) requestMesh(npos, mask, false)
                }
            }
        }
    }

    /** Which sub-chunks of [chunk] have any block in the layer of cells along the edge facing
     *  [side] (0 = x-1, 1 = x+1, 2 = z-1, 3 = z+1): only those can look different once the chunk on
     *  that side exists. */
    private fun boundaryMask(chunk: Chunk, side: Int): Int {
        val cs = WorldConfig.CHUNK_SIZE
        val sh = WorldConfig.SUBCHUNK_HEIGHT
        var mask = 0
        for (s in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
            val sub = chunk.subChunks[s]
            if (sub.isAllAir()) continue
            val blocks = sub.blocks
            var any = false
            scan@ for (ly in 0 until sh) {
                for (t in 0 until cs) {
                    val lx = if (side == 0) 0 else if (side == 1) cs - 1 else t
                    val lz = if (side == 2) 0 else if (side == 3) cs - 1 else t
                    if (blocks[SubChunk.index(lx, ly, lz)].toInt() != 0) {
                        any = true
                        break@scan
                    }
                }
            }
            if (any) mask = mask or (1 shl s)
        }
        return mask
    }

    // ---- meshing --------------------------------------------------------------------------

    /** True when none of the four neighbours of [pos] is still to come: each is generated, or is not
     *  meant to exist (outside the ring and its halo), in which case it is not waited for. Every
     *  neighbour of a chunk of the ring is in the ring or its halo, so a chunk of the ring is meshed
     *  against real neighbours; only a neighbour whose generation failed (or the memory budget cut
     *  off) can still arrive late, and [releaseWaitingChunks] stops waiting for it after a while. */
    private fun neighboursSettled(pos: ChunkPos): Boolean {
        for (i in 0 until 4) {
            val next = ChunkPos(pos.x + SIDE_DX[i], pos.z + SIDE_DZ[i])
            when (chunkStates[next]) {
                ChunkState.GENERATED -> {}
                ChunkState.QUEUED, ChunkState.GENERATING -> return false
                // Not queued (yet, or it failed and is backing off): only worth waiting for if it is meant to exist.
                else -> if (genRing.contains(next)) return false
            }
        }
        return true
    }

    private fun neighbourBits(pos: ChunkPos): Int {
        var bits = 0
        for (i in 0 until 4) if (world.getChunkAt(pos.x + SIDE_DX[i], pos.z + SIDE_DZ[i]) != null) bits = bits or (1 shl i)
        return bits
    }

    /** Meshes [pos] now if its neighbours are settled, otherwise lets it wait (briefly). A chunk that
     *  is outside the ring (the halo, the look-ahead) is generated for its neighbours' sake and is
     *  not meshed until the ring reaches it. */
    private fun evaluateMesh(pos: ChunkPos) {
        if (chunkStates[pos] != ChunkState.GENERATED) return
        if (!meshRing.contains(pos)) return
        val column = ColumnKeys.column(pos.x, pos.z)
        if (neighboursSettled(pos)) {
            // Whoever takes the chunk out of the waiting list is the one that asks for its mesh; if the
            // scheduler got there first, it has already asked.
            if (waiting.containsKey(column) && waiting.remove(column) == null) return
            requestMesh(pos, FULL_MASK, false)
        } else if (waiting.putIfAbsent(column, System.nanoTime()) == null) {
            // The neighbours that are still in the queue are now the next thing worth generating.
            val rank = ChunkPriority.score(pos.x, pos.z, viewTracker.current) + 1
            for (i in 0 until 4) queue.improve(workKey(KIND_GEN, pos.x + SIDE_DX[i], pos.z + SIDE_DZ[i]), rank)
        }
    }

    /** Scheduler tick: lets chunks that waited for a neighbour go once it is done, or once they
     *  have waited long enough that waiting longer would cost more than meshing twice. A chunk far
     *  from the player may wait longer: the distant terrain shows there meanwhile, so the wait costs
     *  nothing that can be seen, while meshing twice costs worker time and a second upload. */
    private fun releaseWaitingChunks(nowNs: Long) {
        if (waiting.isEmpty()) return
        val center = lastSchedCenter
        val ring = meshRing
        for ((column, since) in waiting) {
            val pos = ChunkPos(ColumnKeys.columnX(column), ColumnKeys.columnZ(column))
            if (chunkStates[pos] != ChunkState.GENERATED || !ring.contains(pos)) {
                waiting.remove(column)
                continue
            }
            val near = center == null || pos.distanceSquaredTo(center) <= NEAR_WAIT_CHUNKS.toLong() * NEAR_WAIT_CHUNKS
            val patience = if (near) NEIGHBOUR_WAIT_NS else NEIGHBOUR_WAIT_FAR_NS
            if (neighboursSettled(pos) || nowNs - since >= patience) {
                if (waiting.remove(column) != null) requestMesh(pos, FULL_MASK, false)
            }
        }
    }

    /** Queues a mesh job for the sub-chunks of [pos] in [mask] (bit i = sub-chunk i). A job for the
     *  same chunk that is already waiting absorbs it; one that is running defers it. */
    private fun requestMesh(pos: ChunkPos, mask: Int, urgent: Boolean) {
        val column = ColumnKeys.column(pos.x, pos.z)
        synchronized(meshLock) {
            if (activeMesh.contains(column)) {
                deferredMask[column] = (deferredMask[column] ?: 0) or mask
                if (urgent) deferredUrgent.add(column)
                return
            }
        }
        val view = viewTracker.current
        val job = MeshWork(pos, mask, urgent)
        job.priority = if (urgent) JobPriority.URGENT else ChunkPriority.score(pos.x, pos.z, view) + JobPriority.MESH_BIAS
        queue.submit(job) { existing, incoming ->
            existing as MeshWork
            incoming as MeshWork
            existing.mask = existing.mask or incoming.mask
            existing.urgent = existing.urgent || incoming.urgent
            existing.priority = min(existing.priority, incoming.priority)
        }
    }

    private fun runMesh(job: MeshWork) {
        val pos = job.pos
        val column = ColumnKeys.column(pos.x, pos.z)
        synchronized(meshLock) {
            if (!activeMesh.add(column)) {
                deferredMask[column] = (deferredMask[column] ?: 0) or job.mask
                if (job.urgent) deferredUrgent.add(column)
                return
            }
        }
        try {
            meshColumn(job)
        } finally {
            var followMask = 0
            var followUrgent = false
            synchronized(meshLock) {
                activeMesh.remove(column)
                followMask = deferredMask.remove(column) ?: 0
                followUrgent = deferredUrgent.remove(column)
            }
            if (followMask != 0) requestMesh(pos, followMask, followUrgent)
        }
    }

    private fun meshColumn(job: MeshWork) {
        val pos = job.pos
        val mask = job.mask
        val column = ColumnKeys.column(pos.x, pos.z)
        val chunk = world.getChunk(pos) ?: return
        if (chunkStates[pos] != ChunkState.GENERATED) return

        val full = mask == FULL_MASK
        (if (full) fullMeshCounter else partialMeshCounter).incrementAndGet()
        val deep = wantsDeep(chunk)
        val seabed = wantsSeabed(chunk)
        // Recorded before the blocks are read: a neighbour that arrives from now on triggers a
        // redo, one that arrived earlier is part of this mesh.
        if (full) chunk.meshedWithNeighbors = neighbourBits(pos)

        val solid = arrayOfNulls<MeshData>(WorldConfig.SUBCHUNKS_PER_CHUNK)
        val water = arrayOfNulls<MeshData>(WorldConfig.SUBCHUNKS_PER_CHUNK)
        var sawDeep = false
        var sawSeabed = false
        var triangles = 0
        val startNs = if (DiagLog.isActive()) System.nanoTime() else 0L
        try {
            for (s in 0 until WorldConfig.SUBCHUNKS_PER_CHUNK) {
                if (mask and (1 shl s) == 0) continue
                val sub = chunk.subChunks[s]
                if (sub.isAllAir()) {
                    sub.isEmpty = true
                    continue
                }
                sub.meshDirty = false
                val mesh = ChunkMesher.buildSubChunkMesh(world, pos.x, pos.z, s, atlas, deep, seabed)
                sub.isEmpty = mesh.isEmpty()
                if (mesh.sawDeep) sawDeep = true
                if (mesh.sawSeabed) sawSeabed = true
                if (!mesh.solid.isEmpty()) solid[s] = mesh.solid
                if (!mesh.water.isEmpty()) water[s] = mesh.water
                triangles += (mesh.solid.indices.size + mesh.water.indices.size) / 3
            }
        } catch (t: Throwable) {
            onMeshFailed(job, column, t)
            return
        }
        meshFailures.remove(column)
        if (startNs != 0L) DiagLog.meshBuild((System.nanoTime() - startNs) / 1_000_000f, triangles)

        synchronized(storeLock) {
            // Unloaded (or replaced) while meshing: drop the result rather than resurrect a column
            // nothing would ever unload again.
            if (world.getChunk(pos) !== chunk) return
            if (sawDeep) chunk.deepCapable = true
            if (sawSeabed) chunk.seabedCapable = true
            if (full) {
                chunk.deepIncluded = deep
                chunk.seabedIncluded = seabed
            }
            meshStore.update(column, mask, solid, water)
        }
        markRegionDirty(ColumnKeys.regionOfColumn(column), job.urgent)
    }

    /** A mesh job that threw. The first failure is retried; if it fails again the column is
     *  published as empty, so it counts as accounted for instead of leaving a permanent hole in the
     *  coverage that shortens the whole view. */
    private fun onMeshFailed(job: MeshWork, column: Long, t: Throwable) {
        val failures = (meshFailures[column] ?: 0) + 1
        meshFailures[column] = failures
        noteFailure("mesh", "column (${job.pos.x}, ${job.pos.z}) failed ($failures): $t", t)
        if (failures < MAX_ATTEMPTS - 1) {
            requestMesh(job.pos, job.mask, job.urgent)
            return
        }
        meshFailures.remove(column)
        val empty = arrayOfNulls<MeshData>(WorldConfig.SUBCHUNKS_PER_CHUNK)
        synchronized(storeLock) {
            if (world.getChunk(job.pos) == null) return
            meshStore.update(column, job.mask, empty, empty)
        }
        markRegionDirty(ColumnKeys.regionOfColumn(column), job.urgent)
    }

    // ---- packing ----------------------------------------------------------------------------

    private fun markRegionDirty(region: Long, urgent: Boolean) {
        val now = System.nanoTime()
        val info = dirtyRegions.computeIfAbsent(region) { DirtyRegion(now, now, urgent) }
        info.lastNs = now
        if (urgent) info.urgent = true
    }

    /**
     * Scheduler tick: queues the packing of regions that changed. A region that is still receiving
     * columns is left alone for a moment so it is packed (and uploaded) once instead of once per
     * column; player edits go at once. Packing pauses while the GL thread is far behind.
     */
    private fun dispatchPacks(nowNs: Long) {
        if (dirtyRegions.isEmpty()) return
        val backedUp = readyRegions.pendingBytes > READY_BYTES_LIMIT
        for ((region, info) in dirtyRegions) {
            if (info.queued) continue
            // Still being packed: the mark stays and is dispatched once that pack is done, so the next
            // one sees everything that changed in the meantime.
            if (packing.contains(region)) continue
            val due = info.urgent || nowNs - info.lastNs >= PACK_SETTLE_NS || nowNs - info.firstNs >= PACK_MAX_WAIT_NS
            if (!due) continue
            if (backedUp && !info.urgent) continue
            info.queued = true
            val job = PackWork(region, info.urgent)
            job.priority = if (info.urgent) JobPriority.URGENT else regionPriority(region, viewTracker.current)
            queue.submit(job) { existing, incoming ->
                existing as PackWork
                incoming as PackWork
                existing.urgent = existing.urgent || incoming.urgent
                existing.priority = min(existing.priority, incoming.priority)
            }
        }
    }

    private fun runPack(job: PackWork) {
        if (!packing.add(job.region)) {
            // Another worker is packing this region: leave the mark for the scheduler to dispatch again.
            dirtyRegions[job.region]?.queued = false
            return
        }
        try {
            // Claim the region's dirty mark first: anything that changes it from now on marks it again
            // and is packed by the next job, while everything already in the store is in this one.
            val info = dirtyRegions.remove(job.region)
            val urgent = job.urgent || (info?.urgent ?: false)
            try {
                readyRegions.put(packer.pack(job.region, meshStore, urgent))
            } catch (t: Throwable) {
                // Most likely out of native memory for the buffers: log it and try again later rather
                // than leave the region stuck as it was.
                noteFailure("pack", "region (${ColumnKeys.regionX(job.region)}, ${ColumnKeys.regionZ(job.region)}) failed: $t", t)
                markRegionDirty(job.region, urgent)
            }
        } finally {
            packing.remove(job.region)
        }
    }

    /** Re-packs every region from the CPU-side meshes. Used when the GL surface/context is
     *  recreated (e.g. after the app is backgrounded): the GPU copies are gone but the meshes in
     *  the store are untouched, so nothing needs to be regenerated or re-meshed. */
    fun remeshAllLoaded() {
        val past = System.nanoTime() - PACK_MAX_WAIT_NS
        for (region in meshStore.regionKeys()) {
            val info = dirtyRegions.computeIfAbsent(region) { DirtyRegion(past, past, false) }
            info.firstNs = past
        }
    }

    // ---- companion ---------------------------------------------------------------------------

    companion object {
        private const val KIND_GEN = 1L
        private const val KIND_MESH = 2L
        private const val KIND_PACK = 3L

        private fun workKey(kind: Long, a: Int, b: Int): Long =
            (kind shl 58) or ((a.toLong() and 0x1FFFFFFFL) shl 29) or (b.toLong() and 0x1FFFFFFFL)

        /** All sixteen sub-chunks of a column. */
        private const val FULL_MASK = (1 shl WorldConfig.SUBCHUNKS_PER_CHUNK) - 1

        /** Neighbour order shared by [Chunk.meshedWithNeighbors]: x-1, x+1, z-1, z+1. */
        private val SIDE_DX = intArrayOf(-1, 1, 0, 0)
        private val SIDE_DZ = intArrayOf(0, 0, -1, 1)
        private val OPPOSITE = intArrayOf(1, 0, 3, 2)

        /** At most this many streaming threads; how many are awake follows the backlog. */
        private const val MAX_WORKER_THREADS = 5

        private const val TICK_MS = 20L
        private const val PARK_MS = 40L
        private const val MAX_ATTEMPTS = 3

        /** Re-rank the waiting jobs after the player has moved this far or turned this much. */
        private const val RERANK_MOVE_BLOCKS = 6f
        private const val RERANK_TURN_COS = 0.966f // about 15 degrees
        private const val RERANK_MIN_INTERVAL_MS = 80L

        /** A generated chunk waits at most this long for a neighbour that is still being made, and
         *  longer if it is more than [NEAR_WAIT_CHUNKS] chunks from the player (see [releaseWaitingChunks]). */
        private const val NEIGHBOUR_WAIT_NS = 250_000_000L
        private const val NEIGHBOUR_WAIT_FAR_NS = 1_000_000_000L
        private const val NEAR_WAIT_CHUNKS = 8

        /** How far the halo reaches beyond the edge of the ring: one chunk (the chunks that touch it). */
        private const val HALO_REACH = 1.0

        /** Chunks stay loaded this far beyond the halo before they are unloaded. */
        private const val UNLOAD_HYSTERESIS = 2.0

        /** A region is packed once no column has arrived for this long, or after this long at most. */
        private const val PACK_SETTLE_NS = 35_000_000L
        private const val PACK_MAX_WAIT_NS = 160_000_000L

        /** Packing pauses while this much packed data is waiting for the GL thread. */
        private const val READY_BYTES_LIMIT = 24L shl 20

        /** Generate ahead of need: from this speed, up to this many rows beyond the halo, in a cone
         *  around the direction of travel. */
        private const val LOOKAHEAD_MIN_SPEED = 6f
        private const val LOOKAHEAD_DEPTH = 1.5
        private const val LOOKAHEAD_CONE_COS = 0.6
        private const val LOOKAHEAD_MAX_CHUNKS = 128

        /** While the player is underground, chunks within this many chunks get their cave faces
         *  meshed (caves are only ever seen from close by); once meshed they keep them out to the
         *  larger radius. The deep sea floor is only needed within the underwater fog. */
        private const val DEEP_RADIUS = 7
        private const val DEEP_KEEP_RADIUS = 9
        private const val SEABED_RADIUS = 3
        private const val SEABED_KEEP_RADIUS = 4

        /** How long the deep geometry stays wanted after the player leaves the cave / the water. */
        private const val DEEP_GRACE_MS = 20_000L

        /** Memory is read this often; a change of the chunk budget re-plans the wanted set at most this often. */
        private const val MEMORY_SAMPLE_MS = 1000L
        private const val BUDGET_REBUILD_MS = 250L

        /** Pooled upload buffers kept when the OS asks for memory back. */
        private const val POOL_KEEP_ON_TRIM = 8L shl 20

        /** The chunk budget never drops below this, whatever the pressure. */
        private const val MIN_CHUNK_BUDGET = 150

        /** Upper bound for the streaming radius: the largest selectable detail distance. */
        private const val MAX_STREAM_RADIUS = 1000

        /** How often the wanted set is re-evaluated even if the player hasn't moved. */
        private const val REBUILD_INTERVAL_MS = 2000L

        /** Share of the Java heap that loaded chunks (blocks + CPU mesh caches) may use; the rest
         *  is left for the garbage collector, region uploads and everything else. */
        private const val CHUNK_HEAP_SHARE = 0.25

        /** How many chunks this device's heap can keep resident: the memory ceiling on the
         *  full-detail (voxel) radius, whatever the distance settings say. For the settings
         *  screen, which tells the player what a very large detail distance really gives. */
        fun chunkBudgetForThisDevice(): Int = computeChunkBudget()

        /** Budgets chunk-column memory against a slice of this app's OWN heap ceiling, not the
         *  device's total RAM: maxMemory() respects android:largeHeap and whatever this specific
         *  device actually grants the process, which is the real wall the game can hit. Far
         *  corners beyond the budget simply don't load, no matter how far the visual setting is
         *  cranked. perChunk (WorldConfig.RESIDENT_BYTES_PER_CHUNK) is deliberately more than the
         *  raw block bytes of a chunk: the CPU-side meshes of every loaded column stay cached (in
         *  the MeshStore) so a region can be rebuilt without re-meshing its untouched columns. */
        private fun computeChunkBudget(): Int {
            return try {
                val budgetBytes = (Runtime.getRuntime().maxMemory() * CHUNK_HEAP_SHARE).toLong()
                val perChunk = WorldConfig.RESIDENT_BYTES_PER_CHUNK.toLong()
                (budgetBytes / perChunk).toInt().coerceIn(300, 6000)
            } catch (t: Throwable) {
                1200
            }
        }
    }
}
