package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.world.Face

/**
 * The brightness of a block face by the way it faces, in one place: the voxel mesher bakes it into the
 * vertices of every block, and the distant terrain bakes the very same numbers into its columns, so a hill
 * does not change brightness where the real blocks hand over to the distant columns (the old distant
 * constants were each 2-3 % darker, which showed as a faint ring around the voxel area).
 *
 * The sun is fixed, so this is just a table: tops are fully lit, the two horizontal axes get different
 * amounts so that a corner reads as a corner, the bottoms are dark.
 */
object FaceShade {
    const val TOP = 1.0f
    const val BOTTOM = 0.4f

    /** Faces that look along the Z axis (north / south). */
    const val ALONG_Z = 0.82f

    /** Faces that look along the X axis (east / west). */
    const val ALONG_X = 0.70f

    fun of(face: Face): Float = when (face) {
        Face.TOP -> TOP
        Face.BOTTOM -> BOTTOM
        Face.NORTH, Face.SOUTH -> ALONG_Z
        Face.EAST, Face.WEST -> ALONG_X
    }
}
