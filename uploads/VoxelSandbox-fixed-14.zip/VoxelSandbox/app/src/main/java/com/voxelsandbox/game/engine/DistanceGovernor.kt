package com.voxelsandbox.game.engine

import java.util.Arrays
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Automatic Render Distance: decides, while the player has the option switched on, how much of
 * the *selected* distance is worth drawing right now. With the option off the governor does not
 * exist as far as the renderer is concerned ([scale] is exactly 1 and every lever returns the
 * selected value), so the selected distance is never reduced behind the player's back.
 *
 * Why this is not "reduce while FPS is low". The first governor did just that, and on a phone
 * that is fill-rate bound it pulled the view in to its floor and stayed there for minutes at the
 * same 30 FPS: a shorter view distance does very little for a bottleneck that is not distance.
 * This one only keeps a reduction that is *measured* to pay for itself:
 *
 *  1. It watches the mean frame time over short windows (trimmed, so one GC pause does not count).
 *  2. When frames are too slow it takes one small step down and measures again. The step is
 *     kept only if the frame time fell by at least [Config.minGain]; otherwise it is undone at
 *     once and further reductions are held off for a while (the hold-off doubles every time a
 *     probe fails, up to [Config.backoffMaxSec]). So a distance-insensitive bottleneck costs a
 *     couple of seconds per hold-off period, not a permanently shrunken world.
 *  3. When there is headroom it takes one small step up, and keeps it unless the frame time got
 *     worse by more than [Config.maxLoss]. The same test is repeated every [Config.revalidateSec]
 *     while a reduction is active, so a reduction that stopped being useful (the player left the
 *     dense forest) is given back. The two thresholds differ on purpose: a step that costs
 *     between [Config.maxLoss] and [Config.minGain] is left exactly where it is, which is what
 *     stops it from flip-flopping.
 *
 * It never goes below [Config.minScale] of the selected distance nor below
 * [Config.floorBlocks] (a close wall of fog is worse than a lower frame rate), and a selected
 * distance that is already at or under that floor is left alone completely.
 *
 * Pure Kotlin on purpose (no Android, no GL, no clock): the caller feeds frame times, so the
 * behaviour is reproducible in a JVM test (see the v14 notes for the scenarios it is tested with).
 */
class DistanceGovernor(private val cfg: Config = Config()) {

    class Config(
        /** Lowest fraction of the selected distance the governor may use. */
        val minScale: Float = 0.40f,
        /** The view is never pulled in below this many blocks (or the selected distance if that is smaller). */
        val floorBlocks: Float = 560f,
        /** A mean frame time above this (ms) is "too slow". 34 ms is just under 30 FPS. */
        val slowMs: Float = 34f,
        /** A mean frame time below this (ms) leaves room to give distance back. 24 ms is about 42 FPS. */
        val comfortMs: Float = 24f,
        /** Length of one measurement window. */
        val windowSec: Float = 2f,
        /** After a change, this long is ignored while the new distance takes effect (the fog grows smoothly). */
        val settleSec: Float = 1f,
        /** After start-up or a distance change nothing is decided for this long: the world is still streaming in. */
        val warmupSec: Float = 8f,
        val stepDown: Float = 0.88f,
        /** Bigger step while frames are very slow (mean above [severeFactor] x [slowMs]), so a 15 FPS stretch is not endured in small steps. */
        val stepDownSevere: Float = 0.78f,
        val severeFactor: Float = 1.4f,
        val stepUp: Float = 1.07f,
        /** A reduction must make frames at least this much faster (fraction of the frame time) to be kept. */
        val minGain: Float = 0.06f,
        /** A restored step is kept unless frames got more than this much slower. */
        val maxLoss: Float = 0.03f,
        /** At least this long between a probe that was undone (or a restored step) and the next decision. */
        val minDwellSec: Float = 1.5f,
        val backoffStartSec: Float = 15f,
        val backoffMaxSec: Float = 240f,
        /** While reduced, a probe back up is made at least this often to check the reduction still helps. */
        val revalidateSec: Float = 45f
    )

    enum class Phase { OFF, WARMUP, STEADY, PROBE_DOWN, PROBE_UP }

    /** Receives a short line for every decision (the diagnostic log); never called when nothing happens. */
    fun interface Listener {
        fun onDecision(scale: Float, text: String)
    }

    var listener: Listener? = null

    /** Fraction of the selected distance in use: 1 = all of it. Read by the renderer every frame. */
    @Volatile var scale: Float = 1f
        private set

    @Volatile var phase: Phase = Phase.OFF
        private set

    /** Mean frame time of the last complete window, for the overlay (ms). */
    @Volatile var lastMeanMs: Float = 0f
        private set

    var probesKept: Int = 0
        private set
    var probesUndone: Int = 0
        private set

    /** True from the moment a distance-insensitive bottleneck was detected until the hold-off ends. */
    @Volatile var distanceIsNotTheLimit: Boolean = false
        private set

    private var fineRing = true

    // ---- state -----------------------------------------------------------------------------
    private var clock = 0f
    private var lastSelectedBlocks = -1f
    private var warmupLeft = 0f
    private var settleLeft = 0f
    private var windowTime = 0f
    private var count = 0
    private val samples = FloatArray(MAX_SAMPLES)

    private var baselineMs = 0f
    private var prevScale = 1f
    private var lastChangeClock = 0f
    private var reduceBlockedUntil = 0f
    private var growBlockedUntil = 0f
    private var reduceBackoff = cfg.backoffStartSec
    private var growBackoff = cfg.backoffStartSec

    // ---- what the renderer uses -----------------------------------------------------------

    /** How far (blocks) the view reaches now, given the selected distance. */
    fun effectiveBlocks(selectedBlocks: Float): Float {
        val s = scale
        if (phase == Phase.OFF || s >= 0.999f) return selectedBlocks
        return max(min(selectedBlocks, cfg.floorBlocks), selectedBlocks * s)
    }

    /** Same in chunks, for the settings screen and the overlay. */
    fun effectiveChunks(selectedChunks: Int, chunkBlocks: Int): Float =
        effectiveBlocks((selectedChunks * chunkBlocks).toFloat()) / chunkBlocks

    /** Factor (0.6 .. 1) for the radius of full-detail voxel terrain: it shrinks with the view, because a
     *  block of voxel terrain costs several times the triangles of the distant terrain behind it. */
    fun detailFactor(): Float {
        if (phase == Phase.OFF) return 1f
        val t = ((scale - cfg.minScale) / (1f - cfg.minScale)).coerceIn(0f, 1f)
        return 0.6f + 0.4f * t
    }

    /** Whether the thin finest ring of distant terrain is kept (it goes while the view is pulled in a lot). */
    fun fineRingAllowed(): Boolean = fineRing

    /** One line for the stats overlay. */
    fun statusLine(selectedChunks: Int, chunkBlocks: Int): String {
        val eff = effectiveChunks(selectedChunks, chunkBlocks)
        val state = when (phase) {
            Phase.OFF -> "off"
            Phase.WARMUP -> "warming up"
            Phase.STEADY -> if (distanceIsNotTheLimit) "distance not the limit" else "steady"
            Phase.PROBE_DOWN -> "testing less"
            Phase.PROBE_UP -> "testing more"
        }
        return "auto distance: %d of %d chunks (%s)".format(java.util.Locale.US, eff.toInt(), selectedChunks, state)
    }

    // ---- per frame -------------------------------------------------------------------------

    /**
     * @param dt seconds since the previous frame
     * @param enabled the player's Automatic Render Distance switch
     * @param measuring false while the frame time says nothing about the world (paused, under water,
     *        waiting for the spawn chunk): the window is dropped and a probe in flight is undone
     * @param selectedBlocks the render distance the player chose, in blocks
     */
    fun update(dt: Float, enabled: Boolean, measuring: Boolean, selectedBlocks: Float) {
        if (!enabled) {
            if (phase != Phase.OFF) switchOff()
            return
        }
        if (phase == Phase.OFF || abs(selectedBlocks - lastSelectedBlocks) > 0.5f) restart(selectedBlocks)

        clock += dt
        if (!measuring) {
            interrupt()
            return
        }
        if (floorScale(selectedBlocks) >= 0.999f) {
            // Nothing can be taken away without going under the floor.
            if (scale != 1f) setScale(1f, "selected distance is at the floor; nothing to adjust")
            return
        }
        if (settleLeft > 0f) {
            settleLeft -= dt
            return
        }
        windowTime += dt
        if (count < samples.size) samples[count++] = dt
        if (windowTime >= cfg.windowSec) evaluate(selectedBlocks)
    }

    // ---- decisions -------------------------------------------------------------------------

    private fun evaluate(selectedBlocks: Float) {
        val ms = trimmedMeanMs()
        lastMeanMs = ms
        clearWindow()
        when (phase) {
            Phase.WARMUP -> {
                warmupLeft -= cfg.windowSec
                if (warmupLeft <= 0f) phase = Phase.STEADY
            }
            Phase.STEADY -> decide(ms, selectedBlocks)
            Phase.PROBE_DOWN -> finishProbeDown(ms, selectedBlocks)
            Phase.PROBE_UP -> finishProbeUp(ms, selectedBlocks)
            Phase.OFF -> Unit
        }
    }

    /** [chain] = the window that just proved a probe was right is also the baseline for the next
     *  one in the same direction ([CHAIN_DOWN] / [CHAIN_UP]), so a long descent (or recovery) is not
     *  held up by an extra measuring window per step; it never turns round on its own result. */
    private fun decide(ms: Float, selectedBlocks: Float, chain: Int = CHAIN_NONE) {
        if (chain == CHAIN_NONE && clock - lastChangeClock < cfg.minDwellSec) return
        val floor = floorScale(selectedBlocks)
        val canReduce = scale > floor + 0.01f && clock >= reduceBlockedUntil && chain != CHAIN_UP
        val canGrow = scale < 0.999f && clock >= growBlockedUntil && chain != CHAIN_DOWN
        distanceIsNotTheLimit = clock < reduceBlockedUntil && ms > cfg.slowMs

        if (ms > cfg.slowMs && canReduce) {
            val step = if (ms > cfg.slowMs * cfg.severeFactor) cfg.stepDownSevere else cfg.stepDown
            startProbe(ms, max(floor, scale * step), Phase.PROBE_DOWN, "frames slow (%.1f ms): trying less distance".format(java.util.Locale.US, ms))
        } else if (canGrow && (ms < cfg.comfortMs || (chain == CHAIN_NONE && clock - lastChangeClock >= cfg.revalidateSec))) {
            var target = min(1f, max(scale * cfg.stepUp, scale + 0.03f))
            if (target > 0.985f) target = 1f
            val why = if (ms < cfg.comfortMs) "headroom (%.1f ms)" else "re-checking that the reduction still helps (%.1f ms)"
            startProbe(ms, target, Phase.PROBE_UP, "trying more distance: " + why.format(java.util.Locale.US, ms))
        }
    }

    private fun startProbe(ms: Float, target: Float, next: Phase, text: String) {
        baselineMs = ms
        prevScale = scale
        phase = next
        settleLeft = cfg.settleSec
        setScale(target, text)
    }

    private fun finishProbeDown(ms: Float, selectedBlocks: Float) {
        val gain = (baselineMs - ms) / baselineMs
        if (gain >= cfg.minGain) {
            probesKept++
            reduceBackoff = cfg.backoffStartSec
            distanceIsNotTheLimit = false
            lastChangeClock = clock
            phase = Phase.STEADY
            note("kept: %.0f%% faster (%.1f -> %.1f ms)".format(java.util.Locale.US, gain * 100f, baselineMs, ms))
            decide(ms, selectedBlocks, CHAIN_DOWN)
        } else {
            probesUndone++
            distanceIsNotTheLimit = true
            reduceBlockedUntil = clock + reduceBackoff
            note("undone: only %.0f%% faster, distance is not the limit; no more reductions for %.0f s".format(java.util.Locale.US, gain * 100f, reduceBackoff))
            reduceBackoff = min(reduceBackoff * 2f, cfg.backoffMaxSec)
            lastChangeClock = clock
            phase = Phase.STEADY
            setScale(prevScale, "back to the previous distance")
        }
    }

    private fun finishProbeUp(ms: Float, selectedBlocks: Float) {
        val loss = (ms - baselineMs) / baselineMs
        if (loss <= cfg.maxLoss) {
            probesKept++
            growBackoff = cfg.backoffStartSec
            lastChangeClock = clock
            phase = Phase.STEADY
            note("kept: frame time %+.0f%% (%.1f -> %.1f ms)".format(java.util.Locale.US, loss * 100f, baselineMs, ms))
            decide(ms, selectedBlocks, CHAIN_UP)
        } else {
            probesUndone++
            growBlockedUntil = clock + growBackoff
            note("undone: frames %.0f%% slower; the reduction is paying, no retry for %.0f s".format(java.util.Locale.US, loss * 100f, growBackoff))
            growBackoff = min(growBackoff * 2f, cfg.backoffMaxSec)
            lastChangeClock = clock
            phase = Phase.STEADY
            setScale(prevScale, "back to the previous distance")
        }
    }

    // ---- housekeeping ----------------------------------------------------------------------

    private fun floorScale(selectedBlocks: Float): Float =
        if (selectedBlocks <= cfg.floorBlocks) 1f else max(cfg.minScale, cfg.floorBlocks / selectedBlocks)

    private fun setScale(value: Float, text: String) {
        val before = scale
        scale = value
        // The finest distant ring goes when the view is pulled in a lot and returns only once it is mostly back.
        if (value < FINE_RING_OFF_BELOW) fineRing = false else if (value >= FINE_RING_ON_ABOVE) fineRing = true
        if (before != value) listener?.onDecision(value, text)
    }

    private fun note(text: String) {
        listener?.onDecision(scale, text)
    }

    /** The frame time stopped meaning anything (pause, diving, loading): drop the window and undo an unfinished probe. */
    private fun interrupt() {
        clearWindow()
        settleLeft = 0f
        if (phase == Phase.PROBE_DOWN || phase == Phase.PROBE_UP) {
            phase = Phase.STEADY
            setScale(prevScale, "measurement interrupted; back to the previous distance")
        }
    }

    private fun restart(selectedBlocks: Float) {
        scale = 1f
        fineRing = true
        phase = Phase.WARMUP
        warmupLeft = cfg.warmupSec
        lastSelectedBlocks = selectedBlocks
        clock = 0f
        lastChangeClock = 0f
        reduceBlockedUntil = 0f
        growBlockedUntil = 0f
        reduceBackoff = cfg.backoffStartSec
        growBackoff = cfg.backoffStartSec
        distanceIsNotTheLimit = false
        clearWindow()
        settleLeft = 0f
    }

    private fun switchOff() {
        phase = Phase.OFF
        scale = 1f
        fineRing = true
        distanceIsNotTheLimit = false
        lastSelectedBlocks = -1f
        clearWindow()
        settleLeft = 0f
    }

    private fun clearWindow() {
        windowTime = 0f
        count = 0
    }

    /** Mean of the window with the slowest 5% of frames dropped, in ms (one hitch must not decide a probe). */
    private fun trimmedMeanMs(): Float {
        val n = count
        if (n == 0) return 0f
        Arrays.sort(samples, 0, n)
        val keep = n - n / 20
        var sum = 0f
        for (i in 0 until keep) sum += samples[i]
        return sum / keep * 1000f
    }

    private companion object {
        const val MAX_SAMPLES = 1024
        const val CHAIN_NONE = 0
        const val CHAIN_DOWN = -1
        const val CHAIN_UP = 1
        const val FINE_RING_OFF_BELOW = 0.85f
        const val FINE_RING_ON_ABOVE = 0.97f
    }
}
