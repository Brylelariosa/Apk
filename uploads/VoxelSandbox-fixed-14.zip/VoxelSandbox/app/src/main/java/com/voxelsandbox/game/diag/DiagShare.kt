package com.voxelsandbox.game.diag

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.io.File

/**
 * Hands exported diagnostic files to Android's native share sheet (so they can go straight to the
 * Claude app, a mail client, a chat, cloud storage...). The files travel as real attachments through
 * a content URI; nothing is ever put on the clipboard.
 */
object DiagShare {
    fun authority(context: Context): String = context.packageName + ".diagfiles"

    fun uriFor(context: Context, file: File): Uri =
        Uri.Builder()
            .scheme("content")
            .authority(authority(context))
            .appendPath("share")
            .appendPath(file.name)
            .build()

    /** Opens the share sheet for [files] (call on the UI thread, after [DiagLog.exportFiles] ran
     *  on a background thread). */
    fun shareFiles(activity: Activity, files: List<File>) {
        if (files.isEmpty()) return
        val uris = ArrayList<Uri>()
        for (f in files) uris.add(uriFor(activity, f))

        val intent = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE)
        intent.type = "text/plain"
        if (uris.size == 1) {
            intent.putExtra(Intent.EXTRA_STREAM, uris[0])
        } else {
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }
        intent.putExtra(Intent.EXTRA_SUBJECT, "VoxelSandbox diagnostic report")
        intent.putExtra(
            Intent.EXTRA_TEXT,
            "VoxelSandbox diagnostic report: a readable .txt summary and the structured .jsonl event log."
        )
        // Grant the receiving app read access to every file. The ClipData is what makes the share
        // sheet extend the grant to all of them, whichever app is picked.
        val clip = ClipData.newUri(activity.contentResolver, "VoxelSandbox diagnostics", uris[0])
        for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(intent, "Share diagnostic report"))
    }
}
