package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.generation.Biome
import com.voxelsandbox.game.world.generation.Climate
import com.voxelsandbox.game.world.generation.SurfaceKind
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.generation.TreeSpecies
import com.voxelsandbox.game.world.mesh.FaceShade
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Tile add ([tile] != null) or removal ([tile] == null) for [key], delivered to the GL
 *  thread strictly in the order the worker produced them. A single ordered stream matters:
 *  with separate "ready" and "unload" queues a tile that was built, unloaded and rebuilt
 *  could be applied in the wrong order and leave a ghost mesh behind. */
class FarEvent(val key: Long, val tile: FarTile?)

/** One finished distant-terrain tile, ready for the GL thread to upload: the opaque land
 *  mesh (seven floats per vertex, see [FarTerrain.LAND_FLOATS]) and (where the tile touches
 *  water) the translucent water mesh (six floats per vertex). */
class FarTile(
    val key: Long,
    val land: MeshData,
    val water: MeshData,
    val minY: Float,
    val maxY: Float
) {
    val level: Int get() = FarTerrain.levelOf(key)

    /** Edge length of the (square) tile in blocks. */
    val size: Float get() = FarTerrain.tileBlocks(level).toFloat()

    /** World-space X/Z of the tile's lower corner. */
    val x0: Float get() = FarTerrain.tileX(key) * size
    val z0: Float get() = FarTerrain.tileZ(key) * size
}

/**
 * Distant terrain: cheap blocky "voxel-style" columns (with little trees) that fill the space
 * between the full-detail voxel chunks and the horizon, so the view distance can be many
 * times larger than what voxel chunks could ever afford (memory- or draw-call-wise).
 *
 * Nothing here touches the voxel world. Heights come straight from the terrain
 * generator's pure height function, so a tile can exist for terrain that no chunk has
 * generated yet -- which is also why the horizon is there instantly at start-up and why
 * it fills any gap while real chunks are still streaming in.
 *
 * Levels of detail. LOD 0 is the voxel world itself (real chunks, see GameRenderer). Beyond
 * it there are [LEVELS] levels of column terrain, finest first; every level has columns twice
 * as wide as the one before and its own distance band around the player:
 *
 *  - level 0 = LOD 1 (high):   2-block columns, a thin ring right behind the voxel area
 *  - level 1 = LOD 2 (medium): 4-block columns
 *  - level 2 = LOD 3 (low):    8-block columns
 *  - levels 3, 4, 5 = VERY FAR: 16-, 32- and 64-block columns (the original far terrain; the
 *    16-block level only bridges what used to be an 8 -> 32 jump)
 *  - levels 6, 7 = EXTREME: 128- and 256-block columns, only used beyond 6400 and 12800 blocks
 *    (400 and 800 chunks). Each doubling of the distance doubles the column size too, so a
 *    column keeps about the same size on screen and every further doubling of the render
 *    distance adds a roughly constant number of columns instead of four times as many: the
 *    1000-chunk maximum costs ~15 % more triangles than the old 400-chunk maximum, not 80 %.
 *
 * Levels meet WITHOUT cracks, overlaps, or popping. The old scheme drew two levels on top of
 * each other near a seam and sank the coarser one by a distance-dependent amount, which made
 * the ground heave as the player walked and left a height step at the end of every ring.
 * Now the columns of a level slide smoothly to the height of the *parent* column of the next
 * coarser level (the 2 x 2 columns of a fine level share one parent: all steps are powers
 * of two on a common grid) over the outer part of their ring (see [morphWidth]; the vertex
 * shader does the blend from a per-vertex target height). At the ring's edge a fine mesh is
 * exactly the coarse mesh, so the two can meet on a plain distance cut with nothing to hide,
 * and a point of ground changes level only through a continuous change of shape.
 *
 * Tiles of one level sample exactly the same heights along their shared edges, so there are
 * no cracks inside a level either. Colour comes from a palette in the texture atlas chosen
 * from the surface type (see [SurfaceKind]), height and forest density (smooth coherent
 * noise, so fields have natural patches rather than stripes), so a tile needs no per-block
 * textures. Where the ground is below sea level the tile also gets a water mesh whose
 * vertices carry the water depth, drawn by the animated-water shader.
 *
 * Everything is built on background threads, nearest tile first: one coordinator that plans,
 * unloads and publishes in order, plus (on devices with enough cores) a couple of builders
 * that construct tiles side by side. [coveredRadiusBlocks] reports how far from the player
 * the tiles are contiguously complete, which the renderer uses to keep the fog in front of
 * any still-missing ground.
 */
class FarTerrain(private val generator: TerrainGenerator) {

    @Volatile private var running = false
    @Volatile private var enabled = true
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var radiusBlocks = 0f
    @Volatile private var resetRequested = false

    /** Tiles to add / remove, in order, for the GL thread to apply. */
    val events = LinkedBlockingQueue<FarEvent>()

    /** Distance from the player out to which every wanted tile has been built. */
    @Volatile var coveredRadiusBlocks: Float = 0f
        private set

    /** Upper bound of the GPU memory the published tiles occupy (bytes), and the ceiling the builder
     *  keeps it under. Hitting the ceiling is not an error: the horizon is simply drawn in at the
     *  distance the budget reaches (see [FarBudget]), with the fog in front of it, and the ground
     *  near the player is never given up for ground far away. */
    @Volatile var residentTileBytes: Long = 0L
        private set
    val tileByteBudget: Long = budgetForThisDevice()

    /** True while the byte budget, not the render distance, decides how far the horizon reaches. */
    @Volatile var budgetLimited: Boolean = false
        private set

    /** Share of [tileByteBudget] in use right now: the OS asking apps to give memory back lowers it
     *  (see [setBudgetScale]); the farthest tiles go first and come back when it is restored. */
    @Volatile private var budgetScale = 1f

    // Coordinator-thread only: the size of every published tile, so unloading gives its bytes back.
    private val tileBytes = HashMap<Long, Int>()

    // Coordinator-thread only: what a tile of each level has weighed so far (an average), which is
    // what the budget assumes for a tile that has not been built yet.
    private val levelBytes = FloatArray(LEVELS) { DEFAULT_TILE_BYTES[it].toFloat() }
    private val budget = FarBudget()

    // The player's velocity (blocks per second, smoothed), for where to prefetch tiles: the plan covers the
    // rings around where the player is and around where they will be PREFETCH_SECONDS from now.
    @Volatile private var velX = 0f
    @Volatile private var velZ = 0f
    private var speedNs = 0L
    private var speedX = 0f
    private var speedZ = 0f

    /** How many tiles were unloaded because they left the plan, and how many were evicted to stay within
     *  the memory budget (statistics; the second should stay near zero in normal play). */
    @Volatile var staleUnloads = 0L
        private set
    @Volatile var budgetEvictions = 0L
        private set
    @Volatile var tilesBuilt = 0L
        private set

    private var thread: Thread? = null

    /** How many tiles are built at the same time. One builder (the coordinator thread itself)
     *  on small CPUs; two or three on bigger ones, leaving cores for the chunk workers and the
     *  render thread. */
    private val builderCount: Int = (Runtime.getRuntime().availableProcessors() / 3).coerceIn(1, 3)
    private var builderPool: ExecutorService? = null

    fun start() {
        if (running) return
        running = true
        if (builderCount > 1) {
            builderPool = Executors.newFixedThreadPool(builderCount) { task ->
                Thread({
                    lowerPriority()
                    task.run()
                }, "voxel-far-build").apply { isDaemon = true }
            }
        }
        thread = Thread({ workerLoop() }, "voxel-far").apply {
            isDaemon = true
            start()
        }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
        thread = null
        builderPool?.shutdownNow()
        builderPool = null
    }

    private fun lowerPriority() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // best effort only
        }
    }

    /** Scales the memory the tiles may use (1 = all of [tileByteBudget]); lowering it is how the
     *  distant terrain gives memory back when the OS asks for it. Safe from any thread. */
    fun setBudgetScale(scale: Float) {
        budgetScale = scale.coerceIn(MIN_BUDGET_SCALE, 1f)
    }

    private fun effectiveBudget(): Long = (tileByteBudget * budgetScale).toLong()

    /** Cheap; safe to call every frame. [radius] is the render distance in blocks. */
    fun updatePlayer(x: Float, z: Float, radius: Float, enable: Boolean) {
        val now = System.nanoTime()
        if (speedNs == 0L) {
            speedNs = now
            speedX = x
            speedZ = z
        } else if (now - speedNs >= SPEED_WINDOW_NS) {
            val dt = (now - speedNs) / 1.0e9f
            velX += ((x - speedX) / dt - velX) * 0.5f
            velZ += ((z - speedZ) / dt - velZ) * 0.5f
            speedNs = now
            speedX = x
            speedZ = z
        }
        playerX = x
        playerZ = z
        // Bounded on purpose: the tile planner loops over every tile of every level out to this radius,
        // so a stray huge (or NaN) value must never reach it. 20,000 blocks covers the largest
        // selectable render distance (1000 chunks = 16,000 blocks) with room to spare.
        radiusBlocks = if (radius.isNaN()) 0f else radius.coerceIn(0f, MAX_RADIUS_BLOCKS)
        enabled = enable
    }

    /** The renderer lost its GL objects (context recreated): everything must be rebuilt
     *  and re-sent, since the CPU copies are not kept after upload. */
    fun invalidateAll() {
        resetRequested = true
    }

    // ---- worker ---------------------------------------------------------------------------

    /**
     * One tile the plan wants. [near] is the distance to the nearest point of the tile that is
     * actually drawn (the part inside its level's band): how far the picture is complete once every
     * tile before this one is built. Not the distance to the tile's footprint, which for a big coarse
     * tile can be hundreds of blocks nearer than anything of it that is ever on screen, and which
     * used to drag the whole horizon in whenever such a tile was missing.
     */
    private class Candidate(val level: Int, val tx: Int, val tz: Int, val key: Long, val near: Float, val rank: Int) {
        /** Tiles whose absence leaves a hole in the picture; the others are an improvement
         *  (the finest ring) or a prefetch and never hold back the fog. */
        val required: Boolean get() = rank == FarBudget.RANK_REQUIRED
    }

    /** A tile that is being built on a builder thread; kept in plan order. */
    private class Pending(val cand: Candidate, val job: Future<FarTile>)

    private fun workerLoop() {
        lowerPriority()

        val built = HashSet<Long>()
        while (running) {
            try {
                if (resetRequested) {
                    resetRequested = false
                    built.clear()
                    clearBytes()
                    budget.reset()
                    events.clear()
                    coveredRadiusBlocks = 0f
                }

                val radius = radiusBlocks
                if (!enabled || radius < 32f) {
                    if (built.isNotEmpty()) {
                        for (k in built) events.put(FarEvent(k, null))
                        built.clear()
                        clearBytes()
                    }
                    coveredRadiusBlocks = 0f
                    Thread.sleep(250)
                    continue
                }

                val px = playerX
                val pz = playerZ
                val ahead = predictedPosition(px, pz)
                val ax = ahead[0]
                val az = ahead[1]
                val plan = planTiles(px, pz, ax, az, radius)
                unloadStale(built, px, pz, ax, az, radius)

                // How much of the plan the memory budget allows (see FarBudget), and what to give up
                // when the resident tiles are over it. A horizon that has to come in is published BEFORE
                // any tile is evicted, so the fog is already in front of ground that is about to go.
                val limit = effectiveBudget()
                val fit = budget.fit(planEntries(plan), limit)
                if (fit.horizon < coveredRadiusBlocks) coveredRadiusBlocks = fit.horizon
                if (residentTileBytes > limit * FarBudget.EVICT_ABOVE) {
                    evictDownTo(built, fit.keep, px, pz, (limit * FarBudget.EVICT_TO).toLong())
                }

                val replan = buildPass(plan, fit, built, px, pz, radius)
                noteBudgetLimit(fit.horizon < radius, fit.horizon)
                if (!replan) Thread.sleep(120)
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                // A bad tile must never kill the whole horizon; back off briefly and retry.
                DiagLog.error("far", "tile build failed: " + t)
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    /**
     * Builds what the plan still lacks, nearest first, and publishes the tiles to the GL thread in plan
     * order, keeping [coveredRadiusBlocks] honest as it goes. Returns true if the player has moved so far
     * that the plan is stale and should be redone at once.
     */
    private fun buildPass(plan: List<Candidate>, fit: FarBudget.Fit, built: HashSet<Long>, px: Float, pz: Float, radius: Float): Boolean {
        var replan = false
        var limitedAt = -1f // where the first required tile the budget leaves out would have begun
        val pool = builderPool
        // Tiles being built right now, oldest first. Their results are published in exactly the order the
        // tiles were planned, so the event stream (and the coverage radius) behaves as if one thread
        // had built them one after another.
        val pending = ArrayDeque<Pending>()
        try {
            for (cand in plan) {
                if (!running) return false
                if (built.contains(cand.key)) continue
                if (!fit.keep.contains(cand.key)) {
                    if (cand.required && limitedAt < 0f) limitedAt = cand.near
                    continue
                }

                // Plan order is nearest first and every nearer required tile is already built (or is the
                // oldest one still in flight), so contiguous coverage ends exactly where the oldest
                // unfinished required tile begins.
                if (cand.required) {
                    coveredRadiusBlocks = if (pending.isEmpty()) cand.near else firstRequiredNear(pending, cand.near)
                }

                // Room for it? What the plan does not keep goes first, farthest first; if that is not
                // enough the budget really is full and this tile is beyond the horizon.
                val estimate = estimateBytes(cand.level).toLong()
                val limit = effectiveBudget()
                if (residentTileBytes + estimate > limit) {
                    evictDownTo(built, fit.keep, px, pz, limit - estimate)
                    if (residentTileBytes + estimate > limit) {
                        if (cand.required && limitedAt < 0f) limitedAt = cand.near
                        continue
                    }
                }

                // Backpressure: the GL thread uploads only a couple per frame.
                while (running && events.size >= MAX_QUEUED_EVENTS) Thread.sleep(4)

                if (pool == null) {
                    val tile = timedBuild(cand)
                    events.put(FarEvent(tile.key, tile))
                    built.add(cand.key)
                    addBytes(tile)
                    tilesBuilt++
                } else {
                    pending.addLast(Pending(cand, pool.submit(Callable<FarTile> { timedBuild(cand) })))
                    if (pending.size < builderCount) continue // keep every builder busy first
                    publish(pending.removeFirst(), built)
                }

                if (resetRequested || !enabled || radiusBlocks != radius ||
                    abs(playerX - px) > REPLAN_DISTANCE || abs(playerZ - pz) > REPLAN_DISTANCE
                ) {
                    replan = true
                    break
                }
            }

            // Whatever is still in flight is finished and published too (unless everything is being
            // thrown away anyway).
            while (pending.isNotEmpty()) {
                val p = pending.removeFirst()
                if (resetRequested) {
                    p.job.cancel(true)
                } else {
                    if (p.cand.required) coveredRadiusBlocks = p.cand.near
                    publish(p, built)
                }
            }
        } finally {
            for (p in pending) p.job.cancel(true)
        }
        if (!replan) coveredRadiusBlocks = if (limitedAt >= 0f) limitedAt else radius
        return replan
    }

    private fun noteBudgetLimit(limited: Boolean, horizon: Float) {
        if (limited && !budgetLimited) {
            DiagLog.note(
                "far terrain: memory budget (%d of %d MB in use) limits the horizon to %.0f blocks"
                    .format(residentTileBytes shr 20, effectiveBudget() shr 20, horizon)
            )
        }
        budgetLimited = limited
    }

    /** Where the player will be [PREFETCH_SECONDS] from now if they keep their velocity (at most
     *  [MAX_PREFETCH] blocks away): the plan also covers the rings around that point, so a tile is
     *  there before the player is whatever the speed, without carrying a prefetch margin on all sides
     *  of the player, including behind them. */
    private fun predictedPosition(px: Float, pz: Float): FloatArray {
        var dx = velX * PREFETCH_SECONDS
        var dz = velZ * PREFETCH_SECONDS
        val len = sqrt(dx * dx + dz * dz)
        if (len > MAX_PREFETCH) {
            dx *= MAX_PREFETCH / len
            dz *= MAX_PREFETCH / len
        }
        return floatArrayOf(px + dx, pz + dz)
    }

    private fun planEntries(plan: List<Candidate>): ArrayList<FarBudget.Entry> {
        val out = ArrayList<FarBudget.Entry>(plan.size)
        for (c in plan) out.add(FarBudget.Entry(c.key, c.near, c.rank, tileBytes[c.key] ?: estimateBytes(c.level)))
        return out
    }

    private fun estimateBytes(level: Int): Int = levelBytes[level].toInt()

    /** Evicts resident tiles the plan does not keep (stale ones, and planned ones beyond the horizon),
     *  farthest first, until the resident bytes are at most [target] or none is left to evict. */
    private fun evictDownTo(built: HashSet<Long>, keep: Set<Long>, px: Float, pz: Float, target: Long) {
        if (residentTileBytes <= target) return
        var victims: ArrayList<Long>? = null
        for (key in built) {
            if (keep.contains(key)) continue
            if (victims == null) victims = ArrayList()
            victims.add(key)
        }
        if (victims == null) return
        victims.sortByDescending { nearestDistance(tileX(it), tileZ(it), tileBlocks(levelOf(it)), px, pz) }
        for (key in victims) {
            if (residentTileBytes <= target) break
            built.remove(key)
            removeBytes(key)
            events.put(FarEvent(key, null))
            budgetEvictions++
        }
    }

    private fun firstRequiredNear(pending: ArrayDeque<Pending>, fallback: Float): Float {
        for (p in pending) {
            if (p.cand.required) return p.cand.near
        }
        return fallback
    }

    /** Builds one tile and reports how long it took (and how big it came out) to the
     *  diagnostic log, which is a no-op while logging is off. */
    private fun timedBuild(cand: Candidate): FarTile {
        val t0 = System.nanoTime()
        val tile = buildTile(cand.level, cand.tx, cand.tz)
        if (DiagLog.isActive()) {
            val ms = (System.nanoTime() - t0) / 1_000_000f
            DiagLog.farTile(cand.level, ms, tile.land.indices.size / 3, tile.water.indices.size / 3)
        }
        return tile
    }

    /** Waits for [p]'s tile and hands it to the GL thread. A tile that failed to build is
     *  reported as the original exception (the coordinator backs off and retries). */
    private fun publish(p: Pending, built: HashSet<Long>) {
        val tile = try {
            p.job.get()
        } catch (e: ExecutionException) {
            throw e.cause ?: e
        }
        events.put(FarEvent(tile.key, tile))
        built.add(p.cand.key)
        addBytes(tile)
        tilesBuilt++
    }

    private fun addBytes(tile: FarTile) {
        val bytes = tileSizeBytes(tile)
        val old = tileBytes.put(tile.key, bytes)
        residentTileBytes += bytes - (old ?: 0)
        // What a tile of this level weighs, for the budget's estimate of the ones not built yet.
        val level = tile.level
        levelBytes[level] += (bytes - levelBytes[level]) * 0.15f
    }

    private fun removeBytes(key: Long) {
        val old = tileBytes.remove(key) ?: return
        residentTileBytes -= old
    }

    private fun clearBytes() {
        tileBytes.clear()
        residentTileBytes = 0L
    }

    /** Every tile that must exist for the current position and render distance, across all
     *  levels, in the order they are to be built: first the tiles whose ground is on screen (nearest
     *  first, by the nearest part of them that is drawn), then the optional finest ring, then the
     *  tiles that are only prefetched: those that the player will need within [PREFETCH_SECONDS] ([ax],
     *  [az] is where they will be), or that are just outside the band they belong to (a margin, on the
     *  inner side as well as the outer, so a band that the player walks into is already built). */
    private fun planTiles(px: Float, pz: Float, ax: Float, az: Float, radius: Float): ArrayList<Candidate> {
        val out = ArrayList<Candidate>()
        val moving = abs(ax - px) + abs(az - pz) > 1f
        for (level in 0 until LEVELS) {
            val inner = planInner(level)
            if (inner - PLAN_MARGIN > radius) continue
            val visibleOuter = min(drawOuter(level), radius)
            val outer = min(drawOuter(level) + PLAN_MARGIN, radius)
            if (outer <= inner + 1f) continue
            val size = tileBlocks(level)
            val minTx = Math.floorDiv(floor(min(px, ax) - outer).toInt(), size)
            val maxTx = Math.floorDiv(floor(max(px, ax) + outer).toInt(), size)
            val minTz = Math.floorDiv(floor(min(pz, az) - outer).toInt(), size)
            val maxTz = Math.floorDiv(floor(max(pz, az) + outer).toInt(), size)
            for (tz in minTz..maxTz) {
                for (tx in minTx..maxTx) {
                    val near = nearestDistance(tx, tz, size, px, pz)
                    val far = farthestDistance(tx, tz, size, px, pz)
                    val visible = near < visibleOuter && (inner <= 0f || far >= inner)
                    var priority = near
                    var planned = visible || (near <= outer && (inner <= 0f || far >= inner - PLAN_MARGIN))
                    if (!planned && moving) {
                        val nearAhead = nearestDistance(tx, tz, size, ax, az)
                        val farAhead = farthestDistance(tx, tz, size, ax, az)
                        if (nearAhead <= outer && (inner <= 0f || farAhead >= inner - PLAN_MARGIN)) {
                            planned = true
                            priority = nearAhead
                        }
                    }
                    if (!planned) continue
                    val rank = when {
                        !visible -> FarBudget.RANK_PREFETCH
                        level == 0 -> FarBudget.RANK_FINE
                        else -> FarBudget.RANK_REQUIRED
                    }
                    out.add(Candidate(level, tx, tz, tileKey(level, tx, tz), max(priority, inner), rank))
                }
            }
        }
        out.sortWith(compareBy<Candidate>({ it.rank }, { it.near }))
        return out
    }

    /** True if the tile is outside the plan around ([x], [z]) by more than [UNLOAD_SLACK]. */
    private fun outOfPlan(level: Int, tx: Int, tz: Int, x: Float, z: Float, radius: Float): Boolean {
        val size = tileBlocks(level)
        val near = nearestDistance(tx, tz, size, x, z)
        val outer = min(drawOuter(level) + PLAN_MARGIN, radius)
        if (near > outer + UNLOAD_SLACK) return true
        val inner = planInner(level)
        return inner > 0f && farthestDistance(tx, tz, size, x, z) < inner - PLAN_MARGIN - UNLOAD_SLACK
    }

    /** Drops tiles that are well outside the plan, both where the player is and where they are heading.
     *  The slack is the hysteresis that stops a tile on the edge of a band being rebuilt back and forth. */
    private fun unloadStale(built: HashSet<Long>, px: Float, pz: Float, ax: Float, az: Float, radius: Float) {
        var stale: ArrayList<Long>? = null
        for (key in built) {
            val level = levelOf(key)
            val tx = tileX(key)
            val tz = tileZ(key)
            if (outOfPlan(level, tx, tz, px, pz, radius) && outOfPlan(level, tx, tz, ax, az, radius)) {
                if (stale == null) stale = ArrayList()
                stale.add(key)
            }
        }
        if (stale != null) {
            for (key in stale) {
                built.remove(key)
                removeBytes(key)
                events.put(FarEvent(key, null))
                staleUnloads++
            }
        }
    }

    private fun nearestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val cx = if (px < x0) x0 else if (px > x0 + size) x0 + size else px
        val cz = if (pz < z0) z0 else if (pz > z0 + size) z0 + size else pz
        val dx = px - cx
        val dz = pz - cz
        return sqrt(dx * dx + dz * dz)
    }

    private fun farthestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val dx = max(abs(px - x0), abs(px - (x0 + size)))
        val dz = max(abs(pz - z0), abs(pz - (z0 + size)))
        return sqrt(dx * dx + dz * dz)
    }

    // ---- tile construction ----------------------------------------------------------------

    private fun buildTile(level: Int, tx: Int, tz: Int): FarTile {
        val size = tileBlocks(level)
        val x0 = tx * size
        val z0 = tz * size

        // The ground of every cell of the tile plus a one-cell ring around it, so the walls
        // along the tile's edges know their neighbours.
        val field = buildField(level, tx * cellsOf(level), tz * cellsOf(level), cellsOf(level))

        // Ground that is far below the surface is hidden by (near-opaque) water, so a tile
        // that is entirely deep ocean needs only its water mesh.
        val hasLand = field.highest + LAND_Y_OFFSET > landFloor(level)
        val hasWater = field.lowest + LAND_Y_OFFSET < WATER_Y

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val land = if (hasLand) buildLandMesh(level, tx, tz, x0, z0, field) else MeshData.EMPTY
        if (!land.isEmpty()) {
            minY = land.minY
            maxY = land.maxY
        }
        val water = if (hasWater) buildWaterMesh(level, x0, z0, field.heights) else MeshData.EMPTY
        if (!water.isEmpty()) {
            minY = min(minY, WATER_Y)
            maxY = max(maxY, WATER_Y)
        }
        if (minY > maxY) {
            minY = WATER_Y
            maxY = WATER_Y
        }
        return FarTile(tileKey(level, tx, tz), land, water, minY, maxY)
    }

    /** The ground of a window of [cells] x [cells] columns of [level] whose first column is the
     *  global column ([gx0], [gz0]) -- height, top, colour, visibility -- plus a one-column ring
     *  around the window. Array index (i, j) is window cell (i - 1, j - 1). A function of the
     *  global column indices only, so a tile and the finer tiles that blend into it agree on it
     *  exactly. */
    private class CellField(val n: Int) {
        val heights = IntArray(n * n)
        val topY = FloatArray(n * n)
        val col = IntArray(n * n)

        /** The colour of the walls that stand under each cell's top (the same as [col] except over soil). */
        val wallCol = IntArray(n * n)
        val skip = BooleanArray(n * n)
        var lowest = Int.MAX_VALUE
        var highest = Int.MIN_VALUE
    }

    private fun buildField(level: Int, gx0: Int, gz0: Int, cells: Int): CellField {
        val step = step(level)
        val lod = LEVEL_LOD[level]
        val shape = generator.shape
        val climate = generator.climate
        val n = cells + 2
        val f = CellField(n)
        val heights = f.heights
        val topY = f.topY
        val col = f.col
        val wallCol = f.wallCol
        val skip = f.skip
        // Heights are sampled one column beyond the ring too, so that every column of the window
        // (the ring included) gets its slope from its true neighbours, not from a clamped edge: the
        // ring's colour, biome and canopy are then exactly what the neighbouring tile computes for
        // the same column, and the walls along a tile's edge agree on both sides.
        val m = cells + 4
        val big = IntArray(m * m)
        // The smooth base elevation of each cell, a by-product of its height (see
        // TerrainShape.heightAndCoast), for the biome rules.
        val coast = DoubleArray(m * m)
        for (j in 0 until m) {
            val wz = (gz0 + j - 1.5) * step
            for (i in 0 until m) {
                val wx = (gx0 + i - 1.5) * step
                big[j * m + i] = floor(shape.heightAndCoast(wx, wz, lod, coast, j * m + i)).toInt()
            }
        }
        for (j in 0 until n) {
            for (i in 0 until n) {
                val h = big[(j + 1) * m + (i + 1)]
                heights[j * n + i] = h
                if (i in 1..cells && j in 1..cells) {
                    if (h < f.lowest) f.lowest = h
                    if (h > f.highest) f.highest = h
                }
            }
        }

        val sea = WorldConfig.SEA_LEVEL
        val span = 2f * step
        val slopeGain = SLOPE_GAIN[level]
        val floorY = landFloor(level)
        for (j in 0 until n) {
            val wz = (gz0 + j - 0.5) * step
            for (i in 0 until n) {
                val c = j * n + i
                val bc = (j + 1) * m + (i + 1) // the same column in the larger window
                val h = heights[c]
                val wx = (gx0 + i - 0.5) * step
                val groundTop = h + LAND_Y_OFFSET // the top face of the voxel column (see LAND_Y_OFFSET)
                topY[c] = groundTop
                if (groundTop <= floorY) {
                    skip[c] = true // hidden under water that is (nearly) opaque from here
                    continue
                }
                if (h < sea) {
                    val cold = climate.baseTemperature(wx, wz) < Climate.COLD
                    val deep = sea - h > 8
                    val bed = if (deep || cold) TextureAtlas.RAMP_GRAVEL + 1f else TextureAtlas.RAMP_SAND + 2f
                    col[c] = colorKey(TextureAtlas.RAMP_ROW_SURFACE, bed)
                    wallCol[c] = col[c]
                    continue
                }

                val dhdx = (big[bc + 1] - big[bc - 1]) / span
                val dhdz = (big[bc + m] - big[bc - m]) / span
                val slope = max(abs(dhdx), abs(dhdz)) * slopeGain
                val hd = h.toDouble()
                val biome = climate.biome(wx, wz, hd, slope.toDouble(), coast[bc])
                val kind = climate.surfaceFor(biome, wx, wz, hd, slope.toDouble())
                val fx = wx.toFloat()
                val fz = wz.toFloat()
                val forest = climate.forest(wx, wz).toFloat()
                // Large soft patches (coherent noise, never a regular wave), so a field of one
                // surface type is not one flat colour and has no stripes or repeats.
                val patch = patchNoise(fx, fz, step)
                val t = when (kind) {
                    SurfaceKind.BEACH -> TextureAtlas.RAMP_SAND + (if (h <= sea) 2f else if (h == sea + 1) 1f else 0f)
                    SurfaceKind.GRASS -> TextureAtlas.RAMP_GRASS + 0.3f + patch * 2.0f + forest * 1.9f
                    SurfaceKind.DRY_GRASS -> TextureAtlas.RAMP_DRY + patch * 1.8f + forest * 0.6f
                    SurfaceKind.DESERT -> TextureAtlas.RAMP_DESERT + patch * 2.0f
                    SurfaceKind.SNOW -> TextureAtlas.RAMP_SNOW + patch * 1.8f
                    SurfaceKind.ROCK -> TextureAtlas.RAMP_STONE + patch * 2.0f
                    SurfaceKind.GRAVEL -> TextureAtlas.RAMP_GRAVEL + patch * 2.0f
                    SurfaceKind.SWAMP -> TextureAtlas.RAMP_SWAMP + patch * 2.0f
                }
                col[c] = colorKey(TextureAtlas.RAMP_ROW_SURFACE, t)
                wallCol[c] = if (kind.soilSides) soilWallKey else col[c]

                // Coarse levels: forested cells are raised into a canopy layer.
                if (level >= CANOPY_FROM_LEVEL && h >= sea + 2 && generator.treeDensity(biome) > 0.0) {
                    val cover = min(0.92, generator.treeChance(biome, forest.toDouble()) * 2.4)
                    val gx = gx0 + (i - 1)
                    val gz = gz0 + (j - 1)
                    if (cellRandom(gx, gz, level).toDouble() < cover) {
                        val rr = cellRandom(gx, gz, level + 7)
                        val leafBase = when (biome) {
                            Biome.TAIGA, Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS, Biome.MOUNTAINS -> TextureAtlas.RAMP_SPRUCE_LEAF
                            Biome.BIRCH_FOREST -> TextureAtlas.RAMP_BIRCH_LEAF
                            else -> TextureAtlas.RAMP_OAK_LEAF
                        }
                        val raise = (if (leafBase == TextureAtlas.RAMP_SPRUCE_LEAF) 7f else 4.5f) + 3f * rr
                        topY[c] = groundTop + raise
                        col[c] = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + (if (rr < 0.5f) 0f else 1f))
                        wallCol[c] = col[c] // a canopy is leaves all the way down
                    }
                }
            }
        }
        return f
    }

    /** For every cell of a tile (with its ring): the height its column slides to as it nears
     *  the outer edge of its level's ring -- the top of the parent column of the next coarser
     *  level, computed by exactly the code that builds that level, so the two meshes coincide
     *  there. The coarsest level has nothing to slide to. */
    private fun morphTargets(level: Int, tx: Int, tz: Int, cells: Int, n: Int, field: CellField, floorY: Float): FloatArray {
        val out = FloatArray(n * n)
        if (level >= LEVELS - 1) {
            System.arraycopy(field.topY, 0, out, 0, n * n)
            return out
        }
        // Columns are twice as wide one level up and the grids are aligned, so the window of
        // parent columns that covers this tile (and its ring) has half the columns per edge.
        val half = cells / 2
        val parent = buildField(level + 1, tx * half, tz * half, half)
        val np = half + 2
        for (j in 0 until n) {
            val pj = ((j - 1) shr 1) + 1
            for (i in 0 until n) {
                val pi = ((i - 1) shr 1) + 1
                out[j * n + i] = max(parent.topY[pj * np + pi], floorY)
            }
        }
        return out
    }

    /**
     * The land of one tile as blocky, voxel-style columns: every cell is a flat-topped column
     * at its (whole-block) ground height with vertical walls wherever a neighbour is lower,
     * all in flat colours from the atlas palette. Equal neighbours along a row are merged into
     * one long quad, so flat country costs very little. The two finest levels also stand real
     * little trees (a trunk box and a canopy box, at exactly the places the chunk generator
     * will grow them) on the ground; coarser levels raise the cells of forests into a dark
     * canopy layer. Every vertex also carries the height it slides to (see [morphTargets]).
     */
    private fun buildLandMesh(level: Int, tx: Int, tz: Int, x0: Int, z0: Int, field: CellField): MeshData {
        val step = step(level)
        val cells = cellsOf(level)
        val n = cells + 2
        val topY = field.topY
        val col = field.col
        val wallCol = field.wallCol
        val skip = field.skip
        val sea = WorldConfig.SEA_LEVEL
        val floorY = landFloor(level)
        val morphY = morphTargets(level, tx, tz, cells, n, field, floorY)

        val b = LodBuilder(cells * cells / 2)
        val sizeF = step.toFloat()

        // Tops, merged into runs along X.
        for (j in 0 until cells) {
            val za = (z0 + j * step).toFloat()
            val zb = za + sizeF
            var i = 0
            while (i < cells) {
                val c = (j + 1) * n + (i + 1)
                if (skip[c]) {
                    i++
                    continue
                }
                var run = 1
                while (i + run < cells) {
                    val c2 = c + run
                    if (skip[c2] || topY[c2] != topY[c] || col[c2] != col[c] || morphY[c2] != morphY[c]) break
                    run++
                }
                val xa = (x0 + i * step).toFloat()
                emitTop(b, xa, xa + run * sizeF, za, zb, topY[c], keyU(col[c]), keyV(col[c]), SHADE_TOP, morphY[c])
                i += run
            }
        }

        // Walls on the edges between row j and row j + 1 (j = -1 is the tile's own edge), merged along X.
        for (j in -1 until cells) {
            val z = (z0 + (j + 1) * step).toFloat()
            val aInside = j >= 0
            val bInside = j + 1 < cells
            var i = 0
            while (i < cells) {
                val a = (j + 1) * n + (i + 1)
                val dir = edgeDir(topY, morphY, a, a + n, aInside, bInside)
                if (dir == 0) {
                    i++
                    continue
                }
                val hi = if (dir > 0) a else a + n
                val lo = if (dir > 0) a + n else a
                if (skip[hi]) {
                    i++
                    continue
                }
                var run = 1
                while (i + run < cells) {
                    val a2 = a + run
                    if (edgeDir(topY, morphY, a2, a2 + n, aInside, bInside) != dir) break
                    val hi2 = if (dir > 0) a2 else a2 + n
                    val lo2 = if (dir > 0) a2 + n else a2
                    if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || wallCol[hi2] != wallCol[hi] ||
                        morphY[hi2] != morphY[hi] || morphY[lo2] != morphY[lo]
                    ) break
                    run++
                }
                val yt = topY[hi]
                val yb = max(topY[lo], floorY)
                // (equal heights with different slide targets: a wall that is flat now and opens later)
                if (yt > yb || morphY[hi] > morphY[lo]) {
                    val xa = (x0 + i * step).toFloat()
                    val xb = xa + run * sizeF
                    layeredWall(yb, yt, morphY[lo], morphY[hi], wallCol[hi]) { y0, y1, m0, m1, key ->
                        val shade = wallShade(y0, y1, SHADE_Z)
                        if (dir > 0) {
                            emitWallPosZ(b, z, xa, xb, y0, y1, keyU(key), keyV(key), shade, m0, m1)
                        } else {
                            emitWallNegZ(b, z, xa, xb, y0, y1, keyU(key), keyV(key), shade, m0, m1)
                        }
                    }
                }
                i += run
            }
        }

        // Walls on the edges between column i and column i + 1, merged along Z.
        for (i in -1 until cells) {
            val x = (x0 + (i + 1) * step).toFloat()
            val aInside = i >= 0
            val bInside = i + 1 < cells
            var j = 0
            while (j < cells) {
                val a = (j + 1) * n + (i + 1)
                val dir = edgeDir(topY, morphY, a, a + 1, aInside, bInside)
                if (dir == 0) {
                    j++
                    continue
                }
                val hi = if (dir > 0) a else a + 1
                val lo = if (dir > 0) a + 1 else a
                if (skip[hi]) {
                    j++
                    continue
                }
                var run = 1
                while (j + run < cells) {
                    val a2 = a + run * n
                    if (edgeDir(topY, morphY, a2, a2 + 1, aInside, bInside) != dir) break
                    val hi2 = if (dir > 0) a2 else a2 + 1
                    val lo2 = if (dir > 0) a2 + 1 else a2
                    if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || wallCol[hi2] != wallCol[hi] ||
                        morphY[hi2] != morphY[hi] || morphY[lo2] != morphY[lo]
                    ) break
                    run++
                }
                val yt = topY[hi]
                val yb = max(topY[lo], floorY)
                // (equal heights with different slide targets: a wall that is flat now and opens later)
                if (yt > yb || morphY[hi] > morphY[lo]) {
                    val za = (z0 + j * step).toFloat()
                    val zb = za + run * sizeF
                    layeredWall(yb, yt, morphY[lo], morphY[hi], wallCol[hi]) { y0, y1, m0, m1, key ->
                        val shade = wallShade(y0, y1, SHADE_X)
                        if (dir > 0) {
                            emitWallPosX(b, x, za, zb, y0, y1, keyU(key), keyV(key), shade, m0, m1)
                        } else {
                            emitWallNegX(b, x, za, zb, y0, y1, keyU(key), keyV(key), shade, m0, m1)
                        }
                    }
                }
                j += run
            }
        }

        // The finest levels: real trees, where the chunk generator will grow them. (The
        // generator's tree lattice is 4 x 4 blocks whatever the column width here.)
        if (level < TREE_LEVELS) {
            val size = tileBlocks(level)
            val lattice = size / 4
            val lx0 = x0 / 4
            val lz0 = z0 / 4
            for (lj in 0 until lattice) {
                for (li in 0 until lattice) {
                    val spot = generator.treeSpot(lx0 + li, lz0 + lj) ?: continue
                    val ci = Math.floorDiv(spot.x - x0, step) + 1
                    val cj = Math.floorDiv(spot.z - z0, step) + 1
                    if (ci < 1 || ci > cells || cj < 1 || cj > cells) continue
                    val c = cj * n + ci
                    if (skip[c] || field.heights[c] < sea + 1) continue
                    // A tree slides into the ground (just under the parent column's top) as its
                    // ring ends, so it never pops.
                    emitTree(b, spot, topY[c], morphY[c] - 0.6f)
                }
            }
        }
        return b.build()
    }

    /** Which side of the edge between cells [a] and [b] gets a wall: 1 = a's (a is the higher
     *  cell and inside this tile), -1 = b's, 0 = none (nothing to cover, or the higher cell
     *  belongs to the neighbouring tile, which emits that wall itself).
     *
     *  Two columns need a wall between them if their heights differ, *or if the heights they
     *  slide to differ* ([morphY]): equal neighbours whose parents are at different heights come
     *  apart as the ring ends, and without a (still zero-height) wall there the gap between them
     *  would be a crack. The higher cell is the one with the higher height, ties broken by the
     *  higher slide target. */
    private fun edgeDir(topY: FloatArray, morphY: FloatArray, a: Int, b: Int, aInside: Boolean, bInside: Boolean): Int {
        val aHigher: Boolean
        if (topY[a] != topY[b]) {
            aHigher = topY[a] > topY[b]
        } else if (morphY[a] != morphY[b]) {
            aHigher = morphY[a] > morphY[b]
        } else {
            return 0
        }
        return if (aHigher) (if (aInside) 1 else 0) else (if (bInside) -1 else 0)
    }

    /** Shade of a wall. Walls that stand in the water (the seabed steps seen through a
     *  translucent surface, the foot of a coast) get the shade of a top, so they never draw
     *  dark contour lines through or along the water; low shore steps get a halfway shade. */
    private fun wallShade(yb: Float, yt: Float, base: Float): Float {
        if (yt <= WATER_Y) return SHADE_TOP
        if (yb < WATER_Y && yt < WATER_Y + 2.5f) return 0.5f * (base + SHADE_TOP)
        return base
    }

    private fun colorKey(row: Int, column: Float): Int {
        val q = (column * 4f + 0.5f).toInt()
        return row * 256 + (if (q < 0) 0 else if (q > 124) 124 else q)
    }

    /** The colour of the walls over soil (see SurfaceKind.soilSides): the middle shade of the palette's dirt. */
    private val soilWallKey = colorKey(TextureAtlas.RAMP_ROW_SURFACE, TextureAtlas.RAMP_DIRT + 1f)

    /** What a soil-sided column is made of below its soil: the middle shade of the palette's stone. */
    private val rockWallKey = colorKey(TextureAtlas.RAMP_ROW_SURFACE, TextureAtlas.RAMP_STONE + 1f)

    /**
     * Draws the wall of a step in the ground, from [yb] up to [yt] (its foot and its top slide to [mb] and [mt]),
     * through [emit] -- in one piece, or in two where it is taller than the soil is deep. A soil-sided column is
     * dirt for [SOIL_DEPTH] blocks below its top and stone below that, as the generator builds it, so the
     * cliffs of a distant mountain are not dirt all the way down. Where the wall is split, the slide target of
     * the seam is interpolated along the wall, so the two pieces stay one plane while they slide.
     */
    private inline fun layeredWall(
        yb: Float, yt: Float, mb: Float, mt: Float, key: Int,
        emit: (yb: Float, yt: Float, mb: Float, mt: Float, key: Int) -> Unit
    ) {
        if (key != soilWallKey || yt - yb <= SOIL_DEPTH) {
            emit(yb, yt, mb, mt, key)
            return
        }
        val seam = yt - SOIL_DEPTH
        val seamTarget = mb + (mt - mb) * ((seam - yb) / (yt - yb))
        emit(yb, seam, mb, seamTarget, rockWallKey)
        emit(seam, yt, seamTarget, mt, soilWallKey)
    }

    private fun keyU(key: Int): Float = TextureAtlas.rampU((key and 255) / 4f)

    private fun keyV(key: Int): Float = TextureAtlas.rampV(key shr 8, (key and 255) / 4f)

    // Flat-coloured quads, each wound counter-clockwise as seen from outside. [m] / [mb] / [mt]
    // are the heights the vertices slide to (see morphTargets); walls list their two bottom
    // vertices first, then their two top vertices.

    private fun emitTop(b: LodBuilder, xa: Float, xb: Float, za: Float, zb: Float, y: Float, u: Float, v: Float, shade: Float, m: Float) {
        b.quad(xa, y, za, xa, y, zb, xb, y, zb, xb, y, za, u, v, shade, m, m, m, m)
    }

    private fun emitWallPosX(b: LodBuilder, x: Float, za: Float, zb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(x, yb, zb, x, yb, za, x, yt, za, x, yt, zb, u, v, shade, mb, mb, mt, mt)
    }

    private fun emitWallNegX(b: LodBuilder, x: Float, za: Float, zb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(x, yb, za, x, yb, zb, x, yt, zb, x, yt, za, u, v, shade, mb, mb, mt, mt)
    }

    private fun emitWallPosZ(b: LodBuilder, z: Float, xa: Float, xb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(xa, yb, z, xb, yb, z, xb, yt, z, xa, yt, z, u, v, shade, mb, mb, mt, mt)
    }

    private fun emitWallNegZ(b: LodBuilder, z: Float, xa: Float, xb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(xb, yb, z, xa, yb, z, xa, yt, z, xb, yt, z, u, v, shade, mb, mb, mt, mt)
    }

    /** An open-bottomed box: a top and four walls, all sliding to the height [m]. */
    private fun emitBox(
        b: LodBuilder, xa: Float, xb: Float, za: Float, zb: Float, yb: Float, yt: Float, topKey: Int, sideKey: Int, m: Float
    ) {
        if (yt <= yb) return
        emitTop(b, xa, xb, za, zb, yt, keyU(topKey), keyV(topKey), SHADE_TOP, m)
        val su = keyU(sideKey)
        val sv = keyV(sideKey)
        emitWallPosX(b, xb, za, zb, yb, yt, su, sv, SHADE_X, m, m)
        emitWallNegX(b, xa, za, zb, yb, yt, su, sv, SHADE_X, m, m)
        emitWallPosZ(b, zb, xa, xb, yb, yt, su, sv, SHADE_Z, m, m)
        emitWallNegZ(b, za, xa, xb, yb, yt, su, sv, SHADE_Z, m, m)
    }

    /**
     * One distant tree as boxes: a trunk and a canopy (two stacked canopy boxes for a spruce),
     * sized to match what [com.voxelsandbox.game.world.generation.TreeBuilder] grows.
     * [cellTop] is the LOD ground the tree stands on; the trunk reaches down to it so a tree
     * never floats above the flat cell top on a slope. [m] is the height the whole tree
     * flattens to at the end of its ring.
     */
    private fun emitTree(b: LodBuilder, spot: TerrainGenerator.TreeSpot, cellTop: Float, m: Float) {
        val th = spot.th
        val species = spot.species
        val base = spot.ground + 1f
        val x = spot.x.toFloat()
        val z = spot.z.toFloat()
        val variant = ((th ushr 3) and 1).toFloat()
        val bush = species != TreeSpecies.SPRUCE && ((th ushr 20) and 15) == 0
        val leafBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_LEAF
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_LEAF
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_LEAF
        }
        val woodBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_WOOD
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_WOOD
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_WOOD
        }
        val topKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + variant)
        val sideKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + 1f + variant)
        val woodKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, woodBase)
        val bigOak = species == TreeSpecies.OAK && ((th ushr 24) and 7) == 0
        val trunk = when {
            bush -> 1
            species == TreeSpecies.BIRCH -> 6 + ((th ushr 4) % 4)
            species == TreeSpecies.SPRUCE -> 7 + ((th ushr 4) % 7)
            bigOak -> 7 + ((th ushr 4) % 3)
            else -> 5 + ((th ushr 4) % 4)
        }

        if (!bush) {
            emitBox(b, x, x + 1f, z, z + 1f, min(base - 0.25f, cellTop), base + trunk, woodKey, woodKey, m)
        }
        val cx = x + 0.5f
        val cz = z + 0.5f
        val tf = trunk.toFloat()
        when {
            bush -> emitBox(b, cx - 1.5f, cx + 1.5f, cz - 1.5f, cz + 1.5f, base, base + 3f, topKey, sideKey, m)
            species == TreeSpecies.SPRUCE -> {
                emitBox(b, cx - 3.25f, cx + 3.25f, cz - 3.25f, cz + 3.25f, base + 2f, base + tf - 4f, topKey, sideKey, m)
                emitBox(b, cx - 1.7f, cx + 1.7f, cz - 1.7f, cz + 1.7f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            }
            species == TreeSpecies.BIRCH ->
                emitBox(b, cx - 2f, cx + 2f, cz - 2f, cz + 2f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            bigOak ->
                emitBox(b, cx - 3.5f, cx + 3.5f, cz - 3.5f, cz + 3.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            else ->
                emitBox(b, cx - 2.5f, cx + 2.5f, cz - 2.5f, cz + 2.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
        }
    }

    /** The sea / lake / river surface of a tile: a flat grid at [WATER_Y] whose vertices
     *  carry the depth of the ground below (averaged over the four cells that meet there),
     *  and only the cells that touch water.
     *
     *  Open sea is the bulk of it, and over deep water every vertex has the same attributes
     *  (the water shader's depth tint has long saturated), so those cells would all draw
     *  identically. Instead of two triangles per cell, any aligned block of 4x4 up to 64x64
     *  cells whose every vertex is deep becomes a fan of triangles from one extra vertex at its
     *  centre to the vertices around its edge: the edge keeps every grid vertex, so the block
     *  still meets its neighbours (merged or not) exactly, with no cracks, while a whole deep
     *  tile costs 256 triangles instead of 8192. */
    private fun buildWaterMesh(level: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val step = step(level)
        val cells = cellsOf(level)
        val verts = cells + 1
        val n = cells + 2
        val stride = MeshData.FLOATS_PER_VERTEX
        val gridVerts = verts * verts
        val vertexData = FloatArray((gridVerts + (cells / MIN_FAN_BLOCK) * (cells / MIN_FAN_BLOCK)) * stride)
        val depths = FloatArray(gridVerts)
        var vi = 0
        for (j in 0 until verts) {
            for (i in 0 until verts) {
                // The four cells meeting at vertex (i, j) are array cells (i, j) .. (i + 1, j + 1).
                val c = j * n + i
                val depth = (cellDepth(heights[c]) + cellDepth(heights[c + 1]) +
                    cellDepth(heights[c + n]) + cellDepth(heights[c + n + 1])) * 0.25f
                depths[j * verts + i] = depth
                vertexData[vi++] = (x0 + i * step).toFloat()
                vertexData[vi++] = WATER_Y
                vertexData[vi++] = (z0 + j * step).toFloat()
                vertexData[vi++] = depth // the water shader reads depth from the first data slot
                vertexData[vi++] = 0f // flow X: distant water is always still
                vertexData[vi++] = 0f // flow Z
            }
        }

        // Prefix sums of the deep vertices: "is this whole block deep" in O(1).
        val w = verts + 1
        val deepSum = IntArray(w * w)
        for (j in 0 until verts) {
            var row = 0
            for (i in 0 until verts) {
                if (depths[j * verts + i] >= DEEP_WATER) row++
                deepSum[(j + 1) * w + (i + 1)] = deepSum[j * w + (i + 1)] + row
            }
        }

        val indices = IntArray(cells * cells * 6)
        var ii = 0
        var fans = 0

        fun emit(i0: Int, j0: Int, size: Int) {
            if (size >= MIN_FAN_BLOCK) {
                val s1 = size + 1
                val deepCount = deepSum[(j0 + s1) * w + (i0 + s1)] - deepSum[j0 * w + (i0 + s1)] -
                    deepSum[(j0 + s1) * w + i0] + deepSum[j0 * w + i0]
                if (deepCount == s1 * s1) {
                    val center = gridVerts + fans
                    fans++
                    val o = center * stride
                    vertexData[o] = (x0 + (i0 + size / 2) * step).toFloat()
                    vertexData[o + 1] = WATER_Y
                    vertexData[o + 2] = (z0 + (j0 + size / 2) * step).toFloat()
                    vertexData[o + 3] = DEEP_WATER
                    vertexData[o + 4] = 0f
                    vertexData[o + 5] = 0f
                    // Walk the block's edge: along the top (+i), the right (+j), the bottom (-i)
                    // and the left (-j); each edge step with the centre is one upward-facing triangle.
                    val count = 4 * size
                    for (k in 0 until count) {
                        val p = edgeVertex(i0, j0, size, k, verts)
                        val q = edgeVertex(i0, j0, size, if (k + 1 == count) 0 else k + 1, verts)
                        indices[ii++] = center
                        indices[ii++] = q
                        indices[ii++] = p
                    }
                    return
                }
            }
            if (size == 1) {
                val a = j0 * verts + i0
                val b = a + 1
                val d = a + verts
                val c = d + 1
                if (depths[a] <= 0f && depths[b] <= 0f && depths[c] <= 0f && depths[d] <= 0f) return
                indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
                return
            }
            val half = size / 2
            emit(i0, j0, half)
            emit(i0 + half, j0, half)
            emit(i0, j0 + half, half)
            emit(i0 + half, j0 + half, half)
        }
        emit(0, 0, cells)

        if (ii == 0) return MeshData.EMPTY
        val total = gridVerts + fans
        return MeshData(vertexData.copyOf(total * stride), indices.copyOf(ii), total, WATER_Y, WATER_Y)
    }

    /** Grid vertex number [k] (0 until 4 * size) when walking round the edge of the block of
     *  [size] cells at (i0, j0): top edge left to right, right edge top to bottom, bottom
     *  edge right to left, left edge bottom to top. */
    private fun edgeVertex(i0: Int, j0: Int, size: Int, k: Int, verts: Int): Int {
        val side = k / size
        val t = k - side * size
        return when (side) {
            0 -> j0 * verts + (i0 + t)
            1 -> (j0 + t) * verts + (i0 + size)
            2 -> (j0 + size) * verts + (i0 + size - t)
            else -> (j0 + size - t) * verts + i0
        }
    }

    private fun cellDepth(h: Int): Float = (WATER_Y - (h + LAND_Y_OFFSET)).coerceIn(0f, DEEP_WATER)

    companion object {
        /** Number of levels of column terrain (0 = finest). */
        const val LEVELS = 8

        /** Most columns along a tile edge. */
        const val MAX_CELLS = 64

        /** Floats per vertex of the land meshes: position (3), palette uv (2), shade (1) and
         *  the height the vertex slides to (1). */
        const val LAND_FLOATS = 7

        /** Columns along a tile edge, per level. Fine levels have small tiles (a thin ring
         *  does not waste triangles on ground it never draws); the coarse ones have few columns
         *  because beyond a kilometre a column is a handful of pixels, and what a weak GPU
         *  chokes on is the *number of triangles* of the distant terrain. */
        private val LEVEL_CELLS = intArrayOf(32, 64, 64, 32, 32, 32, 32, 32)

        /** Column size per level, in blocks: every step is a power of two, so the columns of
         *  one level are exactly 2 x 2 of the level below it (the basis of the height blend). */
        private val LEVEL_STEP = intArrayOf(2, 4, 8, 16, 32, 64, 128, 256)

        /** The terrain generator's detail setting per level (see TerrainShape.height): the
         *  finest levels keep the voxel world's full shape, the coarse ones drop the features
         *  that sparse sampling would only alias. */
        private val LEVEL_LOD = intArrayOf(0, 0, 1, 2, 2, 3, 3, 3)

        fun cellsOf(level: Int): Int = LEVEL_CELLS[level]
        fun step(level: Int): Int = LEVEL_STEP[level]

        /** Tile edge in blocks: 64, 256, 512, 512, 1024, 2048, 4096, 8192. */
        fun tileBlocks(level: Int): Int = LEVEL_CELLS[level] * LEVEL_STEP[level]

        /** Short names for the on-screen statistics and the diagnostic log. */
        fun levelName(level: Int): String = when (level) {
            0 -> "LOD1"
            1 -> "LOD2"
            2 -> "LOD3"
            3 -> "far16"
            4 -> "far32"
            5 -> "far64"
            6 -> "far128"
            else -> "far256"
        }

        /** Real trees stand on the ground of the levels below this; the coarser ones raise
         *  forested columns into a canopy layer instead. */
        private const val TREE_LEVELS = 2
        private const val CANOPY_FROM_LEVEL = 2

        /** Outer edge of each level's distance band, in blocks from the player. The first
         *  entry is a placeholder: the finest ring is placed just behind the voxel area (see
         *  [configureFineRing]). The last level has no outer edge (it reaches the render
         *  distance). */
        private val BAND_OUTER = floatArrayOf(0f, 512f, 896f, 1408f, 2304f, 6400f, 12800f, 1.0e9f)

        /** How far in from its outer edge each level starts sliding to the next coarser
         *  level's heights. */
        private val MORPH_WIDTH = floatArrayOf(32f, 96f, 128f, 192f, 288f, 512f, 1024f, 0f)

        /** Width of the finest ring. A step-2 column is four times the triangles per block
         *  of the next level, so the ring is kept thin: its job is the first stretch behind
         *  the voxel terrain, where the dissolve needs a good backdrop. */
        private const val FINE_RING_WIDTH = 56f
        private const val FINE_MIN_START = 96f

        /** Tiles are planned this much beyond a band's edge, so walking on between replans
         *  never uncovers the ring. Moving fast is covered separately: the plan also reaches to where
         *  the player will be in [PREFETCH_SECONDS] (see [predictedPosition]). */
        private const val PLAN_MARGIN = 24f

        /** How many seconds ahead of the player the plan reaches (at their current velocity), and at most
         *  how many blocks. */
        private const val PREFETCH_SECONDS = 2f
        private const val MAX_PREFETCH = 360f

        /** A tile is unloaded only this far (blocks) beyond the edge of the plan. */
        private const val UNLOAD_SLACK = 96f

        /** The player's speed is measured over windows of this length. */
        private const val SPEED_WINDOW_NS = 100_000_000L

        /** The tile budget never shrinks below this share, whatever the OS asks for: below it the
         *  horizon would start to come in over ground that is on screen. */
        private const val MIN_BUDGET_SCALE = 0.4f

        /** What a tile of each level weighs on the GPU, as a first guess for the budget until real
         *  tiles have been built (measured on the real generator; the average takes over). */
        private val DEFAULT_TILE_BYTES = intArrayOf(210_000, 1_300_000, 1_250_000, 340_000, 380_000, 400_000, 420_000, 420_000)

        /** Distant water of a level keeps drawing this far past its band's outer edge, so
         *  the flat translucent rings overlap by a sliver instead of leaving a hairline gap. */
        const val WATER_OVERLAP = 1.5f

        @Volatile private var fineIn = 0f
        @Volatile private var fineOut = 0f

        /**
         * Places the thin finest ring (level 0) just behind the voxel area, or takes it away
         * ([allowed] = false, e.g. while the adaptive-distance governor is saving work).
         * [voxelFadeStart] is where the voxel terrain begins to dissolve. The ring only moves
         * when that changes by a good margin, so it does not make tiles come and go.
         */
        fun configureFineRing(voxelFadeStart: Float, allowed: Boolean) {
            if (!allowed || voxelFadeStart < FINE_MIN_START) {
                fineOut = 0f
                return
            }
            val raw = voxelFadeStart - 8f
            if (fineOut > 0f && abs(raw - fineIn) < 40f) return
            val a0 = max(0f, floor(raw / 32f) * 32f)
            val a1 = min(a0 + FINE_RING_WIDTH, BAND_OUTER[1] - 96f)
            if (a1 - a0 < 24f) {
                fineOut = 0f
                return
            }
            fineIn = a0
            fineOut = a1
        }

        fun fineInner(): Float = fineIn
        fun fineOuter(): Float = fineOut

        /** Inner edge of the area a level's tiles are built for. Level 1 is always built from
         *  the player outwards: it is the ground that shows (the ring of level 0 aside) and
         *  the stand-in for level 0 whenever the voxel area is not loaded yet. */
        fun planInner(level: Int): Float = when (level) {
            0 -> fineIn
            1 -> 0f
            else -> BAND_OUTER[level - 1]
        }

        /** Where a level is drawn from. (Level 1 also covers the ring that level 0 improves; the renderer
         *  takes that ring out of it, per tile, once the level-0 tiles for it are on the GPU.) */
        fun drawInner(level: Int): Float = when (level) {
            0 -> fineIn
            1 -> 0f
            else -> BAND_OUTER[level - 1]
        }

        /** Exact outer edge of a level's distance band (the next level starts there). */
        fun drawOuter(level: Int): Float = if (level == 0) fineOut else BAND_OUTER[level]

        /** Distance from the player at which a level starts sliding to its parent's heights. */
        fun morphStart(level: Int): Float = drawOuter(level) - MORPH_WIDTH[level]

        /** Far-terrain slopes are measured over a coarser baseline than the voxel terrain's,
         *  which smooths them; these gains restore the rock / scree coverage the voxel
         *  generator would give, so a mountainside keeps its colour with distance. */
        private val SLOPE_GAIN = floatArrayOf(1.0f, 1.2f, 1.5f, 1.9f, 2.4f, 3.4f, 4.4f, 5.6f)

        /** Voxel water surfaces sit at SEA_LEVEL + 0.875 (see ChunkMesher). */
        const val WATER_Y = WorldConfig.SEA_LEVEL + 0.875f

        /** Land vertices sit this far above the top block's floor: exactly at the voxel top face (+1). A
         *  column is then as high as the block it stands for, the shore falls where the voxel shore does
         *  (ground at sea level is land, ground below it is under water exactly as deep as the voxel water
         *  is), and distant ground that fills in for a chunk which has not loaded yet is not a hair lower than
         *  the chunks around it. (It used to sit a quarter of a block lower to keep out of the voxel
         *  terrain's way in the depth buffer; the far and the voxel pass have their own depth ranges now, the
         *  buffer is cleared between them, so they never compete.) */
        private const val LAND_Y_OFFSET = 1.0f

        /** How deep the soil of a column is: the top block and the three layers of dirt the generator puts under it. */
        private const val SOIL_DEPTH = 4f

        /** Water at least this deep is drawn (near-)opaque, so ground beneath it is skipped. */
        private const val DEEP_WATER = 10f

        /** Ground below this height is not built for a level at all. Water is at least ~90 %
         *  opaque in a slanted view through 3.5 blocks of it, and drawn solid beyond 300 blocks
         *  (see the water shader), so only the finest ring needs the sea floor in full; coarser
         *  levels keep just the shore. This is also what keeps seabed steps from ever outlining
         *  themselves through the surface. */
        private fun landFloor(level: Int): Float = when (level) {
            0 -> WATER_Y - DEEP_WATER
            1 -> WATER_Y - 3.5f
            else -> WATER_Y - 0.9f
        }

        /** Smallest block of deep water cells merged into one fan (a tile holds at most one fan
         *  per aligned block of that size). */
        private const val MIN_FAN_BLOCK = 4

        private const val MAX_QUEUED_EVENTS = 12

        /** Hard bound for the render distance the planner will work with (blocks). */
        const val MAX_RADIUS_BLOCKS = 20_000f

        /** What a published tile occupies on the GPU: 32-bit indices and float vertices (land: 7 floats
         *  per vertex, water: 6), both layers. */
        fun tileSizeBytes(tile: FarTile): Int {
            val land = tile.land.vertexCount.toLong() * LAND_FLOATS * 4 + tile.land.indices.size.toLong() * 4
            val water = tile.water.vertexCount.toLong() * 6 * 4 + tile.water.indices.size.toLong() * 4
            return (land + water).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }

        /** The most GPU memory the distant terrain may hold: a quarter of the app's heap ceiling (a proxy
         *  for how much memory the device has to share between CPU and GPU), between 96 and 192 MB. The
         *  two finest rings alone need ~45 MB and the level ladder keeps the 1000-chunk maximum around
         *  90 MB on ordinary terrain, so this is a safety ceiling (rough, mountainous worlds produce more
         *  wall geometry), not a limit the normal case meets. */
        fun budgetForThisDevice(): Long = try {
            (Runtime.getRuntime().maxMemory() / 4).coerceIn(96L * 1024 * 1024, 192L * 1024 * 1024)
        } catch (t: Throwable) {
            128L * 1024 * 1024
        }

        // Shading of the flat-coloured columns: exactly the voxel faces' (tops, and walls along each axis).
        private const val SHADE_TOP = FaceShade.TOP
        private const val SHADE_Z = FaceShade.ALONG_Z
        private const val SHADE_X = FaceShade.ALONG_X
        private const val REPLAN_DISTANCE = 24f

        // Tile key = level (3 bits) | tx (29 bits, signed) | tz (29 bits, signed).
        private const val COORD_MASK = 0x1FFFFFFFL

        fun tileKey(level: Int, tx: Int, tz: Int): Long =
            (level.toLong() shl 58) or ((tx.toLong() and COORD_MASK) shl 29) or (tz.toLong() and COORD_MASK)

        fun levelOf(key: Long): Int = (key ushr 58).toInt()
        fun tileX(key: Long): Int = (((key ushr 29) and COORD_MASK).toInt() shl 3) shr 3
        fun tileZ(key: Long): Int = ((key and COORD_MASK).toInt() shl 3) shr 3

        /** Deterministic 0..1 value for a cell of the LOD grid. */
        private fun cellRandom(gx: Int, gz: Int, salt: Int): Float {
            var h = gx * 73856093 xor gz * 19349663 xor salt * 83492791
            h = h xor (h ushr 15)
            h *= 739982445
            h = h xor (h ushr 13)
            return ((h ushr 8) and 0xFFFF) / 65536f
        }

        /** Smooth value noise (0..1) on an integer lattice, deterministic in the lattice
         *  coordinates and [salt]. */
        private fun valueNoise(x: Float, z: Float, salt: Int): Float {
            val xf = floor(x)
            val zf = floor(z)
            val fx = x - xf
            val fz = z - zf
            val ix = xf.toInt()
            val iz = zf.toInt()
            val sx = fx * fx * (3f - 2f * fx)
            val sz = fz * fz * (3f - 2f * fz)
            val a = cellRandom(ix, iz, salt)
            val b = cellRandom(ix + 1, iz, salt)
            val c = cellRandom(ix, iz + 1, salt)
            val d = cellRandom(ix + 1, iz + 1, salt)
            return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz
        }

        /**
         * The soft patchiness of a surface (0..1) at a world position: domain-warped fractal
         * value noise, so it forms irregular clusters at several scales instead of repeating
         * waves, and is a pure function of the position (the same at every level and from every
         * tile, never re-rolled). The finest octave is dropped on coarse levels, where a column
         * is wider than its wavelength and the octave would only turn into random speckle.
         */
        private fun patchNoise(wx: Float, wz: Float, step: Int): Float {
            val qx = wx + 55f * (valueNoise(wx * 0.011f, wz * 0.011f, 11) - 0.5f)
            val qz = wz + 55f * (valueNoise(wx * 0.011f + 17.3f, wz * 0.011f - 9.1f, 12) - 0.5f)
            val fine = if (step <= 4) 0.20f else if (step <= 8) 0.10f else 0f
            val v = (0.50f * valueNoise(qx * 0.0065f, qz * 0.0065f, 21) +
                0.30f * valueNoise(qx * 0.019f, qz * 0.019f, 22) +
                fine * valueNoise(qx * 0.057f, qz * 0.057f, 23)) / (0.80f + fine)
            // Sums of noise bunch up around the middle; stretch them so patches are distinct.
            return ((v - 0.5f) * 1.8f + 0.5f).coerceIn(0f, 1f)
        }
    }
}

/** Collects flat-coloured quads (all four vertices share one palette colour and shade) for a
 *  distant-terrain land tile. Vertex layout: position (3), uv (2), shade (1) and the height
 *  the vertex slides to as its level's ring ends (1), see [FarTerrain.LAND_FLOATS]. */
private class LodBuilder(initialQuads: Int) {
    private var floats = FloatArray(initialQuads * 4 * FarTerrain.LAND_FLOATS)
    private var indices = IntArray(initialQuads * 6)
    private var verts = 0
    private var idx = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    /** One quad; (0,1,2) and (0,2,3) must be counter-clockwise seen from the front. */
    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        u: Float, v: Float, shade: Float,
        m0: Float, m1: Float, m2: Float, m3: Float
    ) {
        val stride = FarTerrain.LAND_FLOATS
        if ((verts + 4) * stride > floats.size) floats = floats.copyOf(max(floats.size * 2, (verts + 4) * stride))
        if (idx + 6 > indices.size) indices = indices.copyOf(max(indices.size * 2, idx + 6))
        val f = floats
        var i = verts * stride
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = u; f[i++] = v; f[i++] = shade; f[i++] = m0
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = u; f[i++] = v; f[i++] = shade; f[i++] = m1
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = u; f[i++] = v; f[i++] = shade; f[i++] = m2
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = u; f[i++] = v; f[i++] = shade; f[i] = m3
        val ix = indices
        ix[idx++] = verts; ix[idx++] = verts + 1; ix[idx++] = verts + 2
        ix[idx++] = verts; ix[idx++] = verts + 2; ix[idx++] = verts + 3
        verts += 4
        if (y0 < minY) minY = y0
        if (y1 < minY) minY = y1
        if (y2 < minY) minY = y2
        if (y3 < minY) minY = y3
        if (y0 > maxY) maxY = y0
        if (y1 > maxY) maxY = y1
        if (y2 > maxY) maxY = y2
        if (y3 > maxY) maxY = y3
        // The slide targets count towards the tile's vertical extent too (a tile is culled
        // by that box), whichever way they go.
        if (m0 < minY) minY = m0
        if (m1 < minY) minY = m1
        if (m2 < minY) minY = m2
        if (m3 < minY) minY = m3
        if (m0 > maxY) maxY = m0
        if (m1 > maxY) maxY = m1
        if (m2 > maxY) maxY = m2
        if (m3 > maxY) maxY = m3
    }

    fun build(): MeshData {
        if (verts == 0) return MeshData.EMPTY
        return MeshData(
            floats.copyOf(verts * FarTerrain.LAND_FLOATS),
            indices.copyOf(idx),
            verts,
            minY,
            maxY
        )
    }
}
