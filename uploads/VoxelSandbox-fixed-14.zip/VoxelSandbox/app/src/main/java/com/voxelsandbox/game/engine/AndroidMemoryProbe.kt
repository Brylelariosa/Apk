package com.voxelsandbox.game.engine

import android.app.ActivityManager
import android.content.Context
import com.voxelsandbox.game.world.streaming.MemoryProbe
import com.voxelsandbox.game.world.streaming.MemoryReading

/**
 * Memory readings with the system's figures added to the heap's: how much memory the whole device has
 * free, the level below which Android starts killing apps, and whether it is below it. The calls go
 * to the activity manager service, so they belong on a background thread, once a second or so (the
 * world manager's scheduler does exactly that).
 */
class AndroidMemoryProbe(context: Context) : MemoryProbe {
    private val manager = context.applicationContext.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    private val info = ActivityManager.MemoryInfo()

    @Synchronized
    override fun read(): MemoryReading {
        val rt = Runtime.getRuntime()
        val used = rt.totalMemory() - rt.freeMemory()
        val max = rt.maxMemory()
        val am = manager ?: return MemoryReading(used, max)
        return try {
            am.getMemoryInfo(info)
            MemoryReading(used, max, info.availMem, info.threshold, info.lowMemory)
        } catch (t: Throwable) {
            MemoryReading(used, max)
        }
    }
}
