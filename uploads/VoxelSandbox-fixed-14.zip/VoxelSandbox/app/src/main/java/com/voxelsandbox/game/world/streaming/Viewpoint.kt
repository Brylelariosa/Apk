package com.voxelsandbox.game.world.streaming

import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Where the player is, which way they look and how fast they move: an immutable snapshot the
 * streaming threads read while the game thread keeps producing new ones (see
 * [ViewpointTracker]). Positions are in blocks, velocities in blocks per second.
 */
class Viewpoint(
    @JvmField val x: Float,
    @JvmField val z: Float,
    /** Unit vector of the horizontal look direction. */
    @JvmField val lookX: Float,
    @JvmField val lookZ: Float,
    @JvmField val velX: Float,
    @JvmField val velZ: Float
) {
    @JvmField val speed: Float = sqrt(velX * velX + velZ * velZ)

    /** Unit vector of the direction of travel (0, 0 when standing still). */
    @JvmField val dirX: Float = if (speed > 1.0e-3f) velX / speed else 0f
    @JvmField val dirZ: Float = if (speed > 1.0e-3f) velZ / speed else 0f

    companion object {
        val ORIGIN = Viewpoint(0f, 0f, 0f, -1f, 0f, 0f)
    }
}

/**
 * Turns the per-frame position stream of the game thread into [Viewpoint]s: the velocity is
 * smoothed over a third of a second so a single hitch or a one-frame stop does not flip the
 * heading, and a teleport (a respawn, a long fall back to the surface) resets it instead of
 * registering as an enormous speed.
 */
class ViewpointTracker {
    @Volatile
    var current: Viewpoint = Viewpoint.ORIGIN
        private set

    private var lastNs = 0L
    private var lastX = 0f
    private var lastZ = 0f
    private var vx = 0f
    private var vz = 0f

    /** Game thread only; cheap enough to call every frame. [yawRad]: 0 looks down -Z (see Camera). */
    fun update(x: Float, z: Float, yawRad: Float, nowNs: Long) {
        if (lastNs != 0L) {
            val dt = (nowNs - lastNs) / 1.0e9f
            if (dt > 1.0e-3f) {
                val dx = x - lastX
                val dz = z - lastZ
                if (dx * dx + dz * dz > TELEPORT_BLOCKS * TELEPORT_BLOCKS) {
                    vx = 0f
                    vz = 0f
                } else {
                    val alpha = 1f - exp(-dt / VELOCITY_TIME_CONSTANT)
                    vx += (dx / dt - vx) * alpha
                    vz += (dz / dt - vz) * alpha
                }
                lastNs = nowNs
                lastX = x
                lastZ = z
            }
        } else {
            lastNs = nowNs
            lastX = x
            lastZ = z
        }
        current = Viewpoint(x, z, sin(yawRad), -cos(yawRad), vx, vz)
    }

    private companion object {
        const val VELOCITY_TIME_CONSTANT = 0.35f
        const val TELEPORT_BLOCKS = 48f
    }
}

/**
 * How urgently a chunk is needed, as one number (smaller = sooner), used to order generation,
 * meshing and packing. It is an "effective distance" in chunks (times [UNIT]):
 *
 *  - the real distance to the player, so what is under and around the camera always comes first;
 *  - blended towards the distance from a point AHEAD of the player when they are moving (half
 *    the way at 12+ blocks/s), so the ground they are about to reach is ready before they arrive;
 *  - stretched for chunks outside the camera's view (up to +80 % directly behind), because they
 *    cannot be seen yet and the player can only turn so fast;
 *  - stretched for chunks behind the direction of travel while moving.
 *
 * The chunks closest to the player ([NEAR_CHUNKS]) are exempt from every adjustment: those are
 * the ones the player stands on and bumps into.
 */
object ChunkPriority {
    const val UNIT = 64f
    private const val INV_CHUNK = 1f / 16f
    private const val NEAR_CHUNKS = 1.6f

    private const val MOVING_SPEED = 12f // blocks/s at which the look-ahead is fully applied
    private const val LEAD_SECONDS = 0.9f
    private const val MAX_LEAD_CHUNKS = 7f

    private const val VIEW_EDGE_COS = 0.45f // cos of the angle where "in view" ends (about 63 degrees)
    private const val VIEW_BACK_COS = -0.55f
    private const val VIEW_PENALTY = 0.8f

    private const val MOVE_EDGE_COS = 0.2f
    private const val MOVE_BACK_COS = -0.7f
    private const val MOVE_PENALTY = 0.6f

    /** Priority of the chunk with chunk coordinates [cx], [cz]. */
    fun score(cx: Int, cz: Int, v: Viewpoint): Long = scoreAt(cx + 0.5f, cz + 0.5f, v)

    /** Priority of the point ([chunkX], [chunkZ]) given in (fractional) chunk coordinates. */
    fun scoreAt(chunkX: Float, chunkZ: Float, v: Viewpoint): Long {
        val rx = chunkX - v.x * INV_CHUNK
        val rz = chunkZ - v.z * INV_CHUNK
        val d = sqrt(rx * rx + rz * rz)
        if (d < NEAR_CHUNKS) return (d * UNIT).toLong()

        val moving = min(1f, v.speed / MOVING_SPEED)
        var dEff = d
        if (moving > 0f) {
            val lead = min(v.speed * INV_CHUNK * LEAD_SECONDS, MAX_LEAD_CHUNKS)
            val lx = rx - v.dirX * lead
            val lz = rz - v.dirZ * lead
            val dLead = sqrt(lx * lx + lz * lz)
            dEff = d + (dLead - d) * 0.5f * moving
        }

        val cosLook = (rx * v.lookX + rz * v.lookZ) / d
        var factor = 1f + VIEW_PENALTY * smooth01((VIEW_EDGE_COS - cosLook) / (VIEW_EDGE_COS - VIEW_BACK_COS))
        if (moving > 0f) {
            val cosMove = (rx * v.dirX + rz * v.dirZ) / d
            factor *= 1f + MOVE_PENALTY * moving * smooth01((MOVE_EDGE_COS - cosMove) / (MOVE_EDGE_COS - MOVE_BACK_COS))
        }
        return (dEff * factor * UNIT).toLong()
    }

    private fun smooth01(t: Float): Float {
        val c = if (t < 0f) 0f else if (t > 1f) 1f else t
        return c * c * (3f - 2f * c)
    }
}

/** Offsets that place the three kinds of job (and the rare special cases) relative to each other. */
object JobPriority {
    /** A player edit: runs before anything else and is uploaded the frame it arrives. */
    const val URGENT = Long.MIN_VALUE / 4

    /** Packing a region into upload buffers is cheap and is the last step before terrain shows. */
    const val PACK_BIAS = -4_000_000L

    /** Meshing runs ahead of generating a chunk the same distance away: it finishes work that is
     *  already paid for and brings terrain on screen sooner than starting another chunk. */
    const val MESH_BIAS = -160L

    /** Chunks generated ahead of need (outside the wanted ring) only run when nothing else does. */
    const val SPECULATIVE_BIAS = 1_000_000L
}
