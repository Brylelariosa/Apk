package com.voxelsandbox.game.gl

import android.opengl.GLES30
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The cloud layer: thick, blocky, shaded clouds with a flat base and a bumpy top, like
 * stacks of big white boxes (cell size [CELL] blocks). The whole pattern is one static mesh
 * built once at start-up, for a square tile of [TILE] blocks whose cloud density repeats
 * seamlessly in both directions; it is drawn as 3 x 3 copies around the camera with a single
 * instanced draw call, so there is no per-frame CPU work except setting a few uniforms.
 *
 * Looks:
 *  - Every cloud cell has a thickness (5..16 blocks) that grows with the local density, so
 *    banks have domes and thin wisps at their edges.
 *  - Light is baked per vertex: tops are white, sides facing the sun are bright and the far
 *    sides cool grey; undersides are bluish grey and darkest where the cloud is thickest
 *    (mean thickness of the cells meeting at a vertex), which gives each cloud a soft,
 *    rounded underbelly instead of a flat ceiling.
 *  - The clouds are opaque. Distance does not fade them with alpha but dissolves their
 *    colour into the sky gradient itself (the fragment shader knows the sky's formula), so
 *    the far edge of the cloud field is invisible and the depth buffer behaves.
 *  - They drift with the wind: the pattern slides by exactly one tile over the 1,000 s the
 *    texture clock runs before wrapping, so the wrap never shows.
 *
 * Distance bands: the far and the near part of the sky are drawn in different depth ranges
 * (see GameRenderer), so [draw] takes the band of 3D distances to draw and discards the rest.
 * GL-thread only.
 */
class CloudRenderer {
    private lateinit var program: ShaderProgram
    private var uViewProj = 0
    private var uOrigin = 0
    private var uTile = 0
    private var uBaseY = 0
    private var uEye = 0
    private var uRadius = 0
    private var uBand = 0
    private var uHorizon = 0
    private var uZenith = 0

    private var vao = 0
    private var vbo = 0
    private var ibo = 0
    private var indexCount = 0

    // ---- mesh under construction (CPU only, dropped after upload) ----
    private var verts = FloatArray(0)
    private var vertCount = 0
    private var idx = ShortArray(0)
    private var idxCount = 0
    private var thickness = IntArray(0)

    /** Call from onSurfaceCreated (a new GL context needs a fresh program and buffers). */
    fun init() {
        program = ShaderProgram(Shaders.CLOUD_VERTEX, Shaders.CLOUD_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uOrigin = program.uniform("uOrigin")
        uTile = program.uniform("uTile")
        uBaseY = program.uniform("uBaseY")
        uEye = program.uniform("uEye")
        uRadius = program.uniform("uRadius")
        uBand = program.uniform("uBand")
        uHorizon = program.uniform("uHorizon")
        uZenith = program.uniform("uZenith")
        buildMesh()
        upload()
        verts = FloatArray(0)
        idx = ShortArray(0)
        thickness = IntArray(0)
    }

    /**
     * Draws the clouds that are between [bandMin] and [bandMax] blocks (3D distance) from the
     * eye and closer than [radius] (where they have faded into the sky). Uses whatever
     * view-projection [frame] holds; depth testing and writing stay on, blending off, culling on.
     */
    fun draw(frame: FrameState, radius: Float, bandMin: Float, bandMax: Float) {
        if (radius < 8f || indexCount == 0) return
        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)

        // The pattern's world position: its drift (blocks) grows linearly with the texture
        // clock and is exactly one tile at the clock's wrap, so it jumps by a whole period.
        val drift = frame.textureTime.toDouble() * (TILE / FrameState.TEXTURE_TIME_PERIOD)
        val ox = floor((frame.eyeX - drift) / TILE) * TILE - TILE + drift
        val oz = floor(frame.eyeZ.toDouble() / TILE) * TILE - TILE
        // Everything the shaders get is relative to the camera origin (see FrameState.originX): the
        // tile origin and the cloud base are computed in double, shifted, and only then narrowed.
        GLES30.glUniform2f(uOrigin, (ox - frame.originX).toFloat(), (oz - frame.originZ).toFloat())
        GLES30.glUniform1f(uTile, TILE.toFloat())
        GLES30.glUniform1f(uBaseY, BASE_Y - frame.originY)
        GLES30.glUniform3f(uEye, frame.eyeRelX, frame.eyeRelY, frame.eyeRelZ)
        GLES30.glUniform1f(uRadius, radius)
        GLES30.glUniform2f(uBand, bandMin, bandMax)
        GLES30.glUniform3f(uHorizon, Atmosphere.HORIZON_R, Atmosphere.HORIZON_G, Atmosphere.HORIZON_B)
        GLES30.glUniform3f(uZenith, Atmosphere.ZENITH_R, Atmosphere.ZENITH_G, Atmosphere.ZENITH_B)

        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, indexCount, GLES30.GL_UNSIGNED_SHORT, 0, 9)
        GLES30.glBindVertexArray(0)
    }

    // ---- the mesh --------------------------------------------------------------------

    private fun buildMesh() {
        verts = FloatArray(4096 * 16)
        idx = ShortArray(4096 * 6)
        vertCount = 0
        idxCount = 0
        thickness = IntArray(GRID * GRID)
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val d = density(i, j)
                if (d > THRESHOLD) {
                    val k = smooth(THRESHOLD, THRESHOLD + 0.20f, d)
                    thickness[j * GRID + i] = MIN_T + ((MAX_T - MIN_T) * k).roundToInt()
                }
            }
        }
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val t = thickness[j * GRID + i]
                if (t == 0) continue
                val x0 = i * CELL
                val x1 = (i + 1) * CELL
                val z0 = j * CELL
                val z1 = (j + 1) * CELL
                // underside (faces down)
                quad(
                    x0, 0f, z0, x1, 0f, z0, x1, 0f, z1, x0, 0f, z1,
                    bottomShade(i, j), bottomShade(i + 1, j), bottomShade(i + 1, j + 1), bottomShade(i, j + 1)
                )
                // top (faces up)
                val ty = t.toFloat()
                quad(
                    x0, ty, z0, x0, ty, z1, x1, ty, z1, x1, ty, z0,
                    topShade(i, j), topShade(i, j + 1), topShade(i + 1, j + 1), topShade(i + 1, j)
                )
            }
        }
        // sides: only where the neighbouring cell is thinner (or empty), as tall as the step
        for (j in 0 until GRID) {
            for (i in 0 until GRID) {
                val t = thickness[j * GRID + i]
                if (t == 0) continue
                for (k in 0 until 4) {
                    val tn = thicknessAt(i + SIDE_DX[k], j + SIDE_DZ[k])
                    if (tn >= t) continue
                    val x0 = i * CELL
                    val x1 = (i + 1) * CELL
                    val z0 = j * CELL
                    val z1 = (j + 1) * CELL
                    val ylo = tn.toFloat()
                    val yhi = t.toFloat()
                    var s = 0.80f + 0.14f * (SIDE_DX[k] * SUN_X + SIDE_DZ[k] * SUN_Z)
                    s *= 0.97f + 0.03f * cellRand(i + 7, j + 3)
                    val sLo = s * (if (tn == 0) 0.86f else 0.95f)
                    when (k) {
                        0 -> quad(x1, ylo, z0, x1, yhi, z0, x1, yhi, z1, x1, ylo, z1, sLo, s, s, sLo)
                        1 -> quad(x0, ylo, z0, x0, ylo, z1, x0, yhi, z1, x0, yhi, z0, sLo, sLo, s, s)
                        2 -> quad(x0, ylo, z1, x1, ylo, z1, x1, yhi, z1, x0, yhi, z1, sLo, sLo, s, s)
                        else -> quad(x1, ylo, z0, x0, ylo, z0, x0, yhi, z0, x1, yhi, z0, sLo, sLo, s, s)
                    }
                }
            }
        }
        indexCount = idxCount
    }

    private fun thicknessAt(i: Int, j: Int): Int =
        thickness[Math.floorMod(j, GRID) * GRID + Math.floorMod(i, GRID)]

    /** Mean thickness of the four cells meeting at lattice vertex (vi, vj), as 0..1 of a
     *  "full" cloud. */
    private fun thick01(vi: Int, vj: Int): Float {
        val sum = thicknessAt(vi - 1, vj - 1) + thicknessAt(vi, vj - 1) + thicknessAt(vi - 1, vj) + thicknessAt(vi, vj)
        return min(1f, sum * 0.25f / 11f)
    }

    private fun bottomShade(vi: Int, vj: Int): Float = 0.84f - 0.34f * thick01(vi, vj) + 0.05f * vertexJitter(vi, vj)

    private fun topShade(vi: Int, vj: Int): Float = 0.88f + 0.12f * thick01(vi, vj) + 0.04f * vertexJitter(vi + 5, vj + 9)

    private fun vertexJitter(i: Int, j: Int): Float = cellRand(i * 3 + 11, j * 5 + 17) - 0.5f

    private fun vert(x: Float, y: Float, z: Float, shade: Float) {
        if ((vertCount + 1) * 4 > verts.size) verts = verts.copyOf(verts.size * 2)
        val o = vertCount * 4
        verts[o] = x
        verts[o + 1] = y
        verts[o + 2] = z
        verts[o + 3] = shade
        vertCount++
    }

    /** One quad (counter-clockwise seen from outside), two triangles. */
    private fun quad(
        x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float, x3: Float, y3: Float, z3: Float,
        s0: Float, s1: Float, s2: Float, s3: Float
    ) {
        val b = vertCount
        vert(x0, y0, z0, s0)
        vert(x1, y1, z1, s1)
        vert(x2, y2, z2, s2)
        vert(x3, y3, z3, s3)
        if (idxCount + 6 > idx.size) idx = idx.copyOf(idx.size * 2)
        idx[idxCount++] = b.toShort()
        idx[idxCount++] = (b + 1).toShort()
        idx[idxCount++] = (b + 2).toShort()
        idx[idxCount++] = b.toShort()
        idx[idxCount++] = (b + 2).toShort()
        idx[idxCount++] = (b + 3).toShort()
    }

    private fun upload() {
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0)
        vao = ids[0]
        GLES30.glGenBuffers(1, ids, 0)
        vbo = ids[0]
        GLES30.glGenBuffers(1, ids, 0)
        ibo = ids[0]

        GLES30.glBindVertexArray(vao)
        val vb = ByteBuffer.allocateDirect(vertCount * 16).order(ByteOrder.nativeOrder())
        vb.asFloatBuffer().put(verts, 0, vertCount * 4)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, vertCount * 16, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 16, 0)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 1, GLES30.GL_FLOAT, false, 16, 12)

        val ib = ByteBuffer.allocateDirect(idxCount * 2).order(ByteOrder.nativeOrder())
        ib.asShortBuffer().put(idx, 0, idxCount)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idxCount * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
    }

    // ---- the density field (tileable value noise) ---------------------------------------

    /** Cloud density in about 0..1 at cell (i, j); repeats every [GRID] cells. Three octaves:
     *  big banks, puffs, and detail. */
    private fun density(i: Int, j: Int): Float {
        val x = i + 0.5f
        val y = j + 0.5f
        return 0.50f * valueNoise(x, y, 16, 1) + 0.30f * valueNoise(x, y, 8, 2) + 0.20f * valueNoise(x, y, 4, 3)
    }

    /** Smooth value noise in 0..1 whose lattice repeats every [GRID] / [cell] steps. */
    private fun valueNoise(x: Float, y: Float, cell: Int, salt: Int): Float {
        val period = GRID / cell
        val fx = x / cell
        val fy = y / cell
        val ix = floor(fx).toInt()
        val iy = floor(fy).toInt()
        var tx = fx - ix
        var ty = fy - iy
        tx = tx * tx * (3f - 2f * tx)
        ty = ty * ty * (3f - 2f * ty)
        val a = lattice(ix, iy, period, salt)
        val b = lattice(ix + 1, iy, period, salt)
        val c = lattice(ix, iy + 1, period, salt)
        val d = lattice(ix + 1, iy + 1, period, salt)
        val top = a + (b - a) * tx
        val bottom = c + (d - c) * tx
        return top + (bottom - top) * ty
    }

    private fun lattice(ix: Int, iy: Int, period: Int, salt: Int): Float {
        val x = Math.floorMod(ix, period)
        val y = Math.floorMod(iy, period)
        var h = x * 374761393 + y * 668265263 + salt * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return ((h ushr 8) and 0xFFFF) / 65535f
    }

    private fun cellRand(i: Int, j: Int): Float {
        var h = (i * 73856093) xor (j * 19349663)
        h = (h xor (h ushr 15)) * 739982445
        h = h xor (h ushr 13)
        return ((h ushr 8) and 0xFF) / 255f
    }

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    companion object {
        /** Cells per tile side; the density field repeats every GRID cells. */
        private const val GRID = 64

        /** Blocks per cloud cell. */
        private const val CELL = 32f

        /** Blocks per tile side. */
        const val TILE = GRID * 32

        /** Height (world Y) of the underside of the clouds. Above the plains and the
         *  foothills, below the tallest peaks, which poke through. */
        const val BASE_Y = 212f

        /** Density above this is cloud; about a third of the sky ends up covered. */
        private const val THRESHOLD = 0.575f
        private const val MIN_T = 5
        private const val MAX_T = 16

        // Direction the sun is in on the horizontal plane (see Atmosphere.SUN), baked into
        // the shade of the side faces.
        private const val SUN_X = 0.63f
        private const val SUN_Z = -0.77f

        // Neighbour offsets for +x, -x, +z, -z.
        private val SIDE_DX = intArrayOf(1, -1, 0, 0)
        private val SIDE_DZ = intArrayOf(0, 0, 1, -1)
    }
}
