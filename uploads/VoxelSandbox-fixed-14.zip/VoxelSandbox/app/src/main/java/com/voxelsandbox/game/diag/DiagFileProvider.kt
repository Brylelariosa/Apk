package com.voxelsandbox.game.diag

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/**
 * Serves the exported diagnostic files (see [DiagLog.exportFiles]) to other apps through
 * Android's share sheet. The project has no AndroidX dependency, so this is the small subset of
 * what FileProvider does that sharing needs: read-only access to files in one folder, each
 * granted to the receiving app through a content URI (so the files stay private otherwise: the
 * provider is not exported, and access exists only while a share is in progress).
 *
 * URI form: content://<package>.diagfiles/share/<file name>
 */
class DiagFileProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    private fun resolve(uri: Uri): File? {
        val ctx = context ?: return null
        val name = uri.lastPathSegment ?: return null
        // The name is a bare file name: no directories, no way out of the share folder.
        if (name.isEmpty() || name.contains('/') || name.contains('\\') || name.contains("..")) return null
        val file = File(DiagLog.shareDir(ctx), name)
        return if (file.isFile) file else null
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor? {
        val file = resolve(uri) ?: return null
        val columns: Array<out String> = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val cursor = MatrixCursor(columns, 1)
        val row = arrayOfNulls<Any>(columns.size)
        for (i in columns.indices) {
            row[i] = when (columns[i]) {
                OpenableColumns.DISPLAY_NAME -> file.name
                OpenableColumns.SIZE -> file.length()
                else -> null
            }
        }
        cursor.addRow(row)
        return cursor
    }

    override fun getType(uri: Uri): String? = if (resolve(uri) != null) "text/plain" else null

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val file = resolve(uri) ?: throw FileNotFoundException(uri.toString())
        if (mode != "r") throw SecurityException("read-only")
        return ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
