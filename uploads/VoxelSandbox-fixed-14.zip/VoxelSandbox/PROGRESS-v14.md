# VoxelSandbox v14 work log

Everything below is checked by compile (kotlinc 1.9.22 against the android-34 stubs) and by JVM / software-renderer
simulation. **Nothing here has been run on a phone**, and the Gradle/AGP build has not been run in the sandbox that
made this version (GitHub Actions is still the real build). CHANGELOG.md has the numbers and the full wording.

## Done
1. **Chunk flicker**: five causes found in the device log and removed. Memory policy works from evidence and moves
   in bounded steps (world/streaming/MemoryPolicy.kt); the far-terrain byte ceiling cuts the plan from its far end
   with hysteresis (world/far/FarBudget.kt); the hand-over radius follows the nominal edge, rate-limited, with a
   per-column coverage mask (gl/Handover.kt, gl/CoverageMask.kt); packs carry a sequence number and an overtaken pack
   is dropped (world/streaming/RegionVersions.kt); redundant remeshing is gone (generation halo, below).
2. **LOD ring**: one shared face-shade table (world/mesh/FaceShade.kt) and one shared grain (gl/BlockGrain.kt) for
   voxel and distant terrain; distant tone patches start at zero at the voxel edge; distant cliffs are dirt/stone
   like the voxel ones; distant columns sit exactly at the voxel top face; the finest ring is handed over per tile.
   Software renderer: no visible circle in the top-down pictures; the darkness of the far terrain against the voxel
   terrain went 7.2 / 5.7 / 3.2 -> 4.0 / 2.5 / 1.0 luminance steps (of 255) in the 200-240 / 240-280 / 280-320 bands.
3. **Distant terrain shape**: heights measured against the real generator (unbiased, peaks kept). The remaining
   3-6 block rms stair-step error on mountains is inherent to flat-topped columns; two estimators tried, not adopted.
4. **Texture stability**: camera-relative rendering (`uCamOrigin`), `textureGrad` on unwrapped tile coordinates,
   sharp-bilinear magnification fading to trilinear, world-fixed dissolve noise (gl/VoxelShader.kt, gl/Shaders.kt).
5. **Texture variation**: per-block hash picks mirror/rotate in the shader, per texture rules, stable across reloads,
   merged quads and LOD (world/mesh/TextureVariants.kt). Logs/bark/side fringes keep their direction.
6. **Greedy meshing**: real rectangle merging per direction and layer of a sub-chunk (ChunkMesher.emitGreedy);
   AO, cave light, transparency, water and block boundaries preserved. 1416 -> 1116 triangles per chunk (-21%),
   radius 10, simulation.
7. **Performance**: generation halo (about 1.0 whole mesh job per chunk of the ring, partial redo jobs 398-13,836 ->
   0-18 per run), far-terrain tiles uploaded under a byte/time budget shared with the regions, one admission rule for
   region uploads (world/streaming/UploadBudget.kt), mesh-job counters on the stats line.
8. Earlier in v14: Automatic Render Distance switch, 1000-chunk maximum, extreme-distance safety, ChunkMap, streaming
   core, generator output verified bit-identical (SHA-256).

## Not done, and why
- The far-terrain triangle count (about 1.0-1.2 million land triangles per test scene before frustum culling, 60-70%
  walls) is as it was: merging colours that look alike saved about 1%, and anything bigger changes the look.
- Region repacking still uploads 1.4-3x the ideal bytes in fast flights (the granularity is a 4x4-column region).
- A cold start or a teleport takes about 0.1 s longer and uploads about 10% more bytes because of the halo.

## Needs a phone (unverified)
- Frame rate, stutter and upload hitches on a Mali-G52 (Infinix Hot 11 2022); the simulation's worst-frame numbers
  are noise, only its counts (jobs, bytes, holes) are meaningful.
- `EDGE_GROW = 6.0e-5` (crack hiding between merged quads of different sizes) and the cost of the new fragment
  shader on Mali.
- The coastline and water at the voxel/distant hand-over, trees, AO and risers in the dissolve zone.
- How Android's real memory signals drive the memory policy, and the effect of the far-upload budget on frame times.
- The Gradle build itself.

## Tools used (not shipped)
JVM harnesses for streaming flights, halo/ring changes, memory per chunk, far-terrain quads, generator hash
(golden `fec83b834d0dd9950844e81dda29afe3` at radius 6), and a headless-Chromium / SwiftShader renderer for the LOD
pictures. They live in the sandbox's scratch area, not in this project.
