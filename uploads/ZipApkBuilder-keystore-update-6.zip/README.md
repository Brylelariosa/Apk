# ZIP → APK Builder

An Android app that uploads your Android project ZIP to GitHub, triggers GitHub Actions to build an APK, and downloads the result — all from your phone.

---

## How it works

```
Your phone                        GitHub
──────────                        ──────
 Pick ZIP  ──── upload ────►  /uploads/project.zip
                                    │
                               push event
                                    ▼
                           GitHub Actions runs
                           build.yml workflow
                                    │
                            assembleDebug
                                    │
                           APK artifact uploaded
                                    │
 App polls ◄─── artifact URL ───────┘
     │
 Download & install APK
```

---

## One-time GitHub setup (5 minutes)

### 1 — Create a dedicated GitHub repository

- Name it anything, e.g. `apk-builder-repo`
- Set to **Private** (your code stays private)
- Initialize with a `README` so the default branch (`main`) exists

### 2 — Add the workflow file

In the repo, create `.github/workflows/build.yml` and paste the contents of the `build.yml` file included with this project.

### 3 — Create a Personal Access Token

1. GitHub → **Settings → Developer settings → Personal access tokens → Tokens (classic)**
2. Click **Generate new token (classic)**
3. Select scopes:
   - `repo` (full control of private repositories)
   - `workflow` (update GitHub Actions workflows)
4. Copy the token — you will not see it again.

---

## App setup

### Build this app

Open `ZipApkBuilder/` in Android Studio and run on your device, **or** zip it up and build it with the same workflow!

### Configure in the app

| Field | What to enter |
|---|---|
| **Personal Access Token** | The `ghp_…` token from step 3 |
| **Repository Owner** | Your GitHub username |
| **Repository Name** | `apk-builder-repo` (or whatever you named it) |
| **Branch** | `main` |

Settings are saved automatically — you only need to enter them once.

---

## Using the app

1. Tap **Pick ZIP File** → select your Android project ZIP
2. Tap **Upload & Build**
3. Watch the log — the app uploads the ZIP, waits for GitHub Actions, and polls the build status
4. When the build succeeds, tap **Download APK** → the APK downloads and the installer opens

---

## Requirements for projects you build

- The ZIP must contain an Android Gradle project with `settings.gradle` or `settings.gradle.kts`
- The project must build with `./gradlew assembleDebug`
- ZIP raw size should be under ~70 MB (GitHub Contents API limit)

---

## Build time

| Stage | Typical time |
|---|---|
| Upload | 10–60 s (depends on ZIP size) |
| GitHub Actions spin-up | 30–60 s |
| Gradle build (cold) | 3–8 min |
| Gradle build (cached) | 1–3 min |
| APK download | 5–20 s |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Upload fails 422 | Token lacks `repo` scope, or repo/owner is wrong |
| No workflow run detected | Ensure `build.yml` is committed to the branch |
| Build fails | Open `github.com/{owner}/{repo}/actions` to read the full log |
| APK not found | Check the `Upload APK artifact` step in the workflow log |
| ZIP too large | Remove `build/`, `.gradle/`, `.idea/` folders before zipping |

---

## Project structure

```
ZipApkBuilder/
├── app/src/main/
│   ├── java/com/zipapkbuilder/MainActivity.kt   ← all logic
│   ├── res/layout/activity_main.xml
│   ├── res/xml/file_paths.xml
│   └── AndroidManifest.xml
├── .github/workflows/build.yml                  ← copy to your builder repo
├── build.gradle
├── settings.gradle
└── README.md
```
