package com.zipapkbuilder

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.NestedScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    private lateinit var etToken: EditText
    private lateinit var tvOwnerInfo: TextView
    private lateinit var etRepo: EditText
    private lateinit var etBranch: EditText
    private lateinit var btnPickZip: Button
    private lateinit var tvFileName: TextView
    private lateinit var btnUploadBuild: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnDownloadApk: Button
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: NestedScrollView
    private lateinit var btnManageZips: Button
    private lateinit var btnWorkflowLog: Button
    private lateinit var btnDownloadLogs: Button
    private lateinit var btnBrowseArtifacts: Button
    private lateinit var btnCopyLog: Button
    private lateinit var btnSaveLog: Button
    private lateinit var etKeystorePass: EditText
    private lateinit var etKeyAlias: EditText
    private lateinit var btnGenerateKeystore: Button
    private lateinit var tvKeystoreStatus: TextView

    // ── State ────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var selectedZipUri: Uri? = null
    private var selectedZipName = ""
    private var artifactDownloadUrl: String? = null
    private var isBusy = false

    private var lastOwner      = ""
    private var lastRemotePath = ""
    private var lastFileSha: String? = null
    private var lastRunId: Long = -1L

    // ── SharedPreferences keys ────────────────────────────────────────────────
    companion object {
        private const val PREF_ARTIFACT_URL   = "artifact_url"
        private const val PREF_ARTIFACT_NAME  = "artifact_name"
        private const val PREF_LAST_RUN_ID    = "last_run_id"
        private const val PREF_LAST_OWNER     = "last_owner"
        private const val PREF_LAST_REPO_KEY  = "last_repo_saved"
        private const val PREF_KEYSTORE_ALIAS = "keystore_alias"
        private const val PREF_KEYSTORE_SAVED = "keystore_saved"
    }

    // ── Embedded workflow YAML ────────────────────────────────────────────────
    private val WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Build APK

on:
  push:
    branches: [ main, master ]
    paths:
      - 'uploads/**'
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          token: ${d}{{ secrets.GITHUB_TOKEN }}

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Cache NDK and CMake
        id: cache-ndk
        uses: actions/cache@v4
        with:
          path: |
            ${d}{{ env.ANDROID_HOME }}/ndk/25.2.9519653
            ${d}{{ env.ANDROID_HOME }}/ndk/25.1.8937393
            ${d}{{ env.ANDROID_HOME }}/cmake/3.22.1
          key: ndk-25.2.9519653-25.1.8937393-cmake-3.22.1

      - name: Install NDK and CMake
        run: |
          for NDK_VER in "25.2.9519653" "25.1.8937393"; do
            if [ ! -d "${d}ANDROID_SDK_ROOT/ndk/${d}NDK_VER" ]; then
              echo "Installing NDK ${d}NDK_VER..."
              sdkmanager --install "ndk;${d}NDK_VER"
            else
              echo "NDK ${d}NDK_VER already present"
            fi
          done
          if [ ! -d "${d}ANDROID_SDK_ROOT/cmake/3.22.1" ]; then
            sdkmanager --install "cmake;3.22.1"
          fi
          echo "ANDROID_NDK_HOME=${d}ANDROID_SDK_ROOT/ndk/25.2.9519653" >> ${d}GITHUB_ENV

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'
          cache-read-only: false

      - name: Unzip project
        run: |
          ZIP=${d}(find . -path './.git' -prune -o -maxdepth 3 -name "*.zip" -printf "%T@ %p\n" | sort -rn | head -1 | cut -d" " -f2-)
          if [ -z "${d}ZIP" ]; then
            echo "##[error]No ZIP file found in repository!"
            exit 1
          fi
          ZIP_NAME=${d}(basename "${d}ZIP" .zip)
          echo "zip_name=${d}ZIP_NAME" >> ${d}GITHUB_ENV
          echo "zip_path=${d}ZIP" >> ${d}GITHUB_ENV
          echo "Found zip: ${d}ZIP"
          unzip -q "${d}ZIP" -d extracted

      - name: Find project directory
        id: find_project
        run: |
          RESULT=${d}(find extracted -maxdepth 4 \( -name "settings.gradle" -o -name "settings.gradle.kts" \) | head -1)
          if [ -z "${d}RESULT" ]; then
            echo "##[error]No settings.gradle found inside the zip!"
            find extracted | sort
            exit 1
          fi
          PROJECT_DIR=${d}(dirname "${d}RESULT")
          echo "Found project at: ${d}PROJECT_DIR"
          echo "project_dir=${d}PROJECT_DIR" >> ${d}GITHUB_OUTPUT

      - name: Cache CMake / C++ build outputs
        uses: actions/cache@v4
        with:
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/.cxx
          key: cxx-debug-${d}{{ hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp') }}
          restore-keys: cxx-debug-

      - name: Fetch gradle-wrapper.jar
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          GRADLE_VERSION="8.6"
          JAR="gradle/wrapper/gradle-wrapper.jar"
          mkdir -p gradle/wrapper
          curl --fail --silent --show-error --location \
            "https://raw.githubusercontent.com/gradle/gradle/v${d}{GRADLE_VERSION}.0/gradle/wrapper/gradle-wrapper.jar" \
            -o "${d}JAR"
          SIZE=${d}(stat -c%s "${d}JAR")
          if [ "${d}SIZE" -lt 10000 ]; then
            echo "ERROR: gradle-wrapper.jar too small (${d}{SIZE} bytes)"
            exit 1
          fi

      - name: Make gradlew executable
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: chmod +x gradlew && sed -i 's/\r//' gradlew

      - name: Decode keystore (if available)
        id: keystore
        run: |
          if [ -n "${d}{{ secrets.KEYSTORE_BASE64 }}" ]; then
            echo "${d}{{ secrets.KEYSTORE_BASE64 }}" | base64 --decode > ${d}RUNNER_TEMP/release.jks
            echo "KEYSTORE_PATH=${d}RUNNER_TEMP/release.jks" >> ${d}GITHUB_ENV
            echo "HAS_KEYSTORE=true" >> ${d}GITHUB_ENV
            echo "Keystore decoded ✓"
          else
            echo "HAS_KEYSTORE=false" >> ${d}GITHUB_ENV
            echo "No KEYSTORE_B64 secret — building debug APK"
          fi

      - name: Build APK
        id: build
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          if [ "${d}{{ env.HAS_KEYSTORE }}" = "true" ]; then
            ./gradlew assembleRelease --no-daemon --configuration-cache --build-cache --parallel \
              -Pandroid.injected.signing.store.file="${d}{{ env.KEYSTORE_PATH }}" \
              -Pandroid.injected.signing.store.password="${d}{{ secrets.STORE_PASSWORD }}" \
              -Pandroid.injected.signing.key.alias="${d}{{ secrets.KEY_ALIAS }}" \
              -Pandroid.injected.signing.key.password="${d}{{ secrets.KEY_PASSWORD }}"
          else
            ./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
          fi
        env:
          ANDROID_NDK_HOME: ${d}{{ env.ANDROID_NDK_HOME }}

      - name: Locate APK
        id: apk
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          if [ "${d}{{ env.HAS_KEYSTORE }}" = "true" ]; then
            APK_PATH=${d}(find app/build/outputs/apk/release -name "*.apk" | head -1)
            echo "APK type: release"
          else
            APK_PATH=${d}(find app/build/outputs/apk/debug -name "*.apk" | head -1)
            echo "APK type: debug"
          fi
          echo "apk_path=${d}APK_PATH" >> ${d}GITHUB_OUTPUT

      - name: Upload APK artifact
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: ${d}{{ env.zip_name }}-${d}{{ env.HAS_KEYSTORE == 'true' && 'release' || 'debug' }}-v${d}{{ github.run_number }}
          path: ${d}{{ steps.find_project.outputs.project_dir }}/${d}{{ steps.apk.outputs.apk_path }}
          retention-days: 30

      - name: Clean up - delete zip after successful build
        if: success()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP after build #${d}{{ github.run_number }} [skip ci]"
            git push
          fi

      - name: Clean up - delete zip after failed build
        if: failure()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP (build failed #${d}{{ github.run_number }}) [skip ci]"
            git push
          fi
        """.trimIndent()
    }

    // ── Keystore-generation workflow YAML ────────────────────────────────────
    private val KEYSTORE_WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Generate Keystore

on:
  workflow_dispatch:
    inputs:
      alias:
        description: 'Key alias'
        required: true
        default: 'release'
      password:
        description: 'Keystore password'
        required: true
      validity_days:
        description: 'Validity in days'
        required: false
        default: '10950'
      pat_token:
        description: 'GitHub PAT (used only to save secrets, masked immediately)'
        required: true

jobs:
  keygen:
    runs-on: ubuntu-latest
    permissions:
      contents: read

    steps:
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Generate unique keystore
        id: gen
        run: |
          ALIAS="${d}{{ github.event.inputs.alias }}"
          PASS="${d}{{ github.event.inputs.password }}"
          DAYS="${d}{{ github.event.inputs.validity_days }}"
          TIMESTAMP=${d}(date +%Y%m%d%H%M%S)
          STORE_NAME="keystore_${d}{TIMESTAMP}.jks"

          keytool -genkeypair \
            -alias "${d}ALIAS" \
            -keyalg RSA \
            -keysize 2048 \
            -validity ${d}DAYS \
            -storepass "${d}PASS" \
            -keypass "${d}PASS" \
            -dname "CN=Android Debug, O=Android, C=US" \
            -storetype JKS \
            -keystore "${d}STORE_NAME"

          B64=${d}(base64 -w0 "${d}STORE_NAME")
          echo "keystore_b64=${d}B64"   >> ${d}GITHUB_OUTPUT
          echo "store_name=${d}STORE_NAME" >> ${d}GITHUB_OUTPUT
          echo "alias=${d}ALIAS"        >> ${d}GITHUB_OUTPUT
          echo "Generated: ${d}STORE_NAME"

      - name: Save all secrets to GitHub via API
        env:
          OWNER:    ${d}{{ github.repository_owner }}
          REPO:     ${d}{{ github.event.repository.name }}
        run: |
          # Mask the PAT immediately so it never appears in logs
          GH_TOKEN="${d}{{ github.event.inputs.pat_token }}"
          echo "::add-mask::${d}GH_TOKEN"

          PASS="${d}{{ github.event.inputs.password }}"
          ALIAS="${d}{{ github.event.inputs.alias }}"
          B64="${d}{{ steps.gen.outputs.keystore_b64 }}"
          STORE="${d}{{ steps.gen.outputs.store_name }}"

          set_secret() {
            local name="${d}1" value="${d}2"
            # Get repo public key for encryption
            KEY_JSON=${d}(curl -sf \
              -H "Authorization: Bearer ${d}GH_TOKEN" \
              -H "Accept: application/vnd.github+json" \
              "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/secrets/public-key")
            KEY_ID=${d}(echo "${d}KEY_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['key_id'])")
            PUB_KEY=${d}(echo "${d}KEY_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['key'])")

            # Encrypt with libsodium (PyNaCl) — correct sealed-box format GitHub expects
            pip install pynacl -q
            ENCRYPTED=${d}(python3 - <<PYEOF
import sys, base64, json
from nacl import encoding, public

pub_key = base64.b64decode("${d}PUB_KEY")
sealed = public.SealedBox(public.PublicKey(pub_key)).encrypt(
    "${d}value".encode("utf-8"))
print(base64.b64encode(sealed).decode("utf-8"))
PYEOF
)
            curl -sf -X PUT \
              -H "Authorization: Bearer ${d}GH_TOKEN" \
              -H "Accept: application/vnd.github+json" \
              "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/secrets/${d}name" \
              -d "{\"encrypted_value\":\"${d}ENCRYPTED\",\"key_id\":\"${d}KEY_ID\"}"
            echo "Secret ${d}name saved ✓"
          }

          set_secret "PAT_TOKEN"     "${d}GH_TOKEN"
          set_secret "KEYSTORE_B64"  "${d}B64"
          set_secret "KEYSTORE_PASS" "${d}PASS"
          set_secret "KEYSTORE_ALIAS" "${d}ALIAS"
          set_secret "KEYSTORE_FILE"  "${d}STORE"

      - name: Save keystore name to repository variable
        env:
          GH_TOKEN: ${d}{{ secrets.PAT_TOKEN }}
          OWNER:    ${d}{{ github.repository_owner }}
          REPO:     ${d}{{ github.event.repository.name }}
        run: |
          STORE="${d}{{ steps.gen.outputs.store_name }}"
          # Try update first, fall back to create
          CODE=${d}(curl -s -o /dev/null -w "%{http_code}" -X PATCH \
            -H "Authorization: Bearer ${d}GH_TOKEN" \
            -H "Accept: application/vnd.github+json" \
            "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/variables/KEYSTORE_FILENAME" \
            -d "{\"value\":\"${d}STORE\"}")
          if [ "${d}CODE" != "204" ]; then
            curl -sf -X POST \
              -H "Authorization: Bearer ${d}GH_TOKEN" \
              -H "Accept: application/vnd.github+json" \
              "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/variables" \
              -d "{\"name\":\"KEYSTORE_FILENAME\",\"value\":\"${d}STORE\"}"
          fi
          echo "Variable KEYSTORE_FILENAME=${d}STORE saved ✓"

      - name: Summary
        run: |
          echo "## ✅ Keystore Generated" >> ${d}GITHUB_STEP_SUMMARY
          echo "" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Field | Value |" >> ${d}GITHUB_STEP_SUMMARY
          echo "|---|---|" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Filename | ${d}{{ steps.gen.outputs.store_name }} |" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Alias | ${d}{{ steps.gen.outputs.alias }} |" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Secrets saved | PAT_TOKEN, KEYSTORE_B64, KEYSTORE_PASS, KEYSTORE_ALIAS, KEYSTORE_FILE |" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Variable saved | KEYSTORE_FILENAME |" >> ${d}GITHUB_STEP_SUMMARY
        """.trimIndent()
    }

    // ── File picker ──────────────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = resolveFileName(uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken        = findViewById(R.id.etToken)
        tvOwnerInfo    = findViewById(R.id.tvOwnerInfo)
        etRepo         = findViewById(R.id.etRepo)
        etBranch       = findViewById(R.id.etBranch)
        btnPickZip     = findViewById(R.id.btnPickZip)
        tvFileName     = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus       = findViewById(R.id.tvStatus)
        progressBar    = findViewById(R.id.progressBar)
        btnDownloadApk = findViewById(R.id.btnDownloadApk)
        btnBrowseArtifacts = findViewById(R.id.btnBrowseArtifacts)
        btnManageZips  = findViewById(R.id.btnManageZips)
        btnWorkflowLog = findViewById(R.id.btnWorkflowLog)
        btnDownloadLogs = findViewById(R.id.btnDownloadLogs)
        btnCopyLog     = findViewById(R.id.btnCopyLog)
        btnSaveLog     = findViewById(R.id.btnSaveLog)
        etKeystorePass     = findViewById(R.id.etKeystorePass)
        etKeyAlias         = findViewById(R.id.etKeyAlias)
        btnGenerateKeystore = findViewById(R.id.btnGenerateKeystore)
        tvKeystoreStatus   = findViewById(R.id.tvKeystoreStatus)
        tvLog              = findViewById(R.id.tvLog)
        scrollLog          = findViewById(R.id.scrollLog)

        etToken.setText(prefs.getString("token", ""))
        etRepo.setText(prefs.getString("repo", ""))
        etBranch.setText(prefs.getString("branch", "main"))

        btnPickZip.setOnClickListener     { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener  { if (!isBusy) startFlow() }
        btnDownloadApk.setOnClickListener  { artifactDownloadUrl?.let { downloadArtifact(it) } }
        btnBrowseArtifacts.setOnClickListener { if (!isBusy) browseAllArtifacts() }
        btnManageZips.setOnClickListener   { if (!isBusy) showManageFilesDialog() }
        btnWorkflowLog.setOnClickListener  { if (!isBusy) fetchAndShowWorkflowLog() }
        btnDownloadLogs.setOnClickListener  { if (!isBusy) downloadLatestRunLogs() }
        btnCopyLog.setOnClickListener      { copyLogToClipboard() }
        btnSaveLog.setOnClickListener      { saveLogToFile() }
        btnGenerateKeystore.setOnClickListener { generateKeystore() }
        // Build Log is always enabled — it lists all runs, no active build needed
        btnWorkflowLog.isEnabled = true

        // Restore any previously completed build so Download still works after restart
        restoreSavedBuildState()

        // Restore keystore saved state
        if (prefs.getBoolean(PREF_KEYSTORE_SAVED, false)) {
            val alias = prefs.getString(PREF_KEYSTORE_ALIAS, "") ?: ""
            tvKeystoreStatus.text = "✓ Keystore saved  •  alias: $alias"
            tvKeystoreStatus.visibility = android.view.View.VISIBLE
        }
    }

    // ── Build state persistence ───────────────────────────────────────────────

    private fun saveBuildState(artUrl: String, artName: String, runId: Long, owner: String, repo: String) {
        prefs.edit()
            .putString(PREF_ARTIFACT_URL,  artUrl)
            .putString(PREF_ARTIFACT_NAME, artName)
            .putLong(PREF_LAST_RUN_ID,     runId)
            .putString(PREF_LAST_OWNER,    owner)
            .putString(PREF_LAST_REPO_KEY, repo)
            .apply()
    }

    private fun clearBuildState() {
        prefs.edit()
            .remove(PREF_ARTIFACT_URL)
            .remove(PREF_ARTIFACT_NAME)
            .remove(PREF_LAST_RUN_ID)
            .remove(PREF_LAST_OWNER)
            .remove(PREF_LAST_REPO_KEY)
            .apply()
    }

    /**
     * On cold start, checks SharedPreferences for the last successful build.
     * If found, immediately re-enables the Download button so the user can still
     * download the APK even after killing and reopening the app.
     */
    private fun restoreSavedBuildState() {
        val savedUrl   = prefs.getString(PREF_ARTIFACT_URL, null)
        val savedName  = prefs.getString(PREF_ARTIFACT_NAME, "APK") ?: "APK"
        val savedRunId = prefs.getLong(PREF_LAST_RUN_ID, -1L)
        val savedOwner = prefs.getString(PREF_LAST_OWNER, "") ?: ""
        val savedRepo  = prefs.getString(PREF_LAST_REPO_KEY, "") ?: ""

        if (!savedUrl.isNullOrEmpty()) {
            artifactDownloadUrl      = savedUrl
            lastRunId                = savedRunId
            lastOwner                = savedOwner
            btnDownloadApk.isEnabled = true


            if (savedOwner.isNotEmpty()) tvOwnerInfo.text = "✓  @$savedOwner (last build)"

            setStatus("Ready ✓")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLog("✓ Previous build restored!")
            appendLog("  Artifact : $savedName")
            if (savedRepo.isNotEmpty())  appendLog("  Repo     : $savedRepo")
            if (savedRunId != -1L)       appendLog("  Run #    : $savedRunId")
            appendLog("  ▸ Tap  📲 Download & Install APK  to save to your phone.")
            appendLog("  ▸ Tap  🚀 Upload & Build  to start a new build.")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        } else {
            setStatus("Idle")
        }
    }

    // ── Entry point ──────────────────────────────────────────────────────────
    private fun startFlow() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val uri    = selectedZipUri

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub Personal Access Token."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name."); return }
        if (uri == null)     { appendLog("⚠ Pick a ZIP file first."); return }

        prefs.edit()
            .putString("token",  token)
            .putString("repo",   repo)
            .putString("branch", branch)
            .apply()

        // Clear old build state so stale URL doesn't linger
        clearBuildState()

        setBusy(true)
        tvLog.text = ""
        artifactDownloadUrl      = null
        btnDownloadApk.isEnabled = false
        lastOwner      = ""
        lastRemotePath = ""
        lastFileSha    = null
        lastRunId      = -1L
        mainHandler.post {
            tvOwnerInfo.text         = ""

        }

        thread { runFlow(token, repo, branch, uri) }
    }

    // ── Main flow ────────────────────────────────────────────────────────────
    private fun runFlow(token: String, repo: String, branch: String, uri: Uri) {
        try {
            setStatus("Verifying token…")
            appendLog("Verifying GitHub token…")
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network. Make sure your PAT has 'repo' scope.")
            appendLog("✓  Signed in as @$owner")
            lastOwner = owner
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner" }

            setStatus("Checking repo…")
            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            setStatus("Setting up workflow…")
            ensureWorkflow(token, owner, repo, branch)

            setStatus("Reading ZIP…")
            appendLog("Reading ZIP…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("Size: ${bytes.size / 1024} KB  →  encoded: ${b64.length / 1024} KB")
            if (b64.length > 95 * 1024 * 1024) {
                throw Exception("ZIP too large for GitHub Contents API (> ~70 MB raw).")
            }

            setStatus("Uploading…")
            appendLog("Uploading to github.com/$owner/$repo …")
            val remotePath  = "uploads/$selectedZipName"
            val existingSha = fetchFileSha(token, owner, repo, remotePath)
            val uploadJson  = JSONObject().apply {
                put("message", "ci: upload $selectedZipName [run ${System.currentTimeMillis()}]")
                put("content", b64)
                put("branch",  branch)
                if (existingSha != null) {
                    put("sha", existingSha)
                    appendLog("Replacing existing file (SHA: ${existingSha.take(8)}…)")
                }
            }.toString()

            val (upCode, upBody) = httpPut(token, apiContents(owner, repo, remotePath), uploadJson)
            if (upCode !in 200..201) throw Exception("Upload failed ($upCode): ${upBody.take(400)}")
            lastRemotePath = remotePath
            lastFileSha = try {
                JSONObject(upBody).optJSONObject("content")?.optString("sha")
            } catch (_: Exception) { null }
            appendLog("Upload OK — GitHub Actions will start shortly…")

            setStatus("Waiting for build…")
            appendLog("Waiting for GitHub Actions to pick up the commit…")
            val afterMs = System.currentTimeMillis()
            Thread.sleep(6_000)

            val runId = waitForRun(token, owner, repo, branch, afterMs)
                ?: throw Exception("No workflow run appeared within 3 minutes. " +
                    "Check that build.yml is on the $branch branch.")
            lastRunId = runId
            appendLog("Run #$runId started — streaming live build log…")
            appendLog("─────────────────────────────────────")

            setStatus("Building…")
            val success = streamBuildLog(token, owner, repo, runId)
            if (!success) throw Exception("Build failed. Tap '🔍 Build Log' for the full output.")

            setStatus("Fetching APK…")
            appendLog("Build succeeded! Looking for APK artifact…")
            val (artName, artUrl) = fetchArtifact(token, owner, repo, runId)
                ?: throw Exception("Run succeeded but no artifact found.")

            artifactDownloadUrl = artUrl
            appendLog("Artifact ready: $artName")
            setStatus("Ready ✓")

            // ─── Persist so Download button works after any app restart ──────
            saveBuildState(artUrl, artName, runId, owner, repo)

            mainHandler.post { btnDownloadApk.isEnabled = true }

        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setStatus("Failed")
        } finally {
            setBusy(false)
        }
    }

    // ── Auto-setup helpers ────────────────────────────────────────────────────

    private fun fetchOwner(token: String): String? = try {
        val (code, body) = httpGet(token, "https://api.github.com/user")
        if (code == 200) JSONObject(body).optString("login").takeIf { it.isNotEmpty() }
        else null
    } catch (_: Exception) { null }

    private fun ensureRepo(token: String, owner: String, repo: String) {
        val (code, _) = httpGet(token, "https://api.github.com/repos/$owner/$repo")
        if (code == 200) { appendLog("Repo already exists ✓"); return }
        appendLog("Repo not found — creating github.com/$owner/$repo …")
        val body = JSONObject().apply {
            put("name",        repo)
            put("private",     false)
            put("auto_init",   true)
            put("description", "APK build repo — managed by ZipApkBuilder")
        }.toString()
        val (createCode, createBody) = httpPost(token, "https://api.github.com/user/repos", body)
        if (createCode !in 200..201) throw Exception("Could not create repo ($createCode): ${createBody.take(300)}")
        appendLog("Repo created ✓ — waiting for GitHub to initialise it…")
        Thread.sleep(4_000)
    }

    private fun ensureWorkflow(token: String, owner: String, repo: String, branch: String) {
        val path = ".github/workflows/build.yml"
        val existingSha = fetchFileSha(token, owner, repo, path)
        if (existingSha != null) { appendLog("Workflow already present ✓"); return }
        appendLog("Committing build workflow to repo…")
        val encoded = Base64.encodeToString(WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("message", "ci: add GitHub Actions build workflow")
            put("content", encoded)
            put("branch",  branch)
        }.toString()
        val (code, body) = httpPut(token, apiContents(owner, repo, path), payload)
        if (code !in 200..201) throw Exception("Could not commit workflow ($code): ${body.take(300)}")
        appendLog("Workflow committed ✓")
        Thread.sleep(2_000)
    }

    // ── GitHub API helpers ────────────────────────────────────────────────────

    private fun fetchFileSha(token: String, owner: String, repo: String, path: String): String? =
        try {
            val (code, body) = httpGet(token, apiContents(owner, repo, path))
            if (code == 200) JSONObject(body).optString("sha").takeIf { it.isNotEmpty() }
            else null
        } catch (_: Exception) { null }

    private fun waitForRun(token: String, owner: String, repo: String, branch: String, afterMs: Long): Long? {
        val deadline = System.currentTimeMillis() + 3 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val url = "${apiRuns(owner, repo)}?branch=$branch&per_page=10&event=push"
                val (code, body) = httpGet(token, url)
                if (code == 200) {
                    val runs = JSONObject(body).getJSONArray("workflow_runs")
                    for (i in 0 until runs.length()) {
                        val run   = runs.getJSONObject(i)
                        val runMs = parseIso8601(run.getString("created_at"))
                        if (runMs >= afterMs - 15_000) return run.getLong("id")
                    }
                }
            } catch (_: Exception) {}
            Thread.sleep(10_000)
        }
        return null
    }

    private fun streamBuildLog(token: String, owner: String, repo: String, runId: Long): Boolean {
        val deadline    = System.currentTimeMillis() + 45 * 60_000L
        val stepStarted  = mutableSetOf<Int>()
        val stepFinished = mutableSetOf<Int>()
        val tsRegex      = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
        val ansiRegex    = Regex("""\x1B\[[0-9;]*[A-Za-z]""")
        var conclusion   = ""

        while (System.currentTimeMillis() < deadline) {
            try {
                val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
                if (jCode == 200) {
                    val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                    if (jobsArr != null && jobsArr.length() > 0) {
                        val steps = jobsArr.getJSONObject(0).optJSONArray("steps")
                        if (steps != null) {
                            for (i in 0 until steps.length()) {
                                val step     = steps.getJSONObject(i)
                                val num      = step.getInt("number")
                                val name     = step.getString("name")
                                val status   = step.optString("status", "")
                                val stepConc = step.optString("conclusion", "")
                                if (status == "in_progress" && stepStarted.add(num)) appendLog("▶ $name")
                                if (status == "completed" && stepFinished.add(num)) {
                                    if (!stepStarted.contains(num)) appendLog("▶ $name")
                                    val icon = if (stepConc == "success") "✓" else "✗"
                                    val started   = step.optString("started_at", "")
                                    val completed = step.optString("completed_at", "")
                                    val dur = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                        try {
                                            val e = parseIso8601(completed); val s = parseIso8601(started)
                                            if (e > s) "  ${(e - s) / 1000}s" else ""
                                        } catch (_: Exception) { "" }
                                    } else ""
                                    appendLog("  $icon $name$dur")
                                }
                            }
                        }
                    }
                }
                val (sCode, sBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId")
                if (sCode == 200) {
                    val obj = JSONObject(sBody)
                    conclusion = obj.optString("conclusion", "")
                    if (obj.getString("status") == "completed") break
                }
            } catch (_: Exception) {}
            Thread.sleep(5_000)
        }

        // Fetch and append full log text
        try {
            val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
            if (jCode == 200) {
                val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                if (jobsArr != null && jobsArr.length() > 0) {
                    val jobId  = jobsArr.getJSONObject(0).getLong("id")
                    val logUrl = "https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs"
                    val conn1  = (URL(logUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        setRequestProperty("Authorization", "token $token")
                        setRequestProperty("Accept", "application/vnd.github.v3+json")
                        instanceFollowRedirects = false
                        connectTimeout = 20_000; readTimeout = 60_000
                    }
                    val rawLog: String? = when (val c = conn1.responseCode) {
                        in 301..308 -> {
                            val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                            try {
                                val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                                    requestMethod = "GET"; connectTimeout = 20_000; readTimeout = 60_000
                                }
                                if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText().also { c2.disconnect() }
                                else { c2.disconnect(); null }
                            } catch (_: Exception) { null }
                        }
                        200  -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                        else -> { conn1.disconnect(); null }
                    }
                    if (rawLog != null) {
                        appendLog("─────────────────────────────────────")
                        val groupRx = Regex("""^##\[(?:group|endgroup)\]""")
                        for (raw in rawLog.lines()) {
                            val line = ansiRegex.replace(tsRegex.replace(raw, ""), "")
                            if (!groupRx.containsMatchIn(line) && line.isNotBlank()) appendLog(line)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        appendLog("─────────────────────────────────────")
        appendLog(if (conclusion == "success") "✓ Build completed successfully" else "✗ Build $conclusion")
        return conclusion == "success"
    }

    private fun fetchArtifact(token: String, owner: String, repo: String, runId: Long): Pair<String, String>? {
        val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId/artifacts")
        if (code != 200) return null
        val artifacts = JSONObject(body).getJSONArray("artifacts")
        if (artifacts.length() == 0) return null
        val art = artifacts.getJSONObject(0)
        return art.getString("name") to art.getString("archive_download_url")
    }

    // ── Download Build Logs ZIP ───────────────────────────────────────────────

    private fun downloadLatestRunLogs() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        setStatus("Fetching latest run…")
        appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        appendLog("📥 Downloading build logs ZIP…")

        thread {
            try {
                // Resolve owner — use cached value or fetch from token
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: run {
                        appendLog("✗ Could not verify token.")
                        setStatus("Failed")
                        setBusy(false)
                        return@thread
                    }).also { lastOwner = it }
                }

                // 1. Get the latest run on this branch
                val runsUrl = "${apiRuns(owner, repo)}?branch=$branch&per_page=1"
                val (code, body) = httpGet(token, runsUrl)
                if (code != 200) {
                    appendLog("✗ Could not fetch runs (HTTP $code)")
                    setStatus("Failed")
                    setBusy(false)
                    return@thread
                }
                val runs = JSONObject(body).getJSONArray("workflow_runs")
                if (runs.length() == 0) {
                    appendLog("⚠ No runs found on branch '$branch'")
                    setStatus("No runs")
                    setBusy(false)
                    return@thread
                }
                val run   = runs.getJSONObject(0)
                val runId = run.getLong("id")
                val runNum = run.getInt("run_number")
                val status = run.optString("status", "")
                val conclusion = run.optString("conclusion", "")
                appendLog("  Run #$runNum  status=$status  conclusion=${conclusion.ifEmpty { "in_progress" }}")

                // 2. Request the logs ZIP (GitHub returns a redirect)
                val logsUrl = "https://api.github.com/repos/$owner/$repo/actions/runs/$runId/logs"
                val conn = (URL(logsUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github+json")
                    instanceFollowRedirects = false
                    connectTimeout = 20_000
                    readTimeout    = 60_000
                }
                conn.connect()
                val respCode = conn.responseCode
                val realUrl = when {
                    respCode in 301..308 -> { val loc = conn.getHeaderField("Location"); conn.disconnect(); loc }
                    respCode == 200      -> { logsUrl.also { conn.disconnect() } }
                    else -> {
                        conn.disconnect()
                        appendLog("✗ Logs not available yet (HTTP $respCode) — try after the run completes")
                        setStatus("Logs unavailable")
                        setBusy(false)
                        return@thread
                    }
                }

                // 3. Download the ZIP
                appendLog("  Downloading…")
                val dlConn = (URL(realUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000
                    readTimeout    = 120_000
                }
                val total = dlConn.contentLength
                val tmpFile = File(cacheDir, "logs_${runId}.zip")
                dlConn.inputStream.use { inp -> FileOutputStream(tmpFile).use { inp.copyTo(it) } }
                dlConn.disconnect()
                appendLog("  Downloaded: ${tmpFile.length() / 1024} KB")

                // 4. Save to Downloads
                val fileName = "logs_${runId}.zip"
                setStatus("Saving…")
                val savedPath = saveZipToDownloads(tmpFile, fileName)
                tmpFile.delete()

                appendLog("✓ Saved to Downloads!")
                appendLog("  File : $fileName")
                appendLog("  Path : $savedPath")
                setStatus("Logs saved ✓")

            } catch (e: Exception) {
                appendLog("✗ Error: ${e.message}")
                setStatus("Failed")
            } finally {
                setBusy(false)
            }
        }
    }

    // ── Download & Install ────────────────────────────────────────────────────

    private fun downloadArtifact(downloadUrl: String) {
        if (isBusy) return
        setBusy(true)
        setStatus("Downloading…")
        appendLog("Downloading artifact ZIP from GitHub…")
        val token = etToken.text.toString().trim()

        // Use the artifact name exactly as GitHub names it (same as the website)
        val rawName = prefs.getString(PREF_ARTIFACT_NAME, "artifact") ?: "artifact"
        val zipFileName = if (rawName.endsWith(".zip", ignoreCase = true)) rawName else "$rawName.zip"

        thread {
            try {
                // 1. Resolve GitHub's redirect to the actual download URL
                val conn0 = URL(downloadUrl).openConnection() as HttpURLConnection
                conn0.setRequestProperty("Authorization", "token $token")
                conn0.setRequestProperty("Accept", "application/vnd.github.v3+json")
                conn0.instanceFollowRedirects = false
                conn0.connectTimeout = 30_000
                conn0.readTimeout    = 30_000
                conn0.connect()
                val realUrl = if (conn0.responseCode in 301..308) {
                    val loc = conn0.getHeaderField("Location")
                    conn0.disconnect(); loc
                } else { conn0.disconnect(); downloadUrl }

                // 2. Download the artifact ZIP
                val dlConn = URL(realUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60_000
                dlConn.readTimeout   = 300_000
                val total = dlConn.contentLength
                appendLog("Downloading… (${if (total > 0) "${total / 1024} KB" else "size unknown"})")

                val artifactZip = File(cacheDir, "artifact_${System.currentTimeMillis()}.zip")
                dlConn.inputStream.use { inp -> FileOutputStream(artifactZip).use { inp.copyTo(it) } }
                dlConn.disconnect()
                appendLog("Downloaded: ${artifactZip.length() / 1024} KB")

                // 3. Save the ZIP directly to Downloads using the artifact name (no rename, no APK extraction)
                setStatus("Saving…")
                val savedPath = saveZipToDownloads(artifactZip, zipFileName)
                appendLog("✓ Saved to Downloads!")
                appendLog("  File : $zipFileName")
                appendLog("  Path : $savedPath")
                appendLog("  Size : ${artifactZip.length() / 1024} KB")
                appendLog("  Open your Downloads app to find it anytime.")
                setStatus("Ready ✓")
                mainHandler.post { btnDownloadApk.isEnabled = true }

            } catch (e: Exception) {
                appendLog("✗ Download error: ${e.message}")
                setStatus("Download failed")
                mainHandler.post { btnDownloadApk.isEnabled = true }
            } finally {
                setBusy(false)
            }
        }
    }

    /**
     * Saves [zipFile] to the public Downloads directory as [fileName] (a .zip).
     *
     * Android 10+ (API 29+): MediaStore API — no storage permission required.
     * Android 7–9  (API 24–28): direct file write (needs WRITE_EXTERNAL_STORAGE).
     *
     * Returns the absolute path of the saved file.
     */
    private fun saveZipToDownloads(zipFile: File, fileName: String): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — MediaStore.Downloads (no permission needed)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val collection = MediaStore.Downloads
                .getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = contentResolver.insert(collection, values)
                ?: throw Exception("MediaStore insert failed.")

            contentResolver.openOutputStream(itemUri)!!.use { out: OutputStream ->
                zipFile.inputStream().use { it.copyTo(out) }
            }

            // Clear IS_PENDING so it appears in Downloads app right away
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(itemUri, values, null, null)

            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                .absolutePath + "/$fileName"

        } else {
            // Android 7–9 — direct file write (needs WRITE_EXTERNAL_STORAGE)
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val dest = File(dir, fileName)
            zipFile.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }


    // ── Keystore Generation ────────────────────────────────────────────────────

    private fun generateKeystore() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        val pass  = etKeystorePass.text.toString().trim()
        val rawAlias = etKeyAlias.text.toString().trim()

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }
        if (pass.length < 6) { appendLog("⚠ Keystore password must be at least 6 characters."); return }

        val ts = SimpleDateFormat("yyyyMMddHHmm", Locale.US).format(java.util.Date())
        val alias = rawAlias.ifEmpty { "key-$ts" }

        AlertDialog.Builder(this)
            .setTitle("🔑 Generate Keystore")
            .setMessage(
                "This will:\n\n" +
                "• Run the keystore generation workflow\n" +
                "• Save keystore as GitHub Secrets:\n" +
                "  KEYSTORE_B64, KEYSTORE_PASS,\n" +
                "  KEYSTORE_ALIAS, KEYSTORE_FILE\n" +
                "• Save KEYSTORE_FILENAME as a variable\n\n" +
                "Alias: $alias\n\n" +
                "Each run creates a uniquely-named keystore.\n" +
                "Continue?"
            )
            .setPositiveButton("Generate") { _, _ ->
                setBusy(true)
                tvKeystoreStatus.visibility = android.view.View.GONE
                appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                appendLog("🔑 Keystore generation starting…")
                appendLog("  Alias : $alias")
                appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                thread { runKeystoreGeneration(token, repo, alias, pass) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun runKeystoreGeneration(token: String, repo: String, alias: String, pass: String) {
        try {
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network.")
            lastOwner = owner
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner" }

            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            // Always commit/update the keystore workflow so the latest version is in place.
            // PAT_TOKEN is passed as a masked dispatch input — no app-side encryption needed.
            val wfPath = ".github/workflows/keystore.yml"
            val existingSha = fetchFileSha(token, owner, repo, wfPath)
            appendLog(if (existingSha != null) "Updating keystore workflow…" else "Committing keystore workflow…")
            val wfEncoded = Base64.encodeToString(
                KEYSTORE_WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val wfPayload = JSONObject().apply {
                put("message", if (existingSha != null) "ci: update keystore workflow" else "ci: add keystore workflow")
                put("content", wfEncoded)
                put("branch",  "main")
                if (existingSha != null) put("sha", existingSha)
            }.toString()
            val (wfCode, wfBody) = httpPut(token, apiContents(owner, repo, wfPath), wfPayload)
            if (wfCode !in 200..201) throw Exception("Could not commit workflow ($wfCode): ${wfBody.take(300)}")
            appendLog("Keystore workflow ready ✓")
            Thread.sleep(3_000)

            // Dispatch the workflow
            appendLog("Triggering keystore generation workflow…")
            val dispatchBody = JSONObject().apply {
                put("ref", "main")
                put("inputs", JSONObject().apply {
                    put("alias",         alias)
                    put("password",      pass)
                    put("validity_days", "10950")
                    put("pat_token",     token)   // passed masked; workflow uses PyNaCl to save it
                })
            }.toString()
            val dispatchUrl = "https://api.github.com/repos/$owner/$repo/actions/workflows/keystore.yml/dispatches"
            val (dCode, dBody) = httpPost(token, dispatchUrl, dispatchBody)
            if (dCode !in 200..204) throw Exception("Dispatch failed ($dCode): ${dBody.take(300)}")
            appendLog("Workflow dispatched ✓ — waiting for run…")

            Thread.sleep(6_000)

            // Wait for the run to appear
            val afterMs  = System.currentTimeMillis() - 15_000L
            val deadline = System.currentTimeMillis() + 3 * 60_000L
            var keystoreRunId = -1L
            while (System.currentTimeMillis() < deadline && keystoreRunId == -1L) {
                try {
                    val url = "https://api.github.com/repos/$owner/$repo/actions/workflows/keystore.yml/runs?per_page=5"
                    val (code, body) = httpGet(token, url)
                    if (code == 200) {
                        val runs = JSONObject(body).getJSONArray("workflow_runs")
                        for (i in 0 until runs.length()) {
                            val run = runs.getJSONObject(i)
                            if (parseIso8601(run.getString("created_at")) >= afterMs) {
                                keystoreRunId = run.getLong("id"); break
                            }
                        }
                    }
                } catch (_: Exception) {}
                if (keystoreRunId == -1L) Thread.sleep(8_000)
            }
            if (keystoreRunId == -1L) throw Exception("Keystore run did not appear within 3 minutes.")

            appendLog("Run #$keystoreRunId started — polling steps…")
            appendLog("─────────────────────────────────────")

            // Poll until complete, streaming step names
            val runDeadline  = System.currentTimeMillis() + 10 * 60_000L
            var conclusion   = ""
            val stepStarted  = mutableSetOf<Int>()
            val stepFinished = mutableSetOf<Int>()
            while (System.currentTimeMillis() < runDeadline) {
                try {
                    val (jCode, jBody) = httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/runs/$keystoreRunId/jobs")
                    if (jCode == 200) {
                        val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                        if (jobsArr != null && jobsArr.length() > 0) {
                            val steps = jobsArr.getJSONObject(0).optJSONArray("steps")
                            if (steps != null) {
                                for (i in 0 until steps.length()) {
                                    val step     = steps.getJSONObject(i)
                                    val num      = step.getInt("number")
                                    val name     = step.getString("name")
                                    val status   = step.optString("status", "")
                                    val stepConc = step.optString("conclusion", "")
                                    if (status == "in_progress" && stepStarted.add(num)) appendLog("▶ $name")
                                    if (status == "completed" && stepFinished.add(num)) {
                                        if (!stepStarted.contains(num)) appendLog("▶ $name")
                                        val icon = if (stepConc == "success") "✓" else "✗"
                                        val started   = step.optString("started_at", "")
                                        val completed = step.optString("completed_at", "")
                                        val dur = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                            try {
                                                val e = parseIso8601(completed); val s = parseIso8601(started)
                                                if (e > s) "  ${(e - s) / 1000}s" else ""
                                            } catch (_: Exception) { "" }
                                        } else ""
                                        appendLog("  $icon $name$dur")
                                    }
                                }
                            }
                        }
                    }
                    val (sCode, sBody) = httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/runs/$keystoreRunId")
                    if (sCode == 200) {
                        val obj = JSONObject(sBody)
                        conclusion = obj.optString("conclusion", "")
                        if (obj.getString("status") == "completed") break
                    }
                } catch (_: Exception) {}
                Thread.sleep(6_000)
            }

            appendLog("─────────────────────────────────────")
            if (conclusion != "success") throw Exception("Keystore workflow $conclusion. Check run #$keystoreRunId on GitHub.")

            prefs.edit()
                .putBoolean(PREF_KEYSTORE_SAVED, true)
                .putString(PREF_KEYSTORE_ALIAS, alias)
                .apply()

            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLog("✓ Keystore generated successfully!")
            appendLog("  Alias    : $alias")
            appendLog("  Secrets  : KEYSTORE_B64, KEYSTORE_PASS,")
            appendLog("             KEYSTORE_ALIAS, KEYSTORE_FILE")
            appendLog("  Variable : KEYSTORE_FILENAME")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            mainHandler.post {
                tvKeystoreStatus.text = "✓ Keystore saved  •  alias: $alias"
                tvKeystoreStatus.visibility = android.view.View.VISIBLE
            }

        } catch (e: Exception) {
            appendLog("✗ Keystore error: ${e.message}")
        } finally {
            setBusy(false)
        }
    }

    /**
     * Saves [value] as a GitHub Actions secret in [repo] using the Secrets API.
     * Uses JCE X25519 + AES-GCM (sealed-box approximation) for the required
     * libsodium sealed-box encryption that GitHub expects.
     */
    private fun setGitHubSecret(token: String, owner: String, repo: String, name: String, value: String) {
        val (keyCode, keyBody) = httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/secrets/public-key")
        if (keyCode != 200) throw Exception("Could not fetch public key ($keyCode)")
        val keyObj    = JSONObject(keyBody)
        val keyId     = keyObj.getString("key_id")
        val pubKeyB64 = keyObj.getString("key")
        val pubKeyBytes = android.util.Base64.decode(pubKeyB64, android.util.Base64.DEFAULT)

        // GitHub requires libsodium sealed-box (X25519 + XSalsa20-Poly1305).
        // Android ships BouncyCastle which supports X25519 but not XSalsa20.
        // We use X25519 ECDH + AES-256-GCM as a practical equivalent.
        // The workflow then re-encrypts via PyNaCl for all subsequent secrets.
        try {
            val kpg = java.security.KeyPairGenerator.getInstance("X25519")
            kpg.initialize(255)
            val eph = kpg.generateKeyPair()

            // Import recipient key
            val keySpec = java.security.spec.XECPublicKeySpec(
                java.security.spec.NamedParameterSpec.X25519,
                java.math.BigInteger(1, pubKeyBytes))
            val recipientPub = java.security.KeyFactory.getInstance("X25519").generatePublic(keySpec)

            val ka = javax.crypto.KeyAgreement.getInstance("X25519")
            ka.init(eph.private)
            ka.doPhase(recipientPub, true)
            val shared = ka.generateSecret()

            // HKDF-like key derivation
            val ephRaw = (eph.public.encoded).takeLast(32).toByteArray()
            val ikm    = ephRaw + pubKeyBytes + shared
            val dk     = java.security.MessageDigest.getInstance("SHA-256").digest(ikm)

            val iv     = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
            val cipher = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(javax.crypto.Cipher.ENCRYPT_MODE,
                        javax.crypto.spec.SecretKeySpec(dk, "AES"),
                        javax.crypto.spec.GCMParameterSpec(128, iv))
            val ct = cipher.doFinal(value.toByteArray(Charsets.UTF_8))

            val blob = android.util.Base64.encodeToString(ephRaw + iv + ct, android.util.Base64.NO_WRAP)
            val payload = JSONObject().apply {
                put("encrypted_value", blob)
                put("key_id", keyId)
            }.toString()
            val (code, body) = httpPut(token, "https://api.github.com/repos/$owner/$repo/actions/secrets/$name", payload)
            if (code !in 200..204) throw Exception("Secret PUT $name failed ($code): ${body.take(200)}")
        } catch (e: Exception) {
            throw Exception("Encryption failed: ${e.message}")
        }
    }

    // ── Browse All Artifacts (persists across reinstall — reads from GitHub) ─

    /**
     * Fetches every artifact for the repo from GitHub API — exactly what the
     * GitHub website shows on the Actions → Artifacts page.  Works even after
     * the app is uninstalled and reinstalled because the data lives on GitHub,
     * not in SharedPreferences.
     */
    private fun browseAllArtifacts() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Fetching all artifacts from GitHub…")

        thread {
            try {
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: throw Exception("Could not verify token.")).also { lastOwner = it }
                }

                // Collect up to 5 pages × 30 = 150 artifacts (same as GitHub website)
                val allArtifacts = mutableListOf<JSONObject>()
                var page = 1
                while (page <= 5) {
                    val url = "https://api.github.com/repos/$owner/$repo/actions/artifacts?per_page=30&page=$page"
                    val (code, body) = httpGet(token, url)
                    if (code != 200) break
                    val obj  = JSONObject(body)
                    val arr  = obj.getJSONArray("artifacts")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allArtifacts.add(arr.getJSONObject(i))
                    val totalCount = obj.optInt("total_count", 0)
                    if (allArtifacts.size >= totalCount) break
                    page++
                }

                mainHandler.post {
                    setBusy(false)
                    if (allArtifacts.isEmpty()) {
                        appendLog("No artifacts found in github.com/$owner/$repo")
                        appendLog("  Artifacts are kept for 30 days after each build.")
                        AlertDialog.Builder(this)
                            .setTitle("📁 No Artifacts Found")
                            .setMessage(
                                "No artifacts were found in:\ngithub.com/$owner/$repo\n\n" +
                                "Possible reasons:\n" +
                                "• All artifacts have expired (30-day limit)\n" +
                                "• The repo name is wrong\n" +
                                "• No builds have been run yet\n\n" +
                                "Start a new build with 🚀 Upload & Build."
                            )
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        appendLog("Found ${allArtifacts.size} artifact(s) ✓")
                        showArtifactBrowserDialog(token, owner, repo, allArtifacts)
                    }
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /**
     * Displays all artifacts in a dialog — same information as the GitHub website:
     * name, size, creation date, expiry date, and a Download button per artifact.
     */
    private fun showArtifactBrowserDialog(
        token: String, owner: String, repo: String,
        artifacts: List<JSONObject>
    ) {
        // Build display labels: "🟢 name  •  1.2 MB  •  expires May 15"
        val fmt      = SimpleDateFormat("MMM d, yyyy", Locale.US)
        val fmtIn    = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
        val labels = artifacts.map { art ->
            val name      = art.getString("name")
            val sizeBytes = art.optLong("size_in_bytes", 0L)
            val sizeStr   = when {
                sizeBytes >= 1_048_576 -> "%.1f MB".format(sizeBytes / 1_048_576.0)
                sizeBytes >= 1_024     -> "${sizeBytes / 1024} KB"
                else                   -> "$sizeBytes B"
            }
            val expired     = art.optBoolean("expired", false)
            val expiresRaw  = art.optString("expires_at", "")
            val expiresStr  = if (expiresRaw.isNotEmpty()) {
                try { "expires " + fmt.format(fmtIn.parse(expiresRaw)!!) }
                catch (_: Exception) { "" }
            } else ""
            val createdRaw  = art.optString("created_at", "")
            val createdStr  = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) }
                catch (_: Exception) { "" }
            } else ""
            val icon = if (expired) "🔴" else "🟢"
            buildString {
                append("$icon $name")
                append("\n    $sizeStr")
                if (createdStr.isNotEmpty()) append("  •  built $createdStr")
                if (expiresStr.isNotEmpty()) append("\n    $expiresStr")
                if (expired) append("  ⚠ expired")
            }
        }.toTypedArray()

        var selectedIndex = -1

        AlertDialog.Builder(this)
            .setTitle("📁  All Artifacts  (${artifacts.size})")
            .setSingleChoiceItems(labels, -1) { _, which -> selectedIndex = which }
            .setPositiveButton("📲 Download Selected") { _, _ ->
                if (selectedIndex < 0) {
                    appendLog("⚠ Tap an artifact to select it first.")
                    return@setPositiveButton
                }
                val art = artifacts[selectedIndex]
                if (art.optBoolean("expired", false)) {
                    appendLog("✗ That artifact has expired — it can no longer be downloaded.")
                    AlertDialog.Builder(this)
                        .setTitle("Artifact Expired")
                        .setMessage(
                            "\"${art.getString("name")}\" has expired.\n\n" +
                            "GitHub keeps artifacts for 30 days. " +
                            "Start a new build to get a fresh APK."
                        )
                        .setPositiveButton("OK", null).show()
                    return@setPositiveButton
                }
                val dlUrl  = art.getString("archive_download_url")
                val dlName = art.getString("name")
                // Save so the Download button on the main screen also works
                val runId  = art.optLong("workflow_run", 0L).let {
                    // archive_download_url contains the run id in some cases; use artifact id instead
                    art.optLong("id", -1L)
                }
                saveBuildState(dlUrl, dlName, runId, owner, repo)
                artifactDownloadUrl      = dlUrl
                lastRunId                = runId
                btnDownloadApk.isEnabled = true
                appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                appendLog("Selected artifact: $dlName")
                appendLog("Starting download…")
                appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                downloadArtifact(dlUrl)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ── Manage ZIPs dialog ────────────────────────────────────────────────────

    private fun showManageFilesDialog() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Listing ZIPs in repo uploads/ …")

        thread {
            try {
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: throw Exception("Could not verify token.")).also { lastOwner = it }
                }
                val (code, body) = httpGet(token, apiContents(owner, repo, "uploads"))
                when {
                    code == 404 -> { mainHandler.post { setBusy(false); appendLog("No uploads/ directory found.") }; return@thread }
                    code != 200 -> throw Exception("Could not list uploads/ (HTTP $code)")
                }
                val arr      = JSONArray(body)
                val zipFiles = mutableListOf<Triple<String, String, String>>()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    if (obj.optString("type") == "file" && obj.getString("name").lowercase().endsWith(".zip"))
                        zipFiles.add(Triple(obj.getString("path"), obj.optString("sha"), obj.getString("name")))
                }
                mainHandler.post {
                    setBusy(false)
                    if (zipFiles.isEmpty()) appendLog("No ZIP files in uploads/ — repo is clean.")
                    else showZipSelectionDialog(token, owner, repo, zipFiles)
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    private fun showZipSelectionDialog(
        token: String, owner: String, repo: String,
        zipFiles: List<Triple<String, String, String>>
    ) {
        val names   = zipFiles.map { it.third }.toTypedArray()
        val checked = BooleanArray(zipFiles.size) { false }
        AlertDialog.Builder(this)
            .setTitle("🗂️  Select ZIPs to Delete")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Delete Selected") { _, _ ->
                val toDelete = zipFiles.filterIndexed { i, _ -> checked[i] }
                if (toDelete.isEmpty()) { appendLog("No files selected."); return@setPositiveButton }
                val list = toDelete.joinToString("\n• ", prefix = "• ") { it.third }
                AlertDialog.Builder(this)
                    .setTitle("Confirm Deletion")
                    .setMessage("Permanently delete ${toDelete.size} file(s) from repo?\n\n$list")
                    .setPositiveButton("Delete") { _, _ ->
                        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
                        setBusy(true)
                        thread { deleteSelectedFiles(token, owner, repo, branch, toDelete) }
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun deleteSelectedFiles(
        token: String, owner: String, repo: String, branch: String,
        files: List<Triple<String, String, String>>
    ) {
        try {
            for ((path, sha, name) in files) {
                appendLog("Deleting $name …")
                val body = JSONObject().apply {
                    put("message", "ci: delete $path via ZipApkBuilder [skip ci]")
                    put("sha",     sha)
                    put("branch",  branch)
                }.toString()
                val (code, resp) = httpDelete(token, apiContents(owner, repo, path), body)
                if (code in 200..204) { appendLog("✓ Deleted: $name"); if (path == lastRemotePath) lastFileSha = null }
                else appendLog("✗ Failed ($code): ${resp.take(120)}")
            }
        } catch (e: Exception) { appendLog("✗ ${e.message}") }
        finally { setBusy(false) }
    }

    // ── In-app workflow log viewer ────────────────────────────────────────────

    /** Entry point — fetches all runs and shows a picker dialog. */
    private fun fetchAndShowWorkflowLog() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        val owner = lastOwner.ifEmpty {
            appendLog("⚠ Build or browse artifacts first so the owner is known."); return
        }

        setBusy(true)
        appendLog("Fetching workflow runs from GitHub…")

        thread {
            try {
                val allRuns = mutableListOf<JSONObject>()
                // Fetch up to 3 pages × 30 = 90 runs (covers all recent history)
                for (page in 1..3) {
                    val url = "${apiRuns(owner, repo)}?per_page=30&page=$page"
                    val (code, body) = httpGet(token, url)
                    if (code != 200) break
                    val arr = JSONObject(body).getJSONArray("workflow_runs")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allRuns.add(arr.getJSONObject(i))
                    if (arr.length() < 30) break
                }
                if (allRuns.isEmpty()) {
                    appendLog("No workflow runs found in github.com/$owner/$repo")
                    mainHandler.post { setBusy(false) }
                    return@thread
                }
                appendLog("Found ${allRuns.size} run(s) ✓")
                mainHandler.post { setBusy(false); showRunPickerDialog(token, owner, repo, allRuns) }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /**
     * Shows a list of all workflow runs — same card style as Browse Artifacts.
     * Each entry shows: workflow name, run number, conclusion icon, date.
     * Tapping "View Log" fetches and displays that run's log.
     */
    private fun showRunPickerDialog(
        token: String, owner: String, repo: String,
        runs: List<JSONObject>
    ) {
        val fmt   = SimpleDateFormat("MMM d, HH:mm", Locale.US)
        val fmtIn = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }

        val labels = runs.map { run ->
            val runNum    = run.optLong("run_number", 0L)
            val name      = run.optString("name", "build")
            val status    = run.optString("status", "")
            val conc      = run.optString("conclusion", "")
            val createdRaw = run.optString("created_at", "")
            val dateStr   = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) } catch (_: Exception) { "" }
            } else ""
            val icon = when (conc) {
                "success"   -> "✅"
                "failure"   -> "❌"
                "cancelled" -> "⛔"
                "skipped"   -> "⏭"
                else        -> if (status == "in_progress") "🔄" else "⏳"
            }
            buildString {
                append("$icon  Run #$runNum  •  $name")
                if (dateStr.isNotEmpty()) append("\n    $dateStr")
                if (conc.isNotEmpty()) append("  •  $conc")
                else if (status.isNotEmpty()) append("  •  $status")
            }
        }.toTypedArray()

        var selectedIndex = -1

        AlertDialog.Builder(this)
            .setTitle("🔍  Workflow Runs  (${runs.size})")
            .setSingleChoiceItems(labels, -1) { _, which -> selectedIndex = which }
            .setPositiveButton("📄 View Log") { _, _ ->
                if (selectedIndex < 0) {
                    appendLog("⚠ Tap a run to select it first.")
                    return@setPositiveButton
                }
                val run   = runs[selectedIndex]
                val runId = run.getLong("id")
                val runNum = run.optLong("run_number", runId)
                setBusy(true)
                appendLog("Fetching log for run #$runNum…")
                thread { fetchLogForRun(token, owner, repo, runId, runNum) }
            }
            .setNeutralButton("🔄 Refresh") { _, _ ->
                fetchAndShowWorkflowLog()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    /** Fetches the log text for a specific run and shows it in showLogDialog. */
    private fun fetchLogForRun(token: String, owner: String, repo: String, runId: Long, runNum: Long) {
        try {
            val (jobsCode, jobsBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
            if (jobsCode != 200) throw Exception("Could not fetch jobs (HTTP $jobsCode)")
            val jobsArr = JSONObject(jobsBody).optJSONArray("jobs")
                ?: throw Exception("No jobs array for run #$runNum")
            if (jobsArr.length() == 0) throw Exception("No jobs found for run #$runNum")

            // Show all jobs in the run, not just the first one
            val allJobLogs = StringBuilder()
            for (ji in 0 until jobsArr.length()) {
                val job   = jobsArr.getJSONObject(ji)
                val jobId = job.getLong("id")
                val jobName = job.optString("name", "job-$ji")
                appendLog("Loading log for job '$jobName'…")

                val conn1 = (URL("https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs")
                    .openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                    instanceFollowRedirects = false
                    connectTimeout = 30_000; readTimeout = 120_000
                }
                val text: String? = when (val c = conn1.responseCode) {
                    in 301..308 -> {
                        val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                        try {
                            val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                                requestMethod = "GET"; connectTimeout = 30_000; readTimeout = 120_000
                            }
                            if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText()
                                .also { c2.disconnect() }
                            else { c2.disconnect(); null }
                        } catch (_: Exception) { null }
                    }
                    200  -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                    410  -> { conn1.disconnect(); "⚠ Log expired or unavailable for this run." }
                    else -> { conn1.disconnect(); "⚠ HTTP $c — log not available." }
                }
                if (text != null) {
                    if (jobsArr.length() > 1) {
                        allJobLogs.append("══════ JOB: $jobName ══════\n")
                    }
                    allJobLogs.append(text).append("\n")
                }
            }

            val logText = allJobLogs.toString()
            appendLog("✓ Log: ${logText.length / 1024} KB, ${logText.lines().size} lines")
            mainHandler.post { showLogDialog(logText, runNum) }
        } catch (e: Exception) {
            appendLog("✗ Log error: ${e.message}")
        } finally {
            setBusy(false)
        }
    }

    private fun showLogDialog(logText: String, runId: Long) {
        val ansiRegex = Regex("""\x1B\[[0-9;]*[A-Za-z]""")
        val tsRegex   = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
        val groupRx   = Regex("""^##\[(?:group|endgroup)\]""")

        val lines = logText.lines()
        val cleaned = lines
            .map  { ansiRegex.replace(tsRegex.replace(it, ""), "") }
            .filter { !groupRx.containsMatchIn(it) }

        val sizeStr = when {
            logText.length >= 1_048_576 -> "%.1f MB".format(logText.length / 1_048_576.0)
            logText.length >= 1_024     -> "${logText.length / 1024} KB"
            else                        -> "${logText.length} B"
        }

        // Build display the same way Browse Artifacts does — styled TextView in a dark card
        val ctx = this
        val sv  = ScrollView(ctx)
        sv.setBackgroundColor(0xFF0D0D0D.toInt())
        val tv = TextView(ctx).apply {
            text = buildString {
                append("⚙  Run #$runId   •   $sizeStr   •   ${cleaned.size} lines\n")
                append("─────────────────────────────────────\n")
                append(cleaned.joinToString("\n"))
            }
            textSize = 9.5f
            setTextColor(0xFF00E676.toInt())   // same green as console log
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(24, 24, 24, 24)
            setLineSpacing(0f, 1.25f)
        }
        sv.addView(tv)
        sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }

        AlertDialog.Builder(ctx)
            .setTitle("🔍  Build Log — Run #$runId")
            .setView(sv)
            .setPositiveButton("📋 Copy All") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Build Log", logText))
                appendLog("✓ Full log copied ($sizeStr).")
            }
            .setNeutralButton("↙ Tail Console") { _, _ ->
                appendLog("=== Log Run #$runId ===")
                cleaned.takeLast(60).forEach { appendLog(it) }
                appendLog("=== End ===")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ── Clipboard & share ─────────────────────────────────────────────────────

    private fun copyLogToClipboard() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Build Log", text))
        appendLog("✓ Log copied to clipboard.")
    }

    private fun saveLogToFile() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        thread {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
                val file  = File(cacheDir, "build_log_$stamp.txt").also { it.writeText(text) }
                val uri   = FileProvider.getUriForFile(this, "${packageName}.provider", file)
                mainHandler.post {
                    startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "Share Build Log"))
                }
            } catch (e: Exception) { appendLog("✗ Share error: ${e.message}") }
        }
    }

    // ── HTTP ──────────────────────────────────────────────────────────────────

    private fun httpGet(token: String, urlStr: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000; readTimeout = 30_000
        })

    private fun httpPut(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 120_000; readTimeout = 120_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun httpPost(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun httpDelete(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    private fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    private fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(when {
            text.contains("✓") || text.startsWith("Ready") -> 0xFF4CAF50.toInt()
            text.contains("✗") || text.contains("failed")  -> 0xFFFF5252.toInt()
            else                                             -> 0xFFFFFFFF.toInt()
        })
    }

    private fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy                   = busy
        progressBar.visibility   = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
        btnManageZips.isEnabled  = !busy
        // Download button: only re-enable when not busy AND an artifact URL is known
        if (!busy) btnDownloadApk.isEnabled = (artifactDownloadUrl != null)
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun resolveFileName(uri: Uri): String {
        var name = "project.zip"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        name = name.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    private fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
