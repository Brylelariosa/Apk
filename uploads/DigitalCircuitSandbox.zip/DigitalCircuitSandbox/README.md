# Digital Circuit Sandbox

A native Android digital-logic circuit editor and simulator. 100% offline —
no network permission is requested anywhere in the manifest, and the
project has zero ad/analytics/account dependencies.

## Honest status: this is a foundation, not the finished spec

The original brief asks for a complete, polished app covering ~40 component
types across six categories, a full debugging/learning suite, mini-map,
custom modules, and more. That is a multi-week build. What's in this zip is
a **real, working, non-trivial foundation** for it — not a stub and not a
mockup — built so the rest can be added on top without re-architecting:

**Implemented now**
- Native C++ simulation engine (event-driven propagation, oscillation
  detection, floating-input detection, short-circuit detection), reached
  from Kotlin over a real JNI bridge — not a placeholder.
- 14 component types: Switch, Push Button, Power, Ground, Clock, LED, and
  all 8 logic gates (AND/OR/XOR/XNOR/NAND/NOR/NOT/Buffer).
- Infinite pan/zoom canvas, adaptive grid, procedural vector rendering
  (every shape is drawn with `Path`/`Canvas`, no bitmaps), animated signal
  flow along wires, glowing LEDs.
- Touch interaction: place, drag with grid snapping, rotate, mirror,
  multi-select via selection box, wire drawing by dragging pin-to-pin.
- Undo/redo via command pattern.
- Local save/load to JSON (hand-written, no serialization library).
- Three themes: Dark, Light, Blueprint (cycle via the toolbar overflow menu).
- Per-component description + truth table, shown in a bottom sheet on tap.

**Deliberately not implemented yet** (see Roadmap) — Memory, Arithmetic,
Display and Misc. component categories; mini-map; component search;
custom reusable modules; wire auto-routing around obstacles; gate timing
analysis; component/wire inspectors beyond the truth-table sheet;
auto-save/backup recovery; project thumbnails/favorites; accessibility
pass; tooltips.

I can't compile or run this inside the sandbox I built it in (no network
access, no Android SDK/NDK installed there), so **I have not verified it
builds**. I checked it carefully by hand — directory layout, Gradle/AGP/
Kotlin/NDK version compatibility, and a full cross-check that every JNI
`external fun` in `NativeSimulation.kt` has a matching `Java_...` symbol in
`jni_bridge.cpp` (14/14 match) — but a hand review is not a compiler. Please
treat the first build as the real test, and send me whatever error comes
back if one does; that's much faster to fix than guessing blind.

## Architecture

```
app/src/main/
  cpp/                     # native simulation engine (C++17, JNI)
    CMakeLists.txt
    jni_bridge.cpp
    core/
      gate_types.h          # GateType enum — ordinal must mirror ComponentType.kt
      gate.h / gate.cpp      # single-gate evaluation logic
      simulation_engine.h/.cpp  # graph, propagation, error detection
  java/com/circuitsandbox/app/
    model/        # CircuitModel, ComponentInstance, WireInstance — pure data
    simulation/   # NativeSimulation (JNI wrapper), SimulationController (loop)
    render/       # GateRenderer, WireRenderer, GridRenderer, CircuitTheme
    ui/           # CircuitCanvasView (gestures + drawing), MainActivity
    undo/         # Command pattern + CommandHistory
    persistence/  # CircuitSerializer (org.json), ProjectRepository
```

**Why native C++ for simulation, not Kotlin?** Your CI workflow already
installs the NDK and caches `core/*.cpp`/`jni_bridge.cpp`, so I matched that
architecture rather than introducing a second one. It also genuinely suits
the brief's "thousands of components, multi-threaded simulation" requirement
better than a pure-Kotlin graph walk would.

**Why traditional Views instead of Jetpack Compose?** The brief repeatedly
emphasizes APK size and minimal dependencies. Compose's runtime adds real
weight for comparatively little benefit on a screen that's 90% one custom
canvas. Material Components (the XML library) still gives genuine Material
3 styling without that cost.

**Why `org.json` instead of kotlinx.serialization?** Same reasoning —
`org.json` ships with the OS, so saving a circuit costs zero extra
dependencies.

## Known limitations / rough edges to expect

- `snapshotOutputs()` rebuilds a `HashMap` every simulation tick. Fine at
  hundreds of components; for the "thousands of components at 60fps" goal
  in the original brief this should move to a flat array keyed by a dense
  index instead of a `Map<Int, Boolean>`.
- Wire routing is a simple 3-segment orthogonal path — no obstacle
  avoidance yet.
- `gradlew`/`gradlew.bat` are streamlined rewrites of the standard Gradle
  wrapper scripts, not byte-identical to the official ones. They should
  work, but if your CI ever complains, regenerate the official versions
  with `gradle wrapper --gradle-version 8.6` and recommit.
- ABI filters include `x86_64` for emulator convenience; drop it before a
  real Play Store release to shave APK size.

## Build

This project is meant to go through the GitHub Actions workflow you
already have (NDK + CMake install, gradlew assemble). Locally:

```
./gradlew assembleDebug
```

requires Android SDK + NDK 25.2.9519653 + CMake 3.22.1 installed.

## Roadmap (suggested order)

1. **Fix what doesn't compile.** Real first step — see above.
2. **Memory components**: SR latch, D/JK/T flip-flop, register, counter —
   these need the simulation engine to track *previous* tick state, which
   the current `Gate::evaluate` deliberately keeps simple (combinational
   only) and will need extending.
3. **Arithmetic + displays**: half/full adder, comparator, encoder/decoder,
   mux/demux, seven-segment/hex/binary displays — all buildable on the
   existing gate-graph model with new `GateType` cases.
4. **Debugging tools**: dedicated inspector panels, timing/power analysis,
   disconnected-wire finder — mostly UI on top of data the engine already
   computes (`SimulationReport` already flags oscillation/floating/short).
5. **Mini-map, component search, custom modules, auto-save/thumbnails.**

Happy to keep building any of these next — just say which phase.
