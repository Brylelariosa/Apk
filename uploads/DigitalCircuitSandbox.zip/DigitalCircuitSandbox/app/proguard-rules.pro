# Keep every native (JNI) entry point — names must survive obfuscation
# exactly as Java_com_circuitsandbox_app_simulation_NativeSimulation_*
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.circuitsandbox.app.simulation.NativeSimulation { *; }

# Model classes are (de)serialized to/from JSON by field name via
# reflection-free hand-written code, but keep enum names stable anyway
# since save files store ComponentType by name().
-keepclassmembers enum com.circuitsandbox.app.model.ComponentType { *; }
