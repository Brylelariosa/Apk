#include <jni.h>
#include <vector>
#include <unordered_map>
#include <mutex>
#include "core/simulation_engine.h"

namespace {

// Registry of live engine instances keyed by an opaque handle. Using a
// registry (rather than reinterpret_cast<jlong> of a raw pointer) means an
// invalid/stale handle from the Kotlin side can never crash the process —
// it just becomes a no-op.
std::mutex g_registryMutex;
std::unordered_map<jlong, circuitcore::SimulationEngine*> g_registry;
jlong g_nextHandle = 1;

circuitcore::SimulationEngine* engineFor(jlong handle) {
    std::lock_guard<std::mutex> lock(g_registryMutex);
    auto it = g_registry.find(handle);
    return it == g_registry.end() ? nullptr : it->second;
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeCreate(JNIEnv*, jobject) {
    auto* engine = new circuitcore::SimulationEngine();
    std::lock_guard<std::mutex> lock(g_registryMutex);
    jlong handle = g_nextHandle++;
    g_registry[handle] = engine;
    return handle;
}

JNIEXPORT void JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    std::lock_guard<std::mutex> lock(g_registryMutex);
    auto it = g_registry.find(handle);
    if (it != g_registry.end()) {
        delete it->second;
        g_registry.erase(it);
    }
}

JNIEXPORT jint JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeAddGate(
        JNIEnv*, jobject, jlong handle, jint id, jint type, jint numInputs, jint numOutputs) {
    auto* engine = engineFor(handle);
    if (!engine) return -1;
    return engine->addGate(id, type, numInputs, numOutputs);
}

JNIEXPORT void JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeRemoveGate(
        JNIEnv*, jobject, jlong handle, jint gateId) {
    auto* engine = engineFor(handle);
    if (engine) engine->removeGate(gateId);
}

JNIEXPORT jboolean JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeConnect(
        JNIEnv*, jobject, jlong handle, jint fromGate, jint fromPin, jint toGate, jint toPin) {
    auto* engine = engineFor(handle);
    if (!engine) return JNI_FALSE;
    return engine->connect(fromGate, fromPin, toGate, toPin) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeDisconnect(
        JNIEnv*, jobject, jlong handle, jint fromGate, jint fromPin, jint toGate, jint toPin) {
    auto* engine = engineFor(handle);
    if (engine) engine->disconnect(fromGate, fromPin, toGate, toPin);
}

JNIEXPORT void JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeSetManualState(
        JNIEnv*, jobject, jlong handle, jint gateId, jboolean state) {
    auto* engine = engineFor(handle);
    if (engine) engine->setManualState(gateId, state == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeSetClockPeriod(
        JNIEnv*, jobject, jlong handle, jint gateId, jint halfPeriodTicks) {
    auto* engine = engineFor(handle);
    if (engine) engine->setClockPeriod(gateId, halfPeriodTicks);
}

JNIEXPORT jboolean JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeOutputState(
        JNIEnv*, jobject, jlong handle, jint gateId, jint pinIndex) {
    auto* engine = engineFor(handle);
    if (!engine) return JNI_FALSE;
    return engine->outputState(gateId, pinIndex) ? JNI_TRUE : JNI_FALSE;
}

// Packs a SimulationReport into a flat jintArray so the Kotlin side avoids
// a per-field JNI call: [hasOscillation, hasFloating, hasShort,
//   oscillatingCount, ...oscillatingIds, floatingCount, ...floatingIds]
JNIEXPORT jintArray JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeStep(
        JNIEnv* env, jobject, jlong handle, jint maxIterations) {
    auto* engine = engineFor(handle);
    if (!engine) return env->NewIntArray(0);

    circuitcore::SimulationReport report = engine->step(maxIterations);

    std::vector<jint> packed;
    packed.push_back(report.hasOscillation ? 1 : 0);
    packed.push_back(report.hasFloatingInput ? 1 : 0);
    packed.push_back(report.hasShortCircuit ? 1 : 0);
    packed.push_back(static_cast<jint>(report.oscillatingGateIds.size()));
    for (int id : report.oscillatingGateIds) packed.push_back(id);
    packed.push_back(static_cast<jint>(report.floatingInputGateIds.size()));
    for (int id : report.floatingInputGateIds) packed.push_back(id);

    jintArray result = env->NewIntArray(static_cast<jsize>(packed.size()));
    if (result != nullptr && !packed.empty()) {
        env->SetIntArrayRegion(result, 0, static_cast<jsize>(packed.size()), packed.data());
    }
    return result;
}

// Batched output read used by the renderer once per frame instead of one
// JNI call per gate — this is the call that matters most for keeping
// rendering cheap with large circuits.
JNIEXPORT jbooleanArray JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeGetOutputs(
        JNIEnv* env, jobject, jlong handle, jintArray gateIds, jintArray pinIndices) {
    jsize count = env->GetArrayLength(gateIds);
    jbooleanArray result = env->NewBooleanArray(count);
    auto* engine = engineFor(handle);
    if (!engine || count == 0) return result;

    std::vector<jint> ids(count);
    std::vector<jint> pins(count);
    env->GetIntArrayRegion(gateIds, 0, count, ids.data());
    env->GetIntArrayRegion(pinIndices, 0, count, pins.data());

    std::vector<jboolean> values(count);
    for (jsize i = 0; i < count; ++i) {
        values[i] = engine->outputState(ids[i], pins[i]) ? JNI_TRUE : JNI_FALSE;
    }
    env->SetBooleanArrayRegion(result, 0, count, values.data());
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeInputState(
        JNIEnv*, jobject, jlong handle, jint gateId, jint pinIndex) {
    auto* engine = engineFor(handle);
    if (!engine) return JNI_FALSE;
    return engine->inputState(gateId, pinIndex) ? JNI_TRUE : JNI_FALSE;
}

// Mirrors nativeGetOutputs but reads input-pin state. Needed for sink-only
// components such as the LED, which has zero output pins — its visible
// "lit" state is its single input pin's value, not an output pin's.
JNIEXPORT jbooleanArray JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeGetInputs(
        JNIEnv* env, jobject, jlong handle, jintArray gateIds, jintArray pinIndices) {
    jsize count = env->GetArrayLength(gateIds);
    jbooleanArray result = env->NewBooleanArray(count);
    auto* engine = engineFor(handle);
    if (!engine || count == 0) return result;

    std::vector<jint> ids(count);
    std::vector<jint> pins(count);
    env->GetIntArrayRegion(gateIds, 0, count, ids.data());
    env->GetIntArrayRegion(pinIndices, 0, count, pins.data());

    std::vector<jboolean> values(count);
    for (jsize i = 0; i < count; ++i) {
        values[i] = engine->inputState(ids[i], pins[i]) ? JNI_TRUE : JNI_FALSE;
    }
    env->SetBooleanArrayRegion(result, 0, count, values.data());
    return result;
}

JNIEXPORT void JNICALL
Java_com_circuitsandbox_app_simulation_NativeSimulation_nativeReset(JNIEnv*, jobject, jlong handle) {
    auto* engine = engineFor(handle);
    if (engine) engine->reset();
}

} // extern "C"
