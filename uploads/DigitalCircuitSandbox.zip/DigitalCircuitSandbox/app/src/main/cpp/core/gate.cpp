#include "gate.h"

namespace circuitcore {

Gate::Gate(int id, GateType type, int numInputs, int numOutputs)
    : id_(id), type_(type), inputs_(numInputs, false), outputs_(numOutputs, false) {}

bool Gate::inputAt(int index) const {
    if (index < 0 || index >= static_cast<int>(inputs_.size())) return false;
    return inputs_[index];
}

void Gate::setInputAt(int index, bool value) {
    if (index < 0 || index >= static_cast<int>(inputs_.size())) return;
    inputs_[index] = value;
}

bool Gate::outputAt(int index) const {
    if (index < 0 || index >= static_cast<int>(outputs_.size())) return false;
    return outputs_[index];
}

bool Gate::evaluate(long long simulationTick) {
    bool newOutput = outputs_.empty() ? false : outputs_[0];

    switch (type_) {
        case GateType::INPUT_SWITCH:
        case GateType::PUSH_BUTTON:
        case GateType::POWER:
            newOutput = manualState_;
            break;
        case GateType::GROUND:
            newOutput = false;
            break;
        case GateType::CLOCK: {
            int period = clockHalfPeriodTicks_ <= 0 ? 1 : clockHalfPeriodTicks_;
            newOutput = ((simulationTick / period) % 2) == 0;
            break;
        }
        case GateType::OUTPUT_LED:
            newOutput = !inputs_.empty() && inputs_[0];
            break;
        case GateType::AND: {
            newOutput = !inputs_.empty();
            for (bool in : inputs_) newOutput = newOutput && in;
            break;
        }
        case GateType::OR: {
            newOutput = false;
            for (bool in : inputs_) newOutput = newOutput || in;
            break;
        }
        case GateType::XOR: {
            int highCount = 0;
            for (bool in : inputs_) if (in) highCount++;
            newOutput = (highCount % 2) == 1;
            break;
        }
        case GateType::XNOR: {
            int highCount = 0;
            for (bool in : inputs_) if (in) highCount++;
            newOutput = (highCount % 2) == 0;
            break;
        }
        case GateType::NAND: {
            bool allHigh = !inputs_.empty();
            for (bool in : inputs_) allHigh = allHigh && in;
            newOutput = !allHigh;
            break;
        }
        case GateType::NOR: {
            bool anyHigh = false;
            for (bool in : inputs_) anyHigh = anyHigh || in;
            newOutput = !anyHigh;
            break;
        }
        case GateType::NOT:
            newOutput = inputs_.empty() ? true : !inputs_[0];
            break;
        case GateType::BUFFER:
            newOutput = !inputs_.empty() && inputs_[0];
            break;
    }

    bool changed = !outputs_.empty() && (outputs_[0] != newOutput);
    if (!outputs_.empty()) outputs_[0] = newOutput;
    return changed;
}

} // namespace circuitcore
