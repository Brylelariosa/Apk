#ifndef CIRCUITCORE_GATE_TYPES_H
#define CIRCUITCORE_GATE_TYPES_H

namespace circuitcore {

// IMPORTANT: this ordering must exactly mirror `ComponentType` in
// ComponentType.kt on the Kotlin side. The integer ordinal is passed
// across the JNI boundary directly (see jni_bridge.cpp / NativeSimulation.kt)
// — reordering one side without the other will silently corrupt simulation
// behaviour instead of producing a compile error, so treat this enum as a
// stable wire format, not an implementation detail.
enum class GateType : int {
    INPUT_SWITCH = 0,
    PUSH_BUTTON = 1,
    POWER = 2,
    GROUND = 3,
    CLOCK = 4,
    OUTPUT_LED = 5,
    AND = 6,
    OR = 7,
    XOR = 8,
    XNOR = 9,
    NAND = 10,
    NOR = 11,
    NOT = 12,
    BUFFER = 13
};

} // namespace circuitcore

#endif // CIRCUITCORE_GATE_TYPES_H
