#include "simulation_engine.h"
#include <algorithm>
#include <unordered_set>

namespace circuitcore {

int SimulationEngine::addGate(int id, int type, int numInputs, int numOutputs) {
    std::lock_guard<std::mutex> lock(mutex_);
    gates_.emplace(id, Gate(id, static_cast<GateType>(type), numInputs, numOutputs));
    outgoing_[id]; // ensure an (empty) entry exists
    return id;
}

void SimulationEngine::removeGate(int gateId) {
    std::lock_guard<std::mutex> lock(mutex_);
    gates_.erase(gateId);
    outgoing_.erase(gateId);
    connections_.erase(
        std::remove_if(connections_.begin(), connections_.end(),
            [gateId](const Connection& c) {
                return c.from.gateId == gateId || c.to.gateId == gateId;
            }),
        connections_.end());
    rebuildOutgoingIndex();
}

bool SimulationEngine::connect(int fromGate, int fromPin, int toGate, int toPin) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (gates_.find(fromGate) == gates_.end() || gates_.find(toGate) == gates_.end()) {
        return false;
    }
    Connection c{{fromGate, fromPin}, {toGate, toPin}};
    outgoing_[fromGate].push_back(static_cast<int>(connections_.size()));
    connections_.push_back(c);
    return true;
}

void SimulationEngine::disconnect(int fromGate, int fromPin, int toGate, int toPin) {
    std::lock_guard<std::mutex> lock(mutex_);
    connections_.erase(
        std::remove_if(connections_.begin(), connections_.end(),
            [&](const Connection& c) {
                return c.from.gateId == fromGate && c.from.pinIndex == fromPin &&
                       c.to.gateId == toGate && c.to.pinIndex == toPin;
            }),
        connections_.end());
    rebuildOutgoingIndex();
}

void SimulationEngine::rebuildOutgoingIndex() {
    for (auto& entry : outgoing_) entry.second.clear();
    for (size_t i = 0; i < connections_.size(); ++i) {
        outgoing_[connections_[i].from.gateId].push_back(static_cast<int>(i));
    }
}

void SimulationEngine::setManualState(int gateId, bool state) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = gates_.find(gateId);
    if (it != gates_.end()) it->second.setManualState(state);
}

void SimulationEngine::setClockPeriod(int gateId, int halfPeriodTicks) {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = gates_.find(gateId);
    if (it != gates_.end()) it->second.setClockHalfPeriodTicks(halfPeriodTicks);
}

bool SimulationEngine::outputState(int gateId, int pinIndex) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = gates_.find(gateId);
    if (it == gates_.end()) return false;
    return it->second.outputAt(pinIndex);
}

bool SimulationEngine::inputState(int gateId, int pinIndex) const {
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = gates_.find(gateId);
    if (it == gates_.end()) return false;
    return it->second.inputAt(pinIndex);
}

bool SimulationEngine::hasFloatingInputs(int gateId) const {
    // An input pin is "floating" if no connection drives it at all.
    std::unordered_set<long long> driven;
    for (const auto& c : connections_) {
        driven.insert((static_cast<long long>(c.to.gateId) << 32) |
                      static_cast<unsigned int>(c.to.pinIndex));
    }
    auto it = gates_.find(gateId);
    if (it == gates_.end()) return false;
    int n = it->second.numInputs();
    for (int i = 0; i < n; ++i) {
        long long key = (static_cast<long long>(gateId) << 32) | static_cast<unsigned int>(i);
        if (driven.find(key) == driven.end()) return true;
    }
    return false;
}

void SimulationEngine::propagateFrom(int gateId, std::vector<int>& dirtyOut) {
    auto outIt = outgoing_.find(gateId);
    if (outIt == outgoing_.end()) return;
    for (int connIndex : outIt->second) {
        const Connection& c = connections_[connIndex];
        auto fromGateIt = gates_.find(c.from.gateId);
        auto toGateIt = gates_.find(c.to.gateId);
        if (fromGateIt == gates_.end() || toGateIt == gates_.end()) continue;
        bool value = fromGateIt->second.outputAt(c.from.pinIndex);
        toGateIt->second.setInputAt(c.to.pinIndex, value);
        dirtyOut.push_back(c.to.gateId);
    }
}

SimulationReport SimulationEngine::step(int maxIterationsPerTick) {
    std::lock_guard<std::mutex> lock(mutex_);
    SimulationReport report;
    tick_++;

    // Every gate is a propagation candidate on tick 0 of the wave; after
    // that only gates downstream of an actual output change are touched.
    std::vector<int> dirty;
    dirty.reserve(gates_.size());
    for (auto& entry : gates_) dirty.push_back(entry.first);

    std::unordered_map<int, int> evaluationCount;
    int iterations = 0;

    while (!dirty.empty() && iterations < maxIterationsPerTick) {
        std::vector<int> nextDirty;
        std::unordered_set<int> nextDirtySet;

        for (int gateId : dirty) {
            auto it = gates_.find(gateId);
            if (it == gates_.end()) continue;

            int& count = evaluationCount[gateId];
            count++;
            if (count > maxIterationsPerTick / 2) {
                // This gate keeps flipping within a single tick — it is
                // part of an unstable feedback loop (e.g. NOT gate feeding
                // its own input), not a normal settling transient.
                if (std::find(report.oscillatingGateIds.begin(), report.oscillatingGateIds.end(), gateId)
                    == report.oscillatingGateIds.end()) {
                    report.oscillatingGateIds.push_back(gateId);
                }
                continue;
            }

            bool changed = it->second.evaluate(tick_);
            if (changed) {
                std::vector<int> downstream;
                propagateFrom(gateId, downstream);
                for (int d : downstream) {
                    if (nextDirtySet.insert(d).second) nextDirty.push_back(d);
                }
            }
        }

        dirty = std::move(nextDirty);
        iterations++;
    }

    report.hasOscillation = !report.oscillatingGateIds.empty();

    // Floating-input detection: any logic/output gate with an
    // unconnected input pin is flagged.
    for (auto& entry : gates_) {
        GateType t = entry.second.type();
        bool isLogicOrSink = (t == GateType::AND || t == GateType::OR || t == GateType::XOR ||
                               t == GateType::XNOR || t == GateType::NAND || t == GateType::NOR ||
                               t == GateType::NOT || t == GateType::BUFFER || t == GateType::OUTPUT_LED);
        if (isLogicOrSink && hasFloatingInputs(entry.first)) {
            report.floatingInputGateIds.push_back(entry.first);
        }
    }
    report.hasFloatingInput = !report.floatingInputGateIds.empty();

    // Short-circuit detection: two different wires driving the same input
    // pin with conflicting logic values during this tick.
    std::unordered_map<long long, std::vector<bool>> destValues;
    for (const auto& c : connections_) {
        auto fromIt = gates_.find(c.from.gateId);
        if (fromIt == gates_.end()) continue;
        long long key = (static_cast<long long>(c.to.gateId) << 32) |
                        static_cast<unsigned int>(c.to.pinIndex);
        destValues[key].push_back(fromIt->second.outputAt(c.from.pinIndex));
    }
    for (auto& kv : destValues) {
        if (kv.second.size() < 2) continue;
        bool first = kv.second[0];
        for (bool v : kv.second) {
            if (v != first) {
                report.hasShortCircuit = true;
                break;
            }
        }
        if (report.hasShortCircuit) break;
    }

    return report;
}

void SimulationEngine::reset() {
    std::lock_guard<std::mutex> lock(mutex_);
    tick_ = 0;
    for (auto& entry : gates_) {
        Gate fresh(entry.second.id(), entry.second.type(), entry.second.numInputs(), entry.second.numOutputs());
        fresh.setManualState(entry.second.manualState());
        entry.second = fresh;
    }
}

std::vector<int> SimulationEngine::allGateIds() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<int> ids;
    ids.reserve(gates_.size());
    for (auto& entry : gates_) ids.push_back(entry.first);
    return ids;
}

} // namespace circuitcore
