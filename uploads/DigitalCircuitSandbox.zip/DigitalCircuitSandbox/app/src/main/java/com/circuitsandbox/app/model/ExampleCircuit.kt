package com.circuitsandbox.app.model

enum class Difficulty(val label: String) {
    BEGINNER("Beginner"),
    INTERMEDIATE("Intermediate"),
    ADVANCED("Advanced"),
    COMING_SOON("Coming Soon")
}

/**
 * One entry in the built-in example library.
 *
 * [model] is null for [Difficulty.COMING_SOON] entries — those are shown
 * greyed-out in the browser as a preview of what's planned but not yet
 * implemented (mostly circuits that require flip-flop / memory components
 * which the simulation engine does not yet support).
 */
data class ExampleCircuit(
    val title: String,
    val difficulty: Difficulty,
    val description: String,
    val howItWorks: String = "",
    val model: CircuitModel? = null
) {
    val isAvailable: Boolean get() = model != null

    companion object {
        fun planned(title: String, difficulty: Difficulty, description: String) =
            ExampleCircuit(title, difficulty, description, model = null)
    }
}
