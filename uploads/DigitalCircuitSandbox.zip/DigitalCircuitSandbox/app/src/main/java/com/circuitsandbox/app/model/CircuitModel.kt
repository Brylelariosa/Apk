package com.circuitsandbox.app.model

/**
 * In-memory representation of one circuit. Pure data with no Android or
 * rendering dependencies, so it can be unit-tested, serialized, and driven
 * by the native simulation engine independently of the UI layer.
 */
class CircuitModel {
    private val components = linkedMapOf<Int, ComponentInstance>()
    private val wires = linkedMapOf<Int, WireInstance>()
    private var nextComponentIdCounter = 1
    private var nextWireIdCounter = 1

    val allComponents: Collection<ComponentInstance> get() = components.values
    val allWires: Collection<WireInstance> get() = wires.values

    fun componentById(id: Int): ComponentInstance? = components[id]
    fun wireById(id: Int): WireInstance? = wires[id]

    fun nextComponentId(): Int = nextComponentIdCounter++
    fun nextWireId(): Int = nextWireIdCounter++

    fun addComponent(component: ComponentInstance) {
        components[component.id] = component
        if (component.id >= nextComponentIdCounter) nextComponentIdCounter = component.id + 1
    }

    fun removeComponent(id: Int) {
        components.remove(id)
        val toRemove = wires.values.filter { it.from.componentId == id || it.to.componentId == id }
        toRemove.forEach { wires.remove(it.id) }
    }

    fun addWire(wire: WireInstance) {
        wires[wire.id] = wire
        if (wire.id >= nextWireIdCounter) nextWireIdCounter = wire.id + 1
    }

    fun removeWire(id: Int) {
        wires.remove(id)
    }

    fun wiresConnectedTo(componentId: Int): List<WireInstance> =
        wires.values.filter { it.from.componentId == componentId || it.to.componentId == componentId }

    /** Topmost (last-added) component at a world-space point, or null. */
    fun componentAt(worldX: Float, worldY: Float): ComponentInstance? =
        components.values.lastOrNull { it.containsPoint(worldX, worldY) }

    fun clear() {
        components.clear()
        wires.clear()
        nextComponentIdCounter = 1
        nextWireIdCounter = 1
    }
}
