package com.circuitsandbox.app.undo

/**
 * Simple linear undo/redo stack (command pattern). Executing a new
 * command always clears the redo stack, matching standard editor
 * behaviour.
 *
 * `maxHistory` is intentionally very high rather than truly infinite —
 * "unlimited" undo with a generous safety cap, so a multi-hour editing
 * session can't accumulate unbounded memory.
 */
class CommandHistory(private val maxHistory: Int = 20_000) {

    private val undoStack = ArrayDeque<Command>()
    private val redoStack = ArrayDeque<Command>()

    fun execute(command: Command) {
        command.execute()
        undoStack.addLast(command)
        if (undoStack.size > maxHistory) undoStack.removeFirst()
        redoStack.clear()
    }

    fun undo() {
        val command = undoStack.removeLastOrNull() ?: return
        command.undo()
        redoStack.addLast(command)
    }

    fun redo() {
        val command = redoStack.removeLastOrNull() ?: return
        command.execute()
        undoStack.addLast(command)
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    /** Wipes both stacks. Used when loading a saved project or an example
     * circuit, so Undo can't travel back "before" the load action. */
    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}
