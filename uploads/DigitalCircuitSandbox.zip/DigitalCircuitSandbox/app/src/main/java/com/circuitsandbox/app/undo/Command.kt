package com.circuitsandbox.app.undo

interface Command {
    fun execute()
    fun undo()
}
