package com.circuitsandbox.app.model

import kotlin.math.cos
import kotlin.math.sin

/** A placed instance of a [ComponentType] on the canvas, in world-space
 * coordinates (independent of the current pan/zoom transform). */
data class ComponentInstance(
    val id: Int,
    val type: ComponentType,
    var x: Float,
    var y: Float,
    var rotationDegrees: Int = 0,
    var mirrored: Boolean = false,
    var label: String? = null
) {
    companion object {
        const val GRID_UNIT = 80f
        const val PIN_SPACING = 30f
    }

    val width: Float get() = GRID_UNIT
    val height: Float get() = maxOf(type.inputCount, type.outputCount, 1) * PIN_SPACING + 20f

    fun inputPinWorldPosition(index: Int): Pair<Float, Float> = pinWorldPosition(index, isInput = true)
    fun outputPinWorldPosition(index: Int): Pair<Float, Float> = pinWorldPosition(index, isInput = false)

    private fun pinWorldPosition(index: Int, isInput: Boolean): Pair<Float, Float> {
        val count = if (isInput) type.inputCount else type.outputCount
        val totalSpan = (count - 1).coerceAtLeast(0) * PIN_SPACING
        val localY = -totalSpan / 2f + index * PIN_SPACING
        var localX = if (isInput) -width / 2f else width / 2f
        if (mirrored) localX = -localX

        val rad = Math.toRadians(rotationDegrees.toDouble())
        val cosR = cos(rad).toFloat()
        val sinR = sin(rad).toFloat()
        val worldX = x + localX * cosR - localY * sinR
        val worldY = y + localX * sinR + localY * cosR
        return worldX to worldY
    }

    /** Hit-test in world space, accounting for rotation. */
    fun containsPoint(px: Float, py: Float): Boolean {
        val rad = Math.toRadians(-rotationDegrees.toDouble())
        val dx = px - x
        val dy = py - y
        val localX = dx * cos(rad).toFloat() - dy * sin(rad).toFloat()
        val localY = dx * sin(rad).toFloat() + dy * cos(rad).toFloat()
        return localX in -width / 2f..width / 2f && localY in -height / 2f..height / 2f
    }
}
