package com.circuitsandbox.app.simulation

import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the native simulation instance for one [CircuitModel] and drives the
 * real-time loop on a background coroutine, so gate evaluation never blocks
 * the UI thread even on a large circuit.
 */
class SimulationController(private val circuit: CircuitModel) {

    private val native = NativeSimulation()
    private var loopJob: Job? = null

    var isRunning: Boolean = false
        private set

    var ticksPerSecond: Int = 30
        set(value) {
            field = value.coerceIn(1, 240)
        }

    var onStateChanged: ((NativeSimulation.StepReport) -> Unit)? = null

    /** Call after any topology change (component or wire added/removed)
     * while the simulation is stopped. Rebuilds the native graph from
     * scratch from the current [CircuitModel]. */
    fun rebuild() {
        native.reset()
        for (component in circuit.allComponents) {
            native.addGate(
                component.id,
                component.type.ordinal,
                component.type.inputCount,
                component.type.outputCount
            )
        }
        for (wire in circuit.allWires) {
            native.connect(wire.from.componentId, wire.from.pinIndex, wire.to.componentId, wire.to.pinIndex)
        }
    }

    fun setSwitchState(componentId: Int, state: Boolean) {
        native.setManualState(componentId, state)
    }

    fun outputState(component: ComponentInstance, pinIndex: Int = 0): Boolean =
        native.outputState(component.id, pinIndex)

    /** One or two JNI calls for the whole circuit's current visible state —
     * used by the renderer every frame rather than querying gate-by-gate.
     *
     * Most components light up their output pin's value, but sink-only
     * components with zero output pins (currently just the LED) show their
     * *input* pin's value instead, since they have no output to read. */
    fun snapshotOutputs(): Map<Int, Boolean> {
        val withOutput = circuit.allComponents.filter { it.type.outputCount > 0 }
        val withoutOutput = circuit.allComponents.filter { it.type.outputCount == 0 && it.type.inputCount > 0 }

        val result = HashMap<Int, Boolean>(circuit.allComponents.size)

        if (withOutput.isNotEmpty()) {
            val ids = withOutput.map { it.id }.toIntArray()
            val pins = IntArray(ids.size) // every implemented gate's primary output is pin 0
            val values = native.outputsFor(ids, pins)
            ids.indices.forEach { result[ids[it]] = values[it] }
        }
        if (withoutOutput.isNotEmpty()) {
            val ids = withoutOutput.map { it.id }.toIntArray()
            val pins = IntArray(ids.size) // every implemented sink's relevant input is pin 0
            val values = native.inputsFor(ids, pins)
            ids.indices.forEach { result[ids[it]] = values[it] }
        }
        return result
    }

    fun singleStep(): NativeSimulation.StepReport {
        val report = native.step()
        onStateChanged?.invoke(report)
        return report
    }

    fun start(scope: CoroutineScope) {
        if (isRunning) return
        isRunning = true
        loopJob = scope.launch(Dispatchers.Default) {
            while (isActive && isRunning) {
                val report = native.step()
                withContext(Dispatchers.Main) { onStateChanged?.invoke(report) }
                delay((1000L / ticksPerSecond).coerceAtLeast(1L))
            }
        }
    }

    fun pause() {
        isRunning = false
        loopJob?.cancel()
        loopJob = null
    }

    fun release() {
        pause()
        native.release()
    }
}
