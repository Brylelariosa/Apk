package com.circuitsandbox.app.render

import android.graphics.Canvas
import android.graphics.Paint

/**
 * Draws an adaptively-fading grid: fine grid lines fade out as the user
 * zooms out (so they never turn into visual noise) while coarse "major"
 * lines stay visible across the whole zoom range.
 */
object GridRenderer {

    private const val MINOR_SPACING = 20f
    private const val MAJOR_EVERY = 4

    private val minorPaint = Paint()
    private val majorPaint = Paint()

    fun draw(
        canvas: Canvas,
        theme: CircuitTheme,
        scale: Float,
        visibleWorldLeft: Float,
        visibleWorldTop: Float,
        visibleWorldRight: Float,
        visibleWorldBottom: Float
    ) {
        minorPaint.color = theme.gridMinor
        minorPaint.strokeWidth = 1f / scale
        majorPaint.color = theme.gridMajor
        majorPaint.strokeWidth = 1.4f / scale

        // Fade the fine grid out below this zoom level.
        val minorAlpha = ((scale - 0.25f) / 0.5f).coerceIn(0f, 1f)
        minorPaint.alpha = (minorAlpha * 255).toInt()

        val startCol = (visibleWorldLeft / MINOR_SPACING).toInt() - 1
        val endCol = (visibleWorldRight / MINOR_SPACING).toInt() + 1
        val startRow = (visibleWorldTop / MINOR_SPACING).toInt() - 1
        val endRow = (visibleWorldBottom / MINOR_SPACING).toInt() + 1

        if (minorPaint.alpha > 0) {
            for (col in startCol..endCol) {
                if (col % MAJOR_EVERY == 0) continue
                val xPos = col * MINOR_SPACING
                canvas.drawLine(xPos, visibleWorldTop, xPos, visibleWorldBottom, minorPaint)
            }
            for (row in startRow..endRow) {
                if (row % MAJOR_EVERY == 0) continue
                val yPos = row * MINOR_SPACING
                canvas.drawLine(visibleWorldLeft, yPos, visibleWorldRight, yPos, minorPaint)
            }
        }

        for (col in startCol..endCol) {
            if (col % MAJOR_EVERY != 0) continue
            val xPos = col * MINOR_SPACING
            canvas.drawLine(xPos, visibleWorldTop, xPos, visibleWorldBottom, majorPaint)
        }
        for (row in startRow..endRow) {
            if (row % MAJOR_EVERY != 0) continue
            val yPos = row * MINOR_SPACING
            canvas.drawLine(visibleWorldLeft, yPos, visibleWorldRight, yPos, majorPaint)
        }
    }
}
