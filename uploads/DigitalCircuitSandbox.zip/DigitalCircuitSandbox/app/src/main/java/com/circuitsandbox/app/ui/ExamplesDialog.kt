package com.circuitsandbox.app.ui

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.circuitsandbox.app.model.Difficulty
import com.circuitsandbox.app.model.ExampleCircuit
import com.circuitsandbox.app.model.ExampleLibrary
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors

/**
 * Bottom-sheet browser for the built-in example circuits.
 *
 * Fully programmatic — no additional layout XML file, which keeps the
 * APK lean and avoids inflating a separate resource file for a screen
 * that only exists here.
 *
 * Call [show] and supply an [onLoad] callback. When the user taps "Load"
 * on a [ExampleCircuit.isAvailable] entry, the callback receives a fresh
 * deep copy of that entry's [ExampleCircuit.model] and the sheet dismisses.
 */
object ExamplesDialog {

    fun show(context: Context, hasUnsavedContent: Boolean, onLoad: (ExampleCircuit) -> Unit) {
        val dialog = BottomSheetDialog(context)

        val scroll = ScrollView(context)
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val dp = context.resources.displayMetrics.density
            setPadding((16 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt(), (40 * dp).toInt())
        }
        scroll.addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        val dp = context.resources.displayMetrics.density

        // --- Sheet title --------------------------------------------------
        root.addView(TextView(context).apply {
            text = "Example Circuits"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, (8 * dp).toInt())
        })
        root.addView(TextView(context).apply {
            text = "Tap any available example to load it onto the canvas. Coming-soon entries preview future features."
            textSize = 13f
            setPadding(0, 0, 0, (16 * dp).toInt())
        })

        // --- Group by difficulty ------------------------------------------
        val groups = ExampleLibrary.all.groupBy { it.difficulty }
        val order = listOf(Difficulty.BEGINNER, Difficulty.INTERMEDIATE, Difficulty.ADVANCED, Difficulty.COMING_SOON)

        for (difficulty in order) {
            val items = groups[difficulty] ?: continue

            // Category header
            root.addView(TextView(context).apply {
                text = difficulty.label
                textSize = 14f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, (12 * dp).toInt(), 0, (4 * dp).toInt())
                setTextColor(difficultyColor(context, difficulty))
            })

            for (example in items) {
                root.addView(buildEntryCard(context, example, dp) {
                    dialog.dismiss()
                    onLoad(it)
                })
            }
        }

        dialog.setContentView(scroll)
        dialog.show()
    }

    private fun buildEntryCard(
        context: Context,
        example: ExampleCircuit,
        dp: Float,
        onLoad: (ExampleCircuit) -> Unit
    ): View {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val bg = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSurface, 0xFF1E2227.toInt())
            setBackgroundColor(bg)
            setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
            val margin = (0 * dp).toInt()
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
            layoutParams = lp
            alpha = if (example.isAvailable) 1f else 0.5f
        }

        card.addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(context).apply {
                text = example.title
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(TextView(context).apply {
                text = example.difficulty.label
                textSize = 11f
                setPadding((8 * dp).toInt(), (2 * dp).toInt(), (8 * dp).toInt(), (2 * dp).toInt())
                setTextColor(difficultyColor(context, example.difficulty))
            })
        })

        card.addView(TextView(context).apply {
            text = example.description
            textSize = 13f
            setPadding(0, (4 * dp).toInt(), 0, 0)
        })

        if (example.isAvailable) {
            card.addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.topMargin = (6 * dp).toInt()
                layoutParams = lp
                addView(Button(context).apply {
                    text = "Load"
                    textSize = 13f
                    setOnClickListener { onLoad(example) }
                })
            })
        }

        return card
    }

    private fun difficultyColor(context: Context, difficulty: Difficulty): Int {
        val res = context.resources
        return when (difficulty) {
            Difficulty.BEGINNER -> 0xFF33C9A6.toInt()
            Difficulty.INTERMEDIATE -> 0xFF4C8DFF.toInt()
            Difficulty.ADVANCED -> 0xFFE5484D.toInt()
            Difficulty.COMING_SOON -> 0xFF888888.toInt()
        }
    }
}
