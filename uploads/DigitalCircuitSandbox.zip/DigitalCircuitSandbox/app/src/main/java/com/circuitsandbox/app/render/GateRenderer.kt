package com.circuitsandbox.app.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import kotlin.math.sin

/**
 * Draws every component as a procedural vector shape (Path / Canvas
 * primitives only — never a bitmap), so components stay crisp at any zoom
 * level and the APK never has to ship per-density PNG assets for them.
 *
 * All Paint objects are held as reusable fields and mutated per draw call
 * rather than allocated fresh, since this runs once per visible component
 * every frame.
 */
object GateRenderer {

    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pinStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val pinDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 22f
    }
    private val reusableRect = RectF()

    fun draw(
        canvas: Canvas,
        component: ComponentInstance,
        theme: CircuitTheme,
        outputHigh: Boolean,
        isSelected: Boolean,
        hasError: Boolean,
        animationPhase: Float = 0f
    ) {
        canvas.save()
        canvas.translate(component.x, component.y)
        canvas.rotate(component.rotationDegrees.toFloat())
        if (component.mirrored) canvas.scale(-1f, 1f)

        outlinePaint.color = when {
            isSelected -> theme.selectionHighlight
            hasError -> theme.wireError
            else -> theme.componentOutline
        }
        fillPaint.color = theme.componentFill
        textPaint.color = theme.textColor

        val halfW = component.width / 2f
        val halfH = component.height / 2f

        when (component.type) {
            ComponentType.AND -> drawAndShape(canvas, halfW, halfH)
            ComponentType.OR -> drawOrShape(canvas, halfW, halfH, withExtraCurve = false)
            ComponentType.XOR -> drawOrShape(canvas, halfW, halfH, withExtraCurve = true)
            ComponentType.NAND -> { drawAndShape(canvas, halfW, halfH); drawBubble(canvas, halfW) }
            ComponentType.NOR -> { drawOrShape(canvas, halfW, halfH, false); drawBubble(canvas, halfW) }
            ComponentType.XNOR -> { drawOrShape(canvas, halfW, halfH, true); drawBubble(canvas, halfW) }
            ComponentType.NOT -> { drawTriangle(canvas, halfW, halfH); drawBubble(canvas, halfW) }
            ComponentType.BUFFER -> drawTriangle(canvas, halfW, halfH)
            ComponentType.INPUT_SWITCH, ComponentType.PUSH_BUTTON ->
                drawSwitch(canvas, halfW, halfH, outputHigh, theme)
            ComponentType.POWER -> drawRail(canvas, halfW, halfH, theme, isPower = true)
            ComponentType.GROUND -> drawRail(canvas, halfW, halfH, theme, isPower = false)
            ComponentType.CLOCK -> drawClock(canvas, halfW, halfH, outputHigh, theme)
            ComponentType.OUTPUT_LED -> drawLed(canvas, halfW, halfH, outputHigh, theme, animationPhase)
        }

        if (component.type != ComponentType.OUTPUT_LED &&
            component.type != ComponentType.POWER &&
            component.type != ComponentType.GROUND
        ) {
            canvas.drawText(component.type.displayName, 0f, halfH + 26f, textPaint)
        }

        drawPins(canvas, component, halfW, theme, outputHigh)
        canvas.restore()
    }

    /** Classic ANSI "D" shape: flat left/top/bottom edges, semicircular right bulge. */
    private fun drawAndShape(canvas: Canvas, halfW: Float, halfH: Float) {
        val path = Path()
        path.moveTo(-halfW, -halfH)
        path.lineTo(0f, -halfH)
        reusableRect.set(-halfH, -halfH, halfH, halfH)
        path.arcTo(reusableRect, -90f, 180f, false)
        path.lineTo(-halfW, halfH)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, outlinePaint)
    }

    /** Curved "shield" OR-gate shape; XOR adds the extra leading curve. */
    private fun drawOrShape(canvas: Canvas, halfW: Float, halfH: Float, withExtraCurve: Boolean) {
        val path = Path()
        path.moveTo(-halfW, -halfH)
        path.quadTo(-halfW * 0.2f, -halfH, halfW, 0f)
        path.quadTo(-halfW * 0.2f, halfH, -halfW, halfH)
        path.quadTo(-halfW * 0.5f, 0f, -halfW, -halfH)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, outlinePaint)
        if (withExtraCurve) {
            val extra = Path()
            extra.moveTo(-halfW * 1.25f, -halfH)
            extra.quadTo(-halfW * 0.75f, 0f, -halfW * 1.25f, halfH)
            canvas.drawPath(extra, outlinePaint)
        }
    }

    /** NOT/Buffer triangle, point facing right. */
    private fun drawTriangle(canvas: Canvas, halfW: Float, halfH: Float) {
        val path = Path()
        path.moveTo(-halfW, -halfH)
        path.lineTo(-halfW, halfH)
        path.lineTo(halfW * 0.8f, 0f)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, outlinePaint)
    }

    /** Small inversion bubble used by NAND/NOR/XNOR/NOT. */
    private fun drawBubble(canvas: Canvas, halfW: Float) {
        val r = halfW * 0.12f
        canvas.drawCircle(halfW * 0.95f, 0f, r, fillPaint)
        canvas.drawCircle(halfW * 0.95f, 0f, r, outlinePaint)
    }

    private fun drawSwitch(canvas: Canvas, halfW: Float, halfH: Float, on: Boolean, theme: CircuitTheme) {
        reusableRect.set(-halfW, -halfH, halfW, halfH)
        canvas.drawRoundRect(reusableRect, 10f, 10f, fillPaint)
        canvas.drawRoundRect(reusableRect, 10f, 10f, outlinePaint)
        accentPaint.style = Paint.Style.FILL
        accentPaint.color = if (on) theme.wireHigh else theme.wireLow
        canvas.drawCircle(if (on) halfW * 0.4f else -halfW * 0.4f, 0f, halfH * 0.5f, accentPaint)
    }

    private fun drawRail(canvas: Canvas, halfW: Float, halfH: Float, theme: CircuitTheme, isPower: Boolean) {
        accentPaint.style = Paint.Style.STROKE
        accentPaint.strokeWidth = 4f
        accentPaint.color = theme.componentOutline
        if (isPower) {
            canvas.drawLine(0f, -halfH, 0f, 0f, accentPaint)
            canvas.drawLine(-halfW * 0.6f, 0f, halfW * 0.6f, 0f, accentPaint)
        } else {
            canvas.drawLine(0f, -halfH, 0f, 0f, accentPaint)
            canvas.drawLine(-halfW * 0.7f, 0f, halfW * 0.7f, 0f, accentPaint)
            canvas.drawLine(-halfW * 0.45f, halfH * 0.3f, halfW * 0.45f, halfH * 0.3f, accentPaint)
            canvas.drawLine(-halfW * 0.2f, halfH * 0.6f, halfW * 0.2f, halfH * 0.6f, accentPaint)
        }
        canvas.drawText(if (isPower) "1" else "GND", 0f, halfH + 26f, textPaint)
    }

    private fun drawClock(canvas: Canvas, halfW: Float, halfH: Float, high: Boolean, theme: CircuitTheme) {
        reusableRect.set(-halfW, -halfH, halfW, halfH)
        canvas.drawRoundRect(reusableRect, 10f, 10f, fillPaint)
        canvas.drawRoundRect(reusableRect, 10f, 10f, outlinePaint)

        val w = halfW * 0.6f
        val h = halfH * 0.4f
        val wave = Path()
        wave.moveTo(-w, h)
        wave.lineTo(-w / 2, h)
        wave.lineTo(-w / 2, -h)
        wave.lineTo(w / 2, -h)
        wave.lineTo(w / 2, h)
        wave.lineTo(w, h)

        accentPaint.style = Paint.Style.STROKE
        accentPaint.strokeWidth = 3f
        accentPaint.color = if (high) theme.wireHigh else theme.wireLow
        canvas.drawPath(wave, accentPaint)
    }

    private fun drawLed(canvas: Canvas, halfW: Float, halfH: Float, on: Boolean, theme: CircuitTheme, animationPhase: Float) {
        val radius = minOf(halfW, halfH) * 0.85f
        if (on) {
            // Subtle pulsing glow rather than a static radius — small
            // amplitude so it reads as "alive" without being distracting.
            val pulse = 1f + 0.12f * sin(animationPhase * 2f * Math.PI).toFloat()
            val glowRadius = radius * 2.6f * pulse
            glowPaint.shader = RadialGradient(
                0f, 0f, glowRadius,
                theme.ledOnColor, 0x00000000, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, glowRadius, glowPaint)
        }
        fillPaint.color = if (on) theme.ledOnColor else theme.ledOffColor
        canvas.drawCircle(0f, 0f, radius, fillPaint)
        canvas.drawCircle(0f, 0f, radius, outlinePaint)
    }

    private fun drawPins(canvas: Canvas, component: ComponentInstance, halfW: Float, theme: CircuitTheme, outputHigh: Boolean) {
        pinStrokePaint.color = theme.componentOutline
        pinDotPaint.color = theme.componentOutline
        for (i in 0 until component.type.inputCount) {
            val localY = pinLocalY(i, component.type.inputCount)
            canvas.drawLine(-halfW, localY, -halfW - 14f, localY, pinStrokePaint)
            canvas.drawCircle(-halfW - 14f, localY, 5f, pinDotPaint)
        }
        val wireColor = if (outputHigh) theme.wireHigh else theme.wireLow
        pinStrokePaint.color = wireColor
        pinDotPaint.color = wireColor
        for (i in 0 until component.type.outputCount) {
            val localY = pinLocalY(i, component.type.outputCount)
            canvas.drawLine(halfW, localY, halfW + 14f, localY, pinStrokePaint)
            canvas.drawCircle(halfW + 14f, localY, 5f, pinDotPaint)
        }
    }

    private fun pinLocalY(index: Int, count: Int): Float {
        val spacing = ComponentInstance.PIN_SPACING
        val totalSpan = (count - 1).coerceAtLeast(0) * spacing
        return -totalSpan / 2f + index * spacing
    }
}
