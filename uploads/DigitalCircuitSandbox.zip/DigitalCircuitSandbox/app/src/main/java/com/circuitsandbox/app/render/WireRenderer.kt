package com.circuitsandbox.app.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.WireInstance

/**
 * Renders wires as orthogonal (Manhattan-style) routed paths, and animates
 * a small pulse travelling along powered wires so the user can visually
 * trace signal flow through the circuit.
 */
object WireRenderer {

    private val wirePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
    }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pathMeasure = PathMeasure()
    private val measurePos = FloatArray(2)

    fun draw(
        canvas: Canvas,
        wire: WireInstance,
        from: ComponentInstance,
        to: ComponentInstance,
        theme: CircuitTheme,
        isHigh: Boolean,
        isFloating: Boolean,
        hasError: Boolean,
        isSelected: Boolean,
        animationPhase: Float
    ) {
        val (startX, startY) = from.outputPinWorldPosition(wire.from.pinIndex)
        val (endX, endY) = to.inputPinWorldPosition(wire.to.pinIndex)

        val path = buildOrthogonalPath(startX, startY, endX, endY)

        wirePaint.color = when {
            isSelected -> theme.selectionHighlight
            hasError -> theme.wireError
            isFloating -> theme.wireFloating
            isHigh -> theme.wireHigh
            else -> theme.wireLow
        }
        canvas.drawPath(path, wirePaint)

        if (isHigh) {
            pathMeasure.setPath(path, false)
            val length = pathMeasure.length
            if (length > 0f) {
                val distance = (animationPhase * length) % length
                pathMeasure.getPosTan(distance, measurePos, null)
                pulsePaint.color = theme.wireHigh
                canvas.drawCircle(measurePos[0], measurePos[1], 5f, pulsePaint)
            }
        }
    }

    private fun buildOrthogonalPath(x1: Float, y1: Float, x2: Float, y2: Float): Path {
        val path = Path()
        path.moveTo(x1, y1)
        val midX = (x1 + x2) / 2f
        path.lineTo(midX, y1)
        path.lineTo(midX, y2)
        path.lineTo(x2, y2)
        return path
    }
}
