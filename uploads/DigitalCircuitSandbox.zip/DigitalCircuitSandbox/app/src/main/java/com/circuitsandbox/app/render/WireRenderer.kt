package com.circuitsandbox.app.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.WireInstance

/**
 * Renders wires as orthogonal (Manhattan-style) routed paths, and animates
 * a small pulse travelling along powered wires so the user can visually
 * trace signal flow through the circuit.
 *
 * [routeVertices] is also used by [com.circuitsandbox.app.ui.CircuitCanvasView]
 * for wire hit-testing (tap-to-select, drag-to-erase), so the touchable
 * area always matches exactly what's drawn.
 */
object WireRenderer {

    /** Minimum horizontal run before the routed path turns, so a wire
     * never looks like it cuts straight through a gate body when the
     * target pin sits almost directly behind the source pin. */
    private const val MIN_STUB = 18f

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val wirePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pathMeasure = PathMeasure()
    private val measurePos = FloatArray(2)
    private val reusablePath = Path()

    /** The vertices of the orthogonal route from (x1,y1) to (x2,y2), in
     * order. Always 4 points: start, two bend points sharing one x, end. */
    fun routeVertices(x1: Float, y1: Float, x2: Float, y2: Float): List<Pair<Float, Float>> {
        val dx = x2 - x1
        val midX = if (dx > MIN_STUB * 2f) x1 + dx / 2f else x1 + MIN_STUB
        return listOf(x1 to y1, midX to y1, midX to y2, x2 to y2)
    }

    fun draw(
        canvas: Canvas,
        wire: WireInstance,
        from: ComponentInstance,
        to: ComponentInstance,
        theme: CircuitTheme,
        isHigh: Boolean,
        isFloating: Boolean,
        hasError: Boolean,
        isSelected: Boolean,
        animationPhase: Float
    ) {
        val (startX, startY) = from.outputPinWorldPosition(wire.from.pinIndex)
        val (endX, endY) = to.inputPinWorldPosition(wire.to.pinIndex)
        val vertices = routeVertices(startX, startY, endX, endY)

        reusablePath.rewind()
        reusablePath.moveTo(vertices[0].first, vertices[0].second)
        for (i in 1 until vertices.size) reusablePath.lineTo(vertices[i].first, vertices[i].second)

        val color = when {
            isSelected -> theme.selectionHighlight
            hasError -> theme.wireError
            isFloating -> theme.wireFloating
            isHigh -> theme.wireHigh
            else -> theme.wireLow
        }

        // Cheap glow for powered wires: a wide, low-alpha stroke drawn
        // under the crisp line. A real BlurMaskFilter would be cleaner,
        // but it silently no-ops on a hardware-accelerated Canvas (which
        // this app uses throughout for performance), so this layered-
        // stroke approximation is the one that actually renders.
        if (isHigh && !hasError) {
            glowPaint.color = theme.wireHigh
            glowPaint.alpha = 70
            glowPaint.strokeWidth = 12f
            canvas.drawPath(reusablePath, glowPaint)
        }

        wirePaint.color = color
        wirePaint.strokeWidth = if (isSelected) 5.5f else 4f
        canvas.drawPath(reusablePath, wirePaint)

        if (isHigh) {
            pathMeasure.setPath(reusablePath, false)
            val length = pathMeasure.length
            if (length > 0f) {
                val distance = (animationPhase * length) % length
                pathMeasure.getPosTan(distance, measurePos, null)
                pulsePaint.color = theme.wireHigh
                canvas.drawCircle(measurePos[0], measurePos[1], 5f, pulsePaint)
            }
        }
    }
}
