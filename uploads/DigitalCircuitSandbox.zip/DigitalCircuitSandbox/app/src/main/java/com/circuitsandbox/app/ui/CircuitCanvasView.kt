package com.circuitsandbox.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.WireEndpoint
import com.circuitsandbox.app.model.WireInstance
import com.circuitsandbox.app.render.CircuitTheme
import com.circuitsandbox.app.render.GateRenderer
import com.circuitsandbox.app.render.GridRenderer
import com.circuitsandbox.app.render.WireRenderer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sqrt

/**
 * The infinite pan/zoom canvas — the heart of the app.
 *
 * All drawing is procedural (Path/Canvas primitives only, never bitmaps),
 * so components stay crisp at any zoom level. Per-frame work only ever
 * touches components inside the current viewport (simple AABB culling),
 * which keeps frame time roughly constant regardless of how large the
 * overall circuit is.
 *
 * This view never mutates [circuit] for anything the user should be able
 * to undo — it only ever reports intent through [listener], and the host
 * decides whether/how to apply it (see [CircuitInteractionListener]).
 */
class CircuitCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var circuit: CircuitModel = CircuitModel()
    var theme: CircuitTheme = CircuitTheme.DARK
    var listener: CircuitInteractionListener? = null

    /** Live HIGH/LOW state per component, refreshed once per frame by the
     * host from a single batched native read. Never mutated mid-draw. */
    var outputStates: Map<Int, Boolean> = emptyMap()
    var floatingComponentIds: Set<Int> = emptySet()
    var oscillatingComponentIds: Set<Int> = emptySet()
    var shortCircuitWireIds: Set<Int> = emptySet()
    var simulationRunning: Boolean = false

    var pendingPlacementType: ComponentType? = null
        set(value) {
            field = value
            selection.clear()
            invalidate()
        }

    private var offsetX = 0f
    private var offsetY = 0f
    private var scale = 1f
    private val minScale = 0.15f
    private val maxScale = 4f

    private val selection = mutableSetOf<Int>()
    private var dragCandidateId: Int? = null
    private var isDraggingComponent = false
    private var dragStartWorldX = 0f
    private var dragStartWorldY = 0f
    private var dragOriginalX = 0f
    private var dragOriginalY = 0f

    private var wireDragStart: Pair<Int, Int>? = null // (componentId, outputPinIndex)
    private var wireDragCurrentWorld: Pair<Float, Float>? = null

    private var selectionBoxStart: Pair<Float, Float>? = null
    private var selectionBoxCurrent: Pair<Float, Float>? = null

    private var animationPhase = 0f
    private val pinHitRadius = 14f

    private val wireDragPreviewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    }
    private val selectionBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val previousScale = scale
            scale = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
            // Keep the pinch focal point stationary on screen while zooming.
            val factor = scale / previousScale
            offsetX = detector.focusX - (detector.focusX - offsetX) * factor
            offsetY = detector.focusY - (detector.focusY - offsetY) * factor
            invalidate()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (dragCandidateId == null && wireDragStart == null && selectionBoxStart == null) {
                offsetX -= dx
                offsetY -= dy
                invalidate()
                return true
            }
            return false
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            handleTap(e.x, e.y)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            handleLongPress(e.x, e.y)
        }
    })

    init {
        isClickable = true
        isFocusable = true
    }

    fun screenToWorld(screenX: Float, screenY: Float): Pair<Float, Float> =
        ((screenX - offsetX) / scale) to ((screenY - offsetY) / scale)

    fun worldToScreen(worldX: Float, worldY: Float): Pair<Float, Float> =
        (worldX * scale + offsetX) to (worldY * scale + offsetY)

    fun centerOn(worldX: Float, worldY: Float) {
        offsetX = width / 2f - worldX * scale
        offsetY = height / 2f - worldY * scale
        invalidate()
    }

    /** Advances the wire-flow pulse animation by one frame. The host drives
     * this on a Choreographer/timer tick only while it's worth animating
     * (simulation running or a gesture in progress), to avoid burning
     * battery redrawing a static circuit. */
    fun advanceAnimation() {
        animationPhase = (animationPhase + 0.01f) % 1f
        invalidate()
    }

    fun deleteSelection() {
        for (id in selection.toList()) {
            circuit.componentById(id)?.let { listener?.onComponentRemoved(it) }
        }
        selection.clear()
        listener?.onSelectionChanged(selection)
        invalidate()
    }

    fun rotateSelection() {
        for (id in selection) {
            circuit.componentById(id)?.let { it.rotationDegrees = (it.rotationDegrees + 90) % 360 }
        }
        invalidate()
    }

    fun mirrorSelection() {
        for (id in selection) {
            circuit.componentById(id)?.let { it.mirrored = !it.mirrored }
        }
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) {
            gestureDetector.onTouchEvent(event)
        }

        val (worldX, worldY) = screenToWorld(event.x, event.y)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> handleActionDown(worldX, worldY)
            MotionEvent.ACTION_MOVE -> handleActionMove(worldX, worldY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handleActionUp(worldX, worldY)
        }
        return true
    }

    private fun handleActionDown(worldX: Float, worldY: Float) {
        pendingPlacementType?.let { type ->
            placeComponent(type, snap(worldX), snap(worldY))
            pendingPlacementType = null
            return
        }
        val pinHit = findOutputPinNear(worldX, worldY)
        if (pinHit != null) {
            wireDragStart = pinHit
            return
        }
        val component = circuit.componentAt(worldX, worldY)
        if (component != null) {
            if (!selection.contains(component.id)) {
                selection.clear()
                selection.add(component.id)
                listener?.onSelectionChanged(selection)
            }
            dragCandidateId = component.id
            dragStartWorldX = worldX
            dragStartWorldY = worldY
            dragOriginalX = component.x
            dragOriginalY = component.y
        } else {
            selectionBoxStart = worldX to worldY
            selectionBoxCurrent = worldX to worldY
        }
    }

    private fun handleActionMove(worldX: Float, worldY: Float) {
        if (wireDragStart != null) {
            wireDragCurrentWorld = worldX to worldY
            invalidate()
            return
        }
        val id = dragCandidateId
        if (id != null) {
            val component = circuit.componentById(id)
            if (component != null) {
                if (!isDraggingComponent) {
                    val movedEnough = abs(worldX - dragStartWorldX) > 4f || abs(worldY - dragStartWorldY) > 4f
                    if (movedEnough) isDraggingComponent = true
                }
                if (isDraggingComponent) {
                    component.x = snap(dragOriginalX + (worldX - dragStartWorldX))
                    component.y = snap(dragOriginalY + (worldY - dragStartWorldY))
                    invalidate()
                }
            }
            return
        }
        if (selectionBoxStart != null) {
            selectionBoxCurrent = worldX to worldY
            invalidate()
        }
    }

    private fun handleActionUp(worldX: Float, worldY: Float) {
        wireDragStart?.let { (fromId, fromPin) ->
            val targetPin = findInputPinNear(worldX, worldY)
            if (targetPin != null) {
                val (toId, toPin) = targetPin
                val wire = WireInstance(
                    circuit.nextWireId(),
                    WireEndpoint(fromId, fromPin, isInput = false),
                    WireEndpoint(toId, toPin, isInput = true)
                )
                listener?.onWireAdded(wire)
            }
            wireDragStart = null
            wireDragCurrentWorld = null
            invalidate()
        }

        dragCandidateId?.let { id ->
            val component = circuit.componentById(id)
            if (isDraggingComponent && component != null) {
                listener?.onComponentMoved(id, dragOriginalX, dragOriginalY, component.x, component.y)
            }
        }
        dragCandidateId = null
        isDraggingComponent = false

        selectionBoxStart?.let { (sx, sy) ->
            val (cx, cy) = selectionBoxCurrent ?: (sx to sy)
            val left = min(sx, cx); val right = max(sx, cx)
            val top = min(sy, cy); val bottom = max(sy, cy)
            if (abs(right - left) > 6f || abs(bottom - top) > 6f) {
                selection.clear()
                circuit.allComponents.filter { it.x in left..right && it.y in top..bottom }
                    .forEach { selection.add(it.id) }
                listener?.onSelectionChanged(selection)
            }
            selectionBoxStart = null
            selectionBoxCurrent = null
            invalidate()
        }
    }

    private fun handleTap(screenX: Float, screenY: Float) {
        val (worldX, worldY) = screenToWorld(screenX, screenY)
        val component = circuit.componentAt(worldX, worldY) ?: return
        if (simulationRunning &&
            (component.type == ComponentType.INPUT_SWITCH || component.type == ComponentType.PUSH_BUTTON)
        ) {
            listener?.onSwitchToggled(component.id)
            invalidate()
        }
    }

    private fun handleLongPress(screenX: Float, screenY: Float) {
        val (worldX, worldY) = screenToWorld(screenX, screenY)
        val component = circuit.componentAt(worldX, worldY) ?: return
        selection.clear()
        selection.add(component.id)
        listener?.onSelectionChanged(selection)
        invalidate()
    }

    private fun placeComponent(type: ComponentType, x: Float, y: Float) {
        val component = ComponentInstance(circuit.nextComponentId(), type, x, y)
        listener?.onComponentAdded(component)
        selection.clear()
        selection.add(component.id)
        listener?.onSelectionChanged(selection)
        invalidate()
    }

    private fun snap(value: Float): Float {
        val gridSize = 20f
        return round(value / gridSize) * gridSize
    }

    private fun findOutputPinNear(worldX: Float, worldY: Float): Pair<Int, Int>? {
        for (component in circuit.allComponents) {
            for (i in 0 until component.type.outputCount) {
                val (px, py) = component.outputPinWorldPosition(i)
                if (distance(px, py, worldX, worldY) <= pinHitRadius) return component.id to i
            }
        }
        return null
    }

    private fun findInputPinNear(worldX: Float, worldY: Float): Pair<Int, Int>? {
        for (component in circuit.allComponents) {
            for (i in 0 until component.type.inputCount) {
                val (px, py) = component.inputPinWorldPosition(i)
                if (distance(px, py, worldX, worldY) <= pinHitRadius) return component.id to i
            }
        }
        return null
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt(dx * dx + dy * dy)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(theme.canvasBackground)

        val topLeft = screenToWorld(0f, 0f)
        val bottomRight = screenToWorld(width.toFloat(), height.toFloat())

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)

        GridRenderer.draw(canvas, theme, scale, topLeft.first, topLeft.second, bottomRight.first, bottomRight.second)

        val margin = 200f
        val visibleComponents = circuit.allComponents.filter {
            it.x in (topLeft.first - margin)..(bottomRight.first + margin) &&
                it.y in (topLeft.second - margin)..(bottomRight.second + margin)
        }
        val visibleIds = visibleComponents.map { it.id }.toSet()

        for (wire in circuit.allWires) {
            val from = circuit.componentById(wire.from.componentId) ?: continue
            val to = circuit.componentById(wire.to.componentId) ?: continue
            if (wire.from.componentId !in visibleIds && wire.to.componentId !in visibleIds) continue
            val isHigh = outputStates[wire.from.componentId] ?: false
            WireRenderer.draw(
                canvas, wire, from, to, theme,
                isHigh = isHigh,
                isFloating = false,
                hasError = wire.id in shortCircuitWireIds,
                isSelected = false,
                animationPhase = animationPhase
            )
        }

        wireDragStart?.let { (fromId, fromPin) ->
            val from = circuit.componentById(fromId)
            val target = wireDragCurrentWorld
            if (from != null && target != null) {
                val (sx, sy) = from.outputPinWorldPosition(fromPin)
                wireDragPreviewPaint.color = theme.selectionHighlight
                canvas.drawLine(sx, sy, target.first, target.second, wireDragPreviewPaint)
            }
        }

        for (component in visibleComponents) {
            val outputHigh = outputStates[component.id] ?: false
            GateRenderer.draw(
                canvas, component, theme, outputHigh,
                isSelected = component.id in selection,
                hasError = component.id in floatingComponentIds || component.id in oscillatingComponentIds
            )
        }

        canvas.restore()

        selectionBoxStart?.let { (sx, sy) ->
            val (cx, cy) = selectionBoxCurrent ?: (sx to sy)
            val (screenSX, screenSY) = worldToScreen(sx, sy)
            val (screenCX, screenCY) = worldToScreen(cx, cy)
            selectionBoxPaint.color = theme.selectionHighlight
            canvas.drawRect(
                min(screenSX, screenCX), min(screenSY, screenCY),
                max(screenSX, screenCX), max(screenSY, screenCY),
                selectionBoxPaint
            )
        }
    }
}
