package com.circuitsandbox.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Region
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.WireEndpoint
import com.circuitsandbox.app.model.WireInstance
import com.circuitsandbox.app.render.CircuitTheme
import com.circuitsandbox.app.render.GateRenderer
import com.circuitsandbox.app.render.GridRenderer
import com.circuitsandbox.app.render.WireRenderer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sqrt

/** How a drag starting on empty canvas selects multiple objects. */
enum class SelectionMode { BOX, LASSO }

/**
 * The infinite pan/zoom canvas — the heart of the app.
 *
 * All drawing is procedural (Path/Canvas primitives only, never bitmaps),
 * so components stay crisp at any zoom level. Per-frame work only ever
 * touches components inside the current viewport (simple AABB culling),
 * which keeps frame time roughly constant regardless of how large the
 * overall circuit is.
 *
 * This view never mutates [circuit] for anything the user should be able
 * to undo on its own — single add/move/remove actions and reconnects are
 * still reported individually through [listener] exactly as before; bulk
 * actions (paste, duplicate, multi-delete) go through dedicated bulk
 * callbacks so the host can collapse them into one undo step.
 */
class CircuitCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var circuit: CircuitModel = CircuitModel()
    var theme: CircuitTheme = CircuitTheme.DARK
    var listener: CircuitInteractionListener? = null

    /** Live HIGH/LOW state per component, refreshed once per frame by the
     * host from a single batched native read. Never mutated mid-draw. */
    var outputStates: Map<Int, Boolean> = emptyMap()
    var floatingComponentIds: Set<Int> = emptySet()
    var oscillatingComponentIds: Set<Int> = emptySet()
    var shortCircuitWireIds: Set<Int> = emptySet()
    var simulationRunning: Boolean = false

    var snapToGridEnabled: Boolean = true
    var selectionMode: SelectionMode = SelectionMode.BOX

    var pendingPlacementType: ComponentType? = null
        set(value) {
            field = value
            selection.clear()
            selectedWireIds.clear()
            invalidate()
        }

    private val density = context.resources.displayMetrics.density

    private var offsetX = 0f
    private var offsetY = 0f
    private var scale = 1f
    private val minScale = 0.15f
    private val maxScale = 4f

    private val selection = mutableSetOf<Int>()
    private val selectedWireIds = mutableSetOf<Int>()

    private var dragCandidateId: Int? = null
    private var isDraggingComponent = false
    private var dragStartWorldX = 0f
    private var dragStartWorldY = 0f
    private var dragOriginalX = 0f
    private var dragOriginalY = 0f
    private var groupDragOriginals: Map<Int, Pair<Float, Float>> = emptyMap()

    private var wireDragStart: Pair<Int, Int>? = null // (componentId, outputPinIndex)
    private var wireDragCurrentWorld: Pair<Float, Float>? = null
    private var reconnectingWireId: Int? = null

    private var selectionBoxStart: Pair<Float, Float>? = null
    private var selectionBoxCurrent: Pair<Float, Float>? = null
    private var lassoPoints: MutableList<Pair<Float, Float>>? = null

    private var eraseModeActive = false

    private var clipboardComponents: List<ComponentInstance> = emptyList()
    private var clipboardWires: List<WireInstance> = emptyList()

    private var animationPhase = 0f

    // --- Touch-target sizing -------------------------------------------------
    // Pin/wire hit radii are expressed in dp and converted through both
    // density and the current zoom level, so the *physical* touch target
    // stays a constant, comfortable size on screen no matter how far the
    // user has zoomed in or out — fixing the original world-space-constant
    // radius, which made pins effectively harder to hit when zoomed out.
    private fun dpToWorld(dp: Float): Float = (dp * density) / scale
    private fun pinSnapRadius(): Float = dpToWorld(24f)
    private fun pinHighlightRadius(): Float = dpToWorld(34f)
    private fun wireHitTolerance(): Float = dpToWorld(16f)

    private val wireDragPreviewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    private val pinHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val selectionOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val lassoFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val previousScale = scale
            scale = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
            val factor = scale / previousScale
            offsetX = detector.focusX - (detector.focusX - offsetX) * factor
            offsetY = detector.focusY - (detector.focusY - offsetY) * factor
            invalidate()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            val noOtherGestureActive = dragCandidateId == null && wireDragStart == null &&
                selectionBoxStart == null && lassoPoints == null && !eraseModeActive
            if (noOtherGestureActive) {
                offsetX -= dx
                offsetY -= dy
                invalidate()
                return true
            }
            return false
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            handleTap(e.x, e.y)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            handleLongPress(e.x, e.y)
        }
    })

    init {
        isClickable = true
        isFocusable = true
    }

    // --- Public API used by MainActivity --------------------------------

    fun screenToWorld(screenX: Float, screenY: Float): Pair<Float, Float> =
        ((screenX - offsetX) / scale) to ((screenY - offsetY) / scale)

    fun worldToScreen(worldX: Float, worldY: Float): Pair<Float, Float> =
        (worldX * scale + offsetX) to (worldY * scale + offsetY)

    fun centerOn(worldX: Float, worldY: Float) {
        offsetX = width / 2f - worldX * scale
        offsetY = height / 2f - worldY * scale
        invalidate()
    }

    /** Frames every placed component on screen with padding. A no-op
     * (just re-centers on the origin) on an empty circuit. */
    fun fitToScreen() {
        val components = circuit.allComponents
        if (components.isEmpty() || width == 0 || height == 0) {
            centerOn(0f, 0f)
            return
        }
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (c in components) {
            minX = min(minX, c.x - c.width); maxX = max(maxX, c.x + c.width)
            minY = min(minY, c.y - c.height); maxY = max(maxY, c.y + c.height)
        }
        val pad = 100f
        minX -= pad; minY -= pad; maxX += pad; maxY += pad
        val contentW = (maxX - minX).coerceAtLeast(1f)
        val contentH = (maxY - minY).coerceAtLeast(1f)
        scale = min(width / contentW, height / contentH).coerceIn(minScale, maxScale)
        offsetX = width / 2f - (minX + maxX) / 2f * scale
        offsetY = height / 2f - (minY + maxY) / 2f * scale
        invalidate()
    }

    /** Advances the wire-flow / LED-pulse animation by one frame. The host
     * drives this on a tick only while it's worth animating (simulation
     * running), to avoid burning battery redrawing a static circuit. */
    fun advanceAnimation() {
        animationPhase = (animationPhase + 0.01f) % 1f
        invalidate()
    }

    fun hasSelection(): Boolean = selection.isNotEmpty() || selectedWireIds.isNotEmpty()
    fun hasClipboard(): Boolean = clipboardComponents.isNotEmpty()

    fun deleteSelection() {
        if (!hasSelection()) return
        listener?.onBulkDelete(selection.toSet(), selectedWireIds.toSet())
        selection.clear(); selectedWireIds.clear()
        reportSelectionChanged()
        invalidate()
    }

    fun deleteAllWires() {
        val ids = circuit.allWires.map { it.id }.toSet()
        if (ids.isEmpty()) return
        listener?.onBulkDelete(emptySet(), ids)
        selectedWireIds.clear()
        invalidate()
    }

    fun deleteAllComponents() {
        val ids = circuit.allComponents.map { it.id }.toSet()
        if (ids.isEmpty()) return
        listener?.onBulkDelete(ids, emptySet())
        selection.clear()
        invalidate()
    }

    /** Defensive integrity cleanup: every [WireInstance] should already
     * reference two real components — [CircuitModel] cascades wire
     * removal whenever a component is deleted — so under normal use this
     * is a no-op. It exists to recover cleanly from a hand-edited or
     * otherwise corrupted save file that references a missing component. */
    fun deleteDisconnectedWires() {
        val orphaned = circuit.allWires.filter {
            circuit.componentById(it.from.componentId) == null || circuit.componentById(it.to.componentId) == null
        }.map { it.id }.toSet()
        if (orphaned.isNotEmpty()) listener?.onBulkDelete(emptySet(), orphaned)
        invalidate()
    }

    fun clearCanvas() {
        val componentIds = circuit.allComponents.map { it.id }.toSet()
        val wireIds = circuit.allWires.map { it.id }.toSet()
        if (componentIds.isEmpty() && wireIds.isEmpty()) return
        listener?.onBulkDelete(componentIds, wireIds)
        selection.clear(); selectedWireIds.clear()
        invalidate()
    }

    fun rotateSelection() {
        if (selection.isEmpty()) return
        listener?.onRotateRequested(selection.toSet())
        invalidate()
    }

    fun mirrorSelection() {
        if (selection.isEmpty()) return
        listener?.onMirrorRequested(selection.toSet())
        invalidate()
    }

    fun copySelection() {
        if (selection.isEmpty()) return
        clipboardComponents = selection.mapNotNull { circuit.componentById(it) }.map { it.copy() }
        clipboardWires = circuit.allWires.filter {
            it.from.componentId in selection && it.to.componentId in selection
        }
    }

    fun duplicateSelection() {
        if (selection.isEmpty()) return
        copySelection()
        pasteClipboard()
    }

    /** Pastes the current clipboard offset from its original position, so
     * the copy is never placed exactly on top of the original. */
    fun pasteClipboard() {
        if (clipboardComponents.isEmpty()) return
        val offset = 40f
        val idRemap = HashMap<Int, Int>()
        val newComponents = clipboardComponents.map { original ->
            val newId = circuit.nextComponentId()
            idRemap[original.id] = newId
            original.copy(id = newId, x = original.x + offset, y = original.y + offset)
        }
        val newWires = clipboardWires.mapNotNull { original ->
            val newFrom = idRemap[original.from.componentId] ?: return@mapNotNull null
            val newTo = idRemap[original.to.componentId] ?: return@mapNotNull null
            WireInstance(
                circuit.nextWireId(),
                original.from.copy(componentId = newFrom),
                original.to.copy(componentId = newTo)
            )
        }
        listener?.onBulkAdd(newComponents, newWires)
        selection.clear(); selectedWireIds.clear()
        newComponents.forEach { selection.add(it.id) }
        reportSelectionChanged()
        invalidate()
    }

    // --- Touch handling ---------------------------------------------------

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) {
            gestureDetector.onTouchEvent(event)
        }

        val (worldX, worldY) = screenToWorld(event.x, event.y)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> handleActionDown(worldX, worldY)
            MotionEvent.ACTION_MOVE -> handleActionMove(worldX, worldY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handleActionUp(worldX, worldY)
        }
        return true
    }

    private fun handleActionDown(worldX: Float, worldY: Float) {
        pendingPlacementType?.let { type ->
            placeComponent(type, snap(worldX), snap(worldY))
            pendingPlacementType = null
            return
        }

        // 1) Start a brand-new wire from an output pin.
        findOutputPinNear(worldX, worldY)?.let { pin ->
            wireDragStart = pin
            reconnectingWireId = null
            return
        }

        // 2) Grab an existing wire's input endpoint to reconnect/detach it.
        findWireInputEndpointNear(worldX, worldY)?.let { (wire, sourceComponentId) ->
            wireDragStart = sourceComponentId to wire.from.pinIndex
            wireDragCurrentWorld = worldX to worldY
            reconnectingWireId = wire.id
            selection.clear(); selectedWireIds.clear()
            reportSelectionChanged()
            return
        }

        // 3) Component tap/drag. Tapping a member of an existing multi-
        // selection keeps the whole selection (so it can be moved as a
        // group); tapping anything else collapses to a single selection.
        circuit.componentAt(worldX, worldY)?.let { component ->
            val keepExistingMultiSelection = selection.size > 1 && selection.contains(component.id) && selectedWireIds.isEmpty()
            if (!keepExistingMultiSelection) {
                selection.clear(); selectedWireIds.clear()
                selection.add(component.id)
                reportSelectionChanged()
            }
            dragCandidateId = component.id
            dragStartWorldX = worldX; dragStartWorldY = worldY
            dragOriginalX = component.x; dragOriginalY = component.y
            groupDragOriginals = selection.mapNotNull { id ->
                circuit.componentById(id)?.let { id to (it.x to it.y) }
            }.toMap()
            return
        }

        // 4) Wire-body tap (select a wire without dragging it).
        findWireNear(worldX, worldY)?.let { wire ->
            selection.clear(); selectedWireIds.clear()
            selectedWireIds.add(wire.id)
            reportSelectionChanged()
            invalidate()
            return
        }

        // 5) Nothing hit — begin a multi-select gesture.
        if (selectionMode == SelectionMode.BOX) {
            selectionBoxStart = worldX to worldY
            selectionBoxCurrent = worldX to worldY
        } else {
            lassoPoints = mutableListOf(worldX to worldY)
        }
    }

    private fun handleActionMove(worldX: Float, worldY: Float) {
        if (eraseModeActive) {
            eraseAt(worldX, worldY)
            invalidate()
            return
        }

        if (wireDragStart != null) {
            wireDragCurrentWorld = worldX to worldY
            invalidate()
            return
        }

        val id = dragCandidateId
        if (id != null) {
            val component = circuit.componentById(id)
            if (component != null) {
                if (!isDraggingComponent) {
                    val movedEnough = abs(worldX - dragStartWorldX) > 4f || abs(worldY - dragStartWorldY) > 4f
                    if (movedEnough) isDraggingComponent = true
                }
                if (isDraggingComponent) {
                    val dx = worldX - dragStartWorldX
                    val dy = worldY - dragStartWorldY
                    if (selection.size > 1) {
                        for ((compId, orig) in groupDragOriginals) {
                            circuit.componentById(compId)?.let {
                                it.x = snap(orig.first + dx)
                                it.y = snap(orig.second + dy)
                            }
                        }
                    } else {
                        component.x = snap(dragOriginalX + dx)
                        component.y = snap(dragOriginalY + dy)
                    }
                    invalidate()
                }
            }
            return
        }

        if (selectionBoxStart != null) {
            selectionBoxCurrent = worldX to worldY
            invalidate()
            return
        }

        lassoPoints?.let {
            it.add(worldX to worldY)
            invalidate()
        }
    }

    private fun handleActionUp(worldX: Float, worldY: Float) {
        if (eraseModeActive) {
            eraseModeActive = false
            return
        }

        wireDragStart?.let { (fromId, fromPin) ->
            val targetPin = findInputPinNear(worldX, worldY)
            val oldWireId = reconnectingWireId
            if (targetPin != null) {
                val (toId, toPin) = targetPin
                val newWire = WireInstance(
                    circuit.nextWireId(),
                    WireEndpoint(fromId, fromPin, isInput = false),
                    WireEndpoint(toId, toPin, isInput = true)
                )
                val oldWire = oldWireId?.let { circuit.wireById(it) }
                if (oldWire != null) {
                    listener?.onWireReconnected(oldWire, newWire)
                } else {
                    listener?.onWireAdded(newWire)
                }
            } else if (oldWireId != null) {
                // Dropped on empty space while reconnecting — that
                // disconnects it, matching the "drag a wire away to
                // remove it" gesture from desktop circuit editors.
                circuit.wireById(oldWireId)?.let { listener?.onWireRemoved(it) }
            }
            wireDragStart = null
            wireDragCurrentWorld = null
            reconnectingWireId = null
            invalidate()
        }

        dragCandidateId?.let { id ->
            if (isDraggingComponent) {
                if (selection.size > 1) {
                    // One undo entry per moved component — slightly more
                    // granular than a single combined step, but it keeps
                    // the listener interface unchanged and undo still
                    // fully reverses the group move if pressed enough times.
                    for ((compId, orig) in groupDragOriginals) {
                        val comp = circuit.componentById(compId)
                        if (comp != null) {
                            listener?.onComponentMoved(compId, orig.first, orig.second, comp.x, comp.y)
                        }
                    }
                } else {
                    val component = circuit.componentById(id)
                    if (component != null) {
                        listener?.onComponentMoved(id, dragOriginalX, dragOriginalY, component.x, component.y)
                    }
                }
            }
        }
        dragCandidateId = null
        isDraggingComponent = false

        selectionBoxStart?.let { (sx, sy) ->
            val (cx, cy) = selectionBoxCurrent ?: (sx to sy)
            val left = min(sx, cx); val right = max(sx, cx)
            val top = min(sy, cy); val bottom = max(sy, cy)
            if (abs(right - left) > 6f || abs(bottom - top) > 6f) {
                selection.clear()
                circuit.allComponents.filter { it.x in left..right && it.y in top..bottom }
                    .forEach { selection.add(it.id) }
                selectWiresBetweenSelectedComponents()
                reportSelectionChanged()
            }
            selectionBoxStart = null
            selectionBoxCurrent = null
            invalidate()
        }

        lassoPoints?.let { finishLassoSelection(it) }
    }

    private fun handleTap(screenX: Float, screenY: Float) {
        val (worldX, worldY) = screenToWorld(screenX, screenY)
        val component = circuit.componentAt(worldX, worldY) ?: return
        if (simulationRunning &&
            (component.type == ComponentType.INPUT_SWITCH || component.type == ComponentType.PUSH_BUTTON)
        ) {
            listener?.onSwitchToggled(component.id)
            invalidate()
        }
    }

    private fun handleLongPress(screenX: Float, screenY: Float) {
        val (worldX, worldY) = screenToWorld(screenX, screenY)
        eraseModeActive = true
        dragCandidateId = null
        isDraggingComponent = false
        wireDragStart = null
        wireDragCurrentWorld = null
        reconnectingWireId = null
        selectionBoxStart = null
        selectionBoxCurrent = null
        lassoPoints = null
        eraseAt(worldX, worldY)
        invalidate()
    }

    private fun eraseAt(worldX: Float, worldY: Float) {
        circuit.componentAt(worldX, worldY)?.let {
            listener?.onComponentRemoved(it)
            return
        }
        findWireNear(worldX, worldY)?.let {
            listener?.onWireRemoved(it)
        }
    }

    private fun placeComponent(type: ComponentType, x: Float, y: Float) {
        val component = ComponentInstance(circuit.nextComponentId(), type, x, y)
        listener?.onComponentAdded(component)
        selection.clear(); selectedWireIds.clear()
        selection.add(component.id)
        reportSelectionChanged()
        invalidate()
    }

    private fun snap(value: Float): Float {
        if (!snapToGridEnabled) return value
        val gridSize = 20f
        return round(value / gridSize) * gridSize
    }

    private fun reportSelectionChanged() {
        listener?.onSelectionChanged(selection.toSet(), selectedWireIds.toSet())
    }

    /** After a box/lasso pass picks components, also select any wire
     * whose *both* endpoints landed inside the same selection — this is
     * what lets a drag-select sweep up wires, not just components. */
    private fun selectWiresBetweenSelectedComponents() {
        selectedWireIds.clear()
        for (wire in circuit.allWires) {
            if (wire.from.componentId in selection && wire.to.componentId in selection) {
                selectedWireIds.add(wire.id)
            }
        }
    }

    private fun finishLassoSelection(points: List<Pair<Float, Float>>) {
        lassoPoints = null
        if (points.size < 3) { invalidate(); return }

        val path = Path()
        path.moveTo(points[0].first, points[0].second)
        for (i in 1 until points.size) path.lineTo(points[i].first, points[i].second)
        path.close()

        val bounds = android.graphics.RectF()
        path.computeBounds(bounds, true)
        val clip = Region(
            floor(bounds.left).toInt() - 1, floor(bounds.top).toInt() - 1,
            ceil(bounds.right).toInt() + 1, ceil(bounds.bottom).toInt() + 1
        )
        val pathRegion = Region()
        pathRegion.setPath(path, clip)

        selection.clear()
        for (component in circuit.allComponents) {
            if (pathRegion.contains(component.x.toInt(), component.y.toInt())) {
                selection.add(component.id)
            }
        }
        selectWiresBetweenSelectedComponents()
        reportSelectionChanged()
        invalidate()
    }

    // --- Hit-testing --------------------------------------------------------

    private fun findOutputPinNear(worldX: Float, worldY: Float): Pair<Int, Int>? {
        val radius = pinSnapRadius()
        var best: Pair<Int, Int>? = null
        var bestDist = Float.MAX_VALUE
        for (component in circuit.allComponents) {
            for (i in 0 until component.type.outputCount) {
                val (px, py) = component.outputPinWorldPosition(i)
                val d = distance(px, py, worldX, worldY)
                if (d <= radius && d < bestDist) { bestDist = d; best = component.id to i }
            }
        }
        return best
    }

    private fun findInputPinNear(worldX: Float, worldY: Float): Pair<Int, Int>? {
        val radius = pinSnapRadius()
        var best: Pair<Int, Int>? = null
        var bestDist = Float.MAX_VALUE
        for (component in circuit.allComponents) {
            for (i in 0 until component.type.inputCount) {
                val (px, py) = component.inputPinWorldPosition(i)
                val d = distance(px, py, worldX, worldY)
                if (d <= radius && d < bestDist) { bestDist = d; best = component.id to i }
            }
        }
        return best
    }

    /** Finds an existing wire whose *input* endpoint is near the touch
     * point, returning the wire and the component id at its *output*
     * end — so the caller can continue the gesture exactly as if a fresh
     * wire-drag had started from that same output pin. */
    private fun findWireInputEndpointNear(worldX: Float, worldY: Float): Pair<WireInstance, Int>? {
        val radius = pinSnapRadius()
        for (wire in circuit.allWires) {
            val to = circuit.componentById(wire.to.componentId) ?: continue
            val (px, py) = to.inputPinWorldPosition(wire.to.pinIndex)
            if (distance(px, py, worldX, worldY) <= radius) {
                return wire to wire.from.componentId
            }
        }
        return null
    }

    private fun findWireNear(worldX: Float, worldY: Float): WireInstance? {
        val tolerance = wireHitTolerance()
        var closest: WireInstance? = null
        var closestDist = Float.MAX_VALUE
        for (wire in circuit.allWires) {
            val from = circuit.componentById(wire.from.componentId) ?: continue
            val to = circuit.componentById(wire.to.componentId) ?: continue
            val (sx, sy) = from.outputPinWorldPosition(wire.from.pinIndex)
            val (ex, ey) = to.inputPinWorldPosition(wire.to.pinIndex)
            val vertices = WireRenderer.routeVertices(sx, sy, ex, ey)
            for (i in 0 until vertices.size - 1) {
                val (ax, ay) = vertices[i]
                val (bx, by) = vertices[i + 1]
                val d = distanceToSegment(worldX, worldY, ax, ay, bx, by)
                if (d < tolerance && d < closestDist) {
                    closestDist = d
                    closest = wire
                }
            }
        }
        return closest
    }

    private fun distanceToSegment(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1; val dy = y2 - y1
        val lengthSq = dx * dx + dy * dy
        if (lengthSq < 0.0001f) return distance(px, py, x1, y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lengthSq).coerceIn(0f, 1f)
        return distance(px, py, x1 + t * dx, y1 + t * dy)
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt(dx * dx + dy * dy)
    }

    // --- Drawing -------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(theme.canvasBackground)

        val topLeft = screenToWorld(0f, 0f)
        val bottomRight = screenToWorld(width.toFloat(), height.toFloat())

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)

        GridRenderer.draw(canvas, theme, scale, topLeft.first, topLeft.second, bottomRight.first, bottomRight.second)

        val margin = 200f
        val visibleComponents = circuit.allComponents.filter {
            it.x in (topLeft.first - margin)..(bottomRight.first + margin) &&
                it.y in (topLeft.second - margin)..(bottomRight.second + margin)
        }
        val visibleIds = visibleComponents.map { it.id }.toSet()

        for (wire in circuit.allWires) {
            val from = circuit.componentById(wire.from.componentId) ?: continue
            val to = circuit.componentById(wire.to.componentId) ?: continue
            if (wire.from.componentId !in visibleIds && wire.to.componentId !in visibleIds) continue
            val isHigh = outputStates[wire.from.componentId] ?: false
            WireRenderer.draw(
                canvas, wire, from, to, theme,
                isHigh = isHigh,
                isFloating = false,
                hasError = wire.id in shortCircuitWireIds,
                isSelected = wire.id in selectedWireIds,
                animationPhase = animationPhase
            )
        }

        drawWireDragPreview(canvas)

        for (component in visibleComponents) {
            val outputHigh = outputStates[component.id] ?: false
            GateRenderer.draw(
                canvas, component, theme, outputHigh,
                isSelected = component.id in selection,
                hasError = component.id in floatingComponentIds || component.id in oscillatingComponentIds,
                animationPhase = animationPhase
            )
        }

        canvas.restore()

        drawSelectionGesturePreview(canvas)
    }

    private fun drawWireDragPreview(canvas: Canvas) {
        val (fromId, fromPin) = wireDragStart ?: return
        val from = circuit.componentById(fromId) ?: return
        val target = wireDragCurrentWorld ?: return
        val (sx, sy) = from.outputPinWorldPosition(fromPin)

        // Highlight every nearby compatible input pin so the user can see
        // where a connection will land before lifting their finger, and
        // find the single nearest one within actual snap range.
        val highlightR = pinHighlightRadius()
        val snapR = pinSnapRadius()
        var nearestX = target.first
        var nearestY = target.second
        var nearestDist = Float.MAX_VALUE
        var hasSnapTarget = false

        for (component in circuit.allComponents) {
            if (component.id == fromId) continue
            for (i in 0 until component.type.inputCount) {
                val (px, py) = component.inputPinWorldPosition(i)
                val d = distance(px, py, target.first, target.second)
                if (d > highlightR) continue
                pinHighlightPaint.color = theme.selectionHighlight
                pinHighlightPaint.alpha = if (d <= snapR) 255 else 110
                canvas.drawCircle(px, py, 10f, pinHighlightPaint)
                if (d <= snapR && d < nearestDist) {
                    nearestDist = d
                    nearestX = px; nearestY = py
                    hasSnapTarget = true
                }
            }
        }

        wireDragPreviewPaint.color = theme.selectionHighlight
        if (hasSnapTarget) {
            wireDragPreviewPaint.pathEffect = null
            wireDragPreviewPaint.strokeWidth = 4.5f
        } else {
            wireDragPreviewPaint.pathEffect = dashEffect
            wireDragPreviewPaint.strokeWidth = 3f
        }
        val endX = if (hasSnapTarget) nearestX else target.first
        val endY = if (hasSnapTarget) nearestY else target.second
        canvas.drawLine(sx, sy, endX, endY, wireDragPreviewPaint)
    }

    private fun drawSelectionGesturePreview(canvas: Canvas) {
        selectionBoxStart?.let { (sx, sy) ->
            val (cx, cy) = selectionBoxCurrent ?: (sx to sy)
            val (screenSX, screenSY) = worldToScreen(sx, sy)
            val (screenCX, screenCY) = worldToScreen(cx, cy)
            selectionOutlinePaint.color = theme.selectionHighlight
            canvas.drawRect(
                min(screenSX, screenCX), min(screenSY, screenCY),
                max(screenSX, screenCX), max(screenSY, screenCY),
                selectionOutlinePaint
            )
            return
        }

        val points = lassoPoints ?: return
        if (points.size < 2) return
        val path = Path()
        val (startX, startY) = worldToScreen(points[0].first, points[0].second)
        path.moveTo(startX, startY)
        for (i in 1 until points.size) {
            val (sx, sy) = worldToScreen(points[i].first, points[i].second)
            path.lineTo(sx, sy)
        }
        lassoFillPaint.color = theme.selectionHighlight
        lassoFillPaint.alpha = 40
        canvas.drawPath(path, lassoFillPaint)
        selectionOutlinePaint.color = theme.selectionHighlight
        canvas.drawPath(path, selectionOutlinePaint)
    }
}
