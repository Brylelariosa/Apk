package com.circuitsandbox.app.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.circuitsandbox.app.R
import com.circuitsandbox.app.databinding.ActivityMainBinding
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.WireInstance
import com.circuitsandbox.app.persistence.ProjectRepository
import com.circuitsandbox.app.render.CircuitTheme
import com.circuitsandbox.app.simulation.SimulationController
import com.circuitsandbox.app.undo.AddComponentCommand
import com.circuitsandbox.app.undo.AddWireCommand
import com.circuitsandbox.app.undo.CommandHistory
import com.circuitsandbox.app.undo.MoveComponentCommand
import com.circuitsandbox.app.undo.RemoveComponentCommand
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * Hosts the canvas, toolbar, component palette, and play/pause control.
 *
 * Every circuit mutation that the user should be able to undo flows
 * through [history] rather than touching [circuit] directly — including
 * mutations that originate from [CircuitCanvasView] via the
 * [CircuitInteractionListener] callbacks below.
 */
class MainActivity : AppCompatActivity(), CircuitInteractionListener {

    private lateinit var binding: ActivityMainBinding
    private val circuit = CircuitModel()
    private lateinit var simulation: SimulationController
    private val history = CommandHistory()
    private lateinit var projectRepository: ProjectRepository
    private var themeIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectRepository = ProjectRepository(filesDir)

        simulation = SimulationController(circuit)
        simulation.onStateChanged = { report ->
            binding.canvasView.outputStates = simulation.snapshotOutputs()
            binding.canvasView.floatingComponentIds = report.floatingInputGateIds.toSet()
            binding.canvasView.oscillatingComponentIds = report.oscillatingGateIds.toSet()
            binding.canvasView.advanceAnimation()
        }

        binding.canvasView.circuit = circuit
        binding.canvasView.theme = CircuitTheme.DARK
        binding.canvasView.listener = this

        setSupportActionBar(binding.toolbar)

        buildPalette()

        binding.fabPlayPause.setOnClickListener { toggleSimulation() }
        binding.btnUndo.setOnClickListener { history.undo(); refreshAll() }
        binding.btnRedo.setOnClickListener { history.redo(); refreshAll() }

        binding.canvasView.post { binding.canvasView.centerOn(0f, 0f) }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_theme -> { cycleTheme(); true }
            R.id.action_save -> { saveProject(); true }
            R.id.action_load -> { loadLatestProject(); true }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun buildPalette() {
        val container = binding.paletteContainer
        container.removeAllViews()
        for (type in ComponentType.entries) {
            val button = Button(this)
            button.text = type.displayName
            button.setOnClickListener { binding.canvasView.pendingPlacementType = type }
            container.addView(button)
        }
    }

    private fun toggleSimulation() {
        if (simulation.isRunning) {
            simulation.pause()
            binding.canvasView.simulationRunning = false
            binding.fabPlayPause.setImageResource(R.drawable.ic_play)
        } else {
            simulation.rebuild()
            simulation.start(lifecycleScope)
            binding.canvasView.simulationRunning = true
            binding.fabPlayPause.setImageResource(R.drawable.ic_pause)
        }
    }

    private fun refreshAll() {
        binding.canvasView.invalidate()
    }

    private fun cycleTheme() {
        themeIndex = (themeIndex + 1) % CircuitTheme.ALL.size
        binding.canvasView.theme = CircuitTheme.ALL[themeIndex]
        binding.canvasView.invalidate()
    }

    private fun saveProject() {
        projectRepository.save("my-circuit", circuit)
        Toast.makeText(this, R.string.saved_toast, Toast.LENGTH_SHORT).show()
    }

    private fun loadLatestProject() {
        val file = projectRepository.listProjects().firstOrNull()
        if (file == null) {
            Toast.makeText(this, R.string.no_saved_project_toast, Toast.LENGTH_SHORT).show()
            return
        }
        val loaded = projectRepository.load(file)
        circuit.clear()
        loaded.allComponents.forEach { circuit.addComponent(it) }
        loaded.allWires.forEach { circuit.addWire(it) }
        refreshAll()
        Toast.makeText(this, R.string.loaded_toast, Toast.LENGTH_SHORT).show()
    }

    override fun onSelectionChanged(selected: Set<Int>) {
        if (selected.size == 1) {
            circuit.componentById(selected.first())?.let { showInspector(it) }
        }
    }

    override fun onComponentMoved(componentId: Int, fromX: Float, fromY: Float, toX: Float, toY: Float) {
        history.execute(MoveComponentCommand(circuit, componentId, fromX, fromY, toX, toY))
    }

    override fun onComponentAdded(component: ComponentInstance) {
        history.execute(AddComponentCommand(circuit, component))
        refreshAll()
    }

    override fun onComponentRemoved(component: ComponentInstance) {
        history.execute(RemoveComponentCommand(circuit, component))
        refreshAll()
    }

    override fun onWireAdded(wire: WireInstance) {
        history.execute(AddWireCommand(circuit, wire))
        refreshAll()
    }

    override fun onWireRemoved(wire: WireInstance) {
        refreshAll()
    }

    override fun onSwitchToggled(componentId: Int) {
        val component = circuit.componentById(componentId) ?: return
        val current = simulation.outputState(component)
        simulation.setSwitchState(componentId, !current)
    }

    private fun showInspector(component: ComponentInstance) {
        val dialog = BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_inspector, null)
        view.findViewById<TextView>(R.id.inspectorTitle).text = component.type.displayName
        view.findViewById<TextView>(R.id.inspectorDescription).text = component.type.description

        val tableContainer = view.findViewById<LinearLayout>(R.id.truthTableContainer)
        for ((inputs, outputs) in component.type.truthTable) {
            val row = TextView(this)
            val inStr = inputs.joinToString("") { if (it) "1" else "0" }
            val outStr = outputs.joinToString("") { if (it) "1" else "0" }
            row.text = "$inStr  →  $outStr"
            tableContainer.addView(row)
        }

        dialog.setContentView(view)
        dialog.show()
    }

    override fun onDestroy() {
        simulation.release()
        super.onDestroy()
    }
}
