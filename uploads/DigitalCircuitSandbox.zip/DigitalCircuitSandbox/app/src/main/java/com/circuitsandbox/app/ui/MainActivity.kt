package com.circuitsandbox.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.circuitsandbox.app.R
import com.circuitsandbox.app.databinding.ActivityMainBinding
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.ExampleLibrary
import com.circuitsandbox.app.model.WireInstance
import com.circuitsandbox.app.persistence.ProjectRepository
import com.circuitsandbox.app.render.CircuitTheme
import com.circuitsandbox.app.simulation.SimulationController
import com.circuitsandbox.app.undo.AddComponentCommand
import com.circuitsandbox.app.undo.AddWireCommand
import com.circuitsandbox.app.undo.Command
import com.circuitsandbox.app.undo.CommandHistory
import com.circuitsandbox.app.undo.CompositeCommand
import com.circuitsandbox.app.undo.MirrorComponentsCommand
import com.circuitsandbox.app.undo.MoveComponentCommand
import com.circuitsandbox.app.undo.RemoveComponentCommand
import com.circuitsandbox.app.undo.RemoveWireCommand
import com.circuitsandbox.app.undo.RotateComponentsCommand
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * Hosts the canvas, toolbar, contextual action bar, component search/
 * palette, and play/pause control.
 *
 * Every circuit mutation the user should be able to undo flows through
 * [history] — including mutations that originate from [CircuitCanvasView]
 * via the [CircuitInteractionListener] callbacks below. Single-item
 * actions become one [Command]; bulk actions (paste, duplicate, multi-
 * delete) become one [CompositeCommand], so one tap on "undo" always
 * reverses one whole user-visible action.
 */
class MainActivity : AppCompatActivity(), CircuitInteractionListener {

    private lateinit var binding: ActivityMainBinding
    private val circuit = CircuitModel()
    private lateinit var simulation: SimulationController
    private val history = CommandHistory()
    private lateinit var projectRepository: ProjectRepository
    private var themeIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectRepository = ProjectRepository(filesDir)

        simulation = SimulationController(circuit)
        simulation.onStateChanged = { report ->
            binding.canvasView.outputStates = simulation.snapshotOutputs()
            binding.canvasView.floatingComponentIds = report.floatingInputGateIds.toSet()
            binding.canvasView.oscillatingComponentIds = report.oscillatingGateIds.toSet()
            binding.canvasView.advanceAnimation()
        }

        binding.canvasView.circuit = circuit
        binding.canvasView.theme = CircuitTheme.DARK
        binding.canvasView.listener = this

        setSupportActionBar(binding.toolbar)

        buildPalette()
        setupSearchBox()
        setupContextualBar()

        binding.fabPlayPause.setOnClickListener { toggleSimulation() }
        binding.btnUndo.setOnClickListener { history.undo(); refreshAll() }
        binding.btnRedo.setOnClickListener { history.redo(); refreshAll() }

        binding.canvasView.post { binding.canvasView.centerOn(0f, 0f) }
    }

    // --- Menu ---------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        menu.findItem(R.id.action_snap_grid)?.isChecked = binding.canvasView.snapToGridEnabled
        menu.findItem(R.id.action_lasso_mode)?.isChecked = binding.canvasView.selectionMode == SelectionMode.LASSO
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_paste)?.isEnabled = binding.canvasView.hasClipboard()
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_examples -> { showExamples(); true }
            R.id.action_theme -> { cycleTheme(); true }
            R.id.action_save -> { saveProject(); true }
            R.id.action_load -> { loadLatestProject(); true }
            R.id.action_fit_screen -> { binding.canvasView.fitToScreen(); true }
            R.id.action_snap_grid -> {
                item.isChecked = !item.isChecked
                binding.canvasView.snapToGridEnabled = item.isChecked
                true
            }
            R.id.action_lasso_mode -> {
                item.isChecked = !item.isChecked
                binding.canvasView.selectionMode = if (item.isChecked) SelectionMode.LASSO else SelectionMode.BOX
                true
            }
            R.id.action_paste -> {
                if (binding.canvasView.hasClipboard()) {
                    binding.canvasView.pasteClipboard()
                } else {
                    Toast.makeText(this, R.string.clipboard_empty_toast, Toast.LENGTH_SHORT).show()
                }
                true
            }
            R.id.action_delete_wires -> {
                confirmAndRun(R.string.confirm_delete_wires) { binding.canvasView.deleteAllWires() }
                true
            }
            R.id.action_delete_components -> {
                confirmAndRun(R.string.confirm_delete_components) { binding.canvasView.deleteAllComponents() }
                true
            }
            R.id.action_delete_disconnected -> {
                binding.canvasView.deleteDisconnectedWires()
                true
            }
            R.id.action_clear_canvas -> {
                confirmAndRun(R.string.confirm_clear_canvas) { binding.canvasView.clearCanvas() }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun confirmAndRun(messageRes: Int, action: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setMessage(messageRes)
            .setPositiveButton(R.string.confirm) { _, _ -> action() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // --- Setup ----------------------------------------------------------

    private fun setupContextualBar() {
        binding.btnCopy.setOnClickListener {
            binding.canvasView.copySelection()
            invalidateOptionsMenu()
            Toast.makeText(this, R.string.copied_toast, Toast.LENGTH_SHORT).show()
        }
        binding.btnDuplicate.setOnClickListener {
            binding.canvasView.duplicateSelection()
            invalidateOptionsMenu()
        }
        binding.btnRotate.setOnClickListener { binding.canvasView.rotateSelection() }
        binding.btnMirror.setOnClickListener { binding.canvasView.mirrorSelection() }
        binding.btnDeleteSelected.setOnClickListener { binding.canvasView.deleteSelection() }
    }

    // Ordered list of last-used types shown at the head of the palette.
    private val recentlyUsed = LinkedHashSet<ComponentType>()

    private fun setupSearchBox() {
        binding.searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                buildPalette(s?.toString().orEmpty())
            }
        })
    }

    private fun buildPalette(filter: String = "") {
        val container = binding.paletteContainer
        container.removeAllViews()
        val query = filter.trim().lowercase()
        val dp = resources.displayMetrics.density

        fun addChip(type: ComponentType) {
            val chip = com.google.android.material.chip.Chip(this)
            chip.text = type.displayName
            chip.isCheckable = false
            chip.setOnClickListener {
                // Track recently used (max 6, most-recent first)
                recentlyUsed.remove(type)
                recentlyUsed.add(type)
                if (recentlyUsed.size > 6) recentlyUsed.remove(recentlyUsed.first())
                binding.canvasView.pendingPlacementType = type
            }
            container.addView(chip)
        }

        fun addHeader(text: String) {
            val tv = android.widget.TextView(this)
            tv.text = text
            tv.textSize = 10f
            tv.setPadding((8 * dp).toInt(), 0, (4 * dp).toInt(), 0)
            tv.gravity = android.view.Gravity.CENTER_VERTICAL
            tv.layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT
            )
            container.addView(tv)
        }

        if (query.isEmpty()) {
            // Show "recent" section only when not searching
            if (recentlyUsed.isNotEmpty()) {
                addHeader("RECENT")
                for (type in recentlyUsed.reversed()) addChip(type)
                addHeader("|")
            }
            for (category in com.circuitsandbox.app.model.ComponentCategory.entries) {
                val types = ComponentType.entries.filter { it.category == category }
                if (types.isEmpty()) continue
                addHeader(category.displayName.uppercase())
                types.forEach { addChip(it) }
            }
        } else {
            ComponentType.entries
                .filter { it.displayName.lowercase().contains(query) }
                .forEach { addChip(it) }
        }
    }

    private fun toggleSimulation() {
        if (simulation.isRunning) {
            simulation.pause()
            binding.canvasView.simulationRunning = false
            binding.fabPlayPause.setImageResource(R.drawable.ic_play)
        } else {
            simulation.rebuild()
            simulation.start(lifecycleScope)
            binding.canvasView.simulationRunning = true
            binding.fabPlayPause.setImageResource(R.drawable.ic_pause)
        }
    }

    private fun refreshAll() {
        binding.canvasView.invalidate()
    }

    private fun cycleTheme() {
        themeIndex = (themeIndex + 1) % CircuitTheme.ALL.size
        binding.canvasView.theme = CircuitTheme.ALL[themeIndex]
        binding.canvasView.invalidate()
    }

    private fun saveProject() {
        projectRepository.save("my-circuit", circuit)
        Toast.makeText(this, R.string.saved_toast, Toast.LENGTH_SHORT).show()
    }

    private fun loadLatestProject() {
        val file = projectRepository.listProjects().firstOrNull()
        if (file == null) {
            Toast.makeText(this, R.string.no_saved_project_toast, Toast.LENGTH_SHORT).show()
            return
        }
        val loaded = projectRepository.load(file)
        circuit.clear()
        loaded.allComponents.forEach { circuit.addComponent(it) }
        loaded.allWires.forEach { circuit.addWire(it) }
        history.clear()
        refreshAll()
        Toast.makeText(this, R.string.loaded_toast, Toast.LENGTH_SHORT).show()
    }

    // --- CircuitInteractionListener --------------------------------------

    override fun onSelectionChanged(componentIds: Set<Int>, wireIds: Set<Int>) {
        binding.contextualBar.visibility = if (componentIds.isNotEmpty() || wireIds.isNotEmpty()) {
            View.VISIBLE
        } else {
            View.GONE
        }
        if (componentIds.size == 1 && wireIds.isEmpty()) {
            circuit.componentById(componentIds.first())?.let { showInspector(it) }
        }
    }

    override fun onComponentMoved(componentId: Int, fromX: Float, fromY: Float, toX: Float, toY: Float) {
        history.execute(MoveComponentCommand(circuit, componentId, fromX, fromY, toX, toY))
    }

    override fun onComponentAdded(component: ComponentInstance) {
        history.execute(AddComponentCommand(circuit, component))
        refreshAll()
    }

    override fun onComponentRemoved(component: ComponentInstance) {
        history.execute(RemoveComponentCommand(circuit, component))
        refreshAll()
    }

    override fun onWireAdded(wire: WireInstance) {
        history.execute(AddWireCommand(circuit, wire))
        refreshAll()
    }

    override fun onWireRemoved(wire: WireInstance) {
        history.execute(RemoveWireCommand(circuit, wire))
        refreshAll()
    }

    override fun onWireReconnected(oldWire: WireInstance, newWire: WireInstance) {
        history.execute(CompositeCommand(listOf(
            RemoveWireCommand(circuit, oldWire),
            AddWireCommand(circuit, newWire)
        )))
        refreshAll()
    }

    override fun onSwitchToggled(componentId: Int) {
        val component = circuit.componentById(componentId) ?: return
        val current = simulation.outputState(component)
        simulation.setSwitchState(componentId, !current)
    }

    override fun onBulkAdd(components: List<ComponentInstance>, wires: List<WireInstance>) {
        val commands = mutableListOf<Command>()
        components.forEach { commands.add(AddComponentCommand(circuit, it)) }
        wires.forEach { commands.add(AddWireCommand(circuit, it)) }
        if (commands.isNotEmpty()) history.execute(CompositeCommand(commands))
        refreshAll()
    }

    override fun onBulkDelete(componentIds: Set<Int>, wireIds: Set<Int>) {
        val commands = mutableListOf<Command>()
        // Explicit wire removals first; component removal also cascades
        // any wires still attached to it. CircuitModel's map-based
        // storage makes addWire/removeWire safely idempotent by id, so
        // combining both kinds of command here is safe even when a wire
        // is captured by more than one of them (see CompositeCommand).
        wireIds.forEach { id -> circuit.wireById(id)?.let { commands.add(RemoveWireCommand(circuit, it)) } }
        componentIds.forEach { id -> circuit.componentById(id)?.let { commands.add(RemoveComponentCommand(circuit, it)) } }
        if (commands.isEmpty()) {
            Toast.makeText(this, R.string.nothing_to_delete_toast, Toast.LENGTH_SHORT).show()
            return
        }
        history.execute(CompositeCommand(commands))
        refreshAll()
    }

    override fun onRotateRequested(componentIds: Set<Int>) {
        history.execute(RotateComponentsCommand(circuit, componentIds))
        refreshAll()
    }

    override fun onMirrorRequested(componentIds: Set<Int>) {
        history.execute(MirrorComponentsCommand(circuit, componentIds))
        refreshAll()
    }

    private fun showExamples() {
        ExamplesDialog.show(
            context = this,
            hasUnsavedContent = circuit.allComponents.isNotEmpty()
        ) { example ->
            val model = example.model ?: return@show
            // Confirm only when the canvas has content the user might care about
            val hasContent = circuit.allComponents.isNotEmpty()
            val doLoad = {
                if (simulation.isRunning) {
                    simulation.pause()
                    binding.canvasView.simulationRunning = false
                    binding.fabPlayPause.setImageResource(R.drawable.ic_play)
                }
                circuit.clear()
                model.allComponents.forEach { circuit.addComponent(it.copy()) }
                model.allWires.forEach { circuit.addWire(it.copy()) }
                history.clear()
                binding.canvasView.fitToScreen()
                refreshAll()
            }
            if (hasContent) {
                MaterialAlertDialogBuilder(this)
                    .setMessage(R.string.confirm_load_example)
                    .setPositiveButton(R.string.confirm) { _, _ -> doLoad() }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            } else {
                doLoad()
            }
        }
    }

    private fun showInspector(component: ComponentInstance) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_inspector, null)
        view.findViewById<TextView>(R.id.inspectorTitle).text = component.type.displayName
        view.findViewById<TextView>(R.id.inspectorDescription).text = component.type.description

        val tableContainer = view.findViewById<LinearLayout>(R.id.truthTableContainer)
        for ((inputs, outputs) in component.type.truthTable) {
            val row = TextView(this)
            val inStr = inputs.joinToString("") { if (it) "1" else "0" }
            val outStr = outputs.joinToString("") { if (it) "1" else "0" }
            row.text = "$inStr  →  $outStr"
            tableContainer.addView(row)
        }

        dialog.setContentView(view)
        dialog.show()
    }

    override fun onDestroy() {
        simulation.release()
        super.onDestroy()
    }
}
