package com.circuitsandbox.app.render

import android.graphics.Color

/**
 * Color palette for one visual theme. Swappable at runtime with no
 * Activity recreation, since [com.circuitsandbox.app.ui.CircuitCanvasView]
 * just reads whichever instance is assigned to it on its next draw pass.
 */
data class CircuitTheme(
    val name: String,
    val canvasBackground: Int,
    val gridMinor: Int,
    val gridMajor: Int,
    val componentOutline: Int,
    val componentFill: Int,
    val wireLow: Int,
    val wireHigh: Int,
    val wireFloating: Int,
    val wireError: Int,
    val selectionHighlight: Int,
    val textColor: Int,
    val ledOffColor: Int,
    val ledOnColor: Int
) {
    companion object {
        val DARK = CircuitTheme(
            name = "Dark",
            canvasBackground = Color.parseColor("#121417"),
            gridMinor = Color.parseColor("#1E2227"),
            gridMajor = Color.parseColor("#2A2F36"),
            componentOutline = Color.parseColor("#E3E6EA"),
            componentFill = Color.parseColor("#1B1E23"),
            wireLow = Color.parseColor("#5C6470"),
            wireHigh = Color.parseColor("#33C9A6"),
            wireFloating = Color.parseColor("#C99A1F"),
            wireError = Color.parseColor("#E5484D"),
            selectionHighlight = Color.parseColor("#4C8DFF"),
            textColor = Color.parseColor("#E3E6EA"),
            ledOffColor = Color.parseColor("#3A2020"),
            ledOnColor = Color.parseColor("#FF5A4D")
        )

        val LIGHT = CircuitTheme(
            name = "Light",
            canvasBackground = Color.parseColor("#F7F8FA"),
            gridMinor = Color.parseColor("#E7E9EC"),
            gridMajor = Color.parseColor("#D2D6DB"),
            componentOutline = Color.parseColor("#1B1E23"),
            componentFill = Color.parseColor("#FFFFFF"),
            wireLow = Color.parseColor("#9098A3"),
            wireHigh = Color.parseColor("#0E9E7E"),
            wireFloating = Color.parseColor("#C08A00"),
            wireError = Color.parseColor("#D1373C"),
            selectionHighlight = Color.parseColor("#2F6FE4"),
            textColor = Color.parseColor("#1B1E23"),
            ledOffColor = Color.parseColor("#E8D7D5"),
            ledOnColor = Color.parseColor("#E5402F")
        )

        val BLUEPRINT = CircuitTheme(
            name = "Blueprint",
            canvasBackground = Color.parseColor("#0B3D63"),
            gridMinor = Color.parseColor("#134B76"),
            gridMajor = Color.parseColor("#1E5C8A"),
            componentOutline = Color.parseColor("#EAF4FF"),
            componentFill = Color.parseColor("#0B3D63"),
            wireLow = Color.parseColor("#5E8FB5"),
            wireHigh = Color.parseColor("#7CF2C4"),
            wireFloating = Color.parseColor("#F2C46A"),
            wireError = Color.parseColor("#FF7A7A"),
            selectionHighlight = Color.parseColor("#FFFFFF"),
            textColor = Color.parseColor("#EAF4FF"),
            ledOffColor = Color.parseColor("#13507D"),
            ledOnColor = Color.parseColor("#7CF2C4")
        )

        val ALL = listOf(DARK, LIGHT, BLUEPRINT)
    }
}
