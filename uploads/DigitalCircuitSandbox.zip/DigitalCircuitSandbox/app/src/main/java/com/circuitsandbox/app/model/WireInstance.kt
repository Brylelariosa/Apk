package com.circuitsandbox.app.model

data class WireEndpoint(val componentId: Int, val pinIndex: Int, val isInput: Boolean)

data class WireInstance(
    val id: Int,
    val from: WireEndpoint,
    val to: WireEndpoint
)
