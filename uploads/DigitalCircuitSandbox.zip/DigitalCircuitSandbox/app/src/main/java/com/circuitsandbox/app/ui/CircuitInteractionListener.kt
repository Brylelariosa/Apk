package com.circuitsandbox.app.ui

import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.WireInstance

/**
 * Callbacks [CircuitCanvasView] uses to report user intent upward, so the
 * host (MainActivity) can route every mutation through undo/redo instead
 * of the view mutating the model directly and silently.
 *
 * Selection now covers components and wires together in one combined
 * report, since wires became independently selectable in this milestone.
 * Bulk operations (paste, duplicate, multi-delete) get their own
 * callbacks so the host can collapse them into a single undo step.
 */
interface CircuitInteractionListener {
    fun onSelectionChanged(componentIds: Set<Int>, wireIds: Set<Int>)
    fun onComponentMoved(componentId: Int, fromX: Float, fromY: Float, toX: Float, toY: Float)
    fun onComponentAdded(component: ComponentInstance)
    fun onComponentRemoved(component: ComponentInstance)
    fun onWireAdded(wire: WireInstance)
    fun onWireRemoved(wire: WireInstance)

    /** Dragging an existing wire's input endpoint onto a new pin:
     * [oldWire] is replaced by [newWire] in a single undo step. */
    fun onWireReconnected(oldWire: WireInstance, newWire: WireInstance)

    fun onSwitchToggled(componentId: Int)

    /** Paste or duplicate: a whole batch added as one undo step. */
    fun onBulkAdd(components: List<ComponentInstance>, wires: List<WireInstance>)

    /** Any "delete many at once" action — selection delete, delete-wires-
     * only, delete-components-only, delete-disconnected-wires, or
     * clear-canvas — always lands as one undo step. */
    fun onBulkDelete(componentIds: Set<Int>, wireIds: Set<Int>)

    fun onRotateRequested(componentIds: Set<Int>)
    fun onMirrorRequested(componentIds: Set<Int>)
}
