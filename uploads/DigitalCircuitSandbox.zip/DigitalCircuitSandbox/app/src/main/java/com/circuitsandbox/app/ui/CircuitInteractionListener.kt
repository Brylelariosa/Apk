package com.circuitsandbox.app.ui

import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.WireInstance

/** Callbacks [CircuitCanvasView] uses to report user intent upward, so the
 * host (MainActivity) can route every mutation through undo/redo instead
 * of the view mutating the model directly and silently. */
interface CircuitInteractionListener {
    fun onSelectionChanged(selected: Set<Int>)
    fun onComponentMoved(componentId: Int, fromX: Float, fromY: Float, toX: Float, toY: Float)
    fun onComponentAdded(component: ComponentInstance)
    fun onComponentRemoved(component: ComponentInstance)
    fun onWireAdded(wire: WireInstance)
    fun onWireRemoved(wire: WireInstance)
    fun onSwitchToggled(componentId: Int)
}
