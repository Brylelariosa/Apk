package com.circuitsandbox.app.undo

import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.WireInstance

class AddComponentCommand(
    private val circuit: CircuitModel,
    private val component: ComponentInstance
) : Command {
    override fun execute() = circuit.addComponent(component)
    override fun undo() = circuit.removeComponent(component.id)
}

class RemoveComponentCommand(
    private val circuit: CircuitModel,
    private val component: ComponentInstance
) : Command {
    // Captured at construction time, before execute() removes anything,
    // so undo() can restore exactly what was connected.
    private val removedWires = circuit.wiresConnectedTo(component.id)

    override fun execute() = circuit.removeComponent(component.id)
    override fun undo() {
        circuit.addComponent(component)
        removedWires.forEach { circuit.addWire(it) }
    }
}

class MoveComponentCommand(
    private val circuit: CircuitModel,
    private val componentId: Int,
    private val fromX: Float,
    private val fromY: Float,
    private val toX: Float,
    private val toY: Float
) : Command {
    override fun execute() {
        circuit.componentById(componentId)?.let { it.x = toX; it.y = toY }
    }
    override fun undo() {
        circuit.componentById(componentId)?.let { it.x = fromX; it.y = fromY }
    }
}

class AddWireCommand(
    private val circuit: CircuitModel,
    private val wire: WireInstance
) : Command {
    override fun execute() = circuit.addWire(wire)
    override fun undo() = circuit.removeWire(wire.id)
}
