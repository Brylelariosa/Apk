package com.circuitsandbox.app.undo

import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.WireInstance

class AddComponentCommand(
    private val circuit: CircuitModel,
    private val component: ComponentInstance
) : Command {
    override fun execute() = circuit.addComponent(component)
    override fun undo() = circuit.removeComponent(component.id)
}

class RemoveComponentCommand(
    private val circuit: CircuitModel,
    private val component: ComponentInstance
) : Command {
    // Captured at construction time, before execute() removes anything,
    // so undo() can restore exactly what was connected. CircuitModel's
    // map-based storage makes addWire/addComponent idempotent by id, so
    // it's safe for the same wire to be captured by more than one
    // RemoveComponentCommand in the same bulk delete (see CompositeCommand).
    private val removedWires = circuit.wiresConnectedTo(component.id)

    override fun execute() = circuit.removeComponent(component.id)
    override fun undo() {
        circuit.addComponent(component)
        removedWires.forEach { circuit.addWire(it) }
    }
}

class MoveComponentCommand(
    private val circuit: CircuitModel,
    private val componentId: Int,
    private val fromX: Float,
    private val fromY: Float,
    private val toX: Float,
    private val toY: Float
) : Command {
    override fun execute() {
        circuit.componentById(componentId)?.let { it.x = toX; it.y = toY }
    }
    override fun undo() {
        circuit.componentById(componentId)?.let { it.x = fromX; it.y = fromY }
    }
}

class AddWireCommand(
    private val circuit: CircuitModel,
    private val wire: WireInstance
) : Command {
    override fun execute() = circuit.addWire(wire)
    override fun undo() = circuit.removeWire(wire.id)
}

class RemoveWireCommand(
    private val circuit: CircuitModel,
    private val wire: WireInstance
) : Command {
    override fun execute() = circuit.removeWire(wire.id)
    override fun undo() = circuit.addWire(wire)
}

/** Rotates every component in [componentIds] by 90°. Stores each one's
 * prior rotation individually so undo restores exact original angles
 * even if components started at different rotations. */
class RotateComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>
) : Command {
    private val previousRotations: Map<Int, Int> =
        componentIds.associateWith { circuit.componentById(it)?.rotationDegrees ?: 0 }

    override fun execute() {
        componentIds.forEach { id ->
            circuit.componentById(id)?.let { it.rotationDegrees = (it.rotationDegrees + 90) % 360 }
        }
    }

    override fun undo() {
        componentIds.forEach { id ->
            circuit.componentById(id)?.rotationDegrees = previousRotations[id] ?: 0
        }
    }
}

/** Mirrors every component in [componentIds]. Mirroring is its own
 * inverse, so undo can just re-run execute(). */
class MirrorComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>
) : Command {
    override fun execute() {
        componentIds.forEach { id -> circuit.componentById(id)?.let { it.mirrored = !it.mirrored } }
    }
    override fun undo() = execute()
}

/** Bundles any number of commands into a single undo/redo step. Used for
 * paste, duplicate, and every bulk-delete action, so one tap on "undo"
 * always reverses the whole user-visible action rather than one
 * sub-step of it. */
class CompositeCommand(private val commands: List<Command>) : Command {
    override fun execute() {
        commands.forEach { it.execute() }
    }
    override fun undo() {
        commands.asReversed().forEach { it.undo() }
    }
}
