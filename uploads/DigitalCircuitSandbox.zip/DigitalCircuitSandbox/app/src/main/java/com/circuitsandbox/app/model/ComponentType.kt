package com.circuitsandbox.app.model

/**
 * Every component type implemented in this milestone.
 *
 * IMPORTANT: ordinal order must exactly mirror `GateType` in
 * `cpp/core/gate_types.h` — the integer ordinal crosses the JNI boundary
 * as a raw Int, so reordering this enum without also touching the native
 * side will silently corrupt simulation behaviour.
 *
 * The full component-library categories from the product spec (memory,
 * arithmetic, displays, custom modules, etc.) are intentionally not part
 * of this milestone — see the project README for the build roadmap.
 */
enum class ComponentType(
    val displayName: String,
    val category: ComponentCategory,
    val inputCount: Int,
    val outputCount: Int,
    val description: String,
    val truthTable: List<Pair<List<Boolean>, List<Boolean>>>
) {
    INPUT_SWITCH(
        "Switch", ComponentCategory.BASIC, 0, 1,
        "A manual toggle. Tap it while the simulation is running to flip its output between HIGH and LOW.",
        emptyList()
    ),
    PUSH_BUTTON(
        "Push Button", ComponentCategory.BASIC, 0, 1,
        "Outputs HIGH only while pressed, and LOW otherwise.",
        emptyList()
    ),
    POWER(
        "Power", ComponentCategory.BASIC, 0, 1,
        "A constant logic HIGH (1) source.",
        listOf(emptyList<Boolean>() to listOf(true))
    ),
    GROUND(
        "Ground", ComponentCategory.BASIC, 0, 1,
        "A constant logic LOW (0) source.",
        listOf(emptyList<Boolean>() to listOf(false))
    ),
    CLOCK(
        "Clock", ComponentCategory.BASIC, 0, 1,
        "Automatically toggles its output HIGH and LOW at a steady rate once the simulation is running.",
        emptyList()
    ),
    OUTPUT_LED(
        "LED", ComponentCategory.BASIC, 1, 0,
        "Lights up while its input is HIGH.",
        listOf(listOf(false) to emptyList(), listOf(true) to emptyList())
    ),
    AND(
        "AND", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH only when every input is HIGH.",
        listOf(
            listOf(false, false) to listOf(false),
            listOf(false, true) to listOf(false),
            listOf(true, false) to listOf(false),
            listOf(true, true) to listOf(true)
        )
    ),
    OR(
        "OR", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH when at least one input is HIGH.",
        listOf(
            listOf(false, false) to listOf(false),
            listOf(false, true) to listOf(true),
            listOf(true, false) to listOf(true),
            listOf(true, true) to listOf(true)
        )
    ),
    XOR(
        "XOR", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH when an odd number of inputs are HIGH.",
        listOf(
            listOf(false, false) to listOf(false),
            listOf(false, true) to listOf(true),
            listOf(true, false) to listOf(true),
            listOf(true, true) to listOf(false)
        )
    ),
    XNOR(
        "XNOR", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH when an even number of inputs are HIGH.",
        listOf(
            listOf(false, false) to listOf(true),
            listOf(false, true) to listOf(false),
            listOf(true, false) to listOf(false),
            listOf(true, true) to listOf(true)
        )
    ),
    NAND(
        "NAND", ComponentCategory.GATES, 2, 1,
        "The inverse of AND — outputs LOW only when every input is HIGH.",
        listOf(
            listOf(false, false) to listOf(true),
            listOf(false, true) to listOf(true),
            listOf(true, false) to listOf(true),
            listOf(true, true) to listOf(false)
        )
    ),
    NOR(
        "NOR", ComponentCategory.GATES, 2, 1,
        "The inverse of OR — outputs HIGH only when every input is LOW.",
        listOf(
            listOf(false, false) to listOf(true),
            listOf(false, true) to listOf(false),
            listOf(true, false) to listOf(false),
            listOf(true, true) to listOf(false)
        )
    ),
    NOT(
        "NOT", ComponentCategory.GATES, 1, 1,
        "Inverts its single input.",
        listOf(listOf(false) to listOf(true), listOf(true) to listOf(false))
    ),
    BUFFER(
        "Buffer", ComponentCategory.GATES, 1, 1,
        "Passes its input straight through, unchanged. Useful for re-amplifying a signal.",
        listOf(listOf(false) to listOf(false), listOf(true) to listOf(true))
    );
}

enum class ComponentCategory(val displayName: String) {
    BASIC("Basic Components"),
    GATES("Logic Gates")
}
