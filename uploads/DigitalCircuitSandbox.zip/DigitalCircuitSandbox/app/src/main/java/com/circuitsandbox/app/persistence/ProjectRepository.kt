package com.circuitsandbox.app.persistence

import com.circuitsandbox.app.model.CircuitModel
import org.json.JSONObject
import java.io.File

/** Local-only project storage. Every project is one `.dcs.json` file under
 * the app's private files directory — nothing here ever touches the
 * network, consistent with the app being fully offline. */
class ProjectRepository(private val baseDir: File) {

    private val projectsDir: File by lazy {
        File(baseDir, "projects").apply { if (!exists()) mkdirs() }
    }

    fun save(name: String, circuit: CircuitModel): File {
        val safeName = name.ifBlank { "untitled" }
        val file = File(projectsDir, "$safeName.dcs.json")
        file.writeText(CircuitSerializer.toJson(circuit).toString(2))
        return file
    }

    fun load(file: File): CircuitModel {
        val text = file.readText()
        return CircuitSerializer.fromJson(JSONObject(text))
    }

    fun listProjects(): List<File> =
        projectsDir.listFiles { f -> f.name.endsWith(".dcs.json") }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun delete(file: File): Boolean = file.delete()

    fun autoSavePath(): File = File(projectsDir, "_autosave.dcs.json")
}
