package com.circuitsandbox.app.persistence

import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.WireEndpoint
import com.circuitsandbox.app.model.WireInstance
import org.json.JSONArray
import org.json.JSONObject

/**
 * Hand-rolled JSON (de)serialization for [CircuitModel] using `org.json`,
 * which ships with the Android platform. This avoids pulling in a
 * reflection-based serialization library just to save a small project
 * file, which keeps the dependency graph — and the APK — lean.
 */
object CircuitSerializer {

    fun toJson(circuit: CircuitModel): JSONObject {
        val root = JSONObject()
        val componentsArray = JSONArray()
        for (c in circuit.allComponents) {
            componentsArray.put(JSONObject().apply {
                put("id", c.id)
                put("type", c.type.name)
                put("x", c.x)
                put("y", c.y)
                put("rotation", c.rotationDegrees)
                put("mirrored", c.mirrored)
                put("label", c.label ?: JSONObject.NULL)
            })
        }
        val wiresArray = JSONArray()
        for (w in circuit.allWires) {
            wiresArray.put(JSONObject().apply {
                put("id", w.id)
                put("fromComponentId", w.from.componentId)
                put("fromPin", w.from.pinIndex)
                put("toComponentId", w.to.componentId)
                put("toPin", w.to.pinIndex)
            })
        }
        root.put("formatVersion", 1)
        root.put("components", componentsArray)
        root.put("wires", wiresArray)
        return root
    }

    fun fromJson(json: JSONObject): CircuitModel {
        val circuit = CircuitModel()
        val componentsArray = json.optJSONArray("components") ?: JSONArray()
        for (i in 0 until componentsArray.length()) {
            val obj = componentsArray.getJSONObject(i)
            val type = ComponentType.valueOf(obj.getString("type"))
            circuit.addComponent(
                ComponentInstance(
                    id = obj.getInt("id"),
                    type = type,
                    x = obj.getDouble("x").toFloat(),
                    y = obj.getDouble("y").toFloat(),
                    rotationDegrees = obj.optInt("rotation", 0),
                    mirrored = obj.optBoolean("mirrored", false),
                    label = if (obj.isNull("label")) null else obj.optString("label")
                )
            )
        }
        val wiresArray = json.optJSONArray("wires") ?: JSONArray()
        for (i in 0 until wiresArray.length()) {
            val obj = wiresArray.getJSONObject(i)
            circuit.addWire(
                WireInstance(
                    id = obj.getInt("id"),
                    from = WireEndpoint(obj.getInt("fromComponentId"), obj.getInt("fromPin"), isInput = false),
                    to = WireEndpoint(obj.getInt("toComponentId"), obj.getInt("toPin"), isInput = true)
                )
            )
        }
        return circuit
    }
}
