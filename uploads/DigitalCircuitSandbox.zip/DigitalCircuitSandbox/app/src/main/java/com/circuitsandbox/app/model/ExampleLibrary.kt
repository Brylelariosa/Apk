package com.circuitsandbox.app.model

/**
 * Pre-built example circuits that ship with the app.
 *
 * Every [ExampleCircuit.model] with [ExampleCircuit.isAvailable] == true is
 * built entirely from the 14 component types already implemented in the
 * current simulation engine (INPUT_SWITCH, PUSH_BUTTON, POWER, GROUND,
 * CLOCK, OUTPUT_LED, and the eight logic gates). Examples requiring
 * flip-flops, registers, or memory are listed as COMING_SOON.
 *
 * Each builder function is self-contained: it allocates its own
 * [CircuitModel] with local ID counters, so examples can be loaded in any
 * order without ID collisions, and the returned model's counter is already
 * positioned above the highest used ID so user additions won't collide.
 */
object ExampleLibrary {

    val all: List<ExampleCircuit> by lazy { build() }

    private fun build(): List<ExampleCircuit> = listOf(
        ledSwitch(),
        andGate(),
        orGate(),
        notGate(),
        xorGate(),
        halfAdder(),
        clockBlinker(),
        nandAsNot(),
        majorityVote(),
        parityChecker(),
        ExampleCircuit.planned("SR Latch",         Difficulty.INTERMEDIATE, "Two cross-coupled NAND gates. Requires memory — coming in a future update."),
        ExampleCircuit.planned("D Flip-Flop",      Difficulty.INTERMEDIATE, "Edge-triggered data latch. Requires memory — coming in a future update."),
        ExampleCircuit.planned("Binary Counter",    Difficulty.INTERMEDIATE, "4-bit synchronous counter. Requires flip-flops — coming in a future update."),
        ExampleCircuit.planned("Traffic Light",     Difficulty.INTERMEDIATE, "3-phase controller. Requires a counter — coming in a future update."),
        ExampleCircuit.planned("8-bit Adder",      Difficulty.ADVANCED,     "Full adder chain. Coming in a future update."),
        ExampleCircuit.planned("ALU Demo",         Difficulty.ADVANCED,     "Arithmetic logic unit. Coming in a future update."),
        ExampleCircuit.planned("Simple CPU",       Difficulty.ADVANCED,     "Minimal fetch-decode-execute CPU. Coming in a future update.")
    )

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /** Tiny builder state threaded through each circuit factory.
     * Using a class instance (not a global counter) keeps each factory
     * function independent and thread-safe to call. */
    private class Builder {
        private var nextCompId = 1
        private var nextWireId = 1
        fun compId() = nextCompId++
        fun wireId() = nextWireId++

        fun comp(type: ComponentType, x: Float, y: Float, label: String? = null) =
            ComponentInstance(compId(), type, x, y, label = label)

        fun wire(from: ComponentInstance, fromPin: Int = 0,
                 to: ComponentInstance, toPin: Int = 0) =
            WireInstance(wireId(), WireEndpoint(from.id, fromPin, false), WireEndpoint(to.id, toPin, true))
    }

    private fun circuit(
        title: String,
        difficulty: Difficulty,
        description: String,
        howItWorks: String,
        block: Builder.(CircuitModel) -> Unit
    ): ExampleCircuit {
        val builder = Builder()
        val model = CircuitModel()
        builder.block(model)
        return ExampleCircuit(title, difficulty, description, howItWorks, model)
    }

    // -----------------------------------------------------------------------
    // Beginner
    // -----------------------------------------------------------------------

    private fun ledSwitch() = circuit(
        title = "LED Switch",
        difficulty = Difficulty.BEGINNER,
        description = "The simplest possible circuit: a toggle switch driving an LED.",
        howItWorks = "Tap the switch while the simulation is running. Its output pin goes HIGH (1), which lights the LED. Tap again to turn it off."
    ) { m ->
        val sw = comp(ComponentType.INPUT_SWITCH, -160f, 0f, "Switch")
        val led = comp(ComponentType.OUTPUT_LED, 160f, 0f, "LED")
        m.addComponent(sw); m.addComponent(led)
        m.addWire(wire(sw, 0, led, 0))
    }

    private fun andGate() = circuit(
        title = "AND Gate",
        difficulty = Difficulty.BEGINNER,
        description = "Two switches controlling one LED through an AND gate. The LED only lights when BOTH switches are ON.",
        howItWorks = "AND outputs 1 only when every input is 1. Try all four combinations of the two switches to see the truth table in action."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -240f, -70f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -240f,  70f, "B")
        val g = comp(ComponentType.AND,            0f,   0f)
        val led = comp(ComponentType.OUTPUT_LED,  220f,   0f, "A · B")
        listOf(a, b, g, led).forEach { m.addComponent(it) }
        m.addWire(wire(a, 0, g, 0))
        m.addWire(wire(b, 0, g, 1))
        m.addWire(wire(g, 0, led, 0))
    }

    private fun orGate() = circuit(
        title = "OR Gate",
        difficulty = Difficulty.BEGINNER,
        description = "Two switches and an OR gate. The LED lights when EITHER switch (or both) is ON.",
        howItWorks = "OR outputs 1 when at least one input is 1. Compare this with the AND gate demo — the only combination that doesn't light the LED is both inputs OFF."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -240f, -70f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -240f,  70f, "B")
        val g = comp(ComponentType.OR,             0f,   0f)
        val led = comp(ComponentType.OUTPUT_LED, 220f,   0f, "A + B")
        listOf(a, b, g, led).forEach { m.addComponent(it) }
        m.addWire(wire(a, 0, g, 0))
        m.addWire(wire(b, 0, g, 1))
        m.addWire(wire(g, 0, led, 0))
    }

    private fun notGate() = circuit(
        title = "NOT Gate (Inverter)",
        difficulty = Difficulty.BEGINNER,
        description = "A switch and its inverted output side by side. When the switch is ON, the top LED is on and the bottom is off — and vice versa.",
        howItWorks = "NOT (also called an inverter) flips its input. The top LED shows the raw switch state; the bottom LED shows NOT of it."
    ) { m ->
        val sw  = comp(ComponentType.INPUT_SWITCH,  -200f,  0f, "A")
        val buf = comp(ComponentType.BUFFER,          -20f, -70f)   // pass-through for the "A" branch
        val inv = comp(ComponentType.NOT,             -20f,  70f)
        val dA  = comp(ComponentType.OUTPUT_LED,     180f, -70f, "A")
        val dNA = comp(ComponentType.OUTPUT_LED,     180f,  70f, "NOT A")
        listOf(sw, buf, inv, dA, dNA).forEach { m.addComponent(it) }
        m.addWire(wire(sw, 0, buf, 0))
        m.addWire(wire(sw, 0, inv, 0))
        m.addWire(wire(buf, 0, dA,  0))
        m.addWire(wire(inv, 0, dNA, 0))
    }

    private fun xorGate() = circuit(
        title = "XOR Gate",
        difficulty = Difficulty.BEGINNER,
        description = "XOR (Exclusive-OR): the LED lights when the two switches DIFFER. When both are ON or both are OFF, the LED stays dark.",
        howItWorks = "XOR outputs 1 when an odd number of inputs are 1. With two inputs this means 'one or the other but not both' — perfect for detecting differences."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -240f, -70f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -240f,  70f, "B")
        val g = comp(ComponentType.XOR,            0f,   0f)
        val led = comp(ComponentType.OUTPUT_LED, 220f,   0f, "A ⊕ B")
        listOf(a, b, g, led).forEach { m.addComponent(it) }
        m.addWire(wire(a, 0, g, 0))
        m.addWire(wire(b, 0, g, 1))
        m.addWire(wire(g, 0, led, 0))
    }

    // -----------------------------------------------------------------------
    // Intermediate
    // -----------------------------------------------------------------------

    private fun halfAdder() = circuit(
        title = "Half Adder",
        difficulty = Difficulty.INTERMEDIATE,
        description = "Adds two 1-bit numbers. The XOR output is the Sum and the AND output is the Carry-out. This is the building block of all binary arithmetic.",
        howItWorks = "0+0=00, 0+1=01, 1+0=01, 1+1=10. Notice the Sum LED and Carry LED together give you the binary result. Chain two of these (with a Full Adder) to add wider numbers."
    ) { m ->
        val a    = comp(ComponentType.INPUT_SWITCH, -240f,  0f,   "A")
        val b    = comp(ComponentType.INPUT_SWITCH, -240f, 120f,  "B")
        val xor  = comp(ComponentType.XOR,            0f,  0f)
        val and  = comp(ComponentType.AND,             0f, 120f)
        val sum  = comp(ComponentType.OUTPUT_LED,   220f,  0f,   "Sum")
        val carry= comp(ComponentType.OUTPUT_LED,   220f, 120f,  "Carry")
        listOf(a, b, xor, and, sum, carry).forEach { m.addComponent(it) }
        m.addWire(wire(a,   0, xor,  0))
        m.addWire(wire(b,   0, xor,  1))
        m.addWire(wire(a,   0, and,  0))
        m.addWire(wire(b,   0, and,  1))
        m.addWire(wire(xor, 0, sum,  0))
        m.addWire(wire(and, 0, carry,0))
    }

    private fun clockBlinker() = circuit(
        title = "Clock Blinker",
        difficulty = Difficulty.INTERMEDIATE,
        description = "A clock generator connected to an LED. Start the simulation to see the LED flash at the clock's rate.",
        howItWorks = "The Clock component automatically toggles HIGH/LOW each simulation tick. Adjust the simulation speed with the FAB — faster speed = faster blink. This is the heartbeat of every sequential circuit."
    ) { m ->
        val clk = comp(ComponentType.CLOCK,        -120f, 0f, "CLK")
        val led = comp(ComponentType.OUTPUT_LED,   120f,  0f, "Pulse")
        m.addComponent(clk); m.addComponent(led)
        m.addWire(wire(clk, 0, led, 0))
    }

    private fun nandAsNot() = circuit(
        title = "NAND as NOT",
        difficulty = Difficulty.INTERMEDIATE,
        description = "A NAND gate wired as an inverter by tying both inputs together. This demonstrates that NAND is a universal gate — you can build any logic function from NAND gates alone.",
        howItWorks = "When both NAND inputs get the same value, NAND(A,A) = NOT(A·A) = NOT(A). Toggle the switch: the LED shows the opposite state, just like a NOT gate — but built from a NAND."
    ) { m ->
        val sw  = comp(ComponentType.INPUT_SWITCH, -220f, 0f, "A")
        val nand= comp(ComponentType.NAND,           0f,  0f)
        val led = comp(ComponentType.OUTPUT_LED,   220f,  0f, "NOT A")
        listOf(sw, nand, led).forEach { m.addComponent(it) }
        // Both NAND inputs tied to the same switch output
        m.addWire(wire(sw, 0, nand, 0))
        m.addWire(wire(sw, 0, nand, 1))
        m.addWire(wire(nand, 0, led, 0))
    }

    private fun majorityVote() = circuit(
        title = "Majority Vote (3-input)",
        difficulty = Difficulty.INTERMEDIATE,
        description = "The LED lights when 2 or more of the 3 inputs are HIGH — a democratic majority vote circuit.",
        howItWorks = "Logic: (A·B) + (B·C) + (A·C). Each AND gate detects one of the three 'agree' pairs; the OR tree combines them. Useful in fault-tolerant systems where at least two of three sensors must agree."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -320f, -80f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -320f,   0f, "B")
        val c = comp(ComponentType.INPUT_SWITCH, -320f,  80f, "C")

        val ab = comp(ComponentType.AND,  -120f, -100f)
        val bc = comp(ComponentType.AND,  -120f,    0f)
        val ac = comp(ComponentType.AND,  -120f,  100f)

        val or1 = comp(ComponentType.OR,  80f, -50f)
        val or2 = comp(ComponentType.OR, 220f,  25f)
        val led = comp(ComponentType.OUTPUT_LED, 380f, 25f, "Majority")

        listOf(a, b, c, ab, bc, ac, or1, or2, led).forEach { m.addComponent(it) }

        // Feed inputs into AND pairs
        m.addWire(wire(a, 0, ab, 0)); m.addWire(wire(b, 0, ab, 1))
        m.addWire(wire(b, 0, bc, 0)); m.addWire(wire(c, 0, bc, 1))
        m.addWire(wire(a, 0, ac, 0)); m.addWire(wire(c, 0, ac, 1))

        // Two-stage OR tree
        m.addWire(wire(ab, 0, or1, 0)); m.addWire(wire(bc, 0, or1, 1))
        m.addWire(wire(or1, 0, or2, 0)); m.addWire(wire(ac, 0, or2, 1))
        m.addWire(wire(or2, 0, led, 0))
    }

    // -----------------------------------------------------------------------
    // Advanced
    // -----------------------------------------------------------------------

    private fun parityChecker() = circuit(
        title = "4-bit Parity Checker",
        difficulty = Difficulty.ADVANCED,
        description = "Computes the XOR of 4 bits. The LED lights when an ODD number of inputs are HIGH — this is the parity bit used in error-detection codes.",
        howItWorks = "XOR is associative: A⊕B⊕C⊕D = ((A⊕B)⊕C)⊕D. This is called even parity checking — the combined output is 1 when the data has odd parity, which is exactly the bit you'd append to a 4-bit word to make it always even parity."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -360f, -120f, "D0")
        val b = comp(ComponentType.INPUT_SWITCH, -360f,  -40f, "D1")
        val c = comp(ComponentType.INPUT_SWITCH, -360f,   40f, "D2")
        val d = comp(ComponentType.INPUT_SWITCH, -360f,  120f, "D3")

        val x1 = comp(ComponentType.XOR, -160f, -80f)   // A⊕B
        val x2 = comp(ComponentType.XOR, -160f,  80f)   // C⊕D
        val x3 = comp(ComponentType.XOR,   40f,   0f)   // (A⊕B)⊕(C⊕D)
        val led = comp(ComponentType.OUTPUT_LED, 240f,   0f, "Parity")

        listOf(a, b, c, d, x1, x2, x3, led).forEach { m.addComponent(it) }
        m.addWire(wire(a,  0, x1, 0)); m.addWire(wire(b, 0, x1, 1))
        m.addWire(wire(c,  0, x2, 0)); m.addWire(wire(d, 0, x2, 1))
        m.addWire(wire(x1, 0, x3, 0)); m.addWire(wire(x2, 0, x3, 1))
        m.addWire(wire(x3, 0, led, 0))
    }
}
