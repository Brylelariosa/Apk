// Root build file. Per-module configuration lives in app/build.gradle.kts.
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
