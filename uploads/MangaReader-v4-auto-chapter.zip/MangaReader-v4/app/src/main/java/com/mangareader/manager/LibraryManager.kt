package com.mangareader.manager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mangareader.data.Chapter
import com.mangareader.data.Series
import com.mangareader.parser.ChapterParser
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipInputStream

class LibraryManager(private val context: Context) {

    private val prefs       = context.getSharedPreferences("manga_library", Context.MODE_PRIVATE)
    private val gson        = Gson()
    private val mhtmlParser = MhtmlParser(context)

    /**
     * In-memory series list. Avoids Gson deserialisation on every [getAllSeries]
     * call — which happened once per card during library composition.
     * Invalidated (set to null) whenever the list changes.
     */
    @Volatile private var seriesCache: List<Series>? = null

    // ── Read / Write ──────────────────────────────────────────────────────────

    fun getAllSeries(): List<Series> {
        seriesCache?.let { return it }
        val json = prefs.getString("series_list", "[]") ?: "[]"
        val type = object : TypeToken<List<Series>>() {}.type
        val loaded = runCatching {
            gson.fromJson<List<Series>>(json, type) ?: emptyList()
        }.getOrDefault(emptyList())
        seriesCache = loaded
        return loaded
    }

    fun saveSeries(series: Series) {
        seriesCache = null                      // invalidate before write
        val list = getAllSeries().toMutableList()
        val idx  = list.indexOfFirst { it.id == series.id }
        if (idx >= 0) list[idx] = series else list.add(series)
        prefs.edit().putString("series_list", gson.toJson(list)).apply()
        seriesCache = null                      // invalidate after write too
    }

    fun deleteSeries(seriesId: String) {
        seriesCache = null
        val list = getAllSeries().filter { it.id != seriesId }
        prefs.edit().putString("series_list", gson.toJson(list)).apply()
        seriesCache = null

        // Wipe extracted/cached images
        File(context.cacheDir, "manga/$seriesId").deleteRecursively()
        File(context.filesDir, "zips/$seriesId").deleteRecursively()
        thumbnailFile(seriesId).delete()

        // Release the persistable URI permission for folder-based series so
        // the OS can clean up after us (best-effort; may already be gone).
        getAllSeries()   // re-read so we don't try releasing permissions we never had
    }

    // ── Library cover thumbnails ──────────────────────────────────────────────

    fun thumbnailFile(seriesId: String): File = File(context.cacheDir, "thumbs/$seriesId.jpg")

    /**
     * Returns a cover thumbnail for [series], generating it the first time.
     * Generation decodes only the first usable page of the first chapter at a
     * small downsampled size, so it's cheap even for large libraries.
     */
    suspend fun ensureThumbnail(series: Series): File? = withContext(Dispatchers.IO) {
        val file = thumbnailFile(series.id)
        if (file.exists() && file.length() > 0) return@withContext file

        val firstChapter = series.chapters.firstOrNull() ?: return@withContext null
        val ok = runCatching {
            mhtmlParser.extractFirstPageThumbnail(firstChapter.mhtmlPath, file)
        }.getOrDefault(false)

        if (ok) file else null
    }

    // ── Add from SAF folder ───────────────────────────────────────────────────

    /**
     * Imports one or more series from a folder tree.
     *
     * If the selected folder has sub-folders that each contain .mhtml/.mht
     * files, each sub-folder becomes its own Series (multi-series mode).
     * Otherwise the selected folder itself is treated as a single Series.
     *
     * Re-picking a folder that's already the source of an existing Series
     * (a common way to manually check for new chapters) merges into that
     * Series instead of creating a duplicate — see [addOrRefreshFromDocFile].
     */
    suspend fun addFolder(treeUri: Uri): List<Series> = withContext(Dispatchers.IO) {
        context.contentResolver.takePersistableUriPermission(
            treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
        )

        val docFile = DocumentFile.fromTreeUri(context, treeUri)
            ?: error("Cannot open folder: $treeUri")

        val seriesDirs = docFile.listFiles()
            .filter { f ->
                f.isDirectory && f.listFiles().any { sf ->
                    val n = sf.name?.lowercase() ?: ""
                    sf.isFile && (n.endsWith(".mhtml") || n.endsWith(".mht"))
                }
            }
            .sortedBy { it.name }

        if (seriesDirs.isNotEmpty()) {
            seriesDirs.map { dir -> addOrRefreshFromDocFile(dir) }
        } else {
            listOf(addOrRefreshFromDocFile(docFile, sourceFolderUri = treeUri.toString()))
        }
    }

    /**
     * Imports [docFile] as a new Series — unless a Series already has this
     * exact folder as its [Series.sourceFolderUri], in which case the
     * existing Series is updated in place instead: files already known keep
     * their original [Chapter.id] (so reading progress stays valid), and
     * only genuinely new files become new chapters. Nothing is ever
     * re-added or duplicated, no matter how many times the same folder is
     * picked.
     */
    private fun addOrRefreshFromDocFile(
        docFile: DocumentFile,
        sourceFolderUri: String? = null
    ): Series {
        val folderUri = sourceFolderUri ?: docFile.uri.toString()
        val existing   = getAllSeries().find { it.sourceFolderUri == folderUri }
        val seriesId   = existing?.id ?: UUID.randomUUID().toString()

        val mhtmlFiles = docFile.listFiles()
            .filter { f ->
                val name = f.name?.lowercase() ?: ""
                f.isFile && (name.endsWith(".mhtml") || name.endsWith(".mht"))
            }
            .sortedWith(Comparator { a, b ->
                ChapterParser.byNumber.compare(a.name ?: "", b.name ?: "")
            })

        val chapters = mergeChapters(mhtmlFiles, existing?.chapters.orEmpty(), seriesId)

        val series = existing?.copy(chapters = chapters) ?: Series(
            id              = seriesId,
            title           = ChapterParser.extractSeriesName(docFile.name ?: "Manga"),
            sourceFolderUri = folderUri,
            chapters        = chapters
        )
        saveSeries(series)
        return series
    }

    /**
     * Builds a chapter list from [mhtmlFiles]: files whose content URI
     * already appears in [existingChapters] keep that chapter's id (title
     * and number are recomputed in case the filename changed), and any file
     * not already present becomes a brand-new [Chapter]. Files that were
     * previously imported but are no longer present on disk are dropped.
     *
     * Shared by [addOrRefreshFromDocFile] and [refreshSeries] so the two
     * import paths can't drift apart.
     */
    private fun mergeChapters(
        mhtmlFiles: List<DocumentFile>,
        existingChapters: List<Chapter>,
        seriesId: String
    ): List<Chapter> {
        val existingByPath = existingChapters.associateBy { it.mhtmlPath }
        return mhtmlFiles.mapIndexed { i, file ->
            val uriStr = file.uri.toString()
            existingByPath[uriStr]?.copy(
                title  = ChapterParser.formatTitle(file.name ?: "Chapter ${i + 1}"),
                number = ChapterParser.extractNumber(file.name ?: "${i + 1}")
            ) ?: Chapter(
                title     = ChapterParser.formatTitle(file.name ?: "Chapter ${i + 1}"),
                number    = ChapterParser.extractNumber(file.name ?: "${i + 1}"),
                mhtmlPath = uriStr,
                seriesId  = seriesId
            )
        }
    }

    // ── Add from ZIP ──────────────────────────────────────────────────────────

    suspend fun addZip(zipUri: Uri): Series = withContext(Dispatchers.IO) {
        val seriesId   = UUID.randomUUID().toString()
        val extractDir = File(context.filesDir, "zips/$seriesId").also { it.mkdirs() }

        val displayName = context.contentResolver.query(
            zipUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Manga"

        val seriesTitle = ChapterParser.extractSeriesName(displayName)

        // Extract MHTML files; clean up the whole dir if anything goes wrong
        // so we never leave a half-written series on disk.
        val extracted = mutableListOf<File>()
        runCatching {
            context.contentResolver.openInputStream(zipUri)?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val name = entry.name.substringAfterLast("/")
                        if (!entry.isDirectory &&
                            (name.lowercase().endsWith(".mhtml") || name.lowercase().endsWith(".mht"))
                        ) {
                            val out = File(extractDir, name)
                            out.outputStream().use { o -> zip.copyTo(o) }
                            extracted.add(out)
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }
        }.onFailure { e ->
            extractDir.deleteRecursively()   // clean up partial extraction
            throw e
        }

        if (extracted.isEmpty()) {
            extractDir.deleteRecursively()
            error("No .mhtml or .mht files found in the ZIP")
        }

        val sorted = extracted.sortedWith(Comparator { a, b ->
            ChapterParser.byNumber.compare(a.name, b.name)
        })

        val chapters = sorted.mapIndexed { i, file ->
            Chapter(
                title     = ChapterParser.formatTitle(file.name),
                number    = ChapterParser.extractNumber(file.name),
                mhtmlPath = file.absolutePath,
                seriesId  = seriesId
            )
        }

        val series = Series(
            id           = seriesId,
            title        = seriesTitle,
            sourceZipUri = zipUri.toString(),
            chapters     = chapters
        )
        saveSeries(series)
        series
    }

    // ── Refresh (rescan folder for new chapters) ──────────────────────────────

    /**
     * Re-scans [series]'s source folder and merges in any new chapters via
     * [mergeChapters] — a no-op if nothing changed on disk, so it's safe to
     * call this every time (e.g. whenever the chapter list is opened, not
     * just when the user manually taps refresh). No-ops entirely for
     * ZIP-backed series, which have no folder to watch.
     */
    suspend fun refreshSeries(series: Series): Series = withContext(Dispatchers.IO) {
        val uriStr  = series.sourceFolderUri ?: return@withContext series
        val treeUri = Uri.parse(uriStr)
        val docFile = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext series

        val mhtmlFiles = docFile.listFiles()
            .filter { f ->
                val name = f.name?.lowercase() ?: ""
                f.isFile && (name.endsWith(".mhtml") || name.endsWith(".mht"))
            }
            .sortedWith(Comparator { a, b ->
                ChapterParser.byNumber.compare(a.name ?: "", b.name ?: "")
            })

        val updated = series.copy(chapters = mergeChapters(mhtmlFiles, series.chapters, series.id))
        saveSeries(updated)
        updated
    }
}
