package com.game.topdown;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    /** Force font scale = 1.0 so system "Large font" never affects the UI. */
    @Override
    protected void attachBaseContext(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = 1.0f;
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    private EditText nameInput, ipInput;
    private Button   hostBtn, scanBtn, joinIpBtn;
    private ListView hostList;
    private TextView statusText;

    private final List<String[]>  hosts   = new ArrayList<>();   // {ip, name}
    private ArrayAdapter<String>  adapter;
    private final Handler         handler = new Handler(Looper.getMainLooper());
    private NetworkManager        scanner;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        nameInput  = findViewById(R.id.nameInput);
        ipInput    = findViewById(R.id.ipInput);
        hostBtn    = findViewById(R.id.hostBtn);
        scanBtn    = findViewById(R.id.scanBtn);
        joinIpBtn  = findViewById(R.id.joinIpBtn);
        hostList   = findViewById(R.id.hostList);
        statusText = findViewById(R.id.statusText);

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>());
        hostList.setAdapter(adapter);

        hostBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            launch(n, true, null);
        });

        joinIpBtn.setOnClickListener(v -> {
            String n  = name();          if (n  == null) return;
            String ip = ipInput.getText().toString().trim();
            if (ip.isEmpty()) { status("Enter or select a host IP"); return; }
            launch(n, false, ip);
        });

        scanBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            scan();
        });

        // Tap a discovered host → auto-fill IP field and highlight JOIN button
        hostList.setOnItemClickListener((p, v, pos, id) -> {
            String ip = hosts.get(pos)[0];
            ipInput.setText(ip);
            joinIpBtn.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.parseColor("#2ecc71")));
            status("Tap JOIN to connect to " + hosts.get(pos)[1] + " (" + ip + ")");
        });
    }

    // ── Scan ──────────────────────────────────────────────────────────────────
    private void scan() {
        hosts.clear(); adapter.clear();
        scanBtn.setEnabled(false);
        status("Scanning your Wi-Fi…");

        if (scanner != null) scanner.stop();
        scanner = new NetworkManager(new NetworkManager.Callback() {
            @Override public void onHostDiscovered(String ip, String hn) {
                handler.post(() -> {
                    for (String[] h : hosts) if (h[0].equals(ip)) return;
                    hosts.add(new String[]{ip, hn});
                    adapter.add("▶  " + hn + "  —  " + ip);
                    status("Found " + hosts.size() + " game(s). Tap one, then JOIN.");
                });
            }
            @Override public void onJoined(int i){}
            @Override public void onPlayerJoined(int i, String n){}
            @Override public void onStateUpdate(String j){}
            @Override public void onInputReceived(int i, String j){}
        });
        scanner.discoverHosts(3000);

        handler.postDelayed(() -> {
            scanBtn.setEnabled(true);
            if (hosts.isEmpty())
                status("No games found. Ask host for IP and type it above.");
        }, 3500);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private String name() {
        String s = nameInput.getText().toString().trim();
        if (s.isEmpty()) { status("Enter your name first!"); return null; }
        return s;
    }

    private void status(String msg) { statusText.setText(msg); }

    private void launch(String name, boolean host, String ip) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name);
        i.putExtra("isHost", host);
        if (ip != null) i.putExtra("hostIp", ip);
        startActivity(i);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (scanner != null) scanner.stop();
    }
}
