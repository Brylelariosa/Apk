package com.immortalascension

import kotlin.random.Random

// The heavens resist abnormal cultivators.
// Every Foundation+ breakthrough triggers a tribulation.
// The fateless path and forbidden inheritances make tribulations heavier.

data class TribulationWave(
    val number: Int,
    val desc: String,
    val damage: Int,
    val qiDrain: Int = 0,
    val daoHeartDamage: Int = 0
)

data class TribulationResult(
    val survived: Boolean,
    val waves: List<TribulationWave>,
    val totalDamage: Int,
    val perfectSurvivor: Boolean,   // survived all waves with >50% HP
    val newTitle: String = ""
)

object TribulationSystem {

    // Tribulation fires for Foundation and above breakthroughs
    fun shouldTrigger(newRealm: Realm, player: Player): Boolean {
        return when (newRealm.tier) {
            RealmTier.MORTAL, RealmTier.QI_GATHERING -> false
            RealmTier.FOUNDATION                     -> true
            else                                     -> true
        }
    }

    fun generate(newRealm: Realm, player: Player): List<TribulationWave> {
        val waveCount = when (newRealm.tier) {
            RealmTier.FOUNDATION    -> 3
            RealmTier.CORE_FORMATION-> 5
            RealmTier.NASCENT_SOUL  -> 7
            RealmTier.SPIRIT_SEVERING -> 9
            else -> 1
        }

        val heavinessMultiplier = heavinessFor(player)
        val waves = mutableListOf<TribulationWave>()

        repeat(waveCount) { i ->
            waves += generateWave(i + 1, waveCount, newRealm, heavinessMultiplier, player)
        }
        return waves
    }

    private fun heavinessFor(player: Player): Float {
        var mult = 1.0f
        if (player.fateless)              mult += 0.5f    // fateless = heavier tribulation
        if (player.isDemonicPath())       mult += 0.4f
        if (player.daoPath == "Destruction Dao") mult += 0.3f
        if (player.titles.any { it.contains("Forbidden") || it.contains("Demonic") }) mult += 0.25f
        if (player.innerDemonLevel > 60)  mult += 0.2f
        if (player.daoHeart > 80)         mult -= 0.2f   // high dao heart reduces it
        return mult.coerceIn(0.5f, 2.5f)
    }

    private fun generateWave(
        waveNum: Int, totalWaves: Int,
        realm: Realm, heaviness: Float, player: Player
    ): TribulationWave {
        val basePercent = 0.08f + (waveNum.toFloat() / totalWaves) * 0.15f
        val dmg = (player.maxHp * basePercent * heaviness).toInt().coerceAtLeast(5)
        val qi  = if (waveNum == totalWaves) player.maxQi / 3 else 0
        val daoHit = if (waveNum > totalWaves / 2) (3 * heaviness).toInt() else 0

        val descs = when {
            waveNum == 1 -> listOf(
                "Tribulation clouds gather overhead. The first bolt descends.",
                "Heaven stirs. A single arc of divine lightning strikes.",
                "The sky darkens. The first wave of heaven's judgment falls."
            )
            waveNum == totalWaves -> listOf(
                "The final wave. Heaven pours everything it has into this last bolt.",
                "The tribulation's last strike descends — a column of pure divine judgment.",
                "One final lightning arc, wider than before. Heaven's patience has run out."
            )
            waveNum > totalWaves / 2 -> listOf(
                "Wave $waveNum. The lightning carries hatred now.",
                "The tribulation intensifies. Heaven has noticed you.",
                "Wave $waveNum. Reality cracks where the lightning touches."
            )
            else -> listOf(
                "Wave $waveNum descends.",
                "Another arc. The burns from the previous strike haven't healed.",
                "The tribulation continues without pause."
            )
        }

        return TribulationWave(waveNum, descs.random(), dmg, qi, daoHit)
    }

    // ── RESOLVE TRIBULATION ───────────────────────────────────────────────────

    fun resolve(player: Player, waves: List<TribulationWave>): TribulationResult {
        val startHp = player.hp
        var totalDmg = 0
        val survivedWaves = mutableListOf<TribulationWave>()

        for (wave in waves) {
            // Dao Heart partially resists tribulation
            val resistance = (player.daoHeart / 200f).coerceIn(0f, 0.4f)
            val actualDmg  = (wave.damage * (1f - resistance)).toInt().coerceAtLeast(1)

            player.hp -= actualDmg
            if (wave.qiDrain > 0) player.qi = (player.qi - wave.qiDrain).coerceAtLeast(0)
            if (wave.daoHeartDamage > 0)
                player.daoHeart = (player.daoHeart - wave.daoHeartDamage).coerceAtLeast(0)

            totalDmg += actualDmg
            survivedWaves.add(wave)

            if (player.hp <= 0) {
                player.hp = 1   // tribulation can't kill you outright — only cripple
                return TribulationResult(
                    survived = false,
                    waves = survivedWaves,
                    totalDamage = totalDmg,
                    perfectSurvivor = false
                )
            }
        }

        val perfect = player.hp > startHp * 0.5f
        val newTitle = when {
            perfect && player.fateless -> "Fateless Tribulation Survivor"
            perfect && waves.size >= 7 -> "Heaven's Defiance"
            perfect                    -> "Tribulation Endured"
            else                       -> ""
        }
        if (newTitle.isNotEmpty() && !player.titles.contains(newTitle))
            player.titles.add(newTitle)

        return TribulationResult(
            survived = true,
            waves = survivedWaves,
            totalDamage = totalDmg,
            perfectSurvivor = perfect,
            newTitle = newTitle
        )
    }

    // ── NARRATIVE ─────────────────────────────────────────────────────────────

    fun buildNarrative(realm: Realm, result: TribulationResult, player: Player): String = buildString {
        appendLine("━━━ HEAVENLY TRIBULATION ━━━")
        appendLine("You have grown beyond what heaven permits quietly.")
        appendLine("${result.waves.size} waves descend.")
        appendLine()
        result.waves.forEach { w ->
            appendLine("Wave ${w.number}: ${w.desc}")
            appendLine("  Damage: ${w.damage}${if (w.qiDrain > 0) "  Qi drained: ${w.qiDrain}" else ""}")
        }
        appendLine()
        if (result.survived) {
            if (result.perfectSurvivor) {
                appendLine("★ You stand unbroken. The heavens grow silent.")
                appendLine("Heaven cannot stop you. It can only make the price higher.")
            } else {
                appendLine("You survive. Barely.")
                appendLine("The tribulation scars do not fade quickly.")
            }
            if (result.newTitle.isNotEmpty()) appendLine("New title: 「${result.newTitle}」")
        } else {
            appendLine("The tribulation overwhelms you. Your breakthrough is disrupted.")
            appendLine("You remain at your current realm, clinging to life.")
        }
        appendLine()
        appendLine("Remaining HP: ${player.hp}/${player.maxHp}")
    }.trim()

    private fun Player.isDemonicPath() =
        titles.any { it.contains("Demonic") || it.contains("Demon") } || innerDemonLevel > 70
}
