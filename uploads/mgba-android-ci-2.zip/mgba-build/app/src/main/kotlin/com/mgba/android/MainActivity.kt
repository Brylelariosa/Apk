package com.mgba.android

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    // ── Views ────────────────────────────────────────────────────────────────
    private lateinit var surfaceView: SurfaceView
    private lateinit var loadRomBtn: Button
    private var surfaceHolder: SurfaceHolder? = null

    // ── Game loop ────────────────────────────────────────────────────────────
    private var gameThread: Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    private var frameBitmap: Bitmap? = null
    private val gameMatrix = Matrix()

    // ── Input ────────────────────────────────────────────────────────────────
    private val currentKeys = AtomicInteger(0)

    // ── Controller layout ────────────────────────────────────────────────────
    private val buttons     = mutableListOf<ButtonDef>()
    private var controlsTop = 0f

    // ── ROM picker (guard flag prevents double-launch on fast taps) ──────────
    @Volatile private var pickerLive = false

    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult

        // File copy + native init must NOT block the UI thread.
        Thread {
            /*
             * FIX 1 — catch Throwable, not Exception.
             *
             * System.loadLibrary("mgba-jni") is called lazily on the first
             * non-const access to EmulatorEngine (here: nativeLoadROM).
             * If the library cannot be found — wrong ABI, compressed .so
             * without extractNativeLibs=true, missing file — it throws
             * UnsatisfiedLinkError.  That class extends LinkageError →
             * Error → Throwable.  It is NOT an Exception, so the original
             * "catch (e: Exception)" block was completely bypassed,
             * the background thread died with an uncaught Error, and
             * Android's default uncaught-exception handler killed the process.
             */
            try {
                val tmp = cacheDir.resolve("rom_loaded.gba")

                contentResolver.openInputStream(uri)?.use { ins ->
                    tmp.outputStream().use { out -> ins.copyTo(out) }
                } ?: run {
                    uiToast("Cannot read selected file")
                    return@Thread
                }

                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath)

                Handler(Looper.getMainLooper()).post {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth()
                        val h = EmulatorEngine.nativeGetHeight()
                        frameBitmap = Bitmap.createBitmap(
                            w.coerceAtLeast(1), h.coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        romLoaded = true
                        loadRomBtn.visibility = View.GONE
                        startGameLoop()
                    } else {
                        uiToast("Unsupported ROM format")
                    }
                }
            } catch (e: Throwable) {           // FIX 1: was "catch (e: Exception)"
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)

        // Game surface fills everything
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        // "Load ROM" button — a real View so we get proper click handling
        loadRomBtn = Button(this).apply {
            text = "▶  Load ROM"
            setBackgroundColor(Color.parseColor("#BB86FC"))
            setTextColor(Color.BLACK)
            textSize = 16f
            setOnClickListener {
                if (!pickerLive) {
                    pickerLive = true
                    romPicker.launch(arrayOf("*/*"))
                }
            }
        }
        root.addView(loadRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.CENTER })

        setContentView(root)

        // Touch events on the surface are only used for in-game controls
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }

        setImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        EmulatorEngine.nativeDestroy()
    }

    // ── SurfaceHolder.Callback ───────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceHolder = holder
    }

    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) {
            updateGameMatrix(w.toFloat(), h.toFloat())
            /*
             * FIX 2 — restart the game loop if the surface was destroyed and
             * recreated (e.g. app backgrounded then foregrounded) while a ROM
             * was already loaded.  Previously, surfaceChanged only called
             * updateGameMatrix, leaving the loop permanently stopped after a
             * surface-destroy / surface-create cycle.
             */
            if (!running) startGameLoop()
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        stopGameLoop()
        surfaceHolder = null
    }

    // ── Game loop ────────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bmp    = frameBitmap    ?: return
        val holder = surfaceHolder  ?: return

        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) {
            buildControlLayout(sw, sh)
            updateGameMatrix(sw, sh)
        }

        running = true
        gameThread = Thread {
            val targetNs = 1_000_000_000L / 60
            while (running) {
                /*
                 * FIX 3 — wrap the frame body so that a Java-level exception
                 * from native glue (e.g. AndroidBitmap errors surfaced as JNI
                 * exceptions) or an InterruptedException from Thread.sleep
                 * does not silently kill the loop thread, leaving the UI
                 * frozen with no error message.
                 *
                 * Note: a native SIGSEGV still kills the process — that is
                 * unavoidable from the Kotlin side and must be fixed in C.
                 */
                try {
                    val t0 = System.nanoTime()
                    EmulatorEngine.nativeSetKeys(currentKeys.get())
                    EmulatorEngine.nativeRunFrame(bmp)
                    renderFrame(bmp)
                    val elapsed = System.nanoTime() - t0
                    val sleep   = (targetNs - elapsed) / 1_000_000L
                    if (sleep > 0L) Thread.sleep(sleep)
                } catch (_: InterruptedException) {
                    break
                } catch (e: Throwable) {
                    Log.e(TAG, "Game loop error — stopping", e)
                    uiToast("Emulator error: ${e.message ?: e.javaClass.simpleName}")
                    break
                }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        gameThread?.join(500)
        gameThread = null
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try {
            holder.lockCanvas() ?: return
        } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
        } finally {
            try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
        }
    }

    // ── Scaling matrix ────────────────────────────────────────────────────────

    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp   = frameBitmap ?: return
        val gameH = sh * GAME_FRACTION
        val scale = minOf(sw / bmp.width, gameH / bmp.height)
        val tx    = (sw    - bmp.width  * scale) / 2f
        val ty    = (gameH - bmp.height * scale) / 2f
        gameMatrix.reset()
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(tx, ty)
    }

    // ── On-screen controller ──────────────────────────────────────────────────

    companion object {
        private const val TAG           = "mGBA"
        private const val GAME_FRACTION = 0.52f
    }

    private data class ButtonDef(
        val rect: RectF, val keyMask: Int, val label: String, val color: Int
    )

    private fun buildControlLayout(sw: Float, sh: Float) {
        buttons.clear()
        controlsTop = sh * GAME_FRACTION
        val padH  = sh - controlsTop
        val btnSz = minOf(padH * 0.24f, sw * 0.084f)
        val abSz  = btnSz * 0.94f
        val step  = btnSz * 1.1f

        // D-pad
        val dpCx = sw * 0.18f; val dpCy = controlsTop + padH * 0.52f
        fun pad(dx: Float, dy: Float, m: Int, l: String) = ButtonDef(
            RectF(dpCx+dx-btnSz/2, dpCy+dy-btnSz/2,
                  dpCx+dx+btnSz/2, dpCy+dy+btnSz/2),
            m, l, Color.parseColor("#555566")
        )
        buttons += pad(0f,    -step, EmulatorEngine.KEY_UP,    "▲")
        buttons += pad(0f,    +step, EmulatorEngine.KEY_DOWN,  "▼")
        buttons += pad(-step, 0f,    EmulatorEngine.KEY_LEFT,  "◀")
        buttons += pad(+step, 0f,    EmulatorEngine.KEY_RIGHT, "▶")

        // A / B
        val abCx = sw * 0.82f; val abCy = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        buttons += ButtonDef(
            RectF(abCx+abGap-abSz/2, abCy-abSz/2,
                  abCx+abGap+abSz/2, abCy+abSz/2),
            EmulatorEngine.KEY_A, "A", Color.parseColor("#CF6679"))
        buttons += ButtonDef(
            RectF(abCx-abGap-abSz/2, abCy-abSz/2,
                  abCx-abGap+abSz/2, abCy+abSz/2),
            EmulatorEngine.KEY_B, "B", Color.parseColor("#4FC3F7"))

        // Start / Select
        val ssW = sw * 0.11f; val ssH = sh * 0.038f
        val ssCy = controlsTop + padH * 0.82f; val gap = sw * 0.07f
        buttons += ButtonDef(
            RectF(sw/2f-gap-ssW, ssCy, sw/2f-gap, ssCy+ssH),
            EmulatorEngine.KEY_SELECT, "SEL", Color.parseColor("#444455"))
        buttons += ButtonDef(
            RectF(sw/2f+gap, ssCy, sw/2f+gap+ssW, ssCy+ssH),
            EmulatorEngine.KEY_START,  "STA", Color.parseColor("#444455"))

        // L / R shoulder
        val lrW = sw * 0.13f; val lrH = sh * 0.042f
        val lrY = controlsTop + padH * 0.06f
        buttons += ButtonDef(
            RectF(sw*0.03f, lrY, sw*0.03f+lrW, lrY+lrH),
            EmulatorEngine.KEY_L, "L", Color.parseColor("#444455"))
        buttons += ButtonDef(
            RectF(sw-sw*0.03f-lrW, lrY, sw-sw*0.03f, lrY+lrH),
            EmulatorEngine.KEY_R, "R", Color.parseColor("#444455"))
    }

    private val fillPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return
        fillPaint.color = Color.parseColor("#CC111122")
        canvas.drawRect(
            0f, controlsTop,
            canvas.width.toFloat(), canvas.height.toFloat(),
            fillPaint)

        val keys = currentKeys.get()
        for (btn in buttons) {
            fillPaint.color = btn.color
            fillPaint.alpha = if (keys and btn.keyMask != 0) 220 else 140
            canvas.drawRoundRect(btn.rect, 12f, 12f, fillPaint)
            labelPaint.textSize = (btn.rect.height() * 0.46f).coerceAtLeast(14f)
            canvas.drawText(
                btn.label,
                btn.rect.centerX(),
                btn.rect.centerY() + labelPaint.textSize * 0.36f,
                labelPaint)
        }
    }

    // ── Touch ─────────────────────────────────────────────────────────────────

    private fun onGameTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> {
                var keys = 0
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i); val y = event.getY(i)
                    for (btn in buttons) if (btn.rect.contains(x, y)) keys = keys or btn.keyMask
                }
                currentKeys.set(keys)
            }
            else -> currentKeys.set(0)
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun uiToast(msg: String) =
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    or
            View.SYSTEM_UI_FLAG_FULLSCREEN          or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION     or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE       or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )
    }
}
