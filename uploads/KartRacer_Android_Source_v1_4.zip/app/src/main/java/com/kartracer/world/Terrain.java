package com.kartracer.world;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.util.Noise;

/** Theme specific terrain shape, surface classification and vertex colors. */
public final class Terrain {
    private Terrain() {}

    /** Normalized radial position: 1.0 exactly on the main loop. */
    public static float rho(TrackDef d, float x, float z) {
        float nx = x / d.rx, nz = z / d.rz;
        float rr = (float) Math.sqrt(nx * nx + nz * nz);
        float th = (float) Math.atan2(nz, nx);
        return rr / Math.max(0.3f, d.radial(th));
    }

    public static float height(TrackDef d, float x, float z, float rho) {
        int s = d.seed;
        switch (d.theme) {
            case 0: {
                float land = 1f - MathX.smooth(1.10f, 1.55f, rho);
                float dunes = Noise.fbm(x / 70f, z / 70f, 4, s) * 3.0f + Noise.fbm(x / 17f, z / 17f, 2, s + 5) * 0.6f;
                float h = MathX.lerp(-6f, 1.0f + dunes, land);
                return h - 5.2f * MathX.smooth(0.60f, 0.28f, rho);
            }
            case 1: {
                float h = 6f + 10f * Noise.fbm(x / 110f, z / 110f, 4, s) + 2f * Noise.fbm(x / 26f, z / 26f, 3, s + 3);
                return h + 24f * MathX.smooth(1.18f, 1.8f, rho);
            }
            case 2: {
                float cone = 46f * (float) Math.pow(MathX.smooth(1.02f, 0.05f, rho), 1.5);
                float bowl = 12f * MathX.smooth(0.20f, 0.04f, rho);
                float plain = 2.5f + 3.5f * Noise.fbm(x / 95f, z / 95f, 3, s);
                float rough = Noise.ridged(x / 60f, z / 60f, 4, s + 2) * 7f * MathX.smooth(1.0f, 0.2f, rho);
                return plain + cone - bowl + rough + 20f * MathX.smooth(1.25f, 1.8f, rho);
            }
            default: {
                float h = 4f + 7f * Noise.fbm(x / 130f, z / 130f, 3, s) + 1.4f * Noise.fbm(x / 24f, z / 24f, 2, s + 9);
                return h + 28f * MathX.smooth(1.2f, 1.7f, rho);
            }
        }
    }

    /** Post road-blend shaping (ponds, lava pools, mesas). sdf = distance to nearest road edge. */
    public static float carve(TrackDef d, float x, float z, float rho, float sdf, float h) {
        int s = d.seed;
        switch (d.theme) {
            case 1: {
                float p = MathX.smooth(0.66f, 0.74f, Noise.fbm(x / 65f + 17f, z / 65f - 5f, 3, s + 11)) * MathX.smooth(7f, 14f, sdf);
                return MathX.lerp(h, 0.5f, p * 0.95f);
            }
            case 2: {
                float p = MathX.smooth(0.66f, 0.73f, Noise.fbm(x / 48f + 3f, z / 48f + 11f, 3, s + 13))
                        * MathX.smooth(0.45f, 0.6f, rho) * MathX.smooth(8f, 15f, sdf);
                return MathX.lerp(h, -2.0f, p);
            }
            case 3: {
                float m = MathX.smooth(0.60f, 0.68f, Noise.fbm(x / 85f + 40f, z / 85f + 7f, 3, s + 4));
                return h + m * 16f * MathX.smooth(20f, 32f, sdf);
            }
            default:
                return h;
        }
    }

    public static int surface(TrackDef d, float x, float z, float h, float ny, float sdf) {
        float n = Noise.fbm(x / 30f, z / 30f, 2, d.seed + 21);
        switch (d.theme) {
            case 0:
                if (ny < 0.78f) return Surf.ROCK;
                if (h > 2.6f + n * 1.5f) return Surf.GRASS;
                return Surf.SAND;
            case 1:
                if (ny < 0.72f) return Surf.ROCK;
                if (h < d.waterLevel + 0.9f) return Surf.MUD;
                return Surf.GRASS;
            case 2:
                if (ny > 0.92f && n > 0.55f) return Surf.SAND;
                return Surf.ROCK;
            default:
                if (ny < 0.8f || h > 13f) return Surf.ROCK;
                return Surf.SAND;
        }
    }

    /** Vertex color incl. alpha = emissive weight (0..255). */
    public static int color(TrackDef d, int surf, float x, float z, float h, float ny, float sdf, float rho) {
        float n = Noise.fbm(x / 9f, z / 9f, 3, d.seed + 40);
        float n2 = Noise.fbm(x / 45f, z / 45f, 2, d.seed + 41);
        int c;
        int emis = 0;
        switch (d.theme) {
            case 0: {
                int sand = Col.mix(Col.rgb(240, 224, 172), Col.rgb(226, 204, 150), n);
                if (h < 0.7f) sand = Col.mix(Col.rgb(196, 170, 122), sand, MathX.smooth(-1.5f, 0.7f, h));
                int grass = Col.mix(Col.rgb(104, 172, 74), Col.rgb(70, 142, 62), n2);
                if (surf == Surf.GRASS) c = Col.mix(sand, grass, MathX.smooth(0.0f, 0.5f, h - 2.4f));
                else if (surf == Surf.ROCK) c = Col.mix(Col.rgb(138, 128, 118), Col.rgb(112, 104, 98), n);
                else c = sand;
                if (h > 1.6f && surf == Surf.SAND) c = Col.mix(c, grass, MathX.smooth(1.6f, 2.8f, h) * 0.55f);
                c = Col.mix(c, Col.rgb(214, 192, 150), MathX.smooth(5f, 0.5f, sdf) * 0.8f);
                break;
            }
            case 1: {
                int grass = Col.mix(Col.rgb(66, 146, 56), Col.rgb(40, 112, 46), n);
                if (surf == Surf.MUD) c = Col.mix(Col.rgb(112, 84, 52), Col.rgb(90, 66, 42), n);
                else if (surf == Surf.ROCK) c = Col.mix(Col.rgb(116, 112, 98), Col.rgb(84, 90, 78), n);
                else c = Col.mix(grass, Col.rgb(96, 160, 70), n2 * 0.5f);
                c = Col.mix(c, Col.rgb(150, 116, 76), MathX.smooth(5f, 0.5f, sdf) * 0.85f);
                break;
            }
            case 2: {
                int rock = Col.mix(Col.rgb(80, 70, 72), Col.rgb(116, 102, 102), n);
                if (surf == Surf.SAND) c = Col.mix(Col.rgb(128, 118, 114), Col.rgb(106, 98, 96), n);
                else c = rock;
                float steep = MathX.smooth(0.9f, 0.6f, ny);
                c = Col.mix(c, Col.rgb(56, 46, 48), steep * 0.55f);
                float lava = MathX.smooth(d.waterLevel + 2.4f, d.waterLevel - 0.2f, h);
                if (h < d.waterLevel + 0.1f) c = Col.rgb(40, 24, 22);
                float glow = Math.max(lava, MathX.smooth(0.22f, 0.06f, rho) * (0.5f + n));
                c = Col.mix(c, Col.rgb(255, 104, 24), glow * 0.9f);
                emis = (int) (glow * 210f);
                c = Col.mix(c, Col.rgb(96, 84, 86), MathX.smooth(5f, 0.5f, sdf) * 0.5f);
                break;
            }
            default: {
                int sand = Col.mix(Col.rgb(226, 174, 106), Col.rgb(208, 148, 88), n);
                if (surf == Surf.ROCK) {
                    float band = 0.5f + 0.5f * (float) Math.sin(h * 1.7f + n * 3f);
                    c = Col.mix(Col.rgb(184, 100, 66), Col.rgb(150, 78, 54), band);
                } else c = Col.mix(sand, Col.rgb(238, 196, 130), n2 * 0.6f);
                c = Col.mix(c, Col.rgb(206, 160, 108), MathX.smooth(5f, 0.5f, sdf) * 0.7f);
                break;
            }
        }
        return Col.withAlpha(c, emis);
    }
}
