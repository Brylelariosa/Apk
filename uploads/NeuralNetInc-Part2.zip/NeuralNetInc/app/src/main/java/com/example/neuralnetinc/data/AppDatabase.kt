package com.example.neuralnetinc.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.neuralnetinc.util.Constants

/**
 * Room database — version 2.
 *
 * Migration 1→2: adds Part 2 hardware count columns and derived stat columns
 * to the existing game_state table. Existing saves are preserved.
 */
@Database(
    entities  = [GameState::class],
    version   = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun gameStateDao(): GameStateDao

    companion object {

        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Migration 1 → 2: ALTER TABLE for each new column.
         * SQLite requires one ALTER per column; no multi-column ALTER.
         */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE game_state ADD COLUMN laptopsOwned     INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_state ADD COLUMN gamingPcsOwned   INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_state ADD COLUMN gpuRigsOwned     INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_state ADD COLUMN serverRacksOwned INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE game_state ADD COLUMN currentHeat          REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE game_state ADD COLUMN currentPowerUsage    REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE game_state ADD COLUMN efficiencyMultiplier REAL NOT NULL DEFAULT 1.0")
                // computePerSecond already exists; set to 0 so HardwareCalculator owns it
                db.execSQL("UPDATE game_state SET computePerSecond = 0.0 WHERE id = 1")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    Constants.DB_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
