package com.example.neuralnetinc.data

/**
 * Reserved for Room TypeConverter methods in Part 2.
 * Will be registered via @TypeConverters(Converters::class) on AppDatabase
 * once complex field types (e.g. List<Hardware>) are introduced.
 *
 * NOT currently registered — Room handles all Part 1 primitive types natively.
 */
class Converters
