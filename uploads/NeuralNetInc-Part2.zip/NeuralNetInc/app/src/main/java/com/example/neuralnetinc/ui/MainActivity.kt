package com.example.neuralnetinc.ui

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.neuralnetinc.NeuralNetApp
import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import java.text.DecimalFormat

/**
 * MainActivity — thin UI layer.
 *
 * Fix: use repeatOnLifecycle(STARTED) so the collector restarts every time
 * the activity comes back into view (back navigation, task switch, etc.).
 * One single collector on gameState builds both the stats UI and the
 * hardware list — avoids the empty-list flash caused by the separate
 * SharingStarted.Lazily derived flow.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.Factory((application as NeuralNetApp).repository)
    }

    private lateinit var hardwareAdapter: HardwareAdapter

    private val moneyFmt   = DecimalFormat("#,##0.00")
    private val computeFmt = DecimalFormat("#,##0.000")
    private val statFmt    = DecimalFormat("#,##0.0")
    private val pctFmt     = DecimalFormat("#0.0")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        observeGameState()
    }

    private fun setupRecyclerView() {
        hardwareAdapter = HardwareAdapter { hardwareId ->
            viewModel.buyHardware(hardwareId)
        }
        binding.recyclerViewHardware.apply {
            layoutManager            = LinearLayoutManager(this@MainActivity)
            adapter                  = hardwareAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun observeGameState() {
        lifecycleScope.launch {
            // repeatOnLifecycle restarts the block every time the lifecycle
            // reaches STARTED (i.e. on every resume) and cancels on STOP.
            // This fixes the disappearing items when navigating back.
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.gameState.collect { state ->
                    if (state == null) return@collect
                    updateUI(state)
                    // Build hardware list here directly — no separate derived
                    // flow means no empty-list flash on first emission.
                    hardwareAdapter.submitList(viewModel.buildHardwareDisplayList(state))
                }
            }
        }
    }

    private fun updateUI(state: GameState) {
        binding.tvMoney.text         = "\$${moneyFmt.format(state.money)}"
        binding.tvTotalCompute.text  = "${computeFmt.format(state.totalCompute)} GF"
        binding.tvComputePerSec.text = "${computeFmt.format(state.computePerSecond)} GF/s"
        binding.tvElectricity.text   = "${statFmt.format(state.electricity)} kW"
        binding.tvCooling.text       = "${statFmt.format(state.cooling)}\u00B0C"
        binding.tvResearch.text      = "${computeFmt.format(state.researchPoints)} RP"

        val effPct = state.efficiencyMultiplier * 100.0
        binding.tvEfficiency.text    = "${pctFmt.format(effPct)}%"
        binding.tvHeatUsage.text     = "${statFmt.format(state.currentHeat)} / ${statFmt.format(state.cooling)}"
        binding.tvPowerUsage.text    = "${statFmt.format(state.currentPowerUsage)} / ${statFmt.format(state.electricity)} kW"
    }

    override fun onPause() {
        super.onPause()
        viewModel.saveGame()
    }
}
