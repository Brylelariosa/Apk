package com.example.neuralnetinc.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * GameState — single Room row representing the full game save.
 *
 * Part 1 fields: money, totalCompute, computePerSecond,
 *                electricity, cooling, researchPoints, lastSavedTime
 *
 * Part 2 additions:
 *   Hardware counts  — one Int per tier; avoids JSON/TypeConverter complexity.
 *                      Adding a new tier requires a schema migration.
 *   currentHeat      — sum(heatOutput * owned) across all hardware.
 *   currentPowerUsage — sum(powerUsage * owned) across all hardware.
 *   efficiencyMultiplier — 0.25–1.0; penalises compute/money when hot or underpowered.
 *
 * computePerSecond is now a DERIVED value recalculated by HardwareCalculator
 * on every tick from the hardware counts. It no longer has a non-zero default.
 */
@Entity(tableName = "game_state")
data class GameState(

    @PrimaryKey
    val id: Int = 1,

    val money: Double = 0.0,

    val totalCompute: Double = 0.0,

    /** Recalculated each tick by HardwareCalculator. Default 0 — buy hardware first. */
    val computePerSecond: Double = 0.0,

    /** Available power budget (kW). Expanded by infrastructure in Part 3+. */
    val electricity: Double = 100.0,

    /** Cooling capacity. Limits heat before efficiency penalty kicks in. */
    val cooling: Double = 100.0,

    val researchPoints: Double = 0.0,

    val lastSavedTime: Long = System.currentTimeMillis(),

    // ── Part 2: hardware inventory ───────────────────────────────
    val laptopsOwned: Int = 0,
    val gamingPcsOwned: Int = 0,
    val gpuRigsOwned: Int = 0,
    val serverRacksOwned: Int = 0,

    // ── Part 2: derived runtime stats (recalculated each tick) ───
    /** Sum of heatOutput × owned across all hardware. */
    val currentHeat: Double = 0.0,

    /** Sum of powerUsage × owned across all hardware. */
    val currentPowerUsage: Double = 0.0,

    /**
     * Combined efficiency multiplier applied to compute and money generation.
     * Formula: min(heatEfficiency, powerEfficiency), clamped to [0.25, 1.0].
     */
    val efficiencyMultiplier: Double = 1.0
)
