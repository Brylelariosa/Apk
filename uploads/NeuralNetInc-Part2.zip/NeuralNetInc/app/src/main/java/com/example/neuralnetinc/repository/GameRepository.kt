package com.example.neuralnetinc.repository

import com.example.neuralnetinc.data.AppDatabase
import com.example.neuralnetinc.data.GameState
import kotlinx.coroutines.flow.Flow

/**
 * Repository layer — abstracts the data source from the rest of the app.
 * Future parts can swap Room for a cloud backend here transparently.
 */
class GameRepository(private val db: AppDatabase) {

    /** Reactive stream — emits whenever the DB row changes. */
    fun observeGameState(): Flow<GameState?> =
        db.gameStateDao().observeGameState()

    /** One-shot suspend load. Returns a fresh GameState if no save exists. */
    suspend fun loadGameState(): GameState =
        db.gameStateDao().loadGameState() ?: GameState()

    /**
     * Persist current state.
     * Stamps lastSavedTime so offline progress can be calculated on next load.
     */
    suspend fun saveGameState(state: GameState) {
        db.gameStateDao().saveGameState(
            state.copy(lastSavedTime = System.currentTimeMillis())
        )
    }
}
