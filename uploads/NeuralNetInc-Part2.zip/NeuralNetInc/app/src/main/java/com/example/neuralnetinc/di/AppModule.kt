package com.example.neuralnetinc.di

/**
 * AppModule — reserved for Hilt dependency injection in a future part.
 *
 * Currently, manual DI is provided through NeuralNetApp (Application class).
 * When Hilt is added:
 *   - Annotate AppModule with @Module @InstallIn(SingletonComponent::class)
 *   - Move database/repository providers here as @Provides @Singleton functions
 */
object AppModule {
    // Future Hilt providers will live here
}
