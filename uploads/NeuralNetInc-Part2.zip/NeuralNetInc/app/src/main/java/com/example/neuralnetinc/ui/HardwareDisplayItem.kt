package com.example.neuralnetinc.ui

import com.example.neuralnetinc.data.Hardware

/**
 * HardwareDisplayItem — UI model consumed by HardwareAdapter.
 * prerequisiteCount forwarded from Hardware for the lock label.
 */
data class HardwareDisplayItem(
    val hardware: Hardware,
    val owned: Int,
    val currentCost: Double,
    val isUnlocked: Boolean,
    val canAfford: Boolean
) {
    val prerequisiteCount: Int get() = hardware.prerequisiteCount
}
