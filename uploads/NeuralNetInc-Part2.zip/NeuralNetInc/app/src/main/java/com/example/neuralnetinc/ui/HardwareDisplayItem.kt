package com.example.neuralnetinc.ui

import com.example.neuralnetinc.data.Hardware

/**
 * HardwareDisplayItem — UI model consumed by HardwareAdapter.
 * Computed by MainViewModel from GameState on every state emission.
 */
data class HardwareDisplayItem(
    val hardware: Hardware,
    val owned: Int,
    val currentCost: Double,
    val isUnlocked: Boolean,
    val canAfford: Boolean
)
