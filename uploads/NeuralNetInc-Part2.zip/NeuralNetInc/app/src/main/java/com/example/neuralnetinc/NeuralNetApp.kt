package com.example.neuralnetinc

import android.app.Application
import com.example.neuralnetinc.data.AppDatabase
import com.example.neuralnetinc.repository.GameRepository

/**
 * Application class — manual dependency injection root.
 * Provides lazy singletons for database and repository.
 * Hilt can replace this in a future refactor.
 */
class NeuralNetApp : Application() {

    val database: AppDatabase by lazy {
        AppDatabase.getInstance(this)
    }

    val repository: GameRepository by lazy {
        GameRepository(database)
    }
}
