package com.example.neuralnetinc.engine

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.util.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * GameLoop — drives the simulation using a coroutine ticker.
 *
 * Design decisions:
 *  - Runs on Dispatchers.Default (CPU work off main thread).
 *  - Exposes state via StateFlow so UI can collect it safely.
 *  - Auto-save callback is a suspend lambda so the save can happen
 *    on whichever dispatcher the repository prefers.
 *  - Loop is started/stopped with the ViewModel lifecycle.
 *
 * Loop rhythm (every TICK_INTERVAL_MS):
 *   delay → tick → emit new state → auto-save if due
 */
class GameLoop(private val tickSystem: TickSystem) {

    private val _gameState = MutableStateFlow<GameState?>(null)
    val gameState: StateFlow<GameState?> = _gameState

    private var loopJob: Job? = null

    /**
     * Start the game loop.
     *
     * @param scope        CoroutineScope tied to ViewModel (auto-cancelled on clear)
     * @param initialState The loaded (and offline-progressed) GameState
     * @param onAutoSave   Called every AUTO_SAVE_INTERVAL_TICKS with the latest state
     */
    fun start(
        scope: CoroutineScope,
        initialState: GameState,
        onAutoSave: suspend (GameState) -> Unit
    ) {
        if (loopJob?.isActive == true) return   // prevent double-start

        _gameState.value = initialState
        loopJob = scope.launch(Dispatchers.Default) {
            while (isActive) {
                delay(Constants.TICK_INTERVAL_MS)

                val current = _gameState.value ?: initialState
                val updated = tickSystem.tick(current)
                _gameState.value = updated

                if (tickSystem.shouldAutoSave(Constants.AUTO_SAVE_INTERVAL_TICKS)) {
                    onAutoSave(updated)
                }
            }
        }
    }

    /** Stop the loop (called from ViewModel.onCleared). */
    fun stop() {
        loopJob?.cancel()
        loopJob = null
    }

    /** Inject an externally-modified state (e.g., after a purchase in Part 2). */
    fun updateState(state: GameState) {
        _gameState.value = state
    }

    val isRunning: Boolean get() = loopJob?.isActive == true
}
