package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.data.HardwareCatalog
import com.example.neuralnetinc.util.Constants

/**
 * HardwareCalculator — derives all hardware-driven stats from GameState.
 *
 * Formulas:
 *   totalComputePerSecond = BASE_COMPUTE_PER_SECOND + sum(hw.computeOutput * owned)
 *   totalPowerUsage       = sum(hw.powerUsage    * owned)
 *   totalHeat             = sum(hw.heatOutput    * owned)
 *
 * BASE_COMPUTE_PER_SECOND ensures money and compute always tick even with
 * no hardware purchased — hardware adds on top of this floor.
 *
 *   heatEfficiency  = HeatManager.calculateEfficiency(totalHeat,  cooling)
 *   powerEfficiency = PowerManager.calculateEfficiency(totalPower, electricity)
 *   finalEfficiency = min(heatEfficiency, powerEfficiency), clamped [0.25, 1.0]
 */
class HardwareCalculator(
    private val hardwareSystem: HardwareSystem,
    private val heatManager: HeatManager,
    private val powerManager: PowerManager
) {

    fun recalculate(state: GameState): GameState {
        // Start from the base floor so compute/money always tick
        var totalCompute = Constants.BASE_COMPUTE_PER_SECOND
        var totalHeat    = 0.0
        var totalPower   = 0.0

        for (hw in HardwareCatalog.ALL) {
            val owned = hardwareSystem.getOwnedCount(state, hw)
            totalCompute += hw.computeOutput * owned
            totalHeat    += hw.heatOutput    * owned
            totalPower   += hw.powerUsage    * owned
        }

        val heatEff  = heatManager.calculateEfficiency(totalHeat,  state.cooling)
        val powerEff = powerManager.calculateEfficiency(totalPower, state.electricity)
        val finalEff = minOf(heatEff, powerEff)

        return state.copy(
            computePerSecond     = totalCompute,
            currentHeat          = totalHeat,
            currentPowerUsage    = totalPower,
            efficiencyMultiplier = finalEff
        )
    }
}
