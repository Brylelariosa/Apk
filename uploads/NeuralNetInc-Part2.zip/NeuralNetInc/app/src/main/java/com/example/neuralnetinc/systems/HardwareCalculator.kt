package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.data.HardwareCatalog

/**
 * HardwareCalculator — derives all hardware-driven stats from GameState.
 *
 * Called by TickSystem on every tick so derived values stay consistent
 * with the owned hardware counts. Also called immediately after a purchase
 * so the UI reflects changes without waiting for the next tick.
 *
 * Formulas (per spec):
 *   totalComputePerSecond = sum(hardware.computeOutput * owned)
 *   totalPowerUsage       = sum(hardware.powerUsage    * owned)
 *   totalHeat             = sum(hardware.heatOutput    * owned)
 *
 *   heatEfficiency  = HeatManager.calculateEfficiency(totalHeat,  cooling)
 *   powerEfficiency = PowerManager.calculateEfficiency(totalPower, electricity)
 *   finalEfficiency = min(heatEfficiency, powerEfficiency)
 */
class HardwareCalculator(
    private val hardwareSystem: HardwareSystem,
    private val heatManager: HeatManager,
    private val powerManager: PowerManager
) {

    /**
     * Recalculate all hardware-derived fields and return an updated GameState.
     * Pure function — does not mutate any state.
     */
    fun recalculate(state: GameState): GameState {
        var totalCompute = 0.0
        var totalHeat    = 0.0
        var totalPower   = 0.0

        for (hw in HardwareCatalog.ALL) {
            val owned = hardwareSystem.getOwnedCount(state, hw)
            totalCompute += hw.computeOutput * owned
            totalHeat    += hw.heatOutput    * owned
            totalPower   += hw.powerUsage    * owned
        }

        val heatEff  = heatManager.calculateEfficiency(totalHeat,  state.cooling)
        val powerEff = powerManager.calculateEfficiency(totalPower, state.electricity)

        // Both heat and power can independently penalise — take the worse.
        val finalEff = minOf(heatEff, powerEff)

        return state.copy(
            computePerSecond      = totalCompute,
            currentHeat           = totalHeat,
            currentPowerUsage     = totalPower,
            efficiencyMultiplier  = finalEff
        )
    }
}
