package com.example.neuralnetinc.systems

/**
 * PowerManager — translates power usage vs supply into an efficiency multiplier.
 *
 * Formula:
 *   if usage <= supply : efficiency = 1.0  (no penalty)
 *   if usage >  supply : efficiency = supply / usage
 *
 * Minimum efficiency clamp: 0.25 — hardware doesn't fully stop, just throttles.
 *
 * Example:
 *   electricity = 100 kW, usage = 150 kW  →  efficiency = 100/150 ≈ 0.67
 */
class PowerManager {

    companion object {
        const val MIN_EFFICIENCY = 0.25
    }

    /**
     * Returns power efficiency in range [MIN_EFFICIENCY, 1.0].
     * @param usage      total kW consumed by owned hardware
     * @param supply     available kW from GameState.electricity
     */
    fun calculateEfficiency(usage: Double, supply: Double): Double {
        if (usage <= 0.0 || usage <= supply) return 1.0
        val raw = supply / usage
        return raw.coerceAtLeast(MIN_EFFICIENCY)
    }

    /** Human-readable power status for the UI. */
    fun powerStatus(usage: Double, supply: Double): String = when {
        usage <= 0.0        -> "IDLE"
        usage <= supply     -> "STABLE"
        usage <= supply * 2 -> "STRAINED"
        else                -> "OVERLOADED"
    }
}
