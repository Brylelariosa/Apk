package com.example.neuralnetinc.systems

/**
 * HeatManager — translates raw heat vs cooling into an efficiency multiplier.
 *
 * Formula (per spec):
 *   if heat <= cooling : efficiency = 1.0  (no penalty)
 *   if heat >  cooling : efficiency = cooling / heat
 *
 * Minimum efficiency clamp: 0.25 (25%) — prevents total shutdown.
 *
 * Example:
 *   cooling = 100, heat = 200  →  efficiency = 100/200 = 0.50
 *   cooling = 100, heat = 500  →  efficiency = clamped to 0.25
 */
class HeatManager {

    companion object {
        const val MIN_EFFICIENCY = 0.25
    }

    /**
     * Returns heat efficiency in range [MIN_EFFICIENCY, 1.0].
     * @param heat     current total heat generated (sum across hardware)
     * @param cooling  available cooling capacity from GameState
     */
    fun calculateEfficiency(heat: Double, cooling: Double): Double {
        if (heat <= 0.0 || heat <= cooling) return 1.0
        val raw = cooling / heat
        return raw.coerceAtLeast(MIN_EFFICIENCY)
    }

    /** Human-readable heat status for the UI. */
    fun heatStatus(heat: Double, cooling: Double): String = when {
        heat <= 0.0         -> "IDLE"
        heat <= cooling     -> "NOMINAL"
        heat <= cooling * 2 -> "WARM"
        heat <= cooling * 4 -> "HOT"
        else                -> "CRITICAL"
    }
}
