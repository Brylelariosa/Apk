package com.example.neuralnetinc.data

/**
 * Hardware — immutable template describing a purchasable hardware tier.
 *
 * unlockRequirement: number of the PREVIOUS tier that must be owned before
 * this tier's buy button becomes active. 0 = always available.
 * All tiers are always VISIBLE — only the buy button is locked.
 */
data class Hardware(
    val id: String,
    val name: String,
    val description: String,
    val baseCost: Double,
    val computeOutput: Double,
    val powerUsage: Double,
    val heatOutput: Double,
    /** ID of the hardware that must be owned before this unlocks. Empty = no requirement. */
    val prerequisiteId: String = "",
    /** How many of prerequisiteId must be owned. 0 = no requirement. */
    val prerequisiteCount: Int = 0
)

/**
 * HardwareCatalog — all hardware definitions.
 *
 * Progression:
 *   Old Laptop      — always available
 *   Gaming PC       — unlocks after owning 1 laptop
 *   GPU Rig         — unlocks after owning 1 Gaming PC
 *   Mini Server Rack — unlocks after owning 1 GPU Rig
 *
 * This ties unlocks to purchases, not time — much more intuitive.
 */
object HardwareCatalog {

    val ALL: List<Hardware> = listOf(

        Hardware(
            id            = "old_laptop",
            name          = "Old Laptop",
            description   = "Slow but cheap. Every empire starts somewhere.",
            baseCost      = 10.0,
            computeOutput = 0.5,
            powerUsage    = 2.0,
            heatOutput    = 1.0
        ),

        Hardware(
            id                = "gaming_pc",
            name              = "Gaming PC",
            description       = "A repurposed gaming rig. Decent compute, decent heat.",
            baseCost          = 150.0,
            computeOutput     = 5.0,
            powerUsage        = 15.0,
            heatOutput        = 10.0,
            prerequisiteId    = "old_laptop",
            prerequisiteCount = 1
        ),

        Hardware(
            id                = "gpu_rig",
            name              = "GPU Rig",
            description       = "Six GPUs in a frame. Power-hungry but effective.",
            baseCost          = 2000.0,
            computeOutput     = 60.0,
            powerUsage        = 120.0,
            heatOutput        = 80.0,
            prerequisiteId    = "gaming_pc",
            prerequisiteCount = 1
        ),

        Hardware(
            id                = "mini_server_rack",
            name              = "Mini Server Rack",
            description       = "A proper rack unit. Serious compute for serious players.",
            baseCost          = 25000.0,
            computeOutput     = 750.0,
            powerUsage        = 500.0,
            heatOutput        = 400.0,
            prerequisiteId    = "gpu_rig",
            prerequisiteCount = 1
        )
    )

    fun getById(id: String): Hardware? = ALL.find { it.id == id }
}
