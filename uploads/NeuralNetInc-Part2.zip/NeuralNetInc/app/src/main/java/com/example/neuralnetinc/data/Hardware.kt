package com.example.neuralnetinc.data

/**
 * Hardware — immutable template describing a purchasable hardware tier.
 * NOT a Room entity; owned counts are stored as Int columns in GameState.
 *
 * @param id               Stable string key, must match the when() branches
 *                         in HardwareSystem.getOwnedCount / incrementOwned.
 * @param computeOutput    GigaFLOPS per second added per unit owned.
 * @param powerUsage       kW consumed per unit owned.
 * @param heatOutput       Heat units generated per unit owned.
 * @param unlockRequirement totalCompute threshold before this tier appears.
 */
data class Hardware(
    val id: String,
    val name: String,
    val description: String,
    val baseCost: Double,
    val computeOutput: Double,
    val powerUsage: Double,
    val heatOutput: Double,
    val unlockRequirement: Double = 0.0
)

/**
 * HardwareCatalog — single source of truth for all hardware definitions.
 * Add new tiers here; no other files need changing for the template itself.
 *
 * Balancing:
 *   Old Laptop      cheap, very low output — starter unit
 *   Gaming PC       10× compute, 7.5× cost vs laptop
 *   GPU Rig         100× compute vs laptop, high heat
 *   Mini Server Rack 1000× compute vs laptop, requires serious investment
 */
object HardwareCatalog {

    val ALL: List<Hardware> = listOf(

        Hardware(
            id              = "old_laptop",
            name            = "Old Laptop",
            description     = "Slow but cheap. Every empire starts somewhere.",
            baseCost        = 10.0,
            computeOutput   = 0.5,
            powerUsage      = 2.0,
            heatOutput      = 1.0,
            unlockRequirement = 0.0
        ),

        Hardware(
            id              = "gaming_pc",
            name            = "Gaming PC",
            description     = "A repurposed gaming rig. Decent compute, decent heat.",
            baseCost        = 150.0,
            computeOutput   = 5.0,
            powerUsage      = 15.0,
            heatOutput      = 10.0,
            unlockRequirement = 50.0
        ),

        Hardware(
            id              = "gpu_rig",
            name            = "GPU Rig",
            description     = "Six GPUs in a frame. Power-hungry but effective.",
            baseCost        = 2000.0,
            computeOutput   = 60.0,
            powerUsage      = 120.0,
            heatOutput      = 80.0,
            unlockRequirement = 500.0
        ),

        Hardware(
            id              = "mini_server_rack",
            name            = "Mini Server Rack",
            description     = "A proper rack unit. Serious compute for serious players.",
            baseCost        = 25000.0,
            computeOutput   = 750.0,
            powerUsage      = 500.0,
            heatOutput      = 400.0,
            unlockRequirement = 10000.0
        )
    )

    fun getById(id: String): Hardware? = ALL.find { it.id == id }
}
