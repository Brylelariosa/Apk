package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.util.Constants

/**
 * EconomyManager — all resource generation formulas.
 *
 * Part 2 change: both compute and money generation are multiplied by
 * GameState.efficiencyMultiplier (set by HardwareCalculator each tick).
 * Research is unaffected by efficiency (knowledge persists through heat/power issues).
 *
 * Core tick formulas:
 *   compute  += computePerSecond * efficiencyMultiplier
 *   money    += computePerSecond * BASE_MONEY_PER_COMPUTE * efficiencyMultiplier
 *   research += BASE_RESEARCH_PER_TICK  (no efficiency penalty)
 */
class EconomyManager {

    // ── Per-tick generators ───────────────────────────────────────

    /**
     * Raw money rate before efficiency. Applied as:
     *   money += moneyPerTick(state) * state.efficiencyMultiplier
     */
    fun moneyPerTick(state: GameState): Double =
        state.computePerSecond * Constants.BASE_MONEY_PER_COMPUTE

    fun researchPerTick(@Suppress("UNUSED_PARAMETER") state: GameState): Double =
        Constants.BASE_RESEARCH_PER_TICK

    // ── Tick application ──────────────────────────────────────────

    /**
     * Apply one game tick. Efficiency multiplier applied to compute and money.
     * NOTE: HardwareCalculator.recalculate() must be called BEFORE this
     * (done inside TickSystem.tick) to ensure efficiencyMultiplier is current.
     */
    fun applyTick(state: GameState): GameState {
        val eff = state.efficiencyMultiplier
        return state.copy(
            totalCompute   = state.totalCompute   + state.computePerSecond * eff,
            money          = state.money          + moneyPerTick(state)    * eff,
            researchPoints = state.researchPoints + researchPerTick(state)
        )
    }

    // ── Offline progress ──────────────────────────────────────────

    /**
     * O(1) offline progress calculation. Applies efficiency from saved state.
     * Capped at OFFLINE_CAP_SECONDS.
     */
    fun applyOfflineProgress(state: GameState): GameState {
        val elapsed = ((System.currentTimeMillis() - state.lastSavedTime) / 1000L)
            .coerceIn(0L, Constants.OFFLINE_CAP_SECONDS)
        if (elapsed == 0L) return state

        val e   = elapsed.toDouble()
        val eff = state.efficiencyMultiplier
        return state.copy(
            totalCompute   = state.totalCompute   + state.computePerSecond * eff * e,
            money          = state.money          + moneyPerTick(state)    * eff * e,
            researchPoints = state.researchPoints + researchPerTick(state)       * e
        )
    }

    // ── Scaling helpers ───────────────────────────────────────────

    /** Exponential cost formula used by HardwareSystem. Kept here for reference. */
    fun hardwareCost(baseCost: Double, scaleFactor: Double, owned: Int): Double =
        baseCost * Math.pow(scaleFactor, owned.toDouble())

    fun computeContribution(computePerUnit: Double, count: Int): Double =
        computePerUnit * count
}
