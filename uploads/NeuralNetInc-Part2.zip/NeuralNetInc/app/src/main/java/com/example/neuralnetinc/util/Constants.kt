package com.example.neuralnetinc.util

/**
 * Global game constants.
 * All tuneable values live here to make balancing easy.
 */
object Constants {

    // ── Timing ──────────────────────────────────────────────────────────
    /** How often the game ticks, in milliseconds. */
    const val TICK_INTERVAL_MS = 1000L

    /** Auto-save every N ticks (default: 30 s). */
    const val AUTO_SAVE_INTERVAL_TICKS = 30

    // ── Economy formulas ─────────────────────────────────────────────────
    /**
     * Money earned per unit of compute per tick.
     * Formula: money += computePerSecond * BASE_MONEY_PER_COMPUTE
     * Tuned so $0.01 per GF/s feels rewarding early.
     */
    const val BASE_MONEY_PER_COMPUTE = 0.01

    /**
     * Flat research points generated each tick (pre-hardware).
     * Will scale with research hardware in Part 2.
     */
    const val BASE_RESEARCH_PER_TICK = 0.001

    /** Cap offline progress at 8 hours to prevent abuse. */
    const val OFFLINE_CAP_SECONDS = 8 * 3600L

    // ── Database ─────────────────────────────────────────────────────────
    const val DB_NAME = "neuralnet_db"
}

    /**
     * Base compute generated per second before any hardware.
     * Restored in Part 2 so money and compute tick from the very start.
     * Hardware adds ON TOP of this floor.
     */
    const val BASE_COMPUTE_PER_SECOND = 1.0
