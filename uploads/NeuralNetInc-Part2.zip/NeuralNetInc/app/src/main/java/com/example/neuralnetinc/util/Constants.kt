package com.example.neuralnetinc.util

/**
 * Global game constants.
 * All tuneable values live here to make balancing easy.
 */
object Constants {

    // ── Timing ──────────────────────────────────────────────────────────
    const val TICK_INTERVAL_MS = 1000L
    const val AUTO_SAVE_INTERVAL_TICKS = 30

    // ── Economy formulas ─────────────────────────────────────────────────
    /** money += computePerSecond * BASE_MONEY_PER_COMPUTE per tick */
    const val BASE_MONEY_PER_COMPUTE = 0.01

    /** Flat research points per tick, independent of hardware. */
    const val BASE_RESEARCH_PER_TICK = 0.001

    /**
     * Base compute (GF/s) before any hardware is purchased.
     * Ensures money and compute tick from the very first second.
     * Hardware adds on top of this floor.
     */
    const val BASE_COMPUTE_PER_SECOND = 1.0

    /** Cap offline progress at 8 hours to prevent abuse. */
    const val OFFLINE_CAP_SECONDS = 8 * 3600L

    // ── Database ─────────────────────────────────────────────────────────
    const val DB_NAME = "neuralnet_db"
}
