package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.repository.GameRepository

/**
 * SaveManager — wraps the repository with game-aware load/save logic.
 * Applies offline progress on load so players are rewarded for time away.
 */
class SaveManager(
    private val repository: GameRepository,
    private val economyManager: EconomyManager
) {

    /**
     * Load game from DB and apply offline progress.
     * Returns a fresh GameState if no save exists yet.
     */
    suspend fun loadGame(): GameState {
        val saved = repository.loadGameState()
        return economyManager.applyOfflineProgress(saved)
    }

    /** Persist the current game state. */
    suspend fun saveGame(state: GameState) {
        repository.saveGameState(state)
    }
}
