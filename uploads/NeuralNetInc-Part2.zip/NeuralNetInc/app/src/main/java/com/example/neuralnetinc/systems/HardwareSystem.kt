package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.data.Hardware
import com.example.neuralnetinc.data.HardwareCatalog
import kotlin.math.pow

/**
 * HardwareSystem — all purchase logic for hardware.
 *
 * Buying formula (per spec):
 *   cost = baseCost * 1.15 ^ ownedQuantity
 *
 * This means:
 *   - 1st unit: baseCost * 1.15^0 = baseCost
 *   - 2nd unit: baseCost * 1.15^1 = baseCost * 1.15
 *   - Nth unit: baseCost * 1.15^(N-1)
 *
 * Hardware counts map to specific GameState Int fields.
 * When adding a new tier in Part 3: add a field to GameState,
 * add a migration in AppDatabase, and add a branch here.
 */
class HardwareSystem {

    companion object {
        /** Exponential cost scale factor per additional unit. */
        const val COST_SCALE = 1.15
    }

    // ── Owned count accessors ─────────────────────────────────────

    fun getOwnedCount(state: GameState, hardware: Hardware): Int = when (hardware.id) {
        "old_laptop"       -> state.laptopsOwned
        "gaming_pc"        -> state.gamingPcsOwned
        "gpu_rig"          -> state.gpuRigsOwned
        "mini_server_rack" -> state.serverRacksOwned
        else               -> 0
    }

    /** Returns a new GameState with the owned count for [hardware] incremented by 1. */
    private fun incrementOwned(state: GameState, hardware: Hardware): GameState = when (hardware.id) {
        "old_laptop"       -> state.copy(laptopsOwned     = state.laptopsOwned     + 1)
        "gaming_pc"        -> state.copy(gamingPcsOwned   = state.gamingPcsOwned   + 1)
        "gpu_rig"          -> state.copy(gpuRigsOwned     = state.gpuRigsOwned     + 1)
        "mini_server_rack" -> state.copy(serverRacksOwned = state.serverRacksOwned + 1)
        else               -> state
    }

    // ── Cost calculations ─────────────────────────────────────────

    /**
     * Current purchase price for the next unit of [hardware].
     * Formula: baseCost * COST_SCALE ^ owned
     */
    fun currentCost(hardware: Hardware, owned: Int): Double =
        hardware.baseCost * COST_SCALE.pow(owned.toDouble())

    fun currentCost(state: GameState, hardware: Hardware): Double =
        currentCost(hardware, getOwnedCount(state, hardware))

    // ── Affordability ─────────────────────────────────────────────

    fun canAfford(state: GameState, hardware: Hardware): Boolean =
        state.money >= currentCost(state, hardware)

    // ── Unlock check ──────────────────────────────────────────────

    fun isUnlocked(state: GameState, hardware: Hardware): Boolean =
        state.totalCompute >= hardware.unlockRequirement

    // ── Purchase ──────────────────────────────────────────────────

    /**
     * Attempt to buy one unit of [hardwareId].
     * Returns an updated GameState with money deducted and count incremented,
     * or null if the player cannot afford it or the ID is unknown.
     */
    fun buyHardware(state: GameState, hardwareId: String): GameState? {
        val hw = HardwareCatalog.getById(hardwareId) ?: return null
        if (!canAfford(state, hw)) return null

        val cost     = currentCost(state, hw)
        val deducted = state.copy(money = state.money - cost)
        return incrementOwned(deducted, hw)
    }

    // ── Display list helper ───────────────────────────────────────

    /**
     * Build a display-ready list showing all hardware tiers.
     * Locked tiers are included so the player can see what's coming.
     */
    fun buildDisplayList(
        state: GameState
    ): List<Triple<Hardware, Int, Double>> =   // (hardware, owned, cost)
        HardwareCatalog.ALL.map { hw ->
            Triple(hw, getOwnedCount(state, hw), currentCost(state, hw))
        }
}
