package com.example.neuralnetinc.systems

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.data.Hardware
import com.example.neuralnetinc.data.HardwareCatalog
import kotlin.math.pow

/**
 * HardwareSystem — all purchase logic for hardware.
 *
 * Unlock rule: a tier is unlocked when the player owns at least
 * prerequisiteCount of prerequisiteId. This ties progression to
 * purchases rather than time, which is far more intuitive.
 *
 * Cost formula: baseCost * 1.15 ^ owned
 */
class HardwareSystem {

    companion object {
        const val COST_SCALE = 1.15
    }

    // ── Owned count ───────────────────────────────────────────────

    fun getOwnedCount(state: GameState, hardware: Hardware): Int = when (hardware.id) {
        "old_laptop"       -> state.laptopsOwned
        "gaming_pc"        -> state.gamingPcsOwned
        "gpu_rig"          -> state.gpuRigsOwned
        "mini_server_rack" -> state.serverRacksOwned
        else               -> 0
    }

    private fun incrementOwned(state: GameState, hardware: Hardware): GameState = when (hardware.id) {
        "old_laptop"       -> state.copy(laptopsOwned     = state.laptopsOwned     + 1)
        "gaming_pc"        -> state.copy(gamingPcsOwned   = state.gamingPcsOwned   + 1)
        "gpu_rig"          -> state.copy(gpuRigsOwned     = state.gpuRigsOwned     + 1)
        "mini_server_rack" -> state.copy(serverRacksOwned = state.serverRacksOwned + 1)
        else               -> state
    }

    // ── Cost ──────────────────────────────────────────────────────

    fun currentCost(hardware: Hardware, owned: Int): Double =
        hardware.baseCost * COST_SCALE.pow(owned.toDouble())

    fun currentCost(state: GameState, hardware: Hardware): Double =
        currentCost(hardware, getOwnedCount(state, hardware))

    // ── Unlock ────────────────────────────────────────────────────

    /**
     * A tier is unlocked when its prerequisite owned count is met.
     * Tiers with no prerequisite (empty id) are always unlocked.
     */
    fun isUnlocked(state: GameState, hardware: Hardware): Boolean {
        if (hardware.prerequisiteId.isEmpty()) return true
        val prereq = HardwareCatalog.getById(hardware.prerequisiteId) ?: return true
        return getOwnedCount(state, prereq) >= hardware.prerequisiteCount
    }

    fun canAfford(state: GameState, hardware: Hardware): Boolean =
        state.money >= currentCost(state, hardware)

    // ── Purchase ──────────────────────────────────────────────────

    /**
     * Returns updated GameState with purchase applied, or null if can't afford
     * or not unlocked.
     */
    fun buyHardware(state: GameState, hardwareId: String): GameState? {
        val hw = HardwareCatalog.getById(hardwareId) ?: return null
        if (!isUnlocked(state, hw)) return null
        if (!canAfford(state, hw)) return null
        val cost = currentCost(state, hw)
        return incrementOwned(state.copy(money = state.money - cost), hw)
    }
}
