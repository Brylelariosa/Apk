package com.example.neuralnetinc.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.neuralnetinc.databinding.ItemHardwareBinding
import java.text.DecimalFormat

/**
 * HardwareAdapter — plain RecyclerView.Adapter (no DiffUtil).
 *
 * DiffUtil's async background diff was causing unlock state changes to be
 * swallowed when a new submitList() arrived from the next tick before the
 * previous diff completed. With only 4 rows, notifyDataSetChanged() is
 * instantaneous and completely reliable.
 */
class HardwareAdapter(
    private val onBuyClick: (hardwareId: String) -> Unit
) : RecyclerView.Adapter<HardwareAdapter.ViewHolder>() {

    private val items = mutableListOf<HardwareDisplayItem>()

    private val costFmt    = DecimalFormat("#,##0.00")
    private val computeFmt = DecimalFormat("#,##0.0##")
    private val statFmt    = DecimalFormat("#,##0.0")

    fun updateList(newItems: List<HardwareDisplayItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val b: ItemHardwareBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(item: HardwareDisplayItem) {
            val hw = item.hardware

            b.tvHardwareName.text = hw.name
            b.tvHardwareDesc.text = hw.description
            b.tvOwnedCount.text   = "\u00D7${item.owned}"
            b.tvComputeStat.text  = "${computeFmt.format(hw.computeOutput)} GF/s"
            b.tvPowerStat.text    = "${statFmt.format(hw.powerUsage)} kW"
            b.tvHeatStat.text     = "${statFmt.format(hw.heatOutput)}\u00B0/s"

            when {
                !item.isUnlocked -> {
                    b.btnBuy.isEnabled = false
                    b.btnBuy.alpha     = 0.3f
                    b.tvBuyCost.text   = "\uD83D\uDD12  Buy ${hw.prerequisiteCount}x prev tier to unlock"
                    b.itemRoot.alpha   = 0.55f
                }
                !item.canAfford -> {
                    b.btnBuy.isEnabled = false
                    b.btnBuy.alpha     = 0.45f
                    b.tvBuyCost.text   = "Need \$${costFmt.format(item.currentCost)}"
                    b.itemRoot.alpha   = 1.0f
                }
                else -> {
                    b.btnBuy.isEnabled = true
                    b.btnBuy.alpha     = 1.0f
                    b.tvBuyCost.text   = "\$${costFmt.format(item.currentCost)}"
                    b.itemRoot.alpha   = 1.0f
                }
            }

            b.btnBuy.setOnClickListener {
                if (item.isUnlocked && item.canAfford) onBuyClick(hw.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHardwareBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(items[position])

    override fun getItemCount() = items.size
}
