package com.example.neuralnetinc.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.neuralnetinc.databinding.ItemHardwareBinding
import java.text.DecimalFormat

/**
 * HardwareAdapter — RecyclerView adapter for the hardware shop.
 *
 * All tiers are always shown. Locked tiers show a "LOCKED" label and
 * a dimmed disabled button — the row itself is never hidden so the
 * player always sees what's coming next.
 */
class HardwareAdapter(
    private val onBuyClick: (hardwareId: String) -> Unit
) : ListAdapter<HardwareDisplayItem, HardwareAdapter.ViewHolder>(DIFF_CALLBACK) {

    private val costFmt    = DecimalFormat("#,##0.00")
    private val computeFmt = DecimalFormat("#,##0.0##")
    private val statFmt    = DecimalFormat("#,##0.0")

    inner class ViewHolder(private val b: ItemHardwareBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(item: HardwareDisplayItem) {
            val hw = item.hardware

            b.tvHardwareName.text  = hw.name
            b.tvHardwareDesc.text  = hw.description
            b.tvOwnedCount.text    = "\u00D7${item.owned}"
            b.tvComputeStat.text   = "${computeFmt.format(hw.computeOutput)} GF/s"
            b.tvPowerStat.text     = "${statFmt.format(hw.powerUsage)} kW"
            b.tvHeatStat.text      = "${statFmt.format(hw.heatOutput)}\u00B0/s"

            when {
                !item.isUnlocked -> {
                    // Show the row, lock the button — player sees what's next
                    b.btnBuy.isEnabled = false
                    b.btnBuy.alpha     = 0.3f
                    b.tvBuyCost.text   = "\uD83D\uDD12  Buy ${hw.prerequisiteCount}x prev tier to unlock"
                    b.itemRoot.alpha   = 0.55f
                }
                !item.canAfford -> {
                    b.btnBuy.isEnabled = false
                    b.btnBuy.alpha     = 0.45f
                    b.tvBuyCost.text   = "Need \$${costFmt.format(item.currentCost)}"
                    b.itemRoot.alpha   = 1.0f
                }
                else -> {
                    b.btnBuy.isEnabled = true
                    b.btnBuy.alpha     = 1.0f
                    b.tvBuyCost.text   = "\$${costFmt.format(item.currentCost)}"
                    b.itemRoot.alpha   = 1.0f
                }
            }

            b.btnBuy.setOnClickListener {
                if (item.isUnlocked && item.canAfford) onBuyClick(hw.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHardwareBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<HardwareDisplayItem>() {
            override fun areItemsTheSame(a: HardwareDisplayItem, b: HardwareDisplayItem) =
                a.hardware.id == b.hardware.id

            override fun areContentsTheSame(a: HardwareDisplayItem, b: HardwareDisplayItem) =
                a == b
        }
    }
}
