package com.example.neuralnetinc.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.neuralnetinc.R
import com.example.neuralnetinc.databinding.ItemHardwareBinding
import java.text.DecimalFormat

/**
 * HardwareAdapter — RecyclerView adapter for the hardware shop.
 * Uses ListAdapter + DiffUtil for efficient updates (called every tick).
 *
 * @param onBuyClick  Called with hardware.id when the Buy button is tapped.
 */
class HardwareAdapter(
    private val onBuyClick: (hardwareId: String) -> Unit
) : ListAdapter<HardwareDisplayItem, HardwareAdapter.ViewHolder>(DIFF_CALLBACK) {

    private val costFmt    = DecimalFormat("#,##0.00")
    private val computeFmt = DecimalFormat("#,##0.0##")
    private val statFmt    = DecimalFormat("#,##0.0")

    inner class ViewHolder(private val b: ItemHardwareBinding) :
        RecyclerView.ViewHolder(b.root) {

        fun bind(item: HardwareDisplayItem) {
            val hw = item.hardware

            b.tvHardwareName.text    = hw.name
            b.tvHardwareDesc.text    = hw.description
            b.tvOwnedCount.text      = "×${item.owned}"
            b.tvComputeStat.text     = "${computeFmt.format(hw.computeOutput)} GF/s"
            b.tvPowerStat.text       = "${statFmt.format(hw.powerUsage)} kW"
            b.tvHeatStat.text        = "${statFmt.format(hw.heatOutput)} \u00B0/s"
            b.tvBuyCost.text         = "BUY  \$${costFmt.format(item.currentCost)}"

            when {
                !item.isUnlocked -> {
                    b.btnBuy.isEnabled = false
                    b.btnBuy.alpha     = 0.35f
                    b.tvBuyCost.text   = "LOCKED — ${computeFmt.format(hw.unlockRequirement)} GF needed"
                }
                !item.canAfford  -> {
                    b.btnBuy.isEnabled = false
                    b.btnBuy.alpha     = 0.5f
                }
                else -> {
                    b.btnBuy.isEnabled = true
                    b.btnBuy.alpha     = 1.0f
                }
            }

            b.btnBuy.setOnClickListener {
                if (item.isUnlocked && item.canAfford) onBuyClick(hw.id)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHardwareBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<HardwareDisplayItem>() {
            override fun areItemsTheSame(a: HardwareDisplayItem, b: HardwareDisplayItem) =
                a.hardware.id == b.hardware.id

            override fun areContentsTheSame(a: HardwareDisplayItem, b: HardwareDisplayItem) =
                a == b
        }
    }
}
