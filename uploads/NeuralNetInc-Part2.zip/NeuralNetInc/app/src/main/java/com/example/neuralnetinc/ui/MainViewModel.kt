package com.example.neuralnetinc.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.data.HardwareCatalog
import com.example.neuralnetinc.engine.GameLoop
import com.example.neuralnetinc.engine.TickSystem
import com.example.neuralnetinc.repository.GameRepository
import com.example.neuralnetinc.systems.EconomyManager
import com.example.neuralnetinc.systems.HardwareCalculator
import com.example.neuralnetinc.systems.HardwareSystem
import com.example.neuralnetinc.systems.HeatManager
import com.example.neuralnetinc.systems.PowerManager
import com.example.neuralnetinc.systems.SaveManager
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * MainViewModel — single source of truth for the UI.
 *
 * Fix: removed the derived hardwareItems StateFlow (was SharingStarted.Lazily
 * which caused an empty-list flash). The Activity now calls
 * buildHardwareDisplayList() directly inside its single gameState collector.
 */
class MainViewModel(
    private val repository: GameRepository
) : ViewModel() {

    // ── Manual DI ─────────────────────────────────────────────────
    private val economyManager     = EconomyManager()
    private val heatManager        = HeatManager()
    private val powerManager       = PowerManager()
    val hardwareSystem             = HardwareSystem()
    private val hardwareCalculator = HardwareCalculator(hardwareSystem, heatManager, powerManager)
    private val tickSystem         = TickSystem(economyManager, hardwareCalculator)
    private val gameLoop           = GameLoop(tickSystem)
    private val saveManager        = SaveManager(repository, economyManager)

    // ── Public state ──────────────────────────────────────────────
    val gameState: StateFlow<GameState?> = gameLoop.gameState

    // ── Init ──────────────────────────────────────────────────────
    init { loadAndStart() }

    private fun loadAndStart() {
        viewModelScope.launch {
            val state = saveManager.loadGame()
            val ready = hardwareCalculator.recalculate(state)
            gameLoop.start(
                scope        = viewModelScope,
                initialState = ready,
                onAutoSave   = { latest -> saveManager.saveGame(latest) }
            )
        }
    }

    // ── Hardware display list (called by Activity on each state emit) ──

    /**
     * Build the RecyclerView list from the current GameState.
     * Called directly by MainActivity's single collector — no intermediate
     * StateFlow, no empty-list flash, always in sync with displayed stats.
     */
    fun buildHardwareDisplayList(state: GameState): List<HardwareDisplayItem> =
        HardwareCatalog.ALL.map { hw ->
            val owned = hardwareSystem.getOwnedCount(state, hw)
            val cost  = hardwareSystem.currentCost(hw, owned)
            HardwareDisplayItem(
                hardware    = hw,
                owned       = owned,
                currentCost = cost,
                isUnlocked  = hardwareSystem.isUnlocked(state, hw),
                canAfford   = state.money >= cost
            )
        }

    // ── Actions ───────────────────────────────────────────────────

    fun buyHardware(hardwareId: String) {
        val current      = gameState.value ?: return
        val purchased    = hardwareSystem.buyHardware(current, hardwareId) ?: return
        val recalculated = hardwareCalculator.recalculate(purchased)
        gameLoop.updateState(recalculated)
    }

    fun saveGame() {
        viewModelScope.launch {
            gameState.value?.let { saveManager.saveGame(it) }
        }
    }

    fun applyStateChange(newState: GameState) {
        gameLoop.updateState(newState)
    }

    // ── Lifecycle ─────────────────────────────────────────────────
    override fun onCleared() {
        super.onCleared()
        gameLoop.stop()
    }

    class Factory(private val repository: GameRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(repository) as T
    }
}
