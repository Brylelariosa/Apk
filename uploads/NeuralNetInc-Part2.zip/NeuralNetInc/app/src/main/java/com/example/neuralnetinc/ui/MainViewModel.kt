package com.example.neuralnetinc.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.data.HardwareCatalog
import com.example.neuralnetinc.engine.GameLoop
import com.example.neuralnetinc.engine.TickSystem
import com.example.neuralnetinc.repository.GameRepository
import com.example.neuralnetinc.systems.EconomyManager
import com.example.neuralnetinc.systems.HardwareCalculator
import com.example.neuralnetinc.systems.HardwareSystem
import com.example.neuralnetinc.systems.HeatManager
import com.example.neuralnetinc.systems.PowerManager
import com.example.neuralnetinc.systems.SaveManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * MainViewModel — single source of truth for the UI.
 *
 * Part 2 additions:
 *   - hardwareSystem / hardwareCalculator wired into dependency graph
 *   - TickSystem now receives HardwareCalculator
 *   - hardwareItems StateFlow computed from gameState for the shop RecyclerView
 *   - buyHardware() action: deducts cost, increments count, recalculates stats
 */
class MainViewModel(
    private val repository: GameRepository
) : ViewModel() {

    // ── Manual DI ─────────────────────────────────────────────────
    private val economyManager     = EconomyManager()
    private val heatManager        = HeatManager()
    private val powerManager       = PowerManager()
    val hardwareSystem             = HardwareSystem()
    private val hardwareCalculator = HardwareCalculator(hardwareSystem, heatManager, powerManager)
    private val tickSystem         = TickSystem(economyManager, hardwareCalculator)
    private val gameLoop           = GameLoop(tickSystem)
    private val saveManager        = SaveManager(repository, economyManager)

    // ── Public state ──────────────────────────────────────────────

    val gameState: StateFlow<GameState?> = gameLoop.gameState

    /**
     * Hardware display list — recomputed from GameState on every emission.
     * The adapter uses DiffUtil so only changed rows re-bind.
     */
    val hardwareItems: StateFlow<List<HardwareDisplayItem>> = gameState
        .filterNotNull()
        .map { state -> buildHardwareList(state) }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // ── Init ──────────────────────────────────────────────────────

    init { loadAndStart() }

    private fun loadAndStart() {
        viewModelScope.launch {
            val state = saveManager.loadGame()
            // Recalculate derived stats immediately on load.
            val ready = hardwareCalculator.recalculate(state)
            gameLoop.start(
                scope        = viewModelScope,
                initialState = ready,
                onAutoSave   = { latest -> saveManager.saveGame(latest) }
            )
        }
    }

    // ── Actions ───────────────────────────────────────────────────

    /**
     * Attempt to buy one unit of the specified hardware.
     * If successful, immediately recalculates derived stats so the UI
     * reflects the change without waiting for the next tick.
     */
    fun buyHardware(hardwareId: String) {
        val current = gameState.value ?: return
        val purchased = hardwareSystem.buyHardware(current, hardwareId) ?: return
        val recalculated = hardwareCalculator.recalculate(purchased)
        gameLoop.updateState(recalculated)
    }

    fun saveGame() {
        viewModelScope.launch {
            gameState.value?.let { saveManager.saveGame(it) }
        }
    }

    fun applyStateChange(newState: GameState) {
        gameLoop.updateState(newState)
    }

    // ── Helpers ───────────────────────────────────────────────────

    private fun buildHardwareList(state: GameState): List<HardwareDisplayItem> =
        HardwareCatalog.ALL.map { hw ->
            val owned   = hardwareSystem.getOwnedCount(state, hw)
            val cost    = hardwareSystem.currentCost(hw, owned)
            HardwareDisplayItem(
                hardware    = hw,
                owned       = owned,
                currentCost = cost,
                isUnlocked  = hardwareSystem.isUnlocked(state, hw),
                canAfford   = state.money >= cost
            )
        }

    // ── Lifecycle ─────────────────────────────────────────────────

    override fun onCleared() {
        super.onCleared()
        gameLoop.stop()
    }

    class Factory(private val repository: GameRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            MainViewModel(repository) as T
    }
}
