package com.example.neuralnetinc.engine

import com.example.neuralnetinc.data.GameState
import com.example.neuralnetinc.systems.EconomyManager
import com.example.neuralnetinc.systems.HardwareCalculator

/**
 * TickSystem — processes one game tick.
 *
 * Part 2 change: before applying the economy tick, HardwareCalculator
 * recalculates all derived hardware stats (computePerSecond, heat, power,
 * efficiency). This keeps state consistent without requiring the ViewModel
 * to manually trigger recalculation every second.
 *
 * Tick order each second:
 *   1. HardwareCalculator.recalculate(state) → updates derived fields
 *   2. EconomyManager.applyTick(recalculated) → adds resources
 */
class TickSystem(
    private val economyManager: EconomyManager,
    private val hardwareCalculator: HardwareCalculator
) {

    private var tickCount = 0

    /**
     * Process one tick. Recalculates hardware stats then applies economy.
     */
    fun tick(currentState: GameState): GameState {
        tickCount++
        val recalculated = hardwareCalculator.recalculate(currentState)
        return economyManager.applyTick(recalculated)
    }

    fun shouldAutoSave(interval: Int): Boolean =
        tickCount > 0 && tickCount % interval == 0

    fun resetTickCount() { tickCount = 0 }

    fun getTickCount(): Int = tickCount
}
