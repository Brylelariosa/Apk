package com.example.neuralnetinc.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for GameState.
 * Uses a single row (id = 1) pattern — the game has one save slot.
 */
@Dao
interface GameStateDao {

    /** Observe the game state reactively (updates UI on every DB write). */
    @Query("SELECT * FROM game_state WHERE id = 1")
    fun observeGameState(): Flow<GameState?>

    /** One-shot load for initial startup or save checks. */
    @Query("SELECT * FROM game_state WHERE id = 1")
    suspend fun loadGameState(): GameState?

    /** Upsert — always replaces the single row. */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveGameState(state: GameState)
}
