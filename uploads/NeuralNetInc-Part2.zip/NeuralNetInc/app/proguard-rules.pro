# NeuralNet Inc. ProGuard Rules
-keep class com.example.neuralnetinc.data.** { *; }
