package com.launcher.engineermode;

import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TARGET_PACKAGE = "com.sprd.engineermode";
    private static final String TARGET_CLASS   = "com.sprd.engineermode.EngineerModeActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        launchEngineerMode();
    }

    private void launchEngineerMode() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(TARGET_PACKAGE, TARGET_CLASS));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
            finish();
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this,
                    "EngineerMode not found on this device.\n(" + TARGET_PACKAGE + ")",
                    Toast.LENGTH_LONG).show();
        } catch (SecurityException e) {
            Toast.makeText(this,
                    "Permission denied — device may require root or system privileges.",
                    Toast.LENGTH_LONG).show();
        }
    }
}
