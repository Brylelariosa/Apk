package com.romexplorer.gba.core.analysis.model

import kotlinx.serialization.Serializable

/**
 * One classified byte range of the ROM. [confidence] is in 0f..1f and is
 * only meaningful for heuristic detectors (HEADER is always 1.0; UNKNOWN is
 * always 0.0 since it represents "nothing claimed this range", not a guess).
 */
@Serializable
data class RomRegion(
    val startOffset: Long,
    val endOffsetExclusive: Long,
    val type: RegionType,
    val confidence: Float,
    val label: String = type.displayName,
) {
    val length: Long get() = endOffsetExclusive - startOffset
}

@Serializable
data class RomMap(
    val romSizeBytes: Long,
    val regions: List<RomRegion>,
)
