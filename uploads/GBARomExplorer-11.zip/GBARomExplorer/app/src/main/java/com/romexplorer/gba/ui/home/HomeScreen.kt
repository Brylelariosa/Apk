@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.ui.common.ErrorBanner
import com.romexplorer.gba.ui.common.SectionHeader
import com.romexplorer.gba.ui.navigation.Screen
import kotlinx.coroutines.launch
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavHostController, viewModel: HomeViewModel = koinViewModel()) {
    val session by viewModel.session.collectAsState()
    val recents by viewModel.recents.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val scope = rememberCoroutineScope()
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = viewModel.openRom(uri)
                if (ok) {
                    navController.navigate(Screen.RomInfo.route)
                } else {
                    errorMessage = viewModel.lastError ?: "Failed to open ROM"
                }
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("GBA ROM Explorer") }) }) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Button(
                    onClick = { openDocumentLauncher.launch(arrayOf("*/*")) },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null)
                    Text("  Open ROM File")
                }
            }

            errorMessage?.let { msg ->
                item { ErrorBanner(message = msg) }
            }

            session?.let { current ->
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        onClick = { navController.navigate(Screen.RomInfo.route) },
                    ) {
                        ListItem(
                            headlineContent = { Text(current.displayName) },
                            supportingContent = { Text("Currently open · tap for details") },
                            leadingContent = { Icon(Icons.Filled.VideogameAsset, contentDescription = null) },
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedButton(
                        onClick = { navController.navigate(Screen.Analyzer.route) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.Analytics, contentDescription = null)
                        Text(" Analyze")
                    }
                    OutlinedButton(
                        onClick = { navController.navigate(Screen.Patch.route) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Text("Patch ROM")
                    }
                    OutlinedButton(
                        onClick = { navController.navigate(Screen.Tools.route) },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.Build, contentDescription = null)
                        Text(" Tools")
                    }
                }
            }

            val favoriteEntries = recents.filter { it.uri in favorites }
            if (favoriteEntries.isNotEmpty()) {
                item { SectionHeader("Favorites") }
                items(favoriteEntries, key = { "fav_" + it.uri }) { entry ->
                    RomListRow(
                        displayName = entry.displayName,
                        isFavorite = true,
                        onOpen = {
                            scope.launch {
                                if (viewModel.openRom(android.net.Uri.parse(entry.uri))) {
                                    navController.navigate(Screen.RomInfo.route)
                                } else {
                                    errorMessage = viewModel.lastError ?: "Failed to open ROM"
                                }
                            }
                        },
                        onToggleFavorite = { viewModel.toggleFavorite(entry.uri) },
                        onRemove = { viewModel.removeRecent(entry.uri) },
                    )
                }
            }

            item { SectionHeader("Recent ROMs") }
            if (recents.isEmpty()) {
                item { Text("No ROMs opened yet. Use \"Open ROM File\" to get started.") }
            }
            items(recents, key = { "recent_" + it.uri }) { entry ->
                RomListRow(
                    displayName = entry.displayName,
                    isFavorite = entry.uri in favorites,
                    onOpen = {
                        scope.launch {
                            if (viewModel.openRom(android.net.Uri.parse(entry.uri))) {
                                navController.navigate(Screen.RomInfo.route)
                            } else {
                                errorMessage = viewModel.lastError ?: "Failed to open ROM"
                            }
                        }
                    },
                    onToggleFavorite = { viewModel.toggleFavorite(entry.uri) },
                    onRemove = { viewModel.removeRecent(entry.uri) },
                )
            }
        }
    }
}

@Composable
private fun RomListRow(
    displayName: String,
    isFavorite: Boolean,
    onOpen: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRemove: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth(), onClick = onOpen) {
        ListItem(
            headlineContent = { Text(displayName) },
            trailingContent = {
                Row {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                            contentDescription = if (isFavorite) "Unfavorite" else "Favorite",
                        )
                    }
                    IconButton(onClick = onRemove) {
                        Icon(Icons.Filled.Delete, contentDescription = "Remove")
                    }
                }
            },
        )
    }
}
