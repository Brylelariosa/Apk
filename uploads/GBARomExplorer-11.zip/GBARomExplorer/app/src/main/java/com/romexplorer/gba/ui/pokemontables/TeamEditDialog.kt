package com.romexplorer.gba.ui.pokemontables

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.romexplorer.gba.core.pokemon.TrainerPartyMember

private const val MAX_PARTY_SIZE = 6

/**
 * Full team editor for one trainer — the real party reached via this
 * trainer's "Party Pointer" (see
 * [com.romexplorer.gba.core.pokemon.TrainerPartyReader]), editable rather
 * than just displayed. Editing an existing Pokémon's species/level/item/
 * moves writes in place; adding or removing one relocates the whole party
 * to free space (see
 * [com.romexplorer.gba.core.pokemon.TrainerPartyWriter.resize] for why).
 */
@Composable
fun TeamEditDialog(
    trainerRowIndex: Int,
    trainerName: String,
    partyFlags: Int,
    members: List<TrainerPartyMember>,
    viewModel: PokemonTableViewModel,
    onDismiss: () -> Unit,
) {
    val hasItem = partyFlags and 0x2 != 0
    val hasMoves = partyFlags and 0x1 != 0
    var editingIndex by remember { mutableStateOf<Int?>(null) }

    val speciesNames by produceState(initialValue = emptyMap<Int, String>()) { value = viewModel.speciesNameOptions() }
    val itemNames by produceState(initialValue = emptyMap<Int, String>()) { value = viewModel.itemNameOptions() }
    val moveNames by produceState(initialValue = emptyMap<Int, String>()) { value = viewModel.moveNameOptions() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("$trainerName's team") },
        text = {
            Column {
                LazyColumn(modifier = Modifier.height(320.dp)) {
                    itemsIndexed(members) { index, member ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column(modifier = Modifier.clickable { editingIndex = index }) {
                                Text(
                                    "Lv.${member.level} ${speciesNames[member.species] ?: "Species #${member.species}"}",
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                val itemSuffix = member.heldItem
                                    ?.takeIf { it != 0 }
                                    ?.let { " @ " + (itemNames[it] ?: "Item #$it") }
                                    .orEmpty()
                                val movesSuffix = member.moves
                                    ?.filter { it != 0 }
                                    ?.joinToString("/") { moveNames[it] ?: "Move #$it" }
                                    ?.takeIf { it.isNotBlank() }
                                    ?.let { " — $it" }
                                    .orEmpty()
                                Text(
                                    ("$itemSuffix$movesSuffix").ifBlank { "Tap to edit" },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                if (hasMoves && member.moves?.all { it == 0 } == true) {
                                    Text(
                                        "⚠ No moves set — will likely crash the game in battle",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error,
                                    )
                                }
                            }
                            IconButton(onClick = {
                                val updated = members.toMutableList().apply { removeAt(index) }
                                viewModel.resizeTrainerParty(trainerRowIndex, updated)
                            }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Remove this Pokémon")
                            }
                        }
                        HorizontalDivider()
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(
                    onClick = {
                        val updated = members + TrainerPartyMember(
                            species = 1,
                            level = 5,
                            heldItem = if (hasItem) 0 else null,
                            // MOVE_POUND (1) in slot 0, not 0 in every slot: a
                            // custom-moveset trainer Pokémon with all four
                            // slots at 0 has zero real moves at all — not the
                            // same as a Pokémon that just knows fewer than 4
                            // (completely normal), but a state the real battle
                            // engine isn't built to hit, and the reported
                            // cause of a real black-screen crash battling a
                            // trainer edited this way. One safe, always-valid
                            // move here means a freshly added Pokémon is
                            // never in that state, even before anyone opens
                            // the Moves section below to set real ones.
                            moves = if (hasMoves) listOf(1, 0, 0, 0) else null,
                        )
                        viewModel.resizeTrainerParty(trainerRowIndex, updated)
                    },
                    enabled = members.size < MAX_PARTY_SIZE,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (members.size < MAX_PARTY_SIZE) "+ Add Pokémon" else "Party is full (max $MAX_PARTY_SIZE)")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
    )

    val editIdx = editingIndex
    if (editIdx != null && editIdx < members.size) {
        PartyMemberEditDialog(
            member = members[editIdx],
            hasItem = hasItem,
            hasMoves = hasMoves,
            speciesNames = speciesNames,
            itemNames = itemNames,
            moveNames = moveNames,
            onDismiss = { editingIndex = null },
            onSave = { updated ->
                viewModel.editTrainerPartyMember(trainerRowIndex, editIdx, updated)
                editingIndex = null
            },
        )
    }
}

private sealed class PartyPickerTarget {
    data object Species : PartyPickerTarget()
    data object Item : PartyPickerTarget()
    data class Move(val slot: Int) : PartyPickerTarget()
}

@Composable
private fun PartyMemberEditDialog(
    member: TrainerPartyMember,
    hasItem: Boolean,
    hasMoves: Boolean,
    speciesNames: Map<Int, String>,
    itemNames: Map<Int, String>,
    moveNames: Map<Int, String>,
    onDismiss: () -> Unit,
    onSave: (TrainerPartyMember) -> Unit,
) {
    var species by remember(member) { mutableStateOf(member.species) }
    var level by remember(member) { mutableStateOf(member.level.toString()) }
    var heldItem by remember(member) { mutableStateOf(member.heldItem ?: 0) }
    var moves by remember(member) { mutableStateOf(member.moves ?: List(4) { 0 }) }
    var activePicker by remember { mutableStateOf<PartyPickerTarget?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Pokémon") },
        text = {
            Column {
                LabeledPickerRow("Species", speciesNames[species] ?: "Species #$species") { activePicker = PartyPickerTarget.Species }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = level,
                    onValueChange = { level = it.filter(Char::isDigit).take(3) },
                    label = { Text("Level (1-100)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (hasItem) {
                    Spacer(Modifier.height(8.dp))
                    LabeledPickerRow(
                        "Held item",
                        heldItem.takeIf { it != 0 }?.let { itemNames[it] ?: "Item #$it" } ?: "None",
                    ) { activePicker = PartyPickerTarget.Item }
                }
                if (hasMoves) {
                    Spacer(Modifier.height(8.dp))
                    Text("Moves", style = MaterialTheme.typography.labelMedium)
                    moves.forEachIndexed { slot, moveId ->
                        LabeledPickerRow(
                            "Move ${slot + 1}",
                            moveId.takeIf { it != 0 }?.let { moveNames[it] ?: "Move #$it" } ?: "—",
                        ) { activePicker = PartyPickerTarget.Move(slot) }
                    }
                    if (moves.all { it == 0 }) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "This Pokémon has no moves set at all — battling this trainer will likely crash the game (black screen). Set at least one move above before saving.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val newLevel = level.toIntOrNull()?.coerceIn(1, 100) ?: member.level
                onSave(
                    TrainerPartyMember(
                        species = species,
                        level = newLevel,
                        heldItem = if (hasItem) heldItem else null,
                        moves = if (hasMoves) moves else null,
                    ),
                )
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )

    when (val target = activePicker) {
        PartyPickerTarget.Species -> NamePickerDialog(
            title = "Choose species",
            unknownLabel = "Species",
            loadOptions = { speciesNames },
            onDismiss = { activePicker = null },
            onSelect = { id -> species = id; activePicker = null },
        )
        PartyPickerTarget.Item -> NamePickerDialog(
            title = "Choose held item",
            unknownLabel = "Item",
            loadOptions = { mapOf(0 to "None") + itemNames },
            onDismiss = { activePicker = null },
            onSelect = { id -> heldItem = id; activePicker = null },
        )
        is PartyPickerTarget.Move -> NamePickerDialog(
            title = "Choose move ${target.slot + 1}",
            unknownLabel = "Move",
            loadOptions = { mapOf(0 to "—") + moveNames },
            onDismiss = { activePicker = null },
            onSelect = { id -> moves = moves.toMutableList().apply { this[target.slot] = id }; activePicker = null },
        )
        null -> Unit
    }
}

@Composable
private fun LabeledPickerRow(label: String, value: String, onClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
