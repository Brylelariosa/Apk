package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.rom.RomAccessor

sealed class FieldWriteResult {
    data object Success : FieldWriteResult()
    data object OutOfRange : FieldWriteResult()
    data object NotEditable : FieldWriteResult()
    data object OutOfBounds : FieldWriteResult()
}

/**
 * Writes one field's new value back into the ROM, via the same per-byte
 * [EditOverlay] the hex editor uses (see [com.romexplorer.gba.data.repository.RomSession.editOverlay])
 * — nothing here mutates the ROM file directly, and edits made through a
 * table view and edits made through the hex editor are the same overlay,
 * visible and undoable from either screen.
 *
 * Only plain numeric fields are supported. [FieldKind.POKEMON_STRING] isn't
 * — text has its own character encoding, a different kind of edit than a
 * number. [FieldKind.POINTER32] isn't either — a pointer is a file address,
 * and editing it means relocating data, not changing a stat; that's a
 * different, much riskier operation than this UI is meant for.
 */
object PokemonTableWriter {

    suspend fun write(
        rom: RomAccessor,
        overlay: EditOverlay,
        schema: KnownTableSchema,
        rowIndex: Int,
        field: TableField,
        newValue: Long,
    ): FieldWriteResult {
        if (field.kind == FieldKind.POKEMON_STRING || field.kind == FieldKind.POINTER32) return FieldWriteResult.NotEditable
        if (newValue !in validRange(field.kind)) return FieldWriteResult.OutOfRange

        val entryStart = schema.romOffset + rowIndex.toLong() * schema.entrySize
        val fieldStart = entryStart + field.byteOffset
        if (fieldStart < 0 || fieldStart + field.byteLength > rom.sizeBytes) return FieldWriteResult.OutOfBounds

        // Little-endian, low byte first — the exact inverse of PokemonTableReader.readLeUnsigned,
        // so a value written here decodes back to itself afterward.
        for (i in 0 until field.byteLength) {
            val byteOffset = fieldStart + i
            val newByte = ((newValue shr (8 * i)) and 0xFF).toInt()
            val originalByte = rom.readByte(byteOffset)
            if (originalByte < 0) return FieldWriteResult.OutOfBounds
            overlay.setByte(byteOffset, newByte, originalByte)
        }
        return FieldWriteResult.Success
    }

    /** The set of values that fit back into [byteLength] bytes the way [kind] interprets them. */
    fun validRange(kind: FieldKind): LongRange = when (kind) {
        FieldKind.UINT8 -> 0L..255L
        FieldKind.INT8 -> -128L..127L
        FieldKind.UINT16 -> 0L..65_535L
        FieldKind.UINT24 -> 0L..16_777_215L
        FieldKind.UINT32 -> 0L..4_294_967_295L
        FieldKind.POINTER32, FieldKind.POKEMON_STRING -> LongRange.EMPTY
    }

    /**
     * Writes a name into a schema's own embedded [FieldKind.POKEMON_STRING] field
     * (e.g. an item's "Name") — unlike [write], which deliberately refuses text
     * fields for ordinary stat edits, this is the one path that's meant to touch
     * them: naming a previously-blank, unused table slot the user has chosen to
     * claim as a new entry (see [UnusedSlotDetector]). Ordinary renames of an
     * already-used entry go through the same call; nothing here distinguishes
     * "new" from "rename" at the byte level, only the caller's UI does.
     */
    suspend fun writeName(
        rom: RomAccessor,
        overlay: EditOverlay,
        schema: KnownTableSchema,
        rowIndex: Int,
        field: TableField,
        newName: String,
    ): FieldWriteResult {
        if (field.kind != FieldKind.POKEMON_STRING) return FieldWriteResult.NotEditable
        val entryStart = schema.romOffset + rowIndex.toLong() * schema.entrySize
        val fieldStart = entryStart + field.byteOffset
        if (fieldStart < 0 || fieldStart + field.byteLength > rom.sizeBytes) return FieldWriteResult.OutOfBounds

        val encoded = PokemonTextCodec.encode(newName, field.byteLength)
        for (i in 0 until field.byteLength) {
            val byteOffset = fieldStart + i
            val originalByte = rom.readByte(byteOffset)
            if (originalByte < 0) return FieldWriteResult.OutOfBounds
            overlay.setByte(byteOffset, encoded[i].toInt() and 0xFF, originalByte)
        }
        return FieldWriteResult.Success
    }
}
