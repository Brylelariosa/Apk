package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

/** One party member this app can't confirm is real trainer data — see [CorruptedPartyScanner]'s doc. */
data class SuspiciousPartyMember(val memberIndex: Int, val species: Int, val level: Int, val reason: String)

data class SuspiciousTrainer(val trainerRowIndex: Int, val trainerName: String, val members: List<SuspiciousPartyMember>)

/**
 * Scans every trainer's party for a member that can't plausibly be real
 * game data:
 *  - level 0 — FireRed's own level field is 1-100; no real trainer
 *    Pokémon is level 0.
 *  - a species whose name is blank, or is the placeholder pattern FireRed
 *    itself uses for a handful of reserved/unused species slots between
 *    the original 251 and the Gen 3 additions — a run of literal "?"
 *    characters (e.g. "??????????"). A real trainer's Pokémon is never
 *    one of these — nobody canonically owns a reserved slot.
 *
 * Built to find every trainer damaged by the free-space collision bug
 * [TrainerPartyWriter.resize] (via [com.romexplorer.gba.ui.pokemontables.PokemonTableViewModel.resizeTrainerParty])
 * now prevents — a party relocation that landed on top of a *different*,
 * untouched trainer's real data, because a Pokémon's `iv` field is
 * conventionally 0xFFFF, the same byte [com.romexplorer.gba.core.common.FreeSpaceAllocator]'s
 * free-space scan treats as unused ROM space. That's fixed going forward,
 * but a ROM already exported while the bug was active has the corrupted
 * bytes baked in permanently — no calculation recovers bytes once
 * they're overwritten, so this exists to find every trainer that needs a
 * manual fix, rather than only the ones someone happens to search for by
 * name.
 *
 * Deliberately has no idea what the *correct* data should be — restoring
 * that means knowing this specific trainer's real, intended team, which a
 * general scan can't know and this doesn't try to guess. It only finds
 * where to look; fixing what it finds is exactly the Edit Team dialog
 * this app already has, same as any other edit.
 */
object CorruptedPartyScanner {
    private val VALID_LEVEL_RANGE = 1..100

    suspend fun scan(rom: RomAccessor, overlay: EditOverlay?): List<SuspiciousTrainer> = coroutineScope {
        val table = PokemonTableReader.read(rom, FireRedTables.trainers, overlay)
        val speciesNames = NameTableLookup.build(rom, FireRedTables.SPECIES_NAMES_OFFSET, FireRedTables.SPECIES_NAME_LENGTH, FireRedTables.speciesBaseStats.entryCount)

        table.rows.map { row ->
            async {
                val partyFlags = (row.values["Party Flags"] as? Long)?.toInt() ?: 0
                val partyPointer = row.values["Party Pointer"] as? Long ?: 0L
                val partySize = (row.values["Party Size"] as? Long)?.toInt() ?: 0
                val members = TrainerPartyReader.read(rom, partyFlags, partyPointer, partySize, overlay)
                val flagged = members.mapIndexedNotNull { i, member -> flagIfSuspicious(i, member, speciesNames) }
                if (flagged.isEmpty()) {
                    null
                } else {
                    val trainerName = row.values["Name"] as? String
                    SuspiciousTrainer(row.index, trainerName?.takeIf { it.isNotBlank() } ?: "Trainer #${row.index}", flagged)
                }
            }
        }.awaitAll().filterNotNull()
    }

    private fun flagIfSuspicious(memberIndex: Int, member: TrainerPartyMember, speciesNames: Map<Int, String>): SuspiciousPartyMember? {
        val name = speciesNames[member.species]
        val reason = when {
            member.level !in VALID_LEVEL_RANGE -> "level ${member.level}"
            name.isNullOrBlank() -> "species #${member.species} has no name"
            name.all { it == '?' } -> "species is a reserved/unused slot ($name), not a real Pokémon"
            else -> null
        } ?: return null
        return SuspiciousPartyMember(memberIndex, member.species, member.level, reason)
    }
}
