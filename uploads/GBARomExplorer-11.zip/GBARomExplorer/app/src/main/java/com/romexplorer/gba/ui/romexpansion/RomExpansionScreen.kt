@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.romexpansion

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.domain.usecase.RomExpansionTarget
import com.romexplorer.gba.ui.common.ErrorBanner
import com.romexplorer.gba.ui.common.SectionHeader
import org.koin.androidx.compose.koinViewModel

@Composable
fun RomExpansionScreen(navController: NavHostController, viewModel: RomExpansionViewModel = koinViewModel()) {
    val state by viewModel.state.collectAsState()
    var selectedTarget by remember { mutableStateOf(RomExpansionTarget.SIZE_32MB) }

    val destinationPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { dest -> if (dest != null) viewModel.expand(dest, selectedTarget) }

    LaunchedEffect(state) {
        if (state is ExpansionState.Done) navController.popBackStack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ROM Expansion") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(
                "Grows this ROM's file size, padded with 0xFF — the same byte value this app already treats as free space, so every extra byte is immediately usable by the table, map, and script editors. Writes a new, larger file and switches to it; your current ROM file is left untouched.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Spacer(Modifier.height(16.dp))
            SectionHeader("Target size")
            RomExpansionTarget.entries.forEach { target ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().clickable { selectedTarget = target }.padding(vertical = 4.dp),
                ) {
                    RadioButton(selected = selectedTarget == target, onClick = { selectedTarget = target })
                    Text(target.label)
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { destinationPicker.launch("expanded_rom.gba") },
                enabled = state !is ExpansionState.Expanding,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (state is ExpansionState.Expanding) "Expanding…" else "Choose destination & expand")
            }
            val currentState = state
            if (currentState is ExpansionState.Failed) {
                Spacer(Modifier.height(12.dp))
                ErrorBanner(currentState.message)
            }
        }
    }
}
