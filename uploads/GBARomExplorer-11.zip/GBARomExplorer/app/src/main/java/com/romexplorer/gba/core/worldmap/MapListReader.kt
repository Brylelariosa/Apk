package com.romexplorer.gba.core.worldmap

import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/** One entry in the map list — resolved location, not yet the full decoded [MapHeaderData] (see [MapHeaderReader.read] for that, fetched lazily per map). */
data class MapListEntry(val id: MapId, val headerOffset: Long)

/**
 * Walks FireRed's map bank/group pointer table (see [FireRedMapTables]) to
 * build the full list of maps in this ROM. Neither the number of banks nor
 * the number of maps in a given bank is stored anywhere in the ROM itself
 * — it's implicit in the compiled pointer arrays' own lengths, which only
 * the compiler that built this ROM ever knew — so unlike every fixed-size
 * table in [com.romexplorer.gba.core.pokemon.FireRedTables], this can't
 * just read a known entry count. Instead each level stops as soon as the
 * next 4 bytes stop looking like a real pointer to a real [MapHeaderData]
 * (see [MapHeaderReader.looksLikeMapHeader]), with a generous hard cap
 * ([FireRedMapTables.MAX_MAP_GROUPS]/[FireRedMapTables.MAX_MAPS_PER_GROUP])
 * as a backstop against a corrupt or non-FireRed ROM scanning forever.
 */
object MapListReader {
    suspend fun listMaps(rom: RomAccessor): List<MapListEntry> {
        val result = mutableListOf<MapListEntry>()
        val groupTableOffset = FireRedMapTables.MAP_GROUP_TABLE_OFFSET

        for (group in 0 until FireRedMapTables.MAX_MAP_GROUPS) {
            val groupPtrOffset = groupTableOffset + group * 4L
            if (groupPtrOffset + 4 > rom.sizeBytes) break
            val groupArrayOffset = GbaGraphics.readPointer32(rom.read(groupPtrOffset, 4), 0) ?: break

            var foundAnyInGroup = false
            for (mapNum in 0 until FireRedMapTables.MAX_MAPS_PER_GROUP) {
                val headerPtrOffset = groupArrayOffset + mapNum * 4L
                if (headerPtrOffset + 4 > rom.sizeBytes) break
                val headerOffset = GbaGraphics.readPointer32(rom.read(headerPtrOffset, 4), 0) ?: break
                if (!MapHeaderReader.looksLikeMapHeader(rom, headerOffset)) break
                result += MapListEntry(MapId(group, mapNum), headerOffset)
                foundAnyInGroup = true
            }
            // A group with zero valid maps almost certainly means the group
            // pointer table itself has ended (this "group pointer" was
            // really unrelated ROM data that happened to look like one) —
            // stop there rather than continuing to scan past it.
            if (!foundAnyInGroup) break
        }
        return result
    }
}
