package com.romexplorer.gba.core.rom

/**
 * Detects the save type a GBA ROM expects by scanning for the well-known
 * ASCII ID strings that commercial GBA SDKs (and homebrew toolchains that
 * follow the same convention) embed near their save-related code, e.g.
 * "SRAM_V", "FLASH1M_V", "EEPROM_V". This is the same heuristic used by
 * hardware flash-carts and emulators to auto-configure save memory.
 *
 * The scan streams the ROM in overlapping chunks so it never needs the
 * whole file resident in memory, and stitches matches that straddle a
 * chunk boundary by carrying over a small tail from the previous chunk.
 */
object SaveTypeDetector {

    private val signatures: List<Pair<String, SaveType>> = listOf(
        "EEPROM_V" to SaveType.EEPROM,
        "SRAM_V" to SaveType.SRAM,
        "FLASH1M_V" to SaveType.FLASH_1M,
        "FLASH512_V" to SaveType.FLASH_512K,
        "FLASH_V" to SaveType.FLASH_512K,
    )

    private const val CHUNK_SIZE = 1 shl 20 // 1MB
    private val maxSignatureLength = signatures.maxOf { it.first.length }

    suspend fun detect(rom: RomAccessor): SaveType {
        var offset = 0L
        var carry = ByteArray(0)

        while (offset < rom.sizeBytes) {
            val length = minOf(CHUNK_SIZE.toLong(), rom.sizeBytes - offset).toInt()
            val chunk = rom.read(offset, length)
            val window = carry + chunk
            val windowText = window.toAsciiApprox()

            for ((sig, type) in signatures) {
                if (windowText.contains(sig)) return type
            }

            carry = if (window.size > maxSignatureLength) {
                window.copyOfRange(window.size - maxSignatureLength, window.size)
            } else {
                window
            }
            offset += length
        }
        return SaveType.NONE_DETECTED
    }

    /** Maps bytes to their ASCII char if printable, else a placeholder that
     * can never accidentally form part of a signature match. */
    private fun ByteArray.toAsciiApprox(): String {
        val sb = StringBuilder(size)
        for (b in this) {
            val c = b.toInt() and 0xFF
            sb.append(if (c in 0x20..0x7E) c.toChar() else '\u0000')
        }
        return sb.toString()
    }
}
