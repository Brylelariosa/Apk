package com.romexplorer.gba.core.pokescript

/**
 * Renders a [DisassembledScript] into the plain-text "pokescript" format
 * this app's script editor shows and accepts — one instruction per line,
 * `mnemonic arg1 arg2 ...`, pointer arguments written as `0x08XXXXXX` (the
 * same form XSE-era Gen III script tools use, so scripts copied out of
 * this app read naturally next to scripts written for those; see
 * [DisassembledArg]'s doc), everything else in decimal. [ScriptAssembler]
 * is this format's exact inverse.
 */
object ScriptTextFormatter {
    fun format(script: DisassembledScript): String {
        val lines = script.instructions.joinToString("\n") { formatInstruction(it) }
        val note = stopNote(script)
        return if (note != null) (if (lines.isBlank()) note else "$lines\n$note") else lines
    }

    private fun stopNote(script: DisassembledScript): String? = when (script.stopReason) {
        StopReason.TERMINATED -> null
        StopReason.UNKNOWN_OPCODE ->
            "// stopped: the byte at 0x${script.stoppedAtOffset.toString(16)} isn't a command this app has a verified layout for — see ScriptCommandTable"
        StopReason.OUT_OF_BOUNDS -> "// stopped: ran past the end of the ROM"
        StopReason.MAX_INSTRUCTIONS -> "// stopped: reached this app's instruction safety cap"
    }

    private fun formatInstruction(instruction: DisassembledInstruction): String {
        val args = instruction.args.joinToString(" ") { formatArg(it) }
        return if (args.isBlank()) instruction.mnemonic else "${instruction.mnemonic} $args"
    }

    private fun formatArg(arg: DisassembledArg): String = when (arg.type) {
        ArgType.POINTER -> "0x" + arg.rawValue.toString(16).uppercase().padStart(8, '0')
        else -> arg.rawValue.toString()
    }
}
