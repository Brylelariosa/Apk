package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Reads FireRed's item data table ([FireRedTables.items]) and builds an
 * item-ID -> item-name lookup, used to resolve the raw item-ID fields found
 * elsewhere (species held items, trainer party items — see their
 * [com.romexplorer.gba.core.pokemon.model.DisplayHint.ITEM_ID] fields)
 * instead of showing a bare index number.
 *
 * Item names are decoded the same way trainer names are (Gen III's
 * proprietary text encoding, via [PokemonTableReader]), so this is just the
 * items table read once and reshaped into a map — no new decoding logic.
 */
object ItemNameLookup {
    suspend fun build(rom: RomAccessor): Map<Int, String> =
        PokemonTableReader.read(rom, FireRedTables.items).rows.associate { row ->
            row.index to (row.values["Name"] as? String ?: "")
        }
}
