package com.romexplorer.gba.ui.pokemontables

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema

/**
 * "Add a new [entryLabel]" as this app can safely do it: claim one of the
 * table's own genuinely-unused, reserved slots (see [UnusedSlotDetector])
 * and give it a name — never expands or relocates the table, so it can't
 * corrupt anything outside the one slot claimed. Two steps: pick a slot,
 * then name it; the same flow regardless of which of the three tables
 * (items/species/moves) it's used for.
 */
@Composable
fun AddEntryFlow(
    schema: KnownTableSchema,
    entryLabel: String,
    viewModel: PokemonTableViewModel,
    onDismiss: () -> Unit,
    onClaimed: (index: Int, name: String) -> Unit,
) {
    var chosenSlot by remember { mutableStateOf<Int?>(null) }
    val slot = chosenSlot
    if (slot == null) {
        UnusedSlotPickerDialog(schema, entryLabel, viewModel, onDismiss, onPick = { chosenSlot = it })
    } else {
        NameEntryDialog(
            title = "Name new $entryLabel (slot #$slot)",
            onDismiss = onDismiss,
            onConfirm = { name -> onClaimed(slot, name) },
        )
    }
}

@Composable
private fun UnusedSlotPickerDialog(
    schema: KnownTableSchema,
    entryLabel: String,
    viewModel: PokemonTableViewModel,
    onDismiss: () -> Unit,
    onPick: (Int) -> Unit,
) {
    var loading by remember { mutableStateOf(true) }
    var slots by remember { mutableStateOf<List<Int>>(emptyList()) }

    LaunchedEffect(schema) {
        slots = viewModel.unusedSlotIndices(schema)
        loading = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add new $entryLabel") },
        text = {
            when {
                loading -> Box(Modifier.fillMaxWidth().padding(24.dp)) { CircularProgressIndicator() }
                slots.isEmpty() -> Text(
                    "Every slot in this ROM's $entryLabel table is already used — there's no free, unused slot left to claim.",
                )
                else -> Column {
                    Text(
                        "This ROM ships a few reserved, unused slots in its $entryLabel table. " +
                            "Pick one to turn into a real new $entryLabel:",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.height(280.dp)) {
                        items(slots) { index ->
                            Text(
                                "Slot #$index (unused)",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPick(index) }
                                    .padding(vertical = 10.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun NameEntryDialog(title: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { if (name.isNotBlank()) onConfirm(name) }, enabled = name.isNotBlank()) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
