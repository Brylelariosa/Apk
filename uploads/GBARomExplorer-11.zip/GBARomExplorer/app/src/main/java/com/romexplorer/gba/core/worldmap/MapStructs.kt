package com.romexplorer.gba.core.worldmap

/** A map's location within FireRed's two-level bank/number addressing — see [FireRedMapTables]. */
data class MapId(val group: Int, val number: Int)

data class TilesetData(
    val isCompressed: Boolean,
    val isSecondary: Boolean,
    val tilesPointer: Long,
    val palettesPointer: Long,
    val metatilesPointer: Long,
    val metatileAttributesPointer: Long,
)

data class MapLayoutData(
    val width: Int,
    val height: Int,
    val borderPointer: Long,
    val mapDataPointer: Long,
    val primaryTileset: TilesetData?,
    val secondaryTileset: TilesetData?,
    val borderWidth: Int,
    val borderHeight: Int,
)

/** One NPC/scripted-object placement — see [FireRedMapTables]'s doc for struct sourcing. */
data class ObjectEventData(
    val index: Int,
    val localId: Int,
    val graphicsId: Int,
    val kind: Int,
    val x: Int,
    val y: Int,
    val elevation: Int,
    val movementType: Int,
    val movementRangeX: Int,
    val movementRangeY: Int,
    val trainerType: Int,
    val trainerRangeOrBerryTreeId: Int,
    val scriptPointer: Long,
    val flagId: Int,
    val romOffset: Long,
)

data class WarpEventData(
    val index: Int,
    val x: Int,
    val y: Int,
    val elevation: Int,
    val warpId: Int,
    val destinationMapNum: Int,
    val destinationMapGroup: Int,
    val romOffset: Long,
)

/** A "trigger" event — see [FireRedMapTables]'s doc for why [varOrTrigger]/[valueOrIndex] use neutral names. */
data class CoordEventData(
    val index: Int,
    val x: Int,
    val y: Int,
    val elevation: Int,
    val varOrTrigger: Int,
    val valueOrIndex: Int,
    val scriptPointer: Long,
    val romOffset: Long,
)

/** A sign, hidden item, or secret-base-entrance event. [kind] decides whether [scriptPointerOrHiddenItem] is a script pointer or a packed item/quantity value. */
data class BgEventData(
    val index: Int,
    val x: Int,
    val y: Int,
    val elevation: Int,
    val kind: Int,
    val scriptPointerOrHiddenItem: Long,
    val romOffset: Long,
)

data class MapEventsData(
    val objectEvents: List<ObjectEventData>,
    val warps: List<WarpEventData>,
    val coordEvents: List<CoordEventData>,
    val bgEvents: List<BgEventData>,
)

data class MapConnectionData(val direction: Int, val offset: Int, val mapGroup: Int, val mapNum: Int)

data class MapHeaderData(
    val id: MapId,
    val headerOffset: Long,
    val layout: MapLayoutData?,
    val events: MapEventsData,
    val connections: List<MapConnectionData>,
    val music: Int,
    val mapLayoutId: Int,
    val regionMapSectionId: Int,
    val cave: Int,
    val weather: Int,
    val mapType: Int,
    val bikingAllowed: Boolean,
    val battleType: Int,
)
