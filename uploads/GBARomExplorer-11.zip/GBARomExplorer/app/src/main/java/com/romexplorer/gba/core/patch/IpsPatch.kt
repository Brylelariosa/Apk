package com.romexplorer.gba.core.patch

import java.io.ByteArrayOutputStream

/** Thrown when an IPS patch is malformed or cannot be applied cleanly. */
class IpsFormatException(message: String) : Exception(message)

/**
 * Full IPS (International Patching System) implementation.
 *
 * Record layout after the 5-byte "PATCH" magic:
 *   offset   : 3 bytes, big-endian
 *   size     : 2 bytes, big-endian
 *     if size != 0: `size` literal bytes follow (a normal record)
 *     if size == 0: 2-byte RLE run-length (big-endian) + 1 byte value
 *   ...repeated until the 3-byte "EOF" marker (0x45 0x4F 0x46).
 *
 * The classic IPS format cannot address offsets >= 0x1000000 (3-byte offset
 * field), which comfortably covers the 64MB ceiling this app targets isn't
 * guaranteed for every possible patch — [create] will throw if an edit
 * falls beyond that range, since silently truncating an offset would
 * produce a corrupt patch.
 */
object IpsPatch : PatchFormat {

    override val formatName: String = "IPS"

    private val MAGIC = byteArrayOf('P'.code.toByte(), 'A'.code.toByte(), 'T'.code.toByte(), 'C'.code.toByte(), 'H'.code.toByte())
    private val EOF_MARKER = byteArrayOf('E'.code.toByte(), 'O'.code.toByte(), 'F'.code.toByte())
    private const val MAX_ADDRESSABLE_OFFSET = 0xFFFFFF
    private const val MIN_RLE_RUN = 9 // below this, literal encoding is smaller or equal

    override fun isValid(patch: ByteArray): Boolean {
        if (patch.size < 8) return false
        return patch.copyOfRange(0, 5).contentEquals(MAGIC)
    }

    override fun create(original: ByteArray, modified: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(MAGIC)

        var i = 0
        val maxLen = maxOf(original.size, modified.size)

        while (i < maxLen) {
            val originalByte = original.getOrNull(i)
            val modifiedByte = modified.getOrNull(i)

            if (originalByte == modifiedByte) {
                i++
                continue
            }

            if (i > MAX_ADDRESSABLE_OFFSET) {
                throw IpsFormatException(
                    "Difference at offset 0x${i.toString(16)} exceeds classic IPS's 3-byte address limit (16MB)."
                )
            }

            // Find the extent of this differing run.
            var runEnd = i
            while (runEnd < maxLen &&
                original.getOrNull(runEnd) != modified.getOrNull(runEnd) &&
                runEnd - i < 0xFFFF
            ) {
                runEnd++
            }

            val runBytes = ByteArray(runEnd - i) { idx -> modified.getOrElse(i + idx) { 0 } }

            // Use RLE encoding if the run is a single repeated byte and long enough to be worth it.
            val isUniform = runBytes.isNotEmpty() && runBytes.all { it == runBytes[0] }
            if (isUniform && runBytes.size >= MIN_RLE_RUN) {
                writeOffset(out, i)
                out.write(0); out.write(0) // size = 0 marks an RLE record
                out.write((runBytes.size ushr 8) and 0xFF)
                out.write(runBytes.size and 0xFF)
                out.write(runBytes[0].toInt() and 0xFF)
            } else {
                writeOffset(out, i)
                out.write((runBytes.size ushr 8) and 0xFF)
                out.write(runBytes.size and 0xFF)
                out.write(runBytes)
            }

            i = runEnd
        }

        // If the modified file is longer than the original and its tail wasn't
        // already covered by a diff run above, the IPS "truncate extension"
        // trick (a zero-length record at the final offset) isn't reliable
        // across all appliers, so we've already emitted real byte runs for
        // any appended region via the getOrElse(0) fallback above — nothing
        // further to do here.

        out.write(EOF_MARKER)
        return out.toByteArray()
    }

    override fun apply(original: ByteArray, patch: ByteArray): ByteArray {
        if (!isValid(patch)) throw IpsFormatException("Not a valid IPS patch (bad magic)")

        // Determine final size first: it's at least original.size, but a patch
        // may extend the file, so scan once to find the highest touched offset.
        var maxOffset = original.size
        var scanPos = 5
        while (scanPos + 3 <= patch.size) {
            if (isEofAt(patch, scanPos)) break
            val offset = readOffset(patch, scanPos)
            scanPos += 3
            if (scanPos + 2 > patch.size) throw IpsFormatException("Truncated record size field")
            val size = readUInt16(patch, scanPos)
            scanPos += 2
            if (size == 0) {
                if (scanPos + 3 > patch.size) throw IpsFormatException("Truncated RLE record")
                val rleLen = readUInt16(patch, scanPos)
                scanPos += 3 // 2-byte length + 1-byte value
                maxOffset = maxOf(maxOffset, offset + rleLen)
            } else {
                if (scanPos + size > patch.size) throw IpsFormatException("Truncated literal record")
                scanPos += size
                maxOffset = maxOf(maxOffset, offset + size)
            }
        }

        val result = original.copyOf(maxOffset)

        var pos = 5
        while (pos + 3 <= patch.size) {
            if (isEofAt(patch, pos)) break
            val offset = readOffset(patch, pos)
            pos += 3
            val size = readUInt16(patch, pos)
            pos += 2
            if (size == 0) {
                val rleLen = readUInt16(patch, pos)
                pos += 2
                val value = patch[pos]
                pos += 1
                for (k in 0 until rleLen) result[offset + k] = value
            } else {
                System.arraycopy(patch, pos, result, offset, size)
                pos += size
            }
        }

        return result
    }

    private fun isEofAt(patch: ByteArray, pos: Int): Boolean =
        pos + 3 <= patch.size && patch.copyOfRange(pos, pos + 3).contentEquals(EOF_MARKER)

    private fun writeOffset(out: ByteArrayOutputStream, offset: Int) {
        out.write((offset ushr 16) and 0xFF)
        out.write((offset ushr 8) and 0xFF)
        out.write(offset and 0xFF)
    }

    private fun readOffset(patch: ByteArray, pos: Int): Int =
        ((patch[pos].toInt() and 0xFF) shl 16) or
            ((patch[pos + 1].toInt() and 0xFF) shl 8) or
            (patch[pos + 2].toInt() and 0xFF)

    private fun readUInt16(patch: ByteArray, pos: Int): Int =
        ((patch[pos].toInt() and 0xFF) shl 8) or (patch[pos + 1].toInt() and 0xFF)
}
