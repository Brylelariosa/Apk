package com.romexplorer.gba.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

@Serializable
private data class CustomTypeEntry(val id: Int, val name: String)

/**
 * User-defined names for type IDs beyond FireRed's own 18 built-in types
 * (see [com.romexplorer.gba.core.pokemon.FireRedTables.TYPE_COUNT]) — e.g.
 * registering ID 18 as "FAIRY" so it can be picked for a Pokémon's or
 * move's Type field.
 *
 * This is a display label only, merged on top of the ROM's real type-name
 * table by [com.romexplorer.gba.ui.pokemontables.PokemonTableViewModel] —
 * it never writes into the ROM itself. Genuinely adding a type — new
 * in-battle type-effectiveness matchups against every existing type — lives
 * in the game's compiled type chart and battle-engine code, which this
 * ROM *analysis* toolkit doesn't modify (see README: "Not an emulator").
 * What this does give a custom type is everywhere this app itself shows or
 * lets you assign a type — it'll show "FAIRY" instead of "Type #18" the
 * moment you set a Pokémon's or move's Type field to that ID.
 *
 * Keyed by ROM hash, same convention as [BookmarksRepository].
 */
class CustomTypeNamesRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val listSerializer = ListSerializer(CustomTypeEntry.serializer())

    private fun keyFor(romHashKey: String) = stringPreferencesKey("custom_types_$romHashKey")

    fun customTypesFor(romHashKey: String): Flow<Map<Int, String>> =
        context.appDataStore.data.map { prefs -> decode(prefs[keyFor(romHashKey)]).associate { it.id to it.name } }

    suspend fun setCustomType(romHashKey: String, id: Int, name: String) {
        context.appDataStore.edit { prefs ->
            val current = decode(prefs[keyFor(romHashKey)]).filterNot { it.id == id }
            val updated = current + CustomTypeEntry(id, name.uppercase())
            prefs[keyFor(romHashKey)] = json.encodeToString(listSerializer, updated)
        }
    }

    suspend fun removeCustomType(romHashKey: String, id: Int) {
        context.appDataStore.edit { prefs ->
            val current = decode(prefs[keyFor(romHashKey)]).filterNot { it.id == id }
            prefs[keyFor(romHashKey)] = json.encodeToString(listSerializer, current)
        }
    }

    private fun decode(raw: String?): List<CustomTypeEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching { json.decodeFromString(listSerializer, raw) }.getOrDefault(emptyList())
    }
}
