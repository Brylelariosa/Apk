package com.romexplorer.gba.ui.home

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.data.repository.FavoritesRepository
import com.romexplorer.gba.data.repository.RecentRomEntry
import com.romexplorer.gba.data.repository.RecentRomsRepository
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
    private val sessionManager: RomSessionManager,
    private val recentRomsRepository: RecentRomsRepository,
    private val favoritesRepository: FavoritesRepository,
) : ViewModel() {

    val session = sessionManager.session

    val recents: StateFlow<List<RecentRomEntry>> = recentRomsRepository.recents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favorites: StateFlow<Set<String>> = favoritesRepository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private var lastErrorInternal: String? = null
    val lastError: String? get() = lastErrorInternal

    suspend fun openRom(uri: Uri): Boolean {
        val result = sessionManager.open(uri)
        lastErrorInternal = result.exceptionOrNull()?.message
        return result.isSuccess
    }

    fun toggleFavorite(uri: String) {
        viewModelScope.launch { favoritesRepository.toggle(uri) }
    }

    fun removeRecent(uri: String) {
        viewModelScope.launch { recentRomsRepository.remove(uri) }
    }
}
