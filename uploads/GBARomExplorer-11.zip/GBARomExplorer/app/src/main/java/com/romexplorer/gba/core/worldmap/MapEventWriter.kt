package com.romexplorer.gba.core.worldmap

import com.romexplorer.gba.core.common.FreeSpaceAllocator
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Writes map event fields back to the ROM, in place, at the same byte
 * offsets [MapHeaderReader] read them from — position/elevation/graphics/
 * movement for NPCs and scripted objects, and position/elevation/
 * destination for warps. Every field this doesn't explicitly touch
 * (localId, kind, trainer data, the event's own script pointer, flag id)
 * is read back out of the ROM first and written back unchanged, so editing
 * one field can't accidentally clobber another.
 *
 * Adding or removing an event (as opposed to editing an existing one)
 * isn't supported yet — that needs relocating the whole event array to
 * free space and repointing the map's own MapEvents struct, the same kind
 * of resize [com.romexplorer.gba.core.pokemon.TrainerPartyWriter.resize]
 * does for trainer parties, just across four different event-struct shapes
 * instead of one. Tracked as a follow-up rather than attempted here half
 * finished — see the project README's roadmap.
 */
object MapEventWriter {
    suspend fun writeObjectEvent(
        rom: RomAccessor,
        overlay: EditOverlay,
        event: ObjectEventData,
        x: Int,
        y: Int,
        elevation: Int,
        graphicsId: Int,
        movementType: Int,
    ): Boolean {
        val size = FireRedMapTables.OBJECT_EVENT_SIZE
        val bytes = rom.read(event.romOffset, size)
        if (bytes.size < size) return false
        val out = bytes.copyOf()
        out[0x01] = graphicsId.toByte()
        writeS16(out, 0x04, x)
        writeS16(out, 0x06, y)
        out[0x08] = elevation.toByte()
        out[0x09] = movementType.toByte()
        return FreeSpaceAllocator.write(rom, overlay, event.romOffset, out)
    }

    suspend fun writeWarpEvent(
        rom: RomAccessor,
        overlay: EditOverlay,
        event: WarpEventData,
        x: Int,
        y: Int,
        elevation: Int,
        warpId: Int,
        destinationMapNum: Int,
        destinationMapGroup: Int,
    ): Boolean {
        val size = FireRedMapTables.WARP_EVENT_SIZE
        val out = ByteArray(size)
        writeS16(out, 0x00, x)
        writeS16(out, 0x02, y)
        out[0x04] = elevation.toByte()
        out[0x05] = warpId.toByte()
        out[0x06] = destinationMapNum.toByte()
        out[0x07] = destinationMapGroup.toByte()
        return FreeSpaceAllocator.write(rom, overlay, event.romOffset, out)
    }

    private fun writeS16(bytes: ByteArray, offset: Int, value: Int) {
        bytes[offset] = (value and 0xFF).toByte()
        bytes[offset + 1] = ((value shr 8) and 0xFF).toByte()
    }
}
