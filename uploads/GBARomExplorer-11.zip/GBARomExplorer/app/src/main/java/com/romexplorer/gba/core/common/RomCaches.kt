package com.romexplorer.gba.core.common

import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Memoizes one lookup result per ROM, keyed by [RomAccessor] identity rather
 * than equality — different ROMs get different accessor instances, so
 * switching ROMs naturally invalidates the cache instead of serving stale
 * data from whatever was open before. Used for whole-table lookups that are
 * cheap to hold in memory but not free to (re)compute — name tables, a
 * single verification check — wherever it'd otherwise be recomputed once
 * per screen visit instead of once per session.
 */
class RomKeyedCache<T> {
    private var entry: Pair<RomAccessor, T>? = null

    suspend fun getOrPut(accessor: RomAccessor, compute: suspend () -> T): T {
        entry?.let { (cachedAccessor, value) -> if (cachedAccessor === accessor) return value }
        val value = compute()
        entry = accessor to value
        return value
    }

    /** Forces the next [getOrPut] to recompute — e.g. after a custom type name is added. */
    fun invalidate() {
        entry = null
    }
}

/**
 * Same idea as [RomKeyedCache], but for lookups keyed by an index rather
 * than a single value per ROM — species icons, item icons, trainer
 * sprites, battle animation scripts, a map's resolved name. Each of these
 * is real work (LZ77 decompression + tile decode, or a handful of ROM
 * reads), so this is what makes scrolling back up through an
 * already-viewed table or list, or reselecting an already-seen entry,
 * free instead of redoing that work every time.
 */
class IndexedCache<T> {
    private var accessor: RomAccessor? = null
    private val cache = mutableMapOf<Int, T>()

    suspend fun getOrPut(currentAccessor: RomAccessor, index: Int, compute: suspend () -> T): T {
        if (accessor !== currentAccessor) {
            accessor = currentAccessor
            cache.clear()
        }
        if (cache.containsKey(index)) return cache.getValue(index)
        return compute().also { cache[index] = it }
    }
}
