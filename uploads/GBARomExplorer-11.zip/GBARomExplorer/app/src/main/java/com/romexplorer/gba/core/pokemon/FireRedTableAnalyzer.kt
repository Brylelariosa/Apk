package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Flags the known FireRed table byte ranges (species/moves/items/trainers)
 * in the ROM map, so they show up as labeled regions instead of being
 * absorbed into whatever the generic heuristic analyzers guess for that
 * space. Before claiming anything, this checks the species table's first
 * real entry (Bulbasaur, index 1) against its verified byte fingerprint —
 * cheap, deterministic, and a much stronger guarantee than the game code
 * check alone that these offsets actually line up in *this* ROM (a romhack
 * built from FireRed could have moved things around even with the same
 * header). If that check fails, no regions are claimed at all rather than
 * risk mislabeling something else as Pokémon data.
 */
class FireRedTableAnalyzer : RegionAnalyzer {
    override val id: String = "firered_known_tables"

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        onProgress(0f)
        if (!verifyBulbasaurFingerprint(rom)) {
            onProgress(1f)
            return emptyList()
        }

        val regions = mutableListOf<RomRegion>()
        val schemas = listOf(
            FireRedTables.speciesBaseStats to RegionType.POKEMON_SPECIES,
            FireRedTables.moves to RegionType.POKEMON_MOVES,
            FireRedTables.items to RegionType.POKEMON_ITEMS,
            FireRedTables.trainers to RegionType.POKEMON_TRAINERS,
        )

        schemas.forEachIndexed { index, (schema, type) ->
            val start = schema.romOffset
            val end = minOf(start + schema.totalSizeBytes, rom.sizeBytes)
            if (start < rom.sizeBytes && end > start) {
                regions += RomRegion(
                    startOffset = start,
                    endOffsetExclusive = end,
                    type = type,
                    confidence = 1f,
                    label = schema.displayName,
                )
            }
            onProgress((index + 1).toFloat() / schemas.size)
        }
        return regions
    }

    private suspend fun verifyBulbasaurFingerprint(rom: RomAccessor): Boolean {
        val schema = FireRedTables.speciesBaseStats
        val bulbasaurOffset = schema.romOffset + schema.entrySize // index 1, not the index-0 placeholder
        if (bulbasaurOffset + schema.entrySize > rom.sizeBytes) return false

        val actual = rom.read(bulbasaurOffset, schema.entrySize)
        return actual.contentEquals(BULBASAUR_FINGERPRINT)
    }

    companion object {
        // Verified against Bulbapedia's published sample bytes and Bulbasaur's
        // real, known base stats - see FireRedTables.kt's doc comment.
        private val BULBASAUR_FINGERPRINT = byteArrayOf(
            0x2D, 0x31, 0x31, 0x2D, 0x41, 0x41, 0x0C, 0x03,
            0x2D, 0x40, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
            0x1F, 0x14, 0x46, 0x03, 0x01, 0x07, 0x41, 0x00,
            0x00, 0x03, 0x00, 0x00,
        )
    }
}
