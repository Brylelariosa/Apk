package com.romexplorer.gba.core.hex

import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Streaming search across a ROM for either a raw byte pattern or ASCII text,
 * without ever loading the whole file. Reads overlapping chunks so matches
 * spanning a chunk boundary are never missed.
 */
object HexSearchEngine {

    private const val CHUNK_SIZE = 1 shl 20 // 1MB

    suspend fun searchBytes(
        rom: RomAccessor,
        pattern: ByteArray,
        startOffset: Long = 0L,
        onProgress: suspend (Float) -> Unit = {},
    ): List<Long> {
        if (pattern.isEmpty()) return emptyList()
        val matches = mutableListOf<Long>()

        var offset = startOffset.coerceAtLeast(0)
        var carry = ByteArray(0)
        var carryBase = offset

        while (offset < rom.sizeBytes) {
            val length = minOf(CHUNK_SIZE.toLong(), rom.sizeBytes - offset).toInt()
            val chunk = rom.read(offset, length)
            val window = carry + chunk
            val windowBase = carryBase

            var searchFrom = 0
            while (true) {
                val idx = window.indexOfSubArray(pattern, searchFrom)
                if (idx == -1) break
                matches += windowBase + idx
                searchFrom = idx + 1
            }

            val tailSize = minOf(pattern.size - 1, window.size).coerceAtLeast(0)
            carry = if (tailSize > 0) window.copyOfRange(window.size - tailSize, window.size) else ByteArray(0)
            carryBase = windowBase + window.size - carry.size

            offset += length
            onProgress((offset.toFloat() / rom.sizeBytes.toFloat()).coerceIn(0f, 1f))
        }
        return matches
    }

    suspend fun searchAscii(
        rom: RomAccessor,
        text: String,
        startOffset: Long = 0L,
        onProgress: suspend (Float) -> Unit = {},
    ): List<Long> {
        val pattern = ByteArray(text.length) { i -> text[i].code.toByte() }
        return searchBytes(rom, pattern, startOffset, onProgress)
    }

    private fun ByteArray.indexOfSubArray(pattern: ByteArray, from: Int): Int {
        if (pattern.isEmpty() || from < 0) return -1
        val lastPossible = size - pattern.size
        var i = from
        outer@ while (i <= lastPossible) {
            for (j in pattern.indices) {
                if (this[i + j] != pattern[j]) {
                    i++
                    continue@outer
                }
            }
            return i
        }
        return -1
    }
}
