package com.romexplorer.gba.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.romexplorer.gba.core.hex.HexBookmark
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/** Persists hex-editor bookmarks per ROM, keyed by the ROM's SHA-1 hash so
 * bookmarks survive re-opening the same ROM from a different URI/location. */
class BookmarksRepository(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }
    private val listSerializer = ListSerializer(HexBookmark.serializer())

    private fun keyFor(romHashKey: String) = stringPreferencesKey("bookmarks_$romHashKey")

    fun bookmarksFor(romHashKey: String): Flow<List<HexBookmark>> =
        context.appDataStore.data.map { prefs -> decode(prefs[keyFor(romHashKey)]) }

    suspend fun add(romHashKey: String, bookmark: HexBookmark) {
        context.appDataStore.edit { prefs ->
            val current = decode(prefs[keyFor(romHashKey)])
            val updated = (current.filterNot { it.offset == bookmark.offset } + bookmark)
                .sortedBy { it.offset }
            prefs[keyFor(romHashKey)] = json.encodeToString(listSerializer, updated)
        }
    }

    suspend fun remove(romHashKey: String, offset: Long) {
        context.appDataStore.edit { prefs ->
            val current = decode(prefs[keyFor(romHashKey)])
            prefs[keyFor(romHashKey)] = json.encodeToString(listSerializer, current.filterNot { it.offset == offset })
        }
    }

    private fun decode(raw: String?): List<HexBookmark> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching { json.decodeFromString(listSerializer, raw) }.getOrDefault(emptyList())
    }
}
