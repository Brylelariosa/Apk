package com.romexplorer.gba.core.rom

enum class SaveType(val label: String) {
    SRAM("SRAM (32KB)"),
    FLASH_512K("FLASH 512Kbit"),
    FLASH_1M("FLASH 1Mbit"),
    EEPROM("EEPROM"),
    NONE_DETECTED("None detected"),
}
