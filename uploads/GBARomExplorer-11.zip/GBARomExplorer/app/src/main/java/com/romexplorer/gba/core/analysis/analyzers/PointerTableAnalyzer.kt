package com.romexplorer.gba.core.analysis.analyzers

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Finds runs of consecutive, word-aligned 32-bit values that all look like
 * valid GBA ROM pointers (0x08000000..0x09FFFFFF, the ROM address space as
 * seen by the CPU, mirrored across two wait-state regions). A run of at
 * least [minRunLength] consecutive valid pointers is reported as a
 * POINTER_TABLE, since a handful of coincidental in-range words is common
 * in ordinary data but a long unbroken run strongly implies a real table.
 */
class PointerTableAnalyzer(
    private val minRunLength: Int = 4,
    private val chunkWords: Int = 1 shl 14, // 16384 words = 64KB per chunk
) : RegionAnalyzer {
    override val id: String = "pointer_tables"

    private val ROM_ADDR_LOW = 0x08000000L
    private val ROM_ADDR_HIGH = 0x0A000000L // exclusive upper bound across both mirrors

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        val regions = mutableListOf<RomRegion>()
        val romSize = rom.sizeBytes

        var runStart = -1L
        var runCount = 0

        var offset = 0L
        val chunkBytes = chunkWords * 4
        while (offset + 4 <= romSize) {
            val length = minOf(chunkBytes.toLong(), romSize - offset).toInt().let { it - (it % 4) }
            if (length <= 0) break
            val chunk = rom.read(offset, length)

            var i = 0
            while (i + 4 <= chunk.size) {
                val value = readUInt32Le(chunk, i)
                val isPointer = value in ROM_ADDR_LOW until ROM_ADDR_HIGH &&
                    (value and 0xFFFFFFL) < romSize

                if (isPointer) {
                    if (runCount == 0) runStart = offset + i
                    runCount++
                } else {
                    flushRun(regions, runStart, runCount)
                    runCount = 0
                }
                i += 4
            }
            offset += length
            onProgress((offset.toFloat() / romSize.toFloat()).coerceIn(0f, 1f))
        }
        flushRun(regions, runStart, runCount)
        return regions
    }

    private fun flushRun(regions: MutableList<RomRegion>, start: Long, count: Int) {
        if (count < minRunLength) return
        val end = start + count * 4L
        val confidence = (count.toFloat() / 16f).coerceIn(0.4f, 1f)
        regions += RomRegion(
            startOffset = start,
            endOffsetExclusive = end,
            type = RegionType.POINTER_TABLE,
            confidence = confidence,
            label = "Pointer table ($count entries)",
        )
    }

    private fun readUInt32Le(bytes: ByteArray, offset: Int): Long {
        return (bytes[offset].toLong() and 0xFF) or
            ((bytes[offset + 1].toLong() and 0xFF) shl 8) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 16) or
            ((bytes[offset + 3].toLong() and 0xFF) shl 24)
    }
}
