package com.romexplorer.gba.core.analysis.analyzers

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Finds runs of a single repeated byte (0xFF or 0x00, the two values ROM
 * mask images and flash-cart erasures are padded with) at least
 * [minRunLength] bytes long.
 */
class FreeSpaceAnalyzer(
    private val minRunLength: Int = 64,
    private val chunkSize: Int = 1 shl 16,
) : RegionAnalyzer {
    override val id: String = "free_space"

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        val regions = mutableListOf<RomRegion>()
        var runStart = -1L
        var runValue = -1

        var offset = 0L
        while (offset < rom.sizeBytes) {
            val length = minOf(chunkSize.toLong(), rom.sizeBytes - offset).toInt()
            val chunk = rom.read(offset, length)

            for (i in chunk.indices) {
                val value = chunk[i].toInt() and 0xFF
                val globalPos = offset + i
                val isFillByte = value == 0xFF || value == 0x00

                if (isFillByte && (runStart == -1L || value == runValue)) {
                    if (runStart == -1L) {
                        runStart = globalPos
                        runValue = value
                    }
                } else {
                    flushRun(regions, runStart, globalPos, runValue)
                    runStart = if (isFillByte) globalPos else -1L
                    runValue = if (isFillByte) value else -1
                }
            }

            offset += length
            onProgress((offset.toFloat() / rom.sizeBytes.toFloat()).coerceIn(0f, 1f))
        }
        flushRun(regions, runStart, rom.sizeBytes, runValue)
        return regions
    }

    private fun flushRun(regions: MutableList<RomRegion>, start: Long, end: Long, value: Int) {
        if (start < 0) return
        val length = end - start
        if (length < minRunLength) return
        val confidence = (length.toFloat() / (minRunLength * 4)).coerceIn(0.3f, 1f)
        val label = if (value == 0xFF) "Free Space (0xFF)" else "Free Space (0x00)"
        regions += RomRegion(start, end, RegionType.FREE_SPACE, confidence, label)
    }
}
