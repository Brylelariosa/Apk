package com.romexplorer.gba.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object RomInfo : Screen("rom_info")
    data object HexEditor : Screen("hex_editor")
    data object RomMap : Screen("rom_map")
    data object Analyzer : Screen("analyzer")
    data object Patch : Screen("patch")
    data object Tools : Screen("tools")
    data object PokemonTables : Screen("pokemon_tables")
    data object MapExplorer : Screen("map_explorer")
    data object RomExpansion : Screen("rom_expansion")

    /** Parameterized — see [PokeScript.routeWithArgs] to build a navigable route and [PokeScript.route] for the pattern registered in the nav graph. */
    data object PokeScript : Screen("pokescript") {
        const val ARG_SCRIPT_OFFSET = "scriptOffset"
        const val ARG_OWNER_OFFSET = "ownerOffset"
        val routePattern = "$route/{$ARG_SCRIPT_OFFSET}/{$ARG_OWNER_OFFSET}"
        fun routeWithArgs(scriptOffset: Long, ownerFieldOffset: Long) = "$route/$scriptOffset/$ownerFieldOffset"
    }
}
