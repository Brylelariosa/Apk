package com.romexplorer.gba.core.analysis.analyzers

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Finds runs of printable ASCII bytes at least [minRunLength] long. This is
 * a coarse heuristic — many GBA games use custom, non-ASCII text encodings
 * that this analyzer will miss entirely (a game-specific [com.romexplorer.gba.core.analysis.GameAnalyzerPlugin]
 * is the right place to decode those; this one only catches plain ASCII/DMA
 * debug strings, credits text, and similar).
 */
class TextRegionAnalyzer(
    private val minRunLength: Int = 8,
    private val chunkSize: Int = 1 shl 16,
) : RegionAnalyzer {
    override val id: String = "ascii_text"

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        val regions = mutableListOf<RomRegion>()
        var runStart = -1L

        var offset = 0L
        while (offset < rom.sizeBytes) {
            val length = minOf(chunkSize.toLong(), rom.sizeBytes - offset).toInt()
            val chunk = rom.read(offset, length)

            for (i in chunk.indices) {
                val value = chunk[i].toInt() and 0xFF
                val globalPos = offset + i
                val isPrintable = value in 0x20..0x7E

                if (isPrintable) {
                    if (runStart == -1L) runStart = globalPos
                } else {
                    flushRun(regions, runStart, globalPos)
                    runStart = -1L
                }
            }
            offset += length
            onProgress((offset.toFloat() / rom.sizeBytes.toFloat()).coerceIn(0f, 1f))
        }
        flushRun(regions, runStart, rom.sizeBytes)
        return regions
    }

    private fun flushRun(regions: MutableList<RomRegion>, start: Long, end: Long) {
        if (start < 0) return
        val length = end - start
        if (length < minRunLength) return
        val confidence = (length.toFloat() / (minRunLength * 3)).coerceIn(0.3f, 1f)
        regions += RomRegion(start, end, RegionType.TEXT, confidence, "ASCII text ($length chars)")
    }
}
