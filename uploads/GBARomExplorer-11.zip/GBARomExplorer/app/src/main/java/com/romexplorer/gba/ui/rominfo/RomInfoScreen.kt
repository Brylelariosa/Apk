@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.rominfo

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.ui.common.ProgressRow
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RomInfoScreen(navController: NavHostController, viewModel: RomInfoViewModel = koinViewModel()) {
    val session by viewModel.session.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val hashProgress by viewModel.hashProgress.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(session?.displayName ?: "ROM Info") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    val uri = session?.uri?.toString()
                    if (uri != null) {
                        val isFav = uri in favorites
                        IconButton(onClick = { viewModel.toggleFavorite() }) {
                            Icon(
                                imageVector = if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder,
                                contentDescription = "Favorite",
                            )
                        }
                    }
                },
            )
        },
    ) { padding ->
        val current = session
        if (current == null) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("No ROM is currently open.")
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (current.warnings.isNotEmpty()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row {
                                Icon(Icons.Filled.WarningAmber, contentDescription = null)
                                Text(
                                    "  Warnings",
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(start = 4.dp),
                                )
                            }
                            current.warnings.forEach { w ->
                                Text("• " + w.message, modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                    }
                }
            }

            item { InfoCard(title = "Header") {
                InfoRow("Title", current.header.title.ifBlank { "(blank)" })
                InfoRow("Game Code", current.header.gameCode.ifBlank { "(blank)" })
                InfoRow("Maker Code", current.header.makerCode.ifBlank { "(blank)" })
                InfoRow("Version", current.header.version.toString())
                InfoRow("ROM Size", formatSize(current.header.romSizeBytes))
                InfoRow("Boot Mode", current.header.bootMode.name)
            } }

            item { InfoCard(title = "Validation") {
                InfoRow("Fixed byte (0xB2)", if (current.header.fixedByteValid) "Valid (0x96)" else "Invalid")
                InfoRow(
                    "Header checksum",
                    if (current.header.headerChecksumValid) {
                        "Valid (0x${current.header.headerChecksumDeclared.toString(16).uppercase()})"
                    } else {
                        "Mismatch: declared 0x${current.header.headerChecksumDeclared.toString(16)}, " +
                            "computed 0x${current.header.headerChecksumComputed.toString(16)}"
                    },
                )
                InfoRow("Logo region", if (current.header.logoRegionPresent) "Present" else "Blank")
            } }

            item { InfoCard(title = "Checksums") {
                if (hashProgress != null) {
                    ProgressRow("Computing…", hashProgress)
                } else {
                    val hashes = current.hashes
                    if (hashes == null) {
                        Text("Not yet computed")
                    } else {
                        InfoRow("CRC32", hashes.crc32)
                        InfoRow("MD5", hashes.md5)
                        InfoRow("SHA-1", hashes.sha1)
                    }
                }
            } }

            item { InfoCard(title = "Save Type") {
                InfoRow("Detected", current.saveType?.label ?: "Detecting…")
            } }
        }
    }
}

@Composable
private fun InfoCard(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 6.dp))
            content()
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, modifier = Modifier.padding(end = 12.dp))
        Text(value)
    }
}

private fun formatSize(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return "%.2f MB (%,d bytes)".format(mb, bytes)
}
