package com.romexplorer.gba.core.pokescript

/** One argument slot's width in a fixed-shape command — see [ArgSpec.Fixed]. */
enum class ArgType(val byteLength: Int) {
    /** A raw single-byte number — a small id, flag, or count. */
    BYTE(1),

    /** A raw two-byte number — a variable id, flag id, item id, sound id, etc. */
    WORD(2),

    /** A raw four-byte number that isn't a ROM address (e.g. a literal compared against a script bank). */
    DWORD(4),

    /** A four-byte GBA ROM pointer (0x08000000+) — a script target, text string, or movement script. */
    POINTER(4),
}

/** An opcode's argument shape — see [ScriptCommandTable]'s class doc for how these are assigned. */
sealed class ArgSpec {
    data class Fixed(val args: List<ArgType>) : ArgSpec() {
        val totalBytes: Int get() = args.sumOf { it.byteLength }
    }

    /** Opcode name is verified; this app doesn't have a confidently-verified argument byte layout for it. [ScriptDisassembler] stops here rather than guess. */
    object Unknown : ArgSpec()

    /** 0x5C only — trainerbattle's argument length depends on its own first byte. Special-cased in [ScriptDisassembler] rather than modeled as one fixed shape. */
    object TrainerBattle : ArgSpec()
}

data class ScriptCommand(val opcode: Int, val mnemonic: String, val args: ArgSpec)

/**
 * Every opcode Pokémon FireRed's field-script engine recognizes (0x00
 * through 0xD4), and the exact argument byte layout for a well-scoped
 * subset of the most commonly-used ones.
 *
 * The opcode -> mnemonic mapping for the *entire* table is copied verbatim
 * from `pret/pokefirered`'s own `data/script_cmd_table.inc` — the literal
 * jump table this ROM's script interpreter uses at runtime (`gScriptCmdTable`,
 * each entry a function pointer with the real opcode number in an adjacent
 * `@` comment, 0x00 through 0xD4 with no gaps, ending at `gScriptCmdTableEnd`)
 * — the same standard [com.romexplorer.gba.core.pokemon.FireRedTables]
 * holds its trainer-struct citation to, and the highest-confidence kind of
 * source this app uses anywhere: not a community transcription of the
 * table, the actual table.
 *
 * Argument *layouts*, though, aren't in that file — each `ScrCmd_*`
 * function reads its own arguments in `src/scrcmd.c`, which this app
 * hasn't independently cross-checked byte-for-byte for every one of the
 * 213 commands. Rather than guess, only commands whose argument shape is
 * simple, unambiguous, and consistent with the wider Gen III scripting
 * community's own long-standing documentation (the XSE-era command
 * references most published FireRed hacks' scripts were originally written
 * against) get an [ArgSpec.Fixed] entry here. Everything else is
 * [ArgSpec.Unknown] — [ScriptDisassembler] still names the command
 * correctly (it IS this opcode, verified against the real jump table), it
 * just doesn't attempt to decode arguments it can't verify, and stops
 * there instead of guessing a byte count that would silently misalign
 * every command after it in the same script.
 *
 * trainerbattle (0x5C) is deliberately excluded from that "simple and
 * unambiguous" bar and given its own [ArgSpec.TrainerBattle] marker
 * instead — its own first argument byte changes how many further bytes
 * follow, and getting that wrong would be exactly the kind of silent
 * misalignment this table is designed to avoid. See
 * [ScriptDisassembler]'s handling of it for the (also explicitly
 * lower-confidence) sub-shapes this app does attempt.
 */
object ScriptCommandTable {
    private val B = ArgType.BYTE
    private val W = ArgType.WORD
    private val P = ArgType.POINTER
    private val NONE = ArgSpec.Fixed(emptyList())
    private val U = ArgSpec.Unknown
    private fun f(vararg types: ArgType) = ArgSpec.Fixed(types.toList())

    val COMMANDS: List<ScriptCommand> = listOf(
        ScriptCommand(0x00, "nop", NONE),
        ScriptCommand(0x01, "nop1", NONE),
        ScriptCommand(0x02, "end", NONE),
        ScriptCommand(0x03, "return", NONE),
        ScriptCommand(0x04, "call", f(P)),
        ScriptCommand(0x05, "goto", f(P)),
        ScriptCommand(0x06, "goto_if", f(B, P)),
        ScriptCommand(0x07, "call_if", f(B, P)),
        ScriptCommand(0x08, "gotostd", f(B)),
        ScriptCommand(0x09, "callstd", f(B)),
        ScriptCommand(0x0a, "gotostd_if", f(B, B)),
        ScriptCommand(0x0b, "callstd_if", f(B, B)),
        ScriptCommand(0x0c, "returnram", NONE),
        ScriptCommand(0x0d, "endram", NONE),
        ScriptCommand(0x0e, "setmysteryeventstatus", f(B)),
        ScriptCommand(0x0f, "loadword", U),
        ScriptCommand(0x10, "loadbyte", U),
        ScriptCommand(0x11, "setptr", U),
        ScriptCommand(0x12, "loadbytefromptr", U),
        ScriptCommand(0x13, "setptrbyte", U),
        ScriptCommand(0x14, "copylocal", f(B, B)),
        ScriptCommand(0x15, "copybyte", U),
        ScriptCommand(0x16, "setvar", f(W, W)),
        ScriptCommand(0x17, "addvar", f(W, W)),
        ScriptCommand(0x18, "subvar", f(W, W)),
        ScriptCommand(0x19, "copyvar", f(W, W)),
        ScriptCommand(0x1a, "setorcopyvar", f(W, W)),
        ScriptCommand(0x1b, "compare_local_to_local", f(B, B)),
        ScriptCommand(0x1c, "compare_local_to_value", U),
        ScriptCommand(0x1d, "compare_local_to_ptr", U),
        ScriptCommand(0x1e, "compare_ptr_to_local", U),
        ScriptCommand(0x1f, "compare_ptr_to_value", U),
        ScriptCommand(0x20, "compare_ptr_to_ptr", U),
        ScriptCommand(0x21, "compare_var_to_value", f(W, W)),
        ScriptCommand(0x22, "compare_var_to_var", f(W, W)),
        ScriptCommand(0x23, "callnative", f(P)),
        ScriptCommand(0x24, "gotonative", f(P)),
        ScriptCommand(0x25, "special", f(W)),
        ScriptCommand(0x26, "specialvar", f(W, W)),
        ScriptCommand(0x27, "waitstate", NONE),
        ScriptCommand(0x28, "delay", f(W)),
        ScriptCommand(0x29, "setflag", f(W)),
        ScriptCommand(0x2a, "clearflag", f(W)),
        ScriptCommand(0x2b, "checkflag", f(W)),
        ScriptCommand(0x2c, "initclock", f(B, B)),
        ScriptCommand(0x2d, "dotimebasedevents", NONE),
        ScriptCommand(0x2e, "gettime", NONE),
        ScriptCommand(0x2f, "playse", f(W)),
        ScriptCommand(0x30, "waitse", NONE),
        ScriptCommand(0x31, "playfanfare", f(W)),
        ScriptCommand(0x32, "waitfanfare", NONE),
        ScriptCommand(0x33, "playbgm", U),
        ScriptCommand(0x34, "savebgm", f(W)),
        ScriptCommand(0x35, "fadedefaultbgm", NONE),
        ScriptCommand(0x36, "fadenewbgm", f(W)),
        ScriptCommand(0x37, "fadeoutbgm", f(B)),
        ScriptCommand(0x38, "fadeinbgm", f(B)),
        ScriptCommand(0x39, "warp", f(B, B, B, W, W)),
        ScriptCommand(0x3a, "warpsilent", f(B, B, B, W, W)),
        ScriptCommand(0x3b, "warpdoor", f(B, B, B, W, W)),
        ScriptCommand(0x3c, "warphole", U),
        ScriptCommand(0x3d, "warpteleport", f(B, B, B, W, W)),
        ScriptCommand(0x3e, "setwarp", f(B, B, B, W, W)),
        ScriptCommand(0x3f, "setdynamicwarp", f(B, B, B, W, W)),
        ScriptCommand(0x40, "setdivewarp", f(B, B, B, W, W)),
        ScriptCommand(0x41, "setholewarp", U),
        ScriptCommand(0x42, "getplayerxy", f(W, W)),
        ScriptCommand(0x43, "getpartysize", NONE),
        ScriptCommand(0x44, "additem", f(W, W)),
        ScriptCommand(0x45, "removeitem", f(W, W)),
        ScriptCommand(0x46, "checkitemspace", f(W, W)),
        ScriptCommand(0x47, "checkitem", f(W, W)),
        ScriptCommand(0x48, "checkitemtype", f(W)),
        ScriptCommand(0x49, "addpcitem", f(W, W)),
        ScriptCommand(0x4a, "checkpcitem", f(W, W)),
        ScriptCommand(0x4b, "adddecoration", U),
        ScriptCommand(0x4c, "removedecoration", U),
        ScriptCommand(0x4d, "checkdecor", U),
        ScriptCommand(0x4e, "checkdecorspace", U),
        ScriptCommand(0x4f, "applymovement", f(W, P)),
        ScriptCommand(0x50, "applymovementat", U),
        ScriptCommand(0x51, "waitmovement", f(W)),
        ScriptCommand(0x52, "waitmovementat", U),
        ScriptCommand(0x53, "removeobject", f(W)),
        ScriptCommand(0x54, "removeobjectat", U),
        ScriptCommand(0x55, "addobject", f(W)),
        ScriptCommand(0x56, "addobjectat", U),
        ScriptCommand(0x57, "setobjectxy", f(W, W, W)),
        ScriptCommand(0x58, "showobjectat", U),
        ScriptCommand(0x59, "hideobjectat", U),
        ScriptCommand(0x5a, "faceplayer", NONE),
        ScriptCommand(0x5b, "turnobject", f(W, B)),
        ScriptCommand(0x5c, "trainerbattle", ArgSpec.TrainerBattle),
        ScriptCommand(0x5d, "dotrainerbattle", NONE),
        ScriptCommand(0x5e, "gotopostbattlescript", NONE),
        ScriptCommand(0x5f, "gotobeatenscript", NONE),
        ScriptCommand(0x60, "checktrainerflag", f(W)),
        ScriptCommand(0x61, "settrainerflag", f(W)),
        ScriptCommand(0x62, "cleartrainerflag", f(W)),
        ScriptCommand(0x63, "setobjectxyperm", U),
        ScriptCommand(0x64, "copyobjectxytoperm", f(W)),
        ScriptCommand(0x65, "setobjectmovementtype", f(W, B)),
        ScriptCommand(0x66, "waitmessage", NONE),
        ScriptCommand(0x67, "message", f(P)),
        ScriptCommand(0x68, "closemessage", NONE),
        ScriptCommand(0x69, "lockall", NONE),
        ScriptCommand(0x6a, "lock", NONE),
        ScriptCommand(0x6b, "releaseall", NONE),
        ScriptCommand(0x6c, "release", NONE),
        ScriptCommand(0x6d, "waitbuttonpress", NONE),
        ScriptCommand(0x6e, "yesnobox", NONE),
        ScriptCommand(0x6f, "multichoice", f(B, B, B, B)),
        ScriptCommand(0x70, "multichoicedefault", f(B, B, B, B, B)),
        ScriptCommand(0x71, "multichoicegrid", f(B, B, B, B, B)),
        ScriptCommand(0x72, "drawbox", U),
        ScriptCommand(0x73, "erasebox", U),
        ScriptCommand(0x74, "drawboxtext", U),
        ScriptCommand(0x75, "showmonpic", f(W, B, B)),
        ScriptCommand(0x76, "hidemonpic", NONE),
        ScriptCommand(0x77, "showcontestpainting", f(B)),
        ScriptCommand(0x78, "braillemessage", f(P)),
        ScriptCommand(0x79, "givemon", U),
        ScriptCommand(0x7a, "giveegg", U),
        ScriptCommand(0x7b, "setmonmove", U),
        ScriptCommand(0x7c, "checkpartymove", U),
        ScriptCommand(0x7d, "bufferspeciesname", f(B, W)),
        ScriptCommand(0x7e, "bufferleadmonspeciesname", f(B)),
        ScriptCommand(0x7f, "bufferpartymonnick", f(B, W)),
        ScriptCommand(0x80, "bufferitemname", f(B, W)),
        ScriptCommand(0x81, "bufferdecorationname", U),
        ScriptCommand(0x82, "buffermovename", f(B, W)),
        ScriptCommand(0x83, "buffernumberstring", f(B, W)),
        ScriptCommand(0x84, "bufferstdstring", f(B, W)),
        ScriptCommand(0x85, "bufferstring", f(B, P)),
        ScriptCommand(0x86, "pokemart", f(P)),
        ScriptCommand(0x87, "pokemartdecoration", U),
        ScriptCommand(0x88, "pokemartdecoration2", U),
        ScriptCommand(0x89, "playslotmachine", U),
        ScriptCommand(0x8a, "setberrytree", U),
        ScriptCommand(0x8b, "choosecontestmon", NONE),
        ScriptCommand(0x8c, "startcontest", NONE),
        ScriptCommand(0x8d, "showcontestresults", NONE),
        ScriptCommand(0x8e, "contestlinktransfer", U),
        ScriptCommand(0x8f, "random", f(W)),
        ScriptCommand(0x90, "addmoney", U),
        ScriptCommand(0x91, "removemoney", U),
        ScriptCommand(0x92, "checkmoney", U),
        ScriptCommand(0x93, "showmoneybox", U),
        ScriptCommand(0x94, "hidemoneybox", NONE),
        ScriptCommand(0x95, "updatemoneybox", U),
        ScriptCommand(0x96, "getpokenewsactive", U),
        ScriptCommand(0x97, "fadescreen", f(B)),
        ScriptCommand(0x98, "fadescreenspeed", U),
        ScriptCommand(0x99, "setflashlevel", f(W)),
        ScriptCommand(0x9a, "animateflash", f(B)),
        ScriptCommand(0x9b, "messageautoscroll", f(P)),
        ScriptCommand(0x9c, "dofieldeffect", f(W)),
        ScriptCommand(0x9d, "setfieldeffectargument", U),
        ScriptCommand(0x9e, "waitfieldeffect", NONE),
        ScriptCommand(0x9f, "setrespawn", f(B)),
        ScriptCommand(0xa0, "checkplayergender", NONE),
        ScriptCommand(0xa1, "playmoncry", U),
        ScriptCommand(0xa2, "setmetatile", U),
        ScriptCommand(0xa3, "resetweather", NONE),
        ScriptCommand(0xa4, "setweather", f(W)),
        ScriptCommand(0xa5, "doweather", NONE),
        ScriptCommand(0xa6, "setstepcallback", f(B)),
        ScriptCommand(0xa7, "setmaplayoutindex", f(W)),
        ScriptCommand(0xa8, "setobjectsubpriority", U),
        ScriptCommand(0xa9, "resetobjectsubpriority", U),
        ScriptCommand(0xaa, "createvobject", U),
        ScriptCommand(0xab, "turnvobject", U),
        ScriptCommand(0xac, "opendoor", U),
        ScriptCommand(0xad, "closedoor", U),
        ScriptCommand(0xae, "waitdooranim", NONE),
        ScriptCommand(0xaf, "setdooropen", U),
        ScriptCommand(0xb0, "setdoorclosed", U),
        ScriptCommand(0xb1, "addelevmenuitem", U),
        ScriptCommand(0xb2, "showelevmenu", NONE),
        ScriptCommand(0xb3, "checkcoins", f(W)),
        ScriptCommand(0xb4, "addcoins", f(W)),
        ScriptCommand(0xb5, "removecoins", f(W)),
        ScriptCommand(0xb6, "setwildbattle", U),
        ScriptCommand(0xb7, "dowildbattle", NONE),
        ScriptCommand(0xb8, "setvaddress", f(P)),
        ScriptCommand(0xb9, "vgoto", f(P)),
        ScriptCommand(0xba, "vcall", f(P)),
        ScriptCommand(0xbb, "vgoto_if", f(B, P)),
        ScriptCommand(0xbc, "vcall_if", f(B, P)),
        ScriptCommand(0xbd, "vmessage", f(P)),
        ScriptCommand(0xbe, "vbuffermessage", f(P)),
        ScriptCommand(0xbf, "vbufferstring", U),
        ScriptCommand(0xc0, "showcoinsbox", U),
        ScriptCommand(0xc1, "hidecoinsbox", U),
        ScriptCommand(0xc2, "updatecoinsbox", U),
        ScriptCommand(0xc3, "incrementgamestat", f(B)),
        ScriptCommand(0xc4, "setescapewarp", f(B, B, B, W, W)),
        ScriptCommand(0xc5, "waitmoncry", NONE),
        ScriptCommand(0xc6, "bufferboxname", f(B, W)),
        ScriptCommand(0xc7, "textcolor", f(B)),
        ScriptCommand(0xc8, "loadhelp", U),
        ScriptCommand(0xc9, "unloadhelp", NONE),
        ScriptCommand(0xca, "signmsg", NONE),
        ScriptCommand(0xcb, "normalmsg", NONE),
        ScriptCommand(0xcc, "comparestat", U),
        ScriptCommand(0xcd, "setmonmodernfatefulencounter", U),
        ScriptCommand(0xce, "checkmonmodernfatefulencounter", U),
        ScriptCommand(0xcf, "trywondercardscript", NONE),
        ScriptCommand(0xd0, "setworldmapflag", f(W)),
        ScriptCommand(0xd1, "warpspinenter", f(B, B, B, W, W)),
        ScriptCommand(0xd2, "setmonmetlocation", U),
        ScriptCommand(0xd3, "getbraillestringwidth", U),
        ScriptCommand(0xd4, "bufferitemnameplural", U),
    )

    val byOpcode: Map<Int, ScriptCommand> = COMMANDS.associateBy { it.opcode }
    val byMnemonic: Map<String, ScriptCommand> = COMMANDS.associateBy { it.mnemonic }
}

/**
 * The two trainerbattle (0x5C) argument shapes this app decodes — see
 * [ArgSpec.TrainerBattle]'s doc. Shared by [ScriptDisassembler] and
 * [ScriptAssembler] so the read and write sides of pokescript editing stay
 * in sync by construction rather than by two hand-maintained copies of the
 * same battle-type-number sets.
 */
object TrainerBattleShapes {
    private val STANDARD_TYPES = setOf(0, 2, 5, 6, 7)
    private val EXTENDED_TYPES = setOf(1, 3, 8, 9)
    private val STANDARD_ARGS = listOf(ArgType.BYTE, ArgType.WORD, ArgType.WORD, ArgType.POINTER, ArgType.POINTER)
    private val EXTENDED_ARGS = STANDARD_ARGS + ArgType.POINTER

    /** Null for any battle-type byte this app doesn't have a verified shape for — the caller should stop rather than guess (see [ArgSpec.TrainerBattle]). */
    fun argsFor(battleType: Int): List<ArgType>? = when (battleType) {
        in STANDARD_TYPES -> STANDARD_ARGS
        in EXTENDED_TYPES -> EXTENDED_ARGS
        else -> null
    }
}
