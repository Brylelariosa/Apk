package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/** One decoded step of a disassembled animation script — see [BattleAnimScriptDisassembler]. */
sealed class AnimScriptStep {
    /** A command this app has a verified byte layout for, decoded into a real, human-readable summary. */
    data class Command(val offset: Long, val opcode: Int, val name: String, val summary: String, val byteLength: Int) : AnimScriptStep()

    /** Where and why linear decoding stopped — not an error, just the honest edge of what this app currently decodes. */
    data class Stopped(val offset: Long, val reason: String) : AnimScriptStep()
}

data class DisassembledAnimScript(val steps: List<AnimScriptStep>, val fullyDecoded: Boolean)

/**
 * Disassembles a FireRed battle animation script into real commands —
 * `delay 4`, `playse SE_M_TACKLE`, `call 0x1C74B0` — rather than treating
 * the bytes as opaque data. Where [BattleAnimationReader] resolves *which*
 * bytes a move's animation script actually is, this decodes what they mean.
 *
 * The command set is the real one: all 48 opcode names below (0x00-0x2F)
 * come directly from `sScriptCmdTable[]` in pret/pokefirered's
 * `src/battle_anim.c` — the actual interpreter's own dispatch table, not a
 * guess. This app has independently verified the exact byte layout (how
 * many bytes each argument takes, and what it means) for [DECODED_OPCODES]
 * of those 48, each read from that same file's own command handler
 * (`Cmd_delay`, `Cmd_playse`, etc.) — see the `when` branches below, each
 * commented with which real field it reads. The remaining opcodes are
 * real, named commands too (`playsewithpan`, `loopsewithpan`, `goto`
 * aside — see below) — this app just doesn't have their exact operand
 * widths pinned down yet, and guessing would silently desync every byte
 * after the guess, which is worse than stopping cleanly. [disassemble]
 * decodes as far as it verifiably can and then stops with an honest
 * [AnimScriptStep.Stopped], naming the real command it stopped at rather
 * than continuing on a guess.
 *
 * `goto` (0x13) is the one exception decoded without its own directly-seen
 * C body: its only job is an unconditional jump, and it shares the exact
 * `T2_READ_PTR` 4-byte-pointer pattern this app *did* verify for `call`
 * (0x0E) and `choosetwoturnanim` (0x11) — the same pattern reused a third
 * time, not a new guess.
 */
object BattleAnimScriptDisassembler {
    /** Real command names for every opcode 0x00-0x2F, straight from `sScriptCmdTable[]` — shown even for opcodes this app can't decode the operands of yet, since the name alone is still real, verified information. */
    private val COMMAND_NAMES = listOf(
        "loadspritegfx", "unloadspritegfx", "createsprite", "createvisualtask", "delay",
        "waitforvisualfinish", "nop", "nop2", "end", "playse", "monbg", "clearmonbg",
        "setalpha", "blendoff", "call", "return", "setarg", "choosetwoturnanim",
        "jumpifmoveturn", "goto", "fadetobg", "restorebg", "waitbgfadeout", "waitbgfadein",
        "changebg", "playsewithpan", "setpan", "panse", "loopsewithpan", "waitplaysewithpan",
        "setbldcnt", "createsoundtask", "waitsound", "jumpargeq", "monbg_static",
        "clearmonbg_static", "jumpifcontest", "fadetobgfromset", "panse_adjustnone",
        "panse_adjustall", "splitbgprio", "splitbgprio_all", "splitbgprio_foes",
        "invisible", "visible", "teamattack_moveback", "teamattack_movefwd", "stopsound",
    )

    /** Opcodes with a verified operand layout — see class doc. Used only for the "X of 48" figure shown to the user. */
    const val DECODED_OPCODE_COUNT = 19

    // Safety bound against a call/goto cycle this app's decoder would
    // otherwise walk forever — real scripts are nowhere near this long.
    private const val MAX_STEPS = 400

    suspend fun disassemble(rom: RomAccessor, startOffset: Long): DisassembledAnimScript {
        val steps = mutableListOf<AnimScriptStep>()
        val callStack = ArrayDeque<Long>()
        var offset = startOffset
        var stepCount = 0

        while (true) {
            if (stepCount++ >= MAX_STEPS) {
                steps += AnimScriptStep.Stopped(offset, "Stopped after $MAX_STEPS commands — this script (or a call/goto loop in it) runs longer than this app follows in one go.")
                return DisassembledAnimScript(steps, fullyDecoded = false)
            }
            if (offset < 0 || offset + 1 > rom.sizeBytes) {
                steps += AnimScriptStep.Stopped(offset, "Stopped: this address falls outside the ROM.")
                return DisassembledAnimScript(steps, fullyDecoded = false)
            }
            val opcodeByte = rom.read(offset, 1).firstOrNull()?.let { it.toInt() and 0xFF }
            if (opcodeByte == null) {
                steps += AnimScriptStep.Stopped(offset, "Stopped: couldn't read the next byte.")
                return DisassembledAnimScript(steps, fullyDecoded = false)
            }
            val name = COMMAND_NAMES.getOrNull(opcodeByte) ?: "opcode 0x${opcodeByte.toString(16).uppercase()}"

            val decoded = decodeOne(rom, offset, opcodeByte, name)
            if (decoded == null) {
                steps += AnimScriptStep.Stopped(
                    offset,
                    "Stopped at a real command, $name (0x${opcodeByte.toString(16).uppercase().padStart(2, '0')}) — " +
                        "this app has verified byte layouts for $DECODED_OPCODE_COUNT of the 48 real commands so far, and this isn't yet one of them.",
                )
                return DisassembledAnimScript(steps, fullyDecoded = false)
            }
            steps += AnimScriptStep.Command(offset, opcodeByte, name, decoded.summary, decoded.byteLength)

            when (val control = decoded.control) {
                Control.Continue -> offset += decoded.byteLength
                Control.End -> return DisassembledAnimScript(steps, fullyDecoded = true)
                is Control.Jump -> offset = control.target
                is Control.Call -> {
                    callStack.addLast(offset + decoded.byteLength)
                    offset = control.target
                }
                Control.Return -> {
                    val returnTo = callStack.removeLastOrNull()
                    if (returnTo == null) {
                        steps += AnimScriptStep.Stopped(offset, "Stopped: return with no call on this app's call stack to return to.")
                        return DisassembledAnimScript(steps, fullyDecoded = false)
                    }
                    offset = returnTo
                }
                Control.Branch -> {
                    // e.g. choosetwoturnanim: which target actually runs
                    // depends on runtime battle state (which turn of a
                    // two-turn move this is) this app has no way to know
                    // statically — both targets are already named in the
                    // command's own summary, so this stops here rather
                    // than guessing which one a real battle would take.
                    return DisassembledAnimScript(steps, fullyDecoded = false)
                }
            }
        }
    }

    private sealed class Control {
        data object Continue : Control()
        data object End : Control()
        data class Jump(val target: Long) : Control()
        data class Call(val target: Long) : Control()
        data object Return : Control()
        data object Branch : Control()
    }

    private data class Decoded(val summary: String, val byteLength: Int, val control: Control)

    /** One command's operand bytes, decoded from [offset] (which still points at the opcode byte itself). Returns null for any opcode not in the verified set. */
    private suspend fun decodeOne(rom: RomAccessor, offset: Long, opcode: Int, name: String): Decoded? {
        // Small local helpers — every command below reads its own operand
        // window starting right after the opcode byte.
        suspend fun bytesAfterOpcode(count: Int): ByteArray? {
            val bytes = rom.read(offset + 1, count)
            return bytes.takeIf { it.size == count }
        }
        fun u8(bytes: ByteArray, i: Int) = bytes[i].toInt() and 0xFF
        fun u16(bytes: ByteArray, i: Int) = (bytes[i].toInt() and 0xFF) or ((bytes[i + 1].toInt() and 0xFF) shl 8)
        suspend fun pointerAfterOpcode(): Long? = bytesAfterOpcode(4)?.let { GbaGraphics.readPointer32(it, 0) }

        return when (opcode) {
            // Cmd_loadspritegfx: sBattleAnimScriptPtr++; index = T1_READ_16(ptr); ptr += 2
            0x00, 0x01 -> {
                val args = bytesAfterOpcode(2) ?: return null
                Decoded("$name sprite #${u16(args, 0)}", 3, Control.Continue)
            }
            // Cmd_createsprite: ptr(4) template, u8 flags, u8 argsCount, then argsCount * u16
            0x02 -> {
                val header = bytesAfterOpcode(6) ?: return null
                val template = GbaGraphics.readPointer32(header, 0)
                val flags = u8(header, 4)
                val argsCount = u8(header, 5)
                val argBytes = if (argsCount > 0) rom.read(offset + 7, argsCount * 2) else ByteArray(0)
                if (argBytes.size != argsCount * 2) return null
                val args = (0 until argsCount).map { u16(argBytes, it * 2) }
                val target = if (flags and 0x80 != 0) "target" else "attacker"
                val templateHex = template?.let { "0x${it.toString(16).uppercase()}" } ?: "an invalid pointer"
                Decoded("createsprite $templateHex, relative to $target, args=$args", 7 + argsCount * 2, Control.Continue)
            }
            // Cmd_createvisualtask: ptr(4) taskFunc, u8 priority, u8 numArgs, then numArgs * u16
            0x03 -> {
                val header = bytesAfterOpcode(6) ?: return null
                val taskFunc = GbaGraphics.readPointer32(header, 0)
                val priority = u8(header, 4)
                val numArgs = u8(header, 5)
                val argBytes = if (numArgs > 0) rom.read(offset + 7, numArgs * 2) else ByteArray(0)
                if (argBytes.size != numArgs * 2) return null
                val args = (0 until numArgs).map { u16(argBytes, it * 2) }
                val taskHex = taskFunc?.let { "0x${it.toString(16).uppercase()}" } ?: "an invalid pointer"
                Decoded("createvisualtask $taskHex, priority=$priority, args=$args", 7 + numArgs * 2, Control.Continue)
            }
            // Cmd_delay: sAnimFramesToWait = ptr[0]; 0 means "wait indefinitely" (until something else cancels it)
            0x04 -> {
                val args = bytesAfterOpcode(1) ?: return null
                val frames = u8(args, 0)
                Decoded(if (frames == 0) "delay indefinitely" else "delay $frames frame${if (frames == 1) "" else "s"}", 2, Control.Continue)
            }
            // Cmd_waitforvisualfinish: no operand bytes — polls gAnimVisualTaskCount at runtime
            0x05 -> Decoded("wait for all sprites/visual tasks to finish", 1, Control.Continue)
            // Cmd_nop / Cmd_nop2: empty bodies in the real interpreter — verified dead opcodes, not just unimplemented ones
            0x06, 0x07 -> Decoded("$name (does nothing — confirmed dead in the real interpreter)", 1, Control.Continue)
            // Cmd_end: terminates the whole animation
            0x08 -> Decoded("end", 1, Control.End)
            // Cmd_playse: PlaySE(T1_READ_16(ptr))
            0x09 -> {
                val args = bytesAfterOpcode(2) ?: return null
                Decoded("play sound #${u16(args, 0)}", 3, Control.Continue)
            }
            // Cmd_monbg / Cmd_clearmonbg: single battler-selector byte
            0x0A, 0x0B -> {
                val args = bytesAfterOpcode(1) ?: return null
                Decoded("$name battler ${u8(args, 0)}", 2, Control.Continue)
            }
            // Cmd_setalpha: two separate blend coefficient bytes (EVA, EVB)
            0x0C -> {
                val args = bytesAfterOpcode(2) ?: return null
                Decoded("set blend alpha (EVA=${u8(args, 0)}, EVB=${u8(args, 1)})", 3, Control.Continue)
            }
            // Cmd_blendoff: no operand bytes
            0x0D -> Decoded("turn off blending", 1, Control.Continue)
            // Cmd_call: sBattleAnimScriptRetAddr = ptr+4; ptr = T2_READ_PTR(ptr) — a real subroutine call
            0x0E -> {
                val target = pointerAfterOpcode() ?: return null
                Decoded("call 0x${target.toString(16).uppercase()}", 5, Control.Call(target))
            }
            // Cmd_return: sBattleAnimScriptPtr = sBattleAnimScriptRetAddr — no operand bytes
            0x0F -> Decoded("return", 1, Control.Return)
            // Cmd_setarg: u8 argId, u16 value
            0x10 -> {
                val args = bytesAfterOpcode(3) ?: return null
                Decoded("set anim arg[${u8(args, 0)}] = ${u16(args, 1)}", 4, Control.Continue)
            }
            // Cmd_choosetwoturnanim: two back-to-back 4-byte pointers (first-turn, second-turn); runtime picks one via gAnimMoveTurn
            0x11 -> {
                val both = bytesAfterOpcode(8) ?: return null
                val firstTurn = GbaGraphics.readPointer32(both, 0)
                val secondTurn = GbaGraphics.readPointer32(both, 4)
                val firstHex = firstTurn?.let { "0x${it.toString(16).uppercase()}" } ?: "an invalid pointer"
                val secondHex = secondTurn?.let { "0x${it.toString(16).uppercase()}" } ?: "an invalid pointer"
                Decoded("branch on move turn: first turn → $firstHex, second turn → $secondHex", 9, Control.Branch)
            }
            // Cmd_goto: unconditional jump — verified by the identical T2_READ_PTR pattern call/choosetwoturnanim use, see class doc
            0x13 -> {
                val target = pointerAfterOpcode() ?: return null
                Decoded("goto 0x${target.toString(16).uppercase()}", 5, Control.Jump(target))
            }
            // Cmd_setbldcnt: two raw bytes combined into the BLDCNT register value directly (not two separate fields like setalpha)
            0x1E -> {
                val args = bytesAfterOpcode(2) ?: return null
                val value = u8(args, 0) or (u8(args, 1) shl 8)
                Decoded("set raw blend control = 0x${value.toString(16).uppercase()}", 3, Control.Continue)
            }
            else -> null
        }
    }
}
