package com.romexplorer.gba.core.graphics

import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.compression.Lz77FormatException
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * A decoded, ready-to-render image: row-major ARGB_8888 pixels. Plain class
 * (not `data`) with hand-written [equals]/[hashCode] because [IntArray]'s
 * own equals is reference-based — a generated data-class equals would
 * silently compare array identity, not pixel content.
 */
class DecodedImage(val width: Int, val height: Int, val pixels: IntArray) {
    override fun equals(other: Any?): Boolean =
        other is DecodedImage && width == other.width && height == other.height && pixels.contentEquals(other.pixels)

    override fun hashCode(): Int = 31 * (31 * width + height) + pixels.contentHashCode()
}

/**
 * Decodes the GBA's native graphics formats: 15-bit BGR555 palettes and
 * 4bpp (16-color) tiled bitmaps. Unlike every ROM offset elsewhere in this
 * app, this is fixed Game Boy Advance PPU hardware behavior — the same on
 * every GBA game, not something reverse-engineered from FireRed
 * specifically — so it's implemented and tested independently of any ROM
 * offset, and reused by every sprite/icon reader in [com.romexplorer.gba.core.pokemon].
 */
object GbaGraphics {
    private const val COLORS_PER_PALETTE = 16
    private const val BYTES_PER_COLOR = 2
    private const val TILE_SIZE_PX = 8
    private const val BYTES_PER_TILE_ROW = 4 // 8 pixels, 2 per byte at 4bpp

    /**
     * Decodes a 16-color GBA palette (32 bytes) to ARGB_8888. Each color is
     * a 15-bit value: bits 0-4 red, 5-9 green, 10-14 blue, scaled from a
     * 5-bit to an 8-bit channel. Palette index 0 is GBA hardware's
     * transparency key for sprites — decoded to alpha 0 rather than
     * whatever color happens to be stored there.
     */
    fun decodePalette(bytes: ByteArray, offset: Int = 0): IntArray {
        val colors = IntArray(COLORS_PER_PALETTE)
        for (i in 0 until COLORS_PER_PALETTE) {
            val byteOffset = offset + i * BYTES_PER_COLOR
            val lo = bytes[byteOffset].toInt() and 0xFF
            val hi = bytes[byteOffset + 1].toInt() and 0xFF
            val value = lo or (hi shl 8)
            val r = scale5to8(value and 0x1F)
            val g = scale5to8((value shr 5) and 0x1F)
            val b = scale5to8((value shr 10) and 0x1F)
            val alpha = if (i == 0) 0x00 else 0xFF
            colors[i] = (alpha shl 24) or (r shl 16) or (g shl 8) or b
        }
        return colors
    }

    /**
     * Decodes 4bpp tile-planar pixel data to a row-major ARGB pixel array.
     * GBA tiles are 8x8 pixels, 32 bytes each (2 pixels/byte, low nibble
     * first), and the tile stream is ordered left-to-right across each
     * 8-pixel-tall band before moving down to the next band — not simple
     * row-major over the whole image.
     */
    fun decode4bpp(tileData: ByteArray, palette: IntArray, widthPx: Int, heightPx: Int): IntArray {
        val tilesX = widthPx / TILE_SIZE_PX
        val tilesY = heightPx / TILE_SIZE_PX
        val out = IntArray(widthPx * heightPx)
        var pos = 0
        for (tileY in 0 until tilesY) {
            for (tileX in 0 until tilesX) {
                for (row in 0 until TILE_SIZE_PX) {
                    for (col in 0 until BYTES_PER_TILE_ROW) {
                        val b = tileData[pos++].toInt() and 0xFF
                        val left = palette[b and 0x0F]
                        val right = palette[(b shr 4) and 0x0F]
                        val px = tileX * TILE_SIZE_PX + col * 2
                        val py = tileY * TILE_SIZE_PX + row
                        out[py * widthPx + px] = left
                        out[py * widthPx + px + 1] = right
                    }
                }
            }
        }
        return out
    }

    /** Reads a 4-byte little-endian ROM pointer (0x08xxxxxx) and converts it to a file offset, or null if it's not a ROM address. */
    fun readPointer32(bytes: ByteArray, offset: Int): Long? {
        val raw = (bytes[offset].toLong() and 0xFF) or
            ((bytes[offset + 1].toLong() and 0xFF) shl 8) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 16) or
            ((bytes[offset + 3].toLong() and 0xFF) shl 24)
        return if (raw in 0x08000000L..0x09FFFFFFL) raw - 0x08000000L else null
    }

    /**
     * Reads [expectedDecompressedSize] bytes of pixel/palette data starting
     * at [pointer], transparently handling both the LZ77-compressed and
     * raw-uncompressed cases some FireRed graphics tables mix (see the
     * per-asset readers for which is expected where, and how confident that
     * expectation is). Returns null — never truncated or malformed data —
     * if decompression fails or the result isn't exactly the expected size,
     * so a wrong offset shows no image rather than a corrupted one.
     */
    suspend fun readPossiblyCompressed(rom: RomAccessor, pointer: Long, expectedDecompressedSize: Int): ByteArray? {
        if (pointer <= 0) return null
        val firstByte = rom.readByte(pointer)
        if (firstByte < 0) return null
        return if (Lz77Codec.isLikelyHeader(firstByte)) {
            // Generous upper bound on compressed size — LZ77 worst case is
            // ~9 bytes per 8 input bytes (all-literal blocks) plus a 4-byte
            // header; RomAccessor safely truncates near ROM end, and
            // Lz77Codec.decompress stops reading once it has produced
            // exactly expectedDecompressedSize bytes, so over-requesting
            // here is harmless either way.
            val compressed = rom.read(pointer, expectedDecompressedSize * 2 + 32)
            try {
                Lz77Codec.decompress(compressed).takeIf { it.size == expectedDecompressedSize }
            } catch (e: Lz77FormatException) {
                null
            }
        } else {
            rom.read(pointer, expectedDecompressedSize).takeIf { it.size == expectedDecompressedSize }
        }
    }

    private fun scale5to8(value5: Int): Int = (value5 * 255) / 31
}
