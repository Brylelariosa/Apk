@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.pokemontables

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.pokemon.DisplayField
import com.romexplorer.gba.core.pokemon.DisplayRow
import com.romexplorer.gba.core.pokemon.FireRedTables
import com.romexplorer.gba.core.pokemon.TrainerPartyMember
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.ui.common.ConfirmDialog
import com.romexplorer.gba.ui.common.toImageBitmap
import org.koin.androidx.compose.koinViewModel

/** Which field the edit dialog is currently open for, captured at tap time. Shared with FieldEditDialogs.kt. */
data class EditTarget(val schema: KnownTableSchema, val rowIndex: Int, val field: DisplayField)

/** The three tables "add a new entry" (see AddEntryDialogs.kt) supports, and the label to show for each. Trainers/types don't go through this flow — trainers have no reliable "unused" convention, and types are handled separately via a custom label, not a claimed ROM slot. */
private fun addEntryLabelFor(schema: KnownTableSchema): String? = when (schema) {
    FireRedTables.items -> "item"
    FireRedTables.speciesBaseStats -> "Pokémon"
    FireRedTables.moves -> "move"
    else -> null
}

@Composable
fun PokemonTableScreen(
    navController: NavHostController,
    viewModel: PokemonTableViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedTable by viewModel.selectedTable.collectAsState()
    val isLoading by viewModel.isLoadingTable.collectAsState()
    val editStatus by viewModel.editStatus.collectAsState()
    val romDisplayName by viewModel.romDisplayName.collectAsState()
    val corruptionScanState by viewModel.corruptedTrainerScan.collectAsState()

    var editTarget by remember { mutableStateOf<EditTarget?>(null) }
    var showAddEntry by remember { mutableStateOf(false) }
    var showDiscardConfirm by remember { mutableStateOf(false) }
    var showCorruptionScan by remember { mutableStateOf(false) }
    var animatingMoveRow by remember { mutableStateOf<DisplayRow?>(null) }
    var editingTeamRowIndex by remember { mutableStateOf<Int?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri -> if (uri != null) viewModel.exportRom(uri) { } }

    LaunchedEffect(editStatus) {
        editStatus?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearEditStatus()
        }
    }

    val romOpen = uiState is PokemonTablesState.Ready
    val addEntryLabel = selectedTable?.schema?.let { addEntryLabelFor(it) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(selectedTable?.schema?.displayName ?: "Pokémon Tables") },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedTable != null) viewModel.clearSelection() else navController.popBackStack()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (selectedTable != null && viewModel.canUndoEdit()) {
                        TextButton(onClick = { viewModel.undoEdit() }) { Text("Undo") }
                    }
                    if (selectedTable?.schema == FireRedTables.trainers) {
                        IconButton(onClick = {
                            showCorruptionScan = true
                            viewModel.scanForCorruptedTrainers()
                        }) {
                            Icon(Icons.Filled.Warning, contentDescription = "Scan for trainers with implausible party data")
                        }
                    }
                    if (romOpen && viewModel.hasUnsavedEdits()) {
                        IconButton(onClick = { showDiscardConfirm = true }) {
                            Icon(Icons.Filled.RestartAlt, contentDescription = "Discard all unsaved edits")
                        }
                    }
                    if (romOpen) {
                        IconButton(onClick = { saveLauncher.launch("${romDisplayName ?: "rom"}_edited.gba") }) {
                            Icon(Icons.Filled.Save, contentDescription = "Save edited ROM")
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            if (addEntryLabel != null) {
                FloatingActionButton(onClick = { showAddEntry = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add new $addEntryLabel")
                }
            }
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                selectedTable != null -> EntryList(
                    selection = selectedTable!!,
                    viewModel = viewModel,
                    onFieldTap = { rowIndex, field -> editTarget = EditTarget(selectedTable!!.schema, rowIndex, field) },
                    onPreviewAnimation = if (selectedTable!!.schema == FireRedTables.moves) {
                        { row -> animatingMoveRow = row }
                    } else {
                        null
                    },
                    onEditTeam = if (selectedTable!!.schema == FireRedTables.trainers) {
                        { row -> editingTeamRowIndex = row.index }
                    } else {
                        null
                    },
                )
                uiState is PokemonTablesState.NoRomOpen -> CenteredMessage("Open a ROM first.")
                uiState is PokemonTablesState.NotFireRed -> CenteredMessage(
                    "These known tables are specific to Pokémon FireRed — this ROM isn't recognized as FireRed.",
                )
                uiState is PokemonTablesState.Ready -> TableList(
                    tables = (uiState as PokemonTablesState.Ready).availableTables,
                    onSelect = viewModel::selectTable,
                )
            }
        }
    }

    editTarget?.let { target ->
        EditFieldDialog(
            target = target,
            viewModel = viewModel,
            onDismiss = { editTarget = null },
            onConfirm = { newValue ->
                target.field.editableField?.let { viewModel.editField(target.schema, target.rowIndex, it, newValue) }
                editTarget = null
            },
        )
    }

    val currentSchemaForAddEntry = selectedTable?.schema
    if (showAddEntry && addEntryLabel != null && currentSchemaForAddEntry != null) {
        AddEntryFlow(
            schema = currentSchemaForAddEntry,
            entryLabel = addEntryLabel,
            viewModel = viewModel,
            onDismiss = { showAddEntry = false },
            onClaimed = { index, name ->
                viewModel.claimSlot(currentSchemaForAddEntry, index, name)
                showAddEntry = false
            },
        )
    }

    animatingMoveRow?.let { row ->
        val typeValue = row.fields.firstOrNull { it.label == "Type" }?.value?.takeIf { it.isNotBlank() } ?: "Normal"
        val powerValue = row.fields.firstOrNull { it.label == "Base Power" }?.value?.toIntOrNull() ?: 0
        // Real work (a ROM read) kept out of viewModelScope on purpose — see
        // PokemonTableViewModel.loadSpeciesIcon's doc for why produceState,
        // tied to this composable's own lifecycle, is the right scope here.
        val scriptState by produceState<com.romexplorer.gba.core.pokemon.BattleAnimationScript?>(initialValue = null, row.index) {
            value = viewModel.loadBattleAnimation(row.index)
        }
        val disassemblyState by produceState<com.romexplorer.gba.core.pokemon.DisassembledAnimScript?>(initialValue = null, row.index) {
            value = viewModel.loadBattleAnimationDisassembly(row.index)
        }
        MoveAnimationDialog(
            moveName = row.title ?: "Move #${row.index}",
            typeName = typeValue,
            power = powerValue,
            script = scriptState,
            disassembly = disassemblyState,
            onDismiss = { animatingMoveRow = null },
        )
    }

    editingTeamRowIndex?.let { idx ->
        val row = selectedTable?.rows?.firstOrNull { it.index == idx }
        if (row != null) {
            val partyFlags = row.fields.firstOrNull { it.label == "Party Flags" }?.value?.toIntOrNull() ?: 0
            TeamEditDialog(
                trainerRowIndex = row.index,
                trainerName = row.title ?: "Trainer #${row.index}",
                partyFlags = partyFlags,
                members = row.partyMembers,
                viewModel = viewModel,
                onDismiss = { editingTeamRowIndex = null },
            )
        }
    }

    if (showDiscardConfirm) {
        ConfirmDialog(
            title = "Discard all unsaved edits?",
            message = "Every field you've changed on this ROM reverts back to its original value. This can't be undone once confirmed.",
            confirmLabel = "Discard",
            onConfirm = {
                viewModel.discardAllEdits()
                showDiscardConfirm = false
            },
            onDismiss = { showDiscardConfirm = false },
        )
    }

    if (showCorruptionScan) {
        CorruptionScanDialog(
            state = corruptionScanState,
            onSelectTrainer = { trainerRowIndex ->
                showCorruptionScan = false
                viewModel.dismissCorruptedTrainerScan()
                editingTeamRowIndex = trainerRowIndex
            },
            onDismiss = {
                showCorruptionScan = false
                viewModel.dismissCorruptedTrainerScan()
            },
        )
    }
}

/**
 * Results of [PokemonTableViewModel.scanForCorruptedTrainers] — see
 * [CorruptedPartyScanner]'s doc for what "suspicious" means here. Tapping a
 * result opens that trainer's Edit Team dialog directly (the same one any
 * other edit uses) rather than this dialog trying to fix anything itself —
 * a scan can find where to look, not what the correct data should be.
 */
@Composable
private fun CorruptionScanDialog(
    state: CorruptedTrainerScanState?,
    onSelectTrainer: (Int) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Suspicious trainer data") },
        text = {
            when (state) {
                null, CorruptedTrainerScanState.Scanning -> {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is CorruptedTrainerScanState.Done -> {
                    if (state.results.isEmpty()) {
                        Text("No trainers with an implausible level or species were found.")
                    } else {
                        Column(modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                            Text(
                                "${state.results.size} trainer${if (state.results.size == 1) "" else "s"} found. Tap one to open its team and fix it — this app can find where to look, not what the correct team should be.",
                                style = MaterialTheme.typography.bodySmall,
                            )
                            Spacer(Modifier.height(8.dp))
                            state.results.forEach { trainer ->
                                Column(
                                    modifier = Modifier.fillMaxWidth().clickable { onSelectTrainer(trainer.trainerRowIndex) }.padding(vertical = 6.dp),
                                ) {
                                    Text("#${trainer.trainerRowIndex} ${trainer.trainerName}", style = MaterialTheme.typography.bodyMedium)
                                    trainer.members.forEach { member ->
                                        Text(
                                            "  Pokémon ${member.memberIndex + 1}: ${member.reason}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun CenteredMessage(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text)
    }
}

@Composable
private fun TableList(tables: List<KnownTableSchema>, onSelect: (KnownTableSchema) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        items(tables) { schema ->
            Card(onClick = { onSelect(schema) }, modifier = Modifier.padding(vertical = 4.dp)) {
                ListItem(
                    headlineContent = { Text(schema.displayName) },
                    supportingContent = { Text("${schema.entryCount} entries · ${schema.fields.size} fields") },
                )
            }
        }
    }
}

/**
 * One card per entry, fields laid out two-per-row and wrapped to the
 * screen's width — unlike a spreadsheet grid, this never needs horizontal
 * scrolling no matter how many fields a schema has. A search field pinned
 * above the list filters by name or index — the "long scroll" this
 * addresses can mean scrolling through up to ~750 rows otherwise.
 */
@Composable
private fun EntryList(
    selection: PokemonTableSelection,
    viewModel: PokemonTableViewModel,
    onFieldTap: (rowIndex: Int, field: DisplayField) -> Unit,
    onPreviewAnimation: ((DisplayRow) -> Unit)?,
    onEditTeam: ((DisplayRow) -> Unit)?,
) {
    var query by remember(selection.schema) { mutableStateOf("") }
    val filteredRows = remember(selection.rows, query) {
        val q = query.trim()
        if (q.isBlank()) {
            selection.rows
        } else {
            selection.rows.filter { row ->
                row.index.toString() == q ||
                    "#${row.index}".equals(q, ignoreCase = true) ||
                    (row.title?.contains(q, ignoreCase = true) == true)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search by name or #") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        )
        if (filteredRows.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No matches for \"$query\"")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            ) {
                items(filteredRows, key = { it.index }) { row ->
                    EntryCard(selection.schema, row, viewModel, onFieldTap, onPreviewAnimation, onEditTeam)
                }
            }
        }
    }
}

@Composable
private fun EntryCard(
    schema: KnownTableSchema,
    row: DisplayRow,
    viewModel: PokemonTableViewModel,
    onFieldTap: (rowIndex: Int, field: DisplayField) -> Unit,
    onPreviewAnimation: ((DisplayRow) -> Unit)?,
    onEditTeam: ((DisplayRow) -> Unit)?,
) {
    val showsIcon = schema == FireRedTables.speciesBaseStats || schema == FireRedTables.items || schema == FireRedTables.trainers
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(12.dp)) {
            if (showsIcon) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    EntryIcon(schema, row, viewModel)
                    Spacer(modifier = Modifier.width(8.dp))
                    EntryTitle(row)
                }
            } else {
                EntryTitle(row)
            }
            Spacer(modifier = Modifier.height(6.dp))
            FieldGrid(row.fields, row.index, onFieldTap)
            if (onEditTeam != null) {
                Spacer(modifier = Modifier.height(6.dp))
                PartySection(row.partyMembers, row.partyLines, viewModel, onEditTeam = { onEditTeam(row) })
            }
            if (onPreviewAnimation != null) {
                TextButton(onClick = { onPreviewAnimation(row) }, modifier = Modifier.padding(top = 2.dp)) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Preview animation")
                }
            }
        }
    }
}

@Composable
private fun EntryTitle(row: DisplayRow) {
    Text(
        text = if (row.title != null) "#${row.index}  ${row.title}" else "#${row.index}",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
    )
}

/**
 * Loads its row's icon lazily, in a coroutine scoped to this composable's
 * own lifetime via `produceState` — not `viewModelScope` — so decoding
 * only happens while the row is actually on screen (LazyColumn only keeps
 * near-visible rows composed) and is cancelled the moment it scrolls away.
 * Shows nothing (not even a placeholder box) while loading or if this
 * particular entry has no image — a blank cell reads better here than a
 * "broken image" glyph for something that's often genuinely just empty.
 */
@Composable
private fun EntryIcon(schema: KnownTableSchema, row: DisplayRow, viewModel: PokemonTableViewModel) {
    val image by produceState<DecodedImage?>(initialValue = null, row.index, row.trainerPicIndex, schema) {
        value = when (schema) {
            FireRedTables.speciesBaseStats -> viewModel.loadSpeciesIcon(row.index)
            FireRedTables.items -> viewModel.loadItemIcon(row.index)
            FireRedTables.trainers -> row.trainerPicIndex?.let { viewModel.loadTrainerSprite(it) }
            else -> null
        }
    }
    val bitmap = image?.toImageBitmap()
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(40.dp))
    } else {
        Spacer(modifier = Modifier.size(40.dp))
    }
}

/**
 * Each party member on its own row with its own species icon, and a
 * "Party (N)" header stating the count up front — previously this was
 * unstyled plain-text lines with no count and no icons, easy to mistake
 * for "only one Pokémon" when a trainer actually had several.
 */
@Composable
private fun PartySection(
    members: List<TrainerPartyMember>,
    partyLines: List<String>,
    viewModel: PokemonTableViewModel,
    onEditTeam: () -> Unit,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Party (${partyLines.size})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onEditTeam) { Text("Edit team") }
        }
        partyLines.forEachIndexed { i, line ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                members.getOrNull(i)?.species?.let { speciesIndex ->
                    PartyMemberIcon(speciesIndex, viewModel)
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(line, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun PartyMemberIcon(speciesIndex: Int, viewModel: PokemonTableViewModel) {
    val image by produceState<DecodedImage?>(initialValue = null, speciesIndex) {
        value = viewModel.loadSpeciesIcon(speciesIndex)
    }
    val bitmap = image?.toImageBitmap()
    if (bitmap != null) {
        Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(28.dp))
    } else {
        Spacer(modifier = Modifier.size(28.dp))
    }
}

/** Two-column label/value layout; wraps within the available width instead of scrolling sideways. */
@Composable
private fun FieldGrid(fields: List<DisplayField>, rowIndex: Int, onFieldTap: (rowIndex: Int, field: DisplayField) -> Unit) {
    Column {
        fields.chunked(2).forEach { pair ->
            Row(modifier = Modifier.fillMaxWidth()) {
                FieldCell(pair[0], Modifier.weight(1f)) { onFieldTap(rowIndex, pair[0]) }
                if (pair.size > 1) {
                    FieldCell(pair[1], Modifier.weight(1f)) { onFieldTap(rowIndex, pair[1]) }
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/** Editable fields (a plain number under the hood, see PokemonTableWriter) are tappable and shown in the theme's accent color as a lightweight "you can edit this" signal. */
@Composable
private fun FieldCell(field: DisplayField, modifier: Modifier, onTap: () -> Unit) {
    val editable = field.editableField != null
    Column(
        modifier = if (editable) modifier.padding(vertical = 3.dp).clickable(onClick = onTap) else modifier.padding(vertical = 3.dp),
    ) {
        Text(field.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            field.value,
            style = MaterialTheme.typography.bodyMedium,
            color = if (editable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
    }
}
