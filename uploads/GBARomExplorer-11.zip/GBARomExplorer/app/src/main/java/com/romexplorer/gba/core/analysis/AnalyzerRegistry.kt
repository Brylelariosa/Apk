package com.romexplorer.gba.core.analysis

/**
 * Central place plugins register themselves. Core code (AnalysisEngine)
 * only ever calls [analyzersForGameCode] — it never references a concrete
 * plugin class, so adding a new one is a one-line [register] call and
 * nothing in the core engine changes.
 */
class AnalyzerRegistry {
    private val plugins = mutableListOf<GameAnalyzerPlugin>()

    fun register(plugin: GameAnalyzerPlugin) {
        plugins += plugin
    }

    fun analyzersForGameCode(gameCode: String): List<RegionAnalyzer> =
        plugins.filter { it.supports(gameCode) }.flatMap { it.analyzersFor(gameCode) }
}
