package com.romexplorer.gba.domain.usecase

import android.content.Context
import android.net.Uri
import com.romexplorer.gba.core.analysis.model.RomMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

enum class ReportFormat(val label: String, val mimeType: String, val suggestedExtension: String) {
    JSON("JSON", "application/json", "json"),
    CSV("CSV", "text/csv", "csv"),
    HTML("HTML", "text/html", "html"),
    MARKDOWN("Markdown", "text/markdown", "md"),
}

/**
 * Renders a [RomMap] analysis result into one of the requested report
 * formats and writes it to a user-chosen SAF destination. UI is
 * responsible for launching the document-creation picker; this use case
 * only needs the resulting [Uri].
 */
class ExportReportUseCase(private val context: Context) {

    private val json = Json { prettyPrint = true }

    suspend fun export(
        romMap: RomMap,
        romDisplayName: String,
        format: ReportFormat,
        destination: Uri,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val content = render(romMap, romDisplayName, format)
            context.contentResolver.openOutputStream(destination)?.use { out ->
                out.write(content.toByteArray(Charsets.UTF_8))
            } ?: error("Unable to open output stream for report destination")
        }
    }

    private fun render(romMap: RomMap, romDisplayName: String, format: ReportFormat): String = when (format) {
        ReportFormat.JSON -> json.encodeToString(RomMap.serializer(), romMap)
        ReportFormat.CSV -> renderCsv(romMap)
        ReportFormat.HTML -> renderHtml(romMap, romDisplayName)
        ReportFormat.MARKDOWN -> renderMarkdown(romMap, romDisplayName)
    }

    private fun renderCsv(romMap: RomMap): String = buildString {
        appendLine("start_offset,end_offset,length,type,confidence,label")
        for (r in romMap.regions.sortedBy { it.startOffset }) {
            append("0x").append(r.startOffset.toString(16)).append(',')
            append("0x").append(r.endOffsetExclusive.toString(16)).append(',')
            append(r.length).append(',')
            append(r.type.name).append(',')
            append(r.confidence).append(',')
            append('"').append(r.label.replace("\"", "'")).append('"')
            appendLine()
        }
    }

    private fun renderMarkdown(romMap: RomMap, romDisplayName: String): String = buildString {
        appendLine("# ROM Map Report: $romDisplayName")
        appendLine()
        appendLine("ROM size: ${romMap.romSizeBytes} bytes")
        appendLine()
        appendLine("| Start | End | Length | Type | Confidence | Label |")
        appendLine("|---|---|---|---|---|---|")
        for (r in romMap.regions.sortedBy { it.startOffset }) {
            appendLine(
                "| 0x${r.startOffset.toString(16)} | 0x${r.endOffsetExclusive.toString(16)} | " +
                    "${r.length} | ${r.type.displayName} | ${"%.2f".format(r.confidence)} | ${r.label} |"
            )
        }
    }

    private fun renderHtml(romMap: RomMap, romDisplayName: String): String = buildString {
        appendLine("<!DOCTYPE html><html><head><meta charset='utf-8'>")
        appendLine("<title>ROM Map Report: $romDisplayName</title>")
        appendLine(
            "<style>body{font-family:sans-serif;margin:24px}" +
                "table{border-collapse:collapse;width:100%}" +
                "th,td{border:1px solid #ccc;padding:6px 10px;text-align:left;font-size:14px}" +
                "th{background:#f2f2f2}</style>"
        )
        appendLine("</head><body>")
        appendLine("<h1>ROM Map Report: $romDisplayName</h1>")
        appendLine("<p>ROM size: ${romMap.romSizeBytes} bytes</p>")
        appendLine("<table><tr><th>Start</th><th>End</th><th>Length</th><th>Type</th><th>Confidence</th><th>Label</th></tr>")
        for (r in romMap.regions.sortedBy { it.startOffset }) {
            appendLine(
                "<tr><td>0x${r.startOffset.toString(16)}</td><td>0x${r.endOffsetExclusive.toString(16)}</td>" +
                    "<td>${r.length}</td><td>${r.type.displayName}</td><td>${"%.2f".format(r.confidence)}</td>" +
                    "<td>${r.label}</td></tr>"
            )
        }
        appendLine("</table></body></html>")
    }
}
