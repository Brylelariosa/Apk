package com.romexplorer.gba.core.rom

/**
 * Parses the fixed 0x00-0xC0 GBA cartridge header. All offsets below are the
 * standard, publicly documented GBA ROM header layout.
 */
object RomHeaderParser {

    private const val HEADER_SIZE = 0xC0
    private const val TITLE_OFFSET = 0xA0
    private const val TITLE_LENGTH = 12
    private const val GAME_CODE_OFFSET = 0xAC
    private const val GAME_CODE_LENGTH = 4
    private const val MAKER_CODE_OFFSET = 0xB0
    private const val MAKER_CODE_LENGTH = 2
    private const val FIXED_BYTE_OFFSET = 0xB2
    private const val FIXED_BYTE_EXPECTED = 0x96
    private const val VERSION_OFFSET = 0xBC
    private const val CHECKSUM_OFFSET = 0xBD
    private const val LOGO_OFFSET = 0x04
    private const val LOGO_LENGTH = 156 // 0x04..0x9F inclusive
    private const val ENTRY_POINT_OFFSET = 0x00

    suspend fun parse(rom: RomAccessor): Pair<RomHeader, List<RomWarning>> {
        val warnings = mutableListOf<RomWarning>()

        if (rom.sizeBytes < HEADER_SIZE) {
            warnings += RomWarning.UndersizedRom
        }

        val header = rom.read(0, minOf(HEADER_SIZE, rom.sizeBytes.toInt().coerceAtLeast(0)))

        val entryPointRaw = header.readIntLe(ENTRY_POINT_OFFSET)
        val title = header.readAsciiTrimmed(TITLE_OFFSET, TITLE_LENGTH)
        val gameCode = header.readAsciiTrimmed(GAME_CODE_OFFSET, GAME_CODE_LENGTH)
        val makerCode = header.readAsciiTrimmed(MAKER_CODE_OFFSET, MAKER_CODE_LENGTH)
        val version = header.byteAt(VERSION_OFFSET)

        val fixedByte = header.byteAt(FIXED_BYTE_OFFSET)
        val fixedByteValid = fixedByte == FIXED_BYTE_EXPECTED
        if (!fixedByteValid) warnings += RomWarning.InvalidFixedByte

        val declaredChecksum = header.byteAt(CHECKSUM_OFFSET)
        val computedChecksum = computeHeaderChecksum(header)
        val checksumValid = declaredChecksum == computedChecksum
        if (!checksumValid) warnings += RomWarning.InvalidHeaderChecksum

        val logoBytes = header.slice(LOGO_OFFSET, LOGO_LENGTH)
        val logoPresent = logoBytes.any { it.toInt() != 0 }
        if (!logoPresent) warnings += RomWarning.EmptyLogoRegion

        val bootMode = detectBootMode(entryPointRaw)

        val result = RomHeader(
            title = title,
            gameCode = gameCode,
            makerCode = makerCode,
            version = version,
            entryPointRaw = entryPointRaw,
            fixedByteValid = fixedByteValid,
            headerChecksumDeclared = declaredChecksum,
            headerChecksumComputed = computedChecksum,
            headerChecksumValid = checksumValid,
            logoRegionPresent = logoPresent,
            bootMode = bootMode,
            romSizeBytes = rom.sizeBytes,
        )
        return result to warnings
    }

    /**
     * GBA header checksum: one's-complement-style sum over bytes 0xA0..0xBC
     * (inclusive), documented as `checksum = -(sum(header[0xA0..0xBC]) + 0x19) & 0xFF`.
     */
    private fun computeHeaderChecksum(header: ByteArray): Int {
        if (header.size < 0xBD) return -1
        var sum = 0
        for (i in 0xA0..0xBC) sum += header[i].toInt() and 0xFF
        return (0 - (sum + 0x19)) and 0xFF
    }

    /**
     * GBA has no explicit "boot mode" field; standard cartridges begin with a
     * `B <offset>` ARM branch opcode (0xEA......) at the entry point. Entry
     * points that don't look like a branch are flagged as possible multiboot
     * (EWRAM-loaded) images, which commonly use a different startup sequence.
     */
    private fun detectBootMode(entryPointRaw: Int): BootMode {
        val opcodeTopByte = (entryPointRaw ushr 24) and 0xFF
        return when {
            opcodeTopByte == 0xEA -> BootMode.STANDARD_CARTRIDGE
            entryPointRaw == 0 -> BootMode.UNKNOWN
            else -> BootMode.MULTIBOOT_LIKELY
        }
    }

    private fun ByteArray.byteAt(offset: Int): Int =
        if (offset < size) this[offset].toInt() and 0xFF else -1

    private fun ByteArray.readIntLe(offset: Int): Int {
        if (offset + 4 > size) return 0
        return (this[offset].toInt() and 0xFF) or
            ((this[offset + 1].toInt() and 0xFF) shl 8) or
            ((this[offset + 2].toInt() and 0xFF) shl 16) or
            ((this[offset + 3].toInt() and 0xFF) shl 24)
    }

    private fun ByteArray.slice(offset: Int, length: Int): ByteArray {
        if (offset >= size) return ByteArray(0)
        val end = minOf(offset + length, size)
        return copyOfRange(offset, end)
    }

    private fun ByteArray.readAsciiTrimmed(offset: Int, length: Int): String {
        val raw = slice(offset, length)
        val sb = StringBuilder(raw.size)
        for (b in raw) {
            val c = b.toInt() and 0xFF
            if (c == 0) break
            if (c in 0x20..0x7E) sb.append(c.toChar())
        }
        return sb.toString().trim()
    }
}
