package com.romexplorer.gba.core.hex

import kotlinx.serialization.Serializable

@Serializable
data class HexBookmark(
    val offset: Long,
    val label: String,
)
