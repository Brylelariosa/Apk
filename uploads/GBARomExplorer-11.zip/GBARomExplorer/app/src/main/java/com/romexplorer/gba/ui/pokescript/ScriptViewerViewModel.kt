package com.romexplorer.gba.ui.pokescript

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.pokescript.AssembleResult
import com.romexplorer.gba.core.pokescript.ScriptAssembler
import com.romexplorer.gba.core.pokescript.ScriptDisassembler
import com.romexplorer.gba.core.pokescript.ScriptTextFormatter
import com.romexplorer.gba.core.pokescript.ScriptWriter
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ScriptViewerState {
    data object Loading : ScriptViewerState()
    data class Loaded(val text: String) : ScriptViewerState()
    data class Failed(val message: String) : ScriptViewerState()
}

sealed class SaveState {
    data object Idle : SaveState()
    data object Saving : SaveState()
    data object Saved : SaveState()
    data class Failed(val message: String) : SaveState()
}

/**
 * Backs [ScriptViewerScreen] — real disassembly ([ScriptDisassembler] +
 * [ScriptTextFormatter]) of a script at a real ROM offset, and real
 * reassembly-and-write ([ScriptAssembler] + [ScriptWriter]) back to it.
 */
class ScriptViewerViewModel(private val sessionManager: RomSessionManager) : ViewModel() {
    private val _state = MutableStateFlow<ScriptViewerState>(ScriptViewerState.Loading)
    val state: StateFlow<ScriptViewerState> = _state.asStateFlow()

    private val _saveState = MutableStateFlow<SaveState>(SaveState.Idle)
    val saveState: StateFlow<SaveState> = _saveState.asStateFlow()

    fun load(scriptOffset: Long) {
        val session = sessionManager.session.value
        if (session == null) {
            _state.value = ScriptViewerState.Failed("No ROM open")
            return
        }
        _state.value = ScriptViewerState.Loading
        viewModelScope.launch {
            val disassembled = ScriptDisassembler.disassemble(session.accessor, scriptOffset)
            _state.value = ScriptViewerState.Loaded(ScriptTextFormatter.format(disassembled))
        }
    }

    fun save(text: String, ownerFieldOffset: Long) {
        val session = sessionManager.session.value ?: return
        _saveState.value = SaveState.Saving
        viewModelScope.launch {
            when (val result = ScriptAssembler.assemble(text)) {
                is AssembleResult.Failure -> _saveState.value = SaveState.Failed("Line ${result.lineNumber}: ${result.message}")
                is AssembleResult.Success -> {
                    val wrote = ScriptWriter.write(session.accessor, session.editOverlay, ownerFieldOffset, result.bytes)
                    if (wrote) {
                        sessionManager.persistDraft()
                        _saveState.value = SaveState.Saved
                    } else {
                        _saveState.value = SaveState.Failed("Couldn't find free space for this script (${result.bytes.size} bytes) — try ROM Expansion first")
                    }
                }
            }
        }
    }

    fun resetSaveState() {
        _saveState.value = SaveState.Idle
    }
}
