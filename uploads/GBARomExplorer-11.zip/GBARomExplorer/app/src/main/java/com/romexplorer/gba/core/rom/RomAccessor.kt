package com.romexplorer.gba.core.rom

/**
 * Random-access reader over a GBA ROM. Implementations must never require
 * the whole ROM to be resident in memory — reads are always bounded and
 * positional so multiple callers (hex editor, analyzers, hashing) can read
 * concurrently without racing over a shared file cursor.
 */
interface RomAccessor {
    val sizeBytes: Long

    /** Reads [length] bytes starting at [romOffset]. Returned array may be
     * shorter than [length] if the read reaches end-of-file. */
    suspend fun read(romOffset: Long, length: Int): ByteArray

    /** Low-level positional read into a caller-owned buffer, avoiding a new
     * allocation per call. Returns the number of bytes actually read (may be
     * less than [length] at EOF, or 0 at exact EOF). */
    suspend fun readInto(buffer: ByteArray, romOffset: Long, length: Int): Int

    /** Single-byte convenience read. Returns -1 if [romOffset] is out of range. */
    suspend fun readByte(romOffset: Long): Int

    fun close()
}
