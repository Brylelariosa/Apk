package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Decodes a trainer's 64x64 front battle sprite, indexed by the trainer's
 * own "Trainer Pic" field (0-147 — a shared sprite per trainer *class*,
 * the same way real FireRed works, not one sprite per individual trainer).
 * Sprite and palette each live in their own 148-entry, 8-byte-per-entry
 * table (0x23957C sprites, 0x239A1C palettes); each entry's first 4 bytes
 * are a pointer to LZ77-compressed data, the remaining 4 an internal
 * id/tag this reader doesn't need. 64x64 pixels, 16 colors (4bpp),
 * LZ77-compressed — general trainer/battle-sprite format confirmed by a
 * ROM-hacking documentation wiki, independent of the offset itself.
 *
 * Confidence note: this is the least-corroborated of this app's three
 * sprite/icon readers — the specific table offsets (0x23957C / 0x239A1C)
 * come from a single, if detailed and long-standing, community tutorial,
 * not the double/triple-checked references used elsewhere in this file's
 * neighbors ([SpeciesIconReader], [FireRedTables]). If trainer sprites
 * don't render right, this is the first thing to double-check.
 */
object TrainerSpriteReader {
    private const val SPRITE_TABLE_OFFSET = 0x23957CL
    private const val PALETTE_TABLE_OFFSET = 0x239A1CL
    private const val ENTRY_SIZE = 8
    private const val ENTRY_COUNT = 148
    private const val SPRITE_SIZE_PX = 64
    private const val IMAGE_BYTES = SPRITE_SIZE_PX * SPRITE_SIZE_PX / 2 // 2048
    private const val PALETTE_BYTES = 32

    suspend fun read(rom: RomAccessor, trainerPicIndex: Int): DecodedImage? {
        if (trainerPicIndex !in 0 until ENTRY_COUNT) return null

        val spritePointer = readTablePointer(rom, SPRITE_TABLE_OFFSET, trainerPicIndex) ?: return null
        val palettePointer = readTablePointer(rom, PALETTE_TABLE_OFFSET, trainerPicIndex) ?: return null

        val imageBytes = GbaGraphics.readPossiblyCompressed(rom, spritePointer, IMAGE_BYTES) ?: return null
        val paletteBytes = GbaGraphics.readPossiblyCompressed(rom, palettePointer, PALETTE_BYTES) ?: return null

        val palette = GbaGraphics.decodePalette(paletteBytes)
        val pixels = GbaGraphics.decode4bpp(imageBytes, palette, SPRITE_SIZE_PX, SPRITE_SIZE_PX)
        return DecodedImage(SPRITE_SIZE_PX, SPRITE_SIZE_PX, pixels)
    }

    private suspend fun readTablePointer(rom: RomAccessor, tableOffset: Long, index: Int): Long? {
        val entry = rom.read(tableOffset + index * ENTRY_SIZE.toLong(), 4) // only the leading pointer is needed
        if (entry.size < 4) return null
        return GbaGraphics.readPointer32(entry, 0)
    }
}
