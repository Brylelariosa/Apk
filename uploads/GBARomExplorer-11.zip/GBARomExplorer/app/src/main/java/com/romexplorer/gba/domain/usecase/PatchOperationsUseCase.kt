package com.romexplorer.gba.domain.usecase

import android.content.Context
import android.net.Uri
import com.romexplorer.gba.core.patch.IpsPatch
import com.romexplorer.gba.core.patch.PatchFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

data class PatchApplyOutcome(val outputSizeBytes: Int, val outputSha1: String)

/**
 * Coordinates whole-file patch operations through SAF. Unlike the hex
 * editor and analyzers, patch create/apply/verify inherently need full
 * random access to both files to diff or splice them, so — unlike the
 * rest of the app — these operations do read entire ROMs into memory.
 * That's an explicit, one-shot user action bounded by the app's stated
 * 64MB ROM ceiling, not routine browsing, so it doesn't conflict with the
 * "never load the whole ROM unnecessarily" goal elsewhere in the app.
 *
 * Only IPS is wired up today; [format] is accepted as a parameter so
 * adding UPS/BPS later is a matter of passing a different [PatchFormat]
 * implementation in, with no change to this class.
 */
class PatchOperationsUseCase(
    private val context: Context,
    private val format: PatchFormat = IpsPatch,
) {
    suspend fun createPatch(
        originalUri: Uri,
        modifiedUri: Uri,
        destinationUri: Uri,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val original = readAll(originalUri)
            val modified = readAll(modifiedUri)
            val patchBytes = format.create(original, modified)
            writeAll(destinationUri, patchBytes)
        }
    }

    suspend fun applyPatch(
        originalUri: Uri,
        patchUri: Uri,
        destinationUri: Uri,
    ): Result<PatchApplyOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val original = readAll(originalUri)
            val patch = readAll(patchUri)
            if (!format.isValid(patch)) error("Selected file is not a valid ${format.formatName} patch")
            val result = format.apply(original, patch)
            writeAll(destinationUri, result)
            PatchApplyOutcome(result.size, sha1Of(result))
        }
    }

    /** Applies [patchUri] to [originalUri] in memory (no output written) and
     * reports the resulting size/hash so the user can compare against a
     * known-good checksum before committing to a destination file. */
    suspend fun verifyPatch(
        originalUri: Uri,
        patchUri: Uri,
    ): Result<PatchApplyOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val original = readAll(originalUri)
            val patch = readAll(patchUri)
            if (!format.isValid(patch)) error("Selected file is not a valid ${format.formatName} patch")
            val result = format.apply(original, patch)
            PatchApplyOutcome(result.size, sha1Of(result))
        }
    }

    private fun readAll(uri: Uri): ByteArray =
        context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Unable to read file")

    private fun writeAll(uri: Uri, bytes: ByteArray) {
        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: error("Unable to write file")
    }

    private fun sha1Of(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-1").digest(bytes).joinToString("") { "%02X".format(it) }
}
