package com.romexplorer.gba.ui.analyzer

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.analysis.AnalysisProgress
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.data.repository.RomSessionManager
import com.romexplorer.gba.domain.usecase.ExportReportUseCase
import com.romexplorer.gba.domain.usecase.ReportFormat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AnalyzerViewModel(
    private val sessionManager: RomSessionManager,
    private val exportReportUseCase: ExportReportUseCase,
) : ViewModel() {

    val session = sessionManager.session

    private val _progress = MutableStateFlow<Float?>(null)
    val progress: StateFlow<Float?> = _progress.asStateFlow()

    private val _typeFilter = MutableStateFlow<RegionType?>(null)
    val typeFilter: StateFlow<RegionType?> = _typeFilter.asStateFlow()

    private val _exportStatus = MutableStateFlow<String?>(null)
    val exportStatus: StateFlow<String?> = _exportStatus.asStateFlow()

    init {
        if (sessionManager.session.value?.romMap == null) runAnalysis()
    }

    fun runAnalysis() {
        viewModelScope.launch {
            _progress.value = 0f
            sessionManager.computeRomMap().collect { p ->
                _progress.value = when (p) {
                    is AnalysisProgress.InProgress -> p.fraction
                    is AnalysisProgress.Done -> null
                }
            }
        }
    }

    fun setTypeFilter(type: RegionType?) {
        _typeFilter.value = type
    }

    fun exportReport(format: ReportFormat, destination: Uri) {
        val romMap = sessionManager.session.value?.romMap ?: return
        val name = sessionManager.session.value?.displayName ?: "rom"
        viewModelScope.launch {
            val result = exportReportUseCase.export(romMap, name, format, destination)
            _exportStatus.value = if (result.isSuccess) "Report exported" else "Export failed: ${result.exceptionOrNull()?.message}"
        }
    }

    fun clearExportStatus() {
        _exportStatus.value = null
    }
}
