package com.romexplorer.gba.ui.mapexplorer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.common.IndexedCache
import com.romexplorer.gba.core.common.RomKeyedCache
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.rom.RomAccessor
import com.romexplorer.gba.core.worldmap.MapEventWriter
import com.romexplorer.gba.core.worldmap.MapHeaderData
import com.romexplorer.gba.core.worldmap.MapHeaderReader
import com.romexplorer.gba.core.worldmap.MapId
import com.romexplorer.gba.core.worldmap.MapListEntry
import com.romexplorer.gba.core.worldmap.MapListReader
import com.romexplorer.gba.core.worldmap.MapNameReader
import com.romexplorer.gba.core.worldmap.MetatileRenderer
import com.romexplorer.gba.core.worldmap.ObjectEventData
import com.romexplorer.gba.core.worldmap.WarpEventData
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class MapListState {
    data object Loading : MapListState()
    data class Loaded(val maps: List<MapListEntry>) : MapListState()
    data class Failed(val message: String) : MapListState()
}

data class MapDetailState(
    val entry: MapListEntry,
    val header: MapHeaderData?,
    val image: DecodedImage?,
    val isLoading: Boolean,
)

/**
 * Backs [MapExplorerScreen] — the real map list ([MapListReader]), a
 * selected map's real header/events/rendered tiles ([MapHeaderReader],
 * [MetatileRenderer]), the two event edits this app currently supports
 * ([MapEventWriter]), and each map's real name ([MapNameReader]).
 */
class MapExplorerViewModel(private val sessionManager: RomSessionManager) : ViewModel() {
    private val _mapList = MutableStateFlow<MapListState>(MapListState.Loading)
    val mapList: StateFlow<MapListState> = _mapList.asStateFlow()

    private val _detail = MutableStateFlow<MapDetailState?>(null)
    val detail: StateFlow<MapDetailState?> = _detail.asStateFlow()

    // Scanning the bank table is real work (up to MAX_MAP_GROUPS *
    // MAX_MAPS_PER_GROUP header-plausibility reads) - remember it per ROM
    // rather than rescanning every time the screen is reopened.
    private var listedForAccessor: RomAccessor? = null

    // See MapNameReader's doc: this table's ROM offset is single-sourced,
    // so names are only ever shown for a ROM where the sourcing thread's
    // own worked example (id 0 -> "PALLET TOWN") actually holds.
    private val mapNamesTrusted = RomKeyedCache<Boolean>()
    private val mapNameCache = IndexedCache<String?>()

    fun loadMapListIfNeeded() {
        val session = sessionManager.session.value ?: return
        if (listedForAccessor === session.accessor && _mapList.value is MapListState.Loaded) return
        _mapList.value = MapListState.Loading
        viewModelScope.launch {
            runCatching { MapListReader.listMaps(session.accessor) }
                .onSuccess {
                    listedForAccessor = session.accessor
                    _mapList.value = MapListState.Loaded(it)
                }
                .onFailure { _mapList.value = MapListState.Failed(it.message ?: "Couldn't read this ROM's map list") }
        }
    }

    fun selectMap(entry: MapListEntry) {
        val session = sessionManager.session.value ?: return
        _detail.value = MapDetailState(entry, header = null, image = null, isLoading = true)
        viewModelScope.launch {
            val header = MapHeaderReader.read(session.accessor, entry.id, entry.headerOffset)
            val image = header?.layout?.let { MetatileRenderer.renderMap(session.accessor, it) }
            // Only replace the state if the user hasn't already navigated
            // elsewhere while this map's tiles were still decoding.
            if (_detail.value?.entry == entry) _detail.value = MapDetailState(entry, header, image, isLoading = false)
        }
    }

    fun clearSelection() {
        _detail.value = null
    }

    /**
     * Resolves a map's real location name from its `regionMapSectionId` —
     * called from the UI per visible row/detail screen (e.g. from
     * `produceState`), not eagerly for the whole list, since it costs a map
     * header read plus [MapNameReader]'s own pointer-chase per call. Results
     * are cached per id ([mapNameCache]) so re-viewing a map or scrolling
     * back up through the list is free. Returns null outright, without
     * attempting a read, for any ROM where [MapNameReader]'s one sourcing
     * thread doesn't check out (see its doc) — never a name this app isn't
     * actually confident in.
     */
    suspend fun resolveMapName(regionMapSectionId: Int): String? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        val trusted = mapNamesTrusted.getOrPut(accessor) { MapNameReader.verifyAgainstPalletTown(accessor) }
        if (!trusted) return null
        return mapNameCache.getOrPut(accessor, regionMapSectionId) { MapNameReader.read(accessor, regionMapSectionId) }
    }

    /** Same as [resolveMapName], but for a list row that only has a header offset, not a decoded [MapHeaderData] yet. */
    suspend fun resolveMapName(entry: MapListEntry): String? {
        val accessor = sessionManager.session.value?.accessor ?: return null
        val trusted = mapNamesTrusted.getOrPut(accessor) { MapNameReader.verifyAgainstPalletTown(accessor) }
        if (!trusted) return null
        val header = MapHeaderReader.read(accessor, entry.id, entry.headerOffset) ?: return null
        return mapNameCache.getOrPut(accessor, header.regionMapSectionId) { MapNameReader.read(accessor, header.regionMapSectionId) }
    }

    /**
     * Resolves every map's name at once, for the list's search box —
     * [resolveMapName] only resolves whichever rows happen to be on
     * screen, which can't back a search over maps that aren't. Cheap
     * enough to do eagerly and concurrently for the whole list, unlike a
     * trainer table's per-row party decode ([formatTrainerRow] in
     * [com.romexplorer.gba.ui.pokemontables.PokemonTableViewModel]): each
     * map here costs one small header read plus a pointer chase, not a
     * compressed tile/palette decode. Backed by the same [mapNameCache]
     * [resolveMapName] uses, so this and scrolling the list never do the
     * same read twice.
     */
    suspend fun resolveAllMapNames(entries: List<MapListEntry>): Map<MapId, String?> {
        val accessor = sessionManager.session.value?.accessor ?: return emptyMap()
        val trusted = mapNamesTrusted.getOrPut(accessor) { MapNameReader.verifyAgainstPalletTown(accessor) }
        if (!trusted) return emptyMap()
        return coroutineScope {
            entries.map { entry -> async { entry.id to resolveMapName(entry) } }.awaitAll().toMap()
        }
    }

    fun editObjectEvent(event: ObjectEventData, x: Int, y: Int, elevation: Int, graphicsId: Int, movementType: Int) {
        val session = sessionManager.session.value ?: return
        val current = _detail.value ?: return
        viewModelScope.launch {
            val ok = MapEventWriter.writeObjectEvent(session.accessor, session.editOverlay, event, x, y, elevation, graphicsId, movementType)
            if (ok) {
                sessionManager.persistDraft()
                selectMap(current.entry)
            }
        }
    }

    fun editWarpEvent(
        event: WarpEventData,
        x: Int,
        y: Int,
        elevation: Int,
        warpId: Int,
        destinationMapNum: Int,
        destinationMapGroup: Int,
    ) {
        val session = sessionManager.session.value ?: return
        val current = _detail.value ?: return
        viewModelScope.launch {
            val ok = MapEventWriter.writeWarpEvent(
                session.accessor,
                session.editOverlay,
                event,
                x,
                y,
                elevation,
                warpId,
                destinationMapNum,
                destinationMapGroup,
            )
            if (ok) {
                sessionManager.persistDraft()
                selectMap(current.entry)
            }
        }
    }
}
