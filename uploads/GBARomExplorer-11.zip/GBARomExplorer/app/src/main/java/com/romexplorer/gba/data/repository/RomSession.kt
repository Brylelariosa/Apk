package com.romexplorer.gba.data.repository

import android.net.Uri
import com.romexplorer.gba.core.analysis.model.RomMap
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor
import com.romexplorer.gba.core.rom.RomHashes
import com.romexplorer.gba.core.rom.RomHeader
import com.romexplorer.gba.core.rom.RomWarning
import com.romexplorer.gba.core.rom.SaveType

/**
 * Everything in memory about the ROM the user currently has open. One
 * instance lives for as long as that ROM stays open; every screen
 * (info/hex/map/analyzer/patch) reads from the same instance via
 * [RomSessionManager] rather than each re-opening the file.
 */
data class RomSession(
    val uri: Uri,
    val displayName: String,
    val accessor: RomAccessor,
    val header: RomHeader,
    val warnings: List<RomWarning>,
    /**
     * A cheap content fingerprint (see [com.romexplorer.gba.core.rom.RomHasher.quickFingerprint]),
     * computed once when this session opens and stable for its whole
     * lifetime. Exists specifically so a saved edit draft never gets keyed
     * by [uri] alone: a URI is unique per file-picker *pick*, not per file
     * *content* — replacing a file at the same on-disk location, or a
     * document provider that reuses URIs for a given slot, can hand back
     * the exact same URI for genuinely different bytes, which would
     * otherwise let one ROM's draft silently reapply itself onto another.
     */
    val quickFingerprint: String,
    val hashes: RomHashes? = null,
    val saveType: SaveType? = null,
    val romMap: RomMap? = null,
    val editOverlay: EditOverlay = EditOverlay(),
) {
    /**
     * Best available stable key for cross-session caching (the analysis
     * cache — see [com.romexplorer.gba.core.analysis.RomMapCache]): the
     * full SHA-1 once known, falling back to [quickFingerprint] until
     * hashing finishes. Deliberately *not* used for the edit draft
     * ([com.romexplorer.gba.data.repository.RomSessionManager.persistDraft]) —
     * that always keys by [quickFingerprint] alone, so the key it's saved
     * under can never drift mid-session if hashing happens to finish
     * between one save and the next; see [quickFingerprint]'s doc for why
     * a raw URI isn't safe to key either of these by in the first place.
     */
    val cacheKey: String get() = hashes?.sha1 ?: quickFingerprint
}
