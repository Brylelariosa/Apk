package com.romexplorer.gba.domain.usecase

import android.content.Context
import android.net.Uri
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A size the user can expand the currently-open ROM to. GBA cartridges shipped up to 32MB, so that's the largest size any real GBA (or accurate emulator) will still treat as a valid ROM. */
enum class RomExpansionTarget(val sizeBytes: Long, val label: String) {
    SIZE_16MB(16 * 1024 * 1024L, "16 MB"),
    SIZE_32MB(32 * 1024 * 1024L, "32 MB"),
}

/**
 * Grows the currently-open ROM's file size, padding the new space with
 * 0xFF — the same byte value
 * [com.romexplorer.gba.core.analysis.analyzers.FreeSpaceAnalyzer] already
 * treats as "free" — so every new byte is immediately usable free space
 * for new tables, scripts, maps, or graphics (see
 * [com.romexplorer.gba.core.common.FreeSpaceAllocator]), without a
 * separate "mark this region free" step.
 *
 * This only ever makes the ROM *larger*, never relocates or resizes any
 * existing table — it just gives every allocator in this app more room to
 * work with. The GBA header checksum (see
 * [com.romexplorer.gba.core.rom.RomHeaderParser]) only covers the header
 * region itself (0xA0-0xBC), not the ROM's total length, so it doesn't
 * need recomputing here — a longer ROM with the same header bytes is
 * still a checksum-valid ROM.
 *
 * Rather than growing the currently-open file in place (SAF documents
 * aren't guaranteed to support that, and every other "save" operation in
 * this app already works by writing a *new* file — see
 * [RomSessionManager.exportEditedRom]), this writes the expanded ROM to a
 * new destination and then reopens that file as the current session, so
 * every screen immediately sees the larger size and the newly-free space.
 */
class RomExpansionUseCase(
    private val context: Context,
    private val sessionManager: RomSessionManager,
) {
    private companion object {
        const val FILL_BYTE: Byte = 0xFF.toByte()
    }

    suspend fun expand(destination: Uri, target: RomExpansionTarget): Result<Unit> = withContext(Dispatchers.IO) {
        val current = sessionManager.session.value
            ?: return@withContext Result.failure(IllegalStateException("No ROM open"))
        runCatching {
            val originalSize = current.accessor.sizeBytes
            if (target.sizeBytes <= originalSize) {
                error("This ROM is already ${originalSize / (1024 * 1024)} MB — nothing to expand to ${target.label}")
            }
            val original = current.accessor.read(0, originalSize.toInt())
            val expanded = ByteArray(target.sizeBytes.toInt()) { FILL_BYTE }
            original.copyInto(expanded)
            // Carry over any pending edits, same as an ordinary export —
            // expanding shouldn't silently drop in-progress work.
            val patched = current.editOverlay.applyTo(expanded)

            context.contentResolver.openOutputStream(destination)?.use { it.write(patched) }
                ?: error("Unable to open output stream")
        }.onSuccess {
            sessionManager.open(destination)
        }
    }
}
