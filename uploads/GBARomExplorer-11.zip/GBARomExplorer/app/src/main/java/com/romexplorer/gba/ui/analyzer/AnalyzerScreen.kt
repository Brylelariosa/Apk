@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.analyzer

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.domain.usecase.ReportFormat
import com.romexplorer.gba.ui.common.ProgressRow
import com.romexplorer.gba.ui.theme.regionColor
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerScreen(navController: NavHostController, viewModel: AnalyzerViewModel = koinViewModel()) {
    val session by viewModel.session.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val typeFilter by viewModel.typeFilter.collectAsState()
    val exportStatus by viewModel.exportStatus.collectAsState()
    var showExportMenu by remember { mutableStateOf(false) }
    var pendingFormat by remember { mutableStateOf<ReportFormat?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*"),
    ) { uri ->
        val format = pendingFormat
        if (uri != null && format != null) viewModel.exportReport(format, uri)
        pendingFormat = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ROM Analyzer") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showExportMenu = true }) {
                        Icon(Icons.Filled.Download, contentDescription = "Export report")
                    }
                    DropdownMenu(expanded = showExportMenu, onDismissRequest = { showExportMenu = false }) {
                        ReportFormat.entries.forEach { format ->
                            DropdownMenuItem(
                                text = { Text("Export as ${format.label}") },
                                onClick = {
                                    showExportMenu = false
                                    pendingFormat = format
                                    val session = viewModel.session.value
                                    val baseName = session?.displayName?.replace(" ", "_") ?: "rom"
                                    exportLauncher.launch("${baseName}_report.${format.suggestedExtension}")
                                },
                            )
                        }
                    }
                },
            )
        },
    ) { padding ->
        val current = session
        if (current == null) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("No ROM is currently open.")
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            if (progress != null) {
                ProgressRow("Analyzing ROM…", progress)
            }
            exportStatus?.let { Text(it, modifier = Modifier.padding(vertical = 4.dp)) }

            val romMap = current.romMap
            if (romMap == null) {
                Text("Analysis will start automatically once a ROM is open.")
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    FilterChip(
                        selected = typeFilter == null,
                        onClick = { viewModel.setTypeFilter(null) },
                        label = { Text("All") },
                    )
                    RegionType.entries.forEach { type ->
                        FilterChip(
                            selected = typeFilter == type,
                            onClick = { viewModel.setTypeFilter(if (typeFilter == type) null else type) },
                            label = { Text(type.displayName) },
                        )
                    }
                }

                val visibleRegions = romMap.regions
                    .filter { typeFilter == null || it.type == typeFilter }
                    .sortedByDescending { it.length }

                Text("${visibleRegions.size} region(s)", modifier = Modifier.padding(vertical = 4.dp))

                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(visibleRegions, key = { it.startOffset }) { region ->
                        RegionRow(region)
                    }
                }
            }
        }
    }
}

@Composable
private fun RegionRow(region: RomRegion) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                AssistChip(
                    onClick = {},
                    label = { Text(region.type.displayName) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = regionColor(region.type).copy(alpha = 0.2f),
                    ),
                )
                Text("${(region.confidence * 100).toInt()}% confidence")
            }
            Text(
                "0x${region.startOffset.toString(16)} – 0x${region.endOffsetExclusive.toString(16)} (${region.length} bytes)",
                modifier = Modifier.padding(top = 4.dp),
            )
            Text(region.label, modifier = Modifier.padding(top = 2.dp))
        }
    }
}
