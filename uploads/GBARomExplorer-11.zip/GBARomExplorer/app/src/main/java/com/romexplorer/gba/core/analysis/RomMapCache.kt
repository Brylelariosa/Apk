package com.romexplorer.gba.core.analysis

import com.romexplorer.gba.core.analysis.model.RomMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Caches a completed [RomMap] to disk keyed by the ROM's content hash, so
 * re-opening a ROM (or reopening the app) skips a full re-analysis. Kept
 * deliberately simple — plain JSON files in the app cache dir — since the
 * data is small (a few thousand [com.romexplorer.gba.core.analysis.model.RomRegion] entries at most) and disposable
 * (the cache dir can be cleared by the OS at any time without correctness
 * issues; a cache miss just means a normal re-analysis).
 */
class RomMapCache(private val cacheDir: File) {

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun get(romHashKey: String): RomMap? = withContext(Dispatchers.IO) {
        val file = fileFor(romHashKey)
        if (!file.exists()) return@withContext null
        runCatching { json.decodeFromString(RomMap.serializer(), file.readText()) }.getOrNull()
    }

    suspend fun put(romHashKey: String, map: RomMap) = withContext(Dispatchers.IO) {
        runCatching {
            fileFor(romHashKey).writeText(json.encodeToString(RomMap.serializer(), map))
        }
    }

    private fun fileFor(key: String): File {
        val safeKey = key.filter { it.isLetterOrDigit() }.ifEmpty { "unknown" }
        return File(cacheDir, "rommap_$safeKey.json")
    }
}
