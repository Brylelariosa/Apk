package com.romexplorer.gba.core.pokescript

import com.romexplorer.gba.core.rom.RomAccessor

/** One decoded argument — [rawValue] is the literal little-endian value exactly as stored in the ROM (for [ArgType.POINTER], that's the full `0x08XXXXXX`-style address, the same form XSE-era script tools show and expect — not a bare file offset). */
data class DisassembledArg(val type: ArgType, val rawValue: Long)

data class DisassembledInstruction(
    val offset: Long,
    val opcode: Int,
    val mnemonic: String,
    val args: List<DisassembledArg>,
    val totalBytes: Int,
)

enum class StopReason { TERMINATED, UNKNOWN_OPCODE, OUT_OF_BOUNDS, MAX_INSTRUCTIONS }

data class DisassembledScript(
    val startOffset: Long,
    val instructions: List<DisassembledInstruction>,
    val stopReason: StopReason,
    val stoppedAtOffset: Long,
)

/**
 * Decodes a field script's real bytes into a real, verified instruction
 * sequence — see [ScriptCommandTable]'s class doc for how each opcode's
 * name and argument shape were sourced.
 *
 * This is a *linear* disassembly from [disassemble]'s own entry point: it
 * doesn't follow `goto`/`call` targets to also decode the scripts they
 * jump to, the way a full control-flow-following disassembler would.
 * FireRed's field scripts are a graph, not a line — most real NPC scripts
 * are written as a short main body that `goto`s into shared "std" or
 * reusable sub-scripts — so this intentionally shows exactly one script's
 * own instructions and stops at the first `end`/`return`, rather than
 * silently pulling in and concatenating whatever else happens to be
 * reachable from it. [DisassembledInstruction.args] still show every
 * `goto`/`call` target's address, so following the graph by hand (or
 * re-running [disassemble] at that address) is one tap away in the UI.
 *
 * Stops (see [StopReason]) at a real terminator (`end`/`return`/`endram`/
 * `returnram`), the first opcode this app doesn't have a verified argument
 * shape for (see [ScriptCommandTable]), running off the end of the ROM, or
 * a generous instruction-count safety cap — never by guessing a byte
 * length it isn't sure of. A script that stops earlier than expected is
 * this app being honest about the edge of what it's verified, not a bug.
 */
object ScriptDisassembler {
    private const val MAX_INSTRUCTIONS = 400
    private val TERMINATOR_MNEMONICS = setOf("end", "return", "endram", "returnram")

    suspend fun disassemble(rom: RomAccessor, startOffset: Long): DisassembledScript {
        val instructions = mutableListOf<DisassembledInstruction>()
        var offset = startOffset
        var stopReason = StopReason.MAX_INSTRUCTIONS

        while (instructions.size < MAX_INSTRUCTIONS) {
            if (offset < 0 || offset >= rom.sizeBytes) {
                stopReason = StopReason.OUT_OF_BOUNDS
                break
            }
            val opcode = rom.readByte(offset)
            if (opcode < 0) {
                stopReason = StopReason.OUT_OF_BOUNDS
                break
            }
            val command = ScriptCommandTable.byOpcode[opcode]
            if (command == null) {
                stopReason = StopReason.UNKNOWN_OPCODE
                break
            }

            when (val spec = command.args) {
                is ArgSpec.Fixed -> {
                    val total = 1 + spec.totalBytes
                    if (offset + total > rom.sizeBytes) {
                        stopReason = StopReason.OUT_OF_BOUNDS
                        break
                    }
                    val argBytes = if (spec.totalBytes > 0) rom.read(offset + 1, spec.totalBytes) else ByteArray(0)
                    instructions += DisassembledInstruction(offset, opcode, command.mnemonic, decodeArgs(argBytes, spec.args), total)
                    offset += total
                    if (command.mnemonic in TERMINATOR_MNEMONICS) {
                        stopReason = StopReason.TERMINATED
                        break
                    }
                }
                ArgSpec.TrainerBattle -> {
                    val decoded = decodeTrainerBattle(rom, offset)
                    if (decoded == null) {
                        stopReason = StopReason.UNKNOWN_OPCODE
                        break
                    }
                    instructions += decoded
                    offset += decoded.totalBytes
                }
                ArgSpec.Unknown -> {
                    stopReason = StopReason.UNKNOWN_OPCODE
                    break
                }
            }
        }
        return DisassembledScript(startOffset, instructions, stopReason, offset)
    }

    /**
     * trainerbattle (0x5C)'s own first argument byte ("battle type")
     * decides how many further bytes follow it — a genuinely variable-
     * length command, unlike every [ArgSpec.Fixed] one in
     * [ScriptCommandTable]. Only the two most common shapes are modeled,
     * both consistent with long-standing Gen III scripting community
     * documentation: a standard single battle — type + trainer id + a
     * reserved word + two text pointers (intro, defeat) — and the same
     * shape with a trailing "already beaten" script pointer for battle
     * types that continue into more script afterward. Together these cover
     * the overwhelming majority of real trainerbattle calls. Any other
     * type value stops disassembly here, the same as an [ArgSpec.Unknown]
     * command, rather than guess at a shape this app hasn't verified.
     */
    private suspend fun decodeTrainerBattle(rom: RomAccessor, offset: Long): DisassembledInstruction? {
        if (offset + 2 > rom.sizeBytes) return null
        val battleType = rom.readByte(offset + 1)
        val types = TrainerBattleShapes.argsFor(battleType) ?: return null
        val argBytesLen = types.sumOf { it.byteLength }
        val total = 1 + argBytesLen
        if (offset + total > rom.sizeBytes) return null
        val argBytes = rom.read(offset + 1, argBytesLen)
        return DisassembledInstruction(offset, 0x5c, "trainerbattle", decodeArgs(argBytes, types), total)
    }

    private fun decodeArgs(argBytes: ByteArray, types: List<ArgType>): List<DisassembledArg> {
        val args = mutableListOf<DisassembledArg>()
        var cursor = 0
        for (type in types) {
            args += DisassembledArg(type, readLittleEndian(argBytes, cursor, type.byteLength))
            cursor += type.byteLength
        }
        return args
    }

    private fun readLittleEndian(bytes: ByteArray, offset: Int, length: Int): Long {
        var value = 0L
        for (i in 0 until length) value = value or ((bytes[offset + i].toLong() and 0xFF) shl (8 * i))
        return value
    }
}
