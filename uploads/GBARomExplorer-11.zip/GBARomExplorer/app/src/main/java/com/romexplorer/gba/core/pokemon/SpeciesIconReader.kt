package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Decodes a species' 32x32 icon (the small sprite used in the party list,
 * PC boxes, etc.) — three tables, all in the same neighborhood of the ROM:
 *   - 0x3D37A0: one 4-byte pointer per species to its icon graphic. Each
 *     graphic is two uncompressed 512-byte frames (a two-frame "bounce"
 *     animation); only the first frame is read here.
 *   - 0x3D3E80: one byte per species, selecting which of 3 shared icon
 *     palettes it uses (there are only 3 for the whole Pokédex — a GBA
 *     object-palette hardware limit, not a FireRed-specific choice).
 *   - 0x3D3740: the 3 palettes themselves, 32 bytes each, raw/uncompressed.
 *
 * All three offsets are independently corroborated by 3 separate community
 * ROM-offset references, and 0x3D3740 + (3 x 32 bytes) = 0x3D37A0 exactly —
 * the palette table ends precisely where the pointer table begins, which
 * is a strong internal consistency check that these two offsets, at least,
 * are correctly placed relative to each other. Of the three sprite/icon
 * readers in this package, this is the best-corroborated.
 */
object SpeciesIconReader {
    private const val POINTER_TABLE_OFFSET = 0x3D37A0L
    private const val PALETTE_INDEX_TABLE_OFFSET = 0x3D3E80L
    private const val PALETTES_OFFSET = 0x3D3740L
    private const val ICON_SIZE_PX = 32
    private const val FRAME_BYTES = ICON_SIZE_PX * ICON_SIZE_PX / 2 // 512, uncompressed
    private const val PALETTE_BYTES = 32
    private const val PALETTE_COUNT = 3

    suspend fun read(rom: RomAccessor, speciesIndex: Int): DecodedImage? {
        if (speciesIndex < 0) return null

        val pointerBytes = rom.read(POINTER_TABLE_OFFSET + speciesIndex * 4L, 4)
        if (pointerBytes.size < 4) return null
        val iconOffset = GbaGraphics.readPointer32(pointerBytes, 0) ?: return null

        val frame = rom.read(iconOffset, FRAME_BYTES)
        if (frame.size < FRAME_BYTES) return null

        val paletteIndexByte = rom.readByte(PALETTE_INDEX_TABLE_OFFSET + speciesIndex)
        val paletteIndex = paletteIndexByte.takeIf { it in 0 until PALETTE_COUNT } ?: 0
        val paletteBytes = rom.read(PALETTES_OFFSET + paletteIndex * PALETTE_BYTES.toLong(), PALETTE_BYTES)
        if (paletteBytes.size < PALETTE_BYTES) return null

        val palette = GbaGraphics.decodePalette(paletteBytes)
        val pixels = GbaGraphics.decode4bpp(frame, palette, ICON_SIZE_PX, ICON_SIZE_PX)
        return DecodedImage(ICON_SIZE_PX, ICON_SIZE_PX, pixels)
    }
}
