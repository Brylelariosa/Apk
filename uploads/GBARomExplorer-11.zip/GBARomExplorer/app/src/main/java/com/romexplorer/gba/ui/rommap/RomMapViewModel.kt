package com.romexplorer.gba.ui.rommap

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.analysis.AnalysisProgress
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RomMapViewModel(
    private val sessionManager: RomSessionManager,
) : ViewModel() {

    val session = sessionManager.session

    private val _progress = MutableStateFlow<Float?>(null)
    val progress: StateFlow<Float?> = _progress.asStateFlow()

    init {
        val existing = sessionManager.session.value?.romMap
        if (existing == null) {
            runAnalysis()
        }
    }

    fun runAnalysis() {
        viewModelScope.launch {
            _progress.value = 0f
            sessionManager.computeRomMap().collect { p ->
                _progress.value = when (p) {
                    is AnalysisProgress.InProgress -> p.fraction
                    is AnalysisProgress.Done -> null
                }
            }
        }
    }
}
