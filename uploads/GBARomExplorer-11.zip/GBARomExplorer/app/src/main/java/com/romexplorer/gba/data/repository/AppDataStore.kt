package com.romexplorer.gba.data.repository

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

/** Single shared DataStore instance for all small, JSON-encoded app preferences
 * (recent ROMs, favorites, per-ROM bookmarks). Kept as one file since each
 * value is tiny — separate DataStore files per concern would be overkill. */
val Context.appDataStore by preferencesDataStore(name = "gba_rom_explorer_prefs")
