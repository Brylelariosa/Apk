package com.romexplorer.gba.core.rom

/** GBA cartridge header, laid out per the fixed 0x00-0xC0 header region. */
data class RomHeader(
    val title: String,
    val gameCode: String,
    val makerCode: String,
    val version: Int,
    val entryPointRaw: Int,
    val fixedByteValid: Boolean,
    val headerChecksumDeclared: Int,
    val headerChecksumComputed: Int,
    val headerChecksumValid: Boolean,
    val logoRegionPresent: Boolean,
    val bootMode: BootMode,
    val romSizeBytes: Long,
)

enum class BootMode {
    STANDARD_CARTRIDGE,
    MULTIBOOT_LIKELY,
    UNKNOWN,
}

/** Non-fatal issues found while validating a [RomHeader], surfaced to the user. */
sealed class RomWarning(val message: String) {
    data object InvalidFixedByte : RomWarning(
        "Fixed header byte at 0xB2 is not 0x96 — this ROM may be corrupt or non-standard."
    )
    data object InvalidHeaderChecksum : RomWarning(
        "Header checksum does not match the computed value — header bytes may be corrupted or hand-edited."
    )
    data object EmptyLogoRegion : RomWarning(
        "Nintendo logo region (0x04-0x9F) is blank — likely a homebrew ROM without a boot logo, or a stripped header."
    )
    data object UndersizedRom : RomWarning(
        "File is smaller than the standard 192-byte GBA header and cannot be fully parsed."
    )
    data class Custom(val text: String) : RomWarning(text)
}
