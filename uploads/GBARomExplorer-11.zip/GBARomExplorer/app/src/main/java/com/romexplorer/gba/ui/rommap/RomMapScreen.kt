@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.rommap

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.ui.common.ProgressRow
import com.romexplorer.gba.ui.navigation.Screen
import com.romexplorer.gba.ui.theme.regionColor
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RomMapScreen(navController: NavHostController, viewModel: RomMapViewModel = koinViewModel()) {
    val session by viewModel.session.collectAsState()
    val progress by viewModel.progress.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ROM Map") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        val current = session
        if (current == null) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("No ROM is currently open.")
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {
            if (progress != null) {
                ProgressRow("Analyzing ROM…", progress)
            }

            val romMap = current.romMap
            if (romMap == null) {
                Text("Run the analyzer to build a ROM map.")
            } else {
                Text(
                    "Pinch to zoom, drag to pan, tap a region to jump to it in the Hex Editor.",
                    modifier = Modifier.padding(vertical = 6.dp),
                )
                RomMapCanvas(
                    regions = romMap.regions,
                    totalSize = romMap.romSizeBytes,
                    onTapOffset = { offset ->
                        navController.navigate(Screen.HexEditor.route)
                        // The hex editor opens at its default page; jumping directly to the
                        // tapped offset would require passing nav args, which is a natural
                        // next iteration once the hex editor route accepts a start offset.
                    },
                    modifier = Modifier.fillMaxWidth().weight(1f),
                )
                RomMapLegend()
            }
        }
    }
}

@Composable
private fun RomMapCanvas(
    regions: List<RomRegion>,
    totalSize: Long,
    onTapOffset: (Long) -> Unit,
    modifier: Modifier = Modifier,
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var topOffset by remember { mutableLongStateOf(0L) }
    var canvasHeightPx by remember { mutableFloatStateOf(1f) }

    val minVisibleBytes = 512L
    val maxZoom = (totalSize.toFloat() / minVisibleBytes).coerceAtLeast(1f)

    Canvas(
        modifier = modifier
            .onSizeChanged { canvasHeightPx = it.height.toFloat() }
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoomChange, _ ->
                    val newZoom = (zoom * zoomChange).coerceIn(1f, maxZoom)
                    val visibleBytes = (totalSize / newZoom).toLong().coerceAtLeast(1L)
                    val bytesPerPixel = visibleBytes.toFloat() / canvasHeightPx
                    val newTop = (topOffset - (pan.y * bytesPerPixel).toLong())
                        .coerceIn(0L, (totalSize - visibleBytes).coerceAtLeast(0L))
                    zoom = newZoom
                    topOffset = newTop
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { tapPos ->
                    val visibleBytes = (totalSize / zoom).toLong().coerceAtLeast(1L)
                    val bytesPerPixel = visibleBytes.toFloat() / canvasHeightPx
                    val tappedOffset = topOffset + (tapPos.y * bytesPerPixel).toLong()
                    onTapOffset(tappedOffset.coerceIn(0L, totalSize - 1))
                }
            },
    ) {
        val visibleBytes = (totalSize / zoom).toLong().coerceAtLeast(1L)
        val visibleEnd = (topOffset + visibleBytes).coerceAtMost(totalSize)
        val pxPerByte = size.height / visibleBytes.toFloat()

        for (region in regions) {
            if (region.endOffsetExclusive <= topOffset || region.startOffset >= visibleEnd) continue
            val clampedStart = maxOf(region.startOffset, topOffset)
            val clampedEnd = minOf(region.endOffsetExclusive, visibleEnd)
            val yStart = (clampedStart - topOffset) * pxPerByte
            val yEnd = (clampedEnd - topOffset) * pxPerByte
            drawRect(
                color = regionColor(region.type),
                topLeft = Offset(0f, yStart),
                size = Size(size.width, (yEnd - yStart).coerceAtLeast(1f)),
            )
        }
    }
}

@Composable
private fun RomMapLegend() {
    val types = RegionType.entries
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        types.chunked(3).forEach { rowTypes ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                rowTypes.forEach { type ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .size(12.dp)
                                .background(regionColor(type)),
                        )
                        Text(type.displayName, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
