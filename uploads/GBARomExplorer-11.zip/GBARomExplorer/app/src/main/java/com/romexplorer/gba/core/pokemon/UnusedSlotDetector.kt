package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.TableRow

/**
 * Finds rows in FireRed's fixed-size species/item/move tables that are
 * genuinely unused — reserved placeholder slots the vanilla game ships with
 * blank, not real Pokémon/items/moves that merely have unusual data. This is
 * what makes "add a new Pokémon/item" possible at all without expanding the
 * ROM (relocating a table and repointing every reference to it is a much
 * bigger, riskier operation this app doesn't attempt): claiming one of these
 * slots only ever changes bytes already inside the table's existing,
 * verified byte range (see [FireRedTables]), so it can never corrupt
 * anything adjacent.
 *
 * The heuristic is deliberately conservative — blank name *and* all-zero
 * stat bytes — so a real entry with an edge-case value (e.g. 0 catch rate)
 * is never mistaken for a free slot.
 */
object UnusedSlotDetector {

    fun isUnusedItemSlot(row: TableRow): Boolean {
        val name = row.values["Name"] as? String
        val price = row.values["Price"] as? Long ?: 0L
        val holdEffect = row.values["Hold Effect"] as? Long ?: 0L
        val pocket = row.values["Pocket"] as? Long ?: 0L
        return name.isNullOrBlank() && price == 0L && holdEffect == 0L && pocket == 0L
    }

    fun isUnusedSpeciesSlot(row: TableRow, speciesName: String?): Boolean {
        val hp = row.values["Base HP"] as? Long ?: 0L
        val atk = row.values["Base Attack"] as? Long ?: 0L
        val def = row.values["Base Defense"] as? Long ?: 0L
        val speed = row.values["Base Speed"] as? Long ?: 0L
        return speciesName.isNullOrBlank() && hp == 0L && atk == 0L && def == 0L && speed == 0L
    }

    fun isUnusedMoveSlot(row: TableRow, moveName: String?): Boolean {
        val power = row.values["Base Power"] as? Long ?: 0L
        val accuracy = row.values["Accuracy"] as? Long ?: 0L
        val pp = row.values["PP"] as? Long ?: 0L
        return moveName.isNullOrBlank() && power == 0L && accuracy == 0L && pp == 0L
    }
}
