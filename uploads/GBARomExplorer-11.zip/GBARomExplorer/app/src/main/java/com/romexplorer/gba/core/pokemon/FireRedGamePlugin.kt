package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.analysis.GameAnalyzerPlugin
import com.romexplorer.gba.core.analysis.RegionAnalyzer

/**
 * First [GameAnalyzerPlugin] implementation. Matches on the internal game
 * code alone ("BPRE" covers both US and EU FireRed); the revision-specific
 * check (are these known offsets actually right for *this* ROM) happens
 * inside [FireRedTableAnalyzer] itself, since [supports] doesn't have
 * access to the ROM to check the header version byte.
 */
class FireRedGamePlugin : GameAnalyzerPlugin {
    override val pluginId: String = "pokemon_firered"

    override fun supports(gameCode: String): Boolean = gameCode == FireRedTables.EXPECTED_GAME_CODE

    override fun analyzersFor(gameCode: String): List<RegionAnalyzer> = listOf(FireRedTableAnalyzer())
}
