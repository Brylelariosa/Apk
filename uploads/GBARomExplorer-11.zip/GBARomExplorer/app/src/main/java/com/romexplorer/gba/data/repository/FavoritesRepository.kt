package com.romexplorer.gba.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/** Persists which ROM URIs (as strings) the user has starred as favorites. */
class FavoritesRepository(private val context: Context) {

    private val key = stringSetPreferencesKey("favorite_rom_uris")

    val favorites: Flow<Set<String>> = context.appDataStore.data.map { prefs ->
        prefs[key] ?: emptySet()
    }

    suspend fun toggle(uri: String) {
        context.appDataStore.edit { prefs ->
            val current = prefs[key] ?: emptySet()
            prefs[key] = if (uri in current) current - uri else current + uri
        }
    }

    suspend fun isFavorite(uri: String): Boolean = favorites.first().contains(uri)
}
