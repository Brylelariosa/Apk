package com.romexplorer.gba.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

@Serializable
private data class OverlayEntry(val offset: Long, val value: Int)

/**
 * Persists the same sparse offset -> byte overlay the hex editor and
 * Pokémon table screens edit (see [com.romexplorer.gba.core.hex.EditOverlay])
 * so in-progress edits survive backgrounding, navigating back to Home and
 * reopening the same ROM, or Android killing the process outright — none of
 * which used to be safe, since the overlay previously only ever lived in
 * memory and there was no autosave. This is a *draft*, separate from an
 * actual exported ROM file: since exporting (see
 * [RomSessionManager.exportEditedRom]) writes a separate new file rather
 * than modifying the ROM the user has open, the draft deliberately stays
 * in place after an export too — the open ROM and its pending edits still
 * differ from the original file on disk either way. It's only cleared by
 * an explicit discard (see [RomSessionManager.discardDraft]).
 *
 * Keyed by the ROM's content URI — the same fallback identity
 * [RomSession.cacheKey] itself uses before a SHA-1 hash is available — since
 * a draft needs to exist from the moment of the very first edit, before
 * hashing (a separate, opt-in, streamed step) has necessarily run.
 */
class EditDraftRepository(private val context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val listSerializer = ListSerializer(OverlayEntry.serializer())

    private fun keyFor(romKey: String) = stringPreferencesKey("edit_draft_$romKey")

    suspend fun draftFor(romKey: String): Map<Long, Int> {
        val raw = context.appDataStore.data.first()[keyFor(romKey)] ?: return emptyMap()
        return decode(raw).associate { it.offset to it.value }
    }

    suspend fun saveDraft(romKey: String, overlay: Map<Long, Int>) {
        context.appDataStore.edit { prefs ->
            if (overlay.isEmpty()) {
                prefs.remove(keyFor(romKey))
            } else {
                val encoded = overlay.map { (offset, value) -> OverlayEntry(offset, value) }
                prefs[keyFor(romKey)] = json.encodeToString(listSerializer, encoded)
            }
        }
    }

    suspend fun clearDraft(romKey: String) {
        context.appDataStore.edit { prefs -> prefs.remove(keyFor(romKey)) }
    }

    private fun decode(raw: String): List<OverlayEntry> =
        runCatching { json.decodeFromString(listSerializer, raw) }.getOrDefault(emptyList())
}
