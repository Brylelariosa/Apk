package com.romexplorer.gba.core.worldmap

import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.compression.Lz77FormatException
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Assembles a map's actual visible tile graphics into one bitmap — the
 * same GBA background-layer tile/palette format
 * [com.romexplorer.gba.core.graphics.GbaGraphics] already decodes for
 * sprites/icons, composed here per [FireRedMapTables]'s documented
 * metatile and map-grid formats (see that class's doc for sourcing).
 *
 * A metatile combines up to 8 individual 8x8 tiles — two stacked 2x2
 * layers — into one 16x16 unit; a map's own grid is a 2D array of metatile
 * references, each also carrying its own palette and h/v-flip bits, again
 * matching ordinary GBA tilemap-entry encoding. Primary and secondary
 * tilesets share one combined addressing space (tile/metatile index
 * 0-511 = this map's primary tileset, 512-1023 = its secondary tileset),
 * which is why both are read and passed in together rather than one at a
 * time — see [FireRedMapTables]'s class doc.
 *
 * Palette bank convention (metatile palette numbers 0-5 from the primary
 * tileset's own palette data, 6-15 from the secondary's, each indexed from
 * its own 0): the same split every actively-maintained Gen III map editor
 * uses, and — unlike the pointer offsets elsewhere in this app — a purely
 * cosmetic one: getting it wrong would show wrong colors, not corrupt
 * anything, and doesn't block the geometry (metatile/tile layout, flips)
 * this renderer's correctness actually depends on.
 */
object MetatileRenderer {
    private const val MAX_RENDER_TILES = 200 * 200 // safety cap on total metatiles rendered
    private const val PRIMARY_PALETTE_COUNT = 6
    private val TILE_PX = FireRedMapTables.TILE_PIXEL_SIZE
    private val METATILE_PX = FireRedMapTables.METATILE_PIXEL_SIZE
    private const val TILES_PER_METATILE = 8 // 2 layers x 2x2
    private val METATILE_BYTES = TILES_PER_METATILE * 2

    suspend fun renderMap(rom: RomAccessor, layout: MapLayoutData): DecodedImage? {
        if (layout.width <= 0 || layout.height <= 0 || layout.width.toLong() * layout.height > MAX_RENDER_TILES) return null
        val primary = layout.primaryTileset ?: return null
        val secondary = layout.secondaryTileset

        val primaryTileBytes = readTileGraphics(rom, primary)
        val secondaryTileBytes = secondary?.let { readTileGraphics(rom, it) }
        val primaryPalettes = readPalettes(rom, primary.palettesPointer)
        val secondaryPalettes = secondary?.let { readPalettes(rom, it.palettesPointer) } ?: emptyList()

        val metatileCount = layout.width * layout.height
        val gridBytes = rom.read(layout.mapDataPointer, metatileCount * 2)
        if (gridBytes.size < metatileCount * 2) return null

        // Every distinct metatile actually used on this map, decoded once
        // and cached — a route reusing the same "tall grass" metatile
        // hundreds of times shouldn't decode it hundreds of times.
        val metatilePixelCache = HashMap<Int, IntArray?>()

        val outWidthPx = layout.width * METATILE_PX
        val outHeightPx = layout.height * METATILE_PX
        val out = IntArray(outWidthPx * outHeightPx)

        for (row in 0 until layout.height) {
            for (col in 0 until layout.width) {
                val cellIndex = row * layout.width + col
                val cell = readU16(gridBytes, cellIndex * 2)
                val metatileId = cell and 0x03FF
                val pixels = metatilePixelCache.getOrPut(metatileId) {
                    decodeMetatile(
                        rom, metatileId, primary, secondary,
                        primaryTileBytes, secondaryTileBytes, primaryPalettes, secondaryPalettes,
                    )
                } ?: continue
                blitMetatile(out, outWidthPx, pixels, col * METATILE_PX, row * METATILE_PX)
            }
        }
        return DecodedImage(outWidthPx, outHeightPx, out)
    }

    /**
     * Reads a tileset's raw 4bpp tile graphics. Unlike
     * [GbaGraphics.readPossiblyCompressed], this doesn't require an exact
     * expected decompressed size up front — a tileset's real tile count
     * (and so its true decompressed byte length) varies and isn't stored
     * anywhere separate from the compressed stream's own embedded size, so
     * this trusts that embedded size instead of forcing a fixed one.
     * Always returns a full [FireRedMapTables.TILES_PER_TILESET_SPACE]-tile
     * buffer, padded with zero bytes (which decode as fully transparent)
     * so a tile index past the end of a shorter-than-full tileset renders
     * as blank instead of throwing.
     */
    private suspend fun readTileGraphics(rom: RomAccessor, tileset: TilesetData): ByteArray {
        val maxSize = FireRedMapTables.TILES_PER_TILESET_SPACE * FireRedMapTables.TILE_BYTES_4BPP
        val raw: ByteArray = if (tileset.isCompressed) {
            val firstByte = rom.readByte(tileset.tilesPointer)
            if (firstByte < 0 || !Lz77Codec.isLikelyHeader(firstByte)) {
                ByteArray(0)
            } else {
                try {
                    // Generous compressed-read window — LZ77 data is
                    // usually smaller than what it decompresses to.
                    val windowLen = minOf((maxSize * 2 + 32).toLong(), rom.sizeBytes - tileset.tilesPointer).toInt()
                    Lz77Codec.decompress(rom.read(tileset.tilesPointer, windowLen))
                } catch (e: Lz77FormatException) {
                    ByteArray(0)
                }
            }
        } else {
            val windowLen = minOf(maxSize.toLong(), rom.sizeBytes - tileset.tilesPointer).coerceAtLeast(0).toInt()
            rom.read(tileset.tilesPointer, windowLen)
        }
        // ByteArray.copyOf both pads (with zero, which decodes as fully
        // transparent) and truncates to the fixed per-tileset tile budget,
        // whichever this tileset's real data needs.
        return raw.copyOf(maxSize)
    }

    private suspend fun readPalettes(rom: RomAccessor, palettesPointer: Long): List<IntArray> {
        if (palettesPointer <= 0) return emptyList()
        val totalBytes = FireRedMapTables.PALETTES_PER_TILESET * FireRedMapTables.PALETTE_BYTES
        val available = (rom.sizeBytes - palettesPointer).coerceAtLeast(0)
        val readable = minOf(totalBytes.toLong(), available).toInt()
        if (readable <= 0) return emptyList()
        val bytes = rom.read(palettesPointer, readable)
        val count = bytes.size / FireRedMapTables.PALETTE_BYTES
        return (0 until count).map { i -> GbaGraphics.decodePalette(bytes, i * FireRedMapTables.PALETTE_BYTES) }
    }

    private fun paletteFor(paletteNum: Int, primaryPalettes: List<IntArray>, secondaryPalettes: List<IntArray>): IntArray {
        val fromList = if (paletteNum < PRIMARY_PALETTE_COUNT) primaryPalettes else secondaryPalettes
        val localIndex = if (paletteNum < PRIMARY_PALETTE_COUNT) paletteNum else paletteNum - PRIMARY_PALETTE_COUNT
        // Neutral grayscale fallback (rather than crashing/index-erroring)
        // if this map's palette data couldn't be read — lets the map's
        // *shapes* still render even when its colors can't.
        return fromList.getOrNull(localIndex) ?: IntArray(16) { i -> if (i == 0) 0 else (0xFF000000.toInt() or (i * 0x101010)) }
    }

    private suspend fun decodeMetatile(
        rom: RomAccessor,
        metatileId: Int,
        primary: TilesetData,
        secondary: TilesetData?,
        primaryTileBytes: ByteArray,
        secondaryTileBytes: ByteArray?,
        primaryPalettes: List<IntArray>,
        secondaryPalettes: List<IntArray>,
    ): IntArray? {
        val tileSpace = FireRedMapTables.TILES_PER_TILESET_SPACE
        val fromSecondary = metatileId >= tileSpace
        val tileset = if (fromSecondary) secondary else primary
        val localMetatileId = if (fromSecondary) metatileId - tileSpace else metatileId
        if (tileset == null) return null

        val entryOffset = tileset.metatilesPointer + localMetatileId.toLong() * METATILE_BYTES
        if (entryOffset < 0 || entryOffset + METATILE_BYTES > rom.sizeBytes) return null
        val entry = rom.read(entryOffset, METATILE_BYTES)
        if (entry.size < METATILE_BYTES) return null

        val out = IntArray(METATILE_PX * METATILE_PX)
        for (subTile in 0 until TILES_PER_METATILE) {
            val cell = readU16(entry, subTile * 2)
            val tileIndex = cell and 0x03FF
            val hFlip = (cell shr 10) and 1 == 1
            val vFlip = (cell shr 11) and 1 == 1
            val paletteNum = (cell shr 12) and 0xF

            val fromSecondaryTile = tileIndex >= tileSpace
            val tileBytes = if (fromSecondaryTile) secondaryTileBytes else primaryTileBytes
            val localTileIndex = if (fromSecondaryTile) tileIndex - tileSpace else tileIndex
            val palette = paletteFor(paletteNum, primaryPalettes, secondaryPalettes)
            val tilePixels = if (tileBytes != null) decodeSingleTile(tileBytes, localTileIndex, palette, hFlip, vFlip) else IntArray(TILE_PX * TILE_PX)

            // 8 sub-tiles arranged as two stacked 2x2 blocks: bottom layer
            // (indices 0-3) covers the metatile first, top layer (4-7) is
            // drawn over it — the standard two-layer Gen III metatile
            // composite. Non-transparent top-layer pixels win.
            val layer = subTile / 4
            val posInLayer = subTile % 4
            val tileCol = posInLayer % 2
            val tileRow = posInLayer / 2
            blitTile(out, METATILE_PX, tilePixels, tileCol * TILE_PX, tileRow * TILE_PX, forceOpaque = layer == 0)
        }
        return out
    }

    /** Decodes one 8x8 4bpp tile with its own h/v flip — [GbaGraphics.decode4bpp] decodes a flip-free multi-tile grid, which doesn't fit a metatile's per-sub-tile flip bits. */
    private fun decodeSingleTile(tileBytes: ByteArray, tileIndex: Int, palette: IntArray, hFlip: Boolean, vFlip: Boolean): IntArray {
        val out = IntArray(TILE_PX * TILE_PX)
        val base = tileIndex * FireRedMapTables.TILE_BYTES_4BPP
        if (base < 0 || base + FireRedMapTables.TILE_BYTES_4BPP > tileBytes.size) return out
        for (row in 0 until TILE_PX) {
            for (byteCol in 0 until TILE_PX / 2) {
                val b = tileBytes[base + row * (TILE_PX / 2) + byteCol].toInt() and 0xFF
                val left = palette.getOrElse(b and 0x0F) { 0 }
                val right = palette.getOrElse((b shr 4) and 0x0F) { 0 }
                val px0 = byteCol * 2
                val px1 = px0 + 1
                val outRow = if (vFlip) TILE_PX - 1 - row else row
                val outCol0 = if (hFlip) TILE_PX - 1 - px0 else px0
                val outCol1 = if (hFlip) TILE_PX - 1 - px1 else px1
                out[outRow * TILE_PX + outCol0] = left
                out[outRow * TILE_PX + outCol1] = right
            }
        }
        return out
    }

    private fun blitTile(dest: IntArray, destWidth: Int, src: IntArray, dx: Int, dy: Int, forceOpaque: Boolean) {
        for (y in 0 until TILE_PX) {
            for (x in 0 until TILE_PX) {
                var color = src[y * TILE_PX + x]
                val alpha = (color ushr 24) and 0xFF
                if (alpha == 0 && !forceOpaque) continue // top layer's transparent pixels let the bottom layer show through
                // The bottom metatile layer has nothing further behind it
                // to show through to — render its own palette index 0 as
                // opaque instead of GbaGraphics' sprite-style transparency
                // key (index 0 = see-through), which would otherwise punch
                // holes in ordinary ground/path tiles.
                if (forceOpaque) color = color or 0xFF000000.toInt()
                val destIndex = (dy + y) * destWidth + (dx + x)
                if (destIndex in dest.indices) dest[destIndex] = color
            }
        }
    }

    private fun blitMetatile(dest: IntArray, destWidth: Int, src: IntArray, dx: Int, dy: Int) {
        for (y in 0 until METATILE_PX) {
            for (x in 0 until METATILE_PX) {
                val destIndex = (dy + y) * destWidth + (dx + x)
                if (destIndex in dest.indices) dest[destIndex] = src[y * METATILE_PX + x]
            }
        }
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)
}
