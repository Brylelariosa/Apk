package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Writes into a flat, fixed-length name array — the format [NameTableLookup]
 * reads (species names, move names). Species and move data have no name
 * field of their own (see [FireRedTables]'s class doc), so naming one of
 * these — most importantly, naming a newly-claimed unused slot (see
 * [UnusedSlotDetector]) — can't go through [PokemonTableWriter], which only
 * knows about a schema's own embedded fields.
 *
 * Same overlay-based, non-destructive write as everywhere else in this
 * package: nothing here touches the ROM file directly.
 */
object NameTableWriter {
    suspend fun write(
        rom: RomAccessor,
        overlay: EditOverlay,
        tableOffset: Long,
        entryLength: Int,
        index: Int,
        newName: String,
    ): FieldWriteResult {
        val entryStart = tableOffset + index.toLong() * entryLength
        if (entryStart < 0 || entryStart + entryLength > rom.sizeBytes) return FieldWriteResult.OutOfBounds

        val encoded = PokemonTextCodec.encode(newName, entryLength)
        for (i in 0 until entryLength) {
            val byteOffset = entryStart + i
            val originalByte = rom.readByte(byteOffset)
            if (originalByte < 0) return FieldWriteResult.OutOfBounds
            overlay.setByte(byteOffset, encoded[i].toInt() and 0xFF, originalByte)
        }
        return FieldWriteResult.Success
    }
}
