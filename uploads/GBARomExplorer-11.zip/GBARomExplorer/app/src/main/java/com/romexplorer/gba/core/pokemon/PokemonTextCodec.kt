package com.romexplorer.gba.core.pokemon

/**
 * Decodes the Generation III "Western" proprietary character encoding used
 * by Pokémon FireRed/LeafGreen/Emerald/Ruby/Sapphire for item names, trainer
 * names, and other in-ROM strings — verified against the character table at
 * https://bulbapedia.bulbagarden.net/wiki/Character_encoding_(Generation_III).
 *
 * This intentionally covers only the codepoints needed to render standard
 * English names correctly (letters, digits, space, and common punctuation):
 * enough for every FireRed item/trainer name. Regional-accented characters,
 * control codes (0xFC+), and the Japanese character set are out of scope —
 * unmapped bytes render as a hex placeholder rather than silently guessing.
 */
object PokemonTextCodec {
    private const val TERMINATOR = 0xFF
    private const val SPACE = 0x00

    private val table: Map<Int, Char> = buildMap {
        put(SPACE, ' ')
        // 0xA1..0xAA = '0'..'9'
        for (i in 0..9) put(0xA1 + i, ('0' + i))
        put(0xAB, '!')
        put(0xAC, '?')
        put(0xAD, '.')
        put(0xAE, '-')
        put(0xB0, '…')
        put(0xB1, '"')
        put(0xB2, '"')
        put(0xB3, '\'')
        put(0xB4, '\'')
        put(0xB5, '♂')
        put(0xB6, '♀')
        put(0xB7, '$')
        put(0xB8, ',')
        put(0xB9, '×')
        put(0xBA, '/')
        // 0xBB..0xD4 = 'A'..'Z'
        for (i in 0..25) put(0xBB + i, ('A' + i))
        // 0xD5..0xEE = 'a'..'z'
        for (i in 0..25) put(0xD5 + i, ('a' + i))
        put(0xF0, ':')
    }

    /** Reverse of [table], for [encode]. A few characters (curly quotes, both
     * apostrophe variants) map from two different bytes when decoding; built
     * with "first entry wins" so encoding is deterministic — always the lower,
     * canonical byte for those. */
    private val reverseTable: Map<Char, Int> = buildMap {
        for ((byte, char) in table) {
            if (char !in this) put(char, byte)
        }
    }

    /**
     * Decodes bytes starting at [offset] up to [maxLength] bytes or the
     * 0xFF terminator, whichever comes first. Padding after the terminator
     * (conventionally 0x00) is not included in the result.
     */
    fun decode(bytes: ByteArray, offset: Int, maxLength: Int): String {
        val sb = StringBuilder()
        var i = offset
        val end = minOf(offset + maxLength, bytes.size)
        while (i < end) {
            val b = bytes[i].toInt() and 0xFF
            if (b == TERMINATOR) break
            sb.append(table[b] ?: '\uFFFD') // unmapped byte -> replacement char, never a guess
            i++
        }
        return sb.toString()
    }

    /**
     * Encodes [text] into exactly [fieldLength] bytes: as many characters as
     * fit, then a 0xFF terminator (if there's room), then 0x00 padding to fill
     * the rest — the inverse of [decode], and matching the on-disk shape every
     * name field in FireRed already uses. Characters with no mapping in
     * [reverseTable] (accents, unsupported punctuation, non-Latin script) are
     * written as a space rather than silently guessing a lookalike byte;
     * [unsupportedChars] in the same string reports which ones so a caller can
     * warn the user instead of the substitution happening invisibly.
     */
    fun encode(text: String, fieldLength: Int): ByteArray {
        val bytes = ByteArray(fieldLength) { 0x00 }
        var i = 0
        for (ch in text) {
            if (i >= fieldLength) break
            bytes[i] = (reverseTable[ch] ?: reverseTable[' ']!!).toByte()
            i++
        }
        if (i < fieldLength) bytes[i] = TERMINATOR.toByte()
        return bytes
    }

    /** Characters in [text] that [encode] can't represent and will fall back to a space for. */
    fun unsupportedChars(text: String): Set<Char> = text.filterNot { it in reverseTable }.toSet()

    /** The longest name [encode] can store in a field of [fieldLength] bytes (room left for the terminator). */
    fun maxEncodableLength(fieldLength: Int): Int = (fieldLength - 1).coerceAtLeast(0)
}
