package com.romexplorer.gba.core.compression

/** Thrown when a byte stream does not decode as valid GBA LZ77. */
class Lz77FormatException(message: String) : Exception(message)

/**
 * Codec for the GBA BIOS "LZ77UnCompVram"/"LZ77UnCompWram" format (a
 * variant of LZSS). Header layout:
 *   byte 0        = 0x10 (format tag)
 *   bytes 1..3    = decompressed size, little-endian, 24-bit
 *   then a stream of blocks: 1 flag byte (MSB-first bits), where a 0 bit
 *   means "copy one literal byte" and a 1 bit means "copy/back-reference"
 *   encoded as 2 bytes: high nibble of byte0 = (len-3), low nibble of byte0
 *   plus all of byte1 = (disp-1), disp counted back from the output cursor.
 */
object Lz77Codec {

    const val FORMAT_TAG = 0x10

    fun isLikelyHeader(byte0: Int): Boolean = byte0 == FORMAT_TAG

    /**
     * Decompresses [input] (which must start at the 4-byte LZ77 header).
     * Throws [Lz77FormatException] on any structural inconsistency rather
     * than silently returning garbage — callers (e.g. the ROM analyzer) rely
     * on this to distinguish a real compressed block from a coincidental
     * 0x10 byte in unrelated data.
     */
    fun decompress(input: ByteArray): ByteArray {
        if (input.size < 4) throw Lz77FormatException("Input too short for LZ77 header")
        if ((input[0].toInt() and 0xFF) != FORMAT_TAG) {
            throw Lz77FormatException("Missing 0x10 format tag")
        }

        val decompressedSize = (input[1].toInt() and 0xFF) or
            ((input[2].toInt() and 0xFF) shl 8) or
            ((input[3].toInt() and 0xFF) shl 16)

        if (decompressedSize <= 0) {
            throw Lz77FormatException("Declared decompressed size is zero")
        }

        val out = ByteArray(decompressedSize)
        var outPos = 0
        var inPos = 4

        fun nextByte(): Int {
            if (inPos >= input.size) throw Lz77FormatException("Unexpected end of input")
            return (input[inPos++].toInt() and 0xFF)
        }

        while (outPos < decompressedSize) {
            val flags = nextByte()
            for (bit in 7 downTo 0) {
                if (outPos >= decompressedSize) break
                val isBackref = (flags shr bit) and 1 == 1
                if (!isBackref) {
                    out[outPos++] = nextByte().toByte()
                } else {
                    val b0 = nextByte()
                    val b1 = nextByte()
                    val length = ((b0 ushr 4) and 0x0F) + 3
                    val disp = (((b0 and 0x0F) shl 8) or b1) + 1
                    val copySrc = outPos - disp
                    if (copySrc < 0) {
                        throw Lz77FormatException("Back-reference points before start of output")
                    }
                    for (i in 0 until length) {
                        if (outPos >= decompressedSize) break
                        out[outPos] = out[copySrc + i]
                        outPos++
                    }
                }
            }
        }
        return out
    }

    /**
     * Greedy LZ77 compressor: at each position, finds the longest match
     * within the 4096-byte window using a simple backward scan. Not as
     * tight as an optimal-parse compressor, but produces correct,
     * spec-compliant output that decompresses byte-for-byte identically —
     * verified by [decompress] round-trip in unit tests.
     */
    fun compress(input: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        out.write(FORMAT_TAG)
        out.write(input.size and 0xFF)
        out.write((input.size ushr 8) and 0xFF)
        out.write((input.size ushr 16) and 0xFF)

        var pos = 0
        val maxDisp = 4096
        val minMatch = 3
        val maxMatch = 18

        while (pos < input.size) {
            var flagByte = 0
            val blockBuffer = java.io.ByteArrayOutputStream()

            for (bit in 7 downTo 0) {
                if (pos >= input.size) break

                val windowStart = maxOf(0, pos - maxDisp)
                var bestLen = 0
                var bestDisp = 0

                var searchPos = windowStart
                while (searchPos < pos) {
                    var matchLen = 0
                    val maxPossible = minOf(maxMatch, input.size - pos)
                    while (matchLen < maxPossible && input[searchPos + matchLen] == input[pos + matchLen]) {
                        matchLen++
                    }
                    if (matchLen > bestLen) {
                        bestLen = matchLen
                        bestDisp = pos - searchPos
                    }
                    searchPos++
                }

                if (bestLen >= minMatch) {
                    flagByte = flagByte or (1 shl bit)
                    val lenField = bestLen - 3
                    val dispField = bestDisp - 1
                    blockBuffer.write(((lenField and 0x0F) shl 4) or ((dispField ushr 8) and 0x0F))
                    blockBuffer.write(dispField and 0xFF)
                    pos += bestLen
                } else {
                    blockBuffer.write(input[pos].toInt() and 0xFF)
                    pos += 1
                }
            }

            out.write(flagByte)
            blockBuffer.writeTo(out)
        }

        // Pad to a multiple of 4 bytes, as GBA BIOS decompression routines expect.
        while (out.size() % 4 != 0) out.write(0)
        return out.toByteArray()
    }
}
