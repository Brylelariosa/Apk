package com.romexplorer.gba.core.worldmap

import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.pokemon.PokemonTextCodec
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Resolves a map header's `regionMapSectionId` (see [MapHeaderReader]) to
 * the real in-game location name it displays on the status bar and Town
 * Map — "PALLET TOWN", "ROUTE 1", ... — rather than only this app's own
 * "Bank X, Map Y" label.
 *
 * The table itself ([FireRedMapTables.MAP_NAMES_POINTER_TABLE_OFFSET]) is a
 * flat array of 4-byte pointers, one per region-map-section id, each
 * pointing to its own Pokémon-text-encoded, 0xFF-terminated string
 * elsewhere in ROM — unlike
 * [com.romexplorer.gba.core.pokemon.NameTableLookup]'s flat *fixed-length*
 * arrays (species/move/type names), since location names vary too much in
 * length for one fixed stride to fit all of them.
 *
 * That offset itself still comes from a single source (see
 * [FireRedMapTables]'s class doc) — but the table's *length* now has two:
 * a 2010 PokéCommunity thread's own aside ("Fire Red has exactly 108 map
 * names") and, independently, Bulbapedia's "FireRed and LeafGreen
 * locations" category, which currently lists exactly 108 pages. [read]
 * enforces that bound ([VALID_SECTION_ID_RANGE]) rather than trusting
 * anything that merely decodes cleanly: real ROM data past the table's
 * real end can still coincidentally fall in [PokemonTextCodec]'s
 * letter/space ranges for a few bytes and produce a plausible-*looking*
 * word — that's exactly what shipped briefly, resolving a handful of
 * Sevii Islands interior maps to invented names like "WEEPTH CHAMBER"
 * instead of leaving them as "Bank X, Map Y". A byte with literally no
 * [PokemonTextCodec] mapping is still rejected too, as a second,
 * independent check. Beyond both, [verifyAgainstPalletTown] re-checks the
 * sourcing thread's own worked example — id 0 must decode to exactly
 * "PALLET TOWN" — against whatever ROM is actually open; callers use it
 * once per session (see `MapExplorerViewModel`) to decide whether to trust
 * [read]'s output for this ROM at all, so a revision or hack where this
 * offset doesn't hold falls back to "Bank X, Map Y" instead of showing a
 * confidently wrong name.
 */
object MapNameReader {
    private const val MAX_NAME_BYTES = 16 // comfortably fits every vanilla FireRed location name, e.g. "SEVEN ISLAND"

    /** See class doc — corroborated by two independent sources counting exactly 108 real entries (ids 0-107). */
    private val VALID_SECTION_ID_RANGE = 0..107

    suspend fun read(rom: RomAccessor, regionMapSectionId: Int): String? {
        if (regionMapSectionId !in VALID_SECTION_ID_RANGE) return null
        val pointerOffset = FireRedMapTables.MAP_NAMES_POINTER_TABLE_OFFSET + regionMapSectionId * 4L
        if (pointerOffset < 0 || pointerOffset + 4 > rom.sizeBytes) return null

        val stringOffset = GbaGraphics.readPointer32(rom.read(pointerOffset, 4), 0) ?: return null
        if (stringOffset < 0 || stringOffset >= rom.sizeBytes) return null

        val bytes = rom.read(stringOffset, MAX_NAME_BYTES)
        if (bytes.isEmpty()) return null
        val decoded = PokemonTextCodec.decode(bytes, 0, bytes.size)
        // '\uFFFD' is PokemonTextCodec's own "byte not in the known table"
        // marker — a real location name never contains one, so its
        // presence means these bytes almost certainly aren't a name at all.
        return decoded.takeIf { it.isNotBlank() && '\uFFFD' !in it }
    }

    /** See class doc — the one runtime fact this table's sourcing thread demonstrates byte-for-byte. */
    suspend fun verifyAgainstPalletTown(rom: RomAccessor): Boolean = read(rom, 0) == "PALLET TOWN"
}
