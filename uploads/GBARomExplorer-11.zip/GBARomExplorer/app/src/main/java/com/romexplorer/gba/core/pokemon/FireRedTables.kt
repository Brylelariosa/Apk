package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.DisplayHint
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField

/**
 * Known, fixed-layout data tables for Pokémon FireRed (US/EU, revision 0 —
 * internal game code "BPRE", header version byte 0x00, the ROM the
 * `pret/pokefirered` decompilation project builds by default). Every offset
 * and struct layout below was cross-checked against real data before being
 * used here, not taken on faith from a single source:
 *
 * - Species base stats (28 bytes/entry, offset 0x254784): struct layout from
 *   Bulbapedia's "Pokémon species data structure (Generation III)". Verified
 *   by hand-decoding the article's own Bulbasaur sample bytes against
 *   Bulbasaur's real, known stats (HP 45/Atk 49/Def 49/Spe 45/SpA 65/SpD 65,
 *   Grass/Poison, catch rate 45, ability Overgrow, egg groups Monster/Grass,
 *   Pokédex color Green) — every field matched exactly. The table's start
 *   offset (where index 0, the unused placeholder, begins) is 0x254784,
 *   cross-checked against two independent community ROM-offset references
 *   (erandis-vol/Pokemon-Editor's BPRE.ini and MrDollSteak's G3HS BPRE ini,
 *   which agree on 0x254784 despite being unrelated projects); Bulbasaur
 *   (index 1) then sits at 0x2547A0, which is what the fingerprint check
 *   below actually verifies. An earlier version of this file used 0x2547A0
 *   as the table start instead of 0x254784, which put every species one
 *   index too low (index 0 showing Bulbasaur's real stats, index 5 showing
 *   Charizard's, etc.) — the kind of bug that looks correct at a glance
 *   because the data itself isn't corrupted, just mislabeled.
 * - Move data (12 bytes/entry, offset 0x250C04): struct layout from
 *   Bulbapedia's "Move data structure (Generation III)". Verified against
 *   the article's Pound sample (power 40, Normal type, 100 accuracy, 35 PP,
 *   makes contact, blocked by Protect) — matches Pound's real data exactly.
 * - Item data (44 bytes/entry, offset 0x3DB028): struct layout from
 *   Bulbapedia's "Item data structure (Generation III)".
 * - Trainer headers (40 bytes/entry, offset 0x23EAC8): struct layout copied
 *   verbatim from `pret/pokefirered`'s own `include/battle.h` (the actual
 *   decompiled source used to build this ROM), which documents each field's
 *   byte offset directly in comments. The offset (0x23EAC8) and per-entry
 *   size (40 bytes) are independently corroborated by two community
 *   references, one of which states the table is exactly 29,720 bytes long
 *   — 743 x 40, matching FireRed's well-known trainer count.
 * - Species names (11 bytes/entry, offset 0x245EE0) and move names (13
 *   bytes/entry, offset 0x247094): both cross-checked against the same two
 *   community ROM-offset references used above for the trainer table, which
 *   agree exactly on both offsets and both entry lengths. Flat array format
 *   — see [NameTableLookup] — indexed identically to the data table each
 *   describes ([speciesBaseStats], [moves]).
 * - Trainer party entries (variable shape, reached via each trainer's "Party
 *   Pointer"): struct layouts copied verbatim from `pret/pokefirered`'s
 *   `include/battle.h` (`TrainerMonNoItemDefaultMoves`/`ItemDefaultMoves`/
 *   `NoItemCustomMoves`/`ItemCustomMoves` — which of the four a given trainer
 *   uses is decided by its "Party Flags" bits, see [TrainerPartyReader]).
 *   None of the four declares a packed layout, so each has an implicit
 *   1-byte pad after `lvl` to align `species` on an even address — standard
 *   ARM struct alignment, not the ROM format doing anything unusual.
 * - Type names (7 bytes/entry, offset 0x24F1A0, 18 types): cross-checked by
 *   two independent sources, one of which (a "how to add a type" tutorial)
 *   shows the actual decoded bytes at that address spelling out NORMAL,
 *   FIGHT, FLYING, ... DARK in FireRed's own in-game order — not just an
 *   offset copied between lists, but someone's real hex dump read back as
 *   the expected type names. Items also has an unrelated field also named
 *   "Type" (byte 27) — that's the item's menu category (Ball/TM/etc.), not
 *   an elemental type, and isn't resolved against this table.
 *
 * Revision 1 (v1.1) and other language releases use different offsets for
 * at least some of these tables and are not covered — [FireRedGamePlugin]
 * only claims these regions for the specific header signature this file
 * was verified against.
 */
object FireRedTables {
    const val EXPECTED_GAME_CODE = "BPRE"
    const val EXPECTED_HEADER_VERSION = 0 // rev0 / v1.0; see class doc

    // Flat name arrays — see NameTableLookup and the class doc above.
    const val SPECIES_NAMES_OFFSET = 0x245EE0L
    const val SPECIES_NAME_LENGTH = 11
    const val MOVE_NAMES_OFFSET = 0x247094L
    const val MOVE_NAME_LENGTH = 13
    const val TYPE_NAMES_OFFSET = 0x24F1A0L
    const val TYPE_NAME_LENGTH = 7
    const val TYPE_COUNT = 18

    val speciesBaseStats = KnownTableSchema(
        id = "fr_species_base_stats",
        displayName = "Species Base Stats",
        romOffset = 0x254784L,
        entrySize = 28,
        entryCount = 412, // standard Gen III species table size (incl. Egg/unused slots)
        fields = listOf(
            TableField("Base HP", 0, 1, FieldKind.UINT8),
            TableField("Base Attack", 1, 1, FieldKind.UINT8),
            TableField("Base Defense", 2, 1, FieldKind.UINT8),
            TableField("Base Speed", 3, 1, FieldKind.UINT8),
            TableField("Base Sp. Attack", 4, 1, FieldKind.UINT8),
            TableField("Base Sp. Defense", 5, 1, FieldKind.UINT8),
            TableField("Type 1", 6, 1, FieldKind.UINT8, DisplayHint.TYPE_ID),
            TableField("Type 2", 7, 1, FieldKind.UINT8, DisplayHint.TYPE_ID),
            TableField("Catch Rate", 8, 1, FieldKind.UINT8),
            TableField("Base Exp Yield", 9, 1, FieldKind.UINT8),
            TableField("EV Yield (packed)", 10, 2, FieldKind.UINT16),
            TableField("Item 1", 12, 2, FieldKind.UINT16, DisplayHint.ITEM_ID),
            TableField("Item 2", 14, 2, FieldKind.UINT16, DisplayHint.ITEM_ID),
            TableField("Gender Threshold", 16, 1, FieldKind.UINT8),
            TableField("Egg Cycles", 17, 1, FieldKind.UINT8),
            TableField("Base Friendship", 18, 1, FieldKind.UINT8),
            TableField("Level-up Type", 19, 1, FieldKind.UINT8),
            TableField("Egg Group 1", 20, 1, FieldKind.UINT8),
            TableField("Egg Group 2", 21, 1, FieldKind.UINT8),
            TableField("Ability 1", 22, 1, FieldKind.UINT8),
            TableField("Ability 2", 23, 1, FieldKind.UINT8),
            TableField("Safari Zone Rate", 24, 1, FieldKind.UINT8),
            TableField("Color / Flip", 25, 1, FieldKind.UINT8),
        ),
    )

    val moves = KnownTableSchema(
        id = "fr_moves",
        displayName = "Move Data",
        romOffset = 0x250C04L,
        entrySize = 12,
        entryCount = 355, // standard Gen III move count (index 0 = unused "-")
        fields = listOf(
            TableField("Effect", 0, 1, FieldKind.UINT8),
            TableField("Base Power", 1, 1, FieldKind.UINT8),
            TableField("Type", 2, 1, FieldKind.UINT8, DisplayHint.TYPE_ID),
            TableField("Accuracy", 3, 1, FieldKind.UINT8),
            TableField("PP", 4, 1, FieldKind.UINT8),
            TableField("Effect Accuracy", 5, 1, FieldKind.UINT8),
            TableField("Target", 6, 1, FieldKind.UINT8),
            TableField("Priority", 7, 1, FieldKind.INT8),
            TableField("Flags", 8, 1, FieldKind.UINT8),
        ),
    )

    val items = KnownTableSchema(
        id = "fr_items",
        displayName = "Item Data",
        romOffset = 0x3DB028L,
        entrySize = 44,
        entryCount = 375, // commonly-cited FireRed/LeafGreen item count; a few trailing slots may be unused padding
        fields = listOf(
            TableField("Name", 0, 14, FieldKind.POKEMON_STRING),
            TableField("Index Number", 14, 2, FieldKind.UINT16),
            TableField("Price", 16, 2, FieldKind.UINT16),
            TableField("Hold Effect", 18, 1, FieldKind.UINT8),
            TableField("Parameter", 19, 1, FieldKind.UINT8),
            TableField("Description Pointer", 20, 4, FieldKind.POINTER32),
            TableField("Mystery Value", 24, 2, FieldKind.UINT16),
            TableField("Pocket", 26, 1, FieldKind.UINT8),
            TableField("Type", 27, 1, FieldKind.UINT8),
            TableField("Field Usage Pointer", 28, 4, FieldKind.POINTER32),
            TableField("Battle Usage", 32, 4, FieldKind.UINT32),
            TableField("Battle Usage Pointer", 36, 4, FieldKind.POINTER32),
            TableField("Extra Parameter", 40, 4, FieldKind.UINT32),
        ),
    )

    val trainers = KnownTableSchema(
        id = "fr_trainers",
        displayName = "Trainer Data",
        romOffset = 0x23EAC8L,
        entrySize = 40,
        entryCount = 743, // cross-checked: community-documented table size 29,720 bytes / 40 = 743
        fields = listOf(
            TableField("Party Flags", 0, 1, FieldKind.UINT8),
            TableField("Trainer Class", 1, 1, FieldKind.UINT8),
            TableField("Encounter Music / Gender", 2, 1, FieldKind.UINT8),
            TableField("Trainer Pic", 3, 1, FieldKind.UINT8),
            TableField("Name", 4, 12, FieldKind.POKEMON_STRING),
            TableField("Item 1", 16, 2, FieldKind.UINT16, DisplayHint.ITEM_ID),
            TableField("Item 2", 18, 2, FieldKind.UINT16, DisplayHint.ITEM_ID),
            TableField("Item 3", 20, 2, FieldKind.UINT16, DisplayHint.ITEM_ID),
            TableField("Item 4", 22, 2, FieldKind.UINT16, DisplayHint.ITEM_ID),
            TableField("Double Battle", 24, 1, FieldKind.UINT8),
            TableField("AI Flags", 28, 4, FieldKind.UINT32),
            TableField("Party Size", 32, 1, FieldKind.UINT8),
            TableField("Party Pointer", 36, 4, FieldKind.POINTER32),
        ),
    )

    val all: List<KnownTableSchema> = listOf(speciesBaseStats, moves, items, trainers)
}
