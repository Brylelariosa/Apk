package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/** A move's real battle-animation script, as read from the ROM — see [BattleAnimationReader]. */
data class BattleAnimationScript(
    val moveIndex: Int,
    val romOffset: Long,
    val bytes: ByteArray,
) {
    override fun equals(other: Any?): Boolean =
        other is BattleAnimationScript && moveIndex == other.moveIndex && romOffset == other.romOffset && bytes.contentEquals(other.bytes)

    override fun hashCode(): Int = 31 * (31 * moveIndex + romOffset.hashCode()) + bytes.contentHashCode()
}

/**
 * Resolves a move's real battle animation script — the actual per-move
 * pointer table and script bytes FireRed's animation engine plays back in
 * battle — rather than a decorative stand-in with no connection to the
 * ROM. See [MoveAnimationVisualizer] for what this data is (and isn't)
 * used for.
 *
 * - Animation pointer table (4 bytes/entry, offset 0x1C68F4, indexed
 *   identically to [FireRedTables.moves]/[FireRedTables.MOVE_NAMES_OFFSET]):
 *   community-documented with a worked, independently-reproducible example
 *   (move #57, Surf: 57 x 4 + 0x1C68F4 = 0x1C69D8) — the same "hand-verify
 *   the arithmetic" bar [FireRedTables]'s own class doc holds every offset
 *   in this app to, rather than an offset just copied between lists.
 *   Corroborated further by the same source's two adjacent offsets (attack
 *   names, attack data) matching this app's own already-independently-
 *   verified [FireRedTables.MOVE_NAMES_OFFSET] and [FireRedTables.moves]
 *   offsets exactly.
 *
 * What this deliberately does NOT do: semantically decode the animation
 * script's own bytecode. That's a different, much less publicly documented
 * instruction set from the field-script engine [com.romexplorer.gba.core.pokescript]
 * decodes — see that package's class doc for why *that* one could be
 * fully, verifiably decoded and this one wasn't attempted. Rather than ship
 * an opcode table this app can't stand behind, this reader exposes exactly
 * what it can verify: the real pointer, and the real bytes at it.
 */
object BattleAnimationReader {
    const val POINTER_TABLE_OFFSET = 0x1C68F4L

    /**
     * How many raw bytes to pull back per script. Real FireRed animation
     * scripts are typically well under this, but this is a display/derive
     * window, not a claim about a given script's true length — this reader
     * doesn't decode the bytecode, so it has no way to know exactly where a
     * given script actually ends (see class doc).
     */
    const val SCRIPT_WINDOW_BYTES = 256

    suspend fun read(rom: RomAccessor, moveIndex: Int): BattleAnimationScript? {
        if (moveIndex < 0) return null
        val pointerOffset = POINTER_TABLE_OFFSET + moveIndex * 4L
        if (pointerOffset + 4 > rom.sizeBytes) return null
        val pointerBytes = rom.read(pointerOffset, 4)
        if (pointerBytes.size < 4) return null
        val scriptOffset = GbaGraphics.readPointer32(pointerBytes, 0) ?: return null
        if (scriptOffset < 0 || scriptOffset >= rom.sizeBytes) return null

        val windowLen = minOf(SCRIPT_WINDOW_BYTES.toLong(), rom.sizeBytes - scriptOffset).toInt()
        if (windowLen <= 0) return null
        val bytes = rom.read(scriptOffset, windowLen)
        if (bytes.isEmpty()) return null
        return BattleAnimationScript(moveIndex, scriptOffset, bytes)
    }
}
