package com.romexplorer.gba.ui.patch

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.domain.usecase.PatchApplyOutcome
import com.romexplorer.gba.domain.usecase.PatchOperationsUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class PatchOpState {
    data object Idle : PatchOpState()
    data object Running : PatchOpState()
    data class Success(val message: String) : PatchOpState()
    data class Failure(val message: String) : PatchOpState()
}

class PatchViewModel(
    private val patchOperationsUseCase: PatchOperationsUseCase,
) : ViewModel() {

    private val _createState = MutableStateFlow<PatchOpState>(PatchOpState.Idle)
    val createState: StateFlow<PatchOpState> = _createState.asStateFlow()

    private val _applyState = MutableStateFlow<PatchOpState>(PatchOpState.Idle)
    val applyState: StateFlow<PatchOpState> = _applyState.asStateFlow()

    private val _verifyState = MutableStateFlow<PatchOpState>(PatchOpState.Idle)
    val verifyState: StateFlow<PatchOpState> = _verifyState.asStateFlow()

    fun createPatch(originalUri: Uri, modifiedUri: Uri, destinationUri: Uri) {
        viewModelScope.launch {
            _createState.value = PatchOpState.Running
            val result = patchOperationsUseCase.createPatch(originalUri, modifiedUri, destinationUri)
            _createState.value = result.fold(
                onSuccess = { PatchOpState.Success("IPS patch created successfully") },
                onFailure = { PatchOpState.Failure(it.message ?: "Failed to create patch") },
            )
        }
    }

    fun applyPatch(originalUri: Uri, patchUri: Uri, destinationUri: Uri) {
        viewModelScope.launch {
            _applyState.value = PatchOpState.Running
            val result = patchOperationsUseCase.applyPatch(originalUri, patchUri, destinationUri)
            _applyState.value = result.fold(
                onSuccess = { it.toSuccessState("Patch applied") },
                onFailure = { PatchOpState.Failure(it.message ?: "Failed to apply patch") },
            )
        }
    }

    fun verifyPatch(originalUri: Uri, patchUri: Uri) {
        viewModelScope.launch {
            _verifyState.value = PatchOpState.Running
            val result = patchOperationsUseCase.verifyPatch(originalUri, patchUri)
            _verifyState.value = result.fold(
                onSuccess = { it.toSuccessState("Patch verified") },
                onFailure = { PatchOpState.Failure(it.message ?: "Failed to verify patch") },
            )
        }
    }

    private fun PatchApplyOutcome.toSuccessState(prefix: String): PatchOpState.Success =
        PatchOpState.Success("$prefix — output size $outputSizeBytes bytes, SHA-1 $outputSha1")
}
