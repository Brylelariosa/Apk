package com.romexplorer.gba.core.patch

/** Result of applying or verifying a patch. */
sealed class PatchResult {
    data class Success(val outputSize: Int) : PatchResult()
    data class Failure(val reason: String) : PatchResult()
}

/**
 * Common contract for binary patch formats (IPS today; UPS/BPS are natural
 * next implementations of this same interface — see the project roadmap).
 * Keeping this as an interface means the patch screen and repository layer
 * never need to change when a new format is added.
 */
interface PatchFormat {
    val formatName: String

    /** Produces a patch describing how to transform [original] into [modified]. */
    fun create(original: ByteArray, modified: ByteArray): ByteArray

    /** Applies [patch] to [original], returning the patched bytes. */
    fun apply(original: ByteArray, patch: ByteArray): ByteArray

    /** Quick structural check that [patch] is well-formed for this format. */
    fun isValid(patch: ByteArray): Boolean
}
