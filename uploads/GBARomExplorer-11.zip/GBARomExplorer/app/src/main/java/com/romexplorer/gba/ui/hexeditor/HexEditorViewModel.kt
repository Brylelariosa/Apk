package com.romexplorer.gba.ui.hexeditor

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.hex.HexBookmark
import com.romexplorer.gba.core.hex.HexSearchEngine
import com.romexplorer.gba.data.repository.BookmarksRepository
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** One row's worth of already-decoded hex-editor state, ready for the UI to render. */
data class HexRow(
    val offset: Long,
    val bytes: List<Int>, // 0..255 per byte, overlay-resolved
    val editedMask: List<Boolean>,
)

class HexEditorViewModel(
    private val sessionManager: RomSessionManager,
    private val bookmarksRepository: BookmarksRepository,
) : ViewModel() {

    companion object {
        const val BYTES_PER_ROW = 16
        const val ROWS_PER_PAGE = 16
        const val PAGE_SIZE = BYTES_PER_ROW * ROWS_PER_PAGE // 256 bytes
    }

    val session = sessionManager.session

    private val _pageStart = MutableStateFlow(0L)
    val pageStart: StateFlow<Long> = _pageStart.asStateFlow()

    private val _rows = MutableStateFlow<List<HexRow>>(emptyList())
    val rows: StateFlow<List<HexRow>> = _rows.asStateFlow()

    private val _editMode = MutableStateFlow(false)
    val editMode: StateFlow<Boolean> = _editMode.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Long>>(emptyList())
    val searchResults: StateFlow<List<Long>> = _searchResults.asStateFlow()

    private val _searching = MutableStateFlow(false)
    val searching: StateFlow<Boolean> = _searching.asStateFlow()

    val bookmarks: StateFlow<List<HexBookmark>> = sessionManager.session
        .flatMapLatest { s -> if (s == null) kotlinx.coroutines.flow.flowOf(emptyList()) else bookmarksRepository.bookmarksFor(s.cacheKey) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadPage(0L)
    }

    fun toggleEditMode() {
        _editMode.value = !_editMode.value
    }

    fun jumpToOffset(offset: Long) {
        val size = sessionManager.session.value?.accessor?.sizeBytes ?: return
        val clamped = offset.coerceIn(0L, (size - 1).coerceAtLeast(0))
        loadPage(clamped - (clamped % PAGE_SIZE))
    }

    fun nextPage() {
        val size = sessionManager.session.value?.accessor?.sizeBytes ?: return
        val next = _pageStart.value + PAGE_SIZE
        if (next < size) loadPage(next)
    }

    fun previousPage() {
        val prev = _pageStart.value - PAGE_SIZE
        if (prev >= 0) loadPage(prev)
    }

    private fun loadPage(start: Long) {
        val current = sessionManager.session.value ?: return
        viewModelScope.launch {
            val length = minOf(PAGE_SIZE.toLong(), current.accessor.sizeBytes - start).toInt().coerceAtLeast(0)
            val bytes = if (length > 0) current.accessor.read(start, length) else ByteArray(0)
            _pageStart.value = start
            _rows.value = buildRows(start, bytes, current.editOverlay)
        }
    }

    /** Re-renders the currently loaded page from the overlay (called after an edit/undo/redo). */
    private fun refreshCurrentPage() {
        val current = sessionManager.session.value ?: return
        val start = _pageStart.value
        viewModelScope.launch {
            val length = minOf(PAGE_SIZE.toLong(), current.accessor.sizeBytes - start).toInt().coerceAtLeast(0)
            val bytes = if (length > 0) current.accessor.read(start, length) else ByteArray(0)
            _rows.value = buildRows(start, bytes, current.editOverlay)
        }
    }

    private fun buildRows(pageStart: Long, bytes: ByteArray, overlay: com.romexplorer.gba.core.hex.EditOverlay): List<HexRow> {
        return bytes.toList().chunked(BYTES_PER_ROW).mapIndexed { rowIndex, rowBytes ->
            val rowOffset = pageStart + rowIndex * BYTES_PER_ROW
            val resolved = rowBytes.mapIndexed { i, b ->
                overlay.get(rowOffset + i) ?: (b.toInt() and 0xFF)
            }
            val edited = rowBytes.indices.map { i -> overlay.get(rowOffset + i) != null }
            HexRow(rowOffset, resolved, edited)
        }
    }

    fun editByte(offset: Long, newValue: Int) {
        if (!_editMode.value) return
        val current = sessionManager.session.value ?: return
        viewModelScope.launch {
            val originalByte = withContext(Dispatchers.IO) { current.accessor.readByte(offset) }
            if (originalByte < 0) return@launch
            current.editOverlay.setByte(offset, newValue.coerceIn(0, 255), originalByte)
            sessionManager.persistDraft()
            refreshCurrentPage()
        }
    }

    fun undo() {
        val current = sessionManager.session.value ?: return
        current.editOverlay.undo()
        viewModelScope.launch { sessionManager.persistDraft() }
        refreshCurrentPage()
    }

    fun redo() {
        val current = sessionManager.session.value ?: return
        current.editOverlay.redo()
        viewModelScope.launch { sessionManager.persistDraft() }
        refreshCurrentPage()
    }

    fun canUndo(): Boolean = sessionManager.session.value?.editOverlay?.canUndo() ?: false
    fun canRedo(): Boolean = sessionManager.session.value?.editOverlay?.canRedo() ?: false
    fun isDirty(): Boolean = sessionManager.session.value?.editOverlay?.isDirty ?: false

    fun search(query: String, asHex: Boolean) {
        val current = sessionManager.session.value ?: return
        viewModelScope.launch {
            _searching.value = true
            _searchResults.value = emptyList()
            val results = if (asHex) {
                val pattern = parseHexPattern(query)
                if (pattern != null) HexSearchEngine.searchBytes(current.accessor, pattern) else emptyList()
            } else {
                HexSearchEngine.searchAscii(current.accessor, query)
            }
            _searchResults.value = results
            _searching.value = false
            if (results.isEmpty()) {
                _statusMessage.value = "No matches found"
            } else {
                _statusMessage.value = "${results.size} match(es) found"
                jumpToOffset(results.first())
            }
        }
    }

    private fun parseHexPattern(text: String): ByteArray? {
        val clean = text.replace(" ", "").replace("0x", "", ignoreCase = true)
        if (clean.isEmpty() || clean.length % 2 != 0) return null
        return runCatching {
            ByteArray(clean.length / 2) { i ->
                clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
            }
        }.getOrNull()
    }

    fun addBookmark(offset: Long, label: String) {
        val current = sessionManager.session.value ?: return
        viewModelScope.launch { bookmarksRepository.add(current.cacheKey, HexBookmark(offset, label)) }
    }

    fun removeBookmark(offset: Long) {
        val current = sessionManager.session.value ?: return
        viewModelScope.launch { bookmarksRepository.remove(current.cacheKey, offset) }
    }

    fun clearStatus() {
        _statusMessage.value = null
    }

    fun hasUnsavedEdits(): Boolean = sessionManager.hasUnsavedEdits()

    /** Writes the edited ROM (original bytes with the overlay applied) to [destination] — see RomSessionManager.exportEditedRom. */
    fun saveAs(destination: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val result = sessionManager.exportEditedRom(destination)
            _statusMessage.value = if (result.isSuccess) "Saved successfully" else "Save failed: ${result.exceptionOrNull()?.message}"
            onDone(result.isSuccess)
        }
    }
}
