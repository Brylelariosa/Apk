package com.romexplorer.gba.core.worldmap

import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/** Decodes a single map's full data — header, layout, tilesets, events, connections — from a known header offset. See [FireRedMapTables] for struct sourcing. */
object MapHeaderReader {

    /**
     * True if the bytes at [offset] look like a real MapHeader rather than
     * unrelated data — its layout and events pointer fields both have to
     * resolve to plausible, in-bounds ROM addresses. This is what lets
     * [MapListReader] tell "a real map" apart from "ran off the end of a
     * bank's pointer array into whatever follows it" without knowing an
     * exact map count up front — FireRed doesn't store one (see
     * [MapListReader]'s class doc).
     */
    suspend fun looksLikeMapHeader(rom: RomAccessor, offset: Long): Boolean {
        if (offset < 0 || offset + FireRedMapTables.MAP_HEADER_SIZE > rom.sizeBytes) return false
        val bytes = rom.read(offset, FireRedMapTables.MAP_HEADER_SIZE)
        if (bytes.size < FireRedMapTables.MAP_HEADER_SIZE) return false
        val layoutOffset = GbaGraphics.readPointer32(bytes, 0x00) ?: return false
        val eventsOffset = GbaGraphics.readPointer32(bytes, 0x04) ?: return false
        return layoutOffset < rom.sizeBytes && eventsOffset < rom.sizeBytes
    }

    suspend fun read(rom: RomAccessor, id: MapId, headerOffset: Long): MapHeaderData? {
        if (headerOffset < 0 || headerOffset + FireRedMapTables.MAP_HEADER_SIZE > rom.sizeBytes) return null
        val header = rom.read(headerOffset, FireRedMapTables.MAP_HEADER_SIZE)
        if (header.size < FireRedMapTables.MAP_HEADER_SIZE) return null

        val layoutOffset = GbaGraphics.readPointer32(header, 0x00)
        val eventsOffset = GbaGraphics.readPointer32(header, 0x04)
        val connectionsOffset = GbaGraphics.readPointer32(header, 0x0C)

        val layout = layoutOffset?.let { readLayout(rom, it) }
        val events = eventsOffset?.let { readEvents(rom, it) } ?: MapEventsData(emptyList(), emptyList(), emptyList(), emptyList())
        val connections = connectionsOffset?.let { readConnections(rom, it) } ?: emptyList()

        return MapHeaderData(
            id = id,
            headerOffset = headerOffset,
            layout = layout,
            events = events,
            connections = connections,
            music = readU16(header, 0x10),
            mapLayoutId = readU16(header, 0x12),
            regionMapSectionId = header[0x14].toInt() and 0xFF,
            cave = header[0x15].toInt() and 0xFF,
            weather = header[0x16].toInt() and 0xFF,
            mapType = header[0x17].toInt() and 0xFF,
            bikingAllowed = (header[0x18].toInt() and 0xFF) != 0,
            battleType = header[0x1B].toInt() and 0xFF,
        )
    }

    private suspend fun readLayout(rom: RomAccessor, offset: Long): MapLayoutData? {
        val size = FireRedMapTables.MAP_LAYOUT_READ_SIZE
        if (offset < 0 || offset + size > rom.sizeBytes) return null
        val bytes = rom.read(offset, size)
        if (bytes.size < size) return null
        val width = readS32(bytes, 0x00)
        val height = readS32(bytes, 0x04)
        // Sanity bound, not a verified engine limit — filters out garbage
        // reads from a wrong pointer rather than trying to render a
        // multi-million-tile bitmap.
        if (width <= 0 || height <= 0 || width > 500 || height > 500) return null
        val mapDataPointer = GbaGraphics.readPointer32(bytes, 0x0C) ?: return null
        val primaryTilesetOffset = GbaGraphics.readPointer32(bytes, 0x10)
        val secondaryTilesetOffset = GbaGraphics.readPointer32(bytes, 0x14)
        return MapLayoutData(
            width = width,
            height = height,
            borderPointer = GbaGraphics.readPointer32(bytes, 0x08) ?: 0L,
            mapDataPointer = mapDataPointer,
            primaryTileset = primaryTilesetOffset?.let { readTileset(rom, it) },
            secondaryTileset = secondaryTilesetOffset?.let { readTileset(rom, it) },
            borderWidth = bytes[0x18].toInt() and 0xFF,
            borderHeight = bytes[0x19].toInt() and 0xFF,
        )
    }

    private suspend fun readTileset(rom: RomAccessor, offset: Long): TilesetData? {
        val size = FireRedMapTables.TILESET_HEADER_SIZE
        if (offset < 0 || offset + size > rom.sizeBytes) return null
        val bytes = rom.read(offset, size)
        if (bytes.size < size) return null
        return TilesetData(
            isCompressed = (bytes[0].toInt() and 0xFF) != 0,
            isSecondary = (bytes[1].toInt() and 0xFF) != 0,
            tilesPointer = GbaGraphics.readPointer32(bytes, 0x04) ?: return null,
            palettesPointer = GbaGraphics.readPointer32(bytes, 0x08) ?: return null,
            metatilesPointer = GbaGraphics.readPointer32(bytes, 0x0C) ?: return null,
            metatileAttributesPointer = GbaGraphics.readPointer32(bytes, 0x14) ?: 0L,
        )
    }

    private suspend fun readEvents(rom: RomAccessor, offset: Long): MapEventsData? {
        val size = FireRedMapTables.MAP_EVENTS_SIZE
        if (offset < 0 || offset + size > rom.sizeBytes) return null
        val header = rom.read(offset, size)
        if (header.size < size) return null
        val objectCount = header[0].toInt() and 0xFF
        val warpCount = header[1].toInt() and 0xFF
        val coordCount = header[2].toInt() and 0xFF
        val bgCount = header[3].toInt() and 0xFF
        val objectEventsPtr = GbaGraphics.readPointer32(header, 0x04)
        val warpsPtr = GbaGraphics.readPointer32(header, 0x08)
        val coordEventsPtr = GbaGraphics.readPointer32(header, 0x0C)
        val bgEventsPtr = GbaGraphics.readPointer32(header, 0x10)

        return MapEventsData(
            objectEvents = if (objectCount > 0 && objectEventsPtr != null) readObjectEvents(rom, objectEventsPtr, objectCount) else emptyList(),
            warps = if (warpCount > 0 && warpsPtr != null) readWarps(rom, warpsPtr, warpCount) else emptyList(),
            coordEvents = if (coordCount > 0 && coordEventsPtr != null) readCoordEvents(rom, coordEventsPtr, coordCount) else emptyList(),
            bgEvents = if (bgCount > 0 && bgEventsPtr != null) readBgEvents(rom, bgEventsPtr, bgCount) else emptyList(),
        )
    }

    private suspend fun readObjectEvents(rom: RomAccessor, offset: Long, count: Int): List<ObjectEventData> {
        val size = FireRedMapTables.OBJECT_EVENT_SIZE
        val total = size * count
        if (offset < 0 || offset + total > rom.sizeBytes) return emptyList()
        val bytes = rom.read(offset, total)
        return (0 until count).mapNotNull { i ->
            val base = i * size
            if (base + size > bytes.size) return@mapNotNull null
            val movementPacked = readU16(bytes, base + 0x0A)
            ObjectEventData(
                index = i,
                localId = bytes[base].toInt() and 0xFF,
                graphicsId = bytes[base + 1].toInt() and 0xFF,
                kind = bytes[base + 2].toInt() and 0xFF,
                x = readS16(bytes, base + 0x04),
                y = readS16(bytes, base + 0x06),
                elevation = bytes[base + 0x08].toInt() and 0xFF,
                movementType = bytes[base + 0x09].toInt() and 0xFF,
                movementRangeX = movementPacked and 0xF,
                movementRangeY = (movementPacked shr 4) and 0xF,
                trainerType = readU16(bytes, base + 0x0C),
                trainerRangeOrBerryTreeId = readU16(bytes, base + 0x0E),
                scriptPointer = GbaGraphics.readPointer32(bytes, base + 0x10) ?: 0L,
                flagId = readU16(bytes, base + 0x14),
                romOffset = offset + base,
            )
        }
    }

    private suspend fun readWarps(rom: RomAccessor, offset: Long, count: Int): List<WarpEventData> {
        val size = FireRedMapTables.WARP_EVENT_SIZE
        val total = size * count
        if (offset < 0 || offset + total > rom.sizeBytes) return emptyList()
        val bytes = rom.read(offset, total)
        return (0 until count).mapNotNull { i ->
            val base = i * size
            if (base + size > bytes.size) return@mapNotNull null
            WarpEventData(
                index = i,
                x = readS16(bytes, base + 0x00),
                y = readS16(bytes, base + 0x02),
                elevation = bytes[base + 0x04].toInt() and 0xFF,
                warpId = bytes[base + 0x05].toInt() and 0xFF,
                destinationMapNum = bytes[base + 0x06].toInt() and 0xFF,
                destinationMapGroup = bytes[base + 0x07].toInt() and 0xFF,
                romOffset = offset + base,
            )
        }
    }

    private suspend fun readCoordEvents(rom: RomAccessor, offset: Long, count: Int): List<CoordEventData> {
        val size = FireRedMapTables.COORD_EVENT_SIZE
        val total = size * count
        if (offset < 0 || offset + total > rom.sizeBytes) return emptyList()
        val bytes = rom.read(offset, total)
        return (0 until count).mapNotNull { i ->
            val base = i * size
            if (base + size > bytes.size) return@mapNotNull null
            CoordEventData(
                index = i,
                x = readU16(bytes, base + 0x00),
                y = readU16(bytes, base + 0x02),
                elevation = bytes[base + 0x04].toInt() and 0xFF,
                varOrTrigger = readU16(bytes, base + 0x06),
                valueOrIndex = readU16(bytes, base + 0x08),
                scriptPointer = GbaGraphics.readPointer32(bytes, base + 0x0C) ?: 0L,
                romOffset = offset + base,
            )
        }
    }

    private suspend fun readBgEvents(rom: RomAccessor, offset: Long, count: Int): List<BgEventData> {
        val size = FireRedMapTables.BG_EVENT_SIZE
        val total = size * count
        if (offset < 0 || offset + total > rom.sizeBytes) return emptyList()
        val bytes = rom.read(offset, total)
        return (0 until count).mapNotNull { i ->
            val base = i * size
            if (base + size > bytes.size) return@mapNotNull null
            BgEventData(
                index = i,
                x = readU16(bytes, base + 0x00),
                y = readU16(bytes, base + 0x02),
                elevation = bytes[base + 0x04].toInt() and 0xFF,
                kind = bytes[base + 0x05].toInt() and 0xFF,
                scriptPointerOrHiddenItem = readU32(bytes, base + 0x08),
                romOffset = offset + base,
            )
        }
    }

    private suspend fun readConnections(rom: RomAccessor, offset: Long): List<MapConnectionData> {
        if (offset < 0 || offset + 8 > rom.sizeBytes) return emptyList()
        val header = rom.read(offset, 8)
        if (header.size < 8) return emptyList()
        val count = readS32(header, 0).coerceIn(0, 16) // sanity bound — FireRed maps have at most 4 cardinal-direction connections in practice
        val listPointer = GbaGraphics.readPointer32(header, 4) ?: return emptyList()
        val size = FireRedMapTables.MAP_CONNECTION_SIZE
        val total = size * count
        if (listPointer < 0 || listPointer + total > rom.sizeBytes) return emptyList()
        val bytes = rom.read(listPointer, total)
        return (0 until count).mapNotNull { i ->
            val base = i * size
            if (base + size > bytes.size) return@mapNotNull null
            MapConnectionData(
                direction = bytes[base].toInt() and 0xFF,
                offset = readS32(bytes, base + 0x04),
                mapGroup = bytes[base + 0x08].toInt() and 0xFF,
                mapNum = bytes[base + 0x09].toInt() and 0xFF,
            )
        }
    }

    private fun readU16(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun readS16(bytes: ByteArray, offset: Int): Int = readU16(bytes, offset).toShort().toInt()

    private fun readU32(bytes: ByteArray, offset: Int): Long =
        (bytes[offset].toLong() and 0xFF) or ((bytes[offset + 1].toLong() and 0xFF) shl 8) or
            ((bytes[offset + 2].toLong() and 0xFF) shl 16) or ((bytes[offset + 3].toLong() and 0xFF) shl 24)

    private fun readS32(bytes: ByteArray, offset: Int): Int = readU32(bytes, offset).toInt()
}
