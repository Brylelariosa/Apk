package com.romexplorer.gba.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val AppTypography = Typography(
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
        letterSpacing = 0.5.sp,
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 22.sp,
        lineHeight = 28.sp,
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.5.sp,
    ),
)

/** Maps a [com.romexplorer.gba.core.analysis.model.RegionType] to its display color.
 * Kept here alongside typography since both are pure presentation concerns. */
fun regionColor(type: com.romexplorer.gba.core.analysis.model.RegionType): androidx.compose.ui.graphics.Color =
    when (type) {
        com.romexplorer.gba.core.analysis.model.RegionType.HEADER -> RegionHeader
        com.romexplorer.gba.core.analysis.model.RegionType.POKEMON_SPECIES -> RegionPokemonSpecies
        com.romexplorer.gba.core.analysis.model.RegionType.POKEMON_MOVES -> RegionPokemonMoves
        com.romexplorer.gba.core.analysis.model.RegionType.POKEMON_ITEMS -> RegionPokemonItems
        com.romexplorer.gba.core.analysis.model.RegionType.POKEMON_TRAINERS -> RegionPokemonTrainers
        com.romexplorer.gba.core.analysis.model.RegionType.ARM_CODE -> RegionArmCode
        com.romexplorer.gba.core.analysis.model.RegionType.THUMB_CODE -> RegionThumbCode
        com.romexplorer.gba.core.analysis.model.RegionType.GRAPHICS -> RegionGraphics
        com.romexplorer.gba.core.analysis.model.RegionType.PALETTE -> RegionPalette
        com.romexplorer.gba.core.analysis.model.RegionType.TILEMAP -> RegionTilemap
        com.romexplorer.gba.core.analysis.model.RegionType.MUSIC -> RegionMusic
        com.romexplorer.gba.core.analysis.model.RegionType.TEXT -> RegionText
        com.romexplorer.gba.core.analysis.model.RegionType.POINTER_TABLE -> RegionPointerTable
        com.romexplorer.gba.core.analysis.model.RegionType.COMPRESSED -> RegionCompressed
        com.romexplorer.gba.core.analysis.model.RegionType.FREE_SPACE -> RegionFreeSpace
        com.romexplorer.gba.core.analysis.model.RegionType.UNKNOWN -> RegionUnknown
    }
