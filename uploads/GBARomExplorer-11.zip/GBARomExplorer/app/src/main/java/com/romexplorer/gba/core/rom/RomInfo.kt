package com.romexplorer.gba.core.rom

/**
 * Aggregate, UI-facing snapshot of everything known about a loaded ROM.
 * [hashes] and [saveType] are filled in asynchronously after [header] since
 * they require a full-file scan; [RomInfo] is immutable, so the ViewModel
 * holds a nullable-hash/save-type version until those finish and then
 * republishes a new copy.
 */
data class RomInfo(
    val displayName: String,
    val header: RomHeader,
    val warnings: List<RomWarning>,
    val hashes: RomHashes? = null,
    val saveType: SaveType? = null,
)
