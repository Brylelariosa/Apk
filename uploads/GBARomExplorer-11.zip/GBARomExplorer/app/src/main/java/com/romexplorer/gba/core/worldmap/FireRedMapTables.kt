package com.romexplorer.gba.core.worldmap

/**
 * ROM-wide layout for Pokémon FireRed's world map data — a completely
 * separate part of the ROM from anything in
 * [com.romexplorer.gba.core.pokemon.FireRedTables] (species/moves/items/
 * trainers), reached through its own pointer table rather than a
 * fixed-offset array of same-size structs.
 *
 * - Map bank/group pointer table (offset 0x3526A8): each 4-byte entry
 *   points to one bank's own array of map-header pointers — one more
 *   level of indirection, `bank -> (map number -> header)`. Community-
 *   documented with a worked, independently-reproducible example: bank 3,
 *   map 0 (Pallet Town) resolves to a map header at 0x350618, and that
 *   source's own byte-by-byte breakdown of the header at that address
 *   matches struct MapHeader's field order below exactly.
 * - Map names pointer table (offset 0x3F1CAC): each 4-byte entry is a
 *   pointer to a Pokémon-text-encoded, 0xFF-terminated location name
 *   ("PALLET TOWN", "ROUTE 1", ...), indexed by a map header's own
 *   `regionMapSectionId` byte — unlike every other name table this file
 *   documents, this one is sourced from a single 2010 PokéCommunity
 *   research thread (id #212492: reverse-engineered via Advance Map's
 *   World Editor, worked example "index 0 -> bytes FC EC 3E 08 -> decodes
 *   to PALLET TOWN"), not corroborated by a second independent source the
 *   way the rest of this file's offsets are. [MapNameReader] therefore
 *   verifies that worked example against whatever ROM is actually open
 *   before trusting this offset for it, rather than assuming this offset
 *   necessarily carries over correctly — see that class's doc.
 * - struct MapHeader (28 bytes), struct MapLayout (map dimensions +
 *   tileset pointers), struct Tileset (graphics/palette/metatile
 *   pointers), struct MapEvents plus its four event sub-structs
 *   (ObjectEventTemplate/WarpEvent/CoordEvent/BgEvent), and struct
 *   MapConnection(s): field layouts copied from `pret/pokefirered`'s own
 *   `include/global.fieldmap.h` — the actual decompiled source used to
 *   build this ROM, the same standard
 *   [com.romexplorer.gba.core.pokemon.FireRedTables] holds its own
 *   trainer-struct citation to. MapHeader and MapLayout are additionally
 *   cross-checked against the community source above, which independently
 *   documents both structs' fields in offset order and agrees with pret's
 *   field order exactly.
 * - Metatile composition (8 x u16 tile entries per 16x16 metatile, two
 *   overlaid 2x2 layers; each u16 = 10-bit tile index + h-flip + v-flip +
 *   4-bit palette number) and the map-data grid's own packing (10-bit
 *   metatile id + 2-bit collision + 4-bit elevation per u16 cell) are
 *   fixed GBA-era Pokémon engine formats, not a FireRed-specific offset
 *   guess — the same class of "hardware/engine format" as
 *   [com.romexplorer.gba.core.graphics.GbaGraphics]. The 512/512 tile and
 *   metatile split between a map's primary and secondary tileset falls
 *   directly out of that 10-bit field's 1024-value range, not a separate
 *   assumption.
 *
 * What ISN'T independently verified here: which of [CoordEventData]'s two
 * trailing u16 fields is "the variable" versus "the value it's compared
 * against". The byte offsets are correct either way — both come from the
 * same struct source above — but the two are exposed under neutral names
 * rather than asserting a mapping this file can't independently confirm.
 */
object FireRedMapTables {
    const val MAP_GROUP_TABLE_OFFSET = 0x3526A8L
    const val MAP_NAMES_POINTER_TABLE_OFFSET = 0x3F1CACL // see class doc — single-sourced, cross-checked at runtime by MapNameReader

    const val MAP_HEADER_SIZE = 0x1C
    const val MAP_LAYOUT_READ_SIZE = 0x1A // through borderHeight — how much this app reads, not the padded struct size
    const val TILESET_HEADER_SIZE = 0x18
    const val MAP_EVENTS_SIZE = 0x14
    const val OBJECT_EVENT_SIZE = 0x18
    const val WARP_EVENT_SIZE = 0x08
    const val COORD_EVENT_SIZE = 0x10
    const val BG_EVENT_SIZE = 0x0C
    const val MAP_CONNECTION_SIZE = 0x0C

    const val METATILE_PIXEL_SIZE = 16
    const val TILE_PIXEL_SIZE = 8
    const val TILES_PER_TILESET_SPACE = 512 // see class doc — half of the 10-bit combined tile-index range
    const val TILE_BYTES_4BPP = 32
    const val PALETTES_PER_TILESET = 16
    const val PALETTE_BYTES = 32

    // Generous safety caps for the self-terminating scans in MapListReader —
    // not verified "true" counts (FireRed doesn't store one anywhere — see
    // that class's doc), just bounds no real FireRed ROM should exceed, so
    // a corrupt or non-FireRed ROM fails closed (returns fewer maps)
    // instead of scanning off into unrelated data forever.
    const val MAX_MAP_GROUPS = 64
    const val MAX_MAPS_PER_GROUP = 128
}
