package com.romexplorer.gba.core.analysis

import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * A single detector that scans a ROM and proposes regions of a particular
 * kind. Each analyzer is independent and unit-testable in isolation — the
 * [AnalysisEngine] is the only thing that knows how to combine them, so a
 * new analyzer never requires touching an existing one.
 */
interface RegionAnalyzer {
    val id: String

    /**
     * Scans [rom] and returns the regions it detected. [onProgress] should be
     * called periodically with a 0f..1f fraction so the engine can combine
     * progress across analyzers; implementations that can't estimate progress
     * may call it only at 0f and 1f.
     */
    suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion>
}

/**
 * Extension point for game-specific analysis (Pokémon, Fire Emblem, etc.).
 * A plugin contributes extra [RegionAnalyzer]s only when it recognizes the
 * ROM's game code, and the core engine never needs to know which plugins
 * exist — see [AnalyzerRegistry]. No plugins ship yet; this interface exists
 * so future game-specific modules (starting with Pokémon) can be added
 * without modifying [AnalysisEngine] or any existing analyzer.
 */
interface GameAnalyzerPlugin {
    val pluginId: String

    /** Whether this plugin has anything useful to contribute for [gameCode]. */
    fun supports(gameCode: String): Boolean

    /** Additional analyzers to run when [supports] returned true. */
    fun analyzersFor(gameCode: String): List<RegionAnalyzer>
}
