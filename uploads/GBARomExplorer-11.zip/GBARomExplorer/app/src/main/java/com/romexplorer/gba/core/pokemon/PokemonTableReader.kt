package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.PokemonTable
import com.romexplorer.gba.core.pokemon.model.TableField
import com.romexplorer.gba.core.pokemon.model.TableRow
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Turns a [KnownTableSchema] plus ROM bytes into parsed [TableRow]s. Every
 * table this reads (species/moves/items/trainers) is at most ~30KB, so each
 * is fetched in one [RomAccessor.read] call rather than chunked.
 */
object PokemonTableReader {

    /**
     * [overlay], if given, is applied on top of the raw ROM bytes before
     * decoding — the same [EditOverlay] the hex editor writes to (see
     * [PokemonTableWriter]) — so a field edited through this table view (or
     * through the hex editor, since they share one overlay per ROM session)
     * shows its new value here too, not the stale on-disk one.
     */
    suspend fun read(rom: RomAccessor, schema: KnownTableSchema, overlay: EditOverlay? = null): PokemonTable {
        val totalSize = schema.totalSizeBytes
        val available = (rom.sizeBytes - schema.romOffset).coerceAtLeast(0)
        val readableEntries = if (available >= totalSize) {
            schema.entryCount
        } else {
            (available / schema.entrySize).toInt().coerceAtLeast(0)
        }
        if (readableEntries <= 0) return PokemonTable(schema, emptyList())

        val bytes = rom.read(schema.romOffset, readableEntries * schema.entrySize)
        overlay?.applyToRange(bytes, schema.romOffset)

        val rows = ArrayList<TableRow>(readableEntries)
        for (entryIndex in 0 until readableEntries) {
            val entryStart = entryIndex * schema.entrySize
            val values = LinkedHashMap<String, Any>(schema.fields.size)
            for (field in schema.fields) {
                values[field.name] = decodeField(bytes, entryStart + field.byteOffset, field)
            }
            rows += TableRow(entryIndex, values)
        }
        return PokemonTable(schema, rows)
    }

    private fun decodeField(bytes: ByteArray, offset: Int, field: TableField): Any {
        if (offset < 0 || offset + field.byteLength > bytes.size) return 0L
        return when (field.kind) {
            FieldKind.UINT8 -> (bytes[offset].toInt() and 0xFF).toLong()
            FieldKind.INT8 -> bytes[offset].toLong() // signed, matches Kotlin Byte's sign-extension
            FieldKind.UINT16 -> readLeUnsigned(bytes, offset, 2)
            FieldKind.UINT24 -> readLeUnsigned(bytes, offset, 3)
            FieldKind.UINT32 -> readLeUnsigned(bytes, offset, 4)
            FieldKind.POINTER32 -> {
                val raw = readLeUnsigned(bytes, offset, 4)
                if (raw in 0x08000000L..0x09FFFFFFL) raw - 0x08000000L else raw
            }
            FieldKind.POKEMON_STRING -> PokemonTextCodec.decode(bytes, offset, field.byteLength)
        }
    }

    private fun readLeUnsigned(bytes: ByteArray, offset: Int, length: Int): Long {
        var value = 0L
        for (i in 0 until length) {
            value = value or ((bytes[offset + i].toLong() and 0xFF) shl (8 * i))
        }
        return value
    }
}
