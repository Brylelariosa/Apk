package com.romexplorer.gba.core.rom

import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * [RomAccessor] backed by a [ParcelFileDescriptor] obtained from the Storage
 * Access Framework. Uses [FileChannel]'s positional read overload, which
 * takes an explicit offset and does not mutate a shared file-position, so it
 * is safe to call concurrently from multiple coroutines (hex editor paging
 * alongside a background analyzer, for example) without external locking.
 */
class FileChannelRomAccessor(
    private val pfd: ParcelFileDescriptor,
) : RomAccessor {

    private val stream = FileInputStream(pfd.fileDescriptor)
    private val channel: FileChannel = stream.channel

    override val sizeBytes: Long = channel.size()

    override suspend fun read(romOffset: Long, length: Int): ByteArray = withContext(Dispatchers.IO) {
        val buffer = ByteArray(length)
        val n = readIntoBlocking(buffer, romOffset, length)
        if (n == length) buffer else buffer.copyOf(n.coerceAtLeast(0))
    }

    override suspend fun readInto(buffer: ByteArray, romOffset: Long, length: Int): Int =
        withContext(Dispatchers.IO) { readIntoBlocking(buffer, romOffset, length) }

    override suspend fun readByte(romOffset: Long): Int {
        if (romOffset < 0 || romOffset >= sizeBytes) return -1
        val b = read(romOffset, 1)
        return if (b.isEmpty()) -1 else b[0].toInt() and 0xFF
    }

    /** Loops on the positional read until [length] bytes are gathered or EOF is hit. */
    private fun readIntoBlocking(buffer: ByteArray, romOffset: Long, length: Int): Int {
        if (romOffset >= sizeBytes || length <= 0) return 0
        var totalRead = 0
        while (totalRead < length) {
            val remaining = length - totalRead
            val byteBuffer = ByteBuffer.wrap(buffer, totalRead, remaining)
            val n = channel.read(byteBuffer, romOffset + totalRead)
            if (n <= 0) break
            totalRead += n
        }
        return totalRead
    }

    override fun close() {
        runCatching { stream.close() }
        runCatching { pfd.close() }
    }
}
