package com.romexplorer.gba.data.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

@Serializable
data class RecentRomEntry(
    val uri: String,
    val displayName: String,
    val lastOpenedEpochMillis: Long,
)

/** Persists the list of recently-opened ROMs (by SAF URI) across app restarts. */
class RecentRomsRepository(private val context: Context) {

    private val key = stringPreferencesKey("recent_roms_json")
    private val json = Json { ignoreUnknownKeys = true }
    private val listSerializer = ListSerializer(RecentRomEntry.serializer())
    private val maxEntries = 20

    val recents: Flow<List<RecentRomEntry>> = context.appDataStore.data.map { prefs ->
        decode(prefs[key])
    }

    suspend fun recordOpened(uri: String, displayName: String) {
        context.appDataStore.edit { prefs ->
            val current = decode(prefs[key]).filterNot { it.uri == uri }
            val updated = (listOf(RecentRomEntry(uri, displayName, System.currentTimeMillis())) + current)
                .take(maxEntries)
            prefs[key] = json.encodeToString(listSerializer, updated)
        }
    }

    suspend fun remove(uri: String) {
        context.appDataStore.edit { prefs ->
            val current = decode(prefs[key]).filterNot { it.uri == uri }
            prefs[key] = json.encodeToString(listSerializer, current)
        }
    }

    private fun decode(raw: String?): List<RecentRomEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        return runCatching { json.decodeFromString(listSerializer, raw) }.getOrDefault(emptyList())
    }
}
