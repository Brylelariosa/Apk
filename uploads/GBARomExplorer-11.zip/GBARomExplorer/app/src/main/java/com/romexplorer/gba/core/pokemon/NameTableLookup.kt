package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Reads a flat array of fixed-length, proprietary-encoded name strings — the
 * format FireRed uses for species and move names. Unlike items and trainers,
 * whose names are embedded fields within a larger per-entry struct (see
 * [FireRedTables.items], [FireRedTables.trainers]), species and move data
 * have no name field at all; the names live in their own separate table,
 * indexed the same way as the data table they describe.
 *
 * Mirrors [PokemonTableReader]'s bounds-safe, single-read-per-table approach.
 */
object NameTableLookup {
    suspend fun build(rom: RomAccessor, romOffset: Long, entryLength: Int, count: Int): Map<Int, String> {
        val totalSize = entryLength.toLong() * count
        val available = (rom.sizeBytes - romOffset).coerceAtLeast(0)
        val readableEntries = if (available >= totalSize) count else (available / entryLength).toInt().coerceAtLeast(0)
        if (readableEntries <= 0) return emptyMap()

        val bytes = rom.read(romOffset, readableEntries * entryLength)
        return (0 until readableEntries).associateWith { index ->
            PokemonTextCodec.decode(bytes, index * entryLength, entryLength)
        }
    }
}
