package com.romexplorer.gba.core.analysis.analyzers

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor

/** Always claims the fixed 0x00-0xC0 header range with full confidence. */
class HeaderRegionAnalyzer : RegionAnalyzer {
    override val id: String = "header"

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        onProgress(0f)
        val size = minOf(0xC0L, rom.sizeBytes)
        onProgress(1f)
        if (size <= 0) return emptyList()
        return listOf(RomRegion(0L, size, RegionType.HEADER, confidence = 1f))
    }
}
