package com.romexplorer.gba

import android.app.Application
import com.romexplorer.gba.di.appModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin

class GbaRomExplorerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        startKoin {
            androidContext(this@GbaRomExplorerApp)
            modules(appModule)
        }
    }
}
