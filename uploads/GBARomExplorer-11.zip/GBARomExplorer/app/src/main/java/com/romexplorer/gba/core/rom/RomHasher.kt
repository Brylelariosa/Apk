package com.romexplorer.gba.core.rom

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.zip.CRC32

data class RomHashes(
    val crc32: String,
    val md5: String,
    val sha1: String,
)

sealed class HashProgress {
    data class InProgress(val fraction: Float) : HashProgress()
    data class Done(val hashes: RomHashes) : HashProgress()
}

/**
 * Computes CRC32/MD5/SHA-1 over a ROM in a single streaming pass so a 64MB
 * file never needs to be loaded into memory at once. All three digests are
 * updated together per chunk to avoid re-reading the file three times.
 */
object RomHasher {

    private const val CHUNK_SIZE = 1 shl 20 // 1MB
    private const val QUICK_SAMPLE_SIZE = 1 shl 16 // 64KB

    /**
     * A fast, good-enough-to-tell-two-ROMs-apart fingerprint: CRC32 over
     * the first and last [QUICK_SAMPLE_SIZE] bytes, combined with the
     * file's own size — one or two small reads, not a multi-second
     * streaming pass over the whole ROM like [hashWithProgress]. Sampling
     * both ends rather than just the start matters here specifically
     * because this app's own writers ([com.romexplorer.gba.core.common.FreeSpaceAllocator])
     * place new data in free space, which tends to be later in the file —
     * exactly where a previously-edited-and-exported ROM would differ from
     * a fresh vanilla one, potentially with an identical first 64KB.
     *
     * Used to key edit drafts ([EditDraftRepository]) instead of the
     * content URI alone: a URI is stable per file-picker *selection*, not
     * per file *content* — picking a different ROM from the same on-disk
     * location (a common case: replacing a file, or a document provider
     * that reuses URIs for a given slot) can return the exact same URI
     * string for genuinely different bytes. Keying drafts by URI alone
     * means a stale draft — someone else's edits, or last session's — can
     * silently reapply itself onto an unrelated ROM's real data instead of
     * this app ever noticing the two don't match.
     */
    suspend fun quickFingerprint(rom: RomAccessor): String = withContext(Dispatchers.IO) {
        val size = rom.sizeBytes
        val head = rom.read(0, minOf(QUICK_SAMPLE_SIZE.toLong(), size).toInt())
        val crc = CRC32()
        crc.update(head)
        if (size > QUICK_SAMPLE_SIZE) {
            val tailStart = size - QUICK_SAMPLE_SIZE
            val tail = rom.read(tailStart, QUICK_SAMPLE_SIZE)
            crc.update(tail)
        }
        "${size}_${crc.value.toString(16).uppercase().padStart(8, '0')}"
    }

    fun hashWithProgress(rom: RomAccessor) = flow {
        val crc = CRC32()
        val md5 = MessageDigest.getInstance("MD5")
        val sha1 = MessageDigest.getInstance("SHA-1")
        val buffer = ByteArray(CHUNK_SIZE)

        var offset = 0L
        val total = rom.sizeBytes.coerceAtLeast(1)

        while (offset < rom.sizeBytes) {
            val length = minOf(CHUNK_SIZE.toLong(), rom.sizeBytes - offset).toInt()
            val n = withContext(Dispatchers.IO) { rom.readInto(buffer, offset, length) }
            if (n <= 0) break
            crc.update(buffer, 0, n)
            md5.update(buffer, 0, n)
            sha1.update(buffer, 0, n)
            offset += n
            emit(HashProgress.InProgress(offset.toFloat() / total.toFloat()))
        }

        val hashes = RomHashes(
            crc32 = crc.value.toString(16).uppercase().padStart(8, '0'),
            md5 = md5.digest().toHex(),
            sha1 = sha1.digest().toHex(),
        )
        emit(HashProgress.Done(hashes))
    }

    private fun ByteArray.toHex(): String =
        joinToString("") { "%02X".format(it) }
}
