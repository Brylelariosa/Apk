@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.pokescript

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.ui.common.ErrorBanner
import org.koin.androidx.compose.koinViewModel

/** [ownerFieldOffset] below this means "no owner to repoint" — see [ScriptViewerScreen]'s doc. */
const val NO_SCRIPT_OWNER = -1L

/**
 * Views (and, when reached from a real map event, edits) one script's real,
 * disassembled bytes — see [ScriptViewerViewModel].
 *
 * [ownerFieldOffset] is [NO_SCRIPT_OWNER] when this screen was opened
 * without a specific field to repoint if the script grows (e.g. a
 * standalone "view the bytes at this offset" entry point rather than one
 * reached by tapping a specific map event's script) — in that case editing
 * is disabled rather than risk writing a script nothing in the ROM
 * actually points at.
 */
@Composable
fun ScriptViewerScreen(
    navController: NavHostController,
    scriptOffset: Long,
    ownerFieldOffset: Long,
    viewModel: ScriptViewerViewModel = koinViewModel(),
) {
    LaunchedEffect(scriptOffset) { viewModel.load(scriptOffset) }
    val state by viewModel.state.collectAsState()
    val saveState by viewModel.saveState.collectAsState()
    var editedText by remember(state) { mutableStateOf((state as? ScriptViewerState.Loaded)?.text.orEmpty()) }
    val readOnly = ownerFieldOffset < 0

    LaunchedEffect(saveState) {
        if (saveState is SaveState.Saved) {
            viewModel.load(scriptOffset) // reload so the editor shows exactly what was just written, as the new source of truth
            viewModel.resetSaveState()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Script @ 0x${scriptOffset.toString(16).uppercase()}") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (!readOnly) {
                        TextButton(onClick = { viewModel.save(editedText, ownerFieldOffset) }, enabled = saveState !is SaveState.Saving) {
                            Text(if (saveState is SaveState.Saving) "Saving…" else "Save")
                        }
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            if (readOnly) {
                Text(
                    "Opened directly, not linked to a specific map event — read-only, since there's nowhere to repoint to if an edited script grows. Open a script from Map Explorer's event list to edit it.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }
            when (val current = state) {
                is ScriptViewerState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                is ScriptViewerState.Failed -> ErrorBanner(current.message)
                is ScriptViewerState.Loaded -> {
                    OutlinedTextField(
                        value = editedText,
                        onValueChange = { editedText = it },
                        readOnly = readOnly,
                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            val currentSaveState = saveState
            if (currentSaveState is SaveState.Failed) {
                Spacer(Modifier.height(8.dp))
                ErrorBanner(currentSaveState.message)
            }
        }
    }
}
