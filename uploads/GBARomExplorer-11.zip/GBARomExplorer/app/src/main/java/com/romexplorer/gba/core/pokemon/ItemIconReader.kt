package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.graphics.GbaGraphics
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Decodes an item's 24x24 icon (the one shown in the bag, on the ground, in
 * shop menus). A table at 0x3D4294 holds one 8-byte entry per item: a
 * 4-byte pointer to the icon's tile data, then a 4-byte pointer to its
 * 16-color palette — this pairing is a standard, widely-used layout in
 * this game's engine (mirrors how sprite+palette pairs work elsewhere,
 * e.g. trainer pics, see [TrainerSpriteReader]).
 *
 * Confidence note: the table offset (0x3D4294) and per-entry size (8 bytes)
 * come from one community ROM-offset reference (not independently
 * cross-checked the way [FireRedTables]' data tables are), and whether the
 * palette pointer specifically is LZ77-compressed or raw isn't confirmed —
 * [GbaGraphics.readPossiblyCompressed] handles both, but it's a real
 * unknown, not just defensive boilerplate. If item icons don't render
 * right, this offset is the first thing to double-check.
 */
object ItemIconReader {
    private const val TABLE_OFFSET = 0x3D4294L
    private const val ENTRY_SIZE = 8
    private const val ICON_WIDTH_PX = 24
    private const val ICON_HEIGHT_PX = 24
    private const val IMAGE_BYTES = ICON_WIDTH_PX * ICON_HEIGHT_PX / 2 // 288
    private const val PALETTE_BYTES = 32

    suspend fun read(rom: RomAccessor, itemIndex: Int): DecodedImage? {
        if (itemIndex < 0) return null

        val entry = rom.read(TABLE_OFFSET + itemIndex * ENTRY_SIZE.toLong(), ENTRY_SIZE)
        if (entry.size < ENTRY_SIZE) return null
        val imagePointer = GbaGraphics.readPointer32(entry, 0) ?: return null
        val palettePointer = GbaGraphics.readPointer32(entry, 4) ?: return null

        val imageBytes = GbaGraphics.readPossiblyCompressed(rom, imagePointer, IMAGE_BYTES) ?: return null
        val paletteBytes = GbaGraphics.readPossiblyCompressed(rom, palettePointer, PALETTE_BYTES) ?: return null

        val palette = GbaGraphics.decodePalette(paletteBytes)
        val pixels = GbaGraphics.decode4bpp(imageBytes, palette, ICON_WIDTH_PX, ICON_HEIGHT_PX)
        return DecodedImage(ICON_WIDTH_PX, ICON_HEIGHT_PX, pixels)
    }
}
