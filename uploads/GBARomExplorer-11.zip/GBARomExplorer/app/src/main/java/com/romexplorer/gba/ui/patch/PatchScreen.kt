@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.patch

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.ui.common.SectionHeader
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatchScreen(navController: NavHostController, viewModel: PatchViewModel = koinViewModel()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Patch Tool (IPS)") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text(
                    "UPS and BPS formats are on the roadmap; IPS create/apply/verify is fully supported today.",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            item { CreatePatchSection(viewModel) }
            item { ApplyPatchSection(viewModel) }
            item { VerifyPatchSection(viewModel) }
        }
    }
}

@Composable
private fun CreatePatchSection(viewModel: PatchViewModel) {
    val state by viewModel.createState.collectAsState()
    var original by remember { mutableStateOf<Uri?>(null) }
    var modified by remember { mutableStateOf<Uri?>(null) }

    val originalPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { original = it }
    val modifiedPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { modified = it }
    val destinationPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { dest ->
        val o = original
        val m = modified
        if (dest != null && o != null && m != null) viewModel.createPatch(o, m, dest)
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            SectionHeader("Create Patch")
            Text("Diff an original ROM against a modified copy to produce an .ips patch.")
            PickerRow("1. Original ROM", original != null) { originalPicker.launch(arrayOf("*/*")) }
            PickerRow("2. Modified ROM", modified != null) { modifiedPicker.launch(arrayOf("*/*")) }
            Button(
                onClick = { destinationPicker.launch("patch.ips") },
                enabled = original != null && modified != null,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("Create Patch…") }
            PatchStateText(state)
        }
    }
}

@Composable
private fun ApplyPatchSection(viewModel: PatchViewModel) {
    val state by viewModel.applyState.collectAsState()
    var original by remember { mutableStateOf<Uri?>(null) }
    var patch by remember { mutableStateOf<Uri?>(null) }

    val originalPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { original = it }
    val patchPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { patch = it }
    val destinationPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { dest ->
        val o = original
        val p = patch
        if (dest != null && o != null && p != null) viewModel.applyPatch(o, p, dest)
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            SectionHeader("Apply Patch")
            Text("Apply an .ips patch to an original ROM to produce the patched ROM.")
            PickerRow("1. Original ROM", original != null) { originalPicker.launch(arrayOf("*/*")) }
            PickerRow("2. Patch file (.ips)", patch != null) { patchPicker.launch(arrayOf("*/*")) }
            Button(
                onClick = { destinationPicker.launch("patched.gba") },
                enabled = original != null && patch != null,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("Apply Patch…") }
            PatchStateText(state)
        }
    }
}

@Composable
private fun VerifyPatchSection(viewModel: PatchViewModel) {
    val state by viewModel.verifyState.collectAsState()
    var original by remember { mutableStateOf<Uri?>(null) }
    var patch by remember { mutableStateOf<Uri?>(null) }

    val originalPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { original = it }
    val patchPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { patch = it }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            SectionHeader("Verify Patch")
            Text("Apply a patch in memory and report the resulting size and SHA-1, without writing a file — useful for checking a patch against a known-good checksum first.")
            PickerRow("1. Original ROM", original != null) { originalPicker.launch(arrayOf("*/*")) }
            PickerRow("2. Patch file (.ips)", patch != null) { patchPicker.launch(arrayOf("*/*")) }
            Button(
                onClick = { val o = original; val p = patch; if (o != null && p != null) viewModel.verifyPatch(o, p) },
                enabled = original != null && patch != null,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            ) { Text("Verify") }
            PatchStateText(state)
        }
    }
}

@Composable
private fun PickerRow(label: String, picked: Boolean, onClick: () -> Unit) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
            Text(if (picked) "$label ✓ selected" else "$label — choose file")
        }
    }
}

@Composable
private fun PatchStateText(state: PatchOpState) {
    when (state) {
        is PatchOpState.Idle -> {}
        is PatchOpState.Running -> {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                CircularProgressIndicator(modifier = Modifier.padding(bottom = 4.dp))
                Text("Working…")
            }
        }
        is PatchOpState.Success -> Text(state.message, modifier = Modifier.padding(top = 8.dp))
        is PatchOpState.Failure -> Text(
            state.message,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}
