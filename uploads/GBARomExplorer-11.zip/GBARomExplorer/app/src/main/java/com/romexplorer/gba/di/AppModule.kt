package com.romexplorer.gba.di

import com.romexplorer.gba.core.analysis.AnalysisEngine
import com.romexplorer.gba.core.analysis.AnalyzerRegistry
import com.romexplorer.gba.core.analysis.RomMapCache
import com.romexplorer.gba.core.pokemon.FireRedGamePlugin
import com.romexplorer.gba.data.repository.BookmarksRepository
import com.romexplorer.gba.data.repository.CustomTypeNamesRepository
import com.romexplorer.gba.data.repository.EditDraftRepository
import com.romexplorer.gba.data.repository.FavoritesRepository
import com.romexplorer.gba.data.repository.RecentRomsRepository
import com.romexplorer.gba.data.repository.RomSessionManager
import com.romexplorer.gba.domain.usecase.ExportReportUseCase
import com.romexplorer.gba.domain.usecase.PatchOperationsUseCase
import com.romexplorer.gba.domain.usecase.RomExpansionUseCase
import com.romexplorer.gba.ui.analyzer.AnalyzerViewModel
import com.romexplorer.gba.ui.hexeditor.HexEditorViewModel
import com.romexplorer.gba.ui.home.HomeViewModel
import com.romexplorer.gba.ui.mapexplorer.MapExplorerViewModel
import com.romexplorer.gba.ui.patch.PatchViewModel
import com.romexplorer.gba.ui.pokemontables.PokemonTableViewModel
import com.romexplorer.gba.ui.pokescript.ScriptViewerViewModel
import com.romexplorer.gba.ui.rominfo.RomInfoViewModel
import com.romexplorer.gba.ui.rommap.RomMapViewModel
import com.romexplorer.gba.ui.romexpansion.RomExpansionViewModel
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

/**
 * Single Koin module for the whole app. Kept flat and in one file since the
 * dependency graph is small; if this grows, split by layer (coreModule /
 * dataModule / uiModule) without changing how callers install it.
 */
val appModule = module {

    // Core analysis
    single {
        AnalyzerRegistry().apply {
            register(FireRedGamePlugin())
        }
    }
    single { AnalysisEngine(registry = get()) }
    single { RomMapCache(cacheDir = get<android.content.Context>().cacheDir) }

    // Data / repositories
    single { RecentRomsRepository(get()) }
    single { FavoritesRepository(get()) }
    single { BookmarksRepository(get()) }
    single { EditDraftRepository(get()) }
    single { CustomTypeNamesRepository(get()) }
    single { RomSessionManager(get(), get(), get(), get(), get()) }
    single { ExportReportUseCase(get()) }
    single { PatchOperationsUseCase(get()) }
    single { RomExpansionUseCase(get(), get()) }

    // ViewModels
    viewModel { HomeViewModel(get(), get(), get()) }
    viewModel { RomInfoViewModel(get(), get()) }
    viewModel { HexEditorViewModel(get(), get()) }
    viewModel { RomMapViewModel(get()) }
    viewModel { AnalyzerViewModel(get(), get()) }
    viewModel { PatchViewModel(get()) }
    viewModel { PokemonTableViewModel(get(), get()) }
    viewModel { MapExplorerViewModel(get()) }
    viewModel { ScriptViewerViewModel(get()) }
    viewModel { RomExpansionViewModel(get()) }
}
