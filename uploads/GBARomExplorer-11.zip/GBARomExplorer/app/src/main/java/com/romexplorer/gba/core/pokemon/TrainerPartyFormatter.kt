package com.romexplorer.gba.core.pokemon

/**
 * Turns decoded [TrainerPartyMember]s into one display-ready line each,
 * e.g. "Lv.72 Heracross @ Choice Scarf — Megahorn/Earthquake/Close Combat".
 * Pure and Android-free by design, so it's unit-testable without a ROM.
 */
object TrainerPartyFormatter {
    fun format(
        members: List<TrainerPartyMember>,
        speciesNames: Map<Int, String>,
        itemNames: Map<Int, String>,
        moveNames: Map<Int, String>,
    ): List<String> = members.map { member ->
        val species = nameOrFallback(speciesNames, member.species, "Species")
        val itemSuffix = member.heldItem
            ?.takeIf { it != 0 }
            ?.let { " @ " + nameOrFallback(itemNames, it, "Item") }
            .orEmpty()
        val movesSuffix = member.moves
            ?.filter { it != 0 }
            ?.takeIf { it.isNotEmpty() }
            ?.joinToString("/") { nameOrFallback(moveNames, it, "Move") }
            ?.let { " — $it" }
            .orEmpty()
        "Lv.${member.level} $species$itemSuffix$movesSuffix"
    }

    private fun nameOrFallback(names: Map<Int, String>, id: Int, label: String): String =
        names[id]?.takeIf { it.isNotBlank() } ?: "$label #$id"
}
