package com.romexplorer.gba.ui.romexpansion

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.domain.usecase.RomExpansionTarget
import com.romexplorer.gba.domain.usecase.RomExpansionUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ExpansionState {
    data object Idle : ExpansionState()
    data object Expanding : ExpansionState()
    data object Done : ExpansionState()
    data class Failed(val message: String) : ExpansionState()
}

class RomExpansionViewModel(private val useCase: RomExpansionUseCase) : ViewModel() {
    private val _state = MutableStateFlow<ExpansionState>(ExpansionState.Idle)
    val state: StateFlow<ExpansionState> = _state.asStateFlow()

    fun expand(destination: Uri, target: RomExpansionTarget) {
        _state.value = ExpansionState.Expanding
        viewModelScope.launch {
            val result = useCase.expand(destination, target)
            _state.value = result.fold(
                onSuccess = { ExpansionState.Done },
                onFailure = { ExpansionState.Failed(it.message ?: "Couldn't expand this ROM") },
            )
        }
    }
}
