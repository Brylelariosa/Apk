package com.romexplorer.gba.core.common

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Finds a run of free space — bytes already 0xFF, the conventional GBA
 * "unused ROM space" fill value (see
 * [com.romexplorer.gba.core.analysis.analyzers.FreeSpaceAnalyzer], which
 * treats the same value the same way) — large enough to hold newly-grown
 * data, so something that outgrows its original byte range (an edited
 * script, a resized event array, a trainer's resized party) can be
 * relocated instead of overflowing into whatever happens to sit right
 * after it in the ROM.
 *
 * Shared by every feature in this app that can grow ROM data —
 * [com.romexplorer.gba.core.pokescript], [com.romexplorer.gba.core.worldmap],
 * and [com.romexplorer.gba.core.pokemon.TrainerPartyWriter] — rather than
 * each reimplementing its own scan.
 *
 * Deliberately independent of [com.romexplorer.gba.core.analysis.AnalysisEngine]'s
 * full ROM-wide analysis, which is comparatively expensive (and analyzes
 * far more than free space) — this does a narrow, on-demand scan instead,
 * since these allocations happen one at a time as part of an interactive
 * edit, not as a batch analysis pass.
 */
object FreeSpaceAllocator {
    private const val FILL_BYTE = 0xFF
    private const val CHUNK_SIZE = 1 shl 14 // 16 KB per read, to bound memory use while scanning a large ROM

    /**
     * Where [findFreeRun] starts looking by default. FireRed's original,
     * unmodified data — every table, every trainer's party, every map —
     * sits packed well below this address; ROM-hacking tooling generally
     * treats space *above* it as the conventional "safe to write new data
     * here" region for exactly that reason (visible as a real, checked-for
     * convention in the community: hacks are expected to keep their new
     * data "above 0x800000", and hack reviewers explicitly flag ones that
     * don't). [FILL_BYTE] alone isn't a reliable signal of *genuinely*
     * unused space below this address — a real Pokémon's `iv` field is
     * conventionally 0xFFFF, so a scan that starts at byte 0 can and does
     * walk straight through real, packed game data and mistake it for
     * free space. A ROM that hasn't been expanded past this size yet
     * simply has no space [findFreeRun] will find — which is correct:
     * there isn't any safe space to hand out yet, the same way a real
     * hacking workflow expects a ROM to be expanded before new data is
     * added to it.
     */
    const val CONVENTIONAL_SAFE_REGION_START = 0x800000L

    /**
     * Scans from [searchStart] to the end of the ROM for the first run of
     * at least [length] consecutive free bytes, honoring [overlay] (a byte
     * already overwritten by a pending edit — even to another 0xFF — isn't
     * free) and [reservedRanges] (offsets a caller has already claimed
     * earlier in the same operation, before actually writing them via
     * [write]). Returns null if no run is found before the end of the ROM.
     *
     * [searchStart] defaults to [CONVENTIONAL_SAFE_REGION_START] rather
     * than 0 — see that constant's doc. Pass an earlier offset explicitly
     * only with real justification for why the bytes there are safe;
     * [reservedRanges] narrows a search that's already confined to a safe
     * region, it doesn't make searching an unsafe one safe.
     */
    suspend fun findFreeRun(
        rom: RomAccessor,
        overlay: EditOverlay,
        length: Int,
        searchStart: Long = CONVENTIONAL_SAFE_REGION_START,
        reservedRanges: List<LongRange> = emptyList(),
    ): Long? {
        if (length <= 0) return null
        var runStart = -1L
        var offset = searchStart.coerceAtLeast(0L)

        while (offset < rom.sizeBytes) {
            val readLen = minOf(CHUNK_SIZE.toLong(), rom.sizeBytes - offset).toInt()
            val chunk = rom.read(offset, readLen)
            if (chunk.isEmpty()) break
            for (i in chunk.indices) {
                val globalPos = offset + i
                val byteValue = overlay.get(globalPos) ?: (chunk[i].toInt() and 0xFF)
                val isFree = byteValue == FILL_BYTE && reservedRanges.none { globalPos in it }
                if (isFree) {
                    if (runStart == -1L) runStart = globalPos
                    if (globalPos - runStart + 1 >= length) return runStart
                } else {
                    runStart = -1L
                }
            }
            offset += readLen
        }
        return null
    }

    /**
     * Writes [bytes] into the overlay starting at [destination] — the
     * actual "claim" step after [findFreeRun]. Also the general-purpose way
     * every writer in this app touches more than one field at once: pass
     * any raw byte range, not just ones [findFreeRun] found.
     *
     * Atomic: reads every original byte in the destination range up front
     * and only starts mutating [overlay] once all of them check out. A
     * byte-at-a-time version of this that mutated the overlay inside the
     * same loop it validated in could fail partway through a multi-byte
     * write (e.g. mid-write into a party member's 6-12 byte entry) and
     * leave the overlay with some of the new bytes applied and the rest
     * still the old ones, while still reporting failure overall — silently
     * splicing part of a new value into unrelated old bytes rather than
     * either the whole write or none of it.
     */
    suspend fun write(rom: RomAccessor, overlay: EditOverlay, destination: Long, bytes: ByteArray): Boolean {
        if (destination < 0 || destination + bytes.size > rom.sizeBytes) return false
        val originalBytes = rom.read(destination, bytes.size)
        if (originalBytes.size != bytes.size) return false
        for (i in bytes.indices) {
            overlay.setByte(destination + i, bytes[i].toInt() and 0xFF, originalBytes[i].toInt() and 0xFF)
        }
        return true
    }

    /** Little-endian encodes [value] into [length] bytes — the layout every pointer/number field in this ROM uses. */
    fun leBytes(value: Long, length: Int): ByteArray = ByteArray(length) { i -> ((value shr (8 * i)) and 0xFF).toByte() }

    /** Encodes a file offset as a raw 0x08000000-based GBA ROM pointer, the inverse of [com.romexplorer.gba.core.graphics.GbaGraphics.readPointer32]. */
    fun toRomPointer(fileOffset: Long): Long = fileOffset or 0x08000000L
}
