package com.romexplorer.gba.core.pokescript

import java.io.ByteArrayOutputStream

sealed class AssembleResult {
    data class Success(val bytes: ByteArray) : AssembleResult()
    data class Failure(val lineNumber: Int, val message: String) : AssembleResult()
}

/**
 * Parses this app's plain-text pokescript format (see
 * [ScriptTextFormatter]) back into bytes — the exact inverse, so a script
 * this app disassembled, left untouched, and reassembled round-trips to
 * identical bytes (see the round-trip test in this package). Only
 * understands the same commands [ScriptDisassembler] can decode (see
 * [ScriptCommandTable]) — an unrecognized mnemonic, wrong argument count,
 * or unparseable number fails the *whole* assembly with the offending line
 * number, rather than silently writing something different from what the
 * text said.
 */
object ScriptAssembler {
    fun assemble(text: String): AssembleResult {
        val out = ByteArrayOutputStream()
        for ((index, rawLine) in text.lines().withIndex()) {
            val lineNumber = index + 1
            val line = rawLine.substringBefore("//").trim()
            if (line.isEmpty()) continue

            val tokens = line.split(Regex("\\s+"))
            val mnemonic = tokens[0]
            val argTokens = tokens.drop(1)
            val command = ScriptCommandTable.byMnemonic[mnemonic]
                ?: return AssembleResult.Failure(lineNumber, "Unknown command \"$mnemonic\"")

            val types = when (val spec = command.args) {
                is ArgSpec.Fixed -> spec.args
                ArgSpec.TrainerBattle -> {
                    val battleType = argTokens.getOrNull(0)?.let(::parseNumberOrNull)
                        ?: return AssembleResult.Failure(lineNumber, "trainerbattle needs a battle type as its first argument")
                    TrainerBattleShapes.argsFor(battleType.toInt())
                        ?: return AssembleResult.Failure(lineNumber, "Battle type $battleType isn't a shape this app can assemble — see TrainerBattleShapes")
                }
                ArgSpec.Unknown -> return AssembleResult.Failure(
                    lineNumber,
                    "\"$mnemonic\" is a real command but this app doesn't have a verified argument layout for it, so it can't be assembled",
                )
            }

            if (argTokens.size != types.size) {
                return AssembleResult.Failure(lineNumber, "\"$mnemonic\" needs ${types.size} argument(s), got ${argTokens.size}")
            }

            out.write(command.opcode)
            for ((i, type) in types.withIndex()) {
                val value = parseNumberOrNull(argTokens[i])
                    ?: return AssembleResult.Failure(lineNumber, "\"${argTokens[i]}\" isn't a valid number")
                writeLittleEndian(out, value, type.byteLength)
            }
        }
        return AssembleResult.Success(out.toByteArray())
    }

    private fun parseNumberOrNull(token: String): Long? =
        if (token.startsWith("0x", ignoreCase = true)) token.substring(2).toLongOrNull(16) else token.toLongOrNull()

    private fun writeLittleEndian(out: ByteArrayOutputStream, value: Long, length: Int) {
        for (i in 0 until length) out.write(((value shr (8 * i)) and 0xFF).toInt())
    }
}
