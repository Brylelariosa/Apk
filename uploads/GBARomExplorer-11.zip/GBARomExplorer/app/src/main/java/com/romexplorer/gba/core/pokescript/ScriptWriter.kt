package com.romexplorer.gba.core.pokescript

import com.romexplorer.gba.core.common.FreeSpaceAllocator
import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Writes an edited, reassembled script (see [ScriptAssembler]) back to the
 * ROM by relocating it to a fresh block of free space (see
 * [FreeSpaceAllocator]) and repointing whatever referenced it — a map
 * event's own `script` field, most commonly — to the new location.
 *
 * [ownerPointerFieldOffset] is the file offset of that pointer *field*
 * itself (e.g. an [com.romexplorer.gba.core.worldmap.ObjectEventData]'s
 * [com.romexplorer.gba.core.worldmap.ObjectEventData.romOffset] plus its
 * script-pointer field's byte offset within that struct), not the
 * script's own address.
 *
 * This always relocates — even when the new script is the same size as or
 * smaller than the one it replaces — rather than try to determine whether
 * it's safe to overwrite in place. Same trade-off, and the same reason,
 * [com.romexplorer.gba.core.pokemon.TrainerPartyWriter.resize] makes for
 * trainer parties: this app's own disassembly of the *original* script
 * doesn't always know exactly where it safely ends (see
 * [ScriptDisassembler]'s `stopReason`), so there's no verified boundary
 * this could overwrite up to without risking corrupting whatever comes
 * right after it.
 */
object ScriptWriter {
    suspend fun write(
        rom: RomAccessor,
        overlay: EditOverlay,
        ownerPointerFieldOffset: Long,
        newBytes: ByteArray,
    ): Boolean {
        if (newBytes.isEmpty()) return false
        val destination = FreeSpaceAllocator.findFreeRun(rom, overlay, newBytes.size) ?: return false
        if (!FreeSpaceAllocator.write(rom, overlay, destination, newBytes)) return false
        val pointerBytes = FreeSpaceAllocator.leBytes(FreeSpaceAllocator.toRomPointer(destination), 4)
        return FreeSpaceAllocator.write(rom, overlay, ownerPointerFieldOffset, pointerBytes)
    }
}
