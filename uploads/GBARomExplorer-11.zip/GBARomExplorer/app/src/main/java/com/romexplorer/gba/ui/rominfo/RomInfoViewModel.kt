package com.romexplorer.gba.ui.rominfo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.rom.HashProgress
import com.romexplorer.gba.data.repository.FavoritesRepository
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RomInfoViewModel(
    private val sessionManager: RomSessionManager,
    private val favoritesRepository: FavoritesRepository,
) : ViewModel() {

    val session = sessionManager.session

    val favorites: StateFlow<Set<String>> = favoritesRepository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private val _hashProgress = MutableStateFlow<Float?>(null)
    val hashProgress: StateFlow<Float?> = _hashProgress.asStateFlow()

    init {
        // Hashing and save-type detection both require a full scan; kick
        // them off as soon as the screen is created rather than waiting for
        // the user to ask, since both are always useful ROM-info fields.
        computeHashesIfNeeded()
        viewModelScope.launch { sessionManager.computeSaveType() }
    }

    private fun computeHashesIfNeeded() {
        if (sessionManager.session.value?.hashes != null) return
        viewModelScope.launch {
            sessionManager.computeHashes().collect { progress ->
                _hashProgress.value = when (progress) {
                    is HashProgress.InProgress -> progress.fraction
                    is HashProgress.Done -> null
                }
            }
        }
    }

    fun toggleFavorite() {
        val uri = sessionManager.session.value?.uri?.toString() ?: return
        viewModelScope.launch { favoritesRepository.toggle(uri) }
    }
}
