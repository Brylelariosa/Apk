package com.romexplorer.gba.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.romexplorer.gba.ui.analyzer.AnalyzerScreen
import com.romexplorer.gba.ui.hexeditor.HexEditorScreen
import com.romexplorer.gba.ui.home.HomeScreen
import com.romexplorer.gba.ui.home.ToolsScreen
import com.romexplorer.gba.ui.mapexplorer.MapExplorerScreen
import com.romexplorer.gba.ui.patch.PatchScreen
import com.romexplorer.gba.ui.pokemontables.PokemonTableScreen
import com.romexplorer.gba.ui.pokescript.NO_SCRIPT_OWNER
import com.romexplorer.gba.ui.pokescript.ScriptViewerScreen
import com.romexplorer.gba.ui.rominfo.RomInfoScreen
import com.romexplorer.gba.ui.rommap.RomMapScreen
import com.romexplorer.gba.ui.romexpansion.RomExpansionScreen

@Composable
fun GbaRomExplorerNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController)
        }
        composable(Screen.Tools.route) {
            ToolsScreen(navController)
        }
        composable(Screen.RomInfo.route) {
            RomInfoScreen(navController)
        }
        composable(Screen.HexEditor.route) {
            HexEditorScreen(navController)
        }
        composable(Screen.RomMap.route) {
            RomMapScreen(navController)
        }
        composable(Screen.Analyzer.route) {
            AnalyzerScreen(navController)
        }
        composable(Screen.Patch.route) {
            PatchScreen(navController)
        }
        composable(Screen.PokemonTables.route) {
            PokemonTableScreen(navController)
        }
        composable(Screen.MapExplorer.route) {
            MapExplorerScreen(navController)
        }
        composable(Screen.RomExpansion.route) {
            RomExpansionScreen(navController)
        }
        composable(
            Screen.PokeScript.routePattern,
            arguments = listOf(
                navArgument(Screen.PokeScript.ARG_SCRIPT_OFFSET) { type = NavType.LongType },
                navArgument(Screen.PokeScript.ARG_OWNER_OFFSET) { type = NavType.LongType },
            ),
        ) { backStackEntry ->
            val scriptOffset = backStackEntry.arguments?.getLong(Screen.PokeScript.ARG_SCRIPT_OFFSET) ?: 0L
            val ownerOffset = backStackEntry.arguments?.getLong(Screen.PokeScript.ARG_OWNER_OFFSET) ?: NO_SCRIPT_OWNER
            ScriptViewerScreen(navController, scriptOffset, ownerOffset)
        }
    }
}
