package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class NameTableWriterTest {

    @Test
    fun `writes and round-trips a name at the correct flat-table offset`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(500))
        val overlay = EditOverlay()

        // tableOffset 200, entryLength 11, writing index 3 -> starts at 200 + 3*11 = 233
        val result = NameTableWriter.write(rom, overlay, tableOffset = 200L, entryLength = 11, index = 3, newName = "FAIRY STONE")

        assertEquals(FieldWriteResult.Success, result)
        val written = ByteArray(11) { i -> overlay.get(233L + i)!!.toByte() }
        assertEquals("FAIRY STONE", PokemonTextCodec.decode(written, 0, 11))
    }

    @Test
    fun `does not touch bytes before or after the target entry`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(500))
        val overlay = EditOverlay()

        NameTableWriter.write(rom, overlay, tableOffset = 200L, entryLength = 10, index = 1, newName = "BULBASAUR")

        assertEquals(null, overlay.get(209L)) // last byte of entry 0, untouched
        assertEquals(null, overlay.get(220L)) // first byte of entry 2, untouched
    }

    @Test
    fun `rejects an index whose entry runs past the end of the ROM`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(50))
        val overlay = EditOverlay()

        val result = NameTableWriter.write(rom, overlay, tableOffset = 40L, entryLength = 20, index = 0, newName = "TOO FAR")

        assertEquals(FieldWriteResult.OutOfBounds, result)
    }
}
