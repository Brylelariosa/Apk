package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FireRedTableAnalyzerTest {

    private val bulbasaurFingerprint = byteArrayOf(
        0x2D, 0x31, 0x31, 0x2D, 0x41, 0x41, 0x0C, 0x03,
        0x2D, 0x40, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
        0x1F, 0x14, 0x46, 0x03, 0x01, 0x07, 0x41, 0x00,
        0x00, 0x03, 0x00, 0x00,
    )

    private fun buildRom(includeFingerprint: Boolean): ByteArrayRomAccessor {
        val data = ByteArray(4 * 1024 * 1024)
        if (includeFingerprint) {
            val bulbasaurOffset = FireRedTables.speciesBaseStats.romOffset.toInt() + FireRedTables.speciesBaseStats.entrySize
            bulbasaurFingerprint.copyInto(data, bulbasaurOffset)
        }
        return ByteArrayRomAccessor(data)
    }

    @Test
    fun `claims all four known tables when the Bulbasaur fingerprint matches`() = runBlocking {
        val regions = FireRedTableAnalyzer().analyze(buildRom(includeFingerprint = true)) {}

        assertEquals(4, regions.size)
        assertTrue(regions.any { it.type == RegionType.POKEMON_SPECIES && it.startOffset == FireRedTables.speciesBaseStats.romOffset })
        assertTrue(regions.any { it.type == RegionType.POKEMON_MOVES && it.startOffset == FireRedTables.moves.romOffset })
        assertTrue(regions.any { it.type == RegionType.POKEMON_ITEMS && it.startOffset == FireRedTables.items.romOffset })
        assertTrue(regions.any { it.type == RegionType.POKEMON_TRAINERS && it.startOffset == FireRedTables.trainers.romOffset })
    }

    @Test
    fun `claims nothing when the fingerprint does not match`() = runBlocking {
        val regions = FireRedTableAnalyzer().analyze(buildRom(includeFingerprint = false)) {}
        assertTrue(regions.isEmpty())
    }

    @Test
    fun `reads Bulbasaur's base stats fields correctly`() = runBlocking {
        val rom = buildRom(includeFingerprint = true)
        val table = PokemonTableReader.read(rom, FireRedTables.speciesBaseStats)

        val bulbasaur = table.rows[1].values
        assertEquals(45L, bulbasaur["Base HP"])
        assertEquals(49L, bulbasaur["Base Attack"])
        assertEquals(49L, bulbasaur["Base Defense"])
        assertEquals(45L, bulbasaur["Base Speed"])
        assertEquals(65L, bulbasaur["Base Sp. Attack"])
        assertEquals(65L, bulbasaur["Base Sp. Defense"])
        assertEquals(12L, bulbasaur["Type 1"]) // Grass
        assertEquals(3L, bulbasaur["Type 2"]) // Poison
        assertEquals(45L, bulbasaur["Catch Rate"])
        assertEquals(64L, bulbasaur["Base Exp Yield"])
        assertEquals(31L, bulbasaur["Gender Threshold"])
        assertEquals(20L, bulbasaur["Egg Cycles"])
        assertEquals(70L, bulbasaur["Base Friendship"])
        assertEquals(3L, bulbasaur["Level-up Type"]) // Medium Slow
        assertEquals(1L, bulbasaur["Egg Group 1"]) // Monster
        assertEquals(7L, bulbasaur["Egg Group 2"]) // Grass
        assertEquals(65L, bulbasaur["Ability 1"]) // Overgrow
        assertEquals(3L, bulbasaur["Color / Flip"]) // Green
    }
}
