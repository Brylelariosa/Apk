package com.romexplorer.gba.core.graphics

import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GbaGraphicsTest {

    private fun le16(value: Int): ByteArray = byteArrayOf((value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte())

    @Test
    fun `decodes pure white, pure red, and black as index 0 becomes transparent`() {
        // BGR555: bits 0-4 red, 5-9 green, 10-14 blue.
        val palette = le16(0x0000) + le16(0x7FFF) + le16(0x001F) + ByteArray(26) // slot0=black(->transparent), 1=white, 2=red, rest 0

        val colors = GbaGraphics.decodePalette(palette)

        assertEquals(0x00000000.toInt(), colors[0]) // index 0: alpha forced to 0 regardless of stored color
        assertEquals(0xFFFFFFFF.toInt(), colors[1]) // 31,31,31 -> 255,255,255
        assertEquals(0xFFFF0000.toInt(), colors[2]) // R=31,G=0,B=0 -> pure red
    }

    @Test
    fun `decodes a single 8x8 tile respecting low-nibble-first pixel order`() {
        val palette = IntArray(16) { it } // palette[n] = n, so decoded pixel value directly reveals which index was read
        // One row of a tile: byte 0x21 -> low nibble 1 (left pixel), high nibble 2 (right pixel)
        val tile = ByteArray(32)
        tile[0] = 0x21

        val pixels = GbaGraphics.decode4bpp(tile, palette, widthPx = 8, heightPx = 8)

        assertEquals(1, pixels[0]) // top-left pixel = low nibble
        assertEquals(2, pixels[1]) // next pixel = high nibble
    }

    @Test
    fun `decodes tiles left-to-right within a band before moving down`() {
        val palette = IntArray(16) { it }
        // Two tiles side by side (16x8): first byte of tile 0 vs first byte of tile 1
        val data = ByteArray(64)
        data[0] = 0x21 // tile (0,0) top-left pixels
        data[32] = 0x43 // tile (1,0) top-left pixels (tile 1 starts at byte 32)

        val pixels = GbaGraphics.decode4bpp(data, palette, widthPx = 16, heightPx = 8)

        assertEquals(1, pixels[0]) // tile 0's pixel
        assertEquals(3, pixels[8]) // tile 1 starts at x=8 in the output row
    }

    @Test
    fun `readPointer32 converts a ROM address, and returns null for non-ROM values`() {
        val romPointerBytes = byteArrayOf(0x00, 0x10, 0x00, 0x08) // 0x08001000 little-endian

        assertEquals(0x1000L, GbaGraphics.readPointer32(romPointerBytes, 0))
        assertNull(GbaGraphics.readPointer32(byteArrayOf(0, 0, 0, 0), 0)) // 0x00000000 isn't a ROM address
    }

    @Test
    fun `readPossiblyCompressed decompresses LZ77 data and validates the resulting size`() = runBlocking {
        val raw = ByteArray(32) { it.toByte() }
        val compressed = Lz77Codec.compress(raw)
        val data = ByteArray(200)
        compressed.copyInto(data, 10)
        val rom = ByteArrayRomAccessor(data)

        val result = GbaGraphics.readPossiblyCompressed(rom, pointer = 10, expectedDecompressedSize = 32)

        assertEquals(raw.toList(), result?.toList())
    }

    @Test
    fun `readPossiblyCompressed reads raw bytes directly when there is no LZ77 header`() = runBlocking {
        val data = ByteArray(64) { (it + 5).toByte() }
        data[0] = 0x05 // deliberately not the 0x10 LZ77 tag
        val rom = ByteArrayRomAccessor(data)

        val result = GbaGraphics.readPossiblyCompressed(rom, pointer = 0, expectedDecompressedSize = 32)

        assertEquals(data.copyOfRange(0, 32).toList(), result?.toList())
    }

    @Test
    fun `readPossiblyCompressed returns null when decompressed size does not match expectations`() = runBlocking {
        val compressed = Lz77Codec.compress(ByteArray(16))
        val rom = ByteArrayRomAccessor(compressed)

        // We ask for 999 bytes but the block only decompresses to 16 — a wrong offset/format, not a real match.
        val result = GbaGraphics.readPossiblyCompressed(rom, pointer = 0, expectedDecompressedSize = 999)

        assertNull(result)
    }
}
