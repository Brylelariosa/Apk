package com.romexplorer.gba.core.hex

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EditOverlayTest {

    @Test
    fun `a fresh overlay is not dirty and returns null for every offset`() {
        val overlay = EditOverlay()
        assertFalse(overlay.isDirty)
        assertNull(overlay.get(0L))
    }

    @Test
    fun `setByte records the new value and marks the overlay dirty`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 10L, newValue = 0x42, originalValue = 0x00)
        assertTrue(overlay.isDirty)
        assertEquals(0x42, overlay.get(10L))
    }

    @Test
    fun `setByte back to the original value is a no-op, not a recorded edit`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 10L, newValue = 0x00, originalValue = 0x00)
        assertFalse(overlay.isDirty)
        assertFalse(overlay.canUndo())
    }

    @Test
    fun `undo reverts the most recent edit and redo reapplies it`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 5L, newValue = 9, originalValue = 0)

        overlay.undo()
        assertNull(overlay.get(5L))
        assertTrue(overlay.canRedo())

        overlay.redo()
        assertEquals(9, overlay.get(5L))
    }

    @Test
    fun `applyTo overlays only edited offsets onto a copy, leaving the original untouched`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 2L, newValue = 0xFF, originalValue = 0x00)
        val original = ByteArray(5)

        val patched = overlay.applyTo(original)

        assertEquals(0xFF.toByte(), patched[2])
        assertEquals(0.toByte(), original[2]) // original array never mutated
    }

    @Test
    fun `applyTo extends the result rather than silently dropping an edit past the original's length`() {
        // Regression test: a relocation this app itself performs (a
        // trainer's resized party, a repointed script) can legitimately
        // land past a stale or short read of the ROM's own bytes — losing
        // that edit at export time, with no error, would leave a pointer
        // this app itself wrote aimed at content that was never actually
        // included in the exported file.
        val overlay = EditOverlay()
        overlay.setByte(offset = 10L, newValue = 0x42, originalValue = 0x00)
        val original = ByteArray(5) // shorter than offset 10

        val patched = overlay.applyTo(original)

        assertEquals(11, patched.size)
        assertEquals(0x42.toByte(), patched[10])
        // the gap between the original's end and the new byte reads as
        // unused ROM space (0xFF), not fabricated/zeroed content
        assertEquals(0xFF.toByte(), patched[5])
        assertEquals(0xFF.toByte(), patched[9])
    }

    @Test
    fun `snapshot reflects current overlay contents and loadSnapshot restores them into a fresh instance`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 1L, newValue = 11, originalValue = 0)
        overlay.setByte(offset = 2L, newValue = 22, originalValue = 0)

        val snapshot = overlay.snapshot()
        assertEquals(mapOf(1L to 11, 2L to 22), snapshot)

        val restored = EditOverlay()
        restored.loadSnapshot(snapshot)

        assertTrue(restored.isDirty)
        assertEquals(11, restored.get(1L))
        assertEquals(22, restored.get(2L))
    }

    @Test
    fun `loadSnapshot clears undo-redo history so it isn't mistaken for a live edit`() {
        val overlay = EditOverlay()
        overlay.loadSnapshot(mapOf(1L to 11))

        assertFalse(overlay.canUndo())
        assertFalse(overlay.canRedo())
    }

    @Test
    fun `loadSnapshot replaces rather than merges with any existing overlay content`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 1L, newValue = 99, originalValue = 0)

        overlay.loadSnapshot(mapOf(2L to 22))

        assertNull(overlay.get(1L)) // gone — loadSnapshot replaces, not merges
        assertEquals(22, overlay.get(2L))
    }

    @Test
    fun `clear empties the overlay and undo-redo history`() {
        val overlay = EditOverlay()
        overlay.setByte(offset = 1L, newValue = 1, originalValue = 0)

        overlay.clear()

        assertFalse(overlay.isDirty)
        assertFalse(overlay.canUndo())
        assertFalse(overlay.canRedo())
    }
}
