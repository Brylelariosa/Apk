package com.romexplorer.gba.core.analysis

import com.romexplorer.gba.core.analysis.analyzers.FreeSpaceAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class FreeSpaceAnalyzerTest {

    @Test
    fun `detects a single long 0xFF run`() = runBlocking {
        val data = ByteArray(1000) { 0x42 }
        for (i in 200 until 400) data[i] = 0xFF.toByte()
        val rom = ByteArrayRomAccessor(data)

        val regions = FreeSpaceAnalyzer(minRunLength = 64).analyze(rom) {}

        assertEquals(1, regions.size)
        assertEquals(200L, regions[0].startOffset)
        assertEquals(400L, regions[0].endOffsetExclusive)
        assertEquals(RegionType.FREE_SPACE, regions[0].type)
    }

    @Test
    fun `ignores runs shorter than the minimum`() = runBlocking {
        val data = ByteArray(1000) { 0x42 }
        for (i in 200 until 210) data[i] = 0xFF.toByte() // only 10 bytes, below threshold
        val rom = ByteArrayRomAccessor(data)

        val regions = FreeSpaceAnalyzer(minRunLength = 64).analyze(rom) {}

        assertEquals(0, regions.size)
    }

    @Test
    fun `detects separate runs of 0x00 and 0xFF independently`() = runBlocking {
        val data = ByteArray(1000) { 0x42 }
        for (i in 100 until 200) data[i] = 0x00
        for (i in 500 until 600) data[i] = 0xFF.toByte()
        val rom = ByteArrayRomAccessor(data)

        val regions = FreeSpaceAnalyzer(minRunLength = 64).analyze(rom) {}

        assertEquals(2, regions.size)
    }
}
