package com.romexplorer.gba.core.pokemon

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MoveAnimationVisualizerTest {

    @Test
    fun `same script bytes always derive the same visual params`() {
        val script = BattleAnimationScript(moveIndex = 57, romOffset = 0x1C69D8L, bytes = byteArrayOf(1, 2, 3, 4, 5))
        val first = MoveAnimationVisualizer.derive(script, movePower = 90)
        val second = MoveAnimationVisualizer.derive(script, movePower = 90)
        assertEquals(first, second)
    }

    @Test
    fun `different script bytes derive different particle timing`() {
        val a = BattleAnimationScript(1, 0L, byteArrayOf(1, 1, 1, 1))
        val b = BattleAnimationScript(2, 0L, byteArrayOf(9, 40, 200, 3, 250, 12))
        val paramsA = MoveAnimationVisualizer.derive(a, movePower = 40)
        val paramsB = MoveAnimationVisualizer.derive(b, movePower = 40)
        assertTrue(paramsA != paramsB)
    }

    @Test
    fun `a missing script falls back to a plain minimal pulse rather than throwing`() {
        val params = MoveAnimationVisualizer.derive(null, movePower = 40)
        assertEquals(0, params.scriptByteCount)
        assertTrue(params.particleCount > 0)
    }

    @Test
    fun `particle count always stays within the declared bounds`() {
        val bigScript = BattleAnimationScript(1, 0L, ByteArray(200) { it.toByte() })
        val params = MoveAnimationVisualizer.derive(bigScript, movePower = 250)
        assertTrue(params.particleCount in 6..20)
    }
}
