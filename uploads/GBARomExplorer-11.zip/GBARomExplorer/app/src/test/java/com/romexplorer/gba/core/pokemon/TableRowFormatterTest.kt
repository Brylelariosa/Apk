package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.TableRow
import org.junit.Assert.assertEquals
import org.junit.Test

class TableRowFormatterTest {

    @Test
    fun `resolves an item ID field to its name`() {
        val row = TableRow(index = 5, values = mapOf("Item 1" to 3L, "Base HP" to 45L))

        val display = TableRowFormatter.format(FireRedTables.trainers, row, itemNames = mapOf(3 to "Potion"))

        assertEquals("Potion", display.fields.first { it.label == "Item 1" }.value)
    }

    @Test
    fun `item ID 0 renders as no item rather than a name lookup`() {
        val row = TableRow(index = 0, values = mapOf("Item 1" to 0L))

        val display = TableRowFormatter.format(FireRedTables.trainers, row, itemNames = mapOf(0 to "Should never be shown"))

        assertEquals("-", display.fields.first { it.label == "Item 1" }.value)
    }

    @Test
    fun `unresolved item ID falls back to a numbered placeholder, not a raw number`() {
        val row = TableRow(index = 0, values = mapOf("Item 1" to 250L))

        val display = TableRowFormatter.format(FireRedTables.trainers, row, itemNames = emptyMap())

        assertEquals("Item #250", display.fields.first { it.label == "Item 1" }.value)
    }

    @Test
    fun `promotes the trainer's name field to the row title instead of listing it as a field`() {
        val row = TableRow(index = 12, values = mapOf("Name" to "YOUNGSTER JOEY", "Party Flags" to 0L))

        val display = TableRowFormatter.format(FireRedTables.trainers, row)

        assertEquals("YOUNGSTER JOEY", display.title)
        assertEquals(false, display.fields.any { it.label == "Name" })
    }

    @Test
    fun `species table has no embedded name field so title is null without an external title`() {
        val row = TableRow(index = 1, values = mapOf("Base HP" to 45L, "Base Attack" to 49L))

        val display = TableRowFormatter.format(FireRedTables.speciesBaseStats, row)

        assertEquals(null, display.title)
        assertEquals("45", display.fields.first { it.label == "Base HP" }.value)
    }

    @Test
    fun `external title takes the species name lookup since species data has no name field of its own`() {
        val row = TableRow(index = 1, values = mapOf("Base HP" to 45L))

        val display = TableRowFormatter.format(FireRedTables.speciesBaseStats, row, externalTitle = "BULBASAUR")

        assertEquals("BULBASAUR", display.title)
    }

    @Test
    fun `resolves a type ID field to its name`() {
        val row = TableRow(index = 1, values = mapOf("Type 1" to 12L, "Type 2" to 3L))

        val display = TableRowFormatter.format(FireRedTables.speciesBaseStats, row, typeNames = mapOf(12 to "GRASS", 3 to "POISON"))

        assertEquals("GRASS", display.fields.first { it.label == "Type 1" }.value)
        assertEquals("POISON", display.fields.first { it.label == "Type 2" }.value)
    }

    @Test
    fun `type ID 0 resolves normally instead of being treated as none, unlike item ID 0`() {
        val row = TableRow(index = 0, values = mapOf("Type" to 0L))

        val display = TableRowFormatter.format(FireRedTables.moves, row, typeNames = mapOf(0 to "NORMAL"))

        assertEquals("NORMAL", display.fields.first { it.label == "Type" }.value)
    }

    @Test
    fun `unresolved type ID falls back to a numbered placeholder`() {
        val row = TableRow(index = 0, values = mapOf("Type" to 9L))

        val display = TableRowFormatter.format(FireRedTables.moves, row, typeNames = emptyMap())

        assertEquals("Type #9", display.fields.first { it.label == "Type" }.value)
    }

    @Test
    fun `items menu-category Type field is not resolved against elemental type names`() {
        val row = TableRow(index = 0, values = mapOf("Type" to 1L))

        // Even if a caller mistakenly passed typeNames here, items' own "Type" field has no TYPE_ID hint, so it must pass through raw.
        val display = TableRowFormatter.format(FireRedTables.items, row, typeNames = mapOf(1 to "FIGHTING"))

        assertEquals("1", display.fields.first { it.label == "Type" }.value)
    }

    @Test
    fun `plain numeric fields carry raw value and editable metadata for writing back`() {
        val row = TableRow(index = 1, values = mapOf("Base HP" to 45L))

        val display = TableRowFormatter.format(FireRedTables.speciesBaseStats, row)

        val hp = display.fields.first { it.label == "Base HP" }
        assertEquals(45L, hp.rawValue)
        assertEquals("Base HP", hp.editableField?.name)
    }

    @Test
    fun `pointer fields are not marked editable even though they have a raw numeric value`() {
        val row = TableRow(index = 0, values = mapOf("Party Pointer" to 12345L, "Party Flags" to 0L))

        val display = TableRowFormatter.format(FireRedTables.trainers, row)

        val pointerField = display.fields.first { it.label == "Party Pointer" }
        assertEquals(12345L, pointerField.rawValue) // still shown
        assertEquals(null, pointerField.editableField) // but not editable through this path
    }
}
