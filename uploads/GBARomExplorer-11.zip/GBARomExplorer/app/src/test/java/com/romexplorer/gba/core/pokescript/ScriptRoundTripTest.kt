package com.romexplorer.gba.core.pokescript

import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScriptRoundTripTest {

    /** lock; faceplayer; message 0x08123456; waitmessage; end */
    private fun sampleScript(): ByteArray = byteArrayOf(
        0x6a, // lock
        0x5a, // faceplayer
        0x67, 0x56, 0x34, 0x12, 0x08, // message 0x08123456
        0x66, // waitmessage
        0x02, // end
    )

    @Test
    fun `disassembles a known instruction sequence with correct mnemonics`() = runTest {
        val rom = ByteArrayRomAccessor(sampleScript())
        val result = ScriptDisassembler.disassemble(rom, 0L)

        assertEquals(StopReason.TERMINATED, result.stopReason)
        assertEquals(listOf("lock", "faceplayer", "message", "waitmessage", "end"), result.instructions.map { it.mnemonic })
        val messageArg = result.instructions[2].args.single()
        assertEquals(ArgType.POINTER, messageArg.type)
        assertEquals(0x08123456L, messageArg.rawValue)
    }

    @Test
    fun `text format round trips back to identical bytes when unedited`() = runTest {
        val original = sampleScript()
        val rom = ByteArrayRomAccessor(original)
        val disassembled = ScriptDisassembler.disassemble(rom, 0L)
        val text = ScriptTextFormatter.format(disassembled)

        val reassembled = ScriptAssembler.assemble(text)
        assertTrue(reassembled is AssembleResult.Success)
        assertArrayEquals(original, (reassembled as AssembleResult.Success).bytes)
    }

    @Test
    fun `stops at an unrecognized opcode rather than misaligning`() = runTest {
        // 0xFF isn't a valid FireRed script opcode (table ends at 0xD4).
        val rom = ByteArrayRomAccessor(byteArrayOf(0x5a, 0xFF.toByte(), 0x02))
        val result = ScriptDisassembler.disassemble(rom, 0L)

        assertEquals(listOf("faceplayer"), result.instructions.map { it.mnemonic })
        assertEquals(StopReason.UNKNOWN_OPCODE, result.stopReason)
        assertEquals(1L, result.stoppedAtOffset)
    }

    @Test
    fun `assembler rejects an unknown mnemonic with a line number`() {
        val result = ScriptAssembler.assemble("lock\nnotarealcommand 1 2\nend")
        assertTrue(result is AssembleResult.Failure)
        assertEquals(2, (result as AssembleResult.Failure).lineNumber)
    }

    @Test
    fun `assembler rejects a wrong argument count`() {
        val result = ScriptAssembler.assemble("setvar 1 2 3")
        assertTrue(result is AssembleResult.Failure)
    }

    @Test
    fun `trainerbattle assembles and disassembles consistently for a standard battle type`() = runTest {
        val text = "trainerbattle 0 5 0 0x08000010 0x08000020"
        val assembled = ScriptAssembler.assemble(text)
        assertTrue(assembled is AssembleResult.Success)
        val bytes = (assembled as AssembleResult.Success).bytes

        val rom = ByteArrayRomAccessor(bytes + byteArrayOf(0x02)) // + end, so disassembly has a real terminator
        val disassembled = ScriptDisassembler.disassemble(rom, 0L)
        assertEquals(listOf("trainerbattle", "end"), disassembled.instructions.map { it.mnemonic })
        assertEquals(14, disassembled.instructions[0].totalBytes)
    }
}
