package com.romexplorer.gba.core.rom

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class RomHasherTest {

    @Test
    fun `same content produces the same fingerprint, so reopening the same ROM restores its draft`() = runBlocking {
        val romA = ByteArrayRomAccessor(ByteArray(4_000_000) { (it % 251).toByte() })
        val romB = ByteArrayRomAccessor(ByteArray(4_000_000) { (it % 251).toByte() })

        assertEquals(RomHasher.quickFingerprint(romA), RomHasher.quickFingerprint(romB))
    }

    @Test
    fun `different content produces a different fingerprint`() = runBlocking {
        val romA = ByteArrayRomAccessor(ByteArray(4_000_000) { (it % 251).toByte() })
        val romB = ByteArrayRomAccessor(ByteArray(4_000_000) { (it % 250).toByte() })

        assertNotEquals(RomHasher.quickFingerprint(romA), RomHasher.quickFingerprint(romB))
    }

    @Test
    fun `two ROMs identical at the start but differing only near the end are still told apart`() = runBlocking {
        // The realistic case this app's own edits create: a ROM this app
        // previously exported (new data written into free space, which
        // tends to be late in the file — see FreeSpaceAllocator) versus a
        // fresh, unmodified one. A start-only fingerprint would collide here.
        val data = ByteArray(4_000_000) { (it % 251).toByte() }
        val romA = ByteArrayRomAccessor(data.copyOf())
        val editedNearEnd = data.copyOf()
        editedNearEnd[editedNearEnd.size - 100] = (editedNearEnd[editedNearEnd.size - 100] + 1).toByte()
        val romB = ByteArrayRomAccessor(editedNearEnd)

        assertNotEquals(RomHasher.quickFingerprint(romA), RomHasher.quickFingerprint(romB))
    }

    @Test
    fun `a ROM smaller than the sample window doesn't crash and still fingerprints deterministically`() = runBlocking {
        val small = ByteArray(1000) { it.toByte() }
        val romA = ByteArrayRomAccessor(small.copyOf())
        val romB = ByteArrayRomAccessor(small.copyOf())

        assertEquals(RomHasher.quickFingerprint(romA), RomHasher.quickFingerprint(romB))
    }

    @Test
    fun `fingerprint includes file size, so truncated content isn't mistaken for a match`() = runBlocking {
        val full = ByteArray(4_000_000) { (it % 251).toByte() }
        val truncated = full.copyOf(3_999_000)
        val romA = ByteArrayRomAccessor(full)
        val romB = ByteArrayRomAccessor(truncated)

        assertNotEquals(RomHasher.quickFingerprint(romA), RomHasher.quickFingerprint(romB))
    }
}
