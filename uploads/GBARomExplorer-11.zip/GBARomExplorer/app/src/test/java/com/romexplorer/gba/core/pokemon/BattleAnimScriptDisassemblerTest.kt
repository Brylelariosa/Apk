package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BattleAnimScriptDisassemblerTest {

    private fun romWithScript(startOffset: Int, script: ByteArray, size: Int = 0x400000): ByteArrayRomAccessor {
        val data = ByteArray(size)
        script.copyInto(data, startOffset)
        return ByteArrayRomAccessor(data)
    }

    private fun le32Pointer(fileOffset: Int): ByteArray {
        val romAddr = fileOffset + 0x08000000
        return byteArrayOf(
            (romAddr and 0xFF).toByte(),
            ((romAddr shr 8) and 0xFF).toByte(),
            ((romAddr shr 16) and 0xFF).toByte(),
            ((romAddr shr 24) and 0xFF).toByte(),
        )
    }

    @Test
    fun `decodes a simple linear script down to end`() = runBlocking {
        // delay 4; playse #7; waitforvisualfinish; end
        val script = byteArrayOf(0x04, 0x04) + byteArrayOf(0x09, 0x07, 0x00) + byteArrayOf(0x05) + byteArrayOf(0x08)
        val rom = romWithScript(0x1000, script)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertTrue(result.fullyDecoded)
        val commands = result.steps.filterIsInstance<AnimScriptStep.Command>()
        assertEquals(4, commands.size)
        assertEquals("delay 4 frames", commands[0].summary)
        assertEquals("play sound #7", commands[1].summary)
        assertEquals("wait for all sprites/visual tasks to finish", commands[2].summary)
        assertEquals("end", commands[3].summary)
    }

    @Test
    fun `delay 0 means wait indefinitely, matching the real interpreter's sentinel`() = runBlocking {
        val script = byteArrayOf(0x04, 0x00, 0x08)
        val rom = romWithScript(0x1000, script)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        val delayStep = result.steps.filterIsInstance<AnimScriptStep.Command>().first()
        assertEquals("delay indefinitely", delayStep.summary)
    }

    @Test
    fun `call jumps to the subroutine and return comes back to right after the call`() = runBlocking {
        // main @0x1000: call 0x2000; playse #9; end   (5 + 3 + 1 = 9 bytes)
        // sub  @0x2000: delay 1; return
        val callTarget = le32Pointer(0x2000)
        val main = byteArrayOf(0x0E) + callTarget + byteArrayOf(0x09, 0x09, 0x00) + byteArrayOf(0x08)
        val sub = byteArrayOf(0x04, 0x01, 0x0F)
        val data = ByteArray(0x400000)
        main.copyInto(data, 0x1000)
        sub.copyInto(data, 0x2000)
        val rom = ByteArrayRomAccessor(data)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertTrue(result.fullyDecoded)
        val commands = result.steps.filterIsInstance<AnimScriptStep.Command>()
        // call, delay (inside the subroutine), return, playse (back in main), end
        assertEquals(listOf("call 0x2000", "delay 1 frame", "return", "play sound #9", "end"), commands.map { it.summary })
    }

    @Test
    fun `goto jumps unconditionally and never returns`() = runBlocking {
        // main @0x1000: goto 0x2000 (5 bytes)
        // target @0x2000: end
        val target = le32Pointer(0x2000)
        val data = ByteArray(0x400000)
        (byteArrayOf(0x13) + target).copyInto(data, 0x1000)
        data[0x2000] = 0x08
        val rom = ByteArrayRomAccessor(data)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertTrue(result.fullyDecoded)
        val commands = result.steps.filterIsInstance<AnimScriptStep.Command>()
        assertEquals(listOf("goto 0x2000", "end"), commands.map { it.summary })
    }

    @Test
    fun `stops cleanly and honestly at the first opcode outside the verified set`() = runBlocking {
        // delay 2; playsewithpan (0x19, not decoded) ...
        val script = byteArrayOf(0x04, 0x02, 0x19, 0x00, 0x00)
        val rom = romWithScript(0x1000, script)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertEquals(false, result.fullyDecoded)
        assertEquals(1, result.steps.filterIsInstance<AnimScriptStep.Command>().size)
        val stopped = result.steps.filterIsInstance<AnimScriptStep.Stopped>().single()
        assertTrue(stopped.reason.contains("playsewithpan"))
        assertTrue(stopped.reason.contains("19")) // the real opcode number, not hidden
    }

    @Test
    fun `createsprite decodes its variable-length trailing args correctly`() = runBlocking {
        // createsprite: ptr(4)=0x08003000, flags=0x02 (attacker), argsCount=2, args=[10, 20]; then end
        val template = le32Pointer(0x3000)
        val script = byteArrayOf(0x02) + template + byteArrayOf(0x02, 0x02) +
            byteArrayOf(10, 0, 20, 0) + byteArrayOf(0x08)
        val rom = romWithScript(0x1000, script)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertTrue(result.fullyDecoded)
        val createStep = result.steps.filterIsInstance<AnimScriptStep.Command>().first()
        assertTrue(createStep.summary.contains("[10, 20]"))
        assertTrue(createStep.summary.contains("attacker"))
        assertEquals(11, createStep.byteLength) // 1 opcode + 4 ptr + 1 flags + 1 count + 2*2 args
    }

    @Test
    fun `a goto cycle is bounded rather than looping forever`() = runBlocking {
        // Two mutually-jumping gotos: a real (if unusual) infinite loop this app must not hang on decoding.
        val toB = le32Pointer(0x1010)
        val toA = le32Pointer(0x1000)
        val data = ByteArray(0x400000)
        (byteArrayOf(0x13) + toB).copyInto(data, 0x1000)
        (byteArrayOf(0x13) + toA).copyInto(data, 0x1010)
        val rom = ByteArrayRomAccessor(data)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertEquals(false, result.fullyDecoded)
        assertTrue(result.steps.last() is AnimScriptStep.Stopped)
        assertTrue(result.steps.size <= 401) // MAX_STEPS commands plus the final Stopped marker, not unbounded
    }

    @Test
    fun `choosetwoturnanim decodes both named targets and stops rather than guessing which runs`() = runBlocking {
        val firstTurn = le32Pointer(0x2000)
        val secondTurn = le32Pointer(0x3000)
        val script = byteArrayOf(0x11) + firstTurn + secondTurn
        val rom = romWithScript(0x1000, script)

        val result = BattleAnimScriptDisassembler.disassemble(rom, 0x1000)

        assertEquals(false, result.fullyDecoded)
        val step = result.steps.filterIsInstance<AnimScriptStep.Command>().single()
        assertTrue(step.summary.contains("0x2000"))
        assertTrue(step.summary.contains("0x3000"))
    }
}
