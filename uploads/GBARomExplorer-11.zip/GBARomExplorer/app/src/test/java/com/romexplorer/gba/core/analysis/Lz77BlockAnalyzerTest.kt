package com.romexplorer.gba.core.analysis

import com.romexplorer.gba.core.analysis.analyzers.Lz77BlockAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Lz77BlockAnalyzerTest {

    @Test
    fun `finds a real compressed block embedded in surrounding data`() = runBlocking {
        val payload = "The quick brown fox jumps over the lazy dog many times over.".toByteArray()
        val compressed = Lz77Codec.compress(payload)

        val data = ByteArray(2000) { 0x42 }
        val insertAt = 500
        compressed.copyInto(data, insertAt)
        val rom = ByteArrayRomAccessor(data)

        val regions = Lz77BlockAnalyzer().analyze(rom) {}

        assertEquals(1, regions.size)
        assertEquals(insertAt.toLong(), regions[0].startOffset)
        assertEquals(RegionType.COMPRESSED, regions[0].type)
        assertTrue(regions[0].confidence > 0.5f)
    }

    @Test
    fun `does not false-positive on a lone 0x10 byte in unrelated data`() = runBlocking {
        val data = ByteArray(2000) { 0x42 }
        data[300] = 0x10 // looks like an LZ77 tag but isn't followed by a valid stream
        val rom = ByteArrayRomAccessor(data)

        val regions = Lz77BlockAnalyzer().analyze(rom) {}

        assertEquals(0, regions.size)
    }
}
