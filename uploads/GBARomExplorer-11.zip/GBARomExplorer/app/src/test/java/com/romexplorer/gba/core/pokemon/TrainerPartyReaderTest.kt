package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainerPartyReaderTest {

    private fun le16(value: Int): ByteArray = byteArrayOf((value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte())

    /** iv(2) + lvl(1) + pad(1) + species(2) [+ heldItem(2)] [+ moves(2x4)], matching the real struct layouts. */
    private fun entry(level: Int, species: Int, heldItem: Int? = null, moves: List<Int>? = null): ByteArray {
        var bytes = le16(0) + byteArrayOf(level.toByte(), 0) + le16(species)
        heldItem?.let { bytes += le16(it) }
        moves?.forEach { bytes += le16(it) }
        return bytes
    }

    @Test
    fun `no item default moves - reads species and level only`() = runBlocking {
        val data = ByteArray(64)
        entry(level = 50, species = 1).copyInto(data, 10)
        val rom = ByteArrayRomAccessor(data)

        val members = TrainerPartyReader.read(rom, partyFlags = 0, partyPointer = 10, partySize = 1)

        assertEquals(1, members.size)
        assertEquals(50, members[0].level)
        assertEquals(1, members[0].species)
        assertNull(members[0].heldItem)
        assertNull(members[0].moves)
    }

    @Test
    fun `item default moves - reads held item`() = runBlocking {
        val data = ByteArray(64)
        entry(level = 40, species = 25, heldItem = 13).copyInto(data, 10)
        val rom = ByteArrayRomAccessor(data)

        val members = TrainerPartyReader.read(rom, partyFlags = 0x2, partyPointer = 10, partySize = 1)

        assertEquals(13, members[0].heldItem)
        assertNull(members[0].moves)
    }

    @Test
    fun `no item custom moves - reads four moves`() = runBlocking {
        val data = ByteArray(64)
        entry(level = 72, species = 6, moves = listOf(52, 89, 126, 157)).copyInto(data, 10)
        val rom = ByteArrayRomAccessor(data)

        val members = TrainerPartyReader.read(rom, partyFlags = 0x1, partyPointer = 10, partySize = 1)

        assertNull(members[0].heldItem)
        assertEquals(listOf(52, 89, 126, 157), members[0].moves)
    }

    @Test
    fun `item custom moves - reads held item and moves together`() = runBlocking {
        val data = ByteArray(64)
        entry(level = 73, species = 130, heldItem = 234, moves = listOf(89, 57, 58, 116)).copyInto(data, 10)
        val rom = ByteArrayRomAccessor(data)

        val members = TrainerPartyReader.read(rom, partyFlags = 0x3, partyPointer = 10, partySize = 1)

        assertEquals(234, members[0].heldItem)
        assertEquals(listOf(89, 57, 58, 116), members[0].moves)
    }

    @Test
    fun `reads multiple entries at the correct stride for the variant size`() = runBlocking {
        val data = ByteArray(64)
        entry(level = 10, species = 1).copyInto(data, 0)
        entry(level = 20, species = 2).copyInto(data, 6) // no-item-default-moves entries are 6 bytes each
        val rom = ByteArrayRomAccessor(data)

        val members = TrainerPartyReader.read(rom, partyFlags = 0, partyPointer = 0, partySize = 2)

        assertEquals(2, members.size)
        assertEquals(1, members[0].species)
        assertEquals(2, members[1].species)
        assertEquals(20, members[1].level)
    }

    @Test
    fun `empty party size or missing pointer returns no members`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(64))

        assertTrue(TrainerPartyReader.read(rom, partyFlags = 0, partyPointer = 10, partySize = 0).isEmpty())
        assertTrue(TrainerPartyReader.read(rom, partyFlags = 0, partyPointer = 0, partySize = 3).isEmpty())
    }
}
