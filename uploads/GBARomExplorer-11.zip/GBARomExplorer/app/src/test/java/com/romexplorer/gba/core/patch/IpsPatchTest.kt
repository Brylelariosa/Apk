package com.romexplorer.gba.core.patch

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IpsPatchTest {

    @Test
    fun `round trips a small edit`() {
        val original = ByteArray(1000) { it.toByte() }
        val modified = original.copyOf()
        modified[500] = 0xAB.toByte()
        modified[501] = 0xCD.toByte()

        val patch = IpsPatch.create(original, modified)
        assertTrue(IpsPatch.isValid(patch))

        val result = IpsPatch.apply(original, patch)
        assertArrayEquals(modified, result)
    }

    @Test
    fun `round trips a run of identical bytes via RLE`() {
        val original = ByteArray(2000) { 0x00 }
        val modified = original.copyOf()
        for (i in 100 until 200) modified[i] = 0xFF.toByte() // 100-byte uniform run, triggers RLE

        val patch = IpsPatch.create(original, modified)
        val result = IpsPatch.apply(original, patch)
        assertArrayEquals(modified, result)
    }

    @Test
    fun `round trips multiple scattered edits`() {
        val original = ByteArray(5000) { (it % 256).toByte() }
        val modified = original.copyOf()
        modified[10] = 1
        modified[2000] = 2
        modified[2001] = 3
        modified[4999] = 4

        val patch = IpsPatch.create(original, modified)
        val result = IpsPatch.apply(original, patch)
        assertArrayEquals(modified, result)
    }

    @Test
    fun `round trips a file that grows in size`() {
        val original = ByteArray(100) { it.toByte() }
        val modified = original.copyOf(150)
        for (i in 100 until 150) modified[i] = (i - 100).toByte()

        val patch = IpsPatch.create(original, modified)
        val result = IpsPatch.apply(original, patch)
        assertArrayEquals(modified, result)
    }

    @Test
    fun `identical files produce an empty patch that round trips to the same bytes`() {
        val original = ByteArray(500) { it.toByte() }
        val patch = IpsPatch.create(original, original.copyOf())
        val result = IpsPatch.apply(original, patch)
        assertArrayEquals(original, result)
    }

    @Test
    fun `isValid rejects a file without the PATCH magic`() {
        val bogus = "NOT A PATCH FILE".toByteArray()
        assertTrue(!IpsPatch.isValid(bogus))
    }
}
