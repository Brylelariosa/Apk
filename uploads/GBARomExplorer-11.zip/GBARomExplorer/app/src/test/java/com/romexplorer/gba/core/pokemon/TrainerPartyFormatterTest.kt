package com.romexplorer.gba.core.pokemon

import org.junit.Assert.assertEquals
import org.junit.Test

class TrainerPartyFormatterTest {

    @Test
    fun `formats a default-moves member with just level and species`() {
        val members = listOf(TrainerPartyMember(species = 1, level = 50, heldItem = null, moves = null))

        val lines = TrainerPartyFormatter.format(members, speciesNames = mapOf(1 to "BULBASAUR"), itemNames = emptyMap(), moveNames = emptyMap())

        assertEquals(listOf("Lv.50 BULBASAUR"), lines)
    }

    @Test
    fun `includes held item when present, omits it when item ID is 0`() {
        val withItem = TrainerPartyMember(species = 25, level = 40, heldItem = 13, moves = null)
        val noItem = TrainerPartyMember(species = 25, level = 40, heldItem = 0, moves = null)

        val lines = TrainerPartyFormatter.format(
            listOf(withItem, noItem),
            speciesNames = mapOf(25 to "PIKACHU"),
            itemNames = mapOf(13 to "POTION"),
            moveNames = emptyMap(),
        )

        assertEquals("Lv.40 PIKACHU @ POTION", lines[0])
        assertEquals("Lv.40 PIKACHU", lines[1])
    }

    @Test
    fun `includes resolved moves joined together, skipping empty move slots`() {
        val member = TrainerPartyMember(species = 6, level = 72, heldItem = null, moves = listOf(52, 89, 0, 0))

        val lines = TrainerPartyFormatter.format(
            listOf(member),
            speciesNames = mapOf(6 to "CHARIZARD"),
            itemNames = emptyMap(),
            moveNames = mapOf(52 to "EMBER", 89 to "EARTHQUAKE"),
        )

        assertEquals("Lv.72 CHARIZARD — EMBER/EARTHQUAKE", lines[0])
    }

    @Test
    fun `falls back to a numbered placeholder for unresolved names`() {
        val member = TrainerPartyMember(species = 999, level = 5, heldItem = null, moves = null)

        val lines = TrainerPartyFormatter.format(listOf(member), speciesNames = emptyMap(), itemNames = emptyMap(), moveNames = emptyMap())

        assertEquals("Lv.5 Species #999", lines[0])
    }
}
