package com.romexplorer.gba.core.compression

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import kotlin.random.Random

class Lz77CodecTest {

    @Test
    fun `round trips small repetitive data`() {
        val original = "AAAAAAAAAAAAAAAABBBBBBBBBBBBBBBBCCCCCCCCCCCCCCCC".toByteArray()
        val compressed = Lz77Codec.compress(original)
        val decompressed = Lz77Codec.decompress(compressed)
        assertArrayEquals(original, decompressed)
    }

    @Test
    fun `round trips random data`() {
        val original = Random(42).nextBytes(2000)
        val compressed = Lz77Codec.compress(original)
        val decompressed = Lz77Codec.decompress(compressed)
        assertArrayEquals(original, decompressed)
    }

    @Test
    fun `round trips data with long back references`() {
        val chunk = "The quick brown fox jumps over the lazy dog. ".toByteArray()
        val original = ByteArray(chunk.size * 50)
        for (i in original.indices) original[i] = chunk[i % chunk.size]
        val compressed = Lz77Codec.compress(original)
        val decompressed = Lz77Codec.decompress(compressed)
        assertArrayEquals(original, decompressed)
    }

    @Test
    fun `compressed output starts with format tag and declared size`() {
        val original = ByteArray(300) { it.toByte() }
        val compressed = Lz77Codec.compress(original)
        assertEquals(Lz77Codec.FORMAT_TAG, compressed[0].toInt() and 0xFF)
        val declaredSize = (compressed[1].toInt() and 0xFF) or
            ((compressed[2].toInt() and 0xFF) shl 8) or
            ((compressed[3].toInt() and 0xFF) shl 16)
        assertEquals(original.size, declaredSize)
    }

    @Test
    fun `rejects input missing the format tag`() {
        val bogus = byteArrayOf(0x00, 0x05, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05)
        assertThrows(Lz77FormatException::class.java) { Lz77Codec.decompress(bogus) }
    }

    @Test
    fun `isLikelyHeader recognizes the format tag`() {
        assert(Lz77Codec.isLikelyHeader(0x10))
        assert(!Lz77Codec.isLikelyHeader(0x11))
    }
}
