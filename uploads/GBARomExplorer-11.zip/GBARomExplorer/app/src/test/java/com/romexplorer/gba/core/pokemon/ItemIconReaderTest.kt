package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ItemIconReaderTest {

    private fun le32Pointer(fileOffset: Long): ByteArray {
        val romAddr = (fileOffset + 0x08000000L).toInt()
        return byteArrayOf(
            (romAddr and 0xFF).toByte(),
            ((romAddr shr 8) and 0xFF).toByte(),
            ((romAddr shr 16) and 0xFF).toByte(),
            ((romAddr shr 24) and 0xFF).toByte(),
        )
    }

    @Test
    fun `reads an item icon from compressed image data and a raw palette`() = runBlocking {
        val data = ByteArray(0x400000)
        val itemIndex = 3
        val imageOffset = 0x200000L
        val paletteOffset = 0x210000L

        val rawImage = ByteArray(288).also { it[0] = 0x21 } // 24x24 4bpp
        Lz77Codec.compress(rawImage).copyInto(data, imageOffset.toInt())

        val rawPalette = ByteArray(32)
        rawPalette[2] = 0xFF.toByte() // palette index 1, low byte
        rawPalette[3] = 0x7F // palette index 1, high byte -> 0x7FFF (white)
        rawPalette.copyInto(data, paletteOffset.toInt())

        val entryOffset = (0x3D4294L + itemIndex * 8L).toInt()
        le32Pointer(imageOffset).copyInto(data, entryOffset)
        le32Pointer(paletteOffset).copyInto(data, entryOffset + 4)

        val rom = ByteArrayRomAccessor(data)
        val image = ItemIconReader.read(rom, itemIndex)

        assertEquals(24, image?.width)
        assertEquals(0xFFFFFFFF.toInt(), image?.pixels?.get(0))
    }

    @Test
    fun `returns null for a negative item index`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(0x400000))
        assertNull(ItemIconReader.read(rom, -1))
    }
}
