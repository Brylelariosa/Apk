package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SpeciesIconReaderTest {

    private fun le32Pointer(fileOffset: Long): ByteArray {
        val romAddr = (fileOffset + 0x08000000L).toInt()
        return byteArrayOf(
            (romAddr and 0xFF).toByte(),
            ((romAddr shr 8) and 0xFF).toByte(),
            ((romAddr shr 16) and 0xFF).toByte(),
            ((romAddr shr 24) and 0xFF).toByte(),
        )
    }

    private fun le16(value: Int): ByteArray = byteArrayOf((value and 0xFF).toByte(), ((value shr 8) and 0xFF).toByte())

    @Test
    fun `reads a species icon using its own palette slot`() = runBlocking {
        val data = ByteArray(0x400000)
        val speciesIndex = 5
        val iconDataOffset = 0x100000L

        le32Pointer(iconDataOffset).copyInto(data, (0x3D37A0L + speciesIndex * 4L).toInt())
        data[iconDataOffset.toInt()] = 0x21 // low nibble 1 (1st pixel), high nibble 2 (2nd pixel)
        data[(0x3D3E80L + speciesIndex).toInt()] = 1 // this species uses palette slot 1

        val palette1 = le16(0) + le16(0x7FFF) + le16(0x001F) + ByteArray(26) // index1=white, index2=red
        palette1.copyInto(data, (0x3D3740L + 1 * 32).toInt())

        val rom = ByteArrayRomAccessor(data)
        val image = SpeciesIconReader.read(rom, speciesIndex)

        assertEquals(32, image?.width)
        assertEquals(0xFFFFFFFF.toInt(), image?.pixels?.get(0))
        assertEquals(0xFFFF0000.toInt(), image?.pixels?.get(1))
    }

    @Test
    fun `returns null for a negative species index`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(0x400000))
        assertNull(SpeciesIconReader.read(rom, -1))
    }
}
