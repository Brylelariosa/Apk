package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class NameTableLookupTest {

    /** Encodes uppercase ASCII the same way PokemonTextCodec's table does (0xBB + letter offset), 0xFF-terminated. */
    private fun encode(name: String): ByteArray =
        name.map { (0xBB + (it - 'A')).toByte() }.toByteArray() + 0xFF.toByte()

    @Test
    fun `builds an index to name map from a flat fixed-length array`() = runBlocking {
        val entryLength = 6
        val data = ByteArray(100)
        val offset = 40
        encode("BULB").copyInto(data, offset) // index 0
        encode("IVY").copyInto(data, offset + entryLength) // index 1
        val rom = ByteArrayRomAccessor(data)

        val names = NameTableLookup.build(rom, romOffset = offset.toLong(), entryLength = entryLength, count = 2)

        assertEquals("BULB", names[0])
        assertEquals("IVY", names[1])
    }

    @Test
    fun `truncates entry count when the ROM is too short for all of them`() = runBlocking {
        val entryLength = 4
        val data = ByteArray(10)
        val rom = ByteArrayRomAccessor(data)

        val names = NameTableLookup.build(rom, romOffset = 0, entryLength = entryLength, count = 100)

        assertEquals(2, names.size) // only 2 whole entries fit in 10 bytes at 4 bytes each
    }
}
