package com.romexplorer.gba.core.analysis

import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import com.romexplorer.gba.core.rom.RomAccessor
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FixedRegionAnalyzer(
    override val id: String,
    private val regions: List<RomRegion>,
) : RegionAnalyzer {
    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        onProgress(1f)
        return regions
    }
}

class AnalysisEngineTest {

    @Test
    fun `higher priority analyzer wins on overlapping bytes`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(1000))
        val header = FixedRegionAnalyzer("header", listOf(RomRegion(0, 100, RegionType.HEADER, 1f)))
        // A pointer-table false positive that overlaps the header region.
        val pointerTable = FixedRegionAnalyzer("pointers", listOf(RomRegion(50, 150, RegionType.POINTER_TABLE, 0.5f)))

        val engine = AnalysisEngine(coreAnalyzers = listOf(header, pointerTable))
        val results = engine.analyze(rom, gameCode = "TEST").toList()
        val map = (results.last() as AnalysisProgress.Done).map

        val headerRegion = map.regions.first { it.startOffset == 0L }
        assertEquals(RegionType.HEADER, headerRegion.type)
        assertEquals(100L, headerRegion.endOffsetExclusive) // header keeps its full claimed range

        val remainderPointerRegion = map.regions.first { it.type == RegionType.POINTER_TABLE }
        assertEquals(100L, remainderPointerRegion.startOffset) // pointer table only gets what's left over
        assertEquals(150L, remainderPointerRegion.endOffsetExclusive)
    }

    @Test
    fun `unclaimed bytes are filled as unknown`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(500))
        val header = FixedRegionAnalyzer("header", listOf(RomRegion(0, 50, RegionType.HEADER, 1f)))

        val engine = AnalysisEngine(coreAnalyzers = listOf(header))
        val results = engine.analyze(rom, gameCode = "TEST").toList()
        val map = (results.last() as AnalysisProgress.Done).map

        val totalCovered = map.regions.sumOf { it.length }
        assertEquals(500L, totalCovered)
        assertTrue(map.regions.any { it.type == RegionType.UNKNOWN && it.startOffset == 50L })
    }
}
