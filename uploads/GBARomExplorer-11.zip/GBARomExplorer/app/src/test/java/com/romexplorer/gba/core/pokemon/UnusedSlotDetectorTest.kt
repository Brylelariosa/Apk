package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.TableRow
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UnusedSlotDetectorTest {

    @Test
    fun `an item slot with a blank name and all-zero stats is unused`() {
        val row = TableRow(5, mapOf("Name" to "", "Price" to 0L, "Hold Effect" to 0L, "Pocket" to 0L))
        assertTrue(UnusedSlotDetector.isUnusedItemSlot(row))
    }

    @Test
    fun `an item slot with a real name is not unused even if some stats are zero`() {
        val row = TableRow(5, mapOf("Name" to "POTION", "Price" to 0L, "Hold Effect" to 0L, "Pocket" to 0L))
        assertFalse(UnusedSlotDetector.isUnusedItemSlot(row))
    }

    @Test
    fun `an item slot with a blank name but nonzero price is not unused`() {
        // guards against mistaking a real, unusually-blank-named item for a free slot
        val row = TableRow(5, mapOf("Name" to "", "Price" to 300L, "Hold Effect" to 0L, "Pocket" to 1L))
        assertFalse(UnusedSlotDetector.isUnusedItemSlot(row))
    }

    @Test
    fun `a species slot with a blank name and all-zero base stats is unused`() {
        val row = TableRow(
            412,
            mapOf("Base HP" to 0L, "Base Attack" to 0L, "Base Defense" to 0L, "Base Speed" to 0L),
        )
        assertTrue(UnusedSlotDetector.isUnusedSpeciesSlot(row, speciesName = null))
        assertTrue(UnusedSlotDetector.isUnusedSpeciesSlot(row, speciesName = ""))
    }

    @Test
    fun `a species slot with a real name is not unused`() {
        val row = TableRow(1, mapOf("Base HP" to 45L, "Base Attack" to 49L, "Base Defense" to 49L, "Base Speed" to 45L))
        assertFalse(UnusedSlotDetector.isUnusedSpeciesSlot(row, speciesName = "BULBASAUR"))
    }

    @Test
    fun `a move slot with a blank name and all-zero power, accuracy, and PP is unused`() {
        val row = TableRow(356, mapOf("Base Power" to 0L, "Accuracy" to 0L, "PP" to 0L))
        assertTrue(UnusedSlotDetector.isUnusedMoveSlot(row, moveName = null))
    }

    @Test
    fun `a move slot with a real name is not unused even at 0 power (a status move)`() {
        val row = TableRow(1, mapOf("Base Power" to 0L, "Accuracy" to 0L, "PP" to 35L))
        assertFalse(UnusedSlotDetector.isUnusedMoveSlot(row, moveName = "GROWL"))
    }
}
