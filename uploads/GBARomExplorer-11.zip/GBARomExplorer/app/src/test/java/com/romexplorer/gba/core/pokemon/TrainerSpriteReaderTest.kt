package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TrainerSpriteReaderTest {

    private fun le32Pointer(fileOffset: Long): ByteArray {
        val romAddr = (fileOffset + 0x08000000L).toInt()
        return byteArrayOf(
            (romAddr and 0xFF).toByte(),
            ((romAddr shr 8) and 0xFF).toByte(),
            ((romAddr shr 16) and 0xFF).toByte(),
            ((romAddr shr 24) and 0xFF).toByte(),
        )
    }

    @Test
    fun `reads a trainer sprite by its Trainer Pic index, from compressed sprite and palette`() = runBlocking {
        val data = ByteArray(0x400000)
        val picIndex = 12
        val spriteOffset = 0x300000L
        val paletteOffset = 0x310000L

        val rawSprite = ByteArray(2048).also { it[0] = 0x21 } // 64x64 4bpp
        Lz77Codec.compress(rawSprite).copyInto(data, spriteOffset.toInt())

        val rawPalette = ByteArray(32)
        rawPalette[2] = 0xFF.toByte()
        rawPalette[3] = 0x7F // palette index 1 -> 0x7FFF (white)
        Lz77Codec.compress(rawPalette).copyInto(data, paletteOffset.toInt())

        le32Pointer(spriteOffset).copyInto(data, (0x23957CL + picIndex * 8L).toInt())
        le32Pointer(paletteOffset).copyInto(data, (0x239A1CL + picIndex * 8L).toInt())

        val rom = ByteArrayRomAccessor(data)
        val image = TrainerSpriteReader.read(rom, picIndex)

        assertEquals(64, image?.width)
        assertEquals(0xFFFFFFFF.toInt(), image?.pixels?.get(0))
    }

    @Test
    fun `returns null when the Trainer Pic index is out of the known 0-147 range`() = runBlocking {
        val rom = ByteArrayRomAccessor(ByteArray(64))

        assertNull(TrainerSpriteReader.read(rom, 200))
        assertNull(TrainerSpriteReader.read(rom, -1))
    }
}
