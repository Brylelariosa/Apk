package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CorruptedPartyScannerTest {

    private val trainerTableOffset = FireRedTables.trainers.romOffset
    private val trainerEntrySize = 40 // see FireRedTables.trainers' field layout
    private val speciesNamesOffset = FireRedTables.SPECIES_NAMES_OFFSET
    private val speciesNameLength = FireRedTables.SPECIES_NAME_LENGTH

    /** A ROM sized to actually reach every fixed offset this scanner depends on, with real species names populated for ids 1 and 2. */
    private fun baseRom(): ByteArray {
        val size = 4_000_000
        val data = ByteArray(size)
        writeSpeciesName(data, 1, "PIDGEY")
        writeSpeciesName(data, 2, "RATTATA")
        writeSpeciesName(data, 3, "??????????") // a real reserved-slot placeholder, same convention FireRed itself uses
        // id 0 and everything else stay blank/zeroed, matching a real unused species table slot
        return data
    }

    private fun writeSpeciesName(data: ByteArray, speciesId: Int, name: String) {
        val encoded = PokemonTextCodec.encode(name, speciesNameLength)
        encoded.copyInto(data, (speciesNamesOffset + speciesId.toLong() * speciesNameLength).toInt())
    }

    private fun le32(value: Long): ByteArray {
        val v = value.toInt()
        return byteArrayOf((v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte(), ((v shr 16) and 0xFF).toByte(), ((v shr 24) and 0xFF).toByte())
    }

    /** Writes one trainer row — party flags 0 (no item, no custom moves — plain iv/lvl/species entries). */
    private fun writeTrainerRow(data: ByteArray, rowIndex: Int, partySize: Int, partyPointer: Long) {
        val base = (trainerTableOffset + rowIndex.toLong() * trainerEntrySize).toInt()
        data[base] = 0 // party flags
        data[base + 32] = partySize.toByte()
        le32(partyPointer).copyInto(data, base + 36)
    }

    /** Writes [members] as plain 6-byte (iv/lvl/species) entries at [partyPointer]. */
    private fun writePlainParty(data: ByteArray, partyPointer: Long, members: List<Pair<Int, Int>>) {
        members.forEachIndexed { i, (species, level) ->
            val base = (partyPointer + i * 6L).toInt()
            data[base + 2] = level.toByte()
            le32(species.toLong()).copyInto(data, base + 4, 0, 2) // species is only 2 bytes, but le32 gives 4 — take the low 2
        }
    }

    @Test
    fun `a trainer with an entirely plausible party is never flagged`() = runBlocking {
        val data = baseRom()
        writeTrainerRow(data, 0, partySize = 2, partyPointer = 3_000_000L)
        writePlainParty(data, 3_000_000L, listOf(1 to 12, 2 to 14)) // Pidgey Lv.12, Rattata Lv.14
        val rom = ByteArrayRomAccessor(data)

        val result = CorruptedPartyScanner.scan(rom, overlay = null)

        assertTrue(result.none { it.trainerRowIndex == 0 })
    }

    @Test
    fun `flags a level-0 member as suspicious, regardless of which trainer or species it is`() = runBlocking {
        val data = baseRom()
        writeTrainerRow(data, 0, partySize = 2, partyPointer = 3_000_000L)
        writePlainParty(data, 3_000_000L, listOf(1 to 12, 2 to 0)) // second member level 0 — the reported symptom
        val rom = ByteArrayRomAccessor(data)

        val result = CorruptedPartyScanner.scan(rom, overlay = null)

        val trainer = result.single { it.trainerRowIndex == 0 }
        assertEquals(1, trainer.members.size)
        assertEquals(1, trainer.members[0].memberIndex)
        assertTrue(trainer.members[0].reason.contains("level 0"))
    }

    @Test
    fun `flags a species that resolves to the reserved-slot placeholder name`() = runBlocking {
        val data = baseRom()
        writeTrainerRow(data, 0, partySize = 2, partyPointer = 3_000_000L)
        writePlainParty(data, 3_000_000L, listOf(1 to 12, 3 to 48)) // second member: valid level, but species #3 is "??????????"
        val rom = ByteArrayRomAccessor(data)

        val result = CorruptedPartyScanner.scan(rom, overlay = null)

        val trainer = result.single { it.trainerRowIndex == 0 }
        assertEquals(1, trainer.members.size)
        assertTrue(trainer.members[0].reason.contains("reserved"))
    }

    @Test
    fun `never flags a genuinely unused species slot as a problem on its own — only when a trainer actually has it`() = runBlocking {
        // id 50 has no name at all (blank) and is never referenced by any
        // trainer here — a real unused table slot, not a corrupted party.
        val data = baseRom()
        writeTrainerRow(data, 0, partySize = 1, partyPointer = 3_000_000L)
        writePlainParty(data, 3_000_000L, listOf(1 to 12))
        val rom = ByteArrayRomAccessor(data)

        val result = CorruptedPartyScanner.scan(rom, overlay = null)

        assertTrue(result.none { it.trainerRowIndex == 0 })
    }

    @Test
    fun `only flags the trainers that actually have a problem, not every trainer in the table`() = runBlocking {
        val data = baseRom()
        writeTrainerRow(data, 0, partySize = 1, partyPointer = 3_000_000L)
        writePlainParty(data, 3_000_000L, listOf(1 to 12)) // fine
        writeTrainerRow(data, 1, partySize = 1, partyPointer = 3_100_000L)
        writePlainParty(data, 3_100_000L, listOf(2 to 0)) // corrupted
        val rom = ByteArrayRomAccessor(data)

        val result = CorruptedPartyScanner.scan(rom, overlay = null)

        assertEquals(listOf(1), result.map { it.trainerRowIndex })
    }
}
