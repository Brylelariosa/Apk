package com.romexplorer.gba.core.rom

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RomHeaderParserTest {

    /** Builds a syntactically valid 192-byte GBA header with a correct checksum. */
    private fun buildValidHeader(title: String = "TESTGAME", gameCode: String = "ABCE", makerCode: String = "01"): ByteArray {
        val header = ByteArray(0xC0)
        // Entry point: a standard ARM branch opcode (0xEA......) so boot mode reads as STANDARD_CARTRIDGE.
        header[3] = 0xEA.toByte()

        title.toByteArray().copyInto(header, 0xA0)
        gameCode.toByteArray().copyInto(header, 0xAC)
        makerCode.toByteArray().copyInto(header, 0xB0)
        header[0xB2] = 0x96.toByte() // fixed value
        header[0xBC] = 1 // version

        // Fill the logo region with non-zero bytes so it's not flagged as blank.
        for (i in 0x04..0x9F) header[i] = 0x24

        var sum = 0
        for (i in 0xA0..0xBC) sum += header[i].toInt() and 0xFF
        header[0xBD] = ((0 - (sum + 0x19)) and 0xFF).toByte()

        return header
    }

    @Test
    fun `parses title game code and maker code`() = runBlocking {
        val rom = ByteArrayRomAccessor(buildValidHeader())
        val (header, warnings) = RomHeaderParser.parse(rom)

        assertEquals("TESTGAME", header.title)
        assertEquals("ABCE", header.gameCode)
        assertEquals("01", header.makerCode)
        assertTrue(warnings.isEmpty())
    }

    @Test
    fun `flags invalid header checksum`() = runBlocking {
        val bytes = buildValidHeader()
        bytes[0xBD] = (bytes[0xBD] + 1).toByte() // corrupt the checksum
        val rom = ByteArrayRomAccessor(bytes)

        val (header, warnings) = RomHeaderParser.parse(rom)

        assertTrue(!header.headerChecksumValid)
        assertTrue(warnings.any { it is RomWarning.InvalidHeaderChecksum })
    }

    @Test
    fun `flags invalid fixed byte`() = runBlocking {
        val bytes = buildValidHeader()
        bytes[0xB2] = 0x00
        val rom = ByteArrayRomAccessor(bytes)

        val (header, _) = RomHeaderParser.parse(rom)

        assertTrue(!header.fixedByteValid)
    }

    @Test
    fun `flags blank logo region`() = runBlocking {
        val bytes = buildValidHeader()
        for (i in 0x04..0x9F) bytes[i] = 0
        // Recompute checksum unaffected since logo bytes are outside 0xA0-0xBC.
        val rom = ByteArrayRomAccessor(bytes)

        val (header, warnings) = RomHeaderParser.parse(rom)

        assertTrue(!header.logoRegionPresent)
        assertTrue(warnings.any { it is RomWarning.EmptyLogoRegion })
    }

    @Test
    fun `detects standard cartridge boot mode from branch entry point`() = runBlocking {
        val rom = ByteArrayRomAccessor(buildValidHeader())
        val (header, _) = RomHeaderParser.parse(rom)
        assertEquals(BootMode.STANDARD_CARTRIDGE, header.bootMode)
    }
}
