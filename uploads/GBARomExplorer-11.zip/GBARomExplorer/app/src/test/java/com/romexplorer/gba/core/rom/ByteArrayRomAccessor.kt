package com.romexplorer.gba.core.rom

/** Pure-JVM [RomAccessor] backed by an in-memory array, used only in unit
 * tests so core logic (parsers, analyzers, codecs) can be tested without
 * any Android framework dependency. */
class ByteArrayRomAccessor(private val data: ByteArray) : RomAccessor {
    override val sizeBytes: Long = data.size.toLong()

    override suspend fun read(romOffset: Long, length: Int): ByteArray {
        if (romOffset >= sizeBytes) return ByteArray(0)
        val end = minOf(romOffset + length, sizeBytes).toInt()
        return data.copyOfRange(romOffset.toInt(), end)
    }

    override suspend fun readInto(buffer: ByteArray, romOffset: Long, length: Int): Int {
        val bytes = read(romOffset, length)
        bytes.copyInto(buffer)
        return bytes.size
    }

    override suspend fun readByte(romOffset: Long): Int {
        if (romOffset < 0 || romOffset >= sizeBytes) return -1
        return data[romOffset.toInt()].toInt() and 0xFF
    }

    override fun close() = Unit
}
