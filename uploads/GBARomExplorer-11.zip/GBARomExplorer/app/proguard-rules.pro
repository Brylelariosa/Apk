# Minification is enabled for release builds (see build.gradle.kts). This
# project is built and shipped via CI without an attached device, so these
# rules are correct on paper (standard, documented rules for the two
# reflection-sensitive libraries this app uses) but have NOT been verified
# against an actual installed release build. Sideload/smoke-test a release
# APK before shipping - if something breaks at runtime rather than at build
# time, it's almost certainly a missing keep rule for a class R8 couldn't
# see was needed.

# --- kotlinx.serialization ---
# Standard rules from kotlinx.serialization's own documentation: keep each
# @Serializable class's generated serializer and Companion accessor. Scoped
# to this app's own package since that's where every @Serializable class
# lives (RomRegion, HexBookmark, and the recent-ROMs list entry).
-keepattributes InnerClasses
-keepattributes RuntimeVisibleAnnotations, AnnotationDefault
-if @kotlinx.serialization.Serializable class com.romexplorer.gba.**
-keepclassmembers class <1> {
    static <1>$Companion Companion;
}
-if @kotlinx.serialization.Serializable class com.romexplorer.gba.** {
    static **$Companion Companion;
}
-keepclassmembers class <1>$Companion {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.romexplorer.gba.**$$serializer { *; }

# --- Koin ---
# Koin resolves dependencies by type at runtime rather than via classpath
# scanning, so it generally shrinks safely - these are the conservative,
# commonly-recommended rules to avoid it losing type information.
-keepattributes *Annotation*
-keep class org.koin.** { *; }
-keep class kotlin.reflect.** { *; }
-dontwarn org.koin.**
