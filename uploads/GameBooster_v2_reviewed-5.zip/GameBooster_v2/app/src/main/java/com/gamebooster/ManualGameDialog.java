package com.gamebooster;

import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.FragmentActivity;

/**
 * Dialog that lets the user add a game by typing its package name directly —
 * no need to scroll through the installed-apps list.
 *
 * <p>As the user types, it tries to resolve the package live and shows
 * the app icon + label if found on the device, or a "not installed" note
 * if the package name is custom / the game isn't installed.
 *
 * <p>Both paths produce a valid {@link AppInfo} so the boost can start:
 * <ul>
 *   <li>Package found on device → full label + icon</li>
 *   <li>Package not found → package name used as label, default icon</li>
 * </ul>
 */
public final class ManualGameDialog {

    public interface OnGameAdded {
        void onAdded(AppInfo app);
    }

    private ManualGameDialog() {}

    public static void show(FragmentActivity activity, OnGameAdded callback) {
        View view = LayoutInflater.from(activity)
            .inflate(R.layout.dialog_manual_game, null);

        EditText   etPackage  = view.findViewById(R.id.et_package_name);
        ImageView  ivPreview  = view.findViewById(R.id.iv_preview_icon);
        TextView   tvPreview  = view.findViewById(R.id.tv_preview_label);
        TextView   tvStatus   = view.findViewById(R.id.tv_pkg_status);

        // Live preview as the user types
        etPackage.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                updatePreview(activity, s.toString().trim(),
                    ivPreview, tvPreview, tvStatus);
            }
        });

        // Set hint / default state
        tvPreview.setText("Enter a package name below");
        tvStatus.setText("");
        ivPreview.setImageResource(R.drawable.ic_gamepad);

        AlertDialog dialog = new AlertDialog.Builder(activity)
            .setTitle("Add Game Manually")
            .setView(view)
            .setPositiveButton("Add", null) // set below to prevent auto-dismiss on error
            .setNegativeButton("Cancel", null)
            .create();

        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String pkg = etPackage.getText().toString().trim();
                if (pkg.isEmpty()) {
                    etPackage.setError("Enter a package name");
                    return;
                }
                AppInfo app = resolveApp(activity, pkg);
                if (callback != null) callback.onAdded(app);
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static void updatePreview(FragmentActivity ctx, String pkg,
                                       ImageView icon, TextView label, TextView status) {
        if (pkg.isEmpty()) {
            icon.setImageResource(R.drawable.ic_gamepad);
            label.setText("Enter a package name below");
            status.setText("");
            return;
        }
        try {
            PackageManager pm   = ctx.getPackageManager();
            android.content.pm.ApplicationInfo info =
                pm.getApplicationInfo(pkg, 0);
            String      appLabel = pm.getApplicationLabel(info).toString();
            Drawable    appIcon  = pm.getApplicationIcon(pkg);
            label.setText(appLabel);
            icon.setImageDrawable(appIcon);
            status.setText("✓  Found on this device");
            status.setTextColor(ctx.getResources().getColor(R.color.perm_ok, null));
        } catch (PackageManager.NameNotFoundException e) {
            icon.setImageResource(R.drawable.ic_gamepad);
            label.setText(pkg);
            status.setText("Not installed — will still be added");
            status.setTextColor(ctx.getResources().getColor(R.color.perm_warn, null));
        }
    }

    private static AppInfo resolveApp(FragmentActivity ctx, String pkg) {
        try {
            PackageManager pm   = ctx.getPackageManager();
            android.content.pm.ApplicationInfo info =
                pm.getApplicationInfo(pkg, 0);
            String   label = pm.getApplicationLabel(info).toString();
            Drawable icon  = pm.getApplicationIcon(pkg);
            AppInfo  app   = new AppInfo(label, pkg);
            app.icon = icon;
            return app;
        } catch (PackageManager.NameNotFoundException e) {
            return new AppInfo(pkg, pkg); // use pkg as label fallback
        }
    }
}
