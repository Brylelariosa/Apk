package com.gamebooster;

import android.content.ContentResolver;
import android.content.Context;
import android.provider.Settings;
import android.util.Log;

/**
 * Controls the three-finger screenshot gesture on supported devices.
 *
 * <h3>How it works</h3>
 * The three-finger screenshot is stored in {@link Settings.System} under a
 * manufacturer-specific key. This class tries the known keys in priority order:
 *
 * <ol>
 *   <li>{@code three_finger_shot}         — Infinix / XOS / TECNO (confirmed HOT series)</li>
 *   <li>{@code gesture_three_finger_slide} — MIUI / Xiaomi</li>
 *   <li>{@code screenshot_gesture_enabled} — some Samsung ONE UI builds</li>
 *   <li>{@code palm_swipe_to_capture}      — Samsung standard</li>
 *   <li>{@code three_finger_screenshot}    — generic fallback label</li>
 * </ol>
 *
 * <p>If none of the keys can be written (setting not found or WRITE_SETTINGS
 * not granted), the helper silently returns {@code false} — boost still works,
 * just without this tweak.
 *
 * <h3>Why disable during boost?</h3>
 * In fast-paced games (battle royale, MOBAs) three-finger swipes are common
 * in-game gestures. Accidentally triggering a screenshot causes a brief UI
 * interruption, a notification sound, and can draw focus from the game.
 */
public final class ThreeFingerScreenshotHelper {

    private static final String TAG = "3FingerHelper";

    /** Manufacturer-specific Settings.System keys, tried in priority order. */
    private static final String[] KEYS = {
        "three_finger_shot",           // Infinix XOS (HOT 11 confirmed)
        "gesture_three_finger_slide",  // MIUI / Xiaomi
        "screenshot_gesture_enabled",  // Samsung ONE UI (some builds)
        "palm_swipe_to_capture",       // Samsung standard
        "three_finger_screenshot",     // generic
    };

    /** Value used to ENABLE the gesture (restore on boost-off). */
    private static final int ENABLED  = 1;
    /** Value used to DISABLE the gesture (set on boost-on). */
    private static final int DISABLED = 0;

    /** Key that was successfully written — cached for the restore call. */
    private String activeKey = null;
    /** Original value read before we changed it — restored on stop. */
    private int    savedValue = ENABLED;
    /** Whether we actually changed anything. */
    private boolean applied = false;

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Disables three-finger screenshot if supported.
     * Saves the previous value so it can be restored by {@link #restore(Context)}.
     *
     * @return {@code true} if the setting was successfully disabled.
     */
    public boolean disable(Context ctx) {
        if (!Settings.System.canWrite(ctx)) {
            Log.d(TAG, "WRITE_SETTINGS not granted — skipping");
            return false;
        }
        ContentResolver cr = ctx.getContentResolver();
        for (String key : KEYS) {
            try {
                int current = Settings.System.getInt(cr, key);
                if (current == DISABLED) {
                    // Already off — record but don't spam a write
                    activeKey  = key;
                    savedValue = DISABLED;
                    applied    = false;
                    Log.d(TAG, key + " was already disabled");
                    return true;
                }
                Settings.System.putInt(cr, key, DISABLED);
                activeKey  = key;
                savedValue = current;
                applied    = true;
                Log.i(TAG, "Disabled three-finger screenshot via key: " + key
                    + " (saved value=" + current + ")");
                return true;
            } catch (Settings.SettingNotFoundException ignored) {
                // This key doesn't exist on this device — try next
            } catch (Exception e) {
                Log.w(TAG, "Failed to write key " + key + ": " + e.getMessage());
            }
        }
        Log.d(TAG, "No three-finger screenshot key found on this device");
        return false;
    }

    /**
     * Restores the three-finger screenshot to its original state.
     * Safe to call even if {@link #disable(Context)} was never called or failed.
     */
    public void restore(Context ctx) {
        if (!applied || activeKey == null) return;
        if (!Settings.System.canWrite(ctx)) return;
        try {
            Settings.System.putInt(ctx.getContentResolver(), activeKey, savedValue);
            Log.i(TAG, "Restored " + activeKey + " to " + savedValue);
        } catch (Exception e) {
            Log.w(TAG, "Failed to restore three-finger screenshot", e);
        } finally {
            applied    = false;
            activeKey  = null;
        }
    }

    /**
     * Returns {@code true} if the device appears to support three-finger
     * screenshot via any known Settings.System key.
     * Useful for deciding whether to show the toggle in the UI.
     */
    public static boolean isSupported(Context ctx) {
        ContentResolver cr = ctx.getContentResolver();
        for (String key : KEYS) {
            try {
                Settings.System.getInt(cr, key);
                return true;
            } catch (Settings.SettingNotFoundException ignored) {}
        }
        return false;
    }
}
