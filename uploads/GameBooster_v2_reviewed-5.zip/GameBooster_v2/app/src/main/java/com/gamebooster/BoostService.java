package com.gamebooster;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.List;

/**
 * Foreground service that applies system-level performance boosts.
 *
 * <h3>Fixes in this revision</h3>
 * <ul>
 *   <li>Three-finger screenshot disabled on boost start via
 *       {@link ThreeFingerScreenshotHelper}; restored on stop.</li>
 *   <li>{@code KEY_IS_RUNNING} written with {@code commit()} (synchronous)
 *       not {@code apply()} so the Activity can read it immediately in
 *       {@code onResume} without a race window.</li>
 * </ul>
 */
public class BoostService extends Service {

    private static final String TAG = "BoostService";

    public static final String EXTRA_PACKAGE  = "extra_package_name";
    public static final String EXTRA_LABEL    = "extra_app_label";
    public static final String EXTRA_PROFILE  = "extra_boost_profile";
    public static final String ACTION_STOP    = "com.gamebooster.action.STOP";

    public static final String ACTION_STATE_CHANGED   = "com.gamebooster.STATE_CHANGED";
    public static final String EXTRA_IS_RUNNING       = "is_running";
    public static final String ACTION_THERMAL_WARNING = "com.gamebooster.THERMAL_WARNING";
    public static final String EXTRA_THERMAL_HEADROOM = "thermal_headroom";
    public static final String ACTION_THERMAL_OK      = "com.gamebooster.THERMAL_OK";
    public static final String ACTION_RAM_WARNING     = "com.gamebooster.RAM_WARNING";
    public static final String EXTRA_RAM_FREE_MB      = "ram_free_mb";
    public static final String ACTION_RAM_OK          = "com.gamebooster.RAM_OK";

    private static final int  NOTIFICATION_ID = 1001;

    // SharedPreferences keys
    static final  String PREFS_BOOST       = "boost_service_state";
    public static final String KEY_IS_RUNNING    = "service_running";
    private static final String KEY_DND_APPLIED  = "dnd_applied";
    private static final String KEY_DND_FILTER   = "dnd_saved_filter";

    // Timing
    private static final long WAKELOCK_MAX_MS        = 3 * 60 * 60 * 1000L;
    private static final long MONITOR_INTERVAL_MS    = 5_000L;
    private static final long THERMAL_INTERVAL_MS    = 10_000L;
    private static final long GAME_INACTIVE_TIMEOUT  = 120_000L;
    private static final long USAGE_LOOKBACK_MS      = GAME_INACTIVE_TIMEOUT + 30_000L;
    private static final float THERMAL_WARN_LEVEL    = 0.80f;
    private static final long  RAM_WARN_MB           = 600L;

    // Fields
    private String                gamePackage;
    private String                appLabel;
    private BoostProfile          profile;
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock  wifiLock;
    private HandlerThread         monitorThread;
    private Handler               monitorHandler;
    private ThreeFingerScreenshotHelper threeFingerHelper;

    private int     savedBrightness     = -1;
    private boolean brightnessApplied   = false;
    private boolean thermalWarningActive = false;
    private boolean ramWarningActive     = false;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        monitorThread = new HandlerThread("GameBoosterMonitor");
        monitorThread.start();
        monitorHandler = new Handler(monitorThread.getLooper());
        threeFingerHelper = new ThreeFingerScreenshotHelper();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        gamePackage = intent != null ? intent.getStringExtra(EXTRA_PACKAGE) : null;
        appLabel    = intent != null ? intent.getStringExtra(EXTRA_LABEL)   : null;

        if (gamePackage == null || gamePackage.isEmpty()) {
            Log.w(TAG, "No EXTRA_PACKAGE — stopping.");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (appLabel == null || appLabel.isEmpty()) appLabel = resolveLabel(gamePackage);
        profile = parseProfile(intent.getStringExtra(EXTRA_PROFILE));

        startForeground(NOTIFICATION_ID, buildNotification());

        // FIX: use commit() (synchronous) so Activity reads the flag immediately
        // in onResume — apply() is async and creates a race window of ~10-50 ms
        // where onResume reads the old value and incorrectly resets the UI.
        setRunningFlag(true);
        broadcastState(true);

        if (profile.enableWakeLock)      acquireWakeLock();
        if (profile.enableWifiLock)      acquireWifiLock();
        if (profile.enableDnd)           applyDnd();
        if (profile.enableMaxBrightness) applyMaxBrightness();

        // Disable three-finger screenshot to prevent accidental triggers in-game
        threeFingerHelper.disable(this);

        monitorHandler.postDelayed(monitorRunnable, MONITOR_INTERVAL_MS);
        monitorHandler.postDelayed(thermalRunnable, THERMAL_INTERVAL_MS);

        Log.i(TAG, "Boost started — " + gamePackage + " [" + profile.name() + "]");
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        setRunningFlag(false);
        broadcastState(false);

        monitorHandler.removeCallbacksAndMessages(null);
        monitorThread.quitSafely();

        releaseWakeLock();
        releaseWifiLock();
        restoreDnd();
        restoreBrightness();
        threeFingerHelper.restore(this);  // restore three-finger screenshot

        Log.i(TAG, "Boost stopped — all settings restored.");
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    // ── Notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        PendingIntent openApp = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopPi = PendingIntent.getService(this, 1,
            new Intent(this, BoostService.class).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, App.BOOST_CHANNEL_ID)
            .setContentTitle("GameBooster Active")
            .setContentText("Boosting " + appLabel + "  ·  "
                + (profile != null ? profile.displayName : "Balanced"))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    // ── WakeLock ──────────────────────────────────────────────────────────────

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GameBooster:boost");
            wakeLock.acquire(WAKELOCK_MAX_MS);
        } catch (Exception e) { Log.w(TAG, "WakeLock failed", e); }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }

    // ── WifiLock ──────────────────────────────────────────────────────────────

    private void acquireWifiLock() {
        try {
            WifiManager wm = (WifiManager)
                getApplicationContext().getSystemService(WIFI_SERVICE);
            wifiLock = wm.createWifiLock(
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "GameBooster:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception e) { Log.w(TAG, "WifiLock failed", e); }
    }

    private void releaseWifiLock() {
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        wifiLock = null;
    }

    // ── DND ───────────────────────────────────────────────────────────────────

    private void applyDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) return;
        int current = nm.getCurrentInterruptionFilter();
        getSharedPreferences(PREFS_BOOST, MODE_PRIVATE).edit()
            .putBoolean(KEY_DND_APPLIED, true).putInt(KEY_DND_FILTER, current).apply();
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
    }

    private void restoreDnd() {
        SharedPreferences sp = getSharedPreferences(PREFS_BOOST, MODE_PRIVATE);
        if (!sp.getBoolean(KEY_DND_APPLIED, false)) return;
        int saved = sp.getInt(KEY_DND_FILTER, NotificationManager.INTERRUPTION_FILTER_UNKNOWN);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()
                && saved != NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
            nm.setInterruptionFilter(saved);
        sp.edit().remove(KEY_DND_APPLIED).remove(KEY_DND_FILTER).apply();
    }

    // ── Brightness ────────────────────────────────────────────────────────────

    private void applyMaxBrightness() {
        if (!Settings.System.canWrite(this)) return;
        try {
            savedBrightness = Settings.System.getInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);
            brightnessApplied = true;
        } catch (Settings.SettingNotFoundException e) { Log.w(TAG, "Brightness read failed", e); }
    }

    private void restoreBrightness() {
        if (!brightnessApplied || savedBrightness < 0) return;
        if (Settings.System.canWrite(this))
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, savedBrightness);
        brightnessApplied = false;
    }

    // ── Game monitor ──────────────────────────────────────────────────────────

    private final Runnable monitorRunnable = new Runnable() {
        @Override public void run() {
            if (!isGameRecentlyActive()) { stopSelf(); return; }
            monitorHandler.postDelayed(this, MONITOR_INTERVAL_MS);
        }
    };

    private boolean isGameRecentlyActive() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY, now - USAGE_LOOKBACK_MS, now);
        if (stats == null || stats.isEmpty()) return true;
        for (UsageStats s : stats)
            if (gamePackage.equals(s.getPackageName()))
                return (now - s.getLastTimeUsed()) < GAME_INACTIVE_TIMEOUT;
        return false;
    }

    // ── Thermal + RAM monitor ─────────────────────────────────────────────────

    private final Runnable thermalRunnable = new Runnable() {
        @Override public void run() {
            checkThermal();
            checkRam();
            monitorHandler.postDelayed(this, THERMAL_INTERVAL_MS);
        }
    };

    private void checkThermal() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            float headroom = pm.getThermalHeadroom(10);
            if (headroom >= THERMAL_WARN_LEVEL && !thermalWarningActive) {
                thermalWarningActive = true;
                broadcast(new Intent(ACTION_THERMAL_WARNING)
                    .putExtra(EXTRA_THERMAL_HEADROOM, headroom));
            } else if (headroom < THERMAL_WARN_LEVEL - 0.05f && thermalWarningActive) {
                thermalWarningActive = false;
                broadcast(new Intent(ACTION_THERMAL_OK));
            }
        } catch (Exception ignored) {}
    }

    private void checkRam() {
        try {
            android.app.ActivityManager am =
                (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi =
                new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long freeMb = mi.availMem / (1024 * 1024);
            if (freeMb < RAM_WARN_MB && !ramWarningActive) {
                ramWarningActive = true;
                broadcast(new Intent(ACTION_RAM_WARNING).putExtra(EXTRA_RAM_FREE_MB, freeMb));
            } else if (freeMb >= RAM_WARN_MB + 50 && ramWarningActive) {
                ramWarningActive = false;
                broadcast(new Intent(ACTION_RAM_OK));
            }
        } catch (Exception ignored) {}
    }

    // ── SharedPreferences flag ────────────────────────────────────────────────

    /**
     * Uses {@code commit()} (synchronous write) so the Activity can read the flag
     * immediately in {@code onResume()} — {@code apply()} is async and creates a
     * ~10-50 ms window where {@code onResume} reads stale {@code false} and resets the UI.
     */
    private void setRunningFlag(boolean running) {
        getSharedPreferences(PREFS_BOOST, MODE_PRIVATE).edit()
            .putBoolean(KEY_IS_RUNNING, running)
            .commit(); // synchronous — intentional
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void broadcastState(boolean running) {
        broadcast(new Intent(ACTION_STATE_CHANGED).putExtra(EXTRA_IS_RUNNING, running));
    }

    private void broadcast(Intent intent) {
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private String resolveLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) { return pkg; }
    }

    private static BoostProfile parseProfile(String name) {
        if (name == null) return BoostProfile.BALANCED;
        try { return BoostProfile.valueOf(name); }
        catch (IllegalArgumentException e) { return BoostProfile.BALANCED; }
    }
}
