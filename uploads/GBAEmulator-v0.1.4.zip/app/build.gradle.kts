import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.gbaemu.app"
    compileSdk = 36
    ndkVersion = "25.2.9519653"

    defaultConfig {
        applicationId = "com.gbaemu.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 5
        versionName = "0.1.4"

        // Keep the emulator core interpreter loop off the debuggable/JVM path —
        // it's a pure C++ target, no JVM instrumentation needed here.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-fno-exceptions", "-fno-rtti")
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            // Both root causes of the earlier instant-crash (a package-name
            // mismatch, then a CPU addressing bug) are fixed and confirmed
            // unrelated to R8 — safe to turn shrinking back on. This is the
            // single biggest APK-size lever available: it strips unused code
            // out of the Compose/AndroidX dependency graph, not anything of
            // ours. proguard-rules.pro keeps the one thing R8 can't see on
            // its own (the JNI-called EmulatorCore class).
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            externalNativeBuild {
                cmake {
                    // Release core still ships assertions off but keeps symbols for native crash reports.
                    arguments += listOf("-DCMAKE_BUILD_TYPE=Release")
                }
            }
        }
        debug {
            isDebuggable = true
            externalNativeBuild {
                cmake {
                    arguments += listOf("-DCMAKE_BUILD_TYPE=Debug", "-DGBA_CORE_DEBUG=1")
                }
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        jniLibs {
            // Compressed = smaller .apk file (what "APK size" usually means).
            // Trade-off: libs get extracted to app storage at install time
            // instead of being mapped straight out of the APK, so on-device
            // footprint is slightly larger and installs are a touch slower.
            // Flip to false if you'd rather optimize that side instead.
            useLegacyPackaging = true
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = JvmTarget.JVM_17
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.04.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
