# Keep our own components (used from manifest)
-keep class com.example.floatingnote.MainActivity { *; }
-keep class com.example.floatingnote.FloatingNoteService { *; }

# Keep AppCompat classes
-keep class androidx.appcompat.** { *; }
-dontwarn androidx.appcompat.**