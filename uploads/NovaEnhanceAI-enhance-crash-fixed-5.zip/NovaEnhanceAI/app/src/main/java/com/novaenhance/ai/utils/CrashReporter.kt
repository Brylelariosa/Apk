package com.novaenhance.ai.utils

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val TAG = "CrashReporter"
private const val CRASH_FILE_NAME = "last_crash.txt"

/**
 * Persists the next uncaught exception to disk before the process dies, so
 * it survives the crash and can be inspected afterwards - unlike [NovaLog]'s
 * history, which is purely in-memory and is gone the moment the process is.
 * [install] should be called once, as early as possible, from
 * [com.novaenhance.ai.NovaEnhanceApplication.onCreate].
 *
 * Deliberately does not swallow the crash: it writes the report, then
 * always rethrows to whichever handler was previously installed (normally
 * the platform's own), so the app still crashes exactly as it would
 * without this. This only adds a persisted record of what happened.
 *
 * [pendingCrashReport] is meant to be picked up by the caller of
 * [DiagnosticsReport.build] on the next launch and folded into the same
 * plain-text report already copyable from Settings - no new screen needed
 * to retrieve it, no adb/file-manager access required.
 */
object CrashReporter {

    private val timestampFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private var appContext: Context? = null

    fun install(context: Context) {
        appContext = context.applicationContext
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrashFile(thread, throwable)
            } catch (writeFailure: Throwable) {
                // Writing the report failing must never be why the crash
                // itself fails to propagate - log and fall through either way.
                Log.e(TAG, "Failed writing crash report", writeFailure)
            }
            previousHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrashFile(thread: Thread, throwable: Throwable) {
        val context = appContext ?: return
        val report = buildString {
            appendLine("Crashed: ${timestampFormat.format(Date(System.currentTimeMillis()))}")
            appendLine("Thread: ${thread.name}")
            appendLine(
                "Device: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
                    "${Build.MANUFACTURER} ${Build.MODEL}"
            )
            appendLine()
            appendLine(Log.getStackTraceString(throwable))
            appendLine("--- Recent activity leading up to the crash (most recent last) ---")
            val history = NovaLog.recentHistory()
            if (history.isEmpty()) {
                appendLine("(none this session)")
            } else {
                history.forEach { appendLine(it) }
            }
        }
        File(context.filesDir, CRASH_FILE_NAME).writeText(report)
    }

    /** Contents of the last persisted crash, if any - see [DiagnosticsReport.build]. */
    fun pendingCrashReport(): String? {
        val file = File((appContext ?: return null).filesDir, CRASH_FILE_NAME)
        return if (file.exists()) file.readText() else null
    }
}
