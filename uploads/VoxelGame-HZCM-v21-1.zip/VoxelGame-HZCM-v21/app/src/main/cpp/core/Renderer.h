#pragma once
// ============================================================================
// HZCM v13 — Renderer.h
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include "Camera.h"
#include "World.h"
#include "DebugOverlay.h"

class Renderer {
public:
    Camera camera;
    World  world;
    bool   initialized = false;

    // Exposed so jni_bridge can read current FPS for nativeGetDebugStats()
    float  currentFps  = 60.f;

    void init();
    void resize(int width, int height);
    void render(float dt);
    ~Renderer();

    // Forward console commands to the world's render distance system
    bool sendCommand(const char* cmd) { return world.parseCommand(cmd); }

    // ── Debug overlay ─────────────────────────────────────────────────────────
    DebugOverlay& debugOverlay()             { return m_debugOverlay; }
    const DebugOverlay& debugOverlay() const { return m_debugOverlay; }

private:
    // ── Debug overlay (state + stats cache) ──────────────────────────────────
    DebugOverlay m_debugOverlay;
    float        m_fpsEma     = 60.f;   // EMA for stable FPS display

    // Main cluster shader (texture-atlas driven — v21)
    GLuint m_prog    = 0;
    GLint  m_uMVP    = -1;
    GLint  m_uCamPos = -1;
    GLint  m_uOrigin = -1;
    // OPT v17: cache fog uniform location — glGetUniformLocation() does a
    // driver string-table lookup and must never be called in the hot render
    // loop.  Was called every frame, costing ~0.1–0.3 ms per frame on ARM Mali.
    GLint  m_uFogEnd = -1;

    // v21: Texture atlas (GL_TEXTURE_2D_ARRAY, 20 layers of 16×16 RGBA8)
    GLuint m_atlasTexture = 0;
    GLint  m_uAtlas       = -1;

    // HUD shader (crosshair)
    GLuint m_hudProg = 0;
    GLuint m_hudVao  = 0;
    GLuint m_hudVbo  = 0;

    // Debug overlay shader (render-distance / thermal HUD via coloured quads)
    GLuint m_dbgProg = 0;
    GLuint m_dbgVao  = 0;
    GLuint m_dbgVbo  = 0;

    // VAO for cluster draws (attribute layout set once per frame)
    GLuint m_clusterVao = 0;

    static constexpr float SKY_R = 0.52f, SKY_G = 0.77f, SKY_B = 0.95f;

    GLuint compileShader(GLenum type, const char* src);
    GLuint linkProgram  (GLuint vert, GLuint frag);
    void   initHUD();
    void   initDebugOverlay();
    void   initAtlas();       // v21: build + upload procedural texture atlas
    void   renderHUD();
    void   renderDebugOverlay();
};
