# Refactoring Notes

Original `GameView.java` was **5 680 lines** — a single God Class containing
world data, physics, rendering, AI, networking, shop, HUD, and input.

---

## New files

| File | Lines | What moved there |
|------|------:|-----------------|
| `MapData.java` | 69 | `MAP_W/H`, `PR`, `RESPAWN_MS`, `WALLS[][]`, `SPAWNS[][]`, `DUMMY_*` |
| `PhysicsSystem.java` | 190 | `walls()`, `hasLos()`, `dashWithWallStop()`, `moveBotWithCollision()`, `resolvePlayerCollisions()`, `lerpAngle()`, `d2()`, `clamp()` |
| `GameConstants.java` | 58 | `AS_RADIUS/DAMAGE/WARNING_MS`, `EBURST_*`, `GUN_PRICES`, `GUN_NAMES`, `GUN_COLORS`, `PASSIVE/ACTIVE_SKILL_COSTS`, `SHOP_ROW_H/GAP` |
| `BotController.java` | 143 | `doBotShopping()` → `doShopping()`, `doBotUseSkill()` → `doUseSkill()` |

All three constants classes are **static-imported** in `GameView`:

```java
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;
```

Every existing call site (`MAP_W`, `walls(ox,oy,nx,ny)`, `GUN_PRICES[i]`, …)
compiles unchanged — zero mechanical churn in `GameView`.

---

## GameView.java changes

### GC / allocation fixes (60 Hz render loop)

**Before:** `fill()` allocated a `new Paint()` on every call.  
**After:** Reuses `_fillScratch` — safe because drawing is single-threaded and
each `Canvas.drawXxx()` consumes the paint before `fill()` is called again.

**Before:** 70+ `new Paint()` calls inside draw methods that run every frame.  
**After:** All pre-allocated as named fields, configured once in `initPaints()`.

Pre-allocated paint groups added:

- `ddBombShadow/Fly/DangerFill/DangerRing/Emoji/Dot` — bomb world-draw
- `ddAsReloadRing/Lbl`, `ddAsAimRing/Conn/Prev/Xh` — air-strike aim UI
- `ddAsDangerRing/Warn/Cross` — air-strike warning
- `ddRopeOuter/Inner/Highlight`, `ddChainGlow/Dark/Light` — rope & chain
- `dpCharge/Tip/SbCharge/SbTick/SbTip/Tier/Soul/SbLbl` — player draw
- `uiP`, `uiTxt`, `uiCopy` — scratch paints for UI overlays (shop, settings,
  weapon wheel). `uiCopy.set(existingPaint)` replaces every
  `new Paint(existingPaint)` copy-constructor call in UI methods.

### Physics method delegation

The eight physics methods were **removed** from GameView and replaced by
`PhysicsSystem` static calls. The one instance-state method
(`resolvePlayerCollisions`) was updated to accept the player list explicitly:

```java
// before  — called with implicit GameView state
resolvePlayerCollisions();

// after  — explicit list, no GameView coupling
collisionPlayers.clear();
if (localPlayer != null && localPlayer.alive) collisionPlayers.add(localPlayer);
for (Player rp : remote.values()) if (rp.alive) collisionPlayers.add(rp);
resolvePlayerCollisions(collisionPlayers);   // PhysicsSystem static import
```

### BotAI.Context callbacks

`GameView.this.hasLos(…)` and `GameView.this.moveBotWithCollision(…)` inside
the anonymous `BotAI.Context` now call `PhysicsSystem` directly:

```java
// before
return GameView.this.hasLos(x1, y1, x2, y2);

// after
return PhysicsSystem.hasLos(x1, y1, x2, y2);
```

Shopping and skill-use callbacks now delegate to `BotController`:

```java
@Override public void doBotShopping(Player bot)                { BotController.doShopping(bot); }
@Override public void doBotUseSkill(Player bot, Player lp, float dist) {
    BotController.doUseSkill(bot, lp, dist, effects, botDashVisual);
}
```

---

## Result

| Metric | Before | After |
|--------|-------:|------:|
| `GameView.java` lines | 5 680 | 5 409 |
| Total source lines | 5 680 | 9 732 |
| `new Paint()` in render loop | 70+ | **0** |
| `new Paint()` in UI overlays | ~30 | **0** |
| Extractable pure functions left in `GameView` | 8 | 0 |
| Bot logic in `GameView` | yes | no |

### What's still in GameView (future work)

- `drawHUD()` / `drawShop()` / `drawSettings()` — ~1 800 lines of UI rendering;
  could move to a `UIRenderer` class once a thin game-state interface is defined.
- `broadcast()` / `applyState()` / `sendInput()` — network serialisation;
  tightly coupled to game state, best deferred until a `GameState` value class exists.
- `updateBots()` — the `BotAI.Context` adapter stays in `GameView` because it
  captures a dozen live game-state references; the actual AI logic is already in
  `BotAI.java` and `BotController.java`.
