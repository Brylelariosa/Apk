package com.game.topdown;

/**
 * All game-balance and layout constants.
 * Extracted from GameView so balance tweaks are one-file edits and
 * so bot/shop/UI code can reference prices without touching the view.
 *
 * GameView uses {@code import static com.game.topdown.GameConstants.*}
 * so all existing call sites compile unchanged.
 */
public final class GameConstants {

    private GameConstants() {}

    // ── Air Strike ────────────────────────────────────────────────────────────
    public static final float AS_RADIUS     = 110f;   // AoE radius per strike (px)
    public static final float AS_DAMAGE     = 28f;    // damage per strike
    public static final long  AS_WARNING_MS = 1500L;  // warning delay before explosion
    public static final long  AS_FLASH_MS   = 350L;   // explosion flash duration
    public static final float AS_RING_R     = 700f;   // aim-ring radius (world px)

    // ── Electric Burst ────────────────────────────────────────────────────────
    public static final float EBURST_RADIUS   = 160f; // AoE radius (also used by EffectsManager)
    public static final float EBURST_DAMAGE   = 18f;  // damage per chain hop
    public static final int   ECHAIN_MAX_HOPS = 3;    // max chain jumps (T8+)

    // ── Shop / Economy ────────────────────────────────────────────────────────
    /** Purchase price for each gun slot (index = gunIndex, 0 = Pistol = free). */
    public static final int[] GUN_PRICES = {
        0, 50, 60, 80, 120, 90, 150, 70, 100, 130,
        110, 140, 160, 120, 85, 130, 110, 145, 170, 200, 130, 180
    };

    /** Cost of each passive-skill level (fire-rate or move-speed). Level 0→1, 1→2, 2→3. */
    public static final int[] PASSIVE_SKILL_COSTS = { 40, 70, 100 };

    /** Cost of each active-skill unlock: dash, stealth, heal, shield. */
    public static final int[] ACTIVE_SKILL_COSTS  = { 80, 100, 80, 90 };

    // ── Shop layout ───────────────────────────────────────────────────────────
    public static final float SHOP_ROW_H   = 46f; // weapon row height (compact)
    public static final float SHOP_ROW_GAP = 2f;  // gap between rows

    // ── Gun display metadata ──────────────────────────────────────────────────
    public static final String[] GUN_NAMES = {
        "Pistol", "SMG", "Shotgun", "Assault", "Sniper", "Burst", "Minigun",
        "Revolver", "LMG", "Plasma", "Bouncer", "Piercer", "Seeker", "Blaster",
        "Ghost", "Paint", "Coin Gun", "V.Chakram", "Hook Spear", "Air Strike",
        "Soul Surge", "Shadow Blade"
    };

    public static final int[] GUN_COLORS = {
        0xFF4FC3F7, 0xFF81C784, 0xFFFF8A65, 0xFFFFB347, 0xFFCE93D8, 0xFF4DD0E1,
        0xFFFF5252, 0xFFFFD54F, 0xFF90A4AE, 0xFF00E5FF, 0xFF69F0AE, 0xFF40C4FF,
        0xFFFF6E40, 0xFFFFD740, 0xFF26C6DA, 0xFFFFD700, 0xFF80D8FF, 0xFFFF8F00,
        0xFFE040FB, 0xFF7B1FA2, 0xFF9C27B0, 0xFFFF1744
    };
}
