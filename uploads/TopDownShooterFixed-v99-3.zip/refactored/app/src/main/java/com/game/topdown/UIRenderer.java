package com.game.topdown;

/**
 * Stub UIRenderer — future work.
 *
 * drawHUD() / drawShop() / drawSettings() (~1 800 lines) will move here
 * once a thin game-state interface is defined (see REFACTORING.md).
 *
 * For now this class holds the entry points called by GameView's touch
 * handler so that the codebase compiles cleanly.
 */
public class UIRenderer {

    /** Handle a tap that may land on the release-fire settings panel. */
    void handleRelFireTap(float x, float y) {
        // TODO: move relFire tap logic here from GameView
    }

    /** Handle a tap that may land on the main settings overlay. */
    void handleSettingsTap(float x, float y) {
        // TODO: move settings tap logic here from GameView
    }

    /** Handle a tap that may land on the shop overlay. */
    void handleShopTap(float x, float y) {
        // TODO: move shop tap logic here from GameView
    }
}
