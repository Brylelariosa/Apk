package com.game.topdown;

import java.util.Map;

import static com.game.topdown.GameConstants.*;
import static com.game.topdown.PhysicsSystem.*;

/**
 * Pure static helpers for bot decision-making.
 * No Android imports; no GameView reference.
 *
 * These were private methods in GameView, called via the BotAI.Context
 * interface. Moving them here makes them testable and keeps GameView
 * free of AI logic.
 */
public final class BotController {

    private BotController() {}

    // ─────────────────────────────────────────────────────────────────────────
    // Shopping
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Spends {@code bot}'s coins according to a fixed priority:
     * best-affordable gun first, then passive fire-rate, then move-speed.
     *
     * Only reads/writes {@link Player} fields and {@link GameConstants} arrays —
     * no game-world state needed.
     */
    public static void doShopping(Player bot) {
        // Guns ranked by combat value (Sniper ▶ Plasma ▶ Assault ▶ Burst …)
        int[] gunPriority = { 4, 9, 3, 5, 7, 8, 1, 2, 6, 17 };

        for (int i : gunPriority) {
            if (!bot.unlockedGuns[i] && bot.coins >= GUN_PRICES[i]) {
                bot.coins -= GUN_PRICES[i];
                // Keep at most one non-default extra gun
                for (int j = 1; j < 7; j++) {
                    if (j != i && bot.unlockedGuns[j]) { bot.unlockedGuns[j] = false; break; }
                }
                bot.unlockedGuns[i] = true;
                bot.gunIndex = i;
                return;
            }
        }

        // Passive: fire-rate first, then move-speed
        if (bot.skillFireRate < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillFireRate]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillFireRate];
            bot.skillFireRate++;
            return;
        }
        if (bot.skillMoveSpeed < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed];
            bot.skillMoveSpeed++;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Skill activation
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Activates {@code bot}'s active skill when conditions are right.
     *
     * @param bot          the bot making the decision
     * @param lp           local (human) player — used for range/LOS checks
     * @param dist         pre-computed squared distance to {@code lp}
     * @param effects      game effects list — receives dash-ghost entries
     * @param botDashVisual per-bot dash-start/end record for smooth rendering
     */
    public static void doUseSkill(
            Player bot, Player lp, float dist,
            EffectsManager effects,
            Map<Integer, float[]> botDashVisual) {

        if (bot.activeSkillType == Player.ACTIVE_NONE)    return;
        if (bot.skillOnCooldown())                         return;

        long now = System.currentTimeMillis();
        Gun  bg  = bot.currentGun();
        float botRange = bg.range * bot.rangeMult();

        switch (bot.activeSkillType) {

            case Player.ACTIVE_HEAL:
                // Heal proactively at 60 HP rather than waiting until critical
                if (bot.hp < 60) {
                    bot.hp = Math.min(100, bot.hp + 40);
                    bot.skillCooldownEnd = now + 12_000L;
                }
                break;

            case Player.ACTIVE_SHIELD:
                if (bot.hp < 80 && !bot.isShielded()) {
                    bot.shieldHp         = 60f;
                    bot.skillActiveUntil = now + 6_000L;
                    bot.skillCooldownEnd = now + 14_000L;
                }
                break;

            case Player.ACTIVE_STEALTH:
                // Bots don't use stealth (confuses their own targeting)
                break;

            case Player.ACTIVE_DASH:
                float angle = Float.NaN;
                if (bot.hp < 35) {
                    // Critically low — flee
                    angle = (float) Math.atan2(bot.y - lp.y, bot.x - lp.x);
                } else if (dist > botRange * 1.6f && dist < botRange * 4f) {
                    // Out of range — close the gap
                    angle = (float) Math.atan2(lp.y - bot.y, lp.x - bot.x);
                }

                if (!Float.isNaN(angle)) {
                    float[] end = dashWithWallStop(bot.x, bot.y, angle, 280f);
                    long nowRel = System.currentTimeMillis() - EffectsManager.FX_EPOCH;

                    float dx = end[0] - bot.x, dy = end[1] - bot.y;
                    float len = (float) Math.sqrt(dx * dx + dy * dy);
                    int ghosts = Math.max(2, (int) (len / 32f));

                    for (int gi = 0; gi <= ghosts; gi++) {
                        float t = (float) gi / ghosts;
                        effects.botDashGhosts.add(new float[]{
                            bot.x + dx * t,
                            bot.y + dy * t,
                            (float) (nowRel - (long) (t * 60f))
                        });
                    }

                    botDashVisual.put(bot.id,
                        new float[]{ bot.x, bot.y, end[0], end[1], (float) nowRel });
                    bot.x = end[0];
                    bot.y = end[1];
                    bot.skillCooldownEnd = now + 6_000L;
                }
                break;
        }
    }
}
