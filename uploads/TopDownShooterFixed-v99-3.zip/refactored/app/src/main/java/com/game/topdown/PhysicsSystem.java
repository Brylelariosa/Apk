package com.game.topdown;

import java.util.List;

/**
 * Pure static physics helpers.  No Android or game-state dependencies —
 * every method is a self-contained function over primitive data.
 *
 * GameView uses {@code import static com.game.topdown.PhysicsSystem.*}
 * so all existing call sites (walls(…), hasLos(…), clamp(…), …) compile
 * unchanged.
 */
public final class PhysicsSystem {

    private PhysicsSystem() {}

    // ── Squared distance ──────────────────────────────────────────────────────

    public static float d2(float ax, float ay, float bx, float by) {
        float dx = ax - bx, dy = ay - by;
        return dx * dx + dy * dy;
    }

    // ── Value clamp ───────────────────────────────────────────────────────────

    public static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // ── Angle lerp (shortest path, handles ±π wrap) ───────────────────────────

    public static float lerpAngle(float from, float to, float t) {
        float d = to - from;
        while (d >  (float) Math.PI) d -= (float) (Math.PI * 2);
        while (d < -(float) Math.PI) d += (float) (Math.PI * 2);
        return from + d * t;
    }

    // ── Circle-vs-AABB wall sliding ───────────────────────────────────────────
    /**
     * Slides a circle of radius {@link MapData#PR} from (ox,oy) toward (nx,ny),
     * resolving collisions against every wall in {@link MapData#WALLS}.
     *
     * Returns the closest reachable position as [x, y].
     */
    public static float[] walls(float ox, float oy, float nx, float ny) {
        final float pr = MapData.PR;
        for (float[] w : MapData.WALLS) {
            float cx  = clamp(nx, w[0], w[2]);
            float cy  = clamp(ny, w[1], w[3]);
            float dSq = d2(nx, ny, cx, cy);
            if (dSq < pr * pr) {
                boolean xBlocked = d2(nx, oy, clamp(nx, w[0], w[2]), clamp(oy, w[1], w[3])) < pr * pr;
                boolean yBlocked = d2(ox, ny, clamp(ox, w[0], w[2]), clamp(ny, w[1], w[3])) < pr * pr;
                if (xBlocked) nx = ox;
                if (yBlocked) ny = oy;
                if (!xBlocked && !yBlocked) {
                    // Corner hit — push the circle to exactly PR from the corner.
                    if (dSq > 0f) {
                        float dist = (float) Math.sqrt(dSq);
                        nx = cx + (nx - cx) / dist * pr;
                        ny = cy + (ny - cy) / dist * pr;
                    } else {
                        nx = ox; ny = oy;   // fully inside — full revert
                    }
                }
            }
        }
        return new float[]{ nx, ny };
    }

    // ── Line-of-sight check ───────────────────────────────────────────────────
    /**
     * Returns {@code true} if no wall occludes the segment (x1,y1)→(x2,y2).
     * Steps along the segment in 25-px increments.
     */
    public static boolean hasLos(float x1, float y1, float x2, float y2) {
        float dx   = x2 - x1, dy = y2 - y1;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        int steps  = Math.max(1, (int) (dist / 25));
        for (int i = 1; i <= steps; i++) {
            float t  = (float) i / steps;
            float px = x1 + dx * t;
            float py = y1 + dy * t;
            for (float[] w : MapData.WALLS) {
                if (px > w[0] && px < w[2] && py > w[1] && py < w[3]) return false;
            }
        }
        return true;
    }

    // ── Dash with wall stop ───────────────────────────────────────────────────
    /**
     * Steps from (startX,startY) along {@code angle} up to {@code maxDist} px,
     * stopping at the last position that does not penetrate any wall.
     * Uses 6-px steps so thin walls (≥35 px) are never tunnelled.
     */
    public static float[] dashWithWallStop(
            float startX, float startY, float angle, float maxDist) {

        final float pr   = MapData.PR;
        final float mapW = MapData.MAP_W;
        final float mapH = MapData.MAP_H;

        // If start clips a wall, nudge it clear so the dash doesn't dead-stop.
        for (float[] w : MapData.WALLS) {
            float csx = clamp(startX, w[0], w[2]);
            float csy = clamp(startY, w[1], w[3]);
            float ddx = startX - csx, ddy = startY - csy;
            if (ddx * ddx + ddy * ddy < pr * pr) {
                startX = clamp(startX + (float) Math.cos(angle) * pr, pr, mapW - pr);
                startY = clamp(startY + (float) Math.sin(angle) * pr, pr, mapH - pr);
                break;
            }
        }

        final float STEP   = 6f;
        int         steps  = Math.max(1, (int) (maxDist / STEP));
        float lastX = startX, lastY = startY;

        for (int i = 1; i <= steps; i++) {
            float testX = clamp(startX + (float) Math.cos(angle) * STEP * i, pr, mapW - pr);
            float testY = clamp(startY + (float) Math.sin(angle) * STEP * i, pr, mapH - pr);
            boolean hit = false;
            for (float[] w : MapData.WALLS) {
                float cx = clamp(testX, w[0], w[2]);
                float cy = clamp(testY, w[1], w[3]);
                float ddx = testX - cx, ddy = testY - cy;
                if (ddx * ddx + ddy * ddy < pr * pr) { hit = true; break; }
            }
            if (hit) break;
            lastX = testX; lastY = testY;
        }
        return new float[]{ lastX, lastY };
    }

    // ── Axis-separated bot movement with wall slide ───────────────────────────
    /**
     * Moves {@code bot} by (moveX, moveY) * speed * dt, testing each axis
     * independently so the bot slides along wall faces rather than stopping dead.
     */
    public static void moveBotWithCollision(
            Player bot, float moveX, float moveY, float speed, float dt) {

        final float pr   = MapData.PR;
        final float mapW = MapData.MAP_W;
        final float mapH = MapData.MAP_H;

        float nx = clamp(bot.x + moveX * speed * dt, pr, mapW - pr);
        float ny = clamp(bot.y + moveY * speed * dt, pr, mapH - pr);

        boolean xOk = true, yOk = true;
        for (float[] w : MapData.WALLS) {
            if (xOk && nx + pr > w[0] && nx - pr < w[2]
                     && bot.y + pr > w[1] && bot.y - pr < w[3]) xOk = false;
            if (yOk && bot.x + pr > w[0] && bot.x - pr < w[2]
                     && ny + pr > w[1] && ny - pr < w[3]) yOk = false;
        }
        if (xOk) bot.x = nx;
        if (yOk) bot.y = ny;
    }

    // ── Player–player push-apart ──────────────────────────────────────────────
    /**
     * Prevents overlapping player circles by pushing them apart.
     * Operates in place on the supplied list; caller builds the list each frame.
     */
    public static void resolvePlayerCollisions(List<Player> players) {
        final float pr    = MapData.PR;
        final float mapW  = MapData.MAP_W;
        final float mapH  = MapData.MAP_H;
        final float minD  = pr * 2f;

        for (int i = 0; i < players.size(); i++) {
            for (int j = i + 1; j < players.size(); j++) {
                Player a = players.get(i), b = players.get(j);
                float dx   = a.x - b.x, dy = a.y - b.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist < minD && dist > 0.5f) {
                    float push = (minD - dist) * 0.5f;
                    float nx   = dx / dist, ny = dy / dist;
                    a.x = clamp(a.x + nx * push, pr, mapW - pr);
                    a.y = clamp(a.y + ny * push, pr, mapH - pr);
                    b.x = clamp(b.x - nx * push, pr, mapW - pr);
                    b.y = clamp(b.y - ny * push, pr, mapH - pr);
                }
            }
        }
    }
}
