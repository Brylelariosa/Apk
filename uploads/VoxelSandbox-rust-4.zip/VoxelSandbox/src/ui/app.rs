//! The application logic that does not depend on the platform: screens, menus and the per-frame glue between
//! touch input and the game. The Android shell feeds it touches and frame times and draws what it produces.

use std::fs;
use std::path::PathBuf;

use super::batch::{rgba, Color, UiBatch};
use super::hud::{self, HudLayout, TapTarget};
use super::touch::{Role, Touches};
use super::widgets::HoldRepeater;
use crate::diag::{Gauges, ScreenKind};
use crate::game::catalog::{self, Category};
use crate::game::engine::GameEngine;
use crate::game::save;
use crate::game::settings::Settings;
use crate::perf::{self, Governor};
use crate::world::block::Block;
use crate::world::pos::ChunkPos;

mod controls;
mod settings_screen;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Screen {
    MainMenu,
    Loading,
    Playing,
    Pause,
    Settings,
    Inventory,
    Crash,
}

/// Where the renderer should put the camera.
#[derive(Clone, Copy, Debug)]
pub struct CameraState {
    pub x: f64,
    pub y: f64,
    pub z: f64,
    pub yaw: f32,
    pub pitch: f32,
    pub underwater: bool,
}

const WHITE: Color = rgba(255, 255, 255, 255);
const GREY: Color = rgba(190, 196, 210, 255);
const GOLD: Color = rgba(255, 214, 102, 255);
const LOADING_TIMEOUT: f32 = 40.0;

pub struct App {
    pub settings: Settings,
    pub engine: Option<GameEngine>,
    pub screen: Screen,
    pub ui: UiBatch,
    pub width: f32,
    pub height: f32,
    pub time: f32,
    pub fps: f32,
    scale: f32,
    layout: HudLayout,
    touches: Touches,
    data_dir: PathBuf,
    settings_return: Screen,
    crash_text: Option<String>,
    inv_tab: usize,
    status: String,
    status_timer: f32,
    loading_time: f32,
    toast: String,
    toast_timer: f32,
    save_exists: bool,
    /// Seconds of the frame being updated (the menus' hold-to-repeat buttons need it).
    dt: f32,
    settings_tab: usize,
    repeat: HoldRepeater,
    /// Where the debug log is being written (or why it is not); set by the platform shell.
    log_status: String,
    /// Extra lines for the FPS overlay (frame breakdown etc.); set by the platform shell about once a second.
    overlay_lines: Vec<String>,
    /// Keeps the frame rate up by lowering the block distance and the resolution when the phone cannot hold 60 fps.
    governor: Governor,
    /// What the game actually runs with: the player's settings, lowered by the governor (see `game_settings`).
    effective: Settings,
    /// The GPU time of a recent frame (from the renderer's timer queries), when the driver can tell.
    gpu_ms: Option<f32>,
    /// The screen at the previous update (the governor only judges frames while playing).
    last_screen: Screen,
    /// The settings the debug log was last told about, so changes can be noted once the settings screen closes.
    noted_settings: Settings,
    /// Things for the debug log (quality decisions, setting changes), taken by the platform shell.
    notes: Vec<String>,
    #[cfg(test)]
    rects: Vec<(String, [f32; 4])>,
}

/// Most notes kept for the debug log if nobody takes them (the platform shell does every frame).
const MAX_NOTES: usize = 24;
/// Where the level the automatic quality control settled on is remembered (see `perf::memory`).
const QUALITY_FILE: &str = "quality.txt";

fn wrap_lines(text: &str, max_chars: usize) -> Vec<String> {
    let mut out = Vec::new();
    for raw in text.lines() {
        let line = raw.trim_end();
        if line.is_empty() {
            out.push(String::new());
            continue;
        }
        let chars: Vec<char> = line.chars().collect();
        let mut i = 0;
        while i < chars.len() {
            let end = (i + max_chars).min(chars.len());
            out.push(chars[i..end].iter().collect());
            i = end;
        }
    }
    out
}

impl App {
    pub fn new(data_dir: PathBuf) -> App {
        let settings = Settings::load(&data_dir.join("settings.txt"));
        let mut governor = Governor::new(settings.detail_radius(), settings.resolution_percent);
        governor.set_enabled(settings.auto_quality);
        if let Some(remembered) = perf::memory::load_quality(&data_dir.join(QUALITY_FILE)) {
            governor.start_at(remembered);
        }
        let effective = settings.with_quality(governor.quality());
        let noted_settings = settings.clone();
        let crash_text = fs::read_to_string(data_dir.join("last_panic.txt")).ok().filter(|t| !t.trim().is_empty());
        let save_exists = save::exists(&data_dir);
        let mut app = App {
            settings,
            engine: None,
            screen: Screen::MainMenu,
            ui: UiBatch::new(),
            width: 1280.0,
            height: 720.0,
            time: 0.0,
            fps: 60.0,
            scale: 2.0,
            layout: HudLayout::compute(1280.0, 720.0, 2.0),
            touches: Touches::new(),
            data_dir,
            settings_return: Screen::MainMenu,
            crash_text,
            inv_tab: 0,
            status: String::new(),
            status_timer: 0.0,
            loading_time: 0.0,
            toast: String::new(),
            toast_timer: 0.0,
            save_exists,
            dt: 0.016,
            settings_tab: 0,
            repeat: HoldRepeater::new(),
            log_status: String::new(),
            overlay_lines: Vec::new(),
            governor,
            effective,
            gpu_ms: None,
            last_screen: Screen::MainMenu,
            noted_settings,
            notes: Vec::new(),
            #[cfg(test)]
            rects: Vec::new(),
        };
        app.resize(1280.0, 720.0);
        app
    }

    /// Tells the settings screen where the debug log is going (shown on the DEBUG tab).
    pub fn set_log_status(&mut self, text: &str) {
        if self.log_status != text {
            self.log_status = text.to_string();
        }
    }

    /// Extra lines drawn under the FPS counter while "SHOW FPS" is on.
    pub fn set_overlay_lines(&mut self, lines: Vec<String>) {
        self.overlay_lines = lines;
    }

    /// The settings the game and the renderer run with right now: what the player chose, with the block distance
    /// and the resolution lowered if "auto performance" had to (it never raises anything above the player's choice).
    pub fn game_settings(&self) -> &Settings {
        &self.effective
    }

    /// The quality level the automatic control chose, and whether that is below what the player allows.
    pub fn auto_quality(&self) -> (perf::Quality, bool) {
        (self.governor.quality(), self.governor.is_reduced())
    }

    /// The renderer reports how long the GPU needed for a recent frame (when it can measure that).
    pub fn note_gpu_ms(&mut self, ms: Option<f32>) {
        self.gpu_ms = ms;
    }

    /// Lines for the debug log (what the automatic quality control did, which settings changed); empties the list.
    pub fn take_notes(&mut self) -> Vec<String> {
        std::mem::take(&mut self.notes)
    }

    fn add_note(&mut self, text: String) {
        if self.notes.len() < MAX_NOTES {
            self.notes.push(text);
        }
    }

    /// Runs the automatic quality control for this frame and works out the settings the game runs with.
    fn update_quality(&mut self, dt: f32) {
        self.governor.set_limits(self.settings.detail_radius(), self.settings.resolution_percent);
        self.governor.set_enabled(self.settings.auto_quality);
        let playing = self.screen == Screen::Playing;
        if playing {
            if self.last_screen != Screen::Playing {
                self.governor.begin_play(self.last_screen == Screen::Loading);
            }
            let gpu = self.gpu_ms;
            if self.governor.observe(dt, gpu) {
                if let Some(change) = self.governor.take_change() {
                    self.add_note(change.describe());
                }
                perf::memory::save_quality(&self.data_dir.join(QUALITY_FILE), self.governor.quality());
            }
        }
        self.last_screen = self.screen;
        self.effective = self.settings.with_quality(self.governor.quality());
        // changes made on the settings screen are noted once, when it is closed
        if self.screen != Screen::Settings && self.settings != self.noted_settings {
            let lines = self.settings.describe_changes(&self.noted_settings);
            for l in lines {
                self.add_note(format!("setting changed: {}", l));
            }
            self.noted_settings = self.settings.clone();
        }
    }

    /// Records a control's rectangle so tests can tap it (does nothing in normal builds).
    #[cfg(test)]
    fn note_rect(&mut self, name: &str, x: f32, y: f32, w: f32, h: f32) {
        self.rects.push((name.to_string(), [x, y, w, h]));
    }

    #[cfg(not(test))]
    #[inline(always)]
    fn note_rect(&mut self, _name: &str, _x: f32, _y: f32, _w: f32, _h: f32) {}

    pub fn resize(&mut self, w: f32, h: f32) {
        if w < 1.0 || h < 1.0 {
            return;
        }
        self.width = w;
        self.height = h;
        self.scale = (h / 360.0).max(1.0);
        self.layout = HudLayout::compute(w, h, self.scale);
    }

    /// Which screen is up, as the debug log names it.
    pub fn screen_kind(&self) -> ScreenKind {
        match self.screen {
            Screen::MainMenu => ScreenKind::Menu,
            Screen::Loading => ScreenKind::Loading,
            Screen::Playing => ScreenKind::Playing,
            Screen::Pause => ScreenKind::Paused,
            Screen::Settings => ScreenKind::Settings,
            Screen::Inventory => ScreenKind::Inventory,
            Screen::Crash => ScreenKind::Other,
        }
    }

    /// What the game is holding and doing right now, for the once-a-second line in the debug log. (The shell adds
    /// what only the renderer knows.)
    pub fn gauges(&self) -> Gauges {
        let mut g = Gauges {
            screen: self.screen_kind(),
            render_distance: self.effective.render_distance,
            detail_radius: self.effective.detail_radius(),
            resolution_percent: self.effective.resolution_percent,
            ..Gauges::default()
        };
        if let Some(e) = self.engine.as_ref() {
            let s = e.manager.stats();
            let chunk = ChunkPos::from_world(e.player.position.x, e.player.position.z);
            g.in_world = true;
            g.chunk_x = chunk.x;
            g.chunk_z = chunk.z;
            g.height = e.player.position.y;
            g.flying = e.player.flying;
            g.underwater = e.underwater;
            g.chunks_loaded = s.loaded;
            g.chunks_meshed = s.meshed;
            g.gen_queue = s.gen_pending;
            g.mesh_queue = s.mesh_in_flight;
            g.jobs_in_flight = s.queued;
            g.workers = s.workers;
            let far = e.far.stats();
            g.far_tiles_ready = far.present;
            g.far_tiles_wanted = far.wanted;
        }
        g
    }

    /// Chunks waiting to be generated and meshes being built (cheap; the debug log notes them with every hitch).
    pub fn queue_sizes(&self) -> (u32, u32) {
        match self.engine.as_ref() {
            Some(e) => {
                let s = e.manager.stats();
                (s.gen_pending, s.mesh_in_flight)
            }
            None => (0, 0),
        }
    }

    /// True while the 3D world should be drawn behind the UI.
    pub fn world_visible(&self) -> bool {
        self.engine.is_some() && self.screen != Screen::MainMenu && self.screen != Screen::Crash
    }

    /// True while the game is paused (the pause menu, or the settings opened from it): nothing in the world moves,
    /// so the renderer may keep the picture instead of drawing the world again every frame.
    pub fn world_frozen(&self) -> bool {
        self.engine.is_some()
            && (self.screen == Screen::Pause || (self.screen == Screen::Settings && self.settings_return == Screen::Pause))
    }

    pub fn camera(&self) -> Option<CameraState> {
        let e = self.engine.as_ref()?;
        Some(CameraState {
            x: e.player.eye_x() as f64,
            y: (e.player.eye_y() + e.bob_offset) as f64,
            z: e.player.eye_z() as f64,
            yaw: e.player.yaw,
            pitch: e.player.pitch,
            underwater: e.underwater,
        })
    }

    // ------------------------------------------------------------------ input from the platform

    pub fn touch_down(&mut self, id: i32, x: f32, y: f32) {
        let role = if self.screen == Screen::Playing {
            let busy = self.touches.active.iter().any(|t| t.role == Role::Joystick);
            self.layout.assign_role(x, y, busy)
        } else {
            Role::None
        };
        self.touches.down(id, x, y, role);
    }

    pub fn touch_move(&mut self, id: i32, x: f32, y: f32) {
        let slop = 12.0 * self.scale;
        self.touches.moved(id, x, y, slop);
    }

    pub fn touch_up(&mut self, id: i32, cancelled: bool) {
        self.touches.up(id, cancelled);
    }

    /// The system back button. Returns true when the app handled it (false lets Android leave the app).
    pub fn back_pressed(&mut self) -> bool {
        match self.screen {
            Screen::Playing => {
                self.go(Screen::Pause);
                true
            }
            Screen::Pause | Screen::Inventory => {
                self.go(Screen::Playing);
                true
            }
            Screen::Settings => {
                self.settings.save(&self.data_dir.join("settings.txt"));
                let back = self.settings_return;
                self.go(back);
                true
            }
            Screen::Crash => {
                self.go(Screen::MainMenu);
                true
            }
            Screen::Loading => true,
            Screen::MainMenu => false,
        }
    }

    /// The app is leaving the foreground: save and pause.
    pub fn on_background(&mut self) {
        self.touches.clear();
        self.repeat.reset();
        if let Some(e) = self.engine.as_mut() {
            e.input.release_all();
        }
        self.settings.save(&self.data_dir.join("settings.txt"));
        if self.engine.is_some() && self.screen != Screen::Loading {
            self.save_game(false);
        }
        if self.screen == Screen::Playing || self.screen == Screen::Inventory {
            self.screen = Screen::Pause;
        }
    }

    // ------------------------------------------------------------------ state changes

    fn go(&mut self, screen: Screen) {
        self.screen = screen;
        self.touches.clear();
        self.repeat.reset();
        if let Some(e) = self.engine.as_mut() {
            e.input.release_all();
        }
    }

    fn show_toast(&mut self, text: &str) {
        self.toast = text.to_string();
        self.toast_timer = 2.5;
    }

    fn save_game(&mut self, announce: bool) {
        let result = match self.engine.as_ref() {
            Some(e) => e.save(&self.data_dir),
            None => return,
        };
        match result {
            Ok(()) => {
                self.save_exists = true;
                if announce {
                    self.show_toast("WORLD SAVED");
                }
            }
            Err(e) => {
                crate::loge!("save failed: {}", e);
                if announce {
                    self.show_toast("SAVE FAILED");
                }
            }
        }
    }

    fn start_world(&mut self, saved: Option<save::LoadedSave>) {
        self.engine = Some(GameEngine::new(&self.effective, saved));
        self.loading_time = 0.0;
        self.status.clear();
        self.status_timer = 0.0;
        self.go(Screen::Loading);
    }

    fn quit_to_menu(&mut self) {
        self.save_game(false);
        self.engine = None;
        self.go(Screen::MainMenu);
    }

    // ------------------------------------------------------------------ per-frame update

    /// Advances the game and rebuilds the UI geometry for this frame.
    pub fn update(&mut self, dt: f32) {
        let dt = dt.max(0.0001);
        self.dt = dt;
        self.time += dt;
        self.touches.tick(dt);
        #[cfg(test)]
        self.rects.clear();
        self.fps += (1.0 / dt - self.fps) * 0.08;
        if self.toast_timer > 0.0 {
            self.toast_timer -= dt;
        }
        self.ui.clear();
        self.update_quality(dt);
        let taps = self.touches.take_taps();
        match self.screen {
            Screen::MainMenu => self.main_menu(&taps),
            Screen::Loading => self.loading(dt),
            Screen::Playing => self.playing(dt, &taps),
            Screen::Pause => self.pause_menu(&taps),
            Screen::Settings => self.settings_menu(&taps),
            Screen::Inventory => self.inventory(dt, &taps),
            Screen::Crash => self.crash_screen(&taps),
        }
        if self.toast_timer > 0.0 {
            let px = self.font_px(10.0);
            let s = self.toast.clone();
            let y = self.height - 40.0 * self.scale;
            self.ui.text_centered(self.width * 0.5, y, px, &s, GOLD);
        }
    }

    // ------------------------------------------------------------------ widgets

    fn dp(&self, v: f32) -> f32 {
        v * self.scale
    }

    /// Pixel size of one font pixel so a glyph is about `glyph_dp` tall.
    fn font_px(&self, glyph_dp: f32) -> f32 {
        (glyph_dp * self.scale / 7.0).round().max(1.0)
    }

    fn dim(&mut self, alpha: u8) {
        self.ui.rect(0.0, 0.0, self.width, self.height, rgba(0, 0, 0, alpha));
    }

    fn panel(&mut self, x: f32, y: f32, w: f32, h: f32) {
        self.ui.rect(x, y, w, h, rgba(24, 28, 40, 235));
        let t = self.dp(2.0);
        self.ui.border(x, y, w, h, t, rgba(120, 132, 168, 255));
    }

    /// Draws a button; `down` shows it pressed.
    fn draw_button(&mut self, x: f32, y: f32, w: f32, h: f32, label: &str, down: bool) {
        let fill = if down { rgba(110, 130, 170, 240) } else { rgba(50, 58, 78, 235) };
        self.ui.rect(x, y, w, h, fill);
        let t = self.dp(2.0);
        self.ui.border(x, y, w, h, t, rgba(190, 200, 230, 255));
        let px = self.font_px(11.0);
        let th = UiBatch::text_height(px);
        self.ui.text_centered(x + w * 0.5, y + (h - th) * 0.5, px, label, WHITE);
    }

    /// A tap button: draws itself and returns true when it was tapped this frame.
    fn button(&mut self, x: f32, y: f32, w: f32, h: f32, label: &str, taps: &[(f32, f32)]) -> bool {
        let down = self.touches.any_inside(x, y, w, h);
        self.draw_button(x, y, w, h, label, down);
        self.note_rect(label, x, y, w, h);
        taps.iter().any(|&(tx, ty)| tx >= x && tx <= x + w && ty >= y && ty <= y + h)
    }

    /// `[-] value [+]` with a label on the left. Returns -1, 0 or 1.
    fn stepper_row(&mut self, x: f32, y: f32, w: f32, label: &str, value: &str, taps: &[(f32, f32)]) -> i32 {
        let px = self.font_px(8.0);
        let th = UiBatch::text_height(px);
        let row_h = self.dp(34.0);
        self.ui.text(x, y + (row_h - th) * 0.5, px, label, GREY);
        let b = self.dp(30.0);
        let value_w = self.dp(58.0);
        let right = x + w;
        let plus_x = right - b;
        let minus_x = plus_x - value_w - b - self.dp(4.0);
        let vx = minus_x + b + self.dp(2.0);
        let mut out = 0;
        if self.button(minus_x, y + (row_h - b) * 0.5, b, b, "-", taps) {
            out = -1;
        }
        if self.button(plus_x, y + (row_h - b) * 0.5, b, b, "+", taps) {
            out = 1;
        }
        let vpx = self.font_px(9.0);
        let vth = UiBatch::text_height(vpx);
        self.ui.text_centered(vx + value_w * 0.5, y + (row_h - vth) * 0.5, vpx, value, WHITE);
        out
    }

    fn toggle_row(&mut self, x: f32, y: f32, w: f32, label: &str, on: bool, taps: &[(f32, f32)]) -> bool {
        let px = self.font_px(8.0);
        let th = UiBatch::text_height(px);
        let row_h = self.dp(34.0);
        self.ui.text(x, y + (row_h - th) * 0.5, px, label, GREY);
        let bw = self.dp(76.0);
        let bh = self.dp(30.0);
        self.button(x + w - bw, y + (row_h - bh) * 0.5, bw, bh, if on { "ON" } else { "OFF" }, taps)
    }

    // ------------------------------------------------------------------ screens

    fn main_menu(&mut self, taps: &[(f32, f32)]) {
        self.dim(110);
        let cx = self.width * 0.5;
        let title_px = self.font_px(34.0);
        self.ui.text_centered(cx, self.height * 0.12, title_px, "VOXEL SANDBOX", WHITE);
        let sub_px = self.font_px(10.0);
        self.ui.text_centered(cx, self.height * 0.12 + UiBatch::text_height(title_px) + self.dp(8.0), sub_px, "RUST EDITION", GOLD);

        let bw = self.dp(230.0);
        let bh = self.dp(42.0);
        let gap = self.dp(10.0);
        let x = cx - bw * 0.5;
        let mut y = self.height * 0.43;
        if self.save_exists {
            if self.button(x, y, bw, bh, "CONTINUE", taps) {
                match save::read(&self.data_dir) {
                    Some(s) => self.start_world(Some(s)),
                    None => {
                        self.save_exists = false;
                        self.show_toast("SAVE COULD NOT BE READ");
                    }
                }
                return;
            }
            y += bh + gap;
        }
        if self.button(x, y, bw, bh, "NEW WORLD", taps) {
            self.start_world(None);
            return;
        }
        y += bh + gap;
        if self.button(x, y, bw, bh, "SETTINGS", taps) {
            self.settings_return = Screen::MainMenu;
            self.go(Screen::Settings);
            return;
        }
        if self.crash_text.is_some() {
            let cw = self.dp(260.0);
            let ch = self.dp(30.0);
            if self.button(cx - cw * 0.5, self.height - ch - self.dp(14.0), cw, ch, "VIEW LAST ERROR REPORT", taps) {
                self.go(Screen::Crash);
            }
        }
    }

    fn loading(&mut self, dt: f32) {
        self.loading_time += dt;
        let mut progress = 0.0;
        let mut ready = false;
        if let Some(engine) = self.engine.as_mut() {
            engine.input.ui_blocked = true;
            engine.update(&self.effective, dt);
            let center = ChunkPos::from_world(engine.player.position.x, engine.player.position.z);
            progress = (engine.manager.meshed_count() as f32 / 29.0).min(1.0);
            ready = !engine.player.waiting_for_spawn && engine.manager.area_ready(center, 3);
        }
        if ready || self.loading_time > LOADING_TIMEOUT {
            self.go(Screen::Playing);
            return;
        }
        self.dim(150);
        let cx = self.width * 0.5;
        let px = self.font_px(16.0);
        self.ui.text_centered(cx, self.height * 0.36, px, "GENERATING WORLD", WHITE);
        let bw = self.dp(280.0);
        let bh = self.dp(14.0);
        let x = cx - bw * 0.5;
        let y = self.height * 0.36 + UiBatch::text_height(px) + self.dp(18.0);
        self.ui.rect(x, y, bw, bh, rgba(255, 255, 255, 50));
        self.ui.rect(x, y, bw * progress, bh, rgba(120, 200, 120, 255));
        let t = self.dp(2.0);
        self.ui.border(x, y, bw, bh, t, rgba(255, 255, 255, 160));
    }

    fn playing(&mut self, dt: f32, taps: &[(f32, f32)]) {
        let mut next: Option<Screen> = None;
        if let Some(engine) = self.engine.as_mut() {
            for &(x, y) in taps {
                match self.layout.tap_target(x, y) {
                    TapTarget::Fly => engine.input.request_flight_toggle(),
                    TapTarget::Inventory => next = Some(Screen::Inventory),
                    TapTarget::Pause => next = Some(Screen::Pause),
                    TapTarget::Hotbar(i) => engine.hotbar.select(i),
                    TapTarget::None => {}
                }
            }
            engine.input.ui_blocked = false;
            hud::apply_touches(&self.layout, &mut self.touches, &mut engine.input);
            engine.update(&self.effective, dt);
        }
        self.status_timer -= dt;
        if self.status_timer <= 0.0 {
            self.status_timer = 0.5;
            if let Some(e) = self.engine.as_ref() {
                self.status = e.status_line();
            }
        }
        self.draw_world_hud();
        if let Some(s) = next {
            self.go(s);
        }
    }

    fn draw_world_hud(&mut self) {
        let engine = match self.engine.as_ref() {
            Some(e) => e,
            None => return,
        };
        if engine.underwater {
            self.ui.rect(0.0, 0.0, self.width, self.height, rgba(20, 70, 150, 70));
        }
        hud::draw(&self.layout, &mut self.ui, &self.touches, &engine.hotbar, engine.player.flying, self.width, self.height);
        let px = self.font_px(9.0);
        let x = self.dp(12.0);
        let mut y = self.dp(10.0);
        let line = UiBatch::text_height(px) + self.dp(4.0);
        let status = self.status.clone();
        self.ui.text_shadow(x, y, px, &status, WHITE);
        y += line;
        if self.settings.show_fps {
            let fps_text = format!("FPS {:.0}", self.fps);
            self.ui.text_shadow(x, y, px, &fps_text, GOLD);
            y += line;
            if self.governor.is_reduced() {
                let q = self.governor.quality();
                let auto_text = format!("AUTO: {} CHUNKS, {}%", q.detail_chunks, q.resolution_percent);
                self.ui.text_shadow(x, y, px, &auto_text, GOLD);
                y += line;
            }
            let stats = engine.debug_stats();
            for l in stats.lines() {
                self.ui.text_shadow(x, y, px, l, GREY);
                y += line;
            }
            // what the frame time is made of (calculation / drawing / waiting for the screen); see `diag`
            for l in self.overlay_lines.iter() {
                self.ui.text_shadow(x, y, px, l, GREY);
                y += line;
            }
        }
        if engine.laser_active {
            let lp = self.font_px(12.0);
            self.ui.text_centered(self.width * 0.5, self.height * 0.62, lp, "LASER", rgba(255, 90, 90, 255));
        }
    }

    fn pause_menu(&mut self, taps: &[(f32, f32)]) {
        self.dim(150);
        let cx = self.width * 0.5;
        let tp = self.font_px(22.0);
        self.ui.text_centered(cx, self.height * 0.16, tp, "PAUSED", WHITE);
        let bw = self.dp(240.0);
        let bh = self.dp(42.0);
        let gap = self.dp(10.0);
        let x = cx - bw * 0.5;
        let mut y = self.height * 0.36;
        if self.button(x, y, bw, bh, "RESUME", taps) {
            self.go(Screen::Playing);
            return;
        }
        y += bh + gap;
        if self.button(x, y, bw, bh, "SAVE WORLD", taps) {
            self.save_game(true);
        }
        y += bh + gap;
        if self.button(x, y, bw, bh, "SETTINGS", taps) {
            self.settings_return = Screen::Pause;
            self.go(Screen::Settings);
            return;
        }
        y += bh + gap;
        if self.button(x, y, bw, bh, "SAVE & MAIN MENU", taps) {
            self.quit_to_menu();
        }
    }

    fn inventory(&mut self, dt: f32, taps: &[(f32, f32)]) {
        if let Some(engine) = self.engine.as_mut() {
            engine.input.ui_blocked = true;
            engine.update(&self.effective, dt);
        }
        self.dim(165);
        let w = self.width;
        let h = self.height;
        let m = self.dp(14.0);
        // header: title on the left, close button on the right, the hotbar in the middle
        let tp = self.font_px(12.0);
        self.ui.text_shadow(m, m, tp, "CREATIVE INVENTORY", WHITE);
        let close = self.dp(40.0);
        if self.button(w - m - close, m * 0.6, close, close, "X", taps) {
            self.go(Screen::Playing);
            return;
        }
        if let Some(engine) = self.engine.as_mut() {
            hud::draw_hotbar(&self.layout, &mut self.ui, &engine.hotbar);
            for &(x, y) in taps {
                if let TapTarget::Hotbar(i) = self.layout.tap_target(x, y) {
                    engine.hotbar.select(i);
                }
            }
        }

        // category tabs
        let tab_w = self.dp(132.0);
        let tab_h = self.dp(38.0);
        let tab_gap = self.dp(6.0);
        let top = self.dp(74.0);
        for (i, c) in Category::ALL.iter().enumerate() {
            let y = top + i as f32 * (tab_h + tab_gap);
            let active = i == self.inv_tab;
            if active {
                self.ui.rect(m - self.dp(4.0), y - self.dp(3.0), tab_w + self.dp(8.0), tab_h + self.dp(6.0), rgba(255, 214, 102, 255));
            }
            if self.button(m, y, tab_w, tab_h, c.label(), taps) {
                self.inv_tab = i;
            }
        }

        // block grid
        let category = Category::ALL[self.inv_tab.min(Category::ALL.len() - 1)];
        let blocks = catalog::blocks_in(category);
        let gx0 = m + tab_w + self.dp(20.0);
        let cell = self.dp(54.0);
        let cgap = self.dp(8.0);
        let cols = (((w - gx0 - m) + cgap) / (cell + cgap)).floor().max(1.0) as usize;
        let selected = self.engine.as_ref().map(|e| e.hotbar.selected_block()).unwrap_or(Block::Air);
        let mut picked: Option<Block> = None;
        for (i, b) in blocks.iter().enumerate() {
            let col = i % cols;
            let row = i / cols;
            let x = gx0 + col as f32 * (cell + cgap);
            let y = top + row as f32 * (cell + cgap);
            let is_sel = *b == selected;
            self.ui.rect(x, y, cell, cell, if is_sel { rgba(255, 255, 255, 80) } else { rgba(0, 0, 0, 120) });
            let bt = if is_sel { self.dp(3.0) } else { self.dp(1.5) };
            self.ui.border(x, y, cell, cell, bt, if is_sel { rgba(255, 214, 102, 255) } else { rgba(255, 255, 255, 80) });
            self.ui.block_icon(*b, x + cell * 0.5, y + cell * 0.5, cell * 0.74);
            if taps.iter().any(|&(tx, ty)| tx >= x && tx <= x + cell && ty >= y && ty <= y + cell) {
                picked = Some(*b);
            }
        }
        if let Some(b) = picked {
            if let Some(engine) = self.engine.as_mut() {
                engine.hotbar.pick(b);
            }
        }
        let hold = self.engine.as_ref().map(|e| e.hotbar.selected_block()).unwrap_or(Block::Air);
        let np = self.font_px(10.0);
        let label = format!("HOLDING: {}", hold.name());
        self.ui.text_centered(gx0 + (w - gx0 - m) * 0.5, h - self.dp(40.0), np, &label, GOLD);
    }

    fn crash_screen(&mut self, taps: &[(f32, f32)]) {
        self.dim(200);
        let cx = self.width * 0.5;
        let tp = self.font_px(14.0);
        self.ui.text_centered(cx, self.dp(12.0), tp, "LAST ERROR REPORT", rgba(255, 120, 120, 255));
        let px = self.font_px(7.0);
        let adv = 6.0 * px;
        let max_chars = (((self.width - self.dp(32.0)) / adv).floor() as usize).max(10);
        let text = self.crash_text.clone().unwrap_or_default();
        let lines = wrap_lines(&text, max_chars);
        let line_h = UiBatch::text_height(px) + self.dp(3.0);
        let mut y = self.dp(48.0);
        let limit = self.height - self.dp(70.0);
        for l in lines.iter() {
            if y > limit {
                break;
            }
            self.ui.text(self.dp(16.0), y, px, l, WHITE);
            y += line_h;
        }
        let bw = self.dp(190.0);
        let bh = self.dp(38.0);
        let by = self.height - bh - self.dp(12.0);
        if self.button(cx - bw - self.dp(8.0), by, bw, bh, "DISMISS", taps) {
            let _ = fs::remove_file(self.data_dir.join("last_panic.txt"));
            self.crash_text = None;
            self.go(Screen::MainMenu);
        } else if self.button(cx + self.dp(8.0), by, bw, bh, "BACK", taps) {
            self.go(Screen::MainMenu);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_app(name: &str) -> App {
        let dir = std::env::temp_dir().join(name);
        let _ = fs::create_dir_all(&dir);
        let _ = fs::remove_file(dir.join("world.bin"));
        let _ = fs::remove_file(dir.join("last_panic.txt"));
        // every test starts from the default settings, not from what an earlier run saved
        let _ = fs::remove_file(dir.join("settings.txt"));
        let _ = fs::remove_file(dir.join(QUALITY_FILE));
        App::new(dir)
    }

    /// Plays `seconds` of frames that take `frame_ms` each, with no world (only the quality control looks at them).
    fn play_slowly(app: &mut App, seconds: f32, frame_ms: f32) {
        let mut t = 0.0;
        while t < seconds {
            app.update(frame_ms / 1000.0);
            t += frame_ms / 1000.0;
        }
    }

    #[test]
    fn menu_builds_geometry_and_new_world_starts_loading() {
        let mut app = temp_app("vs_app_test_a");
        app.update(0.016);
        assert!(!app.ui.verts.is_empty());
        // tap NEW WORLD (second button position is computed from the layout; tap the first button instead)
        let bw = app.dp(230.0);
        let x = app.width * 0.5 - bw * 0.5 + 5.0;
        let y = app.height * 0.43 + 5.0;
        app.touch_down(1, x, y);
        app.touch_up(1, false);
        app.update(0.016);
        assert_eq!(app.screen, Screen::Loading);
        assert!(app.engine.is_some());
    }

    #[test]
    fn back_button_walks_out_of_menus() {
        let mut app = temp_app("vs_app_test_b");
        assert!(!app.back_pressed());
        app.screen = Screen::Settings;
        app.settings_return = Screen::MainMenu;
        assert!(app.back_pressed());
        assert_eq!(app.screen, Screen::MainMenu);
    }

    fn rect_of(app: &App, name: &str) -> [f32; 4] {
        app.rects.iter().find(|(n, _)| n == name).map(|(_, r)| *r).unwrap_or_else(|| panic!("no control named {}", name))
    }

    fn center(r: [f32; 4]) -> (f32, f32) {
        (r[0] + r[2] * 0.5, r[1] + r[3] * 0.5)
    }

    fn tap(app: &mut App, r: [f32; 4]) {
        let (x, y) = center(r);
        app.touch_down(9, x, y);
        app.touch_up(9, false);
        app.update(0.016);
    }

    fn settings_app(name: &str) -> App {
        let mut app = temp_app(name);
        app.screen = Screen::Settings;
        app.settings_return = Screen::MainMenu;
        app.update(0.016);
        app
    }

    #[test]
    fn max_button_jumps_straight_to_a_thousand_chunks() {
        let mut app = settings_app("vs_app_test_max");
        assert_eq!(app.settings.render_distance, 10);
        let r = rect_of(&app, "MAX");
        tap(&mut app, r);
        assert_eq!(app.settings.render_distance, 1000);
        assert!(app.settings.far_terrain_wanted());
    }

    #[test]
    fn holding_plus_climbs_quickly_and_stops_when_released() {
        let mut app = settings_app("vs_app_test_hold");
        let r = rect_of(&app, "repeat+");
        let (x, y) = center(r);
        app.touch_down(3, x, y);
        for _ in 0..40 {
            app.update(0.016);
        }
        let after_a_moment = app.settings.render_distance;
        assert!(after_a_moment > 10, "the press itself must step: {}", after_a_moment);
        for _ in 0..200 {
            app.update(0.016);
        }
        let after_a_while = app.settings.render_distance;
        assert!(after_a_while >= 400, "holding should climb fast, got {}", after_a_while);
        app.touch_up(3, false);
        app.update(0.016);
        let released = app.settings.render_distance;
        for _ in 0..30 {
            app.update(0.016);
        }
        assert_eq!(app.settings.render_distance, released, "releasing must stop the climb");
    }

    #[test]
    fn single_taps_on_minus_and_plus_move_by_a_small_step() {
        let mut app = settings_app("vs_app_test_taps");
        let plus = rect_of(&app, "repeat+");
        let (x, y) = center(plus);
        app.touch_down(4, x, y);
        app.update(0.016);
        app.touch_up(4, false);
        app.update(0.016);
        assert_eq!(app.settings.render_distance, 11);
        let minus = rect_of(&app, "repeat-");
        let (x, y) = center(minus);
        app.touch_down(4, x, y);
        app.update(0.016);
        app.touch_up(4, false);
        app.update(0.016);
        assert_eq!(app.settings.render_distance, 10);
    }

    #[test]
    fn dragging_the_slider_sets_the_distance() {
        let mut app = settings_app("vs_app_test_slider");
        let r = rect_of(&app, "render-slider");
        let knob = app.dp(14.0);
        let track_x = r[0] + knob * 0.5;
        let track_w = r[2] - knob;
        let y = r[1] + r[3] * 0.5;
        app.touch_down(5, track_x + track_w * 0.5, y);
        app.update(0.016);
        let mid = app.settings.render_distance;
        assert!(mid > 40 && mid < 90, "middle of a log slider is about 63, got {}", mid);
        // drag past the right end, even above the slider: it clamps to the maximum
        app.touch_move(5, track_x + track_w * 1.4, y - 60.0);
        app.update(0.016);
        assert_eq!(app.settings.render_distance, 1000);
        app.touch_move(5, track_x - 50.0, y);
        app.update(0.016);
        assert_eq!(app.settings.render_distance, 4);
    }

    #[test]
    fn the_graphics_tab_switches_greedy_meshing_and_occlusion_culling() {
        let mut app = settings_app("vs_app_test_opt");
        assert!(app.settings.greedy_meshing && app.settings.occlusion_culling, "both start on");
        // switches in drawing order: clouds, greedy meshing, occlusion culling, auto performance
        let on: Vec<[f32; 4]> = app.rects.iter().filter(|(n, _)| n == "ON").map(|(_, r)| *r).collect();
        assert_eq!(on.len(), 4, "four switches on the graphics tab");
        tap(&mut app, on[1]);
        assert!(!app.settings.greedy_meshing);
        assert!(app.settings.occlusion_culling && app.settings.clouds);
        tap(&mut app, on[2]);
        assert!(!app.settings.occlusion_culling);
        assert!(app.settings.clouds);
        // and back on again (a tap is applied while the frame is drawn, so draw once more to see the new labels)
        app.update(0.016);
        let off: Vec<[f32; 4]> = app.rects.iter().filter(|(n, _)| n == "OFF").map(|(_, r)| *r).collect();
        assert_eq!(off.len(), 2, "greedy meshing and occlusion culling both read OFF now");
        tap(&mut app, off[0]);
        tap(&mut app, off[1]);
        assert!(app.settings.greedy_meshing && app.settings.occlusion_culling);
    }

    #[test]
    fn slow_play_lowers_what_the_game_runs_with_and_the_next_launch_starts_there() {
        let mut app = temp_app("vs_app_test_auto");
        app.settings.render_distance = 24;
        app.settings.detail_distance = 24;
        app.screen = Screen::Playing;
        app.update(0.016);
        assert_eq!(app.game_settings().detail_radius(), 24, "the player's settings to begin with");
        play_slowly(&mut app, 12.0, 45.0);
        let running = app.game_settings().detail_radius();
        assert!(running < 24, "45 ms frames must bring the block distance down, still {}", running);
        assert_eq!(app.settings.detail_radius(), 24, "the player's own setting is left alone");
        assert!(app.game_settings().far_terrain_wanted(), "the far terrain takes over beyond the shorter distance");
        let notes = app.take_notes();
        assert!(notes.iter().any(|n| n.starts_with("auto performance:")), "{:?}", notes);
        assert!(app.take_notes().is_empty(), "notes are handed over once");
        // the level is remembered for the next launch (with the same settings of the player's)
        app.settings.save(&app.data_dir.join("settings.txt"));
        let again = App::new(app.data_dir.clone());
        assert_eq!(again.game_settings().detail_radius(), running);
        assert!(again.auto_quality().1, "and it knows it is below what the player allows");
        // the first frames of the new run must not throw the remembered level away
        let mut again = again;
        again.update(0.016);
        again.update(0.016);
        assert_eq!(again.game_settings().detail_radius(), running);
    }

    #[test]
    fn with_auto_performance_off_the_game_runs_the_players_settings() {
        let mut app = temp_app("vs_app_test_auto_off");
        app.settings.render_distance = 24;
        app.settings.detail_distance = 24;
        app.settings.auto_quality = false;
        app.screen = Screen::Playing;
        app.update(0.016);
        play_slowly(&mut app, 12.0, 45.0);
        assert_eq!(app.game_settings().detail_radius(), 24);
        assert_eq!(app.game_settings().resolution_percent, 100);
    }

    #[test]
    fn menus_do_not_count_as_slow_play() {
        let mut app = temp_app("vs_app_test_auto_menu");
        app.settings.render_distance = 24;
        app.settings.detail_distance = 24;
        app.screen = Screen::Pause;
        app.update(0.016);
        play_slowly(&mut app, 12.0, 60.0);
        assert_eq!(app.game_settings().detail_radius(), 24, "only played frames are judged");
    }

    #[test]
    fn settings_changes_are_noted_once_the_settings_screen_is_closed() {
        let mut app = settings_app("vs_app_test_notes");
        app.take_notes();
        app.settings.clouds = false;
        app.settings.greedy_meshing = false;
        app.update(0.016);
        assert!(app.take_notes().is_empty(), "nothing is noted while the settings screen is open");
        app.screen = Screen::MainMenu;
        app.update(0.016);
        let notes = app.take_notes();
        assert!(notes.iter().any(|n| n.contains("clouds: on -> off")), "{:?}", notes);
        assert!(notes.iter().any(|n| n.contains("greedy meshing: on -> off")), "{:?}", notes);
        app.update(0.016);
        assert!(app.take_notes().is_empty(), "and only once");
    }

    #[test]
    fn the_auto_performance_switch_is_on_the_graphics_tab() {
        let mut app = settings_app("vs_app_test_auto_switch");
        assert!(app.settings.auto_quality);
        // switches in drawing order: clouds, greedy meshing, occlusion culling, auto performance
        let on: Vec<[f32; 4]> = app.rects.iter().filter(|(n, _)| n == "ON").map(|(_, r)| *r).collect();
        tap(&mut app, on[3]);
        assert!(!app.settings.auto_quality);
        app.update(0.016);
        let off: Vec<[f32; 4]> = app.rects.iter().filter(|(n, _)| n == "OFF").map(|(_, r)| *r).collect();
        assert_eq!(off.len(), 1);
        tap(&mut app, off[0]);
        assert!(app.settings.auto_quality);
    }

    #[test]
    fn tabs_switch_and_the_debug_log_can_be_turned_off_and_saved() {
        let mut app = settings_app("vs_app_test_tabs");
        assert!(app.settings.debug_log);
        let r = rect_of(&app, "DEBUG");
        tap(&mut app, r);
        assert_eq!(app.settings_tab, 2);
        app.set_log_status("LOG: WRITING TO DOWNLOAD/TEST.TXT");
        app.update(0.016);
        let r = rect_of(&app, "ON");
        tap(&mut app, r);
        assert!(!app.settings.debug_log);
        let r = rect_of(&app, "BACK");
        tap(&mut app, r);
        assert_eq!(app.screen, Screen::MainMenu);
        let saved = Settings::load(&app.data_dir.join("settings.txt"));
        assert!(!saved.debug_log);
    }

    #[test]
    fn every_settings_tab_draws_inside_the_screen() {
        let mut app = settings_app("vs_app_test_draw");
        for tab in 0..3 {
            app.settings_tab = tab;
            app.update(0.016);
            assert!(!app.ui.verts.is_empty());
            for v in app.ui.verts.iter() {
                assert!(v.pos[0] >= -1.0 && v.pos[0] <= app.width + 1.0, "x out of screen on tab {}: {}", tab, v.pos[0]);
                assert!(v.pos[1] >= -1.0 && v.pos[1] <= app.height + 1.0, "y out of screen on tab {}: {}", tab, v.pos[1]);
            }
        }
    }

    #[test]
    fn wrapping_splits_long_lines() {
        let lines = wrap_lines("abcdefghij\n\nxy", 4);
        assert_eq!(lines, vec!["abcd", "efgh", "ij", "", "xy"]);
    }
}
