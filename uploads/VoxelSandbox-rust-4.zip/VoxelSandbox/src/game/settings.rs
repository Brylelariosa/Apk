//! User settings, stored as simple `key=value` lines.

use std::fs;
use std::path::Path;

use crate::perf::Quality;

/// Render distance is how far you can *see*, in chunks of 16 blocks. Anything beyond the detail distance is
/// drawn as cheap far terrain, which is what makes very large values affordable.
pub const MIN_RENDER_CHUNKS: i32 = 4;
pub const MAX_RENDER_CHUNKS: i32 = 1000;
pub const DEFAULT_RENDER_CHUNKS: i32 = 10;
/// Detail distance is how far real blocks are built around the player (the expensive part).
pub const MIN_DETAIL_CHUNKS: i32 = 4;
pub const MAX_DETAIL_CHUNKS: i32 = 24;
pub const DEFAULT_DETAIL_CHUNKS: i32 = 10;
/// Share of the screen's native pixel size the game renders at.
pub const MIN_RESOLUTION_PERCENT: i32 = 40;
pub const MAX_RESOLUTION_PERCENT: i32 = 100;
/// Chunks nearer than this always get the full-detail mesh (see `Settings::merge_from_chunks`).
pub const MERGE_FROM_CHUNKS: i32 = 6;
pub const MIN_FLY_SPEED: f32 = 8.0;
pub const MAX_FLY_SPEED: f32 = 200.0;
pub const DEFAULT_FLY_SPEED: f32 = 30.0;

#[derive(Clone, Debug, PartialEq)]
pub struct Settings {
    /// How far you can see, in chunks.
    pub render_distance: i32,
    /// Radius (in chunks) of the fully detailed block world around the player (never more than
    /// `render_distance`; see [`Settings::detail_radius`]).
    pub detail_distance: i32,
    /// Render resolution as a percentage of the screen's native size.
    pub resolution_percent: i32,
    pub show_fps: bool,
    pub touch_sensitivity: f32,
    pub look_sensitivity: f32,
    pub view_bobbing: bool,
    pub clouds: bool,
    pub auto_jump: bool,
    pub fly_speed: f32,
    /// Write the performance log to a text file (see `diag`).
    pub debug_log: bool,
    /// Greedy meshing: far-ish chunks are built from big merged quads (fewer triangles).
    pub greedy_meshing: bool,
    /// Occlusion culling: sections of the world that are shut off from the camera by rock are not drawn.
    pub occlusion_culling: bool,
    /// Auto performance: the game lowers the real-block distance and the resolution by itself when it cannot keep
    /// up (never above what the two settings above say).
    pub auto_quality: bool,
}

fn clamp_i(v: i32, lo: i32, hi: i32) -> i32 {
    v.max(lo).min(hi)
}

impl Settings {
    pub fn defaults() -> Settings {
        Settings {
            render_distance: DEFAULT_RENDER_CHUNKS,
            detail_distance: DEFAULT_DETAIL_CHUNKS,
            resolution_percent: MAX_RESOLUTION_PERCENT,
            show_fps: false,
            touch_sensitivity: 0.5,
            look_sensitivity: 0.5,
            view_bobbing: true,
            clouds: true,
            auto_jump: true,
            fly_speed: DEFAULT_FLY_SPEED,
            debug_log: true,
            greedy_meshing: true,
            occlusion_culling: true,
            auto_quality: true,
        }
    }

    /// Chunks farther than this many chunks from the player are built as cheap merged meshes; 0 means never.
    /// It is the same distance whatever the detail distance is, so the automatic quality control can change the
    /// detail distance without every chunk being built again.
    pub fn merge_from_chunks(&self) -> i32 {
        if self.greedy_meshing {
            MERGE_FROM_CHUNKS
        } else {
            0
        }
    }

    /// These settings with the distance of real blocks and the resolution lowered to what the automatic quality
    /// control decided (it never raises them).
    pub fn with_quality(&self, q: Quality) -> Settings {
        let mut s = self.clone();
        s.detail_distance = s.detail_distance.min(q.detail_chunks).max(MIN_DETAIL_CHUNKS);
        s.resolution_percent = s.resolution_percent.min(q.resolution_percent).max(MIN_RESOLUTION_PERCENT);
        s
    }

    /// One line per graphics setting that differs from `old`, for the debug log ("greedy meshing: on -> off").
    pub fn describe_changes(&self, old: &Settings) -> Vec<String> {
        let on = |b: bool| if b { "on" } else { "off" };
        let mut out = Vec::new();
        if self.render_distance != old.render_distance {
            out.push(format!("render distance: {} -> {} chunks", old.render_distance, self.render_distance));
        }
        if self.detail_distance != old.detail_distance {
            out.push(format!("detail distance: {} -> {} chunks", old.detail_distance, self.detail_distance));
        }
        if self.resolution_percent != old.resolution_percent {
            out.push(format!("resolution: {}% -> {}%", old.resolution_percent, self.resolution_percent));
        }
        let switches = [
            ("clouds", old.clouds, self.clouds),
            ("greedy meshing", old.greedy_meshing, self.greedy_meshing),
            ("occlusion culling", old.occlusion_culling, self.occlusion_culling),
            ("auto performance", old.auto_quality, self.auto_quality),
        ];
        for (name, before, after) in switches {
            if before != after {
                out.push(format!("{}: {} -> {}", name, on(before), on(after)));
            }
        }
        out
    }

    /// The radius of real, block-by-block terrain actually built: the detail distance, but never past the
    /// render distance.
    pub fn detail_radius(&self) -> i32 {
        clamp_i(self.detail_distance, MIN_DETAIL_CHUNKS, MAX_DETAIL_CHUNKS).min(self.render_distance).max(MIN_RENDER_CHUNKS)
    }

    /// True when the render distance reaches past the block world, so far terrain is needed.
    pub fn far_terrain_wanted(&self) -> bool {
        self.render_distance > self.detail_radius()
    }

    /// The graphics settings in one line, for the top of the debug log.
    pub fn summary(&self) -> String {
        let on = |b: bool| if b { "on" } else { "off" };
        format!(
            "render distance {} chunks, real blocks out to {} chunks, resolution {}%, clouds {}, greedy meshing {}, occlusion culling {}, far terrain {}, auto performance {}",
            self.render_distance,
            self.detail_radius(),
            self.resolution_percent,
            on(self.clouds),
            on(self.greedy_meshing),
            on(self.occlusion_culling),
            on(self.far_terrain_wanted()),
            on(self.auto_quality),
        )
    }

    /// Pulls every value back into its allowed range.
    pub fn sanitize(&mut self) {
        self.render_distance = clamp_i(self.render_distance, MIN_RENDER_CHUNKS, MAX_RENDER_CHUNKS);
        self.detail_distance = clamp_i(self.detail_distance, MIN_DETAIL_CHUNKS, MAX_DETAIL_CHUNKS);
        self.resolution_percent = clamp_i(self.resolution_percent, MIN_RESOLUTION_PERCENT, MAX_RESOLUTION_PERCENT);
        self.touch_sensitivity = self.touch_sensitivity.max(0.0).min(1.0);
        self.look_sensitivity = self.look_sensitivity.max(0.0).min(1.0);
        self.fly_speed = self.fly_speed.max(MIN_FLY_SPEED).min(MAX_FLY_SPEED);
    }

    /// Reads `path`; anything missing or unreadable falls back to the default.
    pub fn load(path: &Path) -> Settings {
        match fs::read_to_string(path) {
            Ok(text) => Settings::parse(&text),
            Err(_) => Settings::defaults(),
        }
    }

    /// Parses the text of a settings file. Unknown keys are ignored. A file written by an older version
    /// (no `detail_distance`) keeps its old meaning: the whole render distance was real blocks.
    pub fn parse(text: &str) -> Settings {
        let mut s = Settings::defaults();
        let mut saw_detail = false;
        for line in text.lines() {
            let mut parts = line.splitn(2, '=');
            let key = parts.next().unwrap_or("").trim();
            let value = parts.next().unwrap_or("").trim();
            match key {
                "render_distance" => {
                    if let Ok(v) = value.parse::<i32>() {
                        s.render_distance = v;
                    }
                }
                "detail_distance" => {
                    if let Ok(v) = value.parse::<i32>() {
                        s.detail_distance = v;
                        saw_detail = true;
                    }
                }
                "resolution_percent" => {
                    if let Ok(v) = value.parse::<i32>() {
                        s.resolution_percent = v;
                    }
                }
                "show_fps" => s.show_fps = value == "true",
                "touch_sensitivity" => {
                    if let Ok(v) = value.parse::<f32>() {
                        s.touch_sensitivity = v;
                    }
                }
                "look_sensitivity" => {
                    if let Ok(v) = value.parse::<f32>() {
                        s.look_sensitivity = v;
                    }
                }
                "view_bobbing" => s.view_bobbing = value == "true",
                "clouds" => s.clouds = value == "true",
                "auto_jump" => s.auto_jump = value == "true",
                "fly_speed" => {
                    if let Ok(v) = value.parse::<f32>() {
                        s.fly_speed = v;
                    }
                }
                "debug_log" => s.debug_log = value == "true",
                "greedy_meshing" => s.greedy_meshing = value == "true",
                "occlusion_culling" => s.occlusion_culling = value == "true",
                "auto_quality" => s.auto_quality = value == "true",
                _ => {}
            }
        }
        if !saw_detail {
            s.detail_distance = s.render_distance;
        }
        s.sanitize();
        s
    }

    pub fn to_text(&self) -> String {
        format!(
            "render_distance={}\ndetail_distance={}\nresolution_percent={}\nshow_fps={}\ntouch_sensitivity={}\nlook_sensitivity={}\nview_bobbing={}\nclouds={}\nauto_jump={}\nfly_speed={}\ndebug_log={}\ngreedy_meshing={}\nocclusion_culling={}\nauto_quality={}\n",
            self.render_distance,
            self.detail_distance,
            self.resolution_percent,
            self.show_fps,
            self.touch_sensitivity,
            self.look_sensitivity,
            self.view_bobbing,
            self.clouds,
            self.auto_jump,
            self.fly_speed,
            self.debug_log,
            self.greedy_meshing,
            self.occlusion_culling,
            self.auto_quality
        )
    }

    pub fn save(&self, path: &Path) {
        if let Err(e) = fs::write(path, self.to_text()) {
            crate::logw!("could not save settings: {}", e);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn settings_round_trip_through_a_file() {
        let dir = std::env::temp_dir().join("vs_settings_test");
        let _ = fs::create_dir_all(&dir);
        let path = dir.join("settings.txt");
        let mut s = Settings::defaults();
        s.render_distance = 14;
        s.show_fps = true;
        s.fly_speed = 55.0;
        s.detail_distance = 8;
        s.resolution_percent = 75;
        s.debug_log = false;
        s.greedy_meshing = false;
        s.occlusion_culling = false;
        s.auto_quality = false;
        s.save(&path);
        let t = Settings::load(&path);
        assert_eq!(t, s);
    }

    #[test]
    fn render_distance_can_reach_a_thousand_chunks_and_no_more() {
        let t = Settings::parse("render_distance=1000\n");
        assert_eq!(t.render_distance, 1000);
        let t = Settings::parse("render_distance=999999\n");
        assert_eq!(t.render_distance, MAX_RENDER_CHUNKS);
        let t = Settings::parse("render_distance=-5\n");
        assert_eq!(t.render_distance, MIN_RENDER_CHUNKS);
    }

    #[test]
    fn old_settings_files_keep_their_block_distance() {
        // before far terrain existed, render_distance was the radius of real blocks
        let t = Settings::parse("render_distance=20\nshow_fps=true\n");
        assert_eq!(t.render_distance, 20);
        assert_eq!(t.detail_radius(), 20);
        assert!(!t.far_terrain_wanted());
        assert!(t.debug_log, "the log is on unless switched off");
    }

    #[test]
    fn detail_radius_never_exceeds_the_render_distance_or_its_cap() {
        let mut s = Settings::defaults();
        s.render_distance = 6;
        s.detail_distance = 20;
        assert_eq!(s.detail_radius(), 6);
        s.render_distance = 1000;
        assert_eq!(s.detail_radius(), 20);
        assert!(s.far_terrain_wanted());
        s.detail_distance = 500;
        s.sanitize();
        assert_eq!(s.detail_distance, MAX_DETAIL_CHUNKS);
        assert_eq!(s.detail_radius(), MAX_DETAIL_CHUNKS);
    }

    #[test]
    fn merged_meshes_start_at_a_fixed_distance_and_can_be_switched_off() {
        let mut s = Settings::defaults();
        assert!(s.greedy_meshing && s.occlusion_culling && s.auto_quality, "all three are on by default");
        for detail in [4, 10, 16, 24] {
            s.detail_distance = detail;
            assert_eq!(s.merge_from_chunks(), MERGE_FROM_CHUNKS, "the distance does not depend on the detail distance");
        }
        s.greedy_meshing = false;
        assert_eq!(s.merge_from_chunks(), 0);
    }

    #[test]
    fn the_automatic_quality_only_ever_lowers_the_settings() {
        let mut s = Settings::defaults();
        s.render_distance = 40;
        s.detail_distance = 20;
        s.resolution_percent = 90;
        let low = s.with_quality(Quality { detail_chunks: 12, resolution_percent: 70 });
        assert_eq!((low.detail_distance, low.resolution_percent), (12, 70));
        assert_eq!(low.render_distance, 40, "what the player can see does not change, only how it is drawn");
        assert!(low.far_terrain_wanted());
        let same = s.with_quality(Quality { detail_chunks: 24, resolution_percent: 100 });
        assert_eq!(same, s, "a better quality than the settings does not raise them");
        let floor = s.with_quality(Quality { detail_chunks: 1, resolution_percent: 1 });
        assert_eq!((floor.detail_distance, floor.resolution_percent), (MIN_DETAIL_CHUNKS, MIN_RESOLUTION_PERCENT));
    }

    #[test]
    fn changes_are_described_for_the_log() {
        let old = Settings::defaults();
        let mut s = old.clone();
        assert!(s.describe_changes(&old).is_empty());
        s.greedy_meshing = false;
        s.render_distance = 30;
        s.clouds = false;
        s.auto_quality = false;
        let lines = s.describe_changes(&old);
        assert!(lines.iter().any(|l| l == "greedy meshing: on -> off"), "{:?}", lines);
        assert!(lines.iter().any(|l| l == "render distance: 10 -> 30 chunks"), "{:?}", lines);
        assert!(lines.iter().any(|l| l == "clouds: on -> off"), "{:?}", lines);
        assert!(lines.iter().any(|l| l == "auto performance: on -> off"), "{:?}", lines);
        assert_eq!(lines.len(), 4);
    }

    #[test]
    fn the_summary_names_every_graphics_setting() {
        let mut s = Settings::defaults();
        s.render_distance = 500;
        s.detail_distance = 12;
        s.greedy_meshing = false;
        let text = s.summary();
        assert!(text.contains("render distance 500 chunks"), "{}", text);
        assert!(text.contains("real blocks out to 12 chunks"), "{}", text);
        assert!(text.contains("greedy meshing off") && text.contains("occlusion culling on"), "{}", text);
        assert!(text.contains("far terrain on") && text.contains("auto performance on"), "{}", text);
        assert!(!text.contains('\n'), "it goes on one header line");
    }

    #[test]
    fn garbage_values_fall_back_to_sane_ones() {
        let t = Settings::parse("render_distance=abc\nresolution_percent=3\nfly_speed=nan\nlook_sensitivity=9\n");
        assert_eq!(t.render_distance, DEFAULT_RENDER_CHUNKS);
        assert_eq!(t.resolution_percent, MIN_RESOLUTION_PERCENT);
        assert!(t.fly_speed >= MIN_FLY_SPEED && t.fly_speed <= MAX_FLY_SPEED);
        assert_eq!(t.look_sensitivity, 1.0);
    }
}
