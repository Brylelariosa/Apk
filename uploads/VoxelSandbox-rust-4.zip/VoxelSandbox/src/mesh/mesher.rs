//! Turns a chunk (plus a one-block apron from its eight neighbours) into triangles: culled cube faces with
//! per-vertex ambient occlusion, cave darkening and biome tint, crossed-quad plants and animated-height water.

use std::sync::Arc;

use super::biome_color::{tint_for_cell, Anchor, BiomeColorField, BiomePalette, TintInfo};
use super::visibility;
use super::{ChunkMeshData, Vertex, PASS_COUNT, PASS_CUTOUT, PASS_DOUBLE, PASS_OPAQUE, PASS_WATER};
use crate::tex::cells;
use crate::world::block::{Block, Face, CUTOUT_BY_ID, OPAQUE_BY_ID, SOLID_BY_ID};
use crate::world::chunk::ChunkData;
use crate::world::config::{SEA_LEVEL, SECTIONS, WORLD_HEIGHT};
use crate::world::fluid;
use crate::world::pos::ChunkPos;

const PAD_XZ: usize = 18;
const PAD_Y: usize = 258;

/// Corner brightness for ambient-occlusion level 0 (boxed in) .. 3 (open).
const AO_SHADE: [f32; 4] = [0.58, 0.72, 0.86, 1.0];
/// Shade per face, in `Face` order: top, bottom, north, south, east, west.
const FACE_SHADE: [f32; 6] = [1.0, 0.4, 0.82, 0.82, 0.70, 0.70];
const CAVE_DARK_START: i32 = 3;
const CAVE_DARK_RATE: f32 = 0.03;
const MAX_LIGHT_STEP: i32 = 21;

const FACE_NORMAL: [[i32; 3]; 6] = [[0, 1, 0], [0, -1, 0], [0, 0, -1], [0, 0, 1], [1, 0, 0], [-1, 0, 0]];

/// Quad corners per face, counter-clockwise seen from outside.
const FACE_CORNERS: [[[i32; 3]; 4]; 6] = [
    [[0, 1, 0], [0, 1, 1], [1, 1, 1], [1, 1, 0]],
    [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
    [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]],
    [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
    [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
    [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
];

const UV_TOP: [[f32; 2]; 4] = [[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]];
const UV_BOTTOM: [[f32; 2]; 4] = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
const UV_SIDE: [[f32; 2]; 4] = [[0.0, 1.0], [1.0, 1.0], [1.0, 0.0], [0.0, 0.0]];

const FLIP_X: u8 = 1;
const FLIP_Y: u8 = 2;
const SWAP: u8 = 4;

/// Which mirror / rotate tricks keep a tile looking right (they break up the repetition of the ground).
fn variant_flags(layer: i32) -> u8 {
    match layer {
        cells::GRASS_TOP
        | cells::DIRT
        | cells::STONE
        | cells::SAND
        | cells::OAK_RINGS
        | cells::OAK_LEAVES
        | cells::COAL_ORE
        | cells::BIRCH_LEAVES
        | cells::SPRUCE_LEAVES
        | cells::BIRCH_RINGS
        | cells::SPRUCE_RINGS
        | cells::SNOW
        | cells::GRAVEL
        | cells::SANDSTONE_TOP
        | cells::DRY_GRASS_TOP
        | cells::CACTUS_TOP
        | cells::SWAMP_GRASS_TOP
        | cells::DEEP_STONE => FLIP_X | FLIP_Y | SWAP,
        cells::OAK_BARK | cells::BIRCH_BARK | cells::SPRUCE_BARK => FLIP_X | FLIP_Y,
        cells::GRASS_SIDE
        | cells::SNOW_SIDE
        | cells::SANDSTONE_SIDE
        | cells::DRY_GRASS_SIDE
        | cells::CACTUS_SIDE
        | cells::SWAMP_GRASS_SIDE => FLIP_X,
        _ => 0,
    }
}

/// A snapshot of a chunk and its eight neighbours (index `(dz + 1) * 3 + (dx + 1)`, centre = 4).
pub struct MeshInput {
    pub pos: ChunkPos,
    pub chunks: [Option<ChunkData>; 9],
    /// Build the cheap "merged" mesh: neighbouring faces of the same block share one big quad, and the per-block
    /// brightness variation and ambient occlusion are left out, and so are plants (grass, flowers, lily pads).
    /// About a third of the triangles, meant for chunks far enough from the player that the difference cannot
    /// be seen.
    pub merge: bool,
}

/// Shared, read-only data the mesher needs.
pub struct MeshContext {
    pub color_field: Arc<BiomeColorField>,
}

#[inline]
fn pidx(x: i32, y: i32, z: i32) -> usize {
    (((y + 1) as usize * PAD_XZ + (z + 1) as usize) * PAD_XZ) + (x + 1) as usize
}

/// Per-block brightness multiplier in `1 - range ..= 1`, a pure function of position.
fn variation(x: i32, y: i32, z: i32, range: f32) -> f32 {
    let mut h = x.wrapping_mul(73856093) ^ y.wrapping_mul(19349663) ^ z.wrapping_mul(83492791);
    h ^= ((h as u32) >> 15) as i32;
    h = h.wrapping_mul(739982445);
    h ^= ((h as u32) >> 13) as i32;
    1.0 - range * ((((h as u32) >> 8) & 0xFF) as f32 / 255.0)
}

fn hash3(x: i32, y: i32, z: i32) -> u32 {
    let mut h = x.wrapping_mul(374761393).wrapping_add(y.wrapping_mul(668265263)).wrapping_add(z.wrapping_mul(1274126177));
    h = (h ^ (((h as u32) >> 13) as i32)).wrapping_mul(-1028477387);
    ((h ^ (((h as u32) >> 16) as i32)) as u32) & 0x7FFF_FFFF
}

/// Largest side (in blocks) of a merged quad. Smaller than a whole chunk so the biome tint, which is blended
/// between the quad's corners, stays close to the per-block result.
const MERGE_CAP: usize = 8;
/// Flat water surfaces in merged chunks can cover a whole chunk with one quad: the water has no tint and the
/// texture repeats per block, so there is nothing that must stay small.
const WATER_MERGE_CAP: usize = 16;
/// The staged-face layer used for flat water surfaces (after the six block face directions).
const WATER_TOP: usize = 6;
const MASK_FACES: usize = 7;
/// Merged quads are grown by this much along their plane so the cracks that appear where a big quad meets
/// smaller ones (T-junctions) are covered.
const MERGE_GROW: f32 = 0.003;
/// The average of the per-block brightness variation that merged meshes use instead (see `variation`).
const MERGED_VARIATION: f32 = 0.965;
const MERGED_VARIATION_CUTOUT: f32 = 0.93;
/// Cave darkening is stored in 1/12 steps in merged meshes (so faces that are almost equally dark can merge).
const LIGHT_STEPS: f32 = 12.0;

/// Texture mapping of the six faces for merged quads: whether the texture's first / second axis runs against the
/// quad's first / second axis (see `merged_axes`).
const MERGE_FLIP_A: [bool; 6] = [false, false, true, false, true, false];
const MERGE_FLIP_B: [bool; 6] = [false, false, true, true, true, true];

/// The axes (0 = x, 1 = y, 2 = z) a face's merge grid is laid out on: `(u, v, normal)`.
fn merged_axes(face: usize) -> (usize, usize, usize) {
    match face {
        0 | 1 => (0, 2, 1),
        2 | 3 => (0, 1, 2),
        _ => (2, 1, 0),
    }
}

/// A cube face that will be drawn, before its vertices are made.
struct FaceInfo {
    layer: i32,
    /// Cave darkening, 1.0 = none.
    light: f32,
}

struct Builder<'a> {
    pad: Vec<u8>,
    hpad: Vec<i16>,
    base_x: i32,
    base_z: i32,
    palette: &'a BiomePalette,
    tint_grid: [[f32; 3]; 25],
    verts: Vec<Vertex>,
    idx: [Vec<u32>; PASS_COUNT],
    /// Merged mode: one face descriptor per cell, per face direction and layer of the section being built
    /// (`[(face * 16 + slice) * 256 + v * 16 + u]`, 0 = no face). The seventh direction is flat water surfaces.
    /// Empty when not merging.
    masks: Vec<u32>,
    /// How many faces are staged in each `(face, slice)` of `masks`, so empty layers are skipped.
    staged: [u16; MASK_FACES * 16],
}

fn pack_u8(v: f32) -> u8 {
    let x = v * 255.0 + 0.5;
    if x <= 0.0 {
        0
    } else if x >= 255.0 {
        255
    } else {
        x as u8
    }
}

impl<'a> Builder<'a> {
    #[inline]
    fn raw(&self, x: i32, y: i32, z: i32) -> u8 {
        self.pad[pidx(x, y, z)]
    }

    #[inline]
    fn opaque(&self, x: i32, y: i32, z: i32) -> bool {
        OPAQUE_BY_ID[(self.raw(x, y, z) & 31) as usize]
    }

    /// Which pairs of faces of the section starting at height `y0` can see each other (see `visibility`).
    fn section_vis(&self, y0: i32) -> u16 {
        let open = visibility::open_cells(|i| {
            let x = (i & 15) as i32;
            let z = ((i >> 4) & 15) as i32;
            let y = y0 + (i >> 8) as i32;
            !self.opaque(x, y, z)
        });
        visibility::section_connectivity(&open)
    }

    #[inline]
    fn ground(&self, x: i32, z: i32) -> i32 {
        self.hpad[((z + 1) as usize) * PAD_XZ + (x + 1) as usize] as i32
    }

    fn field_at(&self, vx: f32, vz: f32) -> [f32; 3] {
        let fx = (vx / 4.0).max(0.0).min(3.999);
        let fz = (vz / 4.0).max(0.0).min(3.999);
        let gx = fx as usize;
        let gz = fz as usize;
        let tx = fx - gx as f32;
        let tz = fz - gz as f32;
        let a = &self.tint_grid[gz * 5 + gx];
        let b = &self.tint_grid[gz * 5 + gx + 1];
        let c = &self.tint_grid[(gz + 1) * 5 + gx];
        let d = &self.tint_grid[(gz + 1) * 5 + gx + 1];
        let mut out = [0.0f32; 3];
        for k in 0..3 {
            let top = a[k] + (b[k] - a[k]) * tx;
            let bot = c[k] + (d[k] - c[k]) * tx;
            out[k] = top + (bot - top) * tz;
        }
        out
    }

    /// The colour bytes and tint mode for a vertex of a tile at chunk-local (vx, vz).
    fn tint_bytes(&self, info: Option<TintInfo>, vx: f32, vz: f32) -> ([u8; 3], u8) {
        let info = match info {
            Some(i) => i,
            None => return ([128, 128, 128], 0),
        };
        let f = self.field_at(vx, vz);
        let anchor = match info.anchor {
            Anchor::Grass => &self.palette.grass,
            Anchor::Dry => &self.palette.dry,
            Anchor::Swamp => &self.palette.swamp,
        };
        let mut out = [0u8; 3];
        for k in 0..3 {
            let factor = f[k] / anchor[k].max(1.0);
            let t = 1.0 + (factor - 1.0) * info.strength;
            out[k] = pack_u8(t * 0.5);
        }
        (out, info.mode)
    }

    fn push_vertex(&mut self, pos: [f32; 3], uv: [f32; 2], rgb: [u8; 3], shade: f32, layer: i32, mode: u8) -> u32 {
        let i = self.verts.len() as u32;
        self.verts.push(Vertex {
            pos,
            uv,
            color: [rgb[0], rgb[1], rgb[2], pack_u8(shade)],
            info: [layer as u8, mode, 0, 0],
        });
        i
    }

    fn push_quad(&mut self, pass: usize, v: [u32; 4], flip: bool) {
        let list = &mut self.idx[pass];
        if !flip {
            list.extend_from_slice(&[v[0], v[1], v[2], v[0], v[2], v[3]]);
        } else {
            list.extend_from_slice(&[v[1], v[2], v[3], v[1], v[3], v[0]]);
        }
    }

    // ------------------------------------------------------------------ cube faces

    fn ao_level(&self, x: i32, y: i32, z: i32, face: usize, corner: [i32; 3]) -> usize {
        let n = FACE_NORMAL[face];
        let bx = x + n[0];
        let by = y + n[1];
        let bz = z + n[2];
        // the two tangent axes of this face
        let mut axes = [0usize; 2];
        let mut k = 0;
        for a in 0..3 {
            if n[a] == 0 {
                axes[k] = a;
                k += 1;
            }
        }
        let sign = |a: usize| if corner[a] == 1 { 1 } else { -1 };
        let mut s1 = [0i32; 3];
        let mut s2 = [0i32; 3];
        s1[axes[0]] = sign(axes[0]);
        s2[axes[1]] = sign(axes[1]);
        let side1 = self.opaque(bx + s1[0], by + s1[1], bz + s1[2]);
        let side2 = self.opaque(bx + s2[0], by + s2[1], bz + s2[2]);
        let corner_occ = self.opaque(bx + s1[0] + s2[0], by + s1[1] + s2[1], bz + s1[2] + s2[2]);
        if side1 && side2 {
            0
        } else {
            3 - (side1 as usize + side2 as usize + corner_occ as usize)
        }
    }

    /// Whether `face` of the cube `block` at (x, y, z) can be seen at all, and if so what it looks like.
    fn visible_face(&self, block: Block, face: Face, x: i32, y: i32, z: i32) -> Option<FaceInfo> {
        let fi = face as usize;
        let n = FACE_NORMAL[fi];
        let ny = y + n[1];
        if ny < 0 {
            return None; // below the world floor: never visible
        }
        let nraw = self.raw(x + n[0], ny, z + n[2]);
        let nid = (nraw & 31) as usize;
        if OPAQUE_BY_ID[nid] {
            return None;
        }
        if block.cutout() && CUTOUT_BY_ID[nid] {
            return None;
        }
        let layer = block.cell_for(face);
        if layer < 0 {
            return None;
        }
        // cave darkening: faces looking into a cell that lies well under the ground get darker with depth
        let mut light = 1.0f32;
        if y <= self.ground(x, z) - CAVE_DARK_START {
            let buried = self.ground(x + n[0], z + n[2]) - ny;
            if buried >= CAVE_DARK_START {
                let mut step = buried - CAVE_DARK_START;
                if step > MAX_LIGHT_STEP {
                    step = MAX_LIGHT_STEP;
                }
                light = 1.0 - step as f32 * CAVE_DARK_RATE;
            }
        }
        Some(FaceInfo { layer, light })
    }

    /// Merged mode: notes the face in the section's masks instead of making vertices for it.
    fn stage_face(&mut self, block: Block, face: Face, x: i32, y: i32, z: i32) {
        let info = match self.visible_face(block, face, x, y, z) {
            Some(i) => i,
            None => return,
        };
        let fi = face as usize;
        let ly = (y & 15) as usize;
        let (slice, u, v) = match fi {
            0 | 1 => (ly, x as usize, z as usize),
            2 | 3 => (z as usize, x as usize, ly),
            _ => (x as usize, z as usize, ly),
        };
        let steps = (info.light * LIGHT_STEPS + 0.5) as u32;
        let pass = if block.cutout() { 1u32 } else { 0 };
        let descriptor = (1u32 << 31) | (pass << 16) | (steps << 8) | info.layer as u32;
        self.masks[(fi * 16 + slice) * 256 + v * 16 + u] = descriptor;
        self.staged[fi * 16 + slice] += 1;
    }

    /// Merged mode: turns the staged faces of the section starting at height `y0` into quads, merging runs of
    /// identical neighbouring faces, and clears the masks for the next section.
    fn flush_merged(&mut self, y0: i32) {
        for fi in 0..MASK_FACES {
            let cap = if fi == WATER_TOP { WATER_MERGE_CAP } else { MERGE_CAP };
            for slice in 0..16usize {
                if self.staged[fi * 16 + slice] == 0 {
                    continue;
                }
                self.staged[fi * 16 + slice] = 0;
                let base = (fi * 16 + slice) * 256;
                for v in 0..16usize {
                    let mut u = 0usize;
                    while u < 16 {
                        let d = self.masks[base + v * 16 + u];
                        if d == 0 {
                            u += 1;
                            continue;
                        }
                        let mut w = 1usize;
                        while u + w < 16 && w < cap && self.masks[base + v * 16 + u + w] == d {
                            w += 1;
                        }
                        let mut h = 1usize;
                        'grow: while v + h < 16 && h < cap {
                            for k in 0..w {
                                if self.masks[base + (v + h) * 16 + u + k] != d {
                                    break 'grow;
                                }
                            }
                            h += 1;
                        }
                        for dv in 0..h {
                            for du in 0..w {
                                self.masks[base + (v + dv) * 16 + u + du] = 0;
                            }
                        }
                        if fi == WATER_TOP {
                            self.merged_water_quad(slice, u, v, w, h, d, y0);
                        } else {
                            self.merged_quad(fi, slice, u, v, w, h, d, y0);
                        }
                        u += w;
                    }
                }
            }
        }
    }

    /// One merged quad: `w` x `h` cells starting at (`u`, `v`) of layer `slice` of face direction `fi`.
    fn merged_quad(&mut self, fi: usize, slice: usize, u: usize, v: usize, w: usize, h: usize, descriptor: u32, y0: i32) {
        let layer = (descriptor & 0xFF) as i32;
        let steps = (descriptor >> 8) & 0xFF;
        let cutout = (descriptor >> 16) & 1 != 0;
        let light = steps as f32 / LIGHT_STEPS;
        let (ua, va, na) = merged_axes(fi);
        // chunk-local position of the quad's first cell
        let mut origin = [0i32; 3];
        origin[ua] = u as i32;
        origin[va] = v as i32;
        origin[na] = slice as i32;
        // exactly one of the three axes is the height; it is counted from the bottom of the section
        origin[1] += y0;
        let variation = if cutout { MERGED_VARIATION_CUTOUT } else { MERGED_VARIATION };
        let shade = FACE_SHADE[fi] * light * variation;
        let tint = tint_for_cell(layer);
        let mut ids = [0u32; 4];
        for c in 0..4 {
            let corner = FACE_CORNERS[fi][c];
            let cu = corner[ua] as f32;
            let cv = corner[va] as f32;
            let mut p = [0.0f32; 3];
            p[ua] = origin[ua] as f32 + cu * w as f32 + (cu * 2.0 - 1.0) * MERGE_GROW;
            p[va] = origin[va] as f32 + cv * h as f32 + (cv * 2.0 - 1.0) * MERGE_GROW;
            p[na] = origin[na] as f32 + corner[na] as f32;
            let tu = if MERGE_FLIP_A[fi] { 1.0 - cu } else { cu } * w as f32;
            let tv = if MERGE_FLIP_B[fi] { 1.0 - cv } else { cv } * h as f32;
            let (rgb, mode) = self.tint_bytes(tint, p[0], p[2]);
            ids[c] = self.push_vertex(p, [tu, tv], rgb, shade, layer, mode);
        }
        let pass = if cutout { PASS_CUTOUT } else { PASS_OPAQUE };
        self.push_quad(pass, ids, false);
    }

    /// One merged flat water surface: `w` x `h` cells starting at (`u`, `v`) of the layer `slice` of the section
    /// starting at height `y0`; the descriptor holds the surface height in 1/255 of a block.
    fn merged_water_quad(&mut self, slice: usize, u: usize, v: usize, w: usize, h: usize, descriptor: u32, y0: i32) {
        let height = (descriptor & 0xFF) as f32 / 255.0;
        let y = y0 + slice as i32;
        let shade = (1.0 - 0.012 * (SEA_LEVEL - y).max(0) as f32).max(0.5);
        let uv_x = (self.base_x + u as i32).rem_euclid(16) as f32;
        let uv_z = (self.base_z + v as i32).rem_euclid(16) as f32;
        let mut ids = [0u32; 4];
        for c in 0..4 {
            let corner = FACE_CORNERS[Face::Top as usize][c];
            let cx = corner[0] as f32;
            let cz = corner[2] as f32;
            ids[c] = self.push_vertex(
                [
                    u as f32 + cx * w as f32 + (cx * 2.0 - 1.0) * MERGE_GROW,
                    y as f32 + height,
                    v as f32 + cz * h as f32 + (cz * 2.0 - 1.0) * MERGE_GROW,
                ],
                [uv_x + cx * w as f32, uv_z + cz * h as f32],
                [128, 128, 128],
                shade,
                cells::WATER,
                0,
            );
        }
        self.push_quad(PASS_WATER, ids, false);
    }

    fn cube_face(&mut self, block: Block, face: Face, x: i32, y: i32, z: i32) {
        let fi = face as usize;
        let info = match self.visible_face(block, face, x, y, z) {
            Some(i) => i,
            None => return,
        };
        let layer = info.layer;
        let light = info.light;
        let wx = self.base_x + x;
        let wz = self.base_z + z;
        let range = if block.cutout() { 0.14 } else { 0.07 };
        let shade = FACE_SHADE[fi] * light * variation(wx, y, wz, range);

        // texture orientation variant
        let flags = variant_flags(layer);
        let h = hash3(wx, y, wz).wrapping_add((fi as u32).wrapping_mul(0x9E37_79B1));
        let h = h ^ (h >> 15);
        let do_fx = flags & FLIP_X != 0 && (h & 1) != 0;
        let do_fy = flags & FLIP_Y != 0 && (h & 2) != 0;
        let do_sw = flags & SWAP != 0 && (h & 4) != 0;

        let uvs = match face {
            Face::Top => &UV_TOP,
            Face::Bottom => &UV_BOTTOM,
            _ => &UV_SIDE,
        };
        let tint = tint_for_cell(layer);
        let mut ids = [0u32; 4];
        let mut ao = [3usize; 4];
        for c in 0..4 {
            let corner = FACE_CORNERS[fi][c];
            ao[c] = self.ao_level(x, y, z, fi, corner);
            let mut u = uvs[c][0];
            let mut t = uvs[c][1];
            if do_fx {
                u = 1.0 - u;
            }
            if do_fy {
                t = 1.0 - t;
            }
            if do_sw {
                std::mem::swap(&mut u, &mut t);
            }
            let vx = (x + corner[0]) as f32;
            let vy = (y + corner[1]) as f32;
            let vz = (z + corner[2]) as f32;
            let (rgb, mode) = self.tint_bytes(tint, vx, vz);
            ids[c] = self.push_vertex([vx, vy, vz], [u, t], rgb, shade * AO_SHADE[ao[c]], layer, mode);
        }
        let flip = (ao[0] + ao[2]) < (ao[1] + ao[3]);
        let pass = if block.cutout() { PASS_CUTOUT } else { PASS_OPAQUE };
        self.push_quad(pass, ids, flip);
    }

    // ------------------------------------------------------------------ plants

    fn plant(&mut self, block: Block, x: i32, y: i32, z: i32) {
        let wx = self.base_x + x;
        let wz = self.base_z + z;
        let h = hash3(wx, y, wz);
        let layer = if block == Block::Seagrass {
            if h & 1 == 0 {
                cells::SEAGRASS_A
            } else {
                cells::SEAGRASS_B
            }
        } else {
            block.cell_for(Face::Top)
        };
        if layer < 0 {
            return;
        }
        let tint = tint_for_cell(layer);
        let var = variation(wx, y, wz, 0.16);
        let fx = x as f32;
        let fz = z as f32;
        let fy = y as f32;

        if block.flat() {
            // lily pad: one flat quad just above the water surface
            let py = fy - 0.115;
            let corners = [[0.0f32, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]];
            let mut ids = [0u32; 4];
            for (c, corner) in corners.iter().enumerate() {
                let (rgb, mode) = self.tint_bytes(tint, fx + corner[0], fz + corner[1]);
                let (u, t) = if h & 2 == 0 { (corner[0], corner[1]) } else { (corner[1], corner[0]) };
                ids[c] = self.push_vertex([fx + corner[0], py, fz + corner[1]], [u, t], rgb, 0.95 * var, layer, mode);
            }
            self.push_quad(PASS_DOUBLE, ids, false);
            return;
        }

        // two crossed quads through the cell diagonals, nudged by a per-cell offset
        let ox = (((h >> 8) & 15) as f32 / 15.0) * 0.3 - 0.15;
        let oz = (((h >> 12) & 15) as f32 / 15.0) * 0.3 - 0.15;
        let lo = 0.1f32;
        let hi = 0.9f32;
        let quads: [[[f32; 2]; 2]; 2] = [[[lo, lo], [hi, hi]], [[hi, lo], [lo, hi]]];
        for q in quads.iter() {
            let a = q[0];
            let b = q[1];
            let corners = [
                ([a[0], 0.0, a[1]], [0.0f32, 1.0], 0.78f32),
                ([b[0], 0.0, b[1]], [1.0, 1.0], 0.78),
                ([b[0], 1.0, b[1]], [1.0, 0.0], 1.0),
                ([a[0], 1.0, a[1]], [0.0, 0.0], 1.0),
            ];
            let mut ids = [0u32; 4];
            for (c, (p, uv, s)) in corners.iter().enumerate() {
                let px = fx + p[0] + ox;
                let pz = fz + p[2] + oz;
                let (rgb, mode) = self.tint_bytes(tint, px, pz);
                ids[c] = self.push_vertex([px, fy + p[1], pz], *uv, rgb, s * var, layer, mode);
            }
            self.push_quad(PASS_DOUBLE, ids, false);
        }
    }

    // ------------------------------------------------------------------ water

    fn water_corner_height(&self, x: i32, y: i32, z: i32, cx: i32, cz: i32) -> f32 {
        let mut sum = 0.0f32;
        let mut wsum = 0.0f32;
        for dz in (cz - 1)..=cz {
            for dx in (cx - 1)..=cx {
                let nx = x + dx;
                let nz = z + dz;
                let r = self.raw(nx, y, nz);
                let a = fluid::amount_of(r);
                if a > 0 {
                    if fluid::amount_of(self.raw(nx, y + 1, nz)) > 0 {
                        return 1.0;
                    }
                    let w = if a >= fluid::SOURCE { 10.0 } else { 1.0 };
                    sum += fluid::height_of(a) * w;
                    wsum += w;
                } else if !SOLID_BY_ID[(r & 31) as usize] {
                    wsum += 1.0; // air or a plant: counts as height 0
                }
            }
        }
        if wsum <= 0.0 {
            0.0
        } else {
            sum / wsum
        }
    }

    fn water(&mut self, x: i32, y: i32, z: i32) {
        let depth = (SEA_LEVEL - y).max(0) as f32;
        let depth_shade = (1.0 - 0.012 * depth).max(0.5);
        let wx = self.base_x + x;
        let wz = self.base_z + z;
        // wraps every 16 blocks: the texture repeats per block and the ripples in the water shader have periods
        // of 4, 8 and 16 blocks, so nothing changes, but the numbers stay small enough for the shader's
        // half-precision interpolation to keep the texture steady
        let uv_x = (wx.rem_euclid(16)) as f32;
        let uv_z = (wz.rem_euclid(16)) as f32;
        let above = fluid::amount_of(self.raw(x, y + 1, z));
        let layer = cells::WATER;
        let rgb = [128u8, 128, 128];

        if above == 0 {
            let mut heights = [0.0f32; 4];
            for c in 0..4 {
                let corner = FACE_CORNERS[Face::Top as usize][c];
                heights[c] = self.water_corner_height(x, y, z, corner[0], corner[2]);
            }
            let flat = heights.iter().all(|&h| h == heights[0]);
            if flat && !self.masks.is_empty() {
                // merged mode: a flat surface (open sea, a calm lake) joins its neighbours into bigger quads
                let slice = (y & 15) as usize;
                self.masks[(WATER_TOP * 16 + slice) * 256 + z as usize * 16 + x as usize] = (1u32 << 31) | pack_u8(heights[0]) as u32;
                self.staged[WATER_TOP * 16 + slice] += 1;
            } else {
                let mut ids = [0u32; 4];
                for c in 0..4 {
                    let corner = FACE_CORNERS[Face::Top as usize][c];
                    ids[c] = self.push_vertex(
                        [(x + corner[0]) as f32, y as f32 + heights[c], (z + corner[2]) as f32],
                        [uv_x + corner[0] as f32, uv_z + corner[2] as f32],
                        rgb,
                        depth_shade,
                        layer,
                        0,
                    );
                }
                self.push_quad(PASS_WATER, ids, false);
            }
        }

        for face in [Face::North, Face::South, Face::East, Face::West] {
            let fi = face as usize;
            let n = FACE_NORMAL[fi];
            let nraw = self.raw(x + n[0], y, z + n[2]);
            if fluid::amount_of(nraw) > 0 || OPAQUE_BY_ID[(nraw & 31) as usize] {
                continue;
            }
            let mut ids = [0u32; 4];
            for c in 0..4 {
                let corner = FACE_CORNERS[fi][c];
                let top = if corner[1] == 1 { self.water_corner_height(x, y, z, corner[0], corner[2]) } else { 0.0 };
                ids[c] = self.push_vertex(
                    [(x + corner[0]) as f32, y as f32 + top, (z + corner[2]) as f32],
                    [uv_x + uv_z + (corner[0] + corner[2]) as f32, y as f32 + top],
                    rgb,
                    0.8 * depth_shade,
                    layer,
                    0,
                );
            }
            self.push_quad(PASS_WATER, ids, false);
        }

        if y > 0 {
            let below = self.raw(x, y - 1, z);
            if fluid::amount_of(below) == 0 && !OPAQUE_BY_ID[(below & 31) as usize] {
                let mut ids = [0u32; 4];
                for c in 0..4 {
                    let corner = FACE_CORNERS[Face::Bottom as usize][c];
                    ids[c] = self.push_vertex(
                        [(x + corner[0]) as f32, y as f32, (z + corner[2]) as f32],
                        [uv_x + corner[0] as f32, uv_z + corner[2] as f32],
                        rgb,
                        0.6 * depth_shade,
                        layer,
                        0,
                    );
                }
                self.push_quad(PASS_WATER, ids, false);
            }
        }
    }
}

/// Builds the mesh of the centre chunk of `input`. All eight neighbours should be present (a missing one
/// reads as air).
pub fn build_chunk_mesh(input: &MeshInput, ctx: &MeshContext) -> ChunkMeshData {
    let center = match &input.chunks[4] {
        Some(c) => c,
        None => return ChunkMeshData::empty(),
    };
    let top_sub = center.top_section();
    if top_sub < 0 {
        return ChunkMeshData::empty();
    }
    let max_y = std::cmp::min(top_sub * 16 + 15, WORLD_HEIGHT - 1);

    // padded copy of the blocks and the height map, so neighbour lookups need no chunk arithmetic
    let mut pad = vec![0u8; PAD_XZ * PAD_XZ * PAD_Y];
    let mut hpad = vec![0i16; PAD_XZ * PAD_XZ];
    for pz in 0..PAD_XZ as i32 {
        for px in 0..PAD_XZ as i32 {
            let lx = px - 1;
            let lz = pz - 1;
            let cdx: usize = if lx < 0 { 0 } else if lx >= 16 { 2 } else { 1 };
            let cdz: usize = if lz < 0 { 0 } else if lz >= 16 { 2 } else { 1 };
            let chunk = match &input.chunks[cdz * 3 + cdx] {
                Some(c) => c,
                None => continue,
            };
            let mx = lx.rem_euclid(16);
            let mz = lz.rem_euclid(16);
            hpad[(pz as usize) * PAD_XZ + px as usize] = chunk.height_map[(mz * 16 + mx) as usize];
            for sub in 0..16usize {
                if let Some(sec) = &chunk.sections[sub] {
                    for ly in 0..16i32 {
                        let y = sub as i32 * 16 + ly;
                        pad[pidx(lx, y, lz)] = sec[(((ly * 16 + mz) * 16) + mx) as usize];
                    }
                }
            }
        }
    }

    let base_x = input.pos.x * 16;
    let base_z = input.pos.z * 16;
    let palette = &ctx.color_field.palette;
    let mut tint_grid = [[0.0f32; 3]; 25];
    for gz in 0..5 {
        for gx in 0..5 {
            tint_grid[gz * 5 + gx] =
                ctx.color_field.grass_at((base_x + gx as i32 * 4) as f64, (base_z + gz as i32 * 4) as f64);
        }
    }

    let merge = input.merge;
    let mut b = Builder {
        pad,
        hpad,
        base_x,
        base_z,
        palette,
        tint_grid,
        verts: Vec::with_capacity(4096),
        idx: [Vec::new(), Vec::new(), Vec::new(), Vec::new()],
        masks: if merge { vec![0u32; MASK_FACES * 16 * 256] } else { Vec::new() },
        staged: [0; MASK_FACES * 16],
    };

    // Section by section, bottom to top, so that the indices of one section are contiguous in every pass.
    let section_count = (max_y / 16 + 1) as usize;
    let mut marks = [[0u32; SECTIONS + 1]; PASS_COUNT];
    let mut vis = [visibility::OPEN; SECTIONS];
    let mut top_block_y = 0;
    for s in 0..section_count {
        for p in 0..PASS_COUNT {
            marks[p][s] = b.idx[p].len() as u32;
        }
        let y0 = s as i32 * 16;
        for y in y0..y0 + 16 {
            for z in 0..16 {
                for x in 0..16 {
                    let raw = b.raw(x, y, z);
                    if raw == 0 {
                        continue;
                    }
                    if y > top_block_y {
                        top_block_y = y;
                    }
                    let block = Block::from_raw(raw);
                    if fluid::amount_of(raw) > 0 {
                        b.water(x, y, z);
                    }
                    if block.plant() {
                        // merged meshes belong to far chunks, where a tuft of grass is a few pixels of noise
                        // that costs four triangles each: leave plants out there
                        if !merge {
                            b.plant(block, x, y, z);
                        }
                        continue;
                    }
                    if block == Block::Water {
                        continue;
                    }
                    for face in Face::ALL.iter() {
                        if merge {
                            b.stage_face(block, *face, x, y, z);
                        } else {
                            b.cube_face(block, *face, x, y, z);
                        }
                    }
                }
            }
        }
        if merge {
            b.flush_merged(y0);
        }
        if center.sections[s].is_some() {
            vis[s] = b.section_vis(y0);
        }
    }
    for p in 0..PASS_COUNT {
        for s in section_count..=SECTIONS {
            marks[p][s] = b.idx[p].len() as u32;
        }
    }

    let mut indices: Vec<u32> = Vec::with_capacity(b.idx.iter().map(|v| v.len()).sum());
    let mut ranges = [(0u32, 0u32); PASS_COUNT];
    let mut section_starts = [[0u32; SECTIONS + 1]; PASS_COUNT];
    for p in 0..PASS_COUNT {
        let base = indices.len() as u32;
        ranges[p] = (base, b.idx[p].len() as u32);
        for s in 0..=SECTIONS {
            section_starts[p][s] = base + marks[p][s];
        }
        indices.extend_from_slice(&b.idx[p]);
    }
    // the lowest section that has anything to draw
    let first_section = (0..SECTIONS).find(|s| (0..PASS_COUNT).any(|p| marks[p][s + 1] > marks[p][*s])).unwrap_or(0);
    ChunkMeshData {
        vertices: b.verts,
        indices,
        ranges,
        section_starts,
        vis,
        min_y: (first_section * 16) as f32,
        max_y: (top_block_y + 2) as f32,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gen::terrain::TerrainGenerator;
    use crate::mesh::biome_color::BiomePalette;

    fn context(gen: &TerrainGenerator) -> MeshContext {
        MeshContext {
            color_field: Arc::new(BiomeColorField::new(gen.climate.clone(), gen.shape.clone(), BiomePalette::from_tiles())),
        }
    }

    fn input_for(gen: &TerrainGenerator, pos: ChunkPos) -> MeshInput {
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| None);
        for dz in -1..=1 {
            for dx in -1..=1 {
                chunks[((dz + 1) * 3 + (dx + 1)) as usize] = Some(gen.generate(ChunkPos::new(pos.x + dx, pos.z + dz)));
            }
        }
        MeshInput { pos, chunks, merge: false }
    }

    #[test]
    fn terrain_chunk_produces_a_consistent_mesh() {
        let gen = TerrainGenerator::new(555);
        let ctx = context(&gen);
        let mesh = build_chunk_mesh(&input_for(&gen, ChunkPos::new(0, 0)), &ctx);
        assert!(!mesh.vertices.is_empty());
        assert_eq!(mesh.indices.len() % 3, 0);
        for &i in mesh.indices.iter() {
            assert!((i as usize) < mesh.vertices.len());
        }
        let total: u32 = mesh.ranges.iter().map(|r| r.1).sum();
        assert_eq!(total as usize, mesh.indices.len());
    }

    #[test]
    fn single_block_has_six_faces() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        if let Some(c) = chunks[4].as_mut() {
            c.set(5, 100, 5, Block::Stone);
        }
        let mesh = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: false }, &ctx);
        assert_eq!(mesh.vertices.len(), 24);
        assert_eq!(mesh.indices.len(), 36);
    }

    fn merged_input(gen: &TerrainGenerator, pos: ChunkPos) -> MeshInput {
        let mut input = input_for(gen, pos);
        input.merge = true;
        input
    }

    /// The area (in whole blocks) of every flat quad in a pass: the six indices of a quad span a box that is
    /// flat in one direction.
    fn pass_area(mesh: &ChunkMeshData, pass: usize) -> u64 {
        let (first, count) = mesh.ranges[pass];
        let mut total = 0u64;
        let mut k = first as usize;
        let end = (first + count) as usize;
        while k < end {
            let mut lo = [f32::MAX; 3];
            let mut hi = [f32::MIN; 3];
            for j in 0..6 {
                let p = mesh.vertices[mesh.indices[k + j] as usize].pos;
                for a in 0..3 {
                    lo[a] = lo[a].min(p[a]);
                    hi[a] = hi[a].max(p[a]);
                }
            }
            let mut dims = [(hi[0] - lo[0]).round(), (hi[1] - lo[1]).round(), (hi[2] - lo[2]).round()];
            dims.sort_by(|a, b| a.partial_cmp(b).unwrap());
            assert!(dims[0] == 0.0, "quads must be flat, got {:?}", dims);
            total += (dims[1] * dims[2]) as u64;
            k += 6;
        }
        total
    }

    #[test]
    fn merged_meshes_cover_the_same_blocks_with_fewer_triangles() {
        for (seed, x, z) in [(555i64, 0, 0), (7, 3, -2), (1234, -5, 4)] {
            let gen = TerrainGenerator::new(seed);
            let ctx = context(&gen);
            let pos = ChunkPos::new(x, z);
            let detail = build_chunk_mesh(&input_for(&gen, pos), &ctx);
            let merged = build_chunk_mesh(&merged_input(&gen, pos), &ctx);
            for pass in [PASS_OPAQUE, PASS_CUTOUT] {
                assert_eq!(pass_area(&detail, pass), pass_area(&merged, pass), "seed {} pass {}: a face was lost or doubled", seed, pass);
            }
            assert!(merged.ranges[PASS_WATER].1 <= detail.ranges[PASS_WATER].1, "merging must never add water triangles");
            assert_eq!(merged.ranges[PASS_DOUBLE].1, 0, "far chunks leave plants out");
            assert!(
                merged.indices.len() < detail.indices.len() * 9 / 10,
                "seed {}: merging saved too little ({} -> {})",
                seed,
                detail.indices.len(),
                merged.indices.len()
            );
            for &i in merged.indices.iter() {
                assert!((i as usize) < merged.vertices.len());
            }
        }
    }

    #[test]
    fn a_calm_sea_is_one_quad_per_chunk_when_merged() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        for c in chunks.iter_mut().flatten() {
            for x in 0..16 {
                for z in 0..16 {
                    for y in 0..=30 {
                        c.set(x, y, z, Block::Stone);
                    }
                    c.set(x, 31, z, Block::Water);
                }
            }
        }
        let detail = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks: chunks.clone(), merge: false }, &ctx);
        let merged = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: true }, &ctx);
        assert_eq!(detail.ranges[PASS_WATER].1, 256 * 6, "one quad per surface cell");
        assert_eq!(merged.ranges[PASS_WATER].1, 6, "the whole calm surface is one quad");
        // the same surface: same height, covering the whole chunk
        let (first, count) = merged.ranges[PASS_WATER];
        let mut lo = [f32::MAX; 3];
        let mut hi = [f32::MIN; 3];
        for k in first..first + count {
            let p = merged.vertices[merged.indices[k as usize] as usize].pos;
            for a in 0..3 {
                lo[a] = lo[a].min(p[a]);
                hi[a] = hi[a].max(p[a]);
            }
        }
        assert!((lo[1] - hi[1]).abs() < 1e-6 && (lo[1] - 31.875).abs() < 0.005, "height {} .. {}", lo[1], hi[1]);
        assert!(lo[0] < 0.01 && hi[0] > 15.99 && lo[2] < 0.01 && hi[2] > 15.99, "{:?} {:?}", lo, hi);
    }

    #[test]
    fn a_shore_keeps_its_sloping_water_cells() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        for c in chunks.iter_mut().flatten() {
            for x in 0..16 {
                for z in 0..16 {
                    for y in 0..=30 {
                        c.set(x, y, z, Block::Stone);
                    }
                }
            }
        }
        // a 4 x 4 pond: its middle is flat, its rim slopes down to the dry land around it
        if let Some(c) = chunks[4].as_mut() {
            for x in 6..10 {
                for z in 6..10 {
                    c.set(x, 31, z, Block::Water);
                }
            }
        }
        let detail = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks: chunks.clone(), merge: false }, &ctx);
        let merged = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: true }, &ctx);
        let (detail_quads, merged_quads) = (detail.ranges[PASS_WATER].1 / 6, merged.ranges[PASS_WATER].1 / 6);
        // 16 surface cells and the 16 sides of the pond; only the flat middle 2 x 2 cells join into one quad
        assert_eq!(detail_quads, 32);
        assert_eq!(merged_quads, 32 - 3, "the four flat middle cells become one quad, the sloping rim stays");
    }

    #[test]
    fn plants_are_built_for_near_chunks_and_left_out_for_far_ones() {
        let gen = TerrainGenerator::new(555);
        let ctx = context(&gen);
        let mut near_with_plants = 0;
        for x in -3..3 {
            for z in -3..3 {
                let pos = ChunkPos::new(x, z);
                let detail = build_chunk_mesh(&input_for(&gen, pos), &ctx);
                let merged = build_chunk_mesh(&merged_input(&gen, pos), &ctx);
                if detail.ranges[PASS_DOUBLE].1 > 0 {
                    near_with_plants += 1;
                }
                assert_eq!(merged.ranges[PASS_DOUBLE].1, 0);
            }
        }
        assert!(near_with_plants > 0, "the test world must have plants somewhere");
    }

    #[test]
    fn water_coordinates_stay_small() {
        let gen = TerrainGenerator::new(555);
        let ctx = context(&gen);
        let mut seen_water = false;
        for x in -4..4 {
            for z in -4..4 {
                let mesh = build_chunk_mesh(&input_for(&gen, ChunkPos::new(x, z)), &ctx);
                let (first, count) = mesh.ranges[PASS_WATER];
                for k in first..first + count {
                    let v = &mesh.vertices[mesh.indices[k as usize] as usize];
                    seen_water = true;
                    assert!(v.uv[0] >= 0.0 && v.uv[0] <= 17.0 && v.uv[1] >= 0.0 && v.uv[1] <= 17.0, "uv {:?}", v.uv);
                }
            }
        }
        assert!(seen_water, "the test world must have water somewhere");
    }

    #[test]
    fn a_flat_floor_merges_into_a_few_quads() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        for c in chunks.iter_mut().flatten() {
            for x in 0..16 {
                for z in 0..16 {
                    for y in 0..=40 {
                        c.set(x, y, z, Block::Stone);
                    }
                }
            }
        }
        let mesh = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: true }, &ctx);
        // 16 x 16 top faces become four 8 x 8 quads; the sides of the chunk are hidden by the neighbours
        assert_eq!(mesh.indices.len(), 4 * 6);
        assert_eq!(pass_area(&mesh, PASS_OPAQUE), 256);
    }

    #[test]
    fn section_ranges_split_the_index_buffer_by_height() {
        for merge in [false, true] {
            let gen = TerrainGenerator::new(555);
            let ctx = context(&gen);
            let mut input = input_for(&gen, ChunkPos::new(1, 1));
            input.merge = merge;
            let mesh = build_chunk_mesh(&input, &ctx);
            for pass in 0..PASS_COUNT {
                let starts = &mesh.section_starts[pass];
                assert_eq!(starts[0], mesh.ranges[pass].0);
                assert_eq!(starts[SECTIONS], mesh.ranges[pass].0 + mesh.ranges[pass].1);
                for s in 0..SECTIONS {
                    assert!(starts[s] <= starts[s + 1], "starts must not go backwards");
                    let lo = (s * 16) as f32 - 0.01;
                    let hi = (s * 16 + 16) as f32 + 1.01;
                    for k in starts[s]..starts[s + 1] {
                        let y = mesh.vertices[mesh.indices[k as usize] as usize].pos[1];
                        assert!(y >= lo && y <= hi, "merge {} pass {} section {}: index {} sits at y = {}", merge, pass, s, k, y);
                    }
                }
            }
            let (mut ymin, mut ymax) = (f32::MAX, f32::MIN);
            for &i in mesh.indices.iter() {
                let y = mesh.vertices[i as usize].pos[1];
                ymin = ymin.min(y);
                ymax = ymax.max(y);
            }
            assert!(mesh.min_y <= ymin + 0.01 && mesh.max_y >= ymax - 0.01, "bounds {}..{} vs {}..{}", mesh.min_y, mesh.max_y, ymin, ymax);
        }
    }

    #[test]
    fn section_visibility_follows_the_blocks() {
        let gen = TerrainGenerator::new(1);
        let ctx = context(&gen);
        let mut chunks: [Option<ChunkData>; 9] = std::array::from_fn(|_| Some(ChunkData::new()));
        if let Some(c) = chunks[4].as_mut() {
            for x in 0..16 {
                for z in 0..16 {
                    for y in 0..=59 {
                        c.set(x, y, z, Block::Stone);
                    }
                }
            }
            // a sealed pocket inside section 1 and a tunnel along x through section 2
            for x in 5..8 {
                for z in 5..8 {
                    for y in 20..23 {
                        c.set(x, y, z, Block::Air);
                    }
                }
            }
            for x in 0..16 {
                c.set(x, 40, 8, Block::Air);
            }
        }
        let mesh = build_chunk_mesh(&MeshInput { pos: ChunkPos::new(0, 0), chunks, merge: false }, &ctx);
        assert_eq!(mesh.vis[0], 0, "solid rock sees nothing");
        assert_eq!(mesh.vis[1], 0, "a sealed pocket is not connected to any face");
        assert!(visibility::connected(mesh.vis[2], visibility::EAST, visibility::WEST), "the tunnel joins east and west");
        assert!(!visibility::connected(mesh.vis[2], visibility::UP, visibility::DOWN));
        assert!(visibility::connected(mesh.vis[3], visibility::UP, visibility::EAST), "open sky above the ground");
        assert!(!visibility::connected(mesh.vis[3], visibility::DOWN, visibility::UP), "the floor of section 3 is solid");
        assert_eq!(mesh.vis[8], visibility::OPEN, "sections above the highest block are empty");
    }
}
