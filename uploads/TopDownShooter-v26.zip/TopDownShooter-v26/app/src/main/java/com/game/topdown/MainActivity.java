package com.game.topdown;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = 1.0f;
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    // ── Menu panel views ─────────────────────────────────────────────────────
    private LinearLayout menuPanel, multiPanel;
    private EditText     nameInput;
    private Button       singlePlayerBtn, multiplayerBtn;

    // ── Multiplayer panel views ───────────────────────────────────────────────
    private TextView     multiNameLabel, statusText;
    private EditText     ipInput;
    private Button       hostBtn, backBtn, scanBtn, joinIpBtn;
    private ListView     hostList;

    private final List<String[]>  hosts   = new ArrayList<>();
    private ArrayAdapter<String>  adapter;
    private final Handler         handler = new Handler(Looper.getMainLooper());
    private NetworkManager        scanner;
    private String                savedName = "";

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        // ── Window flags — must be set BEFORE setContentView ──────────────────
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                           | WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        // ── Hide system bars — must be called AFTER setContentView ─────────────
        hideSystemUI();

        // ── Menu panel ────────────────────────────────────────────────────────
        menuPanel       = findViewById(R.id.menuPanel);
        multiPanel      = findViewById(R.id.multiPanel);
        nameInput       = findViewById(R.id.nameInput);
        singlePlayerBtn = findViewById(R.id.singlePlayerBtn);
        multiplayerBtn  = findViewById(R.id.multiplayerBtn);

        singlePlayerBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            launchSinglePlayer(n);
        });

        multiplayerBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            savedName = n;
            showMultiplayer();
        });

        // ── Multiplayer panel ─────────────────────────────────────────────────
        multiNameLabel  = findViewById(R.id.multiNameLabel);
        hostBtn         = findViewById(R.id.hostBtn);
        backBtn         = findViewById(R.id.backBtn);
        scanBtn         = findViewById(R.id.scanBtn);
        joinIpBtn       = findViewById(R.id.joinIpBtn);
        ipInput         = findViewById(R.id.ipInput);
        hostList        = findViewById(R.id.hostList);
        statusText      = findViewById(R.id.statusText);

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>());
        hostList.setAdapter(adapter);

        backBtn.setOnClickListener(v -> showMenu());

        hostBtn.setOnClickListener(v -> launch(savedName, true, null));

        joinIpBtn.setOnClickListener(v -> {
            String ip = ipInput.getText().toString().trim();
            if (ip.isEmpty()) { status("Enter or select a host IP"); return; }
            launch(savedName, false, ip);
        });

        scanBtn.setOnClickListener(v -> scan());

        hostList.setOnItemClickListener((p, v, pos, id) -> {
            String ip = hosts.get(pos)[0];
            ipInput.setText(ip);
            joinIpBtn.setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(Color.parseColor("#2ecc71")));
            status("Tap JOIN to connect to " + hosts.get(pos)[1] + " (" + ip + ")");
        });
    }

    // ── Panel switching ───────────────────────────────────────────────────────
    private void showMenu() {
        menuPanel.setVisibility(View.VISIBLE);
        multiPanel.setVisibility(View.GONE);
    }

    private void showMultiplayer() {
        multiNameLabel.setText("Playing as: " + savedName);
        menuPanel.setVisibility(View.GONE);
        multiPanel.setVisibility(View.VISIBLE);
        status("");
    }

    // ── Scan ──────────────────────────────────────────────────────────────────
    private void scan() {
        hosts.clear(); adapter.clear();
        scanBtn.setEnabled(false);
        status("Scanning your Wi-Fi…");

        if (scanner != null) scanner.stop();
        scanner = new NetworkManager(new NetworkManager.Callback() {
            @Override public void onHostDiscovered(String ip, String hn) {
                handler.post(() -> {
                    for (String[] h : hosts) if (h[0].equals(ip)) return;
                    hosts.add(new String[]{ip, hn});
                    adapter.add("▶  " + hn + "  —  " + ip);
                    status("Found " + hosts.size() + " game(s). Tap one, then JOIN.");
                });
            }
            @Override public void onJoined(int i){}
            @Override public void onPlayerJoined(int i, String n){}
            @Override public void onStateUpdate(String j){}
            @Override public void onInputReceived(int i, String j){}
        });
        scanner.discoverHosts(3000);

        handler.postDelayed(() -> {
            scanBtn.setEnabled(true);
            if (hosts.isEmpty())
                status("No games found. Ask host for IP and type it above.");
        }, 3500);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private String name() {
        String s = nameInput.getText().toString().trim();
        if (s.isEmpty()) { Toast.makeText(this, "Enter your name first!", Toast.LENGTH_SHORT).show(); return null; }
        return s;
    }

    private void status(String msg) { statusText.setText(msg); }

    private void launchSinglePlayer(String name) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name);
        i.putExtra("singlePlayer", true);
        startActivity(i);
    }

    private void launch(String name, boolean host, String ip) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name);
        i.putExtra("isHost", host);
        i.putExtra("singlePlayer", false);
        if (ip != null) i.putExtra("hostIp", ip);
        startActivity(i);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (scanner != null) scanner.stop();
    }

    // ── Fullscreen helpers ────────────────────────────────────────────────────
    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController ctrl = getWindow().getInsetsController();
            if (ctrl != null) {
                ctrl.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                ctrl.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            //noinspection deprecation
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }
}
