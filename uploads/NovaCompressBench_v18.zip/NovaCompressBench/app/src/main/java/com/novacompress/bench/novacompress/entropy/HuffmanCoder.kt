package com.novacompress.bench.novacompress.entropy

import java.util.PriorityQueue

/**
 * Static (two-pass) canonical Huffman coding over the same symbol alphabet
 * the range coder uses. No adaptive state: frequencies are counted up
 * front, code lengths derived once, and the length table travels in the
 * segment header so the decoder can rebuild identical codes.
 *
 * Deliberately NOT length-limited (no package-merge algorithm): the range
 * coder is always available as a fallback via [EntropyCoderSelector], so if
 * a pathological frequency distribution would need code lengths beyond
 * [MAX_CODE_LENGTH], [build] just returns null and the caller uses range
 * coding for that segment instead of risking a subtle bug in a more
 * involved length-limiting algorithm. Real byte/token frequency data never
 * comes close to this limit in practice.
 */
object HuffmanCoder {
    const val MAX_CODE_LENGTH = 48

    data class Table(val codeLengths: IntArray, val codes: LongArray, val alphabet: Int)

    private class Node(val freq: Long, val tieBreak: Int, val symbol: Int, val left: Node?, val right: Node?)

    fun build(counts: IntArray): Table? {
        val n = counts.size
        val heap = PriorityQueue<Node>(compareBy({ it.freq }, { it.tieBreak }))
        var tieBreak = 0
        for (s in 0 until n) if (counts[s] > 0) heap.add(Node(counts[s].toLong(), tieBreak++, s, null, null))

        if (heap.isEmpty()) return Table(IntArray(n), LongArray(n), n)

        if (heap.size == 1) {
            val only = heap.poll()
            val lengths = IntArray(n)
            lengths[only.symbol] = 1
            return canonicalize(lengths, n)
        }

        while (heap.size > 1) {
            val a = heap.poll()
            val b = heap.poll()
            heap.add(Node(a.freq + b.freq, tieBreak++, -1, a, b))
        }
        val root = heap.poll()

        val lengths = IntArray(n)
        fun walk(node: Node, depth: Int) {
            if (node.left == null && node.right == null) {
                lengths[node.symbol] = maxOf(depth, 1)
                return
            }
            node.left?.let { walk(it, depth + 1) }
            node.right?.let { walk(it, depth + 1) }
        }
        walk(root, 0)

        if (lengths.any { it > MAX_CODE_LENGTH }) return null
        return canonicalize(lengths, n)
    }

    /** Derives canonical codes from a code-length table. Also used by [EntropyCoderSelector]
     *  to rebuild the same codes from the lengths transmitted in a segment header, so there's
     *  only one implementation of canonical-code assignment to keep in sync. */
    internal fun canonicalize(lengths: IntArray, n: Int): Table {
        val codes = LongArray(n)
        val order = (0 until n).filter { lengths[it] > 0 }.sortedWith(compareBy({ lengths[it] }, { it }))
        var code = 0L
        var prevLen = 0
        for (sym in order) {
            val len = lengths[sym]
            code = code shl (len - prevLen)
            codes[sym] = code
            code++
            prevLen = len
        }
        return Table(lengths, codes, n)
    }

    fun encode(symbols: IntArray, table: Table): ByteArray {
        val writer = BitWriter()
        for (sym in symbols) {
            writer.writeBits(table.codes[sym], table.codeLengths[sym])
        }
        return writer.finish()
    }

    fun decode(bytes: ByteArray, table: Table, symbolCount: Int): IntArray {
        val lookup = HashMap<Long, Int>()
        for (sym in 0 until table.alphabet) {
            val len = table.codeLengths[sym]
            if (len > 0) lookup[(len.toLong() shl 56) or table.codes[sym]] = sym
        }

        val reader = BitReader(bytes)
        val result = IntArray(symbolCount)
        for (i in 0 until symbolCount) {
            var current = 0L
            var len = 0
            while (true) {
                current = (current shl 1) or reader.readBit().toLong()
                len++
                val sym = lookup[(len.toLong() shl 56) or current]
                if (sym != null) {
                    result[i] = sym
                    break
                }
                if (len > MAX_CODE_LENGTH + 2) {
                    throw IllegalStateException("Huffman decode failed to match a code - corrupt stream or table")
                }
            }
        }
        return result
    }
}
