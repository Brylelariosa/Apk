package com.novacompress.bench.novacompress

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.novacompress.format.ChunkResearchStats
import com.novacompress.bench.novacompress.format.EncodedChunk
import com.novacompress.bench.novacompress.format.NovaContainerFormat
import com.novacompress.bench.novacompress.format.NovaResearchReport
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.Future

/**
 * The experimental research compressor. Ties together every stage from the
 * spec:
 *  - [com.novacompress.bench.novacompress.analyzer.FileAnalyzer] (Stage 1: File Analyzer)
 *  - [com.novacompress.bench.novacompress.segment.Segmenter] (Stage 2: Adaptive Segmentation)
 *  - [com.novacompress.bench.novacompress.matcher.LongRangeMatcher] (Stages 3 & 7: Structural
 *    Pattern Detection & Long-Range Matching; its repeat-offset list covers Stage 4's
 *    "micro" dictionary level)
 *  - [com.novacompress.bench.novacompress.predictor.ContextPredictor] (Stages 5 & 10:
 *    Predictive Encoder & Learning Component - one adaptive model serves both)
 *  - [com.novacompress.bench.novacompress.entropy.EntropyCoderSelector] (Stage 9: Entropy
 *    Encoder, auto-selecting range coding vs. Huffman)
 *
 * Stage 6 ("Graph-Based Pattern Compression") is deliberately *not* a
 * separate compression mechanism here: the long-range matcher already
 * deduplicates repeated structure, so a second graph-based pass over the
 * same data would be redundant engineering risk for little extra ratio.
 * Instead it shows up as analytics - which templates got referenced how
 * often - surfaced through [NovaResearchReport], matching what the spec's
 * own "Research Mode" section actually asks to *see* (detected structures,
 * repeated templates) rather than a second compressor.
 *
 * Input is read in bounded [CHUNK_SIZE] chunks - never the whole file at
 * once, so a 10GB+ file has the same peak memory as a 16MB one. Chunks
 * double as the dictionary's effective scope: all NOVA-strategy content
 * *within* one chunk shares a single match dictionary and entropy-coded
 * stream, which for any file at or under [CHUNK_SIZE] (most real files)
 * means genuinely whole-file ("global") reach with no separate mechanism
 * needed. Chunks within a batch of up to [PARALLEL_BATCH] are compressed
 * concurrently on a dedicated fixed-size [executor] (Stage 8: Parallel
 * Compression, using all CPU cores), then written to the output stream in
 * original order. This is the same trade-off production parallel
 * compressors make (pigz, zstd's multithreaded mode): a dictionary can't
 * usefully span chunks being compressed concurrently, so the chunk
 * boundary is where "global reach" gives way to "parallel throughput" -
 * see class-level docs on
 * [com.novacompress.bench.novacompress.dictionary.MultiLevelDictionary]
 * for more.
 *
 * The fan-out uses a plain [java.util.concurrent.ExecutorService] rather
 * than `kotlinx.coroutines` deliberately: [compress]/[compressWithReport]
 * are synchronous methods on the shared [CompressionAlgorithm] interface,
 * called by [com.novacompress.bench.benchmark.BenchmarkRunner] from
 * whatever thread/dispatcher the caller happens to be on. An earlier
 * version used `runBlocking { async(Dispatchers.Default) { ... } }` here,
 * which - when that caller was itself already a `Dispatchers.Default`
 * coroutine (as the benchmark ViewModel's `viewModelScope.launch` is) -
 * blocked one of that dispatcher's own limited threads for the whole
 * chunk batch, quietly reducing the pool's effective parallelism for the
 * duration. Chunk encoding never suspends (it's pure CPU work), so a
 * dedicated executor sized to [PARALLEL_BATCH] sidesteps that entirely
 * and composes safely no matter what thread calls in.
 *
 * Decompression is sequential - chunks are small and independent, but
 * unlike compression there's no length-prefix on the *compressed* chunk
 * bytes to let a reader skip ahead without parsing, so parallel decode
 * would need that framing added first. Decompression is also the cheaper
 * direction (see README benchmark notes), so this was left sequential
 * rather than adding untested framing changes late in this pass.
 */
class NovaCompressAlgorithm : CompressionAlgorithm {
    override val id = "novacompress"
    override val displayName = "NovaCompress (experimental)"
    override val category = AlgorithmCategory.EXPERIMENTAL

    override fun isAvailable() = true

    override fun compress(input: InputStream, output: OutputStream) {
        compressWithReport(input, output)
    }

    /** Same as [compress], but also returns aggregated Stage 1-10 telemetry
     *  for the Research Mode screen. The generic [compress] entry point
     *  (used by the benchmark runner for every algorithm uniformly) just
     *  discards the report. */
    fun compressWithReport(input: InputStream, output: OutputStream): NovaResearchReport {
        val dout = DataOutputStream(output)
        NovaContainerFormat.writeHeader(dout)

        var originalTotal = 0L
        var compressedTotal = 5L // header: 4 magic + 1 version
        val allStats = ArrayList<ChunkResearchStats>()

        val readBuffer = ByteArray(CHUNK_SIZE)
        var streamEnded = false
        while (!streamEnded) {
            val batch = ArrayList<ByteArray>(PARALLEL_BATCH)
            for (i in 0 until PARALLEL_BATCH) {
                val chunk = readFullyUpTo(input, readBuffer, CHUNK_SIZE)
                if (chunk == null) {
                    streamEnded = true
                    break
                }
                batch.add(chunk)
            }
            if (batch.isEmpty()) break

            // Submit the whole batch first (non-blocking) so every chunk starts compressing
            // concurrently, then collect in original order - same shape as the old
            // deferred.map { it.await() }, just without a coroutine dispatcher underneath it.
            val futures: List<Future<EncodedChunk>> = batch.map { chunkData ->
                executor.submit<EncodedChunk> { NovaContainerFormat.encodeChunk(chunkData) }
            }
            for (future in futures) {
                val encoded = try {
                    future.get()
                } catch (e: ExecutionException) {
                    // Unwrap so callers (e.g. BenchmarkRunner's failure reporting) see the
                    // original exception, not a generic ExecutionException wrapper around it.
                    throw e.cause ?: e
                }
                dout.write(encoded.bytes)
                compressedTotal += encoded.bytes.size
                allStats.add(encoded.stats)
            }
            originalTotal += batch.sumOf { it.size.toLong() }
        }

        NovaContainerFormat.writeEndMarker(dout)
        compressedTotal += 1
        dout.flush()

        return NovaResearchReport(allStats, originalTotal, compressedTotal)
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        val din = DataInputStream(input)
        NovaContainerFormat.readAndVerifyHeader(din)

        while (true) {
            val marker = din.readUnsignedByte()
            if (marker == NovaContainerFormat.MARKER_END) break
            check(marker == NovaContainerFormat.MARKER_MORE) { "Corrupt NovaCompress stream: unknown chunk marker $marker" }
            NovaContainerFormat.decodeChunk(din, output)
        }
        output.flush()
    }

    /** Reads up to [maxLen] bytes into a right-sized copy, or null at EOF
     *  with nothing read. Returns fewer than [maxLen] bytes for a partial
     *  final chunk, which [NovaContainerFormat.encodeChunk] handles fine. */
    private fun readFullyUpTo(input: InputStream, buffer: ByteArray, maxLen: Int): ByteArray? {
        var total = 0
        while (total < maxLen) {
            val read = input.read(buffer, total, maxLen - total)
            if (read == -1) break
            total += read
        }
        if (total == 0) return null
        return buffer.copyOf(total)
    }

    companion object {
        /** 16MB: also the dictionary's effective "global" reach - see class KDoc. */
        const val CHUNK_SIZE = 16 * 1024 * 1024
        val PARALLEL_BATCH = maxOf(1, minOf(Runtime.getRuntime().availableProcessors(), 4))

        /** Dedicated pool for chunk-level parallel compression - see class KDoc for why this
         *  is a plain executor rather than `Dispatchers.Default`. Daemon threads so it never
         *  blocks app process shutdown; shared across instances (companion object) rather than
         *  per-instance so repeated [NovaCompressAlgorithm] construction (e.g. in tests) can't
         *  leak thread pools. Sized to [PARALLEL_BATCH] since that's the most chunks ever
         *  in flight at once - no benefit to a larger pool. */
        private val executor = Executors.newFixedThreadPool(PARALLEL_BATCH) { r ->
            Thread(r, "novacompress-chunk-worker").apply { isDaemon = true }
        }
    }
}
