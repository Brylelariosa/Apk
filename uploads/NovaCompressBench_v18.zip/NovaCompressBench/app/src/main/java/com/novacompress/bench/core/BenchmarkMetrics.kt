package com.novacompress.bench.core

/**
 * One completed benchmark run of a single algorithm against a single file.
 * All fields are measured, not estimated - see [com.novacompress.bench.benchmark.BenchmarkRunner].
 */
data class BenchmarkMetrics(
    val algorithmId: String,
    val algorithmName: String,
    val category: AlgorithmCategory,
    val sourceFileName: String,
    val originalSizeBytes: Long,
    val compressedSizeBytes: Long,
    val compressionTimeMs: Long,
    val decompressionTimeMs: Long,
    val compressionCpuTimeMs: Long,
    val decompressionCpuTimeMs: Long,
    val peakMemoryDeltaBytes: Long,
    val verified: VerificationResult,
    val timestampEpochMs: Long,
    val failureReason: String? = null,
) {
    val compressionRatio: Double
        get() = if (compressedSizeBytes == 0L) 0.0 else originalSizeBytes.toDouble() / compressedSizeBytes

    val spaceSavingPercent: Double
        get() = if (originalSizeBytes == 0L) 0.0 else (1.0 - compressedSizeBytes.toDouble() / originalSizeBytes) * 100.0

    val compressionThroughputMBps: Double
        get() = megabytesPerSecond(originalSizeBytes, compressionTimeMs)

    val decompressionThroughputMBps: Double
        get() = megabytesPerSecond(originalSizeBytes, decompressionTimeMs)

    private fun megabytesPerSecond(bytes: Long, millis: Long): Double {
        if (millis <= 0L) return 0.0
        val mb = bytes / (1024.0 * 1024.0)
        return mb / (millis / 1000.0)
    }
}

enum class VerificationResult { PASS, FAIL, SKIPPED, UNAVAILABLE }
