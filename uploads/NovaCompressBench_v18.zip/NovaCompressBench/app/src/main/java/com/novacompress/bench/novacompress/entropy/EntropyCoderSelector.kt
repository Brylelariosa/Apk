package com.novacompress.bench.novacompress.entropy

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import kotlin.math.floor
import kotlin.math.ln

/**
 * Runs both entropy coders over the same symbol stream and keeps whichever
 * produced the smaller output - the literal "benchmark multiple entropy
 * coders... choose automatically" behavior requested for NovaCompress,
 * scoped to the two coders implemented here (see [HuffmanCoder] for why ANS
 * isn't one of them in this pass).
 *
 * The range-coder path optionally splits into two independent [FreqModel]s
 * selected by whether the *previous* symbol was below or at/above
 * [contextSplit] - cheap context modeling in the same spirit as LZMA's
 * literal/match state split (e.g. NovaSegmentCodec passes its SYM_MATCH
 * value so byte-value statistics right after a match get modeled
 * separately from statistics after a literal). It's opt-in: callers that
 * don't pass [contextSplit] - MatchFieldCoder's distance/length "slot"
 * streams, which use a differently-shaped alphabet where this split
 * wouldn't mean anything - get the original single-model behavior,
 * unchanged. Canonical Huffman doesn't get a context split: it would need
 * to transmit a separate header table per context, which is real added
 * complexity for a coder that's already just an automatic fallback here.
 */
object EntropyCoderSelector {
    private const val TYPE_RANGE = 0
    private const val TYPE_HUFFMAN = 1

    fun encode(symbols: IntArray, alphabet: Int, contextSplit: Int? = null): ByteArray {
        val rangeBytes = encodeRange(symbols, alphabet, contextSplit)

        val counts = IntArray(alphabet)
        for (s in symbols) counts[s]++

        // Building+running Huffman is a full O(N) pass just like the range
        // coder's own encode was - only worth paying for when Huffman could
        // still possibly win. See huffmanLowerBoundBytes's KDoc.
        val huffmanBytes = if (huffmanLowerBoundBytes(counts, symbols.size, alphabet) >= rangeBytes.size) {
            null
        } else {
            val huffmanTable = HuffmanCoder.build(counts)
            huffmanTable?.let { encodeHuffman(symbols, it) }
        }

        val useHuffman = huffmanBytes != null && huffmanBytes.size < rangeBytes.size
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            if (useHuffman) {
                d.writeByte(TYPE_HUFFMAN)
                d.write(huffmanBytes!!)
            } else {
                d.writeByte(TYPE_RANGE)
                d.write(rangeBytes)
            }
        }
        return out.toByteArray()
    }

    fun decode(bytes: ByteArray, symbolCount: Int, alphabet: Int, contextSplit: Int? = null): IntArray {
        val din = DataInputStream(ByteArrayInputStream(bytes))
        return when (val type = din.readUnsignedByte()) {
            TYPE_RANGE -> decodeRange(din, symbolCount, alphabet, contextSplit)
            TYPE_HUFFMAN -> decodeHuffman(din, symbolCount, alphabet)
            else -> throw IllegalStateException("Unknown entropy coder type tag: $type")
        }
    }

    private const val LN2 = 0.6931471805599453

    /**
     * A safe (never-too-optimistic) lower bound, in bytes, on what
     * [encodeHuffman] could possibly produce for this exact symbol
     * distribution: the table overhead ([alphabet] length bytes + the
     * 4-byte payload-length prefix [encodeHuffman] writes) plus the
     * Shannon entropy of [counts] itself. No prefix code - Huffman's
     * canonical codes included - can average fewer bits/symbol than the
     * source distribution's own entropy; Huffman is *optimal* among prefix
     * codes for a given frequency table, but "optimal" is still bounded
     * below by entropy, same as any other prefix code would be. [counts]
     * is the exact, unconditional whole-stream distribution
     * [HuffmanCoder.build] itself uses, so this isn't an approximation of
     * what Huffman would see - it's the same input.
     *
     * Comparing this bound against [rangeBytes]'s already-known exact size
     * lets [encode] skip actually building and running the Huffman coder -
     * a full O(N) pass over every symbol, on top of the range coder's own
     * O(N) pass - whenever the bound alone already proves Huffman can't
     * win. In practice that's the common case for anything past a
     * trivially short stream: [rangeBytes] comes from an *adaptive*,
     * optionally context-split model (see [encode]'s `contextSplit`
     * param), and both of those routinely beat the flat, unconditional
     * distribution this bound is computed from - especially once a stream
     * is long enough that the fixed table overhead charged here to Huffman
     * stops mattering, which is exactly the regime where skipping the
     * O(N) trial saves the most work.
     *
     * The `- 1.0` below is a one-bit safety margin against this being a
     * hair too aggressive from floating-point rounding in the entropy sum
     * - the only cost of being too conservative here is occasionally
     * running the O(N) trial when it wasn't strictly necessary, never a
     * wrong answer: whenever this function returns a value at or above
     * [rangeBytes].size, the real Huffman output (which is provably at
     * least this large) cannot be strictly smaller than [rangeBytes]
     * either, so skipping it changes nothing about which coder [encode]
     * ultimately picks.
     */
    private fun huffmanLowerBoundBytes(counts: IntArray, symbolCount: Int, alphabet: Int): Int {
        val tableOverheadBytes = alphabet + 4
        if (symbolCount == 0) return tableOverheadBytes
        var entropyBits = 0.0
        for (c in counts) {
            if (c <= 0) continue
            val p = c.toDouble() / symbolCount
            entropyBits -= c * (ln(p) / LN2)
        }
        val payloadBytes = floor((entropyBits - 1.0) / 8.0).toInt().coerceAtLeast(0)
        return tableOverheadBytes + payloadBytes
    }

    private fun encodeRange(symbols: IntArray, alphabet: Int, contextSplit: Int?): ByteArray {
        val enc = RangeEncoder()
        if (contextSplit == null) {
            val model = FreqModel(alphabet)
            for (s in symbols) enc.encode(model, s)
        } else {
            val modelLo = FreqModel(alphabet) // context: previous symbol < contextSplit
            val modelHi = FreqModel(alphabet) // context: previous symbol >= contextSplit
            var prevWasHi = false
            for (s in symbols) {
                enc.encode(if (prevWasHi) modelHi else modelLo, s)
                prevWasHi = s >= contextSplit
            }
        }
        val payload = enc.finish()
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            d.writeInt(payload.size)
            d.write(payload)
        }
        return out.toByteArray()
    }

    private fun decodeRange(din: DataInputStream, symbolCount: Int, alphabet: Int, contextSplit: Int?): IntArray {
        val len = din.readInt()
        val payload = ByteArray(len)
        din.readFully(payload)
        val dec = RangeDecoder(payload)
        if (contextSplit == null) {
            val model = FreqModel(alphabet)
            return IntArray(symbolCount) { dec.decodeSymbol(model) }
        }
        val modelLo = FreqModel(alphabet)
        val modelHi = FreqModel(alphabet)
        var prevWasHi = false
        return IntArray(symbolCount) {
            val sym = dec.decodeSymbol(if (prevWasHi) modelHi else modelLo)
            prevWasHi = sym >= contextSplit
            sym
        }
    }

    private fun encodeHuffman(symbols: IntArray, table: HuffmanCoder.Table): ByteArray {
        val bits = HuffmanCoder.encode(symbols, table)
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            for (len in table.codeLengths) d.writeByte(len)
            d.writeInt(bits.size)
            d.write(bits)
        }
        return out.toByteArray()
    }

    private fun decodeHuffman(din: DataInputStream, symbolCount: Int, alphabet: Int): IntArray {
        val lengths = IntArray(alphabet) { din.readUnsignedByte() }
        val len = din.readInt()
        val bits = ByteArray(len)
        din.readFully(bits)

        // Rebuild canonical codes from the transmitted lengths, via the same
        // derivation HuffmanCoder.build uses - one implementation, not two.
        val table = HuffmanCoder.canonicalize(lengths, alphabet)
        return HuffmanCoder.decode(bits, table, symbolCount)
    }
}
