package com.novacompress.bench.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.novacompress.bench.MainActivity
import com.novacompress.bench.R

/**
 * Exists for exactly one reason: a benchmark run over several sources and
 * algorithms can take minutes - slow algorithms (Bzip2, LZMA2) against real
 * multi-MB files have run past a minute *each* elsewhere in this project's
 * own testing - and with nothing telling Android this is ongoing,
 * user-initiated work, backgrounding the app during a run risked the whole
 * process being killed to reclaim memory, silently losing everything in
 * progress. See BENCHMARKS.md Entry 16.
 *
 * This is deliberately *not* where the benchmark logic lives. It does
 * nothing but call [android.app.Service.startForeground] (which elevates
 * the whole process to foreground priority - Android is far less likely to
 * kill it for memory reasons while any foreground service is running) and
 * show a simple ongoing notification, kept up to date via [updateProgress].
 * [com.novacompress.bench.ui.BenchmarkViewModel.runBenchmark] still owns and
 * runs the actual compression work in its own coroutine exactly as before -
 * this service's only job is to keep that coroutine's process alive long
 * enough to finish, not to own or relocate the work itself. Moving the
 * benchmark loop itself into a bound service (so it could keep running and
 * be reattached to even if the *Activity* were recreated, not just kept
 * alive at the process level) would be a more thorough fix, but a much
 * larger, riskier change to make in a sandbox with no way to compile or run
 * it - see "Suggested next subsystem" in Entry 16 for that tradeoff spelled
 * out explicitly.
 *
 * Started and stopped entirely from [com.novacompress.bench.ui.BenchmarkViewModel.runBenchmark] -
 * see [start]/[stop]/[updateProgress].
 */
class KeepAliveService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification(this, intent?.getStringExtra(EXTRA_PROGRESS_TEXT))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        // START_NOT_STICKY: if the process *does* still get killed despite this (OS pressure can
        // override foreground priority in extreme cases), don't have the OS silently restart an
        // empty service with no benchmark to run - runBenchmark's own coroutine is gone at that
        // point regardless, and an orphaned restarted service would just show a stuck notification
        // for work that isn't actually happening anymore.
        return START_NOT_STICKY
    }

    companion object {
        private const val CHANNEL_ID = "benchmark_running"
        private const val NOTIFICATION_ID = 1001
        private const val EXTRA_PROGRESS_TEXT = "progress_text"

        private fun createNotificationChannel(context: Context) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Benchmark running",
                NotificationManager.IMPORTANCE_LOW, // low: ongoing-work notification, not an alert - no sound/vibration
            ).apply {
                description = "Shown while a NovaCompress benchmark run is in progress"
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        private fun buildNotification(context: Context, progressText: String?): Notification {
            // NEW_TASK + CLEAR_TOP reinforce what MainActivity's android:launchMode="singleTask"
            // manifest declaration already establishes (see BENCHMARKS.md Entry 17): tapping this
            // notification must bring the existing running instance forward, never spawn a second
            // one with a fresh, disconnected BenchmarkViewModel that doesn't know a benchmark is
            // already in progress. NEW_TASK is also required outright here regardless, since this
            // Intent is built from a Service/companion-object context, not a running Activity.
            val openAppIntent = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_IMMUTABLE,
            )
            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle("NovaCompress benchmark running")
                .setContentText(progressText ?: "Starting...")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(openAppIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true) // don't re-alert on every progress update, see updateProgress
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
        }

        /** Starts the service, eligible per Android's "foreground service start" rules since this
         *  is always called from [com.novacompress.bench.ui.BenchmarkViewModel.runBenchmark],
         *  itself only ever reachable from a button tap while the app is visible - the run may
         *  finish long after the app is backgrounded, but it always *starts* while foregrounded. */
        fun start(context: Context) {
            val intent = Intent(context, KeepAliveService::class.java)
            context.startForegroundService(intent)
        }

        /** Updates the ongoing notification's text in place (same notification ID = replaces
         *  rather than duplicates) - callable from anywhere holding a [Context], no bound
         *  connection to a live [KeepAliveService] instance needed. If the `POST_NOTIFICATIONS`
         *  permission wasn't granted (possible in principle even though [MainActivity] requests it
         *  - the person may have denied it), this is a silent no-op rather than a crash: the
         *  process stays protected via [start]'s [Service.startForeground] call either way, which
         *  doesn't itself depend on the notification being visible - only its display does. */
        fun updateProgress(context: Context, text: String) {
            if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return
            val notification = buildNotification(context, text)
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }

        /** Stops the service - and explicitly cancels its notification, deliberately not relying
         *  on the usual "stopping a foreground service auto-removes its notification" behavior.
         *  [updateProgress] posts through [NotificationManagerCompat] directly (needed so it can be
         *  called without a live, bound connection to the running [KeepAliveService] instance - see
         *  that method's KDoc), which touches the same notification ID *outside* the service's own
         *  [Service.startForeground]-managed lifecycle - observed on-device to leave the
         *  notification stuck showing its last progress text after the service had already stopped,
         *  rather than disappearing. Explicit [NotificationManagerCompat.cancel] here removes that
         *  ambiguity instead of depending on exactly how a given OS version reconciles the two. */
        fun stop(context: Context) {
            context.stopService(Intent(context, KeepAliveService::class.java))
            NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
        }
    }
}
