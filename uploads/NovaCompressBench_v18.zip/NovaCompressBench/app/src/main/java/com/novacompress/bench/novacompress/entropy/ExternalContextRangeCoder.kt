package com.novacompress.bench.novacompress.entropy

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Range-codes a symbol stream using a caller-supplied per-symbol boolean
 * context, rather than [FreqModel]-selecting off the stream's own previous
 * element the way [EntropyCoderSelector]'s `contextSplit` does.
 *
 * Needed by [com.novacompress.bench.novacompress.NovaSegmentCodec]'s
 * split-stream scheme (see that class's KDoc "Split entropy scheme"): the
 * byte-value stream's natural context - "did the immediately preceding
 * *token* copy from a match or land a prediction hit" - lives in a
 * different, longer sequence (every token) than the value stream itself
 * (only the tokens whose type turned out to be a literal miss), so a
 * same-array lookback the way [EntropyCoderSelector.encode]'s `contextSplit`
 * works can't express it - by the time two consecutive *value-stream*
 * entries are being encoded, an arbitrary number of match/predict-hit
 * tokens carrying no value-stream entry of their own may have happened in
 * between them.
 *
 * No Huffman fallback here, deliberately - canonical Huffman has no
 * equivalent of "which of two tables applies to this specific symbol"
 * without transmitting both tables in full (real added complexity, and
 * this codec's own fixture testing never showed a need for it here - see
 * BENCHMARKS.md Entry 9). [context] must have exactly one entry per symbol
 * in [symbols]/being decoded, computed identically by both the encoder and
 * the decoder from state both sides already reconstruct in lockstep
 * (see the call site).
 */
object ExternalContextRangeCoder {
    fun encode(symbols: IntArray, context: BooleanArray, alphabet: Int): ByteArray {
        val enc = RangeEncoder()
        val modelLo = FreqModel(alphabet)
        val modelHi = FreqModel(alphabet)
        for (i in symbols.indices) {
            enc.encode(if (context[i]) modelHi else modelLo, symbols[i])
        }
        val payload = enc.finish()
        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            d.writeInt(payload.size)
            d.write(payload)
        }
        return out.toByteArray()
    }

    fun decode(bytes: ByteArray, context: BooleanArray, alphabet: Int): IntArray {
        val din = DataInputStream(ByteArrayInputStream(bytes))
        val len = din.readInt()
        val payload = ByteArray(len)
        din.readFully(payload)
        val dec = RangeDecoder(payload)
        val modelLo = FreqModel(alphabet)
        val modelHi = FreqModel(alphabet)
        return IntArray(context.size) { i -> dec.decodeSymbol(if (context[i]) modelHi else modelLo) }
    }
}
