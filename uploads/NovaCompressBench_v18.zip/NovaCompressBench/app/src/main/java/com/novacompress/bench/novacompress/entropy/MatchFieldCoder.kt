package com.novacompress.bench.novacompress.entropy

import com.novacompress.bench.novacompress.util.GrowableIntArray
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Encodes the non-negative integers that make up a match token's distance
 * and length - previously written as raw 7-bit varint bytes with no entropy
 * coding at all, which measured out to over 99% of NovaCompress's total
 * output on repetitive text (33798 matches on a 256KB file, ~2.4 raw
 * side-channel bytes each, while the entropy-coded symbol stream carrying
 * *which* token type each of those was cost under 250 bytes total - the
 * "which" was well compressed, the "how much"/"how far" never was).
 *
 * Each value is split into a slot (its bit-length, so ~13 distinct values
 * cover the full 32-bit range) and the extra bits needed to pick the exact
 * value within that slot's range - the same technique DEFLATE and LZMA use
 * for their length/distance codes. The slot is entropy-coded through
 * [EntropyCoderSelector] (adaptive, so a file that reuses a handful of
 * distances heavily - the common case, since [MultiLevelDictionary]'s
 * repeat-offset list already biases the matcher toward recent distances -
 * gets those slots for close to free); the extra bits are close to
 * uniformly distributed within a slot, so writing them raw costs no more
 * than an ideal coder would spend on them anyway, without paying for the
 * modeling overhead of trying to compress raw noise.
 *
 * That last assumption - "extra bits are close to uniform" - is only true
 * for genuinely varied distances. Measuring the encoder's own byte
 * breakdown (see BENCHMARKS.md) showed the *opposite* is common: on
 * periodic/structured data (fixed-width records, columnar/tabular binary,
 * anything with a repeating stride) the matcher keeps finding the *same*
 * distance value over and over, because the structure itself repeats.
 * [MultiLevelDictionary]'s repeat-offset list already lets the matcher
 * *find* those matches cheaply parse-wise, but every one of them still paid
 * full price here: the slot compressed away (adaptive model, one dominant
 * symbol), but that slot's raw extra bits were rewritten from scratch every
 * time even though the value never changed - on a 256KB synthetic
 * fixed-stride-record file, raw distance extra-bits alone were ~56% of the
 * *entire compressed output*, more than every other component combined.
 *
 * [DIST_REPEAT_SLOTS] fixes this with a small MRU cache of recently-used
 * *distance* values, tracked independently in [FieldWriter]/[unpack] (not
 * the same list [MultiLevelDictionary] uses for match-finding - this one
 * exists purely so the entropy coder can say "same as before" for free).
 * When a distance matches a cached value, it costs one cheap slot symbol
 * and zero extra bits, the same way LZMA's rep0-rep3 codes make reusing a
 * recent distance nearly free. Measured effect: 6.6x -> 13.6x ratio on the
 * fixed-stride-record case, smaller (~1%) gains on JSON/executable-like
 * data, no measurable change on prose text or image data (few enough
 * repeated distances there that the cache rarely fires) and no regression
 * anywhere tested - see BENCHMARKS.md for the full sweep. Lengths are
 * deliberately left on the original encoding ([DIST_REPEAT_SLOTS] isn't
 * applied there): a match length doesn't recur the way a periodic
 * structure's distance does, and MIN_MATCH-rebasing already gives the
 * single most common length (exactly MIN_MATCH) the cheapest slot.
 */
object MatchFieldCoder {
    // Bit-lengths 0..32 cover every non-negative Int, including 0 itself
    // (rebased match lengths can be exactly 0 when length == MIN_MATCH).
    private const val SLOT_ALPHABET = 33

    /** Repeat-offset MRU cache size for the *distance* field only - see
     *  class KDoc. Same size LZMA uses for its rep0-rep3 distances; not
     *  tied to [MultiLevelDictionary.repDistances]'s size, just a sensible
     *  default this codebase already uses that shape for elsewhere. */
    const val DIST_REPEAT_SLOTS = 4

    private fun slotOf(value: Int): Int = 32 - Integer.numberOfLeadingZeros(value)
    private fun extraBitsFor(slot: Int): Int = maxOf(0, slot - 1)

    /** Shifts `rep[idx]` to the front (same MRU promotion shape
     *  [com.novacompress.bench.novacompress.matcher.LongRangeMatcher] uses for its own,
     *  separate repeat-offset list). */
    private fun promote(rep: IntArray, idx: Int, value: Int) {
        for (m in idx downTo 1) rep[m] = rep[m - 1]
        rep[0] = value
    }

    /** Accumulates one field's worth of values (all distances, or all
     *  rebased lengths, for one NOVA block) as they're discovered during
     *  the single left-to-right token pass NovaSegmentCodec already makes.
     *  [repSlots] > 0 enables the repeat-offset MRU cache described in the
     *  class KDoc (NovaSegmentCodec passes [DIST_REPEAT_SLOTS] for the
     *  distance field); 0 (the default) reproduces the original
     *  slot-plus-extra-bits-only encoding exactly, unchanged - what the
     *  length field still uses. */
    class FieldWriter(private val repSlots: Int = 0) {
        private val slots = GrowableIntArray()
        private val extra = BitWriter()
        private val rep = IntArray(repSlots) { it + 1 }

        fun write(value: Int) {
            if (repSlots > 0) {
                val idx = rep.indexOf(value)
                if (idx >= 0) {
                    slots.add(idx) // reuse rep[idx]: one cheap symbol, zero extra bits
                    promote(rep, idx, value)
                    return
                }
            }
            val slot = slotOf(value)
            slots.add(repSlots + slot)
            val extraBits = extraBitsFor(slot)
            if (extraBits > 0) {
                extra.writeBits((value - (1 shl extraBits)).toLong(), extraBits)
            }
            if (repSlots > 0) promote(rep, repSlots - 1, value)
        }

        /** Alphabet size for this field's slot stream - callers pass this
         *  to [EntropyCoderSelector.encode] rather than a hardcoded
         *  constant, since it depends on [repSlots]. */
        fun alphabet(): Int = repSlots + SLOT_ALPHABET
        fun slotArray(): IntArray = slots.toIntArray()
        fun extraBytes(): ByteArray = extra.finish()
    }

    /** The decoded distance/length pairs for every match in a block, in the
     *  same left-to-right order they were written. */
    class Fields(val distances: IntArray, val lengths: IntArray)

    fun pack(distances: FieldWriter, lengths: FieldWriter): ByteArray {
        val distEntropy = EntropyCoderSelector.encode(distances.slotArray(), distances.alphabet())
        val distExtra = distances.extraBytes()
        val lenEntropy = EntropyCoderSelector.encode(lengths.slotArray(), lengths.alphabet())
        val lenExtra = lengths.extraBytes()

        val out = ByteArrayOutputStream()
        DataOutputStream(out).use { d ->
            d.writeInt(distEntropy.size); d.write(distEntropy)
            d.writeInt(distExtra.size); d.write(distExtra)
            d.writeInt(lenEntropy.size); d.write(lenEntropy)
            d.writeInt(lenExtra.size); d.write(lenExtra)
        }
        return out.toByteArray()
    }

    /** [minMatch] is added back to every decoded length, undoing the
     *  rebasing the writer side applies (see NovaSegmentCodec) so that slot
     *  0 - the cheapest possible code - lines up with the most common
     *  length (exactly MIN_MATCH) rather than being wasted on a length that
     *  can never occur.
     *
     *  [distRepSlots] MUST equal whatever `repSlots` the distance
     *  [FieldWriter] was constructed with, the same way [minMatch] must
     *  equal the value used to rebase lengths at write time - it defaults
     *  to [DIST_REPEAT_SLOTS] because that's what NovaSegmentCodec always
     *  passes for its distance writer, so the real call site needs no
     *  change, but a mismatched value here (like a mismatched [minMatch])
     *  would desync the decode silently rather than fail loudly, so tests
     *  that use a different `repSlots` must pass the same value here too. */
    fun unpack(bytes: ByteArray, matchCount: Int, minMatch: Int, distRepSlots: Int = DIST_REPEAT_SLOTS): Fields {
        val din = DataInputStream(ByteArrayInputStream(bytes))
        val distEntropy = ByteArray(din.readInt()).also { din.readFully(it) }
        val distExtra = ByteArray(din.readInt()).also { din.readFully(it) }
        val lenEntropy = ByteArray(din.readInt()).also { din.readFully(it) }
        val lenExtra = ByteArray(din.readInt()).also { din.readFully(it) }

        val distSlots = EntropyCoderSelector.decode(distEntropy, matchCount, distRepSlots + SLOT_ALPHABET)
        val lenSlots = EntropyCoderSelector.decode(lenEntropy, matchCount, SLOT_ALPHABET)
        val distReader = BitReader(distExtra)
        val lenReader = BitReader(lenExtra)

        // Explicit loops rather than IntArray(n) { ... } - both readers are
        // stateful (each read advances the bit cursor), so evaluation order
        // must be left-to-right, and this makes that requirement obvious at
        // the call site instead of resting on the array constructor's
        // (correct, but implicit) sequential-evaluation guarantee. The
        // distance loop also carries the repeat-offset MRU cache described
        // in the class KDoc, mirroring FieldWriter.write exactly so it
        // reconstructs the identical value FieldWriter saw.
        val distances = IntArray(matchCount)
        val distRep = IntArray(distRepSlots) { it + 1 }
        for (i in 0 until matchCount) {
            val sym = distSlots[i]
            val value: Int
            if (distRepSlots > 0 && sym < distRepSlots) {
                value = distRep[sym]
                promote(distRep, sym, value)
            } else {
                val slot = sym - distRepSlots
                value = readValue(slot, distReader)
                if (distRepSlots > 0) promote(distRep, distRepSlots - 1, value)
            }
            distances[i] = value
        }
        val lengths = IntArray(matchCount)
        for (i in 0 until matchCount) lengths[i] = readValue(lenSlots[i], lenReader) + minMatch

        return Fields(distances, lengths)
    }

    private fun readValue(slot: Int, reader: BitReader): Int {
        val extraBits = extraBitsFor(slot)
        if (extraBits == 0) return if (slot == 0) 0 else 1
        return (1 shl extraBits) + reader.readBits(extraBits).toInt()
    }
}
