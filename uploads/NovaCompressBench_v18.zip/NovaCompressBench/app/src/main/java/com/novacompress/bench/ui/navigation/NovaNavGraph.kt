package com.novacompress.bench.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.screens.history.HistoryScreen
import com.novacompress.bench.ui.screens.home.HomeScreen
import com.novacompress.bench.ui.screens.research.ResearchScreen
import com.novacompress.bench.ui.screens.results.ResultsScreen

object Routes {
    const val HOME = "home"
    const val RESULTS = "results"
    const val RESEARCH = "research"
    const val HISTORY = "history"
}

/**
 * Guards a `navigate()` call against firing while the current screen isn't actually [Lifecycle.State.RESUMED]
 * - a bare `navController.navigate(...)` called from a callback that can fire at an unpredictable
 * time (after a long background computation, in this app's case [BenchmarkViewModel.runBenchmark]'s
 * `onComplete`) can land while the app was backgrounded (screen timeout, switched away - an 11-
 * source, 8-algorithm run with slow algorithms on large files can easily run for minutes) and the
 * current back stack entry's lifecycle hasn't caught back up to RESUMED yet. Navigating in that
 * window is what produces `IllegalStateException: State must be at least CREATED to move to
 * DESTROYED, but was INITIALIZED` - a documented AndroidX Navigation Compose issue, not anything
 * specific to this app's own navigation graph. This guard is the standard mitigation: skip the
 * navigate() call entirely rather than let it fire into an inconsistent lifecycle state. A skipped
 * navigation from [BenchmarkViewModel.runBenchmark]'s `onComplete` isn't silently lost, either -
 * `results`/`researchReports` are already updated in [BenchmarkViewModel]'s state before this
 * callback runs (see that function), so the person lands back on Home with fresh results ready,
 * one tap on "Run Benchmark" or a manual navigation away from re-showing them.
 */
private fun NavHostController.navigateIfResumed(route: String) {
    if (currentBackStackEntry?.lifecycle?.currentState == Lifecycle.State.RESUMED) {
        navigate(route)
    }
}

@Composable
fun NovaNavGraph(
    viewModelFactory: androidx.lifecycle.ViewModelProvider.Factory,
    navController: NavHostController = rememberNavController(),
) {
    val viewModel: BenchmarkViewModel = viewModel(factory = viewModelFactory)

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                viewModel = viewModel,
                onRunComplete = { navController.navigateIfResumed(Routes.RESULTS) },
                onOpenHistory = { navController.navigateIfResumed(Routes.HISTORY) },
            )
        }
        composable(Routes.RESULTS) {
            ResultsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenResearch = { navController.navigateIfResumed(Routes.RESEARCH) },
            )
        }
        composable(Routes.RESEARCH) {
            ResearchScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
            )
        }
        composable(Routes.HISTORY) {
            HistoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
