package com.novacompress.bench.di

import android.content.Context
import com.novacompress.bench.algorithms.AlgorithmRegistry
import com.novacompress.bench.benchmark.BenchmarkRunner
import com.novacompress.bench.data.db.BenchmarkDatabase
import com.novacompress.bench.data.repository.BenchmarkRepository

/**
 * Lightweight manual dependency container (constructor injection, no
 * Hilt/Dagger). Chosen deliberately: Hilt's KSP-based codegen is another
 * exact-version-pairing surface (Kotlin <-> KSP <-> Hilt) on top of the one
 * Room already needs, and none of it could be resolved/verified in the
 * sandbox this project was built in. One dependency graph this small
 * doesn't need a framework - swapping in Hilt later is a mechanical change
 * given everything already takes its dependencies through constructors.
 */
class AppContainer(context: Context) {
    /** Kept for [com.novacompress.bench.ui.BenchmarkViewModel] to start/stop
     *  [com.novacompress.bench.service.KeepAliveService] around a benchmark
     *  run - see that service's KDoc for why one exists at all. Stored as
     *  the *application* context specifically (not the `context` param
     *  as-is, which could be an Activity context depending on the caller)
     *  to avoid holding a reference that could outlive an Activity. */
    val applicationContext: Context = context.applicationContext

    val algorithms = AlgorithmRegistry.all()
    val benchmarkRunner = BenchmarkRunner(context.cacheDir)
    val benchmarkRepository = BenchmarkRepository(
        BenchmarkDatabase.getInstance(context).benchmarkResultDao()
    )
}
