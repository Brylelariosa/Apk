package com.novacompress.bench.novacompress.util

/**
 * A manually-managed, growable `IntArray` - the same role `ArrayList<Int>`
 * played in [com.novacompress.bench.novacompress.NovaSegmentCodec.encode]
 * and [com.novacompress.bench.novacompress.entropy.MatchFieldCoder.FieldWriter]
 * before this, but without the boxing an `ArrayList<Int>` implies. Kotlin's
 * generic collections can't hold a primitive `Int` directly - every `add()`
 * on an `ArrayList<Int>` allocates a `java.lang.Integer`, and the JVM/ART
 * shared box cache only covers -128..127: half this codec's own byte-value
 * alphabet (128..255), plus both of its non-byte symbols (256/257), falls
 * outside that range and gets freshly allocated every time. For a symbol
 * stream with millions of entries - the common case for any real
 * multi-megabyte input - that's millions of short-lived heap objects and a
 * matching amount of GC pressure for values that are only ever written
 * once and read back out in bulk via [toIntArray]; nothing in between ever
 * needs them boxed.
 *
 * Deliberately minimal - `add` and `toIntArray` are the only operations
 * either call site ([NovaSegmentCodec.encode]'s `symbols` list or
 * [com.novacompress.bench.novacompress.entropy.MatchFieldCoder.FieldWriter]'s
 * `slots` list) actually uses.
 */
class GrowableIntArray(initialCapacity: Int = 16) {
    private var data = IntArray(initialCapacity.coerceAtLeast(1))

    var size = 0
        private set

    fun add(value: Int) {
        if (size == data.size) {
            data = data.copyOf(data.size * 2)
        }
        data[size++] = value
    }

    /** Right-sized copy of the values added so far, in insertion order. */
    fun toIntArray(): IntArray = data.copyOf(size)
}
