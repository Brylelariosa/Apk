package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.analyzer.FileAnalyzer
import com.novacompress.bench.novacompress.format.NovaContainerFormat
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.novacompress.segment.Segmenter
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import kotlin.random.Random

class NovaContainerFormatTest {
    private fun roundTripChunk(chunkData: ByteArray): ByteArray {
        val encoded = NovaContainerFormat.encodeChunk(chunkData)
        val din = DataInputStream(ByteArrayInputStream(encoded.bytes))
        val marker = din.readUnsignedByte()
        check(marker == NovaContainerFormat.MARKER_MORE)
        val out = ByteArrayOutputStream()
        NovaContainerFormat.decodeChunk(din, out)
        return out.toByteArray()
    }

    @Test fun mixedRealisticChunk() {
        val r = Random(2024)
        val out = ByteArrayOutputStream()
        while (out.size() < 50000) {
            if (r.nextBoolean()) {
                val words = listOf("alpha", "beta", "gamma", "research")
                repeat(1 + r.nextInt(30)) { out.write((words[r.nextInt(words.size)] + " ").toByteArray()) }
            } else {
                val b = ByteArray(200 + r.nextInt(1000))
                r.nextBytes(b)
                out.write(b)
            }
        }
        val data = out.toByteArray().copyOf(50000)
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun allHighEntropyChunk() {
        val data = ByteArray(20000)
        Random(1).nextBytes(data)
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun allTextChunk() {
        val data = "the quick brown fox ".repeat(2000).toByteArray()
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun tinyChunk() = assertArrayEquals(byteArrayOf(1, 2, 3), roundTripChunk(byteArrayOf(1, 2, 3)))

    @Test fun promotedStoreSegmentSandwichedBetweenNovaSegmentsRoundTrips() {
        // Regression test for a real corruption bug in the version-1
        // format: every NOVA-strategy segment in a chunk was concatenated
        // into one shared buffer, and a STORE segment that traded up to a
        // block after trial-compression (see encodeChunk) was appended to
        // the *end* of that buffer regardless of its actual position. That
        // was harmless as long as the promoted segment was already last in
        // the file, but silently corrupted everything from that segment
        // onward whenever it sat between two NOVA segments - exactly the
        // shape built here: repeated text, then a genuinely high-entropy
        // region the classifier flags ALREADY_COMPRESSED_OR_ENCRYPTED, then
        // more repeated text. (An earlier version of this fixture used a
        // periodic fixed-width-record table instead of true random bytes
        // for the middle region, since *that* also used to classify
        // ALREADY_COMPRESSED_OR_ENCRYPTED - see RegionClassifier's
        // periodicity-blind-spot note. It's genuinely repetitive now that
        // that's fixed, i.e. it no longer produces a STORE segment at all,
        // so it stopped testing what this test is for. True random bytes
        // classify ALREADY_COMPRESSED_OR_ENCRYPTED regardless.)
        val textA = "alpha beta gamma delta epsilon ".repeat(2000).toByteArray()
        val randomB = ByteArray(65536).also { Random(99).nextBytes(it) }
        val textC = "zeta eta theta iota kappa ".repeat(2000).toByteArray()
        val data = textA + randomB + textC

        // Confirm the test actually exercises the shape it's meant to -
        // if the classifier's thresholds ever shift enough that this data
        // no longer produces a STORE segment sandwiched between two NOVA
        // segments, this assertion fails loudly instead of the test
        // silently stopping to cover anything.
        val segments = Segmenter.segment(FileAnalyzer.analyze(data))
        val strategies = segments.map { it.strategy }
        assertTrue(
            "Test setup expects a STORE segment between two NOVA segments, got: $strategies",
            strategies.windowed(3).any { (a, b, c) -> a == SegmentStrategy.NOVA && b == SegmentStrategy.STORE && c == SegmentStrategy.NOVA },
        )

        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun heterogeneousChunkProducesMultipleSegmentsAndBlocks() {
        val text = "the quick brown fox jumps over the lazy dog ".repeat(3000).toByteArray()
        val table = ByteArray(80000) { i -> ((i % 24) * 7 + i / 24).toByte() }
        val data = text + table

        val encoded = NovaContainerFormat.encodeChunk(data)
        assertTrue(
            "Expected more than one segment for genuinely heterogeneous content, got ${encoded.stats.segments.size}",
            encoded.stats.segments.size > 1,
        )
        assertArrayEquals(data, roundTripChunk(data))
    }

    @Test fun uniformChunkStaysOneSegmentAndOneBlock() {
        // A same-family, same-entropy file shouldn't fragment just because
        // the new Segmenter is capable of splitting - this is the "only
        // when benchmarks show a benefit" half of the behavior.
        val data = "the quick brown fox jumps over the lazy dog ".repeat(6000).toByteArray()
        val encoded = NovaContainerFormat.encodeChunk(data)
        assertEquals(1, encoded.stats.segments.size)
        assertArrayEquals(data, roundTripChunk(data))
    }
}

class NovaCompressAlgorithmTest {
    private fun roundTrip(data: ByteArray): ByteArray {
        val algo = NovaCompressAlgorithm()
        val compressed = ByteArrayOutputStream()
        algo.compress(ByteArrayInputStream(data), compressed)
        val decompressed = ByteArrayOutputStream()
        algo.decompress(ByteArrayInputStream(compressed.toByteArray()), decompressed)
        return decompressed.toByteArray()
    }

    @Test fun emptyFile() = assertArrayEquals(ByteArray(0), roundTrip(ByteArray(0)))

    @Test fun smallFileOneChunk() {
        val data = "hello NovaCompress ".repeat(500).toByteArray()
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun multiChunkFile() {
        // Larger than NovaCompressAlgorithm.CHUNK_SIZE forces multiple chunks
        // and exercises the parallel-batch compression path.
        val r = Random(7)
        val out = ByteArrayOutputStream()
        val chunkTarget = NovaCompressAlgorithm.CHUNK_SIZE * 3 + 12345
        while (out.size() < chunkTarget) {
            if (r.nextInt(5) == 0) {
                val b = ByteArray(50000)
                r.nextBytes(b)
                out.write(b)
            } else {
                out.write("repeated structured record field value ".repeat(50).toByteArray())
            }
        }
        val data = out.toByteArray().copyOf(chunkTarget)
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun researchReportIsConsistentWithOutput() {
        val data = "{\"a\":1,\"b\":2}\n".repeat(3000).toByteArray()
        val algo = NovaCompressAlgorithm()
        val compressed = ByteArrayOutputStream()
        val report = algo.compressWithReport(ByteArrayInputStream(data), compressed)

        val decompressed = ByteArrayOutputStream()
        algo.decompress(ByteArrayInputStream(compressed.toByteArray()), decompressed)

        assertArrayEquals(data, decompressed.toByteArray())
        org.junit.Assert.assertEquals(data.size.toLong(), report.originalSize)
        org.junit.Assert.assertEquals(compressed.toByteArray().size.toLong(), report.compressedSize)
        org.junit.Assert.assertTrue("Highly repetitive JSON should find match tokens", report.totalMatchTokens > 0)
    }
}
