package com.menushell.billiards

/**
 * A pocket mouth on the table. [captures] is the one piece of behaviour a
 * pocket needs to be functional rather than decorative: given where an
 * object's center is and how big it is, has it gone in far enough to drop.
 * No ball exists yet to call it, but the check itself is real and ready
 * for one.
 */
data class Pocket(val center: Vec2, val radius: Float) {

    fun captures(objectCenter: Vec2, objectRadius: Float): Boolean =
        center.distanceTo(objectCenter) <= radius - objectRadius * CAPTURE_MARGIN

    companion object {
        /** An object must cross past its own half-radius into the mouth to drop, not just kiss the rim. */
        const val CAPTURE_MARGIN = 0.5f
    }
}
