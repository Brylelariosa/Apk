package com.menushell

import android.os.Bundle
import com.menushell.databinding.ActivityGameBinding

/**
 * The screen `Play` opens. For now this just hosts the billiards table
 * ([com.menushell.billiards.BilliardsTableView]) full screen — no ball or
 * cue yet, see CHANGELOG.
 */
class GameActivity : ImmersiveActivity() {

    private lateinit var binding: ActivityGameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}
