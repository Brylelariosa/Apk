package com.menushell.billiards

import kotlin.math.sqrt

/**
 * A minimal 2D vector, kept free of any Android framework dependency so the
 * geometry and collision math in this package (see [TableGeometry]) can be
 * reasoned about — and unit tested — entirely on its own.
 */
data class Vec2(val x: Float, val y: Float) {

    operator fun plus(other: Vec2) = Vec2(x + other.x, y + other.y)
    operator fun minus(other: Vec2) = Vec2(x - other.x, y - other.y)
    operator fun times(scalar: Float) = Vec2(x * scalar, y * scalar)

    infix fun dot(other: Vec2): Float = x * other.x + y * other.y

    fun length(): Float = sqrt(x * x + y * y)

    fun distanceTo(other: Vec2): Float = (this - other).length()

    /** A unit-length copy of this vector, or [ZERO] if this vector has no length. */
    fun normalized(): Vec2 {
        val len = length()
        return if (len > 0f) Vec2(x / len, y / len) else ZERO
    }

    companion object {
        val ZERO = Vec2(0f, 0f)
    }
}
