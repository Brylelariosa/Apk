package com.menushell.billiards

import kotlin.math.abs
import kotlin.math.min

/**
 * Rendering-only shapes derived from a [TableGeometry] — the cushion band
 * and pocket mouth outlines a real table shows, as opposed to the plain
 * segments and circles [Cushion] and [Pocket] use for collision.
 *
 * Kept framework-agnostic like the rest of this package, so these can be
 * reasoned about (and unit tested) without Android: [BilliardsTableView]
 * is the only thing that turns them into an actual `android.graphics.Path`.
 */

/**
 * Which of [Cushion.normal]'s two directions actually points inward.
 *
 * The sign [Cushion] itself picks is arbitrary — reflection works the same
 * either way, so it never had to be pinned down — but drawing the cushion
 * as a one-sided band needs an actual answer. [feltCenter] is always
 * unambiguously on the inward side of every cushion, so flipping the
 * normal when it points away from that center is all that's needed,
 * regardless of the felt rect's aspect ratio.
 */
fun inwardNormal(cushion: Cushion, feltCenter: Vec2): Vec2 {
    val normal = cushion.normal
    val mid = (cushion.start + cushion.end) * 0.5f
    return if ((normal dot (feltCenter - mid)) >= 0f) normal else normal * -1f
}

/**
 * The visible cushion strip for [cushion]: a band [depth] deep running
 * inward from the rail seam, tapering to an exact point at each end over
 * [taper] — the classic pocket "jaw". Sitting entirely on the felt side of
 * the seam (rather than straddling it) is what keeps the felt boundary
 * reading as a straight line instead of a wavy one.
 *
 * Returned as the 4 corners of a closed quadrilateral; the implicit 4th
 * edge — from [Cushion.end] back to [Cushion.start] — is the rail seam
 * itself, so the band never needs to describe it explicitly.
 */
fun cushionBand(cushion: Cushion, depth: Float, taper: Float, feltCenter: Vec2): List<Vec2> {
    val edge = cushion.end - cushion.start
    val length = edge.length()
    val along = if (length > 0f) edge * (1f / length) else Vec2(1f, 0f)
    val normal = inwardNormal(cushion, feltCenter)
    val t = min(taper, length / 2f)

    val innerStart = cushion.start + along * t + normal * depth
    val innerEnd = cushion.end - along * t + normal * depth

    return listOf(cushion.start, innerStart, innerEnd, cushion.end)
}

/**
 * The two points where a cushion ends exactly on [pocket]'s radius — the
 * jaw tips framing its mouth — found by proximity rather than by index, so
 * this keeps working for any pocket/cushion layout, not just the standard
 * 6-pocket one [TableGeometry] builds. Which one ends up "first" doesn't
 * matter to [pocketMouth] — the shape it builds is symmetric in the two.
 */
fun jawsForPocket(pocket: Pocket, cushions: List<Cushion>): List<Vec2> {
    val tolerance = (pocket.radius * JAW_TOLERANCE_FRACTION).coerceAtLeast(MIN_JAW_TOLERANCE_PX)
    return cushions.flatMap { listOf(it.start, it.end) }
        .filter { abs(it.distanceTo(pocket.center) - pocket.radius) < tolerance }
}

/**
 * A pocket mouth: two jaw points and the bezier control points that flare
 * the opening away from the table, ready for [BilliardsTableView] to turn
 * into a `moveTo`/`cubicTo` path — a real cut into the rail, rather than a
 * circle sitting on top of it.
 */
data class PocketMouth(val jawA: Vec2, val jawB: Vec2, val controlA: Vec2, val controlB: Vec2)

/**
 * Builds [pocket]'s mouth, or null if it doesn't have exactly two jaws (an
 * unusual custom layout) — callers should fall back to a plain circle in
 * that case rather than guess at a shape.
 */
fun pocketMouth(
    pocket: Pocket,
    cushions: List<Cushion>,
    feltCenter: Vec2,
    controlFraction: Float
): PocketMouth? {
    val jaws = jawsForPocket(pocket, cushions)
    if (jaws.size != 2) return null
    val (jawA, jawB) = jaws

    // Perpendicular to the jaw-to-jaw chord, pointing away from the felt.
    // Deriving this from the jaws (rather than "pocket center minus felt
    // rect center") is what makes it correct for both pocket kinds: a
    // corner's jaws are 90 degrees apart, a side pocket's are 180 degrees
    // apart — antipodal, where "the bisector of the two jaw directions" is
    // undefined — but a quarter-turn of their chord is well-defined either
    // way, and doesn't depend on the felt rect's aspect ratio the way
    // "away from the rect's center" would (that skewed the angle for
    // corner pockets on a non-square table).
    val chord = jawB - jawA
    var outward = Vec2(-chord.y, chord.x).normalized()
    if ((outward dot (pocket.center - feltCenter)) < 0f) outward *= -1f

    val pull = pocket.radius * controlFraction
    return PocketMouth(jawA, jawB, jawA + outward * pull, jawB + outward * pull)
}

private const val JAW_TOLERANCE_FRACTION = 0.02f
private const val MIN_JAW_TOLERANCE_PX = 0.5f
