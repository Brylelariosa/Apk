package com.menushell.billiards

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.menushell.R
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * One wavy grain streak on the wooden rail, ready to stroke: [path] is
 * built once in [BilliardsTableView.layoutTable] (it only depends on
 * layout, not on anything that changes per frame), while [color]/[alpha]/
 * [strokeWidth] are applied to a single shared [Paint] at draw time so
 * [BilliardsTableView.onDraw] doesn't allocate one Paint per stroke.
 */
private data class GrainStroke(val path: Path, val color: Int, val alpha: Int, val strokeWidth: Float)

/**
 * Draws a pool table — wooden rail, felt, cushions, rail diamonds, and
 * pockets — fit to whatever size this View is given.
 *
 * [tableGeometry] is the exact same model a future ball would collide
 * against; this View only turns it into pixels; it doesn't own any
 * gameplay state itself. No ball or cue yet.
 */
class BilliardsTableView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Recomputed whenever this View is resized; read by whatever eventually simulates a ball. */
    var tableGeometry: TableGeometry? = null
        private set

    private val railColor = ContextCompat.getColor(context, R.color.billiards_rail)
    private val feltPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = railColor }
    private val railHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.billiards_rail_light)
        style = Paint.Style.STROKE
    }

    /** Reused for every grain stroke; [onDraw] sets color/alpha/strokeWidth per [GrainStroke] before drawing it. */
    private val railGrainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val diamondPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.accent_amber)
    }
    private val feltLightColor = ContextCompat.getColor(context, R.color.billiards_felt)
    private val feltDarkColor = ContextCompat.getColor(context, R.color.billiards_felt_dark)
    private val pocketRimColor = ContextCompat.getColor(context, R.color.billiards_rail_light)
    private val pocketCoreColor = ContextCompat.getColor(context, R.color.black)
    private val cushionOuterColor = ContextCompat.getColor(context, R.color.billiards_cushion_light)
    private val cushionInnerColor = ContextCompat.getColor(context, R.color.billiards_cushion_dark)

    /** A brighter tone of [cushionOuterColor] for the gradient's middle stop — see [layoutTable]. */
    private val cushionHighlightColor = scaledValue(cushionOuterColor, CUSHION_HIGHLIGHT_FACTOR)

    private val railPath = Path()
    private val feltBounds = RectF()
    private var railGrainStrokes: List<GrainStroke> = emptyList()
    private var pocketPaints: List<Paint> = emptyList()
    private var pocketMouthPaths: List<Path> = emptyList()
    private var cushionPaths: List<Path> = emptyList()
    private var cushionPaints: List<Paint> = emptyList()
    private var diamondPoints: List<PointF> = emptyList()
    private var diamondRadius = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) layoutTable(w.toFloat(), h.toFloat())
    }

    /**
     * Fits a 2:1 table inside the View, centered, and derives every paint
     * that depends on that layout (gradients, stroke widths) once here —
     * not in [onDraw], which can run every frame once something animates.
     */
    private fun layoutTable(viewWidth: Float, viewHeight: Float) {
        val margin = min(viewWidth, viewHeight) * MARGIN_FRACTION
        val availableW = viewWidth - margin * 2f
        val availableH = viewHeight - margin * 2f

        var tableW = availableW
        var tableH = tableW / TABLE_ASPECT
        if (tableH > availableH) {
            tableH = availableH
            tableW = tableH * TABLE_ASPECT
        }

        val railLeft = (viewWidth - tableW) / 2f
        val railTop = (viewHeight - tableH) / 2f
        val railRect = RectF(railLeft, railTop, railLeft + tableW, railTop + tableH)

        val railThickness = tableH * RAIL_THICKNESS_FRACTION
        feltBounds.set(
            railRect.left + railThickness,
            railRect.top + railThickness,
            railRect.right - railThickness,
            railRect.bottom - railThickness
        )

        val feltHalfW = feltBounds.width() / 2f
        val feltHalfH = feltBounds.height() / 2f
        feltPaint.shader = RadialGradient(
            feltBounds.centerX(), feltBounds.centerY(),
            sqrt(feltHalfW * feltHalfW + feltHalfH * feltHalfH),
            feltLightColor, feltDarkColor, Shader.TileMode.CLAMP
        )

        val geometry = TableGeometry(
            left = feltBounds.left,
            top = feltBounds.top,
            right = feltBounds.right,
            bottom = feltBounds.bottom,
            cornerPocketRadius = feltBounds.height() * CORNER_POCKET_FRACTION,
            sidePocketRadius = feltBounds.height() * SIDE_POCKET_FRACTION
        )
        tableGeometry = geometry

        val railCorner = railThickness * 0.4f
        railPath.reset()
        railPath.addRoundRect(railRect, railCorner, railCorner, Path.Direction.CW)
        railHighlightPaint.strokeWidth = railThickness * 0.06f

        // Grain runs along each side's length — horizontal for the top/bottom
        // rail, vertical for the left/right rail — so it reads as wood milled
        // along the rail rather than across it. The 4 bands are plain
        // rectangles; onDraw clips them to railPath so the outer rounded
        // corners stay clean without needing rounded bands here.
        val topBand = RectF(railRect.left, railRect.top, railRect.right, feltBounds.top)
        val bottomBand = RectF(railRect.left, feltBounds.bottom, railRect.right, railRect.bottom)
        val leftBand = RectF(railRect.left, feltBounds.top, feltBounds.left, feltBounds.bottom)
        val rightBand = RectF(feltBounds.right, feltBounds.top, railRect.right, feltBounds.bottom)
        railGrainStrokes = buildWoodGrain(topBand, horizontal = true, seed = GRAIN_SEED_TOP) +
            buildWoodGrain(bottomBand, horizontal = true, seed = GRAIN_SEED_BOTTOM) +
            buildWoodGrain(leftBand, horizontal = false, seed = GRAIN_SEED_LEFT) +
            buildWoodGrain(rightBand, horizontal = false, seed = GRAIN_SEED_RIGHT)

        val feltCenter = Vec2(feltBounds.centerX(), feltBounds.centerY())

        // The cushion is a band running inward from the rail seam, tapering
        // to an exact point at each pocket (the classic "jaw"). It's given
        // its own gradient — bright at the seam, fading toward the felt's
        // own dark tone — rather than a flat fill, so it always reads as a
        // distinct raised strip no matter how light or dark the felt's own
        // gradient happens to be at that point along the rail.
        val cushionDepth = railThickness * CUSHION_DEPTH_FRACTION
        val cushionTaper = railThickness * CUSHION_TAPER_FRACTION
        cushionPaths = geometry.cushions.map { cushion ->
            pathFromPoints(cushionBand(cushion, cushionDepth, cushionTaper, feltCenter))
        }
        cushionPaints = geometry.cushions.map { cushion ->
            val normal = inwardNormal(cushion, feltCenter)
            val outer = cushion.start
            val inner = outer + normal * cushionDepth
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                // 3 stops instead of a flat fade: the cushion is a rounded
                // bumper, and a brighter middle stop is where its curve would
                // catch the light, so it reads as round instead of flat.
                shader = LinearGradient(
                    outer.x, outer.y, inner.x, inner.y,
                    intArrayOf(cushionOuterColor, cushionHighlightColor, cushionInnerColor),
                    floatArrayOf(0f, CUSHION_HIGHLIGHT_STOP, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        // Each pocket's gradient depends on its own position/radius, so
        // these are rebuilt here on resize rather than allocated in onDraw.
        // Mostly-black throat with a warm rim band is what reads as a real
        // opening — the earlier version used two near-black tones and the
        // gradient was invisible.
        pocketPaints = geometry.pockets.map { pocket ->
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(
                    pocket.center.x, pocket.center.y, pocket.radius,
                    intArrayOf(pocketCoreColor, pocketCoreColor, pocketRimColor),
                    floatArrayOf(0f, 0.72f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        // A real pocket is a mouth flaring away from the table between two
        // cushion jaws, not a circle laid on top of the felt — see
        // pocketMouth(). Tables built with an unusual layout (not exactly
        // two jaws per pocket) fall back to the plain circle instead of
        // guessing at a shape.
        pocketMouthPaths = geometry.pockets.map { pocket ->
            val mouth = pocketMouth(pocket, geometry.cushions, feltCenter, MOUTH_CONTROL_FRACTION)
            Path().apply {
                if (mouth != null) {
                    moveTo(mouth.jawA.x, mouth.jawA.y)
                    cubicTo(
                        mouth.controlA.x, mouth.controlA.y,
                        mouth.controlB.x, mouth.controlB.y,
                        mouth.jawB.x, mouth.jawB.y
                    )
                    close()
                } else {
                    addCircle(pocket.center.x, pocket.center.y, pocket.radius, Path.Direction.CW)
                }
            }
        }

        diamondRadius = railThickness * 0.09f
        diamondPoints = geometry.cushions.map { cushion -> diamondFor(cushion, railThickness) }
    }

    private fun pathFromPoints(points: List<Vec2>): Path = Path().apply {
        moveTo(points.first().x, points.first().y)
        points.drop(1).forEach { lineTo(it.x, it.y) }
        close()
    }

    /** A sight-mark position on the wood rail, just outside the cushion's midpoint. */
    private fun diamondFor(cushion: Cushion, railThickness: Float): PointF {
        val mid = (cushion.start + cushion.end) * 0.5f
        val outward = when {
            abs(mid.y - feltBounds.top) < 1f -> Vec2(0f, -1f)
            abs(mid.y - feltBounds.bottom) < 1f -> Vec2(0f, 1f)
            mid.x - feltBounds.left < feltBounds.width() / 2f -> Vec2(-1f, 0f)
            else -> Vec2(1f, 0f)
        }
        val diamond = mid + outward * (railThickness * 0.5f)
        return PointF(diamond.x, diamond.y)
    }

    /**
     * Wavy, semi-transparent grain streaks filling [band], as strokeable
     * [GrainStroke]s. [horizontal] is which way the grain runs: true for the
     * top/bottom rail (streaks run along x, stacked down y), false for the
     * left/right rail (streaks run along y, stacked across x). [seed] keeps
     * the pattern fixed across relayouts instead of reshuffling on every
     * resize/rotation.
     */
    private fun buildWoodGrain(band: RectF, horizontal: Boolean, seed: Int): List<GrainStroke> {
        val alongLen = if (horizontal) band.width() else band.height()
        val acrossLen = if (horizontal) band.height() else band.width()
        if (alongLen <= 0f || acrossLen <= 0f) return emptyList()

        val random = Random(seed)
        val sampleCount = (alongLen / GRAIN_SAMPLE_SPACING_PX).toInt().coerceIn(6, 40)

        return (0 until GRAIN_LINES_PER_BAND).map { i ->
            val jitter = (random.nextFloat() - 0.5f) * acrossLen * 0.02f
            val across = (i.toFloat() + 0.5f) / GRAIN_LINES_PER_BAND.toFloat() * acrossLen + jitter
            val valueFactor = GRAIN_MIN_VALUE_FACTOR +
                random.nextFloat() * (GRAIN_MAX_VALUE_FACTOR - GRAIN_MIN_VALUE_FACTOR)
            val alpha = (GRAIN_MIN_ALPHA + random.nextFloat() * (GRAIN_MAX_ALPHA - GRAIN_MIN_ALPHA)).toInt()
            val waveAmp = acrossLen *
                (GRAIN_MIN_WAVE_FRACTION + random.nextFloat() * (GRAIN_MAX_WAVE_FRACTION - GRAIN_MIN_WAVE_FRACTION))
            val waveFreq = (1.2f + random.nextFloat() * 1.8f) * (2f * PI.toFloat() / alongLen)
            val phase = random.nextFloat() * 2f * PI.toFloat()
            val strokeWidth = (0.6f + random.nextFloat() * 1.6f) * (acrossLen / 90f)

            val path = Path()
            for (s in 0..sampleCount) {
                val along = alongLen * (s.toFloat() / sampleCount.toFloat())
                val offset = sin(along * waveFreq + phase) * waveAmp
                val x = if (horizontal) band.left + along else band.left + across + offset
                val y = if (horizontal) band.top + across + offset else band.top + along
                if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            GrainStroke(path, scaledValue(railColor, valueFactor), alpha, strokeWidth)
        }
    }

    /** [color] with its HSV "value" (brightness) scaled by [factor]; hue and saturation are unchanged. */
    private fun scaledValue(color: Int, factor: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[2] = (hsv[2] * factor).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        tableGeometry ?: return

        canvas.drawPath(railPath, railPaint)
        canvas.save()
        canvas.clipPath(railPath)
        railGrainStrokes.forEach { stroke ->
            railGrainPaint.color = stroke.color
            railGrainPaint.alpha = stroke.alpha
            railGrainPaint.strokeWidth = stroke.strokeWidth
            canvas.drawPath(stroke.path, railGrainPaint)
        }
        canvas.restore()
        canvas.drawPath(railPath, railHighlightPaint)
        canvas.drawRoundRect(
            feltBounds, feltBounds.height() * 0.02f, feltBounds.height() * 0.02f, feltPaint
        )

        diamondPoints.forEach { p -> canvas.drawCircle(p.x, p.y, diamondRadius, diamondPaint) }

        cushionPaths.forEachIndexed { index, path -> canvas.drawPath(path, cushionPaints[index]) }

        pocketMouthPaths.forEachIndexed { index, path -> canvas.drawPath(path, pocketPaints[index]) }
    }

    companion object {
        private const val TABLE_ASPECT = 2f // standard pool table length:width
        private const val MARGIN_FRACTION = 0.05f
        private const val RAIL_THICKNESS_FRACTION = 0.09f

        // Target pocket MOUTH width — what's actually visible on screen, as a
        // fraction of feltBounds.height() — not the capture-circle radius
        // TableGeometry ends up using. A corner's two jaws sit 90 degrees
        // apart on its capture circle, so the chord between them (the visible
        // opening) is only radius * sqrt(2), not the full diameter; a side
        // pocket's jaws are antipodal, 180 degrees apart, so its chord IS the
        // full diameter. Routing both targets through
        // radiusFractionForMouthWidth() is what keeps that difference from
        // silently detuning the on-screen proportions the way it once did,
        // back when both pocket kinds used a radius fraction sized for a
        // plain circle — the corner mouth came out narrower than the side
        // one even though its capture circle was bigger.
        private const val CORNER_MOUTH_WIDTH_FRACTION = 0.116f // regulation ~5" mouth on a 44" bed
        private const val SIDE_MOUTH_WIDTH_FRACTION = 0.10f // regulation ~4.5" mouth on a 44" bed
        private val CORNER_POCKET_FRACTION =
            radiusFractionForMouthWidth(CORNER_MOUTH_WIDTH_FRACTION, jawSpreadDegrees = 90f)
        private val SIDE_POCKET_FRACTION =
            radiusFractionForMouthWidth(SIDE_MOUTH_WIDTH_FRACTION, jawSpreadDegrees = 180f)

        private const val CUSHION_DEPTH_FRACTION = 0.40f
        private const val CUSHION_TAPER_FRACTION = 0.30f
        private const val MOUTH_CONTROL_FRACTION = 1.05f
        private const val CUSHION_HIGHLIGHT_FACTOR = 1.35f // HSV-value boost for the cushion's lit ridge
        private const val CUSHION_HIGHLIGHT_STOP = 0.30f // how far in the highlight sits; seam=0, inner edge=1

        private const val GRAIN_LINES_PER_BAND = 24
        private const val GRAIN_SAMPLE_SPACING_PX = 6f
        private const val GRAIN_MIN_VALUE_FACTOR = 0.62f
        private const val GRAIN_MAX_VALUE_FACTOR = 1.42f
        private const val GRAIN_MIN_ALPHA = 25.5f // 0.10 * 255
        private const val GRAIN_MAX_ALPHA = 76.5f // 0.30 * 255
        private const val GRAIN_MIN_WAVE_FRACTION = 0.015f
        private const val GRAIN_MAX_WAVE_FRACTION = 0.05f
        private const val GRAIN_SEED_TOP = 1
        private const val GRAIN_SEED_BOTTOM = 2
        private const val GRAIN_SEED_LEFT = 3
        private const val GRAIN_SEED_RIGHT = 4

        /**
         * The capture-circle radius fraction whose two jaws — [jawSpreadDegrees]
         * apart around that circle — produce a chord equal to [mouthWidthFraction].
         * See the comment above [CORNER_MOUTH_WIDTH_FRACTION] for why pocket
         * radius and pocket mouth width need this conversion between them.
         */
        private fun radiusFractionForMouthWidth(mouthWidthFraction: Float, jawSpreadDegrees: Float): Float =
            mouthWidthFraction / (2f * sin(jawSpreadDegrees * PI.toFloat() / 360f))
    }
}
