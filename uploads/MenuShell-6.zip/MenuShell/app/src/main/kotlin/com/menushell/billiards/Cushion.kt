package com.menushell.billiards

/**
 * A straight rail segment a ball bounces off of. Reflection uses the
 * standard v' = v - 2(v·n)n formula, which comes out the same regardless
 * of which of the two opposite directions [normal] happens to point in
 * (flipping its sign leaves the result unchanged), so there's no need to
 * carefully orient it "inward" here.
 */
data class Cushion(val start: Vec2, val end: Vec2) {

    private val edge = end - start
    private val edgeLengthSquared = edge dot edge

    val normal: Vec2 = Vec2(-edge.y, edge.x).normalized()

    /** Closest point on this segment (not the infinite line through it) to [point]. */
    fun closestPoint(point: Vec2): Vec2 {
        if (edgeLengthSquared == 0f) return start
        val t = (((point - start) dot edge) / edgeLengthSquared).coerceIn(0f, 1f)
        return start + edge * t
    }

    fun distanceTo(point: Vec2): Float = closestPoint(point).distanceTo(point)

    fun collidesWith(center: Vec2, radius: Float): Boolean = distanceTo(center) <= radius

    /** Elastic-ish bounce: reflects [velocity] across this cushion's normal, damped by [restitution]. */
    fun reflect(velocity: Vec2, restitution: Float = DEFAULT_RESTITUTION): Vec2 {
        val bounced = velocity - normal * (2f * (velocity dot normal))
        return bounced * restitution
    }

    companion object {
        /** Real cushions lose a little energy per bounce; ~0.92 reads as lively without feeling frictionless. */
        const val DEFAULT_RESTITUTION = 0.92f
    }
}
