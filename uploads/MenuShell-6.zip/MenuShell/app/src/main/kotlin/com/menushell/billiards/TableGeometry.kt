package com.menushell.billiards

/**
 * The physical layout of a pool table's playing surface: where its 6
 * pockets are and where its 6 cushions run, derived from the rectangle they
 * sit inside. Framework-agnostic — [BilliardsTableView] turns this into
 * pixels, but nothing in this file draws or knows about Android, so it's
 * reusable by anything that needs the collision surface (a future ball's
 * physics step included).
 *
 * @param left left edge of the felt, i.e. the inner edge the cushions sit
 *   on — not the outer wooden rail.
 * @param top top edge of the felt.
 * @param right right edge of the felt.
 * @param bottom bottom edge of the felt.
 * @param cornerPocketRadius radius of the 4 corner pockets.
 * @param sidePocketRadius radius of the 2 side (long-rail midpoint) pockets
 *   — smaller than the corner pockets, matching a regulation table.
 */
class TableGeometry(
    left: Float,
    top: Float,
    right: Float,
    bottom: Float,
    cornerPocketRadius: Float,
    sidePocketRadius: Float
) {
    val pockets: List<Pocket>
    val cushions: List<Cushion>

    init {
        val midX = (left + right) / 2f
        val cr = cornerPocketRadius
        val sr = sidePocketRadius

        pockets = listOf(
            Pocket(Vec2(left, top), cr),
            Pocket(Vec2(midX, top), sr),
            Pocket(Vec2(right, top), cr),
            Pocket(Vec2(left, bottom), cr),
            Pocket(Vec2(midX, bottom), sr),
            Pocket(Vec2(right, bottom), cr)
        )

        // Each rail stops short of the pocket centers above — that gap is
        // what makes a pocket an opening in the rail rather than a marking
        // on an unbroken cushion.
        cushions = listOf(
            Cushion(Vec2(left + cr, top), Vec2(midX - sr, top)),
            Cushion(Vec2(midX + sr, top), Vec2(right - cr, top)),
            Cushion(Vec2(left + cr, bottom), Vec2(midX - sr, bottom)),
            Cushion(Vec2(midX + sr, bottom), Vec2(right - cr, bottom)),
            Cushion(Vec2(left, top + cr), Vec2(left, bottom - cr)),
            Cushion(Vec2(right, top + cr), Vec2(right, bottom - cr))
        )
    }

    /** The pocket that has captured a ball centered at [center], if any. */
    fun pocketCapturing(center: Vec2, objectRadius: Float): Pocket? =
        pockets.firstOrNull { it.captures(center, objectRadius) }

    /** The cushion currently in contact with a ball centered at [center], if any. */
    fun cushionColliding(center: Vec2, radius: Float): Cushion? =
        cushions.firstOrNull { it.collidesWith(center, radius) }
}
