# Add project-specific ProGuard rules here.
#
# No manual keep rules needed for release R8 (full mode, on by default
# under AGP 8.4.2): ViewBinding resolves views via generated
# findViewById calls, not reflection, and AGP auto-generates keep
# rules for the MaterialButton / ConstraintLayout / Guideline classes
# referenced directly from layout XML. Revisit this file if a
# reflection-based library (Gson, Retrofit, etc.) is added later.
