# ── Readable crash logs ────────────────────────────────────────────────────────
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keepattributes *Annotation*

# ── Activities, Services, BroadcastReceivers, ContentProviders ────────────────
-keep public class com.mangatool.app.MainActivity
-keep public class com.mangatool.app.ImagePreviewActivity
-keep public class com.mangatool.app.AllPhotosActivity
-keep public class com.mangatool.app.MergeImagePickerActivity

# ── Data model classes ────────────────────────────────────────────────────────
-keepclassmembers class com.mangatool.app.model.ImageItem {
    public synthetic ** component*();
    public ** copy(...);
}
-keepclassmembers class com.mangatool.app.model.ImageGroup {
    public synthetic ** component*();
    public ** copy(...);
}

# ── Enum safety ───────────────────────────────────────────────────────────────
-keepclassmembers enum com.mangatool.app.AppMode { *; }

# ── Kotlin & coroutines ───────────────────────────────────────────────────────
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**

# ── ViewBinding ───────────────────────────────────────────────────────────────
# AGP generates keep rules for ViewBinding automatically.

# ── Material / AndroidX ───────────────────────────────────────────────────────
-dontwarn com.google.android.material.**
-dontwarn androidx.**

# ── Glide ─────────────────────────────────────────────────────────────────────
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { <init>(...); }
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** {
    **[] $VALUES;
    public *;
}
-keep class com.bumptech.glide.load.data.ParcelFileDescriptorRewinder$InternalRewinder {
    *** rewind();
}
-dontwarn com.bumptech.glide.**
