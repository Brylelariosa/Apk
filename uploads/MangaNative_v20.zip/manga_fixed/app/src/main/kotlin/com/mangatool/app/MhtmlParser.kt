package com.mangatool.app

import android.util.Base64
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MhtmlParser {

    /**
     * Stream-parse an MHTML file into an ImageGroup without loading the whole
     * file into RAM.
     *
     * ── Memory model ──────────────────────────────────────────────────────────
     * v16: used StringBuilder bodyBuf, accumulating every part body as text.
     *   For a 200 KB image base64-encoded to ~270 KB of ASCII, the old path
     *   allocated: StringBuilder (~270 KB) → toString() String (~270 KB) →
     *   toByteArray(ISO_8859_1) (~270 KB) → Base64.decode() result (~200 KB).
     *   Peak per image ≈ 810 KB. Non-image parts (HTML, CSS) were also fully
     *   accumulated even though they were always discarded.
     *
     * v19 improvements:
     *   1. Headers are parsed FIRST. Non-image parts skip body accumulation
     *      entirely — only the boundary-scan loop runs, zero allocation.
     *   2. Image bodies accumulate into a ByteArrayOutputStream pre-sized to
     *      128 KB. No intermediate String. Single toByteArray() call feeds
     *      Base64.decode() directly.
     *      Peak per image ≈ ~270 KB (stream buffer) + ~200 KB (decoded) = ~470 KB.
     *      Saves ~340 KB of intermediate allocation per image.
     *   3. onProgress is throttled to fire every 5 images — eliminates rapid
     *      main-thread post() spam on chapters with many pages.
     *
     * Page order is preserved identically to v16: [partIdx] increments for every
     * MIME part in document order.
     */
    suspend fun parse(
        stream: InputStream,
        filename: String,
        tempDir: File,
        onProgress: ((done: Int) -> Unit)? = null
    ): ImageGroup? = withContext(Dispatchers.IO) {
        try {
            // ISO-8859-1 preserves all byte values (safe for binary/QP parts);
            // the boundary value is ASCII so charset choice doesn't matter there.
            val reader = stream.bufferedReader(Charsets.ISO_8859_1)

            // ── 1. Detect MIME boundary ──────────────────────────────────────
            var boundary: String? = null
            var line: String? = reader.readLine()
            while (line != null && boundary == null) {
                boundary = Regex("""boundary="?([^";\s\r\n]+)"?""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.get(1)
                if (boundary == null) line = reader.readLine()
            }
            if (boundary == null) return@withContext null

            val boundaryMarker = "--$boundary"
            val closingMarker  = "--$boundary--"

            // ── 2. Skip to the first boundary line ──────────────────────────
            while (line != null && !line.startsWith(boundaryMarker)) {
                line = reader.readLine()
            }

            data class Extracted(val sortKey: String, val filePath: String, val size: Int, val ext: String)
            val extracted = mutableListOf<Extracted>()
            var partIdx = 0

            tempDir.mkdirs()

            // Reusable body buffer — pre-sized for a typical image part (~128 KB base64).
            // reset() before each image part so the same buffer object is reused
            // across parts, reducing ByteArrayOutputStream allocation churn.
            val bodyStream = ByteArrayOutputStream(128 * 1024)

            // ── 3. State machine: boundary → headers → body → boundary ──────
            while (line != null && !line.startsWith(closingMarker)) {

                // READ HEADERS — until the blank-line separator
                val headers = StringBuilder()
                line = reader.readLine()
                while (line != null && line.isNotBlank()) {
                    headers.append(line).append('\n')
                    line = reader.readLine()
                }

                val headStr   = headers.toString()
                val typeMatch = CONTENT_TYPE_RE.find(headStr)
                val encoding  = ENCODING_RE.find(headStr)?.groupValues?.get(1)?.lowercase()

                if (typeMatch != null) {
                    // ── Image part: accumulate body into reusable ByteArrayOutputStream ──
                    // Avoids StringBuilder → String → ByteArray triple-allocation of v16.
                    // Each base64 line is pure ASCII; ISO_8859_1 maps char→byte directly.
                    bodyStream.reset()
                    line = reader.readLine()
                    while (line != null && !line.startsWith(boundaryMarker)) {
                        bodyStream.write(line.toByteArray(Charsets.ISO_8859_1))
                        line = reader.readLine()
                    }

                    val rawExt = typeMatch.groupValues[1].lowercase()
                    val ext    = if (rawExt == "jpeg") "jpg" else rawExt

                    val bytes: ByteArray? = when (encoding) {
                        "base64" -> try {
                            // Base64.DEFAULT ignores whitespace — no explicit newline stripping needed.
                            Base64.decode(bodyStream.toByteArray(), Base64.DEFAULT)
                        } catch (_: Exception) { null }

                        "quoted-printable" ->
                            // QP is text-safe to convert via String
                            decodeQP(bodyStream.toString("ISO-8859-1"))
                                .toByteArray(Charsets.ISO_8859_1)

                        else -> bodyStream.toByteArray()
                    }

                    if (bytes != null && bytes.size > 100) {
                        val sortKey = partIdx.toString().padStart(8, '0')
                        val file    = File(tempDir, "$sortKey.$ext")
                        BufferedOutputStream(FileOutputStream(file)).use { it.write(bytes) }
                        extracted += Extracted(sortKey, file.absolutePath, bytes.size, ext)

                        // Throttle progress callbacks: fire every 5 images to avoid
                        // spamming the main thread with a post() per page on large chapters.
                        if (extracted.size % 5 == 0) {
                            onProgress?.invoke(extracted.size)
                        }
                        // bytes and bodyStream contents eligible for GC now
                    }

                } else {
                    // ── Non-image part (HTML, CSS, favicon, etc.) ─────────────────────
                    // Skip body lines without accumulating — zero allocation.
                    // v16 accumulated every part body even though non-image parts were
                    // always discarded; this was the largest source of wasted allocation
                    // for typical MHTML files (which start with a large HTML wrapper).
                    line = reader.readLine()
                    while (line != null && !line.startsWith(boundaryMarker)) {
                        line = reader.readLine()
                    }
                }

                partIdx++
            }

            // Fire a final progress update for any trailing images not covered by % 5
            if (extracted.isNotEmpty()) onProgress?.invoke(extracted.size)

            if (extracted.isEmpty()) return@withContext null

            extracted.sortBy { it.sortKey }
            val images = extracted.mapIndexed { i, r ->
                ImageItem(originalIdx = i, filePath = r.filePath, ext = r.ext, size = r.size)
            }
            ImageGroup(groupName = smartRename(filename)).also { g -> g.allImages.addAll(images) }

        } catch (_: Exception) { null }
    }

    // ── Pattern constants — compiled once at class load, not per call ─────────
    private val CONTENT_TYPE_RE = Regex(
        """Content-Type:\s*image/(jpeg|jpg|png|gif|webp)""", RegexOption.IGNORE_CASE)
    private val ENCODING_RE = Regex(
        """Content-Transfer-Encoding:\s*(base64|quoted-printable)""", RegexOption.IGNORE_CASE)

    private fun decodeQP(s: String): String =
        s.replace(Regex("=[\\r\\n]+"), "")
         .replace(Regex("=[0-9A-Fa-f]{2}")) { it.value.substring(1).toInt(16).toChar().toString() }

    // ── Filename prettifier ───────────────────────────────────────────────────
    private fun smartRename(filename: String): String {
        var n = filename.replace(Regex("\\.mhtml?$", RegexOption.IGNORE_CASE), "")
        n = n.replace(Regex("[_+]"), " ")
        n = n.replace(Regex("\\b(read manga online|read online|manga)\\b", RegexOption.IGNORE_CASE), "")
        n = n.trim()

        val m = Regex("""^(.*?)(\b(?:chapter|ch\.?|no\.?|c\.?|vol\.?|volume|#)\s*[\d.]+|\b\d+)(.*)$""",
            RegexOption.IGNORE_CASE).find(n)

        if (m != null) {
            val prefix = m.groupValues[1].trim()
            var num    = m.groupValues[2].trim()
            val suffix = m.groupValues[3].trim()
            num = num.replace(Regex("(\\d+)")) { it.value.padStart(3, '0') }
            val cp = prefix.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trimEnd('-', '_').trim()
            n = if (cp.isNotEmpty()) "$num - $cp $suffix".trim() else "$num $suffix".trim()
        } else {
            n = n.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trim()
        }

        return n.replace(Regex("\\s+-\\s*$"), "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { filename.substringBefore('.') }
    }
}
