package com.mangatool.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.adapter.FileEntry
import com.mangatool.app.adapter.FileManagerAdapter
import java.io.File

/**
 * Built-in file manager for browsing and selecting manga files (MHTML, images).
 *
 * Does NOT use SAF or an external app — navigates the real file system directly,
 * so the user can reach any folder on their device without leaving MIE.
 *
 * On Android 11+ (API 30+) MANAGE_EXTERNAL_STORAGE is required so that
 * File.listFiles() returns MHTML files and openInputStream() can read them.
 * READ_MEDIA_IMAGES alone only covers image types; arbitrary files like .mhtml
 * are invisible / unreadable without the all-files permission.
 *
 * Returns selected file URIs via FileProvider so processFiles() can open them
 * with contentResolver.openInputStream() like any other picked file.
 */
class InternalFileManagerActivity : AppCompatActivity() {

    private enum class SortBy { NAME, DATE, TYPE }

    companion object {
        const val RESULT_URIS = "result_uris"

        /** Common starting roots, tried in order — first readable one is used. */
        private val CANDIDATE_ROOTS = listOf(
            Environment.getExternalStorageDirectory(),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            File("/storage/emulated/0"),
            File("/sdcard")
        )
    }

    private lateinit var adapter: FileManagerAdapter
    private lateinit var tvPath: TextView
    private lateinit var tvSelected: TextView
    private lateinit var btnOpen: Button
    private lateinit var tvEmpty: TextView

    /** Stack of visited dirs — enables Back-to-navigate. */
    private val navStack = ArrayDeque<File>()

    /** Current sort field and direction — persisted across folder navigation. */
    private var sortBy = SortBy.NAME
    private var sortAscending = true

    private lateinit var btnSortName: Button
    private lateinit var btnSortDate: Button
    private lateinit var btnSortType: Button
    private lateinit var rv: RecyclerView

    /**
     * Launched when the user returns from the "All files access" settings screen.
     * Re-attempts navigation if the permission was granted; shows a warning if not.
     */
    private val manageStorageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            startNavigation()
        } else {
            Toast.makeText(
                this,
                "All files access not granted — MHTML files may not appear",
                Toast.LENGTH_LONG
            ).show()
            startNavigation() // still try; images may still work
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_manager)

        tvPath     = findViewById(R.id.tvCurrentPath)
        tvSelected = findViewById(R.id.tvSelectedCount)
        btnOpen    = findViewById(R.id.btnOpenSelected)
        tvEmpty    = findViewById(R.id.tvEmpty)

        val btnBack      = findViewById<ImageButton>(R.id.btnFmBack)
        val btnSelectAll = findViewById<Button>(R.id.btnSelectAll)
        rv               = findViewById(R.id.rvFiles)

        adapter = FileManagerAdapter(
            onFolderClick    = { dir -> navigateTo(dir) },
            onSelectionChanged = { sel ->
                val n = sel.size
                tvSelected.text = if (n == 0) "Tap files to select"
                                  else "$n file${if (n == 1) "" else "s"} selected"
                btnOpen.isEnabled = n > 0
            }
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter        = adapter
        rv.setItemViewCacheSize(20)
        rv.overScrollMode = View.OVER_SCROLL_NEVER

        btnBack.setOnClickListener      { handleBack() }
        btnSelectAll.setOnClickListener { adapter.selectAll() }

        // ── Sort buttons ──────────────────────────────────────────────────────
        btnSortName = findViewById(R.id.btnSortName)
        btnSortDate = findViewById(R.id.btnSortDate)
        btnSortType = findViewById(R.id.btnSortType)

        fun onSortClick(field: SortBy) {
            if (sortBy == field) sortAscending = !sortAscending
            else { sortBy = field; sortAscending = true }
            updateSortButtons()
            refreshSort()
        }
        btnSortName.setOnClickListener { onSortClick(SortBy.NAME) }
        btnSortDate.setOnClickListener { onSortClick(SortBy.DATE) }
        btnSortType.setOnClickListener { onSortClick(SortBy.TYPE) }
        updateSortButtons()

        btnOpen.setOnClickListener {
            val selected = adapter.getSelected()
            if (selected.isEmpty()) return@setOnClickListener
            val authority = "${packageName}.fileprovider"
            val uriStrings = selected.mapNotNull { file ->
                runCatching { FileProvider.getUriForFile(this, authority, file).toString() }.getOrNull()
            }
            if (uriStrings.isEmpty()) {
                Toast.makeText(this, "Could not access selected files", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            setResult(Activity.RESULT_OK, Intent().apply {
                putStringArrayListExtra(RESULT_URIS, ArrayList(uriStrings))
            })
            finish()
        }

        // On Android 11+, all-files access is required to list and open MHTML files
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            showAllFilesPermissionDialog()
        } else {
            startNavigation()
        }
    }

    @Deprecated("Use handleBack()")
    override fun onBackPressed() { handleBack() }

    // ── Permission ────────────────────────────────────────────────────────────

    private fun showAllFilesPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("All Files Access Needed")
            .setMessage(
                "To browse and open MHTML files, please enable " +
                "'All files access' for this app on the next screen."
            )
            .setPositiveButton("Grant Access") { _, _ ->
                runCatching {
                    manageStorageLauncher.launch(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:$packageName")
                        }
                    )
                }.onFailure {
                    // Fallback: open the general all-files settings page
                    runCatching {
                        manageStorageLauncher.launch(
                            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        )
                    }.onFailure {
                        Toast.makeText(this, "Cannot open settings", Toast.LENGTH_SHORT).show()
                        startNavigation()
                    }
                }
            }
            .setNegativeButton("Skip") { _, _ -> startNavigation() }
            .setCancelable(false)
            .show()
    }

    // ── Navigation ────────────────────────────────────────────────────────────

    /** Navigate to the first readable root on startup. */
    private fun startNavigation() {
        val startDir = CANDIDATE_ROOTS.firstOrNull { it.exists() && it.canRead() }
        if (startDir == null) {
            Toast.makeText(this, "Cannot access storage", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        navigateTo(startDir)
    }

    private fun handleBack() {
        if (navStack.size > 1) {
            navStack.removeLast()            // pop current
            val prev = navStack.removeLast() // pop previous (navigateTo will re-push)
            navigateTo(prev)
        } else {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }

    private fun navigateTo(dir: File) {
        if (!dir.canRead()) {
            Toast.makeText(this, "Cannot read: ${dir.name}", Toast.LENGTH_SHORT).show()
            return
        }
        navStack.addLast(dir)

        // ── Path label ────────────────────────────────────────────────────────
        val extRoot = Environment.getExternalStorageDirectory().absolutePath
        val display = dir.absolutePath
            .replace(extRoot, "📱 Internal Storage")
            .replace("/storage/emulated/0", "📱 Internal Storage")
        tvPath.text = display

        // ── Build entry list ──────────────────────────────────────────────────
        val files   = dir.listFiles() ?: emptyArray()
        val entries = mutableListOf<FileEntry>()

        // Parent folder entry (except at root candidates)
        val parent = dir.parentFile
        if (parent != null && parent.canRead() &&
            !CANDIDATE_ROOTS.any { it.canonicalPath == dir.canonicalPath }) {
            entries.add(FileEntry(parent, isParent = true))
        }

        val folders        = sortFiles(files.filter { it.isDirectory && !it.name.startsWith('.') && it.canRead() })
        val supportedFiles = sortFiles(files.filter { it.isFile && isSupportedFile(it.name) })

        entries.addAll(folders.map { FileEntry(it) })
        entries.addAll(supportedFiles.map { FileEntry(it) })

        adapter.setEntries(entries)
        rv.scrollToPosition(0)

        tvEmpty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        btnOpen.isEnabled  = false
        tvSelected.text    = "Tap files to select"
    }

    // ── Sort helpers ──────────────────────────────────────────────────────────

    /** Re-navigate to the current directory to apply a changed sort. */
    private fun refreshSort() {
        if (navStack.isNotEmpty()) {
            val current = navStack.removeLast()
            navigateTo(current)
        }
    }

    private fun sortFiles(files: List<File>): List<File> {
        val comp: Comparator<File> = when (sortBy) {
            SortBy.NAME -> compareBy { it.name.lowercase() }
            SortBy.DATE -> compareBy { it.lastModified() }
            SortBy.TYPE -> compareBy { it.extension.lowercase() }
        }
        return if (sortAscending) files.sortedWith(comp) else files.sortedWith(comp.reversed())
    }

    /** True for all file types the app can open. Uses explicit endsWith so
     *  multi-dot names like "ch.1.mhtml" always resolve to the right extension. */
    private fun isSupportedFile(name: String): Boolean {
        val lower = name.lowercase()
        return lower.endsWith(".mhtml") || lower.endsWith(".mht")  ||
               lower.endsWith(".jpg")   || lower.endsWith(".jpeg") ||
               lower.endsWith(".png")   || lower.endsWith(".webp") ||
               lower.endsWith(".gif")
    }

    private fun updateSortButtons() {
        val arrow = if (sortAscending) " ↑" else " ↓"
        btnSortName.text = "Name${if (sortBy == SortBy.NAME) arrow else ""}"
        btnSortDate.text = "Date${if (sortBy == SortBy.DATE) arrow else ""}"
        btnSortType.text = "Type${if (sortBy == SortBy.TYPE) arrow else ""}"

        val colorActive   = 0xFFA78BFA.toInt()  // purple-300
        val colorInactive = 0xFF6E7681.toInt()  // dim grey
        val bgActive      = 0x1A7C3AED           // 10% purple tint
        val bgClear       = 0x00000000

        listOf(
            btnSortName to (sortBy == SortBy.NAME),
            btnSortDate to (sortBy == SortBy.DATE),
            btnSortType to (sortBy == SortBy.TYPE)
        ).forEach { (btn, active) ->
            btn.setTextColor(if (active) colorActive else colorInactive)
            btn.setBackgroundColor(if (active) bgActive else bgClear)
        }
    }
}
