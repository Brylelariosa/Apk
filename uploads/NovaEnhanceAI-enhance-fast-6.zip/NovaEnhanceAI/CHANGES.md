# What changed in this build (faster + better enhancement, tuned for the Infinix HOT 11 2022)

Full explanation, measurements and honest limitations: README.md -> "Performance and quality work".
Trained models are unaffected: the network architecture and the checkpoint/parameter layout are unchanged,
so every existing checkpoint loads exactly as before.

## Native (C++)  app/src/main/cpp
| File | Status | Purpose |
|---|---|---|
| nn/simd.h | new | 4-lane SIMD layer: NEON AArch64, NEON ARMv7, portable fallback |
| nn/conv_kernels.{h,cpp} | new | register-blocked 3x3 conv kernels (forward, gated backward-data, weight-gradient) |
| nn/weights.{h,cpp} | new | repack flat params into kernel layouts (checkpoint format untouched) |
| nn/inference.{h,cpp} | new | fused streaming whole-image inference, column strips, seam-free |
| nn/training.{h,cpp} | new | parallel forward/backward over (sample x row-band) jobs |
| util/thread_pool.{h,cpp} | new | persistent worker pool, dynamic job scheduling (big.LITTLE friendly) |
| nn/network.{h,cpp} | modified | slim front door: init + optimizer; delegates to the above. Public API unchanged (trainStep gains a defaulted `threads`) |
| filters/convolution.{h,cpp} | modified | bilateral LUTs, blur fast path, row-parallel; output bit-identical |
| native-lib.cpp | modified | new JNI: nativeInferRegion, threads for train step, workspace release, backend name; image ceiling 4096 -> 16384 |
| CMakeLists.txt, ../../build.gradle.kts | modified | new sources; -O3 in every build type; NEON forced on armeabi-v7a |

## Kotlin  app/src/main/java/com/novaenhance/ai
| File | Status | Purpose |
|---|---|---|
| ai/engine/BandProcessor.kt | new | seam-free band-by-band processing (replaces TileProcessor) |
| ai/engine/TileProcessor.kt | removed | superseded by BandProcessor |
| ai/engine/EnhancementEngine.kt | modified | uses bands + whole-band native inference; same public API |
| ai/engine/NativeNeuralEngine.kt, NovaModelEngine.kt | modified | inferRegion, thread budget, workspace release, backend name |
| ai/engine/PixelBufferOps.kt | modified | cropRect, transformSquare (rotate/mirror augmentation) |
| training/trainer/TrainingPatchLoader.kt | new | background prefetch, 4 augmented patches per decoded crop |
| training/trainer/ModelTrainer.kt, AdaptiveTrainingController.kt | modified | uses the loader and thread budget; frees native workspace after a session |
| utils/ComputeBudget.kt | new | thread counts per workload (8 enhance / 6 train on an 8-core phone) |
| utils/Constants.kt, DiagnosticsReport.kt, ThermalGovernor.kt, ... | modified | new constants, "Native kernels:" line in debug info, doc updates |

## Tests and tooling
- app/src/test: PixelBufferOpsTest (+8 tests), ComputeBudgetTest (new) - written, NOT run (no Kotlin toolchain here).
- tools/nn_verification: run_all.sh, kernel_check, equivalence_check, bench, neon_shim.h, reference_network.cpp.
- tools/filter_verification: bit-exact filter check against the original implementation.
