package com.outcrop.feature.learningdashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.aiengine.LearningEvent
import com.outcrop.core.designsystem.OutcropPalette

/** A literal rendering of StrataStore's event log -- what got learned,
 *  reinforced, disputed, crystallized, or weathered into dormancy, most
 *  recent first (app spec S4.6). Not a separately-computed summary. */
@Composable
fun LearningDashboardScreen(viewModel: LearningDashboardViewModel = viewModel()) {
    val events by viewModel.events.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        if (events.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                BasicText(text = "No activity yet. Ingest something in Learn, then come back.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(events) { event -> EventRow(event) }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OutcropPalette.StrataDark)
                .clickable { viewModel.refresh() }
                .padding(12.dp)
        ) {
            BasicText(text = "Refresh")
        }
    }
}

@Composable
private fun EventRow(event: LearningEvent) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(rowColor(event))
            .padding(10.dp)
    ) {
        BasicText(text = "${ago(event.timestamp)} \u00b7 ${describe(event)}")
    }
}

private fun ago(timestampMillis: Long): String {
    val seconds = (System.currentTimeMillis() - timestampMillis) / 1000
    return when {
        seconds < 60 -> "${seconds}s ago"
        seconds < 3600 -> "${seconds / 60}m ago"
        else -> "${seconds / 3600}h ago"
    }
}

private fun describe(event: LearningEvent): String = when (event) {
    is LearningEvent.Learned ->
        "learned: ${event.subject} ${event.relation} ${event.obj} (conf ${"%.2f".format(event.confidence)})"
    is LearningEvent.Reinforced ->
        "reinforced: ${event.subject} ${event.relation} ${event.obj} (conf ${"%.2f".format(event.confidence)})"
    is LearningEvent.Disputed ->
        if (event.resolved) "correction accepted: ${event.subject} ${event.relation}"
        else "conflict noted: ${event.subject} ${event.relation}"
    is LearningEvent.Crystallized ->
        "rule crystallized: * ${event.relation} ${event.obj} (from ${event.fromInstances}, conf ${"%.2f".format(event.confidence)})"
    is LearningEvent.WentDormant ->
        "went dormant: ${event.subject} ${event.relation} ${event.obj}"
    is LearningEvent.Hypothesized ->
        "wondered: does ${event.subject} ${event.relation} ${event.obj}? \u2014 see Discover"
    is LearningEvent.HypothesisConfirmed ->
        "confirmed: ${event.subject} ${event.relation} ${event.obj} \u2014 promoted to a fact"
}

private fun rowColor(event: LearningEvent) = when (event) {
    is LearningEvent.Learned -> OutcropPalette.StrataBand1
    is LearningEvent.Reinforced -> OutcropPalette.StrataBand2
    is LearningEvent.Disputed -> if (event.resolved) OutcropPalette.StrataBand3 else OutcropPalette.StrataDark
    is LearningEvent.Crystallized -> OutcropPalette.StrataBand1
    is LearningEvent.WentDormant -> OutcropPalette.StrataDark
    is LearningEvent.Hypothesized -> OutcropPalette.StrataBand3
    is LearningEvent.HypothesisConfirmed -> OutcropPalette.StrataBand1
}
