package com.outcrop.feature.learningdashboard

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.LearningEvent
import com.outcrop.core.aiengine.StrataEngineProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class LearningDashboardViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _events = MutableStateFlow<List<LearningEvent>>(emptyList())
    val events: StateFlow<List<LearningEvent>> = _events

    init { refresh() }

    fun refresh() {
        _events.value = engine.recentEvents(100)
    }
}
