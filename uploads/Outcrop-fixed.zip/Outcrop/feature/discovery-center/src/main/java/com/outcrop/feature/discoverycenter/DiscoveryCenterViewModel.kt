package com.outcrop.feature.discoverycenter

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.DiscoveryScoring
import com.outcrop.core.aiengine.Grain
import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.StrataEngineProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class HypothesisCard(
    val grain: Grain,
    val novelty: Double,
    val surprise: Double,
    val discoveryScore: Double,
    val reason: String
)

/** Reads live Hypothesis grains from the shared engine and scores them --
 *  see DiscoveryScoring in :core:ai-engine for what novelty/surprise/
 *  discovery actually mean here. */
class DiscoveryCenterViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _hypotheses = MutableStateFlow<List<HypothesisCard>>(emptyList())
    val hypotheses: StateFlow<List<HypothesisCard>> = _hypotheses

    init { refresh() }

    fun refresh() {
        val all = engine.allGrains()
        _hypotheses.value = all
            .filter { it.type == GrainType.HYPOTHESIS }
            .map { hyp ->
                val novelty = DiscoveryScoring.novelty(hyp, all)
                val surprise = DiscoveryScoring.surprise(hyp, engine)
                HypothesisCard(
                    grain = hyp,
                    novelty = novelty,
                    surprise = surprise,
                    discoveryScore = DiscoveryScoring.discoveryScore(novelty, surprise),
                    reason = DiscoveryScoring.reasonFor(hyp, all)
                )
            }
            .sortedByDescending { it.discoveryScore }
    }
}
