package com.outcrop.feature.discoverycenter

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.designsystem.OutcropPalette

/** Live hypotheses -- proposed by StrataStore.generateHypotheses() when a
 *  rule crystallizes -- with novelty/surprise/discovery scores and a
 *  plain-English reason for each (app spec S4.4). */
@Composable
fun DiscoveryCenterScreen(viewModel: DiscoveryCenterViewModel = viewModel()) {
    val hypotheses by viewModel.hypotheses.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        if (hypotheses.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                BasicText(
                    text = "No open hypotheses yet. These appear once a rule crystallizes and " +
                        "looks like it should apply to someone you've mentioned but never " +
                        "confirmed -- try the \"chases\" example a few times in Teach, then " +
                        "mention a new name in an unrelated sentence first."
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(hypotheses, key = { it.grain.id }) { card -> HypothesisRow(card) }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OutcropPalette.StrataDark)
                .clickable { viewModel.refresh() }
                .padding(12.dp)
        ) {
            BasicText(text = "Refresh")
        }
    }
}

@Composable
private fun HypothesisRow(card: HypothesisCard) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(OutcropPalette.StrataBand3)
            .padding(12.dp)
    ) {
        BasicText(text = "${card.grain.subject} ${card.grain.relation} ${card.grain.obj}?")
        BasicText(
            text = "conf ${"%.2f".format(card.grain.confidence())}  \u00b7  novelty ${"%.2f".format(card.novelty)}" +
                "  \u00b7  surprise ${"%.2f".format(card.surprise)}  \u00b7  discovery ${"%.2f".format(card.discoveryScore)}"
        )
        BasicText(text = card.reason)
    }
}
