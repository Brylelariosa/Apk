package com.outcrop.feature.teach

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.outcrop.core.aiengine.EngineSnapshot
import com.outcrop.core.aiengine.Grain
import com.outcrop.core.aiengine.IngestResult
import com.outcrop.core.aiengine.Prospector
import com.outcrop.core.aiengine.QuestionQuery
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.appstorage.SnapshotStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class TeachEntry(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val grainCount: Int = 0
)

/**
 * Wires real Strata ingest/retrieval into the teach loop (app spec S4.1).
 * Strata V1 S0 is still explicit that Strata is the memory/reasoning
 * layer, not the language model -- there's no base LLM here, and this
 * doesn't generate text. What it now does is answer simple questions by
 * looking your taught facts up (Prospector.parseQuestion + engine.simulate/
 * allGrains): "does max chase ball" gets a yes/no against what's actually
 * stored, not a generated guess. Anything that doesn't parse as a
 * question still goes through the original extract -> ingest -> readout
 * path, unchanged.
 */
class TeachViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _entries = MutableStateFlow(
        listOf(
            TeachEntry(
                id = "intro", isUser = false,
                text = "Teach it facts, or ask about what you've taught it. Try \"max chases ball\" " +
                    "a few times, then ask \"does max chase ball\" or \"what does max chase\" -- " +
                    "answers come straight from what's stored, not a guess. Multi-word subjects " +
                    "and negation both work for teaching too, e.g. \"tom doesn't like java\"."
            )
        )
    )
    val entries: StateFlow<List<TeachEntry>> = _entries

    private val _telemetry = MutableStateFlow(EngineSnapshot(0, 0, 0))
    val telemetry: StateFlow<EngineSnapshot> = _telemetry

    fun send(text: String) {
        if (text.isBlank()) return
        appendEntry(isUser = true, text = text)

        val question = Prospector.parseQuestion(text)
        if (question != null) {
            val reply = answerQuestion(question)
            appendEntry(isUser = false, text = reply.text, grainCount = reply.grainCount)
            _telemetry.value = engine.telemetry()
            return
        }

        val reply = teach(text)
        appendEntry(isUser = false, text = reply.text, grainCount = reply.grainCount)
        _telemetry.value = engine.telemetry()
        persistSnapshot()
    }

    /** Fire-and-forget, off the main thread -- teaching a fact shouldn't
     *  visibly stall on a file write. See SnapshotStore's doc for why
     *  this exists at all (StrataEngineProvider.engine used to be
     *  in-memory only). */
    private fun persistSnapshot() {
        viewModelScope.launch(Dispatchers.IO) { SnapshotStore.save(engine.exportData()) }
    }

    private data class Reply(val text: String, val grainCount: Int = 0)

    private fun teach(text: String): Reply {
        val triples = Prospector.extract(text)
        val ingestNotes = triples.map { (s, r, o) ->
            when (val result = engine.ingest(s, r, o)) {
                is IngestResult.Created ->
                    "learned: $s $r $o (conf ${format(result.grain.confidence())})"
                is IngestResult.Reinforced ->
                    "reinforced: $s $r $o (conf ${format(result.grain.confidence())})"
                is IngestResult.Disputed ->
                    if (result.resolved) "correction accepted for $s $r"
                    else "noted a conflict on $s $r — not enough authority to override yet"
            }
        }

        val related = engine.query(text, k = 3)
        val newRules = engine.crystallize()
        engine.weatherTick()

        val responseText = buildString {
            append(
                if (ingestNotes.isEmpty())
                    "Didn't extract a clear fact from that — try a short \"X verb Y\" sentence, " +
                        "or a question like \"does X verb Y\"."
                else ingestNotes.joinToString("; ")
            )
            if (newRules.isNotEmpty()) {
                append(". New rule crystallized: * ${newRules.first().relation} ${newRules.first().obj}")
            }
            if (related.isNotEmpty()) {
                append(". Related in memory: ")
                append(related.joinToString("; ") { "${it.subject} ${it.relation} ${it.obj} (${format(it.confidence())})" })
            }
        }
        return Reply(responseText, grainCount = related.size)
    }

    /** Answers strictly from what's already stored -- engine.simulate()
     *  for subject-first lookups (facts and single-hop rule inference
     *  both), a direct grain scan for the reverse (relation, object) ->
     *  subject direction since simulate() doesn't support that side. No
     *  hit means saying so plainly and suggesting how to teach it,
     *  rather than falling back to a guess. */
    private fun answerQuestion(query: QuestionQuery): Reply = when (query) {
        is QuestionQuery.VerifyTriple -> {
            val known = engine.simulate(query.subject, query.relation)
            when {
                known != null && known.obj.equals(query.obj, ignoreCase = true) ->
                    Reply(
                        "Yes — ${query.subject} ${query.relation} ${query.obj} " +
                            "(conf ${format(known.confidence())}, ${sourceLabel(known)}).",
                        grainCount = 1
                    )
                known != null ->
                    Reply(
                        "Not quite — as far as I know, ${query.subject} ${query.relation} ${known.obj} instead " +
                            "(conf ${format(known.confidence())}, ${sourceLabel(known)}).",
                        grainCount = 1
                    )
                else ->
                    Reply(
                        "I don't have anything about that yet. Teach me with " +
                            "\"${query.subject} ${query.relation} ${query.obj}\" if it's true."
                    )
            }
        }
        is QuestionQuery.FindObject -> {
            val known = engine.simulate(query.subject, query.relation)
            if (known != null) {
                Reply(
                    "${query.subject} ${query.relation} ${known.obj} " +
                        "(conf ${format(known.confidence())}, ${sourceLabel(known)}).",
                    grainCount = 1
                )
            } else {
                Reply(
                    "I don't know yet what ${query.subject} ${query.relation}. Teach me with a sentence like " +
                        "\"${query.subject} ${query.relation} ...\"."
                )
            }
        }
        is QuestionQuery.FindSubject -> {
            val matches = engine.allGrains().filter {
                it.subject != "*" &&
                    it.relation.equals(query.relation, ignoreCase = true) &&
                    it.obj.equals(query.obj, ignoreCase = true)
            }
            if (matches.isNotEmpty()) {
                Reply(
                    "Matches: " + matches.joinToString("; ") { "${it.subject} (conf ${format(it.confidence())})" },
                    grainCount = matches.size
                )
            } else {
                Reply("I don't know of anything that ${query.relation} ${query.obj} yet.")
            }
        }
    }

    private fun sourceLabel(g: Grain): String = if (g.subject == "*") "inferred from a rule" else "direct fact"

    private fun appendEntry(isUser: Boolean, text: String, grainCount: Int = 0) {
        _entries.value = _entries.value + TeachEntry(
            id = (_entries.value.size + 1).toString(), isUser = isUser, text = text, grainCount = grainCount
        )
    }

    private fun format(v: Double) = "%.2f".format(v)
}
