package com.outcrop.feature.teach

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.aiengine.EngineSnapshot
import com.outcrop.core.designsystem.OutcropPalette

/** Primary teaching UI (app spec S4.1). Real text input wired to a real
 *  ingest/retrieval loop -- this is learn-only, not a Q&A chat, so there
 *  is no "answer" to send back. Streaming, cancel, edit, regenerate, and
 *  branch are still specified but not implemented here (app spec S7). */
@Composable
fun TeachScreen(viewModel: TeachViewModel = viewModel()) {
    val entries by viewModel.entries.collectAsState()
    val telemetry by viewModel.telemetry.collectAsState()

    // Background + system-bar/IME insets now come from OutcropTheme
    // (core/design-system) -- this Column just fills the space it's given.
    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries) { entry -> EntryBubble(entry) }
        }
        TelemetryFooter(telemetry)
        ComposerBar(onSend = viewModel::send)
    }
}

@Composable
private fun EntryBubble(entry: TeachEntry) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (entry.isUser) OutcropPalette.StrataBand3 else OutcropPalette.StrataBand1)
    ) {
        if (!entry.isUser && entry.grainCount > 0) {
            BasicText(
                text = "\u27E1 ${entry.grainCount} grains referenced",
                modifier = Modifier.padding(start = 12.dp, top = 8.dp)
            )
        }
        BasicText(text = entry.text, modifier = Modifier.padding(12.dp))
    }
}

/** Live counts straight from StrataEngine.telemetry() -- a minimal stand-in
 *  for the full AI Engine Dashboard (app spec S9), which is still a
 *  separate, not-yet-built screen. */
@Composable
private fun TelemetryFooter(telemetry: EngineSnapshot) {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        BasicText(
            text = "${telemetry.grainCount} grains \u00b7 ${telemetry.ruleCount} rules \u00b7 " +
                "${telemetry.latticeCount} in lattice"
        )
    }
}

@Composable
private fun ComposerBar(onSend: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(OutcropPalette.StrataDark)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            // BasicTextField has no built-in placeholder slot the way
            // Material's TextField does -- render one behind it manually.
            // (Also fixed: no cursorBrush meant an invisible text cursor
            // against the dark composer background.)
            if (input.isEmpty()) {
                BasicText(
                    text = "Teach it something\u2026",
                    style = TextStyle(color = OutcropPalette.Surface.copy(alpha = 0.5f))
                )
            }
            BasicTextField(
                value = input,
                onValueChange = { input = it },
                textStyle = TextStyle(color = OutcropPalette.Surface),
                cursorBrush = SolidColor(OutcropPalette.Surface)
            )
        }
        Row(
            modifier = Modifier
                .background(OutcropPalette.StrataBand2)
                .clickable {
                    if (input.isNotBlank()) {
                        onSend(input)
                        input = ""
                    }
                }
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            BasicText(text = "Teach")
        }
    }
}
