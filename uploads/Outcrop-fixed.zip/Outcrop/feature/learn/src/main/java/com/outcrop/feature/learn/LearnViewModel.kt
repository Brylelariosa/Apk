package com.outcrop.feature.learn

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.EngineSnapshot
import com.outcrop.core.aiengine.IngestResult
import com.outcrop.core.aiengine.Prospector
import com.outcrop.core.aiengine.StrataEngineProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class LearnEntry(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val grainCount: Int = 0
)

/**
 * Wires real Strata ingest/retrieval into the learn loop (app spec S4.1).
 * This is a teaching interface, not a chat -- Strata V1 S0 is explicit that
 * Strata is the memory/reasoning layer, not the language model, and there
 * is no base LLM here to answer questions with. What you type gets
 * genuinely extracted (see Prospector), deduplicated, confidence-scored,
 * and stored; the readout is a transparent record of what the memory
 * system actually did with it, not a conversational reply.
 */
class LearnViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _entries = MutableStateFlow(
        listOf(
            LearnEntry(
                id = "intro", isUser = false,
                text = "Teach it facts, don't ask it questions -- there's no Q&A here yet. " +
                    "Try \"max chases ball\" a few times, \"my favorite language is kotlin\", " +
                    "or \"tom doesn't like java\" -- multi-word subjects and negation both work " +
                    "now. I'll show exactly what gets learned, reinforced, or disputed."
            )
        )
    )
    val entries: StateFlow<List<LearnEntry>> = _entries

    private val _telemetry = MutableStateFlow(EngineSnapshot(0, 0, 0))
    val telemetry: StateFlow<EngineSnapshot> = _telemetry

    fun send(text: String) {
        if (text.isBlank()) return
        appendEntry(isUser = true, text = text)

        val triples = Prospector.extract(text)
        val ingestNotes = triples.map { (s, r, o) ->
            when (val result = engine.ingest(s, r, o)) {
                is IngestResult.Created ->
                    "learned: $s $r $o (conf ${format(result.grain.confidence())})"
                is IngestResult.Reinforced ->
                    "reinforced: $s $r $o (conf ${format(result.grain.confidence())})"
                is IngestResult.Disputed ->
                    if (result.resolved) "correction accepted for $s $r"
                    else "noted a conflict on $s $r — not enough authority to override yet"
            }
        }

        val related = engine.query(text, k = 3)
        val newRules = engine.crystallize()
        engine.weatherTick()

        val response = buildString {
            append(
                if (ingestNotes.isEmpty())
                    "Didn't extract a clear fact from that — try a short \"X verb Y\" sentence."
                else ingestNotes.joinToString("; ")
            )
            if (newRules.isNotEmpty()) {
                append(". New rule crystallized: * ${newRules.first().relation} ${newRules.first().obj}")
            }
            if (related.isNotEmpty()) {
                append(". Related in memory: ")
                append(related.joinToString("; ") { "${it.subject} ${it.relation} ${it.obj} (${format(it.confidence())})" })
            }
        }

        appendEntry(isUser = false, text = response, grainCount = related.size)
        _telemetry.value = engine.telemetry()
    }

    private fun appendEntry(isUser: Boolean, text: String, grainCount: Int = 0) {
        _entries.value = _entries.value + LearnEntry(
            id = (_entries.value.size + 1).toString(), isUser = isUser, text = text, grainCount = grainCount
        )
    }

    private fun format(v: Double) = "%.2f".format(v)
}
