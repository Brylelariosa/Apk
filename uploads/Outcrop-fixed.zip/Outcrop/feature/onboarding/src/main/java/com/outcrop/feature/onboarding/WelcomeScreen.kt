package com.outcrop.feature.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.outcrop.core.designsystem.OutcropPalette

/** First-run screen (app spec S2.2, S5). Background + insets now come
 *  from OutcropTheme, so this screen only worries about its own content. */
@Composable
fun WelcomeScreen(onContinue: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            BasicText(text = "Outcrop")
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .background(OutcropPalette.StrataBand2)
                    .clickable { onContinue() }
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                BasicText(text = "Get started")
            }
        }
    }
}
