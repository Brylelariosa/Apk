package com.outcrop.feature.knowledgegraph

import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.Tier
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Normalized 0f..1f position -- deliberately not androidx.compose.ui's
 *  Offset, so this presentation-adjacent math has zero dependency on the
 *  UI framework and stays trivially testable outside Android. */
data class GraphPoint(val x: Float, val y: Float)

data class GraphNode(val key: String, val label: String, val isWildcard: Boolean)

data class GraphEdge(
    val fromKey: String,
    val toKey: String,
    val relation: String,
    val type: GrainType,
    val tier: Tier,
    val confidence: Double
)

data class GraphData(
    val nodes: List<GraphNode> = emptyList(),
    val positions: Map<String, GraphPoint> = emptyMap(),
    val edges: List<GraphEdge> = emptyList()
)

/**
 * A small, dependency-free Fruchterman-Reingold layout (app spec S4.3):
 * every node pair repels, every edge attracts its two endpoints, a gentle
 * spring pulls everything toward center so the graph doesn't drift off
 * screen, and a cooling "temperature" caps how far a node can move per
 * iteration so the system settles instead of oscillating. Positions start
 * on a deterministic circle (no randomness) so the same grain set always
 * settles into a comparable layout run to run.
 */
object ForceLayout {
    private const val ITERATIONS = 250
    private const val MIN_DISTANCE = 0.001f
    private const val CENTERING_STRENGTH = 0.02f
    private const val INITIAL_TEMPERATURE = 0.12f
    private const val COOLING = 0.97f
    private const val MARGIN = 0.06f

    fun compute(keys: List<String>, edges: List<Pair<String, String>>): Map<String, GraphPoint> {
        if (keys.isEmpty()) return emptyMap()
        if (keys.size == 1) return mapOf(keys[0] to GraphPoint(0.5f, 0.5f))

        val indexOf = keys.withIndex().associate { (i, key) -> key to i }
        val idealDistance = sqrt(1f / keys.size)

        val x = FloatArray(keys.size)
        val y = FloatArray(keys.size)
        keys.indices.forEach { i ->
            val angle = (2.0 * PI * i / keys.size).toFloat()
            x[i] = 0.5f + 0.3f * cos(angle)
            y[i] = 0.5f + 0.3f * sin(angle)
        }

        val edgeIndices = edges.mapNotNull { (from, to) ->
            val i = indexOf[from]
            val j = indexOf[to]
            if (i != null && j != null && i != j) i to j else null
        }

        var temperature = INITIAL_TEMPERATURE
        repeat(ITERATIONS) {
            val dispX = FloatArray(keys.size)
            val dispY = FloatArray(keys.size)

            for (i in keys.indices) {
                for (j in keys.indices) {
                    if (i == j) continue
                    var dx = x[i] - x[j]
                    var dy = y[i] - y[j]
                    var dist = sqrt(dx * dx + dy * dy)
                    if (dist < MIN_DISTANCE) { dx = MIN_DISTANCE; dy = 0f; dist = MIN_DISTANCE }
                    val force = (idealDistance * idealDistance) / dist
                    dispX[i] += (dx / dist) * force
                    dispY[i] += (dy / dist) * force
                }
            }

            for ((i, j) in edgeIndices) {
                var dx = x[i] - x[j]
                var dy = y[i] - y[j]
                var dist = sqrt(dx * dx + dy * dy)
                if (dist < MIN_DISTANCE) dist = MIN_DISTANCE
                val force = (dist * dist) / idealDistance
                val fx = (dx / dist) * force
                val fy = (dy / dist) * force
                dispX[i] -= fx; dispY[i] -= fy
                dispX[j] += fx; dispY[j] += fy
            }

            for (i in keys.indices) {
                dispX[i] += (0.5f - x[i]) * CENTERING_STRENGTH
                dispY[i] += (0.5f - y[i]) * CENTERING_STRENGTH
            }

            for (i in keys.indices) {
                val dist = sqrt(dispX[i] * dispX[i] + dispY[i] * dispY[i]).coerceAtLeast(MIN_DISTANCE)
                val capped = dist.coerceAtMost(temperature)
                x[i] = (x[i] + (dispX[i] / dist) * capped).coerceIn(MARGIN, 1f - MARGIN)
                y[i] = (y[i] + (dispY[i] / dist) * capped).coerceIn(MARGIN, 1f - MARGIN)
            }

            temperature *= COOLING
        }

        return keys.indices.associate { i -> keys[i] to GraphPoint(x[i], y[i]) }
    }
}
