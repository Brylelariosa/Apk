package com.outcrop.feature.knowledgegraph

// Placeholder module -- see app spec S4.3.
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object KnowledgeGraphPlaceholder
