package com.outcrop.feature.memoryexplorer

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.Grain
import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.StrataEngineProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Reads from the shared StrataEngineProvider.engine -- the same instance
 *  Learn ingests into -- not a private copy. */
class MemoryExplorerViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _grains = MutableStateFlow<List<Grain>>(emptyList())
    val grains: StateFlow<List<Grain>> = _grains

    private val _filter = MutableStateFlow<GrainType?>(null)
    val filter: StateFlow<GrainType?> = _filter

    init { refresh() }

    fun refresh() {
        _grains.value = engine.allGrains()
    }

    fun setFilter(type: GrainType?) {
        _filter.value = type
    }
}
