package com.outcrop.feature.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.outcrop.core.aiengine.StrataEngineProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/**
 * AndroidViewModel (not plain ViewModel) specifically to get access to
 * Application/filesDir for the export/import file path -- the first
 * screen in this project that needs real file I/O.
 */
class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val engine = StrataEngineProvider.engine

    private val _hypothesesEnabled = MutableStateFlow(engine.hypothesesEnabled)
    val hypothesesEnabled: StateFlow<Boolean> = _hypothesesEnabled

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status

    fun setHypothesesEnabled(enabled: Boolean) {
        engine.hypothesesEnabled = enabled
        _hypothesesEnabled.value = enabled
    }

    private fun exportFile(): File = File(getApplication<Application>().filesDir, "outcrop-export.txt")

    fun export() {
        try {
            exportFile().writeText(engine.exportData())
            _status.value = "Exported ${engine.allGrains().size} grain(s) to ${exportFile().name}."
        } catch (e: Exception) {
            _status.value = "Export failed: ${e.message}"
        }
    }

    fun import() {
        try {
            val file = exportFile()
            if (!file.exists()) {
                _status.value = "No export file yet -- tap Export first."
                return
            }
            engine.importData(file.readText())
            _status.value = "Imported ${engine.allGrains().size} grain(s) from ${file.name}. " +
                "This replaced whatever was in memory before."
        } catch (e: Exception) {
            _status.value = "Import failed: ${e.message}"
        }
    }
}
