package com.outcrop.feature.settings

import android.content.Context
import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.background.UndertowScheduler
import com.outcrop.core.background.UndertowStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Plain ViewModel, not AndroidViewModel -- export/import/backup already
 * moved out to feature/data-io; the Undertow controls below take Context
 * as a per-call parameter from the Composable (LocalContext.current)
 * instead of this ViewModel holding one, for the same reason.
 */
class SettingsViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _hypothesesEnabled = MutableStateFlow(engine.hypothesesEnabled)
    val hypothesesEnabled: StateFlow<Boolean> = _hypothesesEnabled

    private val _undertowStatus = MutableStateFlow<UndertowStatus?>(null)
    val undertowStatus: StateFlow<UndertowStatus?> = _undertowStatus

    fun setHypothesesEnabled(enabled: Boolean) {
        engine.hypothesesEnabled = enabled
        _hypothesesEnabled.value = enabled
    }

    fun refreshUndertowStatus(context: Context) {
        _undertowStatus.value = UndertowScheduler.status(context)
    }

    fun setUndertowEnabled(context: Context, enabled: Boolean) {
        UndertowScheduler.setEnabled(context, enabled)
        refreshUndertowStatus(context)
    }

    /** WorkManager runs this asynchronously, so the status readout won't
     *  reflect it immediately -- the screen re-checks a couple of times
     *  over the following seconds rather than promising a synchronous
     *  result the underlying API can't actually give. */
    fun runUndertowNow(context: Context) {
        UndertowScheduler.runNow(context)
    }
}
