package com.outcrop.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.background.UndertowStatus
import com.outcrop.core.designsystem.OutcropPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Preferences, folded together with entry points into Data I/O and
 *  Undertow rather than separate top-level tabs -- the original nav plan
 *  (app spec S2) put Backup/Import/Export as children of Settings, not
 *  their own destination, and the bottom nav is already at six tabs.
 *  Data I/O (feature/data-io) has the real SAF file picker, share sheet,
 *  and plugin format support; Undertow (core/background) is the graded
 *  background maintenance worker (app spec S1.6). */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel(), onOpenDataIo: () -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val hypothesesEnabled by viewModel.hypothesesEnabled.collectAsState()
    val undertowStatus by viewModel.undertowStatus.collectAsState()

    LaunchedEffect(Unit) { viewModel.refreshUndertowStatus(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        BasicText(text = "Settings")
        Spacer(modifier = Modifier.height(16.dp))

        ToggleRow(
            label = "Discovery -- propose hypotheses when a rule crystallizes",
            checked = hypothesesEnabled,
            onToggle = { viewModel.setHypothesesEnabled(!hypothesesEnabled) }
        )

        Spacer(modifier = Modifier.height(24.dp))
        BasicText(text = "Background maintenance")
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(
            text = "Undertow keeps decay and rule crystallization current even when Teach " +
                "isn't open. No networking involved -- purely local."
        )
        Spacer(modifier = Modifier.height(8.dp))
        ToggleRow(
            label = "Enabled",
            checked = undertowStatus?.enabled ?: true,
            onToggle = {
                viewModel.setUndertowEnabled(context, !(undertowStatus?.enabled ?: true))
            }
        )
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(text = undertowStatusLabel(undertowStatus))
        Spacer(modifier = Modifier.height(8.dp))
        ActionRow("Run now") {
            viewModel.runUndertowNow(context)
            scope.launch {
                // WorkManager runs this asynchronously -- poll a couple of
                // times rather than pretending the tap is synchronous.
                delay(3000); viewModel.refreshUndertowStatus(context)
                delay(4000); viewModel.refreshUndertowStatus(context)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        BasicText(text = "Data & plugins")
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(text = "Export or restore a snapshot, share it, or manage import/export plugins.")
        Spacer(modifier = Modifier.height(8.dp))
        ActionRow("Open Data I/O", onClick = onOpenDataIo)

        Spacer(modifier = Modifier.height(24.dp))
        BasicText(text = "About")
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(text = "Outcrop 0.1.0-skeleton")
        BasicText(text = "Memory reset (clears everything) lives on the Insights screen.")
    }
}

private fun undertowStatusLabel(status: UndertowStatus?): String = when {
    status == null -> "Checking status…"
    status.lastRunAtMillis == 0L -> "Hasn't run yet."
    else -> {
        val ago = formatAgo(System.currentTimeMillis() - status.lastRunAtMillis)
        val effort = status.lastEffort?.name?.lowercase() ?: "unknown"
        "Last ran $ago at $effort effort."
    }
}

private fun formatAgo(deltaMillis: Long): String {
    val minutes = deltaMillis / 60_000
    return when {
        minutes < 1 -> "just now"
        minutes < 60 -> "${minutes}m ago"
        minutes < 60 * 24 -> "${minutes / 60}h ago"
        else -> "${minutes / (60 * 24)}d ago"
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .background(if (checked) OutcropPalette.StrataBand1 else OutcropPalette.StrataDark)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            BasicText(text = if (checked) "ON" else "OFF")
        }
        BasicText(text = label, modifier = Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun ActionRow(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(OutcropPalette.StrataBand2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        BasicText(text = label)
    }
}
