package com.outcrop.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.designsystem.OutcropPalette

/** Preferences plus a minimal backup/restore, folded into one screen
 *  rather than a separate Data I/O tab -- the original nav plan (app spec
 *  S2) put Backup/Import/Export as children of Settings, not their own
 *  top-level destination, and the bottom nav is already at five tabs. A
 *  fuller Data I/O experience (real file picker, share sheet) is still a
 *  reasonable future upgrade -- :feature:data-io stays reserved for it. */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel()) {
    val hypothesesEnabled by viewModel.hypothesesEnabled.collectAsState()
    val status by viewModel.status.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BasicText(text = "Settings")
        Spacer(modifier = Modifier.height(16.dp))

        ToggleRow(
            label = "Discovery -- propose hypotheses when a rule crystallizes",
            checked = hypothesesEnabled,
            onToggle = { viewModel.setHypothesesEnabled(!hypothesesEnabled) }
        )

        Spacer(modifier = Modifier.height(24.dp))
        BasicText(text = "Backup")
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(
            text = "Everything lives in memory and resets when the app closes. This saves a " +
                "plain-text snapshot to app-private storage -- not a real share sheet or file " +
                "picker yet, just enough to survive a restart."
        )
        Spacer(modifier = Modifier.height(8.dp))
        ActionRow("Export current memory", OutcropPalette.StrataBand2) { viewModel.export() }
        Spacer(modifier = Modifier.height(8.dp))
        ActionRow("Import (replaces current memory)", OutcropPalette.StrataDark) { viewModel.import() }
        if (status.isNotBlank()) {
            Spacer(modifier = Modifier.height(8.dp))
            BasicText(text = status)
        }

        Spacer(modifier = Modifier.height(24.dp))
        BasicText(text = "About")
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(text = "Outcrop 0.1.0-skeleton")
        BasicText(text = "Memory reset (clears everything) lives on the Insights screen.")
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .background(if (checked) OutcropPalette.StrataBand1 else OutcropPalette.StrataDark)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            BasicText(text = if (checked) "ON" else "OFF")
        }
        BasicText(text = label, modifier = Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun ActionRow(label: String, color: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        BasicText(text = label)
    }
}
