package com.outcrop.feature.dataio

import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.designsystem.OutcropPalette
import java.io.File

/**
 * Data I/O (app spec S1.7): a real SAF document picker for export/import
 * (ActivityResultContracts.CreateDocument/OpenDocument) plus a share-sheet
 * export via FileProvider, replacing the placeholder that used to live
 * inline in Settings. Reached from Settings, not the bottom nav -- see
 * OutcropNavHost's Routes comment for why.
 */
@Composable
fun DataIoScreen(viewModel: DataIoViewModel = viewModel()) {
    val context = LocalContext.current
    val plugins by viewModel.plugins.collectAsState()

    val exportFormats = viewModel.exportFormats()
    val importFormats = viewModel.importFormats()

    var selectedExportFormat by remember { mutableStateOf(NATIVE_FORMAT_ID) }
    var selectedImportFormat by remember { mutableStateOf(NATIVE_FORMAT_ID) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(exportFormats) {
        if (exportFormats.none { it.id == selectedExportFormat }) selectedExportFormat = NATIVE_FORMAT_ID
    }
    LaunchedEffect(importFormats) {
        if (importFormats.none { it.id == selectedImportFormat }) selectedImportFormat = NATIVE_FORMAT_ID
    }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        statusMessage = try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(viewModel.exportText(selectedExportFormat).toByteArray())
            }
            "Exported."
        } catch (e: Exception) {
            "Export failed: ${e.message}"
        }
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        statusMessage = try {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            if (text == null) {
                "Import failed: couldn't read that file."
            } else {
                val s = viewModel.importText(selectedImportFormat, text)
                if (selectedImportFormat == NATIVE_FORMAT_ID) {
                    "Restored ${s.total} grain(s) from snapshot."
                } else {
                    "Imported ${s.total} record(s): ${s.created} new, ${s.reinforced} reinforced, ${s.disputed} disputed."
                }
            }
        } catch (e: Exception) {
            "Import failed: ${e.message}"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        BasicText(text = "Export")
        Spacer(modifier = Modifier.height(6.dp))
        FormatRow(options = exportFormats, selected = selectedExportFormat, onSelect = { selectedExportFormat = it })
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("Export to file") {
                exportLauncher.launch(exportFileName(selectedExportFormat))
            }
            ActionButton("Share") {
                statusMessage = try {
                    shareExport(context, viewModel.exportText(selectedExportFormat), selectedExportFormat)
                    "Opened share sheet."
                } catch (e: Exception) {
                    "Share failed: ${e.message}"
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        BasicText(text = "Import")
        Spacer(modifier = Modifier.height(6.dp))
        FormatRow(options = importFormats, selected = selectedImportFormat, onSelect = { selectedImportFormat = it })
        Spacer(modifier = Modifier.height(8.dp))
        ActionButton("Import from file") { importLauncher.launch(arrayOf("*/*")) }

        statusMessage?.let {
            Spacer(modifier = Modifier.height(10.dp))
            BasicText(text = it)
        }

        Spacer(modifier = Modifier.height(28.dp))
        BasicText(text = "Plugins")
        Spacer(modifier = Modifier.height(6.dp))
        plugins.forEach { p ->
            PluginRow(state = p, onToggle = { viewModel.setPluginEnabled(p.descriptor.id, !p.enabled) })
        }
    }
}

@Composable
private fun FormatRow(options: List<FormatChoice>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            Box(
                modifier = Modifier
                    .background(if (option.id == selected) OutcropPalette.StrataBand2 else OutcropPalette.StrataBand3)
                    .clickable { onSelect(option.id) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                BasicText(text = option.displayName)
            }
        }
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .background(OutcropPalette.StrataBand2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) { BasicText(text = label) }
}

@Composable
private fun PluginRow(state: PluginUiState, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            BasicText(text = "${state.descriptor.displayName} \u00b7 ${state.descriptor.kind.name.lowercase()}")
            BasicText(text = state.descriptor.description)
        }
        BasicText(text = if (state.enabled) "On" else "Off")
    }
}

private fun exportFileName(formatId: String): String = when {
    formatId == NATIVE_FORMAT_ID -> "outcrop_export.txt"
    formatId.contains("csv") -> "outcrop_export.csv"
    formatId.contains("jsonlines") -> "outcrop_export.jsonl"
    else -> "outcrop_export.txt"
}

/** Writes to the app's own cache/exports/ folder (matching res/xml/file_paths.xml)
 *  and hands a content:// URI to the system share sheet -- no broad storage
 *  permission needed since the file never leaves app-private storage until
 *  the receiving app reads it through that URI. */
private fun shareExport(context: Context, text: String, formatId: String) {
    val dir = File(context.cacheDir, "exports").apply { mkdirs() }
    val file = File(dir, exportFileName(formatId))
    file.writeText(text)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share Outcrop export"))
}
