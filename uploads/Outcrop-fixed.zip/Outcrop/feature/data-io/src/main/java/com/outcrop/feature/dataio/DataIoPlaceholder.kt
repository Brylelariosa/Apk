package com.outcrop.feature.dataio

// Placeholder module -- see app spec S1.7 (importer/exporter).
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object DataIoPlaceholder
