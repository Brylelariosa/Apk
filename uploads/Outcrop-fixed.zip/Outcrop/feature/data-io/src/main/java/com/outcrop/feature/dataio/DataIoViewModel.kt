package com.outcrop.feature.dataio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.outcrop.core.aiengine.IngestResult
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.appstorage.OutcropDatabaseProvider
import com.outcrop.core.appstorage.SnapshotStore
import com.outcrop.core.appstorage.entity.PluginEntity
import com.outcrop.core.pluginapi.PluginDescriptor
import com.outcrop.core.pluginapi.PluginKind
import com.outcrop.core.pluginapi.PluginRegistry
import com.outcrop.core.pluginapi.PluginTriple
import com.outcrop.core.pluginapi.sourceHash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Reserved id for the app's own hand-rolled snapshot format
 *  (PersistenceCodec, via StrataEngine.exportData/importData). Never
 *  collides with a plugin id -- every built-in plugin id is namespaced
 *  "builtin.<name>.<kind>". */
const val NATIVE_FORMAT_ID = "native"

/** A pickable format in the export/import UI. Deliberately not
 *  PluginDescriptor -- the native format isn't a plugin (it doesn't go
 *  through PluginRegistry, and forcing a PluginKind onto it to satisfy
 *  that type would be a lie about what it is), so this is its own small
 *  shape that both native and plugin formats fit into. */
data class FormatChoice(val id: String, val displayName: String, val description: String)

data class PluginUiState(val descriptor: PluginDescriptor, val enabled: Boolean)

data class ImportSummary(val created: Int, val reinforced: Int, val disputed: Int, val total: Int)

/**
 * Backs the Data I/O screen (app spec S1.7): real export/import, plus
 * enable/disable for the built-in importer/exporter plugins. Plugin
 * *implementations* are fixed, compiled-in code from PluginRegistry
 * (core/plugin-api) -- what's actually persisted here, via PluginDao, is
 * just which of them the user has turned on, matching PluginEntity's
 * real shape in core/app-storage.
 */
class DataIoViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine
    private val pluginDao = OutcropDatabaseProvider.pluginDao()

    private val nativeFormat = FormatChoice(
        id = NATIVE_FORMAT_ID, displayName = "Outcrop native",
        description = "Full snapshot -- import replaces current memory entirely, doesn't merge"
    )

    private val _plugins = MutableStateFlow<List<PluginUiState>>(
        PluginRegistry.all.map { PluginUiState(it, enabled = true) }
    )
    val plugins: StateFlow<List<PluginUiState>> = _plugins

    private val _lastImportSummary = MutableStateFlow<ImportSummary?>(null)
    val lastImportSummary: StateFlow<ImportSummary?> = _lastImportSummary

    init {
        viewModelScope.launch {
            seedMissingPlugins()
            pluginDao.observeAll().collect { entities ->
                val byId = entities.associateBy { it.id }
                _plugins.value = PluginRegistry.all.map { descriptor ->
                    PluginUiState(descriptor, enabled = byId[descriptor.id]?.enabled ?: true)
                }
            }
        }
    }

    private suspend fun seedMissingPlugins() {
        val existingIds = pluginDao.observeAll().first().map { it.id }.toSet()
        PluginRegistry.all.filter { it.id !in existingIds }.forEach { descriptor ->
            pluginDao.upsert(
                PluginEntity(
                    id = descriptor.id,
                    kind = descriptor.kind.name.lowercase(),
                    enabled = true,
                    sourceHash = descriptor.sourceHash(),
                    combinatorProgram = null
                )
            )
        }
    }

    fun setPluginEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch { pluginDao.setEnabled(id, enabled) }
    }

    fun exportFormats(): List<FormatChoice> =
        listOf(nativeFormat) + _plugins.value
            .filter { it.enabled && it.descriptor.kind == PluginKind.EXPORTER }
            .map { FormatChoice(it.descriptor.id, it.descriptor.displayName, it.descriptor.description) }

    fun importFormats(): List<FormatChoice> =
        listOf(nativeFormat) + _plugins.value
            .filter { it.enabled && it.descriptor.kind == PluginKind.IMPORTER }
            .map { FormatChoice(it.descriptor.id, it.descriptor.displayName, it.descriptor.description) }

    fun exportText(formatId: String): String {
        if (formatId == NATIVE_FORMAT_ID) return engine.exportData()
        val plugin = PluginRegistry.exporterById(formatId) ?: return ""
        val triples = engine.allGrains().map { PluginTriple(it.subject, it.relation, it.obj) }
        return plugin.render(triples)
    }

    /** Native format replaces the store wholesale (StrataEngine.importData's
     *  existing, documented behavior). Plugin formats instead go through
     *  ingest() per triple -- the same dedupe/confidence/dispute path Teach
     *  uses -- since a CSV or JSON Lines file is a list of facts to teach,
     *  not a full Grain snapshot with its own confidence/tier/vitality. */
    fun importText(formatId: String, text: String): ImportSummary {
        val summary = if (formatId == NATIVE_FORMAT_ID) {
            engine.importData(text)
            val total = engine.allGrains().size
            ImportSummary(created = total, reinforced = 0, disputed = 0, total = total)
        } else {
            val plugin = PluginRegistry.importerById(formatId)
            val triples = plugin?.parse(text) ?: emptyList()
            var created = 0
            var reinforced = 0
            var disputed = 0
            for (t in triples) {
                when (engine.ingest(t.subject, t.relation, t.obj)) {
                    is IngestResult.Created -> created++
                    is IngestResult.Reinforced -> reinforced++
                    is IngestResult.Disputed -> disputed++
                }
            }
            ImportSummary(created, reinforced, disputed, triples.size)
        }
        _lastImportSummary.value = summary
        viewModelScope.launch(Dispatchers.IO) { SnapshotStore.save(engine.exportData()) }
        return summary
    }
}
