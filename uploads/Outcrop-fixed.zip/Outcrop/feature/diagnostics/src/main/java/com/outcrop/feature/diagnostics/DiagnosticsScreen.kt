package com.outcrop.feature.diagnostics

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.designsystem.DistributionBar
import com.outcrop.core.designsystem.LegendRow
import com.outcrop.core.designsystem.OutcropConfidenceScale
import com.outcrop.core.designsystem.OutcropPalette

/** The AI Engine Dashboard (app spec S9). Grew out of a minimal
 *  stat-row stand-in -- still no external charting dependency, every
 *  visualization here is plain weighted Rows/Columns over OutcropPalette
 *  and OutcropConfidenceScale, matching how the rest of this app avoids
 *  pulling in a chart library for a handful of bars. */
@Composable
fun DiagnosticsScreen(viewModel: DiagnosticsViewModel = viewModel()) {
    val s by viewModel.snapshot.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            BasicText(text = "Engine snapshot")
            Spacer(modifier = Modifier.height(16.dp))
            StatRow("Total grains", "${s.totalGrains}")
            StatRow("Average confidence", "%.2f".format(s.averageConfidence))

            Spacer(modifier = Modifier.height(20.dp))
            BasicText(text = "By type")
            Spacer(modifier = Modifier.height(6.dp))
            DistributionBar(
                listOf(
                    s.factCount to OutcropPalette.StrataBand1,
                    s.ruleCount to OutcropPalette.StrataBand2,
                    s.hypothesisCount to OutcropPalette.StrataBand3
                )
            )
            LegendRow(
                listOf(
                    "Fact ${s.factCount}" to OutcropPalette.StrataBand1,
                    "Rule ${s.ruleCount}" to OutcropPalette.StrataBand2,
                    "Hypothesis ${s.hypothesisCount}" to OutcropPalette.StrataBand3
                )
            )

            Spacer(modifier = Modifier.height(20.dp))
            BasicText(text = "By tier")
            Spacer(modifier = Modifier.height(6.dp))
            DistributionBar(
                listOf(
                    s.seedCount to OutcropPalette.StrataBand3,
                    s.latticeCount to OutcropPalette.StrataBand1,
                    s.dormantCount to OutcropPalette.StrataDark
                )
            )
            LegendRow(
                listOf(
                    "Seed ${s.seedCount}" to OutcropPalette.StrataBand3,
                    "Lattice ${s.latticeCount}" to OutcropPalette.StrataBand1,
                    "Dormant ${s.dormantCount}" to OutcropPalette.StrataDark
                )
            )

            Spacer(modifier = Modifier.height(20.dp))
            BasicText(text = "Confidence histogram")
            Spacer(modifier = Modifier.height(6.dp))
            ConfidenceHistogram(s.confidenceBuckets)

            if (s.relationStats.isNotEmpty()) {
                Spacer(modifier = Modifier.height(20.dp))
                BasicText(text = "By relation")
                Spacer(modifier = Modifier.height(6.dp))
                s.relationStats.forEach { rel ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        BasicText(text = rel.relation)
                        BasicText(text = "${rel.count} \u00b7 conf %.2f".format(rel.averageConfidence))
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .background(OutcropPalette.StrataBand2)
                .clickable { viewModel.refresh() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { BasicText(text = "Refresh") }

        Row(
            modifier = Modifier
                .background(OutcropPalette.StrataDark)
                .clickable { viewModel.resetMemory() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { BasicText(text = "Reset memory (clears every grain)") }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        BasicText(text = label)
        BasicText(text = value)
    }
}

/** Five bars over OutcropConfidenceScale.Low/Mid/High -- the same fixed,
 *  wallpaper-independent confidence colors used everywhere else, so a
 *  bucket's color always means the same thing across the whole app. */
@Composable
private fun ConfidenceHistogram(buckets: List<Int>) {
    val maxCount = (buckets.maxOrNull() ?: 0).coerceAtLeast(1)
    val maxBarHeight = 72.dp
    Row(
        modifier = Modifier.fillMaxWidth().height(maxBarHeight + 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        buckets.forEachIndexed { index, count ->
            val fraction = count.toFloat() / maxCount
            val color = when (index) {
                0, 1 -> OutcropConfidenceScale.Low
                2 -> OutcropConfidenceScale.Mid
                else -> OutcropConfidenceScale.High
            }
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                BasicText(text = "$count")
                Spacer(modifier = Modifier.height(2.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((maxBarHeight.value * fraction).dp.coerceAtLeast(2.dp))
                        .background(color)
                )
                Spacer(modifier = Modifier.height(2.dp))
                BasicText(text = bucketLabel(index))
            }
        }
    }
}

private fun bucketLabel(index: Int): String {
    val low = index * 100 / CONFIDENCE_BUCKET_COUNT
    val high = (index + 1) * 100 / CONFIDENCE_BUCKET_COUNT
    return "$low-$high"
}
