package com.outcrop.feature.diagnostics

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.designsystem.OutcropPalette

/** Minimal stand-in for the AI Engine Dashboard / Statistics screens (app
 *  spec S9, S5). */
@Composable
fun DiagnosticsScreen(viewModel: DiagnosticsViewModel = viewModel()) {
    val s by viewModel.snapshot.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        BasicText(text = "Engine snapshot")
        Spacer(modifier = Modifier.height(16.dp))
        StatRow("Total grains", "${s.totalGrains}")
        StatRow("Facts / Rules / Hypotheses", "${s.factCount} / ${s.ruleCount} / ${s.hypothesisCount}")
        StatRow("Seed / Lattice / Dormant", "${s.seedCount} / ${s.latticeCount} / ${s.dormantCount}")
        StatRow("Average confidence", "%.2f".format(s.averageConfidence))

        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier
                .background(OutcropPalette.StrataBand2)
                .clickable { viewModel.refresh() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { BasicText(text = "Refresh") }

        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .background(OutcropPalette.StrataDark)
                .clickable { viewModel.resetMemory() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { BasicText(text = "Reset memory (clears every grain)") }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        BasicText(text = label)
        BasicText(text = value)
    }
}
