package com.outcrop.feature.diagnostics

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.aiengine.Tier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class DiagnosticsSnapshot(
    val totalGrains: Int = 0,
    val factCount: Int = 0,
    val ruleCount: Int = 0,
    val hypothesisCount: Int = 0,
    val seedCount: Int = 0,
    val latticeCount: Int = 0,
    val dormantCount: Int = 0,
    val averageConfidence: Double = 0.0
)

/** A minimal stand-in for the full AI Engine Dashboard (app spec S9) --
 *  every number here is a real read of StrataEngineProvider.engine's
 *  state, computed fresh on refresh(), not mocked. */
class DiagnosticsViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _snapshot = MutableStateFlow(DiagnosticsSnapshot())
    val snapshot: StateFlow<DiagnosticsSnapshot> = _snapshot

    init { refresh() }

    fun refresh() {
        val all = engine.allGrains()
        _snapshot.value = DiagnosticsSnapshot(
            totalGrains = all.size,
            factCount = all.count { it.type == GrainType.FACT },
            ruleCount = all.count { it.type == GrainType.RULE },
            hypothesisCount = all.count { it.type == GrainType.HYPOTHESIS },
            seedCount = all.count { it.tier == Tier.SEED },
            latticeCount = all.count { it.tier == Tier.LATTICE },
            dormantCount = all.count { it.tier == Tier.DORMANT },
            averageConfidence = if (all.isEmpty()) 0.0 else all.sumOf { it.confidence() } / all.size
        )
    }

    fun resetMemory() {
        engine.resetAll()
        refresh()
    }
}
