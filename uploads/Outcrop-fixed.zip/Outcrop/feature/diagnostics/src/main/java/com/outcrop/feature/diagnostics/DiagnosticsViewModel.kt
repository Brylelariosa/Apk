package com.outcrop.feature.diagnostics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.aiengine.Tier
import com.outcrop.core.appstorage.SnapshotStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class RelationStat(
    val relation: String,
    val count: Int,
    val averageConfidence: Double
)

/** Five equal-width confidence buckets covering [0.0, 1.0]:
 *  index 0 = [0.0, 0.2), ... index 4 = [0.8, 1.0]. */
const val CONFIDENCE_BUCKET_COUNT = 5

data class DiagnosticsSnapshot(
    val totalGrains: Int = 0,
    val factCount: Int = 0,
    val ruleCount: Int = 0,
    val hypothesisCount: Int = 0,
    val seedCount: Int = 0,
    val latticeCount: Int = 0,
    val dormantCount: Int = 0,
    val averageConfidence: Double = 0.0,
    val confidenceBuckets: List<Int> = List(CONFIDENCE_BUCKET_COUNT) { 0 },
    val relationStats: List<RelationStat> = emptyList()
)

/** The AI Engine Dashboard (app spec S9) -- every number here is a real
 *  read of StrataEngineProvider.engine's state, computed fresh on
 *  refresh(), not mocked. Started as a minimal stat-row stand-in; now
 *  also breaks the same numbers down by tier, type, confidence, and
 *  relation so the aggregate counts on Insights and the literal event
 *  feed on Learn have a middle ground between them. */
class DiagnosticsViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _snapshot = MutableStateFlow(DiagnosticsSnapshot())
    val snapshot: StateFlow<DiagnosticsSnapshot> = _snapshot

    init { refresh() }

    fun refresh() {
        val all = engine.allGrains()

        val buckets = MutableList(CONFIDENCE_BUCKET_COUNT) { 0 }
        for (g in all) {
            val idx = (g.confidence() * CONFIDENCE_BUCKET_COUNT).toInt().coerceIn(0, CONFIDENCE_BUCKET_COUNT - 1)
            buckets[idx] = buckets[idx] + 1
        }

        val relationStats = all.groupBy { it.relation }
            .map { (relation, grains) ->
                RelationStat(
                    relation = relation,
                    count = grains.size,
                    averageConfidence = grains.sumOf { it.confidence() } / grains.size
                )
            }
            .sortedByDescending { it.count }

        _snapshot.value = DiagnosticsSnapshot(
            totalGrains = all.size,
            factCount = all.count { it.type == GrainType.FACT },
            ruleCount = all.count { it.type == GrainType.RULE },
            hypothesisCount = all.count { it.type == GrainType.HYPOTHESIS },
            seedCount = all.count { it.tier == Tier.SEED },
            latticeCount = all.count { it.tier == Tier.LATTICE },
            dormantCount = all.count { it.tier == Tier.DORMANT },
            averageConfidence = if (all.isEmpty()) 0.0 else all.sumOf { it.confidence() } / all.size,
            confidenceBuckets = buckets,
            relationStats = relationStats
        )
    }

    fun resetMemory() {
        engine.resetAll()
        refresh()
        viewModelScope.launch(Dispatchers.IO) { SnapshotStore.save(engine.exportData()) }
    }
}
