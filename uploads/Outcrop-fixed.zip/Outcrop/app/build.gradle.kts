plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.outcrop.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.outcrop.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-skeleton"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Only the modules actually wired into navigation right now.
    // Every other module still builds independently — see settings.gradle.kts.
    implementation(project(":core:design-system"))
    implementation(project(":core:ai-engine"))
    implementation(project(":core:app-storage"))
    implementation(project(":core:background"))
    implementation(project(":feature:onboarding"))
    implementation(project(":feature:teach"))
    implementation(project(":feature:memory-explorer"))
    implementation(project(":feature:knowledge-graph"))
    implementation(project(":feature:diagnostics"))
    implementation(project(":feature:learning-dashboard"))
    implementation(project(":feature:discovery-center"))
    implementation(project(":feature:settings"))
    implementation(project(":feature:data-io"))

    implementation(libs.core.ktx)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.activity.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.foundation)
    implementation(libs.navigation.compose)
}
