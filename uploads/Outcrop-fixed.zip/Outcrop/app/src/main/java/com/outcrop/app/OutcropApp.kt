package com.outcrop.app

import android.app.Application

class OutcropApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Staged startup (Outcrop spec §8 Cold startup): heavy Strata
        // engine warmup deliberately does NOT happen here. The UI renders
        // an interactive shell first; engine init is kicked off async and
        // the UI observes readiness state. Not yet implemented in this
        // scaffold — this is where that sequencing would be wired in.
    }
}
