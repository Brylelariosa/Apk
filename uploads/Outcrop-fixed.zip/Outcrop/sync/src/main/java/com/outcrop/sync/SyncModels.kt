package com.outcrop.sync

import java.net.InetAddress

/** One other Outcrop instance found via NSD on the local network. */
data class SyncPeer(
    val name: String,
    val host: InetAddress,
    val port: Int
)

data class SyncResult(
    val received: Int,
    val newFacts: Int,
    val reinforced: Int,
    val disputed: Int
)
