package com.outcrop.sync

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.appstorage.SnapshotStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SyncUiState(
    val enabled: Boolean = false,
    val advertisedName: String? = null,
    val peers: List<SyncPeer> = emptyList(),
    val syncingPeerName: String? = null,
    val lastResult: SyncResult? = null,
    val lastResultPeerName: String? = null,
    val error: String? = null
)

class SyncViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine
    private var discovery: SyncDiscovery? = null
    private var server: SyncServer? = null

    private val _state = MutableStateFlow(SyncUiState())
    val state: StateFlow<SyncUiState> = _state

    /** Call once when the screen appears -- picks up the persisted
     *  enabled flag and starts advertising/discovering if it was already on. */
    fun start(context: Context) {
        val enabled = SyncPrefs(context).enabled
        _state.value = _state.value.copy(enabled = enabled)
        if (enabled) startNetworking(context)
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        SyncPrefs(context).enabled = enabled
        _state.value = _state.value.copy(enabled = enabled)
        if (enabled) startNetworking(context) else stopNetworking()
    }

    /** Call when the screen goes away. No foreground service backs this
     *  (see SyncScreen's doc), so advertising/listening only really
     *  exists while the screen is visible regardless of the persisted
     *  flag -- this stops the actual networking without touching that
     *  flag, so reopening the screen picks the toggle back up where the
     *  user left it. */
    fun pauseNetworking() {
        stopNetworking()
    }

    fun syncWith(context: Context, peer: SyncPeer) {
        if (_state.value.syncingPeerName != null) return
        _state.value = _state.value.copy(syncingPeerName = peer.name, error = null)
        viewModelScope.launch {
            try {
                val result = SyncClient.sync(peer, engine)
                _state.value = _state.value.copy(
                    syncingPeerName = null, lastResult = result, lastResultPeerName = peer.name
                )
                persist(context, peer.name)
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    syncingPeerName = null, error = "Sync with ${peer.name} failed: ${e.message}"
                )
            }
        }
    }

    private fun startNetworking(context: Context) {
        val d = SyncDiscovery(context)
        discovery = d
        val s = SyncServer(engine)
        server = s

        val port = s.start(viewModelScope) { result ->
            _state.value = _state.value.copy(lastResult = result, lastResultPeerName = "a nearby device")
            persist(context, "a nearby device")
        }
        d.startAdvertising(port)
        d.startDiscovery()

        viewModelScope.launch { d.peers.collect { peers -> _state.value = _state.value.copy(peers = peers) } }
        viewModelScope.launch {
            d.advertisedName.collect { name -> _state.value = _state.value.copy(advertisedName = name) }
        }
    }

    private fun stopNetworking() {
        discovery?.stopDiscovery()
        discovery?.stopAdvertising()
        discovery = null
        server?.stop()
        server = null
        _state.value = _state.value.copy(peers = emptyList(), advertisedName = null)
    }

    /** engine.exportData() runs on whatever dispatcher calls it -- Main
     *  here, same as every other engine touch in this app, since
     *  StrataStore isn't synchronized (see SyncTransfer's doc). Only the
     *  actual file write moves to IO. */
    private fun persist(context: Context, peerName: String) {
        val prefs = SyncPrefs(context)
        prefs.lastSyncAtMillis = System.currentTimeMillis()
        prefs.lastPeerName = peerName
        viewModelScope.launch {
            val text = engine.exportData()
            withContext(Dispatchers.IO) { SnapshotStore.save(text) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        stopNetworking()
    }
}
