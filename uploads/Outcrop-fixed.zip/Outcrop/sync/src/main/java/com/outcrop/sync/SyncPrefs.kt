package com.outcrop.sync

import android.content.Context

/** Off by default (app spec S1.10) -- a handful of scalars, same pattern
 *  as core/background's UndertowPrefs. */
internal class SyncPrefs(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    var lastSyncAtMillis: Long
        get() = prefs.getLong(KEY_LAST_SYNC_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_SYNC_AT, value).apply()

    var lastPeerName: String?
        get() = prefs.getString(KEY_LAST_PEER, null)
        set(value) = prefs.edit().putString(KEY_LAST_PEER, value).apply()

    private companion object {
        const val PREFS_NAME = "outcrop_sync"
        const val KEY_ENABLED = "enabled"
        const val KEY_LAST_SYNC_AT = "last_sync_at_millis"
        const val KEY_LAST_PEER = "last_peer_name"
    }
}
