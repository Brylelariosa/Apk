package com.outcrop.sync

import com.outcrop.core.aiengine.IngestResult
import com.outcrop.core.aiengine.StrataEngine
import com.outcrop.core.pluginapi.CsvExporterPlugin
import com.outcrop.core.pluginapi.CsvImporterPlugin
import com.outcrop.core.pluginapi.PluginTriple
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.ServerSocket
import java.net.Socket

/**
 * The wire format is just CSV over a socket, reusing core:plugin-api's
 * CsvExporterPlugin/CsvImporterPlugin rather than inventing a third
 * triple-serialization format alongside Data I/O's -- sync is really the
 * same "exchange (subject, relation, object) triples" problem Data I/O
 * already solves, just over a socket instead of a file.
 *
 * Protocol, one connection per exchange: the side that connected sends
 * its triples as CSV text, then half-closes its write side
 * (Socket.shutdownOutput()) to signal "done sending" -- no length
 * prefix or delimiter needed, a plain read-until-EOF on the other side
 * gets everything. The listener replies the same way and closes the
 * socket, which is what tells the connector its own read-until-EOF is
 * complete. Whichever side receives triples runs them through
 * StrataEngine.ingest() exactly like a manual Teach entry or a Data I/O
 * plugin import would -- new facts are learned, matching facts
 * reinforce, conflicting facts become disputes. Nothing is ever
 * silently overwritten.
 *
 * StrataEngine/StrataStore aren't synchronized (see Grain.kt / 
 * StrataStore.kt) and every other caller in this app touches them from
 * the main thread, so the actual engine reads/writes here are wrapped in
 * withContext(Dispatchers.Main) even though the socket I/O around them
 * runs on Dispatchers.IO -- keeps this from racing a Teach entry typed
 * mid-sync.
 */
internal object SyncTransfer {

    suspend fun outgoingPayload(engine: StrataEngine): String = withContext(Dispatchers.Main) {
        val triples = engine.allGrains().map { PluginTriple(it.subject, it.relation, it.obj) }
        CsvExporterPlugin.render(triples)
    }

    suspend fun applyIncomingPayload(engine: StrataEngine, text: String): SyncResult = withContext(Dispatchers.Main) {
        val triples = CsvImporterPlugin.parse(text)
        var created = 0
        var reinforced = 0
        var disputed = 0
        for (t in triples) {
            when (engine.ingest(t.subject, t.relation, t.obj)) {
                is IngestResult.Created -> created++
                is IngestResult.Reinforced -> reinforced++
                is IngestResult.Disputed -> disputed++
            }
        }
        SyncResult(received = triples.size, newFacts = created, reinforced = reinforced, disputed = disputed)
    }
}

/** Listens for incoming sync connections. One SyncServer per app process
 *  (started when the user enables Sync, stopped when they disable it). */
internal class SyncServer(private val engine: StrataEngine) {
    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null

    /** Binds to a system-assigned free port and starts accepting
     *  connections in the background. Returns the bound port, which the
     *  caller advertises via NSD. */
    fun start(scope: CoroutineScope, onSynced: (SyncResult) -> Unit): Int {
        val socket = ServerSocket(0)
        serverSocket = socket
        acceptJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                val client = try {
                    socket.accept()
                } catch (e: Exception) {
                    if (isActive) continue else break
                }
                try {
                    handleConnection(client, onSynced)
                } catch (e: Exception) {
                    // One bad exchange shouldn't take the listener down.
                }
            }
        }
        return socket.localPort
    }

    fun stop() {
        acceptJob?.cancel()
        acceptJob = null
        runCatching { serverSocket?.close() }
        serverSocket = null
    }

    private suspend fun handleConnection(socket: Socket, onSynced: (SyncResult) -> Unit) {
        socket.use {
            val incomingText = it.getInputStream().bufferedReader().readText()
            val result = SyncTransfer.applyIncomingPayload(engine, incomingText)

            val outgoingText = SyncTransfer.outgoingPayload(engine)
            it.getOutputStream().write(outgoingText.toByteArray())
            it.getOutputStream().flush()
            // socket.use{}'s close() on exit is what tells the connector's
            // read-until-EOF that this reply is complete.

            onSynced(result)
        }
    }
}

/** One outgoing sync, initiated by the user tapping a discovered peer. */
internal object SyncClient {
    suspend fun sync(peer: SyncPeer, engine: StrataEngine): SyncResult = withContext(Dispatchers.IO) {
        Socket(peer.host, peer.port).use { socket ->
            val outgoingText = SyncTransfer.outgoingPayload(engine)
            socket.getOutputStream().write(outgoingText.toByteArray())
            socket.getOutputStream().flush()
            socket.shutdownOutput()

            val incomingText = socket.getInputStream().bufferedReader().readText()
            SyncTransfer.applyIncomingPayload(engine, incomingText)
        }
    }
}
