package com.outcrop.sync

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

private const val SERVICE_TYPE = "_outcrop._tcp."

/**
 * Wraps Android's NsdManager (multicast-DNS / DNS-SD) for LAN-only peer
 * discovery -- advertise this device under SERVICE_TYPE, and find other
 * devices advertising the same. Nothing outside the local subnet is ever
 * contacted; NsdManager itself never leaves the local network.
 */
internal class SyncDiscovery(context: Context) {
    private val nsdManager = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager

    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    private val _peers = MutableStateFlow<List<SyncPeer>>(emptyList())
    val peers: StateFlow<List<SyncPeer>> = _peers

    private val _advertisedName = MutableStateFlow<String?>(null)
    val advertisedName: StateFlow<String?> = _advertisedName

    fun startAdvertising(port: Int) {
        stopAdvertising()
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = "Outcrop on ${Build.MODEL}"
            serviceType = SERVICE_TYPE
            setPort(port)
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                _advertisedName.value = info.serviceName
            }
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                _advertisedName.value = null
            }
            override fun onServiceUnregistered(info: NsdServiceInfo) {
                _advertisedName.value = null
            }
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) { /* nothing to clean up further */ }
        }
        registrationListener = listener
        nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    fun stopAdvertising() {
        registrationListener?.let { runCatching { nsdManager.unregisterService(it) } }
        registrationListener = null
        _advertisedName.value = null
    }

    fun startDiscovery() {
        stopDiscovery()
        _peers.value = emptyList()
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) { /* no-op */ }
            override fun onServiceFound(info: NsdServiceInfo) {
                val matchesType = info.serviceType.startsWith(SERVICE_TYPE.trimEnd('.'))
                if (matchesType && info.serviceName != _advertisedName.value) resolve(info)
            }
            override fun onServiceLost(info: NsdServiceInfo) {
                _peers.value = _peers.value.filterNot { it.name == info.serviceName }
            }
            override fun onDiscoveryStopped(serviceType: String) { /* no-op */ }
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                discoveryListener?.let { runCatching { nsdManager.stopServiceDiscovery(it) } }
                discoveryListener = null
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { /* nothing more to try */ }
        }
        discoveryListener = listener
        nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    fun stopDiscovery() {
        discoveryListener?.let { runCatching { nsdManager.stopServiceDiscovery(it) } }
        discoveryListener = null
    }

    private fun resolve(info: NsdServiceInfo) {
        nsdManager.resolveService(info, object : NsdManager.ResolveListener {
            override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) { /* peer just won't appear */ }
            override fun onServiceResolved(info: NsdServiceInfo) {
                val host = info.host ?: return
                val peer = SyncPeer(name = info.serviceName, host = host, port = info.port)
                _peers.value = _peers.value.filterNot { it.name == peer.name } + peer
            }
        })
    }
}
