package com.outcrop.sync

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.designsystem.OutcropPalette

/**
 * Sync (app spec S1.10): LAN-only, peer-to-peer, off by default. No
 * account, no server, no cloud -- two phones on the same WiFi discover
 * each other via NsdManager and exchange taught facts directly. Reached
 * from Settings, not the bottom nav, same as Data I/O.
 *
 * No foreground service backs this, so advertising/listening only
 * actually runs while this screen is on screen, regardless of the
 * persisted "enabled" preference -- that preference just controls
 * whether networking auto-starts the next time this screen opens, not
 * whether it keeps running once you navigate away.
 */
@Composable
fun SyncScreen(viewModel: SyncViewModel = viewModel()) {
    val context = LocalContext.current
    val state by viewModel.state.collectAsState()

    LaunchedEffect(Unit) { viewModel.start(context) }
    DisposableEffect(Unit) { onDispose { viewModel.pauseNetworking() } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        BasicText(text = "Sync")
        Spacer(modifier = Modifier.height(4.dp))
        BasicText(
            text = "Exchanges taught facts directly with another Outcrop device on the same " +
                "WiFi network. Nothing leaves the local network; there's no server."
        )
        Spacer(modifier = Modifier.height(12.dp))

        ToggleRow(
            label = "Enabled",
            checked = state.enabled,
            onToggle = { viewModel.setEnabled(context, !state.enabled) }
        )

        if (state.enabled) {
            Spacer(modifier = Modifier.height(8.dp))
            BasicText(
                text = state.advertisedName?.let { "Visible to nearby devices as \"$it\"." }
                    ?: "Starting up…"
            )

            Spacer(modifier = Modifier.height(20.dp))
            BasicText(text = "Nearby devices")
            Spacer(modifier = Modifier.height(6.dp))
            if (state.peers.isEmpty()) {
                BasicText(text = "None found yet. Make sure the other device also has Sync enabled.")
            } else {
                state.peers.forEach { peer ->
                    PeerRow(
                        name = peer.name,
                        busy = state.syncingPeerName == peer.name,
                        enabled = state.syncingPeerName == null,
                        onClick = { viewModel.syncWith(context, peer) }
                    )
                }
            }
        }

        state.lastResult?.let { result ->
            Spacer(modifier = Modifier.height(20.dp))
            BasicText(text = "Last sync -- with ${state.lastResultPeerName}")
            BasicText(
                text = "${result.received} record(s) received: ${result.newFacts} new, " +
                    "${result.reinforced} reinforced, ${result.disputed} disputed."
            )
        }

        state.error?.let { error ->
            Spacer(modifier = Modifier.height(12.dp))
            BasicText(text = error)
        }
    }
}

@Composable
private fun PeerRow(name: String, busy: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(OutcropPalette.StrataBand2)
            .clickable(enabled = enabled && !busy, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        BasicText(text = name)
        BasicText(text = if (busy) "Syncing…" else "Sync")
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .background(if (checked) OutcropPalette.StrataBand1 else OutcropPalette.StrataDark)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            BasicText(text = if (checked) "ON" else "OFF")
        }
        BasicText(text = label, modifier = Modifier.padding(start = 12.dp))
    }
}
