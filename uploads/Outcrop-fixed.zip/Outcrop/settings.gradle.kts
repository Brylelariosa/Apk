pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "Outcrop"

include(":app")

include(":core:design-system")
include(":core:ai-engine")
include(":core:ai-native")
include(":core:app-storage")
include(":core:background")
include(":core:plugin-api")

include(":feature:onboarding")
include(":feature:learn")
include(":feature:memory-explorer")
include(":feature:knowledge-graph")
include(":feature:discovery-center")
include(":feature:learning-dashboard")
include(":feature:diagnostics")
include(":feature:settings")
include(":feature:data-io")

include(":sync")
