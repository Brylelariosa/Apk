package com.outcrop.core.ainative

/**
 * Direct JNI surface — deliberately small (spec §1.4: minimize boundary
 * crossings). Only :core:ai-engine is meant to call this object.
 */
object StrataNative {
    init {
        System.loadLibrary("strata_native")
    }

    external fun nativeIngest(shardBatch: ByteArray): Boolean
    external fun nativeQuery(querySig: ByteArray, k: Int): ByteArray
    external fun nativeGetTelemetry(): ByteArray
}
