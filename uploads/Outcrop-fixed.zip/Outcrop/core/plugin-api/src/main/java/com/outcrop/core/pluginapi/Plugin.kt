package com.outcrop.core.pluginapi

// Placeholder module -- see app spec S1.7 (Plugin System).
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object Plugin
