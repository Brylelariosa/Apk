package com.outcrop.core.pluginapi

/** subject,relation,object per line. Quoted per RFC 4180 only when a
 *  field actually contains a comma, quote, or newline -- kept minimal on
 *  purpose, this is a built-in convenience format, not a general CSV
 *  library. */
private object CsvFormat {
    fun parse(text: String): List<PluginTriple> =
        text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .mapNotNull { line ->
                val fields = splitLine(line)
                if (fields.size >= 3) PluginTriple(fields[0], fields[1], fields[2]) else null
            }
            .toList()

    fun render(triples: List<PluginTriple>): String =
        triples.joinToString("\n") { "${field(it.subject)},${field(it.relation)},${field(it.obj)}" }

    private fun field(value: String): String =
        if (value.any { it == ',' || it == '"' || it == '\n' }) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else value

    private fun splitLine(line: String): List<String> {
        val fields = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                inQuotes && c == '"' && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"'); i++
                }
                c == '"' -> inQuotes = !inQuotes
                c == ',' && !inQuotes -> { fields.add(current.toString()); current.clear() }
                else -> current.append(c)
            }
            i++
        }
        fields.add(current.toString())
        return fields.map { it.trim() }
    }
}

object CsvImporterPlugin : ImporterPlugin {
    override val descriptor = PluginDescriptor(
        id = "builtin.csv.importer", kind = PluginKind.IMPORTER,
        displayName = "CSV", description = "subject,relation,object per line"
    )
    override fun parse(text: String): List<PluginTriple> = CsvFormat.parse(text)
}

object CsvExporterPlugin : ExporterPlugin {
    override val descriptor = PluginDescriptor(
        id = "builtin.csv.exporter", kind = PluginKind.EXPORTER,
        displayName = "CSV", description = "subject,relation,object per line"
    )
    override fun render(triples: List<PluginTriple>): String = CsvFormat.render(triples)
}
