package com.outcrop.core.designsystem

import androidx.compose.ui.graphics.Color

/**
 * Confidence is rendered on a fixed, wallpaper-independent scale so its
 * meaning never shifts with dynamic color (spec §3 Design Language,
 * §10 Accessibility strategy). Everything else may sample platform
 * dynamic color later; this scale deliberately never does.
 */
object OutcropConfidenceScale {
    val Low = Color(0xFFB5443B)
    val Mid = Color(0xFFC9A227)
    val High = Color(0xFF3E7C7A)
}

/** Placeholder static palette. Real version samples platform dynamic
 *  color (Android 12+) as a data source while keeping custom shapes —
 *  not implemented in this scaffold. */
object OutcropPalette {
    val StrataDark = Color(0xFF1B2530)
    val StrataBand1 = Color(0xFF3E7C7A)
    val StrataBand2 = Color(0xFF5FA39A)
    val StrataBand3 = Color(0xFF8FC7B8)
    val Surface = Color(0xFFF4F2ED)
}
