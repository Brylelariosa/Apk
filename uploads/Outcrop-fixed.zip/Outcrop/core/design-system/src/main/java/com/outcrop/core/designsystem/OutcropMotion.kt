package com.outcrop.core.designsystem

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring

/** Motion tokens from the Outcrop Design Language (spec §3) — spring
 *  physics throughout, never plain ease curves. */
object OutcropMotion {
    fun <T> defaultSpring() = spring<T>(
        dampingRatio = 0.7f,
        stiffness = Spring.StiffnessMedium
    )

    /** Deliberately springier — used for Knowledge Graph node settling
     *  (spec §4.3), where visible physics is the point, not a side effect. */
    fun <T> graphNodeSpring() = spring<T>(
        dampingRatio = 0.55f,
        stiffness = Spring.StiffnessLow
    )
}
