package com.outcrop.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Small, dependency-free chart primitives shared across feature screens
 * (AI Engine Dashboard, Knowledge Graph, ...) -- no charting library is
 * pulled in anywhere in this app; a proportional bar is just weighted
 * Boxes, and a legend is just colored swatches next to labels. Living
 * here in design-system rather than duplicated per-feature so every
 * screen's legend/bar looks and behaves identically.
 */

/** A single proportional bar split into weighted segments. Falls back to
 *  a flat neutral bar when every segment is empty, since Modifier.weight
 *  requires a positive value and there's nothing meaningful to show yet. */
@Composable
fun DistributionBar(segments: List<Pair<Int, Color>>, modifier: Modifier = Modifier) {
    val total = segments.sumOf { it.first }
    Row(modifier = modifier.fillMaxWidth().height(20.dp)) {
        if (total <= 0) {
            Box(modifier = Modifier.weight(1f).fillMaxHeight().background(OutcropPalette.StrataDark))
        } else {
            segments.forEach { (count, color) ->
                if (count > 0) {
                    Box(modifier = Modifier.weight(count.toFloat()).fillMaxHeight().background(color))
                }
            }
        }
    }
}

/** A row of "swatch + label" entries, wrapping onto the next line only in
 *  the sense that callers should keep the entry count small -- this is a
 *  single Row, not a flow layout. */
@Composable
fun LegendRow(entries: List<Pair<String, Color>>, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        entries.forEach { (label, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.width(10.dp).height(10.dp).background(color))
                BasicText(text = label, modifier = Modifier.padding(start = 4.dp))
            }
        }
    }
}
