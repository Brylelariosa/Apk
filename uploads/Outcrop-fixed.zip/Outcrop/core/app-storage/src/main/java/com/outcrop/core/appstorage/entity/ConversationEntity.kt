package com.outcrop.core.appstorage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val folderId: String?,
    val pinned: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val parentConversationId: String?,   // non-null only for a branch
    val branchPointMessageId: String?
)
