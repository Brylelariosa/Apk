package com.outcrop.core.appstorage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,                 // "user" | "assistant"
    val content: String,
    val createdAt: Long,
    val editedFromId: String?,
    // JSON array of Grain IDs used via Grain-Conditioned Prompting
    // (Strata V1 §16) — powers the reasoning-trace view (app spec §4.2).
    val grainsReferenced: String,
    // Set if the Simulation Engine (Strata V2 §4.8) contributed a
    // derived, not observed, conclusion to this answer.
    val simulationDepth: Int?
)
