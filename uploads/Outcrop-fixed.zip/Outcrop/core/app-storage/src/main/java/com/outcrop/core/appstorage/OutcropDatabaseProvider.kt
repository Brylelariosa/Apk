package com.outcrop.core.appstorage

import android.content.Context
import androidx.room.Room
import com.outcrop.core.appstorage.dao.PluginDao

/**
 * Shared OutcropDatabase instance, mirroring StrataEngineProvider's
 * pattern in core/ai-engine -- one instance for the whole app instead of
 * every screen's ViewModel building its own. Unlike StrataEngine, Room
 * needs a Context to build, so this can't just be a bare `by lazy { }`;
 * OutcropApp.onCreate() calls init(applicationContext) once at startup,
 * before anything touches .database.
 *
 * Consumers outside this module should go through the pluginDao() (etc.)
 * accessors below, not `.database` directly: OutcropDatabase extends
 * androidx.room.RoomDatabase, and Room is only an `implementation`
 * dependency here, not `api` -- so a feature module resolving
 * `.database`'s full type would need Room on its own compile classpath
 * too, for a type it never actually needs. Handing out plain DAO
 * interfaces (which don't extend anything Room-specific themselves)
 * keeps Room genuinely internal to this module.
 *
 * A proper DI setup (Hilt) is the natural next step here too, same as
 * noted on StrataEngineProvider -- this is the minimal thing that's
 * actually correct today, and the first real use of OutcropDatabase in
 * this codebase (the entities and DAOs existed; nothing had built the
 * database itself yet).
 */
object OutcropDatabaseProvider {
    @Volatile private var instance: OutcropDatabase? = null

    fun init(context: Context) {
        if (instance != null) return
        synchronized(this) {
            if (instance == null) {
                instance = Room.databaseBuilder(
                    context.applicationContext,
                    OutcropDatabase::class.java,
                    "outcrop.db"
                ).build()
            }
        }
    }

    private val database: OutcropDatabase
        get() = instance ?: error(
            "OutcropDatabaseProvider.init(context) must run before the database is used " +
                "-- OutcropApp.onCreate() is where that happens."
        )

    fun pluginDao(): PluginDao = database.pluginDao()
}
