package com.outcrop.core.appstorage

import androidx.room.Database
import androidx.room.RoomDatabase
import com.outcrop.core.appstorage.dao.ConversationDao
import com.outcrop.core.appstorage.dao.MessageDao
import com.outcrop.core.appstorage.dao.PluginDao
import com.outcrop.core.appstorage.entity.BackupMetadataEntity
import com.outcrop.core.appstorage.entity.ConversationEntity
import com.outcrop.core.appstorage.entity.FolderEntity
import com.outcrop.core.appstorage.entity.MessageEntity
import com.outcrop.core.appstorage.entity.PluginEntity

/**
 * App-layer conversation/UI storage ONLY (app spec §1.5). This is
 * deliberately NOT the Strata knowledge store — Grains live in Strata's
 * own mmap files (Strata V1 §6: Keystone / Lattice / Bedrock). Conflating
 * the two was explicitly flagged as a mistake to avoid during design —
 * Room is the right tool for relationally-queryable, non-performance-
 * critical data like this; it is deliberately absent from the Grain
 * substrate's hot path (Strata V2 §4.11).
 */
@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        FolderEntity::class,
        PluginEntity::class,
        BackupMetadataEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class OutcropDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun pluginDao(): PluginDao
}
