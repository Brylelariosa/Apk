package com.outcrop.core.aiengine

/**
 * A record of something StrataStore actually did. ingest/reinforce/
 * arbitrate/crystallize/weatherTick all append to this as a side effect,
 * so the Learning Dashboard is a literal rendering of real activity, not
 * a separately-computed summary (app spec S4.6).
 */
sealed class LearningEvent {
    abstract val timestamp: Long

    data class Learned(
        override val timestamp: Long, val subject: String, val relation: String,
        val obj: String, val confidence: Double
    ) : LearningEvent()

    data class Reinforced(
        override val timestamp: Long, val subject: String, val relation: String,
        val obj: String, val confidence: Double
    ) : LearningEvent()

    data class Disputed(
        override val timestamp: Long, val subject: String, val relation: String, val resolved: Boolean
    ) : LearningEvent()

    data class Crystallized(
        override val timestamp: Long, val relation: String, val obj: String,
        val fromInstances: Int, val confidence: Double
    ) : LearningEvent()

    data class WentDormant(
        override val timestamp: Long, val subject: String, val relation: String, val obj: String
    ) : LearningEvent()

    data class Hypothesized(
        override val timestamp: Long, val subject: String, val relation: String, val obj: String
    ) : LearningEvent()

    data class HypothesisConfirmed(
        override val timestamp: Long, val subject: String, val relation: String, val obj: String
    ) : LearningEvent()
}
