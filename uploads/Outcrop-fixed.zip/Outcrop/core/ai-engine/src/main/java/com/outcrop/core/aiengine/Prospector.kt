package com.outcrop.core.aiengine

/** Result of Prospector.parseQuestion: which piece of a (subject,
 *  relation, object) triple the question is asking about. */
sealed class QuestionQuery {
    /** "does/is X relation Y" -- both sides given, asking to confirm. */
    data class VerifyTriple(val subject: String, val relation: String, val obj: String) : QuestionQuery()
    /** "what does X relation" -- object is the unknown. */
    data class FindObject(val subject: String, val relation: String) : QuestionQuery()
    /** "who/what relation Y" -- subject is the unknown. */
    data class FindSubject(val relation: String, val obj: String) : QuestionQuery()
}

/** One extracted (subject, relation, object), plus whether it came from
 *  a vetted dictionary match or a morphological guess (see extract()'s
 *  doc on the guessed fallback). Callers should treat guessed=true as
 *  lower-confidence -- TeachViewModel ingests those at reduced authority
 *  and says so in the readout, rather than presenting a guess with the
 *  same certainty as a recognized verb. */
data class ExtractedFact(
    val subject: String,
    val relation: String,
    val obj: String,
    val guessed: Boolean = false
)

/**
 * Purely rule-based (no ML, no models, no learned weights) sentence-to-
 * triple extraction: tokenize, strip negation auxiliaries, find a known
 * verb phrase, subject is what comes before it, object is what comes
 * after it. Every decision here is a lookup, a spelling rule, or an
 * index comparison -- nothing statistical.
 *
 * The verb dictionary covers ~90 common predicates across preference,
 * location, relationship, possession/creation, and everyday action, each
 * registered under base/3rd-person/past-tense forms (regular verbs via
 * thirdPerson()/pastTense()'s spelling rules, irregulars via an explicit
 * override) so "chased", "visits", and "visited" all resolve without
 * needing every inflected form hand-typed. When nothing in that
 * dictionary matches, extract() falls back to a conservative
 * morphological guess (findLikelyVerb) rather than silently producing
 * nothing -- see its own doc for exactly how conservative.
 *
 * Known, honest limitations:
 *  - Compound sentences ("X likes Y and lives in Z") only extract the
 *    first clause when the second elides its subject -- fixing that needs
 *    real coreference resolution, out of scope for a non-AI extractor.
 *  - Ambiguous constructions ("I think X likes Y") can produce a noisy
 *    subject phrase rather than a wrong one -- verified deliberately, so
 *    a bad extraction looks obviously odd rather than confidently wrong.
 *  - The dictionary is closed-vocabulary by nature; the fallback guess
 *    widens coverage but will occasionally flag a plural noun as a verb
 *    ("the dogs bark" with "bark" unlisted might guess "dogs") -- that's
 *    exactly why guesses are flagged and ingested at reduced authority
 *    instead of treated like a dictionary match.
 *  - Progressive tense ("is playing") isn't specially handled -- "is"
 *    matches as the copula first, so "max is playing guitar" extracts as
 *    (max, is, playing guitar) rather than (max, plays, guitar).
 *  - Still no real grammar -- this is verb-position heuristics, not parsing.
 */
object Prospector {

    private fun thirdPerson(base: String): String = when {
        base.length > 1 && base.endsWith("y") && base[base.length - 2] !in "aeiou" ->
            base.dropLast(1) + "ies"
        base.endsWith("s") || base.endsWith("x") || base.endsWith("z") ||
            base.endsWith("ch") || base.endsWith("sh") -> base + "es"
        else -> base + "s"
    }

    private fun pastTense(base: String): String = when {
        base.endsWith("e") -> base + "d"
        base.length > 1 && base.endsWith("y") && base[base.length - 2] !in "aeiou" ->
            base.dropLast(1) + "ied"
        else -> base + "ed"
    }

    /** Registers a verb's base, 3rd-person, and past-tense forms under
     *  one canonical relation (the 3rd-person form, matching this
     *  dictionary's existing convention: "chases", "likes", "owns", ...).
     *  Pass irregularPast for verbs whose past tense doesn't follow the
     *  regular +ed/+d/+ied spelling rule ("buy" -> "bought", not "buyed"). */
    private fun MutableMap<String, String>.verb(base: String, irregularPast: String? = null) {
        val canonical = thirdPerson(base)
        put(base, canonical)
        put(canonical, canonical)
        put(irregularPast ?: pastTense(base), canonical)
    }

    /** Same idea for two-word "verb + particle" predicates ("live" + "in"
     *  -> livesIn), which is how this dictionary represents anything that
     *  needs its preposition to mean what it means ("works at" a company
     *  isn't "works"). Canonical relation is camelCase: livesIn, worksAt. */
    private fun MutableMap<String, String>.phrasal(base: String, particle: String, irregularPast: String? = null) {
        val thirdPersonBase = thirdPerson(base)
        val canonical = thirdPersonBase + particle.replaceFirstChar { it.uppercase() }
        val past = irregularPast ?: pastTense(base)
        put("$base $particle", canonical)
        put("$thirdPersonBase $particle", canonical)
        put("$past $particle", canonical)
    }

    private val verbDictionary: Map<String, String> = buildMap {
        // -- copula / possession --
        put("is", "is"); put("are", "is"); put("was", "is"); put("were", "is")
        put("has", "has"); put("have", "has"); put("had", "has") // "have" is 3rd-person-irregular too ("has", not "haves") -- verb() only overrides past tense, so this stays hand-written
        verb("own")
        verb("use")

        // -- preference / opinion --
        verb("like"); put("loves", "likes"); put("love", "likes"); put("loved", "likes")
        put("enjoys", "likes"); put("enjoy", "likes"); put("enjoyed", "likes")
        put("hates", "dislikes"); put("hate", "dislikes"); put("hated", "dislikes")
        verb("dislike")
        verb("prefer")
        verb("want")
        verb("need")
        verb("hope")
        verb("fear")
        verb("trust")
        verb("admire")
        verb("respect")
        verb("envy")
        verb("miss")
        verb("appreciate")
        verb("dread")
        phrasal("care", "about")
        phrasal("worry", "about")
        phrasal("believe", "in")
        // "X is interested in Y" is already covered by copula "is" treating
        // "interested in Y" as the object text -- no separate entry needed,
        // and "interested" doesn't have a real base-verb form to conjugate.

        // -- location / origin --
        put("lives in", "livesIn"); put("live in", "livesIn"); put("lived in", "livesIn")
        put("resides in", "livesIn"); put("reside in", "livesIn"); put("resided in", "livesIn")
        phrasal("work", "at")
        phrasal("work", "on")
        phrasal("work", "for")
        phrasal("study", "at")
        put("born in", "bornIn"); put("was born in", "bornIn")
        phrasal("grow", "up in", irregularPast = "grew up")
        phrasal("move", "to")
        phrasal("travel", "to")
        verb("visit")
        phrasal("locate", "in")
        phrasal("base", "in")

        // -- relationship --
        put("married to", "marriedTo"); put("marries", "marriedTo"); put("marry", "marriedTo"); put("married", "marriedTo")
        phrasal("friend", "with") // covers "friend/friends/friended with"
        phrasal("relate", "to")
        verb("know", irregularPast = "knew")
        verb("meet", irregularPast = "met")
        verb("date")
        verb("follow")
        verb("support")
        verb("oppose")
        phrasal("compete", "with")
        phrasal("collaborate", "with")
        phrasal("report", "to")
        verb("manage")
        verb("lead", irregularPast = "led")
        verb("join")
        phrasal("belong", "to")

        // -- creation / transaction --
        verb("build", irregularPast = "built")
        verb("make", irregularPast = "made")
        verb("create")
        verb("buy", irregularPast = "bought")
        verb("sell", irregularPast = "sold")
        verb("give", irregularPast = "gave")
        verb("borrow")
        verb("lend", irregularPast = "lent")
        verb("find", irregularPast = "found")
        verb("lose", irregularPast = "lost")
        verb("break", irregularPast = "broke")
        verb("fix")
        verb("write", irregularPast = "wrote")
        verb("draw", irregularPast = "drew")
        verb("paint")
        verb("design")
        verb("invent")
        put("founded", "founded") // present-tense "found" collides with find's past tense; past-only entry avoids that

        // -- everyday action --
        verb("chase")
        verb("play")
        verb("eat", irregularPast = "ate")
        verb("drink", irregularPast = "drank")
        verb("read", irregularPast = "read")
        verb("watch")
        phrasal("listen", "to")
        verb("teach", irregularPast = "taught")
        verb("learn")
        verb("study")
        verb("drive", irregularPast = "drove")
        verb("walk")
        verb("run", irregularPast = "ran")
        verb("swim", irregularPast = "swam")
        verb("cook")
        verb("clean")
        verb("sing", irregularPast = "sang")
        verb("dance")
        verb("call")
        verb("text")
        verb("email")
        verb("help")
        verb("hurt", irregularPast = "hurt")
        verb("avoid")
        verb("ignore")
        verb("catch", irregularPast = "caught")
        verb("throw", irregularPast = "threw")
        verb("carry", irregularPast = "carried")
        verb("hold", irregularPast = "held")
        verb("wear", irregularPast = "wore")
        verb("remember")
        verb("forget", irregularPast = "forgot")
        verb("understand", irregularPast = "understood")
        verb("explain")
        verb("describe")
        verb("discuss")
        verb("mention")
        verb("recommend")
        verb("suggest")
    }

    private val negatedForm = mapOf("likes" to "dislikes")
    private val stopwordLead = setOf("the", "a", "an")
    private val copulaRelations = setOf("is", "has")

    private val helperAux = setOf("does", "did", "do", "can", "will", "should")
    private val copulaAux = setOf("is", "are", "was", "were")
    private val whWords = setOf("who", "what", "when", "where", "why", "how", "which")

    private data class VerbMatch(val start: Int, val end: Int, val relation: String)

    private fun tokenize(text: String): Pair<List<String>, Boolean> {
        val cleaned = text.trim().replace(Regex("[.!?,]+$"), "")
        if (cleaned.isEmpty()) return emptyList<String>() to false

        val expanded = mutableListOf<String>()
        for (raw in cleaned.split(Regex("\\s+"))) {
            val lower = raw.lowercase()
            if (lower.endsWith("n't") && lower.length > 3) {
                expanded.add(lower.dropLast(3))
                expanded.add("n't")
            } else {
                expanded.add(lower)
            }
        }

        var negation = false
        val result = mutableListOf<String>()
        var i = 0
        while (i < expanded.size) {
            val tok = expanded[i]
            val next = expanded.getOrNull(i + 1)
            when {
                (tok == "do" || tok == "does" || tok == "did") && next == "n't" -> {
                    negation = true; i += 2
                }
                tok == "not" || tok == "never" -> {
                    negation = true; i += 1
                }
                else -> {
                    result.add(tok); i += 1
                }
            }
        }
        return result to negation
    }

    private fun findVerbPhrase(tokens: List<String>, from: Int): VerbMatch? {
        for (i in from until tokens.size) {
            if (i + 1 < tokens.size) {
                val twoWord = "${tokens[i]} ${tokens[i + 1]}"
                verbDictionary[twoWord]?.let { return VerbMatch(i, i + 2, it) }
            }
            verbDictionary[tokens[i]]?.let { return VerbMatch(i, i + 1, it) }
        }
        return null
    }

    /** Coarse, deliberately conservative morphological guess for when no
     *  dictionary verb matches anywhere in the sentence: the first token
     *  strictly between the first and last (so a subject and object both
     *  exist) that ends in "ed" or "s" the way a conjugated verb would.
     *  This will occasionally flag a plural noun instead of a real verb
     *  -- that's exactly why extract() marks results from here as
     *  guessed rather than presenting them like a dictionary match. */
    private fun findLikelyVerb(tokens: List<String>): Int? {
        if (tokens.size < 3) return null
        for (i in 1 until tokens.size - 1) {
            val t = tokens[i]
            if (t in stopwordLead) continue
            val looksVerby = (t.endsWith("ed") && t.length > 3) ||
                (t.endsWith("s") && !t.endsWith("ss") && t.length > 2)
            if (looksVerby) return i
        }
        return null
    }

    private fun join(tokens: List<String>, from: Int, to: Int): String =
        if (from >= to) "" else tokens.subList(from, to).joinToString(" ").trim()

    private fun stripLeadingArticle(tokens: List<String>, from: Int, to: Int): String {
        val start = if (from < to && tokens[from] in stopwordLead) from + 1 else from
        return join(tokens, start, to)
    }

    private fun extractOne(clause: String): ExtractedFact? {
        val (tokens, negation) = tokenize(clause)
        if (tokens.isEmpty()) return null

        // Case 1: "my X is/has Y" -> subject=user, relation=X, obj=Y.
        // Restricted to copula-like verbs -- "my dog chases squirrels" is
        // NOT the same shape as "my name is tom"; firing this for action
        // verbs produced wrong results during testing.
        if (tokens[0] == "my") {
            val m = findVerbPhrase(tokens, 1)
            if (m != null && m.start > 1 && m.relation in copulaRelations) {
                val relation = join(tokens, 1, m.start)
                val obj = join(tokens, m.end, tokens.size)
                if (relation.isNotEmpty() && obj.isNotEmpty()) return ExtractedFact("user", relation, obj)
            }
        }

        // Case 2: "I verb Y" -> subject=user, relation=verb, obj=Y. Verb
        // must sit immediately at index 1 (after negation-stripping) so
        // "I think tom likes kotlin" doesn't get misattributed to the user.
        if (tokens[0] == "i") {
            val m = findVerbPhrase(tokens, 1)
            if (m != null && m.start == 1) {
                val relation = if (negation) negatedForm[m.relation] ?: m.relation else m.relation
                val obj = join(tokens, m.end, tokens.size)
                if (obj.isNotEmpty()) return ExtractedFact("user", relation, obj)
            }
        }

        // Case 3: general "SUBJECT verb OBJECT" anywhere in the clause.
        val m = findVerbPhrase(tokens, 0)
        if (m != null && m.start > 0) {
            val relation = if (negation) negatedForm[m.relation] ?: m.relation else m.relation
            val subject = stripLeadingArticle(tokens, 0, m.start)
            val obj = join(tokens, m.end, tokens.size)
            if (subject.isNotEmpty() && obj.isNotEmpty()) return ExtractedFact(subject, relation, obj)
        }

        // Case 4: nothing in the dictionary matched anywhere -- fall back
        // to a morphological guess rather than silently extracting
        // nothing. See findLikelyVerb's doc for exactly how conservative
        // this is. Negation-stripping still applies since "n't"/"not"
        // was already removed from tokens by tokenize().
        val guessIndex = findLikelyVerb(tokens)
        if (guessIndex != null) {
            val relation = tokens[guessIndex]
            val subject = stripLeadingArticle(tokens, 0, guessIndex)
            val obj = join(tokens, guessIndex + 1, tokens.size)
            if (subject.isNotEmpty() && obj.isNotEmpty()) return ExtractedFact(subject, relation, obj, guessed = true)
        }

        return null
    }

    /** Splits on "and" so simple compound sentences can yield more than one
     *  fact -- a clause that elides its subject after "and" (very common in
     *  English) won't extract on its own; see the class doc. */
    fun extract(text: String): List<ExtractedFact> =
        text.split(Regex("(?i)\\s+and\\s+")).mapNotNull { extractOne(it) }

    /**
     * Same verb-position heuristics as extract(), pointed at question
     * shapes instead of statements. Recognizes:
     *  - "does/is X relation Y[?]"     -> VerifyTriple (yes/no lookup)
     *  - "what/who does X relation[?]" -> FindObject (what fills Y?)
     *  - "who/what relation Y[?]"      -> FindSubject (what fills X?)
     *
     * Deliberately does NOT use the Case 4 guess fallback -- a wrong
     * guess at what's being taught just produces an odd-looking grain
     * the user can see and correct; a wrong guess at what's being asked
     * would answer a question that wasn't actually asked, which is worse.
     * Compound questions, and questions needing an implicit preposition
     * ("where does tom work" -> the dictionary only has "works at"/"works
     * on", not bare "work"), come back null rather than a guess. Returning
     * null is the caller's signal to fall back to teaching this input as
     * a statement instead of trying to answer it.
     */
    fun parseQuestion(text: String): QuestionQuery? {
        val (tokens, _) = tokenize(text)
        if (tokens.isEmpty()) return null

        val questionish = text.trim().endsWith("?") ||
            tokens[0] in helperAux || tokens[0] in copulaAux || tokens[0] in whWords
        if (!questionish) return null

        var i = 0
        var hasWh = false
        if (tokens[i] in whWords) { hasWh = true; i++ }
        if (i < tokens.size && tokens[i] in helperAux) i++
        if (i >= tokens.size) return null

        val remainder = tokens.subList(i, tokens.size)

        // "is/are/was/were X Y" -- the copula IS the relation and sits
        // before the subject, not between subject and object like every
        // other verb in the dictionary.
        if (remainder[0] in copulaAux && remainder.size >= 3) {
            val subject = remainder[1]
            val obj = join(remainder, 2, remainder.size)
            if (subject.isNotEmpty() && obj.isNotEmpty()) return QuestionQuery.VerifyTriple(subject, "is", obj)
        }

        val m = findVerbPhrase(remainder, 0) ?: return null
        val subject = stripLeadingArticle(remainder, 0, m.start)
        val obj = join(remainder, m.end, remainder.size)

        return when {
            hasWh && subject.isEmpty() && obj.isNotEmpty() -> QuestionQuery.FindSubject(m.relation, obj)
            hasWh && subject.isNotEmpty() && obj.isEmpty() -> QuestionQuery.FindObject(subject, m.relation)
            subject.isNotEmpty() && obj.isNotEmpty() -> QuestionQuery.VerifyTriple(subject, m.relation, obj)
            else -> null
        }
    }
}
