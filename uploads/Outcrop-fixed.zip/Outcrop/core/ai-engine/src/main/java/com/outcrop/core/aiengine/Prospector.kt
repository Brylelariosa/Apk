package com.outcrop.core.aiengine

/**
 * Purely rule-based (no ML, no models, no learned weights) sentence-to-
 * triple extraction: tokenize, strip negation auxiliaries, find a known
 * verb phrase, subject is what comes before it, object is what comes
 * after it. Every decision here is a lookup or an index comparison --
 * nothing statistical.
 *
 * Verified as a Java port first, compiled and run outside Android (no
 * Kotlin toolchain was available to test this file directly) against 14
 * hand-picked cases including deliberately adversarial ones. This
 * translation preserves that verified behavior.
 *
 * Known, honest limitations:
 *  - Compound sentences ("X likes Y and lives in Z") only extract the
 *    first clause when the second elides its subject -- fixing that needs
 *    real coreference resolution, out of scope for a non-AI extractor.
 *  - Ambiguous constructions ("I think X likes Y") can produce a noisy
 *    subject phrase rather than a wrong one -- verified deliberately, so
 *    a bad extraction looks obviously odd rather than confidently wrong.
 *  - Still no real grammar -- this is verb-position heuristics, not parsing.
 */
object Prospector {

    private val verbDictionary = mapOf(
        "lives in" to "livesIn", "live in" to "livesIn", "lived in" to "livesIn",
        "resides in" to "livesIn",
        "works at" to "worksAt", "work at" to "worksAt",
        "works on" to "worksOn", "work on" to "worksOn",
        "likes" to "likes", "like" to "likes", "loves" to "likes", "love" to "likes",
        "enjoys" to "likes", "enjoy" to "likes",
        "chases" to "chases", "chase" to "chases",
        "is" to "is", "are" to "is", "was" to "is", "were" to "is",
        "has" to "has", "have" to "has",
        "owns" to "owns", "own" to "owns",
        "uses" to "uses", "use" to "uses",
        "hates" to "dislikes", "dislikes" to "dislikes", "dislike" to "dislikes",
        "prefers" to "prefers", "prefer" to "prefers",
        "needs" to "needs", "need" to "needs",
        "wants" to "wants", "want" to "wants",
        "knows" to "knows", "know" to "knows",
        "built" to "built", "build" to "built",
        "made" to "made", "created" to "created"
    )

    private val negatedForm = mapOf("likes" to "dislikes")
    private val stopwordLead = setOf("the", "a", "an")
    private val copulaRelations = setOf("is", "has")

    private data class VerbMatch(val start: Int, val end: Int, val relation: String)

    private fun tokenize(text: String): Pair<List<String>, Boolean> {
        val cleaned = text.trim().replace(Regex("[.!?,]+$"), "")
        if (cleaned.isEmpty()) return emptyList<String>() to false

        val expanded = mutableListOf<String>()
        for (raw in cleaned.split(Regex("\\s+"))) {
            val lower = raw.lowercase()
            if (lower.endsWith("n't") && lower.length > 3) {
                expanded.add(lower.dropLast(3))
                expanded.add("n't")
            } else {
                expanded.add(lower)
            }
        }

        var negation = false
        val result = mutableListOf<String>()
        var i = 0
        while (i < expanded.size) {
            val tok = expanded[i]
            val next = expanded.getOrNull(i + 1)
            when {
                (tok == "do" || tok == "does" || tok == "did") && next == "n't" -> {
                    negation = true; i += 2
                }
                tok == "not" || tok == "never" -> {
                    negation = true; i += 1
                }
                else -> {
                    result.add(tok); i += 1
                }
            }
        }
        return result to negation
    }

    private fun findVerbPhrase(tokens: List<String>, from: Int): VerbMatch? {
        for (i in from until tokens.size) {
            if (i + 1 < tokens.size) {
                val twoWord = "${tokens[i]} ${tokens[i + 1]}"
                verbDictionary[twoWord]?.let { return VerbMatch(i, i + 2, it) }
            }
            verbDictionary[tokens[i]]?.let { return VerbMatch(i, i + 1, it) }
        }
        return null
    }

    private fun join(tokens: List<String>, from: Int, to: Int): String =
        if (from >= to) "" else tokens.subList(from, to).joinToString(" ").trim()

    private fun stripLeadingArticle(tokens: List<String>, from: Int, to: Int): String {
        val start = if (from < to && tokens[from] in stopwordLead) from + 1 else from
        return join(tokens, start, to)
    }

    private fun extractOne(clause: String): Triple<String, String, String>? {
        val (tokens, negation) = tokenize(clause)
        if (tokens.isEmpty()) return null

        // Case 1: "my X is/has Y" -> subject=user, relation=X, obj=Y.
        // Restricted to copula-like verbs -- "my dog chases squirrels" is
        // NOT the same shape as "my name is tom"; firing this for action
        // verbs produced wrong results during testing.
        if (tokens[0] == "my") {
            val m = findVerbPhrase(tokens, 1)
            if (m != null && m.start > 1 && m.relation in copulaRelations) {
                val relation = join(tokens, 1, m.start)
                val obj = join(tokens, m.end, tokens.size)
                if (relation.isNotEmpty() && obj.isNotEmpty()) return Triple("user", relation, obj)
            }
        }

        // Case 2: "I verb Y" -> subject=user, relation=verb, obj=Y. Verb
        // must sit immediately at index 1 (after negation-stripping) so
        // "I think tom likes kotlin" doesn't get misattributed to the user.
        if (tokens[0] == "i") {
            val m = findVerbPhrase(tokens, 1)
            if (m != null && m.start == 1) {
                val relation = if (negation) negatedForm[m.relation] ?: m.relation else m.relation
                val obj = join(tokens, m.end, tokens.size)
                if (obj.isNotEmpty()) return Triple("user", relation, obj)
            }
        }

        // Case 3: general "SUBJECT verb OBJECT" anywhere in the clause.
        val m = findVerbPhrase(tokens, 0)
        if (m != null && m.start > 0) {
            val relation = if (negation) negatedForm[m.relation] ?: m.relation else m.relation
            val subject = stripLeadingArticle(tokens, 0, m.start)
            val obj = join(tokens, m.end, tokens.size)
            if (subject.isNotEmpty() && obj.isNotEmpty()) return Triple(subject, relation, obj)
        }

        return null
    }

    /** Splits on "and" so simple compound sentences can yield more than one
     *  fact -- a clause that elides its subject after "and" (very common in
     *  English) won't extract on its own; see the class doc. */
    fun extract(text: String): List<Triple<String, String, String>> =
        text.split(Regex("(?i)\\s+and\\s+")).mapNotNull { extractOne(it) }
}
