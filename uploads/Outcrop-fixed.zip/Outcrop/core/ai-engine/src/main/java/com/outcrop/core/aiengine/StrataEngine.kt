package com.outcrop.core.aiengine

/**
 * The single Kotlin gateway to Strata's logic (app spec S1.1 / S1.4).
 *
 * This now wraps a real, verified, in-process Kotlin implementation
 * (StrataStore/Resonance/Grain in this module) instead of the native JNI
 * bridge. :core:ai-native's placeholder JNI module still exists and still
 * compiles standalone -- reserved as the future target for porting the
 * hot paths (encode/similarity/ingest) to C++ once this reference
 * implementation has earned that. That's deliberate: this logic was
 * verified by compiling and running a Java port of it outside Android (no
 * Kotlin toolchain was available to test this file directly), and native
 * code is a much less forgiving place to carry an unverified translation
 * than the JVM is.
 */
class StrataEngine {
    private val store = StrataStore()

    fun ingest(subject: String, relation: String, obj: String, authorityWeight: Double = 1.0): IngestResult =
        store.ingest(subject, relation, obj, authorityWeight)

    fun query(text: String, k: Int = 5): List<Grain> = store.query(text, k)

    fun simulate(subject: String, relation: String): Grain? = store.simulate(subject, relation)

    fun crystallize(): List<Grain> = store.crystallize()

    fun recentEvents(limit: Int = 50): List<LearningEvent> = store.recentEvents(limit)

    var hypothesesEnabled: Boolean
        get() = store.hypothesesEnabled
        set(value) { store.hypothesesEnabled = value }

    fun exportData(): String = store.exportData()

    fun importData(text: String) = store.importData(text)

    fun weatherTick() = store.weatherTick()

    fun allGrains(): List<Grain> = store.allGrains()

    /** Clears every grain -- used by the Diagnostics screen's "reset memory"
     *  action, mainly useful for repeated demo/testing runs. */
    fun resetAll() = store.clear()


    fun telemetry(): EngineSnapshot {
        val all = store.allGrains()
        return EngineSnapshot(
            grainCount = all.size,
            ruleCount = all.count { it.type == GrainType.RULE },
            latticeCount = all.count { it.tier == Tier.LATTICE }
        )
    }
}

/** Backs the AI Engine Dashboard (app spec S9) once that screen exists. */
data class EngineSnapshot(val grainCount: Int, val ruleCount: Int, val latticeCount: Int)
