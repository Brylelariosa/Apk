plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.outcrop.core.aiengine"
    compileSdk = 36
    defaultConfig { minSdk = 26 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// No dependency on :core:ai-native. This module's logic is currently a
// real, verified, in-process Kotlin implementation -- see StrataEngine.kt.
// :core:ai-native's JNI bridge still exists and still compiles standalone,
// reserved as the future native-port target once this reference
// implementation earns that.
