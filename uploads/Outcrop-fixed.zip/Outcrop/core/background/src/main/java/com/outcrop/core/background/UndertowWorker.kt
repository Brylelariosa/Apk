package com.outcrop.core.background

import android.content.Context
import android.os.BatteryManager
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.appstorage.SnapshotStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * One Undertow tick. WorkManager may invoke this as often as every 15
 * minutes (its own platform minimum for periodic work), but weatherTick()
 * itself only ever actually runs once per calendar day here -- vitality
 * decay is `vitality *= exp(-rate * ageInDays)`, an absolute function of
 * elapsed days applied on top of whatever vitality already is, so calling
 * it twice in the same day would incorrectly double-decay. Everything
 * else this worker does (crystallize, snapshot save) is safe to repeat;
 * crystallize() already guards its own duplicate-rule case (see
 * StrataStore.kt), and saving is just re-writing the same or newer text.
 *
 * StrataEngine/StrataStore aren't synchronized, and every other caller
 * (Teach, Data I/O, Sync, Diagnostics) touches the shared
 * StrataEngineProvider.engine instance from the main thread -- so despite
 * this being a *background* worker, the actual engine reads/writes below
 * run on Dispatchers.Main to avoid racing something the user is doing at
 * the same moment. Only the SharedPreferences bookkeeping and the
 * snapshot file write happen off Main.
 */
class UndertowWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val prefs = UndertowPrefs(applicationContext)
        val forced = inputData.getBoolean(KEY_FORCE, false)
        if (!prefs.enabled && !forced) return Result.success()

        val effort = currentEffort(applicationContext)
        val engine = StrataEngineProvider.engine

        val changed = withContext(Dispatchers.Main) {
            var didChange = false

            val today = LocalDate.now().toEpochDay()
            if (today != prefs.lastTickedEpochDay) {
                engine.weatherTick()
                prefs.lastTickedEpochDay = today
                didChange = true
            }

            if (effort != UndertowEffort.MINIMAL) {
                val newRules = engine.crystallize()
                if (newRules.isNotEmpty()) didChange = true
                if (effort == UndertowEffort.FULL) {
                    // A charging device can afford a second pass to catch
                    // any rule that only became eligible because of the first.
                    if (engine.crystallize().isNotEmpty()) didChange = true
                }
            }

            didChange
        }

        if (changed || effort == UndertowEffort.FULL) {
            val text = withContext(Dispatchers.Main) { engine.exportData() }
            withContext(Dispatchers.IO) { SnapshotStore.save(text) }
        }

        prefs.lastRunAtMillis = System.currentTimeMillis()
        prefs.lastEffort = effort.name

        return Result.success()
    }

    /** FULL whenever charging (cost of running is basically free); on
     *  battery, STANDARD normally and MINIMAL under 20% -- skip the
     *  heavier crystallize() pass rather than compete with whatever the
     *  user is actually doing on a low battery. */
    private fun currentEffort(context: Context): UndertowEffort {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val level = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
        val isCharging = batteryManager?.isCharging ?: true
        return when {
            isCharging -> UndertowEffort.FULL
            level < 20 -> UndertowEffort.MINIMAL
            else -> UndertowEffort.STANDARD
        }
    }

    companion object {
        const val KEY_FORCE = "force"
    }
}
