package com.outcrop.core.background

// Placeholder module -- see app spec S1.6 (Graded Undertow Effort Levels).
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object UndertowScheduler
