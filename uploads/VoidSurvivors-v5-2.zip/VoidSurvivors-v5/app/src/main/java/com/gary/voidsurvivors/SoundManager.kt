package com.gary.voidsurvivors

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.*

/**
 * Synthesized audio engine — no asset files required.
 * Each sound is generated as PCM at 22 050 Hz, 16-bit mono.
 * Playback uses a fixed thread pool of 4 workers so multiple sounds
 * overlap without blocking the game thread.
 */
object SoundManager {

    enum class Sfx {
        SHOOT, HIT_ENEMY, PLAYER_HIT, XP_PICKUP,
        LEVEL_UP, BOSS_APPEAR, EXPLOSION,
        ABILITY_USE, UI_CLICK, CHEST_OPEN, STATUS_APPLY
    }

    private const val SR = 22050              // sample rate
    var sfxVolume  = 0.75f
    var musicVolume= 0.4f                     // reserved for future BGM
    var enabled    = true

    private val pool   = Executors.newFixedThreadPool(4)
    private val pcmMap = HashMap<Sfx, ShortArray>()

    // ─── Init / release ──────────────────────────────────────────

    fun init() {
        Sfx.values().forEach { pcmMap[it] = synthesize(it) }
    }

    fun release() {
        pool.shutdownNow()
        pcmMap.clear()
    }

    // ─── Play ────────────────────────────────────────────────────

    fun play(sfx: Sfx) {
        if (!enabled || sfxVolume <= 0f) return
        val data = pcmMap[sfx] ?: return
        val vol  = sfxVolume
        pool.submit {
            try {
                val minBuf = AudioTrack.getMinBufferSize(SR,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val bufSz  = maxOf(data.size * 2, minBuf)
                val attrs  = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val fmt    = AudioFormat.Builder()
                    .setSampleRate(SR)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
                val track  = AudioTrack(attrs, fmt, bufSz,
                    AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE)
                track.write(data, 0, data.size)
                track.setVolume(vol)
                track.play()
                // Wait for approximate playback duration then release
                Thread.sleep((data.size * 1000L / SR) + 80L)
                track.stop()
                track.release()
            } catch (_: Exception) { /* ignore on low-end devices */ }
        }
    }

    // ─── PCM synthesis ───────────────────────────────────────────

    private fun synthesize(sfx: Sfx): ShortArray = when (sfx) {
        Sfx.SHOOT        -> buildShoot()
        Sfx.HIT_ENEMY    -> buildHitEnemy()
        Sfx.PLAYER_HIT   -> buildPlayerHit()
        Sfx.XP_PICKUP    -> buildXpPickup()
        Sfx.LEVEL_UP     -> buildLevelUp()
        Sfx.BOSS_APPEAR  -> buildBossAppear()
        Sfx.EXPLOSION    -> buildExplosion()
        Sfx.ABILITY_USE  -> buildAbility()
        Sfx.UI_CLICK     -> buildClick()
        Sfx.CHEST_OPEN   -> buildChestOpen()
        Sfx.STATUS_APPLY -> buildStatusApply()
    }

    /** Quick square-wave chirp: 80 ms, 1 400 → 700 Hz */
    private fun buildShoot(): ShortArray {
        val n = SR * 80 / 1000
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val freq = 1400f - t * 9000f
            val amp  = 14000 * (1f - t * 12f).coerceIn(0f, 1f)
            val phase = freq * t
            (if ((phase % 1f) < 0.5f) amp else -amp).toInt().toShort()
        }
    }

    /** Low thud: 60 ms white-noise burst with fast decay */
    private fun buildHitEnemy(): ShortArray {
        val n   = SR * 60 / 1000
        val rng = java.util.Random(42)
        return ShortArray(n) { i ->
            val t   = i.toFloat() / SR
            val amp = 18000 * exp(-t * 50f)
            ((rng.nextGaussian() * amp).toInt().toShort())
        }
    }

    /** Deep thud + low sine: 220 ms */
    private fun buildPlayerHit(): ShortArray {
        val n   = SR * 220 / 1000
        val rng = java.util.Random(7)
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val amp  = 20000 * exp(-t * 18f)
            val sine = sin(2 * PI * 120.0 * t) * amp * 0.4
            val noise= rng.nextGaussian() * amp * 0.6
            ((sine + noise).toInt().toShort())
        }
    }

    /** Bright ascending sine sweep: 120 ms, 660 → 1320 Hz */
    private fun buildXpPickup(): ShortArray {
        val n = SR * 120 / 1000
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val freq = 660f + t * 5500f
            val amp  = 12000 * (1f - t * 8f).coerceIn(0f, 1f)
            (sin(2 * PI * freq * t) * amp).toInt().toShort()
        }
    }

    /** Major arpeggio C-E-G-C over 350 ms */
    private fun buildLevelUp(): ShortArray {
        val n      = SR * 350 / 1000
        val notes  = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f)
        val segLen = n / notes.size
        return ShortArray(n) { i ->
            val seg  = (i / segLen).coerceAtMost(notes.size - 1)
            val t    = (i % segLen).toFloat() / SR
            val freq = notes[seg]
            val fade = 1f - t * (1f / (segLen.toFloat() / SR))
            (sin(2 * PI * freq * t) * 16000 * fade.coerceIn(0f, 1f)).toInt().toShort()
        }
    }

    /** Low rumble + rising growl: 600 ms */
    private fun buildBossAppear(): ShortArray {
        val n   = SR * 600 / 1000
        val rng = java.util.Random(13)
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val freq = 55f + t * 60f
            val amp  = 20000 * (if (t < 0.3f) t / 0.3f else 1f - (t - 0.3f) / 0.7f).coerceIn(0f, 1f)
            val bass = sin(2 * PI * freq * t) * amp * 0.6
            val noise= rng.nextGaussian() * amp * 0.35
            ((bass + noise).toInt().toShort())
        }
    }

    /** Noise burst with low rumble: 400 ms */
    private fun buildExplosion(): ShortArray {
        val n   = SR * 400 / 1000
        val rng = java.util.Random(99)
        return ShortArray(n) { i ->
            val t   = i.toFloat() / SR
            val amp = 22000 * exp(-t * 12f)
            val low = sin(2 * PI * 80.0 * t) * amp * 0.4
            val noise = rng.nextGaussian() * amp * 0.6
            ((low + noise).toInt().toShort())
        }
    }

    /** Downward sweep + brief silence then click: 200 ms */
    private fun buildAbility(): ShortArray {
        val n = SR * 200 / 1000
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val freq = 1800f - t * 7000f
            val amp  = 16000 * (1f - t * 5f).coerceIn(0f, 1f)
            (sin(2 * PI * freq * t) * amp).toInt().toShort()
        }
    }

    /** Crisp click: 20 ms */
    private fun buildClick(): ShortArray {
        val n   = SR * 20 / 1000
        val rng = java.util.Random(3)
        return ShortArray(n) { i ->
            val t   = i.toFloat() / SR
            val amp = 14000 * exp(-t * 200f)
            ((rng.nextGaussian() * amp).toInt().toShort())
        }
    }

    /** Sparkling arpeggio + coins: 280 ms */
    private fun buildChestOpen(): ShortArray {
        val n     = SR * 280 / 1000
        val notes = floatArrayOf(880f, 1108f, 1318f, 1760f)
        val segLen= n / notes.size
        val rng   = java.util.Random(55)
        return ShortArray(n) { i ->
            val seg  = (i / segLen).coerceAtMost(notes.size - 1)
            val t    = (i % segLen).toFloat() / SR
            val freq = notes[seg]
            val fade = 1f - t * (1f / (segLen.toFloat() / SR))
            val sine = sin(2 * PI * freq * t) * 14000 * fade.coerceIn(0f, 1f)
            val click= rng.nextGaussian() * 3000 * exp(-t * 150.0)
            ((sine + click).toInt().toShort())
        }
    }

    /** Short crackling zap: 90 ms */
    private fun buildStatusApply(): ShortArray {
        val n   = SR * 90 / 1000
        val rng = java.util.Random(21)
        return ShortArray(n) { i ->
            val t    = i.toFloat() / SR
            val freq = 2200f + rng.nextFloat() * 800f
            val amp  = 12000 * exp(-t * 40f)
            val wave = if ((t * freq).toInt() % 2 == 0) amp else -amp
            (wave.toInt().toShort())
        }
    }

    // ─── Convenience wrappers ─────────────────────────────────────

    fun onShoot()       = play(Sfx.SHOOT)
    fun onHitEnemy()    = play(Sfx.HIT_ENEMY)
    fun onPlayerHit()   = play(Sfx.PLAYER_HIT)
    fun onXpPickup()    = play(Sfx.XP_PICKUP)
    fun onLevelUp()     = play(Sfx.LEVEL_UP)
    fun onBossAppear()  = play(Sfx.BOSS_APPEAR)
    fun onExplosion()   = play(Sfx.EXPLOSION)
    fun onAbility()     = play(Sfx.ABILITY_USE)
    fun onUiClick()     = play(Sfx.UI_CLICK)
    fun onChestOpen()   = play(Sfx.CHEST_OPEN)
    fun onStatus()      = play(Sfx.STATUS_APPLY)
}
