package com.gary.voidsurvivors

import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.os.*
import android.view.*
import kotlin.math.*
import kotlin.random.Random

// ════════════════════════════════════════════════════════════════
//  Persistent Settings
// ════════════════════════════════════════════════════════════════

data class GameSettings(
    var sfxVolume:     Float   = 0.75f,
    var musicVolume:   Float   = 0.40f,
    var vibration:     Boolean = true,
    var hudScale:      Float   = 1.0f,
    var quality:       Int     = 2,      // 1=Low 2=Med 3=High
    var joystickLeft:  Boolean = true,
    var showFps:       Boolean = false
)

// ════════════════════════════════════════════════════════════════
//  Achievement Toast
// ════════════════════════════════════════════════════════════════

class AchievementToast(val name: String, var life: Float = 3.5f, val maxLife: Float = 3.5f)

// ════════════════════════════════════════════════════════════════
//  Tutorial Step
// ════════════════════════════════════════════════════════════════

enum class TutorialStep {
    MOVE, SHOOT_AUTO, COLLECT_XP, LEVEL_UP_INFO, ABILITIES, DONE
}

// ════════════════════════════════════════════════════════════════
//  GameView
// ════════════════════════════════════════════════════════════════

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    // ─── World / state ────────────────────────────────────────────
    private var worldW = 1080f; private var worldH = 1920f
    private val state  = GameState(worldW, worldH)
    private val meta   = MetaUpgrades()

    // ─── Settings ─────────────────────────────────────────────────
    private val settings = GameSettings()
    private val prefs: SharedPreferences = context.getSharedPreferences("vs_prefs_v5", Context.MODE_PRIVATE)

    // ─── Thread ───────────────────────────────────────────────────
    private var gameThread: Thread? = null
    @Volatile private var running   = false
    private var lastTime = 0L

    // ─── Input ────────────────────────────────────────────────────
    private var moveX = 0f; private var moveY = 0f
    private var joyActive = false
    private var joyBaseX = 0f; private var joyBaseY = 0f
    private var joyDx    = 0f; private var joyDy    = 0f
    private val joyRadius = 130f
    private val joyPointerId = intArrayOf(-1)

    // Ability buttons: index = slot index in state.abilities
    private data class AbilityBtn(val cx: Float, val cy: Float, val r: Float, val idx: Int,
                                  var pressScale: Float = 1f)
    private val abilityBtns = mutableListOf<AbilityBtn>()

    // ─── UI overlays ──────────────────────────────────────────────
    private val toasts      = mutableListOf<AchievementToast>()
    private var tutorialStep: TutorialStep = TutorialStep.DONE
    private var tutorialTimer = 0f
    private var tutorialShown = false
    private var showCharSelect = false       // entry screen before first run
    private var selectedCharIdx = 0

    // Settings sliders
    private var draggingSlider = -1   // 0=sfx 1=music 2=hud
    private var sliderX = 0f

    // FPS counter
    private var fpsTimer  = 0f; private var fpsCount = 0; private var fpsDisplay = 0

    // Vibrator
    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    // ─── Paint pool ───────────────────────────────────────────────
    private val pMain   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pText   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pHud    = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBar    = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pShader = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rng     = Random.Default

    // Background star field (static)
    private data class Star(val x: Float, val y: Float, val r: Float, val bright: Float, val twinkle: Float)
    private val stars   = mutableListOf<Star>()
    private val stars2  = mutableListOf<Star>()  // parallax layer
    private var bgScrollY = 0f

    // Upgrade card press scales for animation
    private val cardScales = floatArrayOf(1f, 1f, 1f)
    // Prevent double-saving run stats on death
    private var runEndSaved = false

    // Meta screen button state
    private var metaBtns = listOf<RectF>()
    private var charBtns = listOf<RectF>()

    // ─── Init ────────────────────────────────────────────────────
    init {
        holder.addCallback(this)
        isFocusable = true
        loadSettings()
        loadMeta()
        SoundManager.sfxVolume  = settings.sfxVolume
        SoundManager.musicVolume= settings.musicVolume
        SoundManager.init()
        generateStars()
    }

    private fun generateStars() {
        repeat(120) { stars  += Star(rng.nextFloat()*worldW, rng.nextFloat()*worldH, 1f+rng.nextFloat()*1.5f, 0.3f+rng.nextFloat()*0.7f, rng.nextFloat()*3f) }
        repeat(50)  { stars2 += Star(rng.nextFloat()*worldW, rng.nextFloat()*worldH, 2f+rng.nextFloat()*3f,   0.5f+rng.nextFloat()*0.5f, rng.nextFloat()*2f+1f) }
    }

    // ─── Surface callbacks ───────────────────────────────────────

    override fun surfaceCreated(h: SurfaceHolder) {
        running = true; lastTime = System.nanoTime()
        gameThread = Thread(::gameLoop, "GameLoop").also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, fmt: Int, w: Int, h2: Int) {
        worldW = w.toFloat(); worldH = h2.toFloat()
        state.worldW = worldW; state.worldH = worldH
        layoutAbilityButtons()
        GameLogic.reset(state, meta)
        state.phase = Phase.CHARACTER_SELECT
        // Check tutorial
        if (!prefs.getBoolean("tutorial_done", false)) {
            tutorialShown = true
        }
    }

    override fun surfaceDestroyed(h: SurfaceHolder) { running = false }

    fun onPause()  { running = false }
    fun onResume() { if (holder.surface.isValid && !running) { running = true; lastTime = System.nanoTime(); gameThread = Thread(::gameLoop, "GameLoop").also { it.start() } } }
    fun onStop()   { running = false; SoundManager.release() }

    // ─── Game loop ───────────────────────────────────────────────

    private fun gameLoop() {
        while (running) {
            val now  = System.nanoTime()
            val dt   = ((now - lastTime) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            lastTime = now

            update(dt)

            val canvas = try { holder.lockCanvas() } catch (_: Exception) { null } ?: continue
            try { drawAll(canvas, dt) } finally { holder.unlockCanvasAndPost(canvas) }

            val elapsed = (System.nanoTime() - now) / 1_000_000L
            val budget  = if (settings.quality == 1) 33L else 16L
            if (elapsed < budget) Thread.sleep(budget - elapsed)
        }
    }

    // ─── Update ──────────────────────────────────────────────────

    private fun update(dt: Float) {
        // FPS
        fpsTimer += dt; fpsCount++
        if (fpsTimer >= 1f) { fpsDisplay = fpsCount; fpsCount = 0; fpsTimer = 0f }

        // Scroll background
        bgScrollY += dt * 20f
        if (bgScrollY > worldH) bgScrollY -= worldH

        when (state.phase) {
            Phase.PLAYING -> {
                GameLogic.update(state, dt, moveX, moveY)
                GameLogic.checkAchievements(state, meta)

                // Process new achievement notifications
                while (state.pendingAchievements.isNotEmpty()) {
                    toasts += AchievementToast(state.pendingAchievements.removeAt(0))
                    vibrate(40L)
                }

                // Phase transitions with sounds
                if (state.phase == Phase.LEVEL_UP) SoundManager.onLevelUp()
                if (state.phase == Phase.DEAD && !runEndSaved) {
                    runEndSaved = true
                    onRunEnd()
                    vibrate(200L)
                }

                // Tutorial step tracking
                if (tutorialShown && !prefs.getBoolean("tutorial_done", false)) {
                    updateTutorial(dt)
                }
            }
            Phase.LEVEL_UP, Phase.DEAD, Phase.PAUSED,
            Phase.SETTINGS, Phase.CHARACTER_SELECT -> { /* idle */ }
        }

        // Tick toasts
        val tIter = toasts.iterator()
        while (tIter.hasNext()) {
            val t = tIter.next(); t.life -= dt
            if (t.life <= 0f) tIter.remove()
        }
    }

    private fun onRunEnd() {
        meta.currency      += state.runCurrency
        meta.totalBossKills += state.stats.bossesKilled
        meta.totalStatusApplied += state.stats.statusApplied
        meta.totalRuns++
        val elapsed = state.elapsed.toInt()
        if (state.wave  > meta.bestWave) meta.bestWave = state.wave
        if (elapsed     > meta.bestTime) meta.bestTime  = elapsed
        saveMeta()
    }

    private fun updateTutorial(dt: Float) {
        tutorialTimer -= dt
        val p = state.player
        val step = when {
            state.elapsed < 4f  && (moveX == 0f && moveY == 0f) -> TutorialStep.MOVE
            state.elapsed < 8f  -> TutorialStep.SHOOT_AUTO
            state.elapsed < 14f && state.orbs.size < 3          -> TutorialStep.COLLECT_XP
            state.phase == Phase.LEVEL_UP                       -> TutorialStep.LEVEL_UP_INFO
            state.abilities.any { it.level > 0 }                -> TutorialStep.ABILITIES
            else                                                 -> TutorialStep.DONE
        }
        if (step != tutorialStep) { tutorialStep = step; tutorialTimer = 4f }
        if (step == TutorialStep.DONE) {
            prefs.edit().putBoolean("tutorial_done", true).apply()
            tutorialShown = false
        }
    }

    // ─── Layout buttons ──────────────────────────────────────────

    private fun layoutAbilityButtons() {
        abilityBtns.clear()
        val h   = settings.hudScale
        val sz  = 80f * h
        val gap = 12f * h
        val yRow1 = worldH - 100f * h
        val yRow2 = worldH - 200f * h
        val cols  = 3
        val startX = if (settings.joystickLeft) worldW - (sz + gap) * cols + gap
                     else 0f + gap

        // Row 1: abilities 0,1,2   Row 2: 3,4,5
        for (i in 0 until 6) {
            val col = i % cols
            val row = i / cols
            val cx = startX + col * (sz + gap) + sz / 2f
            val cy = if (row == 0) yRow1 else yRow2
            abilityBtns += AbilityBtn(cx, cy, sz / 2f, i)
        }
    }

    // ─── Touch ───────────────────────────────────────────────────

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action = ev.actionMasked
        val idx    = ev.actionIndex
        val pid    = ev.getPointerId(idx)
        val rx     = ev.getX(idx)
        val ry     = ev.getY(idx)

        // Settings / character-select screens: simple tap forwarding
        if (state.phase == Phase.SETTINGS) {
            handleSettingsTouch(action, rx, ry, pid); return true
        }
        if (state.phase == Phase.CHARACTER_SELECT) {
            handleCharSelectTouch(action, rx, ry); return true
        }
        if (state.phase == Phase.DEAD) {
            handleDeadTouch(action, rx, ry); return true
        }
        if (state.phase == Phase.PAUSED) {
            handlePauseTouch(action, rx, ry); return true
        }
        if (state.phase == Phase.LEVEL_UP) {
            handleLevelUpTouch(action, rx, ry); return true
        }

        // In-game touches
        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val joySide = if (settings.joystickLeft) rx < worldW * 0.55f else rx > worldW * 0.45f
                if (joySide && !joyActive) {
                    joyBaseX = rx; joyBaseY = ry; joyDx = 0f; joyDy = 0f
                    joyActive = true; joyPointerId[0] = pid
                } else {
                    // Check ability buttons
                    for (btn in abilityBtns) {
                        val dx = rx - btn.cx; val dy = ry - btn.cy
                        if (sqrt(dx*dx+dy*dy) <= btn.r + 20f) {
                            val ab = state.abilities.getOrNull(btn.idx)
                            if (ab != null) {
                                GameLogic.activateAbility(state, ab.id, moveX, moveY)
                                btn.pressScale = 0.85f
                                SoundManager.onAbility()
                                vibrate(15L)
                            }
                        }
                    }
                    // Pause button (top-right corner)
                    if (rx > worldW - 90f && ry < 100f) {
                        state.phase = Phase.PAUSED
                        SoundManager.onUiClick()
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) {
                    if (ev.getPointerId(i) == joyPointerId[0]) {
                        val x = ev.getX(i); val y = ev.getY(i)
                        joyDx = x - joyBaseX; joyDy = y - joyBaseY
                        val len = sqrt(joyDx*joyDx + joyDy*joyDy)
                        if (len > joyRadius) { joyDx = joyDx/len*joyRadius; joyDy = joyDy/len*joyRadius }
                        moveX = joyDx / joyRadius; moveY = joyDy / joyRadius
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pid == joyPointerId[0]) {
                    joyActive = false; joyPointerId[0] = -1
                    moveX = 0f; moveY = 0f; joyDx = 0f; joyDy = 0f
                }
            }
        }
        return true
    }

    private fun handleLevelUpTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val ups = state.pendingUpgrades; if (ups.isEmpty()) return
        val cardH = worldH * 0.24f; val cardW = worldW * 0.8f
        val startY = worldH * 0.28f; val gap = cardH + 18f
        for ((i, up) in ups.withIndex()) {
            val top = startY + i * gap
            if (ry in top..(top + cardH) && rx in (worldW*0.1f)..(worldW*0.9f)) {
                cardScales[i] = 0.92f
                GameLogic.applyUpgrade(state, up)
                SoundManager.onUiClick()
                vibrate(20L)
                return
            }
        }
    }

    private fun handlePauseTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx = worldW / 2f; val btnW = 340f; val btnH = 90f
        // Resume
        if (ry in (worldH*0.42f)..(worldH*0.42f+btnH) && rx in (cx-btnW/2)..(cx+btnW/2)) {
            state.phase = Phase.PLAYING; SoundManager.onUiClick()
        }
        // Settings
        if (ry in (worldH*0.54f)..(worldH*0.54f+btnH) && rx in (cx-btnW/2)..(cx+btnW/2)) {
            state.phase = Phase.SETTINGS; SoundManager.onUiClick()
        }
        // Quit
        if (ry in (worldH*0.66f)..(worldH*0.66f+btnH) && rx in (cx-btnW/2)..(cx+btnW/2)) {
            state.phase = Phase.DEAD; SoundManager.onUiClick()
        }
    }

    private fun handleDeadTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx = worldW / 2f; val btnW = 380f; val btnH = 90f
        // Retry
        if (ry in (worldH*0.79f)..(worldH*0.79f+btnH) && rx in (cx-btnW/2)..(cx+btnW/2)) {
            SoundManager.onUiClick()
            runEndSaved = false; GameLogic.reset(state, meta); return
        }
        // Character select
        if (ry in (worldH*0.87f)..(worldH*0.87f+btnH) && rx in (cx-btnW/2)..(cx+btnW/2)) {
            SoundManager.onUiClick()
            runEndSaved = false; state.phase = Phase.CHARACTER_SELECT; return
        }
    }

    private fun handleCharSelectTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx = worldW / 2f
        val cardW = worldW * 0.78f; val cardH = worldH * 0.14f
        val startY = worldH * 0.24f; val gap = cardH + 14f
        for ((i, def) in Characters.ALL.withIndex()) {
            val top = startY + i * gap
            if (ry in top..(top+cardH) && rx in (cx-cardW/2)..(cx+cardW/2)) {
                if (meta.isCharUnlocked(def.type)) {
                    selectedCharIdx = i
                    meta.selectedCharacter = def.type
                    SoundManager.onUiClick()
                }
                return
            }
        }
        // Permanent upgrade purchases
        val metaY2 = startY + Characters.ALL.size * gap + 16f
        val metaCardH2 = 110f; val metaCardW2 = worldW*0.78f
        val metaBtnW = metaCardW2 / 4f - 12f; val metaBtnH = 70f
        for (i in 0 until 4) {
            val bx = cx - metaCardW2/2f + 8f + i*(metaBtnW+12f)
            val by = metaY2 + 52f
            if (ry in by..(by+metaBtnH) && rx in bx..(bx+metaBtnW)) {
                when (i) {
                    0 -> if (meta.currency >= meta.costHp())    { meta.currency -= meta.costHp();    meta.hpLevel++ }
                    1 -> if (meta.currency >= meta.costSpeed())  { meta.currency -= meta.costSpeed(); meta.speedLevel++ }
                    2 -> if (meta.currency >= meta.costCdr())    { meta.currency -= meta.costCdr();   meta.cdrLevel++ }
                    3 -> if (meta.currency >= meta.costXp())     { meta.currency -= meta.costXp();    meta.xpLevel++ }
                }
                SoundManager.onUiClick(); saveMeta(); return
            }
        }

        // Start button
        val metaCardH3 = 150f
        val startBtnTop = startY + Characters.ALL.size * gap + 16f + metaCardH3 + 22f
        if (ry in startBtnTop..(startBtnTop+100f) && rx in (cx-200f)..(cx+200f)) {
            SoundManager.onUiClick()
            runEndSaved = false; GameLogic.reset(state, meta)
            state.phase = Phase.PLAYING
            if (tutorialShown) { tutorialStep = TutorialStep.MOVE; tutorialTimer = 5f }
        }
    }

    private fun handleSettingsTouch(action: Int, rx: Float, ry: Float, pid: Int) {
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            val cx = worldW/2f; val sliderW = worldW*0.6f
            val sliderLeft = cx - sliderW/2f; val sliderRight = cx + sliderW/2f
            fun sliderVal(ry2: Float, yTarget: Float): Boolean {
                if (abs(ry2 - yTarget) < 45f && rx in sliderLeft..sliderRight) {
                    return true
                }
                return false
            }
            val ySfx   = worldH * 0.38f; val yMusic = worldH * 0.50f; val yHud = worldH * 0.62f
            if (sliderVal(ry, ySfx)) {
                settings.sfxVolume    = ((rx - sliderLeft) / sliderW).coerceIn(0f,1f)
                SoundManager.sfxVolume = settings.sfxVolume; saveSettings()
            }
            if (sliderVal(ry, yMusic)) {
                settings.musicVolume   = ((rx - sliderLeft) / sliderW).coerceIn(0f,1f)
                SoundManager.musicVolume = settings.musicVolume; saveSettings()
            }
            if (sliderVal(ry, yHud)) {
                settings.hudScale = (0.7f + ((rx - sliderLeft) / sliderW) * 0.9f).coerceIn(0.7f,1.6f)
                layoutAbilityButtons(); saveSettings()
            }
        }
        if (action == MotionEvent.ACTION_DOWN) {
            val cx = worldW/2f
            // Vibration toggle
            val vibY = worldH * 0.72f
            if (abs(ry - vibY) < 40f) {
                settings.vibration = !settings.vibration; SoundManager.onUiClick(); saveSettings()
            }
            // Quality toggle
            val qualY = worldH * 0.80f
            if (abs(ry - qualY) < 40f && rx in (cx-200f)..(cx+200f)) {
                settings.quality = (settings.quality % 3) + 1; SoundManager.onUiClick(); saveSettings()
            }
            // Show FPS toggle
            val fpsY = worldH * 0.86f
            if (abs(ry - fpsY) < 40f) {
                settings.showFps = !settings.showFps; SoundManager.onUiClick(); saveSettings()
            }
            // Joystick side toggle
            val joyY = worldH * 0.92f
            if (abs(ry - joyY) < 40f) {
                settings.joystickLeft = !settings.joystickLeft
                layoutAbilityButtons(); SoundManager.onUiClick(); saveSettings()
            }
            // Back
            if (ry < 120f && rx < 180f) {
                state.phase = if (state.kills > 0) Phase.PAUSED else Phase.CHARACTER_SELECT
                SoundManager.onUiClick()
            }
        }
    }

    // ─── Draw all ────────────────────────────────────────────────

    private fun drawAll(c: Canvas, dt: Float) {
        // Animate ability press scales
        for (btn in abilityBtns) {
            if (btn.pressScale < 1f) btn.pressScale = minOf(1f, btn.pressScale + dt * 10f)
        }

        when (state.phase) {
            Phase.CHARACTER_SELECT -> drawCharacterSelect(c)
            Phase.SETTINGS         -> drawSettings(c)
            Phase.PLAYING, Phase.LEVEL_UP, Phase.PAUSED, Phase.DEAD -> {
                val shake = if (state.shakeTimer > 0f) state.shakeAmt * (state.shakeTimer / 0.5f).coerceIn(0f,1f) else 0f
                val sx = if (shake > 0f) (rng.nextFloat()-0.5f) * shake else 0f
                val sy = if (shake > 0f) (rng.nextFloat()-0.5f) * shake else 0f

                if (shake > 0f) c.save()
                if (shake > 0f) c.translate(sx, sy)

                drawBackground(c)
                drawGameObjects(c)
                drawHUD(c)

                if (shake > 0f) c.restore()

                if (state.phase == Phase.LEVEL_UP)         drawLevelUp(c)
                if (state.phase == Phase.PAUSED)           drawPause(c)
                if (state.phase == Phase.DEAD)             drawDead(c)

                drawToasts(c)
                drawTutorialOverlay(c)
                drawBossWarning(c)
                drawEventAnnouncement(c)
                if (settings.showFps) drawFps(c)
            }
        }
    }

    // ─── Background ──────────────────────────────────────────────

    private fun drawBackground(c: Canvas) {
        c.drawColor(0xFF070A14.toInt())

        val time = state.elapsed
        // Subtle hex-grid overlay based on quality setting
        if (settings.quality >= 2) {
            pMain.color = 0x08445588
            pMain.style = Paint.Style.STROKE
            pMain.strokeWidth = 1f
            val grid = 80f
            var gx = 0f
            while (gx < worldW + grid) {
                c.drawLine(gx, 0f, gx, worldH, pMain); gx += grid
            }
            var gy = 0f
            while (gy < worldH + grid) {
                c.drawLine(0f, gy, worldW, gy, pMain); gy += grid
            }
        }

        // Time-slow tint
        if (state.timeSlowActive) {
            pMain.color = 0x22006688; pMain.style = Paint.Style.FILL
            c.drawRect(0f, 0f, worldW, worldH, pMain)
        }

        // Stars layer 1 (fast)
        pMain.style = Paint.Style.FILL
        for (s in stars) {
            val yy = ((s.y + bgScrollY * 0.6f) % worldH + worldH) % worldH
            val tw = 0.65f + 0.35f * sin(time * s.twinkle)
            pMain.color = (((tw * s.bright * 200f).toInt() shl 24) or 0xAABBFF) and 0xFFFFFFFF.toInt()
            c.drawCircle(s.x, yy, s.r, pMain)
        }
        // Stars layer 2 (slow)
        for (s in stars2) {
            val yy = ((s.y + bgScrollY * 0.2f) % worldH + worldH) % worldH
            val tw = 0.7f + 0.3f * sin(time * s.twinkle + 1.3f)
            pMain.color = (((tw * s.bright * 160f).toInt() shl 24) or 0xCCEEFF) and 0xFFFFFFFF.toInt()
            c.drawCircle(s.x, yy, s.r, pMain)
        }

        // Darkness event vignette
        if (state.currentEvent == EventType.DARKNESS) {
            val rr = RadialGradient(worldW/2f, worldH/2f, worldW*0.35f,
                intArrayOf(0x00000000, 0xDD000000.toInt()), floatArrayOf(0f,1f), Shader.TileMode.CLAMP)
            pShader.shader = rr; pShader.style = Paint.Style.FILL
            c.drawRect(0f, 0f, worldW, worldH, pShader)
            pShader.shader = null
        }
    }

    // ─── Game objects ─────────────────────────────────────────────

    private fun drawGameObjects(c: Canvas) {
        val time = state.elapsed
        drawChests(c, time)
        drawBlackHoles(c, time)
        drawXpOrbs(c, time)
        drawParticles(c)
        drawEnemies(c, time)
        drawPlayer(c, time)
        drawBullets(c)
        drawFloatTexts(c)
    }

    private fun drawChests(c: Canvas, time: Float) {
        for (ch in state.chests) {
            val bob = sin(ch.bobTimer * 2.5f) * 5f
            val y   = ch.y + bob
            // Glow
            pMain.color = 0x55FFCC00; pMain.style = Paint.Style.FILL
            c.drawCircle(ch.x, y, ch.radius * 1.8f + sin(time*3f)*3f, pMain)
            // Body
            pMain.color = 0xFF8B5A00.toInt(); pMain.style = Paint.Style.FILL
            val rect = RectF(ch.x-ch.radius, y-ch.radius*0.8f, ch.x+ch.radius, y+ch.radius*0.8f)
            c.drawRoundRect(rect, 6f, 6f, pMain)
            // Lid
            pMain.color = 0xFFA0722A.toInt()
            val lid = RectF(ch.x-ch.radius, y-ch.radius*0.8f, ch.x+ch.radius, y-ch.radius*0.1f)
            c.drawRoundRect(lid, 6f, 6f, pMain)
            // Clasp
            pMain.color = 0xFFFFD700.toInt()
            c.drawCircle(ch.x, y, 6f, pMain)
            // Label
            pText.color = 0xFFFFEE88.toInt(); pText.textSize = 22f
            pText.textAlign = Paint.Align.CENTER
            c.drawText("CHEST", ch.x, y - ch.radius - 10f, pText)
        }
    }

    private fun drawBlackHoles(c: Canvas, time: Float) {
        for (bh in state.blackHoles) {
            val progress = 1f - bh.life / bh.maxLife
            val pulse    = sin(time * 12f) * 5f
            val r        = RadialGradient(bh.x, bh.y, bh.radius + pulse,
                intArrayOf(0xFF330066.toInt(), 0x66660099, 0x00000000),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            pShader.shader = r; pShader.style = Paint.Style.FILL
            c.drawCircle(bh.x, bh.y, bh.radius + pulse, pShader)
            pShader.shader = null
            // Core
            pMain.color = 0xFF9900FF.toInt(); pMain.style = Paint.Style.FILL
            c.drawCircle(bh.x, bh.y, 14f + pulse*0.3f, pMain)
        }
    }

    private fun drawXpOrbs(c: Canvas, time: Float) {
        val pulse = sin(time * 5f) * 2f
        pMain.style = Paint.Style.FILL
        for (orb in state.orbs) {
            pMain.color = 0x4400FFAA; c.drawCircle(orb.x, orb.y, orb.radius + 4f + pulse, pMain)
            pMain.color = 0xFF00FFAA.toInt(); c.drawCircle(orb.x, orb.y, orb.radius + pulse*0.5f, pMain)
            pMain.color = 0xFFAAFFDD.toInt(); c.drawCircle(orb.x, orb.y, orb.radius * 0.4f, pMain)
        }
    }

    private fun drawParticles(c: Canvas) {
        pMain.style = Paint.Style.FILL
        for (pt in state.particles) {
            if (!pt.active) continue
            val alpha = (pt.life / pt.maxLife * 255f).toInt().coerceIn(0, 255)
            val col   = (pt.color and 0x00FFFFFF) or (alpha shl 24)
            pMain.color = col
            c.drawCircle(pt.x, pt.y, pt.radius * (pt.life / pt.maxLife), pMain)
        }
    }

    private fun drawEnemies(c: Canvas, time: Float) {
        pMain.style = Paint.Style.FILL
        for (e in state.enemies) {
            if (e.hp <= 0f) continue
            val flashing  = e.flashTimer > 0f
            val baseColor = enemyColor(e.type)

            // Status effect tints
            val tintedColor = when {
                e.statusEffects.any { it.type == StatusEffectType.FREEZE } -> blendColors(baseColor, 0xFF88DDFF.toInt(), 0.5f)
                e.statusEffects.any { it.type == StatusEffectType.BURN   } -> blendColors(baseColor, 0xFFFF4400.toInt(), 0.4f)
                e.statusEffects.any { it.type == StatusEffectType.SHOCK  } -> blendColors(baseColor, 0xFFFFFF44.toInt(), 0.4f)
                else -> baseColor
            }

            pMain.color = if (flashing) 0xFFFFFFFF.toInt() else tintedColor

            // Shadow (quality >= 2)
            if (settings.quality >= 2) {
                pMain.color = 0x33000000
                c.drawCircle(e.x + 4f, e.y + 4f, e.radius, pMain)
                pMain.color = if (flashing) 0xFFFFFFFF.toInt() else tintedColor
            }

            // Body
            when (e.type) {
                EnemyType.BOSS -> {
                    // Multi-ring boss
                    c.drawCircle(e.x, e.y, e.radius * 1.2f, pMain)
                    pMain.color = if (e.bossPhase >= 2) 0xFFFF4400.toInt() else 0xFFAA0000.toInt()
                    c.drawCircle(e.x, e.y, e.radius * 0.7f, pMain)
                    pMain.color = 0xFFFFFFFF.toInt(); c.drawCircle(e.x, e.y, e.radius * 0.25f, pMain)
                    // Spikes
                    pMain.color = tintedColor; pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 3f
                    repeat(8) { i ->
                        val a = i * (2f * PI.toFloat() / 8f) + time * 1.2f
                        val x1 = e.x + cos(a) * e.radius; val y1 = e.y + sin(a) * e.radius
                        val x2 = e.x + cos(a) * (e.radius*1.5f); val y2 = e.y + sin(a) * (e.radius*1.5f)
                        c.drawLine(x1, y1, x2, y2, pMain)
                    }
                    pMain.style = Paint.Style.FILL
                }
                EnemyType.ELITE -> {
                    c.drawCircle(e.x, e.y, e.radius, pMain)
                    pMain.color = 0xAAFFD700.toInt()
                    pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 4f
                    c.drawCircle(e.x, e.y, e.radius + 5f + sin(time*4f)*2f, pMain)
                    pMain.style = Paint.Style.FILL
                }
                EnemyType.TANK -> {
                    val r = RectF(e.x-e.radius, e.y-e.radius*0.8f, e.x+e.radius, e.y+e.radius*0.8f)
                    c.drawRoundRect(r, 8f, 8f, pMain)
                }
                EnemyType.FAST -> {
                    // Triangle pointing toward player
                    val p2 = state.player
                    val a  = atan2(p2.y - e.y, p2.x - e.x)
                    val path = Path()
                    path.moveTo(e.x + cos(a)*e.radius, e.y + sin(a)*e.radius)
                    path.lineTo(e.x + cos(a+2.5f)*e.radius*0.7f, e.y + sin(a+2.5f)*e.radius*0.7f)
                    path.lineTo(e.x + cos(a-2.5f)*e.radius*0.7f, e.y + sin(a-2.5f)*e.radius*0.7f)
                    path.close(); c.drawPath(path, pMain)
                }
                EnemyType.SHIELD_ENEMY -> {
                    c.drawCircle(e.x, e.y, e.radius, pMain)
                    if (!e.shieldBroken) {
                        pMain.color = 0x880088FF.toInt()
                        pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 5f
                        c.drawCircle(e.x, e.y, e.radius + 8f + sin(time*3f)*2f, pMain)
                        pMain.style = Paint.Style.FILL
                    }
                }
                EnemyType.EXPLODER -> {
                    c.drawCircle(e.x, e.y, e.radius, pMain)
                    pMain.color = 0x88FF8800.toInt()
                    c.drawCircle(e.x, e.y, e.radius * (0.8f + sin(time*8f)*0.2f), pMain)
                }
                else -> c.drawCircle(e.x, e.y, e.radius, pMain)
            }

            // Status effect icon overlays
            drawStatusIcons(c, e)

            // HP bar above enemy
            val barW = e.radius * 2f; val barH = 5f
            val bx   = e.x - e.radius; val by = e.y - e.radius - 12f
            pBar.color = 0xFF330000.toInt(); pBar.style = Paint.Style.FILL
            c.drawRect(bx, by, bx+barW, by+barH, pBar)
            val hpFrac = (e.hp / e.maxHp).coerceIn(0f,1f)
            pBar.color = when { hpFrac > 0.6f -> 0xFF22CC44.toInt(); hpFrac > 0.3f -> 0xFFEEAA00.toInt(); else -> 0xFFCC2222.toInt() }
            c.drawRect(bx, by, bx+barW*hpFrac, by+barH, pBar)

            // Shield HP bar
            if (e.type == EnemyType.SHIELD_ENEMY && !e.shieldBroken && e.maxShieldHp > 0f) {
                val sy2 = by - barH - 3f
                pBar.color = 0xFF003388.toInt(); c.drawRect(bx, sy2, bx+barW, sy2+barH, pBar)
                pBar.color = 0xFF0088FF.toInt(); c.drawRect(bx, sy2, bx+barW*(e.shieldHp/e.maxShieldHp).coerceIn(0f,1f), sy2+barH, pBar)
            }
        }
    }

    private fun drawStatusIcons(c: Canvas, e: Enemy) {
        if (e.statusEffects.isEmpty()) return
        var iconX = e.x - e.statusEffects.size * 9f
        pText.textSize = 18f; pText.textAlign = Paint.Align.CENTER
        for (eff in e.statusEffects) {
            val icon = when (eff.type) {
                StatusEffectType.BURN   -> "F"
                StatusEffectType.POISON -> "P"
                StatusEffectType.FREEZE -> "Z"
                StatusEffectType.SHOCK  -> "S"
                StatusEffectType.BLEED  -> "B"
            }
            pText.color = when (eff.type) {
                StatusEffectType.BURN   -> 0xFFFF5500.toInt()
                StatusEffectType.POISON -> 0xFF44CC00.toInt()
                StatusEffectType.FREEZE -> 0xFF88DDFF.toInt()
                StatusEffectType.SHOCK  -> 0xFFFFFF44.toInt()
                StatusEffectType.BLEED  -> 0xFFCC0044.toInt()
            }
            c.drawText(icon, iconX, e.y - e.radius - 18f, pText)
            iconX += 18f
        }
    }

    private fun drawPlayer(c: Canvas, time: Float) {
        val p = state.player
        // Hit flash
        val flashing = p.hitFlashTimer > 0f

        // Shield ring
        if (p.shieldActive) {
            val alpha = (sin(time * 8f) * 40f + 180f).toInt()
            pMain.color = ((alpha shl 24) or 0x004488FF)
            pMain.style = Paint.Style.FILL
            c.drawCircle(p.x, p.y, p.radius + 14f, pMain)
            pMain.color = 0xFF4488FF.toInt(); pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 3f
            c.drawCircle(p.x, p.y, p.radius + 14f, pMain)
            pMain.style = Paint.Style.FILL
        }

        // iFrame ghost tint
        if (p.iFrames > 0f && !p.shieldActive) {
            val alpha = ((sin(time * 25f) * 0.5f + 0.5f) * 200f).toInt()
            pMain.color = (alpha shl 24) or 0x00FFFFFF
            pMain.style = Paint.Style.FILL
            c.drawCircle(p.x, p.y, p.radius + 4f, pMain)
        }

        // Body
        val bodyColor = if (flashing) 0xFFFF8888.toInt() else 0xFF44AAFF.toInt()
        pMain.color = bodyColor; pMain.style = Paint.Style.FILL
        c.drawCircle(p.x, p.y, p.radius, pMain)

        // Inner glow
        pMain.color = if (flashing) 0xFFFFBBBB.toInt() else 0xFF88CCFF.toInt()
        c.drawCircle(p.x, p.y, p.radius * 0.55f, pMain)

        // Dash trail effect
        if (p.isDashing) {
            repeat(5) { i ->
                val tr = 1f - i / 5f
                pMain.color = ((tr * 100f).toInt() shl 24) or 0x0022FFFF
                c.drawCircle(p.x - p.dashVx * 0.003f * i, p.y - p.dashVy * 0.003f * i,
                    p.radius * tr, pMain)
            }
        }

        // Energy orb
        val orbAb = state.abilities.find { it.id == AbilityId.ENERGY_ORB }
        if ((orbAb?.level ?: 0) > 0) {
            val orbCount = orbAb!!.level.coerceAtMost(3)
            val orbR     = 75f + p.areaScale * 15f
            repeat(orbCount) { i ->
                val a = p.orbAngle + i * (2f * PI.toFloat() / orbCount)
                val ox = p.x + cos(a)*orbR; val oy = p.y + sin(a)*orbR
                val orbCol = if (EvoType.ICE_ORB in state.evolutions) 0xFF44AAFF.toInt()
                             else if (p.orbBurst)                      0xFFFF8800.toInt()
                             else                                       0xFFFFDD00.toInt()
                pMain.color = orbCol and 0x00FFFFFF or 0x66000000
                c.drawCircle(ox, oy, 18f, pMain)
                pMain.color = orbCol; c.drawCircle(ox, oy, 12f, pMain)
                pMain.color = 0xFFFFFFFF.toInt(); c.drawCircle(ox, oy, 5f, pMain)
            }
        }
    }

    private fun drawBullets(c: Canvas) {
        pMain.style = Paint.Style.FILL
        for (b in state.bullets) {
            if (b.fromPlayer) {
                // Color by status type
                val col = when (b.statusType) {
                    StatusEffectType.BURN   -> 0xFFFF6600.toInt()
                    StatusEffectType.FREEZE -> 0xFF44AAFF.toInt()
                    StatusEffectType.SHOCK  -> 0xFFFFFF44.toInt()
                    else -> if (b.piercesLeft > 0) 0xFF00FFFF.toInt()
                            else if (b.chainLeft > 0) 0xFF88FFFF.toInt()
                            else 0xFFFFFF88.toInt()
                }
                pMain.color = col and 0x00FFFFFF or 0x44000000
                c.drawCircle(b.x, b.y, b.radius * 2.2f, pMain)
                pMain.color = col; c.drawCircle(b.x, b.y, b.radius, pMain)
            } else {
                pMain.color = 0x44FF3300; c.drawCircle(b.x, b.y, b.radius * 1.8f, pMain)
                pMain.color = 0xFFFF4444.toInt(); c.drawCircle(b.x, b.y, b.radius, pMain)
            }
        }
    }

    private fun drawFloatTexts(c: Canvas) {
        for (ft in state.floatTexts) {
            val alpha = (ft.life / 0.9f * 255f).toInt().coerceIn(0, 255)
            pText.color = (ft.color and 0x00FFFFFF) or (alpha shl 24)
            pText.textSize = (if (ft.isCrit) 44f else 32f) * ft.scale * settings.hudScale
            pText.textAlign = Paint.Align.CENTER
            pText.isFakeBoldText = ft.isCrit
            // Outline for crits
            if (ft.isCrit) {
                pText.style = Paint.Style.STROKE; pText.strokeWidth = 3f
                pText.color = (0x00000000) or (alpha shl 24)
                c.drawText(ft.text, ft.x, ft.y, pText)
                pText.style = Paint.Style.FILL
                pText.color = (ft.color and 0x00FFFFFF) or (alpha shl 24)
            }
            c.drawText(ft.text, ft.x, ft.y, pText)
            pText.isFakeBoldText = false; pText.style = Paint.Style.FILL
        }
    }

    // ─── HUD ─────────────────────────────────────────────────────

    private fun drawHUD(c: Canvas) {
        val p  = state.player
        val hs = settings.hudScale

        // ── HP bar ──────────────────────────────────────────────
        val hpBarW = worldW * 0.55f * hs; val hpBarH = 28f * hs
        val hpBarX = 20f; val hpBarY = 50f
        pBar.style = Paint.Style.FILL
        pBar.color = 0xFF1A0A0A.toInt(); c.drawRoundRect(RectF(hpBarX, hpBarY, hpBarX+hpBarW, hpBarY+hpBarH), hpBarH/2, hpBarH/2, pBar)
        val hpFrac = (p.hp / p.maxHp).coerceIn(0f,1f)
        val hpCol  = when { hpFrac > 0.5f -> 0xFF22CC44.toInt(); hpFrac > 0.25f -> 0xFFEEAA00.toInt(); else -> 0xFFCC2222.toInt() }
        pBar.color = hpCol
        c.drawRoundRect(RectF(hpBarX, hpBarY, hpBarX+hpBarW*hpFrac, hpBarY+hpBarH), hpBarH/2, hpBarH/2, pBar)
        pBar.style = Paint.Style.STROKE; pBar.strokeWidth = 2f; pBar.color = 0xFF445566.toInt()
        c.drawRoundRect(RectF(hpBarX, hpBarY, hpBarX+hpBarW, hpBarY+hpBarH), hpBarH/2, hpBarH/2, pBar)
        pBar.style = Paint.Style.FILL
        pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 18f * hs; pText.textAlign = Paint.Align.LEFT
        c.drawText("HP ${p.hp.toInt()} / ${p.maxHp.toInt()}", hpBarX + 8f, hpBarY + hpBarH - 6f, pText)

        // ── XP bar ──────────────────────────────────────────────
        val xpBarY  = hpBarY + hpBarH + 8f * hs
        val xpBarH  = 16f * hs; val xpFrac = (p.xp / p.xpNext).coerceIn(0f,1f)
        pBar.color = 0xFF0A1A1A.toInt(); c.drawRoundRect(RectF(hpBarX, xpBarY, hpBarX+hpBarW, xpBarY+xpBarH), xpBarH/2, xpBarH/2, pBar)
        pBar.color = 0xFF00AAFF.toInt(); c.drawRoundRect(RectF(hpBarX, xpBarY, hpBarX+hpBarW*xpFrac, xpBarY+xpBarH), xpBarH/2, xpBarH/2, pBar)
        pText.textSize = 16f * hs
        c.drawText("LV ${p.level}", hpBarX + 8f, xpBarY + xpBarH - 2f, pText)

        // ── Wave / time / kills ──────────────────────────────────
        pText.color = 0xFFCCDDFF.toInt(); pText.textSize = 22f * hs; pText.textAlign = Paint.Align.RIGHT
        val mins = (state.elapsed / 60f).toInt(); val secs = (state.elapsed % 60f).toInt()
        c.drawText("WAVE ${state.wave}  |  %02d:%02d".format(mins, secs), worldW - 20f, 68f * hs, pText)
        c.drawText("KILLS: ${state.kills}", worldW - 20f, 92f * hs, pText)

        // ── Combo display ────────────────────────────────────────
        val combo = state.combo
        if (combo.count >= 3) {
            val comboAlpha = (combo.timer / combo.timeout * 255f).toInt().coerceIn(80, 255)
            val comboSize  = 36f * hs * (if (combo.count >= 10) 1.3f else 1f)
            pText.textSize = comboSize; pText.textAlign = Paint.Align.CENTER
            pText.color    = (comboAlpha shl 24) or 0xFFAA00
            c.drawText(combo.label, worldW / 2f, worldH * 0.14f, pText)
            pText.textSize = 22f * hs
            pText.color    = ((comboAlpha / 2) shl 24) or 0xFFCC44
            c.drawText("x%.2f DMG".format(combo.multiplier), worldW/2f, worldH*0.14f + 32f*hs, pText)
        }

        // ── Boss HP bar ──────────────────────────────────────────
        state.boss?.let { boss ->
            val bossBarW = worldW * 0.7f; val bossBarH = 32f * hs
            val bossBarX = (worldW - bossBarW) / 2f; val bossBarY = worldH * 0.11f
            pBar.color = 0xFF1A0000.toInt(); c.drawRoundRect(RectF(bossBarX, bossBarY, bossBarX+bossBarW, bossBarY+bossBarH), 6f, 6f, pBar)
            val bFrac = (boss.hp / boss.maxHp).coerceIn(0f,1f)
            val bCol  = when (boss.bossPhase) { 3 -> 0xFFFF2200.toInt(); 2 -> 0xFFFF6600.toInt(); else -> 0xFFCC0000.toInt() }
            pBar.color = bCol; c.drawRoundRect(RectF(bossBarX, bossBarY, bossBarX+bossBarW*bFrac, bossBarY+bossBarH), 6f, 6f, pBar)
            pText.color = 0xFFFFDDCC.toInt(); pText.textSize = 20f * hs; pText.textAlign = Paint.Align.CENTER
            c.drawText("BOSS  ${boss.hp.toInt()} / ${boss.maxHp.toInt()}", worldW/2f, bossBarY + bossBarH - 6f, pText)
        }

        // ── Ability buttons ──────────────────────────────────────
        drawAbilityButtons(c, hs)

        // ── Joystick ghost ───────────────────────────────────────
        if (joyActive) {
            pMain.color = 0x33FFFFFF; pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 2f
            c.drawCircle(joyBaseX, joyBaseY, joyRadius, pMain)
            pMain.color = 0x88FFFFFF.toInt(); pMain.style = Paint.Style.FILL
            c.drawCircle(joyBaseX + joyDx, joyBaseY + joyDy, 38f * hs, pMain)
            pMain.style = Paint.Style.FILL
        }

        // ── Pause button ─────────────────────────────────────────
        pMain.color = 0x55AABBCC; pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(worldW-85f, 14f, worldW-14f, 80f), 12f, 12f, pMain)
        pText.color = 0xFFCCDDFF.toInt(); pText.textSize = 20f; pText.textAlign = Paint.Align.CENTER
        c.drawText("II", worldW - 50f, 58f, pText)
        pMain.style = Paint.Style.FILL

        // ── Currency ─────────────────────────────────────────────
        pText.color = 0xFFFFCC44.toInt(); pText.textSize = 20f*hs; pText.textAlign = Paint.Align.LEFT
        c.drawText("${state.runCurrency} c", hpBarX, xpBarY + xpBarH + 24f*hs, pText)

        // ── Event indicator ──────────────────────────────────────
        state.currentEvent?.let { evt ->
            pMain.color = 0x88222244.toInt(); pMain.style = Paint.Style.FILL
            val evRect = RectF(worldW/2f - 160f, worldH*0.06f - 20f, worldW/2f + 160f, worldH*0.06f + 20f)
            c.drawRoundRect(evRect, 12f, 12f, pMain)
            pText.color = eventColor(evt); pText.textSize = 22f*hs; pText.textAlign = Paint.Align.CENTER
            c.drawText(eventName(evt), worldW/2f, worldH*0.06f + 7f, pText)
        }
    }

    private fun drawAbilityButtons(c: Canvas, hs: Float) {
        for (btn in abilityBtns) {
            val ab = state.abilities.getOrNull(btn.idx) ?: continue
            val unlocked = ab.level > 0
            val ready    = ab.isReady()
            val cdFrac   = if (ab.baseCd > 0f) (ab.cdTimer / ab.baseCd).coerceIn(0f,1f) else 0f
            val sc       = btn.pressScale

            c.save(); c.scale(sc, sc, btn.cx, btn.cy)

            // Background
            pMain.color = when {
                !unlocked -> 0x33334455
                ready     -> 0xCC1A3366.toInt()
                else      -> 0xCC1A1A2A.toInt()
            }
            pMain.style = Paint.Style.FILL
            c.drawCircle(btn.cx, btn.cy, btn.r, pMain)

            // CD arc
            if (!ready && unlocked && cdFrac > 0f) {
                pMain.color = 0xAA002244.toInt()
                val oval = RectF(btn.cx-btn.r, btn.cy-btn.r, btn.cx+btn.r, btn.cy+btn.r)
                c.drawArc(oval, -90f, 360f*cdFrac, true, pMain)
            }

            // Border
            pMain.style  = Paint.Style.STROKE
            pMain.strokeWidth = 2.5f
            pMain.color  = if (ready && unlocked) 0xFF4488FF.toInt() else 0xFF334455.toInt()
            c.drawCircle(btn.cx, btn.cy, btn.r, pMain)
            pMain.style = Paint.Style.FILL

            // Label
            pText.color  = if (unlocked) 0xFFDDEEFF.toInt() else 0xFF445566.toInt()
            pText.textSize = 20f * hs; pText.textAlign = Paint.Align.CENTER
            c.drawText(ab.label, btn.cx, btn.cy + 7f, pText)

            // CD timer text
            if (!ready && unlocked && ab.cdTimer > 0f) {
                pText.color = 0xAADDEEFF.toInt(); pText.textSize = 14f * hs
                c.drawText("%.1f".format(ab.cdTimer), btn.cx, btn.cy + btn.r - 6f, pText)
            }
            c.restore()
        }
    }

    // ─── Level Up overlay ─────────────────────────────────────────

    private fun drawLevelUp(c: Canvas) {
        val time = state.elapsed
        // Dim background
        pMain.color = 0xCC050810.toInt(); pMain.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pMain)

        // Title
        pText.color = 0xFF00FFAA.toInt(); pText.textSize = 54f * settings.hudScale
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        c.drawText("LEVEL UP!", worldW/2f, worldH*0.14f, pText)
        pText.isFakeBoldText = false

        pText.color = 0xFF88CCFF.toInt(); pText.textSize = 26f * settings.hudScale
        c.drawText("Level ${state.player.level}  —  Choose an upgrade", worldW/2f, worldH*0.20f, pText)

        val ups    = state.pendingUpgrades
        val cardH  = worldH * 0.24f; val cardW = worldW * 0.80f
        val startY = worldH * 0.27f; val gap   = cardH + 18f
        val cx     = worldW / 2f

        for ((i, up) in ups.withIndex()) {
            val top    = startY + i * gap
            val sc     = cardScales[i]
            val highlighted = sc < 1f

            c.save(); c.scale(sc, sc, cx, top + cardH/2f)

            // Card background
            val cardCol = rarityCardColor(up.rarity)
            pMain.color = cardCol; pMain.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx-cardW/2, top, cx+cardW/2, top+cardH), 20f, 20f, pMain)

            // Rarity glow border
            pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 3.5f
            pMain.color = rarityBorderColor(up.rarity)
            c.drawRoundRect(RectF(cx-cardW/2, top, cx+cardW/2, top+cardH), 20f, 20f, pMain)
            pMain.style = Paint.Style.FILL

            // Rarity badge
            val rarStr = rarityLabel(up.rarity)
            pText.color = rarityBorderColor(up.rarity); pText.textSize = 18f
            pText.textAlign = Paint.Align.LEFT
            c.drawText(rarStr, cx - cardW/2 + 16f, top + 28f, pText)

            // Upgrade name
            pText.color = 0xFFEEFFFF.toInt(); pText.textSize = 32f * settings.hudScale
            pText.isFakeBoldText = true; pText.textAlign = Paint.Align.CENTER
            c.drawText(up.name, cx, top + cardH * 0.45f, pText)
            pText.isFakeBoldText = false

            // Upgrade description
            pText.color = 0xFFAABBCC.toInt(); pText.textSize = 24f * settings.hudScale
            c.drawText(up.desc, cx, top + cardH * 0.72f, pText)

            c.restore()
        }
    }

    // ─── Pause overlay ────────────────────────────────────────────

    private fun drawPause(c: Canvas) {
        pMain.color = 0xBB040608.toInt(); pMain.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pMain)

        pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 56f; pText.textAlign = Paint.Align.CENTER
        pText.isFakeBoldText = true; c.drawText("PAUSED", worldW/2f, worldH*0.32f, pText); pText.isFakeBoldText = false

        val cx = worldW/2f; val btnW = 340f; val btnH = 90f
        drawMenuBtn(c, cx, worldH*0.42f, btnW, btnH, "RESUME",   0xFF224466.toInt(), 0xFF44AAFF.toInt())
        drawMenuBtn(c, cx, worldH*0.54f, btnW, btnH, "SETTINGS", 0xFF222244.toInt(), 0xFF8888FF.toInt())
        drawMenuBtn(c, cx, worldH*0.66f, btnW, btnH, "QUIT",     0xFF440000.toInt(), 0xFFFF4444.toInt())

        // Mini stats
        pText.color = 0xFF778899.toInt(); pText.textSize = 22f; pText.textAlign = Paint.Align.CENTER
        val p = state.player; val mins = (state.elapsed/60f).toInt(); val secs = (state.elapsed%60f).toInt()
        c.drawText("Wave ${state.wave}  •  Kills: ${state.kills}  •  Level ${p.level}  •  %02d:%02d".format(mins, secs), cx, worldH*0.78f, pText)
    }

    // ─── Dead / stats overlay ─────────────────────────────────────

    private fun drawDead(c: Canvas) {
        pMain.color = 0xDD050508.toInt(); pMain.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pMain)

        pText.textAlign = Paint.Align.CENTER

        // Title
        pText.color = 0xFFCC2222.toInt(); pText.textSize = 60f; pText.isFakeBoldText = true
        c.drawText("ELIMINATED", worldW/2f, worldH*0.09f, pText); pText.isFakeBoldText = false

        // Stats card
        val cx   = worldW/2f; val cardW = worldW*0.85f
        val cardX = cx - cardW/2f; val cardY = worldH*0.12f; val cardBottom = worldH*0.76f
        pMain.color = 0xBB0A0C1A.toInt(); pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(cardX, cardY, cardX+cardW, cardBottom), 22f, 22f, pMain)
        pMain.color = 0xFF223344.toInt(); pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 2f
        c.drawRoundRect(RectF(cardX, cardY, cardX+cardW, cardBottom), 22f, 22f, pMain)
        pMain.style = Paint.Style.FILL

        val p  = state.player; val st = state.stats
        val mins = (state.elapsed/60f).toInt(); val secs = (state.elapsed%60f).toInt()

        fun statRow(label: String, value: String, y: Float) {
            pText.textAlign = Paint.Align.LEFT; pText.color = 0xFF778899.toInt(); pText.textSize = 24f
            c.drawText(label, cardX+28f, y, pText)
            pText.textAlign = Paint.Align.RIGHT; pText.color = 0xFFCCDDEE.toInt()
            c.drawText(value, cardX+cardW-28f, y, pText)
        }

        var ry = cardY + 46f
        pText.textAlign = Paint.Align.CENTER; pText.color = 0xFFAABBCC.toInt(); pText.textSize = 28f
        c.drawText("RUN SUMMARY", cx, ry, pText); ry += 38f

        // Divider
        pMain.color = 0xFF223344.toInt(); pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 1.5f
        c.drawLine(cardX+20f, ry-10f, cardX+cardW-20f, ry-10f, pMain); pMain.style = Paint.Style.FILL

        val rs = 34f
        statRow("Survived",        "%02d:%02d".format(mins, secs),       ry       ); ry += rs
        statRow("Wave Reached",    "${state.wave}",                       ry       ); ry += rs
        statRow("Kills",           "${state.kills}",                      ry       ); ry += rs
        statRow("Level",           "${p.level}",                          ry       ); ry += rs
        statRow("Damage Dealt",    "${st.damageDealt.toInt()}",           ry       ); ry += rs
        statRow("Damage Taken",    "${st.damageTaken.toInt()}",           ry       ); ry += rs
        statRow("Healing Done",    "${st.healingDone.toInt()}",           ry       ); ry += rs
        statRow("Bosses Slain",    "${st.bossesKilled}",                  ry       ); ry += rs
        statRow("Best Combo",      "x${st.bestCombo}",                    ry       ); ry += rs
        statRow("Chests Opened",   "${st.chestsOpened}",                  ry       ); ry += rs
        statRow("Status Effects",  "${st.statusApplied}",                 ry       ); ry += rs
        statRow("Abilities Used",  "${st.abilitiesUsed}",                 ry       )

        // Coins earned
        pMain.color = 0xFF443300.toInt(); pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(cardX+20f, cardBottom-50f, cardX+cardW-20f, cardBottom-10f), 10f, 10f, pMain)
        pText.color = 0xFFFFCC44.toInt(); pText.textSize = 26f; pText.textAlign = Paint.Align.CENTER
        c.drawText("+${state.runCurrency} coins earned  (Total: ${meta.currency})", cx, cardBottom-22f, pText)

        val cx2 = worldW/2f; val btnW = 380f; val btnH = 90f
        drawMenuBtn(c, cx2, worldH*0.79f, btnW, btnH, "PLAY AGAIN",       0xFF0A3A1A.toInt(), 0xFF22CC66.toInt())
        drawMenuBtn(c, cx2, worldH*0.87f, btnW, btnH, "CHARACTER SELECT", 0xFF222244.toInt(), 0xFF6688FF.toInt())
    }

    // ─── Character Select ─────────────────────────────────────────

    private fun drawCharacterSelect(c: Canvas) {
        c.drawColor(0xFF060810.toInt())
        drawBackgroundStars(c)

        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFF88AAFF.toInt(); pText.textSize = 52f
        c.drawText("VOID SURVIVORS", worldW/2f, worldH*0.1f, pText); pText.isFakeBoldText = false

        pText.color = 0xFF445566.toInt(); pText.textSize = 24f
        c.drawText("Choose your character", worldW/2f, worldH*0.16f, pText)

        // Currency
        pText.color = 0xFFFFCC44.toInt(); pText.textSize = 26f
        c.drawText("Coins: ${meta.currency}", worldW/2f, worldH*0.20f, pText)

        val cx = worldW/2f; val cardW = worldW*0.78f; val cardH = worldH*0.14f
        val startY = worldH*0.24f; val gap = cardH + 14f

        for ((i, def) in Characters.ALL.withIndex()) {
            val top      = startY + i * gap
            val selected = i == selectedCharIdx
            val unlocked = meta.isCharUnlocked(def.type)

            // Card bg
            val bgCol = when {
                !unlocked -> 0x66111122
                selected  -> 0xBB001A44.toInt()
                else      -> 0xAA0A0C1A.toInt()
            }
            pMain.color = bgCol; pMain.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx-cardW/2, top, cx+cardW/2, top+cardH), 16f, 16f, pMain)

            // Selected border
            pMain.style = Paint.Style.STROKE; pMain.strokeWidth = if (selected) 3.5f else 1.5f
            pMain.color = if (selected) 0xFF4488FF.toInt() else 0xFF223344.toInt()
            c.drawRoundRect(RectF(cx-cardW/2, top, cx+cardW/2, top+cardH), 16f, 16f, pMain)
            pMain.style = Paint.Style.FILL

            // Color indicator
            val charColor = charColor(def.type)
            pMain.color = if (unlocked) charColor else 0xFF333333.toInt()
            c.drawCircle(cx - cardW/2 + 45f, top + cardH/2f, 22f, pMain)

            pText.textAlign = Paint.Align.LEFT
            val tx = cx - cardW/2 + 82f

            if (unlocked) {
                pText.color = if (selected) 0xFFEEFFFF.toInt() else 0xFFCCDDEE.toInt()
                pText.textSize = 30f; pText.isFakeBoldText = true
                c.drawText(def.name, tx, top + cardH*0.42f, pText); pText.isFakeBoldText = false
                pText.color = 0xFF778899.toInt(); pText.textSize = 21f
                c.drawText(def.tagline, tx, top + cardH*0.73f, pText)
                if (selected) {
                    pText.color = 0xFF44AAFF.toInt(); pText.textAlign = Paint.Align.RIGHT
                    pText.textSize = 22f; c.drawText("SELECTED", cx+cardW/2-18f, top+cardH*0.55f, pText)
                }
            } else {
                pText.color = 0xFF445566.toInt(); pText.textSize = 30f; pText.isFakeBoldText = true
                c.drawText(def.name, tx, top + cardH*0.42f, pText); pText.isFakeBoldText = false
                pText.color = 0xFFFFCC44.toInt(); pText.textSize = 22f
                c.drawText("Unlock: ${def.unlockCost} coins  (You: ${meta.currency})", tx, top + cardH*0.73f, pText)
            }
        }

        // Permanent upgrades row
        val metaY = startY + Characters.ALL.size * gap + 16f
        pText.textAlign = Paint.Align.CENTER; pText.color = 0xFF556677.toInt(); pText.textSize = 22f
        c.drawText("PERMANENT UPGRADES  (Coins: ${meta.currency})", cx, metaY + 28f, pText)

        val metaCardW = worldW*0.78f; val metaCardH = 110f
        val metaBg = RectF(cx-metaCardW/2f, metaY+40f, cx+metaCardW/2f, metaY+40f+metaCardH)
        pMain.color = 0xAA0A0C1A.toInt(); pMain.style = Paint.Style.FILL
        c.drawRoundRect(metaBg, 16f, 16f, pMain)
        pMain.color = 0xFF223344.toInt(); pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 1.5f
        c.drawRoundRect(metaBg, 16f, 16f, pMain); pMain.style = Paint.Style.FILL

        val cols = 4; val btnW2 = metaCardW/cols - 12f; val btnH2 = 70f
        val labels = arrayOf("HP+20 (${meta.costHp()}c)", "SPD+15 (${meta.costSpeed()}c)",
            "CDR-5% (${meta.costCdr()}c)", "XP+10% (${meta.costXp()}c)")
        val levels = intArrayOf(meta.hpLevel, meta.speedLevel, meta.cdrLevel, meta.xpLevel)
        for (i in 0 until cols) {
            val bx = cx - metaCardW/2f + 8f + i*(btnW2+12f)
            val by = metaY + 52f
            val canAfford = when(i) {
                0 -> meta.currency >= meta.costHp(); 1 -> meta.currency >= meta.costSpeed()
                2 -> meta.currency >= meta.costCdr(); else -> meta.currency >= meta.costXp()
            }
            pMain.color = if (canAfford) 0xFF0A2A1A.toInt() else 0xFF1A1A2A.toInt()
            c.drawRoundRect(RectF(bx, by, bx+btnW2, by+btnH2), 10f, 10f, pMain)
            pText.textAlign = Paint.Align.CENTER; pText.textSize = 17f
            pText.color = if (canAfford) 0xFF88FF88.toInt() else 0xFF445566.toInt()
            c.drawText(labels[i], bx+btnW2/2, by+28f, pText)
            pText.color = 0xFF446688.toInt(); pText.textSize = 14f
            c.drawText("Lv ${levels[i]}", bx+btnW2/2, by+52f, pText)
        }

        // Start button
        val startY2 = metaY + 40f + metaCardH + 22f
        drawMenuBtn(c, cx, startY2, 400f, 100f, "START RUN", 0xFF003322.toInt(), 0xFF22EE88.toInt())
    }

    // ─── Settings screen ─────────────────────────────────────────

    private fun drawSettings(c: Canvas) {
        c.drawColor(0xFF060810.toInt())
        drawBackgroundStars(c)

        pText.textAlign = Paint.Align.CENTER
        pText.color = 0xFF88AAFF.toInt(); pText.textSize = 46f; pText.isFakeBoldText = true
        c.drawText("SETTINGS", worldW/2f, worldH*0.12f, pText); pText.isFakeBoldText = false

        val cx = worldW/2f; val sliderW = worldW*0.6f; val sliderH = 18f
        val sliderLeft = cx - sliderW/2f

        fun drawSlider(label: String, value: Float, yLine: Float) {
            pText.color = 0xFFAABBCC.toInt(); pText.textSize = 26f; pText.textAlign = Paint.Align.LEFT
            c.drawText(label, sliderLeft, yLine - 16f, pText)
            pBar.color = 0xFF1A2233.toInt(); pBar.style = Paint.Style.FILL
            c.drawRoundRect(RectF(sliderLeft, yLine, sliderLeft+sliderW, yLine+sliderH), sliderH/2, sliderH/2, pBar)
            pBar.color = 0xFF4488FF.toInt()
            c.drawRoundRect(RectF(sliderLeft, yLine, sliderLeft+sliderW*value, yLine+sliderH), sliderH/2, sliderH/2, pBar)
            pMain.color = 0xFFAABBFF.toInt(); pMain.style = Paint.Style.FILL
            c.drawCircle(sliderLeft + sliderW*value, yLine + sliderH/2, 22f, pMain)
            pText.color = 0xFF6677AA.toInt(); pText.textSize = 22f; pText.textAlign = Paint.Align.RIGHT
            c.drawText("${(value*100).toInt()}%", sliderLeft+sliderW+70f, yLine+14f, pText)
        }

        drawSlider("SFX Volume",   settings.sfxVolume,   worldH*0.38f)
        drawSlider("Music Volume", settings.musicVolume, worldH*0.50f)

        val hudNorm = (settings.hudScale - 0.7f) / 0.9f
        drawSlider("HUD Scale",    hudNorm,               worldH*0.62f)

        fun drawToggle(label: String, value: Boolean, y: Float) {
            pText.color = 0xFFAABBCC.toInt(); pText.textSize = 26f; pText.textAlign = Paint.Align.LEFT
            c.drawText(label, sliderLeft, y+10f, pText)
            val bgCol = if (value) 0xFF224422.toInt() else 0xFF221A22.toInt()
            pMain.color = bgCol; pMain.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx+80f, y-16f, cx+200f, y+20f), 18f, 18f, pMain)
            pMain.color = if (value) 0xFF44FF88.toInt() else 0xFF664466.toInt()
            c.drawCircle(if (value) cx+182f else cx+98f, y+2f, 18f, pMain)
            pText.color = if (value) 0xFF44FF88.toInt() else 0xFF664466.toInt()
            pText.textSize = 22f; pText.textAlign = Paint.Align.RIGHT
            c.drawText(if (value) "ON" else "OFF", cx+200f, y+10f, pText)
        }

        drawToggle("Vibration",      settings.vibration,    worldH*0.72f)
        drawToggle("Show FPS",       settings.showFps,      worldH*0.86f)
        drawToggle("Left Joystick",  settings.joystickLeft, worldH*0.92f)

        // Quality picker
        pText.color = 0xFFAABBCC.toInt(); pText.textSize = 26f; pText.textAlign = Paint.Align.LEFT
        c.drawText("Graphics Quality", sliderLeft, worldH*0.80f - 12f, pText)
        val qualLabels = arrayOf("", "LOW", "MEDIUM", "HIGH")
        for (q in 1..3) {
            val bx = cx - 140f + (q-1)*100f
            pMain.color = if (settings.quality == q) 0xFF224466.toInt() else 0xFF111A2A.toInt()
            pMain.style = Paint.Style.FILL
            c.drawRoundRect(RectF(bx-36f, worldH*0.80f+4f, bx+36f, worldH*0.80f+44f), 10f, 10f, pMain)
            pMain.color = if (settings.quality == q) 0xFF4488FF.toInt() else 0xFF334455.toInt()
            pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 1.5f
            c.drawRoundRect(RectF(bx-36f, worldH*0.80f+4f, bx+36f, worldH*0.80f+44f), 10f, 10f, pMain)
            pMain.style = Paint.Style.FILL
            pText.color = if (settings.quality == q) 0xFF88CCFF.toInt() else 0xFF445566.toInt()
            pText.textSize = 18f; pText.textAlign = Paint.Align.CENTER
            c.drawText(qualLabels[q], bx, worldH*0.80f + 30f, pText)
        }

        // Back
        pMain.color = 0x44FFFFFF; pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(14f, 14f, 160f, 76f), 12f, 12f, pMain)
        pText.color = 0xFFCCDDFF.toInt(); pText.textSize = 26f; pText.textAlign = Paint.Align.CENTER
        c.drawText("< Back", 87f, 55f, pText)
    }

    // ─── Tutorial overlay ─────────────────────────────────────────

    private fun drawTutorialOverlay(c: Canvas) {
        if (!tutorialShown || tutorialStep == TutorialStep.DONE || state.phase != Phase.PLAYING) return
        val msg = when (tutorialStep) {
            TutorialStep.MOVE         -> "Drag the left side of the screen to move"
            TutorialStep.SHOOT_AUTO   -> "You shoot automatically! Target the nearest enemy"
            TutorialStep.COLLECT_XP   -> "Collect glowing orbs to gain XP"
            TutorialStep.LEVEL_UP_INFO-> "Tap an upgrade card to level up!"
            TutorialStep.ABILITIES    -> "Tap the ability buttons to activate skills"
            TutorialStep.DONE         -> return
        }
        val alpha = if (tutorialTimer > 3f) 220 else (tutorialTimer / 3f * 220f).toInt().coerceIn(0, 220)
        pMain.color = ((alpha) shl 24) or 0x000A0C14
        pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(40f, worldH*0.8f, worldW-40f, worldH*0.8f+90f), 18f, 18f, pMain)
        pText.color = ((255) shl 24) or 0xCCEEFF; pText.textSize = 26f; pText.textAlign = Paint.Align.CENTER
        c.drawText(msg, worldW/2f, worldH*0.8f + 54f, pText)
    }

    // ─── Announcement / warning overlays ─────────────────────────

    private fun drawBossWarning(c: Canvas) {
        if (!state.showBossWarning) return
        val flash = (sin(state.elapsed * 12f) * 0.5f + 0.5f)
        pMain.color = ((flash * 120f).toInt() shl 24) or 0xFF0000
        pMain.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pMain)
        pText.color = 0xFFFF2222.toInt(); pText.textSize = 62f * (0.85f + flash*0.15f)
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        c.drawText("! BOSS INCOMING !", worldW/2f, worldH/2f, pText)
        pText.isFakeBoldText = false
    }

    private fun drawEventAnnouncement(c: Canvas) {
        val ann = state.eventAnnouncement ?: return
        val alpha = (ann.warningTimer / 2.5f * 200f).toInt().coerceIn(0, 200)
        pMain.color = (alpha shl 24) or 0x001A0A2A
        pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(60f, worldH*0.38f, worldW-60f, worldH*0.62f), 22f, 22f, pMain)
        pText.color = eventColor(ann.type); pText.textSize = 44f; pText.textAlign = Paint.Align.CENTER
        pText.isFakeBoldText = true; c.drawText("EVENT!", worldW/2f, worldH*0.46f, pText); pText.isFakeBoldText = false
        pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 32f
        c.drawText(eventName(ann.type), worldW/2f, worldH*0.54f, pText)
    }

    // ─── Achievement toasts ───────────────────────────────────────

    private fun drawToasts(c: Canvas) {
        var ty = worldH * 0.22f
        for (toast in toasts) {
            val alpha  = if (toast.life > 2.5f) 255
                         else (toast.life / 2.5f * 255f).toInt()
            val slideX = if (toast.life > 3f) (3.5f - toast.life) / 0.5f else 1f

            pMain.color = ((alpha) shl 24) or 0x001A3322
            pMain.style = Paint.Style.FILL
            val w = 360f * slideX; val h = 64f
            c.drawRoundRect(RectF(worldW - w - 10f, ty, worldW - 10f, ty+h), 14f, 14f, pMain)
            pMain.color = ((alpha/2) shl 24) or 0x00226644
            pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 2f
            c.drawRoundRect(RectF(worldW - w - 10f, ty, worldW - 10f, ty+h), 14f, 14f, pMain)
            pMain.style = Paint.Style.FILL

            pText.color = ((alpha) shl 24) or 0xFFCC44
            pText.textSize = 18f; pText.textAlign = Paint.Align.RIGHT
            c.drawText("ACHIEVEMENT", worldW-20f, ty+22f, pText)
            pText.color = ((alpha) shl 24) or 0xEEFFEE
            pText.textSize = 24f
            c.drawText(toast.name, worldW-20f, ty+52f, pText)
            ty += h + 8f
        }
    }

    // ─── FPS display ─────────────────────────────────────────────

    private fun drawFps(c: Canvas) {
        pText.color = 0xFF55FF55.toInt(); pText.textSize = 22f; pText.textAlign = Paint.Align.LEFT
        c.drawText("FPS: $fpsDisplay", 20f, worldH - 20f, pText)
    }

    // ─── Helpers ─────────────────────────────────────────────────

    private fun drawBackgroundStars(c: Canvas) {
        pMain.style = Paint.Style.FILL
        for (s in stars) {
            pMain.color = (((s.bright * 160f).toInt()) shl 24) or 0xAABBFF
            c.drawCircle(s.x, s.y, s.r, pMain)
        }
    }

    private fun drawMenuBtn(c: Canvas, cx: Float, top: Float, w: Float, h: Float,
                             label: String, bgColor: Int, borderColor: Int) {
        pMain.color = bgColor; pMain.style = Paint.Style.FILL
        c.drawRoundRect(RectF(cx-w/2, top, cx+w/2, top+h), h/2, h/2, pMain)
        pMain.color = borderColor; pMain.style = Paint.Style.STROKE; pMain.strokeWidth = 2.5f
        c.drawRoundRect(RectF(cx-w/2, top, cx+w/2, top+h), h/2, h/2, pMain)
        pMain.style = Paint.Style.FILL
        pText.color = borderColor; pText.textSize = 30f; pText.textAlign = Paint.Align.CENTER
        pText.isFakeBoldText = true
        c.drawText(label, cx, top + h*0.64f, pText)
        pText.isFakeBoldText = false
    }

    private fun enemyColor(type: EnemyType): Int = when (type) {
        EnemyType.BASIC        -> 0xFFCC3333.toInt()
        EnemyType.FAST         -> 0xFFFF6600.toInt()
        EnemyType.TANK         -> 0xFF884422.toInt()
        EnemyType.SHOOTER      -> 0xFF8833CC.toInt()
        EnemyType.SWARM        -> 0xFFCC4422.toInt()
        EnemyType.CHARGER      -> 0xFFFF2200.toInt()
        EnemyType.RANGED       -> 0xFF994488.toInt()
        EnemyType.EXPLODER     -> 0xFFFF8800.toInt()
        EnemyType.SHIELD_ENEMY -> 0xFF2244AA.toInt()
        EnemyType.TELEPORTER   -> 0xFF8800CC.toInt()
        EnemyType.ELITE        -> 0xFFFF8C00.toInt()
        EnemyType.BOSS         -> 0xFF880000.toInt()
    }

    private fun charColor(type: CharacterType): Int = when (type) {
        CharacterType.VOID_WALKER -> 0xFF44AAFF.toInt()
        CharacterType.BERSERKER   -> 0xFFFF4422.toInt()
        CharacterType.SPECTER     -> 0xFF88FF88.toInt()
        CharacterType.ARCANIST    -> 0xFFAA44FF.toInt()
    }

    private fun eventColor(evt: EventType): Int = when (evt) {
        EventType.SWARM_RUSH  -> 0xFFFF4444.toInt()
        EventType.DARKNESS    -> 0xFF8844FF.toInt()
        EventType.METEOR_RAIN -> 0xFFFF8800.toInt()
        EventType.ELITE_ONLY  -> 0xFFFFD700.toInt()
        EventType.SLOW_MOTION -> 0xFF00CCFF.toInt()
    }

    private fun eventName(evt: EventType): String = when (evt) {
        EventType.SWARM_RUSH  -> "SWARM RUSH"
        EventType.DARKNESS    -> "DARKNESS"
        EventType.METEOR_RAIN -> "METEOR RAIN"
        EventType.ELITE_ONLY  -> "ELITE ASSAULT"
        EventType.SLOW_MOTION -> "TIME DISTORTION"
    }

    private fun rarityCardColor(r: Int): Int = when (r) {
        3    -> 0xBB1A0A2A.toInt()
        2    -> 0xBB0A1A2A.toInt()
        else -> 0xBB0A0A1A.toInt()
    }

    private fun rarityBorderColor(r: Int): Int = when (r) {
        3    -> 0xFFAA44FF.toInt()
        2    -> 0xFF4488FF.toInt()
        else -> 0xFF446688.toInt()
    }

    private fun rarityLabel(r: Int): String = when (r) {
        3    -> "★ EPIC"
        2    -> "◆ RARE"
        else -> "· COMMON"
    }

    private fun blendColors(c1: Int, c2: Int, t: Float): Int {
        val r1 = (c1 shr 16 and 0xFF); val g1 = (c1 shr 8 and 0xFF); val b1 = (c1 and 0xFF)
        val r2 = (c2 shr 16 and 0xFF); val g2 = (c2 shr 8 and 0xFF); val b2 = (c2 and 0xFF)
        val r  = (r1 + (r2-r1)*t).toInt(); val g = (g1 + (g2-g1)*t).toInt(); val b = (b1 + (b2-b1)*t).toInt()
        return 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
    }

    private fun vibrate(ms: Long) {
        if (!settings.vibration) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") vibrator?.vibrate(ms)
            }
        } catch (_: Exception) {}
    }

    // ─── Persistence ─────────────────────────────────────────────

    private fun saveSettings() {
        prefs.edit()
            .putFloat("sfx_vol",   settings.sfxVolume)
            .putFloat("music_vol", settings.musicVolume)
            .putBoolean("vibration",    settings.vibration)
            .putFloat("hud_scale",      settings.hudScale)
            .putInt("quality",          settings.quality)
            .putBoolean("joy_left",     settings.joystickLeft)
            .putBoolean("show_fps",     settings.showFps)
            .apply()
    }

    private fun loadSettings() {
        settings.sfxVolume     = prefs.getFloat("sfx_vol",   0.75f)
        settings.musicVolume   = prefs.getFloat("music_vol", 0.40f)
        settings.vibration     = prefs.getBoolean("vibration", true)
        settings.hudScale      = prefs.getFloat("hud_scale", 1.0f)
        settings.quality       = prefs.getInt("quality", 2)
        settings.joystickLeft  = prefs.getBoolean("joy_left", true)
        settings.showFps       = prefs.getBoolean("show_fps", false)
    }

    private fun saveMeta() {
        prefs.edit()
            .putInt("currency",        meta.currency)
            .putInt("hp_level",        meta.hpLevel)
            .putInt("speed_level",     meta.speedLevel)
            .putInt("cdr_level",       meta.cdrLevel)
            .putInt("xp_level",        meta.xpLevel)
            .putString("start_ab",     meta.startAbility?.name)
            .putInt("char_sel",        meta.selectedCharacter.ordinal)
            .putInt("unlocked_chars",  meta.unlockedCharsMask)
            .putLong("achieve_flags",  meta.achievementFlags)
            .putInt("total_boss_kills",meta.totalBossKills)
            .putInt("total_status",    meta.totalStatusApplied)
            .putInt("total_runs",      meta.totalRuns)
            .putInt("best_wave",       meta.bestWave)
            .putInt("best_time",       meta.bestTime)
            .apply()
    }

    private fun loadMeta() {
        try {
            meta.currency          = prefs.getInt("currency", 0)
            meta.hpLevel           = prefs.getInt("hp_level", 0)
            meta.speedLevel        = prefs.getInt("speed_level", 0)
            meta.cdrLevel          = prefs.getInt("cdr_level", 0)
            meta.xpLevel           = prefs.getInt("xp_level", 0)
            meta.startAbility      = prefs.getString("start_ab", null)?.let {
                try { AbilityId.valueOf(it) } catch (_: Exception) { null }
            }
            meta.selectedCharacter = CharacterType.values().getOrElse(prefs.getInt("char_sel", 0)) { CharacterType.VOID_WALKER }
            meta.unlockedCharsMask = prefs.getInt("unlocked_chars", 1)
            meta.achievementFlags  = prefs.getLong("achieve_flags", 0L)
            meta.totalBossKills    = prefs.getInt("total_boss_kills", 0)
            meta.totalStatusApplied= prefs.getInt("total_status", 0)
            meta.totalRuns         = prefs.getInt("total_runs", 0)
            meta.bestWave          = prefs.getInt("best_wave", 0)
            meta.bestTime          = prefs.getInt("best_time", 0)
            selectedCharIdx        = meta.selectedCharacter.ordinal
        } catch (_: Exception) {
            // Recover from corrupted prefs — start fresh
            prefs.edit().clear().apply()
        }
    }
}
