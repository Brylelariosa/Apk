package com.example.neuralnetinc.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.neuralnetinc.util.Constants

/**
 * Room database — single source of truth.
 * Version 1: only GameState table.
 *
 * NOTE: @TypeConverters removed — not needed in Part 1 since all GameState
 * fields are primitive types that Room handles natively (Double, Long, Int).
 * Re-add when Part 2 introduces List<Hardware> or other complex field types.
 */
@Database(
    entities = [GameState::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun gameStateDao(): GameStateDao

    companion object {

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    Constants.DB_NAME
                ).build().also { INSTANCE = it }
            }
        }
    }
}
