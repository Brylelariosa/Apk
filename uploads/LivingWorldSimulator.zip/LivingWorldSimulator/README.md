# Living World Simulator - Milestone 1: planet & Earth-system foundation

Build: push `LivingWorldSimulator.zip` into `uploads/` of the repo that holds the existing "Build APK" workflow
(JDK 17, Gradle 8.6, NDK 25.2.9519653, CMake 3.22.1). The project is a plain universal APK (arm64-v8a + armeabi-v7a, no ABI splits).

## Architecture
Native C++17 core (`app/src/main/cpp/core`, bit-reproducible: own sin/exp/log/atan, no fast-math, no FMA contraction)
+ Kotlin / OpenGL ES 3.0 renderer.

| Layer | What it does |
|---|---|
| `params.h` | PlanetParameters -> Derived constants (Coriolis, Hadley width, lapse rate, heat capacity, greenhouse, relief limit ...). Every system reads these. |
| `tectonics.*` | Weighted, noise-warped Voronoi plates on Euler-pole rotations; boundary type from relative velocity (convergent / divergent / transform); crust is carried with its plate through geological time. |
| `terrain.*` | Isostasy-based elevation, trenches, arcs, collision belts, rifts, ridges (age-depth), hotspot chains, inherited orogens, sea level from ocean %, stream-power erosion (implicit, priority-flood), sediment transport, deltas, shelves. |
| `climate.*` | Insolation (tilt, eccentricity) -> surface/air energy balance (land/ocean heat capacity, sea ice, snow albedo) -> thermal-equator-following Hadley/Ferrel/polar pressure belts + thermal highs/lows -> friction-geostrophic winds -> Stommel wind-driven ocean gyres, Ekman upwelling -> moisture transport with orographic lift and rain shadows -> clouds, rain/snow, soil water, runoff, glaciers. |
| `ecology.*` | Downscaled climate -> water balance, flow routing, lakes (closed basins evaporate), river discharge, soils, NPP, biomes (never painted), resources, hazard foundations. |
| `chunk.*` | Streaming chunk builder: 33x33 mesh + skirts, 96x96 albedo + tangent-space normal textures, fractal detail steered by simulated roughness, 11 debug layers. |
| `explain.cpp` | "Why is this here?" - walks the real cause data (plates, upwind moisture trace, watershed ...). |
| Kotlin | Cube-sphere quadtree LOD, frustum + horizon culling, camera-relative double-precision rendering, pooled direct buffers, worker threads, LRU GPU cache, debug overlay. |

Generation is deterministic: the same seed + parameters give the same planet (verified bit-identical across -O1/-O2/-O3 builds).
