package com.livingworld.simulator

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns the native world and a single background simulation thread. All heavy work (planet generation,
 * geological steps) runs there; the UI and GL threads only read small snapshots.
 */
class Sim {
    val handle: Long = NativeBridge.nCreate()
    private val exec = Executors.newSingleThreadExecutor { r ->
        val t = Thread(r, "lw-sim")
        t.isDaemon = true
        t.priority = Thread.NORM_PRIORITY - 1
        t
    }
    val busy = AtomicBoolean(false)
    @Volatile var ready = false
    @Volatile var epoch = 0          // bumps when the terrain itself changes (new planet / geological step)
    @Volatile var stamp = 0          // bumps when seasonal visuals should refresh
    @Volatile var layer = 0
        set(v) { field = v; stamp++ }
    @Volatile var busyTitle = ""
    @Volatile var lastError = ""
    @Volatile var radiusM = 6371000.0
    @Volatile var seedText = ""

    private val lock = Any()
    private val sun = doubleArrayOf(1.0, 0.0, 0.0, 0.0)
    private val info = DoubleArray(16)
    private val tmpSun = DoubleArray(4)
    private val tmpInfo = DoubleArray(16)
    private var lastStampFrac = 0.0

    val cloudW = 512
    val cloudH = 256
    private val cloudLock = Any()
    private var cloudFront: ByteBuffer = ByteBuffer.allocateDirect(512 * 256).order(ByteOrder.nativeOrder())
    private var cloudBack: ByteBuffer = ByteBuffer.allocateDirect(512 * 256).order(ByteOrder.nativeOrder())
    private var cloudDirty = false

    fun getSun(out: DoubleArray) {
        synchronized(lock) { System.arraycopy(sun, 0, out, 0, 4) }
    }

    fun getInfo(out: DoubleArray) {
        synchronized(lock) { System.arraycopy(info, 0, out, 0, 16) }
    }

    fun uploadCloudsIfDirty(action: (ByteBuffer) -> Unit): Boolean {
        synchronized(cloudLock) {
            if (!cloudDirty) return false
            action(cloudFront)
            cloudDirty = false
            return true
        }
    }

    fun generate(seed: String, params: DoubleArray) {
        if (!busy.compareAndSet(false, true)) return
        busyTitle = "Generating planet"
        seedText = seed
        exec.execute {
            try {
                ready = false
                NativeBridge.nGenerate(handle, seed, params)
                refresh(true)
                lastStampFrac = info[1]
                epoch++
                ready = true
            } catch (t: Throwable) {
                lastError = t.toString()
            } finally {
                busy.set(false)
            }
        }
    }

    fun advance(years: Double) {
        if (!ready || !busy.compareAndSet(false, true)) return
        busyTitle = if (years >= 4.0e5) "Moving continents (plate tectonics)" else if (years >= 100.0) "Slow processes: ice, soils, vegetation" else "Simulating"
        exec.execute {
            try {
                NativeBridge.nAdvance(handle, years)
                NativeBridge.nInfo(handle, tmpInfo)
                var d = tmpInfo[1] - lastStampFrac
                if (d < 0) d += 1.0
                val big = years >= 1.0 || d >= 1.0 / 24.0
                if (big) lastStampFrac = tmpInfo[1]
                refresh(big)
                if (years >= 4.0e5) epoch++ else if (big) stamp++
            } catch (t: Throwable) {
                lastError = t.toString()
            } finally {
                busy.set(false)
            }
        }
    }

    fun shiftTimeOfDay(hours: Double) {
        if (!ready) return
        exec.execute {
            try {
                NativeBridge.nAddDayHours(handle, hours)
                refresh(false)
            } catch (t: Throwable) {
                lastError = t.toString()
            }
        }
    }

    private fun refresh(clouds: Boolean) {
        NativeBridge.nSunDir(handle, tmpSun)
        NativeBridge.nInfo(handle, tmpInfo)
        synchronized(lock) {
            System.arraycopy(tmpSun, 0, sun, 0, 4)
            System.arraycopy(tmpInfo, 0, info, 0, 16)
        }
        radiusM = tmpInfo[8] * 1000.0
        if (clouds && NativeBridge.nBuildClouds(handle, cloudW, cloudH, cloudBack)) {
            synchronized(cloudLock) {
                val t = cloudFront
                cloudFront = cloudBack
                cloudBack = t
                cloudDirty = true
            }
        }
    }

    fun progress(): Float = NativeBridge.nProgress(handle)
    fun stage(): String = NativeBridge.nStage(handle)
    fun inspect(lat: Double, lon: Double): String = if (ready) NativeBridge.nInspect(handle, lat, lon, layer) else ""
    fun explain(lat: Double, lon: Double): String = if (ready) NativeBridge.nExplain(handle, lat, lon) else ""
    fun stats(out: DoubleArray) = NativeBridge.nStats(handle, out)

    fun shutdown() {
        exec.shutdownNow()
    }
}
