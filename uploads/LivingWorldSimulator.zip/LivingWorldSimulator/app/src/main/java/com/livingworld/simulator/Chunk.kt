package com.livingworld.simulator

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.sqrt

/** CPU-side buffers filled by the native builder, recycled through a pool (no per-chunk allocation). */
class BufSet {
    val vtx: ByteBuffer = ByteBuffer.allocateDirect(Const.VERT_COUNT * Const.VERT_BYTES).order(ByteOrder.nativeOrder())
    val alb: ByteBuffer = ByteBuffer.allocateDirect(Const.ALBEDO_BYTES).order(ByteOrder.nativeOrder())
    val nrm: ByteBuffer = ByteBuffer.allocateDirect(Const.NORMAL_BYTES).order(ByteOrder.nativeOrder())
    val meta = DoubleArray(9)
}

/** One quadtree node of a cube face. Geometry for culling/LOD is analytic; mesh+textures stream in. */
class Chunk(val face: Int, val level: Int, val x: Int, val y: Int, val parent: Chunk?, R: Double) {
    val kids = arrayOfNulls<Chunk>(4)

    // unit direction of the chunk centre, bounding radius (m), nominal edge length (m)
    val cx: Double
    val cy: Double
    val cz: Double
    val radius: Double
    val edgeM: Double

    // streaming state
    @Volatile var state = 0            // 0 idle, 1 queued, 2 building, 3 built (awaiting upload)
    @Volatile var wanted = 0L
    @Volatile var discarded = false
    @Volatile var retryAt = 0L
    var lastUsed = 0L
    var bufs: BufSet? = null
    var pendGen = 0
    var pendStamp = 0
    var pendLayer = 0

    // GPU
    var hasGpu = false
    var vao = 0
    var vbo = 0
    var texA = 0
    var texN = 0
    var builtGen = -1
    var builtStamp = -1
    var builtLayer = -1

    init {
        val n = 1 shl level
        val size = 2.0 / n
        val u0 = -1.0 + x * size
        val v0 = -1.0 + y * size
        val c = DoubleArray(3)
        Cube.faceDir(face, u0 + size * 0.5, v0 + size * 0.5, c)
        cx = c[0]; cy = c[1]; cz = c[2]
        var far = 0.0
        val q = DoubleArray(3)
        for (k in 0 until 4) {
            Cube.faceDir(face, u0 + (k and 1) * size, v0 + (k shr 1) * size, q)
            val dx = q[0] - c[0]
            val dy = q[1] - c[1]
            val dz = q[2] - c[2]
            far = max(far, sqrt(dx * dx + dy * dy + dz * dz))
        }
        radius = far * R * 1.02 + 12000.0
        val a = DoubleArray(3)
        val b = DoubleArray(3)
        Cube.faceDir(face, u0, v0 + size * 0.5, a)
        Cube.faceDir(face, u0 + size, v0 + size * 0.5, b)
        val ex = a[0] - b[0]
        val ey = a[1] - b[1]
        val ez = a[2] - b[2]
        edgeM = sqrt(ex * ex + ey * ey + ez * ez) * R
    }
}
