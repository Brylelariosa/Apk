package com.livingworld.simulator

import android.opengl.GLES20
import android.opengl.GLES30
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Streams terrain chunks: background workers call the native builder into pooled direct buffers,
 * the GL thread uploads a few per frame, and an LRU keeps GPU memory bounded.
 * Only the GL thread touches the tree and GPU resources; workers only touch chunk state flags.
 */
class ChunkManager(private val sim: Sim) {
    companion object {
        const val IDLE = 0
        const val QUEUED = 1
        const val BUILDING = 2
        const val BUILT = 3
    }

    var radiusM = 6371000.0
    val roots = arrayOfNulls<Chunk>(6)
    private val gpuList = ArrayList<Chunk>()
    private val uploadQ = ConcurrentLinkedQueue<Chunk>()
    private val workers: Int
    private val pool: ArrayBlockingQueue<BufSet>
    private val exec: ThreadPoolExecutor
    val activeJobs = AtomicInteger(0)
    val queuedJobs = AtomicInteger(0)

    @Volatile var frame = 0L
    @Volatile var gen = -1
    @Volatile var stamp = 0
    @Volatile var layer = 0
    var ibo = 0
    var maxGpuChunks = 420
    var uploadsThisFrame = 0

    init {
        val cores = Runtime.getRuntime().availableProcessors()
        workers = (cores / 2).coerceIn(1, 3)
        pool = ArrayBlockingQueue(workers + 10)
        for (i in 0 until workers + 10) pool.add(BufSet())
        val factory = ThreadFactory { r ->
            val t = Thread(r, "lw-chunk")
            t.isDaemon = true
            t.priority = Thread.NORM_PRIORITY - 1
            t
        }
        exec = ThreadPoolExecutor(workers, workers, 0L, TimeUnit.MILLISECONDS, PriorityBlockingQueue<Runnable>(), factory)
    }

    val workerCount: Int get() = workers
    val gpuChunkCount: Int get() = gpuList.size

    fun root(face: Int): Chunk {
        var r = roots[face]
        if (r == null) {
            r = Chunk(face, 0, 0, 0, null, radiusM)
            roots[face] = r
        }
        return r
    }

    fun child(p: Chunk, i: Int): Chunk {
        var c = p.kids[i]
        if (c == null) {
            c = Chunk(p.face, p.level + 1, p.x * 2 + (i and 1), p.y * 2 + (i shr 1), p, radiusM)
            p.kids[i] = c
        }
        return c
    }

    fun isStale(c: Chunk): Boolean = c.builtGen != gen || c.builtStamp != stamp || c.builtLayer != layer

    fun request(c: Chunk, prio: Double) {
        if (c.state != IDLE || c.discarded) return
        if (frame < c.retryAt) return
        c.state = QUEUED
        c.wanted = frame
        queuedJobs.incrementAndGet()
        exec.execute(Job(c, prio))
    }

    private inner class Job(val c: Chunk, val prio: Double) : Runnable, Comparable<Job> {
        override fun compareTo(other: Job): Int = prio.compareTo(other.prio)

        override fun run() {
            queuedJobs.decrementAndGet()
            if (c.discarded || frame - c.wanted > 45L) {
                c.state = IDLE
                return
            }
            var got: BufSet? = null
            while (got == null) {
                got = pool.poll(50, TimeUnit.MILLISECONDS)
                if (c.discarded) {
                    if (got != null) pool.offer(got)
                    c.state = IDLE
                    return
                }
            }
            val bs: BufSet = got ?: return
            c.state = BUILDING
            activeJobs.incrementAndGet()
            val g = gen
            val st = stamp
            val ly = layer
            var ok = false
            try {
                ok = NativeBridge.nBuildChunk(sim.handle, c.face, c.level, c.x, c.y, ly, bs.vtx, bs.alb, bs.nrm, bs.meta)
            } catch (t: Throwable) {
                ok = false
            }
            activeJobs.decrementAndGet()
            if (!ok || c.discarded) {
                pool.offer(bs)
                if (!ok) c.retryAt = frame + 90L
                c.state = IDLE
                return
            }
            c.bufs = bs
            c.pendGen = g
            c.pendStamp = st
            c.pendLayer = ly
            c.state = BUILT
            uploadQ.add(c)
        }
    }

    // ------------------------------------------------------------------------------------------
    // GL thread
    // ------------------------------------------------------------------------------------------
    private val one = IntArray(1)

    fun processUploads(budgetNs: Long) {
        val t0 = System.nanoTime()
        uploadsThisFrame = 0
        while (true) {
            val c = uploadQ.poll() ?: break
            val bs = c.bufs
            c.bufs = null
            if (bs == null) continue
            if (c.discarded) {
                pool.offer(bs)
                continue
            }
            upload(c, bs)
            pool.offer(bs)
            c.builtGen = c.pendGen
            c.builtStamp = c.pendStamp
            c.builtLayer = c.pendLayer
            c.state = IDLE
            uploadsThisFrame++
            if (System.nanoTime() - t0 > budgetNs) break
        }
    }

    private fun upload(c: Chunk, bs: BufSet) {
        val first = !c.hasGpu
        if (first) {
            GLES30.glGenVertexArrays(1, one, 0); c.vao = one[0]
            GLES20.glGenBuffers(1, one, 0); c.vbo = one[0]
            GLES20.glGenTextures(1, one, 0); c.texA = one[0]
            GLES20.glGenTextures(1, one, 0); c.texN = one[0]
        }
        GLES30.glBindVertexArray(c.vao)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, c.vbo)
        bs.vtx.position(0)
        bs.vtx.limit(Const.VERT_COUNT * Const.VERT_BYTES)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, Const.VERT_COUNT * Const.VERT_BYTES, bs.vtx, GLES20.GL_STATIC_DRAW)
        if (first) {
            GLES20.glEnableVertexAttribArray(0)
            GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, Const.VERT_BYTES, 0)
            GLES20.glEnableVertexAttribArray(1)
            GLES20.glVertexAttribPointer(1, 2, GLES20.GL_UNSIGNED_SHORT, true, Const.VERT_BYTES, 12)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo)
        }
        GLES30.glBindVertexArray(0)

        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, c.texA)
        bs.alb.position(0)
        bs.alb.limit(Const.ALBEDO_BYTES)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, Const.D, Const.D, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, bs.alb)
        if (first) texParams()
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, c.texN)
        bs.nrm.position(0)
        bs.nrm.limit(Const.NORMAL_BYTES)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES30.GL_RG8, Const.D, Const.D, 0, GLES30.GL_RG, GLES20.GL_UNSIGNED_BYTE, bs.nrm)
        if (first) texParams()
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)

        if (first) {
            c.hasGpu = true
            gpuList.add(c)
        }
    }

    private fun texParams() {
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    private fun freeGpu(c: Chunk, contextAlive: Boolean) {
        if (contextAlive && c.hasGpu) {
            one[0] = c.vao; GLES30.glDeleteVertexArrays(1, one, 0)
            one[0] = c.vbo; GLES20.glDeleteBuffers(1, one, 0)
            one[0] = c.texA; GLES20.glDeleteTextures(1, one, 0)
            one[0] = c.texN; GLES20.glDeleteTextures(1, one, 0)
        }
        c.hasGpu = false
        c.vao = 0; c.vbo = 0; c.texA = 0; c.texN = 0
        c.builtGen = -1
    }

    /** New planet / geological step / lost GL context: drop everything and start a fresh tree. */
    fun hardReset(newGen: Int, contextAlive: Boolean) {
        for (c in gpuList) freeGpu(c, contextAlive)
        gpuList.clear()
        for (i in 0 until 6) {
            markDiscarded(roots[i])
            roots[i] = null
        }
        gen = newGen
    }

    private fun markDiscarded(c: Chunk?) {
        if (c == null) return
        c.discarded = true
        for (k in c.kids) markDiscarded(k)
    }

    /** LRU eviction of GPU chunks and pruning of unused tree nodes. */
    fun evict() {
        if (gpuList.size > maxGpuChunks) {
            val cand = ArrayList<Chunk>()
            for (c in gpuList) if (c.level > 1 && frame - c.lastUsed > 4L) cand.add(c)
            cand.sortBy { it.lastUsed }
            var excess = gpuList.size - maxGpuChunks
            var i = 0
            while (excess > 0 && i < cand.size) {
                val c = cand[i++]
                gpuList.remove(c)
                freeGpu(c, true)
                excess--
            }
        }
        if (frame % 240L == 0L) for (r in roots) prune(r)
    }

    private fun prune(c: Chunk?): Boolean {
        if (c == null) return false
        var keep = c.hasGpu || c.state != IDLE || frame - c.lastUsed < 600L
        for (i in 0 until 4) {
            val k = c.kids[i] ?: continue
            if (prune(k)) keep = true else {
                k.discarded = true
                c.kids[i] = null
            }
        }
        return keep
    }

    fun shutdown() {
        exec.shutdownNow()
    }
}
