package com.livingworld.simulator

import android.opengl.Matrix
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Orbit camera around a point on the globe. Everything is kept in double precision and the view is
 * rendered camera-relative, so there is no jitter from planet-scale coordinates down to metres.
 */
class Camera {
    var radius = 6371000.0           // planet radius (m)
    // target on the globe
    private var cx = 1.0
    private var cy = 0.0
    private var cz = 0.0
    private var heading = 0.0        // radians clockwise from north
    private var tilt = 0.0           // 0 = looking straight down
    private var dist = 2.6e7         // camera distance from the target (m)
    var targetHeight = 0.0           // terrain height under the target (m)
    private var flingVx = 0.0
    private var flingVy = 0.0

    val fovY = 50.0 * PI / 180.0

    // derived (valid after update())
    val pos = DoubleArray(3)
    val fwd = DoubleArray(3)
    val up = DoubleArray(3)
    val right = DoubleArray(3)
    var altitude = 0.0
    var posLen = 0.0
    var near = 1.0f
    var far = 1e7f
    val viewRot = FloatArray(16)
    val proj = FloatArray(16)
    val vp = FloatArray(16)
    private val planes = FloatArray(24)
    var focalPx = 1000.0
    val lat: Double get() = asin(cz.coerceIn(-1.0, 1.0)) * 180.0 / PI
    val lon: Double get() = atan2(cy, cx) * 180.0 / PI

    @Synchronized
    fun setCenter(latDeg: Double, lonDeg: Double) {
        val la = latDeg * PI / 180.0
        val lo = lonDeg * PI / 180.0
        cx = cos(la) * cos(lo); cy = cos(la) * sin(lo); cz = sin(la)
    }

    @Synchronized
    fun reset(R: Double) {
        radius = R
        dist = R * 4.0
        tilt = 0.0
        heading = 0.0
        flingVx = 0.0; flingVy = 0.0
    }

    @Synchronized
    fun stopFling() {
        flingVx = 0.0; flingVy = 0.0
    }

    @Synchronized
    fun startFling(vx: Float, vy: Float) {
        flingVx = vx.toDouble(); flingVy = vy.toDouble()
    }

    private fun basis(e: DoubleArray, n: DoubleArray) {
        // east = Z x c, north = c x east
        var ex = -cy
        var ey = cx
        val ez = 0.0
        var l = sqrt(ex * ex + ey * ey)
        if (l < 1e-9) { ex = 0.0; ey = 1.0; l = 1.0 }
        ex /= l; ey /= l
        e[0] = ex; e[1] = ey; e[2] = ez
        n[0] = cy * ez - cz * ey
        n[1] = cz * ex - cx * ez
        n[2] = cx * ey - cy * ex
    }

    private val tmpE = DoubleArray(3)
    private val tmpN = DoubleArray(3)

    /** Drag in screen pixels (finger moves dx right, dy down). */
    @Synchronized
    fun pan(dx: Float, dy: Float, viewH: Int) {
        val mpp = 2.0 * dist * tan(fovY / 2.0) / max(1, viewH)
        basis(tmpE, tmpN)
        val hx = sin(heading) * tmpE[0] + cos(heading) * tmpN[0]
        val hy = sin(heading) * tmpE[1] + cos(heading) * tmpN[1]
        val hz = sin(heading) * tmpE[2] + cos(heading) * tmpN[2]
        // ground-right = h x c
        val rx = hy * cz - hz * cy
        val ry = hz * cx - hx * cz
        val rz = hx * cy - hy * cx
        val mx = (-dx * rx + dy * hx) * mpp
        val my = (-dx * ry + dy * hy) * mpp
        val mz = (-dx * rz + dy * hz) * mpp
        val len = sqrt(mx * mx + my * my + mz * mz)
        if (len < 1e-9) return
        val a = len / (radius + targetHeight)
        val ca = cos(a)
        val sa = sin(a)
        var nx = cx * ca + mx / len * sa
        var ny = cy * ca + my / len * sa
        var nz = cz * ca + mz / len * sa
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        nx /= l; ny /= l; nz /= l
        cx = nx; cy = ny; cz = nz
    }

    @Synchronized
    fun zoomBy(factor: Double) {
        dist = (dist * factor).coerceIn(minDist(), radius * 4.6)
    }

    @Synchronized
    fun rotateHeading(d: Double) {
        heading += d
    }

    @Synchronized
    fun tiltBy(d: Double) {
        tilt = (tilt + d).coerceIn(0.0, 1.35)
    }

    private fun minDist(): Double = 60.0

    /** Per-frame inertia. */
    @Synchronized
    fun stepFling(dt: Double, viewH: Int) {
        if (abs(flingVx) + abs(flingVy) < 8.0) { flingVx = 0.0; flingVy = 0.0; return }
        pan((flingVx * dt).toFloat(), (flingVy * dt).toFloat(), viewH)
        val k = exp(-3.2 * dt)
        flingVx *= k; flingVy *= k
    }

    @Synchronized
    fun update(aspect: Double) {
        // tilt is only meaningful when close to the ground
        val tiltMax = 1.35 * (1.0 - smooth(0.4 * radius, 1.6 * radius, dist))
        if (tilt > tiltMax) tilt += (tiltMax - tilt) * 0.2
        basis(tmpE, tmpN)
        val sh = sin(heading)
        val ch = cos(heading)
        val hx = sh * tmpE[0] + ch * tmpN[0]
        val hy = sh * tmpE[1] + ch * tmpN[1]
        val hz = sh * tmpE[2] + ch * tmpN[2]
        val st = sin(tilt)
        val ct = cos(tilt)
        val tr = radius + targetHeight
        val tx = cx * tr
        val ty = cy * tr
        val tz = cz * tr
        pos[0] = tx + dist * (ct * cx - st * hx)
        pos[1] = ty + dist * (ct * cy - st * hy)
        pos[2] = tz + dist * (ct * cz - st * hz)
        fwd[0] = -ct * cx + st * hx
        fwd[1] = -ct * cy + st * hy
        fwd[2] = -ct * cz + st * hz
        up[0] = st * cx + ct * hx
        up[1] = st * cy + ct * hy
        up[2] = st * cz + ct * hz
        right[0] = fwd[1] * up[2] - fwd[2] * up[1]
        right[1] = fwd[2] * up[0] - fwd[0] * up[2]
        right[2] = fwd[0] * up[1] - fwd[1] * up[0]
        posLen = sqrt(pos[0] * pos[0] + pos[1] * pos[1] + pos[2] * pos[2])
        altitude = max(1.0, posLen - (radius + targetHeight))
        val horizon = sqrt(max(0.0, posLen * posLen - radius * radius))
        near = max(1.0, min(altitude * 0.12, 3.0e6)).toFloat()
        far = min(horizon + 400000.0, posLen + radius).toFloat().coerceAtLeast(near * 20f)
        java.util.Arrays.fill(viewRot, 0f)
        viewRot[0] = right[0].toFloat(); viewRot[4] = right[1].toFloat(); viewRot[8] = right[2].toFloat()
        viewRot[1] = up[0].toFloat(); viewRot[5] = up[1].toFloat(); viewRot[9] = up[2].toFloat()
        viewRot[2] = (-fwd[0]).toFloat(); viewRot[6] = (-fwd[1]).toFloat(); viewRot[10] = (-fwd[2]).toFloat()
        viewRot[15] = 1f
        Matrix.perspectiveM(proj, 0, (fovY * 180.0 / PI).toFloat(), aspect.toFloat(), near, far)
        Matrix.multiplyMM(vp, 0, proj, 0, viewRot, 0)
        // frustum planes (camera-relative space)
        for (i in 0 until 4) {
            val s = if (i % 2 == 0) 1f else -1f
            val r = i / 2          // 0: x planes, 1: y planes
            for (k in 0 until 4) planes[i * 4 + k] = vp[k * 4 + 3] + s * vp[k * 4 + r]
        }
        for (k in 0 until 4) {
            planes[16 + k] = vp[k * 4 + 3] + vp[k * 4 + 2]
            planes[20 + k] = vp[k * 4 + 3] - vp[k * 4 + 2]
        }
        for (i in 0 until 6) {
            val a = planes[i * 4]; val b = planes[i * 4 + 1]; val c = planes[i * 4 + 2]
            val l = sqrt(a * a + b * b + c * c)
            if (l > 0f) { planes[i * 4] /= l; planes[i * 4 + 1] /= l; planes[i * 4 + 2] /= l; planes[i * 4 + 3] /= l }
        }
    }

    /** Is a sphere (centre relative to the camera, radius in metres) possibly inside the frustum? */
    fun sphereVisible(x: Double, y: Double, z: Double, r: Double): Boolean {
        for (i in 0 until 6) {
            val d = planes[i * 4] * x + planes[i * 4 + 1] * y + planes[i * 4 + 2] * z + planes[i * 4 + 3]
            if (d < -r) return false
        }
        return true
    }

    fun centerDir(out: DoubleArray) {
        out[0] = cx; out[1] = cy; out[2] = cz
    }

    private fun smooth(a: Double, b: Double, x: Double): Double {
        val t = ((x - a) / (b - a)).coerceIn(0.0, 1.0)
        return t * t * (3.0 - 2.0 * t)
    }
}
