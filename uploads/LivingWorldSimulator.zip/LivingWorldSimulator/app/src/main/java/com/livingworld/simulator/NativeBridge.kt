package com.livingworld.simulator

import java.nio.ByteBuffer

/** JNI surface of the native planet simulation (see src/main/cpp). */
object NativeBridge {
    init {
        System.loadLibrary("livingworld")
    }

    external fun nCreate(): Long
    external fun nDestroy(h: Long)
    external fun nDefaultParams(out: DoubleArray)
    external fun nGenerate(h: Long, seed: String, params: DoubleArray)
    external fun nAdvance(h: Long, years: Double)
    external fun nAddDayHours(h: Long, hours: Double)
    external fun nProgress(h: Long): Float
    external fun nStage(h: Long): String
    external fun nGeneration(h: Long): Int
    external fun nBuildChunk(
        h: Long, face: Int, level: Int, cx: Int, cy: Int, layer: Int,
        vtx: ByteBuffer, albedo: ByteBuffer, normal: ByteBuffer, meta: DoubleArray
    ): Boolean
    external fun nBuildClouds(h: Long, w: Int, hgt: Int, out: ByteBuffer): Boolean
    external fun nSunDir(h: Long, out: DoubleArray)
    external fun nInfo(h: Long, out: DoubleArray): Boolean
    external fun nStats(h: Long, out: DoubleArray)
    external fun nInspect(h: Long, lat: Double, lon: Double, layer: Int): String
    external fun nExplain(h: Long, lat: Double, lon: Double): String
    external fun nHeightAt(h: Long, lat: Double, lon: Double): Double
}
