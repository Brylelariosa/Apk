package com.livingworld.simulator

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.security.SecureRandom
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var sim: Sim
    private lateinit var renderer: GlobeRenderer
    private lateinit var glView: GlobeSurfaceView
    private lateinit var prefs: SharedPreferences
    private val ui = Handler(Looper.getMainLooper())

    private var seed = "EARTH-7F42A91C"
    private val params = DoubleArray(12)
    private var running = false
    private var speedIdx = 1
    private var debugOn = false
    private var tickCount = 0
    private var pssMb = 0L
    private var lastPssMs = 0L

    private val scaleNames = arrayOf("1 day", "1 month", "1 year", "10 years", "100 years", "1,000 years", "1 million years")
    private val scaleYears = doubleArrayOf(1.0 / 365.25, 1.0 / 12.0, 1.0, 10.0, 100.0, 1000.0, 1.0e6)

    // widgets
    private lateinit var tvSeed: TextView
    private lateinit var tvYear: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvPress: TextView
    private lateinit var tvOcean: TextView
    private lateinit var tvTilt: TextView
    private lateinit var tvRot: TextView
    private lateinit var btnSimulate: TextView
    private lateinit var btnPause: TextView
    private lateinit var btnSpeed: TextView
    private lateinit var tvDebug: TextView
    private lateinit var layerBox: ScrollView
    private lateinit var layerList: LinearLayout
    private lateinit var reticle: TextView
    private lateinit var loading: FrameLayout
    private lateinit var loadTitle: TextView
    private lateinit var loadStage: TextView
    private lateinit var loadBar: ProgressBar
    private lateinit var tvError: TextView
    private val layerViews = ArrayList<TextView>()
    private val info = DoubleArray(16)
    private val stats = DoubleArray(10)

    private fun dp(v: Float): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun pill(text: String, sp: Float = 12f): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10f), dp(7f), dp(10f), dp(7f))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(190, 18, 28, 52))
        bg.setStroke(dp(1f), Color.argb(120, 140, 170, 230))
        bg.cornerRadius = dp(9f).toFloat()
        t.background = bg
        t.isClickable = true
        return t
    }

    private fun label(text: String, sp: Float = 12f, mono: Boolean = false, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (mono) t.typeface = Typeface.MONOSPACE
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun panelBg(): GradientDrawable {
        val bg = GradientDrawable()
        bg.setColor(Color.argb(150, 6, 12, 28))
        bg.cornerRadius = dp(10f).toFloat()
        return bg
    }

    private fun randomSeed(): String {
        val r = SecureRandom()
        return String.format(Locale.US, "EARTH-%08X", r.nextInt())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("lw", Context.MODE_PRIVATE)
        NativeBridge.nDefaultParams(params)
        val saved = prefs.getString("params", null)
        if (saved != null) {
            val parts = saved.split(",")
            if (parts.size == params.size) for (i in params.indices) parts[i].toDoubleOrNull()?.let { params[i] = it }
        }
        seed = prefs.getString("seed", seed) ?: seed

        sim = Sim()
        renderer = GlobeRenderer(sim)
        glView = GlobeSurfaceView(this, renderer)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(glView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        buildInfoPanel(root)
        buildDebugPanel(root)
        buildBottomBar(root)
        buildLoading(root)
        setContentView(root)
        startGenerate(false)
    }

    // ------------------------------------------------------------------------------------------ UI
    private fun buildInfoPanel(root: FrameLayout) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = panelBg()
        box.setPadding(dp(10f), dp(8f), dp(10f), dp(8f))
        box.addView(label("PLANET", 13f, bold = true))
        tvSeed = label("", 11f); box.addView(tvSeed)
        tvYear = label("", 11f); box.addView(tvYear)
        tvTemp = label("", 11f); box.addView(tvTemp)
        tvPress = label("", 11f); box.addView(tvPress)
        tvOcean = label("", 11f); box.addView(tvOcean)
        tvTilt = label("", 11f); box.addView(tvTilt)
        tvRot = label("", 11f); box.addView(tvRot)
        btnSimulate = pill("SIMULATE", 12f)
        btnSimulate.setOnClickListener { setRunning(!running) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6f)
        box.addView(btnSimulate, lp)
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
        flp.setMargins(dp(10f), dp(26f), 0, 0)
        root.addView(box, flp)
    }

    private fun buildDebugPanel(root: FrameLayout) {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.END
        val dbg = pill("DEBUG", 11f)
        dbg.setOnClickListener { setDebug(!debugOn) }
        col.addView(dbg)
        tvDebug = label("", 9f, mono = true)
        tvDebug.background = panelBg()
        tvDebug.setPadding(dp(6f), dp(4f), dp(6f), dp(4f))
        tvDebug.visibility = View.GONE
        val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = dp(4f)
        col.addView(tvDebug, dlp)
        layerBox = ScrollView(this)
        layerList = LinearLayout(this)
        layerList.orientation = LinearLayout.VERTICAL
        layerBox.addView(layerList)
        layerBox.visibility = View.GONE
        for (i in Layers.names.indices) {
            val t = pill(Layers.names[i], 10f)
            t.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            t.setOnClickListener { selectLayer(i) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(3f)
            layerList.addView(t, lp)
            layerViews.add(t)
        }
        selectLayer(0)
        val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(210f))
        llp.topMargin = dp(4f)
        col.addView(layerBox, llp)
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        flp.setMargins(0, dp(26f), dp(10f), 0)
        root.addView(col, flp)

        reticle = label("+", 22f)
        reticle.visibility = View.GONE
        root.addView(reticle, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        tvError = label("", 10f, mono = true)
        tvError.setTextColor(Color.rgb(255, 120, 120))
        tvError.visibility = View.GONE
        val elp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        elp.bottomMargin = dp(62f)
        root.addView(tvError, elp)
    }

    private fun buildBottomBar(root: FrameLayout) {
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(8f), dp(4f), dp(8f), dp(8f))
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(6f)
            bar.addView(v, lp)
        }
        val bNew = pill("Generate New Planet")
        bNew.setOnClickListener { seed = randomSeed(); startGenerate(true) }
        add(bNew)
        val bRegen = pill("Regenerate From Seed")
        bRegen.setOnClickListener { startGenerate(true) }
        add(bRegen)
        val bSeed = pill("Seed")
        bSeed.setOnClickListener { seedDialog() }
        add(bSeed)
        btnPause = pill("Pause")
        btnPause.setOnClickListener { setRunning(false) }
        add(btnPause)
        btnSpeed = pill("")
        btnSpeed.setOnClickListener { speedIdx = (speedIdx + 1) % scaleNames.size; updateSpeedLabel() }
        add(btnSpeed)
        val bStep = pill("Step")
        bStep.setOnClickListener { sim.advance(scaleYears[speedIdx]) }
        add(bStep)
        val bSun = pill("Sun +6h")
        bSun.setOnClickListener { sim.shiftTimeOfDay(6.0) }
        add(bSun)
        val bWhy = pill("Why?")
        bWhy.setOnClickListener { whyDialog() }
        add(bWhy)
        val bPar = pill("Planet parameters")
        bPar.setOnClickListener { paramsDialog() }
        add(bPar)
        scroll.addView(bar)
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        updateSpeedLabel()
        setRunning(false)
    }

    private fun buildLoading(root: FrameLayout) {
        loading = FrameLayout(this)
        loading.setBackgroundColor(Color.argb(215, 2, 6, 16))
        loading.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        loadTitle = label("Generating planet", 18f, bold = true)
        col.addView(loadTitle)
        loadStage = label("", 12f)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(8f)
        col.addView(loadStage, slp)
        loadBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        loadBar.max = 1000
        val blp = LinearLayout.LayoutParams(dp(240f), dp(10f))
        blp.topMargin = dp(12f)
        col.addView(loadBar, blp)
        val hint = label("Drag: rotate  -  Pinch: zoom  -  Two-finger drag: tilt / twist", 11f)
        hint.setTextColor(Color.argb(200, 170, 190, 230))
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.topMargin = dp(18f)
        col.addView(hint, hlp)
        loading.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        root.addView(loading, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ------------------------------------------------------------------------------------------ actions
    private fun startGenerate(save: Boolean) {
        if (sim.busy.get()) return
        if (save) saveState()
        prefs.edit().putString("seed", seed).apply()
        setRunning(false)
        sim.generate(seed, params.copyOf())
        loading.visibility = View.VISIBLE
        loadTitle.text = "Generating planet"
    }

    private fun saveState() {
        prefs.edit().putString("seed", seed).putString("params", params.joinToString(",") { String.format(Locale.US, "%.6f", it) }).apply()
    }

    private fun setRunning(on: Boolean) {
        running = on
        btnSimulate.text = if (on) "PAUSE" else "SIMULATE"
        btnPause.alpha = if (on) 1.0f else 0.5f
    }

    private fun updateSpeedLabel() {
        btnSpeed.text = "Speed: " + scaleNames[speedIdx] + "/s"
    }

    private fun setDebug(on: Boolean) {
        debugOn = on
        val v = if (on) View.VISIBLE else View.GONE
        tvDebug.visibility = v
        layerBox.visibility = v
        reticle.visibility = v
    }

    private fun selectLayer(i: Int) {
        sim.layer = i
        for (k in layerViews.indices) layerViews[k].alpha = if (k == i) 1.0f else 0.62f
    }

    private fun seedDialog() {
        val et = EditText(this)
        et.setText(seed)
        et.setSelectAllOnFocus(true)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        AlertDialog.Builder(this)
            .setTitle("World seed")
            .setMessage("The same seed always rebuilds the same planet (with the same planet parameters).")
            .setView(et)
            .setPositiveButton("Regenerate") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) { seed = s; startGenerate(true) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun whyDialog() {
        val text = sim.explain(renderer.camLat, renderer.camLon)
        val tv = TextView(this)
        tv.text = text
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        tv.setPadding(dp(18f), dp(10f), dp(18f), dp(10f))
        val sv = ScrollView(this)
        sv.addView(tv)
        val title = String.format(Locale.US, "Why is this here?  %.1f%s %.1f%s", Math.abs(renderer.camLat), if (renderer.camLat >= 0) "N" else "S", Math.abs(renderer.camLon), if (renderer.camLon >= 0) "E" else "W")
        AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show()
    }

    private class PRow(val name: String, val idx: Int, val min: Double, val max: Double, val step: Double, val fmt: String)

    private fun paramsDialog() {
        val rows = listOf(
            PRow("Radius (km)", 0, 2000.0, 12000.0, 250.0, "%.0f"),
            PRow("Gravity (m/s2)", 1, 3.0, 30.0, 0.5, "%.1f"),
            PRow("Rotation (hours)", 2, 6.0, 96.0, 2.0, "%.0f"),
            PRow("Orbit (days)", 3, 100.0, 1500.0, 20.0, "%.0f"),
            PRow("Axial tilt (deg)", 4, 0.0, 85.0, 2.5, "%.1f"),
            PRow("Solar intensity (x)", 5, 0.6, 1.5, 0.05, "%.2f"),
            PRow("Pressure (atm)", 6, 0.3, 3.0, 0.1, "%.1f"),
            PRow("Ocean coverage", 7, 0.2, 0.95, 0.05, "%.2f"),
            PRow("CO2 (ppm)", 8, 100.0, 4000.0, 100.0, "%.0f"),
            PRow("Salinity (PSU)", 9, 0.0, 50.0, 2.5, "%.1f"),
            PRow("Geothermal (x)", 10, 0.4, 3.0, 0.1, "%.1f"),
            PRow("Sea level offset (m)", 11, -200.0, 200.0, 25.0, "%.0f")
        )
        val work = params.copyOf()
        val valueViews = ArrayList<TextView>()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14f), dp(8f), dp(14f), dp(4f))
        fun refresh() {
            for (i in rows.indices) valueViews[i].text = String.format(Locale.US, rows[i].fmt, work[rows[i].idx])
        }
        val reset = TextView(this)
        reset.text = "Reset to Earth"
        reset.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        reset.setTextColor(Color.rgb(40, 110, 200))
        reset.setPadding(0, dp(4f), 0, dp(8f))
        reset.setOnClickListener { NativeBridge.nDefaultParams(work); refresh() }
        col.addView(reset)
        for (r in rows) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val name = TextView(this)
            name.text = r.name
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val minus = TextView(this)
            minus.text = "  -  "
            minus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            val value = TextView(this)
            value.gravity = Gravity.CENTER
            value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            val plus = TextView(this)
            plus.text = "  +  "
            plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            minus.setOnClickListener { work[r.idx] = (work[r.idx] - r.step).coerceIn(r.min, r.max); refresh() }
            plus.setOnClickListener { work[r.idx] = (work[r.idx] + r.step).coerceIn(r.min, r.max); refresh() }
            row.addView(minus)
            row.addView(value, LinearLayout.LayoutParams(dp(64f), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(plus)
            valueViews.add(value)
            col.addView(row)
        }
        refresh()
        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Planet parameters")
            .setView(sv)
            .setPositiveButton("Apply & regenerate") { _, _ ->
                for (i in params.indices) params[i] = work[i]
                startGenerate(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------------------------------ periodic updates
    private val tick = object : Runnable {
        override fun run() {
            tickCount++
            updateLoading()
            if (tickCount % 3 == 0) updatePanels()
            if (running && tickCount % 10 == 0) sim.advance(scaleYears[speedIdx])
            ui.postDelayed(this, 100L)
        }
    }

    private fun updateLoading() {
        val busy = sim.busy.get()
        val waiting = sim.ready && !renderer.rootsReady
        if (busy || waiting || !sim.ready) {
            loading.visibility = View.VISIBLE
            if (busy) {
                loadTitle.text = sim.busyTitle
                val st = sim.stage()
                loadStage.text = st
                loadBar.isIndeterminate = false
                loadBar.progress = (sim.progress() * 1000f).toInt().coerceIn(0, 1000)
            } else if (!sim.ready && sim.lastError.isNotEmpty()) {
                loadTitle.text = "Generation failed"
                loadStage.text = sim.lastError
                loadBar.isIndeterminate = false
            } else if (waiting) {
                loadTitle.text = "Building terrain tiles"
                loadStage.text = ""
                loadBar.isIndeterminate = true
            }
        } else {
            loading.visibility = View.GONE
        }
    }

    private fun fmtYears(y: Double): String {
        return if (y < 1.0e5) String.format(Locale.US, "%,d", y.toLong()) else String.format(Locale.US, "%.2f Myr", y / 1.0e6)
    }

    private fun updatePanels() {
        sim.getInfo(info)
        tvSeed.text = "Seed: " + seed
        val day = (info[1] * info[10]).toInt() + 1
        tvYear.text = "Year: " + fmtYears(Math.floor(info[0])) + "  -  Day " + day
        tvTemp.text = String.format(Locale.US, "Temperature: %.1f C (global mean)", info[3])
        tvPress.text = String.format(Locale.US, "Atmospheric Pressure: %.2f atm", info[4])
        tvOcean.text = String.format(Locale.US, "Ocean Coverage: %.0f %%", info[5] * 100.0)
        tvTilt.text = String.format(Locale.US, "Axial Tilt: %.1f deg", info[6])
        tvRot.text = String.format(Locale.US, "Rotation: %.1f h", info[7])
        val err = if (sim.lastError.isNotEmpty()) sim.lastError else renderer.shaderError
        if (err.isNotEmpty()) { tvError.text = err; tvError.visibility = View.VISIBLE } else tvError.visibility = View.GONE
        if (debugOn) updateDebug()
    }

    private fun updateDebug() {
        sim.stats(stats)
        val now = System.currentTimeMillis()
        if (now - lastPssMs > 2000L) {
            val mi = Debug.MemoryInfo()
            Debug.getMemoryInfo(mi)
            pssMb = mi.totalPss / 1024L
            lastPssMs = now
        }
        val rt = Runtime.getRuntime()
        val javaMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L
        val nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576L
        val mgr = renderer.mgr
        val sb = StringBuilder()
        sb.append(String.format(Locale.US, "FPS %.1f  frame %.1f ms\n", renderer.fps, renderer.frameMs))
        sb.append(String.format(Locale.US, "RAM pss %d MB  native %d  java %d\n", pssMb, nativeMb, javaMb))
        sb.append(String.format(Locale.US, "Chunks loaded %d  visible %d\n", mgr.gpuChunkCount, renderer.visibleChunks))
        sb.append(String.format(Locale.US, "Gen queue %d  workers %d/%d  up %d/f\n", mgr.queuedJobs.get(), mgr.activeJobs.get(), mgr.workerCount, renderer.uploadsPerFrame))
        sb.append(String.format(Locale.US, "Mesh+tex avg %.1f ms (n=%d)\n", stats[7], stats[8].toLong()))
        sb.append(String.format(Locale.US, "Sim step %.0f ms  climate %.0f ms/step\n", stats[4], stats[5]))
        sb.append(String.format(Locale.US, "Gen %.1f s: terrain %.1f climate %.1f\n", stats[0] / 1000.0, stats[1] / 1000.0, stats[2] / 1000.0))
        sb.append(String.format(Locale.US, "  rivers/soil/biomes %.1f s (est. rivers %.1f)\n", stats[3] / 1000.0, stats[6] / 1000.0))
        sb.append(String.format(Locale.US, "GPU tris %dk draws %d\n", renderer.trianglesDrawn / 1000, renderer.drawCalls))
        sb.append(renderer.gpuInfo.take(44)).append('\n')
        sb.append(String.format(Locale.US, "Cam alt %s  layer %s\n", fmtAlt(renderer.camAlt), Layers.names[sim.layer]))
        sb.append(String.format(Locale.US, "Water budget error %.1f%%\n", info[15] * 100.0))
        sb.append(sim.inspect(renderer.camLat, renderer.camLon))
        tvDebug.text = sb.toString()
    }

    private fun fmtAlt(m: Double): String = if (m >= 1.0e6) String.format(Locale.US, "%.0f km", m / 1000.0) else if (m >= 1.0e4) String.format(Locale.US, "%.1f km", m / 1000.0) else String.format(Locale.US, "%.0f m", m)

    // ------------------------------------------------------------------------------------------ lifecycle
    override fun onResume() {
        super.onResume()
        glView.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        renderer.shutdown()
        sim.shutdown()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }
}
