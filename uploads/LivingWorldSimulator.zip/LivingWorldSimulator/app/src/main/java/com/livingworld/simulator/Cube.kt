package com.livingworld.simulator

import kotlin.math.PI
import kotlin.math.sqrt
import kotlin.math.tan

/** Constants shared with the native chunk builder (chunk.h). */
object Const {
    const val G = 32
    const val VG = G + 1
    const val VERT_COUNT = VG * VG + 4 * VG
    const val VERT_BYTES = 16
    const val T = 96
    const val D = T + 2
    const val ALBEDO_BYTES = D * D * 4
    const val NORMAL_BYTES = D * D * 2
    const val INDEX_COUNT = G * G * 6 + 4 * G * 6
    const val MAX_LEVEL = 15
}

/** Debug layers, same order as the native Layer enum. */
object Layers {
    val names = arrayOf(
        "Visual", "Elevation", "Temperature", "Rainfall", "Wind", "Pressure",
        "Rivers", "Tectonic plates", "Plate boundaries", "Biomes", "Soil fertility", "Ocean depth"
    )
}

/** Cube-sphere face frames (must match grid.cpp). */
object Cube {
    val N = arrayOf(
        doubleArrayOf(1.0, 0.0, 0.0), doubleArrayOf(-1.0, 0.0, 0.0), doubleArrayOf(0.0, 1.0, 0.0),
        doubleArrayOf(0.0, -1.0, 0.0), doubleArrayOf(0.0, 0.0, 1.0), doubleArrayOf(0.0, 0.0, -1.0)
    )
    val T1 = arrayOf(
        doubleArrayOf(0.0, 1.0, 0.0), doubleArrayOf(0.0, -1.0, 0.0), doubleArrayOf(-1.0, 0.0, 0.0),
        doubleArrayOf(1.0, 0.0, 0.0), doubleArrayOf(1.0, 0.0, 0.0), doubleArrayOf(1.0, 0.0, 0.0)
    )
    val T2 = arrayOf(
        doubleArrayOf(0.0, 0.0, 1.0), doubleArrayOf(0.0, 0.0, 1.0), doubleArrayOf(0.0, 0.0, 1.0),
        doubleArrayOf(0.0, 0.0, 1.0), doubleArrayOf(0.0, 1.0, 0.0), doubleArrayOf(0.0, -1.0, 0.0)
    )

    fun faceDir(face: Int, u: Double, v: Double, out: DoubleArray) {
        val a = tan(u * PI / 4.0)
        val b = tan(v * PI / 4.0)
        val n = N[face]
        val t1 = T1[face]
        val t2 = T2[face]
        val x = n[0] + a * t1[0] + b * t2[0]
        val y = n[1] + a * t1[1] + b * t2[1]
        val z = n[2] + a * t1[2] + b * t2[2]
        val l = sqrt(x * x + y * y + z * z)
        out[0] = x / l
        out[1] = y / l
        out[2] = z / l
    }
}
