package com.livingworld.simulator

import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Renders the planet: cube-sphere quadtree of streamed chunks with camera-relative coordinates,
 * frustum + horizon culling, screen-space LOD, skirts for crack-free LOD borders, plus a cloud shell,
 * atmosphere glow and a star field.
 */
class GlobeRenderer(private val sim: Sim) : GLSurfaceView.Renderer {
    val cam = Camera()
    val mgr = ChunkManager(sim)

    // programs
    private var progTerrain = 0
    private var progCloud = 0
    private var progAtmo = 0
    private var progStar = 0
    private var uT = IntArray(12)
    private var uC = IntArray(8)
    private var uA = IntArray(6)
    private var uS = IntArray(3)

    // GL objects
    private var ibo = 0
    private var sphereVbo = 0
    private var sphereIbo = 0
    private var sphereIdx = 0
    private var starVbo = 0
    private val starCount = 900
    private var cloudTex = 0
    private var cloudsReady = false

    private var viewW = 1
    @Volatile var viewH = 1
    private var contextLost = true
    private var havePlanet = false
    private var frameNo = 0L
    private var lastNs = 0L
    private var cloudShift = 0f

    private val visible = ArrayList<Chunk>(512)
    private var refreshBudget = 0
    private var camX = 0.0
    private var camY = 0.0
    private var camZ = 0.0
    private var camLen = 0.0
    private var radius = 6371000.0
    private var horizonMargin = 0.0
    private val sunD = DoubleArray(4)
    private val cd = DoubleArray(3)

    // statistics (read by the UI thread)
    @Volatile var fps = 0.0
    @Volatile var frameMs = 0.0
    @Volatile var visibleChunks = 0
    @Volatile var trianglesDrawn = 0
    @Volatile var drawCalls = 0
    @Volatile var gpuInfo = ""
    @Volatile var shaderError = ""
    @Volatile var camLat = 0.0
    @Volatile var camLon = 0.0
    @Volatile var camAlt = 0.0
    @Volatile var rootsReady = false
    @Volatile var uploadsPerFrame = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        gpuInfo = (GLES20.glGetString(GLES20.GL_RENDERER) ?: "?") + " / " + (GLES20.glGetString(GLES20.GL_VERSION) ?: "?")
        progTerrain = Shaders.compile(Shaders.TERRAIN_VS, Shaders.TERRAIN_FS)
        progCloud = Shaders.compile(Shaders.SHELL_VS, Shaders.CLOUD_FS)
        progAtmo = Shaders.compile(Shaders.SHELL_VS, Shaders.ATMO_FS)
        progStar = Shaders.compile(Shaders.STAR_VS, Shaders.STAR_FS)
        shaderError = Shaders.lastError
        if (progTerrain != 0) {
            val n = arrayOf("uVP", "uOffset", "uCenter", "uAxis1", "uSun", "uHazeK", "uHazeAmt", "uHazeColor", "uTexT", "uTexD", "uAlbedo", "uNormal")
            for (i in n.indices) uT[i] = GLES20.glGetUniformLocation(progTerrain, n[i])
        }
        if (progCloud != 0) {
            val n = arrayOf("uVP", "uCenterRel", "uRadius", "uCloud", "uSun", "uAlpha", "uShift")
            for (i in n.indices) uC[i] = GLES20.glGetUniformLocation(progCloud, n[i])
        }
        if (progAtmo != 0) {
            val n = arrayOf("uVP", "uCenterRel", "uRadius", "uSun", "uAlpha")
            for (i in n.indices) uA[i] = GLES20.glGetUniformLocation(progAtmo, n[i])
        }
        if (progStar != 0) {
            val n = arrayOf("uVP", "uAlpha")
            for (i in n.indices) uS[i] = GLES20.glGetUniformLocation(progStar, n[i])
        }
        buildSharedBuffers()
        cloudsReady = false
        cloudTex = 0
        contextLost = true
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewW = max(1, width)
        viewH = max(1, height)
        GLES20.glViewport(0, 0, width, height)
        cam.focalPx = viewH / (2.0 * Math.tan(cam.fovY / 2.0))
    }

    private fun buildSharedBuffers() {
        val ids = IntArray(1)
        // shared terrain index buffer: grid + 4 skirts
        val g = Const.G
        val vg = Const.VG
        val idx = ShortArray(Const.INDEX_COUNT)
        var n = 0
        for (j in 0 until g) for (i in 0 until g) {
            val a = j * vg + i
            val b = a + 1
            val c = a + vg
            val d = c + 1
            idx[n++] = a.toShort(); idx[n++] = b.toShort(); idx[n++] = c.toShort()
            idx[n++] = b.toShort(); idx[n++] = d.toShort(); idx[n++] = c.toShort()
        }
        val base = vg * vg
        for (e in 0 until 4) {
            for (i in 0 until g) {
                val ga: Int; val gb: Int
                when (e) {
                    0 -> { ga = i; gb = i + 1 }
                    1 -> { ga = g * vg + i; gb = g * vg + i + 1 }
                    2 -> { ga = i * vg; gb = (i + 1) * vg }
                    else -> { ga = i * vg + g; gb = (i + 1) * vg + g }
                }
                val sa = base + e * vg + i
                val sb = sa + 1
                idx[n++] = ga.toShort(); idx[n++] = sa.toShort(); idx[n++] = gb.toShort()
                idx[n++] = gb.toShort(); idx[n++] = sa.toShort(); idx[n++] = sb.toShort()
            }
        }
        val ib = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        ib.put(idx); ib.position(0)
        GLES30.glBindVertexArray(0)
        GLES20.glGenBuffers(1, ids, 0); ibo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, ib, GLES20.GL_STATIC_DRAW)
        mgr.ibo = ibo

        // unit sphere for cloud / atmosphere shells
        val segX = 64
        val segY = 32
        val vs = FloatArray((segX + 1) * (segY + 1) * 3)
        var k = 0
        for (y in 0..segY) {
            val lat = PI * (0.5 - y.toDouble() / segY)
            for (x in 0..segX) {
                val lon = 2.0 * PI * (x.toDouble() / segX - 0.5)
                vs[k++] = (cos(lat) * cos(lon)).toFloat()
                vs[k++] = (cos(lat) * sin(lon)).toFloat()
                vs[k++] = sin(lat).toFloat()
            }
        }
        val si = ShortArray(segX * segY * 6)
        var m = 0
        for (y in 0 until segY) for (x in 0 until segX) {
            val a = y * (segX + 1) + x
            val b = a + 1
            val c = a + segX + 1
            val d = c + 1
            si[m++] = a.toShort(); si[m++] = c.toShort(); si[m++] = b.toShort()
            si[m++] = b.toShort(); si[m++] = c.toShort(); si[m++] = d.toShort()
        }
        sphereIdx = si.size
        val vb = ByteBuffer.allocateDirect(vs.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        vb.put(vs); vb.position(0)
        GLES20.glGenBuffers(1, ids, 0); sphereVbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, sphereVbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vs.size * 4, vb, GLES20.GL_STATIC_DRAW)
        val sb = ByteBuffer.allocateDirect(si.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        sb.put(si); sb.position(0)
        GLES20.glGenBuffers(1, ids, 0); sphereIbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, sphereIbo)
        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, si.size * 2, sb, GLES20.GL_STATIC_DRAW)

        // stars
        val rnd = java.util.Random(12345L)
        val st = FloatArray(starCount * 4)
        for (i in 0 until starCount) {
            var x = 0.0; var y = 0.0; var z = 0.0; var l = 0.0
            do {
                x = rnd.nextGaussian(); y = rnd.nextGaussian(); z = rnd.nextGaussian()
                l = sqrt(x * x + y * y + z * z)
            } while (l < 1e-3)
            st[i * 4] = (x / l).toFloat(); st[i * 4 + 1] = (y / l).toFloat(); st[i * 4 + 2] = (z / l).toFloat()
            val r = rnd.nextFloat()
            st[i * 4 + 3] = r * r * r
        }
        val fb = ByteBuffer.allocateDirect(st.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        fb.put(st); fb.position(0)
        GLES20.glGenBuffers(1, ids, 0); starVbo = ids[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, starVbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, st.size * 4, fb, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    private fun smooth(a: Double, b: Double, x: Double): Double {
        val t = ((x - a) / (b - a)).coerceIn(0.0, 1.0)
        return t * t * (3.0 - 2.0 * t)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016 else ((now - lastNs) * 1e-9).coerceAtMost(0.1)
        if (lastNs != 0L) {
            frameMs = frameMs * 0.9 + dt * 1000.0 * 0.1
            fps = if (frameMs > 0.01) 1000.0 / frameMs else 0.0
        }
        lastNs = now
        frameNo++
        mgr.frame = frameNo

        if (contextLost) {
            mgr.hardReset(sim.epoch, false)
            havePlanet = false
            contextLost = false
        }
        if (!sim.ready) {
            GLES20.glClearColor(0.01f, 0.01f, 0.03f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            return
        }
        if (!havePlanet || sim.epoch != mgr.gen) {
            val R = sim.radiusM
            mgr.radiusM = R
            mgr.hardReset(sim.epoch, true)
            if (!havePlanet || abs(cam.radius - R) > 1.0) { cam.reset(R); cam.setCenter(18.0, 12.0) }
            radius = R
            havePlanet = true
        }
        mgr.stamp = sim.stamp
        mgr.layer = sim.layer
        sim.getSun(sunD)

        // camera
        cam.stepFling(dt, viewH)
        if (frameNo % 6L == 0L) {
            val h = NativeBridge.nHeightAt(sim.handle, cam.lat, cam.lon)
            cam.targetHeight += (h - cam.targetHeight) * 0.4
        }
        cam.update(viewW.toDouble() / viewH)
        camX = cam.pos[0]; camY = cam.pos[1]; camZ = cam.pos[2]
        camLen = cam.posLen
        horizonMargin = 2.0 * radius * sqrt(max(0.0, camLen - radius) * 9500.0)
        camLat = cam.lat; camLon = cam.lon; camAlt = cam.altitude

        mgr.processUploads(4_000_000L)
        uploadsPerFrame = mgr.uploadsThisFrame
        uploadClouds()

        // sky
        cam.centerDir(cd)
        val dayCam = (cd[0] * sunD[0] + cd[1] * sunD[1] + cd[2] * sunD[2])
        val alt = cam.altitude
        val skyAmt = 1.0 - smooth(30_000.0, 260_000.0, alt)
        val dayF = smooth(-0.12, 0.25, dayCam)
        val sr = (0.01 + 0.34 * dayF) * skyAmt
        val sg = (0.012 + 0.55 * dayF) * skyAmt
        val sb = (0.025 + 0.88 * dayF) * skyAmt
        GLES20.glClearColor(sr.toFloat(), sg.toFloat(), sb.toFloat(), 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        drawStars(alt, dayF)

        // terrain
        visible.clear()
        refreshBudget = 6
        for (f in 0 until 6) select(mgr.root(f))
        var rr = true
        for (f in 0 until 6) { val r = mgr.roots[f]; if (r == null || !r.hasGpu) rr = false }
        rootsReady = rr
        drawTerrain(alt, dayF)

        // shells
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glDepthMask(false)
        drawClouds(alt)
        drawAtmosphere(alt)
        GLES20.glDepthMask(true)
        GLES20.glDisable(GLES20.GL_BLEND)

        mgr.evict()
        visibleChunks = visible.size
        trianglesDrawn = visible.size * (Const.INDEX_COUNT / 3)
        drawCalls = visible.size
        if (shaderError.isEmpty() && Shaders.lastError.isNotEmpty()) shaderError = Shaders.lastError
    }

    // ------------------------------------------------------------------------------------------
    private fun select(c: Chunk) {
        val R = radius
        val rx = c.cx * R - camX
        val ry = c.cy * R - camY
        val rz = c.cz * R - camZ
        if (!cam.sphereVisible(rx, ry, rz, c.radius)) return
        val dotc = (c.cx * camX + c.cy * camY + c.cz * camZ) * R
        if (dotc + c.radius * camLen < R * R - horizonMargin) return
        c.lastUsed = frameNo
        c.wanted = frameNo
        val dist = sqrt(rx * rx + ry * ry + rz * rz)
        val d = max(dist - c.radius * 0.55, 1.0)
        val texPx = (c.edgeM / Const.T) / d * cam.focalPx
        if (c.level < Const.MAX_LEVEL && texPx > SPLIT_PX) {
            var allReady = true
            for (i in 0 until 4) {
                val k = mgr.child(c, i)
                if (!k.hasGpu) {
                    allReady = false
                    mgr.request(k, (c.level + 1) * 1.0e9 + dist)
                }
            }
            if (allReady) {
                for (i in 0 until 4) select(c.kids[i]!!)
                return
            }
        }
        if (c.hasGpu) {
            visible.add(c)
            if (refreshBudget > 0 && c.state == ChunkManager.IDLE && mgr.isStale(c)) {
                mgr.request(c, c.level * 1.0e9 + dist)
                refreshBudget--
            }
        } else {
            mgr.request(c, c.level * 1.0e9 + dist)
        }
    }

    private fun drawTerrain(alt: Double, dayF: Double) {
        if (progTerrain == 0) return
        GLES20.glUseProgram(progTerrain)
        GLES20.glUniformMatrix4fv(uT[0], 1, false, cam.vp, 0)
        GLES20.glUniform3f(uT[4], sunD[0].toFloat(), sunD[1].toFloat(), sunD[2].toFloat())
        GLES20.glUniform1f(uT[5], 5.0e-7f)
        val hazeAmt = 1.0 - smooth(600_000.0, 2_500_000.0, alt)
        GLES20.glUniform1f(uT[6], hazeAmt.toFloat())
        GLES20.glUniform3f(uT[7], 0.55f, 0.72f, 0.95f)
        GLES20.glUniform1f(uT[8], Const.T.toFloat())
        GLES20.glUniform1f(uT[9], Const.D.toFloat())
        GLES20.glUniform1i(uT[10], 0)
        GLES20.glUniform1i(uT[11], 1)
        val R = radius
        for (vi in 0 until visible.size) {
            val c = visible[vi]
            GLES20.glUniform3f(uT[1], (c.cx * R - camX).toFloat(), (c.cy * R - camY).toFloat(), (c.cz * R - camZ).toFloat())
            GLES20.glUniform3f(uT[2], (c.cx * R).toFloat(), (c.cy * R).toFloat(), (c.cz * R).toFloat())
            val ax = Cube.T1[c.face]
            GLES20.glUniform3f(uT[3], ax[0].toFloat(), ax[1].toFloat(), ax[2].toFloat())
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, c.texA)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, c.texN)
            GLES30.glBindVertexArray(c.vao)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, Const.INDEX_COUNT, GLES20.GL_UNSIGNED_SHORT, 0)
        }
        GLES30.glBindVertexArray(0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
    }

    private fun drawStars(alt: Double, dayF: Double) {
        if (progStar == 0) return
        val a = (1.0 - dayF * (1.0 - smooth(40_000.0, 500_000.0, alt))).coerceIn(0.0, 1.0)
        if (a < 0.02) return
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE)
        GLES20.glUseProgram(progStar)
        GLES20.glUniformMatrix4fv(uS[0], 1, false, cam.vp, 0)
        GLES20.glUniform1f(uS[1], a.toFloat())
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, starVbo)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 4, GLES20.GL_FLOAT, false, 16, 0)
        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, starCount)
        GLES20.glDisableVertexAttribArray(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    private fun drawShell(prog: Int, rad: Double) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, sphereVbo)
        GLES20.glEnableVertexAttribArray(0)
        GLES20.glVertexAttribPointer(0, 3, GLES20.GL_FLOAT, false, 12, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, sphereIbo)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, sphereIdx, GLES20.GL_UNSIGNED_SHORT, 0)
        GLES20.glDisableVertexAttribArray(0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    private fun drawClouds(alt: Double) {
        if (progCloud == 0 || !cloudsReady) return
        val a = smooth(25_000.0, 160_000.0, alt)
        if (a < 0.01) return
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(progCloud)
        GLES20.glUniformMatrix4fv(uC[0], 1, false, cam.vp, 0)
        GLES20.glUniform3f(uC[1], (-camX).toFloat(), (-camY).toFloat(), (-camZ).toFloat())
        GLES20.glUniform1f(uC[2], (radius + 11_000.0).toFloat())
        GLES20.glUniform1i(uC[3], 0)
        GLES20.glUniform3f(uC[4], sunD[0].toFloat(), sunD[1].toFloat(), sunD[2].toFloat())
        GLES20.glUniform1f(uC[5], (0.92 * a).toFloat())
        cloudShift += 0.00002f
        GLES20.glUniform1f(uC[6], cloudShift)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, cloudTex)
        drawShell(progCloud, radius + 11_000.0)
    }

    private fun drawAtmosphere(alt: Double) {
        if (progAtmo == 0) return
        val a = smooth(120_000.0, 700_000.0, alt)
        if (a < 0.01) return
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE)
        GLES20.glUseProgram(progAtmo)
        GLES20.glUniformMatrix4fv(uA[0], 1, false, cam.vp, 0)
        GLES20.glUniform3f(uA[1], (-camX).toFloat(), (-camY).toFloat(), (-camZ).toFloat())
        GLES20.glUniform1f(uA[2], (radius + 100_000.0).toFloat())
        GLES20.glUniform3f(uA[3], sunD[0].toFloat(), sunD[1].toFloat(), sunD[2].toFloat())
        GLES20.glUniform1f(uA[4], a.toFloat())
        drawShell(progAtmo, radius + 100_000.0)
    }

    private fun uploadClouds() {
        val up = sim.uploadCloudsIfDirty { buf ->
            if (cloudTex == 0) {
                val ids = IntArray(1)
                GLES20.glGenTextures(1, ids, 0)
                cloudTex = ids[0]
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, cloudTex)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, cloudTex)
            GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
            buf.position(0)
            buf.limit(sim.cloudW * sim.cloudH)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES30.GL_R8, sim.cloudW, sim.cloudH, 0, GLES30.GL_RED, GLES20.GL_UNSIGNED_BYTE, buf)
        }
        if (up) cloudsReady = true
    }

    fun shutdown() {
        mgr.shutdown()
    }

    companion object {
        const val SPLIT_PX = 1.7
    }
}
