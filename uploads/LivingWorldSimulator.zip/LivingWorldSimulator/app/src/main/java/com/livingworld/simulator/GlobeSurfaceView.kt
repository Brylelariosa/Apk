package com.livingworld.simulator

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.VelocityTracker
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.hypot

/** GL surface with one-finger pan, pinch zoom, two-finger twist (heading) and two-finger vertical drag (tilt). */
class GlobeSurfaceView(ctx: Context, private val renderer: GlobeRenderer) : GLSurfaceView(ctx) {
    private var mode = 0
    private var lastX = 0f
    private var lastY = 0f
    private var lastDist = 0f
    private var lastAng = 0f
    private var lastCy = 0f
    private var vt: VelocityTracker? = null

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 24, 0)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    private fun startTwo(e: MotionEvent) {
        val dx = e.getX(1) - e.getX(0)
        val dy = e.getY(1) - e.getY(0)
        lastDist = hypot(dx, dy)
        lastAng = atan2(dy, dx)
        lastCy = (e.getY(0) + e.getY(1)) * 0.5f
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cam = renderer.cam
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = 1
                lastX = e.x; lastY = e.y
                cam.stopFling()
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount >= 2) {
                    mode = 2
                    startTwo(e)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (mode == 1 && e.pointerCount == 1) {
                    cam.pan(e.x - lastX, e.y - lastY, renderer.viewH)
                    lastX = e.x; lastY = e.y
                } else if (mode == 2 && e.pointerCount >= 2) {
                    val dx = e.getX(1) - e.getX(0)
                    val dy = e.getY(1) - e.getY(0)
                    val dist = hypot(dx, dy)
                    val ang = atan2(dy, dx)
                    val cy = (e.getY(0) + e.getY(1)) * 0.5f
                    if (lastDist > 8f && dist > 8f) cam.zoomBy((lastDist / dist).toDouble())
                    var da = (ang - lastAng).toDouble()
                    while (da > PI) da -= 2 * PI
                    while (da < -PI) da += 2 * PI
                    cam.rotateHeading(-da)
                    cam.tiltBy(-((cy - lastCy) / renderer.viewH).toDouble() * 1.6)
                    lastDist = dist; lastAng = ang; lastCy = cy
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (e.pointerCount == 2) {
                    mode = 1
                    val keep = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(keep); lastY = e.getY(keep)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == 1 && e.actionMasked == MotionEvent.ACTION_UP) {
                    vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    val vy = vt?.yVelocity ?: 0f
                    cam.startFling(vx, vy)
                }
                vt?.recycle()
                vt = null
                mode = 0
            }
        }
        return true
    }
}
