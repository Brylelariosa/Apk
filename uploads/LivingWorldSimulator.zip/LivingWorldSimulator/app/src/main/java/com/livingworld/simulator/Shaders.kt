package com.livingworld.simulator

import android.opengl.GLES20

object Shaders {
    var lastError: String = ""

    const val TERRAIN_VS = """#version 300 es
precision highp float;
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;
uniform mat4 uVP;
uniform vec3 uOffset;
uniform vec3 uCenter;
out vec2 vUV;
out vec3 vN;
out vec3 vRel;
void main() {
    vec3 rel = aPos + uOffset;
    gl_Position = uVP * vec4(rel, 1.0);
    vUV = aUV;
    vN = normalize(uCenter + aPos);
    vRel = rel;
}
"""

    const val TERRAIN_FS = """#version 300 es
precision highp float;
in vec2 vUV;
in vec3 vN;
in vec3 vRel;
uniform sampler2D uAlbedo;
uniform sampler2D uNormal;
uniform vec3 uAxis1;
uniform vec3 uSun;
uniform float uHazeK;
uniform float uHazeAmt;
uniform vec3 uHazeColor;
uniform float uTexT;
uniform float uTexD;
out vec4 fragColor;
void main() {
    vec2 st = (vUV * uTexT + 1.0) / uTexD;
    vec4 al = texture(uAlbedo, st);
    vec2 nm = texture(uNormal, st).rg * 2.0 - 1.0;
    float nz = sqrt(max(0.0, 1.0 - dot(nm, nm)));
    vec3 N = normalize(vN);
    vec3 T1 = normalize(uAxis1 - N * dot(uAxis1, N));
    vec3 T2 = cross(N, T1);
    vec3 n = normalize(T1 * nm.x + T2 * nm.y + N * nz);
    vec3 L = normalize(uSun);
    float geo = dot(N, L);
    float day = smoothstep(-0.07, 0.10, geo);
    float diff = max(dot(n, L), 0.0);
    float dist = length(vRel);
    vec3 V = -vRel / max(dist, 0.001);
    vec3 H = normalize(L + V);
    float nh = max(dot(n, H), 0.0);
    float water = al.a;
    float spec = (pow(nh, 140.0) * 0.9 + pow(nh, 22.0) * 0.10) * water * day;
    float fres = pow(1.0 - max(dot(N, V), 0.0), 4.0) * water;
    vec3 alb = al.rgb * al.rgb;
    vec3 ambient = vec3(0.020, 0.028, 0.050) + vec3(0.075, 0.095, 0.135) * day;
    vec3 col = alb * (ambient + vec3(1.10, 1.04, 0.96) * diff * day);
    col += vec3(spec) + fres * vec3(0.12, 0.20, 0.34) * day;
    float haze = (1.0 - exp(-dist * uHazeK)) * uHazeAmt;
    col = mix(col, uHazeColor * (0.25 + 0.75 * day), clamp(haze, 0.0, 0.92));
    col = col / (1.0 + 0.18 * col);
    fragColor = vec4(sqrt(max(col, 0.0)), 1.0);
}
"""

    const val SHELL_VS = """#version 300 es
precision highp float;
layout(location = 0) in vec3 aDir;
uniform mat4 uVP;
uniform vec3 uCenterRel;
uniform float uRadius;
out vec3 vDir;
out vec3 vRel;
void main() {
    vec3 rel = uCenterRel + aDir * uRadius;
    gl_Position = uVP * vec4(rel, 1.0);
    vDir = aDir;
    vRel = rel;
}
"""

    const val CLOUD_FS = """#version 300 es
precision highp float;
in vec3 vDir;
in vec3 vRel;
uniform sampler2D uCloud;
uniform vec3 uSun;
uniform float uAlpha;
uniform float uShift;
out vec4 fragColor;
void main() {
    vec3 d = normalize(vDir);
    float u = atan(d.y, d.x) * 0.15915494 + 0.5 + uShift;
    float v = 0.5 - asin(clamp(d.z, -1.0, 1.0)) * 0.31830989;
    float c = texture(uCloud, vec2(u, v)).r;
    float geo = dot(d, normalize(uSun));
    float lit = smoothstep(-0.12, 0.28, geo);
    vec3 col = mix(vec3(0.04, 0.05, 0.08), vec3(1.0, 0.99, 0.97), lit);
    float shade = 0.80 + 0.20 * smoothstep(0.2, 1.0, c);
    fragColor = vec4(col * shade, c * uAlpha);
}
"""

    const val ATMO_FS = """#version 300 es
precision highp float;
in vec3 vDir;
in vec3 vRel;
uniform vec3 uSun;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    vec3 N = normalize(vDir);
    vec3 V = normalize(-vRel);
    float ndv = clamp(dot(N, V), 0.0, 1.0);
    float glow = smoothstep(0.0, 0.10, ndv) * (1.0 - smoothstep(0.15, 0.50, ndv)) * 1.1 + 0.10 * pow(1.0 - ndv, 3.0);
    float geo = dot(N, normalize(uSun));
    float day = smoothstep(-0.30, 0.35, geo);
    vec3 col = mix(vec3(0.95, 0.45, 0.22), vec3(0.28, 0.55, 1.0), smoothstep(-0.05, 0.40, geo));
    fragColor = vec4(col, glow * day * uAlpha);
}
"""

    const val STAR_VS = """#version 300 es
precision highp float;
layout(location = 0) in vec4 aStar;
uniform mat4 uVP;
out float vB;
void main() {
    vec4 p = uVP * vec4(aStar.xyz, 0.0);
    gl_Position = p.xyww;
    gl_PointSize = 1.2 + 1.8 * aStar.w;
    vB = aStar.w;
}
"""

    const val STAR_FS = """#version 300 es
precision mediump float;
in float vB;
uniform float uAlpha;
out vec4 fragColor;
void main() {
    float b = 0.45 + 0.55 * vB;
    fragColor = vec4(vec3(b, b, b * 1.05), uAlpha);
}
"""

    fun compile(vs: String, fs: String): Int {
        val v = shader(GLES20.GL_VERTEX_SHADER, vs)
        val f = shader(GLES20.GL_FRAGMENT_SHADER, fs)
        if (v == 0 || f == 0) return 0
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val st = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) {
            lastError = "link: " + GLES20.glGetProgramInfoLog(p)
            GLES20.glDeleteProgram(p)
            return 0
        }
        GLES20.glDeleteShader(v)
        GLES20.glDeleteShader(f)
        return p
    }

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val st = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            lastError = (if (type == GLES20.GL_VERTEX_SHADER) "vs: " else "fs: ") + GLES20.glGetShaderInfoLog(s)
            GLES20.glDeleteShader(s)
            return 0
        }
        return s
    }
}
