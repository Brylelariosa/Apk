// JNI glue between the Kotlin app and the native simulation core.
#include <jni.h>
#include <atomic>
#include <mutex>
#include <string>
#include <cstring>
#include "core/chunk.h"

using namespace lw;

namespace {

struct Handle {
    World world;
    std::atomic<float> progress{0.f};
    std::mutex mu;
    std::string stage = "Idle";
    std::atomic<uint64_t> chunkUs{0}, chunkCount{0};
};

inline Handle* H(jlong h) { return reinterpret_cast<Handle*>(h); }

ProgressFn makeProgress(Handle* h) {
    return [h](const char* s, float f) {
        h->progress.store(f);
        std::lock_guard<std::mutex> lk(h->mu);
        h->stage = s ? s : "";
    };
}

}  // namespace

extern "C" {

#define JFN(ret, name) __attribute__((visibility("default"))) JNIEXPORT ret JNICALL Java_com_livingworld_simulator_NativeBridge_##name

JFN(jlong, nCreate)(JNIEnv*, jobject) { return reinterpret_cast<jlong>(new Handle()); }

JFN(void, nDestroy)(JNIEnv*, jobject, jlong h) { delete H(h); }

JFN(void, nDefaultParams)(JNIEnv* env, jobject, jdoubleArray out) {
    PlanetParams p;
    double a[PlanetParams::kCount];
    p.toArray(a);
    env->SetDoubleArrayRegion(out, 0, PlanetParams::kCount, a);
}

JFN(void, nGenerate)(JNIEnv* env, jobject, jlong h, jstring seed, jdoubleArray params) {
    Handle* hd = H(h);
    const char* cs = env->GetStringUTFChars(seed, nullptr);
    std::string sd(cs ? cs : "EARTH-00000000");
    if (cs) env->ReleaseStringUTFChars(seed, cs);
    PlanetParams pp;
    double a[PlanetParams::kCount];
    pp.toArray(a);
    if (params && env->GetArrayLength(params) >= PlanetParams::kCount) env->GetDoubleArrayRegion(params, 0, PlanetParams::kCount, a);
    pp.fromArray(a);
    hd->progress.store(0.f);
    hd->world.generate(sd, pp, makeProgress(hd));
    hd->progress.store(1.f);
}

JFN(void, nAdvance)(JNIEnv*, jobject, jlong h, jdouble years) {
    Handle* hd = H(h);
    hd->progress.store(0.f);
    hd->world.advance(years, makeProgress(hd));
    hd->progress.store(1.f);
}

JFN(void, nAddDayHours)(JNIEnv*, jobject, jlong h, jdouble hours) { H(h)->world.addDayHours(hours); }

JFN(jfloat, nProgress)(JNIEnv*, jobject, jlong h) { return H(h)->progress.load(); }

JFN(jstring, nStage)(JNIEnv* env, jobject, jlong h) {
    std::string s;
    {
        std::lock_guard<std::mutex> lk(H(h)->mu);
        s = H(h)->stage;
    }
    return env->NewStringUTF(s.c_str());
}

JFN(jint, nGeneration)(JNIEnv*, jobject, jlong h) { return (jint)H(h)->world.generation(); }

JFN(jboolean, nBuildChunk)(JNIEnv* env, jobject, jlong h, jint face, jint level, jint cx, jint cy, jint layer, jobject vtx, jobject albedo, jobject normal, jdoubleArray meta) {
    Handle* hd = H(h);
    uint8_t* pv = (uint8_t*)env->GetDirectBufferAddress(vtx);
    uint8_t* pa = (uint8_t*)env->GetDirectBufferAddress(albedo);
    uint8_t* pn = (uint8_t*)env->GetDirectBufferAddress(normal);
    if (!pv || !pa || !pn) return JNI_FALSE;
    if (env->GetDirectBufferCapacity(vtx) < (jlong)(kVertCount * kVertBytes) || env->GetDirectBufferCapacity(albedo) < (jlong)kAlbedoBytes ||
        env->GetDirectBufferCapacity(normal) < (jlong)kNormalBytes)
        return JNI_FALSE;
    View v = hd->world.view();
    if (!v) return JNI_FALSE;
    double m[9] = {0};
    Timer t;
    bool ok = buildChunk(v, face, level, cx, cy, layer, pv, pa, pn, m);
    hd->chunkUs.fetch_add((uint64_t)(t.ms() * 1000.0));
    hd->chunkCount.fetch_add(1);
    if (ok && meta) env->SetDoubleArrayRegion(meta, 0, 9, m);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JFN(jboolean, nBuildClouds)(JNIEnv* env, jobject, jlong h, jint w, jint hh, jobject out) {
    uint8_t* p = (uint8_t*)env->GetDirectBufferAddress(out);
    if (!p || env->GetDirectBufferCapacity(out) < (jlong)w * hh) return JNI_FALSE;
    View v = H(h)->world.view();
    if (!v) return JNI_FALSE;
    buildCloudTexture(v, w, hh, p);
    return JNI_TRUE;
}

JFN(void, nSunDir)(JNIEnv* env, jobject, jlong h, jdoubleArray out) {
    View v = H(h)->world.view();
    double a[4] = {1, 0, 0, 0};
    if (v) { a[0] = v.d->sunDir.x; a[1] = v.d->sunDir.y; a[2] = v.d->sunDir.z; a[3] = v.d->declDeg; }
    env->SetDoubleArrayRegion(out, 0, 4, a);
}

JFN(jboolean, nInfo)(JNIEnv* env, jobject, jlong h, jdoubleArray out) {
    View v = H(h)->world.view();
    double a[16] = {0};
    if (!v) { env->SetDoubleArrayRegion(out, 0, 16, a); return JNI_FALSE; }
    a[0] = v.d->timeYears; a[1] = v.d->fracYear; a[2] = v.d->dayFrac; a[3] = v.d->globalT - 273.15;
    a[4] = v.s->pp.pressureAtm; a[5] = 1.0 - v.s->T().landFraction; a[6] = v.s->pp.axialTiltDeg; a[7] = v.s->pp.rotationHours;
    a[8] = v.s->pp.radiusKm; a[9] = v.d->declDeg; a[10] = v.s->pp.orbitDays; a[11] = v.s->pp.gravity; a[12] = v.s->T().landFraction;
    a[13] = v.s->tectTimeMyr; a[14] = v.s->st().hadleyDeg; a[15] = v.s->st().waterImbalance;
    env->SetDoubleArrayRegion(out, 0, 16, a);
    return JNI_TRUE;
}

JFN(void, nStats)(JNIEnv* env, jobject, jlong h, jdoubleArray out) {
    Handle* hd = H(h);
    Timings t = hd->world.timings();
    uint64_t n = hd->chunkCount.load();
    double a[10] = {t.genTotalMs, t.terrainMs, t.climateMs, t.ecoMs, t.stepMs, t.climateStepMs, t.riverMs,
                    n ? (double)hd->chunkUs.load() / 1000.0 / (double)n : 0.0, (double)n, 0};
    env->SetDoubleArrayRegion(out, 0, 10, a);
}

JFN(jstring, nInspect)(JNIEnv* env, jobject, jlong h, jdouble lat, jdouble lon, jint layer) {
    View v = H(h)->world.view();
    std::string s = v ? inspectText(v, lat, lon, layer) : std::string();
    return env->NewStringUTF(s.c_str());
}

JFN(jstring, nExplain)(JNIEnv* env, jobject, jlong h, jdouble lat, jdouble lon) {
    View v = H(h)->world.view();
    std::string s = v ? explainText(v, lat, lon) : std::string("No planet yet.");
    return env->NewStringUTF(s.c_str());
}

JFN(jdouble, nHeightAt)(JNIEnv*, jobject, jlong h, jdouble lat, jdouble lon) {
    View v = H(h)->world.view();
    return v ? heightAtLatLon(v, lat, lon) : 0.0;
}

}  // extern "C"
