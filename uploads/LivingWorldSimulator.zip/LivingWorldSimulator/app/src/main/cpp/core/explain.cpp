// "Why is this here?" - walks the simulation's actual cause-and-effect data for a location.
#include "chunk.h"
#include <cstdio>
#include <cstdarg>

namespace lw {

namespace {

struct Wind { double u, v; };

Wind annualWind(const Sampler& S, const V3& p) {
    int ids[4];
    float w[4];
    S.cg.locate(p, ids, w);
    const ClimateSlices& sl = S.s.sl();
    int n = S.cg.count;
    double u = 0, v = 0;
    for (int m = 0; m < NSLICE; m++)
        for (int k = 0; k < 4; k++) { u += w[k] * sl.wu[(size_t)m * n + ids[k]]; v += w[k] * sl.wv[(size_t)m * n + ids[k]]; }
    return {u / NSLICE, v / NSLICE};
}

const char* compass(double fromDeg) {
    static const char* c[8] = {"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"};
    return c[((int)((fromDeg + 22.5) / 45.0)) % 8];
}

void add(std::string& out, const char* fmt, ...) __attribute__((format(printf, 2, 3)));
void add(std::string& out, const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    out += buf;
    out += "\n";
}

}  // namespace

std::string explainText(const View& v, double latDeg, double lonDeg) {
    if (!v) return "No planet loaded.";
    Sampler S(v);
    const double Rkm = S.Rm / 1000.0;
    V3 p = fromLatLon(latDeg * DEG2RAD, lonDeg * DEG2RAD);
    int fc = S.fg.cellOf(p);
    double h = S.height(p, 80.0);
    double lakeLv = S.fg.sample(S.H.lakeLevel.data(), p);
    const TerrainData& T = S.T;
    const EcoData& E = S.E;
    const HydroData& H = S.H;
    std::string out;
    TectSample ts;
    TectFrame fr;
    S.s.tect.makeFrame(S.s.tectTimeMyr, fr);
    S.s.tect.sample(fr, p, ts);
    static const char* bt[4] = {"no boundary nearby", "convergent (plates closing)", "divergent (plates spreading)", "transform (plates sliding past)"};

    if (h <= 0.0) {
        add(out, "OCEAN, %.0f m deep.", -h);
        double age = S.fg.sample(T.crustAge.data(), p);
        add(out, "Depth: oceanic crust ~%.0f Myr old. New crust forms hot and high at spreading ridges, then cools and sinks as it drifts away.", age);
        if (T.btype[fc] == 1 && T.bdist[fc] < 250) add(out, "A subduction trench: plate %d dives under plate %d here (%.1f cm/yr), pulling the seafloor down.", ts.plate, ts.other, ts.conv);
        else if (T.btype[fc] == 2 && T.bdist[fc] < 300) add(out, "Mid-ocean ridge: plates %d and %d spread apart at %.1f cm/yr and new crust wells up.", ts.plate, ts.other, -ts.conv);
        else if (T.sediment[fc] > 30) add(out, "Continental shelf: river sediment (%.0f m) has built a shallow shelf.", T.sediment[fc]);
        int cc = S.cg.cellOf(p);
        double cu = S.s.st().cu[cc], cv = S.s.st().cv[cc];
        double sp = std::sqrt(cu * cu + cv * cv);
        double sst = S.s.sl().ts.empty() ? 0 : S.cur(S.d.ts, p) - 273.15;
        add(out, "Surface water %.1f C. Wind-driven gyre current %.2f m/s%s.", sst, sp, S.s.st().upwell[cc] > 2e-7 ? "; upwelling brings cold deep water here" : "");
        return out;
    }

    // ---------------- land ----------------
    int bi = E.biome[fc];
    add(out, "%s at %.0f m.", biomeName(bi), h);
    double orog = T.orogeny[fc], volc = T.volcanism[fc];
    // elevation chain
    if (orog > 0.25 && h > 700) {
        if (ts.type == 1 && ts.distKm < 700) add(out, "MOUNTAINS: plates %d and %d are closing at %.1f cm/yr, %.0f km from here. Crust crumples, thickens and floats high (isostasy); erosion carves it.", ts.plate, ts.other, ts.conv, ts.distKm);
        else add(out, "MOUNTAINS: an old collision belt from an earlier plate boundary, now carried inland by plate %d and worn down by erosion.", ts.plate);
    } else if (volc > 0.35) {
        add(out, "VOLCANIC: %s", T.btype[fc] == 1 ? "magma from the subducting plate rises through the overriding plate (volcanic arc)." : (T.btype[fc] == 2 ? "rifting crust lets magma reach the surface." : "a mantle hotspot under plate %d builds volcanoes."));
    } else if (h < 250) {
        add(out, "LOWLAND: %s", T.sediment[fc] > 40 ? "sediment eroded from uplands has been dumped here, building a flat plain." : "stable crust far from active plate boundaries.");
    } else {
        add(out, "UPLAND: continental crust lifted by plate motion and shaped by river erosion.");
    }
    // river chain
    double Q = H.discharge[fc];
    if (Q > 5.0) {
        int cur = fc, steps = 0;
        while (cur >= 0 && T.height[cur] > 0.f && steps < 4000) {
            int r = H.rec[cur];
            if (r < 0 || T.height[r] <= 0.f) break;
            cur = r; steps++;
        }
        bool toSea = cur >= 0 && H.rec[cur] >= 0 && T.height[H.rec[cur]] <= 0.f;
        double dropM = std::max(0.0, h - std::max(0.0, (double)T.height[cur]));
        add(out, "RIVER %.0f m3/s: gathers rain and snowmelt from its whole watershed (local runoff %.0f mm/yr, %.0f%% of the flow is snowmelt) and runs downhill ~%.0f km, losing %.0f m of height, %s.", Q, (double)H.runoff[fc], 100.0 * H.snowmeltFrac[fc], steps * 52.0, dropM, toSea ? "to the ocean" : "into a closed basin or lake");
    }
    if (H.lakeDepth[fc] > 8) add(out, "LAKE: a basin %.0f m deep fills from inflowing rivers; %s", H.lakeDepth[fc], H.lakeKind[fc] == 1 ? "it overflows at the lowest rim, feeding a river." : (H.lakeKind[fc] == 3 ? "evaporation exceeds inflow so only a salt flat remains." : "it has no outlet, so evaporation sets its level."));
    // climate chain
    double tAnn = E.tAnn[fc], pAnn = E.pAnn[fc], ai = E.aridity[fc];
    add(out, "Climate: %.1f C mean, %.0f mm/yr rain, aridity index %.2f (rain / evaporation demand).", tAnn, pAnn, ai);
    if (ai < 0.30) {
        // trace the moisture source upwind
        Wind w = annualWind(S, p);
        double sp = std::sqrt(w.u * w.u + w.v * w.v);
        if (sp < 0.3) {
            add(out, "DRY: air is nearly still here, so little moisture arrives.");
        } else {
            double toward = std::atan2(w.u, w.v);          // direction the wind blows towards (from north, clockwise)
            double from = std::fmod(toward * RAD2DEG + 180.0, 360.0);
            V3 e, n;
            eastNorth(p, e, n);
            V3 dirUp = e * (-w.u / sp) + n * (-w.v / sp);
            V3 q = p;
            double ridge = 0, ridgeAt = 0, oceanAt = -1;
            for (int s = 1; s <= 30; s++) {
                double a = 100.0 / Rkm;
                V3 tdir = normalize(tangentPart(dirUp, q));
                q = normalize(q * dcos(a) + tdir * dsin(a));
                int c2 = S.fg.cellOf(q);
                double hh = T.height[c2];
                if (hh <= 0.0) { oceanAt = s * 100.0; break; }
                if (hh - h > ridge && s * 100.0 <= 1500.0) { ridge = hh - h; ridgeAt = s * 100.0; }
                Wind w2 = annualWind(S, q);
                double sp2 = std::sqrt(w2.u * w2.u + w2.v * w2.v);
                if (sp2 > 0.3) { V3 e2, n2; eastNorth(q, e2, n2); dirUp = e2 * (-w2.u / sp2) + n2 * (-w2.v / sp2); }
            }
            double itcz = S.s.st().itczLat[(int)clampv((lonDeg + 180.0) / 10.0, 0.0, 35.0)];
            if (ridge > 1000.0) {
                add(out, "RAIN SHADOW: prevailing wind blows from the %s (%.1f m/s). %.0f km upwind a range stands %.0f m higher; air forced up it cools, rains out, and arrives here dry.", compass(from), sp, ridgeAt, ridge);
            } else if (oceanAt < 0 || oceanAt > 1500.0) {
                add(out, "FAR FROM THE SEA: wind from the %s has travelled %s over land, losing moisture to every basin and slope on the way.", compass(from), oceanAt < 0 ? ">3000 km" : ">1500 km");
            } else if (std::fabs(latDeg) > 15.0 && std::fabs(latDeg) < 40.0 && std::fabs(latDeg - itcz) > 12.0) {
                add(out, "SUBTROPICAL HIGH: air rises at the equatorial trough (near %.0f deg), flows poleward and sinks near %.0f deg latitude. Sinking air warms and dries, suppressing cloud (Hadley cell).", itcz, S.s.st().hadleyDeg);
            } else {
                add(out, "DRY: wind from the %s reaches the ocean %.0f km away but is too weak and cool-surfaced to load enough moisture.", compass(from), oceanAt);
            }
            double evapDemand = pAnn / std::max(0.02, ai);
            add(out, "Evaporation demand %.0f mm/yr is %.1fx the rainfall, so soil dries out.", evapDemand, evapDemand / std::max(1.0, pAnn));
        }
    } else if (ai > 1.3 && pAnn > 1400) {
        double itcz = S.s.st().itczLat[(int)clampv((lonDeg + 180.0) / 10.0, 0.0, 35.0)];
        if (std::fabs(latDeg - itcz) < 14.0) add(out, "WET: the Intertropical Convergence Zone (thermal equator near %.0f deg) draws warm humid ocean air together; it rises and rains daily.", itcz);
        else add(out, "WET: moist ocean air is forced up slopes or meets cooler air, condensing into %.0f mm of rain a year.", pAnn);
    }
    if (bi == B_ICE || bi == B_TUNDRA || bi == B_ALPINE) add(out, "Cold: %.1f C annual mean, warmest month only %.1f C; temperature falls ~6.5 C per km of altitude and with distance from the equator.", tAnn, E.tMax[fc]);
    add(out, "Soil fertility %.2f from parent rock %.2f, organic matter %.2f and drainage.", E.fertility[fc], E.mineral[fc], E.organic[fc]);
    (void)bt;
    return out;
}

}  // namespace lw
