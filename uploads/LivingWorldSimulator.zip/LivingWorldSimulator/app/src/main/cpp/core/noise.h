// 3D simplex noise with analytic gradient. Deterministic per seed.
#pragma once
#include "util.h"

namespace lw {

class Noise {
public:
    explicit Noise(uint64_t seed = 0) { init(seed); }

    void init(uint64_t seed) {
        uint8_t p[256];
        for (int i = 0; i < 256; i++) p[i] = (uint8_t)i;
        Rng r(seed ^ 0xA5A5A5A5DEADBEEFULL);
        for (int i = 255; i > 0; i--) {
            int j = (int)(r.next() % (uint64_t)(i + 1));
            uint8_t t = p[i]; p[i] = p[j]; p[j] = t;
        }
        for (int i = 0; i < 512; i++) { perm_[i] = p[i & 255]; pm12_[i] = (uint8_t)(perm_[i] % 12); }
    }

    // value in about [-1,1]; if g != nullptr, also writes d(value)/d(x,y,z)
    float n3d(float xin, float yin, float zin, float* g) const {
        static const float G[12][3] = {{1, 1, 0}, {-1, 1, 0}, {1, -1, 0}, {-1, -1, 0}, {1, 0, 1}, {-1, 0, 1},
                                       {1, 0, -1}, {-1, 0, -1}, {0, 1, 1}, {0, -1, 1}, {0, 1, -1}, {0, -1, -1}};
        const float F3 = 1.0f / 3.0f, G3 = 1.0f / 6.0f;
        float s = (xin + yin + zin) * F3;
        int i = ffloor(xin + s), j = ffloor(yin + s), k = ffloor(zin + s);
        float t = (float)(i + j + k) * G3;
        float x0 = xin - ((float)i - t), y0 = yin - ((float)j - t), z0 = zin - ((float)k - t);
        // Which of the six simplex orderings x0,y0,z0 fall in -- same decisions as the nested if/else it replaces
        // (including tie-breaks), computed without data-dependent branches.
        const int a = x0 >= y0, b = y0 >= z0, c = x0 >= z0;
        const int i1 = a & (b | c), j1 = (1 - a) & b, k1 = (1 - b) & (1 - (a & c));
        const int i2 = a | (b & c), j2 = (1 - a) | b, k2 = (1 - b) | ((1 - a) & (1 - c));
        float x1 = x0 - (float)i1 + G3, y1 = y0 - (float)j1 + G3, z1 = z0 - (float)k1 + G3;
        float x2 = x0 - (float)i2 + 2.0f * G3, y2 = y0 - (float)j2 + 2.0f * G3, z2 = z0 - (float)k2 + 2.0f * G3;
        float x3 = x0 - 1.0f + 3.0f * G3, y3 = y0 - 1.0f + 3.0f * G3, z3 = z0 - 1.0f + 3.0f * G3;
        int ii = i & 255, jj = j & 255, kk = k & 255;
        int gi0 = pm12_[ii + perm_[jj + perm_[kk]]];
        int gi1 = pm12_[ii + i1 + perm_[jj + j1 + perm_[kk + k1]]];
        int gi2 = pm12_[ii + i2 + perm_[jj + j2 + perm_[kk + k2]]];
        int gi3 = pm12_[ii + 1 + perm_[jj + 1 + perm_[kk + 1]]];
        float n = 0, gx = 0, gy = 0, gz = 0;
        corner(G[gi0], x0, y0, z0, n, gx, gy, gz, g != nullptr);
        corner(G[gi1], x1, y1, z1, n, gx, gy, gz, g != nullptr);
        corner(G[gi2], x2, y2, z2, n, gx, gy, gz, g != nullptr);
        corner(G[gi3], x3, y3, z3, n, gx, gy, gz, g != nullptr);
        if (g) { g[0] = 32.0f * gx; g[1] = 32.0f * gy; g[2] = 32.0f * gz; }
        return 32.0f * n;
    }
    float n3(float x, float y, float z) const { return n3d(x, y, z, nullptr); }

    // fractal Brownian motion, normalised to about [-1,1]
    float fbm(float x, float y, float z, int oct, float lac = 2.0f, float gain = 0.5f) const {
        float sum = 0, amp = 1, norm = 0, f = 1;
        for (int o = 0; o < oct; o++) {
            sum += amp * n3(x * f + 17.3f * o, y * f - 9.1f * o, z * f + 5.7f * o);
            norm += amp; amp *= gain; f *= lac;
        }
        return sum / norm;
    }
    // ridged multifractal in [0,1] (sharp crests)
    float ridged(float x, float y, float z, int oct, float lac = 2.0f, float gain = 0.5f) const {
        float sum = 0, amp = 1, norm = 0, f = 1, w = 1;
        for (int o = 0; o < oct; o++) {
            float n = 1.0f - std::fabs(n3(x * f + 31.7f * o, y * f + 3.3f * o, z * f - 11.9f * o));
            n *= n;
            n *= w;
            w = clampv(n * 1.6f, 0.0f, 1.0f);
            sum += amp * n; norm += amp; amp *= gain; f *= lac;
        }
        return sum / norm;
    }

private:
    static inline int ffloor(float x) { int i = (int)x; return x < (float)i ? i - 1 : i; }
    static inline void corner(const float* gg, float x, float y, float z, float& n, float& gx, float& gy, float& gz, bool wantG) {
        float t0 = 0.6f - x * x - y * y - z * z;
        if (t0 > 0.0f) {
            float t2 = t0 * t0, t4 = t2 * t2;
            float gd = gg[0] * x + gg[1] * y + gg[2] * z;
            n += t4 * gd;
            if (wantG) {
                float t3 = t2 * t0;
                gx += t4 * gg[0] - 8.0f * t3 * gd * x;
                gy += t4 * gg[1] - 8.0f * t3 * gd * y;
                gz += t4 * gg[2] - 8.0f * t3 * gd * z;
            }
        }
    }
    uint8_t perm_[512];
    uint8_t pm12_[512];
};

}  // namespace lw
