#include "chunk.h"
#include <cstdio>

namespace lw {

namespace {

struct Stop { float v, r, g, b; };

void rampColor(const Stop* st, int n, float v, float& r, float& g, float& b) {
    if (v <= st[0].v) { r = st[0].r; g = st[0].g; b = st[0].b; return; }
    for (int i = 1; i < n; i++) {
        if (v <= st[i].v) {
            float t = (v - st[i - 1].v) / (st[i].v - st[i - 1].v);
            r = st[i - 1].r + (st[i].r - st[i - 1].r) * t;
            g = st[i - 1].g + (st[i].g - st[i - 1].g) * t;
            b = st[i - 1].b + (st[i].b - st[i - 1].b) * t;
            return;
        }
    }
    r = st[n - 1].r; g = st[n - 1].g; b = st[n - 1].b;
}

const Stop kElev[] = {{-8000, 0.02f, 0.05f, 0.25f}, {-4000, 0.04f, 0.15f, 0.45f}, {-1000, 0.10f, 0.35f, 0.65f}, {-100, 0.30f, 0.65f, 0.85f},
                      {0, 0.55f, 0.85f, 0.90f}, {1, 0.20f, 0.55f, 0.20f}, {300, 0.45f, 0.65f, 0.25f}, {800, 0.75f, 0.72f, 0.35f},
                      {1800, 0.62f, 0.45f, 0.28f}, {3500, 0.55f, 0.45f, 0.42f}, {5500, 0.97f, 0.97f, 0.97f}};
const Stop kTemp[] = {{-40, 0.45f, 0.20f, 0.65f}, {-20, 0.20f, 0.30f, 0.85f}, {0, 0.40f, 0.80f, 0.90f}, {10, 0.40f, 0.80f, 0.40f},
                      {20, 0.95f, 0.90f, 0.30f}, {30, 0.95f, 0.50f, 0.15f}, {40, 0.85f, 0.10f, 0.10f}};
const Stop kRain[] = {{0, 0.90f, 0.80f, 0.50f}, {250, 0.90f, 0.90f, 0.55f}, {800, 0.50f, 0.80f, 0.40f}, {1600, 0.20f, 0.60f, 0.50f},
                      {3000, 0.15f, 0.40f, 0.80f}, {5000, 0.40f, 0.15f, 0.65f}};
const Stop kPres[] = {{985, 0.20f, 0.30f, 0.85f}, {1013, 0.90f, 0.90f, 0.90f}, {1040, 0.85f, 0.20f, 0.15f}};
const Stop kFert[] = {{0, 0.78f, 0.66f, 0.45f}, {0.4f, 0.60f, 0.65f, 0.25f}, {0.7f, 0.25f, 0.60f, 0.20f}, {1, 0.05f, 0.35f, 0.10f}};
const Stop kDepth[] = {{0, 0.60f, 0.90f, 0.95f}, {200, 0.25f, 0.65f, 0.85f}, {1000, 0.10f, 0.40f, 0.70f}, {4000, 0.05f, 0.15f, 0.45f}, {8000, 0.01f, 0.02f, 0.15f}};
const Stop kSpeed[] = {{0, 0.10f, 0.15f, 0.40f}, {5, 0.20f, 0.70f, 0.85f}, {10, 0.95f, 0.90f, 0.30f}, {20, 1.0f, 0.30f, 0.15f}};
#define RAMP(tbl, v, r, g, b) rampColor(tbl, (int)(sizeof(tbl) / sizeof(Stop)), (float)(v), r, g, b)

inline uint8_t u8(double v) { int i = (int)(v * 255.0 + 0.5); return (uint8_t)(i < 0 ? 0 : (i > 255 ? 255 : i)); }

// Chunk samples sit on a regular (u,v) lattice, so everything that depends on only one of u / v (cell index, fraction,
// spline weights, tan()) is computed once per column / row instead of once per sample.  The arithmetic is exactly the
// per-sample arithmetic it replaces, so results are bit-identical.
struct Axis {
    int i0;
    float t;
    float w[4];   // Catmull-Rom weights (filled when cubicW)
};

inline void axisAt(int N, double uv, bool cubicW, Axis& a) {
    double fu = (uv + 1.0) * 0.5 * N - 0.5;
    a.i0 = (int)std::floor(fu);
    a.t = (float)(fu - a.i0);
    if (cubicW) {
        float t = a.t, t2 = t * t, t3 = t2 * t;
        a.w[0] = -0.5f * t3 + t2 - 0.5f * t; a.w[1] = 1.5f * t3 - 2.5f * t2 + 1.0f; a.w[2] = -1.5f * t3 + 2.0f * t2 + 0.5f * t; a.w[3] = 0.5f * t3 - 0.5f * t2;
    }
}

// bilinear stencil on one cube face
inline void locateAx(const CubeGrid& g, int face, const Axis& X, const Axis& Y, int ids[4], float w[4]) {
    ids[0] = g.cellExt(face, X.i0, Y.i0);
    ids[1] = g.cellExt(face, X.i0 + 1, Y.i0);
    ids[2] = g.cellExt(face, X.i0, Y.i0 + 1);
    ids[3] = g.cellExt(face, X.i0 + 1, Y.i0 + 1);
    w[0] = (1 - X.t) * (1 - Y.t); w[1] = X.t * (1 - Y.t); w[2] = (1 - X.t) * Y.t; w[3] = X.t * Y.t;
}

// Catmull-Rom bicubic sample on one cube face
inline float cubicAx(const CubeGrid& g, int face, const float* f, const Axis& X, const Axis& Y) {
    bool inside = (X.i0 >= 1 && X.i0 + 2 < g.N && Y.i0 >= 1 && Y.i0 + 2 < g.N);
    float sum = 0;
    for (int b = 0; b < 4; b++) {
        float row = 0;
        for (int a = 0; a < 4; a++) {
            int c = inside ? g.idx(face, X.i0 - 1 + a, Y.i0 - 1 + b) : g.cellExt(face, X.i0 - 1 + a, Y.i0 - 1 + b);
            row += X.w[a] * f[c];
        }
        sum += Y.w[b] * row;
    }
    return sum;
}

constexpr int kLN = kT + 3;   // lattice samples per edge (1 border + 1 spare each side)

struct Scratch {
    std::vector<V3> dir;
    std::vector<float> h, wl;
    std::vector<float> riv;
    std::vector<V3> P;
    // per-column / per-row tables
    Axis latFx[kLN], latFy[kLN], latCx[kLN], latCy[kLN];   // lattice: fine grid (with spline weights), coarse grid
    double tanU[kLN], tanV[kLN];
    Axis texFx[kD], texFy[kD], texCx[kD], texCy[kD];       // texels: fine grid, coarse grid
};
thread_local Scratch tl;

// rasterise river segments of the fine-grid flow network into riv[kD*kD]
void rasterRivers(const Sampler& S, int face, double u0, double v0, double size, double texM, const V3& fn, const V3& t1, const V3& t2, std::vector<float>& riv) {
    const CubeGrid& g = S.fg;
    const int N = g.N;
    double Qthr = std::max(3.0, 40.0 * texM / 1000.0);
    int i0 = clampv((int)std::floor((u0 + 1.0) * 0.5 * N) - 2, 0, N - 1), i1 = clampv((int)std::floor((u0 + size + 1.0) * 0.5 * N) + 2, 0, N - 1);
    int j0 = clampv((int)std::floor((v0 + 1.0) * 0.5 * N) - 2, 0, N - 1), j1 = clampv((int)std::floor((v0 + size + 1.0) * 0.5 * N) + 2, 0, N - 1);
    auto toXY = [&](const V3& p, double& X, double& Y) {
        double dn = dot(p, fn);
        double a = dot(p, t1) / dn, b = dot(p, t2) / dn;
        X = (datan(a) * (4.0 / PI) - u0) / size * kT;
        Y = (datan(b) * (4.0 / PI) - v0) / size * kT;
    };
    for (int j = j0; j <= j1; j++)
        for (int i = i0; i <= i1; i++) {
            int c = g.idx(face, i, j);
            double Q = S.H.discharge[c];
            if (Q < Qthr || S.T.height[c] <= 0.f) continue;
            int r = S.H.rec[c];
            if (r < 0 || dot(g.pos[r], fn) < 0.2) continue;
            V3 p0 = g.pos[c], p1 = g.pos[r];
            double wm = 2.5 * std::sqrt(Q);
            if (S.T.height[r] <= 0.f) wm *= 1.8;
            double wpx = clampv(wm / texM, 1.15, 40.0);
            V3 dv = p1 - p0;
            double len = length(dv);
            V3 pr;
            double X0 = 0, Y0 = 0;
            const int M = 6;
            for (int k = 0; k <= M; k++) {
                double s = (double)k / M;
                V3 p = normalize(p0 * (1.0 - s) + p1 * s);
                double nse = S.s.noise.n3((float)(c % 997) * 0.731f + (float)s * 2.3f, (float)(c / 997) * 0.377f, 3.1f);
                V3 perp = normalize(cross(p, dv));
                p = normalize(p + perp * (0.34 * len * dsin(PI * s) * nse));
                double X, Y;
                toXY(p, X, Y);
                if (k > 0) {
                    double minx = std::min(X, X0) - wpx - 1, maxx = std::max(X, X0) + wpx + 1, miny = std::min(Y, Y0) - wpx - 1, maxy = std::max(Y, Y0) + wpx + 1;
                    int tx0 = clampv((int)std::floor(minx) + 1, 0, kD - 1), tx1 = clampv((int)std::ceil(maxx) + 1, 0, kD - 1);
                    int ty0 = clampv((int)std::floor(miny) + 1, 0, kD - 1), ty1 = clampv((int)std::ceil(maxy) + 1, 0, kD - 1);
                    double ex = X - X0, ey = Y - Y0, el2 = ex * ex + ey * ey;
                    for (int ty = ty0; ty <= ty1; ty++)
                        for (int tx = tx0; tx <= tx1; tx++) {
                            double cx = tx - 0.5, cy = ty - 0.5;
                            double tt = el2 > 1e-12 ? clampv(((cx - X0) * ex + (cy - Y0) * ey) / el2, 0.0, 1.0) : 0.0;
                            double dx = cx - (X0 + ex * tt), dy = cy - (Y0 + ey * tt);
                            double dd = std::sqrt(dx * dx + dy * dy);
                            float a = (float)clampv((wpx * 0.5 + 0.75 - dd), 0.0, 1.0);
                            float& o = riv[ty * kD + tx];
                            if (a > o) o = a;
                        }
                }
                X0 = X; Y0 = Y;
            }
        }
}

}  // namespace

bool buildChunk(const View& v, int face, int level, int cx, int cy, int layer, uint8_t* vtx, uint8_t* albedo, uint8_t* normal, double* meta) {
    if (!v) return false;
    Sampler S(v);
    const double R = S.Rm;
    const int nTiles = 1 << level;
    const double size = 2.0 / nTiles;
    const double u0 = -1.0 + cx * size, v0 = -1.0 + cy * size;
    V3 fn, t1, t2;
    CubeGrid::faceAxes(face, fn, t1, t2);
    const V3 cdir = CubeGrid::faceDir(face, u0 + size * 0.5, v0 + size * 0.5);
    const V3 C0 = cdir * R;
    const double edgeM = length(CubeGrid::faceDir(face, u0, v0 + size * 0.5) - CubeGrid::faceDir(face, u0 + size, v0 + size * 0.5)) * R;
    const double texM = edgeM / kT;
    const double lamMin = std::max(5.0, 2.2 * texM);
    const int LN = kLN;
    Scratch& sc = tl;   // bind the thread-local once (TLS access can be a runtime call on older Android)
    sc.dir.resize((size_t)LN * LN);
    sc.h.resize((size_t)LN * LN);
    sc.wl.resize((size_t)LN * LN);
    sc.P.resize((size_t)LN * LN);
    sc.riv.assign((size_t)kD * kD, 0.f);
    const CubeGrid& fg = *S.s.fg;
    const CubeGrid& cgr = *S.s.cg;
    const TerrainData& T = S.T;
    const HydroData& H = S.H;
    const EcoData& E = S.E;
    const DynamicData& D = S.d;

    // ---- lattice of positions and heights --------------------------------------------------------
    V3* const dirP = sc.dir.data();
    float* const hP = sc.h.data();
    float* const wlP = sc.wl.data();
    V3* const PP = sc.P.data();
    {
        for (int li = 0; li < LN; li++) {
            double u = u0 + (li - 1) * size / kT;
            axisAt(fg.N, u, true, sc.latFx[li]);
            axisAt(cgr.N, u, false, sc.latCx[li]);
            sc.tanU[li] = dtan(u * (PI / 4.0));
        }
        for (int lj = 0; lj < LN; lj++) {
            double vv = v0 + (lj - 1) * size / kT;
            axisAt(fg.N, vv, true, sc.latFy[lj]);
            axisAt(cgr.N, vv, false, sc.latCy[lj]);
            sc.tanV[lj] = dtan(vv * (PI / 4.0));
        }
        Sampler::DetailTab dtab;
        S.makeDetailTab(lamMin, dtab);
        const float* const heightP = T.height.data();
        const float* const glacierP = D.glacier.data();
        const float* const roughP = T.rough.data();
        const float* const lakeP = H.lakeLevel.data();
        for (int lj = 0; lj < LN; lj++) {
            const Axis& Yf = sc.latFy[lj];
            const Axis& Yc = sc.latCy[lj];
            for (int li = 0; li < LN; li++) {
                const Axis& Xf = sc.latFx[li];
                const Axis& Xc = sc.latCx[li];
                V3 p = CubeGrid::dirFromTan(face, sc.tanU[li], sc.tanV[lj]);
                size_t k = (size_t)lj * LN + li;
                dirP[k] = p;
                double base = cubicAx(fg, face, heightP, Xf, Yf);
                int ids[4];
                float w[4];
                locateAx(cgr, face, Xc, Yc, ids, w);
                float gl = 0;
                for (int q = 0; q < 4; q++) gl += w[q] * glacierP[ids[q]];
                if (gl > 1.0f && base > 0) base += 0.85 * gl;
                locateAx(fg, face, Xf, Yf, ids, w);
                float rough = 0, ll = 0;
                for (int q = 0; q < 4; q++) { rough += w[q] * roughP[ids[q]]; ll += w[q] * lakeP[ids[q]]; }
                double h = base + S.detailT(p, rough, base, dtab);
                hP[k] = (float)h;
                bool lake = ll > h + 0.5 && ll > 0.5 && base > -5.0;
                wlP[k] = lake ? ll : (h < 0 ? 0.f : -1e5f);
                double surf = std::max(h, (double)wlP[k]);
                PP[k] = p * (R + (h < 0 ? h : surf));
            }
        }
    }

    // ---- vertex buffer ----------------------------------------------------------------------------
    {
        float* fv = reinterpret_cast<float*>(vtx);
        float skirt = (float)clampv(edgeM * 0.03, 8.0, 8000.0);
        double maxr = 0, hmin = 1e9, hmax = -1e9;
        auto put = [&](int idx, int gi, int gj, bool sk) {
            int li = 1 + gi * (kT / kG), lj = 1 + gj * (kT / kG);
            size_t k = (size_t)lj * LN + li;
            double surf = std::max((double)hP[k], (double)wlP[k]);
            if (surf < 0) surf = 0;
            hmin = std::min(hmin, surf); hmax = std::max(hmax, surf);
            V3 pos = dirP[k] * (R + surf - (sk ? skirt : 0.0)) - C0;
            uint8_t* o = vtx + (size_t)idx * kVertBytes;
            float* f = reinterpret_cast<float*>(o);
            f[0] = (float)pos.x; f[1] = (float)pos.y; f[2] = (float)pos.z;
            maxr = std::max(maxr, length(pos));
            uint16_t* uv = reinterpret_cast<uint16_t*>(o + 12);
            uv[0] = (uint16_t)clampv((int)std::lround(65535.0 * gi / kG), 0, 65535);
            uv[1] = (uint16_t)clampv((int)std::lround(65535.0 * gj / kG), 0, 65535);
        };
        (void)fv;
        for (int gj = 0; gj < kVG; gj++)
            for (int gi = 0; gi < kVG; gi++) put(gj * kVG + gi, gi, gj, false);
        int base = kVG * kVG;
        for (int i = 0; i < kVG; i++) put(base + i, i, 0, true);
        for (int i = 0; i < kVG; i++) put(base + kVG + i, i, kG, true);
        for (int j = 0; j < kVG; j++) put(base + 2 * kVG + j, 0, j, true);
        for (int j = 0; j < kVG; j++) put(base + 3 * kVG + j, kG, j, true);
        meta[0] = C0.x; meta[1] = C0.y; meta[2] = C0.z;
        meta[3] = maxr + 1.0;
        meta[4] = hmin; meta[5] = hmax;
        meta[6] = t1.x; meta[7] = t1.y; meta[8] = t1.z;
    }

    // ---- rivers -----------------------------------------------------------------------------------
    if (layer == L_VISUAL || layer == L_RIVERS || layer == L_BIOMES) rasterRivers(S, face, u0, v0, size, texM, fn, t1, t2, sc.riv);

    // ---- per-texel textures ------------------------------------------------------------------------
    const double tAmbient = 1.0;
    (void)tAmbient;
    const double gam = S.gam;
    TectFrame tf;
    if (layer == L_PLATES || layer == L_BOUNDARIES) S.s.tect.makeFrame(S.s.tectTimeMyr, tf);
    const double detSc = std::max(40.0, R / (9.0 * texM));
    const V3 lightFixed = normalize(V3(-0.5, 0.6, 0.62));
    const V3 lightFixedN = normalize(lightFixed);   // loop invariant
    const float sunLat = 0;
    (void)sunLat;
    for (int ti = 0; ti < kD; ti++) {
        double u = u0 + (ti - 0.5) * size / kT;
        axisAt(fg.N, u, false, sc.texFx[ti]);
        axisAt(cgr.N, u, false, sc.texCx[ti]);
    }
    for (int tj = 0; tj < kD; tj++) {
        double vv = v0 + (tj - 0.5) * size / kT;
        axisAt(fg.N, vv, false, sc.texFy[tj]);
        axisAt(cgr.N, vv, false, sc.texCy[tj]);
    }
    float* const rivP = sc.riv.data();
    for (int tj = 0; tj < kD; tj++) {
        for (int ti = 0; ti < kD; ti++) {
            size_t k00 = (size_t)tj * LN + ti, k10 = k00 + 1, k01 = k00 + LN, k11 = k01 + 1;
            V3 N = normalize(dirP[k00] + dirP[k10] + dirP[k01] + dirP[k11]);
            double h = 0.25 * ((double)hP[k00] + hP[k10] + hP[k01] + hP[k11]);
            double wl = 0.25 * ((double)wlP[k00] + wlP[k10] + wlP[k01] + wlP[k11]);
            bool lakeT = wl > h + 0.5 && wl > 0.5 && (wlP[k00] > 0 || wlP[k11] > 0);
            bool oceanT = !lakeT && h < 0.0;
            bool water = lakeT || oceanT;
            // surface normal from the lattice
            V3 tx = (PP[k10] + PP[k11] - PP[k00] - PP[k01]) * 0.5;
            V3 ty = (PP[k01] + PP[k11] - PP[k00] - PP[k10]) * 0.5;
            V3 nrm = normalize(cross(tx, ty));
            if (dot(nrm, N) < 0) nrm = -nrm;
            // tangent-space normal (water is flat) and slope: only derived where they are used
            double nx = 0.0, ny = 0.0;
            if (!water) {
                V3 T1 = normalize(t1 - N * dot(t1, N));
                V3 T2 = cross(N, T1);
                nx = dot(nrm, T1); ny = dot(nrm, T2);
            }
            auto slopeOf = [&]() {
                double nzF = dot(nrm, N);
                return std::sqrt(std::max(0.0, 1.0 - nzF * nzF)) / std::max(0.05, nzF);
            };
            {
                size_t o = ((size_t)tj * kD + ti) * 2;
                normal[o] = u8(nx * 0.5 + 0.5);
                normal[o + 1] = u8(ny * 0.5 + 0.5);
            }
            // fine-grid climate fields
            int ids[4];
            float w[4];
            locateAx(fg, face, sc.texFx[ti], sc.texFy[tj], ids, w);
            auto F = [&](const std::vector<float>& f) { return (double)(w[0] * f[ids[0]] + w[1] * f[ids[1]] + w[2] * f[ids[2]] + w[3] * f[ids[3]]); };
            double hb = F(T.height);
            int cs = ids[0];
            {
                float mx = w[0];
                for (int q = 1; q < 4; q++) if (w[q] > mx) { mx = w[q]; cs = ids[q]; }
            }
            double r = 0, g = 0, b = 0, aw = 0;
            float rr, gg, bb;
            if (layer == L_ELEVATION) {
                double hh = water ? (lakeT ? wl : h) : h;
                RAMP(kElev, hh, rr, gg, bb);
                r = rr; g = gg; b = bb;
            } else if (layer == L_OCEAN_DEPTH) {
                if (oceanT) { RAMP(kDepth, -h, rr, gg, bb); r = rr; g = gg; b = bb; }
                else if (lakeT) { r = 0.3; g = 0.6; b = 0.7; }
                else { double c = clampv(0.25 + h / 6000.0, 0.15, 0.6); r = c; g = c * 0.95; b = c * 0.9; }
            } else if (layer == L_TEMPERATURE) {
                double tcur;
                {
                    int cid[4];
                    float cw[4];
                    locateAx(cgr, face, sc.texCx[ti], sc.texCy[tj], cid, cw);
                    double ta = 0, zm = 0;
                    for (int q = 0; q < 4; q++) { ta += cw[q] * (water && oceanT ? D.ts[cid[q]] : D.ta[cid[q]]); zm += cw[q] * S.s.st().zMean[cid[q]]; }
                    tcur = ta - 273.15;
                    if (!oceanT) tcur -= gam * (std::max(h, 0.0) - zm);
                }
                RAMP(kTemp, tcur, rr, gg, bb);
                r = rr; g = gg; b = bb;
            } else if (layer == L_RAINFALL) {
                RAMP(kRain, F(E.pAnn), rr, gg, bb);
                r = rr; g = gg; b = bb;
            } else if (layer == L_PRESSURE) {
                int cid[4];
                float cw[4];
                locateAx(cgr, face, sc.texCx[ti], sc.texCy[tj], cid, cw);
                double p = 0;
                for (int q = 0; q < 4; q++) p += cw[q] * D.pres[cid[q]];
                RAMP(kPres, p, rr, gg, bb);
                r = rr; g = gg; b = bb;
                double ph = p / 4.0;
                double fr = ph - std::floor(ph);
                double iso = smoothstep(0.10, 0.0, std::min(fr, 1.0 - fr) * 4.0 * 0.5);
                r = r * (1 - 0.35 * iso); g = g * (1 - 0.35 * iso); b = b * (1 - 0.35 * iso);
            } else if (layer == L_WIND) {
                int cc = S.cg.cellOf(N);
                double wu = D.wu[cc], wv = D.wv[cc];
                double sp = std::sqrt(wu * wu + wv * wv);
                V3 e, nn;
                eastNorth(S.cg.pos[cc], e, nn);
                V3 dvv = N - S.cg.pos[cc];
                double X = dot(dvv, e) * R / 1000.0, Y = dot(dvv, nn) * R / 1000.0;
                double cellKm = S.cg.cellKm(cc, R / 1000.0);
                double ux = sp > 1e-6 ? wu / sp : 1.0, uy = sp > 1e-6 ? wv / sp : 0.0;
                double L = cellKm * clampv(0.15 + 0.035 * sp, 0.15, 0.46), hl = L * 0.5;
                double a = X * ux + Y * uy, bq = -X * uy + Y * ux;
                double base = water ? 0.10 : 0.16;
                r = base * 0.6; g = base * 0.8; b = base + (oceanT ? 0.10 : 0.0);
                double wb = cellKm * 0.035;
                bool body = std::fabs(a) <= hl && std::fabs(bq) < wb;
                bool head = a > hl - 0.32 * L && a <= hl + 0.08 * L && std::fabs(bq) < (hl + 0.08 * L - a) * 0.55;
                if (body || head) { RAMP(kSpeed, sp, rr, gg, bb); r = rr; g = gg; b = bb; }
            } else if (layer == L_PLATES || layer == L_BOUNDARIES) {
                TectSample ts;
                S.s.tect.sample(tf, N, ts);
                uint64_t hh = mix64((uint64_t)ts.plate * 977 + 5);
                double pr = 0.35 + 0.5 * (double)(hh & 255) / 255.0, pg = 0.35 + 0.5 * (double)((hh >> 8) & 255) / 255.0, pb = 0.35 + 0.5 * (double)((hh >> 16) & 255) / 255.0;
                double dim = water ? 0.55 : 1.0;
                if (layer == L_BOUNDARIES) { pr = pg = pb = water ? 0.10 : 0.22; pb += water ? 0.12 : 0.0; dim = 1.0; }
                r = pr * dim; g = pg * dim; b = pb * dim;
                double wk = std::max(texM * 1.0, layer == L_BOUNDARIES ? 22.0 : 10.0) / 1000.0;
                if (ts.distKm < wk * 1.0 || ts.distKm < std::max(texM, 14.0) / 1000.0 * (layer == L_BOUNDARIES ? 1.6 : 1.0) ) {
                    if (ts.type == 1) { r = 1.0; g = 0.2; b = 0.15; }
                    else if (ts.type == 2) { r = 0.25; g = 0.5; b = 1.0; }
                    else if (ts.type == 3) { r = 0.3; g = 0.95; b = 0.3; }
                    else { r = 0.9; g = 0.9; b = 0.9; }
                }
            } else if (layer == L_SOIL) {
                if (water) { r = 0.06; g = 0.10; b = 0.20; }
                else { RAMP(kFert, F(E.fertility), rr, gg, bb); r = rr; g = gg; b = bb; }
            } else {
                // ---------------- visual / biome / rivers ----------------
                int cid[4];
                float cw[4];
                locateAx(cgr, face, sc.texCx[ti], sc.texCy[tj], cid, cw);
                auto Cc = [&](const std::vector<float>& f) { return (double)(cw[0] * f[cid[0]] + cw[1] * f[cid[1]] + cw[2] * f[cid[2]] + cw[3] * f[cid[3]]); };
                float px = (float)(N.x * detSc), py = (float)(N.y * detSc), pz = (float)(N.z * detSc);
                float nz1 = S.s.noise.fbm(px, py, pz, 3);
                double tint = 1.0 + 0.10 * nz1;
                if (oceanT) {
                    double depth = -h;
                    double zz = clampv(depth, 0.0, 9000.0);
                    RAMP(kDepth, zz, rr, gg, bb);
                    r = rr; g = gg; b = bb;
                    V3 flr = nrm;
                    double sh = dot(flr, lightFixedN) - 0.55;
                    double fdepth = dexp(-depth / 500.0);
                    double fac = 1.0 + 0.9 * fdepth * clampv(sh, -0.6, 0.6);
                    r *= fac; g *= fac; b *= fac;
                    double ice = Cc(D.ice);
                    double ic = smoothstep(0.30 + 0.25 * nz1, 0.75 + 0.25 * nz1, ice);
                    if (ic > 0) { r = r + (0.86 - r) * ic; g = g + (0.92 - g) * ic; b = b + (0.96 - b) * ic; }
                    aw = 1.0 - 0.75 * ic;
                } else if (lakeT) {
                    double depth = std::max(0.0, wl - h);
                    double t = clampv(depth / 60.0, 0.0, 1.0);
                    r = 0.10 - 0.04 * t; g = 0.36 - 0.14 * t; b = 0.45 - 0.12 * t;
                    int lk = H.lakeKind[cs];
                    if (lk == 3) { r = 0.82; g = 0.82; b = 0.78; aw = 0.2; }
                    else aw = 1.0;
                } else {
                    // land: derive biome from local climate (lapse-corrected for the fine terrain)
                    const double slopeTan = slopeOf();
                    double dh = h - hb;
                    double tAnn = F(E.tAnn) - gam * dh, tMin = F(E.tMin) - gam * dh, tMax = F(E.tMax) - gam * dh;
                    double pAnn = F(E.pAnn), ai = F(E.aridity);
                    double wet = clampv(F(E.soilMoist) * (1.0 - clampv(slopeTan / 0.1, 0.0, 1.0)) * 0.9 + 0.4 * (double)rivP[tj * kD + ti] - 0.2, 0.0, 1.0);
                    bool coastal = hb < 14.0;
                    // |latitude| is only consulted by one rare rule, so it is derived lazily
                    BiomeIn bi{tAnn, tMin, tMax, pAnn, ai, F(E.pDryFrac) * 12.0, h, slopeTan * 0.25, wet, 0.0, coastal};
                    uint8_t bio = classifyBiomeLazy(bi, [&N]() { return std::fabs(latOf(N)) * RAD2DEG; });
                    float cr, cg2, cb;
                    biomeColor(bio, cr, cg2, cb);
                    r = cr; g = cg2; b = cb;
                    if (layer == L_VISUAL) {
                        double fert = F(E.fertility);
                        double veg = (bio == B_DESERT || bio == B_ICE || bio == B_ALPINE) ? 0.25 : 1.0;
                        // patchiness & soil tone
                        double n2 = S.s.noise.fbm(px * 0.21f + 7.0f, py * 0.21f, pz * 0.21f, 3);
                        double soilTone = 1.0 + 0.16 * n2;
                        r *= tint * soilTone; g *= tint * soilTone * (1.0 + 0.05 * n2 * veg); b *= tint * soilTone;
                        // exposed rock on steep ground and above the vegetation limit
                        double steep = smoothstep(0.45, 1.1, slopeTan);
                        double bare = std::max(steep, smoothstep(9.0, 3.0, tMax) * 0.8);
                        if (bio == B_DESERT) bare *= 0.6;
                        double rk = 0.34 + 0.12 * nz1;
                        r += (rk * 1.05 - r) * bare; g += (rk * 0.98 - g) * bare; b += (rk * 0.90 - b) * bare;
                        // snow: seasonal cover from the simulated snow depth + permanent snow above the snow line
                        double tcur = Cc(D.ta) - 273.15 - gam * (h - Cc(S.s.st().zMean));
                        double sdepth = Cc(D.snow);
                        double snowSeason = smoothstep(1.0, -3.0, tcur) * clampv(0.15 + sdepth / 50.0, 0.0, 1.0);
                        double glc = Cc(D.glacier);
                        double gk = smoothstep(2.0, 70.0, glc + 30.0 * nz1);
                        double snowPerm = std::max(smoothstep(2.0, -1.0, tMax), gk * smoothstep(9.0, 0.0, tMax));
                        double snow = std::max(snowSeason, snowPerm);
                        snow *= (1.0 - 0.55 * steep);
                        if (bio == B_ICE) snow = 1.0;
                        double sn = snow * (0.9 + 0.1 * nz1);
                        r += (0.93 - r) * sn; g += (0.95 - g) * sn; b += (0.98 - b) * sn;
                        // beaches
                        if (h < 4.0 && coastal && wet < 0.8) { double bt = smoothstep(4.0, 0.0, h) * 0.75; r += (0.80 - r) * bt; g += (0.74 - g) * bt; b += (0.55 - b) * bt; }
                        (void)fert;
                    }
                    if (layer == L_RIVERS) { r *= 0.45; g *= 0.45; b *= 0.45; }
                }
                float rv = rivP[tj * kD + ti];
                if (rv > 0.0f && !oceanT && (layer == L_VISUAL || layer == L_RIVERS || layer == L_BIOMES)) {
                    double cr = layer == L_RIVERS ? 0.10 : 0.12, cg2 = layer == L_RIVERS ? 0.55 : 0.34, cb = layer == L_RIVERS ? 1.0 : 0.52;
                    r += (cr - r) * rv; g += (cg2 - g) * rv; b += (cb - b) * rv;
                    aw = std::max(aw, (double)rv * 0.8);
                }
                if (layer == L_RIVERS && lakeT) { r = 0.2; g = 0.7; b = 1.0; }
                if (layer == L_RIVERS && oceanT) { r *= 0.35; g *= 0.4; b *= 0.6; }
                if (layer == L_BIOMES && !water) {
                    // flat biome colours, without photographic variation
                    const double slopeTan = slopeOf();
                    double dh = h - hb;
                    double tAnn = F(E.tAnn) - gam * dh;
                    BiomeIn bi{tAnn, F(E.tMin) - gam * dh, F(E.tMax) - gam * dh, F(E.pAnn), F(E.aridity), F(E.pDryFrac) * 12.0, h, slopeTan * 0.25, clampv(F(E.soilMoist) * (1.0 - clampv(slopeTan / 0.1, 0.0, 1.0)) * 0.9 - 0.2, 0.0, 1.0), 0.0, hb < 14.0};
                    float cr, cg2, cb;
                    biomeColor(classifyBiomeLazy(bi, [&N]() { return std::fabs(latOf(N)) * RAD2DEG; }), cr, cg2, cb);
                    r = cr; g = cg2; b = cb;
                }
            }
            size_t o = ((size_t)tj * kD + ti) * 4;
            albedo[o] = u8(r); albedo[o + 1] = u8(g); albedo[o + 2] = u8(b);
            albedo[o + 3] = u8(layer == L_VISUAL || layer == L_RIVERS ? aw : 0.0);
        }
    }
    return true;
}

void buildCloudTexture(const View& v, int w, int h, uint8_t* out) {
    if (!v) return;
    const CubeGrid& cg = *v.s->cg;
    const Noise& nz = v.s->noise;
    for (int y = 0; y < h; y++) {
        double lat = (0.5 - (y + 0.5) / h) * PI;
        for (int x = 0; x < w; x++) {
            double lon = ((x + 0.5) / w - 0.5) * TAU;
            V3 p = fromLatLon(lat, lon);
            double cover = cg.sample(v.d->cloud.data(), p);
            float n = 0.5f + 0.5f * nz.fbm((float)p.x * 6.5f + 3.0f, (float)p.y * 6.5f, (float)p.z * 6.5f, 5);
            double dens = cover * 1.55 - 0.40 + (n - 0.5) * 1.05;
            out[(size_t)y * w + x] = u8(smoothstep(0.0, 0.45, dens));
        }
    }
}

double heightAtLatLon(const View& v, double latDeg, double lonDeg) {
    if (!v) return 0;
    Sampler S(v);
    V3 p = fromLatLon(latDeg * DEG2RAD, lonDeg * DEG2RAD);
    double h = S.height(p, 30.0);
    double ll = S.fg.sample(S.H.lakeLevel.data(), p);
    if (ll > h + 0.5 && ll > 0.5) h = ll;
    return std::max(0.0, h);
}

std::string inspectText(const View& v, double latDeg, double lonDeg, int layer) {
    (void)layer;
    if (!v) return "";
    Sampler S(v);
    V3 p = fromLatLon(latDeg * DEG2RAD, lonDeg * DEG2RAD);
    char b[1400];
    int len = 0;
    double h = S.height(p, 60.0);
    int fc = S.fg.cellOf(p), cc = S.cg.cellOf(p);
    bool ocean = h <= 0.0;
    double zm = S.cg.sample(S.s.st().zMean.data(), p);
    double tcur = S.cur(S.d.ta, p) - 273.15 - (ocean ? 0.0 : S.gam * (h - zm));
    if (ocean) tcur = S.cur(S.d.ts, p) - 273.15;
    double wu = S.cur(S.d.wu, p), wv = S.cur(S.d.wv, p);
    double sp = std::sqrt(wu * wu + wv * wv);
    double dirFrom = std::fmod(std::atan2(-wu, -wv) * RAD2DEG + 360.0, 360.0);
    static const char* cp[8] = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
    const char* cdir = cp[((int)((dirFrom + 22.5) / 45.0)) % 8];
    TectSample ts;
    TectFrame fr;
    S.s.tect.makeFrame(S.s.tectTimeMyr, fr);
    S.s.tect.sample(fr, p, ts);
    static const char* bt[4] = {"interior", "convergent", "divergent", "transform"};
    len += snprintf(b + len, sizeof(b) - len, "%.2f%c %.2f%c\n", std::fabs(latDeg), latDeg >= 0 ? 'N' : 'S', std::fabs(lonDeg), lonDeg >= 0 ? 'E' : 'W');
    if (ocean) len += snprintf(b + len, sizeof(b) - len, "Ocean depth %.0f m\n", -h);
    else len += snprintf(b + len, sizeof(b) - len, "Elevation %.0f m\n", h);
    len += snprintf(b + len, sizeof(b) - len, "Temp %.1f C (annual %.1f)\n", tcur, S.fg.sample(S.E.tAnn.data(), p));
    len += snprintf(b + len, sizeof(b) - len, "Rain %.0f mm/yr (now %.1f mm/d)\n", S.fg.sample(S.E.pAnn.data(), p), S.cur(S.d.precip, p));
    len += snprintf(b + len, sizeof(b) - len, "Biome %s\n", ocean ? "Ocean" : biomeName(S.E.biome[fc]));
    len += snprintf(b + len, sizeof(b) - len, "Fertility %.2f  Moisture %.2f\n", S.E.fertility[fc], S.E.soilMoist[fc]);
    len += snprintf(b + len, sizeof(b) - len, "Wind %.1f m/s from %s  Pres %.0f hPa\n", sp, cdir, S.cur(S.d.pres, p));
    len += snprintf(b + len, sizeof(b) - len, "Plate %d / %d  %s %.0f km (%.1f cm/yr)\n", ts.plate, ts.other, bt[ts.type], ts.distKm, ts.conv);
    if (!ocean && S.H.discharge[fc] > 1.0f) len += snprintf(b + len, sizeof(b) - len, "River %.0f m3/s\n", S.H.discharge[fc]);
    (void)cc;
    return std::string(b, len);
}

}  // namespace lw
