// Read-only access to the simulated planet at arbitrary positions and any level of detail.
// Large scales come from the simulation grids; small scales are fractal detail whose amplitude
// is steered by simulated roughness (tectonic activity, relief), so detail is consistent with the
// geology instead of being random noise.
#pragma once
#include "world.h"
#include "biome.h"

namespace lw {

struct Sampler {
    const StaticData& s;
    const DynamicData& d;
    const CubeGrid& fg;
    const CubeGrid& cg;
    const TerrainData& T;
    const HydroData& H;
    const EcoData& E;
    double Rm, gam;

    explicit Sampler(const View& v)
        : s(*v.s), d(*v.d), fg(*v.s->fg), cg(*v.s->cg), T(v.s->T()), H(v.s->H()), E(v.s->E()), Rm(v.s->dv.R), gam(v.s->dv.lapse) {}

    double baseHeight(const V3& p) const {
        double h = fg.sampleCubic(T.height.data(), p);
        float gl = cg.sample(d.glacier.data(), p);
        if (gl > 1.0f && h > 0) h += 0.85 * gl;
        return h;
    }
    double roughAt(const V3& p) const { return fg.sample(T.rough.data(), p); }

    // fractal detail (metres). lamMin = smallest wavelength worth synthesising.
    double detail(const V3& p, double rough, double base, double lamMin) const {
        double sum = 0, lam = 62000.0;
        double land = base > -30.0 ? 1.0 : 0.16;
        double amp = 560.0 * rough * land;
        float gx = 0, gy = 0, gz = 0;
        for (int j = 0; j < 14 && lam >= lamMin; j++, lam *= 0.5, amp *= 0.5359) {
            double sc = Rm / lam;
            float g[3];
            float n = s.noise.n3d((float)(p.x * sc + 17.3 * j), (float)(p.y * sc - 9.1 * j), (float)(p.z * sc + 5.7 * j), g);
            gx += g[0]; gy += g[1]; gz += g[2];
            double damp = 1.0 / (1.0 + 0.55 * (double)(gx * gx + gy * gy + gz * gz));
            float v = j < 4 ? (1.0f - std::fabs(n)) * 1.6f - 0.8f : n;
            sum += amp * v * damp;
        }
        return sum;
    }
    double height(const V3& p, double lamMin) const {
        double b = baseHeight(p);
        return b + detail(p, roughAt(p), b, lamMin);
    }
    // lake surface elevation (== height where no lake)
    double lakeLevel(const V3& p) const { return fg.sample(H.lakeLevel.data(), p); }

    // current-date climate at coarse resolution (bilinear)
    float cur(const std::vector<float>& f, const V3& p) const { return cg.sample(f.data(), p); }
};

}  // namespace lw
