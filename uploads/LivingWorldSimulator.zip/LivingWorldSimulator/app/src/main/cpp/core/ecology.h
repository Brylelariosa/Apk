// Hydrology, soil, vegetation, biomes, resources and hazards on the fine grid.
#pragma once
#include "world_data.h"
#include "noise.h"

namespace lw {

// Downscale the coarse climate cycle to the fine terrain grid, route water, build rivers/lakes, soils, biomes.
// Also returns the coarse vegetation / soil-capacity / glacier fields that feed back into the climate.
void buildHydroEco(const PlanetParams& pp, const Derived& dv, const Noise& nz, const CubeGrid& cg, const CubeGrid& fg,
                   const TerrainData& T, const ClimateSlices& sl, const ClimateStatic& st, const std::vector<float>& oroVec,
                   HydroData& H, EcoData& E, std::vector<float>& vegCoarse, std::vector<float>& soilCapCoarse,
                   std::vector<float>& glacierCoarse, const ProgressFn& progress);

}  // namespace lw
