// Streaming terrain chunks.  A chunk is a quadtree node of a cube-face: a 33x33 vertex mesh (+skirts)
// and two small textures (albedo+water mask, tangent-space normal), generated on worker threads.
#pragma once
#include "sampler.h"

namespace lw {

constexpr int kG = 32;                       // mesh cells per chunk edge
constexpr int kVG = kG + 1;                  // vertices per edge
constexpr int kVertCount = kVG * kVG + 4 * kVG;   // grid + 4 skirts
constexpr int kVertBytes = 16;               // float3 position + 2x uint16 uv
constexpr int kT = 96;                       // texels per chunk edge
constexpr int kD = kT + 2;                   // texture size incl. 1 texel border
constexpr int kAlbedoBytes = kD * kD * 4;
constexpr int kNormalBytes = kD * kD * 2;
constexpr int kMaxLevel = 16;

enum Layer : int {
    L_VISUAL = 0, L_ELEVATION, L_TEMPERATURE, L_RAINFALL, L_WIND, L_PRESSURE, L_RIVERS, L_PLATES, L_BOUNDARIES,
    L_BIOMES, L_SOIL, L_OCEAN_DEPTH, L_COUNT
};

// meta[0..2] origin (chunk centre at sea level, metres from planet centre), meta[3] bounding radius,
// meta[4] min height, meta[5] max height, meta[6] face tangent-1 x? (unused), meta[7] reserved
bool buildChunk(const View& v, int face, int level, int cx, int cy, int layer, uint8_t* vtx, uint8_t* albedo, uint8_t* normal, double* meta);

// equirectangular cloud cover (R8)
void buildCloudTexture(const View& v, int w, int h, uint8_t* out);

std::string inspectText(const View& v, double latDeg, double lonDeg, int layer);
std::string explainText(const View& v, double latDeg, double lonDeg);
double heightAtLatLon(const View& v, double latDeg, double lonDeg);

}  // namespace lw
