#pragma once
#include "world_data.h"
#include "noise.h"
#include "tectonics.h"

namespace lw {

// Flow routing graph on the fine grid (priority-flood so depressions become lakes)
struct FlowGraph {
    std::vector<int32_t> rec;     // receiver, -1 for ocean cells
    std::vector<int32_t> order;   // land cells, receivers before donors
    std::vector<float> fill;      // filled elevation
};

void computeFlow(const CubeGrid& g, const std::vector<float>& h, float sea, FlowGraph& fl);

// Build the whole solid-earth foundation: tectonic context, crust, elevation, bathymetry,
// erosion and sedimentation.  Heights end up relative to sea level (ocean% honoured).
void generateTerrain(const PlanetParams& pp, const Derived& dv, uint64_t seed, const Noise& noise,
                     const Tectonics& tect, const CubeGrid& g, double tMyr, TerrainData& T, const ProgressFn& progress);

}  // namespace lw
