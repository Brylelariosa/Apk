// Plate tectonics model.  Plates are weighted, noise-warped Voronoi regions whose
// centres move along Euler-pole rotations.  Boundary geometry, relative motion and
// crust content are evaluated analytically at any point and any geological time.
#pragma once
#include "util.h"
#include "noise.h"
#include "params.h"

namespace lw {

struct Plate {
    int id = 0;
    V3 seed;            // present-day centre
    double weight = 1;  // size weight (bigger = larger plate)
    V3 pole;            // Euler pole
    double omega = 0;   // rad / Myr
    double cont = 0;    // continentalness of the plate's crust (0 oceanic .. 1 continental)
    double baseAge = 100;  // typical age (Myr) of oceanic crust on this plate
};

struct TectSample {
    int plate = 0, other = 0;
    double distKm = 1e9;   // distance to the nearest plate boundary
    V3 n;                  // tangent unit vector pointing toward the other plate
    double conv = 0;       // cm/yr, + converging, - diverging
    double shear = 0;      // cm/yr along the boundary
    int type = 0;          // 0 interior, 1 convergent, 2 divergent, 3 transform
};

struct TectFrame {
    double t = 0;          // Myr relative to the present
    std::vector<V3> seed;
};

class Tectonics {
public:
    std::vector<Plate> plates;
    double contThreshold = 0.5;
    double radiusKm = 6371.0;
    const Noise* noise = nullptr;
    TectFrame frame0;

    void init(uint64_t seed, const PlanetParams& pp, const Derived& dv, const Noise& nz);
    void makeFrame(double tMyr, TectFrame& fr) const;
    void sample(const TectFrame& fr, const V3& x, TectSample& s) const;
    V3 velocityCmYr(int p, const V3& x) const;
    // continental fraction (0..1) of the crust that plate s.plate carries at x in frame fr
    double crustFrac(const TectFrame& fr, const V3& x, const TectSample& s) const;
    double maskValue(const V3& y, const TectSample& s0) const;

private:
    V3 warp(const V3& x) const;
};

}  // namespace lw
