// Central planet parameters.  Every system reads from here (via Derived) so
// changing a parameter genuinely changes the simulation.
#pragma once
#include "util.h"

namespace lw {

struct PlanetParams {
    double radiusKm = 6371.0;
    double gravity = 9.80665;        // m/s^2
    double rotationHours = 24.0;     // length of one local solar day
    double orbitDays = 365.25;       // orbital period in 24 h days
    double axialTiltDeg = 23.44;
    double eccentricity = 0.0167;
    double solarIntensity = 1.0;     // x 1361 W/m^2
    double pressureAtm = 1.0;        // surface pressure
    double oceanFraction = 0.71;     // fraction of surface below sea level
    double seaLevelOffsetM = 0.0;    // eustatic offset applied after ocean% is satisfied
    double n2 = 0.7808, o2 = 0.2095, ar = 0.0093, co2ppm = 420.0;
    double salinityPsu = 35.0;
    double geothermal = 1.0;         // x Earth (plate speed, volcanism, uplift)

    static constexpr int kCount = 12;
    // flat view used by the UI (index order is stable)
    void toArray(double* a) const {
        a[0] = radiusKm; a[1] = gravity; a[2] = rotationHours; a[3] = orbitDays; a[4] = axialTiltDeg;
        a[5] = solarIntensity; a[6] = pressureAtm; a[7] = oceanFraction; a[8] = co2ppm; a[9] = salinityPsu;
        a[10] = geothermal; a[11] = seaLevelOffsetM;
    }
    void fromArray(const double* a) {
        radiusKm = a[0]; gravity = a[1]; rotationHours = a[2]; orbitDays = a[3]; axialTiltDeg = a[4];
        solarIntensity = a[5]; pressureAtm = a[6]; oceanFraction = a[7]; co2ppm = a[8]; salinityPsu = a[9];
        geothermal = a[10]; seaLevelOffsetM = a[11];
    }
    void sanitize() {
        radiusKm = clampv(radiusKm, 1500.0, 20000.0);
        gravity = clampv(gravity, 2.0, 40.0);
        rotationHours = clampv(rotationHours, 4.0, 2000.0);
        orbitDays = clampv(orbitDays, 30.0, 20000.0);
        axialTiltDeg = clampv(axialTiltDeg, 0.0, 85.0);
        eccentricity = clampv(eccentricity, 0.0, 0.3);
        solarIntensity = clampv(solarIntensity, 0.4, 1.8);
        pressureAtm = clampv(pressureAtm, 0.2, 5.0);
        oceanFraction = clampv(oceanFraction, 0.1, 0.97);
        seaLevelOffsetM = clampv(seaLevelOffsetM, -300.0, 300.0);
        co2ppm = clampv(co2ppm, 50.0, 20000.0);
        salinityPsu = clampv(salinityPsu, 0.0, 60.0);
        geothermal = clampv(geothermal, 0.2, 4.0);
    }
};

struct Derived {
    double R = 6.371e6;          // m
    double g = 9.80665;
    double omega = 7.2921e-5;    // rad/s
    double dayHours = 24.0;
    double yearDays = 365.25;    // 24 h days
    double solarDaysPerYear = 365.25;
    double S0 = 1361.0;          // W/m^2
    double tilt = 0.4091;        // rad
    double ecc = 0.0167;
    double p0 = 101325.0;        // Pa
    double Rspec = 287.0;        // J/kg/K
    double cp = 1004.0;
    double lapse = 0.0065;       // environmental lapse rate K/m
    double colMass = 10330.0;    // kg/m^2
    double Ca = 1.0e7;           // atmospheric column heat capacity J/m^2/K
    double Hscale = 7300.0;      // m
    double olrA = 203.3;         // W/m^2 (linearised OLR = A + B*T_C)
    double olrB = 2.09;
    double diffD = 0.65;         // W/m^2/K meridional eddy transport
    double hadleyDeg = 30.0;     // poleward edge of the Hadley cell
    double maxReliefM = 9500.0;  // gravity-limited mountain height
    double tFreezeK = 271.23;    // sea water freezing point
    double Cocean = 2.5e8;       // mixed layer heat capacity
    double plateScale = 1.0;
    double contFraction = 0.40;  // continental crust area fraction
    double vaporScale = 1.0;     // column vapour scale (gravity dependent)
    double fCor0 = 1.4584e-4;    // 2*Omega
    double pressScale = 1.0;
    double geoScale = 1.0;
};

inline Derived derive(const PlanetParams& p) {
    Derived d;
    const double g0 = 9.80665, Om0 = 7.2921e-5, R0 = 6.371e6;
    d.R = p.radiusKm * 1000.0;
    d.g = p.gravity;
    d.omega = TAU / (p.rotationHours * 3600.0);
    d.dayHours = p.rotationHours;
    d.yearDays = p.orbitDays;
    d.solarDaysPerYear = p.orbitDays * 24.0 / p.rotationHours;
    d.S0 = 1361.0 * p.solarIntensity;
    d.tilt = p.axialTiltDeg * DEG2RAD;
    d.ecc = p.eccentricity;
    d.p0 = 101325.0 * p.pressureAtm;
    double tot = p.n2 + p.o2 + p.ar + p.co2ppm * 1e-6;
    double M = (p.n2 * 28.013 + p.o2 * 31.999 + p.ar * 39.948 + p.co2ppm * 1e-6 * 44.01) / (tot > 0 ? tot : 1.0);
    d.Rspec = 8.314462 / (M * 1e-3);
    d.cp = 1004.0;
    d.lapse = 0.665 * p.gravity / d.cp;
    d.colMass = d.p0 / d.g;
    d.Ca = d.cp * d.colMass;
    d.Hscale = d.Rspec * 250.0 / d.g;
    // greenhouse: CO2 forcing 5.35 ln(C/C0) and a weak pressure-broadening term
    d.olrA = 203.3 + 5.0 - 5.35 * dlog(p.co2ppm / 340.0) - 4.0 * dlog(std::max(0.05, p.pressureAtm));
    d.olrB = 2.09;
    double dd = 0.65 * p.pressureAtm * (g0 / p.gravity) * sqr(R0 / d.R) * (Om0 / d.omega);
    d.diffD = clampv(dd, 0.15, 2.5);
    double hd = 30.0 * (Om0 * R0) / (d.omega * d.R) * std::sqrt(d.Rspec / 287.0);
    d.hadleyDeg = clampv(hd, 9.0, 80.0);
    d.maxReliefM = 9500.0 * (g0 / p.gravity);
    double S = p.salinityPsu;
    d.tFreezeK = 273.15 + (-0.0575 * S + 1.710523e-3 * S * std::sqrt(S) - 2.154996e-4 * S * S);
    d.Cocean = 2.5e8;
    d.plateScale = std::sqrt(p.geothermal);
    d.geoScale = p.geothermal;
    d.contFraction = clampv((1.0 - p.oceanFraction) + 0.11, 0.15, 0.95);
    d.vaporScale = g0 / p.gravity;
    d.fCor0 = 2.0 * d.omega;
    d.pressScale = p.pressureAtm;
    return d;
}

}  // namespace lw
