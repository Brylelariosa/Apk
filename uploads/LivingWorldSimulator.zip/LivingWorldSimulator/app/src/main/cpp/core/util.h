// Living World Simulator - core utilities.
// Deterministic math (no libm trig/exp/log in the generation path) so a seed
// produces the same planet on every device / ABI.  Build with -ffp-contract=off.
#pragma once
#include <cstdint>
#include <cmath>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
#include <chrono>

namespace lw {

constexpr double PI = 3.14159265358979323846;
constexpr double TAU = 6.28318530717958647692;
constexpr double DEG2RAD = PI / 180.0;
constexpr double RAD2DEG = 180.0 / PI;

// ---------------------------------------------------------------------------
// Deterministic math (IEEE basic ops only)
// ---------------------------------------------------------------------------
inline void dsincos(double x, double& s, double& c) {
    const double invpio2 = 6.36619772367581382433e-01;
    const double pio2_1 = 1.57079632673412561417e+00;
    const double pio2_1t = 6.07710050650619224932e-11;
    double kf = std::floor(x * invpio2 + 0.5);
    double r = (x - kf * pio2_1) - kf * pio2_1t;
    long long k = (long long)kf;
    double z = r * r;
    double sn = r + r * z * (-1.66666666666666324348e-01 + z * (8.33333333332248946124e-03 + z * (-1.98412698298579493134e-04 + z * (2.75573137070700676789e-06 + z * (-2.50507602534068634195e-08 + z * 1.58969099521155010221e-10)))));
    double cs = 1.0 - 0.5 * z + z * z * (4.16666666666666019037e-02 + z * (-1.38888888888741095749e-03 + z * (2.48015872894767294178e-05 + z * (-2.75573143513906633035e-07 + z * (2.08757232129817482790e-09 + z * -1.13596475577881948265e-11)))));
    switch (k & 3) {
        case 0: s = sn; c = cs; break;
        case 1: s = cs; c = -sn; break;
        case 2: s = -sn; c = -cs; break;
        default: s = -cs; c = sn; break;
    }
}
inline double dsin(double x) { double s, c; dsincos(x, s, c); return s; }
inline double dcos(double x) { double s, c; dsincos(x, s, c); return c; }
inline double dtan(double x) { double s, c; dsincos(x, s, c); return s / c; }

inline double dexp(double x) {
    if (x > 700.0) x = 700.0;
    if (x < -700.0) return 0.0;
    const double ln2hi = 6.93147180369123816490e-01, ln2lo = 1.90821492927058770002e-10, invln2 = 1.44269504088896338700e+00;
    double kf = std::floor(x * invln2 + 0.5);
    double r = (x - kf * ln2hi) - kf * ln2lo;
    double p = 1.0 + r * (1.0 + r * (1.0 / 2 + r * (1.0 / 6 + r * (1.0 / 24 + r * (1.0 / 120 + r * (1.0 / 720 + r * (1.0 / 5040 + r * (1.0 / 40320 + r * (1.0 / 362880 + r * (1.0 / 3628800 + r * (1.0 / 39916800 + r * (1.0 / 479001600 + r * (1.0 / 6227020800.0)))))))))))));
    return std::ldexp(p, (int)kf);
}

inline double dlog(double x) {
    if (x <= 0.0) return -1e300;
    int e;
    double m = std::frexp(x, &e);
    if (m < 0.70710678118654752440) { m *= 2.0; e -= 1; }
    double s = (m - 1.0) / (m + 1.0), z = s * s;
    double r = s * (2.0 + z * (2.0 / 3 + z * (2.0 / 5 + z * (2.0 / 7 + z * (2.0 / 9 + z * (2.0 / 11 + z * (2.0 / 13 + z * (2.0 / 15 + z * (2.0 / 17 + z * (2.0 / 19 + z * (2.0 / 21))))))))))); 
    return r + (double)e * 0.693147180559945309417232;
}
inline double dpow(double x, double y) { return x <= 0.0 ? 0.0 : dexp(y * dlog(x)); }

inline double datan(double x) {
    double sgn = 1.0;
    if (x < 0) { x = -x; sgn = -1.0; }
    bool inv = false;
    if (x > 1.0) { x = 1.0 / x; inv = true; }
    x = x / (1.0 + std::sqrt(1.0 + x * x));
    x = x / (1.0 + std::sqrt(1.0 + x * x));
    x = x / (1.0 + std::sqrt(1.0 + x * x));
    double z = x * x;
    double r = x * (1.0 + z * (-1.0 / 3 + z * (1.0 / 5 + z * (-1.0 / 7 + z * (1.0 / 9 + z * (-1.0 / 11 + z * (1.0 / 13)))))));
    r *= 8.0;
    if (inv) r = PI / 2 - r;
    return sgn * r;
}
inline double datan2(double y, double x) {
    if (x == 0.0 && y == 0.0) return 0.0;
    if (std::fabs(x) >= std::fabs(y)) {
        double a = datan(y / x);
        if (x < 0) a += (y >= 0 ? PI : -PI);
        return a;
    }
    double a = datan(x / y);
    return (y > 0 ? PI / 2 : -PI / 2) - a;
}
inline double dacos(double x) { x = x < -1 ? -1 : (x > 1 ? 1 : x); return datan2(std::sqrt(std::max(0.0, 1.0 - x * x)), x); }
inline double dasin(double x) { x = x < -1 ? -1 : (x > 1 ? 1 : x); return datan2(x, std::sqrt(std::max(0.0, 1.0 - x * x))); }
inline double dtanh(double x) { if (x > 20) return 1; if (x < -20) return -1; double e = dexp(2 * x); return (e - 1) / (e + 1); }

// ---------------------------------------------------------------------------
// Scalar helpers
// ---------------------------------------------------------------------------
template <class T> inline T clampv(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline double lerpd(double a, double b, double t) { return a + (b - a) * t; }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline double smoothstep(double a, double b, double x) {
    double t = (x - a) / (b - a);
    t = t < 0 ? 0 : (t > 1 ? 1 : t);
    return t * t * (3.0 - 2.0 * t);
}
inline double sqr(double x) { return x * x; }

// ---------------------------------------------------------------------------
// Vectors
// ---------------------------------------------------------------------------
struct V3 {
    double x = 0, y = 0, z = 0;
    V3() {}
    V3(double a, double b, double c) : x(a), y(b), z(c) {}
    V3 operator+(const V3& o) const { return V3(x + o.x, y + o.y, z + o.z); }
    V3 operator-(const V3& o) const { return V3(x - o.x, y - o.y, z - o.z); }
    V3 operator*(double s) const { return V3(x * s, y * s, z * s); }
    V3 operator-() const { return V3(-x, -y, -z); }
    V3& operator+=(const V3& o) { x += o.x; y += o.y; z += o.z; return *this; }
    V3& operator-=(const V3& o) { x -= o.x; y -= o.y; z -= o.z; return *this; }
    V3& operator*=(double s) { x *= s; y *= s; z *= s; return *this; }
};
inline double dot(const V3& a, const V3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline V3 cross(const V3& a, const V3& b) { return V3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
inline double length(const V3& a) { return std::sqrt(dot(a, a)); }
inline V3 normalize(const V3& a) {
    double l = length(a);
    return l > 1e-300 ? a * (1.0 / l) : V3(0, 0, 1);
}
// rotate v about unit axis by angle (radians)
inline V3 rotateAxis(const V3& v, const V3& axis, double ang) {
    double s, c;
    dsincos(ang, s, c);
    return v * c + cross(axis, v) * s + axis * (dot(axis, v) * (1.0 - c));
}
inline double latOf(const V3& d) { return dasin(d.z); }
inline double lonOf(const V3& d) { return datan2(d.y, d.x); }
inline V3 fromLatLon(double lat, double lon) {
    double sl, cl, so, co;
    dsincos(lat, sl, cl);
    dsincos(lon, so, co);
    return V3(cl * co, cl * so, sl);
}
// local east / north at unit position p (north pole = +Z)
inline void eastNorth(const V3& p, V3& e, V3& n) {
    V3 ee = cross(V3(0, 0, 1), p);
    double l = length(ee);
    if (l < 1e-9) ee = V3(0, 1, 0); else ee = ee * (1.0 / l);
    e = ee;
    n = cross(p, ee);
}
inline V3 tangentPart(const V3& v, const V3& p) { return v - p * dot(v, p); }

// ---------------------------------------------------------------------------
// RNG / hashing
// ---------------------------------------------------------------------------
inline uint64_t mix64(uint64_t z) {
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}
struct Rng {
    uint64_t s;
    explicit Rng(uint64_t seed = 0) : s(seed) {}
    uint64_t next() { s += 0x9E3779B97F4A7C15ULL; return mix64(s); }
    double uni() { return (double)(next() >> 11) * (1.0 / 9007199254740992.0); }
    double range(double a, double b) { return a + (b - a) * uni(); }
    int irange(int a, int b) { return a + (int)(next() % (uint64_t)(b - a + 1)); }
    V3 unitVec() {
        double z = range(-1.0, 1.0), t = range(0.0, TAU);
        double r = std::sqrt(std::max(0.0, 1.0 - z * z)), sn, cs;
        dsincos(t, sn, cs);
        return V3(r * cs, r * sn, z);
    }
};
inline uint64_t hashStr(const std::string& s) {
    uint64_t h = 1469598103934665603ULL;
    for (unsigned char c : s) { h ^= c; h *= 1099511628211ULL; }
    return mix64(h);
}

struct Timer {
    std::chrono::steady_clock::time_point t0;
    Timer() { reset(); }
    void reset() { t0 = std::chrono::steady_clock::now(); }
    double ms() const { return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); }
};

}  // namespace lw
