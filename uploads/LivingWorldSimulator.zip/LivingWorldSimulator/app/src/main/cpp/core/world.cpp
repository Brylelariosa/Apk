#include "world.h"

namespace lw {

namespace {
std::mutex gGridMu;
std::shared_ptr<const CubeGrid> gFine, gCoarse;
void getGrids(std::shared_ptr<const CubeGrid>& fg, std::shared_ptr<const CubeGrid>& cg) {
    std::lock_guard<std::mutex> lk(gGridMu);
    if (!gFine) { auto g = std::make_shared<CubeGrid>(); g->build(NT, false); gFine = g; }
    if (!gCoarse) { auto g = std::make_shared<CubeGrid>(); g->build(NC, true); gCoarse = g; }
    fg = gFine;
    cg = gCoarse;
}
}  // namespace

void sliceWeights(double fy, int& m0, int& m1, float& w) {
    double u = fy * NSLICE - 0.5;
    double fl = std::floor(u);
    w = (float)(u - fl);
    int i = (int)fl;
    m0 = ((i % NSLICE) + NSLICE) % NSLICE;
    m1 = (m0 + 1) % NSLICE;
}

World::World() {}
World::~World() {}

uint64_t World::parseSeed(const std::string& s) {
    size_t dash = s.find_last_of('-');
    std::string tail = dash == std::string::npos ? s : s.substr(dash + 1);
    bool hex = !tail.empty() && tail.size() <= 16;
    uint64_t v = 0;
    for (char ch : tail) {
        int d;
        if (ch >= '0' && ch <= '9') d = ch - '0';
        else if (ch >= 'a' && ch <= 'f') d = 10 + ch - 'a';
        else if (ch >= 'A' && ch <= 'F') d = 10 + ch - 'A';
        else { hex = false; break; }
        v = (v << 4) | (uint64_t)d;
    }
    if (hex) return mix64(v ^ 0x9E3779B97F4A7C15ULL);
    return hashStr(s);
}

View World::view() const {
    std::lock_guard<std::mutex> lk(mu_);
    View v;
    v.s = s_;
    v.d = d_;
    return v;
}

Timings World::timings() const {
    std::lock_guard<std::mutex> lk(mu_);
    return tm_;
}

void World::generate(const std::string& seed, const PlanetParams& ppIn, const ProgressFn& progress) {
    PlanetParams pp = ppIn;
    pp.sanitize();
    rebuild(pp, parseSeed(seed), seed, 0.0, false, progress);
    time_ = 0;
    sinceSlow_ = 0;
    dayPhase_ = 0.5;   // new planets start at local noon on the prime meridian
    publishDynamic(s_, 0.0);
}

void World::rebuild(const PlanetParams& pp, uint64_t seed, const std::string& seedStr, double tectMyr, bool warm, const ProgressFn& progress) {
    Timer total;
    auto map = [&](float a, float b) {
        return ProgressFn([&progress, a, b](const char* s, float f) { if (progress) progress(s, a + (b - a) * clampv(f, 0.0f, 1.0f)); });
    };
    auto sd = std::make_shared<StaticData>();
    sd->pp = pp;
    sd->dv = derive(pp);
    sd->seed = seed;
    sd->seedStr = seedStr;
    sd->tectTimeMyr = tectMyr;
    getGrids(sd->fg, sd->cg);
    sd->noise.init(seed * 7919ULL + 13ULL);
    sd->tect.init(seed, pp, sd->dv, sd->noise);

    Timer t;
    auto T = std::make_shared<TerrainData>();
    {
        ProgressFn pf = map(0.0f, 0.30f);
        generateTerrain(pp, sd->dv, seed, sd->noise, sd->tect, *sd->fg, tectMyr, *T, [&](const char* s, float f) { pf(s, f / 0.85f); });
    }
    sd->Tp = T;
    double terrainMs = t.ms();

    t.reset();
    std::unique_ptr<Climate> cl(new Climate(pp, sd->dv, *sd->cg, *sd->fg, *T));
    if (warm && climate_) cl->warmStartFrom(*climate_);
    std::vector<float> veg, cap, gl;
    if (warm && veg_.size() == (size_t)sd->cg->count) cl->setSurface(veg_, soilCap_, glacier_);
    cl->run(3, map(0.30f, 0.52f));
    double climateMs = t.ms();

    t.reset();
    auto eco = std::make_shared<EcoPack>();
    buildHydroEco(pp, sd->dv, sd->noise, *sd->cg, *sd->fg, *T, cl->sl, cl->st, cl->oroVec(), eco->H, eco->E, veg, cap, gl, map(0.52f, 0.62f));
    cl->setSurface(veg, cap, gl);
    double ecoMs = t.ms();

    t.reset();
    cl->run(2, map(0.62f, 0.82f));
    climateMs += t.ms();
    t.reset();
    buildHydroEco(pp, sd->dv, sd->noise, *sd->cg, *sd->fg, *T, cl->sl, cl->st, cl->oroVec(), eco->H, eco->E, veg, cap, gl, map(0.82f, 1.0f));
    ecoMs += t.ms();

    auto cp = std::make_shared<ClimatePack>();
    cp->sl = cl->sl;
    cp->st = cl->st;
    sd->Ep = eco;
    sd->Cp = cp;
    double cstep = cl->msPerStep;
    {
        std::lock_guard<std::mutex> lk(mu_);
        climate_ = std::move(cl);
        veg_ = veg; soilCap_ = cap; glacier_ = gl;
        sd->id = gen_.fetch_add(1) + 1;
        s_ = sd;
        tm_.terrainMs = terrainMs; tm_.climateMs = climateMs; tm_.ecoMs = ecoMs; tm_.climateStepMs = cstep;
        tm_.genTotalMs = total.ms();
        tm_.riverMs = ecoMs * 0.4;
    }
    if (progress) progress("Ready", 1.0f);
}

void World::publishDynamic(const std::shared_ptr<const StaticData>& s, double timeYears) {
    if (!s) return;
    auto d = std::make_shared<DynamicData>();
    const int n = s->cg->count;
    d->timeYears = timeYears;
    d->fracYear = timeYears - std::floor(timeYears);
    double days = timeYears * s->dv.solarDaysPerYear;
    double dd = days + dayPhase_;
    d->dayFrac = dd - std::floor(dd);
    int m0, m1;
    float w;
    sliceWeights(d->fracYear, m0, m1, w);
    const ClimateSlices& sl = s->sl();
    auto interp = [&](const std::vector<float>& src, std::vector<float>& dst) {
        dst.resize(n);
        const float* a = &src[(size_t)m0 * n];
        const float* b = &src[(size_t)m1 * n];
        for (int c = 0; c < n; c++) dst[c] = a[c] + (b[c] - a[c]) * w;
    };
    interp(sl.ta, d->ta); interp(sl.ts, d->ts); interp(sl.precip, d->precip); interp(sl.wvap, d->wvap);
    interp(sl.cloud, d->cloud); interp(sl.snow, d->snow); interp(sl.ice, d->ice); interp(sl.wu, d->wu);
    interp(sl.wv, d->wv); interp(sl.pres, d->pres);
    d->glacier = sl.glacier;
    double decl, rinv;
    solarGeometry(s->dv, d->fracYear, decl, rinv);
    d->declDeg = decl * RAD2DEG;
    d->sunDir = fromLatLon(decl, -TAU * (d->dayFrac - 0.5));
    double sa = 0, st = 0;
    for (int c = 0; c < n; c++) { sa += s->cg->area[c]; st += s->cg->area[c] * d->ta[c]; }
    d->globalT = st / sa;
    std::lock_guard<std::mutex> lk(mu_);
    d_ = d;
}

void World::addDayHours(double hours) {
    std::shared_ptr<const StaticData> s;
    {
        std::lock_guard<std::mutex> lk(mu_);
        s = s_;
        if (!s) return;
        dayPhase_ += hours / s->dv.dayHours;
        dayPhase_ -= std::floor(dayPhase_);
    }
    publishDynamic(s, time_);
}

void World::advance(double years, const ProgressFn& progress) {
    std::shared_ptr<const StaticData> s;
    {
        std::lock_guard<std::mutex> lk(mu_);
        s = s_;
    }
    if (!s || years <= 0) return;
    Timer t;
    time_ += years;
    if (years >= 1.0 / 400.0) {
        // coarse steps advance by whole solar days so the time of day (and the terminator) stays put
        double spy = s->dv.solarDaysPerYear;
        time_ = std::floor(time_ * spy + 0.5) / spy;
    }
    if (years >= 4.0e5) {
        // geological step: plates move, crust is carried, mountains rise and erode, everything downstream is recomputed
        rebuild(s->pp, s->seed, s->seedStr, s->tectTimeMyr + years / 1.0e6, true, progress);
        sinceSlow_ = 0;
        publishDynamic(this->view().s, time_);
    } else {
        sinceSlow_ += years;
        if (sinceSlow_ >= 100.0 && climate_) {
            // slow coupled update: vegetation, soils and glaciers adjust and feed back to climate
            sinceSlow_ = 0;
            auto sd2 = std::make_shared<StaticData>(*s);
            sd2->tect.noise = &sd2->noise;
            climate_->setSurface(veg_, soilCap_, glacier_);
            climate_->run(2, progress);
            std::vector<float> veg, cap, gl;
            auto eco = std::make_shared<EcoPack>();
            buildHydroEco(sd2->pp, sd2->dv, sd2->noise, *sd2->cg, *sd2->fg, *sd2->Tp, climate_->sl, climate_->st, climate_->oroVec(), eco->H, eco->E, veg, cap, gl, progress);
            auto cp = std::make_shared<ClimatePack>();
            cp->sl = climate_->sl;
            cp->st = climate_->st;
            sd2->Ep = eco;
            sd2->Cp = cp;
            {
                std::lock_guard<std::mutex> lk(mu_);
                veg_ = veg; soilCap_ = cap; glacier_ = gl;
                sd2->id = gen_.fetch_add(1) + 1;
                s_ = sd2;
            }
        }
        publishDynamic(this->view().s, time_);
    }
    std::lock_guard<std::mutex> lk(mu_);
    tm_.stepMs = t.ms();
}

}  // namespace lw
