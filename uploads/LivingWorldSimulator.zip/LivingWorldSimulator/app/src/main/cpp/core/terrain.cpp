#include "terrain.h"
#include <queue>

namespace lw {

namespace {

struct BumpCtx {
    const CubeGrid* g;
    double Rkm;
    std::vector<int> stamp;
    int cur = 0;
    std::vector<int> q;
    BumpCtx(const CubeGrid& grid, double R) : g(&grid), Rkm(R), stamp(grid.count, 0) { q.reserve(4096); }
    template <class F>
    void run(const V3& center, double reachKm, F fn) {
        cur++;
        int c0 = g->cellOf(center);
        q.clear();
        q.push_back(c0);
        stamp[c0] = cur;
        for (size_t h = 0; h < q.size(); h++) {
            int c = q[h];
            fn(c, length(g->pos[c] - center) * Rkm);
            for (int k = 0; k < 8; k++) {
                int n = g->nbr[(size_t)c * 8 + k];
                if (n < 0 || stamp[n] == cur) continue;
                if (length(g->pos[n] - center) * Rkm > reachKm) continue;
                stamp[n] = cur;
                q.push_back(n);
            }
        }
    }
};

double margin(double cf, double Eoc, double Econt) {
    if (cf < 0.10) return Eoc;
    if (cf < 0.40) return lerpd(Eoc, -0.25, smoothstep(0.10, 0.40, cf));
    if (cf < 0.62) return lerpd(-0.25, -0.05, (cf - 0.40) / 0.22);
    return lerpd(-0.05, Econt, smoothstep(0.62, 0.85, cf));
}

inline double gauss(double d, double c, double w) { double t = (d - c) / w; return dexp(-t * t); }

}  // namespace

void computeFlow(const CubeGrid& g, const std::vector<float>& h, float sea, FlowGraph& fl) {
    const int n = g.count;
    fl.rec.assign(n, -1);
    fl.fill.assign(n, 0.f);
    fl.order.clear();
    fl.order.reserve(n);
    std::vector<uint8_t> closed(n, 0);
    typedef std::pair<float, int> PI;
    std::priority_queue<PI, std::vector<PI>, std::greater<PI>> open;
    for (int c = 0; c < n; c++)
        if (h[c] <= sea) { closed[c] = 1; fl.fill[c] = h[c]; }
    for (int c = 0; c < n; c++) {
        if (h[c] > sea) continue;
        for (int k = 0; k < 8; k++) {
            int q = g.nbr[(size_t)c * 8 + k];
            if (q < 0 || closed[q]) continue;
            closed[q] = 1;
            fl.rec[q] = c;
            fl.fill[q] = h[q];
            open.push(PI(h[q], q));
        }
    }
    const float eps = 0.02f;
    while (!open.empty()) {
        PI top = open.top();
        open.pop();
        int c = top.second;
        float fc = top.first;
        fl.order.push_back(c);
        for (int k = 0; k < 8; k++) {
            int q = g.nbr[(size_t)c * 8 + k];
            if (q < 0 || closed[q]) continue;
            closed[q] = 1;
            fl.rec[q] = c;
            float f = h[q] > fc ? h[q] : fc + eps;
            fl.fill[q] = f;
            open.push(PI(f, q));
        }
    }
}

void generateTerrain(const PlanetParams& pp, const Derived& dv, uint64_t seed, const Noise& nz, const Tectonics& tect,
                     const CubeGrid& g, double tMyr, TerrainData& T, const ProgressFn& progress) {
    const int n = g.count;
    const double Rkm = pp.radiusKm, Rm = dv.R;
    auto prog = [&](const char* s, float f) { if (progress) progress(s, f); };
    T.N = g.N;
    T.plate.assign(n, 0); T.plate2.assign(n, 0); T.btype.assign(n, 0);
    for (auto* v : {&T.bdist, &T.conv, &T.cf, &T.crustAge, &T.thickness, &T.volcanism, &T.seismic, &T.orogeny, &T.target,
                    &T.height, &T.sediment, &T.rough, &T.slope, &T.rockHard})
        v->assign(n, 0.f);
    T.volcanoes.clear();

    // ---------------- A. tectonic context per cell ----------------
    prog("Tectonic plates", 0.0f);
    TectFrame fr;
    tect.makeFrame(tMyr, fr);
    std::vector<float> cfO(n, 0.f), shear(n, 0.f);
    for (int c = 0; c < n; c++) {
        V3 x = g.pos[c];
        TectSample s;
        tect.sample(fr, x, s);
        double cfS = tect.crustFrac(fr, x, s);
        double cfOth = cfS;
        if (s.distKm < 900.0) {
            double ang = 2.0 * s.distKm / Rkm + 4e-4;
            V3 xm = normalize(x * dcos(ang) + s.n * dsin(ang));
            TectSample sm;
            tect.sample(fr, xm, sm);
            cfOth = tect.crustFrac(fr, xm, sm);
        }
        T.plate[c] = (uint8_t)s.plate;
        T.plate2[c] = (uint8_t)s.other;
        T.btype[c] = (uint8_t)s.type;
        T.bdist[c] = (float)s.distKm;
        T.conv[c] = (float)s.conv;
        shear[c] = (float)s.shear;
        T.cf[c] = (float)cfS;
        cfO[c] = (float)cfOth;
    }

    // ---------------- B. oceanic crust age (distance from spreading ridges within a plate) ----------------
    prog("Crust age", 0.12f);
    {
        std::vector<float> dist(n, 1e30f), rate(n, 20.f);
        typedef std::pair<float, int> PI;
        std::priority_queue<PI, std::vector<PI>, std::greater<PI>> pq;
        double cellKm = std::sqrt((double)g.area[0]) * Rkm;
        for (int c = 0; c < n; c++)
            if (T.btype[c] == 2 && T.bdist[c] < 0.9 * cellKm) {
                dist[c] = 0;
                rate[c] = (float)std::max(10.0, std::fabs((double)T.conv[c]) * 5.0);
                pq.push(PI(0.f, c));
            }
        while (!pq.empty()) {
            PI t = pq.top();
            pq.pop();
            int c = t.second;
            if (t.first > dist[c]) continue;
            for (int k = 0; k < 8; k++) {
                int q = g.nbr[(size_t)c * 8 + k];
                if (q < 0 || T.plate[q] != T.plate[c]) continue;
                float nd = t.first + (float)(length(g.pos[q] - g.pos[c]) * Rkm);
                if (nd < dist[q]) { dist[q] = nd; rate[q] = rate[c]; pq.push(PI(nd, q)); }
            }
        }
        for (int c = 0; c < n; c++) {
            double base = tect.plates[T.plate[c]].baseAge;
            double a = dist[c] < 1e29f ? dist[c] / rate[c] : base;
            T.crustAge[c] = (float)clampv(a, 0.0, 185.0);
        }
    }

    // ---------------- C. inherited orogens (older collision belts, carried with their plates) ----------------
    prog("Ancient mountain belts", 0.2f);
    CubeGrid pg;
    pg.build(48, false);
    std::vector<float> paleo(pg.count, 0.f);
    {
        static const double TIMES[3] = {-40.0, -100.0, -180.0};
        TectFrame ft[3];
        for (int k = 0; k < 3; k++) tect.makeFrame(tMyr + TIMES[k], ft[k]);
        for (int c = 0; c < pg.count; c++) {
            V3 x = pg.pos[c];
            TectSample s;
            tect.sample(fr, x, s);
            if (tect.crustFrac(fr, x, s) < 0.5) continue;
            const Plate& pl = tect.plates[s.plate];
            double sum = 0;
            for (int k = 0; k < 3; k++) {
                V3 xp = normalize(rotateAxis(x, pl.pole, pl.omega * TIMES[k]));
                TectSample sp;
                tect.sample(ft[k], xp, sp);
                if (sp.plate != s.plate || sp.type != 1 || sp.conv < 1.0) continue;
                double ang = 2.0 * sp.distKm / Rkm + 4e-4;
                V3 xm = normalize(xp * dcos(ang) + sp.n * dsin(ang));
                TectSample sm;
                tect.sample(ft[k], xm, sm);
                double co = tect.crustFrac(ft[k], xm, sm);
                double sc = clampv(sp.conv / 6.0, 0.2, 1.3);
                double age = -TIMES[k];
                sum += (co > 0.5 ? 5.2 : 2.2) * sc * dexp(-sqr(sp.distKm / 400.0)) * dexp(-age / 230.0);
            }
            paleo[c] = (float)sum;
        }
    }

    // ---------------- D. base elevation from isostasy / boundary processes ----------------
    prog("Crust and elevation", 0.3f);
    std::vector<float> E(n, 0.f);
    for (int c = 0; c < n; c++) {
        V3 x = g.pos[c];
        float px = (float)x.x, py = (float)x.y, pz = (float)x.z;
        double cf = T.cf[c], co = cfO[c], d = T.bdist[c];
        double age = T.crustAge[c];
        double Eoc = -(2.6 + 3.0 * (1.0 - dexp(-age / 32.0)));
        double Econt = 1.05 + 0.50 * nz.fbm(px * 1.1f + 3.3f, py * 1.1f, pz * 1.1f, 3) + 0.30 * nz.fbm(px * 3.1f, py * 3.1f + 1.7f, pz * 3.1f, 3);
        double e = margin(cf, Eoc, Econt);
        double dE = 0, orog = 0;
        double sc = clampv((double)T.conv[c] / 4.5, 0.2, 1.5);
        bool selfC = cf > 0.5, othC = co > 0.5;
        double mod = clampv(0.7 + 0.6 * nz.fbm(px * 7.0f, py * 7.0f + 4.4f, pz * 7.0f, 2), 0.25, 1.35);
        int type = T.btype[c];
        double volc = 0, seis = 0.02;
        if (type == 1) {
            seis = clampv(sc * dexp(-d / 200.0), 0.0, 1.0);
            if (selfC && othC) {
                dE = 7.0 * sc * mod * gauss(d, 0, 450) + 1.6 * sc * gauss(d, 720, 450);
                orog = clampv(dE / 4.5, 0.0, 1.0);
            } else if (!selfC && othC) {
                double s2 = clampv(sc, 0.5, 1.2);
                dE = -3.8 * s2 * gauss(d, 55, 55) + 0.35 * gauss(d, 190, 70);
            } else if (selfC && !othC) {
                dE = 4.6 * sc * mod * gauss(d, 170, 130) + 1.1 * clampv(sc - 0.6, 0.0, 1.0) * gauss(d, 480, 260) - 0.7 * gauss(d, 35, 40);
                orog = clampv(dE / 3.5, 0.0, 1.0);
                volc = sc * gauss(d, 170, 90);
            } else {
                bool sub = tect.plates[T.plate[c]].baseAge > tect.plates[T.plate2[c]].baseAge;
                double s2 = clampv(sc, 0.5, 1.2);
                if (sub) dE = -2.9 * s2 * gauss(d, 55, 55) + 0.3 * gauss(d, 190, 70);
                else { dE = 4.8 * sc * mod * gauss(d, 125, 75) - 0.4 * gauss(d, 380, 160); orog = clampv(dE / 4.0, 0.0, 1.0); volc = sc * gauss(d, 125, 70); }
            }
        } else if (type == 2) {
            double sp = clampv(std::fabs((double)T.conv[c]) / 3.0, 0.2, 1.0);
            seis = 0.35 * gauss(d, 0, 90);
            if (!selfC && !othC) { dE = -0.25 * gauss(d, 0, 30); volc = 0.18 * gauss(d, 0, 60); }
            else { dE = -1.3 * sp * gauss(d, 0, 75) + 0.9 * gauss(d, 0, 380); volc = 0.55 * sp * gauss(d, 0, 100); orog = 0.2 * gauss(d, 0, 300); }
        } else if (type == 3) {
            dE = 0.12 * nz.fbm(px * 12.0f, py * 12.0f, pz * 12.0f, 2) - 0.15 * gauss(d, 0, 28);
            seis = clampv(0.8 * gauss(d, 0, 100), 0.0, 1.0);
        }
        double pal = pg.sample(paleo.data(), x);
        if (pal > 0) { dE += pal; orog = std::max(orog, clampv(pal / 3.0, 0.0, 0.8)); }
        e += dE;
        // large-scale relief of the mountain belts, abyssal hills, and seeding noise for the river network
        if (orog > 0.02) e += orog * 0.9 * (nz.ridged(px * 8.0f, py * 8.0f, pz * 8.0f, 4) - 0.42);
        if (e < -1.0) e += 0.10 * nz.fbm(px * 30.0f, py * 30.0f, pz * 30.0f, 3);
        e += 0.045 * nz.n3(px * 64.0f, py * 64.0f + 7.0f, pz * 64.0f) + 0.025 * nz.n3(px * 150.0f + 9.0f, py * 150.0f, pz * 150.0f);
        E[c] = (float)e;
        T.orogeny[c] = (float)orog;
        T.volcanism[c] = (float)volc;
        T.seismic[c] = (float)seis;
        T.thickness[c] = (float)(7.0 + 28.0 * cf + std::max(0.0, dE) * 6.6);
    }

    // ---------------- E. hotspot chains and volcanic arcs ----------------
    prog("Volcanoes", 0.5f);
    {
        BumpCtx bc(g, Rkm);
        Rng rng(seed ^ 0x40750707ULL);
        int nHot = clampv((int)std::floor(4.0 * dpow(dv.geoScale, 0.7) + rng.range(-1.0, 1.5) + 0.5), 1, 9);
        for (int hnum = 0; hnum < nHot; hnum++) {
            V3 h0 = rng.unitVec();
            TectSample s;
            tect.sample(fr, h0, s);
            const Plate& pl = tect.plates[s.plate];
            for (int k = 0; k < 44; k++) {
                double tau = k * 1.25;
                V3 p = normalize(rotateAxis(h0, pl.pole, pl.omega * tau));
                double amp = 6.0 * dexp(-tau / 9.0) * std::min(1.0, 0.6 + 0.4 * dv.geoScale);
                double rad = 55.0 + 30.0 * dexp(-tau / 12.0);
                double act = dexp(-tau / 3.0);
                bc.run(p, rad * 2.2, [&](int c, double dd) {
                    double w = dexp(-sqr(dd / rad));
                    E[c] += (float)(amp * w);
                    T.volcanism[c] = std::max(T.volcanism[c], (float)(act * w));
                });
                if (k == 0) {
                    bc.run(p, 1300.0, [&](int c, double dd) { E[c] += (float)(0.7 * dexp(-sqr(dd / 650.0))); });
                    T.volcanoes.push_back(g.cellOf(p));
                }
            }
        }
        // stratovolcano cones strung along volcanic arcs
        for (int c = 0; c < n; c++) {
            if (T.volcanism[c] < 0.35f || T.btype[c] != 1) continue;
            uint64_t hh = mix64((uint64_t)c * 2654435761ULL + seed);
            if ((hh & 1023) > 150) continue;
            double amp = 1.2 + 1.2 * (double)((hh >> 12) & 255) / 255.0;
            V3 p = g.pos[c];
            bc.run(p, 90.0, [&](int cc, double dd) { E[cc] += (float)(amp * dexp(-sqr(dd / 32.0))); });
            T.volcanoes.push_back(c);
        }
    }

    // gravity limits how high crust can stand: soft cap on everything above the datum (volcanoes included)
    {
        const double capMax = (dv.maxReliefM / 1000.0 + 0.7), knee = 0.54 * capMax;
        for (int c = 0; c < n; c++)
            if (E[c] > knee) E[c] = (float)(knee + (capMax - knee) * dtanh(((double)E[c] - knee) / (capMax - knee)));
    }

    // ---------------- F. sea level so that ocean% is honoured ----------------
    prog("Ocean basins", 0.58f);
    std::vector<float> h(n);
    for (int c = 0; c < n; c++) h[c] = E[c] * 1000.0f;
    auto findSea = [&](const std::vector<float>& hv, double frac) {
        std::vector<int> ord(n);
        for (int i = 0; i < n; i++) ord[i] = i;
        std::sort(ord.begin(), ord.end(), [&](int a, int b) { return hv[a] < hv[b] || (hv[a] == hv[b] && a < b); });
        double total = 0;
        for (int i = 0; i < n; i++) total += g.area[i];
        double acc = 0;
        for (int i = 0; i < n; i++) {
            acc += g.area[ord[i]];
            if (acc >= total * frac) return (double)hv[ord[i]];
        }
        return (double)hv[ord[n - 1]];
    };
    double sea0 = findSea(h, pp.oceanFraction);
    for (int c = 0; c < n; c++) { h[c] -= (float)sea0; T.target[c] = h[c]; }

    // ---------------- G. fluvial erosion + sediment transport (stream-power, implicit) ----------------
    prog("Erosion", 0.62f);
    {
        FlowGraph fl;
        std::vector<float> A(n), eroded(n), Qs(n), nb(n);
        std::vector<double> areaM2(n);
        for (int c = 0; c < n; c++) areaM2[c] = (double)g.area[c] * Rm * Rm;
        const int ITER = 9;
        const double dt = 2.5e5, K = 1.5e-6 / std::sqrt(std::max(0.3, dv.g / 9.80665)), tauUp = 2.5e6;
        const double upFrac = 1.0 - dexp(-dt / tauUp);
        for (int it = 0; it < ITER; it++) {
            computeFlow(g, h, 0.0f, fl);
            for (int c = 0; c < n; c++) A[c] = (float)areaM2[c];
            for (int i = (int)fl.order.size() - 1; i >= 0; i--) {
                int c = fl.order[i];
                int r = fl.rec[c];
                if (r >= 0) A[r] += A[c];
            }
            for (int c = 0; c < n; c++)
                if (h[c] > 0.f && T.target[c] > h[c]) h[c] += (float)((T.target[c] - h[c]) * upFrac);
            std::fill(eroded.begin(), eroded.end(), 0.f);
            for (size_t i = 0; i < fl.order.size(); i++) {
                int c = fl.order[i];
                if (fl.fill[c] > h[c] + 0.5f) continue;
                int r = fl.rec[c];
                double hr = h[r] > 0.f ? h[r] : 0.0;
                double L = length(g.pos[c] - g.pos[r]) * Rm;
                double f = K * dt * std::sqrt((double)A[c]) / L;
                double hn = (h[c] + f * hr) / (1.0 + f);
                if (hn < h[c]) { eroded[c] = (float)(h[c] - hn); h[c] = (float)hn; }
            }
            // sediment: carried downstream, deposited where gradient is low, in lakes and at river mouths
            std::fill(Qs.begin(), Qs.end(), 0.f);
            const double sedEff = 0.35;
            for (int i = (int)fl.order.size() - 1; i >= 0; i--) {
                int c = fl.order[i];
                int r = fl.rec[c];
                double vin = (double)Qs[c] + (double)eroded[c] * areaM2[c] * sedEff;
                if (vin <= 0) continue;
                double hr = h[r] > 0.f ? h[r] : 0.0;
                double L = length(g.pos[c] - g.pos[r]) * Rm;
                double S = (h[c] - hr) / L;
                bool lake = fl.fill[c] > h[c] + 0.5f;
                double frac = lake ? 0.9 : clampv(1.0 - S / 0.004, 0.0, 0.8);
                double dep = vin * frac;
                h[c] += (float)(dep / areaM2[c]);
                T.sediment[c] += (float)(dep / areaM2[c]);
                Qs[r] += (float)(vin - dep);
            }
            // river mouths: deltas and shelf building in the ocean
            for (int c = 0; c < n; c++) {
                if (h[c] > 0.f || Qs[c] <= 0.f) continue;
                double vol = Qs[c];
                int cur = c;
                for (int hop = 0; hop < 10 && vol > 0; hop++) {
                    double room = std::max(0.0, std::min(60.0, 30.0 - (double)h[cur])) * areaM2[cur];
                    double dep = std::min(vol * 0.5, room);
                    h[cur] += (float)(dep / areaM2[cur]);
                    T.sediment[cur] += (float)(dep / areaM2[cur]);
                    vol -= dep;
                    int best = -1;
                    float bh = h[cur];
                    for (int k = 0; k < 4; k++) {
                        int q = g.nbr[(size_t)cur * 8 + k];
                        if (q >= 0 && h[q] < bh) { bh = h[q]; best = q; }
                    }
                    if (best < 0) break;
                    cur = best;
                }
            }
            // hillslope diffusion
            for (int c = 0; c < n; c++) {
                float s = 0; int m = 0;
                for (int k = 0; k < 4; k++) { int q = g.nbr[(size_t)c * 8 + k]; if (q >= 0) { s += h[q]; m++; } }
                nb[c] = (m > 0 && h[c] > 0.f) ? s / m : h[c];
            }
            for (int c = 0; c < n; c++) if (h[c] > 0.f) h[c] += 0.05f * (nb[c] - h[c]);
            if (it % 3 == 0) prog("Erosion", 0.62f + 0.18f * (float)it / ITER);
        }
        // coastal planation: waves flatten the shelf edge and create beaches/lagoons
        for (int pass = 0; pass < 4; pass++) {
            for (int c = 0; c < n; c++) {
                float s = 0; int m = 0;
                for (int k = 0; k < 8; k++) { int q = g.nbr[(size_t)c * 8 + k]; if (q >= 0) { s += h[q]; m++; } }
                nb[c] = m ? s / m : h[c];
            }
            for (int c = 0; c < n; c++)
                if (h[c] > -130.f && h[c] < 90.f) h[c] += 0.25f * (nb[c] - h[c]);
        }
    }

    // ---------------- H. final sea level + derived surface fields ----------------
    prog("Coastlines", 0.82f);
    double sea1 = 0, target = pp.oceanFraction;
    for (int iter = 0; iter < 3; iter++) {
        sea1 = findSea(h, target) + pp.seaLevelOffsetM;
        for (int c = 0; c < n; c++) T.height[c] = h[c] - (float)sea1;
        // landlocked below-sea-level basins are not ocean: turn them into low basins (lakes form later if water allows)
        std::vector<int32_t> lab(n, -1);
        std::vector<int> stack, compSize;
        int ncomp = 0;
        for (int c0 = 0; c0 < n; c0++) {
            if (T.height[c0] > 0.f || lab[c0] >= 0) continue;
            int sz = 0;
            stack.clear();
            stack.push_back(c0);
            lab[c0] = ncomp;
            while (!stack.empty()) {
                int c = stack.back();
                stack.pop_back();
                sz++;
                for (int k = 0; k < 8; k++) {
                    int q = g.nbr[(size_t)c * 8 + k];
                    if (q >= 0 && lab[q] < 0 && T.height[q] <= 0.f) { lab[q] = ncomp; stack.push_back(q); }
                }
            }
            compSize.push_back(sz);
            ncomp++;
        }
        int big = 0;
        for (int i = 1; i < ncomp; i++) if (compSize[i] > compSize[big]) big = i;
        for (int c = 0; c < n; c++)
            if (lab[c] >= 0 && lab[c] != big) {
                T.height[c] = std::max(T.height[c] * 0.02f, -60.0f) + 4.0f;
                if (T.height[c] <= 0.f) T.height[c] = 1.0f;
            }
        double land = 0, total = 0;
        for (int c = 0; c < n; c++) { total += g.area[c]; if (T.height[c] > 0) land += g.area[c]; }
        T.landFraction = land / total;
        double oceanNow = 1.0 - T.landFraction;
        if (pp.seaLevelOffsetM != 0.0 || std::fabs(oceanNow - pp.oceanFraction) < 0.004) break;
        target += pp.oceanFraction - oceanNow;
    }
    T.seaLevelRaw = sea0 + sea1;
    for (int c = 0; c < n; c++) {
        double best = 0, mn = T.height[c], mx = T.height[c];
        for (int k = 0; k < 8; k++) {
            int q = g.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            double L = length(g.pos[q] - g.pos[c]) * Rm;
            best = std::max(best, ((double)T.height[c] - T.height[q]) / L);
            mn = std::min(mn, (double)T.height[q]);
            mx = std::max(mx, (double)T.height[q]);
        }
        T.slope[c] = (float)best;
        double relief = (mx - mn) / 2000.0;
        double ocean = T.height[c] < 0 ? 0.25 : 1.0;
        T.rough[c] = (float)clampv((0.08 + 0.55 * relief + 0.55 * (double)T.orogeny[c]) * ocean, 0.04, 1.0);
        float px = (float)g.pos[c].x, py = (float)g.pos[c].y, pz = (float)g.pos[c].z;
        double rh = 0.40 + 0.45 * T.orogeny[c] - 0.30 * clampv((double)T.sediment[c] / 400.0, 0.0, 1.0) + 0.10 * nz.fbm(px * 5.0f, py * 5.0f, pz * 5.0f + 2.2f, 2);
        T.rockHard[c] = (float)clampv(rh, 0.05, 1.0);
    }
    prog("Terrain complete", 0.85f);
}

}  // namespace lw
