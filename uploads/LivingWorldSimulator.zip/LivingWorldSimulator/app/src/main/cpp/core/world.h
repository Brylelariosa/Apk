// World = the whole planet simulation.  Heavy work (generation, geological steps) runs on a
// caller-provided worker thread and publishes immutable snapshots; renderers/inspectors read
// snapshots on any thread without locks on the data itself.
#pragma once
#include <mutex>
#include <atomic>
#include <string>
#include "world_data.h"
#include "noise.h"
#include "tectonics.h"
#include "terrain.h"
#include "climate.h"
#include "ecology.h"

namespace lw {

struct EcoPack { HydroData H; EcoData E; };
struct ClimatePack { ClimateSlices sl; ClimateStatic st; };

struct StaticData {
    PlanetParams pp;
    Derived dv;
    uint64_t seed = 0;
    std::string seedStr;
    std::shared_ptr<const CubeGrid> fg, cg;
    Noise noise;
    Tectonics tect;
    std::shared_ptr<const TerrainData> Tp;
    std::shared_ptr<const EcoPack> Ep;
    std::shared_ptr<const ClimatePack> Cp;
    double tectTimeMyr = 0;
    uint32_t id = 0;
    const TerrainData& T() const { return *Tp; }
    const HydroData& H() const { return Ep->H; }
    const EcoData& E() const { return Ep->E; }
    const ClimateSlices& sl() const { return Cp->sl; }
    const ClimateStatic& st() const { return Cp->st; }
};

struct DynamicData {
    double timeYears = 0, fracYear = 0, dayFrac = 0, declDeg = 0;
    V3 sunDir;
    // current-date coarse fields (interpolated between monthly slices)
    std::vector<float> ta, ts, precip, wvap, cloud, snow, ice, wu, wv, pres, glacier;
    double globalT = 288.0;
};

struct View {
    std::shared_ptr<const StaticData> s;
    std::shared_ptr<const DynamicData> d;
    explicit operator bool() const { return s && d; }
};

struct Timings {
    double genTotalMs = 0, terrainMs = 0, climateMs = 0, ecoMs = 0, stepMs = 0, climateStepMs = 0, riverMs = 0;
};

class World {
public:
    World();
    ~World();
    void generate(const std::string& seed, const PlanetParams& pp, const ProgressFn& progress);
    // advance by `years` of simulated time; handles every scale from days to millions of years
    void advance(double years, const ProgressFn& progress);
    View view() const;
    void addDayHours(double hours);
    uint32_t generation() const { return gen_.load(); }
    Timings timings() const;
    bool ready() const { return (bool)view(); }
    static uint64_t parseSeed(const std::string& s);

private:
    void rebuild(const PlanetParams& pp, uint64_t seed, const std::string& seedStr, double tectMyr, bool warm, const ProgressFn& progress);
    void publishDynamic(const std::shared_ptr<const StaticData>& s, double timeYears);
    mutable std::mutex mu_;
    std::shared_ptr<const StaticData> s_;
    std::shared_ptr<const DynamicData> d_;
    std::unique_ptr<Climate> climate_;
    std::vector<float> veg_, soilCap_, glacier_;
    std::atomic<uint32_t> gen_{0};
    Timings tm_;
    double time_ = 0;
    double sinceSlow_ = 0;
    double dayPhase_ = 0;
};

// current-date interpolation helper (month slices -> date)
void sliceWeights(double fracYear, int& m0, int& m1, float& w);

}  // namespace lw
