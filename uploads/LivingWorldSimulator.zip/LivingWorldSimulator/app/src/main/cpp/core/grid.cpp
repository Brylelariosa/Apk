#include "grid.h"

namespace lw {

namespace {
const V3 FN[6] = {V3(1, 0, 0), V3(-1, 0, 0), V3(0, 1, 0), V3(0, -1, 0), V3(0, 0, 1), V3(0, 0, -1)};
const V3 FT1[6] = {V3(0, 1, 0), V3(0, -1, 0), V3(-1, 0, 0), V3(1, 0, 0), V3(1, 0, 0), V3(1, 0, 0)};
const V3 FT2[6] = {V3(0, 0, 1), V3(0, 0, 1), V3(0, 0, 1), V3(0, 0, 1), V3(0, 1, 0), V3(0, -1, 0)};

double triArea(const V3& a, const V3& b, const V3& c) {
    double tr = std::fabs(dot(a, cross(b, c)));
    double den = 1.0 + dot(a, b) + dot(b, c) + dot(c, a);
    return 2.0 * datan2(tr, den);
}
}  // namespace

void CubeGrid::faceAxes(int f, V3& n, V3& t1, V3& t2) { n = FN[f]; t1 = FT1[f]; t2 = FT2[f]; }

V3 CubeGrid::faceDir(int f, double u, double v) {
    double a = dtan(u * (PI / 4.0)), b = dtan(v * (PI / 4.0));
    return normalize(FN[f] + FT1[f] * a + FT2[f] * b);
}

void CubeGrid::dirToFace(const V3& d, int& f, double& u, double& v) {
    double ax = std::fabs(d.x), ay = std::fabs(d.y), az = std::fabs(d.z);
    if (ax >= ay && ax >= az) f = d.x > 0 ? 0 : 1;
    else if (ay >= az) f = d.y > 0 ? 2 : 3;
    else f = d.z > 0 ? 4 : 5;
    double dn = dot(d, FN[f]);
    double a = dot(d, FT1[f]) / dn, b = dot(d, FT2[f]) / dn;
    u = datan(a) * (4.0 / PI);
    v = datan(b) * (4.0 / PI);
}

int CubeGrid::cellOf(const V3& d) const {
    int f;
    double u, v;
    dirToFace(d, f, u, v);
    int i = (int)((u + 1.0) * 0.5 * N), j = (int)((v + 1.0) * 0.5 * N);
    i = clampv(i, 0, N - 1);
    j = clampv(j, 0, N - 1);
    return idx(f, i, j);
}

int CubeGrid::cellExt(int f, int i, int j) const {
    if (i >= 0 && i < N && j >= 0 && j < N) return idx(f, i, j);
    double u = 2.0 * (i + 0.5) / N - 1.0, v = 2.0 * (j + 0.5) / N - 1.0;
    return cellOf(faceDir(f, u, v));
}

void CubeGrid::build(int n, bool withGrad) {
    N = n;
    count = 6 * n * n;
    pos.assign(count, V3());
    lat.assign(count, 0.f);
    lon.assign(count, 0.f);
    area.assign(count, 0.f);
    for (int f = 0; f < 6; f++)
        for (int j = 0; j < N; j++)
            for (int i = 0; i < N; i++) {
                int c = idx(f, i, j);
                double u = 2.0 * (i + 0.5) / N - 1.0, v = 2.0 * (j + 0.5) / N - 1.0;
                V3 p = faceDir(f, u, v);
                pos[c] = p;
                lat[c] = (float)latOf(p);
                lon[c] = (float)lonOf(p);
                double u0 = 2.0 * i / N - 1.0, u1 = 2.0 * (i + 1) / N - 1.0, v0 = 2.0 * j / N - 1.0, v1 = 2.0 * (j + 1) / N - 1.0;
                V3 c00 = faceDir(f, u0, v0), c10 = faceDir(f, u1, v0), c11 = faceDir(f, u1, v1), c01 = faceDir(f, u0, v1);
                area[c] = (float)(triArea(c00, c10, c11) + triArea(c00, c11, c01));
            }
    nbr.assign((size_t)count * 8, -1);
    static const int DI[8] = {-1, 1, 0, 0, -1, 1, -1, 1};
    static const int DJ[8] = {0, 0, -1, 1, -1, -1, 1, 1};
    for (int f = 0; f < 6; f++)
        for (int j = 0; j < N; j++)
            for (int i = 0; i < N; i++) {
                int c = idx(f, i, j);
                int32_t* o = &nbr[(size_t)c * 8];
                for (int k = 0; k < 8; k++) {
                    int q = cellExt(f, i + DI[k], j + DJ[k]);
                    bool dup = (q == c);
                    for (int m = 0; m < k && !dup; m++) dup = (o[m] == q);
                    o[k] = dup ? -1 : q;
                }
            }
    hasGrad = withGrad;
    if (!withGrad) return;
    gw.assign((size_t)count * 24, 0.f);
    for (int c = 0; c < count; c++) {
        V3 e, nn;
        eastNorth(pos[c], e, nn);
        double dx[8], dy[8], w[8];
        double sxx = 0, sxy = 0, syy = 0;
        for (int k = 0; k < 8; k++) {
            int q = nbr[(size_t)c * 8 + k];
            if (q < 0) { w[k] = 0; dx[k] = dy[k] = 0; continue; }
            V3 dv = pos[q] - pos[c];
            dx[k] = dot(dv, e);
            dy[k] = dot(dv, nn);
            w[k] = 1.0 / (dx[k] * dx[k] + dy[k] * dy[k]);
            sxx += w[k] * dx[k] * dx[k];
            sxy += w[k] * dx[k] * dy[k];
            syy += w[k] * dy[k] * dy[k];
        }
        double det = sxx * syy - sxy * sxy;
        if (std::fabs(det) < 1e-30) continue;
        double i00 = syy / det, i01 = -sxy / det, i11 = sxx / det;
        for (int k = 0; k < 8; k++) {
            if (w[k] == 0) continue;
            double wx = w[k] * (i00 * dx[k] + i01 * dy[k]);
            double wy = w[k] * (i01 * dx[k] + i11 * dy[k]);
            V3 g = e * wx + nn * wy;
            gw[(size_t)c * 24 + k * 3 + 0] = (float)g.x;
            gw[(size_t)c * 24 + k * 3 + 1] = (float)g.y;
            gw[(size_t)c * 24 + k * 3 + 2] = (float)g.z;
        }
    }
}

void CubeGrid::locate(const V3& d, int ids[4], float w[4]) const {
    int f;
    double u, v;
    dirToFace(d, f, u, v);
    double fu = (u + 1.0) * 0.5 * N - 0.5, fv = (v + 1.0) * 0.5 * N - 0.5;
    int i0 = (int)std::floor(fu), j0 = (int)std::floor(fv);
    float tx = (float)(fu - i0), ty = (float)(fv - j0);
    ids[0] = cellExt(f, i0, j0);
    ids[1] = cellExt(f, i0 + 1, j0);
    ids[2] = cellExt(f, i0, j0 + 1);
    ids[3] = cellExt(f, i0 + 1, j0 + 1);
    w[0] = (1 - tx) * (1 - ty);
    w[1] = tx * (1 - ty);
    w[2] = (1 - tx) * ty;
    w[3] = tx * ty;
}

float CubeGrid::sample(const float* field, const V3& d) const {
    int ids[4];
    float w[4];
    locate(d, ids, w);
    return field[ids[0]] * w[0] + field[ids[1]] * w[1] + field[ids[2]] * w[2] + field[ids[3]] * w[3];
}

float CubeGrid::sampleCubic(const float* field, const V3& d) const {
    int f;
    double u, v;
    dirToFace(d, f, u, v);
    double fu = (u + 1.0) * 0.5 * N - 0.5, fv = (v + 1.0) * 0.5 * N - 0.5;
    int i0 = (int)std::floor(fu), j0 = (int)std::floor(fv);
    float tx = (float)(fu - i0), ty = (float)(fv - j0);
    auto cr = [](float t, float* w) {
        float t2 = t * t, t3 = t2 * t;
        w[0] = -0.5f * t3 + t2 - 0.5f * t;
        w[1] = 1.5f * t3 - 2.5f * t2 + 1.0f;
        w[2] = -1.5f * t3 + 2.0f * t2 + 0.5f * t;
        w[3] = 0.5f * t3 - 0.5f * t2;
    };
    float wx[4], wy[4];
    cr(tx, wx);
    cr(ty, wy);
    float sum = 0;
    bool inside = (i0 >= 1 && i0 + 2 < N && j0 >= 1 && j0 + 2 < N);
    for (int b = 0; b < 4; b++) {
        float row = 0;
        for (int a = 0; a < 4; a++) {
            int c = inside ? idx(f, i0 - 1 + a, j0 - 1 + b) : cellExt(f, i0 - 1 + a, j0 - 1 + b);
            row += wx[a] * field[c];
        }
        sum += wy[b] * row;
    }
    return sum;
}

}  // namespace lw
