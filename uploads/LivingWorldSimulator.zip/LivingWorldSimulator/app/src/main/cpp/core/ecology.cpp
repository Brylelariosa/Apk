#include "ecology.h"
#include "terrain.h"
#include "climate.h"
#include "biome.h"

namespace lw {

namespace {
double dayLengthFrac(double lat, double decl) {
    double x = -dtan(lat) * dtan(decl);
    if (x >= 1.0) return 0.0;
    if (x <= -1.0) return 1.0;
    return dacos(x) / PI;
}
}  // namespace

void buildHydroEco(const PlanetParams& pp, const Derived& dv, const Noise& nz, const CubeGrid& cg, const CubeGrid& fg,
                   const TerrainData& T, const ClimateSlices& sl, const ClimateStatic& st, const std::vector<float>& oroVec,
                   HydroData& H, EcoData& E, std::vector<float>& vegCoarse, std::vector<float>& soilCapCoarse,
                   std::vector<float>& glacierCoarse, const ProgressFn& progress) {
    const int n = fg.count, nc = cg.count;
    auto prog = [&](const char* s, float f) { if (progress) progress(s, f); };
    const double gam = dv.lapse, Rm = dv.R;
    auto resize = [&](std::vector<float>& v) { v.assign(n, 0.f); };
    for (auto* v : {&E.tAnn, &E.tMin, &E.tMax, &E.pAnn, &E.pDryFrac, &E.aridity, &E.soilMoist, &E.npp, &E.fertility, &E.soilDepth, &E.mineral,
                    &E.organic, &E.drainage, &E.seismicHaz, &E.volcHaz, &E.floodHaz, &E.slideHaz, &E.droughtHaz})
        resize(*v);
    for (auto* v : {&H.fill, &H.lakeLevel, &H.lakeDepth, &H.discharge, &H.dischargeMax, &H.runoff, &H.snowmeltFrac, &H.gw, &H.delta, &H.flood}) resize(*v);
    E.biome.assign(n, B_OCEAN);
    for (int r = 0; r < R_COUNT; r++) E.res[r].assign(n, 0);
    H.riverOrder.assign(n, 0);
    H.lakeKind.assign(n, 0);

    // ------------------------------------------------------------------ downscale climate + monthly water balance
    prog("Downscaling climate", 0.0f);
    std::vector<float> runMax(n, 0.f), runMelt(n, 0.f), petAnn(n, 0.f);
    double decl[NSLICE], rinv;
    for (int m = 0; m < NSLICE; m++) solarGeometry(dv, (m + 0.5) / NSLICE, decl[m], rinv);
    const double dayM = dv.yearDays / NSLICE;
    for (int c = 0; c < n; c++) {
        double h = T.height[c];
        int ids[4];
        float w[4];
        cg.locate(fg.pos[c], ids, w);
        double lat = fg.lat[c];
        if (h <= 0.0) {
            double ta = 0, pr = 0, mn = 1e9, mx = -1e9, dry = 0;
            for (int m = 0; m < NSLICE; m++) {
                double t = 0, p = 0;
                for (int k = 0; k < 4; k++) { t += w[k] * sl.ts[(size_t)m * nc + ids[k]]; p += w[k] * sl.precip[(size_t)m * nc + ids[k]]; }
                ta += t; pr += p * dayM;
                mn = std::min(mn, t); mx = std::max(mx, t);
                if (p * dayM < 60.0) dry += 1.0;
            }
            E.tAnn[c] = (float)(ta / NSLICE - 273.15);
            E.tMin[c] = (float)(mn - 273.15);
            E.tMax[c] = (float)(mx - 273.15);
            E.pAnn[c] = (float)pr;
            E.pDryFrac[c] = (float)(dry / NSLICE);
            E.aridity[c] = 2.0f;
            continue;
        }
        double zc = 0;
        for (int k = 0; k < 4; k++) zc += w[k] * st.zMean[ids[k]];
        double whc = 120.0 + 80.0 * clampv((double)T.sediment[c] / 150.0, 0.0, 1.0) + 40.0 * (1.0 - clampv((double)T.slope[c] / 0.01, 0.0, 1.0));
        double snowS = 0, soil = 0.5 * whc, smSum = 0;
        double Tm[NSLICE], Pm[NSLICE], PETm[NSLICE], runM[NSLICE], meltM[NSLICE];
        const float* op = &oroVec[(size_t)c * 3];
        V3 e, nn;
        eastNorth(fg.pos[c], e, nn);
        for (int m = 0; m < NSLICE; m++) {
            double t = 0, p = 0, wu = 0, wv = 0;
            for (int k = 0; k < 4; k++) {
                size_t o = (size_t)m * nc + ids[k];
                t += w[k] * sl.ta[o]; p += w[k] * sl.precip[o]; wu += w[k] * sl.wu[o]; wv += w[k] * sl.wv[o];
            }
            t += gam * (zc - h);
            double up = 1.3 * ((wu * e.x + wv * nn.x) * op[0] + (wu * e.y + wv * nn.y) * op[1] + (wu * e.z + wv * nn.z) * op[2]);
            double of = clampv(1.0 + 0.55 * dtanh(up / 0.05), 0.45, 1.8);
            Tm[m] = t - 273.15;
            Pm[m] = p * of * dayM;
            double Ld = dayLengthFrac(lat, decl[m]) * 2.0;
            double es = 6.108 * dexp(17.27 * Tm[m] / (Tm[m] + 237.3));
            PETm[m] = Tm[m] > 0 ? 0.1651 * Ld * 216.7 * es / (Tm[m] + 273.3) * dayM * 0.82 : 0.0;
        }
        for (int pass = 0; pass < 2; pass++)
            for (int m = 0; m < NSLICE; m++) {
                double fs = clampv((2.0 - Tm[m]) / 3.0, 0.0, 1.0);
                double snowfall = Pm[m] * fs, rain = Pm[m] - snowfall;
                double melt = std::min(snowS + snowfall, 3.5 * std::max(0.0, Tm[m]) * dayM);
                snowS = std::min(snowS + snowfall - melt, 8000.0);
                double in = rain + melt;
                double aet = std::min(PETm[m], soil + in);
                soil += in - aet;
                double sur = std::max(0.0, soil - whc);
                soil -= sur;
                double r2 = 0.12 * in * sqr(soil / whc);
                soil = std::max(0.0, soil - r2);
                runM[m] = sur + r2;
                meltM[m] = in > 1e-6 ? runM[m] * melt / in : 0.0;
                if (pass == 1) smSum += clampv(soil / whc, 0.0, 1.0);
            }
        double ra = 0, rmx = 0, rme = 0, pa = 0, pe = 0, mn = 1e9, mx = -1e9, ta = 0, dry = 0, sm = 0;
        sm = smSum / NSLICE;
        for (int m = 0; m < NSLICE; m++) {
            ra += runM[m]; rmx = std::max(rmx, runM[m]); rme += meltM[m]; pa += Pm[m]; pe += PETm[m];
            mn = std::min(mn, Tm[m]); mx = std::max(mx, Tm[m]); ta += Tm[m]; if (Pm[m] < 60.0) dry += 1.0;
        }
        E.tAnn[c] = (float)(ta / NSLICE);
        E.tMin[c] = (float)mn;
        E.tMax[c] = (float)mx;
        E.pAnn[c] = (float)pa;
        E.pDryFrac[c] = (float)(dry / NSLICE);
        E.aridity[c] = (float)(pa / std::max(30.0, pe));
        E.soilMoist[c] = (float)clampv(std::min(1.0, sm * 0.5 + 0.5 * std::min(1.0, (double)E.aridity[c])), 0.0, 1.0);
        H.runoff[c] = (float)ra;
        runMax[c] = (float)(rmx * 12.0);
        runMelt[c] = (float)rme;
        petAnn[c] = (float)pe;
    }

    // ------------------------------------------------------------------ flow routing, lakes, discharge
    prog("Rivers and lakes", 0.25f);
    FlowGraph fl;
    computeFlow(fg, T.height, 0.0f, fl);
    H.rec = fl.rec;
    std::vector<double> areaM2(n);
    for (int c = 0; c < n; c++) areaM2[c] = (double)fg.area[c] * Rm * Rm;
    const double secYr = dv.yearDays * 86400.0;
    std::vector<double> Q(n, 0.0), Qm(n, 0.0), Qmelt(n, 0.0);
    for (int c = 0; c < n; c++) {
        if (T.height[c] <= 0.f) continue;
        double k = areaM2[c] / 1000.0 / secYr;
        Q[c] = H.runoff[c] * k; Qm[c] = runMax[c] * k; Qmelt[c] = runMelt[c] * k;
    }
    std::vector<uint8_t> nIn(n, 0);
    for (int i = 0; i < (int)fl.order.size(); i++) { int r = fl.rec[fl.order[i]]; if (r >= 0 && T.height[r] > 0.f) nIn[r]++; }
    for (int c = 0; c < n; c++) {
        H.fill[c] = fl.fill[c];
        bool pit = T.height[c] > 0.f && fl.fill[c] > T.height[c] + 2.0f;
        H.lakeDepth[c] = pit ? fl.fill[c] - T.height[c] : 0.f;
        H.lakeLevel[c] = pit ? fl.fill[c] : T.height[c];
    }
    // accumulate downstream; lakes lose water to evaporation (closed basins end up dry / salty)
    for (int i = (int)fl.order.size() - 1; i >= 0; i--) {
        int c = fl.order[i];
        int r = fl.rec[c];
        if (H.lakeDepth[c] > 0.f) {
            double evap = std::max(0.0, (double)petAnn[c] * 0.9 - (double)E.pAnn[c]) / 1000.0 / secYr * areaM2[c] * 0.5;
            double q0 = Q[c];
            double q1 = std::max(0.0, q0 - evap);
            double sc = q0 > 0 ? q1 / q0 : 0.0;
            Q[c] = q1; Qm[c] *= sc; Qmelt[c] *= sc;
            if (q1 <= 0.0) H.lakeKind[c] = (E.aridity[c] < 0.35f) ? 3 : 2;
            else H.lakeKind[c] = 1;
        }
        if (r >= 0 && T.height[r] > 0.f) { Q[r] += Q[c]; Qm[r] += Qm[c]; Qmelt[r] += Qmelt[c]; }
        else if (r >= 0) H.globalDischarge += Q[c];
    }
    for (int c = 0; c < n; c++) {
        H.discharge[c] = (float)Q[c];
        H.dischargeMax[c] = (float)Qm[c];
        H.snowmeltFrac[c] = Q[c] > 1e-6 ? (float)clampv(Qmelt[c] / Q[c], 0.0, 1.0) : 0.f;
    }
    // Strahler-like river order
    {
        std::vector<uint8_t> mx(n, 0), cnt(n, 0);
        for (int i = (int)fl.order.size() - 1; i >= 0; i--) {
            int c = fl.order[i];
            int ord = mx[c] == 0 ? 1 : (cnt[c] >= 2 ? mx[c] + 1 : mx[c]);
            H.riverOrder[c] = (uint8_t)(Q[c] > 3.0 ? ord : 0);
            int r = fl.rec[c];
            if (r >= 0 && T.height[r] > 0.f && H.riverOrder[c]) {
                if (ord > mx[r]) { mx[r] = (uint8_t)ord; cnt[r] = 1; }
                else if (ord == mx[r]) cnt[r]++;
            }
        }
    }
    // ------------------------------------------------------------------ soil, NPP, biomes
    prog("Soils and vegetation", 0.5f);
    std::vector<float> vegF(n, 0.f);
    for (int c = 0; c < n; c++) {
        double h = T.height[c];
        if (h <= 0.0) continue;
        float px = (float)fg.pos[c].x, py = (float)fg.pos[c].y, pz = (float)fg.pos[c].z;
        double t = E.tAnn[c], p = E.pAnn[c], ai = E.aridity[c];
        double q = Q[c];
        double rip = clampv(dlog(std::max(q, 1.0)) / 9.210340371976184, 0.0, 1.0);
        double peff = p * (1.0 + 0.5 * rip * (ai < 0.6 ? 1.0 : 0.3));
        double nT = 3000.0 / (1.0 + dexp(1.315 - 0.119 * t));
        double nP = 3000.0 * (1.0 - dexp(-0.000664 * peff));
        double npp = std::min(nT, nP);
        if (E.tMax[c] < 8.0) npp *= 0.5;
        E.npp[c] = (float)npp;
        double slope = T.slope[c];
        // water table / wetness: flat low ground fed by rivers or standing water
        double flat = 1.0 - clampv(slope / 0.003, 0.0, 1.0);
        double wet = clampv(0.55 * flat + 0.5 * rip + (H.lakeDepth[c] > 0.f ? 0.6 : 0.0) + 0.3 * clampv(ai - 1.0, 0.0, 1.0) - 0.4, 0.0, 1.0);
        bool coastal = false;
        for (int k = 0; k < 4; k++) { int qn = fg.nbr[(size_t)c * 8 + k]; if (qn >= 0 && T.height[qn] <= 0.f) coastal = true; }
        BiomeIn bi{t, E.tMin[c], E.tMax[c], p, ai, E.pDryFrac[c] * 12.0, h, slope, wet, std::fabs((double)fg.lat[c]) * RAD2DEG, coastal};
        uint8_t b = classifyBiome(bi);
        E.biome[c] = b;
        if (H.lakeDepth[c] > 8.f && H.lakeKind[c] != 3) E.biome[c] = B_LAKE;
        double veg = clampv(npp / 1400.0, 0.0, 1.0);
        if (b == B_ICE) veg = 0;
        vegF[c] = (float)veg;
        // parent material richness
        double volc = T.volcanism[c];
        double alluv = clampv((double)T.sediment[c] / 250.0, 0.0, 1.0);
        double mineral = clampv(0.30 + 0.9 * volc + 0.5 * alluv + 0.15 * nz.fbm(px * 7.0f, py * 7.0f, pz * 7.0f, 2) - 0.25 * (T.rockHard[c] - 0.5) * (1.0 - alluv) * 0.6, 0.05, 1.0);
        // weathering and depth
        double weather = clampv(dexp(-sqr((t - 25.0) / 20.0)) * (1.0 - dexp(-p / 700.0)), 0.0, 1.0);
        double steep = clampv(slope / 0.03, 0.0, 1.0);
        double depth = clampv((0.15 + 2.6 * weather) * (1.0 - 0.85 * steep) + 3.0 * alluv * (1.0 - steep), 0.04, 8.0);
        double decomp = dexp(-(t - 5.0) / 14.0);
        double om = clampv(npp / 900.0 * clampv(decomp, 0.5, 2.0) * 0.7 + (b == B_WETLAND ? 0.5 : 0.0), 0.0, 1.0);
        double leach = clampv((p - 2200.0) / 2500.0, 0.0, 1.0) * clampv((t - 18.0) / 8.0, 0.0, 1.0);
        double dry = clampv(1.0 - ai / 0.35, 0.0, 1.0);
        double fert = 0.34 * mineral + 0.30 * om + 0.14 * clampv(depth / 1.5, 0.0, 1.0) + 0.22 * clampv((double)E.soilMoist[c], 0.0, 1.0) - 0.30 * leach - 0.25 * dry;
        if (b == B_ICE) fert = 0;
        E.mineral[c] = (float)mineral;
        E.soilDepth[c] = (float)depth;
        E.organic[c] = (float)om;
        E.fertility[c] = (float)clampv(fert, 0.0, 1.0);
        E.drainage[c] = (float)clampv(0.25 + 0.75 * steep + 0.3 * (1.0 - alluv) - 0.5 * wet, 0.0, 1.0);
        H.gw[c] = (float)clampv(0.5 * clampv(ai, 0.0, 1.5) / 1.5 + 0.5 * (1.0 - steep) * clampv((double)T.sediment[c] / 120.0 + 0.3, 0.0, 1.0), 0.0, 1.0);
        // deltas / floodplains
        double dl = 0;
        if (coastal && q > 50.0 && slope < 0.0015) dl = clampv(dlog(q / 50.0) / 4.605170185988092, 0.0, 1.0);
        H.delta[c] = (float)std::max(dl, alluv * 0.5 * flat * rip);
        double fl2 = clampv(dlog(std::max(1.0, (double)Qm[c])) / 12.664370, 0.0, 1.0) * flat * (0.4 + 0.6 * clampv(p / 1500.0, 0.0, 1.0));
        H.flood[c] = (float)clampv(fl2, 0.0, 1.0);
    }

    // ------------------------------------------------------------------ resources and hazards
    prog("Resources and hazards", 0.75f);
    for (int c = 0; c < n; c++) {
        float px = (float)fg.pos[c].x, py = (float)fg.pos[c].y, pz = (float)fg.pos[c].z;
        double h = T.height[c];
        bool land = h > 0;
        double sed = clampv((double)T.sediment[c] / 300.0, 0.0, 1.0);
        double orog = T.orogeny[c], volc = T.volcanism[c], cf = T.cf[c];
        auto patch = [&](float f, float off) { double v = nz.fbm(px * f + off, py * f, pz * f - off, 3); return smoothstep(-0.05, 0.45, v); };
        double shield = clampv((cf - 0.8) * 5.0, 0.0, 1.0) * (1.0 - orog) * (0.4 + 0.6 * T.rockHard[c]) * (1.0 - sed);
        double iron = (0.9 * shield * patch(14.f, 1.f) + 0.5 * orog * patch(20.f, 5.f) + 0.4 * volc * patch(25.f, 9.f));
        bool arc = T.btype[c] == 1 && T.bdist[c] < 500.0;
        double copper = (arc ? 1.0 : 0.25) * clampv(1.4 * volc + 0.9 * orog, 0.0, 1.0) * patch(22.f, 3.f);
        double humid = land ? smoothstep(600.0, 1400.0, (double)E.pAnn[c]) : 0.5;
        double coal = clampv(sed * 1.3, 0.0, 1.0) * (0.35 + 0.65 * humid) * (cf > 0.5 ? 1.0 : 0.0) * patch(12.f, 7.f) * (1.0 - 0.7 * orog);
        bool shelf = h > -400.0 && h < 250.0 && cf > 0.3;
        double oil = clampv(sed * 1.5, 0.0, 1.0) * (shelf ? 1.0 : 0.3) * patch(11.f, 2.f);
        double gas = clampv(0.55 * oil + 0.5 * coal * patch(16.f, 4.f), 0.0, 1.0);
        double gold = clampv(0.9 * orog + 0.8 * volc + 0.3 * shield, 0.0, 1.0) * sqr(patch(30.f, 6.f));
        double salt = 0;
        if (land) {
            salt = (H.lakeKind[c] == 3 ? 1.0 : 0.0) + (E.aridity[c] < 0.25f ? 0.8 : 0.0) * (T.slope[c] < 0.002f ? 1.0 : 0.2) * (0.3 + sed) * patch(10.f, 8.f);
        } else if (h > -200.0 && E.aridity[c] < 0.3f) salt = 0.5;
        double timber = 0;
        int b = E.biome[c];
        if (b == B_RAINFOREST || b == B_SEASONAL_FOREST || b == B_TEMP_FOREST || b == B_BOREAL || b == B_MANGROVE) timber = clampv(E.npp[c] / 1300.0, 0.0, 1.0);
        double v[R_COUNT] = {iron, copper, coal, oil, gas, gold, salt, timber};
        for (int r = 0; r < R_COUNT; r++) {
            double x = v[r];
            if (!land && (r == R_COAL || r == R_IRON || r == R_TIMBER || r == R_COPPER)) x = 0;
            E.res[r][c] = (uint8_t)clampv(x * 255.0, 0.0, 255.0);
        }
        // hazards
        double seis = clampv((double)T.seismic[c] * 1.2 + 0.02, 0.0, 1.0);
        E.seismicHaz[c] = (float)seis;
        E.volcHaz[c] = (float)clampv((double)T.volcanism[c] * 1.3, 0.0, 1.0);
        double sat = clampv((double)E.soilMoist[c], 0.0, 1.0);
        double steep = clampv((double)T.slope[c] / 0.04, 0.0, 1.0);
        E.slideHaz[c] = land ? (float)clampv(steep * (0.35 + 0.65 * sat) * (0.5 + 0.5 * clampv(E.pAnn[c] / 1500.0, 0.0, 1.0)) * (1.0 - 0.4 * T.rockHard[c]) + 0.3 * seis * steep, 0.0, 1.0) : 0.f;
        E.floodHaz[c] = H.flood[c];
        double dr = clampv(1.0 - E.aridity[c] / 0.9, 0.0, 1.0) * (0.5 + 0.5 * clampv(E.pDryFrac[c] * 2.0, 0.0, 1.0));
        E.droughtHaz[c] = land ? (float)dr : 0.f;
    }
    // ------------------------------------------------------------------ feedback fields for the climate (coarse)
    vegCoarse.assign(nc, 0.f);
    soilCapCoarse.assign(nc, 150.f);
    glacierCoarse.assign(nc, 0.f);
    {
        std::vector<double> sv(nc, 0.0), sa(nc, 0.0), sc(nc, 0.0);
        int ratio = fg.N / cg.N;
        for (int c = 0; c < n; c++) {
            if (T.height[c] <= 0.f) continue;
            int f, i, j;
            fg.unpack(c, f, i, j);
            int cc = cg.idx(f, i / ratio, j / ratio);
            double a = fg.area[c];
            sv[cc] += a * vegF[c];
            sc[cc] += a * (60.0 + 90.0 * E.soilDepth[c]);
            sa[cc] += a;
        }
        for (int c = 0; c < nc; c++) {
            vegCoarse[c] = sa[c] > 0 ? (float)(sv[c] / sa[c]) : 0.f;
            soilCapCoarse[c] = sa[c] > 0 ? (float)clampv(sc[c] / sa[c], 60.0, 400.0) : 150.f;
            glacierCoarse[c] = sl.glacier.size() == (size_t)nc ? sl.glacier[c] : 0.f;
        }
    }
    prog("Ecosystems complete", 1.0f);
}

}  // namespace lw
