#include "tectonics.h"

namespace lw {

void Tectonics::init(uint64_t seed, const PlanetParams& pp, const Derived& dv, const Noise& nz) {
    noise = &nz;
    radiusKm = pp.radiusKm;
    Rng rng(seed ^ 0x7EC70011ULL);
    int P = (int)std::floor(15.0 * pp.radiusKm / 6371.0 + rng.irange(-2, 2) + 0.5);
    P = clampv(P, 8, 26);
    plates.assign(P, Plate());
    // blue-noise-ish plate centres (best candidate)
    for (int i = 0; i < P; i++) {
        V3 best = rng.unitVec();
        double bestScore = 1e9;
        int tries = (i == 0) ? 1 : 24;
        for (int k = 0; k < tries; k++) {
            V3 c = rng.unitVec();
            double mx = -2;
            for (int j = 0; j < i; j++) mx = std::max(mx, dot(c, plates[j].seed));
            if (mx < bestScore) { bestScore = mx; best = c; }
        }
        Plate& pl = plates[i];
        pl.id = i;
        pl.seed = best;
        pl.weight = dexp(rng.range(-0.35, 0.45));
        pl.pole = rng.unitVec();
        pl.omega = rng.range(0.15, 0.85) * DEG2RAD * dv.plateScale;
        pl.baseAge = rng.range(60.0, 170.0);
    }
    // choose which plates are continental
    std::vector<int> order(P);
    for (int i = 0; i < P; i++) order[i] = i;
    for (int i = P - 1; i > 0; i--) std::swap(order[i], order[rng.irange(0, i)]);
    int nCont = (int)std::floor(P * (0.10 + 0.55 * dv.contFraction) + 0.5);
    nCont = clampv(nCont, 1, P - 1);
    for (int k = 0; k < P; k++) {
        Plate& pl = plates[order[k]];
        pl.cont = (k < nCont) ? rng.range(0.80, 1.20) : rng.range(-0.30, 0.10);
    }
    makeFrame(0.0, frame0);
    // continental threshold from a global quantile so the crust fraction matches the ocean parameter
    const int M = 16000;
    std::vector<double> mv(M);
    Rng r2(seed ^ 0x51ED270BULL);
    for (int i = 0; i < M; i++) {
        V3 x = r2.unitVec();
        TectSample s;
        sample(frame0, x, s);
        mv[i] = maskValue(x, s);
    }
    std::sort(mv.begin(), mv.end());
    int q = clampv((int)((1.0 - dv.contFraction) * M), 0, M - 1);
    contThreshold = mv[q];
}

void Tectonics::makeFrame(double tMyr, TectFrame& fr) const {
    fr.t = tMyr;
    fr.seed.resize(plates.size());
    for (size_t i = 0; i < plates.size(); i++)
        fr.seed[i] = (tMyr == 0.0) ? plates[i].seed : normalize(rotateAxis(plates[i].seed, plates[i].pole, plates[i].omega * tMyr));
}

V3 Tectonics::warp(const V3& x) const {
    float px = (float)x.x, py = (float)x.y, pz = (float)x.z;
    float a = 2.0f, b = 5.2f;
    V3 d(noise->n3(px * a + 13.1f, py * a, pz * a) * 0.20 + noise->n3(px * b + 3.7f, py * b, pz * b) * 0.045,
         noise->n3(px * a, py * a + 71.7f, pz * a) * 0.20 + noise->n3(px * b, py * b + 9.1f, pz * b) * 0.045,
         noise->n3(px * a, py * a, pz * a + 37.3f) * 0.20 + noise->n3(px * b, py * b, pz * b + 21.9f) * 0.045);
    return normalize(x + d);
}

V3 Tectonics::velocityCmYr(int p, const V3& x) const {
    const Plate& pl = plates[p];
    return cross(pl.pole, x) * (pl.omega * radiusKm * 0.1);
}

void Tectonics::sample(const TectFrame& fr, const V3& x, TectSample& s) const {
    V3 w = warp(x);
    int P = (int)plates.size();
    double d1 = 1e30, d2 = 1e30, c1 = 1, c2 = 1;
    int i1 = 0, i2 = 0;
    for (int i = 0; i < P; i++) {
        double dt = dot(w, fr.seed[i]);
        double chord = std::sqrt(std::max(1e-12, 2.0 - 2.0 * dt));
        double d = chord / plates[i].weight;
        if (d < d1) { d2 = d1; i2 = i1; c2 = c1; d1 = d; i1 = i; c1 = chord; }
        else if (d < d2) { d2 = d; i2 = i; c2 = chord; }
    }
    s.plate = i1;
    s.other = i2;
    V3 p1 = tangentPart(fr.seed[i1], w), p2 = tangentPart(fr.seed[i2], w);
    V3 gF = p2 * (1.0 / (c2 * plates[i2].weight)) - p1 * (1.0 / (c1 * plates[i1].weight));
    double gl = length(gF);
    double F = d2 - d1;
    s.distKm = (gl > 1e-9 ? F / gl : 1.0) * radiusKm;
    s.n = normalize(tangentPart(gF, x));
    V3 vr = velocityCmYr(i2, x) - velocityCmYr(i1, x);
    s.conv = -dot(vr, s.n);
    s.shear = dot(vr, cross(x, s.n));
    double sp = length(vr);
    double as = std::fabs(s.shear);
    if (sp < 0.4) s.type = 0;
    else if (s.conv > 0.6 * as) s.type = 1;
    else if (s.conv < -0.6 * as) s.type = 2;
    else s.type = 3;
}

double Tectonics::maskValue(const V3& y, const TectSample& s0) const {
    float px = (float)y.x, py = (float)y.y, pz = (float)y.z;
    double m = plates[s0.plate].cont + 0.50 * noise->fbm(px * 1.6f + 5.5f, py * 1.6f, pz * 1.6f, 4) + 0.15 * noise->fbm(px * 4.2f, py * 4.2f + 9.3f, pz * 4.2f, 3);
    double bias = (plates[s0.plate].cont - plates[s0.other].cont) * 1.1 * dexp(-s0.distKm / 350.0);
    return m + bias;
}

double Tectonics::crustFrac(const TectFrame& fr, const V3& x, const TectSample& s) const {
    double m;
    if (fr.t == 0.0) {
        m = maskValue(x, s);
    } else {
        const Plate& pl = plates[s.plate];
        V3 y = rotateAxis(x, pl.pole, -pl.omega * fr.t);
        TectSample s0;
        sample(frame0, y, s0);
        if (s0.plate != s.plate) return 0.0;   // newly created crust
        m = maskValue(y, s0);
    }
    return smoothstep(contThreshold - 0.06, contThreshold + 0.06, m);
}

}  // namespace lw
