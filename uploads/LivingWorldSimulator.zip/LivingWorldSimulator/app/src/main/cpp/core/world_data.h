// Data containers shared by all simulation stages.
// Fine grid  (terrain / hydrology / ecology): NT x NT cells per cube face.
// Coarse grid (climate): NC x NC cells per cube face.
#pragma once
#include <memory>
#include <functional>
#include "util.h"
#include "grid.h"
#include "params.h"

namespace lw {

constexpr int NT = 192;   // fine terrain grid resolution  (6*192^2 = 221k cells, ~52 km)
constexpr int NC = 64;    // coarse climate grid resolution (6*64^2  = 24.6k cells, ~157 km)
constexpr int NSLICE = 12;  // climate slices per orbital year

enum Biome : uint8_t {
    B_OCEAN = 0, B_RAINFOREST, B_SEASONAL_FOREST, B_SAVANNA, B_DESERT, B_SEMIARID, B_GRASSLAND,
    B_TEMP_FOREST, B_BOREAL, B_TUNDRA, B_ALPINE, B_WETLAND, B_MANGROVE, B_ICE, B_LAKE, B_COUNT
};

enum Resource : int { R_IRON = 0, R_COPPER, R_COAL, R_OIL, R_GAS, R_GOLD, R_SALT, R_TIMBER, R_COUNT };

typedef std::function<void(const char* stage, float progress)> ProgressFn;

// ---- geology / terrain (fine grid) -------------------------------------------------
struct TerrainData {
    int N = 0;
    // tectonic context
    std::vector<uint8_t> plate, plate2, btype;
    std::vector<float> bdist, conv, cf, crustAge, thickness, volcanism, seismic, orogeny, target;
    // surface
    std::vector<float> height;    // metres above sea level (sea level = 0)
    std::vector<float> sediment;  // metres of sediment laid down during erosion
    std::vector<float> rough;     // 0..1 roughness used for detail synthesis
    std::vector<float> slope;     // m / m
    std::vector<float> rockHard;  // 0..1
    double seaLevelRaw = 0;       // pre-shift elevation (m) that became sea level
    double landFraction = 0;
    std::vector<int32_t> volcanoes;   // fine-cell indices of notable volcanoes
};

// ---- hydrology (fine grid, uses climate) -------------------------------------------
struct HydroData {
    std::vector<int32_t> rec;        // flow receiver (-1 for ocean)
    std::vector<float> fill;         // filled elevation (metres); > height inside lakes
    std::vector<float> lakeLevel;    // surface elevation of standing water (== height where none)
    std::vector<float> lakeDepth;    // metres
    std::vector<float> discharge;    // mean annual discharge m^3/s
    std::vector<float> dischargeMax; // peak-month discharge m^3/s
    std::vector<float> runoff;       // mean annual runoff mm/yr
    std::vector<float> snowmeltFrac; // share of discharge from snow/ice melt
    std::vector<float> gw;           // groundwater storage index 0..1
    std::vector<uint8_t> riverOrder; // Strahler-like order (0 = not a river)
    std::vector<uint8_t> lakeKind;   // 0 none, 1 through-flow, 2 closed (terminal), 3 salt flat
    std::vector<float> delta;        // delta / alluvial index 0..1
    std::vector<float> flood;        // 0..1
    double globalDischarge = 0;      // m^3/s into oceans
};

// ---- ecology (fine grid) -----------------------------------------------------------
struct EcoData {
    std::vector<float> tAnn, tMin, tMax, pAnn, pDryFrac, aridity, soilMoist, npp;     // climate summaries (downscaled)
    std::vector<float> fertility, soilDepth, mineral, organic, drainage;            // soil (0..1 except depth m)
    std::vector<uint8_t> biome;
    std::vector<uint8_t> res[R_COUNT];                                             // resource potential 0..255
    std::vector<float> seismicHaz, volcHaz, floodHaz, slideHaz, droughtHaz;         // 0..1
};

// ---- climate (coarse grid) ---------------------------------------------------------
struct ClimateSlices {
    // all arrays: NSLICE * ncell
    std::vector<float> ta, ts, precip, wvap, cloud, snow, ice, wu, wv, pres, runoff;
    std::vector<float> glacier;        // thickness (m) of permanent land ice, annual
};

struct ClimateStatic {
    std::vector<float> zMean, landFrac, zMax, relief, ocean, veg, albedoLand, soilCap;
    std::vector<float> psi, cu, cv;    // ocean stream function and surface currents (east/north m/s), annual mean
    std::vector<float> upwell;         // upwelling rate m/s
    std::vector<float> itczLat;        // per longitude bin (36)
    double hadleyDeg = 30;
    double globalMeanT = 288.0, globalMeanP = 0, globalMeanE = 0, albedoP = 0.3;
    double waterImbalance = 0;
};

}  // namespace lw
