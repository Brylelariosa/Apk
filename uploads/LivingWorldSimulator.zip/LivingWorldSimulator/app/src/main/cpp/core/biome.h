// Biomes are never painted: they are derived from the simulated climate, soil water and terrain.
#pragma once
#include "world_data.h"

namespace lw {

struct BiomeIn {
    double tAnn;      // mean annual temperature (C)
    double tMin;      // coldest month (C)
    double tMax;      // warmest month (C)
    double pAnn;      // mm / yr
    double aridity;   // precipitation / potential evapotranspiration
    double dryMonths; // months with < 60 mm
    double elev;      // m above sea level
    double slope;     // m/m
    double wetness;   // 0..1 water table / river proximity
    double latAbs;    // degrees
    bool coastal;
};

// latAbsFn() supplies |latitude| in degrees only when a rule actually needs it (it is expensive to derive per texel).
template <class LatFn>
inline uint8_t classifyBiomeLazy(const BiomeIn& b, LatFn latAbsFn) {
    if (b.tMax < -2.0 || b.tAnn < -16.0) return B_ICE;
    if (b.aridity < 0.10 || b.pAnn < 130.0) return B_DESERT;
    if (b.tMax < 10.0) return (b.elev > 1400.0 && latAbsFn() < 62.0) ? B_ALPINE : B_TUNDRA;
    if (b.wetness > 0.82 && b.aridity > 0.9 && b.slope < 0.0015 && b.elev < 1800.0) {
        if (b.coastal && b.tMin > 14.0 && b.elev < 12.0) return B_MANGROVE;
        return B_WETLAND;
    }
    if (b.tMin >= 15.0) {
        if (b.pAnn > 1900.0 && b.dryMonths <= 2.5) return B_RAINFOREST;
        if (b.aridity > 0.85) return B_SEASONAL_FOREST;
        if (b.aridity > 0.40) return B_SAVANNA;
        if (b.aridity > 0.18) return B_SEMIARID;
        return B_DESERT;
    }
    if (b.tAnn < 3.5) {
        if (b.aridity > 0.45 && b.tMax >= 10.0) return B_BOREAL;
        if (b.aridity > 0.25) return B_TUNDRA;
        return B_DESERT;
    }
    if (b.tAnn >= 18.0) {
        if (b.aridity > 0.85) return B_TEMP_FOREST;
        if (b.aridity > 0.45) return B_SAVANNA;
        if (b.aridity > 0.20) return B_SEMIARID;
        return B_DESERT;
    }
    if (b.aridity > 0.80 && b.pAnn > 600.0) return B_TEMP_FOREST;
    if (b.aridity > 0.45) return B_GRASSLAND;
    if (b.aridity > 0.22) return B_SEMIARID;
    return B_DESERT;
}

inline uint8_t classifyBiome(const BiomeIn& b) {
    return classifyBiomeLazy(b, [&b]() { return b.latAbs; });
}

inline const char* biomeName(int b) {
    static const char* N[B_COUNT] = {"Ocean", "Tropical rainforest", "Tropical seasonal forest", "Savanna", "Desert", "Semi-arid steppe",
                                     "Temperate grassland", "Temperate forest", "Boreal forest", "Tundra", "Alpine", "Wetland", "Mangrove",
                                     "Ice / polar desert", "Lake"};
    return N[b < 0 || b >= B_COUNT ? 0 : b];
}

inline void biomeColor(int b, float& r, float& g, float& bl) {
    static const float C[B_COUNT][3] = {{0.02f, 0.10f, 0.25f}, {0.07f, 0.35f, 0.10f}, {0.22f, 0.45f, 0.14f}, {0.62f, 0.58f, 0.24f},
                                        {0.80f, 0.68f, 0.45f}, {0.66f, 0.60f, 0.34f}, {0.46f, 0.60f, 0.22f}, {0.14f, 0.38f, 0.14f},
                                        {0.12f, 0.30f, 0.20f}, {0.52f, 0.52f, 0.42f}, {0.48f, 0.46f, 0.42f}, {0.20f, 0.42f, 0.34f},
                                        {0.12f, 0.34f, 0.24f}, {0.93f, 0.95f, 0.97f}, {0.10f, 0.25f, 0.45f}};
    int i = b < 0 || b >= B_COUNT ? 0 : b;
    r = C[i][0]; g = C[i][1]; bl = C[i][2];
}

}  // namespace lw
