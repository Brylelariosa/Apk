// Cube-sphere grid (6 faces x N x N cells), tan-warped for near-uniform cells.
// Used at two resolutions: coarse climate grid and fine terrain grid.
#pragma once
#include "util.h"

namespace lw {

struct CubeGrid {
    int N = 0, count = 0;
    std::vector<V3> pos;          // unit vectors of cell centres
    std::vector<float> lat, lon;  // radians
    std::vector<float> area;      // steradians
    std::vector<int32_t> nbr;     // 8 per cell: -i,+i,-j,+j,-i-j,+i-j,-i+j,+i+j (-1 = missing)
    std::vector<float> gw;        // 24 per cell: least-squares gradient weights (per radian), optional
    bool hasGrad = false;

    void build(int n, bool withGrad);

    inline int idx(int f, int i, int j) const { return (f * N + j) * N + i; }
    inline void unpack(int c, int& f, int& i, int& j) const {
        int nn = N * N;
        f = c / nn;
        int r = c - f * nn;
        j = r / N;
        i = r - j * N;
    }
    static void faceAxes(int f, V3& n, V3& t1, V3& t2);
    static V3 faceDir(int f, double u, double v);                       // u,v in [-1,1]
    static void dirToFace(const V3& d, int& f, double& u, double& v);   // inverse
    int cellOf(const V3& d) const;
    int cellExt(int f, int i, int j) const;   // handles indices outside the face (up to ~N/2 away)
    void locate(const V3& d, int ids[4], float w[4]) const;             // bilinear stencil
    float sample(const float* field, const V3& d) const;                // bilinear
    float sampleCubic(const float* field, const V3& d) const;           // Catmull-Rom
    inline double cellKm(int c, double Rkm) const { return std::sqrt((double)area[c]) * Rkm; }
    inline double distKm(int a, int b, double Rkm) const { return length(pos[a] - pos[b]) * Rkm; }
};

}  // namespace lw
