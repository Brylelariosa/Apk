#include "climate.h"

namespace lw {

void solarGeometry(const Derived& dv, double yf, double& decl, double& rinv2) {
    const double varpi = 282.94 * DEG2RAD;
    double e = dv.ecc;
    double nu0 = -varpi;
    double E0 = 2.0 * datan2(std::sqrt(1 - e) * dsin(nu0 / 2), std::sqrt(1 + e) * dcos(nu0 / 2));
    double M = (E0 - e * dsin(E0)) + TAU * yf;
    double E = M;
    for (int i = 0; i < 7; i++) E = M + e * dsin(E);
    double nu = 2.0 * datan2(std::sqrt(1 + e) * dsin(E / 2), std::sqrt(1 - e) * dcos(E / 2));
    double r = 1.0 - e * dcos(E);
    double lam = nu + varpi;
    decl = dasin(dsin(dv.tilt) * dsin(lam));
    rinv2 = 1.0 / (r * r);
}

namespace {
const double LV = 2.5e6, RV = 461.5, RHO_W = 1025.0, CW = 4000.0;
inline double sgn(double x) { return x < 0 ? -1.0 : 1.0; }
}  // namespace

double Climate::es(double TK) const {
    double x = (TK - 150.0) * 4.0;
    if (x < 0) x = 0;
    if (x > (double)esTab_.size() - 2) x = (double)esTab_.size() - 2;
    int i = (int)x;
    double f = x - i;
    return esTab_[i] * (1 - f) + esTab_[i + 1] * f;
}
double Climate::wsat(double TK) const {
    double x = (TK - 150.0) * 4.0;
    if (x < 0) x = 0;
    if (x > (double)wsatTab_.size() - 2) x = (double)wsatTab_.size() - 2;
    int i = (int)x;
    double f = x - i;
    return wsatTab_[i] * (1 - f) + wsatTab_[i + 1] * f;
}

Climate::Climate(const PlanetParams& pp, const Derived& dv, const CubeGrid& cg, const CubeGrid& fg, const TerrainData& T)
    : pp_(pp), dv_(dv), cg_(cg), fg_(fg), T_(T) {
    n_ = cg.count;
    Rm_ = dv.R;
    // saturation tables
    int nt = (int)((380.0 - 150.0) * 4.0) + 2;
    esTab_.resize(nt);
    wsatTab_.resize(nt);
    for (int i = 0; i < nt; i++) {
        double TK = 150.0 + i * 0.25, TC = TK - 273.15;
        double e = 100.0 * 6.112 * dexp(17.67 * TC / (TC + 243.5));    // Pa (Bolton)
        if (TC < -60) e = 100.0 * 6.112 * dexp(17.67 * -60.0 / (-60.0 + 243.5)) * dexp((TC + 60.0) * 0.12);
        esTab_[i] = (float)e;
        double hw = clampv(RV * TK * TK / (LV * dv.lapse), 700.0, 7000.0);
        wsatTab_[i] = (float)(e / (RV * TK) * hw);    // kg/m^2 == mm
    }
    sinLat_.resize(n_); cosLat_.resize(n_); fcor_.resize(n_);
    eastV_.resize(n_ * 3); northV_.resize(n_ * 3);
    edgeDir_.assign((size_t)n_ * 12, 0.f); edgeInvL_.assign((size_t)n_ * 4, 0.f); lwU_.assign((size_t)n_ * 8, 0.f);
    for (int c = 0; c < n_; c++) {
        const V3& p = cg.pos[c];
        sinLat_[c] = (float)p.z;
        cosLat_[c] = (float)std::sqrt(std::max(0.0, 1.0 - p.z * p.z));
        fcor_[c] = (float)(dv.fCor0 * p.z);
        V3 e, nn;
        eastNorth(p, e, nn);
        eastV_[c * 3] = (float)e.x; eastV_[c * 3 + 1] = (float)e.y; eastV_[c * 3 + 2] = (float)e.z;
        northV_[c * 3] = (float)nn.x; northV_[c * 3 + 1] = (float)nn.y; northV_[c * 3 + 2] = (float)nn.z;
        for (int k = 0; k < 8; k++) {
            int q = cg.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            V3 dvv = cg.pos[q] - p;
            if (k < 4) {
                V3 d = normalize(tangentPart(dvv, p));
                edgeDir_[((size_t)c * 4 + k) * 3] = (float)d.x;
                edgeDir_[((size_t)c * 4 + k) * 3 + 1] = (float)d.y;
                edgeDir_[((size_t)c * 4 + k) * 3 + 2] = (float)d.z;
                edgeInvL_[(size_t)c * 4 + k] = (float)(1.0 / (length(dvv) * Rm_));
            }
            double aavg = 0.5 * ((double)cg.area[c] + (double)cg.area[q]);
            lwU_[(size_t)c * 8 + k] = (float)((k < 4 ? 2.0 / 3.0 : 1.0 / 6.0) / aavg);
        }
    }
    // fine -> coarse aggregates
    zEff_.assign(n_, 0.f); lf_.assign(n_, 0.f);
    st.zMax.assign(n_, 0.f); st.relief.assign(n_, 0.f);
    {
        std::vector<double> sa(n_, 0.0), sl(n_, 0.0), sz(n_, 0.0);
        std::vector<float> mn(n_, 1e9f);
        int ratio = fg.N / cg.N;
        for (int c = 0; c < fg.count; c++) {
            int f, i, j;
            fg.unpack(c, f, i, j);
            int cc = cg.idx(f, i / ratio, j / ratio);
            double a = fg.area[c];
            double h = T.height[c];
            sa[cc] += a;
            if (h > 0) {
                sl[cc] += a;
                sz[cc] += a * h;
                st.zMax[cc] = std::max(st.zMax[cc], (float)h);
            }
            mn[cc] = std::min(mn[cc], (float)std::max(h, 0.0));
        }
        for (int c = 0; c < n_; c++) {
            lf_[c] = (float)(sl[c] / sa[c]);
            zEff_[c] = (float)(sz[c] / sa[c]);
            st.relief[c] = st.zMax[c] - (lf_[c] > 0 ? mn[c] : 0.f);
        }
    }
    // fine-grid surface gradient (for orographic lift)
    oroVec_.assign((size_t)fg.count * 3, 0.f);
    for (int c = 0; c < fg.count; c++) {
        const V3& p = fg.pos[c];
        V3 e, nn;
        eastNorth(p, e, nn);
        double hs = std::max(0.0, (double)T.height[c]);
        double sxx = 0, sxy = 0, syy = 0, bx = 0, by = 0;
        for (int k = 0; k < 8; k++) {
            int q = fg.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            V3 dvv = fg.pos[q] - p;
            double dx = dot(dvv, e), dy = dot(dvv, nn);
            double w = 1.0 / (dx * dx + dy * dy);
            double dh = std::max(0.0, (double)T.height[q]) - hs;
            sxx += w * dx * dx; sxy += w * dx * dy; syy += w * dy * dy;
            bx += w * dx * dh; by += w * dy * dh;
        }
        double det = sxx * syy - sxy * sxy;
        if (std::fabs(det) < 1e-30) continue;
        double gx = (syy * bx - sxy * by) / det, gy = (-sxy * bx + sxx * by) / det;    // metres per radian
        V3 g = (e * gx + nn * gy) * (1.0 / Rm_);
        oroVec_[(size_t)c * 3] = (float)g.x; oroVec_[(size_t)c * 3 + 1] = (float)g.y; oroVec_[(size_t)c * 3 + 2] = (float)g.z;
    }
    // surface defaults
    glac_.assign(n_, 0.f); veg_.assign(n_, 0.4f); soilCap_.assign(n_, 150.f); albL_.assign(n_, 0.22f);
    // state
    Ta_.resize(n_); Ts_.resize(n_); W_.resize(n_); sm_.assign(n_, 0.4f); snow_.assign(n_, 0.f); cloud_.assign(n_, 0.6f);
    psi_.assign(n_, 0.f); fi_.assign(n_, 0.f); itcz_.assign(36, 0.f);
    wind_.assign((size_t)n_ * 3, 0.f); cur_.assign((size_t)n_ * 3, 0.f); pres_.assign(n_, 1013.f); divg_.assign(n_, 0.f);
    upw_.assign(n_, 0.f); taux_.assign((size_t)n_ * 3, 0.f);
    P_.assign(n_, 0.f); E_.assign(n_, 0.f); El_.assign(n_, 0.f); runoffS_.assign(n_, 0.f); wOro_.assign(n_, 0.f);
    acc_.assign((size_t)n_ * 4, 0.f);
    for (int c = 0; c < n_; c++) {
        double s = cg.pos[c].z;
        Ta_[c] = Ts_[c] = (float)(301.0 - 50.0 * s * s);
        W_[c] = (float)(0.7 * wsat(Ta_[c]));
    }
    // Stommel operator coefficients (static)
    stomC_.assign((size_t)n_ * 8, 0.f);
    stomS_.assign(n_, 1.f);
    const double rs = 4.0e-6 * (dv.omega / 7.2921e-5 > 0.3 ? 1.0 : 0.6);
    for (int c = 0; c < n_; c++) {
        double beta = 2.0 * dv.omega * cosLat_[c] / Rm_;
        V3 e(eastV_[c * 3], eastV_[c * 3 + 1], eastV_[c * 3 + 2]);
        double S = 0;
        for (int k = 0; k < 8; k++) {
            int q = cg.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            V3 g(cg.gw[(size_t)c * 24 + k * 3], cg.gw[(size_t)c * 24 + k * 3 + 1], cg.gw[(size_t)c * 24 + k * 3 + 2]);
            double cc = beta * dot(e, g) / Rm_ + rs * lwU_[(size_t)c * 8 + k] / (Rm_ * Rm_);
            stomC_[(size_t)c * 8 + k] = (float)cc;
            S += cc;
        }
        stomS_[c] = (float)(S > 1e-30 ? S : 1e-30);
    }
}

void Climate::setSurface(const std::vector<float>& veg, const std::vector<float>& soilCap, const std::vector<float>& glacierM) {
    if (veg.size() == (size_t)n_) {
        veg_ = veg;
        for (int c = 0; c < n_; c++) albL_[c] = (float)clampv(0.36 - 0.24 * (double)veg_[c], 0.10, 0.40);
    }
    if (soilCap.size() == (size_t)n_) soilCap_ = soilCap;
    if (glacierM.size() == (size_t)n_) glac_ = glacierM;
}

void Climate::insolation(int m, std::vector<float>& Q) const {
    double yf = (m + 0.5) / NSLICE, decl, rinv2;
    solarGeometry(dv_, yf, decl, rinv2);
    double sd, cd;
    dsincos(decl, sd, cd);
    if (std::fabs(cd) < 1e-4) cd = 1e-4;
    double k = dv_.S0 * rinv2 / PI;
    for (int c = 0; c < n_; c++) {
        double sp = sinLat_[c], cp = std::max(1e-6, (double)cosLat_[c]);
        double ch = -(sp / cp) * (sd / cd);
        double h0, sh;
        if (ch >= 1.0) { h0 = 0; sh = 0; }
        else if (ch <= -1.0) { h0 = PI; sh = 0; }
        else { h0 = dacos(ch); sh = std::sqrt(1.0 - ch * ch); }
        Q[c] = (float)(k * (h0 * sp * sd + cp * cd * sh));
    }
}

void Climate::computeWinds(int m) {
    (void)m;
    const double Rm = Rm_;
    // --- thermal equator (ITCZ): follows the maximum of moist static energy, not of temperature ---
    const int NL = 40, NLON = 36;
    std::vector<double> sum((size_t)NLON * NL, 0.0), cnt((size_t)NLON * NL, 0.0);
    for (int c = 0; c < n_; c++) {
        double lat = cg_.lat[c] * RAD2DEG;
        if (std::fabs(lat) >= 40.0) continue;
        int lb = clampv((int)((lat + 40.0) / 2.0), 0, NL - 1);
        int ob = clampv((int)((cg_.lon[c] * RAD2DEG + 180.0) / 10.0), 0, NLON - 1);
        double h = Ta_[c] + 0.86 * W_[c];
        sum[(size_t)ob * NL + lb] += h * cg_.area[c];
        cnt[(size_t)ob * NL + lb] += cg_.area[c];
    }
    double lim = clampv(6.0 + 0.9 * (dv_.tilt * RAD2DEG), 6.0, 40.0);
    std::vector<double> newItcz(NLON, 0.0);
    for (int o = 0; o < NLON; o++) {
        double s[NL];
        for (int l = 0; l < NL; l++) s[l] = cnt[(size_t)o * NL + l] > 0 ? sum[(size_t)o * NL + l] / cnt[(size_t)o * NL + l] : 0.0;
        double sm[NL];
        for (int l = 0; l < NL; l++) {
            double a = s[std::max(0, l - 1)], b = s[l], d = s[std::min(NL - 1, l + 1)];
            sm[l] = 0.25 * a + 0.5 * b + 0.25 * d;
        }
        int best = 0;
        for (int l = 1; l < NL; l++) if (sm[l] > sm[best]) best = l;
        double off = 0;
        if (best > 0 && best < NL - 1) {
            double a = sm[best - 1], b = sm[best], d = sm[best + 1];
            double den = a - 2 * b + d;
            if (std::fabs(den) > 1e-9) off = clampv(0.5 * (a - d) / den, -0.5, 0.5);
        }
        newItcz[o] = clampv(-40.0 + (best + 0.5 + off) * 2.0, -lim, lim);
    }
    for (int pass = 0; pass < 3; pass++) {
        double tmp[NLON];
        for (int o = 0; o < NLON; o++) tmp[o] = 0.25 * newItcz[(o + NLON - 1) % NLON] + 0.5 * newItcz[o] + 0.25 * newItcz[(o + 1) % NLON];
        for (int o = 0; o < NLON; o++) newItcz[o] = tmp[o];
    }
    for (int o = 0; o < NLON; o++) itcz_[o] = (float)(0.5 * itcz_[o] + 0.5 * newItcz[o]);

    // --- zonal-mean reference and hemispheric contrast ---
    const int NB = 90;
    std::vector<double> zs(NB, 0.0), zc(NB, 0.0);
    double eqS[2] = {0, 0}, eqC[2] = {0, 0}, poS[2] = {0, 0}, poC[2] = {0, 0};
    for (int c = 0; c < n_; c++) {
        double lat = cg_.lat[c] * RAD2DEG;
        int b = clampv((int)((lat + 90.0) / 2.0), 0, NB - 1);
        zs[b] += Ta_[c] * cg_.area[c];
        zc[b] += cg_.area[c];
        int hs = lat >= 0 ? 0 : 1;
        if (std::fabs(lat) < 15) { eqS[hs] += Ta_[c] * cg_.area[c]; eqC[hs] += cg_.area[c]; }
        if (std::fabs(lat) > 60) { poS[hs] += Ta_[c] * cg_.area[c]; poC[hs] += cg_.area[c]; }
    }
    double amp[2];
    for (int h = 0; h < 2; h++) {
        double dT = (eqC[h] > 0 && poC[h] > 0) ? eqS[h] / eqC[h] - poS[h] / poC[h] : 38.0;
        amp[h] = clampv(dT / 38.0, 0.45, 1.8) * dv_.pressScale;
    }
    // --- sea-level pressure: belts relative to the ITCZ + thermal lows/highs ---
    const double thH = dv_.hadleyDeg, thF = thH + 0.5 * (90.0 - thH);
    const double p0 = dv_.p0 / 100.0;
    std::vector<float> anom(n_), sm1(n_);
    for (int c = 0; c < n_; c++) {
        double lat = cg_.lat[c] * RAD2DEG, lon = cg_.lon[c] * RAD2DEG;
        double fo = (lon + 180.0) / 10.0 - 0.5;
        int o0 = (int)std::floor(fo);
        double t = fo - o0;
        double it = (1 - t) * itcz_[(o0 + NLON * 4) % NLON] + t * itcz_[(o0 + 1 + NLON * 4) % NLON];
        double d = lat - it, th = std::fabs(d);
        int hem = d >= 0 ? 0 : 1;
        double belts = -2.6 * dexp(-sqr(th / 11.0)) + 8.0 * dexp(-sqr((th - thH) / 11.0)) - 12.5 * dexp(-sqr((th - thF) / 10.0));
        double pol = 5.0 * dexp(-sqr((90.0 - std::fabs(lat)) / 22.0));
        int hl = lat >= 0 ? 0 : 1;
        int b = clampv((int)((lat + 90.0) / 2.0), 0, NB - 1);
        double tref = zc[b] > 0 ? zs[b] / zc[b] : (double)Ta_[c];
        anom[c] = (float)(-0.55 * (Ta_[c] - tref));
        pres_[c] = (float)(p0 + belts * amp[hem] + pol * amp[hl]);
    }
    for (int pass = 0; pass < 2; pass++) {
        for (int c = 0; c < n_; c++) {
            double s = 0; int k = 0;
            for (int j = 0; j < 8; j++) { int q = cg_.nbr[(size_t)c * 8 + j]; if (q >= 0) { s += anom[q]; k++; } }
            sm1[c] = (float)(0.5 * anom[c] + 0.5 * s / std::max(1, k));
        }
        anom.swap(sm1);
    }
    for (int c = 0; c < n_; c++) pres_[c] += anom[c];
    // --- winds: pressure gradient + Coriolis + surface friction ---
    for (int c = 0; c < n_; c++) {
        double gx = 0, gy = 0, gz = 0;
        for (int k = 0; k < 8; k++) {
            int q = cg_.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            double dp = pres_[q] - pres_[c];
            gx += cg_.gw[(size_t)c * 24 + k * 3] * dp;
            gy += cg_.gw[(size_t)c * 24 + k * 3 + 1] * dp;
            gz += cg_.gw[(size_t)c * 24 + k * 3 + 2] * dp;
        }
        double rho = pres_[c] * 100.0 / (dv_.Rspec * Ta_[c]);
        double s = -100.0 / (Rm * rho);
        V3 G(gx * s, gy * s, gz * s);
        double lf = lf_[c];
        double r = lf * 2.6e-5 + (1 - lf) * 1.3e-5;
        double f = fcor_[c];
        double ff = std::fabs(f) < 5.0e-5 ? 5.0e-5 * (cg_.lat[c] >= 0 ? 1.0 : -1.0) : f;
        f = ff;
        V3 kxG = cross(cg_.pos[c], G);
        double den = r * r + f * f;
        V3 u = (G * r - kxG * f) * (1.0 / den);
        double z = zEff_[c] + 0.8 * glac_[c];
        double damp = 1.0 - 0.35 * smoothstep(1500.0, 4500.0, z);
        wind_[(size_t)c * 3] = (float)(u.x * damp);
        wind_[(size_t)c * 3 + 1] = (float)(u.y * damp);
        wind_[(size_t)c * 3 + 2] = (float)(u.z * damp);
    }
    {
        std::vector<float> w2(wind_);
        for (int c = 0; c < n_; c++) {
            double sx = 0, sy = 0, sz = 0; int k = 0;
            for (int j = 0; j < 8; j++) {
                int q = cg_.nbr[(size_t)c * 8 + j];
                if (q < 0) continue;
                sx += wind_[(size_t)q * 3]; sy += wind_[(size_t)q * 3 + 1]; sz += wind_[(size_t)q * 3 + 2]; k++;
            }
            if (!k) continue;
            V3 v(0.5 * wind_[(size_t)c * 3] + 0.5 * sx / k, 0.5 * wind_[(size_t)c * 3 + 1] + 0.5 * sy / k, 0.5 * wind_[(size_t)c * 3 + 2] + 0.5 * sz / k);
            v = tangentPart(v, cg_.pos[c]);
            w2[(size_t)c * 3] = (float)v.x; w2[(size_t)c * 3 + 1] = (float)v.y; w2[(size_t)c * 3 + 2] = (float)v.z;
        }
        wind_.swap(w2);
    }
    for (int c = 0; c < n_; c++) {
        double d = 0;
        for (int k = 0; k < 8; k++) {
            int q = cg_.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            for (int a = 0; a < 3; a++) d += cg_.gw[(size_t)c * 24 + k * 3 + a] * (wind_[(size_t)q * 3 + a] - wind_[(size_t)c * 3 + a]);
        }
        divg_[c] = (float)(d / Rm);
    }
}

void Climate::computeOcean(int sweeps) {
    const double Rm = Rm_;
    // wind stress
    for (int c = 0; c < n_; c++) {
        double u0 = wind_[(size_t)c * 3], u1 = wind_[(size_t)c * 3 + 1], u2 = wind_[(size_t)c * 3 + 2];
        double sp = std::sqrt(u0 * u0 + u1 * u1 + u2 * u2);
        double k = 1.2 * 1.3e-3 * sp;
        taux_[(size_t)c * 3] = (float)(k * u0); taux_[(size_t)c * 3 + 1] = (float)(k * u1); taux_[(size_t)c * 3 + 2] = (float)(k * u2);
    }
    std::vector<float> rhs(n_, 0.f);
    for (int c = 0; c < n_; c++) {
        if (lf_[c] >= 0.5f) continue;
        V3 curl(0, 0, 0);
        for (int k = 0; k < 8; k++) {
            int q = cg_.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            V3 g(cg_.gw[(size_t)c * 24 + k * 3], cg_.gw[(size_t)c * 24 + k * 3 + 1], cg_.gw[(size_t)c * 24 + k * 3 + 2]);
            V3 dt(taux_[(size_t)q * 3] - taux_[(size_t)c * 3], taux_[(size_t)q * 3 + 1] - taux_[(size_t)c * 3 + 1], taux_[(size_t)q * 3 + 2] - taux_[(size_t)c * 3 + 2]);
            curl += cross(g, dt);
        }
        rhs[c] = (float)(dot(curl, cg_.pos[c]) / Rm / RHO_W);
    }
    const double omg = 1.75;
    for (int sw = 0; sw < sweeps; sw++) {
        for (int ci = 0; ci < n_; ci++) {
            int c = (sw & 1) ? n_ - 1 - ci : ci;
            if (lf_[c] >= 0.5f) { psi_[c] = 0.f; continue; }
            double s = 0;
            for (int k = 0; k < 8; k++) {
                int q = cg_.nbr[(size_t)c * 8 + k];
                if (q >= 0) s += stomC_[(size_t)c * 8 + k] * psi_[q];
            }
            double pn = (s - rhs[c]) / stomS_[c];
            psi_[c] = (float)(psi_[c] + omg * (pn - psi_[c]));
        }
    }
    // geostrophic-like surface currents from the transport stream function
    const double He = 400.0;
    for (int c = 0; c < n_; c++) {
        cur_[(size_t)c * 3] = cur_[(size_t)c * 3 + 1] = cur_[(size_t)c * 3 + 2] = 0.f;
        if (lf_[c] >= 0.5f) continue;
        V3 g(0, 0, 0);
        for (int k = 0; k < 8; k++) {
            int q = cg_.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            double dpsi = psi_[q] - psi_[c];
            g += V3(cg_.gw[(size_t)c * 24 + k * 3], cg_.gw[(size_t)c * 24 + k * 3 + 1], cg_.gw[(size_t)c * 24 + k * 3 + 2]) * dpsi;
        }
        V3 u = cross(cg_.pos[c], g) * (14.0 / (Rm * He));
        // wind-driven Ekman drift (3% of the wind, turned 45 deg to the right in the NH)
        double sp = std::sqrt(sqr(wind_[(size_t)c * 3]) + sqr(wind_[(size_t)c * 3 + 1]) + sqr(wind_[(size_t)c * 3 + 2]));
        (void)sp;
        cur_[(size_t)c * 3] = (float)u.x; cur_[(size_t)c * 3 + 1] = (float)u.y; cur_[(size_t)c * 3 + 2] = (float)u.z;
    }
    // Ekman transport divergence -> upwelling (coastal and equatorial)
    std::vector<float> me((size_t)n_ * 3, 0.f);
    for (int c = 0; c < n_; c++) {
        if (lf_[c] >= 0.5f) continue;
        double f = fcor_[c];
        double fe = std::fabs(f) > 3e-5 ? f : 3e-5 * sgn(cg_.lat[c]);
        V3 tau(taux_[(size_t)c * 3], taux_[(size_t)c * 3 + 1], taux_[(size_t)c * 3 + 2]);
        V3 M = cross(tau, cg_.pos[c]) * (1.0 / (RHO_W * fe));
        double l = length(M);
        if (l > 15.0) M = M * (15.0 / l);
        me[(size_t)c * 3] = (float)M.x; me[(size_t)c * 3 + 1] = (float)M.y; me[(size_t)c * 3 + 2] = (float)M.z;
    }
    for (int c = 0; c < n_; c++) {
        upw_[c] = 0.f;
        if (lf_[c] >= 0.5f) continue;
        double d = 0;
        for (int k = 0; k < 8; k++) {
            int q = cg_.nbr[(size_t)c * 8 + k];
            if (q < 0) continue;
            for (int a = 0; a < 3; a++) d += cg_.gw[(size_t)c * 24 + k * 3 + a] * (me[(size_t)q * 3 + a] - me[(size_t)c * 3 + a]);
        }
        upw_[c] = (float)clampv(0.1 * d / Rm, 0.0, 1.0e-6);
    }
}

void Climate::solveMoisture(int sweeps, double dt) {
    (void)dt;
    const double Rm2 = Rm_ * Rm_, Kh = 1.2e6, tauS = 14400.0, eps = 0.6, Hbl = 1200.0;
    const double gam = dv_.lapse;
    std::vector<float> E0o(n_), E0l(n_), Wsa(n_), Wss(n_), kl(n_), Wc(n_);
    std::vector<float> lam((size_t)n_ * 4), lamOut(n_);
    // orographic lift from sub-grid slopes (fine children) and wind
    int ratio = fg_.N / cg_.N;
    for (int c = 0; c < n_; c++) {
        int f, I, J;
        cg_.unpack(c, f, I, J);
        double w0 = wind_[(size_t)c * 3] * 1.3, w1 = wind_[(size_t)c * 3 + 1] * 1.3, w2 = wind_[(size_t)c * 3 + 2] * 1.3;
        double s = 0;
        for (int b = 0; b < ratio; b++)
            for (int a = 0; a < ratio; a++) {
                int fc = fg_.idx(f, I * ratio + a, J * ratio + b);
                double up = w0 * oroVec_[(size_t)fc * 3] + w1 * oroVec_[(size_t)fc * 3 + 1] + w2 * oroVec_[(size_t)fc * 3 + 2];
                if (up > 0) s += up;
            }
        wOro_[c] = (float)(s / (ratio * ratio));
    }
    for (int c = 0; c < n_; c++) {
        double lf = lf_[c];
        double z = zEff_[c] + 0.8 * glac_[c];
        double Tact = Ta_[c] - gam * z;
        double sp = std::sqrt(sqr(wind_[(size_t)c * 3]) + sqr(wind_[(size_t)c * 3 + 1]) + sqr(wind_[(size_t)c * 3 + 2]));
        double Ts = Ts_[c];
        double wa = wsat(Tact);
        Wsa[c] = (float)wa;
        Wss[c] = (float)(lf * wa + (1 - lf) * wsat(Ts));
        Wc[c] = (float)(0.92 * wa);
        // evaporation (kg/m^2/s)
        double eo = evapScale_ * 1.1e-3 * (sp + 1.5) * 0.622 * es(Ts) / (dv_.Rspec * Ts) * (1.0 - 0.85 * fi_[c]);
        double beta = (0.10 + 0.90 * clampv((double)sm_[c] / 0.6, 0.0, 1.0)) * (0.55 + 0.45 * veg_[c]);
        double snowc = clampv((double)snow_[c] / 40.0, 0.0, 1.0);
        double el = evapScale_ * 1.1e-3 * (sp + 1.5) * 0.622 * es(Tact) / (dv_.Rspec * Tact) * beta * (1.0 - 0.9 * snowc);
        el = std::min(el, std::max(0.0, (double)El_[c]) );   // El_ temporarily holds the energy cap (kg/m^2/s)
        E0o[c] = (float)eo;
        E0l[c] = (float)el;
        double hw = clampv(RV * Tact * Tact / (LV * gam), 700.0, 7000.0);
        double wconv = std::min(0.012, std::max(0.0, -(double)divg_[c] * Hbl));
        double latd = std::fabs((double)cg_.lat[c]) * RAD2DEG;
        double gT = 0;
        {
            double gx = 0, gy = 0, gz = 0;
            for (int k = 0; k < 8; k++) {
                int q = cg_.nbr[(size_t)c * 8 + k];
                if (q < 0) continue;
                double dT = Ta_[q] - Ta_[c];
                gx += cg_.gw[(size_t)c * 24 + k * 3] * dT; gy += cg_.gw[(size_t)c * 24 + k * 3 + 1] * dT; gz += cg_.gw[(size_t)c * 24 + k * 3 + 2] * dT;
            }
            gT = std::sqrt(gx * gx + gy * gy + gz * gz) / Rm_;
        }
        double wsyn = 0.014 * clampv(gT / 5.0e-6, 0.0, 1.6) * smoothstep(18.0, 38.0, latd);
        kl[c] = (float)((0.26 * wOro_[c] + 0.10 * wconv + 0.16 * wsyn * (1.0 + 0.0 * eps)) / hw);
        double lo = 0;
        for (int k = 0; k < 4; k++) {
            int q = cg_.nbr[(size_t)c * 8 + k];
            double qd = 0;
            if (q >= 0) {
                const float* d = &edgeDir_[((size_t)c * 4 + k) * 3];
                qd = 0.5 * ((wind_[(size_t)c * 3] + wind_[(size_t)q * 3]) * d[0] + (wind_[(size_t)c * 3 + 1] + wind_[(size_t)q * 3 + 1]) * d[1] + (wind_[(size_t)c * 3 + 2] + wind_[(size_t)q * 3 + 2]) * d[2]);
            }
            double il = edgeInvL_[(size_t)c * 4 + k];
            lam[(size_t)c * 4 + k] = qd < 0 ? (float)(-qd * il) : 0.f;
            if (qd > 0) lo += qd * il;
        }
        double li = 0;
        for (int k = 0; k < 4; k++) li += lam[(size_t)c * 4 + k];
        lamOut[c] = (float)(li + 1.0 * (lo - li));
    }
    for (int sw = 0; sw < sweeps; sw++) {
        for (int ci = 0; ci < n_; ci++) {
            int c = (sw & 1) ? n_ - 1 - ci : ci;
            double lf = lf_[c];
            double lv = lamOut[c], wup = 0;
            for (int k = 0; k < 4; k++) {
                double l = lam[(size_t)c * 4 + k];
                if (l > 0) wup += l * W_[cg_.nbr[(size_t)c * 8 + k]];
            }
            double mu = 0, wm = 0;
            for (int k = 0; k < 8; k++) {
                int q = cg_.nbr[(size_t)c * 8 + k];
                if (q < 0) continue;
                double m = Kh * lwU_[(size_t)c * 8 + k] / Rm2;
                mu += m; wm += m * W_[q];
            }
            double E0 = lf * E0l[c] + (1 - lf) * E0o[c];
            double A = lv + mu + E0 / std::max(1.0, (double)Wss[c]) + kl[c];
            double B = wup + wm + E0;
            double w1 = B / A;
            double w;
            if (w1 > Wc[c]) w = (B + Wc[c] / tauS) / (A + 1.0 / tauS);
            else w = w1;
            W_[c] = (float)clampv(w, 0.0, 1.2 * (double)Wsa[c]);
        }
    }
    for (int c = 0; c < n_; c++) {
        double lf = lf_[c];
        double W = W_[c];
        double pr = kl[c] * W + std::max(0.0, W - Wc[c]) / tauS;
        double eo = E0o[c] * std::max(0.0, 1.0 - W / std::max(1.0, (double)Wss[c]));
        double el = E0l[c] * std::max(0.0, 1.0 - W / std::max(1.0, (double)Wss[c]));
        P_[c] = (float)(pr * 86400.0);
        El_[c] = (float)(el * 86400.0);
        E_[c] = (float)((lf * el + (1 - lf) * eo) * 86400.0);
    }
    double sP = 0, sE = 0;
    for (int c = 0; c < n_; c++) { sP += (double)P_[c] * cg_.area[c]; sE += (double)E_[c] * cg_.area[c]; }
}

void Climate::landSurface(int m, double dt) {
    (void)m;
    const double days = dt / 86400.0, ddf = 3.5;
    const double gam = dv_.lapse;
    for (int c = 0; c < n_; c++) {
        double lf = lf_[c];
        double z = zEff_[c] + 0.8 * glac_[c];
        double TC = Ta_[c] - gam * z - 273.15;
        double Pm = P_[c] * days;
        double fs = clampv((2.0 - TC) / 3.0, 0.0, 1.0);
        double Ps = Pm * fs, Pl = Pm - Ps;
        double potMelt = ddf * std::max(0.0, TC) * days;
        acc_[(size_t)c * 4] += (float)Ps;
        acc_[(size_t)c * 4 + 1] += (float)potMelt;
        acc_[(size_t)c * 4 + 2] += (float)Pm;
        acc_[(size_t)c * 4 + 3] += (float)(E_[c] * days);
        if (lf < 0.02) { snow_[c] = 0.f; runoffS_[c] = 0.f; continue; }
        double sn = snow_[c];
        double melt = std::min(sn + Ps, potMelt);
        sn = std::max(0.0, sn + Ps - melt);
        snow_[c] = (float)std::min(sn, 6000.0);
        double Cap = soilCap_[c];
        double sm = sm_[c] * Cap;
        double in = Pl + melt;
        double ea = std::min(El_[c] * days, sm + in);
        sm += in - ea;
        double rs = std::max(0.0, sm - Cap);
        sm -= rs;
        double r2 = 0.22 * in * sqr(sm / Cap);
        sm = std::max(0.0, sm - r2);
        if (TC < -3.0) { rs = 0; r2 = 0; }
        sm_[c] = (float)(sm / Cap);
        runoffS_[c] = (float)((rs + r2) / days);
    }
}

void Climate::stepSlice(int m, int sweepsT, int sweepsW, int sweepsP, bool store) {
    const double dt = dv_.yearDays * 86400.0 / NSLICE;
    const double gam = dv_.lapse;
    std::vector<float> Q(n_), Cs(n_), lam(n_), SWs(n_), SWa(n_), kup(n_), TaOld(Ta_), TsOld(Ts_);
    insolation(m, Q);
    double aGlob = 0, wGlob = 0;
    for (int c = 0; c < n_; c++) {
        double lf = lf_[c], lat = std::fabs((double)cg_.lat[c]) * RAD2DEG;
        double fi = fi_[c];
        double aOc = 0.06 + 0.12 * smoothstep(40.0, 80.0, lat);
        aOc = (1 - fi) * aOc + fi * 0.62;
        double al = albL_[c];
        double fs = clampv((double)snow_[c] / 40.0, 0.0, 1.0);
        double aSn = 0.72 - 0.30 * sqr((double)veg_[c]);
        al = (1 - fs) * al + fs * aSn;
        if (glac_[c] > 20.0f) al = 0.70;
        double as = lf * al + (1 - lf) * aOc;
        double cl = cloud_[c];
        double ap = clampv(0.04 + (1 - cl) * 0.9 * as + cl * 0.30, 0.05, 0.92);
        double sw = Q[c] * (1.0 - ap);
        SWs[c] = (float)(0.78 * sw);
        SWa[c] = (float)(0.22 * sw);
        double Cl = 8.0e6 * (1.0 + 0.6 * clampv((double)snow_[c] / 200.0, 0.0, 1.0));
        double Co = dv_.Cocean;
        if (lf < 0.5 && TsOld[c] > dv_.tFreezeK - 1.0 && TsOld[c] < dv_.tFreezeK + 0.8) Co += 1.3e8;
        Cs[c] = (float)(lf * Cl + (1 - lf) * Co);
        lam[c] = (float)(lf * 35.0 + (1 - lf) * 60.0 * (1.0 - 0.8 * fi));
        kup[c] = (float)((1 - lf) * RHO_W * CW * upw_[c]);
        aGlob += ap * Q[c] * cg_.area[c];
        wGlob += Q[c] * cg_.area[c];
    }
    st.albedoP = wGlob > 0 ? aGlob / wGlob : 0.3;
    const double Ca = dv_.Ca, Cadv = dv_.Ca * 0.10, B = dv_.olrB, A = dv_.olrA, Dd = dv_.diffD * 0.62, kap = 2.0;
    // upwelling brings cold deep water up; the same heat is returned uniformly so the global budget closes
    std::vector<float> upS(n_, 0.f);
    double upMean = 0, upArea = 0;
    for (int c = 0; c < n_; c++) {
        if (lf_[c] >= 0.5f) continue;
        double dTup = clampv((TsOld[c] - 275.15) * 0.30, 0.0, 6.0);
        upS[c] = (float)(RHO_W * CW * upw_[c] * dTup);
        upMean += upS[c] * cg_.area[c];
        upArea += cg_.area[c];
    }
    upMean = upArea > 0 ? upMean / upArea : 0.0;

    // Local implicit update of (air, surface) temperature in one cell.  Surface temperature is eliminated.
    auto localUpdate = [&](int c, double& Tan, double& Tsn, double& dEff, double& eLoc) {
        const int32_t* nb = &cg_.nbr[(size_t)c * 8];
        double dsum = 0, dnb = 0;
        for (int k = 0; k < 8; k++) {
            int q = nb[k];
            if (q < 0) continue;
            double w = Dd * lwU_[(size_t)c * 8 + k];
            dsum += w; dnb += w * Ta_[q];
        }
        double asum = 0, anb = 0, osum = 0, onb = 0;
        double lf = lf_[c];
        double Co = (1 - lf) * dv_.Cocean * kap;
        for (int k = 0; k < 4; k++) {
            int q = nb[k];
            if (q < 0) continue;
            const float* d = &edgeDir_[((size_t)c * 4 + k) * 3];
            double il = edgeInvL_[(size_t)c * 4 + k];
            double vd = wind_[(size_t)c * 3] * d[0] + wind_[(size_t)c * 3 + 1] * d[1] + wind_[(size_t)c * 3 + 2] * d[2];
            if (vd < 0) { double a = Cadv * (-vd) * il; asum += a; anb += a * Ta_[q]; }
            if (Co > 0) {
                double cd = cur_[(size_t)c * 3] * d[0] + cur_[(size_t)c * 3 + 1] * d[1] + cur_[(size_t)c * 3 + 2] * d[2];
                if (cd < 0) { double a = Co * (-cd) * il; osum += a; onb += a * Ts_[q]; }
            }
        }
        double a1 = Cs[c] / dt + lam[c] + osum;
        double b1 = Cs[c] / dt * TsOld[c] + SWs[c] + onb - (lf < 0.5 ? (upS[c] - upMean) : 0.0);
        double a2 = Ca / dt + lam[c] + B + dsum + asum;
        double b2 = Ca / dt * TaOld[c] + SWa[c] - A + B * 273.15 + dnb + anb;
        dEff = a2 - lam[c] * lam[c] / a1;
        Tan = (b2 + lam[c] * b1 / a1) / dEff;
        Tsn = (b1 + lam[c] * Tan) / a1;
        if (lf < 0.5 && Tsn < dv_.tFreezeK - 1.5) Tsn = dv_.tFreezeK - 1.5;
        eLoc = Ca / dt + B + lam[c] * (Cs[c] / dt + osum) / a1;
    };
    const int NB = 48;
    std::vector<int> band(n_);
    std::vector<double> bandArea(NB, 0.0);
    for (int c = 0; c < n_; c++) {
        band[c] = clampv((int)((sinLat_[c] + 1.0) * 0.5 * NB), 0, NB - 1);
        bandArea[band[c]] += cg_.area[c];
    }
    const double dx = 2.0 / NB;
    int cycles = sweepsT >= 30 ? 8 : 2;
    int parity = 0;
    auto sweep = [&]() {
        for (int ci = 0; ci < n_; ci++) {
            int c = (parity & 1) ? n_ - 1 - ci : ci;
            double Tan, Tsn, d, e;
            localUpdate(c, Tan, Tsn, d, e);
            Ta_[c] = (float)Tan;
            Ts_[c] = (float)Tsn;
        }
        parity++;
    };
    for (int cyc = 0; cyc < cycles; cyc++) {
        sweep();
        sweep();
        std::vector<double> rb(NB, 0.0), eb(NB, 0.0);
        for (int c = 0; c < n_; c++) {
            double Tan, Tsn, d, e;
            localUpdate(c, Tan, Tsn, d, e);
            double a = cg_.area[c];
            rb[band[c]] += a * d * (Tan - Ta_[c]);
            eb[band[c]] += a * e;
        }
        std::vector<double> lo(NB), di(NB), up(NB), rr(NB), cp(NB), dp(NB);
        for (int b = 0; b < NB; b++) {
            double xm = -1.0 + b * dx, xp = xm + dx;
            double cm = (1.0 - xm * xm) * Dd / (dx * dx), cpl = (1.0 - xp * xp) * Dd / (dx * dx);
            double ba = std::max(1e-12, bandArea[b]);
            di[b] = eb[b] / ba + cm + cpl;
            lo[b] = -cm;
            up[b] = -cpl;
            rr[b] = rb[b] / ba;
        }
        cp[0] = up[0] / di[0]; dp[0] = rr[0] / di[0];
        for (int b = 1; b < NB; b++) {
            double den = di[b] - lo[b] * cp[b - 1];
            cp[b] = up[b] / den;
            dp[b] = (rr[b] - lo[b] * dp[b - 1]) / den;
        }
        std::vector<double> eb2(NB);
        eb2[NB - 1] = dp[NB - 1];
        for (int b = NB - 2; b >= 0; b--) eb2[b] = dp[b] - cp[b] * eb2[b + 1];
        for (int c = 0; c < n_; c++) Ta_[c] += (float)eb2[band[c]];
        sweep();
        sweep();
    }
    // sea ice from surface temperature
    for (int c = 0; c < n_; c++) {
        double f = clampv((dv_.tFreezeK + 0.8 - Ts_[c]) / 1.8, 0.0, 1.0);
        fi_[c] = (float)(f * (1.0 - lf_[c]) * (lf_[c] < 0.5 ? 1.0 : 0.0));
    }
    computeWinds(m);
    computeOcean(sweepsP);
    // energy cap for land evaporation (absorbed surface shortwave / latent heat)
    for (int c = 0; c < n_; c++) El_[c] = (float)(std::max(0.0, (double)SWs[c]) / LV);
    solveMoisture(sweepsW, dt);
    landSurface(m, dt);
    // clouds
    for (int c = 0; c < n_; c++) {
        double z = zEff_[c] + 0.8 * glac_[c];
        double wa = wsat(Ta_[c] - gam * z);
        double rh = clampv(W_[c] / std::max(1.0, wa), 0.0, 1.2);
        double Pm = P_[c];
        double sc = (1 - lf_[c]) * clampv((Ta_[c] - Ts_[c]) / 3.0, 0.0, 1.0) * clampv(divg_[c] / 4e-6, 0.0, 1.0) * 0.30;
        cloud_[c] = (float)clampv(0.12 + 0.48 * smoothstep(0.30, 0.85, rh) + 0.25 * (1.0 - dexp(-Pm / 2.0)) + 0.12 * (1.0 - lf_[c]) + sc, 0.0, 0.95);
    }
    if (store) {
        size_t o = (size_t)m * n_;
        for (int c = 0; c < n_; c++) {
            double z = zEff_[c] + 0.8 * glac_[c];
            double lf = lf_[c];
            sl.ta[o + c] = (float)(Ta_[c] - gam * z);
            sl.ts[o + c] = (float)(lf > 0.5 ? Ts_[c] - gam * z : Ts_[c]);
            sl.precip[o + c] = P_[c];
            sl.wvap[o + c] = W_[c];
            sl.cloud[o + c] = cloud_[c];
            sl.snow[o + c] = snow_[c];
            sl.ice[o + c] = fi_[c];
            double u0 = wind_[(size_t)c * 3], u1 = wind_[(size_t)c * 3 + 1], u2 = wind_[(size_t)c * 3 + 2];
            sl.wu[o + c] = (float)(u0 * eastV_[c * 3] + u1 * eastV_[c * 3 + 1] + u2 * eastV_[c * 3 + 2]);
            sl.wv[o + c] = (float)(u0 * northV_[c * 3] + u1 * northV_[c * 3 + 1] + u2 * northV_[c * 3 + 2]);
            sl.pres[o + c] = pres_[c];
            sl.runoff[o + c] = runoffS_[c];
        }
    }
}

void Climate::run(int years, const ProgressFn& progress) {
    Timer tm;
    size_t tot = (size_t)NSLICE * n_;
    for (auto* v : {&sl.ta, &sl.ts, &sl.precip, &sl.wvap, &sl.cloud, &sl.snow, &sl.ice, &sl.wu, &sl.wv, &sl.pres, &sl.runoff}) v->assign(tot, 0.f);
    int steps = 0;
    for (int y = 0; y < years; y++) {
        std::fill(acc_.begin(), acc_.end(), 0.f);
        for (int m = 0; m < NSLICE; m++) {
            bool first = (!warm_ && y == 0);
            stepSlice(m, first ? 40 : 10, first ? 40 : 14, first ? 40 : 12, y == years - 1);
            steps++;
        }
        if (progress) progress("Climate", (float)(y + 1) / years);
    }
    warm_ = true;
    msPerStep = tm.ms() / std::max(1, steps);
    finalize();
}

void Climate::warmStartFrom(const Climate& o) {
    if (o.n_ != n_) return;
    Ta_ = o.Ta_; Ts_ = o.Ts_; W_ = o.W_; sm_ = o.sm_; snow_ = o.snow_; cloud_ = o.cloud_; psi_ = o.psi_; fi_ = o.fi_; itcz_ = o.itcz_;
    evapScale_ = o.evapScale_;
    for (int c = 0; c < n_; c++) if (lf_[c] < 0.02f) snow_[c] = 0.f;
    warm_ = true;
}

void Climate::finalize() {
    const double gam = dv_.lapse;
    st.landFrac = lf_;
    st.zMean = zEff_;
    st.ocean.assign(n_, 0.f);
    for (int c = 0; c < n_; c++) st.ocean[c] = 1.f - lf_[c];
    st.veg = veg_;
    st.albedoLand = albL_;
    st.soilCap = soilCap_;
    st.psi = psi_;
    st.cu.assign(n_, 0.f); st.cv.assign(n_, 0.f);
    for (int c = 0; c < n_; c++) {
        st.cu[c] = (float)(cur_[(size_t)c * 3] * eastV_[c * 3] + cur_[(size_t)c * 3 + 1] * eastV_[c * 3 + 1] + cur_[(size_t)c * 3 + 2] * eastV_[c * 3 + 2]);
        st.cv[c] = (float)(cur_[(size_t)c * 3] * northV_[c * 3] + cur_[(size_t)c * 3 + 1] * northV_[c * 3 + 1] + cur_[(size_t)c * 3 + 2] * northV_[c * 3 + 2]);
    }
    st.upwell = upw_;
    st.itczLat = itcz_;
    st.hadleyDeg = dv_.hadleyDeg;
    // global diagnostics (last cycle)
    double aT = 0, aP = 0, aE = 0, aw = 0, imb = 0;
    for (int c = 0; c < n_; c++) {
        double a = cg_.area[c];
        double t = 0;
        for (int m = 0; m < NSLICE; m++) t += sl.ta[(size_t)m * n_ + c];
        aT += a * t / NSLICE;
        aP += a * acc_[(size_t)c * 4 + 2] / 365.25;
        aE += a * acc_[(size_t)c * 4 + 3] / 365.25;
        aw += a;
        imb += a * (acc_[(size_t)c * 4 + 2] - acc_[(size_t)c * 4 + 3]);
    }
    st.globalMeanT = aT / aw;
    st.globalMeanP = aP / aw;
    st.globalMeanE = aE / aw;
    st.waterImbalance = imb / aw / std::max(1.0, aP / aw * 365.25);
    // perennial snow -> glacier thickness from the annual balance
    std::vector<float> H(n_, 0.f);
    for (int c = 0; c < n_; c++) {
        if (lf_[c] < 0.5f) continue;
        double bal = acc_[(size_t)c * 4] - acc_[(size_t)c * 4 + 1];
        double mn = 1e9;
        for (int m = 0; m < NSLICE; m++) mn = std::min(mn, (double)sl.snow[(size_t)m * n_ + c]);
        if (bal > 10.0 && mn > 30.0) H[c] = (float)(3300.0 * (1.0 - dexp(-bal / 60.0)));
    }
    for (int pass = 0; pass < 2; pass++) {
        std::vector<float> H2(H);
        for (int c = 0; c < n_; c++) {
            if (lf_[c] < 0.5f || H[c] <= 0.f) { H2[c] = 0.f; continue; }
            double sum = 0; int k = 0;
            for (int j = 0; j < 4; j++) { int q = cg_.nbr[(size_t)c * 8 + j]; if (q >= 0 && lf_[q] >= 0.5f && H[q] > 0.f) { sum += H[q]; k++; } }
            H2[c] = (float)(0.7 * H[c] + 0.3 * (k ? sum / k : H[c]));
        }
        H.swap(H2);
    }
    sl.glacier = H;
    (void)gam;
}

}  // namespace lw
