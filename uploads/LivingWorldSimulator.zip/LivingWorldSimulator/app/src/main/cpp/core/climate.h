// Coupled seasonal climate on the coarse grid:
//   sun -> insolation -> surface/air energy balance (+ ocean currents, upwelling, sea ice, snow)
//   -> pressure belts (Hadley/Ferrel/polar cells that follow the thermal equator) -> winds
//   -> wind-driven ocean gyres -> moisture transport, orographic lift, rain shadows
//   -> clouds, precipitation, snow, soil moisture, runoff.
#pragma once
#include "world_data.h"
#include "terrain.h"

namespace lw {

void solarGeometry(const Derived& dv, double yearFrac, double& decl, double& rinv2);

class Climate {
public:
    Climate(const PlanetParams& pp, const Derived& dv, const CubeGrid& cg, const CubeGrid& fg, const TerrainData& T);

    // surface properties fed back from ecology / ice (coarse resolution)
    void setSurface(const std::vector<float>& veg, const std::vector<float>& soilCapMm, const std::vector<float>& glacierM);
    // run `years` seasonal cycles; the last cycle is stored in `sl`
    void run(int years, const ProgressFn& progress);
    // reuse the atmosphere/ocean state of a previous climate (after a geological step) so spin-up is short
    void warmStartFrom(const Climate& o);

    ClimateSlices sl;
    ClimateStatic st;
    double msPerStep = 0;
    int ncell() const { return cg_.count; }
    const std::vector<float>& oroVec() const { return oroVec_; }

private:
    const PlanetParams pp_;
    const Derived dv_;
    const CubeGrid& cg_;
    const CubeGrid& fg_;
    const TerrainData& T_;
    int n_;
    double Rm_;

    // static geometry
    std::vector<float> sinLat_, cosLat_, fcor_, eastV_, northV_, edgeDir_, edgeInvL_, lwU_;
    std::vector<float> oroVec_;           // per fine cell: surface gradient (3)
    std::vector<float> zEff_, lf_, glac_, veg_, soilCap_, albL_;
    std::vector<float> wsatTab_, esTab_;
    // prognostic state
    std::vector<float> Ta_, Ts_, W_, sm_, snow_, cloud_, psi_, fi_, itcz_;
    std::vector<float> wind_, cur_, pres_, divg_, upw_, taux_;
    std::vector<float> P_, E_, El_, runoffS_, wOro_, stomC_, stomS_;
    std::vector<float> acc_;              // annual accumulators for diagnostics
    bool hasGlacier_ = false;
    bool warm_ = false;
    double evapScale_ = 1.25;

    double wsat(double TK) const;
    double es(double TK) const;
    void computeOro();
    void stepSlice(int m, int sweepsT, int sweepsW, int sweepsP, bool store);
    void insolation(int m, std::vector<float>& Q) const;
    void computeWinds(int m);
    void computeOcean(int sweeps);
    void solveMoisture(int sweeps, double dt);
    void landSurface(int m, double dt);
    void finalize();
};

}  // namespace lw
