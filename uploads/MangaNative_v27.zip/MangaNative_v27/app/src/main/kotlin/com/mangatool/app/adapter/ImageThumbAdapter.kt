package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.ImageMerger
import java.io.File

/**
 * Thumbnail adapter for extract-mode and merge-mode image grids.
 *
 * v19 changes — Glide replaces all manual bitmap loading:
 *
 *   BEFORE: Each bind launched a coroutine on BitmapUtils.decodeDispatcher,
 *   called BitmapFactory.decodeFile() manually, stored the result in
 *   AppState.thumbCache (an LruCache<String,Bitmap>), then posted setImageBitmap()
 *   to Main. Recycled views required manual job.cancel(). GC was responsible
 *   for reclaiming decoded Bitmaps.
 *
 *   AFTER (v19): Glide.with(view).load(File).override(140).format(RGB_565)
 *   .diskCacheStrategy(RESOURCE)... handles the full pipeline.
 *
 * v21 changes — pre-generated thumbnail files eliminate all runtime resize:
 *
 *   BEFORE (v19): Glide loaded the ORIGINAL extracted image (e.g. a 1200×1800 px
 *   JPEG) and resized it to 140 px via BitmapFactory + createScaledBitmap on every
 *   scroll. Even with DiskCacheStrategy.RESOURCE caching the result, cold-scroll
 *   on a fresh install still required full BitmapFactory decode of the original.
 *   This caused the observable lag on 50+ image lists.
 *
 *   AFTER (v21): MhtmlParser generates a real 140 px WebP file (3–6 KB) during
 *   extraction and stores its path in ImageItem.thumbnailPath. Glide now loads
 *   ONLY that tiny pre-made file:
 *     • override(140) is a no-op — the WebP is already 140 px
 *     • DiskCacheStrategy.NONE — the thumbnail file IS the cache; no Glide
 *       disk-cache overhead at all
 *     • skipMemoryCache(false) — hot entries still live in Glide's LruCache
 *       for instant re-bind on re-scroll
 *     • No BitmapFactory resize, no createScaledBitmap, no intermediate Bitmap
 *       allocation beyond the final display pixels
 *
 *   Fallback: if thumbnailPath is null (loose files from picker, or thumbnail
 *   generation failed), the adapter falls back to filePath with DiskCacheStrategy
 *   .RESOURCE so Glide caches the resized result after the first decode.
 *
 * RecyclerView optimisations (unchanged from v16):
 *   setHasStableIds(true), PAYLOAD_DIMS partial rebind, onViewRecycled cancel.
 */
class ImageThumbAdapter(
    initialItems: List<Any>,
    private val isMerge: Boolean,
    private val group: ImageGroup? = null,
    private val groupIdx: Int = 0,
    // PERF: val — onItemClick is now set once at adapter creation (in attachMainGrid)
    // and never reassigned. Changing var→val prevents accidental re-allocation.
    val onItemClick: (Int) -> Unit,
    private val onItemLongClick: ((ImageItem) -> Unit)? = null,
    private val onSwapChanged: (() -> Unit)? = null
) : RecyclerView.Adapter<ImageThumbAdapter.VH>() {

    companion object {
        /** Payload token for dims-only rebind — does NOT cancel in-flight Glide request. */
        const val PAYLOAD_DIMS = "dims"

        /**
         * ItemCallback for AsyncListDiffer.
         *
         * Items are either ImageItem (extract mode) or List<ImageItem> (merge pairs).
         * areItemsTheSame uses structural identity (originalIdx / pair-lead idx) so the
         * differ can detect moves, insertions, and removals without comparing content.
         * areContentsTheSame guards against unnecessary rebinds when only
         * unrelated fields change (e.g. size bytes metadata update).
         */
        val ITEM_CALLBACK = object : DiffUtil.ItemCallback<Any>() {
            override fun areItemsTheSame(oldItem: Any, newItem: Any): Boolean = when {
                oldItem is ImageItem && newItem is ImageItem ->
                    oldItem.originalIdx == newItem.originalIdx
                oldItem is List<*>   && newItem is List<*>   ->
                    (oldItem.firstOrNull() as? ImageItem)?.originalIdx ==
                    (newItem.firstOrNull() as? ImageItem)?.originalIdx
                else -> oldItem == newItem
            }
            override fun areContentsTheSame(oldItem: Any, newItem: Any): Boolean = when {
                oldItem is ImageItem && newItem is ImageItem ->
                    oldItem.filePath     == newItem.filePath     &&
                    oldItem.thumbnailPath == newItem.thumbnailPath &&
                    oldItem.userDeleted  == newItem.userDeleted  &&
                    oldItem.width        == newItem.width        &&
                    oldItem.height       == newItem.height
                oldItem is List<*>   && newItem is List<*>   ->
                    oldItem.size == newItem.size && oldItem.zip(newItem).all { (a, b) ->
                        a is ImageItem && b is ImageItem && a.filePath == b.filePath
                    }
                else -> oldItem == newItem
            }
        }
    }

    /**
     * AsyncListDiffer runs DiffUtil on a background thread, then posts
     * fine-grained notifyItem* calls back to Main.  This replaces the old
     * notifyDataSetChanged() in refreshItems(), which forced every visible
     * VH to rebind and re-issue its Glide request in a single frame —
     * the primary cause of the "thumbnail tsunami" after extraction.
     *
     * First submitList() (empty → N items) is synchronous in AsyncListDiffer
     * because there is nothing to diff.  Subsequent calls (filter changes,
     * re-extraction) run on Dispatchers.Default and only produce targeted
     * notifyItemInserted / notifyItemChanged / notifyItemRemoved calls,
     * so Glide only re-loads the items that actually changed.
     */
    private val differ = AsyncListDiffer(this, ITEM_CALLBACK)

    // Convenience accessor keeps all internal usages concise.
    private val items: List<Any> get() = differ.currentList

    // Single RequestManager cached at adapter creation time.
    // Glide.with(view) internally does Glide.with(view.context) which calls
    // Glide.get(context) — a synchronized singleton lookup — and then looks up
    // or creates a lifecycle-tracking RequestManager for the Fragment/Activity.
    // Called 30 times per expand (once per thumbnail), that's 30 synchronized
    // singleton lookups + 30 FragmentManager traversals per tap.
    // Caching the RequestManager collapses all 30 lookups into one.
    // The RequestManager is tied to the Activity lifecycle, so it correctly
    // pauses/resumes/clears requests when the app goes to background.
    private var glide: com.bumptech.glide.RequestManager? = null

    private fun glide(context: android.content.Context): com.bumptech.glide.RequestManager =
        glide ?: Glide.with(context).also { glide = it }

    fun destroy() {
        glide = null
    }

    init {
        setHasStableIds(true)
        // First submitList on an empty differ is synchronous — items are
        // immediately available for the first onBindViewHolder call.
        differ.submitList(initialItems)
    }

    override fun getItemId(position: Int): Long = when (val item = items[position]) {
        is ImageItem -> item.originalIdx.toLong()
        is List<*>   -> (item.firstOrNull() as? ImageItem)?.originalIdx?.toLong()
                            ?: position.toLong()
        else         -> position.toLong()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:      ImageView  = v.findViewById(R.id.thumb_image)
        val overlay:    View       = v.findViewById(R.id.thumb_overlay)
        val dims:       TextView?  = v.findViewById(R.id.thumb_dims)
        val thumbLeft:  ImageView? = v.findViewById(R.id.thumb_left)
        val thumbRight: ImageView? = v.findViewById(R.id.thumb_right)
        val btnSwap:    Button?    = v.findViewById(R.id.btn_swap)
        // No Job fields — Glide manages request lifecycle per ImageView target
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (isMerge) R.layout.item_thumb_merge else R.layout.item_thumb
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        val holder = VH(v)

        // Attach click listeners ONCE at creation — bindingAdapterPosition is
        // always fresh at click time, no stale index risk.
        v.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onItemClick(pos)
        }
        v.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (!isMerge && pos != RecyclerView.NO_ID.toInt())
                onItemLongClick?.invoke(items[pos] as ImageItem)
            true
        }
        holder.btnSwap?.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (group != null && pos != RecyclerView.NO_ID.toInt()) {
                @Suppress("UNCHECKED_CAST")
                val curPair = items[pos] as List<ImageItem>
                if (group.pairSwaps.contains(pos)) group.pairSwaps.remove(pos)
                else group.pairSwaps.add(pos)
                // Glide's cache key includes the File path. Swapping just
                // rebinds with the files in reversed order — no manual cache
                // eviction needed; Glide loads the correct file for each side.
                notifyItemChanged(pos)
                onSwapChanged?.invoke()
            }
        }
        return holder
    }

    override fun getItemCount() = items.size

    /**
     * Payload-aware bind: PAYLOAD_DIMS only updates the dims badge without
     * interrupting the in-flight Glide request on the ImageView.
     */
    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_DIMS }) {
            val img = items.getOrNull(position) as? ImageItem ?: return
            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.overlay.visibility = View.GONE
        holder.dims?.visibility   = View.GONE

        if (!isMerge) {
            // ── Extract mode ──────────────────────────────────────────────────
            val img = items[position] as ImageItem
            holder.overlay.visibility = if (img.userDeleted) View.VISIBLE else View.GONE

            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }

            // v21: load thumbnail file, NOT the original extracted image.
            // thumbnailPath is null only for picker imports — falls back to filePath.
            loadThumb(holder.image, img.thumbnailPath, img.filePath)

        } else {
            // ── Merge mode ────────────────────────────────────────────────────
            @Suppress("UNCHECKED_CAST")
            val pair    = items[position] as List<ImageItem>
            val swapped = group?.pairSwaps?.contains(position) == true
            val leftImg  = if (swapped && pair.size > 1) pair[1] else pair[0]
            val rightImg = if (swapped && pair.size > 1) pair[0] else pair.getOrNull(1)

            holder.thumbLeft?.let  { loadThumb(it, leftImg.thumbnailPath,  leftImg.filePath)  }
            if (rightImg != null) {
                holder.thumbRight?.let { loadThumb(it, rightImg.thumbnailPath, rightImg.filePath) }
            } else {
                holder.thumbRight?.let { glide(it.context).clear(it) }
            }
        }
    }

    /**
     * Load a pre-generated thumbnail (or fall back to the original) via Glide.
     *
     * Primary path — [thumbnailPath] is non-null (all MHTML extractions):
     *   The thumbnail is already 140 px WebP written by MhtmlParser.
     *   override(140)               — signals target size to Glide; actual decode
     *                                 is a no-op resize since the file is already 140 px
     *   PREFER_RGB_565              — ADDED IN v27 (was missing on this path).
     *                                 Pre-built WebP thumbnails are opaque manga pages
     *                                 (no alpha channel). RGB_565 = 2 bytes/pixel vs
     *                                 ARGB_8888 = 4 bytes/pixel; visually identical at
     *                                 140 px and halves decoded bitmap memory:
     *                                   140×140 ARGB_8888 = ~78 KB
     *                                   140×140 RGB_565   = ~39 KB  (saves ~39 KB each)
     *                                 For 30 thumbnails per chapter: ~1.17 MB saved per
     *                                 expanded group from Glide's LruCache. More cache
     *                                 room → fewer evictions → fewer disk re-reads on
     *                                 scroll → smoother cover pop-in.
     *                                 The cover thumbnails in ChapterAdapter.onBindViewHolder
     *                                 already had this fix; this is the matching fix for
     *                                 the inner thumbnail grid.
     *   DiskCacheStrategy.NONE      — the thumbnail file IS the persistent cache;
     *                                 adding a second Glide disk-cache layer wastes
     *                                 IO and doubles storage for no benefit
     *   skipMemoryCache(false)      — keep hot thumbnails in Glide's LruCache for
     *                                 instant re-bind when the same item re-enters view
     *   dontAnimate()               — skip crossfade compositing; saves a frame
     *
     * Fallback path — [thumbnailPath] is null (picker imports, generation failed):
     *   Glide loads the original via filePath with DiskCacheStrategy.RESOURCE so
     *   the resized result is cached after the first decode. Performance is identical
     *   to v19 for this minority of items.
     */
    private fun loadThumb(target: ImageView, thumbnailPath: String?, fallbackPath: String) {
        if (thumbnailPath != null) {
            // Fast path: load the pre-built thumbnail — no runtime resize.
            glide(target.context)
                .load(File(thumbnailPath))
                .override(140)
                .format(DecodeFormat.PREFER_RGB_565)   // v27: was missing; saves ~39 KB/thumbnail
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(false)
                .into(target)
        } else {
            // Fallback: original file; Glide resizes and caches the 140 px result.
            glide(target.context)
                .load(File(fallbackPath))
                .override(140)
                .format(DecodeFormat.PREFER_RGB_565)
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .skipMemoryCache(false)
                .into(target)
        }
    }

    override fun onViewRecycled(holder: VH) {
        // Explicitly cancel any in-flight request on the ImageView and release
        // the Bitmap reference back into Glide's BitmapPool for reuse.
        // Glide would eventually do this itself, but calling clear() eagerly
        // prevents a stale image briefly flashing on the recycled view.
        glide(holder.itemView.context).clear(holder.image)
        holder.thumbLeft?.let  { glide(holder.itemView.context).clear(it) }
        holder.thumbRight?.let { glide(holder.itemView.context).clear(it) }
        super.onViewRecycled(holder)
    }

    /**
     * Submit a new item list to the differ.
     *
     * AsyncListDiffer computes the diff on a background thread and posts only
     * the changed positions back via notifyItem*(). Glide only re-loads the
     * items that actually changed — not every visible cell as notifyDataSetChanged
     * would do. For filter-slider drags with 30+ expanded chapters, this
     * eliminates hundreds of redundant thumbnail requests per interaction.
     */
    fun refreshItems(newItems: List<Any>) = differ.submitList(newItems)

}
