package com.mangatool.app.adapter

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.mangatool.app.AppMode
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.ImageMerger
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Outer adapter: one row per ImageGroup. Each row can expand to show a grid of
 * thumbnails (via an inner ImageThumbAdapter) and a filtered-images section.
 *
 * v19 changes:
 *   • Cover thumbnail loading replaced with Glide — no CoroutineScope, no Job,
 *     no AppState.thumbCache. Glide handles cancellation, BitmapPool reuse,
 *     memory + disk caching automatically.
 *   • FilteredThumbAdapter similarly migrated to Glide.
 *   • VH.coverJob field removed — Glide.with(view).clear() in onViewRecycled.
 *   • ChapterAdapter.scope removed — only the inner ImageThumbAdapter/
 *     FilteredThumbAdapter scopes existed; both are now no-ops with Glide.
 */
class ChapterAdapter(
    private val groups: List<ImageGroup>,
    private val onImageClick: (groupIdx: Int, imageIdx: Int) -> Unit,
    private val onGroupRemove: (groupIdx: Int) -> Unit,
    private val onGroupShare: (groupIdx: Int) -> Unit,
    private val onGroupRename: (groupIdx: Int) -> Unit,
    private val onImageLongClick: ((ImageItem) -> Unit)? = null,
    private val onImageRestore: ((ImageItem) -> Unit)? = null,
    private val onFilteredPreview: ((groupIdx: Int, filteredImageIdx: Int) -> Unit)? = null,
    private val onBatchRestore: ((groupIdx: Int) -> Unit)? = null,
    // ── Lazy dims decode hook ─────────────────────────────────────────────────
    // Called the first time a chapter is expanded (and every subsequent expand,
    // but decodeDimsForGroup() is idempotent: it bails immediately if all images
    // already have width > 0). This keeps BitmapFactory.decodeBounds() work
    // strictly on-demand — no library-wide IO burst at the 6-second mark.
    private val onGroupExpand: ((ImageGroup) -> Unit)? = null
) : RecyclerView.Adapter<ChapterAdapter.VH>() {

    private val expandedMain     = mutableSetOf<Long>()
    private val expandedFiltered = mutableSetOf<Long>()
    // Thumb adapters are NEVER destroyed on scroll — only on explicit remove/update.
    private val thumbAdapters    = mutableMapOf<Long, ImageThumbAdapter>()
    private val filteredAdapters = mutableMapOf<Long, FilteredThumbAdapter>()
    var touchHelper: ItemTouchHelper? = null

    // Shared RecycledViewPool — ViewHolder inflation cost amortised across all chapter grids.
    // RULE: only pool adapters with the SAME item layout (same ViewHolder class).
    //   sharedThumbPool     → ImageThumbAdapter (item_thumb / item_thumb_merge)
    //   sharedFilteredPool  → FilteredThumbAdapter (item_thumb_filtered)
    // Mixing pools across layout types causes ClassCastException at rebind time.
    private val sharedThumbPool = RecyclerView.RecycledViewPool().also {
        it.setMaxRecycledViews(0, 24)
    }
    // PERF: Separate pool for filtered grids — all FilteredThumbAdapter instances
    // inflate item_thumb_filtered and can share ViewHolders across chapters.
    // Without this, each chapter's filtered section has its own pool → full
    // ViewHolder inflation cost each time the section is expanded.
    private val sharedFilteredPool = RecyclerView.RecycledViewPool().also {
        it.setMaxRecycledViews(0, 12)
    }

    init { setHasStableIds(true) }
    override fun getItemId(position: Int): Long = groups[position].id

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val cover:           ImageView   = v.findViewById(R.id.chapter_cover)
        val numBadge:        TextView    = v.findViewById(R.id.chapter_num_badge)
        val name:            TextView    = v.findViewById(R.id.chapter_name)
        val count:           TextView    = v.findViewById(R.id.chapter_count)
        val filteredCount:   TextView    = v.findViewById(R.id.filtered_count)
        val arrow:           TextView    = v.findViewById(R.id.chapter_arrow)
        val removeBtn:       ImageButton = v.findViewById(R.id.chapter_remove)
        val renameBtn:       ImageButton = v.findViewById(R.id.chapter_rename)
        val shareBtn:        View        = v.findViewById(R.id.chapter_share)
        val dragHandle:      TextView    = v.findViewById(R.id.drag_handle)
        val header:          View        = v.findViewById(R.id.chapter_header)
        val grid:            RecyclerView= v.findViewById(R.id.chapter_grid)
        val filteredSection: View        = v.findViewById(R.id.filtered_section)
        val filteredHeader:  View        = v.findViewById(R.id.filtered_header)
        val filteredLabel:   TextView    = v.findViewById(R.id.filtered_section_label)
        val filteredArrow:   TextView    = v.findViewById(R.id.filtered_arrow)
        val filteredGrid:    RecyclerView= v.findViewById(R.id.filtered_grid)
        val btnRestoreAll:   Button      = v.findViewById(R.id.btn_restore_all)
        // No coverJob — Glide.with(view).clear(cover) in onViewRecycled instead
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_chapter, parent, false)
        val holder = VH(v)

        // ── PERF: All click/touch listeners registered ONCE at creation ────────
        //
        // BEFORE (original): Every onBindViewHolder call registered 6–8 new lambda
        // objects per VH — one for each setOnClickListener / setOnTouchListener.
        // For 50 groups: 300–400 new lambda allocations per adapter update().
        // These ~250 KB of short-lived objects trigger a minor GC at the exact
        // moment the post-extraction layout pass needs the frame budget: causing
        // the brief stutter visible right as the chapter list appears.
        //
        // AFTER: Zero listener allocations in onBindViewHolder.
        // Each lambda is created once per VH (≈ 8 total for the full list).
        //
        // bindingAdapterPosition is always fresh at interaction time — same safe
        // pattern already used by ImageThumbAdapter.onCreateViewHolder.

        holder.dragHandle.setOnTouchListener { _, event ->
            // Read mode at touch time (not bind time) — applyMode() can change it between binds.
            if (event.actionMasked == MotionEvent.ACTION_DOWN &&
                AppState.currentMode != AppMode.MERGE) {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_ID.toInt()) touchHelper?.startDrag(holder)
            }
            false
        }

        holder.removeBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRemove(pos)
        }

        holder.renameBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
        }

        holder.shareBtn.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupShare(pos)
        }

        holder.name.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onGroupRename(pos)
            true
        }

        holder.header.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups[pos]
            if (grp.id in expandedMain) {
                expandedMain.remove(grp.id)
                holder.grid.visibility = View.GONE
            } else {
                expandedMain.add(grp.id)
                // Trigger lazy dims decode for this group only. The callback is
                // idempotent — if dims are already decoded it returns in O(N) with
                // zero IO. Safe to call before attachMainGrid() since the decode
                // runs on decodeDispatcher and posts back to Main only when done.
                onGroupExpand?.invoke(grp)
                attachMainGrid(holder, pos, grp)
                holder.grid.visibility = View.VISIBLE
            }
            holder.arrow.text = if (grp.id in expandedMain) "▲" else "▼"
        }

        holder.filteredHeader.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_ID.toInt()) return@setOnClickListener
            val grp = groups[pos]
            if (grp.id in expandedFiltered) {
                expandedFiltered.remove(grp.id)
                filteredAdapters.remove(grp.id)?.destroy()
                holder.filteredGrid.adapter = null
                holder.filteredGrid.visibility = View.GONE
            } else {
                expandedFiltered.add(grp.id)
                attachFilteredGrid(holder, pos, grp)
                holder.filteredGrid.visibility = View.VISIBLE
            }
            holder.filteredArrow.text = if (grp.id in expandedFiltered) "▲" else "▼"
        }

        holder.btnRestoreAll.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onBatchRestore?.invoke(pos)
        }

        return holder
    }

    override fun getItemCount() = groups.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val group   = groups[position]
        val isMerge = AppState.currentMode == AppMode.MERGE
        val isExpanded = group.id in expandedMain

        // ── Number badge ──────────────────────────────────────────────────────
        holder.numBadge.text = "${position + 1}"

        // ── Cover thumbnail via Glide ─────────────────────────────────────────
        // PERF: PREFER_RGB_565 added to BOTH paths (was present only in the fallback).
        //   The primary path loaded the pre-built 140 px WebP with default ARGB_8888
        //   (4 bytes/pixel). Manga covers have no alpha channel; RGB_565 (2 bytes/pixel)
        //   is visually identical at 140 px and halves decoded bitmap memory:
        //     140×140 ARGB_8888 = ~78 KB  →  140×140 RGB_565 = ~39 KB
        //   For 50 visible cover rows: 50 × 39 KB = ~2 MB freed from Glide's LruCache,
        //   room for ~50 more thumbnails before eviction → fewer cache misses on scroll.
        val coverImg = group.displayImages.firstOrNull()
        if (coverImg != null) {
            val thumbFile = coverImg.thumbnailPath?.let { File(it) }
            if (thumbFile != null) {
                Glide.with(holder.itemView)
                    .load(thumbFile)
                    .override(140)
                    .format(DecodeFormat.PREFER_RGB_565)   // ADDED: was missing, saves ~39 KB/cover
                    .dontAnimate()
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(false)
                    .into(holder.cover)
            } else {
                Glide.with(holder.itemView)
                    .load(File(coverImg.filePath))
                    .override(140)
                    .format(DecodeFormat.PREFER_RGB_565)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .skipMemoryCache(false)
                    .dontAnimate()
                    .into(holder.cover)
            }
        } else {
            Glide.with(holder.itemView).clear(holder.cover)
        }

        // ── Name + count ──────────────────────────────────────────────────────
        holder.name.text = group.groupName

        if (isMerge) {
            val pairs = (group.displayImages.size + 1) / 2
            holder.count.text = "${group.displayImages.size} images · $pairs pairs"
            holder.dragHandle.visibility = View.GONE
            holder.filteredCount.visibility = View.GONE
            holder.filteredSection.visibility = View.GONE
            holder.removeBtn.visibility = if (groups.size > 1) View.VISIBLE else View.GONE
        } else {
            holder.dragHandle.visibility = View.VISIBLE
            holder.removeBtn.visibility  = View.VISIBLE
            holder.count.text = "${group.displayImages.size} images"
            val fCount = group.filteredImages.size
            holder.filteredCount.visibility = if (fCount > 0) View.VISIBLE else View.GONE
            if (fCount > 0) holder.filteredCount.text = "⚠ $fCount filtered"
        }

        holder.arrow.text = if (isExpanded) "▲" else "▼"

        // ── Drag handle — listener set in onCreateViewHolder; no setup here ────
        // ── Per-chapter actions — listeners set in onCreateViewHolder ──────────

        // ── Expand / collapse ─────────────────────────────────────────────────
        // Listener set in onCreateViewHolder. Only expand state applied here.
        if (isExpanded) {
            attachMainGrid(holder, position, group)
            holder.grid.visibility = View.VISIBLE
        } else {
            if (holder.grid.adapter !== thumbAdapters[group.id]) {
                holder.grid.adapter = null
            }
            holder.grid.visibility = View.GONE
        }

        // ── Filtered section ──────────────────────────────────────────────────
        if (!isMerge && group.filteredImages.isNotEmpty()) {
            holder.filteredSection.visibility = View.VISIBLE
            holder.filteredLabel.text = "${group.filteredImages.size} filtered — tap to review"
            holder.filteredArrow.text = if (group.id in expandedFiltered) "▲" else "▼"
            // Listeners (filteredHeader, btnRestoreAll) set in onCreateViewHolder.
            if (group.id in expandedFiltered) {
                attachFilteredGrid(holder, position, group)
                holder.filteredGrid.visibility = View.VISIBLE
            } else {
                holder.filteredGrid.visibility = View.GONE
            }
        } else {
            holder.filteredSection.visibility = View.GONE
        }
    }

    private fun attachMainGrid(holder: VH, position: Int, group: ImageGroup) {
        val isMerge = AppState.currentMode == AppMode.MERGE
        val items: List<Any> = if (isMerge) ImageMerger.pairImages(group.displayImages) else group.displayImages
        val cols = if (isMerge) 2 else 3
        val groupId = group.id

        val adapter = thumbAdapters.getOrPut(group.id) {
            // ── PERF: onItemClick captured ONCE at adapter creation ─────────────
            // BEFORE: adapter.onItemClick was reassigned AFTER getOrPut() on every
            // attachMainGrid() call — allocating a new lambda every onBindViewHolder
            // for each expanded chapter. For 50 expanded chapters that is 50 new
            // lambda objects per update() pass, adding ~25 KB of short-lived heap.
            //
            // AFTER: onItemClick is captured inside the getOrPut block, which runs
            // only when the adapter is first created. Subsequent attachMainGrid()
            // calls return the cached adapter without any allocation.
            // groupId is captured at adapter-creation time; groups.indexOfFirst()
            // at click-time resolves the correct position after any drag-reorder.
            ImageThumbAdapter(
                items, isMerge,
                group           = if (isMerge) group else null,
                groupIdx        = position,
                onItemClick     = { idx ->
                    val currentPos = groups.indexOfFirst { it.id == groupId }
                    if (currentPos != -1) onImageClick(currentPos, idx)
                },
                onItemLongClick = onImageLongClick,
                onSwapChanged   = null
            )
        }
        // NOTE: adapter.onItemClick NOT reassigned here — zero lambda allocation.

        if (holder.grid.layoutManager == null) {
            holder.grid.layoutManager = GridLayoutManager(holder.grid.context, cols).apply {
                initialPrefetchItemCount = cols * 4
            }
            holder.grid.overScrollMode = View.OVER_SCROLL_NEVER
            // Null animator: DefaultItemAnimator runs a ValueAnimator fade-in for
            // every one of the ~30 cells inflated on first expand — that's 30
            // simultaneous animators posting invalidate() every 16 ms for 300 ms
            // while Glide is also decoding 30 thumbnail files. Combined they
            // blow the 16 ms frame budget on every expand tap.
            // null = no DefaultItemAnimator, no alpha/translate, no ValueAnimator overhead.
            holder.grid.itemAnimator = null
            // NOTE: setHasFixedSize(true) omitted — both grids use wrap_content
            // height inside a vertical LinearLayout (they expand to fit thumbnail rows).
            // setHasFixedSize requires a fixed size in the scrolling direction;
            // Lint [InvalidSetHasFixedSize] correctly rejects it here.
        }
        holder.grid.setRecycledViewPool(sharedThumbPool)
        holder.grid.setItemViewCacheSize(12)
        if (holder.grid.adapter !== adapter) {
            holder.grid.adapter = adapter
        }
    }

    private fun attachFilteredGrid(holder: VH, position: Int, group: ImageGroup) {
        val groupId = group.id
        val adapter = filteredAdapters.getOrPut(group.id) {
            // ── PERF: onPreview captured ONCE at adapter creation ──────────────
            // Same pattern as attachMainGrid — prevents lambda re-allocation on
            // every onBindViewHolder for expanded filtered sections.
            FilteredThumbAdapter(
                initialItems = group.filteredImages,
                groupIdx  = position,
                onPreview = { filtIdx ->
                    val currentPos = groups.indexOfFirst { it.id == groupId }
                    if (currentPos != -1) onFilteredPreview?.invoke(currentPos, filtIdx)
                },
                onRestore = { img -> img.forceKeep = true; img.userDeleted = false; onImageRestore?.invoke(img) }
            )
        }
        // NOTE: adapter.onPreview NOT reassigned here — zero lambda allocation.

        if (holder.filteredGrid.layoutManager == null) {
            holder.filteredGrid.layoutManager = GridLayoutManager(holder.filteredGrid.context, 3).apply {
                initialPrefetchItemCount = 9
            }
            holder.filteredGrid.overScrollMode = View.OVER_SCROLL_NEVER
            holder.filteredGrid.itemAnimator = null
            // setHasFixedSize omitted — filtered grid also uses wrap_content height.
        }
        // ── PERF: Share filtered ViewHolder pool across all chapters ───────────
        // BEFORE: each chapter's filteredGrid used its own isolated RecycledViewPool
        // (RecyclerView default). When a filtered section collapsed and re-expanded,
        // its ViewHolder pool was already cleared (filteredAdapters.remove() in
        // filteredHeader click), forcing full VH inflation on every expand.
        //
        // AFTER: all FilteredThumbAdapter instances share sharedFilteredPool.
        // A VH recycled when chapter A's filtered section collapses is reused when
        // chapter B's section expands — saves the inflate + findViewById cost.
        holder.filteredGrid.setRecycledViewPool(sharedFilteredPool)
        holder.filteredGrid.setItemViewCacheSize(8)
        if (holder.filteredGrid.adapter !== adapter) {
            holder.filteredGrid.adapter = adapter
        }
    }

    private data class GroupSnapshot(val id: Long, val name: String, val displaySize: Int, val filteredSize: Int, val coverPath: String?)
    private var prevSnapshot: List<GroupSnapshot> = emptyList()

    fun destroyGroupAdapters(groupId: Long) {
        thumbAdapters.remove(groupId)?.destroy()
        filteredAdapters.remove(groupId)?.destroy()
    }

    suspend fun update() {
        val newGroups = AppState.groups
        val isMerge = AppState.currentMode == AppMode.MERGE
        newGroups.forEach { group ->
            thumbAdapters[group.id]?.let { adapter ->
                val newItems: List<Any> = if (isMerge)
                    ImageMerger.pairImages(group.displayImages)
                else
                    group.displayImages
                adapter.refreshItems(newItems)
            }
            filteredAdapters[group.id]?.refreshItems(group.filteredImages)
        }

        val newSnapshot = newGroups.map {
            GroupSnapshot(it.id, it.groupName, it.displayImages.size, it.filteredImages.size, it.displayImages.firstOrNull()?.filePath)
        }
        val oldSnapshot = prevSnapshot
        prevSnapshot = newSnapshot

        // ── DiffUtil off the Main thread ───────────────────────────────────
        // DiffUtil.calculateDiff() is O(N + D²) where D is the edit distance.
        // For 50–100 groups this is fast (~1 ms) BUT it runs synchronously on
        // whatever thread calls update(). update() was always called from Main,
        // so the diff blocked the Main thread for 1–5 ms at the exact moment the
        // RecyclerView was starting its post-extraction layout pass.
        //
        // withContext(Default) offloads the diff computation to the CPU pool.
        // dispatchUpdatesTo() is then called back on Main (the coroutine resumes
        // here because update() is a suspend fun called from a Main-thread coroutine
        // in refreshChapterList()). The net result: Main is free for layout during
        // the diff, and the adapter patch arrives one frame later — imperceptible.
        val diff = withContext(Dispatchers.Default) {
            DiffUtil.calculateDiff(object : DiffUtil.Callback() {
                override fun getOldListSize() = oldSnapshot.size
                override fun getNewListSize() = newSnapshot.size
                override fun areItemsTheSame(o: Int, n: Int) = oldSnapshot[o].id == newSnapshot[n].id
                override fun areContentsTheSame(o: Int, n: Int) = oldSnapshot[o] == newSnapshot[n]
            })
        }
        diff.dispatchUpdatesTo(this)
    }

    fun notifyImageDimsChanged(groupIdx: Int, displayIdx: Int) {
        val id = groups.getOrNull(groupIdx)?.id ?: return
        thumbAdapters[id]?.notifyItemChanged(displayIdx, ImageThumbAdapter.PAYLOAD_DIMS)
    }

    /**
     * Push an updated displayImages list into the inner ImageThumbAdapter for
     * the given group via AsyncListDiffer.submitList().
     *
     * This is the correct way to surface dimension changes.  The old
     * notifyImageDimsChanged() called notifyItemChanged(pos, PAYLOAD_DIMS) but
     * the differ's currentList was never refreshed, so onBindViewHolder always
     * read width=0 and the badge never appeared.
     *
     * submitList() diffs old vs new on a background thread and fires only the
     * targeted notifyItemChanged calls for items whose data actually changed.
     * The PAYLOAD_DIMS partial-bind path then runs correctly because
     * differ.currentList now contains the updated ImageItem with non-zero dims.
     */
    fun refreshGroupDisplayImages(group: com.mangatool.app.model.ImageGroup) {
        thumbAdapters[group.id]?.refreshItems(group.displayImages)
    }

    fun destroy() {
        // No adapter-level scope to cancel — Glide manages request lifecycle.
        thumbAdapters.values.forEach { it.destroy() }; thumbAdapters.clear()
        filteredAdapters.values.forEach { it.destroy() }; filteredAdapters.clear()
    }

    override fun onViewRecycled(holder: VH) {
        // Cancel any in-flight Glide request for the cover ImageView and return
        // the Bitmap to Glide's BitmapPool rather than letting it linger in the
        // VH until the next bind overwrites it.
        Glide.with(holder.itemView).clear(holder.cover)
        super.onViewRecycled(holder)
    }
}

// ── Filtered thumbnail adapter ─────────────────────────────────────────────────
class FilteredThumbAdapter(
    initialItems: List<ImageItem>,
    private val groupIdx: Int = 0,
    // PERF: val — set once at adapter creation in attachFilteredGrid, never reassigned.
    val onPreview: (Int) -> Unit,
    private val onRestore: (ImageItem) -> Unit
) : RecyclerView.Adapter<FilteredThumbAdapter.VH>() {

    companion object {
        // Filtered images are stable by originalIdx; content changes when filterReason
        // or filePath changes (edge case: restore-then-re-filter).
        val ITEM_CALLBACK = object : DiffUtil.ItemCallback<ImageItem>() {
            override fun areItemsTheSame(o: ImageItem, n: ImageItem) =
                o.originalIdx == n.originalIdx
            override fun areContentsTheSame(o: ImageItem, n: ImageItem) =
                o.filePath == n.filePath && o.filterReason == n.filterReason
        }
    }

    private val differ = AsyncListDiffer(this, ITEM_CALLBACK)
    private val items: List<ImageItem> get() = differ.currentList

    init { differ.submitList(initialItems) }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:   ImageView = v.findViewById(R.id.thumb_image)
        val reason:  TextView  = v.findViewById(R.id.reason_text)
        val preview: View      = v.findViewById(R.id.btn_preview)
        val restore: View      = v.findViewById(R.id.btn_restore)
        // No Job — Glide manages lifecycle
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_thumb_filtered, parent, false)
        val holder = VH(v)

        // ── PERF: Click listeners registered ONCE at VH creation ──────────────
        // BEFORE (v26): onBindViewHolder registered 3 new lambdas (itemView,
        // preview, restore) on EVERY bind — allocating ~3 objects × N filtered
        // items × M filter passes. For a library with 5 chapters × 8 filtered
        // images × 3 filter changes = 120 lambda allocations in one interaction,
        // adding GC pressure at the moment the adapter is refreshing.
        //
        // AFTER (v27): zero allocations in onBindViewHolder. The restore listener
        // reads items[bindingAdapterPosition] at click time — safe because
        // bindingAdapterPosition always reflects the current differ state.
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.preview.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onPreview(pos)
        }
        holder.restore.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onRestore(items[pos])
        }

        return holder
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val img = items[position]
        holder.reason.text = img.filterReason ?: "Filtered"

        // v21: load pre-generated thumbnail instead of original image.
        // thumbnailPath null-safe: falls back to filePath with RESOURCE cache.
        //
        // v27: PREFER_RGB_565 added to fast path (was missing).
        // FilteredThumbAdapter thumbnails are the same pre-built 140 px WebP
        // files as the main grid — opaque manga pages with no alpha channel.
        // Saves ~39 KB per filtered thumbnail in Glide's LruCache (same fix
        // already applied to ImageThumbAdapter and ChapterAdapter cover row).
        val thumbFile = img.thumbnailPath?.let { File(it) }
        if (thumbFile != null) {
            Glide.with(holder.itemView)
                .load(thumbFile)
                .override(140)
                .format(DecodeFormat.PREFER_RGB_565)   // v27: was missing on this path
                .dontAnimate()
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(false)
                .into(holder.image)
        } else {
            Glide.with(holder.itemView)
                .load(File(img.filePath))
                .override(140)
                .format(DecodeFormat.PREFER_RGB_565)
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .skipMemoryCache(false)
                .dontAnimate()
                .into(holder.image)
        }
        // Click listeners registered once in onCreateViewHolder — no allocations here.
    }

    /**
     * Submit updated filtered list to AsyncListDiffer.
     * Only items whose filterReason or filePath changed will rebind —
     * a restore action on item N no longer forces all other filtered
     * thumbnails to re-issue their Glide requests.
     */
    fun refreshItems(newItems: List<ImageItem>) = differ.submitList(newItems)

    override fun onViewRecycled(holder: VH) {
        Glide.with(holder.itemView).clear(holder.image)
        super.onViewRecycled(holder)
    }

    /** No-op: Glide manages request lifecycle. */
    fun destroy() = Unit
}
