package com.mgba.android

import android.Manifest
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var loadRomBtn:  Button
    private lateinit var linkBtn:     TextView
    private lateinit var settingsBtn: TextView
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    private var frameBitmap: Bitmap? = null
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    private val buttons     = mutableListOf<ButtonDef>()
    private var controlsTop = 0f
    @Volatile private var pickerLive = false
    private lateinit var link: LinkMultiplayer

    // ── Fast-forward state ────────────────────────────────────────────────────
    @Volatile private var fastForwardSpeed  = 2.0f   // speed multiplier set in ⚙ Settings (e.g. 2 = 2×)
    @Volatile private var fastForwardActive = false   // toggled only by tapping ⏩ on the game screen
    private var ffBtnRect  = RectF()
    private var ffFrameAccumulator = 0.0              // game-thread only; fractional GBA-frame carry for FF

    // ── Fullscreen / overlay mode ──────────────────────────────────────────────
    @Volatile private var fullscreenMode = false
    private var fsBtnRect = RectF()

    // ── Audio ─────────────────────────────────────────────────────────────────
    @Volatile private var audioTrack: AudioTrack? = null
    private val audioBuffer = ShortArray(2048)        // 1024 stereo pairs per call

    companion object {
        private const val TAG             = "mGBA"
        private const val GAME_FRAC_NORM  = 0.52f    // game takes top 52 % in normal mode
        private const val CTRL_FRAC_FULL  = 0.60f    // controls start at 60 % in fullscreen
    }

    private data class ButtonDef(val rect: RectF, val keyMask: Int, val label: String, val color: Int)

    // ── ROM picker ────────────────────────────────────────────────────────────

    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        Thread {
            try {
                val tmp = cacheDir.resolve("rom_loaded.gba")
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                } ?: run { uiToast("Cannot read selected file"); return@Thread }
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath)
                Handler(Looper.getMainLooper()).post {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth()
                        val h = EmulatorEngine.nativeGetHeight()
                        frameBitmap = Bitmap.createBitmap(
                            w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        romLoaded = true
                        loadRomBtn.visibility = View.GONE
                        linkBtn.visibility    = View.VISIBLE
                        initAudioTrack()
                        startGameLoop()
                    } else { uiToast("Unsupported ROM format") }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        link = LinkMultiplayer(this)
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        loadRomBtn = Button(this).apply {
            text = "▶  Load ROM"
            setBackgroundColor(Color.parseColor("#BB86FC"))
            setTextColor(Color.BLACK); textSize = 16f
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(loadRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.CENTER })
        linkBtn = TextView(this).apply {
            text = "🔗 Link"; textSize = 13f
            setTextColor(Color.WHITE); setPadding(20, 10, 20, 10)
            setBackgroundColor(Color.parseColor("#44000000"))
            visibility = View.GONE
            setOnClickListener { showLinkDialog() }
        }
        root.addView(linkBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 8 })
        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            setBackgroundColor(Color.parseColor("#44000000"))
            setOnClickListener { showSettingsDialog() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.START; it.topMargin = 8; it.leftMargin = 8 })
        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // ── Audio ─────────────────────────────────────────────────────────────────

    private fun initAudioTrack() {
        releaseAudio()
        val minBuf = AudioTrack.getMinBufferSize(
            44100,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
        Log.d(TAG, "AudioTrack started (minBuf=$minBuf)")
    }

    private fun releaseAudio() {
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null
    }

    // ── Surface ───────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) { updateGameMatrix(w.toFloat(), h.toFloat()); if (!running) startGameLoop() }
    }

    // ── Game loop ─────────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bmp = frameBitmap ?: return
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) { buildControlLayout(sw, sh); updateGameMatrix(sw, sh) }
        running = true
        ffFrameAccumulator = 0.0
        gameThread = Thread {
            while (running) {
                try {
                    val t0 = System.nanoTime()
                    val speed = if (fastForwardActive) fastForwardSpeed else 1f

                    // ── How many GBA frames to simulate THIS iteration ──────────────
                    // Each loop iteration is naturally capped at ~60Hz by lockCanvas()
                    // inside renderFrame() waiting for the display's vsync — so simply
                    // shrinking the end-of-loop sleep (the old approach) had no effect
                    // once that sleep already hit zero. To actually go faster than
                    // real-time we must simulate MULTIPLE emulated frames for every
                    // ONE frame we render to the screen ("frame skipping").
                    // A fractional accumulator keeps non-integer speeds (1.5×, 4.5×…)
                    // accurate on average across iterations.
                    val framesToRun: Int
                    if (fastForwardActive) {
                        ffFrameAccumulator += speed
                        framesToRun = ffFrameAccumulator.toInt().coerceAtLeast(1)
                        ffFrameAccumulator -= framesToRun
                    } else {
                        framesToRun = 1
                        ffFrameAccumulator = 0.0
                    }

                    EmulatorEngine.nativeSetKeys(currentKeys.get())
                    for (i in 0 until framesToRun) {
                        EmulatorEngine.nativeRunFrame(bmp)

                        // Drain audio every simulated frame so the blip buffer never
                        // overflows, but only ever WRITE it out at Normal (1×) speed —
                        // fast-forward stays silent at any multiplier.
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        if (n > 0 && !fastForwardActive) {
                            audioTrack?.write(audioBuffer, 0, n * 2, AudioTrack.WRITE_NON_BLOCKING)
                        }
                    }

                    renderFrame(bmp)

                    if (!fastForwardActive) {
                        // Normal speed: pace to ~60fps. (Fast-forward intentionally
                        // skips this — the loop just runs as fast as rendering allows,
                        // simulating `framesToRun` GBA frames each time through.)
                        val targetNs = (1_000_000_000.0 / 60.0).toLong()
                        val elapsed = System.nanoTime() - t0
                        val sleepMs = (targetNs - elapsed) / 1_000_000L
                        if (sleepMs > 0L) Thread.sleep(sleepMs)
                    }
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        gameThread?.join(500)
        gameThread = null
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try { holder.lockCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
            if (fastForwardActive) drawFfOverlay(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Game matrix ───────────────────────────────────────────────────────────

    /**
     * In normal mode the game fills the top [GAME_FRAC_NORM] of the surface.
     * In fullscreen mode the game scales to fill the ENTIRE surface.
     */
    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp    = frameBitmap ?: return
        val gameH  = if (fullscreenMode) sh else sh * GAME_FRAC_NORM
        val scale  = minOf(sw / bmp.width, gameH / bmp.height)
        gameMatrix.reset()
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(
            (sw - bmp.width  * scale) / 2f,
            (gameH - bmp.height * scale) / 2f
        )
    }

    // ── Controls layout ───────────────────────────────────────────────────────

    /**
     * Builds the on-screen button rects.
     *
     * Normal mode  : controls occupy the bottom strip (below GAME_FRAC_NORM).
     * Fullscreen   : game fills the whole screen; controls float in the bottom
     *                strip starting at CTRL_FRAC_FULL as a transparent overlay.
     */
    private fun buildControlLayout(sw: Float, sh: Float) {
        buttons.clear()
        controlsTop = sh * (if (fullscreenMode) CTRL_FRAC_FULL else GAME_FRAC_NORM)
        val padH = sh - controlsTop

        val btnSz  = minOf(padH * 0.24f, sw * 0.084f)
        val abSz   = btnSz * 0.94f
        val step   = btnSz * 1.1f

        // ── D-pad (left side) ────────────────────────────────────────────────
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        fun pad(dx: Float, dy: Float, m: Int, l: String) = ButtonDef(
            RectF(dpCx+dx-btnSz/2, dpCy+dy-btnSz/2, dpCx+dx+btnSz/2, dpCy+dy+btnSz/2),
            m, l, Color.parseColor("#555566"))
        buttons += pad(0f, -step, EmulatorEngine.KEY_UP,    "▲")
        buttons += pad(0f, +step, EmulatorEngine.KEY_DOWN,  "▼")
        buttons += pad(-step, 0f, EmulatorEngine.KEY_LEFT,  "◀")
        buttons += pad(+step, 0f, EmulatorEngine.KEY_RIGHT, "▶")

        // ── A / B (right side) ───────────────────────────────────────────────
        val abCx  = sw * 0.82f
        val abCy  = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        buttons += ButtonDef(RectF(abCx+abGap-abSz/2, abCy-abSz/2, abCx+abGap+abSz/2, abCy+abSz/2),
            EmulatorEngine.KEY_A, "A", Color.parseColor("#CF6679"))
        buttons += ButtonDef(RectF(abCx-abGap-abSz/2, abCy-abSz/2, abCx-abGap+abSz/2, abCy+abSz/2),
            EmulatorEngine.KEY_B, "B", Color.parseColor("#4FC3F7"))

        // ── Select / Start (centre) ───────────────────────────────────────────
        val ssW   = sw * 0.11f; val ssH = sh * 0.038f
        val ssCy  = controlsTop + padH * 0.82f
        val ssGap = sw * 0.07f
        buttons += ButtonDef(RectF(sw/2f-ssGap-ssW, ssCy, sw/2f-ssGap,    ssCy+ssH),
            EmulatorEngine.KEY_SELECT, "SEL", Color.parseColor("#444455"))
        buttons += ButtonDef(RectF(sw/2f+ssGap,     ssCy, sw/2f+ssGap+ssW, ssCy+ssH),
            EmulatorEngine.KEY_START,  "STA", Color.parseColor("#444455"))

        // ── L / R shoulder buttons ────────────────────────────────────────────
        val lrW = sw * 0.13f; val lrH = sh * 0.042f
        val lrY = controlsTop + padH * 0.06f
        buttons += ButtonDef(RectF(sw*0.03f,          lrY, sw*0.03f+lrW,       lrY+lrH),
            EmulatorEngine.KEY_L, "L", Color.parseColor("#444455"))
        buttons += ButtonDef(RectF(sw-sw*0.03f-lrW,   lrY, sw-sw*0.03f,        lrY+lrH),
            EmulatorEngine.KEY_R, "R", Color.parseColor("#444455"))

        // ── ⏩ Fast-forward  &  ⛶ Fullscreen (utility row above SEL/STA) ────
        val utilH = (ssH * 0.85f).coerceAtLeast(18f)
        val utilW = sw * 0.10f
        val utilY = ssCy - utilH - sh * 0.012f
        val utilGap = sw * 0.055f
        ffBtnRect = RectF(sw/2f - utilGap - utilW, utilY, sw/2f - utilGap,        utilY + utilH)
        fsBtnRect = RectF(sw/2f + utilGap,          utilY, sw/2f + utilGap + utilW, utilY + utilH)
    }

    // ── Draw controls ─────────────────────────────────────────────────────────

    private val fillPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return

        // Dark background only in normal mode; fullscreen controls are transparent overlay
        if (!fullscreenMode) {
            fillPaint.color = Color.parseColor("#CC111122")
            canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), fillPaint)
        }

        val keys      = currentKeys.get()
        val idleAlpha = if (fullscreenMode) 110 else 140
        val pressAlpha = if (fullscreenMode) 210 else 220

        for (btn in buttons) {
            fillPaint.color = btn.color
            fillPaint.alpha = if (keys and btn.keyMask != 0) pressAlpha else idleAlpha
            canvas.drawRoundRect(btn.rect, 12f, 12f, fillPaint)
            labelPaint.textSize = (btn.rect.height() * 0.46f).coerceAtLeast(14f)
            canvas.drawText(
                btn.label,
                btn.rect.centerX(),
                btn.rect.centerY() + labelPaint.textSize * 0.36f,
                labelPaint
            )
        }

        // ── ⏩ Fast-forward button ─────────────────────────────────────────────
        fillPaint.color = if (fastForwardActive) Color.parseColor("#CC7700") else Color.parseColor("#333344")
        fillPaint.alpha = 180
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
        labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
        val ffLabel = if (fastForwardActive) "⏩${formatSpeed(fastForwardSpeed)}×" else "⏩"
        canvas.drawText(ffLabel, ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)

        // ── ⛶ Fullscreen button ───────────────────────────────────────────────
        fillPaint.color = if (fullscreenMode) Color.parseColor("#0055AA") else Color.parseColor("#333344")
        fillPaint.alpha = 180
        canvas.drawRoundRect(fsBtnRect, 8f, 8f, fillPaint)
        labelPaint.textSize = (fsBtnRect.height() * 0.52f).coerceAtLeast(12f)
        canvas.drawText(
            if (fullscreenMode) "⊠" else "⛶",
            fsBtnRect.centerX(), fsBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint
        )
    }

    /** Small HUD overlay in the top-left corner when fast-forward is active */
    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00"); textSize = 28f; isFakeBoldText = true
    }
    private fun drawFfOverlay(canvas: Canvas) {
        canvas.drawText("⏩ ${formatSpeed(fastForwardSpeed)}×", 14f, 36f, hudPaint)
    }

    private fun formatSpeed(s: Float): String =
        if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)

    // ── Touch handling ────────────────────────────────────────────────────────

    private fun onGameTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y

                // ⏩ — plain tap toggles between Normal (1×) and the speed set in ⚙ Settings
                if (ffBtnRect.contains(x, y)) {
                    fastForwardActive = !fastForwardActive
                    return
                }
                // ⛶ — toggle fullscreen immediately on DOWN for snappy feel
                if (fsBtnRect.contains(x, y)) {
                    toggleFullscreen()
                    return
                }
                updateGameKeys(event)
            }

            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> updateGameKeys(event)

            MotionEvent.ACTION_UP -> {
                if (ffBtnRect.contains(event.x, event.y) || fsBtnRect.contains(event.x, event.y)) return
                currentKeys.set(0)
            }

            MotionEvent.ACTION_POINTER_UP -> updateGameKeys(event)
            else                          -> currentKeys.set(0)
        }
    }

    private fun updateGameKeys(event: MotionEvent) {
        var keys = 0
        for (i in 0 until event.pointerCount) {
            val x = event.getX(i); val y = event.getY(i)
            for (btn in buttons) if (btn.rect.contains(x, y)) keys = keys or btn.keyMask
        }
        currentKeys.set(keys)
    }

    // ── Settings dialog ───────────────────────────────────────────────────────

    /**
     * ⚙ Settings — currently just the fast-forward speed.
     * This only stores the chosen multiplier; it does NOT toggle fast-forward
     * on/off. The ⏩ button on the game screen is the only thing that toggles
     * between Normal (1×) and this configured speed.
     */
    private fun showSettingsDialog() {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatSpeed(fastForwardSpeed))
            hint = "e.g. 1.5, 2, 4, 4.5"
            selectAll()
            setPadding(48, 24, 48, 24)
        }
        AlertDialog.Builder(this)
            .setTitle("⚙ Settings")
            .setMessage("Fast-forward speed (0.5 – 16×).\nTap ⏩ on the game screen to switch between Normal and this speed. Audio is muted while fast-forwarding.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val v = et.text.toString().toFloatOrNull()
                when {
                    v == null           -> uiToast("Enter a number like 2 or 4.5")
                    v < 0.5f || v > 16f  -> uiToast("Speed must be between 0.5 and 16")
                    else                 -> { fastForwardSpeed = v; uiToast("Fast-forward speed set to ${formatSpeed(v)}×") }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Fullscreen toggle ─────────────────────────────────────────────────────

    /**
     * Toggle between:
     *   Normal     — game in top 52 %, opaque controls panel below.
     *   Fullscreen — game fills entire screen, semi-transparent controls overlay.
     */
    private fun toggleFullscreen() {
        fullscreenMode = !fullscreenMode
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) {
            buildControlLayout(sw, sh)
            updateGameMatrix(sw, sh)
        }
    }

    // ── Link cable UI ─────────────────────────────────────────────────────────

    private fun showLinkDialog() {
        if (link.isConnected) {
            AlertDialog.Builder(this).setTitle("Link Connected ✓")
                .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("GBA Link Cable")
            .setItems(arrayOf("Host — Wi-Fi", "Join — Wi-Fi",
                               "Host — Bluetooth", "Join — Bluetooth")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady      = { ip -> uiToast("Waiting…\nIP: $ip"); updateLinkBtn("⏳ Hosting…") },
                        onConnected  = { onLinkConnected(true,  "Wi-Fi") },
                        onError      = { uiToast("Host error: $it"); updateLinkBtn("🔗 Link") })
                    1 -> { updateLinkBtn("🔗 Scanning…")
                           link.discoverWifiHosts(
                               onFound = { hosts ->
                                   if (hosts.isEmpty()) showIpDialog()
                                   else AlertDialog.Builder(this)
                                       .setTitle("Select host")
                                       .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                       .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show() },
                               onError = { showIpDialog() }) }
                    2 -> { updateLinkBtn("⏳ BT Host…")
                           link.startBluetoothHost(
                               onConnected = { onLinkConnected(true,  "Bluetooth") },
                               onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") }) }
                    3 -> { val devs = link.getBondedDevices()
                           if (devs.isEmpty()) { uiToast("No paired devices"); return@setItems }
                           AlertDialog.Builder(this).setTitle("Choose device")
                               .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                   updateLinkBtn("⏳ BT…")
                                   link.connectBluetooth(devs[j],
                                       onConnected = { onLinkConnected(false, "Bluetooth") },
                                       onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") })
                               }.show() }
                }
            }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        updateLinkBtn("⏳ Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it"); updateLinkBtn("🔗 Link") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        updateLinkBtn("🔗 $via ✓")
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        updateLinkBtn("🔗 Link"); uiToast("Disconnected")
    }

    private fun updateLinkBtn(t: String) = Handler(Looper.getMainLooper()).post { linkBtn.text = t }

    // ── Link status overlay ───────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun uiToast(msg: String) =
        Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
