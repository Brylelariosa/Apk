package com.gary.voidsurvivors

import android.content.Context
import android.content.SharedPreferences
import android.graphics.*
import android.os.*
import android.view.*
import kotlin.math.*
import kotlin.random.Random

// ─── Persistent settings ────────────────────────────────────────

data class GameSettings(
    var sfxVolume:    Float   = 0.75f,
    var musicVolume:  Float   = 0.40f,
    var vibration:    Boolean = true,
    var hudScale:     Float   = 1.0f,
    var quality:      Int     = 2,       // 1=Low 2=Med 3=High
    var joystickLeft: Boolean = true,
    var showFps:      Boolean = false
)

class AchievementToast(val name: String, var life: Float = 3.5f, val maxLife: Float = 3.5f)

enum class TutorialStep { MOVE, SHOOT_AUTO, COLLECT_XP, LEVEL_UP_INFO, ABILITIES, DONE }

// ════════════════════════════════════════════════════════════════
//  GameView
// ════════════════════════════════════════════════════════════════

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    // ─── State ───────────────────────────────────────────────────
    private var worldW = 1920f; private var worldH = 1080f
    private val state  = GameState(worldW, worldH)
    private val meta   = MetaUpgrades()

    // ─── Settings ────────────────────────────────────────────────
    private val settings = GameSettings()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("vs_prefs_v5", Context.MODE_PRIVATE)

    // ─── Thread ──────────────────────────────────────────────────
    private var gameThread: Thread? = null
    @Volatile private var running = false
    private var lastTime = 0L

    // ─── Input ───────────────────────────────────────────────────
    private var moveX = 0f; private var moveY = 0f
    private var joyActive = false
    private var joyBaseX = 0f; private var joyBaseY = 0f
    private var joyDx = 0f; private var joyDy = 0f
    private val joyRadius = 120f
    private var joyPid = -1

    // 3 ability slot buttons
    private data class AbilityBtn(val cx: Float, val cy: Float, val r: Float, val slotIdx: Int,
                                  var pressScale: Float = 1f)
    private val abilityBtns = mutableListOf<AbilityBtn>()

    // ─── Overlays ────────────────────────────────────────────────
    private val toasts         = mutableListOf<AchievementToast>()
    private var tutorialStep   = TutorialStep.DONE
    private var tutorialTimer  = 0f
    private var tutorialShown  = false
    private var selectedCharIdx = 0
    private var runEndSaved    = false
    private var cardScales     = floatArrayOf(1f, 1f, 1f)

    // ─── FPS ─────────────────────────────────────────────────────
    private var fpsTimer = 0f; private var fpsCount = 0; private var fpsDisplay = 0

    // ─── Vibrator ────────────────────────────────────────────────
    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    // ─── Paint objects (reused, never recreated in loop) ────────
    private val pFill  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pStroke= Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pText  = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pShade = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    // (particle rendering uses per-circle draw for quality flexibility)
    private val rng    = Random.Default

    // ─── Starfield ───────────────────────────────────────────────
    private data class Star(val x: Float, val y: Float, val r: Float,
                            val bright: Float, val speed: Float)
    private val stars  = mutableListOf<Star>()
    private var bgOff  = 0f

    // ─── Init ────────────────────────────────────────────────────
    init {
        holder.addCallback(this)
        isFocusable = true
        loadSettings(); loadMeta()
        SoundManager.sfxVolume   = settings.sfxVolume
        SoundManager.musicVolume = settings.musicVolume
        SoundManager.init()
    }

    private fun makeStars() {
        stars.clear()
        repeat(160) {
            stars += Star(rng.nextFloat()*worldW, rng.nextFloat()*worldH,
                0.8f + rng.nextFloat()*2f, 0.3f + rng.nextFloat()*0.7f,
                6f + rng.nextFloat()*18f)
        }
    }

    // ─── Surface ─────────────────────────────────────────────────
    override fun surfaceCreated(h: SurfaceHolder) {
        running = true; lastTime = System.nanoTime()
        gameThread = Thread(::loop, "GameLoop").also { it.start() }
    }

    override fun surfaceChanged(h: SurfaceHolder, fmt: Int, w: Int, h2: Int) {
        worldW = w.toFloat(); worldH = h2.toFloat()
        state.worldW = worldW; state.worldH = worldH
        makeStars(); layoutAbilityButtons()
        GameLogic.reset(state, meta); state.phase = Phase.CHARACTER_SELECT
        if (!prefs.getBoolean("tutorial_done", false)) tutorialShown = true
    }

    override fun surfaceDestroyed(h: SurfaceHolder) { running = false }

    fun onPause()  { running = false }
    fun onStop()   { running = false; SoundManager.release() }
    fun onResume() {
        if (holder.surface.isValid && !running) {
            running = true; lastTime = System.nanoTime()
            gameThread = Thread(::loop, "GameLoop").also { it.start() }
        }
    }

    // ─── Game loop ───────────────────────────────────────────────
    private fun loop() {
        while (running) {
            val now = System.nanoTime()
            val dt  = ((now - lastTime) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            lastTime = now

            update(dt)

            val canvas = try { holder.lockCanvas() } catch (_: Exception) { null } ?: continue
            try { drawAll(canvas, dt) } finally { holder.unlockCanvasAndPost(canvas) }

            // Cap frame rate based on quality to reduce CPU/battery on low-end devices
            val budget = when (settings.quality) { 1 -> 40L; 3 -> 14L; else -> 20L }
            val spent  = (System.nanoTime() - now) / 1_000_000L
            if (spent < budget) Thread.sleep(budget - spent)
        }
    }

    // ─── Update ──────────────────────────────────────────────────
    private fun update(dt: Float) {
        fpsTimer += dt; fpsCount++
        if (fpsTimer >= 1f) { fpsDisplay = fpsCount; fpsCount = 0; fpsTimer = 0f }
        bgOff = (bgOff + dt * 14f) % worldH

        if (state.phase != Phase.PLAYING) return

        GameLogic.update(state, dt, moveX, moveY)
        GameLogic.checkAchievements(state, meta)

        while (state.pendingAchievements.isNotEmpty()) {
            toasts += AchievementToast(state.pendingAchievements.removeAt(0))
            vibrate(40L)
        }
        if (state.phase == Phase.LEVEL_UP) SoundManager.onLevelUp()
        if (state.phase == Phase.DEAD && !runEndSaved) {
            runEndSaved = true; onRunEnd(); vibrate(200L)
        }
        if (tutorialShown) updateTutorial(dt)

        val iter = toasts.iterator()
        while (iter.hasNext()) { val t = iter.next(); t.life -= dt; if (t.life <= 0f) iter.remove() }
    }

    private fun onRunEnd() {
        meta.currency           += state.runCurrency
        meta.totalBossKills     += state.stats.bossesKilled
        meta.totalStatusApplied += state.stats.statusApplied
        meta.totalRuns++
        if (state.wave         > meta.bestWave) meta.bestWave = state.wave
        if (state.elapsed.toInt() > meta.bestTime) meta.bestTime = state.elapsed.toInt()
        saveMeta()
    }

    private fun updateTutorial(dt: Float) {
        tutorialTimer -= dt
        val p = state.player
        val step = when {
            state.elapsed < 4f  && !p.isMoving         -> TutorialStep.MOVE
            state.elapsed < 8f                          -> TutorialStep.SHOOT_AUTO
            state.elapsed < 14f && state.orbs.size < 3  -> TutorialStep.COLLECT_XP
            state.phase == Phase.LEVEL_UP               -> TutorialStep.LEVEL_UP_INFO
            state.activeSlots.isNotEmpty()              -> TutorialStep.ABILITIES
            else                                        -> TutorialStep.DONE
        }
        if (step != tutorialStep) { tutorialStep = step; tutorialTimer = 4f }
        if (step == TutorialStep.DONE) {
            prefs.edit().putBoolean("tutorial_done", true).apply()
            tutorialShown = false
        }
    }

    // ─── Button layout ───────────────────────────────────────────
    private fun layoutAbilityButtons() {
        abilityBtns.clear()
        val hs   = settings.hudScale
        val sz   = 76f * hs
        val gap  = 14f * hs
        val side = if (settings.joystickLeft) worldW - sz / 2f - 24f * hs
                   else sz / 2f + 24f * hs
        val totalH = 3 * sz + 2 * gap
        val startY = worldH / 2f - totalH / 2f + sz / 2f
        repeat(3) { i ->
            abilityBtns += AbilityBtn(side, startY + i * (sz + gap), sz / 2f, i)
        }
    }

    // ─── Touch ───────────────────────────────────────────────────
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val action = ev.actionMasked
        val ai     = ev.actionIndex
        val pid    = ev.getPointerId(ai)
        val rx     = ev.getX(ai)
        val ry     = ev.getY(ai)

        when (state.phase) {
            Phase.SETTINGS         -> { handleSettingsTouch(action, rx, ry); return true }
            Phase.CHARACTER_SELECT -> { handleCharSelectTouch(action, rx, ry); return true }
            Phase.DEAD             -> { handleDeadTouch(action, rx, ry); return true }
            Phase.PAUSED           -> { handlePauseTouch(action, rx, ry); return true }
            Phase.LEVEL_UP         -> { handleLevelUpTouch(action, rx, ry); return true }
            Phase.ABILITY_SWAP     -> { handleAbilitySwapTouch(action, rx, ry); return true }
            Phase.PLAYING          -> { /* handled below */ }
        }

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val joyLeft  = settings.joystickLeft && rx < worldW * 0.5f
                val joyRight = !settings.joystickLeft && rx > worldW * 0.5f
                if ((joyLeft || joyRight) && !joyActive) {
                    joyBaseX = rx; joyBaseY = ry; joyDx = 0f; joyDy = 0f
                    joyActive = true; joyPid = pid
                } else {
                    // Ability buttons
                    for (btn in abilityBtns) {
                        val dx = rx - btn.cx; val dy = ry - btn.cy
                        if (sqrt(dx * dx + dy * dy) <= btn.r + 22f) {
                            val abilityId = state.activeSlots.getOrNull(btn.slotIdx) ?: continue
                            GameLogic.activateAbility(state, abilityId, moveX, moveY)
                            btn.pressScale = 0.82f
                            SoundManager.onAbility(); vibrate(15L)
                            break
                        }
                    }
                    // Pause
                    if (rx > worldW - 100f && ry < 80f) {
                        state.phase = Phase.PAUSED; SoundManager.onUiClick()
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) {
                    if (ev.getPointerId(i) == joyPid) {
                        joyDx = ev.getX(i) - joyBaseX; joyDy = ev.getY(i) - joyBaseY
                        val len = sqrt(joyDx * joyDx + joyDy * joyDy)
                        if (len > joyRadius) { joyDx = joyDx / len * joyRadius; joyDy = joyDy / len * joyRadius }
                        moveX = joyDx / joyRadius; moveY = joyDy / joyRadius
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (pid == joyPid) {
                    joyActive = false; joyPid = -1
                    moveX = 0f; moveY = 0f; joyDx = 0f; joyDy = 0f
                }
            }
        }
        return true
    }

    private fun handleLevelUpTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val ups = state.pendingUpgrades; if (ups.isEmpty()) return
        val cx = worldW / 2f
        val cardW = worldW * 0.72f; val cardH = worldH * 0.60f / ups.size - 12f
        val startY = worldH * 0.22f; val gap = cardH + 12f
        for ((i, up) in ups.withIndex()) {
            val top = startY + i * gap
            if (ry in top..(top + cardH) && rx in (cx - cardW/2)..(cx + cardW/2)) {
                cardScales[i] = 0.90f
                GameLogic.applyUpgrade(state, up)
                SoundManager.onUiClick(); vibrate(20L); return
            }
        }
    }

    private fun handlePauseTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx = worldW / 2f; val bw = 300f; val bh = 72f
        if (inBtn(rx, ry, cx, worldH*0.42f, bw, bh)) { state.phase = Phase.PLAYING; SoundManager.onUiClick() }
        if (inBtn(rx, ry, cx, worldH*0.55f, bw, bh)) { state.phase = Phase.SETTINGS; SoundManager.onUiClick() }
        if (inBtn(rx, ry, cx, worldH*0.68f, bw, bh)) { state.phase = Phase.DEAD; SoundManager.onUiClick() }
    }

    private fun handleDeadTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx = worldW / 2f; val bw = 340f; val bh = 72f
        if (inBtn(rx, ry, cx, worldH*0.82f, bw, bh)) {
            SoundManager.onUiClick(); runEndSaved = false; GameLogic.reset(state, meta)
        }
        if (inBtn(rx, ry, cx, worldH*0.91f, bw, bh)) {
            SoundManager.onUiClick(); runEndSaved = false; state.phase = Phase.CHARACTER_SELECT
        }
    }

    private fun handleAbilitySwapTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx  = worldW / 2f; val cardW = worldW * 0.55f; val cardH = worldH * 0.18f
        val gap = 14f; val startY = worldH * 0.38f
        for (i in 0..2) {
            val top = startY + i * (cardH + gap)
            if (ry in top..(top + cardH) && rx in (cx - cardW/2)..(cx + cardW/2)) {
                GameLogic.confirmAbilitySwap(state, i)
                SoundManager.onUiClick(); vibrate(20L); return
            }
        }
        // Cancel (keep current abilities, discard new one)
        if (ry > worldH * 0.88f) {
            state.pendingSwapAbility = null; state.phase = Phase.PLAYING
            SoundManager.onUiClick()
        }
    }

    private fun handleCharSelectTouch(action: Int, rx: Float, ry: Float) {
        if (action != MotionEvent.ACTION_DOWN) return
        val cx = worldW / 2f
        val cardW = worldW * 0.55f; val cardH = worldH * 0.15f
        val startY = worldH * 0.18f; val gap = cardH + 10f

        for ((i, def) in Characters.ALL.withIndex()) {
            val top = startY + i * gap
            if (ry !in top..(top + cardH) || rx !in (cx - cardW/2)..(cx + cardW/2)) continue
            if (meta.isCharUnlocked(def.type)) {
                selectedCharIdx = i; meta.selectedCharacter = def.type
                SoundManager.onUiClick()
            } else if (meta.currency >= def.unlockCost) {
                // Spend coins to unlock
                meta.currency -= def.unlockCost
                meta.unlockChar(def.type)
                selectedCharIdx = i; meta.selectedCharacter = def.type
                SoundManager.onLevelUp(); vibrate(60L); saveMeta()
            }
            return
        }

        // Permanent upgrade purchase buttons
        val metaY = startY + Characters.ALL.size * gap + 8f
        val metaCardH = worldH * 0.14f; val btnW = worldW * 0.11f; val btnH = metaCardH * 0.55f
        for (i in 0..3) {
            val bx = cx - worldW * 0.24f + i * (btnW + 10f); val by = metaY + metaCardH * 0.25f
            if (ry in by..(by + btnH) && rx in bx..(bx + btnW)) {
                when (i) {
                    0 -> if (meta.currency >= meta.costHp())    { meta.currency -= meta.costHp();    meta.hpLevel++ }
                    1 -> if (meta.currency >= meta.costSpeed())  { meta.currency -= meta.costSpeed(); meta.speedLevel++ }
                    2 -> if (meta.currency >= meta.costCdr())    { meta.currency -= meta.costCdr();   meta.cdrLevel++ }
                    3 -> if (meta.currency >= meta.costXp())     { meta.currency -= meta.costXp();    meta.xpLevel++ }
                }
                SoundManager.onUiClick(); saveMeta(); return
            }
        }

        // Start run button
        val startY2 = metaY + metaCardH + 10f
        if (inBtn(rx, ry, cx, startY2, 320f, 80f)) {
            SoundManager.onUiClick(); runEndSaved = false
            GameLogic.reset(state, meta); state.phase = Phase.PLAYING
            if (tutorialShown) { tutorialStep = TutorialStep.MOVE; tutorialTimer = 5f }
        }
    }

    private fun handleSettingsTouch(action: Int, rx: Float, ry: Float) {
        val cx = worldW / 2f; val slW = worldW * 0.50f
        val slLeft = cx - slW / 2f
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            val ySfx = worldH * 0.34f; val yMus = worldH * 0.46f; val yHud = worldH * 0.58f
            if (abs(ry - ySfx) < 40f && rx in slLeft..(slLeft + slW)) {
                settings.sfxVolume = ((rx - slLeft) / slW).coerceIn(0f, 1f)
                SoundManager.sfxVolume = settings.sfxVolume; saveSettings()
            }
            if (abs(ry - yMus) < 40f && rx in slLeft..(slLeft + slW)) {
                settings.musicVolume = ((rx - slLeft) / slW).coerceIn(0f, 1f)
                SoundManager.musicVolume = settings.musicVolume; saveSettings()
            }
            if (abs(ry - yHud) < 40f && rx in slLeft..(slLeft + slW)) {
                settings.hudScale = (0.7f + ((rx - slLeft) / slW) * 0.9f).coerceIn(0.7f, 1.6f)
                layoutAbilityButtons(); saveSettings()
            }
        }
        if (action == MotionEvent.ACTION_DOWN) {
            if (abs(ry - worldH * 0.70f) < 36f) { settings.vibration    = !settings.vibration;    SoundManager.onUiClick(); saveSettings() }
            if (abs(ry - worldH * 0.78f) < 36f) { settings.showFps      = !settings.showFps;      SoundManager.onUiClick(); saveSettings() }
            if (abs(ry - worldH * 0.86f) < 36f) { settings.joystickLeft = !settings.joystickLeft; layoutAbilityButtons(); SoundManager.onUiClick(); saveSettings() }
            if (abs(ry - worldH * 0.70f) < 36f && rx > cx + 60f) {
                settings.quality = (settings.quality % 3) + 1; SoundManager.onUiClick(); saveSettings()
            }
            // Back button
            if (rx < 160f && ry < 80f) {
                state.phase = if (state.kills > 0 || runEndSaved) Phase.PAUSED else Phase.CHARACTER_SELECT
                SoundManager.onUiClick()
            }
        }
    }

    // ─── Draw dispatcher ─────────────────────────────────────────
    private fun drawAll(c: Canvas, dt: Float) {
        for (btn in abilityBtns) if (btn.pressScale < 1f)
            btn.pressScale = minOf(1f, btn.pressScale + dt * 12f)

        when (state.phase) {
            Phase.CHARACTER_SELECT -> { drawBg(c); drawCharSelect(c) }
            Phase.SETTINGS         -> { drawBg(c); drawSettings(c) }
            Phase.PLAYING, Phase.LEVEL_UP, Phase.PAUSED,
            Phase.DEAD, Phase.ABILITY_SWAP -> {
                val sh = if (state.shakeTimer > 0f)
                    state.shakeAmt * (state.shakeTimer / 0.5f).coerceIn(0f, 1f) else 0f
                if (sh > 0f) { c.save(); c.translate((rng.nextFloat()-0.5f)*sh, (rng.nextFloat()-0.5f)*sh) }
                drawBg(c); drawWorld(c); drawHud(c)
                if (sh > 0f) c.restore()
                drawOverlays(c)
            }
        }
    }

    // ─── Background ──────────────────────────────────────────────
    private fun drawBg(c: Canvas) {
        c.drawColor(0xFF06080F.toInt())
        if (settings.quality >= 2) {
            pStroke.color = 0x07334466; pStroke.strokeWidth = 1f
            val g = 72f; var x = 0f
            while (x <= worldW) { c.drawLine(x, 0f, x, worldH, pStroke); x += g }
            var y = 0f
            while (y <= worldH) { c.drawLine(0f, y, worldW, y, pStroke); y += g }
        }
        val t = state.elapsed
        pFill.style = Paint.Style.FILL
        for (s in stars) {
            val yy = ((s.y + bgOff * (s.speed / 20f)) % worldH + worldH) % worldH
            val tw = (0.6f + 0.4f * sin(t * s.speed * 0.3f)).coerceIn(0f, 1f)
            pFill.color = ((tw * s.bright * 190f).toInt() shl 24) or 0x99BBFF
            c.drawCircle(s.x, yy, s.r, pFill)
        }
        if (state.timeSlowActive) {
            pFill.color = 0x1A006688; c.drawRect(0f, 0f, worldW, worldH, pFill)
        }
        if (state.currentEvent == EventType.DARKNESS) {
            val rg = RadialGradient(worldW/2f, worldH/2f, worldW*0.32f,
                intArrayOf(0x00000000, 0xCC000000.toInt()), floatArrayOf(0f,1f), Shader.TileMode.CLAMP)
            pShade.shader = rg; c.drawRect(0f, 0f, worldW, worldH, pShade); pShade.shader = null
        }
    }

    // ─── World objects ───────────────────────────────────────────
    private fun drawWorld(c: Canvas) {
        val time = state.elapsed
        // Chests
        pFill.style = Paint.Style.FILL
        for (ch in state.chests) {
            val bob = sin(ch.bobTimer * 2.5f) * 4f; val y = ch.y + bob
            pFill.color = 0x44FFCC00; c.drawCircle(ch.x, y, ch.radius * 1.9f + sin(time*3f)*3f, pFill)
            pFill.color = 0xFF8B5A00.toInt()
            c.drawRoundRect(RectF(ch.x-ch.radius, y-ch.radius*0.8f, ch.x+ch.radius, y+ch.radius*0.8f), 5f, 5f, pFill)
            pFill.color = 0xFFA07820.toInt()
            c.drawRoundRect(RectF(ch.x-ch.radius, y-ch.radius*0.8f, ch.x+ch.radius, y-ch.radius*0.1f), 5f, 5f, pFill)
            pFill.color = 0xFFFFD700.toInt(); c.drawCircle(ch.x, y, 5f, pFill)
            pText.color = 0xFFFFEE88.toInt(); pText.textSize = 18f; pText.textAlign = Paint.Align.CENTER
            c.drawText("CHEST", ch.x, y - ch.radius - 8f, pText)
        }
        // Black holes
        for (bh in state.blackHoles) {
            val rg = RadialGradient(bh.x, bh.y, bh.radius + sin(time*12f)*4f,
                intArrayOf(0xFF330066.toInt(), 0x66660099, 0x00000000),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            pShade.shader = rg; c.drawCircle(bh.x, bh.y, bh.radius + 8f, pShade); pShade.shader = null
            pFill.color = 0xFF9900FF.toInt(); c.drawCircle(bh.x, bh.y, 12f, pFill)
        }
        // XP orbs – batch with drawPoints for speed
        val pulse = sin(time * 5f) * 2f
        pFill.color = 0x4400FFAA

        pFill.style = Paint.Style.FILL
        for (orb in state.orbs) {
            pFill.color = 0x4400FFAA; c.drawCircle(orb.x, orb.y, orb.radius + 3f + pulse, pFill)
            pFill.color = 0xFF00FFAA.toInt(); c.drawCircle(orb.x, orb.y, orb.radius, pFill)
        }
        // Particles – batch tiny ones as points, draw big ones as circles
        drawParticles(c)
        // Enemies
        drawEnemies(c, time)
        // Player
        drawPlayer(c, time)
        // Bullets
        drawBullets(c)
        // Float texts
        drawFloatTexts(c)
    }


    private fun drawParticles(c: Canvas) {
        pFill.style = Paint.Style.FILL
        val quality = settings.quality
        for (pt in state.particles) {
            if (!pt.active) continue
            if (quality == 1 && pt.radius < 2.5f) continue  // skip tiny particles on Low
            val alpha = (pt.life / pt.maxLife * 240f).toInt().coerceIn(0, 240)
            pFill.color = (pt.color and 0x00FFFFFF) or (alpha shl 24)
            val r = pt.radius * (pt.life / pt.maxLife)
            if (r >= 1.5f) c.drawCircle(pt.x, pt.y, r, pFill)
        }
    }

    private fun drawEnemies(c: Canvas, time: Float) {
        pFill.style = Paint.Style.FILL
        for (e in state.enemies) {
            if (e.hp <= 0f) continue
            val flash  = e.flashTimer > 0f
            val base   = enemyCol(e.type)
            val tinted = when {
                e.statusEffects.any { it.type == StatusEffectType.FREEZE } -> blend(base, 0xFF88DDFF.toInt(), 0.5f)
                e.statusEffects.any { it.type == StatusEffectType.BURN   } -> blend(base, 0xFFFF5500.toInt(), 0.4f)
                e.statusEffects.any { it.type == StatusEffectType.SHOCK  } -> blend(base, 0xFFFFFF44.toInt(), 0.35f)
                else -> base
            }
            val col = if (flash) 0xFFFFFFFF.toInt() else tinted

            // Shadow
            if (settings.quality >= 2) {
                pFill.color = 0x22000000; c.drawCircle(e.x+3f, e.y+3f, e.radius, pFill)
            }
            pFill.color = col
            when (e.type) {
                EnemyType.BOSS -> {
                    c.drawCircle(e.x, e.y, e.radius*1.2f, pFill)
                    pFill.color = if (e.bossPhase >= 2) 0xFFFF4400.toInt() else 0xFFAA0000.toInt()
                    c.drawCircle(e.x, e.y, e.radius*0.65f, pFill)
                    pFill.color = 0xFFFFFFFF.toInt(); c.drawCircle(e.x, e.y, e.radius*0.22f, pFill)
                    pStroke.color = tinted; pStroke.strokeWidth = 3f
                    repeat(8) { i ->
                        val a = i*(2f*PI.toFloat()/8f) + time*1.2f
                        c.drawLine(e.x+cos(a)*e.radius, e.y+sin(a)*e.radius,
                            e.x+cos(a)*(e.radius*1.55f), e.y+sin(a)*(e.radius*1.55f), pStroke)
                    }
                    pFill.style = Paint.Style.FILL
                }
                EnemyType.ELITE -> {
                    c.drawCircle(e.x, e.y, e.radius, pFill)
                    pStroke.color = 0xCCFFD700.toInt(); pStroke.strokeWidth = 4f
                    c.drawCircle(e.x, e.y, e.radius+5f+sin(time*4f)*2f, pStroke)
                }
                EnemyType.TANK -> {
                    c.drawRoundRect(RectF(e.x-e.radius, e.y-e.radius*0.8f, e.x+e.radius, e.y+e.radius*0.8f), 8f, 8f, pFill)
                }
                EnemyType.FAST -> {
                    val p2 = state.player; val a = atan2(p2.y-e.y, p2.x-e.x)
                    val path = Path()
                    path.moveTo(e.x+cos(a)*e.radius, e.y+sin(a)*e.radius)
                    path.lineTo(e.x+cos(a+2.5f)*e.radius*0.7f, e.y+sin(a+2.5f)*e.radius*0.7f)
                    path.lineTo(e.x+cos(a-2.5f)*e.radius*0.7f, e.y+sin(a-2.5f)*e.radius*0.7f)
                    path.close(); c.drawPath(path, pFill)
                }
                EnemyType.SHIELD_ENEMY -> {
                    c.drawCircle(e.x, e.y, e.radius, pFill)
                    if (!e.shieldBroken) {
                        pStroke.color = 0x880088FF.toInt(); pStroke.strokeWidth = 5f
                        c.drawCircle(e.x, e.y, e.radius+8f+sin(time*3f)*2f, pStroke)
                    }
                }
                EnemyType.EXPLODER -> {
                    c.drawCircle(e.x, e.y, e.radius, pFill)
                    pFill.color = 0x88FF8800.toInt()
                    c.drawCircle(e.x, e.y, e.radius*(0.78f+sin(time*8f)*0.22f), pFill)
                }
                else -> c.drawCircle(e.x, e.y, e.radius, pFill)
            }

            // Status icons
            if (e.statusEffects.isNotEmpty()) {
                var ix = e.x - e.statusEffects.size * 9f
                pText.textSize = 16f; pText.textAlign = Paint.Align.CENTER
                for (eff in e.statusEffects) {
                    pText.color = statusCol(eff.type)
                    c.drawText(statusIcon(eff.type), ix, e.y - e.radius - 14f, pText); ix += 18f
                }
            }

            // HP bar
            val bw = e.radius*2f; val bh = 4f; val bx = e.x-e.radius; val by = e.y-e.radius-10f
            pFill.color = 0xFF220000.toInt(); c.drawRect(bx, by, bx+bw, by+bh, pFill)
            val hf = (e.hp/e.maxHp).coerceIn(0f,1f)
            pFill.color = if (hf > 0.5f) 0xFF22CC44.toInt() else if (hf > 0.25f) 0xFFDDAA00.toInt() else 0xFFCC2222.toInt()
            c.drawRect(bx, by, bx+bw*hf, by+bh, pFill)
            if (e.type == EnemyType.SHIELD_ENEMY && !e.shieldBroken && e.maxShieldHp > 0f) {
                pFill.color = 0xFF003388.toInt(); c.drawRect(bx, by-bh-2f, bx+bw, by-2f, pFill)
                pFill.color = 0xFF0088FF.toInt(); c.drawRect(bx, by-bh-2f, bx+bw*(e.shieldHp/e.maxShieldHp).coerceIn(0f,1f), by-2f, pFill)
            }
        }
    }

    private fun drawPlayer(c: Canvas, time: Float) {
        val p = state.player; pFill.style = Paint.Style.FILL
        // Shield ring
        if (p.shieldActive) {
            pFill.color = ((sin(time*8f)*30+150).toInt() shl 24) or 0x004488FF
            c.drawCircle(p.x, p.y, p.radius+14f, pFill)
            pStroke.color = 0xFF4488FF.toInt(); pStroke.strokeWidth = 3f
            c.drawCircle(p.x, p.y, p.radius+14f, pStroke)
        }
        // iFrames flicker
        if (p.iFrames > 0f && !p.shieldActive) {
            val al = ((sin(time*25f)*0.5f+0.5f)*180f).toInt()
            pFill.color = (al shl 24) or 0x00FFFFFF; c.drawCircle(p.x, p.y, p.radius+4f, pFill)
        }
        // Body
        pFill.color = if (p.hitFlashTimer > 0f) 0xFFFF8888.toInt() else 0xFF44AAFF.toInt()
        c.drawCircle(p.x, p.y, p.radius, pFill)
        pFill.color = if (p.hitFlashTimer > 0f) 0xFFFFBBBB.toInt() else 0xFF88CCFF.toInt()
        c.drawCircle(p.x, p.y, p.radius*0.52f, pFill)
        // Dash trail
        if (p.isDashing) {
            repeat(5) { i ->
                val tr = 1f - i/5f
                pFill.color = ((tr*80f).toInt() shl 24) or 0x0022FFFF
                c.drawCircle(p.x - p.dashVx*0.003f*i, p.y - p.dashVy*0.003f*i, p.radius*tr, pFill)
            }
        }
        // Energy orb
        val orbAb = state.abilities.find { it.id == AbilityId.ENERGY_ORB }
        if ((orbAb?.level ?: 0) > 0) {
            val orbCnt = orbAb!!.level.coerceAtMost(3); val orbR = 70f + p.areaScale*14f
            repeat(orbCnt) { i ->
                val a = p.orbAngle + i*(2f*PI.toFloat()/orbCnt)
                val ox = p.x+cos(a)*orbR; val oy = p.y+sin(a)*orbR
                val oc = if (EvoType.ICE_ORB in state.evolutions) 0xFF44AAFF.toInt()
                         else if (p.orbBurst) 0xFFFF8800.toInt() else 0xFFFFDD00.toInt()
                pFill.color = oc and 0x00FFFFFF or 0x55000000; c.drawCircle(ox, oy, 17f, pFill)
                pFill.color = oc; c.drawCircle(ox, oy, 11f, pFill)
            }
        }
    }

    private fun drawBullets(c: Canvas) {
        pFill.style = Paint.Style.FILL
        for (b in state.bullets) {
            val col = if (b.fromPlayer) when (b.statusType) {
                StatusEffectType.BURN   -> 0xFFFF6600.toInt()
                StatusEffectType.FREEZE -> 0xFF44AAFF.toInt()
                StatusEffectType.SHOCK  -> 0xFFFFFF44.toInt()
                else -> if (b.piercesLeft > 0) 0xFF00FFFF.toInt()
                        else if (b.chainLeft > 0) 0xFF88FFFF.toInt()
                        else 0xFFFFFF88.toInt()
            } else 0xFFFF4444.toInt()
            pFill.color = col and 0x00FFFFFF or 0x44000000
            c.drawCircle(b.x, b.y, b.radius*2.0f, pFill)
            pFill.color = col; c.drawCircle(b.x, b.y, b.radius, pFill)
        }
    }

    private fun drawFloatTexts(c: Canvas) {
        for (ft in state.floatTexts) {
            val al = (ft.life / 0.9f * 255f).toInt().coerceIn(0, 255)
            pText.textSize    = (if (ft.isCrit) 42f else 30f) * ft.scale * settings.hudScale
            pText.textAlign   = Paint.Align.CENTER
            pText.isFakeBoldText = ft.isCrit
            if (ft.isCrit) {
                pText.color = (al shl 24); pText.style = Paint.Style.STROKE; pText.strokeWidth = 3f
                c.drawText(ft.text, ft.x, ft.y, pText)
                pText.style = Paint.Style.FILL
            }
            pText.color = (ft.color and 0x00FFFFFF) or (al shl 24); pText.style = Paint.Style.FILL
            c.drawText(ft.text, ft.x, ft.y, pText)
            pText.isFakeBoldText = false
        }
    }

    // ─── HUD ─────────────────────────────────────────────────────
    private fun drawHud(c: Canvas) {
        val p = state.player; val hs = settings.hudScale

        // HP bar (top-left)
        val hbW = worldW * 0.28f * hs; val hbH = 22f * hs; val hbX = 16f; val hbY = 14f
        bar(c, hbX, hbY, hbW, hbH,
            (p.hp/p.maxHp).coerceIn(0f,1f),
            if (p.hp/p.maxHp > 0.5f) 0xFF22CC44.toInt() else if (p.hp/p.maxHp > 0.25f) 0xFFDDAA00.toInt() else 0xFFCC2222.toInt())
        pText.color = 0xFFCCEEFF.toInt(); pText.textSize = 15f * hs; pText.textAlign = Paint.Align.LEFT
        c.drawText("HP ${p.hp.toInt()}/${p.maxHp.toInt()}", hbX+6f, hbY+hbH-4f, pText)

        // XP bar
        val xbY = hbY + hbH + 5f * hs
        bar(c, hbX, xbY, hbW, 12f * hs, (p.xp/p.xpNext).coerceIn(0f,1f), 0xFF0088FF.toInt())
        pText.textSize = 13f * hs
        c.drawText("LV${p.level}", hbX+4f, xbY+11f*hs, pText)

        // Wave / time / kills (top-right)
        val mins = (state.elapsed/60f).toInt(); val secs = (state.elapsed%60f).toInt()
        pText.color = 0xFFCCDDFF.toInt(); pText.textSize = 18f * hs; pText.textAlign = Paint.Align.RIGHT
        c.drawText("WAVE ${state.wave}  %02d:%02d".format(mins, secs), worldW-16f, 30f*hs, pText)
        c.drawText("KILLS: ${state.kills}", worldW-16f, 50f*hs, pText)

        // Coins
        pText.color = 0xFFFFCC44.toInt(); pText.textSize = 15f*hs
        c.drawText("${state.runCurrency}c", worldW-16f, 70f*hs, pText)

        // Combo
        val combo = state.combo
        if (combo.count >= 3) {
            val ca = (combo.timer / combo.timeout * 255f).toInt().coerceIn(80, 255)
            pText.textSize = (30f + if (combo.count >= 10) 8f else 0f) * hs
            pText.textAlign = Paint.Align.CENTER
            pText.color = (ca shl 24) or 0xFFAA00
            c.drawText(combo.label, worldW/2f, worldH/2f - worldH*0.3f, pText)
            pText.textSize = 16f * hs
            pText.color = ((ca/2) shl 24) or 0xFFCC44
            c.drawText("x%.2f".format(combo.multiplier), worldW/2f, worldH/2f - worldH*0.3f + 22f*hs, pText)
        }

        // Boss HP bar (top centre)
        state.boss?.let { boss ->
            val bw = worldW*0.45f; val bh = 22f*hs; val bx = (worldW-bw)/2f; val by = 14f
            bar(c, bx, by, bw, bh, (boss.hp/boss.maxHp).coerceIn(0f,1f),
                if (boss.bossPhase >= 3) 0xFFFF2200.toInt() else if (boss.bossPhase >= 2) 0xFFFF6600.toInt() else 0xFFCC0000.toInt())
            pText.color = 0xFFFFDDCC.toInt(); pText.textSize = 14f*hs; pText.textAlign = Paint.Align.CENTER
            c.drawText("BOSS  ${boss.hp.toInt()}/${boss.maxHp.toInt()}", worldW/2f, by+bh-4f, pText)
        }

        // Ability buttons (3 slots)
        drawAbilityBtns(c, hs)

        // Joystick ghost
        if (joyActive) {
            pStroke.color = 0x33FFFFFF; pStroke.strokeWidth = 2f
            c.drawCircle(joyBaseX, joyBaseY, joyRadius, pStroke)
            pFill.color = 0x88FFFFFF.toInt(); pFill.style = Paint.Style.FILL
            c.drawCircle(joyBaseX+joyDx, joyBaseY+joyDy, 34f*hs, pFill)
        }

        // Pause button
        pFill.color = 0x44AABBCC; pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(worldW-86f, 8f, worldW-8f, 68f), 10f, 10f, pFill)
        pText.color = 0xFFCCDDFF.toInt(); pText.textSize = 18f; pText.textAlign = Paint.Align.CENTER
        c.drawText("II", worldW-47f, 48f, pText)

        // Event tag
        state.currentEvent?.let { evt ->
            pFill.color = 0x88111122.toInt(); pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(worldW/2f-130f, worldH-44f*hs, worldW/2f+130f, worldH-10f*hs), 10f, 10f, pFill)
            pText.color = eventCol(evt); pText.textSize = 18f*hs; pText.textAlign = Paint.Align.CENTER
            c.drawText(eventName(evt), worldW/2f, worldH-16f*hs, pText)
        }

        if (settings.showFps) {
            pText.color = 0xFF55FF55.toInt(); pText.textSize = 18f; pText.textAlign = Paint.Align.LEFT
            c.drawText("FPS $fpsDisplay", 14f, worldH-12f, pText)
        }
    }

    private fun drawAbilityBtns(c: Canvas, hs: Float) {
        for (btn in abilityBtns) {
            val abilityId = state.activeSlots.getOrNull(btn.slotIdx)
            val ab        = abilityId?.let { state.abilities.find { a -> a.id == it } }
            val unlocked  = ab != null && ab.level > 0
            val ready     = ab?.isReady() == true
            val cdFrac    = if (ab != null && ab.baseCd > 0f) (ab.cdTimer/ab.baseCd).coerceIn(0f,1f) else 0f
            val sc        = btn.pressScale

            c.save(); c.scale(sc, sc, btn.cx, btn.cy)
            pFill.style = Paint.Style.FILL
            pFill.color = when {
                !unlocked -> 0x22334455
                ready     -> 0xCC1A3366.toInt()
                else      -> 0xCC111122.toInt()
            }
            c.drawCircle(btn.cx, btn.cy, btn.r, pFill)
            if (!ready && unlocked && cdFrac > 0f) {
                pFill.color = 0x88001133.toInt()
                c.drawArc(RectF(btn.cx-btn.r, btn.cy-btn.r, btn.cx+btn.r, btn.cy+btn.r), -90f, 360f*cdFrac, true, pFill)
            }
            pStroke.strokeWidth = 2.5f
            pStroke.color = if (ready && unlocked) 0xFF4488FF.toInt() else 0xFF223344.toInt()
            c.drawCircle(btn.cx, btn.cy, btn.r, pStroke)
            if (ab != null) {
                pText.color = if (unlocked) 0xFFDDEEFF.toInt() else 0xFF334455.toInt()
                pText.textSize = 17f*hs; pText.textAlign = Paint.Align.CENTER
                c.drawText(ab.label, btn.cx, btn.cy+7f, pText)
                if (!ready && unlocked && ab.cdTimer > 0.4f) {
                    pText.color = 0x99DDEEFF.toInt(); pText.textSize = 12f*hs
                    c.drawText("%.1f".format(ab.cdTimer), btn.cx, btn.cy+btn.r-5f, pText)
                }
            } else {
                pText.color = 0xFF223344.toInt(); pText.textSize = 15f*hs; pText.textAlign = Paint.Align.CENTER
                c.drawText("---", btn.cx, btn.cy+6f, pText)
            }
            c.restore()
        }
    }

    // ─── Overlays ────────────────────────────────────────────────
    private fun drawOverlays(c: Canvas) {
        if (state.showBossWarning) drawBossWarning(c)
        state.eventAnnouncement?.let { drawEventAnn(c, it) }
        if (state.phase == Phase.LEVEL_UP) drawLevelUp(c)
        if (state.phase == Phase.ABILITY_SWAP) drawAbilitySwap(c)
        if (state.phase == Phase.PAUSED) drawPause(c)
        if (state.phase == Phase.DEAD) drawDead(c)
        drawToasts(c)
        drawTutorial(c)
    }

    private fun drawBossWarning(c: Canvas) {
        val flash = sin(state.elapsed*12f)*0.5f+0.5f
        pFill.color = ((flash*110f).toInt() shl 24) or 0xFF0000
        c.drawRect(0f, 0f, worldW, worldH, pFill)
        pText.color = 0xFFFF2222.toInt(); pText.textSize = 52f*(0.85f+flash.toFloat()*0.15f)
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        c.drawText("! BOSS INCOMING !", worldW/2f, worldH/2f, pText); pText.isFakeBoldText = false
    }

    private fun drawEventAnn(c: Canvas, ann: EventAnnouncement) {
        val al = (ann.warningTimer/2.5f*200f).toInt().coerceIn(0,200)
        pFill.color = (al shl 24) or 0x00100820; pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(worldW*0.25f, worldH*0.3f, worldW*0.75f, worldH*0.7f), 20f, 20f, pFill)
        pText.color = eventCol(ann.type); pText.textSize = 40f; pText.textAlign = Paint.Align.CENTER
        pText.isFakeBoldText = true; c.drawText("EVENT!", worldW/2f, worldH*0.44f, pText); pText.isFakeBoldText = false
        pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 28f
        c.drawText(eventName(ann.type), worldW/2f, worldH*0.56f, pText)
    }

    private fun drawLevelUp(c: Canvas) {
        pFill.color = 0xCC050810.toInt(); pFill.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pFill)
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFF00FFAA.toInt(); pText.textSize = 46f*settings.hudScale
        c.drawText("LEVEL UP!  LV${state.player.level}", worldW/2f, worldH*0.14f, pText)
        pText.isFakeBoldText = false; pText.color = 0xFF88CCFF.toInt(); pText.textSize = 20f*settings.hudScale
        c.drawText("Choose an upgrade", worldW/2f, worldH*0.21f, pText)

        val ups = state.pendingUpgrades; val cx = worldW/2f
        val cardW = worldW*0.72f; val usable = worldH * 0.60f
        val cardH = usable / ups.size.coerceAtLeast(1) - 12f
        val startY = worldH*0.26f; val gap = cardH + 12f

        for ((i, up) in ups.withIndex()) {
            val top = startY + i*gap; val sc = cardScales[i]
            c.save(); c.scale(sc, sc, cx, top+cardH/2f)
            pFill.color = rarityCard(up.rarity); pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx-cardW/2, top, cx+cardW/2, top+cardH), 16f, 16f, pFill)
            pStroke.color = rarityBorder(up.rarity); pStroke.strokeWidth = 3f
            c.drawRoundRect(RectF(cx-cardW/2, top, cx+cardW/2, top+cardH), 16f, 16f, pStroke)
            pText.textAlign = Paint.Align.LEFT; pText.color = rarityBorder(up.rarity); pText.textSize = 15f
            c.drawText(rarityLabel(up.rarity), cx-cardW/2+14f, top+24f, pText)
            pText.textAlign = Paint.Align.CENTER; pText.color = 0xFFEEFFFF.toInt()
            pText.textSize = 28f*settings.hudScale; pText.isFakeBoldText = true
            c.drawText(up.name, cx, top+cardH*0.46f, pText); pText.isFakeBoldText = false
            pText.color = 0xFFAABBCC.toInt(); pText.textSize = 20f*settings.hudScale
            c.drawText(up.desc, cx, top+cardH*0.74f, pText)
            c.restore()
        }
    }

    private fun drawAbilitySwap(c: Canvas) {
        val newId = state.pendingSwapAbility ?: return
        pFill.color = 0xCC050810.toInt(); pFill.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pFill)
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFFFFAA00.toInt(); pText.textSize = 36f*settings.hudScale
        c.drawText("NEW ABILITY UNLOCKED!", worldW/2f, worldH*0.12f, pText); pText.isFakeBoldText = false
        val newAb = state.abilities.find { it.id == newId }
        pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 26f*settings.hudScale
        c.drawText("[ ${newAb?.label ?: newId.name} ]   Tap a current ability to replace, or", worldW/2f, worldH*0.20f, pText)
        pText.color = 0xFF778899.toInt(); pText.textSize = 20f*settings.hudScale
        c.drawText("tap below to keep your current abilities", worldW/2f, worldH*0.27f, pText)

        val cx = worldW/2f; val cw = worldW*0.55f; val ch = worldH*0.18f; val gap = 14f
        val startY = worldH*0.33f
        for (i in 0..2) {
            val slotId = state.activeSlots.getOrNull(i)
            val ab = slotId?.let { id -> state.abilities.find { it.id == id } }
            val top = startY + i*(ch+gap)
            pFill.color = 0xBB1A2244.toInt(); pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx-cw/2, top, cx+cw/2, top+ch), 14f, 14f, pFill)
            pStroke.color = 0xFF4488FF.toInt(); pStroke.strokeWidth = 2.5f
            c.drawRoundRect(RectF(cx-cw/2, top, cx+cw/2, top+ch), 14f, 14f, pStroke)
            pText.textAlign = Paint.Align.CENTER
            pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 28f*settings.hudScale; pText.isFakeBoldText = true
            c.drawText(ab?.label ?: "SLOT ${i+1}", cx, top+ch*0.5f+4f, pText); pText.isFakeBoldText = false
            pText.color = 0xFF556677.toInt(); pText.textSize = 18f*settings.hudScale
            c.drawText("Tap to replace", cx, top+ch*0.78f, pText)
        }

        // Keep / cancel
        drawMenuBtn(c, cx, worldH*0.87f, 280f, 58f, "KEEP CURRENT", 0xFF221122.toInt(), 0xFF886688.toInt())
    }

    private fun drawPause(c: Canvas) {
        pFill.color = 0xBB040608.toInt(); pFill.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pFill)
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFFDDEEFF.toInt(); pText.textSize = 48f
        c.drawText("PAUSED", worldW/2f, worldH*0.28f, pText); pText.isFakeBoldText = false
        val cx = worldW/2f
        drawMenuBtn(c, cx, worldH*0.42f, 300f, 72f, "RESUME",   0xFF1A3344.toInt(), 0xFF44AAFF.toInt())
        drawMenuBtn(c, cx, worldH*0.55f, 300f, 72f, "SETTINGS", 0xFF1A1A44.toInt(), 0xFF8888FF.toInt())
        drawMenuBtn(c, cx, worldH*0.68f, 300f, 72f, "QUIT RUN", 0xFF331111.toInt(), 0xFFFF4444.toInt())
        pText.color = 0xFF556677.toInt(); pText.textSize = 18f; pText.textAlign = Paint.Align.CENTER
        val mins = (state.elapsed/60f).toInt(); val secs = (state.elapsed%60f).toInt()
        c.drawText("Wave ${state.wave}  •  Kills ${state.kills}  •  LV${state.player.level}  •  %02d:%02d".format(mins,secs), cx, worldH*0.82f, pText)
    }

    private fun drawDead(c: Canvas) {
        pFill.color = 0xDD050508.toInt(); pFill.style = Paint.Style.FILL
        c.drawRect(0f, 0f, worldW, worldH, pFill)
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFFCC2222.toInt(); pText.textSize = 52f
        c.drawText("ELIMINATED", worldW/2f, worldH*0.10f, pText); pText.isFakeBoldText = false

        val cx = worldW/2f; val cw = worldW*0.88f; val cx2 = cx-cw/2f
        val cardTop = worldH*0.15f; val cardBot = worldH*0.79f
        pFill.color = 0xAA0A0C1A.toInt(); pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(cx2, cardTop, cx2+cw, cardBot), 18f, 18f, pFill)
        pStroke.color = 0xFF223344.toInt(); pStroke.strokeWidth = 1.5f
        c.drawRoundRect(RectF(cx2, cardTop, cx2+cw, cardBot), 18f, 18f, pStroke)

        val p = state.player; val st = state.stats
        val mins = (state.elapsed/60f).toInt(); val secs = (state.elapsed%60f).toInt()
        pText.textAlign = Paint.Align.CENTER; pText.color = 0xFFAABBCC.toInt(); pText.textSize = 22f
        c.drawText("— RUN SUMMARY —", cx, cardTop+34f, pText)

        // Two-column stat grid
        val col1x = cx2 + cw * 0.28f; val col2x = cx2 + cw * 0.75f
        var ry = cardTop + 58f; val rs = 28f

        fun stat2(l1: String, v1: String, l2: String, v2: String) {
            pText.textSize = 17f; pText.textAlign = Paint.Align.LEFT
            pText.color = 0xFF556677.toInt(); c.drawText(l1, cx2+12f, ry, pText)
            pText.textAlign = Paint.Align.RIGHT; pText.color = 0xFFCCDDEE.toInt()
            c.drawText(v1, col1x+60f, ry, pText)
            pText.textAlign = Paint.Align.LEFT; pText.color = 0xFF556677.toInt()
            c.drawText(l2, col2x-80f, ry, pText)
            pText.textAlign = Paint.Align.RIGHT; pText.color = 0xFFCCDDEE.toInt()
            c.drawText(v2, cx2+cw-12f, ry, pText)
            ry += rs
        }

        stat2("Survived",    "%02d:%02d".format(mins,secs),   "Wave",         "${state.wave}")
        stat2("Kills",       "${state.kills}",                 "Level",        "${p.level}")
        stat2("Dmg Dealt",   "${st.damageDealt.toInt()}",      "Dmg Taken",    "${st.damageTaken.toInt()}")
        stat2("Healing",     "${st.healingDone.toInt()}",      "Bosses",       "${st.bossesKilled}")
        stat2("Best Combo",  "x${st.bestCombo}",              "Elites",       "${st.elitesKilled}")
        stat2("Shots Fired", "${st.shotsFired}",              "Accuracy",     "${st.accuracy}%")
        stat2("Status FX",   "${st.statusApplied}",           "Chests",       "${st.chestsOpened}")
        stat2("Abilities",   "${st.abilitiesUsed}",           "Distance",     "${(st.distanceTraveled/1000f).let{"%.1f".format(it)}}km")
        stat2("XP Earned",   "${st.xpCollected.toInt()}",     "Evolutions",   "${state.evolutions.size}")

        // Coins
        pFill.color = 0xFF332200.toInt(); pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(cx2+10f, cardBot-44f, cx2+cw-10f, cardBot-8f), 10f, 10f, pFill)
        pText.color = 0xFFFFCC44.toInt(); pText.textSize = 22f; pText.textAlign = Paint.Align.CENTER
        c.drawText("+${state.runCurrency} coins  (Total: ${meta.currency})", cx, cardBot-20f, pText)

        val bw = 300f; val bh = 64f
        drawMenuBtn(c, cx, worldH*0.82f, bw, bh, "PLAY AGAIN",       0xFF0A2A14.toInt(), 0xFF22CC66.toInt())
        drawMenuBtn(c, cx, worldH*0.91f, bw, bh, "CHARACTER SELECT", 0xFF111A33.toInt(), 0xFF6688FF.toInt())
    }

    // ─── Character Select ─────────────────────────────────────────
    private fun drawCharSelect(c: Canvas) {
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFF88AAFF.toInt(); pText.textSize = 44f
        c.drawText("VOID SURVIVORS", worldW/2f, worldH*0.10f, pText); pText.isFakeBoldText = false
        pText.color = 0xFFFFCC44.toInt(); pText.textSize = 22f
        c.drawText("Coins: ${meta.currency}", worldW/2f, worldH*0.17f, pText)

        val cx = worldW/2f; val cw = worldW*0.55f; val ch = worldH*0.15f
        val startY = worldH*0.18f; val gap = ch + 10f

        for ((i, def) in Characters.ALL.withIndex()) {
            val top = startY + i*gap; val unlocked = meta.isCharUnlocked(def.type)
            val sel = i == selectedCharIdx
            pFill.color = if (sel && unlocked) 0xBB001A44.toInt() else if (!unlocked) 0x66111122 else 0xAA0A0C1A.toInt()
            pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx-cw/2, top, cx+cw/2, top+ch), 14f, 14f, pFill)
            pStroke.strokeWidth = if (sel) 3f else 1.5f
            pStroke.color = if (sel && unlocked) 0xFF4488FF.toInt() else 0xFF223344.toInt()
            c.drawRoundRect(RectF(cx-cw/2, top, cx+cw/2, top+ch), 14f, 14f, pStroke)
            pFill.color = if (unlocked) charCol(def.type) else 0xFF333344.toInt()
            c.drawCircle(cx-cw/2+38f, top+ch/2f, 20f, pFill)
            pText.textAlign = Paint.Align.LEFT
            if (unlocked) {
                pText.color = if (sel) 0xFFEEFFFF.toInt() else 0xFFCCDDEE.toInt()
                pText.textSize = 24f; pText.isFakeBoldText = true
                c.drawText(def.name, cx-cw/2+68f, top+ch*0.40f, pText); pText.isFakeBoldText = false
                pText.color = 0xFF667788.toInt(); pText.textSize = 17f
                c.drawText(def.tagline, cx-cw/2+68f, top+ch*0.72f, pText)
                if (sel) { pText.color = 0xFF44AAFF.toInt(); pText.textAlign = Paint.Align.RIGHT; pText.textSize = 18f; c.drawText("SELECTED ✓", cx+cw/2-10f, top+ch*0.55f, pText) }
            } else {
                pText.color = 0xFF445566.toInt(); pText.textSize = 24f; pText.isFakeBoldText = true
                c.drawText(def.name, cx-cw/2+68f, top+ch*0.40f, pText); pText.isFakeBoldText = false
                val canBuy = meta.currency >= def.unlockCost
                pText.color = if (canBuy) 0xFFFFCC44.toInt() else 0xFF665544.toInt(); pText.textSize = 17f
                c.drawText("Unlock: ${def.unlockCost}c  ${if (canBuy) "← Tap to unlock!" else "(need ${def.unlockCost - meta.currency}c more)"}", cx-cw/2+68f, top+ch*0.72f, pText)
            }
        }

        // Permanent upgrades row
        val metaY = startY + Characters.ALL.size * gap + 8f
        pText.color = 0xFF445566.toInt(); pText.textSize = 17f; pText.textAlign = Paint.Align.CENTER
        c.drawText("PERMANENT UPGRADES", cx, metaY+18f, pText)
        val mcH = worldH*0.14f; val btnW = worldW*0.10f; val btnH = mcH*0.55f
        val labels = arrayOf("HP+20\n${meta.costHp()}c", "SPD+15\n${meta.costSpeed()}c", "CDR-5%\n${meta.costCdr()}c", "XP+10%\n${meta.costXp()}c")
        val levels = intArrayOf(meta.hpLevel, meta.speedLevel, meta.cdrLevel, meta.xpLevel)
        val costs  = intArrayOf(meta.costHp(), meta.costSpeed(), meta.costCdr(), meta.costXp())
        for (i in 0..3) {
            val bx = cx - worldW*0.22f + i*(btnW+10f); val by = metaY+28f
            val canAfford = meta.currency >= costs[i]
            pFill.color = if (canAfford) 0xFF0A2A14.toInt() else 0xFF111122.toInt(); pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(bx, by, bx+btnW, by+btnH), 8f, 8f, pFill)
            pStroke.color = if (canAfford) 0xFF44CC66.toInt() else 0xFF223344.toInt(); pStroke.strokeWidth = 1.5f
            c.drawRoundRect(RectF(bx, by, bx+btnW, by+btnH), 8f, 8f, pStroke)
            pText.color = if (canAfford) 0xFF88FF88.toInt() else 0xFF445566.toInt()
            pText.textSize = 14f; pText.textAlign = Paint.Align.CENTER
            c.drawText(labels[i].replace("\n", " "), bx+btnW/2f, by+btnH*0.45f, pText)
            pText.color = 0xFF446688.toInt(); pText.textSize = 12f
            c.drawText("Lv${levels[i]}", bx+btnW/2f, by+btnH*0.80f, pText)
        }

        // Start button
        val sy = metaY + mcH + 8f
        drawMenuBtn(c, cx, sy, 320f, 72f, "START RUN", 0xFF003322.toInt(), 0xFF22EE88.toInt())
    }

    // ─── Settings screen ─────────────────────────────────────────
    private fun drawSettings(c: Canvas) {
        pText.textAlign = Paint.Align.CENTER; pText.isFakeBoldText = true
        pText.color = 0xFF88AAFF.toInt(); pText.textSize = 40f
        c.drawText("SETTINGS", worldW/2f, worldH*0.10f, pText); pText.isFakeBoldText = false

        val cx = worldW/2f; val slW = worldW*0.50f; val slH = 14f; val slLeft = cx-slW/2f

        fun slider(label: String, v: Float, y: Float) {
            pText.textAlign = Paint.Align.LEFT; pText.color = 0xFFAABBCC.toInt(); pText.textSize = 20f
            c.drawText(label, slLeft, y-12f, pText)
            pFill.color = 0xFF1A2233.toInt(); pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(slLeft, y, slLeft+slW, y+slH), slH/2, slH/2, pFill)
            pFill.color = 0xFF4488FF.toInt()
            c.drawRoundRect(RectF(slLeft, y, slLeft+slW*v, y+slH), slH/2, slH/2, pFill)
            pFill.color = 0xFFAABBFF.toInt(); c.drawCircle(slLeft+slW*v, y+slH/2, 18f, pFill)
            pText.textAlign = Paint.Align.RIGHT; pText.color = 0xFF556677.toInt(); pText.textSize = 17f
            c.drawText("${(v*100).toInt()}%", slLeft+slW+56f, y+12f, pText)
        }
        slider("SFX Volume",   settings.sfxVolume,  worldH*0.34f)
        slider("Music Volume", settings.musicVolume, worldH*0.46f)
        slider("HUD Scale",    (settings.hudScale-0.7f)/0.9f, worldH*0.58f)

        fun toggle(label: String, v: Boolean, y: Float) {
            pText.textAlign = Paint.Align.LEFT; pText.color = 0xFFAABBCC.toInt(); pText.textSize = 20f
            c.drawText(label, slLeft, y+8f, pText)
            pFill.color = if (v) 0xFF1A3322.toInt() else 0xFF221A22.toInt(); pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(cx+60f, y-14f, cx+180f, y+18f), 16f, 16f, pFill)
            pFill.color = if (v) 0xFF44FF88.toInt() else 0xFF664466.toInt()
            c.drawCircle(if (v) cx+163f else cx+77f, y+2f, 16f, pFill)
            pText.textAlign = Paint.Align.RIGHT; pText.color = if (v) 0xFF44FF88.toInt() else 0xFF664466.toInt()
            pText.textSize = 18f; c.drawText(if (v) "ON" else "OFF", cx+180f, y+8f, pText)
        }
        toggle("Vibration",     settings.vibration,    worldH*0.70f)
        toggle("Show FPS",      settings.showFps,      worldH*0.78f)
        toggle("Left Joystick", settings.joystickLeft, worldH*0.86f)

        // Back
        pFill.color = 0x44FFFFFF; pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(10f, 8f, 150f, 64f), 10f, 10f, pFill)
        pText.color = 0xFFCCDDFF.toInt(); pText.textSize = 22f; pText.textAlign = Paint.Align.CENTER
        c.drawText("< Back", 80f, 46f, pText)
    }

    // ─── Tutorial ────────────────────────────────────────────────
    private fun drawTutorial(c: Canvas) {
        if (!tutorialShown || tutorialStep == TutorialStep.DONE || state.phase != Phase.PLAYING) return
        val msg = when (tutorialStep) {
            TutorialStep.MOVE         -> "Drag the LEFT side to move"
            TutorialStep.SHOOT_AUTO   -> "You shoot automatically!"
            TutorialStep.COLLECT_XP   -> "Collect glowing orbs for XP"
            TutorialStep.LEVEL_UP_INFO-> "Tap a card to pick an upgrade"
            TutorialStep.ABILITIES    -> "Tap ability buttons on the RIGHT"
            TutorialStep.DONE         -> return
        }
        pFill.color = 0xCC0A0C14.toInt(); pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(30f, worldH*0.80f, worldW-30f, worldH*0.80f+64f), 14f, 14f, pFill)
        pText.color = 0xFFCCEEFF.toInt(); pText.textSize = 22f; pText.textAlign = Paint.Align.CENTER
        c.drawText(msg, worldW/2f, worldH*0.80f+40f, pText)
    }

    // ─── Achievement toasts ───────────────────────────────────────
    private fun drawToasts(c: Canvas) {
        var ty = worldH * 0.22f
        for (toast in toasts) {
            val al = if (toast.life > 2.5f) 255 else (toast.life/2.5f*255f).toInt()
            val slide = (if (toast.life > 3f) (3.5f-toast.life)/0.5f else 1f).coerceIn(0f,1f)
            val w = 300f*slide
            pFill.color = (al shl 24) or 0x001A3322; pFill.style = Paint.Style.FILL
            c.drawRoundRect(RectF(worldW-w-8f, ty, worldW-8f, ty+56f), 12f, 12f, pFill)
            pText.color = (al shl 24) or 0xFFCC44; pText.textSize = 15f; pText.textAlign = Paint.Align.RIGHT
            c.drawText("ACHIEVEMENT", worldW-16f, ty+18f, pText)
            pText.color = (al shl 24) or 0xEEFFEE; pText.textSize = 20f
            c.drawText(toast.name, worldW-16f, ty+44f, pText)
            ty += 62f
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────
    private fun bar(c: Canvas, x: Float, y: Float, w: Float, h: Float, frac: Float, col: Int) {
        pFill.color = 0xFF111A22.toInt(); pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(x, y, x+w, y+h), h/2, h/2, pFill)
        pFill.color = col
        c.drawRoundRect(RectF(x, y, x+w*frac, y+h), h/2, h/2, pFill)
    }

    private fun drawMenuBtn(c: Canvas, cx: Float, top: Float, w: Float, h: Float,
                             label: String, bg: Int, border: Int) {
        pFill.color = bg; pFill.style = Paint.Style.FILL
        c.drawRoundRect(RectF(cx-w/2, top, cx+w/2, top+h), h/2, h/2, pFill)
        pStroke.color = border; pStroke.strokeWidth = 2.5f
        c.drawRoundRect(RectF(cx-w/2, top, cx+w/2, top+h), h/2, h/2, pStroke)
        pText.color = border; pText.textSize = 24f; pText.textAlign = Paint.Align.CENTER
        pText.isFakeBoldText = true; c.drawText(label, cx, top+h*0.64f, pText); pText.isFakeBoldText = false
    }

    private fun inBtn(rx: Float, ry: Float, cx: Float, top: Float, w: Float, h: Float) =
        rx in (cx-w/2)..(cx+w/2) && ry in top..(top+h)

    private fun enemyCol(t: EnemyType) = when (t) {
        EnemyType.BASIC        -> 0xFFCC3333.toInt(); EnemyType.FAST         -> 0xFFFF6600.toInt()
        EnemyType.TANK         -> 0xFF884422.toInt(); EnemyType.SHOOTER      -> 0xFF8833CC.toInt()
        EnemyType.SWARM        -> 0xFFCC4422.toInt(); EnemyType.CHARGER      -> 0xFFFF2200.toInt()
        EnemyType.RANGED       -> 0xFF994488.toInt(); EnemyType.EXPLODER     -> 0xFFFF8800.toInt()
        EnemyType.SHIELD_ENEMY -> 0xFF2244AA.toInt(); EnemyType.TELEPORTER   -> 0xFF8800CC.toInt()
        EnemyType.ELITE        -> 0xFFFF8C00.toInt(); EnemyType.BOSS         -> 0xFF880000.toInt()
    }

    private fun charCol(t: CharacterType) = when (t) {
        CharacterType.VOID_WALKER -> 0xFF44AAFF.toInt(); CharacterType.BERSERKER   -> 0xFFFF4422.toInt()
        CharacterType.SPECTER     -> 0xFF88FF88.toInt(); CharacterType.ARCANIST    -> 0xFFAA44FF.toInt()
    }
    private fun eventCol(e: EventType)  = when (e) {
        EventType.SWARM_RUSH  -> 0xFFFF4444.toInt(); EventType.DARKNESS    -> 0xFF8844FF.toInt()
        EventType.METEOR_RAIN -> 0xFFFF8800.toInt(); EventType.ELITE_ONLY  -> 0xFFFFD700.toInt()
        EventType.SLOW_MOTION -> 0xFF00CCFF.toInt()
    }
    private fun eventName(e: EventType) = when (e) {
        EventType.SWARM_RUSH  -> "SWARM RUSH";    EventType.DARKNESS    -> "DARKNESS"
        EventType.METEOR_RAIN -> "METEOR RAIN";   EventType.ELITE_ONLY  -> "ELITE ASSAULT"
        EventType.SLOW_MOTION -> "TIME DISTORTION"
    }
    private fun statusCol(t: StatusEffectType)  = when (t) {
        StatusEffectType.BURN   -> 0xFFFF5500.toInt(); StatusEffectType.POISON -> 0xFF44CC00.toInt()
        StatusEffectType.FREEZE -> 0xFF88DDFF.toInt(); StatusEffectType.SHOCK  -> 0xFFFFFF44.toInt()
        StatusEffectType.BLEED  -> 0xFFCC0044.toInt()
    }
    private fun statusIcon(t: StatusEffectType) = when (t) {
        StatusEffectType.BURN   -> "F"; StatusEffectType.POISON -> "P"
        StatusEffectType.FREEZE -> "Z"; StatusEffectType.SHOCK  -> "S"
        StatusEffectType.BLEED  -> "B"
    }
    private fun rarityCard  (r: Int) = when (r) { 3 -> 0xBB1A0A2A.toInt(); 2 -> 0xBB0A1A2A.toInt(); else -> 0xBB0A0A1A.toInt() }
    private fun rarityBorder(r: Int) = when (r) { 3 -> 0xFFAA44FF.toInt(); 2 -> 0xFF4488FF.toInt(); else -> 0xFF446688.toInt() }
    private fun rarityLabel (r: Int) = when (r) { 3 -> "★ EPIC"; 2 -> "◆ RARE"; else -> "· COMMON" }

    private fun blend(c1: Int, c2: Int, t: Float): Int {
        val r = ((c1 shr 16 and 0xFF) + ((c2 shr 16 and 0xFF) - (c1 shr 16 and 0xFF)) * t).toInt()
        val g = ((c1 shr  8 and 0xFF) + ((c2 shr  8 and 0xFF) - (c1 shr  8 and 0xFF)) * t).toInt()
        val b = ((c1        and 0xFF) + ((c2        and 0xFF) - (c1        and 0xFF)) * t).toInt()
        return 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
    }

    private fun vibrate(ms: Long) {
        if (!settings.vibration) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vibrator?.vibrate(ms)
        } catch (_: Exception) {}
    }

    // ─── Persistence ─────────────────────────────────────────────
    private fun saveSettings() {
        prefs.edit().putFloat("sfx_vol", settings.sfxVolume).putFloat("music_vol", settings.musicVolume)
            .putBoolean("vibration", settings.vibration).putFloat("hud_scale", settings.hudScale)
            .putInt("quality", settings.quality).putBoolean("joy_left", settings.joystickLeft)
            .putBoolean("show_fps", settings.showFps).apply()
    }
    private fun loadSettings() {
        settings.sfxVolume    = prefs.getFloat("sfx_vol",   0.75f)
        settings.musicVolume  = prefs.getFloat("music_vol", 0.40f)
        settings.vibration    = prefs.getBoolean("vibration", true)
        settings.hudScale     = prefs.getFloat("hud_scale", 1.0f)
        settings.quality      = prefs.getInt("quality", 2)
        settings.joystickLeft = prefs.getBoolean("joy_left", true)
        settings.showFps      = prefs.getBoolean("show_fps", false)
    }
    private fun saveMeta() {
        prefs.edit().putInt("currency", meta.currency).putInt("hp_level", meta.hpLevel)
            .putInt("speed_level", meta.speedLevel).putInt("cdr_level", meta.cdrLevel)
            .putInt("xp_level", meta.xpLevel).putString("start_ab", meta.startAbility?.name)
            .putInt("char_sel", meta.selectedCharacter.ordinal)
            .putInt("unlocked_chars", meta.unlockedCharsMask)
            .putLong("achieve_flags", meta.achievementFlags)
            .putInt("total_boss_kills", meta.totalBossKills)
            .putInt("total_status", meta.totalStatusApplied)
            .putInt("total_runs", meta.totalRuns)
            .putInt("best_wave", meta.bestWave).putInt("best_time", meta.bestTime).apply()
    }
    private fun loadMeta() {
        try {
            meta.currency           = prefs.getInt("currency", 0)
            meta.hpLevel            = prefs.getInt("hp_level", 0)
            meta.speedLevel         = prefs.getInt("speed_level", 0)
            meta.cdrLevel           = prefs.getInt("cdr_level", 0)
            meta.xpLevel            = prefs.getInt("xp_level", 0)
            meta.startAbility       = prefs.getString("start_ab", null)?.let { try { AbilityId.valueOf(it) } catch (_: Exception) { null } }
            meta.selectedCharacter  = CharacterType.values().getOrElse(prefs.getInt("char_sel", 0)) { CharacterType.VOID_WALKER }
            meta.unlockedCharsMask  = prefs.getInt("unlocked_chars", 1)
            meta.achievementFlags   = prefs.getLong("achieve_flags", 0L)
            meta.totalBossKills     = prefs.getInt("total_boss_kills", 0)
            meta.totalStatusApplied = prefs.getInt("total_status", 0)
            meta.totalRuns          = prefs.getInt("total_runs", 0)
            meta.bestWave           = prefs.getInt("best_wave", 0)
            meta.bestTime           = prefs.getInt("best_time", 0)
            selectedCharIdx         = meta.selectedCharacter.ordinal
        } catch (_: Exception) { prefs.edit().clear().apply() }
    }
}
