#pragma once
#include "Tensor.h"
#include <cstdint>
#include <vector>

namespace novallm {

// A tensor quantized to int8 with a single per-tensor symmetric scale:
// dequantize(q).data()[i] == q.data[i] * q.scale exactly (all the
// lossiness happens once, in quantize()). Symmetric (no zero-point) and
// per-tensor (one scale for the whole tensor, not per-row/per-channel) -
// the simplest scheme that's still correct and useful; per-channel
// scales are a plausible follow-up if per-tensor accuracy ever isn't
// enough (see quantize()'s doc comment for the observed error bound).
struct QuantizedTensor {
    std::vector<int8_t> data;
    std::vector<int> shape;
    float scale = 1.0f;

    size_t size() const;
    int rank() const;
    int dim(int axis) const;
};

// Maps every element of `t` through round(x / scale), clamped to
// [-127, 127] - 127, not 128, so the representable range stays
// symmetric around zero (int8 can hold -128, but using it would make
// the negative side one step longer than the positive side for no
// benefit here). scale = absmax(t) / 127, or 1.0f for an all-zero
// tensor (nothing to represent - avoids a divide by zero, and
// dequantizing gives back all zeros regardless of scale). Every
// element therefore quantizes to within +/- scale/2 of its original
// value; see tests/test_quantization.cpp for the error this actually
// produces end to end, through a real matmul and a real trained model.
QuantizedTensor quantize(const Tensor& t);

// Reconstructs an approximate float Tensor from a quantized one.
Tensor dequantize(const QuantizedTensor& q);

// Weight-only quantized matmul: `x` (activations) is float32, `wq` (a
// weight, after quantize()) is int8 + one scale; same {m,k}x{k,n}
// shape convention as matrix::matmul. Mathematically equivalent to
// dequantize(wq) then matrix::matmul(x, that) - scale is constant
// across the whole tensor, so it factors out of each output element's
// inner-product sum and gets applied once at the end instead of once
// per multiply-accumulate, which is both cheaper and exactly the same
// result. `wq` is never expanded into a full float32 copy - it stays
// int8 in memory throughout, dequantized value-by-value only inside
// this loop, which is the actual point of weight-only quantization: a
// ~4x smaller resident weight, not just a smaller file on disk.
Tensor quantizedMatmul(const Tensor& x, const QuantizedTensor& wq);

} // namespace novallm
