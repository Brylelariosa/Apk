// ============================================================================
// HZCM v4 — Renderer.cpp
//
// Key changes from v3:
//   1. LUT-driven vertex shader — all branching replaced with const-array
//      lookups.  Face direction drives vec3 selection with zero if/else.
//      Block colour is a flat 30-element vec3 array (10 blocks × 3 face groups).
//      This cuts Mali/Adreno vertex shader ALU pressure significantly.
//
//   2. DrawBatcher integration — world.gatherAndDraw() replaces the manual
//      cluster loop in Renderer::renderClusters().
//      The batcher sorts by mega-offset → sequential VBO reads, fewer
//      partial-tile flushes on tile-based GPUs.
//
//   3. Fog distance scaled by effective render radius so it always starts
//      at 80% of the render distance regardless of the rd setting.
//
//   4. Debug overlay: bottom-left rect showing render distance, thermal
//      state, visible cluster count. Updated every frame, zero cost.
//
//   5. Attribute setup moved into init (VAO carries the layout; only the
//      base pointer changes per cluster, driven by DrawBatcher).
// ============================================================================
#include "Renderer.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <shared_mutex>

#define TAG  "HZCMRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ============================================================================
// Vertex shader — LUT-driven, branchless face expansion  (GLES 3.0)
//
// All per-face geometry is driven by 6-element const arrays indexed by
// faceDir (0=+X,1=-X,2=+Y,3=-Y,4=+Z,5=-Z).
//
// Block colour is a 30-element vec3 array:
//   BLOCK_COL[blockType * 3 + faceGroup]
//   faceGroup: 0=side, 1=top(+Y), 2=bottom(-Y)
//
// AO: bilinear across the greedy quad, no branches.
// Fog: onset at 80% of uFogEnd, full at uFogEnd (set from render distance).
// ============================================================================
static const char* VERT_SRC = R"(#version 300 es
precision highp float;
precision highp int;

// Instanced PackedFace words (one per face instance)
layout(location = 0) in uint aGeom;
layout(location = 1) in uint aMat;

uniform ivec3 uClusterOrigin;
uniform mat4  uMVP;
uniform vec3  uCamPos;
uniform float uFogEnd;   // = effectiveRadius * 16.0 * 0.8

out vec3  vColor;
out float vFog;

// ── LUT: per-face-direction vectors ─────────────────────────────────────────
// sVec: tangent in the first span direction
// tVec: tangent in the second span direction
// nVec: outward normal (also the +1 offset applied to the face plane)
const vec3 FACE_S[6] = vec3[6](
    vec3(0,1,0), vec3(0,1,0),   // +X/-X : s=Y
    vec3(0,0,1), vec3(0,0,1),   // +Y/-Y : s=Z
    vec3(1,0,0), vec3(1,0,0)    // +Z/-Z : s=X
);
const vec3 FACE_T[6] = vec3[6](
    vec3(0,0,1), vec3(0,0,1),   // +X/-X : t=Z
    vec3(1,0,0), vec3(1,0,0),   // +Y/-Y : t=X
    vec3(0,1,0), vec3(0,1,0)    // +Z/-Z : t=Y
);
// ── Face-plane offset ─────────────────────────────────────────────────────────
// The mesher stores ox/oy/oz = pos[d] (the block position), NOT the face plane.
// BOTH the +X face of block A and the -X face of block B at the same boundary
// are at x = pos[d]+1.  So we ALWAYS add +1 along the normal axis — regardless
// of face direction sign.  The reversed winding in BACK_CI already handles the
// outward normal direction for negative faces; no separate sign is needed here.
// (Matches original v3 shader: "if (nAxis==0) lpos.x += 1.0; ...")
const vec3 FACE_N[6] = vec3[6](
    vec3(1,0,0), vec3(1,0,0),   // +X, -X  →  face at ox+1
    vec3(0,1,0), vec3(0,1,0),   // +Y, -Y  →  face at oy+1
    vec3(0,0,1), vec3(0,0,1)    // +Z, -Z  →  face at oz+1
);

// Per-face directional light multipliers
const float FACE_LIGHT[6] = float[6](0.65, 0.65, 1.0, 0.35, 0.80, 0.80);

// Quad corner (cs,ct) offsets in [span0,span1] units
// Front face (even faceDir): corners 0,1,2 then 0,2,3  (CCW)
// Back face  (odd faceDir):  corners 0,2,1 then 0,3,2  (CW → outward = CCW)
const int FRONT_CI[6] = int[6](0,1,2, 0,2,3);
const int BACK_CI [6] = int[6](0,2,1, 0,3,2);
// cs,ct for each of the 4 quad corners
const float CS4[4] = float[4](0.0, 1.0, 1.0, 0.0);
const float CT4[4] = float[4](0.0, 0.0, 1.0, 1.0);

// ── Block colour LUT ─────────────────────────────────────────────────────────
// 10 block types × 3 face groups (0=side, 1=top +Y, 2=bottom -Y)
// Index: blockType*3 + faceGroup
const vec3 BLOCK_COL[30] = vec3[30](
    // 0 AIR (unused, magenta)
    vec3(1,0,1), vec3(1,0,1), vec3(1,0,1),
    // 1 GRASS
    vec3(0.55,0.38,0.22), vec3(0.29,0.68,0.18), vec3(0.55,0.38,0.22),
    // 2 DIRT
    vec3(0.55,0.38,0.22), vec3(0.55,0.38,0.22), vec3(0.55,0.38,0.22),
    // 3 STONE
    vec3(0.50,0.50,0.50), vec3(0.50,0.50,0.50), vec3(0.50,0.50,0.50),
    // 4 SAND
    vec3(0.89,0.82,0.56), vec3(0.89,0.82,0.56), vec3(0.89,0.82,0.56),
    // 5 SNOW
    vec3(0.82,0.82,0.82), vec3(0.96,0.96,1.00), vec3(0.82,0.82,0.82),
    // 6 WOOD
    vec3(0.45,0.32,0.18), vec3(0.52,0.39,0.25), vec3(0.52,0.39,0.25),
    // 7 LEAVES
    vec3(0.20,0.52,0.12), vec3(0.20,0.52,0.12), vec3(0.20,0.52,0.12),
    // 8 WATER
    vec3(0.18,0.45,0.78), vec3(0.18,0.45,0.78), vec3(0.18,0.45,0.78),
    // 9 GRAVEL
    vec3(0.55,0.52,0.50), vec3(0.55,0.52,0.50), vec3(0.55,0.52,0.50)
);

void main() {
    int geom = int(aGeom);
    int mat  = int(aMat);

    // ── Unpack geometry word ─────────────────────────────────────────────────
    int faceDir = geom & 7;
    int ox      = (geom >>  3) & 15;
    int oy      = (geom >>  7) & 15;
    int oz      = (geom >> 11) & 15;
    int span0   = ((geom >> 15) & 15) + 1;
    int span1   = ((geom >> 19) & 15) + 1;

    // ── Unpack material word ─────────────────────────────────────────────────
    int btype = mat & 255;
    int ao0   = (mat >>  8) & 3;
    int ao1   = (mat >> 10) & 3;
    int ao2   = (mat >> 12) & 3;
    int ao3   = (mat >> 14) & 3;

    // ── Corner selection (branchless winding) ────────────────────────────────
    int vi = gl_VertexID % 6;
    // (faceDir & 1) == 0 → front face; == 1 → back face
    int cornerIdx = ((faceDir & 1) == 0) ? FRONT_CI[vi] : BACK_CI[vi];

    float cs = CS4[cornerIdx] * float(span0);
    float ct = CT4[cornerIdx] * float(span1);

    // ── Reconstruct world position (LUT, no branches) ────────────────────────
    vec3 lpos = vec3(float(ox), float(oy), float(oz));
    lpos += FACE_S[faceDir] * cs;
    lpos += FACE_T[faceDir] * ct;
    lpos += FACE_N[faceDir];   // +1 in normal direction (face offset)

    vec3 wpos = lpos + vec3(float(uClusterOrigin.x),
                             float(uClusterOrigin.y),
                             float(uClusterOrigin.z));

    // Fix #12: Camera-relative position for projection.
    // Instead of multiplying large world-space coords by MVP (float precision
    // loss at big coordinates), subtract the camera position first so the
    // value fed into the matrix multiply stays near zero.
    // uMVP is built from a view matrix with eye at origin (see Renderer.cpp).
    // uCamPos is still the true world position for fog distance.
    vec3 relPos = wpos - uCamPos;

    // ── AO (bilinear across greedy quad) ─────────────────────────────────────
    float aof0 = 0.35 + float(ao0) * 0.2167;
    float aof1 = 0.35 + float(ao1) * 0.2167;
    float aof2 = 0.35 + float(ao2) * 0.2167;
    float aof3 = 0.35 + float(ao3) * 0.2167;
    float su = (span0 > 0) ? cs / float(span0) : 0.0;
    float sv = (span1 > 0) ? ct / float(span1) : 0.0;
    float ao = mix(mix(aof0, aof1, su), mix(aof3, aof2, su), sv);

    // ── Block colour (LUT, zero branches) ────────────────────────────────────
    // faceGroup: 0=side, 1=top, 2=bottom
    int faceGroup = (faceDir == 2) ? 1 : (faceDir == 3) ? 2 : 0;
    int colIdx    = clamp(btype, 0, 9) * 3 + faceGroup;
    vec3 baseCol  = BLOCK_COL[colIdx];

    vColor = baseCol * (FACE_LIGHT[faceDir] * ao);

    // ── Fog (onset at 70% of uFogEnd) ────────────────────────────────────────
    // wpos - uCamPos = relPos (camera-relative distance)
    float dist = length(relPos);
    float fogStart = uFogEnd * 0.70;
    vFog = clamp((dist - fogStart) / (uFogEnd - fogStart + 0.001), 0.0, 1.0);

    // Fix #12: multiply camera-relative position by MVP (eye-at-origin view).
    // This eliminates float cancellation errors from large world coordinates.
    gl_Position = uMVP * vec4(relPos, 1.0);
}
)";

static const char* FRAG_SRC = R"(#version 300 es
precision mediump float;
in  vec3  vColor;
in  float vFog;
out vec4  fragColor;
const vec3 SKY = vec3(0.52, 0.77, 0.95);
void main() {
    fragColor = vec4(mix(vColor, SKY, vFog), 1.0);
}
)";

// ── Crosshair ─────────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
out vec4 o;
void main() { o = vec4(1.0, 1.0, 1.0, 0.8); }
)";

// ── Debug overlay (coloured quad + no-font digit rendering) ───────────────────
// We draw thermal pressure as a horizontal bar and a small colour indicator.
// Full text requires a font atlas which is out of scope; we show a colour bar.
static const char* DBG_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec3 aCol;
out vec3 vCol;
void main() { vCol = aCol; gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* DBG_FRAG = R"(#version 300 es
precision mediump float;
in  vec3 vCol;
out vec4 o;
void main() { o = vec4(vCol, 0.75); }
)";

// ── Shader helpers ────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512]; glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader error: %s", log);
        glDeleteShader(s); return 0;
    }
    return s;
}

GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[512]; glGetProgramInfoLog(p, sizeof(log), nullptr, log);
        LOGE("Link error: %s", log); glDeleteProgram(p); return 0;
    }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

// ── Init ───────────────────────────────────────────────────────────────────────
void Renderer::init() {
    LOGI("Renderer::init()");

    m_prog   = linkProgram(compileShader(GL_VERTEX_SHADER,   VERT_SRC),
                            compileShader(GL_FRAGMENT_SHADER, FRAG_SRC));
    m_uMVP    = glGetUniformLocation(m_prog, "uMVP");
    m_uCamPos = glGetUniformLocation(m_prog, "uCamPos");
    m_uOrigin = glGetUniformLocation(m_prog, "uClusterOrigin");
    // OPT v17: cache now, never call again inside render()
    m_uFogEnd = glGetUniformLocation(m_prog, "uFogEnd");
    GLint uFogEnd = m_uFogEnd;

    // Set initial fog end — will be updated each frame from effective radius
    glUseProgram(m_prog);
    glUniform1f(uFogEnd, (float)(world.getEffectiveRadius()) * 16.f * 0.8f);

    // Cluster VAO: set up the instanced attribute layout once.
    // DrawBatcher will re-point the base address per cluster via
    // glVertexAttribIPointer(offset) — the divisor stays.
    glGenVertexArrays(1, &m_clusterVao);
    glBindVertexArray(m_clusterVao);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glVertexAttribDivisor(0, 1);  // advance once per instance (face)
    glVertexAttribDivisor(1, 1);
    glBindVertexArray(0);

    world.megaBuffer().init();

    initHUD();
    initDebugOverlay();

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    glDepthFunc(GL_LEQUAL);
    glClearColor(SKY_R, SKY_G, SKY_B, 1.f);

    world.init(42);
    initialized = true;
    LOGI("Renderer init done. MegaBuffer: %.1f MB",
         (float)(world.megaBuffer().totalFaces() * sizeof(PackedFace)) / (1024.f*1024.f));
}

void Renderer::initHUD() {
    m_hudProg = linkProgram(compileShader(GL_VERTEX_SHADER, HUD_VERT),
                              compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    float s=0.02f, t=0.002f;
    float verts[] = {
        -s,-t, s,-t, s,t,  -s,-t, s,t, -s,t,
        -t,-s, t,-s, t,s,  -t,-s, t,s, -t,s,
    };
    glGenVertexArrays(1, &m_hudVao);
    glGenBuffers(1, &m_hudVbo);
    glBindVertexArray(m_hudVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_hudVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, nullptr);
    glBindVertexArray(0);
}

void Renderer::initDebugOverlay() {
    m_dbgProg = linkProgram(compileShader(GL_VERTEX_SHADER,   DBG_VERT),
                              compileShader(GL_FRAGMENT_SHADER, DBG_FRAG));
    glGenVertexArrays(1, &m_dbgVao);
    glGenBuffers(1, &m_dbgVbo);
    glBindVertexArray(m_dbgVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_dbgVbo);
    // Buffer size for dynamic data — updated each frame.
    // 3 bars × 6 verts + 1 pip × 6 verts = 24 verts × 5 floats × 4 bytes = 480 bytes.
    // Round up to 2 KB for headroom.
    glBufferData(GL_ARRAY_BUFFER, 2048, nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5*4, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5*4, (void*)(2*4));
    glBindVertexArray(0);
}

// ── Resize ─────────────────────────────────────────────────────────────────────
void Renderer::resize(int w, int h) {
    glViewport(0, 0, w, h);
    camera.aspect = (float)w / (float)h;
    LOGI("Resize %d×%d", w, h);
}

// ── Main render loop ───────────────────────────────────────────────────────────
void Renderer::render(float dt) {
    if (!initialized) return;

    // ── FPS EMA ───────────────────────────────────────────────────────────────
    // Smooth display: ~8-sample EMA damps single-frame spikes.
    // currentFps is read by jni_bridge::nativeGetDebugStats().
    if (dt > 0.f) {
        float fps = 1.f / dt;
        // Clamp outliers (first frame, suspend/resume) before EMA
        if (fps > 200.f) fps = 200.f;
        m_fpsEma  += 0.125f * (fps - m_fpsEma);
        currentFps = m_fpsEma;
    }

    camera.update(dt, reinterpret_cast<World*>(&world));

    float yaw = camera.yaw;
    world.update(camera.position.x, camera.position.z, camera.position.y,
                 0.f, 0.f, sinf(yaw), cosf(yaw), dt);

    world.updateGPU();

    // ── Push debug stats to overlay cache (read by Java at ~4 Hz) ────────────
    // Only collect when overlay is open to avoid overhead when not in use.
    // updateDebugStats() acquires a mutex; still negligible at 60 fps.
    if (m_debugOverlay.isVisible()) {
        WorldDebugStats s = world.getDebugStats(currentFps);
        m_debugOverlay.updateDebugStats(s);
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    Mat4    vp      = camera.getVP();
    // Fix #12: separate relative VP for chunk geometry (eye-at-origin).
    // The frustum uses the regular VP (world-space planes) for correct culling.
    // The shader receives relativeVP so it multiplies camera-relative coords,
    // eliminating float precision loss at large world coordinates.
    Mat4    relativeVP = camera.getRelativeVP();
    Frustum frustum = camera.getFrustum();

    // ── Cluster draw pass ─────────────────────────────────────────────────────
    glUseProgram(m_prog);
    // Fix #12: upload the camera-relative VP (not the world-space VP) so the
    // vertex shader's gl_Position = uMVP * vec4(wpos - uCamPos, 1.0) is correct.
    glUniformMatrix4fv(m_uMVP, 1, GL_FALSE, relativeVP.m);
    glUniform3fv(m_uCamPos, 1, &camera.position.x);

    // Update fog distance from current effective radius.
    // OPT v17: use cached m_uFogEnd — glGetUniformLocation() must NOT be
    // called per-frame (driver string lookup, ~0.1–0.3 ms on Mali/Adreno).
    {
        float fogEnd = (float)world.getEffectiveRadius() * 16.f * 0.80f;
        glUniform1f(m_uFogEnd, fogEnd);
    }

    // Bind mega-buffer and set up VAO attribute layout
    world.megaBuffer().bind();
    glBindVertexArray(m_clusterVao);
    // Note: glVertexAttribIPointer base addresses are overwritten per cluster
    // inside DrawBatcher::issueDraws — the VAO just carries the divisors.

    // Gather visible clusters, sort by mega-offset, issue all draws
    world.gatherAndDraw(frustum, m_uOrigin);

    glBindVertexArray(0);

    // ── HUD ───────────────────────────────────────────────────────────────────
    renderHUD();
    renderDebugOverlay();
}

// ── HUD (crosshair) ───────────────────────────────────────────────────────────
void Renderer::renderHUD() {
    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_hudProg);
    glBindVertexArray(m_hudVao);
    glDrawArrays(GL_TRIANGLES, 0, 12);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Debug overlay — thermal bar + render-distance bar + FPS health bar ────────
//
// Three horizontal bars rendered at the bottom-left of the screen, always
// visible (not gated by debugVisible).  They give instant visual feedback
// without requiring the full text overlay to be open.
//
//   Bar 1 (bottom): Thermal pressure   green→yellow→red  [0..100%]
//   Bar 2 (middle): Effective radius / MAX_DIST           [0..100%]
//   Bar 3 (top):    FPS health         green = fast, red = slow
//
// When the debug text overlay is active (debugVisible) a small white accent
// stripe is drawn at the far-right of the FPS bar to confirm the panel is open.
void Renderer::renderDebugOverlay() {
    float pressure = world.thermal().thermalPressure();
    float rdFrac   = (float)world.getEffectiveRadius()
                   / (float)RenderDistanceSystem::MAX_DIST;

    // FPS health: 0 = 0 fps, 1 = 60+ fps (clamp)
    float fpsFrac  = std::min(1.f, currentFps / 60.f);

    // Bar widths in NDC (from x = -0.98)
    float tw = -0.98f + pressure  * 1.20f;
    float rw = -0.98f + rdFrac    * 1.20f;
    float fw = -0.98f + fpsFrac   * 1.20f;

    // Thermal colour: green (cool) → yellow (warm) → red (hot)
    float tr = std::min(1.f, pressure * 2.f);
    float tg = std::min(1.f, (1.f - pressure) * 2.f);

    // FPS colour: green (fast) → red (slow)
    float fr = std::min(1.f, (1.f - fpsFrac) * 2.f);
    float fg = std::min(1.f, fpsFrac * 2.f);

    // 3 quads × 6 verts × 5 floats (x,y,r,g,b) = 90 floats
    float verts[90] = {
        // Bar 1 — Thermal pressure  (y: -0.98 to -0.93)
        -0.98f,-0.98f, tr,tg,0.f,
        tw,    -0.98f, tr,tg,0.f,
        tw,    -0.93f, tr,tg,0.f,
        -0.98f,-0.98f, tr,tg,0.f,
        tw,    -0.93f, tr,tg,0.f,
        -0.98f,-0.93f, tr,tg,0.f,
        // Bar 2 — Render distance   (y: -0.93 to -0.91)
        -0.98f,-0.93f, 1.f,1.f,1.f,
        rw,    -0.93f, 1.f,1.f,1.f,
        rw,    -0.91f, 1.f,1.f,1.f,
        -0.98f,-0.93f, 1.f,1.f,1.f,
        rw,    -0.91f, 1.f,1.f,1.f,
        -0.98f,-0.91f, 1.f,1.f,1.f,
        // Bar 3 — FPS health        (y: -0.91 to -0.89)
        -0.98f,-0.91f, fr,fg,0.f,
        fw,    -0.91f, fr,fg,0.f,
        fw,    -0.89f, fr,fg,0.f,
        -0.98f,-0.91f, fr,fg,0.f,
        fw,    -0.89f, fr,fg,0.f,
        -0.98f,-0.89f, fr,fg,0.f,
    };

    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_dbgProg);
    glBindVertexArray(m_dbgVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_dbgVbo);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(verts), verts);
    glDrawArrays(GL_TRIANGLES, 0, 18);

    // Debug-panel-open indicator: bright white pip at right edge of FPS bar
    if (m_debugOverlay.isVisible()) {
        float px = 0.20f;   // NDC x = right side of screen
        float py = -0.91f;
        float pipW = 0.015f, pipH = 0.02f;
        float pip[30] = {
            px,     py,      1.f,1.f,1.f,
            px+pipW,py,      1.f,1.f,1.f,
            px+pipW,py+pipH, 1.f,1.f,1.f,
            px,     py,      1.f,1.f,1.f,
            px+pipW,py+pipH, 1.f,1.f,1.f,
            px,     py+pipH, 1.f,1.f,1.f,
        };
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(pip), pip);
        glDrawArrays(GL_TRIANGLES, 0, 6);
    }

    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Destructor ─────────────────────────────────────────────────────────────────
Renderer::~Renderer() {
    if (m_prog)       glDeleteProgram(m_prog);
    if (m_hudProg)    glDeleteProgram(m_hudProg);
    if (m_dbgProg)    glDeleteProgram(m_dbgProg);
    if (m_hudVao)     glDeleteVertexArrays(1, &m_hudVao);
    if (m_hudVbo)     glDeleteBuffers(1, &m_hudVbo);
    if (m_dbgVao)     glDeleteVertexArrays(1, &m_dbgVao);
    if (m_dbgVbo)     glDeleteBuffers(1, &m_dbgVbo);
    if (m_clusterVao) glDeleteVertexArrays(1, &m_clusterVao);
}
