// ============================================================================
// HZCM v4 — Chunk.cpp
// ============================================================================
#include "Chunk.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <algorithm>

#define TAG "HZCMChunk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── Constructor ────────────────────────────────────────────────────────────────
Chunk::Chunk(int cx, int cz) : cx(cx), cz(cz) {
    memset(blocks, BLOCK_AIR, sizeof(blocks));
    for (int i = 0; i < CLUSTER_STACK; ++i) {
        clusterState[i].store(ClusterState::EMPTY, std::memory_order_relaxed);
        clusterGPUOffset[i] = MEGA_INVALID;
        clusterFaceCount[i] = 0;
        clusterDirtyGen[i]  = 0;
    }
}

// ── Terrain generation ─────────────────────────────────────────────────────────
//
// v18 layered terrain system:
//
//   Layer 1 — Continental base (fbm, very low freq ~0.004)
//     Broad hills and lowlands.  Drives sea-level / beach / plains splits.
//
//   Layer 2 — Mountain ridges (fbmRidged × continental mask, freq ~0.013)
//     Ridged noise × clamped continental value adds dramatic peaks ONLY in
//     already-elevated regions → separate mountain ranges, not random spikes.
//
//   Layer 3 — Detail (fbm, freq ~0.055)
//     Fine surface texture.  ±4 blocks.
//
// Biome surface block driven by:
//   • altitude (beach near sea level, stone/snow on peaks)
//   • temperature noise (large-scale, 0.005)
//
// Tree canopy uses an ellipsoidal 5-layer profile with probabilistic border
// thinning for an organic silhouette instead of a rectangular box.
//
void Chunk::generate(const Noise& noise) {

    // ── Constants ─────────────────────────────────────────────────────────────
    static constexpr int SEA_LEVEL = 24;   // water fills up to this y (inclusive)

    // Terrain height profile (all floats to avoid repeated int casts)
    //   base range:    14-38  (continental noise ±12 around 26)
    //   mountain add:   0-30  (ridged × mask × 30)
    //   detail:         ±4
    //   combined clamp: [2, CHUNK_H-4] = [2, 60]
    //
    // In practice:
    //   Deep ocean / shoreline: h ≈ 20-26
    //   Plains / gentle hills:  h ≈ 26-38
    //   Foothills:              h ≈ 38-46
    //   Mountains:              h ≈ 46-58
    //   High peaks (rare):      h ≈ 58-60

    for (int lz = 0; lz < CHUNK_D; ++lz) {
        for (int lx = 0; lx < CHUNK_W; ++lx) {
            const float wx = (float)(cx * CHUNK_W + lx);
            const float wz = (float)(cz * CHUNK_D + lz);

            // ── Height: three additive layers ─────────────────────────────────

            // Layer 1: continental base
            // Slight coordinate offsets on each layer prevent noise alignment.
            float baseN  = noise.fbm(wx * 0.004f,         wz * 0.004f,         4, 2.0f, 0.5f);
            float baseH  = 26.0f + baseN * 12.0f;   // [14, 38]

            // Layer 2: mountain mask (separate low-freq noise, different offset)
            // Clamped to [0,1] so mountains only grow in elevated regions.
            float maskN  = noise.fbm(wx * 0.003f + 50.0f, wz * 0.003f + 50.0f, 2, 2.0f, 0.5f);
            float mountMask = std::max(0.0f, std::min(1.0f, maskN));

            // Ridged noise for the mountain shape (separate offset again)
            float ridgeN  = noise.fbmRidged(wx * 0.013f + 10.0f, wz * 0.013f + 10.0f, 4, 2.0f, 0.5f);
            float mountainH = ridgeN * mountMask * 30.0f;   // [0, 30]

            // Layer 3: fine surface detail
            float detailN = noise.fbm(wx * 0.055f + 20.0f, wz * 0.055f + 20.0f, 3, 2.0f, 0.45f);
            float detailH  = detailN * 4.0f;   // [−4, +4]

            int h = (int)(baseH + mountainH + detailH);
            h = std::max(2, std::min(CHUNK_H - 4, h));

            // ── Biome ──────────────────────────────────────────────────────────
            // Temperature: large-scale noise, independent offsets
            float tempN = noise.noise2D(wx * 0.005f + 300.0f, wz * 0.005f + 300.0f);
            //   tempN > +0.40 → cold biome (snow on flat land)
            //   tempN < -0.35 → hot/dry biome (desert sand)
            //   otherwise     → temperate (grass)

            bool isBeach       = (h <= SEA_LEVEL + 2);
            bool isMidMountain = (h >= 40);
            bool isHighPeak    = (h >= 50);

            uint8_t surfBlock;
            if (isBeach) {
                surfBlock = BLOCK_SAND;       // shoreline / beach
            } else if (isHighPeak) {
                // High peaks: always snow unless very warm; bare stone otherwise
                surfBlock = (tempN > -0.1f) ? BLOCK_SNOW : BLOCK_STONE;
            } else if (isMidMountain) {
                // Mid mountains: stone default, snow only in cold regions
                surfBlock = (tempN > 0.3f) ? BLOCK_SNOW : BLOCK_STONE;
            } else if (tempN > 0.40f) {
                surfBlock = BLOCK_SNOW;       // cold flat / hilly area
            } else if (tempN < -0.35f) {
                surfBlock = BLOCK_SAND;       // hot desert
            } else {
                surfBlock = BLOCK_GRASS;
            }

            // ── Fill blocks ────────────────────────────────────────────────────
            //
            // Sub-surface (h-3 .. h-1):
            //   • Mountain zones (h≥40): always stone — cliffs look natural
            //   • Sand surfaces: fill sand through the 3 sub-surface layers
            //   • Grass/snow on flat land: dirt
            bool mountainZone = (h >= 40);

            for (int ly = 0; ly < CHUNK_H; ++ly) {
                uint8_t bt = BLOCK_AIR;
                if (ly == 0) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 4) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 1) {
                    // Sub-surface fill
                    if (surfBlock == BLOCK_SAND) bt = BLOCK_SAND;
                    else if (mountainZone)       bt = BLOCK_STONE;
                    else                         bt = BLOCK_DIRT;
                } else if (ly == h) {
                    bt = surfBlock;
                } else if (ly <= SEA_LEVEL && h < SEA_LEVEL) {
                    bt = BLOCK_WATER;
                }
                setBlock(lx, ly, lz, bt);
            }

            // ── Trees (grass biome only, not too close to chunk top) ──────────
            //
            // v18 canopy: 5-layer ellipsoidal profile [dy = -2 .. +2 from trunk top]
            // with probabilistic border thinning for an organic silhouette.
            //
            //   Layer dy=-2: small lower skirt (r²≈1.5 → ~3×3)
            //   Layer dy=-1: full lower canopy (r²≈5.0 → ~5×5 rounded)
            //   Layer dy= 0: widest layer      (r²≈5.5 → ~5×5 full)
            //   Layer dy=+1: upper canopy       (r²≈4.5 → ~5×5 tight)
            //   Layer dy=+2: small cap          (r²≈1.5 → ~3×3)
            //
            // Border voxels (distSq > maxRsq - 0.5) have a 25% chance to be
            // skipped, breaking up straight edges into an irregular silhouette.
            // All randomness is seeded from chunk coords + block coords, so the
            // canopy is fully deterministic.
            if (surfBlock == BLOCK_GRASS && h < CHUNK_H - 10) {
                unsigned seed = (unsigned)(cx * 7919 + lx * 131 + cz * 4001 + lz * 37);
                seed = seed * 1664525u + 1013904223u;

                // ~5% tree probability
                if ((seed & 0xFF) < 13u) {
                    int treeH = 4 + (int)((seed >> 8) & 3);   // 4–7 blocks

                    // Trunk
                    for (int ty = h + 1; ty <= h + treeH; ++ty)
                        if (ty < CHUNK_H) setBlock(lx, ty, lz, BLOCK_WOOD);

                    // Canopy profile: max horizontal radius² at each dy offset
                    static const float LEAF_RSQ[5] = {
                        1.5f,   // dy = -2  lower skirt
                        5.0f,   // dy = -1  lower canopy
                        5.5f,   // dy =  0  widest band
                        4.5f,   // dy = +1  upper
                        1.5f,   // dy = +2  cap
                    };

                    int top = h + treeH;
                    for (int dyIdx = 0; dyIdx < 5; ++dyIdx) {
                        int dy  = dyIdx - 2;          // map 0..4 → -2..+2
                        int ly2 = top + dy;
                        if (ly2 < 0 || ly2 >= CHUNK_H) continue;

                        float maxRsq = LEAF_RSQ[dyIdx];
                        int   maxR   = (int)sqrtf(maxRsq) + 1;

                        for (int dx = -maxR; dx <= maxR; ++dx) {
                            for (int dz2 = -maxR; dz2 <= maxR; ++dz2) {
                                float distSq = (float)(dx * dx + dz2 * dz2);
                                if (distSq > maxRsq + 0.5f) continue;

                                // Probabilistic border thinning: 25% chance to
                                // skip voxels at the outer edge of each layer.
                                if (distSq > maxRsq - 0.5f) {
                                    unsigned ls = seed
                                        ^ (unsigned)(dx * 37 + dz2 * 53 + dy * 97);
                                    ls = ls * 1664525u + 1013904223u;
                                    if ((ls & 3) == 0) continue;
                                }

                                int lx2 = lx + dx;
                                int lz3 = lz + dz2;
                                if (lx2 >= 0 && lx2 < CHUNK_W &&
                                    lz3 >= 0 && lz3 < CHUNK_D)
                                    if (getBlock(lx2, ly2, lz3) == BLOCK_AIR)
                                        setBlock(lx2, ly2, lz3, BLOCK_LEAVES);
                            }
                        }
                    }
                }
            }

            // ── Gravel patches (unchanged; seam-safe per-block seeding) ────────
            {
                unsigned seed2 = (unsigned)(cx * 1231 + lx * 53 + cz * 9973 + lz * 73);
                seed2 = seed2 * 1664525u + 1013904223u;
                if ((seed2 & 0xFF) < 20u) {
                    int gy = 2 + (int)((seed2 >> 8) & 15);
                    if (gy < h - 4) setBlock(lx, gy, lz, BLOCK_GRAVEL);
                }
            }
        }
    }

    generated.store(true, std::memory_order_release);
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        clusterState[ci].store(ClusterState::DIRTY, std::memory_order_release);
        clusterDirtyGen[ci]++;
    }
}

// ── Extract 16³ voxels for cluster ci ─────────────────────────────────────────
void Chunk::extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const {
    const int baseY = ci * CL_SIZE;
    for (int z = 0; z < CL_SIZE; ++z) {
        for (int y = 0; y < CL_SIZE; ++y) {
            const uint8_t* src = &blocks[0 + CHUNK_W * ((baseY + y) + CHUNK_H * z)];
            uint8_t*       dst = &out[0 + CL_SIZE * (y + CL_SIZE * z)];
            memcpy(dst, src, CL_SIZE);
        }
    }
}

// ── Build cluster mesh ─────────────────────────────────────────────────────────
void Chunk::buildClusterMesh(int ci,
                               const Chunk* nxC, const Chunk* pxC,
                               const Chunk* nzC, const Chunk* pzC)
{
    static thread_local uint8_t selfVox[CL_VOLUME];
    static thread_local uint8_t nxVox[CL_VOLUME], pxVox[CL_VOLUME];
    static thread_local uint8_t nyVox[CL_VOLUME], pyVox[CL_VOLUME];
    static thread_local uint8_t nzVox[CL_VOLUME], pzVox[CL_VOLUME];

    extractClusterVoxels(ci, selfVox);

    NeighbourVoxels nb;
    if (nxC && nxC->generated.load(std::memory_order_acquire))
        { nxC->extractClusterVoxels(ci, nxVox); nb.nx = nxVox; }
    if (pxC && pxC->generated.load(std::memory_order_acquire))
        { pxC->extractClusterVoxels(ci, pxVox); nb.px = pxVox; }
    if (nzC && nzC->generated.load(std::memory_order_acquire))
        { nzC->extractClusterVoxels(ci, nzVox); nb.nz = nzVox; }
    if (pzC && pzC->generated.load(std::memory_order_acquire))
        { pzC->extractClusterVoxels(ci, pzVox); nb.pz = pzVox; }
    if (ci > 0)               { extractClusterVoxels(ci - 1, nyVox); nb.ny = nyVox; }
    if (ci < CLUSTER_STACK-1) { extractClusterVoxels(ci + 1, pyVox); nb.py = pyVox; }

    std::vector<PackedFace> localFaces;
    ClusterMesher::buildCluster(selfVox, nb, localFaces);

    {
        std::lock_guard<std::mutex> lock(clusterMutex[ci]);
        clusterFaces[ci] = std::move(localFaces);
    }
    clusterState[ci].store(ClusterState::MESHED, std::memory_order_release);
}

// ── AABB ───────────────────────────────────────────────────────────────────────
void Chunk::getAABB(float& mnX, float& mnY, float& mnZ,
                     float& mxX, float& mxY, float& mxZ) const {
    mnX = (float)(cx * CHUNK_W); mnY = 0.f;            mnZ = (float)(cz * CHUNK_D);
    mxX = mnX + CHUNK_W;         mxY = (float)CHUNK_H; mxZ = mnZ + CHUNK_D;
}
