#include "Attention.h"
#include "../math/Matrix.h"
#include <cmath>
#include <stdexcept>
#include <ostream>
#include <istream>

namespace novallm {

MultiHeadAttention::MultiHeadAttention(int embedDim, int numHeads, unsigned int seed)
    : embedDim_(embedDim), numHeads_(numHeads), headDim_(embedDim / numHeads),
      wq_(embedDim, embedDim, seed, true),
      wk_(embedDim, embedDim, seed + 1, true),
      wv_(embedDim, embedDim, seed + 2, true),
      wo_(embedDim, embedDim, seed + 3, true) {
    if (embedDim % numHeads != 0) {
        throw std::invalid_argument("MultiHeadAttention: embedDim must be divisible by numHeads");
    }
}

Tensor MultiHeadAttention::forward(const Tensor& x) const {
    int seqLen = x.dim(0);

    Tensor q = wq_.forward(x); // {seqLen, embedDim}
    Tensor k = wk_.forward(x);
    Tensor v = wv_.forward(x);

    Tensor concatOut({seqLen, embedDim_});
    float scaleFactor = 1.0f / std::sqrt(static_cast<float>(headDim_));

    for (int h = 0; h < numHeads_; ++h) {
        Tensor qh = matrix::sliceColumns(q, h * headDim_, headDim_); // {seqLen, headDim}
        Tensor kh = matrix::sliceColumns(k, h * headDim_, headDim_);
        Tensor vh = matrix::sliceColumns(v, h * headDim_, headDim_);

        Tensor khT = matrix::transpose(kh);                 // {headDim, seqLen}
        Tensor scores = matrix::matmul(qh, khT);             // {seqLen, seqLen}
        scores = matrix::scale(scores, scaleFactor);

        // Causal mask: query position i must not see key position j > i.
        for (int i = 0; i < seqLen; ++i) {
            for (int j = i + 1; j < seqLen; ++j) {
                scores.at({i, j}) = -1e9f;
            }
        }

        matrix::softmaxRows(scores); // row-wise, in place

        Tensor headOut = matrix::matmul(scores, vh); // {seqLen, headDim}
        matrix::setColumns(concatOut, h * headDim_, headOut);
    }

    return wo_.forward(concatOut);
}

Tensor MultiHeadAttention::forwardIncremental(const Tensor& x, KVCache& cache) const {
    int newLen = x.dim(0);

    Tensor qNew = wq_.forward(x); // {newLen, embedDim} - only new positions need new Q
    Tensor kNew = wk_.forward(x); // {newLen, embedDim}
    Tensor vNew = wv_.forward(x);

    int startPos = cache.append(kNew, vNew); // record this step's K/V, get its global offset
    Tensor kAll = cache.keys();               // {totalLen, embedDim} - everything so far
    Tensor vAll = cache.values();
    int totalLen = kAll.dim(0);

    Tensor concatOut({newLen, embedDim_});
    float scaleFactor = 1.0f / std::sqrt(static_cast<float>(headDim_));

    for (int h = 0; h < numHeads_; ++h) {
        Tensor qh = matrix::sliceColumns(qNew, h * headDim_, headDim_); // {newLen, headDim}
        Tensor kh = matrix::sliceColumns(kAll, h * headDim_, headDim_); // {totalLen, headDim}
        Tensor vh = matrix::sliceColumns(vAll, h * headDim_, headDim_); // {totalLen, headDim}

        Tensor khT = matrix::transpose(kh);      // {headDim, totalLen}
        Tensor scores = matrix::matmul(qh, khT); // {newLen, totalLen}
        scores = matrix::scale(scores, scaleFactor);

        // Causal mask against GLOBAL position, not local row index: new
        // row i actually sits at position startPos+i in the full sequence
        // and may only attend to cached positions up to and including it.
        for (int i = 0; i < newLen; ++i) {
            int globalPos = startPos + i;
            for (int j = globalPos + 1; j < totalLen; ++j) {
                scores.at({i, j}) = -1e9f;
            }
        }

        matrix::softmaxRows(scores);

        Tensor headOut = matrix::matmul(scores, vh); // {newLen, headDim}
        matrix::setColumns(concatOut, h * headDim_, headOut);
    }

    return wo_.forward(concatOut);
}

void MultiHeadAttention::save(std::ostream& out) const {
    wq_.save(out);
    wk_.save(out);
    wv_.save(out);
    wo_.save(out);
}

void MultiHeadAttention::load(std::istream& in) {
    wq_.load(in);
    wk_.load(in);
    wv_.load(in);
    wo_.load(in);
    embedDim_ = wq_.outDim();
}

} // namespace novallm
