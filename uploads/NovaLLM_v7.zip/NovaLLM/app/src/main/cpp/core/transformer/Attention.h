#pragma once
#include "../math/Tensor.h"
#include "Linear.h"
#include "KVCache.h"
#include <iosfwd>

namespace novallm {

// Causal (decoder-only) multi-head self-attention. Position i can only
// attend to positions <= i - this is what makes autoregressive generation
// valid at all. There is no non-causal mode: this is a text-generation
// engine, not a bidirectional encoder.
class MultiHeadAttention {
public:
    MultiHeadAttention(int embedDim, int numHeads, unsigned int seed = 42);

    // x: {seqLen, embedDim} -> {seqLen, embedDim}. Full recompute every
    // call - used for training / whole-sequence scoring, not generation.
    Tensor forward(const Tensor& x) const;

    // x: {newLen, embedDim} - JUST the new token(s) since the last call
    // (the whole prompt on the first call, then newLen==1 per step after).
    // Appends this step's K/V to `cache` and attends the new position(s)
    // against the FULL cached history. Returns {newLen, embedDim} - only
    // the new positions' outputs, mathematically identical to what
    // forward() would produce for those same positions given the whole
    // sequence, just without redoing the earlier positions' work.
    Tensor forwardIncremental(const Tensor& x, KVCache& cache) const;

    int embedDim() const { return embedDim_; }
    int numHeads() const { return numHeads_; }
    int headDim() const { return headDim_; }

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    int embedDim_;
    int numHeads_;
    int headDim_;
    Linear wq_, wk_, wv_, wo_;
};

} // namespace novallm
