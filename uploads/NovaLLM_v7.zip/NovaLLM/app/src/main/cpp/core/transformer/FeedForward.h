#pragma once
#include "../math/Tensor.h"
#include "Linear.h"
#include <iosfwd>

namespace novallm {

// Position-wise feed-forward network: fc2(gelu(fc1(x))).
// hiddenDim is conventionally 4x embedDim. Purely per-row/per-position -
// no cross-token interaction - so it needs no separate "incremental"
// variant for generation: calling forward() on just the new token(s) is
// already exactly correct.
class FeedForward {
public:
    struct Grads {
        Tensor gradInput;          // {seqLen, embedDim} - flows further back
        Tensor gradW1, gradB1;     // fc1_'s weight/bias gradients
        Tensor gradW2, gradB2;     // fc2_'s weight/bias gradients
    };

    FeedForward(int embedDim, int hiddenDim, unsigned int seed = 42);

    // x: {seqLen, embedDim} -> {seqLen, embedDim}
    Tensor forward(const Tensor& x) const;

    // Recomputes the fc1/gelu intermediate internally rather than caching
    // it from forward() - keeps the interface simple at the cost of one
    // redundant fc1 pass per backward call.
    Grads backward(const Tensor& x, const Tensor& gradOutput) const;

    void save(std::ostream& out) const;
    void load(std::istream& in);

private:
    Linear fc1_; // embedDim -> hiddenDim
    Linear fc2_; // hiddenDim -> embedDim
};

// GELU activation (tanh approximation, same one GPT-2 uses).
float gelu(float x);

// d(gelu)/dx, same tanh approximation, differentiated analytically.
float geluGrad(float x);

} // namespace novallm
