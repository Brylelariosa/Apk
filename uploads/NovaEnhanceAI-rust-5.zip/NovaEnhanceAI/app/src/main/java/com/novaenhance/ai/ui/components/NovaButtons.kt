package com.novaenhance.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The app's shared button building blocks.
 *
 * Every screen used to lay its buttons out at the end of its scrolling content, so the one you wanted (Save, Start
 * Training, Import ...) was often below the fold. The rule now: the action a screen is *for* lives in a
 * [NovaBottomBar] that stays on screen, and every button is at least [NovaButtonMinHeight] tall - well above the
 * 48dp touch-target minimum, so it is easy to hit with a thumb.
 */
val NovaButtonMinHeight: Dp = 56.dp

enum class NovaButtonStyle { Filled, Tonal, Outlined }

/** A big, easy-to-tap button: [NovaButtonMinHeight] tall, with an optional leading icon. */
@Composable
fun NovaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: NovaButtonStyle = NovaButtonStyle.Filled,
    enabled: Boolean = true,
    iconRes: Int? = null
) {
    val sized = modifier.heightIn(min = NovaButtonMinHeight)
    val content: @Composable RowScope.() -> Unit = {
        if (iconRes != null) {
            Icon(painter = painterResource(iconRes), contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(text = text, textAlign = TextAlign.Center)
    }
    when (style) {
        NovaButtonStyle.Filled -> Button(onClick = onClick, modifier = sized, enabled = enabled, content = content)
        NovaButtonStyle.Tonal -> FilledTonalButton(onClick = onClick, modifier = sized, enabled = enabled, content = content)
        NovaButtonStyle.Outlined -> OutlinedButton(onClick = onClick, modifier = sized, enabled = enabled, content = content)
    }
}

/**
 * A bar pinned to the bottom of a screen for the actions that screen is about. Its content is a [Column], so a bar
 * can hold a row of buttons, a progress line above them, or a one-line hint - whatever the screen needs - and it
 * keeps clear of the system navigation bar.
 */
@Composable
fun NovaBottomBar(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        tonalElevation = 3.dp,
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            content = content
        )
    }
}

/** A large tappable tile with an icon above its label: the Dashboard's way of offering a destination. */
@Composable
fun ActionTile(
    label: String,
    iconRes: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    emphasized: Boolean = false,
    minHeight: Dp = 96.dp
) {
    val container = if (emphasized) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val onContainer = if (emphasized) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = container, contentColor = onContainer)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = minHeight)
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(painter = painterResource(iconRes), contentDescription = null, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = label, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        }
    }
}
