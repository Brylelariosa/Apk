package com.gary.voidsurvivors

import kotlin.math.*
import kotlin.random.Random

// ═══════════════════════════════════════════════════════════════
//  Vec2
// ═══════════════════════════════════════════════════════════════

data class Vec2(var x: Float, var y: Float) {
    fun len() = sqrt(x * x + y * y)
    fun norm(): Vec2 { val l = len(); return if (l > 0.001f) Vec2(x / l, y / l) else Vec2(0f, 0f) }
    operator fun plus(o: Vec2)   = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2)  = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
}

// ═══════════════════════════════════════════════════════════════
//  Enums
// ═══════════════════════════════════════════════════════════════

enum class StatusEffectType { BURN, POISON, FREEZE, SHOCK, BLEED }

enum class EnemyType {
    BASIC, FAST, TANK, SHOOTER, SWARM,
    CHARGER, RANGED, EXPLODER, SHIELD_ENEMY, TELEPORTER, ELITE, BOSS
}

enum class Phase { PLAYING, LEVEL_UP, DEAD, PAUSED, SETTINGS, CHARACTER_SELECT }

enum class AbilityId { DASH, SHOCKWAVE, BLACK_HOLE, TIME_SLOW, SHIELD_PULSE, ENERGY_ORB }

enum class UpType {
    DAMAGE, FIRE_RATE, MAX_HP, SPEED, EXTRA_PROJ, REGEN, MAGNET, HEAL_NOW, RANGE,
    CDR, AREA, LIFESTEAL, CRIT, DMG_MULT,
    UNLOCK_AB, EVOLVE,
    PIERCING, CHAIN_SHOT, ARMOR,
    STATUS_BURN, STATUS_FREEZE, STATUS_SHOCK
}

enum class EvoType { FLAME_DASH, ICE_ORB, INFINITE_PULSE, SINGULARITY_BURST }

enum class EventType { SWARM_RUSH, DARKNESS, METEOR_RAIN, ELITE_ONLY, SLOW_MOTION }

enum class CharacterType { VOID_WALKER, BERSERKER, SPECTER, ARCANIST }

// ═══════════════════════════════════════════════════════════════
//  Character Definitions
// ═══════════════════════════════════════════════════════════════

data class CharacterDef(
    val type: CharacterType,
    val name: String,
    val tagline: String,
    val hpMult: Float       = 1f,
    val speedMult: Float    = 1f,
    val damageMult: Float   = 1f,
    val fireRateMult: Float = 1f,
    val startAbility: AbilityId? = null,
    val unlockCost: Int     = 0
)

object Characters {
    val ALL: List<CharacterDef> = listOf(
        CharacterDef(CharacterType.VOID_WALKER, "Void Walker",
            "Balanced fighter with a built-in Dash.",
            startAbility = AbilityId.DASH),
        CharacterDef(CharacterType.BERSERKER, "Berserker",
            "+50% DMG  /  +20% SPD  /  -20% HP",
            hpMult = 0.8f, speedMult = 1.2f, damageMult = 1.5f,
            unlockCost = 30),
        CharacterDef(CharacterType.SPECTER, "Specter",
            "+40% SPD  /  +30% ATK SPD  /  -20% DMG",
            speedMult = 1.4f, damageMult = 0.8f, fireRateMult = 1.3f,
            unlockCost = 50),
        CharacterDef(CharacterType.ARCANIST, "Arcanist",
            "+50% HP  /  +30% AoE  /  Shockwave unlocked",
            hpMult = 1.5f, speedMult = 0.85f,
            startAbility = AbilityId.SHOCKWAVE,
            unlockCost = 75)
    )
}

// ═══════════════════════════════════════════════════════════════
//  Achievements
// ═══════════════════════════════════════════════════════════════

data class AchievementDef(val id: String, val name: String, val desc: String, val bit: Int)

object AchievementList {
    val ALL: List<AchievementDef> = listOf(
        AchievementDef("first_kill",    "First Blood",       "Kill your first enemy",             0),
        AchievementDef("kill_50",       "Slayer",            "Kill 50 enemies in one run",        1),
        AchievementDef("kill_200",      "Centurion",         "Kill 200 enemies in one run",       2),
        AchievementDef("survive_5min",  "Survivor",          "Survive 5 minutes",                 3),
        AchievementDef("survive_10min", "Veteran",           "Survive 10 minutes",                4),
        AchievementDef("reach_lv10",    "Power Surge",       "Reach level 10",                    5),
        AchievementDef("reach_lv20",    "Ascendant",         "Reach level 20",                    6),
        AchievementDef("kill_boss",     "Boss Slayer",       "Defeat your first boss",            7),
        AchievementDef("kill_5bosses",  "Apex Predator",     "Defeat 5 bosses total",             8),
        AchievementDef("combo_10",      "Combo King",        "Get a 10-kill combo",               9),
        AchievementDef("combo_20",      "Killing Machine",   "Get a 20-kill combo",              10),
        AchievementDef("get_evo",       "Evolved",           "Unlock your first evolution",      11),
        AchievementDef("open_chest",    "Treasure Hunter",   "Open a treasure chest",            12),
        AchievementDef("wave_15",       "Relentless",        "Reach wave 15",                    13),
        AchievementDef("wave_20",       "No Rest",           "Reach wave 20",                    14),
        AchievementDef("status_100",    "Affliction",        "Apply 100 status effects in total",15)
    )
    fun isUnlocked(flags: Long, bit: Int): Boolean = (flags and (1L shl bit)) != 0L
    fun unlock(flags: Long, bit: Int): Long         = flags or (1L shl bit)
}

// ═══════════════════════════════════════════════════════════════
//  Status Effect
// ═══════════════════════════════════════════════════════════════

data class StatusEffect(
    val type: StatusEffectType,
    var duration: Float,
    val dps: Float        = 0f,
    val slowFactor: Float = 1f
)

// ═══════════════════════════════════════════════════════════════
//  Player
// ═══════════════════════════════════════════════════════════════

class Player(worldW: Float, worldH: Float) {
    var x = worldW / 2f;  var y = worldH / 2f
    val radius = 26f
    var speed = 280f;    var maxHp = 100f;    var hp = 100f
    var xp = 0f;         var xpNext = 60f;    var level = 1
    var damage = 20f;    var fireRate = 1.4f; var fireTimer = 0f
    var projectiles = 1; var range = 300f
    var regen = 0f;      var magnet = 85f;    var iFrames = 0f
    val iFrameLen = 0.35f
    var lifesteal  = 0f
    var critChance = 0f
    val critMult   = 2.2f
    var areaScale  = 1f
    var cdr        = 0f
    var dmgMult    = 1f
    var xpGain     = 1f
    var armor          = 0f
    var piercingShots  = 0
    var chainShots     = 0
    var burnChance     = 0f
    var freezeChance   = 0f
    var shockChance    = 0f
    var knockbackMult  = 1f
    var isDashing    = false; var dashTimer = 0f
    var dashVx       = 0f;    var dashVy   = 0f
    val dashDuration = 0.18f; val dashSpeed = 950f
    var shieldActive = false; var shieldTimer = 0f
    val shieldDuration = 2.5f
    var orbAngle = 0f; var orbBurst = false; var orbBurstTimer = 0f
    var isMoving = false; var facingAngle = 0f
    var hitFlashTimer = 0f
}

// ═══════════════════════════════════════════════════════════════
//  Ability
// ═══════════════════════════════════════════════════════════════

class Ability(val id: AbilityId, val baseCd: Float, var level: Int = 0) {
    var cdTimer = 0f
    fun effectiveCd(cdr: Float) = (baseCd * (1f - cdr)).coerceAtLeast(0.5f)
    fun isReady() = level > 0 && cdTimer <= 0f
    val label get() = when (id) {
        AbilityId.DASH         -> "DASH"
        AbilityId.SHOCKWAVE    -> "WAVE"
        AbilityId.BLACK_HOLE   -> "HOLE"
        AbilityId.TIME_SLOW    -> "SLOW"
        AbilityId.SHIELD_PULSE -> "SHLD"
        AbilityId.ENERGY_ORB   -> "ORB"
    }
}

// ═══════════════════════════════════════════════════════════════
//  Enemy
// ═══════════════════════════════════════════════════════════════

class Enemy(
    var x: Float, var y: Float,
    val radius: Float, val baseSpeed: Float,
    val maxHp: Float, var hp: Float,
    val contactDmg: Float, val xpDrop: Float,
    val type: EnemyType
) {
    var speed        = baseSpeed
    var shootTimer   = 2f + Random.nextFloat()
    var flashTimer   = 0f
    var chargeTimer  = 2f;  var isCharging = false
    var chargeVx     = 0f;  var chargeVy   = 0f
    var teleportCd   = 3f + Random.nextFloat() * 2f
    var shieldHp     = 0f;  var maxShieldHp = 0f; var shieldBroken = false
    var bossPhase    = 0;   var summonTimer  = 6f; var rageActive = false
    val statusEffects    = mutableListOf<StatusEffect>()
    var frozenSlowFactor = 1f
    var isShocked        = false
    var shockDmgMult     = 1f
}

// ═══════════════════════════════════════════════════════════════
//  Bullet  (regular class to allow mutable hitEnemies set)
// ═══════════════════════════════════════════════════════════════

class Bullet(
    var x: Float, var y: Float,
    val vx: Float, val vy: Float,
    var damage: Float, val radius: Float,
    var life: Float, val fromPlayer: Boolean,
    var piercesLeft: Int = 0,
    var chainLeft: Int = 0,
    val statusType: StatusEffectType? = null,
    val statusChance: Float = 0f
) {
    val hitEnemies: MutableSet<Enemy> = mutableSetOf()
}

// ═══════════════════════════════════════════════════════════════
//  XPOrb / FloatText / Upgrade / BlackHole / EventAnnouncement
// ═══════════════════════════════════════════════════════════════

data class XPOrb(var x: Float, var y: Float, val value: Float = 5f, val radius: Float = 7f)

class FloatText(
    var x: Float, var y: Float, val text: String,
    var life: Float, val color: Int,
    val scale: Float = 1f, val isCrit: Boolean = false
)

data class Upgrade(
    val type: UpType, val name: String, val desc: String, val rarity: Int,
    val abilityId: AbilityId? = null, val evoType: EvoType? = null
)

class BlackHole(var x: Float, var y: Float, val radius: Float, var life: Float, val maxLife: Float)

class EventAnnouncement(val type: EventType, var warningTimer: Float = 2.5f)

// ═══════════════════════════════════════════════════════════════
//  Particle pool  (pre-allocated, zero GC)
// ═══════════════════════════════════════════════════════════════

class Particle {
    var active = false
    var x = 0f; var y = 0f; var vx = 0f; var vy = 0f
    var life = 0f; var maxLife = 1f
    var color = 0xFFFFFFFF.toInt(); var radius = 3f; var gravity = 0f
}

// ═══════════════════════════════════════════════════════════════
//  Treasure Chest
// ═══════════════════════════════════════════════════════════════

class TreasureChest(var x: Float, var y: Float) {
    val radius   = 20f
    var bobTimer = 0f
}

// ═══════════════════════════════════════════════════════════════
//  Combo State
// ═══════════════════════════════════════════════════════════════

class ComboState {
    var count    = 0
    var timer    = 0f
    val timeout = 2.5f
    var maxCombo = 0

    fun onKill() {
        count++; timer = timeout
        if (count > maxCombo) maxCombo = count
    }

    fun tick(dt: Float) {
        if (count > 0) { timer -= dt; if (timer <= 0f) { count = 0; timer = 0f } }
    }

    val multiplier get() = when {
        count >= 20 -> 3.0f; count >= 10 -> 2.0f
        count >= 5  -> 1.5f; count >= 3  -> 1.25f; else -> 1.0f
    }
    val label get() = when {
        count >= 20 -> "GODLIKE!!"
        count >= 15 -> "LEGENDARY!"
        count >= 10 -> "UNSTOPPABLE!"
        count >= 5  -> "COMBO x$count"
        else        -> ""
    }
}

// ═══════════════════════════════════════════════════════════════
//  Run Statistics
// ═══════════════════════════════════════════════════════════════

class RunStats {
    var damageDealt       = 0f
    var damageTaken       = 0f
    var healingDone       = 0f
    var xpCollected       = 0f
    var bossesKilled      = 0
    var elitesKilled      = 0
    var chestsOpened      = 0
    var abilitiesUsed     = 0
    var bestCombo         = 0
    var statusApplied     = 0
    var totalKillsThisRun = 0
}

// ═══════════════════════════════════════════════════════════════
//  Meta Upgrades  (persistent across runs)
// ═══════════════════════════════════════════════════════════════

class MetaUpgrades {
    var currency   = 0
    var hpLevel    = 0; val hpBonus    get() = hpLevel    * 20f
    var speedLevel = 0; val speedBonus get() = speedLevel * 15f
    var cdrLevel   = 0; val cdrBonus   get() = cdrLevel   * 0.05f
    var xpLevel    = 0; val xpBonus    get() = xpLevel    * 0.10f
    var startAbility: AbilityId? = null
    fun costHp()    = 5  + hpLevel    * 5
    fun costSpeed() = 5  + speedLevel * 5
    fun costCdr()   = 8  + cdrLevel   * 8
    fun costXp()    = 6  + xpLevel    * 6
    var selectedCharacter: CharacterType = CharacterType.VOID_WALKER
    var unlockedCharsMask: Int           = 1
    var achievementFlags: Long           = 0L
    var totalBossKills: Int              = 0
    var totalStatusApplied: Int          = 0
    var totalRuns: Int                   = 0
    var bestWave: Int                    = 0
    var bestTime: Int                    = 0

    fun isCharUnlocked(t: CharacterType) = (unlockedCharsMask and (1 shl t.ordinal)) != 0
    fun unlockChar(t: CharacterType)     { unlockedCharsMask = unlockedCharsMask or (1 shl t.ordinal) }
}

// ═══════════════════════════════════════════════════════════════
//  Game State
// ═══════════════════════════════════════════════════════════════

class GameState(var worldW: Float, var worldH: Float) {
    val player     = Player(worldW, worldH)
    val enemies    = mutableListOf<Enemy>()
    val bullets    = mutableListOf<Bullet>()
    val orbs       = mutableListOf<XPOrb>()
    val floatTexts = mutableListOf<FloatText>()
    val particles  = Array(600) { Particle() }
    val blackHoles = mutableListOf<BlackHole>()
    val chests     = mutableListOf<TreasureChest>()

    val abilities  = mutableListOf(
        Ability(AbilityId.DASH,         baseCd = 4f,  level = 0),
        Ability(AbilityId.SHOCKWAVE,    baseCd = 6f,  level = 0),
        Ability(AbilityId.BLACK_HOLE,   baseCd = 12f, level = 0),
        Ability(AbilityId.TIME_SLOW,    baseCd = 10f, level = 0),
        Ability(AbilityId.SHIELD_PULSE, baseCd = 8f,  level = 0),
        Ability(AbilityId.ENERGY_ORB,   baseCd = 8f,  level = 0)
    )
    val evolutions = mutableSetOf<EvoType>()

    var phase       = Phase.PLAYING
    var wave        = 1
    var waveTimer   = 0f;  var waveDuration   = 30f
    var spawnTimer  = 0f;  var spawnInterval  = 2f
    var kills       = 0;   var elapsed        = 0f
    var pendingUpgrades: List<Upgrade> = emptyList()

    var shakeTimer  = 0f;  var shakeAmt = 0f

    var timeSlowActive = false; var timeSlowTimer = 0f

    var currentEvent: EventType? = null
    var eventTimer   = 0f
    var eventAnnouncement: EventAnnouncement? = null
    var nextEventWave = 6

    var boss: Enemy? = null
    var showBossWarning = false; var bossWarningTimer = 0f

    var runCurrency = 0

    val combo               = ComboState()
    val stats               = RunStats()
    var chestSpawnTimer     = 35f
    val pendingAchievements = mutableListOf<String>()
}

// ═══════════════════════════════════════════════════════════════
//  Game Logic
// ═══════════════════════════════════════════════════════════════

object GameLogic {

    private val rng = Random.Default

    // ─── Upgrade pool ────────────────────────────────────────────

    private val UPGRADES: List<Upgrade> = listOf(
        Upgrade(UpType.DAMAGE,       "Power Up",           "+25% damage",            1),
        Upgrade(UpType.DAMAGE,       "Big Damage",         "+50% damage",            2),
        Upgrade(UpType.DAMAGE,       "Devastate",          "+80% damage",            3),
        Upgrade(UpType.DMG_MULT,     "Battle Mastery",     "x1.3 all damage",        2),
        Upgrade(UpType.FIRE_RATE,    "Rapid Fire",         "+20% fire rate",         1),
        Upgrade(UpType.FIRE_RATE,    "Hyper Fire",         "+40% fire rate",         2),
        Upgrade(UpType.MAX_HP,       "Tough Skin",         "+30 max HP",             1),
        Upgrade(UpType.MAX_HP,       "Iron Body",          "+70 max HP",             2),
        Upgrade(UpType.SPEED,        "Quick Feet",         "+15% move speed",        1),
        Upgrade(UpType.SPEED,        "Blazing Speed",      "+30% move speed",        2),
        Upgrade(UpType.EXTRA_PROJ,   "Twin Shot",          "+1 projectile",          2),
        Upgrade(UpType.EXTRA_PROJ,   "Triple Shot",        "+2 projectiles",         3),
        Upgrade(UpType.REGEN,        "Regeneration",       "+2 HP/sec",              2),
        Upgrade(UpType.REGEN,        "Life Leech",         "+5 HP/sec",              3),
        Upgrade(UpType.MAGNET,       "XP Magnet",          "XP attract +60%",        1),
        Upgrade(UpType.MAGNET,       "Vortex",             "XP attract x2",          2),
        Upgrade(UpType.HEAL_NOW,     "First Aid",          "Heal 40 HP now",         1),
        Upgrade(UpType.HEAL_NOW,     "Full Restore",       "Heal 80 HP now",         2),
        Upgrade(UpType.RANGE,        "Long Reach",         "+25% attack range",      1),
        Upgrade(UpType.CDR,          "Swift Cast",         "-15% ability cooldown",  1),
        Upgrade(UpType.CDR,          "Haste",              "-30% ability cooldown",  2),
        Upgrade(UpType.AREA,         "Blast Radius",       "+25% ability area",      1),
        Upgrade(UpType.AREA,         "Wide Impact",        "+50% ability area",      2),
        Upgrade(UpType.LIFESTEAL,    "Vampiric",           "8% damage to HP",        2),
        Upgrade(UpType.LIFESTEAL,    "Blood Thirst",       "18% damage to HP",       3),
        Upgrade(UpType.CRIT,         "Sharp Focus",        "+10% crit chance",       1),
        Upgrade(UpType.CRIT,         "Deadly Aim",         "+20% crit chance",       2),
        Upgrade(UpType.PIERCING,     "Piercing Shot",      "Bullets pierce 1 enemy", 2),
        Upgrade(UpType.PIERCING,     "Full Pierce",        "Bullets pierce 2 enemies",3),
        Upgrade(UpType.CHAIN_SHOT,   "Chain Lightning",    "Hits chain to 1 enemy",  2),
        Upgrade(UpType.CHAIN_SHOT,   "Arc Storm",          "Hits chain to 2 enemies",3),
        Upgrade(UpType.ARMOR,        "Iron Skin",          "-15% damage taken",      1),
        Upgrade(UpType.ARMOR,        "Fortress",           "-30% damage taken",      2),
        Upgrade(UpType.STATUS_BURN,  "Ignite",             "+25% burn chance",       1),
        Upgrade(UpType.STATUS_BURN,  "Wildfire",           "+50% burn chance",       2),
        Upgrade(UpType.STATUS_FREEZE,"Frostbite",          "+20% freeze chance",     1),
        Upgrade(UpType.STATUS_FREEZE,"Deep Freeze",        "+40% freeze chance",     2),
        Upgrade(UpType.STATUS_SHOCK, "Static Field",       "+20% shock chance",      1),
        Upgrade(UpType.STATUS_SHOCK, "Overcharge",         "+40% shock chance",      2),
        Upgrade(UpType.UNLOCK_AB,    "Unlock: Dash",       "Blink forward!",         2, AbilityId.DASH),
        Upgrade(UpType.UNLOCK_AB,    "Unlock: Shockwave",  "AoE burst!",             2, AbilityId.SHOCKWAVE),
        Upgrade(UpType.UNLOCK_AB,    "Unlock: Black Hole", "Pull enemies!",          3, AbilityId.BLACK_HOLE),
        Upgrade(UpType.UNLOCK_AB,    "Unlock: Time Slow",  "Slow enemies!",          3, AbilityId.TIME_SLOW),
        Upgrade(UpType.UNLOCK_AB,    "Unlock: Shield",     "Deflect shots!",         2, AbilityId.SHIELD_PULSE),
        Upgrade(UpType.UNLOCK_AB,    "Unlock: Energy Orb", "Orbiting damage!",       2, AbilityId.ENERGY_ORB)
    )

    private fun evoPool(state: GameState): List<Upgrade> {
        val evos = mutableListOf<Upgrade>()
        fun has(id: AbilityId) = state.abilities.any { it.id == id && it.level > 0 }
        val p = state.player
        if (has(AbilityId.DASH) && has(AbilityId.SHOCKWAVE) && EvoType.FLAME_DASH !in state.evolutions)
            evos += Upgrade(UpType.EVOLVE, "* Flame Dash",        "Dash leaves fire trail",     3, evoType = EvoType.FLAME_DASH)
        if (has(AbilityId.ENERGY_ORB) && p.cdr >= 0.2f && EvoType.ICE_ORB !in state.evolutions)
            evos += Upgrade(UpType.EVOLVE, "* Ice Orb",           "Orb freezes enemies",        3, evoType = EvoType.ICE_ORB)
        if (has(AbilityId.SHOCKWAVE) && p.cdr >= 0.3f && EvoType.INFINITE_PULSE !in state.evolutions)
            evos += Upgrade(UpType.EVOLVE, "* Infinite Pulse",    "Rapid-fire shockwave",       3, evoType = EvoType.INFINITE_PULSE)
        if (has(AbilityId.BLACK_HOLE) && p.critChance >= 0.2f && EvoType.SINGULARITY_BURST !in state.evolutions)
            evos += Upgrade(UpType.EVOLVE, "* Singularity Burst", "Crits spawn black holes",    3, evoType = EvoType.SINGULARITY_BURST)
        return evos
    }

    fun pickUpgrades(state: GameState): List<Upgrade> {
        val pool = mutableListOf<Upgrade>()
        pool += evoPool(state)
        pool += UPGRADES.filter { up ->
            up.type != UpType.UNLOCK_AB ||
            state.abilities.any { it.id == up.abilityId && it.level == 0 }
        }.shuffled(rng)
        return pool.take(3)
    }

    fun applyUpgrade(state: GameState, up: Upgrade) {
        val p = state.player
        when (up.type) {
            UpType.DAMAGE       -> p.damage      *= if (up.rarity >= 3) 1.8f else if (up.rarity == 2) 1.5f else 1.25f
            UpType.DMG_MULT     -> p.dmgMult     *= 1.3f
            UpType.FIRE_RATE    -> p.fireRate    *= if (up.rarity >= 2) 1.4f else 1.2f
            UpType.MAX_HP       -> { val a = if (up.rarity >= 2) 70f else 30f; p.maxHp += a; p.hp += a }
            UpType.SPEED        -> p.speed       *= if (up.rarity >= 2) 1.3f else 1.15f
            UpType.EXTRA_PROJ   -> p.projectiles += if (up.rarity >= 3) 2 else 1
            UpType.REGEN        -> p.regen       += if (up.rarity >= 3) 5f else 2f
            UpType.MAGNET       -> p.magnet      *= if (up.rarity >= 2) 2f else 1.6f
            UpType.HEAL_NOW     -> { val h = if (up.rarity >= 2) 80f else 40f
                                    p.hp = minOf(p.hp + h, p.maxHp); state.stats.healingDone += h }
            UpType.RANGE        -> p.range       *= 1.25f
            UpType.CDR          -> p.cdr          = (p.cdr + if (up.rarity >= 2) 0.30f else 0.15f).coerceAtMost(0.75f)
            UpType.AREA         -> p.areaScale   *= if (up.rarity >= 2) 1.5f else 1.25f
            UpType.LIFESTEAL    -> p.lifesteal    = (p.lifesteal + if (up.rarity >= 3) 0.18f else 0.08f).coerceAtMost(0.5f)
            UpType.CRIT         -> p.critChance   = (p.critChance + if (up.rarity >= 2) 0.2f else 0.1f).coerceAtMost(0.8f)
            UpType.PIERCING     -> p.piercingShots += if (up.rarity >= 3) 2 else 1
            UpType.CHAIN_SHOT   -> p.chainShots   += if (up.rarity >= 3) 2 else 1
            UpType.ARMOR        -> p.armor         = (p.armor + if (up.rarity >= 2) 0.30f else 0.15f).coerceAtMost(0.75f)
            UpType.STATUS_BURN  -> p.burnChance    = (p.burnChance   + if (up.rarity >= 2) 0.50f else 0.25f).coerceAtMost(1f)
            UpType.STATUS_FREEZE-> p.freezeChance  = (p.freezeChance + if (up.rarity >= 2) 0.40f else 0.20f).coerceAtMost(1f)
            UpType.STATUS_SHOCK -> p.shockChance   = (p.shockChance  + if (up.rarity >= 2) 0.40f else 0.20f).coerceAtMost(1f)
            UpType.UNLOCK_AB    -> state.abilities.find { it.id == up.abilityId }?.level = 1
            UpType.EVOLVE       -> up.evoType?.let { evo ->
                state.evolutions += evo
                when (evo) {
                    EvoType.INFINITE_PULSE -> state.abilities.find { it.id == AbilityId.SHOCKWAVE }?.level = 3
                    EvoType.ICE_ORB        -> state.abilities.find { it.id == AbilityId.ENERGY_ORB }?.level = 3
                    else -> {}
                }
                if (state.evolutions.size == 1) checkAndGrantAchievement(state, "get_evo")
            }
        }
        state.phase = Phase.PLAYING
    }

    // ─── Main update ─────────────────────────────────────────────

    fun update(state: GameState, dt: Float, moveX: Float, moveY: Float) {
        if (state.phase != Phase.PLAYING) return
        val p = state.player

        val gameDt = if (state.timeSlowActive) dt * 0.30f else dt
        state.elapsed   += dt
        state.waveTimer += gameDt

        if (state.showBossWarning) {
            state.bossWarningTimer -= dt
            if (state.bossWarningTimer <= 0f) state.showBossWarning = false
        }
        if (state.shakeTimer > 0f) state.shakeTimer -= dt

        if (state.timeSlowActive) {
            state.timeSlowTimer -= dt
            if (state.timeSlowTimer <= 0f) {
                state.timeSlowActive = false
                state.abilities.find { it.id == AbilityId.TIME_SLOW }
                    ?.let { it.cdTimer = it.effectiveCd(p.cdr) }
            }
        }

        for (ab in state.abilities) { if (ab.cdTimer > 0f) ab.cdTimer -= dt }

        if (p.regen > 0f) {
            val heal = p.regen * gameDt
            p.hp = minOf(p.hp + heal, p.maxHp)
            state.stats.healingDone += heal
        }
        if (p.iFrames        > 0f) p.iFrames        -= dt
        if (p.hitFlashTimer  > 0f) p.hitFlashTimer  -= dt
        if (p.shieldActive)  { p.shieldTimer -= dt; if (p.shieldTimer <= 0f) p.shieldActive = false }
        if (p.orbBurst)      { p.orbBurstTimer -= dt; if (p.orbBurstTimer <= 0f) p.orbBurst = false }

        // Movement
        if (p.isDashing) {
            p.dashTimer -= dt
            p.x = (p.x + p.dashVx * dt).coerceIn(p.radius, state.worldW - p.radius)
            p.y = (p.y + p.dashVy * dt).coerceIn(p.radius, state.worldH - p.radius)
            if (p.dashTimer <= 0f) { p.isDashing = false; p.iFrames = 0.12f }
        } else {
            val mLen = sqrt(moveX * moveX + moveY * moveY)
            if (mLen > 0.01f) {
                p.x = (p.x + moveX / mLen * p.speed * gameDt).coerceIn(p.radius, state.worldW - p.radius)
                p.y = (p.y + moveY / mLen * p.speed * gameDt).coerceIn(p.radius, state.worldH - p.radius)
                p.facingAngle = atan2(moveY, moveX)
                p.isMoving = true
            } else {
                p.isMoving = false
            }
        }

        val orbAb = state.abilities.find { it.id == AbilityId.ENERGY_ORB }
        if ((orbAb?.level ?: 0) > 0) p.orbAngle += (if (p.orbBurst) 14f else 3f) * gameDt

        if (p.isDashing && EvoType.FLAME_DASH in state.evolutions)
            spawnParticles(state, p.x, p.y, 3, 0xFFFF6600.toInt(), 20f, -30f)

        tickSpawn(state, gameDt)
        tickStatusEffects(state, gameDt)
        tickEnemies(state, gameDt)

        p.fireTimer -= gameDt
        if (p.fireTimer <= 0f && state.enemies.isNotEmpty()) {
            fireWeapon(state)
            p.fireTimer = 1f / p.fireRate
        }

        val bIter = state.bullets.iterator()
        while (bIter.hasNext()) {
            val b = bIter.next()
            b.x += b.vx * gameDt; b.y += b.vy * gameDt; b.life -= gameDt
            if (b.life <= 0f || b.x < -80f || b.x > state.worldW + 80f ||
                b.y < -80f  || b.y > state.worldH + 80f) bIter.remove()
        }

        bulletHitEnemies(state)
        tickOrbAttack(state, gameDt)
        tickBlackHoles(state, gameDt)
        tickOrbs(state, gameDt)
        tickParticles(state, gameDt)
        tickChests(state, gameDt)
        state.combo.tick(gameDt)

        val ftIter = state.floatTexts.iterator()
        while (ftIter.hasNext()) {
            val ft = ftIter.next()
            ft.y -= 55f * gameDt; ft.life -= gameDt
            if (ft.life <= 0f) ftIter.remove()
        }

        tickWaves(state, gameDt)
        tickEvents(state, dt)
    }

    // ─── Status Effects ──────────────────────────────────────────

    private fun tickStatusEffects(state: GameState, dt: Float) {
        val p = state.player
        for (e in state.enemies) {
            if (e.hp <= 0f) continue
            e.frozenSlowFactor = 1f
            e.isShocked        = false
            e.shockDmgMult     = 1f

            val iter = e.statusEffects.iterator()
            while (iter.hasNext()) {
                val eff = iter.next()
                eff.duration -= dt
                when (eff.type) {
                    StatusEffectType.BURN,
                    StatusEffectType.POISON,
                    StatusEffectType.BLEED -> {
                        val dot = eff.dps * dt
                        e.hp -= dot
                        if (p.lifesteal > 0f) {
                            val heal = dot * p.lifesteal * 0.4f
                            p.hp = minOf(p.hp + heal, p.maxHp)
                            state.stats.healingDone += heal
                        }
                        if (rng.nextFloat() < dt * 10f) {
                            val col = when (eff.type) {
                                StatusEffectType.BURN  -> 0xFFFF5500.toInt()
                                StatusEffectType.BLEED -> 0xFFCC0033.toInt()
                                else                   -> 0xFF44CC00.toInt()
                            }
                            spawnParticles(state, e.x + rng.nextFloat()*16f-8f,
                                e.y + rng.nextFloat()*16f-8f, 2, col, 18f, 40f)
                        }
                    }
                    StatusEffectType.FREEZE -> {
                        e.frozenSlowFactor = eff.slowFactor
                        if (rng.nextFloat() < dt * 6f)
                            spawnParticles(state, e.x, e.y, 2, 0xFF88DDFF.toInt(), 12f, -20f)
                    }
                    StatusEffectType.SHOCK -> {
                        e.isShocked    = true
                        e.shockDmgMult = 1.35f
                        if (rng.nextFloat() < dt * 14f)
                            spawnParticles(state, e.x, e.y, 3, 0xFFFFFF44.toInt(), 22f, 0f)
                    }
                }
                if (eff.duration <= 0f) iter.remove()
            }
            e.speed = e.baseSpeed * e.frozenSlowFactor
        }
    }

    fun applyStatusEffect(state: GameState, enemy: Enemy, type: StatusEffectType, dmgScale: Float) {
        val (dur, dps, slow) = when (type) {
            StatusEffectType.BURN   -> Triple(3f,   9f * dmgScale, 1f)
            StatusEffectType.POISON -> Triple(5f,   5f * dmgScale, 1f)
            StatusEffectType.FREEZE -> Triple(2.2f, 0f,            0.15f)
            StatusEffectType.SHOCK  -> Triple(3f,   0f,            1f)
            StatusEffectType.BLEED  -> Triple(4f,   14f * dmgScale,1f)
        }
        enemy.statusEffects.removeAll { it.type == type }
        enemy.statusEffects.add(StatusEffect(type, dur, dps, slow))
        state.stats.statusApplied++

        val col = when (type) {
            StatusEffectType.BURN   -> 0xFFFF4400.toInt()
            StatusEffectType.POISON -> 0xFF44CC00.toInt()
            StatusEffectType.FREEZE -> 0xFF88DDFF.toInt()
            StatusEffectType.SHOCK  -> 0xFFFFFF44.toInt()
            StatusEffectType.BLEED  -> 0xFFCC0044.toInt()
        }
        spawnParticles(state, enemy.x, enemy.y, 8, col, 22f, 0f)
    }

    // ─── Wave / boss / event ──────────────────────────────────────

    private fun tickWaves(state: GameState, dt: Float) {
        if (state.waveTimer < state.waveDuration) return
        state.wave++
        state.waveTimer    = 0f
        state.waveDuration  = (state.waveDuration  * 0.93f).coerceAtLeast(14f)
        state.spawnInterval = (state.spawnInterval * 0.82f).coerceAtLeast(0.35f)

        if (state.wave % 5 == 0 && state.boss == null) spawnBoss(state)
        if (state.wave >= state.nextEventWave && state.currentEvent == null) {
            triggerEvent(state)
            state.nextEventWave = state.wave + rng.nextInt(3) + 2
        }
    }

    private fun triggerEvent(state: GameState) {
        val vals = EventType.values()
        val evt  = vals[rng.nextInt(vals.size)]
        state.currentEvent      = evt
        state.eventTimer        = when (evt) {
            EventType.SWARM_RUSH  -> 12f
            EventType.DARKNESS    -> 10f
            EventType.METEOR_RAIN -> 7f
            EventType.ELITE_ONLY  -> 15f
            EventType.SLOW_MOTION -> 8f
        }
        state.eventAnnouncement = EventAnnouncement(evt, 2.5f)
    }

    private fun tickEvents(state: GameState, dt: Float) {
        state.eventAnnouncement?.let { ann ->
            ann.warningTimer -= dt
            if (ann.warningTimer <= 0f) state.eventAnnouncement = null
        }
        if (state.currentEvent == null) return
        state.eventTimer -= dt
        if (state.currentEvent == EventType.METEOR_RAIN) tickMeteors(state, dt)
        if (state.eventTimer <= 0f) state.currentEvent = null
    }

    private fun tickMeteors(state: GameState, dt: Float) {
        if (rng.nextFloat() >= dt * 1.8f) return
        val tx = rng.nextFloat() * state.worldW
        val ty = rng.nextFloat() * state.worldH
        spawnParticles(state, tx, ty, 14, 0xFFFF6600.toInt(), 30f, 0f)
        triggerShake(state, 5f, 0.3f)
        val r = 65f * state.player.areaScale
        for (e in state.enemies) {
            val dx = e.x - tx; val dy = e.y - ty
            if (sqrt(dx * dx + dy * dy) < r) {
                val dmg = 40f * state.player.dmgMult * e.shockDmgMult
                e.hp -= dmg; e.flashTimer = 0.12f
                state.stats.damageDealt += dmg
                addFloatText(state, e.x, e.y - 10f, dmg.toInt().toString(), 0xFFFF8800.toInt())
            }
        }
    }

    // ─── Treasure Chests ─────────────────────────────────────────

    private fun tickChests(state: GameState, dt: Float) {
        val p = state.player
        for (ch in state.chests) ch.bobTimer += dt

        state.chestSpawnTimer -= dt
        if (state.chestSpawnTimer <= 0f) {
            val margin = 80f
            val cx = margin + rng.nextFloat() * (state.worldW - margin * 2f)
            val cy = margin + rng.nextFloat() * (state.worldH - margin * 2f)
            state.chests += TreasureChest(cx, cy)
            state.chestSpawnTimer = 40f + rng.nextFloat() * 20f
        }

        val iter = state.chests.iterator()
        while (iter.hasNext()) {
            val ch = iter.next()
            val dx = p.x - ch.x; val dy = p.y - ch.y
            if (sqrt(dx * dx + dy * dy) < p.radius + ch.radius) {
                openChest(state, ch); iter.remove()
            }
        }
    }

    private fun openChest(state: GameState, ch: TreasureChest) {
        spawnParticles(state, ch.x, ch.y, 28, 0xFFFFDD00.toInt(), 65f, -80f)
        spawnParticles(state, ch.x, ch.y, 14, 0xFFFFFFFF.toInt(), 45f, -50f)
        triggerShake(state, 4f, 0.3f)
        val p = state.player
        when {
            rng.nextFloat() < 0.30f -> {
                val amount = p.maxHp * 0.25f
                p.hp = minOf(p.hp + amount, p.maxHp)
                state.stats.healingDone += amount
                addFloatText(state, ch.x, ch.y, "+${amount.toInt()} HP", 0xFF44FF88.toInt())
                repeat(6) { state.orbs += XPOrb(ch.x + rng.nextFloat()*60f-30f, ch.y + rng.nextFloat()*60f-30f, 8f) }
            }
            rng.nextFloat() < 0.55f -> {
                repeat(14) { state.orbs += XPOrb(ch.x + rng.nextFloat()*120f-60f, ch.y + rng.nextFloat()*120f-60f, 8f) }
                addFloatText(state, ch.x, ch.y, "XP BONUS!", 0xFF00FF88.toInt())
            }
            rng.nextFloat() < 0.80f -> {
                val coins = 10 + rng.nextInt(16)
                state.runCurrency += coins
                addFloatText(state, ch.x, ch.y, "+$coins coins!", 0xFFFFCC00.toInt())
            }
            else -> {
                p.shieldActive = true; p.shieldTimer = p.shieldDuration * 2f
                addFloatText(state, ch.x, ch.y, "SHIELD!", 0xFF44AAFF.toInt())
            }
        }
        state.stats.chestsOpened++
        state.runCurrency += 3
        checkAndGrantAchievement(state, "open_chest")
    }

    // ─── Spawn ────────────────────────────────────────────────────

    private fun tickSpawn(state: GameState, dt: Float) {
        state.spawnTimer -= dt
        if (state.spawnTimer > 0f) return
        val count = if (state.currentEvent == EventType.SWARM_RUSH) rng.nextInt(3) + 2 else 1
        repeat(count) { spawnEnemy(state) }
        state.spawnTimer = state.spawnInterval
    }

    private fun spawnEdge(state: GameState): Pair<Float, Float> {
        val w = state.worldW; val h = state.worldH
        return when (rng.nextInt(4)) {
            0    -> rng.nextFloat() * w to -50f
            1    -> (w + 50f)           to rng.nextFloat() * h
            2    -> rng.nextFloat() * w to (h + 50f)
            else -> (-50f)              to rng.nextFloat() * h
        }
    }

    private fun spawnEnemy(state: GameState) {
        val (ex, ey) = spawnEdge(state)
        val scale    = (1f + (state.wave - 1) * 0.18f).coerceAtMost(4f)

        if (state.currentEvent == EventType.ELITE_ONLY) {
            state.enemies += makeElite(ex, ey, scale); return
        }

        val roll = rng.nextFloat(); val w = state.wave
        val e = when {
            w < 2  || roll < 0.35f -> makeBasic(ex, ey, scale)
            roll < 0.50f           -> makeFast(ex, ey, scale)
            roll < 0.60f && w >= 3 -> makeTank(ex, ey, scale)
            roll < 0.66f && w >= 4 -> makeCharger(ex, ey, scale)
            roll < 0.71f && w >= 5 -> makeShooter(ex, ey, scale)
            roll < 0.75f && w >= 6 -> makeRanged(ex, ey, scale)
            roll < 0.79f && w >= 7 -> makeExploder(ex, ey, scale)
            roll < 0.83f && w >= 8 -> makeShieldEnemy(ex, ey, scale)
            roll < 0.87f && w >= 9 -> makeTeleporter(ex, ey, scale)
            roll < 0.93f && w >= 5 -> makeElite(ex, ey, scale)
            else                   -> makeSwarm(ex, ey, scale)
        }
        state.enemies += e
        if (e.type == EnemyType.SWARM) {
            repeat(rng.nextInt(3) + 1) {
                state.enemies += Enemy(ex + rng.nextFloat()*70f-35f, ey + rng.nextFloat()*70f-35f,
                    e.radius, e.baseSpeed, e.maxHp, e.maxHp, e.contactDmg, e.xpDrop, EnemyType.SWARM)
            }
        }
    }

    private fun makeBasic(x: Float, y: Float, s: Float)   = Enemy(x, y, 22f, (85f + rng.nextFloat()*30f)*s.coerceAtMost(2.2f), 40f*s, 40f*s, 8f, 5f, EnemyType.BASIC)
    private fun makeFast(x: Float, y: Float, s: Float)    = Enemy(x, y, 14f, 185f+rng.nextFloat()*40f, 20f*s, 20f*s, 5f, 4f, EnemyType.FAST)
    private fun makeTank(x: Float, y: Float, s: Float)    = Enemy(x, y, 38f, 52f, 160f*s, 160f*s, 18f, 18f, EnemyType.TANK)
    private fun makeShooter(x: Float, y: Float, s: Float) = Enemy(x, y, 18f, 65f, 32f*s, 32f*s, 3f, 9f, EnemyType.SHOOTER)
    private fun makeSwarm(x: Float, y: Float, s: Float)   = Enemy(x, y, 11f, 150f+rng.nextFloat()*55f, 12f*s, 12f*s, 4f, 2f, EnemyType.SWARM)
    private fun makeCharger(x: Float, y: Float, s: Float) = Enemy(x, y, 20f, 60f, 55f*s, 55f*s, 14f, 8f, EnemyType.CHARGER).also { it.chargeTimer = 1f+rng.nextFloat() }
    private fun makeRanged(x: Float, y: Float, s: Float)  = Enemy(x, y, 16f, 50f, 28f*s, 28f*s, 2f, 10f, EnemyType.RANGED).also { it.shootTimer = 1.5f+rng.nextFloat()*0.5f }
    private fun makeExploder(x: Float, y: Float, s: Float)= Enemy(x, y, 24f, 130f, 35f*s, 35f*s, 0f, 12f, EnemyType.EXPLODER)
    private fun makeShieldEnemy(x: Float, y: Float, s: Float) = Enemy(x, y, 26f, 70f, 80f*s, 80f*s, 10f, 15f, EnemyType.SHIELD_ENEMY).also { it.shieldHp = 60f*s; it.maxShieldHp = 60f*s }
    private fun makeTeleporter(x: Float, y: Float, s: Float) = Enemy(x, y, 15f, 80f, 30f*s, 30f*s, 7f, 14f, EnemyType.TELEPORTER).also { it.teleportCd = 3f+rng.nextFloat()*2f }
    private fun makeElite(x: Float, y: Float, s: Float): Enemy {
        val base = when (rng.nextInt(3)) { 0 -> makeBasic(x,y,s); 1 -> makeTank(x,y,s); else -> makeCharger(x,y,s) }
        return Enemy(x, y, base.radius*1.5f, base.baseSpeed, base.maxHp*3f, base.maxHp*3f, base.contactDmg*1.5f, base.xpDrop*4f, EnemyType.ELITE)
    }

    private fun spawnBoss(state: GameState) {
        val s    = 1f + (state.wave / 5f) * 0.5f
        val boss = Enemy(state.worldW/2f, -80f, 55f, 80f, 800f*s, 800f*s, 22f, 120f, EnemyType.BOSS)
        boss.bossPhase = 1; boss.summonTimer = 6f
        state.boss = boss; state.enemies += boss
        state.showBossWarning = true; state.bossWarningTimer = 3f
        triggerShake(state, 12f, 1f)
    }

    // ─── Enemy AI ─────────────────────────────────────────────────

    private fun tickEnemies(state: GameState, dt: Float) {
        val p    = state.player
        val iter = state.enemies.iterator()
        val toAdd = mutableListOf<Enemy>()

        outer@ while (iter.hasNext()) {
            val e = iter.next()
            if (e.hp <= 0f) { onEnemyDeath(state, e); iter.remove(); continue }
            if (e.flashTimer > 0f) e.flashTimer -= dt

            val dx   = p.x - e.x; val dy = p.y - e.y
            val dist = sqrt(dx * dx + dy * dy)
            val rage = e.hp < e.maxHp * 0.3f
            val sm   = if (rage) 1.4f else 1f

            when (e.type) {
                EnemyType.BASIC, EnemyType.TANK -> {
                    if (dist > 1f) { e.x += dx/dist*e.speed*sm*dt; e.y += dy/dist*e.speed*sm*dt }
                }
                EnemyType.FAST, EnemyType.SWARM -> {
                    if (dist > 1f) { e.x += dx/dist*e.speed*dt; e.y += dy/dist*e.speed*dt }
                }
                EnemyType.SHOOTER -> {
                    val pref = 300f; val move = if (dist < pref-30f) -1f else if (dist > pref+30f) 1f else 0f
                    if (dist > 1f) { e.x += dx/dist*e.speed*move*dt; e.y += dy/dist*e.speed*move*dt }
                    if (dist < 450f) {
                        e.shootTimer -= dt
                        if (e.shootTimer <= 0f) {
                            fireBullet(state, e.x, e.y, dx/dist*210f, dy/dist*210f, 11f, 8f, 2.8f, false)
                            e.shootTimer = 2.3f + rng.nextFloat()*0.5f
                        }
                    }
                }
                EnemyType.CHARGER -> {
                    if (e.isCharging) {
                        e.x += e.chargeVx*dt; e.y += e.chargeVy*dt
                        e.chargeVx *= (1f - 5f*dt); e.chargeVy *= (1f - 5f*dt)
                        if (sqrt(e.chargeVx*e.chargeVx + e.chargeVy*e.chargeVy) < 60f) e.isCharging = false
                    } else {
                        e.chargeTimer -= dt
                        if (e.chargeTimer <= 0f && dist < 380f && e.frozenSlowFactor > 0.5f) {
                            e.isCharging = true
                            e.chargeVx = dx/dist*700f; e.chargeVy = dy/dist*700f
                            e.chargeTimer = 1.8f + rng.nextFloat()
                            spawnParticles(state, e.x, e.y, 8, 0xFFFF4400.toInt(), 22f, 0f)
                        } else if (dist > 1f) { e.x += dx/dist*e.speed*dt; e.y += dy/dist*e.speed*dt }
                    }
                }
                EnemyType.RANGED -> {
                    val pref = 240f; val move = if (dist < pref-30f) -0.8f else if (dist > pref+30f) 1f else 0f
                    if (dist > 1f) { e.x += dx/dist*e.speed*move*dt; e.y += dy/dist*e.speed*move*dt }
                    e.shootTimer -= dt
                    if (e.shootTimer <= 0f) {
                        val baseA = atan2(dy, dx)
                        repeat(3) { i ->
                            val a = baseA + (i-1)*0.3f
                            fireBullet(state, e.x, e.y, cos(a)*170f, sin(a)*170f, 8f, 7f, 3.2f, false)
                        }
                        e.shootTimer = 1.6f + rng.nextFloat()*0.4f
                    }
                }
                EnemyType.EXPLODER -> {
                    if (dist > 1f) { e.x += dx/dist*e.speed*sm*dt; e.y += dy/dist*e.speed*sm*dt }
                    if (dist < p.radius + e.radius + 15f) {
                        spawnParticles(state, e.x, e.y, 28, 0xFFFF5500.toInt(), 55f, 180f)
                        triggerShake(state, 9f, 0.5f)
                        if (dist < 85f*p.areaScale && p.iFrames <= 0f && !p.shieldActive) {
                            val dmg = 28f*(1f-p.armor); p.hp -= dmg; p.iFrames = p.iFrameLen*2
                            p.hitFlashTimer = 0.15f; state.stats.damageTaken += dmg
                            addFloatText(state, p.x, p.y-30f, "-${dmg.toInt()}", 0xFFFF4455.toInt())
                            if (p.hp <= 0f) { p.hp = 0f; state.phase = Phase.DEAD }
                        }
                        onEnemyDeath(state, e); iter.remove(); continue@outer
                    }
                }
                EnemyType.SHIELD_ENEMY -> {
                    if (dist > 1f) { e.x += dx/dist*e.speed*dt; e.y += dy/dist*e.speed*dt }
                }
                EnemyType.TELEPORTER -> {
                    e.teleportCd -= dt
                    if (e.teleportCd <= 0f && e.frozenSlowFactor > 0.5f) {
                        val a = rng.nextFloat()*2f*PI.toFloat(); val r = 100f+rng.nextFloat()*80f
                        e.x = (p.x+cos(a)*r).coerceIn(e.radius, state.worldW-e.radius)
                        e.y = (p.y+sin(a)*r).coerceIn(e.radius, state.worldH-e.radius)
                        spawnParticles(state, e.x, e.y, 12, 0xFFAA00FF.toInt(), 20f, 0f)
                        e.teleportCd = 3f + rng.nextFloat()*2f
                    } else if (dist > 1f) { e.x += dx/dist*e.speed*dt; e.y += dy/dist*e.speed*dt }
                }
                EnemyType.ELITE -> {
                    val em = if (rage) 1.6f else 1f
                    if (dist > 1f) { e.x += dx/dist*e.speed*em*dt; e.y += dy/dist*e.speed*em*dt }
                    e.shootTimer -= dt
                    if (e.shootTimer <= 0f && dist < 500f) {
                        fireBullet(state, e.x, e.y, dx/dist*240f, dy/dist*240f, 18f, 9f, 3f, false)
                        e.shootTimer = 1.6f
                    }
                }
                EnemyType.BOSS -> tickBoss(state, e, p, dx, dy, dist, dt, toAdd)
            }

            // Contact damage
            if (e.type != EnemyType.EXPLODER && dist < p.radius + e.radius && p.iFrames <= 0f) {
                if (p.shieldActive) {
                    spawnParticles(state, p.x, p.y, 6, 0xFF4488FF.toInt(), 20f, 0f)
                    p.iFrames = p.iFrameLen * 0.5f
                } else {
                    val dmg = e.contactDmg*(1f-p.armor); p.hp -= dmg; p.iFrames = p.iFrameLen
                    p.hitFlashTimer = 0.18f; state.stats.damageTaken += dmg
                    // Knockback
                    if (dist > 0.01f) {
                        p.x = (p.x - dx/dist*18f).coerceIn(p.radius, state.worldW-p.radius)
                        p.y = (p.y - dy/dist*18f).coerceIn(p.radius, state.worldH-p.radius)
                    }
                    addFloatText(state, p.x, p.y-30f, "-${dmg.toInt()}", 0xFFFF4455.toInt())
                    spawnParticles(state, p.x, p.y, 6, 0xFFFF3333.toInt(), 12f, 80f)
                    if (p.hp <= 0f) { p.hp = 0f; state.phase = Phase.DEAD }
                }
            }
        }

        // Enemy bullets vs player
        val bIter = state.bullets.iterator()
        while (bIter.hasNext()) {
            val b = bIter.next()
            if (b.fromPlayer) continue
            val dx = p.x - b.x; val dy = p.y - b.y
            if (sqrt(dx*dx + dy*dy) < p.radius + b.radius && p.iFrames <= 0f) {
                if (p.shieldActive) { bIter.remove(); continue }
                val dmg = b.damage*(1f-p.armor); p.hp -= dmg; p.iFrames = p.iFrameLen
                p.hitFlashTimer = 0.15f; state.stats.damageTaken += dmg
                addFloatText(state, p.x, p.y-30f, "-${dmg.toInt()}", 0xFFFF4455.toInt())
                spawnParticles(state, p.x, p.y, 4, 0xFFFF4444.toInt(), 10f, 60f)
                bIter.remove()
                if (p.hp <= 0f) { p.hp = 0f; state.phase = Phase.DEAD }
            }
        }

        if (toAdd.isNotEmpty()) state.enemies += toAdd
    }

    private fun tickBoss(state: GameState, boss: Enemy, p: Player,
                         dx: Float, dy: Float, dist: Float, dt: Float,
                         toAdd: MutableList<Enemy>) {
        if (boss.hp < boss.maxHp*0.5f && boss.bossPhase == 1) {
            boss.bossPhase = 2; boss.rageActive = true
            spawnParticles(state, boss.x, boss.y, 35, 0xFFFF2200.toInt(), 60f, 200f)
            triggerShake(state, 14f, 1f)
        }
        if (boss.hp < boss.maxHp*0.2f && boss.bossPhase == 2) {
            boss.bossPhase = 3
            spawnParticles(state, boss.x, boss.y, 50, 0xFFFF8800.toInt(), 80f, 250f)
            triggerShake(state, 18f, 1.5f)
        }

        val sm = if (boss.rageActive) 1.5f else 1f
        if (dist > 1f) { boss.x += dx/dist*boss.speed*sm*dt; boss.y += dy/dist*boss.speed*sm*dt }
        boss.x = boss.x.coerceIn(boss.radius, state.worldW-boss.radius)
        boss.y = boss.y.coerceIn(boss.radius, state.worldH-boss.radius)

        boss.shootTimer -= dt
        val shootInterval = when (boss.bossPhase) { 3 -> 0.35f; 2 -> 0.65f; else -> 1.1f }
        if (boss.shootTimer <= 0f) {
            val n = when (boss.bossPhase) { 3 -> 8; 2 -> 5; else -> 3 }
            val baseA = atan2(dy, dx)
            repeat(n) { i ->
                val a = baseA + i*(2f*PI.toFloat()/n)
                fireBullet(state, boss.x, boss.y, cos(a)*190f, sin(a)*190f, 18f, 10f, 4f, false)
            }
            boss.shootTimer = shootInterval
        }

        boss.summonTimer -= dt
        if (boss.summonTimer <= 0f) {
            repeat(if (boss.bossPhase >= 2) 4 else 2) {
                val a = rng.nextFloat()*2f*PI.toFloat()
                toAdd += makeBasic(boss.x+cos(a)*80f, boss.y+sin(a)*80f, 1f)
            }
            boss.summonTimer = if (boss.bossPhase >= 2) 5f else 8f
        }

        if (boss.bossPhase >= 2) {
            if (!boss.isCharging) {
                boss.chargeTimer -= dt
                if (boss.chargeTimer <= 0f && dist < 500f) {
                    boss.isCharging = true
                    boss.chargeVx = dx/dist*500f; boss.chargeVy = dy/dist*500f
                    boss.chargeTimer = 4f
                    spawnParticles(state, boss.x, boss.y, 18, 0xFFFF2200.toInt(), 40f, 0f)
                }
            } else {
                boss.x += boss.chargeVx*dt; boss.y += boss.chargeVy*dt
                boss.chargeVx *= (1f-3.5f*dt); boss.chargeVy *= (1f-3.5f*dt)
                if (sqrt(boss.chargeVx*boss.chargeVx+boss.chargeVy*boss.chargeVy) < 50f) boss.isCharging = false
            }
        }
    }

    private fun onEnemyDeath(state: GameState, e: Enemy) {
        val pieces = (e.xpDrop / 5f).toInt().coerceAtLeast(1)
        repeat(pieces) { state.orbs += XPOrb(e.x+rng.nextFloat()*24f-12f, e.y+rng.nextFloat()*24f-12f, 5f) }
        state.kills++
        state.stats.totalKillsThisRun++
        state.combo.onKill()
        if (state.combo.count > state.stats.bestCombo) state.stats.bestCombo = state.combo.count

        addFloatText(state, e.x, e.y, "+${e.xpDrop.toInt()}xp", 0xFF88FF44.toInt())
        val comboLabel = state.combo.label
        if (comboLabel.isNotEmpty())
            addFloatText(state, e.x, e.y - 22f, comboLabel, 0xFFFFAA00.toInt(), 1.05f)

        val deathCol = when (e.type) { EnemyType.ELITE -> 0xFFFFD700.toInt(); EnemyType.BOSS -> 0xFFFF0000.toInt(); else -> 0xFFFF4400.toInt() }
        spawnParticles(state, e.x, e.y, if (e.type == EnemyType.BOSS) 50 else 14, deathCol, e.radius*1.2f, 140f)
        state.runCurrency += when (e.type) { EnemyType.ELITE -> 3; EnemyType.BOSS -> 15; else -> 1 }

        if (e === state.boss) {
            state.stats.bossesKilled++
            state.boss = null
            state.timeSlowActive = true; state.timeSlowTimer = 2f
            triggerShake(state, 16f, 1.5f)
            repeat(25) { state.orbs += XPOrb(e.x+rng.nextFloat()*200f-100f, e.y+rng.nextFloat()*200f-100f, 5f) }
            checkAndGrantAchievement(state, "kill_boss")
        }
        if (e.type == EnemyType.ELITE) state.stats.elitesKilled++

        // Achievement triggers
        if (state.kills == 1)   checkAndGrantAchievement(state, "first_kill")
        if (state.kills == 50)  checkAndGrantAchievement(state, "kill_50")
        if (state.kills == 200) checkAndGrantAchievement(state, "kill_200")
    }

    // ─── Auto-attack ──────────────────────────────────────────────

    private fun fireWeapon(state: GameState) {
        val p = state.player
        data class C(val e: Enemy, val dx: Float, val dy: Float, val dist: Float)
        val inRange = state.enemies.mapNotNull { e ->
            val dx = e.x - p.x; val dy = e.y - p.y; val d = sqrt(dx*dx+dy*dy)
            if (d <= p.range) C(e, dx, dy, d) else null
        }.sortedBy { it.dist }
        if (inRange.isEmpty()) return

        val spd = 500f
        val statusType: StatusEffectType? = when {
            p.burnChance   > 0f && rng.nextFloat() < p.burnChance   -> StatusEffectType.BURN
            p.freezeChance > 0f && rng.nextFloat() < p.freezeChance -> StatusEffectType.FREEZE
            p.shockChance  > 0f && rng.nextFloat() < p.shockChance  -> StatusEffectType.SHOCK
            else                                                     -> null
        }

        inRange.take(p.projectiles).forEach { c ->
            val spread = if (p.projectiles > 1) (rng.nextFloat()-0.5f)*0.25f else 0f
            val a = atan2(c.dy, c.dx) + spread
            fireBullet(state, p.x, p.y, cos(a)*spd, sin(a)*spd,
                p.damage*p.dmgMult, 7f, p.range/spd, true,
                piercesLeft = p.piercingShots, chainLeft = p.chainShots,
                statusType = statusType, statusChance = 1f)
        }
    }

    private fun fireBullet(
        state: GameState, x: Float, y: Float,
        vx: Float, vy: Float, dmg: Float, r: Float, life: Float, fp: Boolean,
        piercesLeft: Int = 0, chainLeft: Int = 0,
        statusType: StatusEffectType? = null, statusChance: Float = 0f
    ) {
        state.bullets += Bullet(x, y, vx, vy, dmg, r, life, fp, piercesLeft, chainLeft, statusType, statusChance)
    }

    // ─── Bullet ↔ enemy ───────────────────────────────────────────

    private fun bulletHitEnemies(state: GameState) {
        val p        = state.player
        val toRemove = mutableListOf<Bullet>()
        val toAdd    = mutableListOf<Bullet>()

        outer@ for (b in state.bullets) {
            if (!b.fromPlayer || b in toRemove) continue
            for (e in state.enemies) {
                if (e.hp <= 0f || e in b.hitEnemies) continue
                val dx = e.x - b.x; val dy = e.y - b.y
                if (sqrt(dx*dx+dy*dy) >= e.radius + b.radius) continue

                // Shield absorbs
                if (e.type == EnemyType.SHIELD_ENEMY && !e.shieldBroken && e.shieldHp > 0f) {
                    e.shieldHp -= b.damage; e.flashTimer = 0.06f
                    if (e.shieldHp <= 0f) { e.shieldBroken = true; spawnParticles(state, e.x, e.y, 16, 0xFF0088FF.toInt(), 20f, 80f) }
                    toRemove += b; continue@outer
                }

                val crit  = rng.nextFloat() < p.critChance
                val baseDmg = b.damage * (if (crit) p.critMult else 1f)
                val dmg   = baseDmg * e.shockDmgMult * state.combo.multiplier
                e.hp -= dmg; e.flashTimer = 0.08f
                state.stats.damageDealt += dmg

                // Knockback enemy
                val edist = sqrt((dx*dx+dy*dy).coerceAtLeast(0.01f))
                e.x -= dx/edist * 35f * 0.016f * p.knockbackMult
                e.y -= dy/edist * 35f * 0.016f * p.knockbackMult

                if (p.lifesteal > 0f) {
                    val heal = dmg * p.lifesteal; p.hp = minOf(p.hp+heal, p.maxHp); state.stats.healingDone += heal
                }

                if (b.statusType != null && rng.nextFloat() < b.statusChance)
                    applyStatusEffect(state, e, b.statusType, p.dmgMult)

                state.floatTexts += FloatText(
                    e.x+rng.nextFloat()*16f-8f, e.y-12f,
                    if (crit) "!${dmg.toInt()}" else dmg.toInt().toString(),
                    if (crit) 0.9f else 0.55f,
                    if (crit) 0xFFFF8800.toInt() else 0xFFFFFF44.toInt(),
                    if (crit) 1.7f else 1f, crit)
                spawnParticles(state, e.x, e.y, if (crit) 8 else 4, 0xFFFFFF44.toInt(), 10f, 40f)

                if (crit && EvoType.SINGULARITY_BURST in state.evolutions) {
                    state.blackHoles += BlackHole(e.x, e.y, 45f*p.areaScale, 1.5f, 1.5f)
                    spawnParticles(state, e.x, e.y, 8, 0xFF8800FF.toInt(), 16f, 0f)
                }

                // Chain shot
                if (b.chainLeft > 0) {
                    val nearest = state.enemies.filter { it != e && it.hp > 0f }
                        .minByOrNull { val ddx = it.x-e.x; val ddy = it.y-e.y; sqrt(ddx*ddx+ddy*ddy) }
                    nearest?.let { target ->
                        val cdx = target.x-e.x; val cdy = target.y-e.y
                        val cLen = sqrt((cdx*cdx+cdy*cdy).coerceAtLeast(0.01f))
                        toAdd += Bullet(e.x, e.y, cdx/cLen*550f, cdy/cLen*550f,
                            b.damage*0.7f, 6f, 1.5f, true, 0, b.chainLeft-1, b.statusType, b.statusChance)
                        spawnParticles(state, e.x, e.y, 5, 0xFF88FFFF.toInt(), 18f, 0f)
                    }
                }

                b.hitEnemies.add(e)
                if (b.piercesLeft > 0) { b.piercesLeft--; continue }
                toRemove += b; continue@outer
            }
        }
        state.bullets += toAdd
        if (toRemove.isNotEmpty()) state.bullets.removeAll(toRemove.toHashSet())
    }

    // ─── Energy orb ───────────────────────────────────────────────

    private fun tickOrbAttack(state: GameState, dt: Float) {
        val p  = state.player
        val ab = state.abilities.find { it.id == AbilityId.ENERGY_ORB }
        if ((ab?.level ?: 0) == 0) return
        val orbCount = ab!!.level.coerceAtMost(3)
        val orbR     = 75f + p.areaScale*15f
        val dmgMult  = if (p.orbBurst) 5f else 1f
        val iceSlow  = EvoType.ICE_ORB in state.evolutions

        repeat(orbCount) { i ->
            val angle = p.orbAngle + i*(2f*PI.toFloat()/orbCount)
            val ox = p.x + cos(angle)*orbR; val oy = p.y + sin(angle)*orbR
            for (e in state.enemies) {
                if (e.hp <= 0f) continue
                val ddx = e.x-ox; val ddy = e.y-oy
                if (sqrt(ddx*ddx+ddy*ddy) < e.radius+13f) {
                    val dmg = p.damage*0.5f*p.dmgMult*dmgMult*dt*6f
                    e.hp -= dmg; e.flashTimer = 0.06f; state.stats.damageDealt += dmg
                    if (iceSlow) applyStatusEffect(state, e, StatusEffectType.FREEZE, 0.5f)
                }
            }
        }
    }

    // ─── Black holes ──────────────────────────────────────────────

    private fun tickBlackHoles(state: GameState, dt: Float) {
        val p    = state.player
        val iter = state.blackHoles.iterator()
        while (iter.hasNext()) {
            val bh = iter.next()
            bh.life -= dt
            if (bh.life <= 0f) {
                for (e in state.enemies) {
                    val dx = e.x-bh.x; val dy = e.y-bh.y
                    if (sqrt(dx*dx+dy*dy) < bh.radius*1.5f) {
                        val dmg = 65f*p.dmgMult*e.shockDmgMult; e.hp -= dmg; e.flashTimer = 0.2f; state.stats.damageDealt += dmg
                    }
                }
                spawnParticles(state, bh.x, bh.y, 32, 0xFF8800FF.toInt(), bh.radius*1.2f, 250f)
                triggerShake(state, 7f, 0.5f); iter.remove(); continue
            }
            for (e in state.enemies) {
                val dx = bh.x-e.x; val dy = bh.y-e.y; val d = sqrt(dx*dx+dy*dy)
                if (d < bh.radius*2.5f && d > 1f) {
                    val pull = (1f - d/(bh.radius*2.5f))*320f
                    e.x += dx/d*pull*dt; e.y += dy/d*pull*dt
                }
            }
            spawnParticles(state, bh.x, bh.y, 2, 0xFF6600CC.toInt(), 10f, 0f)
        }
    }

    // ─── XP orbs ──────────────────────────────────────────────────

    private fun tickOrbs(state: GameState, dt: Float) {
        val p    = state.player
        val iter = state.orbs.iterator()
        while (iter.hasNext()) {
            val orb  = iter.next()
            val dx   = p.x - orb.x; val dy = p.y - orb.y
            val dist = sqrt(dx*dx + dy*dy)
            if (dist < p.magnet && dist > 1f) {
                val spd = 240f + (1f - dist/p.magnet)*200f
                orb.x += dx/dist*spd*dt; orb.y += dy/dist*spd*dt
            }
            if (dist < p.radius + orb.radius) {
                val gained = orb.value * p.xpGain
                p.xp += gained; state.stats.xpCollected += gained; iter.remove()
                spawnParticles(state, orb.x, orb.y, 4, 0xFF33FF88.toInt(), 6f, 40f)
                if (p.xp >= p.xpNext) {
                    p.xp -= p.xpNext; p.xpNext *= 1.45f; p.level++
                    state.phase = Phase.LEVEL_UP
                    state.pendingUpgrades = pickUpgrades(state)
                    spawnParticles(state, p.x, p.y, 30, 0xFF00FFAA.toInt(), 80f, -60f)
                    if (p.level == 10)  checkAndGrantAchievement(state, "reach_lv10")
                    if (p.level == 20)  checkAndGrantAchievement(state, "reach_lv20")
                }
            }
        }
    }

    // ─── Particles ────────────────────────────────────────────────

    fun spawnParticles(state: GameState, x: Float, y: Float, count: Int, color: Int, speed: Float, gravity: Float) {
        var spawned = 0
        for (pt in state.particles) {
            if (pt.active) continue
            val a = rng.nextFloat()*2f*PI.toFloat(); val s = speed*(0.4f+rng.nextFloat()*0.6f)
            pt.x = x+rng.nextFloat()*8f-4f; pt.y = y+rng.nextFloat()*8f-4f
            pt.vx = cos(a)*s; pt.vy = sin(a)*s
            pt.life = 0.3f+rng.nextFloat()*0.5f; pt.maxLife = pt.life
            pt.color = color; pt.radius = 2f+rng.nextFloat()*3f
            pt.gravity = gravity; pt.active = true
            if (++spawned >= count) break
        }
    }

    private fun tickParticles(state: GameState, dt: Float) {
        for (pt in state.particles) {
            if (!pt.active) continue
            pt.x += pt.vx*dt; pt.y += pt.vy*dt; pt.vy += pt.gravity*dt
            pt.vx *= (1f - 2.5f*dt); pt.life -= dt
            if (pt.life <= 0f) pt.active = false
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────

    fun addFloatText(state: GameState, x: Float, y: Float, text: String, color: Int, scale: Float = 1f) {
        state.floatTexts += FloatText(x, y, text, 0.9f, color, scale)
    }

    fun triggerShake(state: GameState, amount: Float, duration: Float) {
        if (amount > state.shakeAmt) {
            state.shakeAmt   = amount.coerceAtMost(20f)
            state.shakeTimer = duration
        }
    }

    fun checkAndGrantAchievement(state: GameState, id: String) {
        val def = AchievementList.ALL.find { it.id == id } ?: return
        state.pendingAchievements += def.name
    }

    fun checkAchievements(state: GameState, meta: MetaUpgrades) {
        val p = state.player; val s = state.stats
        fun check(id: String, cond: Boolean) {
            if (!cond) return
            val def = AchievementList.ALL.find { it.id == id } ?: return
            if (!AchievementList.isUnlocked(meta.achievementFlags, def.bit)) {
                meta.achievementFlags = AchievementList.unlock(meta.achievementFlags, def.bit)
                state.pendingAchievements += def.name
            }
        }
        check("first_kill",    state.kills >= 1)
        check("kill_50",       state.kills >= 50)
        check("kill_200",      state.kills >= 200)
        check("survive_5min",  state.elapsed >= 300f)
        check("survive_10min", state.elapsed >= 600f)
        check("reach_lv10",    p.level >= 10)
        check("reach_lv20",    p.level >= 20)
        check("kill_boss",     s.bossesKilled >= 1 || meta.totalBossKills >= 1)
        check("kill_5bosses",  meta.totalBossKills >= 5)
        check("combo_10",      s.bestCombo >= 10)
        check("combo_20",      s.bestCombo >= 20)
        check("open_chest",    s.chestsOpened >= 1)
        check("wave_15",       state.wave >= 15)
        check("wave_20",       state.wave >= 20)
        check("status_100",    meta.totalStatusApplied >= 100)
    }

    // ─── Ability activation ───────────────────────────────────────

    fun activateAbility(state: GameState, id: AbilityId, moveX: Float, moveY: Float) {
        if (state.phase != Phase.PLAYING) return
        val p  = state.player
        val ab = state.abilities.find { it.id == id } ?: return
        if (!ab.isReady()) return
        state.stats.abilitiesUsed++

        when (id) {
            AbilityId.DASH -> {
                val len = sqrt(moveX*moveX+moveY*moveY)
                val nx  = if (len > 0.01f) moveX/len else 0f
                val ny  = if (len > 0.01f) moveY/len else -1f
                p.isDashing = true; p.dashVx = nx*p.dashSpeed; p.dashVy = ny*p.dashSpeed
                p.dashTimer = p.dashDuration; p.iFrames = p.dashDuration + 0.15f
                ab.cdTimer = ab.effectiveCd(p.cdr)
                if (EvoType.FLAME_DASH in state.evolutions) {
                    repeat(8) { i ->
                        val tx = p.x-nx*i*12f; val ty = p.y-ny*i*12f
                        spawnParticles(state, tx, ty, 6, 0xFFFF6600.toInt(), 35f, -40f)
                        for (e in state.enemies) {
                            val ddx = e.x-tx; val ddy = e.y-ty
                            if (sqrt(ddx*ddx+ddy*ddy) < 45f) {
                                val dmg = 22f*p.dmgMult; e.hp -= dmg; e.flashTimer = 0.1f
                                state.stats.damageDealt += dmg
                                applyStatusEffect(state, e, StatusEffectType.BURN, p.dmgMult*0.5f)
                            }
                        }
                    }
                    triggerShake(state, 4f, 0.25f)
                }
            }
            AbilityId.SHOCKWAVE -> {
                val r = 165f*p.areaScale
                doShockwave(state, p.x, p.y, r, 65f*p.dmgMult)
                spawnParticles(state, p.x, p.y, 40, 0xFF00CCFF.toInt(), 120f, -30f)
                triggerShake(state, 7f, 0.35f)
                ab.cdTimer = if (EvoType.INFINITE_PULSE in state.evolutions) 1.2f else ab.effectiveCd(p.cdr)
            }
            AbilityId.BLACK_HOLE -> {
                state.blackHoles += BlackHole(p.x, p.y, 130f*p.areaScale, 3.5f, 3.5f)
                spawnParticles(state, p.x, p.y, 28, 0xFF6600CC.toInt(), 95f, 0f)
                triggerShake(state, 6f, 0.6f)
                ab.cdTimer = ab.effectiveCd(p.cdr)
            }
            AbilityId.TIME_SLOW -> {
                state.timeSlowActive = true; state.timeSlowTimer = 5f+(ab.level-1f)
                spawnParticles(state, p.x, p.y, 28, 0xFF00FFFF.toInt(), 70f, 0f)
            }
            AbilityId.SHIELD_PULSE -> {
                p.shieldActive = true; p.shieldTimer = p.shieldDuration+(ab.level-1)*0.5f
                for (e in state.enemies) {
                    val edx = e.x-p.x; val edy = e.y-p.y; val d = sqrt(edx*edx+edy*edy)
                    if (d < 160f && d > 0f) {
                        val f = 1f-d/160f
                        e.x += edx/d*500f*f*0.08f; e.y += edy/d*500f*f*0.08f
                        val dmg = 18f*p.dmgMult*f; e.hp -= dmg; e.flashTimer = 0.12f; state.stats.damageDealt += dmg
                    }
                }
                spawnParticles(state, p.x, p.y, 32, 0xFF4488FF.toInt(), 100f, -20f)
                triggerShake(state, 4f, 0.2f)
                ab.cdTimer = ab.effectiveCd(p.cdr)
            }
            AbilityId.ENERGY_ORB -> {
                if (ab.level == 0) return
                p.orbBurst = true; p.orbBurstTimer = 3f
                spawnParticles(state, p.x, p.y, 20, 0xFFFFDD00.toInt(), 75f, -20f)
                ab.cdTimer = ab.effectiveCd(p.cdr).coerceAtLeast(5f)
            }
        }
    }

    private fun doShockwave(state: GameState, cx: Float, cy: Float, radius: Float, dmg: Float) {
        val p = state.player
        for (e in state.enemies) {
            val dx = e.x-cx; val dy = e.y-cy; val d = sqrt(dx*dx+dy*dy)
            if (d < radius && d > 0f) {
                val f = 1f-d/radius
                val hit = dmg*f*e.shockDmgMult; e.hp -= hit; e.flashTimer = 0.18f
                e.x += dx/d*90f*f; e.y += dy/d*90f*f; state.stats.damageDealt += hit
                if (p.shockChance > 0.3f) applyStatusEffect(state, e, StatusEffectType.SHOCK, p.dmgMult*0.5f)
            }
        }
    }

    // ─── Reset ────────────────────────────────────────────────────

    fun reset(state: GameState, meta: MetaUpgrades = MetaUpgrades()) {
        val p   = state.player
        val def = Characters.ALL.find { it.type == meta.selectedCharacter } ?: Characters.ALL[0]

        p.x = state.worldW/2f; p.y = state.worldH/2f
        p.speed    = (280f + meta.speedBonus) * def.speedMult
        p.maxHp    = (100f + meta.hpBonus)    * def.hpMult
        p.hp       = p.maxHp
        p.xp = 0f; p.xpNext = 60f; p.level = 1
        p.damage = 20f*def.damageMult; p.fireRate = 1.4f*def.fireRateMult; p.fireTimer = 0f
        p.projectiles = 1; p.range = 300f; p.regen = 0f; p.magnet = 85f; p.iFrames = 0f
        p.lifesteal = 0f; p.critChance = 0f; p.areaScale = 1f
        p.cdr = meta.cdrBonus; p.dmgMult = 1f; p.xpGain = 1f+meta.xpBonus
        p.isDashing = false; p.shieldActive = false; p.orbAngle = 0f; p.orbBurst = false
        p.armor = 0f; p.piercingShots = 0; p.chainShots = 0
        p.burnChance = 0f; p.freezeChance = 0f; p.shockChance = 0f
        p.knockbackMult = 1f; p.isMoving = false; p.hitFlashTimer = 0f

        state.enemies.clear(); state.bullets.clear(); state.orbs.clear()
        state.floatTexts.clear(); state.blackHoles.clear(); state.chests.clear()
        for (pt in state.particles) pt.active = false

        state.phase = Phase.PLAYING; state.wave = 1; state.waveTimer = 0f
        state.waveDuration = 30f; state.spawnTimer = 0f; state.spawnInterval = 2f
        state.kills = 0; state.elapsed = 0f; state.pendingUpgrades = emptyList()
        state.shakeTimer = 0f; state.shakeAmt = 0f
        state.timeSlowActive = false; state.timeSlowTimer = 0f
        state.currentEvent = null; state.eventTimer = 0f
        state.eventAnnouncement = null; state.nextEventWave = 6
        state.boss = null; state.showBossWarning = false
        state.runCurrency = 0; state.evolutions.clear()
        state.chestSpawnTimer = 35f; state.pendingAchievements.clear()

        state.combo.count = 0; state.combo.timer = 0f; state.combo.maxCombo = 0
        val st = state.stats
        st.damageDealt = 0f; st.damageTaken = 0f; st.healingDone = 0f
        st.xpCollected = 0f; st.bossesKilled = 0; st.elitesKilled = 0
        st.chestsOpened = 0; st.abilitiesUsed = 0; st.bestCombo = 0
        st.statusApplied = 0; st.totalKillsThisRun = 0

        for (ab in state.abilities) { ab.level = 0; ab.cdTimer = 0f }
        val startAb = def.startAbility ?: meta.startAbility
        startAb?.let { id -> state.abilities.find { it.id == id }?.level = 1 }
    }
}
