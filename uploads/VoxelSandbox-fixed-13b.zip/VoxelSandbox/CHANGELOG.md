# VoxelSandbox changelog

## v13 - stable far terrain, a real LOD ladder, cleaner water, and a flight recorder

**Not compiled or run on a device.** This was written without a Kotlin toolchain (none is
available here), like several versions before it. What *was* checked: every shader compiles and
links in a WebGL2 (GLSL ES 3.00) driver; the level-of-detail blending logic was ported to Python and
checked for exact agreement between levels; and all Kotlin was checked for balanced delimiters and
for every cross-file reference. If the build reports an error, it will be a plain type or name slip:
send the message and it is a one-line fix.

**Build fix (CI run 1831).** The first build of v13 stopped on two compile errors in
`diag/DiagLog.kt` ("No set method providing array access"): `upload()` and `farTile()` added a
`Float` sample straight into a `DoubleArray` element. Both now convert it with `.toDouble()` first.
Nothing else changed.

### Distant terrain moved / "waved" while you moved or turned (fixed)

Four separate mechanisms could do this; all are gone:

- **Levels were drawn on top of each other and one was sunk by a distance-dependent amount.** Near
  each seam the coarser level was lowered by an amount that depended on its distance from the
  *player*, so the ground heaved as you walked, and where the finer level ended there was a hard
  height step. Now the columns of a level slide smoothly to the height of their *parent* column
  (2 x 2 columns share one) over the outer part of their ring (a per-vertex target height + a
  smoothstep of distance in the vertex shader). At the ring's edge a fine mesh *is* the coarse
  mesh, so levels meet with no overlap, no sinking, no step and no popping, and the meshes
  themselves stay static and cached. Equal neighbours whose parents differ get a (flat) wall that
  opens as they slide, so there is no crack either.
- **The voxel -> distant-terrain dissolve used screen-space noise.** The stipple was fixed to the
  screen, so the terrain swam behind it whenever the camera moved or turned. It is now noise fixed
  to the world (a quasi-random value per 2 x 2 block cell).
- **Sampling shimmer.** Textures were picked a quarter mip level *sharper* than the hardware rule
  with single-texel fetches, so pixels skipped texels and which ones changed with every camera
  movement. The bias is now a third of a level *coarser*; up close (texels bigger than pixels)
  nothing changes and pixels stay crisp.
- **Per-block grain on far cliffs flickered at large coordinates.** It was decided by
  `floor()` of an interpolated world position, which on a wall (exactly on a cell boundary) comes
  down to the last bit of the interpolation, and at x or z beyond a few thousand that bit is noise.
  The grain is now offset away from cell boundaries and fades out by 220 blocks, where it would
  only alias.

### Intermediate levels of detail (LOD)

Distant terrain is now a ladder of six levels, finest first, every level's columns twice as wide as
the one before and all on a common grid:

| level | name | column | ring (blocks from the player) |
|------:|------|-------:|-------------------------------|
| - | LOD 0: voxel chunks | 1 | unchanged |
| 0 | LOD 1 (high) | 2 | thin ring just behind where the voxel terrain dissolves (about 56 blocks wide) |
| 1 | LOD 2 (medium) | 4 | to 512 (this was the old level 0) |
| 2 | LOD 3 (low) | 8 | 512 - 896 (the old level 1) |
| 3 | very far | 16 | 896 - 1408 (new: bridges what used to be an 8 -> 32 jump) |
| 4 | very far | 32 | 1408 - 2304 (the old level 2, unchanged) |
| 5 | very far | 64 | beyond (the old level 3, unchanged) |

The original far terrain is kept as the VERY FAR family (its 32- and 64-block levels are untouched
apart from where their rings start). Cost control: the 2-block ring costs about four times the
triangles per block of the next level, so it is thin, uses small (64-block) tiles so a thin ring
wastes few triangles, is built *last* (it never delays the horizon or the fog), and is dropped
while the adaptive distance has pulled the view in (below 85 %; back at 97 %). Each 4-block
tile hands the ring over to the 2-block level only once every 2-block tile it needs is on the GPU,
so there is never a hole and never two surfaces. Ground under (near-)opaque water is not built:
level 0 keeps the sea floor down to 10 blocks, level 1 to 3.5, coarser levels keep only the shore
(see water, below). That saves triangles on every coast. Levels 0 and 1 stand real trees (which
sink into the ground at the end of their ring); coarser levels raise forests into a canopy layer, as before.
Ring columns now get their slope from their true neighbours (the height window is one column
larger), so colour and canopy of a tile's edge match the neighbouring tile exactly.

### Distant materials look natural

- The soft colour patches were three sine waves, so they formed regular stripes and repeats. They
  are now domain-warped fractal value noise: irregular clusters at several scales, a pure function
  of world position (identical at every level, never re-rolled, stable while moving). The finest
  octave is dropped on coarse levels, where it would only turn into speckle.
- A small tileable noise texture (`FarNoiseTexture`, 128 x 128, 16 KB) adds soft, world-anchored tonal
  variation to the flat palette colours, growing with distance (two taps at different scales and
  axes so the repeat never shows). It costs two texture fetches per far pixel and nothing in
  geometry.
- Biome, surface type and the generator's rules are untouched: the distant colours still come from
  the same `surfaceFor` rules as the voxel terrain.

### Water

The dark jagged contour-like lines had several independent causes (I could not see your
screenshots in this session, so each plausible cause is closed rather than one guessed at):

- **T-junction cracks in the voxel water.** Deep open sea is merged into big rectangles; where one
  meets the many small quads of unmerged water (or the next chunk's rectangle) the shared edge has
  extra vertices on one side only, and rasterisers round the two sides differently: pixel-wide
  cracks along the *whole 8-block-depth contour*, with the seabed or sky showing through. Merged
  rectangles now overlap their neighbours by 0.004 block (water is not depth-written and is ~97 %
  opaque there, so the overlap is invisible and the cracks are not).
- **Distant sea was only 97 % opaque,** so 3 % of every seam, crack and stray triangle behind it
  showed through, over a whole ocean. Beyond 300 blocks the sea is now fully solid, and the far
  ground under it is not built (see LOD).
- **Seabed steps outlined themselves through the surface.** Walls under water are shaded like tops,
  and low shore steps halfway, so a coast no longer gets a dark outline.
- **Rings of far water now overlap by 1.5 blocks** instead of meeting exactly (a hairline gap
  would show the dark ground as a ring).
- **Depth precision.** The distant pass's near plane could be as small as half a block while the
  voxel area had not loaded; depth resolution at 3000 blocks is then about a block, and the sea
  (an eighth of a block above shallow ground) and the ground fought for every pixel. The floor is
  12 blocks now (under 0.05 block at 3000).
- The old per-level "sink" no longer exists, so land near the sea at a seam cannot rise through water.

### Diagnostics: a low-overhead flight recorder

Settings > Diagnostics: **Off / Lightweight / Detailed**, and an optional on-screen panel. Pause menu >
**Diagnostics**: *Capture incident*, *Save full log*, *Share report* (Android's share sheet; files
are attached through a content URI, never the clipboard).

- Off does nothing (one volatile read per hook; no thread, no memory). On: events go into a
  preallocated ring buffer (12,288 events, ~0.5 MB, no allocation per event); one background thread
  formats them to JSONL and appends in batches (no file I/O on the render thread or any game
  thread), samples memory, and writes reports.
- Records: FPS and frame-time percentiles per second, stutters, freezes, Java/native heap,
  chunk generation and meshing times, GPU upload times, far-tile builds per level (with triangle
  counts), GL errors, coverage and *missing terrain*, governor changes, lifecycle, crashes.
- **Incidents** (lag spike >= 200 ms (120 detailed), freeze >= 500 ms, GL error, error, heap nearly
  full, low-memory, missing terrain for 4 s, or the manual button) keep the 10 s before and 5 s
  after, written to their own file and included in the report. Rate limited (15 s apart, 16 max).
- Timestamps: local time with milliseconds, derived from the monotonic clock (session start wall
  time + monotonic offset), plus elapsed seconds since the session began.
- Survives crashes: events reach disk within 1-2 s; the crash handler flushes and writes the last
  30 s; the next launch notes that the previous session ended abnormally. Folder: bounded to 32 MB
  and the newest 6 sessions; one session file is capped at 6 MB (12 detailed) after which only
  critical events are written.
- Reports say what was lost: events overwritten before writing, shed low-priority events, size cap,
  failed writes, suppressed incidents, and the measured overhead (render thread microseconds per
  frame; background thread busy time). When the writer falls behind or its own cost passes 1.5 % of
  frame time, low-priority events are shed automatically.

Statistics overlay: new line `lod tris(k): LOD1 LOD2 LOD3 | far16 far32 far64`.

### Known limitations

- Not run on a device (see the top). Please try Detailed logging for a minute at a coast and a
  mountain and share the report if anything looks wrong.
- The 2-block ring is dropped under load, so on a device that is always below ~30 FPS the first
  distant ring is the 4-block one, as before.
- The geomorph slides *heights* only: colours still change at a ring's edge (they come from the same
  world-position noise at every level, so the change is subtle, but it is not blended).
- The diagnostic panel shares the existing stats text view, so it appears with the same layout.
- A coast that is far away is built from columns at least 8 blocks wide, so its outline is coarse
  by construction.

## v12 - crisp pixels, calmer water, and about half the distant-terrain triangles

Found from three screenshots at a render distance of 400 chunks (26-37 FPS, 1.0-1.4 million
triangles per frame, three quarters of them distant terrain):

- **Textures were blurry because the GPU was filtering them.** The atlas asks for nearest-texel
  sampling, but on many mobile GPUs (the screenshots look exactly like it) anisotropic filtering is built on
  bilinear probes and quietly overrides that, which smears 16x16 pixel art into soft blotches
  (worst on the ground, where it streaks towards the horizon). Anisotropy is now off, and the
  voxel-terrain shaders no longer rely on the sampler at all: they pick the mip level from the
  pixel's footprint and `texelFetch` single texels (`Shaders.crisp`), which no driver can
  filter. If a driver rejects that shader the game falls back to the old one. (Checked by
  rendering it on a software GLES 3.2 against a CPU reference at six magnifications and
  minifications.)
- **Distant terrain costs half the triangles.** Every far tile used to be 64 x 64 columns whatever
  its distance, so a tile a kilometre or more away cost as much (about 16-18k triangles) as one
  at the edge of the voxel area. The two coarsest levels are now 32 x 32 columns of twice the
  width (same tile size, same bands), about 4k triangles each, and they build four times
  faster. The two finest levels are unchanged. Modelled on the real tile builder, a typical
  400-chunk view goes from about 750k far triangles to about 410k.
- **Tiles that start beyond the fog are not drawn at all** (they were pure fog colour, which is
  also exactly the sky colour at and below the horizon).
- **The adaptive distance can pull in further** (down to 40 % of the render distance, never
  below 560 blocks) because that now really saves work: it used to stop at 70 % and sit at
  27 FPS. While it is pulling in, the voxel area shrinks with it too (down to 60 % of its
  radius, once the distant terrain is proven to cover that range): a block of voxel terrain
  costs about ten times the triangles of the distant terrain that replaces it.
- **Water:** the seabed no longer shows through as dark lines. Opacity now follows the light's
  path through the water (depth / viewing angle) and rises with distance, so a slanted view
  through two or three blocks is nearly solid; the water tile lost its light flecks (they
  stretched into rain-like streaks at a slant) and is a calmer set of blues, and the
  anisotropic filtering that smeared it is gone too. The thin dark lines that remain standing
  in the sea in your screenshots look like real land rather than a water bug (their pixels are
  unblended dark gravel grey and grass tufts stand on them): 1-block-wide bars and terraces at
  sea level that stick out of the water by an eighth of a block or more.

## v11 - 16x16 textures, calmer water, a far horizon that fills in fast, and a lot less CPU per chunk

Saves are compatible with v10: the terrain is bit-for-bit the same (every change to the
generator below is a pure speed-up, checked against the old code on millions of samples).

### Look
- **16x16 block textures, like the classic voxel games.** Every tile is now hand-tuned 16x16
  pixel art (speckled grass/dirt/stone/sand, ragged grass caps on the sides, vertical bark,
  ring-patterned log ends, leaves with a few see-through holes, ...), baked into the code, so
  nothing is generated at start-up. The atlas shrank from 512x512 to 256x256 (a quarter of the
  texture memory and bandwidth). Pixels stay crisp up close; mip-mapping smooths them in the
  distance. The colour ramp of the distant terrain is derived from the new tiles, so the far
  ground matches the near ground.
- **Water** now matches the block textures: a 16x16 pixel-art water tile (four blues and a few
  light flecks), one repeat per block, drifting slowly or running with the current; depth tint,
  a sky tint at grazing angles. The old shader switched the pattern off with distance (so water
  looked flat from afar and "filled in" as you walked up to it) and added foam, a swell and a
  second blended copy of the tile. All of that is gone: the pattern is the same at every distance
  (the mip chain averages it away on its own), and the shader is about half the work per pixel
  (one texture fetch, no per-pixel trigonometry), which matters because water covers a large part
  of the screen over an ocean.

### Far terrain (render distances in the hundreds of chunks)
- **Tiles are built by two or three threads at once** (one on small CPUs), published in plan
  order, so the horizon fills in two to three times faster. Until a ring of tiles exists the fog
  stays in front of it, so a faster build is a longer visible range sooner.
- **Each tile's heights cost about a third less:** the river/lake/mountain/detail layers are
  skipped where their weight is exactly zero (open sea, high ground), and the smooth base
  elevation, which used to be computed a second time per cell for the biome rules, comes out of
  the same pass as the height.
- Trees: the 25 height samples per tree candidate became at most 13 (usually 5).

### Chunk generation and meshing
- Terrain generation is about a quarter to a third cheaper per chunk: base elevation and the
  humidity/temperature fields are computed once per column instead of two or three times, ore
  noise is sampled only for rock that is actually there, caverns are skipped cell by cell where
  the noise cannot reach the threshold, and blocks are written straight into the sub-chunk
  arrays.
- **Meshing reads one padded copy of the cells around a sub-chunk** (18x18x18) instead of doing a
  chunk/world lookup per face and per ambient-occlusion probe. Rock deep underground, with
  nothing see-through in or next to it, is recognised in a few microseconds and skipped. The
  output is identical to v10 (fuzz-tested on thousands of random sub-chunks, including chunk edges,
  unloaded neighbours and the world floor and ceiling), the CPU time per sub-chunk is about a third
  lower, and the per-lookup allocations are gone.
- The crosshair ray looks each cell up once instead of about twenty times.

## v10 - new world, caves, clouds, water, seagrass, and a lot less per-frame work

This version is a big step. **Old saves are not compatible** (the world is taller and the
terrain is different): "Continue" with a v9 save starts a fresh world.

### The world
- **Taller world, real mountains.** The world is 256 blocks tall (was 128) with sea level at 64
  (was 40). Mountain ranges are broad massifs that climb through foothills, forest, bare rock
  and a snow cap, and peak around 180 blocks above the sea (they used to top out near 85).
  About 17% of the land is above the rock line. Ridge height grows with the square of
  the mountain mask, so there are long gentle foothills before the cliffs.
- **Biomes that make sense.** Biomes come from a temperature x humidity table with five
  temperature bands, using the temperature *at the ground* (it drops with altitude). Desert
  (hot) can no longer touch snow (frozen): the way between always runs savanna -> plains ->
  taiga, at least ~400 blocks and typically ~1000. Mountains zone by height from the same
  rule, so the snow line is lower in cold climates and higher in hot ones.
- **Swamps** (new): wet, mild, low land is flattened to about sea level and dotted with shallow
  ponds, with murky olive grass, dense grass and oaks. **Lily pads now grow only in swamps.**
- **Seagrass** (new): meadows on the bed of seas, lakes and rivers (2-14 blocks deep). It is a
  plant that lives in a cell that is also full of water; breaking it leaves water.
- **Caves and a deep underground.** Winding tunnels (in four layers, clustered into cave
  systems), big caverns, and cave entrances: sloping ramps cut into hillsides, so caves are
  findable. Nothing comes closer than 6 blocks to the surface (9 under water), so the ground is
  intact and the sea never drains; any cave cell that would touch water is sealed as rock.
  Below y~24 the rock is dark **deep stone**, with coal veins and pockets of gravel and dirt.
  Faces get darker the deeper they are under the ground, so caves feel underground.
  Cave faces that cannot be seen from outside are only meshed while you are underground (and
  always for chunks with a cave mouth, so a far entrance is dark rock and not a see-through hole,
  and for chunks you have edited), which keeps the hidden underground out of memory and off the
  GPU in the normal case of walking or flying over the surface. Going underground meshes the
  chunks around you within a fraction of a second; they are dropped again 20 s after you leave.

### Look
- **Water**: replaced the one-block 32x32 tile (which tiled into a visible grid and aliased into
  moire) with a 128x128 procedural tile of five blues and thin ripple lines, stretched over
  8-12 blocks, two copies blended at different scales/angles so no lattice of repeats shows,
  fading to a flat colour with distance (with a mip bias), a slow large-scale swell, and a sky
  tint at grazing angles. Still flat and chunky, not realistic.
- **Clouds**: thick, blocky, shaded clouds (flat grey-blue underside that is darkest where the
  cloud is thickest, white tops, sun-lit sides) instead of a flat sheet. One static mesh,
  drawn 3 x 3 times with a single instanced draw; far clouds dissolve into the sky colour
  itself (no alpha blending). Mountains poke through the layer (base y=212).

### Distances
- Render distance slider now goes up to **400 chunks**, detail distance up to **300**, on a
  quadratic scale so the low end stays finely adjustable. Full-detail (voxel) chunks cost
  memory, so a device can only keep so many loaded: the settings text says how many chunks of
  full terrain *this device* holds (typically ~20 on a 512 MB heap), and the distant terrain
  takes over beyond that. To get more, raise `CHUNK_HEAP_SHARE` in WorldManager (memory risk).

### Performance (the HUD showed ~900 GL calls and ~1M triangles per frame, with the GL thread
### spending 22-26 ms of a ~30 ms frame in the driver: CPU-bound on call count, not on Kotlin)
- Regions are 4x4 columns (was 2x2): about a quarter of the draw calls and buffer binds.
- Plants (grass, flowers, seagrass, lily pads) are only drawn within 120 blocks: one less draw
  per far region and far less alpha-tested overdraw. Trees are drawn at any distance.
- **Flat open sea is merged into big quads** (voxel water: greedy rectangles per 16x16 chunk
  layer; distant water: any aligned block of 4x4..64x64 deep cells becomes a fan with the edge
  vertices kept, so no cracks). Over open ocean this was ~190k + ~250k triangles.
- The **sea floor under 10+ blocks of water** is only meshed while you are underwater and
  within ~3 chunks (from above it is hidden by the 93%-opaque water anyway): that was ~230k
  triangles of an ocean view, and flying over the sea no longer triggers any re-meshing for it.
- Chunk generation: ore/pocket noise on a 2-block lattice, cave fields on a 4-block lattice.
- Adaptive-distance governor engages below 30 fps (was 42) and goes no lower than 70% (was 65%).

### How it was checked (no Kotlin toolchain here, so none of it was compiled or run on a device)
- The terrain/climate/cave/cloud/water algorithms were prototyped in Java (identical integer
  semantics) and judged on rendered maps, silhouettes and slices; the cloud and water shaders
  were rendered with the real GLSL in headless WebGL2, and every shader pair in Shaders.kt
  compiles and links there. The water-quad merge, the fan triangulation and the ore rates were
  fuzz/unit tested numerically.
- The Kotlin was desk-checked against the original and checked for balanced braces. **Please
  build it and tell me about any compile error** -- and about frame times: the draw-call and
  triangle reductions are measured in counts, not in milliseconds.
- Known trade-off: where merged flat water meets unmerged water there can be the odd
  single-pixel crack (T-junction), as at the distant-terrain level seams.

## v9: flowing pixel-art water, smoother LOD transition, much lighter on the GPU

## What changed
- **Water flows.** Break a wall next to a lake and it pours in; dig a shaft and it falls; it runs about
  7 blocks over flat ground, one level lower per block, and drains again when you cover its source.
  The last hotbar slot is now **Water** (8 sources in survival, unlimited in creative): place one and watch
  it spread. It is a small event-driven simulation (`FluidSimulator`): nothing runs until a block next to
  water changes, then a few hundred cells per tick at 5 ticks a second, so calm oceans cost nothing.
  How full a cell is lives in the spare top 3 bits of its block byte (`Fluid`), so there is no new storage
  and old saves load unchanged (ocean and lake water are all full "source" blocks).
- **Water looks like the rest of the game.** The reflective / glinting / swelling water is gone. Water is now
  pixel art: a 32x32 tile in six blues (`WaterTexture`), nearest-texel filtered, sliding along the flow
  direction, with a depth tint (azure shallows, deep blue open water) and shoreline foam. Flowing water
  gets stretched streaks, waterfalls get their own side faces with tall streaks running down. The surface
  height follows the water level and slopes smoothly between cells.
- **LOD starts farther out and blends in.** Default detail distance 16 -> 20 chunks (slider up to 32;
  an old saved default of 16 moves to the new one once). The voxel terrain now *dissolves* into the distant
  terrain over the last ~30-45 blocks (ordered-noise screen door), instead of ending in a hard line.
  The distant terrain also carries the same per-block brightness speckle the real blocks have, so flat
  colour no longer reads as a different material. The textured wall that used to stand at the outer rim
  of loaded chunks is gone (see below), and the coverage scan runs 8x per second instead of 4x.
- **Lighter on the GPU / CPU (no visual cost):**
  - Opaque blocks are drawn by a fragment shader with **no `discard`**, so the GPU can reject hidden pixels
    early (and tile-based GPUs can remove them outright). Only leaves and plants are alpha-tested, in
    their own draws afterwards (`MeshData.opaqueEnd` / `cutoutEnd`, `ChunkGpuMesh.drawOpaque/Cutout/DoubleSided`).
  - Plants and lily pads are one quad per plane drawn with culling off instead of two quads each: half the
    vertices and triangles of every meadow, and less memory per chunk.
  - Faces towards a chunk that is not generated yet are not drawn. The outer rim of loaded chunks used to
    be a tall stone/dirt wall of faces nobody should see; that was a big share of all triangles.
  - Region uploads are debounced: a region still receiving subchunk results waits ~70 ms and is built once,
    instead of being rebuilt (and re-uploaded) after each of up to 32 results. Streaming hitches drop a lot.
  - All-air subchunks are not queued for meshing at all (a chunk generating queues its neighbours' too).
  - The new water shader is a couple of texture fetches and a tint (the old one did Fresnel, normals,
    glints and foam per pixel over big translucent oceans); water is also never drawn twice where the
    distant and voxel layers meet.
  - Voxel regions entirely past the dissolve edge are skipped; the sky shader skips the sun terms away from
    the sun.

## Heads-up
- New hotbar slot (Water). An old save has no count for it, so it starts with 8.
- Flowing water is saved with the chunks it entered. Water that was already "frozen" mid-flow when you
  quit stays as it was until something next to it changes.
- Water does not push the player or slow swimming (not asked for, not changed).
- Still written without a Kotlin/Android toolchain: not compiled or run on a device. The GLSL was compiled
  and the water previewed in a headless WebGL2 context, and the fluid rules were run in a Python port.
  If the build reports an error, the log line points straight at it.

---

# (previous) VoxelSandbox v8: creative mode, blocky LOD with trees, new biomes, fixes

## What changed
- **Creative mode** (star button on the HUD, or Settings): free flight along the look direction, jump = up,
  new "fly down" button, double-tap jump toggles flight, unlimited blocks, instant plant/block breaking.
  Fly speed slider in Settings (8..200 blocks/s) for fast travel while testing.
- **Destroy laser** (creative only, new HUD button): hold to carve a 96-block-long tube through everything
  in front of you (pierces terrain, trees, plants) to stress-test chunk edits and remeshing. Edits are batched
  (`WorldManager.setBlockBatched` / `flushBatchedEdits`) so a pulse remeshes each affected subchunk once.
- **Distant terrain (LOD)** now looks like voxels: flat-topped columns with vertical walls, flat colours,
  neighbours merged into long quads. Level 0 stands real little trees (trunk + canopy boxes) at exactly the
  spots the chunk generator will grow them; coarser levels raise forests into a dark canopy layer.
  Tiles are 64x64 columns (256 blocks at level 0), so roughly a quarter of the draw calls.
- **Leaves**: new crisp pixel-art leaf textures (flat palette colours, rare isolated holes with a darker rim)
  instead of the smooth blurry scatter; you can no longer see straight through trees.
- **Thin outlines on blocks** (sand, grass, snow, ...): caused by texture filtering at low angles reaching into
  the neighbouring tile of the atlas. Every tile now has a 16-texel gutter filled with its own pattern.
- **Sky box outline**: it was the edge of the translucent cloud square. Clouds are now a blocky, drifting layer
  with no edge (`CloudRenderer`, `Shaders.CLOUD_*`) that fades out with distance.
- **Biomes** (`Climate`, `Biome`): plains, forest, birch forest, taiga, snowy plains, snowy taiga, savanna,
  desert, mountains, snowy peaks, beach, snowy shore (gravel), ocean, deep ocean, lake. Decided from the slow
  climate fields, the smooth coastline and altitude, never from local bumps, so no more sand mixed with snow
  (snowy coasts are gravel, beaches only exist in warm climates, snow line depends on temperature).
  The biome you are in is shown at the top of the screen.
- **Terrain**: the 1-block jitter (micro noise) is gone, high-frequency hill octaves are weaker, and lone
  1-block bumps/pits are removed (`TerrainGenerator.despike`), so plains are flat and slopes form wide terraces.
- **Jump**: snappier (gravity 32, jump speed 8.9, about 1.25 blocks high), feet-level collision epsilon, and
  Auto Jump is now on by default.
- **Plants** can be targeted (small outline box) and broken, and placing a block on one replaces it.
- **Lily pads** float on shallow warm water in patches (new block, flat quad).
- **Performance**: voxel chunks are drawn in 2x2-column regions (about 3.5x fewer draw calls, the main cost on
  phones), distant tiles are 4x bigger (about 4x fewer draws), water shader skips its fine ripple layer and
  foam for distant fragments, one distant tile uploaded per frame.

## Heads-up
- Save format bumped to v3 (the terrain changed): "Continue" with an old save starts a fresh world.
- Written without a Kotlin/Android toolchain, so not compiled or run on a device. If the build reports an
  error, the log line points straight at it.

---

# Earlier: VoxelSandbox v7: water, textures, realistic terrain, 200-chunk view distance

## What changed
- **Animated water**: translucent surface drawn in its own pass (`WaterRenderer`, `Shaders.WATER_*`).
  Scrolling ripple normals, gentle vertical swell, Fresnel sky reflection, sun glint, depth-based
  colour/opacity (turquoise shallows -> deep blue), drifting shoreline foam. Works on voxel water
  and on distant water. You can now also place blocks into water.
- **Textures**: atlas is now 32x32 per tile (was 16x16), anisotropic filtering where available.
  New scattered-leaf foliage (midribs, rims, holes) for oak/birch/spruce; richer grass, dirt, stone
  (cracks), sand, bark, coal. Grass sides are mostly green so hills no longer read as brown contour bands.
  New blocks: snow, gravel, sandstone, dry grass, cactus, and cross-shaped plants (tall grass,
  poppy, dandelion, dead bush). All textures stay procedural (`BlockTextures.kt`), no assets.
- **Terrain** (`TerrainShape`, `Climate`, `TerrainGenerator`, `TreeBuilder`): world is now 128 tall
  with sea level 40. Oceans, continents, rolling hills, ridged mountain ranges with snow caps and
  rock/scree on steep slopes, rivers, lakes, beaches, deserts, savanna, taiga/snow, per-biome
  trees (oak, birch, tall spruce, cacti). New worlds spawn on dry land (`findSpawn`).
- **Render distance**: slider maximum is 200 chunks (3,200 blocks). Distant terrain now has 4 levels of
  detail (`FarTerrain`, `FarTerrainRenderer`) so the triangle count stays near a 600-block view's.
  Distant terrain is drawn in its own depth range for stable depth precision at that range.
- **Sky**: gradient sky with a sun (`SkyRenderer`, `Atmosphere`); fog fades into the horizon colour.

## Heads-up
- Save format bumped to v2: worlds saved with v6 cannot be loaded (their terrain no longer exists).
  "Continue" with an old save starts a fresh world.
- Chunk memory budget is now `WorldConfig.RESIDENT_BYTES_PER_CHUNK` (96 KB per chunk).
- This version was written without access to a Kotlin/Android toolchain, so it has not been
  compiled or run on a device. If the build reports an error, the log line points straight at it.

## Tuning knobs
- Water look: constants in `Shaders.WATER_FRAGMENT` (colours, alpha, glint power).
- Sky/fog colours and sun direction: `Atmosphere`.
- Terrain scale/shape: numbers in `TerrainShape.height` (continent frequency 0.00042, mountain
  height 74, hill amplitude), biome thresholds in `Climate.classify`.
- LOD ring distances: `FarTerrain.BAND_OUTER` / `BAND_OVERLAP`.
