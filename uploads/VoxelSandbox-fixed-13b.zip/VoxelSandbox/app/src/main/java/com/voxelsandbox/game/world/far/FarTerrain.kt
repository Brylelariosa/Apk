package com.voxelsandbox.game.world.far

import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.gl.TextureAtlas
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.generation.Biome
import com.voxelsandbox.game.world.generation.Climate
import com.voxelsandbox.game.world.generation.SurfaceKind
import com.voxelsandbox.game.world.generation.TerrainGenerator
import com.voxelsandbox.game.world.generation.TreeSpecies
import com.voxelsandbox.game.world.mesh.MeshData
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Tile add ([tile] != null) or removal ([tile] == null) for [key], delivered to the GL
 *  thread strictly in the order the worker produced them. A single ordered stream matters:
 *  with separate "ready" and "unload" queues a tile that was built, unloaded and rebuilt
 *  could be applied in the wrong order and leave a ghost mesh behind. */
class FarEvent(val key: Long, val tile: FarTile?)

/** One finished distant-terrain tile, ready for the GL thread to upload: the opaque land
 *  mesh (seven floats per vertex, see [FarTerrain.LAND_FLOATS]) and (where the tile touches
 *  water) the translucent water mesh (six floats per vertex). */
class FarTile(
    val key: Long,
    val land: MeshData,
    val water: MeshData,
    val minY: Float,
    val maxY: Float
) {
    val level: Int get() = FarTerrain.levelOf(key)

    /** Edge length of the (square) tile in blocks. */
    val size: Float get() = FarTerrain.tileBlocks(level).toFloat()

    /** World-space X/Z of the tile's lower corner. */
    val x0: Float get() = FarTerrain.tileX(key) * size
    val z0: Float get() = FarTerrain.tileZ(key) * size
}

/**
 * Distant terrain: cheap blocky "voxel-style" columns (with little trees) that fill the space
 * between the full-detail voxel chunks and the horizon, so the view distance can be many
 * times larger than what voxel chunks could ever afford (memory- or draw-call-wise).
 *
 * Nothing here touches the voxel world. Heights come straight from the terrain
 * generator's pure height function, so a tile can exist for terrain that no chunk has
 * generated yet -- which is also why the horizon is there instantly at start-up and why
 * it fills any gap while real chunks are still streaming in.
 *
 * Levels of detail. LOD 0 is the voxel world itself (real chunks, see GameRenderer). Beyond
 * it there are [LEVELS] levels of column terrain, finest first; every level has columns twice
 * as wide as the one before and its own distance band around the player:
 *
 *  - level 0 = LOD 1 (high):   2-block columns, a thin ring right behind the voxel area
 *  - level 1 = LOD 2 (medium): 4-block columns
 *  - level 2 = LOD 3 (low):    8-block columns
 *  - levels 3, 4, 5 = VERY FAR: 16-, 32- and 64-block columns (the original far terrain; the
 *    16-block level only bridges what used to be an 8 -> 32 jump)
 *
 * Levels meet WITHOUT cracks, overlaps, or popping. The old scheme drew two levels on top of
 * each other near a seam and sank the coarser one by a distance-dependent amount, which made
 * the ground heave as the player walked and left a height step at the end of every ring.
 * Now the columns of a level slide smoothly to the height of the *parent* column of the next
 * coarser level (the 2 x 2 columns of a fine level share one parent: all steps are powers
 * of two on a common grid) over the outer part of their ring (see [morphWidth]; the vertex
 * shader does the blend from a per-vertex target height). At the ring's edge a fine mesh is
 * exactly the coarse mesh, so the two can meet on a plain distance cut with nothing to hide,
 * and a point of ground changes level only through a continuous change of shape.
 *
 * Tiles of one level sample exactly the same heights along their shared edges, so there are
 * no cracks inside a level either. Colour comes from a palette in the texture atlas chosen
 * from the surface type (see [SurfaceKind]), height and forest density (smooth coherent
 * noise, so fields have natural patches rather than stripes), so a tile needs no per-block
 * textures. Where the ground is below sea level the tile also gets a water mesh whose
 * vertices carry the water depth, drawn by the animated-water shader.
 *
 * Everything is built on background threads, nearest tile first: one coordinator that plans,
 * unloads and publishes in order, plus (on devices with enough cores) a couple of builders
 * that construct tiles side by side. [coveredRadiusBlocks] reports how far from the player
 * the tiles are contiguously complete, which the renderer uses to keep the fog in front of
 * any still-missing ground.
 */
class FarTerrain(private val generator: TerrainGenerator) {

    @Volatile private var running = false
    @Volatile private var enabled = true
    @Volatile private var playerX = 0f
    @Volatile private var playerZ = 0f
    @Volatile private var radiusBlocks = 0f
    @Volatile private var resetRequested = false

    /** Tiles to add / remove, in order, for the GL thread to apply. */
    val events = LinkedBlockingQueue<FarEvent>()

    /** Distance from the player out to which every wanted tile has been built. */
    @Volatile var coveredRadiusBlocks: Float = 0f
        private set

    private var thread: Thread? = null

    /** How many tiles are built at the same time. One builder (the coordinator thread itself)
     *  on small CPUs; two or three on bigger ones, leaving cores for the chunk workers and the
     *  render thread. */
    private val builderCount: Int = (Runtime.getRuntime().availableProcessors() / 3).coerceIn(1, 3)
    private var builderPool: ExecutorService? = null

    fun start() {
        if (running) return
        running = true
        if (builderCount > 1) {
            builderPool = Executors.newFixedThreadPool(builderCount) { task ->
                Thread({
                    lowerPriority()
                    task.run()
                }, "voxel-far-build").apply { isDaemon = true }
            }
        }
        thread = Thread({ workerLoop() }, "voxel-far").apply {
            isDaemon = true
            start()
        }
    }

    fun shutdown() {
        running = false
        thread?.interrupt()
        thread = null
        builderPool?.shutdownNow()
        builderPool = null
    }

    private fun lowerPriority() {
        try {
            android.os.Process.setThreadPriority(
                android.os.Process.THREAD_PRIORITY_BACKGROUND + android.os.Process.THREAD_PRIORITY_MORE_FAVORABLE
            )
        } catch (t: Throwable) {
            // best effort only
        }
    }

    /** Cheap; safe to call every frame. [radius] is the render distance in blocks. */
    fun updatePlayer(x: Float, z: Float, radius: Float, enable: Boolean) {
        playerX = x
        playerZ = z
        radiusBlocks = radius
        enabled = enable
    }

    /** The renderer lost its GL objects (context recreated): everything must be rebuilt
     *  and re-sent, since the CPU copies are not kept after upload. */
    fun invalidateAll() {
        resetRequested = true
    }

    // ---- worker ---------------------------------------------------------------------------

    /** [optional] tiles (the thin finest ring) never hold back the fog: the coarser levels
     *  already cover that ground, the finest ring only improves it. */
    private class Candidate(val level: Int, val tx: Int, val tz: Int, val key: Long, val nearDist: Float) {
        val optional: Boolean get() = level == 0
    }

    /** A tile that is being built on a builder thread; kept in plan order. */
    private class Pending(val cand: Candidate, val job: Future<FarTile>)

    private fun workerLoop() {
        lowerPriority()

        val built = HashSet<Long>()
        while (running) {
            try {
                if (resetRequested) {
                    resetRequested = false
                    built.clear()
                    events.clear()
                    coveredRadiusBlocks = 0f
                }

                val radius = radiusBlocks
                if (!enabled || radius < 32f) {
                    if (built.isNotEmpty()) {
                        for (k in built) events.put(FarEvent(k, null))
                        built.clear()
                    }
                    coveredRadiusBlocks = 0f
                    Thread.sleep(250)
                    continue
                }

                val px = playerX
                val pz = playerZ
                val wanted = planTiles(px, pz, radius)
                unloadStale(built, px, pz, radius)

                var replan = false
                val pool = builderPool
                // Tiles being built right now, oldest first. Their results are published in
                // exactly the order the tiles were planned, so the event stream (and the
                // coverage radius) behaves as if one thread had built them one after another.
                val pending = ArrayDeque<Pending>()
                try {
                    for (cand in wanted) {
                        if (!running) return
                        if (built.contains(cand.key)) continue

                        // Wanted tiles are sorted nearest-first and every nearer one is already
                        // built (or, with several builders, is the oldest still in flight), so
                        // contiguous coverage ends exactly where the oldest unfinished tile begins.
                        if (!cand.optional) {
                            coveredRadiusBlocks = if (pending.isEmpty()) cand.nearDist else firstRequiredNear(pending, cand.nearDist)
                        }

                        // Backpressure: the GL thread uploads only a couple per frame.
                        while (running && events.size >= MAX_QUEUED_EVENTS) Thread.sleep(4)

                        if (pool == null) {
                            val tile = timedBuild(cand)
                            events.put(FarEvent(tile.key, tile))
                            built.add(cand.key)
                        } else {
                            pending.addLast(
                                Pending(cand, pool.submit(Callable<FarTile> { timedBuild(cand) }))
                            )
                            if (pending.size < builderCount) continue // keep every builder busy first
                            publish(pending.removeFirst(), built)
                        }

                        if (resetRequested || !enabled || radiusBlocks != radius ||
                            abs(playerX - px) > REPLAN_DISTANCE || abs(playerZ - pz) > REPLAN_DISTANCE
                        ) {
                            replan = true
                            break
                        }
                    }

                    // Whatever is still in flight is finished and published too (unless everything
                    // is being thrown away anyway).
                    while (pending.isNotEmpty()) {
                        val p = pending.removeFirst()
                        if (resetRequested) {
                            p.job.cancel(true)
                        } else {
                            if (!p.cand.optional) coveredRadiusBlocks = p.cand.nearDist
                            publish(p, built)
                        }
                    }
                } finally {
                    for (p in pending) p.job.cancel(true)
                }
                if (!replan) {
                    coveredRadiusBlocks = radius
                    Thread.sleep(120)
                }
            } catch (e: InterruptedException) {
                return
            } catch (t: Throwable) {
                // A bad tile must never kill the whole horizon; back off briefly and retry.
                DiagLog.error("far", "tile build failed: " + t)
                try {
                    Thread.sleep(250)
                } catch (e: InterruptedException) {
                    return
                }
            }
        }
    }

    private fun firstRequiredNear(pending: ArrayDeque<Pending>, fallback: Float): Float {
        for (p in pending) {
            if (!p.cand.optional) return p.cand.nearDist
        }
        return fallback
    }

    /** Builds one tile and reports how long it took (and how big it came out) to the
     *  diagnostic log, which is a no-op while logging is off. */
    private fun timedBuild(cand: Candidate): FarTile {
        val t0 = System.nanoTime()
        val tile = buildTile(cand.level, cand.tx, cand.tz)
        if (DiagLog.isActive()) {
            val ms = (System.nanoTime() - t0) / 1_000_000f
            DiagLog.farTile(cand.level, ms, tile.land.indices.size / 3, tile.water.indices.size / 3)
        }
        return tile
    }

    /** Waits for [p]'s tile and hands it to the GL thread. A tile that failed to build is
     *  reported as the original exception (the coordinator backs off and retries). */
    private fun publish(p: Pending, built: HashSet<Long>) {
        val tile = try {
            p.job.get()
        } catch (e: ExecutionException) {
            throw e.cause ?: e
        }
        events.put(FarEvent(tile.key, tile))
        built.add(p.cand.key)
    }

    /** Every tile that must exist for the current position and render distance, across all
     *  levels, nearest first (the optional finest ring last, so it never delays the horizon). */
    private fun planTiles(px: Float, pz: Float, radius: Float): ArrayList<Candidate> {
        val out = ArrayList<Candidate>()
        for (level in 0 until LEVELS) {
            val inner = planInner(level)
            if (inner > radius) continue
            val outer = min(planOuter(level), radius)
            if (outer <= inner + 1f) continue
            val size = tileBlocks(level)
            val minTx = Math.floorDiv(floor(px - outer).toInt(), size)
            val maxTx = Math.floorDiv(floor(px + outer).toInt(), size)
            val minTz = Math.floorDiv(floor(pz - outer).toInt(), size)
            val maxTz = Math.floorDiv(floor(pz + outer).toInt(), size)
            for (tz in minTz..maxTz) {
                for (tx in minTx..maxTx) {
                    val near = nearestDistance(tx, tz, size, px, pz)
                    if (near > outer) continue
                    if (inner > 0f && farthestDistance(tx, tz, size, px, pz) < inner) continue
                    out.add(Candidate(level, tx, tz, tileKey(level, tx, tz), near))
                }
            }
        }
        out.sortWith(compareBy<Candidate>({ it.optional }, { it.nearDist }))
        return out
    }

    /** Drops tiles that are well outside their band. The margin (one tile) is the
     *  hysteresis that stops a tile on the edge of a band being rebuilt back and forth. */
    private fun unloadStale(built: HashSet<Long>, px: Float, pz: Float, radius: Float) {
        var stale: ArrayList<Long>? = null
        for (key in built) {
            val level = levelOf(key)
            val size = tileBlocks(level)
            val tx = tileX(key)
            val tz = tileZ(key)
            val near = nearestDistance(tx, tz, size, px, pz)
            val outer = min(planOuter(level), radius)
            val inner = planInner(level)
            val tooFar = near > outer + size
            val tooNear = inner > 0f && farthestDistance(tx, tz, size, px, pz) < inner - size
            if (tooFar || tooNear) {
                if (stale == null) stale = ArrayList()
                stale.add(key)
            }
        }
        if (stale != null) {
            for (key in stale) {
                built.remove(key)
                events.put(FarEvent(key, null))
            }
        }
    }

    private fun nearestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val cx = if (px < x0) x0 else if (px > x0 + size) x0 + size else px
        val cz = if (pz < z0) z0 else if (pz > z0 + size) z0 + size else pz
        val dx = px - cx
        val dz = pz - cz
        return sqrt(dx * dx + dz * dz)
    }

    private fun farthestDistance(tx: Int, tz: Int, size: Int, px: Float, pz: Float): Float {
        val x0 = (tx * size).toFloat()
        val z0 = (tz * size).toFloat()
        val dx = max(abs(px - x0), abs(px - (x0 + size)))
        val dz = max(abs(pz - z0), abs(pz - (z0 + size)))
        return sqrt(dx * dx + dz * dz)
    }

    // ---- tile construction ----------------------------------------------------------------

    private fun buildTile(level: Int, tx: Int, tz: Int): FarTile {
        val size = tileBlocks(level)
        val x0 = tx * size
        val z0 = tz * size

        // The ground of every cell of the tile plus a one-cell ring around it, so the walls
        // along the tile's edges know their neighbours.
        val field = buildField(level, tx * cellsOf(level), tz * cellsOf(level), cellsOf(level))

        // Ground that is far below the surface is hidden by (near-opaque) water, so a tile
        // that is entirely deep ocean needs only its water mesh.
        val hasLand = field.highest + LAND_Y_OFFSET > landFloor(level)
        val hasWater = field.lowest + LAND_Y_OFFSET < WATER_Y

        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val land = if (hasLand) buildLandMesh(level, tx, tz, x0, z0, field) else MeshData.EMPTY
        if (!land.isEmpty()) {
            minY = land.minY
            maxY = land.maxY
        }
        val water = if (hasWater) buildWaterMesh(level, x0, z0, field.heights) else MeshData.EMPTY
        if (!water.isEmpty()) {
            minY = min(minY, WATER_Y)
            maxY = max(maxY, WATER_Y)
        }
        if (minY > maxY) {
            minY = WATER_Y
            maxY = WATER_Y
        }
        return FarTile(tileKey(level, tx, tz), land, water, minY, maxY)
    }

    /** The ground of a window of [cells] x [cells] columns of [level] whose first column is the
     *  global column ([gx0], [gz0]) -- height, top, colour, visibility -- plus a one-column ring
     *  around the window. Array index (i, j) is window cell (i - 1, j - 1). A function of the
     *  global column indices only, so a tile and the finer tiles that blend into it agree on it
     *  exactly. */
    private class CellField(val n: Int) {
        val heights = IntArray(n * n)
        val topY = FloatArray(n * n)
        val col = IntArray(n * n)
        val skip = BooleanArray(n * n)
        var lowest = Int.MAX_VALUE
        var highest = Int.MIN_VALUE
    }

    private fun buildField(level: Int, gx0: Int, gz0: Int, cells: Int): CellField {
        val step = step(level)
        val lod = LEVEL_LOD[level]
        val shape = generator.shape
        val climate = generator.climate
        val n = cells + 2
        val f = CellField(n)
        val heights = f.heights
        val topY = f.topY
        val col = f.col
        val skip = f.skip
        // Heights are sampled one column beyond the ring too, so that every column of the window
        // (the ring included) gets its slope from its true neighbours, not from a clamped edge: the
        // ring's colour, biome and canopy are then exactly what the neighbouring tile computes for
        // the same column, and the walls along a tile's edge agree on both sides.
        val m = cells + 4
        val big = IntArray(m * m)
        // The smooth base elevation of each cell, a by-product of its height (see
        // TerrainShape.heightAndCoast), for the biome rules.
        val coast = DoubleArray(m * m)
        for (j in 0 until m) {
            val wz = (gz0 + j - 1.5) * step
            for (i in 0 until m) {
                val wx = (gx0 + i - 1.5) * step
                big[j * m + i] = floor(shape.heightAndCoast(wx, wz, lod, coast, j * m + i)).toInt()
            }
        }
        for (j in 0 until n) {
            for (i in 0 until n) {
                val h = big[(j + 1) * m + (i + 1)]
                heights[j * n + i] = h
                if (i in 1..cells && j in 1..cells) {
                    if (h < f.lowest) f.lowest = h
                    if (h > f.highest) f.highest = h
                }
            }
        }

        val sea = WorldConfig.SEA_LEVEL
        val span = 2f * step
        val slopeGain = SLOPE_GAIN[level]
        val floorY = landFloor(level)
        for (j in 0 until n) {
            val wz = (gz0 + j - 0.5) * step
            for (i in 0 until n) {
                val c = j * n + i
                val bc = (j + 1) * m + (i + 1) // the same column in the larger window
                val h = heights[c]
                val wx = (gx0 + i - 0.5) * step
                val groundTop = h + LAND_Y_OFFSET // voxel top face is at h + 1; sit just under it
                topY[c] = groundTop
                if (groundTop <= floorY) {
                    skip[c] = true // hidden under water that is (nearly) opaque from here
                    continue
                }
                if (h < sea) {
                    val cold = climate.baseTemperature(wx, wz) < Climate.COLD
                    val deep = sea - h > 8
                    val bed = if (deep || cold) TextureAtlas.RAMP_GRAVEL + 1f else TextureAtlas.RAMP_SAND + 2f
                    col[c] = colorKey(TextureAtlas.RAMP_ROW_SURFACE, bed)
                    continue
                }

                val dhdx = (big[bc + 1] - big[bc - 1]) / span
                val dhdz = (big[bc + m] - big[bc - m]) / span
                val slope = max(abs(dhdx), abs(dhdz)) * slopeGain
                val hd = h.toDouble()
                val biome = climate.biome(wx, wz, hd, slope.toDouble(), coast[bc])
                val kind = climate.surfaceFor(biome, wx, wz, hd, slope.toDouble())
                val fx = wx.toFloat()
                val fz = wz.toFloat()
                val forest = climate.forest(wx, wz).toFloat()
                // Large soft patches (coherent noise, never a regular wave), so a field of one
                // surface type is not one flat colour and has no stripes or repeats.
                val patch = patchNoise(fx, fz, step)
                val t = when (kind) {
                    SurfaceKind.BEACH -> TextureAtlas.RAMP_SAND + (if (h <= sea) 2f else if (h == sea + 1) 1f else 0f)
                    SurfaceKind.GRASS -> TextureAtlas.RAMP_GRASS + 0.3f + patch * 2.0f + forest * 1.9f
                    SurfaceKind.DRY_GRASS -> TextureAtlas.RAMP_DRY + patch * 1.8f + forest * 0.6f
                    SurfaceKind.DESERT -> TextureAtlas.RAMP_DESERT + patch * 2.0f
                    SurfaceKind.SNOW -> TextureAtlas.RAMP_SNOW + patch * 1.8f
                    SurfaceKind.ROCK -> TextureAtlas.RAMP_STONE + patch * 2.0f
                    SurfaceKind.GRAVEL -> TextureAtlas.RAMP_GRAVEL + patch * 2.0f
                    SurfaceKind.SWAMP -> TextureAtlas.RAMP_SWAMP + patch * 2.0f
                }
                col[c] = colorKey(TextureAtlas.RAMP_ROW_SURFACE, t)

                // Coarse levels: forested cells are raised into a canopy layer.
                if (level >= CANOPY_FROM_LEVEL && h >= sea + 2 && generator.treeDensity(biome) > 0.0) {
                    val cover = min(0.92, generator.treeChance(biome, forest.toDouble()) * 2.4)
                    val gx = gx0 + (i - 1)
                    val gz = gz0 + (j - 1)
                    if (cellRandom(gx, gz, level).toDouble() < cover) {
                        val rr = cellRandom(gx, gz, level + 7)
                        val leafBase = when (biome) {
                            Biome.TAIGA, Biome.SNOWY_TAIGA, Biome.SNOWY_PLAINS, Biome.MOUNTAINS -> TextureAtlas.RAMP_SPRUCE_LEAF
                            Biome.BIRCH_FOREST -> TextureAtlas.RAMP_BIRCH_LEAF
                            else -> TextureAtlas.RAMP_OAK_LEAF
                        }
                        val raise = (if (leafBase == TextureAtlas.RAMP_SPRUCE_LEAF) 7f else 4.5f) + 3f * rr
                        topY[c] = groundTop + raise
                        col[c] = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + (if (rr < 0.5f) 0f else 1f))
                    }
                }
            }
        }
        return f
    }

    /** For every cell of a tile (with its ring): the height its column slides to as it nears
     *  the outer edge of its level's ring -- the top of the parent column of the next coarser
     *  level, computed by exactly the code that builds that level, so the two meshes coincide
     *  there. The coarsest level has nothing to slide to. */
    private fun morphTargets(level: Int, tx: Int, tz: Int, cells: Int, n: Int, field: CellField, floorY: Float): FloatArray {
        val out = FloatArray(n * n)
        if (level >= LEVELS - 1) {
            System.arraycopy(field.topY, 0, out, 0, n * n)
            return out
        }
        // Columns are twice as wide one level up and the grids are aligned, so the window of
        // parent columns that covers this tile (and its ring) has half the columns per edge.
        val half = cells / 2
        val parent = buildField(level + 1, tx * half, tz * half, half)
        val np = half + 2
        for (j in 0 until n) {
            val pj = ((j - 1) shr 1) + 1
            for (i in 0 until n) {
                val pi = ((i - 1) shr 1) + 1
                out[j * n + i] = max(parent.topY[pj * np + pi], floorY)
            }
        }
        return out
    }

    /**
     * The land of one tile as blocky, voxel-style columns: every cell is a flat-topped column
     * at its (whole-block) ground height with vertical walls wherever a neighbour is lower,
     * all in flat colours from the atlas palette. Equal neighbours along a row are merged into
     * one long quad, so flat country costs very little. The two finest levels also stand real
     * little trees (a trunk box and a canopy box, at exactly the places the chunk generator
     * will grow them) on the ground; coarser levels raise the cells of forests into a dark
     * canopy layer. Every vertex also carries the height it slides to (see [morphTargets]).
     */
    private fun buildLandMesh(level: Int, tx: Int, tz: Int, x0: Int, z0: Int, field: CellField): MeshData {
        val step = step(level)
        val cells = cellsOf(level)
        val n = cells + 2
        val topY = field.topY
        val col = field.col
        val skip = field.skip
        val sea = WorldConfig.SEA_LEVEL
        val floorY = landFloor(level)
        val morphY = morphTargets(level, tx, tz, cells, n, field, floorY)

        val b = LodBuilder(cells * cells / 2)
        val sizeF = step.toFloat()

        // Tops, merged into runs along X.
        for (j in 0 until cells) {
            val za = (z0 + j * step).toFloat()
            val zb = za + sizeF
            var i = 0
            while (i < cells) {
                val c = (j + 1) * n + (i + 1)
                if (skip[c]) {
                    i++
                    continue
                }
                var run = 1
                while (i + run < cells) {
                    val c2 = c + run
                    if (skip[c2] || topY[c2] != topY[c] || col[c2] != col[c] || morphY[c2] != morphY[c]) break
                    run++
                }
                val xa = (x0 + i * step).toFloat()
                emitTop(b, xa, xa + run * sizeF, za, zb, topY[c], keyU(col[c]), keyV(col[c]), SHADE_TOP, morphY[c])
                i += run
            }
        }

        // Walls on the edges between row j and row j + 1 (j = -1 is the tile's own edge), merged along X.
        for (j in -1 until cells) {
            val z = (z0 + (j + 1) * step).toFloat()
            val aInside = j >= 0
            val bInside = j + 1 < cells
            var i = 0
            while (i < cells) {
                val a = (j + 1) * n + (i + 1)
                val dir = edgeDir(topY, morphY, a, a + n, aInside, bInside)
                if (dir == 0) {
                    i++
                    continue
                }
                val hi = if (dir > 0) a else a + n
                val lo = if (dir > 0) a + n else a
                if (skip[hi]) {
                    i++
                    continue
                }
                var run = 1
                while (i + run < cells) {
                    val a2 = a + run
                    if (edgeDir(topY, morphY, a2, a2 + n, aInside, bInside) != dir) break
                    val hi2 = if (dir > 0) a2 else a2 + n
                    val lo2 = if (dir > 0) a2 + n else a2
                    if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || col[hi2] != col[hi] ||
                        morphY[hi2] != morphY[hi] || morphY[lo2] != morphY[lo]
                    ) break
                    run++
                }
                val yt = topY[hi]
                val yb = max(topY[lo], floorY)
                // (equal heights with different slide targets: a wall that is flat now and opens later)
                if (yt > yb || morphY[hi] > morphY[lo]) {
                    val xa = (x0 + i * step).toFloat()
                    val xb = xa + run * sizeF
                    val shade = wallShade(yb, yt, SHADE_Z)
                    if (dir > 0) {
                        emitWallPosZ(b, z, xa, xb, yb, yt, keyU(col[hi]), keyV(col[hi]), shade, morphY[lo], morphY[hi])
                    } else {
                        emitWallNegZ(b, z, xa, xb, yb, yt, keyU(col[hi]), keyV(col[hi]), shade, morphY[lo], morphY[hi])
                    }
                }
                i += run
            }
        }

        // Walls on the edges between column i and column i + 1, merged along Z.
        for (i in -1 until cells) {
            val x = (x0 + (i + 1) * step).toFloat()
            val aInside = i >= 0
            val bInside = i + 1 < cells
            var j = 0
            while (j < cells) {
                val a = (j + 1) * n + (i + 1)
                val dir = edgeDir(topY, morphY, a, a + 1, aInside, bInside)
                if (dir == 0) {
                    j++
                    continue
                }
                val hi = if (dir > 0) a else a + 1
                val lo = if (dir > 0) a + 1 else a
                if (skip[hi]) {
                    j++
                    continue
                }
                var run = 1
                while (j + run < cells) {
                    val a2 = a + run * n
                    if (edgeDir(topY, morphY, a2, a2 + 1, aInside, bInside) != dir) break
                    val hi2 = if (dir > 0) a2 else a2 + 1
                    val lo2 = if (dir > 0) a2 + 1 else a2
                    if (skip[hi2] || topY[hi2] != topY[hi] || topY[lo2] != topY[lo] || col[hi2] != col[hi] ||
                        morphY[hi2] != morphY[hi] || morphY[lo2] != morphY[lo]
                    ) break
                    run++
                }
                val yt = topY[hi]
                val yb = max(topY[lo], floorY)
                // (equal heights with different slide targets: a wall that is flat now and opens later)
                if (yt > yb || morphY[hi] > morphY[lo]) {
                    val za = (z0 + j * step).toFloat()
                    val zb = za + run * sizeF
                    val shade = wallShade(yb, yt, SHADE_X)
                    if (dir > 0) {
                        emitWallPosX(b, x, za, zb, yb, yt, keyU(col[hi]), keyV(col[hi]), shade, morphY[lo], morphY[hi])
                    } else {
                        emitWallNegX(b, x, za, zb, yb, yt, keyU(col[hi]), keyV(col[hi]), shade, morphY[lo], morphY[hi])
                    }
                }
                j += run
            }
        }

        // The finest levels: real trees, where the chunk generator will grow them. (The
        // generator's tree lattice is 4 x 4 blocks whatever the column width here.)
        if (level < TREE_LEVELS) {
            val size = tileBlocks(level)
            val lattice = size / 4
            val lx0 = x0 / 4
            val lz0 = z0 / 4
            for (lj in 0 until lattice) {
                for (li in 0 until lattice) {
                    val spot = generator.treeSpot(lx0 + li, lz0 + lj) ?: continue
                    val ci = Math.floorDiv(spot.x - x0, step) + 1
                    val cj = Math.floorDiv(spot.z - z0, step) + 1
                    if (ci < 1 || ci > cells || cj < 1 || cj > cells) continue
                    val c = cj * n + ci
                    if (skip[c] || field.heights[c] < sea + 1) continue
                    // A tree slides into the ground (just under the parent column's top) as its
                    // ring ends, so it never pops.
                    emitTree(b, spot, topY[c], morphY[c] - 0.6f)
                }
            }
        }
        return b.build()
    }

    /** Which side of the edge between cells [a] and [b] gets a wall: 1 = a's (a is the higher
     *  cell and inside this tile), -1 = b's, 0 = none (nothing to cover, or the higher cell
     *  belongs to the neighbouring tile, which emits that wall itself).
     *
     *  Two columns need a wall between them if their heights differ, *or if the heights they
     *  slide to differ* ([morphY]): equal neighbours whose parents are at different heights come
     *  apart as the ring ends, and without a (still zero-height) wall there the gap between them
     *  would be a crack. The higher cell is the one with the higher height, ties broken by the
     *  higher slide target. */
    private fun edgeDir(topY: FloatArray, morphY: FloatArray, a: Int, b: Int, aInside: Boolean, bInside: Boolean): Int {
        val aHigher: Boolean
        if (topY[a] != topY[b]) {
            aHigher = topY[a] > topY[b]
        } else if (morphY[a] != morphY[b]) {
            aHigher = morphY[a] > morphY[b]
        } else {
            return 0
        }
        return if (aHigher) (if (aInside) 1 else 0) else (if (bInside) -1 else 0)
    }

    /** Shade of a wall. Walls that stand in the water (the seabed steps seen through a
     *  translucent surface, the foot of a coast) get the shade of a top, so they never draw
     *  dark contour lines through or along the water; low shore steps get a halfway shade. */
    private fun wallShade(yb: Float, yt: Float, base: Float): Float {
        if (yt <= WATER_Y) return SHADE_TOP
        if (yb < WATER_Y && yt < WATER_Y + 2.5f) return 0.5f * (base + SHADE_TOP)
        return base
    }

    private fun colorKey(row: Int, column: Float): Int {
        val q = (column * 4f + 0.5f).toInt()
        return row * 256 + (if (q < 0) 0 else if (q > 124) 124 else q)
    }

    private fun keyU(key: Int): Float = TextureAtlas.rampU((key and 255) / 4f)

    private fun keyV(key: Int): Float = TextureAtlas.rampV(key shr 8, (key and 255) / 4f)

    // Flat-coloured quads, each wound counter-clockwise as seen from outside. [m] / [mb] / [mt]
    // are the heights the vertices slide to (see morphTargets); walls list their two bottom
    // vertices first, then their two top vertices.

    private fun emitTop(b: LodBuilder, xa: Float, xb: Float, za: Float, zb: Float, y: Float, u: Float, v: Float, shade: Float, m: Float) {
        b.quad(xa, y, za, xa, y, zb, xb, y, zb, xb, y, za, u, v, shade, m, m, m, m)
    }

    private fun emitWallPosX(b: LodBuilder, x: Float, za: Float, zb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(x, yb, zb, x, yb, za, x, yt, za, x, yt, zb, u, v, shade, mb, mb, mt, mt)
    }

    private fun emitWallNegX(b: LodBuilder, x: Float, za: Float, zb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(x, yb, za, x, yb, zb, x, yt, zb, x, yt, za, u, v, shade, mb, mb, mt, mt)
    }

    private fun emitWallPosZ(b: LodBuilder, z: Float, xa: Float, xb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(xa, yb, z, xb, yb, z, xb, yt, z, xa, yt, z, u, v, shade, mb, mb, mt, mt)
    }

    private fun emitWallNegZ(b: LodBuilder, z: Float, xa: Float, xb: Float, yb: Float, yt: Float, u: Float, v: Float, shade: Float, mb: Float, mt: Float) {
        b.quad(xb, yb, z, xa, yb, z, xa, yt, z, xb, yt, z, u, v, shade, mb, mb, mt, mt)
    }

    /** An open-bottomed box: a top and four walls, all sliding to the height [m]. */
    private fun emitBox(
        b: LodBuilder, xa: Float, xb: Float, za: Float, zb: Float, yb: Float, yt: Float, topKey: Int, sideKey: Int, m: Float
    ) {
        if (yt <= yb) return
        emitTop(b, xa, xb, za, zb, yt, keyU(topKey), keyV(topKey), SHADE_TOP, m)
        val su = keyU(sideKey)
        val sv = keyV(sideKey)
        emitWallPosX(b, xb, za, zb, yb, yt, su, sv, SHADE_X, m, m)
        emitWallNegX(b, xa, za, zb, yb, yt, su, sv, SHADE_X, m, m)
        emitWallPosZ(b, zb, xa, xb, yb, yt, su, sv, SHADE_Z, m, m)
        emitWallNegZ(b, za, xa, xb, yb, yt, su, sv, SHADE_Z, m, m)
    }

    /**
     * One distant tree as boxes: a trunk and a canopy (two stacked canopy boxes for a spruce),
     * sized to match what [com.voxelsandbox.game.world.generation.TreeBuilder] grows.
     * [cellTop] is the LOD ground the tree stands on; the trunk reaches down to it so a tree
     * never floats above the flat cell top on a slope. [m] is the height the whole tree
     * flattens to at the end of its ring.
     */
    private fun emitTree(b: LodBuilder, spot: TerrainGenerator.TreeSpot, cellTop: Float, m: Float) {
        val th = spot.th
        val species = spot.species
        val base = spot.ground + 1f
        val x = spot.x.toFloat()
        val z = spot.z.toFloat()
        val variant = ((th ushr 3) and 1).toFloat()
        val bush = species != TreeSpecies.SPRUCE && ((th ushr 20) and 15) == 0
        val leafBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_LEAF
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_LEAF
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_LEAF
        }
        val woodBase = when (species) {
            TreeSpecies.BIRCH -> TextureAtlas.RAMP_BIRCH_WOOD
            TreeSpecies.SPRUCE -> TextureAtlas.RAMP_SPRUCE_WOOD
            TreeSpecies.OAK -> TextureAtlas.RAMP_OAK_WOOD
        }
        val topKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + variant)
        val sideKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, leafBase + 1f + variant)
        val woodKey = colorKey(TextureAtlas.RAMP_ROW_FOLIAGE, woodBase)
        val bigOak = species == TreeSpecies.OAK && ((th ushr 24) and 7) == 0
        val trunk = when {
            bush -> 1
            species == TreeSpecies.BIRCH -> 6 + ((th ushr 4) % 4)
            species == TreeSpecies.SPRUCE -> 7 + ((th ushr 4) % 7)
            bigOak -> 7 + ((th ushr 4) % 3)
            else -> 5 + ((th ushr 4) % 4)
        }

        if (!bush) {
            emitBox(b, x, x + 1f, z, z + 1f, min(base - 0.25f, cellTop), base + trunk, woodKey, woodKey, m)
        }
        val cx = x + 0.5f
        val cz = z + 0.5f
        val tf = trunk.toFloat()
        when {
            bush -> emitBox(b, cx - 1.5f, cx + 1.5f, cz - 1.5f, cz + 1.5f, base, base + 3f, topKey, sideKey, m)
            species == TreeSpecies.SPRUCE -> {
                emitBox(b, cx - 3.25f, cx + 3.25f, cz - 3.25f, cz + 3.25f, base + 2f, base + tf - 4f, topKey, sideKey, m)
                emitBox(b, cx - 1.7f, cx + 1.7f, cz - 1.7f, cz + 1.7f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            }
            species == TreeSpecies.BIRCH ->
                emitBox(b, cx - 2f, cx + 2f, cz - 2f, cz + 2f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            bigOak ->
                emitBox(b, cx - 3.5f, cx + 3.5f, cz - 3.5f, cz + 3.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
            else ->
                emitBox(b, cx - 2.5f, cx + 2.5f, cz - 2.5f, cz + 2.5f, base + tf - 4f, base + tf + 1f, topKey, sideKey, m)
        }
    }

    /** The sea / lake / river surface of a tile: a flat grid at [WATER_Y] whose vertices
     *  carry the depth of the ground below (averaged over the four cells that meet there),
     *  and only the cells that touch water.
     *
     *  Open sea is the bulk of it, and over deep water every vertex has the same attributes
     *  (the water shader's depth tint has long saturated), so those cells would all draw
     *  identically. Instead of two triangles per cell, any aligned block of 4x4 up to 64x64
     *  cells whose every vertex is deep becomes a fan of triangles from one extra vertex at its
     *  centre to the vertices around its edge: the edge keeps every grid vertex, so the block
     *  still meets its neighbours (merged or not) exactly, with no cracks, while a whole deep
     *  tile costs 256 triangles instead of 8192. */
    private fun buildWaterMesh(level: Int, x0: Int, z0: Int, heights: IntArray): MeshData {
        val step = step(level)
        val cells = cellsOf(level)
        val verts = cells + 1
        val n = cells + 2
        val stride = MeshData.FLOATS_PER_VERTEX
        val gridVerts = verts * verts
        val vertexData = FloatArray((gridVerts + (cells / MIN_FAN_BLOCK) * (cells / MIN_FAN_BLOCK)) * stride)
        val depths = FloatArray(gridVerts)
        var vi = 0
        for (j in 0 until verts) {
            for (i in 0 until verts) {
                // The four cells meeting at vertex (i, j) are array cells (i, j) .. (i + 1, j + 1).
                val c = j * n + i
                val depth = (cellDepth(heights[c]) + cellDepth(heights[c + 1]) +
                    cellDepth(heights[c + n]) + cellDepth(heights[c + n + 1])) * 0.25f
                depths[j * verts + i] = depth
                vertexData[vi++] = (x0 + i * step).toFloat()
                vertexData[vi++] = WATER_Y
                vertexData[vi++] = (z0 + j * step).toFloat()
                vertexData[vi++] = depth // the water shader reads depth from the first data slot
                vertexData[vi++] = 0f // flow X: distant water is always still
                vertexData[vi++] = 0f // flow Z
            }
        }

        // Prefix sums of the deep vertices: "is this whole block deep" in O(1).
        val w = verts + 1
        val deepSum = IntArray(w * w)
        for (j in 0 until verts) {
            var row = 0
            for (i in 0 until verts) {
                if (depths[j * verts + i] >= DEEP_WATER) row++
                deepSum[(j + 1) * w + (i + 1)] = deepSum[j * w + (i + 1)] + row
            }
        }

        val indices = IntArray(cells * cells * 6)
        var ii = 0
        var fans = 0

        fun emit(i0: Int, j0: Int, size: Int) {
            if (size >= MIN_FAN_BLOCK) {
                val s1 = size + 1
                val deepCount = deepSum[(j0 + s1) * w + (i0 + s1)] - deepSum[j0 * w + (i0 + s1)] -
                    deepSum[(j0 + s1) * w + i0] + deepSum[j0 * w + i0]
                if (deepCount == s1 * s1) {
                    val center = gridVerts + fans
                    fans++
                    val o = center * stride
                    vertexData[o] = (x0 + (i0 + size / 2) * step).toFloat()
                    vertexData[o + 1] = WATER_Y
                    vertexData[o + 2] = (z0 + (j0 + size / 2) * step).toFloat()
                    vertexData[o + 3] = DEEP_WATER
                    vertexData[o + 4] = 0f
                    vertexData[o + 5] = 0f
                    // Walk the block's edge: along the top (+i), the right (+j), the bottom (-i)
                    // and the left (-j); each edge step with the centre is one upward-facing triangle.
                    val count = 4 * size
                    for (k in 0 until count) {
                        val p = edgeVertex(i0, j0, size, k, verts)
                        val q = edgeVertex(i0, j0, size, if (k + 1 == count) 0 else k + 1, verts)
                        indices[ii++] = center
                        indices[ii++] = q
                        indices[ii++] = p
                    }
                    return
                }
            }
            if (size == 1) {
                val a = j0 * verts + i0
                val b = a + 1
                val d = a + verts
                val c = d + 1
                if (depths[a] <= 0f && depths[b] <= 0f && depths[c] <= 0f && depths[d] <= 0f) return
                indices[ii++] = a; indices[ii++] = c; indices[ii++] = b
                indices[ii++] = a; indices[ii++] = d; indices[ii++] = c
                return
            }
            val half = size / 2
            emit(i0, j0, half)
            emit(i0 + half, j0, half)
            emit(i0, j0 + half, half)
            emit(i0 + half, j0 + half, half)
        }
        emit(0, 0, cells)

        if (ii == 0) return MeshData.EMPTY
        val total = gridVerts + fans
        return MeshData(vertexData.copyOf(total * stride), indices.copyOf(ii), total, WATER_Y, WATER_Y)
    }

    /** Grid vertex number [k] (0 until 4 * size) when walking round the edge of the block of
     *  [size] cells at (i0, j0): top edge left to right, right edge top to bottom, bottom
     *  edge right to left, left edge bottom to top. */
    private fun edgeVertex(i0: Int, j0: Int, size: Int, k: Int, verts: Int): Int {
        val side = k / size
        val t = k - side * size
        return when (side) {
            0 -> j0 * verts + (i0 + t)
            1 -> (j0 + t) * verts + (i0 + size)
            2 -> (j0 + size) * verts + (i0 + size - t)
            else -> (j0 + size - t) * verts + i0
        }
    }

    private fun cellDepth(h: Int): Float = (WATER_Y - (h + LAND_Y_OFFSET)).coerceIn(0f, DEEP_WATER)

    companion object {
        /** Number of levels of column terrain (0 = finest). */
        const val LEVELS = 6

        /** Most columns along a tile edge. */
        const val MAX_CELLS = 64

        /** Floats per vertex of the land meshes: position (3), palette uv (2), shade (1) and
         *  the height the vertex slides to (1). */
        const val LAND_FLOATS = 7

        /** Columns along a tile edge, per level. Fine levels have small tiles (a thin ring
         *  does not waste triangles on ground it never draws); the coarse ones have few columns
         *  because beyond a kilometre a column is a handful of pixels, and what a weak GPU
         *  chokes on is the *number of triangles* of the distant terrain. */
        private val LEVEL_CELLS = intArrayOf(32, 64, 64, 32, 32, 32)

        /** Column size per level, in blocks: every step is a power of two, so the columns of
         *  one level are exactly 2 x 2 of the level below it (the basis of the height blend). */
        private val LEVEL_STEP = intArrayOf(2, 4, 8, 16, 32, 64)

        /** The terrain generator's detail setting per level (see TerrainShape.height): the
         *  finest levels keep the voxel world's full shape, the coarse ones drop the features
         *  that sparse sampling would only alias. */
        private val LEVEL_LOD = intArrayOf(0, 0, 1, 2, 2, 3)

        fun cellsOf(level: Int): Int = LEVEL_CELLS[level]
        fun step(level: Int): Int = LEVEL_STEP[level]

        /** Tile edge in blocks: 64, 256, 512, 512, 1024, 2048. */
        fun tileBlocks(level: Int): Int = LEVEL_CELLS[level] * LEVEL_STEP[level]

        /** Short names for the on-screen statistics and the diagnostic log. */
        fun levelName(level: Int): String = when (level) {
            0 -> "LOD1"
            1 -> "LOD2"
            2 -> "LOD3"
            3 -> "far16"
            4 -> "far32"
            else -> "far64"
        }

        /** Real trees stand on the ground of the levels below this; the coarser ones raise
         *  forested columns into a canopy layer instead. */
        private const val TREE_LEVELS = 2
        private const val CANOPY_FROM_LEVEL = 2

        /** Outer edge of each level's distance band, in blocks from the player. The first
         *  entry is a placeholder: the finest ring is placed just behind the voxel area (see
         *  [configureFineRing]). The last level has no outer edge (it reaches the render
         *  distance). */
        private val BAND_OUTER = floatArrayOf(0f, 512f, 896f, 1408f, 2304f, 1.0e9f)

        /** How far in from its outer edge each level starts sliding to the next coarser
         *  level's heights. */
        private val MORPH_WIDTH = floatArrayOf(32f, 96f, 128f, 192f, 288f, 0f)

        /** Width of the finest ring. A step-2 column is four times the triangles per block
         *  of the next level, so the ring is kept thin: its job is the first stretch behind
         *  the voxel terrain, where the dissolve needs a good backdrop. */
        private const val FINE_RING_WIDTH = 56f
        private const val FINE_MIN_START = 96f

        /** Tiles are planned this much beyond a band's edge, so walking on between replans
         *  never uncovers the ring. */
        private const val PLAN_MARGIN = 24f

        /** Distant water of a level keeps drawing this far past its band's outer edge, so
         *  the flat translucent rings overlap by a sliver instead of leaving a hairline gap. */
        const val WATER_OVERLAP = 1.5f

        @Volatile private var fineIn = 0f
        @Volatile private var fineOut = 0f

        /**
         * Places the thin finest ring (level 0) just behind the voxel area, or takes it away
         * ([allowed] = false, e.g. while the adaptive-distance governor is saving work).
         * [voxelFadeStart] is where the voxel terrain begins to dissolve. The ring only moves
         * when that changes by a good margin, so it does not make tiles come and go.
         */
        fun configureFineRing(voxelFadeStart: Float, allowed: Boolean) {
            if (!allowed || voxelFadeStart < FINE_MIN_START) {
                fineOut = 0f
                return
            }
            val raw = voxelFadeStart - 8f
            if (fineOut > 0f && abs(raw - fineIn) < 40f) return
            val a0 = max(0f, floor(raw / 32f) * 32f)
            val a1 = min(a0 + FINE_RING_WIDTH, BAND_OUTER[1] - 96f)
            if (a1 - a0 < 24f) {
                fineOut = 0f
                return
            }
            fineIn = a0
            fineOut = a1
        }

        fun fineInner(): Float = fineIn
        fun fineOuter(): Float = fineOut

        /** Inner edge of the area a level's tiles are built for. Level 1 is always built from
         *  the player outwards: it is the ground that shows (the ring of level 0 aside) and
         *  the stand-in for level 0 whenever the voxel area is not loaded yet. */
        fun planInner(level: Int): Float = when (level) {
            0 -> fineIn
            1 -> 0f
            else -> BAND_OUTER[level - 1]
        }

        /** Outer edge of the area a level's tiles are built for (its band plus a margin). */
        fun planOuter(level: Int): Float = when (level) {
            0 -> if (fineOut > 0f) fineOut + PLAN_MARGIN else 0f
            LEVELS - 1 -> BAND_OUTER[level]
            else -> BAND_OUTER[level] + PLAN_MARGIN
        }

        /** Where a level is drawn from: level 1 gives way to level 0's ring only while that
         *  ring is on screen ([fineDrawn]). */
        fun drawInner(level: Int, fineDrawn: Boolean): Float = when (level) {
            0 -> fineIn
            1 -> if (fineDrawn && fineOut > 0f) fineOut else 0f
            else -> BAND_OUTER[level - 1]
        }

        /** Exact outer edge of a level's distance band (the next level starts there). */
        fun drawOuter(level: Int): Float = if (level == 0) fineOut else BAND_OUTER[level]

        /** Distance from the player at which a level starts sliding to its parent's heights. */
        fun morphStart(level: Int): Float = drawOuter(level) - MORPH_WIDTH[level]

        /** Far-terrain slopes are measured over a coarser baseline than the voxel terrain's,
         *  which smooths them; these gains restore the rock / scree coverage the voxel
         *  generator would give, so a mountainside keeps its colour with distance. */
        private val SLOPE_GAIN = floatArrayOf(1.0f, 1.2f, 1.5f, 1.9f, 2.4f, 3.4f)

        /** Voxel water surfaces sit at SEA_LEVEL + 0.875 (see ChunkMesher). */
        const val WATER_Y = WorldConfig.SEA_LEVEL + 0.875f

        /** Land vertices sit this far above the top block's floor: just under the voxel top
         *  face (which is at +1), so real voxel terrain always wins where both exist. */
        private const val LAND_Y_OFFSET = 0.75f

        /** Water at least this deep is drawn (near-)opaque, so ground beneath it is skipped. */
        private const val DEEP_WATER = 10f

        /** Ground below this height is not built for a level at all. Water is at least ~90 %
         *  opaque in a slanted view through 3.5 blocks of it, and drawn solid beyond 300 blocks
         *  (see the water shader), so only the finest ring needs the sea floor in full; coarser
         *  levels keep just the shore. This is also what keeps seabed steps from ever outlining
         *  themselves through the surface. */
        private fun landFloor(level: Int): Float = when (level) {
            0 -> WATER_Y - DEEP_WATER
            1 -> WATER_Y - 3.5f
            else -> WATER_Y - 0.9f
        }

        /** Smallest block of deep water cells merged into one fan (a tile holds at most one fan
         *  per aligned block of that size). */
        private const val MIN_FAN_BLOCK = 4

        private const val MAX_QUEUED_EVENTS = 12

        // Shading of the flat-coloured columns: tops like a voxel top face, walls like voxel sides.
        private const val SHADE_TOP = 0.97f
        private const val SHADE_Z = 0.80f
        private const val SHADE_X = 0.68f
        private const val REPLAN_DISTANCE = 24f

        // Tile key = level (3 bits) | tx (29 bits, signed) | tz (29 bits, signed).
        private const val COORD_MASK = 0x1FFFFFFFL

        fun tileKey(level: Int, tx: Int, tz: Int): Long =
            (level.toLong() shl 58) or ((tx.toLong() and COORD_MASK) shl 29) or (tz.toLong() and COORD_MASK)

        fun levelOf(key: Long): Int = (key ushr 58).toInt()
        fun tileX(key: Long): Int = (((key ushr 29) and COORD_MASK).toInt() shl 3) shr 3
        fun tileZ(key: Long): Int = ((key and COORD_MASK).toInt() shl 3) shr 3

        /** Deterministic 0..1 value for a cell of the LOD grid. */
        private fun cellRandom(gx: Int, gz: Int, salt: Int): Float {
            var h = gx * 73856093 xor gz * 19349663 xor salt * 83492791
            h = h xor (h ushr 15)
            h *= 739982445
            h = h xor (h ushr 13)
            return ((h ushr 8) and 0xFFFF) / 65536f
        }

        /** Smooth value noise (0..1) on an integer lattice, deterministic in the lattice
         *  coordinates and [salt]. */
        private fun valueNoise(x: Float, z: Float, salt: Int): Float {
            val xf = floor(x)
            val zf = floor(z)
            val fx = x - xf
            val fz = z - zf
            val ix = xf.toInt()
            val iz = zf.toInt()
            val sx = fx * fx * (3f - 2f * fx)
            val sz = fz * fz * (3f - 2f * fz)
            val a = cellRandom(ix, iz, salt)
            val b = cellRandom(ix + 1, iz, salt)
            val c = cellRandom(ix, iz + 1, salt)
            val d = cellRandom(ix + 1, iz + 1, salt)
            return a + (b - a) * sx + (c - a) * sz + (a - b - c + d) * sx * sz
        }

        /**
         * The soft patchiness of a surface (0..1) at a world position: domain-warped fractal
         * value noise, so it forms irregular clusters at several scales instead of repeating
         * waves, and is a pure function of the position (the same at every level and from every
         * tile, never re-rolled). The finest octave is dropped on coarse levels, where a column
         * is wider than its wavelength and the octave would only turn into random speckle.
         */
        private fun patchNoise(wx: Float, wz: Float, step: Int): Float {
            val qx = wx + 55f * (valueNoise(wx * 0.011f, wz * 0.011f, 11) - 0.5f)
            val qz = wz + 55f * (valueNoise(wx * 0.011f + 17.3f, wz * 0.011f - 9.1f, 12) - 0.5f)
            val fine = if (step <= 4) 0.20f else if (step <= 8) 0.10f else 0f
            val v = (0.50f * valueNoise(qx * 0.0065f, qz * 0.0065f, 21) +
                0.30f * valueNoise(qx * 0.019f, qz * 0.019f, 22) +
                fine * valueNoise(qx * 0.057f, qz * 0.057f, 23)) / (0.80f + fine)
            // Sums of noise bunch up around the middle; stretch them so patches are distinct.
            return ((v - 0.5f) * 1.8f + 0.5f).coerceIn(0f, 1f)
        }
    }
}

/** Collects flat-coloured quads (all four vertices share one palette colour and shade) for a
 *  distant-terrain land tile. Vertex layout: position (3), uv (2), shade (1) and the height
 *  the vertex slides to as its level's ring ends (1), see [FarTerrain.LAND_FLOATS]. */
private class LodBuilder(initialQuads: Int) {
    private var floats = FloatArray(initialQuads * 4 * FarTerrain.LAND_FLOATS)
    private var indices = IntArray(initialQuads * 6)
    private var verts = 0
    private var idx = 0
    private var minY = Float.MAX_VALUE
    private var maxY = -Float.MAX_VALUE

    /** One quad; (0,1,2) and (0,2,3) must be counter-clockwise seen from the front. */
    fun quad(
        x0: Float, y0: Float, z0: Float,
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        u: Float, v: Float, shade: Float,
        m0: Float, m1: Float, m2: Float, m3: Float
    ) {
        val stride = FarTerrain.LAND_FLOATS
        if ((verts + 4) * stride > floats.size) floats = floats.copyOf(max(floats.size * 2, (verts + 4) * stride))
        if (idx + 6 > indices.size) indices = indices.copyOf(max(indices.size * 2, idx + 6))
        val f = floats
        var i = verts * stride
        f[i++] = x0; f[i++] = y0; f[i++] = z0; f[i++] = u; f[i++] = v; f[i++] = shade; f[i++] = m0
        f[i++] = x1; f[i++] = y1; f[i++] = z1; f[i++] = u; f[i++] = v; f[i++] = shade; f[i++] = m1
        f[i++] = x2; f[i++] = y2; f[i++] = z2; f[i++] = u; f[i++] = v; f[i++] = shade; f[i++] = m2
        f[i++] = x3; f[i++] = y3; f[i++] = z3; f[i++] = u; f[i++] = v; f[i++] = shade; f[i] = m3
        val ix = indices
        ix[idx++] = verts; ix[idx++] = verts + 1; ix[idx++] = verts + 2
        ix[idx++] = verts; ix[idx++] = verts + 2; ix[idx++] = verts + 3
        verts += 4
        if (y0 < minY) minY = y0
        if (y1 < minY) minY = y1
        if (y2 < minY) minY = y2
        if (y3 < minY) minY = y3
        if (y0 > maxY) maxY = y0
        if (y1 > maxY) maxY = y1
        if (y2 > maxY) maxY = y2
        if (y3 > maxY) maxY = y3
        // The slide targets count towards the tile's vertical extent too (a tile is culled
        // by that box), whichever way they go.
        if (m0 < minY) minY = m0
        if (m1 < minY) minY = m1
        if (m2 < minY) minY = m2
        if (m3 < minY) minY = m3
        if (m0 > maxY) maxY = m0
        if (m1 > maxY) maxY = m1
        if (m2 > maxY) maxY = m2
        if (m3 > maxY) maxY = m3
    }

    fun build(): MeshData {
        if (verts == 0) return MeshData.EMPTY
        return MeshData(
            floats.copyOf(verts * FarTerrain.LAND_FLOATS),
            indices.copyOf(idx),
            verts,
            minY,
            maxY
        )
    }
}
