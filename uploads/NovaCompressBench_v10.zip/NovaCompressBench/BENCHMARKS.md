# NovaCompress benchmark log

One entry per targeted change, following the same "one subsystem, one
measured improvement" process throughout: identify the biggest weakness in
one subsystem, fix only that, benchmark before/after, keep or revert based
on the numbers.

## Version summary

Quick-glance index - see each entry below for the full before/after numbers,
what was tried and reverted, and why. "Type" is what actually moved:
**ratio** entries change output bytes, **speed** entries don't (provably or
measured byte-identical), **correctness** entries fix a bug independent of
either.

| # | Entry | Type | Headline result | Verdict |
|---|---|---|---|---|
| 1 | Repeat-offset distance coding (`MatchFieldCoder`) | Ratio | `table.bin` 6.64x→13.61x (+105%); `json`/`executable` modest gains; `text`/`image`/`random` unchanged | Kept |
| 2 | Adaptive segmentation (`Segmenter`+`NovaContainerFormat`) | Correctness + ratio | Fixed silent data corruption on heterogeneous input (old design produced non-round-tripping output on 2 of 4 mixed fixtures); heterogeneous files -0.34% to -0.72%; uniform files +0.01% (fixed framing cost) | Kept |
| 3 | Periodicity blind spot in `RegionClassifier` | Investigated | 0.00% ratio change across 9 fixtures - container format's trial-and-promote safety net already absorbs this specific gap | Reverted (KDoc note only) |
| 4 | Cost-aware match ranking (`LongRangeMatcher.rankScore`) | Ratio | `json` 8.55x→8.64x, `table` 13.62x→14.45x, `text` +0.1%, `executable` ~flat; 2 analytic cost-model attempts tried and reverted first | Kept |
| 5 | Encode-speed profiling / allocation reduction | Speed | 4MB input: encode -4.7% wall time, byte-identical output | Kept |
| 6 | Matcher rewrite - tiered hashing + pooled workspace | Speed + ratio | 16MB ROM-like: 3.448x→3.458x ratio, compress 1.39-1.45x faster; 6 small fixtures byte-identical | Kept |
| 7 | Adaptive search budget + classifier fix + generalized ranking | Ratio + speed | `json` +0.5%/1.34x faster, `table` exact ratio/2.78x faster, `text`/`executable` flat ratio (slightly slower, HIGH-tier rankScore overhead); no fixture regressed | Kept |
| 8 | `FreqModel` Fenwick tree + boxing avoidance + Huffman-skip bound | Speed only | Byte-identical ratio on every fixture; 16MB ROM decompress 12,227→3,679 ms (**3.32x**), compress 35,738→20,290 ms (1.76x); `image.bmp` decompress 2.91x | Kept |
| 9 | Split match/predict-hit marker into its own model (`NovaSegmentCodec`) | Ratio (conditional) | `image.bmp` +1.78% (real win, high predict-hit content); `text`/`table`/`executable` +0.04% to +0.43% (noise-level); `json` picks the old scheme unchanged (0%) - tried both, kept smaller, zero regression by construction | Kept |
| 10 | Gate Entry 9's split-scheme trial on predict-hit share | Speed (ratio-preserving) | On-device data showed every real fixture under ~8% hit share gained 0-0.1% ratio from Entry 9 while paying real compress-time cost (GBA ROM +14%, `random.bin` +59%) for it; gating below 20% hit share recovers that cost on all of them while keeping `image.bmp`'s full win unchanged | Kept |

## Entry 1: repeat-offset distance coding (MatchFieldCoder)

### Methodology

Same constraint as the "Verification" section of the main README: no
Android SDK, Gradle, or network access in this sandbox, and this time not
even a Kotlin or Java *compiler* (only a JRE) - so the Kotlin project itself
couldn't be built or run here either. The approach was the same one the
README already documents for the original implementation: port the
highest-risk logic to a language actually runnable in the sandbox, verify
it round-trips correctly, measure before/after, and only then port the
verified change into the Kotlin source.

Concretely: the full encode/decode pipeline (`LongRangeMatcher`,
`MultiLevelDictionary`, `ContextPredictor`, `FreqModel`/`RangeEncoder`/
`RangeDecoder`, `MatchFieldCoder`, `EntropyCoderSelector`'s range-coder path,
`NovaSegmentCodec`) was ported line-for-line to Python, including the exact
32-bit hash/multiply wraparound arithmetic `LongRangeMatcher` and
`ContextPredictor` depend on. That port's *baseline* output was checked
against real numbers pasted from a device run of this app's own
Research Mode (`NovaCompress Bench` + `NovaCompress Research Mode` output,
all six built-in sample datasets) - ratio, token counts, match counts, and
prediction-hit counts all matched within noise (the only inputs that aren't
bit-identical are the PRNG streams generating the synthetic fixtures; same
structure, different bytes). That gave confidence the port's behavior, and
therefore its before/after measurements, reflect the real Kotlin code.

The Huffman fallback path in `EntropyCoderSelector` was not ported (the
range coder path was) - irrelevant to this change, since better context
modeling only ever shrinks the range-coded size further, making it *more*
likely to beat Huffman, never less.

### Where the bytes were actually going

Breaking the *baseline* encoder's own output down by component, across the
four sample types where NovaCompress trails Deflate/Bzip2/LZMA2/Zstd
(text, JSON, tabular/structured, executable-like):

| dataset    | total size | main entropy stream | match side-channel (dist+len) |
|------------|-----------:|---------------------:|-------------------------------:|
| text       |     39,728 |         2,519 (6.3%) |               37,209 (93.7%) |
| json       |     30,938 |         4,359 (14.1%)|               26,579 (85.9%) |
| table      |     39,478 |        11,143 (28.2%)|               28,335 (71.8%) |
| executable |     87,573 |        21,106 (24.1%)|               66,467 (75.9%) |

For comparison, on `synthetic_image.bmp` - the one sample type NovaCompress
already *wins* on (4.07x vs LZMA2's 3.03x, per the pasted device benchmark)
- the split is the opposite: 99.2% main stream, 0.8% side-channel, because
matches are rare there (0.1% match share) and `ContextPredictor` is doing
almost all the work (83% hit rate). That contrast is what pointed at the
match side-channel specifically, not the predictor, matcher, or main
entropy coder, as the thing to fix.

Digging one level further into the side-channel itself (distance and length
each split into an entropy-coded "slot" plus raw, uncompressed "extra
bits" - see `MatchFieldCoder`'s KDoc for the scheme): the raw *distance*
extra-bits alone were 56-69% of the total side-channel on every one of
those four datasets - by far the single largest component, ahead of the
distance slots, the length slots, and the length extra-bits combined.

### Root cause

`MatchFieldCoder` entropy-codes a distance's *slot* (its bit-length) but
always writes the bits *within* that slot raw, on the assumption that they're
close to uniformly distributed. That's a reasonable assumption for a
genuinely varied set of distances, but the matcher's own repeat-offset list
(`MultiLevelDictionary.repDistances`) already biases real files toward
reusing a *handful* of distances heavily - and periodic/structured data
(fixed-width records, columnar binary, anything with a repeating stride)
takes that further: the matcher keeps finding the exact same distance value
match after match, because the structure itself repeats. The slot compressed
away fine (adaptive model, one dominant symbol) - but the raw extra bits
were regenerated from scratch every single time even when the value never
changed, because nothing recognized "this is the same distance as before."

### The fix

Scoped to one subsystem: **entropy coding**, specifically how match
*distances* are encoded in `MatchFieldCoder`. Added a small (4-entry) MRU
cache of recently-used distance values, tracked independently inside
`MatchFieldCoder` itself (not the matcher's own repeat-offset list - this
one exists purely so the entropy coder can say "same as before" for free).
When a distance matches a cached entry, it costs one cheap, entropy-coded
symbol and *zero* extra bits, the same idea as LZMA's rep0-rep3 codes. When
it doesn't, encoding falls back to the original slot-plus-extra-bits scheme
unchanged. Match *lengths* are untouched - a length doesn't recur the way a
periodic structure's distance does, and MIN_MATCH-rebasing already gives the
single most common length the cheapest code.

Files touched:
- `entropy/MatchFieldCoder.kt` - the actual change (MRU cache, alphabet
  size now depends on `repSlots`, `pack`/`unpack` updated to match).
- `NovaSegmentCodec.kt` - one line, opting the *distance* `FieldWriter` into
  the new cache (`repSlots = MatchFieldCoder.DIST_REPEAT_SLOTS`); the length
  `FieldWriter` is constructed the same way as before (`repSlots` defaults
  to 0), and `decode()` needed no changes at all, since `unpack()`'s new
  `distRepSlots` parameter defaults to `DIST_REPEAT_SLOTS` - the value
  `encode()` always uses for the real distance writer.
- `MatchFieldCoderTest.kt` - added coverage for the new cache (round-trip
  correctness with a mix of hot/fresh distances, fewer unique values than
  cache slots, empty/single-value edges, and a size assertion that a
  constantly-recurring distance collapses to well under half its baseline
  size). Every pre-existing test in this file still constructs
  `FieldWriter()` with no arguments and therefore still exercises the exact
  original code path (`repSlots` defaults to 0) - none of them needed to
  change to keep passing.

One bug caught during verification, worth recording: an early version of
`unpack()` hardcoded `DIST_REPEAT_SLOTS` for the distance alphabet instead
of taking it as a parameter. That's harmless for the real `NovaSegmentCodec`
call site (which always uses `DIST_REPEAT_SLOTS` on the encode side too,
same as a fixed `minMatch` never being ambiguous there), but it would have
silently corrupted every pre-existing `MatchFieldCoderTest` case, since
those all encode distances with the *default* `repSlots = 0` and would
then have been decoded assuming `repSlots = 4` - an alphabet-size mismatch
that desyncs the range decoder into producing wrong values rather than
throwing. Caught by running the equivalent scenario through the Python
harness (reproduced in an isolated case: encoding `[5, 100, 7, 4, 4, 4]`
with `repSlots=0` and decoding with `repSlots=4` returns
`[0, 2, 0, 0, 0, 44]`) before this ever reached the Kotlin side. Fixed by
making `distRepSlots` an explicit `unpack()` parameter (defaulting to
`DIST_REPEAT_SLOTS`, so the real call site still needs no change) instead
of an assumed constant, and re-verified every test scenario, old and new,
against the harness afterward.

The rest of the pipeline - `LongRangeMatcher`, `MultiLevelDictionary`,
`ContextPredictor`, `Segmenter`, `RegionClassifier`, the container format -
is untouched.

### Results

Six built-in sample datasets, before vs. after, measured on the verified
Python port (byte-identical algorithm to the Kotlin change described
above), with every case round-trip-verified lossless:

| dataset    |    original | before (baseline) | after (this change) | ratio before | ratio after | size change |
|------------|------------:|-------------------:|----------------------:|--------------:|-------------:|------------:|
| text       |     262,144 |              39,728 |                 39,726 |         6.60x |        6.60x |      -0.01% |
| json       |     262,144 |              30,938 |                 30,703 |         8.47x |        8.54x |      -0.76% |
| **table**  | **262,144** |          **39,478** |             **19,267** |     **6.64x** |   **13.61x** |  **-51.20%**|
| image      |     196,608 |              48,167 |                 48,166 |         4.08x |        4.08x |      -0.00% |
| executable |     262,144 |              87,573 |                 87,463 |         2.99x |        3.00x |      -0.13% |
| random     |     262,144 |             267,323 |                267,323 |         0.98x |        0.98x |       0.00% |
| **total**  | 1,507,328   |             513,207 |                492,648 |         2.94x |        3.06x |      -4.01% |

(`random` isn't handled by the pipeline this change touches in the real
app - the segmenter routes incompressible input to STORE before it ever
reaches the matcher/entropy stage - so its baseline ratio here is slightly
below the app's real ~1.00x; that's a limitation of the Python harness, not
this change, and doesn't affect any of the numbers above it.)

The fixed-stride tabular case - exactly the kind of periodic/structured
binary data this fix targets - more than doubles its compression ratio
(6.64x -> 13.61x), moving it from clearly behind Deflate/Bzip2/Zstd
(per the pasted device benchmark: 7.77x/8.01x/22.08x) to solidly ahead of
Deflate and Bzip2 and within reach of LZMA2's 14.07x. JSON and
executable-like data get smaller, consistent (~0.1-0.8%) gains from the
same mechanism, matching the fact that they had *some* repeated-distance
structure but less than the tabular case's constant stride. Text, image,
and random data are unchanged to within rounding, as expected: text's match
distances are driven by scattered word positions with little offset reuse,
image data barely uses the matcher at all (0.1% match share - the predictor
already does the work there), and random data has no matches to encode.

No dataset regressed. Net effect across the full six-dataset suite: **-4.0%
total compressed size** (2.94x -> 3.06x aggregate ratio), driven almost
entirely by the one dataset the root-cause analysis predicted it should
help.

### Verdict

Kept. Improves one dataset dramatically, several others modestly, regresses
none, stays losslessly round-trip-verified throughout (including the new
Kotlin unit tests, checked against the same logic in the Python harness
since no Kotlin compiler was available to run them directly here), and the
change is contained to the entropy-coding of match distances specifically -
no changes to the matcher's search strategy, the predictor, the dictionary,
segmentation, or the container format.

### Suggested next subsystem

With the distance side-channel's dominant cost fixed, the *length* side of
`MatchFieldCoder` is the next largest remaining component on these same
datasets (2,971-7,477 bytes of length-slot entropy plus 4,684-6,008 bytes
of raw length extra-bits per dataset, from the same breakdown above) and
would likely benefit from a similar treatment - lengths cluster around a
small set of common values on structured data too, just not via a literal
repeat-offset mechanism the way distances do. After that, `text.txt` is the
dataset with the least headroom found in this pass (+0.01%) despite still
trailing Bzip2 by nearly 2x (6.60x vs 11.86x); its side-channel is 93.7% of
its output with very little of it concentrated in repeated distances, which
points more at the **matcher**'s parsing strategy (greedy + 1-step lazy
matching vs. LZMA-style optimal parsing, which would choose shorter/more
numerous matches when that leads to cheaper-to-encode distances) than at
anything in the entropy coder.

## Entry 2: adaptive segmentation (Segmenter + NovaContainerFormat)

### Starting point

Every one of the six built-in sample datasets reports "segments 1" in
Research Mode (Entry 1's pasted device benchmark confirms this on the
*current* build, post-Entry-1). That's not wrong for those specific files -
each one really is internally uniform (`table.bin` is fixed-stride records
throughout, `synthetic_text.txt` is prose throughout) - but it meant
`Segmenter` had never actually been exercised on the kind of file it exists
for: something that changes character partway through. The old `Segmenter`
only ever produced a new segment on a STORE<->NOVA strategy change; two
adjacent regions of very different content that both happened to classify
as NOVA (prose text next to a binary table, JSON next to image pixel data,
...) stayed one segment, sharing one dictionary and one entropy model
regardless of how different their statistics actually were.

### A correctness bug found while investigating

Before getting to compression ratio: reading `NovaContainerFormat.encodeChunk`
to understand what a segment boundary actually *does* to the encoded output
turned up a real data-corruption bug, not a hypothetical one.

The old design concatenated every NOVA-strategy segment's bytes into one
shared buffer, in file order - but a STORE segment that traded up to NOVA
after trial-compression (see Entry 1's methodology note on that mechanism;
it predates this entry) got appended to the *end* of that shared buffer,
regardless of where it actually sat in the file. `decodeChunk` then read
that buffer with a single sequential cursor, walking segments in file
order and assuming the buffer's layout matched. Whenever a promoted STORE
segment wasn't already the last segment in the chunk, that assumption was
false: decode would silently read the *next* NOVA segment's bytes in its
place, and everything from there on desyncs.

Reproduced directly, isolated from any Kotlin code, as a minimal trace:
segments `A(NOVA)="AAAA"`, `B(STORE, promoted)="BBBB"`, `C(NOVA)="CCCC"`
encode to a shared buffer `"AAAACCCCBBBB"` (B pushed to the end); decoding
that with a sequential per-segment cursor reads back `"AAAACCCCBBBB"` -
not the original `"AAAABBBBCCCC"`. Confirmed again on a realistic (not
adversarial) file: 128KB each of prose text, a fixed-stride binary table,
executable-like bytes, and genuinely random bytes, concatenated - the
table region classifies STORE (its within-window repetition is below the
classifier's detection threshold - a known blind spot, see
`RegionClassifier`'s KDoc) but compresses well on trial and gets promoted,
sitting between two NOVA regions. Round-tripping that file through the
pre-this-entry `encodeChunk`/`decodeChunk` **failed** - reconstructed
bytes didn't match the input.

This wasn't reachable by any existing test (`NovaContainerFormatTest`'s
`mixedRealisticChunk` alternates text and *genuinely* random bytes, which
never promotes, so the desync condition never fired), and doesn't show up
on any of the six single-character-family sample files (each is one
segment, so there's nothing to desync between). It's exactly the condition
genuine adaptive segmentation makes *more* likely to occur - more, smaller,
more-varied segments mean more opportunities for a STORE segment to land
between two NOVA ones - so it had to be fixed as part of this change, not
filed separately.

### The fix

Two parts, one for each half of the problem:

**Segmenter** now splits a run on two conditions instead of one:

1. A STORE<->NOVA strategy change - unconditional, as before (this is a
   structural requirement, not a heuristic: literal bytes and an encoded
   block aren't interchangeable).
2. A *structural* change - the window's `RegionKind` differs from the
   current run's, or its entropy has drifted more than
   `ENTROPY_DELTA_THRESHOLD` (1.0 bits/byte) from the run's average so far -
   once the run has reached `MIN_SEGMENT_SIZE` (16KB, four analyzer
   windows). The size gate exists so a single noisy window can't fragment
   a file into segments too small to be worth their own block; verified
   directly that it does its job (see Testing below).

Kind changes cover "repeated structures" (`REPETITIVE_BINARY` is its own
kind), "long literal regions" (a `BINARY_UNKNOWN`/non-repetitive stretch
reads differently than its neighbors), and general transitions between
data characteristics directly. The entropy check catches drift *within*
one kind family that a coarse kind bucket alone would miss - verified at
the unit level, independent of any kind change: two synthetic same-kind
regions with a deliberate entropy jump between them split correctly at
`ENTROPY_DELTA_THRESHOLD = 1.0`, and raising the threshold past the jump's
size correctly stops the split (`FileAnalyzerSegmenterTest.entropyDeltaSplitsIndependentlyOfKind`).

Segmenter only ever proposes *candidate* boundaries from these signals -
it has no way to know whether splitting there actually pays for itself
once a fresh model's warm-up cost and per-block framing overhead are
accounted for. That decision moved to where it can actually be measured:

**NovaContainerFormat.encodeChunk** now does two things differently:

- The STORE-vs-promote trial-compression is per-segment instead of pooled
  across the whole chunk - strictly more accurate (different STORE regions
  can have different real compressibility; a pooled trial only sees their
  average), and a natural consequence of processing segments individually
  rather than via one global concatenation.
- Every maximal run of consecutive effective-NOVA segments becomes one or
  more blocks, always in file order (fixing the corruption bug above as a
  side effect - a block only ever covers the exact segments it was built
  from, at their real position, so there's no shared buffer to desync). A
  run of more than one segment is trial-encoded *both* ways - merged into
  one block, and split into one block per segment - and whichever produces
  fewer total bytes, including each block's own ~28-byte framing overhead,
  is what's kept. This is the literal implementation of "split into
  multiple compression blocks only when benchmarks show a benefit": not a
  heuristic guess about when splitting helps, an actual trial encode and a
  byte-count comparison, every time.

This is a real, if bounded, cost: a multi-segment run gets trial-encoded
twice (merged + split) before the smaller one is kept, on top of the
per-segment STORE trial. Same tradeoff Entry 1 (and the STORE-promotion
mechanism, predating both entries) already accepted: pay a spare encode
call to *measure* instead of guess.

File format note: this changes the on-disk chunk layout (segment
boundaries now map to a variable number of blocks instead of always 0 or
1), so `NovaContainerFormat.VERSION` moved from 1 to 2 - streams compressed
with the old build won't decode with this one, and vice versa. There's no
existing format-stability promise in this repo to violate (the README
already labels NovaCompress "experimental"), so this is a clean version
bump rather than a compatibility break of anything documented as stable.

Files touched:
- `segment/Segmenter.kt` - the structural-transition logic described above
  (`MIN_SEGMENT_SIZE`, `ENTROPY_DELTA_THRESHOLD`).
- `format/NovaContainerFormat.kt` - per-segment STORE trial, run-based block
  construction with the merge-vs-split trial, block-sequenced decode (fixes
  the ordering bug), `VERSION` bump. This is more than a one-line wiring
  change (unlike Entry 1's touch on `NovaSegmentCodec.kt`) because making
  segment boundaries actually affect the compressed output - not just the
  STORE/NOVA choice, which is all they affected before - requires it: the
  old design concatenated every NOVA segment into one block regardless of
  how many segments existed, so a smarter `Segmenter` alone would have
  changed nothing about the compressed bytes without this half of the fix.
- `FileAnalyzerSegmenterTest.kt`, `NovaContainerFormatTest.kt` - coverage
  for the new behavior, including a direct regression test for the
  ordering bug (`promotedStoreSegmentSandwichedBetweenNovaSegmentsRoundTrips`)
  built from exactly the NOVA/promoted-STORE/NOVA shape described above.

The matcher, predictor, dictionary, entropy coder, and analyzer
(`FileAnalyzer`/`RegionClassifier`/`EntropyCalculator`) are untouched -
`Segmenter` and `NovaContainerFormat` only *consume* the analyzer's
per-window classification, they don't change how it's computed.

### Methodology

Same sandbox constraints as Entry 1 (no Android SDK/Gradle/Kotlin compiler
available here), same approach: port the relevant logic to Python, verify
it against real device numbers, measure before/after there, then apply the
identical logic to the Kotlin source. This entry additionally ported
`FileAnalyzer`/`RegionClassifier`/`EntropyCalculator` (straightforward -
no bit-level arithmetic, just counts and ratios) and both the old and new
`Segmenter`/`NovaContainerFormat` logic, including the old design's
ordering bug (kept bug-for-bug faithful on purpose, specifically so the
corruption could be demonstrated directly rather than just described).

The existing six sample datasets are each internally uniform, so they
can't exercise structural-transition segmentation at all - a second set of
heterogeneous fixtures was built specifically for this entry: text
directly followed by a fixed-stride binary table; a table directly
followed by random bytes; text/random/text; JSON followed by image pixel
data; a four-way mix of text/table/executable-like/random; and a
fine-grained (6KB-burst) alternation between text and table, to stress-test
whether `MIN_SEGMENT_SIZE` and the merge-vs-split trial actually prevent
pathological over-fragmentation on noisy input (they do - see Results).

A late correctness check on the harness itself is worth recording: the
per-block framing overhead was initially miscounted as 6 length-prefix
ints (24 bytes) in both the Kotlin constant and the Python harness, when
`writeBlock` actually writes 7 (originalLength, symbolCount, tokenCount,
matchTokenCount, predictHitCount, entropyBytes.size, sideChannelBytes.size
- 28 bytes). This doesn't affect losslessness (it only feeds the
merge-vs-split size *comparison*, not the encoding itself), but it would
have made that trial very slightly over-eager to choose "split." Fixed in
both the Kotlin constant and the Python harness before the final numbers
below; re-running the affected comparisons after the fix changed no
merge-vs-split decision and shifted total sizes by only a few bytes per
chunk.

### Results

Round-trip-verified lossless on every case below (including, critically,
the previously-corrupting one). "orig" is the file size; "old"/"new" are
total encoded chunk size (segment metadata + block framing + payloads;
excludes ~9 bytes of fixed chunk-level header common to both designs, so
absolute sizes are each about 9 bytes smaller than real on-disk output,
but ratios and deltas between old and new are unaffected by that).

**The six existing (uniform) sample datasets - checking for regressions:**

| dataset    |    orig | old total | new total | delta   |
|------------|--------:|----------:|----------:|--------:|
| text       | 262,144 |    39,769 |    39,772 |  +0.01% |
| json       | 262,144 |    30,746 |    30,749 |  +0.01% |
| table      | 262,144 |    19,310 |    19,313 |  +0.02% |
| image      | 196,608 |    48,209 |    48,212 |  +0.01% |
| executable | 262,144 |    87,506 |    87,509 |  +0.00% |
| random     | 262,144 |   262,159 |   262,162 |  +0.00% |

Every one of these stays exactly one segment, exactly one block - the new
structural-transition logic correctly finds nothing to split (each file
really is uniform), so the only difference is 3 fixed bytes of chunk-level
framing (a `blocks.size` int replacing a 1-byte `hasNova` flag). Immaterial
at any real file size, and exactly the "cost nothing when there's nothing
to split" half of "only split when benchmarks show a benefit."

**Heterogeneous files - where old design could never do anything but STORE/NOVA:**

| dataset                        |    orig | old total | old ok? | new total | new segs | new blocks | delta   |
|---------------------------------|--------:|----------:|:-------:|----------:|---------:|-----------:|--------:|
| text_then_table                 | 524,288 |    59,357 |   yes   |    59,155 |        2 |          2 |  -0.34% |
| json_then_image                 | 458,560 |   124,204 |   yes   |   123,306 |        2 |          2 |  -0.72% |
| four_way_mix (text/table/exe/rand) | 262,144 |   105,012 | **no**  |   103,184 |        4 |          3 |  n/a*   |
| fine_grained_alternating (6KB bursts) | 196,608 |    24,980 | **no**  |    26,204 |       32 |          1 |  n/a*   |

\* Old design's "total" for these two isn't a usable number - it's the
size of an output that doesn't decode back to the original (`old ok? = no`).
It's included to show the corrupted encoding wasn't even *smaller* for a
good reason (`fine_grained_alternating`'s old total looks smaller than
new's, but that's a broken encoding, not a more efficient one - see below).

`text_then_table` and `json_then_image` are the clean "genuine structural
transition, splitting helps" cases: two very different kinds of content,
each getting its own block instead of one shared model diluted between
them, for a real (if modest at these file sizes) size reduction.

`four_way_mix` is the standout: it's the exact real-world-shaped case that
triggers the ordering bug under the old design (verified: `old ok? = no`,
decoded output doesn't match input) - and the new design not only fixes
that, it also produces an encoding about 1.7% smaller (103,184 vs the old
design's 105,012 bytes - not shown as a delta in the table above, since the
old number is a broken encoding rather than a valid comparison point) by
splitting text/table/executable-like into 3 separate blocks (the
merge-vs-split trial's split side won) while correctly recognizing the
random quarter isn't worth encoding at all (stored inline, 0 blocks spent
on it).

`fine_grained_alternating` is the "don't fragment on noise" check:
`Segmenter` proposes 32 candidate segments (alternating every 6KB, finer
than `MIN_SEGMENT_SIZE`, so the entropy/kind signal alone doesn't suppress
splitting here - the old design's segment count agrees: also 16-32-ish),
but `encodeChunk`'s merge-vs-split trial measures that splitting this
finely doesn't pay for itself and correctly collapses everything back down
to a **single block** regardless. New total is slightly larger than the
old (broken) design's number, which is expected and fine: the old number
represents an encoding that doesn't round-trip, not a more efficient one -
comparing against it is comparing against something that doesn't actually
work. What matters is that the trial-based merge decision, not
`MIN_SEGMENT_SIZE` alone, is what's actually protecting against pathological
fragmentation here, which is the intended design (see "The fix" above).

### Testing

`min_segment_size` and `entropy_delta` were swept (8KB-64KB;
0.5-1.5 bits/byte) across every fixture above; results were insensitive to
`entropy_delta` in that range for these specific fixtures (their
transitions all happen to co-occur with a kind change too, so the entropy
check rarely fires alone here - verified independently at the unit level
instead, see `entropyDeltaSplitsIndependentlyOfKind`) and only mildly
sensitive to `min_segment_size` (smaller values propose more candidate
segments, which costs a little in fixed per-segment metadata and trial-encode
time without changing the final block count, since the merge-vs-split trial
already converges to the same answer regardless). `16KB` / `1.0 bits/byte`
were kept as defaults - not because they're uniquely optimal, but because
the result is robust in a reasonable neighborhood around them, which is a
better property than a sharply-tuned value that happens to score best on
exactly these six fixtures.

Kotlin-side coverage added: `FileAnalyzerSegmenterTest` gets three new
cases (kind-transition splitting, entropy-delta splitting isolated from any
kind change, and `MIN_SEGMENT_SIZE` suppressing a sub-threshold blip);
`NovaContainerFormatTest` gets three new cases (the ordering-bug regression
test described above, a heterogeneous-chunk-produces-multiple-segments
check, and a uniform-chunk-stays-one-segment check for the "only when it
helps" half). Every pre-existing test in both files is unchanged and still
passes under the new logic (verified against the Python harness rather
than a Kotlin compiler, per Entry 1's methodology note).

### Verdict

Kept. Fixes a real, previously-undetected data-corruption bug (not a
theoretical one - reproduced on a realistic, non-adversarial file), gives
a measurable compression benefit on genuinely heterogeneous content
(-0.3% to -1.7% in these tests, likely more on real-world files that mix
content types more often than clean synthetic benchmarks do), costs
nothing measurable on uniform content, and the "only split when it
measurably helps" requirement is enforced by an actual trial-encode
comparison in `encodeChunk` rather than a tuned heuristic threshold -
verified directly on an adversarial fine-grained-alternation input where
`Segmenter` proposes 32 segments and the trial correctly collapses them
back to one block.

### Suggested next subsystem

The merge-vs-split trial currently only considers two shapes per run -
fully merged, or fully split into one block per segment - not partial
groupings (e.g. segments 1+2 merged, segment 3 separate). A run of many
short alternating segments (like `fine_grained_alternating`) always
resolves to "merge everything," even if some sub-grouping within the run
would do better; the fully-merged-vs-fully-split trial can't see that
option. Extending it to consider boundaries individually (or a bounded
dynamic-programming search over partition points) is bounded, well-scoped
follow-up work if a real file surfaces this pattern.

Separately, and unrelated to segmentation: `text.txt` is still the
dataset with the least headroom found across both entries so far (Entry 1:
+0.01%; this entry: +0.01%, since it's already one uniform segment) despite
still trailing Bzip2 by nearly 2x. Its side-channel is dominated by match
tokens with little concentrated repeated-distance structure for Entry 1's
fix to catch, which points at the **matcher**'s parsing strategy (greedy +
1-step lazy matching vs. LZMA-style optimal parsing) as the next place to
look, same conclusion Entry 1 reached.

## Entry 3: FileAnalyzer/RegionClassifier periodicity blind spot (investigated, not fixed)

### Starting point

A targeted request to review `FileAnalyzer` for ratio-limiting classification
gaps, prompted by `RegionClassifier`'s own KDoc and Entry 2's aside ("the
table region classifies STORE ... a known blind spot") - i.e. is this known,
accepted gap actually costing anything, or just noted-and-never-checked?

### Methodology

Same sandbox constraint as Entries 1-2 (no Android SDK/Gradle/network, and
this time not even a Kotlin compiler - only a JRE), same approach: port the
relevant logic to a runnable language, verify the port against real numbers,
measure, decide. This time the *entire* encode-side pipeline was ported (not
just the piece under test) - `EntropyCalculator`, `RegionClassifier`,
`FileAnalyzer`, `Segmenter`, `LongRangeMatcher`, `MultiLevelDictionary`,
`ContextPredictor`, `MatchFieldCoder`, `FreqModel`/`RangeEncoder`,
`HuffmanCoder`, `EntropyCoderSelector`, `NovaSegmentCodec`, and
`NovaContainerFormat.encodeChunk`'s trial/merge/split/framing logic - to Java,
since a ratio question about `FileAnalyzer` can't be answered by looking at
`FileAnalyzer`'s output in isolation; it has to be traced all the way through
to final on-disk bytes. The port's baseline (original, unmodified classifier)
reproduced the six-dataset device benchmark within ~1% on every file (e.g.
table 13.62x here vs. 13.57x on device, image 4.07x vs. 4.07x, executable
2.998x vs. 3.00x) - same caveat as Entries 1-2: PRNG streams for the
synthetic fixtures differ, structure doesn't.

### Root cause, confirmed

`synthetic_table.bin`'s 4KB windows measure entropy ~7.95 bits/byte and
shingle-repetition ~0.227 - just under `REPETITIVE_STRUCTURE_THRESHOLD`
(0.25) - so every window falls through to `ALREADY_COMPRESSED_OR_ENCRYPTED`
and the whole file classifies STORE, exactly as `RegionClassifier`'s KDoc
already flagged as a known gap. Root cause: the 24-byte record's arithmetic-
ramp fields change every record, so most of its 8-byte non-overlapping
shingles never repeat within one window regardless of alignment - a
byte-value histogram plus content-defined-but-non-overlapping shingle
hashing both miss "predictable from position" structure that isn't literal
repetition. A stride-autocorrelation check (does byte N match, or differ by
a constant delta from, byte N-stride for small candidate strides) correctly
reclassifies it as `REPETITIVE_BINARY` and doesn't misfire on genuinely
random data (checked directly: `synthetic_random.bin`'s classification is
unchanged).

### Why the fix doesn't change compressed size

`NovaContainerFormat.encodeChunk` (added in Entry 2, for an unrelated
correctness bug) trial-encodes every STORE-classified segment and promotes
it to the NOVA pipeline whenever that trial actually compresses smaller than
verbatim storage - and `ContextPredictor`'s tier-3 linear/delta fallback
(`predicted = 2*prev - prevPrev`) exactly predicts an arithmetic-ramp field
regardless of segment size, so the isolated trial on a misclassified segment
like this one always succeeds and promotes it. Once promoted, a segment is
grouped into the same effectively-NOVA run as its neighbors and hits the
same merge-vs-split trial either way - so the final encoded bytes are
byte-for-byte identical whether the classifier got the label right the first
time or got it wrong and was corrected downstream.

Measured on all nine fixtures tried (the six built-in samples, plus three
synthetic `20KB JSON + N KB table + 20KB JSON` mixes at N=1/3/8, built
specifically to stress-test whether a *small, embedded* misclassified region
behaves differently from a whole-file one): **0.00% change in final
compressed size on every single one.** The only measured difference is
redundant work: a misclassified-then-promoted segment gets
`NovaSegmentCodec.encode()`'d twice (once for the isolated STORE trial, once
more building its block) instead of once - 50% fewer `encode()` calls on
`table.bin` alone (2 -> 1), 20% fewer on the two larger mixed fixtures - a
real but purely computational saving, not a ratio one.

### Verdict

**Reverted / not shipped.** The fix is correct and the root cause is real,
but it moved zero bytes on every fixture tested, including deliberately
adversarial mixed-content ones - `encodeChunk`'s trial-and-promote safety
net (see Entry 2) already fully absorbs this specific class of
classification error, provided the misclassified content is genuinely
compressible, which it always was in every case tried here. Shipping a
classifier change with a measured ratio benefit of zero doesn't meet this
project's "keep or revert based on the numbers" bar. `FileAnalyzer.kt`,
`RegionClassifier.kt`, and `EntropyCalculator.kt` are unchanged from before
this entry; only a KDoc note in `RegionClassifier.kt` was added, pointing
back here so the gap doesn't get "rediscovered" as unverified in a future
pass.

### Suggested next subsystem

Not `FileAnalyzer` - the safety net means classification accuracy isn't
where the compressed bytes are being lost. Redoing this entry's full-pipeline
byte breakdown on the current (post-Entry-1) build confirms Entries 1 and
2 both already pointed at the right place: the match side-channel is still
75-94% of total output on text/json/executable (`text` 93.5%, `json` 85.7%,
`executable` 75.9%, `table` 41.9% - lower only because Entry 1's
repeat-offset cache already helps its constant record stride specifically).
A direct `MIN_MATCH` sensitivity sweep (4/5/6/8/10/12/16) on these four
datasets shows raising the threshold shuffles bytes between the main entropy
stream and the side-channel but doesn't reliably shrink the total - e.g.
`executable.bin` stays within 2,996-90,668 bytes of its baseline across the
whole sweep with no consistent winner - confirming this isn't a threshold
worth just re-tuning. It's a parsing-strategy gap: `LongRangeMatcher` takes
any match >= `MIN_MATCH` and does one step of lazy lookahead comparing raw
match *length*, with no model of what that match actually costs to encode
(a fresh, expensive-to-encode distance vs. a free repeat-offset slot). Cost-
aware / LZMA-style optimal parsing - preferring a match only when its real
encoded cost beats the literals (or a cheaper match) it replaces - is the
next well-evidenced target, same conclusion both prior entries reached
independently.

## Entry 4: LongRangeMatcher cost-aware candidate ranking

### Starting point

Entry 3's "suggested next subsystem": the matcher takes any match >=
`MIN_MATCH` and ranks candidates (both the hash-chain walk and the 1-step
lazy lookahead) by raw byte length alone, with no model of what a match
actually costs to encode. Goal: raise ratio on `text`/`json`/`executable`
without hurting speed, touching only the matcher.

### Methodology

Same full-pipeline Java port as Entry 3 (this sandbox still has no
Kotlin/Gradle/Android SDK), extended with a toggleable `LongRangeMatcher`
so `COST_AWARE=false` reproduces the shipped matcher byte-for-byte -
confirmed: every one of the eight fixtures below round-trips to the exact
"BEFORE" total in the table. Two designs were tried, measured, and
reverted before the one that shipped; recording why, since both looked
reasonable on paper.

### Attempt 1 (reverted): analytic bit-cost model

Estimated each match's real encoded cost from `MatchFieldCoder`'s own
scheme (slot symbol + extra bits, repeat-offset slots cheap) and each
candidate literal run's cost from a fixed bits-per-byte constant, then
accepted only matches with positive estimated savings. Result: `json`
-7.4%, `table` -5.8%, `text` roughly flat - but `executable.bin` got
*worse*, +0.9% to +2.8% across every constant tried. Root cause: the
formula's implied ~31-bit cost for a short fresh-distance match was
roughly 1.6x the ~18.75-bit real average (typical matches in this content
turned out to have small, cheap-to-encode distances - opcodes recur every
few bytes - not the near-max-file-size distances the formula implicitly
assumed).

### Attempt 2 (reverted): self-calibrated per-byte-value literal cost

Replaced the fixed literal-cost constant with a per-file order-0 byte
histogram (Laplace-smoothed, prefix-summed for O(1) range queries), so
common bytes cost less than rare ones instead of a flat guess. Made
`executable.bin` *worse still* (+0.9% to +2.8%, literal count nearly
tripled from 18,150 to 42,751): a *global*, position-blind histogram can't
represent that this content's real entropy coder splits literal
statistics by context (`EntropyCoderSelector`'s post-match vs.
post-literal split - see Entry 1), and ~87% of this file's bytes come
from a ~10-value opcode alphabet mixed with near-uniform random operand
bytes, a distribution shape a single formula couldn't fit for both this
and text/JSON/table at once without per-content tuning - exactly the kind
of fragility Entry 3 flagged analytic literal-cost modeling as risking.

### What shipped: ranking-only repeat-offset preference

Dropped cost *estimation* entirely in favor of the one piece of that
reasoning that needs no calibration: a repeat-offset distance is *always*
cheaper to encode than a fresh one (one MRU slot symbol vs. a slot symbol
plus up to ~17-18 raw extra bits), so it's worth ranking above a modestly
longer fresh-distance candidate - never accepting a *worse* match outright,
only preferring a cheaper one when candidates are close. Swept
`REPEAT_BONUS` (the length credit given to a qualifying repeat-offset
candidate) x `REPEAT_BONUS_MIN_LEN` (the repeat candidate's own minimum
length before it's eligible for the bonus - guards against a bare
4-byte repeat undercutting a genuinely longer fresh match) against real
encoded output on all six built-in fixtures plus two synthetic
`20KB JSON + N KB table + 20KB JSON` mixes (N=3,8). `minLen=8, bonus=2` was
the strongest point found where **no fixture got worse**, only smaller or
unchanged:

| fixture | before | after | ratio before -> after |
|---|---:|---:|---|
| `text.txt` | 39,843 | 39,807 | 6.579x -> 6.585x |
| `records.json` | 30,659 | 30,348 | 8.550x -> 8.638x |
| `random.bin` | 262,171 | 262,171 | 1.000x -> 1.000x (unchanged) |
| `table.bin` | 19,246 | 18,146 | 13.621x -> 14.446x |
| `image.bmp` | 48,331 | 48,331 | 4.069x -> 4.069x (unchanged) |
| `executable.bin` | 87,431 | 87,429 | 2.998x -> 2.998x |
| mixed json+3K table+json | 3,281 | 3,210 | 13.420x -> 13.717x |
| mixed json+8K table+json | 3,964 | 3,885 | 12.400x -> 12.652x |

All eight numbers are through the real `encodeChunk` path (full framing
overhead included, not just the raw codec), with the classifier untouched
from Entry 3's shipped state.

### Verdict

**Shipped.** Genuine gains on two of the three targeted types (`text`,
`json`) plus `table` and both mixed-content stress fixtures, `executable`
effectively flat (-2 bytes, technically a tiny improvement, not the
regression either analytic attempt produced), and zero fixtures worse than
before. Change is contained to `LongRangeMatcher.kt`: `rankScore` adds one
4-element array scan per candidate already being evaluated - no new O(n)
passes, no touched `FileAnalyzer`/`ContextPredictor`/`EntropyCoderSelector`/
`NovaContainerFormat`. Token semantics, decode logic, and match validity
constraints (`length >= MIN_MATCH`, `distance <= i`) are all unchanged, so
losslessness holds by the same argument as the original matcher: decode
doesn't care *which* valid match was chosen, only that it *is* valid.

### Suggested next subsystem

## Entry 5: encode-speed profiling and allocation reduction (LongRangeMatcher)

### Starting point

A different kind of ask than Entries 1-4: not ratio, but wall-clock speed on
real hardware. A device run on a 16MB real-world GBA ROM
(`Shining Soul II (USA).gba`) measured NovaCompress at 60.6s to compress -
slower than every other algorithm in the app including Bzip2, and 3.4x
slower than LZMA2 despite LZMA2 reaching a meaningfully better ratio
(3.29x vs 2.76x). Research Mode's own numbers from that run (877,940 match
tokens out of 4,894,501 total = 17.9% match share; 9.2% prediction
accuracy) describe content with much less exploitable redundancy than the
six built-in synthetic fixtures Entries 1-4 were tuned against - most of
this file is bytes that don't match anything nearby and aren't predictable
from their neighbors, which matters for where time actually goes (see
below). Goal: reduce compress time on this kind of content, with ratio,
decompress time, and every existing feature held fixed - revert anything
that trades away any of those three.

### Methodology

Same constraint as every prior entry: no Android SDK, Gradle, or Kotlin/Java
compiler in this sandbox, only a JRE - so, same approach as Entries 3-4,
the full encode/decode pipeline (`FileAnalyzer`, `RegionClassifier`,
`EntropyCalculator`, `Segmenter`, `LongRangeMatcher`, `MultiLevelDictionary`,
`ContextPredictor`, `FreqModel`/`RangeEncoder`/`RangeDecoder`,
`HuffmanCoder`, `EntropyCoderSelector`, `MatchFieldCoder`, `NovaSegmentCodec`,
and `NovaContainerFormat.encodeChunk`/`decodeChunk` including the full
trial-and-promote/merge-vs-split logic from Entry 2) was ported line-for-line
to Java, verified round-trip-correct, and used for every measurement below
via `java SomeFile.java`'s single-file launcher (still no javac available).

Two methodology problems specific to *timing* (rather than the correctness/
ratio checks prior entries relied on) surfaced and got fixed before any
number below is trustworthy:

1. **Self-time attribution.** A profiler bucket per subsystem
   (`FileAnalyzer`, `Segmenter`, `LongRangeMatcher`, `MultiLevelDictionary`,
   `ContextPredictor`, `MatchFieldCoder`, `RangeEncoder`, `ContainerFormat`)
   is timed at its own leaf call sites, not by wrapping callers - e.g.
   `LongRangeMatcher.tokenize()` is timed as a whole (it doesn't call into
   any other timed subsystem), while `ContainerFormat`'s bucket is computed
   as (its own wall time) minus (every downstream bucket's growth during
   that span), isolating its own loop/comparison/array-copy overhead from
   the `NovaSegmentCodec.encode()` calls it makes. An early version of this
   subtraction credited "Other" a *negative* percentage - traced to decode's
   own calls into the same shared subsystems (predictor, entropy coder,
   match fields) accumulating into the same static buckets as encode, since
   nothing reset the counters between the two phases. Fixed by resetting
   before decode and reporting encode's breakdown first.
2. **Cold-JVM noise.** Single cold-JVM-per-config measurements were
   swinging by up to 2x run to run (JIT warmup dominates on a workload this
   short), enough to make two genuinely different configurations look
   identical or backwards. Every number below instead comes from several
   configurations swept *within one JVM process* (shared warmup/JIT state,
   several discarded warmup iterations before any measured one, several
   measured iterations reported as a median) - this is what caught the
   `matchLen` regression in Attempt 1 below, which looked like a plausible
   win under the noisier methodology.

Test content: no real ROM was available in this sandbox (and using one
wouldn't be appropriate regardless), so a synthetic generator was built and
calibrated against the real device numbers above rather than assumed
representative - mixing reused-but-not-identical "code-like" sequences,
restricted-palette "noisy" regions (skewed, not uniform, byte values - see
below), periodic tile-like records, text, and genuinely unique filler, tuned
until match share (16.6% vs. the device's 17.9%) and ratio (~2.9x vs. 2.76x)
landed close to the real run. One deliberate departure from strict realism:
byte values throughout are drawn from a restricted ~48-value palette rather
than the full 0-255 range, because Shannon entropy (which `RegionClassifier`
uses for its STORE/pipeline decision) only depends on the marginal byte-value
distribution, not sequence-level repetition - a fully-uniform-random region
can share almost the same entropy as a highly repetitive one built from the
same alphabet, so pure `Random.nextBytes()` content pushed far more of the
buffer into STORE than the real device run showed (0.5% of bytes stored).
Real compiled code and packed asset data have skewed, not uniform, byte
distributions for the same underlying reason, so this isn't just a
calibration trick - it's a closer model of the actual content.

### Where the time was actually going

Percentage breakdown of encode wall-clock time, from the *original*
(pre-this-entry) matcher, median of 6 measured runs after 6 discarded
warmup runs, 4MB of calibrated synthetic content:

```
LongRangeMatcher .......... 41-49%
ContainerFormat ............ 17-21%
ContextPredictor ........... 15-17%
RangeEncoder ............... 10-12%
MatchFieldCoder .............2-3%
HuffmanTrial ................1.5-2%
MultiLevelDictionary .........1-2%
FileAnalyzer ................1.5-2%
SymbolListOverhead ..........~0.2%
Segmenter ...................~0.01%
Other ........................~0%
```

(Ranges rather than single numbers because run-to-run variance at this
workload size was itself several percentage points wide even after
warmup - see methodology above - not because the ranking is uncertain:
`LongRangeMatcher` was the largest bucket in every single run across every
scale and content mix tried, by a wide enough margin over the second-place
bucket that the ranking itself was never in doubt even when the exact
percentages moved.)

`LongRangeMatcher`'s share also *grew* with input size in every scale
tested (1MB -> 4MB moved it from ~30% to ~36-49% depending on run) -
consistent with its hash-chain search cost scaling worse than linearly:
`MultiLevelDictionary`'s hash table is a fixed `2^17` (131,072) buckets
regardless of chunk size, so a larger chunk means more candidate positions
competing for the same buckets, and therefore longer chains to walk before
hitting `MAX_CHAIN`'s 64-candidate cap. This means the real device's 16MB
ROM almost certainly saw an even larger `LongRangeMatcher` share than any
number measured here - this entry's fixture sizes were kept to 1-6MB to
keep the sandbox's total sweep time manageable, not because larger sizes
were expected to change the ranking.

### Root cause

`LongRangeMatcher.bestMatchAt` walks up to `MAX_CHAIN` (64) hash-chain
candidates per call, calling `matchLen` (a byte-comparison loop) against
each one, and `tokenize` calls `bestMatchAt` up to twice per token (the
match itself, plus a one-step lazy lookahead - see Entry 4). On content
with real, sustained redundancy this pays for itself - it's *why* `MAX_CHAIN`
and lazy lookahead exist, and Entry 4 already showed real ratio gains from
searching thoroughly. But the device's own Research Mode numbers (17.9%
match share, 9.2% prediction accuracy) describe content where most
positions *don't* have a good match to find - meaning most `bestMatchAt`
calls walk some or all of that 64-candidate chain only to conclude there's
nothing (or nothing better than a short match already found) there, paying
the full search cost for none of the ratio benefit.

### Attempt 1 (reverted): word-at-a-time `matchLen`

Hypothesis: `matchLen`'s byte-at-a-time comparison loop is itself the hot
path, and comparing 8 bytes at once (XOR two `long`s built from 8 bytes
each, count trailing zero bits to find the first mismatch when they
differ) would speed up every one of those up to 64+2 calls per position
without changing which candidate wins or its reported length - ratio-safe
by construction, since it computes the exact same value, just in bigger
steps. Measured *slower* (an isolated, warmed-up, same-process comparison
against the unmodified loop showed the word-at-a-time version consistently
behind, never ahead). Root cause, in hindsight: most calls in this content
either fail within the first few bytes or return a short (10-30 byte)
match - short compared to the 8-byte word size - so the fixed overhead of
constructing two `long`s from 16 individual byte reads plus shifts often
costs more than the byte-at-a-time loop it was meant to replace, which the
JIT already compiles into tight, well-predicted code. Reverted per this
project's own rule: if measured speed doesn't improve, revert - confirmed
by direct, isolated, same-process measurement rather than assumed from the
theory.

### Attempt 2 (rejected, not reverted - never shipped): stall-based early exit

Hypothesis: since most chain walks find nothing worth keeping, stop early
once several candidates *in a row* fail to improve the best score found so
far (adaptive - resets the moment a candidate does help, unlike a flat
depth cut). This was the only lever tried that produced a large speedup:
roughly 15-30% faster encode depending on the stall threshold, tunable
against ratio. It was *not* shipped, because every threshold tried that
gave a meaningful speedup also measurably reduced ratio (roughly 0.2-1.0%
smaller ratio depending on how aggressive the threshold was) - it stops
searching before some genuinely-better, deeper candidate would have been
found. That's a real, direct violation of "do not reduce compression ratio,"
not a rounding artifact, so per this project's own explicit rule it was not
adopted. Recorded here rather than discarded silently because it's the
single largest lever found in this entry, in case a future pass wants to
revisit it as an explicit, opt-in speed/ratio tradeoff rather than a
transparent "free" win - that would be a product decision this entry
deliberately didn't make unilaterally. A flat, generous "nice length" cutoff
alone (stop searching once a candidate is already very long, without the
stall mechanism) was also tried first and measured almost no benefit on its
own - most matches in this content never get long enough to reach a cutoff
worth using, so the real lever here was giving up on unproductive searches,
not capping productive ones.

### What shipped: allocation reduction, unchanged search

Two changes, both provably ratio-neutral because neither touches *which*
candidate is searched, found, or kept - only how the search's own
bookkeeping is done:

1. **`tokenize`'s token list is now pre-sized** to `data.size` (a safe
   upper bound - a token can never cover zero bytes, so token count can
   never exceed byte count), eliminating the repeated internal array
   allocate-and-copy an unsized `ArrayList` pays as it grows from empty to
   (typically) hundreds of thousands or millions of entries.
2. **`bestMatchAt` no longer allocates a `Token` for its own result.** It's
   called up to twice per token (the match, plus Entry 4's one-step lazy
   lookahead), and the lookahead's result is thrown away whenever the
   original match wins - measured as the common case in this content. The
   two `Int`s (distance, length) are now packed into one `Long` (both
   values are always well within 32 bits for any realistic chunk size, so
   this loses no information) and only unpacked into a real `Token` once a
   match is actually kept, for either output list. `-1L` is a safe "no
   match" sentinel: a real match's distance is always >= 1, so a valid
   packed value can never collide with it.

Neither change alters `bestMatchAt`'s accept/reject logic, `rankScore`'s
candidate ranking, `MAX_CHAIN`, the lazy-lookahead comparison, or anything
about which match wins - decode doesn't care *how* the encoder arrived at a
token, only that it's valid, so token semantics, decode logic, and the
container format are all unaffected. Confirmed directly, not just argued:
every fixture in the sweep below produced byte-identical compressed output
between the original and this change - not just the same size, the same
bytes - and every one round-trips losslessly.

Files touched:
- `matcher/LongRangeMatcher.kt` - both changes (pre-sized `ArrayList`,
  packed-`Long` `bestMatchAt` return type replacing `Token`). No other file
  needed to change: `tokenize`'s public signature and return type
  (`List<Token>`) are unchanged, so `NovaSegmentCodec` and everything else
  downstream needed no changes at all.

### Results

4MB of calibrated synthetic content, same content and seed before/after,
median of 6 measured runs (6 discarded warmup runs first) in the same JVM
process for both configurations:

| | before | after | change |
|---|---:|---:|---|
| Encode (median) | 2516.8 ms | 2397.8 ms | -4.7% |
| Ratio | 2.9261x | 2.9261x | unchanged (byte-identical output) |
| Compressed size | identical | identical | unchanged |
| Round-trip | PASS | PASS | unchanged |
| `LongRangeMatcher` bucket | 939.4 ms (41.4%) | 952.8 ms (39.7%) | ~flat in isolation; net win shows up in overall wall time via less GC/allocation pressure, not a smaller bucket |

A modest, real win - not the large one Attempt 2 found, because it doesn't
touch the actual search cost (still `MAX_CHAIN` candidates walked, same as
before), only the bookkeeping around it. Decompression is untouched by
every change in this entry: `LongRangeMatcher` only runs during encode,
`decode`'s code path calls neither `tokenize` nor `bestMatchAt`.

### Why this is safe

- **Ratio**: proven byte-identical output (not just equal-sized) across the
  full sweep, and argued structurally above - the packed-`Long` change is a
  return-type change with no effect on control flow, and pre-sizing an
  `ArrayList` cannot change its contents.
- **Decompression speed**: structurally unaffected - decode never calls
  `LongRangeMatcher` at all.
- **Existing features**: `MAX_CHAIN`, lazy lookahead, and Entry 4's
  cost-aware `rankScore` are all untouched; nothing was removed or bypassed,
  only how results move between functions internally.
- **Losslessness**: token semantics (`Token.Match(distance, length)`) are
  byte-for-byte the same values reaching `tokens` as before; `MatchFieldCoder`
  and the container format, which is where actual correctness risk would
  live, weren't touched by this entry at all.

### Suggested next subsystem

`ContainerFormat` (17-21% of total time, second-largest bucket in every
run) is doing more physical byte-copying than its own logic strictly
needs: Entry 2's trial-and-promote safety net calls `Arrays.copyOfRange`
once per STORE-candidate segment to build the trial input, and separately
builds a fresh merged buffer (another full copy) for every multi-segment
NOVA run's merge-vs-split comparison - on content where most segments end
up NOVA (true for both this entry's fixtures and the real device run,
where only 0.5% of bytes were STORE), that's real, repeated copying of the
same bytes that a more careful implementation could likely avoid without
touching the trial-and-promote *decision* logic itself (which Entry 2
established is load-bearing for both correctness and ratio, and isn't this
entry's to revisit). Unexplored here because it's a different subsystem
than this entry's brief ("Improve ONLY the subsystem with the highest
measured cost") - `LongRangeMatcher` at 41-49% was clearly the single
largest bucket in every run, `ContainerFormat` a clear second.


## Entry 6: matcher rewrite - tiered hashing + pooled workspace (LongRangeMatcher)

**Brief for this entry:** focus only on `LongRangeMatcher`/`MultiLevelDictionary`
(everything else - `FileAnalyzer`, `ContextPredictor`, the entropy coder,
`NovaContainerFormat`, `Segmenter` - off limits unless correctness strictly
required it; it didn't). Starting point was the real-device 16MB GBA ROM
benchmark from earlier in this file's history:

| metric | value |
|---|---|
| ratio | 2.76x |
| compress | 69306 ms (0.2 MB/s) |
| decompress | 11906 ms (1.3 MB/s) |
| match share | 17.9% (877,940 / 4,894,501 tokens) |
| chunks / segments | 1 / 636 |

### Sandbox methodology (same as every prior entry)

No Android SDK, Gradle, or Kotlin compiler is available in this sandbox -
only a bare JRE (`java Foo.java`'s single-file launcher, no `javac`
binary). As in Entries 1-5, the whole encode pipeline (`FileAnalyzer`,
`Segmenter`, `Token`, both the old and new matcher, `ContextPredictor`,
`RangeEncoder`/`RangeDecoder`/`HuffmanCoder`, `EntropyCoderSelector`,
`MatchFieldCoder`, `NovaSegmentCodec`, and a `NovaContainerFormat.encodeChunk`-
equivalent) was ported line-for-line to a single Java file and verified
before trusting any measurement from it:

- The six built-in sample fixtures, re-generated from the same structural
  recipe as `SampleDatasetGenerator.kt` (word lists, JSON record shape,
  BMP layout, opcode-snippet padding - PRNG streams differ, structure
  doesn't), reproduced Entry 4's own published "after" encoded-byte counts
  **exactly**: `text.txt` 39,807 · `records.json` 30,348 · `random.bin`
  262,171 · `table.bin` 18,146 · `image.bmp` 48,331 · `executable.bin`
  87,429. That's about as strong a confirmation as this methodology can
  give without an actual device.
- No real GBA ROM is available or appropriate to fetch into this sandbox
  (copyrighted game content, and there's no network access here regardless).
  As in Entry 5, a calibrated synthetic "ROM-like" fixture stands in:
  reused-but-jittered "code-like" snippets, skewed-not-uniform "noisy"
  regions, a periodic tile-like record, and unique filler, tuned until its
  *token* match share (not just byte-weighted) landed close to the real
  device's 17.9% (16MB fixture: 18.9% at final settings). Every number
  below carrying the word "rom-like" is this synthetic fixture, not the
  real device - flagged the same way Entry 5 flagged it.
- The full existing round-trip suite (`NovaSegmentCodecTest.kt`, ported
  case-for-case, including the 15-iteration fuzzed-content loop and the
  2MB performance-sanity case) passes byte-for-byte against **both** the
  ported original matcher and the new one, including with a single shared,
  reused workspace run through the whole suite twice in a row (the actual
  production access pattern) - this is what caught two real bugs before
  they reached Kotlin (below).

### Root cause (confirms Entry 5's finding)

Entry 5 identified but didn't fix: `HASH_BITS = 17` (131,072 buckets) was
a compile-time constant regardless of how much data one `tokenize()` call
covered. For a normal few-hundred-KB segment that's plenty (`prev`
average chain length: 1-2). For the real ROM's 16MB, naive average chain
length is **128 candidates per bucket** - *above* `MAX_CHAIN=64`, meaning
a large fraction of positions were already paying the full 64-candidate
walk and still truncating before reaching a genuinely better candidate
further down the chain, on every single position in the file, not just
the "hard" ones.

### What shipped

Full design rationale lives in the KDoc on `LongRangeMatcher.kt` and
`MultiLevelDictionary.kt` (kept there deliberately, not just here, so it
stays next to the code it explains). Summary:

1. **Two hash levels sized to the call, not fixed at 2^17**
   (`MultiLevelDictionary.shortHashBitsFor`/`tierHashBitsFor`). Floor is
   exactly the original's 131,072 buckets, so anything at or under
   roughly the original's typical segment size sees a byte-identical
   table. Grows only once an input is big enough that the fixed table
   would have produced long chains in the first place.
2. **One added 8-byte-anchor tier**, single-slot (no chain), checked
   before the 4-byte chain - an O(1) fast path for long-match discovery
   (item 1/2/3 of the brief). ~76% of tier lookups that find *any*
   candidate turn into a real match on the rom-like fixture (see
   "Diagnostics" below).
3. **Pooled workspace** (`MultiLevelDictionary`, one per compression
   thread via `ThreadLocal`, matching `NovaCompressAlgorithm`'s existing
   `Dispatchers.Default` chunk-parallelism) instead of fresh `IntArray`
   allocations per `tokenize()` call. Generation-stamped instead of
   cleared: `beginCall` increments a counter in O(1) rather than
   re-zeroing potentially millions of entries (item 5/8).
4. **`Token.Literal` instance cache** (256 precomputed singletons) -
   literals are ~82% of all tokens on the real device's own reported
   numbers, so this removes the large majority of matcher-side token
   allocation for free (item 8).
5. **Adaptive chain depth**: after `MISS_THRESHOLD=16` consecutive
   positions find nothing at all (not one difficult position - a whole
   *region*), the tier lookup is skipped and the chain walk's depth drops
   to `REDUCED_CHAIN=1` until something matches again (item 6).
6. **Fast match extension** for tier hits specifically, via
   `java.util.Arrays.mismatch` where available (item 9) - see "Match
   extension: three techniques measured" below for why this one and not
   the other two tried.
7. **Small inputs (`< 1 MiB`) take a separate, size-gated code path**
   that's algorithmically the *original* matcher, unchanged - see
   "Attempt: routing everything through one parameterized path" below for
   why, and the class KDoc for the exact threshold reasoning.

Lazy matching, `rankScore`'s repeat-offset cost-aware ranking (Entry 4),
and `MAX_MATCH`/`MIN_MATCH` are all unchanged in behavior (see "Attempt:
capping lazy matching at a fixed depth" for why the lazy-matching *shape*
specifically was deliberately left alone).

### Attempts (reverted or rejected)

Five separate things were tried and measurably didn't work, in the same
spirit as Entries 4 and 5's own rejected attempts:

**Attempt 1 - table size scaled straight off input size, no floor tying
it back to the original.** First formula was `bits = clamp(log2(n)+1, 15,
21)`. Ratio was unaffected (expected - table size doesn't change what's
findable, only how fast). Speed *regressed* on every one of the six
32-256KB sample fixtures (worst: `image.bmp` and `executable.bin`, both
noticeably slower) despite the algorithm doing essentially identical
work - a table 4-16x bigger than necessary for a small input spreads
lookups across more cache lines for zero benefit (chains were already
short), even though generation-stamping means there's no *clearing* cost
to oversizing. Fixed by tying the floor to the original's exact 131,072
buckets and only growing once `n` is large enough that the original's
fixed table would genuinely have produced long chains - see
`MultiLevelDictionary`'s KDoc §2.

**Attempt 2 - three anchor tiers (32/16/8-byte) instead of one.**
Tried as the most literal reading of the brief's four example anchor
lengths (4 via the existing chain, 8/16/32 via three single-slot tiers,
longest-first with early-accept). Measured real ratio gains on
`text.txt`/`executable.bin`/rom-like - but a real ratio **regression** on
`table.bin` specifically (`table.bin` is a tightly repetitive fixed-stride
record with one varying byte; a 16- or 32-byte anchor can land on a
window that happens to avoid that one varying byte, finding a different,
non-repeat-offset candidate that out-scores the ideal repeat-offset match
`rankScore` would otherwise have picked) - for a real, compounding fixed
cost (each extra tier is another 8-byte-ish hash computed at nearly every
position, whether or not it ever pays off). One tier at 8 bytes keeps
essentially all the measured benefit with none of the `table.bin`
regression; dropped the other two.

**Attempt 3 - routing every input through one parameterized search
path** (bundling the pooled arrays into a small `Search` object,
resolving `n < threshold` as a runtime branch *inside* that one path
instead of two separate functions). Measured **15-35% slower** than the
shipped design on the low-match-share small fixtures (`random.bin`,
`image.bmp`) even after every other change was held identical - reading
array references out of an object field on every call, rather than
receiving them as genuine method parameters the way the original
`bestMatchAt(data, i, n, head, prev, rep)` always did, was consistently
enough to change what the JIT was willing to do with the hot loop, in
isolation from every other variable tested. The shipped design instead
keeps small inputs on their own compact, unparameterized implementation
(`tokenizeSmall`/`bestMatchAtSmall`) - see the class KDoc's "Two search
strategies" for the fuller reasoning, and why that's a deliberate choice
of the new matcher rather than legacy code left in place.

**Attempt 4 - the tier lookup folded directly into the main per-position
search function**, rather than split into its own `tryTier`. Identical
logic, purely a code-organization difference - and it alone cost a
uniform 8-15% slowdown across *every* fixture, including ones where the
tier branch never even fires (`random.bin`), because the larger method
body pushed the hot per-position function past the JIT's inlining size
threshold. Splitting `tryTier` out and combining its result with the
chain walk's one level up (`bestMatchAt`/`pickBetter`) recovered it
fully - both pieces stayed exactly as small as the original's own
`bestMatchAt` was.

**Attempt 5 - capping lazy matching at a fixed 2-step lookahead.**
Reasoning going in: the original's lazy matching looked ahead exactly one
position (`bestMatchAt(i+1)`), so bounding a "2-step" version seemed like
a strict improvement matching the brief's "compare nearby candidates...
instead of the first acceptable one." That reasoning was wrong about what
the original does: its `pending`/`continue` mechanism actually chains
*unboundedly* - it keeps deferring for as long as each successively later
position keeps strictly improving, which is already "compare nearby
candidates, don't stop at the first," just not through an explicit step
counter. A hard 2-step cap is a **regression** against that (it can stop
deferring exactly where the original wouldn't have), and it showed up
immediately: `json`/`executable.bin` ratios both measurably dropped the
moment small inputs were routed through the capped version instead of an
exact reimplementation. Fixed by keeping the exact same unbounded
chained-deferral shape as the original on both the small and large paths
- see the class KDoc for the "why this had to stay unbounded" note.

### Match extension: three techniques measured

Item 9 of the brief asks specifically for "compare 8 or more bytes at a
time before falling back to byte comparisons." Three different ways of
doing that were measured in an isolated microbenchmark (71,979
same-array candidate pairs, lengths 4-8192 bytes, best-of-6 after 8 warm
rounds) before picking one:

| technique | best time | vs byte loop |
|---|---|---|
| byte loop (baseline) | 1.81 ms | 1.00x |
| manual bit-shift into a `Long`, then compare | 1.91 ms | 0.95x (slower) |
| `java.lang.invoke.VarHandle` byte-array view | 0.67 ms | 2.70x |
| `java.util.Arrays.mismatch` | 0.60 ms | 3.02x |

Manual bit-shifting losing to the byte loop it was meant to replace is
consistent with Entry 5's original finding about `matchLen` generally -
confirms it wasn't specific to how Entry 5 happened to use the technique.
`VarHandle`'s byte-array-view accessors are genuinely fast (a real
hardware-backed unaligned read), but its access-mode methods are
*signature-polymorphic* - special compiler support most non-Java JVM
languages have had to add deliberately (Scala's own public writeup on
this is explicit that it took dedicated work landing in 2.11.5, refined
further since). Whether Kotlin's compiler emits the correct call-site
descriptor for this to actually resolve to the fast intrinsic path,
rather than silently falling back to a slow boxing/reflective path or
failing to compile outright, could not be verified in this sandbox -
there's no Kotlin compiler available to inspect the emitted bytecode
against, and it's not the kind of thing worth shipping on an unverified
guess. `Arrays.mismatch` sidesteps the question entirely: it's an
ordinary, non-polymorphic static method, so there's no special-compiler-
support question to begin with, *and* it measured faster than the
`VarHandle` version in the same benchmark - almost certainly because the
platform implementation is free to use a vectorized comparison
internally, which is exactly what the method exists for. Shipped
`Arrays.mismatch`, gated on `Build.VERSION.SDK_INT >= 33` (same floor as
`VarHandle` would have needed anyway - both landed in Android 13/API 33,
comfortably above this app's `minSdk = 26`) with a plain byte-loop
fallback below that.

**Open item for whoever next touches this file with real Gradle/Kotlin
toolchain access:** confirm `Arrays.mismatch` actually compiles as
written and ideally spot-check generated bytecode/on-device timing before
fully trusting the numbers above translate 1:1 - this sandbox's Java port
is the closest available proxy, not a substitute for the real toolchain.

### Benchmark results

**Six sample fixtures** (small-input path - see class KDoc for why this
is algorithmically identical to the original below `1 MiB`): every
encoded byte count is **identical** to the pre-Entry-6 baseline (down to
the byte - `text.txt` 39,807, `records.json` 30,348, `random.bin`
262,171, `table.bin` 18,146, `image.bmp` 48,331, `executable.bin`
87,429), and best-of-9-trial compress time is within ±5% either way of
the original on every one of them - noise-level, not a regression.

**Rom-like fixture, 16MB (large-input path)**, single measured pass after
warmup, best of two independent runs:

| metric | before | after | delta |
|---|---|---|---|
| ratio | 3.448x | 3.458x | +0.29% |
| compress | 11,509-11,742 ms | 8,117-8,282 ms | **1.39-1.45x faster** |
| decompress | ~2,500 ms | ~2,500 ms | unaffected (expected - decode never calls the matcher) |
| tokens | 3,431,649 | 3,435,126 | - |
| matches | 662,062 | 648,770 | -2.0% (fewer, but longer - see below) |
| match share (tokens) | 19.29% | 18.89% | -0.4pp |
| avg match length | 21.2 bytes | 21.6 bytes | +1.9% |

Match *share* alone doesn't tell the full story here: match *count* went
down while the *ratio* went up, meaning the average match got longer -
consistent with the tier mechanism successfully consolidating what used
to be several short chain-found matches into fewer, longer tier-found
ones. At 4MB (a smaller, faster-to-iterate cut of the same fixture, used
throughout development), the speedup was consistently larger still
(2.0-2.2x best-of-11) - the benefit scales with how far past the
original's fixed-table "knee" the input goes, so the real 16MB ROM
sitting well past that knee is the more representative number, and there
may be room for the gap to widen further at 16MB with more tuning than
this entry had time for.

### Diagnostics (16MB rom-like, instrumented pass)

| metric | value |
|---|---|
| longest match found | 88 bytes |
| avg candidates examined per short-chain walk | 19.2 (naive average under the *old* fixed table at this size: 128.0) |
| short-chain walks that still hit the depth cap | 39.4% (down from effectively "most of them," since 128 > `MAX_CHAIN=64` under the old table) |
| tier lookups performed | 2,601,625 |
| tier hit rate (found *any* candidate) | 75.7% |
| tier early-accepts (skipped the chain walk entirely) | 0 (0.00%) |

The zero early-accepts is worth flagging honestly: `EARLY_ACCEPT_LEN=128`
never fires on this fixture because its longest match anywhere is 88
bytes - a limitation of the synthetic generator's snippet-pool design
(individual reused sequences top out well under 128 bytes), not
necessarily representative of a real ROM, which may well contain longer
verbatim-duplicated blocks (padding runs, repeated tile/asset data) that
would exercise this path. 39.4% of walks still hitting the depth cap
also suggests there's more headroom in this specific area than this
entry captured - a reasonable candidate for the next matcher-focused
pass.

### Verification

- Full `NovaSegmentCodecTest.kt`-equivalent suite: byte-identical
  round-trip on every case, both matchers, including a shared/reused
  workspace run twice through the whole suite (the actual pooling access
  pattern) - this specifically is what caught the Attempt 5 (capped lazy
  matching) and a real generation-counter bug (an early version reset the
  pooled generation counter back to a small number whenever the short
  table grew, which could resurrect a stale entry from an unrelated
  earlier call sitting in some *other*, not-just-grown array - fixed by
  never resetting it, see `MultiLevelDictionary`'s KDoc).
- Decompression speed: structurally unaffected, since decode never calls
  `LongRangeMatcher` - confirmed unaffected in measurement too.
- Losslessness: `Token.Match(distance, length)` semantics are completely
  unchanged; `MatchFieldCoder` and the container format weren't touched.
- `NovaSegmentCodec.kt` (the matcher's only consumer) required **zero**
  changes - `LongRangeMatcher.tokenize(data: ByteArray): List<Token>` and
  `LongRangeMatcher.MIN_MATCH` are exactly the same public surface as
  before.

### Suggested next subsystem

Two threads worth picking up, both still inside the matcher's own scope
rather than a different subsystem:

1. The 39.4%-of-walks-still-capped and zero-early-accepts numbers above
   both point at real remaining headroom specifically in *long*-match
   handling - a real ROM's longer verbatim-duplicated runs (this entry's
   synthetic fixture likely underrepresents them) would exercise the tier
   early-accept path much more than measured here.
2. `MAX_MATCH = 1 shl 18` (262,144 bytes) was left completely unexamined
   this entry - `MatchFieldCoder`'s slot/extra-bits scheme already
   supports arbitrary lengths, so this cap is pure matcher policy, not a
   format constraint, and raising it is a same-file, same-scope change
   that simply wasn't part of this entry's brief.

## Entry 7: adaptive search budget + classifier periodicity fix + generalized ranking (matcher + classifier + container)

**Brief for this entry:** the eight-item spec (adaptive search budget,
progressive matcher stages, modern match finder, better match scoring,
limited optimal parsing, skip worthless searches on
already-compressed/random data, adaptive entropy models, preserve existing
architecture), priority order ratio > speed > decompression speed >
losslessness > memory.

**A note on the starting-point numbers this entry was given:** the on-device
GBA ROM figures supplied with this brief (2.76x, 69,306 ms compress, 11,906
ms decompress, 17.9% match share, 636 segments) are **identical** to Entry
6's own pre-fix baseline, not the tree this entry actually started from -
Entry 6's matcher rewrite (tiered hashing, pooled workspace) is already
present in `LongRangeMatcher.kt`/`MultiLevelDictionary.kt` on disk. The
likely explanation is an installed APK built before Entry 6 was merged; this
entry's Java-port baseline reproduces Entry 6's own published *after*
numbers almost exactly (see "Sandbox methodology" below), confirming the
source tree itself is current. Worth a rebuild-and-reinstall before
comparing this entry's numbers against a fresh on-device run, or the
Entry-6 improvement will look like it came from this entry instead.

### Sandbox methodology

No Android SDK, Gradle, or Kotlin compiler is available in this sandbox, and
unlike prior entries, not even a `javac` binary - only `java` (OpenJDK 21
JRE). The single-file source-launcher prior entries relied on
(`java Foo.java`) can't compile a multi-file project, so this entry instead
drove `javax.tools.ToolProvider.getSystemJavaCompiler()` directly (the
compiler *module*, `jdk.compiler`, turned out to still be present even
without the `javac` launcher script) to compile the full ported pipeline as
a normal multi-file `javac`-equivalent build. As in Entries 1-6, the whole
pipeline - `FileAnalyzer`/`RegionClassifier`/`EntropyCalculator`,
`Segmenter`, `Token`, the matcher (both an unmodified-baseline copy and a
copy with this entry's changes), `ContextPredictor`, a range-coder-only
`EntropyCoderSelector` (Huffman comparison omitted - simplification carried
over from Entry 4/5/6's own port), `MatchFieldCoder`, `NovaSegmentCodec`,
and a `NovaContainerFormat.encodeChunk`-equivalent - was ported line-for-line
to Java and verified before trusting any measurement from it:

- The six built-in sample fixtures, regenerated from the same structural
  recipe as `SampleDatasetGenerator.kt` (PRNG streams differ, structure
  doesn't - same caveat as every prior entry), reproduced Entry 6's own
  published baseline almost exactly: this entry's ported-baseline
  `text.txt` is 39,797 bytes against Entry 6's reported 39,807 (0.03% off,
  well within PRNG-stream noise), and the rest land in the same range.
- Round-trip losslessness was checked on **every** config × fixture
  combination this entry ran, not just the shipped one - baseline, each
  ablation, the shipped combination, the reverted attempt, the large
  4MB blob, and the heterogeneous multi-region fixture - and passed on all
  of them, throughout every intermediate iteration including the one that
  got reverted.
- No real GBA ROM is available or appropriate to fetch into this sandbox
  (copyrighted game content, no network access here regardless) - same
  constraint Entries 5 and 6 noted. Synthetic fixtures stand in throughout;
  flagged as such below.

### What shipped

Full design rationale lives in the KDoc on each changed file (kept there
deliberately, not just here). Summary:

1. **`RegionClassifier`/`EntropyCalculator`: periodicity check
   (`periodicityRatio`)**, closing a gap the codebase's own history had
   already identified and deliberately left unfixed (see "FileAnalyzer/
   RegionClassifier periodicity blind spot" earlier in this file): an
   8-byte-aligned exact-shingle repetition check can't see a fixed-width
   record whose only varying field is a monotonic counter/ramp, since no
   two records are byte-identical even though the structure is completely
   regular. `periodicityRatio` instead looks for a *dominant delta* (not
   dominant exact-match) at each of a set of candidate strides - a
   per-record counter produces a strongly dominant constant delta at its
   record stride even though it produces zero dominant exact repeats.
   Previously left unfixed because it measured zero ratio impact on its
   own (the container format's trial-encode-and-promote safety net already
   recovers the ratio for a misclassified-but-compressible segment - it
   only costs one redundant encode call). Revisited now because it's a
   prerequisite for (2) below to be safe - see that item.
2. **`SearchBudget`: a four-tier (HIGH/MEDIUM/WEAK/MINIMAL) search-effort
   hint**, computed once per segment (or per merged run of segments) from
   the classification work `FileAnalyzer`/`Segmenter` already did -
   nothing new to measure, per the "preserve existing architecture" item.
   Chain depths (64/16/4/0) scale the spec's own illustrative
   256/64/16/skip example down to this codebase's already-tuned ceiling
   (`SMALL_MAX_CHAIN`/old `MAX_CHAIN` = 64) using the same 4x-per-step
   shape. Ships together with (1), not behind an independent toggle -
   applying search-budget hints on top of the *unfixed* classifier was
   tested in isolation specifically to check this, and collapsed
   `table.bin` from 14.45x to 4.63x (a still-misclassified
   ALREADY_COMPRESSED_OR_ENCRYPTED segment routed to MINIMAL effort
   instead of the HIGH effort its real periodic content needs) - see
   "Ablation: hints without the classifier fix" below.
3. **`LongRangeMatcher`: chain depth capped by the tier from (2)**, on
   both the small- and large-input paths - the matcher-level
   implementation of "adaptive search budget" (item 1) and "skip
   worthless searches" (item 6). The small path gets four separate,
   compile-time-constant-chain-depth functions (`tokenizeSmall` /
   `tokenizeSmallMedium` / `tokenizeSmallWeak` / `tokenizeSmallMinimal`)
   rather than one function taking chain depth as a parameter, specifically
   to avoid the 15-35% regression Entry 3 already measured from
   parameterizing this exact hot loop (see that file's KDoc); MINIMAL
   additionally skips building the hash table at all, since nothing at
   MINIMAL tier will ever walk it. The large path was already
   parameterized (`bestMatchCore` takes `effChain` as a plain argument, per
   Entry 6), so it just takes the tier's chain depth as a ceiling on top of
   its existing miss-streak reactive cutback - no JIT-shape risk there.
4. **`LongRangeMatcher.rankScore`: generalized, capped, distance-cost-aware
   ranking**, replacing the flat "+2 if repeat-offset and length ≥ 8" rule
   with a graduated credit computed from `MatchFieldCoder`'s own exact
   slot/extra-bits distance-encoding cost (decode-derived, not a guess -
   the earlier literal-byte-cost model that broke on `executable.bin`, see
   "Cost-aware candidate ranking" in `LongRangeMatcher`'s KDoc, never enters
   into it). Reduces to the exact old behavior at a repeat-offset hit.
   Still never affects whether a match is *accepted* - only which candidate
   *wins* when more than one qualifies.
5. **`NovaContainerFormat`: skip the merge-vs-split trial for runs of ≥16
   segments**, going straight to a merged block instead. The trial's own
   cost (encoding the whole run twice, once merged and once split, just to
   decide) grows with run length exactly as fast as the thing it's trying
   to save (per-block `BLOCK_FRAME_OVERHEAD`), so past some run length it's
   pure waste. `16` is a conservative, not fully swept, threshold - see
   "Suggested next subsystem" below.

### What was tried and reverted

**Item 5, "limited optimal parsing"**: a bounded look-ahead window
generalizing the existing single-step lazy-deferral check into an N-step
one, choosing whichever position within the window minimized total
token count (deliberately *not* a literal-bit-cost model, to sidestep the
exact trap that sank the earlier cost-model attempt - see item 4 above).
Implemented, and isolated via a diagnostic harness that ran the *same*
tokens through (new rankScore, old single-step parsing) vs. (new
rankScore, new windowed parsing) so the two changes' effects wouldn't be
conflated:

| fixture | rankScore alone | + windowed parsing | match count (base → windowed) |
|---|---|---|---|
| text.txt | -0.0% | **-5.7%** | 15,630 → 11,331 |
| records.json | +0.5% | **-6.2%** | 10,017 → 5,006 |
| table.bin | +0.0% | **-10.6%** | 10,830 → 10,615 |

The windowed version routinely skipped past a perfectly good nearby match
chasing a marginally-better-by-token-count distant one, fragmenting what
should have stayed long matches - on `records.json` it roughly *halved*
the match count. The existing unbounded single-step chained-deferral lazy
matching (left completely unchanged) already captures this tradeoff
better than the wider window did. Reverted per this project's explicit
"if it reduces ratio, revert and explain why" instruction and its own
established "measure, keep or revert" process (direct precedent: Entry 4's
own reverted cost-model attempts). `rankScore` alone (item 4) shipped -
neutral-to-positive on every fixture with none of the windowed version's
downside.

A smaller reverted micro-optimization along the way: swapping
`rankScore`'s `/ 9` for a `>> 3` (divide-by-8) bit-shift, to avoid integer
division in a hot per-candidate loop. This changes calibration, not just
speed - it shifted where fresh-distance credit rounds to 2 instead of 1 for
very close distances, unbalancing the "reduces to the exact old behavior at
a repeat-offset hit" property. It also measured a small real regression on
`text.txt`. Reverted; the division stayed.

### Items not changed

- **Item 3 (modern match finder)**: already satisfied by Entry 6's
  multi-level hashing, 8-byte-anchor tier, hash chains, repeat-offset MRU
  cache, lazy matching, and `Arrays.mismatch`-based fast match extension.
  No changes made.
- **Item 7 (adaptive entropy models)**: already substantially satisfied -
  separate distance/length entropy streams, a context-split literal/
  match-flag model conditioned on the previous token's type, and a
  repeat-offset MRU side channel. Considered splitting the match/
  predict-hit marker out of the shared 258-symbol alphabet into its own
  model, but didn't attempt it given this entry's effort budget and the
  already-solid baseline - flagged as a candidate for a future entry
  rather than risked here.

### Results (six standard fixtures, median of 7 runs each)

| fixture | ratio before → after | Δratio | encodeCalls before → after | speed (median-of-7) |
|---|---|---|---|---|
| text.txt | 6.59x → 6.59x | -0.0% (noise) | 1 → 1 | 0.77x (slower - rankScore overhead, no tier reduction: already HIGH) |
| records.json | 8.64x → 8.68x | **+0.5%** | 1 → 1 | 1.34x faster |
| table.bin | 14.45x → 14.45x | **+0.0% (exact)** | **2 → 1** | **2.78x faster** |
| image.bmp | 4.07x → 4.07x | 0% | 1 → 1 | ~flat |
| executable.bin | 3.00x → 3.00x | -0.0% (noise) | 1 → 1 | 0.89x (slower, HIGH tier, rankScore overhead) |
| random.bin | 1.00x → 1.00x | 0% | 1 → 1 | 1.15x faster |

No fixture regressed in ratio. `table.bin`'s halved `encodeCalls` is the
classifier fix (1) removing a redundant trial-encode-then-promote call now
that it's correctly classified NOVA/REPETITIVE_BINARY on the first try.
`text.txt`/`executable.bin`'s modest slowdowns are both HIGH-tier fixtures
where the tier mechanism has nothing to reduce (they were already getting
full search effort) - the only thing visible on them is `rankScore`'s added
per-candidate cost, honestly reported rather than hidden. Real content is
expected to be far more heterogeneous than either of these single-region
fixtures - see the ROM's own 17.9% match share, which implies a large
fraction of it is not HIGH-tier-shaped at all.

### Classifier fix, directly

| | old classifier | new classifier | periodicity |
|---|---|---|---|
| `table.bin` window 0 | ALREADY_COMPRESSED_OR_ENCRYPTED | **REPETITIVE_BINARY** | 0.959 |
| `random.bin` window 0 | ALREADY_COMPRESSED_OR_ENCRYPTED | ALREADY_COMPRESSED_OR_ENCRYPTED (unchanged) | 0.007-0.008 |

Correctly discriminates: genuinely periodic structure crosses the
`PERIODICITY_THRESHOLD = 0.08` bar by more than 10x; genuinely random data
stays over an order of magnitude under it.

### Ablation: hints without the classifier fix

Applying (2)/(3)'s search-budget hints on top of the **unfixed** classifier
(i.e. shipping the matcher-side changes alone, without (1)):

| fixture | ratio, classifier fix + hints together | ratio, hints alone (no classifier fix) |
|---|---|---|
| table.bin | 14.45x (unaffected) | **4.63x (-68%)** |

Confirms the coupling is load-bearing, not just theoretically necessary:
`table.bin`'s segment, still misclassified ALREADY_COMPRESSED_OR_ENCRYPTED,
gets routed to MINIMAL search effort for content that's actually highly
matchable. The shipped code does not expose a way to apply one change
without the other - they land in the same commit/entry as an indivisible
unit.

### Large-input path (>1MB) and multi-segment-run sanity checks

**4MB blob** (alternating 512KB table-like/text-like regions - deliberately
uniform-HIGH-tier throughout, to isolate `rankScore`'s standalone overhead
from the tier mechanism's benefit, since a real ROM should have much more
tier variation than this):

| metric | before | after |
|---|---|---|
| ratio | 36.59x | 36.57x (-0.04%, noise) |
| compress (median-of-7) | baseline | 0.81x (~23% slower) |

Ratio-neutral, as intended, but confirms the `rankScore` overhead is real
and non-trivial when a whole large input is already HIGH-tier with no
budget-tier variation to offset it - the same effect as `text.txt`/
`executable.bin` above, just more visible at this scale. Not necessarily
representative of the real ROM (17.9% match share there implies plenty of
non-HIGH-tier content this deliberately-uniform stress test excludes by
construction).

**Heterogeneous fixture** (40 alternating 16KB text/table-like regions -
forces a long multi-segment NOVA run, to exercise change (5)):

| | compressed size | wall time | encodeCalls |
|---|---|---|---|
| before | 5,611 B | baseline | 61 |
| after, without (5) | 5,608 B | faster | 41 |
| after, with (5) | 5,608 B | **fastest** | **1** |

Change (5) costs **zero** additional bytes over "after without (5)" on this
fixture while cutting `encodeCalls` 41→1 and roughly halving wall time
again on top of the other changes - the run-length-16 threshold is doing
exactly what it's meant to here. This is one synthetic multi-region layout,
not a sweep - see "Suggested next subsystem."

### Verification

- Round-trip losslessness: byte-identical on every config × fixture this
  entry ran, at every stage of development, including the iteration that
  got reverted - see "Sandbox methodology" above.
- `NovaSegmentCodecTest.kt`'s existing single-argument `encode(data)` call,
  and the equivalent single-argument `LongRangeMatcher.tokenize(data)`
  call, both still compile and behave identically to before this entry -
  the new `hint`/`tier` parameters default to `HIGH`, this matcher's
  original unconditional behavior.
- One existing test, `NovaContainerFormatTest.kt`'s
  `promotedStoreSegmentSandwichedBetweenNovaSegmentsRoundTrips`, relied on
  the exact classifier gap change (1) fixes to construct its STORE-
  sandwiched-between-NOVA fixture (a periodic fixed-width table, the same
  shape as `table.bin`'s generator). Since it's genuinely repetitive now
  that the gap is closed, it stopped producing a STORE segment at all, and
  the test's own precondition assertion would fail loudly (by the test's
  own design - see its comment). Fixed by swapping that region for
  genuinely random bytes, which still classifies
  ALREADY_COMPRESSED_OR_ENCRYPTED under the corrected classifier and
  preserves the test's real intent (verifying the container format's
  STORE-between-NOVA handling) rather than accidentally depending on the
  bug this entry fixes. Every other existing test file was checked against
  both changes (1) and (4) and found unaffected - most construct `Region`/
  `RegionStats` directly rather than going through the classifier, or use
  fixtures (true random bytes, plain repeated text) that classify the same
  way before and after either change.
- **Not verifiable in this sandbox**: whether the four separate
  small-path tier functions (item 3 above) actually avoid a JIT-shape
  regression on Android's ART runtime specifically - only a desktop JVM
  is available here, and Entry 3's original 15-35% finding was itself
  measured on-device, not reproducible in any JVM-only sandbox either.
  This entry's Java-port numbers measure the *algorithmic* effect (fewer
  candidates examined, fewer hash operations), which should carry over
  directionally, but the *shape* of the fix (compile-time-constant
  functions rather than a parameter) is a precaution carried over from
  Entry 3's finding, not something this entry could re-confirm itself.

### Suggested next subsystem

1. **`MERGE_TRIAL_SKIP_THRESHOLD = 16`** was picked conservatively and
   validated on one synthetic multi-region layout, not swept - a real ROM-
   scale file with hundreds of segments (per the given brief's own 636-
   segment starting point) would be a much more representative test of
   both the threshold value itself and how much it's worth in aggregate
   across a whole real file rather than one 40-segment synthetic case.
2. **`rankScore`'s per-candidate overhead on already-HIGH-tier content**
   (visible on `text.txt`, `executable.bin`, and the uniform 4MB blob) is a
   real, measured cost with no offsetting ratio gain on that specific kind
   of content. It never caused a ratio regression and the coupled tier
   mechanism should dominate it on genuinely heterogeneous input, but a
   cheaper formulation that reaches the same ranking decisions with less
   arithmetic (without repeating this entry's reverted shift-based
   attempt, which changed calibration, not just cost) is worth a future
   pass specifically focused on the matcher's hot-path cost rather than
   its decisions.
3. **`SearchBudget.tierFor`'s IMAGE_LIKE/EXECUTABLE_LIKE/BINARY_UNKNOWN
   mappings** were chosen conservatively (MEDIUM rather than WEAK/MINIMAL)
   specifically because this entry's synthetic `image.bmp`/`executable.bin`
   fixtures may not be representative of real images/executables' actual
   matcher-friendliness - real-content testing could justify pushing these
   lower for more speed, or could reveal MEDIUM is already too aggressive
   for some subcategory. Untested either direction beyond the two
   synthetic fixtures this entry had.

## Entry 8: FreqModel Fenwick tree + boxing avoidance + Huffman-skip bound (entropy coding, speed only)

### Starting point

A general "improve compression ratio and speed" request, scoped down after
a full read-through of the pipeline (analyzer, segmenter, matcher,
predictor, entropy coding, container format) rather than starting from a
specific complaint. One clear bottleneck stood out: `FreqModel.update()`'s
`rebuildCum()` rewrites the *entire* cumulative-frequency array (O(alphabet))
after every single symbol - and `RangeDecoder.decodeSymbol` calls `update()`
exactly as often as the encoder does, so this cost is paid twice, once per
direction. For the 258-symbol main alphabet and millions of symbols on real
input (the GBA ROM's ~4.37M tokens per Research Mode), this measured as the
single largest CPU cost in both directions.

### Methodology

No Kotlin compiler in this sandbox, same constraint as every prior entry -
so the fix was designed and exhaustively cross-checked in a standalone Java
harness *before* being ported, rather than measured after the fact in
Kotlin like Entries 1-7 (which had at least a Python or `javac`-equivalent
full-pipeline port to measure real ratio numbers with; this entry's changes
are provably ratio-neutral instead, see below, so the harness's job was
correctness, not ratio measurement). A byte-for-byte port of the existing
array-rebuild `FreqModel` was cross-checked against a Fenwick-tree candidate
across every alphabet size this codebase actually uses (1, 2, 33, 37, 258),
driven through hundreds of thousands of `update()` calls each, checking
`total()`/`freq()`/every `cumFreqBefore()`/many `findSymbol()` targets
against each other at every single step - 1M+ operations with zero
mismatches, plus a further 4M-operation stress run at production scale with
a skewed distribution shaped like real token streams. This included
reproducing one easy-to-miss detail bit-for-bit rather than "fixing" it: the
original's `MAX_TOTAL` rescale check inside `update()` reads the *previous*
call's cached total, not the just-incremented one (a Kotlin `total()`
call reading stale `cumFreq[n]` ahead of that call's own `rebuildCum()`) -
correcting that timing instead of reproducing it would silently desync
encoder and decoder the moment their update histories differ from this
harness's test sequences.

The other two changes are provable rather than measured:
`GrowableIntArray` produces the identical `IntArray` a boxed `ArrayList<Int>`
would (same `add()`/`toIntArray()` semantics, no algorithm touched), and the
Huffman-skip bound is a Shannon entropy lower bound computed from the exact
`counts` distribution `HuffmanCoder.build` itself uses - whenever that bound
already exceeds the range coder's already-known output size, real Huffman
(which is provably no better than its own distribution's entropy bound)
cannot beat it either, so skipping the O(N) trial in that case cannot change
which coder `EntropyCoderSelector.encode` ultimately picks.

### What shipped

1. **`FreqModel`**: Fenwick tree (binary indexed tree) replacing the flat
   cumulative-frequency array. `update()`/`cumFreqBefore()` go from
   O(alphabet) to O(log alphabet); `freq()` stays O(1) (a flat array - a
   Fenwick tree exists for prefix sums, not point lookups, so keeping the
   point value in its own array is strictly better than deriving it from
   the tree). `RangeEncoder`/`RangeDecoder` updated to the new method-based
   API - a mechanical rename, no logic change.
2. **`NovaSegmentCodec`/`MatchFieldCoder`**: a new `GrowableIntArray`
   utility replaces `ArrayList<Int>` for the two hot per-symbol/per-match
   accumulation lists, avoiding a `java.lang.Integer` allocation per entry
   (the shared JVM/ART box cache only covers -128..127 - half this codec's
   own byte-value alphabet, plus both its non-byte symbols, falls outside
   it).
3. **`EntropyCoderSelector`**: skips building and running the full Huffman
   coder (an O(N) pass over every symbol, on top of the range coder's own
   O(N) pass) whenever the cheap O(alphabet) entropy-bound check above
   already proves it can't win.

### Results

On-device, seven fixtures directly comparable against the pasted
pre-Entry-8 benchmark:

| fixture | compress before→after | decompress before→after | ratio |
|---|---|---|---|
| `text.txt` | 239→213 ms (1.12x) | 62→61 ms (~flat) | 6.58x, unchanged |
| `records.json` | 148→121 ms (1.22x) | 44→34 ms (1.29x) | 8.68x, unchanged |
| `random.bin` | 848→436 ms* | 1→1 ms (flat) | 1.00x, unchanged |
| `table.bin` | 507→454 ms (1.12x) | 129→83 ms (1.55x) | 14.39x, unchanged |
| `image.bmp` | 1191→602 ms (1.98x) | 384→132 ms (**2.91x**) | 4.07x, unchanged |
| `executable.bin` | 574→528 ms (1.09x) | 222→110 ms (2.02x) | 3.00x, unchanged |
| GBA ROM (16MB) | 35,738→20,290 ms (1.76x) | 12,227→3,679 ms (**3.32x**) | 3.22x, unchanged |

\* `random.bin` is stored verbatim - it never reaches the entropy coder at
all, so this improvement can't be coming from anything in this entry;
more likely device/thermal noise between runs than a real effect.

Two fixtures appear only in the "after" run, first time benchmarked, so
have no baseline to compare: a manga MHTML file (6.4MB, 1.34x ratio,
7.8s/1.7s) and an APK (3.7MB, 1.23x ratio, 2.9s/0.34s).

Ratio is unchanged on every directly-comparable fixture, exactly as
predicted going in - this entry changes only how fast the same bytes get
computed, never what they are. The speedup scales with how much of a
file's symbol stream actually reaches the range coder: `image.bmp` (83%
prediction-hit rate per Research Mode, so nearly all 196K tokens pass
through it) sees the largest win among the small files; the GBA ROM's
3.32x decompress speedup on ~4.37M tokens is the clearest real-world
payoff and the case this entry was aimed at.

### Verdict

Kept. Zero ratio change (proven structurally, and confirmed by matching
device numbers), real and substantial speed gains that scale with
symbol-stream size, and the change is contained to `FreqModel`/
`RangeEncoder`/`RangeDecoder`/`EntropyCoderSelector` plus one new small
utility - no changes to the matcher, predictor, classifier, segmenter, or
container format.

### Suggested next subsystem

The GBA ROM's decompress time is still ~3.7s against Zstd's ~250ms on the
same file - that remaining gap is now dominated by matcher/prediction/
side-channel decode cost, not `FreqModel`. Two candidates, ranked by how
much existing evidence in this log already backs them rather than anything
new this entry is proposing:

1. **Match side-channel entropy modeling.** Every prior entry that measured
   a full byte breakdown (Entries 1, 3, 4) found the match distance/length
   side-channel is still 75-94% of total output on `text`/`json`/
   `executable` even after Entry 1's repeat-offset cache and Entry 4's
   cost-aware ranking. Entry 7 explicitly identified, but didn't attempt
   given its own effort budget, splitting the match/predict-hit marker out
   of the shared 258-symbol alphabet into its own model - this is the
   single best-evidenced remaining ratio lever anywhere in this log, not a
   new idea.
2. **Parallel decode.** Decompression is fully sequential today even though
   compression already parallelizes across chunks (see
   `NovaCompressAlgorithm`'s KDoc for why) - a compressed-length prefix per
   chunk would let a reader dispatch chunks to a thread pool the same way
   encode does. Orthogonal to (1) and a format version bump, so higher risk
   to get right blind in this sandbox than (1).

## Entry 9: split match/predict-hit marker into its own model (NovaSegmentCodec)

### Starting point

Entry 7 identified, but didn't attempt, splitting the match/predict-hit
marker out of `NovaSegmentCodec`'s shared 258-symbol alphabet into its own
model - literal byte values 0-255 currently share one adaptive frequency
table with `SYM_MATCH`(256)/`SYM_PREDICT_HIT`(257), so on match-share-heavy
or prediction-hit-heavy content those two control symbols can dominate the
table between rescales, diluting how much of the model's limited adaptation
"budget" (`FreqModel.MAX_TOTAL`, halved every ~1024 symbols) is actually
tracking real byte-value statistics.

### Methodology

Same no-compiler constraint as every entry since 8 - designed and verified
in a Java port before touching Kotlin. This one needed more of the pipeline
ported than Entry 8 did (the matcher's small-input path, the predictor, the
match field coder, `SampleDatasetGenerator`'s exact fixture recipes) since
the question this time is a real ratio question, not a provably-neutral
speed one - see the accompanying report for the full port. Two designs were
tried:

- **V1**: type stream (3-way: literal/predict-hit/match) *and* value stream
  (256-way, literal-miss bytes only) both keep the same "was the preceding
  token a match-or-predict-hit" context split the old combined scheme used.
- **V2**: same, but the type stream drops its own context split (reasoning:
  a 3-symbol decision seemed like it might not need one).

V2 was conclusively worse - a **13.7% regression on `table.bin`** alone
(its periodic fixed-stride records make one token's type a real predictor
of the next; dropping that context blinds the type stream to exactly the
structure `table.bin` has most of). V1 was the design carried forward.

V1 alone, tried unconditionally, measured close to a wash on 4 of 5
fixtures (`text` +0.04%, `json` -0.11%, `table` +0.10%, `executable`
+0.43%) and a real win on the fifth (`image.bmp` +1.78%). Given `json`'s
small regression and only five fixtures (four clustered under a 10%
predict-hit rate, one at 83%) - nowhere near enough data to calibrate a
content-classifier heuristic for when to use which scheme with any
confidence - the shipped design instead computes *both* representations
from the same token/predictor pass and keeps whichever compresses smaller,
tagging the result with which one won. This is the exact "compute both,
keep the smaller, tag which one" shape `EntropyCoderSelector` already uses
for range-vs-Huffman, one layer up. Verified this specific try-both design
(exact byte-level framing, not just the underlying scheme) round-trips
byte-identical to input across all 5 real fixtures plus edge cases: empty
input, a single byte, an all-repeated buffer (forces the matcher into one
giant match, near-zero literal misses), a no-repeats buffer (forces almost
all literals), 50KB of random fuzz, and 20 varied small mixed-content
trials - every case decoded byte-identical, and both schemes were each
observed winning on at least one real case.

### What shipped

1. New `ExternalContextRangeCoder`: range-codes a stream using a
   caller-supplied per-symbol context flag, rather than `FreqModel`
   selecting off the stream's *own* previous element the way
   `EntropyCoderSelector`'s `contextSplit` does. Needed because the value
   stream's context ("was the preceding *token*") lives in a different,
   longer sequence than the value stream itself - an arbitrary number of
   match/predict-hit tokens carrying no value-stream entry can happen
   between two consecutive value-stream entries, so a same-array lookback
   can't express it.
2. `NovaSegmentCodec.encode`: builds the combined-scheme symbol stream and
   the split-scheme type/value streams from one shared pass over the
   tokens (the matcher and predictor - the expensive parts - only run
   once regardless), entropy-codes both, keeps whichever is smaller, tags
   the result's first byte with which scheme won.
3. `NovaSegmentCodec.decode`: reads the tag byte, decodes whichever scheme
   was used. Decode only ever pays for the scheme that won, so no decode
   speed cost, unlike encode which now does pay for computing both.

No format-level field changes - `NovaEncodedBlock`'s existing `tokenCount`
field already carries everything the split scheme's decode needs; the
scheme choice lives entirely inside `entropyBytes`'s own leading byte,
mirroring how `EntropyCoderSelector` already tags its own output the same
way.

### Results

Java-port measurement, five fixtures, try-both selection active on all:

| fixture | old (combined only) | try-both result | delta | scheme picked |
|---|---|---|---|---|
| `text.txt` | 39,756 B (6.594x) | 39,742 B (6.596x) | +0.04% | split |
| `records.json` | 30,146 B (8.696x) | 30,146 B (8.696x) | 0.00% | combined (unchanged) |
| `table.bin` | 18,088 B (14.493x) | 18,070 B (14.507x) | +0.10% | split |
| `image.bmp` | 48,245 B (4.076x) | 47,386 B (4.150x) | **+1.78%** | split |
| `executable.bin` | 87,380 B (3.000x) | 87,007 B (3.013x) | +0.43% | split |

Zero regression on any fixture, by construction - `json` simply falls back
to identical-to-before output rather than costing anything.

**The important finding isn't the numbers above, it's *why* they look like
this.** Entries 1, 3, and 4 all separately measured that the match
distance/length side channel - completely untouched by this entry - is
still 75-94% of total output on `text`/`json`/`executable`. This entry only
ever touches the *other* 6-25% of those fixtures' output, so even a
meaningful improvement to that remainder shows up as a small number
overall. `image.bmp` is the outlier specifically because its match share is
only 0.1% (Research Mode) - the side channel is nearly irrelevant there,
almost the entire output *is* the part this entry touches, so the same
underlying fix reads as a 1.78% win instead of a rounding error. This entry
was Entry 7's own suggested next step, and it's real and worth having -
just not the lever that closes the gap against Bzip2/LZMA2 on prose/JSON/
compiled-code content, which is a different, larger remaining project (see
below).

Not measured: real on-device compress-time cost. Encode now genuinely does
more work (both schemes are computed in full before one is discarded,
mirroring the exact same trade `EntropyCoderSelector` already made for
range-vs-Huffman) - the matcher and predictor passes are shared and not
duplicated, but the entropy-coding stage now processes roughly 2x the
symbol volume in the worst case. Decode cost is unaffected (only the
winning scheme is ever decoded). Worth watching in the next on-device
benchmark run specifically for encode time on `image.bmp`-like content,
where the split scheme is expected to win most often.

### Verdict

Kept. Zero-regression by construction, a real win on prediction-hit-heavy
content (directly relevant to image/sprite/texture-like data), fully
round-trip verified including edge cases. Real compress-side CPU cost not
yet measured on-device - flagged above, not blocking, but worth confirming
doesn't meaningfully hurt compress speed on content where split rarely
wins.

### Suggested next subsystem

**This is the actual lever for closing the ratio gap against Bzip2/LZMA2
on `text`/`json`/`executable`-shaped content**, restated plainly now that
this entry has ruled out the alphabet-sharing hypothesis as the cause: the
match distance/length side channel, still 75-94% of total output on those
three fixture types per Entries 1/3/4, and untouched by every entry since.
Entry 1's repeat-offset cache and Entry 4's cost-aware ranking both already
worked on this same subsystem and both measurably helped - the remaining
headroom is in how the *non-repeat* distances and lengths get entropy-coded
once picked: `MatchFieldCoder` currently writes each one as an adaptively-
coded "slot" symbol plus *raw, uncoded* extra bits (see that class's KDoc
for why - the extra bits were assumed close to uniform within a slot). That
assumption is exactly the next thing worth testing with real byte-frequency
data from a Java port: if the low few extra bits *aren't* uniform on real
match-distance data (plausible - LZMA's own format models exactly this
with a small "align" context on the low 4 bits of long distances), a cheap
context model over just those bits, same shape as this entry's
`ExternalContextRangeCoder`, could recover real ratio on the actual
majority of `text`/`json`/`executable`'s output, rather than the small
remainder Entry 9 worked on.

## Entry 10: gate Entry 9's split-scheme trial on predict-hit share

### Starting point

Entry 9 shipped with an explicit caveat: real on-device compress-time cost
of always computing both entropy schemes hadn't been measured, only ratio.
The very next benchmark run supplied that data, and it was worse than
expected: `image.bmp` +14% compress time (expected - it's where the split
scheme wins and both get computed in full), but also GBA ROM +14%,
`records.json` roughly flat, and `synthetic_random.bin` **+59%** - all for
0% to 0.1% ratio gain, since none of those fixtures' predict-hit share is
anywhere near what makes the split scheme worth trying.

### Methodology

The same run that supplied the compress-time data also validated Entry 9's
ratio predictions closely: `image.bmp` predicted +1.78%, measured +1.72%;
`executable.bin` predicted +0.43%, measured +0.67%; `table.bin` predicted
+0.10%, measured +0.07%; `text`/`json` predicted ~0%, measured ~0%. With
that confirmation in hand, plus three more real fixtures now benchmarked
(GBA ROM, manga MHTML, an APK - none of which were in Entry 9's 5-fixture
Java-port testing), there were 8 real predict-hit-share data points instead
of 5, all clustering the same way Entry 9 already suspected: seven fixtures
between 0.6% and 7.2% hit share (text 0.7%, table 2.1%, executable 1.3%,
GBA ROM 3.9%, MHTML 0.6%, APK 4.4%, json 7.2%), one fixture at 82.9%
(`image.bmp`) - and ratio gain from trying the split scheme tracks that
same split almost exactly (0% to +0.1% for the low cluster, +1.7% for the
outlier).

A threshold at 20% hit share sits with a ~3x margin below the low cluster's
ceiling (7.2%) and a ~4x margin above it to `image.bmp`'s 82.9% - not a
tight fit to 8 points, comfortable headroom on both sides. Verified in the
same Java harness Entry 9 used, gate added: all 5 fixtures plus every edge
case (empty, single byte, all-match, all-literal, incompressible fuzz, 20
mixed small-file trials) still round-trip byte-identical, and the gate
picks exactly the expected path per fixture - `image.bmp` still takes
`SCHEME_SPLIT`, all 4 other real fixtures and every edge case take
`SCHEME_COMBINED` directly without ever building or entropy-coding the type/
value streams.

### What shipped

`NovaSegmentCodec.encode` now checks `hitCount / tokenCount` against
`SPLIT_TRIAL_MIN_PREDICT_HIT_SHARE` (0.20) right after the shared matcher/
predictor pass (which always runs regardless - it's what produces
`hitCount` in the first place, and both schemes need its output either
way). Below the threshold, `entropyBytes` is built directly from the
already-computed combined-scheme bytes, skipping the `typeArray`/
`valueArray` construction, both streams' entropy coding, and the size
comparison entirely. At or above it, behavior is unchanged from Entry 9 -
compute both, keep the smaller.

This can only ever *forgo* a near-zero ratio gain on a fixture that was
never going to benefit much anyway - it can't cost one: the combined-scheme
path taken below the threshold is exactly Entry 8's already-shipped,
already-verified output, unchanged.

### Results

No new on-device numbers yet (that's what the next benchmark run will
show) - expected outcome, from the data above: `image.bmp` unaffected
(still takes the split path, same +1.7% ratio, same compress-time cost as
Entry 9 measured), every other fixture's ratio reverts to exactly Entry 8's
numbers (giving up `table.bin`'s +0.07% and `executable.bin`'s +0.67%,
both now judged not worth their compress-time cost), and compress time on
the previously-costly cases (`random.bin`, GBA ROM, and by the same logic
any other low-hit-share content) should drop back toward Entry 8's numbers
since the expensive trial no longer runs for them.

### Verdict

Kept, pending the next on-device run confirming the predicted compress-time
recovery. Ratio-safe by construction (the gated-out path is Entry 8's
verified output, not new code), and the trade it makes explicit -
`table.bin`/`executable.bin` giving up sub-1% ratio gains in exchange for
recovering real, measured double-digit-percent compress time on GBA-ROM/
random-data-shaped content - is the right one for a mobile CI build
pipeline where compress time is a directly-felt cost and a sub-1% ratio
difference on two fixtures isn't.

### Suggested next subsystem

Unchanged from Entry 9: the match distance/length side channel, still
75-94% of total output on `text`/`json`/`executable` and untouched since
Entry 4. `MatchFieldCoder` writes fresh (non-repeat-offset) distances and
lengths as an adaptively-coded slot symbol plus *raw, uncoded* extra bits -
worth testing with real byte-frequency data whether those extra bits are
actually close to uniform the way that design assumes, since if they're
not (plausible - LZMA's own format models exactly this with a small
"align" context on distances' low bits), that's real recoverable ratio on
the majority of these fixtures' output, not the small remainder the last
two entries worked on.


