package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.entropy.EntropyCoderSelector
import com.novacompress.bench.novacompress.entropy.ExternalContextRangeCoder
import com.novacompress.bench.novacompress.entropy.MatchFieldCoder
import com.novacompress.bench.novacompress.matcher.LongRangeMatcher
import com.novacompress.bench.novacompress.matcher.Token
import com.novacompress.bench.novacompress.predictor.ContextPredictor
import com.novacompress.bench.novacompress.util.GrowableIntArray
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Result of encoding one buffer. [tokenCount]/[matchTokenCount]/[predictHitCount]
 * are pure by-products of the encode pass, kept for Research Mode reporting
 * (detected-structure counts, prediction accuracy) rather than recomputed
 * separately. [symbolCount] is only meaningful when [entropyBytes] turned
 * out to use the combined scheme - see "Split entropy scheme" below; when
 * the split scheme wins, [tokenCount] alone is enough for [decode] to know
 * how many type symbols to read back, and the value-stream length falls
 * out of decoding those.
 */
data class NovaEncodedBlock(
    val symbolCount: Int,
    val entropyBytes: ByteArray,
    val sideChannelBytes: ByteArray,
    val tokenCount: Int,
    val matchTokenCount: Int,
    val predictHitCount: Int,
)

/**
 * Encodes/decodes ONE contiguous buffer (a segment, or several segments
 * concatenated - see [NovaCompressAlgorithm] for why buffer size varies
 * between sequential and parallel mode) through the full pipeline:
 * long-range matching -> order-2 prediction -> entropy coding.
 *
 * Verified via 30 end-to-end round-trip tests (edge cases, random/skewed/
 * repetitive/JSON-like/fuzzed data, and a case specifically constructed to
 * make Huffman beat the range coder) before being ported into this
 * codebase - see README "Verification".
 *
 * The critical correctness invariant: [ContextPredictor] must be updated
 * with *every* reconstructed byte - literal misses, prediction hits, AND
 * every byte a match token copies - so encoder and decoder stay in
 * lockstep. This is the one thing to be most careful about if this file is
 * ever modified; NovaSegmentCodecTest exists specifically to catch a
 * regression here.
 *
 * Match distance/length go through [MatchFieldCoder], not raw bytes - see
 * that class for why. [ContextPredictor]'s state depends only on
 * reconstructed byte values, not on how a match's distance/length were
 * transmitted, so this change is invisible to it.
 *
 * ## Split entropy scheme (BENCHMARKS.md Entry 9)
 *
 * [encode] builds two independent representations of the *same* token
 * pass and keeps whichever compresses smaller, tagging [entropyBytes]'s
 * first byte with which one was used - the exact same "compute both, keep
 * the smaller, tag which one" shape [EntropyCoderSelector] already uses
 * for range-vs-Huffman, just one layer up:
 *
 *  - **[SCHEME_COMBINED]**: the original design - one flat stream where
 *    [SYM_MATCH]/[SYM_PREDICT_HIT] share a 258-symbol alphabet with literal
 *    byte values 0-255.
 *  - **[SCHEME_SPLIT]**: the match/predict-hit marker gets its own 3-symbol
 *    "type" stream (LITERAL/PREDICT_HIT/MATCH), and literal byte values
 *    that actually need transmitting go in a separate 256-symbol "value"
 *    stream containing *only* those bytes - no longer sharing frequency-
 *    table space with two control symbols that, on match-share-heavy
 *    content, can dwarf the real byte-value counts between rescales.
 *    Both streams keep the same "was the immediately preceding token a
 *    match-or-predict-hit" context split the combined scheme used (see
 *    [TYPE_CONTEXT_SPLIT]) - dropping it from the type stream alone was
 *    tried and measured a 13.7% *regression* on `table.bin` (its periodic
 *    record structure makes one token's type a real predictor of the
 *    next), so both streams keep it. The value stream can't reuse
 *    [EntropyCoderSelector]'s own `contextSplit` for this the way the type
 *    stream does, since its context - "was the preceding *token*", not
 *    "was the preceding *value-stream entry*" - lives in a different,
 *    longer sequence than the value stream itself; see
 *    [ExternalContextRangeCoder].
 *
 * Measured on this pass's 5 synthetic fixtures (Java-port testing, see
 * BENCHMARKS.md Entry 9 for the full numbers): a clear, real win on
 * prediction-hit-dominated content (+1.78% on `image.bmp`, whose 83%
 * predict-hit rate is exactly the dilution case above), and roughly noise-
 * level everywhere else (-0.11% to +0.43%) - unsurprising once measured
 * *why*: on `text`/`json`/`executable`, the match distance/length side
 * channel this doesn't touch is still 75-94% of total output (Entries 1,
 * 3, 4), so there's only ever a small remainder here for this change to
 * improve regardless of how well it does its job. Trying both schemes
 * unconditionally rather than picking one via a classifier heuristic was a
 * deliberate choice: five fixtures (four clustered under a 10% predict-hit
 * rate, one at 83%) isn't enough data to calibrate a threshold with any
 * confidence, and getting it wrong either way would cost real ratio on
 * whichever fixtures fell on the wrong side - trying both costs some
 * compress-side CPU (decode only ever runs the winning scheme, so no cost
 * there) but can't regress ratio by construction, the same trade
 * [EntropyCoderSelector] already made for the same reason.
 */
object NovaSegmentCodec {
    const val SYM_MATCH = 256
    const val SYM_PREDICT_HIT = 257
    const val ALPHABET = 258

    private const val SCHEME_COMBINED = 0
    private const val SCHEME_SPLIT = 1

    private const val TYPE_LITERAL = 0
    private const val TYPE_PREDICT_HIT = 1
    private const val TYPE_MATCH = 2
    private const val TYPE_ALPHABET = 3

    /** Previous token type >= this means "was PREDICT_HIT or MATCH" - the
     *  same direction/meaning [SYM_MATCH] played as the combined scheme's
     *  `contextSplit`, just expressed in the type stream's own 3-symbol
     *  alphabet instead of the flat 258-symbol one. */
    private const val TYPE_CONTEXT_SPLIT = TYPE_PREDICT_HIT

    private const val VALUE_ALPHABET = 256

    /** Below this predict-hit share of tokens, don't bother computing the split scheme at all -
     *  see the gate at its call site in [encode] and BENCHMARKS.md Entry 10 for the on-device data
     *  behind this number: every real fixture tested under ~8% hit share gained 0% to +0.1% ratio
     *  from trying the split scheme anyway, while `image.bmp` at 83% gained +1.7%. Comfortable
     *  margin on both sides of the observed data, not a tightly-fit cutoff. */
    private const val SPLIT_TRIAL_MIN_PREDICT_HIT_SHARE = 0.20

    /** [hint] defaults to [SearchBudget.Tier.HIGH] (the matcher's original, unconditional
     *  behavior) for any caller that doesn't pass one - see [SearchBudget]'s KDoc. */
    fun encode(data: ByteArray, hint: SearchBudget.Tier = SearchBudget.Tier.HIGH): NovaEncodedBlock {
        val tokens = LongRangeMatcher.tokenize(data, hint)
        val predictor = ContextPredictor()

        // Combined-scheme stream (kept exactly as before) and split-scheme streams, built
        // together in one pass over the same tokens/predictor calls - see class KDoc "Split
        // entropy scheme". Sharing this one pass matters: the matcher and predictor are the
        // expensive parts of encode, and computing two *entropy-coded representations* of their
        // output is far cheaper than computing that output twice.
        val symbols = GrowableIntArray(data.size / 2 + 8)
        val types = GrowableIntArray(tokens.size)
        val values = GrowableIntArray()
        val valueContextFlags = GrowableIntArray() // 0/1 per value-stream entry; see below for why not BooleanArray directly

        val distances = MatchFieldCoder.FieldWriter(repSlots = MatchFieldCoder.DIST_REPEAT_SLOTS)
        val lengths = MatchFieldCoder.FieldWriter()

        var prevPrev = 0
        var prev = 0
        var pos = 0
        var matchCount = 0
        var hitCount = 0
        var prevTokenWasHi = false

        for (t in tokens) {
            val type: Int
            when (t) {
                is Token.Literal -> {
                    val b = t.byte
                    val predicted = predictor.predict(data, pos, prevPrev, prev)
                    if (predicted == b) {
                        symbols.add(SYM_PREDICT_HIT)
                        type = TYPE_PREDICT_HIT
                        hitCount++
                    } else {
                        symbols.add(b.toInt() and 0xFF)
                        type = TYPE_LITERAL
                        values.add(b.toInt() and 0xFF)
                        valueContextFlags.add(if (prevTokenWasHi) 1 else 0)
                    }
                    predictor.update(data, pos, prevPrev, prev, b)
                    prevPrev = prev
                    prev = b.toInt() and 0xFF
                    pos++
                }
                is Token.Match -> {
                    symbols.add(SYM_MATCH)
                    type = TYPE_MATCH
                    matchCount++
                    distances.write(t.distance)
                    // Rebased so the most common length (exactly MIN_MATCH)
                    // lands on slot 0, the cheapest code - see MatchFieldCoder.
                    lengths.write(t.length - LongRangeMatcher.MIN_MATCH)
                    for (k in 0 until t.length) {
                        val b = data[pos + k]
                        predictor.update(data, pos + k, prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                    }
                    pos += t.length
                }
            }
            types.add(type)
            prevTokenWasHi = type >= TYPE_CONTEXT_SPLIT
        }

        val symbolArray = symbols.toIntArray()
        val combinedEntropy = EntropyCoderSelector.encode(symbolArray, ALPHABET, contextSplit = SYM_MATCH)

        fun wrapCombined(): ByteArray = ByteArrayOutputStream().also { out ->
            DataOutputStream(out).use { d ->
                d.writeByte(SCHEME_COMBINED)
                d.write(combinedEntropy)
            }
        }.toByteArray()

        // Real on-device data (BENCHMARKS.md Entry 10) confirmed the split scheme only wins on
        // high-predict-hit-rate content (image.bmp: 83% hit share, +1.7% ratio) - every other real
        // fixture tested (text/json/table/executable/GBA ROM/manga MHTML/APK, hit shares 0.6-7.2%)
        // gained 0% to +0.1%, while still paying real compress-time cost for the always-computed
        // trial (up to +59% on incompressible content, +14% on the GBA ROM, for zero ratio gain on
        // both). Below the threshold, skip building/entropy-coding the split streams entirely and
        // emit the combined scheme directly - this can only ever forgo a near-zero ratio gain, never
        // cost one: the combined scheme is exactly what Entry 8 already shipped and verified.
        val predictHitShare = if (tokens.isEmpty()) 0.0 else hitCount.toDouble() / tokens.size
        val entropyBytes = if (predictHitShare < SPLIT_TRIAL_MIN_PREDICT_HIT_SHARE) {
            wrapCombined()
        } else {
            val typeArray = types.toIntArray()
            val valueArray = values.toIntArray()
            // GrowableIntArray (0/1) -> BooleanArray via a primitive-only conversion - avoids ever
            // boxing a Boolean per value-stream entry, same reasoning as GrowableIntArray itself
            // (see that class's KDoc); a value-stream entry exists for every literal miss, which for
            // large low-prediction-accuracy inputs can be millions of entries.
            val contextInts = valueContextFlags.toIntArray()
            val valueContext = BooleanArray(contextInts.size) { contextInts[it] != 0 }

            val typeEntropy = EntropyCoderSelector.encode(typeArray, TYPE_ALPHABET, contextSplit = TYPE_CONTEXT_SPLIT)
            val valueEntropy = ExternalContextRangeCoder.encode(valueArray, valueContext, VALUE_ALPHABET)

            if (typeEntropy.size + valueEntropy.size < combinedEntropy.size) {
                ByteArrayOutputStream().also { out ->
                    DataOutputStream(out).use { d ->
                        d.writeByte(SCHEME_SPLIT)
                        d.writeInt(typeEntropy.size)
                        d.write(typeEntropy)
                        d.writeInt(valueEntropy.size)
                        d.write(valueEntropy)
                    }
                }.toByteArray()
            } else {
                wrapCombined()
            }
        }

        return NovaEncodedBlock(
            symbolCount = symbolArray.size,
            entropyBytes = entropyBytes,
            sideChannelBytes = MatchFieldCoder.pack(distances, lengths),
            tokenCount = tokens.size,
            matchTokenCount = matchCount,
            predictHitCount = hitCount,
        )
    }

    fun decode(block: NovaEncodedBlock, originalLength: Int): ByteArray {
        val fields = MatchFieldCoder.unpack(block.sideChannelBytes, block.matchTokenCount, LongRangeMatcher.MIN_MATCH)
        val output = ByteArray(originalLength)
        val predictor = ContextPredictor()
        var matchIndex = 0
        var prevPrev = 0
        var prev = 0
        var pos = 0

        val scheme = block.entropyBytes[0].toInt() and 0xFF
        val din = DataInputStream(ByteArrayInputStream(block.entropyBytes, 1, block.entropyBytes.size - 1))

        if (scheme == SCHEME_COMBINED) {
            val body = ByteArray(block.entropyBytes.size - 1)
            din.readFully(body)
            val symbols = EntropyCoderSelector.decode(body, block.symbolCount, ALPHABET, contextSplit = SYM_MATCH)

            for (sym in symbols) {
                when (sym) {
                    SYM_PREDICT_HIT -> {
                        val b = predictor.predict(output, pos, prevPrev, prev)
                        output[pos] = b
                        predictor.update(output, pos, prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                        pos++
                    }
                    SYM_MATCH -> {
                        val dist = fields.distances[matchIndex]
                        val len = fields.lengths[matchIndex]
                        matchIndex++
                        for (k in 0 until len) {
                            val b = output[pos - dist]
                            output[pos] = b
                            predictor.update(output, pos, prevPrev, prev, b)
                            prevPrev = prev
                            prev = b.toInt() and 0xFF
                            pos++
                        }
                    }
                    else -> {
                        val b = sym.toByte()
                        output[pos] = b
                        predictor.update(output, pos, prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                        pos++
                    }
                }
            }
        } else {
            val typeLen = din.readInt()
            val typeBytes = ByteArray(typeLen).also { din.readFully(it) }
            val valueLen = din.readInt()
            val valueBytes = ByteArray(valueLen).also { din.readFully(it) }

            val typeSymbols = EntropyCoderSelector.decode(typeBytes, block.tokenCount, TYPE_ALPHABET, contextSplit = TYPE_CONTEXT_SPLIT)

            // Same context-derivation walk encode() did, over the now-decoded type stream - both
            // sides compute this identically from state they already agree on, so no need to
            // transmit it separately. See class KDoc "Split entropy scheme".
            var literalCount = 0
            for (type in typeSymbols) if (type == TYPE_LITERAL) literalCount++
            val valueContext = BooleanArray(literalCount)
            var prevTokenWasHi = false
            var vc = 0
            for (type in typeSymbols) {
                if (type == TYPE_LITERAL) {
                    valueContext[vc] = prevTokenWasHi
                    vc++
                }
                prevTokenWasHi = type >= TYPE_CONTEXT_SPLIT
            }
            val valueSymbols = ExternalContextRangeCoder.decode(valueBytes, valueContext, VALUE_ALPHABET)

            var valueIndex = 0
            for (type in typeSymbols) {
                when (type) {
                    TYPE_PREDICT_HIT -> {
                        val b = predictor.predict(output, pos, prevPrev, prev)
                        output[pos] = b
                        predictor.update(output, pos, prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                        pos++
                    }
                    TYPE_MATCH -> {
                        val dist = fields.distances[matchIndex]
                        val len = fields.lengths[matchIndex]
                        matchIndex++
                        for (k in 0 until len) {
                            val b = output[pos - dist]
                            output[pos] = b
                            predictor.update(output, pos, prevPrev, prev, b)
                            prevPrev = prev
                            prev = b.toInt() and 0xFF
                            pos++
                        }
                    }
                    else -> { // TYPE_LITERAL
                        val b = valueSymbols[valueIndex].toByte()
                        valueIndex++
                        output[pos] = b
                        predictor.update(output, pos, prevPrev, prev, b)
                        prevPrev = prev
                        prev = b.toInt() and 0xFF
                        pos++
                    }
                }
            }
        }
        return output
    }
}
