# frame-pacer-test

Host-side tests for `app/src/main/kotlin/com/mgba/android/pacing/` — the pure-Kotlin part of "the game loop stays at
the right speed": the wall-clock fallback for iterations the audio write did not pace (`FallbackFramePacer`) and the
per-speed planning of each iteration, including slow motion (`SpeedPlanner`, `SlowMotionAudio`). They need only a Kotlin compiler (`kotlinc`, any 1.9+ / 2.x)
and a JDK 17+; no Android, no Gradle, no JUnit.

```
KOTLINC=/path/to/kotlinc/bin/kotlinc ./run.sh      # prints "ALL <n> CHECKS PASSED", exit code 1 on any failure
```

`run.sh` compiles the **real** `pacing/*.kt` next to `FramePacerTest.kt`, so a test cannot drift from the shipping
code. Time is a virtual clock (`LoopSim`), so a run is deterministic and takes milliseconds however many seconds of game
time it covers; a `Thread.sleep` that wakes late is modelled with a seeded random overshoot.

| section | what it pins down |
|---|---|
| audio-paced iteration | no wait whatever the clock says |
| schedule start | a fallback schedule starts at its own iteration's start, so time already spent (the emulation, a write that blocked before giving up) counts toward its budget |
| steady state, no drift | every iteration waits out the rest of its frame; 6000 frames with late wake-ups still end at the real GBA rate (within 0.02%) |
| falling behind | a short stumble is repaid and the long-run schedule kept; a long stall (more than `maxLagNs`) is given up instead of played back as a burst; the exact threshold |
| speed and frames | the budget is per emulated frame (`frames / speed`): batches at 2x / 4x / 16x, 0.5x, fractional speeds, a device too slow for the speed runs flat out; bad input (speed 0, negative or NaN; 0 frames) never becomes an endless sleep |
| hand-over | audio -> fallback -> audio: no stale deadline and no burst; the game speed holds through an outage and the recovery |
| clock wrap | a clock that wraps around mid-run changes nothing |
| speed planner | at 1x and above whole frames averaging exactly the selected speed (1.5x alternates 1 and 2), never fewer than one; 0.5x is one frame per iteration with its audio stretched 2x; the "debt" the old accumulator built up below 1x is gone (4x runs 4 frames on the first iteration after minutes of 0.5x); zero / negative / NaN / infinite speeds are sanitised; `reset()` |
| slow-motion audio | `SlowMotionAudio.stretch()`: length `round(n x factor)`, first and last pair preserved, factor 2 = midpoints, constants stay constant, a tone comes out an octave lower, channels independent, never past the destination, full-scale input does not wrap; `writeStretched()`: the stretched clip reaches the AudioTrack write whole, in order, in buffer-sized pieces, the first refused piece ends the frame and reports "not paced", factor <= 1 is one plain write |
| audio-paced loop model | built from the real planner and writer with the real buffer sizes: every speed 0.5x..16x runs at that speed within 0.5% (and 0.5x without the stretch runs at 1x — the old defect, visible to the model); fallback-paced 0.5x; 0.5x through an audio outage and recovery |
| wiring | a source check of `MainActivityRender.kt` / `MainActivityAudio.kt` / `MainActivity.kt`: one `plan()` per iteration, the pacer gets the planner's speed, both single-frame writes go through `writeFramePcm()`, the fast-forward batch does not, the old accumulator is gone, the buffer sizes the model assumes |

A mutation check (breaking the logic on purpose, one change at a time, and confirming a test fails) was used while
writing these — 13 breakages of the pacer (pass 10) and 20 of the planner, the audio stretch and its writer, and the
loop wiring (pass 12), all caught; a change to `pacing/` should keep every section meaningful the same way.

What this does **not** cover: the Android classes themselves. `writePcm()` returning whether it paced and the loop
calling the pacer need the Android SDK; the "wiring" section only checks the source text for them (it cannot see a
change that keeps the text and breaks the meaning — which is why the audio write step lives in
`SlowMotionAudio.writeStretched()`, where it is tested as code). For pass 10 those functions were also compiled
against stand-ins and run against a simulated audio device, as a one-off — see `CHANGELOG.md`.
