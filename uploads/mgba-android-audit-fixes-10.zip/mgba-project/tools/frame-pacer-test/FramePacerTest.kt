package com.mgba.android.pacing

import java.io.File
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.system.exitProcess

// Host-side tests for app/src/main/kotlin/com/mgba/android/pacing/FallbackFramePacer.kt — the wall-clock pacer the
// game loop falls back on when the blocking AudioTrack write did not pace it (no track, a failed or zero-progress
// write, a frame with no audio). run.sh compiles the REAL source next to this file, so a test cannot drift from the
// shipping code. No Android, no JUnit: a tiny assert harness and a virtual clock, so the run is deterministic and takes
// milliseconds however many "seconds" of game time it covers.

private var checks = 0
private val failures = ArrayList<String>()

private fun check(cond: Boolean, what: String) {
    checks++
    if (!cond) { failures += what; println("  FAIL: $what") }
}

private fun <T> checkEq(actual: T, expected: T, what: String) =
    check(actual == expected, "$what — expected <$expected> but was <$actual>")

private fun checkNear(actual: Long, expected: Long, tolNs: Long, what: String) =
    check(abs(actual - expected) <= tolNs, "$what — expected <$expected> ±$tolNs ns but was <$actual>")

private fun checkRate(actual: Double, expected: Double, relTol: Double, what: String) =
    check(abs(actual - expected) <= expected * relTol, "$what — expected <$expected> ±${relTol * 100}% but was <$actual>")

private fun section(name: String) = println("• $name")

private const val MS = 1_000_000L
private const val MAX_LAG = 100_000_000L
// The same arithmetic as FALLBACK_FRAME_NS in MainActivityShared.kt: the GBA's real frame period (~16.74 ms), not 1/60 s.
private val FRAME = 280_896L * 1_000_000_000L / 16_777_216L
private val FRAME_RATE = 1e9 / FRAME   // ~59.7275 frames per second

/**
 * A virtual clock driving the pacer the way the game thread does: run the frame(s), maybe block in the audio write,
 * ask the pacer, sleep for what it says. [maxOvershootNs] models Thread.sleep waking up late by up to that much.
 */
private class LoopSim(
    val pacer: FallbackFramePacer = FallbackFramePacer(FRAME, MAX_LAG),
    var now: Long = 1_000_000_000L,
    private val rng: Random? = null,
    private val maxOvershootNs: Long = 0L
) {
    val startedAt = now
    var frames = 0L

    /** One loop iteration; returns the wait the pacer asked for. */
    fun iteration(
        computeNs: Long,
        framesRun: Int = 1,
        speed: Float = 1f,
        audioPaced: Boolean = false,
        audioBlockNs: Long = 0L
    ): Long {
        val start = now
        now += computeNs + audioBlockNs
        val wait = pacer.waitNs(audioPaced, start, now, framesRun, speed)
        if (wait > 0L) {
            now += wait
            if (rng != null && maxOvershootNs > 0L) now += (rng.nextDouble() * maxOvershootNs).toLong()
        }
        frames += framesRun
        return wait
    }

    val elapsedNs: Long get() = now - startedAt
    val rate: Double get() = frames * 1e9 / elapsedNs   // emulated frames per second of game time
}

// ── tests ───────────────────────────────────────────────────────────────────────────────────────────────────────

private fun audioPacedIterations() {
    section("audio-paced iteration: no wait, whatever the clock says")
    val p = FallbackFramePacer(FRAME, MAX_LAG)
    checkEq(p.waitNs(true, 0L, 0L, 1, 1f), 0L, "no time used")
    checkEq(p.waitNs(true, 0L, 1 * MS, 1, 1f), 0L, "1 ms used")
    checkEq(p.waitNs(true, 0L, 500 * MS, 4, 4f), 0L, "a very long iteration")
}

private fun scheduleStartsAtTheIterationStart() {
    section("a fallback schedule starts at its own iteration's start, so time already spent counts")
    val start = 5_000_000_000L
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start + 3 * MS, 1, 1f), FRAME - 3 * MS,
        "3 ms of emulation → wait out the rest of the frame")
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start + 12 * MS, 1, 1f), FRAME - 12 * MS,
        "an audio write that blocked ~10 ms before giving up (paused track) is not waited out a second time")
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start + 20 * MS, 1, 1f), 0L,
        "already past the frame period → no wait at all")
    checkEq(FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, start, start, 1, 1f), FRAME,
        "nothing used yet → a whole frame period")
}

private fun steadyState() {
    section("steady state: every iteration waits exactly the rest of its frame")
    val sim = LoopSim()
    var allEqual = true
    repeat(200) { if (sim.iteration(3 * MS) != FRAME - 3 * MS) allEqual = false }
    check(allEqual, "200 iterations of 3 ms emulation each wait FRAME - 3 ms")
    checkNear(sim.elapsedNs, 200 * FRAME, 2L, "200 frames take 200 frame periods")
}

private fun noDriftFromLateSleeps() {
    section("sleeps that wake late are paid back, not accumulated as drift")
    val sim = LoopSim(rng = Random(12345), maxOvershootNs = 1_500_000L)   // every sleep wakes 0-1.5 ms late
    val rng = Random(99)
    repeat(6000) { sim.iteration(computeNs = 1 * MS + (rng.nextDouble() * 3 * MS).toLong()) }   // 1-4 ms of emulation
    checkRate(sim.rate, FRAME_RATE, 0.0002, "6000 frames (~100 s) run at the real GBA rate to within 0.02%")
}

private fun fallingBehind() {
    section("a short stumble is repaid, the long-run schedule is kept")
    run {
        val sim = LoopSim()
        val s = sim.now
        sim.iteration(3 * MS)                                 // on schedule
        checkEq(sim.iteration(40 * MS), 0L, "one slow frame (40 ms) → no sleep while behind")
        checkEq(sim.iteration(3 * MS), 0L, "still behind → still no sleep")
        val catchUp = sim.iteration(3 * MS)
        check(catchUp in 1 until FRAME - 3 * MS, "the iteration that closes the gap only waits for the remainder (was $catchUp)")
        checkEq(sim.iteration(3 * MS), FRAME - 3 * MS, "back to a normal wait")
        checkNear(sim.now - s, 5 * FRAME, 2L, "5 iterations ended exactly 5 frame periods after the start — nothing lost, nothing gained")
    }

    section("a long stall is given up, not played back as a burst")
    run {
        val sim = LoopSim()
        sim.iteration(3 * MS)
        checkEq(sim.iteration(500 * MS), 0L, "a 500 ms stall → no sleep")
        var burst = false
        repeat(30) { if (sim.iteration(2 * MS) < FRAME - 3 * MS) burst = true }
        check(!burst, "afterwards every frame is paced again (no run of unthrottled frames winning the 500 ms back)")
    }

    section("the give-up threshold: exactly MAX_LAG behind is repaid, one ns more is given up")
    run {
        // Late by `lag` at the end of the first iteration; the second iteration takes no time, so its wait shows
        // whether the schedule was kept (the lag still has to be repaid → 0) or restarted (a whole frame period).
        fun secondWait(lag: Long): Long {
            val p = FallbackFramePacer(FRAME, MAX_LAG)
            val s = 7_000_000_000L
            val end = s + FRAME + lag
            p.waitNs(false, s, end, 1, 1f)
            return p.waitNs(false, end, end, 1, 1f)
        }
        checkEq(secondWait(MAX_LAG), 0L, "lag == MAX_LAG: schedule kept")
        checkEq(secondWait(MAX_LAG + 1), FRAME, "lag == MAX_LAG + 1: schedule restarted from now")
    }
}

private fun speedAndFrames() {
    section("speed and frame count: the budget is per emulated frame")
    fun budget(frames: Int, speed: Float): Long {
        val s = 1_000_000_000L
        return FallbackFramePacer(FRAME, MAX_LAG).waitNs(false, s, s, frames, speed)
    }
    checkNear(budget(1, 1f), FRAME, 1L, "1 frame at 1x")
    checkNear(budget(1, 2f), FRAME / 2, 1L, "1 frame at 2x")
    checkNear(budget(2, 2f), FRAME, 1L, "a 2-frame batch at 2x takes one frame period (not a quarter of one)")
    checkNear(budget(4, 4f), FRAME, 1L, "a 4-frame batch at 4x takes one frame period")
    checkNear(budget(16, 16f), FRAME, 1L, "a 16-frame batch at 16x takes one frame period")
    checkNear(budget(24, 16f), FRAME * 3 / 2, 1L, "24 frames at 16x")
    checkNear(budget(1, 0.5f), 2 * FRAME, 1L, "1 frame at 0.5x takes two frame periods")
    checkNear(budget(3, 1f), 3 * FRAME, 1L, "3 frames at 1x take three frame periods")

    section("bad input never turns into an endless sleep")
    checkNear(budget(1, 0f), FRAME, 1L, "speed 0 is treated as 1x")
    checkNear(budget(1, -3f), FRAME, 1L, "negative speed is treated as 1x")
    checkNear(budget(1, Float.NaN), FRAME, 1L, "NaN speed is treated as 1x")
    check(budget(1, Float.POSITIVE_INFINITY) in 0L..1L, "infinite speed waits for nothing")
    checkNear(budget(0, 1f), FRAME, 1L, "0 frames counts as 1")
    checkNear(budget(-5, 1f), FRAME, 1L, "negative frames counts as 1")
    check(budget(Int.MAX_VALUE, 1f) > 0L, "absurd frame counts do not overflow into a negative wait")
}

private fun fractionalFastForward() {
    section("fast-forward at a fractional speed: batches of 1 and 2 frames average out to the selected speed")
    val sim = LoopSim(rng = Random(5), maxOvershootNs = 500_000L)
    var i = 0
    repeat(3000) { sim.iteration(computeNs = 1 * MS, framesRun = if (i++ % 2 == 0) 1 else 2, speed = 1.5f) }
    checkRate(sim.rate, FRAME_RATE * 1.5, 0.0005, "1.5x runs at 1.5 times the real GBA rate")

    section("fast-forward 4x as 4-frame batches")
    val ff = LoopSim(rng = Random(6), maxOvershootNs = 500_000L)
    repeat(3000) { ff.iteration(computeNs = 6 * MS, framesRun = 4, speed = 4f) }
    checkRate(ff.rate, FRAME_RATE * 4, 0.0005, "4x runs at 4 times the real GBA rate")

    section("a device too slow for the selected speed runs flat out instead of piling up debt")
    val slow = LoopSim()
    repeat(200) { slow.iteration(computeNs = 40 * MS, framesRun = 4, speed = 4f) }   // 4 frames need 40 ms; 4x allows 16.7
    checkNear(slow.elapsedNs, 200 * 40 * MS, 1L, "no sleeping at all while the schedule cannot be met")
}

private fun audioComesAndGoes() {
    section("audio pacing and the fallback hand over cleanly (no stale deadline, no burst)")
    run {
        val sim = LoopSim()
        repeat(10) { sim.iteration(2 * MS) }                                   // fallback
        repeat(3) { sim.iteration(2 * MS, audioPaced = true, audioBlockNs = FRAME - 2 * MS) }   // audio paced three frames
        checkEq(sim.iteration(2 * MS), FRAME - 2 * MS,
            "first fallback iteration after audio paced: a fresh schedule, not a deadline left over from before")
    }
    run {
        val sim = LoopSim()
        repeat(10) { sim.iteration(2 * MS) }
        repeat(300) { sim.iteration(2 * MS, audioPaced = true, audioBlockNs = FRAME - 2 * MS) }  // ~5 s of audio pacing
        checkEq(sim.iteration(2 * MS), FRAME - 2 * MS, "... also after a long stretch of audio pacing")
    }

    section("audio drops out and comes back: game speed holds in every phase")
    val sim = LoopSim(rng = Random(7), maxOvershootNs = 1 * MS)
    fun phase(seconds: Int, audio: Boolean): Double {
        val f0 = sim.frames
        val t0 = sim.now
        while (sim.now < t0 + seconds * 1_000_000_000L) {
            // audio ok: the blocking write holds the iteration to one frame period. audio gone: it returns at once
            // (or there is no track), so nothing but the pacer slows the loop down.
            if (audio) sim.iteration(2 * MS, audioPaced = true, audioBlockNs = FRAME - 2 * MS) else sim.iteration(2 * MS)
        }
        return (sim.frames - f0) * 1e9 / (sim.now - t0)
    }
    checkRate(phase(5, audio = true), FRAME_RATE, 0.001, "audio working")
    checkRate(phase(5, audio = false), FRAME_RATE, 0.001, "audio gone — paced by the clock alone")
    checkRate(phase(5, audio = true), FRAME_RATE, 0.001, "audio back")
    checkRate(phase(1, audio = false), FRAME_RATE, 0.01, "a one-second blip")
    checkRate(sim.rate, FRAME_RATE, 0.001, "whole run")
}

private fun clockWrap() {
    section("a clock that wraps around mid-run changes nothing")
    val sim = LoopSim(now = Long.MAX_VALUE - 3 * FRAME)
    var ok = true
    repeat(20) { if (sim.iteration(2 * MS) != FRAME - 2 * MS) ok = false }
    check(ok, "20 iterations across the wrap-around all wait FRAME - 2 ms")
    check(sim.now < 0L, "(the test clock really did wrap)")
}

private fun construction() {
    section("constructor guards")
    fun throwsIae(block: () -> Unit) = try { block(); false } catch (_: IllegalArgumentException) { true }
    check(throwsIae { FallbackFramePacer(0L, MAX_LAG) }, "frameNs = 0 rejected")
    check(throwsIae { FallbackFramePacer(-1L, MAX_LAG) }, "negative frameNs rejected")
    check(throwsIae { FallbackFramePacer(FRAME, -1L) }, "negative maxLagNs rejected")
    check(!throwsIae { FallbackFramePacer(FRAME, 0L) }, "maxLagNs = 0 is allowed (never carries any debt)")
}


// ── SpeedPlanner / SlowMotionAudio (audit: the 0.5x speed setting) ────────────────────────────────────────────────

private fun speedPlannerFastForward() {
    section("speed planner: 1x and above — whole frames, at least one, averaging exactly the selected speed")
    for (speed in floatArrayOf(1f, 1.5f, 2f, 3f, 4f, 7.5f, 16f)) {
        val p = SpeedPlanner()
        var total = 0L
        var fewest = Int.MAX_VALUE
        var stretched = false
        val n = 6000
        repeat(n) {
            val f = p.plan(speed)
            total += f
            fewest = minOf(fewest, f)
            if (p.audioStretch != 1.0) stretched = true
        }
        checkRate(total.toDouble() / n, speed.toDouble(), 0.0005, "${speed}x: $total frames in $n iterations")
        check(fewest >= 1, "${speed}x: never an iteration with no frame (fewest was $fewest)")
        check(!stretched, "${speed}x: the audio is never stretched")
        check(p.speed == speed, "${speed}x: the speed handed to the fallback pacer is the selected one")
    }
    section("speed planner: 1.5x alternates 1 and 2 frames, 2x and 4x are the same every time")
    run {
        val p = SpeedPlanner()
        checkEq(List(6) { p.plan(1.5f) }, listOf(1, 2, 1, 2, 1, 2), "1.5x")
        val q = SpeedPlanner()
        check(List(50) { q.plan(2f) }.all { it == 2 }, "2x: 2 frames every iteration")
        val r = SpeedPlanner()
        check(List(50) { r.plan(4f) }.all { it == 4 }, "4x: 4 frames every iteration")
    }
}

private fun speedPlannerSlowMotion() {
    section("speed planner: 0.5x — one frame per iteration, its audio stretched to two frame periods")
    run {
        val p = SpeedPlanner()
        check(List(100) { p.plan(0.5f) }.all { it == 1 }, "one emulated frame in every iteration")
        checkEq(p.audioStretch, 2.0, "the audio is stretched 2x")
        checkEq(p.speed, 0.5f, "and the fallback pacer is told 0.5x")
        val q = SpeedPlanner()
        q.plan(0.8f)
        check(abs(q.audioStretch - 1.0 / 0.8) < 1e-6, "0.8x (an old saved setting) stretches by 1/0.8")
    }
    section("speed planner: the slow-motion debt the old accumulator built up is gone")
    run {
        val p = SpeedPlanner()
        repeat(10_000) { p.plan(0.5f) }                    // about three minutes at 0.5x, fast-forward left on
        val after = List(8) { p.plan(4f) }                 // the slider is then moved to 4x
        check(after.all { it == 4 }, "4x runs 4 frames from the FIRST iteration after slow motion (was $after)")
        val q = SpeedPlanner()
        repeat(10_000) { q.plan(0.5f) }
        check(List(8) { q.plan(2f) }.all { it == 2 }, "and so does 2x")
        val back = SpeedPlanner()
        repeat(1000) { back.plan(2f) }
        check(back.plan(0.5f) == 1 && back.audioStretch == 2.0, "fast-forward to slow motion switches at once too")
    }
    section("speed planner: nonsense speeds are sanitised — never a stall, never a spin")
    run {
        for (bad in floatArrayOf(0f, -1f, Float.NaN, Float.NEGATIVE_INFINITY)) {
            val p = SpeedPlanner()
            check(p.plan(bad) == 1 && p.speed == 1f && p.audioStretch == 1.0, "speed $bad counts as 1x")
        }
        val tiny = SpeedPlanner()
        check(tiny.plan(0.1f) == 1 && tiny.speed == 0.5f && tiny.audioStretch == 2.0, "0.1x is held to the 0.5x minimum")
        val huge = SpeedPlanner()
        check(huge.plan(100f) == 16 && huge.speed == 16f, "100x is held to the 16x maximum")
        val inf = SpeedPlanner()
        check(inf.plan(Float.POSITIVE_INFINITY) == 16, "infinite speed is held to 16x, not Int.MAX_VALUE frames")
    }
    section("speed planner: reset() forgets a carried fraction")
    run {
        val p = SpeedPlanner()
        checkEq(p.plan(1.5f), 1, "first 1.5x iteration")
        p.reset()
        checkEq(p.plan(1.5f), 1, "after reset() it starts over (without it the carried half frame would make this 2)")
    }
}

private fun slowMotionAudio() {
    section("slow-motion audio: length, endpoints and interpolation at 2x")
    run {
        val n = 738                                                      // one frame at 44.1 kHz
        val src = ShortArray(n * 2) { i -> if (i % 2 == 0) (i / 2 * 40).toShort() else (-(i / 2) * 40).toShort() }
        val dst = ShortArray(n * 4)
        val out = SlowMotionAudio.stretch(src, n, dst, 2.0)
        checkEq(out, n * 2, "a frame's 738 pairs become 1476")
        check(dst[0] == src[0] && dst[1] == src[1], "the first output pair is the first input pair")
        var evenOk = true
        var oddOk = true
        for (j in 0 until n) {
            if (dst[4 * j] != src[2 * j] || dst[4 * j + 1] != src[2 * j + 1]) evenOk = false
            if (j < n - 1) {
                val midL = (src[2 * j] + src[2 * j + 2]) / 2.0
                val midR = (src[2 * j + 1] + src[2 * j + 3]) / 2.0
                if (abs(dst[4 * j + 2] - midL) > 0.5 || abs(dst[4 * j + 3] - midR) > 0.5) oddOk = false
            }
        }
        check(evenOk, "every even output pair is an input pair, untouched")
        check(oddOk, "every odd output pair is the midpoint of its neighbours, both channels")
        check(dst[(out - 1) * 2] == src[(n - 1) * 2], "the clip ends on its own last pair (it does not read past the input)")
    }
    section("slow-motion audio: a constant stays constant, a tone stays a tone an octave lower")
    run {
        val n = 738
        val dc = ShortArray(n * 2) { i -> if (i % 2 == 0) 1234.toShort() else (-2000).toShort() }
        val dcOut = ShortArray(n * 4)
        val m = SlowMotionAudio.stretch(dc, n, dcOut, 2.0)
        check((0 until m).all { dcOut[2 * it] == 1234.toShort() && dcOut[2 * it + 1] == (-2000).toShort() },
            "a constant signal is unchanged and the channels stay independent")
        val amp = 10_000.0
        val tone = ShortArray(n * 2)
        for (i in 0 until n) { val v = (amp * sin(2 * PI * i / 100.0)).toInt().toShort(); tone[2 * i] = v; tone[2 * i + 1] = v }
        val toneOut = ShortArray(n * 4)
        val k = SlowMotionAudio.stretch(tone, n, toneOut, 2.0)
        var worst = 0.0
        for (j in 0 until k - 2) worst = maxOf(worst, abs(toneOut[2 * j] - amp * sin(2 * PI * j / 200.0)))
        check(worst < 12.0, "a 441 Hz tone comes out as a 220 Hz tone, within 0.12% of its amplitude (worst error $worst)")
    }
    section("slow-motion audio: other factors, and never past the end of the destination")
    run {
        val n = 738
        val src = ShortArray(n * 2) { (it % 251).toShort() }
        val dst = ShortArray(n * 4)
        checkEq(SlowMotionAudio.stretch(src, n, dst, 1.5), 1107, "1.5x: round(738 x 1.5) pairs")
        checkEq(SlowMotionAudio.stretch(src, n, dst, 1.0 / 0.75), 984, "0.75x: round(738 / 0.75) pairs")
        val small = ShortArray(200)
        checkEq(SlowMotionAudio.stretch(src, n, small, 2.0), 100, "a destination for 100 pairs gets exactly 100 (no overrun)")
        checkEq(SlowMotionAudio.stretch(src, 0, dst, 2.0), 0, "no input, no output")
        checkEq(SlowMotionAudio.stretch(src, -5, dst, 2.0), 0, "negative input count, no output")
        checkEq(SlowMotionAudio.stretch(src, n * 10, dst, 2.0), n * 2, "an input count beyond the array is cut to the array")
        val same = ShortArray(n * 4)
        checkEq(SlowMotionAudio.stretch(src, n, same, 1.0), n, "a stretch of 1 copies the clip")
        check((0 until n * 2).all { same[it] == src[it] }, "... unchanged")
        checkEq(SlowMotionAudio.stretch(src, n, ShortArray(n * 4), Double.NaN), n, "NaN is treated as no stretch")
        val loud = ShortArray(8) { if (it % 2 == 0) Short.MAX_VALUE else Short.MIN_VALUE }
        val loudOut = ShortArray(16)
        checkEq(SlowMotionAudio.stretch(loud, 4, loudOut, 2.0), 8, "full-scale input")
        check(loudOut.all { it in Short.MIN_VALUE..Short.MAX_VALUE }, "... stays in range (no wrap-around)")
    }
}

private const val AUDIO_RATE = 44_100.0


private const val AUDIO_BUFFER_SHORTS = 2048     // MainActivity.audioBuffer — speedWiring() pins this to the source
private const val PAIRS_PER_FRAME = 738          // 44100 Hz / ~59.73 frames per second

private fun slowMotionWriter() {
    section("slow-motion writer: the stretched clip reaches the AudioTrack write whole, in order, in buffer-sized pieces")
    run {
        val n = PAIRS_PER_FRAME
        val buffer = ShortArray(AUDIO_BUFFER_SHORTS)
        val scratch = ShortArray(AUDIO_BUFFER_SHORTS * 2)
        val frame = ShortArray(n * 2) { i -> ((i * 37) % 20001 - 10000).toShort() }
        System.arraycopy(frame, 0, buffer, 0, frame.size)
        val expected = ShortArray(AUDIO_BUFFER_SHORTS * 2)
        val expectedPairs = SlowMotionAudio.stretch(frame, n, expected, 2.0)
        val sizes = ArrayList<Int>()
        val heard = ArrayList<Short>()                         // what each write would have played, in order
        val paced = SlowMotionAudio.writeStretched(buffer, n, scratch, 2.0) { pairs ->
            sizes += pairs
            for (i in 0 until pairs * 2) heard += buffer[i]    // a write plays the FIRST `pairs` pairs of the buffer
            true
        }
        check(paced, "every piece accepted → the write paced the iteration")
        checkEq(sizes, listOf(1024, 452), "738 pairs stretched 2x = 1476 go out as a full 1024-pair buffer, then the 452-pair rest")
        checkEq(heard.size, expectedPairs * 2, "the pieces add up to the whole stretched clip")
        check((0 until heard.size).all { heard[it] == expected[it] }, "... and joined they ARE the stretched clip, sample for sample")
    }
    section("slow-motion writer: sizes around the buffer boundary")
    run {
        val buffer = ShortArray(AUDIO_BUFFER_SHORTS)
        val scratch = ShortArray(AUDIO_BUFFER_SHORTS * 2)
        fun sizesFor(pairs: Int, factor: Double): List<Int> {
            val out = ArrayList<Int>()
            SlowMotionAudio.writeStretched(buffer, pairs, scratch, factor) { out += it; true }
            return out
        }
        checkEq(sizesFor(300, 2.0), listOf(600), "a clip that fits in one buffer is one write")
        checkEq(sizesFor(512, 2.0), listOf(1024), "exactly one buffer is one write")
        checkEq(sizesFor(513, 2.0), listOf(1024, 2), "one pair over is a second, tiny write")
        checkEq(sizesFor(1024, 2.0), listOf(1024, 1024), "a full buffer at 2x is two full pieces (the scratch buffer is exactly big enough)")
        checkEq(sizesFor(738, 1.5), listOf(1024, 83), "1.5x: round(738 x 1.5) = 1107 pairs")
    }
    section("slow-motion writer: the first piece the AudioTrack does not take ends the frame and reports 'not paced'")
    run {
        val buffer = ShortArray(AUDIO_BUFFER_SHORTS) { (it % 91).toShort() }
        val scratch = ShortArray(AUDIO_BUFFER_SHORTS * 2)
        var calls = 0
        val first = SlowMotionAudio.writeStretched(buffer, PAIRS_PER_FRAME, scratch, 2.0) { calls++; false }
        check(!first && calls == 1, "first piece refused → false, and the second piece is not even tried (calls: $calls)")
        calls = 0
        val second = SlowMotionAudio.writeStretched(buffer, PAIRS_PER_FRAME, scratch, 2.0) { calls++; calls < 2 }
        check(!second && calls == 2, "second piece refused → false after exactly two writes (calls: $calls)")
    }
    section("slow-motion writer: normal speed is one plain write, buffer untouched")
    run {
        val n = PAIRS_PER_FRAME
        val buffer = ShortArray(AUDIO_BUFFER_SHORTS) { (it % 53).toShort() }
        val before = buffer.copyOf()
        val scratch = ShortArray(AUDIO_BUFFER_SHORTS * 2)
        for (f in doubleArrayOf(1.0, 0.5, 0.0, -3.0, Double.NaN)) {
            val sizes = ArrayList<Int>()
            val r = SlowMotionAudio.writeStretched(buffer, n, scratch, f) { sizes += it; true }
            check(r && sizes == listOf(n), "factor $f → one write of the whole frame (writes: $sizes)")
        }
        check(buffer.contentEquals(before), "... and the buffer was never touched")
        check(!SlowMotionAudio.writeStretched(buffer, n, scratch, 1.0) { false }, "a refused plain write reports false")
    }
    section("slow-motion writer: nothing to write, and a degenerate buffer, never loop or write")
    run {
        val scratch = ShortArray(AUDIO_BUFFER_SHORTS * 2)
        var calls = 0
        check(!SlowMotionAudio.writeStretched(ShortArray(AUDIO_BUFFER_SHORTS), 0, scratch, 2.0) { calls++; true } && calls == 0,
            "no input pairs, stretched: false, no write")
        check(!SlowMotionAudio.writeStretched(ShortArray(AUDIO_BUFFER_SHORTS), -4, scratch, 2.0) { calls++; true } && calls == 0,
            "a negative count: false, no write")
        check(!SlowMotionAudio.writeStretched(ShortArray(1), 5, scratch, 2.0) { calls++; true } && calls == 0,
            "a buffer too small to hold one pair: false, no write, and no endless loop")
    }
}

/**
 * The game loop's speed, as a multiple of real time, when the blocking audio write is the pacer: the iterations run
 * back to back and each lasts as long as the audio it wrote plays at 44.1 kHz. Built from the REAL SpeedPlanner and
 * SlowMotionAudio; fast-forward batches write `decimateForFastForward()`'s output (their frames' audio / the batch size).
 * [honourStretch] = false writes every frame's audio unstretched — what the loop did before the fix.
 */
private fun audioPacedSpeed(requested: Float, iterations: Int = 6000, honourStretch: Boolean = true): Double {
    val planner = SpeedPlanner()
    val buffer = ShortArray(AUDIO_BUFFER_SHORTS) { (it % 97).toShort() }     // MainActivity.audioBuffer
    val scratch = ShortArray(AUDIO_BUFFER_SHORTS * 2)                         // MainActivity.slowAudioBuffer
    var frames = 0L
    var pairsWritten = 0L
    repeat(iterations) {
        val f = planner.plan(requested)
        frames += f
        // A fast-forward batch writes decimateForFastForward()'s output: f frames' audio / f = one frame's worth.
        if (f > 1) pairsWritten += PAIRS_PER_FRAME
        else SlowMotionAudio.writeStretched(buffer, PAIRS_PER_FRAME, scratch, if (honourStretch) planner.audioStretch else 1.0) { n ->
            pairsWritten += n
            true
        }
    }
    return frames / (pairsWritten / AUDIO_RATE) / FRAME_RATE
}

private fun speedEndToEnd() {
    section("audio-paced loop: every selected speed runs at that speed — 0.5x included")
    for (speed in floatArrayOf(0.5f, 1f, 1.5f, 2f, 4f, 8f, 16f)) {
        checkRate(audioPacedSpeed(speed), speed.toDouble(), 0.005, "${speed}x with working audio")
    }
    check(abs(audioPacedSpeed(0.5f, honourStretch = false) - 1.0) < 0.01,
        "(the model can see the old defect) without the stretch, 0.5x ran at 1x — what the loop did before")

    section("fallback-paced loop (no audio pacing): 0.5x is half speed, as before")
    run {
        val sim = LoopSim()
        val planner = SpeedPlanner()
        repeat(3000) {
            val f = planner.plan(0.5f)
            sim.iteration(computeNs = 2 * MS, framesRun = f, speed = planner.speed, audioPaced = false)
        }
        checkRate(sim.rate, 0.5 * FRAME_RATE, 0.002, "3000 iterations at 0.5x with nothing pacing the audio")
    }

    section("0.5x holds through an audio outage and the recovery (audio -> fallback -> audio)")
    run {
        val sim = LoopSim()
        val planner = SpeedPlanner()
        val stretchedFrameNs = (2.0 * PAIRS_PER_FRAME / AUDIO_RATE * 1e9).toLong()     // the blocking write of a stretched frame
        fun phase(audioPaced: Boolean, iterations: Int): Double {
            val t0 = sim.now; val f0 = sim.frames
            repeat(iterations) {
                val f = planner.plan(0.5f)
                if (audioPaced) sim.iteration(computeNs = 2 * MS, framesRun = f, speed = planner.speed, audioPaced = true, audioBlockNs = stretchedFrameNs - 2 * MS)
                else sim.iteration(computeNs = 2 * MS, framesRun = f, speed = planner.speed, audioPaced = false)
            }
            return (sim.frames - f0) * 1e9 / (sim.now - t0)
        }
        checkRate(phase(true, 600), 0.5 * FRAME_RATE, 0.01, "audio working")
        checkRate(phase(false, 600), 0.5 * FRAME_RATE, 0.01, "audio gone")
        checkRate(phase(true, 600), 0.5 * FRAME_RATE, 0.01, "audio back")
    }
}

/** The model and unit tests above only help if the loop really uses the planner and the stretch — a source check. */
private fun speedWiring() {
    section("wiring: the game loop plans with SpeedPlanner and writes slow-motion audio through writeFramePcm (source check)")
    val dir = File("../../app/src/main/kotlin/com/mgba/android")
    check(dir.isDirectory, "(setup) the Kotlin source directory is where run.sh runs the test from: ${dir.absolutePath}")
    if (!dir.isDirectory) return
    val render = File(dir, "MainActivityRender.kt").readText()
    val audio = File(dir, "MainActivityAudio.kt").readText()
    val main = File(dir, "MainActivity.kt").readText()
    check(!render.contains("ffFrameAccumulator") && !main.contains("ffFrameAccumulator"), "the old inline accumulator is gone")
    checkEq(Regex("""speedPlanner\.plan\(""").findAll(render).count(), 1, "the loop asks the planner once per iteration")
    check(render.contains("if (!fastForwardActive) speedPlanner.reset()"), "leaving fast-forward drops the carried fraction (as the old accumulator did)")
    check(render.contains("val speed = speedPlanner.speed"), "the fallback pacer is handed the planner's (sanitised) speed")
    check(render.contains("val audioStretch = speedPlanner.audioStretch"), "the planner's audio stretch is read each iteration")
    checkEq(Regex("""writeFramePcm\(n, audioStretch\)""").findAll(render).count(), 2,
        "both single-frame audio writes (render and frame-skip branch) go through writeFramePcm()")
    checkEq(Regex("""audioPaced = writePcm\(""").findAll(render).count(), 1, "only the fast-forward batch still writes with writePcm() directly")
    check(render.contains("fallbackPacer.waitNs(audioPaced, t0, System.nanoTime(), framesToRun, speed)"), "the pacer call uses framesToRun and that speed")
    check(audio.contains("fun MainActivity.writeFramePcm(count: Int, stretch: Double): Boolean =") &&
        audio.contains("SlowMotionAudio.writeStretched(audioBuffer, count, slowAudioBuffer, stretch) { n -> writePcm(n) }"),
        "writeFramePcm() hands the frame to SlowMotionAudio.writeStretched(), whose piece writes are the ordinary writePcm()")
    val bufferSize = Regex("""val audioBuffer = ShortArray\((\d+)\)""").find(main)?.groupValues?.get(1)?.toInt()
    checkEq(bufferSize, AUDIO_BUFFER_SHORTS, "the audio-paced model uses MainActivity.audioBuffer's real size")
    check(Regex("""val slowAudioBuffer = ShortArray\(audioBuffer\.size \* 2\)""").containsMatchIn(main),
        "slowAudioBuffer holds a full audioBuffer stretched 2x — the slowest speed (0.5x)'s stretch")
}

fun main() {
    audioPacedIterations()
    scheduleStartsAtTheIterationStart()
    steadyState()
    noDriftFromLateSleeps()
    fallingBehind()
    speedAndFrames()
    fractionalFastForward()
    audioComesAndGoes()
    clockWrap()
    construction()
    speedPlannerFastForward()
    speedPlannerSlowMotion()
    slowMotionAudio()
    slowMotionWriter()
    speedEndToEnd()
    speedWiring()
    println()
    if (failures.isEmpty()) {
        println("ALL $checks CHECKS PASSED")
    } else {
        println("${failures.size} OF $checks CHECKS FAILED")
        exitProcess(1)
    }
}
