package com.mgba.android.saves

import java.io.ByteArrayInputStream
import java.io.File
import java.util.TimeZone
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.system.exitProcess

// Host-side tests for app/src/main/kotlin/com/mgba/android/saves/* — the pure logic behind "the in-game save is
// keyed by the game's name" and "closing the game no longer waits on storage". run.sh compiles the REAL sources
// next to this file, so a test cannot drift from the shipping code. No Android, no JUnit: a tiny assert harness.

private var checks = 0
private val failures = ArrayList<String>()

private fun check(cond: Boolean, what: String) {
    checks++
    if (!cond) { failures += what; println("  FAIL: $what") }
}

private fun <T> checkEq(actual: T, expected: T, what: String) =
    check(actual == expected, "$what — expected <$expected> but was <$actual>")

private fun section(name: String) = println("• $name")

// ── fakes ───────────────────────────────────────────────────────────────────────────────────────────────────────

private fun bytes(fill: Int, size: Int = 64) = ByteArray(size) { fill.toByte() }
private fun progress(seed: Int, size: Int = 64) = ByteArray(size) { ((it * 7 + seed) % 251 + 1).toByte() } // never 0x00/0xFF-only

/** In-memory save folder. Files are `<name>.sav` (and snapshots `<name>.sav.<label>`) → bytes + mtime. */
private class FakeStore : BatteryStore {
    class F(var data: ByteArray, var modified: Long)
    val files = LinkedHashMap<String, F>()
    var now = 1_000L
    var failCopy = false
    var failSnapshot = false
    var statCalls = 0
    var scanCalls = 0
    val copies = ArrayList<String>()

    fun put(key: String, data: ByteArray, modified: Long = ++now) { files["$key.sav"] = F(data, modified) }
    fun data(key: String): ByteArray? = files["$key.sav"]?.data
    fun snapshotNames(): List<String> = files.keys.filter { it.contains(".sav.") }

    private fun info(key: String, crc: String?): SaveFileInfo? {
        val f = files["$key.sav"] ?: return null
        val a = SaveContentAnalyzer.analyze(ByteArrayInputStream(f.data))
        return SaveFileInfo(key, crc, a.size.toLong(), f.modified, a.real, a.digest)
    }

    override fun statShared(key: String): SaveFileInfo? { statCalls++; return info(key, null) }

    override fun scanBuildSaves(readable: String): List<SaveFileInfo> {
        scanCalls++
        return files.keys.mapNotNull { name ->
            val crc = SaveKeys.parseBuildBattery(readable, name) ?: return@mapNotNull null
            info("${readable}_$crc", crc)
        }
    }

    override fun copy(from: SaveFileInfo, toKey: String): Boolean {
        if (failCopy) return false
        val src = files["${from.key}.sav"] ?: return false
        files["$toKey.sav"] = F(src.data.copyOf(), ++now)
        copies += "${from.key}->$toKey"
        return true
    }

    override fun snapshot(key: String, label: String): Boolean {
        if (failSnapshot) return false
        val src = files["$key.sav"] ?: return false
        val name = "$key.sav.$label"
        if (!files.containsKey(name)) files[name] = F(src.data.copyOf(), ++now)
        return true
    }
}

private class FakeRegistry : SaveRegistry {
    val unified = HashMap<String, Set<String>>()
    val seen = HashMap<String, MutableSet<String>>()
    var reads = 0
    override fun isUnified(readable: String): Boolean { reads++; return unified.containsKey(readable) }
    override fun markUnified(readable: String, builds: Set<String>) {
        unified[readable] = builds
        seen.getOrPut(readable) { HashSet() }.addAll(builds)
    }
    override fun builds(readable: String): Set<String> { reads++; return seen[readable]?.toSet() ?: emptySet() }
    override fun addBuild(readable: String, crc: String) { seen.getOrPut(readable) { HashSet() }.add(crc) }
    val last = HashMap<String, String>()
    override fun lastBuild(readable: String): String? = last[readable]
    override fun setLastBuild(readable: String, crc: String) { last[readable] = crc }
}

private class ScriptedChooser(var answer: (List<SaveFileInfo>) -> SaveFileInfo?) : ConflictChooser {
    var asked = 0
    var lastOptions: List<SaveFileInfo> = emptyList()
    override fun choose(readable: String, options: List<SaveFileInfo>, ownCrc: String?): SaveFileInfo? {
        asked++; lastOptions = options; return answer(options)
    }
}

private fun resolver(store: FakeStore, reg: FakeRegistry, chooser: ConflictChooser) =
    BatterySaveResolver(store, reg, chooser, clock = { 1_793_000_000_000L })

// ── SaveKeys ────────────────────────────────────────────────────────────────────────────────────────────────────

private fun testKeys() {
    section("SaveKeys: naming")
    checkEq(SaveKeys.readableName("Pokemon Emerald"), "Pokemon_Emerald", "spaces become _")
    checkEq(SaveKeys.readableName("Pokémon - Émeraude (v1.2)"), "Pokémon_-_Émeraude__v1_2_", "accents kept, punctuation becomes _")
    checkEq(SaveKeys.readableName("ポケモン"), "ポケモン", "non-Latin letters kept")
    checkEq(SaveKeys.readableName("a".repeat(80)), "a".repeat(48), "cut to 48 characters")
    checkEq(SaveKeys.readableName(""), "rom", "blank name -> rom")
    checkEq(SaveKeys.readableName("   "), "___", "spaces become underscores (a name of only spaces is not blank)")
    checkEq(SaveKeys.readableName("Game", playerTwo = true), "p2-Game", "player two prefix")
    checkEq(SaveKeys.legacyName("ポケモン"), "____", "legacy sanitizer drops non-ASCII")
    checkEq(SaveKeys.legacyName("a".repeat(100)).length, 80, "legacy cut to 80")
    checkEq(SaveKeys.buildKey("Game", "a228ff3e"), "Game_a228ff3e", "build key")
    checkEq(SaveKeys.buildKey("Game", null), "Game", "build key without crc")

    section("SaveKeys: the in-game save is keyed by the name only")
    val orig = RomIdentity("Pokemon_Emerald", "a228ff3e")
    val patched = RomIdentity("Pokemon_Emerald", "3632fca4")
    checkEq(orig.batteryKey, patched.batteryKey, "original and renamed patch share one in-game save key")
    check(orig.buildKey != patched.buildKey, "...but keep different save-state keys")
    checkEq(SaveKeys.batteryFileName(orig.batteryKey), "Pokemon_Emerald.sav", "plain <name>.sav")

    section("SaveKeys: a name that looks like <x>_<crc> can never be taken for another game's per-build file")
    checkEq(SaveKeys.batteryKey("Hack_20261026"), "Hack_20261026_", "ends-with-8-hex gets a trailing _")
    checkEq(SaveKeys.batteryKey("Hack"), "Hack", "ordinary name untouched")
    checkEq(SaveKeys.batteryKey("v_12345678x"), "v_12345678x", "not exactly 8 hex at the end -> untouched")
    val names = listOf("Hack", "Hack_20261026", "Hack_20261026_x", "foo", "foo_deadbeef", "a", "a_b", "Hack_", "p2-Hack",
        "Hack_20261026_20261026", "x_00000000", "x")
    for (r in names) {
        val file = SaveKeys.batteryFileName(SaveKeys.batteryKey(r))
        for (r2 in names) {
            checkEq(SaveKeys.parseBuildBattery(r2, file), null, "name-keyed file '$file' (game '$r') is not a per-build file of '$r2'")
        }
    }
    checkEq(SaveKeys.parseBuildBattery("Hack", "Hack_a228ff3e.sav"), "a228ff3e", "per-build file parsed")
    checkEq(SaveKeys.parseBuildBattery("Hack", "Hack_a228ff3e.sav.bak"), null, ".bak is not a save")
    checkEq(SaveKeys.parseBuildBattery("Hack", "Hack_a228ff3e.sav.tmp-123"), null, "temp file is not a save")
    checkEq(SaveKeys.parseBuildBattery("Hack", "Hack_A228FF3E.sav"), null, "upper-case hex is not a CRC we write")
    checkEq(SaveKeys.parseBuildBattery("Hack", "Hack.sav"), null, "name-only file is not per-build")
    checkEq(SaveKeys.parseBuildBattery("Hack", "Other_a228ff3e.sav"), null, "other game")

    section("SaveKeys: state files")
    check(SaveKeys.isStateExtension("state1"), "state1")
    check(SaveKeys.isStateExtension("state12.png"), "state12.png")
    check(SaveKeys.isStateExtension("quicksave"), "quicksave")
    check(SaveKeys.isStateExtension("autosave.png"), "autosave.png")
    check(!SaveKeys.isStateExtension("state"), "bare 'state'")
    check(!SaveKeys.isStateExtension("statex"), "'statex'")
    check(!SaveKeys.isStateExtension("sav"), "sav")
    check(SaveKeys.isThumbnailExtension("state1.png"), "thumbnail")
    check(!SaveKeys.isThumbnailExtension("state1"), "not a thumbnail")
}

// ── SaveContentAnalyzer ─────────────────────────────────────────────────────────────────────────────────────────

private fun testAnalyzer() {
    section("SaveContentAnalyzer: 'real' = played into")
    fun a(b: ByteArray) = SaveContentAnalyzer.analyze(ByteArrayInputStream(b))
    check(!a(bytes(0xFF)).real, "all 0xFF (fresh Flash/EEPROM) is not real")
    check(!a(bytes(0x00)).real, "all 0x00 (fresh SRAM) is not real")
    check(!a(ByteArray(0)).real, "empty is not real")
    check(a(bytes(0x01)).real, "one repeated non-blank value is real")
    check(a(byteArrayOf(0xFF.toByte(), 0xFF.toByte(), 0x00)).real, "mixed 0x00/0xFF only is still real")
    val oneByte = bytes(0xFF, 128 * 1024).also { it[100] = 0x12 }
    check(a(oneByte).real, "a single played byte in 128 KiB of 0xFF is real")
    checkEq(a(bytes(0xFF, 128 * 1024)).size, 128 * 1024, "size reported")
    check(a(progress(1)).digest == a(progress(1)).digest, "equal content -> equal digest")
    check(a(progress(1)).digest != a(progress(2)).digest, "different content -> different digest")
    checkEq(a(bytes(0x11, 300 * 1024)).size, SaveContentAnalyzer.MAX_ANALYZED_BYTES, "reads at most 256 KiB")
}

// ── BatteryAdoption (planner) ───────────────────────────────────────────────────────────────────────────────────

private fun info(key: String, crc: String?, data: ByteArray, modified: Long): SaveFileInfo {
    val a = SaveContentAnalyzer.analyze(ByteArrayInputStream(data))
    return SaveFileInfo(key, crc, a.size.toLong(), modified, a.real, a.digest)
}

private fun testPlanner() {
    section("BatteryAdoption.plan")
    val orig = info("G_a228ff3e", "a228ff3e", progress(1), 100)
    val patchedFresh = info("G_3632fca4", "3632fca4", bytes(0xFF), 200)
    val patchedReal = info("G_3632fca4", "3632fca4", progress(2), 300)

    check(BatteryAdoption.plan(null, emptyList()) is AdoptionPlan.UseShared, "nothing at all -> use (create) the shared file")
    check(BatteryAdoption.plan(info("G", null, progress(3), 10), emptyList()) is AdoptionPlan.UseShared, "only a real shared file -> use it")
    check(BatteryAdoption.plan(info("G", null, bytes(0xFF), 10), emptyList()) is AdoptionPlan.UseShared, "only a fresh shared file -> use it")
    check(BatteryAdoption.plan(null, listOf(patchedFresh)) is AdoptionPlan.UseShared, "only a fresh per-build file -> nothing to carry over")

    var p = BatteryAdoption.plan(null, listOf(orig))
    check(p is AdoptionPlan.Adopt && p.from === orig, "one real per-build save -> adopt it")

    p = BatteryAdoption.plan(null, listOf(orig, patchedFresh))
    check(p is AdoptionPlan.Adopt && p.from === orig, "THE REPORTED CASE: original has progress, renamed patch is fresh -> adopt the original's")

    p = BatteryAdoption.plan(null, listOf(patchedFresh, orig))
    check(p is AdoptionPlan.Adopt && p.from === orig, "...whatever order the scan returned them in")

    p = BatteryAdoption.plan(null, listOf(orig, patchedReal))
    check(p is AdoptionPlan.Ask && p.options.size == 2 && p.options[0] === patchedReal && p.options[1] === orig,
        "two different real saves -> ask, newest first")

    val dup = info("G_3632fca4", "3632fca4", progress(1), 500)
    p = BatteryAdoption.plan(null, listOf(orig, dup))
    check(p is AdoptionPlan.Adopt && p.from === dup, "two real saves with identical bytes are one save (newest represents it)")

    // Name-only file left over from before the CRC suffix existed: the per-build file is its descendant.
    val legacy = info("G", null, progress(9), 50)
    p = BatteryAdoption.plan(legacy, listOf(orig))
    check(p is AdoptionPlan.Adopt && p.from === orig, "old name-only file + newer per-build file -> the per-build file wins, no question")

    val claimCopy = info("G_a228ff3e", "a228ff3e", progress(9), 60)
    check(BatteryAdoption.plan(legacy, listOf(claimCopy)) is AdoptionPlan.UseShared,
        "per-build file identical to the name-only one -> nothing to do")

    // A file the player dropped in by hand, newer than everything else.
    val dropped = info("G", null, progress(77), 900)
    p = BatteryAdoption.plan(dropped, listOf(orig))
    check(p is AdoptionPlan.Ask && p.options.size == 2 && p.options[0] === dropped, "hand-placed newer <name>.sav vs a real per-build save -> ask")
    check(BatteryAdoption.plan(dropped, listOf(patchedFresh)) is AdoptionPlan.UseShared, "hand-placed <name>.sav vs only fresh per-build files -> use it")

    p = BatteryAdoption.plan(legacy, listOf(claimCopy, info("G_bbbbbbbb", "bbbbbbbb", progress(5), 700)))
    check(p is AdoptionPlan.Ask && p.options.size == 2, "two builds with different progress -> ask (legacy file is not a third option)")

    // Planner never invents or drops saves: every real distinct content shows up exactly once.
    val many = listOf(orig, patchedReal, info("G_cccccccc", "cccccccc", progress(3), 150))
    p = BatteryAdoption.plan(null, many)
    check(p is AdoptionPlan.Ask && p.options.size == 3 && p.options.map { it.modified } == listOf(300L, 150L, 100L), "three different saves, newest first")

    // A document provider that reports no modification time (0) proves nothing: the old name-only file is then
    // NOT treated as the ancestor of a different per-build save — the player is asked instead of one of them
    // silently losing.
    val legacyNoDate = info("G", null, progress(9), 0)
    val buildNoDate = info("G_a228ff3e", "a228ff3e", progress(1), 0)
    p = BatteryAdoption.plan(legacyNoDate, listOf(orig))
    check(p is AdoptionPlan.Ask && p.options.size == 2, "name-only file with an unknown date vs a different real per-build save -> ask")
    p = BatteryAdoption.plan(legacy, listOf(buildNoDate))
    check(p is AdoptionPlan.Ask && p.options.size == 2, "per-build save with an unknown date vs a different name-only file -> ask")
    p = BatteryAdoption.plan(legacyNoDate, listOf(buildNoDate))
    check(p is AdoptionPlan.Ask && p.options.size == 2, "both dates unknown -> ask")
    check(BatteryAdoption.plan(legacyNoDate, listOf(info("G_a228ff3e", "a228ff3e", progress(9), 0))) is AdoptionPlan.UseShared,
        "...but identical bytes are one save whatever the dates")
}

// ── BatterySaveResolver ─────────────────────────────────────────────────────────────────────────────────────────

private fun testResolver() {
    val gameOrig = RomIdentity("Pokemon_Emerald", "a228ff3e")
    val gamePatched = RomIdentity("Pokemon_Emerald", "3632fca4")

    section("Resolver: patched ROM renamed to the original's name (the reported bug)")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        store.put("Pokemon_Emerald_a228ff3e", progress(1))          // the original, played before this change
        val res = r.resolve(gamePatched)                            // first launch of the renamed patch
        checkEq(res.key, "Pokemon_Emerald", "opens the name-keyed save")
        checkEq(res.outcome, BatteryResolution.Outcome.ADOPTED, "carried the original's save over")
        check(store.data("Pokemon_Emerald")!!.contentEquals(progress(1)), "the patched ROM starts from the original's progress")
        check(store.data("Pokemon_Emerald_a228ff3e")!!.contentEquals(progress(1)), "the original's file is untouched")
        checkEq(chooser.asked, 0, "no question was needed")
        check(store.snapshotNames().any { it == "Pokemon_Emerald.sav.before-3632fca4" }, "pre-open snapshot kept for the new build")
        check(store.files["Pokemon_Emerald.sav.before-3632fca4"]!!.data.contentEquals(progress(1)), "...holding the original's save as it was")

        // The patched game saves in-game; later the ORIGINAL is opened again.
        store.put("Pokemon_Emerald", progress(2))
        val back = r.resolve(gameOrig)
        checkEq(back.key, "Pokemon_Emerald", "the original uses the same in-game save")
        checkEq(back.outcome, BatteryResolution.Outcome.SHARED, "no second adoption")
        check(store.data("Pokemon_Emerald")!!.contentEquals(progress(2)), "the patched game's newer progress is not overwritten by the old per-build file")
        check(store.data("Pokemon_Emerald_a228ff3e")!!.contentEquals(progress(1)), "old per-build file still untouched")
        check(store.snapshotNames().none { it.endsWith("before-a228ff3e") }, "the original build was recorded when it was adopted: no snapshot needed")
    }

    section("Resolver: single-ROM upgrade (name-only file from before the CRC era + per-build file)")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        store.put("Game", progress(9), modified = 10)                // legacy
        store.put("Game_11111111", progress(10), modified = 20)      // claimed copy, played on since
        val res = resolver(store, reg, chooser).resolve(RomIdentity("Game", "11111111"))
        checkEq(res.outcome, BatteryResolution.Outcome.ADOPTED, "adopted")
        check(store.data("Game")!!.contentEquals(progress(10)), "the name-keyed save now holds the latest progress")
        val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.ROOT).format(java.util.Date(1_793_000_000_000L))
        val snap = "Game.sav.before-adopt-$stamp"
        check(store.files.containsKey(snap), "the old name-only file was snapshotted before being replaced ($snap in ${store.snapshotNames()})")
        check(store.files[snap]?.data?.contentEquals(progress(9)) == true, "snapshot holds the replaced bytes")
        checkEq(chooser.asked, 0, "no question for the common case")
    }

    section("Resolver: nothing saved anywhere -> plain name-keyed file, no copies")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        val res = resolver(store, reg, chooser).resolve(gameOrig)
        checkEq(res.key, "Pokemon_Emerald", "key"); checkEq(res.outcome, BatteryResolution.Outcome.SHARED, "outcome")
        check(store.copies.isEmpty() && store.snapshotNames().isEmpty(), "nothing copied, nothing snapshotted")
        check(reg.unified.containsKey("Pokemon_Emerald"), "name marked as unified")
    }

    section("Resolver: two different real saves -> the player chooses; nothing is deleted")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        store.put("Pokemon_Emerald_a228ff3e", progress(1), modified = 100)
        store.put("Pokemon_Emerald_3632fca4", progress(2), modified = 200)
        val chooser = ScriptedChooser { opts -> opts.first { it.crc == "a228ff3e" } }
        val res = resolver(store, reg, chooser).resolve(gamePatched)
        checkEq(chooser.asked, 1, "asked once")
        checkEq(chooser.lastOptions.map { it.crc }, listOf<String?>("3632fca4", "a228ff3e"), "options newest first")
        checkEq(res.outcome, BatteryResolution.Outcome.ADOPTED, "adopted the chosen one")
        check(store.data("Pokemon_Emerald")!!.contentEquals(progress(1)), "chosen save is now the shared one")
        check(store.data("Pokemon_Emerald_3632fca4")!!.contentEquals(progress(2)), "the other save is still there")
        checkEq(resolver(store, reg, chooser).resolve(gamePatched).outcome, BatteryResolution.Outcome.SHARED, "next load: no more questions")
        checkEq(chooser.asked, 1, "still asked only once")
    }

    section("Resolver: choosing the other save works too, and dismissing defers")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        store.put("Pokemon_Emerald_a228ff3e", progress(1), modified = 100)
        store.put("Pokemon_Emerald_3632fca4", progress(2), modified = 200)
        val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        val deferred = r.resolve(gamePatched)
        checkEq(deferred.outcome, BatteryResolution.Outcome.DEFERRED, "dismissed -> deferred")
        checkEq(deferred.key, "Pokemon_Emerald_3632fca4", "this session runs on the build's own old file")
        check(deferred.usesBuildFile, "usesBuildFile")
        check(!reg.unified.containsKey("Pokemon_Emerald"), "not marked unified")
        check(store.data("Pokemon_Emerald") == null, "nothing was written")
        chooser.answer = { opts -> opts.first { it.crc == "3632fca4" } }
        val chosen = r.resolve(gamePatched)
        checkEq(chooser.asked, 2, "asked again next load")
        checkEq(chosen.key, "Pokemon_Emerald", "now resolved")
        check(store.data("Pokemon_Emerald")!!.contentEquals(progress(2)), "the patch's own save became the shared one")
    }

    section("Resolver: a failed copy never loses anything and is retried")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        store.put("Pokemon_Emerald_a228ff3e", progress(1))
        store.failCopy = true
        val r = resolver(store, reg, chooser)
        val res = r.resolve(gamePatched)
        checkEq(res.outcome, BatteryResolution.Outcome.FAILED, "failed")
        checkEq(res.key, "Pokemon_Emerald_3632fca4", "falls back to the build's own file")
        check(!reg.unified.containsKey("Pokemon_Emerald"), "not marked unified")
        store.failCopy = false
        checkEq(r.resolve(gamePatched).outcome, BatteryResolution.Outcome.ADOPTED, "retried and succeeded next time")
    }

    section("Resolver: an existing real name-keyed save is never overwritten without a snapshot")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        store.put("Pokemon_Emerald", progress(5), modified = 1)        // hand-placed, OLD
        store.put("Pokemon_Emerald_a228ff3e", progress(6), modified = 5)
        val chooser = ScriptedChooser { null }          // never asked: the per-build file is newer, so it is adopted
        store.failSnapshot = true
        val r = resolver(store, reg, chooser)
        val res = r.resolve(gameOrig)
        checkEq(res.outcome, BatteryResolution.Outcome.FAILED, "cannot snapshot -> refuses to overwrite")
        check(store.data("Pokemon_Emerald")!!.contentEquals(progress(5)), "existing save intact")
    }

    section("Resolver: steady state does almost no work")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        r.resolve(gameOrig)                      // first load: unifies
        store.statCalls = 0; store.scanCalls = 0
        for (i in 1..5) r.resolve(gameOrig)
        checkEq(store.scanCalls, 0, "no folder scans once unified")
        checkEq(store.statCalls, 0, "no file reads once the build is known")
    }

    section("Resolver: names that end in 8 hex digits are not confused with per-build files")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        val dated = RomIdentity("Hack_20261026", "deadbeef")
        val plain = RomIdentity("Hack", "cafebabe")
        r.resolve(dated)
        store.put(dated.batteryKey, progress(4))                    // the in-game save the app writes for the dated ROM
        checkEq(dated.batteryKey, "Hack_20261026_", "dated ROM's in-game save key")
        check(store.files.containsKey("Hack_20261026_.sav") && !store.files.containsKey("Hack_20261026.sav"), "file name")
        val res = r.resolve(plain)
        checkEq(res.outcome, BatteryResolution.Outcome.SHARED, "plain 'Hack' does not adopt the dated ROM's save")
        check(store.data("Hack") == null, "no foreign save was copied into 'Hack'")
    }

    section("Resolver: second window (p2-) is independent")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        store.put("Pokemon_Emerald_a228ff3e", progress(1))
        val p2 = RomIdentity("p2-Pokemon_Emerald", "a228ff3e")
        val res = r.resolve(p2)
        checkEq(res.key, "p2-Pokemon_Emerald", "own namespace")
        checkEq(res.outcome, BatteryResolution.Outcome.SHARED, "does not adopt player one's save")
    }

    section("Resolver: unknown CRC")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        val noCrc = RomIdentity("Game", null)
        check(r.resolve(noCrc).key == "Game", "name-keyed save")
        check(reg.builds("Game").isEmpty(), "no build recorded without a CRC")
    }

    section("Resolver: first open by another build snapshots a real save; a fresh one is not worth a copy")
    run {
        val store = FakeStore(); val reg = FakeRegistry(); val chooser = ScriptedChooser { null }
        val r = resolver(store, reg, chooser)
        store.put("G", bytes(0xFF))
        r.resolve(RomIdentity("G", "11111111"))
        store.put("G", progress(3))
        r.resolve(RomIdentity("G", "22222222"))
        check(store.snapshotNames().contains("G.sav.before-22222222"), "second build -> snapshot of the real save")
        check(store.snapshotNames().none { it.endsWith("before-11111111") }, "first build -> none")
        store.put("G", progress(4))
        r.resolve(RomIdentity("G", "22222222"))
        check(store.files["G.sav.before-22222222"]!!.data.contentEquals(progress(3)), "snapshot is taken once, never refreshed")
        // snapshot failure -> retried next time, build not recorded
        store.failSnapshot = true
        r.resolve(RomIdentity("G", "33333333"))
        check("33333333" !in reg.builds("G"), "not recorded while the snapshot failed")
        store.failSnapshot = false
        r.resolve(RomIdentity("G", "33333333"))
        check(store.snapshotNames().contains("G.sav.before-33333333"), "retried")
        check("33333333" in reg.builds("G"), "recorded once snapshotted")
    }
}

// ── Autosave vs. the shared in-game save ────────────────────────────────────────────────────────────────────────

private fun testAutosaveGuard() {
    val orig = RomIdentity("Pokemon_Emerald", "a228ff3e")
    val patched = RomIdentity("Pokemon_Emerald", "3632fca4")

    section("Autosave guard: a build's autosave is only loaded while it still describes the shared in-game save")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        val r = resolver(store, reg, ScriptedChooser { null })
        store.put("Pokemon_Emerald_a228ff3e", progress(1))

        val first = r.resolve(patched)                      // the renamed patch's first launch
        checkEq(first.outcome, BatteryResolution.Outcome.ADOPTED, "patch adopts the original's save")
        check(!first.autosaveMatchesSave, "another build's save was carried in: the patch's own old autosave is stale")
        r.sessionStarted(patched)

        store.put("Pokemon_Emerald", progress(2))           // the patch plays and saves in-game
        check(r.resolve(patched).autosaveMatchesSave, "same build again, nobody else played in between: its autosave fits")
        r.sessionStarted(patched)

        val back = r.resolve(orig)                          // the ORIGINAL is opened again
        checkEq(back.outcome, BatteryResolution.Outcome.SHARED, "no second adoption")
        check(!back.autosaveMatchesSave, "the original's autosave predates the patch's progress: loading it would rewind the save")
        r.sessionStarted(orig)
        check(r.resolve(orig).autosaveMatchesSave, "...until the original has played on the shared save itself")
        check(!r.resolve(patched).autosaveMatchesSave, "and then it is the patch's autosave that is stale")
    }

    section("Autosave guard: first load of a name")
    run {
        // Own old file carried over: the autosave was written right next to it.
        val s1 = FakeStore(); val r1 = FakeRegistry()
        s1.put("G_11111111", progress(1))
        val own = resolver(s1, r1, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111"))
        checkEq(own.outcome, BatteryResolution.Outcome.ADOPTED, "own old save adopted")
        check(own.autosaveMatchesSave, "adopted from this build's own old file -> its autosave fits")

        // Nothing saved anywhere: nothing a state could rewind.
        val s2 = FakeStore(); val r2 = FakeRegistry()
        check(resolver(s2, r2, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111")).autosaveMatchesSave,
            "no save anywhere -> fits")

        // Only a fresh (never saved in) per-build file: still nothing to rewind.
        val s3 = FakeStore(); val r3 = FakeRegistry()
        s3.put("G_11111111", bytes(0xFF))
        check(resolver(s3, r3, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111")).autosaveMatchesSave,
            "only a never-saved file -> fits")

        // A real name-keyed file in place and no real per-build file of this build: the autosave may belong to
        // something else.
        val s4 = FakeStore(); val r4 = FakeRegistry()
        s4.put("G", progress(3))
        val handPlaced = resolver(s4, r4, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111"))
        checkEq(handPlaced.outcome, BatteryResolution.Outcome.SHARED, "the real name-keyed file is simply used")
        check(!handPlaced.autosaveMatchesSave, "real name-keyed save, no matching per-build file -> not provably the autosave's save")

        // ...but when this build's own old file holds the very same bytes, it is.
        val s5 = FakeStore(); val r5 = FakeRegistry()
        s5.put("G", progress(3), modified = 10); s5.put("G_11111111", progress(3), modified = 20)
        val same = resolver(s5, r5, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111"))
        checkEq(same.outcome, BatteryResolution.Outcome.SHARED, "identical files -> nothing to carry over")
        check(same.autosaveMatchesSave, "own old file identical to the name-keyed one -> fits")

        // A blank name-keyed file (the core creates one on its first run) is not a save: nothing to rewind.
        val s8 = FakeStore(); val r8 = FakeRegistry()
        s8.put("G", bytes(0xFF))
        check(resolver(s8, r8, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111")).autosaveMatchesSave,
            "blank name-keyed file, nothing else -> fits")

        // The player answers a question: keeping the OWN file fits, keeping another build's does not.
        val s6 = FakeStore(); val r6 = FakeRegistry()
        s6.put("G_11111111", progress(1), modified = 100); s6.put("G_22222222", progress(2), modified = 200)
        val keepOwn = resolver(s6, r6, ScriptedChooser { o -> o.first { it.crc == "11111111" } }).resolve(RomIdentity("G", "11111111"))
        check(keepOwn.autosaveMatchesSave, "picked this build's own save -> fits")
        val s7 = FakeStore(); val r7 = FakeRegistry()
        s7.put("G_11111111", progress(1), modified = 100); s7.put("G_22222222", progress(2), modified = 200)
        val keepOther = resolver(s7, r7, ScriptedChooser { o -> o.first { it.crc == "22222222" } }).resolve(RomIdentity("G", "11111111"))
        check(!keepOther.autosaveMatchesSave, "picked another build's save -> this build's autosave is stale")
    }

    section("Autosave guard: running on the build's own file (decide later / failed copy) never holds an autosave back")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        store.put("G_11111111", progress(1), modified = 100); store.put("G_22222222", progress(2), modified = 200)
        val deferred = resolver(store, reg, ScriptedChooser { null }).resolve(RomIdentity("G", "11111111"))
        checkEq(deferred.outcome, BatteryResolution.Outcome.DEFERRED, "deferred")
        check(deferred.autosaveMatchesSave, "the build's own file and its own autosave belong together")
        store.failCopy = true
        val failed = resolver(store, FakeRegistry(), ScriptedChooser { o -> o.first() }).resolve(RomIdentity("G", "11111111"))
        checkEq(failed.outcome, BatteryResolution.Outcome.FAILED, "failed copy")
        check(failed.autosaveMatchesSave, "...same")
    }

    section("Autosave guard: unknown CRC and bookkeeping")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        val r = resolver(store, reg, ScriptedChooser { null })
        store.put("G_11111111", progress(1))
        val noCrc = RomIdentity("G", null)
        check(r.resolve(noCrc).autosaveMatchesSave, "unknown CRC cannot be tracked -> behaves as before")
        r.sessionStarted(noCrc)
        check(reg.last.isEmpty(), "sessionStarted with no CRC records nothing")
        check(r.resolve(noCrc).autosaveMatchesSave, "...and still never holds anything back")

        r.sessionStarted(RomIdentity("G", "11111111"))
        checkEq(reg.last["G"], "11111111", "sessionStarted records the build")
        r.sessionStarted(RomIdentity("G", "22222222"))
        checkEq(reg.last["G"], "22222222", "...and the latest one wins")
        check(reg.last.keys == setOf("G"), "only that name was touched")
    }

    section("Autosave guard: second window has its own namespace")
    run {
        val store = FakeStore(); val reg = FakeRegistry()
        val r = resolver(store, reg, ScriptedChooser { null })
        val p1 = RomIdentity("Game", "11111111"); val p2 = RomIdentity("p2-Game", "11111111")
        r.resolve(p1); r.resolve(p2)
        r.sessionStarted(p1)
        check(r.resolve(p1).autosaveMatchesSave, "window 1 fits")
        check(!r.resolve(p2).autosaveMatchesSave, "window 2 has not run on its own save yet: nothing is recorded for it")
        r.sessionStarted(p2)
        check(r.resolve(p2).autosaveMatchesSave, "window 2 fits after its own session")
        check(r.resolve(p1).autosaveMatchesSave, "...and window 1 is unaffected")
    }
}

// ── StateSiblings ───────────────────────────────────────────────────────────────────────────────────────────────

private fun testStateSiblings() {
    section("StateSiblings")
    fun f(n: String, size: Long = 10, m: Long = 1) = NamedFile(n, size, m)
    val files = listOf(
        f("G_a228ff3e.sav", 128, 50), f("G_a228ff3e.state1", 1000, 100), f("G_a228ff3e.state1.png", 500, 100),
        f("G_bbbbbbbb.state2", 1000, 300), f("G_bbbbbbbb.autosave", 1000, 400),
        f("G_cccccccc.state1.png", 500, 900),                       // thumbnail only
        f("G_dddddddd.state1", 0, 900),                              // empty
        f("G_3632fca4.state1", 1000, 800),                           // own build
        f("H_eeeeeeee.state1", 1000, 999), f("G.state1", 1000, 999), f("G_ffffffff.sav", 1000, 999)
    )
    val s = StateSiblings.find("G", "3632fca4", files)
    check(s != null && s.crc == "bbbbbbbb" && s.key == "G_bbbbbbbb" && s.modified == 400L, "newest other build with real states: $s")
    check(StateSiblings.find("G", "bbbbbbbb", files)?.crc == "3632fca4", "with bbbbbbbb as the own build, the newest remaining one is picked")
    check(StateSiblings.find("G", "bbbbbbbb", files.filter { !it.name.startsWith("G_3632fca4") })?.crc == "a228ff3e", "...and the next one when that is gone")
    check(StateSiblings.find("G", "3632fca4", listOf(f("G_a228ff3e.sav"), f("G_cccccccc.state1.png"))) == null, "no sibling when only saves/thumbnails exist")
    check(StateSiblings.hasStates("G_3632fca4", files), "own build has a state")
    check(!StateSiblings.hasStates("G_cccccccc", files), "thumbnail alone is not a state")
    check(!StateSiblings.hasStates("G_dddddddd", files), "empty state file is not a state")
    check(!StateSiblings.hasStates("G_a228ff3e", listOf(f("G_a228ff3e.sav"))), "battery save is not a state")
    check(StateSiblings.hasStates("G_bbbbbbbb", files), "autosave counts")
}

// ── SessionPersister ────────────────────────────────────────────────────────────────────────────────────────────

private fun testPersister() {
    section("SessionPersister")
    val errors = ArrayList<String>()
    val p = SessionPersister("test-persist") { label, _ -> synchronized(errors) { errors += label } }

    val order = ArrayList<Int>()
    val threads = HashSet<String>()
    for (i in 1..20) p.submit("job$i") { synchronized(order) { order += i; threads += Thread.currentThread().name } }
    check(p.awaitIdle(2000), "idle after the queue drains")
    checkEq(order, (1..20).toList(), "jobs run in submission order")
    checkEq(threads, setOf("test-persist"), "all on the one background thread")

    p.submit("boom") { throw IllegalStateException("x") }
    val after = AtomicInteger()
    p.submit("after") { after.incrementAndGet() }
    check(p.awaitIdle(2000), "idle after a failing job")
    checkEq(after.get(), 1, "a job that throws does not stop the next one")
    checkEq(errors, listOf("boom"), "the failure was reported once")

    // A stuck job: awaitIdle gives up on time instead of hanging the caller.
    val release = CountDownLatch(1)
    val started = CountDownLatch(1)
    p.submit("stuck") { started.countDown(); release.await() }
    started.await(2, TimeUnit.SECONDS)
    val t0 = System.nanoTime()
    check(!p.awaitIdle(200), "awaitIdle reports 'still busy'")
    val waited = (System.nanoTime() - t0) / 1_000_000
    check(waited in 150..1500, "...after about the timeout, not never (waited $waited ms)")

    // Submitting never blocks, even behind a stuck job.
    val t1 = System.nanoTime()
    val fut = p.submit("queued") { }
    check((System.nanoTime() - t1) / 1_000_000 < 100, "submit returns immediately behind a stuck job")
    check(fut != null && !p.await(fut, 100), "the queued job has not run yet")
    release.countDown()
    check(p.awaitIdle(2000), "everything drains once the stuck job is released")
    check(fut != null && p.await(fut, 1000), "the queued job ran")

    // Idle thread retires (daemon + keepalive) — only check it is a daemon so it can never hold the process open.
    val daemon = java.util.concurrent.atomic.AtomicBoolean(false)
    p.submit("daemon?") { daemon.set(Thread.currentThread().isDaemon) }
    p.awaitIdle(1000)
    check(daemon.get(), "worker is a daemon thread")

    p.shutdown()
    check(p.submit("late") { } == null, "no jobs after shutdown")
    check(p.awaitIdle(100), "awaitIdle after shutdown returns at once")
}


// ── SaveStateGate (audit: ROM switch vs. an in-flight save/load) ──────────────────────────────────────────────────

/**
 * A model of the two sides of the race, built from the real [SaveStateGate]. A save is tied to a game when it is
 * REQUESTED (`tap()`: the slot is resolved from the game running now — MainActivity.currentRomBaseName) but reaches
 * "native" later (`stage` stands for stageForWrite(): a slow Storage-folder provider), where it snapshots whichever
 * core is live — `core`, which g_core_mutex makes atomic and nothing more. A ROM load (`beginSwap()`) clears
 * `romLoaded` synchronously, does its own staging on a loader thread, and then replaces the core. [swapTakesGuard]
 * switches between the fixed protocol (the swap waits for the guard and holds it across the replacement) and the old
 * one (it does not look at the guard at all).
 */
private class SwapRaceModel(private val swapTakesGuard: Boolean) {
    private val gate = SaveStateGate()
    @Volatile var core = "A"           // the game in the native core
    @Volatile var currentName = "A"    // MainActivity.currentRomBaseName: published AFTER the swap, before romLoaded
    private val romLoaded = AtomicBoolean(true)
    val wrongGame = AtomicInteger()    // operations that filed one game's state/thumbnail under another game's slot
    val completed = AtomicInteger()
    val swapsDone = AtomicInteger()
    val swapsRefused = AtomicInteger()
    val tapsRefused = AtomicInteger()

    /** A Quick Save tap, on the "UI thread". Returns the worker thread, or null for a refused tap. */
    fun tap(stage: () -> Unit = {}): Thread? {
        if (!romLoaded.get()) { tapsRefused.incrementAndGet(); return null }
        if (!gate.tryAcquire()) { tapsRefused.incrementAndGet(); return null }
        val slotGame = currentName                       // entry = quickStateEntry(), resolved at tap time
        return Thread {
            try {
                stage()                                  // entry.stageForWrite()
                val snapshot = core                      // EmulatorEngine.nativeSaveState(): the live core, right now
                stage()                                  // entry.commitWrite()
                val thumbSlot = currentName              // captureStateThumbnail(): resolves the name AGAIN, later
                if (snapshot != slotGame || thumbSlot != slotGame) wrongGame.incrementAndGet()
                completed.incrementAndGet()
            } finally {
                gate.release()
            }
        }.also { it.start() }
    }

    /** A ROM load, on the "UI thread" (romLoaded goes false here, synchronously). Returns the loader thread. */
    fun beginSwap(next: String, staging: () -> Unit = {}): Thread {
        romLoaded.set(false)
        return Thread {
            staging()                                    // stageRomFile() ...
            val owned = !swapTakesGuard || gate.acquire(5_000)
            if (!owned) {                                // refused: the running game is put back
                swapsRefused.incrementAndGet()
                romLoaded.set(true)
            } else {
                try {
                    core = next                          // nativeLoadROM()
                } finally {
                    if (swapTakesGuard) gate.release()
                }
                currentName = next                       // the UI-thread post, then ...
                romLoaded.set(true)                      // ... romLoaded = true
                swapsDone.incrementAndGet()
            }
        }.also { it.start() }
    }
}

private fun testSaveStateGate() {
    section("SaveStateGate: one operation at a time")
    run {
        val g = SaveStateGate()
        check(!g.isBusy, "a new guard is free")
        check(g.tryAcquire() && g.isBusy, "a tap on a free guard gets it")
        check(!g.tryAcquire(), "a second tap while one operation runs is refused (silent no-op)")
        check(!g.acquire(0), "a zero timeout is a plain try: it does not get a held guard either")
        g.release()
        check(!g.isBusy && g.tryAcquire(), "released: free again")
        g.release()
    }

    section("SaveStateGate: never two holders at once, however many threads fight over it")
    run {
        val g = SaveStateGate()
        val inside = AtomicInteger()
        val maxInside = AtomicInteger()
        val entered = AtomicInteger()
        val threads = (0 until 8).map { id ->
            Thread {
                repeat(250) { i ->
                    val got = if ((i + id) % 3 == 0) g.acquire(3_000) else g.tryAcquire()
                    if (got) {
                        try {
                            val n = inside.incrementAndGet()
                            maxInside.updateAndGet { m -> maxOf(m, n) }
                            entered.incrementAndGet()
                            if (i % 50 == 0) Thread.sleep(1)
                            inside.decrementAndGet()
                        } finally {
                            g.release()
                        }
                    }
                }
            }.also { it.start() }
        }
        threads.forEach { it.join(30_000) }
        checkEq(maxInside.get(), 1, "at most one thread was ever inside")
        check(entered.get() > 100, "and the guard really was taken many times (${entered.get()})")
        check(!g.isBusy, "free at the end")
    }

    section("SaveStateGate: acquire() waits for the holder, but only as long as asked")
    run {
        val g = SaveStateGate()
        check(g.tryAcquire(), "(setup) a holder")
        val releaser = Thread { Thread.sleep(80); g.release() }.also { it.start() }
        val t0 = System.nanoTime()
        val got = g.acquire(10_000)
        val waitedMs = (System.nanoTime() - t0) / 1_000_000
        check(got, "waits for the holder and then gets it")
        check(waitedMs in 60..5_000, "... after about the holder's 80 ms, not at once and not at the timeout (was $waitedMs ms)")
        g.release()
        releaser.join()

        val stuck = SaveStateGate()
        stuck.tryAcquire()
        val s0 = System.nanoTime()
        val gotStuck = stuck.acquire(150)
        val stuckMs = (System.nanoTime() - s0) / 1_000_000
        check(!gotStuck, "a holder that never lets go: gives up (false)")
        check(stuckMs in 140..3_000, "... after about the 150 ms timeout (was $stuckMs ms)")
        check(stuck.isBusy, "... and the holder still has it — a timed-out waiter never steals the guard")

        val interruptedGate = SaveStateGate()
        interruptedGate.tryAcquire()
        var result: Boolean? = null
        var flagKept = false
        val waiter = Thread {
            result = interruptedGate.acquire(60_000)
            flagKept = Thread.currentThread().isInterrupted
        }.also { it.start() }
        Thread.sleep(50)
        waiter.interrupt()
        waiter.join(5_000)
        check(result == false && flagKept, "an interrupted waiter returns false and keeps its interrupt flag")
    }
}

private fun testSwapVersusSave() {
    section("ROM switch vs. a save already in flight: the OLD protocol files the new game's state in the old game's slot")
    run {
        val old = SwapRaceModel(swapTakesGuard = false)
        val staging = CountDownLatch(1)
        val worker = old.tap(stage = { staging.await(5, TimeUnit.SECONDS) })!!   // tapped on game A, stuck in a slow stage
        val loader = old.beginSwap("B")                                          // the player picks another ROM meanwhile
        loader.join(5_000)                                                       // swap A -> B completes right under the save
        staging.countDown()
        worker.join(5_000)
        checkEq(old.core, "B", "(model) the core was replaced while the save was in flight")
        check(old.wrongGame.get() > 0, "the old protocol saved game B's state into game A's slot — the model can see the bug")
    }

    section("ROM switch vs. a save already in flight: with the swap taking the guard, the save finishes first, on A")
    run {
        val fixed = SwapRaceModel(swapTakesGuard = true)
        val staging = CountDownLatch(1)
        val worker = fixed.tap(stage = { staging.await(5, TimeUnit.SECONDS) })!!
        val loader = fixed.beginSwap("B")
        Thread.sleep(150)                                                        // the swap has had every chance to overtake
        checkEq(fixed.core, "A", "the core is NOT replaced while the save is still in flight")
        check(fixed.tap() == null, "a second tap during the swap is refused (romLoaded is false)")
        staging.countDown()
        worker.join(5_000)
        loader.join(5_000)
        checkEq(fixed.completed.get(), 1, "the save completed")
        checkEq(fixed.wrongGame.get(), 0, "... against the game it was requested for, with its thumbnail under the same game")
        checkEq(fixed.core, "B", "and only then was the core replaced")
        checkEq(fixed.swapsDone.get(), 1, "the swap went through")
        val after = fixed.tap()
        check(after != null, "once the new game is up, a tap is accepted again")
        after?.join(5_000)
        checkEq(fixed.wrongGame.get(), 0, "... and that save is of the new game, filed under the new game")
    }

    section("ROM switch vs. a save that never finishes (hung provider): the swap is refused, the game keeps running")
    run {
        val hung = SwapRaceModel(swapTakesGuard = true)
        // The model's swap waits 5 s; use a guard of our own to show the refusal path without a 5 s test.
        val g = SaveStateGate()
        check(g.tryAcquire(), "(setup) an operation that never ends")
        check(!g.acquire(100), "a swap waiting on it gives up after its bounded wait instead of replacing the core")
        g.release()
        check(hung.tap()?.also { it.join(5_000) } != null, "(control) an idle model still saves normally")
    }

    section("ROM switch vs. saves, randomized: 40 switches among 3 games under a stream of Quick Saves — never a wrong game")
    run {
        val m = SwapRaceModel(swapTakesGuard = true)
        val rnd = java.util.Random(20261030L)
        val games = listOf("A", "B", "C")
        val workers = ArrayList<Thread>()
        var loader: Thread? = null
        var next = 1
        val jitter = { Thread.sleep(rnd.nextInt(3).toLong()) }
        repeat(900) { step ->
            Thread.sleep(rnd.nextInt(2).toLong())
            val l = loader
            if (l != null && !l.isAlive) loader = null
            if (loader == null && step % 20 == 0 && m.swapsDone.get() < 40) {
                loader = m.beginSwap(games[next % 3], staging = jitter)
                next++
            } else {
                m.tap(stage = jitter)?.let { workers += it }
            }
        }
        loader?.join(10_000)
        workers.forEach { it.join(10_000) }
        check(m.swapsDone.get() >= 20, "enough switches really happened (${m.swapsDone.get()})")
        check(m.completed.get() >= 100, "and enough saves (${m.completed.get()}, ${m.tapsRefused.get()} taps refused while busy or switching)")
        checkEq(m.wrongGame.get(), 0, "no save was ever filed under a game it was not taken from")
        checkEq(m.swapsRefused.get(), 0, "no switch was refused (every save here is short)")
    }
}

/** The protocol above only helps if the real call sites use it: a source check, so a new nativeLoadROM() caller that
 *  skips the guard — or a refactor that drops it from one of the two — fails here instead of shipping. */
private fun testSwapWiring() {
    section("wiring: every native core swap in the app takes the guard first and gives it back in a finally")
    val dir = File("../../app/src/main/kotlin/com/mgba/android")
    check(dir.isDirectory, "(setup) the Kotlin source directory is where run.sh runs the test from: ${dir.absolutePath}")
    if (!dir.isDirectory) return
    val sites = ArrayList<Pair<File, Int>>()
    for (f in dir.listFiles { x -> x.name.endsWith(".kt") }!!.sortedBy { it.name }) {
        val text = f.readText()
        var from = 0
        while (true) {
            val i = text.indexOf("nativeLoadROM(", from)
            if (i < 0) break
            val lineStart = text.lastIndexOf('\n', i) + 1
            val line = text.substring(lineStart, text.indexOf('\n', i).let { if (it < 0) text.length else it }).trim()
            if (!line.startsWith("//") && !line.startsWith("*") && !line.contains("external fun")) sites += f to i
            from = i + 1
        }
    }
    checkEq(sites.map { it.first.name }, listOf("MainActivityDebugLog.kt", "MainActivityRom.kt"),
        "nativeLoadROM() is called from exactly loadRomFromUri() and resetGame() — a new caller needs the guard too")
    for ((f, i) in sites) {
        val text = f.readText()
        val before = text.substring(maxOf(0, i - 3_000), i)
        val after = text.substring(i, minOf(text.length, i + 400))
        val acquireAt = before.lastIndexOf("acquireSaveStateBusy(SAVE_STATE_SWAP_WAIT_MS)")
        check(acquireAt >= 0, "${f.name}: the guard is acquired (with the swap wait) before nativeLoadROM()")
        check(before.indexOf("coreGeneration.incrementAndGet()", maxOf(acquireAt, 0)) >= 0,
            "${f.name}: ... and the core generation is bumped only once the guard is held")
        val finallyAt = after.indexOf("finally")
        val releaseAt = after.indexOf("saveStateBusy.release()")
        check(finallyAt in 0 until releaseAt, "${f.name}: ... and released in a finally right after the swap, success or not")
    }
}

fun main() {
    TimeZone.setDefault(TimeZone.getTimeZone("UTC"))
    testKeys()
    testAnalyzer()
    testPlanner()
    testResolver()
    testAutosaveGuard()
    testStateSiblings()
    testPersister()
    testSaveStateGate()
    testSwapVersusSave()
    testSwapWiring()
    println()
    if (failures.isEmpty()) {
        println("ALL $checks CHECKS PASSED")
    } else {
        println("${failures.size} of $checks CHECKS FAILED")
        exitProcess(1)
    }
}
