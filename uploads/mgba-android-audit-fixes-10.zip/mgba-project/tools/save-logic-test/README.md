# save-logic-test

Host-side tests for `app/src/main/kotlin/com/mgba/android/saves/` — the pure-Kotlin part of "the in-game save is
keyed by the game's name" and "closing the game no longer waits on storage". They need only a Kotlin compiler
(`kotlinc`, any 1.9+ / 2.x) and a JDK 17+; no Android, no Gradle, no JUnit.

```
KOTLINC=/path/to/kotlinc/bin/kotlinc ./run.sh      # prints "ALL <n> CHECKS PASSED", exit code 1 on any failure
```

`run.sh` compiles the **real** `saves/*.kt` next to `SaveLogicTest.kt`, so a test cannot drift from the shipping code.
The Android pieces (files in the app folder / Storage folder, SharedPreferences, the dialog) are replaced by the
in-memory fakes at the top of the test (`FakeStore`, `FakeRegistry`, `ScriptedChooser`).

| section | what it pins down |
|---|---|
| SaveKeys | name sanitising, `<name>.sav` vs `<name>_<crc>.<ext>`, the extra `_` for names that end in 8 hex digits, state file names |
| SaveContentAnalyzer | "played into" = not empty, not all 0x00, not all 0xFF; size and digest |
| BatteryAdoption | one save -> adopt, two different -> ask (newest first), identical bytes count once, old name-only file vs a newer per-build file, unknown dates prove nothing |
| Resolver | the reported case (patch renamed to the original's name), snapshots before anything is overwritten, failed copy / "decide later" fall back and retry, steady state does no folder scans, second window is its own game |
| Autosave guard | an autosave is only loaded while it still describes the shared save (`autosaveMatchesSave`), across alternating builds, first loads, answered questions and unknown CRCs |
| StateSiblings | which other build's save states are offered |
| SessionPersister | FIFO on one daemon thread, a failing job does not stop the next, bounded waits, `submit` never blocks behind a stuck job |
| SaveStateGate | one save/load at a time (a tap on a busy guard is a silent no-op), a bounded wait that gives up, an interrupted waiter, release |
| ROM switch vs. save/load | a model on real threads: under the old protocol (the swap never looks at the guard) a save in flight when the core is replaced files the new game's state under the old game; with the swap taking the guard it never does — also in a randomized run of 40 switches among 3 games; a switch is refused, not forced, when a save never finishes |
| swap wiring | a scan of every Kotlin source: `nativeLoadROM(` is called from exactly `loadRomFromUri()` and `resetGame()`, each takes the guard (with the swap wait) first and releases it in a `finally` |

A mutation check (breaking the logic on purpose, one change at a time, and confirming a test fails) was used while
writing these; a change to `saves/` should keep every section meaningful the same way.
