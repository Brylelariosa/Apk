# native-link-test

Host-side tests for the multiplayer code in `app/src/main/cpp/` — they need only `gcc` and `python3`.
`extract.py` cuts the **real** functions out of `mgba_jni.c` (so a test can't drift from the shipping code)
and the tests compile them against the tiny JNI/mGBA stand-ins in `link_test_stubs.h`.

| script | what it runs | time |
|---|---|---|
| `run.sh` | `test_mailbox.c` — the child's lock-step mailbox, under ASan+UBSan and ThreadSanitizer (a TSan report is shown in full and fails the script) | ~10 s |
| `run_regs.sh` | `test_sio_regs.c` — SIO register semantics, the clock-tie tick, the child's tick-driven delivery / hold / governor, `nativeLinkStart/Stop`; `test_log.c` — the real log-file code (format, rotation, concurrent writers) | ~15 s |
| `run_sim.sh` | `sim_dev.c` ×2 — **two simulated phones** (separate processes running the real link code) joined by UDP with an artificial delay: old behaviour (reproduces the captured failure), new behaviour over Wi-Fi / poor Wi-Fi / Bluetooth-like delay, packet loss, a not-ready child, a frozen child | ~2 min |

The simulation's ROM is a **model** built from the two real captures (a host that probes with a 16-word packet,
a child whose ROM resets its link hardware if a packet isn't complete within 6 of its own frames). It checks
that the code does what the clock-tie fix claims and cannot deadlock; it cannot say what a particular real ROM does.

## Pass 8 additions (smooth link)
- `link_test_stubs.h` models the split-phase methods (`jniExchangeBegin` / `jniExchangeEnd` /
  `jniLastRttUs`) with hooks (`g_begin_hook`, `g_end_hook`, `g_rtt_hook`); `g_smooth_methods_present = 0`
  reproduces a Kotlin side that lacks them.
- `test_sio_regs.c` — 33 new assertions: the Start write returns at once with Start/Busy set, the answer
  is collected only when the transfer completes, the adaptive transfer time follows the measured round
  trip (grows when a collect had to wait, shortens slowly when it did not, capped, unmoved by a timeout),
  answers given locally (peer absent / not in multi mode), teardown with a request in flight, the
  blocking fallback when the completion event is still queued, and the `nativeLinkStart` variants.
- `sim_dev.c` takes an 11th argument (`smooth`, 0/1) and models Begin/End with a delay line so the
  one-way delay is not paid inside the send; `run_sim.py` scenarios 8-14 compare it with the blocking
  exchange at 2 ms, 0.15 ms (local link), 3 ms and 15 ms one-way, under loss, with a late child and with a
  frozen child. Scenario 6's "0 resets at 1% loss" is statistical — one reset in a single run is noise.
- Run each scenario on its own if your sandbox kills long background jobs (each is 10-40 s).

## Pass 12 (ThreadSanitizer)
- `test_mailbox.c`: the fake game thread and the main thread shared `FakeChild.run` / `isr_count` as plain ints —
  a data race in the test itself (not in `link_mailbox.h`, whose fields are all accessed under its mutex). Both are
  C11 `atomic_int` now; the fake thread's other writes happen before the `atomic_fetch_add` that publishes them.
- `run.sh` used to pipe the TSan run through `tail -4`, which hid every report behind a passing-looking summary; it now
  prints the whole report and exits non-zero when TSan fails.
