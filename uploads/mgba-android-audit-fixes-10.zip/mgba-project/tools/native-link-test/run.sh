#!/usr/bin/env bash
# Host-side test of link_mailbox.h — the lock-step hand-off between the link
# child's network thread and its game thread. Real pthreads, fake "game
# thread"; runs under ASan/UBSan and then ThreadSanitizer. Needs gcc only.
set -euo pipefail
cd "$(dirname "$0")"
TSAN_LOG="$(mktemp)"
trap 'rm -f "$TSAN_LOG" test_mailbox_asan test_mailbox_tsan' EXIT
gcc -std=gnu11 -Wall -Wextra -g -fsanitize=address,undefined -fno-omit-frame-pointer test_mailbox.c -o test_mailbox_asan -lpthread
./test_mailbox_asan
gcc -std=gnu11 -Wall -Wextra -g -fsanitize=thread test_mailbox.c -o test_mailbox_tsan -lpthread
echo "--- ThreadSanitizer run ---"
# A data race makes the binary exit non-zero. Show the whole report then: this used to pipe the run through
# `tail -4`, which cut every report off and left a passing-looking summary above a failing exit code.
if ./test_mailbox_tsan >"$TSAN_LOG" 2>&1; then
    tail -4 "$TSAN_LOG"
else
    rc=$?
    cat "$TSAN_LOG"
    echo "ThreadSanitizer run FAILED (exit $rc)"
    exit "$rc"
fi
