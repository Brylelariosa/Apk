package com.mgba.android.saves

import java.util.concurrent.atomic.AtomicBoolean

/**
 * The one-at-a-time guard around everything that reads or replaces the native core's state: Quick Save / Quick Load,
 * the slot dialog's save / load / delete, the autosave — and a ROM load or Reset, which replace the core itself.
 *
 * Why the core swap has to take it too. `g_core_mutex` on the native side only makes each native call atomic; it does
 * not decide WHICH core a save/load thread reaches. An operation is tied to a ROM when it is requested (the slot file's
 * name is resolved from the game that was running at that moment) but only touches the core some time later, after the
 * file was staged — possibly through a slow Storage-folder provider. A core swap landing in between made it snapshot
 * the NEW game into the OLD game's slot, load the old game's slot into the new core (an accepted load also puts the
 * state's copy of the in-game save over the live one), or file a thumbnail under the wrong game. While a swap holds
 * this guard no operation can be in flight, and none can start before the replacement is complete.
 *
 * A flag, not a lock: not reentrant, no owner check. The holder is a short-lived worker thread, and a second tap while
 * one operation runs is meant to be a silent no-op ([tryAcquire] returns false). Every acquirer must [release] in a
 * `finally`, or no save, load or ROM change can ever run again.
 *
 * Pure (no Android types), so `tools/save-logic-test` runs the real class on a JVM.
 */
internal class SaveStateGate {
    private val busy = AtomicBoolean(false)

    /** Whether some operation holds the guard right now. For diagnostics and tests; never a substitute for acquiring. */
    val isBusy: Boolean get() = busy.get()

    /** Takes the guard if it is free, without waiting. For a button tap: it arrives while an operation runs → no-op. */
    fun tryAcquire(): Boolean = busy.compareAndSet(false, true)

    /**
     * Takes the guard, waiting up to [timeoutMs] for the current holder to finish. For callers that must not be
     * silently skipped by a stray tap having got there first: the autosave, and the core swap. Returns false if it
     * could not get it in time, or the waiting thread was interrupted (the interrupt flag is kept).
     */
    fun acquire(timeoutMs: Long): Boolean {
        val timeoutNs = timeoutMs.coerceIn(0L, MAX_WAIT_MS) * 1_000_000L
        val startNs = System.nanoTime()
        while (!busy.compareAndSet(false, true)) {
            if (System.nanoTime() - startNs >= timeoutNs) return false
            try {
                Thread.sleep(POLL_MS)
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                return false
            }
        }
        return true
    }

    /** Gives the guard back. Only the thread that acquired it calls this, from a `finally`. */
    fun release() {
        busy.set(false)
    }

    private companion object {
        const val POLL_MS = 10L
        /** A day: far beyond any real wait, and keeps `timeoutMs * 1_000_000` from overflowing a Long. */
        const val MAX_WAIT_MS = 24L * 60L * 60L * 1000L
    }
}
