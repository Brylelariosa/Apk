package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.mgba.android.pacing.FallbackFramePacer
import com.mgba.android.pacing.SpeedPlanner
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt

internal fun MainActivity.startRenderLoop() {
    // Choreographer is thread-affine (it binds to whichever thread first
    // asks for an instance) and stopGameLoop() can be called from a
    // background thread (see romPicker's reload path). Flip the volatile
    // flag immediately — doFrame() checks it before ever rescheduling
    // itself, so that alone halts the loop within one vsync tick — and
    // push the actual Choreographer registration through mainHandler so
    // it's always made from the main thread's Choreographer instance.
    renderLoopActive = true
    mainHandler.post {
        if (renderLoopActive) Choreographer.getInstance().postFrameCallback(renderCallback)
    }
}

internal fun MainActivity.stopRenderLoop() {
    renderLoopActive = false
    mainHandler.post { Choreographer.getInstance().removeFrameCallback(renderCallback) }
}


// ── Game loop ──────────────────────────────────────────────────────────

internal fun MainActivity.startGameLoop() {
    if (running) return
    val bufs = frameBuffers ?: return
    val holder = surfaceHolder ?: return
    val sw = holder.surfaceFrame.width().toFloat()
    val sh = holder.surfaceFrame.height().toFloat()
    if (sw > 0f && sh > 0f) buildControlLayout(sw, sh)   // also calls updateGameMatrix() internally now
    try { audioTrack?.play() } catch (_: Exception) {}
    running = true
    consecutiveFrameSkips = 0
    lastComputeNs = 0L
    fpsFrameCount = 0
    fpsWindowStartNs = 0L
    startRenderLoop()
    // This loop's identity: it runs only while it is the current one (see gameLoopToken).
    val token = gameLoopToken.incrementAndGet()
    gameThread = Thread {
        // Holds every iteration the blocking audio write did not pace to the real frame rate — see
        // FallbackFramePacer. One per loop thread: it starts with no schedule, and a superseded loop can never hand a
        // stale one on to its replacement.
        val fallbackPacer = FallbackFramePacer(FALLBACK_FRAME_NS, FALLBACK_MAX_LAG_NS)
        // How many frames each iteration runs, and how far its audio is stretched below 1x — see SpeedPlanner. Also one
        // per loop thread, so a superseded loop's carried fraction can never leak into its replacement.
        val speedPlanner = SpeedPlanner()
        while (running && gameLoopToken.get() == token) {
            try {
                // FEATURE (this pass): Sound frequency changed in
                // settings while this loop was already running — see
                // audioTrackRebuildPending's own field comment for why
                // the actual rebuild has to happen here, on this
                // thread, rather than immediately from the settings UI
                // itself. Checked before t0 below so a rebuild's own
                // (one-off) cost is never counted against
                // lastComputeNs's "are we behind" measurement.
                if (audioTrackRebuildPending) initAudioTrack()
                val t0 = System.nanoTime()
                // FEATURE: maybeSkipRenderThisFrame's "are we behind"
                // signal. Compares the *previous* iteration's own
                // compute-only duration (lastComputeNs — see that
                // field's own comment for why total wall-clock time
                // was the wrong thing to measure) against one frame's
                // budget: only genuine device slowness trips this now,
                // not the pacer's own intentional wait. The skip
                // decision itself only ever applies to the
                // framesToRun == 1 branch below — fast-forward already
                // has its own, unrelated skip-blit logic for every
                // sub-frame but the batch's last.
                val behindSchedule = lastComputeNs > frameBudgetNs
                // AUDIT FIX (0.5x speed): the frame count and the speed come from SpeedPlanner now. Below 1x the old
                // inline accumulator still ran one frame per iteration and wrote that frame's audio unstretched, so
                // with working audio — the blocking write is the pacer — the "0.5x" setting ran at 1x (only the
                // no-audio fallback divided by the speed); its accumulator also went further negative every
                // iteration. Now 0.5x is one frame per iteration with its audio stretched to two frame periods
                // (audioStretch, applied in writeFramePcm()), so the audio clock paces the loop at the selected
                // speed. `speed` is the sanitised value: the fallback pacer below must see the same one.
                if (!fastForwardActive) speedPlanner.reset()   // as the old accumulator was: nothing carried out of a fast-forward
                val framesToRun = speedPlanner.plan(if (fastForwardActive) fastForwardSpeed else 1f)
                val speed = speedPlanner.speed
                val audioStretch = speedPlanner.audioStretch

                EmulatorEngine.nativeSetKeys(effectiveKeysForCore())
                // True once writePcm() has taken every sample of this iteration, i.e. its blocking write has held the
                // loop to the audio clock. It stays false when there was nothing to write or the write did not pace
                // the loop (no AudioTrack, an error, no progress) — the pacing step at the bottom then takes over.
                var audioPaced = false
                // FIX (this pass): reported as flickering / flashing white
                // screen once Max frame skips was actually turned on.
                // Root cause: a skipped frame was still going through the
                // *publish* step below unconditionally — readyIdx claimed
                // whatever buffer writeIdx pointed at even though
                // nativeRunFrame(null) never wrote a single pixel into it
                // this iteration. Early on, or after several skips in a
                // row, that buffer can be one none of the 3 have ever
                // actually been rendered into yet — publishing it hands
                // the Choreographer renderer genuinely uninitialized
                // bitmap contents to draw, which is exactly a "flash of
                // garbage" (often reading as white). Fast-forward's own
                // sub-frame skipping never had this problem — every
                // batch's *last* sub-frame still always writes real
                // pixels into backBmp before the one publish at the end —
                // only this pass's new normal-speed skip path shared the
                // unconditional publish without sharing that guarantee.
                // Fixed by moving the publish inside the "a real render
                // actually happened" branch: a skipped frame now claims
                // no buffer and changes nothing about readyIdx/displayIdx
                // at all, so the renderer just keeps showing whatever it
                // was already showing — the correct, safe meaning of
                // "skip this frame's visual update."
                val skipBlit = framesToRun == 1 && maxFrameSkips > 0 &&
                    behindSchedule && consecutiveFrameSkips < maxFrameSkips
                if (skipBlit) {
                    EmulatorEngine.nativeRunFrame(null)
                    consecutiveFrameSkips++
                    val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                    // FIX (this pass): captured here — after the actual
                    // work, before the blocking write below — so the
                    // *next* iteration's behindSchedule check reflects
                    // real compute time, not the pacer's wait. See
                    // lastComputeNs's own field comment.
                    lastComputeNs = System.nanoTime() - t0
                    if (n > 0) audioPaced = writeFramePcm(n, audioStretch)   // blocking — this *is* the frame pacer now, deliberately timed outside lastComputeNs
                } else {
                    consecutiveFrameSkips = 0
                    // Sub-frames of a fast-forward batch all render into
                    // the same back buffer — only the last one ends up on
                    // screen, same as before; only the publish step below
                    // is new.
                    val backBmp = bufs[writeIdx]
                    if (framesToRun == 1) {
                        EmulatorEngine.nativeRunFrame(backBmp)
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        lastComputeNs = System.nanoTime() - t0   // see the FIX note in the skipBlit branch above
                        if (n > 0) audioPaced = writeFramePcm(n, audioStretch)   // blocking — this *is* the frame pacer now, deliberately timed outside lastComputeNs
                    } else {
                        // Fast-forward batch: run every sub-frame, collecting
                        // each one's audio into ffAccumBuffer instead of
                        // discarding it, then compress the whole batch down
                        // to about one frame's worth (decimateForFastForward)
                        // so it can go through the same blocking writePcm()
                        // pacer below — see the audio-architecture note above.
                        var accumPairs = 0
                        for (i in 0 until framesToRun) {
                            // PERF: only the LAST sub-frame in the batch is
                            // ever displayed (see the buffer-publish step
                            // below), so earlier ones pass null and skip the
                            // pixel-copy blit entirely — see FIX 5 in
                            // mgba_jni.c. Emulation and audio still run in
                            // full for every sub-frame.
                            val bmpForThisSubFrame = if (i == framesToRun - 1) backBmp else null
                            EmulatorEngine.nativeRunFrame(bmpForThisSubFrame)
                            val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                            if (n > 0 && accumPairs + n <= ffAccumBuffer.size / 2) {
                                System.arraycopy(audioBuffer, 0, ffAccumBuffer, accumPairs * 2, n * 2)
                                accumPairs += n
                            }
                        }
                        // Skip-decision timing normally doesn't apply
                        // here (skipBlit only ever gates framesToRun ==
                        // 1, never a fast-forward batch — see
                        // behindSchedule's own comment above), but
                        // lastComputeNs is still refreshed on this
                        // branch too so it isn't a stale pre-fast-
                        // forward reading the instant fast-forward ends
                        // and framesToRun == 1 resumes next iteration.
                        lastComputeNs = System.nanoTime() - t0
                        if (accumPairs > 0) {
                            val outPairs = decimateForFastForward(accumPairs, framesToRun)
                            if (outPairs > 0) audioPaced = writePcm(outPairs)
                        }
                    }

                    // Publish the completed frame for the Choreographer
                    // renderer (see the field comments above) and claim
                    // whichever of the 3 buffers is free for next time —
                    // never the one just published or the one the renderer
                    // may currently be drawing. Only ever reached here, on
                    // the branch that actually wrote real pixels into
                    // backBmp — see the FIX note above.
                    synchronized(bufferLock) {
                        readyIdx = writeIdx
                        writeIdx = (0..2).first { it != readyIdx && it != displayIdx }
                    }
                }

                if (showFpsOverlay) {
                    // FEATURE: performance overlay — counts every emulated
                    // GBA frame, so a 4x fast-forward batch counts as 4,
                    // matching the "core FPS" figure emulators
                    // conventionally show. Gated behind the toggle so
                    // there is no counting work at all on this thread —
                    // the one pacing audio — when the overlay is off.
                    if (fpsWindowStartNs == 0L) fpsWindowStartNs = t0
                    fpsFrameCount += framesToRun
                    val windowNs = t0 - fpsWindowStartNs
                    if (windowNs >= 1_000_000_000L) {
                        val fps = fpsFrameCount * 1_000_000_000.0 / windowNs
                        val underruns = try { audioTrack?.underrunCount ?: 0 } catch (_: Exception) { 0 }
                        fpsOverlayText = "%.1f fps  ·  %d underruns".format(fps, underruns)
                        fpsFrameCount = 0
                        fpsWindowStartNs = t0
                    }
                }

                // Pacing. Normal case (audioPaced): writePcm() above already
                // blocked until the audio HAL had room for this batch's
                // samples, which paces the loop against the real device audio
                // clock — no sleep and no drift, whether this iteration ran
                // one GBA frame or a fast-forward batch of them. Rendering is
                // no longer on this thread at all, so a slow frame draw can
                // no longer delay the next audio write.
                //
                // FIX (audit: "audio failure can break performance"): the
                // fallback used to run only for a batch that produced no
                // audio, because `wroteAudio` was set the moment writePcm()
                // was *called* — also when it came straight back having
                // written nothing (no AudioTrack, a write error, a write that
                // made no progress). In exactly the situations the fallback
                // exists for, nothing paced the loop and the core ran as fast
                // as the CPU allows: wrong game speed, a pegged core, a hot
                // phone. writePcm() now reports whether it paced, and every
                // iteration it did not is held to the real GBA frame rate by
                // FallbackFramePacer, per emulated frame at the selected
                // fast-forward speed (the old per-iteration
                // `FALLBACK_FRAME_NS / speed` divided by the speed twice over
                // in a fast-forward batch, and its whole-millisecond sleep
                // truncated up to 1 ms off every frame). The first iteration
                // a write succeeds again hands pacing back to the audio clock.
                val waitNs = fallbackPacer.waitNs(audioPaced, t0, System.nanoTime(), framesToRun, speed)
                // Not while stopping: stopGameLoop() wakes this thread by
                // pausing the track, which makes the write above return
                // early; sleeping out a frame here would only delay the stop.
                if (waitNs > 0L && running && gameLoopToken.get() == token) {
                    Thread.sleep(waitNs / 1_000_000L, (waitNs % 1_000_000L).toInt())
                }
            } catch (_: InterruptedException) { break }
            catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
        }
        // Only the current loop clears the flag: a superseded thread that finally gets here must not switch off the
        // loop that replaced it.
        if (gameLoopToken.get() == token) running = false
    }.also { it.name = "mGBA-loop"; it.start() }
}


internal fun MainActivity.stopGameLoop() {
    running = false
    // PERF (closing a game lagged): wake the game thread BEFORE waiting for it. It is almost always parked inside
    // AudioTrack.write(WRITE_BLOCKING) — that call is the frame pacer, see writePcm() — and a blocking write only
    // returns once the audio hardware has taken the samples or the track changes state under it. Joining first
    // therefore waited out a whole audio buffer on every stop, and the full limit below whenever the track was
    // stalled (Bluetooth output, audio focus lost, a slow HAL) — all of it on the UI thread when the game is closed
    // or the app backgrounded. Pausing the track from this thread interrupts that wait at once (AudioTrack.pause()
    // interrupts a blocked writer, the write returns 0 and writePcm() simply gives up on that frame), and flush()
    // empties what is queued, so a writer that had not reached its write yet finds room instead of blocking on a
    // paused track. Every caller either restarts the loop through startGameLoop(), which calls play() first, or
    // re-creates the track — and previously flushed anyway right after this returned.
    wakeAudioWriter()
    // The join is now only a safety net: the thread leaves its loop as soon as the frame it is in finishes. 750 ms
    // rather than 500 ms for a slow or unusual audio HAL.
    val thread = gameThread
    thread?.join(750)
    // Still running after the first wait: nudge the track once more before giving up on the thread — cheap, and it
    // covers a writer that had not yet reached its blocking write when the first pause() went by.
    if (thread?.isAlive == true) {
        wakeAudioWriter()
        thread?.join(250)
    }
    // FIX (audit F4): hardening only — the comment above already explains
    // why this practically never fires. Checks/interrupts `thread` (the
    // local reference just joined above), not gameThread again, so this
    // can't end up looking at a different Thread than the one that was
    // actually waited on. interrupt() is a safe last-resort signal here
    // specifically because the loop's own catch (_: InterruptedException)
    // break (see startGameLoop() above) already handles it as a clean stop.
    if (thread?.isAlive == true) {
        Log.w(TAG, "Game thread did not stop within 1000ms; interrupting")
        // The thread is abandoned from here on: a later startGameLoop() sets `running` again, and without a new
        // token this thread — still finishing a frame — would see it and carry on next to the new loop, two threads
        // running one core. A new number makes its loop condition false for good.
        gameLoopToken.incrementAndGet()
        // Safe call, not a bare call: `thread?.isAlive == true` does not
        // smart-cast `thread` to non-null (Kotlin doesn't prove non-null
        // through a safe-call-vs-Boolean-literal comparison), even though
        // reaching this line already implies it. Same thread reference
        // either way — this isn't gameThread again, just written null-safely.
        thread?.interrupt()
    }
    gameThread = null
    stopRenderLoop()
}

/** Pauses and flushes the audio track so a game thread parked in its blocking write returns at once — see
 *  [stopGameLoop]. Never throws: the track may be re-created by the game thread at this very moment (a Sound
 *  frequency change), in which case there is nothing to wake. */
private fun MainActivity.wakeAudioWriter() {
    try {
        audioTrack?.pause()
        audioTrack?.flush()
    } catch (_: Exception) {
    }
}


internal fun MainActivity.renderFrame(bmp: Bitmap) {
    val holder = surfaceHolder ?: return
    // PERF: lockHardwareCanvas() (API 23+, always available at our
    // minSdk 24) hands back a GPU-composited canvas instead of the plain
    // software Skia canvas lockCanvas() gives — the scaled drawBitmap()
    // plus the dozen-odd drawRoundRect/drawText calls for the on-screen
    // controls get composited on the GPU instead of the CPU every frame.
    // Falls back to a software canvas automatically on devices/drivers
    // that don't support it, so this is a strict upside with no
    // compatibility risk. Every draw call below (drawColor, drawBitmap
    // with a Matrix, drawRoundRect, drawText, drawCircle) is a basic op
    // fully supported under hardware acceleration — nothing here relies
    // on a software-only Xfermode/PathEffect/Shader.
    val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
    try {
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(bmp, gameMatrix, gamePaint)
        drawControls(canvas)
        if (editModeActive) drawEditOverlay(canvas)
        if (link.isConnected) drawLinkStatus(canvas)
        if (showFpsOverlay) drawFpsOverlay(canvas)
        if (screenRecorder.isRecording) drawRecordingIndicator(canvas)
    } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
}


/** Paints one solid black frame straight onto the SurfaceView, bypassing
 *  the triple-buffered game frames entirely. A SurfaceView keeps showing
 *  whatever it last drew until something draws over it again — so
 *  without this, closing a game (closeGame()) left its last emulated
 *  frame sitting on screen (behind/around whatever comes up next) until
 *  a new ROM loaded and rendered its own first frame. Safe to call
 *  right after stopGameLoop(): that join()s the game thread and flips
 *  the @Volatile renderLoopActive flag synchronously before returning,
 *  and renderFrame() is only ever reached through that flag (see
 *  renderCallback.doFrame), so nothing can race this with another draw.
 *
 *  BUG FIX (real crash, confirmed via two matching device crash logs —
 *  see BUGS_FIXED.md): this used to call the plain software
 *  holder.lockCanvas() instead of lockHardwareCanvas(). Two different
 *  APIs backed by two different rendering paths on the SAME
 *  SurfaceHolder — renderFrame() below has always used the hardware one
 *  (see its own PERF comment) — and switching a Surface between a
 *  software Skia canvas and a hardware GL/Skia-on-GL canvas across
 *  calls is a known way to leave the EGL/GL surface binding in a broken
 *  state on some devices/drivers. That matches the reported crash
 *  precisely: SIGABRT on Android's own RenderThread, "drawRenderNode
 *  called on a context with no surface!", every time, right after a ROM
 *  finishes loading — exactly the point where this function (called
 *  from surfaceChanged()/closeGame() while browsing ROMs) hands off to
 *  renderFrame()'s hardware-locked rendering for the first time in the
 *  session. Now locks the same way renderFrame() does, so this
 *  SurfaceHolder is never touched through two different rendering
 *  backends. No manual fallback to the software lock if this returns
 *  null — matching renderFrame()'s own handling (see its comment): on a
 *  device where hardware locking genuinely isn't available, skipping
 *  one black-clear is harmless, where falling back to software would
 *  reintroduce the exact mismatch this fix removes. */
internal fun MainActivity.clearSurfaceToBlack() {
    val holder = surfaceHolder ?: return
    val canvas: Canvas = try { holder.lockHardwareCanvas() ?: return } catch (_: Exception) { return }
    try { canvas.drawColor(Color.BLACK) } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
}


// ── Game matrix ────────────────────────────────────────────────────────

/** BUG FIX (this pass — see CHANGELOG.md/BUGS_FIXED.md for the full
 *  report): the previous version of this function built the editable
 *  "gamescreen" box as `resolvedRect("gamescreen", ..., w = sw, h =
 *  defaultH)` — FULL SCREEN WIDTH by a fraction of the height, an area
 *  that does NOT match the GBA's 3:2 image aspect ratio at all. Since
 *  the non-stretch branch then aspect-fit the actual bitmap *inside*
 *  that oversized area (see the old minOf() call), the box the editor
 *  let you drag/resize was mostly dead pillarboxed space — resizing
 *  "Game Screen Size" was really resizing a big mostly-empty rectangle
 *  that the small visible image sat somewhere inside of, which is
 *  exactly what read as "resizing enlarges a black area/container
 *  instead of just the image" in the report.
 *
 *  Root-cause fix, not a workaround: the box's DEFAULT geometry is now
 *  itself aspect-correct (matches the live framebuffer's own w:h), so
 *  the editable box IS the image with no baked-in margin. scale (one
 *  uniform float — see LayoutEntry) then grows/shrinks both dimensions
 *  together from that correct baseline, so "Game Screen Size" really
 *  can only ever resize the actual picture. clampRectToScreen() below
 *  additionally caps the box to the screen's own bounds, so no
 *  amount of resizing can push it past the edges of the display
 *  ("enlarge the entire emulator container").
 *
 *  controlsTop/padH (buildControlLayout, unchanged by this pass) were
 *  already computed from gameScreenFraction directly, never from this
 *  box's own current size — so every button's position is completely
 *  unaffected by any of this, in either direction. Resizing the game
 *  screen bigger/smaller never moves them, and the reverse is also
 *  still true. (This comment used to also mention a dark control-strip
 *  background drawn from controlsTop down — colorControlsBg — which
 *  the Fortieth pass removed entirely; see drawControls()'s own note.)
 *
 *  Stretch to Fit is a distinct, fixed mode rather than a different fit
 *  computed over the *same* customizable box: when on, the box is
 *  pinned to exactly (0, 0, sw, sh) — the *entire* screen, both
 *  dimensions — independent of any saved "gamescreen" customLayout
 *  entry, and the bitmap is scaled non-uniformly to fill that exactly
 *  (distorting the 3:2 aspect on purpose — that's what "stretch"
 *  means; unchanged from before).
 *
 *  FIX (this pass — direct report: "if i on stretch to fit screen it
 *  only stretch left to right not at the bottom", further clarified as
 *  "if the half screen is design choice just remove it it's not really
 *  useful because i move button at the top of the screen then i
 *  customize my button"): used to pin the box to (0, 0, sw, availH)
 *  instead — sw the full width, but availH only the reserved area
 *  *above* the control dock (gameScreenFraction, ~52% of sh by
 *  default) — so the image stretched edge-to-edge horizontally but
 *  always stopped partway down, leaving a dead black strip underneath
 *  it no matter how "stretched" the setting claimed to be. That
 *  reservation still means something for buildControlLayout's own
 *  controlsTop/padH — completely untouched by this fix — since that's
 *  still where every button *defaults* to before anyone drags it
 *  anywhere else. It never meant anything for the image itself, and
 *  even less so now that a customized layout already lets every
 *  control float freely to wherever it's dragged, edit mode included,
 *  rather than staying docked below a reserved line. hitTestEditable()
 *  below still skips "gamescreen" entirely while this is on — filling
 *  the screen is the whole point of the mode, so there's nothing left
 *  to usefully drag or resize until it's turned back off. */
internal fun MainActivity.updateGameMatrix(sw: Float, sh: Float) {
    val bmp = frameBuffers?.get(0) ?: return
    gameMatrix.reset()
    if (stretchToFit) {
        gameScreenRect = RectF(0f, 0f, sw, sh)
        gameMatrix.postScale(sw / bmp.width, sh / bmp.height)
    } else {
        // Reserved height above the control dock — see controlsTop.
        // Only the non-stretch default box below still anchors to
        // this; Stretch to Fit itself (above) fills the full screen.
        val availH = sh * gameScreenFraction
        val bmpAspect = bmp.width.toFloat() / bmp.height.toFloat()
        var defaultH = availH
        var defaultW = defaultH * bmpAspect
        if (defaultW > sw) { defaultW = sw; defaultH = sw / bmpAspect }
        val raw = resolvedRect("gamescreen", sw / 2f, defaultH / 2f, defaultW, defaultH)
        gameScreenRect = clampRectToScreen(raw, sw, sh)
        val areaW = gameScreenRect.width()
        val areaH = gameScreenRect.height()
        // Box is already aspect-correct, so this scale is effectively
        // the same for both dimensions — minOf() stays only as a
        // rounding-safe guard, not a real letterbox/pillarbox source.
        val scale = minOf(areaW / bmp.width, areaH / bmp.height)
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(
            gameScreenRect.left + (areaW - bmp.width  * scale) / 2f,
            gameScreenRect.top  + (areaH - bmp.height * scale) / 2f
        )
    }
}


/** Shrinks [rect] to fit within a 0,0..sw,sh screen if it doesn't
 *  already, re-centering it within bounds afterward — the actual
 *  guardrail behind "resizing the game screen can't enlarge the whole
 *  container past the screen's own edges". Only ever needed at the
 *  extreme end of the resize range (8.0x — see setSelectedScalePercent's
 *  own cap); a no-op RectF unchanged for every normal size. */
internal fun MainActivity.clampRectToScreen(rect: RectF, sw: Float, sh: Float): RectF {
    val w = rect.width().coerceAtMost(sw.coerceAtLeast(1f))
    val h = rect.height().coerceAtMost(sh.coerceAtLeast(1f))
    val left = (rect.centerX() - w / 2f).coerceIn(0f, (sw - w).coerceAtLeast(0f))
    val top  = (rect.centerY() - h / 2f).coerceIn(0f, (sh - h).coerceAtLeast(0f))
    return RectF(left, top, left + w, top + h)
}


/** Keeps a [size]-long box, positioned at [pos] along one axis, fully
 *  within [0, screenSize] with [margin] of breathing room from either
 *  edge — used by refreshEditToolbarPosition() for both its x and y,
 *  so the two axes share one clamp instead of two independently
 *  hand-rolled `coerceIn()` calls that could quietly drift apart from
 *  each other over some future edit. Distinct from clampRectToScreen()
 *  just above: that one is a zero-margin flush-to-edge clamp (right for
 *  the resizable game screen, which should be allowed to touch the
 *  edges); this one is for UI chrome like the editor popup, which
 *  shouldn't — see the companion object's EDIT_TOOLBAR_SCREEN_MARGIN_DP
 *  for why that margin needs to be a real dp value. Only falls back to
 *  a bare on-screen clamp (no margin) if [size] itself leaves less than
 *  2×[margin] of room — the popup must never be pushed off-screen just
 *  because there wasn't space to also give it a comfortable gap. */
internal fun MainActivity.clampToScreenAxis(pos: Float, size: Float, screenSize: Float, margin: Float): Float {
    val maxPos = (screenSize - size - margin).coerceAtLeast(margin)
    return pos.coerceIn(margin, maxPos)
}


/** Clamps a draggable/resizable control's CENTER so its full [w]x[h]
 *  bounding box stays on screen — not just the center point, which is
 *  all onEditTouch's old per-axis coerceIn(sw*0.03f, sw*0.97f) ever
 *  looked at. Direct report: "moving button make it that it can't go
 *  over the screen" — a *fixed* 3%/97% center bound has no idea how
 *  big the control actually is, so a large (or resized-up) control
 *  dragged near an edge still rendered well past it even though its
 *  center stayed obediently inside that 3–97% band. Reuses
 *  clampToScreenAxis() per axis (center -> top-left, clamp, back to
 *  center) so this shares one on-screen guarantee with the editor
 *  popup instead of a second, independently hand-rolled bounds check
 *  — see that function's own doc comment for the margin-fallback
 *  behavior this inherits. margin is small and fixed (not a
 *  percentage like the old code) since, unlike the popup, on-screen
 *  controls are normally *meant* to sit flush against an edge (L/R in
 *  the corners, etc.) — this only ever needs to stop a control going
 *  fully off-screen, not keep it politely inset from one. */
internal fun MainActivity.clampControlCenterToScreen(
    cx: Float, cy: Float, w: Float, h: Float, sw: Float, sh: Float
): Pair<Float, Float> {
    val margin = dp(CONTROL_DRAG_EDGE_MARGIN_DP).toFloat()
    val clampedX = clampToScreenAxis(cx - w / 2f, w, sw, margin) + w / 2f
    val clampedY = clampToScreenAxis(cy - h / 2f, h, sh, margin) + h / 2f
    return clampedX to clampedY
}

internal fun MainActivity.drawLinkStatus(canvas: Canvas) =
    canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

internal fun MainActivity.drawFpsOverlay(canvas: Canvas) =
    canvas.drawText(fpsOverlayText, canvas.width - 14f, 32f, fpsPaint)

/** FEATURE — direct report: "add features screen recorder on it but only
 *  the game screen will record and sound no button." The record on-
 *  screen button (drawActionButtonIcon()'s "record" case,
 *  MainActivityControlLayout.kt) already fills solid while recording,
 *  but that's easy to miss among a row of other buttons — a persistent,
 *  unmissable indicator is the standard convention for "you are being
 *  recorded right now" across camera/recording apps generally. Top-left
 *  specifically: FPS already owns top-right, LINK already owns
 *  bottom-left, this is the one corner still free. */
internal fun MainActivity.drawRecordingIndicator(canvas: Canvas) =
    canvas.drawText("⬤ REC", 14f, 32f, recordingPaint)


// ── Helpers ────────────────────────────────────────────────────────────

// uiToast() moved to SharedUi.kt this pass as an Activity extension —
// RomBrowserActivity needs it too for permission-flow messages.

@Suppress("DEPRECATION")
internal fun MainActivity.setImmersive() {
    window.decorView.systemUiVisibility = (
        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
}

