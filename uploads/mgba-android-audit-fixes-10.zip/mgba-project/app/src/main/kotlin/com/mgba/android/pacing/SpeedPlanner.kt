package com.mgba.android.pacing

/**
 * Shapes each game-loop iteration for the selected speed: how many emulated frames it runs, and — below 1x — how far
 * its audio has to be stretched. Replaces the accumulator that used to sit inline in `startGameLoop()`.
 *
 * **Why the audio is part of it.** The loop is paced by the blocking AudioTrack write (see `writePcm()`): one iteration
 * lasts as long as the audio it writes takes to play. Faster than 1x works by running `frames` emulated frames per
 * iteration and squeezing their audio into about one frame's worth (`decimateForFastForward()`), so the iteration still
 * lasts one frame period but covers `frames` frames of game. The inverse is needed below 1x: one frame per iteration,
 * its audio stretched to `1 / speed` frame periods ([audioStretch], applied by [SlowMotionAudio]) so the iteration lasts
 * that long. The old inline code forced "at least one frame" per iteration and wrote the frame's audio unstretched, so
 * with working audio 0.5x ran at 1x — only the no-audio fallback (`FallbackFramePacer`, which divides by the speed)
 * honoured it. The picture, the sound and the audio clock now all agree on `speed`.
 *
 * **Fast-forward accounting.** At 1x and above the fractional part of `speed` is carried between iterations
 * (1.5x alternates 1 and 2 frames), always in [0, 1), so the average is exact and nothing builds up. The old code
 * subtracted a whole frame per iteration even when the speed only added half of one, so at 0.5x its accumulator went
 * more negative every iteration, and raising the speed afterwards (the slider moves it while fast-forward is on) ran at
 * 1x until that debt was paid off — tens of seconds after a minute of slow motion. Below 1x nothing is carried.
 *
 * Allocation-free per call (a result object per iteration would be 60+ allocations a second on the thread that must
 * never hiccup): [plan] returns the frame count and leaves the rest in [speed] and [audioStretch]. Not thread-safe;
 * one per game-loop thread, like `FallbackFramePacer`. Pure — no Android types — so `tools/frame-pacer-test` runs it.
 */
internal class SpeedPlanner {
    /** Fraction of a frame owed to the next iteration at fast-forward speeds. Always in [0, 1). */
    private var carry = 0.0

    /** The speed this iteration actually runs at: the requested one, or 1 for a nonsensical value, kept inside
     *  [MIN_SPEED]..[MAX_SPEED]. Pass this — not the raw setting — to `FallbackFramePacer.waitNs()`. */
    var speed = 1f
        private set

    /** How much longer than normal this iteration's audio must play: 1 at 1x and above, `1 / speed` (1..2) below 1x. */
    var audioStretch = 1.0
        private set

    /** Forget any carried fraction — a loop starting over, or fast-forward switched off (the loop calls this on every
     *  iteration that is not fast-forwarding, as the old accumulator was zeroed there). */
    fun reset() {
        carry = 0.0
    }

    /**
     * Plans one iteration at the requested [requestedSpeed] (1 = real time) and returns how many emulated frames to
     * run — at least 1. Zero, negative and NaN speeds count as 1 so a bad setting can never stall or spin the loop.
     */
    fun plan(requestedSpeed: Float): Int {
        val s = when {
            !(requestedSpeed > 0f) -> 1f              // zero, negative, NaN
            requestedSpeed < MIN_SPEED -> MIN_SPEED
            requestedSpeed > MAX_SPEED -> MAX_SPEED
            else -> requestedSpeed
        }
        speed = s
        if (s < 1f) {
            carry = 0.0
            audioStretch = 1.0 / s
            return 1
        }
        audioStretch = 1.0
        carry += s.toDouble()
        val frames = carry.toInt()                    // >= 1: carry was in [0, 1) and s >= 1
        carry -= frames
        return frames
    }

    companion object {
        /** The Fast-forward speed setting's documented range is 0.5x..16x. */
        const val MIN_SPEED = 0.5f
        const val MAX_SPEED = 16f
    }
}
