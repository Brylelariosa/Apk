package com.mgba.android.pacing

/**
 * Time-stretches one frame's audio for slow motion — the inverse of `decimateForFastForward()`. Played back at the
 * track's normal rate the longer clip takes `stretch` times as long, which is what makes the blocking audio write (the
 * game loop's pacer) hold the iteration to `stretch` frame periods; the sound drops in pitch as slowed audio does.
 *
 * Linear interpolation: one multiply-add per channel per output sample, so a stretched frame costs microseconds on the
 * thread that paces the game, and unlike repeating samples it does not turn every sample into a stair step.
 *
 * Pure (no Android types); `tools/frame-pacer-test` exercises it on a JVM.
 */
internal object SlowMotionAudio {
    /**
     * Stretches [inPairs] interleaved stereo pairs of [src] (index 0 on) to `round(inPairs * stretch)` pairs in [dst]
     * and returns how many pairs it wrote — fewer than that only if [dst] is too small to hold them, never past its end.
     * [src] and [dst] must be different arrays. Output pair `j` is read from input position `j * inPairs / outPairs`,
     * so the first output pair is the first input pair and the clip's length is exactly `outPairs / rate`; the last
     * pair interpolates towards the clip's own last pair rather than reading past it.
     *
     * A [stretch] of 1 or less (or NaN) copies the clip unchanged: this function only ever lengthens audio.
     */
    fun stretch(src: ShortArray, inPairs: Int, dst: ShortArray, stretch: Double): Int {
        val n = inPairs.coerceAtMost(src.size / 2)
        if (n <= 0) return 0
        val capacity = dst.size / 2
        if (!(stretch > 1.0)) {
            val copy = n.coerceAtMost(capacity)
            System.arraycopy(src, 0, dst, 0, copy * 2)
            return copy
        }
        val outPairs = Math.round(n * stretch).coerceAtMost(capacity.toLong()).toInt()
        if (outPairs <= 0) return 0
        val step = n.toDouble() / outPairs
        val last = n - 1
        for (j in 0 until outPairs) {
            val pos = j * step
            val i0 = pos.toInt().coerceAtMost(last)
            val i1 = (i0 + 1).coerceAtMost(last)
            val frac = pos - i0
            val l0 = src[i0 * 2].toInt()
            val r0 = src[i0 * 2 + 1].toInt()
            dst[j * 2] = (l0 + (src[i1 * 2] - l0) * frac).let { Math.round(it).toInt() }.toShort()
            dst[j * 2 + 1] = (r0 + (src[i1 * 2 + 1] - r0) * frac).let { Math.round(it).toInt() }.toShort()
        }
        return outPairs
    }

    /**
     * The write side of slow motion, kept here (and not in the Android-only caller) so a JVM test can drive it: stretches
     * the [count] pairs at the start of [buffer] by [factor] into [scratch] and passes the result to [write] in pieces of
     * at most `buffer.size / 2` pairs, each laid at the start of [buffer] — where the AudioTrack write reads from — so
     * `write(n)` means "play the first n pairs of the buffer", exactly the contract of the unstretched write.
     *
     * Returns true only if every piece was accepted whole. The first piece [write] does not accept ends the frame (the
     * rest is dropped, like any audio the AudioTrack could not take) and the result is false: the blocking write did not
     * hold the iteration to the audio clock, so the caller's fallback pacer must. A [factor] of 1 or less is plain
     * `write(count)` with the buffer untouched. [scratch] needs room for `count * factor` pairs or the clip is cut short
     * at its capacity (see [stretch]); [buffer] and [scratch] must be different arrays.
     *
     * `inline`, so the per-frame call allocates nothing: this runs on the game thread 60+ times a second.
     */
    inline fun writeStretched(
        buffer: ShortArray,
        count: Int,
        scratch: ShortArray,
        factor: Double,
        write: (pairs: Int) -> Boolean
    ): Boolean {
        if (!(factor > 1.0)) return write(count)
        val total = stretch(buffer, count, scratch, factor)
        if (total <= 0) return false                 // nothing to write — also a buffer too small to hold one pair
        val piece = buffer.size / 2                  // >= 1 here: stretch() read at least one pair out of the buffer
        var done = 0
        while (done < total) {
            val n = minOf(piece, total - done)
            System.arraycopy(scratch, done * 2, buffer, 0, n * 2)
            if (!write(n)) return false
            done += n
        }
        return true
    }
}
