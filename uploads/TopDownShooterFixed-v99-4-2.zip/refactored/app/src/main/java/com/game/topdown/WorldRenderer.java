package com.game.topdown;

import android.graphics.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;

/** Draws world-space entities. Owns all pre-allocated Paint fields. */
public class WorldRenderer {

// ── Pre-allocated Paint fields for VoltChakram rendering ─────────────────
private final Paint vcOuterGlow  = mkStroke(0, 18f); // wide soft outer glow
private final Paint vcMidGlow    = mkStroke(0, 10f); // mid glow ring
private final Paint vcTrailP     = mkFill(0);         // disc motion trail
private final Paint vcTrailCore  = mkFill(0);         // trail core dot
private final Paint vcRingP      = mkStroke(0, 3.5f);// main ring outline
private final Paint vcRingP2     = mkStroke(0, 2.0f);// inner ring (glow colour)

// ── Pre-allocated VoltChakram fields (continued) ─────────────────────────
private final Paint vcBladeP   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint vcZapP     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint vcCoreHalo = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint vcCoreP    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint vcConnP    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final android.graphics.Path vcBladePath = new android.graphics.Path();

// ── Rope / chain ──────────────────────────────────────────────────────────
private final Paint ddRopeOuter     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddRopeInner     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddRopeHighlight = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddChainGlow     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddChainDark     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddChainLight    = new Paint(Paint.ANTI_ALIAS_FLAG);

// ── World background ──────────────────────────────────────────────────────
Paint bgP, gridP, bdrP, wallP;

// ── Aim line ──────────────────────────────────────────────────────────────
private final Paint ddAimLine = new Paint(Paint.ANTI_ALIAS_FLAG);
boolean cachedAimLine = true;

// ── Bomb world-draw ───────────────────────────────────────────────────────
private final Paint ddBombShadow     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddBombFly        = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddBombDangerFill = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddBombDangerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddBombEmoji      = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddBombDot        = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddBombArc        = new Paint(Paint.ANTI_ALIAS_FLAG);

// ── Air-strike aim UI ─────────────────────────────────────────────────────
private final Paint ddAsReloadRing = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsReloadLbl  = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsAimRing    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsAimConn    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsAimPrev    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsAimXh      = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsDangerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsWarn       = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint ddAsCross      = new Paint(Paint.ANTI_ALIAS_FLAG);

// ── drawPlayer ────────────────────────────────────────────────────────────
private final Paint dpShadow   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpBody     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpGun      = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpHpFill   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpName2    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpProtRing = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpShRing   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpCharge   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpTip      = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpSbCharge = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpSbTick   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpSbTip    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpTier     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpSoul     = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint dpSbLbl    = new Paint(Paint.ANTI_ALIAS_FLAG);

// ── HUD / UI paints (non-final; initialised by GameView via initPaints()) ─
Paint hudP, hudBgP, btnP, btnTxtP, deathBgP, deathTxtP, gunTxtP;
Paint remP, locP, shP, hpBgP, nameP;
private final Paint uiP    = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint uiTxt  = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint uiCopy = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint hudStatLblP = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint hudStatBgP  = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint hudSbHdrP   = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint hudSbNameP  = new Paint(Paint.ANTI_ALIAS_FLAG);
private final Paint hudSbNumP   = new Paint(Paint.ANTI_ALIAS_FLAG);

// ── State shared with GameView (set by GameView after construction) ───────
float screenW, screenH;
android.view.SurfaceHolder holder;
Joystick moveStick, aimStick;
RectF switchRect, reloadRect, bombRect, dropRect, paintModeRect;
RectF shopBtn, shopCloseRect, confirmMoveRect, sizeSliderTrack;
RectF trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn, relFireOpenBtn;
boolean settingsOpen, shopOpen, relFireOpen, wheelOpen, btnMoveMode;
boolean cachedGunStats = true;
int   btnSizingId  = -1;
float sizeSliderVal;
// ── Additional shared fields (set by GameView alongside syncToWorldRenderer) ──
WeaponSystem weapons;
int difficulty;
Paint ipPaint;
NetworkManager net;
RectF skillRect;
RectF gearRect;
// ── Overlay paint fields (synced from GameView.initPaints) ─────────────────
Paint settingsBgP, settingsTitleP, settingsLabelP;
Paint optBtnP, optBtnSelP, optTxtP, closeBtnP;
// ── Settings layout ────────────────────────────────────────────────────────
RectF settingsPanel, closeSettingsRect, relFireOpenBtn;
RectF fireThreshValRect, fireThreshEditBtn, moveBtnsRect, mainMenuRect, changeNameRect;
RectF[] jsSizeOpts, swapOpts, btnSizeOpts, aimSensOpts, opacityOpts, gunStatOpts, aimLineOpts;
float cachedFireThresh = 0.40f;
// ── Release-fire panel ─────────────────────────────────────────────────────
RectF relFirePanel, relFireCloseBtn;
RectF[] relFireToggleON, relFireToggleOFF;
// ── Shop ───────────────────────────────────────────────────────────────────
int shopTab = 0;
float shopPanelH = 670f;
float[] shopTabScrollY = {0f, 0f};
float[] shopTabScrollMax = {0f, 0f};
RectF shopTabGuns, shopTabSkills;
RectF[] shopBuyRects, passiveBuyRects, activeBuyRects;
Gun[] shopGunsCache;
// ── Weapon wheel ───────────────────────────────────────────────────────────
float wheelCX, wheelCY, wheelRadius;
int[] wheelSlots;
int wheelHovered = -1;
android.graphics.RectF wheelOval;
android.graphics.Path wheelSlicePath;
// ── Context for SharedPreferences ─────────────────────────────────────────
android.content.Context ctx;
private final android.graphics.RectF tmpRectF = new android.graphics.RectF();

// ── Scratch Paint reused per draw call (single-threaded) ─────────────────
private final Paint _fillScratch = new Paint(Paint.ANTI_ALIAS_FLAG);

private static Paint mkFill(int c) {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setStyle(Paint.Style.FILL);
    p.setColor(c);
    return p;
}
private static Paint mkStroke(int c, float w) {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    p.setStyle(Paint.Style.STROKE);
    p.setStrokeWidth(w);
    p.setColor(c);
    return p;
}
private Paint fill(int c) {
    _fillScratch.setColor(c);
    _fillScratch.setStyle(Paint.Style.FILL);
    return _fillScratch;
}


private void drawVoltChakrams(GameState state, Canvas c) {
    long now = System.currentTimeMillis();

    // Each disc gets its own per-disc phase so they pulse out of sync
    for (VoltChakram vc : state.voltChakrams) {
        float cx = vc.x, cy = vc.y;
        float phase = (float)(now / 140.0) + vc.orbitIdx * 2.094f; // 120° apart
        float pulse  = 0.55f + 0.45f * (float) Math.sin(phase);
        float pulse2 = 0.55f + 0.45f * (float) Math.sin(phase * 1.7f + 1.1f);

        boolean orbiting  = vc.state == VoltChakram.ORBITING;
        boolean launched  = vc.state == VoltChakram.LAUNCHED;
        boolean returning = vc.state == VoltChakram.RETURNING;

        // Colour scheme: orbiting = cool electric cyan, launched = hot white-yellow, returning = aqua-green
        int rC, gC, bC;       // core tint
        int rG, gG, bG;       // glow tint
        float discR;          // disc radius
        if (launched) {
            rC = 255; gC = 245; bC = 200;   // white-hot
            rG = 180; gG = 240; bG = 255;
            discR = 13f;
        } else if (returning) {
            rC =  60; gC = 255; bC = 200;   // aqua-green return
            rG =   0; gG = 220; bG = 180;
            discR = 11f;
        } else {
            rC = 160; gC = 230; bC = 255;   // cool cyan orbit
            rG =  80; gG = 180; bG = 255;
            discR = 11f;
        }

        // ── 1. Wide soft outer glow ──────────────────────────────────────
        float glowR1 = discR * 2.6f + pulse * 6f;
        vcOuterGlow.setColor(Color.argb((int)(35 * pulse), rG, gG, bG));
        c.drawCircle(cx, cy, glowR1, vcOuterGlow);

        // ── 2. Mid glow ring ─────────────────────────────────────────────
        float glowR2 = discR * 1.7f + pulse2 * 4f;
        vcMidGlow.setColor(Color.argb((int)(80 * pulse2), rG, gG, bG));
        c.drawCircle(cx, cy, glowR2, vcMidGlow);

        // ── 3. Motion trail (launched & returning) ───────────────────────
        if (!orbiting) {
            float speed = (float) Math.sqrt(vc.vx * vc.vx + vc.vy * vc.vy);
            if (speed > 15f) {
                float ux = -vc.vx / speed, uy = -vc.vy / speed;
                int segments = launched ? 10 : 6;
                float segLen = launched ? Math.min(60f, speed * 0.05f) / segments
                                        : Math.min(30f, speed * 0.03f) / segments;
                // Slight perpendicular jitter for a crackling lightning-bolt look
                float px = -uy, py = ux;  // perpendicular
                for (int t = 0; t < segments; t++) {
                    float tf   = (t + 1f) / segments;
                    float tx   = cx + ux * segLen * (t + 1) * segments;
                    float ty   = cy + uy * segLen * (t + 1) * segments;
                    float jitter = (float)Math.sin(now * 0.041f + t * 1.3f + vc.orbitIdx) * 3f * tf;
                    float rx2  = tx + px * jitter, ry2 = ty + py * jitter;
                    int alpha  = (int)(200 * (1f - tf));
                    float sr   = discR * (1f - tf * 0.7f);
                    vcTrailP.setColor(Color.argb(alpha, rC, gC, bC));
                    c.drawCircle(rx2, ry2, sr, vcTrailP);
                }
                // Extra bright core of trail right behind disc
                vcTrailCore.setColor(Color.argb(160, 255, 255, 255));
                c.drawCircle(cx + ux * discR, cy + uy * discR, discR * 0.45f, vcTrailCore);
            }
        }

        // ── 4. Chakram blade ring (rotating thin ring with notches) ──────
        //    Two overlapping rings at different spin speeds for a shuriken look
        vcRingP.setColor(Color.argb((int)(210 + 45 * pulse), rC, gC, bC));
        vcRingP.setStrokeWidth(launched ? 3.5f : 2.8f);
        c.drawCircle(cx, cy, discR, vcRingP);

        // Inner ring, counter-rotating
        vcRingP2.setColor(Color.argb((int)(120 * pulse2), rG, gG, bG));
        c.drawCircle(cx, cy, discR * 0.62f, vcRingP2);

        // Spinning blade spokes — 6 blades that rotate
        float spinA = vc.spinAngle;
        vcBladePath.reset();
        for (int i = 0; i < 6; i++) {
            float a    = spinA + (float)(i * Math.PI / 3);
            float aTip = spinA + (float)(i * Math.PI / 3) + 0.38f; // angled tip
            float innerR = discR * 0.28f, outerR2 = discR * 0.92f;
            float ix = cx + innerR * (float)Math.cos(a),        iy = cy + innerR * (float)Math.sin(a);
            float ox = cx + outerR2 * (float)Math.cos(aTip),    oy = cy + outerR2 * (float)Math.sin(aTip);
            vcBladePath.moveTo(ix, iy);
            vcBladePath.lineTo(ox, oy);
        }
        vcBladeP.setStrokeWidth(launched ? 2.2f : 1.8f);
        vcBladeP.setColor(Color.argb((int)(200 + 55 * pulse), rC, gC, bC));
        c.drawPath(vcBladePath, vcBladeP);

        // ── 5. Electric bolt sparks radiating from disc ──────────────────
        int zapCount = orbiting ? 4 : (launched ? 6 : 3);
        float zapSeed = (float)(now / 70.0) + vc.orbitIdx * 3.7f;
        for (int z = 0; z < zapCount; z++) {
            float za      = zapSeed + z * ((float)Math.PI * 2 / zapCount);
            float zapLen  = discR * (0.9f + 0.8f * (float)Math.abs(Math.sin(zapSeed + z * 1.6f)));
            float kinkT   = 0.55f; // where the bolt kinks
            float kinkAng = za + (float)Math.sin(zapSeed * 1.3f + z) * 0.5f;
            float kx = cx + (float)Math.cos(kinkAng) * zapLen * kinkT;
            float ky = cy + (float)Math.sin(kinkAng) * zapLen * kinkT;
            float ex2 = cx + (float)Math.cos(za) * zapLen;
            float ey2 = cy + (float)Math.sin(za) * zapLen;
            int zapAlpha = (int)(180 * pulse * (launched ? 1f : 0.75f));
            vcZapP.setStrokeWidth(launched ? 2f : 1.3f);
            vcZapP.setColor(Color.argb(zapAlpha, 200, 240, 255));
            c.drawLine(cx, cy, kx, ky, vcZapP);   // first segment
            vcZapP.setStrokeWidth(launched ? 1.4f : 1f);
            vcZapP.setColor(Color.argb(zapAlpha / 2, 200, 240, 255));
            c.drawLine(kx, ky, ex2, ey2, vcZapP); // second segment (brighter)
        }

        // ── 6. Hot white core ────────────────────────────────────────────
        float coreR = discR * 0.30f + pulse * 1.5f;
        // Soft white halo around core
        vcCoreHalo.setColor(Color.argb((int)(120 * pulse), rC, gC, bC));
        c.drawCircle(cx, cy, coreR * 2.2f, vcCoreHalo);
        // Solid bright centre
        vcCoreP.setColor(Color.argb(255, 240, 255, 255));
        c.drawCircle(cx, cy, coreR, vcCoreP);

        // ── 7. Orbit connection line back to player (orbiting only) ──────
        if (orbiting) {
            Player owner = (state.localPlayer != null && state.localPlayer.id == vc.ownerId)
                    ? state.localPlayer : state.remote.get(vc.ownerId);
            if (owner != null) {
                vcConnP.setColor(Color.argb((int)(55 * pulse), rG, gG, bG));
                vcConnP.setPathEffect(new android.graphics.DashPathEffect(
                        new float[]{6f, 8f}, (float)(now / 60.0)));
                c.drawLine(owner.x, owner.y, cx, cy, vcConnP);
                vcConnP.setPathEffect(null); // reset for next draw
            }
        }
    }
}

private void drawRope(Canvas c, float x1, float y1, float x2, float y2) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = (float) Math.sqrt(dx*dx + dy*dy);
    if (len < 2f) return;
    // Mid-point sag: blend perpendicular + downward gravity
    float mx = (x1+x2)*0.5f, my = (y1+y2)*0.5f;
    float perpX = -dy/len, perpY = dx/len;  // unit perpendicular
    float sagAmt = Math.min(len * 0.14f, 45f);
    // Bias sag downward (+y in world) to simulate gravity
    float ctrlX = mx + perpX * sagAmt * 0.3f;
    float ctrlY = my + perpY * sagAmt * 0.3f + sagAmt * 0.8f;
    android.graphics.Path ropePath = new android.graphics.Path();
    ropePath.moveTo(x1, y1);
    ropePath.quadTo(ctrlX, ctrlY, x2, y2);
    // Outer dark shadow (ddRopeOuter pre-allocated)
    ddRopeOuter.setStrokeWidth(5f); ddRopeOuter.setColor(Color.argb(180, 70, 45, 15));
    ddRopeOuter.setStrokeCap(Paint.Cap.ROUND);
    c.drawPath(ropePath, ddRopeOuter);
    // Inner lighter rope strand
    ddRopeInner.setStrokeWidth(2.5f); ddRopeInner.setColor(Color.argb(230, 205, 165, 90));
    ddRopeInner.setStrokeCap(Paint.Cap.ROUND);
    c.drawPath(ropePath, ddRopeInner);
    // Thin highlight strand for woven look
    ddRopeHighlight.setStrokeWidth(1f); ddRopeHighlight.setColor(Color.argb(120, 255, 220, 140));
    c.drawPath(ropePath, ddRopeHighlight);
}

private void drawPullRopes(GameState state, Canvas c) {
    for (Player p : state.remote.values()) {
        if (!p.alive || !p.isBeingPulled()) continue;
        Player caster = (state.localPlayer != null && p.hookPullOwnerId == state.localPlayer.id)
                ? state.localPlayer : state.remote.get(p.hookPullOwnerId);
        float ox = (caster != null) ? caster.x : p.hookPullFromX;
        float oy = (caster != null) ? caster.y : p.hookPullFromY;
        drawMetalChain(c, ox, oy, p.x, p.y);
    }
    // Local player being pulled
    if (state.localPlayer != null && state.localPlayer.alive && state.localPlayer.isBeingPulled()) {
        Player caster = state.remote.get(state.localPlayer.hookPullOwnerId);
        float ox = (caster != null) ? caster.x : state.localPlayer.hookPullFromX;
        float oy = (caster != null) ? caster.y : state.localPlayer.hookPullFromY;
        drawMetalChain(c, ox, oy, state.localPlayer.x, state.localPlayer.y);
    }
}

private void drawHookChains(GameState state, Canvas c) {
    for (Bullet b : state.bullets) {
        if (!b.hookSpear) continue;
        Player owner = (state.localPlayer != null && state.localPlayer.id == b.ownerId)
                ? state.localPlayer : state.remote.get(b.ownerId);
        float ox = (owner != null) ? owner.x : b.spawnX;
        float oy = (owner != null) ? owner.y : b.spawnY;
        drawMetalChain(c, ox, oy, b.x, b.y);
    }
}

private void drawMetalChain(Canvas c, float x1, float y1, float x2, float y2) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = (float) Math.sqrt(dx * dx + dy * dy);
    if (len < 6f) return;

    float nx = dx / len, ny = dy / len;   // direction along chain
    float px = -ny, py = nx;               // perpendicular

    // Faint glow along full length
    ddChainGlow.setStrokeWidth(10f);
    ddChainGlow.setColor(Color.argb(30, 160, 200, 255));
    c.drawLine(x1, y1, x2, y2, ddChainGlow);

    // Chain links
    float linkLen = 16f;
    float halfW   = 4.5f;      // half-width of a cross link
    int linkCount = Math.max(1, (int)(len / linkLen));
    float actualLinkLen = len / linkCount;
    float halfL = actualLinkLen * 0.42f;

    // ddChainDark pre-allocated

    // ddChainLight pre-allocated

    for (int i = 0; i < linkCount; i++) {
        float t = (i + 0.5f) / linkCount;
        float mx = x1 + nx * len * t;
        float my = y1 + ny * len * t;

        if (i % 2 == 0) {
            // Horizontal link (along chain axis)
            float lx0 = mx - nx * halfL, ly0 = my - ny * halfL;
            float lx1 = mx + nx * halfL, ly1 = my + ny * halfL;
            ddChainDark.setStrokeWidth(5.5f);
            ddChainDark.setColor(Color.argb(230, 90, 100, 115));
            c.drawLine(lx0, ly0, lx1, ly1, ddChainDark);
            ddChainLight.setStrokeWidth(2.5f);
            ddChainLight.setColor(Color.argb(200, 210, 220, 240));
            c.drawLine(lx0, ly0, lx1, ly1, ddChainLight);
        } else {
            // Cross link (perpendicular)
            float cx0 = mx - px * halfW, cy0 = my - py * halfW;
            float cx1 = mx + px * halfW, cy1 = my + py * halfW;
            ddChainDark.setStrokeWidth(5.5f);
            ddChainDark.setColor(Color.argb(230, 70, 80, 95));
            c.drawLine(cx0, cy0, cx1, cy1, ddChainDark);
            ddChainLight.setStrokeWidth(2.5f);
            ddChainLight.setColor(Color.argb(180, 190, 200, 220));
            c.drawLine(cx0, cy0, cx1, cy1, ddChainLight);
        }
    }
}

void render(GameState state){
    if(holder==null) return;
    Canvas c=holder.lockCanvas(); if(c==null) return;
    try{ doDraw(state, c); }finally{ holder.unlockCanvasAndPost(c); }
}

private void doDraw(GameState state, Canvas c){
    c.drawRect(0,0,c.getWidth(),c.getHeight(),bgP);
    c.save();
    c.scale(state.currentZoom, state.currentZoom);   // per-weapon camera zoom
    c.translate(-state.camX,-state.camY);

    for(float x=0;x<=MAP_W;x+=120) c.drawLine(x,0,x,MAP_H,gridP);
    for(float y=0;y<=MAP_H;y+=120) c.drawLine(0,y,MAP_W,y,gridP);
    c.drawRect(0,0,MAP_W,MAP_H,bdrP);

    for(float[] w:WALLS) c.drawRect(w[0],w[1],w[2],w[3],wallP);

    // ── Effects drawn BEHIND players (explosions, hit flashes, dash ghost trails)
    state.effects.drawBehindPlayers(c);

    for(Player p:state.remote.values()) drawPlayer(state,c,p,false);
    Player lp=state.localPlayer;
    if(lp!=null) drawPlayer(state,c,lp,true);

    // ── Effects drawn IN FRONT of players (crescent appears on top of player body)
    state.effects.drawInFrontOfPlayers(c);

    // ── Status-effect particles (slow mist, poison fumes, stun arcs — on top of players)
    if (GunConfig.ShowStatusEffectVisuals) state.effects.drawStatusParticles(c);

    // ── Bullets (drawn on top of all players and state.effects)
    drawHookChains(state,c);    // chains connect hook spears to owner (flight phase)
    drawPullRopes(state,c);     // chains remain visible during pull phase
    state.effects.drawBullets(c, state.bullets);

    // Aim line (world-space dashed line) — hidden while a hook spear is in flight
    boolean hookInFlight = false;
    if (lp != null) { for (Bullet b : state.bullets) { if (b.hookSpear && b.ownerId == lp.id) { hookInFlight = true; break; } } }
    if(lp!=null && lp.alive && !hookInFlight && cachedAimLine){
        float lineLen = 350f;
        float ex = lp.x + (float)Math.cos(lp.angle) * lineLen;
        float ey = lp.y + (float)Math.sin(lp.angle) * lineLen;
        c.drawLine(lp.x,lp.y,ex,ey,ddAimLine); // pre-allocated, no new Paint
    }

    // Draw active bombs (world space)
    long nowDraw = System.currentTimeMillis();
    for (Bomb bomb : state.activeBombs) {
        // ── Spawn explosion FX once when bomb first detonates ─────────────
        if (bomb.explodedAt > 0 && state.spawnedBombFx.add(bomb.explodedAt)) {
            state.effects.spawnBombExplosion(bomb.x, bomb.y);
        }

        if (bomb.isFlashing()) {
            // explosion FX handled by EffectsManager; nothing extra needed here
        } else if (bomb.explodedAt < 0) {
            if (!bomb.hasLanded) {
                // ── Flying: draw a shadow + emoji to indicate arc ─────────
                // Shadow grows as bomb approaches max range (shows distance)
                float travel = (float)Math.sqrt(bomb.traveledSq()) / Bomb.THROW_RANGE;
                float shadowR = 8f + 22f * travel;
                ddBombShadow.setColor(Color.argb((int)(120 * (1f - travel * 0.5f)), 0, 0, 0));
                c.drawCircle(bomb.x, bomb.y, shadowR, ddBombShadow);
                // Emoji slightly offset upward to simulate height
                float bounce = -(float)Math.sin(travel * Math.PI) * 40f;
                c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + bounce + 12f, ddBombFly);
            } else {
                // ── Landed: emoji + pulsing danger ring showing blast radius ─
                long fuseAge   = nowDraw - bomb.deployTime;
                float fuseFrac = Math.min(1f, fuseAge / (float) Bomb.FUSE_MS);
                // pulse rate doubles as fuse runs out
                float pulse = 0.45f + 0.55f * (float)Math.abs(Math.sin(fuseAge / (200f - fuseFrac * 120f)));
                int dangerA = (int)(100 + 80 * pulse);
                ddBombDangerFill.setColor(Color.argb((int)(dangerA * 0.35f), 255, 50, 0));
                c.drawCircle(bomb.x, bomb.y, Bomb.RADIUS, ddBombDangerFill);
                ddBombDangerRing.setStrokeWidth(3f + 2f * pulse);
                ddBombDangerRing.setColor(Color.argb(dangerA, 255, 80, 0));
                c.drawCircle(bomb.x, bomb.y, Bomb.RADIUS, ddBombDangerRing);
                c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + 12f, ddBombEmoji);
            }
        }
    }

    // ── Air Strike ring + orb (joystick-mag maps to target distance) ─────
    if (lp != null && lp.alive && lp.currentGun().bulletAirStrike) {
        boolean aimActive = aimStick != null && aimStick.isActive();
        boolean hasAngle  = !Float.isNaN(state.asAimAngle);
        boolean reloading = lp.currentGun().reloading;
        if (reloading) {
            // Show greyed-out ring + RELOADING label to signal aim is locked
            c.drawCircle(lp.x, lp.y, AS_RING_R, ddAsReloadRing);
            c.drawText("RELOADING — CAN'T AIM", lp.x, lp.y - AS_RING_R - 20f, ddAsReloadLbl);
        } else if (aimActive && hasAngle) {
            float ringR = AS_RING_R; // fixed size, no pulse

            // Big ring around player
            c.drawCircle(lp.x, lp.y, ringR, ddAsAimRing);
            c.drawCircle(lp.x, lp.y, ringR, fill(Color.argb(18, 224, 64, 251)));

            // Small orb: distance = state.asAimMag * ring radius (joystick center = at player)
            float orbDist = state.asAimMag * ringR;
            float orbX = lp.x + (float)Math.cos(state.asAimAngle) * orbDist;
            float orbY = lp.y + (float)Math.sin(state.asAimAngle) * orbDist;
            float ORB_R = 26f;

            // Glow + body + dot
            c.drawCircle(orbX, orbY, ORB_R * 1.7f, fill(Color.argb(70, 224, 64, 251)));
            c.drawCircle(orbX, orbY, ORB_R,         fill(Color.argb(230, 224, 64, 251)));
            c.drawCircle(orbX, orbY, ORB_R * 0.38f, fill(Color.WHITE));

            // Dashed connector: player to orb
            c.drawLine(lp.x, lp.y, orbX, orbY, ddAsAimConn);

            // Strike zone preview: circle showing explosion radius
            float zoneR = AS_RADIUS * 0.75f; // smaller preview circle
            c.drawCircle(orbX, orbY, zoneR, ddAsAimPrev);
            c.drawCircle(orbX, orbY, zoneR, fill(Color.argb(25, 255, 200, 50)));
            // Center crosshair on orb
            c.drawLine(orbX - 16, orbY, orbX + 16, orbY, ddAsAimXh);
            c.drawLine(orbX, orbY - 16, orbX, orbY + 16, ddAsAimXh);
        }
    }

    // Draw Air Strike targets and explosions (world space)
    long asNow = System.currentTimeMillis();
    for (double[] as : state.airStrikes) {
        float sx = (float) as[0], sy = (float) as[1];
        long trigMs = (long) as[2];
        long flashUntil = (long) as[4];
        boolean exploding = flashUntil > 0L && asNow < flashUntil;
        boolean pending   = asNow < trigMs;

        if (exploding) {
            // Spawn the full bomb-style explosion FX once when detonation starts
            if (state.spawnedAirStrikeFx.add(flashUntil)) {
                state.effects.spawnBombExplosion(sx, sy);
            }
            // (drawing handled by EffectsManager.drawBombExplosions)
        } else if (pending) {
            // Incoming warning: fixed danger ring visible to all players
            float countdown = Math.max(0f, (trigMs - asNow) / (float) AS_WARNING_MS);
            int ra = (int)(220 * (1f - countdown * 0.4f));
            // Outer danger ring (fixed size)
            ddAsDangerRing.setColor(Color.argb(ra, 255, 50, 50));
            c.drawCircle(sx, sy, AS_RADIUS, ddAsDangerRing);
            // Danger fill (gets brighter as time runs out)
            c.drawCircle(sx, sy, AS_RADIUS, fill(Color.argb((int)(ra * 0.18f), 255, 50, 50)));
            // Warning text above
            ddAsWarn.setColor(Color.argb(ra, 255, 80, 80));
            c.drawText("⚠", sx, sy - AS_RADIUS - 8f, ddAsWarn);
            ddAsCross.setColor(Color.argb(ra, 255, 100, 100));
            c.drawLine(sx - 12, sy, sx + 12, sy, ddAsCross);
            c.drawLine(sx, sy - 12, sx, sy + 12, ddAsCross);
        }
    }
    // ── Throw preview arc (world space) ──────────────────────────────────
    if (state.throwingBomb && lp != null && lp.alive && aimStick != null) {
        float tax = aimStick.getX(), tay = aimStick.getY();
        float tmag = (float) Math.sqrt(tax * tax + tay * tay);
        if (tmag > 0.08f) {
            float landX = lp.x + tax * Bomb.THROW_RANGE;
            float landY = lp.y + tay * Bomb.THROW_RANGE;
            // Dashed trajectory line (pre-allocated paint, no alloc)
            c.drawLine(lp.x, lp.y, landX, landY, ddBombArc);
            // (blast radius preview circles removed)
            // Landing bullseye
            ddBombDot.setColor(Color.argb(230, 255, 220, 0));
            c.drawCircle(landX, landY, 10f, ddBombDot);
        }
    }

    // ── Volt Chakrams (drawn in world space, on top of everything) ───────
    drawVoltChakrams(state,c);

    c.restore();

    drawHUD(state,c);
}

private void drawPlayer(GameState state, Canvas c, Player p, boolean local){
    // Resolve render position — bots use a visual-only dash interpolation
    float rx = p.x, ry = p.y;
    if (!local) {
        float[] bv = state.botDashVisual.get(p.id);
        if (bv != null) {
            float bt = Math.min(1f, (float)((System.currentTimeMillis() - EffectsManager.FX_EPOCH) - (long)bv[4]) / EffectsManager.DASH_ANIM_MS);
            float ease = 1f - (1f - bt) * (1f - bt) * (1f - bt);
            rx = bv[0] + (bv[2] - bv[0]) * ease;
            ry = bv[1] + (bv[3] - bv[1]) * ease;
        }
    }
    if(!p.alive){
        // Reuse dpShadow as the death-X paint
        dpShadow.setColor(Color.argb(160,230,50,50));
        dpShadow.setStyle(Paint.Style.STROKE); dpShadow.setStrokeWidth(4f);
        c.drawLine(rx-13,ry-13,rx+13,ry+13,dpShadow);
        c.drawLine(rx+13,ry-13,rx-13,ry+13,dpShadow);
        dpShadow.setStyle(Paint.Style.FILL); // restore
        return;
    }
    // Stealth: state.remote players are invisible (skip draw); local is translucent
    if (!local && p.isStealthed()) return;
    int stealthAlpha = (local && p.isStealthed()) ? 100 : 255;
    float r=PR;
    dpShadow.setColor(Color.argb(stealthAlpha*65/255, 0, 0, 0));
    c.drawCircle(rx+4,ry+4,r,dpShadow);
    // Dummies: grey body, no gun line, different name style
    boolean isDummy = state.dummyIds.contains(p.id);
    if (isDummy) dpBody.setColor(Color.argb(stealthAlpha, 140, 140, 140));
    else if (local) { dpBody.setColor(locP.getColor()); dpBody.setAlpha(stealthAlpha); }
    else            { dpBody.setColor(remP.getColor()); dpBody.setAlpha(stealthAlpha); }
    c.drawCircle(rx,ry,r,dpBody);
    dpBody.setAlpha(255); // restore
    if (!isDummy) {
        float gl=r+20f;
        int barrelCol = p.currentGun().color;
        dpGun.setColor(barrelCol); dpGun.setAlpha(stealthAlpha);
        c.drawLine(rx,ry,rx+(float)Math.cos(p.angle)*gl,ry+(float)Math.sin(p.angle)*gl,dpGun);
        dpGun.setAlpha(255); // restore
    }
    float bw=50f,bh=6f,bx=rx-25f,by=ry-r-14f;
    c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,hpBgP);
    float fr=Math.max(0,p.hp/100f);
    dpHpFill.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
    c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,dpHpFill);
    dpName2.set(nameP); dpName2.setAlpha(stealthAlpha);
    if (isDummy) {
        dpName2.setColor(Color.argb(180, 180, 180, 180));
        dpName2.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
    }
    c.drawText(p.name, rx, ry-r-17f, dpName2);
    // Volt Chakram charge arc — drawn around the player when charging
    if (local && weapons != null && weapons.isVoltChakram(p.currentGun()) && state.voltCharge > 0.02f) {
        float sweep = state.voltCharge * 360f;
        dpCharge.setStrokeWidth(4.5f);
        int chargeAlpha = (int)(180 + state.voltCharge * 75);
        dpCharge.setColor(Color.argb(chargeAlpha, 100, 220, 255));
        float arcR = r + 14f;
        RectF arcRect = new RectF(rx - arcR, ry - arcR, rx + arcR, ry + arcR);
        c.drawArc(arcRect, -90f, sweep, false, dpCharge);
        // Bright tip dot at the leading edge
        float tipAngle = (float) Math.toRadians(-90f + sweep);
        float tipX = rx + arcR * (float) Math.cos(tipAngle);
        float tipY = ry + arcR * (float) Math.sin(tipAngle);
        // dpTip pre-allocated
        dpTip.setColor(Color.argb(230, 180, 240, 255));
        c.drawCircle(tipX, tipY, 5f, dpTip);
    }
    // Shadow Blade charge arc — color shifts per tier; tick marks at T2/T3 thresholds
    if (local && weapons != null && weapons.isShadowBlade(p.currentGun()) && state.shadowBladeCharge > 0.02f) {
        float sweep   = state.shadowBladeCharge * 360f;
        long  nowSb   = System.currentTimeMillis();
        float sbArcR  = r + 14f;
        RectF sbRect  = new RectF(rx - sbArcR, ry - sbArcR, rx + sbArcR, ry + sbArcR);
        int   sbAlpha = (int)(170 + state.shadowBladeCharge * 85);

        // Arc color: red (T1) → orange (T2) → white-gold (T3)
        int arcR, arcG, arcB;
        if (state.shadowBladeCharge < 0.40f) {
            arcR = 255; arcG = 30;  arcB = 70;   // crimson
        } else if (state.shadowBladeCharge < 0.85f) {
            float t = (state.shadowBladeCharge - 0.40f) / 0.45f;
            arcR = 255; arcG = (int)(30 + t * 140); arcB = (int)(70 * (1f - t)); // red→orange
        } else {
            float t = (state.shadowBladeCharge - 0.85f) / 0.15f;
            arcR = 255; arcG = (int)(170 + t * 70); arcB = (int)(t * 120); // orange→gold
        }
        dpSbCharge.setStrokeWidth(4.5f);
        dpSbCharge.setColor(Color.argb(sbAlpha, arcR, arcG, arcB));
        c.drawArc(sbRect, -90f, sweep, false, dpSbCharge);

        // Tier threshold marks at 40% and 85%
        float[] ticks = {0.40f, 0.85f};
        for (float thresh : ticks) {
            float tickAngle = (float) Math.toRadians(-90f + thresh * 360f);
            float tx = rx + sbArcR * (float) Math.cos(tickAngle);
            float ty = ry + sbArcR * (float) Math.sin(tickAngle);
            boolean past = state.shadowBladeCharge >= thresh;
            dpSbTick.setColor(past ? Color.argb(220, 255, 255, 255) : Color.argb(130, 180, 180, 180));
            c.drawCircle(tx, ty, past ? 4.5f : 3f, dpSbTick);
        }

        // Bright tip dot
        float sbTipAngle = (float) Math.toRadians(-90f + sweep);
        float sbTipX = rx + sbArcR * (float) Math.cos(sbTipAngle);
        float sbTipY = ry + sbArcR * (float) Math.sin(sbTipAngle);
        dpSbTip.setColor(Color.argb(235, 255, 230, 180));
        c.drawCircle(sbTipX, sbTipY, 5.5f, dpSbTip);

        // Tier name label below the player — updates in real time as charge builds
        String tierName;
        int    tierR, tierG, tierB;
        if (state.shadowBladeCharge < 0.40f) {
            tierName = "LIGHT SLASH";  tierR = 255; tierG = 80;  tierB = 100;
        } else if (state.shadowBladeCharge < 0.85f) {
            tierName = "HEAVY SLASH";  tierR = 255; tierG = 160; tierB = 30;
        } else {
            tierName = "PHANTOM DASH"; tierR = 255; tierG = 220; tierB = 80;
        }
        dpTier.setTextSize(18f);
        dpTier.setTypeface(Typeface.DEFAULT_BOLD);
        dpTier.setColor(Color.argb(200, tierR, tierG, tierB));
        c.drawText(tierName, rx, ry + r + sbArcR + 22f, dpTier);
    }
    // Spawn protection ring
    if (p.isProtected()) {
        long rem = p.spawnProtectionUntil - System.currentTimeMillis();
        float pulse = 0.7f+0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
        dpProtRing.setStrokeWidth(4f*pulse);
        dpProtRing.setColor(Color.argb(Math.min(255,(int)(200*rem/800f)),100,200,255));
        c.drawCircle(rx,ry,(r+10)*pulse,dpProtRing);
    }
    // Shield ring
    if (p.isShielded()) {
        float pulse2 = 0.8f+0.2f*(float)Math.abs(Math.sin(System.currentTimeMillis()/150.0));
        dpShRing.setColor(Color.argb(200,255,200,0));
        c.drawCircle(rx,ry,(r+14)*pulse2,dpShRing);
    }
    // ── Status-effect particle spawning (visuals only — state.effects always active) ──
    // Circles/rings removed; particles are drawn via state.effects.drawStatusParticles().
    if (GunConfig.ShowStatusEffectVisuals) {
        if (p.isSlowed())                         state.effects.spawnSlowParticles(rx, ry, r);
        if (p.isPoisoned())                       state.effects.spawnPoisonParticles(rx, ry, r);
        if (p.isStunned() || p.isBeingPulled())   state.effects.spawnStunParticles(rx, ry, r);
    }
}

private void drawHUD(GameState state, Canvas c){
    Player lp=state.localPlayer;
    // Show connecting screen while waiting for server response (client only)
    if(lp==null){
        if(!state.isHost){
            float w=screenW, h=screenH;
            c.drawRect(0,0,w,h,fill(Color.argb(180,0,0,0)));
            Paint tp=fill(Color.WHITE); tp.setTextSize(32f); tp.setTextAlign(Paint.Align.CENTER);
            tp.setTypeface(Typeface.DEFAULT_BOLD); tp.setShadowLayer(4f,0,2f,Color.BLACK);
            c.drawText("Connecting to host…", w/2, h/2-20, tp);
            Paint tp2=fill(Color.argb(200,180,210,255)); tp2.setTextSize(18f); tp2.setTextAlign(Paint.Align.CENTER);
            c.drawText("Make sure you're on the host's hotspot", w/2, h/2+24, tp2);
        }
        return;
    }
    float w=screenW, h=screenH;

    // ── HP ────────────────────────────────────────────────────────────────
    c.drawRoundRect(10,10,215,56,8,8,hudBgP);
    hudP.setColor(Color.rgb(255,75,75)); hudP.setTextSize(27f); hudP.setTextAlign(Paint.Align.LEFT);
    c.drawText("♥ "+(int)Math.ceil(lp.hp), 22, 46, hudP);

    // ── Coins ─────────────────────────────────────────────────────────────
    c.drawRoundRect(222,10,355,56,8,8,hudBgP);
    Paint coinP2=fill(Color.rgb(255,210,50)); coinP2.setTextSize(22f);
    coinP2.setTextAlign(Paint.Align.LEFT); coinP2.setTypeface(Typeface.DEFAULT_BOLD);
    c.drawText("\uD83D\uDCB0 "+lp.coins, 234, 44, coinP2);

    // ── Kill streak badge ──────────────────────────────────────────────────
    if (!state.singlePlayer && lp.killStreak >= 2) {
        int ksColor;
        if      (lp.killStreak >= 10) ksColor = Color.argb(240, 255, 50,  50);
        else if (lp.killStreak >= 5)  ksColor = Color.argb(240, 255, 140, 20);
        else                          ksColor = Color.argb(240, 255, 210, 30);
        c.drawRoundRect(362,10,490,56,8,8,fill(Color.argb(160,20,10,5)));
        Paint ksPaint = fill(ksColor); ksPaint.setTextSize(21f);
        ksPaint.setTextAlign(Paint.Align.LEFT); ksPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ksPaint.setShadowLayer(3f, 0, 1f, Color.BLACK);
        String bonusPct = "+" + Math.round(lp.killStreak * 3) + "%";
        c.drawText("\uD83D\uDD25" + lp.killStreak + "  " + bonusPct, 374, 43, ksPaint);
    }

    // ── Difficulty / mode badge ────────────────────────────────────────────
    if (state.singlePlayer) {
        String dlbl;
        int    dcol;
        if (state.trainingMode) {
            dlbl = "TRAINING"; dcol = 0xFF22aa66;
        } else {
            String[] diffLabels = {"EASY", "NORMAL", "HARD"};
            int[]    diffColors = {0xFF2ecc71, 0xFFe94560, 0xFF8855ee};
            dlbl = diffLabels[Math.max(0, Math.min(2, difficulty))];
            dcol = diffColors[Math.max(0, Math.min(2, difficulty))];
        }
        Paint diffP = fill(dcol); diffP.setTextSize(17f);
        diffP.setTextAlign(Paint.Align.LEFT); diffP.setTypeface(Typeface.DEFAULT_BOLD);
        diffP.setShadowLayer(3f,1f,1f,Color.BLACK);
        float dlblW = diffP.measureText(dlbl);
        c.drawRoundRect(362, 14, 362 + dlblW + 18, 52, 8, 8, fill(Color.argb(140,0,0,0)));
        c.drawText(dlbl, 371, 43, diffP);
    }

    // ── Gun + ammo ────────────────────────────────────────────────────────
    if(lp.alive){
        Gun g=lp.currentGun();
        String ammoStr = g.reloading ? "RELOADING…" : (g.ammo+"/"+g.maxAmmo);
        // Background panel – taller to fit stat bars when shown
        boolean showGunStats = cachedGunStats;
        boolean isSbHud = lp.gunIndex == 21;
        c.drawRoundRect(w/2-195,6,w/2+195,showGunStats?106:(isSbHud?68:52),10,10,hudBgP);
        // Gun name + ammo
        gunTxtP.setColor(g.color);
        c.drawText(g.name+"   "+ammoStr, w/2, 36, gunTxtP);
        // Soul Surge: show tier and kill progress
        if (lp.gunIndex == 20) {
            int lv = g.soulLevel();
            int next = g.soulNextThreshold();
            String[] tierNames = {
                "☠ DORMANT", "☠ AWAKENED", "☠ PIERCING", "☠ BOUNCING",
                "☠ SEEKING", "☠ UNSTOPPABLE", "☠ ASCENDANT ★", "☠ AWAKENED ★★", "☠ UNLEASHED ★★★"
            };
            String soulLine = tierNames[Math.min(lv, tierNames.length - 1)]
                    + (next >= 0 ? "   (" + g.killCount + "/" + next + " souls)" : "  MAX POWER");
            dpSoul.setTextSize(15f); dpSoul.setTextAlign(Paint.Align.CENTER);
            int[] tierColors = {
                0xFF9E9E9E, 0xFFCE93D8, 0xFFBA68C8, 0xFFAB47BC,
                0xFF8E24AA, 0xFF6A0080, 0xFF4A0060, 0xFFD500F9, 0xFFFFD700
            };
            dpSoul.setColor(tierColors[Math.min(lv, tierColors.length - 1)]);
            c.drawText(soulLine, w/2f, 50f, dpSoul);
        }
        // Shadow Blade: show charge bar + tier name in HUD panel
        if (lp.gunIndex == 21) {
            float sbBarW = 320f, sbBarH = 9f;
            float sbBarX = w / 2f - sbBarW / 2f;
            float sbBarY = 48f;

            // Tier colors: crimson T1, orange T2, gold T3
            int sbR, sbG, sbB;
            String sbTierLabel;
            if (state.shadowBladeCharge < 0.40f) {
                sbR = 255; sbG = 30;  sbB = 70;
                sbTierLabel = "LIGHT SLASH";
            } else if (state.shadowBladeCharge < 0.85f) {
                float t = (state.shadowBladeCharge - 0.40f) / 0.45f;
                sbR = 255; sbG = (int)(30 + t * 140); sbB = (int)(70 * (1f - t));
                sbTierLabel = "HEAVY SLASH";
            } else {
                float t = (state.shadowBladeCharge - 0.85f) / 0.15f;
                sbR = 255; sbG = (int)(170 + t * 70); sbB = (int)(t * 120);
                sbTierLabel = "PHANTOM DASH";
            }

            // Bar background
            Paint sbBgP = fill(Color.argb(80, 255, 255, 255));
            c.drawRoundRect(sbBarX, sbBarY, sbBarX + sbBarW, sbBarY + sbBarH, 4, 4, sbBgP);

            // Bar fill (only if charging)
            if (state.shadowBladeCharge > 0.01f) {
                Paint sbFillP = fill(Color.argb(220, sbR, sbG, sbB));
                c.drawRoundRect(sbBarX, sbBarY, sbBarX + sbBarW * state.shadowBladeCharge, sbBarY + sbBarH, 4, 4, sbFillP);
            }

            // Tier threshold marks at 40% and 85%
            float[] sbTicks = {0.40f, 0.85f};
            for (float thresh : sbTicks) {
                float tx = sbBarX + sbBarW * thresh;
                Paint sbTickP = fill(state.shadowBladeCharge >= thresh
                        ? Color.argb(220, 255, 255, 255) : Color.argb(120, 160, 160, 160));
                c.drawRect(tx - 1f, sbBarY - 2f, tx + 1f, sbBarY + sbBarH + 2f, sbTickP);
            }

            // Tier label (right of bar, colored)
            // dpSbLbl pre-allocated
            dpSbLbl.setTextSize(13f);
            dpSbLbl.setTextAlign(Paint.Align.CENTER);
            dpSbLbl.setTypeface(Typeface.DEFAULT_BOLD);
            dpSbLbl.setColor(state.shadowBladeCharge > 0.01f
                    ? Color.argb(210, sbR, sbG, sbB) : Color.argb(120, 180, 180, 180));
            c.drawText(state.shadowBladeCharge > 0.01f ? sbTierLabel : "HOLD AIM TO CHARGE",
                    w / 2f, sbBarY + sbBarH + 14f, dpSbLbl);
        }
        // Stat bars: DMG | SPD | RANGE | RATE
        if(showGunStats){
        String[] statNames = {"DMG","SPD","RANGE","RATE"};
        float[]  statVals  = {g.statDamage(), g.statSpeed(), g.statRange(), g.statFireRate()};
        int[]    statColors= {0xFFFF5252, 0xFF64B5F6, 0xFF81C784, 0xFFFFD54F};
        float barW=68f, barH=9f, gap=10f;
        float totalW = statNames.length*(barW+gap)-gap;
        float barX = w/2 - totalW/2;
        float barY = 55f;
        for(int si=0;si<statNames.length;si++){
            float sx = barX + si*(barW+gap);
            c.drawRoundRect(sx,barY, sx+barW,barY+barH, 4,4, hudStatBgP);
            tmpRectF.set(sx,barY, sx+barW*statVals[si],barY+barH);
            Paint fp=fill(statColors[si]); // color varies per stat — keep fill() here
            c.drawRoundRect(tmpRectF, 4,4, fp);
            c.drawText(statNames[si], sx, barY+barH+14f, hudStatLblP);
        }
        }
    }

    // ── HOST: show IP so others can join ──────────────────────────────────
    if(state.isHost && !state.hostIpDisplay.isEmpty()){
        int count=state.remote.size()+1;
        String ipLine="Your IP: "+state.hostIpDisplay+"   Players: "+count;
        float bgW=ipPaint.measureText(ipLine)+24f;
        c.drawRoundRect(w/2-bgW/2,h-52,w/2+bgW/2,h-4,10,10,hudBgP);
        c.drawText(ipLine, w/2, h-14, ipPaint);
    }

    // ── Kill state.feed ─────────────────────────────────────────────────────────
    hudP.setColor(Color.rgb(255,210,70)); hudP.setTextSize(18f); hudP.setTextAlign(Paint.Align.LEFT);
    synchronized(state.feed){ for(int i=0;i<state.feed.size();i++) c.drawText(state.feed.get(i),12,72+i*24,hudP); }

    // ── Multiplayer scoreboard ─────────────────────────────────────────────
    if (!state.singlePlayer) {
        // Collect all players: local + state.remote (excluding bots/dummies)
        java.util.List<Player> sbPlayers = new java.util.ArrayList<>();
        sbPlayers.add(lp);
        for (Player rp : state.remote.values()) {
            if (!state.dummyIds.contains(rp.id)) sbPlayers.add(rp);
        }
        // Sort by kills desc, then deaths asc
        sbPlayers.sort((a2, b2) -> a2.kills != b2.kills ? b2.kills - a2.kills : a2.deaths - b2.deaths);

        float sbX = w - 260f, sbY = 14f;
        float rowH = 32f, colW = 260f;
        float headerH = 28f;
        float sbH = headerH + sbPlayers.size() * rowH + 10f;

        // Panel background
        c.drawRoundRect(sbX, sbY, sbX + colW, sbY + sbH, 10, 10,
                fill(Color.argb(170, 8, 12, 28)));

        // Header row
        hudSbHdrP.setTextAlign(Paint.Align.LEFT);
        c.drawText("PLAYER", sbX + 10f, sbY + 20f, hudSbHdrP);
        hudSbHdrP.setTextAlign(Paint.Align.CENTER);
        c.drawText("K", sbX + colW - 100f, sbY + 20f, hudSbHdrP);
        c.drawText("D", sbX + colW - 65f,  sbY + 20f, hudSbHdrP);
        c.drawText("STRK", sbX + colW - 20f, sbY + 20f, hudSbHdrP);

        // Separator
        Paint sepP = fill(Color.argb(80, 100, 140, 220));
        c.drawRect(sbX + 6f, sbY + headerH, sbX + colW - 6f, sbY + headerH + 1.5f, sepP);

        for (int si = 0; si < sbPlayers.size(); si++) {
            Player sp2 = sbPlayers.get(si);
            float ry = sbY + headerH + 6f + si * rowH;
            boolean isMe = (sp2 == lp);

            // Row highlight for local player
            if (isMe) {
                c.drawRoundRect(sbX + 4f, ry - 2f, sbX + colW - 4f, ry + rowH - 4f, 6, 6,
                        fill(Color.argb(60, 100, 160, 255)));
            }

            // Streak badge color
            int streakColor;
            if      (sp2.killStreak >= 10) streakColor = Color.argb(255, 255, 80,  80);
            else if (sp2.killStreak >= 5)  streakColor = Color.argb(255, 255, 160, 30);
            else if (sp2.killStreak >= 3)  streakColor = Color.argb(255, 255, 220, 50);
            else                           streakColor = Color.argb(180, 180, 180, 180);

            hudSbNameP.setColor(isMe ? Color.WHITE : Color.argb(210, 200, 210, 230));
            hudSbNameP.setTypeface(isMe ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            // Truncate long names
            String dname = sp2.name.length() > 10 ? sp2.name.substring(0, 10) + "…" : sp2.name;
            c.drawText(dname, sbX + 10f, ry + 20f, hudSbNameP);

            // Kills (green tint)
            hudSbNumP.setColor(Color.argb(230, 100, 255, 120));
            c.drawText(String.valueOf(sp2.kills), sbX + colW - 100f, ry + 20f, hudSbNumP);
            // Deaths (red tint)
            hudSbNumP.setColor(Color.argb(200, 255, 110, 110));
            c.drawText(String.valueOf(sp2.deaths), sbX + colW - 65f, ry + 20f, hudSbNumP);
            // Streak (colored by level)
            hudSbNumP.setColor(streakColor);
            String streakTxt = sp2.killStreak > 0 ? "🔥" + sp2.killStreak : "-";
            c.drawText(streakTxt, sbX + colW - 20f, ry + 20f, hudSbNumP);
        }
    }

    // ── Disconnect overlay ─────────────────────────────────────────────────
    if(!state.singlePlayer && !state.isHost && net!=null && net.isDisconnected()){
        // Pulsing amber banner across the top
        long now2=System.currentTimeMillis();
        int pulse=(int)(180+75*Math.abs(Math.sin(now2/500.0)));
        Paint discBg=fill(Color.argb(Math.min(255,pulse),120,40,0));
        c.drawRoundRect(w*0.1f,14,w*0.9f,66,12,12,discBg);
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(22f);
        uiTxt.setTextAlign(Paint.Align.CENTER);
        uiTxt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        uiTxt.setShadowLayer(4f,0,1f,Color.BLACK);
        c.drawText("\u26A0 DISCONNECTED \u2014 Reconnecting\u2026",w/2,48,uiTxt);
    }

    // ── Death overlay ─────────────────────────────────────────────────────
    if(!lp.alive){
        c.drawRect(0,0,w,h,deathBgP);
        c.drawText("YOU DIED",w/2,h/2-18,deathTxtP);
        long rem=RESPAWN_MS-(System.currentTimeMillis()-state.deathTime);
        if(rem>0){
            uiCopy.set(deathTxtP); uiCopy.setTextSize(28f); uiCopy.setColor(Color.WHITE);
            uiCopy.setTextAlign(Paint.Align.CENTER);
            c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,uiCopy);
        }
    }

    // ── Buttons ───────────────────────────────────────────────────────────
    // Weapon wheel — gear icon circle
    { float _scx=switchRect.centerX(), _scy=switchRect.centerY(), _sr=switchRect.width()/2f;
      c.drawCircle(_scx, _scy, _sr, btnP);
      uiCopy.set(btnTxtP); uiCopy.setTextSize(_sr * 0.70f);
      c.drawText("⚙", _scx, _scy + _sr*0.25f, uiCopy); }

    // Reload button — icon only (no text), shows reload arc progress when reloading
    { boolean asLocked = lp != null && lp.currentGun().bulletAirStrike;
      float _rcx = reloadRect.centerX(), _rcy = reloadRect.centerY();
      float _rr = Math.min(reloadRect.width(), reloadRect.height()) / 2f;
      if (asLocked) {
          c.drawCircle(_rcx, _rcy, _rr, fill(Color.argb(70, 55, 55, 65)));
          uiP.setTextSize(_rr * 1.05f); uiP.setTextAlign(Paint.Align.CENTER);
          uiP.setColor(Color.argb(110, 190, 190, 190));
          c.drawText("\uD83D\uDD12", _rcx, _rcy + _rr * 0.38f, uiP);
      } else if (lp != null && lp.currentGun().reloading) {
          // Show cool progress arc while reloading
          long elapsed = System.currentTimeMillis() - (lp.currentGun().reloadStart);
          float effectiveReloadMs = lp.currentGun().reloadMs * lp.reloadMult();
          float progress = Math.min(1f, elapsed / effectiveReloadMs);
          c.drawCircle(_rcx, _rcy, _rr, fill(Color.argb(120, 40, 40, 60)));
          uiP.setStyle(Paint.Style.STROKE); uiP.setStrokeWidth(5f);
          uiP.setColor(Color.argb(80, 200, 200, 255)); uiP.setStrokeCap(Paint.Cap.ROUND);
          android.graphics.RectF arcRect = new android.graphics.RectF(_rcx-_rr+4, _rcy-_rr+4, _rcx+_rr-4, _rcy+_rr-4);
          c.drawArc(arcRect, -90f, 360f, false, uiP);
          uiCopy.set(uiP); uiCopy.setColor(Color.argb(230, 100, 200, 255));
          c.drawArc(arcRect, -90f, 360f * progress, false, uiCopy);
          uiTxt.setTextSize(_rr * 0.90f); uiTxt.setTextAlign(Paint.Align.CENTER);
          uiTxt.setColor(Color.argb(200, 100, 200, 255));
          c.drawText("↺", _rcx, _rcy + _rr * 0.35f, uiTxt);
      } else {
          c.drawCircle(_rcx, _rcy, _rr, btnP);
          uiTxt.setTextSize(_rr * 1.0f); uiTxt.setTextAlign(Paint.Align.CENTER);
          uiTxt.setColor(Color.WHITE); uiTxt.setTypeface(Typeface.DEFAULT_BOLD);
          uiTxt.setShadowLayer(3f, 0, 1f, Color.BLACK);
          c.drawText("↺", _rcx, _rcy + _rr * 0.38f, uiTxt);
      }
    }

    // Bomb button — circle with count badge
    if (bombRect != null && lp != null) {
        boolean hasBombs = lp.bombs > 0;
        float _bcx = bombRect.centerX(), _bcy = bombRect.centerY();
        float _br = Math.min(bombRect.width(), bombRect.height()) / 2f;
        Paint bombBtnP;
        if (state.throwingBomb) {
            bombBtnP = fill(Color.argb(230, 220, 160, 0));
        } else {
            bombBtnP = fill(hasBombs ? Color.argb(210, 200, 80, 0) : Color.argb(120, 60, 60, 60));
        }
        c.drawCircle(_bcx, _bcy, _br, bombBtnP);
        // Bomb emoji icon
        uiTxt.setTextSize(_br * 1.05f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
        c.drawText(state.throwingBomb ? "✕" : "\uD83D\uDCA3", _bcx, _bcy + _br * 0.38f, uiTxt);
        // Count badge (top-right corner of circle)
        if (!state.throwingBomb && lp.bombs > 0) {
            float badgeX = _bcx + _br * 0.65f, badgeY = _bcy - _br * 0.65f;
            c.drawCircle(badgeX, badgeY, _br * 0.34f, fill(Color.argb(230, 50, 50, 50)));
            uiTxt.setTextSize(_br * 0.42f); uiTxt.setTextAlign(Paint.Align.CENTER);
            uiTxt.setColor(Color.WHITE); uiTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(String.valueOf(lp.bombs), badgeX, badgeY + _br * 0.14f, uiTxt);
        }
        // AIM hint
        if (state.throwingBomb) {
            Paint hintP = fill(Color.argb(200, 255, 230, 100));
            hintP.setTextSize(16f); hintP.setTextAlign(Paint.Align.CENTER);
            hintP.setShadowLayer(3f, 0, 1f, Color.BLACK);
            c.drawText("aim joystick \u2192 release", _bcx, bombRect.top - 8f, hintP);
        }
    }

    // Drop weapon button — trash icon
    if (dropRect != null && lp != null) {
        int unlockedCount = 0;
        for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
        boolean canDrop = unlockedCount > 1;
        float _dcx = dropRect.centerX(), _dcy = dropRect.centerY();
        float _dr = Math.min(dropRect.width(), dropRect.height()) / 2f;
        c.drawCircle(_dcx, _dcy, _dr, fill(canDrop ? Color.argb(200, 140, 40, 40) : Color.argb(80, 60, 60, 60)));
        uiTxt.setTextSize(_dr * 1.0f); uiTxt.setTextAlign(Paint.Align.CENTER);
        uiTxt.setColor(canDrop ? Color.WHITE : Color.argb(120, 180, 180, 180));
        uiTxt.setShadowLayer(2f, 0, 1f, Color.BLACK);
        c.drawText("\uD83D\uDDD1", _dcx, _dcy + _dr * 0.38f, uiTxt);
    }

    // Paint mode button — only visible when Paint Launcher is equipped
    if (paintModeRect != null && lp != null && lp.gunIndex == 15) {
        Gun pg = lp.currentGun();
        int pm = pg.paintMode; // 0=ALT, 1=SLOW, 2=POISON
        int[] pmColors = { Color.argb(220,0,188,212), Color.argb(220,30,100,220), Color.argb(220,30,180,70) };
        String[] pmEmoji  = { "🎨", "🐌", "☠" };
        String[] pmLabels = { "ALT", "SLOW", "POISON" };
        Paint pmBtnP = fill(pmColors[pm]);
        float _pmcx = paintModeRect.centerX(), _pmcy = paintModeRect.centerY();
        float _pmr = Math.min(paintModeRect.width(), paintModeRect.height()) / 2f;
        c.drawCircle(_pmcx, _pmcy, _pmr, pmBtnP);
        // Icon line
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(20f);
        uiTxt.setTextAlign(Paint.Align.CENTER);
        uiTxt.setTypeface(Typeface.DEFAULT_BOLD);
        uiTxt.setShadowLayer(3f, 0, 1f, Color.BLACK);
        c.drawText(pmEmoji[pm], _pmcx, _pmcy - 5f, uiTxt);
        // Label line
        // uiCopy used for pmLblP
        uiCopy.setColor(Color.WHITE); uiCopy.setTextSize(13f);
        uiCopy.setTextAlign(Paint.Align.CENTER);
        uiCopy.setTypeface(Typeface.DEFAULT_BOLD);
        uiCopy.setShadowLayer(2f, 0, 1f, Color.BLACK);
        c.drawText(pmLabels[pm], _pmcx, _pmcy + _pmr - 8f, uiCopy);
    }

    // Active skill button
    if (skillRect != null && lp != null && lp.activeSkillType != Player.ACTIVE_NONE) {
        float scx = skillRect.centerX(), scy = skillRect.centerY(), sr = skillRect.width() / 2f;
        boolean onCd  = lp.skillOnCooldown();
        boolean active = lp.skillIsActive();
        // Background
        int bgAlpha = onCd ? 120 : 200;
        uiP.setStyle(Paint.Style.FILL);
        uiP.setColor(Color.argb(bgAlpha, 20, 20, 50));
        c.drawCircle(scx, scy, sr, uiP);
        // Active glow ring
        if (active) {
            uiP.setStyle(Paint.Style.STROKE); uiP.setStrokeWidth(4f);
            uiP.setColor(Color.argb(200, 100, 220, 255));
            c.drawCircle(scx, scy, sr + 2f, uiP);
        }
        // Cooldown arc overlay
        if (onCd) {
            long cdTotal = lp.skillCooldownEnd - lp.skillActiveUntil;
            if (cdTotal <= 0) cdTotal = 1;
            float cdRatio = Math.min(1f, (float)(lp.skillCooldownEnd - System.currentTimeMillis()) / cdTotal);
            uiP.setStyle(Paint.Style.FILL);
            uiP.setColor(Color.argb(140, 0, 0, 0));
            RectF arcRect = new RectF(scx - sr, scy - sr, scx + sr, scy + sr);
            c.drawArc(arcRect, -90f, cdRatio * 360f, true, uiP);
        }
        // Skill emoji icon
        String[] icons = {"", "💨", "🌫", "💊", "🛡"};
        String icon = lp.activeSkillType < icons.length ? icons[lp.activeSkillType] : "?";
        uiTxt.setColor(onCd ? Color.argb(140, 255, 255, 255) : Color.WHITE);
        uiTxt.setTextSize(sr * 0.9f); uiTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText(icon, scx, scy + sr * 0.32f, uiTxt);
        // Border ring
        uiP.setStyle(Paint.Style.STROKE); uiP.setStrokeWidth(2.5f);
        uiP.setColor(Color.argb(160, 100, 140, 220));
        c.drawCircle(scx, scy, sr, uiP);
    }

    // Spawn protection pulsing shield ring (screen-space around player circle)
    if (lp != null && lp.alive && lp.isProtected()) {
        long rem = lp.spawnProtectionUntil - System.currentTimeMillis();
        float pulse = 0.7f + 0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
        float alpha = Math.min(1f, rem/800f);
        // Draw in screen centre (player is always at centre of screen)
        float cx2 = screenW/2f, cy2 = screenH/2f;
        uiP.setStyle(Paint.Style.STROKE); uiP.setStrokeWidth(5f*pulse);
        uiP.setColor(Color.argb((int)(200*alpha),100,200,255));
        c.drawCircle(cx2, cy2, (PR*state.currentZoom+18)*pulse, uiP);
        // Timer text
        Paint protTxt = fill(Color.argb((int)(230*alpha),120,220,255));
        protTxt.setTextSize(16f); protTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("🛡 "+(rem/1000+1)+"s", cx2, cy2-(PR*state.currentZoom+32), protTxt);
    }

    // ── Gear button ───────────────────────────────────────────────────────
    if(gearRect!=null){
        Paint gearBg=fill(Color.argb(settingsOpen?210:140,40,50,80));
        c.drawRoundRect(gearRect,10,10,gearBg);
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(26f);
        uiTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("⚙",gearRect.centerX(),gearRect.centerY()+10,uiTxt);
    }

    // ── Shop button ───────────────────────────────────────────────────────
    if(shopBtn!=null){
        Paint sbP=fill(Color.argb(shopOpen?210:150,160,120,10));
        c.drawRoundRect(shopBtn,10,10,sbP);
        uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(22f); uiTxt.setTextAlign(Paint.Align.CENTER);
        c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,uiTxt);
    }

    // ── Joysticks ─────────────────────────────────────────────────────────
    if(moveStick!=null) moveStick.draw(c);
    if(aimStick!=null)  aimStick.draw(c);

    // ── Button-move mode overlay ───────────────────────────────────────────
    if(btnMoveMode){
        Paint dimP = fill(Color.argb(120,0,0,0));
        c.drawRect(0,0,w,h,dimP);
        // Redraw buttons with highlight — selected button glows differently
        Paint hlP    = fill(Color.argb(220,80,160,255));
        Paint hlSelP = fill(Color.argb(240,255,190,40)); // gold = currently selected for sizing
        boolean sizing = btnSizingId != -1;
        if(switchRect!=null){
            Paint p2 = (sizing && btnSizingId==0) ? hlSelP : hlP;
            float _scx=switchRect.centerX(),_scy=switchRect.centerY(),_sr=switchRect.width()/2f;
            c.drawCircle(_scx,_scy,_sr,p2);
            uiCopy.set(btnTxtP); uiCopy.setTextSize(_sr*0.70f);
            c.drawText("⚙",_scx,_scy+_sr*0.25f,uiCopy);
        }
        if(reloadRect!=null){
            Paint p2 = (sizing && btnSizingId==1) ? hlSelP : hlP;
            float _rcx=reloadRect.centerX(),_rcy=reloadRect.centerY(),_rr=Math.min(reloadRect.width(),reloadRect.height())/2f;
            c.drawCircle(_rcx,_rcy,_rr,p2);
            uiTxt.setTextSize(_rr*1.0f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
            c.drawText("↺",_rcx,_rcy+_rr*0.38f,uiTxt);
        }
        if(dropRect!=null) {
            float _dcx=dropRect.centerX(),_dcy=dropRect.centerY(),_dr=Math.min(dropRect.width(),dropRect.height())/2f;
            c.drawCircle(_dcx,_dcy,_dr,hlP);
            uiTxt.setTextSize(_dr*1.0f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
            c.drawText("\uD83D\uDDD1",_dcx,_dcy+_dr*0.38f,uiTxt);
        }
        if(bombRect!=null) {
            float _bcx=bombRect.centerX(),_bcy=bombRect.centerY(),_br=Math.min(bombRect.width(),bombRect.height())/2f;
            c.drawCircle(_bcx,_bcy,_br,hlP);
            uiTxt.setTextSize(_br*1.0f); uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setColor(Color.WHITE);
            c.drawText("\uD83D\uDCA3",_bcx,_bcy+_br*0.38f,uiTxt);
        }
        if(paintModeRect!=null) {
            float _pmcx=paintModeRect.centerX(),_pmcy=paintModeRect.centerY(),_pmr=Math.min(paintModeRect.width(),paintModeRect.height())/2f;
            c.drawCircle(_pmcx,_pmcy,_pmr,fill(Color.argb(200,0,188,212))); c.drawText("🎨",_pmcx,_pmcy+8,btnTxtP);
        }
        if(skillRect!=null) {
            Paint p2 = (sizing && btnSizingId==5) ? hlSelP : hlP;
            float _scx=skillRect.centerX(),_scy=skillRect.centerY(),_sr=skillRect.width()/2f;
            c.drawCircle(_scx, _scy, _sr, p2);
            uiCopy.set(btnTxtP); uiCopy.setTextSize(_sr*0.38f);
            c.drawText("SKILL", _scx, _scy+8, uiCopy);
        }
        if(shopBtn!=null){
            c.drawRoundRect(shopBtn,10,10,hlP);
            uiTxt.setColor(Color.WHITE); uiTxt.setTextSize(22f); uiTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,uiTxt);
        }
            // Instruction label
        Paint infoP = fill(Color.WHITE); infoP.setTextSize(20f); infoP.setTextAlign(Paint.Align.CENTER);
        infoP.setShadowLayer(3f,0,2f,Color.BLACK);
        c.drawText(sizing ? "Drag slider to resize  |  Drag button to move" : "Drag to move  |  Tap button to resize", w/2, h/2 - 20, infoP);

        // ── Training buttons (shown in move mode so they can be repositioned) ──
        if (state.trainingMode) {
            Paint thlP = fill(Color.argb(220, 100, 200, 130));
            String[] tLabels = {"+ Dummy", "- Dummy", "+200 Coins"};
            RectF[]  tRects  = {trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn};
            for (int i = 0; i < tRects.length; i++) {
                if (tRects[i] == null) continue;
                c.drawRoundRect(tRects[i], 10, 10, thlP);
                c.drawText(tLabels[i], tRects[i].centerX(), tRects[i].centerY()+8, btnTxtP);
            }
        }

        // ── Size slider (shown when a button is tapped) ───────────────────
        if(sizing && sizeSliderTrack != null) {
            // Derive current scale for label
            float curScale = 0.4f + sizeSliderVal * 1.8f;
            String btnName = btnSizingId==0 ? "⚙ WHEEL" : (btnSizingId==1 ? "RELOAD" : "SKILL");
            uiTxt.setColor(Color.argb(220,255,220,80)); uiTxt.setTextSize(19f);
            uiTxt.setTextAlign(Paint.Align.CENTER); uiTxt.setShadowLayer(3f,0,2f,Color.BLACK);
            c.drawText(btnName + "  SIZE: " + (int)(curScale*100) + "%",
                    sizeSliderTrack.centerX(), sizeSliderTrack.top - 14f, uiTxt);
            // Track background
            Paint trackBg = fill(Color.argb(180,30,40,80));
            c.drawRoundRect(sizeSliderTrack, 16f, 16f, trackBg);
            // Filled portion
            float knobX = sizeSliderTrack.left + sizeSliderVal * sizeSliderTrack.width();
            RectF filled = new RectF(sizeSliderTrack.left, sizeSliderTrack.top, knobX, sizeSliderTrack.bottom);
            Paint fillP = fill(Color.argb(220,80,180,255));
            c.drawRoundRect(filled, 16f, 16f, fillP);
            // Knob
            Paint knobP = fill(Color.argb(255,255,255,255));
            c.drawCircle(knobX, sizeSliderTrack.centerY(), sizeSliderTrack.height()*0.82f, knobP);
            // Min / Max labels
            uiCopy.setColor(Color.argb(180,200,200,200)); uiCopy.setTextSize(15f);
            uiCopy.setTextAlign(Paint.Align.LEFT);
            c.drawText("40%", sizeSliderTrack.left + 4, sizeSliderTrack.bottom + 18f, uiCopy);
            uiCopy.setTextAlign(Paint.Align.RIGHT);
            c.drawText("220%", sizeSliderTrack.right - 4, sizeSliderTrack.bottom + 18f, uiCopy);
        }

        // Confirm button
        if(confirmMoveRect!=null){
            Paint confP = fill(Color.argb(230,50,190,90));
            c.drawRoundRect(confirmMoveRect,12,12,confP);
            uiCopy.set(btnTxtP); uiCopy.setTextSize(24f);
            c.drawText("✓  DONE", confirmMoveRect.centerX(), confirmMoveRect.centerY()+9, uiCopy);
        }
    }

    // ── Weapon wheel overlay ──────────────────────────────────────────────
    if(wheelOpen) drawWeaponWheel(c);

    // ── Settings overlay ──────────────────────────────────────────────────
    if(settingsOpen) drawSettings(c);

    // ── Per-gun Release Fire overlay ──────────────────────────────────────
    if(relFireOpen) drawRelFirePanel(c);

    // ── Shop overlay ──────────────────────────────────────────────────────
    if(shopOpen) drawShop(c);

    // ── Training overlay ──────────────────────────────────────────────────
    if(state.trainingMode) drawTrainingHUD(c);
}

// ── Overlay implementations (ported from v93 GameView) ──────────────────────

private void drawOpt(Canvas c, RectF r, String label, boolean selected) {
    if(r==null) return;
    c.drawRoundRect(r, 8, 8, selected ? optBtnSelP : optBtnP);
    Paint t = new Paint(optTxtP);
    if(selected) { t.setColor(Color.WHITE); } else { t.setColor(Color.argb(180,200,210,230)); }
    c.drawText(label, r.centerX(), r.centerY()+7, t);
}

private void drawWeaponWheel(Canvas c) {
    if (wheelSlots == null || wheelSlots.length == 0) return;
    Player lp = state.localPlayer; if (lp == null) return;
    Gun[] allGuns = lp.guns;
    int n = wheelSlots.length;
    float sliceDeg = 360f / n;
    float startDeg = -90f;
    c.drawRect(0, 0, screenW, screenH, fill(Color.argb(140, 0, 0, 0)));
    float outerR = wheelRadius, innerR = outerR * 0.38f;
    Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    ringBg.setStyle(Paint.Style.FILL); ringBg.setColor(Color.argb(200, 15, 20, 35));
    c.drawCircle(wheelCX, wheelCY, outerR + 8f, ringBg);
    if (wheelOval != null) wheelOval.set(wheelCX-outerR, wheelCY-outerR, wheelCX+outerR, wheelCY+outerR);
    Paint sliceP = new Paint(Paint.ANTI_ALIAS_FLAG); sliceP.setStyle(Paint.Style.FILL);
    Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG); borderP.setStyle(Paint.Style.STROKE); borderP.setStrokeWidth(2.5f);
    for (int i = 0; i < n; i++) {
        float sweep = sliceDeg - 2f, begin = startDeg + i * sliceDeg + 1f;
        boolean hovered = (i == wheelHovered);
        int slotGunIdx = wheelSlots[i];
        int baseColor = allGuns[slotGunIdx].color;
        int r = Color.red(baseColor), g = Color.green(baseColor), b = Color.blue(baseColor);
        boolean isEmpty = allGuns[slotGunIdx].ammo == 0 && !allGuns[slotGunIdx].reloading;
        sliceP.setColor(hovered ? Color.argb(230,r,g,b) : isEmpty ? Color.argb(55,r/3,g/3,b/3) : Color.argb(110,r/2,g/2,b/2));
        borderP.setColor(hovered ? Color.argb(255,r,g,b) : isEmpty ? Color.argb(70,r,g,b) : Color.argb(130,r,g,b));
        android.graphics.Path slicePath = wheelSlicePath;
        slicePath.reset(); slicePath.moveTo(wheelCX, wheelCY);
        slicePath.arcTo(wheelOval, begin, sweep); slicePath.close();
        c.drawPath(slicePath, sliceP); c.drawPath(slicePath, borderP);
        float midAngleDeg = begin + sweep/2f, midAngleRad = (float)Math.toRadians(midAngleDeg);
        float labelR2 = (outerR+innerR)/2f;
        float lx = wheelCX+(float)Math.cos(midAngleRad)*labelR2, ly = wheelCY+(float)Math.sin(midAngleRad)*labelR2;
        Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG); labelP.setTextAlign(Paint.Align.CENTER);
        labelP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        labelP.setColor(hovered ? Color.WHITE : Color.argb(200,220,220,220));
        labelP.setShadowLayer(3f,0,1f,Color.BLACK);
        String[] gunIcons={"🔫","🔫","🔫","🔫","🎯","🔫","⚙","🔫","🔫","🔵","🟢","⚡","🎯","💥","👻","🎨","💰","🗡"};
        String icon=(slotGunIdx<gunIcons.length)?gunIcons[slotGunIdx]:"🔫";
        labelP.setTextSize(hovered?22f:18f); c.drawText(icon, lx, ly-7f, labelP);
        labelP.setTextSize(hovered?14f:11f); c.drawText(allGuns[slotGunIdx].name, lx, ly+14f, labelP);
        Gun sg=allGuns[slotGunIdx]; boolean isActive=(lp.gunIndex==slotGunIdx);
        Paint subP=new Paint(Paint.ANTI_ALIAS_FLAG); subP.setTextSize(10f); subP.setTextAlign(Paint.Align.CENTER);
        String ammoLabel;
        if(sg.reloading){subP.setColor(Color.argb(255,255,185,30)); ammoLabel="RELOADING\u2026";}
        else if(sg.ammo==0){subP.setColor(Color.argb(255,255,70,70)); ammoLabel="EMPTY";}
        else{subP.setColor(isActive?Color.argb(255,100,255,100):Color.argb(160,180,180,180)); ammoLabel=sg.ammo+"/"+sg.maxAmmo;}
        c.drawText(ammoLabel, lx, ly+27f, subP);
        if(sg.coinScaling){float effDmg=20f+Math.min(lp.coins,600)*0.167f; Paint coinHint=new Paint(Paint.ANTI_ALIAS_FLAG); coinHint.setTextSize(9f); coinHint.setTextAlign(Paint.Align.CENTER); coinHint.setColor(Color.argb(200,255,215,0)); c.drawText("\u26A1"+(int)effDmg+"dmg",lx,ly+38f,coinHint);}
    }
    Paint holeFill=new Paint(Paint.ANTI_ALIAS_FLAG); holeFill.setStyle(Paint.Style.FILL); holeFill.setColor(Color.argb(230,10,14,24));
    c.drawCircle(wheelCX,wheelCY,innerR,holeFill);
    Paint holeRing=new Paint(Paint.ANTI_ALIAS_FLAG); holeRing.setStyle(Paint.Style.STROKE); holeRing.setStrokeWidth(2f); holeRing.setColor(Color.argb(160,100,140,200));
    c.drawCircle(wheelCX,wheelCY,innerR,holeRing);
    String centerMain, centerSub;
    if(wheelHovered>=0&&wheelHovered<n){int sel=wheelSlots[wheelHovered]; centerMain=lp.guns[sel].name; centerSub="SELECT";}
    else{centerMain=lp.currentGun().name; centerSub="drag to pick";}
    Paint cTitleP=new Paint(Paint.ANTI_ALIAS_FLAG); cTitleP.setTextSize(15f); cTitleP.setTextAlign(Paint.Align.CENTER);
    cTitleP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    cTitleP.setColor(wheelHovered>=0?Color.WHITE:Color.argb(200,180,200,255)); cTitleP.setShadowLayer(3f,0,1f,Color.BLACK);
    c.drawText(centerMain,wheelCX,wheelCY-5f,cTitleP);
    Paint cSubP=new Paint(Paint.ANTI_ALIAS_FLAG); cSubP.setTextSize(11f); cSubP.setTextAlign(Paint.Align.CENTER); cSubP.setColor(Color.argb(150,160,180,220));
    c.drawText(centerSub,wheelCX,wheelCY+13f,cSubP);
    Paint coinP=new Paint(Paint.ANTI_ALIAS_FLAG); coinP.setTextSize(13f); coinP.setTextAlign(Paint.Align.CENTER); coinP.setColor(Color.argb(200,255,215,0)); coinP.setShadowLayer(2f,0,1f,Color.BLACK);
    c.drawText("\uD83D\uDCB0 "+lp.coins, wheelCX, wheelCY+outerR+26f, coinP);
}

private void drawSettings(Canvas c) {
    if(settingsPanel==null||ctx==null) return;
    android.content.SharedPreferences prefs = ctx.getSharedPreferences("shooter_ctrl", 0);
    int jsSize=prefs.getInt("js_size",1), btnSize=prefs.getInt("btn_size",1), opacity=prefs.getInt("opacity",1), aimSens=prefs.getInt("aim_sens",1);
    boolean swap=prefs.getBoolean("swap",false), showGunStats=prefs.getBoolean("gun_stats",true), showAimLine=prefs.getBoolean("aim_line",false);
    c.drawRoundRect(settingsPanel, 16, 16, settingsBgP);
    Paint border=new Paint(Paint.ANTI_ALIAS_FLAG); border.setColor(Color.argb(160,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
    c.drawRoundRect(settingsPanel, 16, 16, border);
    float px=settingsPanel.left, py=settingsPanel.top, pw=settingsPanel.width();
    c.drawText("\u2699  CONTROLS", px+20, py+42, settingsTitleP);
    if(closeSettingsRect!=null){c.drawRoundRect(closeSettingsRect,8,8,closeBtnP); Paint cTxt=new Paint(optTxtP); cTxt.setTextSize(20f); c.drawText("\u2715",closeSettingsRect.centerX(),closeSettingsRect.centerY()+7,cTxt);}
    c.drawRect(px+16,py+58,px+pw-16,py+60,fill(Color.argb(60,255,255,255)));
    String[] labels={"JOYSTICK SIZE","SWAP SIDES","BUTTON SIZE","AIM SPEED","OPACITY","GUN STATS","AIM LINE","RELEASE FIRE","FIRE THRESH"};
    float[] rowY={py+66f,py+128f,py+190f,py+252f,py+314f,py+376f,py+438f,py+500f,py+562f};
    for(int r=0;r<9;r++) c.drawText(labels[r],px+20,rowY[r]+26,settingsLabelP);
    if(jsSizeOpts!=null){String[] jL={"S","M","L"}; for(int i=0;i<3;i++) drawOpt(c,jsSizeOpts[i],jL[i],i==jsSize);}
    if(swapOpts!=null){String[] sL={"OFF","ON"}; for(int i=0;i<2;i++) drawOpt(c,swapOpts[i],sL[i],i==(swap?1:0));}
    if(btnSizeOpts!=null){String[] bL={"S","M","L"}; for(int i=0;i<3;i++) drawOpt(c,btnSizeOpts[i],bL[i],i==btnSize);}
    if(aimSensOpts!=null){String[] aL={"SLOW","NORM","FAST"}; for(int i=0;i<3;i++) drawOpt(c,aimSensOpts[i],aL[i],i==aimSens);}
    if(opacityOpts!=null){String[] oL={"LO","MED","HI"}; for(int i=0;i<3;i++) drawOpt(c,opacityOpts[i],oL[i],i==opacity);}
    if(gunStatOpts!=null){String[] gL={"ON","OFF"}; for(int i=0;i<2;i++) drawOpt(c,gunStatOpts[i],gL[i],i==(showGunStats?0:1));}
    if(aimLineOpts!=null){String[] alL={"ON","OFF"}; for(int i=0;i<2;i++) drawOpt(c,aimLineOpts[i],alL[i],i==(showAimLine?0:1));}
    if(relFireOpenBtn!=null){int rfCount=0; for(int i=0;i<GUN_NAMES.length;i++) if(prefs.getBoolean("rel_fire_"+i,false)) rfCount++; c.drawRoundRect(relFireOpenBtn,8,8,optBtnSelP); Paint rfT=new Paint(optTxtP); rfT.setColor(Color.WHITE); rfT.setTextSize(17f); c.drawText(rfCount==0?"OFF \u25B6":rfCount+" gun"+(rfCount>1?"s":"")+" \u25B6",relFireOpenBtn.centerX(),relFireOpenBtn.centerY()+7f,rfT);}
    if(fireThreshValRect!=null){c.drawRoundRect(fireThreshValRect,8,8,fill(Color.argb(180,30,40,70))); Paint ftB=new Paint(Paint.ANTI_ALIAS_FLAG); ftB.setColor(Color.argb(140,80,120,200)); ftB.setStyle(Paint.Style.STROKE); ftB.setStrokeWidth(1.5f); c.drawRoundRect(fireThreshValRect,8,8,ftB); Paint ftV=new Paint(optTxtP); ftV.setColor(Color.WHITE); ftV.setTextSize(18f); c.drawText(String.format(java.util.Locale.US,"%.2f",cachedFireThresh),fireThreshValRect.centerX(),fireThreshValRect.centerY()+7,ftV);}
    if(fireThreshEditBtn!=null){c.drawRoundRect(fireThreshEditBtn,8,8,optBtnSelP); Paint eT=new Paint(optTxtP); eT.setColor(Color.WHITE); eT.setTextSize(17f); c.drawText("EDIT",fireThreshEditBtn.centerX(),fireThreshEditBtn.centerY()+7,eT);}
    if(moveBtnsRect!=null){c.drawRoundRect(moveBtnsRect,10,10,fill(Color.argb(210,60,110,190))); Paint mT=new Paint(optTxtP); mT.setTextSize(19f); mT.setColor(Color.WHITE); c.drawText("\u2725  MOVE BUTTONS",moveBtnsRect.centerX(),moveBtnsRect.centerY()+7,mT);}
    if(mainMenuRect!=null){c.drawRoundRect(mainMenuRect,10,10,fill(Color.argb(220,160,30,30))); Paint mT=new Paint(optTxtP); mT.setTextSize(19f); mT.setColor(Color.WHITE); c.drawText("\u23CE  MAIN MENU",mainMenuRect.centerX(),mainMenuRect.centerY()+7,mT);}
    if(changeNameRect!=null){c.drawRoundRect(changeNameRect,10,10,fill(Color.argb(220,30,120,160))); Paint nT=new Paint(optTxtP); nT.setTextSize(19f); nT.setColor(Color.WHITE); Player lp=state.localPlayer; c.drawText("\u270E  CHANGE NAME  ["+(lp!=null?lp.name:"???")+"]",changeNameRect.centerX(),changeNameRect.centerY()+7,nT);}
}

private void drawRelFirePanel(Canvas c) {
    if(relFirePanel==null||ctx==null) return;
    android.content.SharedPreferences prefs=ctx.getSharedPreferences("shooter_ctrl",0);
    float rfpX=relFirePanel.left, rfpY=relFirePanel.top, rfpW=relFirePanel.width();
    c.drawRoundRect(relFirePanel,16,16,settingsBgP);
    Paint border=new Paint(Paint.ANTI_ALIAS_FLAG); border.setColor(Color.argb(160,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
    c.drawRoundRect(relFirePanel,16,16,border);
    c.drawText("\u26A1  RELEASE FIRE",rfpX+20,rfpY+42,settingsTitleP);
    if(relFireCloseBtn!=null){c.drawRoundRect(relFireCloseBtn,8,8,closeBtnP); Paint cT=new Paint(optTxtP); cT.setTextSize(20f); c.drawText("\u2715",relFireCloseBtn.centerX(),relFireCloseBtn.centerY()+7,cT);}
    c.drawRect(rfpX+16,rfpY+58,rfpX+rfpW-16,rfpY+60,fill(Color.argb(60,255,255,255)));
    float rfColW=rfpW/2f-12f; int rfRows=10; float rfRowH=38f, rfRowGap=5f, rfContentY=rfpY+62f;
    Paint gunNameP=new Paint(Paint.ANTI_ALIAS_FLAG); gunNameP.setTextSize(15f); gunNameP.setTextAlign(Paint.Align.LEFT);
    for(int i=0;i<GUN_NAMES.length;i++){
        int col=i/rfRows, row=i%rfRows;
        float rfRx=rfpX+10f+col*(rfColW+12f), ry=rfContentY+row*(rfRowH+rfRowGap);
        boolean isOn=prefs.getBoolean("rel_fire_"+i,false);
        int gunColor=GUN_COLORS[i];
        c.drawRoundRect(new RectF(rfRx,ry,rfRx+rfColW,ry+rfRowH),6,6,fill(Color.argb(30,Color.red(gunColor),Color.green(gunColor),Color.blue(gunColor))));
        c.drawRoundRect(new RectF(rfRx,ry+8,rfRx+4,ry+rfRowH-8),2,2,fill(gunColor));
        gunNameP.setColor(isOn?Color.WHITE:Color.argb(160,200,210,230));
        c.drawText(GUN_NAMES[i],rfRx+12,ry+rfRowH/2f+6,gunNameP);
        if(relFireToggleON!=null&&relFireToggleON[i]!=null){Paint onP=isOn?fill(Color.argb(230,Color.red(gunColor)/2+60,Color.green(gunColor)/2+60,Color.blue(gunColor)/2+40)):fill(Color.argb(80,40,50,80)); c.drawRoundRect(relFireToggleON[i],6,6,onP); Paint onT=new Paint(optTxtP); onT.setTextSize(13f); onT.setColor(isOn?Color.WHITE:Color.argb(120,180,190,210)); c.drawText("ON",relFireToggleON[i].centerX(),relFireToggleON[i].centerY()+5,onT);}
        if(relFireToggleOFF!=null&&relFireToggleOFF[i]!=null){Paint offP=!isOn?fill(Color.argb(180,60,30,30)):fill(Color.argb(80,40,50,80)); c.drawRoundRect(relFireToggleOFF[i],6,6,offP); Paint offT=new Paint(optTxtP); offT.setTextSize(13f); offT.setColor(!isOn?Color.argb(220,255,160,160):Color.argb(120,180,190,210)); c.drawText("OFF",relFireToggleOFF[i].centerX(),relFireToggleOFF[i].centerY()+5,offT);}
    }
}

private void drawShop(Canvas c) {
    Player lp=state.localPlayer;
    float spw=Math.min(580f,screenW-40f), sph=shopPanelH;
    float spx=(screenW-spw)/2f, spy=(screenH-sph)/2f;
    c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,settingsBgP);
    Paint border=new Paint(Paint.ANTI_ALIAS_FLAG); border.setColor(Color.argb(180,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
    c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,border);
    c.drawText("\uD83D\uDED2  SHOP",spx+20,spy+44,settingsTitleP);
    Paint cpP=fill(Color.rgb(255,210,50)); cpP.setTextSize(22f); cpP.setTextAlign(Paint.Align.RIGHT); cpP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    c.drawText("\uD83D\uDCB0 "+(lp!=null?lp.coins:0),spx+spw-20,spy+44,cpP);
    if(shopCloseRect!=null){c.drawRoundRect(shopCloseRect,8,8,closeBtnP); Paint cT=new Paint(optTxtP); cT.setTextSize(20f); c.drawText("\u2715",shopCloseRect.centerX(),shopCloseRect.centerY()+7,cT);}
    if(shopTabGuns!=null&&shopTabSkills!=null){
        Paint tabA=fill(Color.argb(220,60,100,200)), tabI=fill(Color.argb(100,40,40,70));
        Paint tabTxt=fill(Color.WHITE); tabTxt.setTextSize(17f); tabTxt.setTextAlign(Paint.Align.CENTER); tabTxt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        c.drawRoundRect(shopTabGuns,10,10,shopTab==0?tabA:tabI); c.drawRoundRect(shopTabSkills,10,10,shopTab==1?tabA:tabI);
        c.drawText("\uD83D\uDD2B Weapons",shopTabGuns.centerX(),shopTabGuns.centerY()+7,tabTxt);
        c.drawText("\u26A1 Skills",shopTabSkills.centerX(),shopTabSkills.centerY()+7,tabTxt);
    }
    if(shopTab==0) drawShopGuns(c,lp,spx,spy,spw); else drawShopSkills(c,lp,spx,spy,spw);
}

private void drawShopGuns(Canvas c, Player lp, float spx, float spy, float spw) {
    if(shopGunsCache==null) shopGunsCache=Gun.createAll();
    Gun[] allGuns=shopGunsCache;
    float rowH=SHOP_ROW_H, rowGap=SHOP_ROW_GAP, firstRowY=spy+110f, sph=shopPanelH;
    int numRows=(int)Math.ceil(allGuns.length/2.0);
    float contentH=numRows*(rowH+rowGap), visibleH=sph-110f;
    shopTabScrollMax[0]=Math.max(0f,contentH-visibleH);
    float scrollY=shopTabScrollY[0], colW=(spw-24f)/2f, colPad=8f;
    c.save(); c.clipRect(spx,spy+100f,spx+spw,spy+sph-4f);
    for(int i=0;i<allGuns.length;i++){
        int row=i/2, col=i%2; float ry=firstRowY+row*(rowH+rowGap)-scrollY;
        if(ry+rowH<spy+100f||ry>spy+sph) continue;
        float cardX=spx+8f+col*(colW+colPad), cardW=colW;
        Gun g=allGuns[i]; boolean owned=(lp==null)||lp.unlockedGuns[i];
        c.drawRoundRect(new RectF(cardX,ry,cardX+cardW,ry+rowH),7,7,fill(owned?Color.argb(60,60,140,70):Color.argb(40,40,40,80)));
        c.drawCircle(cardX+14f,ry+rowH/2f,8f,fill(g.color));
        Paint gnP=fill(g.color); gnP.setTextSize(15f); gnP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); gnP.setTextAlign(Paint.Align.LEFT);
        c.save(); c.clipRect(cardX+26f,ry,cardX+cardW-(cardW*0.38f)-6f,ry+rowH); c.drawText(g.name,cardX+26f,ry+rowH*0.42f+5f,gnP); c.restore();
        if(shopBuyRects!=null&&shopBuyRects[i]!=null){RectF br=shopBuyRects[i]; RectF adjBr=new RectF(br.left,ry+(rowH-br.height())/2f,br.right,ry+(rowH+br.height())/2f); if(owned){c.drawRoundRect(adjBr,6,6,fill(Color.argb(170,40,160,70))); Paint otP=fill(Color.WHITE); otP.setTextSize(11f); otP.setTextAlign(Paint.Align.CENTER); otP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText("\u2713",adjBr.centerX(),adjBr.centerY()+5f,otP);}else{int price=GUN_PRICES[i]; boolean afford=(lp!=null&&lp.coins>=price); c.drawRoundRect(adjBr,6,6,fill(afford?Color.argb(220,170,120,0):Color.argb(100,70,70,80))); Paint btP=fill(afford?Color.WHITE:Color.argb(120,200,200,200)); btP.setTextSize(11f); btP.setTextAlign(Paint.Align.CENTER); btP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText("\uD83D\uDCB0"+price,adjBr.centerX(),adjBr.centerY()+5f,btP);}}
    }
    if(shopTabScrollMax[0]>0f){float trackX=spx+spw-6f,trackTop=spy+104f,trackBot=spy+sph-8f,trackH=trackBot-trackTop; float thumbH=Math.max(30f,trackH*(visibleH/contentH)),thumbTop=trackTop+(trackH-thumbH)*(scrollY/shopTabScrollMax[0]); c.drawRoundRect(trackX-3f,thumbTop,trackX+3f,thumbTop+thumbH,3f,3f,fill(Color.argb(120,200,200,255)));}
    c.restore();
}

private void drawShopSkills(Canvas c, Player lp, float spx, float spy, float spw) {
    float sph=shopPanelH, rowH=54f, rowGap=4f;
    float contentBottom=412f+4*(rowH+rowGap), contentH=contentBottom-110f, visibleH=sph-110f;
    shopTabScrollMax[1]=Math.max(0f,contentH-visibleH); float scrollY=shopTabScrollY[1];
    c.save(); c.clipRect(spx,spy+100f,spx+spw,spy+sph-4f); c.translate(0f,-scrollY);
    Paint secP=fill(Color.argb(220,180,180,255)); secP.setTextSize(17f); secP.setTextAlign(Paint.Align.LEFT); secP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    c.drawText("\u25CF PASSIVE SKILLS",spx+18,spy+126,secP);
    String[] passNames={"\u26A1 Fast Reload","\uD83D\uDD25 Fire Rate","\uD83C\uDFAF Bullet Range","\uD83D\uDC9F Move Speed"};
    String[] passDesc={"\u221220% reload per level","+20% fire rate per level","+25% range per level","+12% speed per level"};
    int[] passLevels=(lp==null)?new int[4]:new int[]{lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
    float firstY=spy+132f;
    for(int i=0;i<4;i++){float ry=firstY+i*(rowH+rowGap); int lv=passLevels[i]; c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,fill(Color.argb(80,30,30,70))); Paint nP=fill(Color.WHITE); nP.setTextSize(16f); nP.setTextAlign(Paint.Align.LEFT); nP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText(passNames[i],spx+18,ry+22,nP); Paint dP=fill(Color.argb(150,190,190,190)); dP.setTextSize(12f); dP.setTextAlign(Paint.Align.LEFT); c.drawText(passDesc[i],spx+18,ry+40,dP); for(int d=0;d<3;d++){c.drawCircle(spx+spw-140+d*24,ry+rowH/2f,9,fill(d<lv?Color.rgb(80,200,255):Color.argb(80,80,80,80)));} if(passiveBuyRects!=null&&passiveBuyRects[i]!=null){if(lv>=3){c.drawRoundRect(passiveBuyRects[i],8,8,fill(Color.argb(100,40,120,40))); Paint ot=fill(Color.argb(200,150,255,150)); ot.setTextSize(13f); ot.setTextAlign(Paint.Align.CENTER); c.drawText("MAX",passiveBuyRects[i].centerX(),passiveBuyRects[i].centerY()+5,ot);}else{int cost=PASSIVE_SKILL_COSTS[lv]; boolean canBuy=lp!=null&&lp.coins>=cost; c.drawRoundRect(passiveBuyRects[i],8,8,fill(canBuy?Color.argb(210,60,100,200):Color.argb(80,60,60,60))); Paint bt=fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(13f); bt.setTextAlign(Paint.Align.CENTER); c.drawText("\uD83D\uDCB0"+cost,passiveBuyRects[i].centerX(),passiveBuyRects[i].centerY()+5,bt);}}}
    Paint secP2=fill(Color.argb(220,255,210,80)); secP2.setTextSize(17f); secP2.setTextAlign(Paint.Align.LEFT); secP2.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText("\u25CF ACTIVE SKILL  (equip one)",spx+18,spy+388,secP2);
    Paint noteP=fill(Color.argb(130,180,180,180)); noteP.setTextSize(12f); noteP.setTextAlign(Paint.Align.LEFT); c.drawText("Tap [SKILL] button in-game to activate",spx+18,spy+407,noteP);
    String[] actNames={"\uD83D\uDCA8 Dash","\uD83D\uDC41 Stealth","\uD83D\uDC8A Heal","\uD83D\uDEE1 Shield"};
    String[] actDesc={"Teleport 260px  \u2022  6s cooldown","Invisible 4s  \u2022  10s cooldown","+40 HP  \u2022  12s cooldown","60-HP barrier 6s  \u2022  14s cooldown"};
    int[] actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
    float activeFirstY=spy+412f;
    for(int i=0;i<4;i++){float ry=activeFirstY+i*(rowH+rowGap); boolean owned=(lp!=null&&lp.activeSkillType==actTypes[i]); c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,fill(owned?Color.argb(100,50,80,30):Color.argb(80,30,30,60))); Paint nP=fill(Color.WHITE); nP.setTextSize(16f); nP.setTextAlign(Paint.Align.LEFT); nP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText(actNames[i],spx+18,ry+22,nP); Paint dP=fill(Color.argb(150,190,190,190)); dP.setTextSize(12f); dP.setTextAlign(Paint.Align.LEFT); c.drawText(actDesc[i],spx+18,ry+40,dP); if(activeBuyRects!=null&&activeBuyRects[i]!=null){if(owned){c.drawRoundRect(activeBuyRects[i],8,8,fill(Color.argb(100,40,120,40))); Paint ot=fill(Color.argb(200,150,255,150)); ot.setTextSize(12f); ot.setTextAlign(Paint.Align.CENTER); c.drawText("EQUIPPED",activeBuyRects[i].centerX(),activeBuyRects[i].centerY()+5,ot);}else{int cost=ACTIVE_SKILL_COSTS[i]; boolean canBuy=lp!=null&&lp.coins>=cost; c.drawRoundRect(activeBuyRects[i],8,8,fill(canBuy?Color.argb(210,100,60,200):Color.argb(80,60,60,60))); Paint bt=fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(12f); bt.setTextAlign(Paint.Align.CENTER); c.drawText("\uD83D\uDCB0"+cost,activeBuyRects[i].centerX(),activeBuyRects[i].centerY()+5,bt);}}}
    c.restore();
    if(shopTabScrollMax[1]>0f){float trackX=spx+spw-6f,trackTop=spy+104f,trackBot=spy+sph-8f,trackH=trackBot-trackTop; float thumbH=Math.max(30f,trackH*(visibleH/contentH)),thumbTop=trackTop+(trackH-thumbH)*(scrollY/shopTabScrollMax[1]); c.drawRoundRect(trackX-3f,thumbTop,trackX+3f,thumbTop+thumbH,3f,3f,fill(Color.argb(120,200,200,255)));}
}

private void drawTrainingHUD(Canvas c) {
    if(trainAddDummyBtn==null) return;
    Paint labelP=fill(Color.argb(200,180,230,255)); labelP.setTextSize(14f); labelP.setTextAlign(Paint.Align.RIGHT); labelP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    c.drawText("TRAINING RANGE",trainAddDummyBtn.right,trainAddDummyBtn.top-6f,labelP);
    String dCnt=state.dummyIds.size()+"/"+MAX_DUMMIES+" dummies";
    Paint cntP=fill(Color.argb(180,200,200,200)); cntP.setTextSize(12f); cntP.setTextAlign(Paint.Align.RIGHT);
    c.drawText(dCnt,trainAddDummyBtn.right,trainRemDummyBtn.bottom+16f,cntP);
    RectF[] rects={trainAddDummyBtn,trainRemDummyBtn,trainAddMoneyBtn};
    String[] labels={"+ Dummy","- Dummy","+200 Coins"};
    int[] colors={0xFF2a6faa,0xFF7a3030,0xFF2a8a50};
    Paint btnPt=new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint txtP=fill(Color.WHITE); txtP.setTextSize(15f); txtP.setTextAlign(Paint.Align.CENTER); txtP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
    for(int i=0;i<rects.length;i++){if(rects[i]==null) continue; boolean canAdd=(i==0&&state.dummyIds.size()>=MAX_DUMMIES); int col=canAdd?Color.argb(120,60,80,60):colors[i]; btnPt.setColor(Color.argb(210,Color.red(col),Color.green(col),Color.blue(col))); btnPt.setStyle(Paint.Style.FILL); c.drawRoundRect(rects[i],10,10,btnPt); btnPt.setColor(Color.argb(120,255,255,255)); btnPt.setStyle(Paint.Style.STROKE); btnPt.setStrokeWidth(1.5f); c.drawRoundRect(rects[i],10,10,btnPt); c.drawText(labels[i],rects[i].centerX(),rects[i].centerY()+6f,txtP);}
}

}
