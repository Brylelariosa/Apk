package com.game.topdown;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private LinearLayout menuPanel, multiPanel;
    private EditText     nameInput;
    private Button       singlePlayerBtn, multiplayerBtn, trainingBtn;
    private Button       diffEasyBtn, diffNormalBtn, diffHardBtn;

    private LinearLayout multiNamePanel;
    private TextView     multiNameLabel, statusText;
    private EditText     ipInput;
    private Button       hostBtn, backBtn, scanBtn, joinIpBtn;
    private ListView     hostList;

    private final List<String[]>  hosts   = new ArrayList<>();
    private ArrayAdapter<String>  adapter;
    private final Handler         handler = new Handler(Looper.getMainLooper());
    private NetworkManager        scanner;
    private String                savedName = "";

    // 0=Easy, 1=Normal, 2=Hard  (default Normal)
    private int selectedDifficulty = 1;

    // Colours for selected / unselected difficulty buttons
    private static final int COL_EASY_SEL   = 0xFF2ecc71;
    private static final int COL_EASY_UNS   = 0xFF1a4a2e;
    private static final int COL_NORMAL_SEL = 0xFFe94560;
    private static final int COL_NORMAL_UNS = 0xFF5a1020;
    private static final int COL_HARD_SEL   = 0xFF6644cc;
    private static final int COL_HARD_UNS   = 0xFF1a2744;

    @Override
    protected void attachBaseContext(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = 1.0f;
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                           | WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);
        hideSystemUI();

        menuPanel       = findViewById(R.id.menuPanel);
        multiPanel      = findViewById(R.id.multiPanel);
        nameInput       = findViewById(R.id.nameInput);
        singlePlayerBtn = findViewById(R.id.singlePlayerBtn);
        multiplayerBtn  = findViewById(R.id.multiplayerBtn);
        trainingBtn     = findViewById(R.id.trainingBtn);

        // Difficulty buttons
        diffEasyBtn   = findViewById(R.id.diffEasyBtn);
        diffNormalBtn = findViewById(R.id.diffNormalBtn);
        diffHardBtn   = findViewById(R.id.diffHardBtn);

        diffEasyBtn.setOnClickListener(v   -> setDifficulty(0));
        diffNormalBtn.setOnClickListener(v -> setDifficulty(1));
        diffHardBtn.setOnClickListener(v   -> setDifficulty(2));

        // Show Normal selected by default
        refreshDifficultyUI();

        singlePlayerBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            launchSinglePlayer(n);
        });

        multiplayerBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            savedName = n;
            showMultiplayer();
        });

        trainingBtn.setOnClickListener(v -> {
            String n = name(); if (n == null) return;
            launchTraining(n);
        });

        multiNameLabel  = findViewById(R.id.multiNameLabel);
        hostBtn         = findViewById(R.id.hostBtn);
        backBtn         = findViewById(R.id.backBtn);
        scanBtn         = findViewById(R.id.scanBtn);
        joinIpBtn       = findViewById(R.id.joinIpBtn);
        ipInput         = findViewById(R.id.ipInput);
        hostList        = findViewById(R.id.hostList);
        statusText      = findViewById(R.id.statusText);

        adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, new ArrayList<>());
        hostList.setAdapter(adapter);

        backBtn.setOnClickListener(v -> showMenu());
        hostBtn.setOnClickListener(v -> launch(savedName, true, null));

        joinIpBtn.setOnClickListener(v -> {
            String ip = ipInput.getText().toString().trim();
            if (ip.isEmpty()) { status("Enter or select a host IP"); return; }
            launch(savedName, false, ip);
        });

        scanBtn.setOnClickListener(v -> scan());

        hostList.setOnItemClickListener((p, v, pos, id) -> {
            String ip = hosts.get(pos)[0];
            ipInput.setText(ip);
            joinIpBtn.setBackgroundTintList(
                ColorStateList.valueOf(Color.parseColor("#2ecc71")));
            status("Tap JOIN to connect to " + hosts.get(pos)[1] + " (" + ip + ")");
        });
    }

    private void setDifficulty(int d) {
        selectedDifficulty = d;
        refreshDifficultyUI();
    }

    private void refreshDifficultyUI() {
        diffEasyBtn  .setBackgroundTintList(ColorStateList.valueOf(
                selectedDifficulty == 0 ? COL_EASY_SEL   : COL_EASY_UNS));
        diffNormalBtn.setBackgroundTintList(ColorStateList.valueOf(
                selectedDifficulty == 1 ? COL_NORMAL_SEL : COL_NORMAL_UNS));
        diffHardBtn  .setBackgroundTintList(ColorStateList.valueOf(
                selectedDifficulty == 2 ? COL_HARD_SEL   : COL_HARD_UNS));

        // Update single-player button label to show chosen difficulty
        String[] labels = {"⚔  EASY", "⚔  SINGLE PLAYER", "⚔  HARD MODE"};
        singlePlayerBtn.setText(labels[selectedDifficulty]);
    }

    private void showMenu() {
        menuPanel.setVisibility(View.VISIBLE);
        multiPanel.setVisibility(View.GONE);
    }

    private void showMultiplayer() {
        multiNameLabel.setText("Playing as: " + savedName);
        menuPanel.setVisibility(View.GONE);
        multiPanel.setVisibility(View.VISIBLE);
        status("");
    }

    private void scan() {
        hosts.clear(); adapter.clear();
        scanBtn.setEnabled(false);
        status("Scanning your Wi-Fi…");

        if (scanner != null) scanner.stop();
        scanner = new NetworkManager(new NetworkManager.Callback() {
            @Override public void onHostDiscovered(String ip, String hn) {
                handler.post(() -> {
                    for (String[] h : hosts) if (h[0].equals(ip)) return;
                    hosts.add(new String[]{ip, hn});
                    adapter.add("▶  " + hn + "  —  " + ip);
                    status("Found " + hosts.size() + " game(s). Tap one, then JOIN.");
                });
            }
            @Override public void onJoined(int i){}
            @Override public void onPlayerJoined(int i, String n){}
            @Override public void onStateUpdate(String j){}
            @Override public void onInputReceived(int i, String j){}
            @Override public void onDisconnected(){}
        });
        scanner.discoverHosts(3000);

        handler.postDelayed(() -> {
            scanBtn.setEnabled(true);
            if (hosts.isEmpty())
                status("No games found. Ask host for IP and type it above.");
        }, 3500);
    }

    private String name() {
        String s = nameInput.getText().toString().trim();
        if (s.isEmpty()) { Toast.makeText(this, "Enter your name first!", Toast.LENGTH_SHORT).show(); return null; }
        return s;
    }

    private void status(String msg) { statusText.setText(msg); }

    private void launchSinglePlayer(String name) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name);
        i.putExtra("singlePlayer", true);
        i.putExtra("difficulty", selectedDifficulty);
        startActivity(i);
    }

    private void launchTraining(String name) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name);
        i.putExtra("trainingMode", true);
        startActivity(i);
    }

    private void launch(String name, boolean host, String ip) {
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name);
        i.putExtra("isHost", host);
        i.putExtra("singlePlayer", false);
        if (ip != null) i.putExtra("hostIp", ip);
        startActivity(i);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (scanner != null) scanner.stop();
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController ctrl = getWindow().getInsetsController();
            if (ctrl != null) {
                ctrl.hide(android.view.WindowInsets.Type.statusBars()
                        | android.view.WindowInsets.Type.navigationBars());
                ctrl.setSystemBarsBehavior(
                        android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            //noinspection deprecation
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }
}
