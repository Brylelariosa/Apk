package com.game.topdown;

import java.util.HashSet;
import java.util.Set;

/**
 * A single Volt Chakram disc.
 * Three discs are owned by one player and cycle through three states:
 *   ORBITING  – circling the player while the aim stick is held / idle
 *   LAUNCHED  – flying forward after the stick is released
 *   RETURNING – homing back to the player after reaching max range or hitting a wall
 */
public class VoltChakram {

    public static final int ORBITING  = 0;
    public static final int LAUNCHED  = 1;
    public static final int RETURNING = 2;

    // ── Identity ──────────────────────────────────────────────────────────────
    public final int ownerId;
    public final int orbitIdx;          // 0, 1, 2 → 120° orbit offsets

    // ── State ────────────────────────────────────────────────────────────────
    public int   state       = ORBITING;
    public float x, y;                  // world position
    public float vx, vy;                // velocity (LAUNCHED / RETURNING)
    public float damage      = 18f;     // set at launch
    public float distTraveled = 0f;     // accumulated travel distance

    // ── Visual ────────────────────────────────────────────────────────────────
    public float spinAngle   = 0f;      // self-rotation of the disc graphic
    public float trailTimer  = 0f;      // used to strobe the trail

    // ── Hit tracking ─────────────────────────────────────────────────────────
    /** Player IDs already damaged this pass; cleared when direction reverses. */
    public Set<Integer> hitIds = new HashSet<>();

    // ── Constants ─────────────────────────────────────────────────────────────
    public static final float ORBIT_RADIUS = 52f;
    public static final float HIT_RADIUS   = 16f;
    public static final float LAUNCH_RANGE = 660f;
    public static final float RETURN_SPEED = 740f;

    public VoltChakram(int ownerId, int orbitIdx) {
        this.ownerId  = ownerId;
        this.orbitIdx = orbitIdx;
    }
}
