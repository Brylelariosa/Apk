package com.game.topdown;

/**
 * ════════════════════════════════════════════════════════════════════════════
 *  STATUS EFFECT CONFIG — edit this file to balance all status effects
 * ════════════════════════════════════════════════════════════════════════════
 */
public final class StatusEffectConfig {

    // ── Slow (blue paint bullet) ──────────────────────────────────────────────
    /** How long the slow lasts in milliseconds. */
    public static final long SLOW_DURATION_MS    = 3000L;

    /** Speed multiplier while slowed. 0.5 = half speed, 0.3 = very slow. */
    public static final float SLOW_SPEED_MULT    = 0.4f;


    // ── Poison (green paint bullet) ───────────────────────────────────────────
    /** How long poison lasts in milliseconds. */
    public static final long  POISON_DURATION_MS = 6000L;

    /** HP removed per poison tick. */
    public static final float POISON_TICK_DAMAGE = 8f;

    /** Milliseconds between each poison tick. */
    public static final long  POISON_TICK_MS     = 600L;


    // ── Hook Spear ────────────────────────────────────────────────────────────
    /** Extra stun time added on top of the pull duration (milliseconds). */
    public static final long  HOOK_STUN_BONUS_MS = 600L;

    /** Speed the target is pulled toward the caster (world-px / second). */
    public static final float HOOK_PULL_SPEED    = 520f;


    private StatusEffectConfig() {} // static-only utility class
}
