package com.game.topdown;

import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class NetworkManager {
    public static final int DISC_PORT = 5555;
    public static final int GAME_PORT = 5556;

    public interface Callback {
        void onHostDiscovered(String ip, String name);
        void onJoined(int myId);
        void onPlayerJoined(int id, String name);
        void onStateUpdate(String json);
        void onInputReceived(int pid, String json);
        /** Called on network thread when no packet received for timeoutMs. */
        void onDisconnected();
    }

    // ── Timeout / reconnect tracking ──────────────────────────────────────────
    private static final long TIMEOUT_MS = 6000L; // 6 s silence = disconnected
    private volatile long lastReceivedMs  = System.currentTimeMillis();
    private volatile boolean disconnected = false;
    private String  joinName; // saved so we can retry

    private final Callback cb;
    private volatile boolean running;
    private final ExecutorService exec = Executors.newCachedThreadPool();

    private DatagramSocket discSock;
    private DatagramSocket gameSock;

    private boolean isHost;
    private final Map<Integer, InetSocketAddress> clients = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    private InetAddress hostAddr;
    public  int myId = -1;

    public NetworkManager(Callback cb) { this.cb = cb; }
    public boolean isHost() { return isHost; }
    public boolean isDisconnected() { return disconnected; }

    // ── Host ──────────────────────────────────────────────────────────────────
    public void startHost(String name) throws SocketException {
        isHost = true; myId = 0; running = true;

        discSock = new DatagramSocket(DISC_PORT);
        discSock.setSoTimeout(200); discSock.setBroadcast(true);

        gameSock = new DatagramSocket(GAME_PORT);
        gameSock.setSoTimeout(200);

        exec.submit(() -> discoveryLoop(name));
        exec.submit(this::gameLoop);
    }

    private void discoveryLoop(String hostName) {
        byte[] buf = new byte[256];
        while (running) {
            try {
                DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                discSock.receive(pkt);
                String msg = new String(pkt.getData(), 0, pkt.getLength()).trim();
                if ("DISCOVER".equals(msg)) {
                    byte[] resp = ("HOST:" + hostName).getBytes();
                    discSock.send(new DatagramPacket(resp, resp.length,
                        pkt.getAddress(), pkt.getPort()));
                }
            } catch (SocketTimeoutException ignored) {
            } catch (Exception e) { if (running) e.printStackTrace(); }
        }
    }

    // ── Client ────────────────────────────────────────────────────────────────
    public void joinGame(String ip, String name) throws Exception {
        isHost = false; running = true; joinName = name;
        hostAddr = InetAddress.getByName(ip);
        gameSock = new DatagramSocket();
        gameSock.setSoTimeout(200);
        exec.submit(this::gameLoop);
        // Retry JOIN every second until host sends JOINED back (UDP can drop packets)
        exec.submit(() -> {
            while (running && myId == -1) {
                rawSend("JOIN:" + name, hostAddr, GAME_PORT);
                try { Thread.sleep(1000); } catch (InterruptedException ignored) { break; }
            }
        });
    }

    public void discoverHosts(int timeoutMs) {
        exec.submit(() -> {
            try (DatagramSocket sock = new DatagramSocket()) {
                sock.setBroadcast(true);
                sock.setSoTimeout(500);
                byte[] msg = "DISCOVER".getBytes();
                // broadcast
                sock.send(new DatagramPacket(msg, msg.length,
                    InetAddress.getByName("255.255.255.255"), DISC_PORT));
                byte[] buf = new byte[256];
                long end = System.currentTimeMillis() + timeoutMs;
                while (System.currentTimeMillis() < end) {
                    try {
                        DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                        sock.receive(pkt);
                        String r = new String(pkt.getData(), 0, pkt.getLength()).trim();
                        if (r.startsWith("HOST:"))
                            cb.onHostDiscovered(pkt.getAddress().getHostAddress(), r.substring(5));
                    } catch (SocketTimeoutException ignored) {}
                }
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    // ── Receive loop ──────────────────────────────────────────────────────────
    private void gameLoop() {
        byte[] buf = new byte[16384];
        while (running) {
            try {
                DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                gameSock.receive(pkt);
                lastReceivedMs = System.currentTimeMillis(); // any packet resets timeout
                disconnected = false;
                String msg = new String(pkt.getData(), 0, pkt.getLength()).trim();
                InetSocketAddress from = new InetSocketAddress(pkt.getAddress(), pkt.getPort());
                dispatch(msg, from);
            } catch (SocketTimeoutException ignored) {
                // Check for disconnect timeout (clients only — hosts are authoritative)
                if (!isHost && myId >= 0 && !disconnected
                        && System.currentTimeMillis() - lastReceivedMs > TIMEOUT_MS) {
                    disconnected = true;
                    cb.onDisconnected();
                    // Auto-retry: resend JOIN so host can re-register us
                    if (joinName != null && hostAddr != null) {
                        rawSend("JOIN:" + joinName, hostAddr, GAME_PORT);
                    }
                }
            } catch (Exception e) { if (running) e.printStackTrace(); }
        }
    }

    private void dispatch(String msg, InetSocketAddress from) {
        if (isHost) {
            if (msg.startsWith("JOIN:")) {
                String name = msg.substring(5).trim();
                // Dedup: if this address already joined, just re-send JOINED
                for (Map.Entry<Integer, InetSocketAddress> e : clients.entrySet()) {
                    InetSocketAddress ca = e.getValue();
                    if (ca.getAddress().equals(from.getAddress()) && ca.getPort() == from.getPort()) {
                        rawSend("JOINED:" + e.getKey(), from.getAddress(), from.getPort());
                        return;
                    }
                }
                int id = nextId.getAndIncrement();
                clients.put(id, from);
                rawSend("JOINED:" + id, from.getAddress(), from.getPort());
                cb.onPlayerJoined(id, name);
            } else if (msg.startsWith("INPUT:")) {
                for (Map.Entry<Integer, InetSocketAddress> e : clients.entrySet()) {
                    InetSocketAddress ca = e.getValue();
                    if (ca.getAddress().equals(from.getAddress()) && ca.getPort() == from.getPort()) {
                        cb.onInputReceived(e.getKey(), msg.substring(6));
                        break;
                    }
                }
            }
        } else {
            if (msg.startsWith("JOINED:")) {
                myId = Integer.parseInt(msg.substring(7).trim());
                cb.onJoined(myId);
            } else if (msg.startsWith("STATE:")) {
                cb.onStateUpdate(msg.substring(6));
            }
        }
    }

    // ── Send helpers ──────────────────────────────────────────────────────────
    public void broadcastState(String json) {
        String pkt = "STATE:" + json;
        for (InetSocketAddress addr : clients.values())
            rawSend(pkt, addr.getAddress(), addr.getPort());
    }
    public void sendInput(String json) {
        if (!isHost && hostAddr != null) rawSend("INPUT:" + json, hostAddr, GAME_PORT);
    }
    private void rawSend(String msg, InetAddress addr, int port) {
        try {
            byte[] data = msg.getBytes();
            gameSock.send(new DatagramPacket(data, data.length, addr, port));
        } catch (Exception e) { if (running) e.printStackTrace(); }
    }

    public void stop() {
        running = false; exec.shutdownNow();
        try { if (discSock != null) discSock.close(); } catch (Exception ignored) {}
        try { if (gameSock != null) gameSock.close(); } catch (Exception ignored) {}
    }
}
