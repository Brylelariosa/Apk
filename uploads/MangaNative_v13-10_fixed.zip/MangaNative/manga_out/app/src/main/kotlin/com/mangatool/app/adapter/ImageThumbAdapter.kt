package com.mangatool.app.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.AppState
import com.mangatool.app.R
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import com.mangatool.app.util.BitmapUtils
import com.mangatool.app.util.ImageMerger
import kotlinx.coroutines.*

class ImageThumbAdapter(
    private var items: List<Any>,
    private val isMerge: Boolean,
    private val group: ImageGroup? = null,
    private val groupIdx: Int = 0,
    private val onItemClick: (Int) -> Unit,
    private val onItemLongClick: ((ImageItem) -> Unit)? = null,
    private val onSwapChanged: (() -> Unit)? = null
) : RecyclerView.Adapter<ImageThumbAdapter.VH>() {

    // Launch directly on decodeDispatcher — eliminates a Main dispatch hop per thumbnail.
    // Each job does decode work then posts setImageBitmap back to Main explicitly.
    private val scope = CoroutineScope(BitmapUtils.decodeDispatcher + SupervisorJob())

    companion object {
        /** Payload token for dims-only rebind — does NOT cancel thumbnail decode. */
        const val PAYLOAD_DIMS = "dims"

        /**
         * Stable cache key derived from the image's unique file path.
         *
         * Previously used "g{groupIdx}i{originalIdx}" — broken because both
         * MHTMLs start at originalIdx=0, so two different groups collide when
         * their adapter positions change (drag-to-reorder, second MHTML import).
         * filePath is a unique temp file name and never changes, so it's safe
         * to use as the cache key regardless of group position.
         */
        fun cacheKey(filePath: String)  = "t:$filePath"
        fun cacheKeyL(filePath: String) = "tL:$filePath"
        fun cacheKeyR(filePath: String) = "tR:$filePath"
    }

    init { setHasStableIds(true) }

    override fun getItemId(position: Int): Long = when (val item = items[position]) {
        is ImageItem -> item.originalIdx.toLong()
        is List<*>   -> (item.firstOrNull() as? ImageItem)?.originalIdx?.toLong()
                            ?: position.toLong()
        else         -> position.toLong()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val image:      ImageView = v.findViewById(R.id.thumb_image)
        val overlay:    View      = v.findViewById(R.id.thumb_overlay)
        val dims:       TextView? = v.findViewById(R.id.thumb_dims)
        val thumbLeft:  ImageView? = v.findViewById(R.id.thumb_left)
        val thumbRight: ImageView? = v.findViewById(R.id.thumb_right)
        val btnSwap:    Button?    = v.findViewById(R.id.btn_swap)
        var jobLeft:  Job? = null
        var jobRight: Job? = null
        var job:      Job? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (isMerge) R.layout.item_thumb_merge else R.layout.item_thumb
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        val holder = VH(v)

        // ── Attach click listeners ONCE here, not on every bind ──────────────
        // bindingAdapterPosition is always fresh at click time — no stale index.
        v.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_ID.toInt()) onItemClick(pos)
        }
        v.setOnLongClickListener {
            val pos = holder.bindingAdapterPosition
            if (!isMerge && pos != RecyclerView.NO_ID.toInt())
                onItemLongClick?.invoke(items[pos] as ImageItem)
            true
        }
        holder.btnSwap?.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (group != null && pos != RecyclerView.NO_ID.toInt()) {
                @Suppress("UNCHECKED_CAST")
                val curPair = items[pos] as List<ImageItem>
                if (group.pairSwaps.contains(pos)) group.pairSwaps.remove(pos)
                else group.pairSwaps.add(pos)
                AppState.thumbCache.remove("mg_${curPair.map { it.originalIdx }}_false")
                AppState.thumbCache.remove("mg_${curPair.map { it.originalIdx }}_true")
                notifyItemChanged(pos)
                onSwapChanged?.invoke()
            }
        }
        return holder
    }

    override fun getItemCount() = items.size

    /**
     * Payload-aware bind: PAYLOAD_DIMS only updates the dims badge without
     * touching the image or cancelling the in-flight decode job.
     */
    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_DIMS }) {
            val img = items.getOrNull(position) as? ImageItem ?: return
            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.job?.cancel()
        holder.jobLeft?.cancel()
        holder.jobRight?.cancel()
        holder.image.setImageBitmap(null)
        holder.overlay.visibility = View.GONE
        holder.dims?.visibility = View.GONE

        if (!isMerge) {
            // ── Extract mode ──────────────────────────────────────────────────
            val img = items[position] as ImageItem
            holder.overlay.visibility = if (img.userDeleted) View.VISIBLE else View.GONE

            if (img.width > 0 && img.height > 0) {
                holder.dims?.text = "${img.width}×${img.height}"
                holder.dims?.visibility = View.VISIBLE
            }

            val cacheKey = cacheKey(img.filePath)
            val cached: Bitmap? = AppState.thumbCache.get(cacheKey)
            if (cached != null) {
                holder.image.setImageBitmap(cached)
                return
            }
            // Use BitmapUtils.decodeDispatcher (3 threads max) instead of
            // Dispatchers.IO (64 threads). This prevents CPU thrashing and GC
            // spikes when many thumbnails load at once.
            holder.job = scope.launch {
                val bm = runCatching { BitmapUtils.decodeThumbnail(img.filePath, 200) }.getOrNull()
                if (bm != null && isActive) {
                    AppState.thumbCache.put(cacheKey, bm)
                    withContext(Dispatchers.Main) { holder.image.setImageBitmap(bm) }
                }
            }

        } else {
            // ── Merge mode ────────────────────────────────────────────────────
            @Suppress("UNCHECKED_CAST")
            val pair    = items[position] as List<ImageItem>
            val swapped = group?.pairSwaps?.contains(position) == true
            val leftImg  = if (swapped && pair.size > 1) pair[1] else pair[0]
            val rightImg = if (swapped && pair.size > 1) pair[0] else pair.getOrNull(1)

            holder.thumbLeft?.setImageBitmap(null)
            val keyLeft = cacheKeyL(leftImg.filePath)
            AppState.thumbCache.get(keyLeft)?.let {
                holder.thumbLeft?.setImageBitmap(it)
            } ?: run {
                holder.jobLeft = scope.launch {
                    val bm = runCatching { BitmapUtils.decodeThumbnail(leftImg.filePath, 200) }.getOrNull()
                    if (bm != null && isActive) {
                        AppState.thumbCache.put(keyLeft, bm)
                        withContext(Dispatchers.Main) { holder.thumbLeft?.setImageBitmap(bm) }
                    }
                }
            }

            holder.thumbRight?.setImageBitmap(null)
            if (rightImg != null) {
                val keyRight = cacheKeyR(rightImg.filePath)
                AppState.thumbCache.get(keyRight)?.let {
                    holder.thumbRight?.setImageBitmap(it)
                } ?: run {
                    holder.jobRight = scope.launch {
                        val bm = runCatching { BitmapUtils.decodeThumbnail(rightImg.filePath, 200) }.getOrNull()
                        if (bm != null && isActive) {
                            AppState.thumbCache.put(keyRight, bm)
                            withContext(Dispatchers.Main) { holder.thumbRight?.setImageBitmap(bm) }
                        }
                    }
                }
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        holder.jobLeft?.cancel()
        holder.jobRight?.cancel()
        super.onViewRecycled(holder)
    }

    /**
     * Swap the item list and rebind all visible cells.
     * Called by ChapterAdapter.update() after applyFilters() runs —
     * the outer RecyclerView's notifyDataSetChanged() doesn't reach us.
     */
    fun refreshItems(newItems: List<Any>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun destroy() = scope.cancel()
}
