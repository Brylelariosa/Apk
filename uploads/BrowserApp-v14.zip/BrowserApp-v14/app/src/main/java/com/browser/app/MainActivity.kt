package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.util.TypedValue
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import android.webkit.JavascriptInterface
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────
    private lateinit var webView: ScrollAwareWebView
    private lateinit var urlBar: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnSettings: ImageButton
    private lateinit var btnToggle: ImageButton
    private lateinit var pageProgress: ProgressBar
    private lateinit var debugOverlay: android.widget.TextView

    // ── Gesture detector for double-tap / tap-to-dismiss ──────────────
    private lateinit var gestureDetector: GestureDetector

    // ── State ──────────────────────────────────────────────────────────
    private var urlBarVisible = false
    private var toggleVisible = true
    private var isOnHomePage  = false
    private var isImeVisible        = false
    private var webInputFocused     = false  // true while a web text input is active
    private var debugOverlayVisible = false

    @Volatile private var currentHost: String? = null
    @Volatile private var adBlockEnabled  = true

    /**
     * Data saver level:
     *   0 = Off
     *   1 = High Quality   (~20% saved)
     *   2 = Medium Quality (~40% saved)
     *   3 = Low Quality    (~65% saved)
     *   4 = No Images      (~80% saved)
     */
    @Volatile private var dataSaverLevel = 0

    /**
     * FAB (globe button) hide behaviour:
     *   0 = Auto-hide on scroll  (default — hides when scrolling down)
     *   1 = Tap page to hide     (single tap anywhere on the page hides it)
     *   2 = Always visible       (never auto-hides)
     */
    @Volatile private var fabBehavior = 0

    // ── Keyboard helpers ───────────────────────────────────────────────

    /**
     * Posted by the touch listener on every ACTION_DOWN.
     * Clears webInputFocused if the IME never opened within 600 ms,
     * which lets onWindowFocusChanged correctly re-apply immersive mode
     * on subsequent window-focus events (e.g. returning from another app).
     *
     * Without this reset, a single tap on a non-input area permanently
     * locks webInputFocused=true (because the insets reset only fires when
     * the IME was visible-then-closed, which never happens for non-inputs).
     */
    private val resetWebInputFocusedRunnable = Runnable {
        if (!isImeVisible) {
            webInputFocused = false
            dbg("webInput: auto-reset (IME did not open)")
        }
    }

    companion object {
        private const val MOBILE_UA  =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

        private val DATA_SAVER_LABELS = arrayOf(
            "Off",
            "High Quality  — blocks 3rd-party fonts & video (~20% saved)",
            "Medium Quality — blocks 3rd-party images, fonts & video (~40% saved)",
            "Low Quality    — blocks all images, fonts & video (~65% saved)",
            "No Images      — zero images loaded (~80% saved)"
        )

        private val FAB_BEHAVIOR_LABELS = arrayOf(
            "Auto-hide on scroll",
            "Tap page to hide",
            "Always visible"
        )

        // ── Speed-dial home page HTML ──────────────────────────────────
        private val HOME_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{
  background:#0a0a0a;color:#fff;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  min-height:100vh;display:flex;flex-direction:column;
  align-items:center;padding:52px 18px 30px;
}
.clock{font-size:68px;font-weight:200;letter-spacing:-3px;line-height:1;
  background:linear-gradient(135deg,#fff 40%,#4FC3F7);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.date{font-size:13px;color:#666;margin-top:6px;margin-bottom:48px;letter-spacing:.5px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;width:100%;max-width:400px}
a{text-decoration:none;color:inherit}
.card{display:flex;flex-direction:column;align-items:center;gap:8px;
  padding:16px 8px 12px;border-radius:16px;background:#161616;
  border:1px solid #1e1e1e;transition:background .12s,transform .1s}
.card:active{background:#222;transform:scale(.95)}
.icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;
  justify-content:center;font-size:19px;font-weight:800;color:#fff;letter-spacing:-1px}
.label{font-size:10px;color:#777;text-align:center;letter-spacing:.3px}
</style>
</head>
<body>
<div class="clock" id="clk"></div>
<div class="date" id="dt"></div>
<div class="grid">
  <a href="https://www.google.com"><div class="card">
    <div class="icon" style="background:#4285F4">G</div>
    <span class="label">Google</span></div></a>
  <a href="https://www.youtube.com"><div class="card">
    <div class="icon" style="background:#FF0000">&#9654;</div>
    <span class="label">YouTube</span></div></a>
  <a href="https://www.facebook.com"><div class="card">
    <div class="icon" style="background:#1877F2">f</div>
    <span class="label">Facebook</span></div></a>
  <a href="https://www.reddit.com"><div class="card">
    <div class="icon" style="background:#FF4500">R</div>
    <span class="label">Reddit</span></div></a>
  <a href="https://x.com"><div class="card">
    <div class="icon" style="background:#111;border:1px solid #333">&#120143;</div>
    <span class="label">X</span></div></a>
  <a href="https://www.wikipedia.org"><div class="card">
    <div class="icon" style="background:#636466">W</div>
    <span class="label">Wikipedia</span></div></a>
  <a href="https://github.com"><div class="card">
    <div class="icon" style="background:#24292e">&#9711;</div>
    <span class="label">GitHub</span></div></a>
  <a href="https://gmail.com"><div class="card">
    <div class="icon" style="background:#EA4335">M</div>
    <span class="label">Gmail</span></div></a>
</div>
<script>
function tick(){
  var n=new Date(),
      h=n.getHours().toString().padStart(2,'0'),
      m=n.getMinutes().toString().padStart(2,'0'),
      days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
      months=['January','February','March','April','May','June','July',
              'August','September','October','November','December'];
  document.getElementById('clk').textContent=h+':'+m;
  document.getElementById('dt').textContent=
    days[n.getDay()]+', '+months[n.getMonth()]+' '+n.getDate();
}
tick();setInterval(tick,5000);
</script>
</body>
</html>
        """.trimIndent()
    }

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { view, insets ->
            val wasVisible = isImeVisible
            isImeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            dbg("insets ime=$isImeVisible was=$wasVisible")

            when {
                // ── IME just opened ──────────────────────────────────
                !wasVisible && isImeVisible -> {
                    // Cancel the "IME never opened" reset runnable — it did open.
                    webView.removeCallbacks(resetWebInputFocusedRunnable)
                    webInputFocused = true
                    dbg("insets: IME opened ✓")
                }
                // ── IME just closed ──────────────────────────────────
                wasVisible && !isImeVisible -> {
                    webInputFocused = false
                    dbg("insets: IME closed → restore immersive")
                    applyImmersiveMode()
                }
            }
            ViewCompat.onApplyWindowInsets(view, insets)
        }

        bindViews()
        applyImmersiveMode()
        configureWebView()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        dbg("winFocus hasFocus=$hasFocus isIme=$isImeVisible webInput=$webInputFocused")
        // Re-apply immersive only when focus returns AND we are confident the
        // keyboard is not needed.  We delay 350 ms so that:
        //   (a) The insets listener has time to update isImeVisible.
        //   (b) The JS bridge has time to set webInputFocused.
        // Both conditions must still be false at the delayed check.
        if (hasFocus && !isImeVisible && !webInputFocused) {
            window.decorView.postDelayed({
                if (!isImeVisible && !webInputFocused) {
                    applyImmersiveMode()
                }
            }, 350)
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Immersive mode
    // ══════════════════════════════════════════════════════════════════

    private fun applyImmersiveMode() {
        dbg("applyImmersive")
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ══════════════════════════════════════════════════════════════════
    // Keyboard helper
    // ══════════════════════════════════════════════════════════════════

    /**
     * Single authoritative method to request the soft keyboard for the WebView.
     *
     * Call sequence that works on the widest range of Android builds:
     *   1. requestFocusFromTouch() — registers the focus as touch-originated,
     *      which some IME implementations require before honouring showSoftInput.
     *   2. showSoftInput(SHOW_IMPLICIT) — standard polite request.
     *   3. If showSoftInput returns false, retry with SHOW_FORCED after 150 ms.
     *
     * Do NOT call WindowInsetsControllerCompat.show(ime()) as a first-pass attempt;
     * it bypasses the InputConnection handshake and can break typing on API 30+.
     */
    private fun showKeyboardForWebView() {
        webInputFocused = true
        // Cancel any pending "reset webInputFocused" runnable — we now know
        // the user is in a text field.
        webView.removeCallbacks(resetWebInputFocusedRunnable)

        if (!webView.hasFocus()) {
            // requestFocusFromTouch simulates a touch-sourced focus event.
            // This matters on devices that only honour showSoftInput when
            // focus was gained from a real gesture, not a programmatic call.
            webView.requestFocusFromTouch()
            dbg("showKB: requestFocusFromTouch → hasFocus=${webView.hasFocus()}")
        }

        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val shown = imm.showSoftInput(webView, InputMethodManager.SHOW_IMPLICIT)
        dbg("showKB: SHOW_IMPLICIT → $shown")

        if (!shown) {
            // First attempt failed (InputConnection not ready yet or IMM busy).
            // Retry after 150 ms with SHOW_FORCED to override any suppression.
            webView.postDelayed({
                val shown2 = imm.showSoftInput(webView, InputMethodManager.SHOW_FORCED)
                dbg("showKB: SHOW_FORCED retry → $shown2")
                if (!shown2) {
                    // Last resort: WindowInsetsController path (API 30+).
                    // Only used when both IMM paths fail.
                    WindowInsetsControllerCompat(window, webView)
                        .show(WindowInsetsCompat.Type.ime())
                    dbg("showKB: WindowInsetsController fallback triggered")
                }
            }, 150)
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // View binding
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun bindViews() {
        webView      = findViewById(R.id.webView)
        urlBar       = findViewById(R.id.urlBar)
        urlInput     = findViewById(R.id.urlInput)
        btnBack      = findViewById(R.id.btnBack)
        btnForward   = findViewById(R.id.btnForward)
        btnRefresh   = findViewById(R.id.btnRefresh)
        btnSettings  = findViewById(R.id.btnSettings)
        btnToggle    = findViewById(R.id.btnToggleUrlBar)
        pageProgress = findViewById(R.id.pageProgress)

        // Debug overlay — small translucent box at bottom showing live events
        debugOverlay = android.widget.TextView(this).apply {
            textSize  = 9f
            setTextColor(0xFFFFFF00.toInt())  // yellow
            setBackgroundColor(0xCC000000.toInt())
            setPadding(8, 8, 8, 8)
            elevation = 50f
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.BOTTOM
            )
        }
        (findViewById<android.widget.FrameLayout>(android.R.id.content)).addView(debugOverlay)
        debugOverlay.visibility = View.GONE
        debugOverlay.setOnLongClickListener {
            val clip = android.content.ClipData.newPlainText("debug_log", debugOverlay.text)
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
            android.widget.Toast.makeText(this, "Debug log copied", android.widget.Toast.LENGTH_SHORT).show()
            true
        }

        urlBar.post { urlBar.translationY = -urlBar.height.toFloat() }

        btnToggle.setOnClickListener   { toggleUrlBar() }
        btnBack.setOnClickListener     { if (webView.canGoBack())    webView.goBack()    }
        btnForward.setOnClickListener  { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener  {
            if (isOnHomePage) loadHomePage() else webView.reload()
        }
        btnSettings.setOnClickListener { showSettingsDialog() }

        // ── URL input: IME actions + hardware Enter ───────────────────
        urlInput.setOnEditorActionListener { _, actionId, event ->
            val isAction = actionId == EditorInfo.IME_ACTION_GO
                        || actionId == EditorInfo.IME_ACTION_SEARCH
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || actionId == EditorInfo.IME_ACTION_UNSPECIFIED
            val isEnter  = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                           event.action   == KeyEvent.ACTION_DOWN
            if (isAction || isEnter) { navigateTo(urlInput.text.toString()); true } else false
        }
        urlInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN) {
                navigateTo(urlInput.text.toString()); true
            } else false
        }

        // ── Scroll callback — behaviour depends on fabBehavior setting ─
        webView.onScrollCallback = { dy ->
            if (!urlBarVisible && fabBehavior == 0) {
                if (dy > 8) {
                    hideToggleFab()
                } else if (dy < -8) {
                    showToggleFab(animate = true)
                }
            }
        }

        // ── WebView gesture detector ──────────────────────────────────
        //
        //   Double-tap anywhere  → dismiss URL bar (any mode)
        //   Single tap top 22 %  → show URL bar (any mode)
        //   Single tap anywhere  → hide globe if fabBehavior == 1 (Tap page)
        //
        gestureDetector = GestureDetector(this,
            object : GestureDetector.SimpleOnGestureListener() {

                override fun onDoubleTap(e: MotionEvent): Boolean {
                    if (urlBarVisible) {
                        hideUrlBar()
                        return true
                    }
                    return false
                }

                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    if (fabBehavior == 1 && toggleVisible && !urlBarVisible) {
                        hideToggleFab()
                        return true
                    }
                    return false
                }
            }
        )

        webView.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // Pre-emptively mark webInputFocused=true so that any
                    // onWindowFocusChanged arriving in the next few frames
                    // does NOT fire applyImmersiveMode before the JS bridge
                    // or onCreateInputConnection confirms the field is editable.
                    // If neither confirms within 600 ms, the runnable clears the
                    // flag so immersive mode can be re-applied normally later.
                    webInputFocused = true
                    webView.removeCallbacks(resetWebInputFocusedRunnable)
                    webView.postDelayed(resetWebInputFocusedRunnable, 600)
                }
            }
            gestureDetector.onTouchEvent(event)
            false   // never consume — WebView handles all events normally
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings dialog
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun showSettingsDialog() {
        val dp = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
        }

        fun divider() = View(this).apply {
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
            )
        }

        fun addToggleRow(
            label: String, desc: String, checked: Boolean,
            onToggle: (Boolean) -> Unit
        ) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt())
            }
            val textBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            }
            textBox.addView(TextView(this).apply {
                text = label; textSize = 15f; setTextColor(Color.WHITE)
            })
            textBox.addView(TextView(this).apply {
                text = desc; textSize = 12f
                setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding(0, (2*dp).toInt(), 0, 0)
            })
            val sw = Switch(this).apply {
                isChecked = checked
                setOnCheckedChangeListener { _, on -> onToggle(on) }
            }
            row.addView(textBox); row.addView(sw)
            container.addView(row)
            container.addView(divider())
        }

        fun addChevronRow(
            label: String,
            valueName: () -> String,
            onClick: (TextView) -> Unit
        ) {
            val rippleAttr = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, rippleAttr, true)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt())
                isClickable = true; isFocusable = true
                if (rippleAttr.resourceId != 0) setBackgroundResource(rippleAttr.resourceId)
            }
            val textBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
                isClickable = false
            }
            textBox.addView(TextView(this).apply {
                text = label; textSize = 15f; setTextColor(Color.WHITE)
            })
            val valueLabel = TextView(this).apply {
                text = valueName(); textSize = 12f
                setTextColor(Color.parseColor("#4FC3F7"))
                setPadding(0, (2*dp).toInt(), 0, 0)
            }
            textBox.addView(valueLabel)
            row.addView(textBox)
            row.addView(TextView(this).apply {
                text = "›"; textSize = 22f
                setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding((8*dp).toInt(), 0, 0, 0)
            })
            row.setOnClickListener { onClick(valueLabel) }
            container.addView(row)
            container.addView(divider())
        }

        addToggleRow("Ad Blocker", "Block ads and trackers", adBlockEnabled) { on ->
            adBlockEnabled = on; if (!isOnHomePage) webView.reload()
        }

        val dataSaverShort = arrayOf("Off", "High", "Medium", "Low", "No Images")
        addChevronRow("Data Saver", { dataSaverShort[dataSaverLevel] }) { valueLabel ->
            val checkedItem = intArrayOf(dataSaverLevel)
            AlertDialog.Builder(this)
                .setTitle("Data Saver")
                .setSingleChoiceItems(DATA_SAVER_LABELS, dataSaverLevel) { _, which ->
                    checkedItem[0] = which
                }
                .setPositiveButton("Apply") { _, _ ->
                    dataSaverLevel = checkedItem[0]
                    valueLabel.text = dataSaverShort[dataSaverLevel]
                    applyDataSaverSettings()
                    if (!isOnHomePage) webView.reload()
                }
                .setNegativeButton("Cancel", null)
                .show().styleDialog()
        }

        addChevronRow(
            "URL Button",
            { FAB_BEHAVIOR_LABELS[fabBehavior] }
        ) { valueLabel ->
            val checkedItem = intArrayOf(fabBehavior)
            AlertDialog.Builder(this)
                .setTitle("URL Button Visibility")
                .setSingleChoiceItems(FAB_BEHAVIOR_LABELS, fabBehavior) { _, which ->
                    checkedItem[0] = which
                }
                .setPositiveButton("Apply") { _, _ ->
                    fabBehavior = checkedItem[0]
                    valueLabel.text = FAB_BEHAVIOR_LABELS[fabBehavior]
                    if (fabBehavior == 2) showToggleFab(animate = true)
                }
                .setNegativeButton("Cancel", null)
                .show().styleDialog()
        }

        addToggleRow("Debug Overlay", "Show live event log (long-press to copy)", debugOverlayVisible) { on ->
            debugOverlayVisible = on
            debugOverlay.visibility = if (on) View.VISIBLE else View.GONE
        }

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(container)
            .setPositiveButton("Done", null)
            .show().styleDialog()
    }

    // ── Debug overlay ──────────────────────────────────────────────────

    private val debugLog = ArrayDeque<String>()

    private fun dbg(msg: String) {
        val ts = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)
            .format(java.util.Date())
        val line = "$ts  $msg"
        android.util.Log.d("BrowserKeyboard", line)
        runOnUiThread {
            debugLog.addFirst(line)
            if (debugLog.size > 8) debugLog.removeLast()
            debugOverlay.text = debugLog.joinToString("\n")
        }
    }

    private fun AlertDialog.styleDialog(): AlertDialog {
        window?.setBackgroundDrawableResource(android.R.color.background_dark)
        getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#4FC3F7"))
        getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#99FFFFFF"))
        return this
    }

    // ══════════════════════════════════════════════════════════════════
    // JS → Native bridge
    // ══════════════════════════════════════════════════════════════════

    /**
     * Receives focus notifications from injected JavaScript.
     *
     * Belt-and-suspenders backup for onCreateInputConnection — handles:
     *   • contenteditable divs (don't always trigger onCreateInputConnection)
     *   • role=textbox/searchbox/combobox elements
     *   • Custom widgets using tabindex + programmatic .focus()
     *   • Shadow DOM inputs (React, Angular, Web Components)
     *   • Sites that focus inputs before the page fully loads
     */
    inner class WebKeyboardBridge {

        @JavascriptInterface
        fun onInputFocused() {
            runOnUiThread {
                dbg("jsbridge: input focused → queuing keyboard")
                // Cancel the "no IME" reset runnable — we now know this tap
                // was on an editable element.
                webView.removeCallbacks(resetWebInputFocusedRunnable)
                webInputFocused = true

                // Delay before showSoftInput:
                //   The JS focusin/focus event fires as soon as the DOM element
                //   receives focus.  The WebView's Blink renderer then needs to
                //   signal the native layer to create an InputConnection, which
                //   is asynchronous.  Calling showSoftInput with no active IC
                //   returns false on many devices.  200 ms gives the IC time to
                //   be established; showKeyboardForWebView() has its own 150 ms
                //   SHOW_FORCED retry if the first attempt still fails.
                webView.postDelayed({ showKeyboardForWebView() }, 200)
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView configuration
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        // Ensure the WebView can hold focus so the IMM doesn't drop IC
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true

        webView.settings.apply {
            javaScriptEnabled    = true
            domStorageEnabled    = true
            databaseEnabled      = true
            setSupportZoom(true)
            builtInZoomControls  = true
            displayZoomControls  = false
            userAgentString      = MOBILE_UA
            loadWithOverviewMode = true
            useWideViewPort      = true
            allowFileAccess      = false
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        applyDataSaverSettings()

        webView.addJavascriptInterface(WebKeyboardBridge(), "Android")

        // onCreateInputConnection fires when a web text field is focused and
        // the WebView creates a native InputConnection.  Calling showKeyboardForWebView
        // here covers inputs that do NOT trigger a JS focusin event (e.g. some
        // native-rendered inputs on certain sites, autofocus elements).
        webView.onWebInputFocused = {
            dbg("onCreateIC callback → showKeyboard")
            showKeyboardForWebView()
        }
        webView.onDebugEvent = { msg -> dbg(msg) }

        // Pad WebView bottom so content scrolls above the keyboard.
        // Works because adjustResize delivers real IME insets via WindowInsets.
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            view.setPadding(0, 0, 0, imeBottom)
            insets
        }

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(
                view: WebView, url: String?,
                favicon: android.graphics.Bitmap?
            ) {
                pageProgress.visibility = View.VISIBLE
                pageProgress.progress   = 0
                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true
                    urlInput.setText("Home")
                } else {
                    isOnHomePage = false
                    currentHost = try { java.net.URI(url).host?.removePrefix("www.") }
                                  catch (_: Exception) { null }
                    urlInput.setText(url)
                }
                syncNavButtons()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageProgress.visibility = View.GONE

                // ── Input-focus keyboard bridge ───────────────────────
                //
                // Injected once per page load.  Uses event delegation so all
                // dynamically created inputs (SPAs, infinite-scroll, modals)
                // are automatically covered without re-injection.
                //
                // isEditable() covers:
                //   • <input type=text/search/email/url/tel/number/password/date…>
                //   • <textarea>
                //   • contenteditable elements (attribute OR JS property)
                //   • ARIA role=textbox / searchbox / combobox
                //   • Any ancestor up to 5 levels (for deeply nested React inputs)
                //
                // Two events are used:
                //   focusin  — primary; covers programmatic .focus() calls
                //   focus    — capture; same but non-bubbling; redundant but safe
                //
                // The __kbListenerAttached guard prevents double-attachment on
                // back-navigation in SPAs that reuse the same window object.
                view.evaluateJavascript("""
                    (function() {
                        if (window.__kbListenerAttached) return;
                        window.__kbListenerAttached = true;

                        function isEditable(el) {
                            if (!el || !el.tagName) return false;
                            var tag = el.tagName.toUpperCase();
                            if (tag === 'INPUT') {
                                var t = (el.getAttribute('type') || 'text').toLowerCase();
                                // Exclude non-text input types
                                var excluded = ['checkbox','radio','submit','button',
                                               'file','image','reset','hidden','range','color'];
                                return excluded.indexOf(t) === -1;
                            }
                            if (tag === 'TEXTAREA') return true;
                            var role = (el.getAttribute('role') || '').toLowerCase();
                            if (role === 'textbox' || role === 'searchbox' || role === 'combobox') return true;
                            // contenteditable as attribute or JS property
                            var ce = el.getAttribute('contenteditable');
                            if (ce !== null && ce !== 'false') return true;
                            if (el.isContentEditable) return true;
                            return false;
                        }

                        function onMaybeEditable(e) {
                            // Walk up to 5 ancestors to handle wrapper elements
                            // (e.g. React inputs inside styled-components divs)
                            var el = e.target;
                            for (var i = 0; i < 5 && el; i++, el = el.parentElement) {
                                if (isEditable(el)) {
                                    if (typeof Android !== 'undefined') {
                                        Android.onInputFocused();
                                    }
                                    return;
                                }
                            }
                        }

                        // focusin bubbles — covers all focus events including
                        // programmatic .focus() and autofocus attributes.
                        document.addEventListener('focusin', onMaybeEditable, true);

                        // focus (non-bubbling) — redundant safety net for older
                        // WebKit behaviour where focusin was unreliable.
                        document.addEventListener('focus', onMaybeEditable, true);
                    })();
                """.trimIndent(), null)

                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true
                    urlInput.setText("Home")
                } else {
                    isOnHomePage = false
                    urlInput.setText(url)
                }
                syncNavButtons()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = false

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                if (adBlockEnabled && AdBlocker.shouldBlock(request, currentHost))
                    return AdBlocker.emptyResponse()
                if (dataSaverLevel > 0 &&
                    AdBlocker.shouldBlockForDataSaver(request, currentHost, dataSaverLevel))
                    return AdBlocker.emptyResponse()
                return null
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress < 100) {
                    pageProgress.visibility = View.VISIBLE
                    pageProgress.progress   = newProgress
                } else {
                    pageProgress.postDelayed({ pageProgress.visibility = View.GONE }, 200)
                }
            }
        }
        loadHomePage()
    }

    private fun loadHomePage() {
        isOnHomePage = true
        urlInput.setText("Home")
        webView.loadDataWithBaseURL("https://home.local/", HOME_HTML, "text/html", "UTF-8", null)
    }

    private fun applyDataSaverSettings() {
        webView.settings.apply {
            cacheMode = if (dataSaverLevel >= 3) WebSettings.LOAD_CACHE_ELSE_NETWORK
                        else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = dataSaverLevel < 4
        }
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar show / hide
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() {
        if (urlBarVisible) hideUrlBar() else showUrlBar()
    }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        showToggleFab(animate = false)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).setDuration(270).start()
        if (isOnHomePage) urlInput.setText("")
        urlInput.post {
            urlInput.isFocusable = true
            urlInput.isFocusableInTouchMode = true
            urlInput.requestFocus()
            urlInput.selectAll()
            // Keyboard is NOT forced open here — tap the field to type,
            // or paste directly since text is already selected.
        }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        dismissKeyboard()
        urlInput.clearFocus()
        // Disable focus so urlInput never steals focus from the WebView
        // while the bar is hidden — this was preventing web keyboard from appearing.
        urlInput.isFocusable = false
        urlInput.isFocusableInTouchMode = false
        webView.requestFocus()
        if (isOnHomePage) urlInput.setText("Home")
        urlBar.animate()
            .translationY(-urlBar.height.toFloat())
            .setDuration(220)
            .withEndAction { urlBar.visibility = View.INVISIBLE }
            .start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Floating toggle-button
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (toggleVisible) return
        toggleVisible = true
        if (animate) btnToggle.animate().alpha(1f).translationY(0f).setDuration(220).start()
        else { btnToggle.alpha = 1f; btnToggle.translationY = 0f }
    }

    private fun hideToggleFab() {
        if (!toggleVisible) return
        if (fabBehavior == 2) return
        toggleVisible = false
        btnToggle.animate()
            .alpha(0f)
            .translationY(28f * resources.displayMetrics.density)
            .setDuration(200).start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Navigation
    // ══════════════════════════════════════════════════════════════════

    private fun navigateTo(raw: String) {
        val s = raw.trim()
        if (s.isEmpty() || s == "Home") return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ")                 -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url)
        hideUrlBar()
    }

    private fun dismissKeyboard() {
        WindowInsetsControllerCompat(window, window.decorView)
            .hide(WindowInsetsCompat.Type.ime())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible       -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            !isOnHomePage       -> loadHomePage()
            else                -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }
}
