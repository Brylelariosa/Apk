package com.particlelife3d.app

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class ParticleRenderer(
    private val simulation: ParticleSystem,
    private val camera: OrbitCamera
) : GLSurfaceView.Renderer {

    @Volatile var paused = false
    var onFpsUpdate: ((Float) -> Unit)? = null

    private var particleProgram = 0
    private var pAPosition = 0
    private var pAColor = 0
    private var pUMvp = 0
    private var pUPointScale = 0

    private var lineProgram = 0
    private var lAPosition = 0
    private var lUMvp = 0
    private var lUColor = 0

    private var particleVbo = 0
    private var cubeVbo = 0
    private var cubeVertexCount = 0

    private var vertexData = FloatArray(0)
    private var vertexBuffer: FloatBuffer = emptyFloatBuffer()

    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)

    private var lastFrameNs = 0L
    private var fpsAccumTime = 0f
    private var fpsAccumFrames = 0

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.02f, 0.02f, 0.05f, 1f)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)

        particleProgram = ShaderUtils.createProgram(PARTICLE_VERTEX_SHADER, PARTICLE_FRAGMENT_SHADER)
        pAPosition = GLES20.glGetAttribLocation(particleProgram, "aPosition")
        pAColor = GLES20.glGetAttribLocation(particleProgram, "aColor")
        pUMvp = GLES20.glGetUniformLocation(particleProgram, "uMVPMatrix")
        pUPointScale = GLES20.glGetUniformLocation(particleProgram, "uPointScale")

        lineProgram = ShaderUtils.createProgram(LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER)
        lAPosition = GLES20.glGetAttribLocation(lineProgram, "aPosition")
        lUMvp = GLES20.glGetUniformLocation(lineProgram, "uMVPMatrix")
        lUColor = GLES20.glGetUniformLocation(lineProgram, "uColor")

        val genBuffers = IntArray(2)
        GLES20.glGenBuffers(2, genBuffers, 0)
        particleVbo = genBuffers[0]
        cubeVbo = genBuffers[1]

        uploadCubeWireframe()
        lastFrameNs = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = width.toFloat() / height.toFloat().coerceAtLeast(1f)
        Matrix.perspectiveM(projectionMatrix, 0, 55f, aspect, 1f, 1200f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = (now - lastFrameNs) / 1_000_000_000f
        lastFrameNs = now
        dt = dt.coerceIn(0f, 0.05f)

        if (!paused) simulation.update(dt)
        trackFps(dt)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        val eye = camera.eye()
        Matrix.setLookAtM(
            viewMatrix, 0,
            eye[0], eye[1], eye[2],
            camera.target[0], camera.target[1], camera.target[2],
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projectionMatrix, 0, viewMatrix, 0)

        drawCubeWireframe()
        drawParticles()
    }

    private fun trackFps(dt: Float) {
        fpsAccumTime += dt
        fpsAccumFrames++
        if (fpsAccumTime >= 0.5f) {
            val fps = if (fpsAccumTime > 0f) fpsAccumFrames / fpsAccumTime else 0f
            onFpsUpdate?.invoke(fps)
            fpsAccumTime = 0f
            fpsAccumFrames = 0
        }
    }

    private fun drawParticles() {
        val n = simulation.particleCount
        val needed = n * FLOATS_PER_VERTEX
        if (vertexData.size != needed) vertexData = FloatArray(needed)

        var idx = 0
        val px = simulation.posX
        val py = simulation.posY
        val pz = simulation.posZ
        val sp = simulation.species
        val colors = simulation.speciesColors
        for (i in 0 until n) {
            vertexData[idx++] = px[i]
            vertexData[idx++] = py[i]
            vertexData[idx++] = pz[i]
            val c = colors[sp[i]]
            vertexData[idx++] = c[0]
            vertexData[idx++] = c[1]
            vertexData[idx++] = c[2]
        }

        if (vertexBuffer.capacity() < needed) {
            vertexBuffer = ByteBuffer.allocateDirect(needed * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
        }
        vertexBuffer.clear()
        vertexBuffer.put(vertexData, 0, needed)
        vertexBuffer.position(0)

        GLES20.glUseProgram(particleProgram)
        GLES20.glUniformMatrix4fv(pUMvp, 1, false, vpMatrix, 0)
        GLES20.glUniform1f(pUPointScale, 2200f)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, particleVbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, needed * 4, vertexBuffer, GLES20.GL_DYNAMIC_DRAW)

        GLES20.glEnableVertexAttribArray(pAPosition)
        GLES20.glVertexAttribPointer(pAPosition, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, 0)
        GLES20.glEnableVertexAttribArray(pAColor)
        GLES20.glVertexAttribPointer(pAColor, 3, GLES20.GL_FLOAT, false, STRIDE_BYTES, 3 * 4)

        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, n)

        GLES20.glDisableVertexAttribArray(pAPosition)
        GLES20.glDisableVertexAttribArray(pAColor)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    private fun uploadCubeWireframe() {
        val h = simulation.boundsHalfExtent
        val corners = arrayOf(
            floatArrayOf(-h, -h, -h), floatArrayOf(h, -h, -h),
            floatArrayOf(h, h, -h), floatArrayOf(-h, h, -h),
            floatArrayOf(-h, -h, h), floatArrayOf(h, -h, h),
            floatArrayOf(h, h, h), floatArrayOf(-h, h, h)
        )
        val edges = arrayOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 0,
            4 to 5, 5 to 6, 6 to 7, 7 to 4,
            0 to 4, 1 to 5, 2 to 6, 3 to 7
        )
        val data = FloatArray(edges.size * 2 * 3)
        var idx = 0
        for ((a, b) in edges) {
            data[idx++] = corners[a][0]; data[idx++] = corners[a][1]; data[idx++] = corners[a][2]
            data[idx++] = corners[b][0]; data[idx++] = corners[b][1]; data[idx++] = corners[b][2]
        }
        cubeVertexCount = edges.size * 2

        val buffer = ByteBuffer.allocateDirect(data.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        buffer.put(data)
        buffer.position(0)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cubeVbo)
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.size * 4, buffer, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    private fun drawCubeWireframe() {
        GLES20.glUseProgram(lineProgram)
        GLES20.glUniformMatrix4fv(lUMvp, 1, false, vpMatrix, 0)
        GLES20.glUniform4f(lUColor, 0.3f, 0.35f, 0.5f, 0.35f)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, cubeVbo)
        GLES20.glEnableVertexAttribArray(lAPosition)
        GLES20.glVertexAttribPointer(lAPosition, 3, GLES20.GL_FLOAT, false, 0, 0)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, cubeVertexCount)
        GLES20.glDisableVertexAttribArray(lAPosition)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    companion object {
        private const val STRIDE_BYTES = 6 * 4
        private const val FLOATS_PER_VERTEX = 6

        private fun emptyFloatBuffer(): FloatBuffer =
            ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder()).asFloatBuffer()

        private val PARTICLE_VERTEX_SHADER = """
            uniform mat4 uMVPMatrix;
            uniform float uPointScale;
            attribute vec3 aPosition;
            attribute vec3 aColor;
            varying vec3 vColor;
            void main() {
                vec4 pos = uMVPMatrix * vec4(aPosition, 1.0);
                gl_Position = pos;
                float d = max(pos.w, 1.0);
                gl_PointSize = clamp(uPointScale / d, 3.0, 44.0);
                vColor = aColor;
            }
        """.trimIndent()

        private val PARTICLE_FRAGMENT_SHADER = """
            precision mediump float;
            varying vec3 vColor;
            void main() {
                vec2 coord = gl_PointCoord - vec2(0.5);
                float dist = length(coord);
                if (dist > 0.5) discard;
                float glow = 1.0 - smoothstep(0.0, 0.5, dist);
                gl_FragColor = vec4(vColor * glow, glow);
            }
        """.trimIndent()

        private val LINE_VERTEX_SHADER = """
            uniform mat4 uMVPMatrix;
            attribute vec3 aPosition;
            void main() {
                gl_Position = uMVPMatrix * vec4(aPosition, 1.0);
            }
        """.trimIndent()

        private val LINE_FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            void main() {
                gl_FragColor = uColor;
            }
        """.trimIndent()
    }
}
