package com.particlelife3d.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.sqrt

/**
 * Simple on-screen thumbstick. Reports normalized x/y in [-1,1] via onMove
 * while held, and (0,0) on release. Movement input only, no click semantics.
 */
class JoystickView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var onMove: ((x: Float, y: Float) -> Unit)? = null

    private var centerX = 0f
    private var centerY = 0f
    private var knobX = 0f
    private var knobY = 0f
    private var baseRadius = 0f
    private var knobRadius = 0f

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 255, 255, 255)
        style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 255, 255, 255)
        style = Paint.Style.FILL
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        centerX = w / 2f
        centerY = h / 2f
        knobX = centerX
        knobY = centerY
        baseRadius = minOf(w, h) / 2f - 4f
        knobRadius = baseRadius * 0.42f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawCircle(centerX, centerY, baseRadius, basePaint)
        canvas.drawCircle(centerX, centerY, baseRadius, ringPaint)
        canvas.drawCircle(knobX, knobY, knobRadius, knobPaint)
    }

    private var activePointerId = MotionEvent.INVALID_POINTER_ID

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePointerId = event.getPointerId(0)
                updateKnob(event.x, event.y)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // Stick is already held by another finger -- ignore extra touches
                // landing on it rather than letting them hijack the reading.
                if (activePointerId == MotionEvent.INVALID_POINTER_ID) {
                    val idx = event.actionIndex
                    activePointerId = event.getPointerId(idx)
                    updateKnob(event.getX(idx), event.getY(idx))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = event.findPointerIndex(activePointerId)
                if (idx != -1) updateKnob(event.getX(idx), event.getY(idx))
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.getPointerId(event.actionIndex) == activePointerId) {
                    activePointerId = MotionEvent.INVALID_POINTER_ID
                    resetKnob()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePointerId = MotionEvent.INVALID_POINTER_ID
                resetKnob()
            }
        }
        return true
    }

    private fun updateKnob(x: Float, y: Float) {
        var dx = x - centerX
        var dy = y - centerY
        val dist = sqrt(dx * dx + dy * dy)
        val maxDist = (baseRadius - knobRadius).coerceAtLeast(1f)
        if (dist > maxDist) {
            dx = dx / dist * maxDist
            dy = dy / dist * maxDist
        }
        knobX = centerX + dx
        knobY = centerY + dy
        invalidate()
        onMove?.invoke((dx / maxDist).coerceIn(-1f, 1f), (dy / maxDist).coerceIn(-1f, 1f))
    }

    private fun resetKnob() {
        knobX = centerX
        knobY = centerY
        invalidate()
        onMove?.invoke(0f, 0f)
    }
}
