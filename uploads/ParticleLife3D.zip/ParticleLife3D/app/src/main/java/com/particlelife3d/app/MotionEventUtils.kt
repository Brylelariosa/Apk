package com.particlelife3d.app

import android.view.MotionEvent

/**
 * Returns a new [MotionEvent] containing only the pointers whose IDs are set
 * in [idBits] (bit N corresponds to pointer ID N), re-indexed so pointer
 * index 0 in the result is the lowest-ID pointer that was kept.
 *
 * The platform has a method that does this internally
 * (`MotionEvent.split(int)`), but it is annotated `@hide`/`@UnsupportedAppUsage`
 * and is stripped from the public SDK stubs, so calling it does not compile.
 * This is a drop-in replacement built entirely from the public
 * [MotionEvent.obtain] pointer-array factory, so callers can filter out
 * pointers (e.g. ones already claimed by an overlapping child view like a
 * joystick) before handing the event to something like [android.view.GestureDetector],
 * which otherwise always reads pointer index 0 and gets confused when that
 * index alternates between unrelated fingers.
 *
 * When the pointer whose transition triggered the action survives the
 * filter and it is the *only* surviving pointer, the action collapses to a
 * plain `ACTION_DOWN`/`ACTION_UP` rather than staying an indexed
 * `ACTION_POINTER_DOWN`/`ACTION_POINTER_UP`. This matters for consumers
 * like [android.view.GestureDetector], which only resets its scroll-tracking
 * state on `ACTION_DOWN`: e.g. if a joystick finger is already down and a
 * second, filtered-in finger then touches down to start a look-drag, that
 * finger is the *first* pointer as far as the filtered stream is concerned
 * and needs to be delivered as `ACTION_DOWN`, not `ACTION_POINTER_DOWN`.
 *
 * The caller owns the returned event and must call [MotionEvent.recycle] on
 * it once done, same as the original event it was derived from.
 */
fun MotionEvent.filterPointers(idBits: Int): MotionEvent {
    val properties = ArrayList<MotionEvent.PointerProperties>(pointerCount)
    val coords = ArrayList<MotionEvent.PointerCoords>(pointerCount)

    val originalActionMasked = actionMasked
    val originalActionIndex = actionIndex
    var filteredActionIndex = -1

    for (i in 0 until pointerCount) {
        if ((1 shl getPointerId(i)) and idBits == 0) continue

        val prop = MotionEvent.PointerProperties()
        getPointerProperties(i, prop)
        val coord = MotionEvent.PointerCoords()
        getPointerCoords(i, coord)

        if (i == originalActionIndex) filteredActionIndex = properties.size
        properties.add(prop)
        coords.add(coord)
    }

    require(properties.isNotEmpty()) { "idBits $idBits matched none of this event's pointers" }

    // ACTION_POINTER_DOWN/UP encode which pointer changed in the action's
    // upper bits. If that pointer didn't survive the filter, there's no
    // meaningful "pointer changed" event left for our subset, so fall back
    // to a plain move. If it did survive and it's the only pointer left,
    // collapse to ACTION_DOWN/ACTION_UP; otherwise remap the index to its
    // new position within the filtered pointer list.
    val newAction = when {
        originalActionMasked != MotionEvent.ACTION_POINTER_DOWN &&
            originalActionMasked != MotionEvent.ACTION_POINTER_UP -> originalActionMasked
        filteredActionIndex < 0 -> MotionEvent.ACTION_MOVE
        properties.size == 1 ->
            if (originalActionMasked == MotionEvent.ACTION_POINTER_DOWN) MotionEvent.ACTION_DOWN
            else MotionEvent.ACTION_UP
        else -> originalActionMasked or (filteredActionIndex shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
    }

    return MotionEvent.obtain(
        downTime, eventTime, newAction, properties.size,
        properties.toTypedArray(), coords.toTypedArray(),
        metaState, buttonState, xPrecision, yPrecision,
        deviceId, edgeFlags, source, flags
    )
}
