package com.particlelife3d.app

import kotlin.math.cos
import kotlin.math.sin

/**
 * Free-fly first-person camera: a joystick drives forward/strafe movement
 * continuously (tick(), once per frame on the GL thread), one-finger drag
 * drives look (yaw/pitch). Position wraps at the same bounds as the particle
 * simulation, so flying far enough in one direction loops back around instead
 * of hitting a wall -- paired with the simulation's own toroidal boundary,
 * this gives a seamless, endless-feeling world out of a finite domain.
 */
class FreeCamera(private val boundsHalfExtent: Float) {

    var posX = 0f
    var posY = 35f
    var posZ = 150f

    var yawDeg = 180f
    var pitchDeg = -10f
    private val minPitch = -85f
    private val maxPitch = 85f

    var moveSpeed = 50f // world units per second at full stick deflection

    // Written by the joystick on the UI thread, read every frame by tick() on
    // the GL thread -- simple continuous float inputs, so plain volatility is
    // enough (no need to marshal every joystick tick through queueEvent).
    @Volatile var inputForward = 0f
    @Volatile var inputStrafe = 0f

    fun look(dYawDeg: Float, dPitchDeg: Float) {
        yawDeg = (yawDeg + dYawDeg) % 360f
        pitchDeg = (pitchDeg + dPitchDeg).coerceIn(minPitch, maxPitch)
    }

    fun tick(dt: Float) {
        val f = inputForward
        val s = inputStrafe
        if (f == 0f && s == 0f) return

        val fwd = forward()
        val rgt = right()
        val speed = moveSpeed * dt

        posX += (fwd[0] * f + rgt[0] * s) * speed
        posY += fwd[1] * f * speed
        posZ += (fwd[2] * f + rgt[2] * s) * speed

        val half = boundsHalfExtent
        val full = half * 2f
        if (posX > half) posX -= full else if (posX < -half) posX += full
        if (posY > half) posY -= full else if (posY < -half) posY += full
        if (posZ > half) posZ -= full else if (posZ < -half) posZ += full
    }

    fun forward(): FloatArray {
        val yawRad = Math.toRadians(yawDeg.toDouble())
        val pitchRad = Math.toRadians(pitchDeg.toDouble())
        val cosPitch = cos(pitchRad)
        val x = cosPitch * sin(yawRad)
        val y = sin(pitchRad)
        val z = cosPitch * cos(yawRad)
        return floatArrayOf(x.toFloat(), y.toFloat(), z.toFloat())
    }

    /** Horizontal-only strafe axis, independent of pitch (standard FPS convention). */
    fun right(): FloatArray {
        val yawRad = Math.toRadians(yawDeg.toDouble())
        val x = cos(yawRad)
        val z = -sin(yawRad)
        return floatArrayOf(x.toFloat(), 0f, z.toFloat())
    }

    fun eye(): FloatArray = floatArrayOf(posX, posY, posZ)

    fun lookAtTarget(): FloatArray {
        val f = forward()
        return floatArrayOf(posX + f[0], posY + f[1], posZ + f[2])
    }
}
