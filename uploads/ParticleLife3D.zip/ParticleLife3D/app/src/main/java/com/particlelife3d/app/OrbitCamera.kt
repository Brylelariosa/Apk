package com.particlelife3d.app

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Spherical orbit camera: one-finger drag orbits (rotate), two-finger drag pans
 * the look-at target, and pinch zooms. All mutation happens on the GL thread via
 * GLSurfaceView.queueEvent (see MainActivity), so no synchronization is needed.
 */
class OrbitCamera {
    var azimuthDeg = 35f
    var elevationDeg = 20f
    var distance = 220f

    var minDistance = 40f
    var maxDistance = 500f
    private val minElevation = -85f
    private val maxElevation = 85f

    val target = floatArrayOf(0f, 0f, 0f)

    fun rotate(dAzimuthDeg: Float, dElevationDeg: Float) {
        azimuthDeg = (azimuthDeg + dAzimuthDeg) % 360f
        elevationDeg = (elevationDeg + dElevationDeg).coerceIn(minElevation, maxElevation)
    }

    fun zoom(scaleFactor: Float) {
        if (scaleFactor <= 0f) return
        distance = (distance / scaleFactor).coerceIn(minDistance, maxDistance)
    }

    /** Two-finger drag: translate the look-at target within the screen's right/up plane. */
    fun pan(dxScreen: Float, dyScreen: Float) {
        val eyePos = eye()
        var fx = target[0] - eyePos[0]
        var fy = target[1] - eyePos[1]
        var fz = target[2] - eyePos[2]
        val flen = sqrt(fx * fx + fy * fy + fz * fz).coerceAtLeast(0.0001f)
        fx /= flen; fy /= flen; fz /= flen

        // world up
        val upX = 0f; val upY = 1f; val upZ = 0f

        // screen-right = normalize(forward x up)
        var rx = fy * upZ - fz * upY
        var ry = fz * upX - fx * upZ
        var rz = fx * upY - fy * upX
        val rlen = sqrt(rx * rx + ry * ry + rz * rz).coerceAtLeast(0.0001f)
        rx /= rlen; ry /= rlen; rz /= rlen

        // screen-up = right x forward
        val cux = ry * fz - rz * fy
        val cuy = rz * fx - rx * fz
        val cuz = rx * fy - ry * fx

        // scale pan speed with distance so it feels consistent at any zoom level
        val panScale = distance * 0.0015f

        target[0] -= rx * dxScreen * panScale
        target[1] -= ry * dxScreen * panScale
        target[2] -= rz * dxScreen * panScale

        target[0] += cux * dyScreen * panScale
        target[1] += cuy * dyScreen * panScale
        target[2] += cuz * dyScreen * panScale
    }

    fun eye(): FloatArray {
        val az = Math.toRadians(azimuthDeg.toDouble())
        val el = Math.toRadians(elevationDeg.toDouble())
        val dist = distance.toDouble()
        val horizontal = dist * cos(el)
        val x = target[0].toDouble() + horizontal * sin(az)
        val y = target[1].toDouble() + dist * sin(el)
        val z = target[2].toDouble() + horizontal * cos(az)
        return floatArrayOf(x.toFloat(), y.toFloat(), z.toFloat())
    }
}
