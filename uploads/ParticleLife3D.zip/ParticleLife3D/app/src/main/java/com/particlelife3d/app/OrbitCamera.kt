package com.particlelife3d.app

import kotlin.math.cos
import kotlin.math.sin

/**
 * Spherical orbit camera: drag changes azimuth/elevation, pinch changes
 * distance from the target. All mutation happens on the GL thread via
 * GLSurfaceView.queueEvent (see MainActivity), so no synchronization is
 * needed here.
 */
class OrbitCamera {
    var azimuthDeg = 35f
    var elevationDeg = 20f
    var distance = 220f

    var minDistance = 40f
    var maxDistance = 500f
    private val minElevation = -85f
    private val maxElevation = 85f

    val target = floatArrayOf(0f, 0f, 0f)

    fun rotate(dAzimuthDeg: Float, dElevationDeg: Float) {
        azimuthDeg = (azimuthDeg + dAzimuthDeg) % 360f
        elevationDeg = (elevationDeg + dElevationDeg).coerceIn(minElevation, maxElevation)
    }

    fun zoom(scaleFactor: Float) {
        if (scaleFactor <= 0f) return
        distance = (distance / scaleFactor).coerceIn(minDistance, maxDistance)
    }

    fun eye(): FloatArray {
        val az = Math.toRadians(azimuthDeg.toDouble())
        val el = Math.toRadians(elevationDeg.toDouble())
        val dist = distance.toDouble()
        val horizontal = dist * cos(el)
        val x = target[0].toDouble() + horizontal * sin(az)
        val y = target[1].toDouble() + dist * sin(el)
        val z = target[2].toDouble() + horizontal * cos(az)
        return floatArrayOf(x.toFloat(), y.toFloat(), z.toFloat())
    }
}
