package com.particlelife3d.app

import android.graphics.Color
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Core particle-life simulation: N particles across K species drifting through
 * a bounded 3D cube, governed by a random per-species-pair attraction/repulsion
 * matrix. State lives in flat primitive arrays (structure-of-arrays). Every
 * mutating call here is expected to run on the GL thread (see MainActivity's
 * use of glSurfaceView.queueEvent), so there is no locking between simulation
 * and rendering.
 */
class ParticleSystem(
    initialParticleCount: Int,
    initialSpeciesCount: Int,
    val boundsHalfExtent: Float = 90f
) {
    var particleCount: Int = initialParticleCount
        private set
    var speciesCount: Int = initialSpeciesCount
        private set

    lateinit var posX: FloatArray
    lateinit var posY: FloatArray
    lateinit var posZ: FloatArray
    private lateinit var velX: FloatArray
    private lateinit var velY: FloatArray
    private lateinit var velZ: FloatArray
    lateinit var species: IntArray
    lateinit var speciesColors: Array<FloatArray>

    // Tunable simulation constants -- adjust to taste.
    var interactionRadius = 16f
    var minRepelRadius = 2.5f
    var friction = 0.92f
    var forceScale = 60f

    private lateinit var rules: Array<FloatArray>
    private lateinit var grid: SpatialHashGrid3D

    // The rule/force pass is the dominant per-frame cost and is embarrassingly
    // parallel: each particle only reads shared (already-settled) position/grid
    // state and writes its own velocity slot, so splitting the index range across
    // threads is race-free -- no two threads ever touch the same array element.
    // One core is left for the GL/render thread itself, which also takes a share
    // of the work instead of sitting idle waiting on the pool.
    private val bgWorkerCount = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(0, 3)
    private val executor: ExecutorService? =
        if (bgWorkerCount > 0) Executors.newFixedThreadPool(bgWorkerCount) else null

    init {
        grid = SpatialHashGrid3D(interactionRadius, boundsHalfExtent)
        assignSpeciesColors()
        randomizeRuleMatrix()
        resetParticles()
    }

    private fun assignSpeciesColors() {
        speciesColors = Array(speciesCount) { i ->
            // Value/saturation pulled back from max -- fully saturated, full-brightness
            // HSV dots against a near-black background read as harsh/glary, especially
            // in yellow-green hues. This keeps colors distinct and vivid without the glare.
            val hsv = floatArrayOf(360f * i / speciesCount, 0.68f, 0.82f)
            val c = Color.HSVToColor(hsv)
            floatArrayOf(Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)
        }
    }

    private fun randomizeRuleMatrix() {
        rules = Array(speciesCount) { FloatArray(speciesCount) { Random.nextFloat() * 2f - 1f } }
    }

    /** New interaction rules, new colors, fresh particle spawn. */
    fun randomizeRules() {
        assignSpeciesColors()
        randomizeRuleMatrix()
        resetParticles()
    }

    /** Same rules, just respawn positions/velocities. */
    fun resetParticles() {
        posX = FloatArray(particleCount)
        posY = FloatArray(particleCount)
        posZ = FloatArray(particleCount)
        velX = FloatArray(particleCount)
        velY = FloatArray(particleCount)
        velZ = FloatArray(particleCount)
        species = IntArray(particleCount)

        for (i in 0 until particleCount) {
            posX[i] = (Random.nextFloat() * 2f - 1f) * boundsHalfExtent
            posY[i] = (Random.nextFloat() * 2f - 1f) * boundsHalfExtent
            posZ[i] = (Random.nextFloat() * 2f - 1f) * boundsHalfExtent
            species[i] = i % speciesCount
        }
    }

    fun setSpeciesCount(n: Int) {
        speciesCount = n
        assignSpeciesColors()
        randomizeRuleMatrix()
        resetParticles()
    }

    fun setParticleCount(n: Int) {
        particleCount = n
        resetParticles()
    }

    fun update(dt: Float) {
        val step = dt.coerceIn(0f, 0.033f)
        grid.rebuild(posX, posY, posZ, particleCount)

        val rMax = interactionRadius
        val rMaxSq = rMax * rMax
        val rMin = minRepelRadius
        val half = boundsHalfExtent
        val full = half * 2f

        computeForces(rMax, rMaxSq, rMin, half, full, step)

        for (i in 0 until particleCount) {
            posX[i] += velX[i] * step
            posY[i] += velY[i] * step
            posZ[i] += velZ[i] * step

            if (posX[i] > half) posX[i] -= full else if (posX[i] < -half) posX[i] += full
            if (posY[i] > half) posY[i] -= full else if (posY[i] < -half) posY[i] += full
            if (posZ[i] > half) posZ[i] -= full else if (posZ[i] < -half) posZ[i] += full
        }
    }

    /** Below this, thread hand-off overhead isn't worth it -- just run inline. */
    private val parallelThreshold = 1500

    private fun computeForces(rMax: Float, rMaxSq: Float, rMin: Float, half: Float, full: Float, step: Float) {
        val n = particleCount
        val exec = executor
        if (exec == null || n < parallelThreshold) {
            computeForceRange(0, n, rMax, rMaxSq, rMin, half, full, step)
            return
        }

        val totalChunks = bgWorkerCount + 1
        val chunkSize = (n + totalChunks - 1) / totalChunks
        val latch = CountDownLatch(bgWorkerCount)
        var start = 0
        for (w in 0 until bgWorkerCount) {
            val from = start
            val to = (start + chunkSize).coerceAtMost(n)
            start = to
            exec.execute {
                computeForceRange(from, to, rMax, rMaxSq, rMin, half, full, step)
                latch.countDown()
            }
        }
        // Remaining chunk runs on the calling (GL) thread instead of sitting idle.
        computeForceRange(start, n, rMax, rMaxSq, rMin, half, full, step)
        latch.await()
    }

    private fun computeForceRange(
        from: Int, to: Int,
        rMax: Float, rMaxSq: Float, rMin: Float, half: Float, full: Float, step: Float
    ) {
        for (i in from until to) {
            var fx = 0f
            var fy = 0f
            var fz = 0f
            val xi = posX[i]
            val yi = posY[i]
            val zi = posZ[i]
            val ruleRow = rules[species[i]]

            grid.forEachNeighbor(xi, yi, zi) { j ->
                if (j != i) {
                    var dx = posX[j] - xi
                    var dy = posY[j] - yi
                    var dz = posZ[j] - zi
                    // Minimum-image convention: two particles near opposite edges
                    // of the domain are actually close together once wrapped, so
                    // use whichever offset (direct or wrapped) is shorter.
                    if (dx > half) dx -= full else if (dx < -half) dx += full
                    if (dy > half) dy -= full else if (dy < -half) dy += full
                    if (dz > half) dz -= full else if (dz < -half) dz += full
                    val distSq = dx * dx + dy * dy + dz * dz
                    if (distSq < rMaxSq && distSq > 1e-8f) {
                        val dist = sqrt(distSq)
                        val f = forceBetween(dist, rMin, rMax, ruleRow[species[j]])
                        val inv = f / dist
                        fx += dx * inv
                        fy += dy * inv
                        fz += dz * inv
                    }
                }
            }

            velX[i] = (velX[i] + fx * forceScale * step) * friction
            velY[i] = (velY[i] + fy * forceScale * step) * friction
            velZ[i] = (velZ[i] + fz * forceScale * step) * friction
        }
    }

    /** Call from Activity#onDestroy to release the worker pool. */
    fun shutdown() {
        executor?.shutdown()
    }

    private fun forceBetween(dist: Float, rMin: Float, rMax: Float, k: Float): Float {
        return if (dist < rMin) {
            dist / rMin - 1f
        } else {
            val mid = (rMin + rMax) * 0.5f
            val half = (rMax - rMin) * 0.5f
            k * (1f - abs(dist - mid) / half)
        }
    }
}
