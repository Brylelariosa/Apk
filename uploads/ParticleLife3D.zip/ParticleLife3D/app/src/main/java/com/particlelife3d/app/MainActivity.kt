package com.particlelife3d.app

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.particlelife3d.app.databinding.ActivityMainBinding
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var simulation: ParticleSystem
    private lateinit var camera: OrbitCamera
    private lateinit var renderer: ParticleRenderer
    private lateinit var scaleDetector: ScaleGestureDetector
    private lateinit var gestureDetector: GestureDetector

    private var panelOpen = false
    private var displayedSpeciesCount = 6
    private val particlePresets = intArrayOf(1500, 3000, 4500, 6000, 8000)
    private var particlePresetIndex = 0

    // Two-finger pan tracking (kept separate from GestureDetector, which is
    // built around single-pointer scroll semantics).
    private var isPanning = false
    private var lastPanX = 0f
    private var lastPanY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        hideSystemBars()

        camera = OrbitCamera()
        simulation = ParticleSystem(
            initialParticleCount = particlePresets[particlePresetIndex],
            initialSpeciesCount = displayedSpeciesCount
        )

        glSurfaceView = object : GLSurfaceView(this) {
            override fun onTouchEvent(event: MotionEvent): Boolean = handleTouch(event)
        }
        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.preserveEGLContextOnPause = true

        renderer = ParticleRenderer(simulation, camera)
        renderer.onFpsUpdate = { fps ->
            runOnUiThread { binding.fpsText.text = "FPS: ${fps.roundToInt()}" }
        }
        glSurfaceView.setRenderer(renderer)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        binding.rootContainer.addView(
            glSurfaceView,
            0,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        setupGestureDetectors()
        setupButtons()
        updateParticleLabel()
        binding.speciesCountText.text = displayedSpeciesCount.toString()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun setupGestureDetectors() {
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val factor = detector.scaleFactor
                glSurfaceView.queueEvent { camera.zoom(factor) }
                return true
            }
        })

        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                val dAz = distanceX * 0.25f
                val dEl = -distanceY * 0.25f
                glSurfaceView.queueEvent { camera.rotate(dAz, dEl) }
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (panelOpen) setPanelOpen(false)
                return true
            }
        })
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == 2) {
                    isPanning = true
                    lastPanX = centroidX(event)
                    lastPanY = centroidY(event)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (isPanning && event.pointerCount >= 2) {
                    val cx = centroidX(event)
                    val cy = centroidY(event)
                    val dx = cx - lastPanX
                    val dy = cy - lastPanY
                    lastPanX = cx
                    lastPanY = cy
                    glSurfaceView.queueEvent { camera.pan(dx, dy) }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount <= 2) isPanning = false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isPanning = false
            }
        }

        // While panning, GestureDetector doesn't see move events, so its
        // single-pointer scroll (orbit) can't fight with the two-finger pan.
        if (!isPanning) {
            gestureDetector.onTouchEvent(event)
        }
        return true
    }

    private fun centroidX(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getX(i)
        return sum / event.pointerCount
    }

    private fun centroidY(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getY(i)
        return sum / event.pointerCount
    }

    private fun setPanelOpen(open: Boolean) {
        panelOpen = open
        binding.panel.visibility = if (open) View.VISIBLE else View.GONE
        binding.btnMenu.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_menu)
    }

    private fun setupButtons() {
        binding.btnMenu.setOnClickListener { setPanelOpen(!panelOpen) }

        binding.btnRandomize.setOnClickListener {
            glSurfaceView.queueEvent { simulation.randomizeRules() }
        }
        binding.btnReset.setOnClickListener {
            glSurfaceView.queueEvent { simulation.resetParticles() }
        }
        binding.btnSpeciesMinus.setOnClickListener {
            displayedSpeciesCount = (displayedSpeciesCount - 1).coerceIn(2, 12)
            binding.speciesCountText.text = displayedSpeciesCount.toString()
            val n = displayedSpeciesCount
            glSurfaceView.queueEvent { simulation.setSpeciesCount(n) }
        }
        binding.btnSpeciesPlus.setOnClickListener {
            displayedSpeciesCount = (displayedSpeciesCount + 1).coerceIn(2, 12)
            binding.speciesCountText.text = displayedSpeciesCount.toString()
            val n = displayedSpeciesCount
            glSurfaceView.queueEvent { simulation.setSpeciesCount(n) }
        }
        binding.btnParticles.setOnClickListener {
            particlePresetIndex = (particlePresetIndex + 1) % particlePresets.size
            val n = particlePresets[particlePresetIndex]
            updateParticleLabel()
            glSurfaceView.queueEvent { simulation.setParticleCount(n) }
        }
        binding.btnPause.setOnClickListener {
            renderer.paused = !renderer.paused
            binding.btnPause.setImageResource(if (renderer.paused) R.drawable.ic_play else R.drawable.ic_pause)
        }
    }

    private fun updateParticleLabel() {
        binding.particleCountText.text = "${particlePresets[particlePresetIndex]} particles"
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
    }
}
