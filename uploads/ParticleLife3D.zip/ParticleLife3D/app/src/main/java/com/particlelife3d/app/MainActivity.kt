package com.particlelife3d.app

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.particlelife3d.app.databinding.ActivityMainBinding
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var simulation: ParticleSystem
    private lateinit var camera: FreeCamera
    private lateinit var renderer: ParticleRenderer
    private lateinit var gestureDetector: GestureDetector

    private var panelOpen = false
    private var displayedSpeciesCount = 6
    private val particlePresets = intArrayOf(1500, 3000, 4500, 6000, 8000)
    private var particlePresetIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        hideSystemBars()

        simulation = ParticleSystem(
            initialParticleCount = particlePresets[particlePresetIndex],
            initialSpeciesCount = displayedSpeciesCount
        )
        camera = FreeCamera(simulation.boundsHalfExtent)

        glSurfaceView = object : GLSurfaceView(this) {
            override fun onTouchEvent(event: MotionEvent): Boolean = handleTouch(event)
        }
        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.setEGLConfigChooser(8, 8, 8, 0, 16, 0)
        glSurfaceView.preserveEGLContextOnPause = true

        renderer = ParticleRenderer(simulation, camera)
        renderer.onFpsUpdate = { fps ->
            runOnUiThread { binding.fpsText.text = "FPS: ${fps.roundToInt()}" }
        }
        glSurfaceView.setRenderer(renderer)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        binding.rootContainer.addView(
            glSurfaceView,
            0,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        setupGestureDetector()
        setupJoystick()
        setupButtons()
        updateParticleLabel()
        binding.speciesCountText.text = displayedSpeciesCount.toString()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun setupJoystick() {
        binding.joystick.onMove = { x, y ->
            // Screen Y grows downward, so pushing the stick up (negative y)
            // should mean "move forward" (positive input).
            camera.inputForward = -y
            camera.inputStrafe = x
        }
    }

    private fun setupGestureDetector() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                val dYaw = distanceX * 0.25f
                val dPitch = distanceY * 0.25f
                glSurfaceView.queueEvent { camera.look(dYaw, dPitch) }
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (panelOpen) setPanelOpen(false)
                return true
            }
        })
    }

    private fun handleTouch(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return true
    }

    private fun setPanelOpen(open: Boolean) {
        panelOpen = open
        binding.panel.visibility = if (open) View.VISIBLE else View.GONE
        binding.btnMenu.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_menu)
    }

    private fun setupButtons() {
        binding.btnMenu.setOnClickListener { setPanelOpen(!panelOpen) }

        binding.btnRandomize.setOnClickListener {
            glSurfaceView.queueEvent { simulation.randomizeRules() }
        }
        binding.btnReset.setOnClickListener {
            glSurfaceView.queueEvent { simulation.resetParticles() }
        }
        binding.btnSpeciesMinus.setOnClickListener {
            displayedSpeciesCount = (displayedSpeciesCount - 1).coerceIn(2, 12)
            binding.speciesCountText.text = displayedSpeciesCount.toString()
            val n = displayedSpeciesCount
            glSurfaceView.queueEvent { simulation.setSpeciesCount(n) }
        }
        binding.btnSpeciesPlus.setOnClickListener {
            displayedSpeciesCount = (displayedSpeciesCount + 1).coerceIn(2, 12)
            binding.speciesCountText.text = displayedSpeciesCount.toString()
            val n = displayedSpeciesCount
            glSurfaceView.queueEvent { simulation.setSpeciesCount(n) }
        }
        binding.btnParticles.setOnClickListener {
            particlePresetIndex = (particlePresetIndex + 1) % particlePresets.size
            val n = particlePresets[particlePresetIndex]
            updateParticleLabel()
            glSurfaceView.queueEvent { simulation.setParticleCount(n) }
        }
        binding.btnPause.setOnClickListener {
            renderer.paused = !renderer.paused
            binding.btnPause.setImageResource(if (renderer.paused) R.drawable.ic_play else R.drawable.ic_pause)
        }
    }

    private fun updateParticleLabel() {
        binding.particleCountText.text = "${particlePresets[particlePresetIndex]} particles"
    }

    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
    }
}
