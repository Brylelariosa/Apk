package com.particlelife3d.app

import kotlin.math.ceil

/**
 * Uniform 3D grid over the simulation's fixed bounding cube, using counting-sort
 * binning instead of a hash map: flat IntArrays only, no boxing, no per-cell
 * allocation.
 *
 * Neighbor cell lookups wrap at the domain edge (cell gridDim-1's neighbor is
 * cell 0), matching the particle simulation's own toroidal boundary -- a
 * particle near one edge of the world correctly finds neighbors that wrapped
 * around to the opposite edge.
 */
class SpatialHashGrid3D(private val cellSize: Float, private val boundsHalfExtent: Float) {

    internal val gridDim = (ceil(2f * boundsHalfExtent / cellSize).toInt() + 1).coerceAtLeast(3)
    private val cellCount = gridDim * gridDim * gridDim

    // cellStart[c] .. cellStart[c+1] is the index range in sortedIndices for cell c.
    internal val cellStart = IntArray(cellCount + 1)
    private val cellCursor = IntArray(cellCount + 1)
    private var particleCell = IntArray(0)
    internal var sortedIndices = IntArray(0)

    internal fun axisCoord(v: Float): Int {
        val c = ((v + boundsHalfExtent) / cellSize).toInt()
        return c.coerceIn(0, gridDim - 1)
    }

    internal fun wrapCell(c: Int): Int {
        var v = c
        if (v < 0) v += gridDim
        if (v >= gridDim) v -= gridDim
        return v
    }

    private fun flatIndex(ix: Int, iy: Int, iz: Int) = ix + iy * gridDim + iz * gridDim * gridDim

    fun rebuild(x: FloatArray, y: FloatArray, z: FloatArray, count: Int) {
        if (particleCell.size < count) {
            particleCell = IntArray(count)
            sortedIndices = IntArray(count)
        }
        java.util.Arrays.fill(cellStart, 0)

        // Histogram: count particles per cell (offset by one, so cellStart[c+1]
        // ends up holding cell c's count before the prefix sum below).
        for (i in 0 until count) {
            val c = flatIndex(axisCoord(x[i]), axisCoord(y[i]), axisCoord(z[i]))
            particleCell[i] = c
            cellStart[c + 1]++
        }
        // Prefix sum turns per-cell counts into start offsets.
        for (c in 1..cellCount) cellStart[c] += cellStart[c - 1]

        // Scatter particle indices into their sorted slots.
        System.arraycopy(cellStart, 0, cellCursor, 0, cellCount + 1)
        for (i in 0 until count) {
            val c = particleCell[i]
            sortedIndices[cellCursor[c]] = i
            cellCursor[c]++
        }
    }

    internal inline fun forEachNeighbor(x: Float, y: Float, z: Float, action: (Int) -> Unit) {
        val cx = axisCoord(x)
        val cy = axisCoord(y)
        val cz = axisCoord(z)

        for (dz in -1..1) {
            val iz = wrapCell(cz + dz)
            for (dy in -1..1) {
                val iy = wrapCell(cy + dy)
                val rowBase = iy * gridDim + iz * gridDim * gridDim
                for (dx in -1..1) {
                    val ix = wrapCell(cx + dx)
                    val c = ix + rowBase
                    val from = cellStart[c]
                    val to = cellStart[c + 1]
                    for (k in from until to) action(sortedIndices[k])
                }
            }
        }
    }
}
