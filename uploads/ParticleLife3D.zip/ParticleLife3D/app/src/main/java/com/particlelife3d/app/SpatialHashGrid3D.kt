package com.particlelife3d.app

import kotlin.math.floor

/**
 * Uniform 3D spatial hash used to keep neighbor queries local: instead of an
 * O(n^2) scan, each particle only checks the 27 cells (3x3x3) surrounding it.
 * Buckets are kept around across frames and cleared in place (rather than
 * reallocated) to minimize per-frame garbage.
 */
class SpatialHashGrid3D(private val cellSize: Float) {
    private val buckets = HashMap<Long, ArrayList<Int>>()

    fun rebuild(x: FloatArray, y: FloatArray, z: FloatArray, count: Int) {
        for (bucket in buckets.values) bucket.clear()
        for (i in 0 until count) {
            val key = keyFor(x[i], y[i], z[i])
            val existing = buckets[key]
            if (existing != null) {
                existing.add(i)
            } else {
                val fresh = ArrayList<Int>(8)
                fresh.add(i)
                buckets[key] = fresh
            }
        }
    }

    private fun cellCoord(v: Float): Int = floor(v / cellSize).toInt()

    private fun keyFor(x: Float, y: Float, z: Float): Long {
        val ix = (cellCoord(x) + OFFSET).toLong()
        val iy = (cellCoord(y) + OFFSET).toLong()
        val iz = (cellCoord(z) + OFFSET).toLong()
        return ix or (iy shl 20) or (iz shl 40)
    }

    inline fun forEachNeighbor(x: Float, y: Float, z: Float, action: (Int) -> Unit) {
        val cx = cellCoord(x)
        val cy = cellCoord(y)
        val cz = cellCoord(z)
        for (dz in -1..1) {
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val ix = (cx + dx + OFFSET).toLong()
                    val iy = (cy + dy + OFFSET).toLong()
                    val iz = (cz + dz + OFFSET).toLong()
                    val key = ix or (iy shl 20) or (iz shl 40)
                    val bucket = buckets[key] ?: continue
                    for (idx in bucket) action(idx)
                }
            }
        }
    }

    companion object {
        // 2^19 -- large enough to keep packed cell coordinates non-negative
        // for any cell index this simulation will ever produce.
        private const val OFFSET = 524288
    }
}
