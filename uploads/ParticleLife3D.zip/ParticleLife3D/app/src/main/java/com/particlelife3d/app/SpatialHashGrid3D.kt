package com.particlelife3d.app

import kotlin.math.ceil

/**
 * Uniform 3D grid over the simulation's fixed bounding cube, using counting-sort
 * binning instead of a hash map. This avoids two costly things a HashMap<Long,
 * ArrayList<Int>> forces on the hot path: boxing every cell key/particle index,
 * and chasing hash buckets 27 times per particle per frame.
 *
 * Because the domain is bounded, cells map directly to a flat IntArray index
 * (no hashing needed). And because x is the fastest-varying axis in that flat
 * index, cells with consecutive x at a fixed (y,z) land in one contiguous run
 * of `sortedIndices` -- so a 3x3x3 neighbor query costs 9 contiguous-range
 * reads instead of 27 lookups.
 */
class SpatialHashGrid3D(private val cellSize: Float, private val boundsHalfExtent: Float) {

    internal val gridDim = (ceil(2f * boundsHalfExtent / cellSize).toInt() + 1).coerceAtLeast(3)
    private val cellCount = gridDim * gridDim * gridDim

    // cellStart[c] .. cellStart[c+1] is the index range in sortedIndices for cell c.
    internal val cellStart = IntArray(cellCount + 1)
    private val cellCursor = IntArray(cellCount + 1)
    private var particleCell = IntArray(0)
    internal var sortedIndices = IntArray(0)

    internal fun axisCoord(v: Float): Int {
        val c = ((v + boundsHalfExtent) / cellSize).toInt()
        return c.coerceIn(0, gridDim - 1)
    }

    private fun flatIndex(ix: Int, iy: Int, iz: Int) = ix + iy * gridDim + iz * gridDim * gridDim

    fun rebuild(x: FloatArray, y: FloatArray, z: FloatArray, count: Int) {
        if (particleCell.size < count) {
            particleCell = IntArray(count)
            sortedIndices = IntArray(count)
        }
        java.util.Arrays.fill(cellStart, 0)

        // Histogram: count particles per cell (offset by one, so cellStart[c+1]
        // ends up holding cell c's count before the prefix sum below).
        for (i in 0 until count) {
            val c = flatIndex(axisCoord(x[i]), axisCoord(y[i]), axisCoord(z[i]))
            particleCell[i] = c
            cellStart[c + 1]++
        }
        // Prefix sum turns per-cell counts into start offsets.
        for (c in 1..cellCount) cellStart[c] += cellStart[c - 1]

        // Scatter particle indices into their sorted slots.
        System.arraycopy(cellStart, 0, cellCursor, 0, cellCount + 1)
        for (i in 0 until count) {
            val c = particleCell[i]
            sortedIndices[cellCursor[c]] = i
            cellCursor[c]++
        }
    }

    internal inline fun forEachNeighbor(x: Float, y: Float, z: Float, action: (Int) -> Unit) {
        val cx = axisCoord(x)
        val cy = axisCoord(y)
        val cz = axisCoord(z)
        val x0 = (cx - 1).coerceAtLeast(0)
        val x1 = (cx + 1).coerceAtMost(gridDim - 1)
        val y0 = (cy - 1).coerceAtLeast(0)
        val y1 = (cy + 1).coerceAtMost(gridDim - 1)
        val z0 = (cz - 1).coerceAtLeast(0)
        val z1 = (cz + 1).coerceAtMost(gridDim - 1)

        for (iz in z0..z1) {
            for (iy in y0..y1) {
                val rowBase = iy * gridDim + iz * gridDim * gridDim
                val from = cellStart[x0 + rowBase]
                val to = cellStart[x1 + rowBase + 1]
                for (k in from until to) action(sortedIndices[k])
            }
        }
    }
}
