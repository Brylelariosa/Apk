# Add project specific ProGuard rules here.
# Code shrinking is currently disabled (isMinifyEnabled = false); kept for future use.
