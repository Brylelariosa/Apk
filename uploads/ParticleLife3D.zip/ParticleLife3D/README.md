# Particle Life 3D

A 3D particle-life simulation: colored particle species drift through a
wraparound cube, governed by a random attraction/repulsion matrix between
species pairs. Rendered as flat opaque circles (GL_POINTS) with a hard edge,
no glow -- particle interactions accelerated with a counting-sort uniform
grid (flat IntArrays, no boxing, no hash map), which also wraps its neighbor
lookups at the domain edge so clusters can form and drift smoothly across the
boundary instead of stopping at a wall.

## Controls
- **Joystick** (bottom-left): fly forward/back and strafe left/right. Look
  up/down and push forward to climb or dive.
- **Drag with one finger** (anywhere else): look around (yaw/pitch)
- **Hamburger button** (top-left): open/close the control strip
- **Tap the scene**: close the control strip if it's open
- **Dice icon**: new species colors + new interaction rules + fresh particles
- **Circular-arrow icon**: respawn particles under the current rules
- **- / +**: change species count (2-12)
- **Dots icon**: cycle particle count presets (1500 / 3000 / 4500 / 6000 / 8000)
- **Play/Pause icon**: freeze or resume the simulation (camera still moves)

## World
The simulation lives in a fixed-size cube (`boundsHalfExtent` in
`ParticleSystem.kt`) but the boundary is toroidal: particles -- and the
camera -- that cross one face reappear on the opposite face. Combined with
the free-fly camera, this gives an endless-feeling world out of a
computationally finite domain, similar to classic wraparound arcade games,
just in 3D.

## Tuning
Simulation constants live at the top of `ParticleSystem.kt`:
`interactionRadius`, `minRepelRadius`, `friction`, `forceScale`,
`boundsHalfExtent`. If motion looks too chaotic, lower `forceScale` or raise
`friction`; if it looks too static, do the opposite. Flight speed
(`moveSpeed`) lives in `FreeCamera.kt`; point size (`2200f`) and FOV live in
`ParticleRenderer.kt`.

## Architecture
- `ParticleSystem` -- simulation state + physics update (structure-of-arrays),
  minimum-image (wrapped) distance so forces work correctly across the
  boundary seam
- `SpatialHashGrid3D` -- counting-sort uniform grid for O(n) neighbor lookup;
  neighbor cell lookups wrap at the domain edge to match the simulation
- `ParticleRenderer` -- GLSurfaceView.Renderer, uploads a position+color VBO
  every frame and draws GL_POINTS with a flat circular fragment shader;
  blending is only enabled for the translucent reference cube, not the
  (opaque) particles
- `FreeCamera` -- first-person camera: joystick input is applied once per
  frame in `tick()`, look is driven by touch drag, position wraps at the
  domain edge
- `JoystickView` -- small self-contained Canvas-drawn thumbstick
- `MainActivity` -- wires the joystick, touch-look, and hamburger control
  strip; all simulation mutation is marshaled onto the GL thread via
  `glSurfaceView.queueEvent {}`
