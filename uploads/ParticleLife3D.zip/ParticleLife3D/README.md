# Particle Life 3D

A 3D particle-life simulation: colored particle species drift through a bounded
cube, governed by a random attraction/repulsion matrix between species pairs.
Rendered with OpenGL ES 2.0 point sprites and additive glow blending, particle
interactions accelerated with a counting-sort uniform grid (flat IntArrays,
no boxing, no hash map).

## Controls
- **Drag with one finger**: orbit the camera
- **Drag with two fingers**: pan (move the look-at target around)
- **Pinch**: zoom in/out
- **Hamburger button** (top-left): open/close the control strip
- **Tap the scene**: close the control strip if it's open
- **Dice icon**: new species colors + new interaction rules + fresh particles
- **Circular-arrow icon**: respawn particles under the current rules
- **- / +**: change species count (2-12)
- **Dots icon**: cycle particle count presets (1500 / 3000 / 4500 / 6000 / 8000)
- **Play/Pause icon**: freeze or resume the simulation

## Tuning
Simulation constants live at the top of `ParticleSystem.kt`:
`interactionRadius`, `minRepelRadius`, `friction`, `forceScale`. If motion
looks too chaotic, lower `forceScale` or raise `friction`; if it looks too
static, do the opposite. Point size (`2200f`) and camera defaults (distance,
FOV) live in `ParticleRenderer.kt` / `OrbitCamera.kt`.

## Architecture
- `ParticleSystem` -- simulation state + physics update (structure-of-arrays)
- `SpatialHashGrid3D` -- counting-sort uniform grid for O(n) neighbor lookup;
  cells along the x-axis land contiguously in `sortedIndices`, so a 3x3x3
  neighbor query is 9 contiguous-range reads instead of 27 lookups
- `ParticleRenderer` -- GLSurfaceView.Renderer, uploads a position+color VBO
  every frame and draws GL_POINTS with a soft circular fragment shader
- `OrbitCamera` -- spherical camera with orbit, pan, and zoom, all driven by
  touch
- `MainActivity` -- wires touch gestures and the hamburger control strip; all
  simulation mutation is marshaled onto the GL thread via
  `glSurfaceView.queueEvent {}`
