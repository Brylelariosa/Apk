# Particle Life 3D

A 3D particle-life simulation: colored particle species drift through a bounded
cube, governed by a random attraction/repulsion matrix between species pairs.
Rendered with OpenGL ES 2.0 point sprites and additive glow blending, particle
interactions accelerated with a uniform 3D spatial hash grid.

## Controls
- **Drag** (one finger): orbit the camera
- **Pinch**: zoom in/out
- **Tap**: hide/show the UI bars
- **Randomize**: new species colors + new interaction rules + fresh particles
- **Reset**: respawn particles under the current rules
- **- / +**: change species count (2-12)
- **Particles**: cycle particle count presets (1500 / 3000 / 4500 / 6000 / 8000)
- **Pause**: freeze the simulation

## Tuning
Simulation constants live at the top of `ParticleSystem.kt`:
`interactionRadius`, `minRepelRadius`, `friction`, `forceScale`. If motion
looks too chaotic, lower `forceScale` or raise `friction`; if it looks too
static, do the opposite. Point size (`2200f`) and camera defaults (distance,
FOV) live in `ParticleRenderer.kt` / `OrbitCamera.kt`.

## Architecture
- `ParticleSystem` -- simulation state + physics update (structure-of-arrays)
- `SpatialHashGrid3D` -- O(n) neighbor lookup instead of O(n^2)
- `ParticleRenderer` -- GLSurfaceView.Renderer, uploads a position+color VBO
  every frame and draws GL_POINTS with a soft circular fragment shader
- `OrbitCamera` -- spherical camera driven by touch
- `MainActivity` -- wires touch gestures and the control bar; all simulation
  mutation is marshaled onto the GL thread via `glSurfaceView.queueEvent {}`
