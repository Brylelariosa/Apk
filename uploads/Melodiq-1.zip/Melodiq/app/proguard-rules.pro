# Keep Media3 / ExoPlayer
-keep class androidx.media3.** { *; }
-keep class androidx.media3.session.** { *; }
-dontwarn androidx.media3.**

# Keep Retrofit models
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.melodiq.data.network.** { *; }
-keep class retrofit2.** { *; }
-keep class okhttp3.** { *; }

# Keep Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface *
-dontwarn androidx.room.**

# Keep Gson
-keep class com.google.gson.** { *; }
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}

# Keep Hilt
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.HiltAndroidApp class *
-keep @dagger.hilt.android.AndroidEntryPoint class *
-dontwarn dagger.hilt.**

# Keep Coil
-keep class coil.** { *; }
-dontwarn coil.**

# Keep Palette
-keep class androidx.palette.** { *; }

# Kotlin Coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# General
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
