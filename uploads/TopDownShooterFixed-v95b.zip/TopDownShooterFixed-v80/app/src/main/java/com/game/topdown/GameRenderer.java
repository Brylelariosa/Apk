package com.game.topdown;

import android.content.SharedPreferences;
import android.graphics.*;
import android.view.SurfaceHolder;

/**
 * Handles all Canvas rendering for GameView.
 * Instantiated and owned by GameView; accesses game state through the {@code gv} reference.
 */
class GameRenderer {
    final GameView gv;
    GameRenderer(GameView gv) { this.gv = gv; }

    // Local fill() helper to avoid gv. round-trip for paint creation
    private Paint fill(int c) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(c); p.setStyle(Paint.Style.FILL);
        return p;
    }

    /** Called by the game loop to lock canvas, draw, and post. */
    void render() {
        SurfaceHolder holder = gv.getHolder();
        Canvas c = holder.lockCanvas();
        if (c == null) return;
        try { doDraw(c); } finally { holder.unlockCanvasAndPost(c); }
    }


    /** Render all active chakram discs in world space. */
    private void drawVoltChakrams(Canvas c) {
        long now = System.currentTimeMillis();

        // Each disc gets its own per-disc phase so they pulse out of sync
        for (VoltChakram vc : gv.voltChakrams) {
            float cx = vc.x, cy = vc.y;
            float phase = (float)(now / 140.0) + vc.orbitIdx * 2.094f; // 120° apart
            float pulse  = 0.55f + 0.45f * (float) Math.sin(phase);
            float pulse2 = 0.55f + 0.45f * (float) Math.sin(phase * 1.7f + 1.1f);

            boolean orbiting  = vc.state == VoltChakram.ORBITING;
            boolean launched  = vc.state == VoltChakram.LAUNCHED;
            boolean returning = vc.state == VoltChakram.RETURNING;

            // Colour scheme: orbiting = cool electric cyan, launched = hot white-yellow, returning = aqua-green
            int rC, gC, bC;       // core tint
            int rG, gG, bG;       // glow tint
            float discR;          // disc radius
            if (launched) {
                rC = 255; gC = 245; bC = 200;   // white-hot
                rG = 180; gG = 240; bG = 255;
                discR = 13f;
            } else if (returning) {
                rC =  60; gC = 255; bC = 200;   // aqua-green return
                rG =   0; gG = 220; bG = 180;
                discR = 11f;
            } else {
                rC = 160; gC = 230; bC = 255;   // cool cyan orbit
                rG =  80; gG = 180; bG = 255;
                discR = 11f;
            }

            // ── 1. Wide soft outer glow ──────────────────────────────────────
            float glowR1 = discR * 2.6f + pulse * 6f;
            gv.vcOuterGlow.setColor(Color.argb((int)(35 * pulse), rG, gG, bG));
            c.drawCircle(cx, cy, glowR1, gv.vcOuterGlow);

            // ── 2. Mid glow ring ─────────────────────────────────────────────
            float glowR2 = discR * 1.7f + pulse2 * 4f;
            gv.vcMidGlow.setColor(Color.argb((int)(80 * pulse2), rG, gG, bG));
            c.drawCircle(cx, cy, glowR2, gv.vcMidGlow);

            // ── 3. Motion trail (launched & returning) ───────────────────────
            if (!orbiting) {
                float speed = (float) Math.sqrt(vc.vx * vc.vx + vc.vy * vc.vy);
                if (speed > 15f) {
                    float ux = -vc.vx / speed, uy = -vc.vy / speed;
                    int segments = launched ? 10 : 6;
                    float segLen = launched ? Math.min(60f, speed * 0.05f) / segments
                                            : Math.min(30f, speed * 0.03f) / segments;
                    // Slight perpendicular jitter for a crackling lightning-bolt look
                    float px = -uy, py = ux;  // perpendicular
                    for (int t = 0; t < segments; t++) {
                        float tf   = (t + 1f) / segments;
                        float tx   = cx + ux * segLen * (t + 1) * segments;
                        float ty   = cy + uy * segLen * (t + 1) * segments;
                        float jitter = (float)Math.sin(now * 0.041f + t * 1.3f + vc.orbitIdx) * 3f * tf;
                        float rx2  = tx + px * jitter, ry2 = ty + py * jitter;
                        int alpha  = (int)(200 * (1f - tf));
                        float sr   = discR * (1f - tf * 0.7f);
                        gv.vcTrailP.setColor(Color.argb(alpha, rC, gC, bC));
                        c.drawCircle(rx2, ry2, sr, gv.vcTrailP);
                    }
                    // Extra bright core of trail right behind disc
                    gv.vcTrailCore.setColor(Color.argb(160, 255, 255, 255));
                    c.drawCircle(cx + ux * discR, cy + uy * discR, discR * 0.45f, gv.vcTrailCore);
                }
            }

            // ── 4. Chakram blade ring (rotating thin ring with notches) ──────
            //    Two overlapping rings at different spin speeds for a shuriken look
            gv.vcRingP.setColor(Color.argb((int)(210 + 45 * pulse), rC, gC, bC));
            gv.vcRingP.setStrokeWidth(launched ? 3.5f : 2.8f);
            c.drawCircle(cx, cy, discR, gv.vcRingP);

            // Inner ring, counter-rotating
            gv.vcRingP2.setColor(Color.argb((int)(120 * pulse2), rG, gG, bG));
            c.drawCircle(cx, cy, discR * 0.62f, gv.vcRingP2);

            // Spinning blade spokes — 6 blades that rotate
            float spinA = vc.spinAngle;
            gv.vcBladePath.reset();
            for (int i = 0; i < 6; i++) {
                float a    = spinA + (float)(i * Math.PI / 3);
                float aTip = spinA + (float)(i * Math.PI / 3) + 0.38f; // angled tip
                float innerR = discR * 0.28f, outerR2 = discR * 0.92f;
                float ix = cx + innerR * (float)Math.cos(a),        iy = cy + innerR * (float)Math.sin(a);
                float ox = cx + outerR2 * (float)Math.cos(aTip),    oy = cy + outerR2 * (float)Math.sin(aTip);
                gv.vcBladePath.moveTo(ix, iy);
                gv.vcBladePath.lineTo(ox, oy);
            }
            gv.vcBladeP.setStrokeWidth(launched ? 2.2f : 1.8f);
            gv.vcBladeP.setColor(Color.argb((int)(200 + 55 * pulse), rC, gC, bC));
            c.drawPath(gv.vcBladePath, gv.vcBladeP);

            // ── 5. Electric bolt sparks radiating from disc ──────────────────
            int zapCount = orbiting ? 4 : (launched ? 6 : 3);
            float zapSeed = (float)(now / 70.0) + vc.orbitIdx * 3.7f;
            for (int z = 0; z < zapCount; z++) {
                float za      = zapSeed + z * ((float)Math.PI * 2 / zapCount);
                float zapLen  = discR * (0.9f + 0.8f * (float)Math.abs(Math.sin(zapSeed + z * 1.6f)));
                float kinkT   = 0.55f; // where the bolt kinks
                float kinkAng = za + (float)Math.sin(zapSeed * 1.3f + z) * 0.5f;
                float kx = cx + (float)Math.cos(kinkAng) * zapLen * kinkT;
                float ky = cy + (float)Math.sin(kinkAng) * zapLen * kinkT;
                float ex2 = cx + (float)Math.cos(za) * zapLen;
                float ey2 = cy + (float)Math.sin(za) * zapLen;
                int zapAlpha = (int)(180 * pulse * (launched ? 1f : 0.75f));
                gv.vcZapP.setStrokeWidth(launched ? 2f : 1.3f);
                gv.vcZapP.setColor(Color.argb(zapAlpha, 200, 240, 255));
                c.drawLine(cx, cy, kx, ky, gv.vcZapP);   // first segment
                gv.vcZapP.setStrokeWidth(launched ? 1.4f : 1f);
                gv.vcZapP.setColor(Color.argb(zapAlpha / 2, 200, 240, 255));
                c.drawLine(kx, ky, ex2, ey2, gv.vcZapP); // second segment (brighter)
            }

            // ── 6. Hot white core ────────────────────────────────────────────
            float coreR = discR * 0.30f + pulse * 1.5f;
            // Soft white halo around core
            gv.vcCoreHalo.setColor(Color.argb((int)(120 * pulse), rC, gC, bC));
            c.drawCircle(cx, cy, coreR * 2.2f, gv.vcCoreHalo);
            // Solid bright centre
            gv.vcCoreP.setColor(Color.argb(255, 240, 255, 255));
            c.drawCircle(cx, cy, coreR, gv.vcCoreP);

            // ── 7. Orbit connection line back to player (orbiting only) ──────
            if (orbiting) {
                Player owner = (gv.localPlayer != null && gv.localPlayer.id == vc.ownerId)
                        ? gv.localPlayer : gv.remote.get(vc.ownerId);
                if (owner != null) {
                    gv.vcConnP.setColor(Color.argb((int)(55 * pulse), rG, gG, bG));
                    gv.vcConnP.setPathEffect(new android.graphics.DashPathEffect(
                            new float[]{6f, 8f}, (float)(now / 60.0)));
                    c.drawLine(owner.x, owner.y, cx, cy, gv.vcConnP);
                    gv.vcConnP.setPathEffect(null); // reset for next draw
                }
            }
        }
    }

    private void updateBullets(Player lp, float dt){
        Iterator<Bullet> it=gv.bullets.iterator();
        while(it.hasNext()){
            Bullet b=it.next();

            // ── Homing: steer toward nearest enemy ONLY if within 160px and in front 120° cone ──
            if(b.homing){
                float tx=Float.MAX_VALUE, ty=0; float bestDist=Float.MAX_VALUE;
                float curA=(float)Math.atan2(b.dy,b.dx);
                float coneHalf = (float)(Math.PI / 3); // 60 deg each side
                float seekRangeSq = 160f * 160f;       // only home within 160px
                if(lp.alive&&b.ownerId!=lp.id){
                    float d=gv.d2(b.x,b.y,lp.x,lp.y);
                    float ang=(float)Math.atan2(lp.y-b.y,lp.x-b.x);
                    float diff=ang-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                    if(d<seekRangeSq&&Math.abs(diff)<coneHalf&&d<bestDist){bestDist=d;tx=lp.x;ty=lp.y;}
                }
                for(Player rp:gv.remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    float d=gv.d2(b.x,b.y,rp.x,rp.y);
                    float ang=(float)Math.atan2(rp.y-b.y,rp.x-b.x);
                    float diff=ang-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                    if(d<seekRangeSq&&Math.abs(diff)<coneHalf&&d<bestDist){bestDist=d;tx=rp.x;ty=rp.y;}
                }
                if(tx!=Float.MAX_VALUE){
                    float tgtA=(float)Math.atan2(ty-b.y,tx-b.x);
                    float diff=tgtA-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                    // Weak 1.2 rad/s turn — curves toward enemy but still missable
                    float turn=Math.signum(diff)*Math.min(Math.abs(diff),1.2f*dt);
                    float na=curA+turn; float spd=(float)Math.sqrt(b.dx*b.dx+b.dy*b.dy);
                    b.dx=(float)Math.cos(na)*spd; b.dy=(float)Math.sin(na)*spd;
                }
            }

            // ── Move ─────────────────────────────────────────────────────────
            float nx=b.x+b.dx*dt, ny=b.y+b.dy*dt;
            boolean rm=false;

            // ── Boundary ─────────────────────────────────────────────────────
            boolean xOut=nx<0||nx>GameView.MAP_W, yOut=ny<0||ny>GameView.MAP_H;
            if(xOut||yOut){
                if(b.bouncesLeft>0){
                    if(xOut){b.dx=-b.dx;nx=Math.max(0,Math.min(GameView.MAP_W,nx));}
                    if(yOut){b.dy=-b.dy;ny=Math.max(0,Math.min(GameView.MAP_H,ny));}
                    b.bouncesLeft--; b.spawnX=nx; b.spawnY=ny;
                } else { if(b.explosive) doExplosion(b,lp); rm=true; }
            }

            // ── Walls ─────────────────────────────────────────────────────────
            if(!rm&&!b.ghost){
                boolean xB=false,yB=false;
                for(float[] w:GameView.WALLS){
                    if(!xB&&nx>=w[0]&&nx<=w[2]&&b.y>=w[1]&&b.y<=w[3]) xB=true;
                    if(!yB&&b.x>=w[0]&&b.x<=w[2]&&ny>=w[1]&&ny<=w[3]) yB=true;
                }
                if(!xB&&!yB) for(float[] w:GameView.WALLS) if(nx>=w[0]&&nx<=w[2]&&ny>=w[1]&&ny<=w[3]){xB=true;yB=true;break;}
                if(xB||yB){
                    if(b.bouncesLeft>0){
                        if(xB) b.dx=-b.dx; if(yB) b.dy=-b.dy;
                        if(!xB&&!yB){b.dx=-b.dx;b.dy=-b.dy;}
                        b.bouncesLeft--; b.spawnX=b.x; b.spawnY=b.y; nx=b.x; ny=b.y;
                    } else { if(b.explosive) doExplosion(b,lp); rm=true; }
                }
            }

            b.x=nx; b.y=ny;

            // ── Range culling ─────────────────────────────────────────────────
            if(!rm){float rdx=b.x-b.spawnX,rdy=b.y-b.spawnY;
                if(rdx*rdx+rdy*rdy>b.range*b.range){if(b.explosive)doExplosion(b,lp);rm=true;}}
            if(!rm&&System.currentTimeMillis()-b.spawnTime>5000) rm=true;

            // ── Hit detection ─────────────────────────────────────────────────
            if(!rm&&gv.isHost){
                if(lp.alive&&b.ownerId!=lp.id&&gv.d2(b.x,b.y,lp.x,lp.y)<GameView.PR*GameView.PR){
                    if(b.piercing){
                        if(b.hitIds!=null&&!b.hitIds.contains(lp.id)){b.hitIds.add(lp.id);applyBulletDamage(b,lp,null,lp);}
                    } else { rm=true; if(b.explosive) doExplosion(b,lp); else applyBulletDamage(b,lp,null,lp); }
                }
                if((!rm||b.piercing)) for(Player rp:gv.remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    if(gv.d2(b.x,b.y,rp.x,rp.y)<GameView.PR*GameView.PR){
                        if(b.piercing){
                            if(b.hitIds!=null&&!b.hitIds.contains(rp.id)){b.hitIds.add(rp.id);applyBulletDamage(b,lp,rp,lp);}
                        } else { rm=true; if(b.explosive) doExplosion(b,lp); else applyBulletDamage(b,lp,rp,lp); break; }
                    }
                }
            }
            // ── Client-side hit prediction: instant visual feedback ───────────
            // On the client (not host), when a LOCAL bullet overlaps a gv.remote player,
            // flash a hit marker immediately without waiting for server confirmation.
            if(!rm && !gv.isHost && b.ownerId==lp.id){
                for(Player rp:gv.remote.values()){
                    if(!rp.alive) continue;
                    if(gv.d2(b.x,b.y,rp.x,rp.y)<(GameView.PR*1.4f)*(GameView.PR*1.4f)){
                        // Only flash once per bullet-player pair (check hitIds)
                        if(b.hitIds==null) b.hitIds=new java.util.HashSet<>();
                        if(!b.hitIds.contains(rp.id)){
                            b.hitIds.add(rp.id);
                            gv.effects.predictedHitFx.add(new long[]{(long)b.x,(long)b.y,System.currentTimeMillis()});
                        }
                    }
                }
            }
            if(rm) it.remove();
        }
    }

    private void applyBulletDamage(Bullet b, Player lp, Player rp, Player localP){
        Player t=(rp!=null)?rp:lp;
        if(t.isProtected()) return;
        // Being hit breaks stealth
        if(t.isStealthed()) t.skillActiveUntil = 0;
        float dmg=b.damage;
        if(t.isShielded()){float reduced=dmg*0.5f;float abs=Math.min(reduced,t.shieldHp);t.shieldHp-=abs;dmg-=abs;if(t.shieldHp<=0)t.skillActiveUntil=0;}
        t.hp=Math.max(0,t.hp-dmg);
        // ── Apply paint status gv.effects ─────────────────────────────────────────
        long now=System.currentTimeMillis();
        if(b.paintColor==1){ // blue = slow
            t.slowUntil     = Math.max(t.slowUntil, now+b.slowDurationMs);
            t.slowSpeedMult = b.slowSpeedMult;  // per-gun speed mult (was always ignored before)
        } else if(b.paintColor==2){ // green = poison
            t.poisonUntil = Math.max(t.poisonUntil, now+b.poisonDurationMs);
            t.poisonOwnerId    = b.ownerId;
            t.poisonTickDamage = b.poisonTickDamage;
        }
        if (b.hookSpear) {
            t.hookPullFromX  = b.spawnX;
            t.hookPullFromY  = b.spawnY;
            t.hookPullOwnerId = b.ownerId;
            float hdx = t.x - b.spawnX, hdy = t.y - b.spawnY;
            float hitDist = (float)Math.sqrt(hdx*hdx + hdy*hdy);
            long pullDuration = Math.max(600L, (long)(hitDist / StatusEffectConfig.HOOK_PULL_SPEED * 1000f) + 500L);
            t.hookPullUntil  = now + pullDuration;
            t.stunUntil      = now + pullDuration + b.stunBonusMs;
        }
        if(t.hp==0){
            if(rp==null){
                // Remote bullet killed the host's local player
                t.alive=false;gv.deathTime=System.currentTimeMillis();gv.throwingBomb=false;
                gv.addFeed(gv.nameOf(b.ownerId)+" ➜ "+t.name);
                Player k=gv.remote.get(b.ownerId);
                onKill(k, t);
                if(k!=null && b.isSoulReaper){
                    int prevLv = k.guns[20].soulLevel();
                    k.guns[20].killCount++; k.guns[20].applySoulLevel();
                    if(k.guns[20].soulLevel() > prevLv) gv.addFeed("☠ " + k.name + " Soul Surge TIER UP → Tier " + k.guns[20].soulLevel());
                    if(b.soulTier >= 6) doElectricBurst(t.x, t.y, b.ownerId, b.soulTier,
                            b.soulTier >= 8 ? GameView.ECHAIN_MAX_HOPS : 0, lp);
                }
            } else {
                // A bullet killed a gv.remote player
                t.alive=false;gv.deadAtMs.put(t.id,System.currentTimeMillis());
                gv.addFeed(gv.nameOf(b.ownerId)+" ➜ "+t.name);
                if(b.ownerId==localP.id){
                    onKill(localP, t);
                    if(b.isSoulReaper){
                        int prevLv = localP.guns[20].soulLevel();
                        localP.guns[20].killCount++; localP.guns[20].applySoulLevel();
                        if(localP.guns[20].soulLevel() > prevLv) gv.addFeed("☠ Soul Surge TIER UP! → Tier " + localP.guns[20].soulLevel());
                        if(b.soulTier >= 6) doElectricBurst(t.x, t.y, b.ownerId, b.soulTier,
                                b.soulTier >= 8 ? GameView.ECHAIN_MAX_HOPS : 0, lp);
                    }
                } else {
                    Player k=gv.remote.get(b.ownerId);
                    if(k!=null){
                        onKill(k, t);
                        if(b.isSoulReaper){
                            int prevLv = k.guns[20].soulLevel();
                            k.guns[20].killCount++; k.guns[20].applySoulLevel();
                            if(k.guns[20].soulLevel() > prevLv) gv.addFeed("☠ " + k.name + " Soul Surge TIER UP → Tier " + k.guns[20].soulLevel());
                            if(b.soulTier >= 6) doElectricBurst(t.x, t.y, b.ownerId, b.soulTier,
                                    b.soulTier >= 8 ? GameView.ECHAIN_MAX_HOPS : 0, lp);
                        }
                    }
                }
            }
        }
    }

    /** Moves all players that are currently being pulled by a Hook Spear. */
    private void updateHookPulls(float dt) {
        if (!gv.isHost) return;
        applyHookPull(gv.localPlayer, dt);
        for (Player rp : gv.remote.values()) applyHookPull(rp, dt);
    }

    private void applyHookPull(Player p, float dt) {
        if (p == null || !p.alive || !p.isBeingPulled()) return;
        // Keep pull origin locked to caster's current position so target is dragged all the way to them
        Player caster = (gv.localPlayer != null && p.hookPullOwnerId == gv.localPlayer.id)
                ? gv.localPlayer : gv.remote.get(p.hookPullOwnerId);
        if (caster != null) { p.hookPullFromX = caster.x; p.hookPullFromY = caster.y; }
        float dx = p.hookPullFromX - p.x, dy = p.hookPullFromY - p.y;
        float dist = (float) Math.sqrt(dx*dx + dy*dy);
        // Stop pulling when very close to caster (within 2*GameView.PR)
        if (dist < GameView.PR * 2f) { p.hookPullUntil = 0; return; }
        float pullSpd = StatusEffectConfig.HOOK_PULL_SPEED;
        float nx = p.x + (dx/dist) * pullSpd * dt;
        float ny = p.y + (dy/dist) * pullSpd * dt;
        nx = gv.clamp(nx, GameView.PR, GameView.MAP_W-GameView.PR); ny = gv.clamp(ny, GameView.PR, GameView.MAP_H-GameView.PR);
        float[] pos = walls(p.x, p.y, nx, ny); p.x = pos[0]; p.y = pos[1];
    }

    /** Draws a catenary-style bezier rope between two world-space points. */
    private void drawRope(Canvas c, float x1, float y1, float x2, float y2) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx*dx + dy*dy);
        if (len < 2f) return;
        // Mid-point sag: blend perpendicular + downward gravity
        float mx = (x1+x2)*0.5f, my = (y1+y2)*0.5f;
        float perpX = -dy/len, perpY = dx/len;  // unit perpendicular
        float sagAmt = Math.min(len * 0.14f, 45f);
        // Bias sag downward (+y in world) to simulate gravity
        float ctrlX = mx + perpX * sagAmt * 0.3f;
        float ctrlY = my + perpY * sagAmt * 0.3f + sagAmt * 0.8f;
        android.graphics.Path ropePath = new android.graphics.Path();
        ropePath.moveTo(x1, y1);
        ropePath.quadTo(ctrlX, ctrlY, x2, y2);
        // Outer dark shadow
        Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
        outer.setStyle(Paint.Style.STROKE); outer.setStrokeWidth(5f);
        outer.setColor(Color.argb(180, 70, 45, 15));
        outer.setStrokeCap(Paint.Cap.ROUND);
        c.drawPath(ropePath, outer);
        // Inner lighter rope strand
        Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
        inner.setStyle(Paint.Style.STROKE); inner.setStrokeWidth(2.5f);
        inner.setColor(Color.argb(230, 205, 165, 90));
        inner.setStrokeCap(Paint.Cap.ROUND);
        c.drawPath(ropePath, inner);
        // Thin highlight strand for woven look
        Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
        highlight.setStyle(Paint.Style.STROKE); highlight.setStrokeWidth(1f);
        highlight.setColor(Color.argb(120, 255, 220, 140));
        c.drawPath(ropePath, highlight);
    }

    /** Draws pull-phase ropes for all players currently being yanked. Called in world space. */
    private void drawPullRopes(Canvas c) {
        for (Player p : gv.remote.values()) {
            if (!p.alive || !p.isBeingPulled()) continue;
            Player caster = (gv.localPlayer != null && p.hookPullOwnerId == gv.localPlayer.id)
                    ? gv.localPlayer : gv.remote.get(p.hookPullOwnerId);
            float ox = (caster != null) ? caster.x : p.hookPullFromX;
            float oy = (caster != null) ? caster.y : p.hookPullFromY;
            drawMetalChain(c, ox, oy, p.x, p.y);
        }
        // Local player being pulled
        if (gv.localPlayer != null && gv.localPlayer.alive && gv.localPlayer.isBeingPulled()) {
            Player caster = gv.remote.get(gv.localPlayer.hookPullOwnerId);
            float ox = (caster != null) ? caster.x : gv.localPlayer.hookPullFromX;
            float oy = (caster != null) ? caster.y : gv.localPlayer.hookPullFromY;
            drawMetalChain(c, ox, oy, gv.localPlayer.x, gv.localPlayer.y);
        }
    }

    /** Draws chains connecting in-flight hook spear gv.bullets back to their owners. */
    private void drawHookChains(Canvas c) {
        for (Bullet b : gv.bullets) {
            if (!b.hookSpear) continue;
            Player owner = (gv.localPlayer != null && gv.localPlayer.id == b.ownerId)
                    ? gv.localPlayer : gv.remote.get(b.ownerId);
            float ox = (owner != null) ? owner.x : b.spawnX;
            float oy = (owner != null) ? owner.y : b.spawnY;
            drawMetalChain(c, ox, oy, b.x, b.y);
        }
    }

    /**
     * Draws a metallic chain between two world-space points.
     * Links alternate between along-axis and cross-axis to mimic real chain links.
     */
    private void drawMetalChain(Canvas c, float x1, float y1, float x2, float y2) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 6f) return;

        float nx = dx / len, ny = dy / len;   // direction along chain
        float px = -ny, py = nx;               // perpendicular

        // Faint glow along full length
        Paint glowP = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowP.setStyle(Paint.Style.STROKE);
        glowP.setStrokeWidth(10f);
        glowP.setColor(Color.argb(30, 160, 200, 255));
        glowP.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x1, y1, x2, y2, glowP);

        // Chain links
        float linkLen = 16f;
        float halfW   = 4.5f;      // half-width of a cross link
        int linkCount = Math.max(1, (int)(len / linkLen));
        float actualLinkLen = len / linkCount;
        float halfL = actualLinkLen * 0.42f;

        Paint darkP = new Paint(Paint.ANTI_ALIAS_FLAG);
        darkP.setStyle(Paint.Style.STROKE);
        darkP.setStrokeCap(Paint.Cap.ROUND);

        Paint lightP = new Paint(Paint.ANTI_ALIAS_FLAG);
        lightP.setStyle(Paint.Style.STROKE);
        lightP.setStrokeCap(Paint.Cap.ROUND);

        for (int i = 0; i < linkCount; i++) {
            float t = (i + 0.5f) / linkCount;
            float mx = x1 + nx * len * t;
            float my = y1 + ny * len * t;

            if (i % 2 == 0) {
                // Horizontal link (along chain axis)
                float lx0 = mx - nx * halfL, ly0 = my - ny * halfL;
                float lx1 = mx + nx * halfL, ly1 = my + ny * halfL;
                darkP.setStrokeWidth(5.5f);
                darkP.setColor(Color.argb(230, 90, 100, 115));
                c.drawLine(lx0, ly0, lx1, ly1, darkP);
                lightP.setStrokeWidth(2.5f);
                lightP.setColor(Color.argb(200, 210, 220, 240));
                c.drawLine(lx0, ly0, lx1, ly1, lightP);
            } else {
                // Cross link (perpendicular)
                float cx0 = mx - px * halfW, cy0 = my - py * halfW;
                float cx1 = mx + px * halfW, cy1 = my + py * halfW;
                darkP.setStrokeWidth(5.5f);
                darkP.setColor(Color.argb(230, 70, 80, 95));
                c.drawLine(cx0, cy0, cx1, cy1, darkP);
                lightP.setStrokeWidth(2.5f);
                lightP.setColor(Color.argb(180, 190, 200, 220));
                c.drawLine(cx0, cy0, cx1, cy1, lightP);
            }
        }
    }

    private void doDraw(Canvas c){
        c.drawRect(0,0,c.getWidth(),c.getHeight(),gv.bgP);
        c.save();
        c.scale(gv.currentZoom, gv.currentZoom);   // per-weapon camera zoom
        c.translate(-gv.camX,-gv.camY);

        for(float x=0;x<=GameView.MAP_W;x+=120) c.drawLine(x,0,x,GameView.MAP_H,gv.gridP);
        for(float y=0;y<=GameView.MAP_H;y+=120) c.drawLine(0,y,GameView.MAP_W,y,gv.gridP);
        c.drawRect(0,0,GameView.MAP_W,GameView.MAP_H,gv.bdrP);

        for(float[] w:GameView.WALLS) c.drawRect(w[0],w[1],w[2],w[3],gv.wallP);

        // ── Effects drawn BEHIND players (explosions, hit flashes, dash ghost trails)
        gv.effects.drawBehindPlayers(c);

        for(Player p:gv.remote.values()) drawPlayer(c,p,false);
        Player lp=gv.localPlayer;
        if(lp!=null) drawPlayer(c,lp,true);

        // ── Effects drawn IN FRONT of players (crescent appears on top of player body)
        gv.effects.drawInFrontOfPlayers(c);

        // ── Status-effect particles (slow mist, poison fumes, stun arcs — on top of players)
        if (GunConfig.ShowStatusEffectVisuals) gv.effects.drawStatusParticles(c);

        // ── Bullets (drawn on top of all players and gv.effects)
        drawHookChains(c);    // chains connect hook spears to owner (flight phase)
        drawPullRopes(c);     // chains remain visible during pull phase
        gv.effects.drawBullets(c, gv.bullets);

        // Aim line (world-space dashed line) — hidden while a hook spear is in flight
        boolean hookInFlight = false;
        if (lp != null) { for (Bullet b : gv.bullets) { if (b.hookSpear && b.ownerId == lp.id) { hookInFlight = true; break; } } }
        if(lp!=null && lp.alive && !hookInFlight && gv.cachedAimLine){
            float lineLen = 350f;
            float ex = lp.x + (float)Math.cos(lp.angle) * lineLen;
            float ey = lp.y + (float)Math.sin(lp.angle) * lineLen;
            c.drawLine(lp.x,lp.y,ex,ey,gv.ddAimLine); // pre-allocated, no new Paint
        }

        // Draw active bombs (world space)
        long nowDraw = System.currentTimeMillis();
        for (Bomb bomb : gv.activeBombs) {
            // ── Spawn explosion FX once when bomb first detonates ─────────────
            if (bomb.explodedAt > 0 && gv.spawnedBombFx.add(bomb.explodedAt)) {
                gv.effects.spawnBombExplosion(bomb.x, bomb.y);
            }

            if (bomb.isFlashing()) {
                // explosion FX handled by EffectsManager; nothing extra needed here
            } else if (bomb.explodedAt < 0) {
                if (!bomb.hasLanded) {
                    // ── Flying: draw a shadow + emoji to indicate arc ─────────
                    // Shadow grows as bomb approaches max range (shows distance)
                    float travel = (float)Math.sqrt(bomb.traveledSq()) / Bomb.THROW_RANGE;
                    float shadowR = 8f + 22f * travel;
                    Paint shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    shadowP.setStyle(Paint.Style.FILL);
                    shadowP.setColor(Color.argb((int)(120 * (1f - travel * 0.5f)), 0, 0, 0));
                    c.drawCircle(bomb.x, bomb.y, shadowR, shadowP);
                    // Emoji slightly offset upward to simulate height
                    Paint flyP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    flyP.setTextSize(34f); flyP.setTextAlign(Paint.Align.CENTER);
                    float bounce = -(float)Math.sin(travel * Math.PI) * 40f;
                    c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + bounce + 12f, flyP);
                } else {
                    // ── Landed: emoji + pulsing danger ring showing blast radius ─
                    long fuseAge   = nowDraw - bomb.deployTime;
                    float fuseFrac = Math.min(1f, fuseAge / (float) Bomb.FUSE_MS);
                    // pulse rate doubles as fuse runs out
                    float pulse = 0.45f + 0.55f * (float)Math.abs(Math.sin(fuseAge / (200f - fuseFrac * 120f)));
                    int dangerA = (int)(100 + 80 * pulse);
                    Paint dangerFill = new Paint(Paint.ANTI_ALIAS_FLAG);
                    dangerFill.setStyle(Paint.Style.FILL);
                    dangerFill.setColor(Color.argb((int)(dangerA * 0.35f), 255, 50, 0));
                    c.drawCircle(bomb.x, bomb.y, Bomb.RADIUS, dangerFill);
                    Paint dangerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                    dangerRing.setStyle(Paint.Style.STROKE);
                    dangerRing.setStrokeWidth(3f + 2f * pulse);
                    dangerRing.setColor(Color.argb(dangerA, 255, 80, 0));
                    c.drawCircle(bomb.x, bomb.y, Bomb.RADIUS, dangerRing);
                    Paint bombEmojiP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    bombEmojiP.setTextSize(32f); bombEmojiP.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + 12f, bombEmojiP);
                }
            }
        }

        // ── Air Strike ring + orb (joystick-mag maps to target distance) ─────
        if (lp != null && lp.alive && lp.currentGun().bulletAirStrike) {
            boolean aimActive = gv.aimStick != null && gv.aimStick.isActive();
            boolean hasAngle  = !Float.isNaN(gv.asAimAngle);
            boolean reloading = lp.currentGun().reloading;
            if (reloading) {
                // Show greyed-out ring + RELOADING label to signal aim is locked
                Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
                ringP.setStyle(Paint.Style.STROKE); ringP.setStrokeWidth(3f);
                ringP.setColor(Color.argb(80, 180, 180, 180));
                c.drawCircle(lp.x, lp.y, AS_RING_R, ringP);
                Paint lblP = new Paint(Paint.ANTI_ALIAS_FLAG);
                lblP.setColor(Color.argb(200, 220, 100, 100));
                lblP.setTextSize(36f); lblP.setTextAlign(Paint.Align.CENTER);
                c.drawText("RELOADING — CAN'T AIM", lp.x, lp.y - AS_RING_R - 20f, lblP);
            } else if (aimActive && hasAngle) {
                float ringR = AS_RING_R; // fixed size, no pulse

                // Big ring around player
                Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
                ringP.setStyle(Paint.Style.STROKE);
                ringP.setStrokeWidth(3f);
                ringP.setColor(Color.argb(180, 224, 64, 251));
                c.drawCircle(lp.x, lp.y, ringR, ringP);
                c.drawCircle(lp.x, lp.y, ringR, gv.fill(Color.argb(18, 224, 64, 251)));

                // Small orb: distance = gv.asAimMag * ring radius (joystick center = at player)
                float orbDist = gv.asAimMag * ringR;
                float orbX = lp.x + (float)Math.cos(gv.asAimAngle) * orbDist;
                float orbY = lp.y + (float)Math.sin(gv.asAimAngle) * orbDist;
                float ORB_R = 26f;

                // Glow + body + dot
                c.drawCircle(orbX, orbY, ORB_R * 1.7f, gv.fill(Color.argb(70, 224, 64, 251)));
                c.drawCircle(orbX, orbY, ORB_R,         gv.fill(Color.argb(230, 224, 64, 251)));
                c.drawCircle(orbX, orbY, ORB_R * 0.38f, gv.fill(Color.WHITE));

                // Dashed connector: player to orb
                Paint connP = new Paint(Paint.ANTI_ALIAS_FLAG);
                connP.setColor(Color.argb(110, 224, 64, 251));
                connP.setStrokeWidth(2f);
                connP.setPathEffect(new android.graphics.DashPathEffect(new float[]{10f,6f},0f));
                c.drawLine(lp.x, lp.y, orbX, orbY, connP);

                // Strike zone preview: circle showing explosion radius
                float zoneR = GameView.AS_RADIUS * 0.75f; // smaller preview circle
                Paint prevP = new Paint(Paint.ANTI_ALIAS_FLAG);
                prevP.setStyle(Paint.Style.STROKE); prevP.setStrokeWidth(3f);
                prevP.setColor(Color.argb(160, 255, 200, 50));
                c.drawCircle(orbX, orbY, zoneR, prevP);
                c.drawCircle(orbX, orbY, zoneR, gv.fill(Color.argb(25, 255, 200, 50)));
                // Center crosshair on orb
                Paint xhP = new Paint(Paint.ANTI_ALIAS_FLAG);
                xhP.setColor(Color.argb(200, 255, 200, 50)); xhP.setStrokeWidth(2.5f);
                c.drawLine(orbX - 16, orbY, orbX + 16, orbY, xhP);
                c.drawLine(orbX, orbY - 16, orbX, orbY + 16, xhP);
            }
        }

        // Draw Air Strike targets and explosions (world space)
        long asNow = System.currentTimeMillis();
        for (double[] as : gv.airStrikes) {
            float sx = (float) as[0], sy = (float) as[1];
            long trigMs = (long) as[2];
            long flashUntil = (long) as[4];
            boolean exploding = flashUntil > 0L && asNow < flashUntil;
            boolean pending   = asNow < trigMs;

            if (exploding) {
                // Spawn the full bomb-style explosion FX once when detonation starts
                if (gv.spawnedAirStrikeFx.add(flashUntil)) {
                    gv.effects.spawnBombExplosion(sx, sy);
                }
                // (drawing handled by EffectsManager.drawBombExplosions)
            } else if (pending) {
                // Incoming warning: fixed danger ring visible to all players
                float countdown = Math.max(0f, (trigMs - asNow) / (float) GameView.AS_WARNING_MS);
                int ra = (int)(220 * (1f - countdown * 0.4f));
                // Outer danger ring (fixed size)
                Paint dangerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                dangerRing.setStyle(Paint.Style.STROKE); dangerRing.setStrokeWidth(4f);
                dangerRing.setColor(Color.argb(ra, 255, 50, 50));
                c.drawCircle(sx, sy, GameView.AS_RADIUS, dangerRing);
                // Danger gv.fill (gets brighter as time runs out)
                c.drawCircle(sx, sy, GameView.AS_RADIUS, gv.fill(Color.argb((int)(ra * 0.18f), 255, 50, 50)));
                // Warning text above
                Paint warnP = new Paint(Paint.ANTI_ALIAS_FLAG);
                warnP.setTextSize(22f); warnP.setTextAlign(Paint.Align.CENTER);
                warnP.setColor(Color.argb(ra, 255, 80, 80));
                c.drawText("⚠", sx, sy - GameView.AS_RADIUS - 8f, warnP);
                // Inner crosshair
                Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
                cross.setColor(Color.argb(ra, 255, 100, 100)); cross.setStrokeWidth(2f);
                c.drawLine(sx - 12, sy, sx + 12, sy, cross);
                c.drawLine(sx, sy - 12, sx, sy + 12, cross);
            }
        }
        // ── Throw preview arc (world space) ──────────────────────────────────
        if (gv.throwingBomb && lp != null && lp.alive && gv.aimStick != null) {
            float tax = gv.aimStick.getX(), tay = gv.aimStick.getY();
            float tmag = (float) Math.sqrt(tax * tax + tay * tay);
            if (tmag > 0.08f) {
                float landX = lp.x + tax * Bomb.THROW_RANGE;
                float landY = lp.y + tay * Bomb.THROW_RANGE;
                // Dashed trajectory line (pre-allocated paint, no alloc)
                c.drawLine(lp.x, lp.y, landX, landY, gv.ddBombArc);
                // (blast radius preview circles removed)
                // Landing bullseye
                Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotP.setColor(Color.argb(230, 255, 220, 0));
                dotP.setStyle(Paint.Style.FILL);
                c.drawCircle(landX, landY, 10f, dotP);
            }
        }

        // ── Volt Chakrams (drawn in world space, on top of everything) ───────
        drawVoltChakrams(c);

        c.restore();

        drawHUD(c);
    }

    private void drawPlayer(Canvas c, Player p, boolean local){
        // Resolve render position — bots use a visual-only dash interpolation
        float rx = p.x, ry = p.y;
        if (!local) {
            float[] bv = gv.botDashVisual.get(p.id);
            if (bv != null) {
                float bt = Math.min(1f, (float)((System.currentTimeMillis() - EffectsManager.FX_EPOCH) - (long)bv[4]) / EffectsManager.DASH_ANIM_MS);
                float ease = 1f - (1f - bt) * (1f - bt) * (1f - bt);
                rx = bv[0] + (bv[2] - bv[0]) * ease;
                ry = bv[1] + (bv[3] - bv[1]) * ease;
            }
        }
        if(!p.alive){
            // Reuse gv.dpShadow as the death-X paint
            gv.dpShadow.setColor(Color.argb(160,230,50,50));
            gv.dpShadow.setStyle(Paint.Style.STROKE); gv.dpShadow.setStrokeWidth(4f);
            c.drawLine(rx-13,ry-13,rx+13,ry+13,gv.dpShadow);
            c.drawLine(rx+13,ry-13,rx-13,ry+13,gv.dpShadow);
            gv.dpShadow.setStyle(Paint.Style.FILL); // restore
            return;
        }
        // Stealth: gv.remote players are invisible (skip draw); local is translucent
        if (!local && p.isStealthed()) return;
        int stealthAlpha = (local && p.isStealthed()) ? 100 : 255;
        float r=GameView.PR;
        gv.dpShadow.setColor(Color.argb(stealthAlpha*65/255, 0, 0, 0));
        c.drawCircle(rx+4,ry+4,r,gv.dpShadow);
        // Dummies: grey body, no gun line, different name style
        boolean isDummy = gv.dummyIds.contains(p.id);
        if (isDummy) gv.dpBody.setColor(Color.argb(stealthAlpha, 140, 140, 140));
        else if (local) { gv.dpBody.setColor(gv.locP.getColor()); gv.dpBody.setAlpha(stealthAlpha); }
        else            { gv.dpBody.setColor(gv.remP.getColor()); gv.dpBody.setAlpha(stealthAlpha); }
        c.drawCircle(rx,ry,r,gv.dpBody);
        gv.dpBody.setAlpha(255); // restore
        if (!isDummy) {
            float gl=r+20f;
            int barrelCol = p.currentGun().color;
            gv.dpGun.setColor(barrelCol); gv.dpGun.setAlpha(stealthAlpha);
            c.drawLine(rx,ry,rx+(float)Math.cos(p.angle)*gl,ry+(float)Math.sin(p.angle)*gl,gv.dpGun);
            gv.dpGun.setAlpha(255); // restore
        }
        float bw=50f,bh=6f,bx=rx-25f,by=ry-r-14f;
        c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,gv.hpBgP);
        float fr=Math.max(0,p.hp/100f);
        gv.dpHpFill.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
        c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,gv.dpHpFill);
        gv.dpName2.set(gv.nameP); gv.dpName2.setAlpha(stealthAlpha);
        if (isDummy) {
            gv.dpName2.setColor(Color.argb(180, 180, 180, 180));
            gv.dpName2.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        }
        c.drawText(p.name, rx, ry-r-17f, gv.dpName2);
        // Volt Chakram charge arc — drawn around the player when charging
        if (local && gv.isVoltChakram(p.currentGun()) && gv.voltCharge > 0.02f) {
            float sweep = gv.voltCharge * 360f;
            Paint chargePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            chargePaint.setStyle(Paint.Style.STROKE);
            chargePaint.setStrokeWidth(4.5f);
            int chargeAlpha = (int)(180 + gv.voltCharge * 75);
            chargePaint.setColor(Color.argb(chargeAlpha, 100, 220, 255));
            float arcR = r + 14f;
            RectF arcRect = new RectF(rx - arcR, ry - arcR, rx + arcR, ry + arcR);
            c.drawArc(arcRect, -90f, sweep, false, chargePaint);
            // Bright tip dot at the leading edge
            float tipAngle = (float) Math.toRadians(-90f + sweep);
            float tipX = rx + arcR * (float) Math.cos(tipAngle);
            float tipY = ry + arcR * (float) Math.sin(tipAngle);
            Paint tipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            tipPaint.setStyle(Paint.Style.FILL);
            tipPaint.setColor(Color.argb(230, 180, 240, 255));
            c.drawCircle(tipX, tipY, 5f, tipPaint);
        }
        // Shadow Blade charge arc — color shifts per tier; gv.tick marks at T2/T3 thresholds
        if (local && gv.isShadowBlade(p.currentGun()) && gv.shadowBladeCharge > 0.02f) {
            float sweep   = gv.shadowBladeCharge * 360f;
            long  nowSb   = System.currentTimeMillis();
            float sbArcR  = r + 14f;
            RectF sbRect  = new RectF(rx - sbArcR, ry - sbArcR, rx + sbArcR, ry + sbArcR);
            int   sbAlpha = (int)(170 + gv.shadowBladeCharge * 85);

            // Arc color: red (T1) → orange (T2) → white-gold (T3)
            int arcR, arcG, arcB;
            if (gv.shadowBladeCharge < 0.40f) {
                arcR = 255; arcG = 30;  arcB = 70;   // crimson
            } else if (gv.shadowBladeCharge < 0.85f) {
                float t = (gv.shadowBladeCharge - 0.40f) / 0.45f;
                arcR = 255; arcG = (int)(30 + t * 140); arcB = (int)(70 * (1f - t)); // red→orange
            } else {
                float t = (gv.shadowBladeCharge - 0.85f) / 0.15f;
                arcR = 255; arcG = (int)(170 + t * 70); arcB = (int)(t * 120); // orange→gold
            }
            Paint sbCharge = new Paint(Paint.ANTI_ALIAS_FLAG);
            sbCharge.setStyle(Paint.Style.STROKE);
            sbCharge.setStrokeWidth(4.5f);
            sbCharge.setColor(Color.argb(sbAlpha, arcR, arcG, arcB));
            c.drawArc(sbRect, -90f, sweep, false, sbCharge);

            // Tier gv.tick marks at 40% and 85%
            float[] ticks = {0.40f, 0.85f};
            for (float tick : ticks) {
                float tickAngle = (float) Math.toRadians(-90f + tick * 360f);
                float tx = rx + sbArcR * (float) Math.cos(tickAngle);
                float ty = ry + sbArcR * (float) Math.sin(tickAngle);
                Paint tickP = new Paint(Paint.ANTI_ALIAS_FLAG);
                tickP.setStyle(Paint.Style.FILL);
                boolean past = gv.shadowBladeCharge >= gv.tick;
                tickP.setColor(past ? Color.argb(220, 255, 255, 255) : Color.argb(130, 180, 180, 180));
                c.drawCircle(tx, ty, past ? 4.5f : 3f, tickP);
            }

            // Bright tip dot
            float sbTipAngle = (float) Math.toRadians(-90f + sweep);
            float sbTipX = rx + sbArcR * (float) Math.cos(sbTipAngle);
            float sbTipY = ry + sbArcR * (float) Math.sin(sbTipAngle);
            Paint sbTip = new Paint(Paint.ANTI_ALIAS_FLAG);
            sbTip.setStyle(Paint.Style.FILL);
            sbTip.setColor(Color.argb(235, 255, 230, 180));
            c.drawCircle(sbTipX, sbTipY, 5.5f, sbTip);

            // Tier name label below the player — updates in real time as charge builds
            String tierName;
            int    tierR, tierG, tierB;
            if (gv.shadowBladeCharge < 0.40f) {
                tierName = "LIGHT SLASH";  tierR = 255; tierG = 80;  tierB = 100;
            } else if (gv.shadowBladeCharge < 0.85f) {
                tierName = "HEAVY SLASH";  tierR = 255; tierG = 160; tierB = 30;
            } else {
                tierName = "PHANTOM DASH"; tierR = 255; tierG = 220; tierB = 80;
            }
            Paint tierP = new Paint(Paint.ANTI_ALIAS_FLAG);
            tierP.setTextAlign(Paint.Align.CENTER);
            tierP.setTextSize(18f);
            tierP.setTypeface(Typeface.DEFAULT_BOLD);
            tierP.setColor(Color.argb(200, tierR, tierG, tierB));
            c.drawText(tierName, rx, ry + r + sbArcR + 22f, tierP);
        }
        // Spawn protection ring
        if (p.isProtected()) {
            long rem = p.spawnProtectionUntil - System.currentTimeMillis();
            float pulse = 0.7f+0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            gv.dpProtRing.setStrokeWidth(4f*pulse);
            gv.dpProtRing.setColor(Color.argb(Math.min(255,(int)(200*rem/800f)),100,200,255));
            c.drawCircle(rx,ry,(r+10)*pulse,gv.dpProtRing);
        }
        // Shield ring
        if (p.isShielded()) {
            float pulse2 = 0.8f+0.2f*(float)Math.abs(Math.sin(System.currentTimeMillis()/150.0));
            gv.dpShRing.setColor(Color.argb(200,255,200,0));
            c.drawCircle(rx,ry,(r+14)*pulse2,gv.dpShRing);
        }
        // ── Status-effect particle spawning (visuals only — gv.effects always active) ──
        // Circles/rings removed; particles are drawn via gv.effects.drawStatusParticles().
        if (GunConfig.ShowStatusEffectVisuals) {
            if (p.isSlowed())                         gv.effects.spawnSlowParticles(rx, ry, r);
            if (p.isPoisoned())                       gv.effects.spawnPoisonParticles(rx, ry, r);
            if (p.isStunned() || p.isBeingPulled())   gv.effects.spawnStunParticles(rx, ry, r);
        }
    }

    private void drawHUD(Canvas c){
        Player lp=gv.localPlayer;
        // Show connecting screen while waiting for server response (client only)
        if(lp==null){
            if(!gv.isHost){
                float w=gv.screenW, h=gv.screenH;
                c.drawRect(0,0,w,h,gv.fill(Color.argb(180,0,0,0)));
                Paint tp=gv.fill(Color.WHITE); tp.setTextSize(32f); tp.setTextAlign(Paint.Align.CENTER);
                tp.setTypeface(Typeface.DEFAULT_BOLD); tp.setShadowLayer(4f,0,2f,Color.BLACK);
                c.drawText("Connecting to host…", w/2, h/2-20, tp);
                Paint tp2=gv.fill(Color.argb(200,180,210,255)); tp2.setTextSize(18f); tp2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Make sure you're on the host's hotspot", w/2, h/2+24, tp2);
            }
            return;
        }
        float w=gv.screenW, h=gv.screenH;

        // ── HP ────────────────────────────────────────────────────────────────
        c.drawRoundRect(10,10,215,56,8,8,gv.hudBgP);
        gv.hudP.setColor(Color.rgb(255,75,75)); gv.hudP.setTextSize(27f); gv.hudP.setTextAlign(Paint.Align.LEFT);
        c.drawText("♥ "+(int)Math.ceil(lp.hp), 22, 46, gv.hudP);

        // ── Coins ─────────────────────────────────────────────────────────────
        c.drawRoundRect(222,10,355,56,8,8,gv.hudBgP);
        Paint coinP2=gv.fill(Color.rgb(255,210,50)); coinP2.setTextSize(22f);
        coinP2.setTextAlign(Paint.Align.LEFT); coinP2.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("\uD83D\uDCB0 "+lp.coins, 234, 44, coinP2);

        // ── Kill streak badge ──────────────────────────────────────────────────
        if (!gv.singlePlayer && lp.killStreak >= 2) {
            int ksColor;
            if      (lp.killStreak >= 10) ksColor = Color.argb(240, 255, 50,  50);
            else if (lp.killStreak >= 5)  ksColor = Color.argb(240, 255, 140, 20);
            else                          ksColor = Color.argb(240, 255, 210, 30);
            c.drawRoundRect(362,10,490,56,8,8,gv.fill(Color.argb(160,20,10,5)));
            Paint ksPaint = gv.fill(ksColor); ksPaint.setTextSize(21f);
            ksPaint.setTextAlign(Paint.Align.LEFT); ksPaint.setTypeface(Typeface.DEFAULT_BOLD);
            ksPaint.setShadowLayer(3f, 0, 1f, Color.BLACK);
            String bonusPct = "+" + Math.round(lp.killStreak * 3) + "%";
            c.drawText("\uD83D\uDD25" + lp.killStreak + "  " + bonusPct, 374, 43, ksPaint);
        }

        // ── Difficulty / mode badge ────────────────────────────────────────────
        if (gv.singlePlayer) {
            String dlbl;
            int    dcol;
            if (gv.trainingMode) {
                dlbl = "TRAINING"; dcol = 0xFF22aa66;
            } else {
                String[] diffLabels = {"EASY", "NORMAL", "HARD"};
                int[]    diffColors = {0xFF2ecc71, 0xFFe94560, 0xFF8855ee};
                dlbl = diffLabels[Math.max(0, Math.min(2, gv.difficulty))];
                dcol = diffColors[Math.max(0, Math.min(2, gv.difficulty))];
            }
            Paint diffP = gv.fill(dcol); diffP.setTextSize(17f);
            diffP.setTextAlign(Paint.Align.LEFT); diffP.setTypeface(Typeface.DEFAULT_BOLD);
            diffP.setShadowLayer(3f,1f,1f,Color.BLACK);
            float dlblW = diffP.measureText(dlbl);
            c.drawRoundRect(362, 14, 362 + dlblW + 18, 52, 8, 8, gv.fill(Color.argb(140,0,0,0)));
            c.drawText(dlbl, 371, 43, diffP);
        }

        // ── Gun + ammo ────────────────────────────────────────────────────────
        if(lp.alive){
            Gun g=lp.currentGun();
            String ammoStr = g.reloading ? "RELOADING…" : (g.ammo+"/"+g.maxAmmo);
            // Background panel – taller to fit stat bars when shown
            boolean showGunStats = gv.cachedGunStats;
            boolean isSbHud = lp.gunIndex == 21;
            c.drawRoundRect(w/2-195,6,w/2+195,showGunStats?106:(isSbHud?68:52),10,10,gv.hudBgP);
            // Gun name + ammo
            gv.gunTxtP.setColor(g.color);
            c.drawText(g.name+"   "+ammoStr, w/2, 36, gv.gunTxtP);
            // Soul Surge: show tier and kill progress
            if (lp.gunIndex == 20) {
                int lv = g.soulLevel();
                int next = g.soulNextThreshold();
                String[] tierNames = {
                    "☠ DORMANT", "☠ AWAKENED", "☠ PIERCING", "☠ BOUNCING",
                    "☠ SEEKING", "☠ UNSTOPPABLE", "☠ ASCENDANT ★", "☠ AWAKENED ★★", "☠ UNLEASHED ★★★"
                };
                String soulLine = tierNames[Math.min(lv, tierNames.length - 1)]
                        + (next >= 0 ? "   (" + g.killCount + "/" + next + " souls)" : "  MAX POWER");
                Paint soulP = new Paint(Paint.ANTI_ALIAS_FLAG);
                soulP.setTextSize(15f); soulP.setTextAlign(Paint.Align.CENTER);
                int[] tierColors = {
                    0xFF9E9E9E, 0xFFCE93D8, 0xFFBA68C8, 0xFFAB47BC,
                    0xFF8E24AA, 0xFF6A0080, 0xFF4A0060, 0xFFD500F9, 0xFFFFD700
                };
                soulP.setColor(tierColors[Math.min(lv, tierColors.length - 1)]);
                c.drawText(soulLine, w/2f, 50f, soulP);
            }
            // Shadow Blade: show charge bar + tier name in HUD panel
            if (lp.gunIndex == 21) {
                float sbBarW = 320f, sbBarH = 9f;
                float sbBarX = w / 2f - sbBarW / 2f;
                float sbBarY = 48f;

                // Tier colors: crimson T1, orange T2, gold T3
                int sbR, sbG, sbB;
                String sbTierLabel;
                if (gv.shadowBladeCharge < 0.40f) {
                    sbR = 255; sbG = 30;  sbB = 70;
                    sbTierLabel = "LIGHT SLASH";
                } else if (gv.shadowBladeCharge < 0.85f) {
                    float t = (gv.shadowBladeCharge - 0.40f) / 0.45f;
                    sbR = 255; sbG = (int)(30 + t * 140); sbB = (int)(70 * (1f - t));
                    sbTierLabel = "HEAVY SLASH";
                } else {
                    float t = (gv.shadowBladeCharge - 0.85f) / 0.15f;
                    sbR = 255; sbG = (int)(170 + t * 70); sbB = (int)(t * 120);
                    sbTierLabel = "PHANTOM DASH";
                }

                // Bar background
                Paint sbBgP = gv.fill(Color.argb(80, 255, 255, 255));
                c.drawRoundRect(sbBarX, sbBarY, sbBarX + sbBarW, sbBarY + sbBarH, 4, 4, sbBgP);

                // Bar gv.fill (only if charging)
                if (gv.shadowBladeCharge > 0.01f) {
                    Paint sbFillP = gv.fill(Color.argb(220, sbR, sbG, sbB));
                    c.drawRoundRect(sbBarX, sbBarY, sbBarX + sbBarW * gv.shadowBladeCharge, sbBarY + sbBarH, 4, 4, sbFillP);
                }

                // Tier threshold gv.tick marks at 40% and 85%
                float[] sbTicks = {0.40f, 0.85f};
                for (float tick : sbTicks) {
                    float tx = sbBarX + sbBarW * tick;
                    Paint sbTickP = gv.fill(gv.shadowBladeCharge >= tick
                            ? Color.argb(220, 255, 255, 255) : Color.argb(120, 160, 160, 160));
                    c.drawRect(tx - 1f, sbBarY - 2f, tx + 1f, sbBarY + sbBarH + 2f, sbTickP);
                }

                // Tier label (right of bar, colored)
                Paint sbLblP = new Paint(Paint.ANTI_ALIAS_FLAG);
                sbLblP.setTextSize(13f);
                sbLblP.setTextAlign(Paint.Align.CENTER);
                sbLblP.setTypeface(Typeface.DEFAULT_BOLD);
                sbLblP.setColor(gv.shadowBladeCharge > 0.01f
                        ? Color.argb(210, sbR, sbG, sbB) : Color.argb(120, 180, 180, 180));
                c.drawText(gv.shadowBladeCharge > 0.01f ? sbTierLabel : "HOLD AIM TO CHARGE",
                        w / 2f, sbBarY + sbBarH + 14f, sbLblP);
            }
            // Stat bars: DMG | SPD | RANGE | RATE
            if(showGunStats){
            String[] statNames = {"DMG","SPD","RANGE","RATE"};
            float[]  statVals  = {g.statDamage(), g.statSpeed(), g.statRange(), g.statFireRate()};
            int[]    statColors= {0xFFFF5252, 0xFF64B5F6, 0xFF81C784, 0xFFFFD54F};
            float barW=68f, barH=9f, gap=10f;
            float totalW = statNames.length*(barW+gap)-gap;
            float barX = w/2 - totalW/2;
            float barY = 55f;
            for(int si=0;si<statNames.length;si++){
                float sx = barX + si*(barW+gap);
                c.drawRoundRect(sx,barY, sx+barW,barY+barH, 4,4, gv.hudStatBgP);
                gv.tmpRectF.set(sx,barY, sx+barW*statVals[si],barY+barH);
                Paint fp=gv.fill(statColors[si]); // color varies per stat — keep gv.fill() here
                c.drawRoundRect(gv.tmpRectF, 4,4, fp);
                c.drawText(statNames[si], sx, barY+barH+14f, gv.hudStatLblP);
            }
            }
        }

        // ── HOST: show IP so others can join ──────────────────────────────────
        if(gv.isHost && !gv.hostIpDisplay.isEmpty()){
            int count=gv.remote.size()+1;
            String ipLine="Your IP: "+gv.hostIpDisplay+"   Players: "+count;
            float bgW=gv.ipPaint.measureText(ipLine)+24f;
            c.drawRoundRect(w/2-bgW/2,h-52,w/2+bgW/2,h-4,10,10,gv.hudBgP);
            c.drawText(ipLine, w/2, h-14, gv.ipPaint);
        }

        // ── Kill gv.feed ─────────────────────────────────────────────────────────
        gv.hudP.setColor(Color.rgb(255,210,70)); gv.hudP.setTextSize(18f); gv.hudP.setTextAlign(Paint.Align.LEFT);
        synchronized(gv.feed){ for(int i=0;i<gv.feed.size();i++) c.drawText(gv.feed.get(i),12,72+i*24,gv.hudP); }

        // ── Multiplayer scoreboard ─────────────────────────────────────────────
        if (!gv.singlePlayer) {
            // Collect all players: local + gv.remote (excluding bots/dummies)
            java.util.List<Player> sbPlayers = new java.util.ArrayList<>();
            sbPlayers.add(lp);
            for (Player rp : gv.remote.values()) {
                if (!gv.dummyIds.contains(rp.id)) sbPlayers.add(rp);
            }
            // Sort by kills desc, then deaths asc
            sbPlayers.sort((a2, b2) -> a2.kills != b2.kills ? b2.kills - a2.kills : a2.deaths - b2.deaths);

            float sbX = w - 260f, sbY = 14f;
            float rowH = 32f, colW = 260f;
            float headerH = 28f;
            float sbH = headerH + sbPlayers.size() * rowH + 10f;

            // Panel background
            c.drawRoundRect(sbX, sbY, sbX + colW, sbY + sbH, 10, 10,
                    gv.fill(Color.argb(170, 8, 12, 28)));

            // Header row
            gv.hudSbHdrP.setTextAlign(Paint.Align.LEFT);
            c.drawText("PLAYER", sbX + 10f, sbY + 20f, gv.hudSbHdrP);
            gv.hudSbHdrP.setTextAlign(Paint.Align.CENTER);
            c.drawText("K", sbX + colW - 100f, sbY + 20f, gv.hudSbHdrP);
            c.drawText("D", sbX + colW - 65f,  sbY + 20f, gv.hudSbHdrP);
            c.drawText("STRK", sbX + colW - 20f, sbY + 20f, gv.hudSbHdrP);

            // Separator
            Paint sepP = gv.fill(Color.argb(80, 100, 140, 220));
            c.drawRect(sbX + 6f, sbY + headerH, sbX + colW - 6f, sbY + headerH + 1.5f, sepP);

            for (int si = 0; si < sbPlayers.size(); si++) {
                Player sp2 = sbPlayers.get(si);
                float ry = sbY + headerH + 6f + si * rowH;
                boolean isMe = (sp2 == lp);

                // Row highlight for local player
                if (isMe) {
                    c.drawRoundRect(sbX + 4f, ry - 2f, sbX + colW - 4f, ry + rowH - 4f, 6, 6,
                            gv.fill(Color.argb(60, 100, 160, 255)));
                }

                // Streak badge color
                int streakColor;
                if      (sp2.killStreak >= 10) streakColor = Color.argb(255, 255, 80,  80);
                else if (sp2.killStreak >= 5)  streakColor = Color.argb(255, 255, 160, 30);
                else if (sp2.killStreak >= 3)  streakColor = Color.argb(255, 255, 220, 50);
                else                           streakColor = Color.argb(180, 180, 180, 180);

                gv.hudSbNameP.setColor(isMe ? Color.WHITE : Color.argb(210, 200, 210, 230));
                gv.hudSbNameP.setTypeface(isMe ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
                // Truncate long names
                String dname = sp2.name.length() > 10 ? sp2.name.substring(0, 10) + "…" : sp2.name;
                c.drawText(dname, sbX + 10f, ry + 20f, gv.hudSbNameP);

                // Kills (green tint)
                gv.hudSbNumP.setColor(Color.argb(230, 100, 255, 120));
                c.drawText(String.valueOf(sp2.kills), sbX + colW - 100f, ry + 20f, gv.hudSbNumP);
                // Deaths (red tint)
                gv.hudSbNumP.setColor(Color.argb(200, 255, 110, 110));
                c.drawText(String.valueOf(sp2.deaths), sbX + colW - 65f, ry + 20f, gv.hudSbNumP);
                // Streak (colored by level)
                gv.hudSbNumP.setColor(streakColor);
                String streakTxt = sp2.killStreak > 0 ? "🔥" + sp2.killStreak : "-";
                c.drawText(streakTxt, sbX + colW - 20f, ry + 20f, gv.hudSbNumP);
            }
        }

        // ── Disconnect overlay ─────────────────────────────────────────────────
        if(!gv.singlePlayer && !gv.isHost && gv.net!=null && gv.net.isDisconnected()){
            // Pulsing amber banner across the top
            long now2=System.currentTimeMillis();
            int pulse=(int)(180+75*Math.abs(Math.sin(now2/500.0)));
            Paint discBg=gv.fill(Color.argb(Math.min(255,pulse),120,40,0));
            c.drawRoundRect(w*0.1f,14,w*0.9f,66,12,12,discBg);
            Paint discTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            discTxt.setColor(Color.WHITE); discTxt.setTextSize(22f);
            discTxt.setTextAlign(Paint.Align.CENTER);
            discTxt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            discTxt.setShadowLayer(4f,0,1f,Color.BLACK);
            c.drawText("\u26A0 DISCONNECTED \u2014 Reconnecting\u2026",w/2,48,discTxt);
        }

        // ── Death overlay ─────────────────────────────────────────────────────
        if(!lp.alive){
            c.drawRect(0,0,w,h,gv.deathBgP);
            c.drawText("YOU DIED",w/2,h/2-18,gv.deathTxtP);
            long rem=GameView.RESPAWN_MS-(System.currentTimeMillis()-gv.deathTime);
            if(rem>0){
                Paint t2=new Paint(gv.deathTxtP); t2.setTextSize(28f); t2.setColor(Color.WHITE);
                t2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,t2);
            }
        }

        // ── Buttons ───────────────────────────────────────────────────────────
        // Weapon wheel — gear icon circle
        { float _scx=gv.switchRect.centerX(), _scy=gv.switchRect.centerY(), _sr=gv.switchRect.width()/2f;
          c.drawCircle(_scx, _scy, _sr, gv.btnP);
          Paint _gp = new Paint(gv.btnTxtP); _gp.setTextSize(_sr * 0.70f);
          c.drawText("⚙", _scx, _scy + _sr*0.25f, _gp); }

        // Reload button — icon only (no text), shows reload arc progress when reloading
        { boolean asLocked = lp != null && lp.currentGun().bulletAirStrike;
          float _rcx = gv.reloadRect.centerX(), _rcy = gv.reloadRect.centerY();
          float _rr = Math.min(gv.reloadRect.width(), gv.reloadRect.height()) / 2f;
          if (asLocked) {
              c.drawCircle(_rcx, _rcy, _rr, gv.fill(Color.argb(70, 55, 55, 65)));
              Paint lockP = new Paint(Paint.ANTI_ALIAS_FLAG);
              lockP.setTextSize(_rr * 1.05f); lockP.setTextAlign(Paint.Align.CENTER);
              lockP.setColor(Color.argb(110, 190, 190, 190));
              c.drawText("\uD83D\uDD12", _rcx, _rcy + _rr * 0.38f, lockP);
          } else if (lp != null && lp.currentGun().reloading) {
              // Show cool progress arc while reloading
              long elapsed = System.currentTimeMillis() - (lp.currentGun().reloadStart);
              float effectiveReloadMs = lp.currentGun().reloadMs * lp.reloadMult();
              float progress = Math.min(1f, elapsed / effectiveReloadMs);
              c.drawCircle(_rcx, _rcy, _rr, gv.fill(Color.argb(120, 40, 40, 60)));
              Paint arcBgP = new Paint(Paint.ANTI_ALIAS_FLAG);
              arcBgP.setStyle(Paint.Style.STROKE); arcBgP.setStrokeWidth(5f);
              arcBgP.setColor(Color.argb(80, 200, 200, 255)); arcBgP.setStrokeCap(Paint.Cap.ROUND);
              android.graphics.RectF arcRect = new android.graphics.RectF(_rcx-_rr+4, _rcy-_rr+4, _rcx+_rr-4, _rcy+_rr-4);
              c.drawArc(arcRect, -90f, 360f, false, arcBgP);
              Paint arcP = new Paint(arcBgP);
              arcP.setColor(Color.argb(230, 100, 200, 255));
              c.drawArc(arcRect, -90f, 360f * progress, false, arcP);
              Paint rldIconP = new Paint(Paint.ANTI_ALIAS_FLAG);
              rldIconP.setTextSize(_rr * 0.90f); rldIconP.setTextAlign(Paint.Align.CENTER);
              rldIconP.setColor(Color.argb(200, 100, 200, 255));
              c.drawText("↺", _rcx, _rcy + _rr * 0.35f, rldIconP);
          } else {
              c.drawCircle(_rcx, _rcy, _rr, gv.btnP);
              Paint rldIconP = new Paint(Paint.ANTI_ALIAS_FLAG);
              rldIconP.setTextSize(_rr * 1.0f); rldIconP.setTextAlign(Paint.Align.CENTER);
              rldIconP.setColor(Color.WHITE); rldIconP.setTypeface(Typeface.DEFAULT_BOLD);
              rldIconP.setShadowLayer(3f, 0, 1f, Color.BLACK);
              c.drawText("↺", _rcx, _rcy + _rr * 0.38f, rldIconP);
          }
        }

        // Bomb button — circle with count badge
        if (gv.bombRect != null && lp != null) {
            boolean hasBombs = lp.bombs > 0;
            float _bcx = gv.bombRect.centerX(), _bcy = gv.bombRect.centerY();
            float _br = Math.min(gv.bombRect.width(), gv.bombRect.height()) / 2f;
            Paint bombBtnP;
            if (gv.throwingBomb) {
                bombBtnP = gv.fill(Color.argb(230, 220, 160, 0));
            } else {
                bombBtnP = gv.fill(hasBombs ? Color.argb(210, 200, 80, 0) : Color.argb(120, 60, 60, 60));
            }
            c.drawCircle(_bcx, _bcy, _br, bombBtnP);
            // Bomb emoji icon
            Paint bombIconP = new Paint(Paint.ANTI_ALIAS_FLAG);
            bombIconP.setTextSize(_br * 1.05f); bombIconP.setTextAlign(Paint.Align.CENTER);
            c.drawText(gv.throwingBomb ? "✕" : "\uD83D\uDCA3", _bcx, _bcy + _br * 0.38f, bombIconP);
            // Count badge (top-right corner of circle)
            if (!gv.throwingBomb && lp.bombs > 0) {
                float badgeX = _bcx + _br * 0.65f, badgeY = _bcy - _br * 0.65f;
                c.drawCircle(badgeX, badgeY, _br * 0.34f, gv.fill(Color.argb(230, 50, 50, 50)));
                Paint badgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
                badgeP.setTextSize(_br * 0.42f); badgeP.setTextAlign(Paint.Align.CENTER);
                badgeP.setColor(Color.WHITE); badgeP.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(String.valueOf(lp.bombs), badgeX, badgeY + _br * 0.14f, badgeP);
            }
            // AIM hint
            if (gv.throwingBomb) {
                Paint hintP = gv.fill(Color.argb(200, 255, 230, 100));
                hintP.setTextSize(16f); hintP.setTextAlign(Paint.Align.CENTER);
                hintP.setShadowLayer(3f, 0, 1f, Color.BLACK);
                c.drawText("aim joystick \u2192 release", _bcx, gv.bombRect.top - 8f, hintP);
            }
        }

        // Drop weapon button — trash icon
        if (gv.dropRect != null && lp != null) {
            int unlockedCount = 0;
            for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
            boolean canDrop = unlockedCount > 1;
            float _dcx = gv.dropRect.centerX(), _dcy = gv.dropRect.centerY();
            float _dr = Math.min(gv.dropRect.width(), gv.dropRect.height()) / 2f;
            c.drawCircle(_dcx, _dcy, _dr, gv.fill(canDrop ? Color.argb(200, 140, 40, 40) : Color.argb(80, 60, 60, 60)));
            Paint dropIconP = new Paint(Paint.ANTI_ALIAS_FLAG);
            dropIconP.setTextSize(_dr * 1.0f); dropIconP.setTextAlign(Paint.Align.CENTER);
            dropIconP.setColor(canDrop ? Color.WHITE : Color.argb(120, 180, 180, 180));
            dropIconP.setShadowLayer(2f, 0, 1f, Color.BLACK);
            c.drawText("\uD83D\uDDD1", _dcx, _dcy + _dr * 0.38f, dropIconP);
        }

        // Paint mode button — only visible when Paint Launcher is equipped
        if (gv.paintModeRect != null && lp != null && lp.gunIndex == 15) {
            Gun pg = lp.currentGun();
            int pm = pg.paintMode; // 0=ALT, 1=SLOW, 2=POISON
            int[] pmColors = { Color.argb(220,0,188,212), Color.argb(220,30,100,220), Color.argb(220,30,180,70) };
            String[] pmEmoji  = { "🎨", "🐌", "☠" };
            String[] pmLabels = { "ALT", "SLOW", "POISON" };
            Paint pmBtnP = gv.fill(pmColors[pm]);
            float _pmcx = gv.paintModeRect.centerX(), _pmcy = gv.paintModeRect.centerY();
            float _pmr = Math.min(gv.paintModeRect.width(), gv.paintModeRect.height()) / 2f;
            c.drawCircle(_pmcx, _pmcy, _pmr, pmBtnP);
            // Icon line
            Paint pmIconP = new Paint(Paint.ANTI_ALIAS_FLAG);
            pmIconP.setColor(Color.WHITE); pmIconP.setTextSize(20f);
            pmIconP.setTextAlign(Paint.Align.CENTER);
            pmIconP.setTypeface(Typeface.DEFAULT_BOLD);
            pmIconP.setShadowLayer(3f, 0, 1f, Color.BLACK);
            c.drawText(pmEmoji[pm], _pmcx, _pmcy - 5f, pmIconP);
            // Label line
            Paint pmLblP = new Paint(Paint.ANTI_ALIAS_FLAG);
            pmLblP.setColor(Color.WHITE); pmLblP.setTextSize(13f);
            pmLblP.setTextAlign(Paint.Align.CENTER);
            pmLblP.setTypeface(Typeface.DEFAULT_BOLD);
            pmLblP.setShadowLayer(2f, 0, 1f, Color.BLACK);
            c.drawText(pmLabels[pm], _pmcx, _pmcy + _pmr - 8f, pmLblP);
        }

        // Active skill button
        if (gv.skillRect != null && lp != null) {
            drawSkillButton(c, lp);
        }

        // Spawn protection pulsing shield ring (screen-space around player circle)
        if (lp != null && lp.alive && lp.isProtected()) {
            long rem = lp.spawnProtectionUntil - System.currentTimeMillis();
            float pulse = 0.7f + 0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            float alpha = Math.min(1f, rem/800f);
            // Draw in screen centre (player is always at centre of screen)
            float cx2 = gv.screenW/2f, cy2 = gv.screenH/2f;
            Paint protP = new Paint(Paint.ANTI_ALIAS_FLAG);
            protP.setStyle(Paint.Style.STROKE); protP.setStrokeWidth(5f*pulse);
            protP.setColor(Color.argb((int)(200*alpha),100,200,255));
            c.drawCircle(cx2, cy2, (GameView.PR*gv.currentZoom+18)*pulse, protP);
            // Timer text
            Paint protTxt = gv.fill(Color.argb((int)(230*alpha),120,220,255));
            protTxt.setTextSize(16f); protTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("🛡 "+(rem/1000+1)+"s", cx2, cy2-(GameView.PR*gv.currentZoom+32), protTxt);
        }

        // ── Gear button ───────────────────────────────────────────────────────
        if(gv.gearRect!=null){
            Paint gearBg=gv.fill(Color.argb(gv.settingsOpen?210:140,40,50,80));
            c.drawRoundRect(gv.gearRect,10,10,gearBg);
            Paint gearTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            gearTxt.setColor(Color.WHITE); gearTxt.setTextSize(26f);
            gearTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("⚙",gv.gearRect.centerX(),gv.gearRect.centerY()+10,gearTxt);
        }

        // ── Shop button ───────────────────────────────────────────────────────
        if(gv.shopBtn!=null){
            Paint sbP=gv.fill(Color.argb(gv.shopOpen?210:150,160,120,10));
            c.drawRoundRect(gv.shopBtn,10,10,sbP);
            Paint sTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            sTxt.setColor(Color.WHITE); sTxt.setTextSize(22f); sTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("\uD83D\uDED2",gv.shopBtn.centerX(),gv.shopBtn.centerY()+9,sTxt);
        }

        // ── Joysticks ─────────────────────────────────────────────────────────
        if(gv.moveStick!=null) gv.moveStick.draw(c);
        if(gv.aimStick!=null)  gv.aimStick.draw(c);

        // ── Button-move mode overlay ───────────────────────────────────────────
        if(gv.btnMoveMode){
            Paint dimP = gv.fill(Color.argb(120,0,0,0));
            c.drawRect(0,0,w,h,dimP);
            // Redraw buttons with highlight — selected button glows differently
            Paint hlP    = gv.fill(Color.argb(220,80,160,255));
            Paint hlSelP = gv.fill(Color.argb(240,255,190,40)); // gold = currently selected for sizing
            boolean sizing = gv.btnSizingId != -1;
            if(gv.switchRect!=null){
                Paint p2 = (sizing && gv.btnSizingId==0) ? hlSelP : hlP;
                float _scx=gv.switchRect.centerX(),_scy=gv.switchRect.centerY(),_sr=gv.switchRect.width()/2f;
                c.drawCircle(_scx,_scy,_sr,p2);
                Paint _gp2=new Paint(gv.btnTxtP); _gp2.setTextSize(_sr*0.70f);
                c.drawText("⚙",_scx,_scy+_sr*0.25f,_gp2);
            }
            if(gv.reloadRect!=null){
                Paint p2 = (sizing && gv.btnSizingId==1) ? hlSelP : hlP;
                float _rcx=gv.reloadRect.centerX(),_rcy=gv.reloadRect.centerY(),_rr=Math.min(gv.reloadRect.width(),gv.reloadRect.height())/2f;
                c.drawCircle(_rcx,_rcy,_rr,p2);
                Paint _rip=new Paint(Paint.ANTI_ALIAS_FLAG); _rip.setTextSize(_rr*1.0f); _rip.setTextAlign(Paint.Align.CENTER); _rip.setColor(Color.WHITE);
                c.drawText("↺",_rcx,_rcy+_rr*0.38f,_rip);
            }
            if(gv.dropRect!=null) {
                float _dcx=gv.dropRect.centerX(),_dcy=gv.dropRect.centerY(),_dr=Math.min(gv.dropRect.width(),gv.dropRect.height())/2f;
                c.drawCircle(_dcx,_dcy,_dr,hlP);
                Paint _dip=new Paint(Paint.ANTI_ALIAS_FLAG); _dip.setTextSize(_dr*1.0f); _dip.setTextAlign(Paint.Align.CENTER); _dip.setColor(Color.WHITE);
                c.drawText("\uD83D\uDDD1",_dcx,_dcy+_dr*0.38f,_dip);
            }
            if(gv.bombRect!=null) {
                float _bcx=gv.bombRect.centerX(),_bcy=gv.bombRect.centerY(),_br=Math.min(gv.bombRect.width(),gv.bombRect.height())/2f;
                c.drawCircle(_bcx,_bcy,_br,hlP);
                Paint _bip=new Paint(Paint.ANTI_ALIAS_FLAG); _bip.setTextSize(_br*1.0f); _bip.setTextAlign(Paint.Align.CENTER);
                c.drawText("\uD83D\uDCA3",_bcx,_bcy+_br*0.38f,_bip);
            }
            if(gv.paintModeRect!=null) {
                float _pmcx=gv.paintModeRect.centerX(),_pmcy=gv.paintModeRect.centerY(),_pmr=Math.min(gv.paintModeRect.width(),gv.paintModeRect.height())/2f;
                c.drawCircle(_pmcx,_pmcy,_pmr,gv.fill(Color.argb(200,0,188,212))); c.drawText("🎨",_pmcx,_pmcy+8,gv.btnTxtP);
            }
            if(gv.skillRect!=null) {
                Paint p2 = (sizing && gv.btnSizingId==5) ? hlSelP : hlP;
                float _scx=gv.skillRect.centerX(),_scy=gv.skillRect.centerY(),_sr=gv.skillRect.width()/2f;
                c.drawCircle(_scx, _scy, _sr, p2);
                Paint _st = new Paint(gv.btnTxtP); _st.setTextSize(_sr*0.38f);
                c.drawText("SKILL", _scx, _scy+8, _st);
            }
            if(gv.shopBtn!=null){
                c.drawRoundRect(gv.shopBtn,10,10,hlP);
                Paint sTmp=new Paint(Paint.ANTI_ALIAS_FLAG); sTmp.setColor(Color.WHITE); sTmp.setTextSize(22f); sTmp.setTextAlign(Paint.Align.CENTER);
                c.drawText("\uD83D\uDED2",gv.shopBtn.centerX(),gv.shopBtn.centerY()+9,sTmp);
            }
                // Instruction label
            Paint infoP = gv.fill(Color.WHITE); infoP.setTextSize(20f); infoP.setTextAlign(Paint.Align.CENTER);
            infoP.setShadowLayer(3f,0,2f,Color.BLACK);
            c.drawText(sizing ? "Drag slider to resize  |  Drag button to move" : "Drag to move  |  Tap button to resize", w/2, h/2 - 20, infoP);

            // ── Training buttons (shown in move mode so they can be repositioned) ──
            if (gv.trainingMode) {
                Paint thlP = gv.fill(Color.argb(220, 100, 200, 130));
                String[] tLabels = {"+ Dummy", "- Dummy", "+200 Coins"};
                RectF[]  tRects  = {gv.trainAddDummyBtn, gv.trainRemDummyBtn, gv.trainAddMoneyBtn};
                for (int i = 0; i < tRects.length; i++) {
                    if (tRects[i] == null) continue;
                    c.drawRoundRect(tRects[i], 10, 10, thlP);
                    c.drawText(tLabels[i], tRects[i].centerX(), tRects[i].centerY()+8, gv.btnTxtP);
                }
            }

            // ── Size slider (shown when a button is tapped) ───────────────────
            if(sizing && gv.sizeSliderTrack != null) {
                // Derive current scale for label
                float curScale = 0.4f + gv.sizeSliderVal * 1.8f;
                String btnName = gv.btnSizingId==0 ? "⚙ WHEEL" : (gv.btnSizingId==1 ? "RELOAD" : "SKILL");
                Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
                labelP.setColor(Color.argb(220,255,220,80)); labelP.setTextSize(19f);
                labelP.setTextAlign(Paint.Align.CENTER); labelP.setShadowLayer(3f,0,2f,Color.BLACK);
                c.drawText(btnName + "  SIZE: " + (int)(curScale*100) + "%",
                        gv.sizeSliderTrack.centerX(), gv.sizeSliderTrack.top - 14f, labelP);
                // Track background
                Paint trackBg = gv.fill(Color.argb(180,30,40,80));
                c.drawRoundRect(gv.sizeSliderTrack, 16f, 16f, trackBg);
                // Filled portion
                float knobX = gv.sizeSliderTrack.left + gv.sizeSliderVal * gv.sizeSliderTrack.width();
                RectF filled = new RectF(gv.sizeSliderTrack.left, gv.sizeSliderTrack.top, knobX, gv.sizeSliderTrack.bottom);
                Paint fillP = gv.fill(Color.argb(220,80,180,255));
                c.drawRoundRect(filled, 16f, 16f, fillP);
                // Knob
                Paint knobP = gv.fill(Color.argb(255,255,255,255));
                c.drawCircle(knobX, gv.sizeSliderTrack.centerY(), gv.sizeSliderTrack.height()*0.82f, knobP);
                // Min / Max labels
                Paint mmP = new Paint(Paint.ANTI_ALIAS_FLAG);
                mmP.setColor(Color.argb(180,200,200,200)); mmP.setTextSize(15f);
                mmP.setTextAlign(Paint.Align.LEFT);
                c.drawText("40%", gv.sizeSliderTrack.left + 4, gv.sizeSliderTrack.bottom + 18f, mmP);
                mmP.setTextAlign(Paint.Align.RIGHT);
                c.drawText("220%", gv.sizeSliderTrack.right - 4, gv.sizeSliderTrack.bottom + 18f, mmP);
            }

            // Confirm button
            if(gv.confirmMoveRect!=null){
                Paint confP = gv.fill(Color.argb(230,50,190,90));
                c.drawRoundRect(gv.confirmMoveRect,12,12,confP);
                Paint confTxt = new Paint(gv.btnTxtP); confTxt.setTextSize(24f);
                c.drawText("✓  DONE", gv.confirmMoveRect.centerX(), gv.confirmMoveRect.centerY()+9, confTxt);
            }
        }

        // ── Weapon wheel overlay ──────────────────────────────────────────────
        if(gv.wheelOpen) drawWeaponWheel(c);

        // ── Settings overlay ──────────────────────────────────────────────────
        if(gv.settingsOpen) drawSettings(c);

        // ── Per-gun Release Fire overlay ──────────────────────────────────────
        if(gv.relFireOpen) drawRelFirePanel(c);

        // ── Shop overlay ──────────────────────────────────────────────────────
        if(gv.shopOpen) drawShop(c);

        // ── Training overlay ──────────────────────────────────────────────────
        if(gv.trainingMode) drawTrainingHUD(c);
    }

    // ═══ TRAINING HUD ════════════════════════════════════════════════════════
    private void drawTrainingHUD(Canvas c) {
        if (gv.trainAddDummyBtn == null) return;

        // Label
        Paint labelP = gv.fill(Color.argb(200, 180, 230, 255));
        labelP.setTextSize(14f); labelP.setTextAlign(Paint.Align.RIGHT);
        labelP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("TRAINING RANGE", gv.trainAddDummyBtn.right, gv.trainAddDummyBtn.top - 6f, labelP);

        // Dummy count indicator
        String dCnt = gv.dummyIds.size() + "/" + GameView.MAX_DUMMIES + " dummies";
        Paint cntP = gv.fill(Color.argb(180, 200, 200, 200));
        cntP.setTextSize(12f); cntP.setTextAlign(Paint.Align.RIGHT);
        c.drawText(dCnt, gv.trainAddDummyBtn.right, gv.trainRemDummyBtn.bottom + 16f, cntP);

        // Button data: rect, label, bg color
        RectF[]  rects  = { gv.trainAddDummyBtn, gv.trainRemDummyBtn, gv.trainAddMoneyBtn };
        String[] labels = { "+ Dummy", "- Dummy", "+200 Coins" };
        int[]    colors = { 0xFF2a6faa, 0xFF7a3030, 0xFF2a8a50 };

        gv.btnP  = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint txtP  = gv.fill(Color.WHITE);
        txtP.setTextSize(15f); txtP.setTextAlign(Paint.Align.CENTER);
        txtP.setTypeface(Typeface.DEFAULT_BOLD);

        for (int i = 0; i < rects.length; i++) {
            RectF r = rects[i];
            boolean canAdd = (i == 0 && gv.dummyIds.size() >= GameView.MAX_DUMMIES);
            int col = canAdd ? Color.argb(120, 60, 80, 60) : colors[i];
            gv.btnP.setColor(Color.argb(210, Color.red(col), Color.green(col), Color.blue(col)));
            gv.btnP.setStyle(Paint.Style.FILL);
            c.drawRoundRect(r, 10, 10, gv.btnP);
            gv.btnP.setColor(Color.argb(120, 255, 255, 255));
            gv.btnP.setStyle(Paint.Style.STROKE); gv.btnP.setStrokeWidth(1.5f);
            c.drawRoundRect(r, 10, 10, gv.btnP);
            c.drawText(labels[i], r.centerX(), r.centerY() + 6f, txtP);
        }
    }

    // ═══ SKILL BUTTON ════════════════════════════════════════════════════════
    private void drawSkillButton(Canvas c, Player lp) {
        if (gv.skillRect == null) return;

        // ── Shadow Blade: show Quick Slash button instead of normal skill ─────
        if (gv.isShadowBlade(lp.currentGun())) {
            long now = System.currentTimeMillis();
            long rem = Math.max(0L, gv.quickSlashCdEnd - now);
            boolean onCd = rem > 0;
            float cx = gv.skillRect.centerX(), cy = gv.skillRect.centerY(), r = gv.skillRect.width() / 2f;

            int btnColor = onCd ? Color.argb(150,60,60,80) : Color.argb(220,140,0,200);
            c.drawCircle(cx, cy, r, gv.fill(btnColor));

            Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG);
            borderP.setStyle(Paint.Style.STROKE); borderP.setStrokeWidth(3f);
            borderP.setColor(Color.argb(200, 210, 120, 255));
            c.drawCircle(cx, cy, r, borderP);

            if (onCd) {
                float frac = Math.max(0f, Math.min(1f, (float)rem / 1000L));
                c.drawCircle(cx, cy, r, gv.fill(Color.argb(130,0,0,0)));
                Paint arcP = new Paint(Paint.ANTI_ALIAS_FLAG);
                arcP.setColor(Color.argb(160,140,0,200)); arcP.setStyle(Paint.Style.FILL);
                c.drawArc(new RectF(cx-r, cy-r, cx+r, cy+r), -90f, 360f*(1f-frac), true, arcP);
                c.drawCircle(cx, cy, r, borderP);
                Paint cdTxt = gv.fill(Color.argb(220,255,200,0));
                cdTxt.setTextSize(r*0.45f); cdTxt.setTextAlign(Paint.Align.CENTER);
                cdTxt.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(String.format(java.util.Locale.US, "%.1f", rem/1000f), cx, cy+r*0.17f, cdTxt);
            } else {
                // Ready — show slash icon
                Paint iconP = new Paint(Paint.ANTI_ALIAS_FLAG);
                iconP.setTextSize(r*0.70f); iconP.setTextAlign(Paint.Align.CENTER);
                c.drawText("⚡", cx, cy - r*0.05f, iconP);
                Paint lbP = new Paint(gv.btnTxtP); lbP.setTextSize(r*0.28f);
                lbP.setColor(Color.argb(220,230,180,255));
                c.drawText("Q.SLASH", cx, cy + r*0.62f, lbP);
                // Ready pulse glow
                Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
                glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(4f);
                float pulse = 0.5f+0.5f*(float)Math.abs(Math.sin(now/250.0));
                glow.setColor(Color.argb((int)(160*pulse), 200, 80, 255));
                c.drawCircle(cx, cy, r + 5f*pulse, glow);
            }
            return;
        }

        String[] skillIcons  = {"", "💨", "👁", "💊", "🛡"};
        String[] skillNames  = {"NO SKILL", "DASH", "STEALTH", "HEAL", "SHIELD"};
        int t = lp.activeSkillType;

        boolean onCd    = lp.skillOnCooldown();
        boolean active  = lp.skillIsActive();
        boolean noSkill = (t == Player.ACTIVE_NONE);

        float cx = gv.skillRect.centerX(), cy = gv.skillRect.centerY(), r = gv.skillRect.width() / 2f;

        // Button colour
        int btnColor;
        if (noSkill)      btnColor = Color.argb(100,50,50,50);
        else if (onCd)    btnColor = Color.argb(150,60,60,60);
        else if (active)  btnColor = Color.argb(220,50,200,160);
        else              btnColor = Color.argb(210,60,100,200);

        c.drawCircle(cx, cy, r, gv.fill(btnColor));

        // Circle border
        Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderP.setStyle(Paint.Style.STROKE);
        borderP.setStrokeWidth(3f);
        borderP.setColor(noSkill ? Color.argb(60,150,150,150) : Color.argb(160,150,200,255));
        c.drawCircle(cx, cy, r, borderP);

        // Cooldown sweep overlay (arc over circle)
        if (onCd && !noSkill) {
            long total = skillCooldownTotal(t);
            long rem   = lp.skillCooldownEnd - System.currentTimeMillis();
            float frac = Math.max(0f, Math.min(1f, (float)rem / total));
            // Dark gv.fill
            c.drawCircle(cx, cy, r, gv.fill(Color.argb(140,0,0,0)));
            // Sweep arc to show progress
            Paint arcP = new Paint(Paint.ANTI_ALIAS_FLAG);
            arcP.setColor(Color.argb(180,60,100,200));
            arcP.setStyle(Paint.Style.FILL);
            RectF arcRect = new RectF(cx-r, cy-r, cx+r, cy+r);
            c.drawArc(arcRect, -90f, 360f * (1f - frac), true, arcP);
            // Re-draw border on top
            c.drawCircle(cx, cy, r, borderP);
            // Cooldown text
            Paint cdTxt = gv.fill(Color.argb(220,255,200,0));
            cdTxt.setTextSize(r * 0.45f); cdTxt.setTextAlign(Paint.Align.CENTER);
            cdTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText((rem/1000+1)+"s", cx, cy + r*0.17f, cdTxt);
        }

        // Label + icon (only when not on cooldown)
        if (!onCd || noSkill) {
            String icon  = noSkill ? "❌" : skillIcons[t];
            String label = noSkill ? "SKILL" : skillNames[t];
            Paint iconP = new Paint(Paint.ANTI_ALIAS_FLAG);
            iconP.setTextSize(r * 0.70f); iconP.setTextAlign(Paint.Align.CENTER);
            c.drawText(icon, cx, cy - r * 0.05f, iconP);
            Paint lbP = new Paint(gv.btnTxtP); lbP.setTextSize(r * 0.30f);
            lbP.setColor(Color.argb(200,220,230,255));
            c.drawText(label, cx, cy + r * 0.62f, lbP);
        }

        // Active glow ring
        if (active) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(4f);
            glow.setColor(Color.argb(200,80,255,180));
            float pulse = 0.5f+0.5f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            glow.setAlpha((int)(200*pulse));
            c.drawCircle(cx, cy, r + 5f * pulse, glow);
        }
    }

    private long skillCooldownTotal(int type) {
        switch(type){
            case Player.ACTIVE_DASH:    return 6000;
            case Player.ACTIVE_STEALTH: return 10000;
            case Player.ACTIVE_HEAL:    return 12000;
            case Player.ACTIVE_SHIELD:  return 14000;
            default: return 1;
        }
    }

    // ═══ SETTINGS OVERLAY ════════════════════════════════════════════════════
    // ═══ WEAPON WHEEL ════════════════════════════════════════════════════════
    private void drawWeaponWheel(Canvas c) {
        if (gv.wheelSlots == null || gv.wheelSlots.length == 0) return;
        Player lp = gv.localPlayer; if (lp == null) return;
        Gun[] allGuns = lp.guns;
        int n = gv.wheelSlots.length;
        float sliceDeg = 360f / n;
        float startDeg = -90f; // top of circle = first slot

        // ── Dim background ────────────────────────────────────────────────────
        Paint dimP = gv.fill(Color.argb(140, 0, 0, 0));
        c.drawRect(0, 0, gv.screenW, gv.screenH, dimP);

        // ── Outer ring background ─────────────────────────────────────────────
        float outerR = gv.wheelRadius;
        float innerR = outerR * 0.38f;
        Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringBg.setStyle(Paint.Style.FILL);
        ringBg.setColor(Color.argb(200, 15, 20, 35));
        c.drawCircle(gv.wheelCX, gv.wheelCY, outerR + 8f, ringBg);

        // ── Slices ────────────────────────────────────────────────────────────
        gv.wheelOval.set(gv.wheelCX - outerR, gv.wheelCY - outerR,
                      gv.wheelCX + outerR, gv.wheelCY + outerR);

        Paint sliceP = new Paint(Paint.ANTI_ALIAS_FLAG);
        sliceP.setStyle(Paint.Style.FILL);
        Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderP.setStyle(Paint.Style.STROKE);
        borderP.setStrokeWidth(2.5f);

        for (int i = 0; i < n; i++) {
            float sweep = sliceDeg - 2f;          // 2° gap between slices
            float begin = startDeg + i * sliceDeg + 1f;
            boolean hovered = (i == gv.wheelHovered);
            int slotGunIdx = gv.wheelSlots[i];

            // Slice color
            int baseColor = allGuns[slotGunIdx].color;
            int r = Color.red(baseColor), g = Color.green(baseColor), b = Color.blue(baseColor);

            // Dim empty guns in the wheel so players can spot usable weapons at a glance
            boolean isEmpty = allGuns[slotGunIdx].ammo == 0 && !allGuns[slotGunIdx].reloading;
            sliceP.setColor(hovered
                    ? Color.argb(230, r, g, b)
                    : isEmpty ? Color.argb(55, r/3, g/3, b/3)
                              : Color.argb(110, r / 2, g / 2, b / 2));
            borderP.setColor(hovered
                    ? Color.argb(255, r, g, b)
                    : isEmpty ? Color.argb(70, r, g, b)
                              : Color.argb(130, r, g, b));

            // Draw filled arc then border arc
            android.graphics.Path slicePath = gv.wheelSlicePath; // reuse pre-allocated path
            slicePath.reset();
            slicePath.moveTo(gv.wheelCX, gv.wheelCY);
            slicePath.arcTo(gv.wheelOval, begin, sweep);
            slicePath.close();
            c.drawPath(slicePath, sliceP);
            c.drawPath(slicePath, borderP);

            // Label: icon + short name, placed at mid-radius
            float midAngleDeg = begin + sweep / 2f;
            float midAngleRad = (float) Math.toRadians(midAngleDeg);
            float labelR = (outerR + innerR) / 2f;
            float lx = gv.wheelCX + (float) Math.cos(midAngleRad) * labelR;
            float ly = gv.wheelCY + (float) Math.sin(midAngleRad) * labelR;

            Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
            labelP.setTextAlign(Paint.Align.CENTER);
            labelP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            labelP.setColor(hovered ? Color.WHITE : Color.argb(200, 220, 220, 220));
            labelP.setShadowLayer(3f, 0, 1f, Color.BLACK);

            String icon, shortName;
            {
                Gun sg = allGuns[slotGunIdx];
                // Map gun index to a simple emoji icon
                String[] gunIcons = {"🔫","🔫","🔫","🔫","🎯","🔫","⚙","🔫","🔫",
                                     "🔵","🟢","⚡","🎯","💥","👻","🎨","💰","🗡"};
                icon = (slotGunIdx < gunIcons.length) ? gunIcons[slotGunIdx] : "🔫";
                shortName = sg.name;
            }

            // Icon (emoji)
            labelP.setTextSize(hovered ? 22f : 18f);
            c.drawText(icon, lx, ly - 7f, labelP);
            // Gun name below icon
            labelP.setTextSize(hovered ? 14f : 11f);
            c.drawText(shortName, lx, ly + 14f, labelP);
            // Ammo sub-label
            {
                Gun sg = allGuns[slotGunIdx];
                boolean isActive = (lp.gunIndex == slotGunIdx);
                // Ammo sub-label — color coded: red=empty, amber=reloading, green=active
                Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
                subP.setTextSize(10f); subP.setTextAlign(Paint.Align.CENTER);
                String ammoLabel;
                if (sg.reloading) {
                    subP.setColor(Color.argb(255, 255, 185, 30)); // amber
                    ammoLabel = "RELOADING\u2026";
                } else if (sg.ammo == 0) {
                    subP.setColor(Color.argb(255, 255, 70, 70)); // red
                    ammoLabel = "EMPTY";
                } else {
                    subP.setColor(isActive ? Color.argb(255, 100, 255, 100) : Color.argb(160, 180, 180, 180));
                    ammoLabel = sg.ammo + "/" + sg.maxAmmo;
                }
                c.drawText(ammoLabel, lx, ly + 27f, subP);
                // Coin Gun: show current effective damage
                if (sg.coinScaling) {
                    float effDmg = 20f + Math.min(lp.coins, 600) * 0.167f;
                    Paint coinHint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    coinHint.setTextSize(9f); coinHint.setTextAlign(Paint.Align.CENTER);
                    coinHint.setColor(Color.argb(200, 255, 215, 0));
                    c.drawText("⚡" + (int) effDmg + "dmg", lx, ly + 38f, coinHint);
                }
            }
        }

        // ── Inner hole — currently equipped gun name ───────────────────────────
        Paint holeFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        holeFill.setStyle(Paint.Style.FILL);
        holeFill.setColor(Color.argb(230, 10, 14, 24));
        c.drawCircle(gv.wheelCX, gv.wheelCY, innerR, holeFill);
        Paint holeRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        holeRing.setStyle(Paint.Style.STROKE);
        holeRing.setStrokeWidth(2f);
        holeRing.setColor(Color.argb(160, 100, 140, 200));
        c.drawCircle(gv.wheelCX, gv.wheelCY, innerR, holeRing);

        // Center label: hovered item or current gun
        String centerMain, centerSub;
        if (gv.wheelHovered >= 0 && gv.wheelHovered < n) {
            int sel = gv.wheelSlots[gv.wheelHovered];
            centerMain = lp.guns[sel].name; centerSub = "SELECT";
        } else {
            centerMain = lp.currentGun().name;
            centerSub = "drag to pick";
        }
        Paint cTitleP = new Paint(Paint.ANTI_ALIAS_FLAG);
        cTitleP.setTextSize(15f); cTitleP.setTextAlign(Paint.Align.CENTER);
        cTitleP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        cTitleP.setColor(gv.wheelHovered >= 0 ? Color.WHITE : Color.argb(200, 180, 200, 255));
        cTitleP.setShadowLayer(3f, 0, 1f, Color.BLACK);
        c.drawText(centerMain, gv.wheelCX, gv.wheelCY - 5f, cTitleP);
        Paint cSubP = new Paint(Paint.ANTI_ALIAS_FLAG);
        cSubP.setTextSize(11f); cSubP.setTextAlign(Paint.Align.CENTER);
        cSubP.setColor(Color.argb(150, 160, 180, 220));
        c.drawText(centerSub, gv.wheelCX, gv.wheelCY + 13f, cSubP);

        // ── Coins display (relevant for Coin Gun) ─────────────────────────────
        Paint coinP = new Paint(Paint.ANTI_ALIAS_FLAG);
        coinP.setTextSize(13f); coinP.setTextAlign(Paint.Align.CENTER);
        coinP.setColor(Color.argb(200, 255, 215, 0));
        coinP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        c.drawText("💰 " + lp.coins, gv.wheelCX, gv.wheelCY + outerR + 26f, coinP);
    }

    private void drawSettings(Canvas c) {
        if(gv.settingsPanel==null) return;
        SharedPreferences prefs = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);
        int  opacity = prefs.getInt    ("opacity",  1);

        // Panel background + border
        c.drawRoundRect(gv.settingsPanel, 16, 16, gv.settingsBgP);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(160,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(gv.settingsPanel, 16, 16, border);

        float px = gv.settingsPanel.left, py = gv.settingsPanel.top;
        float pw = gv.settingsPanel.width();

        c.drawText("⚙  CONTROLS", px+20, py+42, gv.settingsTitleP);

        c.drawRoundRect(gv.closeSettingsRect, 8, 8, gv.closeBtnP);
        Paint cTxt = new Paint(gv.optTxtP); cTxt.setTextSize(20f);
        c.drawText("✕", gv.closeSettingsRect.centerX(), gv.closeSettingsRect.centerY()+7, cTxt);

        Paint div = gv.fill(Color.argb(60,255,255,255));
        c.drawRect(px+16, py+58, px+pw-16, py+60, div);

        int aimSens = prefs.getInt("aim_sens", 1);
        boolean showGunStats = prefs.getBoolean("gun_stats", true);
        boolean showAimLine  = prefs.getBoolean("aim_line",  false);
        // Row labels
        String[] labels = {"JOYSTICK SIZE","SWAP SIDES","BUTTON SIZE","AIM SPEED","OPACITY","GUN STATS","AIM LINE","RELEASE FIRE","FIRE THRESH"};
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f, py+500f, py+562f};
        for(int r=0;r<9;r++) c.drawText(labels[r], px+20, rowY[r]+26, gv.settingsLabelP);

        String[] jsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, gv.jsSizeOpts[i],  jsLabels[i], i==jsSize);
        String[] swLabels = {"OFF","ON"};
        for(int i=0;i<2;i++) drawOpt(c, gv.swapOpts[i],    swLabels[i], i==(swap?1:0));
        String[] bsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, gv.btnSizeOpts[i], bsLabels[i], i==btnSize);
        String[] asLabels = {"SLOW","NORM","FAST"};
        for(int i=0;i<3;i++) drawOpt(c, gv.aimSensOpts[i], asLabels[i], i==aimSens);
        String[] opLabels = {"LO","MED","HI"};
        for(int i=0;i<3;i++) drawOpt(c, gv.opacityOpts[i], opLabels[i], i==opacity);
        String[] gsLabels = {"ON","OFF"};
        for(int i=0;i<2;i++) drawOpt(c, gv.gunStatOpts[i], gsLabels[i], i==(showGunStats?0:1));
        String[] alLabels = {"ON","OFF"};
        for(int i=0;i<2;i++) drawOpt(c, gv.aimLineOpts[i], alLabels[i], i==(showAimLine?0:1));
        // RELEASE FIRE ▶ button — opens per-gun panel
        if (gv.relFireOpenBtn != null) {
            // Count how many guns have release fire on
            int rfCount = 0;
            for (int i = 0; i < GameView.GUN_NAMES.length; i++) if (prefs.getBoolean("rel_fire_"+i,false)) rfCount++;
            c.drawRoundRect(gv.relFireOpenBtn, 8, 8, gv.optBtnSelP);
            Paint rfBtnTxt = new Paint(gv.optTxtP); rfBtnTxt.setColor(Color.WHITE); rfBtnTxt.setTextSize(17f);
            String rfLabel = rfCount == 0 ? "OFF ▶" : rfCount + " gun" + (rfCount>1?"s":"") + " ▶";
            c.drawText(rfLabel, gv.relFireOpenBtn.centerX(), gv.relFireOpenBtn.centerY()+7f, rfBtnTxt);
        }

        // Fire threshold — value display box + EDIT button
        if (gv.fireThreshValRect != null) {
            float curFt = gv.getFireThresh();
            c.drawRoundRect(gv.fireThreshValRect, 8, 8, gv.fill(Color.argb(180,30,40,70)));
            Paint ftBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
            ftBorder.setColor(Color.argb(140,80,120,200)); ftBorder.setStyle(Paint.Style.STROKE); ftBorder.setStrokeWidth(1.5f);
            c.drawRoundRect(gv.fireThreshValRect, 8, 8, ftBorder);
            Paint ftVal = new Paint(gv.optTxtP); ftVal.setColor(Color.WHITE); ftVal.setTextSize(18f);
            c.drawText(String.format(java.util.Locale.US, "%.2f", curFt),
                    gv.fireThreshValRect.centerX(), gv.fireThreshValRect.centerY()+7, ftVal);
        }
        if (gv.fireThreshEditBtn != null) {
            c.drawRoundRect(gv.fireThreshEditBtn, 8, 8, gv.optBtnSelP);
            Paint editTxt = new Paint(gv.optTxtP); editTxt.setColor(Color.WHITE); editTxt.setTextSize(17f);
            c.drawText("EDIT", gv.fireThreshEditBtn.centerX(), gv.fireThreshEditBtn.centerY()+7, editTxt);
        }

        // MOVE BUTTONS button
        if(gv.moveBtnsRect!=null){
            Paint mbP = gv.fill(Color.argb(210,60,110,190));
            c.drawRoundRect(gv.moveBtnsRect, 10, 10, mbP);
            Paint mbTxt = new Paint(gv.optTxtP); mbTxt.setTextSize(19f); mbTxt.setColor(Color.WHITE);
            c.drawText("✥  MOVE BUTTONS", gv.moveBtnsRect.centerX(), gv.moveBtnsRect.centerY()+7, mbTxt);
        }

        // MAIN MENU button
        if(gv.mainMenuRect!=null){
            Paint mmP = gv.fill(Color.argb(220,160,30,30));
            c.drawRoundRect(gv.mainMenuRect, 10, 10, mmP);
            Paint mmTxt = new Paint(gv.optTxtP); mmTxt.setTextSize(19f); mmTxt.setColor(Color.WHITE);
            c.drawText("⏎  MAIN MENU", gv.mainMenuRect.centerX(), gv.mainMenuRect.centerY()+7, mmTxt);
        }

        // CHANGE NAME button
        if(gv.changeNameRect!=null){
            Paint cnP = gv.fill(Color.argb(220,30,120,160));
            c.drawRoundRect(gv.changeNameRect, 10, 10, cnP);
            Paint cnTxt = new Paint(gv.optTxtP); cnTxt.setTextSize(19f); cnTxt.setColor(Color.WHITE);
            String currentName = gv.localPlayer != null ? gv.localPlayer.name : "???";
            c.drawText("✎  CHANGE NAME  [" + currentName + "]", gv.changeNameRect.centerX(), gv.changeNameRect.centerY()+7, cnTxt);
        }
    }
    private void drawOpt(Canvas c, RectF r, String label, boolean selected) {
        if(r==null) return;
        c.drawRoundRect(r, 8, 8, selected ? gv.optBtnSelP : gv.optBtnP);
        Paint t = new Paint(gv.optTxtP);
        if(selected) { t.setColor(Color.WHITE); } else { t.setColor(Color.argb(180,200,210,230)); }
        c.drawText(label, r.centerX(), r.centerY()+7, t);
    }

    // ═══ PER-GUN RELEASE FIRE PANEL ══════════════════════════════════════════
    private void drawRelFirePanel(Canvas c) {
        if (gv.relFirePanel == null) return;
        SharedPreferences prefs = gv.getContext().getSharedPreferences(GameView.PREFS, 0);
        float rfpX = gv.relFirePanel.left, rfpY = gv.relFirePanel.top;
        float rfpW = gv.relFirePanel.width();

        // Background
        c.drawRoundRect(gv.relFirePanel, 16, 16, gv.settingsBgP);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(160, 80, 120, 200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(gv.relFirePanel, 16, 16, border);

        // Title
        Paint titleP = new Paint(gv.settingsTitleP);
        c.drawText("⚡  RELEASE FIRE", rfpX + 20, rfpY + 42, titleP);

        // Close button
        c.drawRoundRect(gv.relFireCloseBtn, 8, 8, gv.closeBtnP);
        Paint cTxt = new Paint(gv.optTxtP); cTxt.setTextSize(20f);
        c.drawText("✕", gv.relFireCloseBtn.centerX(), gv.relFireCloseBtn.centerY()+7, cTxt);

        // Divider
        Paint div = gv.fill(Color.argb(60,255,255,255));
        c.drawRect(rfpX+16, rfpY+58, rfpX+rfpW-16, rfpY+60, div);

        // Column header labels
        float rfColW = rfpW / 2f - 12f;
        int rfRows = 10;
        float rfRowH = 38f, rfRowGap = 5f;
        float rfContentY = rfpY + 62f;
        Paint gunNameP = new Paint(Paint.ANTI_ALIAS_FLAG);
        gunNameP.setTextSize(15f); gunNameP.setTextAlign(Paint.Align.LEFT);

        for (int i = 0; i < GameView.GUN_NAMES.length; i++) {
            int col = i / rfRows, row = i % rfRows;
            float rfRx = rfpX + 10f + col * (rfColW + 12f);
            float ry = rfContentY + row * (rfRowH + rfRowGap);

            boolean isOn = prefs.getBoolean("rel_fire_"+i, false);
            int gunColor = GameView.GUN_COLORS[i];

            // Row background
            Paint rowBg = gv.fill(Color.argb(30, Color.red(gunColor), Color.green(gunColor), Color.blue(gunColor)));
            c.drawRoundRect(new RectF(rfRx, ry, rfRx+rfColW, ry+rfRowH), 6, 6, rowBg);

            // Color accent bar
            Paint accentP = gv.fill(gunColor);
            c.drawRoundRect(new RectF(rfRx, ry+8, rfRx+4, ry+rfRowH-8), 2, 2, accentP);

            // Gun name
            gunNameP.setColor(isOn ? Color.WHITE : Color.argb(160, 200, 210, 230));
            c.drawText(GameView.GUN_NAMES[i], rfRx+12, ry+rfRowH/2f+6, gunNameP);

            // ON / OFF toggle buttons
            if (gv.relFireToggleON[i] != null) {
                Paint onP = isOn
                    ? gv.fill(Color.argb(230, Color.red(gunColor)/2+60, Color.green(gunColor)/2+60, Color.blue(gunColor)/2+40))
                    : gv.fill(Color.argb(80,40,50,80));
                c.drawRoundRect(gv.relFireToggleON[i], 6, 6, onP);
                Paint onTxt = new Paint(gv.optTxtP); onTxt.setTextSize(13f);
                onTxt.setColor(isOn ? Color.WHITE : Color.argb(120,180,190,210));
                c.drawText("ON", gv.relFireToggleON[i].centerX(), gv.relFireToggleON[i].centerY()+5, onTxt);
            }
            if (gv.relFireToggleOFF[i] != null) {
                Paint offP = !isOn
                    ? gv.fill(Color.argb(180,60,30,30))
                    : gv.fill(Color.argb(80,40,50,80));
                c.drawRoundRect(gv.relFireToggleOFF[i], 6, 6, offP);
                Paint offTxt = new Paint(gv.optTxtP); offTxt.setTextSize(13f);
                offTxt.setColor(!isOn ? Color.argb(220,255,160,160) : Color.argb(120,180,190,210));
                c.drawText("OFF", gv.relFireToggleOFF[i].centerX(), gv.relFireToggleOFF[i].centerY()+5, offTxt);
            }
        }
    }

    // ═══ SHOP OVERLAY ════════════════════════════════════════════════════════
    private void drawShop(Canvas c) {
        Player lp = gv.localPlayer;
        float spw = Math.min(580f, gv.screenW - 40f);
        float sph = gv.shopPanelH;
        float spx = (gv.screenW - spw) / 2f;
        float spy = (gv.screenH - sph) / 2f;

        // Panel background + border
        c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,gv.settingsBgP);
        Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(180,80,120,200));
        border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,border);

        // Title
        c.drawText("\uD83D\uDED2  SHOP", spx+20, spy+44, gv.settingsTitleP);

        // Coins
        Paint cpP=gv.fill(Color.rgb(255,210,50)); cpP.setTextSize(22f);
        cpP.setTextAlign(Paint.Align.RIGHT); cpP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("\uD83D\uDCB0 "+(lp!=null?lp.coins:0), spx+spw-20, spy+44, cpP);

        // Close button
        if(gv.shopCloseRect!=null){
            c.drawRoundRect(gv.shopCloseRect,8,8,gv.closeBtnP);
            Paint cTxt=new Paint(gv.optTxtP); cTxt.setTextSize(20f);
            c.drawText("✕",gv.shopCloseRect.centerX(),gv.shopCloseRect.centerY()+7,cTxt);
        }

        // Tab buttons
        if (gv.shopTabGuns != null && gv.shopTabSkills != null) {
            Paint tabActive   = gv.fill(Color.argb(220,60,100,200));
            Paint tabInactive = gv.fill(Color.argb(100,40,40,70));
            Paint tabTxt = gv.fill(Color.WHITE); tabTxt.setTextSize(17f); tabTxt.setTextAlign(Paint.Align.CENTER); tabTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawRoundRect(gv.shopTabGuns,   10,10, gv.shopTab==0?tabActive:tabInactive);
            c.drawRoundRect(gv.shopTabSkills, 10,10, gv.shopTab==1?tabActive:tabInactive);
            c.drawText("\uD83D\uDD2B Weapons", gv.shopTabGuns.centerX(),   gv.shopTabGuns.centerY()+7,   tabTxt);
            c.drawText("\u26A1 Skills",         gv.shopTabSkills.centerX(), gv.shopTabSkills.centerY()+7, tabTxt);
        }

        if (gv.shopTab == 0) drawShopGuns(c, lp, spx, spy, spw);
        else              drawShopSkills(c, lp, spx, spy, spw);
    }

    private void drawShopGuns(Canvas c, Player lp, float spx, float spy, float spw) {
        if (gv.shopGunsCache == null) gv.shopGunsCache = Gun.createAll(); // build once, reuse
        Gun[] allGuns = gv.shopGunsCache;
        float rowH=GameView.SHOP_ROW_H, rowGap=GameView.SHOP_ROW_GAP, firstRowY=spy+110f;
        float sph = gv.shopPanelH;
        int numRows = (int) Math.ceil(allGuns.length / 2.0);
        float contentH = numRows * (rowH + rowGap);
        float visibleH  = sph - 110f;
        gv.shopTabScrollMax[0] = Math.max(0f, contentH - visibleH);
        float scrollY = gv.shopTabScrollY[0];

        float colW  = (spw - 24f) / 2f;
        float colPad = 8f;

        c.save();
        c.clipRect(spx, spy + 100f, spx + spw, spy + sph - 4f);

        for (int i = 0; i < allGuns.length; i++) {
            int row = i / 2, col = i % 2;
            float ry = firstRowY + row * (rowH + rowGap) - scrollY;
            if (ry + rowH < spy + 100f || ry > spy + sph) continue;
            float cardX = spx + 8f + col * (colW + colPad);
            float cardW = colW;
            Gun g = allGuns[i];
            boolean owned = (lp == null) || lp.unlockedGuns[i];

            // Card background
            Paint rowBg = gv.fill(owned ? Color.argb(60, 60, 140, 70) : Color.argb(40, 40, 40, 80));
            c.drawRoundRect(new RectF(cardX, ry, cardX + cardW, ry + rowH), 7, 7, rowBg);

            // Color dot
            c.drawCircle(cardX + 14f, ry + rowH / 2f, 8f, gv.fill(g.color));

            // Gun name
            Paint gnP = gv.fill(g.color); gnP.setTextSize(15f);
            gnP.setTypeface(Typeface.DEFAULT_BOLD); gnP.setTextAlign(Paint.Align.LEFT);
            // Clip name to avoid overlapping buy button
            float nameMaxW = cardW - 14f - 20f - (cardW * 0.38f) - 10f;
            c.save();
            c.clipRect(cardX + 26f, ry, cardX + cardW - (cardW * 0.38f) - 6f, ry + rowH);
            c.drawText(g.name, cardX + 26f, ry + rowH * 0.42f + 5f, gnP);
            c.restore();

            // Buy / Owned button
            if (gv.shopBuyRects[i] != null) {
                RectF br = gv.shopBuyRects[i];
                RectF adjBr = new RectF(br.left, ry + (rowH - (br.height())) / 2f,
                                         br.right, ry + (rowH + (br.height())) / 2f);
                if (owned) {
                    c.drawRoundRect(adjBr, 6, 6, gv.fill(Color.argb(170, 40, 160, 70)));
                    Paint otP = gv.fill(Color.WHITE); otP.setTextSize(11f);
                    otP.setTextAlign(Paint.Align.CENTER); otP.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText("✓", adjBr.centerX(), adjBr.centerY() + 5f, otP);
                } else {
                    int price = GameView.GUN_PRICES[i];
                    boolean afford = (lp != null && lp.coins >= price);
                    c.drawRoundRect(adjBr, 6, 6, gv.fill(afford ? Color.argb(220, 170, 120, 0) : Color.argb(100, 70, 70, 80)));
                    Paint btP = gv.fill(afford ? Color.WHITE : Color.argb(120, 200, 200, 200));
                    btP.setTextSize(11f); btP.setTextAlign(Paint.Align.CENTER); btP.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText("\uD83D\uDCB0" + price, adjBr.centerX(), adjBr.centerY() + 5f, btP);
                }
            }
        }

        // Scroll indicator
        if (gv.shopTabScrollMax[0] > 0f) {
            float trackX = spx + spw - 6f;
            float trackTop = spy + 104f, trackBot = spy + sph - 8f, trackH = trackBot - trackTop;
            float thumbH = Math.max(30f, trackH * (visibleH / contentH));
            float thumbTop = trackTop + (trackH - thumbH) * (scrollY / gv.shopTabScrollMax[0]);
            Paint scrollP = gv.fill(Color.argb(120, 200, 200, 255));
            c.drawRoundRect(trackX - 3f, thumbTop, trackX + 3f, thumbTop + thumbH, 3f, 3f, scrollP);
        }

        c.restore();
    }

    private void drawShopSkills(Canvas c, Player lp, float spx, float spy, float spw) {
        float sph = gv.shopPanelH;
        // Total content: passive header(~16px) + 4 passive rows + active header(~35px) + 4 active rows
        float rowH=54f, rowGap=4f;
        float contentBottom = 412f + 4*(rowH+rowGap); // relative to spy
        float contentH = contentBottom - 110f;
        float visibleH  = sph - 110f;
        gv.shopTabScrollMax[1] = Math.max(0f, contentH - visibleH);
        float scrollY = gv.shopTabScrollY[1];

        c.save();
        c.clipRect(spx, spy + 100f, spx + spw, spy + sph - 4f);
        c.translate(0f, -scrollY);

        // ── Passive section header ──
        Paint secP=gv.fill(Color.argb(220,180,180,255)); secP.setTextSize(17f); secP.setTextAlign(Paint.Align.LEFT); secP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("● PASSIVE SKILLS", spx+18, spy+126, secP);

        String[] passNames={"⚡ Fast Reload","🔥 Fire Rate","🎯 Bullet Range","👟 Move Speed"};
        String[] passDesc ={"−20% reload per level","+20% fire rate per level","+25% range per level","+12% speed per level"};
        int[]    passLevels=(lp==null)?new int[4]:new int[]{lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
        float firstY=spy+132f;
        for(int i=0;i<4;i++){
            float ry=firstY+i*(rowH+rowGap);
            int lv=passLevels[i];
            c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,gv.fill(Color.argb(80,30,30,70)));
            Paint nameP2=gv.fill(Color.WHITE); nameP2.setTextSize(16f); nameP2.setTextAlign(Paint.Align.LEFT); nameP2.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(passNames[i],spx+18,ry+22,nameP2);
            Paint descP=gv.fill(Color.argb(150,190,190,190)); descP.setTextSize(12f); descP.setTextAlign(Paint.Align.LEFT);
            c.drawText(passDesc[i],spx+18,ry+40,descP);
            for(int d=0;d<3;d++){
                Paint pip=gv.fill(d<lv?Color.rgb(80,200,255):Color.argb(80,80,80,80));
                c.drawCircle(spx+spw-140+d*24,ry+rowH/2f,9,pip);
            }
            if(gv.passiveBuyRects[i]!=null){
                if(lv>=3){
                    c.drawRoundRect(gv.passiveBuyRects[i],8,8,gv.fill(Color.argb(100,40,120,40)));
                    Paint ot=gv.fill(Color.argb(200,150,255,150)); ot.setTextSize(13f); ot.setTextAlign(Paint.Align.CENTER);
                    c.drawText("MAX",gv.passiveBuyRects[i].centerX(),gv.passiveBuyRects[i].centerY()+5,ot);
                } else {
                    int cost=GameView.PASSIVE_SKILL_COSTS[lv];
                    boolean canBuy=lp!=null&&lp.coins>=cost;
                    c.drawRoundRect(gv.passiveBuyRects[i],8,8,gv.fill(canBuy?Color.argb(210,60,100,200):Color.argb(80,60,60,60)));
                    Paint bt=gv.fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(13f); bt.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCB0"+cost,gv.passiveBuyRects[i].centerX(),gv.passiveBuyRects[i].centerY()+5,bt);
                }
            }
        }

        // ── Active section header ──
        Paint secP2=gv.fill(Color.argb(220,255,210,80)); secP2.setTextSize(17f); secP2.setTextAlign(Paint.Align.LEFT); secP2.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("● ACTIVE SKILL  (equip one)", spx+18, spy+388, secP2);
        Paint noteP=gv.fill(Color.argb(130,180,180,180)); noteP.setTextSize(12f); noteP.setTextAlign(Paint.Align.LEFT);
        c.drawText("Tap [SKILL] button in-game to activate", spx+18, spy+407, noteP);

        String[] actNames={"💨 Dash","👁 Stealth","💊 Heal","🛡 Shield"};
        String[] actDesc ={"Teleport 260px  •  6s cooldown","Invisible 4s  •  10s cooldown","+40 HP  •  12s cooldown","60-HP barrier 6s  •  14s cooldown"};
        int[]    actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
        float activeFirstY=spy+412f;
        for(int i=0;i<4;i++){
            float ry=activeFirstY+i*(rowH+rowGap);
            boolean owned=(lp!=null&&lp.activeSkillType==actTypes[i]);
            c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,gv.fill(owned?Color.argb(100,50,80,30):Color.argb(80,30,30,60)));
            Paint nameP2=gv.fill(Color.WHITE); nameP2.setTextSize(16f); nameP2.setTextAlign(Paint.Align.LEFT); nameP2.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(actNames[i],spx+18,ry+22,nameP2);
            Paint descP=gv.fill(Color.argb(150,190,190,190)); descP.setTextSize(12f); descP.setTextAlign(Paint.Align.LEFT);
            c.drawText(actDesc[i],spx+18,ry+40,descP);
            if(gv.activeBuyRects[i]!=null){
                if(owned){
                    c.drawRoundRect(gv.activeBuyRects[i],8,8,gv.fill(Color.argb(100,40,120,40)));
                    Paint ot=gv.fill(Color.argb(200,150,255,150)); ot.setTextSize(12f); ot.setTextAlign(Paint.Align.CENTER);
                    c.drawText("EQUIPPED",gv.activeBuyRects[i].centerX(),gv.activeBuyRects[i].centerY()+5,ot);
                } else {
                    int cost=GameView.ACTIVE_SKILL_COSTS[i];
                    boolean canBuy=lp!=null&&lp.coins>=cost;
                    c.drawRoundRect(gv.activeBuyRects[i],8,8,gv.fill(canBuy?Color.argb(210,100,60,200):Color.argb(80,60,60,60)));
                    Paint bt=gv.fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(12f); bt.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCB0"+cost,gv.activeBuyRects[i].centerX(),gv.activeBuyRects[i].centerY()+5,bt);
                }
            }
        }

        c.restore();

        // Scroll indicator (drawn after restore so it's not clipped out)
        if (gv.shopTabScrollMax[1] > 0f) {
            float trackX = spx + spw - 6f;
            float trackTop = spy + 104f, trackBot = spy + sph - 8f, trackH = trackBot - trackTop;
            float thumbH = Math.max(30f, trackH * (visibleH / contentH));
            float thumbTop = trackTop + (trackH - thumbH) * (scrollY / gv.shopTabScrollMax[1]);
            Paint scrollP = gv.fill(Color.argb(120, 200, 200, 255));
            c.drawRoundRect(trackX - 3f, thumbTop, trackX + 3f, thumbTop + thumbH, 3f, 3f, scrollP);
        }
    }

}
