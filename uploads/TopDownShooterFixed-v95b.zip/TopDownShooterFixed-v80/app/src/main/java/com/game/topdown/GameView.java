package com.game.topdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import org.json.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public class GameView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, NetworkManager.Callback {

    // ═══ WORLD ════════════════════════════════════════════════════════════════
    static final float MAP_W = 3600, MAP_H = 3600;
    static final int   PR    = 24;
    static final long  RESPAWN_MS = 5000;

    static final float[][] WALLS = {
        // ── Original top-left quadrant ──────────────────────────────────────
        {400,310,760,350}, {880,120,920,560}, {280,660,315,980},
        {560,540,920,580}, {1100,370,1460,410}, {1530,210,1570,670},
        {680,960,720,1310}, {960,840,1320,880}, {180,1160,540,1200},
        {1430,960,1470,1320}, {540,1520,1060,1560}, {1250,1360,1570,1400},
        {1700,480,1740,920}, {300,1480,340,1920}, {820,1780,1220,1820},
        {1600,1580,1640,2020},
        // ── Top-right quadrant (x + ~1850) ──────────────────────────────────
        {2250,310,2610,350}, {2730,120,2770,560}, {2130,660,2165,980},
        {2410,540,2770,580}, {2950,370,3310,410}, {3380,210,3420,670},
        {2530,960,2570,1310}, {2810,840,3170,880}, {2030,1160,2390,1200},
        {3280,960,3320,1320}, {2390,1520,2910,1560}, {3100,1360,3420,1400},
        {3450,480,3490,920},  {2150,1480,2190,1920}, {2670,1780,3070,1820},
        {3450,1580,3490,2020},
        // ── Bottom-left quadrant (y + ~1800) ────────────────────────────────
        {400,2260,760,2300}, {880,2070,920,2510}, {280,2710,315,3030},
        {560,2490,920,2530}, {1100,2320,1460,2360}, {1530,2160,1570,2620},
        {680,2760,720,3110},  {960,2790,1320,2830}, {180,2960,540,3000},
        {1430,2810,1470,3170},{540,3170,1060,3210}, {1250,3010,1570,3050},
        {1700,2430,1740,2870},{300,3080,340,3520},  {820,3430,1220,3470},
        {1600,3230,1640,3570},
        // ── Bottom-right quadrant ────────────────────────────────────────────
        {2250,2260,2610,2300},{2730,2070,2770,2510},{2130,2710,2165,3030},
        {2410,2490,2770,2530},{2950,2320,3310,2360},{3380,2160,3420,2620},
        {2530,2760,2570,3110},{2810,2790,3170,2830},{2030,2960,2390,3000},
        {3280,2810,3320,3170},{2390,3170,2910,3210},{3100,3010,3420,3050},
        {3450,2430,3490,2870},{2150,3080,2190,3520},{2670,3430,3070,3470},
        {3450,3230,3490,3570},
    };
    static final float[][] SPAWNS = {
        {120,120},{3480,120},{120,3480},{3480,3480},
        {1800,120},{120,1800},{3480,1800},{1800,3480},
        {900,900},{2700,900},{900,2700},{2700,2700},
        {1800,1800},
    };

    // ═══ STATE ════════════════════════════════════════════════════════════════
    volatile Player   localPlayer;   // volatile: written by net thread (client join)
    final String      savedName;
    final Map<Integer,Player> remote   = new ConcurrentHashMap<>();
    final Map<Integer,Long>   deadAtMs = new ConcurrentHashMap<>();
    final List<Bullet>        bullets    = new ArrayList<>();
    // Pre-allocated list reused every frame by resolvePlayerCollisions — avoids 60Hz GC
    final List<Player>        collisionPlayers = new ArrayList<>();
    // Explosion visual: {x, y, spawnTimeMs}
    final EffectsManager effects = new EffectsManager();
    int bulletId;

    // ── Volt Chakram ──────────────────────────────────────────────────────────
    final List<VoltChakram> voltChakrams     = new ArrayList<>();
    float             voltOrbitAngle   = 0f;   // master orbit ring angle
    float             voltCharge       = 0f;   // 0.0–1.0 spin charge
    float[]           pendingVoltLaunch = null; // [ax, ay, charge] to send to host

    // ── Shadow Blade ─────────────────────────────────────────────────────────
    float             shadowBladeCharge = 0f;  // 0.0–1.0 hold charge
    float[]           pendingShadowBlade = null; // [ax, ay, charge] to send to host
    long              quickSlashCdEnd    = 0L;  // quick-slash cooldown (ms epoch)
    float[]           pendingQuickSlash  = null; // [ax, ay] to send to host

    // ═══ NETWORK ══════════════════════════════════════════════════════════════
    final NetworkManager          net;
    final boolean                 isHost;
    final boolean                 singlePlayer;
    final Set<Integer>            botIds   = new HashSet<>();
    boolean                 trainingMode = false;
    final Set<Integer>            dummyIds = new HashSet<>();
    final Map<Integer, float[]>   dummyHome = new HashMap<>();
    static final int DUMMY_ID_BASE = 50;
    static final int MAX_DUMMIES   = 6;
    static final float[][] DUMMY_SPAWNS = {
        {1800,1800},{1500,1800},{2100,1800},
        {1800,1500},{1800,2100},{1650,1650}
    };
    RectF trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn;
    volatile String               pendingState;
    final Map<Integer,float[]>    inputs = new ConcurrentHashMap<>();
    long lastBroadcast;
    // FIX: network thread writes these; game thread drains them — avoids
    // ConcurrentModificationException on activeBombs / voltChakrams (plain ArrayLists).
    // float[] bomb entry  : [pid, spawnX, spawnY, vx, vy, maxRange]
    // float[] vc entry    : [pid, ax, ay, charge]
    final ConcurrentLinkedQueue<float[]> netBombQ = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netVcQ   = new ConcurrentLinkedQueue<>();
    final ConcurrentLinkedQueue<float[]> netSbQ   = new ConcurrentLinkedQueue<>(); // Shadow Blade [pid,ax,ay,charge]
    final ConcurrentLinkedQueue<float[]> netQsQ   = new ConcurrentLinkedQueue<>(); // Quick Slash  [pid,ax,ay]
    String hostIpDisplay = "";  // shown in HUD

    // ═══ INPUT ════════════════════════════════════════════════════════════════
    Joystick moveStick, aimStick;
    RectF    switchRect, reloadRect, bombRect, dropRect, paintModeRect;

    // ═══ BOMBS ════════════════════════════════════════════════════════════════
    final List<Bomb> activeBombs = new ArrayList<>();
    volatile boolean throwingBomb = false;  // true while player is aiming a throw
    final Set<Long> spawnedBombFx    = new HashSet<>(); // bomb explodedAt already spawned
    final Set<Long> spawnedAirStrikeFx = new HashSet<>(); // airstrike flashUntil already spawned

    // ═══ AIR STRIKE (Pharsa SS) ══════════════════════════════════════════════
    // Each entry: [worldX, worldY, triggerTimeMs, ownerId, flashUntilMs]
    // Phase: triggerTimeMs in future = pending drop, flashUntilMs>0 = exploding
    final List<double[]> airStrikes = new ArrayList<>();  // [x,y,triggerMs,ownerId,flashUntilMs]
    static final float  AS_RADIUS   = 110f;   // AoE radius per strike
    static final float  AS_DAMAGE   = 28f;    // damage per strike
    static final long   AS_WARNING_MS = 1500L; // warning delay before explosion
    static final long   AS_FLASH_MS = 350L;   // explosion flash duration

    // ── Air Strike ring-aim state ─────────────────────────────────────────────
    static final float AS_RING_R   = 700f;   // big ring radius (world px)
    float asAimAngle = Float.NaN;             // current aimed angle (NaN = ring hidden)
    float asAimMag   = 0f;                    // 0‥1 normalised aim-stick magnitude

    // ═══ CONTROL SETTINGS ════════════════════════════════════════════════════
    static final String PREFS = "shooter_ctrl";
    volatile boolean settingsOpen = false;
    RectF   gearRect, settingsPanel, closeSettingsRect;
    final RectF[] jsSizeOpts  = new RectF[3];
    final RectF[] swapOpts    = new RectF[2];
    final RectF[] btnSizeOpts = new RectF[3];
    final RectF[] opacityOpts   = new RectF[3];
    final RectF[] aimSensOpts   = new RectF[3];
    final RectF[] gunStatOpts   = new RectF[2]; // ON/OFF gun stat bars
    final RectF[] aimLineOpts     = new RectF[2]; // ON/OFF aim line
    // ── Per-gun Release Fire panel ────────────────────────────────────────────
    boolean relFireOpen    = false;
    RectF   relFireOpenBtn = null;           // "RELEASE FIRE ▶" row in main settings
    RectF   relFirePanel   = null;           // secondary overlay panel
    RectF   relFireCloseBtn = null;
    final RectF[] relFireToggleON  = new RectF[22];
    final RectF[] relFireToggleOFF = new RectF[22];
    static final String[] GUN_NAMES = {
        "Pistol","SMG","Shotgun","Assault","Sniper","Burst","Minigun","Revolver","LMG",
        "Plasma","Bouncer","Piercer","Seeker","Blaster","Ghost","Paint","Coin Gun","V.Chakram","Hook Spear","Air Strike",
        "Soul Surge","Shadow Blade"};
    static final int[] GUN_COLORS = {
        0xFF4FC3F7,0xFF81C784,0xFFFF8A65,0xFFFFB347,0xFFCE93D8,0xFF4DD0E1,
        0xFFFF5252,0xFFFFD54F,0xFF90A4AE,0xFF00E5FF,0xFF69F0AE,0xFF40C4FF,
        0xFFFF6E40,0xFFFFD740,0xFF26C6DA,0xFFFFD700,0xFF80D8FF,0xFFFF8F00,
        // 18=Air Strike, 19=Ghost(fixed), 20=Soul Surge, 21=Shadow Blade
        0xFFE040FB,0xFF7B1FA2,0xFF9C27B0,0xFFFF1744};
    RectF fireThreshEditBtn;   // tapping opens custom-value dialog
    RectF fireThreshValRect;   // display of current value
    RectF moveBtnsRect;        // "MOVE BUTTONS" button in settings
    RectF mainMenuRect;        // "MAIN MENU" button in settings
    RectF changeNameRect;      // "CHANGE NAME" button in settings

    // ═══ SHOP ════════════════════════════════════════════════════════════════
    volatile boolean shopOpen = false;
    RectF   shopBtn, shopCloseRect;
    final RectF[] shopBuyRects = new RectF[22];
    static final int[] GUN_PRICES = {0, 50, 60, 80, 120, 90, 150, 70, 100, 130, 110, 140, 160, 120, 85, 130, 110, 145, 170, 200, 130, 180};

    // ═══ SHOP SCROLL ═════════════════════════════════════════════════════════
    float shopPanelH = 670f; // computed dynamically from screenH in initLayout
    static final float SHOP_ROW_H   = 46f;  // weapon row height — compact for less scrolling
    static final float SHOP_ROW_GAP = 2f;   // gap between rows (was 4)
    final float[] shopTabScrollY  = {0f, 0f}; // per-tab scroll offset
    final float[] shopTabScrollMax= {0f, 0f}; // per-tab max scroll (set in draw)
    float  shopDragStartY  = 0f;
    float  shopDragLastY   = 0f;
    boolean shopIsDragging = false;
    float  shopScrollVelocity = 0f;  // fling momentum (px/ms)

    // ═══ SKILL SHOP ══════════════════════════════════════════════════════════
    int   shopTab = 0;   // 0 = guns, 1 = skills
    RectF shopTabGuns, shopTabSkills;
    RectF skillRect;                         // active-skill use button
    final RectF[] passiveBuyRects = new RectF[4];
    final RectF[] activeBuyRects  = new RectF[4];
    static final int[] PASSIVE_SKILL_COSTS = {40, 70, 100};   // per level
    static final int[] ACTIVE_SKILL_COSTS  = {80, 100, 80, 90}; // dash/stealth/heal/shield

    // ═══ CACHED PREFS (refreshed on settings change, avoid 60Hz disk reads) ════
    int   cachedAimSens    = 1;        // 0=slow 1=norm 2=fast
    boolean cachedAimLine  = false;
    boolean cachedGunStats = true;
    float cachedFireThresh = 0.40f;
    // Per-gun release-fire cache: index = gunIndex
    final boolean[] cachedRelFire = new boolean[22];

    void refreshCachedPrefs() {
        SharedPreferences p = getContext().getSharedPreferences(PREFS, 0);
        cachedAimSens    = p.getInt    ("aim_sens",  1);
        cachedAimLine    = p.getBoolean("aim_line",  false);
        cachedGunStats   = p.getBoolean("gun_stats", true);
        cachedFireThresh = p.getFloat  ("fire_thresh_val", 0.40f);
        for (int i = 0; i < 22; i++) cachedRelFire[i] = p.getBoolean("rel_fire_" + i, false);
    }
    // "kjm" → infinite ammo (no reload ever)
    // "khm" → zero skill cooldown (skills fire instantly, back-to-back)
    boolean cheatInfiniteAmmo = false;
    boolean cheatNoSkillCd    = false;
    void detectCheats(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase();
        if (n.equals("kjm")) { cheatInfiniteAmmo = true; }
        if (n.equals("khm")) { cheatNoSkillCd    = true; }
    }
    volatile boolean pendingPositionSync = false;  // send pos after dash
    volatile float[] pendingBombSend     = null;   // [vx,vy,maxRange] from client bomb throw
    volatile boolean pendingHealEvent    = false;  // FIX: notify host when Heal fires

    // ═══ DASH ANIMATION ══════════════════════════════════════════════════════
    // (managed by EffectsManager — access via effects.dashAnim*)

    // ═══ DASH AFTEREFFECTS ═══════════════════════════════════════════════════
    // Bot dash visual-only animation: botId -> [renderX, renderY, destX, destY, beginTimeMs]
    // Logical bot.x/bot.y is already at destination; this only affects rendering.
    final Map<Integer, float[]> botDashVisual = new ConcurrentHashMap<>();
    long                lastGhostTimeMs = 0;

    // ═══ DIFFICULTY (0=Easy 1=Normal 2=Hard) ══════════════════════════════
    int difficulty = 1;

    // ═══ AI VELOCITY TRACKING (predictive aiming) ═════════════════════════
    float lpVelX = 0f, lpVelY = 0f;
    float lpPrevX = -1f, lpPrevY = -1f;

    // ═══ BUTTON DRAG ══════════════════════════════════════════════════════════
    boolean btnMoveMode  = false; // drag-to-reposition mode
    int     draggingBtn  = -1;    // 0=switch, 1=reload, -1=none
    float   dragOffX, dragOffY;
    RectF   confirmMoveRect;      // ✓ button to exit move mode
    // Per-button size slider (shown in btnMoveMode after tapping a button)
    int     btnSizingId    = -1;  // which btn is being resized: 0=wheel,1=reload,5=skill
    float   sizeSliderVal  = 0f;  // 0..1 → scale 0.4x..2.2x
    RectF   sizeSliderTrack;      // drawn at bottom of screen
    float   tapStartX, tapStartY; // for tap vs drag detection
    boolean tapMoved       = false;

    // ═══ WEAPON WHEEL ═════════════════════════════════════════════════════════
    boolean wheelOpen     = false;
    float   wheelCX, wheelCY, wheelRadius;
    int     wheelPid      = -1;   // pointer that opened the wheel
    int     wheelHovered  = -1;   // currently highlighted slot index
    /** Slot array: each entry is a gun index (0-16), or -1 = bomb slot.
     *  Rebuilt every time the wheel opens. */
    int[]   wheelSlots;

    // ═══ CAMERA ZOOM ══════════════════════════════════════════════════════════
    float currentZoom = 0.85f;   // smoothly interpolated per-gun zoom (0.85 = 15% zoomed out)
    Paint settingsBgP, settingsLabelP, optBtnP, optBtnSelP, optTxtP, settingsTitleP, closeBtnP;

    // ═══ PRE-ALLOCATED PAINTS & PATHS (eliminate per-frame GC pressure) ═══════
    // drawVoltChakrams — 11+ Paints + 1 Path created per disc per frame without these
    final Paint vcOuterGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcMidGlow   = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcTrailP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcTrailCore = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcRingP     = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcRingP2    = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcBladeP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcZapP      = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcCoreHalo  = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcCoreP     = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint vcConnP     = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Path  vcBladePath = new Path();
    // drawPlayer — reusable Paints per player per frame
    final Paint dpShadow   = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint dpBody     = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint dpGun      = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint dpHpFill   = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint dpName2    = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint dpProtRing = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint dpShRing   = new Paint(Paint.ANTI_ALIAS_FLAG);
    // doDraw — world-space effects drawn every frame
    final Paint ddAimLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    final android.graphics.DashPathEffect aimLineDash =
            new android.graphics.DashPathEffect(new float[]{18f, 10f}, 0f);
    final Paint ddBombArc = new Paint(Paint.ANTI_ALIAS_FLAG);
    final android.graphics.DashPathEffect bombArcDash =
            new android.graphics.DashPathEffect(new float[]{16f, 10f}, 0f);
    // Weapon wheel — reuse Path/RectF per slice instead of allocating per slice
    final Path                    wheelSlicePath = new Path();
    final android.graphics.RectF  wheelOval      = new android.graphics.RectF();
    // Shop — cache gun list so Gun.createAll() isn't called every draw frame
    Gun[] shopGunsCache = null;
    // HUD + scoreboard Paints — these draw every frame in multiplayer
    final Paint hudStatLblP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint hudStatBgP   = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint hudSbHdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint hudSbNameP   = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint hudSbNumP    = new Paint(Paint.ANTI_ALIAS_FLAG);
    final android.graphics.RectF tmpRectF = new android.graphics.RectF(); // general scratch RectF

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    volatile boolean  gameRunning;
    Thread            gameThread;
    /** Latest serialized state string; the sender thread drains this so the game loop never blocks on UDP. */
    volatile String   broadcastSnapshot = null;
    Thread   senderThread;
    float             screenW, screenH, camX, camY;
    float             camPanX, camPanY;   // aim-pan offset (smoothly lerped)
    int               tick;
    long              deathTime;

    Paint bgP,gridP,wallP,bdrP,remP,locP,shP,hpBgP,
                  nameP,hudP,hudBgP,btnP,btnTxtP,
                  deathBgP,deathTxtP,gunTxtP,ipPaint;

    final List<String> feed = new ArrayList<>();

    // ─── Companion classes (rendering + networking) ─────────────────────────────
    GameRenderer      renderer;
    GameNetworkBridge networkBridge;
    Controls          controls;

    // ═══ CTOR ═════════════════════════════════════════════════════════════════

    /** Single-player constructor — no networking, with bot enemies. */
    public GameView(Context ctx, String name, int botCount, int difficulty) {
        super(ctx);
        savedName    = name;
        isHost       = true;
        singlePlayer = true;
        net          = null;
        this.difficulty = difficulty;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        renderer = new GameRenderer(this);
        networkBridge = new GameNetworkBridge(this);
        controls = new Controls(this);
        spawnLocal(0, name);
        // Spawn bots — IDs 10, 11, 12 … well away from real player IDs
        for (int i = 0; i < botCount; i++) {
            int botId = 10 + i;
            Player bot = new Player();
            bot.id = botId; bot.name = "Bot " + (i + 1); bot.guns = Gun.createAll();
            float[] sp = SPAWNS[botId % SPAWNS.length];
            bot.x = sp[0]; bot.y = sp[1]; bot.hp = 100; bot.alive = true;

            // Give each bot a DIFFERENT starting gun so they're varied
            // 0=Pistol 1=SMG 2=Shotgun 3=Assault 4=Sniper 5=Burst 6=Minigun
            int[] startGuns = {3, 1, 2, 5, 4, 0, 6}; // assault, smg, shotgun, burst, sniper, pistol, minigun
            int startGun = startGuns[i % startGuns.length];
            bot.gunIndex = startGun;
            bot.unlockedGuns[startGun] = true;

            // Give each bot a starting active skill — they'll never earn
            // enough coins fast enough otherwise, so they never use skills
            int[] startSkills = {Player.ACTIVE_HEAL, Player.ACTIVE_DASH,
                                 Player.ACTIVE_SHIELD, Player.ACTIVE_STEALTH};
            bot.activeSkillType = startSkills[i % startSkills.length];

            // Starting coins so Normal bots can buy upgrades after a few kills
            if (difficulty == 1) bot.coins = 40;
            if (difficulty == 2) bot.coins = 200;
            remote.put(botId, bot);
            botIds.add(botId);
        }
    }

    /** Training / practice constructor — no bots, no network. */
    public GameView(Context ctx, String name, boolean trainingMode) {
        super(ctx);
        savedName        = name;
        isHost           = true;
        singlePlayer     = true;
        this.trainingMode = trainingMode;
        net              = null;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        renderer = new GameRenderer(this);
        networkBridge = new GameNetworkBridge(this);
        controls = new Controls(this);
        spawnLocal(0, name);
        // In training mode, start near the dummy area (center of map)
        if (localPlayer != null) { localPlayer.x = 1800f; localPlayer.y = 2200f; }
        // Start with one dummy so the range feels populated
        spawnDummy();
    }

    /** Multiplayer constructor — host or client. */
    public GameView(Context ctx, String name, boolean host, String hostIp) {
        super(ctx);
        savedName    = name;
        isHost       = host;
        singlePlayer = false;
        net          = new NetworkManager(this);
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        renderer = new GameRenderer(this);
        networkBridge = new GameNetworkBridge(this);
        controls = new Controls(this);

        if (host) hostIpDisplay = detectLocalIp();

        try {
            if (host) { net.startHost(name); spawnLocal(0, name); }
            else        net.joinGame(hostIp, name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ═══ PAINTS ═══════════════════════════════════════════════════════════════
    void initPaints() {
        bgP     = fill(Color.rgb(12,25,18));
        gridP   = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridP.setColor(Color.argb(22,255,255,255));
        gridP.setStyle(Paint.Style.STROKE); gridP.setStrokeWidth(1f);
        wallP   = fill(Color.rgb(68,72,112));
        bdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
        bdrP.setColor(Color.rgb(100,108,170)); bdrP.setStyle(Paint.Style.STROKE); bdrP.setStrokeWidth(6f);
        remP    = fill(Color.rgb(240,88,88));
        locP    = fill(Color.rgb(80,190,255));
        shP     = fill(Color.argb(65,0,0,0));
        hpBgP   = fill(Color.rgb(38,38,38));
        nameP   = fill(Color.WHITE); nameP.setTextSize(21f); nameP.setTextAlign(Paint.Align.CENTER);
        nameP.setShadowLayer(3f,1f,1f,Color.BLACK);
        hudP    = fill(Color.WHITE); hudP.setTextSize(28f);
        hudBgP  = fill(Color.argb(145,0,0,0));
        btnP    = fill(Color.argb(205,195,55,85));
        btnTxtP = fill(Color.WHITE); btnTxtP.setTextSize(22f);
        btnTxtP.setTextAlign(Paint.Align.CENTER); btnTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        deathBgP  = fill(Color.argb(165,0,0,0));
        deathTxtP = fill(Color.rgb(255,55,55)); deathTxtP.setTextSize(58f);
        deathTxtP.setTextAlign(Paint.Align.CENTER);
        gunTxtP = fill(Color.WHITE); gunTxtP.setTextSize(25f); gunTxtP.setTextAlign(Paint.Align.CENTER);
        // IP display paint – large, high contrast
        ipPaint = fill(Color.rgb(255,230,80)); ipPaint.setTextSize(28f);
        ipPaint.setTextAlign(Paint.Align.CENTER); ipPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ipPaint.setShadowLayer(4f,0,2f,Color.BLACK);
        // Settings overlay paints
        settingsBgP   = fill(Color.argb(235,10,15,30));
        settingsTitleP= fill(Color.WHITE); settingsTitleP.setTextSize(26f);
        settingsTitleP.setTextAlign(Paint.Align.LEFT); settingsTitleP.setTypeface(Typeface.DEFAULT_BOLD);
        settingsLabelP= fill(Color.argb(210,200,210,230)); settingsLabelP.setTextSize(20f);
        settingsLabelP.setTextAlign(Paint.Align.LEFT);
        optBtnP   = fill(Color.argb(180,40,50,80));
        optBtnSelP= fill(Color.argb(230,80,130,220));
        optTxtP   = fill(Color.WHITE); optTxtP.setTextSize(17f);
        optTxtP.setTextAlign(Paint.Align.CENTER); optTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        closeBtnP = fill(Color.argb(200,180,50,60));
        // Pre-allocated VC paints
        vcOuterGlow.setStyle(Paint.Style.FILL);
        vcMidGlow.setStyle(Paint.Style.FILL);
        vcTrailP.setStyle(Paint.Style.FILL);
        vcTrailCore.setStyle(Paint.Style.FILL);
        vcRingP.setStyle(Paint.Style.STROKE);
        vcRingP2.setStyle(Paint.Style.STROKE); vcRingP2.setStrokeWidth(1.5f);
        vcBladeP.setStyle(Paint.Style.STROKE); vcBladeP.setStrokeCap(Paint.Cap.ROUND);
        vcZapP.setStyle(Paint.Style.STROKE); vcZapP.setStrokeCap(Paint.Cap.ROUND);
        vcCoreHalo.setStyle(Paint.Style.FILL);
        vcCoreP.setStyle(Paint.Style.FILL);
        vcConnP.setStyle(Paint.Style.STROKE); vcConnP.setStrokeWidth(1f);
        // Pre-allocated drawPlayer paints
        dpShadow.setStyle(Paint.Style.FILL);
        dpBody.setStyle(Paint.Style.FILL);
        dpGun.setStyle(Paint.Style.STROKE); dpGun.setStrokeWidth(7f); dpGun.setStrokeCap(Paint.Cap.ROUND);
        dpHpFill.setStyle(Paint.Style.FILL);
        dpName2.set(nameP);
        dpProtRing.setStyle(Paint.Style.STROKE); dpProtRing.setStrokeWidth(4f);
        dpShRing.setStyle(Paint.Style.STROKE); dpShRing.setStrokeWidth(5f); dpShRing.setColor(Color.argb(200,255,200,0));
        // Pre-allocated doDraw paints
        ddAimLine.setColor(Color.argb(160,255,255,255));
        ddAimLine.setStyle(Paint.Style.STROKE); ddAimLine.setStrokeWidth(2.5f);
        ddAimLine.setPathEffect(aimLineDash);
        ddBombArc.setColor(Color.argb(210,255,210,0));
        ddBombArc.setStyle(Paint.Style.STROKE); ddBombArc.setStrokeWidth(3.5f);
        ddBombArc.setPathEffect(bombArcDash);
        // HUD / scoreboard paints
        hudStatLblP.setTextSize(13f); hudStatLblP.setTextAlign(Paint.Align.LEFT);
        hudStatLblP.setColor(Color.argb(180,200,220,255));
        hudStatBgP.setStyle(Paint.Style.FILL); hudStatBgP.setColor(Color.argb(80,255,255,255));
        hudSbHdrP.setTextSize(13f); hudSbHdrP.setTypeface(Typeface.DEFAULT_BOLD);
        hudSbHdrP.setColor(Color.argb(200,150,180,255));
        hudSbHdrP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        hudSbNameP.setTextSize(15f); hudSbNameP.setTextAlign(Paint.Align.LEFT);
        hudSbNameP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        hudSbNumP.setTextSize(15f); hudSbNumP.setTextAlign(Paint.Align.CENTER);
        hudSbNumP.setTypeface(Typeface.DEFAULT_BOLD);
        hudSbNumP.setShadowLayer(2f, 0, 1f, Color.BLACK);
    }
    Paint fill(int c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(c);p.setStyle(Paint.Style.FILL);return p;}

    /** Finds this device's best local IP — works for regular WiFi AND hotspot AP mode. */
    static String detectLocalIp() {
        String best = "???.???.???.???";
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            if (ifaces == null) return best;
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (addr.isLoopbackAddress() || !(addr instanceof Inet4Address)) continue;
                    String ip = addr.getHostAddress();
                    if (ip == null || ip.isEmpty()) continue;
                    best = ip; // keep last found
                    // Hotspot default range — prefer this immediately
                    if (ip.startsWith("192.168.43.") || ip.startsWith("192.168.1.")
                            || ip.startsWith("10.")) return ip;
                }
            }
        } catch (Exception ignored) {}
        return best;
    }

    // ═══ SURFACE ══════════════════════════════════════════════════════════════
    @Override public void surfaceCreated(SurfaceHolder h)  { /* Wait for surfaceChanged which always provides real dimensions */ }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh) { screenW=w; screenH=hh; controls.initControls(); resume(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { pause(); }

    @Override public boolean onTouchEvent(android.view.MotionEvent e) { return controls.onTouchEvent(e); }


    // ═══ LOOP ═════════════════════════════════════════════════════════════════
    public synchronized void resume(){
        if(gameRunning) return;
        gameRunning=true;
        gameThread=new Thread(this,"GameLoop"); gameThread.start();
        // Dedicated UDP sender: the game loop writes broadcastSnapshot; this thread drains it.
        // Keeps the 16ms game-loop budget free of any socket-blocking time.
        senderThread = new Thread(() -> {
            while (gameRunning) {
                String snap = broadcastSnapshot;
                if (snap != null) { broadcastSnapshot = null; net.broadcastState(snap); }
                try { Thread.sleep(1); } catch (InterruptedException e) { break; }
            }
        }, "StateSender");
        senderThread.setDaemon(true);
        senderThread.start();
    }
    public synchronized void pause(){
        gameRunning=false;
        if(senderThread!=null){ senderThread.interrupt(); senderThread=null; }
        if(gameThread!=null) try{gameThread.join(700);}catch(InterruptedException ignored){}
        gameThread=null;
    }
    public void stopGame(){ pause(); if(net!=null) net.stop(); }

    @Override public void run(){
        long prev=System.nanoTime();
        while(gameRunning){
            long now=System.nanoTime();
            float dt=Math.min((now-prev)/1e9f,0.08f); prev=now;
            update(dt); renderer.render();
            long sleep=16_666_000L-(System.nanoTime()-now);
            if(sleep>0) try{Thread.sleep(sleep/1_000_000,(int)(sleep%1_000_000));}catch(InterruptedException ig){}
        }
    }

    // ═══ UPDATE ═══════════════════════════════════════════════════════════════
    void update(float dt){
        tick++;
        if(!isHost && pendingState!=null){ networkBridge.applyState(pendingState); pendingState=null; }

        // ── Shop fling momentum ────────────────────────────────────────────────
        if (shopOpen && Math.abs(shopScrollVelocity) > 0.5f) {
            shopTabScrollY[shopTab] = Math.max(0f,
                Math.min(shopTabScrollMax[shopTab],
                    shopTabScrollY[shopTab] + shopScrollVelocity * dt * 1000f));
            shopScrollVelocity *= 0.88f; // decelerate
            if (Math.abs(shopScrollVelocity) < 0.5f) shopScrollVelocity = 0f;
        }

        // ── Client-side dead-reckoning ─────────────────────────────────────────
        // Between host state packets (~33ms apart), extrapolate remote players
        // forward at their last known velocity so they never freeze or snap.
        if (!isHost) {
            long _drNow = System.currentTimeMillis();
            for (Player rp : remote.values()) {
                if (rp.alive && rp.netUpdateMs >= 0) {
                    long _age = _drNow - rp.netUpdateMs;
                    // Extrapolate up to 120ms; beyond that the player has stopped or packet is lost
                    if (_age > 0 && _age < 120) {
                        rp.x = clamp(rp.netX + rp.netVX * _age, PR, MAP_W - PR);
                        rp.y = clamp(rp.netY + rp.netVY * _age, PR, MAP_H - PR);
                    }
                }
            }
        }

        Player lp = localPlayer;  // snapshot reference — safe
        if(lp==null) return;

        if(lp.alive) {
            float rm = lp.reloadMult();
            for(Gun g:lp.guns) g.tick(rm);
        }

        if(isHost&&!lp.alive&&System.currentTimeMillis()-deathTime>=RESPAWN_MS)
            respawn(lp);

        if(lp.alive) moveAndAim(lp, dt);

        // Smooth dash animation — override position while active
        if (effects.dashAnimating) {
            long elapsed = System.currentTimeMillis() - effects.dashAnimBegin;
            float t = Math.min(1f, (float)elapsed / EffectsManager.DASH_ANIM_MS);
            // Ease-out cubic: fast start, gentle stop — feels like a real dash
            float ease = 1f - (1f - t) * (1f - t) * (1f - t);
            lp.x = effects.dashAnimStartX + (effects.dashAnimEndX - effects.dashAnimStartX) * ease;
            lp.y = effects.dashAnimStartY + (effects.dashAnimEndY - effects.dashAnimStartY) * ease;
            if (t >= 1f) { lp.x = effects.dashAnimEndX; lp.y = effects.dashAnimEndY; effects.dashAnimating = false; effects.isPhantomDashing = false; }

            // ── Emit aftereffect ghost at current position ─────────────────
            long nowGhost = System.currentTimeMillis();
            if (nowGhost - lastGhostTimeMs >= 16) {   // ~60fps cap
                if (effects.isPhantomDashing) {
                    effects.phantomDashGhosts.add(new float[]{lp.x, lp.y, (float)(nowGhost - EffectsManager.FX_EPOCH)});
                } else {
                    effects.dashGhosts.add(new float[]{lp.x, lp.y, (float)(nowGhost - EffectsManager.FX_EPOCH)});
                }
                lastGhostTimeMs = nowGhost;
            }
        }

        // ── Bot dash visual animation — expire finished entries ────────────────
        if (!botDashVisual.isEmpty()) {
            long nowAnim = System.currentTimeMillis() - EffectsManager.FX_EPOCH;
            botDashVisual.entrySet().removeIf(e -> nowAnim - (long)e.getValue()[4] >= EffectsManager.DASH_ANIM_MS);
        }


        // Track player velocity for AI predictive aiming (px / update)
        if (lpPrevX >= 0f) {
            lpVelX = lp.x - lpPrevX;
            lpVelY = lp.y - lpPrevY;
        }
        lpPrevX = lp.x;
        lpPrevY = lp.y;

        updateBullets(lp, dt);
        updateBombs(lp, dt);
        updateAirStrikes(lp);
        updateVoltChakrams(lp, dt);
        updateHookPulls(dt);
        resolvePlayerCollisions();
        applyPoisonTicks(lp);

        if(isHost){
            applyClientInputs(dt);
            networkBridge.drainNetEvents(); // FIX: apply queued bomb/VC events from network thread on game thread
            if(!botIds.isEmpty()) updateBots(dt);
            // Update volt chakrams for remote players (hit detection runs on host)
            for (Player rp : remote.values()) {
                if (rp.alive && isVoltChakram(rp.currentGun())) updateVoltChakrams(rp, dt);
            }
            checkRemoteRespawns();
            if(!singlePlayer && System.currentTimeMillis()-lastBroadcast>33){ networkBridge.broadcast(); lastBroadcast=System.currentTimeMillis(); }
        } else {
            networkBridge.sendInput(lp); // send every frame (60 Hz) for minimal input lag
        }

        // Smooth per-weapon zoom  (global 0.85 scale already baked into GunConfig)
        float targetZoom = (lp.alive) ? lp.currentGun().zoom : 0.85f;
        currentZoom += (targetZoom - currentZoom) * 0.07f;

        // Aim pan — shift camera toward aim stick so the player sees further ahead.
        // Vertical pan is stronger (PAN_Y > PAN_X) but we blend by direction so
        // diagonals feel smooth rather than snapping between the two extremes.
        final float PAN_X = 200f;
        final float PAN_Y = 340f;
        float aimPanTargetX = 0f, aimPanTargetY = 0f;
        if (!throwingBomb && aimStick != null && aimStick.isActive() && !isShadowBlade(lp.currentGun())) {
            float _sx = aimStick.getX(), _sy = aimStick.getY();
            float _mag = (float) Math.sqrt(_sx * _sx + _sy * _sy);
            if (_mag > 0.01f) {
                // vertFrac=0 → pure horizontal (use PAN_X), vertFrac=1 → pure vertical (use PAN_Y)
                float vertFrac = Math.abs(_sy) / _mag;
                float panR = PAN_X + (PAN_Y - PAN_X) * vertFrac;
                aimPanTargetX = _sx * panR;
                aimPanTargetY = _sy * panR;
            }
        }
        camPanX += (aimPanTargetX - camPanX) * 0.09f;
        camPanY += (aimPanTargetY - camPanY) * 0.09f;

        camX = lp.x + camPanX - screenW / (2f * currentZoom);
        camY = lp.y + camPanY - screenH / (2f * currentZoom);
    }

    void moveAndAim(Player lp, float dt){
        if(moveStick==null||aimStick==null) return;
        // Hook Spear: pull overrides movement; stun freezes player entirely
        if (lp.isBeingPulled() || lp.isStunned()) return;
        float spd = 280f * lp.moveSpeedMult() * (lp.isSlowed() ? lp.slowSpeedMult : 1.0f) * (lp.isStealthed() ? 1.3f : 1.0f);
        float nx=lp.x+moveStick.getX()*spd*dt;
        float ny=lp.y+moveStick.getY()*spd*dt;
        nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
        float[] pos=walls(lp.x,lp.y,nx,ny);
        lp.x=pos[0]; lp.y=pos[1];

        float ax=aimStick.getX(), ay=aimStick.getY();
        if(ax*ax+ay*ay>0.01f){
            float targetAngle=(float)Math.atan2(ay,ax);
            // Aim sensitivity: 0=slow(0.10) 1=norm(0.35) 2=fast(1.0)
            float[] sensVals = {0.10f, 0.35f, 1.0f};
            float sens = sensVals[Math.max(0,Math.min(2,cachedAimSens))];
            lp.angle = lerpAngle(lp.angle, targetAngle, sens);
        }

        Gun g=lp.currentGun();
        // ── Cheat: infinite ammo — keep every gun topped up, never reload ────
        if (cheatInfiniteAmmo) {
            for (Gun cg : lp.guns) { cg.ammo = cg.maxAmmo; cg.reloading = false; }
        }
        // ── Cheat: no skill cooldown — reset CD every frame ──────────────────
        if (cheatNoSkillCd) { lp.skillCooldownEnd = 0; }
        // Auto-reload when clip is empty
        if(g.ammo<=0 && !g.reloading && !isVoltChakram(g)) g.startReload();

        // ── Volt Chakram: spin aim stick to charge; fire handled on stick-up ─
        if (isVoltChakram(g)) {
            // Passive idle orbit spin
            voltOrbitAngle += dt * 1.4f;
            // Hold aim stick to charge — orbit ring spins faster as power builds.
            // No joystick spinning needed; fully compatible with aim panning.
            if (aimStick.isActive() && ax*ax + ay*ay > 0.04f) {
                voltCharge = Math.min(1f, voltCharge + dt * 0.38f); // full charge in ~2.6s
            } else {
                voltCharge = Math.max(0f, voltCharge - dt * 0.25f); // slow decay when idle
            }
            // Orbit ring accelerates hard with charge: 1.5 rad/s idle → 18 rad/s full
            voltOrbitAngle += dt * (1.5f + voltCharge * voltCharge * 16.5f);
            return; // skip normal bullet fire
        }

        // ── Shadow Blade: hold aim stick to charge; release dashes and slashes ─
        if (isShadowBlade(g)) {
            if (aimStick.isActive() && ax*ax + ay*ay > 0.04f) {
                shadowBladeCharge = Math.min(1f, shadowBladeCharge + dt * 0.83f); // full in ~1.2s
            }
            // Charge is RETAINED when stick released — only resets on fire (launchShadowBlade sets it to 0)
            return; // fire happens on stick-up via launchShadowBlade
        }

        // Fire with passive fire-rate bonus applied
        float aimMag2 = ax*ax + ay*ay;
        float fireThreshVal = getFireThresh();
        // Per-gun release-fire: skip continuous firing; bullet spawned on stick-up instead
        boolean fireOnRelease = cachedRelFire[lp.gunIndex]; // FIX: was reading disk at 60fps
        boolean isAirStrike = g.bulletAirStrike;

        // Air Strike: track aim angle/mag from stick continuously (blocked while reloading)
        if (isAirStrike && aimStick.isActive()) {
            if (g.reloading) {
                asAimAngle = Float.NaN; asAimMag = 0f; // no aiming while reloading
            } else {
            float _ax = ax, _ay = ay;
            float _mag = (float) Math.sqrt(_ax*_ax + _ay*_ay);
            // Hide ring if walking
            float mvx = moveStick.getX(), mvy = moveStick.getY();
            if (mvx*mvx + mvy*mvy > 0.15f*0.15f) {
                asAimAngle = Float.NaN; asAimMag = 0f;
            } else if (_mag > 0.05f) {
                asAimAngle = (float)Math.atan2(_ay, _ax);
                asAimMag   = Math.min(1f, _mag);
            }
            }
        }

        if(!throwingBomb && aimStick.isActive() && aimMag2 > fireThreshVal*fireThreshVal
                && !fireOnRelease && !isAirStrike){
            float frMult = lp.fireRateMult();
            long fireCooldown = (long)(1000f / (g.fireRate * frMult));
            boolean canFire = g.ammo > 0 && !g.reloading
                    && System.currentTimeMillis() - g.lastFireTime >= fireCooldown;
            if(canFire){ spawnBullets(lp); g.markFired(); }
        }
    }

    float[] walls(float ox,float oy,float nx,float ny){
        for(float[] w:WALLS){
            float cx=clamp(nx,w[0],w[2]), cy=clamp(ny,w[1],w[3]);
            float distSq=d2(nx,ny,cx,cy);
            if(distSq<PR*PR){
                float cx2=clamp(nx,w[0],w[2]), cy2=clamp(oy,w[1],w[3]);
                boolean xBlocked=d2(nx,oy,cx2,cy2)<PR*PR;
                float cx3=clamp(ox,w[0],w[2]), cy3=clamp(ny,w[1],w[3]);
                boolean yBlocked=d2(ox,ny,cx3,cy3)<PR*PR;
                if(xBlocked) nx=ox;
                if(yBlocked) ny=oy;
                if(!xBlocked&&!yBlocked){
                    // Corner hit: neither axis alone penetrates the wall face.
                    // Push player out along the corner->player vector so the
                    // circle sits exactly at radius PR from the corner.
                    if(distSq>0f){
                        float dist=(float)Math.sqrt(distSq);
                        nx=cx+(nx-cx)/dist*PR;
                        ny=cy+(ny-cy)/dist*PR;
                    } else {
                        nx=ox; ny=oy; // fully inside wall — full revert
                    }
                }
            }
        }
        return new float[]{nx,ny};
    }

    /** Shortest-path angle lerp accounting for ±π wrap. */
    float lerpAngle(float from, float to, float t){
        float d=to-from;
        while(d>(float)Math.PI) d-=(float)(Math.PI*2);
        while(d<-(float)Math.PI) d+=(float)(Math.PI*2);
        return from+d*t;
    }

    void spawnBullets(Player p){
        Gun g=p.guns[p.gunIndex];
        if(g.ammo<=0) return;

        // ── Air Strike: queue strikes at ring-aimed position ──────────────────
        if (g.bulletAirStrike) {
            if (Float.isNaN(asAimAngle)) return; // no target selected yet
            g.ammo--;
            if(p.isStealthed()) p.skillActiveUntil = 0;
            long now = System.currentTimeMillis();
            // Target world position: joystick magnitude maps 0→player, 1→ring edge
            float targetDist = asAimMag * AS_RING_R;
            float cx = p.x + (float)Math.cos(asAimAngle) * targetDist;
            float cy = p.y + (float)Math.sin(asAimAngle) * targetDist;
            cx = Math.max(0, Math.min(MAP_W, cx));
            cy = Math.max(0, Math.min(MAP_H, cy));
            // Triple explosion: fires 3 times with stagger after warning
            long triggerMs = now + AS_WARNING_MS;
            airStrikes.add(new double[]{cx, cy, (double)triggerMs, (double)p.id, 0.0, 2.0});
            asAimAngle = Float.NaN; asAimMag = 0f;
            return;
        }

        // FIX: Shadow Blade is purely melee — launchShadowBlade handles all its logic.
        // Without this guard, applyClientInputs was spawning real travelling bullets
        // for the Shadow Blade gun whenever fire-input was high, causing phantom
        // damage that had nothing to do with the dash-slash mechanic.
        if (g.bulletShadowBlade) return;

        g.ammo--;
        // Firing breaks stealth immediately
        if(p.isStealthed()) p.skillActiveUntil = 0;
        // Coin Gun: scale damage with wealth  (20 @ 0 coins → 120 @ 600 coins)
        float coinDmg = g.coinScaling ? 20f + Math.min(p.coins, 600) * 0.167f : g.damage;
        for(int i=0;i<g.pellets;i++){
            float s=(float)(Math.random()-0.5)*g.spread*2, a=p.angle+s;
            float spd=g.bulletSpeed*(0.96f+(float)Math.random()*0.08f);
            float rangeVal = g.range * p.rangeMult();
            float dmg = g.coinScaling ? coinDmg : g.damage;
            Bullet bl = new Bullet(p.x,p.y,(float)Math.cos(a)*spd,(float)Math.sin(a)*spd,p.id,dmg,bulletId++,rangeVal);
            bl.bouncesLeft  = g.bulletBounces;
            bl.piercing     = g.bulletPiercing;
            bl.explosive    = g.bulletExplosive;
            bl.homing       = g.bulletHoming;
            bl.ghost        = g.bulletGhost;
            bl.hookSpear    = g.bulletHookSpear;
            bl.isSoulReaper = (p.gunIndex == 20);
            bl.soulTier     = (p.gunIndex == 20) ? p.guns[20].soulLevel() : 0;
            bl.isShadowBlade = (p.gunIndex == 21);
            // Paint color: 1=blue(slow), 2=green(poison), 3=per-shot alternating (toggle each shot)
            if(g.paintBulletColor==3) {
                if (g.paintMode == 1) { bl.paintColor = 1; }       // SLOW mode — always blue
                else if (g.paintMode == 2) { bl.paintColor = 2; }  // POISON mode — always green
                else { bl.paintColor = g.paintShotToggle; }         // ALT mode — toggling
            }
            else bl.paintColor = g.paintBulletColor;
            bl.slowDurationMs   = g.slowMs;
            bl.slowSpeedMult    = g.slowSpeedMult;
            bl.poisonDurationMs = g.poisonMs;
            bl.poisonTickDamage = g.poisonDmg;
            bl.stunBonusMs      = g.stunBonusMs;
            bl.explosionDmg     = g.explosionDmg;
            if(bl.piercing) bl.hitIds = new HashSet<>();
            bullets.add(bl);
        }
        // Per-shot paint toggle: flip between poison(2) and slow(1) after each shot (ALT mode only)
        if(g.paintBulletColor==3 && g.paintMode==0) g.paintShotToggle = (g.paintShotToggle == 2) ? 1 : 2;
    }

    void updateBombs(Player lp, float dt) {
        if (!isHost) return;
        long now = System.currentTimeMillis();
        Iterator<Bomb> it = activeBombs.iterator();
        while (it.hasNext()) {
            Bomb b = it.next();
            if (b.isDone()) { it.remove(); continue; }

            // ── Move the bomb while in flight ─────────────────────────────────
            if (!b.hasLanded) {
                float nx = b.x + b.vx * dt;
                float ny = b.y + b.vy * dt;
                boolean outOfRange = b.traveledSq() >= b.maxRange * b.maxRange;
                boolean outOfMap   = nx < 0 || nx > MAP_W || ny < 0 || ny > MAP_H;

                if (outOfRange || outOfMap) {
                    // Clamp to map and land with a roll in current travel direction
                    nx = Math.max(0, Math.min(MAP_W, nx));
                    ny = Math.max(0, Math.min(MAP_H, ny));
                    b.x = nx; b.y = ny;
                    b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                    b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                    b.hasLanded = true; b.vx = 0; b.vy = 0;
                } else {
                    // Axis-separated wall bounce so the reflection axis is correct
                    boolean xBlocked = false, yBlocked = false;
                    for (float[] w : WALLS) {
                        if (!xBlocked && nx >= w[0] && nx <= w[2] && b.y >= w[1] && b.y <= w[3]) xBlocked = true;
                        if (!yBlocked && b.x >= w[0] && b.x <= w[2] && ny >= w[1] && ny <= w[3]) yBlocked = true;
                    }
                    if (xBlocked) b.vx = -b.vx * Bomb.BOUNCE_RESTITUTION;
                    if (yBlocked) b.vy = -b.vy * Bomb.BOUNCE_RESTITUTION;
                    if (xBlocked || yBlocked) {
                        // Bounced off a wall — land and give roll velocity in reflected direction
                        b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                        b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                        b.hasLanded = true; b.vx = 0; b.vy = 0;
                    } else {
                        b.x = nx; b.y = ny;
                    }
                }
            }

            // ── Roll the bomb along the ground with friction ───────────────────
            if (b.hasLanded && (b.rollVx != 0 || b.rollVy != 0)) {
                float speed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                float decel = Bomb.ROLL_FRICTION * dt;
                if (decel >= speed) {
                    b.rollVx = 0; b.rollVy = 0;
                } else {
                    float factor = (speed - decel) / speed;
                    b.rollVx *= factor;
                    b.rollVy *= factor;
                    float rnx = b.x + b.rollVx * dt;
                    float rny = b.y + b.rollVy * dt;
                    // Axis-separated wall bounce while rolling (damped)
                    boolean rxBlocked = false, ryBlocked = false;
                    for (float[] w : WALLS) {
                        if (!rxBlocked && rnx >= w[0] && rnx <= w[2] && b.y >= w[1] && b.y <= w[3]) rxBlocked = true;
                        if (!ryBlocked && b.x >= w[0] && b.x <= w[2] && rny >= w[1] && rny <= w[3]) ryBlocked = true;
                    }
                    if (rxBlocked) b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION;
                    if (ryBlocked) b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION;
                    // Apply map boundary bounce
                    if (rnx < 0 || rnx > MAP_W) { b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION; rnx = Math.max(0, Math.min(MAP_W, rnx)); }
                    if (rny < 0 || rny > MAP_H) { b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION; rny = Math.max(0, Math.min(MAP_H, rny)); }
                    if (!rxBlocked) b.x = rnx;
                    if (!ryBlocked) b.y = rny;
                    // Kill negligible roll after bouncing
                    float newSpeed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                    if (newSpeed < Bomb.MIN_ROLL_SPEED) { b.rollVx = 0; b.rollVy = 0; }
                }
            }

            // ── Explode when fuse burns out ───────────────────────────────────
            if (b.shouldExplode()) {
                b.explodedAt = now;
                // Damage local player (no friendly fire)
                if (lp.alive && b.ownerId != lp.id
                        && d2(b.x, b.y, lp.x, lp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                    if(!lp.isProtected()){
                        float dmg = Bomb.DAMAGE;
                        if(lp.isShielded()){
                            float reduced=dmg*0.5f;float abs=Math.min(reduced,lp.shieldHp); lp.shieldHp-=abs; dmg-=abs;
                            if(lp.shieldHp<=0) lp.skillActiveUntil=0;
                        }
                        lp.hp = Math.max(0, lp.hp - dmg);
                        if (lp.hp == 0) {
                            lp.alive = false; deathTime = now;
                            addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + lp.name);
                            onKill(remote.get(b.ownerId), lp);
                        }
                    }
                }
                // Damage remote players
                for (Player rp : remote.values()) {
                    if (!rp.alive || b.ownerId == rp.id) continue;
                    if (d2(b.x, b.y, rp.x, rp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                        if(!rp.isProtected()){
                            float dmg = Bomb.DAMAGE;
                            if(rp.isShielded()){
                                float reduced=dmg*0.5f;float abs=Math.min(reduced,rp.shieldHp); rp.shieldHp-=abs; dmg-=abs;
                                if(rp.shieldHp<=0) rp.skillActiveUntil=0;
                            }
                            rp.hp = Math.max(0, rp.hp - dmg);
                            if (rp.hp == 0) {
                                rp.alive = false; deadAtMs.put(rp.id, now);
                                if (!dummyIds.contains(rp.id)) {
                                    addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + rp.name);
                                    if (b.ownerId == lp.id) {
                                        onKill(lp, rp);
                                    } else {
                                        Player killer = remote.get(b.ownerId);
                                        onKill(killer, rp);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ═══ AIR STRIKE ══════════════════════════════════════════════════════════

    void updateAirStrikes(Player lp) {
        if (!isHost) return;
        long now = System.currentTimeMillis();
        Iterator<double[]> it = airStrikes.iterator();
        while (it.hasNext()) {
            double[] as = it.next();
            float sx = (float) as[0], sy = (float) as[1];
            long triggerMs = (long) as[2];
            int ownerId = (int) as[3];
            long flashUntil = (long) as[4];

            // Not yet triggered
            if (now < (long) triggerMs) continue;

            // Trigger: do damage once (flashUntil == 0 means not yet exploded)
            if (flashUntil == 0L) {
                as[4] = now + AS_FLASH_MS;
                // Damage local player
                if (lp != null && lp.alive && ownerId != lp.id
                        && d2(sx, sy, lp.x, lp.y) < AS_RADIUS * AS_RADIUS) {
                    if (!lp.isProtected()) {
                        float dmg = AS_DAMAGE;
                        if (lp.isShielded()) {
                            float reduced = dmg * 0.5f;
                            float abs = Math.min(reduced, lp.shieldHp);
                            lp.shieldHp -= abs; dmg -= abs;
                            if (lp.shieldHp <= 0) lp.skillActiveUntil = 0;
                        }
                        lp.hp = Math.max(0, lp.hp - dmg);
                        if (lp.hp == 0) {
                            lp.alive = false; deathTime = now;
                            addFeed(nameOf(ownerId) + " ✈ " + lp.name);
                            onKill(remote.get(ownerId), lp);
                        }
                    }
                }
                // Damage bots and remote players
                for (Player p : remote.values()) {
                    if (p.id == ownerId || !p.alive) continue;
                    if (d2(sx, sy, p.x, p.y) < AS_RADIUS * AS_RADIUS) {
                        if(!p.isProtected()){
                            float dmg = AS_DAMAGE;
                            if(p.isShielded()){
                                float reduced=dmg*0.5f;float abs=Math.min(reduced,p.shieldHp);p.shieldHp-=abs;dmg-=abs;
                                if(p.shieldHp<=0) p.skillActiveUntil=0;
                            }
                            p.hp = Math.max(0, p.hp - dmg);
                            if (p.hp == 0) {
                                p.alive = false;
                                deadAtMs.put(p.id, now); // FIX Bug1: air strike kills now trigger respawn
                                if (!dummyIds.contains(p.id)) {
                                    addFeed(nameOf(ownerId) + " ✈ " + p.name);
                                    Player asKiller = (lp != null && lp.id == ownerId) ? lp : remote.get(ownerId);
                                    onKill(asKiller, p);
                                }
                            }
                        }
                    }
                }
            }

            // Chain next explosion if remaining, else remove when flash is done
            if (now > (long) as[4] && as[4] > 0f) {
                int remaining = (as.length > 5) ? (int) as[5] : 0;
                if (remaining > 0) {
                    // Scatter next explosion randomly near original target
                    float scatter = AS_RADIUS * 0.9f; // scatter up to ~1 explosion radius away
                    float nx = (float)(as[0] + (Math.random() - 0.5) * 2.0 * scatter);
                    float ny = (float)(as[1] + (Math.random() - 0.5) * 2.0 * scatter);
                    as[0] = Math.max(0, Math.min(MAP_W, nx));
                    as[1] = Math.max(0, Math.min(MAP_H, ny));
                    as[2] = now + 550L;  // next trigger in 550ms
                    as[4] = 0L;           // reset flash (not yet exploded)
                    as[5] = remaining - 1;
                } else {
                    it.remove();
                }
            }
        }
    }

    // ═══ VOLT CHAKRAM ══════════════════════════════════════════════════════════

    boolean isVoltChakram(Gun g) {
        return g != null && "Volt Chakram".equals(g.name);
    }

    boolean isShadowBlade(Gun g) {
        return g != null && "Shadow Blade".equals(g.name);
    }

    /**
     * Quick Slash — instant short-range melee strike, no charge required.
     * Triggered by the SKILL button while Shadow Blade is equipped.
     * Lower damage than the full charged dash-slash; plays a tighter arc effect.
     */
    void launchQuickSlash(Player lp, float nx, float ny) {
        if (!isHost) return;   // clients only queue; host executes authoritatively
        Gun g = lp.currentGun();
        if (g.ammo <= 0 || g.reloading) return;

        float launchAngle = (float) Math.atan2(ny, nx);
        float slashRange  = 150f;   // shorter than the full charged slash (280f dash + 160f static)
        float damage      = 40f;    // lighter than the full 50f charged slash
        float hitWidth    = 32f;

        // Small lunge — step the player forward so the slash feels aggressive
        float lungeAmount = 35f;
        float[] lungeEnd  = dashWithWallStop(lp.x, lp.y, launchAngle, lungeAmount);
        lp.x = lungeEnd[0];
        lp.y = lungeEnd[1];

        float startX = lp.x, startY = lp.y;
        float endX   = startX + nx * slashRange;
        float endY   = startY + ny * slashRange;

        if (lp.isStealthed()) lp.skillActiveUntil = 0;

        // Hit detection along the slash segment
        float ldx = endX - startX, ldy = endY - startY;
        float lenSq = ldx*ldx + ldy*ldy;
        Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
        proxy.isShadowBlade = true;

        for (Player rp : remote.values()) {
            if (!rp.alive || rp.id == lp.id) continue;
            if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                applyBulletDamage(proxy, localPlayer != null ? localPlayer : lp, rp, localPlayer != null ? localPlayer : lp);
                proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                proxy.isShadowBlade = true;
            }
        }
        if (localPlayer != null && localPlayer.alive && localPlayer.id != lp.id) {
            if (pointToSegDist(localPlayer.x, localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                applyBulletDamage(proxy, localPlayer, null, localPlayer);
        }

        // Crescent arc — slightly larger radius so it looks distinct from the full slash
        float fxScale = 0.85f;
        long now = System.currentTimeMillis();
        // Anchor FX at midpoint so the arc appears right in front of the player
        float fxX = (startX + endX) * 0.5f;
        float fxY = (startY + endY) * 0.5f;
        effects.slashTrails.add(new float[]{fxX, fxY, 55f * fxScale, now - EffectsManager.FX_EPOCH, launchAngle, 0});
        effects.slashTrails.add(new float[]{fxX, fxY, 47f * fxScale, now - EffectsManager.FX_EPOCH, launchAngle, 1});
        effects.slashTrails.add(new float[]{fxX, fxY, 60f * fxScale, now - EffectsManager.FX_EPOCH, launchAngle, 2});
        effects.crescentFx.add(new float[]{fxX, fxY, launchAngle, (float)(now - EffectsManager.FX_EPOCH)});

        g.ammo--;
        g.markFired();
    }

    void launchShadowBlade(Player lp, float ax, float ay) {
        // FIX: removed "if (!isHost) return" — the host now runs this for remote players
        // too (via netSbQ). Clients that fire locally just reset their charge and return;
        // the actual damage/dash/trail is applied authoritatively on the host.
        if (!isHost) { shadowBladeCharge = 0f; return; }
        Gun g = lp.currentGun();
        if (g.ammo <= 0 || g.reloading) return;
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.05f) return;

        float charge = shadowBladeCharge;
        // Minimum charge to do anything — below this it fizzles
        if (charge < 0.05f) { shadowBladeCharge = 0f; return; }
        float launchAngle = (float) Math.atan2(ay / mag, ax / mag);
        long fxNow = System.currentTimeMillis();

        if (lp.isStealthed()) lp.skillActiveUntil = 0;

        float startX = lp.x, startY = lp.y;
        float endX, endY;

        // ════════════════════════════════════════════════════════════════════
        // Tier 1 — Light Slash  (charge < 0.40)
        // Quick forward poke with a short lunge.
        // ════════════════════════════════════════════════════════════════════
        if (charge < 0.40f) {
            float damage   = 35f;
            float hitWidth = 28f;
            float slashRange = 140f;

            float[] lungeEnd = dashWithWallStop(startX, startY, launchAngle, 40f);
            lp.x = lungeEnd[0]; lp.y = lungeEnd[1];
            startX = lp.x; startY = lp.y;
            endX = startX + (float)Math.cos(launchAngle) * slashRange;
            endY = startY + (float)Math.sin(launchAngle) * slashRange;

            float ldx = endX - startX, ldy = endY - startY;
            float lenSq = ldx*ldx + ldy*ldy;
            Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
            proxy.isShadowBlade = true;
            for (Player rp : remote.values()) {
                if (!rp.alive || rp.id == lp.id) continue;
                if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                    applyBulletDamage(proxy, localPlayer != null ? localPlayer : lp, rp, localPlayer != null ? localPlayer : lp);
                    proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                    proxy.isShadowBlade = true;
                }
            }
            if (localPlayer != null && localPlayer.alive && localPlayer.id != lp.id)
                if (pointToSegDist(localPlayer.x, localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                    applyBulletDamage(proxy, localPlayer, null, localPlayer);

            // FX — tight crescent at mid-point
            float fxX = (startX + endX) * 0.5f, fxY = (startY + endY) * 0.5f;
            float fxTs = (float)(fxNow - EffectsManager.FX_EPOCH);
            float fxSc = 0.6f;
            effects.slashTrails.add(new float[]{fxX, fxY, 48f*fxSc, fxTs, launchAngle, 0});
            effects.slashTrails.add(new float[]{fxX, fxY, 40f*fxSc, fxTs, launchAngle, 1});
            effects.crescentFx.add(new float[]{fxX, fxY, launchAngle, fxTs});

        // ════════════════════════════════════════════════════════════════════
        // Tier 2 — Heavy Slash  (0.40 ≤ charge < 0.85)
        // Strong lunge + wide sweep, no full dash.
        // ════════════════════════════════════════════════════════════════════
        } else if (charge < 0.85f) {
            float damage   = 65f;
            float hitWidth = 36f;
            float slashRange = 200f;

            float[] lungeEnd = dashWithWallStop(startX, startY, launchAngle, 85f);
            lp.x = lungeEnd[0]; lp.y = lungeEnd[1];
            startX = lp.x; startY = lp.y;
            endX = startX + (float)Math.cos(launchAngle) * slashRange;
            endY = startY + (float)Math.sin(launchAngle) * slashRange;

            float ldx = endX - startX, ldy = endY - startY;
            float lenSq = ldx*ldx + ldy*ldy;
            Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
            proxy.isShadowBlade = true;
            for (Player rp : remote.values()) {
                if (!rp.alive || rp.id == lp.id) continue;
                if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                    applyBulletDamage(proxy, localPlayer != null ? localPlayer : lp, rp, localPlayer != null ? localPlayer : lp);
                    proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                    proxy.isShadowBlade = true;
                }
            }
            if (localPlayer != null && localPlayer.alive && localPlayer.id != lp.id)
                if (pointToSegDist(localPlayer.x, localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                    applyBulletDamage(proxy, localPlayer, null, localPlayer);

            // FX — two crescents at 1/3 and 2/3 of slash
            float fxTs = (float)(fxNow - EffectsManager.FX_EPOCH);
            float fxSc = 0.88f;
            float fx1x = startX + (float)Math.cos(launchAngle) * slashRange * 0.35f;
            float fx1y = startY + (float)Math.sin(launchAngle) * slashRange * 0.35f;
            float fx2x = startX + (float)Math.cos(launchAngle) * slashRange * 0.70f;
            float fx2y = startY + (float)Math.sin(launchAngle) * slashRange * 0.70f;
            effects.slashTrails.add(new float[]{fx1x, fx1y, 55f*fxSc, fxTs, launchAngle, 0});
            effects.slashTrails.add(new float[]{fx1x, fx1y, 46f*fxSc, fxTs, launchAngle, 1});
            effects.slashTrails.add(new float[]{fx2x, fx2y, 58f*fxSc, fxTs+60f, launchAngle, 0});
            effects.slashTrails.add(new float[]{fx2x, fx2y, 49f*fxSc, fxTs+60f, launchAngle, 2});
            effects.crescentFx.add(new float[]{fx1x, fx1y, launchAngle, fxTs});
            effects.crescentFx.add(new float[]{fx2x, fx2y, launchAngle, fxTs + 80f});

        // ════════════════════════════════════════════════════════════════════
        // Tier 3 — Phantom Dash  (charge ≥ 0.85)
        // Full dash + devastating long slash. Maximum damage.
        // ════════════════════════════════════════════════════════════════════
        } else {
            float damage   = 90f;
            float hitWidth = 44f;
            float dashDist = 300f;
            float slashExt = 220f; // extra reach beyond the dash end

            float[] dashEnd = dashWithWallStop(startX, startY, launchAngle, dashDist);
            endX = dashEnd[0] + (float)Math.cos(launchAngle) * slashExt;
            endY = dashEnd[1] + (float)Math.sin(launchAngle) * slashExt;

            // Animate dash for local player — use beginPhantomDash for dark-gold FX
            if (lp == localPlayer) {
                effects.beginPhantomDash(startX, startY, dashEnd[0], dashEnd[1]);
                lp.x = dashEnd[0]; lp.y = dashEnd[1];
            } else {
                lp.x = dashEnd[0]; lp.y = dashEnd[1];
            }

            float ldx = endX - startX, ldy = endY - startY;
            float lenSq = ldx*ldx + ldy*ldy;
            Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
            proxy.isShadowBlade = true;
            for (Player rp : remote.values()) {
                if (!rp.alive || rp.id == lp.id) continue;
                if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                    applyBulletDamage(proxy, localPlayer != null ? localPlayer : lp, rp, localPlayer != null ? localPlayer : lp);
                    proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                    proxy.isShadowBlade = true;
                }
            }
            if (localPlayer != null && localPlayer.alive && localPlayer.id != lp.id)
                if (pointToSegDist(localPlayer.x, localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                    applyBulletDamage(proxy, localPlayer, null, localPlayer);

            // FX — three crescents along the full path + large outer trail
            float fxTs = (float)(fxNow - EffectsManager.FX_EPOCH);
            float fxSc = 1.15f;
            float totalLen = (float)Math.sqrt((endX-startX)*(endX-startX)+(endY-startY)*(endY-startY));
            for (int i = 1; i <= 3; i++) {
                float frac = i * 0.28f;
                float fxX = startX + (float)Math.cos(launchAngle) * totalLen * frac;
                float fxY = startY + (float)Math.sin(launchAngle) * totalLen * frac;
                float delay = i * 55f;
                effects.slashTrails.add(new float[]{fxX, fxY, 55f*fxSc, fxTs+delay, launchAngle, 0});
                effects.slashTrails.add(new float[]{fxX, fxY, 47f*fxSc, fxTs+delay, launchAngle, 1});
                effects.slashTrails.add(new float[]{fxX, fxY, 62f*fxSc, fxTs+delay, launchAngle, 2});
                effects.crescentFx.add(new float[]{fxX, fxY, launchAngle, fxTs + delay});
            }
        }

        g.ammo--;
        g.markFired();
        shadowBladeCharge = 0f;
    }

    /** Shortest distance from point (px,py) to segment (ax,ay)→(bx,by). lenSq = |b-a|². */
    float pointToSegDist(float px, float py,
                                  float ax, float ay, float bx, float by, float lenSq) {
        if (lenSq == 0f) return (float) Math.sqrt((px-ax)*(px-ax)+(py-ay)*(py-ay));
        float t = ((px-ax)*(bx-ax)+(py-ay)*(by-ay)) / lenSq;
        t = Math.max(0f, Math.min(1f, t));
        float cx = ax + t*(bx-ax), cy = ay + t*(by-ay);
        return (float) Math.sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
    }

    /** Ensure exactly 3 chakrams (one per orbit slot) exist for lp; remove orbiters if gun switched away. */
    void ensureVoltChakrams(Player lp) {
        boolean vcSelected = isVoltChakram(lp.currentGun());
        if (!vcSelected) {
            // Remove only ORBITING discs — launched/returning ones keep flying
            voltChakrams.removeIf(vc -> vc.ownerId == lp.id && vc.state == VoltChakram.ORBITING);
            return;
        }
        // Which of the 3 orbit slots already have a disc (any state)?
        boolean[] hasIdx = {false, false, false};
        for (VoltChakram vc : voltChakrams)
            if (vc.ownerId == lp.id && vc.orbitIdx >= 0 && vc.orbitIdx < 3)
                hasIdx[vc.orbitIdx] = true;
        for (int i = 0; i < 3; i++)
            if (!hasIdx[i]) voltChakrams.add(new VoltChakram(lp.id, i));
    }

    /** Called on aim-stick release when Volt Chakram is equipped. */
    void launchVoltChakrams(Player lp, float ax, float ay) {
        launchVoltChakrams(lp, ax, ay, voltCharge);
    }
    void launchVoltChakrams(Player lp, float ax, float ay, float charge) {
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.05f) return;          // no direction — don't launch
        float launchAngle = (float) Math.atan2(ay / mag, ax / mag);
        float speed  = 820f + charge * 680f;   // 820–1500 px/s (faster with charge)
        float damage = 18f  + charge * 24f;    // 18–42 per disc
        float range  = 660f + charge * 640f;   // 660–1300 px (longer with charge)
        // Three discs fan out — spread CONDENSES as charge builds (0.21→0.06 rad)
        float spreadAmt = 0.21f - charge * 0.15f;
        float[] spreads = {-spreadAmt, 0f, spreadAmt};
        int slot = 0;
        for (VoltChakram vc : voltChakrams) {
            if (vc.ownerId == lp.id && vc.state == VoltChakram.ORBITING && slot < 3) {
                float a = launchAngle + spreads[slot];
                vc.vx = (float) Math.cos(a) * speed;
                vc.vy = (float) Math.sin(a) * speed;
                vc.damage = damage;
                vc.distTraveled = 0f;
                vc.maxRange = range;
                vc.hitIds.clear();
                vc.state = VoltChakram.LAUNCHED;
                slot++;
            }
        }
        voltCharge = 0f;
    }

    /** Main per-frame update: orbit → launch → return cycle + hit detection. */
    void updateVoltChakrams(Player lp, float dt) {
        ensureVoltChakrams(lp);

        // Self-spin of each disc graphic (always rotating for visual life)
        for (VoltChakram vc : voltChakrams) vc.spinAngle += dt * 4.5f;

        int orbiting = 0;
        Iterator<VoltChakram> it = voltChakrams.iterator();
        while (it.hasNext()) {
            VoltChakram vc = it.next();

            // Skip discs that belong to a different player — their positions
            // come from the host's authoritative broadcast, not from this update.
            if (vc.ownerId != lp.id) continue;

            // ── ORBITING ──────────────────────────────────────────────────────
            if (vc.state == VoltChakram.ORBITING) {
                float orbitA = voltOrbitAngle + vc.orbitIdx * (float)(Math.PI * 2 / 3);
                vc.x = lp.x + VoltChakram.ORBIT_RADIUS * (float) Math.cos(orbitA);
                vc.y = lp.y + VoltChakram.ORBIT_RADIUS * (float) Math.sin(orbitA);
                // Damage enemies that walk into orbit range (18 dmg every 700ms per disc)
                if (isHost) {
                    long now = System.currentTimeMillis();
                    if (now >= vc.nextOrbitHitMs) {
                        boolean hit = false;
                        // FIX Bug3: was `vc.ownerId != lp.id` which is always false here
                        // (non-owner VCs are skipped above). Check localPlayer explicitly
                        // so bot chakrams can correctly orbit-damage the human player.
                        Player hlp = localPlayer;
                        if (hlp != null && hlp.alive && vc.ownerId != hlp.id) {
                            float dx = hlp.x - vc.x, dy = hlp.y - vc.y;
                            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, 18f, -1, 999f);
                                applyBulletDamage(proxy, hlp, null, hlp);
                                hit = true;
                            }
                        }
                        for (Player rp : remote.values()) {
                            if (!rp.alive || vc.ownerId == rp.id) continue;
                            float dx = rp.x - vc.x, dy = rp.y - vc.y;
                            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, 18f, -1, 999f);
                                Player hlp2 = localPlayer;
                                applyBulletDamage(proxy, hlp2 != null ? hlp2 : lp, rp, hlp2 != null ? hlp2 : lp);
                                hit = true;
                            }
                        }
                        if (hit) vc.nextOrbitHitMs = now + 700L;
                    }
                }
                orbiting++;
                continue;
            }

            // ── LAUNCHED ──────────────────────────────────────────────────────
            if (vc.state == VoltChakram.LAUNCHED) {
                float nx = vc.x + vc.vx * dt;
                float ny = vc.y + vc.vy * dt;

                // Wall check → reverse to RETURNING
                boolean hitWall = false;
                for (float[] w : WALLS) {
                    if (nx >= w[0]-6 && nx <= w[2]+6 && ny >= w[1]-6 && ny <= w[3]+6) {
                        hitWall = true; break;
                    }
                }
                vc.distTraveled += (float) Math.sqrt((nx-vc.x)*(nx-vc.x)+(ny-vc.y)*(ny-vc.y));

                if (hitWall || vc.distTraveled >= vc.maxRange) {
                    vc.state = VoltChakram.RETURNING;
                    vc.hitIds.clear();  // can re-hit on the way back
                    continue;
                }
                vc.x = nx; vc.y = ny;

                // Hit detection (host only)
                if (isHost) applyChakramHits(vc, lp);
                continue;
            }

            // ── RETURNING ─────────────────────────────────────────────────────
            if (vc.state == VoltChakram.RETURNING) {
                float dx = lp.x - vc.x, dy = lp.y - vc.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);

                if (dist < 24f) {
                    // Disc caught by player — back to orbit
                    vc.state = VoltChakram.ORBITING;
                    vc.hitIds.clear();
                    orbiting++;
                    continue;
                }
                float spd = VoltChakram.RETURN_SPEED;
                // Keep vx/vy in sync with actual movement so the trail renders correctly
                vc.vx = (dx / dist) * spd;
                vc.vy = (dy / dist) * spd;
                vc.x += vc.vx * dt;
                vc.y += vc.vy * dt;

                if (isHost) applyChakramHits(vc, lp);
            }
        }

        // Keep gun ammo in sync with orbiting count for the HUD
        Gun g = lp.currentGun();
        if (isVoltChakram(g)) g.ammo = orbiting;
    }

    /** Apply damage to any players overlapping this chakram (skips already-hit IDs). */
    void applyChakramHits(VoltChakram vc, Player lp) {
        // Local player
        if (lp.alive && vc.ownerId != lp.id && !vc.hitIds.contains(lp.id)) {
            float dx = lp.x - vc.x, dy = lp.y - vc.y;
            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                vc.hitIds.add(lp.id);
                // Re-use applyBulletDamage by creating a thin proxy bullet
                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, vc.damage, -1, 999f);
                applyBulletDamage(proxy, lp, null, lp);
            }
        }
        // Remote players
        for (Player rp : remote.values()) {
            if (!rp.alive || vc.ownerId == rp.id || vc.hitIds.contains(rp.id)) continue;
            float dx = rp.x - vc.x, dy = rp.y - vc.y;
            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                vc.hitIds.add(rp.id);
                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, vc.damage, -1, 999f);
                applyBulletDamage(proxy, lp, rp, lp);
            }
        }
    }
    void resolvePlayerCollisions() {
        collisionPlayers.clear();
        if (localPlayer != null && localPlayer.alive) collisionPlayers.add(localPlayer);
        for (Player rp : remote.values()) if (rp.alive) collisionPlayers.add(rp);
        float minDist = PR * 2f;
        for (int i = 0; i < collisionPlayers.size(); i++) {
            for (int j = i + 1; j < collisionPlayers.size(); j++) {
                Player a = collisionPlayers.get(i), b2 = collisionPlayers.get(j);
                float dx = a.x - b2.x, dy = a.y - b2.y;
                float dist = (float) Math.sqrt(dx*dx + dy*dy);
                if (dist < minDist && dist > 0.5f) {
                    float push = (minDist - dist) * 0.5f;
                    float nx2 = dx/dist, ny2 = dy/dist;
                    a.x  = clamp(a.x  + nx2*push, PR, MAP_W-PR);
                    a.y  = clamp(a.y  + ny2*push, PR, MAP_H-PR);
                    b2.x = clamp(b2.x - nx2*push, PR, MAP_W-PR);
                    b2.y = clamp(b2.y - ny2*push, PR, MAP_H-PR);
                }
            }
        }
    }

    void doExplosion(Bullet b, Player lp){
        // Visual FX — stored as {x, y, spawnMs} drawn by all clients
        effects.explosionFx.add(new long[]{(long)b.x, (long)b.y, System.currentTimeMillis()});
        if(!isHost) return;
        float R=150f;
        // Swap in explosion damage so applyBulletDamage uses AOE value, not bullet base damage
        float savedDmg = b.damage;
        b.damage = b.explosionDmg;
        if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<R*R) applyBulletDamage(b,lp,null,lp);
        for(Player rp:remote.values()){
            if(b.ownerId==rp.id||!rp.alive) continue;
            if(d2(b.x,b.y,rp.x,rp.y)<R*R) applyBulletDamage(b,lp,rp,lp);
        }
        b.damage = savedDmg;
    }

    // ── Electric Burst / Chain (Soul Surge T6+) ───────────────────────────────
    static final float  EBURST_RADIUS  = 160f;  // burst AoE radius (also used by EffectsManager FX)
    static final float  EBURST_DAMAGE  = 18f;   // damage per hop
    static final int    ECHAIN_MAX_HOPS = 3;    // max chain jumps (T8)

    /**
     * Called when a Soul Surge bullet kills a target at (cx, cy).
     * tier >= 6 → single burst; tier >= 8 → chain lightning up to ECHAIN_MAX_HOPS.
     * hopsLeft is decremented each jump; starts at ECHAIN_MAX_HOPS for T8, 0 for T6/T7.
     */
    void doElectricBurst(float cx, float cy, int ownerId, int tier,
                                 int hopsLeft, Player lp) {
        if (!isHost) return;

        // Visual fx — cyan electric ring (index 0=x,1=y,2=spawnMs,3=chain depth)
        effects.electricBurstFx.add(new long[]{(long)cx, (long)cy,
                System.currentTimeMillis(), (long)(ECHAIN_MAX_HOPS - hopsLeft)});

        float R2 = EBURST_RADIUS * EBURST_RADIUS;
        float dmg = EBURST_DAMAGE;

        // Damage local player if in radius and not the killer
        if (lp != null && lp.alive && lp.id != ownerId
                && d2(cx, cy, lp.x, lp.y) < R2) {
            if (!lp.isProtected()) {
                lp.hp = Math.max(0, lp.hp - dmg);
                if (lp.hp == 0) {
                    lp.alive = false; deathTime = System.currentTimeMillis();
                    addFeed("⚡ " + nameOf(ownerId) + " (Soul Surge chain) → " + lp.name);
                    onKill(ownerId == (lp != null ? lp.id : -1) ? lp : remote.get(ownerId), lp);
                    if (hopsLeft > 0)
                        doElectricBurst(lp.x, lp.y, ownerId, tier, hopsLeft - 1, lp);
                }
            }
        }

        // Damage remote players in radius
        for (Player rp : remote.values()) {
            if (!rp.alive || rp.id == ownerId) continue;
            if (d2(cx, cy, rp.x, rp.y) < R2) {
                if (!rp.isProtected()) {
                    rp.hp = Math.max(0, rp.hp - dmg);
                    if (rp.hp == 0) {
                        rp.alive = false;
                        deadAtMs.put(rp.id, System.currentTimeMillis());
                        if (!dummyIds.contains(rp.id)) {
                            addFeed("⚡ " + nameOf(ownerId) + " (Soul Surge chain) → " + rp.name);
                            Player killer = (lp != null && lp.id == ownerId)
                                    ? lp : remote.get(ownerId);
                            onKill(killer, rp);
                            if (hopsLeft > 0)
                                doElectricBurst(rp.x, rp.y, ownerId, tier, hopsLeft - 1, lp);
                        }
                    }
                }
            }
        }
    }

    /** Applies poison damage (8 dmg every 600 ms) to local + remote players. */
    void applyPoisonTicks(Player lp){
        if(!isHost) return;
        long now=System.currentTimeMillis();
        // Local player
        if(lp.alive && lp.isPoisoned() && now-lp.poisonLastTick>=StatusEffectConfig.POISON_TICK_MS){
            lp.poisonLastTick=now;
            if(!lp.isProtected()){
                lp.hp=Math.max(0, lp.hp-lp.poisonTickDamage);
                if(lp.hp==0){
                    lp.alive=false; deathTime=now;
                    addFeed(nameOf(lp.poisonOwnerId)+" ☠ "+lp.name+" (poison)");
                    onKill(remote.get(lp.poisonOwnerId), lp);
                }
                if(lp.isStealthed()) lp.skillActiveUntil=0;
            }
        }
        // Remote players
        for(Player rp:remote.values()){
            if(!rp.alive||!rp.isPoisoned()) continue;
            if(now-rp.poisonLastTick>=StatusEffectConfig.POISON_TICK_MS){
                rp.poisonLastTick=now;
                if(!rp.isProtected()){
                    if(rp.isStealthed()) rp.skillActiveUntil=0;
                    rp.hp=Math.max(0, rp.hp-rp.poisonTickDamage);
                    if(rp.hp==0){
                        rp.alive=false; deadAtMs.put(rp.id,now);
                        addFeed(nameOf(rp.poisonOwnerId)+" ☠ "+rp.name+" (poison)");
                        if(rp.poisonOwnerId==lp.id) onKill(lp, rp);
                        else{ Player killer=remote.get(rp.poisonOwnerId); onKill(killer, rp); }
                    }
                }
            }
        }
    }

    void applyClientInputs(float dt){
        for(Map.Entry<Integer,float[]> e:inputs.entrySet()){
            Player p=remote.get(e.getKey()); if(p==null||!p.alive) continue;
            float[] inp=e.getValue();
            // Sync skill levels from client input
            if(inp.length>13){
                p.skillReload    =Math.max(0,Math.min(3,(int)inp[7]));
                p.skillFireRate  =Math.max(0,Math.min(3,(int)inp[8]));
                p.skillRange     =Math.max(0,Math.min(3,(int)inp[9]));
                p.skillMoveSpeed =Math.max(0,Math.min(3,(int)inp[10]));
                p.activeSkillType=(int)inp[11];
                // FIX Bug6: field 12 is now ms remaining (was seconds — caused up to 999ms precision loss)
                long msRem2=(long)inp[12]; p.skillActiveUntil= msRem2>0?System.currentTimeMillis()+msRem2:0;
                p.shieldHp=inp[13];
                // FIX Bug5: apply heal on the host's authoritative copy so the hp change sticks
                if(inp.length>17 && inp[17]>0.5f && p.alive) p.hp=Math.min(100,p.hp+40);
            }
            // ── Use client's authoritative position if provided ─────────────────
            // inp[14]=px, inp[15]=py (−1 means not provided, fall back to delta)
            float clientX = inp.length>14 ? inp[14] : -1f;
            float clientY = inp.length>15 ? inp[15] : -1f;
            if (p.isBeingPulled() || p.isStunned()) {
                // Hook pull / stun: host position is authoritative — ignore client
            } else if(clientX >= 0 && clientY >= 0){
                // FIX: lerp toward client position to smooth network jitter.
                // Snap instantly if far away (respawn/teleport), otherwise ease in.
                float tX = clamp(clientX, PR, MAP_W-PR);
                float tY = clamp(clientY, PR, MAP_H-PR);
                float snapDist2 = 120f*120f;
                if ((tX-p.x)*(tX-p.x)+(tY-p.y)*(tY-p.y) > snapDist2) {
                    p.x = tX; p.y = tY; // far away: snap immediately
                } else {
                    p.x += (tX - p.x) * 0.3f; // close: smooth interpolation
                    p.y += (tY - p.y) * 0.3f;
                }
            } else {
                // Fallback: dead-reckon from joystick (should rarely happen)
                float nx=p.x+inp[0]*280f*p.moveSpeedMult()*dt, ny=p.y+inp[1]*280f*p.moveSpeedMult()*dt;
                nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
                float[] pos=walls(p.x,p.y,nx,ny); p.x=pos[0]; p.y=pos[1];
            }
            // Aim angle from joystick
            if(inp[2]*inp[2]+inp[3]*inp[3]>0.01f) p.angle=(float)Math.atan2(inp[3],inp[2]);
            p.gunIndex=Math.max(0,Math.min((int)inp[5], p.guns.length-1));
            if(inp[6]>0.5f) p.guns[p.gunIndex].startReload();
            float rm=p.reloadMult();
            for(Gun g:p.guns) g.tick(rm);
            { Gun g=p.currentGun(); if(g.ammo<=0&&!g.reloading) g.startReload(); }
            if(inp[4]>0.5f){
                Gun g=p.currentGun();
                float frMult=p.fireRateMult();
                long fireCd=(long)(1000f/(g.fireRate*frMult));
                if(g.ammo>0&&!g.reloading&&System.currentTimeMillis()-g.lastFireTime>=fireCd){
                    spawnBullets(p); g.markFired();
                }
            }
        }
    }

    void checkRemoteRespawns(){
        long now=System.currentTimeMillis();
        for(Player p:remote.values()) {
            if (!p.alive && deadAtMs.containsKey(p.id)) {
                long delay = dummyIds.contains(p.id) ? 2000L : RESPAWN_MS;
                if (now - deadAtMs.get(p.id) >= delay) {
                    if (dummyIds.contains(p.id)) respawnDummy(p);
                    else respawn(p);
                    deadAtMs.remove(p.id);
                }
            }
        }
    }

    void respawn(Player p){
        float[] sp=SPAWNS[p.id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true; p.guns=Gun.createAll();
        p.bombs = 2;
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        p.shieldHp = 0; p.skillActiveUntil = 0; p.skillCooldownEnd = 0;
        p.slowUntil = 0; p.slowSpeedMult = StatusEffectConfig.SLOW_SPEED_MULT; p.poisonUntil = 0; p.poisonLastTick = 0; p.poisonOwnerId = -1;
        p.stunUntil = 0; p.hookPullUntil = 0; p.hookPullOwnerId = -1;  // clear status effects on respawn
        p.killStreak = 0; // streak resets on death; kills/deaths persist
        // Keep coins, skill levels, active skill type, and unlocked guns
        // FIX: only validate gunIndex for the LOCAL player. The host never receives
        // unlockedGuns data for remote players, so their copy is always {true,false,…}.
        // Without this guard, the host was resetting every remote player to pistol (index 0)
        // on every respawn, even when they had a different gun equipped.
        Player lp = localPlayer;
        if (p == lp && !p.unlockedGuns[p.gunIndex]) p.gunIndex = 0;
        // For remote players, applyClientInputs restores the correct gunIndex each frame.
    }
    void spawnLocal(int id, String name){
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        localPlayer=p;
    }

    /** Spawn one more training dummy (up to MAX_DUMMIES). */
    void spawnDummy() {
        if (dummyIds.size() >= MAX_DUMMIES) return;
        int slot = dummyIds.size();
        int id   = DUMMY_ID_BASE + slot;
        float[] home = DUMMY_SPAWNS[slot % DUMMY_SPAWNS.length];
        Player d = new Player();
        d.id = id; d.name = "Dummy"; d.guns = Gun.createAll();
        d.x = home[0]; d.y = home[1]; d.hp = 100; d.alive = true;
        d.spawnProtectionUntil = 0; // dummies have no protection
        remote.put(id, d);
        dummyIds.add(id);
        dummyHome.put(id, new float[]{home[0], home[1]});
    }

    /** Remove the most recently added training dummy. */
    void removeLastDummy() {
        if (dummyIds.isEmpty()) return;
        int lastId = DUMMY_ID_BASE + dummyIds.size() - 1;
        remote.remove(lastId);
        dummyIds.remove(lastId);
        dummyHome.remove(lastId);
        deadAtMs.remove(lastId);
        voltChakrams.removeIf(vc -> vc.ownerId == lastId);
    }

    /** Respawn a dummy at its fixed home position. */
    void respawnDummy(Player d) {
        float[] home = dummyHome.get(d.id);
        if (home == null) return;
        d.x = home[0]; d.y = home[1];
        d.hp = 100; d.alive = true; d.guns = Gun.createAll();
        d.spawnProtectionUntil = 0;
        d.shieldHp = 0; d.skillActiveUntil = 0; d.skillCooldownEnd = 0;
        d.slowUntil = 0; d.slowSpeedMult = StatusEffectConfig.SLOW_SPEED_MULT; d.poisonUntil = 0; d.poisonLastTick = 0; d.poisonOwnerId = -1;
        d.stunUntil = 0; d.hookPullUntil = 0; d.hookPullOwnerId = -1;
    }

    // ══ BOT AI ════════════════════════════════════════════════════════════════

    /** Tactical state-machine AI engine — fully separated from GameView. */
    final BotAI botAI = new BotAI();

    /** Pre-built wall-corner waypoints used for around-wall routing. */
    float[][] navWaypoints;

    /**
     * Builds waypoints at every wall corner (plus map corners) with a margin so
     * bots always stand outside the wall geometry.  Call once after WALLS is set.
     */
    void buildNavWaypoints() {
        final float PAD = 52f;
        List<float[]> pts = new ArrayList<>();
        // Map corners
        pts.add(new float[]{PAD, PAD});
        pts.add(new float[]{MAP_W - PAD, PAD});
        pts.add(new float[]{PAD, MAP_H - PAD});
        pts.add(new float[]{MAP_W - PAD, MAP_H - PAD});
        // For every wall: 4 outer corners + 4 edge midpoints
        for (float[] w : WALLS) {
            float mx = (w[0] + w[2]) * 0.5f, my = (w[1] + w[3]) * 0.5f;
            pts.add(new float[]{w[0] - PAD, w[1] - PAD});
            pts.add(new float[]{w[2] + PAD, w[1] - PAD});
            pts.add(new float[]{w[0] - PAD, w[3] + PAD});
            pts.add(new float[]{w[2] + PAD, w[3] + PAD});
            pts.add(new float[]{mx,          w[1] - PAD});
            pts.add(new float[]{mx,          w[3] + PAD});
            pts.add(new float[]{w[0] - PAD,  my});
            pts.add(new float[]{w[2] + PAD,  my});
        }
        // Keep only points that are inside the map and not inside any wall
        List<float[]> valid = new ArrayList<>();
        for (float[] p : pts) {
            if (p[0] < PAD || p[0] > MAP_W - PAD || p[1] < PAD || p[1] > MAP_H - PAD) continue;
            boolean blocked = false;
            for (float[] w : WALLS) {
                if (p[0] > w[0] && p[0] < w[2] && p[1] > w[1] && p[1] < w[3]) { blocked = true; break; }
            }
            if (!blocked) valid.add(p);
        }
        navWaypoints = valid.toArray(new float[0][]);
    }

    /**
     * Finds the cheapest 1-hop waypoint such that: bot→wp has clear LOS AND
     * wp→target has clear LOS.  Returns null if no waypoint is needed / found.
     */
    float[] findNavWaypoint(float bx, float by, float tx, float ty) {
        float bestCost = Float.MAX_VALUE;
        float[] best   = null;
        if (navWaypoints == null) return null;
        for (float[] wp : navWaypoints) {
            if (!hasLos(bx, by, wp[0], wp[1])) continue;
            if (!hasLos(wp[0], wp[1], tx, ty))  continue;
            float d1x = wp[0] - bx, d1y = wp[1] - by;
            float d2x = tx - wp[0], d2y = ty - wp[1];
            float cost = (float)(Math.sqrt(d1x*d1x + d1y*d1y) + Math.sqrt(d2x*d2x + d2y*d2y));
            if (cost < bestCost) { bestCost = cost; best = wp; }
        }
        return best;
    }

    /** Move bot by (moveX, moveY)*speed*dt with axis-separated wall sliding. */
    void moveBotWithCollision(Player bot, float moveX, float moveY, float speed, float dt) {
        float nx = clamp(bot.x + moveX * speed * dt, PR, MAP_W - PR);
        float ny = clamp(bot.y + moveY * speed * dt, PR, MAP_H - PR);
        // Test each axis separately so the bot slides along wall faces
        boolean xOk = true, yOk = true;
        for (float[] w : WALLS) {
            if (xOk && nx + PR > w[0] && nx - PR < w[2] && bot.y + PR > w[1] && bot.y - PR < w[3]) xOk = false;
            if (yOk && bot.x + PR > w[0] && bot.x - PR < w[2] && ny + PR > w[1] && ny - PR < w[3]) yOk = false;
        }
        if (xOk) bot.x = nx;
        if (yOk) bot.y = ny;
    }

    /**
     * Per-frame AI update. Delegates entirely to {@link BotAI} via a Context
     * adapter so all tactical logic lives in the separated BotAI class.
     */
    void updateBots(float dt) {
        Player lp = localPlayer;
        if (lp == null) return;
        if (navWaypoints == null) buildNavWaypoints();

        // Build a Context adapter once per frame — captures local references.
        BotAI.Context ctx = new BotAI.Context() {
            @Override public java.util.List<Bullet> getBullets()           { return bullets; }
            @Override public Player getLocalPlayer()                       { return localPlayer; }
            @Override public Map<Integer, Player> getRemote()              { return remote; }
            @Override public int    getDifficulty()                        { return difficulty; }
            @Override public int    getTick()                              { return tick; }
            @Override public float  getPlayerVelX()                        { return lpVelX; }
            @Override public float  getPlayerVelY()                        { return lpVelY; }
            @Override public float[][] getWalls()                          { return WALLS; }
            @Override public float[][] getNavWaypoints()                   { return navWaypoints; }
            @Override public boolean hasLos(float x1, float y1, float x2, float y2) {
                return GameView.this.hasLos(x1, y1, x2, y2);
            }
            @Override public void moveBotWithCollision(Player bot, float mx, float my, float spd, float dt2) {
                GameView.this.moveBotWithCollision(bot, mx, my, spd, dt2);
            }
            @Override public void spawnBotBullets(Player bot)              { spawnBullets(bot); }
            @Override public void doBotShopping(Player bot)                { GameView.this.doBotShopping(bot); }
            @Override public void doBotUseSkill(Player bot, Player lp2, float dist) {
                GameView.this.doBotUseSkill(bot, lp2, dist);
            }
            @Override public float[] findNavWaypoint(float bx, float by, float tx, float ty) {
                return GameView.this.findNavWaypoint(bx, by, tx, ty);
            }
        };

        for (Player bot : remote.values()) {
            if (!botIds.contains(bot.id) || !bot.alive) continue;
            botAI.update(bot, ctx, dt);
        }
    }

    /** Hard mode: bot spends coins on guns then skills. */
    void doBotShopping(Player bot) {
        // ── Priority 1: buy the best gun this bot can afford ──────────────────
        // Iterate from most-expensive to cheapest
        // Bots prefer guns with long range first: Sniper(2100) > Plasma(1100) > Assault(900) > Burst(720) > Revolver(850) > LMG(750) > SMG(620) > Shotgun(220) > Minigun(420)
        int[] gunPriority = {4, 9, 3, 5, 7, 8, 1, 2, 6, 17};
        for (int i : gunPriority) {
            if (!bot.unlockedGuns[i] && bot.coins >= GUN_PRICES[i]) {
                bot.coins -= GUN_PRICES[i];
                // Drop any previously unlocked non-default gun to stay at 1 extra
                for (int j = 1; j < 7; j++) {
                    if (j != i && bot.unlockedGuns[j]) { bot.unlockedGuns[j] = false; break; }
                }
                bot.unlockedGuns[i] = true;
                bot.gunIndex = i;
                return;
            }
        }
        // ── Priority 2: passive fire rate upgrade ─────────────────────────────
        // (bots already have a starting active skill, so skip buying another)
        // ── Priority 3: upgrade passive fire rate then move speed ──────────────
        if (bot.skillFireRate < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillFireRate]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillFireRate];
            bot.skillFireRate++;
            return;
        }
        if (bot.skillMoveSpeed < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed];
            bot.skillMoveSpeed++;
        }
    }

    /** Bot activates its skill when conditions are right. */
    void doBotUseSkill(Player bot, Player lp, float dist) {
        if (bot.activeSkillType == Player.ACTIVE_NONE) return;
        if (bot.activeSkillType == Player.ACTIVE_STEALTH) return;  // bots don't stealth
        if (bot.activeSkillType == Player.ACTIVE_DASH) return;     // bots don't dash
        if (bot.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        Gun bg = bot.currentGun();
        float botRange = bg.range * bot.rangeMult();
        switch (bot.activeSkillType) {
            case Player.ACTIVE_HEAL:
                // Heal at 60 HP (not 45) so it's proactive, not last-resort
                if (bot.hp < 60) {
                    bot.hp = Math.min(100, bot.hp + 40);
                    bot.skillCooldownEnd = now + 12000;
                }
                break;
            case Player.ACTIVE_SHIELD:
                // Pop shield whenever health is moderate or player is in range
                if (bot.hp < 80 && !bot.isShielded()) {
                    bot.shieldHp = 60f;
                    bot.skillActiveUntil = now + 6000;
                    bot.skillCooldownEnd = now + 14000;
                }
                break;
            case Player.ACTIVE_STEALTH:
                // Go stealth whenever player has LOS on the bot (and not already stealthed)
                if (!bot.isStealthed() && hasLos(bot.x, bot.y, lp.x, lp.y)) {
                    bot.skillActiveUntil = now + 4000;
                    bot.skillCooldownEnd = now + 10000;
                }
                break;
            case Player.ACTIVE_DASH:
                float dashAngleBot = Float.NaN;
                if (bot.hp < 35) {
                    // Critically low HP -- dash away from player
                    dashAngleBot = (float) Math.atan2(bot.y - lp.y, bot.x - lp.x);
                } else if (dist > botRange * 1.6f && dist < botRange * 4f) {
                    // Out of range -- dash toward player to close the gap
                    dashAngleBot = (float) Math.atan2(lp.y - bot.y, lp.x - bot.x);
                }
                if (!Float.isNaN(dashAngleBot)) {
                    float[] botDashEnd = dashWithWallStop(bot.x, bot.y, dashAngleBot, 280f);
                    long ghostNow = System.currentTimeMillis();
                    long ghostNowRel = ghostNow - EffectsManager.FX_EPOCH;
                    float ghostDx = botDashEnd[0] - bot.x, ghostDy = botDashEnd[1] - bot.y;
                    float ghostLen = (float)Math.sqrt(ghostDx*ghostDx + ghostDy*ghostDy);
                    int numGhosts = Math.max(2, (int)(ghostLen / 32f));
                    for (int gi = 0; gi <= numGhosts; gi++) {
                        float t2 = (float)gi / numGhosts;
                        effects.botDashGhosts.add(new float[]{
                            bot.x + ghostDx * t2,
                            bot.y + ghostDy * t2,
                            (float)(ghostNowRel - (long)(t2 * 60f))
                        });
                    }
                    // Store visual start for smooth render; logical position jumps immediately
                    botDashVisual.put(bot.id, new float[]{bot.x, bot.y, botDashEnd[0], botDashEnd[1], (float)ghostNowRel});
                    bot.x = botDashEnd[0];
                    bot.y = botDashEnd[1];
                    bot.skillCooldownEnd = now + 6000;
                }
                break;
        }
    }

    /**
     * Steps along a dash from (startX,startY) in the given angle and returns the
     * last valid position before hitting a wall or the map boundary.
     * Uses the player radius (PR) so the circle never overlaps a wall.
     */
    float[] dashWithWallStop(float startX, float startY, float angle, float maxDist) {
        // FIX: if player already clips a wall, nudge start clear so dash doesn't dead-stop
        for (float[] w : WALLS) {
            float csx = clamp(startX, w[0], w[2]);
            float csy = clamp(startY, w[1], w[3]);
            float dx = startX - csx, dy = startY - csy;
            if (dx*dx + dy*dy < (float)(PR*PR)) {
                startX = clamp(startX + (float)Math.cos(angle) * PR, PR, MAP_W - PR);
                startY = clamp(startY + (float)Math.sin(angle) * PR, PR, MAP_H - PR);
                break;
            }
        }
        final float STEP = 6f; // smaller step so thin walls (35px) are never tunnelled
        int steps = Math.max(1, (int)(maxDist / STEP));
        float lastX = startX, lastY = startY;
        for (int i = 1; i <= steps; i++) {
            float testX = startX + (float)Math.cos(angle) * STEP * i;
            float testY = startY + (float)Math.sin(angle) * STEP * i;
            testX = clamp(testX, PR, MAP_W - PR);
            testY = clamp(testY, PR, MAP_H - PR);
            // FIX: correct circle-vs-AABB check (same method as walls() movement function)
            boolean hit = false;
            for (float[] w : WALLS) {
                float cx = clamp(testX, w[0], w[2]);
                float cy = clamp(testY, w[1], w[3]);
                float ddx = testX - cx, ddy = testY - cy;
                if (ddx*ddx + ddy*ddy < (float)(PR*PR)) { hit = true; break; }
            }
            if (hit) break;
            lastX = testX; lastY = testY;
        }
        return new float[]{lastX, lastY};
    }

    /**
     * Checks line-of-sight by stepping along the segment in 25px increments.
     * Returns true if no wall blocks the path.
     */
    boolean hasLos(float x1,float y1,float x2,float y2){
        float ddx=x2-x1, ddy=y2-y1;
        float dist=(float)Math.sqrt(ddx*ddx+ddy*ddy);
        int steps=Math.max(1,(int)(dist/25));
        float sx=ddx/steps, sy=ddy/steps;
        for(int i=1;i<steps;i++){
            float px=x1+sx*i, py=y1+sy*i;
            for(float[] w:WALLS)
                if(px>=w[0]&&px<=w[2]&&py>=w[1]&&py<=w[3]) return false;
        }
        return true;
    }


    /** Returns the fire-joystick magnitude threshold from cached settings (0.15–0.70). */
    float getFireThresh() {
        return cachedFireThresh;
    }



    // ═══ NETWORK CALLBACKS (delegate to GameNetworkBridge) ══════════════════════
    @Override public void onHostDiscovered(String ip,String n){ networkBridge.onHostDiscovered(ip,n); }
    @Override public void onJoined(int id){ networkBridge.onJoined(id); }
    @Override public void onPlayerJoined(int id,String name){ networkBridge.onPlayerJoined(id,name); }
    @Override public void onStateUpdate(String json){ pendingState=json; }
    @Override public void onDisconnected(){ networkBridge.onDisconnected(); }
    @Override public void onInputReceived(int pid,String json){ networkBridge.onInputReceived(pid,json); }

    // ═══ UTIL ═════════════════════════════════════════════════════════════════
    static float d2(float ax,float ay,float bx,float by){float dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
    static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    String nameOf(int id){
        Player lp=localPlayer; if(lp!=null&&id==lp.id) return lp.name;
        Player p=remote.get(id); return p!=null?p.name:"P"+id;
    }
    void addFeed(String msg){
        synchronized(feed){feed.add(0,msg);if(feed.size()>4)feed.remove(feed.size()-1);}
    }

}
