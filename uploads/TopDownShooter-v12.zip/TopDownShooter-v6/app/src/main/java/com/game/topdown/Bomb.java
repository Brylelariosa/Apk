package com.game.topdown;

public class Bomb {
    public float  x, y;
    public int    ownerId;
    public long   deployTime;
    public long   explodedAt = -1;   // -1 = not yet exploded
    public static final float RADIUS   = 130f;
    public static final int   DAMAGE   = 80;
    public static final long  FUSE_MS  = 2000;
    public static final long  FLASH_MS = 400;   // how long to show explosion

    public Bomb(float x, float y, int ownerId) {
        this.x = x; this.y = y; this.ownerId = ownerId;
        this.deployTime = System.currentTimeMillis();
    }

    /** True once the fuse has burned down. */
    public boolean shouldExplode() {
        return explodedAt < 0 && System.currentTimeMillis() - deployTime >= FUSE_MS;
    }

    /** True while the explosion flash is still visible. */
    public boolean isFlashing() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt < FLASH_MS;
    }

    /** True when we can safely remove this bomb from the list. */
    public boolean isDone() {
        return explodedAt >= 0 && System.currentTimeMillis() - explodedAt >= FLASH_MS;
    }
}
