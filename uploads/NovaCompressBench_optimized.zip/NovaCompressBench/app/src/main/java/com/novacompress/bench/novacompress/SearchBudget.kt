package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.analyzer.RegionKind

/**
 * "Adaptive search budget": maps a segment's already-computed classifier signal (dominant
 * [RegionKind] + average entropy - both computed during segmentation, nothing new to measure) to
 * how many hash-chain candidates [com.novacompress.bench.novacompress.matcher.LongRangeMatcher]
 * spends per position. Computed once per [NovaSegmentCodec.encode] call, never inside the
 * matcher's hot per-position loop.
 *
 * Tier chain depths scale the spec's own illustrative 256/64/16/skip example down to this
 * codebase's already-tuned ceiling (MAX_CHAIN = 64, proven across five prior BENCHMARKS.md
 * entries) using the same 4x-per-step shape: 64 / 16 / 4 / 0.
 *
 * This ships together with the RegionClassifier periodicity fix (see its KDoc), not behind an
 * independent toggle: search effort is only safe to cut *because* the classification driving it
 * is more trustworthy now. Verified directly - running the search-budget tiers against the
 * *unfixed* classifier in this pass's Java-port testing (see the accompanying report) collapsed
 * synthetic_table.bin from 14.45x to 4.63x, because its still-misclassified
 * ALREADY_COMPRESSED_OR_ENCRYPTED segment got routed to MINIMAL effort instead of the HIGH effort
 * its real (periodic, highly matchable) content needs. With the classifier fix in place, that
 * same content classifies REPETITIVE_BINARY and correctly gets HIGH effort - table.bin's ratio is
 * unaffected (14.45x -> 14.45x) while its redundant store-trial-then-promote encode is eliminated.
 */
object SearchBudget {
    enum class Tier { HIGH, MEDIUM, WEAK, MINIMAL }

    const val CHAIN_HIGH = 64    // == existing MAX_CHAIN / SMALL_MAX_CHAIN, unchanged default
    const val CHAIN_MEDIUM = 16
    const val CHAIN_WEAK = 4
    const val CHAIN_MINIMAL = 0  // rep-offset checks only - no hash chain walk at all

    fun chainFor(tier: Tier): Int = when (tier) {
        Tier.HIGH -> CHAIN_HIGH
        Tier.MEDIUM -> CHAIN_MEDIUM
        Tier.WEAK -> CHAIN_WEAK
        Tier.MINIMAL -> CHAIN_MINIMAL
    }

    fun tierFor(kind: RegionKind, avgEntropy: Double): Tier = when (kind) {
        RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED -> Tier.MINIMAL
        RegionKind.REPETITIVE_BINARY -> Tier.HIGH
        RegionKind.TEXT, RegionKind.STRUCTURED_TEXT -> if (avgEntropy < 4.5) Tier.HIGH else Tier.MEDIUM
        // The matcher rarely carries image-like content on its own (ContextPredictor typically
        // does the heavy lifting there - e.g. synthetic_image.bmp's match share is ~0.1% against
        // an 83% prediction-hit rate), so a reduced budget costs little; kept at MEDIUM rather
        // than WEAK/MINIMAL as a safety margin since real (non-synthetic) images can have more
        // matcher-friendly structure (large flat regions, tiling) than this pass's test fixture.
        RegionKind.IMAGE_LIKE -> Tier.MEDIUM
        RegionKind.EXECUTABLE_LIKE -> Tier.MEDIUM
        RegionKind.BINARY_UNKNOWN -> if (avgEntropy >= 7.0) Tier.WEAK else Tier.MEDIUM
    }
}
