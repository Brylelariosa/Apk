package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException

/**
 * The single entry point the UI and validator both call to actually enhance
 * an image. Design split, spelled out because it's easy to lose track of
 * which layer does what:
 *
 *  - [NovaModelEngine] (the *learned* part): a fixed-size CNN pass per tile that
 *    does denoise + sharpen + detail-restore + artifact-removal in one shot,
 *    and is the thing that literally gets better as the user trains it.
 *  - [NativeImageProcessor] (the *classical*, non-learned part): manual
 *    sharpen/denoise/saturation controls layered on top of the AI's output,
 *    so a user can nudge the result even between training sessions, and so
 *    "Upscaling" (which the learned model does not do - it's a fixed
 *    tile-size restoration model, not a super-resolution model) has an
 *    honest implementation rather than a fabricated claim.
 *  - [TileProcessor]: keeps peak memory bounded regardless of source image
 *    resolution, and (given [thermalGovernor]) paces itself under thermal
 *    pressure - this is what makes a manual "Enhance" tap on a large photo
 *    back off the same way training's internal validation/rescoring passes
 *    do, since both go through this same class.
 */
class EnhancementEngine(
    private val modelEngine: NovaModelEngine,
    private val thermalGovernor: ThermalGovernor? = null
) {

    private val tileProcessor = TileProcessor(tileSize = modelEngine.tileSize, thermalGovernor = thermalGovernor)

    data class EnhanceProgress(val fraction: Float, val stage: Stage) {
        enum class Stage { AI_TILES, UPSCALING, FINISHING }
    }

    suspend fun enhance(
        source: Bitmap,
        options: EnhancementOptions,
        onProgress: ((EnhanceProgress) -> Unit)? = null,
        // Checked before starting, between the AI-tile pass and the upscale
        // pass, and (inside TileProcessor) between tile chunks - so a
        // request superseded by a newer slider change stops within at most
        // one tile-chunk's worth of native work instead of running the full
        // image to completion. This exists BECAUSE coroutine cancellation
        // alone can't do this: a native JNI call already in flight keeps
        // running to completion regardless of job.cancel() - see
        // EnhanceViewModel.runEnhancement for where this is wired to an
        // actual generation counter. Default `{ false }` preserves the
        // previous unconditional-completion behavior for any other caller
        // (e.g. ModelValidator's before/after comparison passes, which have
        // their own, separate TrainingControlFlow-based cancellation).
        isStale: () -> Boolean = { false }
    ): Bitmap {
        if (isStale()) throw CancellationException("Enhancement superseded before starting")

        val aiEnhanced = tileProcessor.process(
            source,
            onProgress = { p ->
                onProgress?.invoke(EnhanceProgress(p.tilesDone.toFloat() / p.tilesTotal, EnhanceProgress.Stage.AI_TILES))
            },
            isStale = isStale
        ) { tilePixels, tileW, tileH ->
            val aiTile = modelEngine.inferTile(tilePixels)
            applyManualControls(blendWithOriginal(tilePixels, aiTile, options.strength), tileW, tileH, options)
        }

        if (options.upscaleFactor == 1) {
            onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
            return aiEnhanced
        }
        if (isStale()) {
            aiEnhanced.recycle() // not returning it, and nothing else references it yet - free it now rather than leaving it for GC
            throw CancellationException("Enhancement superseded before upscaling")
        }

        onProgress?.invoke(EnhanceProgress(0f, EnhanceProgress.Stage.UPSCALING))
        val targetW = aiEnhanced.width * options.upscaleFactor
        val targetH = aiEnhanced.height * options.upscaleFactor
        val upscaled = Bitmap.createScaledBitmap(aiEnhanced, targetW, targetH, /* filter = */ true)
        if (upscaled !== aiEnhanced) aiEnhanced.recycle()

        // Upsampling always softens fine detail a little; a mild classical
        // sharpen pass compensates. Applied tile-wise too, since the
        // upscaled image can be significantly larger than the original -
        // but skipped entirely (not just made a no-op per tile) when
        // sharpness is 0, since running every tile of the upscaled image
        // through get/setPixels and seam-blending just to hand back the
        // same pixels was pure wasted work.
        val resharpened = if (options.sharpness <= 0f) {
            upscaled
        } else {
            try {
                tileProcessor.process(upscaled, isStale = isStale) { tilePixels, tileW, tileH ->
                    NativeImageProcessor.unsharpMask(tilePixels, tileW, tileH, sigma = 1.2f, amount = options.sharpness * 0.6f)
                }
            } catch (t: Throwable) {
                // upscaled can be considerably larger than the source (up to 4x
                // per dimension - see targetW/targetH above) - process() throwing
                // (staleness or otherwise) must not leave it to GC to notice.
                upscaled.recycle()
                throw t
            }
        }
        if (resharpened !== upscaled) upscaled.recycle()

        onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
        return resharpened
    }

    private fun blendWithOriginal(original: IntArray, aiOutput: IntArray, strength: Float): IntArray {
        if (strength >= 1f) return aiOutput
        if (strength <= 0f) return original
        val blended = IntArray(original.size)
        for (i in original.indices) {
            blended[i] = blendPixel(original[i], aiOutput[i], strength)
        }
        return blended
    }

    private fun applyManualControls(
        pixels: IntArray,
        width: Int,
        height: Int,
        options: EnhancementOptions
    ): IntArray {
        var result = pixels
        if (options.noiseReduction > 0f) {
            result = NativeImageProcessor.denoiseBilateral(
                result, width, height,
                spatialSigma = 1.5f, rangeSigma = 10f + options.noiseReduction * 40f
            )
        }
        if (options.sharpness > 0f) {
            result = NativeImageProcessor.unsharpMask(
                result, width, height, sigma = 1.0f, amount = options.sharpness
            )
        }
        if (options.colorRestoration > 0f) {
            result = applySaturationBoost(result, options.colorRestoration)
        }
        return result
    }

    /** Simple luma-preserving saturation boost; the inverse of the native `colorFade` degradation. */
    private fun applySaturationBoost(pixels: IntArray, amount: Float): IntArray {
        val out = IntArray(pixels.size)
        val boost = 1f + amount // 1.0 (no change) .. 2.0 (double saturation)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val luma = (r * 299 + g * 587 + b * 114) / 1000

            val nr = (luma + (r - luma) * boost).toInt().coerceIn(0, 255)
            val ng = (luma + (g - luma) * boost).toInt().coerceIn(0, 255)
            val nb = (luma + (b - luma) * boost).toInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    private fun blendPixel(oldPixel: Int, newPixel: Int, newWeight: Float): Int {
        val oldWeight = 1f - newWeight
        val r = ((oldPixel shr 16 and 0xFF) * oldWeight + (newPixel shr 16 and 0xFF) * newWeight).toInt()
        val g = ((oldPixel shr 8 and 0xFF) * oldWeight + (newPixel shr 8 and 0xFF) * newWeight).toInt()
        val b = ((oldPixel and 0xFF) * oldWeight + (newPixel and 0xFF) * newWeight).toInt()
        return (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    }
}
