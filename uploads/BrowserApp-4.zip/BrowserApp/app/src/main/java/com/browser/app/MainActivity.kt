package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────
    private lateinit var webView: ScrollAwareWebView
    private lateinit var urlBar: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnAdBlock: ImageButton
    private lateinit var btnDataSaver: ImageButton
    private lateinit var btnToggle: ImageButton

    // ── State ──────────────────────────────────────────────────────────
    private var urlBarVisible  = false
    private var toggleVisible  = true       // tracks fab show/hide

    @Volatile private var currentHost: String? = null
    @Volatile private var adBlockEnabled  = true   // on by default
    @Volatile private var dataSaverEnabled = false

    // Handler + runnable to re-show the toggle after scroll inactivity
    private val scrollHandler = Handler(Looper.getMainLooper())
    private val showToggleRunnable = Runnable { showToggleFab(animate = true) }

    companion object {
        private const val HOME_URL    = "https://www.google.com"
        private const val SHOW_DELAY  = 2_500L   // ms after last scroll event
        private const val DESKTOP_UA  =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"

        // Icon tints
        private val TINT_OFF    = Color.WHITE
        private val TINT_SHIELD = Color.parseColor("#4FC3F7")   // blue  – ad block on
        private val TINT_BOLT   = Color.parseColor("#FFB74D")   // amber – data saver on
    }

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        applyImmersiveMode()
        bindViews()
        configureWebView()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    // ══════════════════════════════════════════════════════════════════
    // Immersive mode
    // ══════════════════════════════════════════════════════════════════

    private fun applyImmersiveMode() {
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ══════════════════════════════════════════════════════════════════
    // View binding
    // ══════════════════════════════════════════════════════════════════

    private fun bindViews() {
        webView      = findViewById(R.id.webView)
        urlBar       = findViewById(R.id.urlBar)
        urlInput     = findViewById(R.id.urlInput)
        btnBack      = findViewById(R.id.btnBack)
        btnForward   = findViewById(R.id.btnForward)
        btnRefresh   = findViewById(R.id.btnRefresh)
        btnAdBlock   = findViewById(R.id.btnAdBlock)
        btnDataSaver = findViewById(R.id.btnDataSaver)
        btnToggle    = findViewById(R.id.btnToggleUrlBar)

        // Slide URL bar off-screen after first measure
        urlBar.post {
            urlBar.translationY = -urlBar.height.toFloat()
        }

        // ── Button listeners ─────────────────────────────────────────
        btnToggle.setOnClickListener   { toggleUrlBar() }
        btnBack.setOnClickListener     { if (webView.canGoBack())    webView.goBack()    }
        btnForward.setOnClickListener  { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener  { webView.reload() }

        btnAdBlock.setOnClickListener  {
            adBlockEnabled = !adBlockEnabled
            updateFeatureIcons()
            // Flash the page to give instant feedback
            webView.reload()
        }

        btnDataSaver.setOnClickListener {
            dataSaverEnabled = !dataSaverEnabled
            updateFeatureIcons()
            // Re-apply WebSettings and reload so new image policy takes effect
            applyDataSaverSettings()
            webView.reload()
        }

        urlInput.setOnEditorActionListener { _, actionId, event ->
            val isGo    = actionId == EditorInfo.IME_ACTION_GO
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                          event.action   == KeyEvent.ACTION_DOWN
            if (isGo || isEnter) { navigateTo(urlInput.text.toString()); true } else false
        }

        // ── Scroll → auto-hide the floating toggle button ────────────
        webView.onScrollCallback = { dy ->
            if (!urlBarVisible) {
                if (dy > 8) {
                    // Scrolling down → hide fab
                    hideToggleFab()
                    scrollHandler.removeCallbacks(showToggleRunnable)
                    scrollHandler.postDelayed(showToggleRunnable, SHOW_DELAY)
                } else if (dy < -8) {
                    // Scrolling up → show fab immediately
                    scrollHandler.removeCallbacks(showToggleRunnable)
                    showToggleFab(animate = true)
                }
            }
        }

        // Initialise icon tints
        updateFeatureIcons()
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView configuration
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled    = true
            domStorageEnabled    = true
            databaseEnabled      = true
            setSupportZoom(true)
            builtInZoomControls  = true
            displayZoomControls  = false
            userAgentString      = DESKTOP_UA
            loadWithOverviewMode = true
            useWideViewPort      = true
            allowFileAccess      = false
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        applyDataSaverSettings()

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                currentHost = url?.let {
                    try { java.net.URI(it).host?.removePrefix("www.") } catch (_: Exception) { null }
                }
                urlInput.setText(url ?: "")
                syncNavButtons()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                urlInput.setText(url ?: "")
                syncNavButtons()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = false

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                // Ad blocker
                if (adBlockEnabled && AdBlocker.shouldBlock(request, currentHost)) {
                    return AdBlocker.emptyResponse()
                }
                // Data saver – block third-party images/fonts/video
                if (dataSaverEnabled && AdBlocker.shouldBlockForDataSaver(request, currentHost)) {
                    return AdBlocker.emptyResponse()
                }
                return null
            }
        }

        webView.webChromeClient = WebChromeClient()
        webView.loadUrl(HOME_URL)
    }

    /**
     * Apply cache policy based on data-saver state.
     * Called once on init and again whenever dataSaverEnabled changes.
     */
    private fun applyDataSaverSettings() {
        webView.settings.cacheMode = if (dataSaverEnabled)
            WebSettings.LOAD_CACHE_ELSE_NETWORK   // prefer cache → fewer requests
        else
            WebSettings.LOAD_DEFAULT
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    // ══════════════════════════════════════════════════════════════════
    // Feature icon tinting
    // ══════════════════════════════════════════════════════════════════

    private fun updateFeatureIcons() {
        tintButton(btnAdBlock,  if (adBlockEnabled)  TINT_SHIELD else TINT_OFF)
        tintButton(btnDataSaver, if (dataSaverEnabled) TINT_BOLT  else TINT_OFF)
    }

    private fun tintButton(btn: ImageButton, color: Int) {
        btn.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar show / hide
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() {
        if (urlBarVisible) hideUrlBar() else showUrlBar()
    }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        // Always keep the fab visible while the URL bar is open
        showToggleFab(animate = false)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).setDuration(270).start()
        urlInput.post { urlInput.requestFocus() }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        dismissKeyboard()
        urlBar.animate()
            .translationY(-urlBar.height.toFloat())
            .setDuration(220)
            .withEndAction { urlBar.visibility = View.INVISIBLE }
            .start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Floating toggle-button show / hide (scroll-driven)
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (toggleVisible) return
        toggleVisible = true
        if (animate) {
            btnToggle.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(220)
                .start()
        } else {
            btnToggle.alpha        = 1f
            btnToggle.translationY = 0f
        }
    }

    private fun hideToggleFab() {
        if (!toggleVisible) return
        toggleVisible = false
        btnToggle.animate()
            .alpha(0f)
            .translationY(28f * resources.displayMetrics.density)
            .setDuration(200)
            .start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Navigation
    // ══════════════════════════════════════════════════════════════════

    private fun navigateTo(raw: String) {
        val s = raw.trim()
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ")                 -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url)
        hideUrlBar()
    }

    private fun dismissKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible       -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            else                -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }
}
