package com.hzcm.duelforge.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*

/** Selection state while the player is choosing tributes for a pending Normal Summon / Set. */
data class TributeSelection(
    val card: CardInstance,
    val asSet: Boolean,
    val required: Int,
    val chosen: List<CardInstance> = emptyList()
)

/**
 * Wraps [GameEngine] for the UI. [com.hzcm.duelforge.model.GameState] is a plain mutable
 * class, not Compose state, so every action bumps [refresh] to force recomposition - the
 * UI then reads fresh values straight from `engine.state`.
 */
class GameViewModel(application: Application) : AndroidViewModel(application) {
    val engine: GameEngine = GameEngine(application.applicationContext)

    /** Bumped after every engine mutation; read (but ignored) by composables that should recompose. */
    var refresh by mutableIntStateOf(0)
        private set

    /** A card (hand, own field monster, or own Spell/Trap zone) the player has tapped. */
    var selectedCard by mutableStateOf<CardInstance?>(null)
        private set

    /** Non-null while the player is choosing tributes for [selectedCard]. */
    var tributeSelection by mutableStateOf<TributeSelection?>(null)
        private set

    /** The attacker chosen during the Battle Phase, awaiting a target tap or direct-attack confirmation. */
    var attackerSelection by mutableStateOf<CardInstance?>(null)

    /**
     * The card(s) the player has tapped to discard while a [DiscardRequest] is pending.
     * The player must pick exactly [DiscardRequest.count] cards before "Confirm" enables.
     */
    var discardChosen by mutableStateOf<List<CardInstance>>(emptyList())
        private set

    /** Card currently shown in the full-screen preview overlay (null = hidden). */
    var previewCard by mutableStateOf<CardInstance?>(null)
        private set

    /**
     * True when the preview was triggered automatically (e.g. after a summon/activation)
     * so the overlay auto-dismisses after a short delay.
     */
    var previewAutoShow by mutableStateOf(false)
        private set

    /** Briefly true after an attack is declared; used to show the attack flash overlay. */
    var attackFlash by mutableStateOf(false)

    init {
        engine.startGame()
        refresh++
    }

    private fun bump() { refresh++ }

    // ------------------------------------------------------------------
    // Preview overlay
    // ------------------------------------------------------------------

    fun showSummonPreview(card: CardInstance) {
        previewCard = card
        previewAutoShow = true
    }

    fun showFieldPreview(card: CardInstance) {
        previewCard = card
        previewAutoShow = false
    }

    fun dismissPreview() {
        previewCard = null
        previewAutoShow = false
    }

    // ------------------------------------------------------------------
    // Selection
    // ------------------------------------------------------------------

    fun clearSelection() {
        selectedCard = null
        tributeSelection = null
        attackerSelection = null
    }

    /** Tap on a card in the human player's hand. */
    fun onHandCardTapped(card: CardInstance) {
        if (tributeSelection != null) return
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    /** Tap on one of the human player's own field monsters. */
    fun onOwnMonsterTapped(card: CardInstance) {
        if (tributeSelection != null) {
            toggleTribute(card)
            return
        }
        if (engine.state.phase == Phase.BATTLE) {
            selectedCard = null
            attackerSelection = if (attackerSelection === card) null else card
            return
        }
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    /** Tap on one of the human player's own Spell/Trap zone cards. */
    fun onOwnSpellTrapTapped(card: CardInstance) {
        if (tributeSelection != null) return
        attackerSelection = null
        selectedCard = if (selectedCard === card) null else card
    }

    /** Tap on an opponent's monster — if an attacker is selected and attack is legal, declares it. */
    fun onOpponentMonsterTapped(card: CardInstance) {
        val attacker = attackerSelection ?: return
        if (!engine.canDeclareAttack(attacker, card)) return
        attackerSelection = null
        attackFlash = true
        engine.declareAttack(attacker, card) { bump() }
        bump()
    }

    // ------------------------------------------------------------------
    // Summon / Set / Flip / Position
    // ------------------------------------------------------------------

    /** Begins Normal Summon (or Set, if [asSet]) for [selectedCard], opening tribute selection if needed. */
    fun beginSummon(asSet: Boolean) {
        val card = selectedCard ?: return
        val required = card.card.tributesRequired
        if (required > 0) {
            tributeSelection = TributeSelection(card, asSet, required)
            return
        }
        val summoned = card
        if (asSet) {
            engine.setMonster(card, emptyList()) { bump() }
        } else {
            engine.normalSummon(card, emptyList()) {
                showSummonPreview(summoned)
                bump()
            }
        }
        selectedCard = null
        bump()
    }

    private fun toggleTribute(card: CardInstance) {
        val sel = tributeSelection ?: return
        if (card.location != Location.MONSTER_ZONE || card.controller != PlayerId.PLAYER) return
        val chosen = sel.chosen.toMutableList()
        if (chosen.contains(card)) {
            chosen.remove(card)
        } else if (chosen.size < sel.required) {
            chosen.add(card)
        }
        tributeSelection = sel.copy(chosen = chosen)
    }

    fun confirmTributeSummon() {
        val sel = tributeSelection ?: return
        if (sel.chosen.size != sel.required) return
        val summoned = sel.card
        if (sel.asSet) {
            engine.setMonster(sel.card, sel.chosen) { bump() }
        } else {
            engine.normalSummon(sel.card, sel.chosen) {
                showSummonPreview(summoned)
                bump()
            }
        }
        tributeSelection = null
        selectedCard = null
        bump()
    }

    fun cancelTributeSummon() {
        tributeSelection = null
    }

    /** Sets a Spell or Trap card face-down from hand. */
    fun setTrap() {
        val card = selectedCard ?: return
        engine.setSpellOrTrap(card) { bump() }
        selectedCard = null
        bump()
    }

    /** Activates a Normal/Quick-Play Spell from hand, an effect on a field monster, or a set Spell from the field. */
    fun activateEffect(effect: CardEffect) {
        val card = selectedCard ?: return
        val activated = card
        engine.activateEffect(card, effect) {
            // Show a summon-style preview for spell/monster effect activations
            if (activated.card.isSpell || activated.card.isMonster) {
                showSummonPreview(activated)
            }
            bump()
        }
        selectedCard = null
        bump()
    }

    fun flipSummon() {
        val card = selectedCard ?: return
        val flipped = card
        engine.flipSummon(card) {
            showSummonPreview(flipped)
            bump()
        }
        selectedCard = null
        bump()
    }

    fun changeBattlePosition(newPosition: BattlePosition) {
        val card = selectedCard ?: return
        engine.changeBattlePosition(card, newPosition) { bump() }
        selectedCard = null
        bump()
    }

    // ------------------------------------------------------------------
    // Battle
    // ------------------------------------------------------------------

    fun declareDirectAttack() {
        val attacker = attackerSelection ?: return
        if (!engine.canDeclareAttack(attacker, null)) return
        attackerSelection = null
        attackFlash = true
        engine.declareAttack(attacker, null) { bump() }
        bump()
    }

    // ------------------------------------------------------------------
    // Phase / priority
    // ------------------------------------------------------------------

    fun advancePhase() {
        clearSelection()
        engine.advancePhase {
            if (engine.state.phase == Phase.BATTLE_START) {
                engine.advancePhase { bump() }
                bump()
            } else {
                bump()
            }
        }
        bump()
    }

    /** From Main Phase 1: proceed to Battle Phase. */
    fun goToBattlePhase() {
        clearSelection()
        engine.advancePhase {
            if (engine.state.phase == Phase.BATTLE_START) {
                engine.advancePhase { bump() }
                bump()
            } else {
                bump()
            }
        }
        bump()
    }

    /** From Main Phase 1: skip Battle Phase and go straight to Main Phase 2. */
    fun skipToMainPhase2() {
        clearSelection()
        skipPhasesUntil(Phase.MAIN2, 0)
    }

    /** Skip ahead to End Phase so the player can manually end the turn. */
    fun skipToEndPhase() {
        clearSelection()
        skipPhasesUntil(Phase.END, 0)
    }

    /**
     * Recursively advances phases until [target] is reached, gives up after [guard] safety
     * iterations, and always stops (without consuming the phase) if a chain or human
     * priority prompt appears - the player resolves that first via [submitPriorityChoice],
     * which naturally resumes this same chain of callbacks afterward.
     */
    private fun skipPhasesUntil(target: Phase, guard: Int) {
        if (engine.state.phase == target || engine.state.gameOver || guard >= 10 ||
            engine.state.chain.isNotEmpty() || engine.state.pendingHumanPriority != null
        ) {
            bump()
            return
        }
        engine.advancePhase {
            skipPhasesUntil(target, guard + 1)
        }
        bump()
    }

    fun submitPriorityChoice(index: Int?) {
        engine.submitPriorityChoice(index)
        bump()
    }

    /** Toggle a card in/out of the pending discard selection. */
    fun onDiscardCardToggled(card: CardInstance) {
        val req = engine.state.pendingDiscard ?: return
        val chosen = discardChosen.toMutableList()
        if (chosen.contains(card)) chosen.remove(card)
        else if (chosen.size < req.count) chosen.add(card)
        discardChosen = chosen
    }

    /**
     * Confirm the player's chosen discard(s), send them to the GY, and resume
     * chain resolution. Only callable when [discardChosen].size == [DiscardRequest.count].
     */
    fun confirmDiscard() {
        val callback = engine.pendingDiscardResume ?: return
        val chosen   = discardChosen.toList()
        engine.state.pendingDiscard = null
        engine.pendingDiscardResume = null
        discardChosen = emptyList()
        chosen.forEach { engine.sendToGraveyard(it) }
        callback(chosen)
        if (engine.state.chain.isNotEmpty()) engine.resolveChain()
        bump()
    }

    /** Restarts the duel from scratch (used by the "New Duel" button after a game over). */
    fun restart() {
        clearSelection()
        discardChosen = emptyList()
        dismissPreview()
        attackFlash = false
        engine.startGame()
        bump()
    }
}
