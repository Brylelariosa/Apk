# Adding Card Art

Drop an image file named after a card's `id` (from `app/src/main/assets/cards.json`)
into this folder. Supported extensions: `.png`, `.jpg`, `.jpeg`, `.webp`.

Example: to give "Wildclaw Tiger" (id `wildclaw_tiger`) artwork, add:

```
app/src/main/assets/cards/wildclaw_tiger.png
```

That's it - no code changes needed. If no image is found for a card, the app
generates a simple colored placeholder (color depends on card type) showing the
card's name, Level/Attribute/Race, and ATK/DEF.

Recommended image size: roughly square or slightly portrait (e.g. 400x580px),
since cards render at a ~0.7 width:height ratio. Images are cropped to fill the
card, so center the important art.

If a card's `id` and the image filename should differ for some reason, set
`"imageId": "some_other_name"` on that card's entry in `cards.json` and name the
image file after `some_other_name` instead.

---

# Adding a New Card

## Vanilla (no effect) monster, Spell, or Trap

Just add a new entry to `app/src/main/assets/cards.json`. Required/optional fields:

- `id` (string, unique, lowercase_with_underscores)
- `name` (string, display name)
- `cardType`: `"MONSTER"`, `"SPELL"`, or `"TRAP"`
- `description` (string, shown in the action panel)
- `count` (how many copies go in the main deck - optional, defaults to 1)

For monsters, also set:
- `attribute`: one of `DARK`, `LIGHT`, `EARTH`, `WATER`, `FIRE`, `WIND`, `DIVINE`
- `race`: one of `WARRIOR`, `SPELLCASTER`, `DRAGON`, `MACHINE`, `FIEND`, `BEAST`,
  `BEAST_WARRIOR`, `ZOMBIE`, `AQUA`, `PYRO`, `ROCK`, `WINGED_BEAST`, `FAIRY`,
  `INSECT`, `PLANT`, `DINOSAUR`
- `level` (1-12), `atk`, `def`
- `monsterCategory`: `"NORMAL"` for a vanilla monster

Tribute requirements are automatic from `level` (1-4: none, 5-6: one, 7+: two).

For Spells, set `spellType`: `"NORMAL"`, `"QUICK_PLAY"`, `"FIELD"`, `"CONTINUOUS"`,
or `"EQUIP"`. (Continuous/Equip Spells with no effect have no special handling beyond
staying on the field - they're included for future expansion.)

For Traps, set `trapType`: `"NORMAL"`, `"CONTINUOUS"`, or `"COUNTER"`.

## Monster/Spell/Trap WITH an effect

1. In `cards.json`, set `monsterCategory: "EFFECT"` (monsters) and optionally list
   the effect ids under `effectIds` (informational only - not read by code, but
   helpful documentation for yourself).
2. Open `app/src/main/java/com/hzcm/duelforge/data/EffectRegistry.kt` and add a new
   entry to the `registry` map, keyed by the card's `id`, with one `CardEffect` per
   ability. See the existing entries for examples of each `EffectTiming`:
   - `NORMAL` - Normal Spell activation from hand (your Main Phase only)
   - `IGNITION` - monster effect activated from the field (your Main Phase only)
   - `QUICK` - Quick-Play Spell / Quick Effect (from hand on your turn, OR offered
     as a chain response if face-up on the field / a face-down Trap / sitting in
     your Graveyard)
   - `TRIGGER` - auto-activates when its `canActivate` condition (checking
     `engine.state.lastEvent`) becomes true
   - `FLIP` - auto-activates when the card is turned face-up (Flip Summon or
     flipped by battle)
   - `CONTINUOUS` - not currently used by the chain system; continuous field-wide
     stat buffs are hand-coded in `GameEngine.computeAtk()`/`computeDef()` (see the
     Battlefield Overgrowth example there)

A `CardEffect` needs: `id` (unique string, for once-per-turn tracking),
`timing`, `description`, `canActivate`, and `resolve`. Optional: `targetSelector`,
`payCost`, `oncePerTurn`.

By default a `MONSTER` effect can only be activated/triggered while the card is
face-up in a Monster Zone. `TRIGGER` and `QUICK` effects are the exception: they're
also checked while the card sits in **hand** or the **Graveyard** (via
`openPriorityWindow`'s own-side scan and `getActivatableEffects`'s responder scan),
which is how cards like "Special Summon this from your hand when X happens" or
"banish this from the GY to do Y" work - just write a `canActivate` that checks
`source.location` explicitly. No engine changes needed.

## Fusion Monster (Extra Deck)

Set `"isExtraDeck": true`, `"monsterCategory": "FUSION"`, and
`"fusionMaterials"`: an array of requirement strings:
- `"SPECIFIC:card_id"` - requires that exact card
- `"RACE:RACE_NAME:count"` - requires `count` monsters of that Race (e.g. `"RACE:BEAST:2"`)
- `"ANY:count"` - requires `count` monsters of any kind

"Fusion Catalyst" automatically finds the first Fusion Monster in the Extra Deck
whose materials are available on the field and Fusion Summons it - no extra code
needed for a new Fusion Monster beyond its `cards.json` entry.
