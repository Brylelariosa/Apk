package com.game.topdown;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {
    private GameView gameView;

    @Override
    protected void attachBaseContext(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = 1.0f;
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        // ── Extend into the camera cutout (notch / punch-hole) ────────────────
        // SHORT_EDGES renders content behind the cutout on all edges in landscape.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                           | WindowManager.LayoutParams.FLAG_FULLSCREEN
                           | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        hideSystemUI();

        String  name         = getIntent().getStringExtra("name");
        boolean singlePlayer = getIntent().getBooleanExtra("singlePlayer", false);
        boolean host         = getIntent().getBooleanExtra("isHost", false);
        String  hostIp       = getIntent().getStringExtra("hostIp");

        if (singlePlayer) {
            gameView = new GameView(this, name, 2);
        } else {
            gameView = new GameView(this, name, host, hostIp);
        }
        setContentView(gameView);
    }

    /**
     * Hides status bar and navigation bar in sticky immersive mode.
     * Uses WindowInsetsController on API 30+ and the legacy flags on older versions
     * so the game truly fills every pixel including the cutout area.
     */
    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController ctrl = getWindow().getInsetsController();
            if (ctrl != null) {
                ctrl.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                ctrl.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            //noinspection deprecation
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    /** Re-hide when the system UI reappears (e.g. after a notification swipe). */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override protected void onPause()   { super.onPause();   if(gameView!=null) gameView.pause(); }
    @Override protected void onResume()  { super.onResume();  hideSystemUI(); if(gameView!=null) gameView.resume(); }
    @Override protected void onDestroy() { super.onDestroy(); if(gameView!=null) gameView.stopGame(); }
    @Override public void onBackPressed(){ if(gameView!=null) gameView.stopGame(); super.onBackPressed(); }
}
