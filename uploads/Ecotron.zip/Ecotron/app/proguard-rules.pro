# Keep the class with native methods intact so JNI bindings never break,
# even if minification is enabled in the future.
-keep class com.ecotron.app.NativeEngine { *; }
