#pragma once
#include <cstdint>

namespace ecotron {

// The four possible occupants of a grid cell.
enum class CellState : uint8_t {
    Empty = 0,
    Plant = 1,
    Herbivore = 2,
    Carnivore = 3
};

// A single cell: what occupies it, and (for animals) how much energy it has left.
struct Cell {
    CellState state = CellState::Empty;
    uint8_t energy = 0;
};

} // namespace ecotron
