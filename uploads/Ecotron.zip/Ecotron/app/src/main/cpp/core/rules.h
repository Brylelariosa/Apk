#pragma once
#include <cstdint>

namespace ecotron {

// All tunable constants for the ecosystem live here, isolated from the
// simulation logic itself, so behavior can be rebalanced without touching
// the update algorithm.
struct Rules {
    // --- Plants ---
    static constexpr float PLANT_GROWTH_BASE = 0.006f;         // chance an empty cell spontaneously sprouts
    static constexpr float PLANT_GROWTH_PER_NEIGHBOR = 0.05f;  // extra chance per adjacent plant
    static constexpr float PLANT_SPREAD_CHANCE = 0.20f;        // chance a plant spreads into an empty neighbor

    // --- Herbivores ---
    static constexpr uint8_t HERBIVORE_START_ENERGY = 60;
    static constexpr uint8_t HERBIVORE_EAT_GAIN = 35;
    static constexpr uint8_t HERBIVORE_METABOLISM = 4;
    static constexpr uint8_t HERBIVORE_REPRO_THRESHOLD = 90;
    static constexpr float HERBIVORE_TO_CARNIVORE_MUTATION = 0.01f; // rare evolutionary leap

    // --- Carnivores ---
    static constexpr uint8_t CARNIVORE_START_ENERGY = 70;
    static constexpr uint8_t CARNIVORE_EAT_GAIN = 55;
    static constexpr uint8_t CARNIVORE_METABOLISM = 6;
    static constexpr uint8_t CARNIVORE_REPRO_THRESHOLD = 120;
    static constexpr float CARNIVORE_TO_HERBIVORE_MUTATION = 0.02f; // rare evolutionary reversion

    static constexpr uint8_t MAX_ENERGY = 200;
};

} // namespace ecotron
