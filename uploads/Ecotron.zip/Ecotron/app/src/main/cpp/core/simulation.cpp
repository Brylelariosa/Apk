#include "simulation.h"
#include "rules.h"
#include <algorithm>

namespace ecotron {

namespace {

// Moore (8-cell) neighborhood offsets.
constexpr int OFFSETS[8][2] = {
    {-1, -1}, {0, -1}, {1, -1},
    {-1,  0},          {1,  0},
    {-1,  1}, {0,  1}, {1,  1}
};

int colorForCell(const Cell& c) {
    switch (c.state) {
        case CellState::Plant:     return static_cast<int>(0xFF2EA043);
        case CellState::Herbivore: return static_cast<int>(0xFF58A6FF);
        case CellState::Carnivore: return static_cast<int>(0xFFF85149);
        default:                   return static_cast<int>(0xFF0D1117);
    }
}

} // namespace

Simulation::Simulation(int width, int height, uint32_t seedValue)
    : current_(width, height), next_(width, height), rng_(seedValue) {
    seed(0.18f, 0.06f, 0.02f);
}

void Simulation::seed(float plantDensity, float herbivoreDensity, float carnivoreDensity) {
    current_.clear();
    for (int y = 0; y < current_.height(); ++y) {
        for (int x = 0; x < current_.width(); ++x) {
            float r = unitDist_(rng_);
            Cell c;
            if (r < carnivoreDensity) {
                c = Cell{CellState::Carnivore, Rules::CARNIVORE_START_ENERGY};
            } else if (r < carnivoreDensity + herbivoreDensity) {
                c = Cell{CellState::Herbivore, Rules::HERBIVORE_START_ENERGY};
            } else if (r < carnivoreDensity + herbivoreDensity + plantDensity) {
                c = Cell{CellState::Plant, 0};
            } else {
                c = Cell{};
            }
            current_.at(x, y) = c;
        }
    }
}

void Simulation::paint(int x, int y, int state) {
    auto s = static_cast<CellState>(state);
    uint8_t energy = 0;
    if (s == CellState::Herbivore) energy = Rules::HERBIVORE_START_ENERGY;
    if (s == CellState::Carnivore) energy = Rules::CARNIVORE_START_ENERGY;
    current_.at(x, y) = Cell{s, energy};
}

int Simulation::countNeighborsOfState(const Grid& g, int x, int y, CellState state) const {
    int count = 0;
    for (auto& off : OFFSETS) {
        if (g.at(x + off[0], y + off[1]).state == state) ++count;
    }
    return count;
}

bool Simulation::findRandomNeighborOfState(const Grid& g, int x, int y, CellState state, int& outX, int& outY) {
    // Start at a random offset each call so search order isn't directionally biased.
    int start = static_cast<int>(rng_() % 8);
    for (int i = 0; i < 8; ++i) {
        int idx = (start + i) % 8;
        int nx = x + OFFSETS[idx][0];
        int ny = y + OFFSETS[idx][1];
        if (g.at(nx, ny).state == state) {
            outX = g.wrapX(nx);
            outY = g.wrapY(ny);
            return true;
        }
    }
    return false;
}

bool Simulation::findRandomEmptyNeighbor(const Grid& g, int x, int y, int& outX, int& outY) {
    return findRandomNeighborOfState(g, x, y, CellState::Empty, outX, outY);
}

void Simulation::step() {
    // next_ starts as an exact copy of current_ and is mutated in place as we
    // scan; every read/write of a *target* cell goes through next_, so a cell
    // that has already been claimed earlier in this same tick (eaten, grown
    // into, moved into) is correctly seen as no longer available.
    next_ = current_;

    for (int y = 0; y < current_.height(); ++y) {
        for (int x = 0; x < current_.width(); ++x) {
            const Cell origin = current_.at(x, y);

            switch (origin.state) {
                case CellState::Empty: {
                    if (next_.at(x, y).state != CellState::Empty) break; // already filled this tick
                    int neighborPlants = countNeighborsOfState(current_, x, y, CellState::Plant);
                    float chance = Rules::PLANT_GROWTH_BASE + neighborPlants * Rules::PLANT_GROWTH_PER_NEIGHBOR;
                    if (unitDist_(rng_) < chance) {
                        next_.at(x, y) = Cell{CellState::Plant, 0};
                    }
                    break;
                }

                case CellState::Plant: {
                    if (unitDist_(rng_) < Rules::PLANT_SPREAD_CHANCE) {
                        int tx, ty;
                        if (findRandomEmptyNeighbor(next_, x, y, tx, ty)) {
                            next_.at(tx, ty) = Cell{CellState::Plant, 0};
                        }
                    }
                    break;
                }

                case CellState::Herbivore:
                case CellState::Carnivore: {
                    const bool isCarnivore = origin.state == CellState::Carnivore;
                    const CellState preyState = isCarnivore ? CellState::Herbivore : CellState::Plant;
                    const uint8_t eatGain = isCarnivore ? Rules::CARNIVORE_EAT_GAIN : Rules::HERBIVORE_EAT_GAIN;
                    const uint8_t metabolism = isCarnivore ? Rules::CARNIVORE_METABOLISM : Rules::HERBIVORE_METABOLISM;
                    const uint8_t reproThreshold = isCarnivore ? Rules::CARNIVORE_REPRO_THRESHOLD : Rules::HERBIVORE_REPRO_THRESHOLD;
                    const float mutationChance = isCarnivore ? Rules::CARNIVORE_TO_HERBIVORE_MUTATION : Rules::HERBIVORE_TO_CARNIVORE_MUTATION;

                    int tx = x, ty = y;
                    bool ate = false;
                    int fx, fy;

                    if (findRandomNeighborOfState(next_, x, y, preyState, fx, fy)) {
                        next_.at(x, y) = Cell{};
                        tx = fx; ty = fy;
                        ate = true;
                    } else if (findRandomEmptyNeighbor(next_, x, y, fx, fy)) {
                        next_.at(x, y) = Cell{};
                        tx = fx; ty = fy;
                    }

                    int energy = origin.energy + (ate ? eatGain : 0) - metabolism;
                    energy = std::min<int>(energy, Rules::MAX_ENERGY);

                    if (energy <= 0) {
                        next_.at(tx, ty) = Cell{};
                        break;
                    }

                    CellState finalState = origin.state;
                    int remainingEnergy = energy;

                    if (energy >= reproThreshold) {
                        int cx, cy;
                        if (findRandomEmptyNeighbor(next_, tx, ty, cx, cy)) {
                            int childEnergy = energy / 2;
                            remainingEnergy = energy - childEnergy;
                            CellState childState = finalState;
                            if (unitDist_(rng_) < mutationChance) {
                                childState = isCarnivore ? CellState::Herbivore : CellState::Carnivore;
                            }
                            next_.at(cx, cy) = Cell{childState, static_cast<uint8_t>(childEnergy)};
                        }
                    }

                    next_.at(tx, ty) = Cell{finalState, static_cast<uint8_t>(remainingEnergy)};
                    break;
                }
            }
        }
    }

    std::swap(current_, next_);
}

void Simulation::render(int* outPixels, int length) const {
    const int total = current_.width() * current_.height();
    const int n = std::min(length, total);
    for (int i = 0; i < n; ++i) {
        int x = i % current_.width();
        int y = i / current_.width();
        outPixels[i] = colorForCell(current_.at(x, y));
    }
}

void Simulation::stats(int* outCounts) const {
    outCounts[0] = outCounts[1] = outCounts[2] = 0;
    for (int y = 0; y < current_.height(); ++y) {
        for (int x = 0; x < current_.width(); ++x) {
            switch (current_.at(x, y).state) {
                case CellState::Plant:     ++outCounts[0]; break;
                case CellState::Herbivore: ++outCounts[1]; break;
                case CellState::Carnivore: ++outCounts[2]; break;
                default: break;
            }
        }
    }
}

} // namespace ecotron
