#pragma once
#include <vector>
#include "cell.h"

namespace ecotron {

// A fixed-size 2D grid of cells with toroidal (wrap-around) topology.
class Grid {
public:
    Grid(int width, int height);

    int width() const { return width_; }
    int height() const { return height_; }

    // Coordinates are wrapped automatically, so callers may pass any int,
    // including negative values or values past the edge.
    Cell& at(int x, int y);
    const Cell& at(int x, int y) const;

    int wrapX(int x) const;
    int wrapY(int y) const;

    void clear();

private:
    int index(int x, int y) const { return y * width_ + x; }

    int width_;
    int height_;
    std::vector<Cell> cells_;
};

} // namespace ecotron
