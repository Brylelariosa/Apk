#pragma once
#include <random>
#include "grid.h"

namespace ecotron {

// The Ecotron ecosystem engine.
//
// This class is deliberately Android/JNI-agnostic: it only knows about
// grids, cells and rules, which makes it easy to unit-test in isolation
// (see /tests) and reusable outside of Android entirely.
class Simulation {
public:
    Simulation(int width, int height, uint32_t seedValue);

    // Advances the ecosystem by one generation.
    void step();

    // Reseeds the grid with fresh random populations at the given densities
    // (each in [0,1], and plantDensity + herbivoreDensity + carnivoreDensity <= 1).
    void seed(float plantDensity, float herbivoreDensity, float carnivoreDensity);

    // Places a single cell of the given state (see CellState) at (x, y).
    void paint(int x, int y, int state);

    // Writes one ARGB_8888 color per cell into outPixels, row-major, up to `length` entries.
    void render(int* outPixels, int length) const;

    // Writes [plantCount, herbivoreCount, carnivoreCount] into outCounts.
    void stats(int* outCounts) const;

    int width() const { return current_.width(); }
    int height() const { return current_.height(); }

private:
    int countNeighborsOfState(const Grid& g, int x, int y, CellState state) const;
    bool findRandomNeighborOfState(const Grid& g, int x, int y, CellState state, int& outX, int& outY);
    bool findRandomEmptyNeighbor(const Grid& g, int x, int y, int& outX, int& outY);

    Grid current_;
    Grid next_;
    std::mt19937 rng_;
    std::uniform_real_distribution<float> unitDist_{0.0f, 1.0f};
};

} // namespace ecotron
