#include "grid.h"
#include <algorithm>

namespace ecotron {

Grid::Grid(int width, int height)
    : width_(width), height_(height), cells_(static_cast<size_t>(width) * height) {}

Cell& Grid::at(int x, int y) {
    return cells_[index(wrapX(x), wrapY(y))];
}

const Cell& Grid::at(int x, int y) const {
    return cells_[index(wrapX(x), wrapY(y))];
}

int Grid::wrapX(int x) const {
    int r = x % width_;
    return r < 0 ? r + width_ : r;
}

int Grid::wrapY(int y) const {
    int r = y % height_;
    return r < 0 ? r + height_ : r;
}

void Grid::clear() {
    std::fill(cells_.begin(), cells_.end(), Cell{});
}

} // namespace ecotron
