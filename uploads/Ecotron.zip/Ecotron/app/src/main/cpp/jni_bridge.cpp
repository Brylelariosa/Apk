// Thin JNI translation layer. All simulation logic lives in core/ and knows
// nothing about JNI or Android; this file only marshals data across the
// boundary, keyed on an opaque handle so multiple instances are possible
// and no global/static state is required.

#include <jni.h>
#include <cstdint>
#include "core/simulation.h"

namespace {
inline ecotron::Simulation* toSim(jlong handle) {
    return reinterpret_cast<ecotron::Simulation*>(handle);
}
} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_ecotron_app_NativeEngine_nativeCreate(JNIEnv*, jobject, jint width, jint height, jlong seedValue) {
    auto* sim = new ecotron::Simulation(width, height, static_cast<uint32_t>(seedValue));
    return reinterpret_cast<jlong>(sim);
}

JNIEXPORT void JNICALL
Java_com_ecotron_app_NativeEngine_nativeDestroy(JNIEnv*, jobject, jlong handle) {
    delete toSim(handle);
}

JNIEXPORT void JNICALL
Java_com_ecotron_app_NativeEngine_nativeStep(JNIEnv*, jobject, jlong handle) {
    toSim(handle)->step();
}

JNIEXPORT void JNICALL
Java_com_ecotron_app_NativeEngine_nativeRender(JNIEnv* env, jobject, jlong handle, jintArray pixels) {
    ecotron::Simulation* sim = toSim(handle);
    jsize len = env->GetArrayLength(pixels);
    jint* buf = env->GetIntArrayElements(pixels, nullptr);
    sim->render(reinterpret_cast<int*>(buf), static_cast<int>(len));
    env->ReleaseIntArrayElements(pixels, buf, 0);
}

JNIEXPORT void JNICALL
Java_com_ecotron_app_NativeEngine_nativeSeed(JNIEnv*, jobject, jlong handle,
                                              jfloat plantDensity, jfloat herbivoreDensity, jfloat carnivoreDensity) {
    toSim(handle)->seed(plantDensity, herbivoreDensity, carnivoreDensity);
}

JNIEXPORT void JNICALL
Java_com_ecotron_app_NativeEngine_nativePaint(JNIEnv*, jobject, jlong handle, jint x, jint y, jint state) {
    toSim(handle)->paint(x, y, state);
}

JNIEXPORT jintArray JNICALL
Java_com_ecotron_app_NativeEngine_nativeGetStats(JNIEnv* env, jobject, jlong handle) {
    int counts[3] = {0, 0, 0};
    toSim(handle)->stats(counts);
    jintArray result = env->NewIntArray(3);
    env->SetIntArrayRegion(result, 0, 3, counts);
    return result;
}

} // extern "C"
