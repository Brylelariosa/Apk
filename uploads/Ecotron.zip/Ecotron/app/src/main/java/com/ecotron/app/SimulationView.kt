package com.ecotron.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * Renders the Ecotron grid as a small off-screen bitmap (one pixel per cell)
 * that is then scaled up to fill the view - fast, since only a small bitmap
 * needs to be produced each tick, and the GPU handles the scaling.
 *
 * Owns its own [NativeEngine] instance, created/recreated to match the
 * view's size in [onSizeChanged], so rotating the device gives a freshly
 * sized ecosystem rather than a stretched one.
 */
class SimulationView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Called after every [advance] with the latest population counts. */
    var onStatsChanged: ((plants: Int, herbivores: Int, carnivores: Int) -> Unit)? = null

    private var engine: NativeEngine? = null
    private var pixelBuffer = IntArray(0)
    private var bitmap: Bitmap? = null
    private val srcRect = Rect()
    private val dstRect = Rect()
    private val drawPaint = Paint().apply {
        isFilterBitmap = false // nearest-neighbor scaling keeps cells crisp, not blurry
        isAntiAlias = false
    }

    private var gridWidth = 0
    private var gridHeight = 0
    private var brushState = NativeEngine.STATE_PLANT

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return

        val density = resources.displayMetrics.density
        val cellPx = max(1f, CELL_SIZE_DP * density)
        gridWidth = max(8, (w / cellPx).toInt())
        gridHeight = max(8, (h / cellPx).toInt())

        engine?.destroy()
        engine = NativeEngine(gridWidth, gridHeight).also {
            it.reseed(0.18f, 0.06f, 0.02f)
        }

        pixelBuffer = IntArray(gridWidth * gridHeight)
        bitmap = Bitmap.createBitmap(gridWidth, gridHeight, Bitmap.Config.ARGB_8888)
        srcRect.set(0, 0, gridWidth, gridHeight)
        dstRect.set(0, 0, w, h)
    }

    /** Steps the simulation once, re-renders the bitmap, and reports fresh stats. */
    fun advance() {
        val e = engine ?: return
        e.step()
        refreshBitmap(e)
        val stats = e.stats()
        onStatsChanged?.invoke(stats[0], stats[1], stats[2])
    }

    /** Reseeds the current grid with fresh random populations. */
    fun reset(plantDensity: Float = 0.18f, herbivoreDensity: Float = 0.06f, carnivoreDensity: Float = 0.02f) {
        val e = engine ?: return
        e.reseed(plantDensity, herbivoreDensity, carnivoreDensity)
        refreshBitmap(e)
    }

    /** Sets which organism gets painted on touch (see NativeEngine.STATE_*). */
    fun setBrush(state: Int) {
        brushState = state
    }

    private fun refreshBitmap(e: NativeEngine) {
        e.render(pixelBuffer)
        bitmap?.setPixels(pixelBuffer, 0, gridWidth, 0, 0, gridWidth, gridHeight)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        bitmap?.let { canvas.drawBitmap(it, srcRect, dstRect, drawPaint) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val e = engine ?: return false
        if (width == 0 || height == 0) return false
        if (event.action == MotionEvent.ACTION_DOWN || event.action == MotionEvent.ACTION_MOVE) {
            val gx = (event.x / width * gridWidth).toInt().coerceIn(0, gridWidth - 1)
            val gy = (event.y / height * gridHeight).toInt().coerceIn(0, gridHeight - 1)
            e.paint(gx, gy, brushState)
            refreshBitmap(e)
            return true
        }
        return false
    }

    /** Releases the native engine. Call from the host Activity's onDestroy. */
    fun destroy() {
        engine?.destroy()
        engine = null
    }

    companion object {
        private const val CELL_SIZE_DP = 6f
    }
}
