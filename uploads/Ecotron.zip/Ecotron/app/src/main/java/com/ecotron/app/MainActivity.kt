package com.ecotron.app

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var simulationView: SimulationView
    private lateinit var statsText: TextView
    private lateinit var playPauseButton: Button

    private val mainHandler = Handler(Looper.getMainLooper())
    private var running = false
    private var stepIntervalMs = MID_INTERVAL_MS

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (running) {
                simulationView.advance()
                mainHandler.postDelayed(this, stepIntervalMs)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        simulationView = findViewById(R.id.simulationView)
        statsText = findViewById(R.id.statsText)
        playPauseButton = findViewById(R.id.playPauseButton)
        val resetButton: Button = findViewById(R.id.resetButton)
        val speedSeekBar: SeekBar = findViewById(R.id.speedSeekBar)
        val plantBrush: Button = findViewById(R.id.brushPlant)
        val herbivoreBrush: Button = findViewById(R.id.brushHerbivore)
        val carnivoreBrush: Button = findViewById(R.id.brushCarnivore)
        val eraseBrush: Button = findViewById(R.id.brushErase)

        simulationView.onStatsChanged = { plants, herbivores, carnivores ->
            statsText.text = getString(R.string.stats_format, plants, herbivores, carnivores)
        }

        playPauseButton.setOnClickListener {
            running = !running
            playPauseButton.text = getString(if (running) R.string.pause else R.string.play)
            if (running) mainHandler.post(tickRunnable)
        }

        resetButton.setOnClickListener { simulationView.reset() }

        plantBrush.setOnClickListener { simulationView.setBrush(NativeEngine.STATE_PLANT) }
        herbivoreBrush.setOnClickListener { simulationView.setBrush(NativeEngine.STATE_HERBIVORE) }
        carnivoreBrush.setOnClickListener { simulationView.setBrush(NativeEngine.STATE_CARNIVORE) }
        eraseBrush.setOnClickListener { simulationView.setBrush(NativeEngine.STATE_EMPTY) }

        speedSeekBar.max = 100
        speedSeekBar.progress = DEFAULT_SPEED_PROGRESS
        speedSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                stepIntervalMs = progressToIntervalMs(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        stepIntervalMs = progressToIntervalMs(DEFAULT_SPEED_PROGRESS)
    }

    private fun progressToIntervalMs(progress: Int): Long {
        // Higher progress = faster simulation = shorter interval.
        val clamped = progress.coerceIn(0, 100)
        return (SLOWEST_INTERVAL_MS - clamped * MS_PER_STEP).toLong().coerceAtLeast(FASTEST_INTERVAL_MS)
    }

    override fun onPause() {
        super.onPause()
        running = false
        mainHandler.removeCallbacks(tickRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        simulationView.destroy()
    }

    companion object {
        private const val SLOWEST_INTERVAL_MS = 400.0
        private const val FASTEST_INTERVAL_MS = 16L
        private const val MS_PER_STEP = 3.84
        private const val DEFAULT_SPEED_PROGRESS = 60
        private const val MID_INTERVAL_MS = 170L
    }
}
