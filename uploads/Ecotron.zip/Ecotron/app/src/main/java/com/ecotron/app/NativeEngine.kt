package com.ecotron.app

/**
 * Kotlin-side handle to a native Ecotron simulation instance.
 *
 * Each instance owns a native `Simulation*` behind an opaque handle rather
 * than relying on global/static native state, so multiple instances could
 * coexist safely if ever needed. [destroy] must be called when finished
 * with an instance to free the native memory.
 */
class NativeEngine(width: Int, height: Int, seedValue: Long = System.nanoTime()) {

    private var handle: Long = nativeCreate(width, height, seedValue)

    /** Advances the ecosystem by one generation. */
    fun step() = nativeStep(handle)

    /** Fills [pixels] with one ARGB_8888 color per cell, row-major. */
    fun render(pixels: IntArray) = nativeRender(handle, pixels)

    /** Reseeds the grid with fresh random populations at the given densities (each in 0f..1f). */
    fun reseed(plantDensity: Float, herbivoreDensity: Float, carnivoreDensity: Float) =
        nativeSeed(handle, plantDensity, herbivoreDensity, carnivoreDensity)

    /** Places a single organism (see STATE_* constants) at grid cell (x, y). */
    fun paint(x: Int, y: Int, state: Int) = nativePaint(handle, x, y, state)

    /** Returns [plantCount, herbivoreCount, carnivoreCount]. */
    fun stats(): IntArray = nativeGetStats(handle)

    /** Frees the native simulation. Safe to call more than once. */
    fun destroy() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    private external fun nativeCreate(width: Int, height: Int, seedValue: Long): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeStep(handle: Long)
    private external fun nativeRender(handle: Long, pixels: IntArray)
    private external fun nativeSeed(handle: Long, plantDensity: Float, herbivoreDensity: Float, carnivoreDensity: Float)
    private external fun nativePaint(handle: Long, x: Int, y: Int, state: Int)
    private external fun nativeGetStats(handle: Long): IntArray

    companion object {
        init {
            System.loadLibrary("ecotron")
        }

        const val STATE_EMPTY = 0
        const val STATE_PLANT = 1
        const val STATE_HERBIVORE = 2
        const val STATE_CARNIVORE = 3
    }
}
