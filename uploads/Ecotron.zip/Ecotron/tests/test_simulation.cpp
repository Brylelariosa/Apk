// Standalone sanity test for the Ecotron core simulation engine.
//
// This is NOT part of the Android/Gradle/CMake build - the core engine is
// plain, portable C++ with zero Android/JNI dependencies, so it can be
// compiled and exercised on its own. Run it locally with (single line):
//
//   g++ -std=c++17 -O2 ../app/src/main/cpp/core/grid.cpp ../app/src/main/cpp/core/simulation.cpp test_simulation.cpp -o test_sim && ./test_sim

#include <cstdio>
#include "../app/src/main/cpp/core/simulation.h"

int main() {
    ecotron::Simulation sim(64, 64, 1234);

    for (int gen = 0; gen <= 300; ++gen) {
        if (gen % 20 == 0) {
            int counts[3];
            sim.stats(counts);
            std::printf("gen %3d  plants=%4d  herbivores=%4d  carnivores=%4d\n",
                        gen, counts[0], counts[1], counts[2]);
        }
        sim.step();
    }
    return 0;
}
