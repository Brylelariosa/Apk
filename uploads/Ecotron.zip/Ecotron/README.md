# Ecotron

A living-ecosystem cellular automaton for Android — not Conway's Game of Life.
Instead of a single binary birth/death rule, Ecotron simulates three
interacting populations on a grid:

- 🌱 **Plants** grow spontaneously and spread into empty neighboring cells.
- 🐇 **Herbivores** hunt plants, spend energy every tick, and reproduce when
  well-fed.
- 🐺 **Carnivores** hunt herbivores the same way, but need more energy to
  survive and reproduce.

The twist that makes this a genuinely new automaton, not a Life variant:
**reproduction has a small chance of mutating a herbivore's offspring into a
carnivore, or a carnivore's offspring into a herbivore.** Combined with
energy-driven death, movement, and reproduction, this produces real
predator-prey population cycles (boom-and-bust plant/herbivore waves, rare
but persistent apex predators) that emerge from the rules rather than being
scripted.

Tap the grid to paint your own plants, herbivores, or carnivores with the
brush buttons at the bottom; drag the slider to speed up or slow down time.

## Architecture

The simulation core is plain, portable C++ with **no Android or JNI
dependency at all** — it's a reusable engine that happens to be driven by an
Android UI:

```
app/src/main/cpp/
├── core/                 # Pure C++ simulation engine (portable, testable)
│   ├── cell.h            # The Cell/CellState data model
│   ├── rules.h           # All tunable constants, isolated from logic
│   ├── grid.h / .cpp     # Toroidal grid container
│   └── simulation.h/.cpp # Step/seed/paint/render/stats — the actual rules
├── jni_bridge.cpp        # Thin JNI translation layer only — no game logic
└── CMakeLists.txt

app/src/main/java/com/ecotron/app/
├── NativeEngine.kt       # Kotlin wrapper around the native handle (only
│                         # file that knows JNI exists)
├── SimulationView.kt     # Renders the grid to a bitmap, handles touch input
└── MainActivity.kt       # Wires up UI controls (play/pause/speed/brush)
```

Because the engine has zero Android dependencies, it can be compiled and
tested completely standalone:

```bash
cd tests
g++ -std=c++17 -O2 ../app/src/main/cpp/core/grid.cpp ../app/src/main/cpp/core/simulation.cpp test_simulation.cpp -o test_sim
./test_sim
```

Rendering works by having the native engine write one ARGB color per cell
into a small `IntArray`, which becomes a tiny bitmap that's scaled up to fill
the screen — only one JNI call per frame, and the GPU does the upscaling.

Tuning the ecosystem's behavior (growth rates, energy costs, reproduction
thresholds, mutation chance) only requires editing the constants in
`core/rules.h` — the update algorithm in `simulation.cpp` never needs to
change for rebalancing.

## Building via CI

This project is structured to drop straight into the existing "Build APK"
GitHub Actions workflow:

1. Zip this whole `Ecotron/` folder: `zip -r Ecotron.zip Ecotron/`
2. Commit the zip to your repo under `uploads/Ecotron.zip`
3. Push to `main`/`master` — the workflow triggers automatically, builds the
   APK (native library + all ABIs), and uploads it as a workflow artifact
4. The workflow deletes the zip from the repo afterward so it won't
   re-trigger on the next push

## Building locally

Requires JDK 17, Android SDK (compileSdk 34), and NDK 25.2.9519653 / CMake
3.22.1 (matching the CI workflow's pinned versions):

```bash
./gradlew assembleDebug
```

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
