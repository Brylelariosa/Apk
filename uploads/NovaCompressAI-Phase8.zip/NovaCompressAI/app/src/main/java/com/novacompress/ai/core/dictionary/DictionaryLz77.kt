package com.novacompress.ai.core.dictionary

import com.novacompress.ai.core.common.BinaryIO
import java.io.ByteArrayOutputStream

/**
 * LZ77 with a preset dictionary, per the spec's Dictionary Section: the
 * dictionary bytes conceptually precede the input in the match-search
 * buffer (seeded into the hash chains before any input byte is
 * processed), so even the very first bytes of the input can reference
 * patterns already established in the dictionary - something ordinary
 * per-chunk LZ77 can never do across a chunk boundary, since each chunk
 * is otherwise compressed independently.
 *
 * Not a [com.novacompress.ai.core.plugins.CompressionPlugin]: the
 * dictionary is a third parameter varying per archive, which doesn't fit
 * that interface's plain `compress(ByteArray)` contract. Used directly by
 * [com.novacompress.ai.core.archive.NovaDictionaryArchiveWriter] instead.
 *
 * Stream format: [originalLength: 4 bytes BE][dictionaryLength: 4 bytes BE]
 * followed by the same packed literal/match token groups as [com.novacompress.ai.core.plugins.Lz77Plugin].
 */
object DictionaryLz77 {

    private const val WINDOW_SIZE = 32768
    private const val MIN_MATCH = 3
    private const val MAX_MATCH = 258
    private const val TOKENS_PER_GROUP = 8

    fun compress(dictionary: ByteArray, input: ByteArray): ByteArray {
        val dictLen = dictionary.size
        val buffer = dictionary + input
        val n = input.size
        val out = ByteArrayOutputStream()
        BinaryIO.writeU32(out, n)
        BinaryIO.writeU32(out, dictLen)
        if (n == 0) return out.toByteArray()

        fun byteAt(i: Int): Int = buffer[i].toInt() and 0xFF
        fun hash3(i: Int): Int = (byteAt(i) shl 16) or (byteAt(i + 1) shl 8) or byteAt(i + 2)

        val head = HashMap<Int, Int>()
        val prev = IntArray(buffer.size) { -1 }

        fun insert(pos: Int) {
            if (pos + MIN_MATCH <= buffer.size) {
                val key = hash3(pos)
                prev[pos] = head[key] ?: -1
                head[key] = pos
            }
        }

        // Seed the hash chains with the dictionary itself.
        for (i in 0 until dictLen) insert(i)

        fun findMatch(cur: Int): Pair<Int, Int> {
            if (cur + MIN_MATCH > buffer.size) return 0 to 0
            val key = hash3(cur)
            var bestLen = 0
            var bestDist = 0
            var pos = head[key] ?: -1
            var tries = 0
            val maxPossible = minOf(MAX_MATCH, buffer.size - cur)
            while (pos != -1 && (cur - pos) <= WINDOW_SIZE && tries < 64) {
                tries++
                var length = 0
                while (length < maxPossible && buffer[pos + length] == buffer[cur + length]) {
                    length++
                }
                if (length > bestLen && length >= MIN_MATCH) {
                    bestLen = length
                    bestDist = cur - pos
                    if (bestLen == maxPossible) break
                }
                pos = prev[pos]
            }
            return bestLen to bestDist
        }

        var flagByte = 0
        var tokenIndexInGroup = 0
        val body = ByteArrayOutputStream()

        fun flushGroup() {
            out.write(flagByte)
            body.writeTo(out)
            body.reset()
            flagByte = 0
            tokenIndexInGroup = 0
        }

        var cur = dictLen
        val end = buffer.size
        while (cur < end) {
            val (length, dist) = findMatch(cur)
            if (length >= MIN_MATCH) {
                body.write((dist shr 8) and 0xFF)
                body.write(dist and 0xFF)
                body.write(length - MIN_MATCH)
                val stop = cur + length
                while (cur < stop) {
                    insert(cur)
                    cur++
                }
            } else {
                flagByte = flagByte or (1 shl tokenIndexInGroup)
                body.write(byteAt(cur))
                insert(cur)
                cur++
            }
            tokenIndexInGroup++
            if (tokenIndexInGroup == TOKENS_PER_GROUP) flushGroup()
        }
        if (tokenIndexInGroup > 0) flushGroup()

        return out.toByteArray()
    }

    fun decompress(dictionary: ByteArray, input: ByteArray): ByteArray {
        val n = BinaryIO.readU32(input, 0)
        val storedDictLen = BinaryIO.readU32(input, 4)
        require(storedDictLen == dictionary.size) {
            "dictionary length mismatch: archive expects $storedDictLen bytes, got ${dictionary.size}"
        }
        var pos = 8

        val buffer = ByteArray(dictionary.size + n)
        dictionary.copyInto(buffer)
        var produced = 0

        while (produced < n) {
            val flagByte = input[pos].toInt() and 0xFF
            pos++
            var gi = 0
            while (gi < TOKENS_PER_GROUP && produced < n) {
                val isLiteral = (flagByte shr gi) and 1
                val writeAt = dictionary.size + produced
                if (isLiteral == 1) {
                    buffer[writeAt] = input[pos]
                    pos++
                    produced++
                } else {
                    val dist = ((input[pos].toInt() and 0xFF) shl 8) or (input[pos + 1].toInt() and 0xFF)
                    val length = (input[pos + 2].toInt() and 0xFF) + MIN_MATCH
                    pos += 3
                    val start = writeAt - dist
                    for (k in 0 until length) {
                        buffer[writeAt + k] = buffer[start + k]
                    }
                    produced += length
                }
                gi++
            }
        }
        return buffer.copyOfRange(dictionary.size, dictionary.size + n)
    }
}
