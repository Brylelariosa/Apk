package com.novacompress.ai.ui.developer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/**
 * A labeled capacity bar (current value against a fixed cap) - e.g.
 * "Genome Population: 340 / 500". Box-based like [com.novacompress.ai.ui.research.SimpleBarChart]
 * rather than Material3's [androidx.compose.material3.LinearProgressIndicator],
 * to sidestep that API's progress-parameter shape changing across
 * Material3 versions (deprecated float overload vs. newer lambda overload)
 * - this stays correct regardless of which Material3 patch version the
 * project's Compose BOM happens to resolve to.
 */
@Composable
fun CapacityBar(
    label: String,
    valueText: String,
    fraction: Float,
    modifier: Modifier = Modifier,
    warningThreshold: Float = 0.85f
) {
    val barColor = if (fraction >= warningThreshold) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
    Column(modifier = modifier) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(valueText, style = MaterialTheme.typography.labelLarge)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                .semantics { contentDescription = "$label: $valueText" }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = fraction.coerceIn(0f, 1f))
                    .background(barColor, RoundedCornerShape(4.dp))
            )
        }
    }
}
