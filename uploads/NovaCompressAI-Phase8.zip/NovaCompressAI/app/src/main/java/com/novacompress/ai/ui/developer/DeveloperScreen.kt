@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.novacompress.ai.ui.developer

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.novacompress.ai.R
import com.novacompress.ai.core.plugins.sdk.PluginInfo
import com.novacompress.ai.core.plugins.sdk.PluginInfoRegistry
import com.novacompress.ai.data.repository.DatabaseUsageSnapshot
import com.novacompress.ai.data.repository.GenomeSummary
import com.novacompress.ai.data.repository.PluginDiagnostic
import com.novacompress.ai.ui.common.novaViewModel

/**
 * Developer Mode: read-only inspectors (Genome/Pipeline/Plugin/Database)
 * plus a live thread/memory monitor, per Phase 8's spec. Reached from
 * Settings rather than the bottom navigation bar - like Android's own
 * Developer Options, this is advanced-user surface most people never need,
 * and a 6th bottom-nav tab would both crowd Material 3's recommended
 * max of 5 destinations and put diagnostic clutter in front of the
 * beginner users the spec explicitly wants to "easily compress files."
 */
@Composable
fun DeveloperScreen(onBack: () -> Unit) {
    val viewModel: DeveloperViewModel = novaViewModel()
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.developer_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.developer_back))
                    }
                }
            )
        }
    ) { innerPadding ->
        BoxWithConstraints(modifier = Modifier.padding(innerPadding)) {
            val isWideScreen = maxWidth >= 600.dp

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        stringResource(R.string.developer_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (isWideScreen) {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            SystemMonitorCard(uiState, modifier = Modifier.weight(1f))
                            DatabaseUsageCard(uiState.databaseUsage, modifier = Modifier.weight(1f))
                        }
                    }
                } else {
                    item { SystemMonitorCard(uiState, modifier = Modifier.fillMaxWidth()) }
                    item { DatabaseUsageCard(uiState.databaseUsage, modifier = Modifier.fillMaxWidth()) }
                }

                item {
                    Text(stringResource(R.string.developer_plugin_section), style = MaterialTheme.typography.titleMedium)
                }
                items(uiState.plugins, key = { it.info.id }) { diagnostic ->
                    PluginDiagnosticRow(diagnostic)
                }

                item {
                    Text(stringResource(R.string.developer_genome_section), style = MaterialTheme.typography.titleMedium)
                }
                if (uiState.genomes.isEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.developer_no_genomes),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    items(uiState.genomes, key = { it.genomeId }) { genome ->
                        GenomePipelineRow(genome)
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemMonitorCard(uiState: DeveloperUiState, modifier: Modifier = Modifier) {
    ElevatedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(stringResource(R.string.developer_system_monitor_section), style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(12.dp))
            val resource = uiState.systemResource
            if (resource == null) {
                Text(
                    stringResource(R.string.developer_loading),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                CapacityBar(
                    label = stringResource(R.string.developer_heap_usage_label),
                    valueText = "${formatBytes(resource.usedHeapBytes)} / ${formatBytes(resource.maxHeapBytes)}",
                    fraction = resource.heapUsedFraction
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    stringResource(R.string.developer_native_heap_label, formatBytes(resource.nativeHeapAllocatedBytes)),
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    stringResource(R.string.developer_thread_count_label, resource.activeThreadCount),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun DatabaseUsageCard(usage: DatabaseUsageSnapshot?, modifier: Modifier = Modifier) {
    ElevatedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(stringResource(R.string.developer_database_section), style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(12.dp))
            if (usage != null) {
                CapacityBar(
                    label = stringResource(R.string.developer_genome_population_label),
                    valueText = "${usage.activeGenomeCount} / ${usage.maxActiveGenomes}",
                    fraction = usage.genomeCountFraction
                )
                Spacer(modifier = Modifier.height(10.dp))
                CapacityBar(
                    label = stringResource(R.string.developer_database_size_label),
                    valueText = "${formatBytes(usage.databaseFileBytes)} / ${formatBytes(usage.maxDatabaseBytes)}",
                    fraction = usage.databaseSizeFraction
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    stringResource(R.string.developer_retired_genomes_label, usage.retiredGenomeCount),
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    stringResource(R.string.developer_benchmark_count_label, usage.benchmarkCount),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun PluginDiagnosticRow(diagnostic: PluginDiagnostic) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(diagnostic.info.displayName, style = MaterialTheme.typography.titleMedium)
                CertificationBadge(diagnostic)
            }
            Text(
                diagnostic.info.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(formatCategoryName(diagnostic.info.category.name), style = MaterialTheme.typography.labelLarge)
                if (diagnostic.info.streamingSupport) {
                    Text(stringResource(R.string.developer_pipeline_stage_streaming), style = MaterialTheme.typography.labelLarge)
                }
                if (diagnostic.info.experimental) {
                    Text(stringResource(R.string.developer_pipeline_stage_experimental), style = MaterialTheme.typography.labelLarge)
                }
            }
            if (diagnostic.userDisabled) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    stringResource(R.string.developer_plugin_user_disabled),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun CertificationBadge(diagnostic: PluginDiagnostic) {
    val passed = diagnostic.certification?.passed ?: true
    val (label, color) = if (passed) {
        stringResource(R.string.developer_plugin_certified) to MaterialTheme.colorScheme.primary
    } else {
        stringResource(R.string.developer_plugin_failed) to MaterialTheme.colorScheme.error
    }
    Surface(
        color = color.copy(alpha = 0.15f),
        contentColor = color,
        shape = RoundedCornerShape(50),
        border = if (!passed) BorderStroke(1.dp, color) else null
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun GenomePipelineRow(genome: GenomeSummary) {
    var expanded by remember { mutableStateOf(false) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(genome.displayName, style = MaterialTheme.typography.titleMedium)
            Text(
                genome.pipelineDescription,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (expanded) {
                Spacer(modifier = Modifier.height(10.dp))
                genome.pluginIds.forEachIndexed { index, pluginId ->
                    PipelineStageRow(stageNumber = index + 1, pluginId = pluginId)
                    if (index != genome.pluginIds.lastIndex) {
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PipelineStageRow(stageNumber: Int, pluginId: String) {
    val info: PluginInfo? = PluginInfoRegistry.get(pluginId)
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("$stageNumber.", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Column {
            Text(info?.displayName ?: pluginId, style = MaterialTheme.typography.bodyMedium)
            if (info != null) {
                val threadSafeLabel = stringResource(R.string.developer_pipeline_stage_thread_safe)
                val streamingLabel = stringResource(R.string.developer_pipeline_stage_streaming)
                val traits = buildList {
                    if (info.threadSafe) add(threadSafeLabel)
                    if (info.streamingSupport) add(streamingLabel)
                }
                if (traits.isNotEmpty()) {
                    Text(traits.joinToString(" \u00b7 "), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

private fun formatCategoryName(rawEnumName: String): String =
    rawEnumName.split('_').joinToString(" ") { word -> word.lowercase().replaceFirstChar { it.uppercase() } }

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes / 1024.0
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.size - 1) {
        value /= 1024
        unitIndex++
    }
    return "%.1f %s".format(value, units[unitIndex])
}
