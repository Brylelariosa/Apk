package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.pipeline.CompressionPipeline
import com.novacompress.ai.core.plugins.PluginRegistry
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * A self-contained multi-file archive format, per the spec's Multi-File
 * Archives section: "Archive Table -> Folder Tree -> Metadata ->
 * Independent File Entries -> Independent Chunk Tables ... -> Footer."
 * Every file gets its own chunk table and its own whole-file SHA-256, so
 * one damaged file never prevents reading the others.
 *
 * A wholly separate format from the single-file [NovaArchiveFormat] (own
 * magic bytes, own writer/reader), for the same reason [NovaDictionaryArchiveWriter]
 * is separate: this project's length-prefixed sequential metadata has no
 * versioning story for safely extending an existing format's shape, so a
 * genuinely new shape gets a genuinely new, independently-versioned format
 * instead of risking the already-validated single-file one.
 *
 * All files in one archive currently share a single genome/pipeline
 * (the spec's per-file "each file may use a different optimized pipeline"
 * is a reasonable future enhancement, not implemented here - see
 * PROGRESS.md).
 */
object NovaMultiFileArchiveFormat {
    val MAGIC: ByteArray = byteArrayOf('N'.code.toByte(), 'V'.code.toByte(), 'A'.code.toByte(), 'M'.code.toByte())
    val FOOTER_MAGIC: ByteArray = byteArrayOf('E'.code.toByte(), 'N'.code.toByte(), 'D'.code.toByte(), 'M'.code.toByte())
    const val FORMAT_VERSION = 1
}

data class MultiFileEntry(
    val relativePath: String,
    val originalSize: Long,
    val chunkSize: Int,
    val chunkCount: Int
)

data class MultiFileArchiveMetadata(
    val entries: List<MultiFileEntry>,
    val genomeId: String,
    val pipelinePluginIds: List<String>,
    val createdAtEpochMillis: Long
)

/** One file to add to a multi-file archive: its archive-relative path, declared size, and a stream opener. */
data class MultiFileInput(
    val relativePath: String,
    val originalSize: Long,
    val openStream: () -> InputStream
)

object NovaMultiFileArchiveWriter {

    fun write(
        output: OutputStream,
        files: List<MultiFileInput>,
        genome: CompressionGenome,
        chunkSize: Int = Constants.DEFAULT_CHUNK_SIZE,
        onFileComplete: (fileIndex: Int, fileCount: Int, relativePath: String) -> Unit = { _, _, _ -> }
    ): MultiFileArchiveMetadata {
        require(files.map { it.relativePath }.toSet().size == files.size) {
            "duplicate relative path in multi-file archive input"
        }

        output.write(NovaMultiFileArchiveFormat.MAGIC)
        output.write(NovaMultiFileArchiveFormat.FORMAT_VERSION)

        val createdAt = System.currentTimeMillis()
        writeString(output, genome.genomeId)
        writeStringList(output, genome.pipeline.pluginIds)
        writeLong(output, createdAt)
        writeU32(output, files.size)

        val pipeline = CompressionPipeline(genome.pipeline)
        val entries = mutableListOf<MultiFileEntry>()
        val perFileHashes = mutableListOf<ByteArray>()

        for ((index, file) in files.withIndex()) {
            val chunkCount = if (file.originalSize == 0L) 0 else ((file.originalSize + chunkSize - 1) / chunkSize).toInt()

            writeString(output, file.relativePath)
            writeLong(output, file.originalSize)
            writeU32(output, chunkSize)
            writeU32(output, chunkCount)

            val fileDigest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(chunkSize)

            file.openStream().use { input ->
                var chunksWritten = 0
                while (chunksWritten < chunkCount) {
                    var readTotal = 0
                    while (readTotal < chunkSize) {
                        val r = input.read(buffer, readTotal, chunkSize - readTotal)
                        if (r == -1) break
                        readTotal += r
                    }
                    if (readTotal == 0) break

                    val chunk = if (readTotal == buffer.size) buffer else buffer.copyOf(readTotal)
                    fileDigest.update(chunk)

                    val compressed = pipeline.compress(chunk)
                    val roundTripOk = try {
                        pipeline.decompress(compressed).contentEquals(chunk)
                    } catch (e: Exception) {
                        throw PipelineVerificationException(
                            "File '${file.relativePath}' chunk $chunksWritten failed verification: decompression threw ${e.message}"
                        )
                    }
                    if (!roundTripOk) {
                        throw PipelineVerificationException(
                            "File '${file.relativePath}' chunk $chunksWritten failed verification: decompressed output did not match the original."
                        )
                    }

                    val chunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)
                    writeU32(output, compressed.size)
                    output.write(compressed)
                    output.write(chunkHash)

                    chunksWritten++
                }
            }

            val fileHash = fileDigest.digest()
            output.write(fileHash)
            perFileHashes.add(fileHash)
            entries.add(MultiFileEntry(file.relativePath, file.originalSize, chunkSize, chunkCount))
            onFileComplete(index + 1, files.size, file.relativePath)
        }

        val overallDigest = MessageDigest.getInstance("SHA-256")
        perFileHashes.forEach { overallDigest.update(it) }
        output.write(overallDigest.digest())
        output.write(NovaMultiFileArchiveFormat.FOOTER_MAGIC)
        output.flush()

        return MultiFileArchiveMetadata(entries, genome.genomeId, genome.pipeline.pluginIds, createdAt)
    }

    private fun writeString(output: OutputStream, value: String) {
        val buf = ByteArrayOutputStream()
        BinaryIO.writeString(buf, value)
        output.write(buf.toByteArray())
    }

    private fun writeStringList(output: OutputStream, values: List<String>) {
        val buf = ByteArrayOutputStream()
        BinaryIO.writeStringList(buf, values)
        output.write(buf.toByteArray())
    }

    private fun writeLong(output: OutputStream, value: Long) {
        val buf = ByteArrayOutputStream(8)
        BinaryIO.writeLong(buf, value)
        output.write(buf.toByteArray())
    }

    private fun writeU32(output: OutputStream, value: Int) {
        val buf = ByteArrayOutputStream(4)
        BinaryIO.writeU32(buf, value)
        output.write(buf.toByteArray())
    }
}

sealed class MultiFileArchiveReadResult {
    data class Success(val metadata: MultiFileArchiveMetadata) : MultiFileArchiveReadResult()
    data class Corrupted(val reason: String, val fileIndex: Int? = null) : MultiFileArchiveReadResult()
}

object NovaMultiFileArchiveReader {

    /** @param openOutputFor supplies the destination stream for a given relative path, e.g. writing under an extraction directory. */
    fun readAndVerify(
        input: InputStream,
        openOutputFor: (relativePath: String) -> OutputStream,
        onFileComplete: (fileIndex: Int, fileCount: Int, relativePath: String) -> Unit = { _, _, _ -> }
    ): MultiFileArchiveReadResult {
        try {
            val magic = readFully(input, 4)
            if (!magic.contentEquals(NovaMultiFileArchiveFormat.MAGIC)) {
                return MultiFileArchiveReadResult.Corrupted("Not a NovaCompress multi-file archive (bad magic header).")
            }
            val version = input.read()
            if (version != NovaMultiFileArchiveFormat.FORMAT_VERSION) {
                return MultiFileArchiveReadResult.Corrupted("Unsupported multi-file archive version: $version")
            }

            val genomeId = readString(input)
            val pipelinePluginIds = readStringList(input)
            val createdAt = readLong(input)
            val fileCount = readU32(input)

            for (pluginId in pipelinePluginIds) {
                if (!PluginRegistry.exists(pluginId)) {
                    return MultiFileArchiveReadResult.Corrupted("Archive references unknown plugin: $pluginId")
                }
            }
            val pipeline = CompressionPipeline.from(pipelinePluginIds)

            val entries = mutableListOf<MultiFileEntry>()
            val perFileHashes = mutableListOf<ByteArray>()

            for (fileIndex in 0 until fileCount) {
                val relativePath = readString(input)
                val originalSize = readLong(input)
                val chunkSize = readU32(input)
                val chunkCount = readU32(input)

                val fileDigest = MessageDigest.getInstance("SHA-256")
                var totalWritten = 0L

                openOutputFor(relativePath).use { fileOutput ->
                    repeat(chunkCount) {
                        val compSize = readU32(input)
                        if (compSize < 0 || compSize > Constants.MAX_PLAUSIBLE_CHUNK_BYTES) {
                            throw ChunkVerificationFailure("Implausible chunk length in file '$relativePath': $compSize", fileIndex)
                        }
                        val compressed = readFully(input, compSize)
                        val storedChunkHash = readFully(input, NovaArchiveFormat.SHA256_LENGTH)
                        val actualChunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)
                        if (!actualChunkHash.contentEquals(storedChunkHash)) {
                            throw ChunkVerificationFailure("Chunk hash mismatch in file '$relativePath' (chunk $it).", fileIndex)
                        }
                        val decompressed = pipeline.decompress(compressed)
                        fileOutput.write(decompressed)
                        fileDigest.update(decompressed)
                        totalWritten += decompressed.size
                    }
                }

                val storedFileHash = readFully(input, NovaArchiveFormat.SHA256_LENGTH)
                val actualFileHash = fileDigest.digest()
                if (!actualFileHash.contentEquals(storedFileHash)) {
                    return MultiFileArchiveReadResult.Corrupted("Whole-file SHA-256 mismatch for '$relativePath'.", fileIndex)
                }
                if (totalWritten != originalSize) {
                    return MultiFileArchiveReadResult.Corrupted(
                        "Size mismatch for '$relativePath': expected $originalSize, produced $totalWritten.",
                        fileIndex
                    )
                }

                perFileHashes.add(actualFileHash)
                entries.add(MultiFileEntry(relativePath, originalSize, chunkSize, chunkCount))
                onFileComplete(fileIndex + 1, fileCount, relativePath)
            }

            val storedOverallHash = readFully(input, NovaArchiveFormat.SHA256_LENGTH)
            val footer = readFully(input, 4)
            if (!footer.contentEquals(NovaMultiFileArchiveFormat.FOOTER_MAGIC)) {
                return MultiFileArchiveReadResult.Corrupted("Bad footer marker - archive is incomplete or corrupted.")
            }
            val overallDigest = MessageDigest.getInstance("SHA-256")
            perFileHashes.forEach { overallDigest.update(it) }
            if (!overallDigest.digest().contentEquals(storedOverallHash)) {
                return MultiFileArchiveReadResult.Corrupted("Overall archive hash mismatch.")
            }

            return MultiFileArchiveReadResult.Success(
                MultiFileArchiveMetadata(entries, genomeId, pipelinePluginIds, createdAt)
            )
        } catch (e: ChunkVerificationFailure) {
            return MultiFileArchiveReadResult.Corrupted(e.message ?: "chunk verification failed", e.fileIndex)
        } catch (e: EOFException) {
            return MultiFileArchiveReadResult.Corrupted("Archive is truncated: ${e.message}")
        } catch (e: Exception) {
            return MultiFileArchiveReadResult.Corrupted("Unexpected error while reading archive: ${e.message}")
        }
    }

    private class ChunkVerificationFailure(message: String, val fileIndex: Int) : Exception(message)

    private fun readString(input: InputStream): String {
        val len = readU32(input)
        if (len < 0 || len > Constants.MAX_PLAUSIBLE_METADATA_BYTES) {
            throw java.io.IOException("Corrupted archive: implausible string length ($len)")
        }
        return String(readFully(input, len), Charsets.UTF_8)
    }

    private fun readStringList(input: InputStream): List<String> {
        val count = readU32(input)
        if (count < 0 || count > Constants.MAX_PLAUSIBLE_LIST_COUNT) {
            throw java.io.IOException("Corrupted archive: implausible string-list count ($count)")
        }
        return List(count) { readString(input) }
    }

    private fun readLong(input: InputStream): Long = BinaryIO.readLong(readFully(input, 8), 0)

    private fun readU32(input: InputStream): Int = BinaryIO.readU32(readFully(input, 4), 0)

    private fun readFully(input: InputStream, length: Int): ByteArray {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val r = input.read(buffer, offset, length - offset)
            if (r == -1) throw EOFException("expected $length bytes, got $offset")
            offset += r
        }
        return buffer
    }
}
