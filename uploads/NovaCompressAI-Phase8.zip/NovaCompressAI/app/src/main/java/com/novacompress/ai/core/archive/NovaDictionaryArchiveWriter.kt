package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.ByteCursor
import com.novacompress.ai.core.dictionary.DictionaryLz77
import com.novacompress.ai.core.plugins.HuffmanCodingPlugin
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * A self-contained archive variant demonstrating the spec's Dictionary
 * Section end-to-end: a shared dictionary (derived from an early sample of
 * the file) is stored once and applied to every chunk's LZ77 pass, so
 * later chunks can reference patterns established early in the file -
 * something the standard chunk-independent format can never do across a
 * chunk boundary.
 *
 * Deliberately a wholly separate format (own magic bytes, own writer/
 * reader) rather than an extension of [NovaArchiveFormat]/[NovaArchiveWriter]:
 * extending the existing length-prefixed-sequential metadata format with a
 * new optional field would make old archives (missing that field) unsafe
 * to decode with a newer reader without careful versioning this project
 * doesn't have infrastructure for yet. This also deliberately uses a fixed
 * pipeline (dictionary-aware LZ77, then Huffman) rather than the general
 * [com.novacompress.ai.core.pipeline.PipelineDescriptor] system, since a
 * dictionary is a third parameter that doesn't fit the plain
 * `CompressionPlugin.compress(ByteArray)` contract every other plugin
 * uses - full genome/Evolution-Engine integration is intentionally out of
 * scope here; see PROGRESS.md.
 */
object NovaDictionaryArchiveFormat {
    val MAGIC: ByteArray = byteArrayOf('N'.code.toByte(), 'V'.code.toByte(), 'A'.code.toByte(), 'D'.code.toByte())
    val FOOTER_MAGIC: ByteArray = byteArrayOf('E'.code.toByte(), 'N'.code.toByte(), 'D'.code.toByte(), 'D'.code.toByte())
    const val FORMAT_VERSION = 1
    const val DEFAULT_DICTIONARY_SIZE = 8 * 1024
    const val DEFAULT_CHUNK_SIZE = 256 * 1024
}

data class DictionaryArchiveMetadata(
    val originalFileName: String,
    val originalSize: Long,
    val dictionarySize: Int,
    val chunkSize: Int,
    val chunkCount: Int,
    val createdAtEpochMillis: Long
)

object NovaDictionaryArchiveWriter {

    /**
     * @param openInput must support being invoked twice: once (internally)
     *   to derive the dictionary from the first [dictionarySize] bytes,
     *   once more for the full chunked compression pass.
     */
    fun write(
        output: OutputStream,
        openInput: () -> InputStream,
        originalFileName: String,
        originalSize: Long,
        dictionarySize: Int = NovaDictionaryArchiveFormat.DEFAULT_DICTIONARY_SIZE,
        chunkSize: Int = NovaDictionaryArchiveFormat.DEFAULT_CHUNK_SIZE,
        onChunkComplete: (chunksDone: Int, chunksTotal: Int) -> Unit = { _, _ -> }
    ): DictionaryArchiveMetadata {
        val effectiveDictSize = if (originalSize < dictionarySize) originalSize.toInt() else dictionarySize
        val dictionary = if (effectiveDictSize > 0) {
            openInput().use { readFullyUpTo(it, effectiveDictSize) }
        } else {
            ByteArray(0)
        }

        val chunkCount = if (originalSize == 0L) 0 else ((originalSize + chunkSize - 1) / chunkSize).toInt()
        val metadata = DictionaryArchiveMetadata(
            originalFileName = originalFileName,
            originalSize = originalSize,
            dictionarySize = dictionary.size,
            chunkSize = chunkSize,
            chunkCount = chunkCount,
            createdAtEpochMillis = System.currentTimeMillis()
        )

        output.write(NovaDictionaryArchiveFormat.MAGIC)
        output.write(NovaDictionaryArchiveFormat.FORMAT_VERSION)
        writeMetadata(output, metadata)
        writeU32Direct(output, dictionary.size)
        output.write(dictionary)
        writeU32Direct(output, chunkCount)

        val huffman = HuffmanCodingPlugin()
        val wholeDigest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(chunkSize)

        openInput().use { input ->
            var chunksWritten = 0
            while (chunksWritten < chunkCount) {
                var readTotal = 0
                while (readTotal < chunkSize) {
                    val r = input.read(buffer, readTotal, chunkSize - readTotal)
                    if (r == -1) break
                    readTotal += r
                }
                if (readTotal == 0) break

                val chunk = if (readTotal == buffer.size) buffer else buffer.copyOf(readTotal)
                wholeDigest.update(chunk)

                val lz77Stage = DictionaryLz77.compress(dictionary, chunk)
                val compressed = huffman.compress(lz77Stage)

                val roundTripOk = try {
                    val decompressedLz77Stage = huffman.decompress(compressed)
                    val decompressed = DictionaryLz77.decompress(dictionary, decompressedLz77Stage)
                    decompressed.contentEquals(chunk)
                } catch (e: Exception) {
                    throw PipelineVerificationException("Dictionary chunk $chunksWritten failed verification: ${e.message}")
                }
                if (!roundTripOk) {
                    throw PipelineVerificationException("Dictionary chunk $chunksWritten failed verification: decompressed output did not match the original.")
                }

                val chunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)
                writeU32Direct(output, compressed.size)
                output.write(compressed)
                output.write(chunkHash)

                chunksWritten++
                onChunkComplete(chunksWritten, chunkCount)
            }
        }

        output.write(wholeDigest.digest())
        output.write(NovaDictionaryArchiveFormat.FOOTER_MAGIC)
        output.flush()

        return metadata
    }

    private fun writeMetadata(output: OutputStream, metadata: DictionaryArchiveMetadata) {
        val buf = ByteArrayOutputStream()
        BinaryIO.writeString(buf, metadata.originalFileName)
        BinaryIO.writeLong(buf, metadata.originalSize)
        BinaryIO.writeU32(buf, metadata.dictionarySize)
        BinaryIO.writeU32(buf, metadata.chunkSize)
        BinaryIO.writeU32(buf, metadata.chunkCount)
        BinaryIO.writeLong(buf, metadata.createdAtEpochMillis)
        val bytes = buf.toByteArray()
        writeU32Direct(output, bytes.size)
        output.write(bytes)
    }

    private fun writeU32Direct(output: OutputStream, value: Int) {
        val buf = ByteArrayOutputStream(4)
        BinaryIO.writeU32(buf, value)
        output.write(buf.toByteArray())
    }

    private fun readFullyUpTo(input: InputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArray(maxBytes)
        var total = 0
        while (total < maxBytes) {
            val r = input.read(buffer, total, maxBytes - total)
            if (r == -1) break
            total += r
        }
        return if (total == buffer.size) buffer else buffer.copyOf(total)
    }
}

sealed class DictionaryArchiveReadResult {
    data class Success(val metadata: DictionaryArchiveMetadata) : DictionaryArchiveReadResult()
    data class Corrupted(val reason: String) : DictionaryArchiveReadResult()
}

object NovaDictionaryArchiveReader {

    fun readAndVerify(
        input: InputStream,
        output: OutputStream,
        onChunkComplete: (chunksDone: Int, chunksTotal: Int) -> Unit = { _, _ -> }
    ): DictionaryArchiveReadResult {
        try {
            val magic = readFully(input, 4)
            if (!magic.contentEquals(NovaDictionaryArchiveFormat.MAGIC)) {
                return DictionaryArchiveReadResult.Corrupted("Not a NovaCompress dictionary archive (bad magic header).")
            }
            val version = input.read()
            if (version != NovaDictionaryArchiveFormat.FORMAT_VERSION) {
                return DictionaryArchiveReadResult.Corrupted("Unsupported dictionary archive version: $version")
            }

            val metaLen = BinaryIO.readU32(readFully(input, 4), 0)
            val metaBytes = readFully(input, metaLen)
            val metadata = decodeMetadata(metaBytes)

            val dictLen = BinaryIO.readU32(readFully(input, 4), 0)
            if (dictLen != metadata.dictionarySize) {
                return DictionaryArchiveReadResult.Corrupted("Dictionary size mismatch between header and metadata.")
            }
            val dictionary = readFully(input, dictLen)

            val chunkCountFromHeader = BinaryIO.readU32(readFully(input, 4), 0)
            if (chunkCountFromHeader != metadata.chunkCount) {
                return DictionaryArchiveReadResult.Corrupted("Chunk count mismatch between header and metadata.")
            }

            val huffman = HuffmanCodingPlugin()
            val runningDigest = MessageDigest.getInstance("SHA-256")
            var totalWritten = 0L

            repeat(metadata.chunkCount) {
                val compSize = BinaryIO.readU32(readFully(input, 4), 0)
                val compressed = readFully(input, compSize)
                val storedChunkHash = readFully(input, 32)

                val actualChunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)
                if (!actualChunkHash.contentEquals(storedChunkHash)) {
                    return DictionaryArchiveReadResult.Corrupted("Chunk hash mismatch - archive is corrupted or was tampered with.")
                }

                val lz77Stage = huffman.decompress(compressed)
                val decompressed = DictionaryLz77.decompress(dictionary, lz77Stage)
                output.write(decompressed)
                runningDigest.update(decompressed)
                totalWritten += decompressed.size
                onChunkComplete(it + 1, metadata.chunkCount)
            }

            val storedWholeHash = readFully(input, 32)
            val footer = readFully(input, 4)
            if (!footer.contentEquals(NovaDictionaryArchiveFormat.FOOTER_MAGIC)) {
                return DictionaryArchiveReadResult.Corrupted("Bad footer marker - archive is incomplete or corrupted.")
            }
            if (!runningDigest.digest().contentEquals(storedWholeHash)) {
                return DictionaryArchiveReadResult.Corrupted("Whole-file SHA-256 mismatch - lossless guarantee was violated, output discarded.")
            }
            if (totalWritten != metadata.originalSize) {
                return DictionaryArchiveReadResult.Corrupted("Size mismatch: expected ${metadata.originalSize} bytes, produced $totalWritten.")
            }

            output.flush()
            return DictionaryArchiveReadResult.Success(metadata)
        } catch (e: EOFException) {
            return DictionaryArchiveReadResult.Corrupted("Archive is truncated: ${e.message}")
        } catch (e: Exception) {
            return DictionaryArchiveReadResult.Corrupted("Unexpected error while reading archive: ${e.message}")
        }
    }

    private fun decodeMetadata(bytes: ByteArray): DictionaryArchiveMetadata {
        val cursor = ByteCursor(bytes)
        return DictionaryArchiveMetadata(
            originalFileName = cursor.readString(),
            originalSize = cursor.readLong(),
            dictionarySize = cursor.readU32(),
            chunkSize = cursor.readU32(),
            chunkCount = cursor.readU32(),
            createdAtEpochMillis = cursor.readLong()
        )
    }

    private fun readFully(input: InputStream, length: Int): ByteArray {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val r = input.read(buffer, offset, length - offset)
            if (r == -1) throw EOFException("expected $length bytes, got $offset")
            offset += r
        }
        return buffer
    }
}
