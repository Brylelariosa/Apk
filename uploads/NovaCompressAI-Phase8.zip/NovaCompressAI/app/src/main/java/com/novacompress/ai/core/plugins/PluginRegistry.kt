package com.novacompress.ai.core.plugins

import com.novacompress.ai.core.plugins.sdk.CertificationResult
import com.novacompress.ai.core.plugins.sdk.PluginCertifier

/**
 * Central lookup from stable plugin ID (as stored in archives and genomes)
 * to the plugin instance. The core engine never needs to change when new
 * plugins are added here.
 *
 * Every registered plugin is automatically certified against
 * [PluginCertifier]'s standard corpus at startup, per the spec: "If any
 * test fails, Plugin becomes disabled." In practice this is a no-op today
 * (all 8 shipped plugins are already thoroughly tested and pass), but it's
 * a real, automatic safety net against a future regression silently
 * producing corrupted archives, rather than relying solely on remembering
 * to run the test suite.
 *
 * If the certification bookkeeping itself is ever missing a result for a
 * plugin (a bug in this safety-net code, not in the plugin), that plugin
 * defaults to *trusted* rather than silently disappearing - a bug in new
 * safety-net code should never be able to break the existing, working
 * plugin set.
 */
object PluginRegistry {

    private val allRegisteredPlugins: List<CompressionPlugin> = listOf(
        DeltaEncodingPlugin(),
        RunLengthEncodingPlugin(),
        HuffmanCodingPlugin(),
        Lz77Plugin(),
        MoveToFrontPlugin(),
        BurrowsWheelerTransformPlugin(),
        ArithmeticCodingPlugin(),
        PredictiveCodingPlugin()
    )

    private val certificationResults: List<CertificationResult> =
        PluginCertifier.certifyAll(allRegisteredPlugins)

    private val plugins: Map<String, CompressionPlugin> = allRegisteredPlugins
        .filter { plugin ->
            certificationResults.firstOrNull { it.pluginId == plugin.id }?.passed ?: true
        }
        .associateBy { it.id }

    fun get(id: String): CompressionPlugin =
        plugins[id] ?: throw IllegalArgumentException("Unknown plugin id: $id")

    fun all(): List<CompressionPlugin> = plugins.values.toList()

    fun exists(id: String): Boolean = plugins.containsKey(id)

    /** The full certification report for every registered plugin, including any that failed and were excluded. */
    fun certificationReport(): List<CertificationResult> = certificationResults
}
