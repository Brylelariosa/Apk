package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.pipeline.CompressionPipeline
import com.novacompress.ai.core.plugins.PluginRegistry
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

sealed class ArchiveReadResult {
    data class Success(val metadata: ArchiveMetadata) : ArchiveReadResult()
    data class Corrupted(val reason: String) : ArchiveReadResult()
}

/**
 * Reads and fully verifies a .nova archive.
 *
 * Per the project's Fundamental Rule, this never emits output it has not
 * verified: any hash mismatch, unknown plugin, or structural inconsistency
 * aborts immediately with [ArchiveReadResult.Corrupted] rather than
 * returning partially-trusted bytes.
 */
object NovaArchiveReader {

    fun readAndVerify(
        input: InputStream,
        output: OutputStream,
        onChunkComplete: (chunksDone: Int, chunksTotal: Int) -> Unit = { _, _ -> }
    ): ArchiveReadResult {
        try {
            val magic = readFully(input, 4)
            if (!magic.contentEquals(NovaArchiveFormat.MAGIC)) {
                return ArchiveReadResult.Corrupted("Not a NovaCompress archive (bad magic header).")
            }

            val version = input.read()
            if (version != com.novacompress.ai.core.common.Constants.ARCHIVE_FORMAT_VERSION) {
                return ArchiveReadResult.Corrupted("Unsupported archive format version: $version")
            }

            val metaLen = BinaryIO.readU32(readFully(input, 4), 0)
            if (metaLen < 0 || metaLen > com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_METADATA_BYTES) {
                return ArchiveReadResult.Corrupted("Implausible metadata length: $metaLen")
            }
            val metaBytes = readFully(input, metaLen)
            val metadata = ArchiveMetadataCodec.decode(metaBytes)

            val chunkCountFromHeader = BinaryIO.readU32(readFully(input, 4), 0)
            if (chunkCountFromHeader != metadata.chunkCount) {
                return ArchiveReadResult.Corrupted("Chunk count mismatch between header and metadata.")
            }

            for (pluginId in metadata.pipelinePluginIds) {
                if (!PluginRegistry.exists(pluginId)) {
                    return ArchiveReadResult.Corrupted("Archive references unknown plugin: $pluginId")
                }
            }
            val pipeline = CompressionPipeline.from(metadata.pipelinePluginIds)

            val runningDigest = MessageDigest.getInstance("SHA-256")
            var totalWritten = 0L

            repeat(metadata.chunkCount) {
                val compSize = BinaryIO.readU32(readFully(input, 4), 0)
                if (compSize < 0 || compSize > com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_CHUNK_BYTES) {
                    return ArchiveReadResult.Corrupted("Implausible chunk length: $compSize")
                }
                val compressed = readFully(input, compSize)
                val storedChunkHash = readFully(input, NovaArchiveFormat.SHA256_LENGTH)

                val actualChunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)
                if (!actualChunkHash.contentEquals(storedChunkHash)) {
                    return ArchiveReadResult.Corrupted("Chunk hash mismatch - archive is corrupted or was tampered with.")
                }

                val decompressed = pipeline.decompress(compressed)
                output.write(decompressed)
                runningDigest.update(decompressed)
                totalWritten += decompressed.size
                onChunkComplete(it + 1, metadata.chunkCount)
            }

            val storedWholeHash = readFully(input, NovaArchiveFormat.SHA256_LENGTH)
            val footer = readFully(input, 4)
            if (!footer.contentEquals(NovaArchiveFormat.FOOTER_MAGIC)) {
                return ArchiveReadResult.Corrupted("Bad footer marker - archive is incomplete or corrupted.")
            }
            if (!runningDigest.digest().contentEquals(storedWholeHash)) {
                return ArchiveReadResult.Corrupted("Whole-file SHA-256 mismatch - lossless guarantee was violated, output discarded.")
            }
            if (totalWritten != metadata.originalSize) {
                return ArchiveReadResult.Corrupted("Size mismatch: expected ${metadata.originalSize} bytes, produced $totalWritten.")
            }

            output.flush()
            return ArchiveReadResult.Success(metadata)
        } catch (e: EOFException) {
            return ArchiveReadResult.Corrupted("Archive is truncated: ${e.message}")
        } catch (e: Exception) {
            return ArchiveReadResult.Corrupted("Unexpected error while reading archive: ${e.message}")
        }
    }

    private fun readFully(input: InputStream, length: Int): ByteArray {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val r = input.read(buffer, offset, length - offset)
            if (r == -1) throw EOFException("expected $length bytes, got $offset")
            offset += r
        }
        return buffer
    }
}
