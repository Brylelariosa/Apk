package com.novacompress.ai.core.common

import java.io.ByteArrayOutputStream

/** Small big-endian integer read/write helpers shared across the archive and plugin code. */
object BinaryIO {

    fun writeU16(out: ByteArrayOutputStream, value: Int) {
        out.write((value shr 8) and 0xFF)
        out.write(value and 0xFF)
    }

    fun writeU32(out: ByteArrayOutputStream, value: Int) {
        out.write((value shr 24) and 0xFF)
        out.write((value shr 16) and 0xFF)
        out.write((value shr 8) and 0xFF)
        out.write(value and 0xFF)
    }

    fun readU16(data: ByteArray, offset: Int): Int {
        return ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
    }

    fun readU32(data: ByteArray, offset: Int): Int {
        return ((data[offset].toInt() and 0xFF) shl 24) or
            ((data[offset + 1].toInt() and 0xFF) shl 16) or
            ((data[offset + 2].toInt() and 0xFF) shl 8) or
            (data[offset + 3].toInt() and 0xFF)
    }

    fun writeLong(out: ByteArrayOutputStream, value: Long) {
        for (shift in 56 downTo 0 step 8) {
            out.write(((value shr shift) and 0xFF).toInt())
        }
    }

    fun readLong(data: ByteArray, offset: Int): Long {
        var result = 0L
        for (i in 0 until 8) {
            result = (result shl 8) or (data[offset + i].toLong() and 0xFF)
        }
        return result
    }

    /** Length-prefixed UTF-8 string: [length: 4 bytes BE][utf-8 bytes]. */
    fun writeString(out: ByteArrayOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        writeU32(out, bytes.size)
        out.write(bytes)
    }

    fun writeStringList(out: ByteArrayOutputStream, values: List<String>) {
        writeU32(out, values.size)
        values.forEach { writeString(out, it) }
    }

    fun writeDouble(out: ByteArrayOutputStream, value: Double) {
        writeLong(out, value.toRawBits())
    }

    fun readDouble(data: ByteArray, offset: Int): Double = Double.fromBits(readLong(data, offset))

    /**
     * Throws [java.io.IOException] if [length] is negative or exceeds
     * [max]. Every archive/backup parser calls this before allocating a
     * buffer sized from a length field read out of untrusted file data, so
     * a corrupted or adversarial length is reported as an ordinary parse
     * failure - caught by the caller's existing `catch (Exception)`
     * handling and turned into a "Corrupted"/"Import failed" result -
     * instead of crashing the process with an uncatchable
     * [OutOfMemoryError] from an unbounded allocation. See
     * [com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_METADATA_BYTES]
     * and [com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_CHUNK_BYTES]
     * for the two bounds callers use here.
     */
    fun requireSaneLength(length: Int, max: Int, fieldDescription: String) {
        if (length < 0 || length > max) {
            throw java.io.IOException("Corrupted data: implausible $fieldDescription ($length bytes)")
        }
    }

    /** Same idea as [requireSaneLength] but for an element *count* (see [com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_LIST_COUNT]) rather than a byte length. */
    fun requireSaneCount(count: Int, max: Int, fieldDescription: String) {
        if (count < 0 || count > max) {
            throw java.io.IOException("Corrupted data: implausible $fieldDescription ($count)")
        }
    }
}
