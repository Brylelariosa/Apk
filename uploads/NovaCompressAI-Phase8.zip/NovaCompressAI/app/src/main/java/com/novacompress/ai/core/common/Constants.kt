package com.novacompress.ai.core.common

/**
 * Engine-wide constants. Centralized here so the Archive, Pipeline, and
 * Analyzer subsystems never hardcode magic numbers independently.
 */
object Constants {

    /** Default chunk size used when streaming a file through the compression pipeline. */
    const val DEFAULT_CHUNK_SIZE: Int = 256 * 1024 // 256 KB, per the Nova spec's chunk size options

    /** Nova archive file extension, without the leading dot. */
    const val ARCHIVE_EXTENSION: String = "nova"

    /** Current Nova archive format version. Future versions must remain able to read this. */
    const val ARCHIVE_FORMAT_VERSION: Int = 1

    /** Maximum number of plugin stages allowed in a single compression pipeline. */
    const val MAX_PIPELINE_STAGES: Int = 16

    /** Default maximum number of pipeline stages the Phase 1 genome presets use. */
    const val DEFAULT_PIPELINE_STAGES: Int = 6

    /**
     * Sanity ceiling for a single self-describing metadata block read from
     * an untrusted archive/backup file, before allocating a buffer sized
     * from its length field. Real metadata is a handful of short strings
     * and ints - this is many times larger than any legitimate value,
     * chosen to reject a corrupted or adversarial length field without
     * ever rejecting a genuine one. Originally introduced in
     * [com.novacompress.ai.core.archive.NovaArchiveInspector]; centralized
     * here so every archive/backup parser applies the same bound.
     */
    const val MAX_PLAUSIBLE_METADATA_BYTES: Int = 10 * 1024 * 1024 // 10 MB

    /**
     * Sanity ceiling for a single compressed chunk or dictionary read from
     * an untrusted archive file. Originally introduced in
     * [com.novacompress.ai.core.archive.NovaArchiveRepairer] as a local
     * constant; centralized here for the same reason as
     * [MAX_PLAUSIBLE_METADATA_BYTES] above.
     */
    const val MAX_PLAUSIBLE_CHUNK_BYTES: Int = 64 * 1024 * 1024 // 64 MB

    /**
     * Sanity ceiling for the *element count* of a length-prefixed list
     * (e.g. a string list or record list) read from untrusted data, before
     * allocating a collection sized from that count. `List(count) { ... }`
     * and similar constructors allocate their backing storage for the full
     * count immediately, before the lambda ever runs - so an unbounded
     * count is a memory-exhaustion vector independent of, and in addition
     * to, the byte-length bounds above.
     */
    const val MAX_PLAUSIBLE_LIST_COUNT: Int = 1_000_000
}
