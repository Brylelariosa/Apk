package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.pipeline.CompressionPipeline
import com.novacompress.ai.core.plugins.PluginRegistry
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

data class ChunkRepairStatus(
    val chunkIndex: Int,
    val recovered: Boolean,
    val reason: String? = null
)

data class ArchiveRepairReport(
    val metadata: ArchiveMetadata?,
    val chunkStatuses: List<ChunkRepairStatus>,
    val recoveredByteCount: Long,
    /**
     * If the archive's structure (a chunk's declared size field, not just
     * its content) became unreadable partway through, this is the index
     * where that happened - nothing from this point on could even be
     * located, let alone recovered. Null if every expected chunk's
     * position could be determined (even if some chunks' content
     * themselves failed their hash check).
     */
    val structurallyTruncatedAtChunk: Int?
) {
    val fullyRecovered: Boolean
        get() = metadata != null && structurallyTruncatedAtChunk == null && chunkStatuses.all { it.recovered }
}

/**
 * Best-effort recovery of a corrupted or truncated `.nova` archive, per
 * the spec's Archive Repair Mode: attempts to salvage whatever chunks
 * still pass their own hash check, and produces a detailed report of what
 * could and couldn't be recovered rather than silently returning partial
 * or wrong data.
 *
 * This has a real, honest limit: chunks are stored inline (each preceded
 * by its own size field), not behind an independent upfront chunk
 * directory, so recovery can only continue past a damaged chunk if that
 * chunk's *size field* is still intact (letting the reader locate where
 * the next chunk begins). If a size field itself is corrupted, nothing
 * after it can be located - [ArchiveRepairReport.structurallyTruncatedAtChunk]
 * reports exactly where that happened rather than guessing. The spec's own
 * "Optional Reed-Solomon Parity (future)" note acknowledges this class of
 * archive format doesn't fully solve arbitrary corruption recovery without
 * redundant structural data, which is out of scope here.
 */
object NovaArchiveRepairer {

    private const val MAX_PLAUSIBLE_CHUNK_BYTES = Constants.MAX_PLAUSIBLE_CHUNK_BYTES

    fun repair(input: InputStream, output: OutputStream): ArchiveRepairReport {
        val metadata = try {
            readHeader(input)
        } catch (e: Exception) {
            return ArchiveRepairReport(null, emptyList(), 0, structurallyTruncatedAtChunk = 0)
        }

        val pipelineKnown = metadata.pipelinePluginIds.all { PluginRegistry.exists(it) }
        val pipeline = if (pipelineKnown) CompressionPipeline.from(metadata.pipelinePluginIds) else null

        val statuses = mutableListOf<ChunkRepairStatus>()
        var recoveredBytes = 0L
        var truncatedAt: Int? = null

        for (chunkIndex in 0 until metadata.chunkCount) {
            val expectedOriginalSize = expectedOriginalChunkSize(metadata, chunkIndex)

            val sizeBytes = tryReadFully(input, 4)
            if (sizeBytes == null) {
                truncatedAt = chunkIndex
                break
            }
            val compSize = BinaryIO.readU32(sizeBytes, 0)
            if (compSize < 0 || compSize > MAX_PLAUSIBLE_CHUNK_BYTES) {
                // The size field itself is unreadable/implausible - we can no
                // longer trust where this chunk ends, so nothing after it is
                // locatable either.
                truncatedAt = chunkIndex
                break
            }

            val compressedAndHash = tryReadFully(input, compSize + NovaArchiveFormat.SHA256_LENGTH)
            if (compressedAndHash == null) {
                truncatedAt = chunkIndex
                break
            }
            val compressed = compressedAndHash.copyOfRange(0, compSize)
            val storedHash = compressedAndHash.copyOfRange(compSize, compressedAndHash.size)
            val actualHash = MessageDigest.getInstance("SHA-256").digest(compressed)

            val status: ChunkRepairStatus = if (!actualHash.contentEquals(storedHash)) {
                output.write(ByteArray(expectedOriginalSize)) // zero-fill to preserve overall layout
                ChunkRepairStatus(chunkIndex, recovered = false, reason = "Chunk hash mismatch (content corrupted)")
            } else if (pipeline == null) {
                output.write(ByteArray(expectedOriginalSize))
                ChunkRepairStatus(chunkIndex, recovered = false, reason = "Archive references an unknown plugin")
            } else {
                try {
                    val decompressed = pipeline.decompress(compressed)
                    output.write(decompressed)
                    recoveredBytes += decompressed.size
                    ChunkRepairStatus(chunkIndex, recovered = true)
                } catch (e: Exception) {
                    output.write(ByteArray(expectedOriginalSize))
                    ChunkRepairStatus(chunkIndex, recovered = false, reason = "Decompression failed: ${e.message}")
                }
            }
            statuses.add(status)
        }

        output.flush()
        return ArchiveRepairReport(metadata, statuses, recoveredBytes, truncatedAt)
    }

    private fun expectedOriginalChunkSize(metadata: ArchiveMetadata, chunkIndex: Int): Int {
        val isLastChunk = chunkIndex == metadata.chunkCount - 1
        return if (!isLastChunk) {
            metadata.chunkSize
        } else {
            val remainder = (metadata.originalSize % metadata.chunkSize).toInt()
            if (remainder == 0) metadata.chunkSize else remainder
        }
    }

    private fun readHeader(input: InputStream): ArchiveMetadata {
        val magic = readFully(input, 4)
        require(magic.contentEquals(NovaArchiveFormat.MAGIC)) { "bad magic header" }
        val version = input.read()
        require(version == Constants.ARCHIVE_FORMAT_VERSION) { "unsupported version $version" }
        val metaLen = BinaryIO.readU32(readFully(input, 4), 0)
        require(metaLen in 0..Constants.MAX_PLAUSIBLE_METADATA_BYTES) { "implausible metadata length: $metaLen" }
        val metaBytes = readFully(input, metaLen)
        val metadata = ArchiveMetadataCodec.decode(metaBytes)
        readFully(input, 4) // chunk count header field; metadata.chunkCount is authoritative for repair purposes
        return metadata
    }

    private fun readFully(input: InputStream, length: Int): ByteArray =
        tryReadFully(input, length) ?: throw java.io.EOFException("expected $length bytes")

    private fun tryReadFully(input: InputStream, length: Int): ByteArray? {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val r = input.read(buffer, offset, length - offset)
            if (r == -1) return null
            offset += r
        }
        return buffer
    }
}
