package com.novacompress.ai.ui.developer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.core.diagnostics.SystemResourceProvider
import com.novacompress.ai.core.diagnostics.SystemResourceSnapshot
import com.novacompress.ai.data.repository.DatabaseUsageSnapshot
import com.novacompress.ai.data.repository.DeveloperStatsRepository
import com.novacompress.ai.data.repository.EvolutionStatsRepository
import com.novacompress.ai.data.repository.GenomeSummary
import com.novacompress.ai.data.repository.PluginDiagnostic
import com.novacompress.ai.data.repository.SettingsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn

data class DeveloperUiState(
    val systemResource: SystemResourceSnapshot? = null,
    val databaseUsage: DatabaseUsageSnapshot? = null,
    val genomes: List<GenomeSummary> = emptyList(),
    val plugins: List<PluginDiagnostic> = emptyList()
)

/**
 * Backs Developer Mode's Genome/Pipeline/Plugin/Database inspectors and
 * live thread/memory monitor - all read-only diagnostics for advanced
 * users, per the spec's "Advanced users should be able to inspect AI
 * decisions, benchmark history, genome evolution, and performance
 * statistics." Plugin *enable/disable* is deliberately not exposed from
 * here - that mutation lives in [com.novacompress.ai.ui.settings.SettingsViewModel]
 * under the Plugin Permissions section, so there's exactly one place that
 * owns writing [SettingsRepository.disabledPluginIds].
 */
class DeveloperViewModel(
    private val developerStatsRepository: DeveloperStatsRepository,
    evolutionStatsRepository: EvolutionStatsRepository,
    settingsRepository: SettingsRepository,
    systemResourceProvider: SystemResourceProvider
) : ViewModel() {

    companion object {
        private const val MONITOR_POLL_INTERVAL_MILLIS = 1_000L
    }

    /** Ticks once immediately, then every [MONITOR_POLL_INTERVAL_MILLIS] - only while something is actually collecting it (see [uiState]'s `WhileSubscribed`), so this never polls in the background after the user leaves the screen. */
    private val systemResourceFlow = flow {
        while (true) {
            emit(systemResourceProvider.snapshot())
            delay(MONITOR_POLL_INTERVAL_MILLIS)
        }
    }

    val uiState: StateFlow<DeveloperUiState> = combine(
        systemResourceFlow,
        developerStatsRepository.observeDatabaseUsage(),
        evolutionStatsRepository.observeGenomeSummaries(),
        settingsRepository.disabledPluginIds
    ) { resource, dbUsage, genomes, disabledPluginIds ->
        DeveloperUiState(
            systemResource = resource,
            databaseUsage = dbUsage,
            genomes = genomes,
            plugins = developerStatsRepository.pluginDiagnostics(disabledPluginIds)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DeveloperUiState())
}
