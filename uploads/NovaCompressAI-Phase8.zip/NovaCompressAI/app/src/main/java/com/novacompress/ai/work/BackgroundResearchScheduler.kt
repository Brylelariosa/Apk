package com.novacompress.ai.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Enqueues or cancels [BackgroundResearchWorker] as a periodic job.
 * `setRequiresCharging`/`setRequiresBatteryNotLow` are WorkManager's own
 * constraints - the OS won't even start the worker unless they hold, which
 * is a stronger and more battery-friendly guarantee than checking from
 * inside `doWork()` alone. [com.novacompress.ai.core.scheduler.ResearchScheduler]
 * is still checked inside the worker for the signals WorkManager has no
 * built-in constraint for (thermal state, memory pressure).
 */
object BackgroundResearchScheduler {

    private const val UNIQUE_WORK_NAME = "nova_background_research"
    private const val DEFAULT_INTERVAL_HOURS = 6L

    /**
     * @param intervalHours How often the periodic job should attempt a
     *   research pass (subject to [com.novacompress.ai.core.scheduler.ResearchScheduler]'s
     *   own gating every time it fires) - Settings' "Research Budget"
     *   category, per the spec. [ExistingPeriodicWorkPolicy.UPDATE] means
     *   calling this again with a new interval (e.g. after the user changes
     *   the setting) correctly reschedules the existing job rather than
     *   creating a duplicate.
     */
    fun enable(context: Context, intervalHours: Long = DEFAULT_INTERVAL_HOURS) {
        val constraints = Constraints.Builder()
            .setRequiresCharging(true)
            .setRequiresBatteryNotLow(true)
            .build()

        val request = PeriodicWorkRequestBuilder<BackgroundResearchWorker>(intervalHours, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun disable(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
    }
}
