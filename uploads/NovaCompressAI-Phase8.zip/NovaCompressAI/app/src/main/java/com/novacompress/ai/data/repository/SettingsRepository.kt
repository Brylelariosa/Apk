package com.novacompress.ai.data.repository

import android.content.Context
import android.os.PowerManager
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_settings")

/**
 * App-wide settings backed by Jetpack DataStore. Phase 4 added the one
 * Background Learning toggle; Phase 8 fills out the rest of the spec's
 * Settings surface (research budget, thermal/battery limits, plugin
 * permissions) - each one wired to a real subsystem (see
 * [com.novacompress.ai.work.BackgroundResearchWorker],
 * [com.novacompress.ai.work.BackgroundResearchScheduler],
 * [com.novacompress.ai.ui.compress.CompressViewModel]), matching this
 * class's existing rule that no control here is ever a dead switch.
 */
class SettingsRepository(private val context: Context) {

    companion object {
        /** Options offered for [researchIntervalHours] - matches WorkManager's periodic-work granularity (hours), not minutes. */
        val RESEARCH_INTERVAL_OPTIONS_HOURS = listOf(3, 6, 12, 24)
        private const val DEFAULT_RESEARCH_INTERVAL_HOURS = 6

        val MIN_BATTERY_PERCENT_RANGE = 10..90
        private const val DEFAULT_MIN_BATTERY_PERCENT = 50

        /** Options offered for [thermalSensitivity], each a real [PowerManager] thermal status constant. */
        val THERMAL_SENSITIVITY_OPTIONS = listOf(
            PowerManager.THERMAL_STATUS_LIGHT,
            PowerManager.THERMAL_STATUS_MODERATE,
            PowerManager.THERMAL_STATUS_SEVERE
        )
        private const val DEFAULT_THERMAL_SENSITIVITY = PowerManager.THERMAL_STATUS_MODERATE
    }

    private object Keys {
        val BACKGROUND_LEARNING_ENABLED = booleanPreferencesKey("background_learning_enabled")
        val RESEARCH_INTERVAL_HOURS = intPreferencesKey("research_interval_hours")
        val MIN_BATTERY_PERCENT_FOR_RESEARCH = intPreferencesKey("min_battery_percent_for_research")
        val THERMAL_SENSITIVITY = intPreferencesKey("thermal_sensitivity")
        val DISABLED_PLUGIN_IDS = stringSetPreferencesKey("disabled_plugin_ids")
    }

    private val preferences: Flow<Preferences> = context.dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }

    /** Whether idle-time background research is allowed to run at all. Defaults to on, gated by [com.novacompress.ai.core.scheduler.ResearchScheduler] regardless. */
    val backgroundLearningEnabled: Flow<Boolean> = preferences
        .map { prefs -> prefs[Keys.BACKGROUND_LEARNING_ENABLED] ?: true }

    suspend fun setBackgroundLearningEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[Keys.BACKGROUND_LEARNING_ENABLED] = enabled }
    }

    /** "Research Budget": how often [com.novacompress.ai.work.BackgroundResearchWorker] is allowed to run, in hours. One of [RESEARCH_INTERVAL_OPTIONS_HOURS]. */
    val researchIntervalHours: Flow<Int> = preferences
        .map { prefs -> prefs[Keys.RESEARCH_INTERVAL_HOURS] ?: DEFAULT_RESEARCH_INTERVAL_HOURS }

    suspend fun setResearchIntervalHours(hours: Int) {
        val clamped = RESEARCH_INTERVAL_OPTIONS_HOURS.minByOrNull { kotlin.math.abs(it - hours) } ?: DEFAULT_RESEARCH_INTERVAL_HOURS
        context.dataStore.edit { prefs -> prefs[Keys.RESEARCH_INTERVAL_HOURS] = clamped }
    }

    /** "Battery Limit": the minimum charge level [com.novacompress.ai.core.scheduler.ResearchScheduler] requires before allowing background research. */
    val minBatteryPercentForResearch: Flow<Int> = preferences
        .map { prefs -> prefs[Keys.MIN_BATTERY_PERCENT_FOR_RESEARCH] ?: DEFAULT_MIN_BATTERY_PERCENT }

    suspend fun setMinBatteryPercentForResearch(percent: Int) {
        context.dataStore.edit { prefs -> prefs[Keys.MIN_BATTERY_PERCENT_FOR_RESEARCH] = percent.coerceIn(MIN_BATTERY_PERCENT_RANGE) }
    }

    /** "Thermal Limit": the [PowerManager] thermal status at which [com.novacompress.ai.core.scheduler.AndroidThermalStatusProvider] reports the device as throttled. Lower = more conservative (backs off sooner). */
    val thermalSensitivity: Flow<Int> = preferences
        .map { prefs -> prefs[Keys.THERMAL_SENSITIVITY] ?: DEFAULT_THERMAL_SENSITIVITY }

    suspend fun setThermalSensitivity(level: Int) {
        val clamped = if (level in THERMAL_SENSITIVITY_OPTIONS) level else DEFAULT_THERMAL_SENSITIVITY
        context.dataStore.edit { prefs -> prefs[Keys.THERMAL_SENSITIVITY] = clamped }
    }

    /**
     * "Plugin Permissions": plugin ids the user has administratively
     * disabled from being used in *newly discovered* genomes (see
     * [com.novacompress.ai.core.evolution.MutationEngine]'s doc comment on
     * `allowedPluginIds` for the important, deliberate limit on what this
     * does and doesn't affect). Defaults to empty - every plugin allowed,
     * identical to behavior before this setting existed.
     */
    val disabledPluginIds: Flow<Set<String>> = preferences
        .map { prefs -> prefs[Keys.DISABLED_PLUGIN_IDS] ?: emptySet() }

    suspend fun setPluginEnabled(pluginId: String, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.DISABLED_PLUGIN_IDS] ?: emptySet()
            prefs[Keys.DISABLED_PLUGIN_IDS] = if (enabled) current - pluginId else current + pluginId
        }
    }
}
