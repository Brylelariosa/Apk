package com.novacompress.ai.core.diagnostics

import android.os.Debug

/**
 * A single point-in-time reading of process-level resource usage, for
 * Developer Mode's live thread/memory monitor. Deliberately a plain data
 * class (not a Flow itself) - [DeveloperViewModel][com.novacompress.ai.ui.developer.DeveloperViewModel]
 * owns the polling interval and turns repeated snapshots into a StateFlow.
 */
data class SystemResourceSnapshot(
    /** JVM heap currently in use, per [Runtime.totalMemory] minus [Runtime.freeMemory]. */
    val usedHeapBytes: Long,
    /** The JVM heap's hard ceiling for this process, per [Runtime.maxMemory]. */
    val maxHeapBytes: Long,
    /** Native (non-JVM) heap allocated by the process - relevant since some plugin/archive code allocates large [ByteArray]s that briefly show up here before GC. */
    val nativeHeapAllocatedBytes: Long,
    /** Live JVM thread count, per [Thread.activeCount] - includes Compose/coroutine dispatcher threads, not just app-created ones. */
    val activeThreadCount: Int
) {
    val heapUsedFraction: Float
        get() = if (maxHeapBytes <= 0) 0f else (usedHeapBytes.toDouble() / maxHeapBytes.toDouble()).toFloat().coerceIn(0f, 1f)
}

/** Abstracted behind an interface, like the battery/thermal/memory status providers, so [DeveloperViewModel][com.novacompress.ai.ui.developer.DeveloperViewModel] doesn't need a real device to be exercised in tests. */
interface SystemResourceProvider {
    fun snapshot(): SystemResourceSnapshot
}

/**
 * Real Android/JVM-backed implementation. [Runtime]'s memory accessors are
 * plain JVM APIs (they work fine in a JVM unit test); only
 * [Debug.getNativeHeapAllocatedSize] is Android-specific and would hit the
 * "not mocked" wall outside a real device/Robolectric, which is why this
 * concrete class - like [com.novacompress.ai.core.scheduler.AndroidBatteryStatusProvider]
 * and its siblings - is exercised only through the interface in tests.
 */
class AndroidSystemResourceProvider : SystemResourceProvider {
    override fun snapshot(): SystemResourceSnapshot {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return SystemResourceSnapshot(
            usedHeapBytes = used,
            maxHeapBytes = runtime.maxMemory(),
            nativeHeapAllocatedBytes = Debug.getNativeHeapAllocatedSize(),
            activeThreadCount = Thread.activeCount()
        )
    }
}
