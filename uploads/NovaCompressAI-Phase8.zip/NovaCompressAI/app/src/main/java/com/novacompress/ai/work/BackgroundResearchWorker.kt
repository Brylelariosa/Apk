package com.novacompress.ai.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.novacompress.ai.NovaCompressApplication
import com.novacompress.ai.core.evolution.BackgroundResearchRunner
import com.novacompress.ai.core.plugins.PluginRegistry
import com.novacompress.ai.core.scheduler.AndroidBatteryStatusProvider
import com.novacompress.ai.core.scheduler.AndroidMemoryStatusProvider
import com.novacompress.ai.core.scheduler.AndroidThermalStatusProvider
import com.novacompress.ai.core.scheduler.ResearchGate
import com.novacompress.ai.core.scheduler.ResearchScheduler
import kotlinx.coroutines.flow.first

/**
 * Runs one idle-time research pass, if [ResearchScheduler] currently
 * allows it. All the actual logic (constraint gating, mutation/crossover,
 * benchmarking) lives in plain, unit-tested Kotlin classes
 * ([ResearchScheduler], [BackgroundResearchRunner]); this class exists
 * purely to bridge WorkManager's lifecycle to them.
 *
 * WorkManager's own [androidx.work.Constraints] (requires charging,
 * battery not low) already gate *whether this worker runs at all* -
 * [ResearchScheduler] is checked again inside [doWork] because thermal and
 * memory state can change in the time between WorkManager deciding to
 * start this worker and it actually executing, and WorkManager has no
 * built-in constraint for either signal.
 */
class BackgroundResearchWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? NovaCompressApplication ?: return Result.failure()
        val locator = app.serviceLocator
        val settings = locator.settingsRepository

        val scheduler = ResearchScheduler(
            battery = AndroidBatteryStatusProvider(applicationContext),
            thermal = AndroidThermalStatusProvider(applicationContext, minThrottleLevel = settings.thermalSensitivity.first()),
            memory = AndroidMemoryStatusProvider(applicationContext),
            minBatteryPercent = settings.minBatteryPercentForResearch.first()
        )

        return when (scheduler.shouldRunResearch()) {
            is ResearchGate.Blocked -> Result.success() // conditions not met right now; the periodic schedule will try again later
            ResearchGate.Allowed -> {
                try {
                    val disabled = settings.disabledPluginIds.first()
                    val allowedPluginIds = PluginRegistry.all().map { it.id }.toSet() - disabled
                    BackgroundResearchRunner(locator.evolutionEngine).runResearchPass(allowedPluginIds = allowedPluginIds)
                    locator.knowledgeMaintenanceService.runMaintenance()
                    Result.success()
                } catch (e: Exception) {
                    Result.retry()
                }
            }
        }
    }
}
