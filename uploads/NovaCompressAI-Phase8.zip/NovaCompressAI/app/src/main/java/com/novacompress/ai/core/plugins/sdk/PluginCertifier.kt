package com.novacompress.ai.core.plugins.sdk

import com.novacompress.ai.core.plugins.CompressionPlugin
import kotlin.random.Random

data class CertificationResult(
    val pluginId: String,
    val passed: Boolean,
    val failedCases: List<String>
)

/**
 * Automatic plugin testing, per the spec: "Every plugin must pass Random
 * Data, Repeated Data, Binary Data, ... Large Files, Tiny Files... If any
 * test fails, Plugin becomes disabled." This runs the standard corpus
 * below against every registered plugin (see [com.novacompress.ai.core.plugins.PluginRegistry]),
 * and any plugin that fails even one case is excluded from the active
 * plugin set - a real, automatic safety net against a future regression
 * silently producing corrupted archives, not just a development-time test
 * suite that has to be remembered to run.
 */
object PluginCertifier {

    private fun standardCorpus(): List<Pair<String, ByteArray>> {
        val random = Random(1)
        return listOf(
            "empty" to ByteArray(0),
            "tiny_single_byte" to byteArrayOf(1),
            "random_small" to ByteArray(500) { random.nextInt(256).toByte() },
            "random_large" to ByteArray(50_000) { random.nextInt(256).toByte() },
            "repeated" to ByteArray(10_000) { 7 },
            "binary_like_ramp" to ByteArray(5_000) { (it % 256).toByte() },
            "all_256_distinct_values" to ByteArray(256) { it.toByte() },
            "text_like" to ("the quick brown fox jumps over the lazy dog. ".repeat(200)).toByteArray(Charsets.UTF_8),
            "corrupted_input_style" to byteArrayOf(-1, -1, -1, -1, 0, 0, 0, 0, 127, -128, 1, 2, 3)
        )
    }

    fun certify(plugin: CompressionPlugin): CertificationResult {
        val failures = mutableListOf<String>()
        for ((label, data) in standardCorpus()) {
            try {
                val compressed = plugin.compress(data)
                val decompressed = plugin.decompress(compressed)
                if (!decompressed.contentEquals(data)) {
                    failures.add("$label: round-trip output did not match the original")
                }
            } catch (e: Exception) {
                failures.add("$label: threw ${e::class.simpleName}: ${e.message}")
            }
        }
        return CertificationResult(plugin.id, passed = failures.isEmpty(), failedCases = failures)
    }

    fun certifyAll(plugins: List<CompressionPlugin>): List<CertificationResult> = plugins.map { certify(it) }
}
