package com.novacompress.ai.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.novacompress.ai.LaunchIntent
import com.novacompress.ai.R
import com.novacompress.ai.ui.compress.CompressScreen
import com.novacompress.ai.ui.dashboard.DashboardScreen
import com.novacompress.ai.ui.decompress.DecompressScreen
import com.novacompress.ai.ui.developer.DeveloperScreen
import com.novacompress.ai.ui.research.ResearchScreen
import com.novacompress.ai.ui.settings.SettingsScreen

private sealed class NovaDestination(val route: String, val labelRes: Int, val icon: ImageVector) {
    object Dashboard : NovaDestination("dashboard", R.string.nav_dashboard, Icons.Filled.Dashboard)
    object Compress : NovaDestination("compress", R.string.nav_compress, Icons.Filled.Archive)
    object Decompress : NovaDestination("decompress", R.string.nav_decompress, Icons.Filled.Unarchive)
    object Research : NovaDestination("research", R.string.nav_research, Icons.Filled.Science)
    object Settings : NovaDestination("settings", R.string.nav_settings, Icons.Filled.Settings)
}

private val bottomBarDestinations = listOf(
    NovaDestination.Dashboard,
    NovaDestination.Compress,
    NovaDestination.Decompress,
    NovaDestination.Research,
    NovaDestination.Settings
)

/**
 * Developer Mode is deliberately *not* one of [bottomBarDestinations] - see
 * [com.novacompress.ai.ui.developer.DeveloperScreen]'s doc comment. It's
 * reached only via a button on the Settings screen, matching Android's own
 * hidden-behind-Settings Developer Options pattern.
 */
private const val DEVELOPER_ROUTE = "developer"

@Composable
fun NovaNavHost(launchIntent: LaunchIntent = LaunchIntent.None) {
    val navController = rememberNavController()

    // Consumed exactly once: after the relevant screen picks it up, this
    // reverts to None so navigating back to Compress/Decompress later
    // (e.g. via the bottom bar) never re-triggers auto-selection.
    var pendingLaunchIntent by remember { mutableStateOf(launchIntent) }

    val startDestination = when (launchIntent) {
        is LaunchIntent.ShareToCompress -> NovaDestination.Compress.route
        is LaunchIntent.OpenToDecompress -> NovaDestination.Decompress.route
        LaunchIntent.None -> NovaDestination.Dashboard.route
    }

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route

            NavigationBar {
                bottomBarDestinations.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        label = { Text(stringResource(destination.labelRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NovaDestination.Dashboard.route) { DashboardScreen() }
            composable(NovaDestination.Compress.route) {
                val initialUri = (pendingLaunchIntent as? LaunchIntent.ShareToCompress)?.uri
                CompressScreen(
                    initialUri = initialUri,
                    onInitialUriConsumed = { pendingLaunchIntent = LaunchIntent.None }
                )
            }
            composable(NovaDestination.Decompress.route) {
                val initialUri = (pendingLaunchIntent as? LaunchIntent.OpenToDecompress)?.uri
                DecompressScreen(
                    initialUri = initialUri,
                    onInitialUriConsumed = { pendingLaunchIntent = LaunchIntent.None }
                )
            }
            composable(NovaDestination.Research.route) { ResearchScreen() }
            composable(NovaDestination.Settings.route) {
                SettingsScreen(onOpenDeveloperMode = { navController.navigate(DEVELOPER_ROUTE) })
            }
            composable(DEVELOPER_ROUTE) {
                DeveloperScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
