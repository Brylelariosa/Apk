package com.novacompress.ai.ui.settings

import android.net.Uri
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novacompress.ai.BuildConfig
import com.novacompress.ai.R
import com.novacompress.ai.data.repository.SettingsRepository
import com.novacompress.ai.ui.common.novaViewModel
import kotlin.math.roundToInt

/**
 * Phase 4 added the Background Learning toggle; Phase 6 added Knowledge
 * Export/Import; Phase 8 fills out the rest of the spec's Settings surface
 * (research budget, thermal/battery limits, plugin permissions) plus the
 * entry point into Developer Mode - every control here is wired to a real
 * subsystem, never a dead switch (see [SettingsViewModel] and
 * [SettingsRepository]).
 */
@Composable
fun SettingsScreen(onOpenDeveloperMode: () -> Unit = {}) {
    val viewModel: SettingsViewModel = novaViewModel()
    val backgroundLearningEnabled by viewModel.backgroundLearningEnabled.collectAsState()
    val researchIntervalHours by viewModel.researchIntervalHours.collectAsState()
    val minBatteryPercent by viewModel.minBatteryPercentForResearch.collectAsState()
    val thermalSensitivity by viewModel.thermalSensitivity.collectAsState()
    val disabledPluginIds by viewModel.disabledPluginIds.collectAsState()
    val backupMessage by viewModel.backupMessage.collectAsState()
    val context = LocalContext.current

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.exportKnowledge { context.contentResolver.openOutputStream(uri) }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importKnowledge { context.contentResolver.openInputStream(uri) }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineMedium)
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.settings_background_learning), style = MaterialTheme.typography.titleMedium)
                        Text(
                            stringResource(R.string.settings_background_learning_description),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = backgroundLearningEnabled,
                        onCheckedChange = { viewModel.setBackgroundLearningEnabled(it) }
                    )
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(stringResource(R.string.settings_research_budget_section), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_research_budget_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SettingsRepository.RESEARCH_INTERVAL_OPTIONS_HOURS.forEach { hours ->
                            FilterChip(
                                selected = researchIntervalHours == hours,
                                onClick = { viewModel.setResearchIntervalHours(hours) },
                                label = { Text(stringResource(R.string.settings_research_interval_chip, hours)) }
                            )
                        }
                    }
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(stringResource(R.string.settings_limits_section), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_limits_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    var sliderPosition by remember(minBatteryPercent) { mutableStateOf(minBatteryPercent.toFloat()) }
                    Text(
                        stringResource(R.string.settings_min_battery_label, sliderPosition.roundToInt()),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Slider(
                        value = sliderPosition,
                        onValueChange = { sliderPosition = it },
                        onValueChangeFinished = { viewModel.setMinBatteryPercentForResearch(sliderPosition.roundToInt()) },
                        valueRange = SettingsRepository.MIN_BATTERY_PERCENT_RANGE.first.toFloat()..SettingsRepository.MIN_BATTERY_PERCENT_RANGE.last.toFloat()
                    )

                    Text(stringResource(R.string.settings_thermal_label), style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SettingsRepository.THERMAL_SENSITIVITY_OPTIONS.forEach { level ->
                            FilterChip(
                                selected = thermalSensitivity == level,
                                onClick = { viewModel.setThermalSensitivity(level) },
                                label = { Text(thermalSensitivityLabel(level)) }
                            )
                        }
                    }
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(stringResource(R.string.settings_plugin_permissions_section), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_plugin_permissions_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    viewModel.allPlugins.forEach { plugin ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(plugin.displayName, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                            Switch(
                                checked = plugin.id !in disabledPluginIds,
                                onCheckedChange = { enabled -> viewModel.setPluginEnabled(plugin.id, enabled) }
                            )
                        }
                    }
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(stringResource(R.string.settings_developer_mode_section), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_developer_mode_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(onClick = onOpenDeveloperMode) {
                        Text(stringResource(R.string.settings_open_developer_mode))
                    }
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(stringResource(R.string.settings_backup_section), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(R.string.settings_backup_description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { exportLauncher.launch("novacompress_knowledge.nova-backup") }) {
                            Text(stringResource(R.string.settings_export_knowledge))
                        }
                        OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                            Text(stringResource(R.string.settings_import_knowledge))
                        }
                    }
                    backupMessage?.let {
                        Text(it, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.settings_about), style = MaterialTheme.typography.titleMedium)
                    Text(
                        "NovaCompress AI ${BuildConfig.VERSION_NAME}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        stringResource(R.string.settings_offline_notice),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
private fun thermalSensitivityLabel(level: Int): String = when (level) {
    PowerManager.THERMAL_STATUS_LIGHT -> stringResource(R.string.settings_thermal_light)
    PowerManager.THERMAL_STATUS_SEVERE -> stringResource(R.string.settings_thermal_severe)
    else -> stringResource(R.string.settings_thermal_moderate)
}
