package com.novacompress.ai.core.common

/**
 * Sequential reader over a byte array. Keeps archive/metadata decoding code
 * free of manual offset bookkeeping.
 */
class ByteCursor(private val data: ByteArray, startOffset: Int = 0) {

    var position: Int = startOffset
        private set

    /** Bytes left to read. A field length or list count claiming more than this is provably impossible to satisfy - see [readBytes] and [readStringList]. */
    val remaining: Int
        get() = data.size - position

    fun readByte(): Int {
        val v = data[position].toInt() and 0xFF
        position += 1
        return v
    }

    fun readBoolean(): Boolean = readByte() != 0

    fun readU16(): Int {
        val v = BinaryIO.readU16(data, position)
        position += 2
        return v
    }

    fun readU32(): Int {
        val v = BinaryIO.readU32(data, position)
        position += 4
        return v
    }

    fun readLong(): Long {
        val v = BinaryIO.readLong(data, position)
        position += 8
        return v
    }

    fun readDouble(): Double {
        val v = BinaryIO.readDouble(data, position)
        position += 8
        return v
    }

    /**
     * @throws java.io.IOException if [length] is negative or exceeds
     *   [remaining] - this data is always an in-memory buffer decoded from
     *   an archive or backup file, so unlike a stream, "more bytes than
     *   are actually left in the buffer" is not just implausible but
     *   provably impossible, making this the tightest bound available
     *   (see [BinaryIO.requireSaneLength] for the stream-reading
     *   equivalent, which can't be this precise since a stream's total
     *   remaining length isn't known upfront).
     */
    fun readBytes(length: Int): ByteArray {
        if (length < 0 || length > remaining) {
            throw java.io.IOException("Corrupted data: implausible byte-field length ($length, only $remaining byte(s) remain)")
        }
        val out = data.copyOfRange(position, position + length)
        position += length
        return out
    }

    fun readString(): String {
        val length = readU32()
        return String(readBytes(length), Charsets.UTF_8)
    }

    /** @throws java.io.IOException if the encoded count is negative or exceeds [remaining] - see [readBytes]'s doc comment for why that's the correct bound for an in-memory buffer, and this class's `List(count) { ... }` doc note in [BinaryIO.requireSaneCount] for why the count itself (not just each string's length) needs its own check before allocating. */
    fun readStringList(): List<String> {
        val count = readU32()
        if (count < 0 || count > remaining) {
            throw java.io.IOException("Corrupted data: implausible string-list count ($count, only $remaining byte(s) remain)")
        }
        return List(count) { readString() }
    }
}
