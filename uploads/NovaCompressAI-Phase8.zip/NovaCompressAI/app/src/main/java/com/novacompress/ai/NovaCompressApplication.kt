package com.novacompress.ai

import android.app.Application
import com.novacompress.ai.core.service.TempFileJanitor
import com.novacompress.ai.di.ServiceLocator
import com.novacompress.ai.work.BackgroundResearchScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class NovaCompressApplication : Application() {

    lateinit var serviceLocator: ServiceLocator
        private set

    /** Long-lived scope for reactive, app-lifetime background wiring (not tied to any UI screen). */
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        serviceLocator = ServiceLocator(this)

        applicationScope.launch(Dispatchers.IO) {
            TempFileJanitor.cleanOrphans(cacheDir)
        }

        // Reactively enqueue/cancel the background research job as the
        // user's preferences change (including once, right away, using
        // whatever values are currently stored). Combined so that changing
        // *either* the on/off toggle or the Research Budget interval alone
        // (without touching the other) still reschedules correctly.
        applicationScope.launch {
            combine(
                serviceLocator.settingsRepository.backgroundLearningEnabled,
                serviceLocator.settingsRepository.researchIntervalHours
            ) { enabled, intervalHours -> enabled to intervalHours }
                .collect { (enabled, intervalHours) ->
                    if (enabled) {
                        BackgroundResearchScheduler.enable(this@NovaCompressApplication, intervalHours.toLong())
                    } else {
                        BackgroundResearchScheduler.disable(this@NovaCompressApplication)
                    }
                }
        }
    }
}
