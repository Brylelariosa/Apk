package com.novacompress.ai.core.backup

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.ByteCursor
import java.io.ByteArrayOutputStream

/**
 * Encodes/decodes the `.nova-backup` format described in the spec's
 * Export/Import section: "Export Knowledge Database, Genome Library...
 * Compressed .nova-backup package." Uses simple length-prefixed fields
 * (the same approach as [com.novacompress.ai.core.archive.ArchiveMetadataCodec]),
 * not JSON - consistent, and avoids Android's `org.json` throwing
 * "not mocked" in plain JVM unit tests.
 *
 * Format:
 * ```
 * [magic: 4 bytes "NVBK"][version: 1 byte][exportedAtEpochMillis: 8 bytes]
 * [genomeCount: 4 bytes] genomeCount * GenomeBackupRecord
 * [benchmarkCount: 4 bytes] benchmarkCount * BenchmarkBackupRecord
 * ```
 */
object KnowledgeBackupCodec {

    private val MAGIC = byteArrayOf('N'.code.toByte(), 'V'.code.toByte(), 'B'.code.toByte(), 'K'.code.toByte())
    private const val FORMAT_VERSION = 1

    fun encode(backup: KnowledgeBackup): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(MAGIC)
        out.write(FORMAT_VERSION)
        BinaryIO.writeLong(out, backup.exportedAtEpochMillis)

        BinaryIO.writeU32(out, backup.genomes.size)
        for (g in backup.genomes) {
            BinaryIO.writeString(out, g.genomeId)
            BinaryIO.writeString(out, g.displayName)
            BinaryIO.writeString(out, g.pluginIdsCsv)
            BinaryIO.writeString(out, g.rationale)
            BinaryIO.writeU32(out, g.generation)
            BinaryIO.writeString(out, g.species)
            BinaryIO.writeString(out, g.status)
            BinaryIO.writeString(out, g.parentIdsCsv)
            BinaryIO.writeDouble(out, g.bestFitness)
            BinaryIO.writeDouble(out, g.bestRatio)
            BinaryIO.writeU32(out, g.benchmarkCount)
            BinaryIO.writeLong(out, g.createdAtEpochMillis)
        }

        BinaryIO.writeU32(out, backup.benchmarks.size)
        for (b in backup.benchmarks) {
            BinaryIO.writeString(out, b.genomeId)
            BinaryIO.writeU32(out, b.originalSize)
            BinaryIO.writeU32(out, b.compressedSize)
            BinaryIO.writeLong(out, b.compressionTimeNanos)
            BinaryIO.writeLong(out, b.decompressionTimeNanos)
            out.write(if (b.verified) 1 else 0)
            BinaryIO.writeDouble(out, b.fitnessScore)
            BinaryIO.writeLong(out, b.createdAtEpochMillis)
        }

        return out.toByteArray()
    }

    fun decode(bytes: ByteArray): KnowledgeBackup {
        require(bytes.size >= 5) { "backup file is too small to be valid" }
        val magic = bytes.copyOfRange(0, 4)
        require(magic.contentEquals(MAGIC)) { "not a NovaCompress AI backup file" }
        val version = bytes[4].toInt() and 0xFF
        require(version == FORMAT_VERSION) { "unsupported backup format version: $version" }

        val cursor = ByteCursor(bytes, startOffset = 5)
        val exportedAt = cursor.readLong()

        val genomeCount = cursor.readU32()
        require(genomeCount in 0..com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_LIST_COUNT) {
            "backup file has an implausible genome count ($genomeCount)"
        }
        val genomes = List(genomeCount) {
            GenomeBackupRecord(
                genomeId = cursor.readString(),
                displayName = cursor.readString(),
                pluginIdsCsv = cursor.readString(),
                rationale = cursor.readString(),
                generation = cursor.readU32(),
                species = cursor.readString(),
                status = cursor.readString(),
                parentIdsCsv = cursor.readString(),
                bestFitness = cursor.readDouble(),
                bestRatio = cursor.readDouble(),
                benchmarkCount = cursor.readU32(),
                createdAtEpochMillis = cursor.readLong()
            )
        }

        val benchmarkCount = cursor.readU32()
        require(benchmarkCount in 0..com.novacompress.ai.core.common.Constants.MAX_PLAUSIBLE_LIST_COUNT) {
            "backup file has an implausible benchmark count ($benchmarkCount)"
        }
        val benchmarks = List(benchmarkCount) {
            BenchmarkBackupRecord(
                genomeId = cursor.readString(),
                originalSize = cursor.readU32(),
                compressedSize = cursor.readU32(),
                compressionTimeNanos = cursor.readLong(),
                decompressionTimeNanos = cursor.readLong(),
                verified = cursor.readBoolean(),
                fitnessScore = cursor.readDouble(),
                createdAtEpochMillis = cursor.readLong()
            )
        }

        return KnowledgeBackup(exportedAt, genomes, benchmarks)
    }
}
