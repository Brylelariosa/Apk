package com.novacompress.ai.ui.research

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novacompress.ai.R
import com.novacompress.ai.core.genome.GenomeStatus
import com.novacompress.ai.data.repository.GenomeSummary
import com.novacompress.ai.ui.common.novaViewModel

@Composable
fun ResearchScreen() {
    val viewModel: ResearchViewModel = novaViewModel()
    val uiState by viewModel.uiState.collectAsState()

    // Same capped-reading-width treatment as Dashboard, for the same reason:
    // a long genome list shouldn't stretch edge-to-edge on a tablet. The list
    // itself stays a single scrollable column at every width - splitting it
    // into side-by-side panels would mean a scrollable list nested inside a
    // bounded-height Row inside the outer LazyColumn, which risks the classic
    // Compose "infinite height constraints" crash without a fixed height to
    // anchor it to; not worth that risk for a genome list that reads perfectly
    // well as a single column even on a wide screen.
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .then(if (isWideScreen) Modifier.widthIn(max = 720.dp) else Modifier)
                .align(Alignment.TopCenter)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Column {
                    Text(stringResource(R.string.research_title), style = MaterialTheme.typography.headlineMedium)
                    Text(
                        stringResource(R.string.research_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (uiState.species.isNotEmpty()) {
                item {
                    Column {
                        Text(stringResource(R.string.research_species_section), style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        SimpleBarChart(
                            values = uiState.species.map { "${it.species} (${it.genomeCount})" to it.bestFitness },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                Text(stringResource(R.string.research_genomes_section), style = MaterialTheme.typography.titleMedium)
            }

            if (uiState.genomes.isEmpty()) {
                item {
                    Text(
                        stringResource(R.string.research_no_genomes),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(uiState.genomes, key = { it.genomeId }) { genome ->
                    GenomeRow(genome)
                }
            }
        }
    }
}

@Composable
private fun GenomeRow(genome: GenomeSummary) {
    var expanded by remember { mutableStateOf(false) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(genome.displayName, style = MaterialTheme.typography.titleMedium)
                StatusChip(genome.status)
            }
            Text(
                genome.pipelineDescription,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(stringResource(R.string.research_generation_label, genome.generation), style = MaterialTheme.typography.labelLarge)
                Text(stringResource(R.string.research_ratio_label, genome.bestRatio), style = MaterialTheme.typography.labelLarge)
                Text(stringResource(R.string.research_benchmarks_label, genome.benchmarkCount), style = MaterialTheme.typography.labelLarge)
            }

            if (expanded) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(genome.rationale, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    if (genome.parentIds.isEmpty()) {
                        stringResource(R.string.research_no_parents)
                    } else {
                        stringResource(R.string.research_parents_label, genome.parentIds.joinToString())
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun StatusChip(status: GenomeStatus) {
    val (label, color) = when (status) {
        GenomeStatus.EXPERIMENTAL -> "Experimental" to MaterialTheme.colorScheme.tertiary
        GenomeStatus.VERIFIED -> "Verified" to MaterialTheme.colorScheme.primary
        GenomeStatus.STABLE -> "Stable" to MaterialTheme.colorScheme.primary
        GenomeStatus.ELITE -> "Elite" to MaterialTheme.colorScheme.primary
        GenomeStatus.RETIRED -> "Retired" to MaterialTheme.colorScheme.outline
    }
    Surface(
        color = color.copy(alpha = 0.15f),
        contentColor = color,
        shape = RoundedCornerShape(50),
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
