package com.novacompress.ai.core.plugins.sdk

enum class PluginCategory {
    PREPROCESSING,
    SEGMENTATION,
    DICTIONARY,
    PATTERN_DETECTION,
    ENTROPY_ENCODING,
    PREDICTION,
    TRANSFORM,
    OPTIMIZATION
}

/**
 * Descriptive metadata about a plugin, per the spec's "Plugin Information"
 * section. Deliberately a separate lookup from [com.novacompress.ai.core.plugins.CompressionPlugin]
 * itself rather than new properties on that interface - this is
 * informational (shown in the Plugin Browser, used by [PluginCertifier]
 * for reporting) and has nothing to do with the compress/decompress
 * contract every plugin already implements, so adding it here means none
 * of the 8 existing, already-validated plugin classes need to change.
 */
data class PluginInfo(
    val id: String,
    val displayName: String,
    val author: String,
    val version: Int,
    val description: String,
    val category: PluginCategory,
    val minAndroidApi: Int,
    val threadSafe: Boolean,
    val streamingSupport: Boolean,
    val experimental: Boolean
)

object PluginInfoRegistry {

    private const val CORE_AUTHOR = "NovaCompress Core Team"

    private val infos: Map<String, PluginInfo> = listOf(
        PluginInfo(
            id = "delta", displayName = "Delta Encoding", author = CORE_AUTHOR, version = 1,
            description = "First-order byte differencing against the previous byte; smooths gradually changing values.",
            category = PluginCategory.PREPROCESSING, minAndroidApi = 26,
            threadSafe = true, streamingSupport = true, experimental = false
        ),
        PluginInfo(
            id = "rle", displayName = "Run-Length Encoding", author = CORE_AUTHOR, version = 1,
            description = "PackBits-style run compression for sequences of repeated bytes.",
            category = PluginCategory.PATTERN_DETECTION, minAndroidApi = 26,
            threadSafe = true, streamingSupport = true, experimental = false
        ),
        PluginInfo(
            id = "huffman", displayName = "Huffman Coding", author = CORE_AUTHOR, version = 1,
            description = "Canonical Huffman entropy coding built from a per-input frequency table.",
            category = PluginCategory.ENTROPY_ENCODING, minAndroidApi = 26,
            threadSafe = true, streamingSupport = false, experimental = false
        ),
        PluginInfo(
            id = "lz77", displayName = "LZ77", author = CORE_AUTHOR, version = 1,
            description = "Sliding-window dictionary matching via hash chains over 3-byte prefixes.",
            category = PluginCategory.DICTIONARY, minAndroidApi = 26,
            threadSafe = true, streamingSupport = false, experimental = false
        ),
        PluginInfo(
            id = "mtf", displayName = "Move-To-Front", author = CORE_AUTHOR, version = 1,
            description = "Recency transform turning locally-clustered byte values into small indices; pairs well with BWT.",
            category = PluginCategory.TRANSFORM, minAndroidApi = 26,
            threadSafe = true, streamingSupport = true, experimental = false
        ),
        PluginInfo(
            id = "bwt", displayName = "Burrows-Wheeler Transform", author = CORE_AUTHOR, version = 1,
            description = "Groups similar byte contexts together via a suffix-array rotation sort (no sentinel byte needed).",
            category = PluginCategory.TRANSFORM, minAndroidApi = 26,
            threadSafe = true, streamingSupport = false, experimental = false
        ),
        PluginInfo(
            id = "arithmetic", displayName = "Arithmetic Coding", author = CORE_AUTHOR, version = 1,
            description = "Witten-Neal-Cleary integer arithmetic coder with a static per-input frequency model.",
            category = PluginCategory.ENTROPY_ENCODING, minAndroidApi = 26,
            threadSafe = true, streamingSupport = false, experimental = false
        ),
        PluginInfo(
            id = "predictive", displayName = "Predictive Coding", author = CORE_AUTHOR, version = 1,
            description = "Second-order linear extrapolation predictor; effective on steady trends (sensor/audio-like data).",
            category = PluginCategory.PREDICTION, minAndroidApi = 26,
            threadSafe = true, streamingSupport = true, experimental = false
        )
    ).associateBy { it.id }

    fun get(pluginId: String): PluginInfo? = infos[pluginId]
    fun all(): List<PluginInfo> = infos.values.toList()
}
