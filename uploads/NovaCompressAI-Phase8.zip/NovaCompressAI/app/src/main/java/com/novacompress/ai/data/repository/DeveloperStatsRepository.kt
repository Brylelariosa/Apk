package com.novacompress.ai.data.repository

import android.content.Context
import com.novacompress.ai.core.plugins.PluginRegistry
import com.novacompress.ai.core.plugins.sdk.CertificationResult
import com.novacompress.ai.core.plugins.sdk.PluginInfo
import com.novacompress.ai.core.plugins.sdk.PluginInfoRegistry
import com.novacompress.ai.data.database.BenchmarkRecordDao
import com.novacompress.ai.data.database.GenomeDao
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

/** One plugin's full Developer Mode picture: its descriptive metadata, its automatic certification result, and whether the user has administratively disabled it (see [SettingsRepository.disabledPluginIds]). */
data class PluginDiagnostic(
    val info: PluginInfo,
    val certification: CertificationResult?,
    val userDisabled: Boolean
)

/** A snapshot of the Knowledge Database's size against the spec's stated limits (see [KnowledgeMaintenanceService]). */
data class DatabaseUsageSnapshot(
    val activeGenomeCount: Int,
    val retiredGenomeCount: Int,
    val benchmarkCount: Int,
    val databaseFileBytes: Long,
    val maxActiveGenomes: Int,
    val maxDatabaseBytes: Long
) {
    val genomeCountFraction: Float
        get() = if (maxActiveGenomes <= 0) 0f else (activeGenomeCount.toDouble() / maxActiveGenomes.toDouble()).toFloat().coerceIn(0f, 1f)

    val databaseSizeFraction: Float
        get() = if (maxDatabaseBytes <= 0) 0f else (databaseFileBytes.toDouble() / maxDatabaseBytes.toDouble()).toFloat().coerceIn(0f, 1f)
}

/**
 * Read-only diagnostics for Developer Mode's Genome/Pipeline/Plugin/Database
 * inspectors. Kept separate from [EvolutionStatsRepository] (which serves
 * the Research screen's simpler, always-relevant "how well is the AI
 * doing" view) since this is deeper, advanced-user-only detail - raw file
 * size against the spec's caps, per-plugin certification results - that
 * would just be noise on Research.
 *
 * Like [KnowledgeMaintenanceService], this is a thin wrapper over a few
 * individually-simple Room queries plus one filesystem stat call, not
 * logic dense enough to justify its own interface+fake abstraction for
 * unit testing.
 */
class DeveloperStatsRepository(
    private val context: Context,
    private val genomeDao: GenomeDao,
    private val benchmarkRecordDao: BenchmarkRecordDao
) {
    fun observeDatabaseUsage(): Flow<DatabaseUsageSnapshot> =
        combine(
            genomeDao.observeActiveGenomeCount(),
            genomeDao.observeRetiredGenomeCount(),
            benchmarkRecordDao.observeCount()
        ) { active, retired, benchmarks ->
            DatabaseUsageSnapshot(
                activeGenomeCount = active,
                retiredGenomeCount = retired,
                benchmarkCount = benchmarks,
                databaseFileBytes = knowledgeDatabaseFileBytes(),
                maxActiveGenomes = KnowledgeMaintenanceService.MAX_ACTIVE_GENOMES,
                maxDatabaseBytes = KnowledgeMaintenanceService.MAX_KNOWLEDGE_DB_BYTES
            )
        }

    /** Every registered plugin's metadata + certification result, in [PluginInfoRegistry]'s declared order. Plugins that failed certification (and so are excluded from [PluginRegistry]) are still listed here - that's exactly the diagnostic this screen exists to surface. */
    fun pluginDiagnostics(disabledPluginIds: Set<String>): List<PluginDiagnostic> {
        val certifications = PluginRegistry.certificationReport().associateBy { it.pluginId }
        return PluginInfoRegistry.all().map { info ->
            PluginDiagnostic(
                info = info,
                certification = certifications[info.id],
                userDisabled = info.id in disabledPluginIds
            )
        }
    }

    private fun knowledgeDatabaseFileBytes(): Long {
        val dbFile = context.getDatabasePath("nova_knowledge.db")
        return if (dbFile.exists()) dbFile.length() else 0L
    }
}
