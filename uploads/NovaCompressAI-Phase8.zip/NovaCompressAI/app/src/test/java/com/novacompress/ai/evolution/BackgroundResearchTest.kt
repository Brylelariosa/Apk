package com.novacompress.ai.evolution

import com.novacompress.ai.core.evolution.BackgroundResearchRunner
import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.core.evolution.SyntheticSampleGenerator
import com.novacompress.ai.testutil.InMemoryGenomeRepository
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class SyntheticSampleGeneratorTest {

    @Test
    fun `produces four distinctly-shaped samples of the expected size`() {
        val samples = SyntheticSampleGenerator.samples()
        assertEquals(4, samples.size)
        assertEquals(setOf("random", "repetitive", "text_like", "structured"), samples.map { it.first }.toSet())
        for ((label, data) in samples) {
            assertTrue("sample $label should be non-empty", data.isNotEmpty())
        }
    }

    @Test
    fun `the random sample has much higher entropy than the repetitive sample`() {
        val samples = SyntheticSampleGenerator.samples().toMap()
        val random = samples.getValue("random")
        val repetitive = samples.getValue("repetitive")

        fun distinctByteCount(data: ByteArray) = data.toSet().size

        assertTrue(
            "expected the random sample to use many more distinct byte values than the repetitive one",
            distinctByteCount(random) > distinctByteCount(repetitive)
        )
    }
}

class BackgroundResearchRunnerTest {

    @Test
    fun `a research pass explores every synthetic sample and grows the knowledge base`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(77))
        val runner = BackgroundResearchRunner(engine)

        val result = runner.runResearchPass()

        assertEquals(4, result.samplesExplored)
        assertTrue(result.totalCandidatesConsidered > 0)
        // 4 samples x >=3 guaranteed candidates each, per EvolutionEngine's own guarantee.
        assertTrue(repository.benchmarkCount() >= 12)
    }

    @Test
    fun `a research pass still succeeds with a restricted set of allowed plugins`() = runTest {
        // Exercises the Plugin Permissions plumbing end-to-end (Settings ->
        // BackgroundResearchWorker -> here) without asserting exact plugin
        // exclusion at this level - that behavior itself is thoroughly
        // covered by MutationEngineTest, the actual enforcement point.
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(77))
        val runner = BackgroundResearchRunner(engine)

        val result = runner.runResearchPass(allowedPluginIds = setOf("delta", "rle", "huffman"))

        assertEquals(4, result.samplesExplored)
        assertTrue(result.totalCandidatesConsidered > 0)
    }
}
