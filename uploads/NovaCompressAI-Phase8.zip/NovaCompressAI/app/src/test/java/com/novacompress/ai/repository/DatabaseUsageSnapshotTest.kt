package com.novacompress.ai.repository

import com.novacompress.ai.data.repository.DatabaseUsageSnapshot
import org.junit.Assert.assertEquals
import org.junit.Test

class DatabaseUsageSnapshotTest {

    private fun snapshot(
        activeGenomeCount: Int = 0,
        databaseFileBytes: Long = 0,
        maxActiveGenomes: Int = 500,
        maxDatabaseBytes: Long = 128L * 1024 * 1024
    ) = DatabaseUsageSnapshot(
        activeGenomeCount = activeGenomeCount,
        retiredGenomeCount = 0,
        benchmarkCount = 0,
        databaseFileBytes = databaseFileBytes,
        maxActiveGenomes = maxActiveGenomes,
        maxDatabaseBytes = maxDatabaseBytes
    )

    @Test
    fun `genome count fraction is the ratio of active genomes to the population cap`() {
        assertEquals(0.5f, snapshot(activeGenomeCount = 250, maxActiveGenomes = 500).genomeCountFraction, 0.0001f)
        assertEquals(0.0f, snapshot(activeGenomeCount = 0, maxActiveGenomes = 500).genomeCountFraction, 0.0001f)
    }

    @Test
    fun `database size fraction is the ratio of file bytes to the spec's 128MB cap`() {
        val cap = 128L * 1024 * 1024
        assertEquals(0.5f, snapshot(databaseFileBytes = cap / 2, maxDatabaseBytes = cap).databaseSizeFraction, 0.0001f)
        assertEquals(1.0f, snapshot(databaseFileBytes = cap, maxDatabaseBytes = cap).databaseSizeFraction, 0.0001f)
    }

    @Test
    fun `both fractions are coerced to 1 rather than overflowing past the cap`() {
        assertEquals(1.0f, snapshot(activeGenomeCount = 600, maxActiveGenomes = 500).genomeCountFraction, 0.0001f)
        assertEquals(1.0f, snapshot(databaseFileBytes = 200L * 1024 * 1024, maxDatabaseBytes = 128L * 1024 * 1024).databaseSizeFraction, 0.0001f)
    }

    @Test
    fun `both fractions are zero rather than a division error when the cap is zero`() {
        assertEquals(0.0f, snapshot(activeGenomeCount = 10, maxActiveGenomes = 0).genomeCountFraction, 0.0001f)
        assertEquals(0.0f, snapshot(databaseFileBytes = 10, maxDatabaseBytes = 0).databaseSizeFraction, 0.0001f)
    }
}
