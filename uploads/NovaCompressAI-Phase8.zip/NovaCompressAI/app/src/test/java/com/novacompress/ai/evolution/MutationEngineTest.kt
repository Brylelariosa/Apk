package com.novacompress.ai.evolution

import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.evolution.MutationEngine
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import com.novacompress.ai.core.plugins.PluginRegistry
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MutationEngineTest {

    @Test
    fun `mutating any valid pipeline always produces another valid pipeline`() {
        val startingPipelines = listOf(
            PipelineDescriptor.of("delta"),
            PipelineDescriptor.of("delta", "rle", "huffman"),
            PipelineDescriptor.of("lz77", "huffman"),
            PipelineDescriptor.of("rle", "huffman", "mtf", "delta", "lz77")
        )
        val random = Random(123)

        for (pipeline in startingPipelines) {
            repeat(200) {
                val mutated = MutationEngine.mutate(pipeline, random)
                assertTrue(mutated.pluginIds.isNotEmpty())
                assertTrue(mutated.pluginIds.size <= Constants.MAX_PIPELINE_STAGES)
                assertTrue("mutation produced a duplicate plugin id: ${mutated.pluginIds}", mutated.pluginIds.size == mutated.pluginIds.toSet().size)
            }
        }
    }

    @Test
    fun `mutating a single-plugin pipeline never deletes down to zero plugins`() {
        val pipeline = PipelineDescriptor.of("huffman")
        val random = Random(7)
        repeat(500) {
            val mutated = MutationEngine.mutate(pipeline, random)
            assertTrue(mutated.pluginIds.isNotEmpty())
        }
    }

    @Test
    fun `mutating a pipeline that already uses every registered plugin stays valid`() {
        val allPluginsPipeline = PipelineDescriptor(PluginRegistry.all().map { it.id })
        val random = Random(9)
        repeat(500) {
            val mutated = MutationEngine.mutate(allPluginsPipeline, random)
            assertTrue(mutated.pluginIds.isNotEmpty())
            assertTrue(mutated.pluginIds.size <= Constants.MAX_PIPELINE_STAGES)
            assertTrue("mutation produced a duplicate plugin id: ${mutated.pluginIds}", mutated.pluginIds.size == mutated.pluginIds.toSet().size)
        }
    }

    @Test
    fun `allowedPluginIds restricts which new plugins INSERT and REPLACE may introduce`() {
        // "delta" is the only plugin already present, and the only other plugin
        // administratively allowed - every other registered plugin ("rle",
        // "huffman", "lz77", "mtf", "bwt", "arithmetic", "predictive") must
        // never appear in any mutation's output, however many stages it grows to.
        val pipeline = PipelineDescriptor.of("delta")
        val allowed = setOf("delta", "rle")
        val random = Random(42)

        repeat(500) {
            val mutated = MutationEngine.mutate(pipeline, random, allowedPluginIds = allowed)
            for (id in mutated.pluginIds) {
                assertTrue("mutation introduced a disallowed plugin id: $id (full pipeline: ${mutated.pluginIds})", id in allowed)
            }
        }
    }

    @Test
    fun `allowedPluginIds never forces removal of an already-present disallowed plugin`() {
        // "lz77" is already part of the pipeline but is NOT in allowedPluginIds -
        // per MutationEngine's contract, permissions are forward-looking only, so
        // DELETE/SWAP mutations may relocate or drop it same as any other plugin,
        // but no mutation should ever throw or otherwise treat its mere presence
        // as invalid.
        val pipeline = PipelineDescriptor.of("lz77", "huffman")
        val allowed = setOf("huffman", "mtf")
        val random = Random(99)

        repeat(500) {
            val mutated = MutationEngine.mutate(pipeline, random, allowedPluginIds = allowed)
            assertTrue(mutated.pluginIds.isNotEmpty())
            assertTrue(mutated.pluginIds.size <= Constants.MAX_PIPELINE_STAGES)
        }
    }

    @Test
    fun `allowedPluginIds excluding every unused plugin still returns a valid pipeline via DELETE or SWAP`() {
        // No plugin is allowed to be newly introduced (allowed = only what's
        // already present), so INSERT/REPLACE must never fire - but with 3+
        // stages, DELETE/SWAP remain possible and mutation should still succeed.
        val pipeline = PipelineDescriptor.of("delta", "rle", "huffman")
        val allowed = setOf("delta", "rle", "huffman")
        val random = Random(17)

        repeat(500) {
            val mutated = MutationEngine.mutate(pipeline, random, allowedPluginIds = allowed)
            assertTrue(mutated.pluginIds.isNotEmpty())
            for (id in mutated.pluginIds) {
                assertTrue(id in allowed)
            }
        }
    }

    @Test
    fun `allowedPluginIds excluding everything for a single-stage pipeline returns it unchanged`() {
        // No unused plugin is allowed and there's only one stage, so DELETE and
        // SWAP are also impossible (same "nothing possible" case already covered
        // for natural exhaustion, but reached here via the permission setting).
        val pipeline = PipelineDescriptor.of("delta")
        val random = Random(5)

        val mutated = MutationEngine.mutate(pipeline, random, allowedPluginIds = emptySet())
        assertTrue(mutated.pluginIds == pipeline.pluginIds)
    }
}
