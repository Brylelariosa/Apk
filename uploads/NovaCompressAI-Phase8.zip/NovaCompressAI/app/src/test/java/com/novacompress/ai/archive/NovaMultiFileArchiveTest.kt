package com.novacompress.ai.archive

import com.novacompress.ai.core.archive.MultiFileArchiveReadResult
import com.novacompress.ai.core.archive.MultiFileInput
import com.novacompress.ai.core.archive.NovaMultiFileArchiveReader
import com.novacompress.ai.core.archive.NovaMultiFileArchiveWriter
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class NovaMultiFileArchiveTest {

    private fun buildInputs(files: Map<String, ByteArray>): List<MultiFileInput> =
        files.map { (path, data) -> MultiFileInput(path, data.size.toLong()) { ByteArrayInputStream(data) } }

    @Test
    fun `round trips multiple files with independent verification`() {
        val files = linkedMapOf(
            "readme.txt" to "hello world, this is a readme file. ".repeat(50).toByteArray(),
            "data/values.bin" to TestSamples.randomBytes(3000, seed = 101),
            "empty.txt" to ByteArray(0),
            "notes/log.txt" to ("log entry\n").repeat(500).toByteArray()
        )

        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaMultiFileArchiveWriter.write(out, buildInputs(files), GenomePresets.BALANCED, chunkSize = 128)
        }.toByteArray()

        val recoveredFiles = mutableMapOf<String, ByteArrayOutputStream>()
        val result = NovaMultiFileArchiveReader.readAndVerify(
            ByteArrayInputStream(archiveBytes),
            openOutputFor = { path -> ByteArrayOutputStream().also { recoveredFiles[path] = it } }
        )

        assertTrue("expected Success but got $result", result is MultiFileArchiveReadResult.Success)
        val metadata = (result as MultiFileArchiveReadResult.Success).metadata
        assertEquals(files.size, metadata.entries.size)

        for ((path, original) in files) {
            assertArrayEquals("mismatch for $path", original, recoveredFiles.getValue(path).toByteArray())
        }
    }

    @Test
    fun `corrupting one file's chunk is detected and correctly attributed to that file's index`() {
        val files = linkedMapOf(
            "a.bin" to TestSamples.randomBytes(500, seed = 1),
            "b.bin" to TestSamples.randomBytes(500, seed = 2),
            "c.bin" to TestSamples.randomBytes(500, seed = 3)
        )
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaMultiFileArchiveWriter.write(out, buildInputs(files), GenomePresets.FAST, chunkSize = 128)
        }.toByteArray().copyOf()

        val corruptAt = (archiveBytes.size * 2) / 3
        archiveBytes[corruptAt] = (archiveBytes[corruptAt].toInt() xor 0xFF).toByte()

        val result = NovaMultiFileArchiveReader.readAndVerify(
            ByteArrayInputStream(archiveBytes),
            openOutputFor = { ByteArrayOutputStream() }
        )

        assertTrue(result is MultiFileArchiveReadResult.Corrupted)
        val corrupted = result as MultiFileArchiveReadResult.Corrupted
        assertTrue("expected a file index to be attributed to the corruption", corrupted.fileIndex != null)
    }

    @Test
    fun `writer rejects duplicate relative paths`() {
        val files = listOf(
            MultiFileInput("same.txt", 3) { ByteArrayInputStream(byteArrayOf(1, 2, 3)) },
            MultiFileInput("same.txt", 3) { ByteArrayInputStream(byteArrayOf(4, 5, 6)) }
        )
        assertThrows(IllegalArgumentException::class.java) {
            NovaMultiFileArchiveWriter.write(ByteArrayOutputStream(), files, GenomePresets.FAST)
        }
    }

    @Test
    fun `an empty file list round trips to a valid, empty archive`() {
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaMultiFileArchiveWriter.write(out, emptyList(), GenomePresets.BALANCED)
        }.toByteArray()

        val result = NovaMultiFileArchiveReader.readAndVerify(
            ByteArrayInputStream(archiveBytes),
            openOutputFor = { ByteArrayOutputStream() }
        )
        assertTrue(result is MultiFileArchiveReadResult.Success)
        assertEquals(0, (result as MultiFileArchiveReadResult.Success).metadata.entries.size)
    }

    @Test
    fun `progress callback fires once per file in order`() {
        val files = linkedMapOf(
            "1.bin" to TestSamples.randomBytes(200, seed = 11),
            "2.bin" to TestSamples.randomBytes(200, seed = 12),
            "3.bin" to TestSamples.randomBytes(200, seed = 13)
        )
        val calls = mutableListOf<String>()
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaMultiFileArchiveWriter.write(
                out, buildInputs(files), GenomePresets.FAST, chunkSize = 64,
                onFileComplete = { _, _, path -> calls.add(path) }
            )
        }.toByteArray()

        assertEquals(listOf("1.bin", "2.bin", "3.bin"), calls)

        val readCalls = mutableListOf<String>()
        NovaMultiFileArchiveReader.readAndVerify(
            ByteArrayInputStream(archiveBytes),
            openOutputFor = { ByteArrayOutputStream() },
            onFileComplete = { _, _, path -> readCalls.add(path) }
        )
        assertEquals(listOf("1.bin", "2.bin", "3.bin"), readCalls)
    }
}
