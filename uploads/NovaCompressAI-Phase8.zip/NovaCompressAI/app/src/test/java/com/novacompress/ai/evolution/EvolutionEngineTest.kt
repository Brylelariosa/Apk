package com.novacompress.ai.evolution

import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.testutil.InMemoryGenomeRepository
import com.novacompress.ai.testutil.TestSamples
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class EvolutionEngineTest {

    @Test
    fun `selecting a genome always returns a verified winner`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(1))

        val data = "evolution engine test data ".repeat(300).toByteArray()
        val selection = engine.selectGenomeForCompression(data)

        assertTrue(selection.benchmark.verified)
        assertTrue(selection.candidatesConsidered >= 1)
        assertTrue(selection.explanation.isNotBlank())
    }

    @Test
    fun `every benchmark run is persisted as knowledge, not just the winner`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(2))

        val data = TestSamples.randomBytes(5000, seed = 8)
        engine.selectGenomeForCompression(data)

        // The 3 known genomes are always benchmarked at minimum; mutation/crossover
        // usually add more; usually stays this way even in the rare case a mutated
        // candidate happens to collide with an already-known pipeline.
        assertTrue(repository.benchmarkCount() >= 3)
        assertTrue(repository.genomeCount() >= 3)
    }

    @Test
    fun `repeated selections keep discovering and accumulating genomes`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(3))

        val data = "repeated selection test ".repeat(200).toByteArray()
        repeat(5) { engine.selectGenomeForCompression(data) }

        // Each call benchmarks at least the 3 known genomes, guaranteed regardless of
        // whether any mutated/crossed candidate happens to collide with an existing
        // pipeline - so 5 calls guarantee at least 15 recorded benchmark experiments.
        assertTrue("expected accumulated benchmark knowledge, got ${repository.benchmarkCount()}", repository.benchmarkCount() >= 15)
        assertTrue(repository.genomeCount() >= 3)
    }

    @Test
    fun `works correctly across every sample including empty input`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(4))

        for ((label, data) in TestSamples.all()) {
            val selection = engine.selectGenomeForCompression(data)
            assertTrue("evolution engine failed to find a verified genome for sample $label", selection.benchmark.verified)
        }
    }

    @Test
    fun `selecting with a restricted allowedPluginIds set still returns a verified winner`() = runTest {
        // Smoke test for the Plugin Permissions plumbing at this layer; the
        // actual introduce-nothing-disallowed guarantee is MutationEngineTest's
        // job, since MutationEngine is where that filtering actually happens.
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(5))

        val data = "restricted plugin permissions test ".repeat(200).toByteArray()
        val selection = engine.selectGenomeForCompression(data, allowedPluginIds = setOf("delta", "rle"))

        assertTrue(selection.benchmark.verified)
        assertTrue(selection.candidatesConsidered >= 1)
    }
}
