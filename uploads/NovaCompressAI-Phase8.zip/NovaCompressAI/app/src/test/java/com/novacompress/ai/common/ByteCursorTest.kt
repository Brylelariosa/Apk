package com.novacompress.ai.common

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.ByteCursor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.IOException

class ByteCursorTest {

    @Test
    fun `reads round trip correctly for every primitive type`() {
        val out = ByteArrayOutputStream()
        BinaryIO.writeU32(out, 42)
        BinaryIO.writeLong(out, 123456789L)
        BinaryIO.writeDouble(out, 3.14)
        BinaryIO.writeString(out, "hello")
        BinaryIO.writeStringList(out, listOf("a", "bb", "ccc"))
        out.write(1) // boolean true

        val cursor = ByteCursor(out.toByteArray())
        assertEquals(42, cursor.readU32())
        assertEquals(123456789L, cursor.readLong())
        assertEquals(3.14, cursor.readDouble(), 0.0001)
        assertEquals("hello", cursor.readString())
        assertEquals(listOf("a", "bb", "ccc"), cursor.readStringList())
        assertEquals(true, cursor.readBoolean())
    }

    @Test
    fun `remaining reflects exactly how many bytes are left`() {
        val cursor = ByteCursor(ByteArray(10))
        assertEquals(10, cursor.remaining)
        cursor.readU32()
        assertEquals(6, cursor.remaining)
        cursor.readBytes(6)
        assertEquals(0, cursor.remaining)
    }

    @Test
    fun `readBytes rejects a length exceeding what actually remains, rather than allocating past the buffer`() {
        // Regression test: readBytes used to pass length straight into
        // copyOfRange with no check, which - for a length claiming more
        // bytes than the buffer actually has - allocates the destination
        // array before validating source bounds, risking an OutOfMemoryError
        // uncatchable by the archive/backup parsers' `catch (Exception)`
        // handling instead of a normal, expected parse failure.
        val cursor = ByteCursor(ByteArray(4))
        val ex = assertThrows(IOException::class.java) { cursor.readBytes(1_000_000_000) }
        assertEquals(true, ex.message?.contains("implausible") == true)
    }

    @Test
    fun `readBytes rejects a negative length`() {
        val cursor = ByteCursor(ByteArray(4))
        assertThrows(IOException::class.java) { cursor.readBytes(-1) }
    }

    @Test
    fun `readString rejects a corrupted length prefix instead of crashing`() {
        val out = ByteArrayOutputStream()
        BinaryIO.writeU32(out, Int.MAX_VALUE) // corrupted/adversarial length prefix, no bytes follow
        val cursor = ByteCursor(out.toByteArray())
        assertThrows(IOException::class.java) { cursor.readString() }
    }

    @Test
    fun `readStringList rejects a corrupted count instead of allocating a list sized from it`() {
        // Regression test: List(count) { ... } allocates its backing
        // storage for the full count immediately, before the lambda runs -
        // so a corrupted count is its own memory-exhaustion vector,
        // independent of each individual string's own length check.
        val out = ByteArrayOutputStream()
        BinaryIO.writeU32(out, Int.MAX_VALUE)
        val cursor = ByteCursor(out.toByteArray())
        assertThrows(IOException::class.java) { cursor.readStringList() }
    }

    @Test
    fun `an empty string list round trips correctly`() {
        val out = ByteArrayOutputStream()
        BinaryIO.writeStringList(out, emptyList())
        val cursor = ByteCursor(out.toByteArray())
        assertEquals(emptyList<String>(), cursor.readStringList())
    }

    @Test
    fun `startOffset positions the cursor correctly for reading a suffix of a larger buffer`() {
        val prefix = byteArrayOf(0, 0, 0, 0, 0)
        val out = ByteArrayOutputStream()
        BinaryIO.writeU32(out, 99)
        val combined = prefix + out.toByteArray()

        val cursor = ByteCursor(combined, startOffset = prefix.size)
        assertEquals(99, cursor.readU32())
    }
}
