package com.novacompress.ai.plugins.sdk

import com.novacompress.ai.core.plugins.CompressionPlugin
import com.novacompress.ai.core.plugins.PluginRegistry
import com.novacompress.ai.core.plugins.sdk.PluginCertifier
import com.novacompress.ai.core.plugins.sdk.PluginInfoRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** A plugin that silently corrupts its input - used only to prove PluginCertifier actually catches failures. */
private class BrokenPlugin : CompressionPlugin {
    override val id = "broken_test_plugin"
    override val displayName = "Broken (test only)"
    override val version = 1
    override fun compress(input: ByteArray): ByteArray = input
    override fun decompress(input: ByteArray): ByteArray =
        if (input.isEmpty()) input else ByteArray(input.size) { (input[it].toInt() + 1).toByte() } // corrupts every non-empty input
}

/** A plugin that throws instead of processing certain input. */
private class ThrowingPlugin : CompressionPlugin {
    override val id = "throwing_test_plugin"
    override val displayName = "Throwing (test only)"
    override val version = 1
    override fun compress(input: ByteArray): ByteArray {
        if (input.size > 100) throw RuntimeException("simulated failure on large input")
        return input
    }
    override fun decompress(input: ByteArray): ByteArray = input
}

class PluginCertifierTest {

    @Test
    fun `every real registered plugin passes certification`() {
        for (plugin in PluginRegistry.all()) {
            val result = PluginCertifier.certify(plugin)
            assertTrue("plugin ${plugin.id} failed certification: ${result.failedCases}", result.passed)
        }
    }

    @Test
    fun `PluginRegistry's own certification report shows every plugin passing`() {
        val report = PluginRegistry.certificationReport()
        assertEquals(8, report.size)
        assertTrue(report.all { it.passed })
    }

    @Test
    fun `certification correctly catches a plugin that corrupts round-trip output`() {
        val result = PluginCertifier.certify(BrokenPlugin())
        assertFalse(result.passed)
        assertTrue(result.failedCases.isNotEmpty())
    }

    @Test
    fun `certification correctly catches a plugin that throws on certain input`() {
        val result = PluginCertifier.certify(ThrowingPlugin())
        assertFalse(result.passed)
        assertTrue(result.failedCases.any { it.contains("random_large") })
    }

    @Test
    fun `every registered plugin has descriptive metadata in PluginInfoRegistry`() {
        for (plugin in PluginRegistry.all()) {
            val info = PluginInfoRegistry.get(plugin.id)
            assertTrue("missing PluginInfo for ${plugin.id}", info != null)
            assertEquals(plugin.id, info!!.id)
        }
    }
}
