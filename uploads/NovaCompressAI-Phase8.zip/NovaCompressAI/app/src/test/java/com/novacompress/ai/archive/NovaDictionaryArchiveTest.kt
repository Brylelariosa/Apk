package com.novacompress.ai.archive

import com.novacompress.ai.core.archive.DictionaryArchiveReadResult
import com.novacompress.ai.core.archive.NovaDictionaryArchiveReader
import com.novacompress.ai.core.archive.NovaDictionaryArchiveWriter
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class NovaDictionaryArchiveTest {

    @Test
    fun `round trips every shared sample with verification, including files smaller than the dictionary size`() {
        for ((label, data) in TestSamples.all()) {
            val archiveBytes = ByteArrayOutputStream().also { out ->
                NovaDictionaryArchiveWriter.write(
                    output = out,
                    openInput = { ByteArrayInputStream(data) },
                    originalFileName = "$label.bin",
                    originalSize = data.size.toLong(),
                    dictionarySize = 64,
                    chunkSize = 32
                )
            }.toByteArray()

            val recovered = ByteArrayOutputStream()
            val result = NovaDictionaryArchiveReader.readAndVerify(ByteArrayInputStream(archiveBytes), recovered)
            assertTrue("expected Success for sample $label but got $result", result is DictionaryArchiveReadResult.Success)
            assertArrayEquals("mismatch for sample $label", data, recovered.toByteArray())
        }
    }

    @Test
    fun `a file with a long-range repeated pattern spanning many chunks compresses better with a matching dictionary`() {
        val phrase = "NovaCompress AI dictionary section test phrase. "
        val data = phrase.repeat(2000).toByteArray()

        val withDictionary = ByteArrayOutputStream().also { out ->
            NovaDictionaryArchiveWriter.write(out, { ByteArrayInputStream(data) }, "x.bin", data.size.toLong(), dictionarySize = 4096, chunkSize = 1024)
        }.toByteArray()

        val withoutDictionary = ByteArrayOutputStream().also { out ->
            NovaDictionaryArchiveWriter.write(out, { ByteArrayInputStream(data) }, "x.bin", data.size.toLong(), dictionarySize = 0, chunkSize = 1024)
        }.toByteArray()

        assertTrue(
            "expected the dictionary to help on data with a long-range repeated pattern (with=${withDictionary.size}, without=${withoutDictionary.size})",
            withDictionary.size < withoutDictionary.size
        )

        val recovered = ByteArrayOutputStream()
        val result = NovaDictionaryArchiveReader.readAndVerify(ByteArrayInputStream(withDictionary), recovered)
        assertTrue(result is DictionaryArchiveReadResult.Success)
        assertArrayEquals(data, recovered.toByteArray())
    }

    @Test
    fun `metadata is preserved through the archive`() {
        val data = TestSamples.randomBytes(5000, seed = 91)
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaDictionaryArchiveWriter.write(out, { ByteArrayInputStream(data) }, "notes.bin", data.size.toLong(), dictionarySize = 512, chunkSize = 1024)
        }.toByteArray()

        val recovered = ByteArrayOutputStream()
        val result = NovaDictionaryArchiveReader.readAndVerify(ByteArrayInputStream(archiveBytes), recovered) as DictionaryArchiveReadResult.Success

        assertEquals("notes.bin", result.metadata.originalFileName)
        assertEquals(data.size.toLong(), result.metadata.originalSize)
        assertEquals(512, result.metadata.dictionarySize)
    }

    @Test
    fun `a single flipped byte anywhere in the archive is detected as corruption`() {
        val data = "dictionary corruption test data ".repeat(300).toByteArray()
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaDictionaryArchiveWriter.write(out, { ByteArrayInputStream(data) }, "corrupt.bin", data.size.toLong(), dictionarySize = 1024, chunkSize = 512)
        }.toByteArray()

        val mutable = archiveBytes.copyOf()
        val mid = mutable.size / 2
        mutable[mid] = (mutable[mid].toInt() xor 0xFF).toByte()

        val recovered = ByteArrayOutputStream()
        val result = NovaDictionaryArchiveReader.readAndVerify(ByteArrayInputStream(mutable), recovered)
        assertTrue(result is DictionaryArchiveReadResult.Corrupted)
    }

    @Test
    fun `progress callback fires once per chunk for both writing and reading`() {
        val data = TestSamples.randomBytes(1000, seed = 92)
        val writeCalls = mutableListOf<Pair<Int, Int>>()
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaDictionaryArchiveWriter.write(
                output = out,
                openInput = { ByteArrayInputStream(data) },
                originalFileName = "p.bin",
                originalSize = data.size.toLong(),
                dictionarySize = 128,
                chunkSize = 64,
                onChunkComplete = { done, total -> writeCalls.add(done to total) }
            )
        }.toByteArray()

        val expectedChunks = (data.size + 64 - 1) / 64
        assertEquals(expectedChunks, writeCalls.size)

        val readCalls = mutableListOf<Pair<Int, Int>>()
        val recovered = ByteArrayOutputStream()
        NovaDictionaryArchiveReader.readAndVerify(
            ByteArrayInputStream(archiveBytes),
            recovered,
            onChunkComplete = { done, total -> readCalls.add(done to total) }
        )
        assertEquals(expectedChunks, readCalls.size)
    }
}
