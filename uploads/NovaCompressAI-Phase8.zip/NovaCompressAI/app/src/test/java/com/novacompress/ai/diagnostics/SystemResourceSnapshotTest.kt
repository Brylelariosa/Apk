package com.novacompress.ai.diagnostics

import com.novacompress.ai.core.diagnostics.SystemResourceSnapshot
import org.junit.Assert.assertEquals
import org.junit.Test

class SystemResourceSnapshotTest {

    private fun snapshot(usedHeapBytes: Long, maxHeapBytes: Long) = SystemResourceSnapshot(
        usedHeapBytes = usedHeapBytes,
        maxHeapBytes = maxHeapBytes,
        nativeHeapAllocatedBytes = 0,
        activeThreadCount = 1
    )

    @Test
    fun `heap fraction is the simple ratio of used to max`() {
        assertEquals(0.5f, snapshot(usedHeapBytes = 50, maxHeapBytes = 100).heapUsedFraction, 0.0001f)
        assertEquals(0.25f, snapshot(usedHeapBytes = 25, maxHeapBytes = 100).heapUsedFraction, 0.0001f)
        assertEquals(1.0f, snapshot(usedHeapBytes = 100, maxHeapBytes = 100).heapUsedFraction, 0.0001f)
        assertEquals(0.0f, snapshot(usedHeapBytes = 0, maxHeapBytes = 100).heapUsedFraction, 0.0001f)
    }

    @Test
    fun `heap fraction is coerced to 1 even if used somehow exceeds max`() {
        // Shouldn't happen in practice, but a live JVM reading and a UI progress
        // bar should never disagree about what "full" means.
        assertEquals(1.0f, snapshot(usedHeapBytes = 150, maxHeapBytes = 100).heapUsedFraction, 0.0001f)
    }

    @Test
    fun `heap fraction is zero rather than a division error when max is zero or negative`() {
        assertEquals(0.0f, snapshot(usedHeapBytes = 10, maxHeapBytes = 0).heapUsedFraction, 0.0001f)
        assertEquals(0.0f, snapshot(usedHeapBytes = 10, maxHeapBytes = -1).heapUsedFraction, 0.0001f)
    }
}
