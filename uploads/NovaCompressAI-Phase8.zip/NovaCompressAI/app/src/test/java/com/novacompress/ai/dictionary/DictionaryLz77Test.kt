package com.novacompress.ai.dictionary

import com.novacompress.ai.core.dictionary.DictionaryLz77
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class DictionaryLz77Test {

    @Test
    fun `round trips correctly across a variety of dictionary and data combinations`() {
        val random = Random(81)
        val cases = listOf(
            Triple("no_dict_random", ByteArray(0), ByteArray(3000) { random.nextInt(256).toByte() }),
            Triple("empty_data", "some dictionary content here".toByteArray(), ByteArray(0)),
            Triple(
                "dict_helps_early_match",
                "The quick brown fox jumps over the lazy dog. ".toByteArray(),
                "The quick brown fox is fast.".toByteArray()
            ),
            Triple("repeated_with_dict", "ABCDEFGH".repeat(10).toByteArray(), "ABCDEFGH".repeat(500).toByteArray()),
            Triple(
                "random_with_random_dict",
                ByteArray(2000) { random.nextInt(256).toByte() },
                ByteArray(4000) { random.nextInt(256).toByte() }
            ),
            Triple("empty_dict", ByteArray(0), "the quick brown fox ".repeat(300).toByteArray()),
            Triple(
                "large_dict_small_data",
                "shared vocabulary words repeated many times. ".repeat(200).toByteArray(),
                "shared vocabulary!".toByteArray()
            )
        )

        for ((label, dictionary, data) in cases) {
            val encoded = DictionaryLz77.compress(dictionary, data)
            val decoded = DictionaryLz77.decompress(dictionary, encoded)
            assertArrayEquals("failed round trip for case: $label", data, decoded)
        }
    }

    @Test
    fun `a matching dictionary measurably improves compression over no dictionary`() {
        val dictionary = "The Nova Compress AI research platform explores compression strategies. ".repeat(5).toByteArray()
        val data = "The Nova Compress AI research platform is fully offline.".toByteArray()

        val withDict = DictionaryLz77.compress(dictionary, data)
        val withoutDict = DictionaryLz77.compress(ByteArray(0), data)

        assertTrue(
            "expected the matching dictionary to measurably help (with=${withDict.size}, without=${withoutDict.size})",
            withDict.size < withoutDict.size
        )
        assertArrayEquals(data, DictionaryLz77.decompress(dictionary, withDict))
        assertArrayEquals(data, DictionaryLz77.decompress(ByteArray(0), withoutDict))
    }

    @Test
    fun `overlapping self-referential copies against the dictionary boundary round trip correctly`() {
        val dictionary = ByteArray(50) { 'z'.code.toByte() }
        val data = ByteArray(500) { 'z'.code.toByte() }
        val encoded = DictionaryLz77.compress(dictionary, data)
        assertArrayEquals(data, DictionaryLz77.decompress(dictionary, encoded))
    }

    @Test
    fun `decompress rejects a dictionary length that does not match what the stream expects`() {
        val dictionary = "correct dictionary".toByteArray()
        val data = TestSamples.randomBytes(200, seed = 4)
        val encoded = DictionaryLz77.compress(dictionary, data)

        assertThrows(IllegalArgumentException::class.java) {
            DictionaryLz77.decompress("a different dictionary entirely".toByteArray(), encoded)
        }
    }

    @Test
    fun `round trips correctly across every shared TestSamples case with a fixed dictionary`() {
        val dictionary = "a reasonably sized shared dictionary for testing purposes. ".repeat(10).toByteArray()
        for ((label, data) in TestSamples.all()) {
            val encoded = DictionaryLz77.compress(dictionary, data)
            val decoded = DictionaryLz77.decompress(dictionary, encoded)
            assertArrayEquals("failed for sample: $label", data, decoded)
        }
    }
}
