# NovaCompress AI — Phase Progress

Tracking status against the full multi-part master spec. Each phase is only
marked done when it is fully generated, internally reviewed, and (where
this sandbox allows) tested — never partially.

## Phase 1 — Core Engine & Minimal Working App — ✅ DONE

- File Analyzer (entropy, histogram, run-length score, repeated-block score)
- 4 compression plugins: Delta, RLE, Huffman, LZ77 (all Python-prototyped
  and round-trip-tested before porting to Kotlin)
- Pipeline engine (chains plugins, reverses correctly)
- 4 hand-crafted genome presets + heuristic selector (behind a
  `GenomeSelector` interface so Phase 2's real Evolution Engine slots in
  without touching callers)
- Verification Engine enforcing compress→decompress→compare→SHA-256 before
  any chunk is trusted
- Full streaming, chunked `.nova` archive format v1 with per-chunk and
  whole-file SHA-256, corruption detection, truncation detection
- Room database for compression history; Dashboard/Compress/Decompress/
  Settings Compose screens
- JUnit tests covering every plugin, pipeline combination, and the archive
  format (including deliberate corruption injection); GitHub Actions CI
  workflow (regenerates the Gradle wrapper, runs tests, assembles a debug
  APK). See the Phase 2 entry below for the corrected, accurate test count.

## Phase 2 — Genome Evolution & Real Benchmark Laboratory — ✅ DONE

- **Real Benchmark Laboratory**: every candidate genome is actually
  compressed, decompressed, timed (`System.nanoTime()`), and verified
  against the real file sample - no estimates, no guessing.
- **Real Evolution Engine**: `MutationEngine` (insert/delete/swap/replace,
  always producing a structurally valid, duplicate-free pipeline) and
  `CrossoverEngine` (single-point recombination of two parent pipelines,
  de-duplicated). Every compression job benchmarks the best 3 known
  genomes plus a fresh mutation and a fresh crossover child, records
  *every* result as knowledge (win or lose), and picks the genuinely
  measured winner.
- **Multidimensional fitness**: `FitnessCalculator` combines ratio with a
  speed penalty, matching the spec's "Compression Ratio x ... x Reliability
  x ... x Battery Score" idea in a simplified, explainable form.
- **Knowledge Database expansion**: new `genomes` and `benchmark_records`
  Room tables. Genomes carry generation, species (classified from which
  plugins they use), lifecycle status (Experimental -> Verified -> Stable
  -> Elite -> Retired), and parent lineage.
- **Fixed a real spec-compliance gap while building this**: the master
  spec explicitly requires rejecting duplicate-plugin pipelines during
  validation, which Phase 1 hadn't enforced. Added the check to
  `PipelineDescriptor`, which required corresponding fixes to
  `MutationEngine` (only insert/replace with an unused plugin) and
  `CrossoverEngine` (de-duplicate overlapping parent plugins) so neither
  could ever attempt to construct an invalid pipeline.
- **New plugin**: Move-To-Front (Python-prototyped and round-trip-tested
  first, like every other plugin). Burrows-Wheeler Transform, Arithmetic
  Coding, and Predictive Coding are deliberately deferred - see the Phase 3
  note below for why.
- **Dashboard now shows real population growth**: "Genomes Discovered" and
  "Benchmarks Run" stat cards, reactively observed from Room.
- `EvolutionEngine`'s logic is tested against an `InMemoryGenomeRepository`
  fake (Room's SQLite backing doesn't work in plain JVM unit tests without
  Robolectric, and the evolutionary logic has nothing to do with SQL) - the
  production `RoomGenomeRepository` implements the same interface.
- 20 net new test methods this phase (19 in new Phase 2 test files, plus 1
  added to Phase 1's `CompressionPipelineTest` for the duplicate-rejection
  fix above) - 50 test methods total across the project now. Phase 1's
  chat summary said 68, which was a miscount; 50 is the accurate, verified
  number, and many methods loop over 14 shared samples internally rather
  than being one-scenario-per-method.

## Phase 3 — More Plugins, Research Dashboard & Visualization — ✅ DONE

- **Burrows-Wheeler Transform**: built the way it deserved - a suffix array
  of the cyclic rotations via prefix-doubling (no sentinel byte needed,
  since every byte value 0-255 is already valid input), cross-validated
  byte-for-byte against a brute-force textbook reference implementation
  across 509 small inputs before being ported to Kotlin, then round-trip
  tested on periodic/large/random data. Paired with Move-To-Front into a
  new "Block Sorting" genome preset (the classic bzip2-style pipeline).
- **Arithmetic Coding**: classic Witten-Neal-Cleary integer coder with
  E1/E2/E3 underflow handling. Stress-tested in Python across 300 random
  alphabet-size/length combinations before porting; the Kotlin port uses
  `Long` throughout since intermediate products reach ~2^50 and would
  overflow a 32-bit `Int`. Powers a new "Research Mode" preset.
  "Bit Packing" (a separate catalog entry in the spec, for densely packing
  known-small-range values) is still deferred - it wasn't needed for any
  plugin built so far and deserves its own use case to design around
  rather than being added speculatively.
- **Predictive Coding**: a second-order linear predictor, genuinely
  different from Delta's first-order approach (handles linear trends -
  sensor readings, audio envelopes - rather than just slowly-changing
  values; confirmed empirically that it zeros out 767/768 residuals on a
  clean linear ramp). Powers a new "Signal Optimized" preset.
- **8 plugins registered now**: Delta, RLE, Huffman, LZ77, MTF, BWT,
  Arithmetic, Predictive. 7 genome presets seed the population.
- **Research Lab screen** (5th bottom-nav destination): Species breakdown
  with a real (if simple, dependency-free) bar chart built from proportional
  Compose boxes, and a Genome Explorer list (sorted by fitness, tap to
  expand for rationale + parent lineage), reactively observed from Room.
- **Archive Inspector**: `NovaArchiveInspector.peek()` reads just the magic
  header + metadata block of a `.nova` file - original filename/size,
  pipeline, chunk count - without touching any chunk data or verifying
  hashes. Wired into the Decompress screen as an "Inspect Archive" button
  before committing to a full decompress.
- 17 new test methods (67 total now), including a from-scratch
  brute-force BWT reference implementation used only in tests, and a
  150-configuration arithmetic-coding stress test mirroring the Python
  prototype's validation methodology.
- What's *not* here: the full Evolution Timeline / Mutation Viewer /
  AI Brain Visualization / interactive zoomable charts from the spec's UI
  parts - those are meaningful polish, not core functionality, and fit
  better in Phase 7 (Developer Mode) once there's more benchmark history
  to visualize meaningfully.

## Phase 4 — Android Runtime Maturity — ✅ DONE

- **Battery/Thermal/Memory awareness**: real Android-backed providers
  (`BatteryManager.BATTERY_PROPERTY_STATUS`/`_CAPACITY`,
  `PowerManager.currentThermalStatus` with a graceful pre-API-29
  fallback, `ActivityManager.MemoryInfo.lowMemory`) feeding a pure-Kotlin
  `ResearchScheduler` that decides whether background research may run
  right now - fully unit tested against fake providers.
- **Real background research via WorkManager**: a periodic
  `BackgroundResearchWorker` (charging + battery-not-low as WorkManager's
  own constraints, thermal/memory re-checked inside `doWork` since
  WorkManager has no built-in constraint for either) runs
  `BackgroundResearchRunner` against synthetic samples (random/repetitive/
  text-like/structured byte patterns - there's no real user file to
  research against between compression jobs) through the same
  `EvolutionEngine` a live compression job uses. Reactively enqueued/
  cancelled based on a DataStore-backed "Background Learning" toggle in
  Settings (the first setting that actually controls something).
- **Fixed an unbounded-growth bug caught during review**: background
  research running every 6 hours forever, with nothing capping the
  Knowledge Database, would have grown storage indefinitely - directly
  contradicting the spec's own explicit "Knowledge database Maximum 128 MB"
  and "Population: Normal 500 genomes" limits. Added
  `KnowledgeMaintenanceService`, run as part of every background research
  pass: prunes benchmark records older than 30 days, retires (not deletes -
  matching the spec's "not deleted immediately... move to Archive")
  the weakest genomes beyond the 500-genome cap, and runs `VACUUM` if the
  database file is still over 128 MB after pruning.
- 9 new test methods for `ResearchScheduler` and the background research
  pass logic (76 total now). `KnowledgeMaintenanceService` itself isn't
  directly unit tested - like `RoomGenomeRepository`, it's a thin,
  carefully-reviewed wrapper over a few individually-simple Room queries
  (deliberately avoiding one complex correlated-subquery UPDATE in favor of
  three obviously-correct ones) rather than logic dense enough to warrant
  its own interface+fake abstraction.
- Hilt is still deferred - `BackgroundResearchWorker` reaches
  `ServiceLocator` via an `applicationContext` cast rather than
  constructor injection, which works fine for one Worker with no
  constructor dependencies of its own.

## Phase 5 — Checkpointing & Progress Reporting — ✅ DONE (partial Phase 5)

- **Checkpoint/resume for interrupted compression**, carried forward from
  Phase 4 as promised: `CompressionCheckpointStore` persists progress
  (as simple `java.util.Properties` key-value files - plain JVM, so no
  Android-testing stubbing gotchas) after every chunk. `NovaArchiveResumer`
  - deliberately a *separate* object from `NovaArchiveWriter` rather than a
  refactor of its chunk loop, specifically to avoid any risk of regressing
  the already-thoroughly-validated writer - re-hashes (never
  re-compresses) the already-completed portion to catch the running
  whole-file SHA-256 digest up to where it left off (a `MessageDigest`'s
  internal state can't portably survive a process restart the way its
  already-produced compressed bytes can), then continues from the exact
  next chunk. Tested by constructing genuinely truncated partial archives
  (parsing a complete archive up to a chunk boundary, not trusting
  resume() to agree with itself about where chunks end) and confirming the
  resumed result is byte-for-byte identical to an uninterrupted write, at
  three different interruption points (early/middle, from-scratch, and
  all-but-the-last-chunk), plus full `CompressionService`-level tests that
  simulate a crash and confirm a retry with the same file is correctly
  detected and resumed (or correctly ignored when the file doesn't match).
- **Fixed an interaction bug caught during review**: `TempFileJanitor`
  (Phase 4's orphaned-temp-file cleanup) would have silently deleted a
  legitimately-resumable checkpoint's temp file if the user hadn't
  retried within an hour, quietly breaking the resume feature. Fixed by
  skipping any temp file that has a matching `.checkpoint` companion.
- **Real progress reporting**: `NovaArchiveWriter`/`NovaArchiveReader` both
  gained an optional `onChunkComplete` callback (purely additive - no
  change to existing control flow or verification logic), plumbed through
  to the Compress/Decompress screens as an actual determinate progress bar
  with a live chunk counter, replacing the indeterminate spinner.
- 13 new test methods (89 total now).
- **Still deferred from the full Phase 5 scope** (multi-file archives,
  dictionary section, archive repair mode, `.nova-backup` export/import,
  R8/minification with real keep rules): R8 specifically was reconsidered
  and *not* rushed here - enabling it changes release-build behavior in
  ways this sandbox can't runtime-verify (CI only builds/tests the debug
  variant so far), and getting keep rules wrong for Room/reflection-based
  code would be an invisible-until-a-real-device runtime failure. Continuing
  these in Phase 6.

## Phase 6 — Archive Format Completion & Release Hardening — ✅ DONE (partial Phase 6)

- **R8/minification enabled for release builds**, with real, deliberately
  broad keep rules (Room's data/database package, WorkManager's
  reflectively-instantiated Worker constructor, the plugin/genome/archive
  packages) rather than aggressive shrinking - a wrong keep rule here is a
  runtime crash this sandbox has no way to catch (no device/emulator to
  actually install and run the shrunk APK on). CI now also builds
  `assembleRelease`, which at least catches build-time shrinking mistakes.
- **Archive Repair Mode**: `NovaArchiveRepairer` attempts best-effort
  recovery of a corrupted `.nova` file - salvages whichever chunks still
  pass their own hash check, zero-fills unrecoverable ones to preserve
  overall byte layout, and reports exactly what could and couldn't be
  recovered. Honest about its real limit: chunks are stored inline (each
  preceded by its own size field, not behind an independent chunk
  directory), so recovery can only continue past a damaged chunk if that
  chunk's *size field* is still intact; if a size field itself is
  corrupted, nothing after it is locatable, and the report says exactly
  where that happened rather than guessing. Wired into the Decompress
  screen as a "Try to Repair" fallback after a normal decompress fails.
- **Knowledge Export/Import** (`.nova-backup`): `KnowledgeBackupCodec`
  (same length-prefixed-field approach as archive metadata, no JSON) plus
  `KnowledgeBackupService`, which merges on import - existing genomes are
  never overwritten (matched by their natural `genomeId`), and duplicate
  benchmark records are skipped via a `(genomeId, timestamp)` check since
  they have no natural key of their own. Wired into Settings via
  Storage-Access-Framework export/import buttons.
- **External intents restored**: "Share to compress" (`ACTION_SEND`,
  pre-fills the Compress screen with the shared file) and "Open with"
  for `.nova` files (`ACTION_VIEW`, pre-fills Decompress) - removed from
  Phase 1's manifest specifically until the handling code existed; it now
  does, via a `LaunchIntent` resolved once in `MainActivity` and consumed
  exactly once by the relevant screen so navigating back to it later never
  re-triggers auto-selection.
- 24 new test methods (100 total now): repairer tests construct genuine
  structural corruption (a garbled size field, not just flipped content
  bytes) and confirm the report distinguishes "chunk content corrupted"
  from "couldn't even find where the next chunk starts"; the backup codec
  is round-trip tested including truncated/garbage-input rejection.
- **Still deferred**: multi-file archives (folder trees, independent
  per-file chunk tables) and the dictionary section (shared/preset
  dictionaries for LZ77-family plugins) - both are genuine archive-*format*
  changes, not additive features like everything else in this phase, and
  deserve a dedicated pass rather than being squeezed in. Continuing in
  Phase 7.

## Phase 7 — Multi-File Archives, Dictionary Section & Plugin SDK — ✅ DONE

- **Formal Plugin SDK groundwork**: `PluginInfo`/`PluginInfoRegistry` adds
  the spec's descriptive plugin metadata (author, category, thread-safety,
  streaming support) without touching the `CompressionPlugin` interface or
  any of the 8 existing plugin classes. `PluginCertifier` runs every
  registered plugin through a standard corpus (empty/tiny/random/repeated/
  binary/all-256-values/corrupted-looking input) at startup and excludes
  any plugin that fails even one case from the active set - a real,
  automatic version of the spec's "Automatic Plugin Testing: if any test
  fails, plugin becomes disabled," not just a development-time test suite.
  Verified the safety net actually works (not just that it always passes)
  with two deliberately-broken fake plugins in tests.
- **Dictionary Section**: `DictionaryLz77` - a preset dictionary
  conceptually precedes the input in the match-search buffer, seeded into
  the hash chains before any input byte is processed, so even the first
  bytes of a chunk can reference patterns already established in the
  dictionary. Validated in Python first (including confirming the
  dictionary measurably helps: 31 bytes vs 71 for matching content) before
  porting. Wired into a new, self-contained `NovaDictionaryArchiveWriter`/
  `Reader` (own magic bytes `NVAD`, own format) that derives the
  dictionary from the first bytes of the file and applies it to every
  chunk - solving a real limitation of the standard format, where chunks
  are compressed fully independently and can never reference patterns
  across a chunk boundary. Full genome/Evolution-Engine integration is
  intentionally out of scope (a dictionary is a third parameter that
  doesn't fit the plain `CompressionPlugin.compress(ByteArray)` contract
  every other plugin uses).
- **Multi-file archives**: `NovaMultiFileArchiveWriter`/`Reader` (own magic
  bytes `NVAM`, own format) - independent per-file chunk tables and
  whole-file SHA-256, so one damaged file never prevents reading the
  others; an overall archive hash over all per-file hashes catches
  tampering with the file list itself. All files in one archive currently
  share a single genome/pipeline rather than the spec's per-file optimized
  pipelines - a reasonable, clearly-labeled future enhancement rather than
  added scope here.
- **Why these three are separate formats, not extensions of the existing
  one**: this project's archive metadata is simple length-prefixed
  sequential fields with no format-versioning story for safely adding a
  new optional field - old archives would be unsafe to read with a newer
  decoder expecting a field that isn't there. A genuinely new shape gets a
  genuinely new, independently-versioned format instead of risking the
  already-validated single-file writer/reader that every existing archive
  depends on.
- 20 new test methods (120 total now).
- **Rebuilt from a sandbox reset**: this phase was fully built once, lost
  when the sandbox environment reset mid-session (see the note in the
  chat), and rebuilt faithfully from the same design and the same
  Python-validation methodology rather than skipped or shortcut.

## Phase 8 — Developer Mode & Polish — ✅ DONE

- **Live thread/memory monitor**: `SystemResourceProvider`/`AndroidSystemResourceProvider`
  reads real JVM heap usage (`Runtime`), native heap allocation
  (`Debug.getNativeHeapAllocatedSize`), and active thread count
  (`Thread.activeCount`). `DeveloperViewModel` polls it every second, but
  only while Developer Mode is actually on screen (`stateIn(WhileSubscribed(5s))`)
  - it never drains battery in the background.
- **Genome/Pipeline/Plugin/Database inspectors**: `DeveloperStatsRepository`
  exposes Knowledge Database usage (active/retired genome counts,
  benchmark count, live `.db` file size) against the spec's own caps from
  `KnowledgeMaintenanceService`, plus a full plugin certification report
  (including any plugin that *failed* certification, which
  `PluginRegistry` otherwise silently excludes - exactly the kind of thing
  an advanced user's diagnostic screen should surface). The Genome
  Inspector reuses Research's `GenomeSummary` but with a new `pluginIds`
  field so each genome's pipeline can be expanded stage-by-stage, showing
  each plugin's category, thread-safety, and streaming support.
- **Full Settings categories - each wired to a real subsystem**:
  - *Research Budget*: how often (3h/6h/12h/24h) `BackgroundResearchWorker`
    runs, via `BackgroundResearchScheduler.enable(context, intervalHours)`
    and `ExistingPeriodicWorkPolicy.UPDATE` so changing it reschedules the
    existing job rather than duplicating it.
  - *Thermal & Battery Limits*: minimum battery percent feeds
    `ResearchScheduler`'s existing constructor parameter; thermal
    sensitivity (Light/Moderate/Severe) is a new `minThrottleLevel`
    parameter on `AndroidThermalStatusProvider`, both previously hardcoded.
  - *Plugin Permissions*: `SettingsRepository.disabledPluginIds` restricts
    which plugins `MutationEngine.mutate` may introduce into *newly
    discovered* genomes (an additive `allowedPluginIds: Set<String>? = null`
    parameter, threaded through `EvolutionEngine`, `BackgroundResearchRunner`,
    and `CompressionService` with every existing call site and test
    untouched via the `null` default). Deliberately scoped to future
    mutations only, not a global plugin kill-switch: disabling a plugin at
    decompression time would break reading archives already compressed
    with it, so `PluginRegistry.get()` - used by decompression - is never
    affected by this setting. The Settings screen says this explicitly
    rather than leaving it to be discovered the hard way.
- **Developer Mode is reached from Settings, not the bottom nav bar** -
  like Android's own hidden-behind-Settings Developer Options, this is
  advanced-user surface that would otherwise crowd Material 3's
  recommended max of 5 destinations and put diagnostic clutter in front of
  the beginner users the spec explicitly wants to "easily compress files."
- **Responsive layout**: Developer Mode's System Monitor and Database
  cards lay out side-by-side on screens ≥600dp wide (`BoxWithConstraints`),
  stacked otherwise. **Still deferred**: a full per-screen tablet/landscape
  pass across Dashboard/Compress/Decompress/Research - a real, scoped
  future improvement rather than a claim this phase doesn't back up.
- **Accessibility**: content descriptions on the Developer Mode back
  button and capacity bars (via `Modifier.semantics`); Material 3's
  built-in components (`Switch`, `FilterChip`, `Slider`) already meet the
  48dp touch-target minimum by default.
- 13 new test methods (133 total now): `MutationEngine`'s
  `allowedPluginIds` filtering (restriction is respected, never forces
  removal of a plugin already in the pipeline, degrades to an unchanged
  pipeline rather than crashing when every unused plugin is disallowed),
  an `EvolutionEngine`-level smoke test that a restricted set doesn't
  break selection, a `BackgroundResearchRunner` passthrough test, and pure
  fraction-math tests for `SystemResourceSnapshot.heapUsedFraction` and
  `DatabaseUsageSnapshot`'s two capacity fractions (normal ratios,
  over-cap coercion to 1.0, division-by-zero safety).
- **Rebuilt from a sandbox reset**: like Phase 7, this phase's data layer
  was interrupted by a sandbox reset mid-session and resumed from scratch
  in a later session rather than assumed complete; the Phase 7 zip that
  had already been sent for a CI build was fixed first (`NovaArchiveRepairer.kt`
  had a `val` assigned across both a `try` and `catch` branch, which
  Kotlin's definite-assignment analysis rejects - rewritten as a single
  `val` assigned once from an if/try expression) before any Phase 8 work
  continued, so the foundation Phase 8 builds on is confirmed working, not
  assumed working.
