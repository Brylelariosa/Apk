# NovaCompress AI — Phases 1-8

A real, working, buildable Android app implementing the large majority of
the NovaCompress AI spec: the compression engine, a genuinely working
genome Evolution Engine + Benchmark Laboratory, eight compression plugins,
thermal/battery/memory-aware background research, checkpoint/resume,
archive repair mode, knowledge export/import, external app integration,
a dictionary section, multi-file archives, an automatic plugin
certification system, and a Developer Mode with live diagnostics. See
[PROGRESS.md](PROGRESS.md) for the full phase-by-phase breakdown of what's
here vs. what's still deliberately deferred.

## What actually works right now

**Compression engine**
- Eight real, lossless plugins: Delta, Run-Length Encoding, Huffman,
  LZ77, Move-To-Front, Burrows-Wheeler Transform (suffix array via
  prefix-doubling, no sentinel byte - cross-validated byte-for-byte
  against a brute-force reference implementation), Arithmetic Coding
  (Witten-Neal-Cleary, stress-tested across 300 configurations), and
  Predictive Coding (second-order linear predictor). Every plugin was
  prototyped and round-trip-tested in Python before being ported to
  Kotlin.
- **Automatic plugin certification**: every registered plugin is run
  against a standard corpus at startup and excluded from use if it fails
  even one case - a real, automatic safety net, not just a development-time
  test suite (verified against two deliberately-broken fake plugins to
  confirm it actually catches failures, not just that it always passes).
- Seven genome presets, a pipeline engine that chains plugins and rejects
  invalid combinations (empty, over the 16-stage limit, unknown plugin, or
  duplicate plugins).

**Archive formats**
- The standard chunked, streaming `.nova` format with per-chunk and
  whole-file SHA-256 verification.
- **Archive Inspector** (metadata without decompressing) and **Archive
  Repair Mode** (best-effort partial recovery with an honest, stated limit
  on what's actually recoverable).
- **Checkpoint/resume**: retrying a file after a crash resumes from the
  last completed chunk instead of starting over.
- **Dictionary Section**: a self-contained archive variant where a
  dictionary derived from the start of the file is shared across every
  chunk's LZ77 pass, letting later chunks reference patterns established
  early in the file - solving a real limitation of the standard format,
  where chunks compress fully independently.
- **Multi-file archives**: a self-contained format with independent
  per-file chunk tables and verification, so one damaged file never
  prevents reading the others.
- Real progress reporting (determinate progress bars) for compress and
  decompress.

**The AI core**
- A real Benchmark Laboratory and Evolution Engine (mutation + crossover,
  both guaranteed to produce structurally valid, duplicate-free
  pipelines) - every compression job benchmarks real candidates against
  real data and picks the genuinely measured winner.
- A Knowledge Database whose growth is actually bounded (128 MB / ~500
  active genomes, matching the spec's own stated limits).
- Thermal/battery/memory-aware background research via WorkManager, and
  Knowledge Export/Import (`.nova-backup`) that merges without overwriting.

**Android app**
- Seven Compose screens (Dashboard, Compress, Decompress, Research,
  History, Settings, Developer Mode), "Share to compress" / "Open with"
  for `.nova` files, R8-minified release builds with real keep rules.
- **133 JUnit test methods**, including a from-scratch brute-force BWT
  reference implementation, a 150-configuration arithmetic-coding stress
  test, genuinely-truncated-archive resume/repair tests, and dedicated
  round-trip + corruption tests for both new archive formats.

**Developer Mode**
- Live thread/memory monitor (real JVM heap + native heap + thread count,
  polled every second, only while the screen is visible).
- Genome/Pipeline/Plugin/Database inspectors: Knowledge Database usage
  against the spec's own caps, per-genome pipeline stage breakdown, and a
  full plugin certification report (including plugins that *failed*
  certification, which are otherwise silently excluded from use).
- Full Settings surface - Research Budget (background research interval),
  Thermal & Battery Limits, and Plugin Permissions - every control wired
  to a real subsystem, never a dead switch. Plugin Permissions is
  deliberately scoped to restrict only *future* AI-discovered pipelines;
  it can never break decompression of archives already created with a
  since-disabled plugin.

## What's deliberately not here yet

Per-file optimized pipelines within a multi-file archive (all files
currently share one pipeline), a full per-screen tablet/landscape pass
(Developer Mode alone gets a responsive two-column layout on wide
screens), a full accessibility audit (some real content-description/
semantics work is in, but not comprehensively swept), dynamically-loaded
third-party plugins with sandboxing, Hilt, and the spec's more elaborate
visualizations (AI Brain Visualization, Mutation Timeline animations,
zoomable interactive charts). See PROGRESS.md.

## About the Gradle Wrapper

The build environment for this project is GitHub Actions, per the project's
own build instructions. The sandbox this project was generated in has **no
network access and no local Gradle/Android SDK/Kotlin compiler** — so a
`gradle-wrapper.jar` binary (normally produced by running `gradle wrapper`
against a real Gradle install) could not be generated or verified here.

Rather than commit a guessed-at binary that might be silently wrong, the
CI workflow (`.github/workflows/android-ci.yml`) installs a real Gradle
distribution first and runs `gradle wrapper --gradle-version 8.6` as its
first step, regenerating `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar`
before anything else runs.

## Verified version matrix

| Component | Version |
|---|---|
| Gradle | 8.6 (per the project's own pinned target) |
| Android Gradle Plugin | 8.4.0 |
| Kotlin | 1.9.24 |
| Compose Compiler extension | 1.5.14 |
| KSP | 1.9.24-1.0.20 |
| compileSdk / targetSdk | 34 |
| minSdk | 26 (Android 8.0) |

As of mid-2026 the ecosystem has moved on to Gradle 9.x / AGP 9.x. This
project deliberately stays on the version matrix the project's own build
spec pinned rather than jumping to the newer major versions.

## Building

```bash
gradle wrapper --gradle-version 8.6   # one-time, if gradlew isn't already valid
./gradlew testDebugUnitTest             # run the 133 unit tests
./gradlew assembleDebug                 # produce app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease               # produce the minified release APK (unsigned)
```

Or push to GitHub and let `.github/workflows/android-ci.yml` build it.

## Project layout

```
app/src/main/java/com/novacompress/ai/
  core/
    analyzer/     FileAnalyzer, FeatureVector
    plugins/      8 CompressionPlugin implementations + PluginRegistry
      sdk/        PluginInfo/PluginInfoRegistry, PluginCertifier
    pipeline/     PipelineDescriptor, CompressionPipeline
    genome/       CompressionGenome, GenomeStatus, GenomePresets, GenomeSelector
    verification/ VerificationEngine
    archive/      Standard/Dictionary/MultiFile writers+readers, Resumer, Repairer, Inspector
    dictionary/   DictionaryLz77
    benchmark/    BenchmarkLaboratory, BenchmarkResult, FitnessCalculator
    evolution/    EvolutionEngine, MutationEngine, CrossoverEngine, GenomeRepository (interface)
    scheduler/    Battery/Thermal/Memory status providers, ResearchScheduler
    diagnostics/  SystemResourceProvider (live heap/thread snapshot for Developer Mode)
    backup/       KnowledgeBackupCodec, backup data records
    service/      CompressionService, DecompressionService, ArchiveRepairService, checkpointing
    common/       Constants, EngineResult, BinaryIO, ByteCursor
  data/           Room database (history + genomes + benchmarks), DAOs, repositories
  di/             ServiceLocator + ViewModel factory (no Hilt yet, see below)
  work/           BackgroundResearchWorker + scheduler
  ui/             Compose screens + ViewModels (including developer/ for Developer Mode)
app/src/test/java/com/novacompress/ai/   133 JUnit tests mirroring the above
```

## Notable engineering decisions

- **Three archive formats, not one extended format.** The standard
  single-file `.nova` format, the dictionary-enabled variant, and the
  multi-file variant each have their own magic bytes and are read/written
  by entirely separate code. This project's archive metadata is simple
  length-prefixed sequential fields with no format-versioning story for
  safely adding a new optional field to an existing shape - old archives
  would be unsafe to read with a newer decoder expecting a field that
  isn't there. A genuinely new shape gets a genuinely new, independently-
  versioned format instead of risking the already-validated writers/
  readers every existing archive depends on. Same reasoning applies to
  `NovaArchiveResumer` and `NovaArchiveRepairer` being separate from
  `NovaArchiveWriter`/`Reader`.
- **Plugin certification is a real startup safety net, not just tests.**
  `PluginCertifier` runs the standard corpus against every registered
  plugin every time the app starts, and a plugin that fails even one case
  is excluded from the active set - verified with deliberately-broken fake
  plugins in tests to confirm it actually catches failures.
- **Checkpoints and backups are plain `java.util.Properties` / custom
  binary, never JSON or SharedPreferences** - both have Android-testing
  gotchas (`org.json` throws "not mocked" in plain JVM unit tests;
  SharedPreferences is framework-stubbed), while these are plain JVM and
  behave identically in tests and production.
- **R8 keep rules are deliberately broad**, not minimal - a wrong keep
  rule is a runtime crash this sandbox cannot detect (no device/emulator
  to install the shrunk APK on).
- **`GenomeRepository` is an interface** specifically so `EvolutionEngine`'s
  logic is unit-testable against an in-memory fake instead of requiring
  Room's real SQLite backing, which doesn't work in plain JVM unit tests
  without Robolectric.
- **The Knowledge Database's growth is actively bounded** - background
  research runs every 6 hours indefinitely, so old benchmark records are
  pruned and weak genomes retired (never deleted) beyond a population cap.
- **No Hilt yet.** `ServiceLocator` is a plain Kotlin class;
  `BackgroundResearchWorker` reaches it via a plain `applicationContext`
  cast, which is fine for one Worker with no constructor dependencies of
  its own.
- **Plugin Permissions restricts future mutations only, never decompression.**
  Disabling a plugin in Settings only stops `MutationEngine` from
  introducing it into newly-discovered genomes going forward
  (`allowedPluginIds`, threaded through as an additive optional parameter
  everywhere it matters). `PluginRegistry.get()` - the lookup decompression
  actually depends on - is never affected, because a plugin being
  administratively out of favor for new research must never make an
  already-written `.nova` archive unreadable.

## A note on this build's history

This project was built across a long session with two sandbox environment
resets that wiped the in-progress working directory (not durable output
storage). Both times, the affected phase was rebuilt faithfully from the
same design and validation methodology rather than skipped or shortcut -
see PROGRESS.md for exactly which phase and what was re-verified. Safety
checkpoints are now saved to durable storage periodically during long
builds specifically to make any future reset cheap to recover from.
