package com.bryle.videoframes

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private var selectedUri: Uri? = null
    private var videoDurationMs: Long = 0L
    private var extractionJob: Job? = null

    private lateinit var btnSelect: Button
    private lateinit var tvName: TextView
    private lateinit var tvInfo: TextView
    private lateinit var etFps: EditText
    private lateinit var tvFpsHint: TextView
    private lateinit var tvEstimate: TextView
    private lateinit var btnExtract: Button
    private lateinit var btnCancel: Button
    private lateinit var cardProgress: View
    private lateinit var progressBar: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvEta: TextView
    private lateinit var tvStatus: TextView
    private lateinit var cardOutput: View
    private lateinit var tvOutputPath: TextView
    private lateinit var btnCopyPath: Button

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedUri = uri
        loadVideoInfo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSelect    = findViewById(R.id.btnSelect)
        tvName       = findViewById(R.id.tvName)
        tvInfo       = findViewById(R.id.tvInfo)
        etFps        = findViewById(R.id.etFps)
        tvFpsHint    = findViewById(R.id.tvFpsHint)
        tvEstimate   = findViewById(R.id.tvEstimate)
        btnExtract   = findViewById(R.id.btnExtract)
        btnCancel    = findViewById(R.id.btnCancel)
        cardProgress = findViewById(R.id.cardProgress)
        progressBar  = findViewById(R.id.progressBar)
        tvProgress   = findViewById(R.id.tvProgress)
        tvEta        = findViewById(R.id.tvEta)
        tvStatus     = findViewById(R.id.tvStatus)
        cardOutput   = findViewById(R.id.cardOutput)
        tvOutputPath = findViewById(R.id.tvOutputPath)
        btnCopyPath  = findViewById(R.id.btnCopyPath)

        btnSelect.setOnClickListener { pickVideo.launch("video/*") }
        btnExtract.setOnClickListener { startExtraction() }
        btnCancel.setOnClickListener { cancelExtraction() }

        btnCopyPath.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("output_path", tvOutputPath.text))
            Toast.makeText(this, "Path copied", Toast.LENGTH_SHORT).show()
        }

        etFps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { updateEstimate() }
        })
    }

    // ─── Video loading ────────────────────────────────────────────────────────

    private fun loadVideoInfo(uri: Uri) {
        tvName.text = getDisplayName(uri)
        tvInfo.text = "Reading…"

        lifecycleScope.launch(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this@MainActivity, uri)

                val durMs  = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val width  = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)  ?: "?"
                val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
                val rot    = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)

                val frameCount = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull()
                } else null

                val durSec    = durMs / 1000f
                val nativeFps = if (frameCount != null && durSec > 0f) frameCount.toFloat() / durSec else null

                val infoText = buildString {
                    append("${width}×${height}")
                    if (rot != null && rot != "0") append(" · ${rot}° rotation")
                    append(" · ${formatDuration(durMs)}")
                    if (nativeFps != null) append(" · ${"%.2f".format(nativeFps)} fps")
                    if (frameCount != null) append(" · $frameCount frames total")
                }

                withContext(Dispatchers.Main) {
                    videoDurationMs = durMs
                    tvInfo.text = infoText

                    // Pre-fill with native fps when detected
                    if (nativeFps != null) {
                        etFps.setText("%.2f".format(nativeFps))
                        tvFpsHint.text = "Native fps detected — all frames will be extracted"
                    } else {
                        tvFpsHint.text = "Enter native fps to extract every frame"
                    }

                    updateEstimate()
                    tvStatus.text = "Ready to extract."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    tvInfo.text = "Could not read video info"
                    tvStatus.text = "Error reading video: ${e.message}"
                }
            } finally {
                retriever.release()
            }
        }
    }

    private fun updateEstimate() {
        val fps = etFps.text.toString().toFloatOrNull() ?: return
        if (videoDurationMs <= 0L || fps <= 0f) {
            tvEstimate.text = "—"
            return
        }
        val est = ((videoDurationMs / 1000f) * fps).toInt().coerceAtLeast(1)
        tvEstimate.text = "$est frames"
    }

    // ─── Extraction ───────────────────────────────────────────────────────────

    private fun startExtraction() {
        val uri = selectedUri ?: run {
            Toast.makeText(this, "Select a video first", Toast.LENGTH_SHORT).show()
            return
        }
        val fps = etFps.text.toString().toFloatOrNull()?.coerceIn(0.1f, 240f) ?: run {
            Toast.makeText(this, "Enter a valid FPS value", Toast.LENGTH_SHORT).show()
            return
        }

        setUiExtracting(true)
        cardProgress.visibility = View.VISIBLE
        cardOutput.visibility = View.GONE
        progressBar.progress = 0
        tvProgress.text = "0 / ?"
        tvEta.text = ""
        tvStatus.text = "Extracting at ${"%.2f".format(fps)} fps…"

        extractionJob = lifecycleScope.launch(Dispatchers.IO) {
            doExtract(uri, fps)
        }
    }

    private fun cancelExtraction() {
        extractionJob?.cancel()
        setUiExtracting(false)
        tvStatus.text = "Stopped."
    }

    private suspend fun doExtract(uri: Uri, fps: Float) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this@MainActivity, uri)

            val durationMs   = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val totalFrames  = ((durationMs / 1000f) * fps).toInt().coerceAtLeast(1)
            val intervalUs   = (1_000_000.0 / fps).toLong()

            // Create timestamped output folder
            val safeVideoName = getDisplayName(uri)
                .substringBeforeLast('.')
                .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                .take(30)
            val stamp  = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outDir = File(getExternalFilesDir("frames"), "${safeVideoName}_${stamp}")
            outDir.mkdirs()

            withContext(Dispatchers.Main) {
                progressBar.max = totalFrames
                tvProgress.text = "0 / $totalFrames"
            }

            var extracted  = 0
            var timeUs     = 0L
            val startMs    = System.currentTimeMillis()

            while (timeUs <= durationMs * 1000L && extracted < totalFrames) {
                if (!currentCoroutineContext().isActive) break

                // OPTION_CLOSEST for accuracy; fall back to OPTION_CLOSEST_SYNC if null
                val bmp: Bitmap? = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)

                if (bmp != null) {
                    val outFile = File(outDir, "frame_%06d.png".format(extracted + 1))
                    FileOutputStream(outFile).use { fos ->
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
                    }
                    bmp.recycle()
                    extracted++

                    val cur         = extracted
                    val elapsedMs   = System.currentTimeMillis() - startMs
                    val msPerFrame  = if (cur > 0) elapsedMs / cur else 0L
                    val remaining   = (totalFrames - cur) * msPerFrame
                    val etaText     = if (cur > 1) "~${formatDuration(remaining)} remaining" else "Estimating…"

                    withContext(Dispatchers.Main) {
                        progressBar.progress = cur
                        tvProgress.text = "$cur / $totalFrames"
                        tvEta.text = etaText
                    }
                }
                timeUs += intervalUs
            }

            val finalCount = extracted
            val finalPath  = outDir.absolutePath
            withContext(Dispatchers.Main) {
                setUiExtracting(false)
                tvStatus.text = "Done — $finalCount frames saved."
                tvOutputPath.text = finalPath
                cardOutput.visibility = View.VISIBLE
                tvEta.text = ""
            }

        } catch (e: CancellationException) {
            withContext(Dispatchers.Main) {
                setUiExtracting(false)
                tvStatus.text = "Stopped."
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                setUiExtracting(false)
                tvStatus.text = "Error: ${e.message}"
            }
        } finally {
            retriever.release()
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private fun setUiExtracting(active: Boolean) {
        btnExtract.isEnabled   = !active
        btnSelect.isEnabled    = !active
        btnCancel.visibility   = if (active) View.VISIBLE else View.GONE
    }

    private fun getDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) return c.getString(0) ?: "video" }
        return uri.lastPathSegment ?: "video"
    }

    private fun formatDuration(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }
}
