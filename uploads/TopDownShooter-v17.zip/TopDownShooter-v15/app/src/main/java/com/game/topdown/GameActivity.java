package com.game.topdown;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {
    private GameView gameView;

    @Override
    protected void attachBaseContext(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = 1.0f;
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                           | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideSystemUI();

        String  name         = getIntent().getStringExtra("name");
        boolean singlePlayer = getIntent().getBooleanExtra("singlePlayer", false);
        boolean host         = getIntent().getBooleanExtra("isHost", false);
        String  hostIp       = getIntent().getStringExtra("hostIp");

        if (singlePlayer) {
            gameView = new GameView(this, name, 2);
        } else {
            gameView = new GameView(this, name, host, hostIp);
        }
        setContentView(gameView);
    }

    /** Hides navigation bar and status bar in sticky immersive mode. */
    @SuppressWarnings("deprecation")
    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    /** Re-hide when the system UI reappears (e.g. after a notification swipe). */
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override protected void onPause()   { super.onPause();   if(gameView!=null) gameView.pause(); }
    @Override protected void onResume()  { super.onResume();  hideSystemUI(); if(gameView!=null) gameView.resume(); }
    @Override protected void onDestroy() { super.onDestroy(); if(gameView!=null) gameView.stopGame(); }
    @Override public void onBackPressed(){ if(gameView!=null) gameView.stopGame(); super.onBackPressed(); }
}
