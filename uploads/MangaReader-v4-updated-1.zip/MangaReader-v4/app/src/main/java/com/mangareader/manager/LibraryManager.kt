package com.mangareader.manager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mangareader.data.Chapter
import com.mangareader.data.Series
import com.mangareader.parser.ChapterParser
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import java.util.zip.ZipInputStream

class LibraryManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("manga_library", Context.MODE_PRIVATE)
    private val gson  = Gson()
    private val mhtmlParser = MhtmlParser(context)

    // ── Read / Write ──────────────────────────────────────────────────────────

    fun getAllSeries(): List<Series> {
        val json = prefs.getString("series_list", "[]") ?: "[]"
        val type = object : TypeToken<List<Series>>() {}.type
        return runCatching { gson.fromJson<List<Series>>(json, type) ?: emptyList() }
            .getOrDefault(emptyList())
    }

    fun saveSeries(series: Series) {
        val list = getAllSeries().toMutableList()
        val idx  = list.indexOfFirst { it.id == series.id }
        if (idx >= 0) list[idx] = series else list.add(series)
        prefs.edit().putString("series_list", gson.toJson(list)).apply()
    }

    fun deleteSeries(seriesId: String) {
        val list = getAllSeries().filter { it.id != seriesId }
        prefs.edit().putString("series_list", gson.toJson(list)).apply()
        // Wipe extracted/cached images
        File(context.cacheDir, "manga/$seriesId").deleteRecursively()
        File(context.filesDir, "zips/$seriesId").deleteRecursively()
        thumbnailFile(seriesId).delete()
    }

    // ── Library cover thumbnails ──────────────────────────────────────────────

    fun thumbnailFile(seriesId: String): File = File(context.cacheDir, "thumbs/$seriesId.jpg")

    /**
     * Returns the cached cover thumbnail for [series], generating it on first
     * use. Generation decodes only the first usable page of the first chapter
     * at a small downsampled size, so it's cheap even for a library with many
     * series and doesn't hold a full-resolution page in memory.
     */
    suspend fun ensureThumbnail(series: Series): File? = withContext(Dispatchers.IO) {
        val file = thumbnailFile(series.id)
        if (file.exists() && file.length() > 0) return@withContext file

        val firstChapter = series.chapters.firstOrNull() ?: return@withContext null
        val ok = runCatching {
            mhtmlParser.extractFirstPageThumbnail(firstChapter.mhtmlPath, file)
        }.getOrDefault(false)

        if (ok) file else null
    }

    // ── Add from SAF folder ───────────────────────────────────────────────────

    /**
     * Adds one or more series from a folder.
     * If the selected folder contains sub-folders that each hold .mhtml/.mht files,
     * each sub-folder becomes its own Series (e.g. "Chainsaw Man", "Solo Leveling").
     * Otherwise the selected folder itself becomes a single Series.
     */
    suspend fun addFolder(treeUri: Uri): List<Series> = withContext(Dispatchers.IO) {
        context.contentResolver.takePersistableUriPermission(
            treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION
        )

        val docFile = DocumentFile.fromTreeUri(context, treeUri)
            ?: error("Cannot open folder")

        // Find sub-directories that contain at least one .mhtml/.mht file
        val seriesDirs = docFile.listFiles()
            .filter { f ->
                f.isDirectory && f.listFiles().any { sf ->
                    val n = sf.name?.lowercase() ?: ""
                    sf.isFile && (n.endsWith(".mhtml") || n.endsWith(".mht"))
                }
            }
            .sortedBy { it.name }

        if (seriesDirs.isNotEmpty()) {
            // Multi-series mode: one Series per subfolder
            seriesDirs.map { dir -> buildSeriesFromDocFile(dir) }
        } else {
            // Single-series mode: the selected folder is one series
            listOf(buildSeriesFromDocFile(docFile, sourceFolderUri = treeUri.toString()))
        }
    }

    private fun buildSeriesFromDocFile(
        docFile: DocumentFile,
        sourceFolderUri: String? = null
    ): Series {
        val seriesId    = UUID.randomUUID().toString()
        val seriesTitle = ChapterParser.extractSeriesName(docFile.name ?: "Manga")

        val mhtmlFiles = docFile.listFiles()
            .filter { f ->
                val name = f.name?.lowercase() ?: ""
                f.isFile && (name.endsWith(".mhtml") || name.endsWith(".mht"))
            }
            .sortedWith(Comparator { a, b ->
                ChapterParser.byNumber.compare(a.name ?: "", b.name ?: "")
            })

        val chapters = mhtmlFiles.mapIndexed { i, file ->
            Chapter(
                title     = ChapterParser.formatTitle(file.name ?: "Chapter ${i + 1}"),
                number    = ChapterParser.extractNumber(file.name ?: "${i + 1}"),
                mhtmlPath = file.uri.toString(),
                seriesId  = seriesId
            )
        }

        val series = Series(
            id              = seriesId,
            title           = seriesTitle,
            sourceFolderUri = sourceFolderUri ?: docFile.uri.toString(),
            chapters        = chapters
        )
        saveSeries(series)
        return series
    }

    // ── Add from ZIP ──────────────────────────────────────────────────────────

    suspend fun addZip(zipUri: Uri): Series = withContext(Dispatchers.IO) {
        val seriesId   = UUID.randomUUID().toString()
        val extractDir = File(context.filesDir, "zips/$seriesId").also { it.mkdirs() }

        // Resolve display name for series title
        val displayName = context.contentResolver.query(
            zipUri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Manga"

        val seriesTitle = ChapterParser.extractSeriesName(displayName)

        // Extract MHTML files from ZIP to internal storage
        val extracted = mutableListOf<File>()
        context.contentResolver.openInputStream(zipUri)?.use { raw ->
            ZipInputStream(raw).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val name = entry.name.substringAfterLast("/")
                    if (!entry.isDirectory &&
                        (name.lowercase().endsWith(".mhtml") || name.lowercase().endsWith(".mht"))
                    ) {
                        val out = File(extractDir, name)
                        out.outputStream().use { o -> zip.copyTo(o) }
                        extracted.add(out)
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }

        val sorted = extracted.sortedWith(Comparator { a, b ->
            ChapterParser.byNumber.compare(a.name, b.name)
        })

        val chapters = sorted.mapIndexed { i, file ->
            Chapter(
                title     = ChapterParser.formatTitle(file.name),
                number    = ChapterParser.extractNumber(file.name),
                mhtmlPath = file.absolutePath,
                seriesId  = seriesId
            )
        }

        val series = Series(
            id           = seriesId,
            title        = seriesTitle,
            sourceZipUri = zipUri.toString(),
            chapters     = chapters
        )
        saveSeries(series)
        series
    }

    // ── Refresh (rescan folder for new chapters) ───────────────────────────────

    suspend fun refreshSeries(series: Series): Series = withContext(Dispatchers.IO) {
        val uriStr = series.sourceFolderUri ?: return@withContext series
        val treeUri = Uri.parse(uriStr)
        val docFile = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext series

        val mhtmlFiles = docFile.listFiles()
            .filter { f ->
                val name = f.name?.lowercase() ?: ""
                f.isFile && (name.endsWith(".mhtml") || name.endsWith(".mht"))
            }
            .sortedWith(Comparator { a, b ->
                ChapterParser.byNumber.compare(a.name ?: "", b.name ?: "")
            })

        val chapters = mhtmlFiles.mapIndexed { i, file ->
            Chapter(
                title     = ChapterParser.formatTitle(file.name ?: "Chapter ${i + 1}"),
                number    = ChapterParser.extractNumber(file.name ?: "${i + 1}"),
                mhtmlPath = file.uri.toString(),
                seriesId  = series.id
            )
        }

        val updated = series.copy(chapters = chapters)
        saveSeries(updated)
        updated
    }
}
