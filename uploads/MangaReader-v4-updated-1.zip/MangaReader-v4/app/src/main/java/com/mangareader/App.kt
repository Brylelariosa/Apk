package com.mangareader

import android.app.Application
import android.graphics.Bitmap
import coil.ImageLoader
import coil.ImageLoaderFactory

/**
 * Provides a single app-wide Coil [ImageLoader].
 *
 * MEMORY: manga pages are decoded as RGB_565 instead of the default ARGB_8888.
 * That halves the memory footprint of every decoded page bitmap (2 bytes per
 * pixel instead of 4) with no visible quality loss for manga art, which adds
 * up fast when a chapter has dozens of tall pages queued up in a scrolling
 * list.
 */
class App : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .bitmapConfig(Bitmap.Config.RGB_565)
            .crossfade(true)
            .build()
}
