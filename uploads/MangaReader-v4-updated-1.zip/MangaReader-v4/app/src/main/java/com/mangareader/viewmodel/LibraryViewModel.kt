package com.mangareader.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series
import com.mangareader.manager.LibraryManager
import com.mangareader.manager.ProgressManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

class LibraryViewModel(app: Application) : AndroidViewModel(app) {

    private val libraryManager  = LibraryManager(app)
    private val progressManager = ProgressManager(app)

    private val _series  = MutableStateFlow<List<Series>>(emptyList())
    val series: StateFlow<List<Series>> = _series

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error   = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // Cover thumbnails, generated lazily and cached by series id.
    private val _thumbnails = MutableStateFlow<Map<String, File>>(emptyMap())
    val thumbnails: StateFlow<Map<String, File>> = _thumbnails
    private val thumbnailsInFlight = mutableSetOf<String>()

    init { reload() }

    private fun reload() {
        _series.value = libraryManager.getAllSeries()
    }

    fun addFolder(uri: Uri) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        runCatching { libraryManager.addFolder(uri) }
            .onFailure { _error.value = "Could not add folder: ${it.message}" }
        reload(); _loading.value = false
    }

    fun addZip(uri: Uri) = viewModelScope.launch {
        _loading.value = true; _error.value = null
        runCatching { libraryManager.addZip(uri) }
            .onFailure { _error.value = "Could not add ZIP: ${it.message}" }
        reload(); _loading.value = false
    }

    fun deleteSeries(seriesId: String) {
        libraryManager.deleteSeries(seriesId)
        reload()
    }

    fun refreshSeries(series: Series) = viewModelScope.launch {
        _loading.value = true
        runCatching { libraryManager.refreshSeries(series) }
        reload(); _loading.value = false
    }

    fun getProgress(seriesId: String): ReadingProgress? =
        progressManager.getProgress(seriesId)

    /** Lazily generates (once) and caches a cover thumbnail for [series]. */
    fun ensureThumbnail(series: Series) {
        if (_thumbnails.value.containsKey(series.id)) return
        if (!thumbnailsInFlight.add(series.id)) return
        viewModelScope.launch {
            val file = runCatching { libraryManager.ensureThumbnail(series) }.getOrNull()
            if (file != null) {
                _thumbnails.value = _thumbnails.value + (series.id to file)
            }
            thumbnailsInFlight.remove(series.id)
        }
    }

    fun clearError() { _error.value = null }
}
