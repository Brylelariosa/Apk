package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mangareader.data.ReadingProgress
import com.mangareader.data.Series
import com.mangareader.viewmodel.LibraryViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onSeriesClick: (Series) -> Unit
) {
    val seriesList by viewModel.series.collectAsStateWithLifecycle()
    val loading    by viewModel.loading.collectAsStateWithLifecycle()
    val error      by viewModel.error.collectAsStateWithLifecycle()
    val thumbnails by viewModel.thumbnails.collectAsStateWithLifecycle()

    var showAddMenu     by remember { mutableStateOf(false) }
    var deleteTarget    by remember { mutableStateOf<Series?>(null) }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> uri?.let { viewModel.addFolder(it) } }

    val zipPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.addZip(it) } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manga Library") },
                actions = {
                    Box {
                        IconButton(onClick = { showAddMenu = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add manga")
                        }
                        DropdownMenu(
                            expanded = showAddMenu,
                            onDismissRequest = { showAddMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Add folder") },
                                leadingIcon = { Icon(Icons.Default.Folder, null) },
                                onClick = {
                                    showAddMenu = false
                                    folderPicker.launch(null)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Add ZIP file") },
                                leadingIcon = { Icon(Icons.Default.Archive, null) },
                                onClick = {
                                    showAddMenu = false
                                    zipPicker.launch(arrayOf("application/zip", "application/x-zip", "*/*"))
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                windowInsets = WindowInsets(0)
            )
        },
        contentWindowInsets = WindowInsets(0)
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (seriesList.isEmpty() && !loading) {
                LibraryEmpty(
                    onAddFolder = { folderPicker.launch(null) },
                    onAddZip    = { zipPicker.launch(arrayOf("application/zip", "*/*")) }
                )
            } else {
                LazyVerticalGrid(
                    columns             = GridCells.Adaptive(160.dp),
                    contentPadding      = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp),
                    flingBehavior         = rememberMomentumFlingBehavior(),
                    modifier              = Modifier.fillMaxSize()
                ) {
                    items(seriesList, key = { it.id }) { series ->
                        SeriesCard(
                            series    = series,
                            progress  = viewModel.getProgress(series.id),
                            thumbnail = thumbnails[series.id],
                            onClick   = { onSeriesClick(series) },
                            onDelete  = { deleteTarget = series },
                            onRefresh = { viewModel.refreshSeries(series) },
                            onRequestThumbnail = { viewModel.ensureThumbnail(series) }
                        )
                    }
                }
            }

            if (loading) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.4f)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Importing…", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            error?.let { msg ->
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    action = {
                        TextButton(onClick = { viewModel.clearError() }) { Text("OK") }
                    }
                ) { Text(msg) }
            }
        }
    }

    // Delete confirmation
    deleteTarget?.let { series ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Remove Series") },
            text  = { Text("Remove \"${series.title}\" from library?\nCached images will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteSeries(series.id)
                    deleteTarget = null
                }) { Text("Remove", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun SeriesCard(
    series: Series,
    progress: ReadingProgress?,
    thumbnail: File?,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onRefresh: () -> Unit,
    onRequestThumbnail: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    // Kick off lazy thumbnail generation the first time this card is composed.
    LaunchedEffect(series.id) { onRequestThumbnail() }

    val progressFraction = remember(progress, series.chapters.size) {
        if (progress != null && series.chapters.isNotEmpty()) {
            ((progress.chapterIndex + 1).toFloat() / series.chapters.size).coerceIn(0f, 1f)
        } else null
    }

    Card(
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick     = onClick,
                onLongClick = { showMenu = true }
            )
    ) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
            ) {
                if (thumbnail != null) {
                    AsyncImage(
                        model = thumbnail,
                        contentDescription = null,
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        Icons.Default.MenuBook,
                        contentDescription = null,
                        modifier = Modifier
                            .size(36.dp)
                            .align(Alignment.Center),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                    )
                }

                // Scrim keeps the chapter-count badge legible over any cover art.
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .align(Alignment.BottomCenter)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))
                            )
                        )
                )

                Text(
                    "${series.chapters.size} ch",
                    style    = MaterialTheme.typography.labelSmall,
                    color    = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                )

                if (progressFraction != null) {
                    LinearProgressIndicator(
                        progress   = progressFraction,
                        modifier   = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .height(3.dp),
                        color      = MaterialTheme.colorScheme.primary,
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )
                }
            }

            Column(Modifier.padding(10.dp)) {
                Text(
                    text     = series.title,
                    style    = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (progress != null) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text  = "Ch ${progress.chapterIndex + 1} · Pg ${progress.pageIndex + 1}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        DropdownMenu(
            expanded          = showMenu,
            onDismissRequest  = { showMenu = false }
        ) {
            if (series.sourceFolderUri != null) {
                DropdownMenuItem(
                    text         = { Text("Refresh chapters") },
                    leadingIcon  = { Icon(Icons.Default.Refresh, null) },
                    onClick      = { showMenu = false; onRefresh() }
                )
            }
            DropdownMenuItem(
                text        = { Text("Remove from library") },
                leadingIcon = { Icon(Icons.Default.Delete, null) },
                onClick     = { showMenu = false; onDelete() }
            )
        }
    }
}

@Composable
private fun LibraryEmpty(onAddFolder: () -> Unit, onAddZip: () -> Unit) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.LibraryBooks,
            contentDescription = null,
            modifier = Modifier.size(80.dp),
            tint     = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        )
        Spacer(Modifier.height(20.dp))
        Text("No manga yet", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        Text(
            "Add a folder or ZIP containing .mhtml files",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onAddFolder) {
                Icon(Icons.Default.Folder, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Folder")
            }
            OutlinedButton(onClick = onAddZip) {
                Icon(Icons.Default.Archive, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("ZIP")
            }
        }
    }
}
