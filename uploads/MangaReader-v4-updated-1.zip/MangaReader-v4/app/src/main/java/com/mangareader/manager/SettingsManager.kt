package com.mangareader.manager

import android.content.Context

/**
 * Persists user-configurable reader preferences across sessions.
 */
class SettingsManager(context: Context) {

    private val prefs = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    /** Fling velocity multiplier (1.0 = stock Compose, higher = snappier). */
    var scrollSpeed: Float
        get() = prefs.getFloat("scroll_speed", 1.5f)
        set(v) { prefs.edit().putFloat("scroll_speed", v).apply() }

    /**
     * Minimum pixel dimension an image must have to be kept as a manga page.
     * Images smaller than this in either width or height are treated as UI
     * noise (icons, ads, small banners) and silently dropped at extraction time.
     * 0 = disabled. Takes effect when a chapter is re-extracted.
     */
    var minImageDimension: Int
        get() = prefs.getInt("min_image_dim", 120)
        set(v) { prefs.edit().putInt("min_image_dim", v).apply() }

    /**
     * Controls how pages are ordered within a chapter after extraction.
     *
     * Different sites structure their MHTML very differently:
     * - [SortOrder.AUTO]      — inspect URL digits; use them only when they look
     *                          like sequential page numbers; otherwise fall back
     *                          to encounter order (the order images appear in the
     *                          saved file, which is usually reading order).
     * - [SortOrder.ENCOUNTER] — always use the file/encounter order. Safest
     *                          choice when AUTO gets it wrong; MHTML saved from a
     *                          browser typically stores images in DOM order.
     * - [SortOrder.URL_PAGE]  — always sort by the number found in the image URL.
     *                          Useful for sites where encounter order is wrong but
     *                          the URLs carry reliable page numbers.
     *
     * Takes effect when a chapter is re-extracted (clear cache or re-open).
     */
    var sortOrder: SortOrder
        get() = SortOrder.from(prefs.getInt("sort_order", SortOrder.AUTO.value))
        set(v) { prefs.edit().putInt("sort_order", v.value).apply() }

    /** How to sort extracted images into reading order for a chapter. */
    enum class SortOrder(val value: Int) {
        AUTO(0),
        ENCOUNTER(1),
        URL_PAGE(2);

        companion object {
            fun from(v: Int) = entries.firstOrNull { it.value == v } ?: AUTO
        }
    }
}
