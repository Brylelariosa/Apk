package com.mangareader.parser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.mangareader.manager.SettingsManager.SortOrder
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader

/**
 * Parses MHTML files and extracts embedded images to a cache directory.
 *
 * PAGE ORDERING — HOW IT WORKS
 * The most reliable source of reading order is the HTML part of the MHTML itself.
 * When a browser saves a page, the HTML body lists <img> tags (or data-src / data-original
 * lazy-load variants) in the order they appear in the document — which is the reading
 * order. The image MIME parts that follow can be in any order; only the HTML reflects
 * the real layout.
 *
 * AUTO strategy (default):
 *   1. On the first pass through the file, accumulate the text/html MIME part.
 *   2. Extract img src / data-src / data-original attributes in document order →
 *      build a URL → position map (htmlOrder).
 *   3. When an image MIME part is processed, look up its Content-Location URL in
 *      htmlOrder to get its reading-order position.
 *   4. Sort by that position. Images with no match (noise images not referenced in
 *      the page HTML) are appended at the end in encounter order.
 *   5. If the HTML had no img tags at all (fully JS-rendered reader), fall back to
 *      URL sequential check → encounter order.
 *
 * ENCOUNTER / URL_PAGE — manual overrides for unusual sites.
 *
 * NOISE FILTERING
 * Images whose width or height is below [minImageDimension] are dropped via a
 * fast header-only decode (inJustDecodeBounds) — no pixel data allocated.
 *
 * MEMORY
 * Streamed line-by-line. The HTML body is accumulated up to 1 MB and then parsed
 * once; image bodies are processed one at a time.
 */
class MhtmlParser(private val context: Context) {

    private val boundaryRegex = Regex(
        """boundary=["']?([^"'\r\n;]+)["']?""", RegexOption.IGNORE_CASE
    )

    private val nonImageContentTypeHints = listOf(
        "text/", "application/javascript", "application/x-javascript",
        "application/json", "font/", "application/font", "application/x-font"
    )

    // Matches src / data-src / data-original / data-lazy / data-lazy-src in any tag.
    // Excludes data: URIs and anything with a space (broken attribute).
    private val htmlImgSrcRegex = Regex(
        """(?:src|data-src|data-original|data-lazy(?:-src)?)\s*=\s*["']([^"'?#\s]+)""",
        RegexOption.IGNORE_CASE
    )

    // ── Public API ─────────────────────────────────────────────────────────────

    fun extractImages(
        mhtmlPath: String,
        cacheDir: File,
        minImageDimension: Int = 120,
        sortOrder: SortOrder = SortOrder.AUTO
    ): List<File> = try {
        openStream(mhtmlPath)?.use {
            extractImages(it, cacheDir, minImageDimension, sortOrder)
        } ?: emptyList()
    } catch (e: Exception) {
        e.printStackTrace(); emptyList()
    }

    fun extractImages(
        inputStream: InputStream,
        cacheDir: File,
        minImageDimension: Int = 120,
        sortOrder: SortOrder = SortOrder.AUTO
    ): List<File> {
        cacheDir.mkdirs()

        data class Pending(
            val file: File,
            val htmlPos: Int?,   // position in HTML document (reading order)
            val pageNum: Int?,   // number extracted from Content-Location URL
            val order: Int       // encounter order (position in MHTML file)
        )
        val pending = mutableListOf<Pending>()
        var encounterIndex = 0

        // URL / filename → HTML document position.  Populated when we parse the
        // text/html MIME part; used later to sort image MIME parts.
        val htmlOrder = mutableMapOf<String, Int>()

        try {
            val reader = BufferedReader(
                InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024
            )
            val boundary = findBoundary(reader) ?: return emptyList()
            val delimiter = "--$boundary"

            val headerBuilder  = StringBuilder()
            val bodyBuilder    = StringBuilder()
            val htmlBodyBuilder= StringBuilder()    // accumulates text/html body
            var inBody             = false
            var isImagePart        = false
            var isHtmlPart         = false
            var contentLocationUrl = ""
            var pageNum: Int?      = null
            var htmlPartsProcessed = 0
            var totalPartsStarted  = 0   // counts delimiter hits (not reset() calls)

            // Called when we hit a boundary and isHtmlPart is still set:
            // parse accumulated HTML and fill htmlOrder.
            fun finaliseHtmlPart() {
                if (!isHtmlPart || htmlBodyBuilder.isEmpty()) return
                htmlImgSrcRegex.findAll(htmlBodyBuilder).forEach { m ->
                    val url = m.groupValues[1].trim()
                    if (url.isBlank() || url.startsWith("data:")) return@forEach
                    if (!htmlOrder.containsKey(url)) {
                        val pos = htmlOrder.size
                        htmlOrder[url] = pos
                    }
                    // Also index by bare filename so we can match Content-Location
                    // absolute URLs against relative src values and vice-versa.
                    val fname = url.substringAfterLast('/').substringBefore('?')
                    if (fname.isNotBlank() && !htmlOrder.containsKey(fname))
                        htmlOrder[fname] = htmlOrder[url]!!
                }
                htmlBodyBuilder.setLength(0)
                htmlPartsProcessed++
            }

            fun flush() {
                if (!isImagePart || bodyBuilder.isEmpty()) return
                try {
                    val bytes = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                    val ext   = sniffImageExt(bytes) ?: return
                    if (bytes.size <= 200) return

                    if (minImageDimension > 0) {
                        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (opts.outWidth  < minImageDimension ||
                            opts.outHeight < minImageDimension) return
                    }

                    // Look up reading-order position from the HTML map.
                    val htmlPos = lookupHtmlPos(contentLocationUrl, htmlOrder)

                    val tmp = File(cacheDir, "tmp_$encounterIndex.$ext")
                    tmp.writeBytes(bytes)
                    pending.add(Pending(tmp, htmlPos, pageNum, encounterIndex))
                    encounterIndex++
                } catch (_: Exception) { }
            }

            fun reset() {
                headerBuilder.setLength(0); bodyBuilder.setLength(0)
                inBody = false; isImagePart = false; isHtmlPart = false
                contentLocationUrl = ""; pageNum = null
            }

            var line: String?
            while (true) {
                line = reader.readLine() ?: break
                val l = line!!

                if (l.startsWith(delimiter)) {
                    finaliseHtmlPart()  // parse HTML before flushing next image
                    flush()
                    reset()
                    totalPartsStarted++
                    if (l.startsWith("$delimiter--")) break
                    continue
                }

                if (!inBody) {
                    if (l.isEmpty()) {
                        inBody = true
                        val headersStr = headerBuilder.toString()

                        // Only look for the HTML part in the first 10 MIME parts;
                        // after that we're definitely into resources.
                        isHtmlPart = htmlPartsProcessed == 0 &&
                            totalPartsStarted < 10 &&
                            headersStr.contains("text/html", ignoreCase = true)

                        isImagePart = !isHtmlPart && isLikelyImagePart(headerBuilder)

                        contentLocationUrl = headerBuilder.lineSequence()
                            .firstOrNull { it.contains("content-location", ignoreCase = true) }
                            ?.substringAfter(':')?.trim().orEmpty()

                        if (isImagePart) pageNum = extractPageNumber(contentLocationUrl)
                    } else {
                        headerBuilder.append(l).append('\n')
                    }
                } else {
                    when {
                        // Cap HTML accumulation at 1 MB to guard against enormous pages.
                        isHtmlPart && htmlBodyBuilder.length < 1_000_000 ->
                            htmlBodyBuilder.append(l).append('\n')
                        isImagePart ->
                            bodyBuilder.append(l)
                    }
                }
            }
            // End-of-file: flush whatever the last part was
            finaliseHtmlPart()
            flush()

        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (pending.isEmpty()) return emptyList()

        // ── Sort ─────────────────────────────────────────────────────────────
        val ordered: List<Pending> = when (sortOrder) {

            SortOrder.ENCOUNTER -> pending.sortedBy { it.order }

            SortOrder.URL_PAGE -> pending.sortedWith(
                compareBy({ it.pageNum == null }, { it.pageNum ?: Int.MAX_VALUE }, { it.order })
            )

            SortOrder.AUTO -> {
                val hasHtmlPositions = pending.any { it.htmlPos != null }

                if (hasHtmlPositions) {
                    // Primary: HTML document order — the browser put <img> tags
                    // in reading order; images not found in the HTML map go at end.
                    pending.sortedWith(
                        compareBy(
                            { it.htmlPos == null },
                            { it.htmlPos ?: Int.MAX_VALUE },
                            { it.order }
                        )
                    )
                } else {
                    // No HTML positions (fully JS-rendered reader or no img tags):
                    // try URL page numbers if they look sequential.
                    val numbered = pending.filter { it.pageNum != null }
                        .sortedBy { it.pageNum }
                    val reliable = numbered.size >= 2 &&
                        numbered.size >= pending.size / 2 &&
                        numbered.zipWithNext().all { (a, b) ->
                            (b.pageNum!! - a.pageNum!!) <= 10
                        }
                    if (reliable)
                        pending.sortedWith(
                            compareBy(
                                { it.pageNum == null },
                                { it.pageNum ?: Int.MAX_VALUE },
                                { it.order }
                            )
                        )
                    else
                        pending.sortedBy { it.order }
                }
            }
        }

        // Rename to cleanly-sortable final filenames so cache reloads
        // reproduce this exact order without re-parsing the MHTML.
        return ordered.mapIndexedNotNull { i, p ->
            val target = File(
                cacheDir,
                "page_${(i + 1).toString().padStart(4, '0')}.${p.file.extension}"
            )
            if (p.file.renameTo(target)) target else null
        }
    }

    // ── Thumbnail ──────────────────────────────────────────────────────────────

    fun extractFirstPageThumbnail(
        mhtmlPath: String,
        outFile: File,
        maxDimension: Int = 480
    ): Boolean {
        val bytes = try {
            openStream(mhtmlPath)?.use { extractFirstPageBytes(it) }
        } catch (e: Exception) {
            e.printStackTrace(); null
        } ?: return false

        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth  / (sample * 2) >= maxDimension ||
                   bounds.outHeight / (sample * 2) >= maxDimension) sample *= 2

            val opts   = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false
            outFile.parentFile?.mkdirs()
            FileOutputStream(outFile).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            bitmap.recycle()
            true
        } catch (e: Exception) {
            e.printStackTrace(); false
        }
    }

    private fun extractFirstPageBytes(inputStream: InputStream): ByteArray? {
        val reader = BufferedReader(
            InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024
        )
        val boundary  = findBoundary(reader) ?: return null
        val delimiter = "--$boundary"
        val headerBuilder = StringBuilder()
        val bodyBuilder   = StringBuilder()
        var inBody = false; var isImagePart = false

        fun tryDecode(): ByteArray? {
            if (!isImagePart || bodyBuilder.isEmpty()) return null
            return try {
                val b = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                if (b.size > 200 && sniffImageExt(b) != null) b else null
            } catch (_: Exception) { null }
        }

        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            val l = line!!
            if (l.startsWith(delimiter)) {
                tryDecode()?.let { return it }
                headerBuilder.setLength(0); bodyBuilder.setLength(0)
                inBody = false; isImagePart = false
                if (l.startsWith("$delimiter--")) return null
                continue
            }
            if (!inBody) {
                if (l.isEmpty()) { inBody = true; isImagePart = isLikelyImagePart(headerBuilder) }
                else headerBuilder.append(l).append('\n')
            } else if (isImagePart) bodyBuilder.append(l)
        }
        return tryDecode()
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun openStream(path: String): InputStream? =
        if (path.startsWith("content://"))
            context.contentResolver.openInputStream(Uri.parse(path))
        else
            File(path).inputStream()

    private fun findBoundary(reader: BufferedReader): String? {
        val peek = StringBuilder()
        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            peek.append(line).append('\n')
            boundaryRegex.find(peek)?.let { return it.groupValues[1].trim() }
            if (peek.length > 8192) break
        }
        return null
    }

    private fun isLikelyImagePart(headers: CharSequence): Boolean {
        val ct = headers.lineSequence()
            .firstOrNull { it.contains("content-type", ignoreCase = true) }
            ?.lowercase() ?: return true
        return nonImageContentTypeHints.none { ct.contains(it) }
    }

    /**
     * Looks up reading-order position for an image given its Content-Location URL.
     * Tries full URL match first, then bare filename (handles absolute vs relative
     * URL differences between HTML src and MHTML Content-Location).
     */
    private fun lookupHtmlPos(contentLocation: String, order: Map<String, Int>): Int? {
        if (order.isEmpty() || contentLocation.isBlank()) return null
        order[contentLocation]?.let { return it }
        val fname = contentLocation.substringAfterLast('/')
            .substringBefore('?').substringBefore('#')
        return order[fname]
    }

    /**
     * Extracts a page number from a Content-Location URL.
     *
     * Priority order so that explicit page keywords beat bare trailing digits:
     *  1. "page"/"pg" keyword   → page-007.jpg, pg_3.png
     *  2. Underscore + zero-pad → _001.jpg, _0042.webp
     *  3. Bare digits before extension, capped at 2 000 to reject timestamps
     */
    private fun extractPageNumber(rawUrl: String): Int? {
        if (rawUrl.isBlank()) return null
        val fname = rawUrl.substringBefore('?').substringBefore('#').substringAfterLast('/')

        Regex("""(?:page|pg)[_\-]?0*(\d+)""", RegexOption.IGNORE_CASE)
            .find(fname)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }

        Regex("""_0*(\d{1,4})\.\w{2,5}$""")
            .find(fname)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }

        val raw = Regex("""(\d+)\.\w{2,5}$""")
            .find(fname)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        return if (raw <= 2000) raw else null
    }

    private fun sniffImageExt(bytes: ByteArray): String? {
        if (bytes.size < 12) return null
        return when {
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "png"
            bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte()                               -> "gif"
            bytes[0] == 0x52.toByte() && bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte() && bytes[3] == 0x46.toByte() &&
            bytes[8] == 0x57.toByte() && bytes[9] == 0x45.toByte() &&
            bytes[10] == 0x42.toByte()&& bytes[11] == 0x50.toByte() -> "webp"
            bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte() -> "bmp"
            else -> null
        }
    }
}
