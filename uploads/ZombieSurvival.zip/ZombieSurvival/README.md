# Zombie Survival — LAN Co-op Wave Shooter

MVP foundation for the full spec. This is a real, playable slice — not a
stub — built so every remaining spec feature has an obvious place to land.
Everything below is either "done" or "deliberately deferred," nothing is
half-wired.

## Stack

Kotlin, pure Android (no game framework, no NDK/C++). Rendering is a
hand-rolled SurfaceView/Canvas engine, same family of approach as the
mGBA emulator's custom skin rendering. Chosen over LibGDX specifically
because LibGDX's default multi-module layout (module name `android`, not
`app`) would break the existing CI's APK-locate step, which assumes a
single `app` module. No native code means no NDK/CMake compile risk in CI.

Build pins: Gradle 8.6 (matches the existing pipeline exactly), AGP 8.4.0
(the AGP line whose *minimum* Gradle requirement is 8.6 — AGP 8.5+ needs
Gradle 8.7+, which would break the pinned wrapper), Kotlin 1.9.24,
compileSdk/targetSdk 34, minSdk 24, JDK 17 (matches the CI's setup-java
step). `gradlew`/`gradlew.bat` were pulled verbatim from the Gradle repo
rather than hand-typed, since the CI's own gradle-wrapper.jar fetch step
already assumes a wrapper script is present and correct.

## Architecture

```
game/            GameView (render+input+loop), GameWorld (entity store),
                 GameSimulation (host-authoritative tick), WaveManager,
                 MapData
game/model/      Plain data classes (PlayerState, ZombieState, BulletState,
                 wire snapshot types) — see the threading contract comment
                 at the top of GameModels.kt before touching these
game/ai/         ZombieAI
game/weapon/     WeaponType stats
input/           VirtualJoystick (not an Android View — GameView hit-tests
                 and routes touch into it directly)
net/             NetworkProtocol (wire format), LanDiscovery (NSD),
                 GameServer (host), GameClient (client)
data/            SaveManager (SharedPreferences)
```

Networking: NSD for LAN discovery, one TCP socket per player,
newline-delimited JSON. Host runs the only simulation; clients send input
and render an interpolated copy of whatever the host last broadcast. This
is a deliberate simplification — see Roadmap.

## What's actually in the MVP

- Main menu → Host or Join, both landscape
- Host: opens a socket, advertises over NSD, shows a live lobby list
- Join: discovers hosts on the LAN, lists them, connects, ready-up
- One map (Farm) — bounded world, a handful of static obstacles
- Twin-stick controls: left = move, right = aim (auto-fires past a
  deadzone), a reload button
- Pistol only, magazine + reload timer
- One zombie type: chases the nearest living player, melee attack
- Wave spawner with an escalating count/health/speed curve
- Bullet/zombie hit detection, money-per-kill
- HUD: health, ammo, wave, money, ping (client-side)
- Game over screen, highest-wave persisted across sessions
- Basic obstacle collision (circle-vs-AABB push-out)

## Known simplifications (not bugs — deliberate MVP calls)

- **No client-side prediction.** The client's own player waits for the
  host's next broadcast + a lerp before you see it move. This is the
  single most noticeable "networking feels laggy" issue and the highest-
  value next step. Full prediction + reconciliation is a bigger lift than
  everything else in this list combined, which is why it's not in v1.
- **No reconnect-on-drop.** A dropped client shows "connection lost" and
  returns to the menu rather than rejoining a match in progress.
- **No host migration.**
- **Zombies ignore obstacles** (straight-line chase, no pathfinding yet).
- **No object pooling** for bullets/zombies — fine at this entity count,
  worth revisiting if a later pass adds hundreds of enemies at once.

## Roadmap (roughly the order I'd tackle it)

1. More weapons (shotgun/SMG/rifle/etc.) — mostly WeaponType entries +
   a shop screen between waves
2. More zombie types (Runner/Tank/Spitter/Exploder/Crawler) + boss waves
3. Barricades, traps, power-ups
4. More maps
5. Client-side prediction + reconciliation for local movement
6. Day/night cycle, particle effects, screen shake, hit markers
7. Achievements/statistics screen, settings screen (graphics/audio/
   controls, manual-fire toggle)
8. Sound

## Building

Same pipeline as everything else — push this as a zip through the usual
CI. This was written without a compiler in the loop (no Android SDK/
network in the build sandbox), so treat the first CI run as the first
real compile: if `assembleDebug` throws anything, paste the log back and
it gets fixed same as any other build error.
