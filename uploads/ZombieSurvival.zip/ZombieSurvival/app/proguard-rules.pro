# Add project specific ProGuard rules here.
# Minification is currently disabled (isMinifyEnabled = false) while the
# networking/reflection-free codebase is still taking shape. Flip it on
# once the feature set stabilizes and add keep rules here if R8 strips
# anything referenced only via the network protocol.
