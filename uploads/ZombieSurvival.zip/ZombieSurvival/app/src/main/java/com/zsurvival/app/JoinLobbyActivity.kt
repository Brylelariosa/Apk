package com.zsurvival.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.zsurvival.app.data.SaveManager
import com.zsurvival.app.game.model.LobbyPlayer
import com.zsurvival.app.net.DiscoveredHost
import com.zsurvival.app.net.GameClient
import com.zsurvival.app.net.LanBrowser

class JoinLobbyActivity : AppCompatActivity() {

    private lateinit var saveManager: SaveManager
    private lateinit var browser: LanBrowser
    private lateinit var hostsAdapter: ArrayAdapter<String>
    private lateinit var lobbyAdapter: ArrayAdapter<String>
    private val discoveredHosts = mutableListOf<DiscoveredHost>()
    private var matchStarting = false
    private var isReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join_lobby)
        saveManager = SaveManager(this)

        GameSession.resetForNewLobby()
        GameSession.isHost = false

        hostsAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        val hostsList = findViewById<ListView>(R.id.listDiscoveredHosts)
        hostsList.adapter = hostsAdapter
        hostsList.setOnItemClickListener { _, _, position, _ -> connectTo(discoveredHosts[position]) }

        lobbyAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        findViewById<ListView>(R.id.listJoinPlayers).adapter = lobbyAdapter

        browser = LanBrowser(this)
        browser.start(
            onFound = { host -> runOnUiThread { addOrUpdateHost(host) } },
            onLost = { name ->
                runOnUiThread {
                    discoveredHosts.removeIf { it.serviceName == name }
                    refreshHostsList()
                }
            }
        )

        findViewById<EditText>(R.id.editJoinName).setText(saveManager.getLastPlayerName().ifBlank { "Player" })

        val readyButton = findViewById<MaterialButton>(R.id.btnReady)
        readyButton.setOnClickListener {
            isReady = !isReady
            readyButton.text = if (isReady) getString(R.string.btn_cancel_ready) else getString(R.string.btn_ready)
            GameSession.client?.sendReady()
        }
    }

    private fun addOrUpdateHost(host: DiscoveredHost) {
        val idx = discoveredHosts.indexOfFirst { it.serviceName == host.serviceName }
        if (idx >= 0) discoveredHosts[idx] = host else discoveredHosts.add(host)
        refreshHostsList()
    }

    private fun refreshHostsList() {
        hostsAdapter.clear()
        hostsAdapter.addAll(discoveredHosts.map { it.serviceName.removePrefix("ZSurvival-") })
        findViewById<TextView>(R.id.textJoinStatus).text =
            if (discoveredHosts.isEmpty()) getString(R.string.join_no_hosts) else getString(R.string.join_subtitle)
    }

    private fun connectTo(host: DiscoveredHost) {
        browser.stop()
        val name = findViewById<EditText>(R.id.editJoinName).text.toString().ifBlank { "Player" }
        GameSession.localPlayerName = name
        saveManager.setLastPlayerName(name)

        val client = GameClient(GameSession.world)
        GameSession.client = client

        findViewById<TextView>(R.id.textJoinStatus).text = getString(R.string.join_connecting)

        client.onWelcome = { id -> GameSession.localPlayerId = id }
        client.onConnected = {
            runOnUiThread {
                findViewById<View>(R.id.sectionDiscovery).visibility = View.GONE
                findViewById<View>(R.id.sectionConnected).visibility = View.VISIBLE
                findViewById<TextView>(R.id.textJoinStatus).text = getString(R.string.join_waiting_host)
            }
        }
        client.onConnectFailed = {
            runOnUiThread {
                Toast.makeText(this, "Couldn't connect — is the host still open?", Toast.LENGTH_LONG).show()
                findViewById<TextView>(R.id.textJoinStatus).text = getString(R.string.join_subtitle)
            }
        }
        client.onLobbyUpdate = { players -> runOnUiThread { renderLobby(players) } }
        client.onMatchStart = {
            matchStarting = true
            runOnUiThread { startActivity(Intent(this, GameActivity::class.java)) }
        }
        client.onDisconnected = {
            if (!matchStarting) {
                runOnUiThread {
                    Toast.makeText(this, R.string.connection_lost, Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        }

        client.connect(host.address, host.port, name)
    }

    private fun renderLobby(players: List<LobbyPlayer>) {
        lobbyAdapter.clear()
        for (p in players) {
            val label = if (p.isHost) getString(R.string.lobby_you_host, p.name)
            else "${p.name} — ${if (p.ready) getString(R.string.lobby_ready) else getString(R.string.lobby_not_ready)}"
            lobbyAdapter.add(label)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        browser.stop()
        if (!matchStarting) {
            GameSession.resetForNewLobby()
        }
    }
}
