package com.zsurvival.app.net

import android.os.SystemClock
import android.util.Log
import com.zsurvival.app.game.GameWorld
import com.zsurvival.app.game.model.LobbyPlayer
import com.zsurvival.app.game.model.PlayerInput
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.Socket

private const val TAG = "GameClient"
private const val CONNECT_TIMEOUT_MS = 5000
private const val PING_INTERVAL_MS = 2000L

/**
 * Runs on a non-host device. All callbacks fire on the network read
 * thread — callers must hop to the UI thread themselves before touching
 * views (same contract as LanBrowser). STATE messages are the exception:
 * they're written straight into world.latestSnapshot via a @Volatile
 * swap, consumed by the render loop — see GameModels.kt's threading note.
 */
class GameClient(private val world: GameWorld) {

    @Volatile var myPlayerId: Int = -1
        private set
    @Volatile var pingMs: Long = -1
        private set
    @Volatile var isConnected: Boolean = false
        private set

    var onConnected: (() -> Unit)? = null
    var onConnectFailed: (() -> Unit)? = null
    var onWelcome: ((Int) -> Unit)? = null
    var onLobbyUpdate: ((List<LobbyPlayer>) -> Unit)? = null
    var onMatchStart: (() -> Unit)? = null
    var onGameOver: ((Int) -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null

    private var socket: Socket? = null
    private var writer: BufferedWriter? = null
    private var nextPingAtMs: Long = 0L

    fun connect(address: String, port: Int, name: String) {
        Thread({
            try {
                val s = Socket()
                s.connect(InetSocketAddress(address, port), CONNECT_TIMEOUT_MS)
                socket = s
                writer = BufferedWriter(OutputStreamWriter(s.getOutputStream()))
                isConnected = true
                sendLine(NetworkProtocol.buildJoin(name))
                onConnected?.invoke()
                readLoop(s)
            } catch (e: IOException) {
                Log.w(TAG, "connect failed", e)
                isConnected = false
                onConnectFailed?.invoke()
            }
        }, "GameClient-Connect").apply {
            isDaemon = true
            start()
        }
    }

    private fun readLoop(s: Socket) {
        try {
            val reader = BufferedReader(InputStreamReader(s.getInputStream()))
            var line = reader.readLine()
            while (line != null) {
                handleLine(line)
                line = reader.readLine()
            }
        } catch (e: IOException) {
            Log.i(TAG, "connection ended: ${e.message}")
        } finally {
            val wasConnected = isConnected
            isConnected = false
            if (wasConnected) onDisconnected?.invoke()
        }
    }

    private fun handleLine(line: String) {
        val json = NetworkProtocol.parseLine(line) ?: return
        when (NetworkProtocol.peekType(json)) {
            NetworkProtocol.TYPE_WELCOME -> {
                val id = NetworkProtocol.parseWelcomeId(json)
                myPlayerId = id
                onWelcome?.invoke(id)
            }
            NetworkProtocol.TYPE_LOBBY -> onLobbyUpdate?.invoke(NetworkProtocol.parseLobby(json))
            NetworkProtocol.TYPE_START -> onMatchStart?.invoke()
            NetworkProtocol.TYPE_STATE -> world.latestSnapshot = NetworkProtocol.parseState(json)
            NetworkProtocol.TYPE_PONG -> {
                val sentAt = NetworkProtocol.parseTimestamp(json)
                if (sentAt > 0) pingMs = SystemClock.elapsedRealtime() - sentAt
            }
            NetworkProtocol.TYPE_GAMEOVER -> onGameOver?.invoke(NetworkProtocol.parseGameOverWave(json))
        }
    }

    fun sendReady() = sendLine(NetworkProtocol.buildReady())

    fun sendInput(input: PlayerInput) = sendLine(NetworkProtocol.buildInput(input))

    /** Call once per frame from the game loop; actually sends at most every [PING_INTERVAL_MS]. */
    fun tickPing(nowMs: Long) {
        if (nowMs >= nextPingAtMs) {
            nextPingAtMs = nowMs + PING_INTERVAL_MS
            sendLine(NetworkProtocol.buildPing(nowMs))
        }
    }

    private fun sendLine(line: String) {
        val w = writer ?: return
        try {
            synchronized(w) {
                w.write(line)
                w.write("\n")
                w.flush()
            }
        } catch (e: IOException) {
            isConnected = false
        }
    }

    fun disconnect() {
        try { socket?.close() } catch (e: IOException) { /* ignore */ }
        socket = null
        writer = null
        isConnected = false
    }
}
