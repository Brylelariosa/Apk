package com.zsurvival.app.net

import android.util.Log
import com.zsurvival.app.game.GameWorld
import com.zsurvival.app.game.MapData
import com.zsurvival.app.game.model.LobbyPlayer
import com.zsurvival.app.game.model.PlayerState
import com.zsurvival.app.game.weapon.WeaponType
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

private const val TAG = "GameServer"

/**
 * Runs on the host device. Owns the ServerSocket plus one ClientHandler
 * (with its own reader thread) per connected remote player. The host's
 * OWN player (id 0) is not a ClientHandler — its input comes straight
 * from local touch handling in GameView, written into world.inputs
 * directly on the UI thread.
 *
 * broadcastState()/broadcastGameOver() are meant to be called BY the
 * game-loop thread, right after it ticks the simulation — that keeps
 * serialization and simulation on the same thread so nothing else ever
 * needs to read GameWorld's mutable entities concurrently (see the
 * threading contract comment in GameModels.kt).
 */
class GameServer(private val world: GameWorld) {

    var onLobbyChanged: ((List<LobbyPlayer>) -> Unit)? = null
    var onClientDisconnected: ((Int) -> Unit)? = null

    private var serverSocket: ServerSocket? = null
    @Volatile private var running = false
    @Volatile private var matchStarted = false

    private val clients = CopyOnWriteArrayList<ClientHandler>()
    private val nextPlayerId = AtomicInteger(1)

    val port: Int get() = serverSocket?.localPort ?: -1

    fun start(): Boolean {
        return try {
            val socket = ServerSocket(0)
            serverSocket = socket
            running = true
            Thread({ acceptLoop(socket) }, "GameServer-Accept").apply {
                isDaemon = true
                start()
            }
            true
        } catch (e: IOException) {
            Log.e(TAG, "Failed to open server socket", e)
            false
        }
    }

    private fun acceptLoop(socket: ServerSocket) {
        while (running) {
            val client = try {
                socket.accept()
            } catch (e: IOException) {
                if (running) Log.w(TAG, "accept() failed", e)
                null
            } ?: continue

            if (matchStarted) {
                // MVP: no late joins mid-match.
                try { client.close() } catch (e: IOException) { /* ignore */ }
                continue
            }
            val handler = ClientHandler(client)
            clients.add(handler)
            handler.start()
        }
    }

    /** Call once, right after start(), for the host's own locally-controlled player. */
    fun addHostPlayer(name: String): PlayerState {
        val (sx, sy) = MapData.startPointFor(0)
        val p = PlayerState(id = 0, name = name)
        p.x = sx; p.y = sy; p.targetX = sx; p.targetY = sy
        p.magSize = WeaponType.PISTOL.magazineSize
        p.ammoInMag = p.magSize
        world.players.add(p)
        return p
    }

    fun startMatch() {
        matchStarted = true
        broadcastRaw(NetworkProtocol.buildStart())
    }

    fun broadcastState(wave: Int) {
        broadcastRaw(NetworkProtocol.buildState(wave, world))
    }

    fun broadcastGameOver(wave: Int) {
        broadcastRaw(NetworkProtocol.buildGameOver(wave))
    }

    fun broadcastLobbyNow() = broadcastLobby()

    private fun broadcastRaw(line: String) {
        for (c in clients) {
            if (c.connected) c.sendLine(line)
        }
    }

    private fun currentLobby(): List<LobbyPlayer> {
        val list = ArrayList<LobbyPlayer>()
        world.findPlayer(0)?.let { list.add(LobbyPlayer(0, it.name, it.ready, true)) }
        for (c in clients) {
            if (!c.connected) continue
            world.findPlayer(c.playerId)?.let { list.add(LobbyPlayer(it.id, it.name, it.ready, false)) }
        }
        return list
    }

    private fun broadcastLobby() {
        val lobby = currentLobby()
        onLobbyChanged?.invoke(lobby)
        broadcastRaw(NetworkProtocol.buildLobby(lobby))
    }

    fun stop() {
        running = false
        for (c in clients) c.close()
        clients.clear()
        try { serverSocket?.close() } catch (e: IOException) { /* ignore */ }
        serverSocket = null
    }

    private inner class ClientHandler(private val socket: Socket) {
        var playerId: Int = -1
            private set

        @Volatile var connected = true
            private set

        private var writer: BufferedWriter? = null

        fun start() {
            Thread({ readLoop() }, "GameServer-Client").apply {
                isDaemon = true
                start()
            }
        }

        private fun readLoop() {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream()))

                var line = reader.readLine()
                while (line != null) {
                    handleLine(line)
                    line = reader.readLine()
                }
            } catch (e: IOException) {
                Log.i(TAG, "client $playerId disconnected: ${e.message}")
            } finally {
                onDisconnect()
            }
        }

        private fun handleLine(line: String) {
            val json = NetworkProtocol.parseLine(line) ?: return
            when (NetworkProtocol.peekType(json)) {
                NetworkProtocol.TYPE_JOIN -> {
                    val name = NetworkProtocol.parseJoinName(json)
                    playerId = nextPlayerId.getAndIncrement()
                    val (sx, sy) = MapData.startPointFor(playerId)
                    val p = PlayerState(id = playerId, name = name)
                    p.x = sx; p.y = sy; p.targetX = sx; p.targetY = sy
                    p.magSize = WeaponType.PISTOL.magazineSize
                    p.ammoInMag = p.magSize
                    world.players.add(p)
                    sendLine(NetworkProtocol.buildWelcome(playerId))
                    broadcastLobby()
                }
                NetworkProtocol.TYPE_READY -> {
                    world.findPlayer(playerId)?.let { it.ready = !it.ready }
                    broadcastLobby()
                }
                NetworkProtocol.TYPE_INPUT -> {
                    if (playerId != -1) world.inputs[playerId] = NetworkProtocol.parseInput(json)
                }
                NetworkProtocol.TYPE_PING -> {
                    sendLine(NetworkProtocol.buildPong(NetworkProtocol.parseTimestamp(json)))
                }
            }
        }

        fun sendLine(line: String) {
            try {
                val w = writer ?: return
                synchronized(w) {
                    w.write(line)
                    w.write("\n")
                    w.flush()
                }
            } catch (e: IOException) {
                onDisconnect()
            }
        }

        private fun onDisconnect() {
            if (!connected) return
            connected = false
            world.findPlayer(playerId)?.let {
                it.connected = false
            }
            // Freeze rather than have them act on stale input forever; they'll
            // still take zombie damage where they stand, which is what
            // eventually makes allPlayersDead() true if everyone else falls too.
            world.inputs.remove(playerId)
            close()
            onClientDisconnected?.invoke(playerId)
            broadcastLobby()
        }

        fun close() {
            try { socket.close() } catch (e: IOException) { /* ignore */ }
        }
    }
}
