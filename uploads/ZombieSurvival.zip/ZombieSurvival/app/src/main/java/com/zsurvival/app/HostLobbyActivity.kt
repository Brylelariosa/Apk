package com.zsurvival.app

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.zsurvival.app.data.SaveManager
import com.zsurvival.app.game.model.LobbyPlayer
import com.zsurvival.app.net.GameServer
import com.zsurvival.app.net.LanAdvertiser

class HostLobbyActivity : AppCompatActivity() {

    private lateinit var saveManager: SaveManager
    private lateinit var listAdapter: ArrayAdapter<String>
    private var matchStarting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_host_lobby)
        saveManager = SaveManager(this)

        GameSession.resetForNewLobby()
        GameSession.isHost = true
        GameSession.localPlayerId = 0

        val nameField = findViewById<EditText>(R.id.editHostName)
        nameField.setText(saveManager.getLastPlayerName().ifBlank { "Host" })

        listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        findViewById<ListView>(R.id.listHostPlayers).adapter = listAdapter

        val server = GameServer(GameSession.world)
        GameSession.server = server
        server.onLobbyChanged = { players -> runOnUiThread { renderLobby(players) } }

        if (!server.start()) {
            Toast.makeText(this, "Couldn't start the server — try again", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val hostName = nameField.text.toString().ifBlank { "Host" }
        GameSession.localPlayerName = hostName
        server.addHostPlayer(hostName)
        renderLobby(listOf(LobbyPlayer(0, hostName, ready = true, isHost = true)))

        val advertiser = LanAdvertiser(this)
        GameSession.advertiser = advertiser
        advertiser.start(server.port, android.os.Build.MODEL.take(12)) { ok ->
            if (!ok) runOnUiThread {
                findViewById<TextView>(R.id.textHostSubtitle).text =
                    "Couldn't advertise on this network — other players may need to be told the IP manually."
            }
        }

        findViewById<MaterialButton>(R.id.btnStartMatch).setOnClickListener {
            val finalName = nameField.text.toString().ifBlank { "Host" }
            saveManager.setLastPlayerName(finalName)
            GameSession.world.findPlayer(0)?.name = finalName
            matchStarting = true
            GameSession.wave.beginMatch(SystemClock.elapsedRealtime())
            server.startMatch()
            startActivity(Intent(this, GameActivity::class.java))
        }
    }

    private fun renderLobby(players: List<LobbyPlayer>) {
        listAdapter.clear()
        for (p in players) {
            val label = if (p.isHost) getString(R.string.lobby_you_host, p.name)
            else "${p.name} — ${if (p.ready) getString(R.string.lobby_ready) else getString(R.string.lobby_not_ready)}"
            listAdapter.add(label)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!matchStarting) {
            GameSession.resetForNewLobby()
        }
    }
}
