package com.zsurvival.app.game

import com.zsurvival.app.game.ai.ZombieAI
import com.zsurvival.app.game.model.BulletState
import com.zsurvival.app.game.model.Obstacle
import com.zsurvival.app.game.model.PlayerInput
import com.zsurvival.app.game.model.PlayerState
import com.zsurvival.app.game.weapon.WeaponType
import com.zsurvival.app.util.MathUtils
import kotlin.math.sqrt

/**
 * Runs ONLY on the host, ONLY on the game-loop thread. Pure logic — no
 * networking, no Android imports — so it stays easy to extend when more
 * weapons/zombie types/maps show up.
 */
object GameSimulation {

    const val PLAYER_RADIUS = 22f
    const val PLAYER_SPEED = 260f
    const val ZOMBIE_HIT_RADIUS = 30f

    private var nextBulletId = 1

    fun tick(
        world: GameWorld,
        wave: WaveManager,
        obstacles: List<Obstacle>,
        dt: Float,
        nowMs: Long,
        onWaveStart: ((Int) -> Unit)? = null
    ) {
        if (world.gameOver) return

        for (player in world.players) {
            if (!player.alive) continue
            val input = world.inputs[player.id] ?: PlayerInput()
            updatePlayer(world, player, input, obstacles, dt, nowMs)
        }

        updateBullets(world, dt, nowMs)
        checkBulletZombieHits(world)
        updateZombies(world, dt, nowMs)

        val waveStarted = wave.update(nowMs, world.aliveZombieCount()) { z ->
            world.zombies.add(z)
        }
        if (waveStarted) onWaveStart?.invoke(wave.currentWave)

        if (world.allPlayersDead() && !world.gameOver) {
            world.gameOver = true
            world.gameOverWave = wave.currentWave
        }
    }

    private fun updatePlayer(
        world: GameWorld,
        player: PlayerState,
        input: PlayerInput,
        obstacles: List<Obstacle>,
        dt: Float,
        nowMs: Long
    ) {
        // Movement
        val (mx, my) = MathUtils.normalize(input.moveX, input.moveY)
        var newX = player.x + mx * PLAYER_SPEED * dt
        var newY = player.y + my * PLAYER_SPEED * dt
        newX = MathUtils.clamp(newX, PLAYER_RADIUS, MapData.WORLD_WIDTH - PLAYER_RADIUS)
        newY = MathUtils.clamp(newY, PLAYER_RADIUS, MapData.WORLD_HEIGHT - PLAYER_RADIUS)
        val (rx, ry) = resolveObstacleCollision(newX, newY, PLAYER_RADIUS, obstacles)
        player.x = rx
        player.y = ry
        player.targetX = player.x
        player.targetY = player.y

        // Aim — host is authoritative for its own view of this player, so
        // target == current directly (targetAngle only matters on a client
        // rendering a *remote* player, see GameView's interpolation step).
        player.angle = input.aimAngle
        player.targetAngle = input.aimAngle

        // Reload completion
        if (player.reloading && nowMs >= player.reloadEndAtMs) {
            player.reloading = false
            player.ammoInMag = player.magSize
        }

        // Explicit reload request
        if (input.reload && !player.reloading && player.ammoInMag < player.magSize) {
            player.reloading = true
            player.reloadEndAtMs = nowMs + WeaponType.PISTOL.reloadTimeMs
        }

        // Firing — auto-fire while the aim stick is held past its deadzone
        // (VirtualJoystick only reports non-zero aim once past that), gated
        // by fire rate and ammo. Empty mag + trying to fire auto-starts a reload.
        if (input.firing && !player.reloading) {
            if (player.ammoInMag <= 0) {
                player.reloading = true
                player.reloadEndAtMs = nowMs + WeaponType.PISTOL.reloadTimeMs
            } else if (nowMs - player.lastShotAtMs >= WeaponType.PISTOL.fireCooldownMs) {
                player.lastShotAtMs = nowMs
                player.ammoInMag--
                world.bullets.add(spawnBullet(player, nowMs))
            }
        }
    }

    private fun spawnBullet(player: PlayerState, nowMs: Long): BulletState {
        val weapon = WeaponType.PISTOL
        val ox = player.x + MathUtils.cosOf(player.angle) * (PLAYER_RADIUS + 4f)
        val oy = player.y + MathUtils.sinOf(player.angle) * (PLAYER_RADIUS + 4f)
        val vx = MathUtils.cosOf(player.angle) * weapon.bulletSpeed
        val vy = MathUtils.sinOf(player.angle) * weapon.bulletSpeed
        val lifetimeMs = ((weapon.range / weapon.bulletSpeed) * 1000).toLong()
        return BulletState(
            id = nextBulletId++,
            ownerId = player.id,
            x = ox, y = oy, vx = vx, vy = vy,
            spawnAtMs = nowMs,
            expiresAtMs = nowMs + lifetimeMs,
            damage = weapon.damage
        )
    }

    private fun updateBullets(world: GameWorld, dt: Float, nowMs: Long) {
        val toRemove = ArrayList<Int>()
        for (b in world.bullets) {
            b.x += b.vx * dt
            b.y += b.vy * dt
            if (nowMs >= b.expiresAtMs ||
                b.x < 0f || b.x > MapData.WORLD_WIDTH ||
                b.y < 0f || b.y > MapData.WORLD_HEIGHT
            ) {
                toRemove.add(b.id)
            }
        }
        for (id in toRemove) world.removeBullet(id)
    }

    private fun checkBulletZombieHits(world: GameWorld) {
        val bulletsToRemove = HashSet<Int>()
        val zombiesToRemove = HashSet<Int>()
        for (bullet in world.bullets) {
            if (bullet.id in bulletsToRemove) continue
            for (zombie in world.zombies) {
                if (zombie.id in zombiesToRemove) continue
                val distSq = MathUtils.distanceSq(bullet.x, bullet.y, zombie.x, zombie.y)
                if (distSq <= ZOMBIE_HIT_RADIUS * ZOMBIE_HIT_RADIUS) {
                    zombie.health -= bullet.damage
                    bulletsToRemove.add(bullet.id)
                    if (zombie.health <= 0) {
                        zombiesToRemove.add(zombie.id)
                        world.findPlayer(bullet.ownerId)?.let { it.money += 10 }
                    }
                    break
                }
            }
        }
        bulletsToRemove.forEach { world.removeBullet(it) }
        zombiesToRemove.forEach { world.removeZombie(it) }
    }

    private fun updateZombies(world: GameWorld, dt: Float, nowMs: Long) {
        for (zombie in world.zombies) {
            val attacked = ZombieAI.step(zombie, world.players, dt, nowMs)
            if (attacked != null) {
                attacked.health -= ZombieAI.ATTACK_DAMAGE
                if (attacked.health <= 0) {
                    attacked.health = 0
                    attacked.alive = false
                }
            }
            zombie.targetX = zombie.x
            zombie.targetY = zombie.y
        }
    }

    /** Circle (player) vs axis-aligned rectangle (obstacle) push-out. */
    private fun resolveObstacleCollision(x: Float, y: Float, radius: Float, obstacles: List<Obstacle>): Pair<Float, Float> {
        var px = x
        var py = y
        for (o in obstacles) {
            val closestX = px.coerceIn(o.x, o.x + o.w)
            val closestY = py.coerceIn(o.y, o.y + o.h)
            val dx = px - closestX
            val dy = py - closestY
            val distSq = dx * dx + dy * dy
            if (distSq < radius * radius) {
                val dist = sqrt(distSq.toDouble()).toFloat()
                if (dist < 0.0001f) {
                    py -= radius // center exactly on/in an edge: push up, rare edge case
                } else {
                    val nx = dx / dist
                    val ny = dy / dist
                    val pushDist = radius - dist
                    px += nx * pushDist
                    py += ny * pushDist
                }
            }
        }
        return px to py
    }
}
