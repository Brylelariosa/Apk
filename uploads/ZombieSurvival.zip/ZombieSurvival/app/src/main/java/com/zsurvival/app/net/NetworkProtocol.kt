package com.zsurvival.app.net

import com.zsurvival.app.game.GameWorld
import com.zsurvival.app.game.model.BulletSnap
import com.zsurvival.app.game.model.LobbyPlayer
import com.zsurvival.app.game.model.PlayerInput
import com.zsurvival.app.game.model.PlayerSnap
import com.zsurvival.app.game.model.StateSnapshot
import com.zsurvival.app.game.model.ZombieSnap
import org.json.JSONArray
import org.json.JSONObject

/**
 * Newline-delimited JSON over TCP. Verbose compared to a packed binary
 * format, but this is LAN traffic for 2-3 players — bandwidth was never
 * the constraint, getting it right without a compiler in the loop was.
 * Every message has a "type" field; peekType() reads just that so callers
 * can dispatch before doing the full per-type parse.
 */
object NetworkProtocol {

    const val TYPE_JOIN = "JOIN"
    const val TYPE_WELCOME = "WELCOME"
    const val TYPE_LOBBY = "LOBBY"
    const val TYPE_READY = "READY"
    const val TYPE_START = "START"
    const val TYPE_INPUT = "INPUT"
    const val TYPE_STATE = "STATE"
    const val TYPE_PING = "PING"
    const val TYPE_PONG = "PONG"
    const val TYPE_GAMEOVER = "GAMEOVER"

    fun peekType(json: JSONObject): String = json.optString("type", "")

    fun parseLine(line: String): JSONObject? = try {
        JSONObject(line)
    } catch (e: Exception) {
        null
    }

    // ---- JOIN ----
    fun buildJoin(name: String): String = JSONObject().put("type", TYPE_JOIN).put("name", name).toString()
    fun parseJoinName(json: JSONObject): String = json.optString("name", "Player").ifBlank { "Player" }

    // ---- WELCOME ----
    fun buildWelcome(id: Int): String = JSONObject().put("type", TYPE_WELCOME).put("id", id).toString()
    fun parseWelcomeId(json: JSONObject): Int = json.optInt("id", -1)

    // ---- LOBBY ----
    fun buildLobby(players: List<LobbyPlayer>): String {
        val arr = JSONArray()
        for (p in players) {
            val po = JSONObject()
            po.put("id", p.id)
            po.put("name", p.name)
            po.put("ready", p.ready)
            po.put("host", p.isHost)
            arr.put(po)
        }
        return JSONObject().put("type", TYPE_LOBBY).put("players", arr).toString()
    }

    fun parseLobby(json: JSONObject): List<LobbyPlayer> {
        val arr = json.optJSONArray("players") ?: JSONArray()
        val list = ArrayList<LobbyPlayer>(arr.length())
        for (i in 0 until arr.length()) {
            val po = arr.getJSONObject(i)
            list.add(
                LobbyPlayer(
                    id = po.optInt("id", -1),
                    name = po.optString("name", "Player"),
                    ready = po.optBoolean("ready", false),
                    isHost = po.optBoolean("host", false)
                )
            )
        }
        return list
    }

    // ---- READY / START ----
    fun buildReady(): String = JSONObject().put("type", TYPE_READY).toString()
    fun buildStart(): String = JSONObject().put("type", TYPE_START).toString()

    // ---- INPUT ----
    fun buildInput(input: PlayerInput): String {
        val o = JSONObject()
        o.put("type", TYPE_INPUT)
        o.put("mx", input.moveX.toDouble())
        o.put("my", input.moveY.toDouble())
        o.put("aim", input.aimAngle.toDouble())
        o.put("fire", input.firing)
        o.put("reload", input.reload)
        return o.toString()
    }

    fun parseInput(json: JSONObject): PlayerInput = PlayerInput(
        moveX = json.optDouble("mx", 0.0).toFloat(),
        moveY = json.optDouble("my", 0.0).toFloat(),
        aimAngle = json.optDouble("aim", 0.0).toFloat(),
        firing = json.optBoolean("fire", false),
        reload = json.optBoolean("reload", false)
    )

    // ---- STATE ----
    fun buildState(wave: Int, world: GameWorld): String {
        val root = JSONObject()
        root.put("type", TYPE_STATE)
        root.put("wave", wave)
        root.put("over", world.gameOver)

        val playersArr = JSONArray()
        for (p in world.players) {
            val po = JSONObject()
            po.put("id", p.id)
            po.put("name", p.name)
            po.put("x", p.x.toDouble())
            po.put("y", p.y.toDouble())
            po.put("a", p.angle.toDouble())
            po.put("hp", p.health)
            po.put("mhp", p.maxHealth)
            po.put("ammo", p.ammoInMag)
            po.put("mag", p.magSize)
            po.put("alive", p.alive)
            po.put("money", p.money)
            po.put("reloading", p.reloading)
            playersArr.put(po)
        }
        root.put("players", playersArr)

        val zombiesArr = JSONArray()
        for (z in world.zombies) {
            val zo = JSONObject()
            zo.put("id", z.id)
            zo.put("type", z.type.wireId)
            zo.put("x", z.x.toDouble())
            zo.put("y", z.y.toDouble())
            zo.put("hp", z.health)
            zo.put("mhp", z.maxHealth)
            zombiesArr.put(zo)
        }
        root.put("zombies", zombiesArr)

        val bulletsArr = JSONArray()
        for (b in world.bullets) {
            val bo = JSONObject()
            bo.put("id", b.id)
            bo.put("owner", b.ownerId)
            bo.put("x", b.x.toDouble())
            bo.put("y", b.y.toDouble())
            bo.put("vx", b.vx.toDouble())
            bo.put("vy", b.vy.toDouble())
            bulletsArr.put(bo)
        }
        root.put("bullets", bulletsArr)

        return root.toString()
    }

    fun parseState(json: JSONObject): StateSnapshot {
        val players = ArrayList<PlayerSnap>()
        val parr = json.optJSONArray("players") ?: JSONArray()
        for (i in 0 until parr.length()) {
            val po = parr.getJSONObject(i)
            players.add(
                PlayerSnap(
                    id = po.optInt("id", -1),
                    name = po.optString("name", ""),
                    x = po.optDouble("x", 0.0).toFloat(),
                    y = po.optDouble("y", 0.0).toFloat(),
                    angle = po.optDouble("a", 0.0).toFloat(),
                    hp = po.optInt("hp", 0),
                    maxHp = po.optInt("mhp", 100),
                    ammo = po.optInt("ammo", 0),
                    mag = po.optInt("mag", 0),
                    alive = po.optBoolean("alive", true),
                    money = po.optInt("money", 0),
                    reloading = po.optBoolean("reloading", false)
                )
            )
        }

        val zombies = ArrayList<ZombieSnap>()
        val zarr = json.optJSONArray("zombies") ?: JSONArray()
        for (i in 0 until zarr.length()) {
            val zo = zarr.getJSONObject(i)
            zombies.add(
                ZombieSnap(
                    id = zo.optInt("id", -1),
                    type = zo.optInt("type", 0),
                    x = zo.optDouble("x", 0.0).toFloat(),
                    y = zo.optDouble("y", 0.0).toFloat(),
                    hp = zo.optInt("hp", 0),
                    maxHp = zo.optInt("mhp", 1)
                )
            )
        }

        val bullets = ArrayList<BulletSnap>()
        val barr = json.optJSONArray("bullets") ?: JSONArray()
        for (i in 0 until barr.length()) {
            val bo = barr.getJSONObject(i)
            bullets.add(
                BulletSnap(
                    id = bo.optInt("id", -1),
                    ownerId = bo.optInt("owner", -1),
                    x = bo.optDouble("x", 0.0).toFloat(),
                    y = bo.optDouble("y", 0.0).toFloat(),
                    vx = bo.optDouble("vx", 0.0).toFloat(),
                    vy = bo.optDouble("vy", 0.0).toFloat()
                )
            )
        }

        return StateSnapshot(
            wave = json.optInt("wave", 0),
            players = players,
            zombieIds = zombies,
            bulletIds = bullets,
            gameOver = json.optBoolean("over", false)
        )
    }

    // ---- PING / PONG ----
    fun buildPing(t: Long): String = JSONObject().put("type", TYPE_PING).put("t", t).toString()
    fun buildPong(t: Long): String = JSONObject().put("type", TYPE_PONG).put("t", t).toString()
    fun parseTimestamp(json: JSONObject): Long = json.optLong("t", 0L)

    // ---- GAME OVER ----
    fun buildGameOver(wave: Int): String = JSONObject().put("type", TYPE_GAMEOVER).put("wave", wave).toString()
    fun parseGameOverWave(json: JSONObject): Int = json.optInt("wave", 0)
}
