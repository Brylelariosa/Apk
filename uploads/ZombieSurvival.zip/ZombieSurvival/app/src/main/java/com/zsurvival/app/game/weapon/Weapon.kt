package com.zsurvival.app.game.weapon

/**
 * Pure data — firing behavior lives in GameSimulation so it has access to
 * the bullet list / id generator. Flamethrower and Rocket Launcher are
 * deliberately not here yet: they need a genuinely different damage model
 * (a continuous cone, and splash-on-impact) rather than just new stats on
 * the existing single-point-hit bullet, so they're a separate pass, not
 * just another enum entry.
 */
enum class WeaponType(
    val displayName: String,
    val damage: Int,
    val fireCooldownMs: Long,
    val magazineSize: Int,
    val reloadTimeMs: Long,
    val bulletSpeed: Float,
    val range: Float,
    val cost: Int,
    val pelletCount: Int = 1,
    val spreadDegrees: Float = 0f
) {
    PISTOL(
        displayName = "Pistol",
        damage = 18,
        fireCooldownMs = 260,
        magazineSize = 12,
        reloadTimeMs = 1100,
        bulletSpeed = 900f,
        range = 750f,
        cost = 0 // starting weapon, not for sale
    ),
    SHOTGUN(
        displayName = "Shotgun",
        damage = 14,
        fireCooldownMs = 700,
        magazineSize = 6,
        reloadTimeMs = 1800,
        bulletSpeed = 850f,
        range = 420f,
        cost = 150,
        pelletCount = 5,
        spreadDegrees = 18f
    ),
    SMG(
        displayName = "SMG",
        damage = 10,
        fireCooldownMs = 90,
        magazineSize = 30,
        reloadTimeMs = 1400,
        bulletSpeed = 950f,
        range = 600f,
        cost = 200
    ),
    ASSAULT_RIFLE(
        displayName = "Assault Rifle",
        damage = 22,
        fireCooldownMs = 140,
        magazineSize = 25,
        reloadTimeMs = 1600,
        bulletSpeed = 1000f,
        range = 800f,
        cost = 350
    ),
    SNIPER_RIFLE(
        displayName = "Sniper Rifle",
        damage = 85,
        fireCooldownMs = 950,
        magazineSize = 5,
        reloadTimeMs = 2200,
        bulletSpeed = 1400f,
        range = 1400f,
        cost = 400
    ),
    LMG(
        displayName = "LMG",
        damage = 20,
        fireCooldownMs = 110,
        magazineSize = 60,
        reloadTimeMs = 2600,
        bulletSpeed = 950f,
        range = 750f,
        cost = 450
    );

    /** Weapons other than the starting pistol, in shop display order. */
    companion object {
        val purchasable: List<WeaponType> = listOf(SHOTGUN, SMG, ASSAULT_RIFLE, SNIPER_RIFLE, LMG)
    }
}
