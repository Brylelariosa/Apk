package com.zsurvival.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.zsurvival.app.data.SaveManager
import com.zsurvival.app.game.GameView

class GameActivity : AppCompatActivity() {

    private lateinit var saveManager: SaveManager
    @Volatile private var returnedToMenu = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)
        saveManager = SaveManager(this)

        val gameView = findViewById<GameView>(R.id.gameView)

        // Fires from the game-loop thread, not the UI thread — SharedPreferences.apply()
        // is documented thread-safe, so no runOnUiThread hop needed here.
        gameView.onGameOverListener = { wave -> saveManager.reportWaveReached(wave) }

        // Fires from onTouchEvent, which Android already dispatches on the UI thread.
        gameView.onReturnToMenuRequested = { returnToMenu() }
    }

    private fun returnToMenu() {
        if (returnedToMenu) return
        returnedToMenu = true
        GameSession.endMatch()
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        GameSession.endMatch()
    }
}
