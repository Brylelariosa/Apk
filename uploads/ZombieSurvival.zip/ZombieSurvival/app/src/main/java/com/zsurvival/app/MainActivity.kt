package com.zsurvival.app

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.zsurvival.app.data.SaveManager

class MainActivity : AppCompatActivity() {

    private lateinit var saveManager: SaveManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        saveManager = SaveManager(this)

        findViewById<TextView>(R.id.textBestWave).text =
            getString(R.string.menu_best_wave, saveManager.getHighestWave())

        findViewById<MaterialButton>(R.id.btnHost).setOnClickListener {
            startActivity(Intent(this, HostLobbyActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnJoin).setOnClickListener {
            startActivity(Intent(this, JoinLobbyActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener { showComingSoon() }
        findViewById<MaterialButton>(R.id.btnAchievements).setOnClickListener { showComingSoon() }
        findViewById<MaterialButton>(R.id.btnExit).setOnClickListener { finishAffinity() }
    }

    override fun onResume() {
        super.onResume()
        // Refresh in case a match just finished with a new best.
        findViewById<TextView>(R.id.textBestWave).text =
            getString(R.string.menu_best_wave, saveManager.getHighestWave())
    }

    private fun showComingSoon() {
        Toast.makeText(this, R.string.toast_coming_soon, Toast.LENGTH_SHORT).show()
    }
}
