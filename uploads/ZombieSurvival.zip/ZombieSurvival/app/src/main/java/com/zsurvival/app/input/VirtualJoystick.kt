package com.zsurvival.app.input

import android.graphics.Canvas
import android.graphics.Paint
import com.zsurvival.app.util.MathUtils

/**
 * Not an Android View — GameView owns the single Canvas/touch dispatch for
 * the whole screen and routes pointer events into instances of this class
 * by hit-testing [tryActivate]. Two of these make up the move+aim sticks.
 */
class VirtualJoystick(private val deadzoneRatio: Float = 0.18f) {

    var centerX: Float = 0f
        private set
    var centerY: Float = 0f
        private set
    var radius: Float = 1f
        private set

    private var knobOffsetX: Float = 0f
    private var knobOffsetY: Float = 0f

    @Volatile private var activePointerId: Int = -1

    fun configure(cx: Float, cy: Float, r: Float) {
        centerX = cx
        centerY = cy
        radius = r
    }

    val isActive: Boolean get() = activePointerId != -1

    /** Normalized displacement, each in [-1, 1]. */
    val normX: Float get() = if (radius <= 0f) 0f else MathUtils.clamp(knobOffsetX / radius, -1f, 1f)
    val normY: Float get() = if (radius <= 0f) 0f else MathUtils.clamp(knobOffsetY / radius, -1f, 1f)

    /** True once displacement passes the deadzone — used to gate auto-fire
     * and to avoid drift from a barely-touched stick. */
    val isPastDeadzone: Boolean get() {
        val mag = MathUtils.distance(0f, 0f, normX, normY)
        return mag >= deadzoneRatio
    }

    val angle: Float get() = MathUtils.angleTo(0f, 0f, knobOffsetX, knobOffsetY)

    /** A slightly larger grab radius than the visible base makes the stick
     * easier to engage with a thumb without needing pixel-perfect taps. */
    fun tryActivate(pointerId: Int, touchX: Float, touchY: Float): Boolean {
        if (activePointerId != -1) return false
        val grabRadius = radius * 1.8f
        if (MathUtils.distance(touchX, touchY, centerX, centerY) > grabRadius) return false
        activePointerId = pointerId
        updateKnob(touchX, touchY)
        return true
    }

    fun onMove(pointerId: Int, touchX: Float, touchY: Float) {
        if (pointerId != activePointerId) return
        updateKnob(touchX, touchY)
    }

    fun onUp(pointerId: Int) {
        if (pointerId != activePointerId) return
        activePointerId = -1
        knobOffsetX = 0f
        knobOffsetY = 0f
    }

    fun forceReset() {
        activePointerId = -1
        knobOffsetX = 0f
        knobOffsetY = 0f
    }

    private fun updateKnob(touchX: Float, touchY: Float) {
        var dx = touchX - centerX
        var dy = touchY - centerY
        val dist = MathUtils.distance(0f, 0f, dx, dy)
        if (dist > radius && dist > 0f) {
            val scale = radius / dist
            dx *= scale
            dy *= scale
        }
        knobOffsetX = dx
        knobOffsetY = dy
    }

    fun draw(canvas: Canvas, basePaint: Paint, knobPaint: Paint) {
        canvas.drawCircle(centerX, centerY, radius, basePaint)
        canvas.drawCircle(centerX + knobOffsetX, centerY + knobOffsetY, radius * 0.42f, knobPaint)
    }
}
