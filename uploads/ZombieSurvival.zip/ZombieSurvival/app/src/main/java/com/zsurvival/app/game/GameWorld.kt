package com.zsurvival.app.game

import com.zsurvival.app.game.model.BulletState
import com.zsurvival.app.game.model.PlayerInput
import com.zsurvival.app.game.model.PlayerState
import com.zsurvival.app.game.model.StateSnapshot
import com.zsurvival.app.game.model.ZombieState
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Holds all live entities. CopyOnWriteArrayList is intentional here, not an
 * oversight: entity counts are small (a couple dozen at most for 2-3
 * players), writes (spawn/despawn) are infrequent relative to reads
 * (render happens every frame), and it lets the render loop iterate
 * without any locking. See GameModels.kt for the single-writer rule that
 * keeps mutation of the entities themselves safe.
 */
class GameWorld {
    val players = CopyOnWriteArrayList<PlayerState>()
    val zombies = CopyOnWriteArrayList<ZombieState>()
    val bullets = CopyOnWriteArrayList<BulletState>()

    /** Host only: latest input per player id, written by network reader
     * threads (remote players) and the UI thread (local player), read by
     * the sim tick. Always replaced wholesale, never mutated in place. */
    val inputs = ConcurrentHashMap<Int, PlayerInput>()

    /** Client only: swapped atomically by the network reader thread each
     * time a STATE message arrives; consumed by the render loop. */
    @Volatile var latestSnapshot: StateSnapshot? = null

    @Volatile var gameOver: Boolean = false
    @Volatile var gameOverWave: Int = 0

    fun findPlayer(id: Int): PlayerState? = players.firstOrNull { it.id == id }

    fun removeZombie(id: Int) {
        zombies.removeIf { it.id == id }
    }

    fun removeBullet(id: Int) {
        bullets.removeIf { it.id == id }
    }

    fun aliveZombieCount(): Int = zombies.size

    fun allPlayersDead(): Boolean = players.isNotEmpty() && players.all { !it.alive }

    fun reset() {
        players.clear()
        zombies.clear()
        bullets.clear()
        inputs.clear()
        latestSnapshot = null
        gameOver = false
        gameOverWave = 0
    }
}
