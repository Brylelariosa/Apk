package com.zsurvival.app.util

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

object MathUtils {

    /** Linear interpolation. */
    fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t.coerceIn(0f, 1f)

    /** Distance between two points. */
    fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float =
        hypot((x2 - x1).toDouble(), (y2 - y1).toDouble()).toFloat()

    /** Squared distance — cheaper when you only need to compare distances. */
    fun distanceSq(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return dx * dx + dy * dy
    }

    /** Angle in radians from (x1,y1) toward (x2,y2), 0 = facing +X, increases clockwise in screen space. */
    fun angleTo(x1: Float, y1: Float, x2: Float, y2: Float): Float =
        atan2((y2 - y1).toDouble(), (x2 - x1).toDouble()).toFloat()

    fun clamp(v: Float, min: Float, max: Float): Float = if (v < min) min else if (v > max) max else v

    fun clampInt(v: Int, min: Int, max: Int): Int = if (v < min) min else if (v > max) max else v

    /** Normalizes a (dx, dy) vector, returns Pair(nx, ny). Returns (0,0) if length is ~0. */
    fun normalize(dx: Float, dy: Float): Pair<Float, Float> {
        val len = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        return if (len < 0.0001f) 0f to 0f else (dx / len) to (dy / len)
    }

    fun cosOf(angle: Float): Float = cos(angle.toDouble()).toFloat()
    fun sinOf(angle: Float): Float = sin(angle.toDouble()).toFloat()

    /** Axis-aligned rectangle overlap test. */
    fun rectsOverlap(
        ax: Float, ay: Float, aw: Float, ah: Float,
        bx: Float, by: Float, bw: Float, bh: Float
    ): Boolean = ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by
}
