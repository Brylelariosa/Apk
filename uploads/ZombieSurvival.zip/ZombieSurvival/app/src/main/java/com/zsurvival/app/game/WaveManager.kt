package com.zsurvival.app.game

import com.zsurvival.app.game.model.ZombieState
import com.zsurvival.app.game.model.ZombieType
import kotlin.random.Random

/**
 * Host-only. Owns the "how many zombies, how tough, how fast are they
 * trickling in" curve. Bosses-every-10-waves, Spitter/Exploder/Crawler/
 * Runner/Tank variety, and random events (fog, power outage, double
 * zombies...) all plug in here later — right now it only ever spawns
 * ZombieType.NORMAL.
 */
class WaveManager {

    var currentWave: Int = 0
        private set
    var waveActive: Boolean = false
        private set
    var zombiesRemainingToSpawn: Int = 0
        private set

    private var nextSpawnAtMs: Long = 0L
    private var intermissionEndAtMs: Long = 0L
    private var nextZombieId = 1

    companion object {
        private const val SPAWN_INTERVAL_MS = 900L
        private const val INTERMISSION_MS = 8000L
        private const val BASE_HEALTH = 40
        private const val BASE_SPEED = 90f
    }

    fun beginMatch(nowMs: Long) {
        currentWave = 0
        waveActive = false
        intermissionEndAtMs = nowMs + 3000L
    }

    /** Clients don't run update() themselves (only the host simulates waves) —
     * this lets GameView mirror the wave number from each STATE broadcast so
     * the HUD shows the real value instead of being stuck at 0. */
    fun syncFromNetwork(w: Int) {
        currentWave = w
    }

    private fun zombiesForWave(wave: Int): Int = 4 + wave * 2

    private fun healthForWave(wave: Int): Int = (BASE_HEALTH * (1f + 0.15f * (wave - 1))).toInt()

    private fun speedForWave(wave: Int): Float =
        BASE_SPEED * (1f + 0.05f * (wave - 1)).coerceAtMost(1.6f)

    /**
     * Call every tick. Spawns zombies into [onSpawn] as needed and returns
     * true exactly on the frame a new wave officially starts (useful for a
     * "WAVE N INCOMING" banner).
     */
    fun update(nowMs: Long, aliveZombieCount: Int, onSpawn: (ZombieState) -> Unit): Boolean {
        if (!waveActive) {
            if (nowMs >= intermissionEndAtMs) {
                currentWave++
                waveActive = true
                zombiesRemainingToSpawn = zombiesForWave(currentWave)
                nextSpawnAtMs = nowMs
                return true
            }
            return false
        }

        if (zombiesRemainingToSpawn > 0 && nowMs >= nextSpawnAtMs) {
            spawnOne(nowMs, onSpawn)
            zombiesRemainingToSpawn--
            nextSpawnAtMs = nowMs + SPAWN_INTERVAL_MS
        }

        if (zombiesRemainingToSpawn == 0 && aliveZombieCount == 0) {
            waveActive = false
            intermissionEndAtMs = nowMs + INTERMISSION_MS
        }
        return false
    }

    private fun spawnOne(nowMs: Long, onSpawn: (ZombieState) -> Unit) {
        val (sx, sy) = MapData.zombieSpawnPoints[Random.nextInt(MapData.zombieSpawnPoints.size)]
        val z = ZombieState(id = nextZombieId++, type = ZombieType.NORMAL)
        z.x = sx
        z.y = sy
        z.maxHealth = healthForWave(currentWave)
        z.health = z.maxHealth
        z.speed = speedForWave(currentWave)
        onSpawn(z)
    }
}
