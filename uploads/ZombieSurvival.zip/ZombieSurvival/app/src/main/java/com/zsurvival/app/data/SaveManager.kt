package com.zsurvival.app.data

import android.content.Context

/**
 * Deliberately tiny for now — highest wave + lifetime coins is enough to
 * make the main menu feel persistent. Weapon unlocks / achievements /
 * per-difficulty stats are a natural extension of this same file once
 * the shop and achievement systems exist.
 */
class SaveManager(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getHighestWave(): Int = prefs.getInt(KEY_HIGHEST_WAVE, 0)

    /** Returns true if this was a new best. */
    fun reportWaveReached(wave: Int): Boolean {
        val best = getHighestWave()
        if (wave > best) {
            prefs.edit().putInt(KEY_HIGHEST_WAVE, wave).apply()
            return true
        }
        return false
    }

    fun getLifetimeCoins(): Int = prefs.getInt(KEY_LIFETIME_COINS, 0)

    fun addLifetimeCoins(amount: Int) {
        if (amount <= 0) return
        prefs.edit().putInt(KEY_LIFETIME_COINS, getLifetimeCoins() + amount).apply()
    }

    fun getLastPlayerName(): String = prefs.getString(KEY_LAST_NAME, "") ?: ""

    fun setLastPlayerName(name: String) {
        prefs.edit().putString(KEY_LAST_NAME, name).apply()
    }

    companion object {
        private const val PREFS_NAME = "zombie_survival_save"
        private const val KEY_HIGHEST_WAVE = "highest_wave"
        private const val KEY_LIFETIME_COINS = "lifetime_coins"
        private const val KEY_LAST_NAME = "last_name"
    }
}
