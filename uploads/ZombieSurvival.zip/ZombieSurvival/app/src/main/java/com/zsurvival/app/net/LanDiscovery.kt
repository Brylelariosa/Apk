package com.zsurvival.app.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.util.Log

const val NSD_SERVICE_TYPE = "_zsurvival._tcp."
private const val TAG = "LanDiscovery"

data class DiscoveredHost(val serviceName: String, val address: String, val port: Int)

/** Host side: advertises this device on the LAN so JoinLobbyActivity can find it. */
class LanAdvertiser(private val context: Context) {

    private val nsdManager: NsdManager by lazy {
        context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    }
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    fun start(serverPort: Int, hostLabel: String, onResult: (success: Boolean) -> Unit) {
        acquireMulticastLock()
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = "ZSurvival-$hostLabel"
            serviceType = NSD_SERVICE_TYPE
            port = serverPort
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {
                onResult(true)
            }
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {
                Log.w(TAG, "NSD registration failed: $errorCode")
                onResult(false)
            }
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }
        registrationListener = listener
        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.w(TAG, "registerService threw", e)
            onResult(false)
        }
    }

    fun stop() {
        try {
            registrationListener?.let { nsdManager.unregisterService(it) }
        } catch (e: Exception) {
            Log.w(TAG, "unregisterService threw", e)
        }
        registrationListener = null
        releaseMulticastLock()
    }

    private fun acquireMulticastLock() {
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifi?.createMulticastLock("zsurvival_host_lock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "multicast lock acquire failed", e)
        }
    }

    private fun releaseMulticastLock() {
        try {
            if (multicastLock?.isHeld == true) multicastLock?.release()
        } catch (e: Exception) {
            Log.w(TAG, "multicast lock release failed", e)
        }
        multicastLock = null
    }
}

/**
 * Client side: browses for advertised hosts. Callbacks may arrive on a
 * non-UI thread (NsdManager doesn't guarantee one on API < 33) — callers
 * must hop to the main thread themselves before touching views.
 */
class LanBrowser(private val context: Context) {

    private val nsdManager: NsdManager by lazy {
        context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    }
    private var discoveryListener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    private val resolveQueue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private val seenServiceNames = HashSet<String>()

    private var onHostFound: ((DiscoveredHost) -> Unit)? = null
    private var onHostLost: ((String) -> Unit)? = null

    fun start(onFound: (DiscoveredHost) -> Unit, onLost: (String) -> Unit) {
        onHostFound = onFound
        onHostLost = onLost
        acquireMulticastLock()

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}

            override fun onServiceFound(service: NsdServiceInfo) {
                synchronized(resolveQueue) {
                    if (seenServiceNames.contains(service.serviceName)) return
                    if (resolveQueue.any { it.serviceName == service.serviceName }) return
                    resolveQueue.addLast(service)
                    if (!resolving) {
                        resolving = true
                        resolveNext()
                    }
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                seenServiceNames.remove(service.serviceName)
                onHostLost?.invoke(service.serviceName)
            }

            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.w(TAG, "start discovery failed: $errorCode")
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
        discoveryListener = listener
        try {
            nsdManager.discoverServices(NSD_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Exception) {
            Log.w(TAG, "discoverServices threw", e)
        }
    }

    private fun resolveNext() {
        val next: NsdServiceInfo?
        synchronized(resolveQueue) {
            next = resolveQueue.removeFirstOrNull()
            resolving = next != null
        }
        val service = next ?: return
        try {
            nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                    synchronized(resolveQueue) { resolving = false }
                    resolveNext()
                }

                override fun onServiceResolved(info: NsdServiceInfo) {
                    seenServiceNames.add(info.serviceName)
                    val address = info.host?.hostAddress
                    if (address != null) {
                        onHostFound?.invoke(DiscoveredHost(info.serviceName, address, info.port))
                    }
                    synchronized(resolveQueue) { resolving = false }
                    resolveNext()
                }
            })
        } catch (e: Exception) {
            Log.w(TAG, "resolveService threw", e)
            synchronized(resolveQueue) { resolving = false }
            resolveNext()
        }
    }

    fun stop() {
        try {
            discoveryListener?.let { nsdManager.stopServiceDiscovery(it) }
        } catch (e: Exception) {
            Log.w(TAG, "stopServiceDiscovery threw", e)
        }
        discoveryListener = null
        synchronized(resolveQueue) {
            resolveQueue.clear()
            resolving = false
        }
        seenServiceNames.clear()
        releaseMulticastLock()
    }

    private fun acquireMulticastLock() {
        try {
            val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wifi?.createMulticastLock("zsurvival_client_lock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "multicast lock acquire failed", e)
        }
    }

    private fun releaseMulticastLock() {
        try {
            if (multicastLock?.isHeld == true) multicastLock?.release()
        } catch (e: Exception) {
            Log.w(TAG, "multicast lock release failed", e)
        }
        multicastLock = null
    }
}
