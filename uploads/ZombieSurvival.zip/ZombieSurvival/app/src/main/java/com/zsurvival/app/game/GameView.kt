package com.zsurvival.app.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.zsurvival.app.GameSession
import com.zsurvival.app.R
import com.zsurvival.app.game.model.BulletState
import com.zsurvival.app.game.model.PlayerInput
import com.zsurvival.app.game.model.PlayerState
import com.zsurvival.app.game.model.StateSnapshot
import com.zsurvival.app.game.model.ZombieState
import com.zsurvival.app.game.model.ZombieType
import com.zsurvival.app.game.weapon.WeaponType
import com.zsurvival.app.input.VirtualJoystick
import com.zsurvival.app.util.MathUtils

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    /** Fired exactly once, the frame game-over is first detected (host or client). */
    var onGameOverListener: ((wave: Int) -> Unit)? = null
    /** Fired on tap once world.gameOver is true. */
    var onReturnToMenuRequested: (() -> Unit)? = null

    private val world get() = GameSession.world
    private val wave get() = GameSession.wave

    private var loopThread: LoopThread? = null
    private var screenWidth = 0
    private var screenHeight = 0

    private val moveStick = VirtualJoystick()
    private val aimStick = VirtualJoystick()
    private var reloadBtnX = 0f
    private var reloadBtnY = 0f
    private var reloadBtnRadius = 1f
    @Volatile private var reloadPointerId = -1
    @Volatile private var reloadPressed = false
    private var lastAimAngle = 0f

    @Volatile private var gameOverNotified = false
    private var waveBannerText: String? = null
    private var waveBannerUntilMs = 0L

    // ---- Paints, created once and reused every frame ----
    private val paintBg = Paint().apply { color = Color.parseColor("#14171C") }
    private val paintObstacle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#3A342A") }
    private val paintZombie = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4A5A57") }
    private val paintZombieOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E3835"); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val paintBullet = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2B441") }
    private val playerColors = intArrayOf(
        Color.parseColor("#D9772E"), // player 0 / host — rust accent
        Color.parseColor("#4E8FA6"), // player 1 — cool teal-blue
        Color.parseColor("#8C6FA6")  // player 2 — muted violet
    )
    private val playerBodyPaints = Array(playerColors.size) { i ->
        Paint(Paint.ANTI_ALIAS_FLAG).apply { color = playerColors[i] }
    }
    private val paintPlayerFacing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; strokeWidth = 4f
    }
    private val paintName = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EDEAE2"); textSize = 24f; textAlign = Paint.Align.CENTER
    }
    private val paintHud = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EDEAE2"); textSize = 34f
    }
    private val paintHudSmall = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A3A79E"); textSize = 24f
    }
    private val paintHealthBg = Paint().apply { color = Color.parseColor("#2A313C") }
    private val paintHealthGood = Paint().apply { color = Color.parseColor("#6FA671") }
    private val paintHealthLow = Paint().apply { color = Color.parseColor("#A6273B") }
    private val paintStickBase = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33FFFFFF"); style = Paint.Style.FILL
    }
    private val paintStickKnob = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D9772E") }
    private val paintStickKnobAim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4E8FA6") }
    private val paintReloadBtn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#55FFFFFF") }
    private val paintReloadBtnActive = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2B441") }
    private val paintBanner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F2B441"); textSize = 46f; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val paintOverlayBg = Paint().apply { color = Color.parseColor("#CC14171C") }
    private val paintOverlayTitle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A6273B"); textSize = 64f; textAlign = Paint.Align.CENTER; isFakeBoldText = true
    }
    private val paintOverlayBody = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EDEAE2"); textSize = 32f; textAlign = Paint.Align.CENTER
    }
    private val paintHudRight = Paint(paintHud).apply { textAlign = Paint.Align.RIGHT }
    private val paintHudSmallRight = Paint(paintHudSmall).apply { textAlign = Paint.Align.RIGHT }
    private val paintPingGood = Paint(paintHudSmallRight).apply { color = Color.parseColor("#6FA671") }
    private val paintPingWarn = Paint(paintHudSmallRight).apply { color = Color.parseColor("#F2B441") }
    private val paintPingBad = Paint(paintHudSmallRight).apply { color = Color.parseColor("#A6273B") }

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    // ---- Surface lifecycle ----
    override fun surfaceCreated(holder: SurfaceHolder) {
        val t = LoopThread()
        loopThread = t
        t.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        screenWidth = width
        screenHeight = height
        layoutControls()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        loopThread?.stopLoop()
        loopThread = null
    }

    private fun layoutControls() {
        val r = minOf(screenWidth, screenHeight) * 0.11f
        moveStick.configure(screenWidth * 0.16f, screenHeight * 0.72f, r)
        aimStick.configure(screenWidth * 0.84f, screenHeight * 0.72f, r)
        reloadBtnRadius = r * 0.4f
        reloadBtnX = screenWidth * 0.84f
        reloadBtnY = screenHeight * 0.72f - r * 1.9f
    }

    // ---- Touch input ----
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (world.gameOver) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) onReturnToMenuRequested?.invoke()
            return true
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = event.actionIndex
                handleDown(event.getPointerId(idx), event.getX(idx), event.getY(idx))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val id = event.getPointerId(i)
                    moveStick.onMove(id, event.getX(i), event.getY(i))
                    aimStick.onMove(id, event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val idx = event.actionIndex
                val id = event.getPointerId(idx)
                moveStick.onUp(id)
                aimStick.onUp(id)
                if (id == reloadPointerId) {
                    reloadPointerId = -1
                    reloadPressed = false
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                moveStick.forceReset()
                aimStick.forceReset()
                reloadPointerId = -1
                reloadPressed = false
            }
        }
        return true
    }

    private fun handleDown(id: Int, x: Float, y: Float) {
        if (moveStick.tryActivate(id, x, y)) return
        if (aimStick.tryActivate(id, x, y)) return
        if (MathUtils.distance(x, y, reloadBtnX, reloadBtnY) <= reloadBtnRadius * 1.7f) {
            reloadPointerId = id
            reloadPressed = true
        }
    }

    // ---- Simulation step ----
    private fun update(dt: Float, nowMs: Long) {
        if (screenWidth == 0 || screenHeight == 0) return
        if (world.gameOver) return

        val aiming = aimStick.isPastDeadzone
        if (aiming) lastAimAngle = aimStick.angle
        val input = PlayerInput(
            moveX = moveStick.normX,
            moveY = moveStick.normY,
            aimAngle = lastAimAngle,
            firing = aiming,
            reload = reloadPressed
        )

        if (GameSession.isHost) {
            world.inputs[GameSession.localPlayerId] = input
            GameSimulation.tick(world, wave, MapData.obstacles, dt, nowMs) { newWave ->
                waveBannerText = context.getString(R.string.wave_incoming, newWave)
                waveBannerUntilMs = nowMs + 2500L
            }
            GameSession.server?.broadcastState(wave.currentWave)
        } else {
            GameSession.client?.sendInput(input)
            GameSession.client?.tickPing(nowMs)
            clientUpdate(dt)
        }

        if (world.gameOver && !gameOverNotified) {
            gameOverNotified = true
            if (GameSession.isHost) GameSession.server?.broadcastGameOver(world.gameOverWave)
            onGameOverListener?.invoke(world.gameOverWave)
        }
    }

    private fun clientUpdate(dt: Float) {
        world.latestSnapshot?.let { snap ->
            syncPlayers(snap)
            syncZombies(snap)
            syncBullets(snap)
            wave.syncFromNetwork(snap.wave)
            world.gameOver = snap.gameOver
            if (snap.gameOver) world.gameOverWave = snap.wave
        }
        for (p in world.players) {
            p.x = MathUtils.lerp(p.x, p.targetX, LERP_FACTOR)
            p.y = MathUtils.lerp(p.y, p.targetY, LERP_FACTOR)
            p.angle = lerpAngle(p.angle, p.targetAngle, LERP_FACTOR)
        }
        for (z in world.zombies) {
            z.x = MathUtils.lerp(z.x, z.targetX, LERP_FACTOR)
            z.y = MathUtils.lerp(z.y, z.targetY, LERP_FACTOR)
        }
        for (b in world.bullets) {
            b.x += b.vx * dt
            b.y += b.vy * dt
        }
    }

    private fun syncPlayers(snap: StateSnapshot) {
        val seen = HashSet<Int>()
        for (ps in snap.players) {
            seen.add(ps.id)
            var p = world.findPlayer(ps.id)
            if (p == null) {
                p = PlayerState(ps.id, ps.name)
                p.x = ps.x; p.y = ps.y; p.angle = ps.angle
                world.players.add(p)
            }
            p.name = ps.name
            p.targetX = ps.x
            p.targetY = ps.y
            p.targetAngle = ps.angle
            p.health = ps.hp
            p.maxHealth = ps.maxHp
            p.ammoInMag = ps.ammo
            p.magSize = ps.mag
            p.alive = ps.alive
            p.money = ps.money
            p.reloading = ps.reloading
        }
        world.players.removeIf { it.id !in seen }
    }

    private fun syncZombies(snap: StateSnapshot) {
        val seen = HashSet<Int>()
        for (zs in snap.zombieIds) {
            seen.add(zs.id)
            var z = world.zombies.firstOrNull { it.id == zs.id }
            if (z == null) {
                z = ZombieState(zs.id, ZombieType.fromWireId(zs.type))
                z.x = zs.x; z.y = zs.y
                world.zombies.add(z)
            }
            z.targetX = zs.x
            z.targetY = zs.y
            z.health = zs.hp
            z.maxHealth = zs.maxHp
        }
        world.zombies.removeIf { it.id !in seen }
    }

    private fun syncBullets(snap: StateSnapshot) {
        val seen = HashSet<Int>()
        for (bs in snap.bulletIds) {
            seen.add(bs.id)
            if (world.bullets.none { it.id == bs.id }) {
                world.bullets.add(
                    BulletState(
                        id = bs.id, ownerId = bs.ownerId,
                        x = bs.x, y = bs.y, vx = bs.vx, vy = bs.vy,
                        spawnAtMs = 0L, expiresAtMs = Long.MAX_VALUE, damage = 0
                    )
                )
            }
        }
        world.bullets.removeIf { it.id !in seen }
    }

    private fun lerpAngle(a: Float, b: Float, t: Float): Float {
        var diff = b - a
        while (diff > Math.PI) diff -= (2 * Math.PI).toFloat()
        while (diff < -Math.PI) diff += (2 * Math.PI).toFloat()
        return a + diff * t
    }

    // ---- Rendering ----
    // Named renderFrame, not draw — View.draw(Canvas) is a real public method
    // SurfaceView inherits, so a method named "draw" here would be treated as
    // an (invalid, since it's private) override of it.
    private fun renderFrame(canvas: Canvas) {
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), paintBg)
        if (screenWidth == 0 || screenHeight == 0) return

        val localPlayer = world.findPlayer(GameSession.localPlayerId)
        val camX = (localPlayer?.x ?: MapData.WORLD_WIDTH / 2f) - screenWidth / 2f
        val camY = (localPlayer?.y ?: MapData.WORLD_HEIGHT / 2f) - screenHeight / 2f

        canvas.save()
        canvas.translate(-camX, -camY)
        for (o in MapData.obstacles) canvas.drawRect(o.x, o.y, o.x + o.w, o.y + o.h, paintObstacle)
        for (b in world.bullets) canvas.drawCircle(b.x, b.y, 6f, paintBullet)
        for (z in world.zombies) {
            canvas.drawCircle(z.x, z.y, GameSimulation.ZOMBIE_HIT_RADIUS, paintZombie)
            canvas.drawCircle(z.x, z.y, GameSimulation.ZOMBIE_HIT_RADIUS, paintZombieOutline)
            drawHealthPip(canvas, z.x, z.y - GameSimulation.ZOMBIE_HIT_RADIUS - 14f, 44f, z.health, z.maxHealth)
        }
        for (p in world.players) drawPlayer(canvas, p)
        canvas.restore()

        drawJoysticks(canvas)
        drawReloadButton(canvas)
        localPlayer?.let { drawHud(canvas, it) }
        drawPingIndicator(canvas)

        waveBannerText?.let {
            if (SystemClock.elapsedRealtime() < waveBannerUntilMs) {
                canvas.drawText(it, screenWidth / 2f, screenHeight * 0.18f, paintBanner)
            }
        }

        if (world.gameOver) drawGameOverOverlay(canvas)
    }

    private fun drawPlayer(canvas: Canvas, p: PlayerState) {
        if (!p.alive) return
        val paintBody = playerBodyPaints[p.id % playerBodyPaints.size]
        canvas.drawCircle(p.x, p.y, GameSimulation.PLAYER_RADIUS, paintBody)
        val fx = p.x + MathUtils.cosOf(p.angle) * GameSimulation.PLAYER_RADIUS
        val fy = p.y + MathUtils.sinOf(p.angle) * GameSimulation.PLAYER_RADIUS
        canvas.drawLine(p.x, p.y, fx, fy, paintPlayerFacing)
        canvas.drawText(p.name, p.x, p.y - GameSimulation.PLAYER_RADIUS - 16f, paintName)
    }

    private fun drawHealthPip(canvas: Canvas, cx: Float, cy: Float, width: Float, hp: Int, maxHp: Int) {
        val h = 6f
        val left = cx - width / 2f
        canvas.drawRect(left, cy - h / 2f, left + width, cy + h / 2f, paintHealthBg)
        val ratio = if (maxHp <= 0) 0f else (hp.toFloat() / maxHp).coerceIn(0f, 1f)
        val fillPaint = if (ratio > 0.35f) paintHealthGood else paintHealthLow
        canvas.drawRect(left, cy - h / 2f, left + width * ratio, cy + h / 2f, fillPaint)
    }

    private fun drawJoysticks(canvas: Canvas) {
        moveStick.draw(canvas, paintStickBase, paintStickKnob)
        aimStick.draw(canvas, paintStickBase, paintStickKnobAim)
    }

    private fun drawReloadButton(canvas: Canvas) {
        val paint = if (reloadPressed) paintReloadBtnActive else paintReloadBtn
        canvas.drawCircle(reloadBtnX, reloadBtnY, reloadBtnRadius, paint)
        canvas.drawText("R", reloadBtnX, reloadBtnY + 10f, paintName)
    }

    private fun drawHud(canvas: Canvas, p: PlayerState) {
        val pad = 24f
        canvas.drawText("HP", pad, pad + 30f, paintHudSmall)
        val barRect = RectF(pad + 50f, pad + 6f, pad + 260f, pad + 34f)
        canvas.drawRect(barRect, paintHealthBg)
        val ratio = (p.health.toFloat() / p.maxHealth.toFloat()).coerceIn(0f, 1f)
        canvas.drawRect(
            barRect.left, barRect.top, barRect.left + barRect.width() * ratio, barRect.bottom,
            if (ratio > 0.3f) paintHealthGood else paintHealthLow
        )

        val ammoText = if (p.reloading) "Reloading…" else "${p.ammoInMag} / ${WeaponType.PISTOL.magazineSize}"
        canvas.drawText(ammoText, pad, pad + 74f, paintHud)

        canvas.drawText("Wave ${wave.currentWave}", screenWidth - pad, pad + 34f, paintHudRight)
        canvas.drawText("$${p.money}", screenWidth - pad, pad + 74f, paintHudSmallRight)
    }

    private fun drawPingIndicator(canvas: Canvas) {
        val ping = GameSession.client?.pingMs ?: -1L
        if (!GameSession.isHost && ping >= 0) {
            val text = "${ping}ms"
            val paint = when {
                ping < 60 -> paintPingGood
                ping < 150 -> paintPingWarn
                else -> paintPingBad
            }
            canvas.drawText(text, screenWidth - 24f, 106f, paint)
        }
    }

    private fun drawGameOverOverlay(canvas: Canvas) {
        canvas.drawRect(0f, 0f, screenWidth.toFloat(), screenHeight.toFloat(), paintOverlayBg)
        val cx = screenWidth / 2f
        val cy = screenHeight / 2f
        canvas.drawText(context.getString(R.string.game_over_title), cx, cy - 30f, paintOverlayTitle)
        canvas.drawText(context.getString(R.string.game_over_wave, world.gameOverWave), cx, cy + 30f, paintOverlayBody)
        canvas.drawText(context.getString(R.string.btn_return_menu), cx, cy + 90f, paintOverlayBody)
    }

    // ---- Loop thread ----
    private inner class LoopThread : Thread("GameLoop") {
        @Volatile var running = true

        fun stopLoop() {
            running = false
            try {
                join(500)
            } catch (e: InterruptedException) {
                // ignore, we're tearing down anyway
            }
        }

        override fun run() {
            var lastNs = System.nanoTime()
            while (running) {
                val frameStartNs = System.nanoTime()
                var dt = (frameStartNs - lastNs) / 1_000_000_000f
                lastNs = frameStartNs
                if (dt > 0.05f) dt = 0.05f // clamp so a hiccup can't cause a huge simulation jump
                val nowMs = SystemClock.elapsedRealtime()

                update(dt, nowMs)

                var canvas: Canvas? = null
                try {
                    canvas = holder.lockCanvas()
                    if (canvas != null) {
                        synchronized(holder) { renderFrame(canvas) }
                    }
                } finally {
                    if (canvas != null) {
                        try {
                            holder.unlockCanvasAndPost(canvas)
                        } catch (e: IllegalArgumentException) {
                            // surface was torn down mid-frame; safe to ignore
                        }
                    }
                }

                val frameMs = (System.nanoTime() - frameStartNs) / 1_000_000
                val sleepMs = TARGET_FRAME_MS - frameMs
                if (sleepMs > 0) {
                    try {
                        sleep(sleepMs)
                    } catch (e: InterruptedException) {
                        // ignore
                    }
                }
            }
        }
    }

    companion object {
        private const val TARGET_FRAME_MS = 16L
        private const val LERP_FACTOR = 0.30f
    }
}
