package com.zsurvival.app.game

import com.zsurvival.app.game.model.Obstacle

/**
 * Single simple map for the first playable pass. More maps (Small Town,
 * Warehouse, School, Hospital, Forest, Military Base) are a straight copy
 * of this shape with different obstacle layouts — add a MapType enum and
 * a lookup here when that's next.
 */
object MapData {
    const val WORLD_WIDTH = 2400f
    const val WORLD_HEIGHT = 2400f

    /** A handful of static rectangles the player collides with; zombies
     * ignore them for now (see ZombieAI notes on pathfinding). */
    val obstacles: List<Obstacle> = listOf(
        Obstacle(x = 500f, y = 500f, w = 260f, h = 160f),   // barn
        Obstacle(x = 1600f, y = 400f, w = 180f, h = 180f),  // silo footprint
        Obstacle(x = 900f, y = 1400f, w = 320f, h = 120f),  // fence line
        Obstacle(x = 1700f, y = 1700f, w = 200f, h = 200f), // shed
        Obstacle(x = 300f, y = 1800f, w = 150f, h = 260f)   // barn 2
    )

    /** Zombies spawn just outside the play area at these edge points and
     * walk in. */
    val zombieSpawnPoints: List<Pair<Float, Float>> = listOf(
        50f to 50f,
        WORLD_WIDTH / 2 to 30f,
        WORLD_WIDTH - 50f to 50f,
        30f to WORLD_HEIGHT / 2,
        WORLD_WIDTH - 30f to WORLD_HEIGHT / 2,
        50f to WORLD_HEIGHT - 50f,
        WORLD_WIDTH / 2 to WORLD_HEIGHT - 30f,
        WORLD_WIDTH - 50f to WORLD_HEIGHT - 50f
    )

    /** Player start positions near the map center, spread out a little so
     * a 2-3 player lobby doesn't stack on one tile. */
    val playerStartPoints: List<Pair<Float, Float>> = listOf(
        WORLD_WIDTH / 2 - 60f to WORLD_HEIGHT / 2,
        WORLD_WIDTH / 2 + 60f to WORLD_HEIGHT / 2,
        WORLD_WIDTH / 2 to WORLD_HEIGHT / 2 + 80f
    )

    fun startPointFor(index: Int): Pair<Float, Float> =
        playerStartPoints[index % playerStartPoints.size]
}
