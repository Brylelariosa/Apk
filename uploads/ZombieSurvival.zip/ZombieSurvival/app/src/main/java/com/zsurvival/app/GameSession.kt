package com.zsurvival.app

import com.zsurvival.app.game.GameWorld
import com.zsurvival.app.game.WaveManager
import com.zsurvival.app.net.GameClient
import com.zsurvival.app.net.GameServer
import com.zsurvival.app.net.LanAdvertiser

/**
 * Android Activities can't easily hand live objects to each other via
 * Intent extras, and a full bound Service is more plumbing than an MVP
 * needs. This process-wide singleton is the deliberate simple choice —
 * it means the game session doesn't survive the process being killed in
 * the background, which is fine for a LAN match you're actively playing.
 */
object GameSession {
    @Volatile var isHost: Boolean = false
    @Volatile var localPlayerId: Int = -1
    var localPlayerName: String = "Player"

    @Volatile var server: GameServer? = null
    @Volatile var client: GameClient? = null
    @Volatile var advertiser: LanAdvertiser? = null

    val world = GameWorld()
    val wave = WaveManager()

    fun resetForNewLobby() {
        isHost = false
        localPlayerId = -1
        server?.stop()
        client?.disconnect()
        advertiser?.stop()
        server = null
        client = null
        advertiser = null
        world.reset()
        wave.beginMatch(0L) // real timing gets set again by beginMatch() at actual match start
    }

    fun endMatch() {
        server?.stop()
        client?.disconnect()
        advertiser?.stop()
        server = null
        client = null
        advertiser = null
    }
}
