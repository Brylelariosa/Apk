package com.zsurvival.app.game.ai

import com.zsurvival.app.game.model.PlayerState
import com.zsurvival.app.game.model.ZombieState
import com.zsurvival.app.util.MathUtils

/**
 * MVP behavior: walk straight at the nearest living player, ignoring
 * obstacles (no pathfinding yet — real pathfinding around MapData's
 * obstacle list is a later pass, noted in WaveManager too).
 */
object ZombieAI {

    const val ATTACK_RANGE = 46f
    const val ATTACK_DAMAGE = 8
    const val ATTACK_COOLDOWN_MS = 900L

    /** Returns the player this zombie attacked this tick, or null. */
    fun step(zombie: ZombieState, players: List<PlayerState>, dt: Float, nowMs: Long): PlayerState? {
        val target = nearestAlivePlayer(zombie, players) ?: return null

        val dist = MathUtils.distance(zombie.x, zombie.y, target.x, target.y)
        if (dist > ATTACK_RANGE) {
            val (nx, ny) = MathUtils.normalize(target.x - zombie.x, target.y - zombie.y)
            zombie.x += nx * zombie.speed * dt
            zombie.y += ny * zombie.speed * dt
            return null
        }

        if (nowMs >= zombie.attackCooldownUntilMs) {
            zombie.attackCooldownUntilMs = nowMs + ATTACK_COOLDOWN_MS
            return target
        }
        return null
    }

    private fun nearestAlivePlayer(zombie: ZombieState, players: List<PlayerState>): PlayerState? {
        var best: PlayerState? = null
        var bestDistSq = Float.MAX_VALUE
        for (p in players) {
            if (!p.alive) continue
            val dSq = MathUtils.distanceSq(zombie.x, zombie.y, p.x, p.y)
            if (dSq < bestDistSq) {
                bestDistSq = dSq
                best = p
            }
        }
        return best
    }
}
