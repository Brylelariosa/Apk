package com.zsurvival.app.game.model

/**
 * Extension point: add RUNNER, TANK, SPITTER, EXPLODER, CRAWLER, BOSS here later.
 * ZombieAI.kt and WaveManager.kt are where new types plug into behavior/spawning.
 */
enum class ZombieType(val wireId: Int) {
    NORMAL(0);

    companion object {
        fun fromWireId(id: Int): ZombieType = entries.firstOrNull { it.wireId == id } ?: NORMAL
    }
}

/**
 * Threading contract (read this before touching fields on these classes):
 * A given PlayerState/ZombieState instance is mutated by exactly ONE thread
 * at a time — on the host that's the game-loop thread (it both simulates
 * AND serializes broadcasts, so no other thread ever touches these).
 * On a client, the network thread never writes into these directly; it
 * builds a fresh [StateSnapshot] and swaps a single @Volatile reference,
 * and only the game-loop thread reads that snapshot, updates the target
 * x/y/angle fields, then lerps toward them. That single-writer rule is
 * what keeps this safe without a synchronized block on every field.
 */
class PlayerState(
    val id: Int,
    var name: String
) {
    var x: Float = 0f
    var y: Float = 0f
    var targetX: Float = 0f
    var targetY: Float = 0f
    var angle: Float = 0f
    var targetAngle: Float = 0f
    var health: Int = MAX_HEALTH
    var maxHealth: Int = MAX_HEALTH
    var ammoInMag: Int = 0
    var magSize: Int = 0
    var alive: Boolean = true
    var money: Int = 0
    var reloading: Boolean = false
    var reloadEndAtMs: Long = 0L
    var lastShotAtMs: Long = 0L
    var ready: Boolean = false
    /** Only this flag is touched from a network thread directly (host side, on disconnect). */
    @Volatile var connected: Boolean = true

    companion object {
        const val MAX_HEALTH = 100
    }
}

class ZombieState(
    val id: Int,
    val type: ZombieType
) {
    var x: Float = 0f
    var y: Float = 0f
    var targetX: Float = 0f
    var targetY: Float = 0f
    var health: Int = 0
    var maxHealth: Int = 0
    var speed: Float = 0f
    var attackCooldownUntilMs: Long = 0L
}

/**
 * Bullets travel in a straight line at constant velocity, so instead of
 * network-lerping them (which looks worse for something fast-moving at a
 * ~15Hz broadcast rate) both host and client just integrate x += vx*dt
 * locally every frame. The network snapshot only tells a client which
 * bullet ids currently exist (spawn / remove), not where they are.
 */
class BulletState(
    val id: Int,
    val ownerId: Int,
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val spawnAtMs: Long,
    val expiresAtMs: Long,
    val damage: Int
)

/** Immutable — always replaced wholesale in the input map, never mutated in place. */
data class PlayerInput(
    val moveX: Float = 0f,
    val moveY: Float = 0f,
    val aimAngle: Float = 0f,
    val firing: Boolean = false,
    val reload: Boolean = false
)

data class Obstacle(val x: Float, val y: Float, val w: Float, val h: Float)

/** One lobby member as broadcast to everyone in the lobby (pre-match). */
data class LobbyPlayer(val id: Int, val name: String, val ready: Boolean, val isHost: Boolean)

/** Immutable snapshot parsed from a STATE network message. Built fresh on the
 * network thread, then handed off via a single @Volatile reference swap —
 * see [com.zsurvival.app.net.GameClient]. */
data class StateSnapshot(
    val wave: Int,
    val players: List<PlayerSnap>,
    val zombieIds: List<ZombieSnap>,
    val bulletIds: List<BulletSnap>,
    val gameOver: Boolean
)

data class PlayerSnap(
    val id: Int, val name: String, val x: Float, val y: Float, val angle: Float,
    val hp: Int, val maxHp: Int, val ammo: Int, val mag: Int,
    val alive: Boolean, val money: Int, val reloading: Boolean
)

data class ZombieSnap(val id: Int, val type: Int, val x: Float, val y: Float, val hp: Int, val maxHp: Int)

data class BulletSnap(val id: Int, val ownerId: Int, val x: Float, val y: Float, val vx: Float, val vy: Float)
