package com.photopuzzle.game.puzzle

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.ceil
import kotlin.math.floor

internal object PuzzlePieceFactory {

    private const val SIDE_TOP = 0
    private const val SIDE_RIGHT = 1
    private const val SIDE_BOTTOM = 2
    private const val SIDE_LEFT = 3

    /**
     * Cuts [source] into a `rows` x `cols` grid of interlocking jigsaw
     * pieces. Each returned piece owns its own small [Bitmap]; [source]
     * itself is left untouched (caller keeps ownership of it).
     *
     * [originX]/[originY] shift every piece's [PuzzlePiece.homeX]/[homeY]
     * out from [source]'s own top-left to wherever the caller's board
     * places the photo/reference area -- e.g. centered with room to spare
     * on every side for scattering, rather than filling the board itself.
     * Left at 0f, home positions match [source]'s own coordinates exactly
     * as before.
     */
    fun createPieces(
        source: Bitmap,
        rows: Int,
        cols: Int,
        seed: Long,
        originX: Float = 0f,
        originY: Float = 0f
    ): List<PuzzlePiece> {
        require(rows >= 2 && cols >= 2) { "A puzzle needs at least a 2x2 grid" }
        require(source.width > 0 && source.height > 0) { "Source bitmap is empty" }

        val edgeData = EdgeGeneratorProvider.get().generate(rows, cols, seed)
        val hEdgeCount = (rows - 1) * cols

        fun edgePair(index: Int) = edgeData[index * 2] to edgeData[index * 2 + 1]
        fun horizontalSign(r: Int, c: Int) = edgePair(r * cols + c)
        fun verticalSign(r: Int, c: Int) = edgePair(hEdgeCount + r * (cols - 1) + c)

        fun edgeSignAt(side: Int, r: Int, c: Int): Pair<Float, Float> = when (side) {
            SIDE_TOP -> if (r == 0) FLAT else
                horizontalSign(r - 1, c).let { (s, j) -> -s to -j }
            SIDE_BOTTOM -> if (r == rows - 1) FLAT else horizontalSign(r, c)
            SIDE_LEFT -> if (c == 0) FLAT else
                verticalSign(r, c - 1).let { (s, j) -> -s to -j }
            else -> if (c == cols - 1) FLAT else verticalSign(r, c)
        }

        val cellW = source.width.toFloat() / cols
        val cellH = source.height.toFloat() / rows
        val bounds = RectF()
        val pieces = ArrayList<PuzzlePiece>(rows * cols)

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val path = buildPieceOutline(r, c, cellW, cellH) { side -> edgeSignAt(side, r, c) }

                path.computeBounds(bounds, true)
                pieces += cutPiece(source, r, c, path, bounds, originX, originY)
            }
        }
        return pieces
    }

    private inline fun buildPieceOutline(
        r: Int,
        c: Int,
        cellW: Float,
        cellH: Float,
        edgeAt: (side: Int) -> Pair<Float, Float>
    ): Path {
        val ox = c * cellW
        val oy = r * cellH
        val path = Path().apply { moveTo(ox, oy) }

        val (topSign, topJitter) = edgeAt(SIDE_TOP)
        PieceEdgeShape.addEdge(path, ox, oy, 1f, 0f, 0f, -1f, cellW, topSign, topJitter)

        val (rightSign, rightJitter) = edgeAt(SIDE_RIGHT)
        PieceEdgeShape.addEdge(path, ox + cellW, oy, 0f, 1f, 1f, 0f, cellH, rightSign, rightJitter)

        val (bottomSign, bottomJitter) = edgeAt(SIDE_BOTTOM)
        PieceEdgeShape.addEdge(path, ox + cellW, oy + cellH, -1f, 0f, 0f, 1f, cellW, bottomSign, bottomJitter)

        val (leftSign, leftJitter) = edgeAt(SIDE_LEFT)
        PieceEdgeShape.addEdge(path, ox, oy + cellH, 0f, -1f, -1f, 0f, cellH, leftSign, leftJitter)

        path.close()
        return path
    }

    private fun cutPiece(
        source: Bitmap,
        r: Int,
        c: Int,
        path: Path,
        bounds: RectF,
        originX: Float,
        originY: Float
    ): PuzzlePiece {
        val bitmapW = ceil(bounds.width()).toInt().coerceAtLeast(1)
        val bitmapH = ceil(bounds.height()).toInt().coerceAtLeast(1)

        // By construction no piece's tab ever reaches past the source
        // bitmap's own edges (the outer grid border is always flat -- see
        // edgeAt() above), so these coerceIn calls are a defensive no-op in
        // practice rather than something that routinely clips real content.
        val srcLeft = floor(bounds.left).toInt().coerceIn(0, source.width)
        val srcTop = floor(bounds.top).toInt().coerceIn(0, source.height)
        val srcRight = ceil(bounds.right).toInt().coerceIn(0, source.width)
        val srcBottom = ceil(bounds.bottom).toInt().coerceIn(0, source.height)
        val subWidth = (srcRight - srcLeft).coerceAtLeast(1)
        val subHeight = (srcBottom - srcTop).coerceAtLeast(1)

        val sourceRegion = Bitmap.createBitmap(source, srcLeft, srcTop, subWidth, subHeight)
        val pieceBitmap = Bitmap.createBitmap(bitmapW, bitmapH, Bitmap.Config.ARGB_8888)

        val localPath = Path(path).apply { offset(-bounds.left, -bounds.top) }
        Canvas(pieceBitmap).apply {
            save()
            clipPath(localPath)
            drawBitmap(sourceRegion, srcLeft - bounds.left, srcTop - bounds.top, null)
            restore()
        }
        sourceRegion.recycle()

        return PuzzlePiece(
            row = r,
            col = c,
            bitmap = pieceBitmap,
            outline = localPath,
            homeX = bounds.left + originX,
            homeY = bounds.top + originY
        )
    }

    private val FLAT = 0f to 0f
}
