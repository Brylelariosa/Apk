#include "ThreadPool.h"
#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>

namespace novallm {

// Below this many columns, parallelFor just runs sequentially. This
// sandbox has one core, so the number itself can't be *tuned* against
// real measurements here - but the reasoning is architecture-
// independent: thread wake/sleep and condition-variable signaling cost
// real, fixed microseconds regardless of core count, and this
// project's demo configs (embedDim 16-32, ffnHiddenDim 64) sit well
// under it, so they correctly stay on the fast, single-threaded path
// unchanged. vocabSize (~300 in the demos) sits comfortably over it,
// which is deliberate - see the part-3 ROADMAP.md entry for why the LM
// head projection specifically is the case this was built for. Revisit
// this number once it can be tuned against a real device instead of
// reasoned about in the abstract.
constexpr int kMinColsPerChunk = 64;

struct ThreadPool::Worker {
    std::thread thread;
    std::mutex mutex;
    std::condition_variable cv;
    std::function<void()> job;
    bool hasJob = false;
    bool shouldStop = false;

    void loop() {
        while (true) {
            std::function<void()> toRun;
            {
                std::unique_lock<std::mutex> lock(mutex);
                cv.wait(lock, [this] { return hasJob || shouldStop; });
                if (shouldStop && !hasJob) return;
                toRun = std::move(job);
                hasJob = false;
            }
            toRun();
        }
    }
};

ThreadPool::ThreadPool(int numWorkers) {
    workers_.reserve(static_cast<size_t>(std::max(numWorkers, 0)));
    for (int i = 0; i < numWorkers; ++i) {
        auto w = std::make_unique<Worker>();
        Worker* raw = w.get();
        w->thread = std::thread([raw] { raw->loop(); });
        workers_.push_back(std::move(w));
    }
}

ThreadPool::~ThreadPool() {
    for (auto& w : workers_) {
        {
            std::lock_guard<std::mutex> lock(w->mutex);
            w->shouldStop = true;
        }
        w->cv.notify_one();
    }
    for (auto& w : workers_) {
        w->thread.join();
    }
}

ThreadPool& ThreadPool::shared() {
    unsigned int cores = std::thread::hardware_concurrency();
    // hardware_concurrency() returning 0 means "couldn't tell" - treat
    // that the same as 1 (no extra worker threads), not as "assume
    // many": on an unknown device, understaffing just costs some
    // parallelism, while overstaffing costs real idle-thread resources
    // for no benefit.
    int numWorkers = (cores > 1) ? static_cast<int>(cores) - 1 : 0;
    static ThreadPool instance(numWorkers);
    return instance;
}

int ThreadPool::numWorkerThreads() const {
    return static_cast<int>(workers_.size());
}

void ThreadPool::parallelFor(int n, const std::function<void(int, int)>& fn) {
    if (n <= 0) return;
    int numWorkers = static_cast<int>(workers_.size());
    if (numWorkers == 0 || n < kMinColsPerChunk * 2) {
        fn(0, n);
        return;
    }

    // At most (numWorkers + 1) chunks - workers plus the calling
    // thread - so no worker ever needs a second chunk queued behind
    // another within this one call; each worker's single job slot is
    // enough.
    int numChunks = std::min(numWorkers + 1, std::max(1, n / kMinColsPerChunk));
    int baseSize = n / numChunks;
    int remainder = n % numChunks;

    // Counts only the WORKER chunks (numChunks - 1) - the calling
    // thread runs its own last chunk directly below and doesn't wait
    // on itself.
    std::atomic<int> remaining{numChunks - 1};
    std::mutex doneMutex;
    std::condition_variable doneCv;

    int begin = 0;
    for (int c = 0; c < numChunks; ++c) {
        int size = baseSize + (c < remainder ? 1 : 0);
        int end = begin + size;

        if (c == numChunks - 1) {
            // Last chunk runs right here instead of on a worker - the
            // calling thread would otherwise just sit idle waiting, so
            // it does its own share of the work too.
            fn(begin, end);
        } else {
            Worker* w = workers_[static_cast<size_t>(c)].get();
            {
                std::lock_guard<std::mutex> lock(w->mutex);
                w->job = [&fn, begin, end, &remaining, &doneMutex, &doneCv]() {
                    fn(begin, end);
                    if (remaining.fetch_sub(1, std::memory_order_acq_rel) == 1) {
                        // We were the last worker to finish - wake the
                        // calling thread. Locking doneMutex here, and
                        // checking the predicate under the same lock
                        // below, closes the classic lost-wakeup race:
                        // it doesn't matter whether this runs before or
                        // after the calling thread reaches wait().
                        std::lock_guard<std::mutex> doneLock(doneMutex);
                        doneCv.notify_one();
                    }
                };
                w->hasJob = true;
            }
            w->cv.notify_one();
        }
        begin = end;
    }

    if (numChunks > 1) {
        std::unique_lock<std::mutex> lock(doneMutex);
        doneCv.wait(lock, [&remaining] { return remaining.load(std::memory_order_acquire) == 0; });
    }
}

} // namespace novallm
