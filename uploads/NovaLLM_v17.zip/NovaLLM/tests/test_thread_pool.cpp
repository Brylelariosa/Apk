// Standalone correctness tests for core/math's ThreadPool and its
// wiring into matrix::matmul / quantizedMatmul (subsystem 8, part 3).
// No Android/JNI needed.
//
// This sandbox reports one CPU core, so ThreadPool::shared() has zero
// worker threads here and every test that needs to actually exercise
// the multi-worker synchronization path constructs an explicit-count
// ThreadPool instead (see ThreadPool's constructor comment) - real
// OS threads, genuinely scheduled (even if only time-sliced on one
// core, not truly concurrent), so this still verifies the actual
// mutex/condition-variable/atomic logic, not just the fallback.
//
// Termux (note the added -pthread - not strictly required by every
// toolchain, but std::thread needs it on some; harmless where it isn't):
//   clang++ -std=c++17 -pthread -I../app/src/main/cpp \
//     test_thread_pool.cpp \
//     ../app/src/main/cpp/core/math/*.cpp \
//     ../app/src/main/cpp/core/tokenizer/*.cpp \
//     ../app/src/main/cpp/core/embedding/*.cpp \
//     ../app/src/main/cpp/core/transformer/*.cpp \
//     ../app/src/main/cpp/core/decoder/*.cpp \
//     -o test_thread_pool && ./test_thread_pool
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <thread>
#include <vector>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/math/Quantization.h"
#include "core/math/ThreadPool.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

// ---------------------------------------------------------------------
// ThreadPool::parallelFor itself
// ---------------------------------------------------------------------

void testEveryIndexTouchedExactlyOnce() {
    ThreadPool pool(4); // forced, regardless of this sandbox's core count
    const int n = 500;
    std::vector<std::atomic<int>> touched(n);
    for (auto& t : touched) t.store(0);

    pool.parallelFor(n, [&](int begin, int end) {
        for (int i = begin; i < end; ++i) {
            touched[static_cast<size_t>(i)].fetch_add(1, std::memory_order_relaxed);
        }
    });

    bool allExactlyOnce = true;
    for (auto& t : touched) {
        if (t.load() != 1) allExactlyOnce = false;
    }
    expectTrue(allExactlyOnce, "parallelFor: every index in [0,n) is touched exactly once, no gaps or overlap");
}

void testMatchesSequentialForVariousSizes() {
    ThreadPool pool(4);
    int sizes[] = {0, 1, 3, 63, 64, 65, 127, 128, 129, 500, 1000};
    bool allMatch = true;
    for (int n : sizes) {
        std::vector<int> expected(static_cast<size_t>(n));
        for (int i = 0; i < n; ++i) expected[static_cast<size_t>(i)] = i * i;

        std::vector<int> actual(static_cast<size_t>(n), -1);
        pool.parallelFor(n, [&](int begin, int end) {
            for (int i = begin; i < end; ++i) actual[static_cast<size_t>(i)] = i * i;
        });

        if (actual != expected) allMatch = false;
    }
    expectTrue(allMatch, "parallelFor: matches a plain sequential loop for n=0 through 1000, including edges around the chunk-size threshold");
}

void testSmallWorkStaysOnCallingThreadOnly() {
    ThreadPool pool(4);
    std::thread::id callingThread = std::this_thread::get_id();
    bool usedOnlyCallingThread = true;

    // Well under the threshold - should never dispatch to a worker.
    pool.parallelFor(10, [&](int begin, int end) {
        (void)begin; (void)end;
        if (std::this_thread::get_id() != callingThread) usedOnlyCallingThread = false;
    });

    expectTrue(usedOnlyCallingThread, "parallelFor: work below the chunk-size threshold runs entirely on the calling thread, no worker dispatch");
}

void testLargeWorkActuallyUsesWorkerThreads() {
    ThreadPool pool(4);
    std::thread::id callingThread = std::this_thread::get_id();
    std::atomic<bool> sawAnotherThread{false};

    pool.parallelFor(1000, [&](int begin, int end) {
        (void)begin; (void)end;
        if (std::this_thread::get_id() != callingThread) sawAnotherThread.store(true);
    });

    expectTrue(sawAnotherThread.load(), "parallelFor: work above the threshold, with workers available, actually dispatches to at least one worker thread");
}

void testManyRepeatedCallsDoNotDeadlockOrCorrupt() {
    ThreadPool pool(4);
    bool ok = true;
    for (int iter = 0; iter < 500 && ok; ++iter) {
        int n = 100 + (iter % 400);
        std::vector<int> result(static_cast<size_t>(n), 0);
        pool.parallelFor(n, [&](int begin, int end) {
            for (int i = begin; i < end; ++i) result[static_cast<size_t>(i)] = i;
        });
        for (int i = 0; i < n; ++i) {
            if (result[static_cast<size_t>(i)] != i) { ok = false; break; }
        }
    }
    expectTrue(ok, "parallelFor: 500 repeated calls with varying sizes on a reused pool never deadlock or corrupt results");
}

void testZeroWorkerPoolFallsBackCorrectly() {
    ThreadPool pool(0); // explicitly no workers - same situation as this sandbox's shared()
    std::vector<int> result(200, 0);
    pool.parallelFor(200, [&](int begin, int end) {
        for (int i = begin; i < end; ++i) result[static_cast<size_t>(i)] = i * 2;
    });
    bool correct = true;
    for (int i = 0; i < 200; ++i) if (result[static_cast<size_t>(i)] != i * 2) correct = false;
    expectTrue(correct, "parallelFor: a zero-worker pool still produces correct results via the sequential fallback");
}

// ---------------------------------------------------------------------
// matrix::matmul / quantizedMatmul threaded through an explicit pool -
// forced multi-worker, compared against the same computation via a
// forced zero-worker pool. Column-split accumulation order for any one
// output element is unchanged (still strictly p=0..k-1), so these
// should be bit-exact, not just close - see Matrix.cpp's comment.
// ---------------------------------------------------------------------

void testMatmulBitExactWithAndWithoutThreading() {
    ThreadPool sequential(0);
    ThreadPool parallel(4);

    Tensor a({8, 40}), b({40, 300}); // n=300 mirrors this project's vocabSize demos - over the chunk threshold
    for (size_t i = 0; i < a.size(); ++i) a.data()[i] = std::sin(static_cast<float>(i) * 0.37f);
    for (size_t i = 0; i < b.size(); ++i) b.data()[i] = std::cos(static_cast<float>(i) * 0.21f);

    Tensor seq = matrix::matmul(a, b, sequential);
    Tensor par = matrix::matmul(a, b, parallel);

    bool bitExact = true;
    for (size_t i = 0; i < seq.size(); ++i) {
        if (seq.data()[i] != par.data()[i]) bitExact = false;
    }
    expectTrue(bitExact, "matmul: forced multi-worker result is bit-exact with the forced sequential result (m > 1 case)");
}

void testMatmulBitExactForSingleRow() {
    // m=1: the case that matters most in practice - every generated
    // token after the first. Row-parallelism would give this zero
    // benefit; column-parallelism should still both work AND help.
    ThreadPool sequential(0);
    ThreadPool parallel(4);

    Tensor a({1, 16}), b({16, 300});
    for (size_t i = 0; i < a.size(); ++i) a.data()[i] = static_cast<float>(i % 7) - 3.0f;
    for (size_t i = 0; i < b.size(); ++i) b.data()[i] = static_cast<float>((i * 3) % 11) - 5.0f;

    Tensor seq = matrix::matmul(a, b, sequential);
    Tensor par = matrix::matmul(a, b, parallel);

    bool bitExact = true;
    for (size_t i = 0; i < seq.size(); ++i) {
        if (seq.data()[i] != par.data()[i]) bitExact = false;
    }
    expectTrue(bitExact, "matmul: bit-exact for m=1 (single-token decoding shape) with a real multi-worker pool");
}

void testQuantizedMatmulBitExactWithAndWithoutThreading() {
    ThreadPool sequential(0);
    ThreadPool parallel(4);

    Tensor x({1, 16});
    for (size_t i = 0; i < x.size(); ++i) x.data()[i] = static_cast<float>(i % 5) - 2.0f;
    Tensor w({16, 300});
    for (size_t i = 0; i < w.size(); ++i) w.data()[i] = std::sin(static_cast<float>(i) * 0.13f) * 0.5f;
    QuantizedTensor wq = quantize(w);

    Tensor seq = quantizedMatmul(x, wq, sequential);
    Tensor par = quantizedMatmul(x, wq, parallel);

    bool bitExact = true;
    for (size_t i = 0; i < seq.size(); ++i) {
        if (seq.data()[i] != par.data()[i]) bitExact = false;
    }
    expectTrue(bitExact, "quantizedMatmul: forced multi-worker result is bit-exact with the forced sequential result");
}

void testDefaultMatmulOverloadStillWorksViaSharedPool() {
    // The plain two-argument overload every existing call site uses -
    // confirms the ThreadPool::shared()-based convenience path is wired
    // correctly, whatever this sandbox's own core count happens to be.
    Tensor a({4, 4}, 1.0f), b({4, 4}, 2.0f);
    Tensor result = matrix::matmul(a, b);
    bool correct = true;
    for (size_t i = 0; i < result.size(); ++i) {
        if (std::fabs(result.data()[i] - 8.0f) > 1e-5f) correct = false; // 4 * (1*2)
    }
    expectTrue(correct, "matmul: the default (a, b) overload still produces correct results through ThreadPool::shared()");
}

int main() {
    testEveryIndexTouchedExactlyOnce();
    testMatchesSequentialForVariousSizes();
    testSmallWorkStaysOnCallingThreadOnly();
    testLargeWorkActuallyUsesWorkerThreads();
    testManyRepeatedCallsDoNotDeadlockOrCorrupt();
    testZeroWorkerPoolFallsBackCorrectly();

    testMatmulBitExactWithAndWithoutThreading();
    testMatmulBitExactForSingleRow();
    testQuantizedMatmulBitExactWithAndWithoutThreading();
    testDefaultMatmulOverloadStillWorksViaSharedPool();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    std::printf("\n(this sandbox: std::thread::hardware_concurrency() = %u, "
                "so ThreadPool::shared().numWorkerThreads() = %d - the tests above forced explicit\n"
                "worker counts specifically to exercise the multi-threaded path anyway)\n",
                std::thread::hardware_concurrency(), ThreadPool::shared().numWorkerThreads());
    return g_failures == 0 ? 0 : 1;
}
