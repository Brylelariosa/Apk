package com.zipapkbuilder

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.widget.NestedScrollView
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.TokenCrypto
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.feature.artifacts.ArtifactBrowser
import com.zipapkbuilder.feature.build.BuildFlowController
import com.zipapkbuilder.feature.buildlog.BuildLogViewer
import com.zipapkbuilder.feature.download.DownloadManager
import com.zipapkbuilder.feature.filemanager.FileManagerController
import com.zipapkbuilder.feature.keystore.KeystoreController
import com.zipapkbuilder.feature.repo.RepoSwitcher
import com.zipapkbuilder.feature.settings.SettingsDialogController
import com.zipapkbuilder.feature.upload.UploadCoordinator
import com.zipapkbuilder.net.NetworkReliability
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Hosts the single-screen UI (token/repo/branch, zip picker, console, keystore
 * card) and every cross-cutting piece of session state and Activity-intrinsic
 * plumbing (views, permission launchers, the shared background executor,
 * lifecycle) that the feature controllers below are built on top of. Business
 * logic for each feature lives in its own controller class — this class wires
 * them to the UI and to each other rather than implementing any of them
 * itself. See each controller's own kdoc for what it owns:
 *
 * - [buildFlowController] — upload → build → fetch-artifact flow, build history
 * - [downloadManager] — resumable downloads, Download Manager dialog, download history
 * - [uploadCoordinator] — reliable/progress-tracked uploads (used by [buildFlowController])
 * - [keystoreController] — GitHub Actions-based signing keystore generation
 * - [artifactBrowser] — browse/download any past build artifact
 * - [fileManagerController] — browse/view/edit/create/delete repo files
 * - [repoSwitcher] — switch which repo/branch the app targets
 * - [buildLogViewer] — browse past runs and view their full logs in-app
 * - [settingsDialogController] — the Settings dialog
 */
class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    internal lateinit var etToken: EditText
    internal lateinit var tvOwnerInfo: TextView
    internal lateinit var etRepo: EditText
    internal lateinit var etBranch: EditText
    internal lateinit var btnPickZip: Button
    internal lateinit var tvFileName: TextView
    internal lateinit var btnUploadBuild: Button
    internal lateinit var tvStatus: TextView
    internal lateinit var progressBar: ProgressBar
    internal var    btnDownloadApk: Button? = null   // removed from layout; kept nullable for logic compat
    internal lateinit var tvLog: TextView
    internal lateinit var scrollLog: NestedScrollView
    internal lateinit var btnManageZips: Button
    internal lateinit var btnWorkflowLog: Button
    internal lateinit var btnBrowseArtifacts: Button
    internal lateinit var btnCopyLog: Button
    internal lateinit var btnSaveLog: Button
    internal lateinit var btnSettings: android.widget.ImageButton
    internal lateinit var btnDownloadManager: android.widget.ImageButton
    internal lateinit var etKeystorePass: EditText
    internal lateinit var etKeyAlias: EditText
    internal lateinit var btnGenerateKeystore: Button
    internal lateinit var tvKeystoreStatus: TextView

    // ── State ────────────────────────────────────────────────────────────────
    internal val mainHandler = Handler(Looper.getMainLooper())
    internal val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    /**
     * Shared bounded pool for all network/file background work, replacing the old
     * pattern of spawning a brand-new raw [Thread] (via `kotlin.concurrent.thread`)
     * for every single action. A fresh OS thread per tap is wasteful on a low-RAM
     * device (thread creation overhead + one full stack per thread) and had no
     * ceiling — rapid taps could pile up an unbounded number of live threads.
     *
     * 4 threads keeps enough concurrency that a long build (up to 45 min of polling)
     * never blocks unrelated actions like Browse Artifacts or viewing a log, while
     * still bounding worst-case thread/memory usage. All existing call sites are
     * fire-and-forget (nothing calls `.join()` on them), so swapping to `execute()`
     * changes nothing about behavior — only how the thread is obtained.
     */
    internal val bgExecutor: ExecutorService = Executors.newFixedThreadPool(4) { r ->
        Thread(r, "ZipApkBuilder-bg").apply { isDaemon = true }
    }

    internal var selectedZipUri: Uri? = null
    internal var selectedZipName = ""
    internal var artifactDownloadUrl: String? = null
    internal var isBusy = false

    // Coalesces appendLog()'s auto-scroll: during a verbose build (hundreds of
    // streamed lines), each line used to queue its own fullScroll() pass — this
    // collapses any burst of rapid-fire lines into a single pending scroll.
    private var scrollPending = false

    // ── Console dot animators ─────────────────────────────────────────────────
    private var dotRed:    View? = null
    private var dotYellow: View? = null
    private var dotGreen:  View? = null
    private var dotAnimRed:    android.animation.AnimatorSet? = null
    private var dotAnimYellow: android.animation.AnimatorSet? = null
    private var dotAnimGreen:  android.animation.AnimatorSet? = null

    // ── Cross-feature session state ───────────────────────────────────────────
    // Owner/repo/build identity resolved once per repo and reused across every
    // feature controller below, rather than each re-resolving it independently.
    internal var lastOwner      = ""
    internal var lastRemotePath = ""
    internal var lastFileSha: String? = null
    internal var lastRunId: Long = -1L

    // ── File-upload-to-repo state ─────────────────────────────────────────────
    /** Set before launching pickUploadFile so the callback knows where to put it. */
    internal var pendingUploadToken  = ""
    internal var pendingUploadOwner  = ""
    internal var pendingUploadRepo   = ""
    internal var pendingUploadBranch = ""
    internal var pendingUploadPath   = ""   // folder path inside repo

    // Callback for settings "Change" download location button
    internal var onFolderPicked: ((Uri) -> Unit)? = null

    internal val pickFolderLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                prefs.edit().putString(PrefKeys.PREF_DOWNLOAD_URI, uri.toString()).apply()
                onFolderPicked?.invoke(uri)
                onFolderPicked = null
            }
        }

    internal val pickUploadFile =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val token  = pendingUploadToken
            val owner  = pendingUploadOwner
            val repo   = pendingUploadRepo
            val branch = pendingUploadBranch
            val folder = pendingUploadPath
            if (token.isEmpty() || owner.isEmpty() || repo.isEmpty()) {
                appendLog("⚠ Upload context lost — try again."); return@registerForActivityResult
            }
            setBusy(true)
            bgExecutor.execute {
                for (uri in uris) {
                    val fileName = UriUtils.resolveUploadFileName(contentResolver, uri)
                    val filePath = if (folder.isEmpty()) fileName else "$folder/$fileName"
                    appendLog("Uploading $fileName …")
                    fileManagerController.uploadFileToRepo(token, owner, repo, branch, filePath, uri, folder)
                }
                mainHandler.post { fileManagerController.fetchAndBrowse(token, owner, repo, branch, folder) }
            }
        }

    // ── Runtime storage permission (Android 7–9 / API 24–28) ─────────────────
    /** Stored so the permission result callback knows what to run after grant. */
    private var pendingStorageAction: (() -> Unit)? = null

    private val requestWritePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                pendingStorageAction?.invoke()
            } else {
                appendLog("⚠ Storage permission denied — cannot save to Downloads on this device.")
            }
            pendingStorageAction = null
        }

    // ── Runtime notification permission (Android 13+ / API 33+) ──────────────
    /** Stored so the permission result callback knows what to run after grant/denial. */
    private var pendingNotificationAction: (() -> Unit)? = null

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            // Proceed either way: background build tracking is a nice-to-have layered
            // on top of the build itself, which must start regardless of the answer.
            // (If denied, BuildTrackingService's own notify() calls no-op safely.)
            pendingNotificationAction?.invoke()
            pendingNotificationAction = null
        }

    /**
     * Runs [action] once the notification-permission prompt (if one was needed) has
     * been answered — never blocks on it indefinitely, and proceeds with [action]
     * regardless of the answer, since it only gates whether build-tracking
     * notifications are *visible*, not whether the build itself runs. No-op prompt
     * on API < 33 (no runtime permission exists there) or if already granted.
     * Must be called from the main thread.
     */
    internal fun withNotificationPermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT < 33) { action(); return }
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            action()
        } else {
            pendingNotificationAction = action
            requestNotificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /**
     * Runs [action] only when the app holds WRITE_EXTERNAL_STORAGE (required on
     * API 24–28).  On API 29+ the MediaStore path is used and no permission is needed.
     * Must be called from the main thread.
     */
    internal fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            action(); return
        }
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            action()
        } else {
            pendingStorageAction = action
            requestWritePermission.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    companion object {
        // Caps the console log's backing buffer so an extra-long or looping build
        // (or just a long-lived session across many builds/log views) can't grow
        // tvLog's Editable without bound. ~200k chars is several thousand lines —
        // far more than anyone reads in-app — trimmed from the oldest end first.
        private const val LOG_CHAR_CAP = 200_000
    }

    // ── Feature controllers ───────────────────────────────────────────────────
    // Each takes this Activity so it can reuse its shared UI-feedback surface
    // (appendLog/setStatus/setBusy), session state, and executor/prefs above,
    // rather than duplicating them. Sibling controllers call one another via
    // these same properties (e.g. ArtifactBrowser calling into RepoSwitcher).
    internal val networkReliability     = NetworkReliability(this)
    internal val uploadCoordinator      = UploadCoordinator(this, networkReliability)
    internal val downloadManager        = DownloadManager(this, networkReliability)
    internal val buildFlowController    = BuildFlowController(this, uploadCoordinator)
    internal val keystoreController     = KeystoreController(this)
    internal val artifactBrowser        = ArtifactBrowser(this)
    internal val fileManagerController  = FileManagerController(this)
    internal val repoSwitcher           = RepoSwitcher(this)
    internal val buildLogViewer         = BuildLogViewer(this)
    internal val settingsDialogController = SettingsDialogController(this)

    // ── File picker ──────────────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = UriUtils.resolveZipFileName(contentResolver, uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
        prefs.edit().putString(PrefKeys.PREF_ZIP_NAME, selectedZipName).apply()
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken        = findViewById(R.id.etToken)
        tvOwnerInfo    = findViewById(R.id.tvOwnerInfo)
        etRepo         = findViewById(R.id.etRepo)
        etBranch       = findViewById(R.id.etBranch)
        btnPickZip     = findViewById(R.id.btnPickZip)
        tvFileName     = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus       = findViewById(R.id.tvStatus)
        progressBar    = findViewById(R.id.progressBar)
        // btnDownloadApk removed from layout — stays null
        btnBrowseArtifacts = findViewById(R.id.btnBrowseArtifacts)
        btnManageZips  = findViewById(R.id.btnManageZips)
        btnWorkflowLog = findViewById(R.id.btnWorkflowLog)
        btnCopyLog     = findViewById(R.id.btnCopyLog)
        btnSaveLog     = findViewById(R.id.btnSaveLog)
        btnSettings    = findViewById(R.id.btnSettings)
        btnDownloadManager = findViewById(R.id.btnDownloadManager)
        etKeystorePass     = findViewById(R.id.etKeystorePass)
        etKeyAlias         = findViewById(R.id.etKeyAlias)
        btnGenerateKeystore = findViewById(R.id.btnGenerateKeystore)
        tvKeystoreStatus   = findViewById(R.id.tvKeystoreStatus)
        tvLog              = findViewById(R.id.tvLog)
        scrollLog          = findViewById(R.id.scrollLog)

        // Console dots
        dotRed    = findViewById(R.id.dotRed)
        dotYellow = findViewById(R.id.dotYellow)
        dotGreen  = findViewById(R.id.dotGreen)
        dotRed?.post { startIdleDotAnimations() }

        etToken.setText(TokenCrypto.decrypt(prefs.getString(PrefKeys.PREF_TOKEN, "") ?: ""))
        etRepo.setText(prefs.getString(PrefKeys.PREF_REPO, ""))
        etBranch.setText(prefs.getString(PrefKeys.PREF_BRANCH, "main"))

        // Clear cached owner whenever the repo field changes so the next
        // API call always resolves the correct owner for the active repo.
        etRepo.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { lastOwner = "" }
        })

        btnPickZip.setOnClickListener     { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener  { if (!isBusy) buildFlowController.startFlow() }
        btnBrowseArtifacts.setOnClickListener { artifactBrowser.browseAllArtifacts() }
        btnManageZips.setOnClickListener   { fileManagerController.showManageFilesDialog() }
        // Build Log button: choose View or Download
        btnWorkflowLog.setOnClickListener  {
            val logTitle = if (selectedZipName.isNotEmpty()) "Build Log — $selectedZipName" else "Build Log"
            AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                .setTitle(logTitle)
                .setItems(arrayOf("📋  View log in app", "📥  Download log ZIP")) { _, which ->
                    when (which) {
                        0 -> buildLogViewer.fetchAndShowWorkflowLog()
                        1 -> withStoragePermission { downloadManager.downloadLatestRunLogs() }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnCopyLog.setOnClickListener      { copyLogToClipboard() }
        btnSaveLog.setOnClickListener      { saveLogToFile() }
        btnGenerateKeystore.setOnClickListener { keystoreController.generateKeystore() }
        btnSettings.setOnClickListener     { settingsDialogController.showSettingsDialog() }
        btnDownloadManager.setOnClickListener { downloadManager.showDownloadManagerDialog() }
        // Build Log is always enabled — it lists all runs, no active build needed
        btnWorkflowLog.isEnabled = true

        // Restore any previously completed build so Download still works after restart
        buildFlowController.restoreSavedBuildState()

        // Restore keystore saved state
        if (prefs.getBoolean(PrefKeys.PREF_KEYSTORE_SAVED, false)) {
            val alias = prefs.getString(PrefKeys.PREF_KEYSTORE_ALIAS, "") ?: ""
            tvKeystoreStatus.text = "✓ Keystore saved  •  alias: $alias"
            tvKeystoreStatus.visibility = View.VISIBLE
        }

        // Sweep any leftover temp files from a previous session that was killed
        // mid-download/mid-build before its own cleanup ran.
        bgExecutor.execute { downloadManager.cleanupStaleCacheFiles() }
    }

    /**
     * Shuts down the shared executor so no orphaned background task keeps running
     * (or keeps a reference to a destroyed Activity/its Views) after the Activity
     * goes away. Queued-but-not-started tasks are dropped; a task already in
     * flight is left to finish on its own rather than interrupted mid-HTTP-call,
     * since [mainHandler.post] from a dead Activity is harmless (just a no-op-ish
     * update to a detached View) but an interrupted half-written file or half-sent
     * request is not.
     *
     * Also unregisters the network callback [NetworkReliability.waitForNetwork] uses
     * to detect a reconnect, if one is still registered — e.g. the Activity is
     * destroyed while a download is paused waiting out a connectivity outage.
     * Without this, the callback (and everything it closes over) would leak for
     * as long as the process lives, since nothing else would ever unregister it.
     */
    override fun onDestroy() {
        networkReliability.unregisterActiveCallback()
        stopDotAnimations()
        bgExecutor.shutdown()
        // shutdown() (not shutdownNow()) — same reasoning as bgExecutor: this only
        // stops accepting *new* downloads, it doesn't interrupt ones already running,
        // so a download in progress when the Activity goes away can still finish.
        downloadManager.shutdown()
        super.onDestroy()
    }

    // ── Clipboard & share ─────────────────────────────────────────────────────

    private fun copyLogToClipboard() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Build Log", text))
        appendLog("✓ Log copied to clipboard.")
    }

    private fun saveLogToFile() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        bgExecutor.execute {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
                val file  = File(cacheDir, "build_log_$stamp.txt").also { it.writeText(text) }
                val uri   = FileProvider.getUriForFile(this, "${packageName}.provider", file)
                mainHandler.post {
                    startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "Share Build Log"))
                }
            } catch (e: Exception) { appendLog("✗ Share error: ${e.message}") }
        }
    }

    // ── UI helpers ────────────────────────────────────────────────────────────
    // Shared UI-feedback surface every feature controller reports through
    // (activity.appendLog/setStatus/setBusy) — kept here rather than split out
    // since they're simple, tied directly to specific views owned by this
    // Activity's layout, and used identically by literally every feature.

    internal fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(when {
            text.contains("✓") || text.startsWith("Ready") -> 0xFF4CAF50.toInt()
            text.contains("✗") || text.contains("failed")  -> 0xFFFF5252.toInt()
            else                                             -> 0xFFFFFFFF.toInt()
        })
    }

    internal fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")

        // A verbose build can stream hundreds of lines in quick succession; without
        // this guard each one queued its own fullScroll() pass on the scroll view's
        // message queue. Collapse any such burst into a single pending scroll.
        if (!scrollPending) {
            scrollPending = true
            scrollLog.post {
                scrollPending = false
                scrollLog.fullScroll(ScrollView.FOCUS_DOWN)
            }
        }

        if (tvLog.length() > LOG_CHAR_CAP) {
            // Trim back to 3/4 of the cap rather than the bare minimum, so we're
            // not re-trimming on almost every subsequent line once near the limit.
            tvLog.editableText?.delete(0, tvLog.length() - (LOG_CHAR_CAP * 3 / 4))
        }
    }

    internal fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy                   = busy
        progressBar.visibility   = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
        // Download button: only re-enable when not busy AND an artifact URL is known
        if (!busy) btnDownloadApk?.isEnabled = (artifactDownloadUrl != null)

        // Animate console dots while busy
        if (busy) startDotAnimations() else { stopDotAnimations(); startIdleDotAnimations() }
    }

    private fun startIdleDotAnimations() {
        stopDotAnimations()
        fun idleAnim(target: View?, delayMs: Long): android.animation.AnimatorSet {
            val sx = android.animation.ObjectAnimator.ofFloat(target, "scaleX", 1f, 1.25f).apply {
                duration = 900; startDelay = delayMs; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            }
            val sy = android.animation.ObjectAnimator.ofFloat(target, "scaleY", 1f, 1.25f).apply {
                duration = 900; startDelay = delayMs; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            }
            val al = android.animation.ObjectAnimator.ofFloat(target, "alpha", 1f, 0.55f).apply {
                duration = 900; startDelay = delayMs; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            }
            return android.animation.AnimatorSet().also { it.playTogether(sx, sy, al); it.start() }
        }
        dotAnimRed    = idleAnim(dotRed,    0L)
        dotAnimYellow = idleAnim(dotYellow, 300L)
        dotAnimGreen  = idleAnim(dotGreen,  600L)
    }

    private fun startDotAnimations() {
        stopDotAnimations()
        fun buildAnim(resId: Int, target: View?): android.animation.AnimatorSet? {
            if (target == null) return null
            val set = android.animation.AnimatorInflater.loadAnimator(this, resId) as android.animation.AnimatorSet
            set.childAnimations.forEach { (it as? android.animation.ObjectAnimator)?.target = target }
            set.start()
            return set
        }
        dotAnimRed    = buildAnim(R.animator.dot_pulse_red,    dotRed)
        dotAnimYellow = buildAnim(R.animator.dot_pulse_yellow, dotYellow)
        dotAnimGreen  = buildAnim(R.animator.dot_pulse_green,  dotGreen)
    }

    private fun stopDotAnimations() {
        listOf(dotAnimRed, dotAnimYellow, dotAnimGreen).forEach { it?.cancel() }
        dotAnimRed = null; dotAnimYellow = null; dotAnimGreen = null
        dotRed?.apply   { scaleX = 1f; scaleY = 1f; alpha = 1f }
        dotYellow?.apply { scaleX = 1f; scaleY = 1f; alpha = 1f }
        dotGreen?.apply  { scaleX = 1f; scaleY = 1f; alpha = 1f }
    }
}
