package com.zipapkbuilder.core

import android.content.Context
import android.widget.Button
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.graphics.drawable.DrawableCompat

/**
 * Sets a tinted vector icon at the start of this [Button]'s text.
 *
 * Used in place of the old convention of prefixing dialog button labels with an emoji glyph
 * (e.g. "🗑 Delete"), which renders inconsistently across devices/system fonts. A real vector
 * drawable always renders crisp and matches the app's own icon set and color system.
 *
 * @param iconRes drawable to show, tinted to a flat, single color.
 * @param tint icon color; pass the same color used for the button's text for a cohesive look.
 * @param paddingDp gap between the icon and the text, in dp.
 */
fun Button.setStartIcon(
    context: Context,
    @DrawableRes iconRes: Int,
    @ColorInt tint: Int,
    paddingDp: Int = 6
) {
    val icon = AppCompatResources.getDrawable(context, iconRes)?.mutate() ?: return
    DrawableCompat.setTint(icon, tint)
    setCompoundDrawablesRelativeWithIntrinsicBounds(icon, null, null, null)
    compoundDrawablePadding = (paddingDp * context.resources.displayMetrics.density).toInt()
}
