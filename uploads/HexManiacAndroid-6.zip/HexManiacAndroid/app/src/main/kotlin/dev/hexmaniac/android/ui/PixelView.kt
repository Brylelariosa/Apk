package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.View
import dev.hexmaniac.core.graphics.Picture

/**
 * Shows a [Picture] with hard pixel edges. A picture that fits in the box is drawn as large as it can be with every
 * pixel a square of a whole number of screen pixels (a sprite of 64 by 64 pixels comes out at 4 screen pixels per
 * pixel in a box of 96 dp on a phone with 2.75 pixels to the dp). A picture that is larger than the box, such as a tile
 * map, is drawn smaller to fit. The box is 96 dp wide and 192 dp high until [fit] changes it.
 */
class PixelView(context: Context) : View(context) {
    private val paint = Paint()
    private val source = Rect()
    private val target = Rect()
    private var limitWidth = context.dp(96)
    private var limitHeight = context.dp(192)
    private var bitmap: Bitmap? = null
    private var shown: Picture? = null

    /** Sets the size, in pixels, of the box the picture has to fit in. */
    fun fit(width: Int, height: Int) {
        if (width == limitWidth && height == limitHeight) return
        limitWidth = width
        limitHeight = height
        requestLayout()
        invalidate()
    }

    /** Shows [picture]; null shows nothing. Showing the picture that is shown already does no work. */
    fun show(picture: Picture?) {
        if (picture === shown) return
        shown = picture
        bitmap = picture?.let { Bitmap.createBitmap(it.pixels, it.width, it.height, Bitmap.Config.ARGB_8888) }
        requestLayout()
        invalidate()
    }

    /** How many screen pixels one pixel of the picture takes: a whole number, or less than one for a big picture. */
    private fun scaleOf(map: Bitmap): Float {
        val ratio = minOf(limitWidth.toFloat() / map.width, limitHeight.toFloat() / map.height)
        return if (ratio >= 1f) ratio.toInt().toFloat() else ratio
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val map = bitmap
        if (map == null) {
            setMeasuredDimension(0, 0)
        } else {
            val scale = scaleOf(map)
            setMeasuredDimension(maxOf(1, (map.width * scale + 0.5f).toInt()), maxOf(1, (map.height * scale + 0.5f).toInt()))
        }
    }

    override fun onDraw(canvas: Canvas) {
        val map = bitmap ?: return
        // Magnified pixels stay square and sharp; a reduced picture is smoothed so that thin lines do not drop out.
        paint.isFilterBitmap = scaleOf(map) < 1f
        source.set(0, 0, map.width, map.height)
        target.set(0, 0, width, height)
        canvas.drawBitmap(map, source, target, paint)
    }
}
