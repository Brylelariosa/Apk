package dev.hexmaniac.android.ui

import android.content.Context
import android.view.Gravity
import android.widget.FrameLayout
import dev.hexmaniac.android.R

/**
 * A raised area that shows one [picture] in its middle, as large as the area allows (see [PixelView.fit]). Setting
 * a click listener on the stage makes the whole area the touch target, not only the picture.
 */
class PictureStage(context: Context) : FrameLayout(context) {
    val picture = PixelView(context)
    private val margin = context.dp(12)

    init {
        setBackgroundColor(context.getColor(R.color.surface_raised))
        addView(picture, LayoutParams(WRAP, WRAP, Gravity.CENTER))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        picture.fit(maxOf(1, w - 2 * margin), maxOf(1, h - 2 * margin))
    }
}
