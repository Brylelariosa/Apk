package dev.hexmaniac.android.tables

import android.app.Activity
import android.graphics.Typeface
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.ActionRow
import dev.hexmaniac.android.ui.MATCH
import dev.hexmaniac.android.ui.PictureStage
import dev.hexmaniac.android.ui.WRAP
import dev.hexmaniac.android.ui.dp
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.table.Graphic
import dev.hexmaniac.core.table.GraphicEntry
import dev.hexmaniac.core.table.GraphicKind

/**
 * One graphic of the game drawn as large as the screen allows, with what it is and which palette paints it. A tap on
 * the picture tries the next palette; the bar below steps to the neighbouring graphics of the list it was opened from.
 * The graphic is found again by its name whenever the ROM changes, because editing a pointer moves its data.
 */
class GraphicPage(
    private val activity: Activity,
    private val browser: TableBrowser,
    private val navigator: TableNavigator,
    private val names: List<String>,
    private var position: Int,
) : Page {

    private val root = LinearLayout(activity)
    private val stage = PictureStage(activity)
    private val summary = TextView(activity)
    private val where = TextView(activity)
    private val paletteNote = TextView(activity)
    private val actions = ActionRow(activity)
    private var previousAction = 0
    private var nextAction = 0
    private var paletteAction = 0

    private var entry: GraphicEntry? = null
    private var graphic: Graphic? = null

    /** Which palette paints the picture; it wraps around, so counting up is how the next one is asked for. */
    private var choice = 0

    override var title: String = ""
        private set
    override var subtitle: String? = null
        private set

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(activity.getColor(R.color.bg))

        stage.setOnClickListener { nextPalette() }
        root.addView(stage, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(details(), LinearLayout.LayoutParams(MATCH, WRAP))

        previousAction = actions.add(R.string.bar_previous) { moveTo(position - 1) }
        nextAction = actions.add(R.string.bar_next) { moveTo(position + 1) }
        paletteAction = actions.add(R.string.bar_palette) { nextPalette() }
        actions.add(R.string.bar_in_hex) { showInHex() }
        root.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP))

        reload()
    }

    override val view: View get() = root

    override val hexLocation: HexLocation? get() = entry?.let { HexLocation(it.offset, 1) }

    override fun refresh(): Boolean {
        if (browser.tables.graphicEntry(names[position]) == null) return false
        reload()
        return true
    }

    /** The text under the picture: what it is, where its data is, and which palette paints it. */
    private fun details(): LinearLayout {
        summary.textSize = 15f
        summary.setTextColor(activity.getColor(R.color.text_primary))
        where.textSize = 11.5f
        where.typeface = Typeface.MONOSPACE
        where.setTextColor(activity.getColor(R.color.text_dim))
        paletteNote.textSize = 12.5f
        paletteNote.setTextColor(activity.getColor(R.color.text_secondary))

        val box = LinearLayout(activity)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(activity.dp(16), activity.dp(12), activity.dp(16), activity.dp(12))
        box.addView(summary, LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(where, LinearLayout.LayoutParams(MATCH, WRAP))
        val noteParams = LinearLayout.LayoutParams(MATCH, WRAP)
        noteParams.topMargin = activity.dp(6)
        box.addView(paletteNote, noteParams)
        return box
    }

    /** Reads the graphic again and brings the picture, the texts, the header and the buttons up to date. */
    private fun reload() {
        val found = browser.tables.graphicEntry(names[position])
        val drawn = found?.let { browser.tables.graphic(it, choice) }
        entry = found
        graphic = drawn

        title = found?.label ?: names[position]
        subtitle = activity.getString(R.string.graphic_page_subtitle, position + 1, names.size)
        stage.picture.show(drawn?.picture)
        summary.text = found?.let { activity.graphicSummary(it) }.orEmpty()
        where.text = found?.let { activity.getString(R.string.graphic_where, it.name, HexText.hex(it.offset, 6)) }.orEmpty()
        val note = noteFor(found, drawn)
        paletteNote.text = note
        paletteNote.visibility = if (note.isEmpty()) View.GONE else View.VISIBLE

        actions.setActionEnabled(previousAction, position > 0)
        actions.setActionEnabled(nextAction, position + 1 < names.size)
        actions.setActionEnabled(paletteAction, (drawn?.choices ?: 0) > 1)
    }

    private fun noteFor(entry: GraphicEntry?, graphic: Graphic?): String = when {
        entry == null -> activity.getString(R.string.graphic_gone)
        graphic == null -> activity.getString(R.string.graphic_unreadable)
        entry.kind == GraphicKind.PALETTE -> ""
        graphic.choices == 0 -> activity.getString(R.string.graphic_no_palette)
        graphic.choices == 1 -> activity.getString(R.string.graphic_palette_one, graphic.palette)
        else -> activity.getString(R.string.graphic_palette_many, graphic.palette, graphic.choice + 1, graphic.choices)
    }

    /** Paints the picture with the next of its palettes; does nothing when it has only one. */
    private fun nextPalette() {
        val current = graphic ?: return
        if (current.choices < 2) return
        choice = current.choice + 1
        reload()
    }

    private fun moveTo(newPosition: Int) {
        if (newPosition !in names.indices) return
        position = newPosition
        choice = 0
        reload()
        navigator.headerChanged()
    }

    private fun showInHex() {
        val current = entry ?: return
        navigator.showInHex(current.offset, 1)
    }
}
