package dev.hexmaniac.android.tables

import android.content.Context
import dev.hexmaniac.android.R
import dev.hexmaniac.core.table.GraphicEntry
import dev.hexmaniac.core.table.GraphicKind

/** "1 row" or "12 rows". */
fun Context.rowCountText(count: Int): String = resources.getQuantityString(R.plurals.row_count, count, count)

/** "1 table" or "12 tables". */
fun Context.tableCountText(count: Int): String = resources.getQuantityString(R.plurals.table_count, count, count)

/** "1 graphic" or "12 graphics". */
fun Context.graphicCountText(count: Int): String = resources.getQuantityString(R.plurals.graphic_count, count, count)

/** What a graphic is, in a few words: "Tile map, 240 x 160 pixels, 4 bit". */
fun Context.graphicSummary(entry: GraphicEntry): String = when (entry.kind) {
    GraphicKind.SPRITE -> getString(R.string.graphic_sprite_summary, entry.pixelWidth, entry.pixelHeight, entry.bits)
    GraphicKind.TILESET -> getString(R.string.graphic_tileset_summary, entry.bits)
    GraphicKind.TILEMAP -> getString(R.string.graphic_tilemap_summary, entry.pixelWidth, entry.pixelHeight, entry.bits)
    GraphicKind.PALETTE -> getString(R.string.graphic_palette_summary)
}
