package dev.hexmaniac.android.tables

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import dev.hexmaniac.android.R
import dev.hexmaniac.android.ui.HeadedAdapter
import dev.hexmaniac.android.ui.MenuAction
import dev.hexmaniac.android.ui.SearchList
import dev.hexmaniac.android.ui.TwoLineRow
import dev.hexmaniac.android.ui.chooseAction
import dev.hexmaniac.core.rom.HexText
import dev.hexmaniac.core.table.GraphicEntry
import dev.hexmaniac.core.table.GraphicSection
import dev.hexmaniac.core.table.TextFilter

/**
 * The sprites, tilesets, tile maps and palettes of the game that are not a field of a table, under the headings of
 * the reference data. A tap opens the picture; the viewer steps through the graphics that are listed here.
 */
class GraphicListPage(
    private val activity: Activity,
    private val browser: TableBrowser,
    private val navigator: TableNavigator,
) : Page {

    private sealed class Item {
        class Heading(val title: String) : Item()

        class Entry(val entry: GraphicEntry) : Item()
    }

    private val search = SearchList(
        activity,
        activity.getString(R.string.graphics_search_hint),
        activity.getString(R.string.graphics_none),
    ) { queryChanged(it) }
    private val adapter = Adapter()
    private var sections: List<GraphicSection> = browser.tables.graphics()
    private var items: List<Item> = emptyList()

    init {
        search.listView.adapter = adapter
        search.listView.setOnItemClickListener { _, _, position, _ -> entryAt(position)?.let { open(it) } }
        search.listView.setOnItemLongClickListener { _, _, position, _ ->
            val entry = entryAt(position)
            if (entry != null) offerActions(entry)
            entry != null
        }
        showMatches("")
    }

    override val view: View get() = search

    override val title: String get() = activity.getString(R.string.graphics_title)

    override val subtitle: String get() = activity.graphicCountText(sections.sumOf { it.entries.size })

    override fun refresh(): Boolean {
        sections = browser.tables.graphics()
        showMatches(search.query)
        return true
    }

    private fun queryChanged(query: String) {
        showMatches(query)
        search.listView.setSelection(0)
    }

    /** Lists the graphics whose name, kind or heading contains every word of [query]. */
    private fun showMatches(query: String) {
        val filter = TextFilter(query)
        val matching = ArrayList<Item>()
        for (section in sections) {
            val entries = section.entries.filter { filter.matches(section.title + " " + it.name + " " + activity.graphicSummary(it)) }
            if (entries.isEmpty()) continue
            matching.add(Item.Heading(section.title))
            for (entry in entries) matching.add(Item.Entry(entry))
        }
        items = matching
        search.emptyMessage = activity.getString(if (filter.isEmpty) R.string.graphics_none else R.string.search_no_matches)
        adapter.notifyDataSetChanged()
    }

    private fun entryAt(position: Int): GraphicEntry? = (items.getOrNull(position) as? Item.Entry)?.entry

    /** Opens [entry]; the viewer's Previous and Next buttons step through the graphics that are listed now. */
    private fun open(entry: GraphicEntry) {
        val names = items.mapNotNull { (it as? Item.Entry)?.entry?.name }
        navigator.openGraphic(names, names.indexOf(entry.name))
    }

    private fun offerActions(entry: GraphicEntry) {
        activity.chooseAction(
            entry.label,
            listOf(
                MenuAction(activity.getString(R.string.open_graphic)) { open(entry) },
                MenuAction(activity.getString(R.string.show_graphic_in_hex)) { navigator.showInHex(entry.offset, 1) },
            ),
        )
    }

    private inner class Adapter : HeadedAdapter(activity) {
        override fun getCount(): Int = items.size

        override fun isHeading(position: Int): Boolean = items[position] is Item.Heading

        override fun headingText(position: Int): String = (items[position] as Item.Heading).title

        override fun rowView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? TwoLineRow) ?: TwoLineRow(activity)
            val entry = (items[position] as Item.Entry).entry
            val line = activity.getString(R.string.graphic_entry_line, activity.graphicSummary(entry), HexText.hex(entry.offset, 6))
            row.bind(null, entry.label, line)
            return row
        }
    }
}
