package dev.hexmaniac.android.tables

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import dev.hexmaniac.android.R
import dev.hexmaniac.android.session.RomSaver
import dev.hexmaniac.android.session.RomSession
import dev.hexmaniac.android.session.SessionStore
import dev.hexmaniac.android.ui.BusyRunner
import dev.hexmaniac.android.ui.showMessage
import dev.hexmaniac.android.ui.toast
import dev.hexmaniac.android.ui.updateUndoRedo
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.TablePath
import dev.hexmaniac.core.table.TableSection

/**
 * The table browser: the data tables of the open ROM as lists of rows and forms of values, instead of bytes. It is a
 * stack of pages (see [Page]) over the same document as the hex view, so every edit made here is an undo step there.
 * "Show in hex" closes the browser and tells the hex view what to select.
 */
class TablesActivity : Activity(), TableNavigator {

    private lateinit var busy: BusyRunner
    private lateinit var saver: RomSaver
    private lateinit var stack: PageStack
    private var session: RomSession? = null
    private var browser: TableBrowser? = null
    private var editors: FieldEditors? = null

    private val documentListener = RomDocument.Listener { onDocumentChanged() }

    /** What loading the tables produces: the engine, and the table list it found. */
    private class Loaded(val browser: TableBrowser, val sections: List<TableSection>)

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        busy = BusyRunner(this) { showError(it) }
        saver = RomSaver(this, busy)
        stack = PageStack(this) { showHeader(it) }
        stack.container.setBackgroundColor(getColor(R.color.bg))
        setContentView(stack.container)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.title = getString(R.string.tables_title)

        val current = SessionStore.current
        if (current == null) {
            // The app was restarted behind this screen's back: there is no ROM to show.
            finish()
            return
        }
        session = current
        load(current)
    }

    override fun onDestroy() {
        session?.document?.removeListener(documentListener)
        busy.dismiss()
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() = goBack()

    /** Closes the top page; the last page closes the browser. */
    private fun goBack() {
        if (!stack.pop()) finish()
    }

    /** Reads the table definitions and finds the tables, which takes a moment, behind the busy dialog. */
    private fun load(current: RomSession) {
        busy.run(getString(R.string.busy_reading_tables), {
            val opened = TableBrowser.open(current)
            opened?.let { Loaded(it, it.tables.sections()) }
        }) { loaded ->
            if (loaded == null) {
                showTablesUnavailable(current) { finish() }
            } else {
                start(current, loaded)
            }
        }
    }

    private fun start(current: RomSession, loaded: Loaded) {
        browser = loaded.browser
        editors = FieldEditors(this, loaded.browser, this)
        current.document.addListener(documentListener)
        stack.push(TableListPage(this, loaded.browser, this, loaded.sections))
    }

    // ------------------------------------------------------------------ header and menu

    private fun showHeader(page: Page) {
        actionBar?.title = page.title
        actionBar?.subtitle = page.subtitle
        invalidateOptionsMenu()
    }

    override fun headerChanged() {
        stack.top?.let { showHeader(it) }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.tables, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val document = session?.document
        updateUndoRedo(menu, document)
        menu.findItem(R.id.action_save)?.isEnabled = document?.isDirty == true
        menu.findItem(R.id.action_show_hex)?.isEnabled = stack.top?.hexLocation != null
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> goBack()
            R.id.action_undo -> session?.document?.undo()
            R.id.action_redo -> session?.document?.redo()
            R.id.action_save -> session?.let { saver.save(it) }
            R.id.action_show_hex -> stack.top?.hexLocation?.let { showInHex(it.offset, it.length) }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ------------------------------------------------------------------ navigation

    override fun openTable(path: TablePath, heading: String) {
        val current = browser ?: return
        if (current.tables.locate(path) == null) {
            toast(R.string.toast_table_gone)
            return
        }
        stack.push(RowListPage(this, current, this, path, heading))
    }

    override fun openRow(path: TablePath, row: Int) {
        val current = browser ?: return
        val form = editors ?: return
        val table = current.tables.locate(path)
        if (table == null || row !in 0 until table.rowCount) {
            toast(R.string.toast_table_gone)
            return
        }
        stack.push(RowPage(this, current, this, form, path, row))
    }

    override fun openGraphics() {
        val current = browser ?: return
        stack.push(GraphicListPage(this, current, this))
    }

    override fun openGraphic(names: List<String>, position: Int) {
        val current = browser ?: return
        if (position !in names.indices) return
        stack.push(GraphicPage(this, current, this, names, position))
    }

    override fun showInHex(offset: Int, length: Int) {
        setResult(RESULT_OK, Intent().putExtra(EXTRA_OFFSET, offset).putExtra(EXTRA_LENGTH, length))
        finish()
    }

    // ------------------------------------------------------------------ changes and errors

    /** The ROM changed (an edit here, an undo or a save): everything read from it is out of date. */
    private fun onDocumentChanged() {
        browser?.invalidate()
        stack.romChanged()
        invalidateOptionsMenu()
    }

    private fun showError(error: Throwable) {
        val text = when (error) {
            is OutOfMemoryError -> getString(R.string.error_out_of_memory)
            else -> error.message ?: error.javaClass.simpleName
        }
        showMessage(getString(R.string.dialog_error_title), text)
    }

    companion object {
        /** Result extras: the offset and length "show in hex" asks the hex view to select. */
        const val EXTRA_OFFSET = "offset"
        const val EXTRA_LENGTH = "length"
    }
}
