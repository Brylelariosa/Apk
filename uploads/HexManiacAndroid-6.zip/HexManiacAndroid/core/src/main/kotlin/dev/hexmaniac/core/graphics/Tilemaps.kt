package dev.hexmaniac.core.graphics

/**
 * Tile maps: grids of cells that each pick a tile of a tileset. A cell is usually two bytes (little endian): the number
 * of the tile in the low 10 bits, a horizontal flip in bit 10, a vertical flip in bit 11 and the number of the palette
 * bank (a page of 16 colours) in the high 4 bits. A compressed map that holds fewer bytes than that has one byte per
 * cell, which is the number of the tile.
 */
internal object Tilemaps {
    private const val TILE_MASK = 0x3FF
    private const val H_FLIP = 1 shl 10
    private const val V_FLIP = 1 shl 11
    private const val TILE_PIXELS = 8

    /** How many bytes a cell takes in a map of [cells] cells whose data is [size] bytes long. */
    fun cellBytes(compressed: Boolean, cells: Int, size: Int): Int = if (compressed && cells * 2 > size) 1 else 2

    /**
     * The palette slots of a map of [tilesWide] by [tilesHigh] cells, as `tilesWide * 8` columns by `tilesHigh * 8` rows.
     * A slot is the colour of the tile's pixel plus 16 times the palette bank of the cell. The map starts at
     * [mapOffset] of [map], the tiles (of [bits] bits per pixel) at [tilesOffset] of [tiles]. Cells and tiles beyond the
     * end of their data read as zero.
     */
    fun slots(
        map: ByteArray,
        mapOffset: Int,
        cellBytes: Int,
        tilesWide: Int,
        tilesHigh: Int,
        tiles: ByteArray,
        tilesOffset: Int,
        bits: Int,
    ): IntArray {
        require(cellBytes == 1 || cellBytes == 2) { "A cell takes one or two bytes" }
        val width = tilesWide * TILE_PIXELS
        val result = IntArray(width * tilesHigh * TILE_PIXELS)
        val bytesPerTile = Tiles.bytesPerTile(bits)
        val cache = HashMap<Int, IntArray>()
        for (cellY in 0 until tilesHigh) {
            for (cellX in 0 until tilesWide) {
                val cell = cellValue(map, mapOffset, cellBytes, cellY * tilesWide + cellX)
                val tile = if (cellBytes == 1) cell else cell and TILE_MASK
                val bank = if (cellBytes == 1) 0 else cell ushr 12
                val pixels = cache.getOrPut(tile) { Tiles.indexes(tiles, tilesOffset + tile * bytesPerTile, bits, 1, 1) }
                val flipX = cellBytes == 2 && cell and H_FLIP != 0
                val flipY = cellBytes == 2 && cell and V_FLIP != 0
                val left = cellX * TILE_PIXELS
                val top = cellY * TILE_PIXELS
                for (y in 0 until TILE_PIXELS) {
                    val fromY = if (flipY) TILE_PIXELS - 1 - y else y
                    for (x in 0 until TILE_PIXELS) {
                        val fromX = if (flipX) TILE_PIXELS - 1 - x else x
                        result[(top + y) * width + left + x] = pixels[fromY * TILE_PIXELS + fromX] + (bank shl 4)
                    }
                }
            }
        }
        return result
    }

    private fun cellValue(map: ByteArray, offset: Int, cellBytes: Int, cell: Int): Int {
        val at = offset.toLong() + cell.toLong() * cellBytes
        val low = byteAt(map, at)
        return if (cellBytes == 1) low else low or (byteAt(map, at + 1) shl 8)
    }

    private fun byteAt(data: ByteArray, at: Long): Int = if (at >= 0 && at < data.size) data[at.toInt()].toInt() and 0xFF else 0
}
