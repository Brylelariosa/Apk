package dev.hexmaniac.core.table

import dev.hexmaniac.core.graphics.GraphicSpec
import dev.hexmaniac.core.graphics.Lz77
import dev.hexmaniac.core.graphics.Palettes
import dev.hexmaniac.core.graphics.Picture
import dev.hexmaniac.core.graphics.Tilemaps
import dev.hexmaniac.core.graphics.Tiles
import dev.hexmaniac.core.rom.RomData
import dev.hexmaniac.core.table.format.Field
import dev.hexmaniac.core.table.format.FieldKind
import dev.hexmaniac.core.table.format.PointerKind

/** What a pointer to a sprite, tileset, tile map or palette looks like: a picture to show with a few words about it. */
class Graphic(
    val picture: Picture,
    /** Name of the palette that paints a sprite ("normal", "shiny"), or null when there is none to name. */
    val palette: String?,
    /** How many palettes the sprite can be painted with; 0 when it cannot be painted with a palette of the game. */
    val choices: Int,
    /** Which of them [picture] is painted with. */
    val choice: Int,
)

/**
 * Draws the pictures that table rows and the reference data point to. Sprites are painted with a palette that the game
 * keeps in one of the places HexManiac looks in: the palette named by the sprite's format, the row with the same number
 * of the table that format names, or (when it names nothing) the palettes that sit in the same row of this or a related
 * table. A tile map is drawn from the tiles of its tileset and painted with the palette of that tileset.
 */
internal class GraphicsReader(private val rom: RomData, private val catalog: TableCatalog) {

    /** Data to read from: [bytes] from [start] on. Compressed data is a copy that starts at 0. */
    private class Source(val bytes: ByteArray, val start: Int)

    /** Where a graphic is used: row [row] of [table], or nowhere in particular ([table] is null) for a graphic of its own. */
    private class Place(val table: TableLocation?, val row: Int)

    private class PaletteRef(val name: String, val spec: GraphicSpec.Palette, val offset: Int)

    /** The tiles a tile map is drawn from, and the hint that names the palette of those tiles. */
    private class TileData(val source: Source, val paletteHint: String?)

    /** The picture the pointer field [index] of row [row] of [table] leads to; see [TableSet.graphic]. */
    fun graphic(table: TableLocation, row: Int, index: Int, choice: Int): Graphic? {
        if (row < 0 || row >= table.rowCount || index < 0 || index >= table.schema.fields.size) return null
        val field = catalog.concreteField(table, row, index)
        if (field.kind != FieldKind.POINTER) return null
        val pointer = field.pointer ?: return null
        if (pointer.kind != PointerKind.SPECIAL) return null
        val spec = GraphicSpec.parse(pointer.inner) ?: return null
        val target = rom.pointerTarget(table.rowStart(row) + field.offset)
        if (target < 0) return null
        return draw(spec, target, Place(table, row), choice)
    }

    /**
     * The single graphic called [name] in the reference data. When the pointer to it sits in a row of a table, that row
     * is where its palette is looked for, as for the sprites of the table.
     */
    fun single(name: String, choice: Int): Graphic? {
        val single = catalog.standalone(name) ?: return null
        val spec = GraphicSpec.parse(single.format) ?: return null
        if (single.offset < 0 || single.offset >= rom.size) return null
        val at = catalog.rowAt(single.pointer)
        return draw(spec, single.offset, Place(at?.first, at?.second ?: -1), choice)
    }

    private fun draw(spec: GraphicSpec, target: Int, place: Place, choice: Int): Graphic? = when (spec) {
        is GraphicSpec.Sprite -> sprite(spec, target, place, choice)
        is GraphicSpec.Tileset -> tileset(spec, target, place, choice)
        is GraphicSpec.Palette -> palette(spec, target)
        is GraphicSpec.Tilemap -> tilemap(spec, target, place, choice)
    }

    // ---- drawing ----

    private fun source(compressed: Boolean, target: Int): Source? {
        if (!compressed) return Source(rom.bytes, target)
        val bytes = Lz77.decompress(rom.bytes, target) ?: return null
        return Source(bytes, 0)
    }

    private fun sprite(spec: GraphicSpec.Sprite, target: Int, place: Place, choice: Int): Graphic? {
        val source = source(spec.compressed, target) ?: return null
        val indexes = Tiles.indexes(source.bytes, source.start, spec.bits, spec.tilesWide, spec.tilesHigh)
        return painted(indexes, spec.tilesWide * 8, spec.tilesHigh * 8, spec.bits, spec.paletteHint, place, choice)
    }

    /** Tiles are laid out 16 to a row, as many as the data holds (or the format says), but never more than [MAX_TILES]. */
    private fun tileset(spec: GraphicSpec.Tileset, target: Int, place: Place, choice: Int): Graphic? {
        val source = source(spec.compressed, target) ?: return null
        val held = if (spec.compressed) source.bytes.size / Tiles.bytesPerTile(spec.bits) else Int.MAX_VALUE
        val tiles = minOf(if (spec.tiles > 0) spec.tiles else held, MAX_TILES)
        if (tiles < 1) return null
        val wide = minOf(TILES_PER_ROW, tiles)
        val high = (tiles + wide - 1) / wide
        val indexes = Tiles.indexes(source.bytes, source.start, spec.bits, wide, high)
        return painted(indexes, wide * 8, high * 8, spec.bits, spec.paletteHint, place, choice)
    }

    /** The map drawn with the tiles of its tileset; null when there is no tileset to be found or the map cannot be read. */
    private fun tilemap(spec: GraphicSpec.Tilemap, target: Int, place: Place, choice: Int): Graphic? {
        val map = source(spec.compressed, target) ?: return null
        val tiles = tilesFor(spec, place) ?: return null
        val cells = spec.tilesWide * spec.tilesHigh
        val cellBytes = Tilemaps.cellBytes(spec.compressed, cells, map.bytes.size)
        val slots = Tilemaps.slots(
            map.bytes, map.start, cellBytes, spec.tilesWide, spec.tilesHigh,
            tiles.source.bytes, tiles.source.start, spec.bits,
        )
        return mapped(slots, spec.tilesWide * 8, spec.tilesHigh * 8, spec.bits, tiles.paletteHint, place, choice)
    }

    /**
     * Where the tiles of a map are: in the tileset (or sprite) that the format names, or in the row of the named table
     * that goes with the map (the row the map itself is in), in the field the format names or else the first tileset.
     */
    private fun tilesFor(spec: GraphicSpec.Tilemap, place: Place): TileData? {
        val hint = spec.tilesetHint
        if (hint != null) {
            val single = catalog.standalone(hint)
            if (single != null) return tileData(GraphicSpec.parse(single.format), single.offset)
        }
        val hinted = (if (hint == null) place.table else catalog.location(hint)) ?: return null
        val row = place.row
        if (row < 0 || row >= hinted.rowCount) return null
        for (index in hinted.schema.fields.indices) {
            val field = catalog.concreteField(hinted, row, index)
            if (field.kind != FieldKind.POINTER) continue
            if (spec.member != null && field.name != spec.member) continue
            val pointer = field.pointer ?: continue
            if (pointer.kind != PointerKind.SPECIAL) continue
            val tileset = GraphicSpec.parse(pointer.inner) as? GraphicSpec.Tileset ?: continue
            val target = rom.pointerTarget(hinted.rowStart(row) + field.offset)
            if (target < 0) continue
            return tileData(tileset, target)
        }
        return null
    }

    /** A sprite is as good as a tileset: its tiles are the tiles of the map. */
    private fun tileData(spec: GraphicSpec?, target: Int): TileData? = when (spec) {
        is GraphicSpec.Tileset -> source(spec.compressed, target)?.let { TileData(it, spec.paletteHint) }
        is GraphicSpec.Sprite -> source(spec.compressed, target)?.let { TileData(it, spec.paletteHint) }
        else -> null
    }

    /** A sprite or tileset painted with the first page of its palette (all of it for 8 bit pixels). */
    private fun painted(
        indexes: IntArray,
        width: Int,
        height: Int,
        bits: Int,
        hint: String?,
        place: Place,
        choice: Int,
    ): Graphic {
        val grey = Palettes.grey(1 shl bits)
        val palettes = if (bits >= 4) palettesFor(place, hint) else emptyList()
        if (palettes.isEmpty()) return Graphic(Picture.painted(indexes, width, height, grey), null, 0, 0)
        val chosen = wrap(choice, palettes.size)
        val ref = palettes[chosen]
        val colors = (if (bits == 8) allColorsOf(ref) else firstPageOf(ref)) ?: grey
        return Graphic(Picture.painted(indexes, width, height, colors), ref.name, palettes.size, chosen)
    }

    /** A tile map painted with all the pages of its palette, each cell with the page of its bank. */
    private fun mapped(
        slots: IntArray,
        width: Int,
        height: Int,
        bits: Int,
        hint: String?,
        place: Place,
        choice: Int,
    ): Graphic {
        val grey = Palettes.grey(1 shl bits)
        val palettes = if (bits >= 4) palettesFor(place, hint) else emptyList()
        if (palettes.isEmpty()) return Graphic(Picture.slotted(slots, width, height, grey, 0), null, 0, 0)
        val chosen = wrap(choice, palettes.size)
        val ref = palettes[chosen]
        val colors = allColorsOf(ref) ?: return Graphic(Picture.slotted(slots, width, height, grey, 0), ref.name, palettes.size, chosen)
        return Graphic(Picture.slotted(slots, width, height, colors, ref.spec.firstPage), ref.name, palettes.size, chosen)
    }

    /** All the pages of a palette as a grid of colours, 16 to a row. */
    private fun palette(spec: GraphicSpec.Palette, target: Int): Graphic? {
        val source = source(spec.compressed, target) ?: return null
        val colors = Palettes.read(source.bytes, source.start, (1 shl spec.bits) * pagesOf(spec, source))
        return Graphic(Picture.swatches(colors, SWATCHES_PER_ROW), null, 0, 0)
    }

    /** The first page of the palette. */
    private fun firstPageOf(ref: PaletteRef): IntArray? {
        val source = source(ref.spec.compressed, ref.offset) ?: return null
        return Palettes.read(source.bytes, source.start, 1 shl ref.spec.bits)
    }

    /** All pages of the palette, one after the other. */
    private fun allColorsOf(ref: PaletteRef): IntArray? {
        val source = source(ref.spec.compressed, ref.offset) ?: return null
        return Palettes.read(source.bytes, source.start, (1 shl ref.spec.bits) * pagesOf(ref.spec, source))
    }

    /** The pages of a palette: as many as the format says, or as many as compressed data holds. */
    private fun pagesOf(spec: GraphicSpec.Palette, source: Source): Int {
        val perPage = 1 shl spec.bits
        val limit = 256 / perPage
        return (if (spec.compressed) source.bytes.size / (perPage * 2) else spec.pages).coerceIn(1, limit)
    }

    private fun wrap(choice: Int, count: Int): Int = ((choice % count) + count) % count

    // ---- finding the palette ----

    private fun palettesFor(place: Place, hint: String?): List<PaletteRef> {
        val found = LinkedHashMap<Int, PaletteRef>()
        val candidates = ArrayList<PaletteRef>()
        val table = place.table
        if (!hint.isNullOrEmpty()) {
            candidates.addAll(hinted(place.row, hint))
        } else if (table != null && place.row >= 0) {
            for (related in catalog.related(table)) {
                if (place.row < related.rowCount) candidates.addAll(palettesIn(related, place.row, own = false))
            }
            candidates.addAll(palettesIn(table, place.row, own = true))
        }
        for (ref in candidates) found.putIfAbsent(ref.offset, ref)
        return found.values.toList()
    }

    /** The palettes a format's hint leads to; [row] is the row of the sprite in its own table, or -1 for a graphic of its own. */
    private fun hinted(row: Int, hint: String): List<PaletteRef> {
        val name = hint.substringBefore(':')
        val key = if (hint.contains(':')) hint.substringAfter(':') else ""

        val single = catalog.standalone(name)
        if (single != null) {
            val spec = GraphicSpec.parse(single.format) as? GraphicSpec.Palette
            if (spec != null && single.offset >= 0 && single.offset < rom.size) {
                return listOf(PaletteRef(shortName(name), spec, single.offset))
            }
        }

        val hintedTable = catalog.location(name) ?: return emptyList()
        val result = ArrayList<PaletteRef>()
        result.addAll(chosenByNumber(hintedTable, row))
        if (key.contains('=')) result.addAll(chosenByKey(hintedTable, key))
        if (row >= 0 && row < hintedTable.rowCount) result.addAll(palettesIn(hintedTable, row, own = false))
        return result
    }

    /** A table with one number per row that picks a row of a table of palettes, as the icons of the Pokemon do. */
    private fun chosenByNumber(hinted: TableLocation, row: Int): List<PaletteRef> {
        val fields = hinted.schema.fields
        if (fields.size != 1 || row < 0 || row >= hinted.rowCount) return emptyList()
        val field = fields[0]
        val enumName = field.enumName ?: return emptyList()
        if (field.kind != FieldKind.NUMBER || enumName.toIntOrNull() != null) return emptyList()
        val palettes = catalog.location(enumName) ?: return emptyList()
        val number = Values.fieldValue(rom, hinted.rowStart(row), field)
        if (number < 0 || number >= palettes.rowCount) return emptyList()
        return palettesIn(palettes, number.toInt(), own = false).take(1)
    }

    /** A hint such as `id=1100`: the row of the table whose value of the field `id` is 1100. */
    private fun chosenByKey(hinted: TableLocation, key: String): List<PaletteRef> {
        val field = hinted.schema.field(key.substringBefore('=')) ?: return emptyList()
        val wanted = keyValue(field, key.substringAfter('=')) ?: return emptyList()
        for (row in 0 until hinted.rowCount) {
            if (Values.fieldValue(rom, hinted.rowStart(row), field) == wanted) return palettesIn(hinted, row, own = false).take(1)
        }
        return emptyList()
    }

    /** The stored value a hint means: hexadecimal for hexadecimal fields, the position of a name, or a decimal number. */
    private fun keyValue(field: Field, text: String): Long? {
        if (text.isEmpty()) return null
        val enumName = field.enumName
        return when {
            field.kind == FieldKind.HEX -> text.toLongOrNull(16)
            enumName != null && enumName.toIntOrNull() == null -> {
                val position = catalog.options(enumName).indexOf(text)
                if (position < 0) null else position.toLong() + field.enumOffset
            }
            else -> text.toLongOrNull()
        }
    }

    /** The palettes that the pointers of row [row] of [table] lead to. */
    private fun palettesIn(table: TableLocation, row: Int, own: Boolean): List<PaletteRef> {
        val result = ArrayList<PaletteRef>()
        for (index in table.schema.fields.indices) {
            val field = catalog.concreteField(table, row, index)
            if (field.kind != FieldKind.POINTER) continue
            val pointer = field.pointer ?: continue
            if (pointer.kind != PointerKind.SPECIAL) continue
            val spec = GraphicSpec.parse(pointer.inner) as? GraphicSpec.Palette ?: continue
            val target = rom.pointerTarget(table.rowStart(row) + field.offset)
            if (target < 0) continue
            result.add(PaletteRef(if (own) field.name else shortName(table.name), spec, target))
        }
        return result
    }

    /** "normal" for "graphics.pokemon.palettes.normal". */
    private fun shortName(name: String): String = name.substringAfterLast('.')

    private companion object {
        const val TILES_PER_ROW = 16
        const val MAX_TILES = 1024
        const val SWATCHES_PER_ROW = 16
    }
}
