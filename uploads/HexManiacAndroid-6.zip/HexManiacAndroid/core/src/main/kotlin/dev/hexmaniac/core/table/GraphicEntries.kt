package dev.hexmaniac.core.table

import dev.hexmaniac.core.graphics.GraphicSpec

/** What a graphic of the reference data is. */
enum class GraphicKind { SPRITE, TILESET, TILEMAP, PALETTE }

/**
 * One picture, tileset, tile map or palette that the reference data names and that is not a field of a table (the
 * Pokemon sprites, for instance, are fields of tables and are not listed).
 */
class GraphicEntry(
    /** The full name from the reference data, such as "graphics.titlescreen.logo.tileset". */
    val name: String,
    /** The name without the heading it is listed under ("logo.tileset"). */
    val label: String,
    val kind: GraphicKind,
    /** File offset of the data. */
    val offset: Int,
    /** Bits per pixel (4 or 8 for palettes: how many colours a page has). */
    val bits: Int,
    /** Size in pixels of sprites and tile maps; 0 for tilesets and palettes, whose size is whatever the data holds. */
    val pixelWidth: Int,
    val pixelHeight: Int,
)

/** Graphics that are listed under one heading. */
class GraphicSection(val title: String, val entries: List<GraphicEntry>)

/** Sorts the single graphics of the reference data under headings. */
internal object GraphicEntries {
    private val TITLES = mapOf(
        "bag" to "Bag",
        "battle" to "Battle",
        "berrycheck" to "Berry check",
        "credits" to "Credits",
        "firstpersonview" to "First person view",
        "gamecorner" to "Game corner",
        "items" to "Items",
        "maps" to "Maps",
        "menu" to "Menus",
        "misc" to "Miscellaneous",
        "moves" to "Move animations",
        "newgame" to "New game",
        "overworld" to "Overworld",
        "pokedex" to "Pokedex",
        "pokemon" to "Pokemon",
        "text" to "Text",
        "titlescreen" to "Title screen",
        "townmap" to "Town map",
        "trainercard" to "Trainer card",
        "trainers" to "Trainers",
    )

    /** The entries of the graphics among [standalones] (other things, such as scripts, are left out), under headings. */
    fun sections(standalones: List<TableCatalog.Standalone>): List<GraphicSection> {
        val byHeading = HashMap<String, MutableList<GraphicEntry>>()
        for (standalone in standalones) {
            val entry = entryOf(standalone) ?: continue
            byHeading.getOrPut(headingOf(standalone.name)) { ArrayList() }.add(entry)
        }
        return byHeading.entries
            .map { (title, entries) -> GraphicSection(title, entries.sortedBy { it.name }) }
            .sortedWith(compareBy<GraphicSection> { it.title == OTHER }.thenBy { it.title.lowercase() })
    }

    /** The entry for [standalone], or null when it is not a graphic this app can draw. */
    fun entryOf(standalone: TableCatalog.Standalone): GraphicEntry? {
        val spec = GraphicSpec.parse(standalone.format) ?: return null
        val name = standalone.name
        val label = labelOf(name)
        return when (spec) {
            is GraphicSpec.Sprite ->
                GraphicEntry(name, label, GraphicKind.SPRITE, standalone.offset, spec.bits, spec.tilesWide * 8, spec.tilesHigh * 8)
            is GraphicSpec.Tileset ->
                GraphicEntry(name, label, GraphicKind.TILESET, standalone.offset, spec.bits, 0, 0)
            is GraphicSpec.Tilemap ->
                GraphicEntry(name, label, GraphicKind.TILEMAP, standalone.offset, spec.bits, spec.tilesWide * 8, spec.tilesHigh * 8)
            is GraphicSpec.Palette ->
                GraphicEntry(name, label, GraphicKind.PALETTE, standalone.offset, spec.bits, 0, 0)
        }
    }

    /** "titlescreen" for "graphics.titlescreen.logo.tileset", shown as "Title screen". */
    private fun headingOf(name: String): String {
        val parts = name.split('.')
        if (parts.size < 3) return OTHER
        val key = if (parts[0] == "graphics") parts[1] else parts[0]
        return TITLES[key] ?: key.replaceFirstChar { it.uppercase() }
    }

    /** The name without "graphics." and the group in front. */
    private fun labelOf(name: String): String {
        val parts = name.split('.')
        return if (parts.size >= 3 && parts[0] == "graphics") parts.drop(2).joinToString(".") else name
    }

    const val OTHER = "Other graphics"
}
