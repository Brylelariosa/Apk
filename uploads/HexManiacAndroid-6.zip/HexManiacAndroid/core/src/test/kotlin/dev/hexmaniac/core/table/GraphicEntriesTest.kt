package dev.hexmaniac.core.table

import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class GraphicEntriesTest {
    private fun standalone(name: String, format: String, offset: Int = 0x1000) = TableCatalog.Standalone(name, offset, -1, format)

    @Test
    fun graphicsAreSortedUnderTheirHeadings() {
        val sections = GraphicEntries.sections(
            listOf(
                standalone("graphics.titlescreen.logo.tileset", "`lzt4`"),
                standalone("graphics.bag.palette", "`lzp4`"),
                standalone("graphics.titlescreen.logo.palette", "`lzp4`"),
                standalone("graphics.townmap.map.tilemap", "`lzm4x30x20|graphics.townmap.map.tileset`"),
            ),
        )
        assertEquals(listOf("Bag", "Title screen", "Town map"), sections.map { it.title })
        assertEquals(listOf("logo.palette", "logo.tileset"), sections[1].entries.map { it.label })
    }

    @Test
    fun thingsThatAreNotGraphicsAreLeftOut() {
        val sections = GraphicEntries.sections(
            listOf(
                standalone("scripts.newgame.setflags", "`xse`"),
                standalone("data.pokemon.moves.egg", "`egg`"),
                standalone("graphics.bag.palette", "`lzp4`"),
            ),
        )
        assertEquals(1, sections.size)
        assertEquals(1, sections[0].entries.size)
    }

    @Test
    fun anUnknownHeadingIsTheNameOfTheGroupWithACapital() {
        val sections = GraphicEntries.sections(listOf(standalone("graphics.fancy.thing.sprite", "`lzs4x2x2`")))
        assertEquals("Fancy", sections[0].title)
        assertEquals("thing.sprite", sections[0].entries[0].label)
    }

    @Test
    fun aNameWithoutAGroupIsListedLastAsOther() {
        val sections = GraphicEntries.sections(
            listOf(
                standalone("graphics.lonely", "`lzp4`"),
                standalone("graphics.bag.palette", "`lzp4`"),
            ),
        )
        assertEquals(listOf("Bag", GraphicEntries.OTHER), sections.map { it.title })
        assertEquals("graphics.lonely", sections[1].entries[0].label)
    }

    @Test
    fun anEntryDescribesWhatItIs() {
        val sprite = GraphicEntries.entryOf(standalone("graphics.bag.male", "`lzs4x8x4|graphics.bag.palette`", 0x20))!!
        assertEquals(GraphicKind.SPRITE, sprite.kind)
        assertEquals(64, sprite.pixelWidth)
        assertEquals(32, sprite.pixelHeight)
        assertEquals(4, sprite.bits)
        assertEquals(0x20, sprite.offset)
        val map = GraphicEntries.entryOf(standalone("graphics.x.y.map", "`ucm8x64x64|graphics.x.y.tiles`"))!!
        assertEquals(GraphicKind.TILEMAP, map.kind)
        assertEquals(512, map.pixelWidth)
        assertEquals(8, map.bits)
        assertEquals(GraphicKind.TILESET, GraphicEntries.entryOf(standalone("graphics.x.y.tiles", "`lzt4`"))!!.kind)
        assertEquals(GraphicKind.PALETTE, GraphicEntries.entryOf(standalone("graphics.x.y.pal", "`ucp4:12`"))!!.kind)
        assertNull(GraphicEntries.entryOf(standalone("graphics.x.y.script", "`xse`")))
    }

    @Test
    fun graphicsThatTheMetadataPlacesAreListedToo() {
        // the Emerald metadata names two 2 bit fonts at fixed addresses
        val data = ReferenceLibrary(ClasspathResources()).load("BPEE0")
        val fake = FakeRom(data, 0x800000)
        val tables = TableSet(RomDocument("emerald.gba", fake.bytes).rom, PcsTable.DEFAULT, "BPEE0", data)
        val fonts = tables.graphics().flatMap { it.entries }.filter { it.name.startsWith("graphics.text.font.japan") }
        assertEquals(listOf("graphics.text.font.japan4.characters", "graphics.text.font.japan5.characters"), fonts.map { it.name })
        assertEquals(0x65C4E4, fonts[0].offset)
        assertEquals(2, fonts[0].bits)
        assertEquals(128, fonts[0].pixelWidth)
        assertEquals(1024, fonts[0].pixelHeight)
        assertNotNull(tables.graphic(fonts[0])) // grey: a 2 bit picture has no palette to name
    }
}
