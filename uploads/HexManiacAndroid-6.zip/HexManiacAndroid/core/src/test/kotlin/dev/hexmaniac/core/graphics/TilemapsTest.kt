package dev.hexmaniac.core.graphics

import org.junit.Assert.assertEquals
import org.junit.Test

class TilemapsTest {
    /** Tiles of 4 bits per pixel whose pixel (x, y) of tile n is [pixel]; every tile is 32 bytes. */
    private fun tiles(count: Int, pixel: (tile: Int, x: Int, y: Int) -> Int): ByteArray {
        val data = ByteArray(count * 32)
        for (tile in 0 until count) {
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val at = tile * 32 + y * 4 + x / 2
                    val value = pixel(tile, x, y) and 0xF
                    data[at] = (data[at].toInt() or (if (x % 2 == 0) value else value shl 4)).toByte()
                }
            }
        }
        return data
    }

    /** A map of two byte cells. */
    private fun cells(vararg values: Int): ByteArray {
        val out = ByteArray(values.size * 2)
        values.forEachIndexed { i, v ->
            out[i * 2] = v.toByte()
            out[i * 2 + 1] = (v shr 8).toByte()
        }
        return out
    }

    private fun IntArray.at(width: Int, x: Int, y: Int) = this[y * width + x]

    /** Tile 0 is empty, tile 1 is solid colour 1, tile 2 has a dot of colour 5 in its top left corner and 6 in its top right. */
    private val tileSet = tiles(3) { tile, x, y ->
        when {
            tile == 1 -> 1
            tile == 2 && x == 0 && y == 0 -> 5
            tile == 2 && x == 7 && y == 0 -> 6
            else -> 0
        }
    }

    @Test
    fun everyCellIsReplacedByItsTile() {
        val slots = Tilemaps.slots(cells(1, 0, 1, 2), 0, 2, 2, 2, tileSet, 0, 4)
        assertEquals(16 * 16, slots.size) // 16 columns by 16 rows
        assertEquals(1, slots.at(16, 0, 0)) // cell 0: tile 1
        assertEquals(0, slots.at(16, 8, 0)) // cell 1: tile 0
        assertEquals(1, slots.at(16, 7, 7))
        assertEquals(1, slots.at(16, 0, 8)) // cell 2: tile 1
        assertEquals(5, slots.at(16, 8, 8)) // cell 3: tile 2
        assertEquals(6, slots.at(16, 15, 8))
    }

    @Test
    fun theHighBitsOfACellPickThePaletteBank() {
        val slots = Tilemaps.slots(cells(1 or (3 shl 12), 2 or (15 shl 12)), 0, 2, 2, 1, tileSet, 0, 4)
        assertEquals(3 * 16 + 1, slots.at(16, 0, 0))
        assertEquals(15 * 16 + 0, slots.at(16, 9, 0))
        assertEquals(15 * 16 + 5, slots.at(16, 8, 0))
    }

    @Test
    fun cellsCanBeFlippedAcross() {
        val slots = Tilemaps.slots(cells(2 or (1 shl 10)), 0, 2, 1, 1, tileSet, 0, 4)
        assertEquals(6, slots.at(8, 0, 0))
        assertEquals(5, slots.at(8, 7, 0))
    }

    @Test
    fun cellsCanBeFlippedUpsideDown() {
        val slots = Tilemaps.slots(cells(2 or (1 shl 11)), 0, 2, 1, 1, tileSet, 0, 4)
        assertEquals(5, slots.at(8, 0, 7))
        assertEquals(6, slots.at(8, 7, 7))
        assertEquals(0, slots.at(8, 0, 0))
    }

    @Test
    fun bothFlipsTurnTheTileHalfAround() {
        val slots = Tilemaps.slots(cells(2 or (3 shl 10)), 0, 2, 1, 1, tileSet, 0, 4)
        assertEquals(6, slots.at(8, 0, 7))
        assertEquals(5, slots.at(8, 7, 7))
    }

    @Test
    fun theTileNumberUsesTenBits() {
        val big = ByteArray(1025 * 32)
        big[1023 * 32] = 7 // the left pixel of the first row of tile 1023
        val slots = Tilemaps.slots(cells(0x3FF or (1 shl 10)), 0, 2, 1, 1, big, 0, 4)
        assertEquals(7, slots.at(8, 7, 0)) // flipped across
    }

    @Test
    fun aMapWithOneByteCellsHasTileNumbersOnly() {
        val map = byteArrayOf(1, 2, 0, 2)
        val slots = Tilemaps.slots(map, 0, 1, 2, 2, tileSet, 0, 4)
        assertEquals(1, slots.at(16, 0, 0))
        assertEquals(5, slots.at(16, 8, 0))
        assertEquals(0, slots.at(16, 0, 8))
        assertEquals(5, slots.at(16, 8, 8)) // no flips and no banks in one byte cells
    }

    @Test
    fun eightBitTilesAreMapped() {
        val tiles8 = ByteArray(2 * 64)
        tiles8[64 + 9] = 200.toByte() // tile 1, pixel (1, 1)
        val slots = Tilemaps.slots(cells(1), 0, 2, 1, 1, tiles8, 0, 8)
        assertEquals(200, slots.at(8, 1, 1))
    }

    @Test
    fun theMapAndTheTilesCanStartAnywhere() {
        val map = ByteArray(10) + cells(2)
        val tileBytes = ByteArray(5) + tileSet
        val slots = Tilemaps.slots(map, 10, 2, 1, 1, tileBytes, 5, 4)
        assertEquals(5, slots.at(8, 0, 0))
    }

    @Test
    fun cellsAndTilesBeyondTheDataAreEmpty() {
        val slots = Tilemaps.slots(cells(1), 0, 2, 2, 1, tileSet, 0, 4) // the second cell is not in the map
        assertEquals(1, slots.at(16, 0, 0))
        assertEquals(0, slots.at(16, 8, 0))
        val missingTile = Tilemaps.slots(cells(9), 0, 2, 1, 1, tileSet, 0, 4)
        assertEquals(0, missingTile.at(8, 3, 3))
    }

    @Test
    fun aCompressedMapHasOneByteCellsWhenItIsTooSmallForTwo() {
        assertEquals(1, Tilemaps.cellBytes(true, 4, 7))
        assertEquals(2, Tilemaps.cellBytes(true, 4, 8))
        assertEquals(2, Tilemaps.cellBytes(true, 4, 100))
        assertEquals(2, Tilemaps.cellBytes(false, 4, 3)) // uncompressed maps always have two bytes
    }

    @Test(expected = IllegalArgumentException::class)
    fun aCellTakesOneOrTwoBytes() {
        Tilemaps.slots(ByteArray(8), 0, 3, 1, 1, tileSet, 0, 4)
    }
}
