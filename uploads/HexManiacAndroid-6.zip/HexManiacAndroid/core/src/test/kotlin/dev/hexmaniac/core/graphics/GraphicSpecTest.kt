package dev.hexmaniac.core.graphics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GraphicSpecTest {
    private fun sprite(text: String) = GraphicSpec.parse(text) as GraphicSpec.Sprite

    private fun palette(text: String) = GraphicSpec.parse(text) as GraphicSpec.Palette

    private fun tileset(text: String) = GraphicSpec.parse(text) as GraphicSpec.Tileset

    @Test
    fun aCompressedSprite() {
        val spec = sprite("`lzs4x8x8`")
        assertTrue(spec.compressed)
        assertEquals(4, spec.bits)
        assertEquals(8, spec.tilesWide)
        assertEquals(8, spec.tilesHigh)
        assertNull(spec.paletteHint)
    }

    @Test
    fun anUncompressedSpriteWithAPaletteHint() {
        val spec = sprite("`ucs4x4x8|graphics.pokemon.icons.index`")
        assertFalse(spec.compressed)
        assertEquals(4, spec.tilesWide)
        assertEquals(8, spec.tilesHigh)
        assertEquals("graphics.pokemon.icons.index", spec.paletteHint)
    }

    @Test
    fun aHintWithAKeyKeepsTheKey() {
        assertEquals("graphics.overworld.palettes:id=1100", sprite("`ucs4x2x2|graphics.overworld.palettes:id=1100`").paletteHint)
    }

    @Test
    fun aSpriteMayAllowLengthErrors() {
        val spec = sprite("`lzs4x2x3!`")
        assertEquals(2, spec.tilesWide)
        assertEquals(3, spec.tilesHigh)
    }

    @Test
    fun oneBitSpritesWork() {
        val spec = sprite("`ucs1x2x2`")
        assertEquals(1, spec.bits)
    }

    @Test
    fun theBackticksAreOptional() {
        assertEquals(3, sprite("lzs4x3x3").tilesWide)
        assertEquals(4, palette("ucp4").bits)
    }

    @Test
    fun badSpriteSizesAreNotUnderstood() {
        assertNull(GraphicSpec.parse("`lzs3x8x8`"))
        assertNull(GraphicSpec.parse("`lzs4x0x8`"))
        assertNull(GraphicSpec.parse("`lzs4x8`"))
        assertNull(GraphicSpec.parse("`lzs4x8x8x8`"))
        assertNull(GraphicSpec.parse("`lzs4xax8`"))
        assertNull(GraphicSpec.parse("`lzs4x101x1`"))
        assertNull(GraphicSpec.parse("`lzs4x64x65`")) // more than 4096 tiles
    }

    @Test
    fun palettesWithOnePage() {
        val compressed = palette("`lzp4`")
        assertTrue(compressed.compressed)
        assertEquals(4, compressed.bits)
        assertEquals(0, compressed.pages)

        val plain = palette("`ucp4`")
        assertFalse(plain.compressed)
        assertEquals(1, plain.pages)
        assertEquals(0, plain.firstPage)
    }

    @Test
    fun palettesWithSeveralPagesNameTheirSlots() {
        val all = palette("`ucp4:0123456789ABCDEF`")
        assertEquals(16, all.pages)
        assertEquals(0, all.firstPage)

        val inner = palette("`ucp4:DE`")
        assertEquals(2, inner.pages)
        assertEquals(13, inner.firstPage)

        val three = palette("`ucp4:234`")
        assertEquals(3, three.pages)
        assertEquals(2, three.firstPage)

        assertEquals(1, palette("`ucp4:12`").firstPage)
        assertEquals(1, palette("`ucp4:8`").pages)
    }

    @Test
    fun aCompressedPaletteTakesItsPagesFromItsSize() {
        val spec = palette("`lzp4:234`")
        assertTrue(spec.compressed)
        assertEquals(2, spec.firstPage)
        assertEquals(0, spec.pages)
    }

    @Test
    fun aPaletteOfEightBitsHasOnePageOf256Colours() {
        assertEquals(8, palette("`ucp8`").bits)
        assertEquals(8, palette("`lzp8`").bits)
    }

    @Test
    fun otherPaletteDepthsAreNotUnderstood() {
        assertNull(GraphicSpec.parse("`lzp2`"))
        assertNull(GraphicSpec.parse("`ucp`"))
        assertNull(GraphicSpec.parse("`ucpx`"))
    }

    @Test
    fun anUnreadablePageListMeansOnePage() {
        val spec = palette("`ucp4:`")
        assertEquals(1, spec.pages)
        assertEquals(0, spec.firstPage)
        assertEquals(1, palette("`ucp4:ZZ`").pages)
        assertEquals(1, palette("`ucp4:BA`").pages)
    }

    @Test
    fun tilesets() {
        val compressed = tileset("`lzt4`")
        assertTrue(compressed.compressed)
        assertEquals(0, compressed.tiles)
        assertNull(compressed.paletteHint)

        val hinted = tileset("`lzt4|graphics.townmap.catchmap.palette`")
        assertEquals("graphics.townmap.catchmap.palette", hinted.paletteHint)

        val plain = tileset("`uct4x18|graphics.text.box.palette`")
        assertFalse(plain.compressed)
        assertEquals(18, plain.tiles)
        assertEquals("graphics.text.box.palette", plain.paletteHint)
    }

    @Test
    fun uncompressedTilesNeedTheirCount() {
        assertNull(GraphicSpec.parse("`uct4`"))
        assertNull(GraphicSpec.parse("`uct4x0`"))
        assertNull(GraphicSpec.parse("`uct4x99999`"))
        assertNull(GraphicSpec.parse("`uct4x1x2`"))
    }

    private fun tilemap(text: String) = GraphicSpec.parse(text) as GraphicSpec.Tilemap

    @Test
    fun tileMaps() {
        val packed = tilemap("`lzm4x32x20|graphics.menu.statusscreen.tileset`")
        assertTrue(packed.compressed)
        assertEquals(4, packed.bits)
        assertEquals(32, packed.tilesWide)
        assertEquals(20, packed.tilesHigh)
        assertEquals("graphics.menu.statusscreen.tileset", packed.tilesetHint)
        assertNull(packed.member)

        val plain = tilemap("`ucm4x32x32|graphics.menu.summaryscreen.tileset`")
        assertFalse(plain.compressed)
        assertEquals(32, plain.tilesHigh)
    }

    @Test
    fun aTileMapCanNameATableAndTheFieldWithItsTiles() {
        val spec = tilemap("`lzm4x32x64|graphics.battle.background.sprites|battletiles`")
        assertEquals("graphics.battle.background.sprites", spec.tilesetHint)
        assertEquals("battletiles", spec.member)
    }

    @Test
    fun aTileMapWithoutAHintHasNoTilesetName() {
        val spec = tilemap("`lzm8x64x64`")
        assertEquals(8, spec.bits)
        assertNull(spec.tilesetHint)
        assertNull(spec.member)
    }

    @Test
    fun aTileMapMayMarkItsLengthAsUncertain() {
        assertEquals("a", tilemap("`lzm4x2x3!|a`").tilesetHint)
        assertEquals("a", tilemap("`lzm4x2x3|a!`").tilesetHint)
    }

    @Test
    fun badTileMapsAreNotUnderstood() {
        for (text in listOf("`lzm4x32`", "`lzm3x2x2`", "`lzm4x0x2`", "`lzm4x2x0`", "`lzm4x101x2`", "`lzm4x2x101`", "`lzm4xax2`", "`lzm`", "`ucm4x-1x2`")) {
            assertNull(text, GraphicSpec.parse(text))
        }
    }

    @Test
    fun otherSpecialDataIsNotAPicture() {
        for (text in listOf("`xse`", "`blm`", "`osl|x`", "`tpt`", "`ase`", "`lz`", "``", "", "x", "`lzq4x1x1`")) {
            assertNull(text, GraphicSpec.parse(text))
        }
    }
}
