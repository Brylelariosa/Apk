package dev.hexmaniac.core.table

import dev.hexmaniac.core.graphics.TestLz77
import dev.hexmaniac.core.io.ClasspathResources
import dev.hexmaniac.core.rom.RomDocument
import dev.hexmaniac.core.table.data.GameData
import dev.hexmaniac.core.table.data.ReferenceLibrary
import dev.hexmaniac.core.text.PcsTable
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** Pictures behind pointers, on a small ROM that is laid out like FireRed 1.0 where the tests need it to be. */
class GraphicsTest {
    private lateinit var data: GameData
    private lateinit var fake: FakeRom
    private lateinit var tables: TableSet

    private val red = 0xFFFF0000.toInt()
    private val green = 0xFF00FF00.toInt()
    private val blue = 0xFF0000FF.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val black = 0xFF000000.toInt()

    // GBA colours
    private val gbaWhite = 0x7FFF
    private val gbaRed = 0x001F
    private val gbaGreen = 0x03E0
    private val gbaBlue = 0x7C00

    @Before
    fun setUp() {
        data = ReferenceLibrary(ClasspathResources()).load("BPRE0")
        fake = FakeRom(data)
        fake.place("data.pokemon.names", NAMES)
        listOf("?", "BULBASAUR", "IVYSAUR", "VENUSAUR").forEachIndexed { i, n -> fake.fixedText(NAMES + i * 11, n, 11) }
    }

    private fun open() {
        tables = TableSet(RomDocument("test.gba", fake.bytes).rom, PcsTable.DEFAULT, "BPRE0", data)
    }

    private fun table(name: String): TableLocation = tables.locate(TablePath(name)) ?: error("no table $name")

    // ---- building data ----

    /** Picture data of 4 bit pixels, [width] by [height] pixels, with the tiles in the order the GBA stores them. */
    private fun tiles4(width: Int, height: Int, pixel: (Int, Int) -> Int): ByteArray {
        val tilesWide = width / 8
        val out = ByteArray(width * height / 2)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val at = ((y / 8) * tilesWide + x / 8) * 32 + (y % 8) * 4 + (x % 8) / 2
                val value = pixel(x, y) and 0xF
                out[at] = (out[at].toInt() or (if (x % 2 == 0) value else value shl 4)).toByte()
            }
        }
        return out
    }

    private fun colors(vararg values: Int): ByteArray {
        val out = ByteArray(32)
        values.forEachIndexed { i, v ->
            out[i * 2] = v.toByte()
            out[i * 2 + 1] = (v shr 8).toByte()
        }
        return out
    }

    private fun put(at: Int, bytes: ByteArray) = System.arraycopy(bytes, 0, fake.bytes, at, bytes.size)

    private fun putPacked(at: Int, bytes: ByteArray) = put(at, TestLz77.compress(bytes))

    /** A 64 by 64 sprite with a dot of colour 1 in the top left corner and a dot of colour 2 in the bottom right one. */
    private fun dots(width: Int = 64, height: Int = 64) = tiles4(width, height) { x, y ->
        when {
            x == 0 && y == 0 -> 1
            x == width - 1 && y == height - 1 -> 2
            else -> 0
        }
    }

    // ---- sprites of the Pokemon: the palettes sit in tables of the same length ----

    private fun pokemonSprites() {
        fake.place("graphics.pokemon.sprites.front", FRONT)
        fake.place("graphics.pokemon.palettes.normal", NORMAL)
        fake.place("graphics.pokemon.palettes.shiny", SHINY)
        // row 1: the sprite and both palettes
        putPacked(BLOBS, dots())
        fake.pointer(FRONT + 8, BLOBS)
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaRed, gbaGreen))
        fake.pointer(NORMAL + 8, BLOBS + 0x1000)
        putPacked(BLOBS + 0x2000, colors(gbaWhite, gbaBlue, gbaGreen))
        fake.pointer(SHINY + 8, BLOBS + 0x2000)
    }

    @Test
    fun aSpriteIsPaintedWithThePaletteOfTheSameRowOfARelatedTable() {
        pokemonSprites()
        open()
        val graphic = tables.graphic(table("graphics.pokemon.sprites.front"), 1, 0)!!
        assertEquals(64, graphic.picture.width)
        assertEquals(64, graphic.picture.height)
        assertEquals(red, graphic.picture.pixels[0])
        assertEquals(white, graphic.picture.pixels[1])
        assertEquals(white, graphic.picture.pixels[64])
        assertEquals(green, graphic.picture.pixels[64 * 64 - 1])
        assertEquals("normal", graphic.palette)
        assertEquals(2, graphic.choices)
        assertEquals(0, graphic.choice)
    }

    @Test
    fun theOtherPaletteCanBeChosen() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        val shiny = tables.graphic(front, 1, 0, 1)!!
        assertEquals(blue, shiny.picture.pixels[0])
        assertEquals(green, shiny.picture.pixels[64 * 64 - 1])
        assertEquals("shiny", shiny.palette)
        assertEquals(1, shiny.choice)
    }

    @Test
    fun theChoiceWrapsAround() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertEquals(0, tables.graphic(front, 1, 0, 2)!!.choice)
        assertEquals(1, tables.graphic(front, 1, 0, 3)!!.choice)
        assertEquals(1, tables.graphic(front, 1, 0, -1)!!.choice)
        assertEquals(0, tables.graphic(front, 1, 0, -2)!!.choice)
    }

    @Test
    fun aPaletteShowsItsColours() {
        pokemonSprites()
        open()
        val graphic = tables.graphic(table("graphics.pokemon.palettes.normal"), 1, 0)!!
        assertEquals(16, graphic.picture.width)
        assertEquals(1, graphic.picture.height)
        assertEquals(white, graphic.picture.pixels[0])
        assertEquals(red, graphic.picture.pixels[1])
        assertEquals(green, graphic.picture.pixels[2])
        assertEquals(black, graphic.picture.pixels[3])
        assertNull(graphic.palette)
        assertEquals(0, graphic.choices)
    }

    @Test
    fun aSpriteWithoutAPaletteIsDrawnInGrey() {
        pokemonSprites()
        putPacked(BLOBS + 0x3000, dots())
        fake.pointer(FRONT + 16, BLOBS + 0x3000)
        open()
        val graphic = tables.graphic(table("graphics.pokemon.sprites.front"), 2, 0)!!
        assertEquals(0, graphic.choices)
        assertNull(graphic.palette)
        assertEquals(0xFF111111.toInt(), graphic.picture.pixels[0])
        assertEquals(0xFF222222.toInt(), graphic.picture.pixels[64 * 64 - 1])
        assertEquals(black, graphic.picture.pixels[1])
    }

    @Test
    fun aPointerThatDoesNotLeadToPictureDataHasNoPicture() {
        pokemonSprites()
        fake.pointer(FRONT + 24, BLOBS + 0x4000) // only unused bytes there
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertNull(tables.graphic(front, 3, 0))
        assertNull(tables.graphic(front, 0, 0)) // no pointer at all
    }

    @Test
    fun onlyPicturePointersHavePictures() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        val fields = tables.fields(front, 1)
        assertTrue(fields[0].picture)
        assertFalse(fields[1].picture)
        assertFalse(fields[2].picture)
        assertNull(tables.graphic(front, 1, 1))
        assertFalse(tables.fields(front, 0)[0].picture) // a pointer that leads nowhere
        assertTrue(tables.fields(table("graphics.pokemon.palettes.normal"), 1)[0].picture)
    }

    @Test
    fun rowsAndFieldsThatDoNotExistHaveNoPicture() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertNull(tables.graphic(front, -1, 0))
        assertNull(tables.graphic(front, 999, 0))
        assertNull(tables.graphic(front, 1, 99))
        assertNull(tables.graphic(front, 1, -1))
    }

    @Test
    fun picturesFollowTheRomAfterItChanges() {
        pokemonSprites()
        open()
        val front = table("graphics.pokemon.sprites.front")
        assertEquals(red, tables.graphic(front, 1, 0)!!.picture.pixels[0])
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaBlue, gbaGreen))
        open()
        assertEquals(blue, tables.graphic(table("graphics.pokemon.sprites.front"), 1, 0)!!.picture.pixels[0])
    }

    // ---- sprites that name their palette table ----

    @Test
    fun aHintToATablePicksThePaletteOfTheSameRow() {
        fake.place("graphics.trainers.sprites.front", TRAINERS)
        fake.place("graphics.trainers.palettes.front", TRAINER_PALETTES)
        for (row in 4..6) {
            putPacked(BLOBS + row * 0x400, dots())
            fake.pointer(TRAINERS + row * 8, BLOBS + row * 0x400)
            putPacked(BLOBS + 0x4000 + row * 0x40, colors(gbaWhite, intArrayOf(gbaRed, gbaGreen, gbaBlue)[row - 4], gbaWhite))
            fake.pointer(TRAINER_PALETTES + row * 8, BLOBS + 0x4000 + row * 0x40)
        }
        open()
        val sprites = table("graphics.trainers.sprites.front")
        assertEquals(148, sprites.rowCount)
        assertEquals(red, tables.graphic(sprites, 4, 0)!!.picture.pixels[0])
        assertEquals(green, tables.graphic(sprites, 5, 0)!!.picture.pixels[0])
        val last = tables.graphic(sprites, 6, 0)!!
        assertEquals(blue, last.picture.pixels[0])
        assertEquals("front", last.palette)
        assertEquals(1, last.choices)
    }

    // ---- icons: a table of numbers picks a row of a table of palettes ----

    @Test
    fun aHintToATableOfNumbersPicksTheNumberedPalette() {
        fake.place("graphics.pokemon.icons.sprites", ICONS)
        fake.place("graphics.pokemon.icons.index", ICON_INDEX)
        fake.place("graphics.pokemon.icons.palettes", ICON_PALETTES)
        put(BLOBS, dots(32, 64))
        fake.pointer(ICONS + 4 * 2, BLOBS)
        fake.u8(ICON_INDEX + 2, 1)
        for (row in 0 until 3) {
            put(BLOBS + 0x1000 + row * 0x40, colors(gbaWhite, intArrayOf(gbaRed, gbaGreen, gbaBlue)[row], gbaWhite))
            fake.pointer(ICON_PALETTES + row * 8, BLOBS + 0x1000 + row * 0x40)
            fake.u32(ICON_PALETTES + row * 8 + 4, row.toLong())
        }
        open()
        val icons = table("graphics.pokemon.icons.sprites")
        val graphic = tables.graphic(icons, 2, 0)!!
        assertEquals(32, graphic.picture.width)
        assertEquals(64, graphic.picture.height)
        assertEquals(green, graphic.picture.pixels[0])
        assertEquals("palettes", graphic.palette)
        assertEquals(1, graphic.choices)

        fake.u8(ICON_INDEX + 2, 2)
        open()
        assertEquals(blue, tables.graphic(table("graphics.pokemon.icons.sprites"), 2, 0)!!.picture.pixels[0])
    }

    // ---- sprites with their palette in their own row ----

    @Test
    fun aSpriteTakesThePaletteOfItsOwnRow() {
        fake.place("data.items.stats", ITEMS)
        fake.constant("data.items.count", 3)
        fake.place("graphics.items.sprites", ITEM_SPRITES)
        putPacked(BLOBS, dots(24, 24))
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaGreen, gbaBlue))
        fake.pointer(ITEM_SPRITES + 8, BLOBS)
        fake.pointer(ITEM_SPRITES + 12, BLOBS + 0x1000)
        open()
        val sprites = table("graphics.items.sprites")
        assertEquals(4, sprites.rowCount)
        val graphic = tables.graphic(sprites, 1, 0)!!
        assertEquals(24, graphic.picture.width)
        assertEquals(green, graphic.picture.pixels[0])
        assertEquals(blue, graphic.picture.pixels[24 * 24 - 1])
        assertEquals("palette", graphic.palette)
        // the palette field of the same row is a picture too
        assertTrue(tables.fields(sprites, 1)[1].picture)
        assertEquals(green, tables.graphic(sprites, 1, 1)!!.picture.pixels[1])
    }

    // ---- sprites that name a key of a palette table ----

    @Test
    fun aHintWithAKeyPicksThePaletteOfTheRowWithThatKey() {
        fake.place("graphics.trainers.emotes.sprites", EMOTES)
        fake.place("graphics.overworld.palettes", OVERWORLD_PALETTES)
        val ids = intArrayOf(0x1000, 0x1100, 0x1200)
        val shades = intArrayOf(gbaRed, gbaGreen, gbaBlue)
        for (row in 0 until 3) {
            put(BLOBS + 0x1000 + row * 0x40, colors(gbaWhite, shades[row], gbaWhite))
            fake.pointer(OVERWORLD_PALETTES + row * 8, BLOBS + 0x1000 + row * 0x40)
            fake.u16(OVERWORLD_PALETTES + row * 8 + 4, ids[row])
            fake.u16(OVERWORLD_PALETTES + row * 8 + 6, 0)
        }
        for (i in 0 until 8) fake.u8(OVERWORLD_PALETTES + 3 * 8 + i, 0) // the end of the table
        put(BLOBS, dots(16, 16))
        fake.pointer(EMOTES, BLOBS)
        fake.u32(EMOTES + 4, 4)
        open()
        val graphic = tables.graphic(table("graphics.trainers.emotes.sprites"), 0, 0)!!
        assertEquals(16, graphic.picture.width)
        assertEquals(green, graphic.picture.pixels[0]) // id 1100 is the second palette
        assertEquals("palettes", graphic.palette)
    }

    // ---- tilesets ----

    @Test
    fun aTilesetIsLaidOutSixteenTilesToARow() {
        fake.place("graphics.items.mail", MAIL)
        val tileData = ByteArray(20 * 32)
        for (tile in 0 until 20) tileData[tile * 32] = (tile % 3 + 1).toByte() // the left pixel of each tile
        putPacked(BLOBS, tileData)
        put(BLOBS + 0x1000, colors(gbaWhite, gbaRed, gbaGreen, gbaBlue))
        fake.pointer(MAIL, BLOBS + 0x1000) // pal
        fake.pointer(MAIL + 4, BLOBS) // tileset
        open()
        val mail = table("graphics.items.mail")
        val graphic = tables.graphic(mail, 0, 1)!!
        assertEquals(128, graphic.picture.width)
        assertEquals(16, graphic.picture.height) // 20 tiles are two rows of tiles
        assertEquals(red, graphic.picture.pixels[0]) // tile 0
        assertEquals(green, graphic.picture.pixels[8]) // tile 1
        assertEquals(blue, graphic.picture.pixels[16]) // tile 2
        assertEquals(green, graphic.picture.pixels[8 * 128]) // tile 16 starts the second row of tiles
        assertEquals(blue, graphic.picture.pixels[8 * 128 + 8]) // tile 17
        assertEquals(white, graphic.picture.pixels[8 * 128 + 4 * 8]) // there is no tile 20: its pixels have the first colour
        assertNotNull(graphic.palette)
    }


    // ---- tile maps ----

    /** Four tiles of 4 bits: the empty tile, then tiles that are solid colour 1, 2 and 3. */
    private fun solidTiles(colorOfTile: (Int) -> Int = { it }) = tiles4(32, 8) { x, _ -> colorOfTile(x / 8) }

    /** A tile map of [count] cells (two bytes each) that starts with the cells [first]. */
    private fun cells(count: Int, vararg first: Int): ByteArray {
        val out = ByteArray(count * 2)
        first.forEachIndexed { i, v ->
            out[i * 2] = v.toByte()
            out[i * 2 + 1] = (v shr 8).toByte()
        }
        return out
    }

    private fun cell(tile: Int, bank: Int = 0, flipX: Boolean = false, flipY: Boolean = false) =
        tile or (if (flipX) 1 shl 10 else 0) or (if (flipY) 1 shl 11 else 0) or (bank shl 12)

    private fun evolutionScene() {
        fake.place("graphics.pokemon.evolution.scene.palette", SCENE_PALETTE) // `ucp4:AB`: two pages, from page 10 on
        fake.place("graphics.pokemon.evolution.scene.tileset", SCENE_TILESET) // `lzt4|...palette`
        fake.place("graphics.pokemon.evolution.scene.tilemap1", SCENE_MAP) // `lzm4x32x32|...tileset`
        put(SCENE_PALETTE, colors(gbaWhite, gbaRed, gbaGreen) + colors(gbaWhite, gbaBlue, gbaRed))
        putPacked(SCENE_TILESET, solidTiles())
        putPacked(SCENE_MAP, cells(32 * 32, cell(1, bank = 10), cell(1, bank = 11), cell(2, bank = 10), cell(2, bank = 11), cell(1, bank = 0)))
    }

    private fun entry(name: String): GraphicEntry =
        tables.graphics().flatMap { it.entries }.firstOrNull { it.name == name } ?: error("no graphic $name")

    @Test
    fun aTileMapIsDrawnFromItsTilesetWithThePagesOfItsPalette() {
        evolutionScene()
        open()
        val graphic = tables.graphic(entry("graphics.pokemon.evolution.scene.tilemap1"))!!
        assertEquals(256, graphic.picture.width)
        assertEquals(256, graphic.picture.height)
        assertEquals(red, graphic.picture.pixels[0]) // tile 1 of bank 10: colour 1 of the first page
        assertEquals(blue, graphic.picture.pixels[8]) // tile 1 of bank 11: colour 1 of the second page
        assertEquals(green, graphic.picture.pixels[16]) // tile 2 of bank 10
        assertEquals(red, graphic.picture.pixels[24]) // tile 2 of bank 11: colour 2 of the second page
        assertEquals(red, graphic.picture.pixels[32]) // bank 0 is before the palette: it wraps onto the first page
        assertEquals(white, graphic.picture.pixels[40]) // the other cells are tile 0 of bank 0: colour 0
        assertEquals("palette", graphic.palette)
        assertEquals(1, graphic.choices)
    }

    @Test
    fun aTileMapFlipsItsTiles() {
        fake.place("graphics.pokemon.evolution.scene.palette", SCENE_PALETTE)
        fake.place("graphics.pokemon.evolution.scene.tileset", SCENE_TILESET)
        fake.place("graphics.pokemon.evolution.scene.tilemap1", SCENE_MAP)
        put(SCENE_PALETTE, colors(gbaWhite, gbaRed, gbaGreen))
        // tile 1 has a red dot (colour 1) in the top left corner only
        putPacked(SCENE_TILESET, tiles4(16, 8) { x, y -> if (x == 8 && y == 0) 1 else 0 })
        putPacked(SCENE_MAP, cells(32 * 32, cell(1, bank = 10), cell(1, bank = 10, flipX = true), cell(1, bank = 10, flipY = true)))
        open()
        val picture = tables.graphic(entry("graphics.pokemon.evolution.scene.tilemap1"))!!.picture
        assertEquals(red, picture.pixels[0])
        assertEquals(white, picture.pixels[7])
        assertEquals(red, picture.pixels[8 + 7]) // flipped across: the dot is in the top right corner
        assertEquals(red, picture.pixels[16 + 7 * 256]) // flipped upside down: the dot is in the bottom left corner
        assertEquals(white, picture.pixels[16])
    }

    @Test
    fun aTileMapWithoutATilesetCannotBeDrawn() {
        fake.place("graphics.pokemon.evolution.scene.tilemap1", SCENE_MAP)
        putPacked(SCENE_MAP, cells(32 * 32, cell(1)))
        open()
        assertNull(tables.graphic(entry("graphics.pokemon.evolution.scene.tilemap1")))
    }

    @Test
    fun aTileMapWithoutAPaletteIsDrawnInGrey() {
        fake.place("graphics.pokemon.evolution.scene.tileset", SCENE_TILESET)
        fake.place("graphics.pokemon.evolution.scene.tilemap1", SCENE_MAP)
        putPacked(SCENE_TILESET, solidTiles())
        putPacked(SCENE_MAP, cells(32 * 32, cell(1, bank = 3), cell(2, bank = 3)))
        open()
        val graphic = tables.graphic(entry("graphics.pokemon.evolution.scene.tilemap1"))!!
        assertEquals(0, graphic.choices)
        assertNull(graphic.palette)
        assertEquals(0xFF111111.toInt(), graphic.picture.pixels[0])
        assertEquals(0xFF222222.toInt(), graphic.picture.pixels[8])
    }

    @Test
    fun aTileMapInATableUsesTheTilesetAndPaletteOfItsRow() {
        fake.place("graphics.menu.boxes.background", MENU_BOXES) // [tileset<`lzt4`> tilemap<`lzm4x20x18|...`> palette<`ucp4:12`>]16
        val row = MENU_BOXES + 3 * 12
        putPacked(BLOBS, solidTiles())
        putPacked(BLOBS + 0x1000, cells(20 * 18, cell(1, bank = 1), cell(1, bank = 2), cell(2, bank = 2)))
        put(BLOBS + 0x2000, colors(gbaWhite, gbaRed, gbaGreen) + colors(gbaWhite, gbaBlue, gbaRed))
        fake.pointer(row, BLOBS)
        fake.pointer(row + 4, BLOBS + 0x1000)
        fake.pointer(row + 8, BLOBS + 0x2000)
        open()
        val boxes = table("graphics.menu.boxes.background")
        assertTrue(tables.fields(boxes, 3)[1].picture)
        val graphic = tables.graphic(boxes, 3, 1)!!
        assertEquals(160, graphic.picture.width)
        assertEquals(144, graphic.picture.height)
        assertEquals(red, graphic.picture.pixels[0]) // bank 1 is the first page of `ucp4:12`
        assertEquals(blue, graphic.picture.pixels[8]) // bank 2 is the second
        assertEquals(red, graphic.picture.pixels[16])
        assertEquals("palette", graphic.palette)
    }

    @Test
    fun aTileMapNamesTheFieldOfItsRowThatHoldsTheTiles() {
        // two tilesets in a row: the battle one is all colour 1, the intro one all colour 2
        fake.place("graphics.battle.background.sprites", BACKGROUNDS) // [battletiles battlemap | introtiles intromap pal]
        putPacked(BLOBS, solidTiles { 1 })
        putPacked(BLOBS + 0x1000, cells(32 * 64, cell(1, bank = 2)))
        putPacked(BLOBS + 0x2000, solidTiles { 2 })
        putPacked(BLOBS + 0x3000, cells(32 * 14, cell(1, bank = 2)))
        putPacked(BLOBS + 0x4000, colors(gbaWhite, gbaRed, gbaGreen) + colors(gbaWhite, gbaBlue, gbaBlue) + colors(gbaWhite, gbaWhite, gbaWhite))
        for ((i, at) in listOf(BLOBS, BLOBS + 0x1000, BLOBS + 0x2000, BLOBS + 0x3000, BLOBS + 0x4000).withIndex()) {
            fake.pointer(BACKGROUNDS + i * 4, at)
        }
        open()
        val backgrounds = table("graphics.battle.background.sprites")
        val battle = tables.graphic(backgrounds, 0, 1)!!
        assertEquals(256, battle.picture.width)
        assertEquals(512, battle.picture.height)
        assertEquals(red, battle.picture.pixels[0])
        val intro = tables.graphic(backgrounds, 0, 3)!!
        assertEquals(256, intro.picture.width)
        assertEquals(112, intro.picture.height)
        assertEquals(green, intro.picture.pixels[0])
    }

    // ---- the list of single graphics ----

    @Test
    fun theSingleGraphicsAreListedUnderHeadings() {
        evolutionScene()
        fake.place("graphics.bag.male", BLOBS + 0x5000)
        fake.place("graphics.bag.palette", BLOBS + 0x6000)
        fake.place("scripts.newgame.setflags", BLOBS + 0x7000) // not a graphic
        open()
        val sections = tables.graphics()
        assertEquals(listOf("Bag", "Pokemon"), sections.map { it.title })
        val bag = sections[0].entries
        assertEquals(listOf("graphics.bag.male", "graphics.bag.palette"), bag.map { it.name })
        assertEquals(listOf("male", "palette"), bag.map { it.label })
        assertEquals(listOf("evolution.scene.palette", "evolution.scene.tilemap1", "evolution.scene.tileset"), sections[1].entries.map { it.label })
    }

    @Test
    fun anEntryKnowsWhatItIsAndWhereItsDataIs() {
        evolutionScene()
        fake.place("graphics.bag.male", BLOBS + 0x5000)
        open()
        val map = entry("graphics.pokemon.evolution.scene.tilemap1")
        assertEquals(GraphicKind.TILEMAP, map.kind)
        assertEquals(SCENE_MAP, map.offset)
        assertEquals(4, map.bits)
        assertEquals(256, map.pixelWidth)
        assertEquals(256, map.pixelHeight)
        val tileset = entry("graphics.pokemon.evolution.scene.tileset")
        assertEquals(GraphicKind.TILESET, tileset.kind)
        assertEquals(0, tileset.pixelWidth)
        assertEquals(GraphicKind.PALETTE, entry("graphics.pokemon.evolution.scene.palette").kind)
        val sprite = entry("graphics.bag.male")
        assertEquals(GraphicKind.SPRITE, sprite.kind)
        assertEquals(64, sprite.pixelWidth)
        assertEquals(64, sprite.pixelHeight)
        assertEquals(BLOBS + 0x5000, sprite.offset)
    }

    @Test
    fun aSingleSpriteIsPaintedWithThePaletteItsFormatNames() {
        fake.place("graphics.bag.male", BLOBS) // `lzs4x8x8|graphics.bag.palette`
        fake.place("graphics.bag.palette", BLOBS + 0x1000) // `lzp4`
        putPacked(BLOBS, dots())
        putPacked(BLOBS + 0x1000, colors(gbaWhite, gbaGreen, gbaBlue))
        open()
        val graphic = tables.graphic(entry("graphics.bag.male"))!!
        assertEquals(green, graphic.picture.pixels[0])
        assertEquals(blue, graphic.picture.pixels[64 * 64 - 1])
        assertEquals("palette", graphic.palette)
        assertEquals(1, graphic.choices)
        // and the palette alone is a row of swatches
        val swatches = tables.graphic(entry("graphics.bag.palette"))!!
        assertEquals(16, swatches.picture.width)
        assertEquals(green, swatches.picture.pixels[1])
    }

    @Test
    fun aSingleGraphicWhoseDataIsGoneHasNoPicture() {
        fake.place("graphics.bag.male", BLOBS + 0x8000) // nothing but unused bytes there
        open()
        assertNull(tables.graphic(entry("graphics.bag.male")))
    }

    @Test
    fun aSingleSpriteTakesItsPaletteFromTheTableRowThatPointsToIt() {
        // Deoxys' icon is a graphic of its own, but the pointer to it is a row of the table of icons
        for (i in 4 until 440) fake.fixedText(NAMES + i * 11, "MON", 11) // the icons have a row for every Pokemon (and 28 more)
        fake.place("graphics.pokemon.icons.sprites", ICONS_AT_HOME)
        fake.place("graphics.pokemon.icons.index", ICON_INDEX)
        fake.place("graphics.pokemon.icons.palettes", ICON_PALETTES)
        fake.place("graphics.pokemon.icons.deoxys", BLOBS) // writes the pointer at 3D3E08: row 410 of the icons
        put(BLOBS, dots(32, 128))
        fake.u8(ICON_INDEX + 410, 2)
        for (row in 0 until 3) {
            put(BLOBS + 0x1000 + row * 0x40, colors(gbaWhite, intArrayOf(gbaRed, gbaGreen, gbaBlue)[row], gbaWhite))
            fake.pointer(ICON_PALETTES + row * 8, BLOBS + 0x1000 + row * 0x40)
            fake.u32(ICON_PALETTES + row * 8 + 4, row.toLong())
        }
        open()
        val graphic = tables.graphic(entry("graphics.pokemon.icons.deoxys"))!!
        assertEquals(32, graphic.picture.width)
        assertEquals(128, graphic.picture.height)
        assertEquals(blue, graphic.picture.pixels[0]) // palette 2
        assertEquals("palettes", graphic.palette)
    }

    @Test
    fun anEntryCanBeFoundAgainByItsName() {
        fake.place("graphics.bag.male", BLOBS + 0x5000)
        open()
        val found = tables.graphicEntry("graphics.bag.male")!!
        assertEquals(BLOBS + 0x5000, found.offset)
        assertEquals(GraphicKind.SPRITE, found.kind)
        assertNull(tables.graphicEntry("graphics.bag.palette")) // the ROM does not have it
        assertNull(tables.graphicEntry("scripts.newgame.setflags")) // not a graphic
        assertNull(tables.graphicEntry("no.such.thing"))
        fake.place("graphics.bag.male", BLOBS + 0x6000) // the pointer moved
        open()
        assertEquals(BLOBS + 0x6000, tables.graphicEntry("graphics.bag.male")!!.offset)
    }

    @Test
    fun theListFollowsTheRomAfterItChanges() {
        evolutionScene()
        open()
        assertEquals(1, tables.graphics().size)
        fake.place("graphics.bag.palette", BLOBS + 0x6000)
        open()
        assertEquals(2, tables.graphics().size)
    }

    companion object {
        const val NAMES = 0x100000
        const val FRONT = 0x110000
        const val NORMAL = 0x111000
        const val SHINY = 0x112000
        const val TRAINERS = 0x113000
        const val TRAINER_PALETTES = 0x114000
        const val ICONS = 0x115000
        const val ICON_INDEX = 0x116000
        const val ICON_PALETTES = 0x117000
        const val ITEMS = 0x118000
        const val ITEM_SPRITES = 0x119000
        const val EMOTES = 0x11A000
        const val OVERWORLD_PALETTES = 0x11B000
        const val MAIL = 0x11C000
        const val MENU_BOXES = 0x11D000
        const val BACKGROUNDS = 0x11E000
        const val SCENE_PALETTE = 0x120000
        const val SCENE_TILESET = 0x121000
        const val SCENE_MAP = 0x122000
        const val ICONS_AT_HOME = 0x3D37A0
        const val BLOBS = 0x130000
    }
}
