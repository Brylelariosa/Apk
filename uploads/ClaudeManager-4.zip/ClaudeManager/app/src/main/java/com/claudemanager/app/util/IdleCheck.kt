package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project

/** One thing that still stops an account from being idle. */
sealed interface IdleReason {

    /** RUNNING, BUILDING, TESTING or a custom status: the work is not done yet. */
    data class Working(val project: Project) : IdleReason

    /** WAITING and the wait is not over. [until] is null when no time was given. */
    data class Waiting(val project: Project, val until: Long?) : IdleReason

    /** The project's reset time has not been reached yet. */
    data class ResetPending(val project: Project, val at: Long) : IdleReason

    /** A project of this account was deleted; the account stays in use until [until]. */
    data class DeleteHold(val until: Long) : IdleReason
}

class IdleReport(val reasons: List<IdleReason>) {

    /** True only when every check passed. */
    val isIdle: Boolean
        get() = reasons.isEmpty()

    /**
     * When the account turns idle by itself: the latest end time among the reasons.
     * Null when it is already idle, or when some reason has no end time (work in progress,
     * or a wait without a time), because then nobody can tell.
     */
    val idleAt: Long?
        get() {
            if (reasons.isEmpty()) return null
            var latest = 0L
            for (reason in reasons) {
                val end: Long = when (reason) {
                    is IdleReason.Working -> return null
                    is IdleReason.Waiting -> reason.until ?: return null
                    is IdleReason.ResetPending -> reason.at
                    is IdleReason.DeleteHold -> reason.until
                }
                if (end > latest) latest = end
            }
            return latest
        }
}

/**
 * "Is this account really idle?" An account is idle only when ALL of these hold:
 *
 *   1. No project is RUNNING, BUILDING, TESTING or has a custom status (the work is done).
 *   2. No project is WAITING with time left (a wait without a time never ends by itself).
 *   3. Every project's reset time has passed (or was never set).
 *   4. The hold after a deleted project is over.
 *
 * READY, FINISHED and ERROR projects do not block by themselves; their reset time (3) still does.
 */
object IdleCheck {

    /** How long an account stays "in use" after one of its projects is deleted. */
    const val DELETE_HOLD_MILLIS: Long = 5L * 60L * 60L * 1000L

    fun report(account: Account, projects: List<Project>, now: Long): IdleReport {
        val working = mutableListOf<IdleReason>()
        val waiting = mutableListOf<IdleReason>()
        val resets = mutableListOf<IdleReason.ResetPending>()

        for (p in projects) {
            if (p.accountId != account.id) continue

            when (p.activityStatus) {
                ActivityStatus.RUNNING,
                ActivityStatus.BUILDING,
                ActivityStatus.TESTING,
                ActivityStatus.CUSTOM -> working.add(IdleReason.Working(p))

                ActivityStatus.WAITING -> {
                    val until = p.waitUntil
                    if (until == null || until > now) waiting.add(IdleReason.Waiting(p, until))
                }

                ActivityStatus.READY,
                ActivityStatus.FINISHED,
                ActivityStatus.ERROR -> Unit
            }

            val end = p.timerEndTimestamp
            if (end != null && end > now) resets.add(IdleReason.ResetPending(p, end))
        }

        val reasons = mutableListOf<IdleReason>()
        reasons.addAll(working)
        reasons.addAll(waiting)
        reasons.addAll(resets.sortedBy { it.at })

        val hold = account.holdUntil
        if (hold != null && hold > now) reasons.add(IdleReason.DeleteHold(hold))

        return IdleReport(reasons)
    }
}
