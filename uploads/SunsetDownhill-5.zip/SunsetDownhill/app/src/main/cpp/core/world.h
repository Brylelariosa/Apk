// world.h - the road, obstacles/traffic and procedurally placed scenery.
#pragma once

#include <cstdint>
#include <unordered_map>
#include <vector>

#include "car_models.h"
#include "color.h"
#include "math3d.h"
#include "rng.h"
#include "scene_types.h"
#include "track.h"

namespace sd {

enum class ObstacleKind : uint8_t { Cone, Rock, Car };

// What a driver is doing (see traffic.cpp). Only meaningful for ObstacleKind::Car.
struct CarState {
    uint8_t type = kCarSedan;     // body style, selects the render batch
    float dir = 1.0f;             // +1 travels the same way as the rider (downhill), -1 oncoming
    float speed = 0.0f;           // m/s along its own direction of travel (>= 0)
    float desiredSpeed = 11.0f;   // what this driver wants on a clear road
    float timeGap = 1.6f;         // seconds of following distance this driver keeps
    float laneX = 1.8f;           // centre of its own lane; it returns here whenever it safely can
    float targetX = 1.8f;         // the line it is steering toward
    float vx = 0.0f;              // lateral velocity in road space (m/s)
    float accel = 0.0f;           // last longitudinal acceleration (drives the brake lights and body pitch)
    float freeAhead = 99.0f;      // how far its current line is clear (m), from the last replan
    float brake = 0.0f;           // brake light intensity 0..1
    float dive = 0.0f;            // smoothed nose-down pitch (rad)
    int signal = 0;               // indicator: -1 left, +1 right (the car's own left / right), 0 off
    float signalT = 0.0f;         // how long the indicator has been on
    float replanT = 0.0f;
    float waitT = 0.0f;           // how long it has been standing still
    bool waiting = false;         // standing short of an obstacle until a gap opens up (it keeps room to pull out)
    bool gone = false;            // removed by the traffic logic (a deadlock far out of sight)
    float baseHs = 2.25f, baseHx = 0.95f;   // body half extents when driving straight
};

struct Obstacle {
    ObstacleKind kind = ObstacleKind::Cone;
    float s = 0.0f, x = 0.0f;       // road space centre
    float hs = 0.3f, hx = 0.3f;     // collision half extents (along road, lateral)
    float yaw = 0.0f;               // visual yaw relative to the road tangent
    float scale = 1.0f;
    float vel = 0.0f;               // along-road velocity (cars); negative = oncoming
    Rgba8 tint;
    bool passed = false;            // near-miss already evaluated
    bool hit = false;               // cones: knocked away
    float hitTime = 0.0f;
    float knockDir = 1.0f;
    float minGap = 99.0f;           // smallest lateral clearance seen while overlapping in s
    CarState car;                   // cars only
    uint32_t id = 0;                // unique within a run (tests and debugging)
};

// The rider as the traffic sees them: drivers keep clear of them and check their mirror before changing lane.
struct PlayerRef {
    float s = 0.0f, x = 0.0f, speed = 0.0f;
    bool active = false;
};

class World {
public:
    explicit World(uint32_t seed = 1u) { reset(seed); }
    void reset(uint32_t seed);

    void setObstaclesEnabled(bool on) { obstaclesEnabled_ = on; }
    // Extends the road, spawns / moves / culls obstacles around the player and lets the drivers react to everything on the road.
    void update(float dt, const PlayerRef& player);
    void update(float dt, float playerS) { PlayerRef p; p.s = playerS; update(dt, p); }

    Track& track() { return track_; }
    const Track& track() const { return track_; }
    std::vector<Obstacle>& obstacles() { return obstacles_; }
    const std::vector<Obstacle>& obstacles() const { return obstacles_; }

    // ---- render-side builders (positions are made camera relative with `origin`) ----
    void buildTerrain(float focusS, const Vec3& origin, SceneGeometry& out) const;
    void buildScenery(float focusS, const Vec3& origin, const Vec3& camFwd, float density, SceneGeometry& out);
    // `time` drives the blinking indicators.
    void buildObstacles(const Vec3& origin, SceneGeometry& out, float time) const;
    void buildStartGate(float focusS, const Vec3& origin, SceneGeometry& out) const;
    // Gorge jumps: the kicker at the cliff edge and the warning signs.
    void buildShortcuts(float focusS, const Vec3& origin, SceneGeometry& out) const;

private:
    struct Placed {
        Instance inst;  // absolute position
        float rank;     // 0..1, drawn when rank <= density
    };
    struct Chunk {
        std::vector<Placed> items[kBatchCount];
    };

    void spawnUpTo(float sLimit);
    bool spawnClear(const Obstacle& candidate) const;
    const Chunk& chunkAt(int index);
    void generateChunk(int index, Chunk& chunk);

    Track track_;
    Rng obstacleRng_;
    std::vector<Obstacle> obstacles_;
    float nextObstacleS_ = 0.0f;
    uint32_t nextId_ = 1;
    bool obstaclesEnabled_ = true;
    std::unordered_map<int, Chunk> chunks_;
    mutable std::vector<Vec3> scratch_;
};

}  // namespace sd
