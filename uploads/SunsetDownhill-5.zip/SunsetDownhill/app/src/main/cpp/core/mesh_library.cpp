#include "mesh_library.h"

#include "car_models.h"

namespace sd {
namespace {

const Mat4 kId = Mat4::identity();

Mat4 at(float x, float y, float z) { return Mat4::translation(Vec3(x, y, z)); }

// Rotation about the vertical axis, with the origin at (x, y, z).
Mat4 rotY(float a, float x, float y, float z) {
    const float c = std::cos(a), s = std::sin(a);
    return Mat4::fromBasis(Vec3(c, 0.0f, -s), Vec3(0.0f, 1.0f, 0.0f), Vec3(s, 0.0f, c), Vec3(x, y, z));
}

// A frustum that starts at `base` and grows along `dir` (boughs and limbs).
Mat4 along(const Vec3& base, const Vec3& dir) {
    const Vec3 y = normalize(dir);
    Vec3 x = cross(Vec3(0.0f, 0.0f, 1.0f), y);
    if (dot(x, x) < 1e-4f) x = Vec3(1.0f, 0.0f, 0.0f);
    x = normalize(x);
    return Mat4::fromBasis(x, y, cross(x, y), base);
}

Rgba8 mixc(const Rgba8& a, const Rgba8& b, float t) {
    return rgba(lerpf(a.r / 255.0f, b.r / 255.0f, t), lerpf(a.g / 255.0f, b.g / 255.0f, t), lerpf(a.b / 255.0f, b.b / 255.0f, t));
}

// Conifer: seven tiers of branches, each turned a little against the one below and ringed by a drooping skirt, so the silhouette is
// ragged like a real spruce instead of a stack of identical cones. Dark inside, lit at the tips.
MeshData buildPine() {
    MeshData m;
    const Material trunk{0, 0, 0, 40};
    m.addFrustum(kId, 0.36f, 0.17f, 3.4f, 8, rgba(0.22f, 0.14f, 0.09f), rgba(0.14f, 0.09f, 0.055f), trunk, 0.0f);
    struct Tier { float y, r, h; };
    const Tier tiers[7] = {{1.10f, 2.55f, 2.55f}, {2.45f, 2.22f, 2.50f}, {3.80f, 1.90f, 2.45f}, {5.10f, 1.58f, 2.35f},
                           {6.35f, 1.26f, 2.25f}, {7.50f, 0.94f, 2.05f}, {8.55f, 0.60f, 1.95f}};
    const Material leaf{255, 0, 255, 255};
    for (int i = 0; i < 7; ++i) {
        const float k = static_cast<float>(i) / 6.0f;
        const float a = 0.83f * static_cast<float>(i);
        const Rgba8 lo = rgba(lerpf(0.030f, 0.065f, k), lerpf(0.105f, 0.19f, k), lerpf(0.065f, 0.085f, k));
        const Rgba8 hi = rgba(lerpf(0.13f, 0.21f, k), lerpf(0.34f, 0.47f, k), lerpf(0.12f, 0.15f, k));
        m.addFrustum(rotY(a, 0.0f, tiers[i].y, 0.0f), tiers[i].r, 0.0f, tiers[i].h, 11, lo, hi, leaf, 0.55f);
        // the drooping rim of the branches, a little darker and wider than the cone above it
        m.addFrustum(rotY(a + 0.3f, 0.0f, tiers[i].y - 0.17f, 0.0f), tiers[i].r * 1.10f, tiers[i].r * 0.56f, tiers[i].h * 0.34f, 11,
                     mixc(lo, rgba(0.0f, 0.04f, 0.02f), 0.45f), lo, leaf, 0.10f);
    }
    m.addFrustum(at(0.0f, 10.2f, 0.0f), 0.09f, 0.0f, 0.95f, 5, rgba(0.10f, 0.20f, 0.08f), rgba(0.18f, 0.34f, 0.12f), leaf, 0.2f);
    return m;
}

// Round autumn tree: a trunk that forks into two limbs and a crown of six lobes in different shades of gold, orange and red.
MeshData buildAutumn() {
    MeshData m;
    const Material wood{0, 0, 0, 30};
    const Rgba8 b0 = rgba(0.25f, 0.16f, 0.10f), b1 = rgba(0.16f, 0.10f, 0.065f);
    m.addFrustum(kId, 0.37f, 0.19f, 3.3f, 8, b0, b1, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 3.0f, 0.0f), Vec3(0.55f, 1.0f, 0.15f)), 0.17f, 0.07f, 2.5f, 6, b1, b1, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 3.1f, 0.0f), Vec3(-0.50f, 1.0f, -0.25f)), 0.15f, 0.06f, 2.4f, 6, b1, b1, wood, 0.0f);
    const Material leaf{255, 0, 255, 200};
    struct Lobe { float x, y, z, rx, ry, rz; uint32_t seed; float warm; };
    const Lobe lobes[6] = {{0.0f, 5.5f, 0.0f, 2.7f, 2.2f, 2.7f, 11u, 0.0f}, {1.5f, 6.3f, 0.7f, 1.9f, 1.6f, 1.9f, 23u, 0.6f},
                           {-1.4f, 6.7f, -0.6f, 1.8f, 1.5f, 1.8f, 37u, 0.3f}, {0.3f, 7.6f, 0.2f, 1.5f, 1.2f, 1.5f, 51u, 1.0f},
                           {-1.9f, 4.9f, 1.1f, 1.5f, 1.2f, 1.5f, 63u, 0.5f}, {1.9f, 4.7f, -1.2f, 1.4f, 1.1f, 1.4f, 77u, 0.2f}};
    for (const Lobe& l : lobes) {
        const Rgba8 lo = mixc(rgba(0.60f, 0.21f, 0.04f), rgba(0.70f, 0.10f, 0.05f), l.warm);
        const Rgba8 hi = mixc(rgba(1.00f, 0.70f, 0.16f), rgba(1.00f, 0.46f, 0.11f), l.warm);
        m.addBlob(at(l.x, l.y, l.z), Vec3(l.rx, l.ry, l.rz), l.seed, 1, 0.17f, false, lo, hi, leaf);
    }
    return m;
}

// Birch: slim white trunk with dark bark bands, thin boughs and a small, light golden crown.
MeshData buildBirch() {
    MeshData m;
    const Material wood{0, 0, 0, 30};
    const Rgba8 white = rgba(0.93f, 0.92f, 0.87f), bandC = rgba(0.10f, 0.09f, 0.08f);
    m.addFrustum(kId, 0.18f, 0.09f, 7.4f, 7, rgba(0.58f, 0.56f, 0.50f), white, wood, 0.0f);
    for (int i = 0; i < 6; ++i) {
        const float y = 0.7f + 1.12f * static_cast<float>(i);
        const float r = lerpf(0.18f, 0.09f, y / 7.4f) + 0.004f;
        m.addFrustum(at(0.0f, y, 0.0f), r, r * 0.985f, 0.10f + 0.03f * static_cast<float>(i % 3), 7, bandC, bandC, wood, 0.0f);
    }
    m.addFrustum(along(Vec3(0.0f, 4.7f, 0.0f), Vec3(0.60f, 1.0f, 0.10f)), 0.08f, 0.03f, 2.3f, 5, white, white, wood, 0.0f);
    m.addFrustum(along(Vec3(0.0f, 5.3f, 0.0f), Vec3(-0.55f, 1.0f, 0.30f)), 0.07f, 0.03f, 2.1f, 5, white, white, wood, 0.0f);
    const Material leaf{255, 0, 255, 220};
    const Rgba8 lo = rgba(0.74f, 0.42f, 0.05f), hi = rgba(1.00f, 0.90f, 0.32f);
    m.addBlob(at(0.0f, 7.9f, 0.0f), Vec3(1.55f, 2.0f, 1.55f), 101u, 1, 0.18f, false, lo, hi, leaf);
    m.addBlob(at(1.15f, 6.6f, 0.5f), Vec3(1.15f, 1.35f, 1.15f), 103u, 1, 0.18f, false, lo, hi, leaf);
    m.addBlob(at(-1.0f, 7.0f, -0.45f), Vec3(1.2f, 1.45f, 1.2f), 107u, 1, 0.18f, false, lo, hi, leaf);
    m.addBlob(at(0.15f, 9.3f, 0.1f), Vec3(0.95f, 1.15f, 0.95f), 109u, 1, 0.18f, false, lo, hi, leaf);
    return m;
}

// Low undergrowth along the verge (three lumps); `autumn` gives it the colours of the autumn trees.
MeshData buildUndergrowth(bool autumn) {
    MeshData m;
    const Material leaf{255, 0, 255, 150};
    const Rgba8 lo = autumn ? rgba(0.50f, 0.17f, 0.04f) : rgba(0.035f, 0.12f, 0.05f);
    const Rgba8 hi = autumn ? rgba(0.92f, 0.56f, 0.13f) : rgba(0.17f, 0.32f, 0.11f);
    m.addBlob(at(0.0f, 0.42f, 0.0f), Vec3(1.0f, 0.62f, 1.0f), autumn ? 91u : 81u, 1, 0.20f, false, lo, hi, leaf, 0.3f);
    m.addBlob(at(0.72f, 0.33f, 0.42f), Vec3(0.70f, 0.48f, 0.70f), autumn ? 92u : 82u, 1, 0.20f, false, lo, hi, leaf, 0.3f);
    m.addBlob(at(-0.62f, 0.28f, -0.50f), Vec3(0.60f, 0.42f, 0.60f), autumn ? 93u : 83u, 1, 0.20f, false, lo, hi, leaf, 0.3f);
    return m;
}

MeshData buildRock() {
    MeshData m;
    m.addBlob(kId, Vec3(1.0f, 0.74f, 1.0f), 5u, 1, 0.30f, true, rgba(0.26f, 0.23f, 0.22f), rgba(0.52f, 0.47f, 0.43f),
              Material{255, 0, 0, 0}, 0.25f);
    return m;
}

MeshData buildPost() {
    MeshData m;
    m.addBox(at(0.0f, 0.5f, 0.0f), Vec3(0.045f, 0.5f, 0.045f), rgba(0.86f, 0.86f, 0.84f), Material{});
    m.addBox(at(0.0f, 0.78f, 0.0f), Vec3(0.05f, 0.07f, 0.05f), rgba(1.0f, 0.35f, 0.12f), Material{0, 190, 0, 0});
    return m;
}

MeshData buildRail() {
    MeshData m;
    const Rgba8 steel = rgba(0.62f, 0.64f, 0.68f);
    m.addBox(at(0.0f, 0.62f, 0.0f), Vec3(0.045f, 0.17f, 2.0f), steel, Material{});
    m.addBox(at(0.0f, 0.46f, 0.0f), Vec3(0.03f, 0.03f, 2.0f), steel, Material{});
    m.addBox(at(0.12f, 0.36f, -1.7f), Vec3(0.05f, 0.36f, 0.05f), rgba(0.40f, 0.30f, 0.20f), Material{});
    m.addBox(at(0.12f, 0.36f, 1.7f), Vec3(0.05f, 0.36f, 0.05f), rgba(0.40f, 0.30f, 0.20f), Material{});
    m.addBox(at(-0.05f, 0.62f, -1.0f), Vec3(0.012f, 0.05f, 0.05f), rgba(1.0f, 0.5f, 0.2f), Material{0, 150, 0, 0});
    return m;
}

MeshData buildCone() {
    MeshData m;
    const Material orange{255, 0, 0, 0};
    m.addBox(at(0.0f, 0.02f, 0.0f), Vec3(0.21f, 0.02f, 0.21f), rgba(0.95f, 0.30f, 0.05f), orange);
    m.addFrustum(at(0.0f, 0.04f, 0.0f), 0.17f, 0.135f, 0.20f, 10, rgba(1.0f, 0.36f, 0.06f), rgba(1.0f, 0.40f, 0.08f), orange, 0.1f);
    m.addFrustum(at(0.0f, 0.24f, 0.0f), 0.135f, 0.105f, 0.17f, 10, rgba(0.95f, 0.95f, 0.92f), rgba(0.95f, 0.95f, 0.92f), Material{}, 0.1f);
    m.addFrustum(at(0.0f, 0.41f, 0.0f), 0.105f, 0.035f, 0.29f, 10, rgba(1.0f, 0.36f, 0.06f), rgba(1.0f, 0.42f, 0.10f), orange, 0.1f);
    return m;
}

}  // namespace

MeshData buildBatchMesh(Batch batch) {
    switch (batch) {
        case kBatchPine: return buildPine();
        case kBatchAutumn: return buildAutumn();
        case kBatchBirch: return buildBirch();
        case kBatchBush: return buildUndergrowth(false);
        case kBatchShrub: return buildUndergrowth(true);
        case kBatchRock: return buildRock();
        case kBatchPost: return buildPost();
        case kBatchRail: return buildRail();
        case kBatchCone: return buildCone();
        default: break;
    }
    if (batch >= kBatchCar && batch < kBatchCar + kCarBatchCount) return buildCarMesh(static_cast<int>(batch) - kBatchCar);
    return MeshData();
}

}  // namespace sd
