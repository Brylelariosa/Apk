// traffic.h - how the cars drive.
//
// Every car perceives the road around it (rocks, other cars and the rider) and behaves like a careful, PREDICTABLE driver: it keeps
// its lane and a safe following distance (Intelligent Driver Model), slows for curves and brakes in time for anything in its path.
// It leaves its lane for one reason only: a boulder that really blocks it - and then only after signalling, and only when the line
// it wants is free of oncoming traffic and nobody is alongside or closing fast from behind (otherwise it stops and waits).
// What it does NOT do (this used to make cars swerve "for no reason"): it does not dodge traffic cones (light plastic: it simply
// drives through and knocks them over, like the rider does), it does not overtake slower cars (it follows them), and it does not
// dodge the rider (keeping clear of cars is the rider's job; a car never moves toward a rider who is alongside or right behind).
#pragma once

#include <vector>

#include "world.h"

namespace sd {

void stepTraffic(std::vector<Obstacle>& obstacles, const Track& track, float dt, const PlayerRef& player);

}  // namespace sd
