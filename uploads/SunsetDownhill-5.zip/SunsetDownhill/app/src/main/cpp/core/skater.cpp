#include "skater.h"

#include <algorithm>
#include <cmath>

namespace sd {

void Skater::reset(float s0, float speed0) {
    *this = Skater();
    s = s0;
    speed = speed0;
}

void Skater::startPush() {
    pushTimer = cfg::kPushTime;
    pushPhase = 0.0f;
    pushAmount = 1.0f;   // the rider is already in the "ready to kick" pose from the countdown
    pushSteps = 1;       // the first kick plants straight away
}

void Skater::crash(CrashCause cause) {
    if (crashed) return;
    crashed = true;
    gapFlight = false;
    crashCause = cause;
    crashTime = 0.0f;
    crashSpeed = speed;
    slide = 0.0f;
    tuck = 0.0f;
    yawVel = 0.0f;
}

float Skater::gripNow() const {
    return cfg::kGrip * (1.0f + cfg::kSlideGripBoost * slide) * (1.0f - cfg::kTuckGripCut * tuck) *
           (onShoulder ? 0.55f : 1.0f);
}

namespace {
// One step of free flight in road space. The heading stays fixed in the world, so relative to the (bending) road it drifts.
void flightStep(const Track& track, float& s, float& x, float& alpha, float& yRel, float& vy, float speed, float dt) {
    const float curv = track.curvatureAt(s);
    const float denom = std::max(0.35f, 1.0f - curv * x);
    const float ds = speed * std::cos(alpha) / denom * dt;
    s += ds;
    x += speed * std::sin(alpha) * dt;
    alpha -= curv * ds;
    vy -= cfg::kAirGravity * dt;
    yRel += vy * dt;
}
}  // namespace

// At the lip of a kicker: with enough speed the rider flies the fixed path over the gorge (see Track::gapFlight); slower than that the
// kicker is only a hop, and the road (and its rail) takes the rider as usual.
bool Skater::beginGapFlight(const Track& track) {
    const int zi = track.zoneIndexAt(s);
    if (zi < 0 || speed < cfg::kGapMinSpeed) return false;
    const ShortcutZone& z = track.shortcuts()[static_cast<size_t>(zi)];
    if (s < z.sLip - 2.0f || s > z.sLip + 6.0f) return false;
    gapFlight = true;
    gapZone = zi;
    gapTime = 0.0f;
    gapU = 0.0f;
    gapStartX = x * z.side;
    gapDuration = clampf(track.gapChord(z) / speed, cfg::kGapMinTime, cfg::kGapMaxTime);
    gapFocus = z.sLip + 40.0f;
    return true;
}

SkaterEvent Skater::stepGap(const SkaterInput& in, const Track& track, float dt) {
    const ShortcutZone& z = track.shortcuts()[static_cast<size_t>(gapZone)];
    // controls keep easing (so the pose is right on landing) but nothing steers the board in the air
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    tuck += (1.0f - tuck) * smoothing(5.0f, dt);   // crouch for the flight
    slide += (0.0f - slide) * smoothing(6.0f, dt);
    pushTimer = 0.0f;
    pushAmount += (0.0f - pushAmount) * smoothing(8.0f, dt);
    stallTime = 0.0f;
    speed *= std::exp(-0.015f * dt);   // a little air drag
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);
    airTime += dt;
    yawVel += (cfg::kColeKick * (0.0f - yawVis) - cfg::kColeDamp * yawVel) * dt;
    yawVis += yawVel * dt;
    lean += (0.0f - lean) * smoothing(5.0f, dt);

    gapTime += dt;
    gapU = saturate(gapTime / gapDuration);
    s = lerpf(z.sLip, z.sLand, gapU);   // (the road-space numbers just follow along)
    x = z.side * lerpf(gapStartX, z.xsFlight, smoothstep(0.0f, 0.4f, gapU));
    alpha = 0.0f;
    yRel = 0.0f;
    vy = 0.0f;
    if (gapU >= 1.0f) {   // touchdown on the road beyond the gorge
        gapFlight = false;
        airborne = false;
        s = z.sLand;
        x = z.side * z.xsFlight;
        lastLandVy = -9.0f;
        lastLandKind = Track::kRoad;
        surface = Track::kRoad;
        onShoulder = false;
        speed *= 0.96f;
        ++landings;
        ++gapJumps;
    }
    return SkaterEvent::None;
}

SkaterEvent Skater::stepAir(const SkaterInput& in, const Track& track, float dt) {
    if (gapFlight) return stepGap(in, track, dt);
    // controls keep easing (so the pose is right on landing) but nothing steers the board in the air
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    tuck += (1.0f - tuck) * smoothing(5.0f, dt);   // crouch for the flight
    slide += (0.0f - slide) * smoothing(6.0f, dt);
    pushTimer = 0.0f;
    pushAmount += (0.0f - pushAmount) * smoothing(8.0f, dt);
    stallTime = 0.0f;
    speed *= std::exp(-0.015f * dt);   // a little air drag
    flightStep(track, s, x, alpha, yRel, vy, speed, dt);
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);
    airTime += dt;
    airPeak = std::max(airPeak, yRel);
    yawVel += (cfg::kColeKick * (0.0f - yawVis) - cfg::kColeDamp * yawVel) * dt;
    yawVis += yawVel * dt;
    lean += (0.0f - lean) * smoothing(5.0f, dt);

    int kind = Track::kVoid;
    const float support = track.supportHeight(s, x, &kind);
    if (vy <= 0.0f && yRel <= support) {   // touchdown
        yRel = support;
        lastLandVy = vy;
        lastLandKind = kind;
        airborne = false;
        ++landings;
        vy = 0.0f;
        if (kind == Track::kVoid || -lastLandVy > cfg::kHardLanding) {   // the hillside below, or too far down
            surface = Track::kRoad;
            crash(CrashCause::Fall);
            return SkaterEvent::Crash;
        }
        surface = kind;
        speed *= 1.0f - std::min(0.12f, 0.006f * (-lastLandVy));
        alpha *= 0.4f;   // the board straightens up as the wheels bite
    }
    return SkaterEvent::None;
}

SkaterEvent Skater::step(const SkaterInput& in, const Track& track, float dt) {
    SkaterEvent ev = SkaterEvent::None;
    scrape = std::max(0.0f, scrape - dt * 4.0f);

    if (crashed) {
        crashTime += dt;
        speed *= std::exp(-1.1f * dt);
        s += speed * std::cos(alpha) * dt;
        x += speed * std::sin(alpha) * dt * 0.5f;
        if (airborne) {   // went over the edge: keep falling until the ground
            vy -= cfg::kAirGravity * dt;
            yRel += vy * dt;
            const float ground = track.supportHeight(s, x);
            if (yRel <= ground) {
                yRel = ground;
                vy = 0.0f;
                airborne = false;
            }
        } else if (yRel > -0.5f) {
            x = clampf(x, -cfg::kRailOffset, cfg::kRailOffset);
        }
        return ev;
    }
    if (airborne) return stepAir(in, track, dt);

    const float curv = track.curvatureAt(s);
    const float pitch = track.pitchAt(s);

    // ---- kick-push: after a couple of kicks TUCK or SLIDE ends it early so the rider can get on with the run
    const bool wasPushing = pushTimer > 0.0f;
    if (wasPushing && pushPhase >= static_cast<float>(cfg::kPushCancelAfter) && (in.tuck || in.slide)) pushTimer = 0.0f;
    const bool pushing = pushTimer > 0.0f;

    // ---- controls
    steer += (clampf(in.steer, -1.0f, 1.0f) - steer) * smoothing(cfg::kSteerResponse, dt);
    const float tuckTarget = (in.tuck && !pushing) ? 1.0f : 0.0f;
    tuck += (tuckTarget - tuck) * smoothing(7.0f, dt);
    const bool slideWanted = in.slide && speed > 3.0f && !pushing;
    slide += ((slideWanted ? 1.0f : 0.0f) - slide) * smoothing(slideWanted ? 12.0f : 6.0f, dt);

    // ---- heading
    const float wMax = std::min(cfg::kYawRateMax * (1.0f + 0.4f * slide), gripNow() / std::max(speed, 3.0f));
    const float omega = steer * wMax;
    const float follow = curv * speed * (1.0f - cfg::kAutoFollow);
    alpha += (omega - follow - cfg::kStability * (1.0f - 0.6f * slide) * alpha) * dt;
    alpha = clampf(alpha, -1.15f, 1.15f);

    // ---- speed
    const float aGrav = cfg::kGravity * std::sin(pitch) * cfg::kGravityScale;
    const float drag = cfg::kDragCoef * (1.0f - cfg::kTuckDragCut * tuck);
    float a = aGrav - drag * speed * speed - cfg::kRolling - std::fabs(omega) * speed * 0.02f;
    a -= slide * (cfg::kSlideDecelBase + cfg::kSlideDecelDrag * speed * speed);
    if (onShoulder) a -= cfg::kShoulderDrag * speed;
    if (pushing) {
        // Each kick: foot planted and driving back for the first part of the cycle, then it swings forward again.
        // Kicks help less and less the faster the board is already rolling.
        const float u = pushPhase - std::floor(pushPhase);
        if (u < cfg::kPushContact) {
            const float drive = std::sin(kPi * u / cfg::kPushContact);
            const float eff = std::max(0.12f, 1.0f - speed / cfg::kPushFadeSpeed);
            a += cfg::kPushAccel * drive * eff;
        }
        const float before = pushPhase;
        pushPhase += dt / cfg::kPushPeriod;
        pushTimer = std::max(0.0f, pushTimer - dt);
        if (pushTimer > 0.0f && std::floor(pushPhase) > std::floor(before)) ++pushSteps;   // next kick plants
        if (pushTimer <= 0.0f) pushPhase = std::max(pushPhase, static_cast<float>(cfg::kPushStrokes));
    }
    if (wasPushing && pushTimer <= 0.0f) ++pushLands;   // foot goes back onto the deck
    speed = std::max(0.0f, speed + a * dt);

    // ---- bail out if the rider has come to a halt
    if (!pushing && speed < 1.0f) {
        stallTime += dt;
        if (stallTime > cfg::kStallTime) {
            crash(CrashCause::Stall);
            return SkaterEvent::Crash;
        }
    } else {
        stallTime = 0.0f;
    }

    // ---- kinematics
    const float denom = std::max(0.35f, 1.0f - curv * x);
    s += speed * std::cos(alpha) / denom * dt;
    x += speed * std::sin(alpha) * dt;
    distance += speed * dt;
    topSpeed = std::max(topSpeed, speed);

    // ---- road edges (the rails)
    float lo, hi;
    track.lateralWindow(s, surface, &lo, &hi);
    onShoulder = std::fabs(x) > cfg::kRoadHalfWidth;
    if (x > hi || x < lo) {
        const float side = x > hi ? 1.0f : -1.0f;
        const float outSpeed = speed * std::sin(alpha) * side;
        if (outSpeed > cfg::kCrashLateralSpeed) {
            crash(CrashCause::Rail);
            return SkaterEvent::Crash;
        }
        x = x > hi ? hi : lo;
        if (outSpeed > 0.0f) {
            alpha = -alpha * 0.35f;
            speed = std::max(0.0f, speed - outSpeed * 0.8f);
        }
        speed *= 1.0f - 1.5f * dt;
        scrape = 1.0f;
        railTime += dt;
        railClear = 0.0f;
        ev = SkaterEvent::Scrape;
        if (railTime > cfg::kRailGrindLimit) {  // grinding along the rail for too long
            crash(CrashCause::Rail);
            return SkaterEvent::Crash;
        }
    } else {
        railClear += dt;
        if (railClear > 0.5f) railTime = std::max(0.0f, railTime - dt * 0.8f);
    }

    // ---- what carries the board: the road or a kicker. If that falls away (the kicker's lip) the rider takes off.
    {
        int kind = Track::kRoad;
        const float support = track.supportHeight(s, x, &kind);
        if (kind == Track::kVoid || support < yRel - 0.05f) {
            airborne = true;
            airTime = 0.0f;
            airPeak = yRel;
            ++takeoffs;
            if (surface == Track::kKicker) beginGapFlight(track);
            return ev;
        }
        vy = clampf((support - yRel) / std::max(dt, 1e-4f), -30.0f, 30.0f);   // the slope's vertical speed: what a takeoff keeps
        yRel = support;
        surface = kind;
    }

    // ---- visuals
    // Coleman slide: SLIDE kicks the board out sideways. Pressing it while steering left / right throws the board out
    // to that side (and further out the harder you steer); once sliding, only a firm opposite steer switches sides.
    const float steerAbs = std::fabs(steer);
    if (slide < 0.15f) {
        if (steerAbs > 0.12f) slideDir = sign1(steer);
    } else if (steerAbs > 0.45f && sign1(steer) != slideDir) {
        slideDir = sign1(steer);
    }
    const float slip = lerpf(cfg::kColeSlipMin, cfg::kColeSlipMax, saturate(steerAbs));
    const float yawTarget = slide * slideDir * slip;
    // underdamped spring: the board snaps out with a small overshoot, like a real kick-out
    yawVel += (cfg::kColeKick * (yawTarget - yawVis) - cfg::kColeDamp * yawVel) * dt;
    yawVis += yawVel * dt;

    const float leanTarget = clampf(steer * 0.40f + curv * speed * 0.25f, -0.55f, 0.55f) * (1.0f - 0.6f * slide);
    lean += (leanTarget - lean) * smoothing(9.0f, dt);
    pushAmount += ((pushing ? 1.0f : 0.0f) - pushAmount) * smoothing(8.0f, dt);
    return ev;
}

}  // namespace sd
