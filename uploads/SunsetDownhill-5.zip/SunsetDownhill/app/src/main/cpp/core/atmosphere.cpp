#include "atmosphere.h"

#include <cmath>

namespace sd {

Atmosphere makeAtmosphere(float progress, float sunAzimuth) {
    const float t = saturate(progress);
    Atmosphere a;
    const float elev = lerpf(12.0f, 3.5f, t) * kDeg2Rad;
    a.sunDir = normalize(Vec3(std::sin(sunAzimuth) * std::cos(elev), std::sin(elev), -std::cos(sunAzimuth) * std::cos(elev)));
    a.sunColor = lerp(Vec3(1.30f, 0.76f, 0.44f), Vec3(1.02f, 0.45f, 0.27f), t);
    a.ambSky = lerp(Vec3(0.36f, 0.38f, 0.66f), Vec3(0.20f, 0.21f, 0.44f), t);
    a.ambGround = lerp(Vec3(0.36f, 0.26f, 0.22f), Vec3(0.20f, 0.14f, 0.17f), t);
    a.fogColor = lerp(Vec3(0.66f, 0.52f, 0.66f), Vec3(0.40f, 0.29f, 0.50f), t);
    a.fogSun = lerp(Vec3(1.02f, 0.68f, 0.52f), Vec3(0.86f, 0.42f, 0.34f), t);
    a.fogDensity = lerpf(0.0055f, 0.0062f, t);
    a.skyTop = lerp(Vec3(0.14f, 0.21f, 0.50f), Vec3(0.05f, 0.07f, 0.24f), t);
    a.skyMid = lerp(Vec3(0.44f, 0.37f, 0.64f), Vec3(0.27f, 0.21f, 0.46f), t);
    a.cloudLit = lerp(Vec3(1.12f, 0.64f, 0.50f), Vec3(0.92f, 0.42f, 0.38f), t);
    a.cloudShade = lerp(Vec3(0.40f, 0.31f, 0.58f), Vec3(0.17f, 0.14f, 0.34f), t);
    a.mountainNear = lerp(Vec3(0.34f, 0.28f, 0.52f), Vec3(0.16f, 0.12f, 0.32f), t);
    a.mountainFar = lerp(Vec3(0.55f, 0.44f, 0.62f), Vec3(0.31f, 0.23f, 0.43f), t);
    return a;
}

}  // namespace sd
