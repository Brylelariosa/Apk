#include "scene_builder.h"

namespace sd {

FrameParams buildScene(Game& game, float treeDensity, SceneGeometry& geo, const std::vector<RemoteRider>* remotes) {
    geo.clear();
    const CameraView& cam = game.camera().view();
    const Vec3 origin = cam.pos;
    const Skater& sk = game.skater();
    World& world = game.world();

    const float focus = sk.focusS();   // (the road position the world is built around: while a rider flies over a gorge, the mouth of it)
    world.buildTerrain(focus, origin, geo);
    world.buildScenery(focus, origin, cam.fwd, treeDensity, geo);
    world.buildObstacles(origin, geo, game.time());
    world.buildStartGate(sk.s, origin, geo);
    world.buildShortcuts(focus, origin, geo);
    const SkaterPose riderPose = game.skaterPose(origin);
    buildSkaterMesh(riderPose, geo.dynamicMesh, riderStyle(game.localStyle()));
    if (remotes) {
        for (const RemoteRider& rr : *remotes) {
            if (rr.net.s < sk.s - 90.0f || rr.net.s > sk.s + 420.0f) continue;   // out of sight
            // Remote riders use the cheaper model, and are skipped altogether if the 16-bit index range of the mesh is nearly used up.
            if (geo.dynamicMesh.vertices.size() + kRemoteRiderVertexBudget > kDynamicMeshVertexLimit) continue;
            SkaterPose rp = poseFromRiderNet(world.track(), rr.net, origin, game.time());
            rp.lowDetail = true;
            buildSkaterMesh(rp, geo.dynamicMesh, riderStyle(rr.style));
        }
    }
    game.particles().build(origin, geo.smoke, geo.sparks);

    FrameParams fp;
    fp.cam = cam;
    fp.atmo = game.atmosphere();
    fp.time = game.time();
    fp.speed01 = game.speed01() * (game.phase() == Phase::Menu ? 0.75f : 1.0f);
    fp.slide = sk.slide;
    fp.flash = game.crashFlash();

    fp.shadowFocus = riderPose.origin + origin + riderPose.fwd * 12.0f;
    return fp;
}

}  // namespace sd
