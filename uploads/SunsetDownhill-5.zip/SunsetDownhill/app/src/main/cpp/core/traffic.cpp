#include "traffic.h"

#include <algorithm>
#include <cmath>

namespace sd {
namespace {

constexpr float kCorridor = 2.65f;     // furthest a car centre strays from the middle line
constexpr float kMargin = 0.40f;       // sideways clearance a driver wants around a hazard
constexpr float kStopGap = 3.0f;       // bumper gap when standing behind something
constexpr float kMaxAccel = 2.2f;      // m/s^2
constexpr float kComfBrake = 3.2f;
constexpr float kMaxBrake = 8.5f;
constexpr float kSignalLead = 1.0f;    // seconds of indicator before a planned lane change starts moving

// Everything a driver has to keep clear of: cones, rocks, the other cars and the rider.
struct Hazard {
    float s, x, hs, hx;
    float speed;   // signed velocity along the road (+ downhill, - oncoming)
    int owner;     // index in the obstacle list, -1 for the rider
    bool rider = false;
};

float alongOf(const Obstacle& c, const Hazard& h) { return c.car.dir * (h.s - c.s); }

// How far car `c` can drive along the line `x` before it meets something worth steering around, capped at `lookahead`.
// Same-direction traffic that is about as fast as this driver wants to go is not an obstacle (the speed controller follows it).
float freeDistance(const Obstacle& c, int self, float x, const std::vector<Hazard>& hz, float lookahead) {
    const CarState& cs = c.car;
    float best = lookahead;
    for (const Hazard& h : hz) {
        if (h.owner == self || h.rider) continue;                            // (the rider is not something a driver steers around)
        if (std::fabs(h.x - x) >= h.hx + cs.baseHx + kMargin) continue;      // not in the way
        const float a = alongOf(c, h);
        if (a < -(h.hs + cs.baseHs)) continue;                               // already behind us
        const float gap = std::max(0.0f, a - h.hs - cs.baseHs);
        const float hv = h.speed * cs.dir;                                   // its speed along our direction (negative = coming at us)
        float usable;
        if (hv < -0.5f) usable = gap * (cs.speed + 0.5f) / (cs.speed - hv + 0.5f);   // we would meet it part-way
        else if (hv < 0.3f) usable = gap;                                            // standing still: a boulder, or a car waiting its turn
        else continue;                                                               // something moving our way: the speed controller follows it
        best = std::min(best, usable);
    }
    return best;
}

// Mirror check and gap acceptance: may the car start moving toward the line `x`? `extraTime` is how long it will stay out there.
bool laneChangeSafe(const Obstacle& c, int self, float x, const std::vector<Hazard>& hz, float extraTime) {
    const CarState& cs = c.car;
    const float midX = 0.5f * (c.x + x);
    for (const Hazard& h : hz) {
        if (h.owner == self) continue;
        const float reach = h.hx + cs.baseHx + 0.5f;
        const bool nearTarget = std::fabs(h.x - x) < reach;
        const bool toward = (h.x - c.x) * (x - c.x) > 0.0f;                          // on the side we are moving to
        const bool nearPath = std::fabs(h.x - midX) < reach && toward;
        if (!nearTarget && !nearPath) continue;
        const float a = alongOf(c, h);
        const float hv = h.speed * cs.dir;
        if (std::fabs(a) < h.hs + cs.baseHs + 1.0f) return false;                       // somebody is alongside
        if (a > 0.0f) {
            const float gap = a - h.hs - cs.baseHs;
            if (hv < -0.5f) {
                if (gap < 25.0f + (cs.speed - hv) * (4.0f + extraTime)) return false;   // oncoming: leave room to finish the manoeuvre
            } else if (gap < 7.0f + std::max(0.0f, cs.speed - hv) * 1.8f) {
                return false;                                                           // too close ahead
            }
        } else {
            const float gap = -a - h.hs - cs.baseHs;
            if (hv > cs.speed + 1.0f && gap < 6.0f + (hv - cs.speed) * 3.0f) return false;     // someone faster is coming up behind
        }
    }
    return true;
}

// While the car moves over to `xTarget` it keeps rolling forward: nothing may be in the strip it sweeps on the way (things it moves
// away from do not count - leaving a hazard behind is always fine).
bool pathClear(const Obstacle& c, int self, float xTarget, const std::vector<Hazard>& hz) {
    const CarState& cs = c.car;
    const float vEff = std::max(cs.speed, 3.5f);
    const float vxMax = std::min(1.9f, 0.4f + 0.18f * vEff);
    const float travelTime = kSignalLead + std::fabs(xTarget - c.x) / (0.8f * vxMax);
    const float length = vEff * travelTime;
    for (const Hazard& h : hz) {
        if (h.owner == self) continue;
        if ((h.x - c.x) * (xTarget - c.x) <= 0.0f) continue;                          // it is on the other side: we move away from it
        const float a = alongOf(c, h);
        if (a < -(h.hs + cs.baseHs)) continue;                                        // fully behind us
        const float gap = std::max(0.0f, a - h.hs - cs.baseHs);
        if (gap > length + 8.0f) continue;
        if (gap <= 0.0f) {                                                            // alongside: never steer toward it
            if (std::fabs(h.x - c.x) < h.hx + cs.baseHx + 1.2f) return false;
            continue;
        }
        const float xAt = c.x + (xTarget - c.x) * saturate(gap / std::max(length, 1.0f));   // where the car will be when it gets there
        if (std::fabs(h.x - xAt) < h.hx + cs.baseHx + 0.2f) return false;
    }
    return true;
}

struct Leader {
    bool any = false;
    float gap = 0.0f;     // bumper to bumper
    float speed = 0.0f;   // along our direction of travel
};

// The nearest thing in the strip the car is about to sweep.
Leader leaderOf(const Obstacle& c, int self, float xCentre, float halfWidth, const std::vector<Hazard>& hz, float lookahead) {
    Leader best;
    best.gap = lookahead;
    for (const Hazard& h : hz) {
        if (h.owner == self) continue;
        if (h.rider && h.speed * c.car.dir < 0.0f) continue;   // a rider coming at us: it is up to the rider to dodge
        if (std::fabs(h.x - xCentre) >= h.hx + halfWidth) continue;
        const float a = alongOf(c, h);
        if (a < 0.0f) continue;                       // level with us or behind
        const float gap = a - h.hs - c.car.baseHs;
        if (gap >= best.gap) continue;
        best.any = true;
        best.gap = std::max(gap, 0.0f);
        best.speed = h.speed * c.car.dir;
    }
    return best;
}

// Choose the line to steer toward: stay in the lane, return to it when it is free again, or go around what blocks it.
void plan(Obstacle& c, int self, const std::vector<Hazard>& hz) {
    CarState& cs = c.car;
    const float v = cs.speed;
    const float react = std::max(26.0f, v * 3.4f + 12.0f);
    const float dOwn = freeDistance(c, self, cs.laneX, hz, react * 1.4f);
    const float dHere = freeDistance(c, self, c.x, hz, react * 1.4f);
    cs.freeAhead = dHere;
    const bool blocked = dOwn < react || dHere < react;
    if (!blocked) {
        cs.waiting = false;
        if (std::fabs(c.x - cs.laneX) < 0.05f || (laneChangeSafe(c, self, cs.laneX, hz, 0.0f) && pathClear(c, self, cs.laneX, hz))) cs.targetX = cs.laneX;
        return;
    }

    // How long the car will be out on the other line: the run to the obstacle and past it, from a standing start if need be.
    const float runLength = std::min(dOwn, dHere) + 8.0f + 2.0f * cs.baseHs + 6.0f;
    const float passTime = kSignalLead + 2.5f + (-v + std::sqrt(v * v + 2.0f * 1.8f * runLength)) / 1.8f;
    float bestX = cs.laneX, bestCost = 1e9f;
    bool found = false;
    for (int k = 0; k <= 12; ++k) {
        const float x = -kCorridor + 2.0f * kCorridor * static_cast<float>(k) / 12.0f;
        if (std::fabs(x - cs.laneX) < 0.2f && dOwn < react) continue;                   // that line is the blocked one
        if (freeDistance(c, self, x, hz, react * 1.2f) < react) continue;               // must be clear for the reaction distance
        if (!pathClear(c, self, x, hz)) continue;                                       // and so must the way there
        const bool wrongSide = x * cs.laneX < 0.5f;                                      // straddling or in the opposite lane
        if (!laneChangeSafe(c, self, x, hz, wrongSide ? passTime : 0.0f)) continue;
        const float cost = std::fabs(x - cs.laneX) + (wrongSide ? 3.0f : 0.0f) + 0.2f * std::fabs(x - c.x);
        if (cost < bestCost) {
            bestCost = cost;
            bestX = x;
            found = true;
        }
    }
    // Nothing safe: keep the current line - the speed controller brings the car to a stop short of the obstacle (with room left
    // to pull out later) and it waits for a gap.
    cs.waiting = !found;
    if (found) cs.targetX = bestX;
}

}  // namespace

void stepTraffic(std::vector<Obstacle>& obs, const Track& track, float dt, const PlayerRef& player) {
    if (dt <= 0.0f) return;
    std::vector<Hazard> hz;
    hz.reserve(obs.size() + 1);
    for (size_t i = 0; i < obs.size(); ++i) {
        const Obstacle& o = obs[i];
        if (o.hit || o.kind == ObstacleKind::Cone) continue;   // cones are light plastic: drivers do not steer around them
        hz.push_back({o.s, o.x, o.hs, o.hx, o.kind == ObstacleKind::Car ? o.car.dir * o.car.speed : 0.0f, static_cast<int>(i), false});
    }
    if (player.active) hz.push_back({player.s, player.x, 0.6f, 0.55f, player.speed, -1, true});

    for (size_t i = 0; i < obs.size(); ++i) {
        Obstacle& c = obs[i];
        if (c.kind != ObstacleKind::Car) continue;
        CarState& cs = c.car;
        const int self = static_cast<int>(i);

        cs.replanT -= dt;
        if (cs.replanT <= 0.0f) {
            cs.replanT = 0.2f + 0.02f * static_cast<float>(i % 7);
            plan(c, self, hz);
        }

        // ---- speed: Intelligent Driver Model with a curve speed limit
        const float v = cs.speed;
        const TrackSample ahead = track.at(c.s + cs.dir * 18.0f);
        const float curveLimit = std::sqrt(3.0f / std::max(std::fabs(ahead.curvature), 0.0015f));
        const float v0 = std::max(2.0f, std::min(cs.desiredSpeed, curveLimit));
        const float xc = c.x + clampf(cs.vx, -1.5f, 1.5f);
        const Leader lead = leaderOf(c, self, xc, cs.baseHx + 0.3f, hz, std::max(70.0f, v * 7.0f));
        float a = kMaxAccel * (1.0f - std::pow(v / v0, 4.0f));
        if (lead.any) {
            const float dv = v - lead.speed;
            const float stopGap = (cs.waiting && lead.speed < 0.5f) ? kStopGap + 12.0f : kStopGap;
            const float sStar = stopGap + std::max(0.0f, v * cs.timeGap + v * dv / (2.0f * std::sqrt(kMaxAccel * kComfBrake)));
            const float ratio = sStar / std::max(lead.gap, 0.1f);
            a = kMaxAccel * (1.0f - std::pow(v / v0, 4.0f) - ratio * ratio);
        }
        a = clampf(a, -kMaxBrake, kMaxAccel);
        cs.accel += (a - cs.accel) * std::min(1.0f, dt * 8.0f);
        cs.speed = std::max(0.0f, v + a * dt);
        if (cs.speed < 0.2f && a < 0.2f) cs.waitT += dt;
        else cs.waitT = 0.0f;

        // ---- steering: signal first, then glide to the chosen line
        const float dxT = cs.targetX - c.x;
        if (std::fabs(dxT) > 0.35f) {
            cs.signal = (dxT > 0.0f ? 1 : -1) * (cs.dir > 0.0f ? 1 : -1);   // +x is the car's right only when it faces downhill
            cs.signalT += dt;
        } else {
            cs.signal = 0;
            cs.signalT = 0.0f;
        }
        const bool emergency = cs.freeAhead < cs.speed * 1.2f + 4.0f && cs.freeAhead < 18.0f;
        const bool go = cs.signalT > kSignalLead || emergency || std::fabs(dxT) <= 0.35f;
        const float vxMax = std::min(1.9f, 0.4f + 0.18f * cs.speed);
        float desiredVx = go ? clampf(dxT * 0.9f, -vxMax, vxMax) : 0.0f;
        desiredVx *= saturate(cs.speed / 3.0f);                              // no sliding sideways while standing
        // Safety net: never drift toward something the car is level with - wait until it has been passed.
        float vxLo = -99.0f, vxHi = 99.0f;
        for (const Hazard& h : hz) {
            if (h.owner == self) continue;
            if (std::fabs(c.s - h.s) >= c.hs + h.hs + 0.5f) continue;
            const float room = std::fabs(h.x - c.x) - h.hx - cs.baseHx;
            if (room > 0.6f) continue;
            if (h.x > c.x) vxHi = std::min(vxHi, 0.0f);
            else vxLo = std::max(vxLo, 0.0f);
        }
        desiredVx = clampf(desiredVx, vxLo, vxHi);
        cs.vx += clampf(desiredVx - cs.vx, -1.4f * dt, 1.4f * dt);
        cs.vx = clampf(cs.vx, vxLo, vxHi);
        c.x = clampf(c.x + cs.vx * dt, -kCorridor - 0.3f, kCorridor + 0.3f);
        c.s += cs.dir * cs.speed * dt;

        // ---- derived state used by collisions and rendering
        c.vel = cs.dir * cs.speed;
        for (Obstacle& cone : obs) {   // a cone in the way is simply driven over and knocked flying (as for the rider)
            if (cone.kind != ObstacleKind::Cone || cone.hit) continue;
            if (std::fabs(cone.s - c.s) < cone.hs + cs.baseHs && std::fabs(cone.x - c.x) < cone.hx + cs.baseHx) {
                cone.hit = true;
                cone.hitTime = 0.0f;
                cone.knockDir = cone.x >= c.x ? 1.0f : -1.0f;
            }
        }
        const float phi = std::atan2(cs.vx, std::max(cs.speed, 3.0f));      // body angle to the road while changing lane
        const float cphi = std::cos(phi), sphi = std::fabs(std::sin(phi));
        c.hx = cs.baseHx * cphi + cs.baseHs * sphi;
        c.hs = cs.baseHs * cphi + cs.baseHx * sphi;
        c.yaw = (cs.dir < 0.0f ? kPi : 0.0f) + cs.dir * phi;
        const float brakeTarget = cs.accel < -0.6f ? saturate(-cs.accel / 2.5f) : (cs.speed < 0.4f && cs.waitT > 0.2f ? 1.0f : 0.0f);
        cs.brake += (brakeTarget - cs.brake) * std::min(1.0f, dt * 12.0f);
        if (cs.waitT > 25.0f && std::fabs(c.s - player.s) > 130.0f) cs.gone = true;   // a jam nobody can see is simply cleared
        const float diveTarget = saturate(-cs.accel / 6.0f) * 0.04f - saturate(cs.accel / 2.2f) * 0.012f;
        cs.dive += (diveTarget - cs.dive) * std::min(1.0f, dt * 6.0f);
    }
}

}  // namespace sd
