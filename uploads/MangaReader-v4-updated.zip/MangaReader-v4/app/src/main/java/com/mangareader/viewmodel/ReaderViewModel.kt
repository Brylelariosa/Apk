package com.mangareader.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.manager.ProgressManager
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReaderViewModel(app: Application) : AndroidViewModel(app) {

    private val mhtmlParser     = MhtmlParser(app)
    private val progressManager = ProgressManager(app)

    private val _pages   = MutableStateFlow<List<File>>(emptyList())
    val pages: StateFlow<List<File>> = _pages

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error   = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private var currentSeriesId    = ""
    private var currentChapterIdx  = 0

    fun loadChapter(chapter: Chapter, chapterIndex: Int) {
        currentSeriesId   = chapter.seriesId
        currentChapterIdx = chapterIndex

        viewModelScope.launch {
            _loading.value = true
            _error.value   = null
            _pages.value   = emptyList()

            val seriesCacheRoot = File(getApplication<Application>().cacheDir, "manga/${chapter.seriesId}")
            val cacheDir        = File(seriesCacheRoot, chapter.id)

            runCatching {
                withContext(Dispatchers.IO) {
                    // Return cached images if they already exist
                    val cached = if (cacheDir.exists()) {
                        cacheDir.listFiles()
                            ?.filter { it.extension in listOf("jpg", "png", "webp", "gif", "bmp") }
                            ?.sortedBy { it.name }
                            .orEmpty()
                    } else emptyList()

                    if (cached.isNotEmpty()) {
                        // Touch the dir so it counts as "recently read" for pruning below.
                        cacheDir.setLastModified(System.currentTimeMillis())
                        cached
                    } else {
                        val extracted = mhtmlParser.extractImages(chapter.mhtmlPath, cacheDir)
                        pruneOldChapterCache(seriesCacheRoot, cacheDir)
                        extracted
                    }
                }
            }.onSuccess { files ->
                _pages.value = files
                if (files.isEmpty()) _error.value = "No images found in this chapter"
            }.onFailure { e ->
                _error.value = "Failed to load chapter: ${e.message}"
            }

            _loading.value = false
        }
    }

    /**
     * Extracted chapter pages live in the app cache dir and are never cleaned up
     * automatically, so a long reading session across many chapters can quietly
     * build up a large amount of decoded images on disk. Keep only the most
     * recently read chapters per series so storage use stays bounded.
     */
    private fun pruneOldChapterCache(seriesCacheRoot: File, keepDir: File, keep: Int = 3) {
        val dirs = seriesCacheRoot.listFiles()?.filter { it.isDirectory } ?: return
        dirs.sortedByDescending { it.lastModified() }
            .drop(keep)
            .filter { it.absolutePath != keepDir.absolutePath }
            .forEach { it.deleteRecursively() }
    }

    fun saveProgress(pageIndex: Int, scrollOffset: Int = 0) {
        if (currentSeriesId.isEmpty()) return
        progressManager.saveProgress(
            ReadingProgress(
                seriesId     = currentSeriesId,
                chapterIndex = currentChapterIdx,
                pageIndex    = pageIndex,
                scrollOffset = scrollOffset
            )
        )
    }

    fun clearCache(chapter: Chapter) {
        File(
            getApplication<Application>().cacheDir,
            "manga/${chapter.seriesId}/${chapter.id}"
        ).deleteRecursively()
    }
}
