package com.mangareader.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.manager.ProgressManager
import com.mangareader.manager.SettingsManager
import com.mangareader.manager.SettingsManager.SortOrder
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReaderViewModel(app: Application) : AndroidViewModel(app) {

    private val mhtmlParser     = MhtmlParser(app)
    private val progressManager = ProgressManager(app)
    private val settingsManager = SettingsManager(app)

    private val _pages   = MutableStateFlow<List<File>>(emptyList())
    val pages: StateFlow<List<File>> = _pages

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error   = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // ── Reader settings ────────────────────────────────────────────────────────

    private val _scrollSpeed = MutableStateFlow(settingsManager.scrollSpeed)
    val scrollSpeed: StateFlow<Float> = _scrollSpeed

    private val _minImageDimension = MutableStateFlow(settingsManager.minImageDimension)
    val minImageDimension: StateFlow<Int> = _minImageDimension

    private val _sortOrder = MutableStateFlow(settingsManager.sortOrder)
    val sortOrder: StateFlow<SortOrder> = _sortOrder

    // ── Chapter state ──────────────────────────────────────────────────────────

    private var currentSeriesId   = ""
    private var currentChapterIdx = 0

    fun loadChapter(chapter: Chapter, chapterIndex: Int) {
        currentSeriesId   = chapter.seriesId
        currentChapterIdx = chapterIndex

        viewModelScope.launch {
            _loading.value = true
            _error.value   = null
            _pages.value   = emptyList()

            val seriesCacheRoot = File(getApplication<Application>().cacheDir, "manga/${chapter.seriesId}")
            val cacheDir        = File(seriesCacheRoot, chapter.id)

            runCatching {
                withContext(Dispatchers.IO) {
                    val cached = if (cacheDir.exists()) {
                        cacheDir.listFiles()
                            ?.filter { it.extension in listOf("jpg", "png", "webp", "gif", "bmp") }
                            ?.sortedBy { it.name }
                            .orEmpty()
                    } else emptyList()

                    if (cached.isNotEmpty()) {
                        cacheDir.setLastModified(System.currentTimeMillis())
                        cached
                    } else {
                        val extracted = mhtmlParser.extractImages(
                            mhtmlPath         = chapter.mhtmlPath,
                            cacheDir          = cacheDir,
                            minImageDimension = settingsManager.minImageDimension,
                            sortOrder         = settingsManager.sortOrder
                        )
                        pruneOldChapterCache(seriesCacheRoot, cacheDir)
                        extracted
                    }
                }
            }.onSuccess { files ->
                _pages.value = files
                if (files.isEmpty()) _error.value = "No images found in this chapter"
            }.onFailure { e ->
                _error.value = "Failed to load chapter: ${e.message}"
            }

            _loading.value = false
        }
    }

    private fun pruneOldChapterCache(seriesCacheRoot: File, keepDir: File, keep: Int = 3) {
        val dirs = seriesCacheRoot.listFiles()?.filter { it.isDirectory } ?: return
        dirs.sortedByDescending { it.lastModified() }
            .drop(keep)
            .filter { it.absolutePath != keepDir.absolutePath }
            .forEach { it.deleteRecursively() }
    }

    fun saveProgress(pageIndex: Int, scrollOffset: Int = 0) {
        if (currentSeriesId.isEmpty()) return
        progressManager.saveProgress(
            ReadingProgress(
                seriesId     = currentSeriesId,
                chapterIndex = currentChapterIdx,
                pageIndex    = pageIndex,
                scrollOffset = scrollOffset
            )
        )
    }

    fun clearCache(chapter: Chapter) {
        File(
            getApplication<Application>().cacheDir,
            "manga/${chapter.seriesId}/${chapter.id}"
        ).deleteRecursively()
    }

    // ── Settings mutators ──────────────────────────────────────────────────────

    fun setScrollSpeed(value: Float) {
        settingsManager.scrollSpeed = value
        _scrollSpeed.value = value
    }

    fun setMinImageDimension(value: Int) {
        settingsManager.minImageDimension = value
        _minImageDimension.value = value
    }

    fun setSortOrder(value: SortOrder) {
        settingsManager.sortOrder = value
        _sortOrder.value = value
    }
}
