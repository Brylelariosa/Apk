package com.mangareader.parser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader

/**
 * Parses MHTML files and extracts embedded images to a cache directory.
 *
 * MHTML stores images as base64-encoded MIME parts separated by a boundary string.
 * We read the file with ISO-8859-1 so byte values are preserved in the char range,
 * then walk it line-by-line, decoding each part's base64 body.
 *
 * COMPATIBILITY ACROSS SITES
 * Different sites/browsers/save-tools produce MHTML that differs in small but
 * breaking ways: some omit "base64" from the Content-Transfer-Encoding header,
 * some use unusual header spacing/casing, and page filenames don't all follow
 * the same "-NNN.ext" numbering convention (some have no number at all). A
 * parser hard-coded to one site's exact format silently drops every image on
 * a differently-formatted file. To stay robust across sources, this version:
 *   - Decides whether a MIME part is "worth trying" with a small denylist
 *     (skip obvious text/css/js/font parts) instead of a strict image/base64
 *     allowlist, so it doesn't matter how a particular site labels its parts.
 *   - Confirms what a part actually is by sniffing the decoded bytes' magic
 *     numbers (JPEG/PNG/GIF/WEBP/BMP) rather than trusting the Content-Type
 *     header for the file extension.
 *   - Tries to recover the page number from the Content-Location URL with a
 *     more general pattern (any trailing digits, not just "-NNN"), and falls
 *     back to plain file-encounter order for chapters where no usable page
 *     numbers can be found at all, instead of dropping those images.
 *
 * MEMORY
 * Chapters can contain many tens of megabytes of base64 text once you have a
 * couple dozen high-resolution pages. Reading the *entire* file into one big
 * String and splitting it into a part-per-image list (the old approach) means
 * the whole chapter sits in memory two or three times over - an easy way to
 * OOM on a phone. This version streams the file line-by-line and only ever
 * holds ONE MIME part's body in memory at a time, so peak memory is roughly
 * "one page's worth of base64 text" instead of "the whole chapter".
 */
class MhtmlParser(private val context: Context) {

    private val boundaryRegex = Regex("""boundary=["']?([^"'\r\n;]+)["']?""", RegexOption.IGNORE_CASE)

    // Parts whose Content-Type unambiguously means "not an image" are skipped
    // before we even bother accumulating their body. Everything else is given
    // the benefit of the doubt and verified later by sniffing the actual bytes.
    private val nonImageContentTypeHints = listOf(
        "text/", "application/javascript", "application/x-javascript",
        "application/json", "font/", "application/font", "application/x-font"
    )

    // -- Public API: extract every page of a chapter into cacheDir ---------------

    fun extractImages(mhtmlPath: String, cacheDir: File): List<File> {
        return try {
            openStream(mhtmlPath)?.use { extractImages(it, cacheDir) } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun extractImages(inputStream: InputStream, cacheDir: File): List<File> {
        cacheDir.mkdirs()

        data class Pending(val file: File, val pageNum: Int?, val order: Int)
        val pending = mutableListOf<Pending>()
        var encounterIndex = 0

        try {
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024)
            val boundary = findBoundary(reader) ?: return emptyList()
            val delimiter = "--$boundary"

            val headerBuilder = StringBuilder()
            val bodyBuilder = StringBuilder()
            var inBody = false
            var isImagePart = false
            var pageNum: Int? = null

            fun flush() {
                if (isImagePart && bodyBuilder.isNotEmpty()) {
                    try {
                        val bytes = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                        val ext = sniffImageExt(bytes)
                        if (ext != null && bytes.size > 200) {
                            val tmp = File(cacheDir, "tmp_$encounterIndex.$ext")
                            tmp.writeBytes(bytes)
                            pending.add(Pending(tmp, pageNum, encounterIndex))
                            encounterIndex++
                        }
                    } catch (_: Exception) {
                        // Not actually decodable base64 image data - skip it.
                    }
                }
            }

            fun reset() {
                headerBuilder.setLength(0)
                bodyBuilder.setLength(0)
                inBody = false
                isImagePart = false
                pageNum = null
            }

            var line: String?
            while (true) {
                line = reader.readLine() ?: break
                val l = line!!

                if (l.startsWith(delimiter)) {
                    flush()
                    reset()
                    if (l.startsWith("$delimiter--")) break
                    continue
                }

                if (!inBody) {
                    if (l.isEmpty()) {
                        inBody = true
                        isImagePart = isLikelyImagePart(headerBuilder)
                        if (isImagePart) {
                            val contentUrl = headerBuilder.lineSequence()
                                .firstOrNull { it.contains("content-location", ignoreCase = true) }
                                ?.substringAfter(':', "")
                                ?.trim()
                                .orEmpty()
                            pageNum = extractPageNumber(contentUrl)
                        }
                    } else {
                        headerBuilder.append(l).append('\n')
                    }
                } else if (isImagePart) {
                    // Only parts we might actually keep accumulate body text -
                    // everything else is dropped line-by-line instead of being
                    // held in memory for the whole file.
                    bodyBuilder.append(l)
                }
            }
            flush()
        } catch (e: Exception) {
            e.printStackTrace()
            // Fall through with whatever was successfully decoded before the
            // error instead of discarding a partially-read chapter entirely.
        }

        if (pending.isEmpty()) return emptyList()

        // If we recovered real page numbers for most images, trust them (with any
        // un-numbered stragglers pushed to the end). Otherwise - a site whose
        // image URLs don't carry a usable page number at all - fall back to the
        // order the images were encountered in the file.
        val numberedCount = pending.count { it.pageNum != null }
        val ordered = if (numberedCount > 0 && numberedCount >= pending.size / 2) {
            pending.sortedWith(compareBy({ it.pageNum == null }, { it.pageNum ?: 0 }, { it.order }))
        } else {
            pending.sortedBy { it.order }
        }

        // Rename into final, cleanly-sortable filenames so a future cache hit
        // (which just re-sorts the cache directory alphabetically) reproduces
        // this exact order without needing to re-parse anything.
        return ordered.mapIndexedNotNull { i, p ->
            val target = File(cacheDir, "page_${(i + 1).toString().padStart(4, '0')}.${p.file.extension}")
            if (p.file.renameTo(target)) target else null
        }
    }

    // -- Public API: grab just the first valid page, for library thumbnails ------

    /**
     * Decodes only the first usable page found in a chapter and writes a small
     * downsampled JPEG thumbnail to [outFile]. Stops reading the source as soon
     * as one valid image has been found, and never holds a full-resolution
     * bitmap of more than one page in memory.
     */
    fun extractFirstPageThumbnail(mhtmlPath: String, outFile: File, maxDimension: Int = 480): Boolean {
        val bytes = try {
            openStream(mhtmlPath)?.use { extractFirstPageBytes(it) }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        } ?: return false

        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth / (sample * 2) >= maxDimension ||
                bounds.outHeight / (sample * 2) >= maxDimension
            ) {
                sample *= 2
            }

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false

            outFile.parentFile?.mkdirs()
            FileOutputStream(outFile).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out) }
            bitmap.recycle()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun extractFirstPageBytes(inputStream: InputStream): ByteArray? {
        val reader = BufferedReader(InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024)
        val boundary = findBoundary(reader) ?: return null
        val delimiter = "--$boundary"

        val headerBuilder = StringBuilder()
        val bodyBuilder = StringBuilder()
        var inBody = false
        var isImagePart = false

        fun tryDecodeCurrent(): ByteArray? {
            if (!isImagePart || bodyBuilder.isEmpty()) return null
            return try {
                val bytes = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                if (bytes.size > 200 && sniffImageExt(bytes) != null) bytes else null
            } catch (_: Exception) {
                null
            }
        }

        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            val l = line!!

            if (l.startsWith(delimiter)) {
                tryDecodeCurrent()?.let { return it }
                headerBuilder.setLength(0)
                bodyBuilder.setLength(0)
                inBody = false
                isImagePart = false
                if (l.startsWith("$delimiter--")) return null
                continue
            }

            if (!inBody) {
                if (l.isEmpty()) {
                    inBody = true
                    isImagePart = isLikelyImagePart(headerBuilder)
                } else {
                    headerBuilder.append(l).append('\n')
                }
            } else if (isImagePart) {
                bodyBuilder.append(l)
            }
        }
        return tryDecodeCurrent()
    }

    // -- Shared helpers ------------------------------------------------------------

    private fun openStream(path: String): InputStream? =
        if (path.startsWith("content://")) {
            context.contentResolver.openInputStream(Uri.parse(path))
        } else {
            File(path).inputStream()
        }

    /** Reads just enough of the header preamble to find the MIME boundary string. */
    private fun findBoundary(reader: BufferedReader): String? {
        val peek = StringBuilder()
        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            peek.append(line).append('\n')
            boundaryRegex.find(peek)?.let { return it.groupValues[1].trim() }
            if (peek.length > 8192) break
        }
        return null
    }

    private fun isLikelyImagePart(headers: CharSequence): Boolean {
        val ctLine = headers.lineSequence()
            .firstOrNull { it.contains("content-type", ignoreCase = true) }
            ?.lowercase()
            ?: return true // no Content-Type at all - give it the benefit of the doubt
        return nonImageContentTypeHints.none { ctLine.contains(it) }
    }

    /** Looks for a page number in a Content-Location URL, trying a couple of conventions. */
    private fun extractPageNumber(rawUrl: String): Int? {
        if (rawUrl.isBlank()) return null
        val clean = rawUrl.substringBefore('?').substringBefore('#')
        val fileName = clean.substringAfterLast('/')

        // Digits immediately before the extension: "page-007.jpg", "007.png", "img007.webp"
        Regex("""(\d+)\.\w+$""").find(fileName)?.let { return it.groupValues[1].toIntOrNull() }
        // Fallback: any trailing digit run near the end of the filename.
        Regex("""(\d+)\D*$""").find(fileName)?.let { return it.groupValues[1].toIntOrNull() }
        return null
    }

    /** Identifies an image format from its magic bytes rather than trusting headers. */
    private fun sniffImageExt(bytes: ByteArray): String? {
        if (bytes.size < 12) return null
        return when {
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
                bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "png"
            bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() && bytes[2] == 0x46.toByte() -> "gif"
            bytes[0] == 0x52.toByte() && bytes[1] == 0x49.toByte() &&
                bytes[2] == 0x46.toByte() && bytes[3] == 0x46.toByte() &&
                bytes[8] == 0x57.toByte() && bytes[9] == 0x45.toByte() &&
                bytes[10] == 0x42.toByte() && bytes[11] == 0x50.toByte() -> "webp"
            bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte() -> "bmp"
            else -> null
        }
    }
}
