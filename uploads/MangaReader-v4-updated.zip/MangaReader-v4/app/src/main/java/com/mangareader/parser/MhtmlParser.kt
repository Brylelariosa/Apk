package com.mangareader.parser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.mangareader.manager.SettingsManager.SortOrder
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader

/**
 * Parses MHTML files and extracts embedded images to a cache directory.
 *
 * PAGE ORDERING
 * Getting page order right across different manga sites is the trickiest part
 * of MHTML parsing. Three strategies are supported via [SortOrder]:
 *
 *  ENCOUNTER — images in the order they appear in the saved file. MHTML files
 *    produced by a browser save-page operation store assets in DOM order, which
 *    is usually reading order. This is the safest fallback.
 *
 *  URL_PAGE — sort by the number found in each image's Content-Location URL.
 *    Works well when URLs look like "page-007.jpg" or "_0042.webp", but breaks
 *    when the number in the URL is a chapter ID, timestamp, or hash rather than
 *    a page index.
 *
 *  AUTO (default) — try URL_PAGE, but only trust the result when the extracted
 *    numbers look sequential (no gap > 10 between adjacent pages, all values
 *    below 2 000). If the numbers fail the sanity check, fall back to ENCOUNTER.
 *    This handles the majority of sites automatically.
 *
 * URL PAGE-NUMBER EXTRACTION
 * The regex pipeline tries increasingly general patterns in priority order so
 * that explicit "page-N" keywords win over bare trailing digits:
 *  1. "page" / "pg" keyword  — page-007.jpg, pg_3.png
 *  2. Underscore + zero-padded digits — _001.jpg, _0042.webp  (zero-padding
 *     is a strong signal that the number is a page index, not a content ID)
 *  3. Any number before the extension, capped at 2 000 to ignore timestamps
 *     and hash-like filenames (e.g. "1712345678.jpg")
 *
 * NOISE FILTERING
 * [minImageDimension] sets a pixel-dimension floor. Images whose width OR
 * height is below the threshold are dropped using a fast header-only decode
 * (BitmapFactory inJustDecodeBounds) so no pixel data is ever allocated for
 * rejected images.
 *
 * MEMORY
 * The file is streamed line-by-line; only one MIME part's body is held in
 * memory at a time (roughly one page's worth of base64 text).
 */
class MhtmlParser(private val context: Context) {

    private val boundaryRegex = Regex("""boundary=["']?([^"'\r\n;]+)["']?""", RegexOption.IGNORE_CASE)

    private val nonImageContentTypeHints = listOf(
        "text/", "application/javascript", "application/x-javascript",
        "application/json", "font/", "application/font", "application/x-font"
    )

    // ── Public API ─────────────────────────────────────────────────────────────

    fun extractImages(
        mhtmlPath: String,
        cacheDir: File,
        minImageDimension: Int = 120,
        sortOrder: SortOrder = SortOrder.AUTO
    ): List<File> {
        return try {
            openStream(mhtmlPath)?.use {
                extractImages(it, cacheDir, minImageDimension, sortOrder)
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun extractImages(
        inputStream: InputStream,
        cacheDir: File,
        minImageDimension: Int = 120,
        sortOrder: SortOrder = SortOrder.AUTO
    ): List<File> {
        cacheDir.mkdirs()

        data class Pending(val file: File, val pageNum: Int?, val order: Int)
        val pending = mutableListOf<Pending>()
        var encounterIndex = 0

        try {
            val reader = BufferedReader(
                InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024
            )
            val boundary = findBoundary(reader) ?: return emptyList()
            val delimiter = "--$boundary"

            val headerBuilder = StringBuilder()
            val bodyBuilder   = StringBuilder()
            var inBody        = false
            var isImagePart   = false
            var pageNum: Int? = null

            fun flush() {
                if (!isImagePart || bodyBuilder.isEmpty()) return
                try {
                    val bytes = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                    val ext   = sniffImageExt(bytes) ?: return
                    if (bytes.size <= 200) return

                    // Dimension gate — fast header-only decode, no pixel allocation
                    if (minImageDimension > 0) {
                        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (opts.outWidth  < minImageDimension ||
                            opts.outHeight < minImageDimension) return
                    }

                    val tmp = File(cacheDir, "tmp_$encounterIndex.$ext")
                    tmp.writeBytes(bytes)
                    pending.add(Pending(tmp, pageNum, encounterIndex))
                    encounterIndex++
                } catch (_: Exception) { /* corrupt / non-image part — skip */ }
            }

            fun reset() {
                headerBuilder.setLength(0)
                bodyBuilder.setLength(0)
                inBody      = false
                isImagePart = false
                pageNum     = null
            }

            var line: String?
            while (true) {
                line = reader.readLine() ?: break
                val l = line!!

                if (l.startsWith(delimiter)) {
                    flush(); reset()
                    if (l.startsWith("$delimiter--")) break
                    continue
                }

                if (!inBody) {
                    if (l.isEmpty()) {
                        inBody      = true
                        isImagePart = isLikelyImagePart(headerBuilder)
                        if (isImagePart) {
                            val url = headerBuilder.lineSequence()
                                .firstOrNull { it.contains("content-location", ignoreCase = true) }
                                ?.substringAfter(':')?.trim().orEmpty()
                            pageNum = extractPageNumber(url)
                        }
                    } else {
                        headerBuilder.append(l).append('\n')
                    }
                } else if (isImagePart) {
                    bodyBuilder.append(l)
                }
            }
            flush()

        } catch (e: Exception) {
            e.printStackTrace()
            // Return whatever was successfully decoded before the error
        }

        if (pending.isEmpty()) return emptyList()

        val ordered = when (sortOrder) {
            // ── ENCOUNTER: trust the file order ───────────────────────────────
            SortOrder.ENCOUNTER -> pending.sortedBy { it.order }

            // ── URL_PAGE: always sort by extracted number ──────────────────────
            SortOrder.URL_PAGE  -> pending.sortedWith(
                compareBy({ it.pageNum == null }, { it.pageNum ?: Int.MAX_VALUE }, { it.order })
            )

            // ── AUTO: use URL numbers only when they look sequential ───────────
            SortOrder.AUTO -> {
                val numbered = pending.filter { it.pageNum != null }
                    .sortedBy { it.pageNum }

                // "Sequential" means:
                //  - at least 2 images have a parseable number
                //  - those numbers cover at least half the images
                //  - no gap between adjacent pages exceeds 10
                //    (a gap of 11 would mean an unexpected jump; probably a
                //    chapter number or content-ID, not a real page index)
                val reliable = numbered.size >= 2 &&
                    numbered.size >= pending.size / 2 &&
                    numbered.zipWithNext().all { (a, b) ->
                        (b.pageNum!! - a.pageNum!!) <= 10
                    }

                if (reliable) {
                    pending.sortedWith(
                        compareBy({ it.pageNum == null }, { it.pageNum ?: Int.MAX_VALUE }, { it.order })
                    )
                } else {
                    // Numbers don't look trustworthy — encounter order is safer
                    pending.sortedBy { it.order }
                }
            }
        }

        // Rename to cleanly-sortable final filenames so cache reloads reproduce
        // this exact order without re-parsing the MHTML.
        return ordered.mapIndexedNotNull { i, p ->
            val target = File(
                cacheDir,
                "page_${(i + 1).toString().padStart(4, '0')}.${p.file.extension}"
            )
            if (p.file.renameTo(target)) target else null
        }
    }

    // ── Thumbnail (library covers) ─────────────────────────────────────────────

    /**
     * Decodes only the first usable image and writes a downsampled JPEG to
     * [outFile]. Stops as soon as one valid page is found.
     * minImageDimension is intentionally NOT applied here — covers should never
     * be blank even on sites with small-image noise.
     */
    fun extractFirstPageThumbnail(
        mhtmlPath: String,
        outFile: File,
        maxDimension: Int = 480
    ): Boolean {
        val bytes = try {
            openStream(mhtmlPath)?.use { extractFirstPageBytes(it) }
        } catch (e: Exception) {
            e.printStackTrace(); null
        } ?: return false

        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth  / (sample * 2) >= maxDimension ||
                   bounds.outHeight / (sample * 2) >= maxDimension) sample *= 2

            val opts   = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return false

            outFile.parentFile?.mkdirs()
            FileOutputStream(outFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
            }
            bitmap.recycle()
            true
        } catch (e: Exception) {
            e.printStackTrace(); false
        }
    }

    private fun extractFirstPageBytes(inputStream: InputStream): ByteArray? {
        val reader = BufferedReader(
            InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024
        )
        val boundary = findBoundary(reader) ?: return null
        val delimiter = "--$boundary"

        val headerBuilder = StringBuilder()
        val bodyBuilder   = StringBuilder()
        var inBody        = false
        var isImagePart   = false

        fun tryDecode(): ByteArray? {
            if (!isImagePart || bodyBuilder.isEmpty()) return null
            return try {
                val bytes = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                if (bytes.size > 200 && sniffImageExt(bytes) != null) bytes else null
            } catch (_: Exception) { null }
        }

        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            val l = line!!
            if (l.startsWith(delimiter)) {
                tryDecode()?.let { return it }
                headerBuilder.setLength(0); bodyBuilder.setLength(0)
                inBody = false; isImagePart = false
                if (l.startsWith("$delimiter--")) return null
                continue
            }
            if (!inBody) {
                if (l.isEmpty()) { inBody = true; isImagePart = isLikelyImagePart(headerBuilder) }
                else headerBuilder.append(l).append('\n')
            } else if (isImagePart) {
                bodyBuilder.append(l)
            }
        }
        return tryDecode()
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun openStream(path: String): InputStream? =
        if (path.startsWith("content://"))
            context.contentResolver.openInputStream(Uri.parse(path))
        else
            File(path).inputStream()

    private fun findBoundary(reader: BufferedReader): String? {
        val peek = StringBuilder()
        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            peek.append(line).append('\n')
            boundaryRegex.find(peek)?.let { return it.groupValues[1].trim() }
            if (peek.length > 8192) break
        }
        return null
    }

    private fun isLikelyImagePart(headers: CharSequence): Boolean {
        val ct = headers.lineSequence()
            .firstOrNull { it.contains("content-type", ignoreCase = true) }
            ?.lowercase() ?: return true
        return nonImageContentTypeHints.none { ct.contains(it) }
    }

    /**
     * Extracts a page number from a Content-Location URL using a priority
     * pipeline that prefers specific/explicit patterns over bare digits.
     *
     *  1. "page"/"pg" keyword   → page-007.jpg, pg_3.png
     *  2. Underscore + zero-pad → _001.jpg, _0042.webp
     *     Zero-padding is a strong signal: content hashes and timestamps are
     *     never zero-padded; page indices almost always are.
     *  3. Bare digits before extension, capped at 2 000 to reject timestamps
     *     and random-looking numeric filenames that could be CDN content IDs.
     *
     * Returns null when no plausible page number can be found; the caller then
     * treats this image as "unnumbered" and either keeps encounter order or
     * appends it at the end of a URL-sorted list.
     */
    private fun extractPageNumber(rawUrl: String): Int? {
        if (rawUrl.isBlank()) return null
        val fileName = rawUrl.substringBefore('?').substringBefore('#')
            .substringAfterLast('/')

        // 1. Explicit page/pg keyword
        Regex("""(?:page|pg)[_\-]?0*(\d+)""", RegexOption.IGNORE_CASE)
            .find(fileName)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }

        // 2. Underscore-prefixed zero-padded number before extension
        Regex("""_0*(\d{1,4})\.\w{2,5}$""")
            .find(fileName)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }

        // 3. Bare number before extension — cap at 2 000 to filter timestamps/hashes
        val raw = Regex("""(\d+)\.\w{2,5}$""")
            .find(fileName)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        return if (raw <= 2000) raw else null
    }

    private fun sniffImageExt(bytes: ByteArray): String? {
        if (bytes.size < 12) return null
        return when {
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "png"
            bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte()                               -> "gif"
            bytes[0] == 0x52.toByte() && bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte() && bytes[3] == 0x46.toByte() &&
            bytes[8] == 0x57.toByte() && bytes[9] == 0x45.toByte() &&
            bytes[10] == 0x42.toByte()&& bytes[11] == 0x50.toByte() -> "webp"
            bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte() -> "bmp"
            else -> null
        }
    }
}
