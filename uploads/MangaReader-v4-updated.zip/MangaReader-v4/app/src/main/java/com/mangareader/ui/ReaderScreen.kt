package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingMode
import com.mangareader.data.ReadingProgress
import com.mangareader.manager.SettingsManager.SortOrder
import com.mangareader.viewmodel.ReaderViewModel
import java.io.File
import kotlin.math.roundToInt

private val BAR_BG = Color.Black.copy(alpha = 0.78f)

@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    chapter: Chapter,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    initialProgress: ReadingProgress?,
    onBack: () -> Unit,
    onChapterChange: (Chapter, Int) -> Unit
) {
    BackHandler { onBack() }

    val pages       by viewModel.pages.collectAsStateWithLifecycle()
    val loading     by viewModel.loading.collectAsStateWithLifecycle()
    val error       by viewModel.error.collectAsStateWithLifecycle()
    val scrollSpeed by viewModel.scrollSpeed.collectAsStateWithLifecycle()
    val minDim      by viewModel.minImageDimension.collectAsStateWithLifecycle()
    val sortOrder   by viewModel.sortOrder.collectAsStateWithLifecycle()
    val readingMode by viewModel.readingMode.collectAsStateWithLifecycle()

    // Reset list position whenever chapter changes
    val listState = remember(chapter.id) { LazyListState() }

    var showControls by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    // Resolve which chapter index had saved progress
    val savedChapterMatches = remember(initialProgress, chapter.id, chapterIndex) {
        initialProgress?.chapterId == chapter.id ||
            (initialProgress?.chapterId == null && initialProgress?.chapterIndex == chapterIndex)
    }

    LaunchedEffect(chapter.id) {
        viewModel.loadChapter(chapter, chapterIndex, allChapters)
    }

    // Restore scroll position once pages load
    var scrollRestored by remember(chapter.id) { mutableStateOf(false) }
    LaunchedEffect(pages.size) {
        if (pages.isNotEmpty() && !scrollRestored && savedChapterMatches) {
            scrollRestored = true
            val target = initialProgress!!.pageIndex.coerceIn(0, pages.size - 1)
            listState.scrollToItem(target, initialProgress.scrollOffset)
        } else if (pages.isNotEmpty()) {
            scrollRestored = true
        }
    }

    // Auto-save progress as user scrolls
    val firstVisible      = listState.firstVisibleItemIndex
    val firstVisibleOffset = listState.firstVisibleItemScrollOffset
    LaunchedEffect(firstVisible, firstVisibleOffset) {
        if (pages.isNotEmpty()) {
            viewModel.saveProgress(firstVisible, firstVisibleOffset)
            // Auto mark as read when the last page is fully visible
            if (firstVisible >= pages.size - 1) {
                viewModel.onLastPageReached()
            }
        }
    }

    if (showSettings) {
        ReaderSettingsDialog(
            scrollSpeed   = scrollSpeed,
            minImageDim   = minDim,
            sortOrder     = sortOrder,
            readingMode   = readingMode,
            onScrollSpeed = { viewModel.setScrollSpeed(it) },
            onMinImageDim = { viewModel.setMinImageDimension(it) },
            onSortOrder   = { viewModel.setSortOrder(it) },
            onReadingMode = { viewModel.setReadingMode(it) },
            onReload      = { viewModel.reloadChapter(); showSettings = false },
            onDismiss     = { showSettings = false }
        )
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            loading -> LoadingState()
            error != null -> ErrorState(
                message = error!!,
                onRetry = { viewModel.loadChapter(chapter, chapterIndex, allChapters) }
            )
            pages.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("No images found", color = Color.White.copy(alpha = 0.6f))
            }
            else -> {
                when (readingMode) {
                    ReadingMode.HORIZONTAL -> HorizontalReader(
                        pages        = pages,
                        chapterIndex = chapterIndex,
                        allChapters  = allChapters,
                        initialPage  = if (savedChapterMatches) initialProgress?.pageIndex ?: 0 else 0,
                        onTap        = { showControls = !showControls },
                        onProgress   = { page -> viewModel.saveProgress(page) },
                        onLastPage   = { viewModel.onLastPageReached() },
                        onPrev = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                        onNext = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) }
                    )
                    else -> VerticalReader(
                        pages        = pages,
                        listState    = listState,
                        scrollSpeed  = scrollSpeed,
                        webtoonMode  = readingMode == ReadingMode.WEBTOON,
                        chapterIndex = chapterIndex,
                        allChapters  = allChapters,
                        onTap        = { showControls = !showControls },
                        onPrev = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                        onNext = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) }
                    )
                }

                // Reading progress bar (top edge)
                if (pages.isNotEmpty() && readingMode != ReadingMode.HORIZONTAL) {
                    val fraction = (firstVisible + 1).toFloat() / pages.size
                    LinearProgressIndicator(
                        progress   = { fraction.coerceIn(0f, 1f) },
                        modifier   = Modifier.fillMaxWidth().height(2.dp).align(Alignment.TopCenter),
                        color      = MaterialTheme.colorScheme.primary,
                        trackColor = Color.White.copy(alpha = 0.1f)
                    )
                }

                // Overlay controls
                AnimatedVisibility(
                    visible = showControls,
                    enter   = fadeIn(),
                    exit    = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        ReaderTopBar(
                            chapter       = chapter,
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            currentPage   = firstVisible + 1,
                            totalPages    = pages.size,
                            onBack        = onBack,
                            onSettings    = { showSettings = true },
                            modifier      = Modifier.align(Alignment.TopCenter)
                        )
                        ReaderBottomBar(
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            onPrev = { val i = chapterIndex-1; onChapterChange(allChapters[i], i) },
                            onNext = { val i = chapterIndex+1; onChapterChange(allChapters[i], i) },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }
        }
    }
}

// ── Vertical / Webtoon reader ──────────────────────────────────────────────────

@Composable
private fun VerticalReader(
    pages: List<File>,
    listState: LazyListState,
    scrollSpeed: Float,
    webtoonMode: Boolean,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    onTap: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    LazyColumn(
        state         = listState,
        flingBehavior = rememberMomentumFlingBehavior(scrollSpeed),
        modifier      = Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { onTap() } }
    ) {
        itemsIndexed(pages, key = { _, f -> f.absolutePath }) { _, file ->
            ZoomableMangaPage(
                file    = file,
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .then(if (webtoonMode) Modifier else Modifier.padding(bottom = 2.dp))
            )
        }
        item(key = "footer") {
            ChapterFooter(chapterIndex, allChapters.size, onPrev, onNext)
        }
    }
}

// ── Horizontal (pager) reader ──────────────────────────────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HorizontalReader(
    pages: List<File>,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    initialPage: Int,
    onTap: () -> Unit,
    onProgress: (Int) -> Unit,
    onLastPage: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val pagerState = rememberPagerState(
        initialPage  = initialPage.coerceIn(0, pages.size - 1),
        pageCount    = { pages.size }
    )

    LaunchedEffect(pagerState.currentPage) {
        onProgress(pagerState.currentPage)
        if (pagerState.currentPage >= pages.size - 1) onLastPage()
    }

    Box(Modifier.fillMaxSize()) {
        HorizontalPager(
            state    = pagerState,
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { onTap() } }
        ) { page ->
            ZoomableMangaPage(
                file     = pages[page],
                modifier = Modifier.fillMaxSize()
            )
        }

        // Chapter nav when at last page
        if (pagerState.currentPage >= pages.size - 1 && allChapters.size > chapterIndex + 1) {
            Box(Modifier.align(Alignment.BottomCenter).padding(24.dp)) {
                Button(onClick = onNext) {
                    Icon(Icons.Default.NavigateNext, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Next Chapter")
                }
            }
        }

        // Page indicator dots
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 60.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            val fraction = (pagerState.currentPage + 1).toFloat() / pages.size
            LinearProgressIndicator(
                progress   = { fraction },
                modifier   = Modifier.fillMaxWidth(0.6f).height(2.dp),
                color      = MaterialTheme.colorScheme.primary,
                trackColor = Color.White.copy(alpha = 0.2f)
            )
        }
    }
}

// ── Zoomable manga page ────────────────────────────────────────────────────────

/**
 * A manga page that supports pinch-to-zoom (1×–4×) and pan while zoomed.
 * Double-tap toggles between 1× and 2×.  When scale == 1× the gesture
 * pass-through allows the parent LazyColumn to handle scrolling normally;
 * at higher scales pan is handled locally.
 */
@Composable
private fun ZoomableMangaPage(file: File, modifier: Modifier) {
    var scale  by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        val newScale = (scale * zoomChange).coerceIn(1f, 4f)
        scale  = newScale
        offset = if (newScale > 1f) offset + panChange else Offset.Zero
    }

    SubcomposeAsyncImage(
        model              = file,
        contentDescription = null,
        contentScale       = ContentScale.FillWidth,
        modifier           = modifier
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        scale  = if (scale > 1f) 1f else 2f
                        offset = Offset.Zero
                    }
                )
            }
            .transformable(state = transformState)
            .graphicsLayer {
                scaleX       = scale
                scaleY       = scale
                translationX = offset.x
                translationY = offset.y
            },
        loading = {
            Box(
                Modifier.fillMaxWidth().aspectRatio(0.7f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color       = Color.White.copy(alpha = 0.5f),
                    modifier    = Modifier.size(32.dp),
                    strokeWidth = 2.dp
                )
            }
        },
        error = {
            Box(
                Modifier.fillMaxWidth().height(80.dp).background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Text("Page failed to load",
                    color = Color.White.copy(alpha = 0.4f),
                    style = MaterialTheme.typography.labelSmall)
            }
        }
    )
}

// ── Settings dialog ────────────────────────────────────────────────────────────

@Composable
private fun ReaderSettingsDialog(
    scrollSpeed: Float,
    minImageDim: Int,
    sortOrder: SortOrder,
    readingMode: ReadingMode,
    onScrollSpeed: (Float) -> Unit,
    onMinImageDim: (Int) -> Unit,
    onSortOrder: (SortOrder) -> Unit,
    onReadingMode: (ReadingMode) -> Unit,
    onReload: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest  = onDismiss,
        containerColor    = Color(0xFF1C1340),
        titleContentColor = Color.White,
        title = { Text("Reader Settings", style = MaterialTheme.typography.titleMedium) },
        text  = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // ── Reading mode ──────────────────────────────────────────────
                SettingLabel("Reading Mode")
                Column(Modifier.selectableGroup()) {
                    ReadingMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(selected = readingMode == mode,
                                    role = Role.RadioButton,
                                    onClick = { onReadingMode(mode) })
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = readingMode == mode, onClick = null,
                                colors   = RadioButtonDefaults.colors(
                                    selectedColor   = MaterialTheme.colorScheme.primary,
                                    unselectedColor = Color.White.copy(alpha = 0.4f)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(mode.label(), color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium)
                                Text(mode.hint(), color = Color.White.copy(alpha = 0.42f),
                                    style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // ── Scroll speed ──────────────────────────────────────────────
                SettingRow("Scroll Speed", "%.1fx".format(scrollSpeed))
                Slider(value = scrollSpeed, onValueChange = onScrollSpeed,
                    valueRange = 0.8f..3.0f, steps = 10, colors = sliderColors())
                SettingHint("How far pages travel after a flick. 1.0× = stock.")

                Spacer(Modifier.height(8.dp))

                // ── Image filter ──────────────────────────────────────────────
                SettingRow("Image Filter",
                    if (minImageDim == 0) "Off" else "${minImageDim}px min")
                Slider(value = minImageDim.toFloat(),
                    onValueChange = { onMinImageDim(it.roundToInt()) },
                    valueRange = 0f..800f, steps = 7, colors = sliderColors())
                SettingHint("Hides images smaller than this (site icons, banners). " +
                    "Recommended: 200–400px. Takes effect after reload.")

                Spacer(Modifier.height(8.dp))

                // ── Page order ────────────────────────────────────────────────
                SettingLabel("Page Order")
                Column(Modifier.selectableGroup()) {
                    data class Opt(val o: SortOrder, val label: String, val hint: String)
                    listOf(
                        Opt(SortOrder.AUTO,      "Auto",       "Detect from HTML structure (recommended)."),
                        Opt(SortOrder.ENCOUNTER, "File Order", "Use MHTML encounter order."),
                        Opt(SortOrder.URL_PAGE,  "URL Number", "Sort by number in image URL.")
                    ).forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(selected = sortOrder == opt.o,
                                    role = Role.RadioButton,
                                    onClick = { onSortOrder(opt.o) })
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            RadioButton(
                                selected = sortOrder == opt.o, onClick = null,
                                colors   = RadioButtonDefaults.colors(
                                    selectedColor   = MaterialTheme.colorScheme.primary,
                                    unselectedColor = Color.White.copy(alpha = 0.4f)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(opt.label, color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium)
                                Text(opt.hint, color = Color.White.copy(alpha = 0.42f),
                                    style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick  = onReload,
                    modifier = Modifier.fillMaxWidth(),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Refresh, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Reload chapter from file")
                }
                TextButton(
                    onClick  = onDismiss,
                    modifier = Modifier.align(Alignment.End),
                    colors   = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary)
                ) { Text("Done") }
            }
        }
    )
}

// ── Shared helpers ─────────────────────────────────────────────────────────────

@Composable private fun SettingLabel(text: String) {
    Text(text, color = Color.White, style = MaterialTheme.typography.titleSmall)
}
@Composable private fun SettingRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, color = Color.White, style = MaterialTheme.typography.titleSmall)
        Text(value, color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.titleSmall)
    }
}
@Composable private fun SettingHint(text: String) =
    Text(text, style = MaterialTheme.typography.labelSmall,
        color = Color.White.copy(alpha = 0.42f))

@Composable private fun sliderColors() = SliderDefaults.colors(
    thumbColor       = MaterialTheme.colorScheme.primary,
    activeTrackColor = MaterialTheme.colorScheme.primary
)

private fun ReadingMode.label() = when (this) {
    ReadingMode.VERTICAL   -> "Vertical"
    ReadingMode.WEBTOON    -> "Webtoon (no gaps)"
    ReadingMode.HORIZONTAL -> "Horizontal (pager)"
}
private fun ReadingMode.hint() = when (this) {
    ReadingMode.VERTICAL   -> "Standard manga pages with small gaps."
    ReadingMode.WEBTOON    -> "Continuous strip, no gaps between pages."
    ReadingMode.HORIZONTAL -> "One page at a time, swipe left/right."
}

// ── Top / Bottom bars ──────────────────────────────────────────────────────────

@Composable
private fun ReaderTopBar(
    chapter: Chapter,
    chapterIndex: Int,
    totalChapters: Int,
    currentPage: Int,
    totalPages: Int,
    onBack: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier          = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(chapter.title, color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Ch ${chapterIndex+1}/$totalChapters  ·  Pg $currentPage/$totalPages",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.labelSmall)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ReaderBottomBar(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier              = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            TextButton(onClick = onPrev, enabled = chapterIndex > 0,
                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)) {
                Icon(Icons.Default.NavigateBefore, null)
                Spacer(Modifier.width(4.dp))
                Text("Prev")
            }
            Text("Ch ${chapterIndex+1} / $totalChapters",
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelMedium)
            TextButton(onClick = onNext, enabled = chapterIndex < totalChapters - 1,
                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)) {
                Text("Next")
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.NavigateNext, null)
            }
        }
    }
}

@Composable
private fun ChapterFooter(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().background(Color(0xFF111111)).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
        Spacer(Modifier.height(20.dp))
        if (chapterIndex < totalChapters - 1) {
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth(0.7f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary)) {
                Icon(Icons.Default.NavigateNext, null)
                Spacer(Modifier.width(6.dp))
                Text("Next Chapter")
            }
        } else {
            Text("You've reached the end!", color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.bodyMedium)
        }
        if (chapterIndex > 0) {
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onPrev,
                colors = ButtonDefaults.textButtonColors(
                    contentColor = Color.White.copy(alpha = 0.6f))) {
                Icon(Icons.Default.NavigateBefore, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Previous Chapter")
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ── Loading / error states ────────────────────────────────────────────────────

@Composable
private fun LoadingState() {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Color.White)
            Spacer(Modifier.height(16.dp))
            Text("Extracting chapter…", color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.BrokenImage, null, Modifier.size(56.dp),
            tint = Color.Red.copy(alpha = 0.7f))
        Spacer(Modifier.height(16.dp))
        Text(message, color = Color.White, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry) { Text("Retry") }
    }
}
