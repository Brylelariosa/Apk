package com.voxelsandbox.game.world.mesh

import com.voxelsandbox.game.world.AtlasCell

/**
 * Which flips and turns of a block texture are allowed when the shader breaks up repetition.
 *
 * Every block face is drawn with its tile turned or mirrored in one of up to eight ways, chosen
 * by a hash of the block's world position and the face (see VoxelShader): the choice is a pure
 * function of where the block is, so it is the same after a chunk is unloaded and loaded again,
 * however the mesher happens to have merged the faces, and at every distance. What a texture
 * allows depends on what it shows:
 *
 *  - ground, rock, sand, snow, leaves, ore and the ring pattern of a log's end can be turned and
 *    mirrored freely ([ANY]);
 *  - bark has streaks that must stay upright, so it can be mirrored but not turned ([MIRROR]);
 *  - the side of grass, snow, sandstone and cactus has a fringe or strata that must stay the right
 *    way up, and can only be mirrored left to right ([FLIP_X]);
 *  - the rest (plants, water, plain colours) are never varied.
 */
object TextureVariants {
    /** Mirror the tile left to right. */
    const val FLIP_X = 1

    /** Mirror the tile top to bottom. */
    const val FLIP_Y = 2

    /** Swap the tile's axes (with the flips this gives the four quarter turns). */
    const val SWAP = 4

    /** Not a variation: the tile repeats seamlessly, so a texture lookup that reaches past its edge continues on
     *  the opposite edge instead of stopping at this one (see VoxelShader). Always reported, even when the
     *  variations are off. */
    const val TILEABLE = 8

    const val NONE = 0
    const val MIRROR = FLIP_X or FLIP_Y
    const val ANY = FLIP_X or FLIP_Y or SWAP

    /** The tiles TextureAtlas fills its gutter by wrapping (seamless by construction); the same set. */
    private val tileable = BooleanArray(64).also { t ->
        for (c in intArrayOf(
            AtlasCell.GRASS_TOP, AtlasCell.DIRT, AtlasCell.STONE, AtlasCell.SAND, AtlasCell.OAK_BARK, AtlasCell.OAK_LEAVES,
            AtlasCell.BIRCH_BARK, AtlasCell.BIRCH_LEAVES, AtlasCell.SPRUCE_LEAVES, AtlasCell.SPRUCE_BARK, AtlasCell.SNOW,
            AtlasCell.GRAVEL, AtlasCell.SANDSTONE_TOP, AtlasCell.DRY_GRASS_TOP, AtlasCell.SWAMP_GRASS_TOP, AtlasCell.DEEP_STONE
        )) t[c] = true
    }

    private val flags = IntArray(64).also { t ->
        val any = intArrayOf(
            AtlasCell.GRASS_TOP, AtlasCell.DIRT, AtlasCell.STONE, AtlasCell.SAND, AtlasCell.OAK_RINGS,
            AtlasCell.OAK_LEAVES, AtlasCell.COAL_ORE, AtlasCell.BIRCH_LEAVES, AtlasCell.SPRUCE_LEAVES,
            AtlasCell.BIRCH_RINGS, AtlasCell.SPRUCE_RINGS, AtlasCell.SNOW, AtlasCell.GRAVEL,
            AtlasCell.SANDSTONE_TOP, AtlasCell.DRY_GRASS_TOP, AtlasCell.CACTUS_TOP,
            AtlasCell.SWAMP_GRASS_TOP, AtlasCell.DEEP_STONE
        )
        for (c in any) t[c] = ANY
        for (c in intArrayOf(AtlasCell.OAK_BARK, AtlasCell.BIRCH_BARK, AtlasCell.SPRUCE_BARK)) t[c] = MIRROR
        for (c in intArrayOf(
            AtlasCell.GRASS_SIDE, AtlasCell.SNOW_SIDE, AtlasCell.SANDSTONE_SIDE, AtlasCell.DRY_GRASS_SIDE,
            AtlasCell.CACTUS_SIDE, AtlasCell.SWAMP_GRASS_SIDE
        )) t[c] = FLIP_X
    }

    /**
     * Whether the variations are applied at all. With it off every face reports [NONE], so the shader draws
     * every block's tile the way the mesher always did. It is a switch for measuring (the picture must then be
     * the plain tiling, pixel for pixel) and for ruling the feature out if it ever misbehaves on a device; the
     * game runs with it on. It only reaches meshes built after it is changed.
     */
    @JvmField @Volatile var enabled: Boolean = true

    /** The allowed variations (a combination of [FLIP_X], [FLIP_Y], [SWAP]) of atlas cell [cell]. */
    fun flagsFor(cell: Int): Int {
        if (cell < 0 || cell >= flags.size) return NONE
        return (if (enabled) flags[cell] else NONE) or (if (tileable[cell]) TILEABLE else NONE)
    }
}
