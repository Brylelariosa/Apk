package com.voxelsandbox.game.gl

import com.voxelsandbox.game.world.mesh.FaceLayout

/**
 * The shaders of the voxel terrain (solid blocks, leaves, plants and the small overlay meshes that
 * share their programs).
 *
 * Two kinds of quad reach them, told apart by the vertex's texture slots:
 *
 *  - **Block faces** (y slot negative, x slot = the face's description, see ChunkMesher.emitCubeRect): a
 *    quad may cover many blocks, so there are no texture coordinates in the mesh at all. The fragment
 *    derives everything from where it is in the world: which block it is in, where in that block's face
 *    it is, and so which texel of the block's tile to read, tiling the tile once per block. That is what
 *    lets the mesher merge faces into big rectangles, and it is also where the repetition of the
 *    ground is broken up: each block's tile is mirrored or turned by a hash of the block's position (only
 *    in the ways the texture allows, see TextureVariants), and each block is a touch brighter or darker
 *    by the same hash that the mesher used to bake in. Both depend on the block's world position and
 *    nothing else, so they are identical after a chunk is reloaded, however the faces were merged, and
 *    on every frame.
 *  - **Free quads** (y slot >= 0: plants, lily pads, particles, the block outline): ordinary atlas
 *    coordinates, interpolated as always.
 *
 * Everything the block-face path needs is exact: positions arrive relative to the eye's whole-block
 * position (`vRel`, small, `highp`), the block coordinates are the integer part of those plus the
 * (integer) origin, and the fractional part is the position inside the block.
 *
 * Which block a fragment belongs to is decided at a point 0.01 inside the face, not on it: a face lies
 * exactly on a block boundary, and the last bit of an interpolated coordinate must not decide which
 * block it belongs to. Within the face the same number that selects the block (its integer part)
 * gives the tile coordinate (its fractional part), so the variation changes exactly where the tile
 * repeats and never anywhere else.
 *
 * Cracks. Where two quads of different sizes lie side by side in one plane (a merged rectangle next to
 * single faces), the corners of the small ones lie on the edge of the big one, and after the GPU has
 * rounded every vertex to its sub-pixel grid a pixel-wide hole can open between them. The vertex shader
 * therefore grows every block face by a hair along its own plane ([EDGE_GROW] of the distance from the
 * camera: the same small fraction of a pixel at any distance), so neighbours overlap instead of just
 * touching; the overlap shows the same texture at the same place, because the texture comes from the
 * world position, not from the quad.
 */
object VoxelShader {
    /** Blocks nearer than this get the full per-block brightness variation; it fades out by [VARIANT_FAR], and
     *  the tile variants stop there too (a tile is a few pixels by then, and the work is not worth it). The
     *  numbers are shared with the distant terrain (see [BlockGrain]). */
    private const val VARIANT_NEAR = BlockGrain.NEAR
    private const val VARIANT_FAR = BlockGrain.FAR

    /** How much the per-block brightness may vary (a factor of 1 - range .. 1): the values the mesher
     *  used to bake in, for solid blocks and for leaves. */
    private const val SOLID_RANGE = BlockGrain.SOLID_RANGE
    private const val LEAF_RANGE = BlockGrain.LEAF_RANGE

    /** How much coarser than the hardware rule the atlas mip level is chosen (2^0.25), as a factor on the
     *  screen-space derivatives: a quarter of a level of margin against the sparkle that high-contrast pixel
     *  art shows at the Nyquist limit. */
    private const val LOD_BIAS = 1.1892071f

    /** The most taps the anisotropic lookup of block faces takes along the stretched direction of a pixel's
     *  footprint (see [LOOKUP_CRISP]). A pixel of ground seen at a low angle covers several texels along the
     *  view direction and a fraction of one across it; one trilinear sample either blurs the across direction
     *  or lets the along direction alias (the crawl of speckled sand and dirt while walking). Taps spread over
     *  the footprint average the along direction and keep the across direction sharp. 1 = the old single
     *  sample. It is the cost knob: pixels that are not stretched (everything within a few blocks, walls)
     *  always take one. */
    const val TERRAIN_TAPS = 4

    /** How much farther than the hardware rule the footprint is widened where texels are many per pixel
     *  (anisotropic minification beyond [FAR_BIAS_FROM] texels per pixel, full by [FAR_BIAS_TO]): the sparkle
     *  of a fine pattern a long way off, where blur costs nothing. 0.4 = about half a mip level. */
    private const val FAR_BIAS = 0.4f
    private const val FAR_BIAS_FROM = 1.5f
    private const val FAR_BIAS_TO = 6.0f

    /**
     * How far a block face is grown along its plane, per unit of distance from the camera (blocks per block).
     * On a 720 p screen with a 70 degree view that is about 1/30 of a pixel at every distance: far less than
     * a pixel can show, and several times the 1/256 pixel a GPU's vertex rounding can leave open.
     */
    private const val EDGE_GROW = 6.0e-5f

    private fun vec3Array(name: String, rows: List<IntArray>): String =
        "const highp vec3 $name[${rows.size}] = vec3[${rows.size}](" +
            rows.joinToString(", ") { "vec3(${it[0]}.0, ${it[1]}.0, ${it[2]}.0)" } + ");\n"

    /** Shared vertex stage. */
    @JvmField
    val VERTEX: String = "#version 300 es\n" +
        "#define CORNER_U ${FaceLayout.CORNER_U}\n" +
        "#define EDGE_GROW $EDGE_GROW\n" +
        vec3Array("CORNER_DIR", (0 until 6).flatMap { f -> (0 until 4).map { c -> FaceLayout.cornerDirection(f, c) } }) +
        """
layout(location = 0) in vec3 aPosition;
layout(location = 1) in vec2 aTexCoord;
layout(location = 2) in float aShade;

uniform mat4 uViewProj;
uniform highp vec3 uCamOrigin;

out vec2 vTexCoord;
flat out highp float vInfo;
out float vShade;
out float vFogDist;
out highp vec3 vWorld;
out highp vec3 vRel;

void main() {
    highp vec3 rel = aPosition - uCamOrigin;
    highp vec4 clip = uViewProj * vec4(rel, 1.0);
    highp float info = -1.0;
    if (aTexCoord.y < 0.0) {
        // A block face: the first slot is its description (plus CORNER_U on the right-hand corners), the
        // second is -1 on the first row of corners and -2 on the second. Say which corner this is, and
        // grow it along the face's plane.
        highp float right = aTexCoord.x >= CORNER_U ? 1.0 : 0.0;
        info = aTexCoord.x - right * CORNER_U;
        int face = (int(info + 0.5) >> 6) & 7;
        int corner = int(right) + (aTexCoord.y < -1.5 ? 2 : 0);
        highp vec3 grow = CORNER_DIR[face * 4 + corner] * (clip.w * EDGE_GROW);
        rel += grow;
        clip += uViewProj * vec4(grow, 0.0);
    }
    gl_Position = clip;
    vTexCoord = aTexCoord;
    vInfo = info;
    vShade = aShade;
    vFogDist = clip.w;
    vWorld = aPosition;
    vRel = rel;
}
"""

    /**
     * The rim dissolve, in [opaqueFade] and [cutout]. `uFade`: xy = the eye (world X/Z), z = radius where
     * the dissolve starts, w = its width (0 = off). A fragment is dropped when a noise value is below a
     * threshold that grows from 0 at z to 1 at z + w, so the distant mesh behind shows through more and
     * more.
     *
     * The noise is fixed to the world: one value per block cell (3-D, so that walls are not striped),
     * from the R3 low-discrepancy sequence, with the cell grid offset by a fraction of a block so that
     * faces lying exactly on a cell boundary (every block face does) are not decided by the last bit of
     * an interpolated coordinate. The pattern therefore stays put on the terrain as the camera moves
     * (screen-space noise swims across it), and the circle it is cut by follows the eye smoothly.
     * Cell coordinates are wrapped at 1024 so that the sum stays small and exact in highp floats far
     * from the origin; the pattern then repeats every 1024 blocks, which is not visible.
     */
    private const val DISSOLVE = """
bool dissolved(highp vec3 world) {
    highp vec2 fd = world.xz - uFade.xy;
    highp float fd2 = dot(fd, fd);
    if (uFade.w <= 0.0 || fd2 <= uFade.z * uFade.z) return false;
    highp float t = min((sqrt(fd2) - uFade.z) / uFade.w, 1.0);
    highp vec3 cell = mod(floor(world + vec3(0.37, 0.21, 0.53)), 1024.0);
    highp float n = fract(dot(cell, vec3(0.8191725134, 0.6710436067, 0.5497004779)));
    return n < t;
}
"""

    /**
     * The atlas lookup of the voxel terrain: crisp square pixels up close, no crawling or shimmering far
     * away. `texel` is the position in the atlas in texels, `dtx` / `dty` its screen-space derivatives
     * in texels (already biased by [LOD_BIAS]).
     *
     *  - Magnified (a pixel covers less than a texel, the usual case within a few blocks): a "sharp
     *    bilinear" remap. The texel coordinate is pushed to the centre of its texel, except within half a
     *    pixel of a texel edge, where it slides linearly across the edge. The linear sampler then returns
     *    the exact texel colour everywhere but in a one-pixel-wide transition at the edges, which
     *    anti-aliases them (they no longer jump a whole pixel as the camera moves) and keeps the pixels
     *    square.
     *  - Minified (a pixel covers one texel or more): the remap fades out completely by one texel per
     *    pixel and the plain trilinear sampler takes over, reading the mip chain with a proper footprint:
     *    a smooth, continuous function of position, so nothing flickers.
     *
     * `textureGrad` gets the derivatives of the *unwrapped* coordinate: the mip level does not depend on
     * the remap, and stays correct where the tile coordinate wraps (at every block boundary), which the
     * hardware's own derivative would not. The gutter around every tile in the atlas holds the tile's
     * own pattern wrapped (for tiles that repeat) or extended, so the blend across a tile edge reads
     * more of the same block.
     */
    private const val LOOKUP_CRISP = """
vec4 atlasLookup(highp vec2 texel, highp vec2 dtx, highp vec2 dty) {
    highp vec2 fp = abs(dtx) + abs(dty);
    highp float rho = max(fp.x, fp.y);
    highp vec2 w = mix(min(fp, vec2(1.0)), vec2(1.0), smoothstep(0.5, 1.0, rho));
    highp vec2 c = floor(texel + 0.5);
    highp vec2 s = c + clamp((texel - c) / max(w, vec2(0.001)), -0.5, 0.5);
    return textureGrad(uTexture, s * (1.0 / ATLAS_PX), dtx * (1.0 / ATLAS_PX), dty * (1.0 / ATLAS_PX));
}

// Block faces: `tc` is the position inside the block's tile in texels (0 .. 16), `origin` the tile's corner in
// the atlas, `dtx` / `dty` the screen-space derivatives of `tc` in texels. See the class comment.
vec4 tileLookup(highp vec2 tc, highp vec2 origin, highp vec2 dtx, highp vec2 dty, bool tileable) {
    highp float lx = dot(dtx, dtx);
    highp float ly = dot(dty, dty);
    highp vec2 axisLong = lx > ly ? dtx : dty;
    highp vec2 axisShort = lx > ly ? dty : dtx;
    highp float lenLong = sqrt(max(lx, ly));
    highp float lenShort = max(sqrt(min(lx, ly)), 1.0e-4);
    int taps = int(clamp(floor(lenLong / max(lenShort, 1.0) + 0.5), 1.0, float(MAX_TAPS)));
    highp float widen = 1.0 + FAR_BIAS * smoothstep(FAR_BIAS_FROM, FAR_BIAS_TO, lenLong);
    highp vec2 stepv = axisLong * (widen / float(taps));
    highp vec2 across = axisShort * widen;
    highp vec2 fp = abs(stepv) + abs(across);
    highp float rho = max(fp.x, fp.y);
    highp vec2 w = mix(min(fp, vec2(1.0)), vec2(1.0), smoothstep(0.7, 1.6, rho));
    highp vec2 gx = stepv * (1.0 / ATLAS_PX);
    highp vec2 gy = across * (1.0 / ATLAS_PX);
    vec4 sum = vec4(0.0);
    for (int i = 0; i < MAX_TAPS; i++) {
        if (i >= taps) break;
        highp vec2 p = tc + axisLong * ((float(i) + 0.5) / float(taps) - 0.5);
        p = tileable ? mod(p, CELL_PX) : clamp(p, vec2(0.0), vec2(CELL_PX));
        highp vec2 c = floor(p + 0.5);
        highp vec2 s = c + clamp((p - c) / max(w, vec2(0.001)), -0.5, 0.5);
        sum += textureGrad(uTexture, (origin + s) * (1.0 / ATLAS_PX), gx, gy);
    }
    return sum / float(taps);
}
"""

    /** The plain lookup, for a driver that rejects [LOOKUP_CRISP]. */
    private const val LOOKUP_PLAIN = """
vec4 atlasLookup(highp vec2 texel, highp vec2 dtx, highp vec2 dty) {
    return textureGrad(uTexture, texel * (1.0 / ATLAS_PX), dtx * (1.0 / ATLAS_PX), dty * (1.0 / ATLAS_PX));
}

vec4 tileLookup(highp vec2 tc, highp vec2 origin, highp vec2 dtx, highp vec2 dty, bool tileable) {
    return atlasLookup(origin + tc, dtx, dty);
}
"""

    /**
     * The colour of the fragment's texture and its per-block brightness (see the class comment).
     *
     * [FACE_U] / [FACE_V] say which world axes run along the tile's horizontal edge and down its rows on each
     * face (a minus sign: against that axis), so that the textures sit the way the mesher always put them:
     * image row 0 at the top of side faces, a grass fringe the right way up. They come from [FaceLayout],
     * like the quads themselves.
     */
    private val TILE: String = vec3Array("FACE_U", (0 until 6).map { FaceLayout.tileU(it) }) +
        vec3Array("FACE_V", (0 until 6).map { FaceLayout.tileV(it) }) +
        vec3Array("FACE_N", (0 until 6).map { FaceLayout.normal(it) }) + """
vec4 voxelTexel(out float brightness) {
    brightness = 1.0;
    // Both derivative sets are taken before any branch: the screen-space derivatives of a quad of
    // fragments are only defined where the whole quad takes the same path.
    highp vec2 uvDx = dFdx(vTexCoord) * (ATLAS_PX * LOD_BIAS);
    highp vec2 uvDy = dFdy(vTexCoord) * (ATLAS_PX * LOD_BIAS);
    int info = int(max(vInfo, 0.0) + 0.5);
    int cell = info & 63;
    int face = (info >> 6) & 7;
    int flags = info >> 9;
    highp vec2 ic = vec2(dot(vRel, FACE_U[face]), dot(vRel, FACE_V[face]));
    highp vec2 dx = dFdx(ic) * (CELL_PX * TILE_BIAS);
    highp vec2 dy = dFdy(ic) * (CELL_PX * TILE_BIAS);

    if (vInfo < 0.0) return atlasLookup(vTexCoord * ATLAS_PX, uvDx, uvDy);

    highp vec2 t = fract(ic);
    if (vFogDist < VARIANT_FAR) {
        // The block this fragment belongs to, as integers: the whole-block eye position is exact.
        ivec3 b = ivec3(floor(vRel - FACE_N[face] * 0.01)) + ivec3(uCamOrigin);
        uvec3 u = uvec3(b);
        uint h = (u.x * 73856093u) ^ (u.y * 19349663u) ^ (u.z * 83492791u);
        h ^= h >> 15u;
        h *= 739982445u;
        h ^= h >> 13u;
        float r = float((h >> 8u) & 255u) * (1.0 / 255.0);
        brightness = 1.0 - VARIATION_RANGE * r * (1.0 - smoothstep(VARIANT_NEAR, VARIANT_FAR, vFogDist));
        // Which way the tile is mirrored or turned: other bits of the block's hash, mixed with the face
        // so that a block's faces are not all turned alike, and limited to what the texture allows.
        uint v = h * 2246822519u + uint(face) * 3266489917u;
        v ^= v >> 15u;
        v *= 2654435761u;
        v ^= v >> 13u;
        uint bits = (v >> 9u) & uint(flags);
        if ((bits & 4u) != 0u) {
            t = t.yx;
            dx = dx.yx;
            dy = dy.yx;
        }
        if ((bits & 1u) != 0u) t.x = 1.0 - t.x;
        if ((bits & 2u) != 0u) t.y = 1.0 - t.y;
    }
    highp vec2 origin = vec2(float(cell & 7), float(cell >> 3)) * PITCH_PX + PAD_PX;
    return tileLookup(t * CELL_PX, origin, dx, dy, (flags & 8) != 0);
}
"""

    private fun constants(variationRange: Float, crisp: Boolean): String =
        "#define ATLAS_PX ${TextureAtlas.SIZE_PX}.0\n" +
            "#define MAX_TAPS ${if (crisp) TERRAIN_TAPS else 1}\n" +
            "#define FAR_BIAS $FAR_BIAS\n" +
            "#define FAR_BIAS_FROM $FAR_BIAS_FROM\n" +
            "#define FAR_BIAS_TO $FAR_BIAS_TO\n" +
            "#define TILE_BIAS ${if (crisp) 1.0f else LOD_BIAS}\n" +
            "#define CELL_PX ${TextureAtlas.CELL_PX}.0\n" +
            "#define PITCH_PX ${TextureAtlas.PITCH_PX}.0\n" +
            "#define PAD_PX ${TextureAtlas.PAD_PX}.0\n" +
            "#define LOD_BIAS $LOD_BIAS\n" +
            "#define VARIANT_NEAR $VARIANT_NEAR\n" +
            "#define VARIANT_FAR $VARIANT_FAR\n" +
            "#define VARIATION_RANGE $variationRange\n"

    private const val HEAD = """#version 300 es
precision mediump float;
precision highp int;

in highp vec2 vTexCoord;
flat in highp float vInfo;
in float vShade;
in float vFogDist;
in highp vec3 vRel;
"""

    private const val FOG = """
uniform sampler2D uTexture;
uniform highp vec3 uCamOrigin;
uniform vec3 uFogColor;
uniform float uFogStart;
uniform float uFogEnd;
"""

    /** Opaque blocks: texture, brightness, baked shade, fog. Deliberately has no `discard`, so the GPU can
     *  use early depth rejection (and, on tile-based GPUs, hidden-surface removal) for the bulk of the terrain. */
    fun opaque(crisp: Boolean): String = HEAD + FOG + constants(SOLID_RANGE, crisp) + lookup(crisp) + TILE + """
out vec4 fragColor;

void main() {
    float brightness;
    vec3 shaded = voxelTexel(brightness).rgb * (vShade * brightness);
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /** The opaque blocks of the regions on the rim of the voxel area: [opaque] plus the dissolve. */
    fun opaqueFade(crisp: Boolean): String = HEAD + "in highp vec3 vWorld;\n" + FOG + "uniform highp vec4 uFade;\n" +
        constants(SOLID_RANGE, crisp) + lookup(crisp) + TILE + DISSOLVE + """
out vec4 fragColor;

void main() {
    if (dissolved(vWorld)) discard;
    float brightness;
    vec3 shaded = voxelTexel(brightness).rgb * (vShade * brightness);
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    fragColor = vec4(mix(shaded, uFogColor, fogFactor), 1.0);
}
"""

    /** Alpha-tested terrain (leaf and plant tiles carry real transparent holes) and the overlay meshes
     *  (block outline, particles, laser). The same rim dissolve as [opaqueFade]; uFade.w = 0 turns it off. */
    fun cutout(crisp: Boolean): String = HEAD + "in highp vec3 vWorld;\n" + FOG + "uniform float uAlpha;\nuniform highp vec4 uFade;\n" +
        constants(LEAF_RANGE, crisp) + lookup(crisp) + TILE + DISSOLVE + """
out vec4 fragColor;

void main() {
    if (dissolved(vWorld)) discard;
    float brightness;
    vec4 texColor = voxelTexel(brightness);
    if (texColor.a < 0.5) discard;
    vec3 shaded = texColor.rgb * (vShade * brightness);
    float fogFactor = clamp((vFogDist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
    vec3 finalColor = mix(shaded, uFogColor, fogFactor);
    fragColor = vec4(finalColor, texColor.a * uAlpha);
}
"""

    private fun lookup(crisp: Boolean): String = if (crisp) LOOKUP_CRISP else LOOKUP_PLAIN
}
