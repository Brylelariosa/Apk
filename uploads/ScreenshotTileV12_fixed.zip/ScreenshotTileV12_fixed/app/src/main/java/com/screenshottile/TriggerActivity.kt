package com.screenshottile

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets

/**
 * Invisible zero-UI activity.
 * startActivityAndCollapse() collapses the QS panel before this activity starts.
 *
 * TASK ISOLATION
 * --------------
 * android:taskAffinity="" in the manifest ensures this activity always runs in its
 * own anonymous task (no affinity with the ScreenshotTile or any other task).
 * Combined with finishAndRemoveTask(), the task is fully destroyed the moment we
 * are done — it never lingers in recents or interferes with other apps' back stacks.
 * Without this, FLAG_ACTIVITY_NEW_TASK could root TriggerActivity in the ScreenshotTile
 * task, and the 800ms it stays alive after firing would surface ScreenshotTile as the
 * foreground app, causing subsequent hardware-button screenshots to "go to" this app.
 *
 * SCREENSHOT TIMING
 * -----------------
 * Primary:  onWindowFocusChanged(hasFocus=true) — fires once the panel animation
 *           is fully complete; most accurate trigger.
 * Fallback: onResume + 600 ms — for home screen / launcher / menus where Android
 *           does not grant focus to a translucent window overlaid on the launcher,
 *           so onWindowFocusChanged(true) never arrives.
 * Both paths are guarded by screenshotTaken so only one fires.
 *
 * SAVE RELIABILITY — HOME SCREEN / LAUNCHER / MENUS
 * --------------------------------------------------
 * Android 12+ suppresses the MediaStore file write when a non-system Activity
 * surface is visible over the launcher. Fix: finish first (removes our surface),
 * then delegate the trigger to ScreenshotAccessibilityService.scheduleScreenshot().
 *
 * SAVE RELIABILITY — IN-APP PATH
 * --------------------------------
 * finish() is delayed 800 ms so the process stays at foreground priority while
 * the system completes the async MediaStore write. finishAndRemoveTask() is used
 * instead of finish() to ensure the anonymous task is fully destroyed — not just
 * the activity popped — so it never re-surfaces.
 */
class TriggerActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private var screenshotTaken = false
    private var retryCount = 0
    private var screenshotRunnable: Runnable? = null
    private var finishRunnable: Runnable? = null

    private var hadWindowFocus = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(null)
        if (ScreenshotAccessibilityService.instance == null) { finishAndRemoveTask(); return }
    }

    override fun onResume() {
        super.onResume()
        if (!screenshotTaken && screenshotRunnable == null) {
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 600L)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !screenshotTaken) {
            hadWindowFocus = true
            // Hide navigation bar at runtime — android:windowHideNavigation is not
            // a valid theme attribute and was removed from styles.xml.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.insetsController?.hide(WindowInsets.Type.navigationBars())
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE
                )
            }
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
            takeScreenshot()
        }
    }

    private fun takeScreenshot() {
        if (screenshotTaken) return

        val service = ScreenshotAccessibilityService.instance
        if (service == null) { finishAndRemoveTask(); return }

        if (!hadWindowFocus) {
            // HOME SCREEN / LAUNCHER / MENU PATH
            // Finish first to remove our surface from the composition stack.
            screenshotTaken = true
            finishAndRemoveTask()
            service.scheduleScreenshot(300L)
            return
        }

        // IN-APP PATH — focus was genuinely granted, fire immediately.
        val dispatched = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)

        if (!dispatched && retryCount < 1) {
            retryCount++
            val r = Runnable { takeScreenshot() }
            screenshotRunnable = r
            handler.postDelayed(r, 200L)
            return
        }

        screenshotTaken = true

        // 800 ms is enough to keep process priority while MediaStore write completes.
        // finishAndRemoveTask() destroys the anonymous task entirely — it won't linger
        // in recents or re-surface when the user takes a screenshot from another app.
        val r = Runnable { finishAndRemoveTask() }
        finishRunnable = r
        handler.postDelayed(r, 800L)
    }

    override fun onPause() {
        super.onPause()
        if (!screenshotTaken) {
            screenshotRunnable?.let { handler.removeCallbacks(it) }
            screenshotRunnable = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        screenshotRunnable = null
        finishRunnable = null
    }
}
