package com.immortalascension

import kotlin.random.Random

object NPCSystem {

    // ── NAME TABLES ───────────────────────────────────────────────────────────

    private val SURNAMES = listOf(
        "Wei","Lin","Chen","Zhao","Liu","Wang","Zhang","Sun","Li","Zhou",
        "Xu","Yan","Xue","Tang","Bai","Jiang","Shen","Fang","He","Lu",
        "Mo","Qin","Han","Yue","Feng","Gu","Shi","Gao","Zhu","Luo"
    )
    private val GIVEN_MALE = listOf(
        "Long","Feng","Tian","Yun","Mo","Jian","Han","Zhen","Hao","Kun",
        "Lei","Xiao","Ming","Bo","Shan","Jun","Wei","Ao","Chen","Yi"
    )
    private val GIVEN_FEMALE = listOf(
        "Yue","Xiu","Mei","Lan","Rou","Zhu","Qing","Lian","Xia","Ning",
        "Yun","Shan","Bai","Ruo","Meng","Yi","Shu","Die","Hong","Zhi"
    )
    private val TITLES = listOf(
        "the Wanderer","the Silent","of the Broken Path","the Merciless",
        "the Undying","of Endless Sorrow","the Enlightened","the Demon-Touched",
        "of the Sword","the Forgotten","of Hollow Eyes","the Reckless"
    )

    fun randomName(female: Boolean = Random.nextBoolean()): String {
        val surname = SURNAMES.random()
        val given   = if (female) GIVEN_FEMALE.random() else GIVEN_MALE.random()
        return "$surname $given"
    }

    fun randomNameWithTitle(): String =
        if (Random.nextFloat() < 0.2f) "${randomName()} ${TITLES.random()}" else randomName()

    // ── NPC GENERATION ────────────────────────────────────────────────────────

    fun generateRandomNPC(
        id: String,
        realmHint: RealmTier = RealmTier.QI_GATHERING,
        locationId: String = LocationSystem.ALL_LOCATIONS.keys.random()
    ): NPC {
        val tier      = realmHint
        val stage     = Random.nextInt(1, tier.stages + 1)
        val realm     = Realm(tier, stage)
        val maxQi     = realm.qiCap
        val maxHp     = 80 + tier.hpBonus * stage
        val personality = NPCPersonality.values().random()
        val stones    = Random.nextInt(0, 50 + tier.ordinal * 30)

        val goals = generateGoals(personality, tier)
        val backstory = generateBackstory(personality, tier)

        return NPC(
            id = id,
            name = randomNameWithTitle(),
            realm = realm,
            personality = personality,
            goals = goals.toMutableList(),
            disposition = when (personality) {
                NPCPersonality.WARM, NPCPersonality.HUMBLE, NPCPersonality.RIGHTEOUS -> NPCDisposition.FRIENDLY
                NPCPersonality.ARROGANT, NPCPersonality.COLD -> NPCDisposition.WARY
                NPCPersonality.CHAOTIC -> if (Random.nextBoolean()) NPCDisposition.NEUTRAL else NPCDisposition.HOSTILE
                else -> NPCDisposition.NEUTRAL
            },
            currentLocation = locationId,
            qi = Random.nextInt(0, maxQi),
            maxQi = maxQi,
            hp = maxHp,
            maxHp = maxHp,
            spiritStones = stones,
            backstory = backstory,
            deathNote = generateDeathNote(personality)
        )
    }

    private fun generateGoals(p: NPCPersonality, tier: RealmTier): List<String> {
        val pool = when (p) {
            NPCPersonality.RIGHTEOUS -> listOf("protect the weak","uphold sect law","purge demonic cultivators","guide a worthy disciple")
            NPCPersonality.ARROGANT  -> listOf("surpass all rivals","claim the best resources","be acknowledged as a genius","crush those who disrespect them")
            NPCPersonality.COLD      -> listOf("survive at any cost","find a certain person","complete an old oath","trust no one")
            NPCPersonality.WARM      -> listOf("find true companions","cultivate alongside friends","leave a legacy worth remembering","protect those they love")
            NPCPersonality.CUNNING   -> listOf("accumulate wealth and power","manipulate sects for gain","discover forbidden techniques","never be controlled")
            NPCPersonality.CHAOTIC   -> listOf("test their own limits","find worthy opponents","burn the world to see what remains","chase the edge of reason")
            NPCPersonality.HUMBLE    -> listOf("reach the next realm quietly","learn from every encounter","find a master worth following","cause no unnecessary harm")
            NPCPersonality.MELANCHOLY-> listOf("find meaning in the endless years","understand why the heavens are silent","reconnect with someone lost","accept their own path")
        }
        val universal = when (tier) {
            RealmTier.MORTAL, RealmTier.QI_GATHERING -> listOf("reach Foundation Building realm","find a powerful sect to join","acquire spirit stones")
            RealmTier.FOUNDATION -> listOf("reach Core Formation","master their technique","build a reputation")
            RealmTier.CORE_FORMATION -> listOf("reach Nascent Soul","find heaven-grade resources","leave a legacy")
            else -> listOf("transcend mortality","defy the heavens","find others who have walked this far")
        }
        return (pool.shuffled().take(2) + universal.shuffled().take(1)).shuffled()
    }

    private fun generateBackstory(p: NPCPersonality, tier: RealmTier): String {
        val origins = listOf(
            "Born to a mortal family with no cultivation lineage.",
            "A former sect outer disciple who was expelled.",
            "The sole survivor of a destroyed sect.",
            "A wandering cultivator with no fixed home.",
            "Once a promising inner disciple who abandoned the sect.",
            "Raised by a reclusive hermit deep in the mountains.",
            "A merchant's child who discovered their spiritual root late.",
            "Formerly a sect elder's attendant, now striking out alone."
        )
        val middles = when (p) {
            NPCPersonality.COLD      -> listOf("Something happened that stripped the warmth from them. They haven't spoken of it since.","They trust actions, never words.")
            NPCPersonality.ARROGANT  -> listOf("Early talent made the world bend to them. They expect it still.","They have never lost to someone they considered an equal.")
            NPCPersonality.RIGHTEOUS -> listOf("They once saw something unforgivable done to the innocent. They carry it.","The righteous path is not easy. They chose it anyway.")
            NPCPersonality.CHAOTIC   -> listOf("Rules were tried. Rules failed them. Now they make their own.","They are not cruel — they simply cannot predict themselves either.")
            NPCPersonality.MELANCHOLY-> listOf("There is a grief in them that cultivation has not healed.","They have lived long enough to watch everyone they knew die.")
            else -> listOf("Their path has been shaped by choices they can no longer undo.","They are still becoming who they will be.")
        }
        return "${origins.random()} ${middles.random()}"
    }

    private fun generateDeathNote(p: NPCPersonality): String = when (p) {
        NPCPersonality.RIGHTEOUS  -> "They died protecting someone. It was always going to end this way."
        NPCPersonality.COLD       -> "They died alone. It was how they preferred it."
        NPCPersonality.ARROGANT   -> "Their last expression was disbelief. They never imagined it possible."
        NPCPersonality.WARM       -> "They died calling out a name. Someone who probably never knew."
        NPCPersonality.CUNNING    -> "Even at the end, their eyes were calculating something."
        NPCPersonality.CHAOTIC    -> "They were laughing. No one understood why."
        NPCPersonality.HUMBLE     -> "They apologized to those around them for the inconvenience. Then they were gone."
        NPCPersonality.MELANCHOLY -> "They seemed almost relieved."
    }

    // ── NAMED NPCs (fixed story characters) ──────────────────────────────────

    fun createWorldNPCs(): List<NPC> = listOf(
        NPC(
            id = "elder_wei", name = "Elder Wei Longshan",
            realm = Realm(RealmTier.FOUNDATION, 3),
            personality = NPCPersonality.HUMBLE,
            goals = mutableListOf("guide worthy cultivators","preserve ancient knowledge","find a successor"),
            relationship = 10, disposition = NPCDisposition.FRIENDLY,
            currentLocation = "azure_wind_village",
            qi = 2400, maxQi = 3000, hp = 400, maxHp = 400,
            spiritStones = 200,
            backstory = "A former sect elder who retired to the village after the death of his sect. Three hundred years old. Still sharp.",
            deathNote = "Elder Wei passed quietly during his evening meditation. Those who knew him say he was smiling."
        ),
        NPC(
            id = "lin_yue", name = "Lin Yue",
            realm = Realm(RealmTier.QI_GATHERING, 7),
            personality = NPCPersonality.COLD,
            goals = mutableListOf("avenge her sect's destruction","reach Foundation realm","find the man who betrayed her sect"),
            disposition = NPCDisposition.WARY,
            currentLocation = "verdant_forest",
            qi = 1400, maxQi = 2100, hp = 180, maxHp = 180,
            spiritStones = 35,
            backstory = "The sole survivor of the Jade Crane Sect massacre. She speaks rarely. Her eyes track exits at all times.",
            deathNote = "Lin Yue died against overwhelming odds. She did not retreat."
        ),
        NPC(
            id = "chen_yan", name = "Chen Yan",
            realm = Realm(RealmTier.QI_GATHERING, 2),
            personality = NPCPersonality.WARM,
            goals = mutableListOf("reach Foundation realm","protect his younger sister","make friends among cultivators"),
            relationship = 15, disposition = NPCDisposition.FRIENDLY,
            currentLocation = "azure_wind_village",
            qi = 200, maxQi = 600, hp = 95, maxHp = 95,
            spiritStones = 8,
            backstory = "A cheerful young cultivator from the village. Modest talent, unbreakable will.",
            deathNote = "His final words were about his sister. He never stopped smiling."
        ),
        NPC(
            id = "xue_mo", name = "Xue Mo the Wanderer",
            realm = Realm(RealmTier.FOUNDATION, 2),
            personality = NPCPersonality.CHAOTIC,
            goals = mutableListOf("test his limits","find worthy opponents","understand the Killing Dao"),
            disposition = NPCDisposition.WARY,
            currentLocation = "thunder_peak",
            qi = 3000, maxQi = 6000, hp = 600, maxHp = 600,
            spiritStones = 120, isRogue = true,
            backstory = "A rogue cultivator who left his sect a century ago. Fights everyone he meets — not always to kill.",
            deathNote = "He fell to a stronger cultivator. By all accounts, he was grinning."
        ),
        NPC(
            id = "zhao_feng", name = "Zhao Feng",
            realm = Realm(RealmTier.QI_GATHERING, 5),
            personality = NPCPersonality.ARROGANT,
            goals = mutableListOf("surpass the player","claim Core Disciple rank","be acknowledged as a genius"),
            relationship = -20, disposition = NPCDisposition.HOSTILE,
            currentLocation = "azure_mountain_sect",
            qi = 900, maxQi = 1500, hp = 140, maxHp = 140,
            spiritStones = 60, sectId = "azure_mountain_sect",
            backstory = "The most talented disciple before you appeared. He has not forgiven you.",
            deathNote = "Zhao Feng was killed by a demonic cultivator during a mission he refused to retreat from."
        ),
        NPC(
            id = "xu_mao", name = "Demonic Emperor Xu Mao",
            realm = Realm(RealmTier.CORE_FORMATION, 2),
            personality = NPCPersonality.CHAOTIC,
            goals = mutableListOf("consume the Three Sects","open the Demon Path wider","transcend through destruction"),
            relationship = -100, disposition = NPCDisposition.HOSTILE,
            currentLocation = "demon_wastes",
            qi = 60000, maxQi = 90000, hp = 8000, maxHp = 8000,
            spiritStones = 5000, isDemonic = true,
            backstory = "Once a righteous sect master. His family was killed by heavenly decree. He no longer seeks justice.",
            deathNote = "Even in death, his Qi corroded the earth for miles."
        )
    )

    // ── RANDOM WORLD POPULATION ───────────────────────────────────────────────

    fun populateWorld(existingNPCs: List<NPC>): List<NPC> {
        val result = mutableListOf<NPC>()
        val locations = LocationSystem.ALL_LOCATIONS.keys.toList()
        var counter = existingNPCs.size

        // Distribute random NPCs across locations weighted by danger
        locations.forEach { locId ->
            val loc   = LocationSystem.get(locId)
            val count = when (loc.dangerLevel) {
                in 1..2 -> Random.nextInt(2, 5)
                in 3..5 -> Random.nextInt(1, 4)
                in 6..8 -> Random.nextInt(1, 3)
                else    -> Random.nextInt(0, 2)
            }
            val realmForLoc = when (loc.dangerLevel) {
                in 1..2 -> if (Random.nextBoolean()) RealmTier.MORTAL else RealmTier.QI_GATHERING
                in 3..5 -> if (Random.nextFloat() < 0.7f) RealmTier.QI_GATHERING else RealmTier.FOUNDATION
                in 6..8 -> if (Random.nextFloat() < 0.5f) RealmTier.FOUNDATION else RealmTier.QI_GATHERING
                else    -> RealmTier.FOUNDATION
            }
            repeat(count) {
                counter++
                result.add(generateRandomNPC("npc_$counter", realmForLoc, locId))
            }
        }

        return result
    }

    // ── PLAYER ENCOUNTER ──────────────────────────────────────────────────────

    fun npcEncounter(state: GameState): NPCEncounterResult {
        val candidates = state.npcs.filter {
            it.alive && it.currentLocation == state.world.locationId &&
            it.activity != NPCActivity.IN_SECLUSION
        }
        val npc = candidates.randomOrNull() ?: return NPCEncounterResult.NoNPC

        npc.metPlayer = true
        val dialogue  = generateDialogue(npc, state.player)
        val outcome   = interactionOutcome(npc, state.player)
        return NPCEncounterResult.Met(npc, dialogue, outcome)
    }

    private fun generateDialogue(npc: NPC, player: Player): List<String> {
        val lines = mutableListOf<String>()
        lines += when (npc.disposition) {
            NPCDisposition.DEVOTED   -> "${npc.name} approaches warmly. \"${player.name}. I hoped we'd meet again.\""
            NPCDisposition.FRIENDLY  -> "${npc.name} nods. \"Cultivator. ${if (npc.metPlayer) "It's been a while." else "New face."}\""
            NPCDisposition.NEUTRAL   -> "${npc.name} regards you without expression."
            NPCDisposition.WARY      -> "${npc.name} keeps distance. \"State your purpose.\""
            NPCDisposition.HOSTILE   -> "${npc.name}'s Qi flares. \"You again.\""
        }

        // Activity context line
        lines += when (npc.activity) {
            NPCActivity.CULTIVATING    -> "You can see the Qi still settling in their meridians from recent meditation."
            NPCActivity.HUNTING        -> "There is blood on their robes. Recent."
            NPCActivity.TRAVELING      -> "They carry a travel pack. Going somewhere with purpose."
            NPCActivity.SEEKING_REVENGE-> "Something cold lives behind their eyes today."
            NPCActivity.EXPLORING      -> "Their hands are stained with the dust of old ruins."
            NPCActivity.TRADING        -> "A merchant's calculating look enters their gaze briefly."
            NPCActivity.DUELING        -> "Fresh wounds on their arms. A recent fight."
            else -> ""
        }.let { if (it.isNotEmpty()) it else "They stand calmly, watching you."  }

        // Personality line
        lines += when (npc.personality) {
            NPCPersonality.HUMBLE     -> "\"I am still far from where I need to be.\""
            NPCPersonality.ARROGANT   -> "\"${player.realm.display}? Adequate, I suppose.\""
            NPCPersonality.COLD       -> "Silence. Then: \"You are not dead yet.\""
            NPCPersonality.WARM       -> "\"How have you been? You look stronger.\""
            NPCPersonality.CUNNING    -> "\"I wonder what you want from this meeting.\""
            NPCPersonality.RIGHTEOUS  -> "\"Are you still walking a righteous path?\""
            NPCPersonality.CHAOTIC    -> "\"Every meeting is a kind of battle. Do you feel it?\""
            NPCPersonality.MELANCHOLY -> "\"Another cultivator. Another path that ends somewhere.\""
        }

        // Rumour / world awareness
        if (npc.lifeEvents.isNotEmpty() && Random.nextFloat() < 0.4f) {
            lines += "They mention in passing: \"${npc.lifeEvents.last()}\""
        }

        if (npc.relationship > 40) {
            lines += "\"${worldWisdom(npc)}\""
        }

        return lines.filter { it.isNotEmpty() }
    }

    private fun worldWisdom(npc: NPC): String = when (npc.personality) {
        NPCPersonality.HUMBLE     -> "Power without wisdom is a sword with no handle."
        NPCPersonality.RIGHTEOUS  -> "The righteous path is not the easiest one. That is precisely why it matters."
        NPCPersonality.COLD       -> "Trust the sword. Trust the technique. Trust nothing else."
        NPCPersonality.WARM       -> "Even the hardest cultivator needs someone who remembers their name."
        NPCPersonality.CUNNING    -> "Information is the only currency that never loses value."
        NPCPersonality.CHAOTIC    -> "The Killing Dao is not about killing. It is about absolute clarity."
        NPCPersonality.MELANCHOLY -> "We outlive everything we love. The question is what we do with that."
        NPCPersonality.ARROGANT   -> "If you want something, be strong enough to take it. Simple."
    }

    private fun interactionOutcome(npc: NPC, player: Player): NPCOutcome = when (npc.disposition) {
        NPCDisposition.DEVOTED, NPCDisposition.FRIENDLY -> when (Random.nextFloat()) {
            in 0f..0.28f -> NPCOutcome.GiftStones(Random.nextInt(5, 25))
            in 0.28f..0.48f -> NPCOutcome.GiftInsight(EventSystem.DAO_INSIGHTS.random())
            in 0.48f..0.65f -> NPCOutcome.HealPlayer
            in 0.65f..0.82f -> NPCOutcome.StrengthenBond(5)
            else -> NPCOutcome.TradeInfo
        }
        NPCDisposition.NEUTRAL -> when (Random.nextFloat()) {
            in 0f..0.35f -> NPCOutcome.StrengthenBond(2)
            in 0.35f..0.55f -> NPCOutcome.TradeInfo
            in 0.55f..0.70f -> NPCOutcome.GiftStones(Random.nextInt(2, 10))
            else -> NPCOutcome.Nothing
        }
        NPCDisposition.WARY -> if (Random.nextFloat() < 0.25f) NPCOutcome.StrengthenBond(1) else NPCOutcome.Nothing
        NPCDisposition.HOSTILE -> NPCOutcome.Combat
    }

    fun applyOutcome(state: GameState, npc: NPC, outcome: NPCOutcome): List<LogEntry> {
        val log = mutableListOf<LogEntry>()
        val p   = state.player
        when (outcome) {
            is NPCOutcome.GiftStones -> {
                p.spiritStones += outcome.amount
                npc.relationship = (npc.relationship + 3).coerceAtMost(100)
                log += LogEntry("${npc.name} presses ${outcome.amount} spirit stones into your hand. \"For the road.\"", LogType.NPC)
            }
            is NPCOutcome.GiftInsight -> {
                if (!p.daoInsights.contains(outcome.insight)) { p.daoInsights.add(outcome.insight); p.comprehension++ }
                p.daoHeart = (p.daoHeart + 5).coerceAtMost(100)
                log += LogEntry("${npc.name}: \"${outcome.insight}\"", LogType.NPC)
                log += LogEntry("The words settle into your Dao Heart. +1 Comprehension, +5 Dao Heart.", LogType.CULTIVATION)
            }
            NPCOutcome.HealPlayer -> {
                val heal = (p.maxHp * 0.3f).toInt()
                p.hp = (p.hp + heal).coerceAtMost(p.maxHp)
                log += LogEntry("${npc.name} channels healing Qi. +$heal HP.", LogType.NPC)
            }
            is NPCOutcome.StrengthenBond -> {
                npc.relationship = (npc.relationship + outcome.amount).coerceAtMost(100)
                log += LogEntry("Your understanding with ${npc.name} deepens. [Relationship: ${npc.relationship}]", LogType.NPC)
            }
            NPCOutcome.TradeInfo -> {
                log += LogEntry("${npc.name} lowers their voice: \"${worldRumour(state)}\"", LogType.NPC)
            }
            NPCOutcome.Combat -> log += LogEntry("${npc.name}'s killing intent surfaces. This ends in blood.", LogType.DANGER)
            NPCOutcome.Nothing -> log += LogEntry("${npc.name} turns and walks away without another word.", LogType.NPC)
        }
        return log
    }

    private fun worldRumour(state: GameState): String {
        val dynamic = mutableListOf(
            "There are ${state.npcs.count { it.alive }} cultivators active in the region right now.",
            "The strongest cultivator I've seen lately was in ${state.npcs.maxByOrNull { it.realm.power }?.currentLocation ?: "the wastes"}.",
        )
        if (state.npcs.any { it.isDemonic && it.alive }) dynamic.add("Something demonic has been spotted moving east. Be careful.")
        if (state.npcs.any { it.isRogue && it.alive }) dynamic.add("Rogue cultivators are growing bolder. The sects are worried.")
        val static = listOf(
            "A secret realm was spotted near Thunder Peak. It won't stay open long.",
            "The sects are recruiting more than usual. That's never a good sign.",
            "Someone found a Foundation Pill in the ancient ruins. Half the region is searching.",
            "An old spring in the valley heals everything, they say. I haven't found it.",
            "The Grand Auction opens soon. Rare artifacts are rumored to be listed.",
        )
        return (dynamic + static).random()
    }


    fun simulateNPCsOverTime(state: GameState, ticks: Int): List<LogEntry> {
        if (ticks <= 0) return emptyList()
        val log = mutableListOf<LogEntry>()
        val aliveNPCs = state.npcs.filter { it.alive }

        aliveNPCs.forEach { npc ->
            repeat(ticks) {
                // Advance cultivation
                val qiGain = (npc.realm.power * 2 + (1..5).random())
                // Chance to advance realm
                if (npc.realm.stage < 9 && (1..100).random() <= 2) {
                    val nextStage = npc.realm.stage + 1
                    npc.realm = Realm(npc.realm.tier, nextStage)
                    if ((1..100).random() <= 15) {
                        log += LogEntry(
                            "Word spreads: ${npc.name} has advanced their cultivation.",
                            LogType.WORLD
                        )
                    }
                }
                // Chance to change location
                if ((1..100).random() <= 10) {
                    val realLocations = LocationSystem.ALL_LOCATIONS.keys.toList()
                    if (realLocations.isNotEmpty()) {
                        npc.currentLocation = realLocations.random()
                    }
                }
                // Chance of going rogue or demonic
                if (!npc.isRogue && !npc.isDemonic && (1..1000).random() == 1) {
                    npc.isRogue = true
                    if ((1..100).random() <= 20) {
                        log += LogEntry(
                            "Disturbing news: ${npc.name} has abandoned their sect and gone rogue.",
                            LogType.WORLD
                        )
                    }
                }
            }
        }
        return log
    }

    fun onPlayerAction(state: GameState, action: PlayerActionType) {
        state.npcs.forEach { npc ->
            val delta = when (action) {
                PlayerActionType.HELPED_WEAK    -> if (npc.personality == NPCPersonality.RIGHTEOUS) 5 else 2
                PlayerActionType.MASSACRED      -> when (npc.personality) {
                    NPCPersonality.RIGHTEOUS -> -15; NPCPersonality.CHAOTIC -> 5; else -> -5
                }
                PlayerActionType.BETRAYED_ALLY  -> -10
                PlayerActionType.ADVANCED_REALM -> if (npc.id == "zhao_feng") -8 else 1
            }
            npc.relationship = (npc.relationship + delta).coerceIn(-100, 100)
        }
    }
}

// ── RESULT TYPES ──────────────────────────────────────────────────────────────

sealed class NPCEncounterResult {
    object NoNPC : NPCEncounterResult()
    data class Met(val npc: NPC, val dialogue: List<String>, val outcome: NPCOutcome) : NPCEncounterResult()
}

sealed class NPCOutcome {
    data class GiftStones(val amount: Int) : NPCOutcome()
    data class GiftInsight(val insight: String) : NPCOutcome()
    object HealPlayer : NPCOutcome()
    data class StrengthenBond(val amount: Int) : NPCOutcome()
    object TradeInfo : NPCOutcome()
    object Combat : NPCOutcome()
    object Nothing : NPCOutcome()
}

enum class PlayerActionType { HELPED_WEAK, MASSACRED, BETRAYED_ALLY, ADVANCED_REALM }
