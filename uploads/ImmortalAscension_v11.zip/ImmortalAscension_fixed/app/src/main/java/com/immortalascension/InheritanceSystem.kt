package com.immortalascension

import kotlin.random.Random

data class Inheritance(
    val id: String,
    val name: String,
    val donor: String,           // who left it
    val donorRealm: String,      // their realm when they left it
    val type: InheritanceType,
    val desc: String,
    val requirements: InheritanceReq,
    val rewards: InheritanceReward,
    val trialDesc: String        // what the player faces to claim it
)

data class InheritanceReq(
    val minRealm: RealmTier = RealmTier.QI_GATHERING,
    val minDaoHeart: Int = 0,
    val maxInnerDemon: Int = 100,
    val requiresDaoPath: String = "",    // empty = any path
    val requiresElement: TechElement? = null,
    val minComprehension: Int = 0,
    val forbiddenPath: String = ""       // can't have this path
)

data class InheritanceReward(
    val techId: String = "",
    val maxHpBonus: Int = 0,
    val maxQiBonus: Int = 0,
    val attackBonus: Int = 0,
    val defenseBonus: Int = 0,
    val comprehensionBonus: Int = 0,
    val daoHeartBonus: Int = 0,
    val daoInsight: String = "",
    val spiritStones: Int = 0,
    val titleGranted: String = ""
)

enum class InheritanceType { TECHNIQUE, BODY, DAO_HEART, LEGACY, FORBIDDEN }

object InheritanceSystem {

    val ALL_INHERITANCES = listOf(

        Inheritance(
            id = "sword_saint",
            name = "Sword Saint's Final Will",
            donor = "Wei Tianfeng, Sword Saint of the Azure Peak",
            donorRealm = "Nascent Soul — Peak Stage",
            type = InheritanceType.TECHNIQUE,
            desc = "The Sword Saint left his life's comprehension crystallised in a jade slip. The technique inside is incomplete — but the Dao intent is whole.",
            requirements = InheritanceReq(
                minRealm = RealmTier.QI_GATHERING, minDaoHeart = 40,
                requiresElement = TechElement.WIND, minComprehension = 15
            ),
            rewards = InheritanceReward(
                techId = "void_slash", attackBonus = 15,
                comprehensionBonus = 3, daoInsight = "The sword does not hesitate. Neither should the mind behind it.",
                titleGranted = "Heir of the Sword Saint"
            ),
            trialDesc = "The Sword Saint's will manifests — a thousand sword Qi projections surround you. You must walk forward. If you hesitate, they close in."
        ),

        Inheritance(
            id = "iron_body_legacy",
            name = "Indestructible Body Scripture",
            donor = "The Iron Demon, rogue Foundation cultivator",
            donorRealm = "Foundation — Perfect Stage",
            type = InheritanceType.BODY,
            desc = "The Iron Demon spent his life perfecting the physical body. His legacy is written into a single drop of blood stored in a jade vial.",
            requirements = InheritanceReq(
                minRealm = RealmTier.QI_GATHERING, requiresDaoPath = "Body Dao",
                minDaoHeart = 30
            ),
            rewards = InheritanceReward(
                maxHpBonus = 200, defenseBonus = 20,
                daoInsight = "The body is not a vessel. The body is the weapon.",
                titleGranted = "Inheritor of the Iron Body"
            ),
            trialDesc = "The legacy requires you to endure a thousand strikes of compressed Qi without defending. Pain tolerance is the only trial."
        ),

        Inheritance(
            id = "chaos_dao",
            name = "Chaos Patriarch's Forbidden Record",
            donor = "Unknown — the name was erased from the record deliberately",
            donorRealm = "Unknown",
            type = InheritanceType.FORBIDDEN,
            desc = "A technique so destructive the Patriarch destroyed their own name rather than let it be traced. The jade is cracked but still warm.",
            requirements = InheritanceReq(
                minRealm = RealmTier.FOUNDATION, maxInnerDemon = 40,
                requiresDaoPath = "Destruction Dao", minDaoHeart = 25,
                forbiddenPath = "Silence Dao"
            ),
            rewards = InheritanceReward(
                techId = "blood_phoenix", attackBonus = 25,
                daoInsight = "Destruction is not the absence of creation. It is creation's most honest form.",
                titleGranted = "Bearer of the Forbidden Record"
            ),
            trialDesc = "The forbidden record shows you everything it will cost. Your Dao Heart must be strong enough to accept that price and continue anyway."
        ),

        Inheritance(
            id = "ancient_healer",
            name = "Healer's Undying Compassion",
            donor = "Sun Meihua, Grand Healer of the Jade Lotus Sect",
            donorRealm = "Core Formation — Second Stage",
            type = InheritanceType.DAO_HEART,
            desc = "Grand Healer Sun did not leave a technique. She left her Dao Heart — compressed into a golden lotus that still blooms ten millennia later.",
            requirements = InheritanceReq(
                minRealm = RealmTier.QI_GATHERING, minDaoHeart = 60,
                maxInnerDemon = 30, minComprehension = 12
            ),
            rewards = InheritanceReward(
                maxQiBonus = 300, daoHeartBonus = 20, comprehensionBonus = 2,
                daoInsight = "To heal another is to understand that their suffering and yours are the same thing.",
                titleGranted = "Blessed by the Grand Healer"
            ),
            trialDesc = "The lotus asks you to relive your three greatest regrets. You cannot look away. You cannot fight. You can only understand."
        ),

        Inheritance(
            id = "silence_dao_master",
            name = "The Void Master's Stillness",
            donor = "Mo Wuyin, the Silence Patriarch",
            donorRealm = "Spirit Severing — First Stage",
            type = InheritanceType.LEGACY,
            desc = "The Silence Patriarch achieved Spirit Severing by severing sound from the world. His legacy is a chamber of absolute silence where his Dao lingers.",
            requirements = InheritanceReq(
                minRealm = RealmTier.FOUNDATION, requiresDaoPath = "Silence Dao",
                minDaoHeart = 70, maxInnerDemon = 20
            ),
            rewards = InheritanceReward(
                techId = "void_step", comprehensionBonus = 5,
                maxQiBonus = 500, daoInsight = "Silence is not the absence of sound. It is the presence of absolute understanding.",
                titleGranted = "Disciple of the Silence Patriarch"
            ),
            trialDesc = "You must sit in absolute silence for what feels like years. The silence speaks. You must listen without breaking."
        ),

        Inheritance(
            id = "demon_emperor_shard",
            name = "Demonic Emperor's Core Fragment",
            donor = "Fragment of an unknown Demonic Emperor",
            donorRealm = "Core Formation — Demonic Path",
            type = InheritanceType.FORBIDDEN,
            desc = "A shard of a Demonic Emperor's core. Taking it will accelerate your path — and your corruption. The heavens will notice.",
            requirements = InheritanceReq(
                minRealm = RealmTier.QI_GATHERING, maxInnerDemon = 100,
                forbiddenPath = "Samsara Dao"
            ),
            rewards = InheritanceReward(
                attackBonus = 30, maxHpBonus = 100,
                daoInsight = "The demonic path does not promise safety. It promises results.",
                titleGranted = "Touched by the Demonic Emperor"
            ),
            trialDesc = "The core fragment tests your will by flooding your mind with its former owner's memories — conquest, massacre, and an immortal loneliness. You must not break."
        )
    )

    // ── COMPATIBILITY CHECK ────────────────────────────────────────────────────

    data class CompatibilityResult(
        val compatible: Boolean,
        val score: Int,                   // 0-100
        val reason: String,
        val failReason: String = ""
    )

    fun checkCompatibility(player: Player, inh: Inheritance): CompatibilityResult {
        val req = inh.requirements
        val fails = mutableListOf<String>()

        if (player.realm.tier.ordinal < req.minRealm.ordinal)
            fails += "Realm too low (need ${req.minRealm.display})"
        if (player.daoHeart < req.minDaoHeart)
            fails += "Dao Heart too low (need ${req.minDaoHeart})"
        if (player.innerDemonLevel > req.maxInnerDemon)
            fails += "Inner Demon too high (max ${req.maxInnerDemon})"
        if (req.requiresDaoPath.isNotEmpty() && player.daoPath != req.requiresDaoPath)
            fails += "Requires ${req.requiresDaoPath}"
        if (req.forbiddenPath.isNotEmpty() && player.daoPath == req.forbiddenPath)
            fails += "Incompatible with your ${req.forbiddenPath}"
        if (req.minComprehension > 0 && player.comprehension < req.minComprehension)
            fails += "Comprehension too low (need ${req.minComprehension})"
        if (req.requiresElement != null) {
            val hasElement = player.techniques.any { it.element == req.requiresElement }
            if (!hasElement) fails += "Need a ${req.requiresElement.name.lowercase()} technique"
        }

        if (fails.isNotEmpty()) {
            return CompatibilityResult(false, 0, "Incompatible", fails.joinToString("; "))
        }

        // Soft score — higher = better match
        var score = 50
        if (player.daoHeart > req.minDaoHeart + 20) score += 15
        if (player.comprehension > req.minComprehension + 5) score += 10
        if (player.innerDemonLevel < 20) score += 10
        if (req.requiresDaoPath.isNotEmpty() && player.daoPath == req.requiresDaoPath) score += 15
        if (player.daoInsights.any { it == inh.rewards.daoInsight }) score -= 10  // already know it

        val desc = when {
            score >= 80 -> "Perfect compatibility. The inheritance resonates with your Dao."
            score >= 60 -> "Strong compatibility. You can claim this."
            else        -> "Marginal compatibility. Success is possible but not guaranteed."
        }

        return CompatibilityResult(true, score.coerceIn(0, 100), desc)
    }

    // ── ATTEMPT CLAIM ─────────────────────────────────────────────────────────

    fun attemptClaim(player: Player, inh: Inheritance): InheritanceClaimResult {
        val compat = checkCompatibility(player, inh)
        if (!compat.compatible) {
            return InheritanceClaimResult.Incompatible(compat.failReason)
        }

        val successChance = (compat.score / 100f * 0.7f + 0.15f).coerceIn(0.1f, 0.9f)
        val roll          = Random.nextFloat()

        return if (roll < successChance) {
            applyRewards(player, inh)
            InheritanceClaimResult.Success(
                "✦ INHERITANCE CLAIMED ✦\n${inh.trialDesc}\n\nYou endure. You accept. The inheritance is yours.\n" +
                rewardSummary(inh.rewards)
            )
        } else {
            // Failed — take damage, inner demon rises
            player.hp = (player.hp - player.maxHp / 4).coerceAtLeast(1)
            player.innerDemonLevel = (player.innerDemonLevel + 15).coerceAtMost(100)
            player.daoHeart = (player.daoHeart - 10).coerceAtLeast(0)
            InheritanceClaimResult.Failed(
                "⚠ INHERITANCE REJECTED ⚠\n${inh.trialDesc}\n\nThe legacy refuses you. The trial breaks something inside.\n" +
                "HP -25%  Inner Demon +15  Dao Heart -10"
            )
        }
    }

    private fun applyRewards(player: Player, inh: Inheritance) {
        val r = inh.rewards
        if (r.techId.isNotEmpty()) {
            val tech = EventSystem.RARE_TECHNIQUES.firstOrNull { it.id == r.techId }
                ?: EventSystem.STARTING_TECHNIQUES.firstOrNull { it.id == r.techId }
            if (tech != null && player.techniques.none { it.id == tech.id })
                player.techniques.add(tech.copy())
        }
        if (r.maxHpBonus > 0)         { player.maxHp += r.maxHpBonus; player.hp += r.maxHpBonus }
        if (r.maxQiBonus > 0)           player.maxQi += r.maxQiBonus
        if (r.attackBonus > 0)          player.attack += r.attackBonus
        if (r.defenseBonus > 0)         player.defense += r.defenseBonus
        if (r.comprehensionBonus > 0)   player.comprehension += r.comprehensionBonus
        if (r.daoHeartBonus > 0)        player.daoHeart = (player.daoHeart + r.daoHeartBonus).coerceAtMost(100)
        if (r.spiritStones > 0)         player.spiritStones += r.spiritStones
        if (r.daoInsight.isNotEmpty() && !player.daoInsights.contains(r.daoInsight))
            player.daoInsights.add(r.daoInsight)
        if (r.titleGranted.isNotEmpty() && !player.titles.contains(r.titleGranted))
            player.titles.add(r.titleGranted)

        // Forbidden inheritances raise inner demon
        if (inh.type == InheritanceType.FORBIDDEN)
            player.innerDemonLevel = (player.innerDemonLevel + 20).coerceAtMost(100)
    }

    private fun rewardSummary(r: InheritanceReward): String = buildString {
        if (r.techId.isNotEmpty()) appendLine("Technique acquired.")
        if (r.maxHpBonus > 0) appendLine("Max HP +${r.maxHpBonus}")
        if (r.maxQiBonus > 0) appendLine("Max Qi +${r.maxQiBonus}")
        if (r.attackBonus > 0) appendLine("Attack +${r.attackBonus}")
        if (r.comprehensionBonus > 0) appendLine("Comprehension +${r.comprehensionBonus}")
        if (r.daoHeartBonus > 0) appendLine("Dao Heart +${r.daoHeartBonus}")
        if (r.titleGranted.isNotEmpty()) appendLine("Title: 「${r.titleGranted}」")
        if (r.daoInsight.isNotEmpty()) appendLine("Insight: \"${r.daoInsight}\"")
    }.trim()

    // ── RANDOM DISCOVERY ──────────────────────────────────────────────────────

    fun randomDiscovery(player: Player): Inheritance? {
        val available = ALL_INHERITANCES.filter {
            checkCompatibility(player, it).compatible ||
            Random.nextFloat() < 0.3f  // sometimes find one you can't claim yet
        }
        return available.randomOrNull()
    }
}

sealed class InheritanceClaimResult {
    data class Success(val text: String) : InheritanceClaimResult()
    data class Failed(val text: String) : InheritanceClaimResult()
    data class Incompatible(val reason: String) : InheritanceClaimResult()
}
