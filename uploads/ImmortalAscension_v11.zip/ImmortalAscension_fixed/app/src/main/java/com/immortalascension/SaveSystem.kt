package com.immortalascension

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder

object SaveSystem {

    private const val PREF_NAME = "immortal_save"
    private const val KEY_GAME  = "game_state"
    private const val KEY_LAST_SAVE = "last_save_time"

    private val gson: Gson = GsonBuilder().serializeNulls().create()

    fun save(context: Context, engine: GameEngine) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_GAME, gson.toJson(engine.state))
            .putLong(KEY_LAST_SAVE, System.currentTimeMillis())
            .apply()
    }

    fun load(context: Context): GameState? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json  = prefs.getString(KEY_GAME, null) ?: return null
        return try {
            val state = gson.fromJson(json, GameState::class.java)
            sanitize(state)
            state
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Gson sets missing list/object fields to null instead of empty.
     * This breaks any .forEach / .any / .add call.  Fix every nullable list here.
     */
    private fun sanitize(s: GameState) {
        // ── Player ────────────────────────────────────────────────────────────
        with(s.player) {
            if (techniques  == null) techniques  = mutableListOf()
            if (inventory   == null) inventory   = mutableListOf()
            if (titles      == null) titles      = mutableListOf()
            if (daoInsights == null) daoInsights = mutableListOf()
            if (mentalScars == null) mentalScars = mutableListOf()
            // reputationState itself could be null for very old saves
            // (Gson won't call the default constructor)
            // We can't reassign a val, but reputationState is var so it's fine:
            if (reputationState == null) reputationState = ReputationState()
            with(reputationState) {
                if (rumours     == null) rumours     = mutableListOf()
                if (knownTitles == null) knownTitles = mutableListOf()
            }
            // Sanitize per-technique usageProfile
            techniques.forEach { tech ->
                // TechUsageProfile is a simple data class with ints - Gson handles fine
            }
        }

        // ── World ─────────────────────────────────────────────────────────────
        with(s.world) {
            if (discoveredPlaces == null) discoveredPlaces = mutableListOf("azure_wind_village")
            if (activeEvents     == null) activeEvents     = mutableListOf()
            if (eventHistory     == null) eventHistory     = mutableListOf()
            // Ensure locationId is valid
            if (locationId.isNullOrBlank() || !LocationSystem.ALL_LOCATIONS.containsKey(locationId)) {
                locationId = "azure_wind_village"
                location   = "Azure Wind Village"
            }
        }

        // ── NPCs ──────────────────────────────────────────────────────────────
        s.npcs.forEach { npc ->
            if (npc.goals             == null) npc.goals             = mutableListOf()
            if (npc.npcRelationships  == null) npc.npcRelationships  = mutableListOf()
            if (npc.techniques        == null) npc.techniques        = mutableListOf()
            if (npc.lifeEvents        == null) npc.lifeEvents        = mutableListOf()
            // Sanitize NPC location too
            if (!LocationSystem.ALL_LOCATIONS.containsKey(npc.currentLocation)) {
                npc.currentLocation = LocationSystem.ALL_LOCATIONS.keys.first()
            }
        }

        // ── Missions ──────────────────────────────────────────────────────────
        if (s.activeMissions == null) s.activeMissions = mutableListOf()

        // ── World News ────────────────────────────────────────────────────────
        if (s.worldNews == null) s.worldNews = mutableListOf()

        // ── Log ───────────────────────────────────────────────────────────────
        if (s.log == null) s.log = mutableListOf()

        // ── Combat (clear stale state) ────────────────────────────────────────
        s.combat?.let { cs ->
            if (cs.playerEffects == null) {
                s.combat = null  // corrupt combat state — safer to clear it
            }
        }
    }

    fun hasSave(context: Context): Boolean =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).contains(KEY_GAME)

    fun deleteSave(context: Context) =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().clear().apply()
}
