package com.immortalascension

import kotlin.random.Random

class GameEngine {

    var state = GameState()

    var onLogUpdate: ((List<LogEntry>) -> Unit)? = null
    var onStateChange: (() -> Unit)? = null
    var onCombatStart: ((Enemy) -> Unit)? = null
    var onCombatEnd: ((Boolean) -> Unit)? = null
    var onBreakthrough: ((String) -> Unit)? = null
    var onGameOver: (() -> Unit)? = null
    var onNPCEncounter: ((NPC, List<String>, NPCOutcome) -> Unit)? = null
    var onWorldEvent: ((WorldEvent) -> Unit)? = null
    var onWorldNews: ((List<WorldNewsEntry>) -> Unit)? = null

    // ── NEW GAME ───────────────────────────────────────────────────────────────

    fun newGame(playerName: String, fateless: Boolean = false) {
        state = GameState()
        val p = state.player
        p.name = playerName.ifBlank { "Nameless Cultivator" }
        p.fateless = fateless
        if (fateless) {
            p.comprehension -= 3
            p.luck -= 3
        }

        // Starting techniques
        val starts = EventSystem.STARTING_TECHNIQUES.shuffled().take(2)
        p.techniques.addAll(starts.map { it.copy() })

        // Populate world NPCs — named characters + random world population
        val namedNPCs = NPCSystem.createWorldNPCs()
        state.npcs.addAll(namedNPCs)
        val randomNPCs = NPCSystem.populateWorld(namedNPCs)
        state.npcs.addAll(randomNPCs)

        state.started = true
        // Ensure all lists initialized even if code path skipped something
        with(state.player) {
            if (techniques  == null) techniques  = mutableListOf()
            if (inventory   == null) inventory   = mutableListOf()
            if (titles      == null) titles      = mutableListOf()
            if (daoInsights == null) daoInsights = mutableListOf()
            if (mentalScars == null) mentalScars = mutableListOf()
        }

        log("─────────────────────────────────", LogType.SYSTEM)
        log("  IMMORTAL ASCENSION", LogType.SYSTEM)
        log("─────────────────────────────────", LogType.SYSTEM)
        log("")
        log("Name: ${p.name}${if (fateless) "  [Fateless]" else ""}")
        log("Realm: ${p.realm.display}")
        log("")
        log("You stand at the edge of ${state.world.location}.")
        log("Your spiritual root is weak — but it exists. That is enough.")
        log("")
        log("Starting techniques: ${starts.joinToString(", ") { it.name }}")
        log("")
        if (fateless) {
            log("You walk the Fateless Path. Heaven has not chosen you.", LogType.DANGER)
            log("Progression will be harder. Your potential is unlimited.", LogType.SYSTEM)
            log("")
        }
        log("Your cultivation journey begins.", LogType.SYSTEM)
        notifyAll()
    }

    // ── CULTIVATE ─────────────────────────────────────────────────────────────

    fun cultivate() {
        val p = state.player
        state.world.advance(4)
        log("")
        log("You settle into a meditative stance…", LogType.CULTIVATION)

        when (val r = EventSystem.cultivationEvent(state)) {
            is CultivationResult.Normal      -> log(r.text, LogType.CULTIVATION)
            is CultivationResult.Enlightenment -> log(r.text, LogType.BREAKTHROUGH)
            is CultivationResult.Deviation   -> {
                log(r.text, LogType.DANGER)
                if (!p.isAlive) { handleDeath(); return }
            }
        }

        if (p.qi >= p.maxQi) {
            log("")
            log("Your Qi has reached its limit. The path to the next realm beckons.", LogType.SYSTEM)
        }

        tickWorldEvents()
        runSimulator(1)
        notifyAll()
    }

    // ── BREAKTHROUGH ──────────────────────────────────────────────────────────

    fun breakthrough() {
        val p = state.player
        log("")
        log("You gather your Qi and face the heavenly barrier…", LogType.BREAKTHROUGH)
        state.world.advance(8)

        val r = try { EventSystem.attemptBreakthrough(state) }
        catch (e: Exception) {
            android.util.Log.e("Breakthrough", "attemptBreakthrough crash: ${e.message}", e)
            log("A disruption scatters your gathered Qi. The barrier holds.", LogType.DANGER)
            state.player.qi = state.player.maxQi / 2
            tickWorldEvents(); notifyAll(); return
        }
        when (r) {
            is BreakthroughResult.Perfect -> {
                log(r.text, LogType.BREAKTHROUGH)
                onBreakthrough?.invoke(r.text)
                try { handleBreakthroughSuccess(r.newRealm, perfect = true) }
                catch (e: Exception) { android.util.Log.e("BT", "handleBreakthroughSuccess crash: ${e.message}", e) }
            }
            is BreakthroughResult.Success -> {
                log(r.text, LogType.BREAKTHROUGH)
                onBreakthrough?.invoke(r.text)
                try { handleBreakthroughSuccess(r.newRealm, perfect = false) }
                catch (e: Exception) { android.util.Log.e("BT", "handleBreakthroughSuccess crash: ${e.message}", e) }
            }
            is BreakthroughResult.Flawed  -> { log(r.text, LogType.EVENT); onTitleCheck() }
            is BreakthroughResult.Failed  -> log(r.text, LogType.DANGER)
            is BreakthroughResult.Deviation -> {
                log(r.text, LogType.DANGER)
                if (!p.isAlive) { handleDeath(); return }
            }
            BreakthroughResult.AtPeak -> log("You have reached the peak. The path beyond has not yet revealed itself.", LogType.SYSTEM)
        }

        tickWorldEvents()
        runSimulator(1)
        notifyAll()
    }

    // ── EXPLORE ───────────────────────────────────────────────────────────────

    fun explore() {
        if (state.combat != null) return
        val p = state.player
        state.world.advance(2)
        log("")
        log(locationFlavour(), LogType.NORMAL)

        val r = try { EventSystem.exploreEvent(state) }
        catch (e: Exception) {
            android.util.Log.e("Explore", "exploreEvent crash: ${e.message}", e)
            log("Something disrupts your senses. The moment passes.", LogType.EVENT)
            tickWorldEvents(); notifyAll(); return
        }
        when (r) {
            is ExploreResult.Combat -> {
                val enemy = r.enemy
                log("A hostile presence materialises: ${enemy.name}  [${enemy.realm.display}]", LogType.DANGER)
                log("HP: ${enemy.hp}  ATK: ${enemy.attack}  DEF: ${enemy.defense}  SPD: ${enemy.speed}", LogType.COMBAT)
                state.combat = CombatState(enemy)
                onCombatStart?.invoke(enemy)
            }
            is ExploreResult.Event -> {
                log(r.text, r.type)
                // Track explore missions
                SectSystem.onExploreLocation(state, state.world.locationId)
            }
            ExploreResult.NPCEncounter -> {
                try { handleNPCExploreEncounter() }
                catch (e: Exception) {
                    android.util.Log.e("NPC", "NPC encounter crash: ${e.message}", e)
                    log("A cultivator passes by without engaging.", LogType.NPC)
                }
            }
        }

        tickWorldEvents()
        notifyAll()
    }

    private fun handleNPCExploreEncounter() {
        when (val enc = NPCSystem.npcEncounter(state)) {
            NPCEncounterResult.NoNPC -> {
                log("The area is quiet. No one crosses your path.", LogType.NORMAL)
            }
            is NPCEncounterResult.Met -> {
                val npc = enc.npc
                log("")
                enc.dialogue.forEach { log(it, LogType.NPC) }

                if (enc.outcome == NPCOutcome.Combat) {
                    // Turn NPC into a combat enemy
                    val enemy = npcToEnemy(npc)
                    log("")
                    log("${npc.name}'s killing intent is no longer hidden.", LogType.DANGER)
                    state.combat = CombatState(enemy)
                    npc.relationship = (npc.relationship - 20).coerceAtLeast(-100)
                    onCombatStart?.invoke(enemy)
                } else {
                    val outcomeLog = NPCSystem.applyOutcome(state, npc, enc.outcome)
                    outcomeLog.forEach { log(it.text, it.type) }
                    onNPCEncounter?.invoke(npc, enc.dialogue, enc.outcome)
                }
            }
        }
    }

    private fun npcToEnemy(npc: NPC): Enemy {
        val atk = npc.realm.power / 4 + 10
        val def = npc.realm.power / 6 + 5
        val hp  = npc.realm.power * 3 + 80
        return Enemy(
            name     = npc.name,
            realm    = npc.realm,
            hp       = hp, maxHp = hp,
            attack   = atk, defense = def, speed = 14,
            behavior = when (npc.personality) {
                NPCPersonality.ARROGANT, NPCPersonality.CHAOTIC -> EnemyBehavior.AGGRESSIVE
                NPCPersonality.CUNNING  -> EnemyBehavior.TACTICAL
                NPCPersonality.COLD     -> EnemyBehavior.CAUTIOUS
                else                    -> EnemyBehavior.TACTICAL
            },
            lootStones = 10..30,
            killDesc = "${npc.name} falls. Their eyes hold no surprise."
        )
    }

    // ── TRAVEL ────────────────────────────────────────────────────────────────

    fun travelTo(locationId: String) {
        if (state.combat != null) return
        val entries = LocationSystem.travelTo(state, locationId)
        entries.forEach { log(it.text, it.type) }

        // Simulate NPC movement when significant time passes
        val loc = LocationSystem.get(locationId)
        val npcLog = NPCSystem.simulateNPCsOverTime(state, loc.travelHours / 8)
        npcLog.forEach { log(it.text, it.type) }

        // Sect explore mission
        SectSystem.onExploreLocation(state, locationId)

        tickWorldEvents()
        runSimulator(1)
        notifyAll()
    }

    // ── COMBAT ────────────────────────────────────────────────────────────────

    fun combatAttack() {
        if (state.combat == null) return
        CombatSystem.playerAttack(state).forEach { log(it.text, it.type) }
        resolveCombatRound(defending = false)
    }

    fun combatTechnique(techIndex: Int) {
        if (state.combat == null) return
        val tech = state.player.techniques.getOrNull(techIndex) ?: return
        CombatSystem.playerTechnique(state, tech).forEach { log(it.text, it.type) }
        resolveCombatRound(defending = false)
    }

    fun combatDefend() {
        if (state.combat == null) return
        CombatSystem.playerDefend(state).forEach { log(it.text, it.type) }
        resolveCombatRound(defending = true)
    }

    fun combatFlee() {
        val (fled, entries) = CombatSystem.flee(state)
        entries.forEach { log(it.text, it.type) }
        if (fled) {
            log("You escape into the shadows.", LogType.EVENT)
            state.combat = null
            onCombatEnd?.invoke(false)
        } else {
            checkCombatEnd()
        }
        notifyAll()
    }

    fun useItemInCombat(itemIndex: Int) {
        val item = state.player.inventory.getOrNull(itemIndex) ?: return
        if (item.type != ItemType.PILL) {
            log("You can only use pills during combat.", LogType.DANGER)
            return
        }
        val result = InventorySystem.useItem(state.player, item)
        log(result, LogType.CULTIVATION)
        // Using item still costs enemy turn
        resolveCombatRound(defending = false)
    }

    private fun resolveCombatRound(defending: Boolean) {
        when (CombatSystem.checkBattleEnd(state)) {
            BattleResult.PLAYER_WIN  -> { endCombat(won = true); return }
            BattleResult.PLAYER_DEAD -> { handleDeath(); return }
            else -> {}
        }
        CombatSystem.enemyTurn(state, defending).forEach { log(it.text, it.type) }
        checkCombatEnd()
        notifyAll()
    }

    private fun checkCombatEnd() {
        when (CombatSystem.checkBattleEnd(state)) {
            BattleResult.PLAYER_WIN  -> endCombat(won = true)
            BattleResult.PLAYER_DEAD -> handleDeath()
            else -> {}
        }
    }

    private fun endCombat(won: Boolean) {
        val cs = state.combat ?: return
        val p  = state.player
        val e  = cs.enemy

        if (won) {
            val stones = e.lootStones.random()
            p.spiritStones += stones
            p.kills++
            p.battlesWon++

            if (e.killDesc.isNotBlank()) log(e.killDesc, LogType.EVENT)
            if (stones > 0) log("You claim $stones spirit stones.", LogType.EVENT)

            // Random item loot
            if (Random.nextFloat() < 0.35f) {
                val item = InventorySystem.randomLootItem(p.realm)
                if (item != null) {
                    EventSystem.addToInventory(p, item)
                    log("You find: ${item.name}. (Added to inventory)", LogType.EVENT)
                }
            }

            // Mastery gain
            p.techniques.forEach { it.mastery = (it.mastery + 1).coerceAtMost(100) }

            // Mission tracking
            SectSystem.onKillEnemy(state, e.name)
            NPCSystem.onPlayerAction(state, if (p.kills > 20 && p.karma < 0) PlayerActionType.MASSACRED else PlayerActionType.HELPED_WEAK)
            try { ReputationSystem.onKill(state, e.name, e.realm) } catch (ex: Exception) {}

            onTitleCheck()
        }

        state.combat = null
        onCombatEnd?.invoke(won)
        notifyAll()
    }

    // ── REST ──────────────────────────────────────────────────────────────────

    fun rest() {
        val p = state.player
        state.world.advance(6)
        val heal = (p.maxHp * 0.35f).toInt()
        val qi   = (p.maxQi * 0.15f).toInt()
        p.hp = (p.hp + heal).coerceAtMost(p.maxHp)
        p.qi = (p.qi + qi).coerceAtMost(p.maxQi)
        p.daoHeart       = (p.daoHeart + 3).coerceAtMost(100)
        p.innerDemonLevel = (p.innerDemonLevel - 3).coerceAtLeast(0)

        try { ReputationSystem.tickRumours(state, 1) } catch (e: Exception) {}
        log("")
        log(listOf(
            "You rest beneath a star-filled sky. The night heals old wounds.",
            "A few hours of stillness. Your meridians settle.",
            "Dreamless sleep in a forest hollow. You wake clearer.",
            "You meditate in rest. The world continues without you.",
            "Rain patters on leaves above. You breathe. Nothing more."
        ).random() + "  +$heal HP  +$qi Qi", LogType.CULTIVATION)

        tickWorldEvents()
        notifyAll()
    }

    // ── LONG SECLUSION ────────────────────────────────────────────────────────

    fun longSeclusion(days: Int) {
        val p = state.player
        log("")
        log("You enter seclusion for $days days, sealing yourself away from the world…", LogType.SYSTEM)

        var enlightenmentCount = 0
        var deviationCount     = 0

        repeat(days) {
            state.world.advance(24)
            when (val r = EventSystem.cultivationEvent(state)) {
                is CultivationResult.Enlightenment -> {
                    log(r.text, LogType.BREAKTHROUGH); enlightenmentCount++
                }
                is CultivationResult.Deviation -> {
                    log(r.text, LogType.DANGER); deviationCount++
                    if (!p.isAlive) { handleDeath(); return }
                }
                is CultivationResult.Normal -> { /* silent */ }
            }
            // Daily sect mission tick
            SectSystem.onCultivateDay(state)
        }

        // NPC simulation for elapsed days
        val npcLog = NPCSystem.simulateNPCsOverTime(state, days)
        npcLog.forEach { log(it.text, it.type) }

        log("")
        log("$days days of seclusion complete. The world has moved on.", LogType.EVENT)
        log("${state.world.timeDisplay}", LogType.SYSTEM)
        log("HP: ${p.hp}/${p.maxHp}  Qi: ${p.qi}/${p.maxQi}", LogType.NORMAL)
        if (enlightenmentCount > 0) log("Enlightenment states: $enlightenmentCount", LogType.BREAKTHROUGH)
        if (deviationCount     > 0) log("Qi deviations suffered: $deviationCount",   LogType.DANGER)

        if (p.qi >= p.maxQi) log("Your Qi reached its limit during seclusion.", LogType.SYSTEM)

        // World events may have fired during seclusion
        tickWorldEvents()
        runSimulator(days)
        notifyAll()
    }

    // ── INVENTORY ─────────────────────────────────────────────────────────────

    fun useItem(itemIndex: Int) {
        val p    = state.player
        val item = p.inventory.getOrNull(itemIndex) ?: return
        val result = InventorySystem.useItem(p, item)
        log("")
        log(result, LogType.EVENT)
        notifyAll()
    }

    fun shopBuy(item: Item) {
        val p = state.player
        if (p.spiritStones < item.value) {
            log("Insufficient spirit stones. (Need ${item.value}, have ${p.spiritStones})", LogType.DANGER)
            notifyAll()
            return
        }
        p.spiritStones -= item.value
        EventSystem.addToInventory(p, item.copy())
        log("Purchased: ${item.name} for ${item.value} spirit stones.", LogType.EVENT)
        notifyAll()
    }

    // ── SECT ──────────────────────────────────────────────────────────────────

    fun joinSect(sectId: String) {
        val entries = SectSystem.joinSect(state, sectId)
        entries.forEach { log(it.text, it.type) }
        notifyAll()
    }

    fun leaveSect() {
        val entries = SectSystem.leaveSect(state)
        entries.forEach { log(it.text, it.type) }
        notifyAll()
    }

    fun titheForMission(missionIndex: Int) {
        val mission = state.activeMissions.getOrNull(missionIndex) ?: return
        if (mission.type != MissionType.SPIRIT_STONE_TITHE) return
        val (ok, err) = SectSystem.titheStones(state, mission)
        if (!ok) log(err, LogType.DANGER)
        else {
            log("Tithe paid. Mission complete: ${mission.title}.", LogType.SECT)
            log("+${mission.contribution} contribution  +${mission.stoneReward} spirit stones returned.", LogType.SECT)
        }
        notifyAll()
    }

    // ── DAO PATH ──────────────────────────────────────────────────────────────

    fun chooseDaoPath(path: String) {
        val p = state.player
        if (p.daoPath.isNotEmpty()) {
            log("Your Dao path is already set: ${p.daoPath}", LogType.SYSTEM)
            return
        }
        p.daoPath = path
        val bonus = when (path) {
            "Sword Dao"     -> { p.attack += 8;     p.speed += 3;  "Attack +8, Speed +3" }
            "Body Dao"      -> { p.maxHp += 100;    p.bodyRefinementLevel = 1; p.defense += 5; "Max HP +100, Defense +5, Body Refinement 1" }
            "Freedom Dao"   -> { p.luck += 5;       p.speed += 5;  "Luck +5, Speed +5" }
            "Destruction Dao"->{ p.attack += 12;   p.daoHeart -= 10; "Attack +12 (Dao Heart -10 — destruction demands cost)" }
            "Silence Dao"   -> { p.spirit += 8;    p.comprehension += 3; "Spirit +8, Comprehension +3" }
            "Samsara Dao"   -> { p.daoHeart += 15; p.comprehension += 2; "Dao Heart +15, Comprehension +2" }
            else            -> "No bonus — an unknown path."
        }
        log("")
        log("✦ DAO PATH CHOSEN: $path ✦", LogType.BREAKTHROUGH)
        log("Your cultivation now flows along the $path. $bonus", LogType.BREAKTHROUGH)
        log("\"${EventSystem.DAO_INSIGHTS.random()}\"", LogType.CULTIVATION)
        notifyAll()
    }

    // ── WORLD EVENTS ──────────────────────────────────────────────────────────

    private fun tickWorldEvents() {
        val entries = WorldEventSystem.checkWorldEvents(state)
        entries.forEach { log(it.text, it.type) }
        if (entries.isNotEmpty()) {
            state.world.activeEvents.lastOrNull()?.let { onWorldEvent?.invoke(it) }
        }
    }

    private fun runSimulator(days: Int) {
        try {
            val news = NPCSimulator.tick(state, days)
            if (news.isNotEmpty()) {
                state.worldNews.addAll(news)
                if (state.worldNews.size > 50) {
                    state.worldNews.subList(0, state.worldNews.size - 50).clear()
                }
                onWorldNews?.invoke(news)
            }
        } catch (e: Exception) {
            // Simulator errors must never propagate to the player UI
            android.util.Log.e("NPCSimulator", "Simulator tick error: ${e.message}", e)
        }
    }

    // ── TITLE / ACHIEVEMENT CHECK ─────────────────────────────────────────────

    private fun onTitleCheck() {
        val p = state.player
        data class TitleCheck(val condition: Boolean, val title: String)

        val checks = listOf(
            TitleCheck(p.battlesWon >= 50  && !p.titles.contains("Blade of Fifty Battles"),      "Blade of Fifty Battles"),
            TitleCheck(p.battlesWon >= 100 && !p.titles.contains("Blade of a Hundred Battles"),  "Blade of a Hundred Battles"),
            TitleCheck(p.kills >= 30       && p.karma < -10 && !p.titles.contains("The Merciless"),   "The Merciless"),
            TitleCheck(p.daoInsights.size >= 5 && !p.titles.contains("Seeker of Truth"),          "Seeker of Truth"),
            TitleCheck(p.daoInsights.size >= 10 && !p.titles.contains("Sage of the Dao"),          "Sage of the Dao"),
            TitleCheck(p.realm.tier == RealmTier.FOUNDATION && !p.titles.contains("Foundation Breaker"), "Foundation Breaker"),
            TitleCheck(p.realm.tier == RealmTier.CORE_FORMATION && !p.titles.contains("Core Formation Master"), "Core Formation Master"),
            TitleCheck(p.realm.tier == RealmTier.NASCENT_SOUL  && !p.titles.contains("Nascent Soul Cultivator"), "Nascent Soul Cultivator"),
            TitleCheck(p.daoHeart >= 90 && !p.titles.contains("Unbreakable Dao Heart"),          "Unbreakable Dao Heart"),
            TitleCheck(p.innerDemonLevel >= 80 && !p.titles.contains("Demon-Touched"),             "Demon-Touched"),
            TitleCheck(p.daoPath.isNotEmpty() && !p.titles.contains("Walker of the ${p.daoPath}"), "Walker of the ${p.daoPath}"),
            TitleCheck(p.luck >= 20 && !p.titles.contains("Heaven's Favourite"),                  "Heaven's Favourite"),
            TitleCheck(p.fateless && p.realm.tier.ordinal >= RealmTier.FOUNDATION.ordinal
                       && !p.titles.contains("The Fateless One"),                                  "The Fateless One"),
        )

        checks.filter { it.condition }.forEach { check ->
            p.titles.add(check.title)
            log("")
            log("✦ New title: 「${check.title}」", LogType.BREAKTHROUGH)
        }
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private fun handleBreakthroughSuccess(newRealm: Realm, perfect: Boolean) {
        try { onTitleCheck() } catch (e: Exception) {}
        try { SectSystem.onRealmAdvance(state) } catch (e: Exception) {}
        try { NPCSystem.onPlayerAction(state, PlayerActionType.ADVANCED_REALM) } catch (e: Exception) {}
        try { ReputationSystem.onBreakthrough(state, newRealm) } catch (e: Exception) {}

        // Heavenly Tribulation for Foundation and above
        if (TribulationSystem.shouldTrigger(newRealm, state.player)) {
            val waves  = TribulationSystem.generate(newRealm, state.player)
            val result = TribulationSystem.resolve(state.player, waves)
            val narr   = TribulationSystem.buildNarrative(newRealm, result, state.player)
            log(""); log(narr, if (result.survived) LogType.BREAKTHROUGH else LogType.DANGER)
            if (result.newTitle.isNotEmpty()) log("✦ Title: 「${result.newTitle}」", LogType.BREAKTHROUGH)
            if (!result.survived) {
                log("The tribulation repels your advancement. You remain at your previous realm.", LogType.DANGER)
            }
        }
    }

    private fun handleDeath() {
        val p = state.player
        log(""); log("Your vision darkens. The world grows silent.", LogType.DANGER)
        log("${p.name} — ${p.realm.display} — ${state.world.timeDisplay}", LogType.SYSTEM)
        log("Battles won: ${p.battlesWon}  Days cultivated: ${p.cultivationDays}", LogType.SYSTEM)
        state.gameOver = true
        state.combat   = null
        onGameOver?.invoke()
        notifyAll()
    }

    private fun locationFlavour(): String {
        val loc     = LocationSystem.get(state.world.locationId)
        val weather = state.world.weather
        val time    = state.world.timeOfDay
        val specific = loc.flavorLines.randomOrNull()
        val ambient  = when (weather) {
            "Misty"  -> "Thick mist clings to ${loc.name}."
            "Stormy" -> "Thunder rolls. Lightning cracks the sky over ${loc.name}."
            "Rainy"  -> "Rain falls steadily over ${loc.name}."
            "Serene" -> "An unusual stillness has settled over ${loc.name}."
            else -> when (time) {
                "Dawn"     -> "First light spills across ${loc.name}."
                "Night","Midnight" -> "Darkness wraps ${loc.name}. Your spiritual sense guides you."
                "Dusk"     -> "Long shadows stretch across ${loc.name}."
                else       -> "You move through ${loc.name}, senses sharp."
            }
        }
        return if (specific != null) "$ambient $specific" else ambient
    }

    private fun log(text: String, type: LogType = LogType.NORMAL) {
        val entry = LogEntry(text, type)
        state.log.add(entry)
        onLogUpdate?.invoke(listOf(entry))
    }

    private fun notifyAll() = onStateChange?.invoke()
}
