package com.immortalascension

import kotlin.random.Random

// A Secret Realm is a temporary pocket dimension with its own rules,
// multi-room exploration, and a final boss / treasure.

data class SecretRealmRoom(
    val id: Int,
    val name: String,
    val desc: String,
    val type: RoomType,
    var cleared: Boolean = false,
    val enemy: Enemy? = null,
    val lootStones: Int = 0,
    val lootItem: Item? = null,
    val qiGain: Int = 0,
    val statBonus: StatBonus? = null,
    val hazard: String = "",           // flavour for traps / environmental
    val daoInsight: String = ""
)

enum class RoomType { ENTRANCE, COMBAT, TREASURE, REST, MYSTERY, INHERITANCE, BOSS }

data class StatBonus(val stat: String, val amount: Int)

data class SecretRealm(
    val name: String,
    val desc: String,
    val daysRemaining: Int,
    val rooms: List<SecretRealmRoom>,
    var currentRoom: Int = 0,
    var completed: Boolean = false,
    val era: String = "",              // flavour: which ancient sect built this
    val realmBonusMult: Float = 1.0f  // how good the loot is
)

object SecretRealmSystem {

    // ── REALM TEMPLATES ───────────────────────────────────────────────────────

    private val REALM_NAMES = listOf(
        "Shattered Heaven Vault", "Azure Immortal's Tomb", "Thousand Sword Cave",
        "Collapsed Star Palace", "Forgotten Demon Sanctum", "Ancient Qi Convergence",
        "Sealed Nascent Passage", "Crimson Cloud Mausoleum", "Boundless Void Fragment",
        "Dying Immortal's Cache"
    )

    private val REALM_ERAS = listOf(
        "built by a sect that ascended ten thousand years ago",
        "carved from void Qi during the last great tribulation war",
        "the personal tomb of a Spirit Severing patriarch",
        "a collapsed pocket dimension from an ancient battle",
        "sealed by a dying Nascent Soul cultivator as a final inheritance"
    )

    // ── GENERATION ────────────────────────────────────────────────────────────

    fun generate(playerRealm: Realm, daysLeft: Int = 28): SecretRealm {
        val name      = REALM_NAMES.random()
        val era       = REALM_ERAS.random()
        val lootMult  = 1.0f + playerRealm.tier.ordinal * 0.3f
        val roomCount = Random.nextInt(4, 8)
        val rooms     = mutableListOf<SecretRealmRoom>()

        // Room 0 — always entrance
        rooms += SecretRealmRoom(
            id = 0, name = "Realm Entrance",
            desc = "The spatial rift seals behind you. Ancient Qi floods your senses. The air here is ten thousand years old.",
            type = RoomType.ENTRANCE,
            qiGain = (playerRealm.qiCap / 6).coerceAtLeast(30)
        )

        // Middle rooms — randomised
        repeat(roomCount - 2) { i ->
            rooms += generateRoom(i + 1, playerRealm, lootMult)
        }

        // Final room — always boss or inheritance
        rooms += generateFinalRoom(roomCount - 1, playerRealm, lootMult)

        return SecretRealm(
            name = name, desc = "A secret realm, $era.",
            daysRemaining = daysLeft, rooms = rooms, era = era, realmBonusMult = lootMult
        )
    }

    private fun generateRoom(id: Int, playerRealm: Realm, lootMult: Float): SecretRealmRoom {
        return when (Random.nextInt(6)) {
            0 -> combatRoom(id, playerRealm)
            1 -> treasureRoom(id, playerRealm, lootMult)
            2 -> restRoom(id, playerRealm)
            3 -> mysteryRoom(id, playerRealm)
            4 -> combatRoom(id, playerRealm)    // combat more common
            else -> treasureRoom(id, playerRealm, lootMult)
        }
    }

    private fun combatRoom(id: Int, playerRealm: Realm): SecretRealmRoom {
        val enemy = buildRealmEnemy(playerRealm, isBoss = false)
        val names = listOf(
            "Guardian Chamber", "Seal Room", "Trial of Blades",
            "Ancient Sentinel Hall", "Qi-Locked Passage"
        )
        val descs = listOf(
            "A guardian left behind by the original sect stirs as you enter.",
            "An ancient formation activates — a warrior of Qi takes shape.",
            "The room seals. Something waits inside.",
            "Statues line the walls. One of them is not a statue."
        )
        return SecretRealmRoom(
            id = id, name = names.random(), desc = descs.random(),
            type = RoomType.COMBAT, enemy = enemy,
            lootStones = Random.nextInt(15, 50),
            lootItem = if (Random.nextFloat() < 0.4f) InventorySystem.randomLootItem(playerRealm) else null
        )
    }

    private fun treasureRoom(id: Int, playerRealm: Realm, lootMult: Float): SecretRealmRoom {
        val stones = (Random.nextInt(30, 100) * lootMult).toInt()
        val item   = InventorySystem.randomLootItem(playerRealm)
        val names  = listOf("Treasury Alcove", "Hidden Cache", "Spirit Stone Vein", "Sealed Reliquary")
        val descs  = listOf(
            "A sealed alcove. The formation protecting it finally exhausted itself.",
            "Spirit stones line the walls — ten thousand years of accumulation.",
            "A storage ring left behind, still full.",
            "The treasure room is small but what is inside is not."
        )
        return SecretRealmRoom(
            id = id, name = names.random(), desc = descs.random(),
            type = RoomType.TREASURE, cleared = false,
            lootStones = stones, lootItem = item
        )
    }

    private fun restRoom(id: Int, playerRealm: Realm): SecretRealmRoom {
        val qiGain = playerRealm.qiCap / 4
        val statBonuses = listOf(
            StatBonus("comprehension", 1), StatBonus("luck", 1),
            StatBonus("daoHeart", 5), StatBonus("innerDemon", -10)
        )
        val names = listOf("Meditation Alcove", "Spirit Spring Chamber", "Ancestor's Rest", "Qi Convergence Node")
        val descs = listOf(
            "A small chamber where Qi pools in perfect stillness. Something here encourages meditation.",
            "A natural spring of spiritual water flows from the wall. Drinking it clears the mind.",
            "The ancestor who built this realm left a meditation room. The imprint of their calm remains.",
            "Qi lines converge here. Sitting for even a short time yields clarity."
        )
        return SecretRealmRoom(
            id = id, name = names.random(), desc = descs.random(),
            type = RoomType.REST, cleared = false,
            qiGain = qiGain, statBonus = statBonuses.random()
        )
    }

    private fun mysteryRoom(id: Int, playerRealm: Realm): SecretRealmRoom {
        val insight = EventSystem.DAO_INSIGHTS.random()
        val hazards = listOf(
            "The floor shifts. A formation array activates — testing your Dao Heart.",
            "An illusion fills the room. Something from your past stands before you.",
            "The walls close in, then stop. This was a test. You passed.",
            "The room asks something of you without words."
        )
        return SecretRealmRoom(
            id = id, name = "Mystery Chamber", desc = hazards.random(),
            type = RoomType.MYSTERY, cleared = false,
            daoInsight = insight, statBonus = StatBonus("daoHeart", 8),
            qiGain = playerRealm.qiCap / 8
        )
    }

    private fun generateFinalRoom(id: Int, playerRealm: Realm, lootMult: Float): SecretRealmRoom {
        return if (Random.nextFloat() < 0.35f) {
            // Inheritance room — no combat, but ancient technique
            SecretRealmRoom(
                id = id, name = "The Patriarch's Chamber",
                desc = "At the deepest point of the realm stands a crystallised figure — the original owner, preserved in Qi for ten thousand years. Their eyes open as you approach.",
                type = RoomType.INHERITANCE, cleared = false,
                lootStones = (Random.nextInt(80, 200) * lootMult).toInt(),
                statBonus = StatBonus("comprehension", 3),
                daoInsight = EventSystem.DAO_INSIGHTS.random()
            )
        } else {
            // Boss room
            val boss = buildRealmEnemy(playerRealm, isBoss = true)
            SecretRealmRoom(
                id = id, name = "The Final Seal",
                desc = "The last guardian of this realm. It has been waiting since the day the sect fell. Its Qi is ancient and patient.",
                type = RoomType.BOSS, cleared = false,
                enemy = boss,
                lootStones = (Random.nextInt(100, 300) * lootMult).toInt(),
                lootItem = InventorySystem.randomLootItem(playerRealm),
                statBonus = StatBonus("maxHp", 40),
                daoInsight = EventSystem.DAO_INSIGHTS.random()
            )
        }
    }

    private fun buildRealmEnemy(playerRealm: Realm, isBoss: Boolean): Enemy {
        val bossNames = listOf(
            "Ancient Formation Guardian", "Ten-Thousand-Year Wraith",
            "Sealed Demon Patriarch", "Dao Heart Phantom",
            "Last Disciple of the Fallen Sect", "Primordial Qi Construct"
        )
        val normalNames = listOf(
            "Realm Guardian", "Ancient Spirit", "Qi Construct",
            "Sealed Demon", "Formation Soldier", "Ancestral Phantom"
        )

        val nameMult = if (isBoss) 2.0f else 1.0f
        val tier     = playerRealm.tier
        val stage    = if (isBoss) playerRealm.stage else (playerRealm.stage - 1).coerceAtLeast(1)
        val realm    = Realm(tier, stage)

        val hp  = ((realm.power * 5 + 200) * nameMult).toInt()
        val atk = ((realm.power / 3 + 20) * nameMult).toInt()
        val def = ((realm.power / 5 + 10) * nameMult).toInt()

        return Enemy(
            name = if (isBoss) bossNames.random() else normalNames.random(),
            realm = realm, hp = hp, maxHp = hp,
            attack = atk, defense = def, speed = 15,
            behavior = if (isBoss) EnemyBehavior.TACTICAL else EnemyBehavior.AGGRESSIVE,
            lootStones = if (isBoss) 50..150 else 10..40,
            killDesc = if (isBoss)
                "The ancient guardian's form dissolves into pure Qi. The realm trembles."
            else
                "The construct shatters. Qi dissipates back into the realm."
        )
    }

    // ── ROOM RESOLUTION ───────────────────────────────────────────────────────

    /** Apply a cleared room's rewards to the player. Returns narrative lines. */
    fun resolveRoom(room: SecretRealmRoom, player: Player): List<String> {
        if (room.cleared) return listOf("This room has already been cleared.")
        room.cleared = true
        val lines = mutableListOf<String>()

        if (room.qiGain > 0) {
            player.qi = (player.qi + room.qiGain).coerceAtMost(player.maxQi)
            lines += "+${room.qiGain} Qi absorbed from ambient realm energy."
        }
        if (room.lootStones > 0) {
            player.spiritStones += room.lootStones
            lines += "+${room.lootStones} spirit stones recovered."
        }
        if (room.lootItem != null) {
            EventSystem.addToInventory(player, room.lootItem.copy())
            lines += "${room.lootItem.name} added to inventory."
        }
        if (room.daoInsight.isNotEmpty() && !player.daoInsights.contains(room.daoInsight)) {
            player.daoInsights.add(room.daoInsight)
            player.comprehension++
            lines += "Dao insight: \"${room.daoInsight}\""
            lines += "+1 Comprehension."
        }
        room.statBonus?.let { bonus ->
            when (bonus.stat) {
                "comprehension" -> { player.comprehension += bonus.amount;   lines += "+${bonus.amount} Comprehension." }
                "daoHeart"      -> { player.daoHeart = (player.daoHeart + bonus.amount).coerceAtMost(100); lines += "+${bonus.amount} Dao Heart." }
                "luck"          -> { player.luck += bonus.amount;            lines += "+${bonus.amount} Luck." }
                "innerDemon"    -> { player.innerDemonLevel = (player.innerDemonLevel + bonus.amount).coerceAtLeast(0); lines += "${bonus.amount} Inner Demon." }
                "maxHp"         -> { player.maxHp += bonus.amount; player.hp = (player.hp + bonus.amount).coerceAtMost(player.maxHp); lines += "+${bonus.amount} Max HP." }
                "attack"        -> { player.attack += bonus.amount;          lines += "+${bonus.amount} Attack." }
            }
        }

        return lines
    }

    fun isComplete(realm: SecretRealm): Boolean =
        realm.rooms.all { it.cleared }

    fun currentRoom(realm: SecretRealm): SecretRealmRoom? =
        realm.rooms.getOrNull(realm.currentRoom)

    fun advance(realm: SecretRealm): Boolean {
        if (realm.currentRoom < realm.rooms.size - 1) {
            realm.currentRoom++
            return true
        }
        return false
    }
}
