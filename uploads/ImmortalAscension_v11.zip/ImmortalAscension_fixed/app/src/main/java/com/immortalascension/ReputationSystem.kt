package com.immortalascension

import kotlin.random.Random



object ReputationSystem {

    // ── EVENTS THAT GENERATE REPUTATION ──────────────────────────────────────

    fun onBreakthrough(state: GameState, newRealm: Realm) {
        val rep = state.player.reputationState
        rep.fame += when (newRealm.tier) {
            RealmTier.FOUNDATION     -> 50
            RealmTier.CORE_FORMATION -> 150
            RealmTier.NASCENT_SOUL   -> 400
            RealmTier.SPIRIT_SEVERING-> 800
            else -> 10
        }

        // Rumour about the breakthrough
        if (newRealm.tier.ordinal >= RealmTier.FOUNDATION.ordinal) {
            val trueRumour = Rumour(
                id = "bt_${state.world.year}",
                text = "A cultivator reached ${newRealm.display} near ${state.world.location}. The tribulation clouds were visible for miles.",
                isTrue = true, subject = "player_breakthrough",
                spreadDays = Random.nextInt(5, 20)
            )
            rep.rumours.add(trueRumour)

            // Possible distorted version
            if (Random.nextFloat() < 0.4f) {
                val distorted = Rumour(
                    id = "bt_dist_${state.world.year}",
                    text = distortedBreakthroughRumour(state.player.name, newRealm),
                    isTrue = false, subject = "player_breakthrough",
                    spreadDays = Random.nextInt(3, 15), distorted = true
                )
                rep.rumours.add(distorted)
            }
        }
    }

    fun onKill(state: GameState, enemyName: String, enemyRealm: Realm) {
        val rep = state.player.reputationState
        val p   = state.player

        // Fame/infamy based on realm gap and karma
        val realmGap = p.realm.dominates(enemyRealm)
        if (realmGap < 0) {
            // Killed something stronger — huge fame boost
            rep.fame  += 80
            rep.infamy += 20
            addRumour(state, Rumour(
                id = "kill_${state.world.year}_${state.world.day}",
                text = "${p.name} was seen defeating a ${enemyRealm.display} cultivator in ${state.world.location}. The fight lasted only moments.",
                isTrue = true, subject = "player_kill",
                spreadDays = Random.nextInt(3, 12)
            ))
        } else if (p.kills > 0 && p.kills % 10 == 0) {
            rep.infamy += 15
            if (p.karma < -30) {
                addRumour(state, Rumour(
                    id = "massacre_${p.kills}",
                    text = "Cultivators in ${state.world.location} say a ${p.realm.display} cultivator has left ${p.kills} bodies in the region.",
                    isTrue = true, subject = "player_massacre",
                    spreadDays = Random.nextInt(5, 20)
                ))
            }
        }
    }

    fun onHelpedWeak(state: GameState) {
        val rep = state.player.reputationState
        rep.fame     += 10
        rep.sainthood = (rep.sainthood + 3).coerceAtMost(100)
        if (rep.sainthood > 30 && Random.nextFloat() < 0.2f) {
            addRumour(state, Rumour(
                id = "saint_${state.world.year}",
                text = "Word spreads that a cultivator named ${state.player.name} helped ordinary people near ${state.world.location}. Rare enough to be notable.",
                isTrue = true, subject = "player_saint",
                spreadDays = Random.nextInt(10, 30)
            ))
        }
    }

    fun onSectJoined(state: GameState, sectName: String) {
        val rep = state.player.reputationState
        rep.fame += 30
        addRumour(state, Rumour(
            id = "sect_join_${state.world.year}",
            text = "A new disciple has joined $sectName. They say the new recruit's talent is unusual.",
            isTrue = true, subject = "player_sect",
            spreadDays = Random.nextInt(5, 15)
        ))
    }

    fun onDaoPathChosen(state: GameState) {
        val rep  = state.player.reputationState
        val path = state.player.daoPath
        rep.fame += 20
        if (path == "Destruction Dao" || path == "Freedom Dao") {
            rep.infamy += 15
            addRumour(state, Rumour(
                id = "dao_${state.world.year}",
                text = "A wandering cultivator in the region appears to walk the $path. Observers describe something unsettling about their presence.",
                isTrue = true, subject = "player_dao",
                spreadDays = Random.nextInt(8, 25)
            ))
        }
    }

    // ── RUMOUR SPREADING ──────────────────────────────────────────────────────

    fun tickRumours(state: GameState, days: Int) {
        val rep = state.player.reputationState
        rep.rumours.forEach { r ->
            r.daysOld += days

            // Distortion over time
            if (!r.distorted && r.daysOld > r.spreadDays * 2 && Random.nextFloat() < 0.15f) {
                r.distorted = true
            }

            // Fame from spreading rumours
            if (r.daysOld >= r.spreadDays) {
                rep.fame = (rep.fame + 5).coerceAtMost(1000)
            }
        }

        // Clean up very old rumours
        if (rep.rumours.size > 20) {
            rep.rumours.sortByDescending { it.daysOld }
            rep.rumours.subList(20, rep.rumours.size).clear()
        }

        // Update world title
        updateWorldTitle(rep, state.player)
    }

    private fun updateWorldTitle(rep: ReputationState, player: Player) {
        val title = when {
            rep.fame > 800 && rep.sainthood > 70         -> "${player.name} the Immortal Saint"
            rep.fame > 800 && rep.demonicRep > 70        -> "${player.name} the Demon of an Age"
            rep.fame > 600 && rep.sainthood > 50         -> "The Righteous ${player.name}"
            rep.fame > 600 && rep.infamy > 400           -> "${player.name} the Feared"
            rep.fame > 400                               -> "${player.name} of the ${player.realm.display}"
            rep.fame > 200                               -> "Cultivator ${player.name}"
            rep.infamy > 300                             -> "The Wandering Blade"
            else                                         -> "Unknown Cultivator"
        }
        if (!rep.knownTitles.contains(title)) {
            rep.knownTitles.add(title)
        }
    }

    // ── WHAT THE WORLD SAYS ABOUT YOU ─────────────────────────────────────────

    fun getActiveRumours(state: GameState): List<Rumour> =
        state.player.reputationState.rumours
            .filter { it.daysOld >= it.spreadDays }
            .sortedByDescending { it.daysOld }
            .take(8)

    fun getReputationSummary(state: GameState): String {
        val rep   = state.player.reputationState
        val p     = state.player
        return buildString {
            appendLine("── How the World Sees You ──")
            appendLine("Known as: ${rep.knownTitles.lastOrNull() ?: "Unknown Cultivator"}")
            appendLine("Fame: ${rep.fame}/1000   Infamy: ${rep.infamy}/1000")
            if (rep.sainthood > 20)   appendLine("Righteous Reputation: ${rep.sainthood}/100")
            if (rep.demonicRep > 20)  appendLine("Demonic Reputation: ${rep.demonicRep}/100")
            appendLine()
            val active = getActiveRumours(state)
            if (active.isEmpty()) {
                appendLine("No rumours have spread about you yet.")
            } else {
                appendLine("── Active Rumours ──")
                active.forEach { r ->
                    val tag = if (r.distorted) " [distorted]" else ""
                    appendLine("• ${r.text}$tag")
                }
            }
        }.trim()
    }

    // ── NPC REACTION BASED ON REPUTATION ──────────────────────────────────────

    fun reputationModifier(rep: ReputationState, npcPersonality: NPCPersonality): Int {
        return when (npcPersonality) {
            NPCPersonality.RIGHTEOUS -> if (rep.sainthood > 40) 15 else if (rep.demonicRep > 40) -20 else 0
            NPCPersonality.CHAOTIC   -> if (rep.infamy > 300) 10 else 0
            NPCPersonality.ARROGANT  -> if (rep.fame > 500) 5 else if (rep.fame < 100) -10 else 0
            NPCPersonality.HUMBLE    -> if (rep.sainthood > 50) 10 else 0
            NPCPersonality.COLD      -> 0
            else -> if (rep.fame > 300) 5 else 0
        }
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private fun addRumour(state: GameState, r: Rumour) {
        state.player.reputationState.rumours.add(r)
    }

    private fun distortedBreakthroughRumour(name: String, realm: Realm): String {
        val exaggerations = listOf(
            "They say $name ascended to ${realm.tier.display} by defeating an ancient immortal single-handedly.",
            "Rumour has it $name broke through ${realm.display} in one night — unheard of.",
            "Word is $name caused a heavenly phenomenon that lasted three days during their breakthrough.",
            "Someone claims $name is actually a reincarnated immortal — the ${realm.display} breakthrough proves it."
        )
        return exaggerations.random()
    }
}

