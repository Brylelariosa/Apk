package com.browser.app

import android.content.Context
import android.util.AttributeSet
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView

/**
 * WebView subclass that exposes onScrollChanged as a public callback so
 * MainActivity can react to page scrolls without polling or reflection.
 */
class ScrollAwareWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    /** Called on every scroll change. Invoked on the main thread. */
    var onScrollCallback: ((dy: Int) -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollCallback?.invoke(t - oldt)
    }

    /**
     * Called by Android's IME framework when a text input inside the WebView
     * is focused and ready for typing. In immersive mode the system skips
     * showing the keyboard automatically, so we request it explicitly here —
     * this is the correct moment because the input connection is already set up.
     */
    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        val ic = super.onCreateInputConnection(outAttrs)
        if (ic != null) {
            post {
                (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
            }
        }
        return ic
    }
}
