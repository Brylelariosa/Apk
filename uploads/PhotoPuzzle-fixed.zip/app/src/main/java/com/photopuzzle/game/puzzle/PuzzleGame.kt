package com.photopuzzle.game.puzzle

import android.graphics.PointF
import android.graphics.Path
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Holds one puzzle's pieces and the rules for moving/connecting/winning.
 * Deliberately has no Android View/Canvas dependency -- [PuzzleBoardView]
 * drives this and draws whatever it reports, but the rules themselves don't
 * care how (or whether) they're being rendered.
 *
 * Pieces snap to *each other*, not to one fixed absolute spot: a piece
 * connects to a grid-neighbor whenever it's dropped close to that
 * neighbor's correct relative position, wherever the neighbor happens to
 * be sitting -- see [tryConnect]. Connected pieces share a [PieceGroup] and
 * from then on move, and are hit-tested and brought to front, together.
 */
internal class PuzzleGame(
    private val pieces: MutableList<PuzzlePiece>,
    private val snapThresholdPx: Float
) {
    var onSolved: (() -> Unit)? = null
    private var solved = false

    /** O(1) grid-adjacency lookups for [tryConnect]; built once since a
     * piece's (row, col) never changes after it's cut. */
    private val byRowCol: Map<Pair<Int, Int>, PuzzlePiece> =
        pieces.associateBy { it.row to it.col }

    val pieceCount: Int get() = pieces.size

    /** Pieces that have connected to at least one neighbor so far -- not
     * necessarily all in the same cluster yet. Reaches [pieceCount] exactly
     * when the puzzle is solved. */
    val connectedCount: Int get() = pieces.count { it.group.size > 1 }

    /** Average of each piece's own (width+height)/2 "size" -- shared by
     * [scatter] (initial pile placement) and [PuzzleBoardView]'s
     * post-drop pile-crowding check, so both agree on what "about one
     * piece" means without computing it twice. */
    val averagePieceExtent: Float by lazy {
        if (pieces.isEmpty()) 0f
        else pieces.sumOf { (it.width + it.height) / 2 }.toFloat() / pieces.size
    }

    /** Back-to-front draw/z order; bringing a piece to front moves its
     * whole group to the end. */
    fun piecesInDrawOrder(): List<PuzzlePiece> = pieces

    fun findTopPieceAt(x: Float, y: Float): PuzzlePiece? {
        if (solved) return null
        for (index in pieces.indices.reversed()) {
            val piece = pieces[index]
            val localX = (x - piece.currentX).toInt()
            val localY = (y - piece.currentY).toInt()
            if (localX in 0 until piece.width &&
                localY in 0 until piece.height &&
                piece.containsLocalPoint(localX, localY)
            ) {
                return piece
            }
        }
        return null
    }

    /** Moves every piece in [piece]'s group to the end of the draw order,
     * preserving their order relative to each other. */
    fun bringToFront(piece: PuzzlePiece) {
        val group = piece.group
        val members = pieces.filter { it.group === group }
        pieces.removeAll(members)
        pieces.addAll(members)
    }

    fun moveBy(piece: PuzzlePiece, dx: Float, dy: Float) {
        piece.group.moveBy(dx, dy)
    }

    /**
     * Looks for a grid-neighbor of [piece]'s group that belongs to a
     * different group and is currently sitting close to where it belongs
     * relative to the piece next to it -- regardless of where on the board
     * that is. If found, nudges [piece]'s group by the small correction
     * needed to line the two up exactly, merges the groups, and keeps
     * looking (so completing, say, the last gap in a row can chain into
     * one connection). The stationary neighbor's group is never the one
     * that moves, so an already-assembled cluster never jumps to meet a
     * single new piece.
     *
     * Returns whether at least one connection was made.
     */
    fun tryConnect(piece: PuzzlePiece): Boolean {
        val group = piece.group
        val thresholdSq = snapThresholdPx * snapThresholdPx
        var connectedAny = false
        var mergedThisPass = true

        while (mergedThisPass) {
            mergedThisPass = false
            for (member in group.members.toList()) {
                for (neighbor in gridNeighbors(member)) {
                    if (neighbor.group === group) continue
                    // A flipped piece must be turned back over before it
                    // can snap in -- see PieceOrientation.
                    if (member.orientation != PieceOrientation.FRONT ||
                        neighbor.orientation != PieceOrientation.FRONT
                    ) continue

                    val correctionX =
                        (neighbor.currentX - member.currentX) - (neighbor.homeX - member.homeX)
                    val correctionY =
                        (neighbor.currentY - member.currentY) - (neighbor.homeY - member.homeY)

                    if (correctionX * correctionX + correctionY * correctionY <= thresholdSq) {
                        group.moveBy(correctionX, correctionY)
                        group.absorb(neighbor.group)
                        markThicknessConnection(member, neighbor)
                        connectedAny = true
                        mergedThisPass = true
                    }
                }
            }
        }

        if (connectedAny) checkSolved(group)
        return connectedAny
    }

    /**
     * The neighbor across [side] from [piece], or null at the grid's
     * edge. The one place grid adjacency is computed -- both
     * [gridNeighbors] (used by [tryConnect]) and [isSideConnected] (used
     * by [PuzzleBoardView] to decide which borders to draw) go through
     * this, rather than each re-deriving "which cell is next door" its
     * own way.
     */
    private fun neighborAt(piece: PuzzlePiece, side: PieceSide): PuzzlePiece? =
        byRowCol[piece.row + side.rowDelta to piece.col + side.colDelta]

    private fun gridNeighbors(piece: PuzzlePiece): List<PuzzlePiece> =
        PieceSide.values().mapNotNull { neighborAt(piece, it) }

    /**
     * Whether [piece] and its neighbor across [side] are already fused
     * into the same [PieceGroup] -- i.e. that shared edge is a solved
     * seam, not just two pieces happening to sit close together.
     * [PuzzleBoardView] uses this to skip drawing a border on a seam
     * that's already connected, so it reads as one continuous piece
     * instead of two with a line down the middle.
     */
    fun isSideConnected(piece: PuzzlePiece, side: PieceSide): Boolean {
        val neighbor = neighborAt(piece, side) ?: return false
        return neighbor.group === piece.group
    }

    /**
     * Carves [a] and [b]'s thickness slivers down to exclude each other's
     * own territory -- see [PuzzlePiece.excludeFromThickness] -- now that
     * they're confirmed sitting flush against each other. Only needs
     * their *current* relative offset, which is safe to capture once and
     * forget: a group only ever translates as a whole from here on (see
     * [PieceGroup.moveBy]), so two connected pieces' positions relative
     * to each other never change again.
     */
    private fun markThicknessConnection(a: PuzzlePiece, b: PuzzlePiece) {
        val dx = b.currentX - a.currentX
        val dy = b.currentY - a.currentY
        a.excludeFromThickness(Path(b.outline).apply { offset(dx, dy) })
        b.excludeFromThickness(Path(a.outline).apply { offset(-dx, -dy) })
    }

    private fun checkSolved(group: PieceGroup) {
        if (solved || group.size != pieces.size) return
        solved = true
        // Every member shares the same offset from its own home position
        // (they only ever move together), so any one of them tells us the
        // correction that lines the whole finished picture up with the
        // frame.
        val anchor = group.members.first()
        group.moveBy(anchor.homeX - anchor.currentX, anchor.homeY - anchor.currentY)
        onSolved?.invoke()
    }

    /**
     * Scatters every piece into a few overlapping heaps within
     * [areaWidth] x [areaHeight] and clears every connection -- used both
     * for initial setup and "play again". Pieces pile up the way they
     * would tipped out of a box: finding a particular one often means
     * moving others off of it first.
     */
    fun scatter(areaWidth: Int, areaHeight: Int, seed: Long) {
        if (areaWidth <= 0 || areaHeight <= 0) return
        val random = Random(seed)
        solved = false

        for (piece in pieces) {
            piece.group = PieceGroup(piece)
            // A piece flipped in a previous game must never carry that
            // over into a fresh one.
            piece.orientation = PieceOrientation.FRONT
        }
        pieces.shuffle(random) // also randomizes which piece lands on top of each heap

        val pileRadius = averagePieceExtent * PILE_RADIUS_FACTOR
        val centers = pileCenters(areaWidth, areaHeight, pileRadius, random)

        for ((index, piece) in pieces.withIndex()) {
            val center = centers[index % centers.size]
            val angle = random.nextFloat() * TWO_PI
            // sqrt() on the radial fraction spreads pieces evenly over the
            // disc's *area* instead of bunching them up near dead center.
            val distance = pileRadius * sqrt(random.nextFloat())
            val targetCenterX = center.x + cos(angle) * distance
            val targetCenterY = center.y + sin(angle) * distance

            piece.currentX = (targetCenterX - piece.width / 2f)
                .coerceIn(0f, (areaWidth - piece.width).coerceAtLeast(0).toFloat())
            piece.currentY = (targetCenterY - piece.height / 2f)
                .coerceIn(0f, (areaHeight - piece.height).coerceAtLeast(0).toFloat())
        }
    }

    /** Jittered-grid pile centers, inset from the edges so a heap never
     * gets clipped by the board bounds. The columns/rows split matches the
     * board's own aspect ratio (not just whatever square-ish grid fits
     * [pileCount]) -- with few piles, e.g. 2 for an Easy 3x3 puzzle,
     * a plain `ceil(sqrt(pileCount))` always reaches for 2 columns before
     * 2 rows, so on a tall phone screen every pile lands in one horizontal
     * band across the middle and the rest of the board's height goes
     * unused. Weighting the column count by aspect ratio spreads piles
     * (and so the pieces in them) the way the screen is actually shaped. */
    private fun pileCenters(
        areaWidth: Int,
        areaHeight: Int,
        pileRadius: Float,
        random: Random
    ): List<PointF> {
        val pileCount = ceil(pieces.size / PIECES_PER_PILE).toInt().coerceAtLeast(1)
        val aspectRatio = areaWidth.toFloat() / areaHeight.toFloat()
        val columns = ceil(sqrt(pileCount * aspectRatio)).toInt().coerceIn(1, pileCount)
        val rows = ceil(pileCount / columns.toFloat()).toInt().coerceAtLeast(1)

        val margin = pileRadius.coerceAtMost(minOf(areaWidth, areaHeight) / 3f)
        val cellW = (areaWidth - margin * 2).coerceAtLeast(1f) / columns
        val cellH = (areaHeight - margin * 2).coerceAtLeast(1f) / rows

        return (0 until pileCount).map { i ->
            val col = i % columns
            val row = i / columns
            PointF(
                margin + cellW * (col + 0.5f) + (random.nextFloat() - 0.5f) * cellW * 0.4f,
                margin + cellH * (row + 0.5f) + (random.nextFloat() - 0.5f) * cellH * 0.4f
            )
        }
    }

    fun recycleAll() {
        pieces.forEach { it.recycle() }
    }

    private companion object {
        const val PIECES_PER_PILE = 7f
        const val PILE_RADIUS_FACTOR = 1.15f
        val TWO_PI = (PI * 2).toFloat()
    }
}
