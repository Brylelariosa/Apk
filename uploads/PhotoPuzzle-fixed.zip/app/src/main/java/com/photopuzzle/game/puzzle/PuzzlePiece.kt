package com.photopuzzle.game.puzzle

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Region

/**
 * One cut-out jigsaw piece.
 *
 * [homeX]/[homeY] are in the board's own coordinate space -- the same
 * space [currentX]/[currentY] live in -- and mark where this piece
 * belongs once solved; [PuzzlePieceFactory] offsets them from the source
 * bitmap's own top-left out to wherever the photo/reference area sits
 * within the larger board. [outline] stays in the piece's own local
 * bitmap coordinates (see [drawSilhouette]) and is unaffected by that
 * offset. [currentX]/[currentY] are updated as the player drags the piece
 * -- or the [group] it belongs to -- around the board.
 */
internal class PuzzlePiece(
    val row: Int,
    val col: Int,
    val bitmap: Bitmap,
    val outline: Path,
    private val sideOutlines: Map<PieceSide, Path>,
    val homeX: Float,
    val homeY: Float
) {
    val width: Int get() = bitmap.width
    val height: Int get() = bitmap.height

    var currentX: Float = homeX
    var currentY: Float = homeY

    /**
     * The cluster this piece currently moves, and is brought to front,
     * together with. Starts as a lone group of one; [PuzzleGame.tryConnect]
     * merges groups together as correctly-adjacent pieces meet, and
     * [PuzzleGame.scatter] resets every piece back to its own group for a
     * fresh game.
     */
    var group: PieceGroup = PieceGroup(this)

    /**
     * Which face is currently showing -- see [PieceOrientation]. Lives here
     * (rather than on [PuzzleBoardView], which only tracks the transient
     * flip *animation*) so it survives dragging, fling, pile movement, and
     * reordering exactly like [currentX]/[group] already do.
     * [PuzzleGame.scatter] resets this to [PieceOrientation.FRONT] for
     * every piece at the start of each game.
     */
    var orientation: PieceOrientation = PieceOrientation.FRONT

    /**
     * [outline] with any *connected* neighbor's own territory already cut
     * out -- see [excludeFromThickness], called by [PuzzleGame.tryConnect]
     * the instant a seam connects. Starts as a plain copy of [outline] (an
     * unconnected piece's thickness sliver is its whole silhouette) and
     * only ever shrinks from there, since pieces never disconnect once
     * joined. Used in place of [outline] anywhere this piece's own
     * "physical bulk" is being filled -- the thickness sliver and the
     * elevation shadow (see [PuzzleBoardView.drawThickness]) -- so neither
     * one bleeds a sliver of this piece over a neighbor it's already
     * sitting flush against.
     */
    private var thicknessMask: Path = Path(outline)

    // Built lazily (and only once) since Region.setPath does real rasterization
    // work; most pieces are dragged/redrawn far more often than they're
    // hit-tested for the first time.
    private val hitRegion: Region by lazy {
        Region().apply { setPath(outline, Region(0, 0, width, height)) }
    }

    /** [localX]/[localY] are relative to this piece's own bitmap, i.e. already
     * had [currentX]/[currentY] subtracted out by the caller. */
    fun containsLocalPoint(localX: Int, localY: Int): Boolean =
        hitRegion.contains(localX, localY)

    /**
     * Draws this piece's *whole* jigsaw-cut silhouette with [paint].
     * Used where connection state doesn't matter: [PieceBackRenderer]'s
     * procedural backside, which only ever shows for a loose,
     * unconnected piece to begin with (see [PieceOrientation]). The
     * front-facing border and "physical bulk" fills care whether a seam
     * is already connected -- see [drawSide] and [drawThicknessMask].
     * [canvas] must already be translated so its origin sits at
     * ([currentX], [currentY]) -- [outline] itself is in the piece's own
     * local bitmap coordinates, same as everywhere else it's used
     * ([containsLocalPoint], [cutPiece]).
     */
    fun drawSilhouette(canvas: Canvas, paint: Paint) {
        canvas.drawPath(outline, paint)
    }

    /**
     * Draws just this piece's [side] -- not its whole silhouette -- with
     * [paint]. [PuzzleBoardView] uses this to stroke only the borders
     * that aren't shared with an already-connected neighbor, so a solved
     * seam goes un-outlined instead of showing a border on both sides of
     * the join. Same coordinate-space contract as [drawSilhouette].
     */
    fun drawSide(canvas: Canvas, side: PieceSide, paint: Paint) {
        canvas.drawPath(sideOutlines.getValue(side), paint)
    }

    /** Draws [thicknessMask] -- see its own doc for what that is and why
     * it can differ from the plain [outline]. Same coordinate-space
     * contract as [drawSilhouette]. */
    fun drawThicknessMask(canvas: Canvas, paint: Paint) {
        canvas.drawPath(thicknessMask, paint)
    }

    /**
     * Cuts [neighborOutline] -- a newly-connected neighbor's own outline,
     * already translated into this piece's local coordinate space (see
     * [PuzzleGame.tryConnect]) -- out of [thicknessMask]. Safe to call as
     * more sides connect over time; a failed [Path.op] (Skia occasionally
     * declines on a degenerate input) leaves the mask unchanged rather
     * than risk corrupting it.
     */
    fun excludeFromThickness(neighborOutline: Path) {
        val result = Path()
        if (result.op(thicknessMask, neighborOutline, Path.Op.DIFFERENCE)) {
            thicknessMask = result
        }
    }

    fun recycle() {
        if (!bitmap.isRecycled) bitmap.recycle()
    }
}
