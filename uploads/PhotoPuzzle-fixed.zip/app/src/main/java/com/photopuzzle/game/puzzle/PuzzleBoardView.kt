package com.photopuzzle.game.puzzle

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Region
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import com.photopuzzle.game.R
import com.photopuzzle.game.util.ImageUtils
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class PuzzleBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var game: PuzzleGame? = null
    private var referenceBitmap: Bitmap? = null

    // Where the photo/reference area sits within the larger board (see
    // start()) -- the board itself is still this whole View, but the photo
    // now only occupies a smaller, centered region of it, leaving real
    // space on every side to scatter and drag pieces into. Everything
    // piece-related (scatter/clamp/fling bounds) already operates in this
    // same board space and needs no separate offset; only drawing the
    // reference photo/frame, and the pieces' own home positions (handled
    // in PuzzlePieceFactory), need to know where the photo sits inside it.
    private var referenceLeft = 0f
    private var referenceTop = 0f

    private var draggingPiece: PuzzlePiece? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var velocityTracker: VelocityTracker? = null

    // Swipe-to-throw: released fast enough, a piece keeps sailing in that
    // direction and decelerates on its own. Driven by FlingPhysics (a
    // constant-deceleration "kinetic friction" model tuned for a short
    // toss across a board a few hundred pixels wide) rather than
    // OverScroller, whose fling curve is built for scrolling through
    // screen-fuls of content and either barely nudges a piece or sends it
    // straight into a wall no matter how gently it was thrown.
    private val flingPhysics by lazy {
        FlingPhysics(FLING_DECELERATION_DP_PER_SEC2 * resources.displayMetrics.density)
    }
    private var flingPiece: PuzzlePiece? = null
    private var lastFlingFrameTimeNanos = 0L
    private val flingTicker = object : Runnable {
        override fun run() {
            val activeGame = game
            val piece = flingPiece
            if (activeGame == null || piece == null) {
                flingPiece = null
                return
            }

            val now = System.nanoTime()
            val deltaSeconds = ((now - lastFlingFrameTimeNanos) / 1_000_000_000f)
                .coerceIn(0f, MAX_FRAME_DELTA_SECONDS)
            lastFlingFrameTimeNanos = now

            val (dx, dy) = flingPhysics.step(deltaSeconds)
            activeGame.moveBy(piece, dx, dy)
            val clamp = clampToBounds(piece.group)
            if (clamp.hitX) flingPhysics.reflectX(WALL_RESTITUTION)
            if (clamp.hitY) flingPhysics.reflectY(WALL_RESTITUTION)
            updateFlingTilt()

            if (flingPhysics.isRunning) {
                invalidate()
                postOnAnimation(this)
                return
            }

            // Only check for a connection once the piece has actually come
            // to rest. Checking on every in-flight frame would let a piece
            // connect while it's still sailing past at speed -- easy to
            // miss happening at all, and the opposite of the deliberate,
            // "I placed that" feeling a snap should have.
            flingPiece = null
            finishPlacing(piece)
        }
    }

    /** Fling-driven counterpart to [updateDragTilt]: keeps the piece tilted
     * into its direction of travel while it's still sailing, scaled off
     * the fling's own current velocity instead of a per-event touch delta. */
    private fun updateFlingTilt() {
        val target = (flingPhysics.velocityX * TILT_DEGREES_PER_VELOCITY_PXPS)
            .coerceIn(-MAX_TILT_DEGREES, MAX_TILT_DEGREES)
        liftTiltDegrees += (target - liftTiltDegrees) * TILT_RESPONSIVENESS
    }

    private val piecePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val referencePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { alpha = REFERENCE_ALPHA }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    // Traces each unsolved piece's own jigsaw-cut silhouette so pieces read
    // clearly as individual pieces while assembling; fades away (see
    // [borderAlpha]) once the puzzle is solved, leaving a clean photo.
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = BORDER_STROKE_DP * resources.displayMetrics.density
        strokeJoin = Paint.Join.ROUND
        color = ContextCompat.getColor(context, R.color.colorTextPrimary)
    }

    // The always-visible sliver simulating each piece's own physical edge
    // (see drawThickness()), and the larger, fainter cast shadow shown only
    // under the piece currently being lifted. Both flat fills rather than a
    // blurred shadow -- BlurMaskFilter isn't reliably supported on a
    // hardware-accelerated Canvas -- with alpha set per-frame rather than
    // baked into the color, the same way [borderPaint] reuses an opaque
    // color at a runtime alpha above.
    private val thicknessPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.colorPieceThickness)
    }
    private val elevationShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.colorPieceShadow)
    }

    // Procedural puzzle-piece backside (see PieceBackRenderer) -- built
    // once and shared by every piece, never a per-piece bitmap.
    private val pieceBackRenderer = PieceBackRenderer(context, resources.displayMetrics.density)

    private val colorFrameGlow = ContextCompat.getColor(context, R.color.colorFrameGlow)
    private val colorFrameBand = ContextCompat.getColor(context, R.color.colorFrameBand)
    private val colorFrameHighlight = ContextCompat.getColor(context, R.color.colorFrameHighlight)

    private val confetti = ConfettiBurst(
        intArrayOf(
            ContextCompat.getColor(context, R.color.colorConfettiGold),
            ContextCompat.getColor(context, R.color.colorConfettiPink),
            ContextCompat.getColor(context, R.color.colorConfettiMint),
            ContextCompat.getColor(context, R.color.colorConfettiSky),
            colorFrameHighlight
        )
    )

    // The piece (or connected group) currently being handled -- grabbed and
    // not yet released, or still sailing from a fling -- rendered enlarged,
    // tilted, and with an extra cast shadow (see drawPiece(),
    // drawThickness()) so it reads as having been lifted off the board.
    private var liftedGroup: PieceGroup? = null
    private var liftAmount = 0f
    private var liftTiltDegrees = 0f
    private var settleStartLift = 0f
    private var settleStartTilt = 0f

    private val liftUpAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = LIFT_UP_DURATION_MS
        interpolator = OvershootInterpolator(1.1f)
        addUpdateListener {
            liftAmount = it.animatedValue as Float
            invalidate()
        }
    }

    // Eases liftAmount/liftTiltDegrees back down from wherever they
    // currently are (not necessarily "fully lifted") to resting (0f/0f),
    // since a piece can be released mid pick-up animation or mid-tilt.
    private val settleAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = SETTLE_DURATION_MS
        interpolator = DecelerateInterpolator()
        addUpdateListener {
            val remaining = 1f - (it.animatedValue as Float)
            liftAmount = settleStartLift * remaining
            liftTiltDegrees = settleStartTilt * remaining
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                liftedGroup = null
                liftAmount = 0f
                liftTiltDegrees = 0f
            }
        })
    }

    /**
     * Starts the pick-up animation for [group] and marks it as the piece
     * currently being handled, so [drawPiece] renders it enlarged with a
     * cast shadow (see [drawThickness]) until it's released again.
     *
     * Deliberately keeps only one such group in flight at a time -- if a
     * different group was still mid-[beginSettle] when this is called (a
     * fast re-grab within roughly [SETTLE_DURATION_MS]), that older
     * group's settle is cut short rather than tracked to completion. In
     * practice this is a rare, sub-quarter-second edge case, and simpler
     * than threading a whole animation queue through what's otherwise a
     * single-piece-at-a-time interaction.
     */
    private fun beginLift(group: PieceGroup) {
        settleAnimator.cancel()
        liftedGroup = group
        liftTiltDegrees = 0f
        liftUpAnimator.cancel()
        liftUpAnimator.start()
    }

    /**
     * Starts animating the currently-lifted group back down to resting
     * size (and its tilt back to level) from wherever [liftAmount] /
     * [liftTiltDegrees] currently are -- called once a drag ends without a
     * fling, or a fling comes to rest.
     */
    private fun beginSettle() {
        liftUpAnimator.cancel()
        settleStartLift = liftAmount
        settleStartTilt = liftTiltDegrees
        settleAnimator.cancel()
        settleAnimator.start()
    }

    // Turning a loose piece over (see maybeStartFlip()). Only ever one
    // piece at a time, the same simplifying assumption liftedGroup already
    // makes for picking a piece up. flipRotationDegrees is the illusion
    // itself -- a genuine perspective rotation about the piece's own
    // vertical center (see applyFlipRotation()), not just a flat squash --
    // while flipThicknessBulge peaks at that same edge-on midpoint so
    // drawThickness() shows more "side" exactly when the face is
    // thinnest, which is also what keeps the piece from ever fully
    // disappearing mid-flip. orientation itself flips on the model
    // (PuzzlePiece.orientation) right at that midpoint, so drawPiece()
    // never needs to know an animation is even running -- it just draws
    // whatever orientation the piece currently reports.
    private var flippingPiece: PuzzlePiece? = null
    private var flipTargetOrientation: PieceOrientation = PieceOrientation.FRONT
    private var flipRotationDegrees = 0f
    private var flipThicknessBulge = 0f
    private val flipCamera = Camera()
    private val flipMatrix = Matrix()
    private val flipAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = FLIP_DURATION_MS
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener {
            val progress = it.animatedValue as Float
            val piece = flippingPiece
            if (piece != null && progress >= 0.5f && piece.orientation != flipTargetOrientation) {
                piece.orientation = flipTargetOrientation
            }
            // Rotate the front face in from 0 to 90 degrees, then -- right
            // as the content swaps to the back at that midpoint -- continue
            // from -90 back to 0, rather than on through 90 to 180.
            // Carrying on past 90 would show the back content mirrored;
            // approaching its own 0 degrees from -90 the same way the
            // front approached 90 from 0 keeps it reading correctly the
            // instant it's visible.
            flipRotationDegrees = if (progress < 0.5f) progress * 180f else (progress - 1f) * 180f
            val faceProgress = abs(1f - 2f * progress)
            flipThicknessBulge = 1f - faceProgress
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                flippingPiece = null
                flipRotationDegrees = 0f
                flipThicknessBulge = 0f
            }
        })
    }

    /**
     * Double-tap-to-flip entry point (wired up in [onTouchEvent] via
     * [flipGestureDetector]). Only a loose piece can flip -- a piece
     * already inside a multi-piece group keeps whatever orientation it
     * joined with (see [PieceOrientation]) -- and only one piece flips at
     * a time.
     */
    private fun maybeStartFlip(x: Float, y: Float) {
        val activeGame = game ?: return
        val piece = activeGame.findTopPieceAt(x, y) ?: return
        if (piece.group.size > 1) return
        if (flippingPiece != null) return

        if (piece === flingPiece) stopFling()
        activeGame.bringToFront(piece)

        flippingPiece = piece
        flipTargetOrientation =
            if (piece.orientation == PieceOrientation.FRONT) PieceOrientation.BACK else PieceOrientation.FRONT
        flipAnimator.cancel()
        flipAnimator.start()
        invalidate()
    }

    /** Feeds [onTouchEvent] without otherwise changing its own drag/fling
     * handling -- only [GestureDetector.SimpleOnGestureListener.onDoubleTap]
     * is used here, purely for its callback, so every other event is still
     * processed exactly as it already is below. Double-tapping a piece
     * flips it; double-tapping empty board space instead zooms back out
     * to the default view (see [resetZoom]), since pinching back to
     * exactly 1x by feel is fiddly. */
    private val flipGestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val (boardX, boardY) = screenToBoard(e.x, e.y)
            if (game?.findTopPieceAt(boardX, boardY) != null) {
                maybeStartFlip(boardX, boardY)
            } else {
                resetZoom()
            }
            return true
        }
    })

    // A quick, satisfying "pop" on the pieces that just connected -- makes
    // a snap read as something that just happened because of where *you*
    // placed the piece, not as the game quietly doing it for you.
    private var snapPulseGroup: PieceGroup? = null
    private var snapPulseScale = 1f
    private var snapPulseCenterX = 0f
    private var snapPulseCenterY = 0f
    private val snapPulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = SNAP_PULSE_DURATION_MS
        interpolator = LinearInterpolator()
        addUpdateListener {
            snapPulseScale = pulseScale(it.animatedValue as Float, SNAP_PULSE_PEAK_SCALE)
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                snapPulseGroup = null
                snapPulseScale = 1f
            }
        })
    }

    // The on-solve celebration: borders fade out, the finished picture
    // gives a small satisfied "pop", and confetti drifts down over it.
    private var borderAlpha = 1f
    private var completionScale = 1f
    private var celebrationProgress = 1f // 1f == no celebration in flight
    private val completionAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = COMPLETION_CELEBRATION_DURATION_MS
        interpolator = LinearInterpolator()
        addUpdateListener {
            val progress = it.animatedValue as Float
            celebrationProgress = progress
            borderAlpha = (1f - progress / BORDER_FADE_FRACTION).coerceIn(0f, 1f)
            completionScale = pulseScale(progress / COMPLETION_POP_FRACTION, COMPLETION_POP_PEAK_SCALE)
            invalidate()
        }
    }

    // Pinch-to-zoom and pan: everything else in this view (piece
    // positions, board width/height, scatter/clamp/fling bounds) stays in
    // the board's own single fixed coordinate space exactly as before --
    // this is purely a camera on top of it, applied once in onDraw() and
    // inverted once per touch event in onTouchEvent() (see
    // screenToBoard()), so none of that logic needs to know zoom exists
    // at all. Panning is clamped so the board's own edge can never scroll
    // past the viewport's (see clampCamera()); zoom only ever goes in
    // from the default 1x, never out, since there's nothing beyond the
    // board's own edges to reveal.
    private var boardScale = 1f
    private var boardPanX = 0f
    private var boardPanY = 0f
    private var isPanning = false
    private var lastPanX = 0f
    private var lastPanY = 0f
    private var lastScaleFocusX = 0f
    private var lastScaleFocusY = 0f
    private val scaleGestureDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                lastScaleFocusX = detector.focusX
                lastScaleFocusY = detector.focusY
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                // The board-space point that was sitting under the focal
                // point just before this incremental step, found using
                // the camera as it stood then -- re-anchoring it under
                // the (possibly moved, possibly pinched) focal point now
                // is what makes two fingers moving together pan the
                // board, and pinching zoom into wherever they are, in one
                // gesture.
                val boardFocusX = (lastScaleFocusX - boardPanX) / boardScale
                val boardFocusY = (lastScaleFocusY - boardPanY) / boardScale

                boardScale = (boardScale * detector.scaleFactor).coerceIn(1f, MAX_BOARD_SCALE)
                boardPanX = detector.focusX - boardFocusX * boardScale
                boardPanY = detector.focusY - boardFocusY * boardScale
                clampCamera()

                lastScaleFocusX = detector.focusX
                lastScaleFocusY = detector.focusY
                invalidate()
                return true
            }
        }
    )

    private var cameraAnimStartScale = 1f
    private var cameraAnimStartPanX = 0f
    private var cameraAnimStartPanY = 0f
    private val cameraAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = CAMERA_RESET_DURATION_MS
        interpolator = DecelerateInterpolator()
        addUpdateListener {
            val fraction = it.animatedValue as Float
            boardScale = cameraAnimStartScale + (1f - cameraAnimStartScale) * fraction
            boardPanX = cameraAnimStartPanX * (1f - fraction)
            boardPanY = cameraAnimStartPanY * (1f - fraction)
            invalidate()
        }
    }

    /** Converts a screen/view-space touch coordinate into the board's own
     * coordinate space -- what every piece's currentX/Y, and the view's
     * own width/height, already live in -- inverting whatever [onDraw]'s
     * pan/zoom camera currently applies. */
    private fun screenToBoard(screenX: Float, screenY: Float): Pair<Float, Float> =
        (screenX - boardPanX) / boardScale to (screenY - boardPanY) / boardScale

    /** Keeps [boardScale] within `[1f, MAX_BOARD_SCALE]` and [boardPanX]/
     * [boardPanY] such that the board's own edge never scrolls past the
     * viewport's -- the standard "don't pan past the content" clamp, at
     * whatever the current zoom level is. */
    private fun clampCamera() {
        boardScale = boardScale.coerceIn(1f, MAX_BOARD_SCALE)
        boardPanX = boardPanX.coerceIn(width * (1f - boardScale), 0f)
        boardPanY = boardPanY.coerceIn(height * (1f - boardScale), 0f)
    }

    /** Smoothly zooms back out to the default fit -- see
     * [flipGestureDetector]'s double-tap-on-empty-space handling, since
     * pinching back to exactly 1x by feel is fiddly. No-op if already
     * there. */
    private fun resetZoom() {
        if (boardScale <= 1f && boardPanX == 0f && boardPanY == 0f) return
        cameraAnimator.cancel()
        cameraAnimStartScale = boardScale
        cameraAnimStartPanX = boardPanX
        cameraAnimStartPanY = boardPanY
        cameraAnimator.start()
    }

    // A piece (or small connected cluster) that just settled somewhere
    // already crowded with other loose pieces slides clear of the pile
    // rather than sitting exactly where it was dropped -- see
    // resolvePileOverlap() and PilePhysics.
    private var pileSlideGroup: PieceGroup? = null
    private var pileSlideStartX = 0f
    private var pileSlideStartY = 0f
    private var pileSlideTargetX = 0f
    private var pileSlideTargetY = 0f
    private val pileSlideAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = PILE_SLIDE_DURATION_MS
        interpolator = DecelerateInterpolator()
        addUpdateListener {
            val group = pileSlideGroup ?: return@addUpdateListener
            val fraction = it.animatedValue as Float
            val desiredX = pileSlideStartX + (pileSlideTargetX - pileSlideStartX) * fraction
            val desiredY = pileSlideStartY + (pileSlideTargetY - pileSlideStartY) * fraction
            val current = groupBounds(group)
            group.moveBy(desiredX - current.centerX(), desiredY - current.centerY())
            invalidate()
        }
        addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                pileSlideGroup = null
            }
        })
    }

    private val snapThresholdPx: Float
        get() = SNAP_THRESHOLD_DP * resources.displayMetrics.density

    private val viewConfiguration by lazy { ViewConfiguration.get(context) }

    var onSolved: (() -> Unit)? = null
    var onPiecePlaced: ((connected: Int, total: Int) -> Unit)? = null

    /**
     * Starts a new puzzle from [sourcePhoto]. This view takes ownership of
     * [sourcePhoto] from this call onward (and of everything derived from
     * it) -- the caller should not use or recycle it afterward; call
     * [recycleAll] (e.g. from `onDestroy`) to free it instead.
     *
     * Waits for layout if this view doesn't have a size yet, since pieces
     * are fit and scattered against the view's actual pixel dimensions.
     */
    fun start(sourcePhoto: Bitmap, rows: Int, cols: Int, seed: Long = System.nanoTime()) {
        if (width == 0 || height == 0) {
            post { start(sourcePhoto, rows, cols, seed) }
            return
        }

        recycleAll()
        resetCelebrationState()

        // The photo only fills a smaller, centered region of the board now
        // (see referenceLeft/referenceTop) -- not the whole View the way it
        // used to -- so there's real, usable space left over on every side
        // for pieces to scatter and drag into. Its own aspect ratio is
        // still respected exactly as fitToBounds always did; only the box
        // it's fit *into* has shrunk.
        val photoMaxWidth = (width * PHOTO_AREA_WIDTH_FRACTION).roundToInt()
        val photoMaxHeight = (height * PHOTO_AREA_HEIGHT_FRACTION).roundToInt()
        val fitted = ImageUtils.fitToBounds(sourcePhoto, photoMaxWidth, photoMaxHeight)
        if (fitted !== sourcePhoto) {
            sourcePhoto.recycle()
        }
        referenceBitmap = fitted
        referenceLeft = (width - fitted.width) / 2f
        referenceTop = (height - fitted.height) / 2f

        val pieces = PuzzlePieceFactory.createPieces(fitted, rows, cols, seed, referenceLeft, referenceTop)
            .toMutableList()
        val newGame = PuzzleGame(pieces, snapThresholdPx)
        newGame.onSolved = {
            startCompletionCelebration()
            onSolved?.invoke()
        }
        newGame.scatter(width, height, seed)

        game = newGame
        invalidate()
    }

    /** Re-scatters the current puzzle's pieces without re-cutting the image. */
    fun shuffle(seed: Long = System.nanoTime()) {
        stopFling()
        resetCelebrationState()
        game?.scatter(width, height, seed)
        invalidate()
    }

    fun recycleAll() {
        stopFling()
        snapPulseAnimator.cancel()
        completionAnimator.cancel()
        liftUpAnimator.cancel()
        settleAnimator.cancel()
        flipAnimator.cancel()
        cameraAnimator.cancel()
        pileSlideAnimator.cancel()
        game?.recycleAll()
        referenceBitmap?.takeIf { !it.isRecycled }?.recycle()
        game = null
        referenceBitmap = null
    }

    private fun resetCelebrationState() {
        completionAnimator.cancel()
        snapPulseAnimator.cancel()
        borderAlpha = 1f
        completionScale = 1f
        celebrationProgress = 1f
        snapPulseGroup = null
        snapPulseScale = 1f
        resetInteractionState()
    }

    /** Clears any in-progress pick-up/settle/tilt/pile-slide state and
     * resets pinch-zoom/pan back to the default fit -- called whenever a
     * puzzle (re)starts, since a fresh (or reshuffled) board should never
     * inherit a "lifted" piece, an in-flight pile slide, or a zoomed-in
     * camera left over from whatever came before. */
    private fun resetInteractionState() {
        liftUpAnimator.cancel()
        settleAnimator.cancel()
        liftedGroup = null
        liftAmount = 0f
        liftTiltDegrees = 0f
        flipAnimator.cancel()
        flippingPiece = null
        flipRotationDegrees = 0f
        flipThicknessBulge = 0f
        pileSlideAnimator.cancel()
        pileSlideGroup = null
        cameraAnimator.cancel()
        boardScale = 1f
        boardPanX = 0f
        boardPanY = 0f
        isPanning = false
    }

    private fun startCompletionCelebration() {
        referenceBitmap?.let { reference ->
            confetti.start(
                centerX = referenceLeft + reference.width / 2f,
                topY = referenceTop,
                spreadWidth = reference.width.toFloat(),
                random = Random(System.nanoTime())
            )
        }
        completionAnimator.cancel()
        completionAnimator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val activeGame = game ?: return
        val reference = referenceBitmap

        canvas.save()
        canvas.translate(boardPanX, boardPanY)
        canvas.scale(boardScale, boardScale)

        canvas.save()
        if (completionScale != 1f && reference != null) {
            canvas.scale(
                completionScale, completionScale,
                referenceLeft + reference.width / 2f, referenceTop + reference.height / 2f
            )
        }

        reference?.let {
            canvas.save()
            canvas.translate(referenceLeft, referenceTop)
            drawFrame(canvas, it.width.toFloat(), it.height.toFloat())
            canvas.drawBitmap(it, 0f, 0f, referencePaint)
            canvas.restore()
        }

        borderPaint.alpha = (255 * BORDER_BASE_OPACITY * borderAlpha).toInt().coerceIn(0, 255)
        thicknessPaint.alpha = (255 * THICKNESS_BASE_OPACITY * borderAlpha).toInt().coerceIn(0, 255)
        val showBorders = borderAlpha > 0f
        val pulsingGroup = snapPulseGroup
        val lifted = liftedGroup
        val liftBounds = if (lifted != null && liftAmount > 0f) groupBounds(lifted) else null
        val density = resources.displayMetrics.density

        for (piece in activeGame.piecesInDrawOrder()) {
            drawPiece(canvas, activeGame, piece, pulsingGroup, lifted, liftBounds, showBorders, density)
        }

        canvas.restore()

        // Kept inside the pan/zoom transform (just outside the
        // completion "pop" scale) so confetti -- whose particle
        // positions/sizes are derived from the reference photo's
        // board-space rect -- stays correctly placed and sized if the
        // player zoomed in before finishing.
        if (celebrationProgress < 1f) {
            confetti.draw(
                canvas,
                elapsedSeconds = celebrationProgress * (COMPLETION_CELEBRATION_DURATION_MS / 1000f),
                lifeFraction = celebrationProgress
            )
        }

        canvas.restore()
    }

    /**
     * Draws one piece: its thickness/shadow, its bitmap, and (while
     * unsolved) whichever of its borders aren't already shared with a
     * connected neighbor (see [PuzzleGame.connectedNeighbor]) -- enlarged
     * and tilted about [liftBounds]'s center first if it belongs to
     * [liftedGroup], and/or pulsed about the snap-pulse center if it
     * belongs to [pulsingGroup]. A piece can be in both at once (the
     * group that was just dragged is usually the same one that just
     * snapped), in which case both transforms apply.
     */
    private fun drawPiece(
        canvas: Canvas,
        activeGame: PuzzleGame,
        piece: PuzzlePiece,
        pulsingGroup: PieceGroup?,
        liftedGroup: PieceGroup?,
        liftBounds: RectF?,
        showBorders: Boolean,
        density: Float
    ) {
        val isPulsing = pulsingGroup != null && piece.group === pulsingGroup
        val isLifted = liftBounds != null && liftedGroup != null && piece.group === liftedGroup
        val isFlipping = piece === flippingPiece
        val needsTransform = isPulsing || isLifted

        if (needsTransform) canvas.save()
        if (isLifted && liftBounds != null) {
            val scale = 1f + liftAmount.coerceAtLeast(0f) * LIFT_SCALE_FACTOR
            canvas.scale(scale, scale, liftBounds.centerX(), liftBounds.centerY())
            canvas.rotate(liftTiltDegrees, liftBounds.centerX(), liftBounds.centerY())
        }
        if (isPulsing) {
            canvas.scale(snapPulseScale, snapPulseScale, snapPulseCenterX, snapPulseCenterY)
        }

        // The thickness/edge sliver is drawn at full width regardless of
        // flip progress -- see flipThicknessBulge -- so the piece always
        // shows *something* even at the flip's edge-on midpoint, rather
        // than needing the squashed face below to carry that on its own.
        val flipBulge = if (isFlipping) flipThicknessBulge else 0f
        drawThickness(canvas, activeGame, piece, if (isLifted) liftAmount.coerceAtLeast(0f) else 0f, density, liftTiltDegrees, flipBulge)

        if (isFlipping) {
            canvas.save()
            applyFlipRotation(canvas, piece)
        }
        if (piece.orientation == PieceOrientation.FRONT) {
            canvas.drawBitmap(piece.bitmap, piece.currentX, piece.currentY, piecePaint)
        } else {
            canvas.save()
            canvas.translate(piece.currentX, piece.currentY)
            pieceBackRenderer.draw(canvas, piece)
            canvas.restore()
        }
        if (showBorders) {
            canvas.save()
            canvas.translate(piece.currentX, piece.currentY)
            for (side in PieceSide.values()) {
                if (activeGame.connectedNeighbor(piece, side) == null) {
                    piece.drawSide(canvas, side, borderPaint)
                }
            }
            canvas.restore()
        }
        if (isFlipping) canvas.restore()

        if (needsTransform) canvas.restore()
    }

    /**
     * Concats a perspective rotation about [piece]'s own vertical center
     * axis onto [canvas], standing in for the old flat horizontal squash
     * with an actual edge-on turn -- see [flipAnimator]. Caller must
     * already have called [Canvas.save] (and pairs it with its own
     * [Canvas.restore]), same contract as every other transform block in
     * [drawPiece].
     */
    private fun applyFlipRotation(canvas: Canvas, piece: PuzzlePiece) {
        val centerX = piece.currentX + piece.width / 2f
        val centerY = piece.currentY + piece.height / 2f

        flipCamera.save()
        flipCamera.rotateY(flipRotationDegrees)
        flipCamera.getMatrix(flipMatrix)
        flipCamera.restore()

        flipMatrix.preTranslate(-centerX, -centerY)
        flipMatrix.postTranslate(centerX, centerY)
        canvas.concat(flipMatrix)
    }

    /**
     * Draws this piece's "physical" side: a thin sliver always visible
     * just behind it, simulating a piece with some real thickness rather
     * than a paper-flat cutout, plus -- while [liftAmount] is above zero
     * -- a larger, fainter cast shadow that grows as the piece rises off
     * the board. [tiltDegrees] and [flipBulge] both grow the sliver a
     * little further beyond its resting [THICKNESS_OFFSET_DP]: a piece
     * that's tilted (dragging/flinging) or mid-flip shows more of its
     * physical edge, the way a real piece would as it turns away from flat.
     *
     * Both fills are clipped against every already-connected neighbor's
     * own outline first (see [PuzzleGame.connectedNeighbor]), so a piece
     * sitting flush against another on one or more sides never bulges a
     * sliver of itself out over that neighbor there -- and since the clip
     * is set up *before* the offset below is applied, it holds regardless
     * of how far that offset currently bulges out to. (A precomputed mask
     * -- this piece's outline with the neighbor's *at-rest* outline cut
     * out of it -- doesn't work here: two correctly interlocked pieces
     * don't overlap in area at rest, only once one of them is nudged out
     * by the offset, so there'd be nothing to cut.)
     *
     * Both the sliver and the elevation shadow are flat, unblurred fills
     * rather than a softened/blurred shadow: [android.graphics.BlurMaskFilter]
     * isn't reliably supported on a hardware-accelerated [Canvas] (this
     * view's default), so a genuinely blurred shadow would need its own
     * offscreen software-rendered bitmap per piece for what's meant to be a
     * subtle touch. Growing a plain flat shape's size, offset, and alpha
     * together reads as "soft and lifting" at this scale without any of that.
     */
    private fun drawThickness(
        canvas: Canvas,
        activeGame: PuzzleGame,
        piece: PuzzlePiece,
        liftAmount: Float,
        density: Float,
        tiltDegrees: Float,
        flipBulge: Float
    ) {
        canvas.save()
        canvas.translate(piece.currentX, piece.currentY)

        for (side in PieceSide.values()) {
            val neighbor = activeGame.connectedNeighbor(piece, side) ?: continue
            val neighborOutline = Path(neighbor.outline).apply {
                offset(neighbor.currentX - piece.currentX, neighbor.currentY - piece.currentY)
            }
            canvas.clipPath(neighborOutline, Region.Op.DIFFERENCE)
        }

        if (liftAmount > 0f) {
            val shadowOffset = (THICKNESS_OFFSET_DP + liftAmount * ELEVATION_MAX_OFFSET_DP) * density
            val shadowScale = 1f + liftAmount * ELEVATION_MAX_SCALE_BONUS
            elevationShadowPaint.alpha =
                (ELEVATION_SHADOW_MAX_ALPHA * liftAmount).roundToInt().coerceIn(0, 255)
            canvas.save()
            canvas.translate(shadowOffset, shadowOffset)
            canvas.scale(shadowScale, shadowScale, piece.width / 2f, piece.height / 2f)
            piece.drawSilhouette(canvas, elevationShadowPaint)
            canvas.restore()
        }

        val tiltBulge = (abs(tiltDegrees) / MAX_TILT_DEGREES).coerceIn(0f, 1f) * TILT_THICKNESS_BONUS_DP
        val edgeOffset = (THICKNESS_OFFSET_DP + tiltBulge + flipBulge * FLIP_THICKNESS_BONUS_DP) * density
        canvas.translate(edgeOffset, edgeOffset)
        piece.drawSilhouette(canvas, thicknessPaint)
        canvas.restore()
    }

    /**
     * Draws a simple layered picture frame -- a soft outer glow, a solid
     * band in the app's primary color, and a thin accent trim right at the
     * photo's edge -- around the [w] x [h] "home" area the solved picture
     * belongs in.
     */
    private fun drawFrame(canvas: Canvas, w: Float, h: Float) {
        val density = resources.displayMetrics.density
        val highlightWidth = FRAME_HIGHLIGHT_DP * density
        val bandWidth = FRAME_BAND_DP * density
        val glowWidth = FRAME_GLOW_DP * density
        val corner = FRAME_CORNER_DP * density

        val bandOffset = highlightWidth / 2f + bandWidth / 2f
        val glowOffset = highlightWidth / 2f + bandWidth + glowWidth / 2f

        framePaint.color = colorFrameGlow
        framePaint.strokeWidth = glowWidth
        canvas.drawRoundRect(-glowOffset, -glowOffset, w + glowOffset, h + glowOffset, corner, corner, framePaint)

        framePaint.color = colorFrameBand
        framePaint.strokeWidth = bandWidth
        canvas.drawRoundRect(-bandOffset, -bandOffset, w + bandOffset, h + bandOffset, corner, corner, framePaint)

        framePaint.color = colorFrameHighlight
        framePaint.strokeWidth = highlightWidth
        canvas.drawRoundRect(0f, 0f, w, h, corner, corner, framePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val activeGame = game ?: return false
        scaleGestureDetector.onTouchEvent(event)

        // A pinch already in progress owns the rest of the gesture --
        // piece dragging and board panning both sit it out rather than
        // fight a second finger for the same touch stream.
        if (scaleGestureDetector.isInProgress) {
            endSingleFingerInteraction()
            return true
        }

        // Only feeds maybeStartFlip() via onDoubleTap -- doesn't otherwise
        // participate in or consume the drag/fling/pan handling below,
        // which runs unchanged for every event.
        flipGestureDetector.onTouchEvent(event)

        val (boardX, boardY) = screenToBoard(event.x, event.y)

        return when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val piece = activeGame.findTopPieceAt(boardX, boardY)
                if (piece != null) {
                    // The double-tap that just started a flip on this same
                    // event shouldn't also start a drag on it.
                    if (piece === flippingPiece) return true
                    stopFling()
                    if (piece.group === pileSlideGroup) {
                        pileSlideAnimator.cancel()
                        pileSlideGroup = null
                    }
                    draggingPiece = piece
                    activeGame.bringToFront(piece)
                    lastTouchX = boardX
                    lastTouchY = boardY
                    velocityTracker = VelocityTracker.obtain().apply { addMovement(event) }
                    beginLift(piece.group)
                    invalidate()
                } else {
                    // Empty board space: pan instead of dragging a piece.
                    isPanning = true
                    lastPanX = event.x
                    lastPanY = event.y
                }
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val piece = draggingPiece
                when {
                    piece != null -> {
                        velocityTracker?.addMovement(event)
                        val dx = boardX - lastTouchX
                        val dy = boardY - lastTouchY
                        activeGame.moveBy(piece, dx, dy)
                        clampToBounds(piece.group)
                        updateDragTilt(dx)
                        lastTouchX = boardX
                        lastTouchY = boardY
                        invalidate()
                        true
                    }
                    isPanning -> {
                        boardPanX += event.x - lastPanX
                        boardPanY += event.y - lastPanY
                        lastPanX = event.x
                        lastPanY = event.y
                        clampCamera()
                        invalidate()
                        true
                    }
                    else -> false
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val piece = draggingPiece
                draggingPiece = null
                if (piece != null) {
                    var flung = false
                    val tracker = velocityTracker
                    if (event.actionMasked == MotionEvent.ACTION_UP && tracker != null) {
                        val maxVelocity = viewConfiguration.scaledMaximumFlingVelocity.toFloat()
                        tracker.computeCurrentVelocity(1000, maxVelocity)
                        flung = maybeFling(piece, tracker.xVelocity, tracker.yVelocity)
                    }
                    if (!flung) finishPlacing(piece)
                }
                velocityTracker?.recycle()
                velocityTracker = null
                isPanning = false
                true
            }
            else -> false
        }
    }

    /**
     * Called the instant a second finger turns a single-finger gesture
     * into a pinch: wraps up whatever that first finger was doing --
     * dropping a dragged piece in place (same as a normal release, just
     * with no fling, since there's no clean single-finger velocity once a
     * second finger is already down) or simply stopping a pan -- so it
     * isn't left half-finished, fighting the pinch for the rest of the
     * gesture.
     */
    private fun endSingleFingerInteraction() {
        val piece = draggingPiece
        if (piece != null) {
            draggingPiece = null
            velocityTracker?.recycle()
            velocityTracker = null
            finishPlacing(piece)
        }
        isPanning = false
    }

    /**
     * Common tail end of a drop, whether it came from a drag release or a
     * fling coming to rest: tries to connect [piece] to a neighbor,
     * settles the pick-up lift/tilt back down, and -- only when it
     * *didn't* connect, since a piece that just joined the assembly isn't
     * part of a loose pile anymore -- checks whether it landed somewhere
     * too crowded and needs to slide clear (see [resolvePileOverlap]).
     */
    private fun finishPlacing(piece: PuzzlePiece) {
        val activeGame = game ?: return
        val connected = activeGame.tryConnect(piece)
        beginSettle()
        if (!connected) resolvePileOverlap(piece.group)
        invalidate()
        if (connected) {
            onPiecePlaced?.invoke(activeGame.connectedCount, activeGame.pieceCount)
            triggerSnapPulse(piece.group)
        }
    }

    /** Nudges [liftTiltDegrees] toward a target derived from this move
     * event's horizontal delta -- eased rather than snapped straight to
     * it, so the piece reads as trailing behind the finger a beat, the
     * way something with real weight would, rather than rotating in
     * lockstep. */
    private fun updateDragTilt(dx: Float) {
        val target = (dx * TILT_DEGREES_PER_PX).coerceIn(-MAX_TILT_DEGREES, MAX_TILT_DEGREES)
        liftTiltDegrees += (target - liftTiltDegrees) * TILT_RESPONSIVENESS
    }

    /**
     * Starts a physics-based fling of [piece]'s group if ([vx], [vy]) --
     * in raw screen pixels/sec, same as [VelocityTracker] reports -- is
     * fast enough to count as a deliberate swipe-throw rather than a
     * normal drag release. The *threshold* check stays in screen space,
     * so how hard a flick needs to be doesn't change with zoom; the
     * simulated fling itself runs in board space (dividing by
     * [boardScale]), so the same-feeling flick covers the same board
     * distance regardless of zoom level. Returns whether a fling was
     * started.
     */
    private fun maybeFling(piece: PuzzlePiece, vx: Float, vy: Float): Boolean {
        if (sqrt(vx * vx + vy * vy) < viewConfiguration.scaledMinimumFlingVelocity) return false

        flingPiece = piece
        flingPhysics.start(vx / boardScale, vy / boardScale)
        lastFlingFrameTimeNanos = System.nanoTime()
        postOnAnimation(flingTicker)
        return true
    }

    private fun stopFling() {
        if (flingPiece != null) {
            flingPhysics.stop()
            flingPiece = null
        }
    }

    private fun triggerSnapPulse(group: PieceGroup) {
        val bounds = groupBounds(group)
        snapPulseCenterX = bounds.centerX()
        snapPulseCenterY = bounds.centerY()
        snapPulseGroup = group
        snapPulseAnimator.cancel()
        snapPulseAnimator.start()
    }

    private fun groupBounds(group: PieceGroup): RectF {
        var left = Float.MAX_VALUE
        var top = Float.MAX_VALUE
        var right = -Float.MAX_VALUE
        var bottom = -Float.MAX_VALUE
        for (member in group.members) {
            left = min(left, member.currentX)
            top = min(top, member.currentY)
            right = max(right, member.currentX + member.width)
            bottom = max(bottom, member.currentY + member.height)
        }
        return RectF(left, top, right, bottom)
    }

    /**
     * Checks whether [group] just landed somewhere already crowded with
     * other *loose* pieces -- see [PilePhysics] -- and if so, kicks off a
     * short slide clear of them. Deliberately ignores pieces already
     * fused into a bigger group (size > 1): those represent the picture
     * actually being assembled, not the scatter pile, and a piece
     * settling near that assembly shouldn't get physically shoved away
     * from it. No-op if the spot is fine as-is.
     */
    private fun resolvePileOverlap(group: PieceGroup) {
        val activeGame = game ?: return
        val bounds = groupBounds(group)
        val neighborCenters = activeGame.piecesInDrawOrder().mapNotNull { other ->
            if (other.group === group || other.group.size > 1) null
            else PointF(other.currentX + other.width / 2f, other.currentY + other.height / 2f)
        }
        val myRadius = max(bounds.width(), bounds.height()) / 2f
        val checkRadius = (myRadius + activeGame.averagePieceExtent / 2f) * PILE_CHECK_RADIUS_FACTOR

        val nudge = PilePhysics.resolveOverlap(bounds.centerX(), bounds.centerY(), neighborCenters, checkRadius)
            ?: return

        pileSlideAnimator.cancel()
        pileSlideGroup = group
        pileSlideStartX = bounds.centerX()
        pileSlideStartY = bounds.centerY()

        // Move to the raw nudged position, let the existing bounds-clamp
        // pull it back onto the board if that overshot, then hop straight
        // back to the start -- the animator is what actually moves it
        // there, frame by frame, so the slide is seen rather than
        // teleported.
        group.moveBy(nudge.dx, nudge.dy)
        clampToBounds(group)
        val clamped = groupBounds(group)
        pileSlideTargetX = clamped.centerX()
        pileSlideTargetY = clamped.centerY()
        group.moveBy(pileSlideStartX - pileSlideTargetX, pileSlideStartY - pileSlideTargetY)

        pileSlideAnimator.start()
    }

    /**
     * Rigidly translates [group] back within the board's pixel bounds if
     * dragging or flinging pushed any of its member pieces past an edge.
     * A group's own footprint is always <= the board (it's built from
     * pieces cut to fit the view), so only *position* ever needs
     * correcting here, never size. Reports which axis (if either) actually
     * hit a wall, so an in-progress fling can bounce off it -- see
     * [FlingPhysics.reflectX]/[FlingPhysics.reflectY].
     */
    private fun clampToBounds(group: PieceGroup): ClampResult {
        val bounds = groupBounds(group)

        var correctionX = 0f
        var correctionY = 0f
        var hitX = false
        var hitY = false
        if (bounds.width() <= width) {
            if (bounds.left < 0f) {
                correctionX = -bounds.left
                hitX = true
            } else if (bounds.right > width) {
                correctionX = width - bounds.right
                hitX = true
            }
        }
        if (bounds.height() <= height) {
            if (bounds.top < 0f) {
                correctionY = -bounds.top
                hitY = true
            } else if (bounds.bottom > height) {
                correctionY = height - bounds.bottom
                hitY = true
            }
        }
        if (correctionX != 0f || correctionY != 0f) group.moveBy(correctionX, correctionY)
        return ClampResult(hitX, hitY)
    }

    companion object {
        /** How long the on-solve celebration (border fade + picture pop +
         * confetti) plays. [PuzzleActivity] reads this too, to delay its
         * own win overlay until the celebration has had room to play out
         * -- kept in one place so the two can't drift apart. */
        const val COMPLETION_CELEBRATION_DURATION_MS = 1100L

        // How much of the board's own width/height the photo/reference
        // area is fit into (see start()) -- the remainder is free space
        // pieces can scatter and drag into. Applied independently per
        // axis, then centered, so a very wide or very tall source photo
        // still ends up bounded by whichever axis is actually tighter.
        private const val PHOTO_AREA_WIDTH_FRACTION = 0.62f
        private const val PHOTO_AREA_HEIGHT_FRACTION = 0.5f

        private const val SNAP_THRESHOLD_DP = 12f
        private const val REFERENCE_ALPHA = 36
        private const val FRAME_HIGHLIGHT_DP = 2f
        private const val FRAME_BAND_DP = 9f
        private const val FRAME_GLOW_DP = 14f
        private const val FRAME_CORNER_DP = 6f

        // Kept thin/low-opacity on purpose: this used to stack visually
        // with the thickness sliver below into a heavy double-dark
        // outline. Its job is just to separate adjacent pieces while
        // unsolved, not to read as a cartoon outline.
        private const val BORDER_STROKE_DP = 0.75f
        private const val BORDER_BASE_OPACITY = 0.22f

        private const val FLING_DECELERATION_DP_PER_SEC2 = 6000f
        private const val WALL_RESTITUTION = 0.22f
        private const val MAX_FRAME_DELTA_SECONDS = 0.05f

        private const val SNAP_PULSE_DURATION_MS = 220L
        private const val SNAP_PULSE_PEAK_SCALE = 0.07f

        private const val BORDER_FADE_FRACTION = 0.4f
        private const val COMPLETION_POP_FRACTION = 0.35f
        private const val COMPLETION_POP_PEAK_SCALE = 0.05f

        // Picking a piece up: how much bigger it renders at full lift, how
        // long the pop-up/settle-down take, and how far it tilts as it's
        // dragged or flung -- see beginLift()/beginSettle() and
        // updateDragTilt()/updateFlingTilt().
        private const val LIFT_SCALE_FACTOR = 0.16f
        private const val LIFT_UP_DURATION_MS = 160L
        private const val SETTLE_DURATION_MS = 220L
        private const val MAX_TILT_DEGREES = 6f
        private const val TILT_DEGREES_PER_PX = 0.6f
        private const val TILT_DEGREES_PER_VELOCITY_PXPS = 0.0018f
        private const val TILT_RESPONSIVENESS = 0.35f

        // The piece's always-on "thickness" sliver and the extra cast
        // shadow shown only while it's lifted -- see drawThickness(). Uses
        // colorPieceThickness, now a material "cardboard edge" tone rather
        // than a near-black shadow color, so it can afford to render fairly
        // solid/opaque without going back to looking like a dark outline.
        private const val THICKNESS_OFFSET_DP = 3.5f
        private const val THICKNESS_BASE_OPACITY = 0.85f
        private const val ELEVATION_MAX_OFFSET_DP = 12f
        private const val ELEVATION_MAX_SCALE_BONUS = 0.05f
        private const val ELEVATION_SHADOW_MAX_ALPHA = 130

        // How much extra the thickness sliver bulges out beyond
        // THICKNESS_OFFSET_DP when a piece is tilted (dragging/flinging,
        // scaled by how close to MAX_TILT_DEGREES it currently is) or
        // mid-flip (scaled by flipThicknessBulge) -- see drawThickness().
        private const val TILT_THICKNESS_BONUS_DP = 1.5f
        private const val FLIP_THICKNESS_BONUS_DP = 3.5f

        // Turning a loose piece over -- see the flip fields/animator above,
        // maybeStartFlip(), and applyFlipRotation().
        private const val FLIP_DURATION_MS = 260L

        // Pinch-to-zoom/pan -- see the camera fields above, screenToBoard(),
        // and clampCamera(). Zoom only ever goes *in* from the default fit
        // (see clampCamera()), so this is a ceiling, not a range.
        private const val MAX_BOARD_SCALE = 4f
        private const val CAMERA_RESET_DURATION_MS = 260L

        // How crowded a spot has to be before a just-dropped piece slides
        // clear of it -- see resolvePileOverlap() and PilePhysics.
        // PILE_CHECK_RADIUS_FACTOR scales how far out "nearby" reaches, in
        // units of the dropped piece's own size plus a typical piece's;
        // PilePhysics.PILE_STABLE_THRESHOLD is the actual crowding cutoff.
        private const val PILE_CHECK_RADIUS_FACTOR = 1.4f
        private const val PILE_SLIDE_DURATION_MS = 280L
    }
}

/** Which axis (if either) [PuzzleBoardView] had to push a group back onto
 * the board for, the last time it checked. */
private data class ClampResult(val hitX: Boolean, val hitY: Boolean)

/** A symmetric "pop": 1f at [fraction] 0 and 1, rising to `1f + peak` at
 * the midpoint -- the shape behind both the snap and completion pulses. */
private fun pulseScale(fraction: Float, peak: Float): Float {
    val clamped = fraction.coerceIn(0f, 1f)
    return 1f + peak * sin(PI.toFloat() * clamped)
}
