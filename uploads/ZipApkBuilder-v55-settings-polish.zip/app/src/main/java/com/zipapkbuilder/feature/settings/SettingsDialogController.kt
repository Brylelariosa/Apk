package com.zipapkbuilder.feature.settings

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.InsetDrawable
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.TokenCrypto
import com.zipapkbuilder.core.iconTile
import com.zipapkbuilder.core.setStartIcon
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions

/**
 * The Settings dialog: a second, larger set of fields mirroring the main
 * screen's token/repo/branch/keystore inputs (handy for editing without the
 * compact main layout), plus download/build history and shortcuts into
 * [com.zipapkbuilder.feature.repo.RepoSwitcher] and
 * [com.zipapkbuilder.feature.keystore.KeystoreController].
 */
class SettingsDialogController(private val activity: MainActivity) {

    private val Int.dp get() = (this * activity.resources.displayMetrics.density).toInt()

    /**
     * One row of a history list: a small tonal tile that says what it is (download, or the
     * build's outcome), a title and a quieter meta line. Sits inside the grouped list
     * container (bg_setting_row) from dialog_settings.xml.
     */
    private fun historyRow(
        iconRes: Int,
        tone: ButtonTone,
        title: String,
        meta: String,
        onLongClick: (() -> Unit)? = null
    ): LinearLayout {
        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 9.dp, 0, 9.dp)
        }
        row.addView(activity.iconTile(iconRes, tone, sizeDp = 32, iconSizeDp = 16, cornerDp = 10).also {
            (it.layoutParams as LinearLayout.LayoutParams).marginEnd = 12.dp
        })
        val info = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        info.addView(TextView(activity).apply {
            text = title
            textSize = 13f
            setTextColor(activity.getColor(R.color.text_primary))
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        })
        info.addView(TextView(activity).apply {
            text = meta
            textSize = 11.5f
            setTextColor(activity.getColor(R.color.text_muted))
            setPadding(0, 1.dp, 0, 0)
        })
        row.addView(info)
        if (onLongClick != null) row.setOnLongClickListener { onLongClick(); true }
        return row
    }

    /** Hairline between history rows — border_default, because divider is nearly invisible on the list surface. */
    private fun historyDivider(): View = View(activity).apply {
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        setBackgroundColor(activity.getColor(R.color.border_default))
    }

    private fun historyEmptyState(message: String): TextView = TextView(activity).apply {
        text = message
        textSize = 12.5f
        setTextColor(activity.getColor(R.color.text_muted))
        gravity = Gravity.CENTER
        setPadding(0, 14.dp, 0, 14.dp)
    }

    fun showSettingsDialog() {
        val view = activity.layoutInflater.inflate(R.layout.dialog_settings, null)

        // Grab settings dialog views
        val sEtToken        = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtToken)
        val sEtRepo         = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtRepo)
        val sEtBranch       = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtBranch)
        val sEtKeystorePass = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtKeystorePass)
        val sEtKeyAlias     = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtKeyAlias)
        val sTvOwnerInfo    = view.findViewById<TextView>(R.id.sTvOwnerInfo)
        val sTvKeystoreStatus = view.findViewById<TextView>(R.id.sTvKeystoreStatus)
        val sBtnSwitchRepo  = view.findViewById<View>(R.id.sBtnSwitchRepo)
        val sSwitchUploadRoot = view.findViewById<CompoundButton>(R.id.sSwitchUploadRoot)
        val sBtnGenerate    = view.findViewById<View>(R.id.sBtnGenerateKeystore)
        val sBtnClose       = view.findViewById<android.widget.ImageButton>(R.id.btnCloseSettings)
        val sBtnSave        = view.findViewById<View>(R.id.sBtnSave)
        val tvDownloadPath    = view.findViewById<TextView>(R.id.tvDownloadPath)
        val sBtnPickFolder    = view.findViewById<View>(R.id.sBtnPickFolder)
        val sBtnClearFolder   = view.findViewById<View>(R.id.sBtnClearFolder)
        val sBtnClearHistory  = view.findViewById<View>(R.id.sBtnClearHistory)
        val layoutDlHistory   = view.findViewById<LinearLayout>(R.id.layoutDownloadHistory)
        val sBtnClearBuildHistory = view.findViewById<View>(R.id.sBtnClearBuildHistory)
        val layoutBuildHistory    = view.findViewById<LinearLayout>(R.id.layoutBuildHistory)
        val tvBuildStats          = view.findViewById<TextView>(R.id.tvBuildStats)

        // The layout declares these two sans-serif so their floating labels come out sans-serif
        // (a TextInputLayout copies its EditText's typeface for the label when the EditText is
        // attached, and password fields are monospace by default). The characters themselves read
        // better monospaced — a token shown in full has O/0 and l/1 to tell apart — so switch the
        // fields over now that the labels have been set up.
        sEtToken.typeface = Typeface.MONOSPACE
        sEtKeystorePass.typeface = Typeface.MONOSPACE

        // Leading glyphs for the two "all good" status chips (their text and visibility are set below).
        val okGreen = activity.getColor(R.color.accent_green)
        sTvOwnerInfo.setStartIcon(activity, R.drawable.ic_github, okGreen, sizeDp = 14, paddingDp = 6)
        sTvKeystoreStatus.setStartIcon(activity, R.drawable.ic_check, okGreen, sizeDp = 14, paddingDp = 6)

        // Show current download path
        fun refreshDownloadPath() {
            val uri = activity.prefs.getString(PrefKeys.PREF_DOWNLOAD_URI, null)
            tvDownloadPath.text = if (uri != null) {
                Uri.parse(uri).lastPathSegment ?: uri
            } else {
                "Downloads folder (default)"
            }
        }
        refreshDownloadPath()

        // Populate download history: one row per download, newest first, in the grouped list
        // container from the layout (rows separated by hairlines, none after the last).
        fun refreshHistory() {
            layoutDlHistory.removeAllViews()
            val entries = activity.downloadManager.loadDownloadHistory()
            if (entries.isEmpty()) {
                layoutDlHistory.addView(historyEmptyState("No downloads yet"))
                return
            }
            entries.forEachIndexed { index, entry ->
                val name = entry.optString("name", "unknown")
                val path = entry.optString("path", "")
                val size = entry.optLong("size", 0L)
                val time = entry.optLong("time", 0L)
                if (index > 0) layoutDlHistory.addView(historyDivider())
                layoutDlHistory.addView(
                    historyRow(
                        iconRes = if (name.endsWith(".apk", ignoreCase = true)) R.drawable.ic_package else R.drawable.ic_zip,
                        tone = ButtonTone.TEAL,
                        title = name,
                        meta = "${Formatters.fmtBytes(size)}  ·  ${Formatters.fmtLocalTime(time)}"
                    ) {
                        // Long-press copies the path
                        val clip = android.content.ClipData.newPlainText("path", path)
                        (activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                        android.widget.Toast.makeText(activity, "Path copied", android.widget.Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
        refreshHistory()

        // Populate build history — outcome tile, repo/branch, duration, and a one-line stats
        // summary (the section subtitle) computed straight from what's stored locally (no
        // network call needed, unlike the live Build Log run browser).
        fun refreshBuildHistory() {
            layoutBuildHistory.removeAllViews()
            val entries = activity.buildFlowController.loadBuildHistory()
            if (entries.isEmpty()) {
                tvBuildStats.text = "No builds recorded yet"
                layoutBuildHistory.addView(historyEmptyState("No builds yet"))
                return
            }
            val successEntries = entries.filter { it.optString("outcome") == "success" }
            val pct = (successEntries.size * 100) / entries.size
            val avgMs = if (successEntries.isNotEmpty())
                successEntries.sumOf { it.optLong("durationMs", 0L) } / successEntries.size else 0L
            tvBuildStats.text = "${entries.size} ${if (entries.size == 1) "build" else "builds"} · $pct% success" +
                if (successEntries.isNotEmpty()) " · avg ${Formatters.fmtDuration(avgMs)}" else ""

            entries.forEachIndexed { index, entry ->
                val repo       = entry.optString("repo", "?")
                val branch     = entry.optString("branch", "")
                val outcome    = entry.optString("outcome", "failed")
                val durationMs = entry.optLong("durationMs", 0L)
                val time       = entry.optLong("time", 0L)
                val (iconRes, tone) = when (outcome) {
                    "success"   -> R.drawable.ic_check to ButtonTone.GREEN
                    "cancelled" -> R.drawable.ic_close to ButtonTone.SURFACE
                    else        -> R.drawable.ic_warning to ButtonTone.RED
                }
                if (index > 0) layoutBuildHistory.addView(historyDivider())
                layoutBuildHistory.addView(
                    historyRow(
                        iconRes = iconRes,
                        tone = tone,
                        title = if (branch.isNotEmpty()) "$repo  ($branch)" else repo,
                        meta = "${Formatters.fmtDuration(durationMs)}  ·  ${Formatters.fmtLocalTime(time)}"
                    )
                )
            }
        }
        refreshBuildHistory()

        // Pre-populate from main activity fields
        sEtToken.setText(activity.etToken.text)
        sEtRepo.setText(activity.etRepo.text)
        sEtBranch.setText(activity.etBranch.text)
        sEtKeystorePass.setText(activity.etKeystorePass.text)
        sEtKeyAlias.setText(activity.etKeyAlias.text)
        val uploadToRootWasOn = activity.prefs.getBoolean(PrefKeys.PREF_UPLOAD_TO_ROOT, false)
        sSwitchUploadRoot.isChecked = uploadToRootWasOn

        // Mirror owner chip if visible
        if (activity.tvOwnerInfo.visibility == View.VISIBLE && activity.tvOwnerInfo.text.isNotEmpty()) {
            sTvOwnerInfo.text = activity.tvOwnerInfo.text
            sTvOwnerInfo.visibility = View.VISIBLE
        }
        // Mirror keystore status if visible
        if (activity.tvKeystoreStatus.visibility == View.VISIBLE && activity.tvKeystoreStatus.text.isNotEmpty()) {
            sTvKeystoreStatus.text = activity.tvKeystoreStatus.text
            sTvKeystoreStatus.visibility = View.VISIBLE
        }

        val dialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setView(view)
            .setCancelable(true)
            .create()
        // The dialog draws its own rounded surface (bg_dialog_root_rounded), so the window
        // background is transparent — wrapped in an InsetDrawable so the dialog floats with a
        // margin on every side, like the other popups, instead of running edge to edge. The
        // inset doubles as the window's padding, which also caps the dialog's height.
        val insetH = 10.dp
        val insetV = 16.dp
        dialog.window?.setBackgroundDrawable(
            InsetDrawable(ColorDrawable(Color.TRANSPARENT), insetH, insetV, insetH, insetV)
        )

        fun saveAndClose() {
            // Write back to main activity fields
            activity.etToken.setText(sEtToken.text)
            activity.etRepo.setText(sEtRepo.text)
            activity.etBranch.setText(sEtBranch.text)
            activity.etKeystorePass.setText(sEtKeystorePass.text)
            activity.etKeyAlias.setText(sEtKeyAlias.text)
            // Persist to prefs
            val tokenText = sEtToken.text.toString().trim()
            val encryptedToken = TokenCrypto.encrypt(tokenText)
            if (encryptedToken != null) {
                activity.securePrefs.edit().putString(PrefKeys.PREF_TOKEN, encryptedToken).apply()
            } else {
                // Fail closed (see TokenCrypto.encrypt's kdoc) — never store the
                // token unencrypted. Nothing typed above is lost; it just isn't
                // persisted to disk until a save succeeds.
                activity.appendLog("[warn] Could not securely save your GitHub token on this device — it's still filled in, but you'll need to save again for it to persist.")
            }
            activity.prefs.edit()
                .putString(PrefKeys.PREF_REPO,   sEtRepo.text.toString().trim())
                .putString(PrefKeys.PREF_BRANCH, sEtBranch.text.toString().trim().ifEmpty { "main" })
                .putBoolean(PrefKeys.PREF_UPLOAD_TO_ROOT, sSwitchUploadRoot.isChecked)
                .apply()
            // Only note this the moment it's actually switched on, not every save while it
            // happens to already be on — the caveat is worth surfacing once, not repeating.
            if (sSwitchUploadRoot.isChecked && !uploadToRootWasOn) {
                activity.appendLog(
                    "[info] Upload destination set to repo root. A brand-new repo's workflow " +
                        "already watches for this; an existing repo's committed build.yml may " +
                        "still only watch uploads/ — if a root upload doesn't trigger a build, " +
                        "delete and let the app recommit build.yml, or update its trigger paths yourself."
                )
            }
            dialog.dismiss()
        }

        // Back-press and tap-outside both go through this (setCancelable(true) above),
        // which otherwise defaults to a bare dismiss — the same silent-discard gap the
        // X button had. Routing it through saveAndClose() closes that gap too, so every
        // way of leaving this dialog behaves the same, consistent way.
        dialog.setOnCancelListener { saveAndClose() }

        sBtnSave.setOnClickListener     { saveAndClose() }
        // X used to just dismiss() — silently discarding any edits made in this
        // session, since only "Save & close" actually persisted them (and that bar was
        // pushed off-screen on a tall form; it is pinned now). That's a real correctness trap: edit the
        // branch/repo/token, close with the far more prominent top-right X, and every
        // subsequent action (including triggering a workflow) would keep using the
        // OLD values with no indication anything was lost. X now saves too, exactly
        // like the "Switch Repository" button below already does.
        sBtnClose.setOnClickListener     { saveAndClose() }
        sBtnSwitchRepo.setOnClickListener {
            saveAndClose()
            activity.repoSwitcher.showSavedReposDialog()
        }
        sBtnGenerate.setOnClickListener {
            // Copy pass/alias back first so generateKeystore() reads correct values
            activity.etKeystorePass.setText(sEtKeystorePass.text)
            activity.etKeyAlias.setText(sEtKeyAlias.text)
            dialog.dismiss()
            activity.keystoreController.generateKeystore()
        }

        sBtnPickFolder.setOnClickListener {
            activity.onFolderPicked = { refreshDownloadPath() }
            activity.pickFolderLauncher.launch(null)
        }

        sBtnClearFolder.setOnClickListener {
            activity.prefs.edit().remove(PrefKeys.PREF_DOWNLOAD_URI).apply()
            refreshDownloadPath()
        }

        sBtnClearHistory.setOnClickListener {
            val count = activity.downloadManager.loadDownloadHistory().size
            if (count == 0) { refreshHistory(); return@setOnClickListener }
            lateinit var clearDlg: AlertDialog
            val content = activity.dialogWithActions(
                activity.dialogMessage("This will permanently remove all $count download history ${if (count == 1) "entry" else "entries"}. " +
                    "The downloaded files themselves aren't touched — only this list.\n\nThis can't be undone."),
                DialogAction("Clear", ButtonTone.RED, R.drawable.ic_delete) {
                    clearDlg.dismiss()
                    activity.prefs.edit().remove(PrefKeys.PREF_DOWNLOAD_HISTORY).apply()
                    refreshHistory()
                },
                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { clearDlg.dismiss() }
            )
            clearDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setCustomTitle(activity.dialogTitleBar("Clear download history?", R.drawable.ic_delete, ButtonTone.RED) { clearDlg.dismiss() })
                .setView(content)
                .show()
        }

        sBtnClearBuildHistory.setOnClickListener {
            val count = activity.buildFlowController.loadBuildHistory().size
            if (count == 0) { refreshBuildHistory(); return@setOnClickListener }
            lateinit var clearDlg: AlertDialog
            val content = activity.dialogWithActions(
                activity.dialogMessage("This will permanently remove all $count build history ${if (count == 1) "entry" else "entries"} " +
                    "(the local success/fail/duration record — not anything on GitHub).\n\nThis can't be undone."),
                DialogAction("Clear", ButtonTone.RED, R.drawable.ic_delete) {
                    clearDlg.dismiss()
                    activity.prefs.edit().remove(PrefKeys.PREF_BUILD_HISTORY).apply()
                    refreshBuildHistory()
                },
                DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { clearDlg.dismiss() }
            )
            clearDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setCustomTitle(activity.dialogTitleBar("Clear build history?", R.drawable.ic_delete, ButtonTone.RED) { clearDlg.dismiss() })
                .setView(content)
                .show()
        }

        dialog.show()

        // Full-width window; the InsetDrawable above is what leaves the margin around the dialog.
        dialog.window?.setLayout(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )

        // The margin is still part of the window, so a tap there is not "outside" as far as the
        // framework is concerned; treat it as a tap outside, which cancels (and so saves) via the
        // cancel listener above. Installed after show(): asking a platform AlertDialog's window
        // for its decor view any earlier would install the decor before the dialog has asked for
        // a title-less window.
        dialog.window?.decorView?.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_UP &&
                (event.x < insetH || event.y < insetV || event.x > v.width - insetH || event.y > v.height - insetV)
            ) {
                v.performClick()
                dialog.cancel()
            }
            false
        }
    }
}
