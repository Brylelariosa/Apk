package com.gamebooster;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Searchable app-picker presented as a Material bottom sheet.
 *
 * <h3>App-load pipeline</h3>
 * <ol>
 *   <li>Show a loading spinner immediately.</li>
 *   <li>Enumerate installed packages on a background {@link ExecutorService} thread.</li>
 *   <li>Post the list back to the main thread via {@link Handler}.</li>
 *   <li>Load app icons in a second background pass (one icon per 16 ms budget).</li>
 *   <li>Show an empty state if no user apps are found.</li>
 * </ol>
 *
 * <h3>Memory safety</h3>
 * The background executor is shut down in {@link #onDestroyView} so no background
 * thread can call back into a destroyed view hierarchy.
 */
public class AppPickerBottomSheet extends BottomSheetDialogFragment {

    public static final String TAG = "AppPickerBottomSheet";

    /** Callback delivered when the user taps an app. */
    public interface OnAppPicked {
        void onAppPicked(AppInfo app);
    }

    // ── UI ────────────────────────────────────────────────────────────────────

    private RecyclerView rvApps;
    private SearchView   searchView;
    private View         progressBar;
    private TextView     tvEmpty;

    // ── Data ──────────────────────────────────────────────────────────────────

    private AppAdapter       adapter;
    private GamePreferences  prefs;
    private OnAppPicked      pickedCallback;
    private ExecutorService  executor;
    private final Handler    mainHandler = new Handler(Looper.getMainLooper());

    // ── Factory ───────────────────────────────────────────────────────────────

    public static AppPickerBottomSheet newInstance() {
        return new AppPickerBottomSheet();
    }

    public void setOnAppPicked(OnAppPicked cb) {
        this.pickedCallback = cb;
    }

    // ── Fragment lifecycle ────────────────────────────────────────────────────

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_app_picker, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvApps      = view.findViewById(R.id.rv_apps);
        searchView  = view.findViewById(R.id.search_view);
        progressBar = view.findViewById(R.id.progress_loading);
        tvEmpty     = view.findViewById(R.id.tv_empty);

        prefs   = new GamePreferences(requireContext());
        adapter = new AppAdapter();
        executor = Executors.newSingleThreadExecutor();

        rvApps.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvApps.setAdapter(adapter);
        // Improve scroll performance — all items are the same height.
        rvApps.setHasFixedSize(false);

        adapter.setOnAppSelected(app -> {
            prefs.saveLastGame(app);
            if (pickedCallback != null) pickedCallback.onAppPicked(app);
            dismiss();
        });

        adapter.setOnFavoriteToggle((app, position) -> {
            prefs.toggleFavorite(app.packageName);
            app.isFavorite = prefs.isFavorite(app.packageName);
            adapter.notifyFavoriteChanged(position);
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String q) { return false; }
            @Override public boolean onQueryTextChange(String newText) {
                adapter.filter(newText);
                return true;
            }
        });

        loadAppsAsync();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        // Cancel any in-flight background work to prevent callbacks into destroyed views.
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
        mainHandler.removeCallbacksAndMessages(null);
    }

    // ── Background app load ───────────────────────────────────────────────────

    /**
     * Phase 1: enumerate package labels on a background thread, post to main thread.
     * Phase 2: load icons lazily so the list appears immediately.
     */
    private void loadAppsAsync() {
        showLoading(true);

        executor.execute(() -> {
            List<AppInfo> list = buildAppList();

            mainHandler.post(() -> {
                if (getView() == null || executor == null) return; // view destroyed

                showLoading(false);
                if (list.isEmpty()) {
                    tvEmpty.setVisibility(View.VISIBLE);
                    rvApps.setVisibility(View.GONE);
                } else {
                    tvEmpty.setVisibility(View.GONE);
                    rvApps.setVisibility(View.VISIBLE);
                    adapter.submitList(list);
                    loadIconsAsync(list);
                }
            });
        });
    }

    /**
     * Builds the app list (labels only — no icons yet).
     * Must be called from a background thread.
     */
    private List<AppInfo> buildAppList() {
        PackageManager pm = requireContext().getPackageManager();
        Set<String>    favorites = prefs.getFavorites();
        List<String>   recents   = prefs.getRecentPackages();

        List<AppInfo> list = new ArrayList<>();
        try {
            List<ApplicationInfo> installed =
                pm.getInstalledApplications(PackageManager.GET_META_DATA);

            for (ApplicationInfo info : installed) {
                boolean isSystem  = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                boolean isUpdated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                if (isSystem && !isUpdated) continue;

                String label = pm.getApplicationLabel(info).toString();
                AppInfo app  = new AppInfo(label, info.packageName);
                app.isFavorite    = favorites.contains(info.packageName);
                app.lastBoostTime = recents.indexOf(info.packageName) >= 0
                    ? System.currentTimeMillis() - (long) recents.indexOf(info.packageName) * 1000L
                    : 0L;
                list.add(app);
            }
        } catch (Exception e) {
            // PackageManager.DeadObjectException or SecurityException — return empty.
            android.util.Log.w(TAG, "App scan failed", e);
        }

        // Sort: favourites first, then alphabetically
        Collections.sort(list, (a, b) -> {
            if (a.isFavorite != b.isFavorite) return a.isFavorite ? -1 : 1;
            return a.label.compareToIgnoreCase(b.label);
        });

        return list;
    }

    /**
     * Phase 2: loads icons on a background thread, posting individual
     * {@code notifyItemChanged} calls back to the main thread.
     * Each icon load is gated behind a 4 ms sleep to stay within the 16 ms frame budget.
     */
    private void loadIconsAsync(List<AppInfo> list) {
        if (executor == null) return;
        executor.execute(() -> {
            PackageManager pm = requireContext().getPackageManager();
            for (int i = 0; i < list.size(); i++) {
                if (Thread.currentThread().isInterrupted()) break;
                AppInfo app = list.get(i);
                try {
                    app.icon = pm.getApplicationIcon(app.packageName);
                } catch (PackageManager.NameNotFoundException ignored) {}
                final int pos = i;
                mainHandler.post(() -> {
                    if (adapter != null) adapter.notifyItemChanged(pos);
                });
                try { Thread.sleep(4); } catch (InterruptedException e) { break; }
            }
        });
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private void showLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        rvApps.setVisibility(loading ? View.GONE : View.VISIBLE);
    }
}
