package com.gamebooster;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

/**
 * Premium dashboard activity for GameBooster.
 *
 * <h3>Architecture improvements vs original</h3>
 * <ul>
 *   <li>Service state communicated via {@link LocalBroadcastManager} — no stale static field.</li>
 *   <li>Last selected game persisted in {@link GamePreferences}.</li>
 *   <li>Searchable app picker via {@link AppPickerBottomSheet} with icons.</li>
 *   <li>Three boost profiles — Battery Saver / Balanced / Max Performance.</li>
 *   <li>Real-time memory, CPU, and battery stats while boosting.</li>
 *   <li>Screen rotation handled via {@link #onSaveInstanceState}.</li>
 *   <li>Permissions shown as compact status cards with icons.</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // Saved instance state keys
    private static final String KEY_SELECTED_PKG   = "sel_pkg";
    private static final String KEY_SELECTED_LABEL = "sel_label";

    // ── Views — Hero card ─────────────────────────────────────────────────────
    private ImageView    ivHeroIcon;
    private TextView     tvHeroGameName;
    private TextView     tvHeroStatus;
    private TextView     tvHeroTweaks;

    // ── Views — Permission cards ───────────────────────────────────────────────
    private MaterialCardView cardPermUsage;
    private MaterialCardView cardPermDnd;
    private MaterialCardView cardPermBrightness;
    private ImageView        ivPermUsage, ivPermDnd, ivPermBrightness;
    private TextView         tvPermUsage, tvPermDnd, tvPermBrightness;

    // ── Views — Boost profiles ────────────────────────────────────────────────
    private MaterialCardView cardBattery, cardBalanced, cardMax;

    // ── Views — Live stats ────────────────────────────────────────────────────
    private View      statsSection;
    private TextView  tvStatRam, tvStatCpu, tvStatBattery;

    // ── Views — Options ───────────────────────────────────────────────────────
    private SwitchCompat switchVpn;

    // ── Views — Action ────────────────────────────────────────────────────────
    private MaterialButton btnBoost;
    private MaterialButton btnPickGame;

    // ── State ─────────────────────────────────────────────────────────────────
    private AppInfo          selectedApp;
    private BoostProfile     selectedProfile;
    private boolean          isBoosting = false;
    private GamePreferences  prefs;

    // ── Stats polling ─────────────────────────────────────────────────────────
    private final Handler statsHandler = new Handler(Looper.getMainLooper());

    // ── Activity result launchers ─────────────────────────────────────────────
    private ActivityResultLauncher<Intent> permLauncher;
    private ActivityResultLauncher<Intent> vpnConsentLauncher;
    private String pendingVpnPackage;

    // ── Local broadcast receiver ──────────────────────────────────────────────
    private final BroadcastReceiver boostStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            if (BoostService.ACTION_STATE_CHANGED.equals(intent.getAction())) {
                boolean running = intent.getBooleanExtra(BoostService.EXTRA_IS_RUNNING, false);
                syncBoostUi(running);
            }
        }
    };

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new GamePreferences(this);

        bindViews();
        setupActivityResultLaunchers();
        setupProfileCards();
        setupVpnSwitch();
        setupPickGameButton();

        // Restore instance state (survives rotation)
        if (savedInstanceState != null) {
            String pkg   = savedInstanceState.getString(KEY_SELECTED_PKG);
            String label = savedInstanceState.getString(KEY_SELECTED_LABEL);
            if (pkg != null) {
                AppInfo restored = new AppInfo(label != null ? label : pkg, pkg);
                restored.isFavorite = prefs.isFavorite(pkg);
                onAppSelected(restored);
            }
        } else {
            // Restore from persistent storage (survives app restart)
            restoreLastGame();
        }

        // Restore persisted settings
        selectedProfile = prefs.getProfile();
        switchVpn.setChecked(prefs.isVpnEnabled());
        highlightProfileCard(selectedProfile);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionCards();

        // Register broadcast receiver to track service state
        IntentFilter filter = new IntentFilter(BoostService.ACTION_STATE_CHANGED);
        LocalBroadcastManager.getInstance(this).registerReceiver(boostStateReceiver, filter);

        // Detect if service is already running (e.g. user navigated away and back)
        // We rely on the broadcast from the service at startup; as a fallback we check
        // the service directly by querying ActivityManager.
        syncBoostUi(isBoostServiceRunning());
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(boostStateReceiver);
        stopStatsPolling();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (selectedApp != null) {
            outState.putString(KEY_SELECTED_PKG,   selectedApp.packageName);
            outState.putString(KEY_SELECTED_LABEL, selectedApp.label);
        }
    }

    // ── View binding ──────────────────────────────────────────────────────────

    private void bindViews() {
        // Hero card
        ivHeroIcon      = findViewById(R.id.iv_hero_icon);
        tvHeroGameName  = findViewById(R.id.tv_hero_game_name);
        tvHeroStatus    = findViewById(R.id.tv_hero_status);
        tvHeroTweaks    = findViewById(R.id.tv_hero_tweaks);

        // Permission cards
        cardPermUsage      = findViewById(R.id.card_perm_usage);
        cardPermDnd        = findViewById(R.id.card_perm_dnd);
        cardPermBrightness = findViewById(R.id.card_perm_brightness);
        ivPermUsage        = findViewById(R.id.iv_perm_usage);
        ivPermDnd          = findViewById(R.id.iv_perm_dnd);
        ivPermBrightness   = findViewById(R.id.iv_perm_brightness);
        tvPermUsage        = findViewById(R.id.tv_perm_usage_label);
        tvPermDnd          = findViewById(R.id.tv_perm_dnd_label);
        tvPermBrightness   = findViewById(R.id.tv_perm_brightness_label);

        // Profile cards
        cardBattery  = findViewById(R.id.card_profile_battery);
        cardBalanced = findViewById(R.id.card_profile_balanced);
        cardMax      = findViewById(R.id.card_profile_max);

        // Live stats
        statsSection = findViewById(R.id.section_live_stats);
        tvStatRam    = findViewById(R.id.tv_stat_ram);
        tvStatCpu    = findViewById(R.id.tv_stat_cpu);
        tvStatBattery= findViewById(R.id.tv_stat_battery);

        // Options
        switchVpn = findViewById(R.id.switch_vpn);

        // Action buttons
        btnBoost    = findViewById(R.id.btn_boost);
        btnPickGame = findViewById(R.id.btn_pick_game);

        btnBoost.setOnClickListener(v -> onBoostClicked());
    }

    // ── Activity result launchers ─────────────────────────────────────────────

    private void setupActivityResultLaunchers() {
        permLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> updatePermissionCards()
        );

        vpnConsentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> {
                if (r.getResultCode() == Activity.RESULT_OK && pendingVpnPackage != null) {
                    launchVpnService(pendingVpnPackage);
                }
                pendingVpnPackage = null;
            }
        );
    }

    // ── Profile cards ─────────────────────────────────────────────────────────

    private void setupProfileCards() {
        cardBattery.setOnClickListener(v -> selectProfile(BoostProfile.BATTERY_SAVER));
        cardBalanced.setOnClickListener(v -> selectProfile(BoostProfile.BALANCED));
        cardMax.setOnClickListener(v -> selectProfile(BoostProfile.MAX_PERFORMANCE));
    }

    private void selectProfile(BoostProfile profile) {
        selectedProfile = profile;
        prefs.saveProfile(profile);
        highlightProfileCard(profile);
        updateHeroTweaks();

        // Auto-sync VPN switch to reflect profile's recommended setting
        if (profile == BoostProfile.MAX_PERFORMANCE && !switchVpn.isChecked()) {
            switchVpn.setChecked(true);
            prefs.saveVpnEnabled(true);
        }
    }

    private void highlightProfileCard(BoostProfile profile) {
        int selectedStroke = ContextCompat.getColor(this, R.color.boost_color);
        int normalStroke   = ContextCompat.getColor(this, R.color.card_stroke);
        int selectedBg     = ContextCompat.getColor(this, R.color.profile_selected_bg);
        int normalBg       = ContextCompat.getColor(this, R.color.bg_card);

        resetProfileCard(cardBattery,  normalStroke,   normalBg);
        resetProfileCard(cardBalanced, normalStroke,   normalBg);
        resetProfileCard(cardMax,      normalStroke,   normalBg);

        MaterialCardView selected = profile == BoostProfile.BATTERY_SAVER ? cardBattery
            : profile == BoostProfile.MAX_PERFORMANCE ? cardMax : cardBalanced;
        selected.setStrokeColor(selectedStroke);
        selected.setStrokeWidth(dpToPx(2));
        selected.setCardBackgroundColor(selectedBg);
    }

    private void resetProfileCard(MaterialCardView card, int stroke, int bg) {
        card.setStrokeColor(stroke);
        card.setStrokeWidth(dpToPx(1));
        card.setCardBackgroundColor(bg);
    }

    // ── VPN switch ────────────────────────────────────────────────────────────

    private void setupVpnSwitch() {
        switchVpn.setOnCheckedChangeListener((btn, checked) -> prefs.saveVpnEnabled(checked));
    }

    // ── App picker ────────────────────────────────────────────────────────────

    private void setupPickGameButton() {
        btnPickGame.setOnClickListener(v -> openAppPicker());
    }

    private void openAppPicker() {
        AppPickerBottomSheet sheet = AppPickerBottomSheet.newInstance();
        sheet.setOnAppPicked(this::onAppSelected);
        sheet.show(getSupportFragmentManager(), AppPickerBottomSheet.TAG);
    }

    /** Called when the user selects an app in the picker (or on restore). */
    private void onAppSelected(AppInfo app) {
        selectedApp = app;
        prefs.saveLastGame(app);

        tvHeroGameName.setText(app.label);
        tvHeroTweaks.setVisibility(View.VISIBLE);
        updateHeroTweaks();

        // Show cached icon; fall back to default
        if (app.icon != null) {
            ivHeroIcon.setImageDrawable(app.icon);
        } else {
            // Try to load icon on a background thread and update
            new Handler(Looper.getMainLooper()).post(() -> {
                try {
                    Drawable icon = getPackageManager().getApplicationIcon(app.packageName);
                    app.icon = icon;
                    ivHeroIcon.setImageDrawable(icon);
                } catch (Exception e) {
                    ivHeroIcon.setImageResource(R.drawable.ic_gamepad);
                }
            });
        }
    }

    private void restoreLastGame() {
        String pkg   = prefs.getLastPackage();
        String label = prefs.getLastLabel();
        if (pkg != null) {
            AppInfo restored = new AppInfo(label != null ? label : pkg, pkg);
            restored.isFavorite = prefs.isFavorite(pkg);
            onAppSelected(restored);
        }
    }

    // ── Boost control ─────────────────────────────────────────────────────────

    private void onBoostClicked() {
        if (isBoosting) {
            stopBoosting();
        } else {
            startBoosting();
        }
    }

    private void startBoosting() {
        if (!PermissionHelper.hasUsageAccess(this)) {
            showSettingsDialog(
                "Usage Access Required",
                "GameBooster needs Usage Access to detect when your game exits and "
                    + "automatically stop the boost.\n\nTap OK → enable GameBooster "
                    + "under Usage access.",
                PermissionHelper.usageAccessIntent()
            );
            return;
        }

        if (selectedApp == null) {
            Toast.makeText(this, "Tap \"Select Game\" to choose an app first",
                Toast.LENGTH_SHORT).show();
            return;
        }

        // Warn about optional missing permissions without blocking
        if (selectedProfile.enableDnd && !PermissionHelper.hasNotificationPolicyAccess(this)) {
            toast("DND access not granted — silence mode will be skipped");
        }
        if (selectedProfile.enableMaxBrightness && !PermissionHelper.canWriteSettings(this)) {
            toast("Write Settings not granted — brightness boost will be skipped");
        }

        Intent svc = new Intent(this, BoostService.class)
            .putExtra(BoostService.EXTRA_PACKAGE, selectedApp.packageName)
            .putExtra(BoostService.EXTRA_LABEL,   selectedApp.label)
            .putExtra(BoostService.EXTRA_PROFILE,  selectedProfile.name());
        startForegroundService(svc);

        if (selectedProfile.enableVpn && switchVpn.isChecked()) {
            requestVpnConsent(selectedApp.packageName);
        }

        // Optimistic UI update; confirmed by the broadcast from BoostService.
        syncBoostUi(true);
        toast("⚡ Boost started — " + selectedProfile.displayName);
    }

    private void stopBoosting() {
        stopService(new Intent(this, BoostService.class));

        if (BoostVpnService.isRunning) {
            Intent vpnStop = new Intent(this, BoostVpnService.class)
                .setAction(BoostVpnService.ACTION_STOP);
            startService(vpnStop);
        }

        syncBoostUi(false);
        toast("Boost stopped");
    }

    // ── VPN consent ───────────────────────────────────────────────────────────

    private void requestVpnConsent(String gamePackage) {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            pendingVpnPackage = gamePackage;
            vpnConsentLauncher.launch(prepare);
        } else {
            launchVpnService(gamePackage);
        }
    }

    private void launchVpnService(String gamePackage) {
        Intent vpn = new Intent(this, BoostVpnService.class)
            .putExtra(BoostVpnService.EXTRA_GAME_PACKAGE, gamePackage);
        startService(vpn);
    }

    // ── UI sync ───────────────────────────────────────────────────────────────

    private void syncBoostUi(boolean boosting) {
        isBoosting = boosting;

        if (boosting) {
            btnBoost.setText(R.string.btn_stop);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.stop_color));
            tvHeroStatus.setText(R.string.status_active);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.perm_ok));
            statsSection.setVisibility(View.VISIBLE);
            startStatsPolling();
        } else {
            btnBoost.setText(R.string.btn_boost);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.boost_color));
            tvHeroStatus.setText(selectedApp != null ? R.string.status_ready : R.string.status_no_game);
            tvHeroStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            statsSection.setVisibility(View.GONE);
            stopStatsPolling();
        }
    }

    // ── Permission cards ──────────────────────────────────────────────────────

    private void updatePermissionCards() {
        setPermCard(
            cardPermUsage, ivPermUsage, tvPermUsage,
            PermissionHelper.hasUsageAccess(this),
            getString(R.string.perm_usage_short),
            PermissionHelper.usageAccessIntent()
        );
        setPermCard(
            cardPermDnd, ivPermDnd, tvPermDnd,
            PermissionHelper.hasNotificationPolicyAccess(this),
            getString(R.string.perm_dnd_short),
            PermissionHelper.notificationPolicyIntent()
        );
        setPermCard(
            cardPermBrightness, ivPermBrightness, tvPermBrightness,
            PermissionHelper.canWriteSettings(this),
            getString(R.string.perm_brightness_short),
            PermissionHelper.writeSettingsIntent(this)
        );
    }

    private void setPermCard(MaterialCardView card, ImageView icon, TextView label,
                              boolean granted, String text, Intent settingsIntent) {
        int okColor   = ContextCompat.getColor(this, R.color.perm_ok);
        int warnColor = ContextCompat.getColor(this, R.color.perm_warn);
        int okStroke  = ContextCompat.getColor(this, R.color.perm_ok_stroke);
        int warnStroke= ContextCompat.getColor(this, R.color.perm_warn_stroke);

        label.setText(text);
        if (granted) {
            icon.setImageResource(R.drawable.ic_check_circle);
            icon.setColorFilter(okColor);
            card.setStrokeColor(okStroke);
            card.setOnClickListener(null);
        } else {
            icon.setImageResource(R.drawable.ic_warning);
            icon.setColorFilter(warnColor);
            card.setStrokeColor(warnStroke);
            card.setOnClickListener(v -> permLauncher.launch(settingsIntent));
        }
    }

    // ── Hero tweaks count ─────────────────────────────────────────────────────

    private void updateHeroTweaks() {
        if (selectedProfile == null) return;
        int count = selectedProfile.activeTweakCount();
        tvHeroTweaks.setText(count + " optimization" + (count == 1 ? "" : "s") + " active");
    }

    // ── Real-time stats ───────────────────────────────────────────────────────

    private final Runnable statsRunnable = this::refreshStats;

    private void startStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
        statsHandler.post(statsRunnable);
    }

    private void stopStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
    }

    private void refreshStats() {
        // RAM
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long usedMb  = (mi.totalMem - mi.availMem) / (1024 * 1024);
        long totalMb = mi.totalMem / (1024 * 1024);
        tvStatRam.setText(usedMb + " / " + totalMb + " MB");

        // Battery
        IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = registerReceiver(null, ifilter);
        int level = batteryStatus != null
            ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scale = batteryStatus != null
            ? batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
        if (level >= 0 && scale > 0) {
            int pct = (int) ((level / (float) scale) * 100);
            tvStatBattery.setText(pct + "%");
        } else {
            tvStatBattery.setText("—");
        }

        // CPU (simple indicator using available memory ratio as a proxy on older APIs)
        // For a richer signal, a two-sample /proc/stat read is needed; omitted here
        // to avoid blocking the main thread. Show memory pressure instead.
        int pressurePct = (int) (100 - (mi.availMem * 100.0 / mi.totalMem));
        tvStatCpu.setText(pressurePct + "%");

        // Schedule next update while boosting
        if (isBoosting) {
            statsHandler.postDelayed(statsRunnable, 2_000L);
        }
    }

    // ── Service detection ─────────────────────────────────────────────────────

    /** Reliable service-running check that doesn't depend on a static field. */
    @SuppressWarnings("deprecation")
    private boolean isBoostServiceRunning() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo info : am.getRunningServices(Integer.MAX_VALUE)) {
            if (BoostService.class.getName().equals(info.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    // ── Dialog / toast helpers ────────────────────────────────────────────────

    private void showSettingsDialog(String title, String message, Intent intent) {
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Open Settings", (d, w) -> permLauncher.launch(intent))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
