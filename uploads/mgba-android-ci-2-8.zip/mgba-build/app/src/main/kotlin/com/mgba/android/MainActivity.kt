package com.mgba.android

import android.Manifest
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var loadRomBtn:  Button
    private lateinit var linkBtn:     TextView
    private lateinit var settingsBtn: TextView
    private var surfaceHolder: SurfaceHolder? = null
    private var gameThread:    Thread? = null
    @Volatile private var running   = false
    @Volatile private var romLoaded = false
    private var frameBitmap: Bitmap? = null
    private val gameMatrix  = Matrix()
    private val currentKeys = AtomicInteger(0)
    private val buttons     = mutableListOf<ButtonDef>()
    private var controlsTop = 0f
    @Volatile private var pickerLive = false
    private lateinit var link: LinkMultiplayer

    // ── Fast-forward state ─────────────────────────────────────────────────
    @Volatile private var fastForwardSpeed  = 2.0f
    @Volatile private var fastForwardActive = false
    private var ffBtnRect  = RectF()
    private var ffFrameAccumulator = 0.0

    // ── Fullscreen mode (toggled ONLY from Settings) ───────────────────────
    @Volatile private var fullscreenMode = false

    // ── Button / screen customization ─────────────────────────────────────
    private var buttonScaleMultiplier = 1.0f   // 0.75 / 1.0 / 1.25
    private var buttonBaseAlpha       = 160    // idle opacity 0-255
    private var gameScreenFraction    = GAME_FRAC_NORM  // 0.35–0.65

    // ── Audio ──────────────────────────────────────────────────────────────
    @Volatile private var audioTrack: AudioTrack? = null
    private val audioBuffer = ShortArray(2048)

    companion object {
        private const val TAG             = "mGBA"
        private const val GAME_FRAC_NORM  = 0.52f
        private const val CTRL_FRAC_FULL  = 0.60f

        // SharedPreferences
        private const val PREFS            = "mgba_prefs"
        private const val PREF_FF_SPEED    = "ff_speed"
        private const val PREF_BTN_SCALE   = "btn_scale"
        private const val PREF_BTN_ALPHA   = "btn_alpha"
        private const val PREF_SCREEN_FRAC = "screen_frac"
        private const val PREF_FULLSCREEN  = "fullscreen"
    }

    private data class ButtonDef(val rect: RectF, val keyMask: Int, val label: String, val color: Int)

    // ── ROM picker ─────────────────────────────────────────────────────────

    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        Thread {
            try {
                val tmp = cacheDir.resolve("rom_loaded.gba")
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                } ?: run { uiToast("Cannot read selected file"); return@Thread }
                val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath)
                Handler(Looper.getMainLooper()).post {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth()
                        val h = EmulatorEngine.nativeGetHeight()
                        frameBitmap = Bitmap.createBitmap(
                            w.coerceAtLeast(1), h.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        romLoaded = true
                        loadRomBtn.visibility = View.GONE
                        linkBtn.visibility    = View.VISIBLE
                        initAudioTrack()
                        startGameLoop()
                    } else { uiToast("Unsupported ROM format") }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "ROM load failed", e)
                uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            }
        }.apply { name = "mGBA-load" }.start()
    }

    // ── Lifecycle ──────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Load saved preferences
        getSharedPreferences(PREFS, MODE_PRIVATE).also { p ->
            fastForwardSpeed      = p.getFloat(PREF_FF_SPEED,    2.0f)
            buttonScaleMultiplier = p.getFloat(PREF_BTN_SCALE,   1.0f)
            buttonBaseAlpha       = p.getInt(PREF_BTN_ALPHA,      160)
            gameScreenFraction    = p.getFloat(PREF_SCREEN_FRAC, GAME_FRAC_NORM)
            fullscreenMode        = p.getBoolean(PREF_FULLSCREEN, false)
        }

        link = LinkMultiplayer(this)
        val root = FrameLayout(this)
        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        root.addView(surfaceView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        loadRomBtn = Button(this).apply {
            text = "▶  Load ROM"
            setBackgroundColor(Color.parseColor("#BB86FC"))
            setTextColor(Color.BLACK); textSize = 16f
            setOnClickListener { if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) } }
        }
        root.addView(loadRomBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.CENTER })

        linkBtn = TextView(this).apply {
            text = "🔗 Link"; textSize = 13f
            setTextColor(Color.WHITE); setPadding(20, 10, 20, 10)
            setBackgroundColor(Color.parseColor("#44000000"))
            visibility = View.GONE
            setOnClickListener { showLinkDialog() }
        }
        root.addView(linkBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.END; it.topMargin = 8; it.rightMargin = 8 })

        settingsBtn = TextView(this).apply {
            text = "⚙"; textSize = 18f
            setTextColor(Color.WHITE); setPadding(20, 6, 20, 6)
            setBackgroundColor(Color.parseColor("#44000000"))
            setOnClickListener { showSettingsDialog() }
        }
        root.addView(settingsBtn, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
        ).also { it.gravity = Gravity.TOP or Gravity.START; it.topMargin = 8; it.leftMargin = 8 })

        setContentView(root)
        surfaceView.setOnTouchListener { _, ev -> onGameTouch(ev); true }
        setImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        releaseAudio()
        EmulatorEngine.nativeLinkStop()
        link.disconnect()
        EmulatorEngine.nativeDestroy()
    }

    // ── Audio ──────────────────────────────────────────────────────────────

    private fun initAudioTrack() {
        releaseAudio()
        val minBuf = AudioTrack.getMinBufferSize(
            44100,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)
        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        audioTrack?.play()
        Log.d(TAG, "AudioTrack started (minBuf=$minBuf)")
    }

    private fun releaseAudio() {
        try { audioTrack?.stop(); audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
    }

    // ── Surface ────────────────────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder)                          { surfaceHolder = holder }
    override fun surfaceDestroyed(holder: SurfaceHolder)                        { stopGameLoop(); surfaceHolder = null }
    override fun surfaceChanged(holder: SurfaceHolder, fmt: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) { updateGameMatrix(w.toFloat(), h.toFloat()); if (!running) startGameLoop() }
    }

    // ── Game loop ──────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val bmp = frameBitmap ?: return
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) { buildControlLayout(sw, sh); updateGameMatrix(sw, sh) }
        running = true
        ffFrameAccumulator = 0.0
        gameThread = Thread {
            while (running) {
                try {
                    val t0 = System.nanoTime()
                    val speed = if (fastForwardActive) fastForwardSpeed else 1f

                    val framesToRun: Int
                    if (fastForwardActive) {
                        ffFrameAccumulator += speed
                        framesToRun = ffFrameAccumulator.toInt().coerceAtLeast(1)
                        ffFrameAccumulator -= framesToRun
                    } else {
                        framesToRun = 1
                        ffFrameAccumulator = 0.0
                    }

                    EmulatorEngine.nativeSetKeys(currentKeys.get())
                    for (i in 0 until framesToRun) {
                        EmulatorEngine.nativeRunFrame(bmp)
                        val n = EmulatorEngine.nativeReadAudioSamples(audioBuffer, audioBuffer.size / 2)
                        if (n > 0 && !fastForwardActive) {
                            audioTrack?.write(audioBuffer, 0, n * 2, AudioTrack.WRITE_NON_BLOCKING)
                        }
                    }

                    renderFrame(bmp)

                    if (!fastForwardActive) {
                        val targetNs = (1_000_000_000.0 / 60.0).toLong()
                        val elapsed  = System.nanoTime() - t0
                        val sleepMs  = (targetNs - elapsed) / 1_000_000L
                        if (sleepMs > 0L) Thread.sleep(sleepMs)
                    }
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { Log.e(TAG, "Loop error", e); uiToast("Error: ${e.message}"); break }
            }
            running = false
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        gameThread?.join(500)
        gameThread = null
    }

    private fun renderFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try { holder.lockCanvas() ?: return } catch (_: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
            if (link.isConnected) drawLinkStatus(canvas)
            if (fastForwardActive) drawFfOverlay(canvas)
        } finally { try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {} }
    }

    // ── Game matrix ────────────────────────────────────────────────────────

    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp   = frameBitmap ?: return
        val gameH = if (fullscreenMode) sh else sh * gameScreenFraction
        val scale = minOf(sw / bmp.width, gameH / bmp.height)
        gameMatrix.reset()
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(
            (sw - bmp.width  * scale) / 2f,
            (gameH - bmp.height * scale) / 2f
        )
    }

    // ── Controls layout ────────────────────────────────────────────────────

    /**
     * Builds the on-screen button rects.
     * buttonScaleMultiplier (0.75 / 1.0 / 1.25) scales all button sizes.
     * gameScreenFraction controls where the controls strip begins.
     *
     * Fullscreen mode: game fills screen, controls overlay from CTRL_FRAC_FULL.
     * Normal mode    : game in top [gameScreenFraction] fraction.
     *
     * NOTE: the fullscreen ⛶ button was REMOVED from the game screen.
     * Toggle fullscreen from ⚙ Settings instead.
     */
    private fun buildControlLayout(sw: Float, sh: Float) {
        buttons.clear()
        controlsTop = sh * (if (fullscreenMode) CTRL_FRAC_FULL else gameScreenFraction)
        val padH = sh - controlsTop

        // Apply scale multiplier to all button sizes
        val s      = buttonScaleMultiplier
        val btnSz  = minOf(padH * 0.24f, sw * 0.084f) * s
        val abSz   = btnSz * 0.94f
        val step   = btnSz * 1.1f

        // ── D-pad (left side) ──────────────────────────────────────────────
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        fun pad(dx: Float, dy: Float, m: Int, l: String) = ButtonDef(
            RectF(dpCx+dx-btnSz/2, dpCy+dy-btnSz/2, dpCx+dx+btnSz/2, dpCy+dy+btnSz/2),
            m, l, Color.parseColor("#555566"))
        buttons += pad(0f,   -step, EmulatorEngine.KEY_UP,    "▲")
        buttons += pad(0f,   +step, EmulatorEngine.KEY_DOWN,  "▼")
        buttons += pad(-step, 0f,   EmulatorEngine.KEY_LEFT,  "◀")
        buttons += pad(+step, 0f,   EmulatorEngine.KEY_RIGHT, "▶")

        // ── A / B (right side) ────────────────────────────────────────────
        val abCx  = sw * 0.82f
        val abCy  = controlsTop + padH * 0.52f
        val abGap = abSz * 1.2f
        buttons += ButtonDef(RectF(abCx+abGap-abSz/2, abCy-abSz/2, abCx+abGap+abSz/2, abCy+abSz/2),
            EmulatorEngine.KEY_A, "A", Color.parseColor("#CF6679"))
        buttons += ButtonDef(RectF(abCx-abGap-abSz/2, abCy-abSz/2, abCx-abGap+abSz/2, abCy+abSz/2),
            EmulatorEngine.KEY_B, "B", Color.parseColor("#4FC3F7"))

        // ── Select / Start (centre) ───────────────────────────────────────
        val ssW  = sw * 0.11f * s;  val ssH  = sh * 0.038f * s
        val ssCy = controlsTop + padH * 0.82f
        val ssGap = sw * 0.07f
        buttons += ButtonDef(RectF(sw/2f-ssGap-ssW, ssCy, sw/2f-ssGap,    ssCy+ssH),
            EmulatorEngine.KEY_SELECT, "SEL", Color.parseColor("#444455"))
        buttons += ButtonDef(RectF(sw/2f+ssGap,     ssCy, sw/2f+ssGap+ssW, ssCy+ssH),
            EmulatorEngine.KEY_START,  "STA", Color.parseColor("#444455"))

        // ── L / R shoulder buttons ─────────────────────────────────────────
        val lrW = sw * 0.13f * s;  val lrH = sh * 0.042f * s
        val lrY = controlsTop + padH * 0.06f
        buttons += ButtonDef(RectF(sw*0.03f,        lrY, sw*0.03f+lrW,    lrY+lrH),
            EmulatorEngine.KEY_L, "L", Color.parseColor("#444455"))
        buttons += ButtonDef(RectF(sw-sw*0.03f-lrW, lrY, sw-sw*0.03f,     lrY+lrH),
            EmulatorEngine.KEY_R, "R", Color.parseColor("#444455"))

        // ── ⏩ Fast-forward (utility strip above SEL/STA) ──────────────────
        val utilH = (ssH * 0.85f).coerceAtLeast(18f)
        val utilW = sw * 0.10f
        val utilY = ssCy - utilH - sh * 0.012f
        val utilGap = sw * 0.055f
        ffBtnRect = RectF(sw/2f - utilGap - utilW, utilY, sw/2f - utilGap, utilY + utilH)
        // NOTE: fsBtnRect REMOVED — fullscreen is now in ⚙ Settings only
    }

    // ── Draw controls ──────────────────────────────────────────────────────

    private val fillPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
    }

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return

        if (!fullscreenMode) {
            fillPaint.color = Color.parseColor("#CC111122")
            canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), fillPaint)
        }

        val keys       = currentKeys.get()
        // Idle alpha scales with user preference; press brightens by +80
        val idleAlpha  = if (fullscreenMode) (buttonBaseAlpha * 0.70f).toInt() else buttonBaseAlpha
        val pressAlpha = (buttonBaseAlpha + 80).coerceAtMost(255)

        for (btn in buttons) {
            fillPaint.color = btn.color
            fillPaint.alpha = if (keys and btn.keyMask != 0) pressAlpha else idleAlpha
            canvas.drawRoundRect(btn.rect, 12f, 12f, fillPaint)
            labelPaint.textSize = (btn.rect.height() * 0.46f).coerceAtLeast(14f)
            canvas.drawText(
                btn.label,
                btn.rect.centerX(),
                btn.rect.centerY() + labelPaint.textSize * 0.36f,
                labelPaint
            )
        }

        // ── ⏩ Fast-forward button ────────────────────────────────────────
        fillPaint.color = if (fastForwardActive) Color.parseColor("#CC7700")
                          else Color.parseColor("#333344")
        fillPaint.alpha = idleAlpha + 20
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
        labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
        val ffLabel = if (fastForwardActive) "⏩${formatSpeed(fastForwardSpeed)}×" else "⏩"
        canvas.drawText(ffLabel,
            ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
        // NOTE: ⛶ fullscreen button no longer drawn here — it lives in ⚙ Settings
    }

    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFCC00"); textSize = 28f; isFakeBoldText = true
    }
    private fun drawFfOverlay(canvas: Canvas) =
        canvas.drawText("⏩ ${formatSpeed(fastForwardSpeed)}×", 14f, 36f, hudPaint)

    private fun formatSpeed(s: Float): String =
        if (s == s.toLong().toFloat()) s.toLong().toString() else "%.1f".format(s)

    // ── Touch handling ─────────────────────────────────────────────────────

    private fun onGameTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x; val y = event.y
                // ⏩ — tap toggles fast-forward
                if (ffBtnRect.contains(x, y)) { fastForwardActive = !fastForwardActive; return }
                // NOTE: fullscreen ⛶ touch removed — use ⚙ Settings to toggle fullscreen
                updateGameKeys(event)
            }
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> updateGameKeys(event)
            MotionEvent.ACTION_UP -> {
                if (ffBtnRect.contains(event.x, event.y)) return
                currentKeys.set(0)
            }
            MotionEvent.ACTION_POINTER_UP -> updateGameKeys(event)
            else                          -> currentKeys.set(0)
        }
    }

    private fun updateGameKeys(event: MotionEvent) {
        var keys = 0
        for (i in 0 until event.pointerCount) {
            val x = event.getX(i); val y = event.getY(i)
            for (btn in buttons) if (btn.rect.contains(x, y)) keys = keys or btn.keyMask
        }
        currentKeys.set(keys)
    }

    // ── Settings dialog ────────────────────────────────────────────────────

    /**
     * ⚙ Settings — comprehensive options panel.
     *
     * Sections:
     *   GAME SCREEN — fraction of screen height the game occupies + fullscreen toggle
     *   CONTROLS    — button size multiplier and opacity
     *   EMULATION   — fast-forward speed
     *
     * Fullscreen mode is intentionally ONLY accessible here (no on-screen button)
     * to keep the game screen clean.
     */
    private fun showSettingsDialog() {
        val ctx  = this
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        // ── Root layout (ScrollView → LinearLayout) ──────────────────────
        val layout = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 28, 56, 20)
        }

        fun sectionLabel(text: String) = TextView(ctx).apply {
            this.text = text; textSize = 10f
            setTextColor(Color.parseColor("#AAAAAA"))
            setPadding(0, 24, 0, 6)
        }
        fun makeRadioGroup(horizontal: Boolean = true) = RadioGroup(ctx).apply {
            if (horizontal) orientation = LinearLayout.HORIZONTAL
        }
        fun RadioGroup.addOpt(label: String): RadioButton = RadioButton(ctx).apply {
            text = label
            id   = View.generateViewId()
            setTextColor(Color.WHITE)
            textSize = 13f
        }.also { addView(it) }

        // ── GAME SCREEN ──────────────────────────────────────────────────
        layout.addView(sectionLabel("── GAME SCREEN ──"))

        val screenOptions = listOf(
            "35%"        to 0.35f,
            "44%"        to 0.44f,
            "52% (def)"  to 0.52f,
            "65%"        to 0.65f
        )
        val screenRadio = makeRadioGroup()
        screenOptions.forEach { (label, _) -> screenRadio.addOpt(label) }
        val curScreenIdx = screenOptions.indexOfFirst { abs(it.second - gameScreenFraction) < 0.02f }
            .takeIf { it >= 0 } ?: 2
        (screenRadio.getChildAt(curScreenIdx) as RadioButton).isChecked = true
        layout.addView(screenRadio)

        // Fullscreen toggle — now ONLY here, not on the game screen
        val fsCheck = CheckBox(ctx).apply {
            text    = "Fullscreen — game covers control area"
            isChecked = fullscreenMode
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(0, 8, 0, 0)
        }
        layout.addView(fsCheck)
        layout.addView(TextView(ctx).apply {
            text = "  (controls become a transparent overlay)"
            textSize = 10f
            setTextColor(Color.parseColor("#888888"))
        })

        // ── CONTROLS ─────────────────────────────────────────────────────
        layout.addView(sectionLabel("── CONTROLS ──"))

        layout.addView(TextView(ctx).apply {
            text = "Button size"; textSize = 12f; setTextColor(Color.WHITE)
        })
        val sizeOptions = listOf("Small" to 0.75f, "Normal" to 1.0f, "Large" to 1.25f)
        val sizeRadio   = makeRadioGroup()
        sizeOptions.forEach { (label, _) -> sizeRadio.addOpt(label) }
        val curSizeIdx = sizeOptions.indexOfFirst { abs(it.second - buttonScaleMultiplier) < 0.05f }
            .takeIf { it >= 0 } ?: 1
        (sizeRadio.getChildAt(curSizeIdx) as RadioButton).isChecked = true
        layout.addView(sizeRadio)

        layout.addView(TextView(ctx).apply {
            text = "Button opacity"; textSize = 12f; setTextColor(Color.WHITE)
            setPadding(0, 10, 0, 0)
        })
        val alphaOptions = listOf("Low" to 90, "Normal" to 160, "High" to 220)
        val alphaRadio   = makeRadioGroup()
        alphaOptions.forEach { (label, _) -> alphaRadio.addOpt(label) }
        val curAlphaIdx = alphaOptions.indexOfFirst { abs(it.second - buttonBaseAlpha) < 40 }
            .takeIf { it >= 0 } ?: 1
        (alphaRadio.getChildAt(curAlphaIdx) as RadioButton).isChecked = true
        layout.addView(alphaRadio)

        // ── EMULATION ────────────────────────────────────────────────────
        layout.addView(sectionLabel("── EMULATION ──"))
        layout.addView(TextView(ctx).apply {
            text = "Fast-forward speed (0.5 – 16×)\nTap ⏩ on screen to activate"
            textSize = 12f; setTextColor(Color.WHITE)
        })
        val ffEdit = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(formatSpeed(fastForwardSpeed))
            hint = "e.g. 2, 4, 4.5"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(8, 8, 8, 8)
        }
        layout.addView(ffEdit)

        // ── Hint about fullscreen ─────────────────────────────────────────
        layout.addView(TextView(ctx).apply {
            text = "\nTip: tap ⚙ during gameplay to toggle fullscreen or adjust size."
            textSize = 10f; setTextColor(Color.parseColor("#666688"))
        })

        // ── Dialog ───────────────────────────────────────────────────────
        AlertDialog.Builder(ctx)
            .setTitle("⚙ Settings")
            .setView(ScrollView(ctx).also { it.addView(layout) })
            .setPositiveButton("Save") { _, _ ->

                // Read screen fraction
                val selScreenIdx = (0 until screenRadio.childCount)
                    .firstOrNull { (screenRadio.getChildAt(it) as RadioButton).isChecked } ?: curScreenIdx
                val newFrac = screenOptions[selScreenIdx].second

                // Read button size
                val selSizeIdx = (0 until sizeRadio.childCount)
                    .firstOrNull { (sizeRadio.getChildAt(it) as RadioButton).isChecked } ?: curSizeIdx
                val newScale = sizeOptions[selSizeIdx].second

                // Read button alpha
                val selAlphaIdx = (0 until alphaRadio.childCount)
                    .firstOrNull { (alphaRadio.getChildAt(it) as RadioButton).isChecked } ?: curAlphaIdx
                val newAlpha = alphaOptions[selAlphaIdx].second

                // Read FF speed
                val ffVal = ffEdit.text.toString().toFloatOrNull()
                if (ffVal != null) {
                    when {
                        ffVal < 0.5f || ffVal > 16f -> uiToast("Speed must be 0.5 – 16")
                        else -> fastForwardSpeed = ffVal
                    }
                }

                // Apply and persist
                val needsRelayout = abs(newFrac - gameScreenFraction) > 0.01f
                    || newScale != buttonScaleMultiplier
                    || fsCheck.isChecked != fullscreenMode

                buttonScaleMultiplier = newScale
                buttonBaseAlpha       = newAlpha
                gameScreenFraction    = newFrac
                fullscreenMode        = fsCheck.isChecked

                prefs.edit()
                    .putFloat(PREF_FF_SPEED,    fastForwardSpeed)
                    .putFloat(PREF_BTN_SCALE,   newScale)
                    .putInt(PREF_BTN_ALPHA,      newAlpha)
                    .putFloat(PREF_SCREEN_FRAC,  newFrac)
                    .putBoolean(PREF_FULLSCREEN,  fullscreenMode)
                    .apply()

                if (needsRelayout) applyLayoutSettings()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * Rebuild control layout and game matrix after settings change.
     * Called on main thread; game thread picks up changes on next frame.
     */
    private fun applyLayoutSettings() {
        val holder = surfaceHolder ?: return
        val sw = holder.surfaceFrame.width().toFloat()
        val sh = holder.surfaceFrame.height().toFloat()
        if (sw > 0f && sh > 0f) {
            buildControlLayout(sw, sh)
            if (romLoaded) updateGameMatrix(sw, sh)
        }
    }

    // ── Link cable UI ──────────────────────────────────────────────────────

    private fun showLinkDialog() {
        if (link.isConnected) {
            AlertDialog.Builder(this).setTitle("Link Connected ✓")
                .setItems(arrayOf("Disconnect")) { _, _ -> stopLink() }.show()
            return
        }
        AlertDialog.Builder(this).setTitle("GBA Link Cable")
            .setItems(arrayOf("Host — Wi-Fi", "Join — Wi-Fi",
                               "Host — Bluetooth", "Join — Bluetooth")) { _, i ->
                when (i) {
                    0 -> link.startWifiHost(
                        onReady     = { ip -> uiToast("Waiting…\nIP: $ip"); updateLinkBtn("⏳ Hosting…") },
                        onConnected = { onLinkConnected(true,  "Wi-Fi") },
                        onError     = { uiToast("Host error: $it"); updateLinkBtn("🔗 Link") })
                    1 -> { updateLinkBtn("🔗 Scanning…")
                           link.discoverWifiHosts(
                               onFound = { hosts ->
                                   if (hosts.isEmpty()) showIpDialog()
                                   else AlertDialog.Builder(this)
                                       .setTitle("Select host")
                                       .setItems(hosts.toTypedArray()) { _, j -> joinWifi(hosts[j]) }
                                       .setNegativeButton("Enter IP") { _, _ -> showIpDialog() }.show() },
                               onError = { showIpDialog() }) }
                    2 -> { updateLinkBtn("⏳ BT Host…")
                           link.startBluetoothHost(
                               onConnected = { onLinkConnected(true,  "Bluetooth") },
                               onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") }) }
                    3 -> { val devs = link.getBondedDevices()
                           if (devs.isEmpty()) { uiToast("No paired devices"); return@setItems }
                           AlertDialog.Builder(this).setTitle("Choose device")
                               .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, j ->
                                   updateLinkBtn("⏳ BT…")
                                   link.connectBluetooth(devs[j],
                                       onConnected = { onLinkConnected(false, "Bluetooth") },
                                       onError     = { uiToast("BT error: $it"); updateLinkBtn("🔗 Link") })
                               }.show() }
                }
            }.show()
    }

    private fun showIpDialog() {
        val et = EditText(this).apply { hint = "192.168.x.x" }
        AlertDialog.Builder(this).setTitle("Host IP").setView(et)
            .setPositiveButton("Connect") { _, _ -> joinWifi(et.text.toString().trim()) }.show()
    }

    private fun joinWifi(ip: String) {
        if (ip.isBlank()) return
        updateLinkBtn("⏳ Connecting…")
        link.connectWifi(ip,
            onConnected = { onLinkConnected(false, "Wi-Fi") },
            onError     = { uiToast("Connect error: $it"); updateLinkBtn("🔗 Link") })
    }

    private fun onLinkConnected(isHost: Boolean, via: String) {
        val ok = EmulatorEngine.nativeLinkStart(link, isHost)
        updateLinkBtn("🔗 $via ✓")
        uiToast("Link via $via${if (!ok) " (SIO error)" else ""}")
    }

    private fun stopLink() {
        EmulatorEngine.nativeLinkStop(); link.disconnect()
        updateLinkBtn("🔗 Link"); uiToast("Disconnected")
    }

    private fun updateLinkBtn(t: String) =
        Handler(Looper.getMainLooper()).post { linkBtn.text = t }

    // ── Link status overlay ────────────────────────────────────────────────

    private val linkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC22BB77"); textSize = 26f
    }
    private fun drawLinkStatus(canvas: Canvas) =
        canvas.drawText("⬤ LINK", 14f, canvas.height - 14f, linkPaint)

    // ── Helpers ────────────────────────────────────────────────────────────

    private fun uiToast(msg: String) =
        Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Suppress("DEPRECATION")
    private fun setImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }
}
