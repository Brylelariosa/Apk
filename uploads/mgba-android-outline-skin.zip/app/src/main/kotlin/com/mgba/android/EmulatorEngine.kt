package com.mgba.android

import android.graphics.Bitmap

/**
 * Thin Kotlin wrapper around the mGBA JNI layer.
 *
 * Key bitmask values match enum GBAKey in mgba/internal/gba/input.h:
 *   A=0, B=1, SELECT=2, START=3, RIGHT=4, LEFT=5, UP=6, DOWN=7, R=8, L=9
 */
object EmulatorEngine {

    // ── GBA key bitmasks ──────────────────────────────────────────────────────
    const val KEY_A      = 1 shl 0   // 0x001
    const val KEY_B      = 1 shl 1   // 0x002
    const val KEY_SELECT = 1 shl 2   // 0x004
    const val KEY_START  = 1 shl 3   // 0x008
    const val KEY_RIGHT  = 1 shl 4   // 0x010
    const val KEY_LEFT   = 1 shl 5   // 0x020
    const val KEY_UP     = 1 shl 6   // 0x040
    const val KEY_DOWN   = 1 shl 7   // 0x080
    const val KEY_R      = 1 shl 8   // 0x100
    const val KEY_L      = 1 shl 9   // 0x200

    init {
        System.loadLibrary("mgba-jni")
    }

    /**
     * Auto-detects ROM type (GBA / GB / GBC), initialises the core,
     * and loads the file at [path].
     * @return true on success
     */
    external fun nativeLoadROM(path: String): Boolean

    /**
     * Runs exactly one emulated frame.
     * If [bitmap] is non-null, writes the result into it (must be
     * ARGB_8888, width = nativeGetWidth(), height = nativeGetHeight()).
     * If [bitmap] is null, the frame still fully emulates (and its audio is
     * still readable via [nativeReadAudioSamples]) but the pixel copy is
     * skipped — use this for fast-forward sub-frames that get overwritten
     * before they're ever displayed, so their pixels are never copied.
     */
    external fun nativeRunFrame(bitmap: Bitmap?)

    /**
     * Updates the current key state.  [keys] is a bitmask of KEY_* constants.
     * All bits not set are treated as released.
     */
    external fun nativeSetKeys(keys: Int)

    /** Returns the emulated screen width in pixels (GBA = 240). */
    external fun nativeGetWidth(): Int

    /** Returns the emulated screen height in pixels (GBA = 160). */
    external fun nativeGetHeight(): Int

    /** Frees the native core and framebuffer.  Call from onDestroy. */
    external fun nativeDestroy()

    /**
     * Drains the mGBA blip audio buffers into [buf] as interleaved stereo PCM.
     * [buf] must have at least [maxSamples] * 2 elements (L+R pairs).
     * @return number of stereo pairs written (0 if no samples available).
     * Call this immediately after nativeRunFrame() on the game thread.
     */
    external fun nativeReadAudioSamples(buf: ShortArray, maxSamples: Int): Int

    // ── Link cable multiplayer ─────────────────────────────────────────────
    external fun nativeLinkStart(link: LinkMultiplayer, isHost: Boolean): Boolean
    external fun nativeLinkStop()
}
