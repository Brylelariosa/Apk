package com.mangareader.parser

import android.content.Context
import android.net.Uri
import android.util.Base64
import java.io.File
import java.io.InputStream

/**
 * Parses MHTML files and extracts embedded images to a cache directory.
 *
 * MHTML stores images as base64-encoded MIME parts separated by a boundary string.
 * We read the file with ISO-8859-1 so byte values are preserved in the char range,
 * split on the boundary, then decode each image part's base64 body.
 */
class MhtmlParser(private val context: Context) {

    fun extractImages(mhtmlPath: String, cacheDir: File): List<File> {
        return try {
            val stream: InputStream = if (mhtmlPath.startsWith("content://")) {
                context.contentResolver.openInputStream(Uri.parse(mhtmlPath))
                    ?: return emptyList()
            } else {
                File(mhtmlPath).inputStream()
            }
            extractImages(stream, cacheDir)
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun extractImages(inputStream: InputStream, cacheDir: File): List<File> {
        cacheDir.mkdirs()
        val images = mutableListOf<File>()
        var imageIndex = 0

        try {
            // ISO-8859-1 preserves raw bytes 1-to-1 as chars — safe for base64 content
            val content = inputStream.use { it.bufferedReader(Charsets.ISO_8859_1).readText() }

            // Locate MIME boundary
            val boundaryMatch = Regex(
                """boundary=["']?([^"'\r\n;]+)["']?""",
                RegexOption.IGNORE_CASE
            ).find(content) ?: return emptyList()
            val boundary = boundaryMatch.groupValues[1].trim()
            val delimiter = "--$boundary"

            val parts = content.split(delimiter)
            // parts[0] = global headers preamble, skip it
            // parts[last] starts with "--" (end boundary marker), skip it

            for (part in parts.drop(1)) {
                val trimmed = part.trimStart('\r', '\n')
                if (trimmed.startsWith("--")) continue   // closing "--" marker

                // Only handle base64-encoded image parts
                if (!part.contains("Content-Type: image/", ignoreCase = true)) continue
                if (!part.contains("base64", ignoreCase = true)) continue

                // Split headers from body at the first blank line
                val sepIdx = part.indexOf("\r\n\r\n").takeIf { it >= 0 }
                    ?: part.indexOf("\n\n").takeIf { it >= 0 }
                    ?: continue

                val headers = part.substring(0, sepIdx)
                val rawBody = part.substring(sepIdx).trim()

                val ext = when {
                    headers.contains("image/png",  ignoreCase = true) -> "png"
                    headers.contains("image/webp", ignoreCase = true) -> "webp"
                    headers.contains("image/gif",  ignoreCase = true) -> "gif"
                    else -> "jpg"
                }

                // Strip all line endings from base64 text before decoding
                val b64 = rawBody
                    .replace("\r\n", "")
                    .replace("\r",   "")
                    .replace("\n",   "")
                    .trim()

                if (b64.length < 10) continue

                try {
                    val bytes = Base64.decode(b64, Base64.DEFAULT)
                    if (bytes.size > 200) {   // skip corrupt/tiny fragments
                        val out = File(cacheDir, "page_${imageIndex.toString().padStart(4, '0')}.$ext")
                        out.writeBytes(bytes)
                        images.add(out)
                        imageIndex++
                    }
                } catch (_: Exception) { /* skip malformed base64 */ }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return images.sortedBy { it.name }
    }
}
