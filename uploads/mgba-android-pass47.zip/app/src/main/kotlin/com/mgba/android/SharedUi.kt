package com.mgba.android

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

// Split out of MainActivity (Thirty-second pass) when the ROM browser
// became its own Activity (see RomBrowserActivity.kt) and needed the same
// small set of UI helpers MainActivity already had as private methods.
// Extension functions on Context/Activity rather than a shared base class —
// avoids touching MainActivity's class hierarchy at all for what's a small,
// stateless, purely-cosmetic set of helpers; every existing unqualified
// call site (dp(20), uiToast("..."), etc.) keeps compiling unchanged since
// these live in the same package.

/** SharedPreferences file name both Activities read/write. */
internal const val PREFS = "mgba_prefs"

internal val colorAccentLight = Color.parseColor("#D8D8DE")

/** Floppy disk glyph — rounded-square body + a smaller notch in the
 *  top-right corner — the universal "save"/"storage" silhouette. Shared
 *  by MainActivityControlLayout.kt's drawActionButtonIcon() (the
 *  quicksave controller button) and SettingsIcons.kt's STORAGE glyph, so
 *  the one shape only has to be drawn correctly in one place. [cx]/[cy]
 *  are the icon's center, [s] its half-extent, both in the caller's own
 *  coordinate space (a live game Canvas for the former, a small View's
 *  onDraw for the latter) — everything below is expressed relative to
 *  those, so it drops in at any size or position.
 *
 *  FIX (direct report: "quicksave... button is weird there like a white
 *  highlight like duplicate light that's why it got lighter"): the
 *  notch used to be stroked as a full rect sharing its top and right
 *  edges with the body's own top/right edges. Wherever those edges
 *  coincide, both shapes' strokes landed on the same pixels — and since
 *  [paint] is typically semi-transparent, that double compositing made
 *  the shared corner visibly brighter than the rest of the outline. The
 *  body's straight edges run from corner..2s-corner (the arc takes the
 *  rest), so only the notch's two fully-interior edges plus the sliver
 *  of top/right edge that falls past the body's rounded corner need
 *  their own stroke; everywhere else the body already drew that pixel
 *  once. */
internal fun drawFloppyDiskIcon(canvas: Canvas, paint: Paint, cx: Float, cy: Float, s: Float) {
    canvas.drawRoundRect(cx - s, cy - s, cx + s, cy + s, s * 0.28f, s * 0.28f, paint)
    val corner = s * 0.72f
    canvas.drawLine(cx + s * 0.05f, cy - s, cx + s * 0.05f, cy - s * 0.30f, paint)
    canvas.drawLine(cx + s * 0.05f, cy - s * 0.30f, cx + s, cy - s * 0.30f, paint)
    canvas.drawLine(cx + corner, cy - s, cx + s, cy - s, paint)
    canvas.drawLine(cx + s, cy - s, cx + s, cy - corner, paint)
}

// FEATURE (this pass — direct report: "make the pop up smaller"): sliderRow()
// builds two rows inside MainActivity's per-item editor bar (Control
// Size, Control Opacity), so these each apply in two places at once —
// named here for the same "one shared number, not two literals that
// could drift apart" reason as MainActivity's own EDIT_TOOLBAR_* constants.
// HEIGHT is still a real tap target: a SeekBar's own touch area is
// generously padded well past its visible track (see sliderRow()'s own
// doc comment), so this box only ever needs to be *comfortably* tappable
// as a secondary/backup input next to it, not meet the same bar a
// primary control would.
internal const val EDIT_TOOLBAR_VALUE_BOX_WIDTH_DP = 48   // was 56 — still fits the "800%" ceiling
internal const val EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP = 32  // was 36

internal fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Resolves the theme's default ripple/selectable-item-background resource
 *  id — the exact same three lines (`TypedValue()` +
 *  `theme.resolveAttribute(android.R.attr.selectableItemBackground, ...)` +
 *  `.resourceId`) that used to be duplicated verbatim at every row-building
 *  call site across this app (RomBrowserActivity's row(), MainActivity's
 *  settingsRow()/videoListRow()/gameMenuRow()/stateSlotRow()). One shared
 *  definition here means a future change to how the ripple is resolved only
 *  has to happen once. Callers on a hot path (a row built once per item in
 *  a potentially-large list, like RomBrowserActivity's row()) should still
 *  cache the *result* themselves (e.g. a `by lazy` field) rather than
 *  calling this fresh per row — this function only removes the duplication,
 *  not the per-call cost of resolveAttribute() itself. */
internal fun Context.rippleBackgroundResId(): Int {
    val tv = TypedValue()
    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
    return tv.resourceId
}

/** True if this app currently holds broad, direct filesystem access to
 *  shared storage — MANAGE_EXTERNAL_STORAGE ("All files access") on API 30+,
 *  plain READ_EXTERNAL_STORAGE below that. This is the exact permission
 *  RomBrowserActivity's free-roam file manager needs to browse anywhere
 *  (see its own ensureBroadFileAccess()), and the one a plain java.io.File
 *  write to a *root*-level folder (sibling to /Android, not inside it)
 *  needs too — shared here so every caller checks the identical condition
 *  instead of two independently-maintained copies of the same version
 *  check quietly drifting apart. Read-only: this never requests anything,
 *  it only reports the current state — see RomBrowserActivity's own
 *  ensureBroadFileAccess() for the request flow, which still needs its own
 *  ActivityResultLauncher plumbing per-Activity since that part can't be
 *  shared the same way a stateless check can. */
internal fun Context.hasBroadFileAccess(): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED
    }

/** Transparent, outlined "chip" background for corner icon buttons. */
internal fun Context.iconChipBackground(): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.RECTANGLE
    cornerRadius = dp(10).toFloat()
    setColor(Color.parseColor("#33000000"))
    setStroke(dp(1).coerceAtLeast(2), colorAccentLight)
}

/** Filled rounded-rect background every AlertDialog in the app uses via
 *  dialog.window?.setBackgroundDrawable(...). Moved here from MainActivity,
 *  alongside sliderRow() below, which needs it too — same "small,
 *  stateless, purely-cosmetic" rationale as every other helper in this
 *  file. Every existing MainActivity call site (unqualified
 *  roundedDialogBackground()) keeps compiling unchanged, exactly the same
 *  "same-package extension function" reasoning as the rest of this file's
 *  own top comment. */
internal fun Context.roundedDialogBackground(): GradientDrawable = GradientDrawable().apply {
    cornerRadius = dp(14).toFloat()
    setColor(Color.parseColor("#FF2E2E33"))
}

/** Rounded-rect background for the per-item editor toolbar (editButtonBar
 *  in MainActivity) — previously a flat setBackgroundColor(), square
 *  corners on every side. Direct report: "make pop up circle edge". Same
 *  fill color as before and the same dp(14) radius roundedDialogBackground()
 *  just above already uses, so every popup/overlay in the app now shares
 *  one consistent "rounded panel" look rather than editButtonBar being the
 *  one flat-cornered exception. */
internal fun Context.editToolbarBackground(): GradientDrawable = GradientDrawable().apply {
    // 14dp → 12dp (this pass, alongside the bar's own smaller padding) so
    // the corner radius stays proportional on a now-more-compact panel.
    cornerRadius = dp(12).toFloat()
    setColor(Color.parseColor("#EE22222E"))
}

/** The standard vertical content container used inside every settings-style
 *  AlertDialog in this app (Grid Settings, Misc, Storage, Advanced, About,
 *  ...) — each wraps this in a ScrollView and adds its own rows/fields.
 *  FIX: every one of those ~7 call sites had its own copy of
 *  `LinearLayout(ctx).apply { orientation = VERTICAL; setPadding(56, 28,
 *  56, 20) }` — raw pixels, never wrapped in dp(), the exact "forgot this
 *  one spot" gap this app's own comments already call out for several
 *  other paddings/margins (e.g. the per-item editor bar's own
 *  EDIT_TOOLBAR_GAP_DP fix). On a high-density phone that's a noticeably
 *  more cramped dialog than the round 56/28/56/20 *dp* numbers this was
 *  almost certainly meant as — same numbers, now actually density-aware,
 *  centralized so a future adjustment (or another fix like this one) only
 *  has to happen at this one definition instead of by-hand at every
 *  dialog that builds its own copy. */
internal fun Context.dialogContentLayout(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(56), dp(28), dp(56), dp(20))
}

internal fun Activity.uiToast(msg: String) =
    Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

/**
 * A drag-or-type-exact-number row: a SeekBar plus a value readout that
 * doubles as a tap-to-type field. Built once per row (Control Size,
 * Control Opacity in MainActivity's per-item editor bar) and refreshed via
 * [SliderRow.setValue]/[SliderRow.setEnabled] whenever what it's editing
 * changes — a different control gets selected, Reset is tapped, lock is
 * toggled — without re-invoking [onChange], the same "built once, refreshed
 * on selection" shape the rest of that editor bar already uses.
 *
 * FIX (an earlier pass): replaces a pair of "-"/"+" chips whose real touch
 * target — even after a previous pass's 48dp-minimum fix — was still just
 * a few glyph-sized pixels. Direct report: "the plus and minus maybe a
 * slider with number or percent and you can type the number". A SeekBar's
 * entire width is draggable, not just one small fixed target, and the
 * value readout next to it both shows the live number and, tapped, opens
 * an exact-entry field.
 *
 * FIX (this pass — direct reports: "if you click the number where you
 * type it should type on the box doesn't pop up another typing area", that
 * popup's own number box being "big", and "the slider and box is not
 * aligned"): the separate typed-entry AlertDialog this used to open
 * (showTypeValueDialog) is gone entirely. Tapping the readout now turns
 * that exact same box into an editable field in place — see
 * [beginInlineEdit]/[commitInlineEdit] below and the FrameLayout in
 * [sliderRow] that overlays valueText/valueEdit in one shared slot — so
 * there is no second popup anywhere on screen, and nothing to visually
 * mis-size relative to it. The readout's own minimum height also comes
 * down from 48dp to 36dp as part of the same report: still a real touch
 * target (a SeekBar's own touch target is generously padded well past its
 * visible track/thumb, so 36dp next to it reads as comfortably tappable,
 * not cramped) but no longer tall enough to visually spill into the row
 * above/below it inside a tightly packed editor panel — see
 * editButtonBar's own row-spacing fix in MainActivity for the rest of that
 * "not aligned" report.
 *
 * FIX (this pass — direct report: "make the pop up smaller"): that 36dp
 * floor comes down again, to EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP (32dp) — see
 * that constant's own comment just above this class for why it's still a
 * reasonable secondary touch target next to the SeekBar's own generously-
 * padded drag area.
 *
 * [min]/[max] are inclusive, in whatever unit [format] displays (a percent
 * in every current caller). SeekBar's own `progress` is always kept
 * 0-based internally regardless of [min] — `SeekBar.setMin()` needs API 26
 * and this app's minSdk is 24 — so every value this class exposes
 * ([initial], [onChange], [SliderRow.setValue], the typed field) is
 * already in real [min]..[max] units; only the SeekBar's own internal
 * progress carries the min-offset, invisibly to every caller.
 */
internal class SliderRow(
    val root: View,
    private val seek: SeekBar,
    private val valueText: TextView,
    private val valueEdit: EditText,
    private val min: Int,
    private val max: Int,
    private val format: (Int) -> String,
    private val onChange: (Int) -> Unit
) {
    /** Updates the displayed value/position without invoking this row's
     *  own [onChange] — for reflecting a value that changed some other way
     *  (a newly-selected control's own current size/opacity, a Reset), not
     *  a fresh user edit. */
    fun setValue(v: Int) {
        seek.progress = (v - min).coerceIn(0, seek.max)
        valueText.text = format(v)
    }

    /** Disables (and visibly dims) the slider and the tap-to-type readout —
     *  for a locked control, matching the "Unlock this control first" guard
     *  the setter functions in MainActivity already enforce.
     *  `SeekBar.isEnabled = false` already blocks drag input at the
     *  platform level (`AbsSeekBar.onTouchEvent`'s own first check);
     *  `valueText.isEnabled = false` equally blocks its tap-to-edit
     *  listener from firing, the same mechanism. The readout's alpha is
     *  set explicitly since a plain TextView with a flat
     *  `setTextColor()`/GradientDrawable background — not a
     *  state-list-aware style — doesn't otherwise dim itself on disable. */
    fun setEnabled(enabled: Boolean) {
        seek.isEnabled = enabled
        valueText.isEnabled = enabled
        valueText.alpha = if (enabled) 1f else 0.5f
    }

    /** Swaps the readout for the inline EditText occupying the same slot,
     *  pre-filled with the current raw number (no "%"/unit suffix — just
     *  what someone would want to retype), selection parked at the end,
     *  keyboard requested immediately. See [sliderRow] for where this is
     *  wired to valueText's own click. */
    internal fun beginInlineEdit() {
        if (!valueText.isEnabled) return
        valueEdit.setText((seek.progress + min).toString())
        valueEdit.setSelection(valueEdit.text.length)
        valueText.visibility = View.GONE
        valueEdit.visibility = View.VISIBLE
        valueEdit.requestFocus()
        (valueEdit.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.showSoftInput(valueEdit, InputMethodManager.SHOW_IMPLICIT)
    }

    /** Reverses [beginInlineEdit]: a valid [min]..[max] number applies
     *  through the exact same [setValue] + [onChange] path a drag would
     *  use; anything else (empty, non-numeric, out of range) is silently
     *  left as it was — no toast, unlike the old dialog's rejection
     *  message, since a mis-tap-away from an inline field someone can just
     *  tap straight back into shouldn't interrupt them the way dismissing
     *  a whole popup with bad input once did. Guarded to a no-op when
     *  already showing valueText so it's safe to call from both the IME
     *  "Done" action and a plain focus-loss (e.g. tapping straight into a
     *  different row) without double-handling either path. */
    internal fun commitInlineEdit() {
        if (valueEdit.visibility != View.VISIBLE) return
        valueEdit.text.toString().toIntOrNull()?.let { typed ->
            if (typed in min..max) { setValue(typed); onChange(typed) }
        }
        valueEdit.visibility = View.GONE
        valueText.visibility = View.VISIBLE
        (valueEdit.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(valueEdit.windowToken, 0)
    }
}

internal fun Activity.sliderRow(
    min: Int,
    max: Int,
    initial: Int,
    label: () -> String,
    format: (Int) -> String = { "$it%" },
    onChange: (Int) -> Unit
): SliderRow {
    val ctx = this
    // Deliberately not set inside a SeekBar.apply{} block: SeekBar has its
    // own `max` property, which would shadow this function's own `max`
    // parameter for any *unqualified* reference on the right-hand side of
    // an assignment inside such a block (Kotlin resolves an implicit-
    // receiver member before an enclosing function's parameter of the same
    // name) — exactly the kind of thing that would silently compile and
    // just be wrong. Two statements, no shared receiver scope, no
    // ambiguity either way.
    val seek = SeekBar(ctx)
    seek.max = (max - min).coerceAtLeast(1)
    // FIX (this pass — direct report: "make the pop up smaller"): 13→12sp,
    // tighter padding, and the 36dp floor from the earlier pass's comment
    // above comes down to EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP (32dp) — see
    // that constant's own comment for why this still reads as tappable.
    val valueText = TextView(ctx).apply {
        textSize = 12f
        setTextColor(colorAccentLight)
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(3), dp(8), dp(3))
        minHeight = dp(EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP); minimumHeight = dp(EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP)
        isClickable = true; isFocusable = true
        background = iconChipBackground()
    }
    // Same visible size/position as valueText (down to the identical
    // background/padding/text size) so swapping one for the other reads as
    // "this box is now editable", not as a different element appearing.
    // IME_FLAG_NO_FULLSCREEN matters specifically here: this editor lives
    // over the game screen in landscape play, where a fullscreen IME (the
    // default a lot of keyboards fall back to for a short landscape input)
    // would otherwise cover the whole thing just to type 2-3 digits.
    val valueEdit = EditText(ctx).apply {
        textSize = 12f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(8), 0, dp(8), 0)
        minHeight = dp(EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP); minimumHeight = dp(EDIT_TOOLBAR_VALUE_BOX_HEIGHT_DP)
        background = iconChipBackground()
        inputType = InputType.TYPE_CLASS_NUMBER
        imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_FULLSCREEN
        setSingleLine(true)
        visibility = View.GONE
        contentDescription = label()
    }
    // FIX (this pass — direct report: "the slider and box is not
    // aligned"): valueText/valueEdit used to be sized by minWidth alone —
    // a floor, not a fixed width, so the box (and the slider next to it,
    // which shares this row's remaining space) quietly shifted left/right
    // by a few px depending on how wide the current number happened to
    // render ("62%" vs "100%" vs the 3-digit ceiling "800%"). A fixed
    // width instead of a minimum means that slot never moves regardless of
    // its content, and — together with editRowLabel()'s own fixed width in
    // MainActivity — both this row and its neighbor line up as one steady
    // two-column grid instead of drifting independently.
    val valueBoxWidth = dp(EDIT_TOOLBAR_VALUE_BOX_WIDTH_DP)
    val valueSlot = FrameLayout(ctx).apply {
        addView(valueText, FrameLayout.LayoutParams(valueBoxWidth, FrameLayout.LayoutParams.WRAP_CONTENT))
        addView(valueEdit, FrameLayout.LayoutParams(valueBoxWidth, FrameLayout.LayoutParams.WRAP_CONTENT))
    }
    val row = SliderRow(
        root = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(seek, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(valueSlot)
        },
        seek = seek, valueText = valueText, valueEdit = valueEdit,
        min = min, max = max, format = format, onChange = onChange
    )
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
            val v = progress + min
            valueText.text = format(v)
            if (fromUser) onChange(v)
        }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    })
    valueText.setOnClickListener { row.beginInlineEdit() }
    valueEdit.setOnEditorActionListener { _, actionId, event ->
        val isEnterKeyDown = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
        if (actionId == EditorInfo.IME_ACTION_DONE || isEnterKeyDown) {
            row.commitInlineEdit()
            true
        } else false
    }
    valueEdit.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) row.commitInlineEdit() }
    row.setValue(initial)
    return row
}
