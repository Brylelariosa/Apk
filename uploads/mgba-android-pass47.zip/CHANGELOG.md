# CHANGELOG — Forty-seventh pass

Five bugs reported directly against the Forty-sixth pass's build, all
fixed this pass — see BUGS_FIXED.md for each one's full root-cause
writeup and FILE_CHANGES.md for the file-by-file detail. No new
features; every item below is a fix to something the Forty-sixth pass
(or earlier) already shipped:

1. **ROM browser** opened a freshly-navigated-into folder scrolled to
   its bottom rather than its top, whenever that folder was shorter than
   whatever was previously on screen.
2. **Screen recorder** video froze at its first frame (audio kept
   recording fine throughout) — the Forty-sixth pass's own build already
   contained one undocumented attempt at this (`lockCanvas()` →
   `lockHardwareCanvas()`) that turned out not to fully fix it; this pass
   replaces both with a real EGL/GLES2 renderer instead.
3. **Quicksave/quickload/screenshot** never visibly reacted to a tap —
   no pressed/highlight feedback at all, unlike every other on-screen
   button.
4. **Custom control layouts** could revert to defaults after leaving the
   app any way other than the in-app menu's own Close (system Back, or
   the OS reclaiming a backgrounded process) — root cause traced to
   `loadCustomLayout()` only ever running once, at a point in `onCreate()`
   that's always Portrait regardless of the player's actual game
   orientation.
5. **Settings screens' icons** — one real leftover emoji character
   (Layouts screen's per-preset edit action), several icons reading as
   too small, and the Input/gamepad glyph's face buttons specifically
   too tiny to read clearly.

# CHANGELOG — Forty-sixth pass

Reported directly: the Forty-fifth pass's file split didn't build — see
BUGS_FIXED.md for the root cause and fix. Six features requested in the
same message, once the build was working again: background music,
screen recording, a rebuilt Layouts screen (named/savable presets), a
Debug settings toggle for two existing tools, a ROM browser scroll fix
(BUGS_FIXED.md), and real icon glyphs for quicksave/quickload/screenshot
(BUGS_FIXED.md).

## 1. Background music (Sound settings)

**Category:** Feature — see FEATURES_ADDED.md for the user-facing summary.
**Files added:** `MusicPlaylistPlayer.kt`, `MainActivityMusic.kt`.
**Files modified:** `MainActivity.kt` (fields, prefs load, lifecycle),
`MainActivityAudio.kt` (nothing — see below), `MainActivitySettingsDialogs.kt`.
**Design:** `MusicPlaylistPlayer` is a small, self-contained playlist
engine (a `Context` and a `List<Uri>` in, nothing else) — sequential or
shuffled playback of a SAF-chosen folder, auto-advance on completion,
bounded skip-on-error (never plays two tracks from the same "everything
in this folder is corrupt" folder past 10 tries). Every `MediaPlayer.
prepare()` call happens on a background thread it spins up itself —
`prepare()` blocks, and this can run from *inside* another track's own
completion callback (auto-advance), which fires on the main thread; a
`setupGeneration` counter discards a background prepare() that's been
superseded by a newer play/skip call before it finishes, so rapid
next-taps can't end up starting stale audio. `MainActivityMusic.kt` is
the glue: `listMusicFiles()` walks a SAF tree (extension **or** reported
mime type — some providers get one wrong), the folder-picker's own
callback (`musicFolderPicker`, a field on `MainActivity.kt` — has to be,
`registerForActivityResult()` needs Activity-construction-time
registration, mirroring `dataFolderPicker`'s own exact pattern), and
`pauseMusicForLifecycle()`/`resumeMusicForLifecycle()` hooked into
`onPause()`/`onResume()` alongside the game loop's own stop/start.
**New prefs:** `PREF_MUSIC_FOLDER_URI`, `PREF_MUSIC_ENABLED`,
`PREF_MUSIC_SHUFFLE`, `PREF_MUSIC_VOLUME`.
**Verification:** brace/paren balance on every touched file; every new
symbol cross-checked declared exactly once and called with the right
name from every call site (see the pass's own full symbol sweep, same
method BUGS_FIXED.md's build-fix verification used); no local compiler
— see KNOWN_LIMITATIONS.md.

## 2. Screen recorder (game screen + audio, no on-screen buttons)

**Category:** Feature — see FEATURES_ADDED.md.
**Files added:** `GameScreenRecorder.kt`, `MainActivityRecorder.kt`.
**Files modified:** `MainActivity.kt` (field, lifecycle),
`MainActivityAudio.kt` (one line in `writePcm()`),
`MainActivityRender.kt` (recording indicator),
`MainActivityControlLayout.kt`/`MainActivity.kt`/
`MainActivityControlEditorGeometry.kt`/`MainActivityInput.kt` (the new
"record" on-screen button — see item 6).
**Design — why no buttons is automatic, not filtered:** the video source
is `captureGameFrameBitmap()` (`MainActivitySaveStateUi.kt`, unmodified
— already exists for screenshots/save-thumbnails, already the
pre-controls game frame) drawn onto a `MediaCodec` Surface-input video
encoder's own input `Surface`, from a dedicated capture thread this
class owns. The on-screen buttons are drawn by a completely different
code path (`drawControls()`, only ever called against the real
`SurfaceView`'s own canvas in `renderFrame()`) that this recorder never
touches — there's no frame where a button *could* appear, rather than
one that gets cropped out after the fact. Audio is fed straight from
`writePcm()` — the literal samples about to reach the `AudioTrack`, into
a standard `MediaCodec` AAC ByteBuffer-input encoder, non-blocking
(drops a chunk rather than ever stalling the game thread waiting for an
encoder buffer). Both muxed into one `.mp4` via `MediaMuxer`, written to
a cache-dir temp file (its String-path constructor is guaranteed
available at any API level this app supports; its FileDescriptor
overload isn't) and copied out to the Storage folder's new `video`
subfolder (or the same automatic-mirror fallback Screenshots/saves
already use) once finished — same "stage locally, copy out" shape
`SaveEntry.stageForWrite()`/`commitWrite()` already established.
720x480/20fps: exactly 3x the GBA's native 240x160 (undistorted, no
letterboxing math), and a modest rate given every captured frame is a
fresh ~1.4MB bitmap on a 2D handheld-console capture, not fast 3D
footage. No `MediaProjection`/screen-capture permission needed at all —
this never touches the device's actual display output, so there's
nothing to request permission for.
**Verification:** same as item 1. The MediaCodec/MediaMuxer sequencing
itself (Surface-input video + ByteBuffer-input audio + a muxer that
needs both tracks' formats before `start()`) follows the standard,
widely-used pattern for exactly this "encode programmatically-drawn
content" case rather than an improvised one — flagged in
KNOWN_LIMITATIONS.md as the one piece of this pass with genuine
runtime-only risk, since there's no device here to actually run it on.

## 3. Layouts screen rebuilt — named, savable/loadable layout presets

**Category:** Feature — see FEATURES_ADDED.md.
**Files added:** `MainActivityLayoutPresets.kt`.
**Files modified:** `MainActivitySettingsDialogs.kt` (`showLayoutsSettings()`
rebuilt; Button size/opacity moved into `showInputSettings()`),
`MainActivityControlEditorMode.kt` (`exitEditMode()`), `MainActivity.kt`
(`editingPresetName` field), `MainActivityMenus.kt` (Layouts row subtitle),
`MainActivityControlEditorGeometry.kt` (stale scope-comment fix, below).
**Design:** a preset is a named JSON snapshot of the *existing*
`customLayout`/`removedButtons`/`addedExtraButtons` — that live state is
completely unchanged, a preset is just a storable copy of it, captured
(`captureCurrentAsPreset()`) or restored (`applyLayoutPreset()`) as a
whole. "+ New layout" and each row's ✎ both funnel into the *same*
existing editor `enterEditMode()`/"Edit Button Layout…" already uses —
`editingPresetName` (null = today's ordinary edit session; `""` = a new
preset pending a name; any other string = updating that preset) is what
tells `exitEditMode()`'s Done handler to also prompt for a name/update
the preset, on top of its existing "save the active layout" behavior,
unchanged. Stored under one new key, `PREF_LAYOUT_PRESETS` (a JSON
array), same "one key, one blob" shape the active layout's own 3
prefixed keys already use.
**Also fixed while researching this:** the control editor's own
top-of-file comment (`MainActivityControlEditorGeometry.kt`) claimed
this app is landscape-locked — true when originally written, no longer
true since `android:screenOrientation` became `"unspecified"` plus a
real Portrait choice in Video settings, some later pass than whichever
wrote that claim. Both it and the (newly-written, this pass)
`LayoutEntry` doc comment it was based on now say so accurately; the
preset code's own cross-orientation handling was already written
correctly regardless (writes straight to the *other* orientation's
stored slot without touching the live one) — only the comment
explaining it as "not reachable today" was wrong.
**Verification:** same as item 1.

## 4. Debug settings — toggle Memory Viewer / Link Debug out of the ▤ menu

**Category:** Feature — see FEATURES_ADDED.md.
**Files modified:** `MainActivityMenus.kt` (`showGameMenu()` rewritten;
new Debug row), `MainActivitySettingsDialogs.kt` (`showDebugSettings()`),
`MainActivity.kt` (two new fields + prefs load), `MainActivityShared.kt`
(two new prefs).
**Design/refactor:** `showGameMenu()` used to be a fixed `items` list, a
*separate* `needsRom` set of hardcoded index positions into that list,
and a `when(which)` dispatch with its *own* hardcoded positions — three
parallel structures kept in sync purely by everyone remembering to
renumber all three together (the old code's own comment about "Memory"
being placed right before "Close" specifically to dodge renumbering
everything after it was already a symptom of this). Conditionally hiding
two entries would have meant every entry *after* whichever one got
hidden shifting position in all three places. Replaced with a
`GameMenuAction(label, needsRom, action)` list built conditionally —
label/needsRom/dispatch bound together per row, so entries can be added,
removed, or hidden in any combination with nothing else to keep in sync.
Both toggles default **true** (today's behavior — both menu entries were
always present before this pass) and persist immediately on tap, same as
every other simple on/off setting in this app.
**New prefs:** `PREF_DEBUG_MEMORY_VIEWER`, `PREF_DEBUG_LINK_LOG`.
**Verification:** same as item 1.

## 5. Fixed and updated

See BUGS_FIXED.md for the pass-45 build failure (root cause, fix,
full symbol-by-symbol verification), the ROM browser scroll/rearrange
fix, and the quicksave/quickload/screenshot icon-button change (a
direct "this looks bad" report, tracked as a fix rather than a
feature, matching how the emoji→text change on the same three buttons
was tracked in the Forty-fourth pass).



Requested directly: split `MainActivity.kt` into separate, organized
files, with the app behaving exactly the same afterward. Pure
architecture pass — no bug fixes, no new features, nothing in
BUGS_FIXED.md/FEATURES_ADDED.md this time.

## 1. MainActivity.kt split into 15 files by responsibility

**Category:** Refactor/architecture (no intended behavior change)
**Files modified:** `MainActivity.kt`; new `MainActivityAudio.kt`,
`MainActivityRom.kt`, `MainActivitySaveStateCore.kt`,
`MainActivitySaveStateUi.kt`, `MainActivityControlLayout.kt`,
`MainActivityRender.kt`, `MainActivityInput.kt`,
`MainActivityControlEditorGeometry.kt`, `MainActivityControlEditorMode.kt`,
`MainActivityMemoryViewer.kt`, `MainActivityMenus.kt`,
`MainActivityVideoSettings.kt`, `MainActivitySettingsDialogs.kt`,
`MainActivityDebugLog.kt`, `MainActivityLink.kt`.
**Problem:** `MainActivity.kt` had grown to ~7,700 lines and ~190
functions covering every concern this app has — audio, the render/game
loop, gameplay touch, the control-layout editor, save-states, ROM
loading, every settings screen, crash/link debug logging, and the link-
multiplayer dialogs — all in one file, making any one piece hard to
find or reason about in isolation.
**Solution:** Every function that wasn't required to stay (see below)
moved verbatim into a new file as an `internal fun MainActivity.<name>()`
extension function, grouped by responsibility (see each new file's own
top-of-file comment, and the file map at the top of `MainActivity.kt`).
This is the exact same mechanism `SharedUi.kt` already established
(Thirty-second pass) for the same reason, just applied to the rest of
the file: an unqualified call site (`someFunction()`) resolves to an
`internal` extension function on the enclosing receiver type the same
way it resolves a real member call, so every existing call site —
inside `MainActivity.kt`, and inside every other new file — keeps
compiling completely unchanged. `MainActivity.kt` itself now holds only
what Kotlin/Android actually requires to stay a physical class member:
every field/property (visibility widened `private`→`internal` so the
new files can read/write them), the `Activity`/`SurfaceHolder.Callback`
lifecycle overrides (`onCreate`, `onDestroy`, `onPause`, `onResume`,
`onWindowFocusChanged`, `surfaceCreated`, `surfaceDestroyed`,
`surfaceChanged` — Kotlin requires an override to be a literal class
member, not an extension function), the `SaveEntry` inner class (an
`inner class` needs to stay physical for its implicit outer-instance
access to keep working), and the small data classes/sealed class/
companion-object constants (left in place — moving the type
declarations themselves, as opposed to the functions that use them,
had no real readability upside worth the relocation risk).
**Reason:** Requested directly. The extension-function approach
specifically (over e.g. real owned-state helper classes holding a
`MainActivity` back-reference) was chosen because it requires
zero rewriting inside any moved function body — every field/function
reference inside a moved function reads exactly as it did before,
Kotlin resolves it exactly as it did before, and the *only* textual
change anywhere is each function's own signature line plus a handful of
visibility keywords — which is what made this safely reviewable at all
without a real compiler in this sandbox (same constraint as every pass;
see Verification below).
**Expected improvement:** Each piece of functionality now lives in a
file sized for what it actually does (the smallest new file is 112
lines, the largest 873) instead of one 7,700-line file holding
everything; a future pass touching, say, save-state logic only has
`MainActivitySaveStateCore.kt`/`MainActivitySaveStateUi.kt` to read, not
the whole app.
**Side effects:** None intended — this pass deliberately touched
nothing about *what* the app does, only *where* the code that does it
lives. Two real textual side effects fell out of the mechanism itself
and are worth naming explicitly: (1) every companion-object constant
(`TAG`, every `PREF_*` key, `ORIENTATION_*`, etc.) and every class field
that any moved function reads is now `internal` instead of `private` —
still invisible outside this app's own module, just no longer scoped to
this one file; (2) `stateSlotRow()` (moved to
`MainActivitySaveStateUi.kt`) used `this@MainActivity` twice, inside
nested `.apply{}` blocks, to reach back past an inner `ImageView`/
`TextView` receiver — valid only because `stateSlotRow()` used to be a
literal member of `class MainActivity`, which is itself a scope named
`MainActivity`. As a top-level extension function its own receiver's
label is the function's own name, not `MainActivity` (see Kotlin's
qualified-`this` rules for extension functions/receivers) — both
rewritten to `this@stateSlotRow`, the only content-level edit inside any
moved function body anywhere in this pass.
**Verification:** No compiler or device in this sandbox, same as every
pass — this one leaned harder on scripted, exhaustive checks specifically
*because* of that, rather than read-through alone, given the size of
what moved:
- Every one of the 190 top-level members (fields, functions, the
  companion object, the small data classes, `SaveEntry`) was segmented
  by exact line range and every function-shaped one mapped to exactly
  one destination (new file or "stays"); a scripted check confirmed
  all 168 that moved plus the 8 lifecycle/callback overrides that
  stayed account for all 176 functions with none missing, none
  duplicated, and none left unmapped.
- Every moved function's body was diffed line-for-line against the
  original: re-indenting the new (top-level) version by one level and
  reverting its signature line reproduces the original file's text
  exactly, everywhere, confirming nothing was altered beyond the
  signature line itself and the whitespace-only dedent.
- Brace balance checked per new file and against the original total
  (854 open/854 close both before and after, split across 16 files
  afterward instead of 1) — every individual file balances on its own,
  meaning no function's braces ended up split across a file boundary.
- Grepped for every symbol that lost `private` (companion-object
  constants inside a *nested* segment weren't touched by the first
  pass of this script, since only each segment's own signature line was
  rewritten — caught by grepping the new `MainActivity.kt` for leftover
  `private` and finding ~40 companion-object constants still
  inaccessible from the new files; fixed, then re-verified the same
  way) and for every `this@`/`return@`/labeled-lambda pattern in every
  moved file (`this@MainActivity` — the two `stateSlotRow()` instances
  above, both real, both fixed; every `return@Thread`/`return@post`/
  `return@setAdapter`/`return@registerForActivityResult`/
  `return@<functionName>` instance checked and confirmed to already be
  either self-contained within the one function that moved as a unit,
  or based on an SDK function/trailing-lambda name rather than
  `MainActivity`'s own class name, neither of which the move affects).
- Confirmed `SaveEntry`'s own three genuinely-private members
  (`doc()`, `stagingFile()`, `usesDataFolder`) are never referenced
  from any new file (only from `SaveEntry`'s own methods, which stayed
  together with it), so they correctly did *not* need widening.
- Diffed the full pre/post file tree: every other existing file
  (`LinkMultiplayer.kt`, `RomBrowserActivity.kt`, `SharedUi.kt`,
  `RomZipUtils.kt`, `EmulatorEngine.kt`, every Gradle/manifest/resource
  file) is byte-for-byte identical to before this pass; the diff is
  exactly the 15 new files plus `MainActivity.kt` itself.
- `build.gradle.kts` has no explicit `sourceSets`/`srcDir`
  configuration, so the default Kotlin source set already picks up
  every `.kt` file under `src/main/kotlin/` automatically — nothing to
  add there for the new files to be compiled.

---

# CHANGELOG — Forty-fourth pass

Nine things this pass, eight from one direct report covering the editor
popup, off-screen dragging, portrait L/R and Select/Start, the three
emoji control buttons, save-slot/screenshot thumbnails capturing the
on-screen buttons, and two new features (Quick Save/Autosave as real
slots, and a My Boy–style Auto Save & Load setting) — plus a ninth,
found and reported mid-pass: customized button layouts not surviving an
abrupt app close.

## 1. Custom button layout lost on an abrupt app close

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly, mid-pass: a layout saved via the
editor's own "Done"/Save action would survive closing the app through
an in-app menu path, but not swiping the app away (or an OEM task
killer) shortly after saving.
**Solution:** `saveCustomLayout()`'s `SharedPreferences.Editor` write
was `.apply()` — queues the disk write on a background thread and
returns immediately. Switched to `.commit()`, which blocks the caller
until the write has actually landed on disk.
**Reason:** `.apply()`'s async write is only guaranteed to be flushed
ahead of a *normal* activity transition; an abrupt process kill can
outrun it outright, and the next cold start then reads whatever was on
disk before that save — indistinguishable from the customization having
reset. `.commit()` closes that window entirely. Called once per
deliberate Save tap, not a hot path, so the small synchronous cost is a
non-issue.
**Expected improvement:** a saved layout now survives being closed any
way at all, not just through the menu.
**Side effects:** none. `exportLayoutBackup()`'s own external-file
mirror, called right after, was already a plain synchronous
`File.writeText()` and needed no equivalent change.

## 2. Editor per-control popup still clipping, after five previous fixes

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly, still reproducible after five previous
passes' worth of fixes to the same report (all of them position-clamp
fixes — see this file's own history above). "The button customization
popup still get cut off if you move around the button."
**Solution:** `editRow2`/`editOpacityRow`'s sliders were a *fixed*
`EDIT_TOOLBAR_SLIDER_WIDTH_DP` (190dp) regardless of actual screen
width. `refreshEditToolbarPosition()` now computes how much width is
actually available (`lastSw` minus margins minus the row label's own
measured width) and shrinks both sliders to fit, down to a
`EDIT_TOOLBAR_SLIDER_MIN_WIDTH_DP` (90dp) floor, before measuring the
bar.
**Reason:** every previous fix clamped where the popup gets
*positioned*; none ever questioned whether its own intrinsic width
could fit the screen at all. On a screen narrower than the ~330dp the
design width adds up to (a portrait phone's own width being the common
case — see item 4 below), no amount of position-clamping can stop the
excess width rendering off one edge or the other, which is exactly what
read as "cut off."
**Expected improvement:** the popup can no longer be wider than the
screen has room for, on any screen size.
**Side effects:** none on any screen wide enough for the 190dp design
width (every existing landscape install) — the new shrink logic is a
no-op there.

## 3. Dragged/resized controls able to render off-screen

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "moving button make it that it can't go
over the screen." A large (or resized-up) control dragged near an edge
could still render well past it.
**Solution:** new `clampControlCenterToScreen()` clamps a control's
center against its *actual current size* (base width/height from
`defaultGeometry`, times its current scale), reusing the existing
`clampToScreenAxis()` per axis. Applied both to the plain-drag branch
and, new this pass, to the resize branch — growing a control near an
edge now gently pushes its position back rather than letting it run
past.
**Reason:** the old clamp was `(x - editDragOffX).coerceIn(sw*0.03f,
sw*0.97f)` — a fixed percentage band on the *center point only*, blind
to the control's own size. A large control's center could stay
obediently inside that band while its rendered edges ran well past the
screen.
**Expected improvement:** no control, at any size, can be dragged or
resized fully or partially off-screen.
**Side effects:** none for typically-sized controls dragged well away
from an edge — behavior there is unchanged.

## 4. L/R and Select/Start distorted in portrait

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "fix if you go portrait the button ge
weird like r l."
**Solution:** both `lrH` (L/R) and `ssH` (Select/Start) were computed
from raw screen height (`sh * <factor>`) while their matching width came
from raw screen width (`sw * <factor>`). Both now use `minOf(sw, sh)`
instead of `sh` alone — the same pattern `outlineStrokeW` already uses
elsewhere in this file for the same reason.
**Reason:** the intended squat/pill shapes only ever held up because
`sw` happens to exceed `sh` in landscape — the app's normal orientation.
Portrait inverts that relationship, and the same formula inverted the
shape into a tall, narrow sliver along with it.
**Expected improvement:** L/R and Select/Start keep a sane, correctly-
proportioned shape in portrait instead of an inverted one.
**Side effects:** none in landscape — `minOf(sw, sh)` equals `sh` there
already, so this is a byte-for-byte no-op for every existing landscape
install.

## 5. Quick Save/Quick Load/Screenshot buttons using emoji glyphs

**Category:** bug fix (visual consistency)
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "it use emoji don't use emoji."
**Solution:** the three `addButton()` labels — "💾"/"📂"/"📷" — replaced
with plain text "QS"/"QL"/"SS", matching the existing 2-letter
convention already used for LA/LB/AB/RA/RB in the same row.
**Reason:** direct request. Scoped specifically to these three
on-screen game-control buttons — dialog titles and settings-list icons
elsewhere in the app use emoji too, but weren't part of this report and
are left untouched this pass.
**Expected improvement:** no emoji rendering variance across devices/
fonts for these three controls.
**Side effects:** none — `drawOutlineButton()`'s label sizing was
already tuned for this exact length.

## 6. Save-slot thumbnails and screenshots capturing on-screen buttons

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "save slot png should only screenshot
the game screen not the buttons too, and same for screenshot button."
**Solution:** new `cropToGameScreen()` crops a full-surface `PixelCopy`
capture down to `gameScreenRect` — already tracked precisely for
hit-testing/dragging/`updateGameMatrix()`'s own clamp — before scaling.
Used by both `captureStateThumbnail()` and `takeScreenshot()`.
**Reason:** `renderFrame()` draws the game bitmap and then
`drawControls()` onto that same `Canvas` before presenting it, so a
`PixelCopy` of the `SurfaceView` was always the game *and* every
on-screen button composited together — there's no earlier,
controls-free version of that surface left to capture instead.
Cropping the already-composited capture down to the known game-screen
region is a much smaller, safer change than trying to suppress control
drawing for one frame around a capture that happens on a different
thread.
**Expected improvement:** state thumbnails and manual screenshots show
only the game image.
**Side effects:** none — crop bounds are clamped to the actual captured
bitmap regardless of what `gameScreenRect` currently holds.

## 7. Quick Save and Autosave now shown as real slots

**Category:** feature
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "make a slot for quick save slot and
autosave slot," plus, from the same report, "idk did it really save
because there no quicksave slot so i can't check."
**Solution:** new `SlotKind` (sealed class: `QuickSave`, `Autosave`,
`Numbered(slot)`) generalizes `SlotInfo`, which used to only hold a bare
`slot: Int`. `showSaveStateSlotDialog()` now lists Quick Save and
Autosave first, ahead of the numbered slots, each with its own
thumbnail and timestamp exactly like a numbered slot already had.
`quickStateFile()` gained a thumbnail sibling (`quickThumbFile()`) it
never had before, and `quickSaveState()` now captures one on every
successful one-tap save.
**Reason:** direct request, and the direct mechanism behind the
"can't check" report — Quick Save previously had no thumbnail and never
appeared in any slot picker, by design, so there was no way to see
whether a one-tap save had actually landed.
**Expected improvement:** both slots are now visible, checkable, and
loadable through the same dialog as the numbered slots.
**Side effects:** none for the numbered slots — `loadSlotInfo()`
(extracted from what used to be `showSaveStateSlotDialog()`'s own inline
per-slot logic) reproduces their existing behavior exactly, just
generalized to also serve the two new kinds.

## 8. New "Auto Save & Load" Misc setting

**Category:** feature
**Files modified:** `MainActivity.kt`
**Problem:** reported directly: "add auto save & load toggle like
myboy... auto save game on exit, load it back on start."
**Solution:** new `autoSaveLoadEnabled` preference (off by default).
When on, `onPause()` writes a dedicated `Autosave` state
(`autoStateFile()`) synchronously — unlike every other save-state write
in this file, which run on a background `Thread` — every time the app
backgrounds. `loadRomFromUri()`'s own success callback silently loads it
back the next time that same ROM starts, before `startGameLoop()`.
**Reason:** `onPause()`'s write has to be synchronous because Android
may kill the process shortly after `onPause()`/`onStop()` return, with
no guarantee a fire-and-forget background `Thread` ever finishes; the
background-`Thread` pattern used elsewhere is optimized for keeping
gameplay responsive while the game loop is still running, which by this
point in `onPause()` it no longer is (`stopGameLoop()` already ran).
Load-on-start is silent (no toast when nothing's found) since it runs on
every single ROM load, and most of the time — especially the very first
time a given ROM is opened — there won't be anything to load yet.
**Expected improvement:** matches the requested My Boy–style behavior;
off by default so nothing changes for anyone who doesn't enable it.
**Side effects:** thumbnail capture for the Autosave slot (see item 7)
is fired on its own best-effort background `Thread` from inside
`onPause()` rather than awaited synchronously there, since
`captureStateThumbnail()`'s own `PixelCopy`-plus-latch approach would
deadlock if blocking-awaited directly on the main thread. The state
save itself — the part that actually matters — is unaffected by this;
worst case the Autosave row's thumbnail lags by one save until the next
chance to update it. Also added to the "Reset settings" flow's own
defaults, unlike several older settings which reached that flow only in
a later pass (see this file's own history) — same gap, closed from the
start this time.

# CHANGELOG — Forty-third pass

Six things this pass: two real performance bugs in the per-frame render
path (found via direct code inspection, not a screenshot/report — both
confirmed by reading `drawDpad()`/`shoulderButtonPath()` directly), the
per-item editor's toolbar still going off-screen on drag despite four
previous passes' worth of fix attempts at the same report, Turbo A/B
rendering smaller than A/B, the control layout resetting when this app's
storage is cleared, and a request for an automatic own-folder — saves,
states, screenshots, layout — with no setup step required, "like My Boy."

## 1. `drawDpad()` — 240 RectF allocations/sec eliminated

**Category:** performance fix
**Files modified:** `MainActivity.kt`
**Problem:** allocated a fresh `RectF` for each of the 4 d-pad arms on
every single rendered frame — permanent GC churn on the same thread that
paces audio playback, for as long as a game is running.
**Solution:** the 4 arm rects are now reusable fields, recomputed via
`updateDpadArmRects()` only when the d-pad's own bounding rect has
actually changed (a plain `RectF.equals()` check) instead of every frame.
**Reason:** direct report, exact numbers given (240 allocations/sec at
60fps).
**Expected improvement:** zero steady-state allocation from this
function during normal play; only an editor drag/resize/orientation
change triggers a recompute.
**Side effects:** none — output is numerically identical, verified by
deriving the draw position from the cached rects' own `centerX()`/
`centerY()`/`width()` rather than duplicating the arithmetic.

## 2. `shoulderButtonPath()` — 120 Path allocations/sec eliminated

**Category:** performance fix
**Files modified:** `MainActivity.kt`
**Problem:** allocated a brand-new `Path` (a moveTo, 2 quadTo, a cubicTo,
a lineTo, a close) on every call, twice per frame for L and R.
**Solution:** two reusable `Path` fields (L and R need independent,
simultaneously-live geometry), rewound (`Path.rewind()`, not `.reset()` —
keeps the internal arrays) and rebuilt only when that side's rect has
changed since the last frame.
**Reason:** direct report, exact numbers given (120 allocations/sec at
60fps).
**Expected improvement:** same steady-state-zero-allocation improvement
as #1, same reasoning.
**Side effects:** none — geometry construction is untouched, just
targeted at a reused Path instead of `Path()`.

## 3. Per-item editor toolbar still cut off/disappearing on drag

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** same direct report as four previous passes'
`refreshEditToolbarPosition()` fix attempts: "if you move it sometimes it
disappears or get cutoff." The most recent of those attempts had already
named the exact remaining gap in its own comment ("the one remaining
case (topBound+h doesn't fit below lastSh at all)") without actually
closing it — a trailing `.coerceAtLeast(topBound)` ran *after* the
on-screen clamp with no ceiling of its own, so on a short enough
effective screen it could push the toolbar below the visible screen
entirely.
**Solution:** `topBound` is now folded into a single `coerceIn(minTy,
maxTy)` as a *preference*, honored only when doing so can't push the bar
past the bottom of the screen; falls back to the screen's own top margin
otherwise. Provably bounded — see the function's own doc comment for the
full argument.
**Reason:** direct report, worded identically to the reports the four
previous fix attempts were responding to.
**Expected improvement:** the toolbar can no longer render off-screen
regardless of screen size, selected control size, or drag position.
**Side effects:** on the one screen-too-short-for-either-preference edge
case, the bar now prefers overlapping the top bar's own strip (still
fully visible/usable) over running off the bottom (not usable at all).

## 4. Turbo A/B rendered smaller than normal A/B

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** `tSz` (Turbo A/B's default size) was `abSz * 0.75f` — a
fixed 75% shrink baked in underneath each button's own independent
Control Size slider, not instead of it. Matching percentages on both
sliders still produced two different sizes.
**Solution:** `tSz = abSz`. Turbo A/B keep their own independent
position/scale entries — still draggable/resizable separately from A/B —
only the default size they scale from now matches.
**Reason:** direct report: "turbo a and b not the same size as normal a
and b."
**Expected improvement:** the same Control Size percentage now produces
the same rendered size on both.
**Side effects:** none — the offset that positions Turbo A/B relative to
A/B is computed from `abSz`, not `tSz`, so it's unaffected; the two
buttons remain comfortably clear of each other at the new size.

## 5. Control layout resetting when this app's storage is cleared

**Category:** bug fix
**Files modified:** `MainActivity.kt`
**Problem:** `loadCustomLayout()`/`saveCustomLayout()` are pure
SharedPreferences, already outside any cache directory — but
SharedPreferences is still only ever as durable as this app's own
private storage, gone the moment that's cleared any other way.
**Solution:** `exportLayoutBackup()` mirrors both orientation profiles to
a JSON file in the new automatic own-folder mirror (#6) every time
`saveCustomLayout()` runs; `importLayoutBackupIfNeeded()` restores from
it on startup, but only when SharedPreferences has no layout data at all
to lose.
**Reason:** direct report: "if i clear cache my button reset."
**Expected improvement:** a layout survives a storage clear as long as
the automatic mirror folder does.
**Side effects:** none for anyone who's configured a Storage folder
already (see #6) — this backup only ever runs in the automatic-mirror
default case.

## 6. Automatic own-folder mirror — saves/states/screenshots/layout

**Category:** feature
**Files modified:** `MainActivity.kt`
**Problem:** this app's existing Storage-folder feature (Settings →
Storage) is opt-in — nothing leaves internal storage without a manual
SAF folder pick first. Requested directly: "make the app make its own
folder like my boy emulator and all the stuff in there like save
screenshot layout."
**Solution:** a new automatic mirror folder —
`Android/data/<pkg>/files/mGBA` (Saves/States/Screenshots/Layout) —
needs no permission and no setup, active whenever no Storage folder is
explicitly chosen. Native save/state I/O is untouched (still reads/writes
`SaveEntry`'s existing internal `legacy` file exactly as before); this
only ever mirrors already-successful writes outward, best-effort, via the
new `SaveEntry.mirrorToAutoFolder()`. Screenshots' existing fallback path
now nests under this same root instead of sitting bare under
`getExternalFilesDir()`. Steps aside entirely once a Storage folder is
configured — one visible "own folder" at a time.
**Reason:** direct report, as above.
**Expected improvement:** saves/states/screenshots/layout are all in one
findable, organized folder from first launch, no setup trip required.
**Side effects:** no migration of anything already saved under plain
internal storage before this pass — deliberately, matching this
project's existing stated policy on the Storage-folder feature just
above (moving/deleting a person's actual save data automatically, with
no real device available anywhere in this project's history to verify
that move against, is a worse risk than asking). Only new
saves/states/screenshots/layout writes go to the new folder from here.

# CHANGELOG — Forty-first pass

Four things reported directly, covering the file manager, the ROM
browser's Landscape→Portrait transition, the per-item editor's Control
Size/Opacity controls, and Max frame skips. Five screenshots attached, all
of the per-item editor bar (the title screen with Game Screen Size open,
then R Shoulder and A Button at a few slightly different toolbar
positions/zoom levels) — matched item 3's report directly. The file
manager and frame skip reports were text-only; both were directly
traceable in code without needing a matching screenshot.

## 1. File manager — .zip files no longer held back from the initial list

**Category:** UX/performance fix
**Files modified:** `RomBrowserActivity.kt`
**Problem:** Even with the Fortieth pass's own zip-scan parallelization,
`.zip` files were still held out of the list entirely until each had been
individually opened and content-checked (`RomZipUtils.zipContainsGba()`)
— a folder with several archives still showed only its bare `.gba`
files/subfolders at first, with the rest populating in afterward as scans
completed one by one. Reported directly: "only one file show at the
start and the other load later unlike my boy file manager it already
show all the file instantly."
**Solution:** `refreshList()` now treats `.zip` files the same as
folders/`.gba` files for the *initial* render — included by name/
extension alone, shown instantly, no scan required, correctly sorted in
place alongside everything else from the start. Content verification
still runs exactly as before, on the same background thread pool, but
now *prunes* an eventually-invalid `.zip` back out of the already-shown
list instead of gating that zip's first appearance on the scan
finishing.
**Reason:** direct report, as above.
**Expected improvement:** the file list should appear complete
immediately, matching the cited reference file manager's own behavior. A
side benefit: since every entry is already in its final sorted position
from the first render, nothing visibly jumps to a new spot once
verification finishes either (the old add-after-verify design appended
newly-verified zips at the end, then re-sorted, which could shuffle the
list the user was already looking at).
**Side effects:** A `.zip` that turns out not to contain a `.gba` may now
be visible for a moment before disappearing, rather than never appearing
at all. Tapping it in that window is already handled safely: MainActivity's
`loadRomFromUri()`/`stageRomFile()` already tolerates "no `.gba` found
inside" gracefully (a toast, not a crash), since the SAF fallback picker
has never gone through `zipContainsGba()` at all — this isn't a new code
path, just a slightly wider window in which an existing, already-graceful
one can be reached. `renderList()`'s own doc comment updated —
`stillScanning` now describes pruning, not gating additions.
**Verification:** No compiler/device available in this sandbox (see
README_SETUP.md). Traced `entries`/`zipCandidates` construction and the
renamed `invalidZips` set to confirm the final `filterNot` only ever
removes, never reorders or duplicates, entries from the already-rendered
list, and that the `generation` staleness guard (untouched) still applies
to it. Balance-checked.

---

## 2. ROM browser — Landscape→Portrait transition, next step tried

**Category:** UX polish (continuation of a Fortieth-pass fix)
**Files modified:** `themes.xml`
**Problem:** Reported directly, still visible after the Fortieth pass's
own `overridePendingTransition(0,0)` fix for this same Landscape
MainActivity → Portrait RomBrowserActivity transition: "it landscape but
it go to portrait instantly which is bad."
**Solution:** Added `android:windowDisablePreview=true` to
`Theme.mGBA.RomBrowser` — the next step that pass's own
KNOWN_LIMITATIONS entry had already flagged to try if a flash was still
visible. It addresses a different mechanism than the earlier fix: the
starting-window snapshot Android can show for a newly-launching Activity
before its first real frame is ready, separate from the enter/exit
transition animation `overridePendingTransition` already suppresses.
**Reason:** direct report, as above.
**Expected improvement:** should remove whatever's left of the visible
mismatch during this transition; combined with the already-black
`windowBackground` on this theme, the worst case left is a plain black
frame rather than a stretched or mismatched-orientation one.
**Side effects:** None expected. `windowDisablePreview` only affects the
one-time starting-window snapshot for this Activity, not its actual
content, layout, or the orientation lock itself — RomBrowserActivity
remains statically Portrait, unchanged, per the Thirty-second pass's own
crash history (see KNOWN_LIMITATIONS.md for why runtime rotation isn't
attempted here again).
**Verification:** No compiler/device. Confirmed `windowDisablePreview`
against long-standing Android theme attributes, no version-gating needed
for minSdk 24. XML re-validated as well-formed. Still can't be fully
confirmed without a real device — the same honest limitation every pass
touching this screen has had to note; see KNOWN_LIMITATIONS.md.

---

## 3. Control Size / Control Opacity — real sliders, type an exact number

**Category:** UX fix + minor architecture improvement
**Files modified:** `MainActivity.kt`, `SharedUi.kt` (new shared widget,
one relocated helper)
**Problem:** Reported directly, even after the Fortieth pass's own
48dp-minimum-touch-target fix for the "-"/"+" chips: "the plus for
opacity and increase button size it very small and bad... maybe a slider
with number or percent and you can type the number."
**Solution:** New reusable `sliderRow()`/`SliderRow` in `SharedUi.kt` — a
`SeekBar` plus a tap-to-type value readout (opens a new
`showTypeValueDialog()`, also in `SharedUi.kt`) — replaces the "-"/"+"
`editChip()` pair for both Control Size (50-800%) and Control Opacity (a
percent, floor matching the existing 60/255 alpha floor via
`alphaToPercent()`/`percentToAlpha()`). Both are drag-anywhere-on-the-
track *and* type-an-exact-number. `roundedDialogBackground()` moved from
`MainActivity.kt` to `SharedUi.kt` alongside them — the new dialog needs
it too, and it's exactly the kind of small/stateless/cosmetic helper that
file exists for (see its own top comment); every existing call site is
unaffected, same unqualified/same-package extension-function pattern the
rest of that file already relies on. The old delta-based
`adjustSelectedScale()`/`adjustSelectedAlpha()` are replaced with
absolute `setSelectedScalePercent()`/`setSelectedAlphaPercent()`, and a
new `syncEditButtonBarToSelection()` consolidates what used to be three
separate partial-refresh spots (`updateEditButtonBarLockIcon()`, plus
inline label/visibility lines in `onEditTouch`'s `ACTION_DOWN`) into one
— now also called after Reset and the lock toggle, which the old
stateless chips never needed since they had no live value that could go
stale.
**Reason:** direct report, as above.
**Expected improvement:** both controls should now be comfortable to
grab anywhere along their width, show their current value at a glance,
and accept an exact typed number for precise adjustment.
**Side effects:** The corner-drag resize gesture on the game canvas
itself (a second, older way to resize a control) now also keeps the
Control Size slider's displayed value live during that drag, so the two
never show inconsistent numbers. A locked control now visibly dims both
sliders (`SliderRow.setEnabled()`) rather than silently no-op-ing on
interaction — a small UX improvement over the old chips, which had no
visual indication of a locked state at all. Two stale doc-comment
references to the deleted `adjustSelectedScale()` were updated to point
at its replacement.
**Verification:** No compiler/device. Traced every constructor/function-
call site for argument name/order correctness. Caught and fixed a real
Kotlin scoping hazard during review: building the `SeekBar` inside an
`.apply {}` block would have let the receiver's own `max` property shadow
this function's `max` parameter for the unqualified reference on the
assignment's right-hand side (an implicit-receiver member resolves before
an enclosing function's same-named parameter) — moved the assignment
outside `apply{}` entirely to remove the ambiguity rather than rely on
being right about which way it resolves. Balance-checked.

---

## 4. Max frame skips — fixed making things slower instead of faster

**Category:** Bug fix (root cause)
**Files modified:** `MainActivity.kt`
**Problem:** Reported directly: "can you check max frame skip at 10 it
very bad its laggy i think it wrong unlike myboy it skip frame so its
fast but it skip frame but in here the max frame skip it becomes
slower." Root cause: the "behind schedule" signal gating
`maybeSkipRenderThisFrame` compared the *previous* iteration's full
wall-clock duration against one frame's budget — but that duration
always includes the blocking `writePcm()` call, the frame pacer by
design (see the AUDIO ARCHITECTURE comment above `initAudioTrack()`),
which alone consumes ~1 frame period of real time on every normal
iteration regardless of whether anything was actually skipped. Total
iteration time therefore sits right on the exact budget threshold
essentially always, so which side of that line it lands on is mostly
scheduling/audio-buffer noise, not a real signal the device is actually
struggling — "behind schedule" could fire close to half the time even on
a healthy device. With no cooldown beyond a single non-skip iteration,
one false trip could then chain up to `maxFrameSkips` visibly-stuck-on-
one-frame iterations in a row — worse, not better, the higher
`maxFrameSkips` was set, exactly the behavior reported.
**Solution:** The skip decision now compares against `lastComputeNs` —
only the CPU-bound portion of the previous iteration (`nativeSetKeys`
through `nativeReadAudioSamples`), timed separately from, and stopping
before, the blocking `writePcm()` call. This isolates "is the device's
own compute too slow for one frame's budget" from "did the pacer's own
intentional wait happen to land a hair over an exact threshold" — the
question this check was always meant to answer.
**Reason:** direct report, as above.
**Expected improvement:** Max frame skips should no longer trigger on
ordinary audio-pacing noise, and should scale sanely with the configured
value (10 no longer worse than a low setting) — it should only engage
when the device's own per-frame compute genuinely exceeds budget.
**Side effects:** The underlying "skip the pixel blit but still fully
emulate the frame" mechanism (`EmulatorEngine.nativeRunFrame(null)` /
`mgba_jni.c`) is unchanged — this pass only fixes *when* that mechanism
engages, not what it does. Re-traced the native side while investigating:
`g_core->runFrame()` (the actual CPU/PPU/APU emulation) always runs
regardless of a null bitmap; only the pixel-copy loop is skipped, so this
feature's real headroom is inherently limited to whatever that copy
costs. Not a new limitation this pass introduces, just one this pass's
own investigation confirmed — noted in KNOWN_LIMITATIONS.md.
**Verification:** No compiler/device. Traced the `lastComputeNs`
assignment through all three code paths (the skip branch, the normal
single-frame branch, and the fast-forward batch branch) to confirm every
one sets it right after its own last `nativeReadAudioSamples` call and
before its own `writePcm()`/decimate-and-write, so whichever branch runs,
the next iteration's decision is always based on real compute time, never
the pacer's wait. Confirmed `t0` (still used for the FPS overlay window
and the no-audio fallback sleep, both unrelated to this fix) is
untouched. Balance-checked.

---

# CHANGELOG — Fortieth pass

Five things reported directly against the Thirty-ninth pass's own
delivery and the ROM browser (Thirty-second pass, untouched since). Five
screenshots attached matched every one of them: the portrait edit view
showing the dark background band behind the D-pad/buttons, the landscape
edit view with the grid visible, both per-item popups (D-Pad, A Button)
showing the tiny Control Size ± chips, and the ROM browser's own
portrait view with a large unused black strip above "Load game."

## 1. Editor alignment grid — cells weren't actually square

**Category:** Bug fix (root cause, not a workaround) + minor extension
**Files modified:** `MainActivity.kt`
**Problem:** `gridDivisions` cells were built as `w/N` columns by `h/N`
rows (`drawGrid()`, `snapScaleToGrid()`) — N of each, independently, over
whatever the screen's actual width and height happened to be. On any
non-square screen (i.e. every real device, in either orientation) that's
a rectangle, not a square, no matter what N is — reads exactly as "not
really box[es]," which is what was reported. Size was also capped at the
32 preset.
**Solution:** New `gridCellPx()` is now the single source of the cell
size: `min(lastSw, lastSh) / gridDivisions`, so cells are always real
squares — N of them across the shorter screen dimension, however many
whole ones fit the longer one. `drawGrid()` and both
`snapPositionToGrid()`/`snapScaleToGrid()` all read from it instead of
each deriving their own (previously non-square) size, so what's drawn
and what dragging/resizing snaps to can never drift apart. `gridOptions`
extended to `4, 8, 16, 32, 64` (was capped at 32); preset labels changed
from `"N×N"` to bare `"N"` since the old label stopped being accurate the
moment N stopped meaning "columns and rows equally" — the dialog's
description text was extended to explain what the number means instead.
**Reason:** Direct report: "grid not really box and add more like 60 not
just 30 grid."
**Expected improvement:** The grid overlay now draws actual squares in
both orientations, snapping matches exactly what's drawn, and a
substantially finer 64-division option is available for precise
alignment (close to the "60" asked for; kept as a power of 2 to match
this dialog's own existing 4/8/16/32 progression rather than introducing
an odd one out).
**Side effects:** A previously-saved `PREF_GRID_SIZE` value (say, 8)
means something visually different now — the same integer now produces
square cells instead of a `w/N`-by-`h/N` rectangle, and landscape vs.
portrait will show a different *number* of columns vs. rows at the same
setting (always exactly N×N before; now N across the short side and
however many fit the long side). This is the fix itself, not a
regression to work around — nothing about a saved layout's own button
positions/sizes changes, only what the (purely visual/optional-snap)
grid looks like.
**Verification:** No compiler/device in this sandbox, as every pass.
Hand-traced `gridCellPx()`/`drawGrid()`/`snapPositionToGrid()`/
`snapScaleToGrid()` for both portrait and landscape aspect ratios,
confirming one shared cell size feeds all four. Grepped every remaining
call site of both snap functions to confirm none still pass the removed
`dimension` argument. Ran a corrected comment/string/template-aware
brace-paren-bracket scanner (own bug found and fixed this pass — it
wasn't restoring string-vs-code mode correctly after a `${...}`
template, which is common enough in this file's own log strings that it
mis-flagged several untouched files too, not just the edited ones; same
class of self-inflicted scanner bug Thirty-ninth pass's own item 5
found) over every `.kt` file in the project: all balanced.

---

## 2. Control Size / Control Opacity ± chips — real touch targets

**Category:** Bug fix (root cause, not a workaround)
**Files modified:** `MainActivity.kt`
**Problem:** `editChip()`'s `setPadding(18, 4, 18, 4)` passed raw pixels,
not dp — every other size in this file goes through `dp()`, this one
didn't. On a real, higher-density phone that's a handful of actual
pixels, not the 18dp/4dp it reads as in the source. Barely visible on
worded chips ("Add Control" etc.), which get most of their size from the
text itself regardless; nearly the *entire* size of a single-glyph
`"-"`/`"+"` chip, which is exactly what was reported.
**Solution:** `setPadding` now goes through `dp()` like everything else
in the file. `editChip()` gained an opt-in `minTouchDp: Int = 0`
parameter — 0 changes nothing for any existing call site — that sets
`minWidth`/`minimumWidth`/`minHeight`/`minimumHeight` to `dp(minTouchDp)`
when positive. The four Control Size/Control Opacity `"-"`/`"+"` call
sites now pass `minTouchDp = 48` (Android's own minimum touch target
guideline), guaranteeing a real tap target regardless of how little a
bare glyph plus padding would otherwise produce.
**Reason:** Direct report: "in control size there's plus and minus but
it really hard to click its very small."
**Expected improvement:** The four stepper buttons are now a guaranteed
48dp square minimum — several times their previous effective size.
**Side effects:** The `dp()` padding fix applies to every `editChip()`
button in the editor UI, not just the four steppers — the top bar (Add
Control / Reset Controls / Grid / Cancel / Done) and Unlocked/Reset in
the per-item bar all get modestly larger too, since 18/4 was always
meant to be dp, not raw pixels. The top bar is already wrapped in a
`HorizontalScrollView` specifically to handle overflow (added when it
grew to five buttons — see Thirty-ninth pass), so this is a safe,
already-anticipated case, not a layout break.
**Verification:** No compiler/device. Confirmed via grep that all 11
`editChip(` call sites resolve correctly against the new 3-parameter
signature — Kotlin's trailing-lambda call syntax works fine with a
defaulted middle parameter, so the 9 call sites that don't pass
`minTouchDp` still compile as `(label) { onClick }` against the default.
Balance-checked.

---

## 3. Removed the semi-transparent control-area background band

**Category:** Bug fix (removal, requested directly)
**Files modified:** `MainActivity.kt`
**Problem:** `drawControls()` filled a full-width rect from
`controlsTop` down to the bottom of the screen with `colorControlsBg`
(`#CC111122` — dark navy at ~80% opacity) every single frame, behind the
D-pad/buttons.
**Solution:** Deleted the fill and its now-unused color constant.
`renderFrame()` already runs `canvas.drawColor(Color.BLACK)` before
`drawControls()`, so the area is now plain black — seamless with the
rest of the screen — instead of a distinct tinted panel. `fillPaint`
itself (the shared `Paint` reused for every button/D-pad/FF fill in this
function) is untouched; only its two `colorControlsBg`-specific lines
are gone.
**Reason:** Direct report: "at the bottom there black transparent and
its bad... i don't really like it."
**Expected improvement:** No more visible tinted band behind the
on-screen controls.
**Side effects:** Worth flagging as a judgment call: the report said the
tint was disliked but didn't specify a replacement, so full removal
(plain black, matching the rest of the screen) was chosen as the most
direct reading rather than, say, a different color or lower opacity —
easy to swap for a specific alternative instead if plain black isn't
actually what was wanted.
**Verification:** No compiler/device. Confirmed `fillPaint`'s other 8
use sites in `drawControls()`/`drawDpad()` are intact and unrelated to
the removed rect. Confirmed `drawColor(Color.BLACK)` unconditionally
precedes `drawControls()` in `renderFrame()`, so no stale-frame/
unfilled-gap risk. Updated one other doc comment (inside
`updateGameMatrix()`) that referenced `colorControlsBg` by name, so
nothing still points at a removed symbol. Balance-checked.

---

## 4. ROM browser — landscape flash before settling into portrait

**Category:** Bug fix
**Files modified:** `MainActivity.kt`, `RomBrowserActivity.kt`
**Problem:** MainActivity runs in landscape during play;
RomBrowserActivity is manifest-locked to portrait. Opening it triggers a
real display reconfiguration, and the default Activity transition
animation (a slide/fade across the switch) gave that reconfiguration a
couple of animated frames to be visible in — reads exactly as "opens in
landscape... then it go to portrait instantly."
**Solution:** `changeRom()` now calls `overridePendingTransition(0, 0)`
immediately after launching `RomBrowserActivity`, collapsing the
enter/exit transition to an instant cut. `RomBrowserActivity` gets a
matching `override fun finish() { super.finish();
overridePendingTransition(0, 0) }` so all of its several `finish()` call
sites (✕ Close, picking a `.gba` file, the SAF-picker callback, backing
out at the root) get the same fix from one place, covering the return
trip too.
**Reason:** Direct report.
**Expected improvement:** The transition into and out of the ROM browser
should now be an instant cut instead of an animated one with a
wrong-orientation frame visible mid-transition.
**Side effects:** `overridePendingTransition` is deprecated as of API 34
(replaced by `overrideActivityTransition`) but remains fully functional
at this app's targetSdk 34 — kept as the plain, long-stable call rather
than a version-gated branch onto the newer, unfamiliar API, since the
two behave identically here and there's no compiler in this sandbox to
verify a new signature against. `@Suppress("DEPRECATION")` added at both
call sites. Deliberately doesn't touch `requestedOrientation` anywhere —
see `RomBrowserActivity`'s own top-of-file comment for the real native
RenderThread SIGABRT that made this screen its own Activity in the first
place; this is a window-transition/animation-only change and doesn't go
near that code path.
**Verification:** No compiler/device, as every pass — this specific
class of fix (a system-compositor-level rotation animation) is
inherently hard to fully verify without a real device; called out again
in KNOWN_LIMITATIONS.md this pass. Confirmed by reading the platform
docs' description of both APIs that neither calls `requestedOrientation`
or touches a live window's surface, so this carries none of the risk the
prior crash involved. Balance-checked both files.

---

## 5. ROM browser — status bar hidden, dead black space at top

**Category:** Bug fix (root cause)
**Files modified:** `themes.xml`, `AndroidManifest.xml`
**Problem:** The whole app uses `Theme.mGBA`, which sets
`android:windowFullscreen=true` at the `<application>` level — correct
for MainActivity's actual gameplay immersion (see `setImmersive()`), but
`RomBrowserActivity` inherited it too despite being a plain file-picking
utility screen. With the status bar hidden, its reserved space just
rendered as dead black area with no clock/notification/signal icons in
it.
**Solution:** New style `Theme.mGBA.RomBrowser` (parent `Theme.mGBA`)
overriding just `android:windowFullscreen` to `false`; applied via
`android:theme` on `RomBrowserActivity`'s own `<activity>` tag. Every
other visual (black window background, black status/nav bar color, no
content overlay) is unchanged.
**Reason:** Direct report: "there's lot of black space... make it that i
can see the notification or mobile data."
**Expected improvement:** The system status bar (clock, notifications,
signal/battery) should now show while browsing for a ROM; MainActivity's
own fullscreen gameplay is unaffected — it still uses `Theme.mGBA`
directly.
**Side effects:** None expected — `RomBrowserActivity.onCreate()` has no
runtime status-bar/immersive code of its own (confirmed below), so the
fullscreen behavior was coming entirely from the inherited theme
attribute; this one override is a complete fix, not a partial one
needing a runtime companion.
**Verification:** No compiler/device. Grepped the whole project
confirming `setImmersive()` and every `SYSTEM_UI_FLAG_*`/
`WindowInsetsController` usage is scoped to `MainActivity.kt` only —
`RomBrowserActivity.kt` has none. Validated both changed XML files parse
as well-formed XML.

---

## 6. ROM browser — zip scan parallelized, real "still scanning" indicator

**Category:** Performance fix + UX clarity fix
**Files modified:** `RomBrowserActivity.kt`
**Problem:** `refreshList()`'s background zip scan checked each `.zip`
candidate for a `.gba` entry one after another on a single `Thread` —
already flagged as a known, deliberate trade-off in
KNOWN_LIMITATIONS.md (Thirtieth pass): "a folder with many... `.zip`
files will take proportionally longer." Reported directly against a
real folder with a dozen archives (screenshot: 11 `.zip` files, one bare
`.gba`) — exactly that cost coming due. The immediate (`.gba`/folder)
results rendered right away, but the rest waited through eleven
sequential scans behind a single, easy-to-miss gray "Checking
archives…" text row.
**Solution:** Two independent fixes. (1) The scan now runs on a small
bounded pool (`ZIP_SCAN_THREADS = 4`) instead of sequentially — every
candidate is submitted up front, then its `Future` is collected, so
wall-clock time for N archives is roughly N/4 scans deep instead of N.
Still coordinated from a background `Thread` (unchanged), so the main
thread is never blocked either way. (2) The old
`messageRow("Checking archives…")` text-only row is replaced by a new
`scanningRow()` — an actual indeterminate `ProgressBar` next to the same
text — so "still actively working" reads unambiguously instead of being
mistakable for a finished/empty state.
**Reason:** Direct report: "it only show one file but still checking
archives to see all file."
**Expected improvement:** A folder with several archives should populate
substantially faster, and the loading state should read clearly as "in
progress."
**Side effects:** `ZIP_SCAN_THREADS` is a fixed constant, not adaptive
to device core count — deliberate, since this work is I/O-bound
(`ContentResolver`/flash reads), not CPU-bound, so core count isn't the
relevant resource; see KNOWN_LIMITATIONS.md. `messageRow()` now only
serves the "No ROMs or folders here" end state; its doc comment was
updated to stop describing the now-separate scanning row.
**Verification:** No compiler/device. Traced the `Future` submission/
collection order to confirm every candidate is submitted before any
`.get()` blocks (genuine parallelism, not accidental serialization), and
that `pool.shutdown()` only runs after every result is collected (no
leaked running tasks). Confirmed the existing `generation` staleness
guard (discarding a scan's result if the user has since navigated away)
is untouched and still applies to the merged final render.
Balance-checked.

---

# CHANGELOG — Thirty-ninth pass

Five related reports, all traced back to the same root cause introduced
when the game screen became resizable (Thirty-seventh pass): "Game
Screen Size" visibly resizing a big black area instead of just the
image, Stretch to Fit stretching what looked like the whole UI, a
leftover top-left speed indicator, and a request for a full grid-based
alignment/snapping system plus a cleanup pass on the editor's own UI
text. Screenshots (edit mode, and the resized game screen mid-session)
were attached and matched this diagnosis directly.

## 1. Game Screen Size resizing a black area instead of just the image

**Category:** Bug fix (root cause, not a workaround)
**Files modified:** `MainActivity.kt`
**Problem:** `updateGameMatrix()` built the editable "gamescreen" box as
`resolvedRect("gamescreen", ..., w = sw, h = sh * gameScreenFraction)` —
full screen width by a height fraction, an area with nothing to do with
the GBA's actual 3:2 image aspect ratio. The non-stretch branch then
aspect-fit the real bitmap *inside* that oversized box, so most of what
the editor let you drag/resize was dead pillarboxed space the small
visible image just happened to sit somewhere inside of. Resizing "Game
Screen Size" really resized that big mostly-empty rectangle — reads
exactly like "resizing enlarges a black area/container instead of the
image," matching both the report and the attached edit-mode screenshots
(a yellow selection box far larger than the actual game picture inside
it).
**Solution:** The box's default geometry is now itself aspect-correct —
built from the live framebuffer's own width:height ratio, clamped to the
available width if the screen is too narrow for it at full reserved
height. Since `scale` (one uniform float, see `LayoutEntry`) multiplies
both dimensions of an already-correct box, the editable box now *is* the
image, with no baked-in margin — there's nothing left for a resize to
enlarge except the picture itself. Added `clampRectToScreen()`, applied
to the resolved box every frame, so no amount of resizing (up to the
existing 8x cap) can push the box past the screen's own edges either —
the other half of "don't enlarge the entire container."
**Reason:** Direct bug report with screenshots.
**Expected improvement:** Dragging/resizing "Game Screen Size" now
visibly, proportionally resizes only the GBA picture. The box can never
exceed the screen's own bounds.
**Side effects:** Any `customLayout["gamescreen"]` entry saved by a
build before this pass had its `scale` computed against the old
(non-aspect-correct) base box; under the new, correct base box the same
stored `scale` number now produces a differently-sized result (in most
realistic cases, closer to correct/smaller, since the old base was
inflated). Position (`xFrac`/`yFrac`) is unaffected in the common case —
the new default box's *center* lands in the same place as the old one
whenever the screen is wide enough that width isn't the clamped
dimension, which is true for essentially every real device this app
targets. Worst case, the game screen's own "Reset" button in the
per-item editor bar fixes it in one tap.
**Verification:** No compiler in this sandbox, as every pass. Traced
`updateGameMatrix()`/`hitTestEditable()`/`onEditTouch()` by hand against
every one of the seven scenarios in the request (portrait, landscape,
grid on/off at each size, snapping, plain resize, Stretch to Fit,
Reset/Cancel/Done) — see KNOWN_LIMITATIONS.md for what's still genuinely
untested (no device or build in this sandbox). Ran a corrected,
comment/string/template-aware brace-paren-bracket scanner (see item 5
below — the previous version of this same scanner had its own bug,
found and fixed this pass) over the whole file: balanced, 0 remaining
depth. Confirmed every other source file (`LinkMultiplayer.kt`,
`EmulatorEngine.kt`, `RomBrowserActivity.kt`, `RomZipUtils.kt`,
`SharedUi.kt`, `mgba_jni.c`, `AndroidManifest.xml`) is byte-identical to
the input zip — nothing multiplayer/emulator-core related was touched.

## 2. Stretch to Fit stretching the whole UI / growing the black area vertically

**Category:** Bug fix
**Files modified:** `MainActivity.kt`
**Problem:** Same root cause as item 1 — Stretch to Fit filled
`gameScreenRect`, which *was* the oversized, non-aspect box. Any resize
applied to that shared box (even from the ordinary, non-stretch editing
flow) affected what Stretch to Fit then filled too, which is what read
as it affecting more than just the game picture.
**Solution:** Stretch to Fit is now a genuinely separate, fixed
computation, independent of any saved `"gamescreen"` `customLayout`
entry: the box is pinned to exactly `(0, 0, sw, sh * gameScreenFraction)`
— full available width, the same reserved height the app has always
used — every time, and the bitmap is scaled non-uniformly to fill that
exactly (unchanged: distorting the 3:2 aspect on purpose is what
"stretch" means). Because the reserved height is untouched by this,
turning Stretch to Fit on can't grow the black area vertically; because
nothing outside `gameScreenRect`/`gameMatrix` is touched, it can't
affect any other part of the UI. `hitTestEditable()` now skips
`"gamescreen"` entirely while Stretch to Fit is on — the box is fixed
and fills the width by definition, so there's nothing left to drag or
resize until it's turned back off (attempting to anyway, e.g. if it was
selected right before the setting was toggled from Settings without
leaving the editor, is a guarded no-op in `onEditTouch()` rather than a
silent edit to a `customLayout` entry that mode never reads).
**Reason:** Direct bug report.
**Expected improvement:** Stretch to Fit now does exactly what its name
says — fills the available width at the standard reserved height — and
nothing else on screen moves or resizes when it's toggled.
**Side effects:** None noted.
**Verification:** Same as item 1 (shared fix, same function).

## 3. Removed the top-left fast-forward speed indicator

**Category:** Bug fix / cleanup (requested removal)
**Files modified:** `MainActivity.kt`
**Problem:** `drawFfOverlay()` drew `"⏩ Nx"` at a fixed top-left canvas
position whenever fast-forward was active — a separate, always-on-top
element from the on-*button* speed text Thirty-seventh pass already
removed (see that pass's FEATURES_ADDED.md entry) for the same
complaint. This one was apparently never noticed until now — it's not
attached to any button, so removing the button-face text didn't affect
it.
**Solution:** Deleted `drawFfOverlay()`, its dedicated `hudPaint`, and
the `if (fastForwardActive) drawFfOverlay(canvas)` call site in
`renderFrame()`. `formatSpeed()` (which it used to build its text) is
still used elsewhere — the Misc settings speed field and the
hold-for-speed-slider readout — and stays.
**Reason:** Requested directly, matching the attached screenshots (all
three show it).
**Expected improvement:** Nothing draws in the top-left corner anymore.
Fast-forward's own on/off state is still visible via the »-button's
existing color/fill change, same as it's been since Thirty-seventh pass.
**Side effects:** None — this was a pure rendering call with no other
state tied to it. The separate, *opt-in* Settings → Misc → "Show
performance overlay (FPS / audio underruns)" readout (top-right, off by
default, added deliberately as a diagnostic tool — see
KNOWN_LIMITATIONS.md's earlier passes) is a different feature entirely
and was left exactly as-is: it isn't top-left, isn't on by default, and
isn't what any of the three attached screenshots show.
**Verification:** Grepped the whole file for both removed identifiers
afterward — zero remaining references.

## 4. Editor alignment grid — Grid Size / Show Grid / Snap to Grid

**Category:** Feature
**Files modified:** `MainActivity.kt`
**What changed:** A new "Grid" entry on the editor's top bar opens a
Grid Settings dialog: **Grid Size** (4×4 / 8×8 / 16×16 / 32×32 preset
radio, matching every other size-like setting already in this app),
**Show Grid** (draws the alignment lines while the editor is open —
`drawGrid()`, called from `drawEditOverlay()` regardless of whether
anything is currently selected), and **Snap to Grid** (drag/resize
round to the nearest grid line/cell — `snapPositionToGrid()` for
position, `snapScaleToGrid()` for size, both called from
`onEditTouch()`'s `ACTION_MOVE` only when the toggle is on). Applies to
every draggable/resizable control, the game screen included (while
Stretch to Fit is off — see item 2). All three settings persist
(`PREF_GRID_SIZE`/`PREF_SHOW_GRID`/`PREF_SNAP_GRID`) independently of
`customLayout`/`removedButtons`/`addedExtraButtons` — toggling them can
never touch, and is never touched by, anything already saved.
**Reason:** Requested directly — coarse-or-precise grid divisions,
snapping on move/resize, visibility toggle, snap toggle, snap
predictable enough that nothing ends up "slightly off-grid."
**Design note (size snapping):** Every entry resizes through one
uniform `scale` float, so buttons and the game screen never distort —
snapping width and height *independently* would either break that or
leave one of the two dimensions off-grid regardless. `snapScaleToGrid()`
snaps the element's **width** to a whole number of grid cells and
derives `scale` from that; height then follows exactly (same scale,
fixed aspect) rather than being separately forced onto its own line.
One predictable rule for every control, not a different one depending
on what's selected.
**Side effects:** None to existing layouts — see persistence note above.
**Verification:** No compiler in this sandbox, as every pass. Traced
`showGridSettingsDialog()` against the existing `showLayoutsSettings()`
it was modeled on (same `dlgRadioGroup()`/`dlgAddOpt()` helpers,
confirmed still present and unchanged in `SharedUi.kt`).

## 5. Customization UI: removed emoji, relabeled per the request, fixed a diagnostic-script bug

**Category:** Cleanup / bug fix (own tooling)
**Files modified:** `MainActivity.kt`
**What changed:** Every emoji/dingbat glyph in the editor's own UI is
gone, replaced with the plain labels requested: top bar now reads Edit
Layout / Add Control / Reset Controls (was "Reset All") / Grid (new) /
Cancel / Done. The per-item bar (shown when a control is selected) is
restructured from one long horizontal strip of `Size±`/`Op±` chips into
three stacked rows so the full requested labels fit: control name + Lock
state (now text, "Locked"/"Unlocked", not a lock emoji) + Reset; then
"Game Screen Size" or "Control Size" (contextual, set in
`onEditTouch()`'s `ACTION_DOWN`) with `-`/`+`; then "Control Opacity"
with `-`/`+` — hidden entirely when the game screen is selected, since
opacity has no effect on the live game image (nothing reads a
`"gamescreen"` `alphaOverride`) and showing a control that visibly does
nothing would be worse than not showing it. The Input-settings button
that opens the editor ("🖊 Edit Button Layout…") and a handful of
directly editor-adjacent toasts/dialogs (reset confirmation,
remove-control menu/toast) were cleaned the same way. Left alone, as
genuinely unrelated: gameplay button glyphs (Quick Save/Load/Screenshot
faces), and Settings-screen titles/rows outside the editor itself
(Memory Viewer, Storage, Advanced, the Link-Connected dialog) — none of
those are part of "Customization UI" and changing them wasn't asked for.
**Also fixed this pass:** the whole-file balance-checker script used to
verify item 1/2 above had its own bug — `${...}` string-template
expressions weren't correctly returning to "real code" parsing after
the `${`, so a closing `}` inside one was miscounted as string content
instead of a real brace. Confirmed by running the broken version against
the *original, unmodified* input file first (same false positive there,
proving it was the checker, not the code) before fixing it and
re-confirming both files balance cleanly. One-off diagnostic only, same
as Thirty-eighth pass's own comment-aware scanner — not added as a
standing part of this project.
**Reason:** Requested directly ("Do not use emojis," specific label
list, working Reset/Cancel/Done).
**Side effects:** None functional — text/visibility only.
**Verification:** Grepped the whole file for every emoji character that
was removed — zero remaining in the editor UI. Diffed the function
signature list against the original file: exactly the five functions
added (`clampRectToScreen`, `snapPositionToGrid`, `snapScaleToGrid`,
`showGridSettingsDialog`, `drawGrid`) and the one removed
(`drawFfOverlay`) — nothing else moved or duplicated.

---



Scope note: one real bug, `MainActivity.kt` only, prompted by an actual
CI build-log attachment (run 1575 — Thirty-seventh pass's zip failed
`compileReleaseKotlin`, so nothing installable came out of it, same as
Thirty-sixth pass's own build-log-prompted fix).

## 1. Fixed a duplicated comment-opener that swallowed the rest of the file

**Category:** Bug fix (build-breaking)
**Files modified:** `MainActivity.kt`
**Problem:** `applyLayoutSettings()`'s doc comment ended up with two
consecutive `/**` openers — the original, plus a new one added on top of
it by mistake during the previous pass's edit, whose `old_str` had
matched starting one line after the existing opener instead of including
it. Kotlin block comments nest, so the one `*/` already present only
closed the inner level; the outer comment stayed open through the rest
of the file.
**Solution:** Removed the duplicate `/**`, leaving the single, correctly
paired opener/closer the comment always should have had.
**Reason:** The user attached the real GitHub Actions build log —
`e: ... Missing '}'`, `e: ... Unclosed comment`, and a cascade of
`Unresolved reference` errors for real functions (`stopLink`,
`drawLinkStatus`, `drawFpsOverlay`, `showLinkRemoteDialog`,
`showLinkLocalDialog`, `showSaveStateSlotDialog`, `applyLayoutSettings`
itself) whose definitions had all been swallowed into the phantom
comment.
**Expected improvement:** `assembleRelease` should compile again — every
error in the log traced back to this one root cause.
**Side effects:** None — removing a stray duplicate comment marker has
no behavioral effect of its own.
**Verification:** No compiler in this sandbox, as every pass — but this
pass's verification method changed as a direct result of this bug: the
usual whole-file `{`/`}` character count (this project's standing
smoke test every pass) cannot detect an unclosed comment at all, since
comment markers don't add or remove brace characters — it reported
721/721 (balanced) both before and after this exact bug was live. Wrote
a proper comment-aware scanner instead (tracks Kotlin's nested `/* */`
depth, skips `//` line comments and string contents) to find precisely
where the phantom comment began, confirmed a clean 0 final depth after
the fix, and confirmed all seven functions the build log reported as
unresolved have exactly one real definition each. See
KNOWN_LIMITATIONS.md for what this means for every earlier pass's own
"balance checked" claims.

---

# CHANGELOG — Thirty-seventh pass

Six things reported together: the hold-for-speed-slider request repeated
(not built two passes ago), the game screen still not actually
resizable, a Z-order bug hiding the editor behind Settings, a request to
remove Fullscreen now that resize is real, 4x fast-forward feel/sound,
and Max frame skips flickering/flashing white. The white-flash one was a
real, confirmed bug — see BUGS_FIXED.md. Everything else here.

## 1. Fast-forward hold-for-speed-slider

**Category:** Feature (previously deferred, now built)
**Files modified:** `MainActivity.kt`
**What changed:** The »/fast-forward button no longer toggles the instant
it's touched. `ACTION_DOWN` now arms a delayed Runnable
(`ffLongPressPending`, same shape as the editor's own
`editLongPressPending`); if `ACTION_UP` lands on the button before the
long-press timeout, that Runnable is cancelled and fast-forward toggles
normally (a real tap). If the timeout fires first, `showFastForwardSpeedSlider()`
opens instead — a slider (0.5–16×, half-speed steps) with a live-updating
readout and a Done button, writing the same `fastForwardSpeed`/
`PREF_FF_SPEED` the Misc settings text field already does. Also removed
the "» 4×" speed-text that used to appear on the button while active —
the existing color/fill change already shows on/off state; the text was
a separate indicator reported as unwanted.
**Reason:** Requested directly (twice — see Thirty-fifth pass's own
deferral note).
**Side effects:** None to the toggle behavior itself for a normal tap —
still instant, just resolved on `ACTION_UP` instead of `ACTION_DOWN` now.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the Runnable is cancelled via
`mainHandler.removeCallbacks()` on both the tap-resolves-first path and
the generic `else` branch (`ACTION_CANCEL`/stray events) other touch
state already gets cleared on, not just the happy path.

## 2. Game screen is now actually resizable/draggable

**Category:** Feature (completing something claimed finished before it
was)
**Files modified:** `MainActivity.kt`
**What changed:** The game screen is now a real participant in the same
editor every button already used, through the same generic id-keyed
machinery (`resolvedRect()`, `editRectFor()`, `hitTestEditable()`,
`labelFor()`, `resetSingleButton()`) rather than a parallel system of its
own — see the `gameScreenRect` field comment for the full reasoning.
`updateGameMatrix()` resolves `"gamescreen"`'s rect the same way any
button resolves its own, then fits/positions the GBA image within
*that* rect instead of a fixed top-left region.
`buildControlLayout()` now calls `updateGameMatrix()` internally at its
own end (removing three now-redundant external call-site pairs), so
`gameScreenRect` — and the actual rendered image — stays in sync with
every layout change, live drag/resize included, without threading a
second call through every one of `buildControlLayout`'s own call sites
individually. Long-press-to-remove is explicitly guarded against
`"gamescreen"` (see `showRemoveButtonMenu()`) — there's nothing sensible
"remove the game screen" would mean.
**Reason:** Requested directly; the previous pass had only fixed the
*navigation* into the editor, not made the screen draggable/resizable
once there (flagged as deferred at the time).
**Side effects:** None to button behavior — buttons' own resolution and
editing are completely unchanged, this only adds a new id alongside them
sharing the same machinery.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed `editRectFor()`/`hitTestEditable()`/`drawEditOverlay()`
(the last one already generic via `editRectFor()`, needed no changes at
all) all correctly reach `gameScreenRect` for the new id; confirmed
`isButtonVisible("gamescreen")` resolves true by default (not in
`extraControlIds`, so it falls to the "not in `removedButtons`" branch,
and the long-press guard stops it from ever landing there); confirmed
`saveCustomLayout()`/`loadCustomLayout()` needed zero changes since they
already serialize the whole `customLayout` map generically by key.

## 3. Fixed: editor was invisible until Settings was closed first

**Category:** Bug fix
**Files modified:** `MainActivity.kt`
**Problem:** Tapping "Screen size" dismissed the Video popup and called
`enterEditMode()`, but never touched `settingsMenuOverlay` — the
Settings screen *underneath* that popup, a separate full-screen opaque
overlay — which stayed covering the editor that had, in fact, already
started right underneath it.
**Solution:** `settingsMenuOverlay.visibility = View.GONE` added
alongside the existing `dialog?.dismiss()`.
**Reason:** Reported directly ("you have to closed setting first to see
screen size or screen button customization").
**Expected improvement:** The editor (and its existing toolbar — Add
control, per-button Reset, Done/Discard — all of which likely read as
missing entirely while this bug made the whole screen unreachable) should
now actually be visible and usable the first time.
**Verification:** No compiler or device in this sandbox. Confirmed
`settingsMenuOverlay.visibility = View.GONE` is the exact same call its
own "✕ Close" button already uses elsewhere in this file, not a new,
unproven way of hiding it.

## 4. Fullscreen removed

**Category:** UX change (requested removal)
**Files modified:** `MainActivity.kt`
**What changed:** `fullscreenMode`, `CTRL_FRAC_FULL`, `PREF_FULLSCREEN`,
and every branch conditioned on them removed entirely — not hidden,
actually deleted (the controls-background rect now always draws; idle
alpha no longer has a fullscreen-only dim). The "Reset settings" handler
(Misc) also gained `stretchToFit`/`maxFrameSkips`/`linearFilterEnabled`,
which turned out to have been missing from it since they were added two
passes ago — an unrelated gap noticed while removing `fullscreenMode`
from that same list.
**Reason:** Requested directly, now that screen resize (item 2) is a
real substitute for what Fullscreen used to be the only way to get.
**Side effects:** Anyone with Fullscreen previously turned on will see
the game screen back at its plain default size after updating — a one-time
resize via the editor gets back to (or past) what Fullscreen used to give
directly.
**Verification:** No compiler or device in this sandbox. Grepped for
every remaining reference to all three removed symbols after the edit —
none left outside this pass's own explanatory comments.

## 5. Fast-forward at 4x and Max frame skips (My Boy comparison)

**Category:** Investigated / partially fixed
**Files modified:** `MainActivity.kt` (Max frame skips only — see
BUGS_FIXED.md for that one; nothing changed for fast-forward speed/audio
itself this pass)
**What happened:** Max frame skips' flickering was a real, confirmed bug
— fixed, see BUGS_FIXED.md. Fast-forward "4x is slow, sound a bit bad"
is the same territory investigated two passes ago (that pass's items 3–4),
now with a specific number attached rather than resolved further — see
KNOWN_LIMITATIONS.md for why this wasn't guessed at a third time either.

---

# CHANGELOG — Thirty-sixth pass

Scope note: one real bug, `MainActivity.kt` only, prompted by an actual
CI build-log attachment (run 1565 — Thirty-fifth pass's zip failed
`compileReleaseKotlin`, so nothing installable came out of it).

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (build-breaking)
**Files modified:** `MainActivity.kt`
**Problem:** `linearFilterEnabled` (Thirty-fifth pass's Linear filtering
feature) was read/written in four places but never declared — an
unchecked assumption that it already existed as a field alongside
`stretchToFit`/`maxFrameSkips`, based on seeing its *name* in a grep
result (a pref-load line and a doc comment) rather than an actual
declaration line for it specifically.
**Solution:** Added `@Volatile private var linearFilterEnabled = false`
next to `stretchToFit`/`maxFrameSkips`, matching their declaration style
exactly. No other change needed — every read/write site already had the
right shape for a plain `Boolean` field.
**Reason:** The user attached the actual GitHub Actions build log
showing `compileReleaseKotlin FAILED` with four `Unresolved reference:
linearFilterEnabled` errors, exact file/line/column for each.
**Expected improvement:** `assembleRelease` should compile again — this
was the only reported error in the log, and all four instances shared
the one root cause.
**Side effects:** None — a missing declaration doesn't have partial or
alternate behavior to preserve; adding it just makes the already-written
call sites work as originally intended.
**Verification:** No compiler in this sandbox, as every pass — verified
by reading the exact four file/line/column locations the real compiler
reported and confirming each now resolves to the new declaration, rather
than a fresh guess; whole-file brace/paren balance checked after the
edit (708 open/close braces, 3113 open/close parens).

---

# CHANGELOG — Thirty-fifth pass

Five screenshots this pass, comparing this app's Video settings against a
reference emulator's, plus a fullscreen crash report, a layout-reset
report, and the Turbo A/B size complaint continuing. Large pass — see
FILE_CHANGES.md for the full diff and KNOWN_LIMITATIONS.md for what's
deferred and why.

## 1. Video settings rebuilt to match the reference screenshots

**Category:** Feature + UX rework
**Files modified:** `MainActivity.kt`
**What changed:** `showVideoSettings()` rebuilt as a plain list (title +
optional gray subtitle per row, dividers) instead of one form with
everything crammed in. Two real, previously-unreachable features turned
out to already exist as fields/logic with zero UI wired to them —
**Stretch to fit screen** (`stretchToFit`, already implemented in
`updateGameMatrix()`) and **Linear filtering** (`linearFilterEnabled`,
had a field and a pref but nothing ever read it — the actual `drawBitmap`
call passed a plain `null` Paint, filtering permanently off regardless of
the setting; now uses a real `gamePaint` whose `isFilterBitmap` follows
it) — both just needed a checkbox. **Max frame skips** was the same
halfway state one level deeper: the field/pref/doc-comment describing the
intended behavior already existed, but the referenced
`maybeSkipRenderThisFrame()` didn't — implemented for real this pass (see
item 2). **Screen orientation** moved from an inline 5-option radio group
into its own popup (`showScreenOrientationDialog()`), matching the
reference's own popup styling — applies on tap, no separate Save. **Enable
OpenGL** and **GLSL Shader**, also in the reference, are deliberately
*not* included — this app's renderer has only ever been Canvas/
SurfaceView; there's no OpenGL path to switch to and no shader system,
and a checkbox that doesn't change anything would be worse than no
checkbox. **Fullscreen** (the previous screen's own checkbox) was kept
despite not appearing in the reference list — see item 4, it's not
redundant yet.
**Reason:** Requested directly, reference screenshots provided.
**Side effects:** None for existing saved prefs — `PREF_STRETCH`,
`PREF_MAX_SKIPS`, `PREF_LINEAR_FILTER` were already being read on every
launch, just never written to by anything in the UI; this pass adds the
first UI that can actually write them.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed all three "phantom" fields
(`stretchToFit`/`maxFrameSkips`/`linearFilterEnabled`) by grepping for
every reference to each, not just the one that prompted the search;
confirmed `gamePaint`'s single shared instance is mutated in place
(`updateLinearFilterPaint()`) rather than allocating a fresh Paint per
frame; whole-file brace/paren balance checked after all edits.

## 2. Max frame skips — implemented for real, wired into the normal-speed loop

**Category:** Feature (completing a half-built one)
**Files modified:** `MainActivity.kt`
**What changed:** The normal (non-fast-forward, `framesToRun == 1`)
branch of the game loop now tracks whether the *previous* iteration took
longer than one frame's budget (~16.67ms) and, if so and skip budget
remains (`consecutiveFrameSkips < maxFrameSkips`), calls
`nativeRunFrame(null)` instead of `nativeRunFrame(backBmp)` for this
frame — skipping the pixel blit only, not emulation or audio, reusing
the exact same null-bitmap fast path fast-forward's own sub-frame loop
already relies on. The buffer-publish step after it is unconditional
either way, so a skipped frame just leaves the previous frame on screen
for one more render cycle rather than corrupting anything.
**Reason:** Requested directly ("add max frame skip features can be set
to 0 to 10").
**Expected improvement:** On a slower device, normal (1x) play can drop
the expensive blit for a few frames to catch back up, rather than only
ever having that option during fast-forward.
**Side effects:** None at the default (0 — behavior identical to every
previous pass, `behindSchedule` is irrelevant when `maxFrameSkips` is 0
since the `&&` short-circuits). `consecutiveFrameSkips`/
`lastFrameLoopStartNs` reset every time the loop (re)starts, alongside
the existing `ffFrameAccumulator` reset, so stale state can't leak into
a fresh game session.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed the buffer-publish `synchronized` block already runs
unconditionally regardless of whether a blit happened (checked its
actual code rather than assuming), which is what makes "skip the blit"
safe rather than needing its own separate handling; confirmed the skip
logic is scoped to `framesToRun == 1` only, so it can't interact with
fast-forward's own, differently-motivated skip-blit logic in the batch
branch.

## 3. Turbo A/B size — raised again

**Category:** Fix (second round of the same complaint)
**Files modified:** `MainActivity.kt`
**What changed:** Default size (`tSz`) raised 0.55x → 0.75x of a normal
A/B button; the resize scale cap (shared by every button, both the
toolbar +/- and the pinch gesture) raised 4x → 8x.
**Reason:** Reported as still too limited after an earlier pass had
already raised the cap once (2.5x → 4x) for this same complaint.
**Expected improvement:** Turbo A/B can now reach roughly 6x their old
default size (0.75 × 8) — comfortably past a normal A/B button's size if
wanted, rather than topping out just short of one.
**Side effects:** The higher cap applies to every button, not just Turbo
A/B — anyone resizing anything can now go bigger than before. Still
bounded, not literally unlimited.
**Verification:** No compiler or device in this sandbox. Confirmed both
`coerceIn` call sites (toolbar +/- and the pinch-resize gesture) were
updated together, not just one.

## 4. Fullscreen crash and lost layout edits — not fixed, crash log requested

**Category:** Investigated, not fixed
**Files modified:** none
**What happened:** Read through `applyLayoutSettings()`,
`buildControlLayout()`, and every `fullscreenMode`-conditional branch
looking for a crash-prone path. Didn't find one with high enough
confidence to act on. Separately, confirmed *why* a crash would also
explain "all the buttons I changed are gone": `saveCustomLayout()` is
only ever called from the edit-mode exit handler (`exitEditMode(save =
true)`) — layout edits aren't persisted until that explicit save, so a
crash before reaching it would lose whatever was mid-edit with no
separate bug required to explain that part.
**Why no code change:** No specific line to point at. This app already
has a built-in crash logger (see "Copy crash log" in the quick game
menu) — that's real data instead of another guess, and the efficient way
to actually find this one.

---

# CHANGELOG — Thirty-fourth pass

Four things reported in one message: cutout black area still present after
last pass, Turbo A/B feeling slow with an unwanted toggle, and fast-forward
described as laggy with weird sound. Two of these got real code changes
this pass; two got investigated and explained instead of guessed at a
third/second time — see each item and KNOWN_LIMITATIONS.md.

## 1. Turbo A/B moved off a toggle, sped up, labels fixed

**Category:** UX rework + fix (existing feature, not new)
**Files modified:** `MainActivity.kt`
**What changed:** The "⚡ Turbo A / Turbo B buttons" Settings checkbox
(added both together, all-or-nothing) is gone. `"ta"`/`"tb"` moved into
`extraControlIds`, the same individually opt-in-via-"+ Add control" system
`"abturbo"`/`"ab"`/etc. already used — each can now be added, positioned,
and removed independently. Their on-button label changed from `"T"` (both
buttons showed the identical letter, no way to tell Turbo A from Turbo B
by looking) to `"A"`/`"B"` respectively, matching how `"abturbo"` already
reuses its equivalent normal button's letter with red signaling "turbo."
`turboHalfPeriodMs` halved, 66ms → 30ms (≈7-8/sec → ≈16-17/sec).
**Reason:** Requested directly — toggle removal, label confusion, and
"its slow" were all named explicitly.
**Expected improvement:** Add just the one you want; tell them apart at a
glance; feels like an actual turbo button rather than a slow repeat.
**Side effects:** Anyone who'd previously turned the old checkbox on will
find Turbo A/B gone from their layout after updating (the old pref is
simply no longer read) — needs re-adding via "+ Add control", once, same
as adopting any other newly-available extra. Not a data-loss concern, no
saves/states involved, just a one-time re-add.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `addButton()` already checks
`isButtonVisible()` internally for every id (checked its implementation
directly rather than assuming), so dropping the `if (turboButtonsEnabled)`
wrapper and calling it unconditionally is exactly the same pattern
`"abturbo"` already used successfully, not a new one; confirmed
`allControlIds()`'s special-cased `if (turboButtonsEnabled)` branch is
now fully redundant with `ids += extraControlIds` and removed rather than
left dead; confirmed `labelFor()` already had `"ta" -> "Turbo A"`/
`"tb" -> "Turbo B"` mapped (so the "+ Add control" menu needed no changes
of its own to show them correctly); confirmed removing the checkbox left
`showInputSettings()`'s local `prefs` variable unused and removed it too,
rather than leaving dead code; whole-file brace/paren balance checked
after all edits.

## 2. Fast-forward audio: better decimation filter

**Category:** Fix (audio quality during fast-forward)
**Files modified:** `MainActivity.kt`
**What changed:** `decimateForFastForward()` used plain box-filter
averaging (each output sample the equal-weighted mean of `factor` input
samples) — the function's own prior doc comment already called this "a
cheap stand-in for a proper low-pass filter." Replaced with the standard
filter-then-downsample shape: a one-pole low-pass runs once across the
whole accumulated block, then every `factor`th filtered sample is kept,
rather than trying to make the averaging do both jobs.
**Reason:** Reported as "sound is weird" alongside the fast-forward lag
complaint.
**Expected improvement:** Less aliasing (harsh/grainy high-frequency
content folding back down) and less of the muffled quality a box filter's
weak, non-flat passband adds — a cleaner-sounding pitch-up. The pitch-up
itself is unchanged and not a bug: speeding up audio this way inherently
raises its pitch (the "chipmunk" effect), same as it would on a tape
played fast, and this function was never trying to hide that.
**Side effects:** None expected for pacing/timing — `outPairs` (what
actually governs how much audio gets written and how long `writePcm()`
blocks for) is computed exactly the same way as before, `accumPairs /
factor`; only how each output sample's *value* is computed changed. CPU
cost is in the same complexity class as the box average it replaces (one
multiply-add per input sample either way), so this shouldn't make the
reported laggy feeling any worse.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the filter runs continuously across
`accumPairs` samples rather than being reset per output (a continuous
IIR state is what makes it an actual low-pass rather than something more
like independent per-block averages again); confirmed the `alpha =
2/(factor+1)` conversion is a standard, well-established period-to-EMA
formula rather than an arbitrary constant; confirmed the caller
(`accumPairs > 0` before calling) already guarantees at least one sample
exists before the function reads `ffAccumBuffer[0]`/`[1]` to seed the
filter state; confirmed the `factor <= 1` early-return path (normal,
non-fast-forward speeds) is completely untouched.

## 3. Camera-cutout black area — not touched again this pass

**Category:** Investigated, not fixed a third time
**Files modified:** none
**What happened:** Still reported after Thirty-third pass's `ALWAYS` mode
upgrade. Read back through how the game screen itself is sized
(`updateGameMatrix()`) rather than guessing at the cutout mode a third
time, and found a real, separate, and quite plausible explanation: the
GBA's native 240×160 (3:2) image is scaled to *fit inside* the available
area preserving aspect ratio (`scale = min(sw/240, gameH/160)`), then
centered — on a modern phone's much wider-than-3:2 landscape screen, the
width term is essentially never the limit, so there's a real, expected,
correctly-computed black margin on the left and right of the game image
(pillarboxing) on every device with this app, cutout or not. If the
phone's cutout happens to sit within that margin — plausible, since
cutouts are usually near an edge and so is the pillarbox — "a lot of
black screen on camera notch area" could describe *that*, not a
cutout-handling gap at all, in which case neither this pass's nor last
pass's cutout-mode changes could ever have looked any different, working
correctly or not.
**Why no code change:** This is a real, different hypothesis from what
the last two passes acted on, not confirmed — and if it's right, there
isn't an obvious fix that doesn't mean stretching or cropping the actual
game image, both worse tradeoffs than the pillarboxing itself. Guessing a
third time on a description this general risked another cycle spent on
the wrong target. See KNOWN_LIMITATIONS.md for what would actually
resolve this.

## 4. Fast-forward "laggy" — investigated, no bug found

**Category:** Investigated, not fixed
**Files modified:** none
**What happened:** Read back through the entire fast-forward path in
`startGameLoop()` (the audio-write-blocking frame pacer, the batched
sub-frame loop, the skip-blit optimization for hidden sub-frames) and
`nativeRunFrame()`'s null-bitmap fast path in `mgba_jni.c` looking for a
concrete inefficiency. Didn't find one — both are already tuned about as
tightly as this design allows (documented across several earlier passes'
own FIX comments already in this code). The audio-blocking pacer's
correctness assumption is that emulating `factor` sub-frames takes *less*
wall-clock time than playing `factor` frames' worth of audio would at 1x
— true with CPU to spare, but if a device's CPU can't emulate faster than
that at the chosen fast-forward multiplier, the same blocking design that
paces normal 1x play smoothly will instead show up as real stutter,
because emulation itself becomes the bottleneck rather than the audio
buffer. Genuinely can't tell from a read-through alone whether that's
what's happening here, or something else — no profiler, no device.
**Why no code change:** No specific bug to point at and fix. See
KNOWN_LIMITATIONS.md for what would help pin this down further.

---

# CHANGELOG — Thirty-third pass

Two unrelated requests this pass: a reported black area around the
camera-cutout notch, and a live memory viewer (full description in
FEATURES_ADDED.md; this entry covers its mechanics too).

## 1. Camera-cutout black area — strengthened, not confirmed fixed

**Category:** Fix attempt (display cutout handling)
**Files modified:** `MainActivity.kt`, `RomBrowserActivity.kt`
**What changed:** MainActivity's existing cutout handling (added an
earlier pass) upgraded from `LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES`
to `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS` on API 30+ (falling back to the
previous `SHORT_EDGES` on API 28–29, where `ALWAYS` doesn't exist).
`ALWAYS` is a strict superset of `SHORT_EDGES` — content is unconditionally
allowed into the cutout area, with none of `SHORT_EDGES`'s own conditions
— so this can only extend the drawable area further, never shrink it.
Separately, and more confidently: RomBrowserActivity — new this overall
changeset, so it never had *any* cutout handling — got the same
ALWAYS/SHORT_EDGES pair MainActivity now has, rather than being left on
the platform default.
**Reason:** Reported directly: "a lot of black screen on camera notch
area."
**Expected improvement:** Less unused black area around the cutout on
MainActivity; RomBrowserActivity should now handle it at all, where
before this pass it did nothing.
**Side effects:** None expected — `ALWAYS` only ever grants more drawable
area, never less, and the two Activities' handling is now consistent
with each other.
**Verification:** No compiler or device in this sandbox, as every pass —
and this one carries a genuine, stated uncertainty on top of that usual
caveat: `ALWAYS` is a real, correct strengthening of the cutout mode
regardless, confirmed against current Android documentation, but whether
it's the *complete* explanation for "a lot of black screen" (as opposed
to, say, aspect-ratio letterboxing being mistaken for it, or the
RomBrowserActivity gap being the larger part of what was actually seen)
isn't something this read-through can settle without a screenshot or a
device to compare against. See KNOWN_LIMITATIONS.md.

## 2. Live memory viewer

**Category:** Feature (see FEATURES_ADDED.md for the full description)
**Files modified:** `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`
**What changed:** New `nativeReadMemory()` (native) /
`EmulatorEngine.nativeReadMemory()` (Kotlin) reads live core memory via
`mCore.busRead8()`; a new overlay displays it as a hex dump, reachable
from the quick game menu's new "Memory" item.
**Reason:** Requested directly.
**Expected improvement:** Can now watch live GBA memory (party/battle
data, or anything else) change turn by turn without leaving the running
game.
**Side effects:** None to existing features — purely additive; the new
`busRead8()` calls happen only while the overlay is open and are held
under the same `g_core_mutex` every other core access already uses, so
they can't race with `nativeRunFrame()` on the game thread.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `busRead8`/`busRead16`/`busRead32` are real,
current `mCore` function-pointer members (checked against mGBA's own
`src/core/cheats.c`, which reads memory through the identical
`core->busRead8(core, address)` call for its cheat system) rather than
assumed from memory of the API; confirmed every `g_core` access in the
new function is inside the lock, matching this file's existing
discipline; confirmed the quick game menu's new item was appended at the
end of the list (not inserted in the middle) so no other item's numeric
dispatch `when` case needed renumbering; whole-file brace/paren balance
checked on every touched file after all edits (`MainActivity.kt` 689/689
braces, `mgba_jni.c` 80/80 braces, all parens balanced too).

---

# CHANGELOG — Thirty-second pass

Follow-up on Thirty-first pass's delivery: remove the Root button, and
pushed back on the no-rotation compromise with a concrete counter-example
(My Boy's own file manager: Portrait for ROM selection, a different,
Settings-configurable rotation for gameplay). Full description in
FEATURES_ADDED.md; this entry covers the mechanics.

## 1. ROM browser split into its own Activity, statically locked to Portrait

**Category:** Feature/architecture (ROM browser presentation)
**Files modified:** `AndroidManifest.xml`, `MainActivity.kt`; new
`RomBrowserActivity.kt`, `RomZipUtils.kt`, `SharedUi.kt`.
**What changed:** ROM selection moved from an overlay inside
MainActivity's window to a separate `RomBrowserActivity`, declared
`android:screenOrientation="portrait"` in the manifest. No
`requestedOrientation` call exists anywhere in the new Activity.
MainActivity's role reduced to launching it and handling the result.
**Reason:** Requested directly, with a specific real-world counter-
example (My Boy) that the previous panel-only compromise didn't match.
**Expected improvement:** The actual Portrait-file-manager /
independently-oriented-gameplay behavior asked for, matching the
reference app, without the two previous attempts' runtime-rotation
crash risk — see below.
**Side effects:** `RomBrowserActivity` is a real screen transition now
(new Activity, not an overlay) — a system Activity transition animation
will play opening/closing it, where before this was instant (an overlay
visibility toggle). Minor visual change, not expected to matter, but
different from before. Back button behavior changed: it now navigates up
a folder before exiting, where previously there was no back-stack
participation for this screen at all (it was an overlay, not an
Activity) — see FEATURES_ADDED.md.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: grepped the entire codebase for every symbol that
should have moved (`romTreeUri`, `romTreePicker`, `PREF_ROMS_TREE_URI`,
`romBrowserStack`, `buildRomBrowser`, `zipContainsGba`,
`ensureBroadFileAccess`, etc.) to confirm no stray references were left
calling something that no longer exists in `MainActivity.kt`; separately
checked every import added or left over from earlier passes
(`android.os.Environment`, `android.provider.Settings`,
`java.io.BufferedInputStream`) for real usage beyond the import line
itself, removing three that had none; checked every import in all three
new files the same way, all used; six now-inaccurate comments (see
FILE_CHANGES.md for the full list) caught and rewritten rather than left
to describe code that no longer exists; whole-file brace/paren balance
checked on `MainActivity.kt` (652/652 braces, 2777/2777 parens) and each
new file individually (`RomBrowserActivity.kt`: 70/70, 259/259;
`RomZipUtils.kt`: 6/6, 29/29; `SharedUi.kt`: 2/2, 23/23); manifest XML
parsed successfully; confirmed the new/pristine file lists differ by
exactly the 3 new files, nothing else added or removed.

---

# CHANGELOG — Thirty-first pass

Follow-up feedback on Thirtieth pass's ROM browser delivery: wanted real
free navigation instead of the existing SAF-tree-scoped browsing, a
Portrait-only file manager screen, and mentioned the menus/browser
feeling laggy. Full description of what got built in FEATURES_ADDED.md;
this entry covers the mechanics and the two things that were *not* just
built as literally requested.

## 1. Free-roam file manager, replacing the SAF tree picker

**Category:** Feature (ROM browser navigation model)
**Files modified:** `AndroidManifest.xml`, `MainActivity.kt`
**What changed:** ROM browsing moved from `DocumentFile` over one
SAF-granted folder tree to plain `java.io.File` over all of local shared
storage, gated by a new permission flow (`ensureBroadFileAccess()` —
`MANAGE_EXTERNAL_STORAGE` on API 30+, `READ_EXTERNAL_STORAGE` below
that). See FEATURES_ADDED.md for the full file list.
**Reason:** Requested directly.
**Expected improvement:** Navigate anywhere in local storage without a
separate folder-granting step; likely addresses the reported "laggy
menus/file manager" too, since folder listing is now a direct local read
instead of a Binder call into Android's storage provider — the
pre-existing code already flagged that call as a possible lag source
(see the block comment above `openRomBrowserAtRoot()` before this pass,
and KNOWN_LIMITATIONS.md).
**Side effects:** First launch (or first ROM load after an update) now
prompts for a real permission — a system Settings screen on API 30+, not
just an in-app dialog — where before this feature needed no storage
permission at all. Documented as a deliberate, known trade-off, not an
oversight — see FEATURES_ADDED.md's note.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed the native ROM-loading call
(`EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)`) already only
ever took plain paths, never a `Uri` or SAF-specific type, so
`stageRomFile()`/`zipContainsGba()`/`loadRomFromUri()` needed zero
changes — the new browser just calls the same `loadRomFromUri(Uri.fromFile(file))`
every other entry point already used; confirmed `deriveRomBaseName()`'s
existing `contentResolver.query()` + `try/catch` + `uri.lastPathSegment`
fallback chain handles a `file://` Uri correctly (the query throws or
returns nothing for a scheme with no registered ContentProvider,
falling through to `lastPathSegment`, which returns the decoded file
name); whole-file brace/paren count checked after all edits (726/726
braces, 3083/3083 parens).

## 2. Portrait-styled panel, not an actual forced rotation

**Category:** Feature (ROM browser presentation)
**Files modified:** `MainActivity.kt`
**What changed:** `buildRomBrowser()` now returns a dimmed-backdrop
`FrameLayout` with a centered, width-capped, rounded `panel` inside it,
instead of one edge-to-edge `LinearLayout`. No orientation API call
anywhere in this screen's code.
**Reason:** Requested as "force Portrait for file manager only" — built
as the safer alternative instead (see below), not the literal request.
**Expected improvement:** The portrait-list look, without reintroducing
the native RenderThread SIGABRT a real forced rotation caused on this
exact screen (found and reverted two passes before this one — see
BUGS_FIXED.md/CHANGELOG.md). That reverted attempt's own comment had
already named this panel approach as the safer route to revisit if
portrait selection mattered enough to come back to — it did, so this
pass built it.
**Side effects:** Not a literal device rotation, so anything that
specifically expected the *device* to report itself as portrait (none of
this app's own code does) wouldn't see that. Purely visual/layout.
**Verification:** No compiler or device in this sandbox. Read-through
only: confirmed no `requestedOrientation` call exists anywhere in
`buildRomBrowser()`, `openRomBrowserAtRoot()`, or the row/close/load
handlers — the exact call sites the reverted attempt used — so the
SIGABRT's specific trigger (a real surface reconfiguration in the middle
of other view work) has nothing to fire on here.

---

# CHANGELOG — Thirtieth pass

Feature request: make the ROM browser's `.zip` filtering content-aware
instead of name-only. Full description in FEATURES_ADDED.md; this entry
covers the mechanics.

## 1. ROM browser now verifies a `.zip` actually contains a `.gba` before listing it

**Category:** Feature (ROM browser filtering)
**Files modified:** `MainActivity.kt`
**What changed:** `refreshRomBrowserList()` no longer treats every `.zip`
in a folder as a ROM by name alone. Directories and bare `.gba` files
still render immediately; `.zip` files are now checked in the background
(`zipContainsGba()`, sharing its magic-bytes check with `stageRomFile()`
via new helper `isZipSignature()`) and only added to the list once
verified. A new generation counter (`romBrowserGeneration`) discards a
scan whose folder the user has already navigated away from by the time
it finishes.
**Reason:** Requested directly — see FEATURES_ADDED.md for the full
description and user-facing behavior.
**Expected improvement:** A ROMs folder that also holds a save-data
backup zip, a screenshot batch, or any other unrelated archive no longer
shows those as if they were games in the "Load game" list — only `.zip`
files that actually contain a `.gba` appear.
**Side effects:** None for directories or bare `.gba` files — that path
is byte-for-byte the same filter as before, same sort order. `.zip`
files now take an extra (background, non-blocking) content check before
appearing; a folder with many/large irrelevant `.zip` files will show its
real ROMs slightly later than a folder with few. See
KNOWN_LIMITATIONS.md.
**Verification:** No compiler or device in this sandbox, as every pass.
Read-through only: confirmed `stageRomFile()`'s own behavior and its one
caller (`loadRomFromUri()`) are unchanged — it now calls the extracted
`isZipSignature()` but performs the identical byte comparison; confirmed
`openRomBrowserAtRoot()`/`romBrowserUp()` (the only two callers of
`refreshRomBrowserList()`) needed no changes; whole-file brace count
checked before and after this pass's edits (713 open, 713 close both
times) and again after a follow-up fix to a doc-comment ordering slip
made during the edit itself.

---

# CHANGELOG — Twenty-ninth pass

User requested a code audit, then a deeper one, then asked to fix both
findings. Neither is the multiplayer bug this project has been chasing —
both are independent, real issues the audit surfaced along the way.

---

## 1. `mgba_jni.c` — close a pre-existing locking gap around g_link_obj/g_link_xchg_mid/g_link_is_host (FIX 23)

**Category:** Correctness (data race), low practical severity
**Files modified:** `mgba_jni.c`
**What the audit found:** These three globals are read under `g_core_mutex`
everywhere else (`link_sio_write_register()`, called from `nativeRunFrame()`
while it holds the lock) but were written *outside* the lock in both
`nativeLinkStart()` (before it was ever taken) and `nativeLinkStop()`
(after it was released) — the one gap in an otherwise-consistent
"always under g_core_mutex" rule for this file's globals. Present since
FIX 7/8 introduced these globals; not something any of the recent passes
introduced.
**The fix:** Both functions now write all three only while holding
`g_core_mutex`. `GetObjectClass()`/`GetMethodID()` stay outside it (pure
JNIEnv reflection, touch no shared state); only the resulting method ID
and global ref, plus `is_host`, move inside. One small, deliberate
behavior refinement along the way: previously, on `nativeLinkStart()`'s
`!g_core` failure path, `g_link_xchg_mid` could be left holding a
freshly-resolved, valid method ID while `g_link_obj` was NULL (the old
code cleared `g_link_obj` unconditionally at the very top, before the
`g_core` check existed). Now all three are only ever written together, so
there's no window where they're inconsistent with each other.
**Practical risk:** Low. Pointer- and bool-sized writes are naturally
atomic on ARM, so this was never likely to produce an actual torn read —
but it was genuine unsynchronized concurrent access by the letter of the C
standard, worth closing once found rather than leaving on the books.
**Verification:** No device or compiler in this sandbox, as every pass.
File-wide brace/paren balance checked before and after (comment- and
string-aware, same script every C-file pass has used).

## 2. `MainActivity.kt` — extend the quicksave-race guard to the slot-picker dialog (FIX, audit pass)

**Category:** Correctness (race condition), same class as a bug already
fixed once in this file
**Files modified:** `MainActivity.kt`
**What the audit found:** An earlier pass added `quickStateBusy` (an
`AtomicBoolean` guard) specifically because `quickSaveState()`/
`quickLoadState()` used to spawn unsynchronized background Threads with no
ordering between overlapping calls — a fast double-tap could load stale
data or land saves out of order. `showSaveStateSlotDialog()`'s own
save/load action had the exact same unguarded pattern and was never given
the same guard. Narrower to actually hit (the dialog dismisses itself
after one tap, so it takes two separate menu visits in quick succession
rather than one fast double-tap on an always-visible button) but
identical underlying race.
**The fix:** Renamed `quickStateBusy` → `saveStateBusy` (its scope is no
longer just the "quick" operations) and added the same
`compareAndSet(false, true)` guard, with a `try/finally` that always
clears it, to the slot dialog's save/load `Thread`. One shared flag
across all three call sites (quick save, quick load, slot save/load) was
chosen over a second, separate flag so a quick-save can't race a
slot-load either — the two would need to know about each other to close
that gap otherwise, which is more state for no real benefit.
**Verification:** No device or compiler in this sandbox. Checked the
edited region's brace/try/finally nesting by hand, plus a whole-file
naive brace count (697 open, 697 close) as a smoke test — not fully
reliable for Kotlin string templates in general, but a meaningful signal
given the edit itself didn't touch any string literals.

---

# CHANGELOG — Twenty-seventh pass

User tested against Dragon Ball Z: Supersonic Warriors with a fresh matched
capture, and confirmed directly that the communication error appears
during the quiet stretch after the initial handshake burst — well before
this file's own ~11.5s retry gives up.

---

## 1. `mgba_jni.c` — log raw SIO mode changes independent of the active per-mode driver (FIX 22)

**Category:** Diagnostic, not a fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Same shape as the Twenty-sixth pass's own
capture — a burst of real handshake data, then both sides write
`SIOCNT=0x2003` (Start cleared) within 65ms of each other and go silent
until a restart ~11.5s later. FIX 21 didn't change this shape, which rules
out pacing as the cause. New this pass, confirmed by the user: the
communication error is already showing on screen during that quiet
stretch, well before this file's own retry timeout — something is failing
faster and on different grounds than anything this driver currently tracks.
**The theory:** Checked GBATEK's actual documented Multi-Player procedure
(gbatek-sio-multi-player-mode). It documents that a child can signal
"not ready" by temporarily leaving Multi-Player mode entirely — not via any
bit this driver inspects. `link_sio_write_register()` is only ever
registered for `SIO_MULTI` (FIX 7), matching how every real per-mode SIO
driver in mGBA's own source is scoped to one mode — so a ROM taking that
exact documented exit would go completely unlogged by this file until it
switches back, and every "restart" logged since the Sixteenth pass might
be exactly that, not a failed-and-retried negotiation. This driver also
never relays *mode*, only actual Multi-Player transfers, so even where the
theory is right, the other device has no way to see its partner's signal.
**What this pass does:** Not the fix — the safe way to check the theory.
Rather than adding `init`/`load`/`unload` driver callbacks (a real option,
deliberately not taken — their exact signature isn't something this
sandbox can verify, and FIX 7's own comment already records getting bitten
by exactly this category of mistake once, on `GBASIOSetDriver()`'s own
argument count), `nativeRunFrame()` now reads `sio.rcnt`/`sio.siocnt`
straight off the core directly and logs on any change — bypassing the
per-mode driver question entirely, since these are plain fields on a
struct this file already dereferences successfully elsewhere.
**Expected outcome:** If the next matched capture shows an "SIO mode" log
line moving away from Multi-Player's own selection during the quiet
stretch, that confirms the theory and justifies the driver-callback
approach next. If `rcnt`/`siocnt` sit still through the whole stretch, the
theory is wrong and this was a cheap way to rule it out.
**Verification:** No device or compiler in this sandbox, as always. Unlike
FIX 20/21's pacing math, this isn't pure arithmetic that can be tested
standalone — it's a struct field read whose only real verification is
whether it compiles against the pinned mGBA headers, which happens in CI.
File-wide brace/paren balance checked before and after, as every pass.

---

# CHANGELOG — Twenty-sixth pass

User tested FIX 20 on a real device and sent back a fresh matched capture,
then separately reported trying Dragon Ball Z: Supersonic Warriors and
getting an instant "communication error" plus noticeable in-game lag.

---

## 1. `mgba_jni.c` — bound FIX 20's pacing to a short per-attempt window (FIX 21)

**Category:** Refinement of an experimental diagnostic, still not a
confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Real movement for the first time in this
project's history — the child's own SIOMLT_SEND is no longer stuck at only
`0x0000`/`0xFEFE`; it's now writing genuinely varying values, and the
~200ms restart loop documented since the Sixteenth pass is gone, replaced
by full attempts ~15-17s apart. Each attempt still ends in a new stall
(both sides write SIOCNT with Start cleared and sit for several seconds)
before restarting — a different, previously-invisible bottleneck.
**What the user separately reported:** Dragon Ball Z: Supersonic Warriors —
a real-time fighting game, far less tolerant than a slow retry-based
handshake — fails instantly with "communication error" and lags visibly.
No capture from that specific attempt, but consistent with FIX 20's own
documented cost: an unconditional ~16.74ms added to every host-triggered
exchange for the whole session, with no way to turn itself off.
**The fix:** Not a fix — a refinement of FIX 20's experiment. Pacing is now
bounded to a 3-second `LINK_PACE_WINDOW_NS` grace window, armed once at
session start and re-armed on every local RCNT write (i.e. every
negotiation restart, per every capture on file). Outside an armed window —
an established connection, exactly where a real-time game would be during
actual play — `link_pace_exchange()` is a single boolean check, identical
in cost to FIX 20 being off. See `mgba_jni.c`'s FIX 21 comment for the full
reasoning and exactly which capture the 3s figure comes from.
**Reason:** The aliasing/timing theory looks confirmed by the first result
(nothing else in 20 fixes had ever moved the child past two placeholder
values) but applying it as a flat, whole-session cost is too blunt — it
risks trading one game's stuck handshake for another game's broken
real-time play. Bounding it to short per-attempt windows keeps the
demonstrated benefit without the standing tax.
**Verification:** No device in this sandbox, as always. The windowed
pacing logic (arm/expire/re-arm, and that only the exchanges genuinely
inside the window ever sleep) was extracted verbatim and compiled
standalone against a controllable fake clock — 5 scenarios (unarmed,
armed-matches-FIX-20, expiry stops sleeping and clears the flag, a
400-call burst spanning the boundary only paces the ~179 calls actually
inside it, re-arming after expiry starts a fresh window) all passed under
`gcc -Wall -Wextra -std=gnu11` with zero warnings. File-wide brace/paren
balance checked before and after.
**Not answered by this pass:** Whether 3s is the right window, whether the
new SIOCNT=0x2003 stall is the next real bottleneck, and whether Dragon
Ball Z: Supersonic Warriors' failure was really pacing latency or
something else about that ROM — all need a real device and, ideally, a
capture from that specific game.

---

# CHANGELOG — Twenty-fifth pass

User-reported, with a fresh matched host+child capture (`log.text`/
`logt.text`, 07-17) attached: multiplayer still doesn't work, and — new
information, not previously on file — confirmed the same ROM's multiplayer
works outside this app, ruling out "this specific ROM's own link code is
unusual" as an explanation for the first time in this project's history.

---

## 1. `mgba_jni.c` — experimental exchange pacing (FIX 20)

**Category:** Diagnostic experiment, not a confirmed fix
**Files modified:** `mgba_jni.c`
**What the new capture shows:** Identical to FIX 18/19's evidence, unchanged
across ten passes and five unrelated feature passes in between: the child's
own SIOMLT_SEND is still only ever `0x0000`/`0xFEFE`, and its own RCNT/SIOCNT
setup sequence still restarts roughly every 200ms (194-209ms apart across
five resets in this capture), while the host's own outgoing data still
arrives at the child correctly and varying, exactly as it always has.
**What's new:** With the ROM ruled out by the user directly, the bug has to
be in this app's own link implementation. That re-focuses attention on the
theory named since the Seventeenth pass but never acted on: this driver
resolves every transfer as one instantaneous blocking network round-trip,
with nothing pacing completion against real per-transfer cycle cost
(`GBASIOCyclesPerTransfer`, cited since FIX 10) — and `nativeLinkChildExchange()`
runs on a background thread with no correlation to when the child's own CPU
actually gets to execute, so at the observed exchange rate (hundreds/second)
roughly a dozen updates can land, each overwriting the last, for every
single frame's worth of CPU time the child ROM gets to run in.
**The fix:** Not a fix — a bounded, reversible experiment. `link_pace_exchange()`
makes a host-triggered exchange wait until at least one emulated GBA frame
(~16.74ms) has passed since the previous one before starting the network
round-trip, so the child's CPU gets a real chance to observe each exchange
before the next one lands. Toggleable via `LINK_PACE_EXCHANGES` (on by
default); set to 0 for this file's exact prior behavior. See `mgba_jni.c`'s
own FIX 20 comment for the full reasoning, including why a fully correct
fix (real `mTiming` scheduler integration) is not attempted here.
**Reason:** Every prior pass that named the timing-architecture theory
declined to test it, for lack of a way to check it without a device. This
gives the user a cheap, single-toggle way to test it on a real device
without this project taking on a full scheduler-integration rewrite blind.
**Expected outcome:** One of two informative results, either of which moves
this forward. If the ~200ms reset and the 0x0000/0xFEFE ceiling persist
unchanged with pacing on, the aliasing theory is very likely wrong (or not
the whole story), and the next pass should look elsewhere. If either
changes, that's real evidence to justify real scheduler integration next.
**Side effects:** Adds up to ~16.7ms of latency per host-triggered exchange
when the network reply would otherwise have arrived faster than that — on
top of the network round-trip's own latency, not instead of it. No effect
on the child role's own code path. No effect on data correctness — every
byte exchanged is identical to before, only the timing of when the next
exchange is allowed to start changes.
**Verification:** No Android/NDK toolchain or device in this sandbox, as
every pass. The pacing/interval math (GBA frame length → nanoseconds,
sleep-remaining-time logic, reset-on-reconnect) was extracted verbatim and
compiled standalone against a controllable fake clock (not real
`clock_gettime`/`nanosleep`, which need a real device to observe) — five
scenarios (first exchange, back-to-back, late-arriving, half-elapsed,
ten-in-a-row) all passed under `gcc -Wall -Wextra -std=gnu11` with zero
warnings. File-wide brace/paren balance checked comment- and string-aware
before and after. This confirms the arithmetic and control flow are correct
in isolation — it does not confirm the fix changes the reported symptom,
which (as with every pass in this project) needs a real device to know.

---

# CHANGELOG — Twenty-fourth pass

User-reported: the menu-based Save State/Load State flow (as opposed to
the Quick Save/Quick Load buttons fixed last pass) feels slow in two
places — the slot-picker dialog taking a moment to appear, and picking a
slot taking a moment to confirm.

---

## 1. `MainActivity.kt` — slot thumbnails cached in memory

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `showSaveStateSlotDialog()` re-read and re-decoded
every slot's PNG thumbnail from disk on *every single open*, even when
nothing about that slot had changed since the last time the dialog was
shown. On repeat opens — exactly what fast save/load testing does — this
was pure wasted disk I/O and PNG decode work.
**The fix:** Added `slotInfoCache`, an in-memory `ConcurrentHashMap` keyed
by ROM name + slot number, holding each slot's already-decoded `SlotInfo`.
A slot is only re-read/re-decoded when its `exists`/`lastModified()` no
longer match what's cached — i.e. only when it's actually stale, which in
practice means right after a save to that slot. Keyed by ROM name as well
as slot number since slot *numbers* repeat across ROMs but point at
different underlying files.
**Confidence:** High — this only removes redundant, correctness-neutral
work; the freshness check still falls back to a full re-decode any time
the underlying file has actually changed.

---

## 2. `MainActivity.kt`/`SaveEntry` — backup-before-save now a rename, not a copy

**Category:** Performance
**Files modified:** `MainActivity.kt`
**What was wrong:** `backupIfExists()` (called right before every save,
by both Quick Save and the menu's Save State) read an existing slot's
full bytes and wrote them out again to the `.bak` sibling — immediately
before `nativeSaveState()` was about to overwrite that same original file
anyway. That's up to 2x a save-state's worth of disk I/O for every single
save, all of it before the confirmation toast could fire.
**The fix:** Added `SaveEntry.moveInto()`. When no Storage folder is
configured (the common case), the backup is now a single
`File.renameTo()` — an instant, metadata-only move on the same volume —
instead of a byte-for-byte copy. Falls back to the old copy behavior if
the rename fails, or whenever a Storage folder IS configured (no
equivalent plain rename via `DocumentFile`).
**Confidence:** High for the internal-storage path (the default); the
Storage-folder path is unchanged from before, so no regression risk
there.

---

# CHANGELOG — Twenty-third pass

User-reported (from fast save/load testing): Quick Save/Quick Load
sometimes "saved on a different frame" than expected, and sometimes
appeared not to save at all when tapped quickly.

---

## 1. `MainActivity.kt` — quickSaveState()/quickLoadState() race fixed

**Category:** Bug fix (data race)
**Files modified:** `MainActivity.kt`
**What was wrong:** Every tap of Quick Save or Quick Load spawned a brand
new, totally unsynchronized `Thread`. `g_core_mutex` on the native side
only serializes the moment of the actual file write/read against the
running game thread — it says nothing about which Kotlin thread reaches
that point first. A fast double-tap of Quick Save, or Quick Save followed
immediately by Quick Load, raced: whichever thread happened to win the
mutex first went first, regardless of tap order. A Load that won the race
before a pending Save had written could read the file from before that
save (looks like "loaded the old/first save"); two Saves landing in
either order looks like "saved a different frame" than the one actually
displayed at the moment of the tap.
**The fix:** Added a shared `AtomicBoolean` busy-guard around both
functions. A tap that arrives while a prior quicksave/quickload is still
in flight is now a no-op with its own toast, instead of spawning a second
racing thread. Confirmed: `nativeSaveState()` already opens with
`O_TRUNC` (see `mgba_jni.c`), so an existing slot is always fully
replaced, never appended to or left partially overwritten — the
"different frame" symptom was the race above, not a failure to replace
the slot.
**Confidence:** The race is definite from the code (no lock, no debounce,
two independent Threads touching the same file/native calls). Not
re-confirmed on a real device this pass — no Android toolchain here.

---

# CHANGELOG — Twenty-second pass

Two user-reported issues, both in `MainActivity.kt`: a stray "Load ROM"
button rendering on top of the ROM browser it was supposed to sit behind,
and Save State feeling slow — the confirmation toast wasn't showing up
until well after the state had actually finished saving.

---

## 1. `MainActivity.kt` — floating "Load ROM" button removed

**Category:** Bug fix (visual — matches a screenshot showing the button
floating over the ROM browser's file list)
**Files modified:** `MainActivity.kt`
**What was wrong:** The purple "▶ Load ROM" `Button` sat behind
`romBrowserOverlay`/`settingsMenuOverlay` in add order (added to `root`
first), but a stock Material `Button` carries a small default elevation
even with nothing explicitly setting one. Android draws children with
non-zero elevation above children with zero elevation regardless of add
order once any Z-order is involved, so the button rendered ON TOP of the
overlays that were supposed to cover it — visible as a stray purple pill
hovering over the ROM browser's file list, exactly as reported.
**The fix:** Removed the button outright rather than patching its
elevation. `changeRom()` already auto-opens the ROM browser on first
launch and on Close (`closeGame()`), which covers the button's main
purpose already. Its other purpose — a way back into ROM selection when
the folder picker gets cancelled before any folder's chosen, or a ROM
load fails — is now handled by `onGameTouch()`: tapping the idle
(no-ROM-loaded) surface calls `changeRom()` directly. No button, no
elevation, no Z-order conflict possible.
**Confidence:** The elevation-over-opaque-sibling explanation matches
Android's own documented Z-order behavior and matches the reported
screenshot exactly (button visible mid-screen, over the file list, below
where "Use system file picker instead" sits). Not re-confirmed on a real
device this pass — no Android toolchain here — but removing the view
entirely can't reproduce a Z-order bug that only existed because the view
was there.

---

## 2. `MainActivity.kt` — Save State confirmation no longer waits on the thumbnail

**Category:** Bug fix (perceived performance — reported as "doesn't save
instantly")
**Files modified:** `MainActivity.kt`
**What was wrong:** In `showSaveStateSlotDialog()`'s save path, the
"Saved to Slot N" toast fired AFTER `captureStateThumbnail(slot)`
completed, not right after the actual state write. That thumbnail capture
waits on `PixelCopy.request()` (up to a 500ms `CountDownLatch.await()`),
then scales and PNG-encodes a full-screen bitmap — all of it fully
blocking, even though the save itself was already done and safely on disk
before any of it started. Every Save State via the slot dialog felt
delayed by however long that took. (The one-tap 💾 quicksave button —
`quickSaveState()` — never had this problem; it doesn't capture a
thumbnail at all.)
**The fix:** Reordered so the confirmation toast fires immediately after
`nativeSaveState()`/`nativeLoadState()` returns, and
`captureStateThumbnail()` runs afterward, still on the same background
thread but no longer gating the confirmation. The slot list just won't
show a brand-new thumbnail until it's next opened; the save itself is no
longer perceived as slow.
**Confidence:** The 500ms figure is read directly from
`captureStateThumbnail()`'s own `latch.await(500, TimeUnit.MILLISECONDS)`
call, so the worst case this fix removes from the confirmation's critical
path is exact, not estimated. Not verified against a real device's actual
felt latency this pass — no Android toolchain here — but the reorder
itself can't change save correctness, only when the toast fires relative
to work that was already happening.

---

# CHANGELOG — Twenty-first pass

Bug fix, real-device-reported: the Twentieth pass's Storage folder feature
broke save/load once someone actually tested it on a phone — reported as
"doesn't save and load" after turning that feature on. Root cause and fix
below; no new feature this pass.

---

## 1. `MainActivity.kt` — SAF native-fopen bridge replaced

**Category:** Bug fix (confirmed on real device this pass; Twentieth pass's
version of this was flagged in KNOWN_LIMITATIONS.md as unconfirmed)
**Files modified:** `MainActivity.kt`
**What was wrong:** `SaveEntry.nativePath()` bridged a SAF document to
native code via `/proc/self/fd/<N>` — reopening a `ParcelFileDescriptor`'s
fd as a plain path and handing that straight to `VFileOpen()`, including
for the battery save, which the core mmaps for the entire ROM session.
Nothing guarantees a re-opened SAF fd supports mmap/seek/`O_TRUNC` the way
native code needs — that's provider-specific — and a real-device test this
pass showed it doesn't hold up: saves and states appeared to go somewhere,
but loading them back either failed or didn't reflect what was saved.
**The fix:** Native code no longer touches a SAF document directly. It
always `fopen()`s a plain file under this app's own internal storage —
exactly as before the Storage-folder feature existed — and Kotlin copies
bytes to/from the chosen folder's document on either side of that call,
using `ContentResolver`'s stream APIs (`openInputStream`/`openOutputStream`),
which every `DocumentsProvider` is required to support. See
`SaveEntry.stageForRead()` / `stageForWrite()` / `commitWrite()` for the
one-shot save-state/quicksave/thumbnail case, and `batteryMirrorPath()` /
`syncBatteryMirror()` for the session-long battery save (synced out at
`onPause()`, before swapping to a different ROM, on `closeGame()`, and as a
last-resort in `onDestroy()`).
**Confidence:** Removes a specific, real failure mode confirmed this pass.
Still not run against every possible DocumentsProvider (cloud-storage-backed
folders in particular) — see KNOWN_LIMITATIONS.md — but no longer depends on
provider-specific mmap/seek/truncate behavior at all, only on the stream
APIs every provider must implement.

---

# CHANGELOG — Twentieth pass

New feature, unrelated to the link/multiplayer work above — user-chosen
Storage folder for saves/states/screenshots, so they can live somewhere
visible in a file manager instead of only under this app's own internal
storage (`Android/data/...`).

---

## 1. `MainActivity.kt` — Storage folder (Settings → Storage)

**Category:** Feature
**Files modified:** `MainActivity.kt`
**What it does:** A new Settings row lets the user pick a folder (system
folder-picker/SAF — same mechanism the ROM browser already uses, see
`romTreePicker`, just with write access too). Once set, three subfolders
appear inside it — `save`, `cheat`, `screenshot` — and every battery save,
save-state, state thumbnail, quicksave, and screenshot goes there instead
of internal storage from that point on. `cheat` is provisioned but unused
— there's no cheat feature yet to write into it (see the "Cheats" menu
entry, still "not implemented yet").
**Why SAF, not a plain hardcoded path:** the obvious alternative
(`MANAGE_EXTERNAL_STORAGE`, giving raw `java.io.File` access anywhere)
was already deliberately rejected for the ROM browser for reasons that
apply just as much here — see that feature's own comment. The wrinkle
specific to this feature: `nativeSaveState()`/`nativeLoadState()`/
`nativeLoadROM()`'s save path all need a real fopen()-able path string,
which a SAF document's `content://` URI isn't. Bridged via
`/proc/self/fd/<N>` — open a `ParcelFileDescriptor` for the SAF document,
hand native code that path instead, close the descriptor once native code
has opened its own independent handle. No native code changed at all.
**No migration:** switching folders does not move whatever already exists
under internal storage — only new saves/states/screenshots go to the new
location. Stated plainly in the Settings screen itself before anyone taps
"Choose folder" — see KNOWN_LIMITATIONS.md for why automatic migration
isn't attempted.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren counts checked directly. The
`/proc/self/fd/` bridge itself is a well-known, long-used technique for
this exact SAF/native-fopen mismatch, but not confirmed against a real
device/provider here — see KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Nineteenth pass

Negative result, not a fix — re-tested Eighteenth pass's SIOCNT-mirroring
change against a real matched capture. No observed change: the child's own
`childData` is still only ever `0x0000`/`0xFEFE`, same as every capture
back to the Sixth pass. Not reverted — it's still correct on its own terms,
just not the fix for this ROM.

Also added: `copyLinkDebugLog()` now appends a `=== copied at
MM-DD HH:MM:SS.mmm ===` line to the exported text, so two phones' captures
can be time-aligned by eye. Prompted by this pass's two logs covering
different real-world spans — turned out to be expected (host logs ~3
lines per SIO exchange, child ~1, so the same 40,000-character cap holds
less real time on the host side), not a bug, but there was no quick way to
confirm that from the logs alone before now.

---

# CHANGELOG — Eighteenth pass

Scope note: `mgba_jni.c` only. First pass with a real matched capture — two
link logs, one per phone, from the same connection attempt (timestamps
overlapping to the second) instead of minutes apart, made possible by
Seventeenth pass's logcat-independent logging.

---

## 1. `mgba_jni.c` — child's own SIOCNT never reflected transfer completion

**Category:** Bug fix
**Files modified:** `mgba_jni.c`
**Problem:** Cross-referencing the new matched capture confirmed the
network layer is not the issue — the host's live, changing outgoing data
correctly reaches the child (visible as `hostData` in its exchange log),
and the child's own data correctly reaches the host (`recv`), both
directions, from a real simultaneous pair for the first time. That leaves
the child ROM's own code as the only place still unaccounted for. Reading
`nativeLinkChildExchange()` end to end turned up a gap it already
self-documented: it writes the SIOMULTI0-3 data registers and raises the
SIO IRQ, but never touched the child device's own SIOCNT. GBATEK documents
Multi-Player SIOCNT bit 7 (Start/Busy) as a hardware-mirrored reflection of
the parent's clock line on every connected unit, not something a child's
CPU sets — polling it to notice "a transfer just landed" is a normal
technique alongside, or instead of, IntrWait on the IRQ this file already
raises. A child ROM using that technique would see a flat, never-changing
value here, regardless of the IRQ or data registers already being correct.
**Solution:** `nativeLinkChildExchange()` now reads the child's current
SIOCNT, refreshes bits 2 (child), 3 (ready), 4-5 (player ID), and clears
bit 7 (busy) after every exchange, preserving every other bit (mode, baud
rate, IRQ-enable) exactly as the ROM last set it.
**Reason:** Closes a gap the code already admitted to itself in a comment,
cross-referenced against GBATEK — not a new guess about either test ROM's
internals.
**Expected improvement:** If either test ROM polls SIOCNT bit 7 to detect
new data (a common pattern alongside or instead of the IRQ), it should now
see it, instead of a flat value indistinguishable from "no cable."
**Side effects:** None on the host path — this only touches the child-role
function. Preserves mode/baud/IRQ-enable bits rather than clobbering them.
**Verification:** No Android toolchain in this sandbox (unchanged
constraint every pass). Brace/paren count checked directly (69/69, 645/645
across the whole file). Not confirmed on a real device — see
KNOWN_LIMITATIONS.md.

---

# CHANGELOG — Seventeenth pass

Scope note: `mgba_jni.c`, `EmulatorEngine.kt`, `MainActivity.kt`,
`LinkMultiplayer.kt`. Prompted by two things in the same message: "still
doesn't work multiplayer" (expected — see KNOWN_LIMITATIONS.md for what
this pass's new evidence actually shows) and "can't get log on this
device, only on other device" — the exact logcat-access split Sixteenth
pass flagged but didn't fix, now confirmed to still be blocking things.

1. **Durable, logcat-independent link debug logging.** `copyLinkDebugLog()`
   used to shell out to `logcat`, which reads back a process's own output
   fine on stock Android but which some OEM builds restrict further — W's
   own two-phone split (real output on one, nothing on the other, same
   build) is direct evidence of that, not of a bug in this app. Every
   `LOGI`/`LOGW`/`LOGE` in `mgba_jni.c` now also writes to a plain private
   file under this app's own `filesDir`, via a new `jni_log_line()` the
   existing `LOGI`/`LOGW`/`LOGE` macros expand to — every call site in the
   file is unchanged, since those are still plain macros. A new
   `nativeSetLinkLogPath()` JNI entry point (called once from
   `MainActivity.onCreate()`) hands the path in. Needs no logcat/READ_LOGS
   access at all, on any device, since it was never reading logcat to
   begin with.
2. **Fresh log per connection attempt, not an ever-growing file.**
   `nativeLinkStart()` re-truncates the log file at the start of every
   session, matching the actual workflow (connect, wait, read the log) —
   a capture reflects one attempt, not whatever a previous one left
   behind. An 8MB backstop cap in the new `link_log_write()` resets to
   empty if a single session ever runs long enough to hit it, which normal
   use shouldn't.
3. **Kotlin-side connection-lifecycle logging (Fifteenth pass's 7 log
   lines in `LinkMultiplayer.kt`) now mirrors into the same file** via a
   new `linkLog()` helper, instead of only going to `Log.i`/`Log.w`. One
   "Copy link log" read now captures the same combined picture the old
   3-tag logcat filter (`mGBA-JNI:* mGBA-Link:* mGBA:*`) used to, without
   depending on logcat access to get it.
4. **No protocol or timing behavior changed.** All four items above are
   logging/infrastructure only. See KNOWN_LIMITATIONS.md for this pass's
   actual investigation (a deeper read of the new host+child evidence, and
   an updated but still-unconfirmed theory) and BUGS_FIXED.md for why this
   isn't labeled a bug fix.

---

# CHANGELOG — Sixteenth pass

Scope note: `mgba_jni.c`, `MainActivity.kt` only. Prompted by the first
genuinely useful evidence this project has had: FIX 13 (Fifteenth pass)
worked, and W sent back four logs — a screenshot of an empty capture on one
phone, and three real logcat files (`wifi_host.text`, `wifi_join.text`,
`bluetoth__1_.text`) with actual multiplayer-attempt content instead of
boot noise.

Reading those three files is what this pass actually is. No new hypothesis
was chased from a cold read this time — everything below follows directly
from what the logs show, and from tracing the two remaining places this
codebase had *no* logging at all (the exchange result on the host side, and
the entire child-side receive path) once it became clear those were the
specific gaps stopping the new evidence from being conclusive.

**Still nothing here fixes the reported bug.** See KNOWN_LIMITATIONS.md.
What this pass adds is the other half of the trace FIX 11/13 started, so
the *next* capture — taken with both phones logging the same session,
which this one wasn't — has a real chance of showing the actual mechanism
rather than another layer of "here's activity, still can't tell what it
means."

---

## 1. Logged the SIO exchange result on the host side, not just the trigger

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()` (FIX 11/13) traced every write that
*triggers* an exchange, but never what `link_exchange()` actually returned.
`wifi_host.text` this pass showed 1124 Start-bit writes in 1.67 seconds —
mathematically far too fast to be hitting `WIFI_XCHG_MS=30` on each one
(that alone would take over 30 seconds) — strongly implying most were
completing fast with real replies, not timing out, but nothing in the log
said so directly, and the reply *content* was invisible either way.
**Solution:** Added `LOGI("SIO exchange result: sent=... recv=... timedOut=...")`
right after `link_exchange()` returns, inside the same host-only branch.
**Reason:** Directly motivated by not being able to answer "is the network
side actually working" from `wifi_host.text` alone, despite the timing
strongly suggesting yes.
**Expected improvement:** The next host-side capture will say, per
transfer, exactly what came back and whether it was a timeout.
**Side effects:** Roughly doubles this function's log volume during active
exchanges — expected and accounted for in item 3 below.
**Verification:** Not runnable here. Read-through only; placed inside the
already-host-gated branch, so no new conditions to get wrong.

---

## 2. Added logging to the entire child-side receive path (previously zero)

**Category:** Diagnostic capture
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `nativeLinkChildExchange()` — the only thing that ever updates
a child device's own SIOMULTI0/1 registers — had no logging in either its
early-exit or success path. Every log gathered across sixteen passes,
including this pass's three, is entirely blind to whether this function is
even being called, let alone what it exchanges. `wifi_join.text` and
`bluetoth__1_.text` both show the child ROM repeatedly restarting its own
SIOCNT/RCNT setup roughly every 200ms — consistent with a ROM that keeps
giving up on its own negotiation — but whether that's because this function
never runs, runs but with bad data, or runs fine and the ROM just doesn't
react, was and is unanswerable without this.
**Solution:** Added `LOGW` on the early-exit branch (active/host-role/core
pointer check) and `LOGI` on every successful call, logging both
`hostData` and `childData`.
**Reason:** Same motivation as item 1 — this was the single largest blind
spot left after item 1, and the one most directly relevant to the
"still doesn't work on rom" reports for a device acting as the child.
**Expected improvement:** The next child-side capture will show whether
this function runs at all during a real attempt, how often, and with what
data — directly testable against the host's own `wifi_host.text`-style
trace if both phones capture the same session.
**Side effects:** Adds log volume proportional to how often the child
actually receives host data — unknown until measured, since this pass's
child-role logs show no evidence either way.
**Verification:** Not runnable here. Read-through only.

---

## 3. Bumped the debug-log capture window again, 8000 → 20000 lines

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** Fifteenth pass's 8000-line bump was sized against *boot*
noise, before this pass's evidence showed real exchange activity running
at ~670/second on the host — 2243 lines in 1.67s from the write trace
alone, before items 1-2 above add more on top.
**Solution:** `-t 8000` → `-t 20000`. Comment above `copyLinkDebugLog()`
updated with the real numbers behind the bump this time, instead of a
guess.
**Reason:** Directly sized against this pass's own measured log rate, with
headroom for items 1-2's added volume.
**Expected improvement:** A capture spanning several seconds of real
exchange activity, from either role, shouldn't scroll its own start out
from under itself before W gets to read it.
**Side effects:** Larger worst-case clipboard/dialog payload — same
reasoning as the Fifteenth-pass bump, still well within what a
`ScrollView`/`TextView` and the clipboard handle fine.
**Verification:** Not runnable here. Read-through only.

---

## Not changed this pass

- The actual mechanism behind the child ROM's repeated resets, or whether
  it's the same mechanism on Wi-Fi and Bluetooth — items 1-2 are what
  would show this, not a fix for it yet.
- The empty-log-on-one-phone issue W also reported/screenshotted this
  pass. Very likely a normal Android self-logcat restriction that varies
  by device/OS version (not something this codebase controls), for which
  Shizuku — already working on W's other phone — is the practical
  workaround. Not attempted as a code fix this pass; see
  KNOWN_LIMITATIONS.md for why and what a real fix would involve.
- Everything else FIX 9-15 already covers.



Scope note: `mgba_jni.c`, `LinkMultiplayer.kt`, `MainActivity.kt`. Prompted
by a retest reporting all three still-open symptoms at once: ROM detection
still failing on both transports, Wi-Fi disconnect not reaching the other
phone, and lag on Bluetooth. Two logcat dumps (one per transport) were
attached as evidence for the ROM-detection question specifically.

Reading those two dumps first, before touching any source, is what this
pass actually turned on: neither contained a single line from anywhere near
an actual link attempt — both covered barely 200ms of real time, entirely
boot-time noise. That's items 1-2 below. Item 3 is a design gap every prior
FIX 9-12 comment already described the intent for but never actually
enforced, found by re-reading `mgba_jni.c` end to end rather than from the
logs (which had no signal to read). Item 4 is the clipboard tool itself,
updated to match.

**None of this is confirmed to fix the reported symptoms** — see
KNOWN_LIMITATIONS.md's Fifteenth-pass entry for exactly what would. Items
1-2 are a confirmed, demonstrated bug (the evidence is the two attached
files) whose fix is straightforward; item 3 is a hardening whose actual
impact is unknown. What every item together should reliably produce,
even if the underlying multiplayer bug turns out to be something else
entirely, is a next debug-log capture that finally contains something to
read.

---

## 1. Filtered mGBA's own core logging out of `jni_log()`

**Category:** Bug fix (diagnostic capture) / possible general performance
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `jni_log()` — the callback that forwards mGBA's internal
logger to Android's logcat — forwarded every core log line, at every
level, to `LOGI` under the `mGBA-JNI` tag, with `(void)level` explicitly
discarding the one piece of information that would have let it filter
anything. Confirmed directly from both logcat files attached this pass:
every line in both was genuinely `mGBA-JNI` (the tag filter was never the
issue), but both covered barely 166-241ms of real time — pure boot-time
`"Starting DMA ..."` / `"Read from write-only I/O register: ..."` spam,
nothing from anywhere near an actual multiplayer attempt. Confirmed
against mgba-emu/mgba's real source this pass (not inferred): the latter
message is logged at `mLOG_STUB`, the same level FIX 12 already
identified for the (now-removed) `rawWrite16` no-op warnings. This chatter
is completely unrelated to link/multiplayer — any DMA-heavy ROM produces
dozens of these lines every single frame — so it was never specific to
this investigation, it just happened to be what finally made the capture
tool's output visibly useless enough to trace.
**Solution:** `jni_log()` now drops `mLOG_DEBUG`/`mLOG_STUB`/
`mLOG_GAME_ERROR` before they reach `LOGI`, matching mGBA's own
`src/platform/libretro/libretro.c` under `NDEBUG` (this project's own
`CMakeLists.txt` also builds with `NDEBUG`). `FATAL`/`ERROR`/`WARN`/`INFO`
are unaffected. Belt-and-suspenders on top of the level check: also drops
the two specific message prefixes actually observed flooding both attached
logs, regardless of level, in case either isn't DEBUG/STUB after all.
**Reason:** Directly demonstrated by the two files W attached — see
mgba_jni.c's own FIX 13 comment for the full trail.
**Expected improvement:** The next `Copy link log` capture should cover
much more real time and actually contain FIX 11's SIO trace lines and
LinkMultiplayer.kt's own connection-lifecycle logging, instead of nothing.
Secondary, unconfirmed: `__android_log_print` is a real syscall: cutting
dozens of avoidable calls per frame, on every ROM, may also just be a
general performance improvement — not only for the Bluetooth lag this pass
was asked about.
**Side effects:** None expected — pure log suppression, no behavior
change. If DEBUG/STUB-level core tracing is ever needed again for
unrelated debugging, this is the one place to temporarily loosen.
**Verification:** No compiler in this sandbox, as every pass. The two
attached logs are direct evidence the *problem* is real; the fix itself
(which specific mLogLevel constants exist, and that STUB is used for
exactly this "wrong-direction register access" case) is checked against
mgba-emu/mgba's real source this pass, not assumed.

---

## 2. Bumped the debug-log capture window, updated its guidance

**Category:** Bug fix (diagnostic capture)
**Files modified:** `MainActivity.kt`
**Problem:** `copyLinkDebugLog()`'s `logcat -t 2000` limit, combined with
Item 1's since-fixed noise, meant the window covered a fraction of a
second in practice.
**Solution:** Bumped `2000` to `8000`. Purely a safety margin on top of
Item 1's real fix, not a substitute for it — the comment above the
function, and the empty-state dialog message, were both updated to say so
and to explicitly mention re-testing the disconnect scenario (tap
Disconnect, wait a few seconds, then read the log), since that's now also
something this capture is meant to help diagnose.
**Reason:** Cheap extra headroom now that each line is worth far more
signal than before.
**Expected improvement:** A long test session (multiple connect/play/
disconnect cycles) is less likely to scroll early evidence back out.
**Side effects:** Slightly larger clipboard payload and dialog text in the
worst case; a plain monospace `TextView` inside a `ScrollView` handles a
few thousand lines fine.
**Verification:** Not runnable here (no device). Read-through only.

---

## 3. Host-gated the native SIO exchange trigger

**Category:** Hardening (protocol correctness) — impact unconfirmed
**Files modified:** `app/src/main/cpp/mgba_jni.c`
**Problem:** `link_sio_write_register()`'s exchange branch fired on *any*
SIOCNT write with the Start bit set, regardless of which role's own ROM
made that write. FIX 9's original comment already claimed this branch
"correctly never fires" on a child device, on the theory that a child ROM
never performs that write (GBATEK: Start/Busy is read-only for slaves) —
but nothing in the code actually enforced that; it was resting entirely on
that assumption holding for both test ROMs.
**Solution:** Added `&& g_link_is_host` to the branch condition; simplified
the two `g_link_is_host ? … : …` blocks inside it that the guard now makes
unreachable in the child case. The FIX 11 diagnostic warning is now also
host-gated, deliberately not logging the (now-expected) child case at all,
to avoid reintroducing Item 1's problem if a ROM's child-role code hits
this on every poll iteration.
**Reason:** Re-reading `mgba_jni.c` end to end for anything FIX 9-12 might
have missed, since the attached logs had no signal to point at anything
more specific. If either test ROM's link code shares one code path between
parent/child roles (plausible — Nintendo's SDK is commonly used that way)
and doesn't itself distinguish, this would have let a child device trigger
a second, spurious exchange of its own alongside the correct
network-triggered one — sending an unsolicited packet the host's *next*
real exchange could then consume as that round's reply. Fits the reported
symptom set well: identical ROM-detection failure on both transports (this
file is shared, unlike the already-hardened transport-specific Kotlin) and
worse lag specifically on Bluetooth (`BT_XCHG_MS=50` vs `WIFI_XCHG_MS=30` —
a stolen reply costs more there). Also may bear on the Twelfth-pass
KNOWN_LIMITATIONS entry that flagged suspiciously rapid repeated exchanges
in an earlier capture, never followed up.
**Expected improvement:** Unconfirmed — see KNOWN_LIMITATIONS.md. Cheap and
safe either way: host behavior is completely unchanged, since `is_host` was
already true on every path that used to run.
**Side effects:** None expected for the host role. For the child role. only
removes a call this design was never supposed to make in the first place.
**Verification:** Not runnable here. Design-intent gap identified by
reading, not by a build or device test.

---

## 4. Added specific reason logging to every disconnect/peer-lost path

**Category:** Bug fix (diagnostic capture)
**Files modified:** `LinkMultiplayer.kt`
**Problem:** `disconnect()`'s outgoing BYE send had a bare
`catch (_: Exception) {}` — completely silent whether it succeeded, was
skipped (null socket/peer), or threw. Separately, all 8 call sites of
`handlePeerLost()` logged one identical generic line regardless of which
of the 6 listener locations detected it or why (explicit BYE vs. the 8s
liveness timeout). A captured log couldn't have distinguished "peer's BYE
never arrived", "it arrived but something else consumed it first", and
"neither side has sent one yet, still waiting on the watchdog" — three
very different bugs that all look identical from the report "if I
disconnect, it doesn't disconnect on the other phone."
**Solution:** `disconnect()` now logs the BYE send's outcome specifically
(sent + destination, skipped + which of socket/peer was null, or the
exception). `handlePeerLost()` now takes a `reason: String`; every call
site names itself and, where relevant, the specific trigger (BYE received
vs. timeout duration).
**Reason:** Purely additive — no timing or protocol logic changed, only
what gets logged and how specifically.
**Expected improvement:** The next capture of a disconnect test should say
exactly which side sent a BYE, whether it was received, and if not,
whether the other side eventually gave up via the 8s watchdog instead —
enough to actually localize the reported bug instead of re-guessing at it.
**Side effects:** None expected. Slightly more log volume on disconnect
specifically (a handful of lines, not per-frame) — not a concern after
Item 1.
**Verification:** Not runnable here. Read-through only; every call site
cross-checked to confirm none were missed (`grep -n "handlePeerLost("`).

---

## Not changed this pass

- The actual WiFi disconnect-propagation bug, if it's not just Item 3
  above or a timing/testing artifact — nothing else found it by reading.
- The actual Bluetooth ROM-detection failure and lag, beyond Items 1 and 3
  above — same.
- `BT_XCHG_MS`/`WIFI_XCHG_MS` themselves — no evidence yet that the
  timeout values are wrong rather than the timeouts being hit at all.
- Everything else FIX 9-14 already covers.



Scope note: one-line fix, `MainActivity.kt` only, prompted by a real CI
build log the user attached (the Thirteenth pass's zip failed
`compileReleaseKotlin`).

---

## 1. Fixed a real Kotlin compile error

**Category:** Bug fix (compile error)
**Files modified:** `MainActivity.kt`
**Problem:** `showLinkDebugLogDialog(text: String)`'s parameter name
collided with `TextView`'s own `text` property. Inside `TextView(this)
.apply { text = shown }`, the bare `text` on the left of the assignment
resolved to the outer parameter (immutable) rather than the receiver's
property, so the compiler rejected it as reassigning a `val`. Everywhere
else in the file, the same kind of assignment goes through an explicit
variable (`row.text = ...`), which is never ambiguous — this was the one
bare/unqualified case, and it happened to collide.
**Solution:** Renamed the parameter to `logText`; the function body's one
reference to it (`text.ifBlank { ... }`) updated to match, `text = shown`
inside the `apply` block left as-is since it's now unambiguous.
**Reason:** Real `compileReleaseKotlin` failure from an actual CI run —
see the attached build log's `14_Build APK.txt`.
**Expected improvement:** Build succeeds.
**Side effects:** None — pure rename, no behavior change. The one caller
(`copyLinkDebugLog()`) passes its argument positionally, so it's
unaffected by the parameter's internal name.
**Verification:** No compiler available in this sandbox, as always — but
this fix is about as close to "verified" as this project gets without
one: the failure came from a real Gradle/Kotlin compiler run, the
collision was fully diagnosed against the exact reported line/column, and
grepping confirmed no other function in either of the last two passes'
additions has a parameter name that collides with a property name used
bare inside a nested `apply`/similar block.

---

# CHANGELOG — Earlier passes (summary)

Full entries for these passes were trimmed to keep this file a
reasonable length. None of them touch multiplayer/link code except where
noted — see FILE_CHANGES.md's own history if the exact diff for one of
these ever matters again.

- **Thirteenth** — `MainActivity.kt`: save-state slot picker now shows a
  thumbnail per slot.
- **Twelfth** — `MainActivity.kt`: added the in-app "Copy link log"
  diagnostic (logcat-based at the time; superseded by Seventeenth pass's
  file-based version). Diagnostic only, not a link fix.
- **Eleventh** — `MainActivity.kt`: fixed a Tenth-pass regression where
  every row in the restyled quick game menu silently did nothing when
  tapped (`isClickable`/`isFocusable` on the row view was stealing the
  touch from the `ListView`'s own click dispatch).
- **Tenth** — `MainActivity.kt`: quick game menu restyled and expanded to
  match a reference screenshot (10 items instead of 5); two now-redundant
  Settings rows removed; immersive mode now re-applied on focus regain;
  display-cutout black bar fixed; Screenshot/Reset/Close actions added.
- **Fifth** — First pass to focus on `LinkMultiplayer.kt`/multiplayer
  internals specifically (four earlier undocumented passes had already
  covered audio, rendering, ROM-swap safety, and the control layout
  editor). Fixed missing `@Volatile` on six connection-state fields
  (a real cross-thread visibility bug) and an untracked discovery socket
  that made `disconnect()` a no-op for it.
