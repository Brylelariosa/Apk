# Rubik AI Lab - NEXT TASK

Version 2.5 - 2026-10-23

## Do this next
1. Build v2.5 with CI. Nothing from v2.3, v2.4 or v2.5 has been compiled yet (the authoring sandbox has no Kotlin compiler or Android SDK):
   if the Kotlin compile or R8 reports anything, fix exactly the reported lines. The CI builds assembleRelease when the keystore secrets
   exist, so R8 (minify + shrinkResources) runs too.
2. Play tab on the phone (v2.5 layout): the puzzle picker, timer / moves, turn pad, rotate view and settings are in one panel at the
   bottom above Scramble / Reset / AI solve; the top only has the face strip and short messages. Check that the puzzle stays centred between
   the face strip and the panel, that the panel's icon switches (pad, rotate view) light up, and that a drag on the panel does not spin the view.
3. Skewb on the phone: swipe each visible corner piece (triangle) in any direction - it must twist that corner every time; swipe a diamond
   centre; open the turn pad (the grid icon, left of the three icons in the panel row) and press URF / URB / DRF / ULF and their inverses as a fallback.
4. Earlier checks still open: the 3x3 thin lines and pieces turning with their layer, the Pyraminx tip swipes, a drag on the puzzle never
   spinning the view, Train tab live view and thermal presets, Test tab sweeps (Learned AI vs Baseline).

## Ideas, not started
- Continuous finger-following turns (current swipes trigger an animated turn).
- Megaminx / other shapes; a "train only while charging" option; per-puzzle hidden sizes in the settings.

## Rules
- Never touch GitHub. Never claim a test or build happened unless a tool confirmed it.
- Keep CI layout: app/src/main/cpp/jni_bridge.cpp and app/src/main/cpp/core/*.cpp (flat).
