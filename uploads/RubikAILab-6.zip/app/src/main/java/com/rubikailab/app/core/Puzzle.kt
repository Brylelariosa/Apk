package com.rubikailab.app.core

import java.util.Random

/** A dark solid that belongs to one piece of the puzzle and turns together with it. */
class Body(val cx: Float, val cy: Float, val cz: Float, val tris: FloatArray)

/** Static facts about the six puzzles that need no native call (menus, file names). */
object Puzzles {
    const val CUBE2 = 0
    const val CUBE3 = 1
    const val CUBE4 = 2
    const val CUBE5 = 3
    const val PYRAMINX = 4
    const val SKEWB = 5
    const val COUNT = 6

    /** Camera yaw a puzzle starts in, in degrees. The Pyraminx is shown edge-on so two of its faces read clearly. */
    fun viewYaw(id: Int): Float = if (id == PYRAMINX) -42f else -35f

    /** Camera pitch a puzzle starts in, in degrees. */
    fun viewPitch(id: Int): Float = if (id == PYRAMINX) 24f else 28f

    fun title(id: Int): String = when (id) {
        CUBE2 -> "2x2 Cube"
        CUBE3 -> "3x3 Cube"
        CUBE4 -> "4x4 Cube"
        CUBE5 -> "5x5 Cube"
        PYRAMINX -> "Pyraminx"
        else -> "Skewb"
    }

    fun shortTitle(id: Int): String = when (id) {
        CUBE2 -> "2x2"
        CUBE3 -> "3x3"
        CUBE4 -> "4x4"
        CUBE5 -> "5x5"
        PYRAMINX -> "Pyraminx"
        else -> "Skewb"
    }

    fun blurb(id: Int): String = when (id) {
        CUBE2 -> "Pocket cube, 3.6 million states"
        CUBE3 -> "The classic, 43 quintillion states"
        CUBE4 -> "Revenge cube, play only"
        CUBE5 -> "Professor cube, play only"
        PYRAMINX -> "Triangle puzzle, tips included"
        else -> "Corner-turning cube, 3.1 million states"
    }

    /** One line on how to turn this puzzle, shown when it is loaded. */
    fun hint(id: Int): String = when (id) {
        PYRAMINX -> "Swipe a layer or a tip to turn it. Press Scramble to start."
        SKEWB -> "Swipe a corner to twist it. Press Scramble to start."
        else -> "Swipe a layer to turn it. Press Scramble to start."
    }

    /** Puzzles with a learning solver; the bigger cubes have far too many states for a phone. */
    fun aiSupported(id: Int): Boolean = id == CUBE2 || id == CUBE3 || id == PYRAMINX || id == SKEWB

    fun checkpointName(id: Int): String = "checkpoint_" + id + ".bin"
}

/**
 * One puzzle: sticker geometry, the moves (axis, angle, layer) and the move tables, decoded from the
 * native core, which is the single source of truth for both the simulation and the drawing.
 * Immutable, so it can be shared between threads.
 */
class PuzzleModel private constructor(
    val id: Int,
    val name: String,
    val shortName: String,
    val stickers: Int,
    val colors: Int,
    val faces: Int,
    val moves: Int,
    val aiSupported: Boolean,
    val needsCanon: Boolean,
    val defaultMaxDepth: Int,
    val moveNames: Array<String>,
    val aiMoves: IntArray,
    val radius: Float,
    val stickerInset: Float,
    val stickerLift: Float,
    val stickerRound: Float,
    val cornerCount: IntArray,
    val corners: FloatArray,
    val normals: FloatArray,
    val centroids: FloatArray,
    val solvedColors: ByteArray,
    val faceOf: IntArray,
    val axis: FloatArray,
    val angle: FloatArray,
    val lo: FloatArray,
    val hi: FloatArray,
    val table: IntArray,
    val bodies: Array<Body>,
    val core: FloatArray
) {
    /**
     * Moves offered as buttons: the twelve face turns of the small cubes, and the eight corner twists the Skewb's
     * solver uses (the other eight are the same turns seen from the opposite corner).
     */
    val padMoves: IntArray = when (id) {
        Puzzles.CUBE2, Puzzles.CUBE3 -> IntArray(12) { it }
        Puzzles.SKEWB -> IntArray(8) { it }
        else -> IntArray(0)
    }

    /** Moves used to scramble by hand: face turns for the small cubes, every move otherwise. */
    val scrambleMoves: IntArray =
        if (id == Puzzles.CUBE2 || id == Puzzles.CUBE3) IntArray(12) { it } else IntArray(moves) { it }

    val palette: Array<FloatArray> = paletteFor(id, colors)

    private val faceStart = IntArray(faces + 1)
    private val faceList = IntArray(stickers)

    init {
        var n = 0
        for (f in 0 until faces) {
            faceStart[f] = n
            for (i in 0 until stickers) {
                if (faceOf[i] == f) {
                    faceList[n] = i
                    n++
                }
            }
        }
        faceStart[faces] = n
    }

    fun solved(): ByteArray = solvedColors.copyOf()

    /** Returns a new state; [state] is left untouched. */
    fun apply(state: ByteArray, move: Int): ByteArray {
        val out = ByteArray(stickers)
        val base = move * stickers
        for (i in 0 until stickers) out[i] = state[table[base + i]]
        return out
    }

    fun applyAll(state: ByteArray, seq: IntArray): ByteArray {
        var s = state
        for (m in seq) s = apply(s, m)
        return s
    }

    /** Solved = every face is one colour (the puzzle may be turned as a whole, e.g. after a slice move). */
    fun isSolved(state: ByteArray): Boolean {
        for (f in 0 until faces) {
            val b = faceStart[f]
            val e = faceStart[f + 1]
            val c = state[faceList[b]]
            for (k in b + 1 until e) {
                if (state[faceList[k]] != c) return false
            }
        }
        return true
    }

    /** True when the point lies inside the layer that [move] turns. */
    fun inLayer(move: Int, x: Float, y: Float, z: Float): Boolean {
        val p = x * axis[move * 3] + y * axis[move * 3 + 1] + z * axis[move * 3 + 2]
        return p >= lo[move] - LAYER_TOL && p <= hi[move] + LAYER_TOL
    }

    fun inverse(move: Int): Int = move xor 1

    fun format(seq: IntArray): String {
        val sb = StringBuilder()
        for (i in seq.indices) {
            if (i > 0) sb.append(' ')
            sb.append(moveNames[seq[i]])
        }
        return sb.toString()
    }

    /**
     * A random walk over [pool]: never undoes the previous move and never repeats a move three times in a
     * row. Only used to mix the puzzle up; the solver never sees the sequence, only the resulting colours.
     */
    fun scramble(rng: Random, length: Int, pool: IntArray): IntArray {
        val out = IntArray(length)
        var prev = -1
        var prev2 = -1
        for (i in 0 until length) {
            var m: Int
            do {
                m = pool[rng.nextInt(pool.size)]
            } while (prev >= 0 && (m == (prev xor 1) || (m == prev && prev2 == prev)))
            out[i] = m
            prev2 = prev
            prev = m
        }
        return out
    }

    fun scramble(rng: Random, length: Int): IntArray = scramble(rng, length, scrambleMoves)

    companion object {
        private const val LAYER_TOL = 1.0e-3f

        private fun paletteFor(id: Int, colors: Int): Array<FloatArray> {
            val white = floatArrayOf(0.96f, 0.96f, 0.94f)
            val red = floatArrayOf(0.80f, 0.09f, 0.12f)
            val green = floatArrayOf(0.06f, 0.62f, 0.26f)
            val yellow = floatArrayOf(0.98f, 0.80f, 0.08f)
            val orange = floatArrayOf(0.98f, 0.45f, 0.04f)
            val blue = floatArrayOf(0.08f, 0.30f, 0.82f)
            if (id == Puzzles.PYRAMINX) return arrayOf(yellow, blue, red, green)
            val cube = arrayOf(white, red, green, yellow, orange, blue)
            return Array(colors) { cube[it % cube.size] }
        }

        /** Decodes puzzle [id] from the native core; null when the library or the tables are unavailable. */
        fun load(id: Int): PuzzleModel? {
            if (!NativeBridge.ensureLoaded()) return null
            val info = NativeBridge.nativePuzzleInfo(id)
            if (info.size < 13 || info[0] == 0) return null
            val stickers = info[1]
            val colors = info[2]
            val faces = info[3]
            val moves = info[4]
            val strings = NativeBridge.nativePuzzleStrings(id)
            val style = NativeBridge.nativePuzzleStyle(id)
            val st = NativeBridge.nativePuzzleStickers(id)
            val faceIds = NativeBridge.nativePuzzleFaces(id)
            val mv = NativeBridge.nativePuzzleMoves(id)
            val table = NativeBridge.nativePuzzleMoveTable(id)
            if (stickers <= 0 || moves <= 0 || strings.size < 3 || style.size < 4) return null
            if (st.size != stickers * 20 || faceIds.size != stickers) return null
            if (mv.size != moves * 8 || table.size != moves * stickers) return null
            val names = strings[2].split(' ').toTypedArray()
            if (names.size != moves) return null

            val cornerCount = IntArray(stickers)
            val corners = FloatArray(stickers * 12)
            val normals = FloatArray(stickers * 3)
            val centroids = FloatArray(stickers * 3)
            val solved = ByteArray(stickers)
            for (i in 0 until stickers) {
                val o = i * 20
                cornerCount[i] = st[o].toInt()
                for (k in 0 until 12) corners[i * 12 + k] = st[o + 1 + k]
                for (k in 0 until 3) normals[i * 3 + k] = st[o + 13 + k]
                for (k in 0 until 3) centroids[i * 3 + k] = st[o + 16 + k]
                solved[i] = st[o + 19].toInt().toByte()
            }

            val axis = FloatArray(moves * 3)
            val angle = FloatArray(moves)
            val lo = FloatArray(moves)
            val hi = FloatArray(moves)
            var aiCount = 0
            for (m in 0 until moves) {
                val o = m * 8
                axis[m * 3] = mv[o]
                axis[m * 3 + 1] = mv[o + 1]
                axis[m * 3 + 2] = mv[o + 2]
                angle[m] = mv[o + 3]
                lo[m] = mv[o + 4]
                hi[m] = mv[o + 5]
                if (mv[o + 7] > 0.5f) aiCount++
            }
            val ai = IntArray(aiCount)
            var at = 0
            for (m in 0 until moves) {
                if (mv[m * 8 + 7] > 0.5f) {
                    ai[at] = m
                    at++
                }
            }

            val rawBodies = NativeBridge.nativePuzzleBodies(id)
            val bodies = ArrayList<Body>()
            if (rawBodies.isNotEmpty()) {
                val count = rawBodies[0].toInt()
                var p = 1
                for (b in 0 until count) {
                    if (p + 4 > rawBodies.size) return null
                    val cx = rawBodies[p]
                    val cy = rawBodies[p + 1]
                    val cz = rawBodies[p + 2]
                    val tc = rawBodies[p + 3].toInt()
                    p += 4
                    if (tc < 0 || p + tc * 12 > rawBodies.size) return null
                    bodies.add(Body(cx, cy, cz, rawBodies.copyOfRange(p, p + tc * 12)))
                    p += tc * 12
                }
            }

            return PuzzleModel(
                id, strings[0], strings[1], stickers, colors, faces, moves,
                info[5] != 0, info[7] != 0, info[8], names, ai,
                style[0], style[1], style[2], style[3],
                cornerCount, corners, normals, centroids, solved, faceIds,
                axis, angle, lo, hi, table, bodies.toTypedArray(), NativeBridge.nativePuzzleCore(id)
            )
        }
    }
}

/** Lazily decoded puzzles, shared by the whole app. */
object PuzzleCatalog {
    private val cache = arrayOfNulls<PuzzleModel>(Puzzles.COUNT)

    @Synchronized
    fun get(id: Int): PuzzleModel? {
        if (id < 0 || id >= Puzzles.COUNT) return null
        val cached = cache[id]
        if (cached != null) return cached
        val loaded = PuzzleModel.load(id)
        cache[id] = loaded
        return loaded
    }
}
