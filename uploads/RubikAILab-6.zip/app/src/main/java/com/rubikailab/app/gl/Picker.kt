package com.rubikailab.app.gl

import android.opengl.Matrix
import com.rubikailab.app.core.PuzzleModel
import com.rubikailab.app.core.Puzzles
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Turns touches into puzzle actions: which sticker is under a finger, and which move a swipe that
 * starts on that sticker asks for. Works for every puzzle because it only uses the sticker polygons and
 * the move definitions (axis, angle, layer), never any puzzle-specific knowledge.
 *
 * Not thread-safe: use it from the UI thread only.
 */
class Picker(private val model: PuzzleModel) {
    private val pv = FloatArray(16)
    private val orbit = FloatArray(16)
    private val mvp = FloatArray(16)
    private val inv = FloatArray(16)
    private val vecIn = FloatArray(4)
    private val vecOut = FloatArray(4)
    private val origin = FloatArray(3)
    private val far = FloatArray(3)
    private val dir = FloatArray(3)
    private val s0 = FloatArray(2)
    private val s1 = FloatArray(2)
    private var width = 1
    private var height = 1
    private var valid = false

    /** How many stickers each move carries: of two layers that follow a drag equally well, the smaller one wins. */
    private val layerSize = IntArray(model.moves)
    private val scores = FloatArray(model.moves)

    init {
        for (m in 0 until model.moves) {
            var count = 0
            for (i in 0 until model.stickers) {
                if (model.inLayer(m, model.centroids[i * 3], model.centroids[i * 3 + 1], model.centroids[i * 3 + 2])) count++
            }
            layerSize[m] = count
        }
    }

    /** Call before picking whenever the view size or the camera angle may have changed. */
    fun setCamera(viewWidth: Int, viewHeight: Int, yaw: Float, pitch: Float, freeTop: Float, freeBottom: Float) {
        width = maxOf(1, viewWidth)
        height = maxOf(1, viewHeight)
        Camera.projectionView(pv, width, height, model.radius, freeTop, freeBottom)
        Camera.orbit(orbit, yaw, pitch)
        Matrix.multiplyMM(mvp, 0, pv, 0, orbit, 0)
        valid = Matrix.invertM(inv, 0, mvp, 0)
    }

    private fun unproject(sx: Float, sy: Float, ndcZ: Float, out: FloatArray) {
        vecIn[0] = 2f * sx / width - 1f
        vecIn[1] = 1f - 2f * sy / height
        vecIn[2] = ndcZ
        vecIn[3] = 1f
        Matrix.multiplyMV(vecOut, 0, inv, 0, vecIn, 0)
        val w = if (abs(vecOut[3]) > 1.0e-9f) vecOut[3] else 1.0e-9f
        out[0] = vecOut[0] / w
        out[1] = vecOut[1] / w
        out[2] = vecOut[2] / w
    }

    /** Screen position (pixels, y down) of a point of the puzzle. */
    private fun project(x: Float, y: Float, z: Float, out: FloatArray) {
        vecIn[0] = x
        vecIn[1] = y
        vecIn[2] = z
        vecIn[3] = 1f
        Matrix.multiplyMV(vecOut, 0, mvp, 0, vecIn, 0)
        val w = if (abs(vecOut[3]) > 1.0e-9f) vecOut[3] else 1.0e-9f
        out[0] = (vecOut[0] / w * 0.5f + 0.5f) * width
        out[1] = (1f - (vecOut[1] / w * 0.5f + 0.5f)) * height
    }

    /** The front-most sticker under the screen point, or -1. */
    fun pick(sx: Float, sy: Float): Int {
        if (!valid) return -1
        unproject(sx, sy, -1f, origin)
        unproject(sx, sy, 1f, far)
        var dx = far[0] - origin[0]
        var dy = far[1] - origin[1]
        var dz = far[2] - origin[2]
        val len = sqrt(dx * dx + dy * dy + dz * dz)
        if (len < 1.0e-9f) return -1
        dx /= len
        dy /= len
        dz /= len
        dir[0] = dx
        dir[1] = dy
        dir[2] = dz

        var best = -1
        var bestT = Float.MAX_VALUE
        for (i in 0 until model.stickers) {
            val nx = model.normals[i * 3]
            val ny = model.normals[i * 3 + 1]
            val nz = model.normals[i * 3 + 2]
            val denom = dx * nx + dy * ny + dz * nz
            if (denom > -1.0e-5f) continue // facing away from the camera
            val cx = model.centroids[i * 3]
            val cy = model.centroids[i * 3 + 1]
            val cz = model.centroids[i * 3 + 2]
            val t = ((cx - origin[0]) * nx + (cy - origin[1]) * ny + (cz - origin[2]) * nz) / denom
            if (t < 0f || t >= bestT) continue
            val px = origin[0] + dx * t
            val py = origin[1] + dy * t
            val pz = origin[2] + dz * t
            if (inside(i, px, py, pz)) {
                best = i
                bestT = t
            }
        }
        return best
    }

    /** Point-in-polygon for the (convex, counter-clockwise from outside) sticker polygon. */
    private fun inside(i: Int, px: Float, py: Float, pz: Float): Boolean {
        val n = model.cornerCount[i]
        val nx = model.normals[i * 3]
        val ny = model.normals[i * 3 + 1]
        val nz = model.normals[i * 3 + 2]
        for (k in 0 until n) {
            val a = i * 12 + k * 3
            val b = i * 12 + ((k + 1) % n) * 3
            val ex = model.corners[b] - model.corners[a]
            val ey = model.corners[b + 1] - model.corners[a + 1]
            val ez = model.corners[b + 2] - model.corners[a + 2]
            val rx = px - model.corners[a]
            val ry = py - model.corners[a + 1]
            val rz = pz - model.corners[a + 2]
            val cx = ey * rz - ez * ry
            val cy = ez * rx - ex * rz
            val cz = ex * ry - ey * rx
            if (cx * nx + cy * ny + cz * nz < -1.0e-4f) return false
        }
        return true
    }

    /**
     * The move that carries [sticker] in the direction of the screen drag (dx, dy), or -1 when no layer
     * through that sticker moves it that way. Candidates are the layers that contain the sticker; each
     * one's velocity at the sticker is projected to the screen and compared with the drag. Turning the
     * very face the sticker sits on is slightly disfavoured, so a drag along a row turns that row. When
     * several layers follow the drag equally well (the tip of a Pyraminx and the layers around it all turn
     * the same way) the smallest one is chosen, so a tip can be turned on its own from its own stickers. On the
     * Skewb a swipe on a corner always twists that corner, and no swipe is dead (see the comments below).
     */
    fun swipeMove(sticker: Int, dx: Float, dy: Float): Int {
        if (!valid || sticker < 0) return -1
        val dl = sqrt(dx * dx + dy * dy)
        if (dl < 1.0e-3f) return -1
        val cx = model.centroids[sticker * 3]
        val cy = model.centroids[sticker * 3 + 1]
        val cz = model.centroids[sticker * 3 + 2]
        val nx = model.normals[sticker * 3]
        val ny = model.normals[sticker * 3 + 1]
        val nz = model.normals[sticker * 3 + 2]
        project(cx, cy, cz, s0)
        val startX = s0[0]
        val startY = s0[1]

        scores.fill(NO_SCORE)
        var top = NO_SCORE
        for (m in 0 until model.moves) {
            if (!model.inLayer(m, cx, cy, cz)) continue
            val ax = model.axis[m * 3]
            val ay = model.axis[m * 3 + 1]
            val az = model.axis[m * 3 + 2]
            // Velocity of the sticker under a positive (counter-clockwise, right-hand) rotation about the axis.
            var vx = ay * cz - az * cy
            var vy = az * cx - ax * cz
            var vz = ax * cy - ay * cx
            if (model.angle[m] < 0f) {
                vx = -vx
                vy = -vy
                vz = -vz
            }
            val vl = sqrt(vx * vx + vy * vy + vz * vz)
            if (vl < 1.0e-3f) continue // the sticker sits on the axis: this move does not carry it anywhere
            val k = 0.25f / vl
            project(cx + vx * k, cy + vy * k, cz + vz * k, s1)
            val ex = s1[0] - startX
            val ey = s1[1] - startY
            val el = sqrt(ex * ex + ey * ey)
            if (el < 1.0e-3f) continue
            var score = (dx * ex + dy * ey) / (dl * el)
            if (abs(ax * nx + ay * ny + az * nz) > 0.9f) score *= FACE_PENALTY
            scores[m] = score
            if (score > top) top = score
        }
        // Skewb: a swipe on a corner piece (a triangle) always twists that very corner, whichever way the finger goes.
        // The turn about the axis through the corner is the only one that corner needs, and the drag only decides
        // clockwise or counter-clockwise (the way the sticker travels on screen). Before, a drag away from that
        // path fell through to a neighbouring corner's turn, so the corner you touched seemed stuck.
        if (model.id == Puzzles.SKEWB && model.cornerCount[sticker] == 3) {
            var own = -1
            var ownDist = Float.MAX_VALUE
            for (m in 0 until model.moves) {
                if (scores[m] == NO_SCORE) continue
                val d = axisDistance(m, cx, cy, cz)
                if (d < ownDist - 1.0e-4f) {
                    ownDist = d
                    own = m
                }
            }
            if (own >= 0) {
                val other = own xor 1
                if (scores[other] != NO_SCORE) return if (scores[own] >= scores[other]) own else other
            }
        }
        // The Skewb has no dead zone: a swipe on a centre piece turns the best-matching corner, however oblique.
        val floor = if (model.id == Puzzles.SKEWB) 0f else MIN_ALIGNMENT
        if (top < floor) return -1
        var best = -1
        for (m in 0 until model.moves) {
            if (scores[m] >= top - TIE_MARGIN && (best < 0 || layerSize[m] < layerSize[best])) best = m
        }
        return best
    }

    /** Squared distance of a point from the axis line of [m]. */
    private fun axisDistance(m: Int, cx: Float, cy: Float, cz: Float): Float {
        val ax = model.axis[m * 3]
        val ay = model.axis[m * 3 + 1]
        val az = model.axis[m * 3 + 2]
        val dot = (cx * ax + cy * ay + cz * az) / sqrt(ax * ax + ay * ay + az * az)
        return cx * cx + cy * cy + cz * cz - dot * dot
    }

    private companion object {
        /** A drag within about 80 degrees of a layer's direction still turns that layer. */
        const val MIN_ALIGNMENT = 0.17f
        const val FACE_PENALTY = 0.7f
        const val TIE_MARGIN = 0.02f
        const val NO_SCORE = -2f
    }
}
