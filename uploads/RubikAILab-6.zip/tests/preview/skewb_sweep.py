"""Sweeps the camera over many views and checks the Skewb swipe rule (a Python port of Picker.kt, see picker_check.py):
a swipe on a corner piece (triangle) must always twist that corner, and no swipe on any visible sticker may be dead.
Usage: skewb_sweep.py <dir with geo_5.txt>   (make the geometry file with dump_geometry, see BUILD.md)"""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import preview as P
import picker_check as PC

g = P.load(os.path.join(PC.GEO_DIR, 'geo_5.txt'))
W, H, FREE_TOP, FREE_BOTTOM = 810, 1800, 230, 335      # a tall phone with the bars in place
sizes = PC.layer_sizes(g)
views = corner_drags = corner_own = corner_dead = centre_drags = centre_dead = misses = 0
for yaw in range(-180, 180, 15):
    for pitch in range(-85, 86, 15):
        views += 1
        O = P.orbit(yaw, pitch); M = P.camera(W, H, g['radius'], FREE_TOP, FREE_BOTTOM) @ O; Minv = np.linalg.inv(M)
        for i, s in enumerate(g['stickers']):
            if np.dot(O[:3, :3] @ s['normal'], [0, 0, 1.0]) <= 0.05: continue          # not facing the camera
            sp = PC.project(M, s['centroid'], W, H)
            if PC.pick(g, M, Minv, sp[0], sp[1], W, H) != i: misses += 1; continue      # sliver at a grazing angle
            own = PC.own_corner_move(g, s['centroid'], {m: 0 for m in range(len(g['moves'])) if P.in_layer(g, m, s['centroid'])}) if s['n'] == 3 else -1
            for k in range(36):
                a = 2 * math.pi * (k + 0.5) / 36
                mv = PC.swipe(g, M, W, H, i, 40 * math.cos(a), 40 * math.sin(a), sizes)
                if s['n'] == 3:
                    corner_drags += 1
                    if mv < 0: corner_dead += 1
                    elif mv == own or mv == (own ^ 1): corner_own += 1
                else:
                    centre_drags += 1
                    if mv < 0: centre_dead += 1
print(f"{views} camera views, 36 drag directions per visible sticker ({misses} grazing stickers skipped: their centre does not pick them)")
print(f"corner drags: {corner_drags}, twist the touched corner {corner_own} ({corner_own / corner_drags * 100:.1f}%), dead {corner_dead}")
print(f"centre drags: {centre_drags}, dead {centre_dead}")
ok = corner_own == corner_drags and corner_dead == 0 and centre_dead == 0
print("OK" if ok else "FAILED")
sys.exit(0 if ok else 1)
