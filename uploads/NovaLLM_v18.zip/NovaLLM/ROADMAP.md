# NovaLLM build order

Custom text-only LLM for Android. No TensorFlow, no ONNX, no third-party ML
framework — every piece below is hand-written C++, compiled via NDK, called
through a thin JNI bridge. Built one subsystem at a time, verified on-device
before moving to the next.

Name/package (`com.jarry.novallm`) is a placeholder — rename `applicationId`/
`namespace` in `app/build.gradle` and the `com/jarry/novallm` folder anytime.

## Status

- [x] **1. core/math** — Tensor, Matrix (matmul/add/transpose/addBias/scale), MemoryPool.
      Naive O(n^3) matmul, correctness-first. Verified with a standalone g++
      test suite (`tests/test_math.cpp`) AND on-device via the JNI test button
      in the shipped APK.
- [x] **2. core/tokenizer** — UTF8 (decode/validate), Vocabulary (256 base
      byte tokens + growable), BPE (train + greedy lowest-rank encode),
      Tokenizer facade (train/encode/decode/save/load). Byte-level, so
      there is no "unknown token" case - anything not covered by a learned
      merge just stays as raw byte tokens and still round-trips exactly.
      No pretokenization step yet (whole byte stream is one BPE sequence,
      not pre-split on whitespace) - simpler and still fully correct, just
      leaves some compression quality on the table; worth revisiting once
      the rest of the pipeline exists to actually benefit from it.
      Verified with a standalone g++ test suite (`tests/test_tokenizer.cpp`,
      24 checks) AND on-device via a second JNI test button.
- [x] **3. core/embedding** — TokenEmbedding (learned {vocabSize, embedDim}
      lookup table, GPT-2-style small Gaussian init, single + sequence
      lookup) and PositionalEncoding (fixed sinusoidal table, `applyTo()`
      adds it to embeddings). RoPE is intentionally NOT here - it rotates
      Q/K vectors inside attention, so it belongs in core/transformer once
      attention exists, not at the embedding stage. Verified with a
      standalone g++ suite (`tests/test_embedding.cpp`, 33 checks) AND
      on-device via a third JNI button that chains the real pipeline:
      text -> trained tokenizer -> ids -> embeddings -> +positional encoding.
- [x] **4. core/transformer** — Linear (shared weight+bias layer),
      LayerNorm, FeedForward (GELU, tanh approximation), MultiHeadAttention
      (causal, scaled dot-product, head split/merge via new
      `matrix::sliceColumns`/`setColumns`), TransformerBlock (pre-norm:
      x -> LN -> Attn -> +x -> LN -> FFN -> +). Residual connections are
      just `matrix::add()` calls, not a separate class - no Residual.cpp on
      purpose. KVCache is deferred to core/runtime (subsystem 6) since it's
      a generation-loop optimization, not a correctness requirement for a
      single forward pass.
      Verified with a standalone g++ suite (`tests/test_transformer.cpp`,
      19 checks) that includes the single most important correctness test
      in the project so far: changing only the LAST token in a sequence
      must leave every earlier position's output byte-for-byte identical.
      That held both at the raw attention level and end-to-end through the
      full block. Also verified by actually *executing* jni_bridge.cpp's
      real exported functions locally against a stubbed JNI env (not just
      compiling them) before this ever reached device, and on-device via a
      fourth JNI button running the same causal-leakage check with real
      random weights.
- [x] **5. core/decoder** — Model (stacks TokenEmbedding + N TransformerBlocks
      + final LayerNorm + LM head into one forward pass; "Logits" is just
      its {seqLen, vocabSize} output shape, not a separate class), Sampling
      (temperature -> softmax -> top-k -> top-p -> renormalize -> sample;
      temperature=0 is deterministic greedy argmax), Generator (the actual
      autoregressive loop: encode prompt, repeatedly forward+sample+append,
      decode). No KV cache yet (subsystem 6) - every new token recomputes
      the whole forward pass, correct but O(n^2). Text generation is now
      real and running end to end, but weights are untrained (random), so
      output is structurally correct gibberish until subsystem 7 exists -
      that's expected, not a bug.
      One real hazard caught here: sampling can select ANY byte-level
      token, so generated text can contain embedded nulls / invalid UTF-8.
      Handing that straight to JNI's `NewStringUTF` was unsafe (silent
      truncation at minimum, undefined behavior at worst) - added
      `escapeForDisplay()` in jni_bridge.cpp so raw bytes are always shown
      safely (confirmed necessary: the on-device run's output did contain
      non-printable bytes).
      Verified with a standalone g++ suite (`tests/test_decoder.cpp`, 8
      checks - including re-proving causality at the full multi-layer
      model level, greedy determinism, top-k/top-p edge behavior, and an
      empirical sampling-distribution check against known softmax
      probabilities) AND by actually executing all five JNI functions
      locally against the stub before this ever reached device.
- [x] **6. core/runtime** — split into two independently-verified halves:
      **Model save/load** (fulfills "ModelLoader" from the original list -
      it's methods on Model itself, not a separate class, same reasoning
      as Residual/Logits earlier): every learned-parameter class
      (Tensor -> Linear -> LayerNorm -> TokenEmbedding -> MultiHeadAttention
      -> FeedForward -> TransformerBlock -> Model) now has stream-based
      save/load, composed hierarchically. Generation cache state is
      deliberately NOT persisted - it's ephemeral per-sequence state, not
      a learned parameter.
      **KVCache** (fulfills "Cache" from the original list; lives in
      core/transformer/ since it's tightly coupled to attention, not
      core/runtime/) - one per layer, appends new K/V and serves the full
      cached history back for attention. `MultiHeadAttention::
      forwardIncremental()` and `TransformerBlock::forwardIncremental()`
      use it; LayerNorm/FeedForward needed no changes since they're
      already position-wise. `PositionalEncoding::encodeRange()` was
      required too - new tokens sit at their TRUE sequence position, not
      position 0, and getting that wrong would silently produce a broken
      model rather than crash. `Generator` now actually uses this path.
      Scheduler/ThreadPool/Quantization from the original runtime/ list
      are correctly deferred to subsystem 8 (Android optimization pass),
      not forgotten.
      Verification for this subsystem went further than usual given how
      easy KV-cache position bugs are to get subtly wrong: KVCache was
      tested in isolation first, then the standalone suite
      (`tests/test_decoder.cpp`, now 13 checks) directly compares
      KV-cached incremental output against the already-trusted non-cached
      forward() - both token-by-token AND whole-prompt-priming - and
      confirms save/load round-trips bit-for-bit. Every prior subsystem's
      test suite was re-run after these changes with zero regressions.
      On-device (sixth button): save/load round trip PASS, KV cache
      exactness PASS, and a real speed comparison - generating 40 tokens
      took 85ms non-cached vs 8ms KV-cached on-device, roughly 10x, even
      on this tiny model.
- [x] 7. **training** — dataset loader, loss (cross-entropy), backprop, optimizer (start with plain SGD or Adam), checkpointing
- [ ] 8. **Android optimization pass** — memory pool wiring, int8 quantization, and a thread pool are all done (see
      below); NEON SIMD is the one piece still ahead.

## Versioning

Zip filenames and `versionName`/`versionCode` in `app/build.gradle` are now
tied to subsystem count (v7 = subsystems 1-6 done + training part 1) so
it's obvious which delivery is which. Bumps each time a zip goes out.

## APK size pass (alongside subsystem 7)

No feature removed, no ABI split (still one universal apk, not multiple
per-architecture outputs):

- Dropped `androidx.appcompat` + `androidx.core:core-ktx` entirely - never
  actually used beyond one theme string and `.apply{}` (Kotlin stdlib, not
  core-ktx). `MainActivity` is now a plain `Activity`, manifest theme is a
  built-in platform theme.
- `abiFilters` restricted to `arm64-v8a` only - your Hot 11 is 64-bit: this
  was compiling every subsystem's C++ twice for an architecture nothing
  here uses. Add `armeabi-v7a` back if you ever test on a 32-bit device.
- `ANDROID_STL` switched from `c++_shared` to `c++_static` - with exactly
  one native lib in this app, static linking drops the separate
  libc++_shared.so and only pulls in the libc++ pieces actually used.
- Native symbols now explicitly stripped at link time (`-s`) regardless of
  buildType. This mattered more than expected: **your CI builds
  `assembleDebug` by default (no keystore secret configured)**, and AGP
  does not strip native debug info from debug builds the way it does for
  release - every .so shipped so far has been carrying full debug symbols.
- `minifyEnabled`/`shrinkResources` enabled on the `debug` buildType
  specifically (not just `release`), since debug is what your pipeline
  actually produces. Added `proguard-rules.pro` with an explicit keep rule
  for `MainActivity`'s native methods - R8 renaming the JNI-bound class or
  an `external fun` wouldn't fail the build, it'd fail at runtime with
  `UnsatisfiedLinkError` the first time a button is tapped, silently past
  compile time. Worth knowing about if any *future* class ever needs
  reflection or name-based lookup too.

Can't measure the actual before/after size in this sandbox (no Android
SDK/NDK here) - compare the artifact size in your next Actions run against
a previous one.

## Training (subsystem 7) - part 1 of N

Backprop through a whole transformer is the single biggest remaining
subsystem, so it's being built in verified slices rather than one pass.
This slice: gradient-check infrastructure, plus backward() for everything
that ISN'T attention (attention's backward - through softmax, causal
masking, and the multi-head split - is real enough to deserve its own
focused pass, not to be rushed alongside everything else).

- [x] `core/training/GradientCheck.h` - numerical gradient checking via
      central differences, the standard way to verify a hand-written
      backward pass. Every backward() below is checked against this.
- [x] `Linear::backward`, `LayerNorm::backward` - both add a `Grads`
      struct and a `backward(x, gradOutput)` method alongside `forward()`.
- [x] `geluGrad()` alongside `gelu()`.
- [x] `FeedForward::backward` - composes `Linear::backward` on both
      layers through `geluGrad`, recomputing the fc1/gelu intermediate
      rather than caching it from forward() (simpler interface, one
      redundant fc1 pass per backward call).
- [x] `core/training/Loss.h` - `CrossEntropyLoss::forwardBackward()`,
      combining softmax+cross-entropy analytically for the classic
      `probs - one_hot(target)` gradient, reusing `matrix::softmaxRows`
      for the third time now.
- [x] **Attention backward** (softmax + causal mask + multi-head
      split/merge) - the hardest piece, deliberately its own pass. Added
      `wq()`/`wk()`/`wv()`/`wo()` accessors on `MultiHeadAttention` and
      `fc1()`/`fc2()` on `FeedForward` (not just for testing - the
      optimizer will need to reach every parameter the same way). Softmax
      backward is the standard `weights * (gradWeights - dot(gradWeights,
      weights))` per row; causally-masked positions have weight~=0 after
      softmax, so their gradient is automatically ~0 too - no separate
      re-masking needed in the backward direction. All 9 gradient checks
      (gradInput + all four projections' weights/biases) passed on the
      FIRST attempt with comfortable margin, no debugging needed - a
      strong sign the portable-RNG and dot-product-loss lessons from the
      earlier layers were worth codifying rather than relearning each time.
      Added a new kind of structural check specific to backward passes:
      if gradOutput is nonzero ONLY at position j, then gradInput at any
      position >j must be EXACTLY zero (position k's output only ever
      depended on positions <=k). Passed cleanly.
- [x] **`TransformerBlock::backward`** - composes all four sublayers
      through the residual connections (gradient simply sums at each
      residual junction, `d(a+b)/da = d(a+b)/db = 1`). Initially "failed"
      weight-gradient checks by 4-10% at the standard 1e-3 epsilon; swept
      epsilon from 1e-1 to 1e-5 and found the error dropped monotonically
      as epsilon *grew* (the opposite of curvature bias) - this deeper
      LN->Attn->LN->FFN chain accumulates enough float32 rounding that
      1e-3 is too small a perturbation for the signal to clear the noise
      floor. 1e-2 gives clean, comfortable convergence. Not a bug; a
      continuation of the same epsilon-must-match-computation-depth
      lesson LayerNorm taught earlier, now confirmed at a second, deeper
      scale. The causal structural check holds end-to-end through the
      full block too.
      Both are wired into the existing "Run Training Test" button
      (extended, not a new button) and into standalone
      `tests/test_attention.cpp` / `tests/test_block.cpp`. Zero
      regressions across every prior subsystem.
- [x] **Embedding backward** - scatter-ADD into the {vocabSize, embedDim}
      table: `gradWeights[tokenIds[i]] += gradOutput[i]` per position, not
      a set, since a repeated token id must accumulate contributions from
      every occurrence. No `gradInput` in the usual sense - token ids are
      discrete, not differentiable. Verified via gradient check (passed
      first attempt) plus two structural checks that need no numerics at
      all: unused token rows are EXACTLY zero, and the repeated-id
      accumulation was verified by direct construction (not finite
      differences) - sum the gradient contributions from both positions
      that used the same id by hand, compare bit-for-bit.
- [x] **Full `Model::backward()`** - embedding -> N blocks (reverse order)
      -> final norm -> LM head, all composed. PositionalEncoding has no
      learnable parameters, so the gradient reaching "x before the
      blocks" flows entirely into the embedding table - nothing splits or
      gets lost there. Deepest chain tested yet; needed epsilon=3e-2
      (vs. 1e-2 at the block level, 1e-3 for individual layers) for clean
      convergence - the same accumulating-rounding-noise pattern as
      before, now confirmed at a third, even deeper scale.
      Added the single most convincing check in the whole training
      subsystem: took the real gradient from `Model::backward()`, applied
      one small manual gradient-descent step to every parameter in the
      model (embedding, every block's every sublayer, final norm, LM
      head), and confirmed the loss actually decreased
      (2.51361 -> 2.42796 locally; matched almost exactly on-device too).
      This needs no precise numerical matching at all - it's a macro-level
      proof that every sign and direction throughout the entire composed
      pipeline (embedding, attention, FFN, norm, LM head, cross-entropy)
      is simultaneously correct. If anything upstream had a sign error,
      this would fail outright rather than just show a slightly-too-large
      relative error the way the finite-difference checks might.
      Added `tokenEmbedding()`, `block(i)`/`numBlocks()`, `finalNorm()`,
      `lmHead()` accessors on `Model` - not just for testing, this is the
      exact traversal the optimizer will need to update every parameter.
      All wired into the existing "Run Training Test" button and into
      `tests/test_embedding_backward.cpp` / `tests/test_model_backward.cpp`.
      Zero regressions across all 8 test suites.
- [x] **Optimizer (Adam)** - standard algorithm (Kingma & Ba 2014), one
      `Adam` instance per learnable tensor with its own persistent
      per-element momentum/variance state. `ModelOptimizer` holds one per
      parameter in the whole model, structured to mirror `Model::Grads`'s
      exact nesting (`LinearOptState`/`LayerNormOptState`/
      `AttentionOptState`/`FeedForwardOptState`/`BlockOptState`) so the
      traversal can be audited side-by-side against `Model::backward()` -
      if either is missing a parameter, the mismatch is visible by
      comparison, not just by a symptom later. Verified first in complete
      isolation (minimize `f(x)=(x-3.7)^2`, confirmed convergence to
      within 1e-3 over 200 steps) before trusting it anywhere near the
      real model - well-known algorithm, but transcription errors are
      still a real risk worth checking for directly.
- [x] **A real multi-step training loop.** Not a demo of the mechanism in
      the abstract - an actual training run: tiny model, tiny tokenizer,
      one repeated phrase ("the quick brown fox..."), 300 steps of
      forward -> `CrossEntropyLoss` -> `Model::backward` -> `Adam` update.
      Loss: **5.665 -> 0.00027**. Generated output before training was
      structurally-correct gibberish (as expected, untrained weights);
      after training, greedy sampling reproduces the phrase exactly. This
      is the classic "can the pipeline even memorize a handful of
      examples" sanity check every ML engineer runs before trusting a
      training loop on anything bigger - and it passed clean on the first
      real run, with every number matching exactly between local testing
      and the actual on-device JNI execution.
      New button: "Run Mini Training Demo" (separate from "Run Training
      Test" - one verifies gradients are mathematically correct, the
      other proves the whole system actually learns). ~0.7s locally
      unoptimized; the shipped APK compiles with `-O2`, so meaningfully
      faster on-device - confirmed safely under Android's ANR threshold.
      Also caught and fixed the same "generated text isn't valid UTF-8"
      hazard from the decoder subsystem, now showing up in this new
      code path too - reused `escapeForDisplay()`.
- [x] **Dataset loader.** Reads raw text (not a file path - see below),
      tokenizes it, and chunks the token stream into non-overlapping
      next-token-prediction examples of up to `maxSeqLen` tokens each
      (`ex.ids`/`ex.targets`, shifted by one; last chunk may be shorter,
      no padding needed since Model/CrossEntropyLoss already handle
      variable lengths). Verified the chunk boundaries and the
      input/target shift relationship by reconstructing the full token
      stream from all chunks and comparing against a direct `encode()`
      call, not just spot-checking a couple of values.
      Deliberately takes a `std::string`, not a file path: Android assets
      (bundled into the APK) aren't reachable through plain
      `std::ifstream` the way `cacheDir` files are - they live inside the
      APK's own container and need `AAssetManager`, not POSIX file I/O.
      Kotlin reads the asset and passes the text down through JNI, the
      same pattern `cacheDir` already established for save/load. Keeps
      Android-specific file access out of core/ entirely.
- [x] **`train()`** - the reusable training loop (`core/training/Trainer.h`):
      for each epoch, for each example, forward -> `CrossEntropyLoss` ->
      `Model::backward` -> `ModelOptimizer::step`, with an optional
      `onStep(step, loss)` callback for progress reporting and optional
      periodic checkpointing via the existing `Model::save()`. No new
      class needed beyond a config struct and a free function - the
      pieces built over the last several passes were already clean enough
      that this is mostly composition, not new design.
      Real multi-example run (ten short thematically-related sentences,
      not one repeated phrase): loss 5.757 -> 0.014 over 22 epochs.
      Generated output moved from gibberish to genuinely recalling a
      specific training sentence based on the prompt ("the sun" ->
      "...stars fill the sky when the sun goes down", with a small
      blending artifact at a sentence boundary - exactly what a tiny
      model overfitting hard on limited data looks like, and a more
      convincing demo than memorizing one string).
      New button: "Run Full Training Demo", reading a bundled
      `assets/training_corpus.txt` (original text, written for this
      project - ten simple declarative sentences with consistent
      structure, giving a tiny model an actual chance of learning
      something recognizable) through the asset->JNI path above.
      **Correctness fix caught here, not after the fact:** this run took
      12s unoptimized locally - long enough to risk Android's ANR
      watchdog if run on the main thread, which the earlier "Run Mini
      Training Demo" button actually was (`resultView.post{}` only defers
      by one frame, it doesn't move work off the UI thread - that button
      shipped in v12 with real, if smaller, risk of exactly this).
      Fixed both training buttons to genuinely run on a background
      `Thread`, posting the result back via `runOnUiThread`. Trimmed to
      22 epochs (~6.7s locally) as a secondary UX improvement, but the
      thread fix is what actually makes this safe regardless of corpus
      size or epoch count - which matters once real text is involved,
      since he'll likely want to scale both up himself.
- [x] **Checkpointing, actually exercised on-device.** "Run Full Training
      Demo" now trains in two phases: phase 1 (11 epochs) checkpoints
      automatically via the real mechanism (`TrainingConfig.
      checkpointEverySteps` -> `train()`'s internal `Model::save()` call,
      not a manual save bypassing it), then a fresh `Model::load()` from
      that file is generated from and compared BYTE-FOR-BYTE against the
      live in-memory model at that exact moment - the strongest possible
      test that a checkpoint captured the real trained state, not just
      "didn't crash." Passed exactly. Training then continues on the same
      live model+optimizer for phase 2 (11 more epochs), proving a
      mid-run checkpoint doesn't disrupt anything: loss kept dropping
      cleanly afterward (3.376 -> 0.011 over the second half).
      Scope boundary worth being explicit about: only MODEL WEIGHTS are
      checkpointed, not optimizer state. Adam's per-parameter momentum/
      variance carries across the phase 1/phase 2 boundary here only
      because it's the same in-memory `ModelOptimizer` object continuing
      - a real resume in a NEW app session would start Adam fresh, which
      still works, just without that warm start. Saving/restoring
      optimizer state too is a real, separate feature, not implemented.
      `nativeRunFullTrainingDemo` now takes a `cacheDir` parameter
      (same pattern as the runtime test) for a real checkpoint path.

### A mid-session environment reset, and what recovery looked like

While finishing this checkpointing work, the whole sandbox filesystem
reset - `/home/claude` came back empty, mid-development. The only
surviving artifact was the last shipped zip (v13) in the persistent
output mount. Recovery: extracted v13 as the known-good base, then
re-applied the checkpointing edits from scratch using the exact
content already produced earlier in the same session (the tool-call
history itself was the source of truth, not memory of what the code
should say). Re-ran the exact same on-device-equivalent test
afterward and it produced bit-for-bit identical output to the
pre-reset run - strong confirmation the recovery was exact, not just
plausible-looking. Full regression sweep across every subsystem
confirmed zero regressions from the recovery process itself.
Practical upshot: shipping this as its own version now, before
starting the larger NEON SIMD work, rather than risking a bigger
chunk of unshipped work to a repeat of the same failure mode.

### A debugging detour worth recording

Every backward pass above initially "failed" gradient checking, and none
of those failures were real - all four were fixed without touching a
single line of backward-pass math:

1. **The checker itself had a bug.** Its near-zero handling
   (`denom < 1e-8f`) was far tighter than the actual float32 noise floor
   of central-difference estimation. When a true gradient is exactly 0,
   the numerical estimate lands on tiny rounding noise (~1e-6), not exact
   0 - dividing by a near-zero denominator turned that harmless noise into
   a misleading ~100% relative error. Fixed by flooring the denominator at
   1e-3 instead of branching on it.
2. **Clean/symmetric test inputs are actively bad for gradient checking.**
   Arithmetic-sequence x values combined with a uniform gradOutput
   (loss = sum(output)) kept coincidentally producing true gradients that
   are genuinely tiny for specific dimensions - not a bug, just an
   unlucky test fixture, but tiny-true-gradient cases are exactly where
   finite-difference noise reads as a large *relative* error even after
   fix #1. Switched every check to pseudo-random x AND a pseudo-random
   loss direction (`loss = dot(output, random_vector)`), which essentially
   never produces an exact-zero true gradient by coincidence.
3. **Finite-difference epsilon needs to match the computation's local
   curvature scale**, not be a fixed global constant. Confirmed by sweeping
   epsilon from 1e-1 to 1e-6 against LayerNorm and watching the
   numerical/analytical ratio go 0.01 -> 0.56 -> 0.96 -> 0.84 -> 0.22 ->
   -0.07 - too large an epsilon picks up second-order curvature the
   analytical (first-derivative) gradient doesn't include; too small and
   float32 rounding dominates. 1e-3 was the sweet spot here.
4. **Longer computation chains need more tolerance, not more suspicion.**
   CrossEntropy (softmax: exp, sum, divide, then log) accumulates more
   float32 rounding than a single matmul. 21/24 sampled elements matched
   under 1%; the rest were small-magnitude gradients where a couple
   percent of noise is expected. Confirmed independently via a
   numerical-precision-free structural check (gradient sign must be
   negative at the target class, positive elsewhere) before loosening the
   tolerance, specifically to rule out "loosened the threshold to hide a
   real bug."

Net lesson for the rest of training: random test data, floored/relative
error with a sane denominator floor, and tolerance scaled to how many
operations are actually chained - all four apply directly to the harder
attention-backward pass coming next.

### v8: on-device failures found by actual testing

Real device run (ARM64, `-O2`, `-DCMAKE_BUILD_TYPE=Release`) failed two of
the five training checks that passed cleanly on the x86_64/unoptimized
desktop build: LayerNorm backward and CrossEntropyLoss backward. Linear,
GELU, and FeedForward all passed on-device too - and those three had the
most margin locally, while the two that failed had the least. That
pattern (comfortable-margin checks survive, tight-margin checks don't) is
consistent with cross-platform/optimization floating-point variance
tipping an already-close-to-threshold comparison over the edge, not two
unrelated implementations suddenly being wrong - but it isn't proof.

Response, in order of how much confidence each part deserves:
- Added a **precision-independent structural check** for each: LayerNorm's
  gradInput must sum to exactly zero per row (an algebraic consequence of
  LayerNorm being invariant to constant shifts, not a finite-difference
  estimate); CrossEntropy's gradient must be negative at the target class
  and positive elsewhere (a sign relationship, immune to magnitude noise).
  Both passed in local re-testing. These are the most trustworthy new
  signal - if they ever fail on-device where the numerical check doesn't,
  that's strong evidence of a real bug rather than platform noise.
- Widened numerical tolerances (1e-2 -> 2e-2 for Linear/LayerNorm/
  FeedForward/GELU, 3e-2 -> 5e-2 for CrossEntropy) and now print the
  actual error value alongside PASS/FAIL instead of just a verdict, so
  any future on-device failure comes with real diagnostic data instead of
  a bare "no."
- Genuinely can't rule out a real -O2-triggered bug (e.g. latent UB that
  happens to behave at -O0) without ARM64 compilation access, which this
  sandbox doesn't have. If the widened thresholds + structural checks
  fail again on-device, that's the strongest signal yet of an actual bug
  worth digging into rather than a tolerance problem.

### v9: found the actual root cause

v8's device run: LayerNorm now passed (1.37%, under the widened 2%
threshold) but CrossEntropy failed harder than before (10.7%, still over
5%) - and its structural (sign) check passed. The tell was the reported
sample loss: 3.83762 on-device vs 1.91291 in local testing, from the
*same seed*. Rounding noise produces close-but-not-identical numbers;
this was a completely different value, which meant the two platforms
weren't computing the same thing with slightly different precision - they
were gradient-checking genuinely different random data.

Root cause: `std::mt19937` is normatively specified by the C++ standard -
same seed gives a bit-identical uint32 sequence on every conforming
implementation. `std::normal_distribution`, which every gradient-check
test built its random data with, is *not* - the standard only requires
correct statistical properties, not a specific algorithm. libstdc++
(desktop, used for all local verification) and libc++ (Android NDK) 
implement different algorithms, so the identical seed silently fed
different actual floats into the test on each platform. Not a bug in any
backward() - a bug in how the *test data* was generated.

Fix: `randomTensor()` now builds test tensors directly from `rng()`'s raw
output (uniform in `[-scale, scale]`) instead of through
`normal_distribution`, in both the JNI test and the local test file.
Re-verified locally: all pass with wide margin (LayerNorm ~9e-5, 
CrossEntropy ~1.5%). Tolerances left at v8's widened values rather than
tightened back down - the underlying data is portable now, but genuine
(much smaller) `-O2`/ARM64 vs `-O0`/x86_64 rounding variance still exists
and isn't verifiable from this sandbox, so keeping honest margin.

Items 2-6 get you a *working inference engine* that can run a model whose
weights come from somewhere else. Item 7 is what makes training actually
happen on-device — that's real but toy-scale only (small vocab, small
context, small param count); do not expect chat-quality output from
on-device training alone.

## Android optimization pass (subsystem 8) - part 1 of N: memory pool wiring

Subsystem 8 has four named pieces (quantization, NEON SIMD, thread pool,
memory pool wiring) and they don't all carry the same risk or the same
sandbox constraints, so — same call as training — it's being done as
verified slices instead of one pass. This slice is memory pool wiring
only, and it's the one piece of the four that's fully buildable *and*
fully verifiable from this sandbox: no ARM toolchain here, so NEON is
out of reach until it's actually run on-device, and a thread pool's
*correctness* is checkable on one core but its *speedup* isn't.

**What changed.** `MemoryPool` (built and tested back in subsystem 1,
unused since) is now actually wired in, everywhere, without touching a
single call site in `matrix::*`, `Linear`, `LayerNorm`, `FeedForward`,
`Attention`, `TransformerBlock`, or `Model::forward`/`backward`:

- `Tensor`'s two real constructors now check a thread-local "active
  pool" pointer. Set, they borrow storage from it; unset (the default,
  unchanged for every existing call site), they heap-allocate exactly
  as before — today's behavior is the fallback, not a special case.
- `PooledScope` (new, in `MemoryPool.h`) is the only thing that sets
  that pointer — an RAII guard, nests safely, scoped to wherever it's
  constructed.
- `Model` gained one new member, `scratchPool_`, sized once at
  construction from the model's own config (see
  `estimateScratchPoolBytes()` in `Model.cpp` for the reasoning —
  attention's `{maxSeqLen, maxSeqLen}` scores matrix is genuinely
  O(L^2 * numHeads), not padding — capped at 32MB so a much larger
  future config fails loud with `std::bad_alloc` instead of trying to
  grab gigabytes upfront). `forwardIncremental()` resets it and opens a
  `PooledScope` around its own body — one line at the top, one new
  member, nothing else in that function changed.
- Learned weights and KVCache's accumulated K/V are never pool-backed:
  they're constructed in `Model`'s constructor, before any scope
  exists, so they stay heap-owned automatically. `forward()`/
  `backward()` (training) don't touch the pool either — `backward()`
  needs its intermediates to outlive the call that produced them, which
  a reset-per-call arena structurally can't provide. Only
  `forwardIncremental()`'s ephemeral activations — the ones rebuilt
  from scratch every single token — are pool-backed.
- Copying a `Tensor` always deep-copies into fresh heap storage now,
  regardless of whether the source was pool-backed, specifically so a
  copy stays correct even after its source pool gets `reset()` for the
  next call. Moving still just transfers whichever storage the source
  had. `MemoryPool` itself picked up a move constructor and
  move-assignment (previously neither copyable nor movable) purely so
  it could become a plain `Model` member without making `Model` itself
  non-movable — `Model::load()`'s `return model;` depends on that.

**Why this piece first.** Of the four, it's the only one with zero
unverifiable claims attached: correctness AND the performance case are
both provable on desktop, no device needed. Threading's speedup only
shows up with >1 core (this sandbox has one); NEON doesn't compile at
all without an ARM toolchain. Quantization is next in line for the same
reason — the quantize/dequantize math and an int8 matmul are both
portable C++, fully testable here, before NEON dot-product intrinsics
accelerate it further in its own pass.

**Testing.** New standalone suite, `tests/test_memory_pool.cpp` (25
checks): `MemoryPool` alloc/reset/exhaustion/move, `Tensor` pool-backed
construction, the copy-survives-a-later-reset property specifically,
explicit move, nested-scope restoration, and — end to end —
`forwardIncremental()` still matches non-pooled `forward()` exactly with
pooling live underneath it, plus a capped-capacity check and a 40-step
stress run that never exhausts the pool. Every prior subsystem's suite
(13 files) was re-run after these changes with zero regressions — worth
calling out specifically for `test_decoder.cpp` and
`test_trainer.cpp`/`test_mini_training_demo.cpp`, since those already
exercise `forwardIncremental()` under real generation loops and would
have caught a correctness bug here even without the new file existing.
Illustrative (not rigorous — single core, desktop allocator, same
caveat as the KV-cache timing test) numbers from the new suite: 20,000
chained matmul+add+transpose calls on 16x16 tensors took ~435ms
heap-allocated vs ~380ms pool-allocated in this sandbox — the gap
should be larger on-device, where malloc/free are relatively more
expensive than on a desktop libc, and larger still for bigger models
than these demo-scale configs.

On-device (seventh button, extended not new — same call as folding
KVCache into it back in subsystem 6): `Run Runtime Test` now also
reports `scratchPool_`'s used/capacity bytes after a real
`forwardIncremental()` call, so a glance at the on-device output
confirms the wiring is live and sanely sized, not just that it compiled.

**Still ahead for subsystem 8:** quantization (int8) next, then a
thread pool, then NEON SIMD last — it's both the least sandbox-testable
of the four and the one most worth having a portable, correct,
baseline underneath before adding ARM-specific code on top of it.

## Android optimization pass (subsystem 8) - part 2 of N: int8 quantization

Weight-only int8 quantization, picked up right where part 1 left off:
portable, testable in this sandbox, no ARM needed yet.

**Scheme.** Per-tensor, symmetric, no zero-point: one `scale =
absmax(weight) / 127` per weight tensor, `q = round(x / scale)` clamped
to `[-127, 127]` (127 so the range stays symmetric — int8 can hold
-128, but using it would make the negative side one step longer for no
benefit here). The simplest scheme that's still correct and useful.
Per-channel scales (one per output column, not one for the whole
tensor) are a plausible follow-up if per-tensor accuracy ever isn't
enough for a bigger model — nothing here rules that out later, it just
isn't needed yet. `core/math/Quantization.h` has the exact math and
error-bound reasoning.

**Weight-only, not full int8.** Activations stay float32 throughout;
only persisted weights become int8. Two reasons: weights dominate a
model's memory footprint far more than activations do, so this
captures most of the size win for much less complexity; and it keeps
the correctness story simple enough to actually verify here — one
source of rounding error (the weight), not two compounding ones
(weight AND activation). Full int8 (activations quantized too, int8x
int8 dot products) only pays for its extra complexity once NEON's
int8 dot-product intrinsics can actually use it — that's a NEON-pass
concern, not this one.

**What changed.**

- `QuantizedTensor` (new, `core/math/Quantization.h/.cpp`) — an int8
  buffer plus one float scale, with `quantize()`/`dequantize()` and a
  standalone `quantizedMatmul(x, wq)` that mirrors `matrix::matmul`'s
  own i-p-j loop order and zero-skip. It never materializes a
  dequantized copy of the whole weight — each element is dequantized
  only inside the inner-product loop, `wq`'s scale factored out and
  applied once at the end (mathematically identical to dequantizing
  first, just cheaper) — which is the actual point of weight-only
  quantization: the weight stays 4x smaller *in memory*, not just on
  disk. `Quantization` depends only on `Tensor`, the same way `Matrix`
  does — sibling modules, neither depending on the other.
- `Linear::quantize()` (new) converts that one layer's weight in place
  and frees the float copy; `forward()` transparently uses
  `quantizedMatmul` instead of `matrix::matmul` from then on, with the
  bias left float32 (small enough — {outDim} — that quantizing it buys
  little size for real accuracy risk on the one term that directly
  shifts every output). This is a one-way, lossy conversion — meant
  for a layer that's done training. `weight()` and `backward()` now
  throw `std::logic_error` afterward (there's no float weight left to
  hand back or differentiate against), and so does `save()` — quantized
  weight *persistence* is real scope on its own (file-format changes,
  backward compatibility with existing checkpoints) and is deliberately
  left for a later pass, same call as deferring NEON.
- `Model::quantize()` (new) walks every Linear the existing
  gradient-checking accessors already reach — each block's four
  attention projections and two FeedForward layers, plus the LM head —
  and quantizes all of them. `TokenEmbedding`'s lookup table is
  untouched: it's indexed, not multiplied, so this scheme doesn't apply
  to it the same way; left for its own pass if it's ever worth it.
  `Model::totalLinearWeightBytes()` (new) sums every layer's
  `weightBytes()` for measuring the real, whole-model reduction.

**Testing.** New standalone suite, `tests/test_quantization.cpp`: the
quantize/dequantize round-trip error bound, the all-zero-tensor edge
case (would divide by zero without the fallback scale), the
`quantizedMatmul` vs `matrix::matmul` error bound, `Linear`'s
before/after forward() closeness and its ~4x `weightBytes()` shrink,
and the throw-after-quantize contract on `weight()`/`backward()`/
`save()`. The one that actually matters most: train a real model on
the same repeated-phrase setup `test_mini_training_demo.cpp` uses,
run 300 steps until confident (loss < 0.01, verified in the test, not
assumed), quantize the whole thing, and generate again — **the
generated text is byte-for-byte identical before and after**, because
a confident model's argmax calls aren't close enough for quantization's
small per-weight rounding noise to flip any of them. Every prior suite
(15 files, including part 1's) re-run with zero regressions.

On-device (`Run Mini Training Demo`, extended not new — same call as
every other closely-related addition this subsystem): after showing
the trained before/after generation, it now also quantizes the model,
reports total Linear weight bytes before/after with the real ratio,
and generates once more to confirm the output is still exactly
`UNCHANGED`.

**Still ahead for subsystem 8:** a thread pool next, then NEON SIMD
last. Quantized weight *persistence* (saving/loading the int8 form,
not just using it in-memory after a fresh float load) is also still
open — worth its own pass once it's actually needed for a shipped
model rather than a freshly-trained one.

## Android optimization pass (subsystem 8) - part 3 of N: thread pool

**A real bug found and fixed first, unrelated to threading itself:**
`core/math/Quantization.cpp` was never added to `app/src/main/cpp/CMakeLists.txt`'s
explicit source list back in part 2 - only this project's own desktop
test scripts (which `find` every `.cpp` under `core/`) picked it up
automatically, so every standalone suite and this sandbox's own JNI-stub
compile checks passed cleanly while the *actual* Android/NDK build was
almost certainly failing to link (undefined references to
`novallm::quantize` / `quantizedMatmul`, called from `jni_bridge.cpp` and
`Linear.cpp`). That lines up exactly with the "Run Mini Training Demo"
showing stale, pre-quantization output on-device after part 2 shipped -
not the CI cache-glob bug this doc already flagged, a different, newly
introduced gap, and CMakeLists.txt's explicit file list is exactly the
kind of place a new source file is easy to forget, since nothing about
adding the `.cpp`/`.h` pair itself fails - only a full from-scratch NDK
build would have caught it, which this sandbox can't run. Fixed now
(`Quantization.cpp` added, alongside the new `ThreadPool.cpp` below) -
worth double-checking this file specifically any time a new `core/`
source file is added from here on, since nothing else will catch it.

**What changed, for threading itself.** New `core/math/ThreadPool.h/.cpp`:
a small fixed-size pool of worker threads with one operation,
`parallelFor(n, fn)` - splits `[0, n)` into disjoint chunks, runs one
per worker (plus one on the calling thread, so it isn't just sitting
idle), blocks until all finish. Below a size threshold, or with no
worker threads available, it just calls `fn(0, n)` directly - todays's
exact sequential behavior, not a special case, same pattern as part 1's
"unset pool = heap, unchanged" default.

`matrix::matmul` and `quantizedMatmul` now run through it, parallelized
over **output columns**, not rows - the opposite of the obvious first
instinct, and deliberately so: during incremental (token-by-token)
generation, `m` (the sequence length going into any one
`forwardIncremental()` call) is 1 for every token after the first, so
row-parallelism would give that dominant, latency-critical workload
zero benefit. `n` (embedDim / ffnHiddenDim / vocabSize) stays
substantial even when `m` collapses to 1 - vocabSize alone is ~300 in
every demo config already, comfortably over the chunk threshold - so
column-parallelism helps the steady-state generation loop exactly as
much as it helps a large-`m` training batch, at no extra complexity:
same i-p-j loop order inside each chunk, same zero-skip, same
cache-friendly access pattern, just restricted to a column range.
Accumulation order for any single output element never changes (still
strictly `p = 0..k-1`) - only *which* thread computes which column does
- so results are **bit-exact** regardless of chunking or worker count,
not an approximation the way quantization is. Both `matmul` and
`quantizedMatmul` picked up a `(a, b, pool)` overload alongside the
existing `(a, b)` one specifically so this could be tested with a
*forced* multi-worker pool rather than only ever exercising
`ThreadPool::shared()`'s fallback path (see below for why that matters
here specifically).

Workers only ever write into a `Tensor` that was already fully
allocated by the calling thread before `parallelFor` starts - they
never construct a `Tensor` themselves, so this doesn't interact with
part 1's thread-local `PooledScope` at all: the pool lookup only ever
happens on the thread that's already inside (or not inside) a scope,
never on a worker. Deliberately built `thread_local` back in part 1
specifically so a later thread pool wouldn't have to fight it - that
groundwork paid off here without needing to touch `MemoryPool.h` again.

**The sandbox problem, and how it's handled.** This project's own build
sandbox reports one CPU core. `ThreadPool::shared()` sizes itself off
`std::thread::hardware_concurrency()`, so here it has zero worker
threads - meaning every ordinary test in this project, run in this
sandbox, only ever exercises the sequential fallback, never the real
multi-worker synchronization path, no matter how it's called. The
constructor most callers should never need,
`explicit ThreadPool(int numWorkers)`, exists specifically to route
around that: tests construct a pool with a forced worker count (4, in
`tests/test_thread_pool.cpp`) and call the `(a, b, pool)` matmul
overloads directly against it. Real OS threads get created and
genuinely scheduled, even if only time-sliced across one physical core
rather than truly running in parallel - which is exactly enough to
prove the mutex/condition-variable/atomic logic itself is correct
(no lost wakeups, no double-counted or skipped chunks, no deadlock
across hundreds of repeated calls on a reused pool), independent of
whether it's fast, which is not something the same sandbox can prove.
**Actual speedup on real multi-core hardware is a claim for whatever
device this runs on to confirm - the tests here prove correctness, not
performance.**

**Testing.** New standalone suite, `tests/test_thread_pool.cpp` (10
checks): every index touched exactly once, results matching a plain
sequential loop across sizes from 0 to 1000 (including right around the
chunk-size threshold on both sides), small work confirmed to stay on
the calling thread only, large work confirmed to actually reach a
worker thread, 500 repeated calls on a reused pool with varying sizes
and no deadlock or corruption, a zero-worker pool falling back
correctly, and - the two that matter most - `matmul` and
`quantizedMatmul` both confirmed bit-exact between a forced-sequential
and forced-4-worker pool, including specifically at `m=1` (the
single-token decoding shape). All 15 prior suites re-run with zero
regressions, `test_mini_training_demo` and `test_trainer` specifically
worth calling out again, since a genuine data race in the threaded path
could plausibly have shown up there as a rare, hard-to-reproduce wrong
value rather than a clean crash - it didn't.

On-device (extended `Run Math Core Test`, same call as every other
extension so far - fold related evidence into whichever existing button
already covers that subsystem): now also runs a forced-4-worker
`parallelFor` correctness check, and reports
`std::thread::hardware_concurrency()` and
`ThreadPool::shared().numWorkerThreads()` directly - the first place in
this project that can show your Hot 11's actual core count, since
nothing in this sandbox can. `Run Runtime Test` picked up the
performance half specifically (correctness already lives with the
primitive in Math Core Test): 500x the model's own LM-head-shaped
matmul, forced-single-thread vs `ThreadPool::shared()` - on this
sandbox those two necessarily land close together (zero workers either
way), which is expected, not a red flag; a real gap here is the
Hot 11's to show.

**CMakeLists.txt also picked up an explicit `Threads::Threads` link**
(`find_package(Threads REQUIRED)`) for this - Android's NDK has had
pthread support built into Bionic's libc for a long time, so this
likely would have linked fine without it too, but declaring the
dependency explicitly is the portable, idiomatic CMake way to ask for
it rather than relying on a specific toolchain's default.

**Still ahead for subsystem 8:** NEON SIMD, last of the four - and now
the only one left that this sandbox structurally cannot compile or run
at all, having no ARM toolchain. Worth a build/link double-check
specifically (this part's own opening bug is exactly why) before
trusting it further than "compiles as portable C++ with a `#ifdef
__ARM_NEON` guard and a scalar fallback."

### Correction: the chunk-size threshold was miscalibrated, found on real hardware

The very first on-device run of this part - Infinix Hot 11, 8 cores,
`ThreadPool::shared()` correctly detecting 7 workers, all confirmed by
Run Math Core Test - also ran the `Run Runtime Test` timing comparison
this part shipped with: `500x matmul(8x16, 16x300) — forced
single-thread: 9ms, ThreadPool::shared(): 61ms`. Threading made this
call **6.7x slower**, not faster. Every result was still correct (not a
correctness bug - `core/runtime: ALL PASS on-device` right below it) -
`kMinColsPerChunk = 64` (threshold `n < 128`) was simply too low, and
this sandbox's one core meant that number was reasoned about in the
abstract, never checked against anything real, right up until now.

Backing out the real cost: n=300 dispatched 3 worker chunks under the
old threshold. (61ms - 9ms) / 500 calls / 3 workers ≈ 35us of
synchronization overhead per dispatched chunk on real Android hardware -
thread wake/sleep through a condition variable is genuinely that
expensive, not a rounding error. The *whole* 8x16x300 matmul only took
18us sequential in the first place, nowhere close to covering that.

Raised `kMinColsPerChunk` to 2048 (threshold `n < 4096`) - comfortably
(13x) above every `n` this project's demo configs actually use
(vocabSize ~300-315 is the largest), so today's models now correctly
stay sequential, verified both in `tests/test_thread_pool.cpp` (new
check: n=300 with 4 workers available still runs entirely on the
calling thread) and on-device (`Run Runtime Test` now sweeps n =
vocabSize, 1000, 4096, 8000, 16000 instead of testing just one size,
specifically to gather the real data needed to tighten this further
once those numbers come back - a single data point is enough to know
64 was wrong, not enough to know exactly where the right number is).
Existing size-dependent tests that were calibrated around the old
threshold (128) got moved to bracket the new one (4096) instead, so
they keep exercising the real multi-worker path rather than quietly
starting to test the sequential fallback against itself.

## Why matmul is naive right now

Correctness has to be provable before it's optimized. The i-p-j loop order
in `matrix::matmul` is cache-friendlier than the textbook i-j-p order and
skips zero entries in A, but it's still O(n^3) with no SIMD. NEON
intrinsics land in step 8, once every subsystem that depends on matmul
being *correct* already exists and can catch a regression.

## Testing loop

Two independent checks exist on purpose:

1. `tests/test_math.cpp` — compiles standalone with clang/g++ in Termux,
   no Android toolchain needed. Fastest iteration loop for pure logic bugs.
2. The JNI test button in the app — proves the same code actually builds
   and runs correctly through NDK/JNI on your Infinix Hot 11, which is a
   different (and historically more failure-prone, per the mgba JNI work)
   code path than plain Linux compilation.

## One CI gotcha worth fixing

Your `Build APK` workflow's C++ build cache is keyed on:

```
hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp')
```

`**/core/*.cpp` only matches files directly inside a `core/` folder, not
nested ones. This project's C++ lives in `core/math/*.cpp` (and will grow
into `core/tokenizer/`, `core/transformer/`, etc.) — one level deeper than
the glob reaches. That means edits to files under `core/math/` won't change
the cache key, so CI can restore a stale `.cxx` build cache instead of
picking up your change. Worth changing that line to:

```
hashFiles('**/CMakeLists.txt', '**/core/**/*.cpp', '**/core/**/*.h', '**/jni_bridge.cpp')
```

so nested subsystem folders actually invalidate the cache.
