#pragma once
#include <cstddef>
#include <functional>
#include <memory>
#include <vector>

namespace novallm {

// A small, fixed-size pool of worker threads for parallelizing
// data-parallel loops - currently used by matrix::matmul /
// quantizedMatmul (see Matrix.cpp / Quantization.cpp) to split their
// output columns across cores. There is exactly one process-wide
// instance (see shared()), used by every matmul call that's large
// enough to benefit - thread count is a property of the DEVICE (core
// count), not any one Model, so this deliberately does NOT live inside
// Model the way scratchPool_ does.
//
// Correctness (parallelFor produces the same result as calling
// fn(0, n) directly) is provable and tested on any core count,
// including this project's own build sandbox, which only reports one -
// see the explicit-count constructor below and
// tests/test_thread_pool.cpp. The actual SPEEDUP only shows up with
// more than one core, which is a claim for whatever device this
// actually runs on to confirm, not this sandbox.
class ThreadPool {
public:
    // The process-wide pool for real use - lazily created on first
    // call, sized to std::thread::hardware_concurrency() - 1 worker
    // threads (the calling thread does a share of the work too in
    // parallelFor, so total effective parallelism is workers + 1). If
    // hardware_concurrency() can't tell (returns 0) or reports exactly
    // 1, this has zero worker threads, and parallelFor transparently
    // falls back to running everything on the calling thread - exactly
    // today's sequential behavior, not a special case.
    static ThreadPool& shared();

    // Explicit worker count, mainly for tests: lets the actual
    // multi-worker synchronization path be exercised and verified even
    // on a machine that only reports one core (like this project's own
    // sandbox) - correctness doesn't depend on true parallelism, only
    // on the synchronization being right, and this is the only way to
    // reach that code path without real multi-core hardware. Any
    // caller that genuinely needs a specific worker count (not just
    // "the shared, device-sized pool") can use this too.
    explicit ThreadPool(int numWorkers);

    ~ThreadPool();
    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;
    ThreadPool(ThreadPool&&) = delete;
    ThreadPool& operator=(ThreadPool&&) = delete;

    // Splits [0, n) into contiguous, disjoint chunks and calls
    // fn(begin, end) once per chunk - one chunk runs on the calling
    // thread itself (so it does its share instead of sitting idle),
    // the rest on worker threads - blocking until every chunk
    // finishes. fn must only touch memory that's either read-only or
    // disjoint between chunks: two different chunks never overlap, so
    // e.g. writing to different output columns of the same Tensor from
    // different chunks is safe, writing to the same column from two
    // chunks would not be. Below a fixed minimum chunk size, or on a
    // pool with no worker threads, calls fn(0, n) directly on the
    // calling thread instead - avoids paying real synchronization
    // overhead on work too small to ever recoup it.
    void parallelFor(int n, const std::function<void(int, int)>& fn);

    // Worker threads only (not counting the calling thread's own share
    // of the work in parallelFor).
    int numWorkerThreads() const;

private:
    struct Worker;
    std::vector<std::unique_ptr<Worker>> workers_;
};

} // namespace novallm
