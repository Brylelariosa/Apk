#pragma once
#include "../math/Tensor.h"
#include "../math/Quantization.h"
#include <iosfwd>

namespace novallm {

// Standard learned linear layer: y = x @ W + b.
// x is {seqLen, inDim}, W is {inDim, outDim}, b is {outDim}, y is {seqLen, outDim}.
// Shared building block for attention's Q/K/V/output projections and for
// the feed-forward network's two layers.
class Linear {
public:
    struct Grads {
        Tensor gradInput;  // {seqLen, inDim}  - flows back to whatever fed this layer
        Tensor gradWeight; // {inDim, outDim}  - accumulated into by the optimizer
        Tensor gradBias;   // {outDim}
    };

    Linear(int inDim, int outDim, unsigned int seed = 42, bool useBias = true);

    Tensor forward(const Tensor& x) const;

    // x is the SAME input that was passed to forward() (needed for the
    // weight/bias gradients). gradOutput is dLoss/dOutput, same shape as
    // forward()'s return value. Throws std::logic_error if this layer
    // has been quantize()'d - see below.
    Grads backward(const Tensor& x, const Tensor& gradOutput) const;

    // Converts this layer's weight to an in-memory int8 + scale
    // representation (core/math/Quantization.h) and discards the float
    // copy, roughly quartering this layer's resident weight memory
    // (weightBytes() reports the exact before/after). One-way and
    // lossy - there is no un-quantize back to the original values, only
    // quantize()'s bounded approximation. Meant for a layer that's done
    // training: forward() keeps working afterward (through
    // quantizedMatmul() instead of matrix::matmul()), but weight() and
    // backward() throw std::logic_error, since there's no float weight
    // left to return or compute a gradient against. bias_ stays
    // float32 - it's a {outDim} vector, small enough that quantizing it
    // buys little size for real accuracy risk on the one term that
    // directly shifts every output. Calling this on an already-
    // quantized layer is a harmless no-op.
    void quantize();
    bool isQuantized() const { return isQuantized_; }

    // Bytes currently used by this layer's weight storage - float32
    // normally, or the much smaller int8-plus-one-scale form after
    // quantize(). Diagnostic / for measuring the actual savings, not
    // decision logic.
    size_t weightBytes() const;

    int inDim() const { return inDim_; }
    int outDim() const { return outDim_; }

    // Both throw std::logic_error once this layer is quantized - see
    // quantize()'s doc comment for why there's no float weight left to
    // hand back.
    Tensor& weight();
    const Tensor& weight() const;

    Tensor& bias() { return bias_; }
    const Tensor& bias() const { return bias_; }

    // Throws std::logic_error if this layer is quantized - persisting
    // the int8 form isn't supported yet (planned for a later
    // subsystem-8 pass); save() needs a float weight to write.
    void save(std::ostream& out) const;
    // Always produces a fresh, non-quantized layer, regardless of any
    // prior state.
    void load(std::istream& in);

private:
    int inDim_;
    int outDim_;
    bool useBias_;
    bool isQuantized_ = false;
    Tensor weight_;                   // {inDim, outDim} - valid only while !isQuantized_
    QuantizedTensor quantizedWeight_; // valid only while isQuantized_
    Tensor bias_;                     // {outDim}, always float
};

} // namespace novallm
