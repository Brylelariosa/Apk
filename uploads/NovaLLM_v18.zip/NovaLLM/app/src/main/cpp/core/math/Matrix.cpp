#include "Matrix.h"
#include <stdexcept>
#include <cmath>
#include <algorithm>

namespace novallm {
namespace matrix {

Tensor matmul(const Tensor& a, const Tensor& b) {
    return matmul(a, b, ThreadPool::shared());
}

Tensor matmul(const Tensor& a, const Tensor& b, ThreadPool& pool) {
    if (a.rank() != 2 || b.rank() != 2) {
        throw std::invalid_argument("matmul: both tensors must be rank 2");
    }
    int m = a.dim(0);
    int k = a.dim(1);
    int k2 = b.dim(0);
    int n = b.dim(1);
    if (k != k2) {
        throw std::invalid_argument("matmul: inner dimensions do not match");
    }

    Tensor out({m, n});
    const float* ad = a.data();
    const float* bd = b.data();
    float* od = out.data();

    // Parallelized over OUTPUT COLUMNS (n), not rows (m): unlike rows, n
    // (embedDim / ffnHiddenDim / vocabSize in this project) stays
    // substantial even when m collapses to 1 - the common case for every
    // generated token after the first during incremental decoding.
    // Splitting by rows would give that dominant, latency-critical
    // workload zero benefit from threading; splitting by columns helps
    // it exactly as much as it helps a large-m training batch. Two
    // different chunks never write the same output column, so this
    // needs no synchronization beyond parallelFor's own join.
    //
    // Same i-p-j loop order and zero-skip as before within each chunk -
    // cache-friendly, doesn't touch B or the output outside its own
    // column range. Accumulation order for any single output element
    // never changes (still strictly p = 0..k-1) - only WHICH thread
    // computes which column does - so results are bit-exact regardless
    // of chunking, not an approximation (see tests/test_thread_pool.cpp).
    pool.parallelFor(n, [&](int colBegin, int colEnd) {
        for (int i = 0; i < m; ++i) {
            float* orow = od + static_cast<size_t>(i) * n;
            for (int p = 0; p < k; ++p) {
                float av = ad[static_cast<size_t>(i) * k + p];
                if (av == 0.0f) continue;
                const float* brow = bd + static_cast<size_t>(p) * n;
                for (int j = colBegin; j < colEnd; ++j) {
                    orow[j] += av * brow[j];
                }
            }
        }
    });
    return out;
}

Tensor add(const Tensor& a, const Tensor& b) {
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("add: shape mismatch");
    }
    Tensor out(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        out.data()[i] = a.data()[i] + b.data()[i];
    }
    return out;
}

Tensor addBias(const Tensor& a, const Tensor& bias) {
    if (a.rank() != 2) throw std::invalid_argument("addBias: a must be rank 2");
    int rows = a.dim(0);
    int cols = a.dim(1);
    if (static_cast<int>(bias.size()) != cols) {
        throw std::invalid_argument("addBias: bias size must equal column count");
    }
    Tensor out({rows, cols});
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            out.data()[static_cast<size_t>(i) * cols + j] =
                a.data()[static_cast<size_t>(i) * cols + j] + bias.data()[j];
        }
    }
    return out;
}

Tensor transpose(const Tensor& a) {
    if (a.rank() != 2) throw std::invalid_argument("transpose: a must be rank 2");
    int rows = a.dim(0);
    int cols = a.dim(1);
    Tensor out({cols, rows});
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            out.data()[static_cast<size_t>(j) * rows + i] =
                a.data()[static_cast<size_t>(i) * cols + j];
        }
    }
    return out;
}

Tensor scale(const Tensor& a, float scalar) {
    Tensor out(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        out.data()[i] = a.data()[i] * scalar;
    }
    return out;
}

void softmaxRows(Tensor& x) {
    if (x.rank() != 2) throw std::invalid_argument("softmaxRows: x must be rank 2");
    int rows = x.dim(0);
    int cols = x.dim(1);
    for (int i = 0; i < rows; ++i) {
        float* row = x.data() + static_cast<size_t>(i) * cols;
        float maxVal = row[0];
        for (int j = 1; j < cols; ++j) maxVal = std::max(maxVal, row[j]);
        float sum = 0.0f;
        for (int j = 0; j < cols; ++j) {
            row[j] = std::exp(row[j] - maxVal);
            sum += row[j];
        }
        for (int j = 0; j < cols; ++j) row[j] /= sum;
    }
}

Tensor sliceColumns(const Tensor& a, int startCol, int numCols) {
    if (a.rank() != 2) throw std::invalid_argument("sliceColumns: a must be rank 2");
    int rows = a.dim(0);
    int colsA = a.dim(1);
    if (startCol < 0 || numCols < 0 || startCol + numCols > colsA) {
        throw std::out_of_range("sliceColumns: column range out of bounds");
    }
    Tensor out({rows, numCols});
    for (int i = 0; i < rows; ++i) {
        const float* src = a.data() + static_cast<size_t>(i) * colsA + startCol;
        float* dst = out.data() + static_cast<size_t>(i) * numCols;
        for (int j = 0; j < numCols; ++j) dst[j] = src[j];
    }
    return out;
}

void setColumns(Tensor& dst, int startCol, const Tensor& src) {
    if (dst.rank() != 2 || src.rank() != 2) throw std::invalid_argument("setColumns: rank must be 2");
    int rows = dst.dim(0);
    int colsDst = dst.dim(1);
    int numCols = src.dim(1);
    if (src.dim(0) != rows) throw std::invalid_argument("setColumns: row count mismatch");
    if (startCol < 0 || startCol + numCols > colsDst) {
        throw std::out_of_range("setColumns: column range out of bounds");
    }
    for (int i = 0; i < rows; ++i) {
        const float* srcRow = src.data() + static_cast<size_t>(i) * numCols;
        float* dstRow = dst.data() + static_cast<size_t>(i) * colsDst + startCol;
        for (int j = 0; j < numCols; ++j) dstRow[j] = srcRow[j];
    }
}

} // namespace matrix
} // namespace novallm
