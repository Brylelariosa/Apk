#include "ThreadPool.h"
#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <thread>

namespace novallm {

// Below this many columns, parallelFor just runs sequentially.
//
// Originally 64 (threshold n < 128), reasoned about in the abstract
// with no real hardware to check it against. On-device numbers from an
// actual 8-core phone (Infinix Hot 11, via Run Runtime Test) showed
// exactly why that was too low: 500x matmul(8x16, 16x300) - n=300, which
// the old threshold happily parallelized into 4 chunks - took 9ms
// forced-sequential vs 61ms through ThreadPool::shared(). Not a
// correctness bug (every result was still right), a performance one:
// thread wake/sleep and condition-variable signaling cost real,
// measured tens of microseconds per dispatched chunk on that hardware
// (~35us, backed out from the 9ms/61ms gap across 3 dispatched workers),
// which a matmul this small doesn't come close to recouping - the
// *whole* 8x16x300 call only took 18us sequential in the first place.
//
// Raised to 2048 (threshold n < 4096) - comfortably (13x) above every
// n this project's demo configs actually use (vocabSize ~300-315 is the
// largest), so today's models correctly stay on the fast sequential
// path unchanged, while the mechanism itself stays correct and ready
// for whenever a much larger n might actually justify it. This is a
// conservative number backed by exactly one real (n=300) data point,
// not a calibrated optimum - Run Runtime Test now sweeps several n
// values specifically to gather more before tightening this further.
constexpr int kMinColsPerChunk = 2048;

struct ThreadPool::Worker {
    std::thread thread;
    std::mutex mutex;
    std::condition_variable cv;
    std::function<void()> job;
    bool hasJob = false;
    bool shouldStop = false;

    void loop() {
        while (true) {
            std::function<void()> toRun;
            {
                std::unique_lock<std::mutex> lock(mutex);
                cv.wait(lock, [this] { return hasJob || shouldStop; });
                if (shouldStop && !hasJob) return;
                toRun = std::move(job);
                hasJob = false;
            }
            toRun();
        }
    }
};

ThreadPool::ThreadPool(int numWorkers) {
    workers_.reserve(static_cast<size_t>(std::max(numWorkers, 0)));
    for (int i = 0; i < numWorkers; ++i) {
        auto w = std::make_unique<Worker>();
        Worker* raw = w.get();
        w->thread = std::thread([raw] { raw->loop(); });
        workers_.push_back(std::move(w));
    }
}

ThreadPool::~ThreadPool() {
    for (auto& w : workers_) {
        {
            std::lock_guard<std::mutex> lock(w->mutex);
            w->shouldStop = true;
        }
        w->cv.notify_one();
    }
    for (auto& w : workers_) {
        w->thread.join();
    }
}

ThreadPool& ThreadPool::shared() {
    unsigned int cores = std::thread::hardware_concurrency();
    // hardware_concurrency() returning 0 means "couldn't tell" - treat
    // that the same as 1 (no extra worker threads), not as "assume
    // many": on an unknown device, understaffing just costs some
    // parallelism, while overstaffing costs real idle-thread resources
    // for no benefit.
    int numWorkers = (cores > 1) ? static_cast<int>(cores) - 1 : 0;
    static ThreadPool instance(numWorkers);
    return instance;
}

int ThreadPool::numWorkerThreads() const {
    return static_cast<int>(workers_.size());
}

void ThreadPool::parallelFor(int n, const std::function<void(int, int)>& fn) {
    if (n <= 0) return;
    int numWorkers = static_cast<int>(workers_.size());
    if (numWorkers == 0 || n < kMinColsPerChunk * 2) {
        fn(0, n);
        return;
    }

    // At most (numWorkers + 1) chunks - workers plus the calling
    // thread - so no worker ever needs a second chunk queued behind
    // another within this one call; each worker's single job slot is
    // enough.
    int numChunks = std::min(numWorkers + 1, std::max(1, n / kMinColsPerChunk));
    int baseSize = n / numChunks;
    int remainder = n % numChunks;

    // Counts only the WORKER chunks (numChunks - 1) - the calling
    // thread runs its own last chunk directly below and doesn't wait
    // on itself.
    std::atomic<int> remaining{numChunks - 1};
    std::mutex doneMutex;
    std::condition_variable doneCv;

    int begin = 0;
    for (int c = 0; c < numChunks; ++c) {
        int size = baseSize + (c < remainder ? 1 : 0);
        int end = begin + size;

        if (c == numChunks - 1) {
            // Last chunk runs right here instead of on a worker - the
            // calling thread would otherwise just sit idle waiting, so
            // it does its own share of the work too.
            fn(begin, end);
        } else {
            Worker* w = workers_[static_cast<size_t>(c)].get();
            {
                std::lock_guard<std::mutex> lock(w->mutex);
                w->job = [&fn, begin, end, &remaining, &doneMutex, &doneCv]() {
                    fn(begin, end);
                    if (remaining.fetch_sub(1, std::memory_order_acq_rel) == 1) {
                        // We were the last worker to finish - wake the
                        // calling thread. Locking doneMutex here, and
                        // checking the predicate under the same lock
                        // below, closes the classic lost-wakeup race:
                        // it doesn't matter whether this runs before or
                        // after the calling thread reaches wait().
                        std::lock_guard<std::mutex> doneLock(doneMutex);
                        doneCv.notify_one();
                    }
                };
                w->hasJob = true;
            }
            w->cv.notify_one();
        }
        begin = end;
    }

    if (numChunks > 1) {
        std::unique_lock<std::mutex> lock(doneMutex);
        doneCv.wait(lock, [&remaining] { return remaining.load(std::memory_order_acquire) == 0; });
    }
}

} // namespace novallm
