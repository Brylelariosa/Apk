#include "Model.h"
#include <fstream>
#include <stdexcept>
#include <cstdint>
#include <algorithm>

namespace novallm {
namespace {

// Every activation Tensor produced during ONE forwardIncremental() call -
// across every layer - has to fit in scratchPool_, since it's only
// reset() between calls, not between layers. The single largest term is
// the {L, L} per-head attention-score matrix seen while priming the
// cache with an L-token prompt: genuinely O(maxSeqLen^2 * numHeads),
// inherent to attention itself, not padding. Per-layer constants below
// (16x / 4x) come from actually counting how many L*embedDim / L*ffnDim
// tensors one forwardIncremental() call allocates (q/k/v, per-head
// splits, residuals, LayerNorm outputs, FeedForward's two linears, ...) -
// a bump allocator can't reclaim any of them until the whole call
// returns, so they all have to fit at once. The x2 on top is headroom
// for undercounting, not the main safety margin - that's the point
// above about O(L^2) already being real, unavoidable, worst-case need.
//
// kMaxBytes exists because that O(L^2 * H) term means a much larger
// future config (this is only "part 1" of subsystem 8 - real model
// scale-up is still ahead) could otherwise demand gigabytes upfront.
// Capping trades that for a clean, immediate std::bad_alloc instead of
// either an allocation that silently starves the rest of the app or one
// that just fails anyway - loud and predictable either way. Revisit this
// whole formula (and the cap) once an actual target model size is
// chosen; today's demo configs (embedDim <= 32, maxSeqLen <= 128) sit
// far below it.
constexpr size_t kMaxScratchPoolBytes = 32u * 1024 * 1024; // 32 MB

size_t estimateScratchPoolBytes(const Model::Config& cfg) {
    size_t L = static_cast<size_t>(std::max(cfg.maxSeqLen, 1));
    size_t E = static_cast<size_t>(std::max(cfg.embedDim, 1));
    size_t F = static_cast<size_t>(std::max(cfg.ffnHiddenDim, 1));
    size_t H = static_cast<size_t>(std::max(cfg.numHeads, 1));
    size_t perLayerFloats = (L * L * H)      // per-head attention scores, every head
                           + (L * E * 16)     // q/k/v/concat/residuals/LN outputs/etc.
                           + (L * F * 4);     // FeedForward's two linear layers
    size_t totalFloats = perLayerFloats * static_cast<size_t>(std::max(cfg.numLayers, 1));
    size_t bytes = totalFloats * sizeof(float) * 2 /* headroom */ + (1u << 16) /* fixed floor */;
    return std::min(bytes, kMaxScratchPoolBytes);
}

} // namespace

Model::Model(const Config& config, unsigned int seed)
    : config_(config),
      tokenEmbedding_(config.vocabSize, config.embedDim, seed),
      positionalEncoding_(config.maxSeqLen, config.embedDim),
      finalNorm_(config.embedDim),
      lmHead_(config.embedDim, config.vocabSize, seed + 1000, /*useBias=*/true),
      scratchPool_(estimateScratchPoolBytes(config)) {
    blocks_.reserve(static_cast<size_t>(config.numLayers));
    caches_.reserve(static_cast<size_t>(config.numLayers));
    for (int i = 0; i < config.numLayers; ++i) {
        blocks_.emplace_back(config.embedDim, config.numHeads, config.ffnHiddenDim,
                              seed + 100 + static_cast<unsigned int>(i) * 10);
        caches_.emplace_back(config.maxSeqLen, config.embedDim);
    }
}

Tensor Model::forward(const std::vector<int>& ids) const {
    Tensor x = positionalEncoding_.applyTo(tokenEmbedding_.lookupSequence(ids));
    for (const auto& block : blocks_) {
        x = block.forward(x);
    }
    x = finalNorm_.forward(x);
    return lmHead_.forward(x); // {seqLen, vocabSize}
}

Model::Grads Model::backward(const std::vector<int>& ids, const Tensor& gradLogits) const {
    // Recompute forward, keeping every block's input around - each
    // block's backward() needs the SAME input it saw during forward().
    std::vector<Tensor> blockInputs;
    blockInputs.reserve(blocks_.size() + 1);
    Tensor x = positionalEncoding_.applyTo(tokenEmbedding_.lookupSequence(ids));
    blockInputs.push_back(x);
    for (const auto& block : blocks_) {
        x = block.forward(x);
        blockInputs.push_back(x); // blockInputs[i+1] = output of block i = input to block i+1
    }
    Tensor finalNormInput = blockInputs.back();
    Tensor afterFinalNorm = finalNorm_.forward(finalNormInput);

    Grads g;
    g.lmHeadGrads = lmHead_.backward(afterFinalNorm, gradLogits);
    g.finalNormGrads = finalNorm_.backward(finalNormInput, g.lmHeadGrads.gradInput);

    Tensor gradX = g.finalNormGrads.gradInput; // gradient into the LAST block's output
    g.blockGrads.resize(blocks_.size());
    for (int i = static_cast<int>(blocks_.size()) - 1; i >= 0; --i) {
        TransformerBlock::Grads bg = blocks_[static_cast<size_t>(i)].backward(
            blockInputs[static_cast<size_t>(i)], gradX);
        gradX = bg.gradInput; // propagate to the block BEFORE this one
        g.blockGrads[static_cast<size_t>(i)] = std::move(bg);
    }

    // gradX now holds dL/d(tokenEmbedding + positionalEncoding).
    // PositionalEncoding has no learnable parameters, so this entire
    // gradient goes to the embedding table - nothing is split or lost.
    g.gradTokenEmbedding = tokenEmbedding_.backward(ids, gradX);

    return g;
}

Tensor Model::forwardIncremental(const std::vector<int>& newIds) {
    // Every Tensor built below - across this whole call, every layer -
    // draws from scratchPool_ instead of the heap. reset() first so this
    // call doesn't build on top of leftovers from the last one; `pooled`
    // going out of scope when this function returns hands the ambient
    // pool back to whatever (if anything) it was before, so nothing
    // outside this function is affected. KVCache's own kBuffer_/vBuffer_
    // and every layer's learned weights were all constructed back in
    // Model's constructor, before any scope existed, so they stay
    // heap-owned automatically - only this call's fresh activations are
    // pool-backed.
    scratchPool_.reset();
    PooledScope pooled(scratchPool_);

    // All layer caches advance together, so any one of them tells us the
    // current global position new tokens are starting from.
    int startPos = caches_.empty() ? 0 : caches_[0].currentLen();
    int newLen = static_cast<int>(newIds.size());

    Tensor tokenEmb = tokenEmbedding_.lookupSequence(newIds);      // {newLen, embedDim}
    Tensor posSlice = positionalEncoding_.encodeRange(startPos, newLen);
    Tensor x({newLen, config_.embedDim});
    for (size_t k = 0; k < x.size(); ++k) {
        x.data()[k] = tokenEmb.data()[k] + posSlice.data()[k];
    }

    for (size_t i = 0; i < blocks_.size(); ++i) {
        x = blocks_[i].forwardIncremental(x, caches_[i]);
    }
    x = finalNorm_.forward(x);
    return lmHead_.forward(x); // {newLen, vocabSize}
}

void Model::resetCache() {
    for (auto& c : caches_) c.reset();
}

void Model::quantize() {
    for (auto& block : blocks_) {
        block.attn().wq().quantize();
        block.attn().wk().quantize();
        block.attn().wv().quantize();
        block.attn().wo().quantize();
        block.ffn().fc1().quantize();
        block.ffn().fc2().quantize();
    }
    lmHead_.quantize();
}

size_t Model::totalLinearWeightBytes() {
    size_t total = lmHead_.weightBytes();
    for (auto& block : blocks_) {
        total += block.attn().wq().weightBytes();
        total += block.attn().wk().weightBytes();
        total += block.attn().wv().weightBytes();
        total += block.attn().wo().weightBytes();
        total += block.ffn().fc1().weightBytes();
        total += block.ffn().fc2().weightBytes();
    }
    return total;
}

void Model::save(const std::string& path) const {
    std::ofstream out(path, std::ios::binary);
    if (!out) throw std::runtime_error("Model::save - cannot open " + path);

    const char magic[4] = {'N', 'M', 'D', 'L'};
    out.write(magic, 4);

    int32_t vocabSize = config_.vocabSize, embedDim = config_.embedDim, numLayers = config_.numLayers;
    int32_t numHeads = config_.numHeads, ffnHiddenDim = config_.ffnHiddenDim, maxSeqLen = config_.maxSeqLen;
    out.write(reinterpret_cast<const char*>(&vocabSize), sizeof(vocabSize));
    out.write(reinterpret_cast<const char*>(&embedDim), sizeof(embedDim));
    out.write(reinterpret_cast<const char*>(&numLayers), sizeof(numLayers));
    out.write(reinterpret_cast<const char*>(&numHeads), sizeof(numHeads));
    out.write(reinterpret_cast<const char*>(&ffnHiddenDim), sizeof(ffnHiddenDim));
    out.write(reinterpret_cast<const char*>(&maxSeqLen), sizeof(maxSeqLen));

    tokenEmbedding_.save(out);
    for (const auto& block : blocks_) block.save(out);
    finalNorm_.save(out);
    lmHead_.save(out);
    // caches_ deliberately NOT saved - generation state, not a parameter.
}

Model Model::load(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("Model::load - cannot open " + path);

    char magic[4];
    in.read(magic, 4);
    if (magic[0] != 'N' || magic[1] != 'M' || magic[2] != 'D' || magic[3] != 'L') {
        throw std::runtime_error("Model::load - bad magic in " + path);
    }

    Config cfg{};
    int32_t v = 0;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.vocabSize = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.embedDim = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.numLayers = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.numHeads = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.ffnHiddenDim = v;
    in.read(reinterpret_cast<char*>(&v), sizeof(v)); cfg.maxSeqLen = v;

    Model model(cfg, /*seed=*/1); // random weights - immediately overwritten below

    model.tokenEmbedding_.load(in);
    for (auto& block : model.blocks_) block.load(in);
    model.finalNorm_.load(in);
    model.lmHead_.load(in);

    return model;
}

} // namespace novallm
