#include "Linear.h"
#include "../math/Matrix.h"
#include <random>
#include <ostream>
#include <istream>
#include <stdexcept>

namespace novallm {

Linear::Linear(int inDim, int outDim, unsigned int seed, bool useBias)
    : inDim_(inDim), outDim_(outDim), useBias_(useBias),
      weight_({inDim, outDim}), bias_({outDim}, 0.0f) {
    std::mt19937 rng(seed);
    std::normal_distribution<float> dist(0.0f, 0.02f); // GPT-2-style small init
    for (size_t i = 0; i < weight_.size(); ++i) {
        weight_.data()[i] = dist(rng);
    }
    // bias_ already zero-initialized via the fill-value constructor
}

Tensor Linear::forward(const Tensor& x) const {
    Tensor y = isQuantized_ ? quantizedMatmul(x, quantizedWeight_)
                             : matrix::matmul(x, weight_);
    if (useBias_) {
        y = matrix::addBias(y, bias_);
    }
    return y;
}

Linear::Grads Linear::backward(const Tensor& x, const Tensor& gradOutput) const {
    if (isQuantized_) {
        throw std::logic_error(
            "Linear::backward - this layer was quantize()'d (inference-only); "
            "there is no float weight left to compute a gradient against");
    }
    Grads g;

    // y = x @ W + b
    // dL/dx = dL/dy @ W^T
    Tensor wT = matrix::transpose(weight_);
    g.gradInput = matrix::matmul(gradOutput, wT);

    // dL/dW = x^T @ dL/dy
    Tensor xT = matrix::transpose(x);
    g.gradWeight = matrix::matmul(xT, gradOutput);

    // dL/db = column-sum of dL/dy (bias is added identically to every row)
    int n = gradOutput.dim(0);
    int outDim = gradOutput.dim(1);
    Tensor gb({outDim}, 0.0f);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < outDim; ++j) {
            gb.data()[j] += gradOutput.at({i, j});
        }
    }
    g.gradBias = gb;

    return g;
}

void Linear::quantize() {
    if (isQuantized_) return; // already quantized - idempotent, not an error
    quantizedWeight_ = novallm::quantize(weight_);
    weight_ = Tensor(); // release the float buffer - the actual memory saving
    isQuantized_ = true;
}

size_t Linear::weightBytes() const {
    return isQuantized_
        ? quantizedWeight_.data.size() * sizeof(int8_t) + sizeof(float) // + one scale
        : weight_.size() * sizeof(float);
}

Tensor& Linear::weight() {
    if (isQuantized_) {
        throw std::logic_error(
            "Linear::weight - this layer was quantize()'d; the float weight "
            "was discarded, see Linear::quantize()'s doc comment");
    }
    return weight_;
}

const Tensor& Linear::weight() const {
    if (isQuantized_) {
        throw std::logic_error(
            "Linear::weight - this layer was quantize()'d; the float weight "
            "was discarded, see Linear::quantize()'s doc comment");
    }
    return weight_;
}

void Linear::save(std::ostream& out) const {
    if (isQuantized_) {
        throw std::logic_error(
            "Linear::save - quantized weight persistence isn't supported yet "
            "(planned for a later subsystem-8 pass); save() needs a float weight");
    }
    weight_.save(out);
    bias_.save(out);
    char useBiasFlag = useBias_ ? 1 : 0;
    out.write(&useBiasFlag, 1);
}

void Linear::load(std::istream& in) {
    isQuantized_ = false; // load() always produces a fresh, non-quantized layer
    weight_.load(in);
    bias_.load(in);
    char useBiasFlag = 0;
    in.read(&useBiasFlag, 1);
    useBias_ = (useBiasFlag != 0);
    inDim_ = weight_.dim(0);
    outDim_ = weight_.dim(1);
}

} // namespace novallm
