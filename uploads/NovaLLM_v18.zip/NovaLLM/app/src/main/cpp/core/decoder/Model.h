#pragma once
#include <vector>
#include <string>
#include <iosfwd>
#include "../math/Tensor.h"
#include "../math/MemoryPool.h"
#include "../embedding/TokenEmbedding.h"
#include "../embedding/PositionalEncoding.h"
#include "../transformer/Block.h"
#include "../transformer/LayerNorm.h"
#include "../transformer/Linear.h"
#include "../transformer/KVCache.h"

namespace novallm {

// The full assembled model: embedding -> +positional encoding -> N
// transformer blocks -> final LayerNorm -> LM head -> logits over the
// vocabulary. "Logits" from the original component list isn't a separate
// class - it's just the shape {seqLen, vocabSize} this returns.
//
// Weights are random (untrained) until subsystem 7 exists. This class is
// the forward-pass machinery; it says nothing meaningful until training
// shapes those weights into something.
class Model {
public:
    struct Config {
        int vocabSize;
        int embedDim;
        int numLayers;
        int numHeads;
        int ffnHiddenDim;
        int maxSeqLen;
    };

    explicit Model(const Config& config, unsigned int seed = 42);

    struct Grads {
        Tensor gradTokenEmbedding; // {vocabSize, embedDim}
        std::vector<TransformerBlock::Grads> blockGrads; // one per layer, in forward order
        LayerNorm::Grads finalNormGrads;
        Linear::Grads lmHeadGrads;
    };

    // ids -> logits, shape {seqLen, vocabSize}. Full recompute every call -
    // for training / whole-sequence scoring, where there's no "previous
    // step" to cache.
    Tensor forward(const std::vector<int>& ids) const;

    // gradLogits is dL/dLogits (e.g. from CrossEntropyLoss::forwardBackward
    // on this same `ids`) - backprops all the way through the LM head,
    // final norm, every block in reverse, and scatter-adds into the
    // embedding table. PositionalEncoding has no learnable parameters, so
    // the gradient reaching "x before the blocks" flows entirely to the
    // embedding - nothing is lost or needs splitting there.
    Grads backward(const std::vector<int>& ids, const Tensor& gradLogits) const;

    // Incremental (KV-cached) forward for fast generation. `newIds` is
    // JUST the new token(s) since the last call - the whole prompt on the
    // first call after resetCache(), then one token at a time after.
    // Returns logits for just those new positions, {newLen, vocabSize}.
    // Mutates internal per-layer cache state; call resetCache() before
    // starting a new, unrelated sequence.
    Tensor forwardIncremental(const std::vector<int>& newIds);
    void resetCache();
    const Config& config() const { return config_; }

    // Diagnostic only, not for decision logic: lets tests/tooling confirm
    // the scratch pool below is actually being exercised by
    // forwardIncremental() and staying within the budget it was
    // constructed with.
    size_t scratchPoolUsed() const { return scratchPool_.used(); }
    size_t scratchPoolCapacity() const { return scratchPool_.capacity(); }

    // Direct access to every learnable component - needed for gradient-
    // checking, and later for the optimizer to walk every parameter.
    TokenEmbedding& tokenEmbedding() { return tokenEmbedding_; }
    TransformerBlock& block(int i) { return blocks_[static_cast<size_t>(i)]; }
    int numBlocks() const { return static_cast<int>(blocks_.size()); }
    LayerNorm& finalNorm() { return finalNorm_; }
    Linear& lmHead() { return lmHead_; }

    // Persists/restores every learned weight (embedding, all blocks,
    // final norm, LM head). Generation cache state is NOT part of this -
    // it's ephemeral per-sequence state, not a learned parameter, and a
    // freshly loaded model always starts with empty caches. Throws
    // std::logic_error if any layer is currently quantized - see
    // Linear::save()'s doc comment.
    void save(const std::string& path) const;
    static Model load(const std::string& path);

    // Quantizes every Linear layer's weight to int8 (see
    // Linear::quantize()) - all four of each block's attention
    // projections, both of its FeedForward layers, and the LM head.
    // TokenEmbedding's lookup table is untouched: it's indexed, not
    // multiplied, so the same per-tensor scheme doesn't apply to it the
    // same way - left for a later pass. Meant for a model that's done
    // training: forward()/forwardIncremental() keep working afterward,
    // but calling backward() (or any quantized layer's weight()) throws
    // std::logic_error, and save() throws until a later pass adds
    // quantized persistence.
    void quantize();

    // Sum of every Linear layer's weightBytes() (see Linear.h) - float32
    // normally, ~4x smaller after quantize(). Diagnostic / for measuring
    // the actual savings, not decision logic. Excludes TokenEmbedding's
    // table and PositionalEncoding's table, neither of which quantize()
    // touches.
    size_t totalLinearWeightBytes();

private:
    Config config_;
    TokenEmbedding tokenEmbedding_;
    PositionalEncoding positionalEncoding_;
    std::vector<TransformerBlock> blocks_;
    LayerNorm finalNorm_;
    Linear lmHead_;
    std::vector<KVCache> caches_; // one per layer, kept in lockstep

    // Ephemeral per-call activation arena for forwardIncremental() ONLY -
    // reset() at the top of every call, so nothing built from it may
    // outlive that single call. forward()/backward() (training) never
    // touch this: backward() needs its intermediates to outlive the
    // call that produced them, which a reset-per-call arena can't give.
    MemoryPool scratchPool_;
};

} // namespace novallm
