#include "Quantization.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace novallm {

size_t QuantizedTensor::size() const {
    size_t n = 1;
    for (int d : shape) n *= static_cast<size_t>(d);
    return n;
}

int QuantizedTensor::rank() const { return static_cast<int>(shape.size()); }

int QuantizedTensor::dim(int axis) const { return shape.at(static_cast<size_t>(axis)); }

QuantizedTensor quantize(const Tensor& t) {
    QuantizedTensor q;
    q.shape = t.shape();
    size_t n = t.size();
    const float* d = t.data();

    float absMax = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        absMax = std::max(absMax, std::fabs(d[i]));
    }
    q.scale = (absMax > 0.0f) ? (absMax / 127.0f) : 1.0f;

    q.data.resize(n);
    for (size_t i = 0; i < n; ++i) {
        float scaled = d[i] / q.scale;
        int rounded = static_cast<int>(std::lround(scaled));
        rounded = std::max(-127, std::min(127, rounded));
        q.data[i] = static_cast<int8_t>(rounded);
    }
    return q;
}

Tensor dequantize(const QuantizedTensor& q) {
    Tensor t(q.shape);
    float* d = t.data();
    size_t n = q.size();
    for (size_t i = 0; i < n; ++i) {
        d[i] = static_cast<float>(q.data[i]) * q.scale;
    }
    return t;
}

Tensor quantizedMatmul(const Tensor& x, const QuantizedTensor& wq) {
    return quantizedMatmul(x, wq, ThreadPool::shared());
}

Tensor quantizedMatmul(const Tensor& x, const QuantizedTensor& wq, ThreadPool& pool) {
    if (x.rank() != 2 || wq.rank() != 2) {
        throw std::invalid_argument("quantizedMatmul: both operands must be rank 2");
    }
    int m = x.dim(0);
    int k = x.dim(1);
    int k2 = wq.dim(0);
    int n = wq.dim(1);
    if (k != k2) {
        throw std::invalid_argument("quantizedMatmul: inner dimensions do not match");
    }

    Tensor out({m, n});
    const float* xd = x.data();
    const int8_t* wd = wq.data.data();
    float* od = out.data();

    // Same i-p-j loop order and zero-skip as matrix::matmul, and the
    // same column-parallel split (see matrix::matmul's comment for the
    // m=1 reasoning). Accumulates unscaled products only; scale is
    // constant for the whole tensor, so it's applied once in a single
    // pass after every chunk has finished, not per chunk - simpler to
    // verify correct, and scaling is O(m*n), trivial next to the O(m*n*k)
    // accumulation above it either way.
    pool.parallelFor(n, [&](int colBegin, int colEnd) {
        for (int i = 0; i < m; ++i) {
            float* orow = od + static_cast<size_t>(i) * n;
            for (int p = 0; p < k; ++p) {
                float xv = xd[static_cast<size_t>(i) * k + p];
                if (xv == 0.0f) continue;
                const int8_t* wrow = wd + static_cast<size_t>(p) * n;
                for (int j = colBegin; j < colEnd; ++j) {
                    orow[j] += xv * static_cast<float>(wrow[j]);
                }
            }
        }
    });
    size_t total = static_cast<size_t>(m) * static_cast<size_t>(n);
    for (size_t idx = 0; idx < total; ++idx) od[idx] *= wq.scale;
    return out;
}

} // namespace novallm
