// Standalone correctness tests for core/math's int8 quantization
// primitives (Quantization.h) and their wiring into Linear/Model
// (subsystem 8, part 2). No Android/JNI needed.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_quantization.cpp \
//     ../app/src/main/cpp/core/math/*.cpp \
//     ../app/src/main/cpp/core/tokenizer/*.cpp \
//     ../app/src/main/cpp/core/embedding/*.cpp \
//     ../app/src/main/cpp/core/transformer/*.cpp \
//     ../app/src/main/cpp/core/decoder/*.cpp \
//     ../app/src/main/cpp/core/training/*.cpp \
//     -o test_quantization && ./test_quantization
#include <cstdio>
#include <cmath>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include "core/math/Tensor.h"
#include "core/math/Matrix.h"
#include "core/math/Quantization.h"
#include "core/transformer/Linear.h"
#include "core/tokenizer/Tokenizer.h"
#include "core/decoder/Model.h"
#include "core/decoder/Generator.h"
#include "core/training/Loss.h"
#include "core/training/ModelOptimizer.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

// ---------------------------------------------------------------------
// quantize() / dequantize()
// ---------------------------------------------------------------------

void testRoundTripStaysWithinHalfAScale() {
    Tensor t({2, 3});
    float vals[] = {1.0f, -2.0f, 3.5f, 0.0f, -3.5f, 2.0f};
    for (int i = 0; i < 6; ++i) t.data()[i] = vals[i];

    QuantizedTensor q = quantize(t);
    Tensor back = dequantize(q);

    bool withinBound = true;
    for (size_t i = 0; i < t.size(); ++i) {
        if (std::fabs(back.data()[i] - t.data()[i]) > q.scale / 2.0f + 1e-6f) withinBound = false;
    }
    expectTrue(withinBound, "quantize/dequantize: every element stays within +/- scale/2 of the original");
}

void testAllZeroTensorDoesNotDivideByZero() {
    Tensor t({4}, 0.0f);
    QuantizedTensor q = quantize(t);
    bool allZeroCodes = true;
    for (auto b : q.data) if (b != 0) allZeroCodes = false;
    Tensor back = dequantize(q);
    bool allZeroBack = true;
    for (size_t i = 0; i < back.size(); ++i) if (back.data()[i] != 0.0f) allZeroBack = false;
    expectTrue(std::isfinite(q.scale) && q.scale > 0.0f, "quantize: an all-zero tensor gets a finite, positive fallback scale");
    expectTrue(allZeroCodes, "quantize: an all-zero tensor quantizes to all-zero codes");
    expectTrue(allZeroBack, "quantize: an all-zero tensor round-trips back to all zeros");
}

void testExtremeValueHitsPlusOrMinus127Exactly() {
    Tensor t({3});
    t.data()[0] = -5.0f;
    t.data()[1] = 0.0f;
    t.data()[2] = 5.0f; // the absmax element
    QuantizedTensor q = quantize(t);
    expectTrue(q.data[2] == 127, "quantize: the absmax element maps to exactly +127");
    expectTrue(q.data[0] == -127, "quantize: the most-negative element maps to exactly -127 (not -128)");
}

// ---------------------------------------------------------------------
// quantizedMatmul() vs matrix::matmul()
// ---------------------------------------------------------------------

void testQuantizedMatmulCloseToFloatMatmul() {
    Tensor x({2, 4});
    Tensor w({4, 3});
    float xv[] = {0.5f, -1.2f, 0.3f, 2.0f, -0.7f, 1.1f, 0.9f, -0.4f};
    float wv[] = {0.1f, -0.2f, 0.05f, 0.3f, -0.15f, 0.25f,
                  -0.05f, 0.4f, -0.3f, 0.2f, 0.1f, -0.1f};
    for (int i = 0; i < 8; ++i) x.data()[i] = xv[i];
    for (int i = 0; i < 12; ++i) w.data()[i] = wv[i];

    Tensor exact = matrix::matmul(x, w);
    QuantizedTensor wq = quantize(w);
    Tensor approx = quantizedMatmul(x, wq);

    // Generous, empirically-motivated bound: worst case per output
    // element is roughly (inner dimension) * (max |x|) * (scale/2).
    float maxAbsX = 2.0f;
    float bound = static_cast<float>(w.dim(0)) * maxAbsX * (wq.scale / 2.0f) + 1e-4f;
    bool close = true;
    float worst = 0.0f;
    for (size_t i = 0; i < exact.size(); ++i) {
        float diff = std::fabs(exact.data()[i] - approx.data()[i]);
        worst = std::max(worst, diff);
        if (diff > bound) close = false;
    }
    std::printf("      (worst-case matmul diff observed: %.6f, bound: %.6f)\n", worst, bound);
    expectTrue(close, "quantizedMatmul: stays within the expected error bound of matrix::matmul");
}

// ---------------------------------------------------------------------
// Linear
// ---------------------------------------------------------------------

void testLinearForwardCloseAfterQuantize() {
    Linear lin(8, 5, /*seed=*/7);
    Tensor x({3, 8});
    for (size_t i = 0; i < x.size(); ++i) x.data()[i] = static_cast<float>(i % 5) - 2.0f;

    Tensor before = lin.forward(x);
    lin.quantize();
    Tensor after = lin.forward(x);

    bool close = true;
    for (size_t i = 0; i < before.size(); ++i) {
        if (std::fabs(before.data()[i] - after.data()[i]) > 0.05f) close = false;
    }
    expectTrue(close, "Linear: forward() output stays close after quantize() (small-init weights, generous bound)");
    expectTrue(lin.isQuantized(), "Linear: isQuantized() reports true after quantize()");
}

void testLinearWeightAndBackwardThrowAfterQuantize() {
    Linear lin(4, 4, /*seed=*/3);
    Tensor x({2, 4}, 1.0f);
    Tensor gradOut({2, 4}, 1.0f);
    lin.quantize();

    bool weightThrew = false;
    try { lin.weight(); } catch (const std::logic_error&) { weightThrew = true; }
    expectTrue(weightThrew, "Linear: weight() throws std::logic_error once quantized");

    bool backwardThrew = false;
    try { lin.backward(x, gradOut); } catch (const std::logic_error&) { backwardThrew = true; }
    expectTrue(backwardThrew, "Linear: backward() throws std::logic_error once quantized");

    bool saveThrew = false;
    std::ostringstream dummy;
    try { lin.save(dummy); } catch (const std::logic_error&) { saveThrew = true; }
    expectTrue(saveThrew, "Linear: save() throws std::logic_error once quantized (persistence not supported yet)");
}

void testLinearWeightBytesShrinksByExpectedRatio() {
    Linear lin(64, 64, /*seed=*/5); // 4096 weight elements - big enough that the
                                     // fixed scale overhead barely matters
    size_t before = lin.weightBytes();
    lin.quantize();
    size_t after = lin.weightBytes();

    size_t n = 64 * 64;
    size_t expectedBefore = n * sizeof(float);
    size_t expectedAfter = n * sizeof(int8_t) + sizeof(float);
    expectTrue(before == expectedBefore, "Linear: weightBytes() matches float32 size before quantize()");
    expectTrue(after == expectedAfter, "Linear: weightBytes() matches int8+scale size after quantize()");
    double ratio = static_cast<double>(before) / static_cast<double>(after);
    expectTrue(ratio > 3.9 && ratio < 4.0, "Linear: quantize() shrinks weight storage by ~4x for a reasonably large layer");
}

// ---------------------------------------------------------------------
// End to end: a REAL trained model, quantized, still generates the
// same thing. Confidence (very low loss) is what makes greedy argmax
// robust to the small noise quantization introduces - an untrained,
// unconfident model would not be a meaningful test of this property.
// ---------------------------------------------------------------------

void testTrainedModelGenerationSurvivesQuantization() {
    Tokenizer tok;
    std::vector<std::string> corpus = {
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox jumps over the lazy dog",
        "the quick brown fox jumps over the lazy dog"
    };
    tok.train(corpus, 40);

    Model::Config cfg;
    cfg.vocabSize = static_cast<int>(tok.vocabSize());
    cfg.embedDim = 16;
    cfg.numLayers = 2;
    cfg.numHeads = 4;
    cfg.ffnHiddenDim = 64;
    cfg.maxSeqLen = 32;
    Model model(cfg, 42);
    ModelOptimizer optimizer(cfg.numLayers);

    std::string text = "the quick brown fox jumps over the lazy dog";
    std::vector<int> ids = tok.encode(text);
    std::vector<int> targets(ids.begin() + 1, ids.end());
    targets.push_back(ids[0]);

    float lastLoss = 0.0f;
    for (int step = 0; step < 300; ++step) {
        Tensor logits = model.forward(ids);
        Tensor gradLogits;
        lastLoss = CrossEntropyLoss::forwardBackward(logits, targets, gradLogits);
        Model::Grads grads = model.backward(ids, gradLogits);
        optimizer.step(model, grads, 0.01f);
    }
    expectTrue(lastLoss < 0.01f, "sanity: training actually drove loss low enough to be confident (< 0.01)");

    Generator::GenerationParams genParams;
    genParams.maxNewTokens = 15;
    genParams.sampling.temperature = 0.0f; // greedy, deterministic

    model.resetCache();
    Generator genBefore(model, tok, 1);
    std::string before = genBefore.generate("the quick", genParams);

    size_t bytesBefore = model.totalLinearWeightBytes();
    model.quantize();
    size_t bytesAfter = model.totalLinearWeightBytes();

    model.resetCache();
    Generator genAfter(model, tok, 1);
    std::string after = genAfter.generate("the quick", genParams);

    std::printf("      (weight bytes: %zu -> %zu, generated before: \"%s\", after: \"%s\")\n",
                bytesBefore, bytesAfter, before.c_str(), after.c_str());
    expectTrue(bytesAfter < bytesBefore / 3, "Model: quantize() shrinks total Linear weight bytes by well over 3x");
    expectTrue(before == after, "Model: a confidently-trained model generates the SAME text after quantize()");
}

int main() {
    testRoundTripStaysWithinHalfAScale();
    testAllZeroTensorDoesNotDivideByZero();
    testExtremeValueHitsPlusOrMinus127Exactly();

    testQuantizedMatmulCloseToFloatMatmul();

    testLinearForwardCloseAfterQuantize();
    testLinearWeightAndBackwardThrowAfterQuantize();
    testLinearWeightBytesShrinksByExpectedRatio();

    testTrainedModelGenerationSurvivesQuantization();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
