package com.zipapkbuilder

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.drawable.ColorDrawable
import androidx.core.widget.NestedScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // ── UI ──────────────────────────────────────────────────────────────────
    private lateinit var etToken: EditText
    private lateinit var tvOwnerInfo: TextView
    private lateinit var etRepo: EditText
    private lateinit var etBranch: EditText
    private lateinit var btnPickZip: Button
    private lateinit var tvFileName: TextView
    private lateinit var btnUploadBuild: Button
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private var    btnDownloadApk: Button? = null   // removed from layout; kept nullable for logic compat
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: NestedScrollView
    private lateinit var btnManageZips: Button
    private lateinit var btnWorkflowLog: Button
    private var    btnDownloadLogs: Button? = null  // merged into btnWorkflowLog
    private lateinit var btnBrowseArtifacts: Button
    private var    btnSavedRepos: Button? = null    // moved to settings dialog
    private lateinit var btnCopyLog: Button
    private lateinit var btnSaveLog: Button
    private lateinit var btnSettings: android.widget.ImageButton
    private lateinit var etKeystorePass: EditText
    private lateinit var etKeyAlias: EditText
    private lateinit var btnGenerateKeystore: Button
    private lateinit var tvKeystoreStatus: TextView

    // ── State ────────────────────────────────────────────────────────────────
    private val mainHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private var selectedZipUri: Uri? = null
    private var selectedZipName = ""
    private var artifactDownloadUrl: String? = null
    private var isBusy = false

    // ── Console dot animators ─────────────────────────────────────────────────
    private var dotRed:    View? = null
    private var dotYellow: View? = null
    private var dotGreen:  View? = null
    private var dotAnimRed:    android.animation.AnimatorSet? = null
    private var dotAnimYellow: android.animation.AnimatorSet? = null
    private var dotAnimGreen:  android.animation.AnimatorSet? = null

    // ── File-upload-to-repo state ─────────────────────────────────────────────
    /** Set before launching pickUploadFile so the callback knows where to put it. */
    private var pendingUploadToken  = ""
    private var pendingUploadOwner  = ""
    private var pendingUploadRepo   = ""
    private var pendingUploadBranch = ""
    private var pendingUploadPath   = ""   // folder path inside repo

    // Callback for settings "Change" download location button
    private var onFolderPicked: ((Uri) -> Unit)? = null

    private val pickFolderLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                prefs.edit().putString(PREF_DOWNLOAD_URI, uri.toString()).apply()
                onFolderPicked?.invoke(uri)
                onFolderPicked = null
            }
        }

    private val pickUploadFile =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val token  = pendingUploadToken
            val owner  = pendingUploadOwner
            val repo   = pendingUploadRepo
            val branch = pendingUploadBranch
            val folder = pendingUploadPath
            if (token.isEmpty() || owner.isEmpty() || repo.isEmpty()) {
                appendLog("⚠ Upload context lost — try again."); return@registerForActivityResult
            }
            setBusy(true)
            thread {
                for (uri in uris) {
                    val fileName = resolveUploadFileName(uri)
                    val filePath = if (folder.isEmpty()) fileName else "$folder/$fileName"
                    appendLog("Uploading $fileName …")
                    uploadFileToRepo(token, owner, repo, branch, filePath, uri, folder)
                }
                mainHandler.post { fetchAndBrowse(token, owner, repo, branch, folder) }
            }
        }

    private var lastOwner      = ""
    private var lastRemotePath = ""
    private var lastFileSha: String? = null
    private var lastRunId: Long = -1L

    // ── Runtime storage permission (Android 7–9 / API 24–28) ─────────────────
    /** Stored so the permission result callback knows what to run after grant. */
    private var pendingStorageAction: (() -> Unit)? = null

    private val requestWritePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                pendingStorageAction?.invoke()
            } else {
                appendLog("⚠ Storage permission denied — cannot save to Downloads on this device.")
            }
            pendingStorageAction = null
        }

    /**
     * Runs [action] only when the app holds WRITE_EXTERNAL_STORAGE (required on
     * API 24–28).  On API 29+ the MediaStore path is used and no permission is needed.
     * Must be called from the main thread.
     */
    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            action(); return
        }
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            action()
        } else {
            pendingStorageAction = action
            requestWritePermission.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    /** Represents one entry returned by the GitHub Contents API. */
    private data class RepoItem(val type: String, val name: String, val path: String, val sha: String)

    // ── SharedPreferences keys ────────────────────────────────────────────────
    companion object {
        private const val PREF_ARTIFACT_URL   = "artifact_url"
        private const val PREF_ARTIFACT_NAME  = "artifact_name"
        private const val PREF_LAST_RUN_ID    = "last_run_id"
        private const val PREF_LAST_OWNER     = "last_owner"
        private const val PREF_LAST_REPO_KEY  = "last_repo_saved"
        private const val PREF_KEYSTORE_ALIAS = "keystore_alias"
        private const val PREF_KEYSTORE_SAVED = "keystore_saved"
        private const val PREF_SAVED_REPOS     = "saved_repos"
        private const val PREF_ZIP_NAME        = "zip_name"
        private const val PREF_DOWNLOAD_URI    = "download_uri"
        private const val PREF_DOWNLOAD_HISTORY = "download_history"
    }

    // dp convenience for programmatic views
    private val Int.dp get() = (this * resources.displayMetrics.density).toInt()

    // ── Embedded workflow YAML ────────────────────────────────────────────────
    private val WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Build APK

on:
  push:
    branches: [ main, master ]
    paths:
      - 'uploads/**'
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    permissions:
      contents: write

    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        with:
          token: ${d}{{ secrets.GITHUB_TOKEN }}

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Cache NDK and CMake
        id: cache-ndk
        uses: actions/cache@v4
        with:
          path: |
            ${d}{{ env.ANDROID_HOME }}/ndk/25.2.9519653
            ${d}{{ env.ANDROID_HOME }}/ndk/25.1.8937393
            ${d}{{ env.ANDROID_HOME }}/cmake/3.22.1
          key: ndk-25.2.9519653-25.1.8937393-cmake-3.22.1

      - name: Install NDK and CMake
        run: |
          for NDK_VER in "25.2.9519653" "25.1.8937393"; do
            if [ ! -d "${d}ANDROID_SDK_ROOT/ndk/${d}NDK_VER" ]; then
              echo "Installing NDK ${d}NDK_VER..."
              sdkmanager --install "ndk;${d}NDK_VER"
            else
              echo "NDK ${d}NDK_VER already present"
            fi
          done
          if [ ! -d "${d}ANDROID_SDK_ROOT/cmake/3.22.1" ]; then
            sdkmanager --install "cmake;3.22.1"
          fi
          echo "ANDROID_NDK_HOME=${d}ANDROID_SDK_ROOT/ndk/25.2.9519653" >> ${d}GITHUB_ENV

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.6'
          cache-read-only: false

      - name: Unzip project
        run: |
          ZIP=${d}(find . -path './.git' -prune -o -maxdepth 3 -name "*.zip" -printf "%T@ %p\n" | sort -rn | head -1 | cut -d" " -f2-)
          if [ -z "${d}ZIP" ]; then
            echo "##[error]No ZIP file found in repository!"
            exit 1
          fi
          ZIP_NAME=${d}(basename "${d}ZIP" .zip)
          echo "zip_name=${d}ZIP_NAME" >> ${d}GITHUB_ENV
          echo "zip_path=${d}ZIP" >> ${d}GITHUB_ENV
          echo "Found zip: ${d}ZIP"
          unzip -q "${d}ZIP" -d extracted

      - name: Find project directory
        id: find_project
        run: |
          RESULT=${d}(find extracted -maxdepth 4 \( -name "settings.gradle" -o -name "settings.gradle.kts" \) | head -1)
          if [ -z "${d}RESULT" ]; then
            echo "##[error]No settings.gradle found inside the zip!"
            find extracted | sort
            exit 1
          fi
          PROJECT_DIR=${d}(dirname "${d}RESULT")
          echo "Found project at: ${d}PROJECT_DIR"
          echo "project_dir=${d}PROJECT_DIR" >> ${d}GITHUB_OUTPUT

      - name: Cache CMake / C++ build outputs
        uses: actions/cache@v4
        with:
          path: ${d}{{ steps.find_project.outputs.project_dir }}/app/.cxx
          key: cxx-debug-${d}{{ hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp') }}
          restore-keys: cxx-debug-

      - name: Fetch gradle-wrapper.jar
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          GRADLE_VERSION="8.6"
          JAR="gradle/wrapper/gradle-wrapper.jar"
          mkdir -p gradle/wrapper
          curl --fail --silent --show-error --location \
            "https://raw.githubusercontent.com/gradle/gradle/v${d}{GRADLE_VERSION}.0/gradle/wrapper/gradle-wrapper.jar" \
            -o "${d}JAR"
          SIZE=${d}(stat -c%s "${d}JAR")
          if [ "${d}SIZE" -lt 10000 ]; then
            echo "ERROR: gradle-wrapper.jar too small (${d}{SIZE} bytes)"
            exit 1
          fi

      - name: Make gradlew executable
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: chmod +x gradlew && sed -i 's/\r//' gradlew

      - name: Decode keystore (if available)
        id: keystore
        run: |
          if [ -n "${d}{{ secrets.KEYSTORE_BASE64 }}" ]; then
            echo "${d}{{ secrets.KEYSTORE_BASE64 }}" | base64 --decode > ${d}RUNNER_TEMP/release.jks
            echo "KEYSTORE_PATH=${d}RUNNER_TEMP/release.jks" >> ${d}GITHUB_ENV
            echo "HAS_KEYSTORE=true" >> ${d}GITHUB_ENV
            echo "Keystore decoded ✓"
          else
            echo "HAS_KEYSTORE=false" >> ${d}GITHUB_ENV
            echo "No KEYSTORE_BASE64 secret — building debug APK"
          fi

      - name: Build APK
        id: build
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          if [ "${d}{{ env.HAS_KEYSTORE }}" = "true" ]; then
            ./gradlew assembleRelease --no-daemon --configuration-cache --build-cache --parallel \
              -Pandroid.injected.signing.store.file="${d}{{ env.KEYSTORE_PATH }}" \
              -Pandroid.injected.signing.store.password="${d}{{ secrets.STORE_PASSWORD }}" \
              -Pandroid.injected.signing.key.alias="${d}{{ secrets.KEY_ALIAS }}" \
              -Pandroid.injected.signing.key.password="${d}{{ secrets.KEY_PASSWORD }}"
          else
            ./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
          fi
        env:
          ANDROID_NDK_HOME: ${d}{{ env.ANDROID_NDK_HOME }}

      - name: Locate APK
        id: apk
        working-directory: ${d}{{ steps.find_project.outputs.project_dir }}
        run: |
          if [ "${d}{{ env.HAS_KEYSTORE }}" = "true" ]; then
            APK_PATH=${d}(find app/build/outputs/apk/release -name "*.apk" | head -1)
            echo "APK type: release"
          else
            APK_PATH=${d}(find app/build/outputs/apk/debug -name "*.apk" | head -1)
            echo "APK type: debug"
          fi
          echo "apk_path=${d}APK_PATH" >> ${d}GITHUB_OUTPUT

      - name: Upload APK artifact
        if: success()
        uses: actions/upload-artifact@v4
        with:
          name: ${d}{{ env.zip_name }}-${d}{{ env.HAS_KEYSTORE == 'true' && 'release' || 'debug' }}-v${d}{{ github.run_number }}
          path: ${d}{{ steps.find_project.outputs.project_dir }}/${d}{{ steps.apk.outputs.apk_path }}
          retention-days: 30

      - name: Clean up - delete zip after successful build
        if: success()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP after build #${d}{{ github.run_number }} [skip ci]"
            git push
          fi

      - name: Clean up - delete zip after failed build
        if: failure()
        run: |
          ZIP="${d}{{ env.zip_path }}"
          if [ -n "${d}ZIP" ] && [ -f "${d}ZIP" ]; then
            git config user.name "github-actions[bot]"
            git config user.email "github-actions[bot]@users.noreply.github.com"
            git rm "${d}ZIP"
            git commit -m "ci: remove ${d}ZIP (build failed #${d}{{ github.run_number }}) [skip ci]"
            git push
          fi
        """.trimIndent()
    }

    // ── Keystore-generation workflow YAML ────────────────────────────────────
    private val KEYSTORE_WORKFLOW_YAML: String by lazy {
        val d = "\$"
        """
name: Generate Keystore

on:
  workflow_dispatch:
    inputs:
      alias:
        description: 'Key alias'
        required: true
        default: 'release'
      password:
        description: 'Keystore password'
        required: true
      validity_days:
        description: 'Validity in days'
        required: false
        default: '10950'
      pat_token:
        description: 'GitHub PAT (used only to save secrets, masked immediately)'
        required: true

jobs:
  keygen:
    runs-on: ubuntu-latest
    permissions:
      contents: read

    steps:
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Generate unique keystore
        id: gen
        run: |
          ALIAS="${d}{{ github.event.inputs.alias }}"
          PASS="${d}{{ github.event.inputs.password }}"
          DAYS="${d}{{ github.event.inputs.validity_days }}"
          TIMESTAMP=${d}(date +%Y%m%d%H%M%S)
          STORE_NAME="keystore_${d}{TIMESTAMP}.jks"

          keytool -genkeypair \
            -alias "${d}ALIAS" \
            -keyalg RSA \
            -keysize 2048 \
            -validity ${d}DAYS \
            -storepass "${d}PASS" \
            -keypass "${d}PASS" \
            -dname "CN=Android Debug, O=Android, C=US" \
            -storetype JKS \
            -keystore "${d}STORE_NAME"

          B64=${d}(base64 -w0 "${d}STORE_NAME")
          echo "keystore_b64=${d}B64"   >> ${d}GITHUB_OUTPUT
          echo "store_name=${d}STORE_NAME" >> ${d}GITHUB_OUTPUT
          echo "alias=${d}ALIAS"        >> ${d}GITHUB_OUTPUT
          echo "Generated: ${d}STORE_NAME"

      - name: Save all secrets to GitHub via API
        env:
          OWNER:    ${d}{{ github.repository_owner }}
          REPO:     ${d}{{ github.event.repository.name }}
        run: |
          # Mask the PAT immediately so it never appears in logs
          GH_TOKEN="${d}{{ github.event.inputs.pat_token }}"
          echo "::add-mask::${d}GH_TOKEN"

          PASS="${d}{{ github.event.inputs.password }}"
          ALIAS="${d}{{ github.event.inputs.alias }}"
          B64="${d}{{ steps.gen.outputs.keystore_b64 }}"
          STORE="${d}{{ steps.gen.outputs.store_name }}"

          set_secret() {
            local name="${d}1" value="${d}2"
            # Get repo public key for encryption
            KEY_JSON=${d}(curl -sf \
              -H "Authorization: Bearer ${d}GH_TOKEN" \
              -H "Accept: application/vnd.github+json" \
              "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/secrets/public-key")
            KEY_ID=${d}(echo "${d}KEY_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['key_id'])")
            PUB_KEY=${d}(echo "${d}KEY_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin)['key'])")

            # Encrypt with libsodium (PyNaCl) — correct sealed-box format GitHub expects
            pip install pynacl -q
            ENCRYPTED=${d}(PYPUBKEY="${d}PUB_KEY" PYVAL="${d}value" python3 -c 'import os,base64; from nacl.public import SealedBox,PublicKey; pk=base64.b64decode(os.environ["PYPUBKEY"]); s=SealedBox(PublicKey(pk)).encrypt(os.environ["PYVAL"].encode()); print(base64.b64encode(s).decode())')
            curl -sf -X PUT \
              -H "Authorization: Bearer ${d}GH_TOKEN" \
              -H "Accept: application/vnd.github+json" \
              "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/secrets/${d}name" \
              -d "{\"encrypted_value\":\"${d}ENCRYPTED\",\"key_id\":\"${d}KEY_ID\"}"
            echo "Secret ${d}name saved ✓"
          }

          set_secret "PAT_TOKEN"     "${d}GH_TOKEN"
          set_secret "KEYSTORE_BASE64" "${d}B64"
          set_secret "STORE_PASSWORD"  "${d}PASS"
          set_secret "KEY_PASSWORD"    "${d}PASS"
          set_secret "KEY_ALIAS"       "${d}ALIAS"
          set_secret "KEYSTORE_FILE"   "${d}STORE"

      - name: Save keystore name to repository variable
        env:
          GH_TOKEN: ${d}{{ github.event.inputs.pat_token }}
          OWNER:    ${d}{{ github.repository_owner }}
          REPO:     ${d}{{ github.event.repository.name }}
        run: |
          STORE="${d}{{ steps.gen.outputs.store_name }}"
          # Try update first, fall back to create
          CODE=${d}(curl -s -o /dev/null -w "%{http_code}" -X PATCH \
            -H "Authorization: Bearer ${d}GH_TOKEN" \
            -H "Accept: application/vnd.github+json" \
            "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/variables/KEYSTORE_FILENAME" \
            -d "{\"value\":\"${d}STORE\"}")
          if [ "${d}CODE" != "204" ]; then
            curl -sf -X POST \
              -H "Authorization: Bearer ${d}GH_TOKEN" \
              -H "Accept: application/vnd.github+json" \
              "https://api.github.com/repos/${d}OWNER/${d}REPO/actions/variables" \
              -d "{\"name\":\"KEYSTORE_FILENAME\",\"value\":\"${d}STORE\"}"
          fi
          echo "Variable KEYSTORE_FILENAME=${d}STORE saved ✓"

      - name: Summary
        run: |
          echo "## ✅ Keystore Generated" >> ${d}GITHUB_STEP_SUMMARY
          echo "" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Field | Value |" >> ${d}GITHUB_STEP_SUMMARY
          echo "|---|---|" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Filename | ${d}{{ steps.gen.outputs.store_name }} |" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Alias | ${d}{{ steps.gen.outputs.alias }} |" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Secrets saved | PAT_TOKEN, KEYSTORE_BASE64, STORE_PASSWORD, KEY_PASSWORD, KEY_ALIAS, KEYSTORE_FILE |" >> ${d}GITHUB_STEP_SUMMARY
          echo "| Variable saved | KEYSTORE_FILENAME |" >> ${d}GITHUB_STEP_SUMMARY
        """.trimIndent()
    }

    // ── File picker ──────────────────────────────────────────────────────────
    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        selectedZipName = resolveFileName(uri)
        tvFileName.text = selectedZipName
        appendLog("Selected: $selectedZipName")
        prefs.edit().putString(PREF_ZIP_NAME, selectedZipName).apply()
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etToken        = findViewById(R.id.etToken)
        tvOwnerInfo    = findViewById(R.id.tvOwnerInfo)
        etRepo         = findViewById(R.id.etRepo)
        etBranch       = findViewById(R.id.etBranch)
        btnPickZip     = findViewById(R.id.btnPickZip)
        tvFileName     = findViewById(R.id.tvFileName)
        btnUploadBuild = findViewById(R.id.btnUploadBuild)
        tvStatus       = findViewById(R.id.tvStatus)
        progressBar    = findViewById(R.id.progressBar)
        // btnDownloadApk removed from layout — stays null
        btnBrowseArtifacts = findViewById(R.id.btnBrowseArtifacts)
        // btnSavedRepos moved to Settings dialog
        btnManageZips  = findViewById(R.id.btnManageZips)
        btnWorkflowLog = findViewById(R.id.btnWorkflowLog)
        // btnDownloadLogs merged into btnWorkflowLog
        btnCopyLog     = findViewById(R.id.btnCopyLog)
        btnSaveLog     = findViewById(R.id.btnSaveLog)
        btnSettings    = findViewById(R.id.btnSettings)
        etKeystorePass     = findViewById(R.id.etKeystorePass)
        etKeyAlias         = findViewById(R.id.etKeyAlias)
        btnGenerateKeystore = findViewById(R.id.btnGenerateKeystore)
        tvKeystoreStatus   = findViewById(R.id.tvKeystoreStatus)
        tvLog              = findViewById(R.id.tvLog)
        scrollLog          = findViewById(R.id.scrollLog)

        // Console dots
        dotRed    = findViewById(R.id.dotRed)
        dotYellow = findViewById(R.id.dotYellow)
        dotGreen  = findViewById(R.id.dotGreen)
        dotRed?.post { startIdleDotAnimations() }

        etToken.setText(prefs.getString("token", ""))
        etRepo.setText(prefs.getString("repo", ""))
        etBranch.setText(prefs.getString("branch", "main"))

        btnPickZip.setOnClickListener     { if (!isBusy) pickZip.launch("application/zip") }
        btnUploadBuild.setOnClickListener  { if (!isBusy) startFlow() }
        btnBrowseArtifacts.setOnClickListener { browseAllArtifacts() }
        btnManageZips.setOnClickListener   { showManageFilesDialog() }
        // Build Log button: choose View or Download
        btnWorkflowLog.setOnClickListener  {
            val logTitle = if (selectedZipName.isNotEmpty()) "Build Log — $selectedZipName" else "Build Log"
            AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                .setTitle(logTitle)
                .setItems(arrayOf("📋  View log in app", "📥  Download log ZIP")) { _, which ->
                    when (which) {
                        0 -> fetchAndShowWorkflowLog()
                        1 -> withStoragePermission { downloadLatestRunLogs() }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnCopyLog.setOnClickListener      { copyLogToClipboard() }
        btnSaveLog.setOnClickListener      { saveLogToFile() }
        btnGenerateKeystore.setOnClickListener { generateKeystore() }
        btnSettings.setOnClickListener     { showSettingsDialog() }
        // Build Log is always enabled — it lists all runs, no active build needed
        btnWorkflowLog.isEnabled = true

        // Restore any previously completed build so Download still works after restart
        restoreSavedBuildState()

        // Restore keystore saved state
        if (prefs.getBoolean(PREF_KEYSTORE_SAVED, false)) {
            val alias = prefs.getString(PREF_KEYSTORE_ALIAS, "") ?: ""
            tvKeystoreStatus.text = "✓ Keystore saved  •  alias: $alias"
            tvKeystoreStatus.visibility = android.view.View.VISIBLE
        }
    }

    // ── Build state persistence ───────────────────────────────────────────────

    private fun saveBuildState(artUrl: String, artName: String, runId: Long, owner: String, repo: String) {
        prefs.edit()
            .putString(PREF_ARTIFACT_URL,  artUrl)
            .putString(PREF_ARTIFACT_NAME, artName)
            .putLong(PREF_LAST_RUN_ID,     runId)
            .putString(PREF_LAST_OWNER,    owner)
            .putString(PREF_LAST_REPO_KEY, repo)
            .apply()
    }

    private fun clearBuildState() {
        prefs.edit()
            .remove(PREF_ARTIFACT_URL)
            .remove(PREF_ARTIFACT_NAME)
            .remove(PREF_LAST_RUN_ID)
            .remove(PREF_LAST_OWNER)
            .remove(PREF_LAST_REPO_KEY)
            .apply()
    }

    /**
     * On cold start, checks SharedPreferences for the last successful build.
     * If found, immediately re-enables the Download button so the user can still
     * download the APK even after killing and reopening the app.
     */
    private fun restoreSavedBuildState() {
        val savedUrl   = prefs.getString(PREF_ARTIFACT_URL, null)
        val savedName  = prefs.getString(PREF_ARTIFACT_NAME, "APK") ?: "APK"
        val savedRunId = prefs.getLong(PREF_LAST_RUN_ID, -1L)
        val savedOwner = prefs.getString(PREF_LAST_OWNER, "") ?: ""
        val savedRepo  = prefs.getString(PREF_LAST_REPO_KEY, "") ?: ""
        val savedZip   = prefs.getString(PREF_ZIP_NAME, "") ?: ""
        if (savedZip.isNotEmpty()) selectedZipName = savedZip

        if (!savedUrl.isNullOrEmpty()) {
            artifactDownloadUrl      = savedUrl
            lastRunId                = savedRunId
            lastOwner                = savedOwner
            btnDownloadApk?.isEnabled = true


            if (savedOwner.isNotEmpty()) tvOwnerInfo.text = "✓  @$savedOwner${if (savedRepo.isNotEmpty()) " / $savedRepo" else ""} (last build)"; tvOwnerInfo.visibility = android.view.View.VISIBLE

            setStatus("Ready ✓")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLog("✓ Previous build restored!")
            appendLog("  Artifact : $savedName")
            if (savedRepo.isNotEmpty())  appendLog("  Repo     : $savedRepo")
            if (savedRunId != -1L)       appendLog("  Run #    : $savedRunId")
            appendLog("  ▸ Tap  📲 Download & Install APK  to save to your phone.")
            appendLog("  ▸ Tap  🚀 Upload & Build  to start a new build.")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        } else {
            setStatus("Idle")
        }
    }

    // ── Entry point ──────────────────────────────────────────────────────────
    private fun startFlow() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val uri    = selectedZipUri

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub Personal Access Token."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name."); return }
        if (uri == null)     { appendLog("⚠ Pick a ZIP file first."); return }

        prefs.edit()
            .putString("token",  token)
            .putString("repo",   repo)
            .putString("branch", branch)
            .apply()

        // Clear old build state so stale URL doesn't linger
        clearBuildState()

        setBusy(true)
        tvLog.text = ""
        artifactDownloadUrl      = null
        btnDownloadApk?.isEnabled = false
        lastOwner      = ""
        lastRemotePath = ""
        lastFileSha    = null
        lastRunId      = -1L
        mainHandler.post {
            tvOwnerInfo.text = ""; tvOwnerInfo.visibility = android.view.View.GONE

        }

        thread { runFlow(token, repo, branch, uri) }
    }

    // ── Main flow ────────────────────────────────────────────────────────────
    private fun runFlow(token: String, repo: String, branch: String, uri: Uri) {
        try {
            setStatus("Verifying token…")
            appendLog("Verifying GitHub token…")
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network. Make sure your PAT has 'repo' scope.")
            appendLog("✓  Signed in as @$owner")
            lastOwner = owner
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner / $repo"; tvOwnerInfo.visibility = android.view.View.VISIBLE }

            setStatus("Checking repo…")
            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            setStatus("Setting up workflow…")
            ensureWorkflow(token, owner, repo, branch)

            setStatus("Reading ZIP…")
            appendLog("Reading ZIP…")
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("Size: ${bytes.size / 1024} KB  →  encoded: ${b64.length / 1024} KB")
            if (b64.length > 95 * 1024 * 1024) {
                throw Exception("ZIP too large for GitHub Contents API (> ~70 MB raw).")
            }

            setStatus("Uploading…")
            appendLog("Uploading to github.com/$owner/$repo …")
            val remotePath  = "uploads/$selectedZipName"
            val existingSha = fetchFileSha(token, owner, repo, remotePath)
            val uploadJson  = JSONObject().apply {
                put("message", "ci: upload $selectedZipName [run ${System.currentTimeMillis()}]")
                put("content", b64)
                put("branch",  branch)
                if (existingSha != null) {
                    put("sha", existingSha)
                    appendLog("Replacing existing file (SHA: ${existingSha.take(8)}…)")
                }
            }.toString()

            // ── Upload progress dialog ────────────────────────────────────
            uploadCancelled = false
            val uploadDialog = showUploadProgressDialog(selectedZipName, uploadJson.length.toLong())

            val (upCode, upBody) = try {
                httpPutWithProgress(token, apiContents(owner, repo, remotePath), uploadJson) { written, total ->
                    if (uploadCancelled) throw Exception("Cancelled by user")
                    mainHandler.post { uploadDialog.onProgress(written, total) }
                }
            } finally {
                mainHandler.post { uploadDialog.dialog.dismiss() }
            }
            if (uploadCancelled) throw Exception("Upload cancelled by user")
            if (upCode !in 200..201) throw Exception("Upload failed ($upCode): ${upBody.take(400)}")
            lastRemotePath = remotePath
            lastFileSha = try {
                JSONObject(upBody).optJSONObject("content")?.optString("sha")
            } catch (_: Exception) { null }
            appendLog("Upload OK — GitHub Actions will start shortly…")

            setStatus("Waiting for build…")
            appendLog("Waiting for GitHub Actions to pick up the commit…")
            val afterMs = System.currentTimeMillis()
            Thread.sleep(6_000)

            val runId = waitForRun(token, owner, repo, branch, afterMs)
                ?: throw Exception("No workflow run appeared within 3 minutes. " +
                    "Check that build.yml is on the $branch branch.")
            lastRunId = runId
            appendLog("Run #$runId started — streaming live build log…")
            appendLog("─────────────────────────────────────")

            setStatus("Building…")
            val success = streamBuildLog(token, owner, repo, runId)
            if (!success) throw Exception("Build failed. Tap '🔍 Build Log' for the full output.")

            setStatus("Fetching APK…")
            appendLog("Build succeeded! Looking for APK artifact…")
            val (artName, artUrl) = fetchArtifact(token, owner, repo, runId)
                ?: throw Exception("Run succeeded but no artifact found.")

            artifactDownloadUrl = artUrl
            appendLog("Artifact ready: $artName")
            setStatus("Ready ✓")

            // ─── Persist so Download button works after any app restart ──────
            saveBuildState(artUrl, artName, runId, owner, repo)

            mainHandler.post { btnDownloadApk?.isEnabled = true }

        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setStatus("Failed")
        } finally {
            setBusy(false)
        }
    }

    // ── Auto-setup helpers ────────────────────────────────────────────────────

    private fun fetchOwner(token: String): String? = try {
        val (code, body) = httpGet(token, "https://api.github.com/user")
        if (code == 200) JSONObject(body).optString("login").takeIf { it.isNotEmpty() }
        else null
    } catch (_: Exception) { null }

    private fun ensureRepo(token: String, owner: String, repo: String) {
        val (code, _) = httpGet(token, "https://api.github.com/repos/$owner/$repo")
        if (code == 200) { appendLog("Repo already exists ✓"); return }
        appendLog("Repo not found — creating github.com/$owner/$repo …")
        val body = JSONObject().apply {
            put("name",        repo)
            put("private",     false)
            put("auto_init",   true)
            put("description", "APK build repo — managed by ZipApkBuilder")
        }.toString()
        val (createCode, createBody) = httpPost(token, "https://api.github.com/user/repos", body)
        if (createCode !in 200..201) throw Exception("Could not create repo ($createCode): ${createBody.take(300)}")
        appendLog("Repo created ✓ — waiting for GitHub to initialise it…")
        Thread.sleep(4_000)
    }

    private fun ensureWorkflow(token: String, owner: String, repo: String, branch: String) {
        val path = ".github/workflows/build.yml"
        val existingSha = fetchFileSha(token, owner, repo, path)
        if (existingSha != null) { appendLog("Workflow already present ✓"); return }
        appendLog("Committing build workflow to repo…")
        val encoded = Base64.encodeToString(WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val payload = JSONObject().apply {
            put("message", "ci: add GitHub Actions build workflow")
            put("content", encoded)
            put("branch",  branch)
        }.toString()
        val (code, body) = httpPut(token, apiContents(owner, repo, path), payload)
        if (code !in 200..201) throw Exception("Could not commit workflow ($code): ${body.take(300)}")
        appendLog("Workflow committed ✓")
        Thread.sleep(2_000)
    }

    // ── GitHub API helpers ────────────────────────────────────────────────────

    private fun fetchFileSha(token: String, owner: String, repo: String, path: String): String? =
        try {
            val (code, body) = httpGet(token, apiContents(owner, repo, path))
            if (code == 200) JSONObject(body).optString("sha").takeIf { it.isNotEmpty() }
            else null
        } catch (_: Exception) { null }

    private fun waitForRun(token: String, owner: String, repo: String, branch: String, afterMs: Long): Long? {
        val deadline = System.currentTimeMillis() + 3 * 60_000L
        while (System.currentTimeMillis() < deadline) {
            try {
                val url = "${apiRuns(owner, repo)}?branch=$branch&per_page=10&event=push"
                val (code, body) = httpGet(token, url)
                if (code == 200) {
                    val runs = JSONObject(body).getJSONArray("workflow_runs")
                    for (i in 0 until runs.length()) {
                        val run    = runs.getJSONObject(i)
                        val runMs  = parseIso8601(run.getString("created_at"))
                        val status = run.optString("status", "")
                        val conc   = run.optString("conclusion", "")
                        // Skip any run that was already completed before the upload,
                        // even if its creation time happens to fall inside the grace window.
                        val alreadyDone = status == "completed" && conc.isNotEmpty()
                        if (runMs >= afterMs - 15_000 && !alreadyDone) return run.getLong("id")
                    }
                }
            } catch (_: Exception) {}
            Thread.sleep(10_000)
        }
        return null
    }

    private fun streamBuildLog(token: String, owner: String, repo: String, runId: Long): Boolean {
        val deadline    = System.currentTimeMillis() + 45 * 60_000L
        val stepStarted  = mutableSetOf<Int>()
        val stepFinished = mutableSetOf<Int>()
        val tsRegex      = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
        val ansiRegex    = Regex("""\x1B\[[0-9;]*[A-Za-z]""")
        var conclusion   = ""

        while (System.currentTimeMillis() < deadline) {
            try {
                val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
                if (jCode == 200) {
                    val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                    if (jobsArr != null && jobsArr.length() > 0) {
                        val steps = jobsArr.getJSONObject(0).optJSONArray("steps")
                        if (steps != null) {
                            for (i in 0 until steps.length()) {
                                val step     = steps.getJSONObject(i)
                                val num      = step.getInt("number")
                                val name     = step.getString("name")
                                val status   = step.optString("status", "")
                                val stepConc = step.optString("conclusion", "")
                                if (status == "in_progress" && stepStarted.add(num)) appendLog("▶ $name")
                                if (status == "completed" && stepFinished.add(num)) {
                                    if (!stepStarted.contains(num)) appendLog("▶ $name")
                                    val icon = if (stepConc == "success") "✓" else "✗"
                                    val started   = step.optString("started_at", "")
                                    val completed = step.optString("completed_at", "")
                                    val dur = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                        try {
                                            val e = parseIso8601(completed); val s = parseIso8601(started)
                                            if (e > s) "  ${(e - s) / 1000}s" else ""
                                        } catch (_: Exception) { "" }
                                    } else ""
                                    appendLog("  $icon $name$dur")
                                }
                            }
                        }
                    }
                }
                val (sCode, sBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId")
                if (sCode == 200) {
                    val obj = JSONObject(sBody)
                    conclusion = obj.optString("conclusion", "")
                    // Only break once the API has also filled in the conclusion.
                    // A "completed" status with no conclusion is a transient GitHub cache state.
                    if (obj.optString("status") == "completed" && conclusion.isNotEmpty()) break
                }
            } catch (_: Exception) {}
            Thread.sleep(5_000)
        }

        // Fetch and append full log text
        try {
            val (jCode, jBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
            if (jCode == 200) {
                val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                if (jobsArr != null && jobsArr.length() > 0) {
                    val jobId  = jobsArr.getJSONObject(0).getLong("id")
                    val logUrl = "https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs"
                    val conn1  = (URL(logUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        setRequestProperty("Authorization", "token $token")
                        setRequestProperty("Accept", "application/vnd.github.v3+json")
                        instanceFollowRedirects = false
                        connectTimeout = 20_000; readTimeout = 60_000
                    }
                    val rawLog: String? = when (val c = conn1.responseCode) {
                        in 301..308 -> {
                            val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                            try {
                                val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                                    requestMethod = "GET"; connectTimeout = 20_000; readTimeout = 60_000
                                }
                                if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText().also { c2.disconnect() }
                                else { c2.disconnect(); null }
                            } catch (_: Exception) { null }
                        }
                        200  -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                        else -> { conn1.disconnect(); null }
                    }
                    if (rawLog != null) {
                        appendLog("─────────────────────────────────────")
                        val groupRx = Regex("""^##\[(?:group|endgroup)\]""")
                        for (raw in rawLog.lines()) {
                            val line = ansiRegex.replace(tsRegex.replace(raw, ""), "")
                            if (!groupRx.containsMatchIn(line) && line.isNotBlank()) appendLog(line)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        appendLog("─────────────────────────────────────")
        appendLog(if (conclusion == "success") "✓ Build completed successfully" else "✗ Build $conclusion")
        return conclusion == "success"
    }

    private fun fetchArtifact(token: String, owner: String, repo: String, runId: Long): Pair<String, String>? {
        val (code, body) = httpGet(token, "${apiRuns(owner, repo)}/$runId/artifacts")
        if (code != 200) return null
        val artifacts = JSONObject(body).getJSONArray("artifacts")
        if (artifacts.length() == 0) return null
        val art = artifacts.getJSONObject(0)
        return art.getString("name") to art.getString("archive_download_url")
    }

    // ── Download Build Logs ZIP ───────────────────────────────────────────────

    private fun downloadLatestRunLogs() {
        val token  = etToken.text.toString().trim()
        val repo   = etRepo.text.toString().trim()
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        setStatus("Fetching latest run…")
        appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        appendLog("📥 Downloading build logs ZIP…")

        thread {
            try {
                // Resolve owner
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: run {
                        appendLog("✗ Could not verify token.")
                        setStatus("Failed"); setBusy(false); return@thread
                    }).also { lastOwner = it }
                }

                // 1. Get the latest run on this branch
                val runsUrl = "${apiRuns(owner, repo)}?branch=$branch&per_page=1"
                val (code, body) = httpGet(token, runsUrl)
                if (code != 200) {
                    appendLog("✗ Could not fetch runs (HTTP $code)")
                    setStatus("Failed"); setBusy(false); return@thread
                }
                val runs = JSONObject(body).getJSONArray("workflow_runs")
                if (runs.length() == 0) {
                    appendLog("⚠ No runs found on branch '${"$"}branch'")
                    setStatus("No runs"); setBusy(false); return@thread
                }
                val run        = runs.getJSONObject(0)
                val runId      = run.getLong("id")
                val runNum         = run.getInt("run_number")
                val status         = run.optString("status", "")
                val conclusion     = run.optString("conclusion", "")
                val conclusionStr  = conclusion.ifEmpty { "in_progress" }
                appendLog("  Run #${"$"}runNum  status=${"$"}status  conclusion=${"$"}conclusionStr")

                // 2. Resolve redirect to real ZIP URL
                val logsUrl = "https://api.github.com/repos/${"$"}owner/${"$"}repo/actions/runs/${"$"}runId/logs"
                val conn0 = (URL(logsUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token ${"$"}token")
                    setRequestProperty("Accept", "application/vnd.github+json")
                    instanceFollowRedirects = false
                    connectTimeout = 20_000; readTimeout = 60_000
                }
                conn0.connect()
                val respCode = conn0.responseCode
                val realUrl = when {
                    respCode in 301..308 -> { val loc = conn0.getHeaderField("Location"); conn0.disconnect(); loc }
                    respCode == 200      -> { logsUrl.also { conn0.disconnect() } }
                    else -> {
                        conn0.disconnect()
                        appendLog(if (status == "completed")
                            "✗ Logs unavailable for run #${"$"}runNum (HTTP ${"$"}respCode) — GitHub deletes logs after 90 days"
                        else
                            "✗ Logs not ready yet (HTTP ${"$"}respCode) — run is still in progress, try again shortly")
                        setStatus("Logs unavailable"); setBusy(false); return@thread
                    }
                }

                // 3. Download with progress dialog
                val baseName = if (selectedZipName.isNotEmpty())
                    selectedZipName.removeSuffix(".zip").removeSuffix(".ZIP") else "logs"
                val fileName = "${"$"}{baseName}_build_log.zip"

                downloadCancelled = false
                downloadPaused    = false

                // Show dialog on main thread
                val dlHolder = arrayOfNulls<DownloadDialogHolder>(1)
                val latch = java.util.concurrent.CountDownLatch(1)
                mainHandler.post {
                    dlHolder[0] = buildDownloadProgressDialog("📋  Downloading Build Log", fileName)
                    latch.countDown()
                }
                latch.await()
                val dlUi = dlHolder[0]!!

                val dlConn = (URL(realUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 30_000; readTimeout = 120_000
                }
                dlConn.connect()
                val total = dlConn.contentLengthLong

                fun fmtBytes(b: Long) = when {
                    b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
                    b >= 1_024     -> "${"$"}{b / 1024} KB"
                    else           -> "${"$"}b B"
                }
                val totalStr = if (total > 0) fmtBytes(total) else "size unknown"
                mainHandler.post { dlUi.tvSize.text = "0 B / ${"$"}totalStr" }
                appendLog("  Size: ${"$"}totalStr")

                val tmpFile = File(cacheDir, "logs_tmp_${"$"}{runId}.zip")
                val buf = ByteArray(32 * 1024)
                var downloaded = 0L
                var speedStartTime  = System.currentTimeMillis()
                var speedStartBytes = 0L

                dlConn.inputStream.use { inp ->
                    FileOutputStream(tmpFile).use { out ->
                        while (true) {
                            if (downloadCancelled) throw Exception("Cancelled by user")
                            while (downloadPaused) {
                                if (downloadCancelled) throw Exception("Cancelled by user")
                                Thread.sleep(150)
                            }
                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            downloaded += n

                            val now     = System.currentTimeMillis()
                            val elapsed = now - speedStartTime
                            if (elapsed >= 200) {
                                val speedBps = (downloaded - speedStartBytes) * 1000L / elapsed.coerceAtLeast(1)
                                speedStartTime  = now; speedStartBytes = downloaded
                                val pct = if (total > 0) (downloaded * 1000L / total).toInt() else 0
                                val dlStr  = fmtBytes(downloaded)
                                val spdStr = "${fmtBytes(speedBps)}/s"
                                val pctStr = if (total > 0) "${"%.1f".format(downloaded * 100.0 / total)}%" else "…"
                                mainHandler.post {
                                    dlUi.progressBar.progress = pct
                                    dlUi.tvPercent.text = pctStr
                                    dlUi.tvSize.text    = "$dlStr / $totalStr"
                                    if (!downloadPaused) dlUi.tvSpeed.text = spdStr
                                }
                            }
                        }
                    }
                }
                dlConn.disconnect()
                if (downloadCancelled) throw Exception("Cancelled by user")

                mainHandler.post {
                    dlUi.progressBar.progress = 1000
                    dlUi.tvPercent.text = "100%"
                    dlUi.tvSize.text    = "${"$"}{fmtBytes(downloaded)} / ${"$"}totalStr"
                    dlUi.tvSpeed.text   = "Saving…"
                    dlUi.btnPauseResume.isEnabled = false
                    dlUi.btnCancel.isEnabled      = false
                }
                appendLog("  Downloaded: ${"$"}{fmtBytes(downloaded)}")

                // 4. Save to Downloads
                setStatus("Saving…")
                val savedPath = saveZipToDownloads(tmpFile, fileName)
                tmpFile.delete()

                mainHandler.post { dlUi.dialog.dismiss() }
                appendLog("✓ Saved to Downloads!")
                appendLog("  File : ${"$"}fileName")
                appendLog("  Path : ${"$"}savedPath")
                appendLog("  Size : ${"$"}{fmtBytes(downloaded)}")
                setStatus("Logs saved ✓")

            } catch (e: Exception) {
                if (e.message == "Cancelled by user") {
                    appendLog("⚠ Log download cancelled.")
                    setStatus("Cancelled")
                } else {
                    appendLog("✗ Error: ${"$"}{e.message}")
                    setStatus("Failed")
                }
            } finally {
                setBusy(false)
            }
        }
    }

    // ── Download & Install ────────────────────────────────────────────────────

    /** Volatile flags shared between the download thread and the progress dialog. */
    @Volatile private var downloadPaused    = false
    @Volatile private var downloadCancelled = false
    @Volatile private var uploadCancelled   = false

    private fun downloadArtifact(downloadUrl: String) {
        if (isBusy) return
        setBusy(true)
        setStatus("Downloading…")
        appendLog("Downloading artifact ZIP from GitHub…")
        val token = etToken.text.toString().trim()

        val rawName = prefs.getString(PREF_ARTIFACT_NAME, "artifact") ?: "artifact"
        val zipFileName = if (rawName.endsWith(".zip", ignoreCase = true)) rawName else "$rawName.zip"

        // ── Build progress dialog ──────────────────────────────────────────
        val dp = resources.displayMetrics.density

        val dialogRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (20*dp).toInt(), (20*dp).toInt(), (12*dp).toInt())
            setBackgroundColor(0xFF13162A.toInt())
        }

        val tvDlFileName = TextView(this).apply {
            text = zipFileName
            textSize = 13f
            setTextColor(0xFFE8EAED.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val tvDlSize = TextView(this).apply {
            text = "Connecting…"
            textSize = 11f
            setTextColor(0xFF9AA0B8.toInt())
            setPadding(0, (4*dp).toInt(), 0, (10*dp).toInt())
        }

        val progressBarDl = android.widget.ProgressBar(this, null,
            android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
            progressDrawable = android.graphics.drawable.LayerDrawable(
                arrayOf(
                    android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt()),
                    android.graphics.drawable.ClipDrawable(
                        android.graphics.drawable.ColorDrawable(0xFF2ECC71.toInt()),
                        android.view.Gravity.START,
                        android.graphics.drawable.ClipDrawable.HORIZONTAL
                    )
                )
            ).also { ld ->
                ld.setId(0, android.R.id.background)
                ld.setId(1, android.R.id.progress)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (8*dp).toInt()
            ).also { it.bottomMargin = (4*dp).toInt() }
        }

        val tvDlPercent = TextView(this).apply {
            text = "0%"
            textSize = 11f
            setTextColor(0xFF2ECC71.toInt())
            gravity = android.view.Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tvDlSpeed = TextView(this).apply {
            text = ""
            textSize = 10.5f
            setTextColor(0xFF50587A.toInt())
            setPadding(0, (6*dp).toInt(), 0, (2*dp).toInt())
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.END
            setPadding(0, (14*dp).toInt(), 0, 0)
        }

        val btnPauseResume = Button(this).apply {
            text = "⏸ Pause"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1E5799.toInt())
            setPadding((16*dp).toInt(), (6*dp).toInt(), (16*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (8*dp).toInt() }
        }

        val btnCancelDl = Button(this).apply {
            text = "✕ Cancel"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF6B2020.toInt())
            setPadding((16*dp).toInt(), (6*dp).toInt(), (16*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        btnRow.addView(btnPauseResume)
        btnRow.addView(btnCancelDl)

        dialogRoot.addView(tvDlFileName)
        dialogRoot.addView(tvDlSize)
        dialogRoot.addView(progressBarDl)
        dialogRoot.addView(tvDlPercent)
        dialogRoot.addView(tvDlSpeed)
        dialogRoot.addView(btnRow)

        val progressDialog = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setCustomTitle(TextView(this).apply {
                text = "📥  Downloading Artifact"
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFFE8EAED.toInt())
                setPadding((20*dp).toInt(), (18*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
                setBackgroundColor(0xFF1C2038.toInt())
            })
            .setView(dialogRoot)
            .setCancelable(false)
            .create()

        downloadPaused    = false
        downloadCancelled = false

        btnPauseResume.setOnClickListener {
            downloadPaused = !downloadPaused
            btnPauseResume.text = if (downloadPaused) "▶ Resume" else "⏸ Pause"
            btnPauseResume.setBackgroundColor(
                if (downloadPaused) 0xFF2A6B2A.toInt() else 0xFF1E5799.toInt()
            )
            tvDlSpeed.text = if (downloadPaused) "Paused" else ""
        }

        btnCancelDl.setOnClickListener {
            downloadCancelled = true
            progressDialog.dismiss()
        }

        progressDialog.show()

        // ── Download thread ────────────────────────────────────────────────
        thread {
            try {
                // 1. Resolve GitHub's redirect to the actual download URL
                val conn0 = URL(downloadUrl).openConnection() as HttpURLConnection
                conn0.setRequestProperty("Authorization", "token $token")
                conn0.setRequestProperty("Accept", "application/vnd.github.v3+json")
                conn0.instanceFollowRedirects = false
                conn0.connectTimeout = 30_000
                conn0.readTimeout    = 30_000
                conn0.connect()
                val realUrl = if (conn0.responseCode in 301..308) {
                    val loc = conn0.getHeaderField("Location")
                    conn0.disconnect(); loc
                } else { conn0.disconnect(); downloadUrl }

                if (downloadCancelled) throw Exception("Cancelled by user")

                // 2. Open connection and get content length
                val dlConn = URL(realUrl).openConnection() as HttpURLConnection
                dlConn.connectTimeout = 60_000
                dlConn.readTimeout   = 300_000
                dlConn.connect()
                val total = dlConn.contentLengthLong

                fun fmtBytes(b: Long) = when {
                    b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
                    b >= 1_024     -> "${b / 1024} KB"
                    else           -> "$b B"
                }

                val totalStr = if (total > 0) fmtBytes(total) else "size unknown"
                mainHandler.post {
                    tvDlSize.text = "0 B / $totalStr"
                    appendLog("Downloading… ($totalStr)")
                }

                // 3. Chunked download loop with pause/cancel support
                val artifactZip = File(cacheDir, "artifact_${System.currentTimeMillis()}.zip")
                val buf = ByteArray(32 * 1024)
                var downloaded = 0L
                var speedStartTime = System.currentTimeMillis()
                var speedStartBytes = 0L

                dlConn.inputStream.use { inp ->
                    FileOutputStream(artifactZip).use { out ->
                        while (true) {
                            if (downloadCancelled) throw Exception("Cancelled by user")

                            // Pause: spin-wait in small sleeps
                            while (downloadPaused) {
                                if (downloadCancelled) throw Exception("Cancelled by user")
                                Thread.sleep(150)
                            }

                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            downloaded += n

                            val now = System.currentTimeMillis()
                            val elapsed = now - speedStartTime
                            val pct = if (total > 0) (downloaded * 1000L / total).toInt() else 0

                            // Update UI every ~200 ms
                            if (elapsed >= 200) {
                                val bytesSinceLastUpdate = downloaded - speedStartBytes
                                val speedBps = bytesSinceLastUpdate * 1000L / elapsed.coerceAtLeast(1)
                                speedStartTime  = now
                                speedStartBytes = downloaded

                                val dlStr  = fmtBytes(downloaded)
                                val spdStr = "${fmtBytes(speedBps)}/s"
                                val pctStr = if (total > 0) "${"%.1f".format(downloaded * 100.0 / total)}%" else "…"

                                mainHandler.post {
                                    progressBarDl.progress = pct
                                    tvDlPercent.text = pctStr
                                    tvDlSize.text    = "$dlStr / $totalStr"
                                    if (!downloadPaused) tvDlSpeed.text = spdStr
                                }
                            }
                        }
                    }
                }
                dlConn.disconnect()

                if (downloadCancelled) throw Exception("Cancelled by user")

                // Final UI update
                mainHandler.post {
                    progressBarDl.progress = 1000
                    tvDlPercent.text = "100%"
                    tvDlSize.text    = "${fmtBytes(downloaded)} / $totalStr"
                    tvDlSpeed.text   = "Saving to Downloads…"
                    btnPauseResume.isEnabled = false
                    btnCancelDl.isEnabled    = false
                }

                appendLog("Downloaded: ${fmtBytes(downloaded)}")

                // 4. Save the ZIP directly to Downloads
                setStatus("Saving…")
                val savedPath = saveZipToDownloads(artifactZip, zipFileName)

                mainHandler.post { progressDialog.dismiss() }

                appendLog("✓ Saved to Downloads!")
                appendLog("  File : $zipFileName")
                appendLog("  Path : $savedPath")
                appendLog("  Size : ${fmtBytes(downloaded)}")
                appendLog("  Open your Downloads app to find it anytime.")
                setStatus("Ready ✓")
                mainHandler.post { btnDownloadApk?.isEnabled = true }

            } catch (e: Exception) {
                mainHandler.post { progressDialog.dismiss() }
                if (e.message == "Cancelled by user") {
                    appendLog("⚠ Download cancelled.")
                    setStatus("Cancelled")
                } else {
                    appendLog("✗ Download error: ${e.message}")
                    setStatus("Download failed")
                }
                mainHandler.post { btnDownloadApk?.isEnabled = true }
            } finally {
                setBusy(false)
            }
        }
    }

    /**
     * Saves [zipFile] to the public Downloads directory as [fileName] (a .zip).
     *
     * Android 10+ (API 29+): MediaStore API — no storage permission required.
     * Android 7–9  (API 24–28): direct file write (needs WRITE_EXTERNAL_STORAGE).
     *
     * Returns the absolute path of the saved file.
     */
    // ── Download History ──────────────────────────────────────────────────────

    private fun addDownloadToHistory(name: String, path: String, sizeBytes: Long) {
        val arr = try {
            JSONArray(prefs.getString(PREF_DOWNLOAD_HISTORY, "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }

        val entry = JSONObject().apply {
            put("name", name)
            put("path", path)
            put("size", sizeBytes)
            put("time", System.currentTimeMillis())
        }
        // Prepend newest first, cap at 30
        val newArr = JSONArray()
        newArr.put(entry)
        for (i in 0 until minOf(arr.length(), 29)) newArr.put(arr.getJSONObject(i))
        prefs.edit().putString(PREF_DOWNLOAD_HISTORY, newArr.toString()).apply()
    }

    private fun loadDownloadHistory(): List<JSONObject> {
        val arr = try {
            JSONArray(prefs.getString(PREF_DOWNLOAD_HISTORY, "[]") ?: "[]")
        } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    private fun saveZipToDownloads(zipFile: File, fileName: String): String {
        val savedPath = saveZipToDownloadsInternal(zipFile, fileName)
        addDownloadToHistory(fileName, savedPath, zipFile.length())
        return savedPath
    }

    private fun saveZipToDownloadsInternal(zipFile: File, fileName: String): String {
        // Use custom folder if the user picked one
        val customUriStr = prefs.getString(PREF_DOWNLOAD_URI, null)
        if (!customUriStr.isNullOrEmpty()) {
            val treeUri = Uri.parse(customUriStr)
            val docUri  = androidx.documentfile.provider.DocumentFile
                .fromTreeUri(this, treeUri)
                ?.createFile("application/zip", fileName)
                ?.uri
                ?: throw Exception("Cannot create file in selected folder")
            contentResolver.openOutputStream(docUri)!!.use { out ->
                zipFile.inputStream().use { it.copyTo(out) }
            }
            return docUri.toString()
        }

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ — MediaStore.Downloads (no permission needed)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val collection = MediaStore.Downloads
                .getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = contentResolver.insert(collection, values)
                ?: throw Exception("MediaStore insert failed.")

            contentResolver.openOutputStream(itemUri)!!.use { out: OutputStream ->
                zipFile.inputStream().use { it.copyTo(out) }
            }

            // Clear IS_PENDING so it appears in Downloads app right away
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(itemUri, values, null, null)

            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                .absolutePath + "/$fileName"

        } else {
            // Android 7–9 — direct file write (needs WRITE_EXTERNAL_STORAGE)
            val dir  = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()
            val dest = File(dir, fileName)
            zipFile.copyTo(dest, overwrite = true)
            dest.absolutePath
        }
    }


    // ── Keystore Generation ────────────────────────────────────────────────────

    private fun generateKeystore() {
        val token    = etToken.text.toString().trim()
        val repo     = etRepo.text.toString().trim()
        val pass     = etKeystorePass.text.toString().trim()
        val rawAlias = etKeyAlias.text.toString().trim()

        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }
        if (pass.length < 6) { appendLog("⚠ Keystore password must be at least 6 characters."); return }

        val ts    = SimpleDateFormat("yyyyMMddHHmm", Locale.US).format(java.util.Date())
        val alias = rawAlias.ifEmpty { "key-$ts" }

        // Check GitHub for an existing keystore before showing the dialog
        setBusy(true)
        appendLog("Checking for existing keystore on GitHub…")
        thread {
            val existingFile: String? = try {
                val owner = fetchOwner(token)
                if (owner == null) {
                    mainHandler.post { setBusy(false); appendLog("⚠ Token invalid or no network.") }
                    return@thread
                }
                lastOwner = owner
                mainHandler.post { tvOwnerInfo.text = "✓  @$owner / $repo"; tvOwnerInfo.visibility = android.view.View.VISIBLE }
                checkExistingKeystore(token, owner, repo)
            } catch (_: Exception) {
                null // on any error fall through to normal generation dialog
            }

            mainHandler.post {
                setBusy(false)
                if (existingFile != null) {
                    // ── Keystore already on GitHub ──────────────────────────────
                    AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                        .setTitle("🔑 Keystore Already Configured")
                        .setMessage(
                            "A keystore is already saved on GitHub:\n\n" +
                            "  File : $existingFile\n\n" +
                            "Builds will automatically use it.\n\n" +
                            "Tap \"Use Existing\" to keep it, or\n" +
                            "\"Generate New\" to overwrite."
                        )
                        .setPositiveButton("Use Existing") { _, _ ->
                            prefs.edit()
                                .putBoolean(PREF_KEYSTORE_SAVED, true)
                                .putString(PREF_KEYSTORE_ALIAS, alias)
                                .apply()
                            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            appendLog("✓ Using existing keystore on GitHub")
                            appendLog("  File : $existingFile")
                            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            tvKeystoreStatus.text = "✓ Keystore ready  •  $existingFile"
                            tvKeystoreStatus.visibility = android.view.View.VISIBLE
                        }
                        .setNegativeButton("Generate New") { _, _ ->
                            setBusy(true)
                            tvKeystoreStatus.visibility = android.view.View.GONE
                            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            appendLog("🔑 Keystore generation starting…")
                            appendLog("  Alias : $alias")
                            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            thread { runKeystoreGeneration(token, repo, alias, pass) }
                        }
                        .setNeutralButton("Cancel", null)
                        .show()
                } else {
                    // ── No existing keystore — original generation dialog ────────
                    AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                        .setTitle("🔑 Generate Keystore")
                        .setMessage(
                            "This will:\n\n" +
                            "• Run the keystore generation workflow\n" +
                            "• Save keystore as GitHub Secrets:\n" +
                            "  KEYSTORE_BASE64, STORE_PASSWORD,\n" +
                            "  KEY_PASSWORD, KEY_ALIAS, KEYSTORE_FILE\n" +
                            "• Save KEYSTORE_FILENAME as a variable\n\n" +
                            "Alias: $alias\n\n" +
                            "Each run creates a uniquely-named keystore.\n" +
                            "Continue?"
                        )
                        .setPositiveButton("Generate") { _, _ ->
                            setBusy(true)
                            tvKeystoreStatus.visibility = android.view.View.GONE
                            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            appendLog("🔑 Keystore generation starting…")
                            appendLog("  Alias : $alias")
                            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                            thread { runKeystoreGeneration(token, repo, alias, pass) }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }
    }

    /**
     * Returns the KEYSTORE_FILENAME variable value if both the KEYSTORE_BASE64
     * secret and KEYSTORE_FILENAME variable already exist in the repo,
     * or null if either is missing.
     */
    private fun checkExistingKeystore(token: String, owner: String, repo: String): String? {
        // GitHub returns 200 if the secret exists (value is never revealed), 404 if not
        val (secretCode, _) = httpGet(
            token, "https://api.github.com/repos/$owner/$repo/actions/secrets/KEYSTORE_BASE64")
        if (secretCode != 200) return null

        // Variable endpoint returns the value directly
        val (varCode, varBody) = httpGet(
            token, "https://api.github.com/repos/$owner/$repo/actions/variables/KEYSTORE_FILENAME")
        if (varCode != 200) return null

        return try {
            JSONObject(varBody).getString("value").takeIf { it.isNotEmpty() }
        } catch (_: Exception) { null }
    }

    private fun runKeystoreGeneration(token: String, repo: String, alias: String, pass: String) {
        try {
            val owner = fetchOwner(token)
                ?: throw Exception("Token invalid or no network.")
            lastOwner = owner
            mainHandler.post { tvOwnerInfo.text = "✓  @$owner / $repo"; tvOwnerInfo.visibility = android.view.View.VISIBLE }

            appendLog("Checking github.com/$owner/$repo …")
            ensureRepo(token, owner, repo)

            // GitHub caches a workflow's trigger list at creation time — updating a file
            // in-place via API never re-registers triggers. Always delete then recreate.
            val wfPath = ".github/workflows/keystore.yml"
            val existingSha = fetchFileSha(token, owner, repo, wfPath)
            if (existingSha != null) {
                appendLog("Removing old keystore workflow…")
                val delPayload = JSONObject().apply {
                    put("message", "ci: remove old keystore workflow")
                    put("sha", existingSha)
                    put("branch", "main")
                }.toString()
                val (delCode, delBody) = httpDelete(token, apiContents(owner, repo, wfPath), delPayload)
                if (delCode !in 200..204) throw Exception("Could not delete old workflow ($delCode): ${delBody.take(300)}")
                Thread.sleep(3_000)
            }
            appendLog("Committing keystore workflow…")
            val wfEncoded = Base64.encodeToString(
                KEYSTORE_WORKFLOW_YAML.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val wfPayload = JSONObject().apply {
                put("message", "ci: add keystore workflow")
                put("content", wfEncoded)
                put("branch",  "main")
                // No "sha" — fresh create forces GitHub to re-register all triggers
            }.toString()
            val (wfCode, wfBody) = httpPut(token, apiContents(owner, repo, wfPath), wfPayload)
            if (wfCode !in 200..201) throw Exception("Could not commit workflow ($wfCode): ${wfBody.take(300)}")
            appendLog("Keystore workflow ready ✓")

            // Use dispatch itself as readiness probe — 422 means GitHub hasn't finished
            // indexing the new file yet; retry for up to 2 minutes.
            appendLog("Triggering keystore generation workflow…")
            val dispatchBody = JSONObject().apply {
                put("ref", "main")
                put("inputs", JSONObject().apply {
                    put("alias",         alias)
                    put("password",      pass)
                    put("validity_days", "10950")
                    put("pat_token",     token)
                })
            }.toString()
            val dispatchUrl = "https://api.github.com/repos/$owner/$repo/actions/workflows/keystore.yml/dispatches"
            val dispatchDeadline = System.currentTimeMillis() + 120_000L
            var dCode = 0; var dBody = ""; var attempt = 0
            while (System.currentTimeMillis() < dispatchDeadline) {
                attempt++
                val (c, b) = httpPost(token, dispatchUrl, dispatchBody)
                dCode = c; dBody = b
                if (c in 200..204) break
                appendLog("  Dispatch attempt $attempt: $c — retrying…")
                Thread.sleep(5_000)
            }
            if (dCode !in 200..204) throw Exception("Dispatch failed ($dCode): ${dBody.take(300)}")
            appendLog("Workflow dispatched ✓ — waiting for run…")

            Thread.sleep(6_000)

            // Wait for the run to appear
            val afterMs  = System.currentTimeMillis() - 15_000L
            val deadline = System.currentTimeMillis() + 3 * 60_000L
            var keystoreRunId = -1L
            while (System.currentTimeMillis() < deadline && keystoreRunId == -1L) {
                try {
                    val url = "https://api.github.com/repos/$owner/$repo/actions/workflows/keystore.yml/runs?per_page=5"
                    val (code, body) = httpGet(token, url)
                    if (code == 200) {
                        val runs = JSONObject(body).getJSONArray("workflow_runs")
                        for (i in 0 until runs.length()) {
                            val run = runs.getJSONObject(i)
                            if (parseIso8601(run.getString("created_at")) >= afterMs) {
                                keystoreRunId = run.getLong("id"); break
                            }
                        }
                    }
                } catch (_: Exception) {}
                if (keystoreRunId == -1L) Thread.sleep(8_000)
            }
            if (keystoreRunId == -1L) throw Exception("Keystore run did not appear within 3 minutes.")

            appendLog("Run #$keystoreRunId started — polling steps…")
            appendLog("─────────────────────────────────────")

            // Poll until complete, streaming step names
            val runDeadline  = System.currentTimeMillis() + 10 * 60_000L
            var conclusion   = ""
            val stepStarted  = mutableSetOf<Int>()
            val stepFinished = mutableSetOf<Int>()
            while (System.currentTimeMillis() < runDeadline) {
                try {
                    val (jCode, jBody) = httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/runs/$keystoreRunId/jobs")
                    if (jCode == 200) {
                        val jobsArr = JSONObject(jBody).optJSONArray("jobs")
                        if (jobsArr != null && jobsArr.length() > 0) {
                            val steps = jobsArr.getJSONObject(0).optJSONArray("steps")
                            if (steps != null) {
                                for (i in 0 until steps.length()) {
                                    val step     = steps.getJSONObject(i)
                                    val num      = step.getInt("number")
                                    val name     = step.getString("name")
                                    val status   = step.optString("status", "")
                                    val stepConc = step.optString("conclusion", "")
                                    if (status == "in_progress" && stepStarted.add(num)) appendLog("▶ $name")
                                    if (status == "completed" && stepFinished.add(num)) {
                                        if (!stepStarted.contains(num)) appendLog("▶ $name")
                                        val icon = if (stepConc == "success") "✓" else "✗"
                                        val started   = step.optString("started_at", "")
                                        val completed = step.optString("completed_at", "")
                                        val dur = if (started.isNotEmpty() && completed.isNotEmpty()) {
                                            try {
                                                val e = parseIso8601(completed); val s = parseIso8601(started)
                                                if (e > s) "  ${(e - s) / 1000}s" else ""
                                            } catch (_: Exception) { "" }
                                        } else ""
                                        appendLog("  $icon $name$dur")
                                    }
                                }
                            }
                        }
                    }
                    val (sCode, sBody) = httpGet(token, "https://api.github.com/repos/$owner/$repo/actions/runs/$keystoreRunId")
                    if (sCode == 200) {
                        val obj = JSONObject(sBody)
                        conclusion = obj.optString("conclusion", "")
                        if (obj.getString("status") == "completed") break
                    }
                } catch (_: Exception) {}
                Thread.sleep(6_000)
            }

            appendLog("─────────────────────────────────────")
            if (conclusion != "success") throw Exception("Keystore workflow $conclusion. Check run #$keystoreRunId on GitHub.")

            prefs.edit()
                .putBoolean(PREF_KEYSTORE_SAVED, true)
                .putString(PREF_KEYSTORE_ALIAS, alias)
                .apply()

            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            appendLog("✓ Keystore generated successfully!")
            appendLog("  Alias    : $alias")
            appendLog("  Secrets  : KEYSTORE_BASE64, STORE_PASSWORD,")
            appendLog("             KEY_PASSWORD, KEY_ALIAS, KEYSTORE_FILE")
            appendLog("  Variable : KEYSTORE_FILENAME")
            appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            mainHandler.post {
                tvKeystoreStatus.text = "✓ Keystore saved  •  alias: $alias"
                tvKeystoreStatus.visibility = android.view.View.VISIBLE
            }

        } catch (e: Exception) {
            appendLog("✗ Keystore error: ${e.message}")
        } finally {
            setBusy(false)
        }
    }

    // ── Browse All Artifacts (persists across reinstall — reads from GitHub) ─

    /**
     * Fetches every artifact for the repo from GitHub API — exactly what the
     * GitHub website shows on the Actions → Artifacts page.  Works even after
     * the app is uninstalled and reinstalled because the data lives on GitHub,
     * not in SharedPreferences.
     */
    private fun browseAllArtifacts() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Fetching all artifacts from GitHub…")

        thread {
            try {
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: throw Exception("Could not verify token.")).also { lastOwner = it }
                }

                // Collect up to 5 pages × 30 = 150 artifacts (same as GitHub website)
                val allArtifacts = mutableListOf<JSONObject>()
                var page = 1
                while (page <= 5) {
                    val url = "https://api.github.com/repos/$owner/$repo/actions/artifacts?per_page=30&page=$page"
                    val (code, body) = httpGet(token, url)
                    if (code != 200) break
                    val obj  = JSONObject(body)
                    val arr  = obj.getJSONArray("artifacts")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allArtifacts.add(arr.getJSONObject(i))
                    val totalCount = obj.optInt("total_count", 0)
                    if (allArtifacts.size >= totalCount) break
                    page++
                }

                mainHandler.post {
                    setBusy(false)
                    if (allArtifacts.isEmpty()) {
                        appendLog("No artifacts found in github.com/$owner/$repo")
                        appendLog("  Artifacts are kept for 30 days after each build.")
                        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                            .setTitle("📁 No Artifacts Found")
                            .setMessage(
                                "No artifacts were found in:\ngithub.com/$owner/$repo\n\n" +
                                "Possible reasons:\n" +
                                "• All artifacts have expired (30-day limit)\n" +
                                "• The repo name is wrong\n" +
                                "• No builds have been run yet\n\n" +
                                "Start a new build with 🚀 Upload & Build."
                            )
                            .setPositiveButton("OK", null)
                            .show()
                    } else {
                        appendLog("Found ${allArtifacts.size} artifact(s) ✓")
                        showArtifactBrowserDialog(token, owner, repo, allArtifacts)
                    }
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /**
     * Displays all artifacts — fixed text visibility, trigger workflow, switch repo.
     */
    private fun showArtifactBrowserDialog(
        token: String, owner: String, repo: String,
        artifacts: List<JSONObject>
    ) {
        val dp   = resources.displayMetrics.density
        val fmt  = SimpleDateFormat("MMM d, yyyy", Locale.US)
        val fmtIn= SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }

        // ── Custom title bar ──────────────────────────────────────────────
        val titleRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1C2038.toInt())
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16*dp).toInt(), (12*dp).toInt(), (8*dp).toInt(), (8*dp).toInt())
        }
        val titleTv = TextView(this).apply {
            text = "📦  $owner / $repo"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val artifactCountTv = TextView(this).apply {
            text = "${artifacts.size}"
            textSize = 10f
            setTextColor(0xFF9AA0B8.toInt())
        }
        topBar.addView(titleTv); topBar.addView(artifactCountTv)
        titleRoot.addView(topBar)

        // Action chips row: Switch Repo + Trigger Build
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), (4*dp).toInt(), (14*dp).toInt(), (10*dp).toInt())
        }
        fun chip(label: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 11f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(bg)
            setPadding((10*dp).toInt(), (5*dp).toInt(), (10*dp).toInt(), (5*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (8*dp).toInt() }
            setOnClickListener { onClick() }
        }

        var pendingArtDialog: AlertDialog? = null
        val switchChip = chip("🔀 Switch Repo", 0xFF2A2D4A.toInt()) {
            pendingArtDialog?.dismiss()
            showSavedReposDialog()
        }
        val triggerChip = chip("⚡ Trigger Build", 0xFF1A2E1A.toInt()) {
            pendingArtDialog?.dismiss()
            triggerWorkflowDispatch(token, owner, repo, branch)
        }
        chipRow.addView(switchChip); chipRow.addView(triggerChip)
        titleRoot.addView(chipRow)

        // Divider
        titleRoot.addView(android.view.View(this).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Custom adapter — explicit colors ──────────────────────────────
        var selectedIndex = -1

        val listView = android.widget.ListView(this).apply {
            setBackgroundColor(0xFF13162A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt())
            dividerHeight = 1
        }

        data class ArtInfo(val name: String, val sizeStr: String, val builtStr: String, val expiresStr: String, val expired: Boolean)
        val artInfos = artifacts.map { art ->
            val name      = art.getString("name")
            val sizeBytes = art.optLong("size_in_bytes", 0L)
            val sizeStr   = when {
                sizeBytes >= 1_048_576 -> "%.1f MB".format(sizeBytes / 1_048_576.0)
                sizeBytes >= 1_024     -> "${sizeBytes / 1024} KB"
                else                   -> "$sizeBytes B"
            }
            val expired     = art.optBoolean("expired", false)
            val expiresRaw  = art.optString("expires_at", "")
            val expiresStr  = if (expiresRaw.isNotEmpty()) {
                try { "expires " + fmt.format(fmtIn.parse(expiresRaw)!!) } catch (_: Exception) { "" }
            } else ""
            val createdRaw = art.optString("created_at", "")
            val builtStr   = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) } catch (_: Exception) { "" }
            } else ""
            ArtInfo(name, sizeStr, builtStr, expiresStr, expired)
        }

        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = artInfos.size
            override fun getItem(pos: Int) = artInfos[pos]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val info = artInfos[pos]
                val isSelected = (pos == selectedIndex)
                val row = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setBackgroundColor(if (isSelected) 0xFF221F4A.toInt() else 0xFF13162A.toInt())
                    setPadding((16*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                }
                // Status dot
                val dot = android.view.View(parent.context).apply {
                    setBackgroundColor(if (info.expired) 0xFFFF6B6B.toInt() else 0xFF2ECC71.toInt())
                    layoutParams = LinearLayout.LayoutParams((8*dp).toInt(), (8*dp).toInt()).also {
                        it.marginEnd = (12*dp).toInt()
                    }
                }
                val col = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val nameTv = TextView(parent.context).apply {
                    text = info.name
                    textSize = 13f
                    setTextColor(if (info.expired) 0xFF9AA0B8.toInt() else 0xFFE8EAED.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val metaTv = TextView(parent.context).apply {
                    text = buildString {
                        append(info.sizeStr)
                        if (info.builtStr.isNotEmpty()) append("  ·  built ${info.builtStr}")
                        if (info.expiresStr.isNotEmpty()) append("  ·  ${info.expiresStr}")
                        if (info.expired) append("  ⚠ EXPIRED")
                    }
                    textSize = 10.5f
                    setTextColor(if (info.expired) 0xFFFF6B6B.toInt() else 0xFF50587A.toInt())
                }
                col.addView(nameTv); col.addView(metaTv)
                row.addView(dot); row.addView(col)
                return row
            }
        }

        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            selectedIndex = pos
            adapter.notifyDataSetChanged()
        }

        // ── Full custom view ──────────────────────────────────────────────
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
        }

        val listContainer = android.widget.FrameLayout(this).apply {
            val maxH = (resources.displayMetrics.heightPixels * 0.55f).toInt()
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH)
            addView(listView)
        }
        root.addView(listContainer)

        val dlg = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(root)
            .setPositiveButton("📲 Download") { _, _ ->
                if (selectedIndex < 0) {
                    appendLog("⚠ Tap an artifact to select it first."); return@setPositiveButton
                }
                val art = artifacts[selectedIndex]
                if (art.optBoolean("expired", false)) {
                    appendLog("✗ That artifact has expired — it can no longer be downloaded.")
                    AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                        .setTitle("Artifact Expired")
                        .setMessage("This artifact has expired and can no longer be downloaded.\n\nRun a new build to generate a fresh one.")
                        .setPositiveButton("OK", null).show()
                    return@setPositiveButton
                }
                val artId  = art.getLong("id")
                val artName = art.getString("name")
                val dlUrl   = "https://api.github.com/repos/$owner/$repo/actions/artifacts/$artId/zip"
                prefs.edit().putString(PREF_ARTIFACT_NAME, artName).apply()
                artifactDownloadUrl = dlUrl
                appendLog("Downloading: $artName")
                withStoragePermission { downloadArtifact(dlUrl) }
            }
            .setNeutralButton("⚡ Trigger") { _, _ ->
                triggerWorkflowDispatch(token, owner, repo, branch)
            }
            .setNegativeButton("Close", null)
            .show()

        // Explicitly style buttons so they're visible on dark background
        dlg.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(0xFF2ECC71.toInt())  // green — Download
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL)?.setTextColor(0xFFFFA726.toInt())   // orange — Trigger
        dlg.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(0xFF9AA0B8.toInt())  // gray — Close

        pendingArtDialog = dlg
    }

    /** Dispatches a workflow_dispatch event for build.yml on the given branch. */
    private fun triggerWorkflowDispatch(token: String, owner: String, repo: String, branch: String) {
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (owner.isEmpty() || repo.isEmpty()) { appendLog("⚠ Repo not set."); return }

        // Ask which workflow to trigger
        val url = "https://api.github.com/repos/$owner/$repo/actions/workflows"
        setBusy(true)
        appendLog("Fetching workflows…")
        thread {
            try {
                val (code, body) = httpGet(token, url)
                if (code != 200) throw Exception("HTTP $code listing workflows")
                val arr = JSONObject(body).optJSONArray("workflows")
                    ?: throw Exception("No workflows found")
                data class WfEntry(val id: Long, val name: String, val path: String)
                val wfs = (0 until arr.length()).map { i ->
                    val obj = arr.getJSONObject(i)
                    WfEntry(obj.getLong("id"), obj.getString("name"), obj.getString("path"))
                }
                mainHandler.post {
                    setBusy(false)
                    if (wfs.isEmpty()) { appendLog("No workflows found in repo."); return@post }
                    val labels = wfs.map { "⚡  ${it.name}\n    ${it.path}" }.toTypedArray()
                    AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                        .setTitle("⚡ Trigger Workflow")
                        .setMessage("Branch: $branch")
                        .setItems(labels) { _, which ->
                            val wf = wfs[which]
                            setBusy(true)
                            appendLog("Triggering '${wf.name}' on $branch…")
                            thread {
                                try {
                                    val payload = JSONObject().put("ref", branch).toString()
                                    val (c2, b2) = httpPost(token,
                                        "https://api.github.com/repos/$owner/$repo/actions/workflows/${wf.id}/dispatches",
                                        payload)
                                    if (c2 == 204) {
                                        appendLog("✓ Workflow '${wf.name}' triggered on $branch!")
                                        appendLog("  Check Build Log in a moment to see it running.")
                                    } else {
                                        appendLog("✗ Trigger failed ($c2): ${b2.take(150)}")
                                    }
                                } catch (e: Exception) {
                                    appendLog("✗ ${e.message}")
                                } finally {
                                    mainHandler.post { setBusy(false) }
                                }
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    // ── Settings dialog ───────────────────────────────────────────────────────

    private fun showSettingsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_settings, null)

        // Grab settings dialog views
        val sEtToken        = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtToken)
        val sEtRepo         = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtRepo)
        val sEtBranch       = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtBranch)
        val sEtKeystorePass = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtKeystorePass)
        val sEtKeyAlias     = view.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.sEtKeyAlias)
        val sTvOwnerInfo    = view.findViewById<TextView>(R.id.sTvOwnerInfo)
        val sTvKeystoreStatus = view.findViewById<TextView>(R.id.sTvKeystoreStatus)
        val sBtnSwitchRepo  = view.findViewById<Button>(R.id.sBtnSwitchRepo)
        val sBtnGenerate    = view.findViewById<Button>(R.id.sBtnGenerateKeystore)
        val sBtnClose       = view.findViewById<android.widget.ImageButton>(R.id.btnCloseSettings)
        val sBtnSave        = view.findViewById<Button>(R.id.sBtnSave)
        val tvDownloadPath    = view.findViewById<TextView>(R.id.tvDownloadPath)
        val sBtnPickFolder    = view.findViewById<Button>(R.id.sBtnPickFolder)
        val sBtnClearFolder   = view.findViewById<Button>(R.id.sBtnClearFolder)
        val sBtnClearHistory  = view.findViewById<Button>(R.id.sBtnClearHistory)
        val layoutDlHistory   = view.findViewById<LinearLayout>(R.id.layoutDownloadHistory)

        // Show current download path
        fun refreshDownloadPath() {
            val uri = prefs.getString(PREF_DOWNLOAD_URI, null)
            tvDownloadPath.text = if (uri != null) {
                Uri.parse(uri).lastPathSegment ?: uri
            } else {
                "Default (Downloads)"
            }
        }
        refreshDownloadPath()

        // Populate download history
        fun refreshHistory() {
            layoutDlHistory.removeAllViews()
            val entries = loadDownloadHistory()
            if (entries.isEmpty()) {
                val empty = TextView(this).apply {
                    text = "No downloads yet"
                    textSize = 12f
                    setTextColor(getColor(R.color.text_tertiary))
                    setPadding(4.dp, 6.dp, 4.dp, 6.dp)
                }
                layoutDlHistory.addView(empty)
            } else {
                entries.forEach { entry ->
                    val name = entry.optString("name", "unknown")
                    val path = entry.optString("path", "")
                    val size = entry.optLong("size", 0L)
                    val time = entry.optLong("time", 0L)
                    val timeStr = java.text.SimpleDateFormat("MMM d, HH:mm", java.util.Locale.getDefault())
                        .format(java.util.Date(time))
                    val sizeStr = fmtBytes(size)

                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = android.view.Gravity.CENTER_VERTICAL
                        setPadding(0, 5.dp, 0, 5.dp)
                    }

                    val icon = TextView(this).apply {
                        text = "📥"
                        textSize = 14f
                        setPadding(0, 0, 8.dp, 0)
                    }

                    val info = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    val tvName = TextView(this).apply {
                        text = name
                        textSize = 12f
                        typeface = android.graphics.Typeface.MONOSPACE
                        setTextColor(getColor(R.color.text_primary))
                        isSingleLine = true
                        ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    }
                    val tvMeta = TextView(this).apply {
                        text = "$sizeStr  ·  $timeStr"
                        textSize = 10f
                        setTextColor(getColor(R.color.text_tertiary))
                    }
                    info.addView(tvName)
                    info.addView(tvMeta)

                    // Long-press copies path
                    row.setOnLongClickListener {
                        val clip = android.content.ClipData.newPlainText("path", path)
                        (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                        android.widget.Toast.makeText(this, "Path copied", android.widget.Toast.LENGTH_SHORT).show()
                        true
                    }

                    row.addView(icon)
                    row.addView(info)
                    layoutDlHistory.addView(row)

                    // Divider
                    val div = View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT, 1
                        ).also { it.setMargins(0, 2.dp, 0, 2.dp) }
                        setBackgroundColor(getColor(R.color.divider))
                    }
                    layoutDlHistory.addView(div)
                }
            }
        }
        refreshHistory()

        // Pre-populate from main activity fields
        sEtToken.setText(etToken.text)
        sEtRepo.setText(etRepo.text)
        sEtBranch.setText(etBranch.text)
        sEtKeystorePass.setText(etKeystorePass.text)
        sEtKeyAlias.setText(etKeyAlias.text)

        // Mirror owner chip if visible
        if (tvOwnerInfo.visibility == android.view.View.VISIBLE && tvOwnerInfo.text.isNotEmpty()) {
            sTvOwnerInfo.text = tvOwnerInfo.text
            sTvOwnerInfo.visibility = android.view.View.VISIBLE
        }
        // Mirror keystore status if visible
        if (tvKeystoreStatus.visibility == android.view.View.VISIBLE && tvKeystoreStatus.text.isNotEmpty()) {
            sTvKeystoreStatus.text = tvKeystoreStatus.text
            sTvKeystoreStatus.visibility = android.view.View.VISIBLE
        }

        val dialog = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setView(view)
            .setCancelable(true)
            .create()
        dialog.window?.setBackgroundDrawable(
            ColorDrawable(android.graphics.Color.TRANSPARENT)
        )

        fun saveAndClose() {
            // Write back to main activity fields
            etToken.setText(sEtToken.text)
            etRepo.setText(sEtRepo.text)
            etBranch.setText(sEtBranch.text)
            etKeystorePass.setText(sEtKeystorePass.text)
            etKeyAlias.setText(sEtKeyAlias.text)
            // Persist to prefs
            prefs.edit()
                .putString("token",  sEtToken.text.toString().trim())
                .putString("repo",   sEtRepo.text.toString().trim())
                .putString("branch", sEtBranch.text.toString().trim().ifEmpty { "main" })
                .apply()
            dialog.dismiss()
        }

        sBtnSave.setOnClickListener     { saveAndClose() }
        sBtnClose.setOnClickListener    { dialog.dismiss() }
        sBtnSwitchRepo.setOnClickListener {
            saveAndClose()
            showSavedReposDialog()
        }
        sBtnGenerate.setOnClickListener {
            // Copy pass/alias back first so generateKeystore() reads correct values
            etKeystorePass.setText(sEtKeystorePass.text)
            etKeyAlias.setText(sEtKeyAlias.text)
            dialog.dismiss()
            generateKeystore()
        }

        sBtnPickFolder.setOnClickListener {
            onFolderPicked = { refreshDownloadPath() }
            pickFolderLauncher.launch(null)
        }

        sBtnClearFolder.setOnClickListener {
            prefs.edit().remove(PREF_DOWNLOAD_URI).apply()
            refreshDownloadPath()
        }

        sBtnClearHistory.setOnClickListener {
            prefs.edit().remove(PREF_DOWNLOAD_HISTORY).apply()
            refreshHistory()
        }

        dialog.show()

        // Make dialog width match screen
        dialog.window?.setLayout(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun showManageFilesDialog() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }

        // Allow opening the create-repo dialog even without a repo name
        if (repo.isEmpty()) {
            AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                .setTitle("📂 File Manager")
                .setMessage("No repo entered. Would you like to create a new repo?")
                .setPositiveButton("🆕 Create Repo") { _, _ -> promptCreateRepo(token) }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        // If owner is already cached, go straight to browsing
        if (lastOwner.isNotEmpty()) {
            fetchAndBrowse(token, lastOwner, repo, branch, "")
            return
        }

        // Otherwise look it up (same pattern as browseAllArtifacts / downloadLatestRunLogs)
        setBusy(true)
        appendLog("Verifying token…")
        thread {
            val owner = fetchOwner(token)
            if (owner == null) {
                appendLog("✗ Could not verify token — check it has 'repo' scope.")
                mainHandler.post { setBusy(false) }
                return@thread
            }
            lastOwner = owner
            mainHandler.post {
                tvOwnerInfo.text = "✓  @$owner / $repo"; tvOwnerInfo.visibility = android.view.View.VISIBLE
                fetchAndBrowse(token, owner, repo, branch, "")
            }
        }
    }

    /** Fetches directory contents and opens the browser dialog. */
    private fun fetchAndBrowse(token: String, owner: String, repo: String, branch: String, path: String) {
        setBusy(true)
        appendLog("Browsing ${if (path.isEmpty()) "repo root" else "/$path"} …")
        thread {
            try {
                val items = mutableListOf<RepoItem>()
                val (code, body) = httpGet(token, apiContents(owner, repo, path.ifEmpty { "" }))
                when {
                    code == 404  -> { /* empty dir — show empty browser */ }
                    code != 200  -> throw Exception("HTTP $code listing /${path.ifEmpty { "" }}")
                    else -> {
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val obj = arr.getJSONObject(i)
                            items.add(RepoItem(
                                type = obj.getString("type"),
                                name = obj.getString("name"),
                                path = obj.getString("path"),
                                sha  = obj.optString("sha", "")
                            ))
                        }
                        // Folders first, then files, alphabetical within each group
                        items.sortWith(compareBy({ if (it.type == "dir") 0 else 1 }, { it.name }))
                    }
                }
                mainHandler.post { setBusy(false); showBrowserDialog(token, owner, repo, branch, path, items) }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /** Main browsing dialog — tap folder to navigate, tap file to act on it. */
    private fun showBrowserDialog(
        token: String, owner: String, repo: String, branch: String,
        path: String, items: List<RepoItem>
    ) {
        val dp = resources.displayMetrics.density

        // ── Custom title: header bar + action chips + breadcrumb ──────────
        val segments = if (path.isEmpty()) emptyList() else path.split("/")

        val titleRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor("#1C2038"))
        }

        // Top bar: icon + repo path
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity     = android.view.Gravity.CENTER_VERTICAL
            setPadding((16 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
        }
        val folderIv = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_folder)
            imageTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#FF9F43"))
            layoutParams = LinearLayout.LayoutParams((18 * dp).toInt(), (18 * dp).toInt()).also {
                it.marginEnd = (10 * dp).toInt()
            }
        }
        val titleTv = TextView(this).apply {
            text      = "$owner / $repo"
            textSize  = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.parseColor("#E8EAED"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val branchChip = TextView(this).apply {
            text = "  $branch  "
            textSize = 9.5f
            setTextColor(0xFF2ECC71.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
        }
        topBar.addView(folderIv); topBar.addView(titleTv); topBar.addView(branchChip)
        titleRoot.addView(topBar)

        // Action chips row
        var pendingDialog: AlertDialog? = null
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), (2*dp).toInt(), (14*dp).toInt(), (8*dp).toInt())
        }
        fun actionChip(label: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 10.5f
            setTextColor(0xFFE8EAED.toInt())
            setBackgroundColor(bg)
            setPadding((8*dp).toInt(), (4*dp).toInt(), (8*dp).toInt(), (4*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (6*dp).toInt() }
            setOnClickListener { onClick() }
        }
        chipRow.addView(actionChip("🔀 Switch", 0xFF2A2D4A.toInt()) {
            pendingDialog?.dismiss(); showSavedReposDialog()
        })
        chipRow.addView(actionChip("⚡ Trigger", 0xFF1A2E1A.toInt()) {
            pendingDialog?.dismiss()
            triggerWorkflowDispatch(token, owner, repo, branch)
        })
        titleRoot.addView(chipRow)

        // Breadcrumb strip
        val breadScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), (12 * dp).toInt())
        }
        val breadRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun crumb(label: String, targetPath: String?, isLast: Boolean) = TextView(this).apply {
            text     = label
            textSize = 13f
            setTextColor(if (isLast)
                android.graphics.Color.parseColor("#9AA0B8")
            else
                android.graphics.Color.parseColor("#7C6BFF"))
            setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
            if (!isLast && targetPath != null) setOnClickListener {
                pendingDialog?.dismiss()
                fetchAndBrowse(token, owner, repo, branch, targetPath)
            }
        }
        fun sep() = TextView(this).apply {
            text = " / "; textSize = 13f
            setTextColor(android.graphics.Color.parseColor("#3A4060"))
        }

        breadRow.addView(crumb("root", "", segments.isEmpty()))
        segments.forEachIndexed { i, seg ->
            breadRow.addView(sep())
            breadRow.addView(crumb(seg, segments.take(i + 1).joinToString("/"), i == segments.lastIndex))
        }
        breadScroll.addView(breadRow)
        breadScroll.post { breadScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }
        titleRoot.addView(breadScroll)

        // Thin accent line at bottom of title
        titleRoot.addView(android.view.View(this).apply {
            setBackgroundColor(android.graphics.Color.parseColor("#232747"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Build nav list ───────────────────────────────────────────────
        val navItems = mutableListOf<RepoItem>()
        if (path.isNotEmpty()) {
            val parentPath = if (path.contains("/")) path.substringBeforeLast("/") else ""
            navItems.add(RepoItem(type = "__up__", name = "..", path = parentPath, sha = ""))
        }
        navItems.addAll(items)

        // ── Custom ArrayAdapter using item_file.xml ──────────────────────
        val adapter = object : android.widget.ArrayAdapter<RepoItem>(
            this, R.layout.item_file, navItems
        ) {
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val row = convertView ?: layoutInflater.inflate(R.layout.item_file, parent, false)
                row.setBackgroundColor(android.graphics.Color.parseColor("#13162A"))
                val item = navItems[pos]
                val ivIcon  = row.findViewById<android.widget.ImageView>(R.id.ivFileIcon)
                val tvName  = row.findViewById<TextView>(R.id.tvFileName)
                val tvType  = row.findViewById<TextView>(R.id.tvFileType)
                val ivChev  = row.findViewById<android.widget.ImageView>(R.id.ivChevron)

                when (item.type) {
                    "__up__" -> {
                        ivIcon.setImageResource(R.drawable.ic_folder)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#9AA0B8"))
                        tvName.text = ".. (up one level)"
                        tvName.setTextColor(android.graphics.Color.parseColor("#9AA0B8"))
                        tvType.text = "parent folder"
                        ivChev.visibility = android.view.View.VISIBLE
                    }
                    "dir" -> {
                        ivIcon.setImageResource(R.drawable.ic_folder)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#FF9F43"))
                        tvName.text = item.name
                        tvName.setTextColor(android.graphics.Color.parseColor("#E8EAED"))
                        tvType.text = "folder"
                        ivChev.visibility = android.view.View.VISIBLE
                    }
                    else -> {
                        ivIcon.setImageResource(R.drawable.ic_file)
                        ivIcon.imageTintList = android.content.res.ColorStateList.valueOf(
                            android.graphics.Color.parseColor("#7C6BFF"))
                        tvName.text = item.name
                        tvName.setTextColor(android.graphics.Color.parseColor("#E8EAED"))
                        val ext = item.name.substringAfterLast(".", "")
                        tvType.text = if (ext.isNotEmpty()) ext.uppercase() else "file"
                        ivChev.visibility = android.view.View.GONE
                    }
                }
                return row
            }
        }

        // ── Buttons ───────────────────────────────────────────────────────
        val builder = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setAdapter(adapter) { _, which ->
                val item = navItems[which]
                when {
                    item.type == "__up__" || item.type == "dir" ->
                        fetchAndBrowse(token, owner, repo, branch, item.path)
                    else -> {
                        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                            .setTitle(item.name)
                            .setItems(arrayOf(
                                "👁  View / Edit",
                                "📋  Copy content",
                                "✏️  Move / Rename",
                                "🗑  Delete"
                            )) { _, action ->
                                when (action) {
                                    0 -> fetchAndViewFile(token, owner, repo, branch, item, path)
                                    1 -> fetchAndCopyFile(token, owner, repo, item)
                                    2 -> {
                                        val input = EditText(this).apply {
                                            setText(item.path)
                                            hint = "new/path/filename.ext"
                                            inputType = android.text.InputType.TYPE_CLASS_TEXT
                                            setPadding(64, 24, 64, 24)
                                            setSelection(text.length)
                                        }
                                        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                                            .setTitle("Move / Rename")
                                            .setMessage("Enter the new path for this file:")
                                            .setView(input)
                                            .setPositiveButton("Move") { _, _ ->
                                                val newPath = input.text.toString().trim().trimStart('/')
                                                if (newPath.isEmpty() || newPath == item.path) {
                                                    appendLog("⚠ Path unchanged."); return@setPositiveButton
                                                }
                                                setBusy(true)
                                                thread { moveRepoFile(token, owner, repo, branch, item, newPath, path) }
                                            }
                                            .setNegativeButton("Cancel", null).show()
                                    }
                                    3 -> AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                                            .setTitle("Confirm Delete")
                                            .setMessage("Delete from repo?\n\n• ${item.name}")
                                            .setPositiveButton("Delete") { _, _ ->
                                                setBusy(true)
                                                thread {
                                                    deleteRepoFile(token, owner, repo, branch, item.path, item.sha, item.name)
                                                    setBusy(false)
                                                    mainHandler.post { fetchAndBrowse(token, owner, repo, branch, path) }
                                                }
                                            }
                                            .setNegativeButton("Cancel", null).show()
                                }
                            }
                            .setNegativeButton("Cancel", null).show()
                    }
                }
            }
            .setPositiveButton("＋ New") { _, _ -> showNewItemDialog(token, owner, repo, branch, path) }

        if (items.isNotEmpty()) {
            builder.setNeutralButton("🗑 Delete") { _, _ ->
                showDeleteDialog(token, owner, repo, branch, path, items)
            }
        } else if (path.isEmpty()) {
            builder.setNeutralButton("🆕 New Repo") { _, _ -> promptCreateRepo(token) }
        }

        builder.setNegativeButton(if (path.isNotEmpty()) "↑ Up" else "Close") { _, _ ->
            if (path.isNotEmpty()) {
                val parentPath = if (path.contains("/")) path.substringBeforeLast("/") else ""
                fetchAndBrowse(token, owner, repo, branch, parentPath)
            }
        }

        if (navItems.isEmpty()) builder.setMessage("  (empty folder)")

        pendingDialog = builder.show()

        // Style buttons with clear semantic colors
        pendingDialog?.getButton(AlertDialog.BUTTON_POSITIVE)
            ?.setTextColor(0xFF2ECC71.toInt())   // green — New
        pendingDialog?.getButton(AlertDialog.BUTTON_NEUTRAL)
            ?.setTextColor(0xFFFF6B6B.toInt())   // red — Delete
        pendingDialog?.getButton(AlertDialog.BUTTON_NEGATIVE)
            ?.setTextColor(0xFF9AA0B8.toInt())   // gray — Close / Up

        // Dark background for the list area
        pendingDialog?.listView?.setBackgroundColor(android.graphics.Color.parseColor("#13162A"))
        pendingDialog?.listView?.divider =
            android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1C2038"))
        pendingDialog?.listView?.dividerHeight = 1
    }

    // ── View / Edit file ─────────────────────────────────────────────────────

    /** Fetches file content from GitHub and opens the editor dialog. */
    private fun fetchAndViewFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, currentPath: String
    ) {
        setBusy(true)
        appendLog("Loading ${item.name} …")
        thread {
            try {
                val (code, body) = httpGet(token, apiContents(owner, repo, item.path))
                if (code != 200) throw Exception("HTTP $code fetching ${item.path}")
                val obj = org.json.JSONObject(body)
                val sha  = obj.optString("sha", item.sha)
                val size = obj.optLong("size", 0)
                // GitHub wraps base64 at 60 chars — strip all whitespace before decoding
                val raw  = obj.optString("content", "").replace("\n", "").replace("\r", "")
                val bytes = try { android.util.Base64.decode(raw, android.util.Base64.DEFAULT) } catch (e: Exception) { ByteArray(0) }
                val text = if (bytes.isEmpty()) "(binary or empty file — not editable)" else {
                    try { String(bytes, Charsets.UTF_8) } catch (e: Exception) { "(binary file — not editable as text)" }
                }
                mainHandler.post {
                    setBusy(false)
                    showFileEditorDialog(token, owner, repo, branch, item.copy(sha = sha), text, currentPath)
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /** Shows the improved file editor dialog — line numbers, horizontal scroll, status bar. */
    private fun showFileEditorDialog(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, content: String, currentPath: String
    ) {
        val dp       = resources.displayMetrics.density
        val screenH  = resources.displayMetrics.heightPixels
        val screenW  = resources.displayMetrics.widthPixels
        val isBinary = content.startsWith("(binary")

        // ── Colour palette (GitHub dark) ─────────────────────────────────
        val bgEditor   = 0xFF0D1117.toInt()
        val bgGutter   = 0xFF161B22.toInt()
        val bgTitleBar = 0xFF1C2038.toInt()
        val bgStatus   = 0xFF161B22.toInt()
        val clrCode    = 0xFFE6EDF3.toInt()
        val clrGutter  = 0xFF495570.toInt()
        val clrInfo    = 0xFF9AA0B8.toInt()
        val clrBadge   = 0xFF7C6BFF.toInt()

        val lines = content.lines()
        val lineCount = lines.size

        // ── Top info bar ─────────────────────────────────────────────────
        val infoBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(bgTitleBar)
            setPadding((12*dp).toInt(), (8*dp).toInt(), (12*dp).toInt(), (8*dp).toInt())
        }
        val ext = item.name.substringAfterLast(".", "").uppercase().takeIf { it.isNotEmpty() } ?: "TXT"
        val extBadge = TextView(this).apply {
            text = ext
            textSize = 9.5f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(clrBadge)
            setPadding((6*dp).toInt(), (2*dp).toInt(), (6*dp).toInt(), (2*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (10*dp).toInt() }
        }
        val infoTv = TextView(this).apply {
            val sizeStr = when {
                content.length >= 1024 -> "${content.length / 1024} KB"
                else -> "${content.length} B"
            }
            text = "$lineCount lines  ·  $sizeStr  ·  UTF-8"
            textSize = 11f
            setTextColor(clrInfo)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val branchBadge = TextView(this).apply {
            text = "  $branch  "
            textSize = 9.5f
            setTextColor(0xFF2ECC71.toInt())
            typeface = android.graphics.Typeface.MONOSPACE
        }
        infoBar.addView(extBadge); infoBar.addView(infoTv); infoBar.addView(branchBadge)

        // ── Line numbers ─────────────────────────────────────────────────
        val lineNumberStr = (1..lineCount).joinToString("\n")
        val lineNumTv = TextView(this).apply {
            text = lineNumberStr
            textSize = 11.5f
            setTextColor(clrGutter)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(bgGutter)
            setPadding((10*dp).toInt(), (14*dp).toInt(), (10*dp).toInt(), (14*dp).toInt())
            gravity = android.view.Gravity.TOP or android.view.Gravity.END
            setLineSpacing(0f, 1.35f)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // ── Code EditText ─────────────────────────────────────────────────
        val etContent = EditText(this).apply {
            setText(content)
            inputType = if (isBinary) android.text.InputType.TYPE_CLASS_TEXT
                        else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            isEnabled = !isBinary
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11.5f
            setTextColor(clrCode)
            setHintTextColor(clrGutter)
            setBackgroundColor(bgEditor)
            setPadding((14*dp).toInt(), (14*dp).toInt(), (24*dp).toInt(), (14*dp).toInt())
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            minLines = 5
            setLineSpacing(0f, 1.35f)
            isSingleLine = false
            maxLines = Integer.MAX_VALUE
            // Make wide enough for horizontal scroll to be useful
            minWidth = (screenW * 2.5f).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            // Sync line numbers on edit
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val n = (s?.toString() ?: "").lines().size
                    lineNumTv.text = (1..n).joinToString("\n")
                }
            })
        }

        // Horizontal scroll wraps the code EditText only
        val hScroll = HorizontalScrollView(this).apply {
            setBackgroundColor(bgEditor)
            isHorizontalScrollBarEnabled = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(etContent)
        }

        // Side-by-side: gutter + hScroll
        val editorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bgEditor)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        editorRow.addView(lineNumTv)
        editorRow.addView(hScroll)

        // Outer vertical scroll for the code area
        val nsv = androidx.core.widget.NestedScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (screenH * 0.54f).toInt()
            )
            isFillViewport = true
            setBackgroundColor(bgEditor)
            addView(editorRow)
        }

        // ── Status bar ────────────────────────────────────────────────────
        val statusBar = TextView(this).apply {
            text = if (isBinary) "Binary file — read only" else "Tap to edit  ·  Save commits to $branch"
            textSize = 10.5f
            setTextColor(clrGutter)
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(bgStatus)
            setPadding((12*dp).toInt(), (6*dp).toInt(), (12*dp).toInt(), (6*dp).toInt())
        }

        // ── Container ─────────────────────────────────────────────────────
        val editorRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgEditor)
        }
        editorRoot.addView(infoBar)
        // Thin separator
        editorRoot.addView(android.view.View(this).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })
        editorRoot.addView(nsv)
        editorRoot.addView(statusBar)

        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("📄  ${item.name}")
            .setView(editorRoot)
            .setPositiveButton(if (isBinary) "Close" else "💾 Save") { _, _ ->
                if (!isBinary) {
                    val newText = etContent.text.toString()
                    setBusy(true)
                    thread { saveFileContent(token, owner, repo, branch, item, newText, currentPath) }
                }
            }
            .setNeutralButton("📋 Copy") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, etContent.text.toString()))
                appendLog("📋 Copied ${item.name} to clipboard.")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Encodes and PUTs the new file content to GitHub. */
    private fun saveFileContent(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newContent: String, refreshPath: String
    ) {
        try {
            val encoded = android.util.Base64.encodeToString(
                newContent.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP
            )
            val payload = org.json.JSONObject().apply {
                put("message", "edit: update ${item.path} via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (code, body) = httpPut(token, apiContents(owner, repo, item.path), payload)
            if (code in 200..201) {
                appendLog("✓ Saved: ${item.path}")
                mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
            } else {
                appendLog("✗ Save failed ($code): ${body.take(150)}")
                mainHandler.post { setBusy(false) }
            }
        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            mainHandler.post { setBusy(false) }
        }
    }

    /** Fetches a file's content from GitHub and copies it to the clipboard. */
    private fun fetchAndCopyFile(token: String, owner: String, repo: String, item: RepoItem) {
        setBusy(true)
        appendLog("Fetching ${item.name} for copy …")
        thread {
            try {
                val (code, body) = httpGet(token, apiContents(owner, repo, item.path))
                if (code != 200) throw Exception("HTTP $code")
                val raw = org.json.JSONObject(body).optString("content", "")
                    .replace("\n", "").replace("\r", "")
                val bytes = android.util.Base64.decode(raw, android.util.Base64.DEFAULT)
                val text  = String(bytes, Charsets.UTF_8)
                mainHandler.post {
                    setBusy(false)
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(item.name, text))
                    appendLog("📋 Copied ${item.name} to clipboard (${text.length} chars).")
                }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    // ── Repository Switcher ───────────────────────────────────────────────────

    /** Switches the active repo/branch and clears all stale per-repo state. */
    private fun applySwitchRepo(repo: String, branch: String) {
        etRepo.setText(repo)
        etBranch.setText(branch)
        prefs.edit().putString("repo", repo).putString("branch", branch).apply()
        lastOwner           = ""
        lastRemotePath      = ""
        lastFileSha         = null
        lastRunId           = -1L
        artifactDownloadUrl = null
        clearBuildState()
        mainHandler.post {
            tvOwnerInfo.text = ""; tvOwnerInfo.visibility = android.view.View.GONE
            btnDownloadApk?.isEnabled = false
            setStatus("Idle")
        }
        appendLog("🔀 Switched to: $repo @ $branch")
    }

    /**
     * Fetches all repos for the authenticated user from GitHub and shows a
     * picker. Tapping a repo immediately switches to it.
     */
    private fun showSavedReposDialog() {
        val token = etToken.text.toString().trim()
        if (token.isEmpty()) {
            AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                .setTitle("No Token")
                .setMessage("Enter your GitHub token first so your repositories can be fetched.")
                .setPositiveButton("OK", null).show()
            return
        }

        // Show a loading dialog while we fetch
        val loadingDlg = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("🔀 Switch Repository")
            .setMessage("Fetching your repositories…")
            .setCancelable(true)
            .show()

        thread {
            try {
                // Fetch up to 100 repos sorted by most recently updated
                val url = "https://api.github.com/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator"
                val (code, body) = httpGet(token, url)
                if (code != 200) throw Exception("GitHub returned HTTP $code")

                val arr = org.json.JSONArray(body)
                if (arr.length() == 0) throw Exception("No repositories found for this token.")

                // Build display list
                data class RepoEntry(val fullName: String, val name: String, val defaultBranch: String, val private: Boolean)
                val repos = (0 until arr.length()).map { i ->
                    val obj = arr.getJSONObject(i)
                    RepoEntry(
                        fullName      = obj.getString("full_name"),
                        name          = obj.getString("name"),
                        defaultBranch = obj.optString("default_branch", "main"),
                        private       = obj.optBoolean("private", false)
                    )
                }
                val labels = repos.map { r ->
                    val icon = if (r.private) "🔒" else "📁"
                    "$icon  ${r.name}   (${r.defaultBranch})"
                }.toTypedArray()

                mainHandler.post {
                    loadingDlg.dismiss()
                    val dp2 = resources.displayMetrics.density
                    val adapter = object : android.widget.ArrayAdapter<String>(
                        this, android.R.layout.simple_list_item_1, labels
                    ) {
                        override fun getView(pos: Int, cv: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                            val row = android.widget.LinearLayout(context).apply {
                                orientation = android.widget.LinearLayout.HORIZONTAL
                                gravity = android.view.Gravity.CENTER_VERTICAL
                                setPadding((16*dp2).toInt(), (14*dp2).toInt(), (16*dp2).toInt(), (14*dp2).toInt())
                                setBackgroundColor(0xFF13162A.toInt())
                            }
                            val tv = TextView(context).apply {
                                text = labels[pos]
                                textSize = 14f
                                setTextColor(0xFFE8EAED.toInt())
                            }
                            row.addView(tv)
                            return row
                        }
                    }
                    val dlgRepo = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                        .setTitle("🔀 Switch Repository  (${repos.size})")
                        .setAdapter(adapter) { _, which ->
                            val picked = repos[which]
                            applySwitchRepo(picked.name, picked.defaultBranch)
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    dlgRepo.listView?.setBackgroundColor(0xFF13162A.toInt())
                    dlgRepo.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(0xFF9AA0B8.toInt())
                }
            } catch (e: Exception) {
                mainHandler.post {
                    loadingDlg.dismiss()
                    AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                        .setTitle("Could not fetch repositories")
                        .setMessage(e.message ?: "Unknown error")
                        .setPositiveButton("OK", null).show()
                }
            }
        }
    }

    /** Sub-menu: create a folder or a file. */
    private fun showNewItemDialog(token: String, owner: String, repo: String, branch: String, currentPath: String) {
        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("Create New…")
            .setItems(arrayOf("📁  New Folder", "📄  New File", "📤  Upload File")) { _, which ->
                when (which) {
                    0 -> promptCreateFolder(token, owner, repo, branch, currentPath)
                    1 -> promptCreateFile(token, owner, repo, branch, currentPath)
                    2 -> {
                        // Store context so the activity-result callback knows where to upload
                        pendingUploadToken  = token
                        pendingUploadOwner  = owner
                        pendingUploadRepo   = repo
                        pendingUploadBranch = branch
                        pendingUploadPath   = currentPath
                        pickUploadFile.launch(arrayOf("*/*"))
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptCreateFolder(token: String, owner: String, repo: String, branch: String, parentPath: String) {
        val input = EditText(this).apply {
            hint = "folder-name"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
        }
        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("📁 New Folder")
            .setMessage("A .gitkeep file will be placed inside\n(GitHub doesn't allow empty folders).")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) { appendLog("⚠ Folder name cannot be empty."); return@setPositiveButton }
                val filePath = if (parentPath.isEmpty()) "$name/.gitkeep" else "$parentPath/$name/.gitkeep"
                setBusy(true)
                thread { createRepoFile(token, owner, repo, branch, filePath, "", parentPath) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptCreateFile(token: String, owner: String, repo: String, branch: String, parentPath: String) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 16, 64, 8)
        }
        val etName = EditText(this).apply {
            hint = "filename.txt"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        val etContent = EditText(this).apply {
            hint = "File content (optional)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        container.addView(etName)
        container.addView(etContent)

        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("📄 New File")
            .setView(container)
            .setPositiveButton("Create") { _, _ ->
                val name    = etName.text.toString().trim()
                val content = etContent.text.toString()
                if (name.isEmpty()) { appendLog("⚠ File name cannot be empty."); return@setPositiveButton }
                val filePath = if (parentPath.isEmpty()) name else "$parentPath/$name"
                setBusy(true)
                thread { createRepoFile(token, owner, repo, branch, filePath, content, parentPath) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun createRepoFile(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, content: String, refreshPath: String
    ) {
        try {
            val encoded = Base64.encodeToString(content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val payload = JSONObject().apply {
                put("message", "chore: create $filePath via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("branch",  branch)
            }.toString()
            val (code, body) = httpPut(token, apiContents(owner, repo, filePath), payload)
            if (code in 200..201) {
                appendLog("✓ Created: $filePath")
                mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
            } else {
                appendLog("✗ Create failed ($code): ${body.take(150)}")
                setBusy(false)
            }
        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setBusy(false)
        }
    }

    // ── Upload local file to repo ─────────────────────────────────────────────

    /**
     * Reads [uri] from the device, base-64 encodes it, and PUTs it to GitHub.
     * Binary files (images, zips, APKs…) are handled the same way as text — the
     * GitHub Contents API accepts any base-64 payload regardless of MIME type.
     * Files > ~50 MB will be rejected by the API; we warn early.
     */
    private fun uploadFileToRepo(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, uri: Uri, refreshPath: String
    ) {
        try {
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            if (bytes.size > 50 * 1024 * 1024) {
                appendLog("✗ File too large for GitHub Contents API (> 50 MB)."); return
            }
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            appendLog("  Size: ${bytes.size / 1024} KB")

            val existingSha = fetchFileSha(token, owner, repo, filePath)
            val payload = JSONObject().apply {
                put("message", "upload: $filePath via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("branch",  branch)
                if (existingSha != null) put("sha", existingSha)
            }.toString()
            val (code, body) = httpPut(token, apiContents(owner, repo, filePath), payload)
            if (code in 200..201) {
                appendLog("✓ Uploaded: $filePath")
            } else {
                appendLog("✗ Upload failed ($code): ${body.take(200)}")
            }
        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
        }
    }

    // ── Create repo from file manager ────────────────────────────────────────

    /**
     * Shows a dialog to create a brand-new GitHub repo without starting a build.
     * Resolves the owner from the token first (cached in [lastOwner]).
     */
    private fun promptCreateRepo(token: String) {
        val input = EditText(this).apply {
            hint = "my-new-repo"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
        }
        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("🆕 Create Repository")
            .setMessage("Enter a name for the new GitHub repo.\n⚠ Spaces will be replaced with hyphens.")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                // Sanitize: trim, replace spaces/invalid chars with hyphens, collapse runs
                val rawName = input.text.toString().trim()
                if (rawName.isEmpty()) { appendLog("⚠ Repo name cannot be empty."); return@setPositiveButton }
                val repoName = rawName
                    .replace(Regex("[^A-Za-z0-9._-]"), "-")  // only letters/digits/./−/_ allowed
                    .replace(Regex("-{2,}"), "-")             // collapse consecutive hyphens
                    .trim('-')                                 // strip leading/trailing hyphens
                if (repoName.isEmpty()) { appendLog("⚠ Repo name invalid after sanitisation."); return@setPositiveButton }
                if (repoName != rawName) appendLog("ℹ Repo name adjusted to: $repoName")

                setBusy(true)
                appendLog("Creating repo: $repoName …")
                thread {
                    try {
                        val owner = if (lastOwner.isNotEmpty()) lastOwner else {
                            val o = fetchOwner(token) ?: throw Exception("Could not verify token.")
                            lastOwner = o
                            mainHandler.post { tvOwnerInfo.text = "✓  @$o / $repoName"; tvOwnerInfo.visibility = android.view.View.VISIBLE }
                            o
                        }
                        val body = JSONObject().apply {
                            put("name",        repoName)
                            put("private",     false)
                            put("auto_init",   true)
                            put("description", "Repo created via ZipApkBuilder")
                        }.toString()
                        val (code, resp) = httpPost(token, "https://api.github.com/user/repos", body)
                        if (code !in 200..201) {
                            appendLog("✗ Create repo failed ($code): ${resp.take(200)}")
                            setBusy(false); return@thread
                        }
                        appendLog("✓ Repo created: github.com/$owner/$repoName")

                        // Auto-fill the repo field
                        mainHandler.post {
                            etRepo.setText(repoName)
                            prefs.edit().putString("repo", repoName).apply()
                        }

                        // Poll until GitHub has initialised the repo (up to ~20 s)
                        val branch = etBranch.text.toString().trim().ifEmpty { "main" }
                        appendLog("Waiting for GitHub to initialise repo…")
                        var ready = false
                        repeat(10) {
                            Thread.sleep(2_000)
                            val (chk, _) = httpGet(token, "https://api.github.com/repos/$owner/$repoName")
                            if (chk == 200) { ready = true; return@repeat }
                        }
                        if (!ready) {
                            appendLog("⚠ Repo created but not yet reachable — open file manager manually.")
                            setBusy(false); return@thread
                        }
                        appendLog("Repo ready ✓")
                        mainHandler.post { fetchAndBrowse(token, owner, repoName, branch, "") }
                    } catch (e: Exception) {
                        appendLog("✗ ${e.message}")
                        setBusy(false)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Multi-select delete dialog. */
    private fun showDeleteDialog(
        token: String, owner: String, repo: String, branch: String,
        currentPath: String, items: List<RepoItem>
    ) {
        val names   = items.map { if (it.type == "dir") "📁  ${it.name}" else "📄  ${it.name}" }.toTypedArray()
        val checked = BooleanArray(items.size)
        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setTitle("🗑️  Select to Delete")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Delete Selected") { _, _ ->
                val toDelete = items.filterIndexed { i, _ -> checked[i] }
                if (toDelete.isEmpty()) { appendLog("Nothing selected."); return@setPositiveButton }
                val hasFolders = toDelete.any { it.type == "dir" }
                val list = toDelete.joinToString("\n• ", prefix = "• ") {
                    "${if (it.type == "dir") "📁" else "📄"} ${it.name}"
                }
                val warning = if (hasFolders) "\n\n⚠ Folders will be deleted recursively." else ""
                AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                    .setTitle("Confirm Deletion")
                    .setMessage("Delete ${toDelete.size} item(s)?$warning\n\n$list")
                    .setPositiveButton("Delete") { _, _ ->
                        setBusy(true)
                        thread { deleteItemsRecursive(token, owner, repo, branch, toDelete, currentPath) }
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun deleteItemsRecursive(
        token: String, owner: String, repo: String, branch: String,
        items: List<RepoItem>, refreshPath: String
    ) {
        try {
            for (item in items) {
                if (item.type == "file") {
                    deleteRepoFile(token, owner, repo, branch, item.path, item.sha, item.name)
                } else {
                    deleteFolderRecursive(token, owner, repo, branch, item.path)
                }
            }
            mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
        } catch (e: Exception) {
            appendLog("✗ ${e.message}")
            setBusy(false)
        }
    }

    /** Recursively lists and deletes every file inside a folder. */
    private fun deleteFolderRecursive(token: String, owner: String, repo: String, branch: String, path: String) {
        appendLog("📁 Deleting folder: $path …")
        val (code, body) = httpGet(token, apiContents(owner, repo, path))
        if (code == 404) { appendLog("  (already gone)"); return }
        if (code != 200) throw Exception("HTTP $code listing $path")
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val obj  = arr.getJSONObject(i)
            val type = obj.getString("type")
            val childPath = obj.getString("path")
            val childSha  = obj.optString("sha", "")
            val childName = obj.getString("name")
            if (type == "dir") deleteFolderRecursive(token, owner, repo, branch, childPath)
            else deleteRepoFile(token, owner, repo, branch, childPath, childSha, childName)
        }
    }

    private fun deleteRepoFile(
        token: String, owner: String, repo: String, branch: String,
        path: String, sha: String, name: String
    ) {
        val payload = JSONObject().apply {
            put("message", "chore: delete $path via ZipApkBuilder [skip ci]")
            put("sha",     sha)
            put("branch",  branch)
        }.toString()
        val (code, resp) = httpDelete(token, apiContents(owner, repo, path), payload)
        if (code in 200..204) {
            appendLog("✓ Deleted: $name")
            if (path == lastRemotePath) lastFileSha = null
        } else {
            appendLog("✗ Failed to delete $name ($code): ${resp.take(120)}")
        }
    }

    /**
     * Moves/renames a file by reading its content, creating it at [newPath],
     * then deleting the original. Refreshes the browser at [refreshPath] when done.
     */
    private fun moveRepoFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newPath: String, refreshPath: String
    ) {
        try {
            appendLog("Moving ${item.name} → $newPath …")

            // 1. Read current file content (base64) from GitHub
            val (getCode, getBody) = httpGet(token, apiContents(owner, repo, item.path))
            if (getCode != 200) throw Exception("Could not read file ($getCode)")
            val encodedContent = JSONObject(getBody).getString("content")
                .replace("\n", "").replace("\r", "") // GitHub wraps base64 at 60 chars

            // 2. Create file at new path
            val createPayload = JSONObject().apply {
                put("message", "chore: move ${item.path} → $newPath via ZipApkBuilder [skip ci]")
                put("content", encodedContent)
                put("branch",  branch)
            }.toString()
            val (putCode, putBody) = httpPut(token, apiContents(owner, repo, newPath), createPayload)
            if (putCode !in 200..201) throw Exception("Could not create at $newPath ($putCode): ${putBody.take(150)}")

            // 3. Delete original
            val deletePayload = JSONObject().apply {
                put("message", "chore: remove ${item.path} after move [skip ci]")
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (delCode, delBody) = httpDelete(token, apiContents(owner, repo, item.path), deletePayload)
            if (delCode !in 200..204) throw Exception("Moved but failed to delete original ($delCode): ${delBody.take(150)}")

            appendLog("✓ Moved to: $newPath")
            if (item.path == lastRemotePath) lastRemotePath = newPath

            mainHandler.post { fetchAndBrowse(token, owner, repo, branch, refreshPath) }
        } catch (e: Exception) {
            appendLog("✗ Move failed: ${e.message}")
        } finally {
            setBusy(false)
        }
    }

    // ── In-app workflow log viewer ────────────────────────────────────────────

    /** Entry point — fetches all runs and shows a picker dialog. */
    private fun fetchAndShowWorkflowLog() {
        val token = etToken.text.toString().trim()
        val repo  = etRepo.text.toString().trim()
        if (token.isEmpty()) { appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { appendLog("⚠ Enter a repository name first."); return }

        setBusy(true)
        appendLog("Fetching workflow runs from GitHub…")

        thread {
            try {
                // Resolve owner — use cached value or fetch from token (same pattern as
                // browseAllArtifacts / downloadLatestRunLogs)
                val owner = lastOwner.ifEmpty {
                    (fetchOwner(token) ?: throw Exception(
                        "Could not verify token — check it has 'repo' scope."
                    )).also {
                        lastOwner = it
                        mainHandler.post { tvOwnerInfo.text = "✓  @$it / $repo"; tvOwnerInfo.visibility = android.view.View.VISIBLE }
                    }
                }

                val allRuns = mutableListOf<JSONObject>()
                // Fetch up to 3 pages × 30 = 90 runs (covers all recent history)
                for (page in 1..3) {
                    val url = "${apiRuns(owner, repo)}?per_page=30&page=$page"
                    val (code, body) = httpGet(token, url)
                    if (code != 200) break
                    val arr = JSONObject(body).getJSONArray("workflow_runs")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allRuns.add(arr.getJSONObject(i))
                    if (arr.length() < 30) break
                }
                if (allRuns.isEmpty()) {
                    appendLog("No workflow runs found in github.com/$owner/$repo")
                    mainHandler.post { setBusy(false) }
                    return@thread
                }
                appendLog("Found ${allRuns.size} run(s) ✓")
                mainHandler.post { setBusy(false); showRunPickerDialog(token, owner, repo, allRuns) }
            } catch (e: Exception) {
                appendLog("✗ ${e.message}")
                mainHandler.post { setBusy(false) }
            }
        }
    }

    /**
     * Shows workflow runs with custom adapter for correct colors, + Trigger button.
     */
    private fun showRunPickerDialog(
        token: String, owner: String, repo: String,
        runs: List<JSONObject>
    ) {
        val dp    = resources.displayMetrics.density
        val fmt   = SimpleDateFormat("MMM d, HH:mm", Locale.US)
        val fmtIn = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
        val branch = etBranch.text.toString().trim().ifEmpty { "main" }

        // ── Custom title ──────────────────────────────────────────────────
        val titleRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1C2038.toInt())
        }
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding((16*dp).toInt(), (12*dp).toInt(), (8*dp).toInt(), (8*dp).toInt())
        }
        val titleTv = TextView(this).apply {
            text = "🔍  $owner / $repo"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val countBadge = TextView(this).apply {
            text = " ${runs.size} runs "
            textSize = 10f
            setTextColor(0xFF00D4AA.toInt())
            setBackgroundColor(0xFF00251F.toInt())
            setPadding((8*dp).toInt(), (3*dp).toInt(), (8*dp).toInt(), (3*dp).toInt())
        }
        topBar.addView(titleTv); topBar.addView(countBadge)
        titleRoot.addView(topBar)
        titleRoot.addView(android.view.View(this).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Custom adapter ────────────────────────────────────────────────
        data class RunInfo(val runNum: Long, val name: String, val icon: String,
                           val dateStr: String, val statusStr: String, val conclusion: String)
        val runInfos = runs.map { run ->
            val runNum     = run.optLong("run_number", 0L)
            val name       = run.optString("name", "build")
            val status     = run.optString("status", "")
            val conc       = run.optString("conclusion", "")
            val createdRaw = run.optString("created_at", "")
            val dateStr    = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) } catch (_: Exception) { "" }
            } else ""
            val icon = when (conc) {
                "success"   -> "✅"
                "failure"   -> "❌"
                "cancelled" -> "⛔"
                "skipped"   -> "⏭"
                else        -> if (status == "in_progress") "🔄" else "⏳"
            }
            val statusStr = if (conc.isNotEmpty()) conc else status
            RunInfo(runNum, name, icon, dateStr, statusStr, conc)
        }

        var selectedIndex = -1
        val listView = android.widget.ListView(this).apply {
            setBackgroundColor(0xFF13162A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt())
            dividerHeight = 1
        }
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = runInfos.size
            override fun getItem(pos: Int) = runInfos[pos]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val info = runInfos[pos]
                val isSelected = (pos == selectedIndex)
                val bgColor = when {
                    isSelected               -> 0xFF221F4A.toInt()
                    info.conclusion == "failure" -> 0xFF1A0000.toInt()
                    info.conclusion == "success" -> 0xFF001A0D.toInt()
                    else -> 0xFF13162A.toInt()
                }
                val row = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setBackgroundColor(bgColor)
                    setPadding((14*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                }
                val iconTv = TextView(parent.context).apply {
                    text = info.icon
                    textSize = 18f
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.marginEnd = (12*dp).toInt() }
                }
                val col = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val runNumTv = TextView(parent.context).apply {
                    text = "Run #${info.runNum}  ·  ${info.name}"
                    textSize = 13f
                    setTextColor(0xFFE8EAED.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                }
                val metaTv = TextView(parent.context).apply {
                    text = buildString {
                        if (info.dateStr.isNotEmpty()) append(info.dateStr)
                        if (info.statusStr.isNotEmpty()) append("  ·  ${info.statusStr}")
                    }
                    textSize = 10.5f
                    setTextColor(when (info.conclusion) {
                        "success"  -> 0xFF2ECC71.toInt()
                        "failure"  -> 0xFFFF6B6B.toInt()
                        else       -> 0xFF50587A.toInt()
                    })
                }
                col.addView(runNumTv); col.addView(metaTv)
                row.addView(iconTv); row.addView(col)
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            selectedIndex = pos
            adapter.notifyDataSetChanged()
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
        }
        // titleRoot is passed to setCustomTitle below — do NOT also addView it here
        val maxH = (resources.displayMetrics.heightPixels * 0.58f).toInt()
        root.addView(android.widget.FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH)
            addView(listView)
        })

        AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(root)
            .setPositiveButton("📄 View Log") { _, _ ->
                if (selectedIndex < 0) { appendLog("⚠ Tap a run to select it first."); return@setPositiveButton }
                val run    = runs[selectedIndex]
                val runId  = run.getLong("id")
                val runNum = run.optLong("run_number", runId)
                setBusy(true)
                appendLog("Fetching log for run #$runNum…")
                thread { fetchLogForRun(token, owner, repo, runId, runNum) }
            }
            .setNeutralButton("⚡ Trigger") { _, _ ->
                triggerWorkflowDispatch(token, owner, repo, branch)
            }
            .setNegativeButton("🔄 Refresh") { _, _ -> fetchAndShowWorkflowLog() }
            .show()
    }

    /** Fetches the log text for a specific run and shows it in showLogDialog. */
    private fun fetchLogForRun(token: String, owner: String, repo: String, runId: Long, runNum: Long) {
        try {
            val (jobsCode, jobsBody) = httpGet(token, "${apiRuns(owner, repo)}/$runId/jobs")
            if (jobsCode != 200) throw Exception("Could not fetch jobs (HTTP $jobsCode)")
            val jobsArr = JSONObject(jobsBody).optJSONArray("jobs")
                ?: throw Exception("No jobs array for run #$runNum")
            if (jobsArr.length() == 0) throw Exception("No jobs found for run #$runNum")

            // Show all jobs in the run, not just the first one
            val allJobLogs = StringBuilder()
            for (ji in 0 until jobsArr.length()) {
                val job   = jobsArr.getJSONObject(ji)
                val jobId = job.getLong("id")
                val jobName = job.optString("name", "job-$ji")
                appendLog("Loading log for job '$jobName'…")

                val conn1 = (URL("https://api.github.com/repos/$owner/$repo/actions/jobs/$jobId/logs")
                    .openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                    instanceFollowRedirects = false
                    connectTimeout = 30_000; readTimeout = 120_000
                }
                val text: String? = when (val c = conn1.responseCode) {
                    in 301..308 -> {
                        val loc = conn1.getHeaderField("Location"); conn1.disconnect()
                        try {
                            val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                                requestMethod = "GET"; connectTimeout = 30_000; readTimeout = 120_000
                            }
                            if (c2.responseCode == 200) c2.inputStream.bufferedReader().readText()
                                .also { c2.disconnect() }
                            else { c2.disconnect(); null }
                        } catch (_: Exception) { null }
                    }
                    200  -> conn1.inputStream.bufferedReader().readText().also { conn1.disconnect() }
                    410  -> { conn1.disconnect(); "⚠ Log expired or unavailable for this run." }
                    else -> { conn1.disconnect(); "⚠ HTTP $c — log not available." }
                }
                if (text != null) {
                    if (jobsArr.length() > 1) {
                        allJobLogs.append("══════ JOB: $jobName ══════\n")
                    }
                    allJobLogs.append(text).append("\n")
                }
            }

            val logText = allJobLogs.toString()
            appendLog("✓ Log: ${logText.length / 1024} KB, ${logText.lines().size} lines")
            mainHandler.post { showLogDialog(logText, runNum) }
        } catch (e: Exception) {
            appendLog("✗ Log error: ${e.message}")
        } finally {
            setBusy(false)
        }
    }

    private fun showLogDialog(logText: String, runId: Long) {
        val ansiRegex = Regex("""\x1B\[[0-9;]*[A-Za-z]""")
        val tsRegex   = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
        val groupRx   = Regex("""^##\[(?:group|endgroup)\]""")

        val lines = logText.lines()
        val allCleaned = lines
            .map  { ansiRegex.replace(tsRegex.replace(it, ""), "") }
            .filter { !groupRx.containsMatchIn(it) }

        // Cap display at 1 500 lines to avoid OOM on large logs — full text still
        // available via "Copy All". Show tail (most relevant for build failures).
        val maxLines   = 1_500
        val truncated  = allCleaned.size > maxLines
        val cleaned    = if (truncated) allCleaned.takeLast(maxLines) else allCleaned

        val sizeStr = when {
            logText.length >= 1_048_576 -> "%.1f MB".format(logText.length / 1_048_576.0)
            logText.length >= 1_024     -> "${logText.length / 1024} KB"
            else                        -> "${logText.length} B"
        }

        val header = buildString {
            append("⚙  Run #$runId   •   $sizeStr   •   ${allCleaned.size} lines\n")
            if (truncated) append("⚠  Showing last $maxLines lines — tap Copy All for full log\n")
            append("─────────────────────────────────────\n")
        }

        // Build display the same way Browse Artifacts does — styled TextView in a dark card
        val ctx = this
        val sv  = ScrollView(ctx)
        sv.setBackgroundColor(0xFF0D0D0D.toInt())
        val tv = TextView(ctx).apply {
            // Append in two calls so we never hold header + body as one giant String
            text = header
            append(cleaned.joinToString("\n"))
            textSize = 9.5f
            setTextColor(0xFF00E676.toInt())   // same green as console log
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(24, 24, 24, 24)
            setLineSpacing(0f, 1.25f)
        }
        sv.addView(tv)
        sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }

        AlertDialog.Builder(ctx, R.style.Theme_App_Dialog)
            .setTitle("🔍  Build Log — Run #$runId")
            .setView(sv)
            .setPositiveButton("📋 Copy All") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Build Log", logText))
                appendLog("✓ Full log copied ($sizeStr).")
            }
            .setNeutralButton("↙ Tail Console") { _, _ ->
                appendLog("=== Log Run #$runId ===")
                cleaned.takeLast(60).forEach { appendLog(it) }
                appendLog("=== End ===")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ── Clipboard & share ─────────────────────────────────────────────────────

    private fun copyLogToClipboard() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("Build Log", text))
        appendLog("✓ Log copied to clipboard.")
    }

    private fun saveLogToFile() {
        val text = tvLog.text.toString()
        if (text.isEmpty()) { appendLog("Log is empty."); return }
        thread {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(java.util.Date())
                val file  = File(cacheDir, "build_log_$stamp.txt").also { it.writeText(text) }
                val uri   = FileProvider.getUriForFile(this, "${packageName}.provider", file)
                mainHandler.post {
                    startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "Share Build Log"))
                }
            } catch (e: Exception) { appendLog("✗ Share error: ${e.message}") }
        }
    }

    // ── HTTP ──────────────────────────────────────────────────────────────────

    // ── Download / Upload dialog helpers ──────────────────────────────────────

    /** Holds references to the live views inside a reusable download-progress dialog. */
    private inner class DownloadDialogHolder(
        val dialog:      AlertDialog,
        val progressBar: android.widget.ProgressBar,
        val tvSize:      TextView,
        val tvPercent:   TextView,
        val tvSpeed:     TextView,
        val btnPauseResume: Button,
        val btnCancel:   Button
    )

    /** Build and show a download-progress dialog. Pause/cancel flags are the shared volatiles. */
    private fun buildDownloadProgressDialog(title: String, fileName: String): DownloadDialogHolder {
        val dp = resources.displayMetrics.density

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (20*dp).toInt(), (20*dp).toInt(), (12*dp).toInt())
            setBackgroundColor(0xFF13162A.toInt())
        }

        val tvName = TextView(this).apply {
            text = fileName; textSize = 13f
            setTextColor(0xFFE8EAED.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val tvSize = TextView(this).apply {
            text = "Connecting…"; textSize = 11f
            setTextColor(0xFF9AA0B8.toInt())
            setPadding(0, (4*dp).toInt(), 0, (10*dp).toInt())
        }

        val progressBar = android.widget.ProgressBar(this, null,
            android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progress = 0
            progressDrawable = android.graphics.drawable.LayerDrawable(arrayOf(
                android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt()),
                android.graphics.drawable.ClipDrawable(
                    android.graphics.drawable.ColorDrawable(0xFF2ECC71.toInt()),
                    android.view.Gravity.START,
                    android.graphics.drawable.ClipDrawable.HORIZONTAL
                )
            )).also { ld -> ld.setId(0, android.R.id.background); ld.setId(1, android.R.id.progress) }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (8*dp).toInt()
            ).also { it.bottomMargin = (4*dp).toInt() }
        }

        val tvPercent = TextView(this).apply {
            text = "0%"; textSize = 11f; setTextColor(0xFF2ECC71.toInt())
            gravity = android.view.Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val tvSpeed = TextView(this).apply {
            text = ""; textSize = 10.5f; setTextColor(0xFF50587A.toInt())
            setPadding(0, (6*dp).toInt(), 0, (2*dp).toInt())
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.END
            setPadding(0, (14*dp).toInt(), 0, 0)
        }

        val btnPauseResume = Button(this).apply {
            text = "⏸ Pause"; textSize = 12f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF1E5799.toInt())
            setPadding((16*dp).toInt(), (6*dp).toInt(), (16*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (8*dp).toInt() }
        }

        val btnCancel = Button(this).apply {
            text = "✕ Cancel"; textSize = 12f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF6B2020.toInt())
            setPadding((16*dp).toInt(), (6*dp).toInt(), (16*dp).toInt(), (6*dp).toInt())
        }

        btnRow.addView(btnPauseResume); btnRow.addView(btnCancel)
        root.addView(tvName); root.addView(tvSize); root.addView(progressBar)
        root.addView(tvPercent); root.addView(tvSpeed); root.addView(btnRow)

        val dialog = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
            .setCustomTitle(TextView(this).apply {
                text = title; textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFFE8EAED.toInt())
                setPadding((20*dp).toInt(), (18*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
                setBackgroundColor(0xFF1C2038.toInt())
            })
            .setView(root).setCancelable(false).create()

        btnPauseResume.setOnClickListener {
            downloadPaused = !downloadPaused
            btnPauseResume.text = if (downloadPaused) "▶ Resume" else "⏸ Pause"
            btnPauseResume.setBackgroundColor(if (downloadPaused) 0xFF2A6B2A.toInt() else 0xFF1E5799.toInt())
            tvSpeed.text = if (downloadPaused) "Paused" else ""
        }
        btnCancel.setOnClickListener { downloadCancelled = true; dialog.dismiss() }

        dialog.show()
        return DownloadDialogHolder(dialog, progressBar, tvSize, tvPercent, tvSpeed, btnPauseResume, btnCancel)
    }

    // ── Upload progress ────────────────────────────────────────────────────────

    private inner class UploadDialogHolder(
        val dialog:     AlertDialog,
        val onProgress: (written: Long, total: Long) -> Unit
    )

    /**
     * Must be called from a background thread. Creates the dialog on the main thread
     * via a latch, then returns the holder so the caller can drive progress updates.
     */
    private fun showUploadProgressDialog(fileName: String, totalBytes: Long): UploadDialogHolder {
        val dp = resources.displayMetrics.density

        fun fmtBytes(b: Long) = when {
            b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
            b >= 1_024     -> "${b / 1024} KB"
            else           -> "$b B"
        }
        val totalStr = fmtBytes(totalBytes)

        // Build views (safe from any thread before attaching to window)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (20*dp).toInt(), (20*dp).toInt(), (12*dp).toInt())
            setBackgroundColor(0xFF13162A.toInt())
        }

        val tvName = TextView(this).apply {
            text = fileName; textSize = 13f
            setTextColor(0xFFE8EAED.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val tvSize = TextView(this).apply {
            text = "0 B / $totalStr"; textSize = 11f
            setTextColor(0xFF9AA0B8.toInt())
            setPadding(0, (4*dp).toInt(), 0, (10*dp).toInt())
        }

        val progressBar = android.widget.ProgressBar(this, null,
            android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; progress = 0
            progressDrawable = android.graphics.drawable.LayerDrawable(arrayOf(
                android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt()),
                android.graphics.drawable.ClipDrawable(
                    android.graphics.drawable.ColorDrawable(0xFF7B68EE.toInt()), // purple for upload
                    android.view.Gravity.START,
                    android.graphics.drawable.ClipDrawable.HORIZONTAL
                )
            )).also { ld -> ld.setId(0, android.R.id.background); ld.setId(1, android.R.id.progress) }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (8*dp).toInt()
            ).also { it.bottomMargin = (4*dp).toInt() }
        }

        val tvPercent = TextView(this).apply {
            text = "0%"; textSize = 11f; setTextColor(0xFF7B68EE.toInt())
            gravity = android.view.Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        val tvSpeed = TextView(this).apply {
            text = ""; textSize = 10.5f; setTextColor(0xFF50587A.toInt())
            setPadding(0, (6*dp).toInt(), 0, (2*dp).toInt())
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.END
            setPadding(0, (14*dp).toInt(), 0, 0)
        }

        val btnCancel = Button(this).apply {
            text = "✕ Cancel"; textSize = 12f; setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF6B2020.toInt())
            setPadding((16*dp).toInt(), (6*dp).toInt(), (16*dp).toInt(), (6*dp).toInt())
        }

        btnRow.addView(btnCancel)
        root.addView(tvName); root.addView(tvSize); root.addView(progressBar)
        root.addView(tvPercent); root.addView(tvSpeed); root.addView(btnRow)

        val holderRef = arrayOfNulls<UploadDialogHolder>(1)
        val latch = java.util.concurrent.CountDownLatch(1)

        mainHandler.post {
            val dialog = AlertDialog.Builder(this, R.style.Theme_App_Dialog)
                .setCustomTitle(TextView(this).apply {
                    text = "📤  Uploading"; textSize = 15f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(0xFFE8EAED.toInt())
                    setPadding((20*dp).toInt(), (18*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
                    setBackgroundColor(0xFF1C2038.toInt())
                })
                .setView(root).setCancelable(false).create()

            btnCancel.setOnClickListener { uploadCancelled = true; dialog.dismiss() }

            var lastSpeedTime  = System.currentTimeMillis()
            var lastSpeedBytes = 0L

            val onProgress: (Long, Long) -> Unit = { written, total ->
                val now     = System.currentTimeMillis()
                val elapsed = now - lastSpeedTime
                if (elapsed >= 200) {
                    val speedBps = (written - lastSpeedBytes) * 1000L / elapsed.coerceAtLeast(1)
                    lastSpeedTime  = now; lastSpeedBytes = written
                    val pct    = if (total > 0) (written * 1000L / total).toInt() else 0
                    val dlStr  = fmtBytes(written)
                    val spdStr = "${fmtBytes(speedBps)}/s"
                    val pctStr = if (total > 0) "${"%.1f".format(written * 100.0 / total)}%" else "…"
                    mainHandler.post {
                        progressBar.progress = pct
                        tvPercent.text = pctStr
                        tvSize.text    = "$dlStr / $totalStr"
                        tvSpeed.text   = spdStr
                    }
                }
            }

            dialog.show()
            holderRef[0] = UploadDialogHolder(dialog, onProgress)
            latch.countDown()
        }

        latch.await()
        return holderRef[0]!!
    }

    /** PUT with chunked writes so upload progress can be tracked. */
    private fun httpPutWithProgress(
        token: String,
        urlStr: String,
        body: String,
        onProgress: (written: Long, total: Long) -> Unit
    ): Pair<Int, String> {
        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 120_000; readTimeout = 120_000
            setFixedLengthStreamingMode(bodyBytes.size.toLong())
        }
        conn.connect()
        val chunkSize = 65_536
        var written = 0
        conn.outputStream.use { out ->
            while (written < bodyBytes.size) {
                if (uploadCancelled) { conn.disconnect(); throw Exception("Cancelled by user") }
                val end = minOf(written + chunkSize, bodyBytes.size)
                out.write(bodyBytes, written, end - written)
                written = end
                onProgress(written.toLong(), bodyBytes.size.toLong())
            }
            out.flush()
        }
        return try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }
    }

    private fun httpGet(token: String, urlStr: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            connectTimeout = 30_000; readTimeout = 30_000
        })

    private fun httpPut(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "PUT"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 120_000; readTimeout = 120_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun httpPost(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun httpDelete(token: String, urlStr: String, body: String) =
        readResponse((URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true; connectTimeout = 30_000; readTimeout = 30_000
        }.also { it.outputStream.bufferedWriter().use { w -> w.write(body) } })

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> =
        try {
            val code = conn.responseCode
            Pair(code, (if (code < 400) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText() ?: "")
        } finally { conn.disconnect() }

    // ── URL builders ──────────────────────────────────────────────────────────

    private fun apiContents(owner: String, repo: String, path: String) =
        "https://api.github.com/repos/$owner/$repo/contents/$path"

    private fun apiRuns(owner: String, repo: String) =
        "https://api.github.com/repos/$owner/$repo/actions/runs"

    // ── UI helpers ────────────────────────────────────────────────────────────

    private fun setStatus(text: String) = mainHandler.post {
        tvStatus.text = text
        tvStatus.setTextColor(when {
            text.contains("✓") || text.startsWith("Ready") -> 0xFF4CAF50.toInt()
            text.contains("✗") || text.contains("failed")  -> 0xFFFF5252.toInt()
            else                                             -> 0xFFFFFFFF.toInt()
        })
    }

    private fun appendLog(msg: String) = mainHandler.post {
        tvLog.append("$msg\n")
        scrollLog.post { scrollLog.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setBusy(busy: Boolean) = mainHandler.post {
        isBusy                   = busy
        progressBar.visibility   = if (busy) View.VISIBLE else View.GONE
        btnUploadBuild.isEnabled = !busy
        btnPickZip.isEnabled     = !busy
        // Download button: only re-enable when not busy AND an artifact URL is known
        if (!busy) btnDownloadApk?.isEnabled = (artifactDownloadUrl != null)

        // Animate console dots while busy
        if (busy) startDotAnimations() else { stopDotAnimations(); startIdleDotAnimations() }
    }

    private fun startIdleDotAnimations() {
        stopDotAnimations()
        fun idleAnim(target: View?, delayMs: Long): android.animation.AnimatorSet {
            val sx = android.animation.ObjectAnimator.ofFloat(target, "scaleX", 1f, 1.25f).apply {
                duration = 900; startDelay = delayMs; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            }
            val sy = android.animation.ObjectAnimator.ofFloat(target, "scaleY", 1f, 1.25f).apply {
                duration = 900; startDelay = delayMs; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            }
            val al = android.animation.ObjectAnimator.ofFloat(target, "alpha", 1f, 0.55f).apply {
                duration = 900; startDelay = delayMs; repeatCount = android.animation.ValueAnimator.INFINITE
                repeatMode = android.animation.ValueAnimator.REVERSE
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            }
            return android.animation.AnimatorSet().also { it.playTogether(sx, sy, al); it.start() }
        }
        dotAnimRed    = idleAnim(dotRed,    0L)
        dotAnimYellow = idleAnim(dotYellow, 300L)
        dotAnimGreen  = idleAnim(dotGreen,  600L)
    }

    private fun startDotAnimations() {
        stopDotAnimations()
        fun buildAnim(resId: Int, target: View?): android.animation.AnimatorSet? {
            if (target == null) return null
            val set = android.animation.AnimatorInflater.loadAnimator(this, resId) as android.animation.AnimatorSet
            set.childAnimations.forEach { (it as? android.animation.ObjectAnimator)?.target = target }
            set.start()
            return set
        }
        dotAnimRed    = buildAnim(R.animator.dot_pulse_red,    dotRed)
        dotAnimYellow = buildAnim(R.animator.dot_pulse_yellow, dotYellow)
        dotAnimGreen  = buildAnim(R.animator.dot_pulse_green,  dotGreen)
    }

    private fun stopDotAnimations() {
        listOf(dotAnimRed, dotAnimYellow, dotAnimGreen).forEach { it?.cancel() }
        dotAnimRed = null; dotAnimYellow = null; dotAnimGreen = null
        dotRed?.apply   { scaleX = 1f; scaleY = 1f; alpha = 1f }
        dotYellow?.apply { scaleX = 1f; scaleY = 1f; alpha = 1f }
        dotGreen?.apply  { scaleX = 1f; scaleY = 1f; alpha = 1f }
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private fun resolveFileName(uri: Uri): String {
        var name = "project.zip"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        name = name.replace(Regex("[^a-zA-Z0-9._ \\-]"), "_")
        if (!name.lowercase().endsWith(".zip")) name += ".zip"
        return name
    }

    /** Like [resolveFileName] but keeps whatever extension the file already has — used for
     *  repo uploads where .cs, .txt, .png etc. must stay as-is. */
    private fun resolveUploadFileName(uri: Uri): String {
        var name = "upload_${System.currentTimeMillis()}"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) name = c.getString(col)
        }
        return name.replace(Regex("[^a-zA-Z0-9._ \\-]"), "_")
    }

    private fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }
}
