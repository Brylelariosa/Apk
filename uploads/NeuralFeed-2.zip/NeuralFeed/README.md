# NEURAL//FEED

Offline action-incremental Android game. You are an AI core in a dark network. Every run is a short, timed
visit to a small sealed sector: find enemies in the dark, lock onto them, collect the Data they drop and get out
when the clock runs out. Spend the Data in the skill tree, make the enemies stronger for richer Data, discover what
the Data really is, and travel back through time.

## How a run works
- **The clock is your health.** There is no health bar. Every hit costs seconds off the run clock (barrier charges can
  block a hit completely, Time guard makes hits cost less). When the clock reaches zero the run ends and everything you
  gathered is banked.
- **Dark network.** You only see as far as your vision radius. A scan ping sweeps the whole sector every few seconds.
  Enemies wander until they notice the core (or a nearby enemy is hit), hunt it, then search where it was last seen.
- **The Finder.** The core searches its lock radius and locks onto the nearest few enemies (multi-lock upgrades add more).
  Only locked enemies take damage. A crowd close to the core adds pressure to every lock.
- **Data fields and elites.** Hidden Data fields slowly regrow. A rich elite process walks in every ~20 s.
- **Quota.** Process enough enemies in a run to meet the quota. Meet it twice at your highest enemy strength to unlock the
  next strength level.
- **Boss runs** (AI level 4+): one boss, a longer clock. Destroying it is what opens time travel.

## Progression
- **Skill tree** (CORE tab): three branches grow out of the core. FINDER (lock-on attack), HARVEST (vision, Data) and
  CHRONO (run clock, barrier). Every node needs the one before it. Tap a node to see what it does; the card at the bottom
  has the buy button (x1 / x10 / max).
- **Enemy strength** (RUN tab): raise it for tougher enemies and more Data per enemy. Quota runs unlock higher levels.
- **Tutorial**: the first run is a guided training run, with the AI explaining each step out loud. Two hub cards then explain
  the skill tree and enemy strength. "Replay the tutorial" is in System settings.
- **Decisions** sometimes follow a run and shape the AI's character (the ideology/karma system, memories and endings are
  unchanged).

## Voice
AI lines are spoken through the system text-to-speech engine, pitched and paced by the AI's ideology and growth, and the music
dips while it talks. Toggle "Spoken AI voice" in System settings. With no speech engine installed the game falls back to
its synthesized voice blips. (Android 11+ needs the `<queries>` entry in the manifest to see the engine.)

## Controls
- Left joystick: move (drag in the lower-left; "Floating joystick" in System settings lets you start anywhere on the left).
- Dash: bottom-right big button. Abilities: the smaller buttons (equip them on the RUN tab).
- Pause (top-right): resume, Customize HUD (move/resize/opacity/reset), volume, end the run (you keep what you gathered).

## Tuning
Balance lives in a few places: `game/Run.java` (enemy strength scaling, quota, data growth), `meta/Upgrades.java` (node
costs, caps, tree layout, `COST_SCALE`), `meta/StatsCalc.java` (how nodes turn into stats), `game/Spawner.java` (pressure and
waves), `game/EnemyAI.java` (detection range, search timing) and `World.damagePlayer` (time lost per hit).

## Project layout (`app/src/main/java/com/neuralfeed`)
- `core`    math, RNG, spatial grid, number formatting
- `data`    profile, versioned/checksummed key-value saves (atomic write + backup), export/import
- `meta`    skill tree, stats, karma/ideology, story text, events, timelines, prestige, endings
- `game`    world simulation (pooled enemies/orbs/bullets/particles), Finder lock-on, enemy AI, bosses, abilities, arenas
- `render`  Canvas renderer (batched primitives, fog of war), AI core art, HUD, immediate-mode UI
- `audio`   procedural SFX/music synthesised at start-up, real-time mixer (AudioTrack), system text-to-speech wrapper
- `ui`      App root, screens (title, hub tabs, gameplay + overlays, HUD editor, cinematics), tutorial

No native code, no third-party libraries, no assets besides the launcher icon. Build with Gradle 8.6, JDK 17, AGP 8.4.2.
