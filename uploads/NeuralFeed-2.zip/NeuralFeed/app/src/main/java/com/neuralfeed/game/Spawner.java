package com.neuralfeed.game;

import com.neuralfeed.core.Mx;
import com.neuralfeed.meta.Defs;

/** Run pacing: keeps a pressure curve of enemies alive, fires encircling waves and sends in a rich elite every so often. */
final class Spawner {
    private Spawner() {}

    private static final float[] BASE_W = {10f, 5f, 2f, 2.2f, 2.5f, 1.6f, 1.2f, 1.0f, 1.0f};
    private static final float[] WT = new float[9];
    private static float sx, sy;

    static void update(World w, float dt) {
        if (w.kind == Defs.RUN_VOID) return;
        w.stageTime += dt;
        float spawnMul = w.run.spawnScale() * w.spawnBias;
        float press = 0.45f + 0.55f * Mx.min(1f, w.stageTime / Mx.max(10f, w.timeMax * 0.6f));
        int target = w.kind == Defs.RUN_BOSS ? 3 + (int) (4f * press) : (int) (12f + 22f * press);
        target = Math.min((int) (target * spawnMul), World.MAXE - 28);
        w.spawnCd -= dt;
        if (w.aliveHostile < target && w.spawnCd <= 0f) {
            spawnOne(w);
            w.spawnCd = Mx.max(0.08f, 0.22f / Mx.max(0.2f, spawnMul));
        }
        if (w.kind == Defs.RUN_HARVEST && w.spawnBias >= 1f) {
            w.waveT -= dt;
            if (w.waveT <= 0f) { spawnWave(w); w.waveT = Mx.max(11f, 21f - 0.5f * w.tier()); }
            w.eliteT -= dt;
            if (w.eliteT <= 0f) { w.spawnElite(); w.eliteT = Mx.max(12f, 22f - 0.4f * w.run.threat); }
        }
        if (w.pf.paradox >= 100f && w.stageTime > 20f && ((int) (w.stageTime) % 25 == 0) && w.rng.chance(dt * 4f)) instability(w);
    }

    private static boolean ringPos(World w, float minD, float maxD) {
        Player pl = w.pl;
        Arena ar = w.arena;
        for (int t = 0; t < 6; t++) {
            float a = w.rng.ang(), d = w.rng.range(minD, maxD);
            float x = Mx.clamp(pl.x + Mx.cos(a) * d, 0.8f, ar.W - 0.8f), y = Mx.clamp(pl.y + Mx.sin(a) * d, 0.8f, ar.H - 0.8f);
            if (Mx.len(x - pl.x, y - pl.y) < 5.5f && t < 5) continue;
            sx = x; sy = y;
            return true;
        }
        return false;
    }

    private static int pickKind(World w) {
        int tier = w.tier();
        if (w.pf.paradox >= 50f) tier = Math.min(9, tier + 2);
        int fw = 0;
        for (int i = 0; i < w.enHi; i++) if (w.en[i].alive && w.en[i].kind == Kinds.FIREWALL) fw++;
        float sum = 0;
        for (int k = 0; k < 9; k++) {
            float v = tier >= Kinds.MIN_TIER[k] ? BASE_W[k] : 0f;
            if (k == Kinds.FIREWALL && fw >= 2) v = 0f;
            if (w.kind == Defs.RUN_BOSS && (k == Kinds.FIREWALL || k == Kinds.SECURITY)) v = 0f;
            WT[k] = v; sum += v;
        }
        float r = w.rng.f() * sum;
        for (int k = 0; k < 9; k++) { r -= WT[k]; if (r <= 0f) return k; }
        return Kinds.DRONE;
    }

    private static void spawnOne(World w) {
        float para = w.pf.paradox;
        int kind;
        if (para >= 20f && w.rng.chance(para >= 80f ? 0.12f : 0.05f)) kind = Kinds.ECHO;
        else kind = pickKind(w);
        if (kind == Kinds.FIREWALL) {
            for (int t = 0; t < 8; t++) {
                float x = w.rng.range(2f, w.arena.W - 2f), y = w.rng.range(2f, w.arena.H - 2f);
                if (Mx.len(x - w.pl.x, y - w.pl.y) < 8f) continue;
                if (w.arena.resolve(x, y, 0.5f, false)) continue;
                w.spawn(kind, x, y);
                return;
            }
            kind = Kinds.DRONE;
        }
        // new processes come out of the dark, beyond the edge of vision
        if (!ringPos(w, 8.5f, 11.5f)) return;
        Enemy e = w.spawn(kind, sx, sy);
        if (e != null && kind == Kinds.ECHO) e.maxHp = e.hp = Kinds.HP[Kinds.ECHO] * w.hpScale();
    }

    static void spawnWave(World w) {
        int n = 10 + Math.min(w.run.threat, 8);
        if (w.aliveHostile + n > World.MAXE - 12) n = World.MAXE - 12 - w.aliveHostile;
        if (n < 4) return;
        float base = w.rng.ang();
        float radius = 9.5f;
        for (int k = 0; k < n; k++) {
            float a = base + k * Mx.TAU / n;
            float x = Mx.clamp(w.pl.x + Mx.cos(a) * radius, 0.8f, w.arena.W - 0.8f);
            float y = Mx.clamp(w.pl.y + Mx.sin(a) * radius, 0.8f, w.arena.H - 0.8f);
            Enemy e = w.spawn(w.rng.chance(0.3f) ? Kinds.VIRUS : Kinds.DRONE, x, y);
            if (e != null) EnemyAI.alert(e);
        }
    }

    private static void instability(World w) {
        w.shake(12f);
        w.glitch = 1f;
        for (int i = 0; i < 3; i++) if (ringPos(w, 6f, 10f)) w.spawn(Kinds.ECHO, sx, sy);
    }
}
