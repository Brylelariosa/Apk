package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.game.Kinds;
import com.neuralfeed.game.World;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Hud;
import com.neuralfeed.render.Theme;

/**
 * The guided first run: a short training run where the clock stays paused until it matters, the AI talks you through
 * moving, locking on, collecting Data, the scan ping and hits costing time. Two hub cards afterwards explain the skill tree
 * and the enemy-strength dial. Progress lives in Profile.tutStep.
 */
public final class Tutorial {
    public static final int HUB_TREE = 50, HUB_THREAT = 60, DONE = 100;

    /** True while the training run has not been completed or skipped. */
    public static boolean needsRun(Profile pf) { return pf.tutStep < HUB_TREE; }

    /** Which hub card should be showing: 1 skill tree, 2 enemy strength, 0 none. */
    public static int hubCard(Profile pf) { return pf.tutStep == HUB_TREE ? 1 : (pf.tutStep == HUB_THREAT ? 2 : 0); }

    public static String hubTitle(int card) { return card == 1 ? "SKILL TREE" : "ENEMY STRENGTH"; }

    public static String hubText(int card) {
        return card == 1
                ? "Spend Data on a node to make the core stronger. Every node needs the one before it, so pick a branch and follow it."
                : "Raise the enemy strength for more Data from every enemy. Meet the quota in a couple of runs to unlock the next level.";
    }

    public static String hubLine(int card) { return card == 1 ? Lines.T_TREE : Lines.T_THREAT; }

    /** The player pressed GOT IT on a hub card. */
    public static void advanceHub(Profile pf) { pf.tutStep = pf.tutStep == HUB_TREE ? HUB_THREAT : DONE; }

    // ------------------------------------------------------------------ the training run

    private static final int S_WELCOME = 0, S_MOVE = 1, S_LOCK = 2, S_DATA = 3, S_SCAN = 4, S_HIT = 5, S_CLOCK = 6, S_N = 7;
    private static final String[] PANEL = {
            "Meet the core. Listen to what it says.",
            "Drag on the left side of the screen to move.",
            "Move close to the red enemies. The core locks on to the nearest ones by itself.",
            "Touch the glowing Data to collect it.",
            "It is dark. The scan ping lights up the whole network for a moment.",
            "Hits cost time, not health. Tap DASH to dodge them.",
            "When the clock reaches zero the run ends. Gather as much Data as you can."};
    private static final String[] TITLE = new String[S_N];
    private static final String[] LINE = {Lines.T_WELCOME, Lines.T_MOVE, Lines.T_LOCK, Lines.T_DATA, Lines.T_SCAN, Lines.T_HIT, Lines.T_CLOCK};
    static { for (int i = 0; i < S_N; i++) TITLE[i] = "TRAINING  " + (i + 1) + "/" + S_N; }

    private final App app;
    private final World w;
    private int step = -1, refI, wrapStep = -1;
    private float stepT, ref, clock;
    private boolean nudged, doneSaid;
    private float skipX, skipY, skipW, skipH;
    private String[] wrapped;

    public Tutorial(App app, World w) { this.app = app; this.w = w; }

    /** Puts the world into training mode: few enemies that come to you, no time loss, clock paused. */
    public void start() {
        w.spawnBias = 0.45f;
        w.forceAlert = true;
        w.clockPaused = true;
        w.noPenalty = true;
        // keep the training simple: no memory fragments, vaults or hazard zones this run
        w.arena.nm = 0; w.arena.nv = 0; w.arena.nz = 0;
        step = S_WELCOME; stepT = 0;
        app.say(Dialogue.AI, LINE[S_WELCOME]);
    }

    public void skip() {
        app.pf.tutStep = DONE;
        release();
        step = -1;
        app.silence();
    }

    private void release() { w.spawnBias = 1f; w.forceAlert = false; w.clockPaused = false; w.noPenalty = false; }

    public boolean skipHit(float x, float y, int sw, int sh) {
        return step >= 0 && x >= skipX && x <= skipX + skipW && y >= skipY && y <= skipY + skipH;
    }

    public void update(float dt) {
        if (step < 0) return;
        stepT += dt;
        if (w.phase >= World.P_END) {
            if (!doneSaid) { doneSaid = true; release(); app.dlg.clearQueue(); app.say(Dialogue.AI, Lines.T_DONE); }
            return;
        }
        switch (step) {
            case S_WELCOME: if (stepT > 2.2f) go(S_MOVE, null); break;
            case S_MOVE: if (w.moved - ref >= 5f) go(S_LOCK, Lines.T_MOVE_OK); break;
            case S_LOCK:
                if (w.run.kills >= 3) go(S_DATA, Lines.T_LOCK_OK);
                else if (stepT > 14f && !nudged) { nudged = true; spawnNear(4.5f, 0.3f); }
                break;
            case S_DATA: if (w.pickups - refI >= 5) go(S_SCAN, Lines.T_DATA_OK); break;
            case S_SCAN: if (stepT > 6.5f) go(S_HIT, null); break;
            case S_HIT: if ((w.dashCount - refI >= 1 && stepT > 2f) || stepT > 22f) go(S_CLOCK, w.dashCount - refI >= 1 ? Lines.T_HIT_OK : null); break;
            default: break;
        }
    }

    private void go(int s, String okLine) {
        step = s; stepT = 0; nudged = false;
        switch (s) {
            case S_MOVE: ref = w.moved; break;
            case S_DATA: refI = w.pickups; dropSample(); break;
            case S_SCAN: w.scanT = 0.2f; break;
            case S_HIT:
                refI = w.dashCount;
                w.noPenalty = false; w.clockPaused = false; w.spawnBias = 0.8f;
                for (int i = 0; i < 3; i++) spawnNear(4.2f, 1.9f + i * 2.1f);
                break;
            case S_CLOCK: w.timeLeft = Math.min(w.timeLeft, 20f); break;
            default: break;
        }
        app.dlg.clearQueue();
        if (okLine != null) app.say(Dialogue.AI, okLine);
        app.say(Dialogue.AI, LINE[s]);
    }

    private void spawnNear(float dist, float ang) {
        float x = Mx.clamp(w.pl.x + Mx.cos(ang) * dist, 1f, w.arena.W - 1f), y = Mx.clamp(w.pl.y + Mx.sin(ang) * dist, 1f, w.arena.H - 1f);
        w.spawn(Kinds.DRONE, x, y);
    }

    /** A small ring of Data around the core so the collecting step always has something to collect. */
    private void dropSample() {
        for (int k = 0; k < 6; k++) {
            float a = k * Mx.TAU / 6f;
            w.orbs.spawn(w.pl.x + Mx.cos(a) * 1.9f, w.pl.y + Mx.sin(a) * 1.9f, 0f, 0f, w.valScale() * 0.8f, Defs.O_BASIC);
        }
    }

    // ------------------------------------------------------------------ drawing

    public void draw(Canvas c, Gfx g, Theme th, Hud hud, int sw, int sh) {
        if (step < 0) return;
        clock += 1f / 60f;
        float dp = g.dp, bx = 22f * dp, bw = sw - 44f * dp, by = sh * 0.6f, lh = 19f * dp;
        if (wrapStep != step) { wrapped = TextUtil.wrap(g, PANEL[step], bw - 28f * dp, 14.5f, g.cond); wrapStep = step; }
        float bh = 46f * dp + wrapped.length * lh;
        g.rrect(c, bx, by, bw, bh, 12f * dp, Gfx.alpha(th.bg, 228));
        g.rrectLine(c, bx, by, bw, bh, 12f * dp, 1.2f * dp, Gfx.alpha(th.accent, 190));
        g.tracked(c, TITLE[step], bx + 14f * dp, by + 22f * dp, 9.5f, 0.3f, th.accent, Paint.Align.LEFT, g.condB);
        g.tracked(c, "SKIP", bx + bw - 14f * dp, by + 22f * dp, 9.5f, 0.3f, Gfx.alpha(th.text, 150), Paint.Align.RIGHT, g.condB);
        skipW = 80f * dp; skipH = 40f * dp; skipX = bx + bw - skipW; skipY = by;
        float y = by + 46f * dp;
        for (String s : wrapped) { g.text(c, s, bx + 14f * dp, y, 14.5f, th.text, Paint.Align.LEFT, g.cond); y += lh; }
        // pulse the control the current step is about
        float p = 0.5f + 0.5f * Mx.sin(clock * 6f);
        Profile pf = app.pf;
        if (step == S_MOVE) g.ring(c, hud.cx(pf, Defs.H_JOY, sw), hud.cy(pf, Defs.H_JOY, sh), hud.rad(pf, Defs.H_JOY) * (1.1f + 0.12f * p), 2.4f * dp, Gfx.alpha(th.accent, 120 + (int) (110 * p)));
        if (step == S_HIT) g.ring(c, hud.cx(pf, Defs.H_DASH, sw), hud.cy(pf, Defs.H_DASH, sh), hud.rad(pf, Defs.H_DASH) * (1.15f + 0.15f * p), 2.6f * dp, Gfx.alpha(th.accent, 120 + (int) (110 * p)));
    }
}
