package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Karma;
import com.neuralfeed.meta.Memories;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;

/** The AI's personality: ideology graph, perks, relationship, discoveries, memories. No raw karma numbers are shown. */
final class MindTab extends Tab {
    private static final String[][] PERK_NAME = {
            {"Shield network", "Restoration", "Guardian protocol", "Shared burden"},
            {"Data harvest", "Devour", "Domination", "Corruption"},
            {"Prediction", "Optimization", "Calculate", "Cold logic"},
            {"Adaptive protocol", "Balance", "Observe", "Execute"}};
    private static final String[][] PERK_DESC = {
            {"More barrier charges, recharging faster.", "Collected Data adds a little time.", "Absorbs the first hit of every run; hits cost less time.", "Damage to a lost process is shared as lost time."},
            {"More Data from every kill.", "Weakened locked enemies are executed.", "Some kills turn nearby enemies on their own.", "Damage arcs between enemies."},
            {"Shows incoming fire, slows it.", "Faster processing, shorter cooldowns.", "Decisions show their numbers.", "More Data and critical hits."},
            {"Shifts bonuses to match the crowd.", "A small boost to every stat.", "Memories and unknown Data come more often.", "Moving at full speed empowers processing."}};
    private static final float[] PERK_AT = {0.25f, 0.45f, 0.65f, 0.85f};
    private static final String[] DISC = {"Data is memory.", "The AI remembers other timelines.", "Its personality is yours.", "It knows what has not happened yet.",
            "The timelines are connected.", "Someone called the Operator.", "A loop with no beginning."};
    private static final long[] DISC_F = {Defs.D_DATA, Defs.D_PAST, Defs.D_SHAPED, Defs.D_FUTURE, Defs.D_CONNECTED, Defs.D_CREATOR, Defs.D_LOOP};
    private final String[][] cache = new String[Memories.N][];
    private float cacheW;
    private final String[] words = new String[3];

    MindTab(App app, HubScreen hub) { super(app, hub); }

    private static String word(float v, String lo, String mid, String hi) { return v < 0.3f ? lo : (v < 0.6f ? mid : hi); }

    @Override void draw(Canvas c, float x, float y, float w, float h, float scroll) {
        Gfx g = app.gfx;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, cx = x + w * 0.5f, yy = y - scroll + 8f * dp;
        app.refreshIdeology();
        float[] s = app.ideo;
        // ideology diamond
        float R = 78f * dp, gy = yy + R + 24f * dp;
        float[] vx = {0f, R, -R, 0f}, vy = {-R, 0f, 0f, R};   // protector, evil, rational, neutral
        int[] order = {0, 1, 3, 2};
        for (int i = 0; i < 4; i++) {
            int a = order[i], b = order[(i + 1) % 4];
            g.seg(c, cx + vx[a], gy + vy[a], cx + vx[b], gy + vy[b], 1.3f * dp, Gfx.alpha(th.text, 90));
        }
        g.seg(c, cx - R, gy, cx + R, gy, dp, Gfx.alpha(th.text, 24));
        g.seg(c, cx, gy - R, cx, gy + R, dp, Gfx.alpha(th.text, 24));
        float px = 0, py = 0, sum = 0.0001f;
        for (int i = 0; i < 4; i++) { px += vx[i] * s[i]; py += vy[i] * s[i]; sum += s[i]; }
        for (int i = 0; i < 4; i++) {
            g.circle(c, cx + vx[i], gy + vy[i], (3f + 6f * s[i]) * dp, Gfx.alpha(th.accent, 70 + (int) (150 * s[i])));
            float ly = vy[i] + (vy[i] < 0 ? -12f * dp : (vy[i] > 0 ? 22f * dp : 4f * dp));
            float lx = vx[i] + (vx[i] < 0 ? -10f * dp : (vx[i] > 0 ? 10f * dp : 0f));
            g.tracked(c, Defs.I_NAMES[i].toUpperCase(), cx + lx, gy + ly, 9.5f, 0.15f, Gfx.alpha(th.text, 170), vx[i] < 0 ? Paint.Align.RIGHT : (vx[i] > 0 ? Paint.Align.LEFT : Paint.Align.CENTER), g.cond);
        }
        float mx = cx + px / sum, my = gy + py / sum;
        g.glow(c, mx, my, 22f * dp, th.accent, 120);
        g.circle(c, mx, my, 5f * dp, th.text);
        g.ring(c, mx, my, 9f * dp, 1.2f * dp, Gfx.alpha(th.accent, 200));
        yy = gy + R + 50f * dp;
        g.tracked(c, "CURRENT IDEOLOGY", cx, yy, 9.5f, 0.3f, Gfx.alpha(th.text, 130), Paint.Align.CENTER, g.cond);
        g.text(c, Karma.label(s), cx, yy + 24f * dp, 20f, th.text, Paint.Align.CENTER, g.condB);
        int n = Karma.tendencies(pf, words);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) { if (i > 0) sb.append("  \u00b7  "); sb.append(words[i]); }
        g.tracked(c, "TENDENCIES", cx, yy + 52f * dp, 9.5f, 0.3f, Gfx.alpha(th.text, 130), Paint.Align.CENTER, g.cond);
        g.text(c, n == 0 ? "Undecided" : sb.toString(), cx, yy + 74f * dp, 14f, Gfx.alpha(th.text, 220), Paint.Align.CENTER, g.cond);
        yy += 110f * dp;
        // perks
        g.text(c, "Ideology perks", x, yy, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 20f * dp;
        boolean any = false;
        for (int i = 0; i < 4; i++) {
            for (int k = 0; k < 4; k++) {
                if (s[i] < PERK_AT[k]) continue;
                any = true;
                g.text(c, PERK_NAME[i][k], x, yy + 4f * dp, 13.5f, th.accent, Paint.Align.LEFT, g.condB);
                g.text(c, PERK_DESC[i][k], x, yy + 21f * dp, 12f, Gfx.alpha(th.text, 160), Paint.Align.LEFT, g.cond);
                yy += 40f * dp;
            }
        }
        if (!any) { g.text(c, "None yet. Your choices shape the AI.", x, yy + 6f * dp, 12.5f, Gfx.alpha(th.text, 140), Paint.Align.LEFT, g.cond); yy += 28f * dp; }
        yy += 14f * dp;
        // relationship
        g.text(c, "Relationship", x, yy, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 14f * dp;
        float[] rv = {pf.trust, pf.bond, pf.indep};
        String[] rl = {"Trust", "Bond", "Independence"};
        String[] rw = {word(pf.trust, "guarded", "cautious", "trusting"), word(pf.bond, "distant", "attached", "inseparable"), word(pf.indep, "obedient", "questioning", "self-willed")};
        for (int i = 0; i < 3; i++) {
            g.text(c, rl[i], x, yy + 14f * dp, 13f, Gfx.alpha(th.text, 200), Paint.Align.LEFT, g.cond);
            g.text(c, rw[i], x + w, yy + 14f * dp, 12f, Gfx.alpha(th.text, 140), Paint.Align.RIGHT, g.cond);
            g.rectFill(c, x, yy + 22f * dp, w, 2f * dp, Gfx.alpha(th.text, 28));
            g.rectFill(c, x, yy + 22f * dp, w * rv[i], 2f * dp, th.accent);
            yy += 38f * dp;
        }
        yy += 10f * dp;
        // discoveries
        g.text(c, "Discoveries", x, yy, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 18f * dp;
        for (int i = 0; i < DISC.length; i++) {
            boolean f = pf.flag(DISC_F[i]);
            g.text(c, f ? DISC[i] : "???", x, yy + 6f * dp, 13f, f ? Gfx.alpha(th.text, 220) : Gfx.alpha(th.text, 70), Paint.Align.LEFT, g.cond);
            yy += 22f * dp;
        }
        yy += 8f * dp;
        StringBuilder es = new StringBuilder();
        for (int i = 0; i < Defs.E_N; i++) if ((pf.endings & (1 << i)) != 0) { if (es.length() > 0) es.append(", "); es.append(Defs.E_NAMES[i]); }
        g.text(c, "Endings seen: " + (es.length() == 0 ? "none" : es.toString()), x, yy + 6f * dp, 12.5f, Gfx.alpha(th.text, 160), Paint.Align.LEFT, g.cond);
        yy += 36f * dp;
        // memories
        g.text(c, "Memories  " + pf.memCount() + "/" + Memories.N, x, yy, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 22f * dp;
        if (cacheW != w) { cacheW = w; for (int i = 0; i < cache.length; i++) cache[i] = null; }
        for (int i = 0; i < Memories.N; i++) {
            if (!pf.hasMem(i)) continue;
            if (cache[i] == null) cache[i] = wrap(Memories.BODY[i], w, 12.5f, g.serifI);
            float eh = 22f * dp + cache[i].length * 17f * dp + 12f * dp;
            if (yy + eh > y - 20f && yy < y + h + 20f) {
                g.text(c, Memories.TITLE[i], x, yy + 4f * dp, 14f, th.data2, Paint.Align.LEFT, g.condB);
                for (int k = 0; k < cache[i].length; k++) g.text(c, cache[i][k], x, yy + 24f * dp + k * 17f * dp, 12.5f, Gfx.alpha(th.text, 200), Paint.Align.LEFT, g.serifI);
            }
            yy += eh;
        }
        int locked = Memories.N - pf.memCount();
        if (locked > 0) { g.text(c, locked + " memories still sealed.", x, yy + 6f * dp, 12.5f, Gfx.alpha(th.text, 100), Paint.Align.LEFT, g.cond); yy += 30f * dp; }
        yy += 20f * dp;
        contentH = yy + scroll - y;
    }

    @Override void click(int id) {}
}
