package com.neuralfeed.audio;

import android.content.Context;
import android.media.AudioAttributes;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import java.util.Locale;
import java.util.Set;

/**
 * Spoken AI lines through the system text-to-speech engine. The caller pitches the voice down and slows it a little
 * so it sounds like a machine mind. Everything fails quietly: with no engine or no voice data {@link #available()} stays
 * false and the game keeps using its synthesized blips.
 */
public final class Speech implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private volatile boolean ready, failed, speaking;
    private volatile String lastId = "";
    private long startedAt;
    private float estimate;
    private int seq;
    // a line asked for before the engine finished starting
    private String pendingText;
    private float pendingPitch, pendingRate, pendingVol;

    public Speech(Context ctx) {
        try { tts = new TextToSpeech(ctx.getApplicationContext(), this); }
        catch (Throwable e) { tts = null; failed = true; }
    }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) { failed = true; return; }
        try {
            int r = tts.setLanguage(Locale.US);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                r = tts.setLanguage(Locale.getDefault());
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { failed = true; return; }
            }
            tts.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            pickVoice();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { if (id != null && id.equals(lastId)) speaking = false; }
                @Override @SuppressWarnings("deprecation") public void onError(String id) { if (id != null && id.equals(lastId)) speaking = false; }
                @Override public void onError(String id, int code) { onError(id); }
            });
            ready = true;
        } catch (Throwable e) { failed = true; return; }
        if (pendingText != null) { String t = pendingText; pendingText = null; speak(t, pendingPitch, pendingRate, pendingVol); }
    }

    /** Prefers an offline English voice (the game works without a connection), male-sounding ones first. */
    private void pickVoice() {
        try {
            Set<Voice> vs = tts.getVoices();
            if (vs == null) return;
            Voice best = null;
            int bestScore = -1;
            for (Voice v : vs) {
                Locale l = v.getLocale();
                if (l == null || !"en".equals(l.getLanguage()) || v.isNetworkConnectionRequired()) continue;
                Set<String> f = v.getFeatures();
                if (f != null && f.contains("notInstalled")) continue;
                String n = v.getName() == null ? "" : v.getName().toLowerCase(Locale.US);
                int score = v.getQuality() + (Locale.US.equals(l) ? 60 : 0) + (n.contains("male") && !n.contains("female") ? 40 : 0);
                if (score > bestScore) { best = v; bestScore = score; }
            }
            if (best != null) tts.setVoice(best);
        } catch (Throwable ignored) { }
    }

    /** True once the engine has started and a usable voice is set. */
    public boolean available() { return ready && !failed; }

    /** True while a line is playing (guarded by a timeout in case the engine never reports completion). */
    public boolean speaking() {
        if (speaking && System.nanoTime() / 1_000_000L - startedAt > estimate) speaking = false;
        return speaking;
    }

    public void speak(String text, float pitch, float rate, float volume) {
        if (failed || text == null || text.length() == 0) return;
        if (!ready) { pendingText = text; pendingPitch = pitch; pendingRate = rate; pendingVol = volume; return; }
        try {
            tts.setPitch(pitch);
            tts.setSpeechRate(rate);
            Bundle b = new Bundle();
            b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Math.max(0f, Math.min(1f, volume)));
            String id = "ai" + (++seq);
            lastId = id;
            startedAt = System.nanoTime() / 1_000_000L;
            estimate = 2500f + text.length() * 120f / Math.max(0.5f, rate);
            speaking = true;
            if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, b, id) != TextToSpeech.SUCCESS) speaking = false;
        } catch (Throwable e) { speaking = false; }
    }

    public void stop() {
        speaking = false;
        pendingText = null;
        try { if (tts != null && ready) tts.stop(); } catch (Throwable ignored) { }
    }

    public void shutdown() {
        speaking = false; ready = false;
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Throwable ignored) { }
        tts = null;
    }
}
