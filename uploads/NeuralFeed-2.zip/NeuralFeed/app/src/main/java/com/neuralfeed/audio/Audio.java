package com.neuralfeed.audio;

import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Defs;

/** Facade used by the game: sound effects with suppression/stacking rules, voice, hum and dynamic music state. */
public final class Audio {
    private final Mixer mixer = new Mixer();
    private SfxBank bank;
    private VoiceBank voices;
    private volatile boolean ready;
    private final float[] last = new float[Sfx.COUNT];
    private final float[] minInt = new float[Sfx.COUNT];
    private float clock;
    private int perFrame;

    public Audio() {
        for (int i = 0; i < Sfx.COUNT; i++) minInt[i] = 0.04f;
        minInt[Sfx.KILL] = 0.06f; minInt[Sfx.TICK1] = 0.07f; minInt[Sfx.TICK2] = 0.07f; minInt[Sfx.TICK3] = 0.07f;
        for (int i = 0; i < 10; i++) minInt[Sfx.PICK0 + i] = 0.028f;
        minInt[Sfx.CASCADE] = 0.5f; minInt[Sfx.HIT] = 0.12f; minInt[Sfx.BOSS_HIT] = 0.2f; minInt[Sfx.BOSS_WARN] = 0.15f;
        minInt[Sfx.UI_TAP] = 0.05f; minInt[Sfx.TIER_UP] = 0.3f; minInt[Sfx.SHIELD_BREAK] = 0.3f; minInt[Sfx.LOCK] = 0.4f;
    }

    /** Builds all sounds on a background thread, then starts the mixer. */
    public void init(final Profile p) {
        applySettings(p);
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                bank = new SfxBank();
                voices = new VoiceBank();
                ready = true;
                mixer.start();
            }
        }, "nf-synth");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        t.setDaemon(true);
        t.start();
    }

    /** Test hook: build banks synchronously without starting an AudioTrack. */
    public void initSync() { bank = new SfxBank(); voices = new VoiceBank(); ready = true; }

    public void renderForTest(short[] out, int n) { mixer.render(out, n); }

    public void applySettings(Profile p) {
        mixer.master = p.vMaster; mixer.musicVol = p.vMusic; mixer.sfxVol = p.vSfx; mixer.voiceVol = p.vVoice;
    }

    public void update(float dt) { clock += dt; perFrame = 0; }

    public void sfx(int id, float vol) { sfx(id, vol, 1f); }

    public void sfx(int id, float vol, float pitch) {
        if (!ready || id < 0 || id >= Sfx.COUNT) return;
        if (clock - last[id] < minInt[id] || perFrame >= 6) return;
        last[id] = clock; perFrame++;
        mixer.play(bank.get(id), vol, pitch, Mixer.BUS_SFX);
    }

    /** Pickups form an ascending musical pattern while chained; rarer types get their own voice. */
    public void pick(int type, int chain) {
        if (!ready) return;
        switch (type) {
            case Defs.O_RARE: sfx(Sfx.PICK_RARE, 0.8f); break;
            case Defs.O_UNK: sfx(Sfx.PICK_UNK, 0.9f); break;
            case Defs.O_CORR: sfx(Sfx.PICK_BAD, 0.7f); break;
            case Defs.O_COMP: sfx(Sfx.PICK_M, 0.6f, 1f + 0.02f * Math.min(chain, 10)); break;
            default: sfx(Sfx.PICK0 + Math.min(9, chain / 2), 0.55f); break;
        }
    }

    public void speak(int stage, int tone, int variant) {
        if (!ready) return;
        mixer.play(voices.get(stage, tone, variant), 0.7f, 1f, Mixer.BUS_VOICE);
    }

    public void field(float energy) { mixer.humLevel = 0.4f + 0.6f * energy; mixer.humEnergy = energy; }

    public void music(float intensity, float danger, float boss, float paradox, float minimal, float decon, float timeScale) {
        Music m = mixer.music;
        m.tInt = intensity; m.tDanger = danger; m.tBoss = boss; m.tPara = paradox; m.tMinimal = minimal; m.tDecon = decon; m.timeScale = timeScale;
    }

    /** Dips the music and hum while a spoken line plays so it stays clear. */
    public void duck(boolean speaking) { mixer.duck = speaking ? 0.35f : 1f; }
    public void musicRoot(int semis) { mixer.music.root = semis; }
    public void pause() { mixer.setPaused(true); }
    public void resume() { mixer.setPaused(false); }
    public void release() { mixer.stop(); }
}
