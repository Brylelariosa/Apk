package com.neuralfeed.game;

import com.neuralfeed.core.Mx;
import com.neuralfeed.core.Rng;
import com.neuralfeed.meta.Defs;

/** Procedurally generated arena: bounds, obstacles, hazards, nests, vaults, memory fragments and a hidden chamber. */
public final class Arena {
    public static final int MC = 56, MR = 24, MZ = 6, MN = 4, MV = 3, MM = 3, MD = 6, MB = 10;

    public float W, H, spawnX, spawnY, bossX, bossY;
    public int nc;
    public final float[] cx = new float[MC], cy = new float[MC], cr = new float[MC];
    public int nr;
    public final float[] rx = new float[MR], ry = new float[MR], rw = new float[MR], rh = new float[MR];
    public int nz;
    public final float[] zx = new float[MZ], zy = new float[MZ], zr = new float[MZ], zt = new float[MZ];
    public int nn;
    public final float[] nx = new float[MN], ny = new float[MN];
    public int nv;
    public final float[] vx = new float[MV], vy = new float[MV], vp = new float[MV];
    public final boolean[] vdone = new boolean[MV];
    public int nm;
    public final float[] mx = new float[MM], my = new float[MM];
    public final boolean[] mgot = new boolean[MM];
    public int nd;
    public final float[] dfx = new float[MD], dfy = new float[MD], dfr = new float[MD], dft = new float[MD];
    public boolean hidden;
    public float hx, hy, hr = 2.4f;
    public final float[] bx = new float[MB], by = new float[MB], br = new float[MB], bt = new float[MB];
    public float outX, outY;
    private float px, py;

    /** A small sealed sector: just big enough that you have to search it for Data in the dark. */
    public void generate(Rng r, int kind, int tier) {
        nc = nr = nz = nn = nv = nm = nd = 0;
        hidden = false;
        for (int i = 0; i < MB; i++) bt[i] = 0;
        boolean boss = kind == Defs.RUN_BOSS;
        if (boss) { W = 22f; H = 30f; } else { W = 20f; H = 28f; }
        spawnX = W * 0.5f; spawnY = H * 0.8f; bossX = W * 0.5f; bossY = H * 0.24f;

        int circles = boss ? 3 : 6 + r.i(3);
        for (int i = 0; i < circles && nc < MC - 12; i++) {
            for (int t = 0; t < 20; t++) {
                float rad = r.range(0.5f, 1.2f), x = r.range(2f, W - 2f), y = r.range(2f, H - 2f);
                if (Mx.len(x - spawnX, y - spawnY) < rad + 4f) continue;
                if (boss && Mx.len(x - bossX, y - bossY) < rad + 5f) continue;
                if (!freeSpot(x, y, rad + 0.9f)) continue;
                cx[nc] = x; cy[nc] = y; cr[nc] = rad; nc++;
                break;
            }
        }
        int walls = boss ? 0 : 2 + r.i(2);
        for (int i = 0; i < walls && nr < MR; i++) {
            for (int t = 0; t < 20; t++) {
                boolean horiz = r.chance(0.5f);
                float len = r.range(3.5f, 6f), th = 0.6f;
                float w = horiz ? len : th, h = horiz ? th : len;
                float x = r.range(2f, W - 2f - w), y = r.range(4f, H - 4f - h);
                if (rectDist(x, y, w, h, spawnX, spawnY) < 5f) continue;
                if (!freeSpot(x + w * 0.5f, y + h * 0.5f, Math.max(w, h) * 0.5f + 0.4f)) continue;
                rx[nr] = x; ry[nr] = y; rw[nr] = w; rh[nr] = h; nr++;
                break;
            }
        }
        if (!boss && r.chance(0.3f) && pick(r, 4f, 7f)) {
            hidden = true; hx = px; hy = py;
            for (int k = 1; k < 8 && nc < MC; k++) {
                float a = k * Mx.TAU / 8f;
                cx[nc] = hx + Mx.cos(a) * hr; cy[nc] = hy + Mx.sin(a) * hr; cr[nc] = 0.6f; nc++;
            }
            mx[0] = hx; my[0] = hy; mgot[0] = false; nm = 1;
        }
        int dfs = boss ? 2 : 4 + r.i(2);
        for (int i = 0; i < dfs && nd < MD; i++) {
            if (pick(r, 2.5f, 3f)) { dfx[nd] = px; dfy[nd] = py; dfr[nd] = r.range(1.1f, 1.8f); dft[nd] = r.range(4f, 9f); nd++; }
        }
        int vaults = boss ? 0 : 1 + (r.chance(0.5f) ? 1 : 0);
        for (int i = 0; i < vaults && nv < MV; i++) {
            if (pick(r, 3f, 6f)) { vx[nv] = px; vy[nv] = py; vp[nv] = 0; vdone[nv] = false; nv++; }
        }
        if (!boss && nm < MM && r.chance(0.4f) && pick(r, 3f, 6f)) { mx[nm] = px; my[nm] = py; mgot[nm] = false; nm++; }
        int zones = !boss && r.chance(0.3f + 0.05f * tier) ? 1 : 0;
        for (int i = 0; i < zones && nz < MZ; i++) {
            if (pick(r, 3.5f, 7f)) { zx[nz] = px; zy[nz] = py; zr[nz] = r.range(2.2f, 3f); zt[nz] = r.range(1f, 3f); nz++; }
        }
        int nests = !boss && tier >= 1 && r.chance(0.35f) ? 1 : 0;
        for (int i = 0; i < nests && nn < MN; i++) {
            if (pick(r, 3f, 8f)) { nx[nn] = px; ny[nn] = py; nn++; }
        }
    }

    /** Timeline 0: an empty void with nothing in it. */
    public void generateVoid() {
        nc = nr = nz = nn = nv = nm = nd = 0;
        hidden = false;
        for (int i = 0; i < MB; i++) bt[i] = 0;
        W = 14f; H = 30f; spawnX = W * 0.5f; spawnY = H * 0.85f; bossX = W * 0.5f; bossY = H * 0.15f;
    }

    /** Random free position at least minSpawn from the spawn point; result in px/py. */
    private boolean pick(Rng r, float margin, float minSpawn) {
        for (int t = 0; t < 24; t++) {
            float x = r.range(margin, W - margin), y = r.range(margin, H - margin);
            if (Mx.len(x - spawnX, y - spawnY) < minSpawn) continue;
            if (!freeSpot(x, y, 1.6f)) continue;
            px = x; py = y;
            return true;
        }
        return false;
    }

    private boolean freeSpot(float x, float y, float rad) {
        for (int i = 0; i < nc; i++) if (Mx.len(x - cx[i], y - cy[i]) < rad + cr[i]) return false;
        for (int i = 0; i < nr; i++) if (rectDist(rx[i], ry[i], rw[i], rh[i], x, y) < rad) return false;
        return true;
    }

    public static float rectDist(float x, float y, float w, float h, float qx, float qy) {
        float cxp = Mx.clamp(qx, x, x + w), cyp = Mx.clamp(qy, y, y + h);
        return Mx.len(qx - cxp, qy - cyp);
    }

    public void update(float dt) { for (int i = 0; i < MB; i++) if (bt[i] > 0) bt[i] -= dt; }

    public void addBarrier(float x, float y, float rad, float life) {
        int s = 0;
        for (int i = 0; i < MB; i++) { if (bt[i] <= 0) { s = i; break; } if (bt[i] < bt[s]) s = i; }
        bx[s] = x; by[s] = y; br[s] = rad; bt[s] = life;
    }

    /** Pushes a circle out of walls/obstacles/barriers. Result in outX/outY; returns true if it moved. */
    public boolean resolve(float x, float y, float r, boolean useBarriers) {
        boolean hit = false;
        if (x < r) { x = r; hit = true; } else if (x > W - r) { x = W - r; hit = true; }
        if (y < r) { y = r; hit = true; } else if (y > H - r) { y = H - r; hit = true; }
        for (int i = 0; i < nc; i++) {
            float dx = x - cx[i], dy = y - cy[i], rr = r + cr[i], d2 = dx * dx + dy * dy;
            if (d2 < rr * rr) {
                float d = Mx.sqrt(d2);
                if (d < 1e-4f) { dx = 1f; dy = 0f; d = 1f; }
                x = cx[i] + dx / d * rr; y = cy[i] + dy / d * rr; hit = true;
            }
        }
        if (useBarriers) {
            for (int i = 0; i < MB; i++) {
                if (bt[i] <= 0) continue;
                float dx = x - bx[i], dy = y - by[i], rr = r + br[i], d2 = dx * dx + dy * dy;
                if (d2 < rr * rr) {
                    float d = Mx.sqrt(d2);
                    if (d < 1e-4f) { dx = 1f; dy = 0f; d = 1f; }
                    x = bx[i] + dx / d * rr; y = by[i] + dy / d * rr; hit = true;
                }
            }
        }
        for (int i = 0; i < nr; i++) {
            float x0 = rx[i], y0 = ry[i], x1 = x0 + rw[i], y1 = y0 + rh[i];
            if (x < x0 - r || x > x1 + r || y < y0 - r || y > y1 + r) continue;
            float qx = Mx.clamp(x, x0, x1), qy = Mx.clamp(y, y0, y1);
            float dx = x - qx, dy = y - qy, d2 = dx * dx + dy * dy;
            if (d2 >= r * r) continue;
            hit = true;
            if (d2 > 1e-8f) {
                float d = Mx.sqrt(d2);
                x = qx + dx / d * r; y = qy + dy / d * r;
            } else {
                float l = x - x0, rt = x1 - x, t = y - y0, b = y1 - y;
                float m = Mx.min(Mx.min(l, rt), Mx.min(t, b));
                if (m == l) x = x0 - r; else if (m == rt) x = x1 + r; else if (m == t) y = y0 - r; else y = y1 + r;
            }
        }
        outX = x; outY = y;
        return hit;
    }
}
