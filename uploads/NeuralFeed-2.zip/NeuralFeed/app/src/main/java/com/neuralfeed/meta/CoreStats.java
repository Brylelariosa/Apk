package com.neuralfeed.meta;

/** Resolved AI statistics (permanent part). World applies temporary buffs on a copy. */
public final class CoreStats {
    public float power, rate, range, collect, runTime, barrier, barrierRegen, speed, dashCd, dataMult, crit, critMul, magnet;
    public float deep, edge, pressure, cascade, haste, potency;
    /** Finder: simultaneous locks, vision radius, scan ping interval. */
    public int locks, patchEvery;
    public float vision, scanCd, hitMul, timeKill, rare;
    // ideology perks
    public float dmgRed, timePerOrb, harvest, devourThr, dominate, chainShare, observe;
    public boolean guardian, predict, calculate, adaptive, execute, steal, chain, friendGuard;
    public int level;
    public float[] ideo = new float[4];

    public void copyFrom(CoreStats o) {
        power = o.power; rate = o.rate; range = o.range; collect = o.collect; runTime = o.runTime; barrier = o.barrier;
        barrierRegen = o.barrierRegen; speed = o.speed; dashCd = o.dashCd; dataMult = o.dataMult; crit = o.crit;
        critMul = o.critMul; magnet = o.magnet; deep = o.deep; edge = o.edge; pressure = o.pressure; cascade = o.cascade;
        haste = o.haste; potency = o.potency; locks = o.locks; patchEvery = o.patchEvery;
        vision = o.vision; scanCd = o.scanCd; hitMul = o.hitMul; timeKill = o.timeKill; rare = o.rare;
        dmgRed = o.dmgRed; timePerOrb = o.timePerOrb;
        harvest = o.harvest; devourThr = o.devourThr; dominate = o.dominate; chainShare = o.chainShare; observe = o.observe;
        guardian = o.guardian; predict = o.predict; calculate = o.calculate; adaptive = o.adaptive; execute = o.execute;
        steal = o.steal; chain = o.chain; friendGuard = o.friendGuard; level = o.level;
        System.arraycopy(o.ideo, 0, ideo, 0, 4);
    }
}
