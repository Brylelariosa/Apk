package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Fmt;
import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Upgrades;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** The skill tree: permanent upgrades bought with Data, laid out as three branches that grow out of the core. */
final class CoreTab extends Tab {
    private static final int ID_DEAD = 299, ID_BUY = 300, ID_NODE = 400;
    private int mode;   // 0 x1, 1 x10, 2 max
    private int sel = Defs.UP_POWER;
    private String[] descLines;
    private int descFor = -1;
    private float descW;

    CoreTab(App app, HubScreen hub) { super(app, hub); }

    private int want() { return mode == 0 ? 1 : (mode == 1 ? 10 : 999); }

    @Override void draw(Canvas c, float x, float y, float w, float h, float scroll) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp, yy = y - scroll + 4f * dp;
        String[] ml = {"x1", "x10", "MAX"};
        float bw = 56f * dp;
        for (int i = 0; i < 3; i++) {
            float bx = x + w - (3 - i) * (bw + 6f * dp) + 6f * dp;
            if (vis(yy, 34f * dp, y, h)) ui.button(c, 201 + i, ml[i], bx, yy, bw, 32f * dp, true, mode == i ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
        }
        g.text(c, "Skill tree", x, yy + 21f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 46f * dp;
        yy = tree(c, g, ui, th, pf, x, y, w, h, yy);
        // process modes
        yy += 8f * dp;
        g.text(c, "Process modes", x, yy + 12f * dp, 15f, th.text, Paint.Align.LEFT, g.condB);
        yy += 28f * dp;
        double cost = Upgrades.modeCost(pf.timeline);
        for (int k = 1; k <= 2; k++) {
            boolean un = (pf.wideUnlock & k) != 0;
            String nm = k == 1 ? "Wide process" : "Condensed process";
            String ds = k == 1 ? "Larger lock radius, lower power." : "Smaller lock radius, much higher power.";
            g.text(c, nm, x, yy + 18f * dp, 15.5f, th.text, Paint.Align.LEFT, g.condB);
            g.text(c, ds, x, yy + 38f * dp, 12.5f, Gfx.alpha(th.text, 150), Paint.Align.LEFT, g.cond);
            String lab = un ? (pf.wide == k ? "ACTIVE" : "ACTIVATE") : Fmt.num(cost);
            boolean en = un || pf.bank >= cost;
            if (vis(yy, 60f * dp, y, h)) ui.button(c, 239 + k, lab, x + w - 100f * dp, yy + 8f * dp, 100f * dp, 46f * dp, en, (un && pf.wide == k) ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
            yy += 68f * dp;
        }
        yy += 136f * dp;   // room for the pinned detail card
        contentH = yy + scroll - y;
        card(c, g, ui, th, pf, x, y, w, h);   // last, so it sits on top of everything and takes taps first
    }

    private int branchColor(Theme th, int branch) { return branch == Upgrades.B_FINDER ? th.accent : (branch == Upgrades.B_HARVEST ? th.data : 0xFF7CF2A8); }

    /** Draws the branching tree and returns the y below it. Nodes register as buttons so a tap selects them. */
    private float tree(Canvas c, Gfx g, Ui ui, Theme th, Profile pf, float x, float y, float w, float h, float top) {
        float dp = g.dp, unit = w / Upgrades.WIDTH, rowH = 80f * dp, r = Mx.min(22f * dp, unit * 0.36f);
        float oy = top + 26f * dp;
        float rx = x + Upgrades.ROOT_X * unit, ry = oy + Upgrades.ROOT_Y * rowH;
        // connections first, so the nodes sit on top of them
        for (Upgrades.Up u : Upgrades.ALL) {
            float nx = x + u.x * unit, ny = oy + u.y * rowH;
            int col = branchColor(th, u.branch);
            if (u.pre.length == 0) {
                g.seg(c, rx, ry, nx, ny, 1.6f * dp, Gfx.alpha(col, 150));
                continue;
            }
            for (int[] p : u.pre) {
                Upgrades.Up q = Upgrades.ALL[p[0]];
                boolean met = pf.up[q.id] >= p[1];
                g.seg(c, x + q.x * unit, oy + q.y * rowH, nx, ny, (met ? 2.2f : 1.2f) * dp, Gfx.alpha(met ? col : th.text, met ? 190 : 40));
            }
        }
        // the core at the root
        g.circle(c, rx, ry, r * 0.8f, th.bg);
        g.ring(c, rx, ry, r * 0.8f, 2f * dp, Gfx.alpha(th.accent, 220));
        g.circle(c, rx, ry, r * 0.3f, th.accent);
        float pulse = 0.5f + 0.5f * Mx.sin(app.time * 4f);
        int lvl = pf.level();
        for (Upgrades.Up u : Upgrades.ALL) {
            float nx = x + u.x * unit, ny = oy + u.y * rowH;
            if (ny + r + 16f * dp < y - 4f * dp || ny - r > y + h + 4f * dp) continue;
            int lv = pf.up[u.id];
            boolean open = Upgrades.unlocked(u, pf), maxed = lv >= u.max, owned = lv > 0;
            boolean afford = open && !maxed && pf.bank >= u.cost(lv);
            int col = branchColor(th, u.branch);
            g.circle(c, nx, ny, r, th.bg);
            g.ring(c, nx, ny, r, (owned ? 2.2f : 1.5f) * dp, open || owned ? Gfx.alpha(col, owned ? 255 : 170) : Gfx.alpha(th.text, 55));
            if (owned) g.arc(c, nx, ny, r - 4f * dp, -90f, 360f * Mx.min(1f, lv / (float) u.max), 3f * dp, Gfx.alpha(col, maxed ? 255 : 210));
            if (maxed) g.circle(c, nx, ny, r - 7f * dp, Gfx.alpha(col, 70));
            g.text(c, u.tag, nx, ny + 4f * dp, 10.5f, open || owned ? th.text : Gfx.alpha(th.text, 90), Paint.Align.CENTER, g.condB);
            g.text(c, lv + "/" + u.max, nx, ny + r + 12f * dp, 9f, Gfx.alpha(th.text, open || owned ? 170 : 80), Paint.Align.CENTER, g.cond);
            if (u.id == sel) g.ring(c, nx, ny, r + 6f * dp, 1.4f * dp, Gfx.alpha(0xFFFFFFFF, 220));
            if (afford) g.circle(c, nx + r * 0.78f, ny - r * 0.78f, (3.4f + 1.2f * pulse) * dp, th.data);   // a gold dot: you can buy this now
            if (vis(ny - r, 2f * r, y, h)) ui.button(c, ID_NODE + u.id, "", nx - r, ny - r, 2f * r, 2f * r, true, Ui.ST_QUIET, 0x00000000, 0x00000000, th.bg);
        }
        float bottom = oy + (Upgrades.ROWS + 0.62f) * rowH;
        float[] bx = {1.0f, 3.0f, 5.0f};
        for (int b = 0; b < 3; b++) {
            g.tracked(c, Upgrades.BRANCH[b], x + bx[b] * unit, bottom, 10f, 0.25f, branchColor(th, b), Paint.Align.CENTER, g.condB);
            g.text(c, Upgrades.BRANCH_DESC[b], x + bx[b] * unit, bottom + 14f * dp, 9.5f, Gfx.alpha(th.text, 120), Paint.Align.CENTER, g.cond);
        }
        return bottom + 34f * dp;
    }

    /** The detail card pinned to the bottom of the tab: what the selected node does, what it needs, and the buy button. */
    private void card(Canvas c, Gfx g, Ui ui, Theme th, Profile pf, float x, float y, float w, float h) {
        float dp = g.dp, ch = 118f * dp, cy = y + h - ch;
        Upgrades.Up u = Upgrades.ALL[sel];
        int lv = pf.up[u.id], col = branchColor(th, u.branch);
        g.rrect(c, x - 6f * dp, cy, w + 12f * dp, ch + 6f * dp, 12f * dp, Gfx.alpha(th.bg, 255));
        g.rrectLine(c, x - 6f * dp, cy, w + 12f * dp, ch + 6f * dp, 12f * dp, 1.2f * dp, Gfx.alpha(col, 180));
        ui.button(c, ID_DEAD, "", x - 6f * dp, cy, w + 12f * dp, ch, true, Ui.ST_QUIET, 0x00000000, 0x00000000, th.bg);
        g.text(c, u.name, x + 8f * dp, cy + 24f * dp, 17f, th.text, Paint.Align.LEFT, g.condB);
        g.text(c, "LV " + lv + "/" + u.max, x + w - 8f * dp, cy + 24f * dp, 12f, Gfx.alpha(col, 230), Paint.Align.RIGHT, g.condB);
        if (descFor != sel || descW != w) { descFor = sel; descW = w; descLines = wrap(u.desc, w - 16f * dp, 12.5f, g.cond); }
        float ty = cy + 44f * dp;
        for (int i = 0; i < descLines.length && i < 2; i++) { g.text(c, descLines[i], x + 8f * dp, ty, 12.5f, Gfx.alpha(th.text, 175), Paint.Align.LEFT, g.cond); ty += 16f * dp; }
        String why = Upgrades.lockReason(u, pf);
        boolean maxed = lv >= u.max;
        float by = cy + ch - 46f * dp;
        if (why != null && !maxed) {
            g.text(c, why, x + 8f * dp, by + 26f * dp, 12.5f, th.hostile, Paint.Align.LEFT, g.condB);
        } else if (!maxed) {
            int n = Upgrades.affordable(u, lv, pf.bank, want());
            boolean can = n > 0;
            String lab = can ? (n > 1 ? "BUY +" + n + "  " : "BUY  ") + Fmt.num(Upgrades.costMany(u, lv, n)) : "NEED " + Fmt.num(u.cost(lv));
            ui.button(c, ID_BUY, lab, x + w - 168f * dp, by, 168f * dp, 40f * dp, can, can ? Ui.ST_PRIMARY : Ui.ST_NORMAL, th.accent, th.text, th.bg);
        } else {
            g.text(c, "MAXED", x + w - 8f * dp, by + 26f * dp, 14f, col, Paint.Align.RIGHT, g.condB);
        }
    }

    @Override void click(int id) {
        Profile pf = app.pf;
        if (id >= 201 && id <= 203) { mode = id - 201; app.tap(); return; }
        if (id == 240 || id == 241) {
            int k = id - 239;
            if ((pf.wideUnlock & k) != 0) { pf.wide = pf.wide == k ? 0 : k; app.audio.sfx(Sfx.UI_BUY, 0.8f); }
            else {
                double cost = Upgrades.modeCost(pf.timeline);
                if (pf.bank >= cost) { pf.bank -= cost; pf.wideUnlock |= k; pf.wide = k; app.audio.sfx(Sfx.UI_BUY, 1f); }
                else app.audio.sfx(Sfx.UI_DENY, 0.8f);
            }
            app.saveNow();
            return;
        }
        if (id >= ID_NODE && id < ID_NODE + Upgrades.ALL.length) { sel = id - ID_NODE; app.tap(); return; }
        if (id != ID_BUY) return;
        Upgrades.Up u = Upgrades.ALL[sel];
        if (!Upgrades.unlocked(u, pf)) { app.audio.sfx(Sfx.UI_DENY, 0.8f); return; }
        int n = Upgrades.affordable(u, pf.up[sel], pf.bank, want());
        if (n <= 0) { app.audio.sfx(Sfx.UI_DENY, 0.8f); return; }
        pf.bank -= Upgrades.costMany(u, pf.up[sel], n);
        pf.up[sel] += n;
        app.audio.sfx(Sfx.UI_BUY, 1f);
        app.saveNow();
    }
}
