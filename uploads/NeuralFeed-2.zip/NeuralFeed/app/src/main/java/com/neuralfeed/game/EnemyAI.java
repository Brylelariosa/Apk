package com.neuralfeed.game;

import com.neuralfeed.core.Mx;
import com.neuralfeed.meta.Defs;

/**
 * Per-kind enemy behaviour. Most mobile enemies have to find the core first: they wander the dark network until it comes within
 * their detection range (or something nearby gets hit), hunt it while they can sense it, then search where it was last seen.
 * Once an enemy is hunting, its own kind-specific behaviour takes over: some rush, some hover at the edge, some strike from outside.
 */
final class EnemyAI {
    private EnemyAI() {}

    private static float TX, TY;

    static void update(World w, float dt) {
        Enemy[] en = w.en;
        int hi = w.enHi;
        for (int i = 0; i < hi; i++) if (en[i].alive) en[i].prot = false;
        for (int i = 0; i < hi; i++) {
            Enemy s = en[i];
            if (!s.alive || s.kind != Kinds.SECURITY) continue;
            int n = w.grid.query(s.x, s.y, 3.4f, w.tmp2);
            for (int j = 0; j < n; j++) {
                Enemy o = en[w.tmp2[j]];
                if (o != s && o.alive && Mx.len(o.x - s.x, o.y - s.y) < 3.2f) o.prot = true;
            }
        }
        for (int i = 0; i < hi; i++) { Enemy e = en[i]; if (e.alive) step(w, e, dt); }
        separation(w, hi);
    }

    static void steer(Enemy e, float tx, float ty, float spd, float acc, float dt) {
        float dx = tx - e.x, dy = ty - e.y, d = Mx.len(dx, dy);
        if (d < 1e-4f) return;
        float a = Mx.min(1f, acc * dt);
        e.vx += (dx / d * spd - e.vx) * a;
        e.vy += (dy / d * spd - e.vy) * a;
    }

    private static void flee(Enemy e, float fx, float fy, float spd, float acc, float dt) {
        steer(e, e.x * 2f - fx, e.y * 2f - fy, spd, acc, dt);
    }

    private static void target(World w, Enemy e) {
        Player pl = w.pl;
        TX = pl.x; TY = pl.y;
        Enemy f = w.friend;
        if (f != null && f.alive && e.kind != Kinds.FRIEND) {
            float df = Mx.len(e.x - f.x, e.y - f.y), dp = Mx.len(e.x - pl.x, e.y - pl.y);
            if (df < 3.5f && df < dp * 0.9f) { TX = f.x; TY = f.y; }
        }
    }

    private static void step(World w, Enemy e, float dt) {
        if (e.flash > 0) e.flash -= dt;
        if (e.contactCd > 0) e.contactCd -= dt;
        if (e.conv > 0) e.conv -= dt;
        if (e.slowT > 0) e.slowT -= dt;
        if (e.phase > 0) e.phase -= dt;
        float edt = e.slowT > 0 ? dt * 0.25f : dt;
        e.rot += edt * (e.kind == Kinds.VIRUS ? 5f : 1.2f);
        if (e.kind == Kinds.BOSS) {
            BossAI.update(w, e, edt);
            integrate(w, e, edt);
            contact(w, e);
            return;
        }
        target(w, e);
        if (e.conv > 0) converted(w, e, edt);
        else if (searches(e.kind)) {
            if (hunting(w, e, edt)) behave(w, e, edt); else roam(w, e, edt);
        } else behave(w, e, edt);
        integrate(w, e, edt);
        contact(w, e);
    }

    // ------------------------------------------------------------------ awareness (enemy search)

    static final float HOLD = 3.5f, SEARCH_TIME = 5f, DETECT = 6.8f;

    /** Kinds that have to find the core before hunting it. */
    static boolean searches(int k) {
        return k == Kinds.DRONE || k == Kinds.VIRUS || k == Kinds.HUNTER || k == Kinds.CORRUPT || k == Kinds.SECURITY || k == Kinds.EATER;
    }

    private static float detectRange(World w, Enemy e) {
        float r = DETECT * (1f + 0.03f * Mx.min(20, w.run.threat));
        if (e.kind == Kinds.HUNTER) r *= 1.3f;
        else if (e.kind == Kinds.CORRUPT) r *= 1.2f;
        else if (e.kind == Kinds.SECURITY) r *= 0.9f;
        if (w.pl.dashT > 0f) r *= 1.4f;
        return r;
    }

    /** Puts an enemy straight into hunting mode (used for spawns, hits, noise). */
    static void alert(Enemy e) { e.aw = Enemy.AW_ALERT; e.awT = HOLD; }

    /** Wakes idle enemies near a point, e.g. after a kill. */
    static void alertNear(World w, float x, float y, float r) {
        int n = w.grid.query(x, y, r, w.tmp2);
        for (int i = 0; i < n; i++) {
            Enemy o = w.en[w.tmp2[i]];
            if (o.alive && o.aw != Enemy.AW_ALERT && searches(o.kind)) alert(o);
        }
    }

    /** Updates the awareness state; returns true while the enemy is actively hunting the core. */
    private static boolean hunting(World w, Enemy e, float dt) {
        Player pl = w.pl;
        float dx = pl.x - e.x, dy = pl.y - e.y, det = detectRange(w, e);
        boolean sees = dx * dx + dy * dy < det * det;
        if (e.aw == Enemy.AW_ALERT) {
            if (sees) { e.awT = HOLD; e.wx = pl.x; e.wy = pl.y; return true; }
            e.awT -= dt;
            if (e.awT > 0f) return true;
            e.aw = Enemy.AW_SEARCH; e.awT = SEARCH_TIME;
            return false;
        }
        if (sees) {
            boolean wasIdle = e.aw == Enemy.AW_IDLE;
            alert(e);
            e.wx = pl.x; e.wy = pl.y;
            if (wasIdle) alertNear(w, e.x, e.y, 3f);
            return true;
        }
        return false;
    }

    /** Idle wandering, or a sweep towards the last place the core was seen. */
    private static void roam(World w, Enemy e, float dt) {
        Arena ar = w.arena;
        if (e.aw == Enemy.AW_SEARCH) {
            steer(e, e.wx, e.wy, e.speed * 0.9f, 3f, dt);
            e.awT -= dt;
            if (e.awT <= 0f || Mx.len(e.wx - e.x, e.wy - e.y) < 0.9f) { e.aw = Enemy.AW_IDLE; e.awT = 0f; }
            return;
        }
        e.awT -= dt;
        if (e.awT <= 0f || Mx.len(e.wx - e.x, e.wy - e.y) < 0.7f) {
            e.wx = Mx.clamp(e.x + w.rng.range(-4.5f, 4.5f), 1f, ar.W - 1f);
            e.wy = Mx.clamp(e.y + w.rng.range(-4.5f, 4.5f), 1f, ar.H - 1f);
            e.awT = 2f + 2f * w.rng.f();
        }
        steer(e, e.wx, e.wy, e.speed * 0.45f, 2.5f, dt);
    }

    private static void integrate(World w, Enemy e, float dt) {
        e.x += (e.vx + e.kx) * dt;
        e.y += (e.vy + e.ky) * dt;
        float kd = Mx.exp(-5f * dt);
        e.kx *= kd; e.ky *= kd;
        Arena ar = w.arena;
        if (e.kind == Kinds.BOSS || e.kind == Kinds.ECHO || e.phase > 0 || Kinds.stationary(e.kind)) {
            e.x = Mx.clamp(e.x, e.r, ar.W - e.r);
            e.y = Mx.clamp(e.y, e.r, ar.H - e.r);
        } else if (ar.resolve(e.x, e.y, e.r, true)) {
            e.x = ar.outX; e.y = ar.outY;
        }
    }

    private static void behave(World w, Enemy e, float dt) {
        Player pl = w.pl;
        float spd = e.speed;
        switch (e.kind) {
            case Kinds.DRONE: steer(e, TX, TY, spd, 4f, dt); break;
            case Kinds.MINI: steer(e, TX, TY, spd, 6f, dt); break;
            case Kinds.VIRUS: {
                e.t += dt;
                float a = Mx.atan2(TY - e.y, TX - e.x) + Mx.sin(e.t * 7f + e.id) * 0.8f;
                float k = Mx.min(1f, 6f * dt);
                e.vx += (Mx.cos(a) * spd - e.vx) * k;
                e.vy += (Mx.sin(a) * spd - e.vy) * k;
                break;
            }
            case Kinds.FIREWALL: {
                e.t -= dt;
                if (e.t <= 0f) {
                    float d = Mx.len(pl.x - e.x, pl.y - e.y);
                    e.t = 2.4f + w.rng.f() * 0.8f;
                    if (d < 10f && d > 1f) w.fireAt(e.x, e.y, pl.x, pl.y, 4.2f, 6f * w.dmgScale(), Bullets.PACKET, 4f);
                }
                break;
            }
            case Kinds.LEECH: leech(w, e, dt); break;
            case Kinds.HUNTER: hunter(w, e, dt); break;
            case Kinds.CORRUPT: corrupt(w, e, dt); break;
            case Kinds.SECURITY: security(w, e, dt); break;
            case Kinds.EATER:
                steer(e, TX, TY, spd, 2.5f, dt);
                if (Mx.len(pl.x - e.x, pl.y - e.y) < 3.0f) pl.supp = Mx.max(pl.supp, 0.6f);
                break;
            case Kinds.UNKNOWN: unknown(w, e, dt); break;
            case Kinds.NEST: {
                e.t -= dt;
                if (e.t <= 0f) {
                    e.t = 3.4f;
                    if (w.aliveHostile < 80) {
                        Enemy m = w.spawn(w.rng.chance(0.3f) ? Kinds.VIRUS : Kinds.DRONE, e.x + w.rng.range(-0.5f, 0.5f), e.y + w.rng.range(-0.5f, 0.5f));
                        if (m != null) w.burst(Particles.HOSTILE, e.x, e.y, 6, 3f, 0.4f, 2f);
                    }
                }
                break;
            }
            case Kinds.ECHO: {
                if (e.ph == 0) e.ph = 20 + w.rng.i(30);
                int idx = w.histIndex(e.ph);
                steer(e, w.histX[idx], w.histY[idx], spd, 5f, dt);
                break;
            }
            case Kinds.MEMFRAG: {
                Enemy b = w.boss;
                if (b != null && b.alive) {
                    e.ax += 1.7f * dt;
                    e.x = Mx.damp(e.x, b.x + Mx.cos(e.ax) * 3f, 6f, dt);
                    e.y = Mx.damp(e.y, b.y + Mx.sin(e.ax) * 3f, 6f, dt);
                } else {
                    steer(e, TX, TY, 2.2f, 4f, dt);
                    e.x += e.vx * dt; e.y += e.vy * dt;
                }
                break;
            }
            case Kinds.FRIEND: {
                float d = Mx.len(pl.x - e.x, pl.y - e.y);
                if (d > 2.4f) steer(e, pl.x, pl.y, 2.8f, 4f, dt);
                else { float k = Mx.exp(-4f * dt); e.vx *= k; e.vy *= k; }
                break;
            }
            default: break;
        }
    }

    private static void leech(World w, Enemy e, float dt) {
        Player pl = w.pl;
        Orbs o = w.orbs;
        if (e.st == 0) {
            e.t -= dt;
            if (e.t <= 0f) {
                e.t = 0.35f;
                int best = -1;
                float bd = 144f;
                for (int i = 0; i < o.hi; i++) {
                    if (!o.on[i] || o.t[i] > 0.2f || o.type[i] == Defs.O_UNK) continue;
                    float dx = o.x[i] - e.x, dy = o.y[i] - e.y, d2 = dx * dx + dy * dy;
                    if (d2 < bd) { bd = d2; best = i; }
                }
                e.ph = best;
                if (best < 0) e.st = 2;
            }
            if (e.ph >= 0 && e.ph < o.cap && o.on[e.ph]) {
                steer(e, o.x[e.ph], o.y[e.ph], e.speed, 5f, dt);
                if (Mx.len(o.x[e.ph] - e.x, o.y[e.ph] - e.y) < e.r + 0.2f) {
                    e.carry += o.v[e.ph];
                    o.remove(e.ph);
                    e.ph = -1; e.st = 1;
                }
            } else {
                e.t = 0f;
            }
        } else if (e.st == 2) {
            steer(e, pl.x, pl.y, e.speed, 4f, dt);
        } else {
            flee(e, pl.x, pl.y, e.speed * 1.15f, 4f, dt);
            Arena ar = w.arena;
            boolean edge = e.x < 1.2f || e.x > ar.W - 1.2f || e.y < 1.2f || e.y > ar.H - 1.2f;
            if (edge || Mx.len(e.x - pl.x, e.y - pl.y) > 15f) {
                e.alive = false;
                if (e.carry > 0) w.pops.addText(pl.x, pl.y - 1.3f, "DATA STOLEN", 0xFFFF8A8A, 0.5f);
            }
        }
    }

    private static void hunter(World w, Enemy e, float dt) {
        Player pl = w.pl;
        float dx = pl.x - e.x, dy = pl.y - e.y, d = Mx.max(0.01f, Mx.len(dx, dy));
        float nx = dx / d, ny = dy / d;
        if (e.ph == 0) { e.ph = 1; e.t = 1.2f + w.rng.f() * 1.5f; }
        if (e.st == 0) {
            float want = w.live.range + 1.3f + e.r;
            float rad = Mx.clamp(d - want, -1f, 1f);
            float dir = (e.id & 1) == 0 ? 1f : -1f;
            float tvx = nx * rad * e.speed - ny * dir * e.speed * 0.7f;
            float tvy = ny * rad * e.speed + nx * dir * e.speed * 0.7f;
            float k = Mx.min(1f, 4f * dt);
            e.vx += (tvx - e.vx) * k;
            e.vy += (tvy - e.vy) * k;
            e.t -= dt;
            if (e.t <= 0f && d < want + 4f) {
                e.st = 1; e.t = 0.5f;
                e.ax = pl.x + pl.vx * 0.45f; e.ay = pl.y + pl.vy * 0.45f;
            }
        } else if (e.st == 1) {
            float k = Mx.exp(-8f * dt);
            e.vx *= k; e.vy *= k;
            e.t -= dt;
            if (e.t <= 0f) {
                float ldx = e.ax - e.x, ldy = e.ay - e.y, ld = Mx.max(0.01f, Mx.len(ldx, ldy));
                e.t2 = ldx / ld; e.t3 = ldy / ld;
                e.st = 2; e.t = 0.55f;
            }
        } else {
            e.vx = e.t2 * 9.5f; e.vy = e.t3 * 9.5f;
            e.t -= dt;
            if (e.t <= 0f) { e.st = 0; e.t = 2.4f + w.rng.f() * 1.2f; }
        }
    }

    private static void corrupt(World w, Enemy e, float dt) {
        Player pl = w.pl;
        float dx = pl.x - e.x, dy = pl.y - e.y, d = Mx.max(0.01f, Mx.len(dx, dy));
        float want = 5.5f;
        float rad = d < want - 0.6f ? -1f : (d > want + 1f ? 1f : 0f);
        float k = Mx.min(1f, 3f * dt);
        e.vx += (dx / d * rad * e.speed - e.vx) * k;
        e.vy += (dy / d * rad * e.speed - e.vy) * k;
        if (e.ph == 0) { e.ph = 1; e.t = 1.5f + w.rng.f(); }
        e.t -= dt;
        if (e.t <= 0f) {
            int a = e.st;
            e.st = (e.st + 1) % 3;
            e.t = 3.2f;
            float dmg = 5f * w.dmgScale();
            if (a == 0) {
                w.fireAt(e.x, e.y, pl.x, pl.y, 3.4f, dmg, Bullets.LOCK, 5f);
            } else if (a == 1) {
                w.ring(e.x, e.y, 8, 3.2f, dmg, Bullets.PACKET, w.rng.ang(), 4f);
            } else {
                w.burst(Particles.MAGENTA, e.x, e.y, 12, 4f, 0.4f, 2f);
                float ang = w.rng.ang(), dist = Mx.max(1.5f, w.live.range * 0.6f);
                e.x = Mx.clamp(pl.x + Mx.cos(ang) * dist, 0.8f, w.arena.W - 0.8f);
                e.y = Mx.clamp(pl.y + Mx.sin(ang) * dist, 0.8f, w.arena.H - 0.8f);
                w.burst(Particles.MAGENTA, e.x, e.y, 12, 4f, 0.4f, 2f);
            }
        }
    }

    private static void security(World w, Enemy e, float dt) {
        Player pl = w.pl;
        steer(e, TX, TY, e.speed, 2f, dt);
        if (e.ph == 0) { e.ph = 1; e.t = 4f; }
        e.t -= dt;
        if (e.t <= 0f) {
            e.t = 7f;
            Arena ar = w.arena;
            float bx = pl.x + pl.vx, by = pl.y + pl.vy;
            if (Mx.len(bx - pl.x, by - pl.y) < 1.8f) { bx = pl.x + pl.lastDx * 2.2f; by = pl.y + pl.lastDy * 2.2f; }
            bx = Mx.clamp(bx, 1f, ar.W - 1f); by = Mx.clamp(by, 1f, ar.H - 1f);
            ar.addBarrier(bx, by, 0.9f, 5f);
            w.burst(Particles.SPARK, bx, by, 10, 3f, 0.4f, 2f);
        }
    }

    private static void unknown(World w, Enemy e, float dt) {
        Player pl = w.pl;
        e.t -= dt;
        if (e.t <= 0f) {
            e.st = w.rng.i(6);
            e.t = 1.2f + w.rng.f();
            if (e.st == 3) {
                float a = w.rng.ang(), d = w.rng.range(4f, 6f);
                w.burst(Particles.VIOLET, e.x, e.y, 10, 4f, 0.4f, 2f);
                e.x = Mx.clamp(pl.x + Mx.cos(a) * d, 0.8f, w.arena.W - 0.8f);
                e.y = Mx.clamp(pl.y + Mx.sin(a) * d, 0.8f, w.arena.H - 0.8f);
                w.burst(Particles.VIOLET, e.x, e.y, 10, 4f, 0.4f, 2f);
                e.st = 0;
            } else if (e.st == 4) {
                e.phase = 1f;
            } else if (e.st == 5) {
                if (e.gen == 0) {
                    for (int i = 0; i < 2; i++) {
                        Enemy m = w.spawn(Kinds.MINI, e.x, e.y);
                        if (m != null) { m.gen = 1; m.kx = (i == 0 ? -3f : 3f); }
                    }
                }
                e.st = 0;
            }
        }
        switch (e.st) {
            case 1: flee(e, TX, TY, e.speed, 4f, dt); break;
            case 2: {
                float dx = pl.x - e.x, dy = pl.y - e.y, d = Mx.max(0.01f, Mx.len(dx, dy));
                float tvx = -dy / d * e.speed + dx / d * (d - 3.5f) * 0.5f;
                float tvy = dx / d * e.speed + dy / d * (d - 3.5f) * 0.5f;
                float k = Mx.min(1f, 4f * dt);
                e.vx += (tvx - e.vx) * k; e.vy += (tvy - e.vy) * k;
                break;
            }
            default: steer(e, TX, TY, e.speed * (e.st == 4 ? 0.7f : 1f), 4f, dt); break;
        }
    }

    /** Corrupted/dominated enemies hunt their own kind. */
    private static void converted(World w, Enemy e, float dt) {
        int n = w.grid.query(e.x, e.y, 7f, w.tmp2);
        Enemy best = null;
        float bd = 1e9f;
        for (int j = 0; j < n; j++) {
            Enemy o = w.en[w.tmp2[j]];
            if (o == e || !o.alive || o.conv > 0 || o.kind == Kinds.FRIEND || o.kind == Kinds.BOSS) continue;
            float dx = o.x - e.x, dy = o.y - e.y, d2 = dx * dx + dy * dy;
            if (d2 < bd) { bd = d2; best = o; }
        }
        if (best == null) { float k = Mx.exp(-3f * dt); e.vx *= k; e.vy *= k; return; }
        steer(e, best.x, best.y, Mx.max(e.speed, 1.6f) * 1.2f + 1f, 5f, dt);
        if (Mx.sqrt(bd) < e.r + best.r + 0.05f && e.contactCd <= 0f) {
            e.contactCd = 0.4f;
            w.hit(best, 4.2f * w.hpScale(), false);
        }
    }

    private static void contact(World w, Enemy e) {
        if (e.conv > 0 || e.dmg <= 0f || e.contactCd > 0f || e.kind == Kinds.FRIEND) return;
        Player pl = w.pl;
        float dx = pl.x - e.x, dy = pl.y - e.y, rr = e.r + pl.r * 0.9f;
        if (dx * dx + dy * dy < rr * rr) {
            if (e.kind == Kinds.LEECH) {
                if (e.st == 2) {
                    double s = w.run.bag * 0.03;
                    w.run.bag -= s; e.carry += s; e.st = 1; e.contactCd = 1f;
                    w.pops.addText(pl.x, pl.y - 1.1f, "DATA STOLEN", 0xFFFF8A8A, 0.5f);
                }
            } else if (pl.invuln <= 0f && pl.dashT <= 0f) {
                w.damagePlayer(e.dmg, false);
                e.contactCd = 0.7f;
                float d = Mx.max(0.01f, Mx.sqrt(dx * dx + dy * dy));
                if (e.kind != Kinds.BOSS) { e.kx -= dx / d * 5f; e.ky -= dy / d * 5f; }
                pl.vx += dx / d * 3f; pl.vy += dy / d * 3f;
            }
        }
        Enemy f = w.friend;
        if (f != null && f.alive && e.kind != Kinds.BOSS && e.kind != Kinds.NEST && e.kind != Kinds.FIREWALL) {
            float fx = f.x - e.x, fy = f.y - e.y, fr = e.r + f.r;
            if (fx * fx + fy * fy < fr * fr) { w.friendHit(e.dmg * 0.5f); e.contactCd = 0.7f; }
        }
    }

    private static void separation(World w, int hi) {
        for (int i = 0; i < hi; i++) {
            Enemy e = w.en[i];
            if (!e.alive || Kinds.stationary(e.kind) || e.kind == Kinds.ECHO) continue;
            int n = w.grid.query(e.x, e.y, e.r * 2f + 0.3f, w.tmp2);
            for (int j = 0; j < n; j++) {
                int k = w.tmp2[j];
                if (k <= i) continue;
                Enemy o = w.en[k];
                if (!o.alive || Kinds.stationary(o.kind) || o.kind == Kinds.ECHO) continue;
                float dx = e.x - o.x, dy = e.y - o.y, rr = (e.r + o.r) * 0.9f, d2 = dx * dx + dy * dy;
                if (d2 >= rr * rr || d2 < 1e-8f) continue;
                float d = Mx.sqrt(d2), push = (rr - d) * 0.5f;
                e.x += dx / d * push; e.y += dy / d * push;
                o.x -= dx / d * push; o.y -= dy / d * push;
            }
        }
    }
}
