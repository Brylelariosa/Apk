package com.neuralfeed.game;

/** The AI core's physical and status state. */
public final class Player {
    public float x, y, vx, vy, r = 0.28f;
    public float barrier, maxBarrier, barrierDelay, invuln, hitFlash;
    public float dashT, dashCd, dashDx, dashDy, lastDx = 0f, lastDy = -1f;
    public float fieldOff, supp, rot, pulse, slowRift;
    public final float[] abCd = new float[3];
    public final float[] abT = new float[7];
    public boolean guardUsed;
    public final float[] trX = new float[10], trY = new float[10], trA = new float[10];
    public int trI;

    public void resetForNode(float px, float py) {
        x = px; y = py; vx = vy = 0; invuln = 1.0f; dashT = 0; fieldOff = 0; supp = 0; slowRift = 0; guardUsed = false;
        for (int i = 0; i < trA.length; i++) trA[i] = 0;
        for (int i = 0; i < abT.length; i++) abT[i] = 0;
    }
}
