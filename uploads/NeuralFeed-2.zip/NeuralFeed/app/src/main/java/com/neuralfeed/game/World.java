package com.neuralfeed.game;

import com.neuralfeed.audio.Sfx;
import com.neuralfeed.core.Fmt;
import com.neuralfeed.core.Grid;
import com.neuralfeed.core.Mx;
import com.neuralfeed.core.Rng;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.CoreStats;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Karma;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.meta.Memories;
import com.neuralfeed.meta.StatsCalc;
import com.neuralfeed.meta.Story;
import com.neuralfeed.meta.Timelines;

/** The simulation: one timed run in a small dark network. Renderer and screens read its public state. */
public final class World {
    public static final int MAXE = 140, MAXB = 32;
    public static final int P_INTRO = 0, P_FIGHT = 1, P_END = 2, P_DONE = 3;
    public static final int END_TIME = 0, END_CLEAR = 1;
    public static final float INTRO_T = 1.5f;

    public final Env env;
    public final Profile pf;
    public final Rng rng = new Rng(System.nanoTime() ^ 0x5DEECE66DL);
    public final CoreStats base = new CoreStats(), live = new CoreStats();
    public final Player pl = new Player();
    public final Enemy[] en = new Enemy[MAXE];
    public final Orbs orbs;
    public final Bullets bul;
    public final Particles parts;
    public final Popups pops = new Popups();
    public final Arena arena = new Arena();
    public final Grid grid = new Grid(64f, 70f, 2f, MAXE);
    public final Run run = new Run();
    public final Input in = new Input();
    public final int[] tmp = new int[MAXE], tmp2 = new int[MAXE];

    public int enHi, aliveHostile, idCounter;
    public int phase, kind, endKind;
    public float phaseT, stageTime, time, timeScale = 1f, slowT, hitStop;
    /** The run clock: seconds left, seconds at the start, bonus seconds earned so far (capped), and the last hit's cost. */
    public float timeLeft, timeMax, timeEarned, lostFlash, lastLoss;
    public boolean bossDead, flawless, voidDone;
    public double xp0;
    public Enemy boss, friend;
    public float spawnCd, waveT, eliteT;

    // tutorial hooks (driven by ui.Tutorial)
    public float spawnBias = 1f;
    public boolean clockPaused, noPenalty, forceAlert;
    public int dashCount, pickups;
    public float moved;

    // the dark network: scan ping and what the Finder has locked
    public float scanT, pingA, pingR, revealT;
    public final int[] lockIdx = new int[16], lockId = new int[16];
    public int lockN, locked, lastSec;
    public float lockT;

    public int sw = 1080, sh = 2400;
    public float camX, camY, scale = 100f, shakePx, shakeX, shakeY, damageFlash, glitch;

    public float procAcc, fieldEnergy, ringPulse, comboFlash, shockR, shockA;
    public int lastTargets, comboTier, maxTargets;
    public final float[] beamX = new float[MAXB], beamY = new float[MAXB], beamL = new float[MAXB];
    public int beamN;

    public int pPow, pRate, pRange, pCol, pData, pSpd, patchKills;
    public float cascadeStacks, cascadeT, stormT;
    public int chain;
    public float chainT, lastPickSfx;

    public int memEvent = -1;
    public boolean levelUp, evolved;
    public int lastLevel, lastTier;
    public String lastPatch = "";
    public float patchT;

    // time echoes + paradox rifts
    public final float[] histX = new float[64], histY = new float[64];
    public int histI;
    public float histT;
    public final float[] riftX = new float[3], riftY = new float[3], riftR = new float[3], riftT = new float[3];
    public final int[] riftType = new int[3];

    public World(Env env, int orbCap, int particleCap) {
        this.env = env;
        this.pf = env.profile();
        orbs = new Orbs(orbCap);
        bul = new Bullets(96);
        parts = new Particles(particleCap);
        for (int i = 0; i < MAXE; i++) en[i] = new Enemy();
    }

    public void setView(int w, int h) { sw = w; sh = h; }

    // ------------------------------------------------------------------ lifecycle

    public void beginRun(int runKind, int threat) {
        kind = pf.timeline >= 10 ? Defs.RUN_VOID : runKind;
        run.reset(kind, kind == Defs.RUN_VOID ? 0 : threat, pf.timeline);
        pf.runs++;
        xp0 = pf.xp;
        pPow = pRate = pRange = pCol = pData = pSpd = 0;
        cascadeStacks = 0; patchKills = 0;
        refreshStats(true);
        lastLevel = pf.level();
        lastTier = StatsCalc.coreTier(pf);
        for (int i = 0; i < 3; i++) pl.abCd[i] = 4f;
        Story.bond(pf, 0.006f);
        startRun();
    }

    public void refreshStats(boolean full) {
        StatsCalc.compute(pf, base);
        pl.maxBarrier = base.barrier;
        pl.barrier = full ? pl.maxBarrier : Mx.min(pl.barrier, pl.maxBarrier);
        if (full) { timeMax = base.runTime + (kind == Defs.RUN_BOSS ? 30f : 0f); timeLeft = timeMax; }
    }

    /** Fraction of the run clock that has been used (0..1). */
    public float progress() { return timeMax > 0f ? Mx.min(1f, stageTime / timeMax) : 0f; }
    public int tier() { return run.tier(pf.timeline, progress()); }
    public float hpScale() { return run.hpScale(pf.timeline); }
    public float dmgScale() { return run.dmgScale(pf.timeline); }
    public float valScale() { return run.valScale(pf.timeline); }

    /** True if something at (x, y) can be seen: inside the vision radius, or while a scan ping reveals the whole network. */
    public boolean visible(float x, float y) {
        if (revealT > 0f || kind != Defs.RUN_HARVEST || phase >= P_END) return true;
        float dx = x - pl.x, dy = y - pl.y, r = live.vision;
        return dx * dx + dy * dy < r * r;
    }

    private float alertChance() {
        if (forceAlert || kind == Defs.RUN_BOSS) return 1f;
        return Mx.min(0.9f, 0.45f + 0.04f * run.threat);
    }

    private void startRun() {
        if (kind == Defs.RUN_VOID) arena.generateVoid(); else arena.generate(rng, kind, tier());
        voidDone = false;
        for (int i = 0; i < MAXE; i++) en[i].alive = false;
        enHi = 0; aliveHostile = 0;
        bul.clear(); orbs.clear(); parts.clear(); pops.clear();
        pl.resetForNode(arena.spawnX, arena.spawnY);
        pl.barrier = pl.maxBarrier;
        camX = pl.x; camY = pl.y; beamN = 0;
        for (int i = 0; i < MAXB; i++) beamL[i] = 0;
        for (int i = 0; i < 3; i++) riftT[i] = 0;
        stageTime = 0; bossDead = false; boss = null; friend = null; lockN = 0; locked = 0; lockT = 0;
        spawnCd = 1.0f; waveT = 12f; eliteT = 14f; flawless = true; shockA = 0; stormT = 0; histT = 0;
        timeEarned = 0; lostFlash = 0; lastLoss = 0; dashCount = 0; pickups = 0; moved = 0; lastSec = -1;
        scanT = base.scanCd * 0.5f; pingA = 0; pingR = 0; revealT = 0;
        for (int i = 0; i < 64; i++) { histX[i] = pl.x; histY[i] = pl.y; }

        float vs = valScale();
        for (int i = 0; i < arena.nd; i++) seedField(i, 7 + rng.i(5), vs * 0.7f);
        for (int i = 0; i < arena.nn; i++) {
            Enemy e = spawn(Kinds.NEST, arena.nx[i], arena.ny[i]);
            if (e != null) e.t = 2f + i;
        }
        if (kind == Defs.RUN_BOSS) spawnBoss();
        if (kind == Defs.RUN_HARVEST && pf.runs > 3 && rng.chance(0.3f)) spawnFriend();
        if (kind == Defs.RUN_VOID) {
            int vi = orbs.spawn(arena.W * 0.5f, arena.H * 0.15f, 0f, 0f, 1f, Defs.O_UNK);
            orbs.t[vi] = 0f;
        }
        phase = P_INTRO; phaseT = 0; timeScale = 1f; slowT = 0;
        glitch = pf.paradox >= 20f ? pf.paradox / 100f : 0f;
        chain = 0; chainT = 0;
    }

    private void seedField(int i, int n, float each) {
        for (int k = 0; k < n; k++) {
            float a = rng.ang(), d = rng.f() * arena.dfr[i];
            int oi = orbs.spawn(arena.dfx[i] + Mx.cos(a) * d, arena.dfy[i] + Mx.sin(a) * d, 0, 0, each, rng.chance(0.15f) ? Defs.O_COMP : Defs.O_BASIC);
            if (oi >= 0) orbs.t[oi] = 0f;
        }
    }

    private void spawnFriend() {
        friend = spawn(Kinds.FRIEND, pl.x + 2f, pl.y + 1f);
        if (friend != null) { friend.maxHp = friend.hp = 60f * hpScale(); env.hint(Defs.H_FRND, Lines.H_FRND); }
    }

    /** A rich elite process that walks in out of the dark. Killing it drops a big pile of Data. */
    public void spawnElite() {
        int[] low = {Kinds.DRONE, Kinds.HUNTER};
        int[] high = {Kinds.HUNTER, Kinds.CORRUPT, Kinds.SECURITY, Kinds.EATER};
        int k = tier() >= 3 ? high[rng.i(high.length)] : low[rng.i(low.length)];
        float x = arena.W * 0.5f, y = arena.H * 0.3f;
        for (int t = 0; t < 10; t++) {
            float a = rng.ang(), d = rng.range(8f, 12f);
            x = Mx.clamp(pl.x + Mx.cos(a) * d, 1f, arena.W - 1f); y = Mx.clamp(pl.y + Mx.sin(a) * d, 1f, arena.H - 1f);
            if (Mx.len(x - pl.x, y - pl.y) > 7f) break;
        }
        Enemy e = spawn(k, x, y);
        if (e == null) return;
        EnemyAI.alert(e);
        e.elite = (1 << rng.i(3)) | 8;
        if (rng.chance(0.4f)) e.elite |= 1 << rng.i(3);
        e.maxHp *= 6f; e.hp = e.maxHp; e.r *= 1.5f; e.dmg *= 1.3f; e.val *= 6f;
        if ((e.elite & 1) != 0) e.speed *= 1.4f;
        lastPatch = "ELITE PROCESS DETECTED"; patchT = 2.2f;
        env.sfx(Sfx.BOSS_WARN, 0.5f);
    }

    private void spawnBoss() {
        int id = (Timelines.bossFor(pf.timeline) + pf.cycle) % Defs.B_N;
        Enemy b = spawn(Kinds.BOSS, arena.bossX, arena.bossY);
        if (b == null) return;
        b.bossId = id;
        b.maxHp = b.hp = 900f * hpScale() * (1f + 0.15f * id);
        b.r = Kinds.R[Kinds.BOSS];
        b.dmg = 12f * dmgScale();
        b.val = 0;
        b.t = 3f; b.t2 = 2f;
        boss = b;
        env.sfx(Sfx.BOSS_SPAWN, 1f);
        env.say(Dialogue.AI, Lines.BOSS_INTRO[id]);
        env.hint(Defs.H_BOSSH, Lines.H_BOSS);
    }

    // ------------------------------------------------------------------ entities

    public Enemy spawn(int kind, float x, float y) {
        for (int i = 0; i < MAXE; i++) {
            Enemy e = en[i];
            if (e.alive) continue;
            e.reset(kind);
            e.x = x; e.y = y; e.r = Kinds.R[kind];
            e.maxHp = e.hp = Kinds.HP[kind] * hpScale();
            e.dmg = Kinds.DMG[kind] * dmgScale();
            e.speed = Kinds.SPD[kind] * run.speedScale();
            e.val = Kinds.VAL[kind] * valScale();
            e.id = ++idCounter;
            e.rot = rng.ang();
            if (EnemyAI.searches(kind) && rng.chance(alertChance())) EnemyAI.alert(e);
            if (i >= enHi) enHi = i + 1;
            return e;
        }
        return null;
    }

    public void burst(int kind, float x, float y, int n, float speed, float life, float size) {
        int c = parts.count(n);
        for (int i = 0; i < c; i++) {
            float a = rng.ang(), s = speed * (0.35f + rng.f() * 0.65f);
            parts.emit(kind, x, y, Mx.cos(a) * s, Mx.sin(a) * s, life * (0.6f + rng.f() * 0.4f), size);
        }
    }

    public void shake(float px) { if (env.shakeEnabled()) shakePx = Mx.max(shakePx, px); }

    public void fireAt(float x, float y, float tx, float ty, float speed, float dmg, int type, float life) {
        float dx = tx - x, dy = ty - y, d = Mx.len(dx, dy);
        if (d < 1e-4f) { dx = 0; dy = 1; d = 1; }
        bul.spawn(x, y, dx / d * speed, dy / d * speed, dmg, type, life);
    }

    public void ring(float x, float y, int n, float speed, float dmg, int type, float off, float life) {
        for (int i = 0; i < n; i++) {
            float a = off + i * Mx.TAU / n;
            bul.spawn(x, y, Mx.cos(a) * speed, Mx.sin(a) * speed, dmg, type, life);
        }
    }

    // ------------------------------------------------------------------ damage / death

    public void hit(Enemy e, float dmg, boolean crit) {
        if (!e.alive || e.kind == Kinds.FRIEND) return;
        if (e.immune || e.phase > 0) { e.flash = 0.05f; return; }
        if (e.prot) dmg *= 0.4f;
        if ((e.elite & 2) != 0) dmg *= 0.6f;
        e.hp -= dmg;
        e.flash = 0.09f;
        if (e.aw != Enemy.AW_ALERT && EnemyAI.searches(e.kind)) EnemyAI.alert(e);
        if (e.kind == Kinds.BOSS && crit && rng.chance(0.2f)) env.sfx(Sfx.BOSS_HIT, 0.5f);
        if (e.hp <= 0) kill(e);
    }

    /** Adds seconds to the run clock. Bonus time (kills, orbs) is capped per run so no build can stall the clock forever. */
    public void addTime(float sec) {
        if (sec <= 0f || phase > P_FIGHT || kind == Defs.RUN_VOID) return;
        float a = Mx.min(sec, Mx.max(0f, timeMax * 0.4f - timeEarned));
        if (a <= 0f) return;
        timeEarned += a; timeLeft += a;
    }

    /** There is no health: every hit costs seconds off the run clock instead. */
    public void damagePlayer(float amt, boolean ignoreInvuln) {
        if (phase != P_FIGHT || amt <= 0 || kind == Defs.RUN_VOID) return;
        if (!ignoreInvuln && (pl.invuln > 0 || pl.dashT > 0)) return;
        boolean drip = ignoreInvuln && amt < 1f;   // hazard zones drain a little every frame
        if (base.guardian && !pl.guardUsed && !ignoreInvuln) {
            pl.guardUsed = true; pl.invuln = 1.2f;
            burst(Particles.SPARK, pl.x, pl.y, 24, 6f, 0.6f, 2.5f);
            pops.addText(pl.x, pl.y - 0.6f, "REDIRECTED", 0xFF8FE3FF, 0.5f);
            env.sfx(Sfx.SHIELD_BREAK, 0.8f);
            return;
        }
        pl.barrierDelay = 3f;
        if (!ignoreInvuln && pl.barrier >= 1f) {
            pl.barrier -= 1f; pl.invuln = 0.6f; pl.hitFlash = 0.2f;
            burst(Particles.SPARK, pl.x, pl.y, 18, 5f, 0.5f, 2.2f);
            pops.addText(pl.x, pl.y - 0.6f, "BLOCKED", 0xFF8FE3FF, 0.5f);
            env.sfx(Sfx.SHIELD_BREAK, 0.8f);
            env.hint(Defs.H_BARRIER, Lines.H_BARRIER);
            return;
        }
        float cost = (drip ? amt * 0.12f : Mx.clamp(0.5f + 0.06f * amt, 0.6f, 3.2f)) * base.hitMul;
        if (!drip) {
            flawless = false;
            if (!ignoreInvuln) pl.invuln = 0.55f;
            pl.hitFlash = 0.2f;
            damageFlash = Mx.min(1f, damageFlash + 0.5f);
            env.sfx(Sfx.HIT, 0.8f);
            env.vibrate(18);
            shake(10f);
            run.hits++;
        } else {
            pl.hitFlash = Mx.max(pl.hitFlash, 0.08f);
            damageFlash = Mx.min(0.5f, damageFlash + 0.04f);
        }
        if (noPenalty) return;
        timeLeft -= cost;
        run.lost += cost;
        lostFlash = 0.6f; lastLoss = cost;
        if (!drip) pops.addText(pl.x, pl.y - 0.8f, "-" + Fmt.secs(cost), 0xFFFF6A6A, 0.62f);
    }

    public void kill(Enemy e) {
        if (!e.alive) return;
        e.alive = false;
        int k = e.kind;
        int pk = k == Kinds.CORRUPT ? Particles.MAGENTA : k == Kinds.UNKNOWN ? Particles.VIOLET : Particles.HOSTILE;
        burst(pk, e.x, e.y, 8 + (int) (e.r * 14), 4.5f, 0.55f, 2.2f);
        if (k == Kinds.FRIEND) {
            friend = null;
            pops.addText(e.x, e.y - 0.5f, "LOST", 0xFFFF8A8A, 0.55f);
            Karma.add(pf, Defs.K_COMP, -0.02f);
            Story.trust(pf, -0.02f);
            env.say(Dialogue.AI, "That entity is gone.");
            return;
        }
        if (k == Kinds.BOSS) { bossDeath(e); return; }
        if (k == Kinds.ECHO) { burst(Particles.WHITE, e.x, e.y, 10, 3f, 0.4f, 2f); return; }
        run.kills++; pf.kills++;
        if (!run.quotaMet && kind == Defs.RUN_HARVEST && run.kills >= run.quota) {
            run.quotaMet = true; lastPatch = "QUOTA MET"; patchT = 2.4f; env.sfx(Sfx.TIER_UP, 0.9f, 1.1f);
        }
        EnemyAI.alertNear(this, e.x, e.y, 3.5f);
        pf.xp += Math.pow(Math.max(0.5, e.val), 0.7) * 0.8;
        dropOrbs(e);
        if (k == Kinds.VIRUS && e.gen == 0) {
            for (int i = 0; i < 2; i++) {
                Enemy m = spawn(Kinds.MINI, e.x + (i == 0 ? -0.2f : 0.2f), e.y);
                if (m != null) { m.gen = 1; m.vx = (i == 0 ? -2f : 2f); }
            }
        }
        if (k == Kinds.LEECH && e.carry > 0) {
            int n = 3;
            for (int i = 0; i < n; i++) {
                float a = rng.ang();
                orbs.spawn(e.x, e.y, Mx.cos(a) * 4f, Mx.sin(a) * 4f, (float) (e.carry / n), Defs.O_COMP);
            }
        }
        if ((e.elite & 4) != 0) ring(e.x, e.y, 10, 3.6f, 6f * dmgScale(), Bullets.PACKET, rng.ang(), 3f);
        if (k == Kinds.NEST) {
            for (int i = 0; i < 6; i++) { float a = rng.ang(); orbs.spawn(e.x, e.y, Mx.cos(a) * 4f, Mx.sin(a) * 4f, e.val * 0.4f, Defs.O_COMP); }
            shake(8f);
        }
        if (base.dominate > 0 && rng.chance(base.dominate)) dominateNear(e.x, e.y);
        if (base.cascade > 0) { cascadeStacks = Mx.min(20f, cascadeStacks + 1f); cascadeT = 3f; }
        addTime(base.timeKill);
        patchKills++;
        if (patchKills >= base.patchEvery) { patchKills = 0; grantPatch(); run.patches++; }
        if ((e.elite & 8) != 0) { env.sfx(Sfx.KILL_BIG, 1f); shake(10f); } else env.sfx(Sfx.KILL, 0.5f);
    }

    private void dominateNear(float x, float y) {
        int n = grid.query(x, y, 2.5f, tmp);
        for (int i = 0; i < n; i++) {
            Enemy o = en[tmp[i]];
            if (o.alive && o.kind != Kinds.BOSS && o.kind != Kinds.FRIEND && o.conv <= 0) { o.conv = 6f; return; }
        }
    }

    private void grantPatch() {
        int r = rng.i(6);
        switch (r) {
            case 0: pPow++; lastPatch = "PATCH: POWER +6%"; break;
            case 1: pRate++; lastPatch = "PATCH: RATE +6%"; break;
            case 2: pRange++; lastPatch = "PATCH: RANGE +5%"; break;
            case 3: pCol++; lastPatch = "PATCH: COLLECTION +8%"; break;
            case 4: pData++; lastPatch = "PATCH: DATA +8%"; break;
            default: pSpd++; lastPatch = "PATCH: SPEED +4%"; break;
        }
        patchT = 2.2f;
    }

    /** Memory Eater effect: wipes temporary bonuses. */
    public void stripBonuses() {
        pPow = pRate = pRange = pCol = pData = pSpd = 0;
        cascadeStacks = 0;
        for (int i = 0; i < 3; i++) pl.abCd[i] += 4f;
        lastPatch = "BONUSES ERASED"; patchT = 2.2f;
    }

    private int orbCount(Enemy e) {
        if ((e.elite & 8) != 0) return 8;
        switch (e.kind) {
            case Kinds.NEST: return 6;
            case Kinds.DRONE: case Kinds.VIRUS: case Kinds.MINI: case Kinds.ECHO: return 1;
            default: return e.r >= 0.4f ? 3 : 2;
        }
    }

    private void dropOrbs(Enemy e) {
        int n = orbCount(e);
        float total = e.val * (1f + base.harvest) * live.dataMult;
        float per = total / n;
        float unk = 0.004f * base.observe + (e.kind == Kinds.UNKNOWN ? 0.06f : 0f) + (e.kind == Kinds.MEMFRAG ? 0.35f : 0f) + (e.elite != 0 ? 0.05f : 0f);
        float corr = e.kind == Kinds.CORRUPT ? 0.25f : 0f;
        float rare = 0.035f * base.rare;
        for (int i = 0; i < n; i++) {
            float roll = rng.f();
            int ty; float m;
            if (roll < unk) { ty = Defs.O_UNK; m = 25f; }
            else if (roll < unk + rare) { ty = Defs.O_RARE; m = 10f; }
            else if (roll < unk + rare + 0.15f) { ty = Defs.O_COMP; m = 3.5f; }
            else if (roll < unk + rare + 0.15f + corr) { ty = Defs.O_CORR; m = 8f; }
            else { ty = Defs.O_BASIC; m = 1f; }
            if (base.steal) {
                addData(per * m * 1.2f);
                if (ty == Defs.O_UNK) onUnknown();
                float a = rng.ang();
                parts.emit(Particles.DATA, e.x, e.y, Mx.cos(a) * 2f, Mx.sin(a) * 2f, 0.4f, 2f);
                continue;
            }
            float a = rng.ang(), sp = 2.5f + rng.f() * 2.5f;
            orbs.spawn(e.x, e.y, Mx.cos(a) * sp, Mx.sin(a) * sp, per * m, ty);
        }
    }

    public void addData(double v) { run.bag += v; }

    public void onUnknown() {
        pf.unknownFound++; run.unknown++;
        if (rng.chance(0.5f) || pf.memCount() == 0) giveMemory();
    }

    public void giveMemory() {
        int id = Memories.next(pf, pf.timeline, rng);
        if (id < 0) { addData(valScale() * 20f); return; }
        pf.setMem(id); run.memories++;
        if (!pf.flag(Defs.F_REMEMBER)) { pf.flags |= Defs.F_REMEMBER; env.say(Dialogue.AI, Lines.REMEMBER); }
        Story.updateFlags(pf);
        Story.bond(pf, 0.01f);
        memEvent = id;
        env.sfx(Sfx.MEMORY, 1f);
    }

    private void bossDeath(Enemy b) {
        int id = b.bossId;
        bossDead = true; boss = null;
        run.bossKills++; pf.bossKills++; pf.bossMask |= 1 << id;
        pf.bossDone = true;
        float vs = valScale();
        for (int i = 0; i < 40; i++) {
            float a = rng.ang(), sp = 3f + rng.f() * 6f;
            int ty = i % 9 == 0 ? Defs.O_RARE : (i % 3 == 0 ? Defs.O_COMP : Defs.O_BASIC);
            orbs.spawn(b.x, b.y, Mx.cos(a) * sp, Mx.sin(a) * sp, vs * 7f * live.dataMult * (ty == Defs.O_RARE ? 10f : ty == Defs.O_COMP ? 3f : 1f), ty);
        }
        orbs.spawn(b.x, b.y, 0, 0, vs * 30f, Defs.O_UNK);
        burst(Particles.WHITE, b.x, b.y, 80, 12f, 1.4f, 3.5f);
        burst(Particles.MAGENTA, b.x, b.y, 50, 8f, 1.6f, 3f);
        shake(26f);
        slowT = 1.6f;
        env.sfx(Sfx.BOSS_DIE, 1f);
        env.vibrate(120);
        env.say(Dialogue.AI, Lines.BOSS_DOWN[id]);
        pf.flags |= Defs.F_BOSS1;
        Karma.add(pf, Defs.K_AGGR, 0.012f);
        Karma.add(pf, Defs.K_CTRL, 0.01f);
        Story.updateFlags(pf);
        for (int i = 0; i < MAXE; i++) {
            Enemy o = en[i];
            if (o.alive && o != friend && o.kind != Kinds.BOSS) { o.alive = false; burst(Particles.HOSTILE, o.x, o.y, 6, 4f, 0.5f, 2f); }
        }
        bul.clear();
        beginEnd(END_CLEAR);
    }

    // ------------------------------------------------------------------ pickups

    private void pickup(int i) {
        int ty = orbs.type[i];
        float v = orbs.v[i];
        float ox = orbs.x[i], oy = orbs.y[i];
        orbs.remove(i);
        if (kind == Defs.RUN_VOID) { voidDone = true; env.sfx(Sfx.MEMORY, 1f); return; }
        addData(v);
        pickups++;
        if (ty == Defs.O_CORR) damagePlayer(4f, false);
        if (ty == Defs.O_UNK) onUnknown();
        chain++; chainT = 0.35f;
        if (lastPickSfx <= 0f || ty >= Defs.O_RARE) { env.pick(ty, chain); lastPickSfx = 0.03f; }
        if (base.timePerOrb > 0f) addTime(base.timePerOrb);
        pl.pulse = 1f;
        int kind = ty == Defs.O_RARE ? Particles.MAGENTA : ty == Defs.O_UNK ? Particles.VIOLET : ty == Defs.O_CORR ? Particles.RED : Particles.DATA;
        burst(kind, ox, oy, ty >= Defs.O_RARE ? 6 : 2, 2.5f, 0.3f, 1.8f);
    }

    // ------------------------------------------------------------------ update

    public void update(float rawDt) {
        float dt = Mx.min(rawDt, 0.033f);
        if (hitStop > 0) { hitStop -= rawDt; dt *= 0.05f; }
        if (slowT > 0) { slowT -= rawDt; timeScale = Mx.damp(timeScale, 0.3f, 8f, rawDt); }
        else timeScale = Mx.damp(timeScale, 1f, 4f, rawDt);
        dt *= timeScale;
        time += dt; phaseT += dt;
        run.time += dt;
        parts.update(dt);
        pops.update(dt);
        arena.update(dt);
        updateBeams(dt);
        damageFlash = Mx.max(0f, damageFlash - dt * 2f);
        glitch = Mx.max(pf.paradox >= 20f ? pf.paradox / 100f * 0.3f : 0f, glitch - dt * 1.2f);
        shakePx = Mx.max(0f, shakePx - dt * 40f);
        if (shakePx > 0.1f) { shakeX = (rng.f() - 0.5f) * 2f * shakePx; shakeY = (rng.f() - 0.5f) * 2f * shakePx; } else { shakeX = 0; shakeY = 0; }
        if (patchT > 0) patchT -= dt;
        if (lastPickSfx > 0) lastPickSfx -= dt;
        chainT -= dt; if (chainT <= 0) chain = 0;
        if (cascadeT > 0) { cascadeT -= dt; if (cascadeT <= 0) cascadeStacks = 0; }
        if (stormT > 0) stormT -= dt;
        ringPulse = Mx.max(0f, ringPulse - dt * 5f);
        comboFlash = Mx.max(0f, comboFlash - dt * 2f);
        shockR += dt * 14f; shockA = Mx.max(0f, shockA - dt * 2.2f);
        lockT -= dt;
        lostFlash = Mx.max(0f, lostFlash - dt);
        if (pingA > 0f) { pingR += dt * 22f; pingA -= dt; }
        if (revealT > 0f) revealT -= dt;

        if (phase == P_DONE) { updateCamera(dt); return; }
        if (phase == P_END) {
            applyLive();
            movePlayer(dt);
            updateOrbsAndBullets(dt);
            updateCamera(dt);
            if (phaseT > (endKind == END_CLEAR ? 2.6f : 1.6f)) phase = P_DONE;
            return;
        }

        applyLive();
        movePlayer(dt);
        if (in.act && friendNear()) consumeFriend();
        AbilitySys.update(this, dt);
        recordHistory(dt);

        grid.clear();
        aliveHostile = 0;
        for (int i = 0; i < enHi; i++) {
            Enemy e = en[i];
            if (!e.alive) continue;
            grid.insert(i, e.x, e.y);
            if (e.kind != Kinds.FRIEND) aliveHostile++;
        }
        if (phase == P_FIGHT) Spawner.update(this, dt);
        EnemyAI.update(this, dt);
        Processing.tick(this, dt);
        updateOrbsAndBullets(dt);
        updateHazards(dt);
        updateRunClock(dt);
        updateCamera(dt);
        hints();
        while (enHi > 0 && !en[enHi - 1].alive) enHi--;
        checkLevel();
        if (phase == P_INTRO && phaseT > INTRO_T) phase = P_FIGHT;
    }

    private void updateBeams(float dt) { for (int i = 0; i < MAXB; i++) if (beamL[i] > 0) beamL[i] -= dt; }

    public void addBeam(float x, float y) {
        beamX[beamN] = x; beamY[beamN] = y; beamL[beamN] = 0.09f;
        beamN = (beamN + 1) % MAXB;
    }

    private void recordHistory(float dt) {
        histT -= dt;
        if (histT <= 0) { histT = 0.1f; histX[histI & 63] = pl.x; histY[histI & 63] = pl.y; histI++; }
    }

    /** Player position recorded roughly steps*0.1s ago. */
    public int histIndex(int steps) { return (histI - 1 - steps) & 63; }

    private void applyLive() {
        live.copyFrom(base);
        float pot = base.potency;
        live.power *= 1f + 0.06f * pPow;
        live.rate *= 1f + 0.06f * pRate;
        live.range *= 1f + 0.05f * pRange;
        live.collect *= 1f + 0.08f * pCol;
        live.dataMult *= 1f + 0.08f * pData;
        live.speed *= 1f + 0.04f * pSpd;
        if (pl.supp <= 0) {
            if (pl.abT[Defs.AB_OVERCLOCK] > 0) live.rate *= 1f + 0.6f * pot;
            if (pl.abT[Defs.AB_EXPANSION] > 0) live.range *= 1f + 0.6f * pot;
            live.rate *= 1f + cascadeStacks * base.cascade;
        } else {
            live.rate *= 0.8f;
        }
        if (base.adaptive) { if (lastTargets >= 6) live.rate *= 1.08f; else if (lastTargets <= 2) live.power *= 1.08f; }
        if (base.execute && in.mag > 0.9f) live.power *= 1.1f;
        if (pl.slowRift > 0) live.speed *= 0.5f;
        live.collect = Mx.max(live.collect, live.range * 0.9f);
    }

    private void movePlayer(float dt) {
        Player p = pl;
        boolean canAct = phase <= P_FIGHT;
        p.invuln = Mx.max(0f, p.invuln - dt);
        p.hitFlash = Mx.max(0f, p.hitFlash - dt);
        p.pulse = Mx.max(0f, p.pulse - dt * 6f);
        p.fieldOff = Mx.max(0f, p.fieldOff - dt);
        p.supp = Mx.max(0f, p.supp - dt);
        p.dashCd = Mx.max(0f, p.dashCd - dt);
        p.slowRift = Mx.max(0f, p.slowRift - dt);
        p.rot += dt * (0.6f + fieldEnergy * 2.2f);
        for (int i = 0; i < p.trA.length; i++) p.trA[i] = Mx.max(0f, p.trA[i] - dt * 4f);

        if (canAct && in.dash && p.dashCd <= 0f && p.dashT <= 0f) {
            float dx, dy;
            if (in.mag > 0.15f) { dx = in.jx / in.mag; dy = in.jy / in.mag; } else { dx = p.lastDx; dy = p.lastDy; }
            float l = Mx.len(dx, dy);
            if (l < 1e-4f) { dx = 0; dy = -1; l = 1; }
            p.dashDx = dx / l; p.dashDy = dy / l;
            p.dashT = 0.16f; p.invuln = Mx.max(p.invuln, 0.3f); p.dashCd = live.dashCd;
            dashCount++;
            env.sfx(Sfx.DASH, 0.8f);
            env.vibrate(10);
            burst(Particles.SPARK, p.x, p.y, 10, 3f, 0.3f, 2f);
        }
        if (p.dashT > 0) {
            p.dashT -= dt;
            p.vx = p.dashDx * 17f; p.vy = p.dashDy * 17f;
            p.trX[p.trI] = p.x; p.trY[p.trI] = p.y; p.trA[p.trI] = 1f; p.trI = (p.trI + 1) % p.trX.length;
        } else {
            float tx = in.jx * live.speed, ty = in.jy * live.speed;
            float a = Mx.min(1f, 16f * dt);
            p.vx += (tx - p.vx) * a; p.vy += (ty - p.vy) * a;
            if (in.mag > 0.12f) { p.lastDx = in.jx / in.mag; p.lastDy = in.jy / in.mag; }
        }
        p.x += p.vx * dt; p.y += p.vy * dt;
        moved += Mx.len(p.vx, p.vy) * dt;
        if (arena.resolve(p.x, p.y, p.r, true)) { p.x = arena.outX; p.y = arena.outY; }

        if (p.barrierDelay > 0) p.barrierDelay -= dt;
        else if (p.barrier < p.maxBarrier) p.barrier = Mx.min(p.maxBarrier, p.barrier + live.barrierRegen * dt);
    }

    private void updateOrbsAndBullets(float dt) {
        float R = live.collect * (stormT > 0 ? 3.2f : 1f);
        float spMul = live.magnet * (stormT > 0 ? 2.2f : 1f);
        if (phase >= P_END) {
            // the clock has run out: whatever is already being drawn in still counts; a cleared boss run vacuums everything
            R = endKind == END_CLEAR ? 1000f : live.collect * 2.5f; spMul = 3f;
        }
        float R2 = R * R, px = pl.x, py = pl.y;
        float fr = Mx.exp(-4f * dt), fb = Mx.exp(-3.5f * dt);
        for (int i = 0; i < orbs.hi; i++) {
            if (!orbs.on[i]) continue;
            float dx = px - orbs.x[i], dy = py - orbs.y[i], d2 = dx * dx + dy * dy;
            if (orbs.t[i] > 0) {
                orbs.t[i] -= dt;
                orbs.x[i] += orbs.vx[i] * dt; orbs.y[i] += orbs.vy[i] * dt;
                orbs.vx[i] *= fb; orbs.vy[i] *= fb;
                if (orbs.t[i] > 0.2f || d2 >= R2) continue;
            }
            if (d2 < R2) {
                float d = Mx.sqrt(d2);
                if (d < pl.r + 0.2f) { pickup(i); continue; }
                float f = 1f - d / R;
                float sp = (2.5f + 16f * f * f) * spMul;
                float a = Mx.min(1f, 9f * dt);
                orbs.vx[i] += (dx / d * sp - orbs.vx[i]) * a;
                orbs.vy[i] += (dy / d * sp - orbs.vy[i]) * a;
                orbs.x[i] += orbs.vx[i] * dt; orbs.y[i] += orbs.vy[i] * dt;
            } else {
                orbs.x[i] += orbs.vx[i] * dt; orbs.y[i] += orbs.vy[i] * dt;
                orbs.vx[i] *= fr; orbs.vy[i] *= fr;
            }
            orbs.x[i] = Mx.clamp(orbs.x[i], 0.2f, arena.W - 0.2f);
            orbs.y[i] = Mx.clamp(orbs.y[i], 0.2f, arena.H - 0.2f);
        }
        while (orbs.hi > 0 && !orbs.on[orbs.hi - 1]) orbs.hi--;

        for (int i = 0; i < bul.hi; i++) {
            if (!bul.on[i]) continue;
            float slow = 1f;
            if (pl.abT[Defs.AB_FREEZE] > 0 && Mx.len(bul.x[i] - pl.x, bul.y[i] - pl.y) < live.range * 1.35f) slow = 0.25f;
            else if (base.predict) slow = 0.9f;
            bul.x[i] += bul.vx[i] * dt * slow; bul.y[i] += bul.vy[i] * dt * slow;
            bul.life[i] -= dt;
            if (bul.life[i] <= 0) { bul.on[i] = false; continue; }
            if (phase <= P_FIGHT) {
                float dx = bul.x[i] - pl.x, dy = bul.y[i] - pl.y;
                float rr = pl.r + 0.12f;
                if (dx * dx + dy * dy < rr * rr) {
                    if (pl.invuln <= 0 && pl.dashT <= 0) {
                        if (bul.type[i] == Bullets.LOCK) { pl.fieldOff = 1.6f; env.sfx(Sfx.LOCK, 1f); pops.addText(pl.x, pl.y - 0.7f, "FIELD LOCKED", 0xFFC9B6FF, 0.5f); }
                        damagePlayer(bul.dmg[i], false);
                        bul.on[i] = false;
                    }
                    continue;
                }
                if (friend != null && friend.alive) {
                    float fx = bul.x[i] - friend.x, fy = bul.y[i] - friend.y;
                    if (fx * fx + fy * fy < 0.1f) { friendHit(bul.dmg[i]); bul.on[i] = false; continue; }
                }
            }
            if (arena.resolve(bul.x[i], bul.y[i], 0.08f, false)) bul.on[i] = false;
        }
        while (bul.hi > 0 && !bul.on[bul.hi - 1]) bul.hi--;
    }

    public void friendHit(float dmg) {
        if (friend == null || !friend.alive) return;
        if (base.friendGuard) { damagePlayer(dmg * 0.5f, true); return; }
        friend.hp -= dmg;
        friend.flash = 0.1f;
        if (friend.hp <= 0) kill(friend);
    }

    /** Consume the nearby lost process for Data (the dark choice). */
    public boolean consumeFriend() {
        if (friend == null || !friend.alive) return false;
        Enemy f = friend;
        f.alive = false; friend = null;
        float v = valScale() * 40f * live.dataMult;
        for (int i = 0; i < 6; i++) {
            float a = rng.ang();
            orbs.spawn(f.x, f.y, Mx.cos(a) * 4f, Mx.sin(a) * 4f, v / 6f, Defs.O_COMP);
        }
        burst(Particles.MAGENTA, f.x, f.y, 30, 6f, 0.8f, 2.5f);
        Karma.add(pf, Defs.K_AGGR, 0.07f); Karma.add(pf, Defs.K_CTRL, 0.04f); Karma.add(pf, Defs.K_COMP, -0.04f);
        Story.trust(pf, -0.08f);
        pf.flags |= Defs.F_CONSUME1;
        env.say(Dialogue.AI, "It was... part of us.");
        env.sfx(Sfx.PICK_BAD, 1f);
        return true;
    }

    private void updateHazards(float dt) {
        float dps = 5f * dmgScale();
        for (int i = 0; i < arena.nz; i++) {
            float dx = pl.x - arena.zx[i], dy = pl.y - arena.zy[i];
            if (dx * dx + dy * dy < arena.zr[i] * arena.zr[i] && pl.dashT <= 0) damagePlayer(dps * dt, true);
            arena.zt[i] -= dt;
            if (arena.zt[i] <= 0) {
                arena.zt[i] = 2.6f;
                if (orbs.count < orbs.cap * 0.6f) {
                    float a = rng.ang(), d = rng.f() * arena.zr[i] * 0.8f;
                    int oi = orbs.spawn(arena.zx[i] + Mx.cos(a) * d, arena.zy[i] + Mx.sin(a) * d, 0, 0, valScale() * 3f, Defs.O_CORR);
                    orbs.t[oi] = 0f;
                }
            }
        }
        if (phase == P_FIGHT && kind == Defs.RUN_HARVEST) {
            for (int i = 0; i < arena.nd; i++) {
                arena.dft[i] -= dt;
                if (arena.dft[i] > 0f) continue;
                arena.dft[i] = 10f;
                if (orbs.count < orbs.cap * 0.5f) seedField(i, 4 + rng.i(3), valScale() * 0.6f);
            }
        }
        for (int i = 0; i < arena.nv; i++) {
            if (arena.vdone[i]) continue;
            float d = Mx.len(pl.x - arena.vx[i], pl.y - arena.vy[i]);
            if (d < 7f) env.hint(Defs.H_VAULT, Lines.H_VAULT);
            if (d < live.range + 0.6f && pl.fieldOff <= 0) arena.vp[i] += dt / (2.6f / base.potency);
            else arena.vp[i] = Mx.max(0f, arena.vp[i] - dt * 0.25f);
            if (arena.vp[i] >= 1f) openVault(i);
        }
        for (int i = 0; i < arena.nm; i++) {
            if (arena.mgot[i]) continue;
            if (Mx.len(pl.x - arena.mx[i], pl.y - arena.my[i]) < 0.9f) { arena.mgot[i] = true; giveMemory(); }
        }
        for (int i = 0; i < 3; i++) {
            if (riftT[i] <= 0) continue;
            riftT[i] -= dt;
            float dx = pl.x - riftX[i], dy = pl.y - riftY[i];
            if (riftType[i] == 0 && dx * dx + dy * dy < riftR[i] * riftR[i]) pl.slowRift = 0.2f;
        }
    }

    private void openVault(int i) {
        arena.vdone[i] = true;
        float vs = valScale();
        float x = arena.vx[i], y = arena.vy[i];
        for (int k = 0; k < 8; k++) {
            float a = rng.ang(), sp = 3f + rng.f() * 3f;
            int ty = k < 2 ? Defs.O_RARE : (k < 6 ? Defs.O_COMP : Defs.O_BASIC);
            orbs.spawn(x, y, Mx.cos(a) * sp, Mx.sin(a) * sp, vs * 3f * live.dataMult * (ty == Defs.O_RARE ? 10f : 3.5f), ty);
        }
        if (rng.chance(0.3f * base.observe)) orbs.spawn(x, y, 0, 0, vs * 20f, Defs.O_UNK);
        burst(Particles.MAGENTA, x, y, 30, 6f, 0.7f, 2.4f);
        env.sfx(Sfx.DECRYPT, 1f);
        shake(8f);
    }

    /** The run clock, the scan ping and the countdown ticks. */
    private void updateRunClock(float dt) {
        if (kind == Defs.RUN_HARVEST && phase <= P_FIGHT) {
            // scan ping: a radar sweep that shows the whole network for a moment
            scanT -= dt;
            if (scanT <= 0f) {
                scanT = base.scanCd; pingA = 1f; pingR = 0f; revealT = 1.3f;
                env.sfx(Sfx.DECRYPT, 0.35f, 1.5f);
                if (phase == P_FIGHT) env.hint(Defs.H_SCAN, Lines.H_SCAN);
            }
        }
        if (phase != P_FIGHT || kind == Defs.RUN_VOID) return;
        if (!clockPaused) timeLeft -= dt;
        int sec = (int) Math.ceil(timeLeft);
        if (sec != lastSec) {
            lastSec = sec;
            if (sec <= 5 && sec > 0 && !clockPaused) env.sfx(Sfx.UI_TAP, 0.6f, 1.6f);
        }
        if (timeLeft <= 0f) { timeLeft = 0f; beginEnd(END_TIME); }
    }

    /** The run is over: the clock ran out, or the boss was destroyed. Enemies break apart and the screen settles into the results. */
    private void beginEnd(int how) {
        if (phase >= P_END) return;
        endKind = how; phase = P_END; phaseT = 0;
        for (int i = 0; i < enHi; i++) {
            Enemy e = en[i];
            if (!e.alive || e.kind == Kinds.FRIEND || e == friend || e.kind == Kinds.BOSS) continue;
            e.alive = false;
            burst(Particles.HOSTILE, e.x, e.y, 6, 4f, 0.5f, 2f);
            if (how == END_CLEAR && e.val > 0 && rng.chance(0.6f)) orbs.spawn(e.x, e.y, 0, 0, e.val * 0.5f * live.dataMult, Defs.O_BASIC);
        }
        bul.clear();
        lockN = 0; locked = 0;
        if (how == END_CLEAR) {
            env.sfx(Sfx.STAGE_CLEAR, 1f);
            env.say(Dialogue.AI, pf.flag(Defs.F_THANK) ? Lines.CLEAR[rng.i(Lines.CLEAR.length)] : Lines.THANK);
        } else {
            env.sfx(Sfx.EXTRACT, 1f);
            slowT = 0.8f;
            if (kind != Defs.RUN_VOID) env.say(Dialogue.AI, pf.flag(Defs.F_THANK) ? Lines.TIMEUP[rng.i(Lines.TIMEUP.length)] : Lines.THANK);
        }
        pf.flags |= Defs.F_THANK;
        if (friend != null && friend.alive) {
            Karma.add(pf, Defs.K_COMP, 0.06f); Karma.add(pf, Defs.K_LOY, 0.02f);
            Story.trust(pf, 0.05f);
            pf.flags |= Defs.F_FRIEND1;
            double bonus = valScale() * 25f * live.dataMult;
            addData(bonus);
            pops.addText(friend.x, friend.y - 0.6f, "SAVED", 0xFF9CFFC0, 0.6f);
        }
        if (flawless) Karma.add(pf, Defs.K_LOGIC, 0.012f);
    }

    /** Settles the run and banks the Data. Returns the amount banked. */
    public double finishRun() {
        double gain = run.bag;
        if (run.quotaMet && kind == Defs.RUN_HARVEST) { run.bonus = gain * 0.15; gain += run.bonus; }
        pf.bank += gain; pf.lifetime += gain; pf.timelineData += gain;
        pf.extracts++; pf.flags |= Defs.F_EXTRACT1;
        Karma.add(pf, Defs.K_LOGIC, 0.02f); Karma.add(pf, Defs.K_LOY, 0.01f);
        Story.trust(pf, 0.008f);
        // choosing tougher enemies reads as risk-taking, the gentlest setting as caution
        if (run.threat >= 3) { Karma.add(pf, Defs.K_RISK, 0.01f + 0.002f * run.threat); Karma.add(pf, Defs.K_AGGR, 0.006f); }
        else if (run.threat == 0 && kind == Defs.RUN_HARVEST) Karma.add(pf, Defs.K_LOGIC, 0.01f);
        if (kind == Defs.RUN_HARVEST && run.quotaMet && run.threat == pf.threatMax && pf.threatMax < Defs.THREAT_MAX) {
            pf.threatProg++;
            if (pf.threatProg >= Defs.THREAT_RUNS) { pf.threatMax++; pf.threatProg = 0; run.threatUnlocked = true; }
        }
        if (gain > pf.bestRun) pf.bestRun = gain;
        float mins = Mx.max(0.5f, run.time / 60f);
        pf.dpm = pf.dpm <= 0 ? gain / mins : pf.dpm * 0.7 + gain / mins * 0.3;
        double gx = Math.max(0.0, pf.xp - xp0) / mins;
        pf.xpm = pf.xpm <= 0 ? gx : pf.xpm * 0.7 + gx * 0.3;
        pf.maxDepth = Math.max(pf.maxDepth, run.threat);
        pf.playMs += (long) (run.time * 1000f);
        Story.updateFlags(pf);
        return gain;
    }

    // ------------------------------------------------------------------ camera, hints, levels

    public void updateCamera(float dt) {
        float ppu = sw / 10.5f;
        float rg = Mx.max(live.range, live.collect * 0.85f);
        if (rg < 0.1f) rg = 2.3f;
        float s = Mx.min(ppu, 0.40f * sw / rg);
        scale = Mx.damp(scale, s, 3f, dt);
        float hw = sw * 0.5f / scale, hh = sh * 0.5f / scale;
        float tx = pl.x + pl.vx * 0.25f, ty = pl.y + pl.vy * 0.25f;
        tx = arena.W > 2f * hw ? Mx.clamp(tx, hw, arena.W - hw) : arena.W * 0.5f;
        ty = arena.H > 2f * hh ? Mx.clamp(ty, hh, arena.H - hh) : arena.H * 0.5f;
        camX = Mx.damp(camX, tx, 9f, dt);
        camY = Mx.damp(camY, ty, 9f, dt);
    }

    private void hints() {
        if (phase != P_FIGHT) return;
        if (lastTargets >= 5) env.hint(Defs.H_COMBO, Lines.H_COMBO);
        if (stageTime > 20f && pf.runs >= 3) env.hint(Defs.H_ABIL, Lines.H_ABIL);
    }

    private void checkLevel() {
        int l = pf.level();
        if (l == lastLevel) return;
        boolean up = l > lastLevel;
        lastLevel = l;
        refreshStats(false);
        if (!up) return;
        levelUp = true;
        env.sfx(Sfx.LEVELUP, 1f);
        env.say(Dialogue.AI, Lines.LEVEL[rng.i(Lines.LEVEL.length)]);
        if (l >= 3 && !pf.flag(Defs.F_OUTSIDE)) { pf.flags |= Defs.F_OUTSIDE; env.say(Dialogue.AI, Lines.OUTSIDE); }
        if (l >= 10) pf.flags |= Defs.F_LEVEL10;
        int t = StatsCalc.coreTier(pf);
        if (t != lastTier) {
            lastTier = t; evolved = true;
            env.sfx(Sfx.EVOLVE, 1f);
            env.say(Dialogue.AI, Lines.EVOLVE);
            shake(14f); slowT = 0.5f;
            burst(Particles.WHITE, pl.x, pl.y, 50, 8f, 1f, 3f);
        }
    }

    public boolean isDone() { return phase == P_DONE; }

    public boolean friendNear() { return friend != null && friend.alive && Mx.len(friend.x - pl.x, friend.y - pl.y) < 2.6f; }
}
