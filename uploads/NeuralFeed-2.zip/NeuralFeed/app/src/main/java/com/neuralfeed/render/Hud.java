package com.neuralfeed.render;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Fmt;
import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.game.AbilitySys;
import com.neuralfeed.game.Arena;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.game.World;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Lines;
import com.neuralfeed.meta.Timelines;

/** Gameplay HUD: minimal top readouts, dialogue ticker and the touch controls. Control geometry is shared with the touch layer. */
public final class Hud {
    private final Gfx g;
    public float topInset;
    public boolean stickActive;
    public float stickBx, stickBy, stickX, stickY;
    private final char[] buf = new char[24];
    private static final String[] BOSS_UP = new String[Defs.B_N];
    static { for (int i = 0; i < Defs.B_N; i++) BOSS_UP[i] = Defs.B_NAMES[i].toUpperCase(); }
    private int cmbKey = -1, nodeKey = -1, clockKey = -1, lossKey = -1, killKey = -1;
    private String cmbS = "", nodeS = "", clockS = "", lossS = "", killS = "";
    private String wrapSrc = "";
    private final String[] wl = new String[4];
    private int wn;

    public static final float JOY_R = 62f, DASH_R = 36f, AB_R = 27f, CTX_R = 34f;

    public Hud(Gfx g) { this.g = g; }

    // ---- control geometry (px) ----
    public float cx(Profile p, int el, int sw) { return p.hud[el * 4] * sw; }
    public float cy(Profile p, int el, int sh) { return p.hud[el * 4 + 1] * sh; }
    public float rad(Profile p, int el) {
        float base = el == Defs.H_JOY ? JOY_R : el == Defs.H_DASH ? DASH_R : el == Defs.H_CTX ? CTX_R : AB_R;
        return base * g.dp * p.hud[el * 4 + 2];
    }
    public float alphaOf(Profile p, int el) { return p.hud[el * 4 + 3] * p.hudOpacity; }
    public boolean pauseHit(float x, float y, int sw) {
        float cx = sw - 28f * g.dp, cy = topInset + 26f * g.dp, r = 26f * g.dp;
        return (x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r;
    }

    // ---- dialogue ----
    private void wrap(String s, float maxW, float sp, android.graphics.Typeface tf) {
        wn = 0;
        String[] words = s.split(" ");
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String trial = line.length() == 0 ? words[i] : line + " " + words[i];
            if (g.measure(trial, sp, tf) > maxW && line.length() > 0 && wn < wl.length - 1) {
                wl[wn++] = line.toString();
                line.setLength(0);
                line.append(words[i]);
            } else {
                line.setLength(0);
                line.append(trial);
            }
        }
        if (line.length() > 0 && wn < wl.length) wl[wn++] = line.toString();
    }

    /** Draws the typewriter dialogue; returns the height used in px. */
    public float dialogue(Canvas c, Dialogue d, float x, float y, float maxW, int accent, int textCol) {
        if (!d.active) return 0f;
        float a = d.alpha();
        if (a <= 0.01f) return 0f;
        boolean ai = d.speaker == Dialogue.AI;
        float sp = ai ? 15f : 12.5f;
        android.graphics.Typeface tf = ai ? g.serifI : g.cond;
        if (d.cur != wrapSrc) { wrapSrc = d.cur; wrap(d.cur, maxW, sp, tf); }
        g.tracked(c, ai ? "AI" : "SYSTEM", x, y, 9f, 0.25f, Gfx.alpha(accent, (int) (220 * a)), Paint.Align.LEFT, g.condB);
        int left = d.visible();
        float ly = y + 20f * g.dp;
        for (int i = 0; i < wn && left > 0; i++) {
            String s = wl[i];
            int n = Math.min(left, s.length());
            left -= s.length() + 1;
            g.text(c, n == s.length() ? s : s.substring(0, n), x, ly, sp, Gfx.alpha(textCol, (int) (235 * a)), Paint.Align.LEFT, tf);
            ly += (sp + 5f) * g.dp;
        }
        return ly - y;
    }

    // ---- main draw ----
    public void draw(Canvas c, World w, Profile pf, Dialogue dlg, Theme th, int sw, int sh) {
        float dp = g.dp, ti = topInset;
        int acc = th.accent, tx = th.text;
        float m = 16f * dp;
        boolean timed = w.kind != Defs.RUN_VOID;
        float frac = timed ? Mx.clamp(w.timeLeft / Math.max(1f, w.timeMax), 0f, 1f) : 1f;
        boolean low = timed && w.timeLeft <= 10f && w.phase == World.P_FIGHT;
        boolean blink = low && ((int) (w.time * 4f) & 1) == 0;
        int clockCol = w.lostFlash > 0f || blink ? 0xFFFF5A5A : tx;
        // the run clock is the only thing that can run out: thin bar across the top
        g.rectFill(c, 0, 0, sw, 2f * dp, Gfx.alpha(acc, 28));
        g.rectFill(c, 0, 0, sw * frac, 2f * dp, low ? 0xFFFF5A5A : Gfx.alpha(acc, 200));
        // center: the clock
        g.tracked(c, w.kind == Defs.RUN_BOSS ? "BOSS RUN" : timed ? "TIME" : "VOID", sw * 0.5f, ti + 14f * dp, 9f, 0.3f, Gfx.alpha(tx, 130), Paint.Align.CENTER, g.cond);
        if (timed) {
            int sec = (int) Math.ceil(Math.max(0f, w.timeLeft));
            if (sec != clockKey) { clockKey = sec; clockS = Fmt.clock(sec); }
            g.text(c, clockS, sw * 0.5f, ti + 42f * dp, 32f, clockCol, Paint.Align.CENTER, g.condB);
            if (w.lostFlash > 0f) {
                int lk = (int) (w.lastLoss * 10f);
                if (lk != lossKey) { lossKey = lk; lossS = "-" + Fmt.secs(w.lastLoss); }
                g.text(c, lossS, sw * 0.5f + 52f * dp, ti + 40f * dp, 16f, Gfx.alpha(0xFFFF5A5A, (int) (255 * Mx.min(1f, w.lostFlash * 2.5f))), Paint.Align.LEFT, g.condB);
            }
        }
        // left: Data banked this run
        g.tracked(c, "DATA", m, ti + 14f * dp, 9f, 0.3f, Gfx.alpha(tx, 130), Paint.Align.LEFT, g.cond);
        int n = Fmt.chars(w.run.bag, buf);
        g.chars(c, buf, n, m, ti + 36f * dp, 20f, th.data, Paint.Align.LEFT, g.condB);
        String yr = pf.timeline >= 10 ? "TIMELINE 0" : Timelines.YEAR[pf.timeline];
        int nk = w.kind * 1000 + w.run.threat * 10 + pf.timeline;
        if (nk != nodeKey) { nodeKey = nk; nodeS = yr + (w.kind == Defs.RUN_VOID ? "" : "  \u00B7  THREAT " + w.run.threat); }
        g.tracked(c, nodeS, m, ti + 50f * dp, 8.5f, 0.12f, Gfx.alpha(tx, 120), Paint.Align.LEFT, g.cond);
        // pause button
        float pcx = sw - 28f * dp, pcy = ti + 26f * dp;
        g.ring(c, pcx, pcy, 14f * dp, 1.3f * dp, Gfx.alpha(tx, 130));
        g.seg(c, pcx - 3f * dp, pcy - 5f * dp, pcx - 3f * dp, pcy + 5f * dp, 1.8f * dp, Gfx.alpha(tx, 190));
        g.seg(c, pcx + 3f * dp, pcy - 5f * dp, pcx + 3f * dp, pcy + 5f * dp, 1.8f * dp, Gfx.alpha(tx, 190));
        // quota progress (harvest runs only)
        if (w.kind == Defs.RUN_HARVEST && !w.forceAlert) {
            int kk = w.run.kills * 1000 + w.run.quota;
            if (kk != killKey) { killKey = kk; killS = "QUOTA " + w.run.kills + "/" + w.run.quota; }
            g.tracked(c, killS, sw - m, ti + 54f * dp, 8.5f, 0.12f, w.run.quotaMet ? th.data : Gfx.alpha(tx, 140), Paint.Align.RIGHT, g.condB);
        }
        // barrier charges
        float y2 = ti + 64f * dp;
        int charges = (int) Math.ceil(w.pl.maxBarrier - 0.001f);
        if (charges > 0) {
            float pr = 3.2f * dp, gap = 9f * dp, x0 = sw * 0.5f - (charges - 1) * gap * 0.5f;
            for (int i = 0; i < charges; i++) {
                float fill = Mx.clamp(w.pl.barrier - i, 0f, 1f);
                g.ring(c, x0 + i * gap, y2, pr, 1.2f * dp, Gfx.alpha(0xFF9FE8FF, 90));
                if (fill > 0f) g.circle(c, x0 + i * gap, y2, pr * (0.35f + 0.65f * fill), 0xFF9FE8FF);
            }
            y2 += 10f * dp;
        }
        float bw = sw * 0.56f, bx = (sw - bw) * 0.5f;
        if (w.boss != null && w.boss.alive) {
            int id = w.boss.bossId;
            g.tracked(c, BOSS_UP[id], bx, y2 + 7f * dp, 9f, 0.2f, Gfx.alpha(th.hostile, 230), Paint.Align.LEFT, g.condB);
            g.rectFill(c, bx, y2 + 12f * dp, bw, 3f * dp, Gfx.alpha(th.hostile, 40));
            g.rectFill(c, bx, y2 + 12f * dp, bw * Mx.clamp(w.boss.hp / w.boss.maxHp, 0f, 1f), 3f * dp, th.hostile);
            if (w.boss.immune) g.tracked(c, "SHIELDED", bx + bw, y2 + 7f * dp, 9f, 0.2f, 0xFFD6C7FF, Paint.Align.RIGHT, g.condB);
            y2 += 26f * dp;
        }
        // status line
        float sy = y2 + 6f * dp;
        if (w.pl.fieldOff > 0f) { g.tracked(c, "LOCK JAMMED", sw * 0.5f, sy + 8f * dp, 10f, 0.25f, 0xFFC9B6FF, Paint.Align.CENTER, g.condB); }
        else if (w.pl.supp > 0f) { g.tracked(c, "BONUSES SUPPRESSED", sw * 0.5f, sy + 8f * dp, 10f, 0.25f, 0xFFB48CFF, Paint.Align.CENTER, g.condB); }
        else if (w.locked > 0 && w.phase == World.P_FIGHT) {
            int lk = (w.locked * 100 + w.live.locks) * 10 + w.comboTier;
            if (lk != cmbKey) {
                cmbKey = lk;
                cmbS = "LOCK " + w.locked + "/" + w.live.locks + (w.comboTier > 0 ? "  " + Lines.COMBO[w.comboTier].toUpperCase() : "");
            }
            int a = 150 + (int) (90 * w.comboFlash);
            g.tracked(c, cmbS, sw * 0.5f, sy + 8f * dp, 10f + w.comboTier, 0.25f, Gfx.alpha(w.comboTier >= 3 ? th.data : acc, a), Paint.Align.CENTER, g.condB);
        }
        if (w.patchT > 0f) g.tracked(c, w.lastPatch, sw * 0.5f, sy + 24f * dp, 9f, 0.2f, Gfx.alpha(th.data2, (int) (255 * Mx.min(1f, w.patchT))), Paint.Align.CENTER, g.condB);
        // dialogue
        dialogue(c, dlg, m, sy + 44f * dp, sw - 2f * m, acc, tx);
        arrows(c, w, th, sw, sh);
        controls(c, w, pf, th, sw, sh);
    }

    private void arrows(Canvas c, World w, Theme th, int sw, int sh) {
        float sc = w.scale, ox = sw * 0.5f - w.camX * sc, oy = sh * 0.5f - w.camY * sc;
        Arena ar = w.arena;
        for (int i = 0; i < ar.nm; i++) if (!ar.mgot[i] && !(ar.hidden && Math.abs(ar.mx[i] - ar.hx) < 0.1f)) arrow(c, ar.mx[i] * sc + ox, ar.my[i] * sc + oy, 0xFFD6C7FF, sw, sh);
        for (int i = 0; i < ar.nv; i++) if (!ar.vdone[i]) arrow(c, ar.vx[i] * sc + ox, ar.vy[i] * sc + oy, th.data2, sw, sh);
        if (w.boss != null && w.boss.alive) arrow(c, w.boss.x * sc + ox, w.boss.y * sc + oy, th.hostile, sw, sh);
        if (w.friend != null && w.friend.alive) arrow(c, w.friend.x * sc + ox, w.friend.y * sc + oy, 0xFF9CFFC0, sw, sh);
    }

    private void arrow(Canvas c, float x, float y, int col, int sw, int sh) {
        float m = 22f * g.dp;
        if (x > m && x < sw - m && y > topInset + m && y < sh - m) return;
        float cx = sw * 0.5f, cy = sh * 0.5f, dx = x - cx, dy = y - cy;
        float k = Math.min((sw * 0.5f - m) / Math.max(1f, Math.abs(dx)), (sh * 0.5f - m - topInset * 0.5f) / Math.max(1f, Math.abs(dy)));
        float px = cx + dx * k, py = cy + dy * k, d = Math.max(1f, Mx.len(dx, dy)), ux = dx / d, uy = dy / d, s = 7f * g.dp;
        g.lb.line(px + ux * s, py + uy * s, px - ux * s - uy * s, py - uy * s + ux * s);
        g.lb.line(px + ux * s, py + uy * s, px - ux * s + uy * s, py - uy * s - ux * s);
        g.line.setStrokeWidth(2f * g.dp); g.line.setColor(Gfx.alpha(col, 200));
        g.lb.lines(c, g.line);
    }

    private void controls(Canvas c, World w, Profile pf, Theme th, int sw, int sh) {
        float dp = g.dp;
        int acc = th.accent, tx = th.text;
        // joystick
        float a = alphaOf(pf, Defs.H_JOY), r = rad(pf, Defs.H_JOY);
        float jx = cx(pf, Defs.H_JOY, sw), jy = cy(pf, Defs.H_JOY, sh);
        if (stickActive && pf.floatStick) { jx = stickBx; jy = stickBy; }
        g.circle(c, jx, jy, r, Gfx.alpha(acc, (int) (14 * a)));
        g.ring(c, jx, jy, r, 1.4f * dp, Gfx.alpha(tx, (int) (110 * a)));
        float kx = jx + stickX * r * 0.78f, ky = jy + stickY * r * 0.78f;
        g.circle(c, kx, ky, r * 0.4f, Gfx.alpha(acc, (int) ((stickActive ? 150 : 90) * a)));
        g.ring(c, kx, ky, r * 0.4f, 1.2f * dp, Gfx.alpha(tx, (int) (140 * a)));
        // dash
        a = alphaOf(pf, Defs.H_DASH); r = rad(pf, Defs.H_DASH);
        float dx = cx(pf, Defs.H_DASH, sw), dy = cy(pf, Defs.H_DASH, sh);
        float ready = w.pl.dashCd <= 0f ? 1f : 0f;
        g.circle(c, dx, dy, r, Gfx.alpha(acc, (int) ((16 + 22 * ready) * a)));
        g.ring(c, dx, dy, r, 1.6f * dp, Gfx.alpha(ready > 0 ? acc : tx, (int) ((ready > 0 ? 220 : 110) * a)));
        for (int k = 0; k < 2; k++) {
            float o = (k - 0.5f) * r * 0.42f;
            g.seg(c, dx - r * 0.3f, dy + o + r * 0.12f, dx, dy + o - r * 0.14f, 2.2f * dp, Gfx.alpha(tx, (int) (210 * a)));
            g.seg(c, dx + r * 0.3f, dy + o + r * 0.12f, dx, dy + o - r * 0.14f, 2.2f * dp, Gfx.alpha(tx, (int) (210 * a)));
        }
        if (w.pl.dashCd > 0f) g.arc(c, dx, dy, r * 0.5f, -90f, 360f * Mx.clamp(w.pl.dashCd / Math.max(0.1f, w.live.dashCd), 0f, 1f), r, Gfx.alpha(0xFF000000, (int) (110 * a)));
        // abilities
        for (int k = 0; k < 3; k++) {
            int ab = AbilitySys.slotAbility(pf, k);
            if (ab < 0) continue;
            int el = Defs.H_AB1 + k;
            a = alphaOf(pf, el); r = rad(pf, el);
            float bx = cx(pf, el, sw), by = cy(pf, el, sh);
            boolean active = w.pl.abT[ab] > 0f, rdy = w.pl.abCd[k] <= 0f;
            g.circle(c, bx, by, r, Gfx.alpha(acc, (int) ((active ? 60 : (rdy ? 26 : 10)) * a)));
            g.ring(c, bx, by, r, 1.5f * dp, Gfx.alpha(active ? th.data : (rdy ? acc : tx), (int) ((rdy || active ? 230 : 100) * a)));
            g.text(c, Defs.AB_SHORT[ab], bx, by + 4f * dp, 11f, Gfx.alpha(tx, (int) ((rdy || active ? 240 : 120) * a)), Paint.Align.CENTER, g.condB);
            if (!rdy) g.arc(c, bx, by, r * 0.5f, -90f, 360f * Mx.clamp(w.pl.abCd[k] / Math.max(0.1f, AbilitySys.cooldown(w, ab)), 0f, 1f), r, Gfx.alpha(0xFF000000, (int) (120 * a)));
            if (active && Defs.AB_DUR[ab] > 0f) g.arc(c, bx, by, r * 1.18f, -90f, 360f * Mx.clamp(w.pl.abT[ab] / (Defs.AB_DUR[ab] * w.base.potency), 0f, 1f), 2f * dp, Gfx.alpha(th.data, (int) (220 * a)));
        }
        // contextual action
        if (w.friendNear()) {
            a = alphaOf(pf, Defs.H_CTX); r = rad(pf, Defs.H_CTX);
            float bx = cx(pf, Defs.H_CTX, sw), by = cy(pf, Defs.H_CTX, sh);
            g.circle(c, bx, by, r, Gfx.alpha(0xFFFF7ADF, (int) (30 * a)));
            g.ring(c, bx, by, r, 1.6f * dp, Gfx.alpha(0xFFFF7ADF, (int) (230 * a)));
            g.text(c, "CONSUME", bx, by + 4f * dp, 10f, Gfx.alpha(tx, (int) (240 * a)), Paint.Align.CENTER, g.condB);
            g.text(c, "or keep it safe", bx, by - r - 6f * dp, 10f, Gfx.alpha(0xFF9CFFC0, (int) (220 * a)), Paint.Align.CENTER, g.cond);
        }
    }
}
