package com.neuralfeed.audio;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Real-time mixer: pooled SFX voices + hum + music into one 22.05 kHz mono AudioTrack. */
public final class Mixer implements Runnable {
    public static final int SR = Synth.SR, CH = 512, NV = 24;
    public static final int BUS_SFX = 0, BUS_VOICE = 1;

    public volatile float master = 0.8f, musicVol = 0.55f, sfxVol = 0.9f, voiceVol = 0.8f;
    public volatile float humLevel, humEnergy;
    /** Music and hum level (0..1) while the AI is speaking; the mix eases towards it. */
    public volatile float duck = 1f;
    private float duckNow = 1f;
    public final Music music = new Music();

    private final short[][] vb = new short[NV][];
    private final float[] vpos = new float[NV], vstep = new float[NV], vgain = new float[NV];
    private final int[] vbus = new int[NV];
    private final Object lock = new Object();
    private final float[] mix = new float[CH];
    private final short[] out = new short[CH];
    private float h1, h2, hamp;
    private AudioTrack track;
    private Thread thread;
    private volatile boolean running, paused;

    public void play(short[] buf, float gain, float pitch, int bus) {
        if (buf == null) return;
        synchronized (lock) {
            int slot = -1;
            float oldest = -1f;
            for (int i = 0; i < NV; i++) {
                if (vb[i] == null) { slot = i; break; }
                float frac = vpos[i] / vb[i].length;
                if (frac > oldest) { oldest = frac; slot = i; }
            }
            vb[slot] = buf; vpos[slot] = 0f; vstep[slot] = pitch; vgain[slot] = gain; vbus[slot] = bus;
        }
    }

    /** Renders n samples (<= CH) of 16-bit mono into dst. Safe to call from tests without an AudioTrack. */
    public void render(short[] dst, int n) {
        for (int i = 0; i < n; i++) mix[i] = 0f;
        float m = master;
        duckNow += (duck - duckNow) * 0.08f;
        synchronized (lock) {
            for (int v = 0; v < NV; v++) {
                short[] b = vb[v];
                if (b == null) continue;
                float g = vgain[v] * m * (vbus[v] == BUS_VOICE ? voiceVol : sfxVol) * (1f / 32768f);
                float pos = vpos[v], st = vstep[v];
                int len = b.length - 1;
                int i = 0;
                for (; i < n; i++) {
                    int p = (int) pos;
                    if (p >= len) { vb[v] = null; break; }
                    float fr = pos - p;
                    mix[i] += (b[p] + (b[p + 1] - b[p]) * fr) * g;
                    pos += st;
                }
                vpos[v] = pos;
            }
        }
        float hl = humLevel, he = humEnergy;
        float f1 = 55f + 25f * he;
        for (int i = 0; i < n; i++) {
            hamp += (hl * 0.5f - hamp) * 0.0006f;
            h1 += f1 / SR; if (h1 >= 1f) h1 -= 1f;
            h2 += f1 * 1.503f / SR; if (h2 >= 1f) h2 -= 1f;
            mix[i] += ((float) Math.sin(h1 * 6.2831853f) * 0.6f + (float) Math.sin(h2 * 6.2831853f) * 0.25f) * hamp * 0.12f * m * sfxVol * duckNow;
        }
        music.render(mix, n, musicVol * m * duckNow);
        for (int i = 0; i < n; i++) {
            float x = mix[i] * 0.9f;
            if (x > 1f) x = 1f; else if (x < -1f) x = -1f;
            x = x * (1.5f - 0.5f * x * x);
            dst[i] = (short) (x * 32000f);
        }
    }

    public void start() {
        if (running) return;
        try {
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
            AudioFormat fmt = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
            int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int size = Math.max(min * 2, CH * 2 * 4);
            track = new AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(fmt).setBufferSizeInBytes(size).setTransferMode(AudioTrack.MODE_STREAM).build();
            track.play();
        } catch (RuntimeException e) {
            track = null;
            return;
        }
        running = true;
        thread = new Thread(this, "nf-audio");
        thread.setPriority(Thread.MAX_PRIORITY);
        thread.setDaemon(true);
        thread.start();
    }

    @Override
    public void run() {
        while (running) {
            if (paused) { try { Thread.sleep(40); } catch (InterruptedException e) { return; } continue; }
            render(out, CH);
            try {
                int w = track.write(out, 0, CH);
                if (w < 0) { try { Thread.sleep(40); } catch (InterruptedException e) { return; } }
            } catch (RuntimeException e) {
                return;
            }
        }
    }

    public void setPaused(boolean p) {
        paused = p;
        if (track != null) { try { if (p) track.pause(); else track.play(); } catch (RuntimeException ignored) { /* ignore */ } }
    }

    public void stop() {
        running = false;
        if (track != null) {
            try { track.stop(); track.release(); } catch (RuntimeException ignored) { /* ignore */ }
            track = null;
        }
    }
}
