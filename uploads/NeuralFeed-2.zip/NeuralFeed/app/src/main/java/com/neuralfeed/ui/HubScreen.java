package com.neuralfeed.ui;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.neuralfeed.core.Fmt;
import com.neuralfeed.game.Dialogue;
import com.neuralfeed.core.Mx;
import com.neuralfeed.data.Profile;
import com.neuralfeed.meta.StatsCalc;
import com.neuralfeed.meta.Timelines;
import com.neuralfeed.meta.Upgrades;
import com.neuralfeed.render.Gfx;
import com.neuralfeed.render.Theme;
import com.neuralfeed.render.Ui;

/** Between-run hub: header, dialogue strip, five tabs. */
public final class HubScreen extends Screen {
    private static final String[] TABS = {"RUN", "CORE", "MIND", "TIME", "SYSTEM"};
    private final Tab[] tabs = new Tab[5];
    private final float[] scroll = new float[5];
    int tab;
    private float t;

    public HubScreen(App app) {
        super(app);
        tabs[0] = new RunTab(app, this);
        tabs[1] = new CoreTab(app, this);
        tabs[2] = new MindTab(app, this);
        tabs[3] = new TimeTab(app, this);
        tabs[4] = new SysTab(app, this);
    }

    @Override public void onShow() {
        app.wr.setTheme(app.pf.timeline);
        app.audio.music(0.12f, 0f, 0f, app.pf.paradox / 100f, 0f, 0f, 1f);
        app.audio.field(0f);
        app.refreshIdeology();
        app.checkRelationship();
        int card = Tutorial.hubCard(app.pf);
        if (card != 0) showCard(card);
        else if (app.pf.bank >= 12) app.hint(com.neuralfeed.meta.Defs.H_CORE, com.neuralfeed.meta.Lines.H_CORE);
        app.saveNow();
    }

    @Override public void update(float dt) { t += dt; }

    /** Opens the tab a coach card is about and has the AI explain it. */
    private void showCard(int card) {
        tab = card == 1 ? 1 : 0;
        app.dlg.clearQueue();
        app.say(Dialogue.AI, Tutorial.hubLine(card));
    }

    /** A short explanation pinned to the top of the content area, for the two things the training run cannot show. */
    private void coachCard(Canvas c, Gfx g, Ui ui, Theme th, float x, float y, float w, int card) {
        float dp = g.dp, ch = 104f * dp;
        g.rrect(c, x - 6f * dp, y, w + 12f * dp, ch, 12f * dp, Gfx.alpha(th.bg, 255));
        g.rrectLine(c, x - 6f * dp, y, w + 12f * dp, ch, 12f * dp, 1.4f * dp, Gfx.alpha(th.accent, 220));
        ui.button(c, 1402, "", x - 6f * dp, y, w + 12f * dp, ch, true, Ui.ST_QUIET, 0x00000000, 0x00000000, th.bg);
        g.tracked(c, Tutorial.hubTitle(card), x + 8f * dp, y + 20f * dp, 9.5f, 0.3f, th.accent, Paint.Align.LEFT, g.condB);
        if (cardFor != card) { cardFor = card; cardLines = TextUtil.wrap(g, Tutorial.hubText(card), w - 130f * dp, 12.5f, g.cond); }
        float ty = y + 40f * dp;
        for (String s : cardLines) { g.text(c, s, x + 8f * dp, ty, 12.5f, th.text, Paint.Align.LEFT, g.cond); ty += 16f * dp; }
        ui.button(c, 1401, "GOT IT", x + w - 104f * dp, y + ch - 50f * dp, 104f * dp, 40f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
    }

    private int cardFor = -1;
    private String[] cardLines;

    @Override public void draw(Canvas c) {
        Gfx g = app.gfx;
        Ui ui = app.ui;
        Theme th = app.wr.th;
        Profile pf = app.pf;
        float dp = g.dp;
        int w = app.w, h = app.h;
        ui.begin();
        c.drawColor(th.bg);
        // faint lattice
        if (g.quality >= 1) {
            float sp = 40f * dp;
            float off = (t * 6f * dp) % sp;
            for (float y = -sp + off; y < h; y += sp) g.lb.line(0, y, w, y);
            g.line.setStrokeWidth(dp * 0.7f); g.line.setColor(Gfx.alpha(th.grid, 110));
            g.lb.lines(c, g.line);
        }
        float m = 18f * dp, ti = app.topInset;
        // header
        String yr = pf.timeline >= 10 ? "TIMELINE 0" : Timelines.YEAR[pf.timeline];
        g.text(c, yr, m, ti + 30f * dp, 26f, th.text, Paint.Align.LEFT, g.condB);
        g.tracked(c, Timelines.NAME[pf.timeline].toUpperCase() + (pf.cycle > 0 ? "  \u00b7  LOOP " + (pf.cycle + 1) : ""), m, ti + 46f * dp, 9.5f, 0.2f, Gfx.alpha(th.text, 140), Paint.Align.LEFT, g.cond);
        g.tracked(c, "DATA", w - m, ti + 16f * dp, 9f, 0.3f, Gfx.alpha(th.text, 130), Paint.Align.RIGHT, g.cond);
        g.text(c, Fmt.num(pf.bank), w - m, ti + 38f * dp, 22f, th.data, Paint.Align.RIGHT, g.condB);
        int lvl = pf.level();
        g.tracked(c, "AI LEVEL " + lvl + "  \u00b7  CORE " + (StatsCalc.coreTier(pf) + 1 < 10 ? "0" : "") + (StatsCalc.coreTier(pf) + 1), w - m, ti + 52f * dp, 9f, 0.2f, Gfx.alpha(th.text, 150), Paint.Align.RIGHT, g.cond);
        float by = ti + 60f * dp;
        g.rectFill(c, m, by, w - 2f * m, 2f * dp, Gfx.alpha(th.text, 26));
        g.rectFill(c, m, by, (w - 2f * m) * pf.levelProgress(), 2f * dp, th.accent);
        // dialogue
        app.hud.dialogue(c, app.dlg, m, by + 22f * dp, w - 2f * m, th.accent, th.text);
        // content
        float cy = by + 70f * dp, tabH = 58f * dp, ch = h - cy - tabH;
        Tab tb = tabs[tab];
        scroll[tab] = Mx.clamp(scroll[tab], 0f, Math.max(0f, tb.contentH - ch));
        c.save();
        c.clipRect(0, cy, w, cy + ch);
        tb.draw(c, m, cy, w - 2f * m, ch, scroll[tab]);
        c.restore();
        scroll[tab] = Mx.clamp(scroll[tab], 0f, Math.max(0f, tb.contentH - ch));
        if (tb.contentH > ch + 4f * dp) {
            float bar = ch * ch / tb.contentH;
            g.rectFill(c, w - 4f * dp, cy + (ch - bar) * (scroll[tab] / (tb.contentH - ch)), 2f * dp, bar, Gfx.alpha(th.text, 50));
        }
        // tab bar
        g.rectFill(c, 0, h - tabH, w, tabH, Gfx.alpha(0xFF000000, 120));
        g.rectFill(c, 0, h - tabH, w, dp, Gfx.alpha(th.text, 30));
        float tw = w / 5f;
        for (int i = 0; i < 5; i++) {
            boolean on = i == tab;
            float tx = tw * i + tw * 0.5f;
            g.tracked(c, TABS[i], tx, h - tabH * 0.5f + 4f * dp, 11f, 0.2f, on ? th.text : Gfx.alpha(th.text, 120), Paint.Align.CENTER, on ? g.condB : g.cond);
            if (on) g.rectFill(c, tx - 14f * dp, h - tabH + 2f * dp, 28f * dp, 2f * dp, th.accent);
            boolean dot = (i == 1 && Upgrades.anyAffordable(pf)) || (i == 3 && Timelines.canActivate(pf));
            if (dot) g.circle(c, tx + 24f * dp, h - tabH * 0.5f - 8f * dp, 3.2f * dp, th.data);
            ui.button(c, 1 + i, "", tw * i, h - tabH, tw, tabH, true, Ui.ST_QUIET, th.accent, 0x00000000, th.bg);
        }
        int card = Tutorial.hubCard(pf);
        if (card != 0 && app.offline == null) coachCard(c, g, ui, th, m, cy, w - 2f * m, card);
        if (app.offline != null) offlineCard(c, g, ui, th, w, h);
    }

    private void offlineCard(Canvas c, Gfx g, Ui ui, Theme th, int w, int h) {
        float dp = g.dp, cw = w - 56f * dp, ch = 250f * dp, x = 28f * dp, y = h * 0.5f - ch * 0.55f;
        g.rectFill(c, 0, 0, w, h, Gfx.alpha(0xFF000000, 190));
        g.rrect(c, x, y, cw, ch, 14f * dp, Gfx.alpha(th.bg, 245));
        g.rrectLine(c, x, y, cw, ch, 14f * dp, 1.3f * dp, Gfx.alpha(th.accent, 200));
        App.Offline o = app.offline;
        g.tracked(c, "TEMPORAL ABSENCE DETECTED", w * 0.5f, y + 34f * dp, 12f, 0.2f, th.accent, Paint.Align.CENTER, g.condB);
        g.text(c, "Away: " + Fmt.dur(o.secs), w * 0.5f, y + 72f * dp, 17f, th.text, Paint.Align.CENTER, g.cond);
        g.text(c, "Data recovered: +" + Fmt.num(o.data), w * 0.5f, y + 104f * dp, 17f, th.data, Paint.Align.CENTER, g.cond);
        g.text(c, "Training: +" + Fmt.num(o.xp), w * 0.5f, y + 134f * dp, 17f, th.text, Paint.Align.CENTER, g.cond);
        g.text(c, "Memory fragments: " + o.mem, w * 0.5f, y + 164f * dp, 17f, th.text, Paint.Align.CENTER, g.cond);
        ui.button(c, 90, "ABSORB", x + 24f * dp, y + ch - 62f * dp, cw - 48f * dp, 44f * dp, true, Ui.ST_PRIMARY, th.accent, th.text, th.bg);
    }

    @Override public void down(float x, float y, int id) { app.ui.down(x, y); }

    @Override public void move(float x, float y, int id) {
        app.ui.move(x, y);
        if (app.offline == null && app.ui.scrolling()) scroll[tab] -= app.ui.dragDy;
    }

    @Override public void up(float x, float y, int id) {
        int hit = app.ui.up(x, y);
        if (hit < 0) return;
        if (app.offline != null) {
            if (hit == 90) { app.offline = null; app.audio.sfx(com.neuralfeed.audio.Sfx.UI_BUY, 0.8f); app.saveNow(); }
            return;
        }
        if (hit == 1401) {
            Tutorial.advanceHub(app.pf);
            app.sfx(com.neuralfeed.audio.Sfx.UI_BUY, 0.8f);
            int next = Tutorial.hubCard(app.pf);
            if (next != 0) showCard(next);
            app.saveNow();
            return;
        }
        if (hit == 1402) return;
        if (hit >= 1 && hit <= 5) {
            if (tab != hit - 1) { tab = hit - 1; app.tap(); }
            return;
        }
        tabs[tab].click(hit);
    }

    void jumpTo(int t) { tab = t; }
}
