package com.neuralfeed.game;

import com.neuralfeed.core.Mx;
import com.neuralfeed.meta.Defs;
import com.neuralfeed.meta.Timelines;

/** One timed run: its kind, the enemy strength ("threat") chosen for it, and the scaling that follows from that. */
public final class Run {
    /** Enemy hit points grow by this factor per threat level. Reward grows more slowly, so higher threat only pays if the build can keep up. */
    public static final float THREAT_HP = 1.30f;
    /** Data per enemy grows with enemy health to this power: below 1, so tougher enemies are richer but never free. */
    public static final float DATA_EXP = 0.7f;

    public int kind = Defs.RUN_HARVEST, threat, quota;
    public double bag, bonus;
    public int kills, bossKills, memories, unknown, patches, hits;
    /** Seconds elapsed, and total seconds lost to hits. */
    public float time, lost;
    public boolean quotaMet, threatUnlocked;

    public void reset(int kind, int threat, int timeline) {
        this.kind = kind; this.threat = threat;
        bag = 0; bonus = 0; kills = 0; bossKills = 0; memories = 0; unknown = 0; patches = 0; hits = 0;
        time = 0; lost = 0; quotaMet = false; threatUnlocked = false;
        quota = quotaFor(threat, timeline);
    }

    /** Enemies to process in one run to count as meeting the quota (meeting it at your top level unlocks the next one). */
    public static int quotaFor(int threat, int timeline) { return (int) (90f * Mx.pow(1.22f, threat)) + 40 * timeline; }

    public static float hpMul(int threat) { return Mx.pow(THREAT_HP, threat); }

    /** Extra Data on top of what tougher enemies already drop. */
    public static float bonusMul(int threat) { return 1f + 0.05f * threat; }

    /** Total Data multiplier of a threat level relative to level 0 (what the player is shown). */
    public static float dataMul(int threat) { return Mx.pow(Mx.pow(THREAT_HP, DATA_EXP), threat) * bonusMul(threat); }

    public float hpScale(int tl) { return Timelines.hpMul(tl) * hpMul(threat); }
    public float dmgScale(int tl) { return 1f + 0.6f * tl + 0.15f * threat; }
    public float valScale(int tl) { return Mx.pow(Timelines.hpMul(tl), 0.88f) * Mx.pow(hpMul(threat), DATA_EXP) * bonusMul(threat); }
    public float speedScale() { return Mx.min(1.6f, 1f + 0.03f * threat); }
    public float spawnScale() { return Mx.min(1.8f, 1f + 0.06f * threat); }
    /** How early the nastier enemy kinds appear (progress is 0..1 through the run). */
    public int tier(int tl, float progress) { return Mx.mini(9, (int) (2 * tl + 0.5f * threat + 3f * progress)); }
}
