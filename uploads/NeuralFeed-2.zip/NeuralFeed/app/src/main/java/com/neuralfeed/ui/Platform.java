package com.neuralfeed.ui;

/** Things only the Android activity can do. Implemented by MainActivity. */
public interface Platform {
    void vibrate(int ms);
    void copy(String text);
    String paste();
    void share(String text);
    void toast(String text);
    /** Spoken lines through the system text-to-speech engine (see audio.Speech). */
    boolean speechReady();
    boolean speaking();
    void speak(String text, float pitch, float rate, float volume);
    void stopSpeech();
}
