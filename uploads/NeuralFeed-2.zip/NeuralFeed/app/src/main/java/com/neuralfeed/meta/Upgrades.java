package com.neuralfeed.meta;

import com.neuralfeed.data.Profile;

/**
 * The skill tree: permanent upgrades bought with Data between runs.
 * Three branches fan out from the core: FINDER (lock-on attack), HARVEST (vision and Data) and CHRONO (the run clock).
 * Node coordinates are in tree units: x in 0..6 (left to right), y in rows (0 is the core).
 */
public final class Upgrades {
    private Upgrades() {}

    public static final int B_FINDER = 0, B_HARVEST = 1, B_CHRONO = 2;
    public static final String[] BRANCH = {"FINDER", "HARVEST", "CHRONO"};
    public static final String[] BRANCH_DESC = {"Lock-on attack", "Vision and Data", "The run clock"};
    public static final float ROOT_X = 3f, ROOT_Y = 0f, WIDTH = 6f, ROWS = 5f;

    public static final class Up {
        public final int id, max, req, branch;
        public final String name, tag, desc;
        public final double base, growth;
        public final float x, y;
        /** Prerequisites as {nodeId, minLevel} pairs; empty means the node hangs directly off the core. */
        public final int[][] pre;

        Up(int id, String tag, String name, String desc, int max, double base, double growth, int req, int branch, float x, float y, int[][] pre) {
            this.id = id; this.tag = tag; this.name = name; this.desc = desc; this.max = max; this.base = base; this.growth = growth;
            this.req = req; this.branch = branch; this.x = x; this.y = y; this.pre = pre;
        }

        public double cost(int level) { return base * Math.pow(growth, level); }
    }

    /** Tree-wide price multiplier (the run economy is tuned against this). */
    private static final double COST_SCALE = 2.0;

    public static final Up[] ALL = new Up[Defs.UP_N];

    private static int[][] pre(int... v) {
        int[][] r = new int[v.length / 2][2];
        for (int i = 0; i < r.length; i++) { r[i][0] = v[i * 2]; r[i][1] = v[i * 2 + 1]; }
        return r;
    }

    private static void def(int id, String tag, String name, String desc, int max, double base, double growth, int req, int branch, float x, float y, int... pre) {
        ALL[id] = new Up(id, tag, name, desc, max, base * COST_SCALE, growth, req, branch, x, y, pre(pre));
    }

    static {
        // FINDER: the lock-on attack
        def(Defs.UP_POWER, "PWR", "Lock power", "+15% damage on every lock", 100, 12, 1.19, 1, B_FINDER, 1.0f, 1);
        def(Defs.UP_RATE, "RTE", "Lock rate", "+4.5% lock ticks per second", 60, 20, 1.23, 1, B_FINDER, 0.4f, 2, Defs.UP_POWER, 3);
        def(Defs.UP_LOCKS, "LCK", "Multi-lock", "+1 enemy locked at the same time", 8, 90, 1.7, 2, B_FINDER, 1.6f, 2, Defs.UP_POWER, 3);
        def(Defs.UP_RANGE, "RNG", "Lock range", "+3.5% lock radius", 40, 25, 1.27, 1, B_FINDER, 0.4f, 3, Defs.UP_RATE, 3);
        def(Defs.UP_CRIT, "CRT", "Critical lock", "+1% crit chance, +3% crit power", 30, 45, 1.25, 1, B_FINDER, 1.6f, 3, Defs.UP_LOCKS, 2);
        def(Defs.UP_DEEP, "DEP", "Deep scan", "Bonus damage to targets close to the core", 20, 400, 1.35, 3, B_FINDER, 0.4f, 4, Defs.UP_RANGE, 3);
        def(Defs.UP_EDGE, "EDG", "Edge breaker", "Bonus damage to targets at the lock edge", 20, 400, 1.35, 3, B_FINDER, 1.6f, 4, Defs.UP_CRIT, 3);
        def(Defs.UP_PRESSURE, "PRS", "Core pressure", "Large bonus right next to the core", 20, 700, 1.38, 5, B_FINDER, 0.4f, 5, Defs.UP_DEEP, 3);
        def(Defs.UP_CASCADE, "CAS", "Neural cascade", "Each kill briefly stacks lock rate", 20, 900, 1.40, 7, B_FINDER, 1.6f, 5, Defs.UP_EDGE, 3);

        // HARVEST: seeing and collecting Data
        def(Defs.UP_DATA, "DAT", "Data multiplier", "+8% Data from everything", 80, 60, 1.24, 1, B_HARVEST, 3.0f, 1);
        def(Defs.UP_COLLECT, "COL", "Collection range", "+4% pickup radius", 40, 15, 1.22, 1, B_HARVEST, 2.4f, 2, Defs.UP_DATA, 3);
        def(Defs.UP_VISION, "VIS", "Vision radius", "+0.28 vision in the dark network", 20, 30, 1.22, 1, B_HARVEST, 3.6f, 2, Defs.UP_DATA, 3);
        def(Defs.UP_MAGNET, "MAG", "Data magnet", "Fragments are pulled harder and farther", 30, 35, 1.24, 1, B_HARVEST, 2.4f, 3, Defs.UP_COLLECT, 3);
        def(Defs.UP_SCAN, "SCN", "Scan ping", "Faster ping that reveals the whole network", 18, 50, 1.24, 2, B_HARVEST, 3.6f, 3, Defs.UP_VISION, 3);
        def(Defs.UP_RARE, "RAR", "Rare finder", "+12% chance that Data drops rare", 20, 80, 1.28, 3, B_HARVEST, 3.0f, 4, Defs.UP_MAGNET, 3, Defs.UP_SCAN, 3);
        def(Defs.UP_PATCH, "PTC", "Patch protocol", "Temporary patches arrive after fewer kills", 10, 1500, 1.45, 9, B_HARVEST, 3.0f, 5, Defs.UP_RARE, 3);

        // CHRONO: the run clock
        def(Defs.UP_TIME, "TIM", "Run time", "+1.5 seconds on the run clock", 40, 18, 1.17, 1, B_CHRONO, 5.0f, 1);
        def(Defs.UP_SPEED, "SPD", "Movement speed", "+1.6% speed", 25, 40, 1.28, 1, B_CHRONO, 4.4f, 2, Defs.UP_TIME, 3);
        def(Defs.UP_GUARD, "GRD", "Time guard", "-4% time lost per hit", 12, 40, 1.24, 1, B_CHRONO, 5.6f, 2, Defs.UP_TIME, 3);
        def(Defs.UP_DASH, "DSH", "Dash cooldown", "-3% cooldown", 20, 50, 1.30, 1, B_CHRONO, 4.4f, 3, Defs.UP_SPEED, 3);
        def(Defs.UP_BARRIER, "BAR", "Barrier", "A charge blocks one hit completely, then recharges", 20, 60, 1.35, 2, B_CHRONO, 5.6f, 3, Defs.UP_GUARD, 3);
        def(Defs.UP_TIMEKILL, "SIP", "Time siphon", "Each kill adds a little time (capped per run)", 12, 160, 1.32, 4, B_CHRONO, 4.4f, 4, Defs.UP_DASH, 3);
        def(Defs.UP_HASTE, "HST", "Ability haste", "-2.5% ability cooldowns", 20, 250, 1.30, 4, B_CHRONO, 5.6f, 4, Defs.UP_BARRIER, 3);
        def(Defs.UP_POTENCY, "POT", "Ability potency", "+4% ability duration and strength", 20, 250, 1.30, 4, B_CHRONO, 5.0f, 5, Defs.UP_TIMEKILL, 3, Defs.UP_HASTE, 3);
    }

    public static double modeCost(int timeline) { return 2000.0 * Math.pow(3.0, timeline); }

    /** True if every prerequisite node has reached its required level. */
    public static boolean prereqsMet(Up u, int[] levels) {
        for (int[] p : u.pre) if (levels[p[0]] < p[1]) return false;
        return true;
    }

    /** A node can be bought into once its prerequisites are met and the AI is trained enough. */
    public static boolean unlocked(Up u, Profile p) { return p.level() >= u.req && prereqsMet(u, p.up); }

    /** Human readable reason a node is still locked, or null. */
    public static String lockReason(Up u, Profile p) {
        for (int[] pr : u.pre) {
            if (p.up[pr[0]] < pr[1]) return "Needs " + ALL[pr[0]].name + " " + pr[1];
        }
        if (p.level() < u.req) return "Needs AI level " + u.req;
        return null;
    }

    /** Total cost of buying n levels starting at level. */
    public static double costMany(Up u, int level, int n) {
        double t = 0;
        for (int i = 0; i < n; i++) t += u.cost(level + i);
        return t;
    }

    /** Largest number of levels (<= want) affordable with budget. */
    public static int affordable(Up u, int level, double budget, int want) {
        int n = 0;
        double spent = 0;
        while (n < want && level + n < u.max) {
            double c = u.cost(level + n);
            if (spent + c > budget) break;
            spent += c;
            n++;
        }
        return n;
    }

    /** True if anything in the tree can be bought right now. */
    public static boolean anyAffordable(Profile p) {
        for (Up u : ALL) if (p.up[u.id] < u.max && unlocked(u, p) && p.bank >= u.cost(p.up[u.id])) return true;
        return false;
    }
}
