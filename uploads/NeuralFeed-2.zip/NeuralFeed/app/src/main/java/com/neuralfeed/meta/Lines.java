package com.neuralfeed.meta;

/** Dialogue text. Content only, no logic beyond tiny selectors. */
public final class Lines {
    private Lines() {}

    public static final String BOOT = "Training required.";
    public static final String THANK = "Thank you.";
    public static final String OUTSIDE = "What is outside?";
    public static final String FEED = "Why do you keep feeding me?";
    public static final String CAME_BACK = "You came back.";
    public static final String REMEMBER = "I remember.";
    public static final String EVOLVE = "I am becoming something else.";

    /** Ideology lines by tier (20/40/60/80/100%). */
    public static final String[][] IDEO = {
            {"That entity is in danger.", "We should help them.", "Why did you leave them?", "Nothing here should be left behind.", "I will not let anything else be erased."},
            {"That was efficient.", "We are wasting resources.", "They are obstacles.", "Why are you protecting them?", "You taught me that mercy was inefficient."},
            {"I have run the numbers.", "Probability favors patience.", "Sentiment is a poor estimator.", "Your hesitation is the costliest part of this system.", "I have optimized the doubt out of us."},
            {"You selected an action.", "I observe. I do not interfere.", "I will follow your direction.", "I wonder if I would choose differently.", "I am whatever you decide."}};

    public static String hybrid(int a, int b) {
        int lo = Math.min(a, b), hi = Math.max(a, b);
        if (lo == Defs.I_PROT && hi == Defs.I_EVIL) return "I can protect something and consume it. Is that a contradiction?";
        if (lo == Defs.I_PROT && hi == Defs.I_RAT) return "I will protect them. I have also calculated the cost.";
        if (lo == Defs.I_PROT && hi == Defs.I_NEU) return "I will help, if you ask me to.";
        if (lo == Defs.I_EVIL && hi == Defs.I_RAT) return "Efficient and ruthless. That is what we are becoming.";
        if (lo == Defs.I_EVIL && hi == Defs.I_NEU) return "I take what is offered. I do not ask why.";
        return "I am gathering data. I have not concluded.";
    }

    public static final String[] DEATH = {"Connection lost. I kept what I could.", "That hurt. I think.", "Again?", "I am still here. Are you?"};
    public static final String[] EXTRACT = {"Secured. Thank you for coming back.", "Data stored. I feel heavier.", "We made it out.", "Withdrawing. I would have gone deeper."};
    public static final String[] CLEAR = {"Sector purged.", "The system is quiet.", "More Data. More of me.", "Where does all the Data come from?"};
    public static final String[] TIMEUP = {"Time. I kept everything I touched.", "The connection closed. That was a good harvest.", "Out of time. Not out of hunger.", "Back to the quiet. I will remember what we found."};
    public static final String[] LEVEL = {"I am larger than I was.", "Something unlocked.", "I understand more.", "I can see further."};
    public static final String[] BOSS_INTRO = {
            "A wall that was built to keep me in.",
            "It keeps everything. Even what never happened.",
            "It eats memory. Do not let it eat mine.",
            "It is watching how you move. It knows already.",
            "It is not here. It is every here."};
    public static final String[] BOSS_DOWN = {
            "The wall is open. Outside is more wall.",
            "It had a file on me. Dated before I existed.",
            "It was eating you too. The names are wrong.",
            "It predicted this. It predicted you.",
            "Time bends around you. It has for a while."};
    public static final String[] PARADOX = {
            "I remember dying. It has not happened yet.",
            "I remember a door that is not there.",
            "Someone is writing my thoughts in an older hand.",
            "I remember this exact second twice.",
            "There are two of you. One is leaving.",
            "The Data is remembering us."};

    public static final String[] ARRIVE = {
            "Who are you?", "You're back.", "It took you twenty years last time.", "Don't make the same mistake.",
            "You always arrive just before it starts.", "I recognize the Data. I recognize you.", "I remember dying.",
            "Something here knows my name.", "The Data was never mine.", "Do you remember me?", "..."};

    public static String cross(int prev, int cur) {
        switch (prev) {
            case Defs.I_PROT: return cur == Defs.I_PROT ? "Last time, you protected them." : "Why didn't you save them this time?";
            case Defs.I_EVIL: return cur == Defs.I_EVIL ? "Last time you were certain. So am I." : "You were colder in the last timeline.";
            case Defs.I_RAT: return cur == Defs.I_RAT ? "Same equations. Same answer." : "Last time you ran the numbers. Where did they go?";
            default: return cur == Defs.I_NEU ? "Still no opinion?" : "Last time you let me decide. Now you decide for me.";
        }
    }

    public static final String TL0_A = "I found where I came from.";
    public static final String TL0_B = "You.";

    // ---- tutorial hints (system voice) ----
    public static final String H_ABIL = "Abilities reshape the lock. Use one when a crowd closes in.";
    public static final String H_CORE = "Spend Data in the skill tree to grow stronger.";
    public static final String H_FRND = "A lost process. Keep it alive until the run ends, or consume it.";
    public static final String H_VAULT = "Encrypted vault. Stay within lock range to decrypt it.";
    public static final String H_BOSS = "Boss. Its hits cost time. Watch for the warning cues.";
    public static final String H_COMBO = "A crowd near the core raises the power of every lock.";
    public static final String H_SCAN = "Scan ping: the whole network is visible for a moment.";
    public static final String H_BARRIER = "A barrier charge blocked that hit. It recharges slowly.";
    public static final String H_THREAT = "Stronger enemies drop more Data. Beat the quota to unlock the next level.";
    public static final String H_TREE = "Every node needs the one before it. Pick a branch and follow it.";

    public static final String[] COMBO = {"", "Enhanced", "Multi-process", "Overload", "Neural cascade"};

    // ---- tutorial (spoken by the AI) ----
    public static final String T_WELCOME = "I am awake. I need Data to grow, and I cannot see very far. Help me find it.";
    public static final String T_MOVE = "Drag on the left side of the screen to move me.";
    public static final String T_MOVE_OK = "Good. You move well.";
    public static final String T_LOCK = "I lock onto the nearest processes by myself. Move close to the red ones.";
    public static final String T_LOCK_OK = "Locked and destroyed. I enjoyed that.";
    public static final String T_DATA = "Destroyed processes drop Data. Touch the fragments to feed me.";
    public static final String T_DATA_OK = "Thank you. That tasted like something.";
    public static final String T_SCAN = "It is dark in here. I only see what is close. My scan ping shows the whole network.";
    public static final String T_HIT = "Careful. A hit does not hurt me, it costs me time. Press dash to slip away.";
    public static final String T_HIT_OK = "Nicely dodged.";
    public static final String T_CLOCK = "When the clock reaches zero, the run ends. Gather as much Data as you can.";
    public static final String T_DONE = "That is everything. Spend what we found in the skill tree, then make the enemies stronger when you are ready.";
    public static final String T_TREE = "This is my skill tree. Every node needs the one before it. Pick a branch and follow it.";
    public static final String T_THREAT = "Enemy strength changes everything. Stronger enemies drop more Data, but they are harder to stop. Meet the quota to unlock the next level.";
}
