package com.hazardyard.game.input;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.InputSource;
import com.hazardyard.game.core.LocalInput;

/**
 * Turns raw multitouch pointers into game controls. Every pointer is bound to exactly one control
 * when it goes down and stays bound until it goes up, so the left stick, the right stick and the
 * buttons never interfere with each other, however the fingers move.
 *
 * Touch callbacks arrive on the UI thread while {@link #sample} runs on the game thread; a small
 * lock keeps the shared state consistent. This class has no Android dependencies (the
 * MotionEvent translation lives in GameView) so the routing rules can be tested on a plain JVM.
 */
public final class InputController implements InputSource {
    public interface Listener {
        /** The pause button was tapped. Called on the thread that delivered the touch event. */
        void onPausePressed();
    }

    private final Object lock = new Object();
    public final VirtualJoystick moveStick = new VirtualJoystick();
    public final VirtualJoystick aimStick = new VirtualJoystick();

    /** Right stick deflection (0..1) at which the player aims and fires. Configurable. */
    public volatile float aimDeadZone = GameConfig.AIM_DEAD_ZONE;

    // layout in screen pixels, filled by setViewport
    private float screenW = 1f, screenH = 1f;
    public float pauseCx, pauseCy, pauseHalf;
    public float reloadCx, reloadCy, reloadRadius;
    /** Where the idle hint rings are drawn. */
    public float moveHintX, moveHintY, aimHintX, aimHintY;

    private int movePointer = -1;
    private int aimPointer = -1;
    private int pausePointer = -1;
    private int reloadPointer = -1;
    private boolean reloadQueued;
    private boolean reloadHeld;
    private float lastAim;
    private volatile Listener listener;

    public void setListener(Listener l) {
        listener = l;
    }

    /** Lays out sticks and buttons for a screen of w x h pixels at the given density (px per dp). */
    public void setViewport(int w, int h, float density) {
        synchronized (lock) {
            screenW = w;
            screenH = h;
            float ring = 58f * density;
            moveStick.radius = ring;
            aimStick.radius = ring;
            pauseHalf = 28f * density;
            pauseCx = w - 14f * density - pauseHalf;
            pauseCy = 14f * density + pauseHalf;
            reloadRadius = 34f * density;
            reloadCx = w - 52f * density;
            reloadCy = h - 232f * density;
            moveHintX = 110f * density;
            moveHintY = h - 96f * density;
            aimHintX = w - 110f * density;
            aimHintY = h - 96f * density;
            cancelAllLocked();
        }
    }

    // ------------------------------------------------------------------ pointer events

    public void onPointerDown(int id, float x, float y) {
        synchronized (lock) {
            if (pausePointer < 0 && Math.abs(x - pauseCx) <= pauseHalf && Math.abs(y - pauseCy) <= pauseHalf) {
                pausePointer = id;
                return;
            }
            if (reloadPointer < 0 && dist2(x, y, reloadCx, reloadCy) <= reloadRadius * reloadRadius * 1.3f) {
                reloadPointer = id;
                reloadQueued = true;
                reloadHeld = true;
                return;
            }
            if (x < screenW * 0.5f) {
                if (movePointer < 0) {
                    movePointer = id;
                    moveStick.begin(x, y);
                }
            } else if (aimPointer < 0) {
                aimPointer = id;
                aimStick.begin(x, y);
            }
        }
    }

    public void onPointerMove(int id, float x, float y) {
        synchronized (lock) {
            if (id == movePointer) moveStick.update(x, y);
            else if (id == aimPointer) aimStick.update(x, y);
        }
    }

    public void onPointerUp(int id) {
        boolean pauseTapped = false;
        synchronized (lock) {
            if (id == movePointer) {
                movePointer = -1;
                moveStick.end();
            } else if (id == aimPointer) {
                aimPointer = -1;
                aimStick.end();
            } else if (id == reloadPointer) {
                reloadPointer = -1;
                reloadHeld = false;
            } else if (id == pausePointer) {
                pausePointer = -1;
                pauseTapped = true;
            }
        }
        Listener l = listener;
        if (pauseTapped && l != null) l.onPausePressed();
    }

    /** A cancelled gesture (system took over the touch): release everything without side effects. */
    public void cancelAll() {
        synchronized (lock) {
            cancelAllLocked();
        }
    }

    private void cancelAllLocked() {
        movePointer = -1;
        aimPointer = -1;
        pausePointer = -1;
        reloadPointer = -1;
        reloadHeld = false;
        moveStick.end();
        aimStick.end();
    }

    // ------------------------------------------------------------------ game thread

    @Override
    public void sample(LocalInput out) {
        synchronized (lock) {
            float mx = moveStick.x;
            float my = moveStick.y;
            float mag = (float) Math.sqrt(mx * mx + my * my);
            float dz = GameConfig.MOVE_DEAD_ZONE;
            if (!moveStick.active || mag <= dz) {
                out.moveX = 0f;
                out.moveY = 0f;
            } else {
                // Rescale so movement ramps smoothly from zero right after the dead zone.
                float k = (mag - dz) / (1f - dz) / mag;
                out.moveX = mx * k;
                out.moveY = my * k;
            }
            boolean aiming = aimStick.active && aimStick.magnitude() >= aimDeadZone;
            if (aiming) {
                lastAim = (float) Math.atan2(aimStick.y, aimStick.x);
                out.aim = lastAim;
            }
            out.firing = aiming;
            out.reload = reloadQueued;
            reloadQueued = false;
        }
    }

    // ------------------------------------------------------------------ read-only state for the HUD

    public boolean isReloadHeld() {
        return reloadHeld;
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }
}
