package com.hazardyard.game.input;

/**
 * Geometry of one floating on-screen stick. The base appears where the thumb lands, so the control
 * works wherever the player holds the phone. Pure math; drawing lives in the HUD renderer.
 */
public final class VirtualJoystick {
    public boolean active;
    /** Centre of the ring (screen pixels). */
    public float baseX, baseY;
    /** Current knob position, clamped to the ring. */
    public float knobX, knobY;
    /** Ring radius in pixels; also the deflection that counts as "fully pushed". */
    public float radius = 100f;
    /** Normalised deflection, each axis in [-1, 1] and overall length at most 1. */
    public float x, y;

    public void begin(float touchX, float touchY) {
        active = true;
        baseX = touchX;
        baseY = touchY;
        update(touchX, touchY);
    }

    public void update(float touchX, float touchY) {
        if (!active) return;
        float dx = touchX - baseX;
        float dy = touchY - baseY;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > radius) {
            float k = radius / len;
            dx *= k;
            dy *= k;
            len = radius;
        }
        knobX = baseX + dx;
        knobY = baseY + dy;
        x = dx / radius;
        y = dy / radius;
    }

    public void end() {
        active = false;
        x = 0f;
        y = 0f;
        knobX = baseX;
        knobY = baseY;
    }

    /** Deflection length in [0, 1]. */
    public float magnitude() {
        return (float) Math.sqrt(x * x + y * y);
    }
}
