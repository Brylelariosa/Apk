package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;

import java.io.IOException;
import java.net.BindException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Host side of the LAN game: accepts up to three clients, runs the lobby, and fans messages out.
 * Lobby traffic is fully handled on the network threads (under this object's lock); during a match
 * only input messages are forwarded to the game thread through the inbound queue.
 */
public final class HostManager extends NetworkManager {
    public interface Listener {
        /** The player list changed. Called from a network thread. */
        void onLobbyChanged();

        /** The listening socket failed and the lobby is no longer reachable. */
        void onFailure(String message);
    }

    private final int gamePort;
    private final int discoveryPort;
    private final LobbyManager lobby = new LobbyManager();
    private final PacketWriter ctl = new PacketWriter(512); // guarded by this
    private volatile ClientLink[] links = new ClientLink[GameConfig.MAX_PLAYERS];
    private volatile Listener listener;
    private volatile boolean closed;
    private volatile boolean matchFlag;
    private boolean matchInProgress; // guarded by this
    private ServerSocket server;
    private DiscoveryResponder responder;

    public HostManager() {
        this(Protocol.GAME_PORT, Protocol.DISCOVERY_PORT);
    }

    public HostManager(int gamePort, int discoveryPort) {
        this.gamePort = gamePort;
        this.discoveryPort = discoveryPort;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    public LobbyManager lobby() {
        return lobby;
    }

    /** TCP port clients must connect to (may differ from the default if that one was busy). */
    public int port() {
        return server == null ? gamePort : server.getLocalPort();
    }

    /** Opens the lobby: binds the game port, registers the host as player 0 and starts answering probes. */
    public void start(String hostName) throws IOException {
        String name = Protocol.sanitizeName(hostName);
        server = new ServerSocket();
        server.setReuseAddress(true);
        try {
            server.bind(new InetSocketAddress(gamePort));
        } catch (BindException busy) {
            server.close();
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(0));
        }
        lobby.addPlayer(name, true);
        responder = new DiscoveryResponder(discoveryPort);
        responder.start(server.getLocalPort(), name);
        responder.update(1, false);
        Thread accept = new Thread(this::acceptLoop, "hy-host-accept");
        accept.setDaemon(true);
        accept.start();
    }

    private void acceptLoop() {
        while (!closed) {
            try {
                Socket s = server.accept();
                try {
                    new ClientLink(this, s).start();
                } catch (IOException | RuntimeException e) {
                    s.close();
                }
            } catch (IOException e) {
                if (!closed) {
                    Listener l = listener;
                    if (l != null) l.onFailure("Network error: " + e.getMessage());
                }
                return;
            }
        }
    }

    // ------------------------------------------------------------------ frames from clients

    void onFrame(ClientLink link, byte[] d) {
        int type = d[0] & 0xFF;
        if (link.playerId < 0) {
            if (type == Protocol.C_HELLO) handleHello(link, d);
            else link.close();
            return;
        }
        switch (type) {
            case Protocol.C_READY: {
                boolean ready = d.length > 1 && d[1] != 0;
                synchronized (this) {
                    if (closed || matchInProgress) return;
                    lobby.setReady(link.playerId, ready);
                    broadcastLobbyLocked();
                }
                notifyLobby();
                break;
            }
            case Protocol.C_INPUT:
            case Protocol.C_RELOAD:
                if (matchFlag) enqueue(new Inbound(link.playerId, d));
                break;
            case Protocol.C_PING:
                if (d.length >= 5) {
                    byte[] pong = new byte[7];
                    pong[1] = 5;
                    pong[2] = (byte) Protocol.S_PONG;
                    System.arraycopy(d, 1, pong, 3, 4);
                    link.send(pong);
                }
                break;
            case Protocol.C_LEAVE:
                link.close();
                break;
            default:
                break;
        }
    }

    private void handleHello(ClientLink link, byte[] d) {
        PacketReader r = new PacketReader().wrap(d, 1, d.length - 1);
        int version = r.u8();
        String name = Protocol.sanitizeName(r.str());
        synchronized (this) {
            if (closed) return;
            if (version != Protocol.VERSION) {
                rejectLocked(link, Protocol.REJECT_VERSION);
                return;
            }
            if (matchInProgress) {
                rejectLocked(link, Protocol.REJECT_IN_MATCH);
                return;
            }
            int id = lobby.addPlayer(name, false);
            if (id < 0) {
                rejectLocked(link, Protocol.REJECT_FULL);
                return;
            }
            link.playerId = id;
            link.setActiveTimeout();
            ClientLink[] next = links.clone();
            next[id] = link;
            links = next;
            link.send(ctl.begin(Protocol.S_WELCOME).u8(id).u8(Protocol.VERSION).finishFrame());
            broadcastLobbyLocked();
        }
        notifyLobby();
    }

    private void rejectLocked(ClientLink link, int reason) {
        link.sendAndClose(ctl.begin(Protocol.S_REJECT).u8(reason).finishFrame());
    }

    void onLinkClosed(ClientLink link) {
        int id = link.playerId;
        if (id < 0) return;
        boolean changed = false;
        synchronized (this) {
            if (closed) return;
            ClientLink[] cur = links;
            if (cur[id] == link) {
                ClientLink[] next = cur.clone();
                next[id] = null;
                links = next;
                lobby.removePlayer(id);
                if (matchInProgress) {
                    enqueue(new Inbound(id, new byte[] {(byte) Protocol.I_PLAYER_LEFT}));
                } else {
                    broadcastLobbyLocked();
                }
                updateDiscoveryLocked();
                changed = true;
            }
        }
        if (changed) notifyLobby();
    }

    // ------------------------------------------------------------------ match control (UI thread)

    /** Locks the lobby and tells every client to start. Fails unless everybody is ready. */
    public synchronized boolean startMatch() {
        if (closed || matchInProgress || !lobby.allReady()) return false;
        matchInProgress = true;
        matchFlag = true;
        clearInbound();
        ctl.begin(Protocol.S_START);
        lobby.write(ctl);
        sendToAllLocked(ctl.finishFrame());
        updateDiscoveryLocked();
        return true;
    }

    /** Returns everybody to the lobby (all players un-ready). */
    public synchronized void endMatch() {
        if (!matchInProgress) return;
        matchInProgress = false;
        matchFlag = false;
        lobby.resetReady();
        sendToAllLocked(ctl.begin(Protocol.S_TO_LOBBY).finishFrame());
        broadcastLobbyLocked();
        updateDiscoveryLocked();
    }

    public boolean isMatchInProgress() {
        return matchFlag;
    }

    // ------------------------------------------------------------------ sending

    /** Sends a frame to every connected client; never dropped while the connection lives. */
    public void broadcast(byte[] frame) {
        for (ClientLink l : links) {
            if (l != null) l.send(frame);
        }
    }

    /** Sends a frame that may be skipped for clients that are lagging behind (snapshots). */
    public void broadcastDroppable(byte[] frame) {
        for (ClientLink l : links) {
            if (l != null) l.sendDroppable(frame);
        }
    }

    public int clientCount() {
        int n = 0;
        for (ClientLink l : links) {
            if (l != null) n++;
        }
        return n;
    }

    private void sendToAllLocked(byte[] frame) {
        for (ClientLink l : links) {
            if (l != null) l.send(frame);
        }
    }

    private void broadcastLobbyLocked() {
        ctl.begin(Protocol.S_LOBBY);
        lobby.write(ctl);
        sendToAllLocked(ctl.finishFrame());
        updateDiscoveryLocked();
    }

    private void updateDiscoveryLocked() {
        if (responder != null) responder.update(lobby.count(), matchInProgress);
    }

    private void notifyLobby() {
        Listener l = listener;
        if (l != null) l.onLobbyChanged();
    }

    // ------------------------------------------------------------------ NetworkManager

    @Override
    public boolean isHost() {
        return true;
    }

    @Override
    public int localPlayerId() {
        return 0;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    @Override
    public void close() {
        ClientLink[] ls;
        synchronized (this) {
            if (closed) return;
            closed = true;
            matchFlag = false;
            ls = links;
            links = new ClientLink[GameConfig.MAX_PLAYERS];
        }
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
            // already closed
        }
        if (responder != null) responder.stop();
        for (ClientLink l : ls) {
            if (l != null) l.close();
        }
        clearInbound();
    }
}
