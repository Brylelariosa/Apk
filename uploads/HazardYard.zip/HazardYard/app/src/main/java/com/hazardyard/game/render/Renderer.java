package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.Projectile;
import com.hazardyard.game.core.ProjectilePool;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.WeaponDef;

/**
 * Draws the arena and everything in it with plain Canvas shapes (no bitmaps). The world is drawn in
 * world units under one camera transform; only things inside the view are drawn. All paints and
 * scratch objects are created once, so a frame allocates nothing.
 */
public final class Renderer {
    private static final float RAD_TO_DEG = 57.29578f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float[] grid;
    private TileMap gridMap;

    public Renderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        label.setTextAlign(Paint.Align.CENTER);
    }

    public void draw(Canvas canvas, GameState st, Camera cam, float time) {
        canvas.drawColor(Palette.BACKDROP);
        canvas.save();
        canvas.translate(cam.viewW * 0.5f, cam.viewH * 0.5f);
        canvas.scale(cam.scale, cam.scale);
        canvas.translate(-cam.x, -cam.y);

        float hw = cam.halfViewWorldW();
        float hh = cam.halfViewWorldH();
        float vx0 = cam.x - hw;
        float vx1 = cam.x + hw;
        float vy0 = cam.y - hh;
        float vy1 = cam.y + hh;

        drawFloor(canvas, st.map, cam);
        drawSpawnDecals(canvas, st.map, vx0, vx1, vy0, vy1);
        drawBlockShadows(canvas, st.map, vx0, vx1, vy0, vy1);
        drawPickups(canvas, st, time, cam);
        drawCorpses(canvas, st, cam);
        drawBlocks(canvas, st.map, vx0, vx1, vy0, vy1);
        drawProjectiles(canvas, st.projectiles, cam);
        drawPlayers(canvas, st, time, cam);
        drawEffects(canvas, st.effects);
        drawNameTags(canvas, st, cam);

        canvas.restore();
    }

    // ------------------------------------------------------------------ floor

    private void drawFloor(Canvas canvas, TileMap map, Camera cam) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.FLOOR);
        canvas.drawRect(0f, 0f, map.worldW, map.worldH, fill);
        if (gridMap != map) {
            gridMap = map;
            int vertical = map.width + 1;
            int horizontal = map.height + 1;
            grid = new float[(vertical + horizontal) * 4];
            int k = 0;
            for (int x = 0; x < vertical; x++) {
                grid[k++] = x * GameConfig.TILE;
                grid[k++] = 0f;
                grid[k++] = x * GameConfig.TILE;
                grid[k++] = map.worldH;
            }
            for (int y = 0; y < horizontal; y++) {
                grid[k++] = 0f;
                grid[k++] = y * GameConfig.TILE;
                grid[k++] = map.worldW;
                grid[k++] = y * GameConfig.TILE;
            }
        }
        line.setColor(Palette.FLOOR_LINE);
        line.setStrokeWidth(1.2f / cam.scale);
        canvas.drawLines(grid, 0, grid.length, line);
    }

    private void drawSpawnDecals(Canvas canvas, TileMap map, float vx0, float vx1, float vy0, float vy1) {
        line.setColor(Palette.FLOOR_DECAL);
        line.setStrokeWidth(2f);
        for (int i = 0; i < map.spawnX.length; i++) {
            float x = map.spawnX[i];
            float y = map.spawnY[i];
            if (x < vx0 - 30f || x > vx1 + 30f || y < vy0 - 30f || y > vy1 + 30f) continue;
            canvas.drawCircle(x, y, 13f, line);
            canvas.drawCircle(x, y, 7f, line);
        }
    }

    // ------------------------------------------------------------------ solid blocks

    private void drawBlockShadows(Canvas canvas, TileMap map, float vx0, float vx1, float vy0, float vy1) {
        fill.setColor(Palette.SHADOW);
        final float t = GameConfig.TILE;
        for (int b = 0; b < map.blockCount; b++) {
            int o = b * 5;
            float x0 = map.blocks[o] * t;
            float y0 = map.blocks[o + 1] * t;
            float x1 = x0 + map.blocks[o + 2] * t;
            float y1 = y0 + map.blocks[o + 3] * t;
            if (x1 < vx0 - 8f || x0 > vx1 || y1 < vy0 - 8f || y0 > vy1) continue;
            canvas.drawRect(x0 + 3f, y0 + 5f, x1 + 3f, y1 + 5f, fill);
        }
    }

    private void drawBlocks(Canvas canvas, TileMap map, float vx0, float vx1, float vy0, float vy1) {
        final float t = GameConfig.TILE;
        for (int b = 0; b < map.blockCount; b++) {
            int o = b * 5;
            int bx = map.blocks[o];
            int by = map.blocks[o + 1];
            int bw = map.blocks[o + 2];
            int bh = map.blocks[o + 3];
            byte kind = (byte) map.blocks[o + 4];
            float x0 = bx * t;
            float y0 = by * t;
            float x1 = x0 + bw * t;
            float y1 = y0 + bh * t;
            if (x1 < vx0 || x0 > vx1 || y1 < vy0 || y0 > vy1) continue;
            if (kind == TileMap.CRATE) {
                for (int yy = 0; yy < bh; yy++) {
                    for (int xx = 0; xx < bw; xx++) drawCrate(canvas, x0 + xx * t, y0 + yy * t);
                }
            } else {
                fill.setColor(Palette.WALL_EDGE);
                canvas.drawRect(x0, y0, x1, y1, fill);
                fill.setColor(Palette.WALL_BODY);
                canvas.drawRect(x0 + 1.5f, y0 + 1.5f, x1 - 1.5f, y1 - 1.5f, fill);
                fill.setColor(Palette.WALL_TOP);
                canvas.drawRect(x0 + 1.5f, y0 + 1.5f, x1 - 1.5f, y0 + 4.5f, fill);
                line.setColor(Palette.WALL_SEAM);
                line.setStrokeWidth(1f);
                for (int xx = 1; xx < bw; xx++) canvas.drawLine(x0 + xx * t, y0 + 4.5f, x0 + xx * t, y1 - 1.5f, line);
                for (int yy = 1; yy < bh; yy++) canvas.drawLine(x0 + 1.5f, y0 + yy * t, x1 - 1.5f, y0 + yy * t, line);
            }
        }
    }

    private void drawCrate(Canvas canvas, float x, float y) {
        final float t = GameConfig.TILE;
        fill.setColor(Palette.CRATE_DARK);
        canvas.drawRect(x + 1f, y + 1f, x + t - 1f, y + t - 1f, fill);
        fill.setColor(Palette.CRATE_BODY);
        canvas.drawRect(x + 3f, y + 3f, x + t - 3f, y + t - 3f, fill);
        fill.setColor(Palette.CRATE_LIGHT);
        canvas.drawRect(x + 3f, y + 3f, x + t - 3f, y + 6f, fill);
        line.setColor(Palette.CRATE_DARK);
        line.setStrokeWidth(2.2f);
        canvas.drawLine(x + 5f, y + 7f, x + t - 5f, y + t - 5f, line);
        canvas.drawLine(x + t - 5f, y + 7f, x + 5f, y + t - 5f, line);
    }

    // ------------------------------------------------------------------ pickups, bodies

    private void drawPickups(Canvas canvas, GameState st, float time, Camera cam) {
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!cam.isVisible(pk.x, pk.y, 24f)) continue;
            WeaponDef d = WeaponDef.byId(pk.weaponId);
            if (!pk.active) {
                line.setColor(Palette.withAlpha(d.color, 50));
                line.setStrokeWidth(1.5f);
                canvas.drawCircle(pk.x, pk.y, 9f, line);
                continue;
            }
            float pulse = 0.5f + 0.5f * (float) Math.sin(time * 4f + i);
            fill.setColor(Palette.withAlpha(d.color, 50 + (int) (40f * pulse)));
            canvas.drawCircle(pk.x, pk.y, 15f + 2f * pulse, fill);
            fill.setColor(Palette.PANEL_SOLID);
            canvas.drawCircle(pk.x, pk.y, 11f, fill);
            line.setColor(d.color);
            line.setStrokeWidth(2f);
            canvas.drawCircle(pk.x, pk.y, 11f, line);
            label.setColor(d.color);
            label.setTextSize(10f);
            canvas.drawText(glyph(pk.weaponId), pk.x, pk.y + 3.6f, label);
        }
    }

    private static String glyph(int weaponId) {
        switch (weaponId) {
            case WeaponDef.RIFLE: return "AR";
            case WeaponDef.SHOTGUN: return "SG";
            case WeaponDef.SMG: return "SM";
            default: return "P";
        }
    }

    private void drawCorpses(Canvas canvas, GameState st, Camera cam) {
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || p.alive || !cam.isVisible(p.rx, p.ry, 20f)) continue;
            int c = PlayerColors.of(i);
            fill.setColor(Palette.withAlpha(c, 70));
            canvas.drawCircle(p.rx, p.ry, GameConfig.PLAYER_RADIUS, fill);
            line.setColor(Palette.withAlpha(c, 160));
            line.setStrokeWidth(2.4f);
            canvas.drawLine(p.rx - 6f, p.ry - 6f, p.rx + 6f, p.ry + 6f, line);
            canvas.drawLine(p.rx + 6f, p.ry - 6f, p.rx - 6f, p.ry + 6f, line);
        }
    }

    // ------------------------------------------------------------------ bullets

    private void drawProjectiles(Canvas canvas, ProjectilePool pool, Camera cam) {
        for (int i = 0; i < pool.activeCount; i++) {
            Projectile b = pool.items[pool.activeList[i]];
            if (!cam.isVisible(b.x, b.y, 24f)) continue;
            int color = WeaponDef.byId(b.weaponId).color;
            float tail = 0.028f;
            line.setColor(Palette.withAlpha(color, 170));
            line.setStrokeWidth(b.radius * 1.8f);
            canvas.drawLine(b.x - b.vx * tail, b.y - b.vy * tail, b.x, b.y, line);
            fill.setColor(0xFFFFFFFF);
            canvas.drawCircle(b.x, b.y, b.radius * 0.9f, fill);
        }
    }

    // ------------------------------------------------------------------ players

    private void drawPlayers(Canvas canvas, GameState st, float time, Camera cam) {
        final float r = GameConfig.PLAYER_RADIUS;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive) continue;
            float x = p.rx;
            float y = p.ry;
            if (!cam.isVisible(x, y, 40f)) continue;
            int color = PlayerColors.of(i);
            boolean shielded = p.spawnProtect > 0f;
            boolean blink = shielded && ((int) (time * 10f) & 1) == 0;

            fill.setColor(Palette.SHADOW);
            canvas.drawCircle(x + 2f, y + 3f, r, fill);

            fill.setColor(blink ? Palette.withAlpha(color, 130) : color);
            canvas.drawCircle(x, y, r, fill);
            line.setColor(Palette.withAlpha(0xFF0B0F14, 200));
            line.setStrokeWidth(2f);
            canvas.drawCircle(x, y, r - 1f, line);

            WeaponDef def = p.weapon.def;
            canvas.save();
            canvas.translate(x, y);
            canvas.rotate(p.rAim * RAD_TO_DEG);
            fill.setColor(0xFF20252D);
            canvas.drawRect(r * 0.35f, -def.barrelWidth * 0.5f, r + def.barrelLength, def.barrelWidth * 0.5f, fill);
            fill.setColor(0xFF4A535F);
            canvas.drawRect(r + def.barrelLength - 3f, -def.barrelWidth * 0.5f, r + def.barrelLength,
                    def.barrelWidth * 0.5f, fill);
            fill.setColor(Palette.withAlpha(0xFFFFFFFF, 215));
            canvas.drawCircle(r * 0.42f, 0f, r * 0.46f, fill);
            canvas.restore();

            if (p.hitFlash > 0f) {
                fill.setColor(Palette.withAlpha(0xFFFFFFFF, (int) (200f * Math.min(1f, p.hitFlash / 0.15f))));
                canvas.drawCircle(x, y, r, fill);
            }
            if (shielded) {
                line.setColor(Palette.withAlpha(Palette.SHIELD, blink ? 110 : 200));
                line.setStrokeWidth(2f);
                canvas.drawCircle(x, y, r + 5f, line);
            }
            if (i == st.localId) {
                line.setColor(Palette.withAlpha(0xFFFFFFFF, 150));
                line.setStrokeWidth(1.4f);
                canvas.drawCircle(x, y, r + 2.5f, line);
            }
        }
    }

    private void drawEffects(Canvas canvas, Effects fx) {
        for (int i = 0; i < Effects.MAX; i++) {
            if (!fx.active[i]) continue;
            float t = fx.age[i] / fx.life[i];
            int alpha = (int) (255f * (1f - t));
            if (alpha <= 0) continue;
            int c = Palette.withAlpha(fx.color[i], alpha);
            switch (fx.kind[i]) {
                case Effects.KIND_FLASH:
                    fill.setColor(c);
                    canvas.drawCircle(fx.x[i], fx.y[i], 7f - 3f * t, fill);
                    break;
                case Effects.KIND_SPARK:
                    line.setColor(c);
                    line.setStrokeWidth(1.8f);
                    canvas.drawCircle(fx.x[i], fx.y[i], 2f + 8f * t, line);
                    break;
                default:
                    line.setColor(c);
                    line.setStrokeWidth(3f * (1f - t) + 0.6f);
                    canvas.drawCircle(fx.x[i], fx.y[i], 6f + 30f * t, line);
                    fill.setColor(Palette.withAlpha(fx.color[i], alpha / 2));
                    canvas.drawCircle(fx.x[i], fx.y[i], 12f * (1f - t), fill);
                    break;
            }
        }
    }

    private void drawNameTags(Canvas canvas, GameState st, Camera cam) {
        final float r = GameConfig.PLAYER_RADIUS;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive) continue;
            float x = p.rx;
            float y = p.ry;
            if (!cam.isVisible(x, y, 40f)) continue;
            float frac = Math.max(0f, Math.min(1f, p.health / (float) GameConfig.PLAYER_MAX_HEALTH));
            float bw = 26f;
            float by = y - r - 9f;
            fill.setColor(0xAA0B0F14);
            canvas.drawRect(x - bw * 0.5f - 1f, by - 1f, x + bw * 0.5f + 1f, by + 4.5f, fill);
            fill.setColor(frac > 0.5f ? Palette.GOOD : (frac > 0.25f ? Palette.WARN : Palette.BAD));
            canvas.drawRect(x - bw * 0.5f, by, x - bw * 0.5f + bw * frac, by + 3.5f, fill);
            if (i != st.localId) {
                label.setTextSize(8.5f);
                label.setColor(0xCC0B0F14);
                canvas.drawText(p.name, x + 0.6f, by - 2.4f, label);
                label.setColor(PlayerColors.of(i));
                canvas.drawText(p.name, x, by - 3f, label);
            }
        }
    }
}
