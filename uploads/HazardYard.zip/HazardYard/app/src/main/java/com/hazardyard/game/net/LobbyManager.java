package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;

/**
 * The player list shown in the lobby: who is in, who is ready. The host owns the authoritative copy
 * and mirrors it to clients with S_LOBBY messages; clients keep a read-only copy decoded from those.
 * All methods are synchronized because network threads and the UI thread both touch it.
 */
public final class LobbyManager {
    public static final class Entry {
        public boolean used;
        public boolean ready;
        public boolean host;
        public String name = "";
    }

    private final Entry[] entries = new Entry[GameConfig.MAX_PLAYERS];

    public LobbyManager() {
        for (int i = 0; i < entries.length; i++) entries[i] = new Entry();
    }

    /** Adds a player to the lowest free slot and returns it, or -1 when the lobby is full. */
    public synchronized int addPlayer(String name, boolean isHost) {
        for (int i = 0; i < entries.length; i++) {
            if (!entries[i].used) {
                Entry e = entries[i];
                e.used = true;
                e.ready = false;
                e.host = isHost;
                e.name = uniqueName(name);
                return i;
            }
        }
        return -1;
    }

    private String uniqueName(String base) {
        String candidate = base;
        int n = 2;
        while (nameTaken(candidate)) {
            String suffix = " " + n++;
            int keep = Math.min(base.length(), Protocol.MAX_NAME - suffix.length());
            candidate = base.substring(0, Math.max(keep, 1)) + suffix;
        }
        return candidate;
    }

    private boolean nameTaken(String n) {
        for (Entry e : entries) {
            if (e.used && e.name.equalsIgnoreCase(n)) return true;
        }
        return false;
    }

    public synchronized void removePlayer(int id) {
        if (id < 0 || id >= entries.length) return;
        Entry e = entries[id];
        e.used = false;
        e.ready = false;
        e.host = false;
        e.name = "";
    }

    public synchronized void setReady(int id, boolean ready) {
        if (id >= 0 && id < entries.length && entries[id].used) entries[id].ready = ready;
    }

    public synchronized int count() {
        int n = 0;
        for (Entry e : entries) if (e.used) n++;
        return n;
    }

    /** True when every non-host player is ready (a lone host may always start). */
    public synchronized boolean allReady() {
        for (Entry e : entries) {
            if (e.used && !e.host && !e.ready) return false;
        }
        return true;
    }

    public synchronized void resetReady() {
        for (Entry e : entries) e.ready = false;
    }

    public synchronized void clear() {
        for (int i = 0; i < entries.length; i++) removePlayer(i);
    }

    /** Copies the current state into caller-owned entries (length MAX_PLAYERS). */
    public synchronized void copyTo(Entry[] out) {
        for (int i = 0; i < entries.length && i < out.length; i++) {
            Entry s = entries[i];
            Entry d = out[i];
            d.used = s.used;
            d.ready = s.ready;
            d.host = s.host;
            d.name = s.name;
        }
    }

    public synchronized String nameOf(int id) {
        return (id >= 0 && id < entries.length && entries[id].used) ? entries[id].name : "";
    }

    public synchronized void write(PacketWriter w) {
        w.u8(entries.length);
        for (Entry e : entries) {
            int flags = (e.used ? 1 : 0) | (e.ready ? 2 : 0) | (e.host ? 4 : 0);
            w.u8(flags);
            w.str(e.name);
        }
    }

    public synchronized void read(PacketReader r) {
        int n = r.u8();
        for (int i = 0; i < n; i++) {
            int flags = r.u8();
            String name = r.str();
            if (i >= entries.length) continue;
            Entry e = entries[i];
            e.used = (flags & 1) != 0;
            e.ready = (flags & 2) != 0;
            e.host = (flags & 4) != 0;
            e.name = e.used ? name : "";
        }
    }
}
