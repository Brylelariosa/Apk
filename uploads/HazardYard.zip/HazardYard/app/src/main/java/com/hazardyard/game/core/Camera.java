package com.hazardyard.game.core;

/** Smooth top-down camera that follows the local player and never shows beyond the map edge. */
public final class Camera {
    /** World position shown at the centre of the screen. */
    public float x, y;
    /** Screen pixels per world unit. */
    public float scale = 1f;
    public int viewW = 1, viewH = 1;
    private float worldW = 1f, worldH = 1f;

    /** Chooses a zoom so at least VIEW_MIN_WIDTH x VIEW_MIN_HEIGHT world units are visible on any screen. */
    public void setViewport(int w, int h, float worldWidth, float worldHeight) {
        viewW = Math.max(1, w);
        viewH = Math.max(1, h);
        worldW = worldWidth;
        worldH = worldHeight;
        scale = Math.min(viewH / GameConfig.VIEW_MIN_HEIGHT, viewW / GameConfig.VIEW_MIN_WIDTH);
        clampToWorld();
    }

    public void snapTo(float tx, float ty) {
        x = tx;
        y = ty;
        clampToWorld();
    }

    public void follow(float tx, float ty, float dt) {
        float k = 1f - (float) Math.exp(-GameConfig.CAMERA_FOLLOW_RATE * dt);
        x += (tx - x) * k;
        y += (ty - y) * k;
        clampToWorld();
    }

    public float halfViewWorldW() {
        return viewW * 0.5f / scale;
    }

    public float halfViewWorldH() {
        return viewH * 0.5f / scale;
    }

    private void clampToWorld() {
        float hw = halfViewWorldW();
        float hh = halfViewWorldH();
        x = worldW <= hw * 2f ? worldW * 0.5f : MathUtil.clamp(x, hw, worldW - hw);
        y = worldH <= hh * 2f ? worldH * 0.5f : MathUtil.clamp(y, hh, worldH - hh);
    }

    public float screenX(float wx) {
        return (wx - x) * scale + viewW * 0.5f;
    }

    public float screenY(float wy) {
        return (wy - y) * scale + viewH * 0.5f;
    }

    /** True when a point (with a margin in world units) lies inside the visible area. */
    public boolean isVisible(float wx, float wy, float margin) {
        return Math.abs(wx - x) <= halfViewWorldW() + margin && Math.abs(wy - y) <= halfViewWorldH() + margin;
    }
}
