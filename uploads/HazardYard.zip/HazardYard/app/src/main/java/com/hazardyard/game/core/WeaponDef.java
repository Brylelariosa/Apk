package com.hazardyard.game.core;

/**
 * Immutable description of a weapon. All weapons share the same firing code; only these numbers
 * differ, so adding a weapon means adding one entry to {@link #ALL}.
 */
public final class WeaponDef {
    public static final int PISTOL = 0;
    public static final int RIFLE = 1;
    public static final int SHOTGUN = 2;
    public static final int SMG = 3;

    public final int id;
    public final String name;
    public final int damage;
    /** Seconds between two shots. */
    public final float fireInterval;
    public final int magSize;
    public final float reloadTime;
    /** World units per second. */
    public final float projectileSpeed;
    /** Half-angle of the random cone in radians. */
    public final float spread;
    /** World units a bullet travels before it disappears. */
    public final float range;
    /** True: keeps firing while the stick is held. False: one shot per trigger pull. */
    public final boolean automatic;
    public final int pellets;

    // presentation only
    public final float barrelLength;
    public final float barrelWidth;
    public final float bulletRadius;
    public final int color;

    private WeaponDef(int id, String name, int damage, float fireInterval, int magSize, float reloadTime,
                      float projectileSpeed, float spreadDegrees, float range, boolean automatic, int pellets,
                      float barrelLength, float barrelWidth, float bulletRadius, int color) {
        this.id = id;
        this.name = name;
        this.damage = damage;
        this.fireInterval = fireInterval;
        this.magSize = magSize;
        this.reloadTime = reloadTime;
        this.projectileSpeed = projectileSpeed;
        this.spread = (float) Math.toRadians(spreadDegrees);
        this.range = range;
        this.automatic = automatic;
        this.pellets = pellets;
        this.barrelLength = barrelLength;
        this.barrelWidth = barrelWidth;
        this.bulletRadius = bulletRadius;
        this.color = color;
    }

    public static final WeaponDef[] ALL = {
        //        id       name             dmg  interval mag  reload speed  spread range auto   pellets barrel width bullet color
        new WeaponDef(PISTOL,  "Pistol",          20, 0.22f, 12, 1.10f, 560f, 1.5f, 420f, false, 1, 9f,  4f, 2.5f, 0xFFFFE08A),
        new WeaponDef(RIFLE,   "Assault Rifle",   15, 0.12f, 30, 1.80f, 660f, 3.0f, 540f, true,  1, 15f, 4f, 2.5f, 0xFFFFB347),
        new WeaponDef(SHOTGUN, "Shotgun",          9, 0.85f,  6, 2.20f, 520f, 8.0f, 260f, false, 8, 13f, 6f, 2.2f, 0xFFFF7A59),
        new WeaponDef(SMG,     "SMG",              8, 0.07f, 35, 1.50f, 600f, 6.0f, 330f, true,  1, 11f, 4f, 2.0f, 0xFF8DE0FF),
    };

    /** Bounds-safe lookup for ids that came off the network. */
    public static WeaponDef byId(int id) {
        return (id >= 0 && id < ALL.length) ? ALL[id] : ALL[PISTOL];
    }

    /**
     * Spawns this weapon's pellets into {@code pool}. Bullets start at the shooter's centre, so a
     * shooter pressed against a wall can never place a bullet on the far side of it. Host and
     * clients call this with identical arguments and therefore get identical bullets.
     *
     * @return number of bullets actually spawned
     */
    public int spawn(ProjectilePool pool, int ownerId, float x, float y, float angle, int seed, int baseId) {
        XorShift rng = pool.rng;
        rng.setSeed(seed);
        int spawned = 0;
        for (int i = 0; i < pellets; i++) {
            Projectile p = pool.acquire();
            if (p == null) break;
            float a = angle + rng.nextSigned() * spread;
            p.x = x;
            p.y = y;
            p.px = x;
            p.py = y;
            p.vx = (float) Math.cos(a) * projectileSpeed;
            p.vy = (float) Math.sin(a) * projectileSpeed;
            p.remaining = range;
            p.id = (baseId + i) & 0xFFFF;
            p.owner = ownerId;
            p.weaponId = id;
            p.damage = damage;
            p.radius = bulletRadius;
            spawned++;
        }
        return spawned;
    }
}
