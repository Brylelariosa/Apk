package com.hazardyard.game.core;

/** Built-in arenas. Maps are authored as one quarter (plus the centre lines) and mirrored. */
public final class MapLibrary {
    private MapLibrary() {}

    /**
     * Top-left quarter including the centre column (last character) and the centre row (last row).
     * Legend: # wall, C crate, S spawn, R rifle, G shotgun, M SMG.
     */
    private static final String[] ARENA_QUARTER = {
        "#####################",
        "#....................",
        "#.S..............R...",
        "#........##.......C..",
        "#.CC.....##.......C..",
        "#.CC.................",
        "#.........#####......",
        "####.####............",
        "#....................",
        "#..S..........CC.....",
        "#.............CC..#..",
        "#.......M.........#..",
        "#...G.............#.G",
    };

    /** The default 41 x 25 tile arena, symmetric in both axes so no spawn is favoured. */
    public static TileMap arena() {
        int qh = ARENA_QUARTER.length;
        int qw = ARENA_QUARTER[0].length();
        String[] rows = new String[qh * 2 - 1];
        for (int y = 0; y < qh; y++) {
            String q = ARENA_QUARTER[y];
            StringBuilder sb = new StringBuilder(qw * 2 - 1);
            sb.append(q);
            for (int x = qw - 2; x >= 0; x--) sb.append(q.charAt(x));
            rows[y] = sb.toString();
            rows[rows.length - 1 - y] = rows[y];
        }
        return TileMap.parse(rows);
    }
}
