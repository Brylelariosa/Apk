package com.hazardyard.game.ui;

import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.HostManager;

/** What screens may ask of the activity; keeps screens free of any knowledge about each other. */
interface Navigator {
    String playerName();

    void setPlayerName(String name);

    /** Shows the main menu and closes any open lobby or connection. {@code notice} may be null. */
    void showMenu(String notice);

    void showJoin();

    /** Opens a lobby on this device. */
    void createGame();

    /** Connects to a host found by discovery or typed in by hand. */
    void connectTo(String address, int port);

    /** Host pressed Start Game. */
    void startMatch();

    /** Live hosting / client objects (null when not in that role). */
    HostManager host();

    ClientManager client();

    /** The running match ended (normally or because the connection died). */
    void onMatchFinished(String reason);

    void toast(String message);
}
