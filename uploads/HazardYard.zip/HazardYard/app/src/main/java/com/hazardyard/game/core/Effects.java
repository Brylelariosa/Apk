package com.hazardyard.game.core;

/**
 * Pooled short-lived visual effects (muzzle flashes, impact sparks, death bursts) and the kill feed.
 * Purely presentational; never affects gameplay and never allocates after construction.
 */
public final class Effects {
    public static final int MAX = 96;
    public static final int KIND_FLASH = 0;
    public static final int KIND_SPARK = 1;
    public static final int KIND_BURST = 2;

    public final boolean[] active = new boolean[MAX];
    public final int[] kind = new int[MAX];
    public final int[] color = new int[MAX];
    public final float[] x = new float[MAX];
    public final float[] y = new float[MAX];
    public final float[] angle = new float[MAX];
    public final float[] age = new float[MAX];
    public final float[] life = new float[MAX];
    private int cursor;

    public static final int FEED_MAX = 3;
    public static final float FEED_LIFE = 4.5f;
    public final int[] feedKiller = new int[FEED_MAX];
    public final int[] feedVictim = new int[FEED_MAX];
    public final int[] feedWeapon = new int[FEED_MAX];
    public final float[] feedAge = new float[FEED_MAX];
    /** Entry 0 is the oldest. */
    public int feedCount;

    public void muzzle(float px, float py, float ang, int argb) {
        spawn(KIND_FLASH, px, py, ang, argb, 0.07f);
    }

    public void impact(float px, float py, int argb) {
        spawn(KIND_SPARK, px, py, 0f, argb, 0.20f);
    }

    public void burst(float px, float py, int argb) {
        spawn(KIND_BURST, px, py, 0f, argb, 0.50f);
    }

    private void spawn(int k, float px, float py, float ang, int argb, float lifeSeconds) {
        int slot = -1;
        for (int n = 0; n < MAX; n++) {
            int i = (cursor + n) % MAX;
            if (!active[i]) {
                slot = i;
                break;
            }
        }
        if (slot < 0) slot = cursor;
        cursor = (slot + 1) % MAX;
        active[slot] = true;
        kind[slot] = k;
        x[slot] = px;
        y[slot] = py;
        angle[slot] = ang;
        color[slot] = argb;
        age[slot] = 0f;
        life[slot] = lifeSeconds;
    }

    public void addKill(int killer, int victim, int weaponId) {
        if (feedCount == FEED_MAX) {
            for (int i = 1; i < FEED_MAX; i++) copyFeed(i, i - 1);
            feedCount--;
        }
        int i = feedCount++;
        feedKiller[i] = killer;
        feedVictim[i] = victim;
        feedWeapon[i] = weaponId;
        feedAge[i] = 0f;
    }

    private void copyFeed(int from, int to) {
        feedKiller[to] = feedKiller[from];
        feedVictim[to] = feedVictim[from];
        feedWeapon[to] = feedWeapon[from];
        feedAge[to] = feedAge[from];
    }

    public void update(float dt) {
        for (int i = 0; i < MAX; i++) {
            if (!active[i]) continue;
            age[i] += dt;
            if (age[i] >= life[i]) active[i] = false;
        }
        for (int i = 0; i < feedCount; i++) feedAge[i] += dt;
        while (feedCount > 0 && feedAge[0] > FEED_LIFE) {
            for (int i = 1; i < feedCount; i++) copyFeed(i, i - 1);
            feedCount--;
        }
    }

    public void clear() {
        for (int i = 0; i < MAX; i++) active[i] = false;
        feedCount = 0;
    }
}
