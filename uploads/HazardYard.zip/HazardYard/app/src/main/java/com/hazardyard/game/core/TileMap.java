package com.hazardyard.game.core;

/**
 * Tile grid of the arena. Walls and crates are solid for players and bullets. Also holds spawn points,
 * weapon pickup locations and a list of merged solid rectangles so the renderer draws a few dozen
 * rectangles instead of one per tile.
 */
public final class TileMap {
    public static final byte FLOOR = 0;
    public static final byte WALL = 1;
    public static final byte CRATE = 2;

    public final int width;
    public final int height;
    public final byte[] tiles;
    public final float worldW;
    public final float worldH;

    public final float[] spawnX;
    public final float[] spawnY;
    public final float[] pickupX;
    public final float[] pickupY;
    public final int[] pickupWeapon;

    /** Merged solid rectangles, 5 ints each: tileX, tileY, tilesW, tilesH, kind. */
    public final int[] blocks;
    public final int blockCount;

    private TileMap(int width, int height, byte[] tiles, float[] sx, float[] sy,
                    float[] px, float[] py, int[] pw, int[] blocks, int blockCount) {
        this.width = width;
        this.height = height;
        this.tiles = tiles;
        this.worldW = width * GameConfig.TILE;
        this.worldH = height * GameConfig.TILE;
        this.spawnX = sx;
        this.spawnY = sy;
        this.pickupX = px;
        this.pickupY = py;
        this.pickupWeapon = pw;
        this.blocks = blocks;
        this.blockCount = blockCount;
    }

    /** Anything outside the grid counts as solid, so nothing can ever leave the arena. */
    public boolean isSolid(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        return tiles[ty * width + tx] != FLOOR;
    }

    public boolean isSolidAt(float wx, float wy) {
        return isSolid((int) Math.floor(wx / GameConfig.TILE), (int) Math.floor(wy / GameConfig.TILE));
    }

    /**
     * Legend: # wall, C crate, . floor, S spawn point, R rifle / G shotgun / M SMG pickup.
     * All rows must have the same length.
     */
    public static TileMap parse(String[] rows) {
        int h = rows.length;
        int w = rows[0].length();
        byte[] tiles = new byte[w * h];
        int spawns = 0;
        int pickups = 0;
        for (int y = 0; y < h; y++) {
            if (rows[y].length() != w) throw new IllegalArgumentException("Map row " + y + " has wrong length");
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                switch (c) {
                    case '#': tiles[y * w + x] = WALL; break;
                    case 'C': tiles[y * w + x] = CRATE; break;
                    case 'S': spawns++; break;
                    case 'R': case 'G': case 'M': pickups++; break;
                    default: break;
                }
            }
        }
        float[] sx = new float[spawns];
        float[] sy = new float[spawns];
        float[] px = new float[pickups];
        float[] py = new float[pickups];
        int[] pw = new int[pickups];
        int si = 0;
        int pi = 0;
        float t = GameConfig.TILE;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                float cx = (x + 0.5f) * t;
                float cy = (y + 0.5f) * t;
                if (c == 'S') {
                    sx[si] = cx;
                    sy[si] = cy;
                    si++;
                } else if (c == 'R' || c == 'G' || c == 'M') {
                    px[pi] = cx;
                    py[pi] = cy;
                    pw[pi] = c == 'R' ? WeaponDef.RIFLE : (c == 'G' ? WeaponDef.SHOTGUN : WeaponDef.SMG);
                    pi++;
                }
            }
        }

        // Greedy rectangle merge of solid tiles of the same kind (used for drawing only).
        boolean[] used = new boolean[w * h];
        int[] blocks = new int[5 * w * h / 2 + 5];
        int bc = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                byte kind = tiles[i];
                if (kind == FLOOR || used[i]) continue;
                int bw = 1;
                while (x + bw < w && tiles[i + bw] == kind && !used[i + bw]) bw++;
                int bh = 1;
                boolean grow = true;
                while (grow && y + bh < h) {
                    for (int k = 0; k < bw; k++) {
                        int j = (y + bh) * w + x + k;
                        if (tiles[j] != kind || used[j]) {
                            grow = false;
                            break;
                        }
                    }
                    if (grow) bh++;
                }
                for (int yy = 0; yy < bh; yy++) {
                    for (int xx = 0; xx < bw; xx++) used[(y + yy) * w + x + xx] = true;
                }
                blocks[bc * 5] = x;
                blocks[bc * 5 + 1] = y;
                blocks[bc * 5 + 2] = bw;
                blocks[bc * 5 + 3] = bh;
                blocks[bc * 5 + 4] = kind;
                bc++;
            }
        }
        return new TileMap(w, h, tiles, sx, sy, px, py, pw, blocks, bc);
    }
}
