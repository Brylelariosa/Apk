package com.hazardyard.game.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.hazardyard.game.engine.ClientEngine;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.engine.HostEngine;
import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.HostManager;
import com.hazardyard.game.net.Protocol;

import java.util.Random;

/**
 * Owns the app's navigation and the lifetime of the network session (lobby host or client
 * connection) and the running match. MainActivity is only a thin window host around this class.
 */
public final class AppController implements Navigator {
    private static final String PREFS = "hazardyard";
    private static final String KEY_NAME = "player_name";

    private final Context ctx;
    private final FrameLayout root;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private Screen current;
    private HostManager host;
    private ClientManager client;
    private GameEngine engine;

    public AppController(Context context, FrameLayout rootView) {
        ctx = context;
        root = rootView;
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void start() {
        showMenu(null);
    }

    /** Returns true when the current screen consumed the back press. */
    public boolean handleBack() {
        return current != null && current.onBack();
    }

    /** Closes everything; called when the activity is destroyed. */
    public void shutdown() {
        closeSession();
        if (current != null) {
            current.onHide();
            root.removeView(current.view());
            current = null;
        }
        ui.removeCallbacksAndMessages(null);
    }

    // ------------------------------------------------------------------ Navigator

    @Override
    public String playerName() {
        String n = prefs.getString(KEY_NAME, null);
        if (n == null || n.isEmpty()) {
            n = "Player" + (1000 + new Random().nextInt(9000));
            prefs.edit().putString(KEY_NAME, n).apply();
        }
        return n;
    }

    @Override
    public void setPlayerName(String name) {
        prefs.edit().putString(KEY_NAME, Protocol.sanitizeName(name)).apply();
    }

    @Override
    public void showMenu(String notice) {
        closeSession();
        show(new MenuScreen(ctx, this, notice));
    }

    @Override
    public void showJoin() {
        closeSession();
        show(new JoinScreen(ctx, this));
    }

    @Override
    public void createGame() {
        closeSession();
        final HostManager h = new HostManager();
        host = h;
        final String name = playerName();
        Thread starter = new Thread(new Runnable() {
            @Override
            public void run() {
                Exception failure = null;
                try {
                    h.start(name);
                } catch (Exception e) {
                    failure = e;
                }
                final Exception f = failure;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (host != h) {
                            h.close();
                            return;
                        }
                        if (f != null) {
                            showMenu("Could not open a lobby: " + f.getMessage());
                        } else {
                            show(LobbyScreen.forHost(ctx, AppController.this));
                        }
                    }
                });
            }
        }, "hy-host-start");
        starter.start();
    }

    @Override
    public void connectTo(String address, int port) {
        closeSession();
        client = new ClientManager();
        show(LobbyScreen.forClientConnecting(ctx, this, address, port));
    }

    @Override
    public void startMatch() {
        if (engine != null) return;
        if (host != null) {
            boolean others = host.lobby().count() > 1;
            if (!host.startMatch()) {
                toast("Everyone needs to be ready first.");
                return;
            }
            engine = new HostEngine(host);
            show(new GameScreen(ctx, this, engine, others));
        } else if (client != null && client.isInMatch()) {
            engine = new ClientEngine(client);
            show(new GameScreen(ctx, this, engine, true));
        }
    }

    @Override
    public HostManager host() {
        return host;
    }

    @Override
    public ClientManager client() {
        return client;
    }

    @Override
    public void onMatchFinished(String reason) {
        engine = null;
        if (host != null) {
            host.endMatch();
            show(LobbyScreen.forHost(ctx, this));
        } else if (client != null && !client.isClosed()) {
            show(LobbyScreen.forClient(ctx, this));
        } else {
            closeSession();
            toast(reason != null ? reason : "You were disconnected.");
            show(new MenuScreen(ctx, this, null));
        }
    }

    @Override
    public void toast(String message) {
        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ internals

    private void show(Screen next) {
        if (current != null) {
            current.onHide();
            root.removeView(current.view());
        }
        current = next;
        root.addView(next.view(), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        next.onShow();
    }

    private void closeSession() {
        if (engine != null) {
            engine.close();
            engine = null;
        }
        if (host != null) {
            host.close();
            host = null;
        }
        if (client != null) {
            client.close();
            client = null;
        }
    }
}
