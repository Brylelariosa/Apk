package com.hazardyard.game.ui;

import android.content.Context;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.render.Palette;

/** Title screen: pick a name, then create a game or go looking for one. */
final class MenuScreen implements Screen {
    private final Context ctx;
    private final Navigator nav;
    private final FrameLayout root;
    private final EditText nameField;

    MenuScreen(Context c, Navigator navigator, String notice) {
        ctx = c;
        nav = navigator;
        root = new FrameLayout(c);
        root.addView(new BackdropView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(Ui.dp(c, 40), Ui.dp(c, 24), Ui.dp(c, 40), Ui.dp(c, 24));
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- left: title block ----
        LinearLayout hero = Ui.column(c);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(hero, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 24, 0, c));

        TextView t1 = Ui.label(c, "Hazard", 56f, Palette.TEXT, true);
        TextView t2 = Ui.label(c, "Yard", 56f, Palette.ACCENT, true);
        hero.addView(t1);
        hero.addView(t2);
        hero.addView(new BackdropView.StripeBar(c), Ui.lp(Ui.dp(c, 150), Ui.dp(c, 10), 0f, 0, 12, 0, 0, c));
        TextView sub = Ui.label(c, "Top-down arena shooter for 2\u20134 players on the same Wi-Fi", 15f,
                Palette.TEXT_DIM, false);
        hero.addView(sub, Ui.fillWidth(c, 14));
        if (notice != null && !notice.isEmpty()) {
            TextView n = Ui.label(c, notice, 14f, Palette.WARN, false);
            hero.addView(n, Ui.fillWidth(c, 14));
        }

        // ---- right: actions ----
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        content.addView(scroll, Ui.lp(Ui.dp(c, 310), ViewGroup.LayoutParams.MATCH_PARENT, 0f, 0, 0, 0, 0, c));

        LinearLayout panel = Ui.panel(c);
        scroll.addView(panel, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(Ui.label(c, "Your name", 13f, Palette.TEXT_DIM, false));
        nameField = new EditText(c);
        nameField.setSingleLine(true);
        nameField.setText(nav.playerName());
        nameField.setSelectAllOnFocus(true);
        nameField.setTextColor(Palette.TEXT);
        nameField.setHintTextColor(Palette.TEXT_DIM);
        nameField.setHint("Player");
        nameField.setTypeface(Ui.MEDIUM);
        nameField.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f);
        nameField.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 14), 0);
        nameField.setBackground(Ui.rounded(c, 0xFF0F151C, 0xFF3A4757, 10f, 1.5f));
        nameField.setFilters(new InputFilter[] {new InputFilter.LengthFilter(Protocol.MAX_NAME)});
        nameField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        nameField.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_EXTRACT_UI);
        nameField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent event) {
                v.clearFocus();
                hideKeyboard(v);
                return true;
            }
        });
        panel.addView(nameField, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 48), 0f, 0, 6, 0, 0, c));

        Button create = Ui.button(c, "Create Game", true);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commitName();
                nav.createGame();
            }
        });
        panel.addView(create, Ui.fillWidth(c, 16));

        Button join = Ui.button(c, "Join Game", false);
        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                commitName();
                nav.showJoin();
            }
        });
        panel.addView(join, Ui.fillWidth(c, 10));

        TextView hint = Ui.label(c, "Left stick moves. Right stick aims and fires.", 12f, Palette.TEXT_DIM, false);
        hint.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.addView(hint, Ui.fillWidth(c, 14));
    }

    private void commitName() {
        hideKeyboard(nameField);
        nav.setPlayerName(nameField.getText().toString());
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // nothing to start
    }

    @Override
    public void onHide() {
        hideKeyboard(nameField);
        nav.setPlayerName(nameField.getText().toString());
    }

    @Override
    public boolean onBack() {
        return false;
    }
}
