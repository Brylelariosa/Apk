package com.hazardyard.game.ui;

import android.graphics.Canvas;
import android.util.Log;
import android.view.SurfaceHolder;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.HudRenderer;
import com.hazardyard.game.render.Renderer;

/**
 * The one game thread: fixed-timestep simulation, then one rendered frame, paced to 60 FPS with a
 * sleep (no busy waiting, which also keeps battery use down on 90/120 Hz screens). Input, rendering
 * and simulation run in strict sequence on this thread, so game state needs no locking; only the
 * touch input crosses threads and it does so through {@link InputController}'s own lock.
 */
final class GameLoop implements Runnable {
    interface Callback {
        /** The engine reports that the session is over. Called once, on the game thread. */
        void onEngineFinished(String reason);
    }

    private static final long FRAME_NANOS = 16_666_667L;

    private final SurfaceHolder holder;
    private final GameEngine engine;
    private final InputController input;
    private final Callback callback;
    private final float density;
    private final Renderer renderer = new Renderer();
    private final HudRenderer hud = new HudRenderer();
    private final Camera camera = new Camera();
    private final LocalInput local = new LocalInput();

    private volatile boolean running;
    private volatile int width;
    private volatile int height;
    private Thread thread;

    GameLoop(SurfaceHolder holder, GameEngine engine, InputController input, float density, Callback callback) {
        this.holder = holder;
        this.engine = engine;
        this.input = input;
        this.density = density;
        this.callback = callback;
    }

    void setSize(int w, int h) {
        width = w;
        height = h;
    }

    void start() {
        running = true;
        thread = new Thread(this, "hy-game");
        thread.start();
    }

    /** Stops the loop and waits until it has really stopped (the surface may be destroyed afterwards). */
    void stop() {
        running = false;
        Thread t = thread;
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        thread = null;
    }

    @Override
    public void run() {
        GameState st = engine.state();
        int appliedW = -1;
        int appliedH = -1;
        boolean cameraPlaced = false;
        boolean aimPlaced = false;
        boolean notified = false;
        int errors = 0;
        float accumulator = 0f;
        float time = 0f;
        long last = System.nanoTime();

        while (running) {
            long frameStart = System.nanoTime();
            try {
                float frame = Math.min((frameStart - last) * 1e-9f, 0.1f);
                last = frameStart;

                int w = width;
                int h = height;
                if (w != appliedW || h != appliedH) {
                    appliedW = w;
                    appliedH = h;
                    camera.setViewport(w, h, st.map.worldW, st.map.worldH);
                }

                Player me = st.local();
                if (!aimPlaced && me.connected && me.alive) {
                    local.aim = me.aim;
                    aimPlaced = true;
                }

                accumulator += frame;
                int steps = 0;
                while (accumulator >= GameConfig.SIM_DT && steps < GameConfig.MAX_STEPS_PER_FRAME) {
                    input.sample(local);
                    engine.fixedUpdate(GameConfig.SIM_DT, local);
                    accumulator -= GameConfig.SIM_DT;
                    steps++;
                }
                if (steps == GameConfig.MAX_STEPS_PER_FRAME) accumulator = 0f;
                engine.frameUpdate(frame);
                time += frame;

                if (me.connected) {
                    if (!cameraPlaced) {
                        camera.snapTo(me.rx, me.ry);
                        cameraPlaced = true;
                    } else {
                        camera.follow(me.rx, me.ry, frame);
                    }
                } else if (!cameraPlaced) {
                    camera.snapTo(st.map.worldW * 0.5f, st.map.worldH * 0.5f);
                }

                draw(st, time);

                if (!notified && engine.isFinished()) {
                    notified = true;
                    callback.onEngineFinished(engine.finishReason());
                }

                errors = 0;
            } catch (RuntimeException e) {
                // One bad frame is survivable; a persistent failure ends the session cleanly.
                Log.e("HazardYard", "Frame failed", e);
                if (++errors > 30 && !notified) {
                    notified = true;
                    callback.onEngineFinished("The match stopped because of an internal error.");
                }
            }

            long spent = System.nanoTime() - frameStart;
            long rest = FRAME_NANOS - spent;
            if (rest > 1_000_000L) {
                try {
                    Thread.sleep(rest / 1_000_000L, (int) (rest % 1_000_000L));
                } catch (InterruptedException e) {
                    running = false;
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    private void draw(GameState st, float time) {
        if (!holder.getSurface().isValid()) return;
        Canvas canvas = null;
        try {
            canvas = holder.lockHardwareCanvas();
        } catch (IllegalStateException | IllegalArgumentException e) {
            return;
        }
        if (canvas == null) return;
        try {
            renderer.draw(canvas, st, camera, time);
            hud.draw(canvas, st, camera, input, engine.pingMs(), density, time);
        } finally {
            try {
                holder.unlockCanvasAndPost(canvas);
            } catch (IllegalStateException | IllegalArgumentException e) {
                // the surface went away while drawing; the next surfaceChanged restarts us
            }
        }
    }
}
