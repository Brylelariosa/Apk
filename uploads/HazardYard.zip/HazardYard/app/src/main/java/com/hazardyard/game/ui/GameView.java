package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.InputController;

import java.util.ArrayList;
import java.util.List;

/**
 * Surface the match is drawn on. Owns the game loop (started when the surface is ready, stopped
 * before it disappears) and translates Android touch events into {@link InputController} calls.
 */
final class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private final GameEngine engine;
    private final GameLoop.Callback callback;
    private final InputController input = new InputController();
    private final float density;
    private GameLoop loop;

    GameView(Context c, GameEngine engine, GameLoop.Callback callback) {
        super(c);
        this.engine = engine;
        this.callback = callback;
        this.density = c.getResources().getDisplayMetrics().density;
        getHolder().addCallback(this);
        setKeepScreenOn(true);
    }

    InputController input() {
        return input;
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // The loop starts in surfaceChanged, once the size is known.
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        input.setViewport(w, h, density);
        if (loop == null) {
            loop = new GameLoop(holder, engine, input, density, callback);
            loop.setSize(w, h);
            loop.start();
        } else {
            loop.setSize(w, h);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        stopLoop();
    }

    /** Stops the game thread (idempotent). */
    void stopLoop() {
        if (loop != null) {
            loop.stop();
            loop = null;
        }
        input.cancelAll();
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (!changed) return;
        // Keep the Android "back" swipe away from the thumb zones at the bottom of both screen edges.
        int w = r - l;
        int h = b - t;
        int edge = Math.round(48f * density);
        int tall = Math.min(h, Math.round(200f * density));
        List<Rect> rects = new ArrayList<>(2);
        rects.add(new Rect(0, h - tall, edge, h));
        rects.add(new Rect(w - edge, h - tall, w, h));
        setSystemGestureExclusionRects(rects);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                input.onPointerDown(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    input.onPointerMove(e.getPointerId(i), e.getX(i), e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                input.onPointerUp(e.getPointerId(e.getActionIndex()));
                break;
            case MotionEvent.ACTION_CANCEL:
                input.cancelAll();
                break;
            default:
                break;
        }
        return true;
    }
}
