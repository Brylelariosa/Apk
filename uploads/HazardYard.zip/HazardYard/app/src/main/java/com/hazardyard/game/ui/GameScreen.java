package com.hazardyard.game.ui;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.Palette;

/** The match: a GameView plus the pause menu on top of it. */
final class GameScreen implements Screen, GameLoop.Callback, InputController.Listener {
    private final Navigator nav;
    private final GameEngine engine;
    private final FrameLayout root;
    private final GameView gameView;
    private final View pauseOverlay;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean paused;
    private boolean finishing;

    GameScreen(Context c, Navigator navigator, GameEngine eng, boolean multiplayer) {
        nav = navigator;
        engine = eng;
        root = new FrameLayout(c);
        gameView = new GameView(c, eng, this);
        gameView.input().setListener(this);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout overlay = new FrameLayout(c);
        overlay.setBackgroundColor(0xB0000000);
        overlay.setClickable(true);
        overlay.setVisibility(View.GONE);
        LinearLayout panel = Ui.panel(c);
        panel.addView(Ui.label(c, "Paused", 28f, Palette.TEXT, true));
        if (multiplayer) {
            panel.addView(Ui.label(c, "The match keeps running for the other players.", 13f, Palette.TEXT_DIM, false),
                    Ui.fillWidth(c, 6));
        }
        Button resume = Ui.button(c, "Resume", true);
        resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPaused(false);
            }
        });
        panel.addView(resume, Ui.fillWidth(c, 16));
        Button quit = Ui.button(c, "Leave match", false);
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishing = true;
                nav.showMenu(null);
            }
        });
        panel.addView(quit, Ui.fillWidth(c, 10));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(Ui.dp(c, 320),
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        overlay.addView(panel, plp);
        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pauseOverlay = overlay;
    }

    private void setPaused(boolean p) {
        paused = p;
        pauseOverlay.setVisibility(p ? View.VISIBLE : View.GONE);
        gameView.input().cancelAll();
        engine.setPaused(p);
    }

    // ------------------------------------------------------------------ callbacks

    /** Pause button tapped (UI thread). */
    @Override
    public void onPausePressed() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (!paused) setPaused(true);
            }
        });
    }

    /** Game thread: the session ended. */
    @Override
    public void onEngineFinished(final String reason) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (finishing) return;
                finishing = true;
                nav.onMatchFinished(reason);
            }
        });
    }

    // ------------------------------------------------------------------ Screen

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // The loop starts by itself when the surface is ready.
    }

    @Override
    public void onHide() {
        finishing = true;
        ui.removeCallbacksAndMessages(null);
        gameView.stopLoop();
        engine.close();
    }

    @Override
    public boolean onBack() {
        setPaused(!paused);
        return true;
    }
}
