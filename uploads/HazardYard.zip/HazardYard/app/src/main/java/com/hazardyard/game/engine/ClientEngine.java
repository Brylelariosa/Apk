package com.hazardyard.game.engine;

import com.hazardyard.game.core.CollisionSystem;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.Projectile;
import com.hazardyard.game.core.ProjectilePool;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.LobbyManager;
import com.hazardyard.game.net.NetworkManager;
import com.hazardyard.game.net.Packets;
import com.hazardyard.game.net.PacketReader;
import com.hazardyard.game.net.PacketWriter;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.net.SnapshotCodec;

/**
 * Mirrors the host's match. Remote players are interpolated between snapshots; the local player moves
 * immediately (client-side prediction) and is nudged back only when the host's authoritative position,
 * matched to the input it acknowledged, disagrees noticeably. Bullets are simulated locally from fire
 * events for display, but only the host decides who gets hit.
 */
public final class ClientEngine implements GameEngine {
    /** Errors below this (world units) are ignored: they are timing noise, not disagreement. */
    static final float CORRECTION_DEADZONE = 10f;
    /** Errors above this snap instantly instead of gliding. */
    static final float SNAP_DISTANCE = 64f;
    private static final int HISTORY = 64;

    private final ClientManager net;
    private final GameState st;
    private final int myId;
    private final CollisionSystem col;
    private final SnapshotCodec.Data snap = new SnapshotCodec.Data();
    private final PacketReader reader = new PacketReader();
    private final PacketWriter writer = new PacketWriter(64);
    private final Packets.Input inputPacket = new Packets.Input();
    private final Packets.Fire firePacket = new Packets.Fire();
    private final Packets.Hit hitPacket = new Packets.Hit();
    private final Packets.Kill killPacket = new Packets.Kill();
    private final LocalInput quantized = new LocalInput();

    // prediction bookkeeping
    private final float[] sentX = new float[HISTORY];
    private final float[] sentY = new float[HISTORY];
    private int sendSeq;
    private float sendTimer;
    private int lastMx, lastMy, lastAim16;
    private boolean lastFiring;
    private boolean sentOnce;

    private boolean hasSnapshot;
    private volatile boolean finished;
    private String reason;
    /** Number of position corrections applied so far (exposed for tests and diagnostics). */
    public int correctionCount;

    public ClientEngine(ClientManager net) {
        this.net = net;
        this.myId = net.localPlayerId();
        st = new GameState(MapLibrary.arena(), myId);
        col = st.collision;
        LobbyManager.Entry[] roster = new LobbyManager.Entry[GameConfig.MAX_PLAYERS];
        for (int i = 0; i < roster.length; i++) roster[i] = new LobbyManager.Entry();
        net.lobby().copyTo(roster);
        for (int i = 0; i < roster.length; i++) {
            if (roster[i].used) st.players[i].name = roster[i].name;
        }
    }

    @Override
    public GameState state() {
        return st;
    }

    @Override
    public void fixedUpdate(float dt, LocalInput in) {
        if (finished) return;
        NetworkManager.Inbound m;
        while ((m = net.poll()) != null) handle(m);
        if (net.consumeReturnToLobby()) {
            finished = true;
            return;
        }
        if (net.isClosed()) {
            finished = true;
            reason = "Connection to the host was lost.";
            return;
        }
        if (!hasSnapshot) return;

        quantized.moveX = in.moveX;
        quantized.moveY = in.moveY;
        quantized.aim = in.aim;
        quantized.firing = in.firing;
        quantized.quantizeMove();

        predictLocal(dt);
        sendInput(dt, in);
        advanceProjectiles(dt);
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.hitFlash > 0f) p.hitFlash -= dt;
            if (p.muzzleFlash > 0f) p.muzzleFlash -= dt;
        }
        st.effects.update(dt);
    }

    // ------------------------------------------------------------------ inbound messages

    private void handle(NetworkManager.Inbound m) {
        try {
            reader.wrap(m.data, 0, m.data.length);
            switch (reader.u8()) {
                case Protocol.S_SNAPSHOT:
                    SnapshotCodec.decode(reader, snap);
                    applySnapshot();
                    break;
                case Protocol.S_FIRE:
                    firePacket.read(reader);
                    onFire();
                    break;
                case Protocol.S_HIT:
                    hitPacket.read(reader);
                    onHit();
                    break;
                case Protocol.S_KILL:
                    killPacket.read(reader);
                    onKill();
                    break;
                default:
                    break;
            }
        } catch (RuntimeException malformed) {
            // Ignore a damaged packet; the next snapshot replaces whatever it carried.
        }
    }

    private void applySnapshot() {
        hasSnapshot = true;
        st.phase = MathUtil.clamp(snap.phase, GameState.PHASE_LOBBY, GameState.PHASE_FINISHED);
        st.timeLeft = snap.timeLeftDs / 10f;
        st.countdown = snap.countdownDs / 10f;
        st.winnerId = snap.winner;
        for (int i = 0; i < st.pickups.length && i < 16; i++) {
            st.pickups[i].active = (snap.pickupMask & (1 << i)) != 0;
        }
        for (int i = 0; i < GameConfig.MAX_PLAYERS; i++) {
            Player p = st.players[i];
            if ((snap.presentMask & (1 << i)) == 0) {
                p.connected = false;
                p.alive = false;
                continue;
            }
            if (!p.connected) {
                p.connected = true;
                p.interpValid = false;
            }
            int flags = snap.flags[i];
            boolean wasAlive = p.alive;
            p.alive = (flags & SnapshotCodec.F_ALIVE) != 0;
            p.health = snap.health[i];
            p.kills = snap.kills[i];
            p.deaths = snap.deaths[i];
            p.respawnTimer = snap.respawnDs[i] / 10f;
            p.spawnProtect = (flags & SnapshotCodec.F_PROTECTED) != 0 ? 1f : 0f;
            Weapon w = p.weapon;
            if (w.def.id != snap.weapon[i]) w.equip(WeaponDef.byId(snap.weapon[i]));
            w.ammo = snap.ammo[i];
            w.reloading = (flags & SnapshotCodec.F_RELOADING) != 0;
            w.reloadFraction = snap.reload[i] / 255f;
            if (i == myId) reconcileLocal(p, i, wasAlive);
            else updateRemote(p, i, wasAlive);
        }
    }

    private void updateRemote(Player p, int i, boolean wasAlive) {
        float nx = snap.x[i];
        float ny = snap.y[i];
        float na = snap.aim[i];
        p.x = nx;
        p.y = ny;
        p.aim = na;
        float dx = nx - p.rx;
        float dy = ny - p.ry;
        boolean teleport = !p.interpValid || !p.alive || !wasAlive || dx * dx + dy * dy > 100f * 100f;
        if (teleport) {
            p.fromX = p.toX = p.rx = nx;
            p.fromY = p.toY = p.ry = ny;
            p.fromAim = p.toAim = p.rAim = na;
            p.interpT = 1f;
            p.interpValid = true;
        } else {
            p.fromX = p.rx;
            p.fromY = p.ry;
            p.fromAim = p.rAim;
            p.toX = nx;
            p.toY = ny;
            p.toAim = na;
            p.interpT = 0f;
        }
    }

    /**
     * Compares the host's position with where this client was when it sent the input the host had
     * applied last. The difference is the real disagreement; the time the packet spent travelling
     * cancels out.
     */
    private void reconcileLocal(Player p, int i, boolean wasAlive) {
        float sx = snap.x[i];
        float sy = snap.y[i];
        boolean predicting = p.alive && wasAlive && st.phase == GameState.PHASE_PLAYING && p.interpValid;
        if (!predicting) {
            p.x = sx;
            p.y = sy;
            p.visX = 0f;
            p.visY = 0f;
            p.rx = sx;
            p.ry = sy;
            if (p.alive && !wasAlive) {
                p.aim = snap.aim[i];
                p.rAim = p.aim;
            }
            p.interpValid = true;
            return;
        }
        if (!sentOnce) return;
        int ack = snap.ack[i];
        if (((sendSeq - ack) & 0xFF) >= HISTORY) return;
        int slot = ack & (HISTORY - 1);
        float ex = sx - sentX[slot];
        float ey = sy - sentY[slot];
        float err2 = ex * ex + ey * ey;
        if (err2 < CORRECTION_DEADZONE * CORRECTION_DEADZONE) return;
        correctionCount++;
        p.x += ex;
        p.y += ey;
        if (err2 > SNAP_DISTANCE * SNAP_DISTANCE) {
            p.visX = 0f;
            p.visY = 0f;
        } else {
            p.visX -= ex;
            p.visY -= ey;
        }
        col.pushOut(p.x, p.y, GameConfig.PLAYER_RADIUS);
        p.x = col.resX;
        p.y = col.resY;
        // Inputs sent before this correction carry stale positions; shift them so the next
        // snapshot does not see (and apply) the same disagreement a second time.
        for (int k = 0; k < HISTORY; k++) {
            sentX[k] += ex;
            sentY[k] += ey;
        }
    }

    private void onFire() {
        WeaponDef d = WeaponDef.byId(firePacket.weaponId);
        d.spawn(st.projectiles, firePacket.owner, firePacket.x, firePacket.y, firePacket.angle,
                firePacket.seed, firePacket.baseId);
        int owner = firePacket.owner;
        if (owner >= 0 && owner < st.players.length) st.players[owner].muzzleFlash = 0.06f;
        float reach = GameConfig.PLAYER_RADIUS + d.barrelLength;
        st.effects.muzzle(firePacket.x + (float) Math.cos(firePacket.angle) * reach,
                firePacket.y + (float) Math.sin(firePacket.angle) * reach, firePacket.angle, d.color);
    }

    private void onHit() {
        Projectile b = st.projectiles.findById(hitPacket.projectileId);
        if (b != null) {
            st.effects.impact(hitPacket.x, hitPacket.y, WeaponDef.byId(b.weaponId).color);
            st.projectiles.release(b);
        } else {
            st.effects.impact(hitPacket.x, hitPacket.y, 0xFFFFFFFF);
        }
        if (hitPacket.victim >= 0 && hitPacket.victim < st.players.length && hitPacket.damage > 0) {
            st.players[hitPacket.victim].hitFlash = 0.15f;
        }
    }

    private void onKill() {
        st.effects.addKill(killPacket.killer, killPacket.victim, killPacket.weaponId);
        if (killPacket.victim >= 0 && killPacket.victim < st.players.length) {
            Player v = st.players[killPacket.victim];
            st.effects.burst(v.rx, v.ry, PlayerColors.of(killPacket.victim));
        }
    }

    // ------------------------------------------------------------------ local prediction + output

    private void predictLocal(float dt) {
        Player me = st.players[myId];
        if (!me.connected) return;
        me.aim = MathUtil.rotateToward(me.aim, quantized.aim, GameConfig.PLAYER_TURN_RATE * dt);
        me.rAim = me.aim;
        if (me.alive && st.phase == GameState.PHASE_PLAYING) {
            float mx = quantized.moveX;
            float my = quantized.moveY;
            float len2 = mx * mx + my * my;
            if (len2 > 1f) {
                float inv = 1f / (float) Math.sqrt(len2);
                mx *= inv;
                my *= inv;
                len2 = 1f;
            }
            if (len2 > 0f) {
                float step = GameConfig.PLAYER_SPEED * dt;
                col.moveCircle(me.x, me.y, mx * step, my * step, GameConfig.PLAYER_RADIUS);
                me.x = col.resX;
                me.y = col.resY;
                pushOutOfRemotePlayers(me);
            }
        }
        float decay = (float) Math.exp(-12f * dt);
        me.visX *= decay;
        me.visY *= decay;
        me.rx = me.x + me.visX;
        me.ry = me.y + me.visY;
    }

    /** Players are solid to each other; remote players are taken at the position they are drawn at. */
    private void pushOutOfRemotePlayers(Player me) {
        float minDist = 2f * GameConfig.PLAYER_RADIUS;
        boolean moved = false;
        for (int i = 0; i < st.players.length; i++) {
            Player o = st.players[i];
            if (o == me || !o.connected || !o.alive) continue;
            float dx = me.x - o.rx;
            float dy = me.y - o.ry;
            float d2 = dx * dx + dy * dy;
            if (d2 >= minDist * minDist) continue;
            float d = (float) Math.sqrt(d2);
            if (d < 1e-4f) continue;
            float push = (minDist - d) / d;
            me.x += dx * push * 0.5f;
            me.y += dy * push * 0.5f;
            moved = true;
        }
        if (moved) {
            col.pushOut(me.x, me.y, GameConfig.PLAYER_RADIUS);
            me.x = col.resX;
            me.y = col.resY;
        }
    }

    private void sendInput(float dt, LocalInput in) {
        Player me = st.players[myId];
        sendTimer += dt;
        int mx = Math.round(quantized.moveX * 127f);
        int my = Math.round(quantized.moveY * 127f);
        int aim16 = MathUtil.angleToU16(in.aim);
        boolean moving = mx != 0 || my != 0;
        boolean dirty = mx != lastMx || my != lastMy || aim16 != lastAim16;
        boolean flagChanged = in.firing != lastFiring;
        float interval = (moving || dirty) ? GameConfig.INPUT_SEND_INTERVAL_MOVING : GameConfig.INPUT_SEND_INTERVAL_IDLE;
        if (sentOnce && !flagChanged && sendTimer < interval - 0.001f) {
            if (in.reload) net.sendReload();
            return;
        }
        sendSeq = (sendSeq + 1) & 0xFF;
        inputPacket.seq = sendSeq;
        inputPacket.moveX = mx;
        inputPacket.moveY = my;
        inputPacket.aim16 = aim16;
        inputPacket.firing = in.firing;
        net.send(inputPacket.encode(writer));
        sentX[sendSeq & (HISTORY - 1)] = me.x;
        sentY[sendSeq & (HISTORY - 1)] = me.y;
        lastMx = mx;
        lastMy = my;
        lastAim16 = aim16;
        lastFiring = in.firing;
        sendTimer = 0f;
        sentOnce = true;
        if (in.reload) net.sendReload();
    }

    private void advanceProjectiles(float dt) {
        ProjectilePool pool = st.projectiles;
        for (int i = pool.activeCount - 1; i >= 0; i--) {
            Projectile b = pool.items[pool.activeList[i]];
            int status = col.advance(b, dt);
            if (status == CollisionSystem.HIT_WALL) {
                st.effects.impact(b.x, b.y, WeaponDef.byId(b.weaponId).color);
                pool.release(b);
            } else if (status == CollisionSystem.EXPIRED) {
                pool.release(b);
            }
        }
    }

    // ------------------------------------------------------------------ per frame

    @Override
    public void frameUpdate(float dt) {
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == myId || !p.connected || !p.interpValid) continue;
            p.interpT += dt;
            float a = Math.min(p.interpT / GameConfig.SNAPSHOT_INTERVAL, 1.35f);
            p.rx = p.fromX + (p.toX - p.fromX) * a;
            p.ry = p.fromY + (p.toY - p.fromY) * a;
            p.rAim = MathUtil.lerpAngle(p.fromAim, p.toAim, Math.min(a, 1f));
        }
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override
    public String finishReason() {
        return reason;
    }

    @Override
    public int pingMs() {
        return net.pingMs;
    }

    @Override
    public void close() {
        finished = true;
    }
}
