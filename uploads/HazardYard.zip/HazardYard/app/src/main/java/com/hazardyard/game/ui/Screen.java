package com.hazardyard.game.ui;

import android.view.View;

/** One full-screen page of the app (menu, join list, lobby, match). */
interface Screen {
    View view();

    /** The screen was added to the window. */
    void onShow();

    /** The screen is about to be removed; stop threads and listeners here. */
    void onHide();

    /** Back was pressed. Return true when the screen handled it. */
    boolean onBack();
}
