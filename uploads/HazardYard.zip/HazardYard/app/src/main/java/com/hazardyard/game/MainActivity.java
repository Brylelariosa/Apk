package com.hazardyard.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;

import com.hazardyard.game.render.Palette;
import com.hazardyard.game.ui.AppController;

/**
 * Thin window host: sets up the full-screen root view and hands everything else (navigation, lobby,
 * network session, match) to {@link AppController}.
 */
public final class MainActivity extends Activity {
    private AppController app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Palette.BACKDROP);
        setContentView(root);
        app = new AppController(this, root);
        app.start();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    /** Immersive mode: bars stay hidden and reappear only on an edge swipe. */
    private void hideSystemBars() {
        WindowInsetsController controller = getWindow().getInsetsController();
        if (controller == null) return;
        controller.hide(WindowInsets.Type.systemBars());
        controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (app != null && app.handleBack()) return;
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (app != null) app.shutdown();
        super.onDestroy();
    }
}
