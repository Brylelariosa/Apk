package com.zipapkbuilder.feature.download

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.FloatingTransferIndicator
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.model.DownloadTask
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Owns every [DownloadTask] the app currently knows about and the worker
 * pool that runs them — queueing, starting, and retrying tasks, and the
 * small per-task bookkeeping ([hasActiveTask], [snapshot], [remove],
 * [removeFinished]) [DownloadDialogController] and [DownloadManager] read
 * and act on. Split out of [DownloadManager] as the scheduling layer between
 * "here's a task to run" ([DownloadManager]'s two entry points) and "here's
 * how to actually transfer its bytes" ([DownloadEngine]).
 *
 * [showManagerDialog] opens the Download Manager dialog — passed in as a
 * callback rather than a direct [DownloadDialogController] reference so this
 * class doesn't need to depend on that concrete class; [DownloadManager]
 * wires the two together.
 *
 * Also owns checkpointing every task's state to [downloadPersistence] at
 * every point worth persisting — submit, retry, restore, and every terminal
 * outcome — so a task that's QUEUED/DOWNLOADING/PAUSED/FAILED/CANCELLED when
 * the process dies is never simply lost; see [DownloadPersistence]'s kdoc.
 */
class DownloadQueue(
    private val activity: MainActivity,
    private val downloadEngine: DownloadEngine,
    private val downloadPersistence: DownloadPersistence,
    private val showManagerDialog: () -> Unit
) {
    companion object {
        /**
         * Process-wide (not tied to any one [DownloadQueue]/Activity instance)
         * monotonically increasing counter, and the matching "task id
         * currently owned by a live worker" registry — together these are
         * what let a [DownloadQueue] safely restore state left behind by a
         * *previous*, possibly still-running, instance of itself.
         *
         * This only ever matters in one narrow window: the Activity is
         * recreated (a theme, locale, or font-scale change, or a foldable's
         * screen-layout change — none of which are in this app's
         * `android:configChanges`) while a download is actively
         * transferring. [MainActivity.onDestroy] deliberately doesn't
         * interrupt an in-flight download (see its kdoc), so the *old*
         * [DownloadQueue]'s worker thread — and its checkpoint writes — can
         * still be running for a little while after a *new* [DownloadQueue]
         * has already been constructed and called [restoreTasks] against
         * the very same persisted state. Left unguarded, that race can
         * revert the persisted queue to older data (whichever instance's
         * checkpoint happens to write last "wins") or start a second worker
         * downloading the same file the old one is still writing.
         *
         * A real process death — overwhelmingly the common case a restore
         * actually runs for — starts [generationCounter] fresh at 0 with an
         * empty [liveTasksById] every time, so neither mechanism ever
         * changes behavior there; they only do anything in the rarer
         * within-process-recreation case described above.
         */
        private val generationCounter = java.util.concurrent.atomic.AtomicLong(0)
        private fun nextGeneration(): Long = generationCounter.incrementAndGet()

        /** task id → the live [DownloadTask] a worker is currently
         *  transferring, across every [DownloadQueue] instance in this
         *  process. Populated/cleared in lockstep with every place that
         *  flips [DownloadTask.workerActive] true/false. */
        private val liveTasksById = java.util.concurrent.ConcurrentHashMap<String, DownloadTask>()
    }

    /** This instance's place in [generationCounter] — see its kdoc. Only the
     *  [DownloadQueue] holding the *current* (highest-assigned) generation
     *  actually writes a checkpoint; see [persistNow]. */
    private val myGeneration = nextGeneration()

    /** Every download the manager knows about, newest first. Synchronized since
     *  [downloadExecutor] threads and the main thread both touch it. */
    private val downloadTasks = java.util.Collections.synchronizedList(mutableListOf<DownloadTask>())

    /**
     * Separate from [MainActivity.bgExecutor] on purpose: downloads can be numerous and
     * long-running (paused for minutes waiting on connectivity), and shouldn't be
     * able to starve build/API calls — or vice versa — by sharing one pool. 2
     * workers means up to 2 downloads actually transfer at once; more just queue
     * (shown as status QUEUED) until a slot frees up, which keeps a burst of
     * downloads from saturating a mobile connection.
     */
    private val downloadExecutor: ExecutorService = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "download-worker").apply { isDaemon = true }
    }

    /** Stops accepting new downloads; call from `onDestroy`. This only stops
     *  accepting *new* downloads, it doesn't interrupt ones already running. */
    fun shutdown() = downloadExecutor.shutdown()

    /** True if a non-terminal task with this id is already queued or running —
     *  used to avoid spawning a second copy of the same download. */
    fun hasActiveTask(id: String): Boolean =
        synchronized(downloadTasks) { downloadTasks.any { it.id == id && !it.isTerminal } }

    /** The task with this id, if the manager currently knows about one (active or terminal). */
    fun find(id: String): DownloadTask? =
        synchronized(downloadTasks) { downloadTasks.firstOrNull { it.id == id } }

    /** A snapshot of every known task, for the dialog to render without holding the lock. */
    fun snapshot(): List<DownloadTask> = synchronized(downloadTasks) { downloadTasks.toList() }

    /** Re-saves the current snapshot to [downloadPersistence] — called at every
     *  meaningful state change rather than the caller reaching into
     *  [downloadPersistence] directly, so there's exactly one place that
     *  decides *when* a checkpoint is worth writing.
     *
     *  A no-op if a newer [DownloadQueue] instance has since been constructed
     *  in this process (see [generationCounter]'s kdoc) — this instance's
     *  view of "every task" is known-stale at that point (it can never see
     *  whatever the newer instance has since done), so writing here would
     *  risk silently reverting the persisted state back to older data
     *  instead of just leaving it alone. */
    fun persistNow() {
        if (myGeneration != generationCounter.get()) return
        downloadPersistence.saveSnapshot(snapshot())
    }

    /** Drops every task in a terminal state (the "Clear finished" button). */
    fun removeFinished() {
        synchronized(downloadTasks) { downloadTasks.removeAll { it.isTerminal } }
        persistNow()
    }

    /** Drops a single terminal task (a row's "Remove" button). */
    fun remove(task: DownloadTask) {
        synchronized(downloadTasks) { downloadTasks.remove(task) }
        persistNow()
    }

    /**
     * Best-effort stable id for [downloadUrl], used to name the resumable temp
     * file so a retry reuses the same partial bytes instead of starting over.
     * GitHub's artifact download URL embeds the numeric artifact id
     * (".../actions/artifacts/{id}/zip"); anything else falls back to a hash
     * of the full URL so this can never throw.
     */
    fun stableIdFor(downloadUrl: String): String =
        Regex("artifacts/(\\d+)").find(downloadUrl)?.groupValues?.get(1)
            ?: downloadUrl.hashCode().toString()

    /** Registers [task] with the manager (newest first) and starts it running. */
    fun submit(task: DownloadTask) {
        downloadTasks.add(0, task)
        task.workerActive = true
        liveTasksById[task.id] = task
        downloadExecutor.execute { runDownloadTask(task) }
        persistNow()
        activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showManagerDialog() }
    }

    /**
     * Resubmits a FAILED or CANCELLED task from scratch. Safe to call any time
     * after [runDownloadTask] has left it in a terminal state — any bytes already
     * on [DownloadTask.destFile] are untouched, so this resumes rather than
     * restarting, exactly like the automatic retry path does.
     */
    fun retry(task: DownloadTask) {
        if (!task.isTerminal) return
        task.cancelRequested = false
        task.pauseRequested  = false
        task.errorMessage    = null
        task.status = DownloadTask.Status.QUEUED
        task.detailText = "Queued…"
        task.workerActive = true
        liveTasksById[task.id] = task
        downloadExecutor.execute { runDownloadTask(task) }
        persistNow()
        activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showManagerDialog() }
    }

    /**
     * Un-pauses [task]. If a worker is still live and blocked in
     * [DownloadEngine]'s pause-wait (the ordinary in-app case — see
     * [DownloadTask.workerActive]'s kdoc), this is exactly the old
     * behavior: flip the flag and let that thread notice within ~200ms. If
     * there's no live worker (the task was restored from
     * [DownloadPersistence] after a process restart, where by definition no
     * worker thread survived), this submits a fresh one instead — the same
     * resumable-from-disk transfer either way, just started by a new thread.
     */
    fun resume(task: DownloadTask) {
        task.pauseRequested = false
        if (!task.workerActive) {
            task.workerActive = true
            liveTasksById[task.id] = task
            task.status = DownloadTask.Status.QUEUED
            task.detailText = "Queued…"
            downloadExecutor.execute { runDownloadTask(task) }
            persistNow()
        }
    }

    /**
     * Adds tasks reconstructed by [DownloadManager] from
     * [DownloadPersistence.loadSnapshot] after a process restart. Terminal
     * tasks (FAILED/CANCELLED) are simply added so they still show up with
     * Retry/Remove, matching exactly what the user would have seen had the
     * process never died. Anything non-terminal — including a task that was
     * PAUSED — is resubmitted to a fresh worker, since no worker thread
     * survives a process restart to reattach to; a preserved
     * [DownloadTask.pauseRequested] makes that fresh worker pause itself
     * again almost immediately (before any bytes transfer — see
     * [DownloadEngine.performResumableDownload]'s pause check, which runs at
     * the very top of its copy loop), so the net effect is the same PAUSED
     * state the user left it in, not a silent auto-resume of something they
     * deliberately paused.
     *
     * The one exception: a task id already present in [liveTasksById] means
     * some *other*, still-running [DownloadQueue] instance in this process —
     * not a real process restart, but the narrower within-process Activity
     * recreation [generationCounter]'s kdoc describes — is already
     * transferring it. That candidate is replaced with the exact live
     * [DownloadTask] object instead of the freshly-rebuilt one, and no
     * second worker is started for it: the live object is still being
     * mutated in place by its real worker, so this queue's copy of the list
     * shows accurate, continuously-updating progress, and Pause/Cancel
     * (which mutate the task object directly — see [DownloadDialogController])
     * keep working on it exactly as if nothing happened.
     */
    fun restoreTasks(tasks: List<DownloadTask>) {
        if (tasks.isEmpty()) return
        var anyResubmitted = false
        val actualTasks = tasks.map { candidate ->
            liveTasksById[candidate.id] ?: candidate.also { task ->
                if (!task.isTerminal) {
                    task.status = DownloadTask.Status.QUEUED
                    task.detailText = "Queued…"
                    task.workerActive = true
                    liveTasksById[task.id] = task
                    anyResubmitted = true
                    downloadExecutor.execute { runDownloadTask(task) }
                }
            }
        }
        synchronized(downloadTasks) { downloadTasks.addAll(actualTasks) }
        persistNow()
        if (anyResubmitted) {
            activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showManagerDialog() }
        }
    }

    // ── Floating download bubble ────────────────────────────────────────────
    // Replaces the old behavior of force-opening the manager dialog every time
    // a download started. Instead of tracking live progress on the bubble, it
    // just flashes briefly when a download is queued and again (a bit
    // differently — checkmark/warning instead of the plain download icon)
    // once it finishes; the running percentage/speed detail stays exclusively
    // inside the Download Manager dialog, which the bubble opens on tap. See
    // FloatingTransferIndicator's kdoc for the full rationale.

    /**
     * Runs [task] end-to-end on the calling thread: the byte transfer via
     * [DownloadEngine.performResumableDownload] (skipped if [task].destFile
     * already fully matches [task].totalBytes from a prior attempt — see the
     * comment inline below), then — on success — [DownloadTask.onSuccess]
     * (which does the save-to-Downloads/integrity-report work specific to
     * each download kind). Leaves [task].status in a terminal state
     * (COMPLETED / FAILED / CANCELLED) no matter how it ends, so the manager
     * UI never has to guess. Must be called from a [downloadExecutor]
     * thread, never the main one.
     */
    private fun runDownloadTask(task: DownloadTask) {
        try {
            // A previous attempt can fail *after* the transfer itself fully completed —
            // e.g. onSuccess's save-to-Downloads step throwing because a custom SAF
            // folder's permission was revoked (see DownloadHistory.saveZipToDownloadsInternal) —
            // leaving destFile on disk fully intact even though the task ended up FAILED.
            // Retrying that shouldn't re-download bytes already sitting right there; only
            // re-run the step that actually failed. Safe even if this check is ever wrong
            // about "complete" (e.g. a stale totalBytes from a since-changed remote file):
            // onSuccess's very first action is always a full ZIP integrity check, which
            // would catch a mismatched file and fail the task again rather than silently
            // accepting it.
            val alreadyComplete = task.totalBytes > 0 &&
                task.destFile.exists() &&
                task.destFile.length() == task.totalBytes
            if (!alreadyComplete) {
                downloadEngine.performResumableDownload(task)
            }
            task.onSuccess(task)
            task.status = DownloadTask.Status.COMPLETED
            task.detailText = "Done"
            persistNow() // drops it from persisted storage — see saveSnapshot's COMPLETED filter
            activity.floatingTransferIndicator.complete(FloatingTransferIndicator.Mode.DOWNLOAD, showRing = false) {
                showManagerDialog()
            }
        } catch (e: Exception) {
            if (e.message == "Cancelled by user") {
                task.status = DownloadTask.Status.CANCELLED
                task.detailText = "Cancelled"
                activity.appendLog("⚠ Download cancelled: ${task.displayName}")
            } else {
                task.status = DownloadTask.Status.FAILED
                task.errorMessage = Formatters.friendlyError(e)
                task.detailText = "Failed"
                activity.appendLog("✗ Download failed: ${task.displayName} — ${Formatters.friendlyError(e)}")
                activity.floatingTransferIndicator.fail(FloatingTransferIndicator.Mode.DOWNLOAD, showRing = false) {
                    showManagerDialog()
                }
            }
            persistNow()
        } finally {
            task.workerActive = false
            liveTasksById.remove(task.id, task)
        }
    }
}
