package com.hzcm.duelforge.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hzcm.duelforge.model.*

/** Card dimensions used throughout the field. */
val CardWidth  = 48.dp
val CardHeight = 66.dp

/**
 * Drop-in replacement for [CardView] used on every field zone (monster zones,
 * Spell/Trap zones) so a card appearing, disappearing, or being replaced in that zone
 * animates instead of popping in/out instantly - addresses "no animation like putting
 * card on the field." Keyed by [CardInstance.instanceId] so Compose treats a different
 * physical card landing in the same zone as a fresh appear-transition, not a content
 * update. Hand cards intentionally keep using [CardView] directly: they shift around in
 * a [androidx.compose.foundation.lazy.LazyRow] too often (selection, re-sort on redraw)
 * for an appear/disappear fade to read as meaningful there.
 */
@Composable
fun AnimatedCardSlot(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    AnimatedContent(
        targetState = instance,
        modifier = modifier,
        transitionSpec = {
            (fadeIn(tween(260)) + scaleIn(initialScale = 0.55f, animationSpec = tween(260)))
                .togetherWith(fadeOut(tween(140)) + scaleOut(targetScale = 0.7f, animationSpec = tween(140)))
        },
        contentKey = { it?.instanceId }
    ) { inst ->
        CardView(
            instance = inst,
            revealFaceDown = revealFaceDown,
            selected = selected,
            onClick = onClick
        )
    }
}

/**
 * Renders one card zone.
 *
 *  - null instance                  → empty zone placeholder
 *  - face-down card (any type)      → card back image (assets/card_back.webp)
 *    - own face-down gets a subtle blue border so owner can identify it's theirs
 *  - defense position monster       → rotated 90°, slot widened to CardHeight to prevent overflow
 *  - face-up with artwork           → artwork fills the card
 *  - face-up without artwork        → colored placeholder with name/stats text
 *
 * [revealFaceDown] marks this as the owner's own card; the card back is still shown
 * but with a distinct border color so the player knows it belongs to them.
 */
@Composable
fun CardView(
    instance: CardInstance?,
    modifier: Modifier = Modifier,
    revealFaceDown: Boolean = false,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val isDefense = instance != null &&
        instance.card.isMonster &&
        instance.battlePosition == BattlePosition.DEFENSE

    // Defense cards rotate 90° — their displayed width becomes CardHeight.
    // Allocate a CardHeight-wide square slot so they don't overflow into neighbors.
    val slotWidth = if (isDefense) CardHeight else CardWidth

    val outerMod = modifier
        .size(slotWidth, CardHeight)
        .let { m -> if (onClick != null) m.clickable { onClick() } else m }

    if (instance == null) {
        Box(
            modifier = outerMod
                .background(Color(0xFF111111), RoundedCornerShape(6.dp))
                .border(1.dp, Color(0xFF2A2A2A), RoundedCornerShape(6.dp))
        ) {}
        return
    }

    // Always show face for face-up cards; face-down always shows card back
    val showFace = instance.faceUp
    val rotation = if (isDefense) 90f else 0f

    Box(modifier = outerMod, contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(CardWidth, CardHeight)
                .graphicsLayer { rotationZ = rotation }
                .clip(RoundedCornerShape(6.dp))
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = when {
                        selected                        -> Color(0xFFFFD54F) // gold for selected
                        !showFace && revealFaceDown     -> Color(0xFF6699CC) // blue tint = your own face-down
                        isDefense && showFace           -> Color(0xFF4488FF) // blue = defense
                        else                            -> Color(0xFF444444)
                    },
                    shape = RoundedCornerShape(6.dp)
                )
        ) {
            if (!showFace) {
                // Always show card back for face-down cards
                CardBack()
            } else {
                val context = LocalContext.current
                val bitmap  = remember(instance.card.imageId) {
                    ImageLoader.loadCardImage(context, instance.card.imageId)
                }

                if (bitmap != null) {
                    Image(
                        bitmap             = bitmap.asImageBitmap(),
                        contentDescription = instance.card.name,
                        modifier           = Modifier.fillMaxSize(),
                        contentScale       = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(cardTypeColor(instance.card))
                    ) {
                        PlaceholderCardContent(instance)
                    }
                }
            }
        }

        // Small "DEF" badge below rotated defense cards
        if (isDefense) {
            Text(
                "DEF",
                color      = Color(0xFF88BBFF),
                fontSize   = 5.sp,
                fontWeight = FontWeight.Bold,
                modifier   = Modifier.align(Alignment.BottomCenter).offset(y = 2.dp)
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card back
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun CardBack(modifier: Modifier = Modifier) {
    val context    = LocalContext.current
    val backBitmap = remember { ImageLoader.loadCardBack(context) }
    Box(
        modifier           = modifier.fillMaxSize().background(Color(0xFF2B2D6E)),
        contentAlignment   = Alignment.Center
    ) {
        if (backBitmap != null) {
            Image(
                bitmap             = backBitmap.asImageBitmap(),
                contentDescription = "Card back",
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .size(CardWidth - 14.dp, CardHeight - 14.dp)
                    .border(1.dp, Color(0xFF6E72C7), RoundedCornerShape(4.dp))
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Text placeholder (shown only when no artwork file exists)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlaceholderCardContent(instance: CardInstance) {
    val card = instance.card
    Column(
        modifier            = Modifier.fillMaxSize().padding(4.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text       = card.name,
            color      = Color.Black,
            fontSize   = 8.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 9.sp,
            maxLines   = 3,
            overflow   = TextOverflow.Ellipsis
        )
        Column {
            if (card.isMonster) {
                Text(
                    text     = "${card.attribute?.name ?: ""} ${card.race?.name?.replace('_', ' ') ?: ""}".trim(),
                    color    = Color(0xFF222222),
                    fontSize = 6.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text       = "Lv${card.level ?: 0}  ${card.atk ?: 0}/${card.def ?: 0}",
                    color      = Color.Black,
                    fontSize   = 7.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines   = 1
                )
            } else {
                Text(
                    text       = if (card.isSpell) "SPELL" else "TRAP",
                    color      = Color.Black,
                    fontSize   = 7.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card type background colours (for placeholder view and preview overlay)
// ─────────────────────────────────────────────────────────────────────────────

fun cardTypeColor(card: Card): Color = when (card.cardType) {
    CardType.MONSTER -> when (card.monsterCategory) {
        MonsterCategory.NORMAL -> Color(0xFFE8C77A)
        MonsterCategory.EFFECT -> Color(0xFFE8915A)
        MonsterCategory.FUSION -> Color(0xFFC79BE8)
        null                   -> Color(0xFFE8C77A)
    }
    CardType.SPELL -> Color(0xFF7FBF7F)
    CardType.TRAP  -> Color(0xFFE07FA8)
}
