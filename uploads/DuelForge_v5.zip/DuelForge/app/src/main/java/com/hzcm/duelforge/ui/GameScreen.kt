package com.hzcm.duelforge.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hzcm.duelforge.data.EffectRegistry
import com.hzcm.duelforge.engine.*
import com.hzcm.duelforge.model.*
import kotlinx.coroutines.delay

private val BgColor    = Color(0xFF0D1B2A)
private val PanelColor = Color(0xFF1B263B)
private val LogColor   = Color(0xFF14213D)

@Composable
fun GameScreen(
    viewModel: GameViewModel = viewModel(),
    onOpenDebug: () -> Unit = {}
) {
    val engine = viewModel.engine
    @Suppress("UNUSED_EXPRESSION")
    viewModel.refresh
    val state = engine.state

    Box(modifier = Modifier.fillMaxSize().background(BgColor)) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 4.dp)
        ) {
            Column(
                modifier = Modifier.weight(1.7f).fillMaxHeight()
            ) {
                // Everything except the hand scrolls independently, so the hand below
                // stays pinned and reachable without scrolling no matter how tall the
                // field area gets.
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.Top
                ) {
                    OpponentPanel(engine, viewModel)
                    Spacer(modifier = Modifier.height(3.dp))
                    PhaseBar(viewModel, onOpenDebug)
                    Spacer(modifier = Modifier.height(3.dp))
                    PlayerFieldPanel(engine, viewModel)
                }
                Spacer(modifier = Modifier.height(3.dp))
                PlayerHandRow(engine, viewModel)
            }

            Spacer(modifier = Modifier.width(4.dp))

            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                LogPanel(state, modifier = Modifier.weight(1f).fillMaxWidth())
                Spacer(modifier = Modifier.height(4.dp))
                ActionPanel(viewModel, modifier = Modifier.fillMaxWidth())
            }
        }

        // ── Overlays (drawn on top of everything) ──────────────────────
        state.pendingHumanPriority?.let { prompt -> PriorityDialog(prompt, viewModel) }
        state.pendingDiscard?.let { req -> DiscardDialog(req, viewModel) }
        state.pendingCoinCall?.let { req -> CoinCallDialog(req, viewModel) }
        if (state.phase == Phase.BATTLE && state.turnPlayer == PlayerId.PLAYER)
            BattlePhaseBanner()
        if (state.gameOver) GameOverOverlay(state, viewModel)

        // Attack flash
        if (viewModel.attackFlash) {
            AttackFlashOverlay(onDone = { viewModel.attackFlash = false })
        }

        // Coin flip reveal (Abare Ushioni and similar "call it" effects)
        viewModel.coinFlipReveal?.let { reveal ->
            CoinFlipOverlay(reveal, onDone = { viewModel.dismissCoinFlipReveal() })
        }

        // Card preview overlay
        val previewCard = viewModel.previewCard
        var cachedPreviewCard by remember { mutableStateOf(previewCard) }
        if (previewCard != null) cachedPreviewCard = previewCard
        AnimatedVisibility(
            visible = previewCard != null,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.85f, animationSpec = tween(180)),
            exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.9f, animationSpec = tween(150))
        ) {
            // Read the cached value, not the (possibly already-null) live state, so the
            // exit transition fades out the actual card instead of an empty box.
            cachedPreviewCard?.let { card ->
                CardPreviewOverlay(
                    card = card,
                    autoDismiss = viewModel.previewAutoShow,
                    onDismiss = { viewModel.dismissPreview() }
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Opponent panel
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun OpponentPanel(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.AI)
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Deck visual — small card back stack
                DeckPile(deckSize = field.deck.size)
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        "Opponent LP: ${field.lifePoints}",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp
                    )
                    Text(
                        "Deck:${field.deck.size}  GY:${field.graveyard.size}" +
                        "  Banished:${field.banished.size}  Extra:${field.extraDeck.size}",
                        color = Color(0xFFAAAAAA), fontSize = 9.sp
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Row {
            Spacer(modifier = Modifier.width(CardWidth + 4.dp))
            for (i in 0..4) {
                AnimatedCardSlot(instance = field.spellTrapZones[i], modifier = Modifier.padding(horizontal = 1.dp))
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedCardSlot(field.fieldZone)
            Spacer(modifier = Modifier.width(4.dp))
            for (i in 0..4) {
                val cardInst = field.monsterZones[i]
                AnimatedCardSlot(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 1.dp),
                    selected = vm.attackerSelection != null && cardInst != null,
                    onClick = cardInst?.let { c -> { vm.onOpponentMonsterTapped(c) } }
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Player panel - split so the hand (PlayerHandRow) can be pinned outside the
// scrollable field area and stay reachable without scrolling.
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PlayerFieldPanel(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.PLAYER)
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AnimatedCardSlot(field.fieldZone)
            Spacer(modifier = Modifier.width(4.dp))
            for (i in 0..4) {
                val cardInst = field.monsterZones[i]
                AnimatedCardSlot(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 1.dp),
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = cardInst?.let { c -> { vm.onOwnMonsterTapped(c) } }
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Row {
            Spacer(modifier = Modifier.width(CardWidth + 4.dp))
            for (i in 0..4) {
                val cardInst = field.spellTrapZones[i]
                AnimatedCardSlot(
                    instance = cardInst,
                    modifier = Modifier.padding(horizontal = 1.dp),
                    revealFaceDown = true,
                    selected = isSelected(cardInst, vm),
                    onClick = cardInst?.let { c -> { vm.onOwnSpellTrapTapped(c) } }
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                DeckPile(deckSize = field.deck.size)
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        "Your LP: ${field.lifePoints}",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp
                    )
                    Text(
                        "Deck:${field.deck.size}  GY:${field.graveyard.size}" +
                        "  Banished:${field.banished.size}  Extra:${field.extraDeck.size}",
                        color = Color(0xFFAAAAAA), fontSize = 9.sp
                    )
                }
            }
        }
    }
}

/** The human player's hand - kept in its own composable, pinned outside the scrollable
 *  field area in [GameScreen], so it never requires scrolling to reach. */
@Composable
private fun PlayerHandRow(engine: GameEngine, vm: GameViewModel) {
    val field = engine.state.field(PlayerId.PLAYER)
    LazyRow {
        items(field.hand) { cardInst ->
            CardView(
                instance = cardInst,
                modifier = Modifier.padding(horizontal = 2.dp),
                revealFaceDown = true,
                selected = isSelected(cardInst, vm),
                onClick = { vm.onHandCardTapped(cardInst) }
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Deck pile visual — small card back with count badge
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun DeckPile(deckSize: Int) {
    if (deckSize == 0) return
    Box(
        modifier = Modifier.size(22.dp, 30.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        CardBack(modifier = Modifier.fillMaxSize())
        Box(
            modifier = Modifier
                .size(13.dp)
                .background(Color(0xCC000000), RoundedCornerShape(3.dp))
                .padding(1.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = deckSize.toString(),
                color = Color.White,
                fontSize = 6.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun isSelected(card: CardInstance?, vm: GameViewModel): Boolean {
    if (card == null) return false
    if (vm.selectedCard === card) return true
    if (vm.attackerSelection === card) return true
    if (vm.tributeSelection?.chosen?.contains(card) == true) return true
    if (vm.discardChosen.contains(card)) return true
    return false
}

// ─────────────────────────────────────────────────────────────────────────────
// Phase bar  —  Main Phase 1 gets three targeted shortcuts
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PhaseBar(vm: GameViewModel, onOpenDebug: () -> Unit = {}) {
    val state = vm.engine.state
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val turnLabel = if (state.turnPlayer == PlayerId.PLAYER) "Your Turn" else "Opp's Turn"
        Text(
            "T${state.turnCount} · $turnLabel · ${phaseDisplayName(state.phase)}",
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 10.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = onOpenDebug,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                modifier = Modifier.height(28.dp)
            ) { Text("🔧", fontSize = 9.sp) }
            Spacer(modifier = Modifier.width(3.dp))

            val canAdvance = state.turnPlayer == PlayerId.PLAYER && !state.gameOver &&
                state.chain.isEmpty() && state.pendingHumanPriority == null

            if (state.phase == Phase.MAIN1 && canAdvance) {
                // Three-button shortcut row
                PhaseBtn("⚔ Battle")  { vm.goToBattlePhase() }
                Spacer(modifier = Modifier.width(2.dp))
                PhaseBtn("→ MP2")     { vm.skipToMainPhase2() }
                Spacer(modifier = Modifier.width(2.dp))
                PhaseBtn("⏭ End")    { vm.skipToEndPhase() }
            } else {
                Button(
                    onClick = { vm.advancePhase() },
                    enabled = canAdvance,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text(
                        when (state.phase) {
                            Phase.DRAW -> "Draw Card ✦"
                            Phase.END  -> "End Turn"
                            else       -> "Next Phase"
                        },
                        fontSize = 9.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PhaseBtn(label: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp),
        modifier = Modifier.height(28.dp)
    ) { Text(label, fontSize = 8.sp) }
}

private fun phaseDisplayName(phase: Phase): String = when (phase) {
    Phase.DRAW         -> "Draw"
    Phase.STANDBY      -> "Standby"
    Phase.MAIN1        -> "Main 1"
    Phase.BATTLE_START -> "Battle"
    Phase.BATTLE       -> "Battle"
    Phase.MAIN2        -> "Main 2"
    Phase.END          -> "End"
}

// ─────────────────────────────────────────────────────────────────────────────
// Log panel
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun LogPanel(state: GameState, modifier: Modifier = Modifier) {
    val listState = rememberLazyListState()
    LaunchedEffect(state.log.size) {
        if (state.log.isNotEmpty()) listState.animateScrollToItem(state.log.size - 1)
    }
    LazyColumn(
        state = listState,
        modifier = modifier.background(LogColor).padding(4.dp)
    ) {
        items(state.log) { line ->
            Text(line, color = Color(0xFFCCCCCC), fontSize = 9.sp, lineHeight = 11.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Action panel
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun ActionPanel(vm: GameViewModel, modifier: Modifier = Modifier) {
    val engine = vm.engine
    Column(
        modifier = modifier
            .background(PanelColor)
            .padding(4.dp)
            .heightIn(max = 200.dp)
            .verticalScroll(rememberScrollState())
    ) {
        val tribute  = vm.tributeSelection
        val attacker = vm.attackerSelection
        val card     = vm.selectedCard

        when {
            tribute  != null -> TributePanel(vm, tribute)
            attacker != null -> AttackerPanel(vm, engine, attacker)
            card     != null -> CardActionPanel(vm, engine, card)
            else -> Text("Tap a card to act.", color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun TributePanel(vm: GameViewModel, tribute: TributeSelection) {
    val action = if (tribute.asSet) "Set" else "Normal Summon"
    Text(
        "$action ${tribute.card.card.name}: choose ${tribute.required} tribute(s) " +
        "(${tribute.chosen.size}/${tribute.required})",
        color = Color.White, fontSize = 10.sp
    )
    Spacer(modifier = Modifier.height(4.dp))
    Row {
        Button(
            onClick = { vm.confirmTributeSummon() },
            enabled = tribute.chosen.size == tribute.required
        ) { Text("Confirm", fontSize = 10.sp) }
        Spacer(modifier = Modifier.width(4.dp))
        Button(onClick = { vm.cancelTributeSummon() }) { Text("Cancel", fontSize = 10.sp) }
    }
}

@Composable
private fun AttackerPanel(vm: GameViewModel, engine: GameEngine, attacker: CardInstance) {
    Text("${attacker.card.name} attacking.", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    Spacer(modifier = Modifier.height(4.dp))
    if (engine.canDeclareAttack(attacker, null)) {
        Text("No opp monsters — attack directly?", color = Color.LightGray, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = { vm.declareDirectAttack() }) { Text("⚔ Attack Directly", fontSize = 10.sp) }
    } else {
        Text("Tap an opponent's monster.", color = Color.LightGray, fontSize = 10.sp)
    }
}

@Composable
private fun CardActionPanel(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    Text(card.card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    Text(card.card.description, color = Color.LightGray, fontSize = 9.sp, lineHeight = 11.sp)
    if (card.card.isMonster) {
        Text(
            "Lv${card.card.level ?: 0}  ${card.card.attribute?.name ?: ""} " +
            "${card.card.race?.name?.replace('_', ' ') ?: ""}  " +
            "ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}",
            color = Color(0xFFAAAAAA), fontSize = 8.sp
        )
    }

    // Always show a "View Card" button for full-art preview (face-up only)
    if (card.faceUp) {
        Spacer(modifier = Modifier.height(2.dp))
        Button(
            onClick = { vm.showFieldPreview(card) },
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
        ) { Text("🔍 View Card", fontSize = 9.sp) }
    }

    Spacer(modifier = Modifier.height(4.dp))

    when (card.location) {
        Location.HAND         -> HandCardActions(vm, engine, card)
        Location.MONSTER_ZONE -> FieldMonsterActions(vm, engine, card)
        Location.SPELL_TRAP_ZONE -> SpellTrapZoneActions(vm, engine, card)
        else -> Text("No actions available.", color = Color.Gray, fontSize = 9.sp)
    }
}

@Composable
private fun HandCardActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    if (card.card.isMonster) {
        if (engine.canNormalSummon(card)) {
            val tribNote = if (card.card.tributesRequired > 0) " (${card.card.tributesRequired} trib)" else ""
            ActionButton("Normal Summon$tribNote") { vm.beginSummon(false) }
            if (engine.canSetMonster(card)) {
                ActionButton("Set (face-down)$tribNote") { vm.beginSummon(true) }
            }
        }
    }
    // Allow setting Spell (Normal/Quick-Play) and Trap cards face-down
    if ((card.card.isSpell || card.card.isTrap) && engine.canSetSpellOrTrap(card)) {
        ActionButton("Set face-down") { vm.setTrap() }
    }
    for (effect in EffectRegistry.effectsFor(card.card.id)) {
        if (engine.canActivateEffect(card, effect)) {
            ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
        }
    }
}

@Composable
private fun FieldMonsterActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    if (engine.canFlipSummon(card)) {
        ActionButton("Flip Summon") { vm.flipSummon() }
    }
    val opposite = if (card.battlePosition == BattlePosition.ATTACK) BattlePosition.DEFENSE else BattlePosition.ATTACK
    if (engine.canChangeBattlePosition(card, opposite)) {
        val label = if (opposite == BattlePosition.ATTACK) "→ Attack Pos" else "→ Defense Pos"
        ActionButton(label) { vm.changeBattlePosition(opposite) }
    }
    for (effect in EffectRegistry.effectsFor(card.card.id)) {
        if (engine.canActivateEffect(card, effect)) {
            ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
        }
    }
}

@Composable
private fun SpellTrapZoneActions(vm: GameViewModel, engine: GameEngine, card: CardInstance) {
    // Set Spell: can activate from zone on your turn
    for (effect in EffectRegistry.effectsFor(card.card.id)) {
        if (engine.canActivateEffect(card, effect)) {
            ActionButton("Activate: ${effect.description}") { vm.activateEffect(effect) }
        }
    }
    if (!card.faceUp) {
        val hint = when {
            card.card.isTrap  -> "Set Trap — activates during opponent's turn."
            card.card.isSpell -> "Set Spell — tap Activate on your turn."
            else -> ""
        }
        if (hint.isNotEmpty()) {
            Text(hint, color = Color(0xFF888888), fontSize = 9.sp)
        }
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.padding(vertical = 2.dp)) {
        Text(label, fontSize = 10.sp)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Priority dialog
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun PriorityDialog(prompt: PriorityPrompt, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Respond?") },
        text = {
            Column {
                Text(prompt.reason, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(8.dp))
                prompt.optionLabels.forEachIndexed { index, label ->
                    Button(
                        onClick = { vm.submitPriorityChoice(index) },
                        modifier = Modifier.padding(vertical = 2.dp).fillMaxWidth()
                    ) { Text(label, fontSize = 10.sp) }
                }
            }
        },
        confirmButton = {
            Button(onClick = { vm.submitPriorityChoice(null) }) { Text("Pass") }
        }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Discard dialog
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun DiscardDialog(req: DiscardRequest, vm: GameViewModel) {
    val hand = vm.engine.state.field(req.player).hand
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Discard ${req.count} card${if (req.count > 1) "s" else ""}") },
        text = {
            Column {
                Text(req.reason, fontSize = 10.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Tap to select (${vm.discardChosen.size}/${req.count}):", fontSize = 9.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow {
                    items(hand) { card ->
                        CardView(
                            instance = card,
                            revealFaceDown = true,
                            selected = vm.discardChosen.contains(card),
                            modifier = Modifier.padding(horizontal = 3.dp),
                            onClick = { vm.onDiscardCardToggled(card) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { vm.confirmDiscard() },
                enabled = vm.discardChosen.size == req.count
            ) { Text("Discard") }
        }
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Coin call dialog — "Call it: Heads or Tails?" (Abare Ushioni and similar effects)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CoinCallDialog(req: CoinCallRequest, vm: GameViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Call it!") },
        text = {
            Column {
                Text(req.reason, fontSize = 11.sp, color = Color.LightGray)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { vm.callCoinToss(CoinSide.HEADS) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Heads") }
                    Button(
                        onClick = { vm.callCoinToss(CoinSide.TAILS) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Tails") }
                }
            }
        },
        confirmButton = {}
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Coin flip reveal overlay — animated flip landing on the already-resolved result
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CoinFlipOverlay(reveal: CoinFlipReveal, onDone: () -> Unit) {
    var displayedSide by remember(reveal) { mutableStateOf(reveal.called) }
    var settled by remember(reveal) { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (settled) 1.18f else 1f,
        animationSpec = tween(220),
        label = "coinScale"
    )

    LaunchedEffect(reveal) {
        // Quick flicker between faces to suggest a spinning coin, then settle on the
        // true (already-resolved) result.
        repeat(12) {
            displayedSide = if (displayedSide == CoinSide.HEADS) CoinSide.TAILS else CoinSide.HEADS
            delay(70L)
        }
        displayedSide = reveal.landed
        settled = true
        delay(1500L)
        onDone()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .scale(scale)
                    .background(
                        Brush.radialGradient(listOf(Color(0xFFFFE9A8), Color(0xFFC9971F))),
                        CircleShape
                    )
                    .border(4.dp, Color(0xFF8A6418), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (displayedSide == CoinSide.HEADS) "H" else "T",
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF4A3300)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                if (!settled) "Flipping..." else "${reveal.landed.displayName}!",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp
            )
            if (settled) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Called ${reveal.called.displayName} — " + if (reveal.won) "right!" else "wrong!",
                    color = if (reveal.won) Color(0xFF66E28A) else Color(0xFFFF6B6B),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Battle phase banner
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun BattlePhaseBanner() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .background(Color(0xCC8B0000), RoundedCornerShape(8.dp))
                .padding(horizontal = 24.dp, vertical = 8.dp)
        ) {
            Text(
                "⚔ BATTLE PHASE — Tap your monsters to attack!",
                color = Color(0xFFFF6666), fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Attack flash overlay — bright red burst when an attack is declared
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun AttackFlashOverlay(onDone: () -> Unit) {
    var visible by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(250L)
        visible = false
        delay(500L)
        onDone()
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(80)),
        exit  = fadeOut(tween(450))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x44FF1100)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xCC000000), RoundedCornerShape(10.dp))
                    .padding(horizontal = 28.dp, vertical = 10.dp)
            ) {
                Text(
                    "⚔  ATTACK!",
                    color = Color(0xFFFF4444),
                    fontWeight = FontWeight.Bold,
                    fontSize = 30.sp
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card preview overlay — full-art modal, tap anywhere to dismiss
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun CardPreviewOverlay(
    card: CardInstance,
    autoDismiss: Boolean,
    onDismiss: () -> Unit
) {
    if (autoDismiss) {
        LaunchedEffect(card) {
            delay(2200L)
            onDismiss()
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(modifier = Modifier.size(170.dp, 245.dp)) {
                val context = LocalContext.current
                val bitmap  = remember(card.card.imageId) {
                    ImageLoader.loadCardImage(context, card.card.imageId)
                }
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = card.card.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    // Fallback placeholder
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(cardTypeColor(card.card), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(card.card.name, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(card.card.description, color = Color.DarkGray, fontSize = 11.sp, lineHeight = 13.sp)
                            if (card.card.isMonster) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "ATK ${card.card.atk ?: 0} / DEF ${card.card.def ?: 0}",
                                    color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                if (autoDismiss) "Tap to dismiss (auto-closes shortly)" else "Tap to dismiss",
                color = Color(0xFFBBBBBB), fontSize = 10.sp
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Game over overlay
// ─────────────────────────────────────────────────────────────────────────────

@Composable
private fun GameOverOverlay(state: GameState, vm: GameViewModel) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val winnerText = when (state.winner) {
                PlayerId.PLAYER -> "You Win! 🎉"
                PlayerId.AI     -> "Opponent Wins!"
                null            -> "Duel Over"
            }
            Text(winnerText, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { vm.restart() }) { Text("New Duel") }
        }
    }
}
