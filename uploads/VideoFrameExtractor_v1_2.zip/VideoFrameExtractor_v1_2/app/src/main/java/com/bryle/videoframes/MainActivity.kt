package com.bryle.videoframes

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    // ─── State ────────────────────────────────────────────────────────────────

    private var selectedUri: Uri? = null
    private var videoDurationMs: Long = 0L
    private var outputTreeUri: Uri? = null
    private var extractionJob: Job? = null
    private var previewJob: Job? = null

    // Rebuild state
    private var selectedZipUri: Uri? = null
    private var rebuildJob: Job? = null

    // ─── Extract views ────────────────────────────────────────────────────────

    private lateinit var btnSelect: Button
    private lateinit var tvName: TextView
    private lateinit var tvInfo: TextView
    private lateinit var etFps: EditText
    private lateinit var tvFpsHint: TextView
    private lateinit var tvEstimate: TextView
    private lateinit var btnExtract: Button
    private lateinit var btnCancel: Button
    private lateinit var cardProgress: View
    private lateinit var progressBar: ProgressBar
    private lateinit var tvProgress: TextView
    private lateinit var tvEta: TextView
    private lateinit var tvStatus: TextView
    private lateinit var cardOutput: View
    private lateinit var tvOutputPath: TextView
    private lateinit var btnCopyPath: Button
    private lateinit var btnChooseFolder: Button
    private lateinit var tvFolderPath: TextView
    private lateinit var btnClearFolder: Button
    private lateinit var etStartTime: EditText
    private lateinit var etEndTime: EditText
    private lateinit var btnPreview: Button
    private lateinit var tvRangeInfo: TextView
    private lateinit var cardPreview: View
    private lateinit var ivPreview: ImageView
    private lateinit var tvPreviewLabel: TextView

    // ─── Rebuild views ────────────────────────────────────────────────────────

    private lateinit var btnSelectZip: Button
    private lateinit var tvZipName: TextView
    private lateinit var etRebuildFps: EditText
    private lateinit var btnRebuild: Button
    private lateinit var btnRebuildCancel: Button
    private lateinit var cardRebuildProgress: View
    private lateinit var progressRebuild: ProgressBar
    private lateinit var tvRebuildProgress: TextView
    private lateinit var tvRebuildStatus: TextView
    private lateinit var cardRebuildOutput: View
    private lateinit var tvRebuildOutputPath: TextView
    private lateinit var btnCopyRebuildPath: Button

    // ─── Launchers ────────────────────────────────────────────────────────────

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedUri = uri
        loadVideoInfo(uri)
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri,
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        outputTreeUri = uri
        val doc = DocumentFile.fromTreeUri(this, uri)
        tvFolderPath.text = doc?.name ?: uri.lastPathSegment ?: "Custom folder"
        btnClearFolder.visibility = View.VISIBLE
    }

    private val pickZip = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        selectedZipUri = uri
        tvZipName.text = getDisplayName(uri)
        tvRebuildStatus.text = "ZIP loaded. Set FPS and tap Rebuild Video."
        cardRebuildOutput.visibility = View.GONE
    }

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Extract views
        btnSelect       = findViewById(R.id.btnSelect)
        tvName          = findViewById(R.id.tvName)
        tvInfo          = findViewById(R.id.tvInfo)
        etFps           = findViewById(R.id.etFps)
        tvFpsHint       = findViewById(R.id.tvFpsHint)
        tvEstimate      = findViewById(R.id.tvEstimate)
        btnExtract      = findViewById(R.id.btnExtract)
        btnCancel       = findViewById(R.id.btnCancel)
        cardProgress    = findViewById(R.id.cardProgress)
        progressBar     = findViewById(R.id.progressBar)
        tvProgress      = findViewById(R.id.tvProgress)
        tvEta           = findViewById(R.id.tvEta)
        tvStatus        = findViewById(R.id.tvStatus)
        cardOutput      = findViewById(R.id.cardOutput)
        tvOutputPath    = findViewById(R.id.tvOutputPath)
        btnCopyPath     = findViewById(R.id.btnCopyPath)
        btnChooseFolder = findViewById(R.id.btnChooseFolder)
        tvFolderPath    = findViewById(R.id.tvFolderPath)
        btnClearFolder  = findViewById(R.id.btnClearFolder)
        etStartTime     = findViewById(R.id.etStartTime)
        etEndTime       = findViewById(R.id.etEndTime)
        btnPreview      = findViewById(R.id.btnPreview)
        tvRangeInfo     = findViewById(R.id.tvRangeInfo)
        cardPreview     = findViewById(R.id.cardPreview)
        ivPreview       = findViewById(R.id.ivPreview)
        tvPreviewLabel  = findViewById(R.id.tvPreviewLabel)

        // Rebuild views
        btnSelectZip        = findViewById(R.id.btnSelectZip)
        tvZipName           = findViewById(R.id.tvZipName)
        etRebuildFps        = findViewById(R.id.etRebuildFps)
        btnRebuild          = findViewById(R.id.btnRebuild)
        btnRebuildCancel    = findViewById(R.id.btnRebuildCancel)
        cardRebuildProgress = findViewById(R.id.cardRebuildProgress)
        progressRebuild     = findViewById(R.id.progressRebuild)
        tvRebuildProgress   = findViewById(R.id.tvRebuildProgress)
        tvRebuildStatus     = findViewById(R.id.tvRebuildStatus)
        cardRebuildOutput   = findViewById(R.id.cardRebuildOutput)
        tvRebuildOutputPath = findViewById(R.id.tvRebuildOutputPath)
        btnCopyRebuildPath  = findViewById(R.id.btnCopyRebuildPath)

        // Extract listeners
        btnSelect.setOnClickListener { pickVideo.launch("video/*") }
        btnExtract.setOnClickListener { startExtraction() }
        btnCancel.setOnClickListener { cancelExtraction() }
        btnChooseFolder.setOnClickListener { pickFolder.launch(null) }
        btnClearFolder.setOnClickListener {
            outputTreeUri = null
            tvFolderPath.text = "Default (App storage)"
            btnClearFolder.visibility = View.GONE
        }
        btnPreview.setOnClickListener { loadPreview() }
        btnCopyPath.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("output_path", tvOutputPath.text))
            Toast.makeText(this, "Path copied", Toast.LENGTH_SHORT).show()
        }

        // Rebuild listeners
        btnSelectZip.setOnClickListener { pickZip.launch("application/zip") }
        btnRebuild.setOnClickListener { startRebuild() }
        btnRebuildCancel.setOnClickListener { cancelRebuild() }
        btnCopyRebuildPath.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("rebuild_output_path", tvRebuildOutputPath.text))
            Toast.makeText(this, "Path copied", Toast.LENGTH_SHORT).show()
        }

        val rangeWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { updateEstimate() }
        }
        etFps.addTextChangedListener(rangeWatcher)
        etStartTime.addTextChangedListener(rangeWatcher)
        etEndTime.addTextChangedListener(rangeWatcher)
    }

    // ─── Video loading ────────────────────────────────────────────────────────

    private fun loadVideoInfo(uri: Uri) {
        tvName.text = getDisplayName(uri)
        tvInfo.text = "Reading…"
        cardPreview.visibility = View.GONE

        lifecycleScope.launch(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this@MainActivity, uri)

                val durMs  = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val width  = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)  ?: "?"
                val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
                val rot    = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                val frameCount = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull()
                else null

                val durSec    = durMs / 1000f
                val nativeFps = if (frameCount != null && durSec > 0f) frameCount.toFloat() / durSec else null

                val infoText = buildString {
                    append("${width}×${height}")
                    if (rot != null && rot != "0") append(" · ${rot}° rotation")
                    append(" · ${formatDuration(durMs)}")
                    if (nativeFps != null) append(" · ${"%.2f".format(nativeFps)} fps")
                    if (frameCount != null) append(" · $frameCount frames total")
                }

                withContext(Dispatchers.Main) {
                    videoDurationMs = durMs
                    tvInfo.text = infoText
                    if (nativeFps != null) {
                        etFps.setText("%.2f".format(nativeFps))
                        tvFpsHint.text = "Native fps detected — all frames will be extracted"
                    } else {
                        tvFpsHint.text = "Enter native fps to extract every frame"
                    }
                    etStartTime.setText("0:00.000")
                    etEndTime.setText(formatTimeMs(durMs))
                    updateEstimate()
                    tvStatus.text = "Ready to extract."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    tvInfo.text = "Could not read video info"
                    tvStatus.text = "Error reading video: ${e.message}"
                }
            } finally {
                retriever.release()
            }
        }
    }

    private fun updateEstimate() {
        val fps = etFps.text.toString().toFloatOrNull()
        if (fps == null || fps <= 0f || videoDurationMs <= 0L) {
            tvEstimate.text = "—"
            tvRangeInfo.text = ""
            return
        }
        val startMs = parseTimeMs(etStartTime.text.toString()) ?: 0L
        val endMs   = parseTimeMs(etEndTime.text.toString()) ?: videoDurationMs
        val rangeMs = (endMs - startMs).coerceAtLeast(0L)
        if (rangeMs == 0L) {
            tvEstimate.text = "0 frames"
            tvRangeInfo.text = "Range is empty"
            return
        }
        val est = ((rangeMs / 1000f) * fps).toInt().coerceAtLeast(1)
        tvEstimate.text = "$est frames"
        tvRangeInfo.text = "Range: ${formatTimeMs(startMs)} → ${formatTimeMs(endMs)} (${formatDuration(rangeMs)})"
    }

    // ─── Preview ──────────────────────────────────────────────────────────────

    private fun loadPreview() {
        val uri = selectedUri ?: run {
            Toast.makeText(this, "Select a video first", Toast.LENGTH_SHORT).show()
            return
        }
        val atMs = parseTimeMs(etStartTime.text.toString()) ?: 0L
        btnPreview.isEnabled = false
        btnPreview.text = "Loading…"

        previewJob?.cancel()
        previewJob = lifecycleScope.launch(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this@MainActivity, uri)
                val bmp: Bitmap? = retriever.getFrameAtTime(
                    atMs * 1000L,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                )
                withContext(Dispatchers.Main) {
                    btnPreview.isEnabled = true
                    btnPreview.text = "Preview"
                    if (bmp != null) {
                        ivPreview.setImageBitmap(bmp)
                        cardPreview.visibility = View.VISIBLE
                        tvPreviewLabel.text = "Frame at ${formatTimeMs(atMs)}"
                    } else {
                        Toast.makeText(this@MainActivity, "No frame at ${formatTimeMs(atMs)}", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    btnPreview.isEnabled = true
                    btnPreview.text = "Preview"
                    Toast.makeText(this@MainActivity, "Preview error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                retriever.release()
            }
        }
    }

    // ─── Frame Extraction ─────────────────────────────────────────────────────

    private fun startExtraction() {
        val uri = selectedUri ?: run {
            Toast.makeText(this, "Select a video first", Toast.LENGTH_SHORT).show()
            return
        }
        val fps = etFps.text.toString().toFloatOrNull()?.coerceIn(0.1f, 240f) ?: run {
            Toast.makeText(this, "Enter a valid FPS value", Toast.LENGTH_SHORT).show()
            return
        }
        val startMs = parseTimeMs(etStartTime.text.toString()) ?: 0L
        val endMs   = parseTimeMs(etEndTime.text.toString()) ?: videoDurationMs
        if (startMs >= endMs) {
            Toast.makeText(this, "Start time must be before end time", Toast.LENGTH_SHORT).show()
            return
        }

        setUiExtracting(true)
        cardProgress.visibility = View.VISIBLE
        cardOutput.visibility   = View.GONE
        progressBar.progress    = 0
        tvProgress.text         = "0 / ?"
        tvEta.text              = ""
        tvStatus.text           = "Extracting at ${"%.2f".format(fps)} fps…"

        extractionJob = lifecycleScope.launch(Dispatchers.IO) {
            doExtract(uri, fps, startMs, endMs)
        }
    }

    private fun cancelExtraction() {
        extractionJob?.cancel()
        setUiExtracting(false)
        tvStatus.text = "Stopped."
    }

    private suspend fun doExtract(uri: Uri, fps: Float, startMs: Long, endMs: Long) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this@MainActivity, uri)

            val durationMs   = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val clampedStart = startMs.coerceIn(0L, durationMs)
            val clampedEnd   = endMs.coerceIn(clampedStart, durationMs)
            val rangeMs      = clampedEnd - clampedStart
            val totalFrames  = ((rangeMs / 1000f) * fps).toInt().coerceAtLeast(1)
            val intervalUs   = (1_000_000.0 / fps).toLong()

            val safeVideoName = getDisplayName(uri)
                .substringBeforeLast('.')
                .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                .take(30)
            val stamp       = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val sessionName = "${safeVideoName}_${stamp}"

            val outDocDir: DocumentFile?
            val outLocalDir: File?
            val outPathLabel: String

            if (outputTreeUri != null) {
                val root = DocumentFile.fromTreeUri(this@MainActivity, outputTreeUri!!)!!
                outDocDir    = root.createDirectory(sessionName)
                outLocalDir  = null
                outPathLabel = "${root.name}/$sessionName"
            } else {
                outLocalDir  = File(getExternalFilesDir("frames"), sessionName).also { it.mkdirs() }
                outDocDir    = null
                outPathLabel = outLocalDir.absolutePath
            }

            withContext(Dispatchers.Main) {
                progressBar.max = totalFrames
                tvProgress.text = "0 / $totalFrames"
            }

            var extracted = 0
            var timeUs    = clampedStart * 1000L
            val endUs     = clampedEnd * 1000L
            val startWall = System.currentTimeMillis()

            while (timeUs <= endUs && extracted < totalFrames) {
                if (!currentCoroutineContext().isActive) break

                val bmp: Bitmap? = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)

                if (bmp != null) {
                    val outName = "frame_%06d.png".format(extracted + 1)
                    if (outDocDir != null) {
                        val df = outDocDir.createFile("image/png", outName)
                        df?.let { contentResolver.openOutputStream(it.uri)?.use { os -> bmp.compress(Bitmap.CompressFormat.PNG, 100, os) } }
                    } else {
                        FileOutputStream(File(outLocalDir!!, outName)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    }
                    bmp.recycle()
                    extracted++

                    val cur        = extracted
                    val elapsedMs  = System.currentTimeMillis() - startWall
                    val msPerFrame = if (cur > 0) elapsedMs / cur else 0L
                    val remaining  = (totalFrames - cur) * msPerFrame
                    val etaText    = if (cur > 1) "~${formatDuration(remaining)} remaining" else "Estimating…"

                    withContext(Dispatchers.Main) {
                        progressBar.progress = cur
                        tvProgress.text = "$cur / $totalFrames"
                        tvEta.text = etaText
                    }
                }
                timeUs += intervalUs
            }

            val finalCount = extracted
            withContext(Dispatchers.Main) {
                setUiExtracting(false)
                tvStatus.text = "Done — $finalCount frames saved."
                tvOutputPath.text = outPathLabel
                cardOutput.visibility = View.VISIBLE
                tvEta.text = ""
            }

        } catch (e: CancellationException) {
            withContext(Dispatchers.Main) { setUiExtracting(false); tvStatus.text = "Stopped." }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) { setUiExtracting(false); tvStatus.text = "Error: ${e.message}" }
        } finally {
            retriever.release()
        }
    }

    // ─── Rebuild Video ────────────────────────────────────────────────────────

    private fun startRebuild() {
        val zipUri = selectedZipUri ?: run {
            Toast.makeText(this, "Select a ZIP file first", Toast.LENGTH_SHORT).show()
            return
        }
        val fps = etRebuildFps.text.toString().toFloatOrNull()?.coerceIn(1f, 240f) ?: run {
            Toast.makeText(this, "Enter a valid FPS value (1–240)", Toast.LENGTH_SHORT).show()
            return
        }

        setUiRebuilding(true)
        cardRebuildProgress.visibility = View.VISIBLE
        cardRebuildOutput.visibility   = View.GONE
        progressRebuild.isIndeterminate = true
        progressRebuild.progress = 0
        tvRebuildProgress.text = "…"
        tvRebuildStatus.text = "Extracting ZIP…"

        rebuildJob = lifecycleScope.launch(Dispatchers.IO) {
            doRebuildVideo(zipUri, fps)
        }
    }

    private fun cancelRebuild() {
        rebuildJob?.cancel()
        setUiRebuilding(false)
        tvRebuildStatus.text = "Stopped."
        File(cacheDir, "rebuild_frames").deleteRecursively()
    }

    private suspend fun doRebuildVideo(zipUri: Uri, fps: Float) {
        // ── Phase 1: Extract PNGs from ZIP ───────────────────────────────────
        val frames = try {
            extractZipToTemp(zipUri)
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                setUiRebuilding(false)
                tvRebuildStatus.text = "ZIP read error: ${e.message}"
            }
            return
        }

        if (frames.isEmpty()) {
            withContext(Dispatchers.Main) {
                setUiRebuilding(false)
                tvRebuildStatus.text = "No PNG frames found in ZIP."
            }
            return
        }

        // ── Phase 2: Read dimensions from first frame ─────────────────────────
        val firstBmp = BitmapFactory.decodeFile(frames[0].absolutePath)
        if (firstBmp == null) {
            withContext(Dispatchers.Main) {
                setUiRebuilding(false)
                tvRebuildStatus.text = "Could not decode first frame PNG."
            }
            return
        }
        // H.264 encoder requires even-numbered width and height
        val encW = if (firstBmp.width  % 2 == 0) firstBmp.width  else firstBmp.width  + 1
        val encH = if (firstBmp.height % 2 == 0) firstBmp.height else firstBmp.height + 1
        firstBmp.recycle()

        val totalFrames    = frames.size
        val frameIntervalUs = (1_000_000.0 / fps).toLong()

        withContext(Dispatchers.Main) {
            progressRebuild.isIndeterminate = false
            progressRebuild.max = totalFrames
            progressRebuild.progress = 0
            tvRebuildProgress.text = "0 / $totalFrames"
            tvRebuildStatus.text = "Encoding ${encW}×${encH} · ${"%.1f".format(fps)} fps · $totalFrames frames…"
        }

        // ── Phase 3: Encode with MediaCodec + MediaMuxer ─────────────────────
        val tempOutput = File(cacheDir, "rebuild_output_${System.currentTimeMillis()}.mp4")
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer?   = null
        var trackIndex = -1
        var muxerStarted = false

        try {
            val bitrate = (encW * encH * fps * 0.2f).toInt().coerceIn(1_000_000, 20_000_000)
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, encW, encH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps.toInt().coerceAtLeast(1))
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            muxer = MediaMuxer(tempOutput.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val bufferInfo = MediaCodec.BufferInfo()

            // Local drain helper: reads encoded output and writes to muxer.
            // Returns true if EOS was seen.
            fun drainOutput(endOfStream: Boolean): Boolean {
                var sawEos = false
                val timeoutUs = if (endOfStream) 50_000L else 0L
                var maxAttempts = if (endOfStream) 200 else 10
                while (maxAttempts-- > 0 && !sawEos) {
                    val outIdx = encoder!!.dequeueOutputBuffer(bufferInfo, timeoutUs)
                    when {
                        outIdx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream) return false
                        }
                        outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (!muxerStarted) {
                                trackIndex = muxer!!.addTrack(encoder!!.outputFormat)
                                muxer!!.start()
                                muxerStarted = true
                            }
                        }
                        outIdx >= 0 -> {
                            val isConfig = bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                            val isEos    = bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            if (!isConfig && muxerStarted && bufferInfo.size > 0) {
                                muxer!!.writeSampleData(trackIndex, encoder!!.getOutputBuffer(outIdx)!!, bufferInfo)
                            }
                            encoder!!.releaseOutputBuffer(outIdx, false)
                            if (isEos) sawEos = true
                        }
                    }
                }
                return sawEos
            }

            // ── Feed frames ──────────────────────────────────────────────────
            var presentationUs = 0L
            for ((idx, frameFile) in frames.withIndex()) {
                if (!currentCoroutineContext().isActive) break

                val bmp = BitmapFactory.decodeFile(frameFile.absolutePath) ?: continue
                val scaledBmp = if (bmp.width == encW && bmp.height == encH) {
                    bmp
                } else {
                    val s = Bitmap.createScaledBitmap(bmp, encW, encH, true)
                    bmp.recycle()
                    s
                }

                val nv12 = bitmapToNV12(scaledBmp, encW, encH)
                scaledBmp.recycle()

                // Queue input buffer
                var inputQueued = false
                var inputAttempts = 0
                while (!inputQueued && inputAttempts++ < 20) {
                    val inputIdx = encoder!!.dequeueInputBuffer(10_000L)
                    if (inputIdx >= 0) {
                        val buf = encoder!!.getInputBuffer(inputIdx)!!
                        buf.clear()
                        buf.put(nv12)
                        encoder!!.queueInputBuffer(inputIdx, 0, nv12.size, presentationUs, 0)
                        presentationUs += frameIntervalUs
                        inputQueued = true
                    } else {
                        // Drain to free up space
                        drainOutput(false)
                    }
                }

                // Partial drain after each frame
                drainOutput(false)

                val cur = idx + 1
                withContext(Dispatchers.Main) {
                    progressRebuild.progress = cur
                    tvRebuildProgress.text = "$cur / $totalFrames"
                }
            }

            // ── Signal end of stream ─────────────────────────────────────────
            var eosQueued = false
            var eosAttempts = 0
            while (!eosQueued && eosAttempts++ < 30) {
                val inputIdx = encoder!!.dequeueInputBuffer(10_000L)
                if (inputIdx >= 0) {
                    encoder!!.queueInputBuffer(inputIdx, 0, 0, presentationUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    eosQueued = true
                } else {
                    drainOutput(false)
                }
            }

            // ── Final drain until EOS ────────────────────────────────────────
            drainOutput(true)

        } catch (e: CancellationException) {
            withContext(Dispatchers.Main) {
                setUiRebuilding(false)
                tvRebuildStatus.text = "Stopped."
            }
            encoder?.stop(); encoder?.release()
            try { muxer?.stop() } catch (_: Exception) {}
            muxer?.release()
            tempOutput.delete()
            File(cacheDir, "rebuild_frames").deleteRecursively()
            return
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                setUiRebuilding(false)
                tvRebuildStatus.text = "Encode error: ${e.message}"
            }
            encoder?.stop(); encoder?.release()
            try { muxer?.stop() } catch (_: Exception) {}
            muxer?.release()
            tempOutput.delete()
            File(cacheDir, "rebuild_frames").deleteRecursively()
            return
        }

        encoder?.stop(); encoder?.release()
        try { muxer?.stop() } catch (_: Exception) {}
        muxer?.release()

        // ── Phase 4: Copy output to destination ───────────────────────────────
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outName = "rebuild_$stamp.mp4"
        val outPathLabel: String

        try {
            if (outputTreeUri != null) {
                val root   = DocumentFile.fromTreeUri(this@MainActivity, outputTreeUri!!)!!
                val outDoc = root.createFile("video/mp4", outName)
                outDoc?.let { doc ->
                    contentResolver.openOutputStream(doc.uri)?.use { os ->
                        FileInputStream(tempOutput).use { it.copyTo(os) }
                    }
                }
                outPathLabel = "${root.name}/$outName"
            } else {
                val outDir  = (getExternalFilesDir("videos") ?: cacheDir).also { it.mkdirs() }
                val outFile = File(outDir, outName)
                tempOutput.copyTo(outFile, overwrite = true)
                outPathLabel = outFile.absolutePath
            }
        } finally {
            tempOutput.delete()
            File(cacheDir, "rebuild_frames").deleteRecursively()
        }

        withContext(Dispatchers.Main) {
            setUiRebuilding(false)
            tvRebuildStatus.text = "Done — $totalFrames frames → video saved."
            tvRebuildOutputPath.text = outPathLabel
            cardRebuildOutput.visibility = View.VISIBLE
        }
    }

    /**
     * Extracts all .png files from the ZIP at [zipUri] into a temp dir, sorted by name.
     * Non-PNG entries are skipped; the directory tree inside the ZIP is flattened.
     */
    private fun extractZipToTemp(zipUri: Uri): List<File> {
        val tempDir = File(cacheDir, "rebuild_frames").also {
            it.deleteRecursively()
            it.mkdirs()
        }
        contentResolver.openInputStream(zipUri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".png", ignoreCase = true)) {
                        // Flatten to filename-only to avoid path traversal
                        val outFile = File(tempDir, File(entry.name).name)
                        FileOutputStream(outFile).use { out -> zis.copyTo(out) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        return tempDir.listFiles { f -> f.name.endsWith(".png", ignoreCase = true) }
            ?.sortedBy { it.name }
            ?: emptyList()
    }

    /**
     * Converts an ARGB_8888 [Bitmap] to an NV12 (YUV420SemiPlanar) byte array.
     * NV12 layout: Y plane (w×h bytes) followed by interleaved UV plane (w×h/2 bytes).
     * H.264 encoders configured with COLOR_FormatYUV420SemiPlanar expect this layout.
     */
    private fun bitmapToNV12(bmp: Bitmap, w: Int, h: Int): ByteArray {
        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        val nv12 = ByteArray(w * h * 3 / 2)

        // Y plane
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8)  and 0xFF
            val b =  p         and 0xFF
            val y = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(16, 235)
            nv12[i] = y.toByte()
        }

        // Interleaved UV plane (2×2 sub-sampled: one U and one V per 2×2 pixel block)
        val uvBase = w * h
        var uvIdx  = 0
        for (row in 0 until h step 2) {
            for (col in 0 until w step 2) {
                val p = pixels[row * w + col]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8)  and 0xFF
                val b =  p         and 0xFF
                val u = (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(16, 240)
                val v = (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(16, 240)
                nv12[uvBase + uvIdx]     = u.toByte()
                nv12[uvBase + uvIdx + 1] = v.toByte()
                uvIdx += 2
            }
        }
        return nv12
    }

    // ─── UI helpers ───────────────────────────────────────────────────────────

    private fun setUiExtracting(active: Boolean) {
        btnExtract.isEnabled      = !active
        btnSelect.isEnabled       = !active
        btnPreview.isEnabled      = !active
        btnChooseFolder.isEnabled = !active
        btnCancel.visibility = if (active) View.VISIBLE else View.GONE
    }

    private fun setUiRebuilding(active: Boolean) {
        btnRebuild.isEnabled        = !active
        btnSelectZip.isEnabled      = !active
        btnRebuildCancel.visibility = if (active) View.VISIBLE else View.GONE
    }

    // ─── Time helpers ─────────────────────────────────────────────────────────

    /** Parse time strings like "3:00.000", "1:23:45.100", "45.500", "0:30" → ms */
    private fun parseTimeMs(s: String): Long? {
        val t = s.trim().ifEmpty { return null }
        return try {
            val dotIdx = t.lastIndexOf('.')
            val msPart: Long
            val timePart: String
            if (dotIdx >= 0) {
                timePart = t.substring(0, dotIdx)
                msPart   = t.substring(dotIdx + 1).padEnd(3, '0').take(3).toLong()
            } else {
                timePart = t
                msPart   = 0L
            }
            val segs = timePart.split(":")
            val totalSec = when (segs.size) {
                1 -> segs[0].toLong()
                2 -> segs[0].toLong() * 60 + segs[1].toLong()
                3 -> segs[0].toLong() * 3600 + segs[1].toLong() * 60 + segs[2].toLong()
                else -> return null
            }
            totalSec * 1000 + msPart
        } catch (e: Exception) { null }
    }

    /** Format milliseconds as m:ss.mmm or h:mm:ss.mmm */
    private fun formatTimeMs(ms: Long): String {
        val h      = ms / 3_600_000
        val m      = (ms % 3_600_000) / 60_000
        val s      = (ms % 60_000) / 1000
        val millis = ms % 1000
        return if (h > 0) "%d:%02d:%02d.%03d".format(h, m, s, millis)
        else "%d:%02d.%03d".format(m, s, millis)
    }

    /** Format milliseconds as compact duration (e.g. for ETA) */
    private fun formatDuration(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun getDisplayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) return c.getString(0) ?: "file" }
        return uri.lastPathSegment ?: "file"
    }
}
