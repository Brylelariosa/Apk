# VideoFrameExtractor — Devlog

Track what we build, fix, and improve. Newest entries first.

---

## v1.2 — Rebuild Video from ZIP
**Built:** ZIP → MP4 rebuild feature using MediaCodec + MediaMuxer (no FFmpeg)

### What's new

#### ZIP → Video Rebuild
- New **Rebuild Video** section added below the existing extract section, visually separated with a divider and amber/gold (#FFC947) accent color
- **Select ZIP File** button opens the system file picker filtered to `application/zip`
- ZIP is extracted to a private temp directory (`cacheDir/rebuild_frames/`); entries are flattened by filename to avoid path traversal issues
- Only `.png` files are extracted; files are sorted alphabetically (preserves `frame_000001.png` ordering from the extractor)
- **Output FPS** field (default 30) — set this to the same fps used during extraction for correct playback speed
- **Rebuild Video** button starts encoding; **Stop** button cancels and cleans up temp files immediately

#### Encoding pipeline
- Uses `MediaCodec` (H.264/AVC encoder) + `MediaMuxer` (MP4 container) — no native libraries or permissions needed
- Color format: `COLOR_FormatYUV420SemiPlanar` (NV12) — universally supported on Android H.264 encoders
- Each PNG frame is decoded via `BitmapFactory`, converted from ARGB_8888 to NV12 in pure Kotlin using standard BT.601 YUV coefficients
- Width/height are automatically rounded up to the nearest even number (H.264 requirement); frames are scaled via `Bitmap.createScaledBitmap` only if needed
- Bitrate is auto-calculated as `(width × height × fps × 0.2)`, clamped between 1 Mbps and 20 Mbps
- I-frame interval set to 1 second for good seekability
- Encoder drain loop handles `INFO_OUTPUT_FORMAT_CHANGED`, `BUFFER_FLAG_CODEC_CONFIG`, and `BUFFER_FLAG_END_OF_STREAM` correctly to avoid muxer corruption
- Output is written to a temp file in `cacheDir`, then copied to the selected output location (SAF or app external storage) after encoding completes

#### Progress & Output
- **ENCODING** progress card appears when rebuild starts (amber theme)
- Progress bar and `X / N` counter update per frame
- Status line shows current phase: "Extracting ZIP…" → "Encoding WxH · fps · N frames…" → "Done — N frames → video saved."
- **VIDEO SAVED** output card (amber) appears on completion with path and Copy Path button
- Output goes to the same folder chosen in the extract section's **OUTPUT LOCATION** (or default app `videos/` folder)
- Output filename: `rebuild_YYYYMMDD_HHmmss.mp4`

#### New fields / launchers in MainActivity
- `selectedZipUri`, `rebuildJob` state fields
- `pickZip` launcher: `GetContent` with `application/zip` MIME type
- `extractZipToTemp(zipUri)` — streams ZipInputStream from ContentResolver, writes PNGs to `cacheDir/rebuild_frames/`, returns sorted `List<File>`
- `bitmapToNV12(bmp, w, h)` — converts ARGB_8888 to NV12 byte array; Y plane first, then interleaved UV (2×2 subsampled)
- `doRebuildVideo(zipUri, fps)` — full coroutine: extract → validate → encode → copy → cleanup
- `setUiRebuilding(active)` — disables Select ZIP and Rebuild buttons; shows/hides Stop button during encoding

#### Cleanup & error handling
- Temp frames dir and temp MP4 are always deleted after rebuild (success, cancel, or error)
- `CancellationException` caught separately so Stop button cleans up immediately
- Empty ZIP, unreadable first frame, and encoder errors all surface as status text messages (no crashes)

### No new dependencies
All encoding APIs (`MediaCodec`, `MediaMuxer`, `ZipInputStream`) are standard Android/Java — no additions to `build.gradle`.

### Known limitations
- Pure Kotlin ARGB→NV12 conversion is single-threaded; large frames (e.g. 4K) will encode slowly
- `MediaMuxer` requires a local file path, so output is always staged through `cacheDir` before moving to final destination
- Only PNG input is supported (matches what the extractor produces); JPEGs in the ZIP are silently skipped
- If the ZIP was extracted to a SAF (DocumentFile) folder, the user must first copy/zip the folder using a file manager before using Rebuild

---

## v1.1 — Save Location, Time Range, Frame Preview
**Built:** Three major feature additions

### Save Location
- New **OUTPUT LOCATION** card with "Choose Folder" button using `ActivityResultContracts.OpenDocumentTree`
- Persists folder permission with `takePersistableUriPermission` so chosen folder survives across sessions
- When a custom folder is picked, extraction writes via `DocumentFile` + SAF `ContentResolver` streams
- Session subfolder (`videoname_TIMESTAMP/`) is still created inside the chosen directory
- "Reset" button clears custom folder and reverts to default app storage
- Default behaviour (app external storage) unchanged when no folder is chosen
- Added `androidx.documentfile:documentfile:1.0.1` dependency

### Time Range
- New **TIME RANGE** section inside the settings card
- **Start** and **End** time fields accept `m:ss.mmm`, `h:mm:ss.mmm`, `ss.mmm` formats with millisecond precision (e.g. `3:00.000`)
- Auto-filled on video load: Start → `0:00.000`, End → video duration
- Extraction clamps both values to `[0, videoDuration]`; validates that start < end
- `updateEstimate()` now uses range duration instead of full video duration
- Range info line shows `Range: 0:30.000 → 1:45.000 (1:15)` live as you type
- `parseTimeMs()` helper parses all supported formats robustly
- `formatTimeMs()` helper produces `m:ss.mmm` / `h:mm:ss.mmm` display strings

### Frame Preview
- **Preview** button next to Start time field
- Loads frame at the current Start time using `OPTION_CLOSEST_SYNC` on IO dispatcher
- Shows frame in a new **FRAME PREVIEW** card (hidden until first preview)
- Card label updates to `Frame at 0:30.000` to confirm which timestamp is shown
- Preview button disabled during active extraction to avoid retriever contention
- `previewJob` is cancellable so rapid taps don't pile up stale requests

### Bug / UX fixes
- `setUiExtracting()` now also disables Preview and Choose Folder buttons during extraction
- `doExtract` now accepts explicit `startMs`/`endMs` params; `startExtraction()` validates and passes them
- Frame counter `totalFrames` is now derived from range duration, not full video duration

---

## v1.0 — Initial Release
**Built:** Core frame extraction app

### What's in v1.0
- **Video picker** via `ActivityResultContracts.GetContent` (no permission needed on modern Android)
- **Auto-detects** video resolution, duration, and native FPS (API 28+ via `METADATA_KEY_VIDEO_FRAME_COUNT`)
- **FPS input** pre-filled with native fps; any custom value supported (0.1–240)
- **Live estimate** updates as you type (e.g. "1800 frames")
- **Frame extraction** using `MediaMetadataRetriever.getFrameAtTime()` with `OPTION_CLOSEST` for accuracy
- **PNG output** saved to `getExternalFilesDir("frames")` — no permissions needed
- **Output folder** timestamped per session: `videoname_20250615_143022/`
- **Frame files** named `frame_000001.png`, `frame_000002.png`, etc.
- **Progress bar** + live frame counter + ETA estimate during extraction
- **Cancel button** stops extraction mid-way, keeping frames extracted so far
- **Copy Path** button copies output folder path to clipboard
- Dark green (#1B4332 / #52B788) UI theme

### Output path
```
/sdcard/Android/data/com.bryle.videoframes/files/frames/videoname_TIMESTAMP/
```
Accessible via any file manager app under `Android/data/`.

### Known limitations
- `OPTION_CLOSEST` is accurate but slow on high-fps videos (decodes every frame sequentially)
- Output goes to app-specific storage, not directly to Gallery/Photos
- No batch processing (one video at a time)
- ETA is a rough estimate based on frames-per-second rate so far
- SAF-backed output (custom folder) is slower than direct File I/O due to per-file IPC overhead

---

## Ideas / Future Work

### Performance
- [ ] Add "Fast mode" toggle → uses `OPTION_CLOSEST_SYNC` (keyframes only, much faster)
- [ ] API 28+: use `getFramesAtIndex()` in batches for native-fps extraction (more efficient)
- [ ] Per-frame decode timing displayed in UI
- [ ] Batch-copy to SAF folder post-extraction (extract locally for speed, then move)
- [ ] Parallel NV12 conversion using coroutines across CPU cores

### Output options
- [ ] Save to `Pictures/` via MediaStore (appears in Gallery) — needs MediaStore insert on Q+
- [ ] Configurable output format: PNG / JPEG (with JPEG quality slider)
- [ ] Custom output folder name override
- [ ] Resize output frames (e.g. 50% scale to reduce file size)
- [ ] Rebuild output: JPEG frame input support
- [ ] Rebuild output: configurable codec (H.265/HEVC for smaller files)

### UI / UX
- [ ] Preview End frame (second preview button)
- [ ] Scrub slider tied to preview — drag to seek and preview any timestamp
- [ ] Recent jobs history (list of past extractions with frame counts)
- [ ] Share button to export a single extracted frame

### Extraction
- [ ] Batch mode: queue multiple videos
- [ ] Extract every Nth frame mode (e.g. every 5th frame)
- [ ] Frame deduplication: skip near-identical frames (hash diff)
