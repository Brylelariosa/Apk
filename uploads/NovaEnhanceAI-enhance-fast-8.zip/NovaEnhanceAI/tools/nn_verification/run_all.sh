#!/usr/bin/env bash
# Builds and runs every native verification on a desktop machine (g++ >= 9, no Android tooling needed).
#
#   tools/nn_verification/run_all.sh            # full run (several minutes on one core)
#   tools/nn_verification/run_all.sh --quick    # reduced sizes/steps, for CI and sanitizer builds
#
# Each check runs against three SIMD flavours of the SAME kernel source:
#   portable        - GCC/Clang vector extensions (what x86 uses)
#   neon-aarch64    - real NEON code path, run through neon_shim.h on this CPU
#   neon-armv7      - the 32-bit NEON code path (16-register blocking), same way
# The shim validates the kernels' logic and wrapper semantics; it does not replace a run on a real phone.
set -euo pipefail
cd "$(dirname "$0")"
CPP=../../app/src/main/cpp
NN=$CPP/nn
QUICK="${1:-}"
OUT=$(mktemp -d)
CXX=${CXX:-g++}
COMMON="-std=c++17 -O2 -Wall -Wextra -pthread -I$CPP -I$NN -I."

NN_SRC="$NN/network.cpp $NN/inference.cpp $NN/training.cpp $NN/conv_kernels.cpp $NN/weights.cpp $CPP/util/thread_pool.cpp"

run() { echo; echo "### $*"; "$@"; }

for flavour in "portable:" "neon-aarch64:-DNOVA_SIMD_SHIM_A64" "neon-armv7:-DNOVA_SIMD_SHIM_A32 -ffp-contract=off"; do
  name=${flavour%%:*}; flags=${flavour#*:}
  echo; echo "==================== SIMD flavour: $name ===================="
  $CXX $COMMON $flags kernel_check.cpp $NN/conv_kernels.cpp -o $OUT/kernel_$name
  run $OUT/kernel_$name | tail -3
  $CXX $COMMON $flags $NN_SRC reference_network.cpp equivalence_check.cpp -o $OUT/equiv_$name
  NOVA_NN_THREADS=4 run $OUT/equiv_$name $QUICK | grep -E "FAIL|PASS|quick"
done

echo; echo "==================== classical filters (bit-exact vs original) ===================="
(cd ../filter_verification && ./run.sh $QUICK)

echo; echo "==================== legacy gradient/integration checks ===================="
$CXX -std=c++17 -O2 -I$NN gradient_check.cpp reference_network.cpp -o $OUT/gradient_check 2>/dev/null && run $OUT/gradient_check | tail -3 || echo "(gradient_check uses the reference implementation directly; see README)"
echo; echo "ALL VERIFICATION STEPS FINISHED"
