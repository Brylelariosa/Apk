// A/B check of the optimized network (app/src/main/cpp/nn/*) against the golden
// scalar reference (reference_network.cpp = the original implementation).
//
//   1. forward:   inferForward() on 64x64 tiles
//   2. gradients: computeLossAndGradient() vs reference::lossAndGradient(), incl. a batch
//                 larger than one wave and 1 / 3 / all threads
//   3. training:  a 25-step trainStep() trajectory (Adam + L2-SP + clipping) vs the reference
//   4. stitching: inferRegion() on awkward image sizes vs a naive double-precision
//                 WHOLE-IMAGE convolution - proves the column-strip halos give exactly
//                 the result of one fully-convolutional pass (no tile seams), byte-exact
//                 against the Kotlin encode/decode rounding.
//
// See run_all.sh for build lines (portable / AArch64-shim / ARMv7-shim flavours).
#include "inference.h"
#include "network.h"
#include "util/thread_pool.h"
#include "training.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <random>
#include <vector>

namespace novaenhance::nn::reference {
float lossAndGradient(const float* inputBatch, const float* targetBatch, int batchSize, const float* params,
                      float* gradOut);
void inferForward(const float* input, const float* params, float* output);
float trainStep(const float* inputBatch, const float* targetBatch, int batchSize, float* params, float* momentum,
                float* velocity, const float* anchorParams, int adamStepNumber, float learningRate,
                float l2SpLambda);
}  // namespace novaenhance::nn::reference

using namespace novaenhance::nn;

namespace {

bool g_ok = true;
bool g_quick = false;  // --quick: smaller sizes / fewer steps, for sanitizer builds that run 10-50x slower

void check(bool cond, const char* what, double a = 0, double b = 0) {
    printf("  [%s] %s", cond ? "PASS" : "FAIL", what);
    if (a != 0 || b != 0) printf("   (%.3e vs limit %.3e)", a, b);
    printf("\n");
    g_ok &= cond;
}

std::mt19937 rng(2024);
float uni(float lo, float hi) { return std::uniform_real_distribution<float>(lo, hi)(rng); }

/** Non-trivial weights everywhere (initializeParams makes conv4 ~0, which would hide conv4 bugs). */
void makeParams(std::vector<float>& p, uint32_t seed) {
    p.assign(TOTAL_PARAMS, 0.0f);
    initializeParams(p.data(), seed);
    for (int i = W4_OFFSET; i < W4_OFFSET + W4_SIZE; ++i) p[i] = uni(-0.08f, 0.08f);
    for (int i = B1_OFFSET; i < B1_OFFSET + B1_SIZE; ++i) p[i] = uni(-0.1f, 0.3f);  // some dead + some live ReLUs
    for (int i = B2_OFFSET; i < B2_OFFSET + B2_SIZE; ++i) p[i] = uni(-0.1f, 0.3f);
    for (int i = B3_OFFSET; i < B3_OFFSET + B3_SIZE; ++i) p[i] = uni(-0.1f, 0.3f);
    for (int i = B4_OFFSET; i < B4_OFFSET + B4_SIZE; ++i) p[i] = uni(-0.05f, 0.05f);
}

void makeBatch(std::vector<float>& in, std::vector<float>& tg, int n) {
    in.resize(static_cast<size_t>(n) * INPUT_FLOATS);
    tg.resize(static_cast<size_t>(n) * OUTPUT_FLOATS);
    for (size_t i = 0; i < in.size(); ++i) {
        in[i] = uni(0.0f, 1.0f);
        tg[i] = std::min(1.0f, std::max(0.0f, in[i] + uni(-0.15f, 0.15f)));
    }
}

double maxAbsDiff(const float* a, const float* b, size_t n) {
    double m = 0;
    for (size_t i = 0; i < n; ++i) m = std::max(m, static_cast<double>(std::fabs(a[i] - b[i])));
    return m;
}

// ---------------------------------------------------------------- 1. forward
void testForward() {
    printf("\n== 1. forward pass (64x64 tile) vs reference ==\n");
    for (uint32_t seed : {1u, 2u, 3u}) {
        if (g_quick && seed > 1) break;
        std::vector<float> params, in, tg;
        makeParams(params, seed);
        makeBatch(in, tg, 1);
        std::vector<float> a(OUTPUT_FLOATS), b(OUTPUT_FLOATS);
        reference::inferForward(in.data(), params.data(), a.data());
        inferForward(in.data(), params.data(), b.data());
        const double d = maxAbsDiff(a.data(), b.data(), OUTPUT_FLOATS);
        char msg[64];
        snprintf(msg, sizeof msg, "seed %u max|diff|", seed);
        check(d < 2e-5, msg, d, 2e-5);
    }
}

// -------------------------------------------------------------- 2. gradients
void testGradients() {
    printf("\n== 2. loss + gradient vs reference ==\n");
    std::vector<float> params;
    makeParams(params, 7);
    const int pool = novaenhance::ThreadPool::instance().maxThreads();
    printf("  (thread pool size on this host: %d)\n", pool);

    for (int batch : {1, 3, 9}) {
        if (g_quick && batch > 2) break;
        std::vector<float> in, tg;
        makeBatch(in, tg, batch);
        std::vector<float> refGrad(TOTAL_PARAMS);
        const float refLoss = reference::lossAndGradient(in.data(), tg.data(), batch, params.data(), refGrad.data());
        double refMax = 0;
        for (float g : refGrad) refMax = std::max(refMax, static_cast<double>(std::fabs(g)));

        for (int threads : {1, 3, 0}) {
            std::vector<float> grad(TOTAL_PARAMS);
            const float loss = computeLossAndGradient(in.data(), tg.data(), batch, params.data(), grad.data(), threads);
            const double gd = maxAbsDiff(refGrad.data(), grad.data(), TOTAL_PARAMS) / std::max(refMax, 1e-12);
            const double ld = std::fabs(loss - refLoss) / std::max(1e-12f, std::fabs(refLoss));
            char msg[96];
            snprintf(msg, sizeof msg, "batch %d threads %d: gradient (rel. to max|g|=%.2e)", batch, threads, refMax);
            check(gd < 2e-4, msg, gd, 2e-4);
            snprintf(msg, sizeof msg, "batch %d threads %d: loss %.6f (ref %.6f)", batch, threads, loss, refLoss);
            check(ld < 1e-5, msg, ld, 1e-5);
        }
    }


    // Linearity: the gradient of a batch is the mean of the per-sample gradients. Cheap, independent of the slow
    // scalar reference, and batch 9 crosses the 8-sample wave boundary inside computeLossAndGradient.
    {
        const int batch = 9;
        std::vector<float> bin, btg;
        makeBatch(bin, btg, batch);
        std::vector<float> whole(TOTAL_PARAMS), one(TOTAL_PARAMS), mean(TOTAL_PARAMS, 0.0f);
        const float wholeLoss = computeLossAndGradient(bin.data(), btg.data(), batch, params.data(), whole.data(), 0);
        double lossMean = 0;
        for (int s = 0; s < batch; ++s) {
            lossMean += computeLossAndGradient(bin.data() + static_cast<size_t>(s) * INPUT_FLOATS,
                                               btg.data() + static_cast<size_t>(s) * OUTPUT_FLOATS, 1, params.data(), one.data(), 0);
            for (int i = 0; i < TOTAL_PARAMS; ++i) mean[i] += one[i] / static_cast<float>(batch);
        }
        double wmax = 0;
        for (float g : whole) wmax = std::max(wmax, static_cast<double>(std::fabs(g)));
        const double d = maxAbsDiff(whole.data(), mean.data(), TOTAL_PARAMS) / wmax;
        check(d < 2e-4, "batch of 9 (two waves) == mean of 9 single-sample gradients", d, 2e-4);
        check(std::fabs(wholeLoss - lossMean / batch) < 1e-5, "batch-9 loss == mean of per-sample losses");
    }

    // threads == 1 must be bit-for-bit repeatable.
    std::vector<float> in, tg;
    makeBatch(in, tg, 4);
    std::vector<float> g1(TOTAL_PARAMS), g2(TOTAL_PARAMS);
    computeLossAndGradient(in.data(), tg.data(), 4, params.data(), g1.data(), 1);
    computeLossAndGradient(in.data(), tg.data(), 4, params.data(), g2.data(), 1);
    check(std::memcmp(g1.data(), g2.data(), sizeof(float) * TOTAL_PARAMS) == 0, "threads=1 is deterministic (bit-exact)");
    releaseTrainingWorkspace();
    computeLossAndGradient(in.data(), tg.data(), 4, params.data(), g2.data(), 1);
    check(std::memcmp(g1.data(), g2.data(), sizeof(float) * TOTAL_PARAMS) == 0,
          "result unchanged after releaseTrainingWorkspace()");
}

// --------------------------------------------------------------- 3. training
void testTrainingTrajectory() {
    const int steps = g_quick ? 3 : 25;
    printf("\n== 3. %d-step trainStep trajectory vs reference ==\n", steps);
    std::vector<float> p0;
    makeParams(p0, 11);
    std::vector<float> anchor = p0;
    std::vector<float> pr = p0, pn = p0;
    std::vector<float> mr(TOTAL_PARAMS, 0.0f), vr(TOTAL_PARAMS, 0.0f), mn = mr, vn = vr;

    float lossRef = 0, lossNew = 0, firstNew = 0;
    double worstRel = 0;
    for (int step = 1; step <= steps; ++step) {
        std::vector<float> in, tg;
        makeBatch(in, tg, 4);
        lossRef = reference::trainStep(in.data(), tg.data(), 4, pr.data(), mr.data(), vr.data(), anchor.data(), step, 1e-3f, 1e-3f);
        lossNew = trainStep(in.data(), tg.data(), 4, pn.data(), mn.data(), vn.data(), anchor.data(), step, 1e-3f, 1e-3f, 0);
        if (step == 1) firstNew = lossNew;
        worstRel = std::max(worstRel, static_cast<double>(std::fabs(lossNew - lossRef) / lossRef));
    }
    char msg[128];
    snprintf(msg, sizeof msg, "loss per step tracks reference (last: new %.5f vs ref %.5f)", lossNew, lossRef);
    check(worstRel < 2e-3, msg, worstRel, 2e-3);
    check(g_quick || lossNew < firstNew, "loss decreases over the run");

    double dot = 0, na = 0, nb = 0;
    for (int i = 0; i < TOTAL_PARAMS; ++i) {
        const double a = pr[i] - p0[i], b = pn[i] - p0[i];
        dot += a * b; na += a * a; nb += b * b;
    }
    const double cosine = dot / std::sqrt(na * nb + 1e-30);
    snprintf(msg, sizeof msg, "total parameter update direction cosine vs reference = %.6f", cosine);
    check(cosine > 0.999, msg, 1.0 - cosine, 1e-3);
    releaseTrainingWorkspace();
}

// -------------------------------------------------------------- 4. stitching
// Naive whole-image reference in double precision, zero padding at the image border only.
std::vector<float> naiveWholeImage(const std::vector<float>& rgb, int W, int H, const std::vector<float>& params) {
    auto conv = [&](const std::vector<double>& src, int cin, int cout, int wOff, int bOff, bool relu) {
        std::vector<double> dst(static_cast<size_t>(H) * W * cout);
        for (int y = 0; y < H; ++y)
            for (int x = 0; x < W; ++x)
                for (int co = 0; co < cout; ++co) {
                    double acc = params[bOff + co];
                    for (int ki = 0; ki < 3; ++ki) {
                        const int yy = y + ki - 1;
                        if (yy < 0 || yy >= H) continue;
                        for (int kj = 0; kj < 3; ++kj) {
                            const int xx = x + kj - 1;
                            if (xx < 0 || xx >= W) continue;
                            const double* px = &src[(static_cast<size_t>(yy) * W + xx) * cin];
                            const float* w = &params[wOff + (ki * 3 + kj) * cin * cout + co];
                            for (int ci = 0; ci < cin; ++ci) acc += px[ci] * static_cast<double>(w[ci * cout]);
                        }
                    }
                    dst[(static_cast<size_t>(y) * W + x) * cout + co] = relu ? std::max(acc, 0.0) : acc;
                }
        return dst;
    };
    std::vector<double> x0(rgb.begin(), rgb.end());
    auto r1 = conv(x0, CIN, C1, W1_OFFSET, B1_OFFSET, true);
    auto r2 = conv(r1, C1, C1, W2_OFFSET, B2_OFFSET, true);
    auto r3 = conv(r2, C1, C2, W3_OFFSET, B3_OFFSET, true);
    auto c4 = conv(r3, C2, COUT, W4_OFFSET, B4_OFFSET, false);
    std::vector<float> out(rgb.size());
    for (size_t i = 0; i < out.size(); ++i) out[i] = static_cast<float>(std::min(1.0, std::max(0.0, x0[i] + c4[i])));
    return out;
}

void testStitching() {
    printf("\n== 4. whole-image inference (column strips + halos) vs naive whole-image convolution ==\n");
    std::vector<float> params;
    makeParams(params, 5);

    struct Size { int w, h; };
    // Includes widths that leave a 1..4 pixel remainder after the last full strip (131 = 4*32 + 3):
    // the strip's right context must be clipped to the image, not read past the row end.
    const Size sizes[] = {{1, 1},   {3, 5},    {13, 7},  {64, 64}, {131, 77}, {200, 37}, {37, 200}, {301, 9},
                          {33, 6},  {35, 5},   {36, 4},  {67, 3},  {68, 3},   {69, 3},   {127, 4},  {129, 4},
                          {130, 4}, {132, 4},  {97, 2},  {5, 40}};
    int cases = 0, failures = 0;
    for (const Size& s : sizes) {
        if (g_quick && (static_cast<long>(s.w) * s.h > 600 || s.w == 1)) continue;
        std::vector<uint32_t> argb(static_cast<size_t>(s.w) * s.h);
        std::vector<float> rgb(argb.size() * 3);
        for (size_t i = 0; i < argb.size(); ++i) {
            const uint32_t r = rng() & 0xFF, g = rng() & 0xFF, b = rng() & 0xFF;
            argb[i] = (static_cast<uint32_t>(rng() & 0xFF) << 24) | (r << 16) | (g << 8) | b;  // random alpha: must be forced to FF
            rgb[i * 3 + 0] = static_cast<float>(r) / 255.0f;
            rgb[i * 3 + 1] = static_cast<float>(g) / 255.0f;
            rgb[i * 3 + 2] = static_cast<float>(b) / 255.0f;
        }
        const std::vector<float> expected = naiveWholeImage(rgb, s.w, s.h, params);

        for (int threads : {1, 3, 0}) {
            std::vector<uint32_t> out(argb.size(), 0xDEADBEEFu);
            inferRegion(argb.data(), s.w, s.h, params.data(), out.data(), threads);
            int maxByteDiff = 0, bigDiffs = 0;
            bool alphaOk = true;
            for (size_t i = 0; i < out.size(); ++i) {
                alphaOk &= (out[i] >> 24) == 0xFF;
                for (int c = 0; c < 3; ++c) {
                    const int got = static_cast<int>((out[i] >> (16 - 8 * c)) & 0xFF);
                    const int want = static_cast<int>(std::lrintf(expected[i * 3 + c] * 255.0f));
                    const int d = std::abs(got - want);
                    maxByteDiff = std::max(maxByteDiff, d);
                    if (d > 1) ++bigDiffs;
                }
            }
            ++cases;
            // +-1 is legitimate: float32 vs double accumulation can land either side of a .5 rounding tie.
            if (!(alphaOk && bigDiffs == 0)) {
                ++failures;
                printf("  [FAIL] %dx%d threads=%d maxByteDiff=%d bigDiffs=%d alphaOk=%d\n", s.w, s.h, threads,
                       maxByteDiff, bigDiffs, alphaOk);
            }
        }
    }
    char msg[160];
    snprintf(msg, sizeof msg, "%d size/thread combinations: every pixel within 1/255 of the whole-image result, alpha=FF", cases);
    check(failures == 0, msg);
}

}  // namespace

int main(int argc, char** argv) {
    for (int i = 1; i < argc; ++i) g_quick |= std::strcmp(argv[i], "--quick") == 0;
    if (g_quick) printf("(quick mode)\n");
    testForward();
    testGradients();
    testTrainingTrajectory();
    testStitching();
    printf("\n%s\n", g_ok ? "ALL PASS" : "SOME CHECKS FAILED");
    return g_ok ? 0 : 1;
}
