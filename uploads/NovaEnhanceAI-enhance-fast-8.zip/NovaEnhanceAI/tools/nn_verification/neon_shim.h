#ifndef NOVAENHANCE_NEON_SHIM_H
#define NOVAENHANCE_NEON_SHIM_H

// ============================================================================
// HOST-ONLY emulation of the small subset of ARM NEON intrinsics that
// app/src/main/cpp/nn/simd.h uses, so the NEON code paths (AArch64 and ARMv7
// flavours) can be compiled and executed on a desktop CPU in the verification
// tools. NOT part of the Android build.
//
// Semantics follow the ARM Architecture Reference Manual for each instruction:
//   * vfmaq_* (FMLA)           : fused multiply-add, ONE rounding   -> std::fmaf
//   * vmlaq_* (VMLA / FMUL+FADD): two roundings (multiply, then add)
//   * vbslq_f32 (BSL)          : bitwise select
//   * vaddvq_f32 (FADDP,FADDP) : ((a0+a1)+(a2+a3))
//
// AArch64-only intrinsics are declared ONLY when NOVA_SIMD_SHIM_A64 is defined,
// so compiling the ARMv7 flavour (NOVA_SIMD_SHIM_A32) fails if simd.h ever
// starts using an intrinsic that 32-bit NEON does not have.
//
// Build the ARMv7 flavour with -ffp-contract=off so the compiler cannot fuse
// the separately-rounded vmlaq_* emulation.
// ============================================================================

#include <cmath>
#include <cstdint>
#include <cstring>

struct float32x2_t { float v[2]; };
struct float32x4_t { float v[4]; };
struct uint32x4_t { uint32_t v[4]; };

inline float32x4_t vld1q_f32(const float* p) { float32x4_t r; std::memcpy(r.v, p, sizeof(r.v)); return r; }
inline void vst1q_f32(float* p, float32x4_t a) { std::memcpy(p, a.v, sizeof(a.v)); }
inline float32x4_t vdupq_n_f32(float x) { return {{x, x, x, x}}; }

inline float32x4_t vaddq_f32(float32x4_t a, float32x4_t b) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) r.v[i] = a.v[i] + b.v[i];
    return r;
}

inline float32x4_t vmaxq_f32(float32x4_t a, float32x4_t b) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) r.v[i] = (a.v[i] != a.v[i] || b.v[i] != b.v[i]) ? NAN : (a.v[i] > b.v[i] ? a.v[i] : b.v[i]);
    return r;
}

// a + b * c, two roundings (valid on both ARMv7 and AArch64).
inline float32x4_t vmlaq_f32(float32x4_t a, float32x4_t b, float32x4_t c) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) {
        volatile float product = b.v[i] * c.v[i];
        r.v[i] = a.v[i] + product;
    }
    return r;
}

// a + b * v[lane], two roundings.
inline float32x4_t vmlaq_lane_f32(float32x4_t a, float32x4_t b, float32x2_t v, int lane) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) {
        volatile float product = b.v[i] * v.v[lane];
        r.v[i] = a.v[i] + product;
    }
    return r;
}

inline float32x2_t vget_low_f32(float32x4_t a) { return {{a.v[0], a.v[1]}}; }
inline float32x2_t vget_high_f32(float32x4_t a) { return {{a.v[2], a.v[3]}}; }
inline float32x2_t vadd_f32(float32x2_t a, float32x2_t b) { return {{a.v[0] + b.v[0], a.v[1] + b.v[1]}}; }
inline float32x2_t vpadd_f32(float32x2_t a, float32x2_t b) { return {{a.v[0] + a.v[1], b.v[0] + b.v[1]}}; }
inline float vget_lane_f32(float32x2_t a, int lane) { return a.v[lane]; }

inline uint32x4_t vcgtq_f32(float32x4_t a, float32x4_t b) {
    uint32x4_t r;
    for (int i = 0; i < 4; ++i) r.v[i] = a.v[i] > b.v[i] ? 0xFFFFFFFFu : 0u;
    return r;
}

inline float32x4_t vbslq_f32(uint32x4_t mask, float32x4_t a, float32x4_t b) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) {
        uint32_t ua, ub;
        std::memcpy(&ua, &a.v[i], 4);
        std::memcpy(&ub, &b.v[i], 4);
        const uint32_t ur = (mask.v[i] & ua) | (~mask.v[i] & ub);
        std::memcpy(&r.v[i], &ur, 4);
    }
    return r;
}

#if defined(NOVA_SIMD_SHIM_A64)
// ---- AArch64-only ----------------------------------------------------------
inline float32x4_t vfmaq_f32(float32x4_t a, float32x4_t b, float32x4_t c) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) r.v[i] = std::fmaf(b.v[i], c.v[i], a.v[i]);
    return r;
}

inline float32x4_t vfmaq_laneq_f32(float32x4_t a, float32x4_t b, float32x4_t v, int lane) {
    float32x4_t r;
    for (int i = 0; i < 4; ++i) r.v[i] = std::fmaf(b.v[i], v.v[lane], a.v[i]);
    return r;
}

inline float vaddvq_f32(float32x4_t a) { return (a.v[0] + a.v[1]) + (a.v[2] + a.v[3]); }
#endif

#endif  // NOVAENHANCE_NEON_SHIM_H
