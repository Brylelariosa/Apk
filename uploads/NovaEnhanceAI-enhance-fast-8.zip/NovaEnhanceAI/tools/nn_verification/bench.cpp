// Micro-benchmark for the optimized network. Prints ms/tile-equivalent for
// whole-image inference and ms/step for a batch-4 training step, so the numbers
// are directly comparable with the same two figures measured on the original
// scalar implementation (reference_network.cpp, also timed here).
//
// Host numbers are a RELATIVE indication only - the target is a Cortex-A75/A55
// phone, not this machine. Use NOVA_NN_THREADS to size the pool.
#include "inference.h"
#include "network.h"
#include "util/thread_pool.h"

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <string>
#include <vector>

namespace novaenhance::nn::reference {
void inferForward(const float* input, const float* params, float* output);
float trainStep(const float* inputBatch, const float* targetBatch, int batchSize, float* params, float* momentum,
                float* velocity, const float* anchorParams, int adamStepNumber, float learningRate,
                float l2SpLambda);
}  // namespace novaenhance::nn::reference

using namespace novaenhance::nn;

static double nowMs() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

int main(int argc, char** argv) {
    const bool withReference = argc > 1 && std::string(argv[1]) == "--with-reference";
    std::vector<float> params(TOTAL_PARAMS);
    initializeParams(params.data(), 7);
    std::mt19937 rng(1);
    std::uniform_real_distribution<float> d(0.f, 1.f);

    printf("pool threads: %d\n", novaenhance::ThreadPool::instance().maxThreads());

    // ---- inference: 768 x 512 image (= 96 tiles of 64x64 area)
    const int W = 768, H = 512;
    std::vector<uint32_t> img(static_cast<size_t>(W) * H), out(img.size());
    for (auto& p : img) p = 0xFF000000u | (rng() & 0xFFFFFF);
    inferRegion(img.data(), W, H, params.data(), out.data(), 0);  // warm-up
    const int reps = 3;
    double t0 = nowMs();
    for (int i = 0; i < reps; ++i) inferRegion(img.data(), W, H, params.data(), out.data(), 0);
    const double regionMs = (nowMs() - t0) / reps;
    const double tileEquivalents = static_cast<double>(W) * H / (TILE_SIZE * TILE_SIZE);
    printf("inferRegion %dx%d: %.1f ms  =>  %.2f ms per 64x64-tile-equivalent (%.2f MP/s)\n", W, H, regionMs,
           regionMs / tileEquivalents, W * H / 1e6 / (regionMs / 1000.0));

    // ---- training step, batch 4
    std::vector<float> in(INPUT_FLOATS * 4), tg(OUTPUT_FLOATS * 4);
    for (auto& v : in) v = d(rng);
    for (auto& v : tg) v = d(rng);
    std::vector<float> p = params, m(TOTAL_PARAMS, 0.f), v(TOTAL_PARAMS, 0.f);
    trainStep(in.data(), tg.data(), 4, p.data(), m.data(), v.data(), nullptr, 1, 1e-4f, 0.f, 0);  // warm-up
    const int steps = 5;
    t0 = nowMs();
    float loss = 0;
    for (int i = 2; i < 2 + steps; ++i) loss = trainStep(in.data(), tg.data(), 4, p.data(), m.data(), v.data(), nullptr, i, 1e-4f, 0.f, 0);
    const double trainMs = (nowMs() - t0) / steps;
    printf("trainStep batch=4: %.1f ms/step (loss %.4f)\n", trainMs, loss);
    releaseTrainingWorkspace();

    if (withReference) {
        std::vector<float> o(OUTPUT_FLOATS);
        reference::inferForward(in.data(), params.data(), o.data());
        t0 = nowMs();
        for (int i = 0; i < 5; ++i) reference::inferForward(in.data(), params.data(), o.data());
        printf("[reference] inferForward: %.2f ms/tile\n", (nowMs() - t0) / 5);
        std::vector<float> p2 = params, m2(TOTAL_PARAMS, 0.f), v2(TOTAL_PARAMS, 0.f);
        t0 = nowMs();
        for (int i = 1; i <= 2; ++i) reference::trainStep(in.data(), tg.data(), 4, p2.data(), m2.data(), v2.data(), nullptr, i, 1e-4f, 0.f);
        printf("[reference] trainStep batch=4: %.1f ms/step\n", (nowMs() - t0) / 2);
    }
    return 0;
}
