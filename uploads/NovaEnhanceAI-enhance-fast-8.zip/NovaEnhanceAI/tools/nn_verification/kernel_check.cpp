// Checks the optimized convolution kernels (conv_kernels.cpp) against a naive
// double-precision reference for every shape the network uses (4->48, 48->48,
// 48->4 channels) plus awkward widths (non-multiples of the 4-pixel block, 1
// pixel wide) that only appear on image/strip edges.
//
// Build/run - see tools/nn_verification/run_all.sh, or by hand:
//   g++ -std=c++17 -O2 -I../../app/src/main/cpp/nn kernel_check.cpp ../../app/src/main/cpp/nn/conv_kernels.cpp -o /tmp/kernel_check
//   /tmp/kernel_check
// Add -DNOVA_SIMD_SHIM_A64 (or _A32 with -ffp-contract=off) and -I. to run the
// NEON code paths through neon_shim.h on a desktop CPU.
#include "conv_kernels.h"
#include "simd.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>

using namespace novaenhance::nn;

namespace {

std::mt19937 rng(12345);

float rnd(float scale = 1.0f) {
    static std::uniform_real_distribution<float> d(-1.0f, 1.0f);
    return d(rng) * scale;
}

// Padded plane (H+2) x (W+2) x C with zero border and random interior.
std::vector<float> randomPlane(int H, int W, int C) {
    std::vector<float> plane(static_cast<size_t>(H + 2) * (W + 2) * C, 0.0f);
    for (int y = 0; y < H; ++y)
        for (int x = 0; x < W; ++x)
            for (int c = 0; c < C; ++c) plane[(static_cast<size_t>(y + 1) * (W + 2) + (x + 1)) * C + c] = rnd();
    return plane;
}

double maxAbs(const std::vector<double>& v) {
    double m = 0;
    for (double x : v) m = std::max(m, std::fabs(x));
    return m;
}

bool report(const char* name, double maxErr, double scale) {
    const double tol = 2e-5 * std::max(1.0, scale);
    const bool ok = maxErr <= tol;
    printf("  %-44s max|err|=%.3e (tol %.1e)  %s\n", name, maxErr, tol, ok ? "PASS" : "FAIL");
    return ok;
}

bool checkForward(int cin, int cout, int W, bool relu, bool gated) {
    const int H = 5;
    std::vector<float> in = randomPlane(H, W, cin);
    std::vector<float> w(static_cast<size_t>(9) * cin * cout), bias(cout);
    for (auto& v : w) v = rnd(0.3f);
    for (auto& v : bias) v = rnd(0.5f);
    std::vector<float> gate(static_cast<size_t>(W) * cout);
    for (auto& v : gate) v = rnd();

    double worst = 0, scale = 0;
    for (int y = 0; y < H; ++y) {
        const float* rows[3];
        for (int k = 0; k < 3; ++k) rows[k] = in.data() + static_cast<size_t>(y + k) * (W + 2) * cin;
        std::vector<float> out(static_cast<size_t>(W) * cout, -777.0f);
        if (gated) kernels::convRowGated(rows, cin, w.data(), cout, W, gate.data(), out.data());
        else kernels::convRow(rows, cin, w.data(), bias.data(), cout, W, relu ? kernels::Epilogue::Relu : kernels::Epilogue::None, out.data());

        for (int x = 0; x < W; ++x) {
            for (int co = 0; co < cout; ++co) {
                double ref = gated ? 0.0 : bias[co];
                for (int ki = 0; ki < 3; ++ki)
                    for (int kj = 0; kj < 3; ++kj)
                        for (int ci = 0; ci < cin; ++ci)
                            ref += static_cast<double>(in[(static_cast<size_t>(y + ki) * (W + 2) + (x + kj)) * cin + ci]) *
                                   w[(static_cast<size_t>(ki * 3 + kj) * cin + ci) * cout + co];
                if (relu) ref = std::max(ref, 0.0);
                if (gated && !(gate[static_cast<size_t>(x) * cout + co] > 0.0f)) ref = 0.0;
                worst = std::max(worst, std::fabs(ref - out[static_cast<size_t>(x) * cout + co]));
                scale = std::max(scale, std::fabs(ref));
            }
        }
    }
    char name[96];
    snprintf(name, sizeof name, "%s %2d->%2d W=%-3d", gated ? "gated " : (relu ? "relu  " : "plain "), cin, cout, W);
    return report(name, worst, scale);
}

bool checkWeightGrad(int cin, int cout, int W, int y0, int y1) {
    const int H = 16;
    std::vector<float> in = randomPlane(H, W, cin);
    std::vector<float> dout = randomPlane(H, W, cout);
    std::vector<float> dW(static_cast<size_t>(9) * cin * cout, 0.25f), dB(cout, -0.5f);  // non-zero: must ACCUMULATE
    const std::vector<float> dW0 = dW, dB0 = dB;
    kernels::convWeightGrad(in.data(), cin, dout.data(), cout, W, y0, y1, dW.data(), dB.data());

    std::vector<double> err;
    double scale = 0;
    for (int ki = 0; ki < 3; ++ki)
        for (int kj = 0; kj < 3; ++kj)
            for (int ci = 0; ci < cin; ++ci)
                for (int co = 0; co < cout; ++co) {
                    const size_t idx = (static_cast<size_t>(ki * 3 + kj) * cin + ci) * cout + co;
                    double ref = dW0[idx];
                    for (int y = y0; y < y1; ++y)
                        for (int x = 0; x < W; ++x)
                            ref += static_cast<double>(in[(static_cast<size_t>(y + ki) * (W + 2) + (x + kj)) * cin + ci]) *
                                   dout[(static_cast<size_t>(y + 1) * (W + 2) + (x + 1)) * cout + co];
                    err.push_back(ref - dW[idx]);
                    scale = std::max(scale, std::fabs(ref));
                }
    for (int co = 0; co < cout; ++co) {
        double ref = dB0[co];
        for (int y = y0; y < y1; ++y)
            for (int x = 0; x < W; ++x) ref += dout[(static_cast<size_t>(y + 1) * (W + 2) + (x + 1)) * cout + co];
        err.push_back(ref - dB[co]);
        scale = std::max(scale, std::fabs(ref));
    }
    char name[96];
    snprintf(name, sizeof name, "weightGrad %2d->%2d W=%-3d rows[%d,%d)", cin, cout, W, y0, y1);
    return report(name, maxAbs(err), scale);
}

}  // namespace

int main() {
    printf("SIMD backend under test: %s\n", simd::backendName());
    bool ok = true;

    printf("\n-- forward / backward-data kernels --\n");
    const int widths[] = {64, 70, 13, 4, 3, 1};
    const int shapes[][2] = {{4, 48}, {48, 48}, {48, 4}, {4, 4}, {8, 20}};
    for (const auto& s : shapes)
        for (int W : widths) {
            ok &= checkForward(s[0], s[1], W, false, false);
            ok &= checkForward(s[0], s[1], W, true, false);
        }
    for (int W : {64, 13, 1}) ok &= checkForward(48, 48, W, false, true);

    printf("\n-- weight-gradient kernel --\n");
    for (const auto& s : shapes) {
        ok &= checkWeightGrad(s[0], s[1], 64, 0, 16);
        ok &= checkWeightGrad(s[0], s[1], 13, 3, 12);  // odd row count + odd width
    }

    printf("\n%s\n", ok ? "PASS" : "FAIL");
    return ok ? 0 : 1;
}
