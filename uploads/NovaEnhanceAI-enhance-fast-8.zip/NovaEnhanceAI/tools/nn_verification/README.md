# Neural Network Verification Tools

These are NOT part of the Android build - they're standalone checks used to
verify the from-scratch CNN's math (in `app/src/main/cpp/nn/`) before it's
trusted inside the app. Re-run these if you ever change the architecture or
the forward/backward pass logic.

**`./run_all.sh`** (or `./run_all.sh --quick`) builds and runs everything below
with plain `g++`, once per SIMD flavour (portable, NEON-AArch64 and NEON-ARMv7
through `neon_shim.h`), plus the filter checks in `../filter_verification/`.

The production network is now split across `network.cpp` (front door +
optimizer), `inference.cpp`, `training.cpp`, `conv_kernels.cpp`, `weights.cpp`
and `util/thread_pool.cpp`. The ORIGINAL scalar implementation lives on, unchanged
except for exposing its gradient, as `reference_network.cpp` - the golden
reference the optimized code is held to:

- `kernel_check.cpp` - every convolution kernel shape the network uses
  (4->48, 48->48, 48->4 ...) plus awkward widths, against a naive
  double-precision convolution. 74 cases per flavour.
- `equivalence_check.cpp` - optimized vs. reference: forward pass, loss and
  gradient (batches of 1, 3, 9 across 1/3/all threads, including a batch that
  spans two internal waves), a 25-step Adam + L2-SP + clipping trajectory, and
  whole-image inference (column strips + halos, 20 awkward sizes) against a
  naive whole-image convolution, byte-exact through the 8-bit encode/decode
  rounding. Set `NOVA_NN_THREADS=8` to force a real 8-thread pool even on a
  small CI box. Also meant to be run under `-fsanitize=address,undefined` and
  `-fsanitize=thread` with `--quick` (both are clean).
- `bench.cpp` - micro-benchmark: ms per 64x64-tile-equivalent for whole-image
  inference and ms per batch-4 training step, optionally next to the
  reference (`--with-reference`). Host numbers are a relative indication only.
- `neon_shim.h` - desktop emulation of the NEON intrinsics `simd.h` uses, so the
  NEON code paths compile and run on x86. It follows the ARM ARM semantics
  (fused vs. separately rounded multiply-add, bitwise select ...), and the
  ARMv7 flavour deliberately lacks the AArch64-only intrinsics, so using one by
  mistake fails the build. It validates logic, not real ARM compilation.

The older checks below are unchanged in what they verify. `production_integration_check`
and `lr_saturation_check` include `network.cpp` directly, so their build lines now also list the
other native sources (shown below).

- `numpy_reference_check.py` - the original reference implementation and
  gradient check, in NumPy. Run with `python3 numpy_reference_check.py`.
- `adam_convergence_check.py` - sanity-checks the Adam optimizer formula
  converges on a toy problem. Run with `python3 adam_convergence_check.py`.
- `gradient_check.cpp` - a double-precision C++ reimplementation of the same
  network (same formulas/indexing as `network.cpp`, just `double` instead of
  `float`) with rigorous gradient checking against numerical
  (finite-difference) derivatives. Double precision is used deliberately:
  float32 checking of a network with small gradients runs into catastrophic
  cancellation at a small epsilon, and a larger epsilon risks crossing a
  ReLU/clip "kink" and reporting a false mismatch. Compile and run with:
  ```
  g++ -std=c++17 -O2 -o /tmp/gradient_check gradient_check.cpp
  /tmp/gradient_check
  ```
  Expect all checked gradients to match analytically to within ~1e-5
  relative error ("0 mismatches... PASS").
- `production_integration_check.cpp` - exercises the REAL production
  float32 code (`inferForward`, `trainStep` at full architecture size, not
  a scaled-down test network): output stays in [0,1], loss decreases when
  overfitting one example, and the anti-forgetting anchor measurably
  reduces parameter drift. Compile and run with:
  ```
  CPP=../../app/src/main/cpp
  g++ -std=c++17 -O2 -pthread -I$CPP -I$CPP/nn production_integration_check.cpp \\
      $CPP/nn/inference.cpp $CPP/nn/training.cpp $CPP/nn/conv_kernels.cpp \\
      $CPP/nn/weights.cpp $CPP/util/thread_pool.cpp -o /tmp/prod_check
  /tmp/prod_check
  ```
- `lr_saturation_check.cpp` - a real failure mode this architecture has:
  the clip[0,1] output activation has EXACTLY zero gradient outside that
  range, so a too-high learning rate can saturate the network and get it
  permanently stuck (found empirically, not theoretically - see the
  comment on `clip01BackwardFromPre` in `reference_network.cpp`; the production
  `training.cpp` applies the same mask in `outputBand`). This confirms the
  app's actual configured learning rate (`Constants.DEFAULT_LEARNING_RATE`)
  and its adaptive-controller ceiling both stay safely clear of that
  boundary. Compile and run with:
  ```
  CPP=../../app/src/main/cpp
  g++ -std=c++17 -O2 -pthread -I$CPP -I$CPP/nn lr_saturation_check.cpp \\
      $CPP/nn/inference.cpp $CPP/nn/training.cpp $CPP/nn/conv_kernels.cpp \\
      $CPP/nn/weights.cpp $CPP/util/thread_pool.cpp -o /tmp/lr_check
  /tmp/lr_check
  ```
  Re-run this one specifically if `DEFAULT_LEARNING_RATE` or the adaptive
  controller's boost factor ever change.

None of this requires TensorFlow, Python ML libraries, or a GPU - just a
C++17 compiler and (for the two `.py` scripts) NumPy.
