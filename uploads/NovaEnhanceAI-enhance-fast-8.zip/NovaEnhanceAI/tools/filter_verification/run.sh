#!/usr/bin/env bash
# Builds and runs the bit-exact filter check (see filter_check.cpp). Desktop g++ only.
set -euo pipefail
cd "$(dirname "$0")"
CPP=../../app/src/main/cpp
OUT=$(mktemp -d)
# -ffp-contract=off: compare pure IEEE float arithmetic, not whatever FMA contraction a given compiler picks.
${CXX:-g++} -std=c++17 -O2 -ffp-contract=off -pthread -I$CPP filter_check.cpp reference_convolution.cpp \
    $CPP/filters/convolution.cpp $CPP/util/thread_pool.cpp -o "$OUT/filter_check"
"$OUT/filter_check" "$@"
