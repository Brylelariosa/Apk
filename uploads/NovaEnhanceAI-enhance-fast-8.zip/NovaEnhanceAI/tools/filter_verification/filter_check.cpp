// Bit-exact check of the optimized classical filters (app/src/main/cpp/filters/convolution.cpp)
// against the original implementation (reference_convolution.cpp), over awkward sizes, extreme
// content and a spread of parameters - plus a timing comparison.
//
//   ./run.sh            full
//   ./run.sh --quick    fewer cases
#include "filters/convolution.h"
#include "util/thread_pool.h"

#include <chrono>
#include <cstdio>
#include <cstring>
#include <random>
#include <string>
#include <vector>

namespace novaenhance::reference {
std::vector<int32_t> gaussianBlur(const std::vector<int32_t>&, int, int, float);
std::vector<int32_t> unsharpMask(const std::vector<int32_t>&, int, int, float, float);
std::vector<int32_t> denoiseBilateral(const std::vector<int32_t>&, int, int, float, float);
}  // namespace novaenhance::reference

namespace {

std::mt19937 rng(99);
bool g_ok = true;
int g_cases = 0;

std::vector<int32_t> makeImage(int w, int h, int kind) {
    std::vector<int32_t> px(static_cast<size_t>(w) * h);
    for (int y = 0; y < h; ++y)
        for (int x = 0; x < w; ++x) {
            uint32_t r, g, b, a = 0xFF;
            switch (kind) {
                case 0: r = rng() & 255; g = rng() & 255; b = rng() & 255; a = rng() & 255; break;   // noise, random alpha
                case 1: r = g = b = 255; break;                                                       // all white (alpha-254 corner case)
                case 2: r = g = b = 0; break;                                                         // all black
                case 3: r = (x * 255) / std::max(1, w - 1); g = (y * 255) / std::max(1, h - 1); b = 128; break;  // gradient
                default: r = ((x / 3 + y / 3) & 1) ? 240 : 15; g = r; b = r; break;                  // checker: hard edges
            }
            px[static_cast<size_t>(y) * w + x] = static_cast<int32_t>((a << 24) | (r << 16) | (g << 8) | b);
        }
    return px;
}

void expectEqual(const char* what, int w, int h, int kind, const std::vector<int32_t>& a, const std::vector<int32_t>& b) {
    ++g_cases;
    if (a.size() == b.size() && std::memcmp(a.data(), b.data(), a.size() * sizeof(int32_t)) == 0) return;
    g_ok = false;
    size_t bad = 0, first = 0;
    for (size_t i = 0; i < a.size() && i < b.size(); ++i)
        if (a[i] != b[i]) { if (bad++ == 0) first = i; }
    printf("  [FAIL] %s %dx%d kind=%d: %zu differing pixels (first at %zu: %08x vs %08x)\n", what, w, h, kind, bad, first,
           static_cast<uint32_t>(a[first]), static_cast<uint32_t>(b[first]));
}

double ms() {
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

}  // namespace

int main(int argc, char** argv) {
    const bool quick = argc > 1 && std::strcmp(argv[1], "--quick") == 0;
    printf("pool threads: %d%s\n", novaenhance::ThreadPool::instance().maxThreads(), quick ? " (quick)" : "");

    struct Size { int w, h; };
    std::vector<Size> sizes = {{1, 1}, {2, 3}, {5, 1}, {1, 9}, {17, 5}, {64, 64}, {130, 97}, {301, 77}};
    if (quick) sizes = {{1, 1}, {17, 5}, {130, 97}};
    // >= 96*96 px so the row-parallel path (not the small-image serial shortcut) is exercised.
    sizes.push_back({200, 131});

    for (const Size& s : sizes) {
        for (int kind = 0; kind < 5; ++kind) {
            const auto img = makeImage(s.w, s.h, kind);
            for (float sigma : {0.5f, 1.0f, 1.2f, 2.5f}) {
                expectEqual("gaussianBlur", s.w, s.h, kind, novaenhance::gaussianBlur(img, s.w, s.h, sigma),
                            novaenhance::reference::gaussianBlur(img, s.w, s.h, sigma));
                for (float amount : {0.3f, 1.0f, 2.0f})
                    expectEqual("unsharpMask", s.w, s.h, kind, novaenhance::unsharpMask(img, s.w, s.h, sigma, amount),
                                novaenhance::reference::unsharpMask(img, s.w, s.h, sigma, amount));
            }
            for (float range : {10.0f, 22.0f, 50.0f})
                expectEqual("denoiseBilateral", s.w, s.h, kind, novaenhance::denoiseBilateral(img, s.w, s.h, 1.5f, range),
                            novaenhance::reference::denoiseBilateral(img, s.w, s.h, 1.5f, range));
        }
    }
    // sigma <= 0 paths
    const auto img = makeImage(33, 21, 0);
    expectEqual("gaussianBlur(sigma=0)", 33, 21, 0, novaenhance::gaussianBlur(img, 33, 21, 0.0f), novaenhance::reference::gaussianBlur(img, 33, 21, 0.0f));
    expectEqual("unsharpMask(sigma=0)", 33, 21, 0, novaenhance::unsharpMask(img, 33, 21, 0.0f, 1.0f), novaenhance::reference::unsharpMask(img, 33, 21, 0.0f, 1.0f));
    expectEqual("empty", 0, 0, 0, novaenhance::denoiseBilateral({}, 0, 0, 1.5f, 20.f), novaenhance::reference::denoiseBilateral({}, 0, 0, 1.5f, 20.f));

    printf("%d comparisons, %s\n", g_cases, g_ok ? "all bit-identical" : "MISMATCHES FOUND");

    // ---- timing (1024x768, the parameters EnhancementEngine uses by default)
    const int W = 1024, H = 768;
    const auto big = makeImage(W, H, 0);
    auto time = [&](const char* name, auto&& refFn, auto&& newFn) {
        const double t0 = ms(); refFn(); const double t1 = ms(); newFn(); const double t2 = ms();
        printf("  %-18s original %8.1f ms   new %8.1f ms   (%.1fx)\n", name, t1 - t0, t2 - t1, (t1 - t0) / (t2 - t1));
    };
    printf("timing on %dx%d (this host, %d pool thread(s)):\n", W, H, novaenhance::ThreadPool::instance().maxThreads());
    time("denoiseBilateral", [&] { novaenhance::reference::denoiseBilateral(big, W, H, 1.5f, 22.0f); },
         [&] { novaenhance::denoiseBilateral(big, W, H, 1.5f, 22.0f); });
    time("unsharpMask s=1.0", [&] { novaenhance::reference::unsharpMask(big, W, H, 1.0f, 0.5f); },
         [&] { novaenhance::unsharpMask(big, W, H, 1.0f, 0.5f); });
    return g_ok ? 0 : 1;
}
