package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ComputeBudgetTest {

    @Test
    fun `an 8-core phone like the Infinix HOT 11 2022 uses every core to enhance and six to train`() {
        assertEquals(8, ComputeBudget.enhancementThreads(8))
        assertEquals(6, ComputeBudget.trainingThreads(8))
    }

    @Test
    fun `thread counts never exceed the native pool cap`() {
        assertEquals(ComputeBudget.MAX_NATIVE_THREADS, ComputeBudget.enhancementThreads(16))
        assertEquals(ComputeBudget.MAX_NATIVE_THREADS, ComputeBudget.trainingThreads(64))
    }

    @Test
    fun `small and degenerate core counts still get at least one thread`() {
        for (cores in listOf(-1, 0, 1, 2, 3)) {
            assertTrue("enhance @ $cores cores", ComputeBudget.enhancementThreads(cores) >= 1)
            assertTrue("train @ $cores cores", ComputeBudget.trainingThreads(cores) >= 1)
        }
        assertEquals(1, ComputeBudget.trainingThreads(2))
    }

    @Test
    fun `training always leaves cores free whenever the phone has more than a few`() {
        for (cores in 4..8) {
            assertTrue(ComputeBudget.trainingThreads(cores) < ComputeBudget.enhancementThreads(cores))
        }
    }
}
