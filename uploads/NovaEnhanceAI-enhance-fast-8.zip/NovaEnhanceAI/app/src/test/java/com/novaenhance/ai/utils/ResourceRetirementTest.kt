package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceRetirementTest {

    /** A data class on purpose: two EQUAL instances must still be tracked as two separate resources. */
    private data class Res(val name: String)

    private val disposed = mutableListOf<Res>()
    private val retirement = ResourceRetirement<Res>(dispose = { disposed += it })

    @Test
    fun `an unheld resource is disposed as soon as it is retired`() {
        val a = Res("a")
        retirement.retire(a)
        assertEquals(1, disposed.size)
        assertSame(a, disposed[0])
    }

    @Test
    fun `a held resource waits for its last release after being retired`() {
        // The slider-at-completion shape: the result is replaced (retired) while the UI still shows it.
        val a = Res("a")
        retirement.hold(a)
        retirement.retire(a)
        assertTrue(disposed.isEmpty())
        retirement.release(a)
        assertEquals(1, disposed.size)
        assertSame(a, disposed[0])
    }

    @Test
    fun `holds are counted - the first release does not free a resource a second holder still uses`() {
        // Two overlapping enhancement runs reading the same original.
        val a = Res("a")
        retirement.hold(a)
        retirement.hold(a)
        retirement.retire(a)
        retirement.release(a)
        assertTrue(disposed.isEmpty())
        retirement.release(a)
        assertEquals(1, disposed.size)
    }

    @Test
    fun `a resource that was never retired is not disposed when its holds end`() {
        // Still the current value in the UI state: the slider letting go of it must not free it.
        val a = Res("a")
        retirement.hold(a)
        retirement.release(a)
        assertTrue(disposed.isEmpty())
        retirement.retire(a)
        assertEquals(1, disposed.size)
    }

    @Test
    fun `retiring the same held resource twice still disposes it only once`() {
        val a = Res("a")
        retirement.hold(a)
        retirement.retire(a)
        retirement.retire(a)
        retirement.release(a)
        assertEquals(1, disposed.size)
    }

    @Test
    fun `an extra release does not dispose a resource that was never retired or hold-counted`() {
        val a = Res("a")
        retirement.release(a)
        assertTrue(disposed.isEmpty())
        // ...and a stray release must not leave a negative count that blocks or breaks a later hold.
        retirement.hold(a)
        retirement.retire(a)
        assertTrue(disposed.isEmpty())
        retirement.release(a)
        assertEquals(1, disposed.size)
    }

    @Test
    fun `identity decides which resource is meant, not equals`() {
        val first = Res("same")
        val second = Res("same")
        retirement.hold(first)

        retirement.retire(second) // equal to first, but a different instance and nothing holds it
        assertEquals(1, disposed.size)
        assertSame(second, disposed[0])

        retirement.retire(first) // held -> deferred
        assertEquals(1, disposed.size)
        retirement.release(first)
        assertEquals(2, disposed.size)
        assertSame(first, disposed[1])
    }

    @Test
    fun `retiring null does nothing`() {
        retirement.retire(null)
        assertTrue(disposed.isEmpty())
    }

    @Test
    fun `withHold keeps a retired resource alive until the block ends and returns the block's result`() {
        val a = Res("a")
        val result = retirement.withHold(a) {
            retirement.retire(a)
            assertTrue("must not be disposed while the block still runs", disposed.isEmpty())
            42
        }
        assertEquals(42, result)
        assertEquals(1, disposed.size)
    }

    @Test
    fun `withHold releases even when the block throws`() {
        val a = Res("a")
        val outcome = runCatching {
            retirement.withHold(a) {
                retirement.retire(a)
                error("boom")
            }
        }
        assertTrue(outcome.exceptionOrNull() is IllegalStateException)
        assertEquals(1, disposed.size)
    }

    @Test
    fun `lifecycle messages are logged for deferred and last-release disposal`() {
        val lines = mutableListOf<String>()
        val logged = ResourceRetirement<Res>(
            dispose = { },
            log = { lines += it },
            label = { it.name }
        )
        val a = Res("a")
        logged.hold(a)
        logged.retire(a)
        logged.release(a)
        assertEquals(listOf("retire a: deferred, hold count 1", "disposed a on last release"), lines)
    }
}
