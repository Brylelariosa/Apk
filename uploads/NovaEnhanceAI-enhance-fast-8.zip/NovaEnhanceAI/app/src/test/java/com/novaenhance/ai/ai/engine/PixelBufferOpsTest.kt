package com.novaenhance.ai.ai.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertSame
import org.junit.Test

class PixelBufferOpsTest {

    @Test
    fun `padByReplication returns same reference when already target size`() {
        val pixels = IntArray(16) { it }
        val result = PixelBufferOps.padByReplication(pixels, 4, 4, 4)
        assertSame("no-op path should avoid allocating a new array", pixels, result)
    }

    @Test
    fun `padByReplication replicates edge pixels into the padded region`() {
        // 2x2 source: [ [1,2], [3,4] ], padded to 4x4 should replicate the
        // last row/column outward rather than leaving zeros.
        val pixels = intArrayOf(1, 2, 3, 4)
        val padded = PixelBufferOps.padByReplication(pixels, 2, 2, 4)

        assertEquals(16, padded.size)
        // Row 0: 1,2,2,2 ; Row 1: 3,4,4,4 ; Row 2 and 3 replicate row 1.
        assertArrayEquals(
            intArrayOf(
                1, 2, 2, 2,
                3, 4, 4, 4,
                3, 4, 4, 4,
                3, 4, 4, 4
            ),
            padded
        )
    }

    @Test
    fun `cropTopLeft returns same reference when already requested size`() {
        val pixels = IntArray(9) { it }
        val result = PixelBufferOps.cropTopLeft(pixels, 3, 3, 3)
        assertSame(pixels, result)
    }

    @Test
    fun `cropTopLeft extracts the top-left region correctly`() {
        // 4x4 source, crop to top-left 2x2.
        val pixels = intArrayOf(
            1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 11, 12,
            13, 14, 15, 16
        )
        val cropped = PixelBufferOps.cropTopLeft(pixels, 4, 2, 2)
        assertArrayEquals(intArrayOf(1, 2, 5, 6), cropped)
    }

    @Test
    fun `pad then crop round-trips the original content for the valid region`() {
        val original = intArrayOf(10, 20, 30, 40, 50, 60) // 3x2
        val padded = PixelBufferOps.padByReplication(original, 3, 2, 6)
        val cropped = PixelBufferOps.cropTopLeft(padded, 6, 3, 2)
        assertArrayEquals(original, cropped)
    }

    @Test
    fun `cropRect copies the requested rectangle`() {
        // 6 wide x 4 tall, values 0..23 row-major.
        val pixels = IntArray(24) { it }
        val crop = PixelBufferOps.cropRect(pixels, srcW = 6, x = 2, y = 1, w = 3, h = 2)
        assertArrayEquals(intArrayOf(8, 9, 10, 14, 15, 16), crop)
    }

    @Test
    fun `transformSquare orientation 0 is the identity and returns the same reference`() {
        val pixels = IntArray(9) { it }
        assertSame(pixels, PixelBufferOps.transformSquare(pixels, 3, 0))
    }

    @Test
    fun `transformSquare orientation 1 rotates a 2x2 tile a quarter turn clockwise`() {
        // [ [1,2], [3,4] ]  --90 degrees clockwise-->  [ [3,1], [4,2] ]
        assertArrayEquals(intArrayOf(3, 1, 4, 2), PixelBufferOps.transformSquare(intArrayOf(1, 2, 3, 4), 2, 1))
    }

    @Test
    fun `transformSquare orientation 4 mirrors left to right`() {
        assertArrayEquals(intArrayOf(2, 1, 4, 3), PixelBufferOps.transformSquare(intArrayOf(1, 2, 3, 4), 2, 4))
    }

    @Test
    fun `transformSquare gives eight distinct permutations of an asymmetric tile`() {
        val size = 5
        val tile = IntArray(size * size) { (it / size) * 10 + it % size } // every value unique
        val results = (0..7).map { PixelBufferOps.transformSquare(tile, size, it).toList() }
        assertEquals("all eight symmetries must differ", 8, results.toSet().size)
        results.forEach { assertEquals(tile.sorted(), it.sorted()) } // each is a pure rearrangement
    }

    @Test
    fun `four quarter turns return the original tile`() {
        val size = 4
        val tile = IntArray(size * size) { it * 7 }
        var turned = tile
        repeat(4) { turned = PixelBufferOps.transformSquare(turned, size, 1) }
        assertArrayEquals(tile, turned)
    }

    @Test
    fun `the same orientation keeps a degraded and a clean tile pixel-aligned`() {
        val size = 5
        val clean = IntArray(size * size) { it }
        val degraded = IntArray(size * size) { clean[it] + 1000 } // fixed offset at every position
        for (orientation in 0..7) {
            val c = PixelBufferOps.transformSquare(clean, size, orientation)
            val d = PixelBufferOps.transformSquare(degraded, size, orientation)
            for (i in c.indices) assertEquals("orientation $orientation, index $i", 1000, d[i] - c[i])
        }
    }

    @Test
    fun `distinct orientations of an asymmetric tile are not equal`() {
        val tile = intArrayOf(1, 2, 3, 4)
        assertNotEquals(PixelBufferOps.transformSquare(tile, 2, 1).toList(), PixelBufferOps.transformSquare(tile, 2, 3).toList())
    }
}
