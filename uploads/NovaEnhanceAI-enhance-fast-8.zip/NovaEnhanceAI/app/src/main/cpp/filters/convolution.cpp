#include "convolution.h"

#include <algorithm>
#include <cmath>
#include <functional>

#include "util/thread_pool.h"

namespace novaenhance {

namespace {

inline uint8_t channel(int32_t pixel, int shift) {
    return static_cast<uint8_t>((pixel >> shift) & 0xFF);
}

inline int32_t packArgb(int a, int r, int g, int b) {
    auto clamp8 = [](int v) { return std::min(255, std::max(0, v)); };
    return (clamp8(a) << 24) | (clamp8(r) << 16) | (clamp8(g) << 8) | clamp8(b);
}

inline int clampi(int v, int lo, int hi) { return std::min(hi, std::max(lo, v)); }

// Builds a normalized 1D Gaussian kernel for the given sigma.
std::vector<float> makeGaussianKernel(float sigma, int& radiusOut) {
    int radius = std::max(1, static_cast<int>(std::ceil(sigma * 3.0f)));
    radiusOut = radius;
    std::vector<float> kernel(2 * radius + 1);
    float sum = 0.0f;
    float twoSigmaSq = 2.0f * sigma * sigma;
    for (int i = -radius; i <= radius; ++i) {
        float v = std::exp(-(i * i) / twoSigmaSq);
        kernel[i + radius] = v;
        sum += v;
    }
    for (float& v : kernel) v /= sum;
    return kernel;
}

// ----------------------------------------------------------------------------
// Row-parallel execution. Every filter below is "output row = f(a few input rows)",
// so rows can be handed to the shared thread pool with no synchronisation beyond
// the barrier between dependent passes, and the result is identical to the serial
// order. Small images skip the pool: waking threads costs more than the work.
// ----------------------------------------------------------------------------
constexpr int kRowsPerJob = 16;
constexpr int64_t kMinPixelsForThreads = 96 * 96;

template <typename RowFn>
void forEachRowBlock(int width, int height, RowFn&& fn) {
    if (static_cast<int64_t>(width) * height < kMinPixelsForThreads) {
        fn(0, height);
        return;
    }
    const int jobs = (height + kRowsPerJob - 1) / kRowsPerJob;
    const std::function<void(int, int)> job = [&](int j, int /*worker*/) {
        fn(j * kRowsPerJob, std::min(height, (j + 1) * kRowsPerJob));
    };
    ThreadPool::instance().parallelFor(jobs, /*threads=*/0, job);
}

// Separable convolution pass along one axis (0 = horizontal, 1 = vertical).
//
// Same arithmetic, in the same order, as the original per-pixel version (taps accumulate from -radius
// to +radius), so results are identical - the gains are structural: no clamp() per tap away from the
// image edge, the vertical taps become 2*radius+1 row pointers resolved once per row instead of once
// per pixel, and rows run in parallel. `WithAlpha` = false skips the alpha accumulator for callers that
// never read the blurred alpha (unsharp mask); the alpha byte of such a result is 0 and meaningless.
template <bool WithAlpha>
void convolveRows(const int32_t* src, int32_t* dst, int width, int height, const std::vector<float>& kernel,
                  int radius, int axis, int y0, int y1) {
    const int taps = 2 * radius + 1;
    std::vector<const int32_t*> rows(static_cast<size_t>(taps));
    for (int y = y0; y < y1; ++y) {
        int32_t* out = dst + static_cast<size_t>(y) * width;
        if (axis == 0) {
            const int32_t* row = src + static_cast<size_t>(y) * width;
            for (int x = 0; x < width; ++x) {
                float a = 0, r = 0, g = 0, b = 0;
                if (x >= radius && x + radius < width) {
                    const int32_t* p = row + (x - radius);
                    for (int k = 0; k < taps; ++k) {
                        const int32_t px = p[k];
                        const float w = kernel[k];
                        if (WithAlpha) a += w * channel(px, 24);
                        r += w * channel(px, 16);
                        g += w * channel(px, 8);
                        b += w * channel(px, 0);
                    }
                } else {
                    for (int k = -radius; k <= radius; ++k) {
                        const int32_t px = row[clampi(x + k, 0, width - 1)];
                        const float w = kernel[k + radius];
                        if (WithAlpha) a += w * channel(px, 24);
                        r += w * channel(px, 16);
                        g += w * channel(px, 8);
                        b += w * channel(px, 0);
                    }
                }
                out[x] = packArgb(static_cast<int>(a), static_cast<int>(r), static_cast<int>(g), static_cast<int>(b));
            }
        } else {
            for (int k = 0; k < taps; ++k) {
                rows[static_cast<size_t>(k)] = src + static_cast<size_t>(clampi(y + k - radius, 0, height - 1)) * width;
            }
            for (int x = 0; x < width; ++x) {
                float a = 0, r = 0, g = 0, b = 0;
                for (int k = 0; k < taps; ++k) {
                    const int32_t px = rows[static_cast<size_t>(k)][x];
                    const float w = kernel[k];
                    if (WithAlpha) a += w * channel(px, 24);
                    r += w * channel(px, 16);
                    g += w * channel(px, 8);
                    b += w * channel(px, 0);
                }
                out[x] = packArgb(static_cast<int>(a), static_cast<int>(r), static_cast<int>(g), static_cast<int>(b));
            }
        }
    }
}

template <bool WithAlpha>
std::vector<int32_t> gaussianBlurImpl(const std::vector<int32_t>& pixels, int width, int height, float sigma) {
    int radius;
    const auto kernel = makeGaussianKernel(sigma, radius);
    std::vector<int32_t> horizontal(pixels.size());
    std::vector<int32_t> result(pixels.size());
    forEachRowBlock(width, height, [&](int y0, int y1) {
        convolveRows<WithAlpha>(pixels.data(), horizontal.data(), width, height, kernel, radius, 0, y0, y1);
    });
    forEachRowBlock(width, height, [&](int y0, int y1) {
        convolveRows<WithAlpha>(horizontal.data(), result.data(), width, height, kernel, radius, 1, y0, y1);
    });
    return result;
}

}  // namespace

std::vector<int32_t> gaussianBlur(const std::vector<int32_t>& pixels,
                                   int width, int height, float sigma) {
    if (sigma <= 0.0f || pixels.empty()) return pixels;
    return gaussianBlurImpl<true>(pixels, width, height, sigma);
}

std::vector<int32_t> unsharpMask(const std::vector<int32_t>& pixels,
                                  int width, int height,
                                  float sigma, float amount) {
    if (pixels.empty()) return pixels;
    // sigma <= 0 means "no blur": the blurred image IS the input (same as gaussianBlur's early return).
    const std::vector<int32_t> blurred =
        sigma <= 0.0f ? pixels : gaussianBlurImpl<false>(pixels, width, height, sigma);
    std::vector<int32_t> out(pixels.size());
    forEachRowBlock(width, height, [&](int y0, int y1) {
        const size_t begin = static_cast<size_t>(y0) * width;
        const size_t end = static_cast<size_t>(y1) * width;
        for (size_t i = begin; i < end; ++i) {
            int32_t orig = pixels[i];
            int32_t blur = blurred[i];
            int a = channel(orig, 24);
            int r = channel(orig, 16) + static_cast<int>(amount * (channel(orig, 16) - channel(blur, 16)));
            int g = channel(orig, 8) + static_cast<int>(amount * (channel(orig, 8) - channel(blur, 8)));
            int b = channel(orig, 0) + static_cast<int>(amount * (channel(orig, 0) - channel(blur, 0)));
            out[i] = packArgb(a, r, g, b);
        }
    });
    return out;
}

std::vector<int32_t> denoiseBilateral(const std::vector<int32_t>& pixels,
                                       int width, int height,
                                       float spatialSigma, float rangeSigma) {
    if (pixels.empty()) return pixels;
    const int radius = 2;  // 5x5 window keeps this affordable on a 256x256 tile.
    constexpr int kSide = 2 * radius + 1;
    float spatialTwoSigmaSq = 2.0f * spatialSigma * spatialSigma;
    float rangeTwoSigmaSq = 2.0f * rangeSigma * rangeSigma;

    // The original evaluated two exp() calls per tap (50 per pixel). Both weights only ever take a
    // handful of distinct values, so they are tabulated once with the SAME expressions - the table
    // entries are bit-identical to what the per-tap calls produced:
    //   * spatial weight: depends only on the tap offset (25 values)
    //   * range weight:   depends only on the integer luma difference, -255..255 (511 values)
    float spatialW[kSide][kSide];
    for (int ky = -radius; ky <= radius; ++ky) {
        for (int kx = -radius; kx <= radius; ++kx) {
            spatialW[ky + radius][kx + radius] = std::exp(-(kx * kx + ky * ky) / spatialTwoSigmaSq);
        }
    }
    std::vector<float> rangeW(511);
    for (int d = -255; d <= 255; ++d) {
        float rangeDiff = static_cast<float>(d);
        rangeW[static_cast<size_t>(d + 255)] = std::exp(-(rangeDiff * rangeDiff) / rangeTwoSigmaSq);
    }

    // Luma once per pixel instead of once per pixel per tap (25x).
    std::vector<uint8_t> luma(pixels.size());
    for (size_t i = 0; i < pixels.size(); ++i) {
        const int32_t p = pixels[i];
        luma[i] = static_cast<uint8_t>((channel(p, 16) * 299 + channel(p, 8) * 587 + channel(p, 0) * 114) / 1000);
    }

    // Clamp-to-edge column lookup: neighbour column of (x, kx) is xc[x + kx + radius].
    std::vector<int> xc(static_cast<size_t>(width) + 2 * radius);
    for (int i = 0; i < width + 2 * radius; ++i) xc[static_cast<size_t>(i)] = clampi(i - radius, 0, width - 1);

    std::vector<int32_t> out(pixels.size());
    forEachRowBlock(width, height, [&](int y0, int y1) {
        for (int y = y0; y < y1; ++y) {
            const int32_t* prow[kSide];
            const uint8_t* lrow[kSide];
            for (int ky = 0; ky < kSide; ++ky) {
                const size_t rowStart = static_cast<size_t>(clampi(y + ky - radius, 0, height - 1)) * width;
                prow[ky] = pixels.data() + rowStart;
                lrow[ky] = luma.data() + rowStart;
            }
            for (int x = 0; x < width; ++x) {
                const int32_t centerPixel = pixels[static_cast<size_t>(y) * width + x];
                const int centerLuma = luma[static_cast<size_t>(y) * width + x];
                const float* rangeRow = rangeW.data() + (255 - centerLuma);

                float wr = 0, wg = 0, wb = 0, wsum = 0;
                for (int ky = 0; ky < kSide; ++ky) {
                    for (int kx = 0; kx < kSide; ++kx) {
                        const int sx = xc[static_cast<size_t>(x + kx)];
                        const int32_t p = prow[ky][sx];
                        float w = spatialW[ky][kx] * rangeRow[lrow[ky][sx]];

                        wr += w * channel(p, 16);
                        wg += w * channel(p, 8);
                        wb += w * channel(p, 0);
                        wsum += w;
                    }
                }
                int a = channel(centerPixel, 24);
                out[static_cast<size_t>(y) * width + x] = packArgb(
                    a, static_cast<int>(wr / wsum), static_cast<int>(wg / wsum), static_cast<int>(wb / wsum));
            }
        }
    });
    return out;
}

std::vector<int32_t> resizeBilinear(const std::vector<int32_t>& pixels,
                                     int srcWidth, int srcHeight,
                                     int dstWidth, int dstHeight) {
    std::vector<int32_t> out(static_cast<size_t>(dstWidth) * dstHeight);
    if (pixels.empty() || srcWidth <= 0 || srcHeight <= 0) return out;

    float xRatio = static_cast<float>(srcWidth) / dstWidth;
    float yRatio = static_cast<float>(srcHeight) / dstHeight;

    for (int dy = 0; dy < dstHeight; ++dy) {
        float sy = (dy + 0.5f) * yRatio - 0.5f;
        int y0 = clampi(static_cast<int>(std::floor(sy)), 0, srcHeight - 1);
        int y1 = clampi(y0 + 1, 0, srcHeight - 1);
        float fy = sy - std::floor(sy);

        for (int dx = 0; dx < dstWidth; ++dx) {
            float sx = (dx + 0.5f) * xRatio - 0.5f;
            int x0 = clampi(static_cast<int>(std::floor(sx)), 0, srcWidth - 1);
            int x1 = clampi(x0 + 1, 0, srcWidth - 1);
            float fx = sx - std::floor(sx);

            int32_t p00 = pixels[y0 * srcWidth + x0];
            int32_t p10 = pixels[y0 * srcWidth + x1];
            int32_t p01 = pixels[y1 * srcWidth + x0];
            int32_t p11 = pixels[y1 * srcWidth + x1];

            auto lerpChannel = [&](int shift) {
                float top = channel(p00, shift) * (1 - fx) + channel(p10, shift) * fx;
                float bottom = channel(p01, shift) * (1 - fx) + channel(p11, shift) * fx;
                return top * (1 - fy) + bottom * fy;
            };

            out[dy * dstWidth + dx] = packArgb(
                static_cast<int>(lerpChannel(24)), static_cast<int>(lerpChannel(16)),
                static_cast<int>(lerpChannel(8)), static_cast<int>(lerpChannel(0)));
        }
    }
    return out;
}

float quickSimilarityScore(const std::vector<int32_t>& a,
                            const std::vector<int32_t>& b,
                            int width, int height) {
    if (a.empty() || b.empty() || a.size() != b.size()) return 0.0f;
    double sumAbsDiff = 0.0;
    size_t n = static_cast<size_t>(width) * height;
    for (size_t i = 0; i < n; ++i) {
        int lumaA = (channel(a[i], 16) * 299 + channel(a[i], 8) * 587 + channel(a[i], 0) * 114) / 1000;
        int lumaB = (channel(b[i], 16) * 299 + channel(b[i], 8) * 587 + channel(b[i], 0) * 114) / 1000;
        sumAbsDiff += std::abs(lumaA - lumaB);
    }
    double meanAbsDiff = sumAbsDiff / static_cast<double>(n);
    // Normalize: 0 diff -> score 1.0, 255 diff (max possible) -> score 0.0.
    return static_cast<float>(1.0 - (meanAbsDiff / 255.0));
}

}  // namespace novaenhance
