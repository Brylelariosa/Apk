#ifndef NOVAENHANCE_INFERENCE_H
#define NOVAENHANCE_INFERENCE_H

#include <cstdint>

namespace novaenhance::nn {

/**
 * Runs the network over an ARGB_8888 image of ANY size in one call and writes
 * the enhanced ARGB_8888 result (alpha forced to 0xFF, exactly like the old
 * per-tile Kotlin decode).
 *
 * The result equals running the network as ONE fully-convolutional pass over
 * the whole image: zero padding applies only at the true image border (where
 * training's tile borders behave the same way), never at internal boundaries.
 * That is what removes the tile-seam artifacts the previous 64x64 tile + feather
 * blend produced - and it is also cheaper than tiling, because rows are
 * streamed through all four layers once (see inference.cpp) instead of being
 * recomputed for every overlapping tile.
 *
 * Work is split into vertical column strips that run in parallel on the shared
 * thread pool. `threads <= 0` means "all pool threads". Safe to call from any
 * thread; `argb` and `out` must not alias.
 */
void inferRegion(const uint32_t* argb, int width, int height, const float* params, uint32_t* out, int threads);

/**
 * Same network, float RGB in/out ([0,1], width*height*3 floats each), on the
 * calling thread only. Backs inferForward() and the verification tools.
 */
void inferFloatImage(const float* rgb, int width, int height, const float* params, float* out);

}  // namespace novaenhance::nn

#endif  // NOVAENHANCE_INFERENCE_H
