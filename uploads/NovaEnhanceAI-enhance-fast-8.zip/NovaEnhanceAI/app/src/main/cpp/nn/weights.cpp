#include "weights.h"

#include <algorithm>

namespace novaenhance::nn {

namespace {

constexpr int kTaps = KERNEL * KERNEL;  // 9

/** src [9][srcCin][srcCout] -> dst [9][dstCin][dstCout], zero-filling the padding. */
void repackPadded(const float* src, int srcCin, int srcCout, std::vector<float>& dst, int dstCin, int dstCout) {
    dst.assign(static_cast<size_t>(kTaps) * dstCin * dstCout, 0.0f);
    for (int tap = 0; tap < kTaps; ++tap)
        for (int ci = 0; ci < srcCin; ++ci)
            for (int co = 0; co < srcCout; ++co)
                dst[(static_cast<size_t>(tap) * dstCin + ci) * dstCout + co] =
                    src[(static_cast<size_t>(tap) * srcCin + ci) * srcCout + co];
}

/** wt[ki'][kj'][co][ci] = w[2-ki'][2-kj'][ci][co]; the flipped tap index is simply 8 - tap. */
void transposeFlip(const std::vector<float>& w, int cin, int cout, std::vector<float>& wt) {
    wt.assign(static_cast<size_t>(kTaps) * cout * cin, 0.0f);
    for (int tap = 0; tap < kTaps; ++tap) {
        const int flipped = kTaps - 1 - tap;
        for (int ci = 0; ci < cin; ++ci)
            for (int co = 0; co < cout; ++co)
                wt[(static_cast<size_t>(tap) * cout + co) * cin + ci] =
                    w[(static_cast<size_t>(flipped) * cin + ci) * cout + co];
    }
}

void padBias(const float* src, int count, std::vector<float>& dst, int paddedCount) {
    dst.assign(static_cast<size_t>(paddedCount), 0.0f);
    std::copy(src, src + count, dst.begin());
}

}  // namespace

void PackedWeights::pack(const float* params, bool withBackward) {
    repackPadded(params + W1_OFFSET, CIN, C1, w1, PADDED_IMAGE_CHANNELS, C1);
    padBias(params + B1_OFFSET, B1_SIZE, b1, C1);

    w2.assign(params + W2_OFFSET, params + W2_OFFSET + W2_SIZE);
    padBias(params + B2_OFFSET, B2_SIZE, b2, C1);

    w3.assign(params + W3_OFFSET, params + W3_OFFSET + W3_SIZE);
    padBias(params + B3_OFFSET, B3_SIZE, b3, C2);

    repackPadded(params + W4_OFFSET, C2, COUT, w4, C2, PADDED_IMAGE_CHANNELS);
    padBias(params + B4_OFFSET, B4_SIZE, b4, PADDED_IMAGE_CHANNELS);

    if (withBackward) {
        transposeFlip(w2, C1, C1, w2t);
        transposeFlip(w3, C1, C2, w3t);
        transposeFlip(w4, C2, PADDED_IMAGE_CHANNELS, w4t);
    }
}

GradientAccumulator::GradientAccumulator() {
    w1.assign(static_cast<size_t>(kTaps) * PADDED_IMAGE_CHANNELS * C1, 0.0f);
    b1.assign(C1, 0.0f);
    w2.assign(static_cast<size_t>(kTaps) * C1 * C1, 0.0f);
    b2.assign(C1, 0.0f);
    w3.assign(static_cast<size_t>(kTaps) * C1 * C2, 0.0f);
    b3.assign(C2, 0.0f);
    w4.assign(static_cast<size_t>(kTaps) * C2 * PADDED_IMAGE_CHANNELS, 0.0f);
    b4.assign(PADDED_IMAGE_CHANNELS, 0.0f);
}

void GradientAccumulator::clear() {
    for (auto* v : {&w1, &b1, &w2, &b2, &w3, &b3, &w4, &b4}) std::fill(v->begin(), v->end(), 0.0f);
}

void GradientAccumulator::add(const GradientAccumulator& other) {
    auto accumulate = [](std::vector<float>& dst, const std::vector<float>& src) {
        for (size_t i = 0; i < dst.size(); ++i) dst[i] += src[i];
    };
    accumulate(w1, other.w1); accumulate(b1, other.b1);
    accumulate(w2, other.w2); accumulate(b2, other.b2);
    accumulate(w3, other.w3); accumulate(b3, other.b3);
    accumulate(w4, other.w4); accumulate(b4, other.b4);
}

void GradientAccumulator::toFlat(float* flat) const {
    // Layer 1: drop the padded input channel.
    for (int tap = 0; tap < kTaps; ++tap)
        for (int ci = 0; ci < CIN; ++ci)
            for (int co = 0; co < C1; ++co)
                flat[W1_OFFSET + (tap * CIN + ci) * C1 + co] =
                    w1[(static_cast<size_t>(tap) * PADDED_IMAGE_CHANNELS + ci) * C1 + co];
    std::copy(b1.begin(), b1.begin() + B1_SIZE, flat + B1_OFFSET);

    std::copy(w2.begin(), w2.end(), flat + W2_OFFSET);
    std::copy(b2.begin(), b2.begin() + B2_SIZE, flat + B2_OFFSET);
    std::copy(w3.begin(), w3.end(), flat + W3_OFFSET);
    std::copy(b3.begin(), b3.begin() + B3_SIZE, flat + B3_OFFSET);

    // Layer 4: drop the padded output channel.
    for (int tap = 0; tap < kTaps; ++tap)
        for (int ci = 0; ci < C2; ++ci)
            for (int co = 0; co < COUT; ++co)
                flat[W4_OFFSET + (tap * C2 + ci) * COUT + co] =
                    w4[(static_cast<size_t>(tap) * C2 + ci) * PADDED_IMAGE_CHANNELS + co];
    std::copy(b4.begin(), b4.begin() + B4_SIZE, flat + B4_OFFSET);
}

}  // namespace novaenhance::nn
