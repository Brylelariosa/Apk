#include "network.h"

#include <algorithm>
#include <cmath>
#include <random>
#include <vector>

#include "inference.h"
#include "simd.h"
#include "training.h"

// network.cpp is the small, stable front door: parameter initialisation and the
// optimizer live here, while the heavy lifting is delegated to
//   inference.cpp   - fused, streaming, multi-threaded forward pass
//   training.cpp    - parallel forward/backward producing the gradient
//   conv_kernels.cpp, simd.h - the NEON (or portable) convolution kernels
// The scalar implementation these replaced is kept, unchanged, as the golden
// reference in tools/nn_verification/reference_network.cpp.

namespace novaenhance::nn {

namespace {

void adamUpdate(float* params, const float* grads, float* momentum, float* velocity,
                 int n, int stepNumber, float learningRate,
                 float beta1 = 0.9f, float beta2 = 0.999f, float eps = 1e-8f) {
    float biasCorrection1 = 1.0f - std::pow(beta1, static_cast<float>(stepNumber));
    float biasCorrection2 = 1.0f - std::pow(beta2, static_cast<float>(stepNumber));
    for (int i = 0; i < n; ++i) {
        momentum[i] = beta1 * momentum[i] + (1.0f - beta1) * grads[i];
        velocity[i] = beta2 * velocity[i] + (1.0f - beta2) * grads[i] * grads[i];
        float mHat = momentum[i] / biasCorrection1;
        float vHat = velocity[i] / biasCorrection2;
        params[i] -= learningRate * mHat / (std::sqrt(vHat) + eps);
    }
}

/**
 * Rescales `grad` in place if its L2 norm exceeds `maxNorm`. Standard
 * gradient-norm clipping. Added after testing found that a large enough
 * learning rate (~0.02, well above this app's default of 1e-4, but not
 * impossible if e.g. a future change to the adaptive controller pushed
 * rates higher) could push every output pixel to exactly 0 or 1 within a
 * few steps - and since clip(0,1)'s backward pass is exactly zero at
 * saturation (by design, same as ReLU's subgradient treatment), a fully
 * saturated output permanently zeroes the gradient with no way to recover.
 * Clipping the gradient norm keeps any single update small enough to make
 * that dead end very unlikely to reach, regardless of learning rate.
 */
void clipGradientNorm(float* grad, int n, float maxNorm) {
    double sumSq = 0.0;
    for (int i = 0; i < n; ++i) sumSq += static_cast<double>(grad[i]) * grad[i];
    double norm = std::sqrt(sumSq);
    if (norm > maxNorm) {
        float scale = static_cast<float>(maxNorm / norm);
        for (int i = 0; i < n; ++i) grad[i] *= scale;
    }
}

}  // namespace

void initializeParams(float* params, uint32_t seed) {
    std::mt19937 rng(seed);

    auto heInit = [&](float* w, int fanIn, int count) {
        float stddev = std::sqrt(2.0f / static_cast<float>(fanIn));
        std::normal_distribution<float> dist(0.0f, stddev);
        for (int i = 0; i < count; ++i) w[i] = dist(rng);
    };

    heInit(params + W1_OFFSET, KERNEL * KERNEL * CIN, W1_SIZE);
    std::fill(params + B1_OFFSET, params + B1_OFFSET + B1_SIZE, 0.0f);

    heInit(params + W2_OFFSET, KERNEL * KERNEL * C1, W2_SIZE);
    std::fill(params + B2_OFFSET, params + B2_OFFSET + B2_SIZE, 0.0f);

    heInit(params + W3_OFFSET, KERNEL * KERNEL * C1, W3_SIZE);
    std::fill(params + B3_OFFSET, params + B3_OFFSET + B3_SIZE, 0.0f);

    // Near-zero init for the tail conv, same rationale as the original
    // TFLite design: at t=0 the network should behave as an approximate
    // identity function (output ~= input) rather than emit noise, so a
    // fresh install "enhances" photos as a safe no-op until trained.
    std::normal_distribution<float> tailDist(0.0f, 1e-3f);
    for (int i = 0; i < W4_SIZE; ++i) params[W4_OFFSET + i] = tailDist(rng);
    std::fill(params + B4_OFFSET, params + B4_OFFSET + B4_SIZE, 0.0f);
}

void inferForward(const float* input, const float* params, float* output) {
    inferFloatImage(input, TILE_SIZE, TILE_SIZE, params, output);
}

float trainStep(
    const float* inputBatch,
    const float* targetBatch,
    int batchSize,
    float* params,
    float* momentum,
    float* velocity,
    const float* anchorParams,
    int adamStepNumber,
    float learningRate,
    float l2SpLambda,
    int threads
) {
    std::vector<float> gradient(TOTAL_PARAMS);
    const float loss = computeLossAndGradient(inputBatch, targetBatch, batchSize, params, gradient.data(), threads);

    if (anchorParams != nullptr && l2SpLambda > 0.0f) {
        for (int i = 0; i < TOTAL_PARAMS; ++i) {
            gradient[i] += 2.0f * l2SpLambda * (params[i] - anchorParams[i]);
        }
    }

    clipGradientNorm(gradient.data(), TOTAL_PARAMS, MAX_GRADIENT_NORM);
    adamUpdate(params, gradient.data(), momentum, velocity, TOTAL_PARAMS, adamStepNumber, learningRate);

    return loss;
}

const char* backendName() { return simd::backendName(); }

}  // namespace novaenhance::nn
