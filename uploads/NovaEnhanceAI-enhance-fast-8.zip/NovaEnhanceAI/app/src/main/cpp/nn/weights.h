#ifndef NOVAENHANCE_WEIGHTS_H
#define NOVAENHANCE_WEIGHTS_H

#include <vector>

#include "network.h"

namespace novaenhance::nn {

/** The image tensors have 3 channels, the kernels want multiples of 4: pad with one always-zero channel. */
constexpr int PADDED_IMAGE_CHANNELS = 4;

/**
 * Kernel-friendly copies of the flat parameter vector. The flat layout in
 * network.h stays THE checkpoint format (nothing on disk or on the Kotlin side
 * changes); this is a cheap per-call repack (~45K floats, microseconds).
 *
 *   w1  [9][4][48]   input channel 3 carries zero weights
 *   w2  [9][48][48]
 *   w3  [9][48][48]
 *   w4  [9][48][4]   output channel 3 carries zero weights and zero bias
 *
 * For training, backward-data weights are also built. The gradient with respect
 * to a layer's input is itself a 3x3 convolution of the output gradient with the
 * kernel rotated 180 degrees and its channel axes swapped:
 *
 *   wNt[ki'][kj'][co][ci] = wN[2-ki'][2-kj'][ci][co]
 *
 * which lets the SAME forward kernel compute backward-data (conv_kernels.h).
 */
struct PackedWeights {
    std::vector<float> w1, b1, w2, b2, w3, b3, w4, b4;
    std::vector<float> w2t, w3t, w4t;  // only filled when pack(..., withBackward = true)

    void pack(const float* params, bool withBackward);
};

/**
 * Per-worker gradient accumulator in the same padded kernel layout as
 * PackedWeights. Each worker thread owns one, accumulates into it lock-free, and
 * toFlatGradient() later folds them into the flat parameter layout.
 */
struct GradientAccumulator {
    std::vector<float> w1, b1, w2, b2, w3, b3, w4, b4;

    GradientAccumulator();
    void clear();
    void add(const GradientAccumulator& other);
    /** Writes the gradient in the flat network.h layout (dropping the padded channel). */
    void toFlat(float* flatGradient) const;
};

}  // namespace novaenhance::nn

#endif  // NOVAENHANCE_WEIGHTS_H
