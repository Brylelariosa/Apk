#ifndef NOVAENHANCE_TRAINING_H
#define NOVAENHANCE_TRAINING_H

namespace novaenhance::nn {

/**
 * Forward + backward over a batch of TILE_SIZE x TILE_SIZE tiles. Writes the
 * batch-AVERAGED L1-loss gradient in the flat network.h parameter layout to
 * `flatGradient` (TOTAL_PARAMS floats) and returns the batch-average L1 loss.
 * No optimizer step, no L2-SP, no clipping - those stay in network.cpp so the
 * pure gradient can be checked against the scalar reference on its own.
 *
 * Parallelism is layer-synchronous over (sample x row-band) jobs on the shared
 * thread pool with dynamic scheduling, so it scales with cores even for a
 * batch of 1 and balances across big.LITTLE cores. With threads == 1 the result
 * is fully deterministic; with more threads the per-thread gradient partial
 * sums are added in a scheduling-dependent order (float rounding level only).
 * `threads <= 0` means "all pool threads".
 */
float computeLossAndGradient(const float* inputBatch, const float* targetBatch, int batchSize,
                             const float* params, float* flatGradient, int threads);

}  // namespace novaenhance::nn

#endif  // NOVAENHANCE_TRAINING_H
