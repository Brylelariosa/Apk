#ifndef NOVAENHANCE_CONV_KERNELS_H
#define NOVAENHANCE_CONV_KERNELS_H

#include <cstddef>

namespace novaenhance::nn::kernels {

// ============================================================================
// Register-blocked 3x3 'same' convolution kernels (stride 1, zero padding).
//
// Data layout, shared by every kernel here and by the code that calls them:
//
//   * Activations are NHWC, one image at a time: pixel (y,x) channel c lives at
//     ((y * W) + x) * C + c.
//   * "Padded planes" carry a ONE-PIXEL ZERO BORDER: (H+2) x (W+2) x C, with the
//     real image in the interior. Every kernel reads its 3x3 neighbourhood
//     straight out of such a plane, so there is no edge special-casing in the
//     hot loops. Callers must never write into the border.
//   * Weights are [ki][kj][cin][cout] with cout contiguous - exactly the flat
//     parameter layout in network.h, so checkpoints need no conversion.
//   * Channel counts must be multiples of 4. The network's 3-channel image
//     tensors are therefore padded to 4 channels (the extra channel is always
//     zero and carries zero weights) - see weights.h.
//
// "Row" kernels produce ONE output row from three padded input rows. That is the
// natural unit for both callers: the streaming inference path feeds them from
// 3-slot ring buffers, and the training path feeds them from full planes.
// ============================================================================

enum class Epilogue { None, Relu };

/**
 * One output row of out = epi(bias + conv3x3(in, weights)).
 *
 *  rows[0..2]  padded input rows y-1, y, y+1. Each points at PADDED pixel 0 (the
 *              left zero column) and is (width + 2) pixels of `cin` floats wide.
 *  weights     [3][3][cin][cout]
 *  bias        cout floats, or nullptr for zero
 *  out         points at OUTPUT pixel 0 of the row; pixel stride is `cout`
 *              (so a caller writing into a padded plane passes plane-row + cout).
 */
void convRow(const float* const rows[3], int cin, const float* weights, const float* bias,
             int cout, int width, Epilogue epilogue, float* out);

/**
 * Backward-data building block: out = (gate > 0) ? conv3x3(in, weights) : 0.
 * Used with spatially flipped / channel-transposed weights (see weights.h) and
 * the forward ReLU activation as `gate`, it computes dL/d(pre-activation) of the
 * previous layer in one pass. `gate` has out's layout (pixel stride `cout`) and
 * points at output pixel 0 of the row.
 */
void convRowGated(const float* const rows[3], int cin, const float* weights, int cout,
                  int width, const float* gate, float* out);

/**
 * Accumulates the weight gradient of one conv layer for output rows [y0, y1):
 *
 *   dW[ki][kj][ci][co] += sum_{y,x} in_pad[y+ki][x+kj][ci] * dout[y][x][co]
 *   dB[co]             += sum_{y,x} dout[y][x][co]
 *
 * inPad / doutPad are padded planes of the layer input (cin channels) and of the
 * gradient at the layer output (cout channels), both (height+2) x (width+2).
 * dW must hold 9*cin*cout floats and dB cout floats; both are ACCUMULATED into,
 * so each worker thread owns a private pair and the caller sums them afterwards.
 */
void convWeightGrad(const float* inPad, int cin, const float* doutPad, int cout, int width,
                    int y0, int y1, float* dW, float* dB);

}  // namespace novaenhance::nn::kernels

#endif  // NOVAENHANCE_CONV_KERNELS_H
