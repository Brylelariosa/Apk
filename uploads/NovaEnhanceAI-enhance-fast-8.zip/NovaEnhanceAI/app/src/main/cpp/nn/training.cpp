#include "training.h"

#include <algorithm>
#include <cmath>
#include <mutex>
#include <vector>

#include "conv_kernels.h"
#include "network.h"
#include "util/thread_pool.h"
#include "weights.h"

namespace novaenhance::nn {

namespace {

constexpr int kSize = TILE_SIZE;                 // 64
constexpr int kPadded = kSize + 2;               // 66: one zero pixel on each side
constexpr int kImageCh = PADDED_IMAGE_CHANNELS;  // 4
constexpr int kHidden = C1;                      // 48 (C1 == C2)

// A job is (sample, kBandRows consecutive rows). 4 rows keeps jobs ~1-2 ms on a
// Cortex-A55 for the heavy layers: small enough that the fast cores never wait
// long for the slow ones at the end of a phase, big enough that scheduling
// overhead stays in the noise.
constexpr int kBandRows = 4;
constexpr int kBands = kSize / kBandRows;
static_assert(kSize % kBandRows == 0, "bands must tile the image exactly");

// Samples processed layer-synchronously at once. ~4.3 MB of activations and
// gradients per sample; larger batches run in waves of this size so peak
// native memory stays bounded (34 MB) on a 4 GB phone.
constexpr int kMaxSamplesInFlight = 8;

size_t planeFloats(int channels) { return static_cast<size_t>(kPadded) * kPadded * channels; }

// Padded-plane addressing. `paddedRow` counts from the zero border row (0) down.
template <typename T>
T* paddedRow(T* plane, int channels, int paddedRowIndex) {
    return plane + static_cast<size_t>(paddedRowIndex) * kPadded * channels;
}

// First interior pixel of image row y.
template <typename T>
T* interiorRow(T* plane, int channels, int y) {
    return plane + (static_cast<size_t>(y + 1) * kPadded + 1) * channels;
}

/** Per-sample activations and gradients. Borders are zero from construction on and never written. */
struct SampleBuffers {
    std::vector<float> x, a1, a2, a3;  // layer inputs / post-ReLU activations
    std::vector<float> g[2];           // ping-pong pre-activation gradients (layer 3 -> 2 -> 1)
    std::vector<float> d4;             // gradient at the conv4 output (4 channels, 4th always 0)

    SampleBuffers()
        : x(planeFloats(kImageCh), 0.0f), a1(planeFloats(kHidden), 0.0f), a2(planeFloats(kHidden), 0.0f),
          a3(planeFloats(kHidden), 0.0f), g{std::vector<float>(planeFloats(kHidden), 0.0f),
                                            std::vector<float>(planeFloats(kHidden), 0.0f)},
          d4(planeFloats(kImageCh), 0.0f) {}
};

struct Workspace {
    std::mutex mutex;
    std::vector<SampleBuffers> samples;
    std::vector<GradientAccumulator> grads;  // one per worker
    PackedWeights weights;
    std::vector<double> bandLoss;
};

Workspace& workspace() {
    static Workspace ws;
    return ws;
}

template <typename Fn>
void runPhase(int samples, int threads, Fn&& fn) {
    const std::function<void(int, int)> job = [&](int j, int worker) {
        fn(j / kBands, (j % kBands) * kBandRows, worker);
    };
    ThreadPool::instance().parallelFor(samples * kBands, threads, job);
}

// out = relu(bias + conv3x3(in)) for the band's rows.
void forwardBand(const float* inPlane, int cin, const std::vector<float>& w, const std::vector<float>& b,
                 float* outPlane, int y0) {
    for (int y = y0; y < y0 + kBandRows; ++y) {
        const float* rows[3] = {paddedRow(inPlane, cin, y), paddedRow(inPlane, cin, y + 1),
                                paddedRow(inPlane, cin, y + 2)};
        kernels::convRow(rows, cin, w.data(), b.data(), kHidden, kSize, kernels::Epilogue::Relu,
                         interiorRow(outPlane, kHidden, y));
    }
}

// Layer 4 + global residual + clip + L1 loss + output gradient, for the band's rows.
// Returns the sum of |out - target| over the band (all 3 channels).
double outputBand(SampleBuffers& s, const PackedWeights& pw, const float* input, const float* target,
                  float gradScale, int y0) {
    float c4[kSize * kImageCh];
    double loss = 0.0;
    for (int y = y0; y < y0 + kBandRows; ++y) {
        const float* rows[3] = {paddedRow(s.a3.data(), kHidden, y), paddedRow(s.a3.data(), kHidden, y + 1),
                                paddedRow(s.a3.data(), kHidden, y + 2)};
        kernels::convRow(rows, kHidden, pw.w4.data(), pw.b4.data(), kImageCh, kSize, kernels::Epilogue::None, c4);

        float* d4Row = interiorRow(s.d4.data(), kImageCh, y);
        const float* in = input + static_cast<size_t>(y) * kSize * CIN;
        const float* tg = target + static_cast<size_t>(y) * kSize * COUT;
        for (int x = 0; x < kSize; ++x) {
            for (int c = 0; c < COUT; ++c) {
                const float residual = in[x * CIN + c] + c4[x * kImageCh + c];
                const float clipped = std::min(1.0f, std::max(0.0f, residual));
                const float diff = clipped - tg[x * COUT + c];
                loss += std::fabs(diff);
                const float sign = diff > 0.0f ? 1.0f : (diff < 0.0f ? -1.0f : 0.0f);
                // The clip has zero gradient outside [0,1] (inputs are valid pixels; the
                // residual only leaves the range when the net over/undershoots).
                d4Row[x * kImageCh + c] = (residual >= 0.0f && residual <= 1.0f) ? sign * gradScale : 0.0f;
            }
        }
    }
    return loss;
}

// One backward layer for the band's rows:
//   dW/dB += weight-gradient(layerInput, gradOut)
//   gradPrev = (prevActivation > 0) ? conv3x3(gradOut, flippedWeights) : 0     (skipped when prevGate == nullptr)
void backwardBand(const float* layerInput, int cin, const float* gradOut, int cout, const std::vector<float>* flippedW,
                  const float* prevGate, float* gradPrev, std::vector<float>& dW, std::vector<float>& dB, int y0) {
    kernels::convWeightGrad(layerInput, cin, gradOut, cout, kSize, y0, y0 + kBandRows, dW.data(), dB.data());
    if (prevGate == nullptr) return;
    for (int y = y0; y < y0 + kBandRows; ++y) {
        const float* rows[3] = {paddedRow(gradOut, cout, y), paddedRow(gradOut, cout, y + 1),
                                paddedRow(gradOut, cout, y + 2)};
        kernels::convRowGated(rows, cout, flippedW->data(), cin, kSize, interiorRow(prevGate, cin, y),
                              interiorRow(gradPrev, cin, y));
    }
}

}  // namespace

float computeLossAndGradient(const float* inputBatch, const float* targetBatch, int batchSize,
                             const float* params, float* flatGradient, int threads) {
    std::fill(flatGradient, flatGradient + TOTAL_PARAMS, 0.0f);
    if (batchSize <= 0) return 0.0f;

    Workspace& ws = workspace();
    std::lock_guard<std::mutex> lock(ws.mutex);

    ThreadPool& pool = ThreadPool::instance();
    const int useThreads = threads > 0 ? std::min(threads, pool.maxThreads()) : pool.maxThreads();
    const int wave = std::min(batchSize, kMaxSamplesInFlight);

    ws.weights.pack(params, /*withBackward=*/true);
    while (static_cast<int>(ws.samples.size()) < wave) ws.samples.emplace_back();
    if (static_cast<int>(ws.grads.size()) < useThreads) ws.grads.resize(static_cast<size_t>(useThreads));
    for (int w = 0; w < useThreads; ++w) ws.grads[static_cast<size_t>(w)].clear();
    ws.bandLoss.assign(static_cast<size_t>(wave) * kBands, 0.0);

    const PackedWeights& pw = ws.weights;
    // dL/d(out) per value = sign(diff) / (values per sample * batch): folds both the L1 mean and the batch mean.
    const float gradScale = 1.0f / (static_cast<float>(OUTPUT_FLOATS) * static_cast<float>(batchSize));
    double lossSum = 0.0;  // sum over samples of the per-sample mean L1

    for (int base = 0; base < batchSize; base += wave) {
        const int count = std::min(wave, batchSize - base);
        std::vector<SampleBuffers>& S = ws.samples;

        // Stage the input tiles as padded 4-channel planes (interior only; border and 4th channel stay 0).
        for (int s = 0; s < count; ++s) {
            const float* src = inputBatch + static_cast<size_t>(base + s) * INPUT_FLOATS;
            for (int y = 0; y < kSize; ++y) {
                float* dst = interiorRow(S[static_cast<size_t>(s)].x.data(), kImageCh, y);
                const float* row = src + static_cast<size_t>(y) * kSize * CIN;
                for (int x = 0; x < kSize; ++x) {
                    dst[x * kImageCh + 0] = row[x * CIN + 0];
                    dst[x * kImageCh + 1] = row[x * CIN + 1];
                    dst[x * kImageCh + 2] = row[x * CIN + 2];
                }
            }
        }

        // ---------------------------------------------------------------- forward
        runPhase(count, useThreads, [&](int s, int y0, int) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            forwardBand(b.x.data(), kImageCh, pw.w1, pw.b1, b.a1.data(), y0);
        });
        runPhase(count, useThreads, [&](int s, int y0, int) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            forwardBand(b.a1.data(), kHidden, pw.w2, pw.b2, b.a2.data(), y0);
        });
        runPhase(count, useThreads, [&](int s, int y0, int) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            forwardBand(b.a2.data(), kHidden, pw.w3, pw.b3, b.a3.data(), y0);
        });
        runPhase(count, useThreads, [&](int s, int y0, int) {
            ws.bandLoss[static_cast<size_t>(s) * kBands + static_cast<size_t>(y0 / kBandRows)] =
                outputBand(S[static_cast<size_t>(s)], pw,
                           inputBatch + static_cast<size_t>(base + s) * INPUT_FLOATS,
                           targetBatch + static_cast<size_t>(base + s) * OUTPUT_FLOATS, gradScale, y0);
        });

        // --------------------------------------------------------------- backward
        // Layer 4: dW4 from (a3, d4); g[0] = gradient at layer-3 pre-activation.
        runPhase(count, useThreads, [&](int s, int y0, int worker) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            GradientAccumulator& acc = ws.grads[static_cast<size_t>(worker)];
            backwardBand(b.a3.data(), kHidden, b.d4.data(), kImageCh, &pw.w4t, b.a3.data(), b.g[0].data(), acc.w4,
                         acc.b4, y0);
        });
        // Layer 3: dW3 from (a2, g[0]); g[1] = gradient at layer-2 pre-activation.
        runPhase(count, useThreads, [&](int s, int y0, int worker) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            GradientAccumulator& acc = ws.grads[static_cast<size_t>(worker)];
            backwardBand(b.a2.data(), kHidden, b.g[0].data(), kHidden, &pw.w3t, b.a2.data(), b.g[1].data(), acc.w3,
                         acc.b3, y0);
        });
        // Layer 2: dW2 from (a1, g[1]); g[0] (layer-3 gradient no longer needed) = gradient at layer-1 pre-activation.
        runPhase(count, useThreads, [&](int s, int y0, int worker) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            GradientAccumulator& acc = ws.grads[static_cast<size_t>(worker)];
            backwardBand(b.a1.data(), kHidden, b.g[1].data(), kHidden, &pw.w2t, b.a1.data(), b.g[0].data(), acc.w2,
                         acc.b2, y0);
        });
        // Layer 1: dW1 from (x, g[0]). The gradient w.r.t. the image itself is never needed.
        runPhase(count, useThreads, [&](int s, int y0, int worker) {
            SampleBuffers& b = S[static_cast<size_t>(s)];
            GradientAccumulator& acc = ws.grads[static_cast<size_t>(worker)];
            backwardBand(b.x.data(), kImageCh, b.g[0].data(), kHidden, nullptr, nullptr, nullptr, acc.w1, acc.b1, y0);
        });

        for (int s = 0; s < count; ++s) {
            double sampleLoss = 0.0;
            for (int band = 0; band < kBands; ++band) sampleLoss += ws.bandLoss[static_cast<size_t>(s) * kBands + band];
            lossSum += sampleLoss / static_cast<double>(OUTPUT_FLOATS);
        }
    }

    for (int w = 1; w < useThreads; ++w) ws.grads[0].add(ws.grads[static_cast<size_t>(w)]);
    ws.grads[0].toFlat(flatGradient);
    return static_cast<float>(lossSum / static_cast<double>(batchSize));
}

void releaseTrainingWorkspace() {
    Workspace& ws = workspace();
    std::lock_guard<std::mutex> lock(ws.mutex);
    std::vector<SampleBuffers>().swap(ws.samples);
    std::vector<GradientAccumulator>().swap(ws.grads);
    std::vector<double>().swap(ws.bandLoss);
    ws.weights = PackedWeights();
}

}  // namespace novaenhance::nn
