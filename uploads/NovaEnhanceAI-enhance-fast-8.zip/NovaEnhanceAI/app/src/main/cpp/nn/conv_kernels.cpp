#include "conv_kernels.h"

#include "simd.h"

namespace novaenhance::nn::kernels {

namespace {

using simd::vf;

constexpr int kTaps = 3;

// ----------------------------------------------------------------------------
// Forward / backward-data micro-kernel.
//
// Computes a block of P adjacent output pixels x (CV*4) output channels,
// holding all P*CV accumulators in vector registers for the WHOLE 3x3xCin
// reduction, then stores once. Per group of 4 input channels it does
//     P input-vector loads + 4*CV weight-vector loads + 4*P*CV lane-FMAs,
// i.e. 48 FMAs per 16 loads for the 4x3 block used on AArch64: the loop is
// limited by the FMA pipes, not by memory. `fmaLane` multiplies a whole weight
// vector by ONE input channel of a pixel (FMLA-by-element), so the input needs
// no broadcast/shuffle instructions at all.
// ----------------------------------------------------------------------------
enum Mode { kPlain = 0, kRelu = 1, kGated = 2 };

template <int L, int P, int CV>
inline void laneStep(vf (&acc)[P][CV], const vf (&xv)[P], const float* wrow) {
    vf wv[CV];
    NOVA_UNROLL
    for (int c = 0; c < CV; ++c) wv[c] = simd::load(wrow + 4 * c);
    NOVA_UNROLL
    for (int p = 0; p < P; ++p) {
        NOVA_UNROLL
        for (int c = 0; c < CV; ++c) acc[p][c] = simd::fmaLane<L>(acc[p][c], wv[c], xv[p]);
    }
}

template <int P, int CV, int MODE>
inline void forwardBlock(const float* const rows[3], int cin, const float* weights, int cout,
                         const float* bias, int x, int co, const float* gate, float* out) {
    vf acc[P][CV];
    NOVA_UNROLL
    for (int c = 0; c < CV; ++c) {
        const vf b = bias != nullptr ? simd::load(bias + co + 4 * c) : simd::zero();
        NOVA_UNROLL
        for (int p = 0; p < P; ++p) acc[p][c] = b;
    }

    const size_t coutS = static_cast<size_t>(cout);
    for (int ki = 0; ki < kTaps; ++ki) {
        for (int kj = 0; kj < kTaps; ++kj) {
            // Output pixel x+p reads padded pixel x+p+kj of input row ki.
            const float* xp = rows[ki] + static_cast<size_t>(x + kj) * static_cast<size_t>(cin);
            const float* wp = weights + static_cast<size_t>(ki * kTaps + kj) * static_cast<size_t>(cin) * coutS + co;
            for (int ci = 0; ci < cin; ci += 4) {
                vf xv[P];
                NOVA_UNROLL
                for (int p = 0; p < P; ++p) xv[p] = simd::load(xp + static_cast<size_t>(p) * static_cast<size_t>(cin) + ci);
                const float* w = wp + static_cast<size_t>(ci) * coutS;
                laneStep<0, P, CV>(acc, xv, w);
                laneStep<1, P, CV>(acc, xv, w + coutS);
                laneStep<2, P, CV>(acc, xv, w + 2 * coutS);
                laneStep<3, P, CV>(acc, xv, w + 3 * coutS);
            }
        }
    }

    NOVA_UNROLL
    for (int p = 0; p < P; ++p) {
        NOVA_UNROLL
        for (int c = 0; c < CV; ++c) {
            const size_t offset = static_cast<size_t>(x + p) * coutS + static_cast<size_t>(co) + 4 * c;
            vf v = acc[p][c];
            if constexpr (MODE == kRelu) v = simd::vmax(v, simd::zero());
            if constexpr (MODE == kGated) v = simd::selectPositive(simd::load(gate + offset), v);
            simd::store(out + offset, v);
        }
    }
}

template <int CV, int MODE>
inline void sweepRow(const float* const rows[3], int cin, const float* weights, int cout,
                     const float* bias, int width, int co, const float* gate, float* out) {
    int x = 0;
    for (; x + 4 <= width; x += 4) forwardBlock<4, CV, MODE>(rows, cin, weights, cout, bias, x, co, gate, out);
    for (; x < width; ++x) forwardBlock<1, CV, MODE>(rows, cin, weights, cout, bias, x, co, gate, out);
}

template <int MODE>
void convRowImpl(const float* const rows[3], int cin, const float* weights, const float* bias,
                 int cout, int width, const float* gate, float* out) {
    // Output channels are processed in blocks of up to kPreferredCoVecs vectors. The block's
    // weight slice (9 * cin * block floats, ~20 KB for 48->12) stays hot in L1 while the
    // block sweeps the whole row.
    int co = 0;
    while (co < cout) {
        const int vecsLeft = (cout - co) / 4;
        const int cv = vecsLeft >= simd::kPreferredCoVecs ? simd::kPreferredCoVecs : vecsLeft;
        switch (cv) {
            case 3: sweepRow<3, MODE>(rows, cin, weights, cout, bias, width, co, gate, out); break;
            case 2: sweepRow<2, MODE>(rows, cin, weights, cout, bias, width, co, gate, out); break;
            default: sweepRow<1, MODE>(rows, cin, weights, cout, bias, width, co, gate, out); break;
        }
        co += 4 * cv;
    }
}

// ----------------------------------------------------------------------------
// Weight-gradient micro-kernel: a 4 (input channels) x CV*4 (output channels)
// block of dW held in registers while it sweeps `rowCount` image rows.
//   acc[i][c] += dout[x][co + 4c ..] * in[x][ci + i]        (one lane-FMA each)
// ----------------------------------------------------------------------------
template <int CV>
inline void gradBlock(const float* inPad, int cin, const float* doutPad, int cout, int width,
                      int yBegin, int yEnd, int ki, int kj, int ci, int co, float* dWTap) {
    vf acc[4][CV];
    NOVA_UNROLL
    for (int i = 0; i < 4; ++i) {
        NOVA_UNROLL
        for (int c = 0; c < CV; ++c) acc[i][c] = simd::zero();
    }

    const size_t paddedW = static_cast<size_t>(width) + 2;
    const size_t cinS = static_cast<size_t>(cin);
    const size_t coutS = static_cast<size_t>(cout);
    for (int y = yBegin; y < yEnd; ++y) {
        const float* xp = inPad + ((static_cast<size_t>(y + ki) * paddedW) + static_cast<size_t>(kj)) * cinS + ci;
        const float* dp = doutPad + ((static_cast<size_t>(y + 1) * paddedW) + 1) * coutS + co;
        for (int x = 0; x < width; ++x) {
            const vf xv = simd::load(xp + static_cast<size_t>(x) * cinS);
            vf dv[CV];
            NOVA_UNROLL
            for (int c = 0; c < CV; ++c) dv[c] = simd::load(dp + static_cast<size_t>(x) * coutS + 4 * c);
            NOVA_UNROLL
            for (int c = 0; c < CV; ++c) {
                acc[0][c] = simd::fmaLane<0>(acc[0][c], dv[c], xv);
                acc[1][c] = simd::fmaLane<1>(acc[1][c], dv[c], xv);
                acc[2][c] = simd::fmaLane<2>(acc[2][c], dv[c], xv);
                acc[3][c] = simd::fmaLane<3>(acc[3][c], dv[c], xv);
            }
        }
    }

    float* base = dWTap + static_cast<size_t>(ci) * coutS + co;
    NOVA_UNROLL
    for (int i = 0; i < 4; ++i) {
        NOVA_UNROLL
        for (int c = 0; c < CV; ++c) {
            float* dst = base + static_cast<size_t>(i) * coutS + 4 * c;
            simd::store(dst, simd::add(simd::load(dst), acc[i][c]));
        }
    }
}

// Two rows per pass: halves the dW load/add/store overhead per pass while the
// two rows of input + gradient (~50 KB for 48 channels) still sit in L2 and the
// hot part in L1.
constexpr int kGradRowsPerPass = 2;

}  // namespace

void convRow(const float* const rows[3], int cin, const float* weights, const float* bias,
             int cout, int width, Epilogue epilogue, float* out) {
    if (epilogue == Epilogue::Relu) {
        convRowImpl<kRelu>(rows, cin, weights, bias, cout, width, nullptr, out);
    } else {
        convRowImpl<kPlain>(rows, cin, weights, bias, cout, width, nullptr, out);
    }
}

void convRowGated(const float* const rows[3], int cin, const float* weights, int cout,
                  int width, const float* gate, float* out) {
    convRowImpl<kGated>(rows, cin, weights, nullptr, cout, width, gate, out);
}

void convWeightGrad(const float* inPad, int cin, const float* doutPad, int cout, int width,
                    int y0, int y1, float* dW, float* dB) {
    const size_t paddedW = static_cast<size_t>(width) + 2;
    const size_t coutS = static_cast<size_t>(cout);

    // Bias gradient: plain per-pixel vector accumulation (a rounding error next to dW).
    for (int y = y0; y < y1; ++y) {
        const float* dp = doutPad + ((static_cast<size_t>(y + 1) * paddedW) + 1) * coutS;
        for (int x = 0; x < width; ++x) {
            const float* px = dp + static_cast<size_t>(x) * coutS;
            for (int c = 0; c < cout; c += 4) {
                simd::store(dB + c, simd::add(simd::load(dB + c), simd::load(px + c)));
            }
        }
    }

    // Weight gradient, blocked over (tap, row pair, input-channel quad, output-channel block).
    for (int ki = 0; ki < kTaps; ++ki) {
        for (int kj = 0; kj < kTaps; ++kj) {
            float* dWTap = dW + static_cast<size_t>(ki * kTaps + kj) * static_cast<size_t>(cin) * coutS;
            for (int y = y0; y < y1; y += kGradRowsPerPass) {
                const int yEnd = y + kGradRowsPerPass < y1 ? y + kGradRowsPerPass : y1;
                for (int ci = 0; ci < cin; ci += 4) {
                    int co = 0;
                    while (co < cout) {
                        const int vecsLeft = (cout - co) / 4;
                        const int cv = vecsLeft >= simd::kPreferredCoVecs ? simd::kPreferredCoVecs : vecsLeft;
                        switch (cv) {
                            case 3: gradBlock<3>(inPad, cin, doutPad, cout, width, y, yEnd, ki, kj, ci, co, dWTap); break;
                            case 2: gradBlock<2>(inPad, cin, doutPad, cout, width, y, yEnd, ki, kj, ci, co, dWTap); break;
                            default: gradBlock<1>(inPad, cin, doutPad, cout, width, y, yEnd, ki, kj, ci, co, dWTap); break;
                        }
                        co += 4 * cv;
                    }
                }
            }
        }
    }
}

}  // namespace novaenhance::nn::kernels
