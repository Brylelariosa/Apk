#ifndef NOVAENHANCE_SIMD_H
#define NOVAENHANCE_SIMD_H

// ============================================================================
// Tiny 4-lane float32 SIMD abstraction used by the convolution kernels.
//
// Three interchangeable backends expose the SAME function set, so every kernel
// in conv_kernels.cpp is written exactly once:
//
//   1. NEON, AArch64  - real intrinsics, fused multiply-add by lane (FMLA).
//                       This is the path the Infinix HOT 11 2022 (Unisoc T610:
//                       2x Cortex-A75 + 6x Cortex-A55, 64-bit) runs.
//   2. NEON, ARMv7    - real intrinsics for 32-bit-userland phones
//                       (armeabi-v7a). Only 16 Q registers, so kernels use a
//                       narrower register block there (see kPreferredCoVecs).
//   3. Portable       - GCC/Clang vector extensions. Used on x86 (host tests,
//                       emulators) and anywhere NEON is unavailable.
//
// tools/nn_verification/neon_shim.h emulates the handful of NEON intrinsics
// used below on a desktop CPU, which lets the NEON backends be compiled and
// exercised in host tests (define NOVA_SIMD_SHIM_A64 or NOVA_SIMD_SHIM_A32).
// That validates the kernel logic and the wrappers' semantics; it is not a
// substitute for running on a real device - see README "Honest limitations".
// ============================================================================

#include <cstddef>

#if defined(NOVA_SIMD_SHIM_A64) || defined(NOVA_SIMD_SHIM_A32)
#  include "neon_shim.h"
#  define NOVA_SIMD_NEON 1
#  if defined(NOVA_SIMD_SHIM_A64)
#    define NOVA_SIMD_A64 1
#  endif
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
#  include <arm_neon.h>
#  define NOVA_SIMD_NEON 1
#  if defined(__aarch64__)
#    define NOVA_SIMD_A64 1
#  endif
#endif

// Full-unroll hint for the small fixed-trip-count register-block loops. The
// accumulator arrays only stay in registers if these loops are fully unrolled.
#if defined(__clang__)
#  define NOVA_UNROLL _Pragma("clang loop unroll(full)")
#elif defined(__GNUC__)
#  define NOVA_UNROLL _Pragma("GCC unroll 16")
#else
#  define NOVA_UNROLL
#endif

namespace novaenhance::nn::simd {

#if defined(NOVA_SIMD_NEON)

// ---------------------------------------------------------------- NEON ------
using vf = float32x4_t;

#if defined(NOVA_SIMD_A64)
// 32 vector registers: 4 pixels x 3 output vectors = 12 accumulators, plus
// 4 input vectors and 3 weight vectors, fits with room to spare.
constexpr int kPreferredCoVecs = 3;
#else
// 16 Q registers: 4 pixels x 2 output vectors = 8 accumulators + 4 + 2.
constexpr int kPreferredCoVecs = 2;
#endif

inline vf load(const float* p) { return vld1q_f32(p); }
inline void store(float* p, vf v) { vst1q_f32(p, v); }
inline vf splat(float x) { return vdupq_n_f32(x); }
inline vf zero() { return vdupq_n_f32(0.0f); }
inline vf add(vf a, vf b) { return vaddq_f32(a, b); }
inline vf vmax(vf a, vf b) { return vmaxq_f32(a, b); }

/** acc + a * b (fused on AArch64, separately rounded on ARMv7). */
inline vf fma(vf acc, vf a, vf b) {
#if defined(NOVA_SIMD_A64)
    return vfmaq_f32(acc, a, b);
#else
    return vmlaq_f32(acc, a, b);
#endif
}

/** acc + a * b[L]  - multiply a whole vector by ONE lane of another vector. */
template <int L>
inline vf fmaLane(vf acc, vf a, vf b) {
#if defined(NOVA_SIMD_A64)
    return vfmaq_laneq_f32(acc, a, b, L);
#else
    return vmlaq_lane_f32(acc, a, (L < 2) ? vget_low_f32(b) : vget_high_f32(b), L & 1);
#endif
}

/** Lane-wise: gate > 0 ? a : 0. Implements the ReLU backward mask. */
inline vf selectPositive(vf gate, vf a) {
    const vf z = vdupq_n_f32(0.0f);
    return vbslq_f32(vcgtq_f32(gate, z), a, z);
}

inline float hsum(vf v) {
#if defined(NOVA_SIMD_A64)
    return vaddvq_f32(v);
#else
    float32x2_t s = vadd_f32(vget_low_f32(v), vget_high_f32(v));
    s = vpadd_f32(s, s);
    return vget_lane_f32(s, 0);
#endif
}

constexpr const char* backendName() {
#if defined(NOVA_SIMD_A64)
    return "neon-aarch64";
#else
    return "neon-armv7";
#endif
}

#else  // ------------------------------------------------------- portable ----

typedef float vf __attribute__((vector_size(16)));
// Unaligned, aliasing-safe view used for loads/stores through float pointers.
typedef float vf_unaligned __attribute__((vector_size(16), aligned(4), may_alias));

// A 4-pixel x 3-vector block needs ~19 live vector registers: fine with 32 (AVX-512VL), but it would spill
// on x86-64's 16 XMM registers, so use 4 x 2 (14 live) there. NOTE the portable backend exists so the
// code runs - and can be verified - on non-ARM hosts; it is not a fast path. Without FMA-by-lane (an ARM
// instruction) plain SSE2 only matches the compiler's own vectorization of the old scalar loops.
#if defined(__AVX512VL__)
constexpr int kPreferredCoVecs = 3;
#else
constexpr int kPreferredCoVecs = 2;
#endif

inline vf load(const float* p) { return *reinterpret_cast<const vf_unaligned*>(p); }
inline void store(float* p, vf v) { *reinterpret_cast<vf_unaligned*>(p) = v; }
inline vf splat(float x) { return vf{x, x, x, x}; }
inline vf zero() { return vf{0.0f, 0.0f, 0.0f, 0.0f}; }
inline vf add(vf a, vf b) { return a + b; }

inline vf vmax(vf a, vf b) {
    vf r;
    for (int i = 0; i < 4; ++i) r[i] = a[i] > b[i] ? a[i] : b[i];
    return r;
}

inline vf fma(vf acc, vf a, vf b) { return acc + a * b; }

template <int L>
inline vf fmaLane(vf acc, vf a, vf b) {
    const float s = b[L];
    return acc + a * vf{s, s, s, s};
}

inline vf selectPositive(vf gate, vf a) {
    vf r;
    for (int i = 0; i < 4; ++i) r[i] = gate[i] > 0.0f ? a[i] : 0.0f;
    return r;
}

inline float hsum(vf v) { return v[0] + v[1] + v[2] + v[3]; }

constexpr const char* backendName() { return "portable"; }

#endif  // NOVA_SIMD_NEON

constexpr int kLanes = 4;

}  // namespace novaenhance::nn::simd

#endif  // NOVAENHANCE_SIMD_H
