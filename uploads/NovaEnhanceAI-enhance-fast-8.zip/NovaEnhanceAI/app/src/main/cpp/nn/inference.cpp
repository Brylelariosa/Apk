#include "inference.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <vector>

#include "conv_kernels.h"
#include "network.h"
#include "util/thread_pool.h"
#include "weights.h"

namespace novaenhance::nn {

namespace {

// Four stacked 3x3 convolutions => every output pixel depends on input pixels at
// most 4 away. A strip computed with this much extra context on each interior
// side therefore produces exact results for the columns it keeps.
constexpr int kHalo = 4;
// Strip width trades redundant work against parallel granularity. Each strip recomputes 2*kHalo extra
// columns (12.5% at width 64, 6.25% at 128) and pays a fixed per-row cost (weight slices re-read from L2,
// ring bookkeeping) that also shrinks as 1/width; measured on the host, 128-wide strips ran ~15% faster
// than 64-wide ones. Cache capacity is NOT the limiter: the kernel is compute-bound (weight and ring
// traffic is ~1% of the arithmetic), so wider is better until there are too few strips to keep every core
// busy - chooseStripWidth() therefore narrows strips only as far as needed for ~2 jobs per thread.
constexpr int kMinStrip = 32;
constexpr int kMaxStrip = 128;

constexpr int kImageCh = PADDED_IMAGE_CHANNELS;  // 4
constexpr int kHidden = C1;                      // 48 (C1 == C2)

// i / 255.0f by TRUE division, bit-identical to TensorImageCodec.encodeSingle.
const std::array<float, 256>& byteToUnit() {
    static const std::array<float, 256> table = [] {
        std::array<float, 256> t{};
        for (int i = 0; i < 256; ++i) t[i] = static_cast<float>(i) / 255.0f;
        return t;
    }();
    return table;
}

/** ARGB_8888 in, ARGB_8888 out. */
struct ArgbIO {
    const uint32_t* src;
    uint32_t* dst;
    int imgW;

    void load(int y, int xs, int w, float* row) const {
        const auto& lut = byteToUnit();
        const uint32_t* p = src + static_cast<size_t>(y) * imgW + xs;
        for (int i = 0; i < w; ++i) {
            const uint32_t px = p[i];
            row[i * 4 + 0] = lut[(px >> 16) & 0xFF];
            row[i * 4 + 1] = lut[(px >> 8) & 0xFF];
            row[i * 4 + 2] = lut[px & 0xFF];
            row[i * 4 + 3] = 0.0f;
        }
    }

    // out = clip01(in + conv4) for local columns [lx0, lx1), rounded half-to-even exactly like the
    // Kotlin decoder (kotlin.math.round).
    void store(int y, int xs, int lx0, int lx1, const float* c4) const {
        const auto& lut = byteToUnit();
        const uint32_t* p = src + static_cast<size_t>(y) * imgW + xs;
        uint32_t* o = dst + static_cast<size_t>(y) * imgW + xs;
        for (int lx = lx0; lx < lx1; ++lx) {
            const uint32_t px = p[lx];
            const float rgb[3] = {lut[(px >> 16) & 0xFF] + c4[lx * 4 + 0],
                                  lut[(px >> 8) & 0xFF] + c4[lx * 4 + 1],
                                  lut[px & 0xFF] + c4[lx * 4 + 2]};
            uint32_t packed = 0xFF000000u;
            for (int c = 0; c < 3; ++c) {
                const float v = std::min(1.0f, std::max(0.0f, rgb[c]));
                packed |= static_cast<uint32_t>(std::lrintf(v * 255.0f)) << (16 - 8 * c);
            }
            o[lx] = packed;
        }
    }
};

/** Float RGB in, float RGB out. */
struct FloatIO {
    const float* src;
    float* dst;
    int imgW;

    void load(int y, int xs, int w, float* row) const {
        const float* p = src + (static_cast<size_t>(y) * imgW + xs) * 3;
        for (int i = 0; i < w; ++i) {
            row[i * 4 + 0] = p[i * 3 + 0];
            row[i * 4 + 1] = p[i * 3 + 1];
            row[i * 4 + 2] = p[i * 3 + 2];
            row[i * 4 + 3] = 0.0f;
        }
    }

    void store(int y, int xs, int lx0, int lx1, const float* c4) const {
        const float* p = src + (static_cast<size_t>(y) * imgW + xs) * 3;
        float* o = dst + (static_cast<size_t>(y) * imgW + xs) * 3;
        for (int lx = lx0; lx < lx1; ++lx)
            for (int c = 0; c < 3; ++c) o[lx * 3 + c] = std::min(1.0f, std::max(0.0f, p[lx * 3 + c] + c4[lx * 4 + c]));
    }
};

size_t scratchFloats(int maxLocalWidth) {
    const size_t wp = static_cast<size_t>(maxLocalWidth) + 2;
    return 3 * wp * kImageCh            // input ring
           + 3 * 3 * wp * kHidden       // layer 1/2/3 activation rings
           + wp * kImageCh              // zero row (image channels)
           + wp * kHidden               // zero row (hidden channels)
           + static_cast<size_t>(maxLocalWidth) * kImageCh  // conv4 output row
           + 16;
}

/**
 * Streams ONE vertical strip of the image top-to-bottom through all four layers.
 *
 * Instead of materialising each layer's full-size activation tensor (for a
 * 64x64 tile that is ~0.8 MB per layer - far beyond the A55's L2), every layer
 * keeps just the 3 most recent output rows in a ring buffer. Row r of layer L is
 * computed as soon as row r+1 of layer L-1 exists, so the whole pipeline's
 * working set is ~150 KB and the activations never leave the core's cache.
 *
 *   step t:  load input row t -> L1 row t-1 -> L2 row t-2 -> L3 row t-3 -> L4/output row t-4
 *
 * Ring rows are (W+2) pixels wide with zero left/right pad pixels (never
 * written), and rows above/below the image are a shared all-zero row, so the
 * kernels need no boundary handling.
 *
 * [x0, x1) are the image columns this strip must produce. Interior strip edges get
 * kHalo extra columns of context that are computed but discarded.
 */
template <typename IO>
void runStrip(const IO& io, int imgW, int imgH, int x0, int x1, const PackedWeights& pw, std::vector<float>& mem) {
    // Context columns exist only where the image does: at a true image border there is nothing
    // to read and the zero padding inside the kernels is the correct behaviour.
    const int xs = std::max(0, x0 - kHalo);
    const int xe = std::min(imgW, x1 + kHalo);
    const int W = xe - xs;
    const size_t wp = static_cast<size_t>(W) + 2;

    std::fill(mem.begin(), mem.begin() + static_cast<std::ptrdiff_t>(scratchFloats(W)), 0.0f);
    float* cursor = mem.data();
    auto take = [&cursor](size_t count) {
        float* p = cursor;
        cursor += count;
        return p;
    };
    float* inRing = take(3 * wp * kImageCh);
    float* a1 = take(3 * wp * kHidden);
    float* a2 = take(3 * wp * kHidden);
    float* a3 = take(3 * wp * kHidden);
    const float* zeroImg = take(wp * kImageCh);
    const float* zeroHidden = take(wp * kHidden);
    float* c4Row = take(static_cast<size_t>(W) * kImageCh);

    auto slot = [wp](float* ring, int channels, int y) { return ring + static_cast<size_t>(y % 3) * wp * channels; };

    for (int t = 0; t < imgH + 4; ++t) {
        if (t < imgH) io.load(t, xs, W, slot(inRing, kImageCh, t) + kImageCh);

        int r = t - 1;  // layer 1
        if (r >= 0 && r < imgH) {
            const float* rows[3] = {r > 0 ? slot(inRing, kImageCh, r - 1) : zeroImg, slot(inRing, kImageCh, r),
                                    r + 1 < imgH ? slot(inRing, kImageCh, r + 1) : zeroImg};
            kernels::convRow(rows, kImageCh, pw.w1.data(), pw.b1.data(), kHidden, W, kernels::Epilogue::Relu,
                             slot(a1, kHidden, r) + kHidden);
        }

        r = t - 2;  // layer 2
        if (r >= 0 && r < imgH) {
            const float* rows[3] = {r > 0 ? slot(a1, kHidden, r - 1) : zeroHidden, slot(a1, kHidden, r),
                                    r + 1 < imgH ? slot(a1, kHidden, r + 1) : zeroHidden};
            kernels::convRow(rows, kHidden, pw.w2.data(), pw.b2.data(), kHidden, W, kernels::Epilogue::Relu,
                             slot(a2, kHidden, r) + kHidden);
        }

        r = t - 3;  // layer 3
        if (r >= 0 && r < imgH) {
            const float* rows[3] = {r > 0 ? slot(a2, kHidden, r - 1) : zeroHidden, slot(a2, kHidden, r),
                                    r + 1 < imgH ? slot(a2, kHidden, r + 1) : zeroHidden};
            kernels::convRow(rows, kHidden, pw.w3.data(), pw.b3.data(), kHidden, W, kernels::Epilogue::Relu,
                             slot(a3, kHidden, r) + kHidden);
        }

        r = t - 4;  // layer 4 + global residual + output
        if (r >= 0 && r < imgH) {
            const float* rows[3] = {r > 0 ? slot(a3, kHidden, r - 1) : zeroHidden, slot(a3, kHidden, r),
                                    r + 1 < imgH ? slot(a3, kHidden, r + 1) : zeroHidden};
            kernels::convRow(rows, kHidden, pw.w4.data(), pw.b4.data(), kImageCh, W, kernels::Epilogue::None, c4Row);
            io.store(r, xs, x0 - xs, x1 - xs, c4Row);
        }
    }
}

int chooseStripWidth(int width, int threads) {
    // ~2 strips per thread so dynamic scheduling can even out fast (A75) and slow (A55) cores.
    int s = (width + 2 * threads - 1) / (2 * threads);
    s = std::clamp(s, kMinStrip, kMaxStrip);
    return (s + 3) & ~3;
}

}  // namespace

void inferRegion(const uint32_t* argb, int width, int height, const float* params, uint32_t* out, int threads) {
    if (width <= 0 || height <= 0) return;

    PackedWeights weights;
    weights.pack(params, /*withBackward=*/false);

    ThreadPool& pool = ThreadPool::instance();
    const int useThreads = threads > 0 ? std::min(threads, pool.maxThreads()) : pool.maxThreads();
    const int strip = chooseStripWidth(width, useThreads);
    const int jobs = (width + strip - 1) / strip;
    const size_t perWorkerFloats = scratchFloats(strip + 2 * kHalo);

    std::vector<std::vector<float>> scratch(static_cast<size_t>(useThreads));
    const ArgbIO io{argb, out, width};
    pool.parallelFor(jobs, useThreads, [&](int job, int worker) {
        std::vector<float>& mem = scratch[static_cast<size_t>(worker)];
        if (mem.empty()) mem.resize(perWorkerFloats);
        const int x0 = job * strip;
        runStrip(io, width, height, x0, std::min(width, x0 + strip), weights, mem);
    });
}

void inferFloatImage(const float* rgb, int width, int height, const float* params, float* out) {
    if (width <= 0 || height <= 0) return;
    PackedWeights weights;
    weights.pack(params, /*withBackward=*/false);
    std::vector<float> mem(scratchFloats(width));
    const FloatIO io{rgb, out, width};
    runStrip(io, width, height, 0, width, weights, mem);
}

}  // namespace novaenhance::nn
