#ifndef NOVAENHANCE_UTIL_THREAD_POOL_H
#define NOVAENHANCE_UTIL_THREAD_POOL_H

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>

namespace novaenhance {

/**
 * A small persistent worker pool. Threads are created once (lazily, on first
 * use) and parked on a condition variable between calls, so a phase that runs
 * for a few milliseconds does not pay thread-creation cost.
 *
 * Work is handed out ONE JOB AT A TIME from an atomic counter ("dynamic
 * scheduling") rather than pre-split into equal shares. That matters on
 * big.LITTLE phones such as the Infinix HOT 11 2022 (2x Cortex-A75 +
 * 6x Cortex-A55): a static split finishes when the slowest core finishes,
 * whereas here the A75 cores simply claim more jobs than the A55 cores and
 * every core stays busy until the last job is taken.
 *
 * One parallelFor runs at a time (callers serialize on an internal mutex); the
 * app already guarantees a single native-processing gate, so this is not a
 * contention point in practice.
 */
class ThreadPool {
public:
    static ThreadPool& instance();

    /**
     * Threads the pool may use, INCLUDING the calling thread: hardware_concurrency(),
     * capped at 8. The environment variable NOVA_NN_THREADS=n overrides it (diagnostics
     * and host tests; the Android app never sets it).
     */
    int maxThreads() const { return maxThreads_; }

    /**
     * Runs fn(job, worker) for every job in [0, jobs) on up to `threads`
     * threads (the caller is one of them) and blocks until all jobs finished.
     * `worker` is in [0, threads) and is unique among the threads running
     * concurrently - use it to index per-thread scratch. threads <= 0 means
     * "use maxThreads()".
     */
    void parallelFor(int jobs, int threads, const std::function<void(int job, int worker)>& fn);

    ThreadPool(const ThreadPool&) = delete;
    ThreadPool& operator=(const ThreadPool&) = delete;

private:
    ThreadPool();
    ~ThreadPool();

    struct Task {
        const std::function<void(int, int)>* fn = nullptr;
        int jobs = 0;
        int participants = 1;             // threads allowed to work on this task, caller included
        std::atomic<int> nextJob{0};
        std::atomic<int> nextSlot{1};     // slot 0 belongs to the caller
        int active = 0;                   // workers currently inside the task; guarded by mutex_
    };

    void workerLoop();

    int maxThreads_ = 1;
    std::vector<std::thread> workers_;

    std::mutex callMutex_;                // serializes parallelFor callers
    std::mutex mutex_;                    // guards current_/generation_/stop_/Task::active
    std::condition_variable wake_;
    std::condition_variable done_;
    Task* current_ = nullptr;
    uint64_t generation_ = 0;
    bool stop_ = false;
};

}  // namespace novaenhance

#endif  // NOVAENHANCE_UTIL_THREAD_POOL_H
