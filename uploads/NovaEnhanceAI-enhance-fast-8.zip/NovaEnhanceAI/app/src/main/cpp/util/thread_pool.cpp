#include "util/thread_pool.h"

#include <algorithm>
#include <cstdlib>

namespace novaenhance {

namespace {
// Phones top out at 8 cores today; more threads than this only adds contention
// on the shared L2/L3 and heat. Also bounds per-thread scratch memory.
constexpr int kMaxPoolThreads = 8;
}  // namespace

ThreadPool& ThreadPool::instance() {
    static ThreadPool pool;
    return pool;
}

ThreadPool::ThreadPool() {
    const unsigned hw = std::thread::hardware_concurrency();
    int threads = hw == 0 ? 4 : static_cast<int>(hw);
    // Diagnostics/benchmark override (like OMP_NUM_THREADS). Lets the host verification tools
    // exercise the real multi-threaded paths even on a single-core CI box.
    if (const char* env = std::getenv("NOVA_NN_THREADS")) {
        const int requested = std::atoi(env);
        if (requested >= 1) threads = requested;
    }
    maxThreads_ = std::clamp(threads, 1, kMaxPoolThreads);
    workers_.reserve(static_cast<size_t>(maxThreads_ - 1));
    for (int i = 1; i < maxThreads_; ++i) {
        workers_.emplace_back([this] { workerLoop(); });
    }
}

ThreadPool::~ThreadPool() {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        stop_ = true;
    }
    wake_.notify_all();
    for (auto& t : workers_) {
        if (t.joinable()) t.join();
    }
}

void ThreadPool::workerLoop() {
    uint64_t seen = 0;
    for (;;) {
        Task* task = nullptr;
        int slot = 0;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            wake_.wait(lock, [&] { return stop_ || generation_ != seen; });
            if (stop_) return;
            seen = generation_;
            task = current_;
            if (task == nullptr) continue;  // the call already finished before this thread woke up
            slot = task->nextSlot.fetch_add(1, std::memory_order_relaxed);
            if (slot >= task->participants) continue;  // enough threads already on this task
            ++task->active;
        }

        for (;;) {
            const int job = task->nextJob.fetch_add(1, std::memory_order_relaxed);
            if (job >= task->jobs) break;
            (*task->fn)(job, slot);
        }

        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (--task->active == 0) done_.notify_all();
        }
    }
}

void ThreadPool::parallelFor(int jobs, int threads, const std::function<void(int, int)>& fn) {
    if (jobs <= 0) return;
    if (threads <= 0) threads = maxThreads_;
    threads = std::min({threads, maxThreads_, jobs});

    if (threads == 1) {
        for (int j = 0; j < jobs; ++j) fn(j, 0);
        return;
    }

    std::lock_guard<std::mutex> serialize(callMutex_);

    Task task;
    task.fn = &fn;
    task.jobs = jobs;
    task.participants = threads;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        current_ = &task;
        ++generation_;
    }
    wake_.notify_all();

    // The caller is worker 0 and takes jobs like everybody else.
    for (;;) {
        const int job = task.nextJob.fetch_add(1, std::memory_order_relaxed);
        if (job >= jobs) break;
        fn(job, 0);
    }

    // Wait for workers still inside their last job, then retract the task so a
    // late-waking worker cannot touch this (stack-allocated) object.
    std::unique_lock<std::mutex> lock(mutex_);
    done_.wait(lock, [&] { return task.active == 0; });
    current_ = nullptr;
}

}  // namespace novaenhance
