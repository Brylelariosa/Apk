package com.novaenhance.ai.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MAX_TRACE_BYTES = 256 * 1024

/** "2026-10-02 14:03:41" - a fresh formatter each call, because SimpleDateFormat is not thread-safe. */
internal fun logStamp(millis: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(millis))

/** One entry of Android's own record of how an earlier run of this app's process ended. */
data class ExitRecord(
    val timestamp: Long,
    val pid: Int,
    val reason: Int,
    val status: Int,
    val importance: Int,
    val description: String,
    val rssKb: Long,
    val pssKb: Long,
    /** Readable strings pulled out of the system's crash/ANR trace for this exit, if it kept one. */
    val traceHint: String? = null
)

/**
 * Reads Android's own "how did the last runs of this app end?" record (ActivityManager
 * .getHistoricalProcessExitReasons, Android 11+). This is what makes crashes visible that no in-process
 * code can ever catch: a native (C++) crash, or Android killing the app because the phone ran out of
 * memory. In both cases the process is simply gone - but the system remembers the reason, the signal
 * number and how much memory the process held, and hands it back on the next launch.
 *
 * Everything here is best-effort and swallows its own failures: on Android 10 (our minSdk) the API does
 * not exist and [recent] just returns an empty list.
 */
object ProcessExitHistory {

    fun recent(context: Context, max: Int): List<ExitRecord> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return emptyList()
        return try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val infos = manager.getHistoricalProcessExitReasons(context.packageName, 0, max)
            infos.mapIndexed { index, info ->
                val wantsTrace = index < 2 && (info.reason == 5 || info.reason == 6)
                ExitRecord(
                    timestamp = info.timestamp,
                    pid = info.pid,
                    reason = info.reason,
                    status = info.status,
                    importance = info.importance,
                    description = info.description ?: "",
                    rssKb = info.rss,
                    pssKb = info.pss,
                    traceHint = if (wantsTrace) readTraceHint(info) else null
                )
            }
        } catch (t: Throwable) {
            emptyList()
        }
    }

    private fun readTraceHint(info: android.app.ApplicationExitInfo): String? {
        return try {
            val input = info.traceInputStream ?: return null
            val bytes = input.use { stream ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (total < MAX_TRACE_BYTES) {
                    val read = stream.read(buffer)
                    if (read < 0) break
                    out.write(buffer, 0, read)
                    total += read
                }
                out.toByteArray()
            }
            if (info.reason == 6) {
                // ANR traces are plain text: the first screenful names the busy thread and where it was stuck.
                String(bytes, Charsets.UTF_8).lineSequence().take(60).joinToString("\n")
            } else {
                // Android 12+ stores native-crash tombstones as protobuf. Rather than parse it, pull out the
                // readable strings: signal name, abort message, thread name, library and function names.
                printableStrings(bytes).joinToString("\n")
            }
        } catch (t: Throwable) {
            null
        }
    }

    internal fun printableStrings(bytes: ByteArray, minLength: Int = 6, maxItems: Int = 60): List<String> {
        val found = LinkedHashSet<String>()
        val current = StringBuilder()

        fun flush() {
            if (current.length >= minLength && found.size < maxItems) {
                val text = current.toString()
                val looksLikeBuildId = text.length >= 20 && text.all { it in '0'..'9' || it in 'a'..'f' }
                if (!looksLikeBuildId) found.add(text.take(160))
            }
            current.setLength(0)
        }

        for (b in bytes) {
            val c = b.toInt() and 0xFF
            if (c in 32..126) current.append(c.toChar()) else flush()
        }
        flush()
        return found.toList()
    }

    fun reasonName(reason: Int): String = when (reason) {
        0 -> "UNKNOWN"
        1 -> "EXIT_SELF"
        2 -> "SIGNALED"
        3 -> "LOW_MEMORY"
        4 -> "CRASH"
        5 -> "CRASH_NATIVE"
        6 -> "ANR"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        14 -> "FREEZER"
        15 -> "PACKAGE_STATE_CHANGE"
        16 -> "PACKAGE_UPDATED"
        else -> "reason $reason"
    }

    fun signalName(signal: Int): String = when (signal) {
        4 -> "SIGILL (4)"
        6 -> "SIGABRT (6)"
        7 -> "SIGBUS (7)"
        8 -> "SIGFPE (8)"
        9 -> "SIGKILL (9)"
        11 -> "SIGSEGV (11)"
        13 -> "SIGPIPE (13)"
        15 -> "SIGTERM (15)"
        else -> "signal $signal"
    }

    private fun importanceName(importance: Int): String = when {
        importance <= 100 -> "in the foreground"
        importance <= 130 -> "running a foreground service"
        importance <= 200 -> "visible"
        importance <= 230 -> "perceptible"
        importance <= 300 -> "a background service"
        else -> "cached in the background"
    }

    /**
     * Whether this exit looks like a problem (as opposed to the user swiping the app away, or Android quietly
     * reclaiming memory from an app sitting in the background). [hadUnfinishedWork] is the app's own on-disk
     * log saying it was mid-enhancement (or had logged a Java crash) when it stopped.
     */
    fun isAbnormal(record: ExitRecord, hadUnfinishedWork: Boolean): Boolean = when (record.reason) {
        4, 5, 6, 7, 9, 12 -> true
        0, 2, 3, 13 -> record.importance <= 230 || hadUnfinishedWork
        else -> false
    }

    fun plainEnglish(record: ExitRecord?, hadUnfinishedWork: Boolean, javaCrash: Boolean): String {
        val cause = when {
            record == null && javaCrash ->
                "A Java/Kotlin exception crashed the app (stack trace is in the 'Last Java crash' section)."
            record == null ->
                "The app stopped without logging a Java crash and Android did not say why."
            record.reason == 5 -> when (record.status) {
                11 -> "A native (C++) crash: SIGSEGV - the code touched memory it must not."
                6 -> "A native (C++) abort: SIGABRT - usually an uncaught C++ exception (for example running out of memory inside native code), a failed assertion, or a JNI error."
                7 -> "A native (C++) crash: SIGBUS - a bad memory access."
                else -> "A native (C++) crash: ${signalName(record.status)}."
            }
            record.reason == 4 ->
                "A Java/Kotlin exception crashed the app (stack trace is in the 'Last Java crash' section)."
            record.reason == 3 ->
                "Android ran low on memory and killed the app."
            record.reason == 2 ->
                if (record.status == 9) {
                    "The app was force-killed (SIGKILL) - usually Android's low-memory killer or a battery/RAM manager."
                } else {
                    "The app was killed by ${signalName(record.status)}."
                }
            record.reason == 6 -> "The app stopped responding (ANR)."
            record.reason == 9 -> "Android killed the app for using too many resources."
            record.reason == 7 -> "The app failed while starting up."
            else -> "Android stopped the app (${reasonName(record.reason)})."
        }
        return if (hadUnfinishedWork) "$cause It was in the middle of enhancing a photo." else cause
    }

    fun oneLine(record: ExitRecord): String {
        val signal = when {
            record.reason == 5 || record.reason == 2 -> " ${signalName(record.status)}"
            record.status != 0 -> " status=${record.status}"
            else -> ""
        }
        val memory = if (record.rssKb > 0L) ", held ${record.rssKb / 1024}MB RAM" else ""
        val description = if (record.description.isNotBlank()) " \"${record.description.take(80)}\"" else ""
        return "${logStamp(record.timestamp)}  ${reasonName(record.reason)}$signal  " +
            "(${importanceName(record.importance)}$memory, pid ${record.pid})$description"
    }
}
