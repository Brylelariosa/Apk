package com.novaenhance.ai.utils

/**
 * Central home for tunables that would otherwise be duplicated/hardcoded
 * across the AI engine, training engine, and workers. Nothing in this file
 * is a hardcoded *path* - storage locations always go through [com.novaenhance.ai.storage.AppStorage],
 * which resolves them from Android's Context APIs at runtime.
 */
object Constants {

    // --- Tile-based processing (keeps peak memory bounded on 4GB devices) ---
    // Must match NativeNeuralEngine.TILE_SIZE exactly - the network's input
    // size is fixed at compile time (see app/src/main/cpp/nn/network.h),
    // not configurable per-model.
    const val TILE_SIZE_PX = 64

    // Enhancing a large image runs the network over whole full-width bands of rows (BandProcessor) rather than
    // 64px tiles: memory stays bounded, yet results have no tile seams. A band's native working set is a few
    // MB per array; taller bands mean less redundant context-row work (BandProcessor re-reads a handful of
    // rows above/below each band), shorter ones mean finer progress/cancellation/thermal-pacing granularity.
    const val BAND_ROWS_PX = 256

    // --- Training defaults (starting points for the adaptive controller) ---
    // WARNING: this architecture's clip[0,1] output activation has zero
    // gradient outside that range, so a learning rate that's too high can
    // saturate the network and get it permanently stuck (verified
    // empirically, not just theoretically - see the comment on
    // clip01BackwardFromPre in nn/network.cpp and
    // tools/nn_verification/lr_saturation_check.cpp). 1e-4 is safely inside
    // the working range (confirmed up to 1.5x this, the adaptive
    // controller's ceiling, under a stress test far harsher than real
    // training); 0.02 reliably breaks within ~30 steps. Don't raise this
    // without re-running that check.
    const val DEFAULT_LEARNING_RATE = 1e-4f
    const val DEFAULT_BATCH_SIZE = 4
    const val DEFAULT_EPOCHS = 3
    const val MIN_BATCH_SIZE = 1
    const val MAX_BATCH_SIZE = 16

    // Training patches cut from every (low, high) image pair per optimizer step, each from the same
    // decoded crop but at its own random position and flip/rotation (TrainingPatchLoader). Decoding a
    // crop out of a JPEG costs about the same whether it yields one patch or four, and the native
    // training step is now fast enough that disk/decode - not math - is what a session waits on.
    const val TRAINING_PATCHES_PER_PAIR = 4
    const val TRAINING_PATCHES_PER_PAIR_REDUCED = 2

    // --- Adaptive controller thresholds ---
    const val LOW_RAM_THRESHOLD_MB = 2048L
    const val CRITICAL_RAM_THRESHOLD_MB = 1024L

    // --- Graduated thermal throttling (see ThermalGovernor.evaluate) ---
    // Below THERMAL_STATUS_SEVERE, the old behavior was "run flat out" -
    // these let CPU-bound work (training batches, validation/rescoring
    // passes, and tile-based image enhancement) ease off progressively
    // instead of pinning every available core until Android's own thermal
    // manager forces SEVERE. Chosen to be a small, close-to-free tax when
    // the device is only mildly warm (MODERATE) and a much more assertive
    // one once thermalProtectionEnabled is off but the device is already at
    // SEVERE (that setting only opts out of the hard PAUSE, not out of
    // easing off at all).
    const val THERMAL_COOLDOWN_MODERATE_MS = 300L
    const val THERMAL_COOLDOWN_SEVERE_UNPROTECTED_MS = 1_500L
    const val THERMAL_CONCURRENCY_MODERATE = 2
    const val THERMAL_CONCURRENCY_SEVERE_UNPROTECTED = 1

    // --- Experience replay (anti-forgetting) ---
    const val REPLAY_BUFFER_MAX_SIZE = 200
    const val REPLAY_BATCH_FRACTION = 0.25f // fraction of each batch drawn from replay buffer

    // --- Dataset analysis ---
    const val PERCEPTUAL_HASH_SIZE = 8 // 8x8 -> 64-bit dHash
    const val DUPLICATE_HASH_DISTANCE_THRESHOLD = 5 // Hamming distance
    const val MIN_VALID_PAIR_SIMILARITY = 0.15f // below this, pair is likely mismatched content
    const val MAX_VALID_PAIR_SIMILARITY = 0.98f // above this, pair has no enhancement signal
    // Every metric analyzeNewPairs computes (perceptual hash, sharpness,
    // quick-similarity) internally downsamples further to <=128px anyway,
    // so decoding at full camera resolution just to shrink it again was
    // pure wasted decode time; this is generous headroom above that 128px
    // ceiling with no measurable effect on the scores themselves.
    const val DATASET_ANALYSIS_DECODE_TARGET_PX = 256

    // --- Model file layout (relative to app-private external files dir) ---
    const val MODELS_DIR = "models"
    const val CHECKPOINTS_DIR = "checkpoints"
    const val BACKUPS_DIR = "model_backups"
    const val DATASET_DIR = "datasets"

    // --- Notification channels ---
    const val NOTIFICATION_CHANNEL_TRAINING = "novaenhance_training"
    const val TRAINING_NOTIFICATION_ID = 1001

    // --- WorkManager unique work names ---
    const val WORK_NAME_TRAINING = "novaenhance_training_work"
    const val WORK_NAME_DATASET_ANALYSIS = "novaenhance_dataset_analysis_work"
}
