package com.novaenhance.ai.ai.engine

import kotlin.math.min

/**
 * Small shared helpers for working with fixed-size ARGB tile buffers - the
 * pad/crop logic [com.novaenhance.ai.training.trainer.ModelTrainer]'s
 * random-patch extraction for training batches needs.
 */
object PixelBufferOps {

    /** Pads a `srcW x srcH` tile up to `targetSize x targetSize` by replicating edge pixels. */
    fun padByReplication(pixels: IntArray, srcW: Int, srcH: Int, targetSize: Int): IntArray {
        if (srcW == targetSize && srcH == targetSize) return pixels
        val out = IntArray(targetSize * targetSize)
        for (y in 0 until targetSize) {
            val sy = min(y, srcH - 1)
            for (x in 0 until targetSize) {
                val sx = min(x, srcW - 1)
                out[y * targetSize + x] = pixels[sy * srcW + sx]
            }
        }
        return out
    }

    /** Copies the `w x h` rectangle whose top-left corner is (`x`, `y`) out of a `srcW`-wide pixel buffer. */
    fun cropRect(pixels: IntArray, srcW: Int, x: Int, y: Int, w: Int, h: Int): IntArray {
        val out = IntArray(w * h)
        for (row in 0 until h) {
            System.arraycopy(pixels, (y + row) * srcW + x, out, row * w, w)
        }
        return out
    }

    /**
     * Applies one of the 8 symmetries of the square (the dihedral group: four 90-degree rotations, each
     * with or without a mirror) to a `size x size` tile. [orientation] 0 is the identity and returns
     * [pixels] itself; 1..3 rotate clockwise by 90/180/270 degrees; 4..7 mirror left-right first and then
     * rotate by orientation - 4 quarter turns.
     *
     * Used for training augmentation: image restoration is equivariant to these transforms, so applying
     * the SAME orientation to a (degraded, clean) pair yields a new, equally valid training pair for free
     * - the standard way to stretch a small photo collection (see TrainingPatchLoader).
     */
    fun transformSquare(pixels: IntArray, size: Int, orientation: Int): IntArray {
        require(orientation in 0..7) { "orientation must be in 0..7, got $orientation" }
        if (orientation == 0) return pixels
        val quarterTurns = orientation and 3
        val mirror = orientation >= 4
        val out = IntArray(size * size)
        for (y in 0 until size) {
            for (x in 0 until size) {
                // Walk backwards from the destination pixel to where it came from: undo each clockwise
                // quarter turn (a pixel at (row, col) moved to (col, size-1-row), so the pixel that
                // landed at (y, x) came from (size-1-x, y)), then undo the mirror.
                var sy = y
                var sx = x
                repeat(quarterTurns) {
                    val ny = size - 1 - sx
                    val nx = sy
                    sy = ny
                    sx = nx
                }
                if (mirror) sx = size - 1 - sx
                out[y * size + x] = pixels[sy * size + sx]
            }
        }
        return out
    }

    /** Crops the top-left `w x h` region out of a `srcSize x srcSize` tile. */
    fun cropTopLeft(pixels: IntArray, srcSize: Int, w: Int, h: Int): IntArray {
        if (w == srcSize && h == srcSize) return pixels
        val out = IntArray(w * h)
        for (y in 0 until h) {
            System.arraycopy(pixels, y * srcSize, out, y * w, w)
        }
        return out
    }
}
