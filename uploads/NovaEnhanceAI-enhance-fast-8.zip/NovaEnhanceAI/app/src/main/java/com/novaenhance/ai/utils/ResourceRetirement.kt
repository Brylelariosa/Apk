package com.novaenhance.ai.utils

import java.util.Collections
import java.util.IdentityHashMap

/**
 * Disposes of a shared resource - in this app, a [android.graphics.Bitmap] - only once that is actually safe:
 * its owner has [retire]d it AND every [hold] taken on it has been [release]d.
 *
 * Why it exists: "no longer the current value in the UI state" does not mean "nobody uses it any more".
 * A native enhancement pass may still be reading the pixels, a gallery save may still be compressing them, and
 * Compose may still redraw from a draw lambda that captured them. Recycling while any of those is true crashes
 * with "Canvas: trying to use a recycled bitmap".
 *
 * Holds are COUNTED, not just present/absent. Two overlapping users of the same instance are normal (a slider
 * drag starts a second enhancement while the first is still inside its native call, both reading the same
 * original). With a plain set, the first one finishing would drop the resource from it while the second is still
 * reading - and a [retire] landing in that gap would dispose a resource in active use.
 *
 * Contract for UI holders (the part that went wrong before): report [release] from the SAME composition that owns
 * the draw code using the resource, never from a parent composition. Compose applies a parent and a
 * subcomposition (BoxWithConstraints, Scaffold, ...) on different frames, so a release reported from the parent
 * can arrive while the child's draw lambda still captures the old instance. See BeforeAfterSlider.
 *
 * Thread-confined by design: call every method from one thread (the main thread in this app) - no locking.
 * Resources are matched by identity, never by equals().
 *
 * @param dispose frees a resource (e.g. `{ it.recycle() }`); called at most once per [retire].
 * @param log optional sink for one-line lifecycle messages (see the in-app crash log's breadcrumbs).
 * @param label short, stable-per-instance name used in [log] messages.
 */
class ResourceRetirement<T : Any>(
    private val dispose: (T) -> Unit,
    private val log: (String) -> Unit = {},
    private val label: (T) -> String = { Integer.toHexString(System.identityHashCode(it)) }
) {
    private val holdCounts = IdentityHashMap<T, Int>()
    private val awaitingRelease: MutableSet<T> = Collections.newSetFromMap(IdentityHashMap<T, Boolean>())

    /** Something started using [resource]; it will not be disposed until the matching [release]. */
    fun hold(resource: T) {
        holdCounts[resource] = (holdCounts[resource] ?: 0) + 1
    }

    /** The matching end of one [hold]. Disposes [resource] now if it was already retired and this was the last hold. */
    fun release(resource: T) {
        val remaining = (holdCounts[resource] ?: 0) - 1
        if (remaining > 0) holdCounts[resource] = remaining else holdCounts.remove(resource)
        if (resource in awaitingRelease && !isHeld(resource)) {
            awaitingRelease -= resource
            dispose(resource)
            log("disposed ${label(resource)} on last release")
        }
    }

    /**
     * The owner no longer publishes [resource] anywhere. Disposes it now if nothing holds it, otherwise defers
     * to whichever [release] brings its hold count to zero. Retiring an instance that is still held more than
     * once is harmless (it is disposed once); retire each instance once, since after disposal a second call
     * would call [dispose] again.
     */
    fun retire(resource: T?) {
        resource ?: return
        if (isHeld(resource)) {
            awaitingRelease += resource
            log("retire ${label(resource)}: deferred, hold count ${holdCounts[resource]}")
        } else {
            dispose(resource)
            log("retire ${label(resource)}: disposed immediately (unheld)")
        }
    }

    /** Runs [block] with [resource] held, releasing it afterwards even if [block] throws or is cancelled. */
    inline fun <R> withHold(resource: T, block: () -> R): R {
        hold(resource)
        try {
            return block()
        } finally {
            release(resource)
        }
    }

    private fun isHeld(resource: T) = (holdCounts[resource] ?: 0) > 0
}
