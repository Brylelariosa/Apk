package com.novaenhance.ai.training.trainer

import android.graphics.Rect
import com.novaenhance.ai.ai.engine.PixelBufferOps
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.decodeBitmapBounds
import com.novaenhance.ai.utils.decodeBitmapRegion
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlin.random.Random

private const val TAG = "TrainingPatchLoader"

/** One aligned (degraded, clean) training patch pair, already padded to the model's tile size. */
class PatchPair(val low: IntArray, val high: IntArray)

/**
 * Turns a batch of (low-quality path, high-quality path) pairs into training patches, off the thread
 * that runs the optimizer.
 *
 * Three things make this much cheaper per unit of learning than the one-region-per-pair decode it
 * replaces:
 *
 *  1. Prefetch. [loadAsync] starts decoding a batch on [scope] and returns immediately, so the trainer
 *     can load batch N+1 while the native step for batch N is running. With the step now several times
 *     faster, waiting for JPEG region decodes on the same thread would have become the bottleneck.
 *  2. Decode once, cut many. Each pair is decoded as ONE crop a few tiles wide and [patchesPerPair]
 *     patches are cut from it at random positions. Decoding a crop out of a JPEG costs about the same
 *     whether it yields one patch or four.
 *  3. Free augmentation. Every patch gets a random one of the 8 square symmetries (rotations and
 *     mirrors), applied identically to the degraded and the clean patch. Restoration is equivariant to
 *     them, so each is a new, equally valid training pair - the standard way to stretch a small photo
 *     collection.
 *
 * The pairs of one batch are decoded in parallel; [scope] should use an I/O dispatcher and be cancelled
 * when the session ends, which also abandons any prefetch still in flight.
 */
class TrainingPatchLoader(
    private val tileSize: Int,
    private val patchesPerPair: Int,
    private val scope: CoroutineScope,
    private val random: Random
) {

    init {
        require(tileSize > 0) { "tileSize must be positive, got $tileSize" }
        require(patchesPerPair > 0) { "patchesPerPair must be positive, got $patchesPerPair" }
    }

    /** Side of the square crop decoded per pair: wide enough that its patches differ, small enough to stay cheap. */
    private val cropSize: Int get() = CROP_TILES * tileSize

    /**
     * Starts decoding [batch] and returns at once. The result holds up to `batch.size * patchesPerPair`
     * patches - fewer (possibly none) if some pairs fail to decode, which are skipped and logged.
     */
    fun loadAsync(batch: List<Pair<String, String>>): Deferred<List<PatchPair>> {
        // Seeds are drawn here, on the caller's thread: kotlin.random.Random instances are not
        // thread-safe, so each parallel decode gets its own generator.
        val seeds = LongArray(batch.size) { random.nextLong() }
        return scope.async {
            batch.indices
                .map { i -> async { loadPair(batch[i].first, batch[i].second, Random(seeds[i])) } }
                .awaitAll()
                .flatten()
        }
    }

    private fun loadPair(lowPath: String, highPath: String, rng: Random): List<PatchPair> {
        val lowBounds = decodeBitmapBounds(lowPath) ?: return emptyList()
        val highBounds = decodeBitmapBounds(highPath) ?: return emptyList()

        val w = minOf(lowBounds.width, highBounds.width)
        val h = minOf(lowBounds.height, highBounds.height)
        if (w <= 0 || h <= 0) return emptyList()

        val cropW = minOf(cropSize, w)
        val cropH = minOf(cropSize, h)
        val x = if (w > cropW) rng.nextInt(w - cropW + 1) else 0
        val y = if (h > cropH) rng.nextInt(h - cropH + 1) else 0
        val region = Rect(x, y, x + cropW, y + cropH)

        val lowBitmap = decodeBitmapRegion(lowPath, region) ?: run {
            NovaLog.w(TAG, "Failed to decode training region $lowPath")
            return emptyList()
        }
        val highBitmap = decodeBitmapRegion(highPath, region) ?: run {
            NovaLog.w(TAG, "Failed to decode training region $highPath")
            lowBitmap.recycle()
            return emptyList()
        }

        try {
            val lowCrop = IntArray(cropW * cropH)
            val highCrop = IntArray(cropW * cropH)
            lowBitmap.getPixels(lowCrop, 0, cropW, 0, 0, cropW, cropH)
            highBitmap.getPixels(highCrop, 0, cropW, 0, 0, cropW, cropH)
            return List(patchesPerPair) { cutPatch(lowCrop, highCrop, cropW, cropH, rng) }
        } finally {
            lowBitmap.recycle()
            highBitmap.recycle()
        }
    }

    private fun cutPatch(lowCrop: IntArray, highCrop: IntArray, cropW: Int, cropH: Int, rng: Random): PatchPair {
        // A crop smaller than a tile (a tiny source photo) yields a smaller patch, padded back up by
        // edge replication exactly as before.
        val patchW = minOf(tileSize, cropW)
        val patchH = minOf(tileSize, cropH)
        val px = if (cropW > patchW) rng.nextInt(cropW - patchW + 1) else 0
        val py = if (cropH > patchH) rng.nextInt(cropH - patchH + 1) else 0

        val low = PixelBufferOps.padByReplication(PixelBufferOps.cropRect(lowCrop, cropW, px, py, patchW, patchH), patchW, patchH, tileSize)
        val high = PixelBufferOps.padByReplication(PixelBufferOps.cropRect(highCrop, cropW, px, py, patchW, patchH), patchW, patchH, tileSize)

        val orientation = rng.nextInt(ORIENTATIONS)
        return PatchPair(
            PixelBufferOps.transformSquare(low, tileSize, orientation),
            PixelBufferOps.transformSquare(high, tileSize, orientation)
        )
    }

    private companion object {
        const val CROP_TILES = 4
        const val ORIENTATIONS = 8
    }
}
