package com.novaenhance.ai.utils

import android.util.Log
import com.novaenhance.ai.BuildConfig
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MAX_HISTORY_LINES = 300

/**
 * Thin wrapper around [android.util.Log] that no-ops verbose/debug logs in
 * release builds. Kept intentionally tiny - this is not a logging framework,
 * just a seam so we're not sprinkling `if (BuildConfig.DEBUG)` everywhere.
 *
 * Also keeps the last [MAX_HISTORY_LINES] lines (every level, including
 * debug, regardless of build type) in memory so [DiagnosticsReport] can
 * include real recent activity - tile-processing/dataset-analysis timings,
 * training failures, etc. - in a report the user can copy out of Settings.
 *
 * Every line is ALSO written through to [PersistentLog]'s on-disk file, so
 * what the app was doing right before a crash or a low-memory kill is still
 * there on the next launch (see the in-app Crash Log screen). That file is
 * private to the app and only leaves the device if the user taps Copy/Share.
 * This is purely additive: every existing `NovaLog.x(...)` call site is
 * unaffected.
 */
object NovaLog {
    private const val GLOBAL_TAG = "NovaEnhance"
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private val history = ArrayDeque<String>()

    private fun record(level: Char, tag: String, message: String, throwable: Throwable?) {
        val line = synchronized(history) {
            if (history.size >= MAX_HISTORY_LINES) history.removeFirst()
            val timestamp = timeFormat.format(Date(System.currentTimeMillis()))
            val throwableSuffix = throwable?.let { " - ${it::class.simpleName}: ${it.message}" } ?: ""
            val formatted = "$timestamp $level/$tag: $message$throwableSuffix"
            history.addLast(formatted)
            formatted
        }
        PersistentLog.append(line)
        if (throwable != null) PersistentLog.appendThrowable(throwable)
    }

    /** Recent log lines, oldest first, for display or export - see [DiagnosticsReport]. */
    fun recentHistory(): List<String> = synchronized(history) { history.toList() }

    /**
     * "What am I doing right now" marker for high-frequency steps (per-band progress, which native filter is
     * about to run). Goes ONLY to the on-disk crash log - not logcat, not the in-memory history above - so it
     * can be as chatty as needed without pushing real log lines out of [DiagnosticsReport].
     */
    fun breadcrumb(tag: String, message: String) {
        val timestamp = synchronized(history) { timeFormat.format(Date(System.currentTimeMillis())) }
        PersistentLog.append("$timestamp B/$tag: $message")
    }

    fun d(tag: String, message: String) {
        record('D', tag, message, null)
        if (BuildConfig.DEBUG) Log.d("$GLOBAL_TAG:$tag", message)
    }

    fun i(tag: String, message: String) {
        record('I', tag, message, null)
        Log.i("$GLOBAL_TAG:$tag", message)
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        record('W', tag, message, throwable)
        Log.w("$GLOBAL_TAG:$tag", message, throwable)
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        record('E', tag, message, throwable)
        Log.e("$GLOBAL_TAG:$tag", message, throwable)
    }
}
