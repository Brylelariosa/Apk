package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.MemoryStats
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

private const val TAG = "BandProcessor"

/**
 * Applies a neighbourhood operation (the network, blur, bilateral denoise ...) to a large bitmap in
 * full-width horizontal BANDS, so peak memory stays bounded whatever the photo's resolution - while,
 * unlike the 64px-tile pass this replaced, leaving no seams.
 *
 * Why no seams: every band is handed to [process]'s callback together with [contextRows] extra REAL
 * rows of image above and below it (wherever the image has them), and only the band's own rows are
 * written to the output. Pixels near a band edge are therefore computed from their true neighbours,
 * exactly as if the whole image had been processed in one go. The old tile pass computed every tile
 * edge from zero-padded or clamped data and then feathered the overlap, which left visible grid
 * artifacts, and it recomputed a ~30% overlap of every tile besides.
 *
 * The callback does its own parallelism (the native engine fans a band out over worker threads), so
 * bands run strictly one after another. Between bands this class consults [thermalGovernor] - the
 * same pacing the old tile chunks got, so a manual "Enhance" on a hot phone backs off exactly like
 * training's own validation passes do - and checks `isStale`, so a request superseded by a newer
 * slider change stops within one band's work instead of finishing the whole image.
 */
class BandProcessor(
    private val thermalGovernor: ThermalGovernor? = null,
    private val bandRows: Int = Constants.BAND_ROWS_PX
) {

    init {
        require(bandRows > 0) { "bandRows must be positive, got $bandRows" }
    }

    data class BandProgress(val rowsDone: Int, val rowsTotal: Int)

    /**
     * @param contextRows real image rows to supply above and below each band (clipped at the image's
     *   top/bottom). Must be at least the vertical reach of the operation in [processBand].
     * @param threadCeiling most native worker threads a band may use; [thermalGovernor] can only
     *   narrow this, never widen it.
     * @param processBand receives a band's pixels INCLUDING its context rows (ARGB_8888, row-major,
     *   `width` x `height` of the band-with-context) and the thread budget for this band; must return
     *   the processed pixels for exactly the same rows. The context rows are dropped afterwards.
     */
    suspend fun process(
        source: Bitmap,
        contextRows: Int,
        threadCeiling: Int,
        onProgress: ((BandProgress) -> Unit)? = null,
        isStale: () -> Boolean = { false },
        processBand: suspend (pixels: IntArray, width: Int, height: Int, threads: Int) -> IntArray
    ): Bitmap {
        require(contextRows >= 0) { "contextRows must not be negative, got $contextRows" }
        val startMs = System.currentTimeMillis()
        val width = source.width
        val height = source.height
        NovaLog.breadcrumb(
            TAG,
            "process ${width}x$height: allocating output bitmap (~${width.toLong() * height * 4L / (1024L * 1024L)}MB), " +
                "bands of $bandRows rows + $contextRows context | ${MemoryStats.summary()}"
        )
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        try {
            var pacedBands = 0
            var bands = 0
            var y0 = 0
            while (y0 < height) {
                if (isStale()) throw CancellationException("Enhancement superseded - aborting before the next band")

                val threads = if (thermalGovernor != null) {
                    val decision = thermalGovernor.evaluate(concurrencyCeiling = threadCeiling)
                    if (decision.action == ThermalGovernor.ThrottleAction.PAUSE) {
                        // There is no meaningful "pause" for one image mid-flight - back off as hard as
                        // the worst COOL_DOWN case instead of abandoning the result.
                        pacedBands++
                        delay(Constants.THERMAL_COOLDOWN_SEVERE_UNPROTECTED_MS)
                    } else if (decision.action == ThermalGovernor.ThrottleAction.COOL_DOWN) {
                        pacedBands++
                        delay(decision.cooldownMillis)
                    }
                    decision.maxConcurrency
                } else {
                    threadCeiling
                }

                val y1 = min(height, y0 + bandRows)
                val top = max(0, y0 - contextRows)
                val bottom = min(height, y1 + contextRows)
                val withContextHeight = bottom - top
                NovaLog.breadcrumb(
                    TAG,
                    "band ${bands + 1} rows $y0-$y1 (with context $top-$bottom, ${width}x$withContextHeight) threads=$threads | ${MemoryStats.summary()}"
                )

                val processed = withContext(Dispatchers.Default) {
                    val pixels = IntArray(width * withContextHeight)
                    source.getPixels(pixels, 0, width, 0, top, width, withContextHeight)
                    val result = processBand(pixels, width, withContextHeight, threads)
                    require(result.size == pixels.size) {
                        "processBand returned ${result.size} pixels for a ${width}x$withContextHeight band"
                    }
                    result
                }
                // Skip the context rows on the way out: start at the band's own first row.
                output.setPixels(processed, (y0 - top) * width, width, 0, y0, width, y1 - y0)

                bands++
                y0 = y1
                onProgress?.invoke(BandProgress(y0, height))
            }

            val pacingNote = if (pacedBands > 0) ", eased off for $pacedBands band(s) on thermal state" else ""
            NovaLog.i(
                TAG,
                "Processed ${width}x$height in $bands band(s) of up to $bandRows rows " +
                    "(+$contextRows context rows, up to $threadCeiling threads$pacingNote) " +
                    "in ${System.currentTimeMillis() - startMs}ms"
            )
            return output
        } catch (t: Throwable) {
            // Covers the isStale() abort as much as any other failure: output is a full-resolution
            // bitmap nothing else references yet - free its native memory now instead of waiting for GC.
            output.recycle()
            throw t
        }
    }
}
