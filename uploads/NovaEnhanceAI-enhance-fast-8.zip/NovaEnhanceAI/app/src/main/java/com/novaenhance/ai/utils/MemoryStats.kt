package com.novaenhance.ai.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Debug

private const val MB = 1024L * 1024L

/**
 * One-line "how much memory is in use right now" snapshot for the crash log's breadcrumbs. When the app is
 * killed for memory, the trend across the last few breadcrumbs (java heap, native heap, free system RAM)
 * is usually the whole story.
 */
object MemoryStats {

    @Volatile
    private var appContext: Context? = null

    fun attach(context: Context) {
        appContext = context.applicationContext
    }

    fun summary(): String {
        return try {
            val runtime = Runtime.getRuntime()
            val javaUsedMb = (runtime.totalMemory() - runtime.freeMemory()) / MB
            val javaMaxMb = runtime.maxMemory() / MB
            val nativeMb = Debug.getNativeHeapAllocatedSize() / MB
            val context = appContext
            val system = if (context != null) {
                val info = ActivityManager.MemoryInfo()
                (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(info)
                " sysFree=${info.availMem / MB}MB${if (info.lowMemory) " LOW" else ""}"
            } else {
                ""
            }
            "mem java=$javaUsedMb/${javaMaxMb}MB native=${nativeMb}MB$system"
        } catch (t: Throwable) {
            "mem unavailable"
        }
    }
}
