package com.novaenhance.ai.utils

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream

private const val TAG = "PersistentLog"
private const val CURRENT_FILE = "session_log.txt"
private const val PREVIOUS_FILE = "previous_session_log.txt"
private const val MAX_BYTES = 160 * 1024
private const val KEEP_BYTES = 64 * 1024
private const val MAX_READ_CHARS = 400_000
private const val MAX_THROWABLE_LINES = 30

/**
 * A small append-only log FILE that survives the process dying - the thing [NovaLog]'s in-memory history
 * cannot do. Every line is written straight through to the file (no buffering), so when the app is killed
 * mid-enhancement - a native crash, Android's low-memory killer, anything - the last thing it wrote is still
 * on disk for the next launch to show in the in-app crash log.
 *
 * One file per process run: [start] (called from [CrashReporter.install]) moves the previous run's file to
 * "previous run" and starts a fresh one. Within a run the file is capped, keeping the newest lines.
 *
 * Never throws and never logs through [NovaLog] (which writes here) - a full disk or a missing file just
 * means lines are dropped.
 */
object PersistentLog {

    private val lock = Any()
    private val enhanceMarker = Regex("ENHANCE_(BEGIN|END|FAIL|CANCEL) gen=(\\d+)")
    private val pidPattern = Regex("pid=(\\d+)")

    @Volatile
    private var directory: File? = null
    private var stream: FileOutputStream? = null
    private var bytesWritten = 0L
    private var header = ""

    /** Moves the last run's log aside (it becomes "previous run") and opens a new one for this run. */
    fun start(context: Context) {
        synchronized(lock) {
            try {
                val dir = context.applicationContext.filesDir
                directory = dir
                val current = File(dir, CURRENT_FILE)
                val previous = File(dir, PREVIOUS_FILE)
                previous.delete()
                if (current.exists()) {
                    if (current.length() > 0L) {
                        if (!current.renameTo(previous)) {
                            previous.writeBytes(current.readBytes())
                            current.delete()
                        }
                    } else {
                        current.delete()
                    }
                }
                header = "=== run started ${logStamp(System.currentTimeMillis())} pid=${android.os.Process.myPid()} ==="
                stream = FileOutputStream(current, false)
                bytesWritten = 0L
                writeLocked(header)
            } catch (t: Throwable) {
                stream = null
                Log.e(TAG, "Could not start the on-disk log", t)
            }
        }
    }

    fun append(line: String) {
        synchronized(lock) { writeLocked(line) }
    }

    /** The first lines of a stack trace, indented under the line that reported it. */
    fun appendThrowable(throwable: Throwable) {
        try {
            val text = Log.getStackTraceString(throwable)
            val lines = text.lineSequence().take(MAX_THROWABLE_LINES).joinToString("\n") { "    $it" }
            append(lines)
        } catch (t: Throwable) {
            // dropping the stack trace is fine; throwing from a logger is not
        }
    }

    private fun writeLocked(line: String) {
        val out = stream ?: return
        try {
            val bytes = (line + "\n").toByteArray(Charsets.UTF_8)
            out.write(bytes)
            bytesWritten += bytes.size
            if (bytesWritten > MAX_BYTES) rollOverLocked()
        } catch (t: Throwable) {
            // disk full or file removed: drop the line
        }
    }

    /** Keeps the run header plus roughly the newest [KEEP_BYTES] of the file. */
    private fun rollOverLocked() {
        val dir = directory ?: return
        val file = File(dir, CURRENT_FILE)
        try {
            stream?.close()
            stream = null
            val all = file.readBytes()
            val from = if (all.size > KEEP_BYTES) all.size - KEEP_BYTES else 0
            var tail = String(all, from, all.size - from, Charsets.UTF_8)
            if (from > 0) {
                val firstNewline = tail.indexOf('\n')
                if (firstNewline >= 0) tail = tail.substring(firstNewline + 1)
            }
            file.writeText(header + "\n... (older lines dropped) ...\n" + tail)
        } catch (t: Throwable) {
            // fall through and just reopen what is there
        }
        try {
            stream = FileOutputStream(file, true)
            bytesWritten = file.length()
        } catch (t: Throwable) {
            stream = null
        }
    }

    /** The previous run's whole log, or "" if there is none. */
    fun previousSessionText(): String = readCapped(PREVIOUS_FILE)

    /** When the previous run last wrote anything (roughly when it died); 0 if there is no previous log. */
    fun previousSessionTimestamp(): Long {
        val dir = directory ?: return 0L
        return try {
            File(dir, PREVIOUS_FILE).lastModified()
        } catch (t: Throwable) {
            0L
        }
    }

    fun currentSessionTail(maxLines: Int): String {
        val text = readCapped(CURRENT_FILE)
        if (text.isEmpty()) return ""
        return text.lineSequence().toList().takeLast(maxLines).joinToString("\n")
    }

    fun clearPrevious() {
        val dir = directory ?: return
        try {
            File(dir, PREVIOUS_FILE).delete()
        } catch (t: Throwable) {
            // nothing to do
        }
    }

    private fun readCapped(name: String): String {
        val dir = directory ?: return ""
        return try {
            val file = File(dir, name)
            if (!file.exists()) {
                ""
            } else {
                val text = file.readText()
                if (text.length > MAX_READ_CHARS) text.takeLast(MAX_READ_CHARS) else text
            }
        } catch (t: Throwable) {
            ""
        }
    }

    /** Process id written in a run's header line, so the run can be matched to Android's exit record. */
    fun pidOf(logText: String): Int? {
        val firstLine = logText.lineSequence().firstOrNull() ?: return null
        return pidPattern.find(firstLine)?.groupValues?.get(1)?.toIntOrNull()
    }

    /**
     * EnhanceViewModel writes ENHANCE_BEGIN / ENHANCE_END / ENHANCE_FAIL / ENHANCE_CANCEL with a generation
     * number around every enhancement. A BEGIN that never got an ending in a run's log means the process
     * died while that enhancement was in flight. Returns that BEGIN line (the newest such one), or null.
     */
    fun interruptedWork(logText: String): String? {
        val openRuns = LinkedHashMap<String, String>()
        for (line in logText.lineSequence()) {
            val match = enhanceMarker.find(line) ?: continue
            val kind = match.groupValues[1]
            val generation = match.groupValues[2]
            if (kind == "BEGIN") openRuns[generation] = line.trim() else openRuns.remove(generation)
        }
        return openRuns.values.lastOrNull()
    }

    fun sawFatalCrash(logText: String): Boolean = logText.contains(" F/CRASH:")
}
