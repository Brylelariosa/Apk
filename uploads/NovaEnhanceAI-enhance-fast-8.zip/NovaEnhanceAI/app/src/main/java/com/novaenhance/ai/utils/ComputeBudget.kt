package com.novaenhance.ai.utils

/**
 * How many native worker threads each kind of job asks for BEFORE [ThermalGovernor] narrows it
 * further for heat / memory pressure (callers pass the result as the governor's
 * `concurrencyCeiling` and run with the `maxConcurrency` it hands back).
 *
 * Kept as a pure function of the core count so the policy is unit-testable and lives in one place.
 *
 * Tuned for the phones this app mostly runs on. Take the Infinix HOT 11 2022 (Unisoc T610: 2x
 * Cortex-A75 + 6x Cortex-A55, all clocked at 1.8 GHz, 4 GB RAM, 5000 mAh):
 *
 *  - Interactive enhancement uses every core. The user is staring at a progress bar and the native
 *    scheduler hands work out one job at a time, so the two fast A75 cores simply take more jobs
 *    than the six A55 cores and nothing idles waiting for the slowest core.
 *  - Background training leaves [CORES_RESERVED_DURING_TRAINING] cores to the OS and UI. A plastic
 *    budget phone cannot shed the heat of eight cores pinned for minutes, and a training session
 *    runs for many minutes; six threads keep well over 90% of the throughput with noticeably less
 *    sustained heat and no UI jank while the phone is in the user's hand.
 */
object ComputeBudget {

    /** Must match the native pool's hard cap (util/thread_pool.cpp, kMaxPoolThreads). */
    const val MAX_NATIVE_THREADS = 8

    const val CORES_RESERVED_DURING_TRAINING = 2

    /** Threads for an interactive, user-waiting job (Enhance, validation previews). */
    fun enhancementThreads(cpuCores: Int): Int = cpuCores.coerceIn(1, MAX_NATIVE_THREADS)

    /** Threads for a background training session. Always at least 1, also on dual/quad-core phones. */
    fun trainingThreads(cpuCores: Int): Int =
        (cpuCores - CORES_RESERVED_DURING_TRAINING).coerceIn(1, MAX_NATIVE_THREADS)
}
