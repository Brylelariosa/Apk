package com.novaenhance.ai.utils

import android.content.Context
import android.os.Build
import android.util.Log
import com.novaenhance.ai.BuildConfig
import java.io.File

private const val TAG = "CrashReporter"
private const val CRASH_FILE_NAME = "last_crash.txt"
private const val INCIDENT_FILE_NAME = "last_incident.txt"
private const val PREFS_NAME = "crash_log_state"
private const val KEY_ARCHIVED_TS = "archived_incident_ts"
private const val KEY_CLEARED_TS = "cleared_before_ts"
private const val INCIDENT_LOG_LINES = 150
private const val SESSION_LOG_LINES = 150
private const val MAX_FILE_CHARS = 200_000

/**
 * Everything behind the in-app Crash Log screen. It captures three different kinds of "the app died":
 *
 *  1. A Java/Kotlin exception - caught by the uncaught-exception handler below, which writes the stack trace
 *     to disk before the process dies (as before), still rethrowing to the platform's own handler so the app
 *     crashes exactly as it would without this.
 *  2. A native (C++) crash, or Android killing the app (low memory, etc.) - NO in-process code can catch
 *     these, the process is simply gone. They are recovered on the NEXT launch instead, from two sources:
 *     Android's own exit record ([ProcessExitHistory]: reason, signal, memory held) and the app's own
 *     crash-proof on-disk log ([PersistentLog]: what it was doing, band by band, right up to the end).
 *  3. Nothing died, but something failed: the same on-disk log has every NovaLog warning/error with stack.
 *
 * [install] must run once, as early as possible, from NovaEnhanceApplication.onCreate. If the previous run
 * ended badly, [pendingPromptSummary] is non-null for the UI to offer "View crash log".
 */
object CrashReporter {

    private var appContext: Context? = null

    @Volatile
    private var promptSummary: String? = null

    fun install(context: Context) {
        val app = context.applicationContext
        appContext = app

        // The handler goes in first so even a failure in the startup work below is recorded.
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrashFile(thread, throwable)
            } catch (writeFailure: Throwable) {
                // Writing the report failing must never be why the crash
                // itself fails to propagate - log and fall through either way.
                Log.e(TAG, "Failed writing crash report", writeFailure)
            }
            previousHandler?.uncaughtException(thread, throwable)
        }

        try {
            MemoryStats.attach(app)
            PersistentLog.start(app)
            checkHowLastRunEnded(app)
        } catch (t: Throwable) {
            Log.e(TAG, "Crash-log startup check failed", t)
        }
    }

    private fun writeCrashFile(thread: Thread, throwable: Throwable) {
        val context = appContext ?: return
        val file = File(context.filesDir, CRASH_FILE_NAME)
        val now = logStamp(System.currentTimeMillis())
        try {
            PersistentLog.append("$now F/CRASH: uncaught ${throwable.javaClass.name}: ${throwable.message} (thread ${thread.name})")
            PersistentLog.appendThrowable(throwable)
            val report = buildString {
                appendLine("Crashed: $now")
                appendLine("Thread: ${thread.name}")
                appendLine(
                    "Device: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), " +
                        "${Build.MANUFACTURER} ${Build.MODEL}"
                )
                appendLine(MemoryStats.summary())
                appendLine()
                appendLine(Log.getStackTraceString(throwable))
                appendLine("--- Recent activity leading up to the crash (most recent last) ---")
                val history = NovaLog.recentHistory()
                if (history.isEmpty()) {
                    appendLine("(none this session)")
                } else {
                    history.forEach { appendLine(it) }
                }
            }
            file.writeText(report)
        } catch (failure: Throwable) {
            // Most likely a second OutOfMemoryError while building the full report: leave a minimal record.
            try {
                file.writeText(
                    "Crashed: $now\nThread: ${thread.name}\n${throwable.javaClass.name}: ${throwable.message}\n" +
                        "(full report could not be written: ${failure.javaClass.simpleName})\n"
                )
            } catch (ignored: Throwable) {
                // nothing more can be done
            }
        }
    }

    /**
     * Looks at how the PREVIOUS run of the app ended. If it ended badly (and we have not already recorded that
     * incident), archives the evidence to disk and arms [pendingPromptSummary].
     */
    private fun checkHowLastRunEnded(context: Context) {
        val previousText = PersistentLog.previousSessionText()
        val previousPid = PersistentLog.pidOf(previousText)
        val interrupted = PersistentLog.interruptedWork(previousText)
        val javaCrash = PersistentLog.sawFatalCrash(previousText)
        val unfinished = interrupted != null || javaCrash

        val exits = ProcessExitHistory.recent(context, 8)
        val exit = if (previousPid != null) exits.firstOrNull { it.pid == previousPid } else exits.firstOrNull()

        val abnormal = if (exit != null) ProcessExitHistory.isAbnormal(exit, unfinished) else unfinished
        val incidentTime = exit?.timestamp ?: PersistentLog.previousSessionTimestamp()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val alreadyHandled = maxOf(prefs.getLong(KEY_ARCHIVED_TS, 0L), prefs.getLong(KEY_CLEARED_TS, 0L))
        if (!abnormal || incidentTime <= alreadyHandled) return

        val summary = ProcessExitHistory.plainEnglish(exit, interrupted != null, javaCrash)
        val archive = buildString {
            appendLine("When: ${logStamp(incidentTime)}")
            appendLine("What happened: $summary")
            if (exit != null) appendLine("Android's record: ${ProcessExitHistory.oneLine(exit)}")
            appendLine("Was busy with: ${interrupted ?: "nothing recorded (idle, or that run predates the crash log)"}")
            appendLine()
            appendLine("--- What the app was doing in that run (newest last) ---")
            if (previousText.isBlank()) {
                appendLine("(no breadcrumbs - that run happened before the crash log existed)")
            } else {
                previousText.lineSequence().toList().takeLast(INCIDENT_LOG_LINES).forEach { appendLine(it) }
            }
            val hint = exit?.traceHint
            if (!hint.isNullOrBlank()) {
                appendLine()
                appendLine("--- Readable strings from Android's crash trace (signal, library, function names) ---")
                appendLine(hint)
            }
        }
        File(context.filesDir, INCIDENT_FILE_NAME).writeText(archive)
        prefs.edit().putLong(KEY_ARCHIVED_TS, incidentTime).apply()
        promptSummary = summary
    }

    /** Non-null when the previous run ended badly and the user has not been told yet. */
    fun pendingPromptSummary(): String? = promptSummary

    fun acknowledgePrompt() {
        promptSummary = null
    }

    /** Contents of the last persisted Java crash, if any - see [DiagnosticsReport.build]. */
    fun pendingCrashReport(): String? = readText(CRASH_FILE_NAME)

    private fun readText(name: String): String? {
        val dir = appContext?.filesDir ?: return null
        return try {
            val file = File(dir, name)
            if (!file.exists()) {
                null
            } else {
                val text = file.readText()
                if (text.length > MAX_FILE_CHARS) text.takeLast(MAX_FILE_CHARS) else text
            }
        } catch (t: Throwable) {
            null
        }
    }

    /** The full plain-text crash log shown on the Crash Log screen and copied/shared from it. */
    fun buildCrashLog(): String {
        val context = appContext
        return buildString {
            appendLine("NovaEnhance AI crash log")
            appendLine("Generated: ${logStamp(System.currentTimeMillis())}")
            appendLine(
                "App ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}, ${BuildConfig.BUILD_TYPE}); " +
                    "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}); ${Build.MANUFACTURER} ${Build.MODEL}"
            )
            appendLine(MemoryStats.summary())
            appendLine()

            val incident = readText(INCIDENT_FILE_NAME)
            appendLine("===== LAST INCIDENT (a run that did not end normally) =====")
            if (incident == null) {
                appendLine("None recorded.")
            } else {
                appendLine(incident)
            }
            appendLine()

            appendLine("===== LAST JAVA CRASH =====")
            val javaCrash = readText(CRASH_FILE_NAME)
            if (javaCrash == null) {
                appendLine("None recorded.")
            } else {
                appendLine(javaCrash)
            }
            appendLine()

            appendLine("===== HOW RECENT RUNS ENDED, according to Android (newest first) =====")
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                appendLine("Not available: Android only keeps this from Android 11 (this phone is API ${Build.VERSION.SDK_INT}).")
            } else if (context == null) {
                appendLine("Not available yet.")
            } else {
                val clearedBefore = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getLong(KEY_CLEARED_TS, 0L)
                val exits = ProcessExitHistory.recent(context, 8).filter { it.timestamp > clearedBefore }
                if (exits.isEmpty()) {
                    appendLine("Nothing recorded.")
                } else {
                    exits.forEach { record ->
                        appendLine(ProcessExitHistory.oneLine(record))
                        val hint = record.traceHint
                        if (!hint.isNullOrBlank()) {
                            appendLine("    trace strings:")
                            hint.lineSequence().forEach { appendLine("    $it") }
                        }
                    }
                }
            }
            appendLine()

            appendLine("===== THIS RUN SO FAR (newest last) =====")
            val session = PersistentLog.currentSessionTail(SESSION_LOG_LINES)
            if (session.isBlank()) appendLine("(empty)") else appendLine(session)
        }
    }

    /** Wipes the saved incident, Java crash and previous-run log. The current run keeps logging. */
    fun clearAll() {
        val context = appContext ?: return
        try {
            File(context.filesDir, CRASH_FILE_NAME).delete()
            File(context.filesDir, INCIDENT_FILE_NAME).delete()
            PersistentLog.clearPrevious()
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putLong(KEY_CLEARED_TS, System.currentTimeMillis()).apply()
            promptSummary = null
        } catch (t: Throwable) {
            Log.w(TAG, "Clearing the crash log failed", t)
        }
    }
}
