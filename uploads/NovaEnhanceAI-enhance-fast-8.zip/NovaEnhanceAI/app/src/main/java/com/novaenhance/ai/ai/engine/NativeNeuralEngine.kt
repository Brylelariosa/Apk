package com.novaenhance.ai.ai.engine

/**
 * Thin JNI bridge to `app/src/main/cpp/nn/network.cpp` - a small residual
 * CNN with hand-implemented (and gradient-checked - see
 * `tools/nn_verification/`) forward and backward passes, plus an Adam
 * optimizer. This is the entire "AI model": there is no TensorFlow, no
 * TFLite, no Python step, and no bundled model asset anywhere in this
 * app - a model is simply a [FloatArray] of [TOTAL_PARAMS] numbers that
 * [NativeNeuralEngine] can initialize, run forward on, or take one training
 * step against, all in a single native call.
 *
 * These constants MUST exactly match `nn/network.h`'s compile-time
 * constants - both sides hard-code the same fixed architecture rather than
 * negotiating shapes across the JNI boundary, which is deliberate (fewer
 * moving parts, no way for the two languages to silently disagree about a
 * dimension).
 */
object NativeNeuralEngine {

    init {
        System.loadLibrary("novaenhance_native")
    }

    const val TILE_SIZE = 64
    const val INPUT_CHANNELS = 3
    const val OUTPUT_CHANNELS = 3
    const val INPUT_FLOATS = TILE_SIZE * TILE_SIZE * INPUT_CHANNELS
    const val OUTPUT_FLOATS = TILE_SIZE * TILE_SIZE * OUTPUT_CHANNELS

    // Layout: conv1(3->48) + bias, conv2(48->48) + bias, conv3(48->48) + bias, conv4(48->3) + bias.
    // See nn/network.h's W1_SIZE..B4_SIZE/TOTAL_PARAMS for the derivation -
    // this is just the sum, kept here as a single source of truth on the
    // Kotlin side for allocating parameter/momentum/velocity arrays.
    // Widened from the original 32-channel/20259-param version on 2026-09-06
    // - see network.h's matching dated comment for why and the re-verification
    // this went through before being trusted.
    const val TOTAL_PARAMS = 44211

    /**
     * How far (in pixels) one output pixel can "see": four stacked 3x3
     * convolutions. Context rows/columns closer than this to a region's
     * border were computed with zero padding instead of real neighbours.
     */
    const val RECEPTIVE_FIELD_RADIUS_PX = 4

    /** Randomly (He-init, near-zero tail layer) initializes a fresh [TOTAL_PARAMS]-sized parameter array in place. */
    fun initializeParams(params: FloatArray, seed: Long) {
        require(params.size == TOTAL_PARAMS) { "params must be exactly $TOTAL_PARAMS floats, got ${params.size}" }
        nativeInitializeParams(params, seed)
    }

    /** Forward pass only. `input` must be [INPUT_FLOATS] normalized [0,1] floats in HWC order; returns [OUTPUT_FLOATS] floats. */
    fun infer(input: FloatArray, params: FloatArray): FloatArray {
        require(input.size == INPUT_FLOATS) { "input must be exactly $INPUT_FLOATS floats, got ${input.size}" }
        require(params.size == TOTAL_PARAMS) { "params must be exactly $TOTAL_PARAMS floats, got ${params.size}" }
        return nativeInfer(input, params)
    }

    /**
     * Forward + backward + one Adam step over a batch, mutating
     * [params]/[momentum]/[velocity] in place. Returns the average L1 loss
     * over the batch (computed before the update). Pass `anchorParams =
     * null` and `l2SpLambda = 0f` to disable the anti-forgetting penalty
     * (e.g. a model's very first training session, with nothing yet to
     * protect).
     *
     * [threads] bounds the native worker threads used for this step
     * (`<= 0` = all the pool has). The step's forward/backward passes are
     * split into row bands handed out dynamically, so it scales across
     * cores even for a batch of one and keeps the fast cores of a
     * big.LITTLE phone busy. With `threads = 1` the result is bit-exact
     * repeatable; with more, only float summation order varies.
     */
    fun trainStep(
        inputBatch: FloatArray,
        targetBatch: FloatArray,
        batchSize: Int,
        params: FloatArray,
        momentum: FloatArray,
        velocity: FloatArray,
        anchorParams: FloatArray?,
        adamStepNumber: Int,
        learningRate: Float,
        l2SpLambda: Float,
        threads: Int = 0
    ): Float {
        require(inputBatch.size == INPUT_FLOATS * batchSize) { "inputBatch size mismatch" }
        require(targetBatch.size == OUTPUT_FLOATS * batchSize) { "targetBatch size mismatch" }
        require(params.size == TOTAL_PARAMS && momentum.size == TOTAL_PARAMS && velocity.size == TOTAL_PARAMS) {
            "params/momentum/velocity must each be exactly $TOTAL_PARAMS floats"
        }
        require(anchorParams == null || anchorParams.size == TOTAL_PARAMS) { "anchorParams must be exactly $TOTAL_PARAMS floats" }

        return nativeTrainStep(
            inputBatch, targetBatch, batchSize,
            params, momentum, velocity, anchorParams,
            adamStepNumber, learningRate, l2SpLambda, threads
        )
    }

    /**
     * Runs the network over a whole ARGB_8888 region (any size, row-major
     * [pixels] of `width * height`) and writes the enhanced ARGB_8888 pixels
     * (alpha forced opaque) into [out], which is also returned.
     *
     * The result equals ONE fully-convolutional pass over the region: there
     * are no tile seams, and zero padding applies only at the region's own
     * border. Callers processing a large image in bands must therefore pass
     * each band with at least [RECEPTIVE_FIELD_RADIUS_PX] rows of real
     * context above and below it (except at the image's true top/bottom) and
     * crop those rows afterwards - see BandProcessor.
     *
     * Runs on the calling thread plus up to `threads - 1` native workers
     * (`<= 0` = all). Does NOT touch any model state, so the caller is
     * responsible for not mutating [params] concurrently (NovaModelEngine
     * holds its mutex around this).
     */
    fun inferRegion(
        pixels: IntArray,
        width: Int,
        height: Int,
        params: FloatArray,
        threads: Int = 0,
        out: IntArray = IntArray(pixels.size)
    ): IntArray {
        require(width > 0 && height > 0) { "region must be non-empty, got ${width}x$height" }
        require(width.toLong() * height.toLong() == pixels.size.toLong()) {
            "pixels.size (${pixels.size}) must equal width*height (${width}x$height)"
        }
        require(out.size == pixels.size) { "out.size (${out.size}) must equal pixels.size (${pixels.size})" }
        require(params.size == TOTAL_PARAMS) { "params must be exactly $TOTAL_PARAMS floats, got ${params.size}" }
        nativeInferRegion(pixels, width, height, params, threads, out)
        return out
    }

    /**
     * Frees the native activation/gradient workspace a training session keeps
     * between steps (tens of MB). Call when a session ends; the next step
     * transparently re-creates it.
     */
    fun releaseTrainingWorkspace() = nativeReleaseTrainingWorkspace()

    /** Which convolution kernels this build runs: "neon-aarch64", "neon-armv7" or "portable". For logs. */
    val backendName: String by lazy { nativeBackendName() }

    // --- JNI declarations, implemented in native-lib.cpp ---
    private external fun nativeInitializeParams(params: FloatArray, seed: Long)
    private external fun nativeInfer(input: FloatArray, params: FloatArray): FloatArray
    private external fun nativeTrainStep(
        inputBatch: FloatArray, targetBatch: FloatArray, batchSize: Int,
        params: FloatArray, momentum: FloatArray, velocity: FloatArray,
        anchorParams: FloatArray?,
        adamStepNumber: Int, learningRate: Float, l2SpLambda: Float,
        threads: Int
    ): Float
    private external fun nativeInferRegion(
        pixels: IntArray, width: Int, height: Int, params: FloatArray, threads: Int, out: IntArray
    )
    private external fun nativeReleaseTrainingWorkspace()
    private external fun nativeBackendName(): String
}
