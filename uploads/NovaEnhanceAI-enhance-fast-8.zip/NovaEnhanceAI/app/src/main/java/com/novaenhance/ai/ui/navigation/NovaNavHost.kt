package com.novaenhance.ai.ui.navigation

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.novaenhance.ai.ui.screens.CrashLogScreen
import com.novaenhance.ai.ui.screens.DashboardScreen
import com.novaenhance.ai.ui.screens.DatasetManagerScreen
import com.novaenhance.ai.ui.screens.EnhanceScreen
import com.novaenhance.ai.ui.screens.ModelManagerScreen
import com.novaenhance.ai.ui.screens.SettingsScreen
import com.novaenhance.ai.ui.screens.TrainingScreen
import com.novaenhance.ai.utils.CrashReporter

@Composable
fun NovaNavHost() {
    val navController = rememberNavController()

    // Set at startup when the previous run ended badly (crash, native crash, killed for memory, ...).
    var crashPrompt by remember { mutableStateOf(CrashReporter.pendingPromptSummary()) }

    NavHost(navController = navController, startDestination = NovaDestination.Dashboard.route) {
        composable(NovaDestination.Dashboard.route) {
            DashboardScreen(
                onNavigateToEnhance = { navController.navigate(NovaDestination.Enhance.route) },
                onNavigateToTraining = { navController.navigate(NovaDestination.Training.route) },
                onNavigateToDataset = { navController.navigate(NovaDestination.DatasetManager.route) },
                onNavigateToModelManager = { navController.navigate(NovaDestination.ModelManager.route) },
                onNavigateToSettings = { navController.navigate(NovaDestination.Settings.route) }
            )
        }
        composable(NovaDestination.Enhance.route) { EnhanceScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.Training.route) { TrainingScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.DatasetManager.route) { DatasetManagerScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.ModelManager.route) { ModelManagerScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.Settings.route) {
            SettingsScreen(
                onBack = { navController.popBackStack() },
                onOpenCrashLog = { navController.navigate(NovaDestination.CrashLog.route) }
            )
        }
        composable(NovaDestination.CrashLog.route) { CrashLogScreen(onBack = { navController.popBackStack() }) }
    }

    val promptText = crashPrompt
    if (promptText != null) {
        AlertDialog(
            onDismissRequest = {
                CrashReporter.acknowledgePrompt()
                crashPrompt = null
            },
            title = { Text("The app stopped unexpectedly last time") },
            text = { Text(promptText + "\n\nOpen the crash log to copy what happened.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        CrashReporter.acknowledgePrompt()
                        crashPrompt = null
                        navController.navigate(NovaDestination.CrashLog.route)
                    }
                ) {
                    Text("View crash log")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        CrashReporter.acknowledgePrompt()
                        crashPrompt = null
                    }
                ) {
                    Text("Dismiss")
                }
            }
        )
    }
}
