package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap

/**
 * Thin JNI bridge over the native (`app/src/main/cpp`) image filter library.
 *
 * All tile-based operations work on plain [IntArray] pixel buffers in
 * Android's ARGB_8888 int layout (as produced by [Bitmap.getPixels]), which
 * keeps the JNI surface simple and lets [com.novaenhance.ai.ai.engine.BandProcessor]
 * own all memory/tiling decisions. [resizeBitmapInto] is the one exception -
 * it operates on raw bitmap memory directly for cheap whole-image thumbnails
 * where an extra IntArray round trip isn't worth it.
 *
 * These are classic (non-learned) filters: they back the manual enhancement
 * sliders (sharpness/noise-reduction controls a user can drag) and the
 * synthetic dataset degradation generator. The *learned* part of the pipeline
 * (the part that actually improves from training) lives in [NovaModelEngine].
 */
object NativeImageProcessor {

    init {
        System.loadLibrary("novaenhance_native")
    }

    fun gaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray {
        validateTileArgs(pixels, width, height, "gaussianBlur")
        return nativeGaussianBlur(pixels, width, height, sigma)
    }

    fun unsharpMask(pixels: IntArray, width: Int, height: Int, sigma: Float, amount: Float): IntArray {
        validateTileArgs(pixels, width, height, "unsharpMask")
        return nativeUnsharpMask(pixels, width, height, sigma, amount)
    }

    fun denoiseBilateral(
        pixels: IntArray,
        width: Int,
        height: Int,
        spatialSigma: Float,
        rangeSigma: Float
    ): IntArray {
        validateTileArgs(pixels, width, height, "denoiseBilateral")
        return nativeDenoiseBilateral(pixels, width, height, spatialSigma, rangeSigma)
    }

    fun resizeBilinear(
        pixels: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        dstWidth: Int,
        dstHeight: Int
    ): IntArray = nativeResizeBilinear(pixels, srcWidth, srcHeight, dstWidth, dstHeight)

    /** Fast proxy similarity in [0,1]; used by the validator, not a full SSIM. */
    fun quickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float =
        nativeQuickSimilarityScore(a, b, width, height)

    fun addGaussianNoise(pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int): IntArray =
        nativeAddGaussianNoise(pixels, width, height, amount, seed)

    fun simulateJpegArtifacts(pixels: IntArray, width: Int, height: Int, qualityPercent: Int): IntArray =
        nativeSimulateJpegArtifacts(pixels, width, height, qualityPercent)

    fun motionBlur(pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int): IntArray =
        nativeMotionBlur(pixels, width, height, angleDegrees, lengthPx)

    fun colorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray =
        nativeColorFade(pixels, width, height, fadeAmount)

    /** Resizes [src] directly into [dst] (must be pre-allocated at the target size). */
    fun resizeBitmapInto(src: Bitmap, dst: Bitmap): Boolean = nativeResizeBitmapInto(src, dst)

    // A reasonable ceiling on any one dimension passed into a native image call.
    // Enhancement works in full-width bands (BandProcessor), so a "tile" here can
    // be as wide as a whole photo - the HOT 11's 13 MP main camera is already 4208px
    // wide, and a 4x upscale of one is wider still - which is why this is no longer the
    // 4096px it was when every caller passed 64px tiles. It exists purely to reject an
    // obviously-wrong value before it reaches JNI, rather than let width*height
    // silently overflow or allocate something huge. Mirrors native-lib.cpp's
    // kMaxImageDimension.
    private const val MAX_IMAGE_DIMENSION = 16384

    /**
     * Explicit validation before any tile-based JNI call - see the class doc
     * comment. Kotlin's non-nullable IntArray already rules out passing a
     * literal null pixels array from code compiled against this signature,
     * but width/height/array-length agreement is a call-site invariant
     * nothing in the type system enforces, and a mismatch here would
     * otherwise reach C++ as an unchecked `pixels[y*width+x]` index -
     * undefined behavior, not a catchable error. Native-lib.cpp repeats an
     * equivalent check at the JNI boundary itself (see its
     * `validatePixelArray`) as defense in depth, but failing fast here with
     * a clear Kotlin stack trace pointing at the actual misuse is more
     * useful than only ever seeing it after crossing into native code.
     */
    private fun validateTileArgs(pixels: IntArray, width: Int, height: Int, fnName: String) {
        require(width > 0 && height > 0) { "$fnName: width and height must be positive (got ${width}x$height)" }
        require(width <= MAX_IMAGE_DIMENSION && height <= MAX_IMAGE_DIMENSION) {
            "$fnName: ${width}x$height exceeds the $MAX_IMAGE_DIMENSION px per-dimension ceiling for a native image call"
        }
        val expected = width.toLong() * height.toLong()
        require(pixels.size.toLong() == expected) {
            "$fnName: pixels.size (${pixels.size}) does not match width*height ($expected for ${width}x$height)"
        }
    }

    // --- JNI declarations, implemented in native-lib.cpp ---
    private external fun nativeGaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray
    private external fun nativeUnsharpMask(
        pixels: IntArray, width: Int, height: Int, sigma: Float, amount: Float
    ): IntArray
    private external fun nativeDenoiseBilateral(
        pixels: IntArray, width: Int, height: Int, spatialSigma: Float, rangeSigma: Float
    ): IntArray
    private external fun nativeResizeBilinear(
        pixels: IntArray, srcWidth: Int, srcHeight: Int, dstWidth: Int, dstHeight: Int
    ): IntArray
    private external fun nativeQuickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float
    private external fun nativeAddGaussianNoise(
        pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int
    ): IntArray
    private external fun nativeSimulateJpegArtifacts(
        pixels: IntArray, width: Int, height: Int, qualityPercent: Int
    ): IntArray
    private external fun nativeMotionBlur(
        pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int
    ): IntArray
    private external fun nativeColorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray
    private external fun nativeResizeBitmapInto(src: Bitmap, dst: Bitmap): Boolean
}
