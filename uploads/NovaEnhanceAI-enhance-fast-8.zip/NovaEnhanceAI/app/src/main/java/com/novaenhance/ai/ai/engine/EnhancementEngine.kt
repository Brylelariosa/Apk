package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap
import com.novaenhance.ai.utils.ComputeBudget
import com.novaenhance.ai.utils.MemoryStats
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.ceil
import kotlin.math.max

/**
 * The single entry point the UI and validator both call to actually enhance
 * an image. Design split, spelled out because it's easy to lose track of
 * which layer does what:
 *
 *  - [NovaModelEngine] (the *learned* part): a CNN pass over whole bands of the
 *    image - multi-threaded and seam-free - that does denoise + sharpen +
 *    detail-restore + artifact-removal in one shot, and is the thing that
 *    literally gets better as the user trains it.
 *  - [NativeImageProcessor] (the *classical*, non-learned part): manual
 *    sharpen/denoise/saturation controls layered on top of the AI's output,
 *    so a user can nudge the result even between training sessions, and so
 *    "Upscaling" (which the learned model does not do - it's a fixed
 *    tile-size restoration model, not a super-resolution model) has an
 *    honest implementation rather than a fabricated claim.
 *  - [BandProcessor]: keeps peak memory bounded regardless of source image
 *    resolution, hands every band its true neighbouring rows as context (so
 *    there are no tile seams), and (given [thermalGovernor]) paces itself under
 *    thermal pressure - this is what makes a manual "Enhance" tap on a large
 *    photo back off the same way training's internal validation/rescoring
 *    passes do, since both go through this same class.
 */
class EnhancementEngine(
    private val modelEngine: NovaModelEngine,
    private val thermalGovernor: ThermalGovernor? = null
) {
    companion object {
        // Shared across every EnhancementEngine instance (a new one is created
        // per enhancement request - see EnhanceViewModel.runEnhancement), so
        // it actually bounds concurrent expensive processing globally instead
        // of per-request. Without this, the per-request thread budget
        // (ComputeBudget.enhancementThreads) only ever bounded ONE
        // request's own work - two overlapping requests (an old one not yet
        // stopped, plus a new one) each got their own independent budget, so
        // native work could still run for both at once even with the
        // generation/isStale checks in place (those stop a stale request from
        // *publishing*, and bound how long it keeps working before noticing
        // it's stale, but never stopped it from running *concurrently* with a
        // newer one in the meantime).
        //
        // A coroutine Mutex (not a thread lock) so acquiring it suspends the
        // calling coroutine without blocking a thread - enhance() already
        // only ever runs on Dispatchers.Default (see EnhanceViewModel), never
        // the main thread, so this doesn't introduce any new main-thread risk.
        private val nativeProcessingGate = Mutex()

        // Vertical reach, in rows, of each classical filter the pipeline layers on top of the network. They
        // mirror filters/convolution.cpp (bilateral window radius 2; Gaussian kernel radius = ceil(3 * sigma))
        // and decide how many real context rows every band needs so that band edges come out exactly as a
        // whole-image pass would.
        private const val BILATERAL_RADIUS_PX = 2
        private const val DENOISE_SPATIAL_SIGMA = 1.5f
        private const val UNSHARP_SIGMA = 1.0f
        private const val RESHARPEN_SIGMA = 1.2f

        private fun gaussianRadius(sigma: Float): Int = max(1, ceil(sigma * 3f).toInt())

        /** Context rows the AI pass needs: the network plus whichever optional filters [options] enables. */
        private fun aiPassContextRows(options: EnhancementOptions): Int =
            NativeNeuralEngine.RECEPTIVE_FIELD_RADIUS_PX +
                (if (options.noiseReduction > 0f) BILATERAL_RADIUS_PX else 0) +
                (if (options.sharpness > 0f) gaussianRadius(UNSHARP_SIGMA) else 0)
    }

    private val bandProcessor = BandProcessor(thermalGovernor = thermalGovernor)

    data class EnhanceProgress(val fraction: Float, val stage: Stage) {
        enum class Stage { AI_TILES, UPSCALING, FINISHING }
    }

    suspend fun enhance(
        source: Bitmap,
        options: EnhancementOptions,
        onProgress: ((EnhanceProgress) -> Unit)? = null,
        // Checked before starting, between the AI pass and the upscale
        // pass, and (inside BandProcessor) between bands - so a
        // request superseded by a newer slider change stops within at most
        // one band's worth of native work instead of running the full
        // image to completion. This exists BECAUSE coroutine cancellation
        // alone can't do this: a native JNI call already in flight keeps
        // running to completion regardless of job.cancel() - see
        // EnhanceViewModel.runEnhancement for where this is wired to an
        // actual generation counter. Default `{ false }` preserves the
        // previous unconditional-completion behavior for any other caller
        // (e.g. ModelValidator's before/after comparison passes, which have
        // their own, separate TrainingControlFlow-based cancellation).
        isStale: () -> Boolean = { false }
    ): Bitmap {
        if (isStale()) throw CancellationException("Enhancement superseded before starting")

        // Everything below - the AI pass and, if applicable, the
        // upscale+resharpen pass - is exactly the "expensive processing" that
        // must not overlap with another request's. Held for the whole call,
        // not re-acquired per stage, so an old request's upscale/resharpen
        // work can't overlap a new request's AI-tile work either. withLock
        // (rather than manual lock()/unlock()) guarantees the gate is
        // released on every exit path, including the isStale() throws below
        // and any exception from deeper in the pipeline - there is no path
        // through this block that can leave it held.
        return nativeProcessingGate.withLock {
            // Re-checked now that this request actually holds the gate: it may
            // have been superseded by a newer one while waiting its turn, and
            // there is no reason to make it start expensive work now, only to
            // have its own isStale checks catch it a moment later.
            if (isStale()) throw CancellationException("Enhancement superseded while waiting for the native-processing gate")

            val threadCeiling = ComputeBudget.enhancementThreads(Runtime.getRuntime().availableProcessors())
            val startMs = System.currentTimeMillis()
            NovaLog.breadcrumb(
                "EnhancementEngine",
                "AI pass start ${source.width}x${source.height} contextRows=${aiPassContextRows(options)} threads<=$threadCeiling | ${MemoryStats.summary()}"
            )
            val aiEnhanced = bandProcessor.process(
                source,
                contextRows = aiPassContextRows(options),
                threadCeiling = threadCeiling,
                onProgress = { p ->
                    onProgress?.invoke(EnhanceProgress(p.rowsDone.toFloat() / p.rowsTotal, EnhanceProgress.Stage.AI_TILES))
                },
                isStale = isStale
            ) { bandPixels, bandW, bandH, threads ->
                NovaLog.breadcrumb("EnhancementEngine", "  neural pass ${bandW}x$bandH threads=$threads")
                val aiBand = modelEngine.inferRegion(bandPixels, bandW, bandH, threads)
                applyManualControls(blendWithOriginal(bandPixels, aiBand, options.strength), bandW, bandH, options)
            }
            NovaLog.i(
                "EnhancementEngine",
                "AI pass ${source.width}x${source.height} done in ${System.currentTimeMillis() - startMs}ms " +
                    "(kernels=${NativeNeuralEngine.backendName}, up to $threadCeiling threads)"
            )

            if (options.upscaleFactor == 1) {
                onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
                return@withLock aiEnhanced
            }
            if (isStale()) {
                aiEnhanced.recycle() // not returning it, and nothing else references it yet - free it now rather than leaving it for GC
                throw CancellationException("Enhancement superseded before upscaling")
            }

            onProgress?.invoke(EnhanceProgress(0f, EnhanceProgress.Stage.UPSCALING))
            val targetW = aiEnhanced.width * options.upscaleFactor
            val targetH = aiEnhanced.height * options.upscaleFactor
            NovaLog.breadcrumb(
                "EnhancementEngine",
                "upscale x${options.upscaleFactor} -> ${targetW}x$targetH (~${targetW.toLong() * targetH * 4L / (1024L * 1024L)}MB) | ${MemoryStats.summary()}"
            )
            val upscaled = Bitmap.createScaledBitmap(aiEnhanced, targetW, targetH, /* filter = */ true)
            if (upscaled !== aiEnhanced) aiEnhanced.recycle()

            // Upsampling always softens fine detail a little; a mild classical
            // sharpen pass compensates. Applied band-wise too, since the
            // upscaled image can be significantly larger than the original -
            // but skipped entirely (not just made a no-op per band) when
            // sharpness is 0, since running every band of the upscaled image
            // through get/setPixels just to hand back the same pixels was
            // pure wasted work.
            val resharpened = if (options.sharpness <= 0f) {
                upscaled
            } else {
                NovaLog.breadcrumb("EnhancementEngine", "resharpen pass over ${upscaled.width}x${upscaled.height}")
                try {
                    bandProcessor.process(
                        upscaled,
                        contextRows = gaussianRadius(RESHARPEN_SIGMA),
                        threadCeiling = threadCeiling,
                        isStale = isStale
                    ) { bandPixels, bandW, bandH, _ ->
                        NativeImageProcessor.unsharpMask(
                            bandPixels, bandW, bandH, sigma = RESHARPEN_SIGMA, amount = options.sharpness * 0.6f
                        )
                    }
                } catch (t: Throwable) {
                    // upscaled can be considerably larger than the source (up to 4x
                    // per dimension - see targetW/targetH above) - process() throwing
                    // (staleness or otherwise) must not leave it to GC to notice.
                    upscaled.recycle()
                    throw t
                }
            }
            if (resharpened !== upscaled) upscaled.recycle()

            onProgress?.invoke(EnhanceProgress(1f, EnhanceProgress.Stage.FINISHING))
            resharpened
        }
    }

    private fun blendWithOriginal(original: IntArray, aiOutput: IntArray, strength: Float): IntArray {
        if (strength >= 1f) return aiOutput
        if (strength <= 0f) return original
        val blended = IntArray(original.size)
        for (i in original.indices) {
            blended[i] = blendPixel(original[i], aiOutput[i], strength)
        }
        return blended
    }

    private fun applyManualControls(
        pixels: IntArray,
        width: Int,
        height: Int,
        options: EnhancementOptions
    ): IntArray {
        var result = pixels
        if (options.noiseReduction > 0f) {
            NovaLog.breadcrumb("EnhancementEngine", "  denoiseBilateral ${width}x$height noiseReduction=${options.noiseReduction}")
            result = NativeImageProcessor.denoiseBilateral(
                result, width, height,
                spatialSigma = DENOISE_SPATIAL_SIGMA, rangeSigma = 10f + options.noiseReduction * 40f
            )
        }
        if (options.sharpness > 0f) {
            NovaLog.breadcrumb("EnhancementEngine", "  unsharpMask ${width}x$height sharpness=${options.sharpness}")
            result = NativeImageProcessor.unsharpMask(
                result, width, height, sigma = UNSHARP_SIGMA, amount = options.sharpness
            )
        }
        if (options.colorRestoration > 0f) {
            NovaLog.breadcrumb("EnhancementEngine", "  saturation boost colorRestoration=${options.colorRestoration}")
            result = applySaturationBoost(result, options.colorRestoration)
        }
        return result
    }

    /** Simple luma-preserving saturation boost; the inverse of the native `colorFade` degradation. */
    private fun applySaturationBoost(pixels: IntArray, amount: Float): IntArray {
        val out = IntArray(pixels.size)
        val boost = 1f + amount // 1.0 (no change) .. 2.0 (double saturation)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val luma = (r * 299 + g * 587 + b * 114) / 1000

            val nr = (luma + (r - luma) * boost).toInt().coerceIn(0, 255)
            val ng = (luma + (g - luma) * boost).toInt().coerceIn(0, 255)
            val nb = (luma + (b - luma) * boost).toInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    private fun blendPixel(oldPixel: Int, newPixel: Int, newWeight: Float): Int {
        val oldWeight = 1f - newWeight
        val r = ((oldPixel shr 16 and 0xFF) * oldWeight + (newPixel shr 16 and 0xFF) * newWeight).toInt()
        val g = ((oldPixel shr 8 and 0xFF) * oldWeight + (newPixel shr 8 and 0xFF) * newWeight).toInt()
        val b = ((oldPixel and 0xFF) * oldWeight + (newPixel and 0xFF) * newWeight).toInt()
        return (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)
    }
}
