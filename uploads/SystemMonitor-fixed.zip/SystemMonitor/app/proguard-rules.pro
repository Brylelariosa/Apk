# Release build ships with isMinifyEnabled + isShrinkResources on. R8 always
# runs in full mode under AGP 8+ (gradle.properties can no longer opt out of
# it — see AGP 8.0 release notes), and full mode's more aggressive renaming
# broke the reflection-based bridge Compose/Lifecycle use to wire up
# LocalLifecycleOwner ("CompositionLocal LocalLifecycleOwner not present",
# crashing on every launch). That's fixed at the code level instead —
# see ProvideLifecycleOwnerCompat in presentation/CompatCompositionLocals.kt —
# since no R8 keep rule here can restore an opt-out AGP itself ignores.

# kotlinx-coroutines-android discovers Dispatchers.Main via ServiceLoader at
# runtime, not a direct code reference — R8 full mode can decide that class
# is unreachable and strip/rename it. MonitorViewModel touches Dispatchers.Main
# the moment it's constructed (viewModelScope.launch in init{}), so losing this
# crashes the app immediately on launch.
-keep class kotlinx.coroutines.android.** { *; }
-keep class kotlinx.coroutines.internal.MainDispatcherFactory { *; }
-keep class kotlinx.coroutines.CoroutineExceptionHandler { *; }
-dontwarn kotlinx.coroutines.**

# Belt-and-suspenders on manifest-declared entry points (AGP's default rules
# already cover this, but it costs nothing to be explicit).
-keep class com.bru.systemmonitor.SystemMonitorApp { *; }
-keep class com.bru.systemmonitor.presentation.MainActivity { *; }
-keep class com.bru.systemmonitor.presentation.MonitorViewModel { *; }
-keep class com.bru.systemmonitor.presentation.MonitorViewModel$Factory { *; }
