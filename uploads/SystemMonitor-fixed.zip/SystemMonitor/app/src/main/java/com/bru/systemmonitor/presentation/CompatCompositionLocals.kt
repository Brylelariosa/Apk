package com.bru.systemmonitor.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLifecycleOwner as LocalViewTreeLifecycleOwner
import androidx.lifecycle.compose.LocalLifecycleOwner

/**
 * Bridges [LocalViewTreeLifecycleOwner] (androidx.compose.ui.platform) into
 * [LocalLifecycleOwner] (androidx.lifecycle.compose) at the composition root.
 *
 * These are two distinct `CompositionLocal`s that happen to share a name. Only the
 * compose-ui one is guaranteed to be auto-provided when a `ComposeView` attaches to
 * its window; `collectAsStateWithLifecycle`, `LifecycleEventEffect`, and friends all
 * read the lifecycle-compose one instead. On compose-ui < 1.7, Lifecycle 2.8.x bridges
 * the two itself via a reflective lookup of the compose-ui CompositionLocal's holder
 * class, kept resolvable by a Proguard rule bundled in the lifecycle-runtime-compose
 * AAR — but AGP 8+ always runs R8 in full mode (the `android.enableR8.fullMode=false`
 * opt-out is silently ignored from AGP 8.0 on), and that's enough to let the holder
 * class get renamed anyway, breaking the lookup and crashing every release launch with
 * "CompositionLocal LocalLifecycleOwner not present" (AndroidX issue 336842920).
 *
 * Providing the value explicitly removes the dependency on that reflection path, so
 * the fix holds regardless of shrinker settings or future compose-ui/lifecycle
 * version pairings. Once this app's compose-ui version reaches 1.7+, compose-ui's own
 * LocalLifecycleOwner becomes a direct alias for this one and this wrapper stops being
 * necessary — but it's harmless to leave in place.
 *
 * Wrap the activity's `setContent` content with this once, above the app theme.
 */
@Composable
fun ProvideLifecycleOwnerCompat(content: @Composable () -> Unit) {
    CompositionLocalProvider(
        LocalLifecycleOwner provides LocalViewTreeLifecycleOwner.current,
        content = content
    )
}
