package com.voxelsandbox.game.ui

import android.content.Context
import android.content.SharedPreferences

/** One customizable HUD element's saved placement. [offsetXFrac]/[offsetYFrac] are
 *  the element's translation away from its normal (default) position, each stored
 *  as a fraction of screen width/height rather than raw pixels so a layout saved
 *  on one screen size still lands in roughly the right place on another. [scale]
 *  multiplies the element's default size. */
data class HudElementLayout(val offsetXFrac: Float, val offsetYFrac: Float, val scale: Float) {
    companion object {
        val DEFAULT = HudElementLayout(0f, 0f, 1f)
    }
}

/**
 * Persists player-customized HUD button positions/sizes (see HudController's
 * "Customize HUD" mode). Kept separate from GameSettings since these are per-
 * element and unrelated to the gameplay settings screen.
 */
class HudLayoutStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("voxel_hud_layout", Context.MODE_PRIVATE)

    fun get(key: String): HudElementLayout {
        if (!prefs.contains(xKey(key))) return HudElementLayout.DEFAULT
        return HudElementLayout(
            offsetXFrac = prefs.getFloat(xKey(key), 0f),
            offsetYFrac = prefs.getFloat(yKey(key), 0f),
            scale = prefs.getFloat(scaleKey(key), 1f)
        )
    }

    fun set(key: String, layout: HudElementLayout) {
        prefs.edit()
            .putFloat(xKey(key), layout.offsetXFrac)
            .putFloat(yKey(key), layout.offsetYFrac)
            .putFloat(scaleKey(key), layout.scale)
            .apply()
    }

    /** Clears every saved element back to default. */
    fun reset() {
        prefs.edit().clear().apply()
    }

    private fun xKey(key: String) = "${key}_x"
    private fun yKey(key: String) = "${key}_y"
    private fun scaleKey(key: String) = "${key}_scale"
}
