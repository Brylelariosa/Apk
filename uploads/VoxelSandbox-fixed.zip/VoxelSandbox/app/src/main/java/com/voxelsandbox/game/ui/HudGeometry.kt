package com.voxelsandbox.game.ui

import android.view.View

/**
 * Keeps a translated/scaled HUD element from ending up (mostly) off-screen. Shared
 * by two callers with different timing needs:
 *  - DragResizeTouchListener calls this live, on every drag/pinch step, so a button
 *    simply can't be carried past the edge in the first place.
 *  - HudController.applyStoredHudLayout calls this once per element after layout,
 *    to heal a position an older build already let the player drag fully off-screen
 *    and saved that way — without this, updating to the fixed build wouldn't be
 *    enough on its own, since the bad offset lives in on-device storage
 *    (HudLayoutStore), not in the app's code.
 *
 * getLocationOnScreen reports wherever the view is *actually* rendered right now —
 * translation and scale already folded in — so correcting from that directly
 * sidesteps re-deriving it from the view's pre-transform layout rect. A no-op if
 * [view] hasn't been laid out yet (width/height still 0), since getLocationOnScreen
 * isn't meaningful until then.
 */
fun clampTranslationToScreen(view: View) {
    if (view.width == 0 || view.height == 0) return
    val loc = IntArray(2)
    view.getLocationOnScreen(loc)
    val dm = view.resources.displayMetrics
    val w = view.width * view.scaleX
    val h = view.height * view.scaleY
    // At least half the element must stay on-screen on every edge — free to tuck
    // into a corner, never free to disappear past one.
    val minLeft = -w / 2f
    val maxLeft = dm.widthPixels - w / 2f
    val minTop = -h / 2f
    val maxTop = dm.heightPixels - h / 2f
    if (loc[0] < minLeft) view.translationX += minLeft - loc[0]
    if (loc[0] > maxLeft) view.translationX += maxLeft - loc[0]
    if (loc[1] < minTop) view.translationY += minTop - loc[1]
    if (loc[1] > maxTop) view.translationY += maxTop - loc[1]
}
