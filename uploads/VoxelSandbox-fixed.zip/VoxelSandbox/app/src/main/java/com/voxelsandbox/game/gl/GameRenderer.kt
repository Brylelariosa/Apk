package com.voxelsandbox.game.gl

import android.opengl.GLES30
import android.os.Handler
import android.os.Looper
import com.voxelsandbox.game.engine.GameEngine
import com.voxelsandbox.game.world.ChunkPos
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.mesh.MeshData
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.floor

/**
 * All GL work lives here and only here — GameEngine (physics/streaming/inventory) is
 * completely GL-agnostic, so this class's job is: call engine.update(dt), move
 * finished background work (mesh uploads, unloads) onto the GPU, and draw.
 */
class GameRenderer(
    private val engine: GameEngine,
    /** Invoked ~2-3x/sec on the main thread regardless of the FPS-counter setting
     *  (the HUD uses every tick to refresh the hotbar); the string argument is the
     *  formatted FPS/debug text when showFps is on, or null when it's off. */
    private val onPeriodicTick: (String?) -> Unit
) : android.opengl.GLSurfaceView.Renderer {

    /** When true, onDrawFrame keeps rendering the last state (so the world stays
     *  visible, frozen, behind a menu overlay) but stops calling engine.update —
     *  set by GameActivity whenever a menu is shown over active gameplay. */
    @Volatile var paused = false

    private val atlas = engine.atlas
    private lateinit var shader: ShaderProgram
    private var uViewProj = 0
    private var uTexture = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uAlpha = 0

    private val camera = Camera()
    private val frustum = Frustum()
    private var aspect = 1f

    // One GPU buffer per chunk COLUMN rather than per subchunk: at high render
    // distance, one draw call per subchunk (up to 4/column) was the dominant
    // mobile-GPU cost. columnMeshData caches each subchunk's latest raw MeshData
    // so that whenever any one subchunk changes, all of that column's current
    // subchunks can be re-concatenated into the single combined buffer in
    // chunkMeshes — trading a slightly heavier re-upload on edits/streaming for up
    // to 4x fewer draw calls every single frame.
    private val chunkMeshes = HashMap<ChunkPos, ChunkGpuMesh>()
    private val columnMeshData = HashMap<ChunkPos, Array<MeshData?>>()
    private val particleMesh = ChunkGpuMesh()
    private val cloudMesh = ChunkGpuMesh()
    private val highlightMesh = ChunkGpuMesh()

    private var lastCloudCell: Pair<Int, Int>? = null
    private var lastHighlightBlock: Triple<Int, Int, Int>? = null

    private var particleFloats = FloatArray(0)
    private var particleIndices = IntArray(0)

    private var lastFrameTimeNanos = 0L
    private var fpsAccumTime = 0f
    private var fpsAccumFrames = 0
    private var currentFps = 0f
    private val mainHandler = Handler(Looper.getMainLooper())

    companion object {
        private const val SKY_R = 0.47f
        private const val SKY_G = 0.68f
        private const val SKY_B = 0.86f
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        shader = ShaderProgram(Shaders.VERTEX, Shaders.FRAGMENT)
        uViewProj = shader.uniform("uViewProj")
        uTexture = shader.uniform("uTexture")
        uFogColor = shader.uniform("uFogColor")
        uFogStart = shader.uniform("uFogStart")
        uFogEnd = shader.uniform("uFogEnd")
        uAlpha = shader.uniform("uAlpha")

        atlas.uploadToGL()

        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glDisable(GLES30.GL_CULL_FACE) // see ChunkMesher: faces aren't wound for culling
        GLES30.glClearColor(SKY_R, SKY_G, SKY_B, 1f)

        // The context (and any GPU handles in it) may have just been recreated
        // (e.g. after backgrounding) while world/chunk state persisted — drop our
        // now-invalid mesh handles and ask WorldManager to remesh everything it
        // still has loaded so the terrain reappears instead of staying blank.
        chunkMeshes.clear()
        columnMeshData.clear()
        lastCloudCell = null
        lastHighlightBlock = null
        engine.worldManager.remeshAllLoaded()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        aspect = if (height > 0) width.toFloat() / height.toFloat() else 1f
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (lastFrameTimeNanos == 0L) 0.016f else ((now - lastFrameTimeNanos) / 1_000_000_000f).coerceIn(0f, 0.1f)
        lastFrameTimeNanos = now

        if (!paused) engine.update(dt)
        drainMeshUploads()
        drainUnloads()

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        val renderDistanceChunks = engine.settings.renderDistance.chunks
        camera.farPlane = renderDistanceChunks * WorldConfig.CHUNK_SIZE.toFloat() + 40f
        camera.setPerspective(aspect)

        val p = engine.player
        camera.updateView(p.eyeX(), p.eyeY() + engine.bobOffset, p.eyeZ(), p.yaw, p.pitch)
        frustum.update(camera.viewProjMatrix)

        shader.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, camera.viewProjMatrix, 0)
        GLES30.glUniform3f(uFogColor, SKY_R, SKY_G, SKY_B)
        val fogEnd = renderDistanceChunks * WorldConfig.CHUNK_SIZE * 0.9f
        GLES30.glUniform1f(uFogStart, fogEnd * 0.55f)
        GLES30.glUniform1f(uFogEnd, fogEnd)
        GLES30.glUniform1f(uAlpha, 1f)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        atlas.bind(0)
        GLES30.glUniform1i(uTexture, 0)

        drawChunks()
        drawHighlight()
        if (engine.settings.particlesEnabled) drawParticles()
        if (engine.settings.cloudsEnabled) drawClouds()

        updateFps(dt)
    }

    // ---- Streaming hand-off (background threads -> GPU) ---------------------------

    private fun drainMeshUploads() {
        var budget = 6 // caps GPU uploads per frame so a burst of finished chunks can't spike frame time
        // A freshly-generated chunk enqueues all 4 of its subchunks together (see
        // WorldManager.onChunkGenerated), so they routinely finish and land here
        // within the same drain pass — collect which columns actually changed and
        // concatenate/upload each one once, after the loop, rather than once per
        // individual subchunk result.
        val touched = LinkedHashSet<ChunkPos>()
        while (budget-- > 0) {
            val result = engine.worldManager.pendingMeshUploads.poll() ?: break
            val slots = columnMeshData.getOrPut(result.pos) { arrayOfNulls(WorldConfig.SUBCHUNKS_PER_CHUNK) }
            if (result.subY !in slots.indices) continue // out-of-range subY: drop this result rather than crash
            slots[result.subY] = result.data
            touched.add(result.pos)
        }
        for (pos in touched) {
            val slots = columnMeshData[pos] ?: continue
            val mesh = chunkMeshes.getOrPut(pos) { ChunkGpuMesh() }
            mesh.upload(concatenateColumn(slots))
        }
    }

    /** Combines a column's up-to-4 subchunk meshes into one buffer. Vertex
     *  positions are already in world space (see ChunkMesher), so no offsetting is
     *  needed there — only each subchunk's indices need shifting by the vertex
     *  count of whatever was already appended ahead of it, since indices are
     *  per-subchunk-local vertex numbers. */
    private fun concatenateColumn(slots: Array<MeshData?>): MeshData {
        var totalVerts = 0
        var totalIndices = 0
        for (s in slots) {
            if (s == null) continue
            totalVerts += s.vertexCount
            totalIndices += s.indices.size
        }
        if (totalVerts == 0) return MeshData.EMPTY

        val floats = FloatArray(totalVerts * MeshData.FLOATS_PER_VERTEX)
        val indices = IntArray(totalIndices)
        var vertOffset = 0
        var floatOffset = 0
        var indexOffset = 0
        for (s in slots) {
            if (s == null || s.vertexCount == 0) continue
            System.arraycopy(s.vertexData, 0, floats, floatOffset, s.vertexData.size)
            for (k in s.indices.indices) indices[indexOffset + k] = s.indices[k] + vertOffset
            floatOffset += s.vertexData.size
            indexOffset += s.indices.size
            vertOffset += s.vertexCount
        }
        return MeshData(floats, indices, vertOffset)
    }

    private fun drainUnloads() {
        while (true) {
            val pos = engine.worldManager.pendingUnloads.poll() ?: break
            chunkMeshes.remove(pos)?.dispose()
            columnMeshData.remove(pos)
        }
    }

    // ---- Drawing --------------------------------------------------------------

    private fun drawChunks() {
        for ((pos, mesh) in chunkMeshes) {
            if (!mesh.hasContent) continue // skip the frustum test too: nothing to draw here
            val baseX = (pos.x * WorldConfig.CHUNK_SIZE).toFloat()
            val baseZ = (pos.z * WorldConfig.CHUNK_SIZE).toFloat()
            // Tests the whole column's height in one box rather than one box per
            // subchunk: a little less precise culling (a column with only its
            // topmost sliver actually on-screen still passes whole) in exchange for
            // one draw call per column instead of up to four. Always safe/conservative
            // — a box containing the true geometry never wrongly culls it.
            val visible = frustum.isBoxVisible(
                baseX, 0f, baseZ,
                baseX + WorldConfig.CHUNK_SIZE, WorldConfig.WORLD_HEIGHT.toFloat(), baseZ + WorldConfig.CHUNK_SIZE
            )
            if (visible) mesh.draw()
        }
    }

    private fun drawHighlight() {
        val hit = engine.lastHit
        if (hit == null) {
            lastHighlightBlock = null
            return
        }
        val block = Triple(hit.blockX, hit.blockY, hit.blockZ)
        if (block != lastHighlightBlock) {
            lastHighlightBlock = block
            uploadHighlightBox(hit.blockX.toFloat(), hit.blockY.toFloat(), hit.blockZ.toFloat())
        }
        GLES30.glUniform1f(uAlpha, 1f)
        highlightMesh.draw(GLES30.GL_LINES)
    }

    private fun uploadHighlightBox(x: Float, y: Float, z: Float) {
        val e = 0.002f // tiny outward expansion avoids z-fighting with the block's own faces
        val x0 = x - e; val x1 = x + 1 + e
        val y0 = y - e; val y1 = y + 1 + e
        val z0 = z - e; val z1 = z + 1 + e
        val corners = arrayOf(
            floatArrayOf(x0, y0, z0), floatArrayOf(x1, y0, z0), floatArrayOf(x1, y0, z1), floatArrayOf(x0, y0, z1),
            floatArrayOf(x0, y1, z0), floatArrayOf(x1, y1, z0), floatArrayOf(x1, y1, z1), floatArrayOf(x0, y1, z1)
        )
        val edges = arrayOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 0,
            4 to 5, 5 to 6, 6 to 7, 7 to 4,
            0 to 4, 1 to 5, 2 to 6, 3 to 7
        )
        val uv = atlas.uvFor(TextureAtlas.WHITE_CELL)
        val floats = FloatArray(edges.size * 2 * 6)
        var fi = 0
        for ((a, b) in edges) {
            for (idx in intArrayOf(a, b)) {
                val c = corners[idx]
                floats[fi++] = c[0]; floats[fi++] = c[1]; floats[fi++] = c[2]
                floats[fi++] = uv.u0; floats[fi++] = uv.v0
                floats[fi++] = 1.3f // >1 shade reads as a bright, unmistakable outline
            }
        }
        val indices = IntArray(edges.size * 2) { it }
        highlightMesh.upload(MeshData(floats, indices, edges.size * 2))
    }

    private fun drawParticles() {
        val n = engine.particles.count()
        if (n == 0) return

        val neededFloats = n * 24 * 6
        val neededIndices = n * 36
        if (particleFloats.size < neededFloats) particleFloats = FloatArray(neededFloats)
        if (particleIndices.size < neededIndices) particleIndices = IntArray(neededIndices)

        var vCount = 0
        var iCount = 0
        for (p in 0 until n) {
            val cx = engine.particles.x(p); val cy = engine.particles.y(p); val cz = engine.particles.z(p)
            val half = engine.particles.scale(p)
            val uv = atlas.uvFor(engine.particles.cellOf(p))
            val x0 = cx - half; val x1 = cx + half
            val y0 = cy - half; val y1 = cy + half
            val z0 = cz - half; val z1 = cz + half

            val faces = arrayOf(
                floatArrayOf(x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1),
                floatArrayOf(x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0),
                floatArrayOf(x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0),
                floatArrayOf(x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1),
                floatArrayOf(x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0),
                floatArrayOf(x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1)
            )
            val us = floatArrayOf(uv.u0, uv.u1, uv.u1, uv.u0)
            val vs = floatArrayOf(uv.v0, uv.v0, uv.v1, uv.v1)
            for (face in faces) {
                val base = vCount
                for (k in 0..3) {
                    var fi = vCount * 6
                    particleFloats[fi++] = face[k * 3]
                    particleFloats[fi++] = face[k * 3 + 1]
                    particleFloats[fi++] = face[k * 3 + 2]
                    particleFloats[fi++] = us[k]
                    particleFloats[fi++] = vs[k]
                    particleFloats[fi] = 1f
                    vCount++
                }
                particleIndices[iCount++] = base
                particleIndices[iCount++] = base + 1
                particleIndices[iCount++] = base + 2
                particleIndices[iCount++] = base
                particleIndices[iCount++] = base + 2
                particleIndices[iCount++] = base + 3
            }
        }

        particleMesh.upload(MeshData(particleFloats.copyOf(vCount * 6), particleIndices.copyOf(iCount), vCount))
        GLES30.glUniform1f(uAlpha, 1f)
        particleMesh.draw()
    }

    private fun drawClouds() {
        val cloudY = (WorldConfig.WORLD_HEIGHT + 24).toFloat()
        val half = 220f
        val cellSize = 64f
        val px = engine.player.position.x
        val pz = engine.player.position.z
        val cellX = (floor(px / cellSize) * cellSize).toInt()
        val cellZ = (floor(pz / cellSize) * cellSize).toInt()
        val key = cellX to cellZ
        if (key != lastCloudCell) {
            lastCloudCell = key
            uploadCloudQuad(cellX.toFloat(), cloudY, cellZ.toFloat(), half)
        }

        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glUniform1f(uAlpha, 0.35f)
        cloudMesh.draw()
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glUniform1f(uAlpha, 1f)
    }

    private fun uploadCloudQuad(cx: Float, cy: Float, cz: Float, half: Float) {
        val uv = atlas.uvFor(TextureAtlas.WHITE_CELL)
        val floats = floatArrayOf(
            cx - half, cy, cz - half, uv.u0, uv.v0, 1f,
            cx + half, cy, cz - half, uv.u1, uv.v0, 1f,
            cx + half, cy, cz + half, uv.u1, uv.v1, 1f,
            cx - half, cy, cz + half, uv.u0, uv.v1, 1f
        )
        val indices = intArrayOf(0, 1, 2, 0, 2, 3)
        cloudMesh.upload(MeshData(floats, indices, 4))
    }

    private fun updateFps(dt: Float) {
        fpsAccumTime += dt
        fpsAccumFrames++
        if (fpsAccumTime >= 0.4f) {
            currentFps = fpsAccumFrames / fpsAccumTime
            fpsAccumTime = 0f
            fpsAccumFrames = 0
            val statsText = if (engine.settings.showFps) "FPS: ${currentFps.toInt()}\n${engine.debugStats()}" else null
            mainHandler.post { onPeriodicTick(statsText) }
        }
    }
}
