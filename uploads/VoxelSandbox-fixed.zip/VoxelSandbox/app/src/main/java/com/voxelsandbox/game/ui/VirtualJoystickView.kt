package com.voxelsandbox.game.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Classic fixed-base virtual joystick. Tracks its own pointer ID so a second finger
 * landing on this view (or the look pad, which is a separate sibling view and gets
 * its own independent touch stream from Android automatically) doesn't steal control.
 */
class VirtualJoystickView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var onChanged: ((forward: Float, strafe: Float) -> Unit)? = null

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAFFFFFF.toInt() }

    private var centerX = 0f
    private var centerY = 0f
    private var knobX = 0f
    private var knobY = 0f
    private var maxRadius = 0f
    private var activePointerId = -1

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        centerX = w / 2f
        centerY = h / 2f
        knobX = centerX
        knobY = centerY
        maxRadius = min(w, h) / 2f * 0.75f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawCircle(centerX, centerY, min(width, height) / 2f * 0.9f, basePaint)
        canvas.drawCircle(knobX, knobY, min(width, height) / 2f * 0.32f, knobPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (activePointerId == -1) {
                    val idx = event.actionIndex
                    activePointerId = event.getPointerId(idx)
                    updateKnob(event.getX(idx), event.getY(idx))
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = event.findPointerIndex(activePointerId)
                if (idx >= 0) updateKnob(event.getX(idx), event.getY(idx))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val idx = event.actionIndex
                if (idx >= 0 && event.getPointerId(idx) == activePointerId) release()
            }
            MotionEvent.ACTION_CANCEL -> release()
        }
        return true
    }

    private fun release() {
        activePointerId = -1
        knobX = centerX
        knobY = centerY
        onChanged?.invoke(0f, 0f)
        invalidate()
    }

    /** Forcibly ends whatever touch this view is currently tracking and snaps the
     *  knob back to centered/neutral, without waiting for that touch's own
     *  ACTION_UP/POINTER_UP/CANCEL to arrive here. Normally this view resets itself
     *  perfectly fine — but if gameplay is interrupted (pause menu, HUD-customize
     *  mode swapping in its own touch listener, a system dialog stealing the
     *  gesture) while a finger is down on the joystick, that finger's eventual lift
     *  never reaches this view's onTouchEvent, so [activePointerId] stays latched
     *  onto a pointer id that will never occur again — silently swallowing every
     *  future touch down on this control from then on. HudController calls this
     *  from releaseAllInputs() to close that gap. */
    fun cancelActiveTouch() {
        if (activePointerId != -1) release()
    }

    private fun updateKnob(x: Float, y: Float) {
        val dx = x - centerX
        val dy = y - centerY
        val dist = sqrt(dx * dx + dy * dy)
        if (dist <= maxRadius || maxRadius <= 0f) {
            knobX = x; knobY = y
        } else {
            val s = maxRadius / dist
            knobX = centerX + dx * s
            knobY = centerY + dy * s
        }
        val nx = if (maxRadius > 0f) (knobX - centerX) / maxRadius else 0f
        val ny = if (maxRadius > 0f) (knobY - centerY) / maxRadius else 0f
        // Screen "up" (negative Y) is forward, so invert Y here.
        onChanged?.invoke(-ny, nx)
        invalidate()
    }
}
