package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.mesh.MeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Owns one subchunk's GPU vertex/index buffers. Every method here issues GL calls,
 * so instances must only ever be touched from the GL thread (GameRenderer enforces
 * this by only creating/uploading/disposing from onDrawFrame).
 */
class ChunkGpuMesh {
    private var vao = 0
    private var vbo = 0
    private var ibo = 0
    private var indexCount = 0
    private var allocated = false

    /** True once this mesh has real geometry to draw. GameRenderer checks this
     *  before doing the 6-plane frustum test, so subchunks with nothing in them
     *  (open sky, fully sealed underground) cost nothing per frame beyond this one
     *  flag check — at a 60-chunk render distance a large fraction of loaded
     *  subchunks fall into this category. */
    val hasContent: Boolean get() = allocated && indexCount > 0

    // Reused across uploads instead of a fresh ByteBuffer.allocateDirect(...) every
    // call: at high render distance, hundreds of subchunks can finish meshing in a
    // short burst (e.g. right after changing the render-distance setting), and
    // allocating a new native buffer per upload on the GL thread for every one of
    // them is a real, avoidable source of frame-time spikes/GC churn. Buffers only
    // grow, never shrink, and are addressed by the shared static instance below.
    private object Scratch {
        var vertexBuf: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
        var indexBuf: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())

        fun vertexFloats(count: Int): java.nio.FloatBuffer {
            val bytes = count * 4
            if (vertexBuf.capacity() < bytes) vertexBuf = ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder())
            vertexBuf.clear()
            return vertexBuf.asFloatBuffer()
        }

        fun indexInts(count: Int): java.nio.IntBuffer {
            val bytes = count * 4
            if (indexBuf.capacity() < bytes) indexBuf = ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder())
            indexBuf.clear()
            return indexBuf.asIntBuffer()
        }
    }

    fun upload(data: MeshData) {
        if (data.isEmpty()) {
            dispose()
            return
        }

        val vertexBuffer = Scratch.vertexFloats(data.vertexData.size).apply { put(data.vertexData); position(0) }
        val indexBuffer = Scratch.indexInts(data.indices.size).apply { put(data.indices); position(0) }

        if (!allocated) {
            val vaoIds = IntArray(1)
            GLES30.glGenVertexArrays(1, vaoIds, 0)
            vao = vaoIds[0]
            val ids = IntArray(2)
            GLES30.glGenBuffers(2, ids, 0)
            vbo = ids[0]
            ibo = ids[1]

            // The vertex layout below is identical for every mesh in the game (see
            // MeshBuilder) and, for a given vbo/ibo pair, never changes again after
            // this — so it's recorded into the VAO exactly once here, rather than
            // reissued via 3x(glEnableVertexAttribArray+glVertexAttribPointer) on
            // every single draw() call for every visible chunk, every frame. Binding
            // the element buffer while this vao is bound records that association
            // into the vao too, so draw() doesn't need to re-bind it either.
            GLES30.glBindVertexArray(vao)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
            val stride = 6 * 4
            GLES30.glEnableVertexAttribArray(0)
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, stride, 0)
            GLES30.glEnableVertexAttribArray(1)
            GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, stride, 3 * 4)
            GLES30.glEnableVertexAttribArray(2)
            GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, stride, 5 * 4)
            GLES30.glBindVertexArray(0)

            allocated = true
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.vertexData.size * 4, vertexBuffer, GLES30.GL_STATIC_DRAW)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, data.indices.size * 4, indexBuffer, GLES30.GL_STATIC_DRAW)

        indexCount = data.indices.size
    }

    /** [mode] defaults to GL_TRIANGLES for normal terrain/particle/cloud meshes;
     *  GameRenderer passes GL_LINES for the block-highlight wireframe so it can
     *  reuse this same buffer/shader plumbing instead of a separate code path. */
    fun draw(mode: Int = GLES30.GL_TRIANGLES) {
        if (!allocated || indexCount == 0) return
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawElements(mode, indexCount, GLES30.GL_UNSIGNED_INT, 0)
    }

    fun dispose() {
        if (allocated) {
            GLES30.glDeleteBuffers(2, intArrayOf(vbo, ibo), 0)
            GLES30.glDeleteVertexArrays(1, intArrayOf(vao), 0)
            allocated = false
            indexCount = 0
        }
    }

    /** Marks this mesh's GL objects as gone WITHOUT issuing glDelete* calls — for
     *  when the EGL context itself was just destroyed and recreated (see
     *  GameRenderer.onSurfaceCreated). The old vao/vbo/ibo handles are already
     *  meaningless in the new context (deleting them would at best be a no-op,
     *  and at worst silently target unrelated objects that happen to reuse the
     *  same integer names in the new context), so this just clears the flag and
     *  lets the next upload() allocate fresh objects instead. */
    fun invalidateForContextLoss() {
        allocated = false
        indexCount = 0
    }
}
