package com.voxelsandbox.game.crash

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Minimal, dependency-free crash logger. This game is built and tested entirely from
 * a phone via GitHub Actions with no PC/ADB access, so logcat is never reachable
 * after something crashes — without this, a crash leaves nothing to go on beyond
 * "it crashed." Writes a plain-text report to internal storage that
 * GameActivity offers to show (as selectable, copyable text) the next time the app
 * launches, then hands off to whatever crash handling already existed so the OS's
 * normal "app has stopped" behavior is unaffected.
 *
 * [install] must run as the very first line of GameActivity.onCreate, before
 * anything else gets a chance to throw.
 */
object CrashReporter {
    private const val FILE_NAME = "last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrash(appContext, thread, throwable)
            } catch (ignored: Throwable) {
                // Logging the crash must never be the reason the handler itself
                // throws — that would just trade one unhandled exception for
                // another and could stop the OS's own "app has stopped" flow from
                // running at all.
            }
            if (previous != null) {
                previous.uncaughtException(thread, throwable)
            } else {
                android.os.Process.killProcess(android.os.Process.myPid())
                kotlin.system.exitProcess(10)
            }
        }
    }

    private fun writeCrash(context: Context, thread: Thread, throwable: Throwable) {
        val stackTrace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val maxMb = rt.maxMemory() / (1024 * 1024)
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val report = buildString {
            appendLine("VoxelSandbox crash report")
            appendLine("Time: $timestamp")
            appendLine("Thread: ${thread.name}")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            // Heap use at the moment of the crash — the most useful single number
            // for telling an out-of-memory crash apart from anything else: maxMb is
            // this app's actual heap ceiling (see WorldManager.computeChunkBudget),
            // and usedMb sitting right up against it is a strong signal of exactly
            // that, even when the exception itself isn't a plain OutOfMemoryError
            // (a GC-thrashing app can throw from all kinds of unrelated places
            // first).
            appendLine("Heap: ${usedMb}MB used / ${maxMb}MB max")
            appendLine()
            append(stackTrace)
        }
        File(context.filesDir, FILE_NAME).writeText(report)
    }

    private fun crashFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun readPendingCrash(context: Context): String? {
        val f = crashFile(context)
        return if (f.exists()) f.readText() else null
    }

    fun clearPendingCrash(context: Context) {
        crashFile(context).delete()
    }
}
