package com.voxelsandbox.game.ui

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Reports raw drag deltas for camera look. Deliberately draws nothing (fully
 * transparent) and covers a large area — the action buttons sit on top of it in the
 * layout and, being drawn later, receive their own touches first, so this view only
 * ever sees drags that don't start on a button.
 */
class LookPadView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    var onLookDelta: ((dx: Float, dy: Float) -> Unit)? = null

    private var activePointerId = -1
    private var lastX = 0f
    private var lastY = 0f
    private val density = resources.displayMetrics.density

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (activePointerId == -1) {
                    val idx = event.actionIndex
                    activePointerId = event.getPointerId(idx)
                    lastX = event.getX(idx)
                    lastY = event.getY(idx)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val idx = event.findPointerIndex(activePointerId)
                if (idx >= 0) {
                    val x = event.getX(idx)
                    val y = event.getY(idx)
                    // Normalized to dp so look sensitivity feels consistent across
                    // different screen densities rather than varying with raw pixels.
                    onLookDelta?.invoke((x - lastX) / density, (y - lastY) / density)
                    lastX = x; lastY = y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val idx = event.actionIndex
                if (idx >= 0 && event.getPointerId(idx) == activePointerId) activePointerId = -1
            }
            MotionEvent.ACTION_CANCEL -> activePointerId = -1
        }
        return true
    }

    /** Forcibly ends whatever touch this view is tracking, without waiting for its
     *  own ACTION_UP/CANCEL — see VirtualJoystickView.cancelActiveTouch for the full
     *  explanation of why that event can silently never arrive. Look has no
     *  persistent value to reset (each frame only cares about the delta since the
     *  last one), so there's nothing to snap back beyond the latched pointer id. */
    fun cancelActiveTouch() {
        activePointerId = -1
    }
}
