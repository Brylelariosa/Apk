package com.voxelsandbox.game

import android.app.Activity
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import com.voxelsandbox.game.engine.GameEngine
import com.voxelsandbox.game.gl.GameRenderer
import com.voxelsandbox.game.save.LoadedSave
import com.voxelsandbox.game.save.SaveManager
import com.voxelsandbox.game.settings.GameSettings
import com.voxelsandbox.game.settings.GraphicsQuality
import com.voxelsandbox.game.settings.RenderDistancePreset
import com.voxelsandbox.game.ui.HudController
import java.util.concurrent.Executors

/**
 * The app's only Activity. Gameplay screens (main menu / loading / playing / paused /
 * settings) are overlay Views toggled on one root layout rather than separate
 * Activities, so the GL context and world state never need to survive an Activity
 * transition — only a much simpler show/hide of a few FrameLayouts.
 */
class GameActivity : Activity() {

    private enum class Screen { MAIN_MENU, LOADING, PLAYING, PAUSED, SETTINGS }

    private lateinit var settings: GameSettings
    private lateinit var saveManager: SaveManager
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var glSurfaceView: GLSurfaceView? = null
    private var renderer: GameRenderer? = null
    private var engine: GameEngine? = null
    private var hud: HudController? = null

    private var currentScreen = Screen.MAIN_MENU
    private var settingsOpenedFrom = Screen.MAIN_MENU

    private lateinit var glContainer: FrameLayout
    private lateinit var mainMenuOverlay: View
    private lateinit var pauseOverlay: View
    private lateinit var settingsOverlay: View
    private lateinit var loadingOverlay: View
    private lateinit var hudOverlay: View

    private lateinit var spinnerRenderDistance: Spinner
    private lateinit var spinnerGraphicsQuality: Spinner
    private lateinit var seekTouchSensitivity: SeekBar
    private lateinit var seekLookSensitivity: SeekBar
    private lateinit var switchFps: Switch
    private lateinit var switchBobbing: Switch
    private lateinit var switchClouds: Switch
    private lateinit var switchParticles: Switch
    private lateinit var switchAutoJump: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        settings = GameSettings(this)
        saveManager = SaveManager(this)

        glContainer = findViewById(R.id.gl_container)
        mainMenuOverlay = findViewById(R.id.main_menu_overlay)
        pauseOverlay = findViewById(R.id.pause_overlay)
        settingsOverlay = findViewById(R.id.settings_overlay)
        loadingOverlay = findViewById(R.id.loading_overlay)
        hudOverlay = findViewById(R.id.hud_overlay)

        findViewById<Button>(R.id.btn_new_world).setOnClickListener { startNewWorld() }
        findViewById<Button>(R.id.btn_continue_world).setOnClickListener { continueWorld() }
        findViewById<Button>(R.id.btn_menu_settings).setOnClickListener { openSettings(Screen.MAIN_MENU) }
        findViewById<Button>(R.id.btn_exit).setOnClickListener { finish() }

        findViewById<Button>(R.id.btn_resume).setOnClickListener { resumeFromPause() }
        findViewById<Button>(R.id.btn_pause_settings).setOnClickListener { openSettings(Screen.PAUSED) }
        findViewById<Button>(R.id.btn_customize_hud).setOnClickListener { customizeHud() }
        findViewById<Button>(R.id.btn_save_quit).setOnClickListener { saveAndQuitToMenu() }

        findViewById<Button>(R.id.btn_settings_back).setOnClickListener { closeSettings() }
        findViewById<Button>(R.id.btn_settings_apply).setOnClickListener { applySettings(); closeSettings() }

        setupSettingsControls()
        showScreen(Screen.MAIN_MENU)
    }

    // ---- Screen management ------------------------------------------------------

    private fun showScreen(screen: Screen) {
        currentScreen = screen
        mainMenuOverlay.visibility = if (screen == Screen.MAIN_MENU) View.VISIBLE else View.GONE
        loadingOverlay.visibility = if (screen == Screen.LOADING) View.VISIBLE else View.GONE
        pauseOverlay.visibility = if (screen == Screen.PAUSED) View.VISIBLE else View.GONE
        settingsOverlay.visibility = if (screen == Screen.SETTINGS) View.VISIBLE else View.GONE
        hudOverlay.visibility = if (screen == Screen.PLAYING) View.VISIBLE else View.GONE
        renderer?.paused = (screen != Screen.PLAYING)

        if (screen == Screen.MAIN_MENU) {
            findViewById<Button>(R.id.btn_continue_world).isEnabled = saveManager.hasSave()
        }
    }

    private fun startNewWorld() {
        createEngineAndPlay(null)
    }

    private fun continueWorld() {
        showScreen(Screen.LOADING)
        ioExecutor.execute {
            val loaded = saveManager.load()
            mainHandler.post { createEngineAndPlay(loaded) }
        }
    }

    private fun createEngineAndPlay(loaded: LoadedSave?) {
        teardownEngine()

        val newEngine = GameEngine(this, settings, loaded)
        engine = newEngine

        val gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            preserveEGLContextOnPause = true
        }
        val newRenderer = GameRenderer(newEngine) { statsText -> onPeriodicTick(statsText) }
        gl.setRenderer(newRenderer)
        renderer = newRenderer
        glContainer.removeAllViews()
        glContainer.addView(gl)
        glSurfaceView = gl

        hud = HudController(hudOverlay, newEngine.input, newEngine.inventory) { pauseGame() }
        showScreen(Screen.PLAYING)
    }

    private fun onPeriodicTick(statsText: String?) {
        val h = hud ?: return
        if (statsText != null) {
            h.debugText.visibility = View.VISIBLE
            h.debugText.text = statsText
        } else {
            h.debugText.visibility = View.GONE
        }
        h.refreshHotbar()
    }

    private fun pauseGame() {
        hud?.releaseAllInputs()
        hud?.exitCustomizeMode() // safety net: never carry a frozen edit session into the pause menu
        showScreen(Screen.PAUSED)
    }

    private fun resumeFromPause() {
        showScreen(Screen.PLAYING)
    }

    private fun customizeHud() {
        resumeFromPause() // same transition Resume uses; edit mode overlays live gameplay
        hud?.enterCustomizeMode()
    }

    private fun openSettings(from: Screen) {
        settingsOpenedFrom = from
        loadSettingsIntoControls()
        showScreen(Screen.SETTINGS)
    }

    private fun closeSettings() {
        showScreen(settingsOpenedFrom)
    }

    private fun saveAndQuitToMenu() {
        val eng = engine ?: return
        showScreen(Screen.LOADING)
        eng.worldManager.shutdown() // stop background gen/mesh so the save snapshot is stable
        ioExecutor.execute {
            try {
                saveManager.save(eng.seed, eng.player, eng.inventory, eng.world)
            } catch (t: Throwable) {
                // Best-effort: failing to save shouldn't trap the player outside the menu.
            }
            mainHandler.post {
                teardownEngine()
                showScreen(Screen.MAIN_MENU)
            }
        }
    }

    private fun teardownEngine() {
        glSurfaceView?.onPause()
        engine?.shutdown()
        glContainer.removeAllViews()
        glSurfaceView = null
        renderer = null
        engine = null
        hud = null
    }

    // ---- Settings screen ----------------------------------------------------------

    private fun setupSettingsControls() {
        spinnerRenderDistance = findViewById(R.id.spinner_render_distance)
        spinnerGraphicsQuality = findViewById(R.id.spinner_graphics_quality)
        seekTouchSensitivity = findViewById(R.id.seek_touch_sensitivity)
        seekLookSensitivity = findViewById(R.id.seek_look_sensitivity)
        switchFps = findViewById(R.id.switch_fps)
        switchBobbing = findViewById(R.id.switch_bobbing)
        switchClouds = findViewById(R.id.switch_clouds)
        switchParticles = findViewById(R.id.switch_particles)
        switchAutoJump = findViewById(R.id.switch_auto_jump)

        spinnerRenderDistance.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            RenderDistancePreset.values().map { "${it.label} (${it.chunks})" }
        )
        spinnerGraphicsQuality.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            GraphicsQuality.values().map { it.label }
        )
    }

    private fun loadSettingsIntoControls() {
        spinnerRenderDistance.setSelection(settings.renderDistance.ordinal)
        spinnerGraphicsQuality.setSelection(settings.graphicsQuality.ordinal)
        seekTouchSensitivity.progress = (settings.touchSensitivity * 100).toInt()
        seekLookSensitivity.progress = (settings.lookSensitivity * 100).toInt()
        switchFps.isChecked = settings.showFps
        switchBobbing.isChecked = settings.viewBobbing
        switchClouds.isChecked = settings.cloudsEnabled
        switchParticles.isChecked = settings.particlesEnabled
        switchAutoJump.isChecked = settings.autoJump
    }

    private fun applySettings() {
        settings.renderDistance = RenderDistancePreset.fromOrdinalSafe(spinnerRenderDistance.selectedItemPosition)
        settings.graphicsQuality = GraphicsQuality.fromOrdinalSafe(spinnerGraphicsQuality.selectedItemPosition)
        settings.touchSensitivity = seekTouchSensitivity.progress / 100f
        settings.lookSensitivity = seekLookSensitivity.progress / 100f
        settings.showFps = switchFps.isChecked
        settings.viewBobbing = switchBobbing.isChecked
        settings.cloudsEnabled = switchClouds.isChecked
        settings.particlesEnabled = switchParticles.isChecked
        settings.autoJump = switchAutoJump.isChecked
        settings.persist()
        if (!settings.showFps) hud?.debugText?.visibility = View.GONE
    }

    // ---- Lifecycle ------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        glSurfaceView?.onResume()
        hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        glSurfaceView?.onPause()
        if (currentScreen == Screen.PLAYING) {
            hud?.releaseAllInputs()
            hud?.exitCustomizeMode()
            showScreen(Screen.PAUSED)
        }
        autoSaveIfActive()
    }

    override fun onDestroy() {
        super.onDestroy()
        engine?.shutdown()
        ioExecutor.shutdown()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (currentScreen) {
            Screen.PLAYING -> pauseGame()
            Screen.PAUSED -> resumeFromPause()
            Screen.SETTINGS -> closeSettings()
            Screen.LOADING -> { /* ignore back while a load/save is in flight */ }
            Screen.MAIN_MENU -> super.onBackPressed()
        }
    }

    private fun autoSaveIfActive() {
        val eng = engine ?: return
        ioExecutor.execute {
            try {
                saveManager.save(eng.seed, eng.player, eng.inventory, eng.world)
            } catch (t: Throwable) {
                // Best-effort autosave on backgrounding; never let this crash the app.
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }
}
