package com.voxelsandbox.game.ui

import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Attached to a HUD element only while HUD-customize mode is active (see
 * HudController.enterCustomizeMode). One finger drags the view by adjusting its
 * translationX/Y; a two-finger pinch resizes it by adjusting scaleX/Y uniformly,
 * pivoting on the view's own center (View's default pivot, so it grows/shrinks in
 * place rather than from a corner). [onAdjusted] fires once per gesture, on finger-up,
 * so the caller can persist the resulting position/scale.
 */
class DragResizeTouchListener(
    private val view: View,
    private val minScale: Float = 0.6f,
    private val maxScale: Float = 1.8f,
    private val onAdjusted: () -> Unit
) : View.OnTouchListener {
    private var lastRawX = 0f
    private var lastRawY = 0f

    private val scaleDetector = ScaleGestureDetector(
        view.context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val next = (view.scaleX * detector.scaleFactor).coerceIn(minScale, maxScale)
                view.scaleX = next
                view.scaleY = next
                return true
            }
        }
    )

    /** event.rawX/rawY (no-arg) always report pointer INDEX 0's position, no matter
     *  which pointer this particular action is actually about. Diffing them straight
     *  across a pointer-count change (e.g. lifting the first finger during a
     *  two-finger resize) silently mixes two different fingers' positions and
     *  produces a sudden jump in the button's translation. These two derive a
     *  specific pointer's raw/screen position from its view-local getX/Y plus the
     *  event's local-to-raw offset, which works back to minSdk 24 without the
     *  pointerIndex overload of getRawX/Y (API 29+ only). */
    private fun rawX(event: MotionEvent, idx: Int) = event.getX(idx) + (event.rawX - event.getX())
    private fun rawY(event: MotionEvent, idx: Int) = event.getY(idx) + (event.rawY - event.getY())

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                lastRawX = rawX(event, 0)
                lastRawY = rawY(event, 0)
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // The finger at actionIndex is about to be removed — if pointer 0 is
                // the one leaving, resync from whichever index will hold the
                // surviving finger once it's gone (this control only ever sees at
                // most two fingers, so "the other one" is unambiguous).
                val remainingIdx = if (event.actionIndex == 0) 1 else 0
                if (remainingIdx < event.pointerCount) {
                    lastRawX = rawX(event, remainingIdx)
                    lastRawY = rawY(event, remainingIdx)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val x = rawX(event, 0)
                val y = rawY(event, 0)
                if (event.pointerCount == 1 && !scaleDetector.isInProgress) {
                    v.translationX += x - lastRawX
                    v.translationY += y - lastRawY
                }
                lastRawX = x
                lastRawY = y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onAdjusted()
        }
        return true
    }
}
