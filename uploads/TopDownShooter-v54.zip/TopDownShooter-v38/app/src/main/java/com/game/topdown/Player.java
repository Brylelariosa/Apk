package com.game.topdown;

public class Player {
    public int    id;
    public String name   = "";
    public float  x, y, angle;
    public float  hp     = 100;
    public int    gunIndex;
    public boolean alive = true;
    public Gun[]  guns;
    public Gun currentGun() { return guns[gunIndex]; }

    // Economy & unlock state
    public int       coins        = 0;
    public boolean[] unlockedGuns = {true,false,false,false,false,false,false,false,false,false};

    // Bombs
    public int bombs = 2;

    // ── Spawn protection (3 s) ────────────────────────────────────────────────
    public volatile long spawnProtectionUntil = 0;
    public boolean isProtected() { return System.currentTimeMillis() < spawnProtectionUntil; }

    // ── Passive skills (0-3 levels each) ──────────────────────────────────────
    public int skillReload    = 0;   // -20 % reload time per level
    public int skillFireRate  = 0;   // +20 % fire rate per level
    public int skillRange     = 0;   // +25 % bullet range per level
    public int skillMoveSpeed = 0;   // +12 % move speed per level

    public float reloadMult()    { return 1f / (1f + 0.20f * skillReload);   }
    public float fireRateMult()  { return 1f + 0.20f * skillFireRate;         }
    public float rangeMult()     { return 1f + 0.25f * skillRange;            }
    public float moveSpeedMult() { return 1f + 0.12f * skillMoveSpeed;        }

    // ── Active skill (one equipped, one press to use) ─────────────────────────
    public static final int ACTIVE_NONE = 0, ACTIVE_DASH = 1,
                             ACTIVE_STEALTH = 2, ACTIVE_HEAL = 3, ACTIVE_SHIELD = 4;
    public int   activeSkillType  = ACTIVE_NONE;
    public volatile long  skillCooldownEnd = 0;
    public volatile long  skillActiveUntil = 0;
    public float shieldHp         = 0;

    public boolean skillOnCooldown() { return System.currentTimeMillis() < skillCooldownEnd; }
    public boolean skillIsActive()   { return System.currentTimeMillis() < skillActiveUntil; }
    public boolean isStealthed()     { return activeSkillType == ACTIVE_STEALTH && skillIsActive(); }
    public boolean isShielded()      { return activeSkillType == ACTIVE_SHIELD  && shieldHp > 0 && skillIsActive(); }
}
