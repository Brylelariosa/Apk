#ifndef CIRCUITCORE_SIMULATION_ENGINE_H
#define CIRCUITCORE_SIMULATION_ENGINE_H

#include <unordered_map>
#include <vector>
#include <mutex>
#include "gate.h"

namespace circuitcore {

struct Pin {
    int gateId;
    int pinIndex;
};

struct Connection {
    Pin from; // source output pin
    Pin to;   // destination input pin
};

struct SimulationReport {
    bool hasOscillation = false;
    bool hasFloatingInput = false;
    bool hasShortCircuit = false;
    std::vector<int> oscillatingGateIds;
    std::vector<int> floatingInputGateIds;
    // Flattened (gateId, pinIndex) pairs identifying every input pin that
    // currently has two or more wires driving it with conflicting values.
    // Consumed in pairs: shortCircuitGatePins[2*i], shortCircuitGatePins[2*i+1].
    std::vector<int> shortCircuitGatePins;
};

// Owns the full circuit graph and runs event-driven propagation, one
// simulation tick at a time.
//
// Thread-safety: every public method takes mutex_, so it is safe to call
// step() repeatedly from a background simulation thread while the UI
// thread concurrently reads state via outputState()/snapshot-style calls
// from the JNI bridge.
class SimulationEngine {
public:
    int addGate(int id, int type, int numInputs, int numOutputs);
    void removeGate(int gateId);

    bool connect(int fromGate, int fromPin, int toGate, int toPin);
    void disconnect(int fromGate, int fromPin, int toGate, int toPin);

    void setManualState(int gateId, bool state);
    void setClockPeriod(int gateId, int halfPeriodTicks);

    bool outputState(int gateId, int pinIndex) const;
    bool inputState(int gateId, int pinIndex) const;

    // Runs up to maxIterationsPerTick propagation passes for a single
    // simulation tick, only re-evaluating gates downstream of something
    // that actually changed. Gates that never settle within the budget
    // are reported as oscillating rather than looping forever.
    SimulationReport step(int maxIterationsPerTick = 64);

    void reset();
    long long currentTick() const { return tick_; }

    std::vector<int> allGateIds() const;

private:
    void propagateFrom(int gateId, std::vector<int>& dirtyOut);
    bool hasFloatingInputs(int gateId) const;
    void rebuildOutgoingIndex();

    mutable std::mutex mutex_;
    std::unordered_map<int, Gate> gates_;
    std::vector<Connection> connections_;
    std::unordered_map<int, std::vector<int>> outgoing_; // gateId -> connection indices
    long long tick_ = 0;
};

} // namespace circuitcore

#endif // CIRCUITCORE_SIMULATION_ENGINE_H
