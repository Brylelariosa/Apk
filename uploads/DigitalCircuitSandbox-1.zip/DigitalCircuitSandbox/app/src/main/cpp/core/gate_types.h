#ifndef CIRCUITCORE_GATE_TYPES_H
#define CIRCUITCORE_GATE_TYPES_H

namespace circuitcore {

// IMPORTANT: this ordering must exactly mirror `ComponentType` in
// ComponentType.kt on the Kotlin side. The integer ordinal is passed
// across the JNI boundary directly (see jni_bridge.cpp / NativeSimulation.kt)
// — reordering one side without the other will silently corrupt simulation
// behaviour instead of producing a compile error, so treat this enum as a
// stable wire format, not an implementation detail.
// NOTE: existing entries 0-13 must never be renumbered — saved .dcs.json
// project files only store the type name, but the ordinal is what crosses
// the JNI boundary at runtime, so any reorder here would corrupt currently
// running simulations if the two sides ever drifted out of sync mid-edit.
// New types are always appended at the end.
enum class GateType : int {
    INPUT_SWITCH = 0,
    PUSH_BUTTON = 1,
    POWER = 2,
    GROUND = 3,
    CLOCK = 4,
    OUTPUT_LED = 5,
    AND = 6,
    OR = 7,
    XOR = 8,
    XNOR = 9,
    NAND = 10,
    NOR = 11,
    NOT = 12,
    BUFFER = 13,

    // --- Sequential (state-holding) components -----------------------
    // These are the only gates whose evaluate() depends on more than the
    // current inputs — they remember something across ticks. Pin 0 of
    // outputs_ is always Q, pin 1 (where present) is the complementary Q'.
    SR_LATCH = 14,      // in: S, R           out: Q, Q'
    D_LATCH = 15,       // in: D, EN          out: Q, Q'  (transparent while EN high)
    D_FLIP_FLOP = 16,   // in: D, CLK         out: Q, Q'  (captures D on CLK rising edge)
    JK_FLIP_FLOP = 17,  // in: J, CLK, K      out: Q, Q'  (edge-triggered)
    T_FLIP_FLOP = 18,   // in: T, CLK         out: Q, Q'  (toggles on rising edge when T=1)

    // --- Combinational building blocks --------------------------------
    MUX_2TO1 = 19,      // in: I0, I1, SEL             out: OUT
    MUX_4TO1 = 20,      // in: I0, I1, I2, I3, S0, S1  out: OUT
    DECODER_2TO4 = 21,  // in: A0, A1                  out: O0, O1, O2, O3 (one-hot)
    FULL_ADDER = 22,    // in: A, B, CIN               out: SUM, COUT

    // --- Display sink ---------------------------------------------------
    SEVEN_SEG_DISPLAY = 23 // in: D0, D1, D2, D3 (binary 0-15)   out: none
};

} // namespace circuitcore

#endif // CIRCUITCORE_GATE_TYPES_H
