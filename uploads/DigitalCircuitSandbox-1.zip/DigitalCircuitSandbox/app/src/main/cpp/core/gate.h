#ifndef CIRCUITCORE_GATE_H
#define CIRCUITCORE_GATE_H

#include <vector>
#include "gate_types.h"

namespace circuitcore {

// A single component instance inside the simulation graph. Gates own their
// own pin state; the owning SimulationEngine's Connection list describes
// topology (which output pin drives which input pin) separately, so a Gate
// has no knowledge of what it is wired to.
//
// Sequential gates (latches/flip-flops) additionally remember their
// previous clock/enable input across evaluate() calls so they can detect
// edges — see evaluate() for why calling it multiple times within the same
// simulation tick is safe and does not cause double-triggering.
class Gate {
public:
    Gate(int id, GateType type, int numInputs, int numOutputs);

    int id() const { return id_; }
    GateType type() const { return type_; }

    int numInputs() const { return static_cast<int>(inputs_.size()); }
    int numOutputs() const { return static_cast<int>(outputs_.size()); }

    bool inputAt(int index) const;
    void setInputAt(int index, bool value);

    bool outputAt(int index) const;

    // Driven sources (switch, push button, power) read this directly.
    void setManualState(bool state) { manualState_ = state; }
    bool manualState() const { return manualState_; }

    void setClockHalfPeriodTicks(int ticks) { clockHalfPeriodTicks_ = ticks; }

    // Recomputes every output pin from inputs_ / manual state / clock phase
    // / internal latched state. Returns true if ANY output pin's value
    // actually changed, so the engine only needs to propagate further
    // along edges that changed.
    bool evaluate(long long simulationTick);

private:
    int id_;
    GateType type_;
    std::vector<bool> inputs_;
    std::vector<bool> outputs_;
    bool manualState_ = false;
    int clockHalfPeriodTicks_ = 4;

    // Edge-detection state for latches/flip-flops. Updated every call to
    // evaluate(); a rising edge is only ever detected once per real clock
    // transition even though evaluate() may run several times in the same
    // tick while the engine settles combinational logic, because after the
    // first detection prevClockInput_ already matches the current value.
    bool prevClockInput_ = false;
};

} // namespace circuitcore

#endif // CIRCUITCORE_GATE_H
