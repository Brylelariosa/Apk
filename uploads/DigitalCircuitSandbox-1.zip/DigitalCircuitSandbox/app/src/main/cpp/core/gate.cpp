#include "gate.h"

namespace circuitcore {

namespace {
// Rising-edge helper shared by every edge-triggered sequential gate.
inline bool risingEdge(bool previous, bool current) { return !previous && current; }
}

Gate::Gate(int id, GateType type, int numInputs, int numOutputs)
    : id_(id), type_(type), inputs_(numInputs, false), outputs_(numOutputs, false) {}

bool Gate::inputAt(int index) const {
    if (index < 0 || index >= static_cast<int>(inputs_.size())) return false;
    return inputs_[index];
}

void Gate::setInputAt(int index, bool value) {
    if (index < 0 || index >= static_cast<int>(inputs_.size())) return;
    inputs_[index] = value;
}

bool Gate::outputAt(int index) const {
    if (index < 0 || index >= static_cast<int>(outputs_.size())) return false;
    return outputs_[index];
}

bool Gate::evaluate(long long simulationTick) {
    // Every gate builds a full vector of its new output values (rather than
    // just pin 0, as earlier versions of this engine did) so that
    // multi-output components — flip-flops (Q/Q'), the decoder, the full
    // adder — are evaluated correctly instead of only their first pin.
    std::vector<bool> newOutputs = outputs_;

    switch (type_) {
        // --- Sources --------------------------------------------------
        case GateType::INPUT_SWITCH:
        case GateType::PUSH_BUTTON:
        case GateType::POWER:
            if (!newOutputs.empty()) newOutputs[0] = manualState_;
            break;
        case GateType::GROUND:
            if (!newOutputs.empty()) newOutputs[0] = false;
            break;
        case GateType::CLOCK: {
            int period = clockHalfPeriodTicks_ <= 0 ? 1 : clockHalfPeriodTicks_;
            if (!newOutputs.empty()) newOutputs[0] = ((simulationTick / period) % 2) == 0;
            break;
        }

        // --- Sinks (no outputs; visible state is read via inputAt) ----
        case GateType::OUTPUT_LED:
        case GateType::SEVEN_SEG_DISPLAY:
            break;

        // --- Combinational logic gates ---------------------------------
        case GateType::AND: {
            bool result = !inputs_.empty();
            for (bool in : inputs_) result = result && in;
            if (!newOutputs.empty()) newOutputs[0] = result;
            break;
        }
        case GateType::OR: {
            bool result = false;
            for (bool in : inputs_) result = result || in;
            if (!newOutputs.empty()) newOutputs[0] = result;
            break;
        }
        case GateType::XOR: {
            int highCount = 0;
            for (bool in : inputs_) if (in) highCount++;
            if (!newOutputs.empty()) newOutputs[0] = (highCount % 2) == 1;
            break;
        }
        case GateType::XNOR: {
            int highCount = 0;
            for (bool in : inputs_) if (in) highCount++;
            if (!newOutputs.empty()) newOutputs[0] = (highCount % 2) == 0;
            break;
        }
        case GateType::NAND: {
            bool allHigh = !inputs_.empty();
            for (bool in : inputs_) allHigh = allHigh && in;
            if (!newOutputs.empty()) newOutputs[0] = !allHigh;
            break;
        }
        case GateType::NOR: {
            bool anyHigh = false;
            for (bool in : inputs_) anyHigh = anyHigh || in;
            if (!newOutputs.empty()) newOutputs[0] = !anyHigh;
            break;
        }
        case GateType::NOT:
            if (!newOutputs.empty()) newOutputs[0] = inputs_.empty() ? true : !inputs_[0];
            break;
        case GateType::BUFFER:
            if (!newOutputs.empty()) newOutputs[0] = !inputs_.empty() && inputs_[0];
            break;

        // --- Sequential (state-holding) gates ---------------------------
        // Pin 0 = Q, pin 1 = Q' for every gate in this group.
        case GateType::SR_LATCH: {
            bool s = inputAt(0), r = inputAt(1);
            bool q = outputs_.size() > 0 && outputs_[0];
            bool qn = outputs_.size() > 1 && outputs_[1];
            if (s && !r) { q = true; qn = false; }
            else if (!s && r) { q = false; qn = true; }
            else if (s && r) { q = false; qn = false; } // invalid/forbidden state
            // s==0 && r==0: hold — q/qn unchanged
            if (newOutputs.size() > 0) newOutputs[0] = q;
            if (newOutputs.size() > 1) newOutputs[1] = qn;
            break;
        }
        case GateType::D_LATCH: {
            bool d = inputAt(0), en = inputAt(1);
            bool q = outputs_.size() > 0 && outputs_[0];
            if (en) q = d; // transparent while enabled, otherwise holds
            if (newOutputs.size() > 0) newOutputs[0] = q;
            if (newOutputs.size() > 1) newOutputs[1] = !q;
            break;
        }
        case GateType::D_FLIP_FLOP: {
            bool d = inputAt(0), clk = inputAt(1);
            bool q = outputs_.size() > 0 && outputs_[0];
            if (risingEdge(prevClockInput_, clk)) q = d;
            prevClockInput_ = clk;
            if (newOutputs.size() > 0) newOutputs[0] = q;
            if (newOutputs.size() > 1) newOutputs[1] = !q;
            break;
        }
        case GateType::JK_FLIP_FLOP: {
            bool j = inputAt(0), clk = inputAt(1), k = inputAt(2);
            bool q = outputs_.size() > 0 && outputs_[0];
            if (risingEdge(prevClockInput_, clk)) {
                if (j && k) q = !q;       // toggle
                else if (j) q = true;     // set
                else if (k) q = false;    // reset
                // else hold
            }
            prevClockInput_ = clk;
            if (newOutputs.size() > 0) newOutputs[0] = q;
            if (newOutputs.size() > 1) newOutputs[1] = !q;
            break;
        }
        case GateType::T_FLIP_FLOP: {
            bool t = inputAt(0), clk = inputAt(1);
            bool q = outputs_.size() > 0 && outputs_[0];
            if (risingEdge(prevClockInput_, clk) && t) q = !q;
            prevClockInput_ = clk;
            if (newOutputs.size() > 0) newOutputs[0] = q;
            if (newOutputs.size() > 1) newOutputs[1] = !q;
            break;
        }

        // --- Combinational building blocks -------------------------------
        case GateType::MUX_2TO1: {
            bool i0 = inputAt(0), i1 = inputAt(1), sel = inputAt(2);
            if (!newOutputs.empty()) newOutputs[0] = sel ? i1 : i0;
            break;
        }
        case GateType::MUX_4TO1: {
            bool ins[4] = { inputAt(0), inputAt(1), inputAt(2), inputAt(3) };
            int sel = (inputAt(4) ? 1 : 0) | (inputAt(5) ? 2 : 0);
            if (!newOutputs.empty()) newOutputs[0] = ins[sel];
            break;
        }
        case GateType::DECODER_2TO4: {
            int idx = (inputAt(0) ? 1 : 0) | (inputAt(1) ? 2 : 0);
            for (int i = 0; i < static_cast<int>(newOutputs.size()); ++i) {
                newOutputs[i] = (i == idx);
            }
            break;
        }
        case GateType::FULL_ADDER: {
            bool a = inputAt(0), b = inputAt(1), cin = inputAt(2);
            bool sum = (a ^ b) ^ cin; // 3-input XOR (bitwise ^ on bool == logical XOR)
            bool cout = (a && b) || (b && cin) || (a && cin);
            if (newOutputs.size() > 0) newOutputs[0] = sum;
            if (newOutputs.size() > 1) newOutputs[1] = cout;
            break;
        }
    }

    bool changed = (newOutputs != outputs_);
    outputs_ = newOutputs;
    return changed;
}

} // namespace circuitcore
