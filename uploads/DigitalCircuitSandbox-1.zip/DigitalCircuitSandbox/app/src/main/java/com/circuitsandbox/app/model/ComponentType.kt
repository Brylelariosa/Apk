package com.circuitsandbox.app.model

/**
 * Every component type implemented in the simulator.
 *
 * IMPORTANT: ordinal order must exactly mirror `GateType` in
 * `cpp/core/gate_types.h` — the integer ordinal crosses the JNI boundary
 * as a raw Int, so reordering this enum without also touching the native
 * side will silently corrupt simulation behaviour. New entries always go
 * at the end of the list, never in the middle.
 *
 * [inputLabels] / [outputLabels] are optional short pin labels (e.g. "S",
 * "R", "Q", "Q'") drawn next to each pin by [com.circuitsandbox.app.render.GateRenderer].
 * An empty list means "no label for this pin" and is the right choice for
 * simple gates where the pin's meaning is obvious from the shape alone.
 */
enum class ComponentType(
    val displayName: String,
    val category: ComponentCategory,
    val inputCount: Int,
    val outputCount: Int,
    val description: String,
    val truthTable: List<Pair<List<Boolean>, List<Boolean>>>,
    val inputLabels: List<String> = emptyList(),
    val outputLabels: List<String> = emptyList()
) {
    INPUT_SWITCH(
        "Switch", ComponentCategory.BASIC, 0, 1,
        "A manual toggle. Tap it while the simulation is running to flip its output between HIGH and LOW.",
        emptyList()
    ),
    PUSH_BUTTON(
        "Push Button", ComponentCategory.BASIC, 0, 1,
        "Outputs HIGH only while pressed, and LOW otherwise.",
        emptyList()
    ),
    POWER(
        "Power", ComponentCategory.BASIC, 0, 1,
        "A constant logic HIGH (1) source.",
        listOf(emptyList<Boolean>() to listOf(true))
    ),
    GROUND(
        "Ground", ComponentCategory.BASIC, 0, 1,
        "A constant logic LOW (0) source.",
        listOf(emptyList<Boolean>() to listOf(false))
    ),
    CLOCK(
        "Clock", ComponentCategory.BASIC, 0, 1,
        "Automatically toggles its output HIGH and LOW at a steady rate once the simulation is running.",
        emptyList()
    ),
    OUTPUT_LED(
        "LED", ComponentCategory.BASIC, 1, 0,
        "Lights up while its input is HIGH.",
        listOf(listOf(false) to emptyList(), listOf(true) to emptyList())
    ),
    AND(
        "AND", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH only when every input is HIGH.",
        listOf(
            listOf(false, false) to listOf(false),
            listOf(false, true) to listOf(false),
            listOf(true, false) to listOf(false),
            listOf(true, true) to listOf(true)
        )
    ),
    OR(
        "OR", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH when at least one input is HIGH.",
        listOf(
            listOf(false, false) to listOf(false),
            listOf(false, true) to listOf(true),
            listOf(true, false) to listOf(true),
            listOf(true, true) to listOf(true)
        )
    ),
    XOR(
        "XOR", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH when an odd number of inputs are HIGH.",
        listOf(
            listOf(false, false) to listOf(false),
            listOf(false, true) to listOf(true),
            listOf(true, false) to listOf(true),
            listOf(true, true) to listOf(false)
        )
    ),
    XNOR(
        "XNOR", ComponentCategory.GATES, 2, 1,
        "Outputs HIGH when an even number of inputs are HIGH.",
        listOf(
            listOf(false, false) to listOf(true),
            listOf(false, true) to listOf(false),
            listOf(true, false) to listOf(false),
            listOf(true, true) to listOf(true)
        )
    ),
    NAND(
        "NAND", ComponentCategory.GATES, 2, 1,
        "The inverse of AND — outputs LOW only when every input is HIGH.",
        listOf(
            listOf(false, false) to listOf(true),
            listOf(false, true) to listOf(true),
            listOf(true, false) to listOf(true),
            listOf(true, true) to listOf(false)
        )
    ),
    NOR(
        "NOR", ComponentCategory.GATES, 2, 1,
        "The inverse of OR — outputs HIGH only when every input is LOW.",
        listOf(
            listOf(false, false) to listOf(true),
            listOf(false, true) to listOf(false),
            listOf(true, false) to listOf(false),
            listOf(true, true) to listOf(false)
        )
    ),
    NOT(
        "NOT", ComponentCategory.GATES, 1, 1,
        "Inverts its single input.",
        listOf(listOf(false) to listOf(true), listOf(true) to listOf(false))
    ),
    BUFFER(
        "Buffer", ComponentCategory.GATES, 1, 1,
        "Passes its input straight through, unchanged. Useful for re-amplifying a signal.",
        listOf(listOf(false) to listOf(false), listOf(true) to listOf(true))
    ),

    // -----------------------------------------------------------------
    // Sequential / memory components. Ordinals 14-18 — appended after the
    // original 14 types so existing saved projects keep decoding correctly.
    // These hold state, so unlike everything above them there is no single
    // static truth table that captures their behaviour (truthTable is left
    // empty on purpose; the inspector shows their [description] instead).
    // -----------------------------------------------------------------
    SR_LATCH(
        "SR Latch", ComponentCategory.MEMORY, 2, 2,
        "The simplest memory cell. S (Set) forces Q to 1, R (Reset) forces Q to 0. When both are LOW, Q holds its last value. Setting both HIGH at once is an invalid/forbidden state and forces both outputs LOW.",
        emptyList(),
        inputLabels = listOf("S", "R"),
        outputLabels = listOf("Q", "Q'")
    ),
    D_LATCH(
        "D Latch", ComponentCategory.MEMORY, 2, 2,
        "Level-triggered memory. While EN is HIGH the latch is transparent and Q follows D. When EN goes LOW, Q freezes at whatever D last was.",
        emptyList(),
        inputLabels = listOf("D", "EN"),
        outputLabels = listOf("Q", "Q'")
    ),
    D_FLIP_FLOP(
        "D Flip-Flop", ComponentCategory.MEMORY, 2, 2,
        "Edge-triggered memory — the building block of registers and counters. Q only updates to match D at the instant CLK rises from LOW to HIGH; it ignores D the rest of the time.",
        emptyList(),
        inputLabels = listOf("D", "CLK"),
        outputLabels = listOf("Q", "Q'")
    ),
    JK_FLIP_FLOP(
        "JK Flip-Flop", ComponentCategory.MEMORY, 3, 2,
        "The most flexible edge-triggered flip-flop. On a rising CLK edge: J=0,K=0 holds; J=1,K=0 sets Q=1; J=0,K=1 resets Q=0; J=1,K=1 toggles Q. Tying J and K together and driving both HIGH turns it into a T flip-flop.",
        emptyList(),
        inputLabels = listOf("J", "CLK", "K"),
        outputLabels = listOf("Q", "Q'")
    ),
    T_FLIP_FLOP(
        "T Flip-Flop", ComponentCategory.MEMORY, 2, 2,
        "Toggle flip-flop. Every rising CLK edge, Q flips to its opposite value whenever T is HIGH (and holds when T is LOW). Chaining these Q-to-CLK is exactly how a ripple binary counter is built.",
        emptyList(),
        inputLabels = listOf("T", "CLK"),
        outputLabels = listOf("Q", "Q'")
    ),

    // -----------------------------------------------------------------
    // Combinational building blocks — ordinals 19-22.
    // -----------------------------------------------------------------
    MUX_2TO1(
        "2:1 Multiplexer", ComponentCategory.ARITHMETIC, 3, 1,
        "Routes one of two data inputs to the output based on SEL. SEL=0 passes I0 through; SEL=1 passes I1 through.",
        listOf(
            listOf(false, false, false) to listOf(false),
            listOf(true, false, false) to listOf(true),
            listOf(false, true, false) to listOf(false),
            listOf(true, true, false) to listOf(true),
            listOf(false, false, true) to listOf(false),
            listOf(true, false, true) to listOf(false),
            listOf(false, true, true) to listOf(true),
            listOf(true, true, true) to listOf(true)
        ),
        inputLabels = listOf("I0", "I1", "SEL"),
        outputLabels = listOf("OUT")
    ),
    MUX_4TO1(
        "4:1 Multiplexer", ComponentCategory.ARITHMETIC, 6, 1,
        "Routes one of four data inputs (I0-I3) to the output, chosen by the 2-bit select S1:S0 (00=I0, 01=I1, 10=I2, 11=I3).",
        emptyList(),
        inputLabels = listOf("I0", "I1", "I2", "I3", "S0", "S1"),
        outputLabels = listOf("OUT")
    ),
    DECODER_2TO4(
        "2-to-4 Decoder", ComponentCategory.ARITHMETIC, 2, 4,
        "Turns a 2-bit binary address (A1:A0) into a one-hot signal: exactly one of the four outputs is HIGH at a time, matching the binary value of the address.",
        listOf(
            listOf(false, false) to listOf(true, false, false, false),
            listOf(true, false) to listOf(false, true, false, false),
            listOf(false, true) to listOf(false, false, true, false),
            listOf(true, true) to listOf(false, false, false, true)
        ),
        inputLabels = listOf("A0", "A1"),
        outputLabels = listOf("O0", "O1", "O2", "O3")
    ),
    FULL_ADDER(
        "Full Adder", ComponentCategory.ARITHMETIC, 3, 2,
        "Adds two bits plus a carry-in. SUM is the result bit, COUT is the carry-out — chain several together (COUT into the next CIN) to build a multi-bit adder.",
        listOf(
            listOf(false, false, false) to listOf(false, false),
            listOf(true, false, false) to listOf(true, false),
            listOf(false, true, false) to listOf(true, false),
            listOf(true, true, false) to listOf(false, true),
            listOf(false, false, true) to listOf(true, false),
            listOf(true, false, true) to listOf(false, true),
            listOf(false, true, true) to listOf(false, true),
            listOf(true, true, true) to listOf(true, true)
        ),
        inputLabels = listOf("A", "B", "CIN"),
        outputLabels = listOf("SUM", "COUT")
    ),

    // -----------------------------------------------------------------
    // Display sink — ordinal 23.
    // -----------------------------------------------------------------
    SEVEN_SEG_DISPLAY(
        "7-Segment Display", ComponentCategory.DISPLAY, 4, 0,
        "Decodes a 4-bit binary value (D3 D2 D1 D0, D0 = least significant bit) into the familiar seven-segment digit 0-9 or A-F.",
        emptyList(),
        inputLabels = listOf("D0", "D1", "D2", "D3")
    );
}

enum class ComponentCategory(val displayName: String) {
    BASIC("Basic Components"),
    GATES("Logic Gates"),
    MEMORY("Memory & Flip-Flops"),
    ARITHMETIC("Arithmetic & Routing"),
    DISPLAY("Displays")
}
