package com.circuitsandbox.app.model

import kotlin.math.floor

/**
 * In-memory representation of one circuit. Pure data with no Android or
 * rendering dependencies, so it can be unit-tested, serialized, and driven
 * by the native simulation engine independently of the UI layer.
 *
 * Maintains a uniform-grid spatial index alongside the plain id-keyed maps
 * so that hit-testing and viewport culling stay fast even on circuits with
 * thousands of components — both operations only need to look at the
 * handful of grid cells near the query point/rectangle instead of scanning
 * every component. [componentAt] still returns the *topmost* (most
 * recently added) match at a point, matching the previous linear-scan
 * behaviour, via a lightweight insertion-order counter rather than by
 * relying on iteration order of a hash-bucketed structure.
 */
class CircuitModel {
    private val components = linkedMapOf<Int, ComponentInstance>()
    private val wires = linkedMapOf<Int, WireInstance>()
    private var nextComponentIdCounter = 1
    private var nextWireIdCounter = 1
    private var nextGroupIdCounter = 1

    // --- Spatial index -----------------------------------------------------
    private val cellSize = 400f
    private val spatialIndex = HashMap<Long, MutableSet<Int>>()
    private val componentCell = HashMap<Int, Long>()
    private val insertionOrder = HashMap<Int, Long>()
    private var insertionCounter = 0L

    private fun cellKey(cx: Int, cy: Int): Long = (cx.toLong() shl 32) or (cy.toLong() and 0xFFFFFFFFL)
    private fun cellFor(x: Float, y: Float): Long = cellKey(floor(x / cellSize).toInt(), floor(y / cellSize).toInt())

    // --- Approximate content bounds (for the minimap) ----------------------
    // Deliberately monotonically-expanding rather than exact: recomputing a
    // tight bounding box every frame would be an O(n) scan per frame, which
    // is exactly the cost the spatial index above exists to avoid. A
    // minimap only needs a reasonable overview, not a pixel-exact box, so
    // it's fine if this stays slightly larger than necessary after a
    // component is deleted or dragged inward — it only ever grows, and
    // resets on [clear]. [fitToScreen]-style exact framing should keep
    // using a real scan over [allComponents], which is already what
    // CircuitCanvasView.fitToScreen does (a deliberate, infrequent action).
    private var boundsInitialized = false
    private var boundsMinX = 0f
    private var boundsMinY = 0f
    private var boundsMaxX = 0f
    private var boundsMaxY = 0f

    private fun expandBoundsFor(component: ComponentInstance) {
        val left = component.x - component.width
        val right = component.x + component.width
        val top = component.y - component.height
        val bottom = component.y + component.height
        if (!boundsInitialized) {
            boundsMinX = left; boundsMaxX = right; boundsMinY = top; boundsMaxY = bottom
            boundsInitialized = true
        } else {
            if (left < boundsMinX) boundsMinX = left
            if (right > boundsMaxX) boundsMaxX = right
            if (top < boundsMinY) boundsMinY = top
            if (bottom > boundsMaxY) boundsMaxY = bottom
        }
    }

    /** [minX, minY, maxX, maxY], or null if the circuit has never had a
     * component in it. */
    fun approximateContentBounds(): FloatArray? =
        if (!boundsInitialized) null else floatArrayOf(boundsMinX, boundsMinY, boundsMaxX, boundsMaxY)

    val allComponents: Collection<ComponentInstance> get() = components.values
    val allWires: Collection<WireInstance> get() = wires.values

    fun componentById(id: Int): ComponentInstance? = components[id]
    fun wireById(id: Int): WireInstance? = wires[id]

    fun nextComponentId(): Int = nextComponentIdCounter++
    fun nextWireId(): Int = nextWireIdCounter++
    fun nextGroupId(): Int = nextGroupIdCounter++

    fun addComponent(component: ComponentInstance) {
        components[component.id] = component
        if (component.id >= nextComponentIdCounter) nextComponentIdCounter = component.id + 1
        val cell = cellFor(component.x, component.y)
        spatialIndex.getOrPut(cell) { mutableSetOf() }.add(component.id)
        componentCell[component.id] = cell
        insertionOrder[component.id] = insertionCounter++
        expandBoundsFor(component)
    }

    fun removeComponent(id: Int) {
        components.remove(id)
        val toRemove = wires.values.filter { it.from.componentId == id || it.to.componentId == id }
        toRemove.forEach { wires.remove(it.id) }
        componentCell.remove(id)?.let { spatialIndex[it]?.remove(id) }
        insertionOrder.remove(id)
    }

    /** Call after directly mutating a component's `x`/`y` (e.g. during a
     * drag) so the spatial index stays consistent. Cheap — O(1) — unless
     * the component actually crossed into a different grid cell. */
    fun notifyComponentMoved(id: Int) {
        val component = components[id] ?: return
        expandBoundsFor(component)
        val newCell = cellFor(component.x, component.y)
        val oldCell = componentCell[id]
        if (oldCell == newCell) return
        oldCell?.let { spatialIndex[it]?.remove(id) }
        spatialIndex.getOrPut(newCell) { mutableSetOf() }.add(id)
        componentCell[id] = newCell
    }

    fun addWire(wire: WireInstance) {
        wires[wire.id] = wire
        if (wire.id >= nextWireIdCounter) nextWireIdCounter = wire.id + 1
    }

    fun removeWire(id: Int) {
        wires.remove(id)
    }

    fun wiresConnectedTo(componentId: Int): List<WireInstance> =
        wires.values.filter { it.from.componentId == componentId || it.to.componentId == componentId }

    /** Every component whose center falls in the axis-aligned rectangle,
     * in original insertion (z) order — used for box/lasso selection and
     * for viewport culling before drawing. Only scans grid cells that
     * intersect the rectangle rather than every component in the circuit. */
    fun componentsInRect(left: Float, top: Float, right: Float, bottom: Float): List<ComponentInstance> {
        val minCx = floor(left / cellSize).toInt()
        val maxCx = floor(right / cellSize).toInt()
        val minCy = floor(top / cellSize).toInt()
        val maxCy = floor(bottom / cellSize).toInt()
        val candidateIds = HashSet<Int>()
        for (cx in minCx..maxCx) {
            for (cy in minCy..maxCy) {
                spatialIndex[cellKey(cx, cy)]?.let { candidateIds.addAll(it) }
            }
        }
        return candidateIds.mapNotNull { components[it] }
            .filter { it.x in left..right && it.y in top..bottom }
            .sortedBy { insertionOrder[it.id] ?: 0L }
    }

    /** Topmost (last-added) component at a world-space point, or null.
     * Only checks the 3x3 grid-cell neighbourhood around the point — safe
     * because every component's bounding box is far smaller than one grid
     * cell, so it can never be hit-tested correctly from further away. */
    fun componentAt(worldX: Float, worldY: Float): ComponentInstance? {
        val cx = floor(worldX / cellSize).toInt()
        val cy = floor(worldY / cellSize).toInt()
        var best: ComponentInstance? = null
        var bestOrder = -1L
        for (dx in -1..1) {
            for (dy in -1..1) {
                val ids = spatialIndex[cellKey(cx + dx, cy + dy)] ?: continue
                for (id in ids) {
                    val component = components[id] ?: continue
                    if (!component.containsPoint(worldX, worldY)) continue
                    val order = insertionOrder[id] ?: 0L
                    if (order > bestOrder) { bestOrder = order; best = component }
                }
            }
        }
        return best
    }

    fun clear() {
        components.clear()
        wires.clear()
        spatialIndex.clear()
        componentCell.clear()
        insertionOrder.clear()
        insertionCounter = 0L
        nextComponentIdCounter = 1
        nextWireIdCounter = 1
        nextGroupIdCounter = 1
        boundsInitialized = false
        boundsMinX = 0f; boundsMinY = 0f; boundsMaxX = 0f; boundsMaxY = 0f
    }
}
