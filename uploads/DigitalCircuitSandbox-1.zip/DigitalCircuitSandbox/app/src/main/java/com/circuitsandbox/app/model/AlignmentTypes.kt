package com.circuitsandbox.app.model

/** Which edge/axis a multi-component alignment operation lines everything
 * up on. Operates on each component's `x`/`y` (its center), which is
 * consistent with how components are positioned everywhere else in the
 * model rather than introducing a separate "bounding box edge" concept. */
enum class AlignmentType { LEFT, RIGHT, TOP, BOTTOM, CENTER_HORIZONTAL, CENTER_VERTICAL }

/** Which axis a "distribute evenly" operation spaces components along. */
enum class DistributeAxis { HORIZONTAL, VERTICAL }
