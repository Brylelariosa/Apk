package com.circuitsandbox.app.simulation

import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Every input- and output-pin's live logic level for the whole circuit,
 * refreshed once per simulation tick from two batched native reads (one
 * for all input pins, one for all output pins) rather than a JNI call per
 * gate. Kept as plain arrays-per-component rather than one flat map so a
 * multi-pin component (a flip-flop's Q *and* Q', a decoder's four
 * outputs, a 7-segment display's four inputs) is represented correctly
 * instead of collapsing to a single bit.
 */
class CircuitPinStates(
    private val inputs: Map<Int, BooleanArray>,
    private val outputs: Map<Int, BooleanArray>
) {
    fun inputAt(componentId: Int, pin: Int): Boolean = inputs[componentId]?.getOrNull(pin) ?: false
    fun outputAt(componentId: Int, pin: Int): Boolean = outputs[componentId]?.getOrNull(pin) ?: false

    /** The single bit that best represents a component's "active" state for
     * shapes that only ever show one glow/fill color (LED, switch fill,
     * clock wave) — its first output pin if it has one, otherwise its
     * first input pin (sink-only components like the LED and 7-segment
     * display have no output pins at all). */
    fun primaryState(component: ComponentInstance): Boolean =
        if (component.type.outputCount > 0) outputAt(component.id, 0) else inputAt(component.id, 0)

    companion object {
        val EMPTY = CircuitPinStates(emptyMap(), emptyMap())
    }
}

/**
 * Owns the native simulation instance for one [CircuitModel] and drives the
 * real-time loop on a background coroutine, so gate evaluation never blocks
 * the UI thread even on a large circuit.
 */
class SimulationController(private val circuit: CircuitModel) {

    private val native = NativeSimulation()
    private var loopJob: Job? = null

    var isRunning: Boolean = false
        private set

    var ticksPerSecond: Int = 30
        set(value) {
            field = value.coerceIn(1, 240)
        }

    var onStateChanged: ((NativeSimulation.StepReport) -> Unit)? = null

    /** Call after any topology change (component or wire added/removed)
     * while the simulation is stopped. Rebuilds the native graph from
     * scratch from the current [CircuitModel]. */
    fun rebuild() {
        native.reset()
        for (component in circuit.allComponents) {
            native.addGate(
                component.id,
                component.type.ordinal,
                component.type.inputCount,
                component.type.outputCount
            )
        }
        for (wire in circuit.allWires) {
            native.connect(wire.from.componentId, wire.from.pinIndex, wire.to.componentId, wire.to.pinIndex)
        }
    }

    fun setSwitchState(componentId: Int, state: Boolean) {
        native.setManualState(componentId, state)
    }

    /** Single-pin read used only where a batched [snapshotPinStates] snapshot
     * would be overkill — e.g. reading a switch's current state right before
     * flipping it in response to a tap. */
    fun outputState(component: ComponentInstance, pinIndex: Int = 0): Boolean =
        native.outputState(component.id, pinIndex)

    /** One or two JNI calls for the whole circuit's current visible state —
     * used by the renderer every frame rather than querying gate-by-gate. */
    fun snapshotPinStates(): CircuitPinStates {
        val withOutputs = circuit.allComponents.filter { it.type.outputCount > 0 }
        val withInputs = circuit.allComponents.filter { it.type.inputCount > 0 }

        val outputs = HashMap<Int, BooleanArray>(withOutputs.size)
        if (withOutputs.isNotEmpty()) {
            val ids = ArrayList<Int>()
            val pins = ArrayList<Int>()
            for (c in withOutputs) for (p in 0 until c.type.outputCount) { ids.add(c.id); pins.add(p) }
            val values = native.outputsFor(ids.toIntArray(), pins.toIntArray())
            var i = 0
            for (c in withOutputs) {
                val arr = BooleanArray(c.type.outputCount)
                for (p in 0 until c.type.outputCount) arr[p] = values[i++]
                outputs[c.id] = arr
            }
        }

        val inputs = HashMap<Int, BooleanArray>(withInputs.size)
        if (withInputs.isNotEmpty()) {
            val ids = ArrayList<Int>()
            val pins = ArrayList<Int>()
            for (c in withInputs) for (p in 0 until c.type.inputCount) { ids.add(c.id); pins.add(p) }
            val values = native.inputsFor(ids.toIntArray(), pins.toIntArray())
            var i = 0
            for (c in withInputs) {
                val arr = BooleanArray(c.type.inputCount)
                for (p in 0 until c.type.inputCount) arr[p] = values[i++]
                inputs[c.id] = arr
            }
        }

        return CircuitPinStates(inputs, outputs)
    }

    fun singleStep(): NativeSimulation.StepReport {
        val report = native.step()
        onStateChanged?.invoke(report)
        return report
    }

    fun start(scope: CoroutineScope) {
        if (isRunning) return
        isRunning = true
        loopJob = scope.launch(Dispatchers.Default) {
            while (isActive && isRunning) {
                val report = native.step()
                withContext(Dispatchers.Main) { onStateChanged?.invoke(report) }
                delay((1000L / ticksPerSecond).coerceAtLeast(1L))
            }
        }
    }

    fun pause() {
        isRunning = false
        loopJob?.cancel()
        loopJob = null
    }

    fun release() {
        pause()
        native.release()
    }
}
