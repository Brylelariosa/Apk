package com.circuitsandbox.app.undo

import com.circuitsandbox.app.model.AlignmentType
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.DistributeAxis
import com.circuitsandbox.app.model.WireInstance

class AddComponentCommand(
    private val circuit: CircuitModel,
    private val component: ComponentInstance
) : Command {
    override fun execute() = circuit.addComponent(component)
    override fun undo() = circuit.removeComponent(component.id)
}

class RemoveComponentCommand(
    private val circuit: CircuitModel,
    private val component: ComponentInstance
) : Command {
    // Captured at construction time, before execute() removes anything,
    // so undo() can restore exactly what was connected. CircuitModel's
    // map-based storage makes addWire/addComponent idempotent by id, so
    // it's safe for the same wire to be captured by more than one
    // RemoveComponentCommand in the same bulk delete (see CompositeCommand).
    private val removedWires = circuit.wiresConnectedTo(component.id)

    override fun execute() = circuit.removeComponent(component.id)
    override fun undo() {
        circuit.addComponent(component)
        removedWires.forEach { circuit.addWire(it) }
    }
}

class MoveComponentCommand(
    private val circuit: CircuitModel,
    private val componentId: Int,
    private val fromX: Float,
    private val fromY: Float,
    private val toX: Float,
    private val toY: Float
) : Command {
    override fun execute() {
        circuit.componentById(componentId)?.let {
            it.x = toX; it.y = toY
            circuit.notifyComponentMoved(componentId)
        }
    }
    override fun undo() {
        circuit.componentById(componentId)?.let {
            it.x = fromX; it.y = fromY
            circuit.notifyComponentMoved(componentId)
        }
    }
}

class AddWireCommand(
    private val circuit: CircuitModel,
    private val wire: WireInstance
) : Command {
    override fun execute() = circuit.addWire(wire)
    override fun undo() = circuit.removeWire(wire.id)
}

class RemoveWireCommand(
    private val circuit: CircuitModel,
    private val wire: WireInstance
) : Command {
    override fun execute() = circuit.removeWire(wire.id)
    override fun undo() = circuit.addWire(wire)
}

/** Rotates every component in [componentIds] by 90°. Stores each one's
 * prior rotation individually so undo restores exact original angles
 * even if components started at different rotations. */
class RotateComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>
) : Command {
    private val previousRotations: Map<Int, Int> =
        componentIds.associateWith { circuit.componentById(it)?.rotationDegrees ?: 0 }

    override fun execute() {
        componentIds.forEach { id ->
            circuit.componentById(id)?.let { it.rotationDegrees = (it.rotationDegrees + 90) % 360 }
        }
    }

    override fun undo() {
        componentIds.forEach { id ->
            circuit.componentById(id)?.rotationDegrees = previousRotations[id] ?: 0
        }
    }
}

/** Mirrors every component in [componentIds]. Mirroring is its own
 * inverse, so undo can just re-run execute(). */
class MirrorComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>
) : Command {
    override fun execute() {
        componentIds.forEach { id -> circuit.componentById(id)?.let { it.mirrored = !it.mirrored } }
    }
    override fun undo() = execute()
}

/** Bundles any number of commands into a single undo/redo step. Used for
 * paste, duplicate, and every bulk-delete action, so one tap on "undo"
 * always reverses the whole user-visible action rather than one
 * sub-step of it. */
class CompositeCommand(private val commands: List<Command>) : Command {
    override fun execute() {
        commands.forEach { it.execute() }
    }
    override fun undo() {
        commands.asReversed().forEach { it.undo() }
    }
}

/** Toggles [ComponentInstance.locked] to [locked] for every id in
 * [componentIds]. Undo restores each component's own *previous* locked
 * state individually, so a mixed selection (some already locked) still
 * round-trips correctly rather than just flipping everything back. */
class LockComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>,
    private val locked: Boolean
) : Command {
    private val previousStates: Map<Int, Boolean> =
        componentIds.associateWith { circuit.componentById(it)?.locked ?: false }

    override fun execute() {
        componentIds.forEach { id -> circuit.componentById(id)?.locked = locked }
    }
    override fun undo() {
        componentIds.forEach { id -> circuit.componentById(id)?.locked = previousStates[id] ?: false }
    }
}

/** Assigns one brand-new shared groupId to every component in
 * [componentIds] so they move/rotate/mirror together from now on. */
class GroupComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>
) : Command {
    private val newGroupId = circuit.nextGroupId()
    private val previousGroupIds: Map<Int, Int?> =
        componentIds.associateWith { circuit.componentById(it)?.groupId }

    override fun execute() {
        componentIds.forEach { id -> circuit.componentById(id)?.groupId = newGroupId }
    }
    override fun undo() {
        componentIds.forEach { id -> circuit.componentById(id)?.groupId = previousGroupIds[id] }
    }
}

/** Clears groupId on every component in [componentIds] — and, since a
 * group is a shared, symmetric relationship, on every *other* component
 * that shared a group with any of them too, not just the ones tapped. */
class UngroupComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>
) : Command {
    private val affectedGroupIds = componentIds.mapNotNull { circuit.componentById(it)?.groupId }.toSet()
    private val allAffectedIds = circuit.allComponents.filter { it.groupId in affectedGroupIds }.map { it.id }
    private val previousGroupIds: Map<Int, Int?> =
        allAffectedIds.associateWith { circuit.componentById(it)?.groupId }

    override fun execute() {
        allAffectedIds.forEach { id -> circuit.componentById(id)?.groupId = null }
    }
    override fun undo() {
        allAffectedIds.forEach { id -> circuit.componentById(id)?.groupId = previousGroupIds[id] }
    }
}

/** Lines every component in [componentIds] up along one shared edge or
 * center line. See [AlignmentType] for exactly which reference point each
 * mode aligns to. */
class AlignComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>,
    private val alignment: AlignmentType
) : Command {
    private val previousPositions: Map<Int, Pair<Float, Float>> =
        componentIds.mapNotNull { id -> circuit.componentById(id)?.let { id to (it.x to it.y) } }.toMap()

    override fun execute() {
        val components = componentIds.mapNotNull { circuit.componentById(it) }
        if (components.isEmpty()) return
        when (alignment) {
            AlignmentType.LEFT -> {
                val edge = components.minOf { it.x - it.width / 2f }
                components.forEach { it.x = edge + it.width / 2f }
            }
            AlignmentType.RIGHT -> {
                val edge = components.maxOf { it.x + it.width / 2f }
                components.forEach { it.x = edge - it.width / 2f }
            }
            AlignmentType.TOP -> {
                val edge = components.minOf { it.y - it.height / 2f }
                components.forEach { it.y = edge + it.height / 2f }
            }
            AlignmentType.BOTTOM -> {
                val edge = components.maxOf { it.y + it.height / 2f }
                components.forEach { it.y = edge - it.height / 2f }
            }
            AlignmentType.CENTER_HORIZONTAL -> {
                val target = components.map { it.x }.average().toFloat()
                components.forEach { it.x = target }
            }
            AlignmentType.CENTER_VERTICAL -> {
                val target = components.map { it.y }.average().toFloat()
                components.forEach { it.y = target }
            }
        }
        components.forEach { circuit.notifyComponentMoved(it.id) }
    }

    override fun undo() {
        previousPositions.forEach { (id, pos) ->
            circuit.componentById(id)?.let { it.x = pos.first; it.y = pos.second }
            circuit.notifyComponentMoved(id)
        }
    }
}

/** Spaces every component in [componentIds] evenly along one axis,
 * keeping the two extreme (min and max) components fixed and
 * redistributing everything between them at equal center-to-center
 * intervals. No-ops on fewer than 3 components — there's nothing "between
 * the ends" to redistribute with only one or two. */
class DistributeComponentsCommand(
    private val circuit: CircuitModel,
    private val componentIds: Set<Int>,
    private val axis: DistributeAxis
) : Command {
    private val previousPositions: Map<Int, Pair<Float, Float>> =
        componentIds.mapNotNull { id -> circuit.componentById(id)?.let { id to (it.x to it.y) } }.toMap()

    override fun execute() {
        val components = componentIds.mapNotNull { circuit.componentById(it) }
        if (components.size < 3) return
        when (axis) {
            DistributeAxis.HORIZONTAL -> {
                val sorted = components.sortedBy { it.x }
                val first = sorted.first().x
                val last = sorted.last().x
                val step = (last - first) / (sorted.size - 1)
                sorted.forEachIndexed { i, c -> c.x = first + step * i }
            }
            DistributeAxis.VERTICAL -> {
                val sorted = components.sortedBy { it.y }
                val first = sorted.first().y
                val last = sorted.last().y
                val step = (last - first) / (sorted.size - 1)
                sorted.forEachIndexed { i, c -> c.y = first + step * i }
            }
        }
        components.forEach { circuit.notifyComponentMoved(it.id) }
    }

    override fun undo() {
        previousPositions.forEach { (id, pos) ->
            circuit.componentById(id)?.let { it.x = pos.first; it.y = pos.second }
            circuit.notifyComponentMoved(id)
        }
    }
}
