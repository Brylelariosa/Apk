package com.circuitsandbox.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.circuitsandbox.app.R
import com.circuitsandbox.app.databinding.ActivityMainBinding
import com.circuitsandbox.app.model.AlignmentType
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentCategory
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.DistributeAxis
import com.circuitsandbox.app.model.WireInstance
import com.circuitsandbox.app.persistence.ProjectRepository
import com.circuitsandbox.app.render.CircuitTheme
import com.circuitsandbox.app.simulation.NativeSimulation
import com.circuitsandbox.app.simulation.SimulationController
import com.circuitsandbox.app.undo.AddComponentCommand
import com.circuitsandbox.app.undo.AddWireCommand
import com.circuitsandbox.app.undo.AlignComponentsCommand
import com.circuitsandbox.app.undo.Command
import com.circuitsandbox.app.undo.CommandHistory
import com.circuitsandbox.app.undo.CompositeCommand
import com.circuitsandbox.app.undo.DistributeComponentsCommand
import com.circuitsandbox.app.undo.GroupComponentsCommand
import com.circuitsandbox.app.undo.LockComponentsCommand
import com.circuitsandbox.app.undo.MirrorComponentsCommand
import com.circuitsandbox.app.undo.MoveComponentCommand
import com.circuitsandbox.app.undo.RemoveComponentCommand
import com.circuitsandbox.app.undo.RemoveWireCommand
import com.circuitsandbox.app.undo.RotateComponentsCommand
import com.circuitsandbox.app.undo.UngroupComponentsCommand
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

/**
 * Hosts the canvas, toolbar, contextual action bar, component search/
 * palette, and play/pause/step/speed controls.
 *
 * Every circuit mutation the user should be able to undo flows through
 * [history] — including mutations that originate from [CircuitCanvasView]
 * via the [CircuitInteractionListener] callbacks below. Single-item
 * actions become one [Command]; bulk actions (paste, duplicate, multi-
 * delete, align, distribute) become one [CompositeCommand] or a single
 * bulk-aware command, so one tap on "undo" always reverses one whole
 * user-visible action.
 *
 * The native simulation graph is only rebuilt when [simulationDirty] is
 * set — i.e. when circuit topology actually changed — rather than on
 * every Play tap, so pausing and resuming preserves every flip-flop,
 * latch, and counter's state instead of silently resetting the circuit.
 */
class MainActivity : AppCompatActivity(), CircuitInteractionListener {

    private lateinit var binding: ActivityMainBinding
    private val circuit = CircuitModel()
    private lateinit var simulation: SimulationController
    private val history = CommandHistory()
    private lateinit var projectRepository: ProjectRepository
    private var themeIndex = 0
    private var simulationDirty = true
    private var currentProjectName = "circuit"
    private var lastWarningMessage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectRepository = ProjectRepository(filesDir)

        simulation = SimulationController(circuit)
        simulation.onStateChanged = { report -> onSimulationTick(report) }

        binding.canvasView.circuit = circuit
        binding.canvasView.theme = CircuitTheme.DARK
        binding.canvasView.listener = this

        setSupportActionBar(binding.toolbar)

        buildPalette()
        setupSearchBox()
        setupContextualBar()
        setupSimulationControls()

        binding.btnUndo.setOnClickListener {
            simulationDirty = true
            history.undo()
            refreshAll()
        }
        binding.btnRedo.setOnClickListener {
            simulationDirty = true
            history.redo()
            refreshAll()
        }

        binding.canvasView.post { binding.canvasView.centerOn(0f, 0f) }
        checkForAutosaveRestore()
    }

    private fun onSimulationTick(report: NativeSimulation.StepReport) {
        binding.canvasView.pinStates = simulation.snapshotPinStates()
        binding.canvasView.floatingComponentIds = report.floatingInputGateIds.toSet()
        binding.canvasView.oscillatingComponentIds = report.oscillatingGateIds.toSet()
        binding.canvasView.shortCircuitWireIds = shortCircuitWireIds(report.shortCircuitGatePins)
        binding.canvasView.advanceAnimation()
        updateWarningBanner(report)
    }

    private fun shortCircuitWireIds(pins: List<Pair<Int, Int>>): Set<Int> {
        if (pins.isEmpty()) return emptySet()
        val pinSet = pins.toHashSet()
        return circuit.allWires
            .filter { (it.to.componentId to it.to.pinIndex) in pinSet }
            .map { it.id }
            .toSet()
    }

    private fun updateWarningBanner(report: NativeSimulation.StepReport) {
        val message = when {
            report.hasShortCircuit -> getString(R.string.warning_short_circuit)
            report.hasOscillation -> getString(R.string.warning_oscillation)
            report.hasFloatingInput -> getString(R.string.warning_floating_input)
            else -> null
        }
        if (message == lastWarningMessage) return
        lastWarningMessage = message
        if (message == null) {
            binding.simulationWarningBanner.visibility = View.GONE
        } else {
            binding.simulationWarningBanner.text = message
            binding.simulationWarningBanner.visibility = View.VISIBLE
        }
    }

    // --- Menu ---------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        menu.findItem(R.id.action_snap_grid)?.isChecked = binding.canvasView.snapToGridEnabled
        menu.findItem(R.id.action_lasso_mode)?.isChecked = binding.canvasView.selectionMode == SelectionMode.LASSO
        menu.findItem(R.id.action_minimap_toggle)?.isChecked = binding.canvasView.minimapEnabled
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_paste)?.isEnabled = binding.canvasView.hasClipboard()
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_examples -> { showExamples(); true }
            R.id.action_theme -> { cycleTheme(); true }
            R.id.action_save -> { showSaveDialog(); true }
            R.id.action_load -> { showLoadDialog(); true }
            R.id.action_fit_screen -> { binding.canvasView.fitToScreen(); true }
            R.id.action_reset_simulation -> {
                confirmAndRun(R.string.confirm_reset_simulation) { resetSimulation() }
                true
            }
            R.id.action_snap_grid -> {
                item.isChecked = !item.isChecked
                binding.canvasView.snapToGridEnabled = item.isChecked
                true
            }
            R.id.action_lasso_mode -> {
                item.isChecked = !item.isChecked
                binding.canvasView.selectionMode = if (item.isChecked) SelectionMode.LASSO else SelectionMode.BOX
                true
            }
            R.id.action_minimap_toggle -> {
                item.isChecked = !item.isChecked
                binding.canvasView.minimapEnabled = item.isChecked
                binding.canvasView.invalidate()
                true
            }
            R.id.action_paste -> {
                if (binding.canvasView.hasClipboard()) {
                    binding.canvasView.pasteClipboard()
                } else {
                    Toast.makeText(this, R.string.clipboard_empty_toast, Toast.LENGTH_SHORT).show()
                }
                true
            }
            R.id.action_delete_wires -> {
                confirmAndRun(R.string.confirm_delete_wires) { binding.canvasView.deleteAllWires() }
                true
            }
            R.id.action_delete_components -> {
                confirmAndRun(R.string.confirm_delete_components) { binding.canvasView.deleteAllComponents() }
                true
            }
            R.id.action_delete_disconnected -> {
                binding.canvasView.deleteDisconnectedWires()
                true
            }
            R.id.action_clear_canvas -> {
                confirmAndRun(R.string.confirm_clear_canvas) { binding.canvasView.clearCanvas() }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun confirmAndRun(messageRes: Int, action: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setMessage(messageRes)
            .setPositiveButton(R.string.confirm) { _, _ -> action() }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // --- Setup ----------------------------------------------------------

    private fun setupContextualBar() {
        binding.btnCopy.setOnClickListener {
            binding.canvasView.copySelection()
            invalidateOptionsMenu()
            Toast.makeText(this, R.string.copied_toast, Toast.LENGTH_SHORT).show()
        }
        binding.btnDuplicate.setOnClickListener {
            binding.canvasView.duplicateSelection()
            invalidateOptionsMenu()
        }
        binding.btnRotate.setOnClickListener { binding.canvasView.rotateSelection() }
        binding.btnMirror.setOnClickListener { binding.canvasView.mirrorSelection() }
        binding.btnLock.setOnClickListener {
            binding.canvasView.lockSelection(!binding.canvasView.isSelectionFullyLocked())
        }
        binding.btnGroup.setOnClickListener {
            if (binding.canvasView.isSelectionFullyGrouped()) {
                binding.canvasView.ungroupSelection()
            } else {
                binding.canvasView.groupSelection()
            }
        }
        binding.btnAlign.setOnClickListener { showAlignMenu(it) }
        binding.btnDeleteSelected.setOnClickListener { binding.canvasView.deleteSelection() }
    }

    private fun showAlignMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(0, 1, 0, R.string.align_left)
        popup.menu.add(0, 2, 0, R.string.align_right)
        popup.menu.add(0, 3, 0, R.string.align_top)
        popup.menu.add(0, 4, 0, R.string.align_bottom)
        popup.menu.add(0, 5, 0, R.string.align_center_h)
        popup.menu.add(0, 6, 0, R.string.align_center_v)
        popup.menu.add(0, 7, 0, R.string.distribute_horizontal)
        popup.menu.add(0, 8, 0, R.string.distribute_vertical)
        popup.setOnMenuItemClickListener { item ->
            if (item.itemId in 1..6 && binding.canvasView.selectedComponentCount() < 2) {
                Toast.makeText(this, R.string.align_needs_two_toast, Toast.LENGTH_SHORT).show()
                return@setOnMenuItemClickListener true
            }
            if (item.itemId in 7..8 && binding.canvasView.selectedComponentCount() < 3) {
                Toast.makeText(this, R.string.distribute_needs_three_toast, Toast.LENGTH_SHORT).show()
                return@setOnMenuItemClickListener true
            }
            when (item.itemId) {
                1 -> binding.canvasView.alignSelection(AlignmentType.LEFT)
                2 -> binding.canvasView.alignSelection(AlignmentType.RIGHT)
                3 -> binding.canvasView.alignSelection(AlignmentType.TOP)
                4 -> binding.canvasView.alignSelection(AlignmentType.BOTTOM)
                5 -> binding.canvasView.alignSelection(AlignmentType.CENTER_HORIZONTAL)
                6 -> binding.canvasView.alignSelection(AlignmentType.CENTER_VERTICAL)
                7 -> binding.canvasView.distributeSelection(DistributeAxis.HORIZONTAL)
                8 -> binding.canvasView.distributeSelection(DistributeAxis.VERTICAL)
            }
            true
        }
        popup.show()
    }

    private fun setupSimulationControls() {
        binding.fabPlayPause.setOnClickListener { toggleSimulation() }
        binding.btnStep.setOnClickListener { stepSimulation() }
        binding.btnSpeed.setOnClickListener { showSpeedDialog() }
    }

    private fun showSpeedDialog() {
        val speeds = listOf(2, 5, 10, 20, 30, 60, 120, 240)
        val labels = speeds.map { "$it ticks/sec" }.toTypedArray()
        val currentIndex = speeds.indexOf(simulation.ticksPerSecond).let { if (it < 0) 4 else it }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.simulation_speed)
            .setSingleChoiceItems(labels, currentIndex) { dialog, which ->
                simulation.ticksPerSecond = speeds[which]
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // Ordered list of last-used types shown at the head of the palette.
    private val recentlyUsed = LinkedHashSet<ComponentType>()

    private fun setupSearchBox() {
        binding.searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                buildPalette(s?.toString().orEmpty())
            }
        })
    }

    private fun buildPalette(filter: String = "") {
        val container = binding.paletteContainer
        container.removeAllViews()
        val query = filter.trim().lowercase()
        val dp = resources.displayMetrics.density

        fun addChip(type: ComponentType) {
            val chip = com.google.android.material.chip.Chip(this)
            chip.text = type.displayName
            chip.isCheckable = false
            chip.setOnClickListener {
                // Track recently used (max 6, most-recent first)
                recentlyUsed.remove(type)
                recentlyUsed.add(type)
                if (recentlyUsed.size > 6) recentlyUsed.remove(recentlyUsed.first())
                binding.canvasView.pendingPlacementType = type
            }
            container.addView(chip)
        }

        fun addHeader(text: String) {
            val tv = TextView(this)
            tv.text = text
            tv.textSize = 10f
            tv.setPadding((8 * dp).toInt(), 0, (4 * dp).toInt(), 0)
            tv.gravity = Gravity.CENTER_VERTICAL
            tv.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            container.addView(tv)
        }

        if (query.isEmpty()) {
            // Show "recent" section only when not searching
            if (recentlyUsed.isNotEmpty()) {
                addHeader("RECENT")
                for (type in recentlyUsed.reversed()) addChip(type)
                addHeader("|")
            }
            for (category in ComponentCategory.entries) {
                val types = ComponentType.entries.filter { it.category == category }
                if (types.isEmpty()) continue
                addHeader(category.displayName.uppercase())
                types.forEach { addChip(it) }
            }
        } else {
            ComponentType.entries
                .filter { it.displayName.lowercase().contains(query) }
                .forEach { addChip(it) }
        }
    }

    // --- Simulation lifecycle --------------------------------------------
    // The native graph is only rebuilt when simulationDirty is set (by a
    // topology-changing edit, undo/redo, or loading a new circuit) —
    // never merely by pressing Play — so pausing and resuming preserves
    // every flip-flop/latch/counter's current state.

    private fun ensureSimulationBuilt() {
        if (simulationDirty) {
            simulation.rebuild()
            simulationDirty = false
        }
    }

    private fun toggleSimulation() {
        if (simulation.isRunning) {
            simulation.pause()
            binding.canvasView.simulationRunning = false
            binding.fabPlayPause.setImageResource(R.drawable.ic_play)
        } else {
            ensureSimulationBuilt()
            simulation.start(lifecycleScope)
            binding.canvasView.simulationRunning = true
            binding.fabPlayPause.setImageResource(R.drawable.ic_pause)
        }
    }

    private fun stepSimulation() {
        ensureSimulationBuilt()
        binding.canvasView.simulationRunning = true
        simulation.singleStep()
    }

    private fun resetSimulation() {
        if (simulation.isRunning) {
            simulation.pause()
            binding.fabPlayPause.setImageResource(R.drawable.ic_play)
        }
        simulation.rebuild()
        simulationDirty = false
        lastWarningMessage = null
        binding.simulationWarningBanner.visibility = View.GONE
        binding.canvasView.floatingComponentIds = emptySet()
        binding.canvasView.oscillatingComponentIds = emptySet()
        binding.canvasView.shortCircuitWireIds = emptySet()
        binding.canvasView.pinStates = simulation.snapshotPinStates()
        binding.canvasView.invalidate()
    }

    private fun refreshAll() {
        binding.canvasView.invalidate()
    }

    private fun cycleTheme() {
        themeIndex = (themeIndex + 1) % CircuitTheme.ALL.size
        binding.canvasView.theme = CircuitTheme.ALL[themeIndex]
        binding.canvasView.invalidate()
    }

    // --- Save / load ------------------------------------------------------

    private fun showSaveDialog() {
        val dp = resources.displayMetrics.density
        val input = EditText(this)
        input.setText(currentProjectName)
        input.setSelection(input.text.length)
        input.hint = getString(R.string.project_name_hint)
        val pad = (20 * dp).toInt()
        input.setPadding(pad, pad, pad, pad)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.save_project_title)
            .setView(input)
            .setPositiveButton(R.string.confirm) { _, _ ->
                val name = input.text.toString().trim().ifBlank { "circuit" }
                currentProjectName = name
                projectRepository.save(name, circuit)
                Toast.makeText(this, R.string.saved_toast, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun userVisibleProjects(): List<File> {
        val autosave = projectRepository.autoSavePath()
        return projectRepository.listProjects().filter { it != autosave }
    }

    private fun selectableBackground(borderless: Boolean = false): Int {
        val outValue = TypedValue()
        val attr = if (borderless) android.R.attr.selectableItemBackgroundBorderless else android.R.attr.selectableItemBackground
        theme.resolveAttribute(attr, outValue, true)
        return outValue.resourceId
    }

    private fun showLoadDialog() {
        if (userVisibleProjects().isEmpty()) {
            Toast.makeText(this, R.string.no_saved_projects_message, Toast.LENGTH_SHORT).show()
            return
        }
        val dp = resources.displayMetrics.density
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val scroll = ScrollView(this)
        scroll.addView(list)

        var dialog: AlertDialog? = null

        fun buildRows() {
            list.removeAllViews()
            val projects = userVisibleProjects()
            if (projects.isEmpty()) {
                dialog?.dismiss()
                return
            }
            for (file in projects) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding((16 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt())
                row.isClickable = true
                row.setBackgroundResource(selectableBackground())

                val label = TextView(this)
                val timestamp = android.text.format.DateFormat.format("MMM d, h:mm a", file.lastModified())
                label.text = "${file.name.removeSuffix(".dcs.json")}\n$timestamp"
                label.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

                val deleteBtn = ImageButton(this)
                deleteBtn.setImageResource(R.drawable.ic_delete)
                deleteBtn.setBackgroundResource(selectableBackground(borderless = true))
                deleteBtn.contentDescription = getString(R.string.delete)
                deleteBtn.layoutParams = LinearLayout.LayoutParams((40 * dp).toInt(), (40 * dp).toInt())
                deleteBtn.setOnClickListener {
                    MaterialAlertDialogBuilder(this)
                        .setMessage(R.string.delete_project_confirm)
                        .setPositiveButton(R.string.delete) { _, _ ->
                            projectRepository.delete(file)
                            Toast.makeText(this, R.string.project_deleted_toast, Toast.LENGTH_SHORT).show()
                            buildRows()
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                }

                row.setOnClickListener {
                    dialog?.dismiss()
                    loadProjectFile(file)
                }

                row.addView(label)
                row.addView(deleteBtn)
                list.addView(row)
            }
        }

        dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.load_project_title)
            .setView(scroll)
            .setNegativeButton(R.string.cancel, null)
            .create()
        buildRows()
        dialog.show()
    }

    private fun loadProjectFile(file: File) {
        val loaded = projectRepository.load(file)
        if (simulation.isRunning) {
            simulation.pause()
            binding.canvasView.simulationRunning = false
            binding.fabPlayPause.setImageResource(R.drawable.ic_play)
        }
        circuit.clear()
        loaded.allComponents.forEach { circuit.addComponent(it) }
        loaded.allWires.forEach { circuit.addWire(it) }
        history.clear()
        simulationDirty = true
        binding.canvasView.fitToScreen()
        refreshAll()
        Toast.makeText(this, R.string.loaded_toast, Toast.LENGTH_SHORT).show()
    }

    private fun checkForAutosaveRestore() {
        val autosaveFile = projectRepository.autoSavePath()
        if (!autosaveFile.exists()) return
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.restore_autosave_title)
            .setMessage(R.string.restore_autosave_message)
            .setCancelable(false)
            .setPositiveButton(R.string.restore) { _, _ ->
                loadProjectFile(autosaveFile)
                currentProjectName = "circuit"
            }
            .setNegativeButton(R.string.discard) { _, _ -> projectRepository.delete(autosaveFile) }
            .show()
    }

    override fun onPause() {
        super.onPause()
        if (simulation.isRunning) {
            simulation.pause()
            binding.canvasView.simulationRunning = false
            binding.fabPlayPause.setImageResource(R.drawable.ic_play)
        }
        if (circuit.allComponents.isNotEmpty() || circuit.allWires.isNotEmpty()) {
            projectRepository.save("_autosave", circuit)
        }
    }

    // --- CircuitInteractionListener --------------------------------------

    override fun onSelectionChanged(componentIds: Set<Int>, wireIds: Set<Int>) {
        val hasSelection = componentIds.isNotEmpty() || wireIds.isNotEmpty()
        binding.contextualBarScroll.visibility = if (hasSelection) View.VISIBLE else View.GONE
        if (componentIds.size == 1 && wireIds.isEmpty()) {
            circuit.componentById(componentIds.first())?.let { showInspector(it) }
        }
    }

    override fun onComponentMoved(componentId: Int, fromX: Float, fromY: Float, toX: Float, toY: Float) {
        history.execute(MoveComponentCommand(circuit, componentId, fromX, fromY, toX, toY))
    }

    override fun onComponentAdded(component: ComponentInstance) {
        simulationDirty = true
        history.execute(AddComponentCommand(circuit, component))
        refreshAll()
    }

    override fun onComponentRemoved(component: ComponentInstance) {
        simulationDirty = true
        history.execute(RemoveComponentCommand(circuit, component))
        refreshAll()
    }

    override fun onWireAdded(wire: WireInstance) {
        simulationDirty = true
        history.execute(AddWireCommand(circuit, wire))
        refreshAll()
    }

    override fun onWireRemoved(wire: WireInstance) {
        simulationDirty = true
        history.execute(RemoveWireCommand(circuit, wire))
        refreshAll()
    }

    override fun onWireReconnected(oldWire: WireInstance, newWire: WireInstance) {
        simulationDirty = true
        history.execute(CompositeCommand(listOf(
            RemoveWireCommand(circuit, oldWire),
            AddWireCommand(circuit, newWire)
        )))
        refreshAll()
    }

    override fun onSwitchToggled(componentId: Int) {
        val component = circuit.componentById(componentId) ?: return
        val current = simulation.outputState(component)
        simulation.setSwitchState(componentId, !current)
    }

    override fun onBulkAdd(components: List<ComponentInstance>, wires: List<WireInstance>) {
        simulationDirty = true
        val commands = mutableListOf<Command>()
        components.forEach { commands.add(AddComponentCommand(circuit, it)) }
        wires.forEach { commands.add(AddWireCommand(circuit, it)) }
        if (commands.isNotEmpty()) history.execute(CompositeCommand(commands))
        refreshAll()
    }

    override fun onBulkDelete(componentIds: Set<Int>, wireIds: Set<Int>) {
        simulationDirty = true
        val commands = mutableListOf<Command>()
        // Explicit wire removals first; component removal also cascades
        // any wires still attached to it. CircuitModel's map-based
        // storage makes addWire/removeWire safely idempotent by id, so
        // combining both kinds of command here is safe even when a wire
        // is captured by more than one of them (see CompositeCommand).
        wireIds.forEach { id -> circuit.wireById(id)?.let { commands.add(RemoveWireCommand(circuit, it)) } }
        componentIds.forEach { id -> circuit.componentById(id)?.let { commands.add(RemoveComponentCommand(circuit, it)) } }
        if (commands.isEmpty()) {
            Toast.makeText(this, R.string.nothing_to_delete_toast, Toast.LENGTH_SHORT).show()
            return
        }
        history.execute(CompositeCommand(commands))
        refreshAll()
    }

    override fun onRotateRequested(componentIds: Set<Int>) {
        history.execute(RotateComponentsCommand(circuit, componentIds))
        refreshAll()
    }

    override fun onMirrorRequested(componentIds: Set<Int>) {
        history.execute(MirrorComponentsCommand(circuit, componentIds))
        refreshAll()
    }

    override fun onLockToggleRequested(componentIds: Set<Int>, locked: Boolean) {
        history.execute(LockComponentsCommand(circuit, componentIds, locked))
        refreshAll()
    }

    override fun onGroupRequested(componentIds: Set<Int>) {
        history.execute(GroupComponentsCommand(circuit, componentIds))
        refreshAll()
    }

    override fun onUngroupRequested(componentIds: Set<Int>) {
        history.execute(UngroupComponentsCommand(circuit, componentIds))
        refreshAll()
    }

    override fun onAlignRequested(componentIds: Set<Int>, alignment: AlignmentType) {
        history.execute(AlignComponentsCommand(circuit, componentIds, alignment))
        refreshAll()
    }

    override fun onDistributeRequested(componentIds: Set<Int>, axis: DistributeAxis) {
        history.execute(DistributeComponentsCommand(circuit, componentIds, axis))
        refreshAll()
    }

    private fun showExamples() {
        ExamplesDialog.show(
            context = this,
            hasUnsavedContent = circuit.allComponents.isNotEmpty()
        ) { example ->
            val model = example.model ?: return@show
            // Confirm only when the canvas has content the user might care about
            val hasContent = circuit.allComponents.isNotEmpty()
            val doLoad = {
                if (simulation.isRunning) {
                    simulation.pause()
                    binding.canvasView.simulationRunning = false
                    binding.fabPlayPause.setImageResource(R.drawable.ic_play)
                }
                circuit.clear()
                model.allComponents.forEach { circuit.addComponent(it.copy()) }
                model.allWires.forEach { circuit.addWire(it.copy()) }
                history.clear()
                simulationDirty = true
                binding.canvasView.fitToScreen()
                refreshAll()
            }
            if (hasContent) {
                MaterialAlertDialogBuilder(this)
                    .setMessage(R.string.confirm_load_example)
                    .setPositiveButton(R.string.confirm) { _, _ -> doLoad() }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            } else {
                doLoad()
            }
        }
    }

    private fun showInspector(component: ComponentInstance) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this)
        val view = layoutInflater.inflate(R.layout.bottom_sheet_inspector, null)
        view.findViewById<TextView>(R.id.inspectorTitle).text = component.label ?: component.type.displayName
        view.findViewById<TextView>(R.id.inspectorDescription).text = component.type.description

        val pinLabelsHeading = view.findViewById<TextView>(R.id.pinLabelsHeading)
        val pinLabelsContainer = view.findViewById<LinearLayout>(R.id.pinLabelsContainer)
        val hasPinLabels = component.type.inputLabels.any { it.isNotEmpty() } || component.type.outputLabels.any { it.isNotEmpty() }
        if (hasPinLabels) {
            pinLabelsHeading.visibility = View.VISIBLE
            component.type.inputLabels.forEachIndexed { i, label ->
                if (label.isEmpty()) return@forEachIndexed
                val row = TextView(this)
                row.text = "IN $i \u2014 $label"
                pinLabelsContainer.addView(row)
            }
            component.type.outputLabels.forEachIndexed { i, label ->
                if (label.isEmpty()) return@forEachIndexed
                val row = TextView(this)
                row.text = "OUT $i \u2014 $label"
                pinLabelsContainer.addView(row)
            }
        }

        val truthTableHeading = view.findViewById<TextView>(R.id.truthTableHeading)
        val stateDependentNote = view.findViewById<TextView>(R.id.stateDependentNote)
        val tableContainer = view.findViewById<LinearLayout>(R.id.truthTableContainer)
        if (component.type.truthTable.isNotEmpty()) {
            truthTableHeading.visibility = View.VISIBLE
            for ((inputs, outputs) in component.type.truthTable) {
                val row = TextView(this)
                val inStr = inputs.joinToString("") { if (it) "1" else "0" }
                val outStr = outputs.joinToString("") { if (it) "1" else "0" }
                row.text = "$inStr  \u2192  $outStr"
                tableContainer.addView(row)
            }
        } else if (component.type.category == ComponentCategory.MEMORY) {
            stateDependentNote.visibility = View.VISIBLE
        }

        dialog.setContentView(view)
        dialog.show()
    }

    override fun onDestroy() {
        simulation.release()
        super.onDestroy()
    }
}
