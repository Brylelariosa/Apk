package com.circuitsandbox.app.model

/**
 * Pre-built example circuits that ship with the app.
 *
 * Every circuit here is built entirely from the component types the
 * simulation engine implements, and every sequential/FSM example below was
 * hand-derived from an explicit state transition table before being wired
 * up — see the comment above each state-machine builder for the table it
 * implements, so the logic can be checked against the circuit independent
 * of running it.
 *
 * Each builder function is self-contained: it allocates its own
 * [CircuitModel] with local ID counters, so examples can be loaded in any
 * order without ID collisions, and the returned model's counter is already
 * positioned above the highest used ID so user additions won't collide.
 */
object ExampleLibrary {

    val all: List<ExampleCircuit> by lazy { build() }

    private fun build(): List<ExampleCircuit> = listOf(
        // Beginner
        ledSwitch(),
        andGate(),
        orGate(),
        notGate(),
        xorGate(),
        // Intermediate
        halfAdder(),
        clockBlinker(),
        nandAsNot(),
        majorityVote(),
        srLatch(),
        dFlipFlop(),
        memoryCell(),
        multiplexerDemo(),
        decoderDemo(),
        // Advanced
        parityChecker(),
        jkFlipFlop(),
        binaryCounter(),
        sevenSegmentCounter(),
        trafficLightController(),
        registerDemo(),
        digitalSafe(),
        fourBitAdder(),
        simpleALU(),
        sequenceDetector(),
        elevatorController(),
        vendingMachine(),
        cpuBuildingBlocks()
    )

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /** Tiny builder state threaded through each circuit factory.
     * Using a class instance (not a global counter) keeps each factory
     * function independent and thread-safe to call. */
    private class Builder {
        private var nextCompId = 1
        private var nextWireId = 1
        fun compId() = nextCompId++
        fun wireId() = nextWireId++

        fun comp(type: ComponentType, x: Float, y: Float, label: String? = null) =
            ComponentInstance(compId(), type, x, y, label = label)

        fun wire(from: ComponentInstance, fromPin: Int = 0,
                 to: ComponentInstance, toPin: Int = 0) =
            WireInstance(wireId(), WireEndpoint(from.id, fromPin, false), WireEndpoint(to.id, toPin, true))
    }

    private fun circuit(
        title: String,
        difficulty: Difficulty,
        description: String,
        howItWorks: String,
        block: Builder.(CircuitModel) -> Unit
    ): ExampleCircuit {
        val builder = Builder()
        val model = CircuitModel()
        builder.block(model)
        return ExampleCircuit(title, difficulty, description, howItWorks, model)
    }

    // -----------------------------------------------------------------------
    // Beginner
    // -----------------------------------------------------------------------

    private fun ledSwitch() = circuit(
        title = "LED Switch",
        difficulty = Difficulty.BEGINNER,
        description = "The simplest possible circuit: a toggle switch driving an LED.",
        howItWorks = "Tap the switch while the simulation is running. Its output pin goes HIGH (1), which lights the LED. Tap again to turn it off."
    ) { m ->
        val sw = comp(ComponentType.INPUT_SWITCH, -160f, 0f, "Switch")
        val led = comp(ComponentType.OUTPUT_LED, 160f, 0f, "LED")
        m.addComponent(sw); m.addComponent(led)
        m.addWire(wire(sw, 0, led, 0))
    }

    private fun andGate() = circuit(
        title = "AND Gate",
        difficulty = Difficulty.BEGINNER,
        description = "Two switches controlling one LED through an AND gate. The LED only lights when BOTH switches are ON.",
        howItWorks = "AND outputs 1 only when every input is 1. Try all four combinations of the two switches to see the truth table in action."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -240f, -70f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -240f,  70f, "B")
        val g = comp(ComponentType.AND,            0f,   0f)
        val led = comp(ComponentType.OUTPUT_LED,  220f,   0f, "A · B")
        listOf(a, b, g, led).forEach { m.addComponent(it) }
        m.addWire(wire(a, 0, g, 0))
        m.addWire(wire(b, 0, g, 1))
        m.addWire(wire(g, 0, led, 0))
    }

    private fun orGate() = circuit(
        title = "OR Gate",
        difficulty = Difficulty.BEGINNER,
        description = "Two switches and an OR gate. The LED lights when EITHER switch (or both) is ON.",
        howItWorks = "OR outputs 1 when at least one input is 1. Compare this with the AND gate demo — the only combination that doesn't light the LED is both inputs OFF."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -240f, -70f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -240f,  70f, "B")
        val g = comp(ComponentType.OR,             0f,   0f)
        val led = comp(ComponentType.OUTPUT_LED, 220f,   0f, "A + B")
        listOf(a, b, g, led).forEach { m.addComponent(it) }
        m.addWire(wire(a, 0, g, 0))
        m.addWire(wire(b, 0, g, 1))
        m.addWire(wire(g, 0, led, 0))
    }

    private fun notGate() = circuit(
        title = "NOT Gate (Inverter)",
        difficulty = Difficulty.BEGINNER,
        description = "A switch and its inverted output side by side. When the switch is ON, the top LED is on and the bottom is off — and vice versa.",
        howItWorks = "NOT (also called an inverter) flips its input. The top LED shows the raw switch state; the bottom LED shows NOT of it."
    ) { m ->
        val sw  = comp(ComponentType.INPUT_SWITCH,  -200f,  0f, "A")
        val buf = comp(ComponentType.BUFFER,          -20f, -70f)   // pass-through for the "A" branch
        val inv = comp(ComponentType.NOT,             -20f,  70f)
        val dA  = comp(ComponentType.OUTPUT_LED,     180f, -70f, "A")
        val dNA = comp(ComponentType.OUTPUT_LED,     180f,  70f, "NOT A")
        listOf(sw, buf, inv, dA, dNA).forEach { m.addComponent(it) }
        m.addWire(wire(sw, 0, buf, 0))
        m.addWire(wire(sw, 0, inv, 0))
        m.addWire(wire(buf, 0, dA,  0))
        m.addWire(wire(inv, 0, dNA, 0))
    }

    private fun xorGate() = circuit(
        title = "XOR Gate",
        difficulty = Difficulty.BEGINNER,
        description = "XOR (Exclusive-OR): the LED lights when the two switches DIFFER. When both are ON or both are OFF, the LED stays dark.",
        howItWorks = "XOR outputs 1 when an odd number of inputs are 1. With two inputs this means 'one or the other but not both' — perfect for detecting differences."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -240f, -70f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -240f,  70f, "B")
        val g = comp(ComponentType.XOR,            0f,   0f)
        val led = comp(ComponentType.OUTPUT_LED, 220f,   0f, "A \u2295 B")
        listOf(a, b, g, led).forEach { m.addComponent(it) }
        m.addWire(wire(a, 0, g, 0))
        m.addWire(wire(b, 0, g, 1))
        m.addWire(wire(g, 0, led, 0))
    }

    // -----------------------------------------------------------------------
    // Intermediate
    // -----------------------------------------------------------------------

    private fun halfAdder() = circuit(
        title = "Half Adder",
        difficulty = Difficulty.INTERMEDIATE,
        description = "Adds two 1-bit numbers. The XOR output is the Sum and the AND output is the Carry-out. This is the building block of all binary arithmetic.",
        howItWorks = "0+0=00, 0+1=01, 1+0=01, 1+1=10. Notice the Sum LED and Carry LED together give you the binary result. The 4-bit Adder example chains Full Adders built the same way."
    ) { m ->
        val a    = comp(ComponentType.INPUT_SWITCH, -240f,  0f,   "A")
        val b    = comp(ComponentType.INPUT_SWITCH, -240f, 120f,  "B")
        val xor  = comp(ComponentType.XOR,            0f,  0f)
        val and  = comp(ComponentType.AND,             0f, 120f)
        val sum  = comp(ComponentType.OUTPUT_LED,   220f,  0f,   "Sum")
        val carry= comp(ComponentType.OUTPUT_LED,   220f, 120f,  "Carry")
        listOf(a, b, xor, and, sum, carry).forEach { m.addComponent(it) }
        m.addWire(wire(a,   0, xor,  0))
        m.addWire(wire(b,   0, xor,  1))
        m.addWire(wire(a,   0, and,  0))
        m.addWire(wire(b,   0, and,  1))
        m.addWire(wire(xor, 0, sum,  0))
        m.addWire(wire(and, 0, carry,0))
    }

    private fun clockBlinker() = circuit(
        title = "Clock Blinker",
        difficulty = Difficulty.INTERMEDIATE,
        description = "A clock generator connected to an LED. Start the simulation to see the LED flash at the clock's rate.",
        howItWorks = "The Clock component automatically toggles HIGH/LOW each simulation tick. Adjust the simulation speed with the FAB — faster speed = faster blink. This is the heartbeat of every sequential circuit."
    ) { m ->
        val clk = comp(ComponentType.CLOCK,        -120f, 0f, "CLK")
        val led = comp(ComponentType.OUTPUT_LED,   120f,  0f, "Pulse")
        m.addComponent(clk); m.addComponent(led)
        m.addWire(wire(clk, 0, led, 0))
    }

    private fun nandAsNot() = circuit(
        title = "NAND as NOT",
        difficulty = Difficulty.INTERMEDIATE,
        description = "A NAND gate wired as an inverter by tying both inputs together. This demonstrates that NAND is a universal gate — you can build any logic function from NAND gates alone.",
        howItWorks = "When both NAND inputs get the same value, NAND(A,A) = NOT(A·A) = NOT(A). Toggle the switch: the LED shows the opposite state, just like a NOT gate — but built from a NAND."
    ) { m ->
        val sw  = comp(ComponentType.INPUT_SWITCH, -220f, 0f, "A")
        val nand= comp(ComponentType.NAND,           0f,  0f)
        val led = comp(ComponentType.OUTPUT_LED,   220f,  0f, "NOT A")
        listOf(sw, nand, led).forEach { m.addComponent(it) }
        // Both NAND inputs tied to the same switch output
        m.addWire(wire(sw, 0, nand, 0))
        m.addWire(wire(sw, 0, nand, 1))
        m.addWire(wire(nand, 0, led, 0))
    }

    private fun majorityVote() = circuit(
        title = "Majority Vote (3-input)",
        difficulty = Difficulty.INTERMEDIATE,
        description = "The LED lights when 2 or more of the 3 inputs are HIGH — a democratic majority vote circuit.",
        howItWorks = "Logic: (A·B) + (B·C) + (A·C). Each AND gate detects one of the three 'agree' pairs; the OR tree combines them. Useful in fault-tolerant systems where at least two of three sensors must agree."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -320f, -80f, "A")
        val b = comp(ComponentType.INPUT_SWITCH, -320f,   0f, "B")
        val c = comp(ComponentType.INPUT_SWITCH, -320f,  80f, "C")

        val ab = comp(ComponentType.AND,  -120f, -100f)
        val bc = comp(ComponentType.AND,  -120f,    0f)
        val ac = comp(ComponentType.AND,  -120f,  100f)

        val or1 = comp(ComponentType.OR,  80f, -50f)
        val or2 = comp(ComponentType.OR, 220f,  25f)
        val led = comp(ComponentType.OUTPUT_LED, 380f, 25f, "Majority")

        listOf(a, b, c, ab, bc, ac, or1, or2, led).forEach { m.addComponent(it) }

        // Feed inputs into AND pairs
        m.addWire(wire(a, 0, ab, 0)); m.addWire(wire(b, 0, ab, 1))
        m.addWire(wire(b, 0, bc, 0)); m.addWire(wire(c, 0, bc, 1))
        m.addWire(wire(a, 0, ac, 0)); m.addWire(wire(c, 0, ac, 1))

        // Two-stage OR tree
        m.addWire(wire(ab, 0, or1, 0)); m.addWire(wire(bc, 0, or1, 1))
        m.addWire(wire(or1, 0, or2, 0)); m.addWire(wire(ac, 0, or2, 1))
        m.addWire(wire(or2, 0, led, 0))
    }

    private fun srLatch() = circuit(
        title = "SR Latch",
        difficulty = Difficulty.INTERMEDIATE,
        description = "The simplest 1-bit memory. Set (S) forces the output to 1 and Reset (R) forces it to 0 — and it remembers whichever happened last, even after you let go of both switches.",
        howItWorks = "With S=0 and R=0 the latch just holds its last value — that's what makes it memory. Try: turn S on then off (Q stays 1), then turn R on then off (Q goes to 0 and stays there). Avoid S=1 and R=1 together — that's an invalid state for this latch."
    ) { m ->
        val s = comp(ComponentType.INPUT_SWITCH, -220f, -60f, "S")
        val r = comp(ComponentType.INPUT_SWITCH, -220f,  60f, "R")
        val latch = comp(ComponentType.SR_LATCH, 0f, 0f)
        val q = comp(ComponentType.OUTPUT_LED, 220f, -60f, "Q")
        val qn = comp(ComponentType.OUTPUT_LED, 220f, 60f, "Q'")
        listOf(s, r, latch, q, qn).forEach { m.addComponent(it) }
        m.addWire(wire(s, 0, latch, 0))
        m.addWire(wire(r, 0, latch, 1))
        m.addWire(wire(latch, 0, q, 0))
        m.addWire(wire(latch, 1, qn, 0))
    }

    private fun dFlipFlop() = circuit(
        title = "D Flip-Flop",
        difficulty = Difficulty.INTERMEDIATE,
        description = "Edge-triggered 1-bit memory — the building block every register and counter is made from. Q only updates the instant CLK rises from 0 to 1.",
        howItWorks = "Set D to whatever you want to store, then tap CLK once. Q captures D at that instant and holds it — changing D afterward has no effect until the next CLK tap. This 'capture only on the edge' behavior is what lets many flip-flops share one clock and all update in perfect lockstep."
    ) { m ->
        val d = comp(ComponentType.INPUT_SWITCH, -220f, -60f, "D")
        val clk = comp(ComponentType.PUSH_BUTTON, -220f, 60f, "CLK (tap)")
        val ff = comp(ComponentType.D_FLIP_FLOP, 0f, 0f)
        val q = comp(ComponentType.OUTPUT_LED, 220f, -60f, "Q")
        val qn = comp(ComponentType.OUTPUT_LED, 220f, 60f, "Q'")
        listOf(d, clk, ff, q, qn).forEach { m.addComponent(it) }
        m.addWire(wire(d, 0, ff, 0))
        m.addWire(wire(clk, 0, ff, 1))
        m.addWire(wire(ff, 0, q, 0))
        m.addWire(wire(ff, 1, qn, 0))
    }

    private fun memoryCell() = circuit(
        title = "1-Bit Memory Cell",
        difficulty = Difficulty.INTERMEDIATE,
        description = "A D Latch used the way real memory is: hold WRITE ENABLE on to store whatever DATA currently is, then release it to freeze that value in place.",
        howItWorks = "While WRITE ENABLE is on, the latch is 'transparent' and the LED just follows DATA directly. The moment you turn WRITE ENABLE off, the last DATA value gets frozen — you can now change DATA freely and the LED won't move, because the cell is remembering what you wrote."
    ) { m ->
        val data = comp(ComponentType.INPUT_SWITCH, -220f, -60f, "DATA")
        val we = comp(ComponentType.INPUT_SWITCH, -220f, 60f, "WRITE ENABLE")
        val latch = comp(ComponentType.D_LATCH, 0f, 0f)
        val q = comp(ComponentType.OUTPUT_LED, 220f, 0f, "STORED")
        listOf(data, we, latch, q).forEach { m.addComponent(it) }
        m.addWire(wire(data, 0, latch, 0))
        m.addWire(wire(we, 0, latch, 1))
        m.addWire(wire(latch, 0, q, 0))
    }

    private fun multiplexerDemo() = circuit(
        title = "4:1 Multiplexer",
        difficulty = Difficulty.INTERMEDIATE,
        description = "A data router: four input switches feed one output LED, and the two SELECT switches choose which single input actually reaches it.",
        howItWorks = "SELECT is read as a 2-bit binary number (S1 S0): 00 routes I0, 01 routes I1, 10 routes I2, 11 routes I3. Everything else is ignored — only the selected input affects the LED. This is exactly how a CPU's bus routes one of several signals onto a shared wire."
    ) { m ->
        val i0 = comp(ComponentType.INPUT_SWITCH, -260f, -150f, "I0")
        val i1 = comp(ComponentType.INPUT_SWITCH, -260f, -50f, "I1")
        val i2 = comp(ComponentType.INPUT_SWITCH, -260f, 50f, "I2")
        val i3 = comp(ComponentType.INPUT_SWITCH, -260f, 150f, "I3")
        val s0 = comp(ComponentType.INPUT_SWITCH, -260f, 250f, "S0")
        val s1 = comp(ComponentType.INPUT_SWITCH, -260f, 330f, "S1")
        val mux = comp(ComponentType.MUX_4TO1, 0f, 40f)
        val out = comp(ComponentType.OUTPUT_LED, 220f, 40f, "OUT")
        listOf(i0, i1, i2, i3, s0, s1, mux, out).forEach { m.addComponent(it) }
        m.addWire(wire(i0, 0, mux, 0))
        m.addWire(wire(i1, 0, mux, 1))
        m.addWire(wire(i2, 0, mux, 2))
        m.addWire(wire(i3, 0, mux, 3))
        m.addWire(wire(s0, 0, mux, 4))
        m.addWire(wire(s1, 0, mux, 5))
        m.addWire(wire(mux, 0, out, 0))
    }

    private fun decoderDemo() = circuit(
        title = "2-to-4 Decoder",
        difficulty = Difficulty.INTERMEDIATE,
        description = "Turns a 2-bit binary address into a one-hot signal: exactly one of the four LEDs lights up, matching the binary value of A1:A0.",
        howItWorks = "This is the mirror image of the multiplexer — instead of routing many inputs to one output, a decoder routes one 'address' to many outputs. Decoders are what select which row of memory, or which peripheral, a CPU is currently talking to."
    ) { m ->
        val a0 = comp(ComponentType.INPUT_SWITCH, -220f, -50f, "A0")
        val a1 = comp(ComponentType.INPUT_SWITCH, -220f, 50f, "A1")
        val dec = comp(ComponentType.DECODER_2TO4, 0f, 0f)
        val o0 = comp(ComponentType.OUTPUT_LED, 220f, -120f, "O0")
        val o1 = comp(ComponentType.OUTPUT_LED, 220f, -40f, "O1")
        val o2 = comp(ComponentType.OUTPUT_LED, 220f, 40f, "O2")
        val o3 = comp(ComponentType.OUTPUT_LED, 220f, 120f, "O3")
        listOf(a0, a1, dec, o0, o1, o2, o3).forEach { m.addComponent(it) }
        m.addWire(wire(a0, 0, dec, 0))
        m.addWire(wire(a1, 0, dec, 1))
        m.addWire(wire(dec, 0, o0, 0))
        m.addWire(wire(dec, 1, o1, 0))
        m.addWire(wire(dec, 2, o2, 0))
        m.addWire(wire(dec, 3, o3, 0))
    }

    // -----------------------------------------------------------------------
    // Advanced
    // -----------------------------------------------------------------------

    private fun parityChecker() = circuit(
        title = "4-bit Parity Checker",
        difficulty = Difficulty.ADVANCED,
        description = "Computes the XOR of 4 bits. The LED lights when an ODD number of inputs are HIGH — this is the parity bit used in error-detection codes.",
        howItWorks = "XOR is associative: A⊕B⊕C⊕D = ((A⊕B)⊕C)⊕D. This is called even parity checking — the combined output is 1 when the data has odd parity, which is exactly the bit you'd append to a 4-bit word to make it always even parity."
    ) { m ->
        val a = comp(ComponentType.INPUT_SWITCH, -360f, -120f, "D0")
        val b = comp(ComponentType.INPUT_SWITCH, -360f,  -40f, "D1")
        val c = comp(ComponentType.INPUT_SWITCH, -360f,   40f, "D2")
        val d = comp(ComponentType.INPUT_SWITCH, -360f,  120f, "D3")

        val x1 = comp(ComponentType.XOR, -160f, -80f)   // A⊕B
        val x2 = comp(ComponentType.XOR, -160f,  80f)   // C⊕D
        val x3 = comp(ComponentType.XOR,   40f,   0f)   // (A⊕B)⊕(C⊕D)
        val led = comp(ComponentType.OUTPUT_LED, 240f,   0f, "Parity")

        listOf(a, b, c, d, x1, x2, x3, led).forEach { m.addComponent(it) }
        m.addWire(wire(a,  0, x1, 0)); m.addWire(wire(b, 0, x1, 1))
        m.addWire(wire(c,  0, x2, 0)); m.addWire(wire(d, 0, x2, 1))
        m.addWire(wire(x1, 0, x3, 0)); m.addWire(wire(x2, 0, x3, 1))
        m.addWire(wire(x3, 0, led, 0))
    }

    private fun jkFlipFlop() = circuit(
        title = "JK Flip-Flop",
        difficulty = Difficulty.ADVANCED,
        description = "The most flexible edge-triggered flip-flop: hold, set, reset, or toggle, chosen by J and K, applied on each CLK tap.",
        howItWorks = "J=0,K=0 holds; J=1,K=0 sets Q=1; J=0,K=1 resets Q=0; J=1,K=1 toggles Q — try all four with a few CLK taps each. Tying J and K together and always driving both HIGH is exactly how the T (toggle) flip-flop used in the Binary Counter example works."
    ) { m ->
        val j = comp(ComponentType.INPUT_SWITCH, -220f, -100f, "J")
        val clk = comp(ComponentType.PUSH_BUTTON, -220f, 0f, "CLK (tap)")
        val k = comp(ComponentType.INPUT_SWITCH, -220f, 100f, "K")
        val ff = comp(ComponentType.JK_FLIP_FLOP, 0f, 0f)
        val q = comp(ComponentType.OUTPUT_LED, 220f, -60f, "Q")
        val qn = comp(ComponentType.OUTPUT_LED, 220f, 60f, "Q'")
        listOf(j, clk, k, ff, q, qn).forEach { m.addComponent(it) }
        m.addWire(wire(j, 0, ff, 0))
        m.addWire(wire(clk, 0, ff, 1))
        m.addWire(wire(k, 0, ff, 2))
        m.addWire(wire(ff, 0, q, 0))
        m.addWire(wire(ff, 1, qn, 0))
    }

    /** Standard 4-bit asynchronous ripple counter: four T flip-flops with T
     * tied permanently HIGH, each one's Q clocking the next stage. A T
     * flip-flop with T=1 toggles on every rising edge of its clock, which
     * halves the frequency — chaining four of them counts 0000 through
     * 1111 in binary, LSB first. */
    private fun buildRippleCounter(m: CircuitModel, b: Builder, originX: Float, originY: Float, stageSpacing: Float): List<ComponentInstance> {
        val power = b.comp(ComponentType.POWER, originX - 140f, originY, "T=1")
        val clk = b.comp(ComponentType.CLOCK, originX - 140f, originY + stageSpacing * 3.2f, "CLK")
        m.addComponent(power); m.addComponent(clk)

        val stages = (0 until 4).map { i -> b.comp(ComponentType.T_FLIP_FLOP, originX + i * stageSpacing, originY, "Bit $i") }
        stages.forEach { m.addComponent(it) }

        stages.forEach { stage -> m.addWire(b.wire(power, 0, stage, 0)) } // T tied high
        m.addWire(b.wire(clk, 0, stages[0], 1))
        for (i in 0 until 3) m.addWire(b.wire(stages[i], 0, stages[i + 1], 1))
        return stages
    }

    private fun binaryCounter() = circuit(
        title = "4-bit Binary Counter",
        difficulty = Difficulty.ADVANCED,
        description = "Four T flip-flops chained into a ripple counter. Run the simulation and watch the four LEDs count up in binary from 0000 to 1111, then wrap around.",
        howItWorks = "Each T flip-flop toggles on every rising edge of its own clock input, which divides the frequency by 2. Chaining Bit0's output into Bit1's clock, Bit1's into Bit2's, and so on means Bit0 changes fastest and Bit3 changes slowest — exactly like an odometer, where the rightmost digit rolls over fastest."
    ) { m ->
        val b = Builder()
        val stages = buildRippleCounter(m, b, -180f, 0f, 120f)
        val leds = stages.mapIndexed { i, stage ->
            val led = b.comp(ComponentType.OUTPUT_LED, stage.x, 100f, "Bit $i")
            m.addComponent(led)
            m.addWire(b.wire(stage, 0, led, 0))
            led
        }
        leds
    }

    private fun sevenSegmentCounter() = circuit(
        title = "Seven-Segment Counter",
        difficulty = Difficulty.ADVANCED,
        description = "The same 4-bit ripple counter as before, but this time its 4 bits drive a real 7-segment display instead of separate LEDs. Run it and watch it count 0-9 then A-F in hex.",
        howItWorks = "A 7-segment display just decodes a 4-bit binary value into the familiar seven-segment digit shape — D0 is the least significant bit. Since 4 bits can represent 0-15 but a single digit only has symbols 0-9, values 10-15 are shown as the hex digits A-F, exactly like a hexadecimal display."
    ) { m ->
        val b = Builder()
        val stages = buildRippleCounter(m, b, -260f, -40f, 110f)
        val display = b.comp(ComponentType.SEVEN_SEG_DISPLAY, -260f + 110f * 1.5f, 140f)
        m.addComponent(display)
        stages.forEachIndexed { i, stage -> m.addWire(b.wire(stage, 0, display, i)) }
    }

    /** 2-bit ripple counter (00→01→10→11→00…) decoded straight into three
     * lights: Green while count=00, Yellow while count=01, Red while
     * count∈{10,11} — giving red twice the duration of green/yellow,
     * loosely mirroring a real light's timing without needing a timer. */
    private fun trafficLightController() = circuit(
        title = "Traffic Light Controller",
        difficulty = Difficulty.ADVANCED,
        description = "A 2-bit counter decoded into Red / Yellow / Green, cycling automatically: Green, then Yellow, then Red for twice as long, then back to Green.",
        howItWorks = "The counter cycles through states 00, 01, 10, 11. Green = NOR(Q1,Q0) (only lit at 00). Yellow = Q1' · Q0 (only at 01). Red is simply Q1 itself — HIGH for both 10 and 11, which is why red stays on twice as long as the other two."
    ) { m ->
        val b = Builder()
        val power = b.comp(ComponentType.POWER, -260f, -140f, "T=1")
        val clk = b.comp(ComponentType.CLOCK, -260f, 140f, "CLK")
        val ff0 = b.comp(ComponentType.T_FLIP_FLOP, -60f, -60f, "Q0")
        val ff1 = b.comp(ComponentType.T_FLIP_FLOP, 140f, -60f, "Q1")
        listOf(power, clk, ff0, ff1).forEach { m.addComponent(it) }
        m.addWire(b.wire(power, 0, ff0, 0)); m.addWire(b.wire(power, 0, ff1, 0))
        m.addWire(b.wire(clk, 0, ff0, 1))
        m.addWire(b.wire(ff0, 0, ff1, 1))

        val notQ1 = b.comp(ComponentType.NOT, 140f, 60f)
        val yellowAnd = b.comp(ComponentType.AND, 320f, 20f)
        val greenNor = b.comp(ComponentType.NOR, 320f, 140f)
        listOf(notQ1, yellowAnd, greenNor).forEach { m.addComponent(it) }
        m.addWire(b.wire(ff1, 0, notQ1, 0))
        m.addWire(b.wire(notQ1, 0, yellowAnd, 0))
        m.addWire(b.wire(ff0, 0, yellowAnd, 1))
        m.addWire(b.wire(ff1, 0, greenNor, 0))
        m.addWire(b.wire(ff0, 0, greenNor, 1))

        val redLed = b.comp(ComponentType.OUTPUT_LED, 500f, -60f, "RED")
        val yellowLed = b.comp(ComponentType.OUTPUT_LED, 500f, 20f, "YELLOW")
        val greenLed = b.comp(ComponentType.OUTPUT_LED, 500f, 140f, "GREEN")
        listOf(redLed, yellowLed, greenLed).forEach { m.addComponent(it) }
        m.addWire(b.wire(ff1, 0, redLed, 0))
        m.addWire(b.wire(yellowAnd, 0, yellowLed, 0))
        m.addWire(b.wire(greenNor, 0, greenLed, 0))
    }

    private fun registerDemo() = circuit(
        title = "4-bit Register",
        difficulty = Difficulty.ADVANCED,
        description = "Four D flip-flops sharing one clock: set the four DATA switches, tap LOAD once, and all four bits latch in together — a working 4-bit storage register.",
        howItWorks = "Because every flip-flop shares the same CLK, they all capture their D input on the exact same tick — that's what makes this a *register* and not just four separate 1-bit memories. Change the DATA switches afterward and the four LEDs won't move until you tap LOAD again."
    ) { m ->
        val b = Builder()
        val load = b.comp(ComponentType.PUSH_BUTTON, -260f, 200f, "LOAD (tap)")
        m.addComponent(load)
        for (i in 0 until 4) {
            val y = -180f + i * 120f
            val data = b.comp(ComponentType.INPUT_SWITCH, -260f, y, "D$i")
            val ff = b.comp(ComponentType.D_FLIP_FLOP, 0f, y)
            val led = b.comp(ComponentType.OUTPUT_LED, 220f, y, "Q$i")
            listOf(data, ff, led).forEach { m.addComponent(it) }
            m.addWire(b.wire(data, 0, ff, 0))
            m.addWire(b.wire(load, 0, ff, 1))
            m.addWire(b.wire(ff, 0, led, 0))
        }
    }

    /** AND/NOT tree checks the 4 switches against the fixed code 1-0-1-0,
     * feeding an SR latch's Set input so the "unlocked" state is
     * remembered even after the switches are changed again — RESET locks
     * it back up. */
    private fun digitalSafe() = circuit(
        title = "Digital Safe",
        difficulty = Difficulty.ADVANCED,
        description = "Enter the 4-switch code 1-0-1-0 (switch0=ON, switch1=OFF, switch2=ON, switch3=OFF) to unlock — the UNLOCKED light latches on and stays on even if you change the switches afterward, until you press RESET.",
        howItWorks = "Four checks (one per switch, inverted for the switches that must be OFF) feed a tree of AND gates that's HIGH only when the exact code is set. That pulse Sets an SR latch, which remembers 'unlocked' from then on — real combination locks work the same way, mechanically latching once the right sequence is entered."
    ) { m ->
        val b = Builder()
        val sw0 = b.comp(ComponentType.INPUT_SWITCH, -320f, -150f, "Switch 0 (want ON)")
        val sw1 = b.comp(ComponentType.INPUT_SWITCH, -320f, -50f, "Switch 1 (want OFF)")
        val sw2 = b.comp(ComponentType.INPUT_SWITCH, -320f, 50f, "Switch 2 (want ON)")
        val sw3 = b.comp(ComponentType.INPUT_SWITCH, -320f, 150f, "Switch 3 (want OFF)")
        val reset = b.comp(ComponentType.PUSH_BUTTON, -320f, 260f, "RESET (tap)")
        listOf(sw0, sw1, sw2, sw3, reset).forEach { m.addComponent(it) }

        val notSw1 = b.comp(ComponentType.NOT, -140f, -50f)
        val notSw3 = b.comp(ComponentType.NOT, -140f, 150f)
        m.addComponent(notSw1); m.addComponent(notSw3)
        m.addWire(b.wire(sw1, 0, notSw1, 0))
        m.addWire(b.wire(sw3, 0, notSw3, 0))

        val and1 = b.comp(ComponentType.AND, 20f, -100f)   // sw0 · notSw1
        val and2 = b.comp(ComponentType.AND, 20f, 100f)    // sw2 · notSw3
        val andFinal = b.comp(ComponentType.AND, 180f, 0f)
        listOf(and1, and2, andFinal).forEach { m.addComponent(it) }
        m.addWire(b.wire(sw0, 0, and1, 0)); m.addWire(b.wire(notSw1, 0, and1, 1))
        m.addWire(b.wire(sw2, 0, and2, 0)); m.addWire(b.wire(notSw3, 0, and2, 1))
        m.addWire(b.wire(and1, 0, andFinal, 0)); m.addWire(b.wire(and2, 0, andFinal, 1))

        val latch = b.comp(ComponentType.SR_LATCH, 340f, 60f)
        val led = b.comp(ComponentType.OUTPUT_LED, 500f, 0f, "UNLOCKED")
        listOf(latch, led).forEach { m.addComponent(it) }
        m.addWire(b.wire(andFinal, 0, latch, 0))
        m.addWire(b.wire(reset, 0, latch, 1))
        m.addWire(b.wire(latch, 0, led, 0))
    }

    private fun fourBitAdder() = circuit(
        title = "4-bit Adder (Calculator Logic)",
        difficulty = Difficulty.ADVANCED,
        description = "Four Full Adders chained carry-to-carry to add two 4-bit numbers (A3A2A1A0 + B3B2B1B0), with a 5th LED for the final Carry-out — the core arithmetic circuit inside every calculator and CPU.",
        howItWorks = "Each Full Adder handles one bit position: it adds Ai + Bi + the carry from the previous (less significant) stage, producing that position's Sum bit and a Carry-out into the next stage. Chaining four of these carry-to-carry — called a ripple-carry adder — adds the full 4-bit numbers correctly, the same way you'd add on paper column by column."
    ) { m ->
        val b = Builder()
        val ground = b.comp(ComponentType.GROUND, -320f, 220f, "Cin=0")
        m.addComponent(ground)
        var carry = ground
        var carryPin = 0
        for (i in 0 until 4) {
            val y = -180f + i * 120f
            val a = b.comp(ComponentType.INPUT_SWITCH, -320f, y - 20f, "A$i")
            val bb = b.comp(ComponentType.INPUT_SWITCH, -320f, y + 20f, "B$i")
            val fa = b.comp(ComponentType.FULL_ADDER, -80f, y)
            val sumLed = b.comp(ComponentType.OUTPUT_LED, 140f, y, "Sum$i")
            listOf(a, bb, fa, sumLed).forEach { m.addComponent(it) }
            m.addWire(b.wire(a, 0, fa, 0))
            m.addWire(b.wire(bb, 0, fa, 1))
            m.addWire(b.wire(carry, carryPin, fa, 2))
            m.addWire(b.wire(fa, 0, sumLed, 0))
            carry = fa; carryPin = 1
        }
        val carryOutLed = b.comp(ComponentType.OUTPUT_LED, 140f, 220f, "Carry-out")
        m.addComponent(carryOutLed)
        m.addWire(b.wire(carry, carryPin, carryOutLed, 0))
    }

    private fun simpleALU() = circuit(
        title = "Simple 1-Bit ALU",
        difficulty = Difficulty.ADVANCED,
        description = "One Arithmetic Logic Unit core: A and B feed AND, OR, XOR, and ADD circuits all at once, and a 2-bit OPCODE selects which single result reaches the output — plus a separate always-on Carry flag.",
        howItWorks = "This is the essence of every real ALU: compute several functions in parallel, then use a multiplexer to pick which one 'wins' based on the opcode (00=AND, 01=OR, 10=XOR, 11=ADD). The Carry-out LED is wired straight from the adder and stays meaningful only when OPCODE selects ADD — just like a real CPU's carry flag."
    ) { m ->
        val b = Builder()
        val a = b.comp(ComponentType.INPUT_SWITCH, -320f, -80f, "A")
        val bIn = b.comp(ComponentType.INPUT_SWITCH, -320f, 0f, "B")
        val ground = b.comp(ComponentType.GROUND, -320f, 80f, "Cin=0")
        val op0 = b.comp(ComponentType.INPUT_SWITCH, -320f, 220f, "OPCODE bit0")
        val op1 = b.comp(ComponentType.INPUT_SWITCH, -320f, 300f, "OPCODE bit1")
        listOf(a, bIn, ground, op0, op1).forEach { m.addComponent(it) }

        val andG = b.comp(ComponentType.AND, -80f, -140f)
        val orG = b.comp(ComponentType.OR, -80f, -60f)
        val xorG = b.comp(ComponentType.XOR, -80f, 20f)
        val adder = b.comp(ComponentType.FULL_ADDER, -80f, 120f)
        listOf(andG, orG, xorG, adder).forEach { m.addComponent(it) }
        for (gate in listOf(andG, orG, xorG)) {
            m.addWire(b.wire(a, 0, gate, 0))
            m.addWire(b.wire(bIn, 0, gate, 1))
        }
        m.addWire(b.wire(a, 0, adder, 0))
        m.addWire(b.wire(bIn, 0, adder, 1))
        m.addWire(b.wire(ground, 0, adder, 2))

        val mux = b.comp(ComponentType.MUX_4TO1, 140f, 0f)
        m.addComponent(mux)
        m.addWire(b.wire(andG, 0, mux, 0))
        m.addWire(b.wire(orG, 0, mux, 1))
        m.addWire(b.wire(xorG, 0, mux, 2))
        m.addWire(b.wire(adder, 0, mux, 3))
        m.addWire(b.wire(op0, 0, mux, 4))
        m.addWire(b.wire(op1, 0, mux, 5))

        val resultLed = b.comp(ComponentType.OUTPUT_LED, 360f, -40f, "RESULT")
        val carryLed = b.comp(ComponentType.OUTPUT_LED, 360f, 120f, "CARRY (ADD only)")
        listOf(resultLed, carryLed).forEach { m.addComponent(it) }
        m.addWire(b.wire(mux, 0, resultLed, 0))
        m.addWire(b.wire(adder, 1, carryLed, 0))
    }

    /** Mealy sequence detector for the overlapping pattern "1011" in a
     * serial bit stream. States encode "longest prefix of 1011 matched by
     * the input seen so far": S0=00 (none), S1=01 ("1"), S2=10 ("10"),
     * S3=11 ("101"); MATCH pulses HIGH exactly when a bit completes the
     * pattern. Full transition table (state, X → next, match):
     *   S0,0→S0,0   S0,1→S1,0   S1,0→S2,0   S1,1→S1,0
     *   S2,0→S0,0   S2,1→S3,0   S3,0→S2,0   S3,1→S1,1
     * From this table: D0 (next Q0) simplifies to X in every single state,
     * so it's wired directly with no gate at all; D1 needed a per-state
     * mux (GND, NOT X, X, NOT X for S0..S3); MATCH = Q1 · Q0 · X. */
    private fun sequenceDetector() = circuit(
        title = "Sequence Detector (finds \"1011\")",
        difficulty = Difficulty.ADVANCED,
        description = "A finite state machine that watches a serial bit stream and lights MATCH the instant it sees the pattern 1011 — overlapping matches count, just like a real pattern detector.",
        howItWorks = "Toggle BIT to feed in 1, 0, 1, 1 one at a time, tapping STEP after each — MATCH should flash on the 4th tap. Then try continuing with another 1 (making the tail '...1011' + '1' = overlap) to see it track a fresh potential match starting from that same bit, exactly like searching for a pattern that could restart mid-stream."
    ) { m ->
        val b = Builder()
        val bit = b.comp(ComponentType.INPUT_SWITCH, -320f, -80f, "BIT")
        val step = b.comp(ComponentType.PUSH_BUTTON, -320f, 40f, "STEP (tap)")
        val ground = b.comp(ComponentType.GROUND, -320f, 160f)
        listOf(bit, step, ground).forEach { m.addComponent(it) }

        val notBit = b.comp(ComponentType.NOT, -140f, -40f)
        m.addComponent(notBit)
        m.addWire(b.wire(bit, 0, notBit, 0))

        val muxD1 = b.comp(ComponentType.MUX_4TO1, 40f, -60f)
        m.addComponent(muxD1)
        // I0=GND, I1=notX, I2=X, I3=notX — select = (S1=Q1, S0=Q0), wired below once ff0/ff1 exist.
        m.addWire(b.wire(ground, 0, muxD1, 0))
        m.addWire(b.wire(notBit, 0, muxD1, 1))
        m.addWire(b.wire(bit, 0, muxD1, 2))
        m.addWire(b.wire(notBit, 0, muxD1, 3))

        val ff1 = b.comp(ComponentType.D_FLIP_FLOP, 220f, -60f, "Q1")
        val ff0 = b.comp(ComponentType.D_FLIP_FLOP, 220f, 60f, "Q0")
        listOf(ff1, ff0).forEach { m.addComponent(it) }
        m.addWire(b.wire(muxD1, 0, ff1, 0))
        m.addWire(b.wire(bit, 0, ff0, 0)) // D0 = X directly, in every state
        m.addWire(b.wire(step, 0, ff1, 1))
        m.addWire(b.wire(step, 0, ff0, 1))
        // Feedback: current state selects the mux for the *next* D1.
        m.addWire(b.wire(ff0, 0, muxD1, 4))
        m.addWire(b.wire(ff1, 0, muxD1, 5))

        val and1 = b.comp(ComponentType.AND, 400f, 0f)
        val matchAnd = b.comp(ComponentType.AND, 400f, 100f)
        listOf(and1, matchAnd).forEach { m.addComponent(it) }
        m.addWire(b.wire(ff1, 0, and1, 0))
        m.addWire(b.wire(ff0, 0, and1, 1))
        m.addWire(b.wire(and1, 0, matchAnd, 0))
        m.addWire(b.wire(bit, 0, matchAnd, 1))

        val matchLed = b.comp(ComponentType.OUTPUT_LED, 560f, 100f, "MATCH")
        m.addComponent(matchLed)
        m.addWire(b.wire(matchAnd, 0, matchLed, 0))

        val decoder = b.comp(ComponentType.DECODER_2TO4, 220f, 220f)
        m.addComponent(decoder)
        m.addWire(b.wire(ff0, 0, decoder, 0))
        m.addWire(b.wire(ff1, 0, decoder, 1))
        val stateLabels = listOf("state: none", "state: \"1\"", "state: \"10\"", "state: \"101\"")
        stateLabels.forEachIndexed { i, label ->
            val led = b.comp(ComponentType.OUTPUT_LED, 400f + i * 90f, 220f, label)
            m.addComponent(led)
            m.addWire(b.wire(decoder, i, led, 0))
        }
    }

    /** 4-state Moore FSM (IDLE=00, OPENING=01, OPEN=10, CLOSING=11).
     * Transition table: IDLE stays unless CALL=1 (→OPENING); OPENING,
     * OPEN, and CLOSING all advance unconditionally to the next state
     * every step, wrapping CLOSING→IDLE. From this table D1 collapses to
     * exactly Q1 XOR Q0 (verified against all 8 state/CALL combinations),
     * and D0 needs one 4:1 mux (CALL, GND, PWR, GND for IDLE..CLOSING). */
    private fun elevatorController() = circuit(
        title = "Elevator Door Controller",
        difficulty = Difficulty.ADVANCED,
        description = "A simplified elevator door FSM: press CALL to start opening, then tap STEP to watch it walk through OPENING → OPEN → CLOSING → back to IDLE on its own.",
        howItWorks = "This is a Moore machine — its four LEDs show the state directly, one lit at a time. IDLE waits for CALL; once triggered, the door marches through the remaining three states automatically regardless of CALL, one state per STEP tap, then returns to IDLE ready for the next call. Real door controllers use a timer instead of a manual STEP button, but the state logic is the same."
    ) { m ->
        val b = Builder()
        val call = b.comp(ComponentType.PUSH_BUTTON, -280f, -60f, "CALL (tap)")
        val step = b.comp(ComponentType.PUSH_BUTTON, -280f, 60f, "STEP (tap)")
        val ground = b.comp(ComponentType.GROUND, -280f, 180f)
        val power = b.comp(ComponentType.POWER, -280f, 260f)
        listOf(call, step, ground, power).forEach { m.addComponent(it) }

        val xorD1 = b.comp(ComponentType.XOR, -60f, -80f)
        m.addComponent(xorD1)

        val muxD0 = b.comp(ComponentType.MUX_4TO1, -60f, 60f)
        m.addComponent(muxD0)
        m.addWire(b.wire(call, 0, muxD0, 0))   // I0 (IDLE):   D0 = CALL
        m.addWire(b.wire(ground, 0, muxD0, 1)) // I1 (OPENING):D0 = 0
        m.addWire(b.wire(power, 0, muxD0, 2))  // I2 (OPEN):   D0 = 1
        m.addWire(b.wire(ground, 0, muxD0, 3)) // I3 (CLOSING):D0 = 0

        val ff1 = b.comp(ComponentType.D_FLIP_FLOP, 140f, -80f, "Q1")
        val ff0 = b.comp(ComponentType.D_FLIP_FLOP, 140f, 60f, "Q0")
        listOf(ff1, ff0).forEach { m.addComponent(it) }
        m.addWire(b.wire(xorD1, 0, ff1, 0))
        m.addWire(b.wire(muxD0, 0, ff0, 0))
        m.addWire(b.wire(step, 0, ff1, 1))
        m.addWire(b.wire(step, 0, ff0, 1))
        // Feedback into both the XOR (D1) and the mux select lines (Q1,Q0 = current state)
        m.addWire(b.wire(ff1, 0, xorD1, 0))
        m.addWire(b.wire(ff0, 0, xorD1, 1))
        m.addWire(b.wire(ff0, 0, muxD0, 4))
        m.addWire(b.wire(ff1, 0, muxD0, 5))

        val decoder = b.comp(ComponentType.DECODER_2TO4, 340f, -10f)
        m.addComponent(decoder)
        m.addWire(b.wire(ff0, 0, decoder, 0))
        m.addWire(b.wire(ff1, 0, decoder, 1))
        val labels = listOf("IDLE", "OPENING", "OPEN", "CLOSING")
        labels.forEachIndexed { i, label ->
            val led = b.comp(ComponentType.OUTPUT_LED, 520f, -140f + i * 90f, label)
            m.addComponent(led)
            m.addWire(b.wire(decoder, i, led, 0))
        }
    }

    /** 4-state FSM (S0=0¢, S5=5¢, S10=10¢, S15=dispense) for a 15¢ machine
     * taking nickels (N) and dimes (D), dime-priority on simultaneous
     * input. Derived per-state as a function of (N,D) — see the inline
     * per-mux-input comments for the hand-verified table each input
     * implements — then selected by a 4:1 mux keyed on the current state,
     * which is simpler and far less error-prone to wire up than the raw
     * 4-variable sum-of-products would have been. */
    private fun vendingMachine() = circuit(
        title = "Vending Machine (15\u00A2)",
        difficulty = Difficulty.ADVANCED,
        description = "Insert nickels and dimes (5\u00A2 / 10\u00A2) until you reach 15\u00A2 or more, then DISPENSE lights — a classic finite-state-machine teaching circuit.",
        howItWorks = "Toggle NICKEL or DIME on, tap STEP to 'insert' it, then toggle back off before the next insert. The four state LEDs track the running total: 0\u00A2 \u2192 5\u00A2 \u2192 10\u00A2 \u2192 DISPENSE. From DISPENSE, the next STEP always returns to 0\u00A2 regardless of the coin switches — a fresh purchase. Overpaying (e.g. two dimes from 5\u00A2) still dispenses; this simple version doesn't track change."
    ) { m ->
        val b = Builder()
        val nickel = b.comp(ComponentType.INPUT_SWITCH, -340f, -140f, "NICKEL")
        val dime = b.comp(ComponentType.INPUT_SWITCH, -340f, -60f, "DIME")
        val step = b.comp(ComponentType.PUSH_BUTTON, -340f, 40f, "STEP (tap)")
        val ground = b.comp(ComponentType.GROUND, -340f, 140f)
        val power = b.comp(ComponentType.POWER, -340f, 220f)
        listOf(nickel, dime, step, ground, power).forEach { m.addComponent(it) }

        val notNickel = b.comp(ComponentType.NOT, -160f, -180f)
        val notDime = b.comp(ComponentType.NOT, -160f, -100f)
        val orND = b.comp(ComponentType.OR, -160f, -20f)          // reused as D1.I1 and D0.I2
        val andN_notD = b.comp(ComponentType.AND, -160f, 60f)     // D0.I0 (state 0¢)
        val orD_notN = b.comp(ComponentType.OR, -160f, 140f)      // D0.I1 (state 5¢)
        listOf(notNickel, notDime, orND, andN_notD, orD_notN).forEach { m.addComponent(it) }
        m.addWire(b.wire(nickel, 0, notNickel, 0))
        m.addWire(b.wire(dime, 0, notDime, 0))
        m.addWire(b.wire(nickel, 0, orND, 0)); m.addWire(b.wire(dime, 0, orND, 1))
        m.addWire(b.wire(nickel, 0, andN_notD, 0)); m.addWire(b.wire(notDime, 0, andN_notD, 1))
        m.addWire(b.wire(dime, 0, orD_notN, 0)); m.addWire(b.wire(notNickel, 0, orD_notN, 1))

        val muxD1 = b.comp(ComponentType.MUX_4TO1, 40f, -100f)
        val muxD0 = b.comp(ComponentType.MUX_4TO1, 40f, 100f)
        listOf(muxD1, muxD0).forEach { m.addComponent(it) }
        // D1: I0(0¢)=DIME, I1(5¢)=OR(N,D), I2(10¢)=1, I3(dispense)=0
        m.addWire(b.wire(dime, 0, muxD1, 0))
        m.addWire(b.wire(orND, 0, muxD1, 1))
        m.addWire(b.wire(power, 0, muxD1, 2))
        m.addWire(b.wire(ground, 0, muxD1, 3))
        // D0: I0(0¢)=N·D', I1(5¢)=D+N', I2(10¢)=OR(N,D), I3(dispense)=0
        m.addWire(b.wire(andN_notD, 0, muxD0, 0))
        m.addWire(b.wire(orD_notN, 0, muxD0, 1))
        m.addWire(b.wire(orND, 0, muxD0, 2))
        m.addWire(b.wire(ground, 0, muxD0, 3))

        val ff1 = b.comp(ComponentType.D_FLIP_FLOP, 220f, -100f, "Q1")
        val ff0 = b.comp(ComponentType.D_FLIP_FLOP, 220f, 100f, "Q0")
        listOf(ff1, ff0).forEach { m.addComponent(it) }
        m.addWire(b.wire(muxD1, 0, ff1, 0))
        m.addWire(b.wire(muxD0, 0, ff0, 0))
        m.addWire(b.wire(step, 0, ff1, 1))
        m.addWire(b.wire(step, 0, ff0, 1))
        m.addWire(b.wire(ff0, 0, muxD1, 4)); m.addWire(b.wire(ff1, 0, muxD1, 5))
        m.addWire(b.wire(ff0, 0, muxD0, 4)); m.addWire(b.wire(ff1, 0, muxD0, 5))

        val decoder = b.comp(ComponentType.DECODER_2TO4, 380f, 0f)
        m.addComponent(decoder)
        m.addWire(b.wire(ff0, 0, decoder, 0))
        m.addWire(b.wire(ff1, 0, decoder, 1))
        val labels = listOf("0\u00A2", "5\u00A2", "10\u00A2", "DISPENSE")
        labels.forEachIndexed { i, label ->
            val led = b.comp(ComponentType.OUTPUT_LED, 560f, -150f + i * 100f, label)
            m.addComponent(led)
            m.addWire(b.wire(decoder, i, led, 0))
        }
    }

    private fun cpuBuildingBlocks() = circuit(
        title = "CPU Building Blocks",
        difficulty = Difficulty.ADVANCED,
        description = "Three of the fundamental pieces a CPU is built from, side by side: a Program Counter that auto-advances, a Decoder that turns its address into an instruction-slot signal, and a Register that loads and holds a value — this is illustrative, not a complete working CPU.",
        howItWorks = "The Program Counter (top) is the same ripple-counter idea as the Binary Counter example, decoded into 4 'instruction slot' LEDs the way a real fetch stage would select the next instruction from memory. The Register (bottom) is the same one-clock-many-flip-flops idea as the Register example, standing in for a CPU's accumulator or general-purpose register. A real CPU wires an ALU between blocks like these — see the Simple 1-Bit ALU example for that piece."
    ) { m ->
        val b = Builder()

        // Program counter (2-bit) + instruction-slot decoder.
        val pcClock = b.comp(ComponentType.CLOCK, -320f, -220f, "CLK")
        val pcPower = b.comp(ComponentType.POWER, -320f, -140f, "T=1")
        listOf(pcClock, pcPower).forEach { m.addComponent(it) }
        val pc0 = b.comp(ComponentType.T_FLIP_FLOP, -140f, -220f, "PC0")
        val pc1 = b.comp(ComponentType.T_FLIP_FLOP, 0f, -220f, "PC1")
        listOf(pc0, pc1).forEach { m.addComponent(it) }
        m.addWire(b.wire(pcPower, 0, pc0, 0)); m.addWire(b.wire(pcPower, 0, pc1, 0))
        m.addWire(b.wire(pcClock, 0, pc0, 1))
        m.addWire(b.wire(pc0, 0, pc1, 1))

        val decoder = b.comp(ComponentType.DECODER_2TO4, 160f, -180f)
        m.addComponent(decoder)
        m.addWire(b.wire(pc0, 0, decoder, 0))
        m.addWire(b.wire(pc1, 0, decoder, 1))
        for (i in 0 until 4) {
            val led = b.comp(ComponentType.OUTPUT_LED, 340f + i * 80f, -220f, "Instr $i")
            m.addComponent(led)
            m.addWire(b.wire(decoder, i, led, 0))
        }

        // 4-bit accumulator register.
        val load = b.comp(ComponentType.PUSH_BUTTON, -320f, 60f, "LOAD (tap)")
        m.addComponent(load)
        for (i in 0 until 4) {
            val y = 140f + i * 100f
            val data = b.comp(ComponentType.INPUT_SWITCH, -320f, y, "D$i")
            val ff = b.comp(ComponentType.D_FLIP_FLOP, -100f, y)
            val led = b.comp(ComponentType.OUTPUT_LED, 100f, y, "ACC$i")
            listOf(data, ff, led).forEach { m.addComponent(it) }
            m.addWire(b.wire(data, 0, ff, 0))
            m.addWire(b.wire(load, 0, ff, 1))
            m.addWire(b.wire(ff, 0, led, 0))
        }
    }
}
