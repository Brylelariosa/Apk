package com.circuitsandbox.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Region
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.circuitsandbox.app.model.AlignmentType
import com.circuitsandbox.app.model.CircuitModel
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.model.DistributeAxis
import com.circuitsandbox.app.model.WireEndpoint
import com.circuitsandbox.app.model.WireInstance
import com.circuitsandbox.app.render.CircuitTheme
import com.circuitsandbox.app.render.GateRenderer
import com.circuitsandbox.app.render.GridRenderer
import com.circuitsandbox.app.render.WireRenderer
import com.circuitsandbox.app.simulation.CircuitPinStates
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sqrt

/** How a drag starting on empty canvas selects multiple objects. */
enum class SelectionMode { BOX, LASSO }

/**
 * The infinite pan/zoom canvas — the heart of the app.
 *
 * All drawing is procedural (Path/Canvas primitives only, never bitmaps),
 * so components stay crisp at any zoom level. Per-frame work only ever
 * touches components inside the current viewport — both hit-testing and
 * render culling are backed by [CircuitModel]'s spatial grid index rather
 * than a linear scan — which keeps frame time roughly constant regardless
 * of how large the overall circuit is.
 *
 * This view never mutates [circuit] for anything the user should be able
 * to undo on its own — single add/move/remove actions and reconnects are
 * still reported individually through [listener] exactly as before; bulk
 * actions (paste, duplicate, multi-delete) go through dedicated bulk
 * callbacks so the host can collapse them into one undo step.
 */
class CircuitCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var circuit: CircuitModel = CircuitModel()
    var theme: CircuitTheme = CircuitTheme.DARK
    var listener: CircuitInteractionListener? = null

    /** Live pin state for the whole circuit, refreshed once per frame by
     * the host from two batched native reads. Never mutated mid-draw. */
    var pinStates: CircuitPinStates = CircuitPinStates.EMPTY
    var floatingComponentIds: Set<Int> = emptySet()
    var oscillatingComponentIds: Set<Int> = emptySet()
    var shortCircuitWireIds: Set<Int> = emptySet()
    var simulationRunning: Boolean = false

    var snapToGridEnabled: Boolean = true
    var selectionMode: SelectionMode = SelectionMode.BOX
    var minimapEnabled: Boolean = true

    var pendingPlacementType: ComponentType? = null
        set(value) {
            field = value
            selection.clear()
            selectedWireIds.clear()
            invalidate()
        }

    private val density = context.resources.displayMetrics.density

    private var offsetX = 0f
    private var offsetY = 0f
    private var scale = 1f
    private val minScale = 0.15f
    private val maxScale = 4f

    private val selection = mutableSetOf<Int>()
    private val selectedWireIds = mutableSetOf<Int>()

    private var dragCandidateId: Int? = null
    private var isDraggingComponent = false
    private var dragStartWorldX = 0f
    private var dragStartWorldY = 0f
    private var dragOriginalX = 0f
    private var dragOriginalY = 0f
    private var groupDragOriginals: Map<Int, Pair<Float, Float>> = emptyMap()

    private var wireDragStart: Pair<Int, Int>? = null // (componentId, outputPinIndex)
    private var wireDragCurrentWorld: Pair<Float, Float>? = null
    private var reconnectingWireId: Int? = null

    private var selectionBoxStart: Pair<Float, Float>? = null
    private var selectionBoxCurrent: Pair<Float, Float>? = null
    private var lassoPoints: MutableList<Pair<Float, Float>>? = null

    private var eraseModeActive = false

    private var clipboardComponents: List<ComponentInstance> = emptyList()
    private var clipboardWires: List<WireInstance> = emptyList()

    private var animationPhase = 0f

    // --- Minimap ------------------------------------------------------------
    private var minimapRect: RectF? = null
    private var minimapContentBounds: FloatArray? = null // [minX, minY, maxX, maxY]
    private var minimapDragActive = false

    // --- Touch-target sizing -------------------------------------------------
    // Pin/wire hit radii are expressed in dp and converted through both
    // density and the current zoom level, so the *physical* touch target
    // stays a constant, comfortable size on screen no matter how far the
    // user has zoomed in or out — fixing the original world-space-constant
    // radius, which made pins effectively harder to hit when zoomed out.
    private fun dpToWorld(dp: Float): Float = (dp * density) / scale
    private fun pinSnapRadius(): Float = dpToWorld(24f)
    private fun pinHighlightRadius(): Float = dpToWorld(34f)
    private fun wireHitTolerance(): Float = dpToWorld(16f)
    private fun touchSlop(): Float = dpToWorld(6f)

    private val wireDragPreviewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dashEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
    private val pinHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val selectionOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val lassoFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val minimapBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val minimapBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
    private val minimapDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val minimapViewportPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f }

    // Tracks the pinch/pan focus point between successive onScale callbacks
    // so a two-finger gesture can zoom AND pan in the same motion — see
    // onScale() for why this single formula covers both cases.
    private var lastFocusX = 0f
    private var lastFocusY = 0f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            lastFocusX = detector.focusX
            lastFocusY = detector.focusY
            // A second finger just joined the touch stream: whatever
            // single-pointer gesture was in progress (component drag, wire
            // drag, box/lasso select) is no longer a valid interpretation
            // of what the user is doing, and letting it keep running while
            // a pinch/pan also processes the same pointers is exactly what
            // caused components to "jump" when a second finger touched
            // down mid-drag. Cancel it cleanly instead.
            cancelSinglePointerGestures()
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val previousScale = scale
            scale = (scale * detector.scaleFactor).coerceIn(minScale, maxScale)
            val factor = scale / previousScale
            // Generalized zoom-to-focus that also accounts for the focus
            // point itself having moved since the last callback — which is
            // exactly what a two-finger pan is. When scaleFactor == 1 this
            // reduces to a pure translation by the focus delta; when the
            // focus doesn't move it reduces to the original zoom-in-place
            // formula. Previously this only used the current frame's focus
            // for both terms, which mathematically cancelled out any pan
            // component and made two-finger panning a no-op.
            offsetX = detector.focusX - (lastFocusX - offsetX) * factor
            offsetY = detector.focusY - (lastFocusY - offsetY) * factor
            lastFocusX = detector.focusX
            lastFocusY = detector.focusY
            invalidate()
            return true
        }
    })

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            val noOtherGestureActive = dragCandidateId == null && wireDragStart == null &&
                selectionBoxStart == null && lassoPoints == null && !eraseModeActive
            if (noOtherGestureActive) {
                offsetX -= dx
                offsetY -= dy
                invalidate()
                return true
            }
            return false
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            handleTap(e.x, e.y)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            handleLongPress(e.x, e.y)
        }
    })

    init {
        isClickable = true
        isFocusable = true
    }

    private fun cancelSinglePointerGestures() {
        dragCandidateId = null
        isDraggingComponent = false
        wireDragStart = null
        wireDragCurrentWorld = null
        reconnectingWireId = null
        selectionBoxStart = null
        selectionBoxCurrent = null
        lassoPoints = null
    }

    // --- Public API used by MainActivity --------------------------------

    fun screenToWorld(screenX: Float, screenY: Float): Pair<Float, Float> =
        ((screenX - offsetX) / scale) to ((screenY - offsetY) / scale)

    fun worldToScreen(worldX: Float, worldY: Float): Pair<Float, Float> =
        (worldX * scale + offsetX) to (worldY * scale + offsetY)

    fun centerOn(worldX: Float, worldY: Float) {
        offsetX = width / 2f - worldX * scale
        offsetY = height / 2f - worldY * scale
        invalidate()
    }

    /** Frames every placed component on screen with padding. A no-op
     * (just re-centers on the origin) on an empty circuit. */
    fun fitToScreen() {
        val components = circuit.allComponents
        if (components.isEmpty() || width == 0 || height == 0) {
            centerOn(0f, 0f)
            return
        }
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (c in components) {
            minX = min(minX, c.x - c.width); maxX = max(maxX, c.x + c.width)
            minY = min(minY, c.y - c.height); maxY = max(maxY, c.y + c.height)
        }
        val pad = 100f
        minX -= pad; minY -= pad; maxX += pad; maxY += pad
        val contentW = (maxX - minX).coerceAtLeast(1f)
        val contentH = (maxY - minY).coerceAtLeast(1f)
        scale = min(width / contentW, height / contentH).coerceIn(minScale, maxScale)
        offsetX = width / 2f - (minX + maxX) / 2f * scale
        offsetY = height / 2f - (minY + maxY) / 2f * scale
        invalidate()
    }

    /** Advances the wire-flow / LED-pulse animation by one frame. The host
     * drives this on a tick only while it's worth animating (simulation
     * running), to avoid burning battery redrawing a static circuit. */
    fun advanceAnimation() {
        animationPhase = (animationPhase + 0.01f) % 1f
        invalidate()
    }

    fun hasSelection(): Boolean = selection.isNotEmpty() || selectedWireIds.isNotEmpty()
    fun hasClipboard(): Boolean = clipboardComponents.isNotEmpty()
    fun selectedComponentCount(): Int = selection.size

    /** True only when every currently-selected component is locked — used
     * by the host to decide whether the contextual toolbar's lock button
     * should read as "Lock" or "Unlock". */
    fun isSelectionFullyLocked(): Boolean =
        selection.isNotEmpty() && selection.all { circuit.componentById(it)?.locked == true }

    /** True when every selected component already shares the *same* single
     * group — used by the host to decide whether tapping the group button
     * should Group (create a new group) or Ungroup (dissolve it). */
    fun isSelectionFullyGrouped(): Boolean {
        if (selection.isEmpty()) return false
        val groupIds = selection.map { circuit.componentById(it)?.groupId }
        val first = groupIds.firstOrNull() ?: return false
        return first != null && groupIds.all { it == first }
    }

    fun selectAll() {
        selection.clear(); selectedWireIds.clear()
        circuit.allComponents.forEach { selection.add(it.id) }
        circuit.allWires.forEach { selectedWireIds.add(it.id) }
        reportSelectionChanged()
        invalidate()
    }

    fun clearSelection() {
        if (!hasSelection()) return
        selection.clear(); selectedWireIds.clear()
        reportSelectionChanged()
        invalidate()
    }

    fun cancelPendingPlacement() {
        pendingPlacementType = null
    }

    private fun unlockedOnly(ids: Set<Int>): Set<Int> =
        ids.filterNot { circuit.componentById(it)?.locked == true }.toSet()

    fun deleteSelection() {
        if (!hasSelection()) return
        val deletableComponents = unlockedOnly(selection)
        listener?.onBulkDelete(deletableComponents, selectedWireIds.toSet())
        selection.clear(); selectedWireIds.clear()
        reportSelectionChanged()
        invalidate()
    }

    fun deleteAllWires() {
        val ids = circuit.allWires.map { it.id }.toSet()
        if (ids.isEmpty()) return
        listener?.onBulkDelete(emptySet(), ids)
        selectedWireIds.clear()
        invalidate()
    }

    fun deleteAllComponents() {
        val ids = unlockedOnly(circuit.allComponents.map { it.id }.toSet())
        if (ids.isEmpty()) return
        listener?.onBulkDelete(ids, emptySet())
        selection.clear()
        invalidate()
    }

    /** Defensive integrity cleanup: every [WireInstance] should already
     * reference two real components — [CircuitModel] cascades wire
     * removal whenever a component is deleted — so under normal use this
     * is a no-op. It exists to recover cleanly from a hand-edited or
     * otherwise corrupted save file that references a missing component. */
    fun deleteDisconnectedWires() {
        val orphaned = circuit.allWires.filter {
            circuit.componentById(it.from.componentId) == null || circuit.componentById(it.to.componentId) == null
        }.map { it.id }.toSet()
        if (orphaned.isNotEmpty()) listener?.onBulkDelete(emptySet(), orphaned)
        invalidate()
    }

    fun clearCanvas() {
        val componentIds = circuit.allComponents.map { it.id }.toSet()
        val wireIds = circuit.allWires.map { it.id }.toSet()
        if (componentIds.isEmpty() && wireIds.isEmpty()) return
        listener?.onBulkDelete(componentIds, wireIds)
        selection.clear(); selectedWireIds.clear()
        invalidate()
    }

    fun rotateSelection() {
        val ids = unlockedOnly(selection)
        if (ids.isEmpty()) return
        listener?.onRotateRequested(ids)
        invalidate()
    }

    fun mirrorSelection() {
        val ids = unlockedOnly(selection)
        if (ids.isEmpty()) return
        listener?.onMirrorRequested(ids)
        invalidate()
    }

    fun lockSelection(locked: Boolean) {
        if (selection.isEmpty()) return
        listener?.onLockToggleRequested(selection.toSet(), locked)
        invalidate()
    }

    /** Groups need at least two components — grouping a single component
     * (or nothing) wouldn't do anything, so those calls are silently
     * ignored rather than sending an empty/no-op command through undo. */
    fun groupSelection() {
        val ids = unlockedOnly(selection)
        if (ids.size < 2) return
        listener?.onGroupRequested(ids)
    }

    fun ungroupSelection() {
        if (selection.isEmpty()) return
        listener?.onUngroupRequested(selection.toSet())
    }

    fun alignSelection(alignment: AlignmentType) {
        val ids = unlockedOnly(selection)
        if (ids.size < 2) return
        listener?.onAlignRequested(ids, alignment)
        invalidate()
    }

    fun distributeSelection(axis: DistributeAxis) {
        val ids = unlockedOnly(selection)
        if (ids.size < 3) return
        listener?.onDistributeRequested(ids, axis)
        invalidate()
    }

    fun copySelection() {
        if (selection.isEmpty()) return
        clipboardComponents = selection.mapNotNull { circuit.componentById(it) }.map { it.copy(locked = false, groupId = null) }
        clipboardWires = circuit.allWires.filter {
            it.from.componentId in selection && it.to.componentId in selection
        }
    }

    fun duplicateSelection() {
        if (selection.isEmpty()) return
        copySelection()
        pasteClipboard()
    }

    /** Pastes the current clipboard offset from its original position, so
     * the copy is never placed exactly on top of the original. */
    fun pasteClipboard() {
        if (clipboardComponents.isEmpty()) return
        val offset = 40f
        val idRemap = HashMap<Int, Int>()
        val newComponents = clipboardComponents.map { original ->
            val newId = circuit.nextComponentId()
            idRemap[original.id] = newId
            original.copy(id = newId, x = original.x + offset, y = original.y + offset)
        }
        val newWires = clipboardWires.mapNotNull { original ->
            val newFrom = idRemap[original.from.componentId] ?: return@mapNotNull null
            val newTo = idRemap[original.to.componentId] ?: return@mapNotNull null
            WireInstance(
                circuit.nextWireId(),
                original.from.copy(componentId = newFrom),
                original.to.copy(componentId = newTo)
            )
        }
        listener?.onBulkAdd(newComponents, newWires)
        selection.clear(); selectedWireIds.clear()
        newComponents.forEach { selection.add(it.id) }
        reportSelectionChanged()
        invalidate()
    }

    // --- Touch handling ---------------------------------------------------

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (handleMinimapTouch(event)) return true

        scaleDetector.onTouchEvent(event)
        if (!scaleDetector.isInProgress) {
            gestureDetector.onTouchEvent(event)
        }

        // A second (or third) finger joining mid-gesture is handled by
        // scaleDetector/onScaleBegin above; here we only need to make sure
        // a *brand new* multi-finger touch sequence never gets fed into
        // the single-pointer DOWN handler as if it were a fresh tap.
        if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN) {
            cancelSinglePointerGestures()
            return true
        }

        val (worldX, worldY) = screenToWorld(event.x, event.y)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> if (event.pointerCount == 1) handleActionDown(worldX, worldY)
            MotionEvent.ACTION_MOVE -> if (event.pointerCount == 1) handleActionMove(worldX, worldY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handleActionUp(worldX, worldY)
        }
        return true
    }

    private fun handleActionDown(worldX: Float, worldY: Float) {
        pendingPlacementType?.let { type ->
            placeComponent(type, snap(worldX), snap(worldY))
            pendingPlacementType = null
            return
        }

        // 1) Start a brand-new wire from an output pin.
        findOutputPinNear(worldX, worldY)?.let { pin ->
            wireDragStart = pin
            reconnectingWireId = null
            return
        }

        // 2) Grab an existing wire's input endpoint to reconnect/detach it.
        findWireInputEndpointNear(worldX, worldY)?.let { (wire, sourceComponentId) ->
            wireDragStart = sourceComponentId to wire.from.pinIndex
            wireDragCurrentWorld = worldX to worldY
            reconnectingWireId = wire.id
            selection.clear(); selectedWireIds.clear()
            reportSelectionChanged()
            invalidate()
            return
        }

        // 3) Component tap/drag. Tapping a member of an existing multi-
        // selection keeps the whole selection (so it can be moved as a
        // group); tapping anything else collapses to a single selection
        // (auto-expanded to every sibling sharing the same group, if the
        // tapped component belongs to one). Locked components can still
        // be selected — e.g. to unlock them from the contextual bar — but
        // never start a drag.
        circuit.componentAt(worldX, worldY)?.let { component ->
            val keepExistingMultiSelection = selection.size > 1 && selection.contains(component.id) && selectedWireIds.isEmpty()
            if (!keepExistingMultiSelection) {
                selection.clear(); selectedWireIds.clear()
                selection.add(component.id)
                expandSelectionForGroups()
                reportSelectionChanged()
            }
            if (!component.locked) {
                dragCandidateId = component.id
                dragStartWorldX = worldX; dragStartWorldY = worldY
                dragOriginalX = component.x; dragOriginalY = component.y
                groupDragOriginals = selection.mapNotNull { id ->
                    circuit.componentById(id)?.takeIf { !it.locked }?.let { id to (it.x to it.y) }
                }.toMap()
            }
            invalidate()
            return
        }

        // 4) Wire-body tap (select a wire without dragging it).
        findWireNear(worldX, worldY)?.let { wire ->
            selection.clear(); selectedWireIds.clear()
            selectedWireIds.add(wire.id)
            reportSelectionChanged()
            invalidate()
            return
        }

        // 5) Nothing hit — begin a multi-select gesture.
        if (selectionMode == SelectionMode.BOX) {
            selectionBoxStart = worldX to worldY
            selectionBoxCurrent = worldX to worldY
        } else {
            lassoPoints = mutableListOf(worldX to worldY)
        }
    }

    /** Expands [selection] to include every component sharing a groupId
     * with anything already selected, so grouped components always move,
     * rotate, and mirror together once any one member is picked. */
    private fun expandSelectionForGroups() {
        val groupIds = selection.mapNotNull { circuit.componentById(it)?.groupId }.toHashSet()
        if (groupIds.isEmpty()) return
        for (component in circuit.allComponents) {
            val gid = component.groupId
            if (gid != null && gid in groupIds) selection.add(component.id)
        }
    }

    private fun handleActionMove(worldX: Float, worldY: Float) {
        if (eraseModeActive) {
            eraseAt(worldX, worldY)
            invalidate()
            return
        }

        if (wireDragStart != null) {
            wireDragCurrentWorld = worldX to worldY
            invalidate()
            return
        }

        val id = dragCandidateId
        if (id != null) {
            val component = circuit.componentById(id)
            if (component != null) {
                if (!isDraggingComponent) {
                    val slop = touchSlop()
                    val movedEnough = abs(worldX - dragStartWorldX) > slop || abs(worldY - dragStartWorldY) > slop
                    if (movedEnough) isDraggingComponent = true
                }
                if (isDraggingComponent) {
                    val dx = worldX - dragStartWorldX
                    val dy = worldY - dragStartWorldY
                    if (groupDragOriginals.size > 1) {
                        for ((compId, orig) in groupDragOriginals) {
                            circuit.componentById(compId)?.let {
                                it.x = snap(orig.first + dx)
                                it.y = snap(orig.second + dy)
                                circuit.notifyComponentMoved(compId)
                            }
                        }
                    } else {
                        component.x = snap(dragOriginalX + dx)
                        component.y = snap(dragOriginalY + dy)
                        circuit.notifyComponentMoved(id)
                    }
                    invalidate()
                }
            }
            return
        }

        if (selectionBoxStart != null) {
            selectionBoxCurrent = worldX to worldY
            invalidate()
            return
        }

        lassoPoints?.let {
            it.add(worldX to worldY)
            invalidate()
        }
    }

    private fun handleActionUp(worldX: Float, worldY: Float) {
        if (eraseModeActive) {
            eraseModeActive = false
            return
        }

        wireDragStart?.let { (fromId, fromPin) ->
            val targetPin = findInputPinNear(worldX, worldY)
            val oldWireId = reconnectingWireId
            if (targetPin != null) {
                val (toId, toPin) = targetPin
                val newWire = WireInstance(
                    circuit.nextWireId(),
                    WireEndpoint(fromId, fromPin, isInput = false),
                    WireEndpoint(toId, toPin, isInput = true)
                )
                val oldWire = oldWireId?.let { circuit.wireById(it) }
                if (oldWire != null) {
                    listener?.onWireReconnected(oldWire, newWire)
                } else {
                    listener?.onWireAdded(newWire)
                }
            } else if (oldWireId != null) {
                // Dropped on empty space while reconnecting — that
                // disconnects it, matching the "drag a wire away to
                // remove it" gesture from desktop circuit editors.
                circuit.wireById(oldWireId)?.let { listener?.onWireRemoved(it) }
            }
            wireDragStart = null
            wireDragCurrentWorld = null
            reconnectingWireId = null
            invalidate()
        }

        dragCandidateId?.let { id ->
            if (isDraggingComponent) {
                if (groupDragOriginals.size > 1) {
                    // One undo entry per moved component — slightly more
                    // granular than a single combined step, but it keeps
                    // the listener interface unchanged and undo still
                    // fully reverses the group move if pressed enough times.
                    for ((compId, orig) in groupDragOriginals) {
                        val comp = circuit.componentById(compId)
                        if (comp != null) {
                            listener?.onComponentMoved(compId, orig.first, orig.second, comp.x, comp.y)
                        }
                    }
                } else {
                    val component = circuit.componentById(id)
                    if (component != null) {
                        listener?.onComponentMoved(id, dragOriginalX, dragOriginalY, component.x, component.y)
                    }
                }
            }
        }
        dragCandidateId = null
        isDraggingComponent = false

        selectionBoxStart?.let { (sx, sy) ->
            val (cx, cy) = selectionBoxCurrent ?: (sx to sy)
            val left = min(sx, cx); val right = max(sx, cx)
            val top = min(sy, cy); val bottom = max(sy, cy)
            if (abs(right - left) > 6f || abs(bottom - top) > 6f) {
                selection.clear()
                circuit.componentsInRect(left, top, right, bottom).forEach { selection.add(it.id) }
                expandSelectionForGroups()
                selectWiresBetweenSelectedComponents()
                reportSelectionChanged()
            }
            selectionBoxStart = null
            selectionBoxCurrent = null
            invalidate()
        }

        lassoPoints?.let { finishLassoSelection(it) }
    }

    private fun handleTap(screenX: Float, screenY: Float) {
        val (worldX, worldY) = screenToWorld(screenX, screenY)
        val component = circuit.componentAt(worldX, worldY) ?: return
        if (simulationRunning &&
            (component.type == ComponentType.INPUT_SWITCH || component.type == ComponentType.PUSH_BUTTON)
        ) {
            listener?.onSwitchToggled(component.id)
            invalidate()
        }
    }

    private fun handleLongPress(screenX: Float, screenY: Float) {
        val (worldX, worldY) = screenToWorld(screenX, screenY)
        eraseModeActive = true
        dragCandidateId = null
        isDraggingComponent = false
        wireDragStart = null
        wireDragCurrentWorld = null
        reconnectingWireId = null
        selectionBoxStart = null
        selectionBoxCurrent = null
        lassoPoints = null
        eraseAt(worldX, worldY)
        invalidate()
    }

    private fun eraseAt(worldX: Float, worldY: Float) {
        circuit.componentAt(worldX, worldY)?.let {
            if (it.locked) return
            listener?.onComponentRemoved(it)
            return
        }
        findWireNear(worldX, worldY)?.let {
            listener?.onWireRemoved(it)
        }
    }

    private fun placeComponent(type: ComponentType, x: Float, y: Float) {
        val component = ComponentInstance(circuit.nextComponentId(), type, x, y)
        listener?.onComponentAdded(component)
        selection.clear(); selectedWireIds.clear()
        selection.add(component.id)
        reportSelectionChanged()
        invalidate()
    }

    private fun snap(value: Float): Float {
        if (!snapToGridEnabled) return value
        val gridSize = 20f
        return round(value / gridSize) * gridSize
    }

    private fun reportSelectionChanged() {
        listener?.onSelectionChanged(selection.toSet(), selectedWireIds.toSet())
    }

    /** After a box/lasso pass picks components, also select any wire
     * whose *both* endpoints landed inside the same selection — this is
     * what lets a drag-select sweep up wires, not just components. */
    private fun selectWiresBetweenSelectedComponents() {
        selectedWireIds.clear()
        for (wire in circuit.allWires) {
            if (wire.from.componentId in selection && wire.to.componentId in selection) {
                selectedWireIds.add(wire.id)
            }
        }
    }

    private fun finishLassoSelection(points: List<Pair<Float, Float>>) {
        lassoPoints = null
        if (points.size < 3) { invalidate(); return }

        val path = Path()
        path.moveTo(points[0].first, points[0].second)
        for (i in 1 until points.size) path.lineTo(points[i].first, points[i].second)
        path.close()

        val bounds = RectF()
        path.computeBounds(bounds, true)
        val clip = Region(
            floor(bounds.left).toInt() - 1, floor(bounds.top).toInt() - 1,
            ceil(bounds.right).toInt() + 1, ceil(bounds.bottom).toInt() + 1
        )
        val pathRegion = Region()
        pathRegion.setPath(path, clip)

        selection.clear()
        // Pre-filtered to only the components whose center could possibly
        // fall inside the lasso's bounding box, instead of testing every
        // component in the circuit against the region.
        for (component in circuit.componentsInRect(bounds.left, bounds.top, bounds.right, bounds.bottom)) {
            if (pathRegion.contains(component.x.toInt(), component.y.toInt())) {
                selection.add(component.id)
            }
        }
        expandSelectionForGroups()
        selectWiresBetweenSelectedComponents()
        reportSelectionChanged()
        invalidate()
    }

    // --- Hit-testing --------------------------------------------------------
    // Pin/wire lookups first narrow candidates down with the spatial index
    // (a generous margin around the touch point covers the largest
    // possible component so no true match is ever missed) before checking
    // individual pins, instead of scanning every component in the circuit
    // on every touch-down.

    private fun nearbyComponents(worldX: Float, worldY: Float, radius: Float) =
        circuit.componentsInRect(worldX - radius - 120f, worldY - radius - 120f, worldX + radius + 120f, worldY + radius + 120f)

    private fun findOutputPinNear(worldX: Float, worldY: Float): Pair<Int, Int>? {
        val radius = pinSnapRadius()
        var best: Pair<Int, Int>? = null
        var bestDist = Float.MAX_VALUE
        for (component in nearbyComponents(worldX, worldY, radius)) {
            for (i in 0 until component.type.outputCount) {
                val (px, py) = component.outputPinWorldPosition(i)
                val d = distance(px, py, worldX, worldY)
                if (d <= radius && d < bestDist) { bestDist = d; best = component.id to i }
            }
        }
        return best
    }

    private fun findInputPinNear(worldX: Float, worldY: Float): Pair<Int, Int>? {
        val radius = pinSnapRadius()
        var best: Pair<Int, Int>? = null
        var bestDist = Float.MAX_VALUE
        for (component in nearbyComponents(worldX, worldY, radius)) {
            for (i in 0 until component.type.inputCount) {
                val (px, py) = component.inputPinWorldPosition(i)
                val d = distance(px, py, worldX, worldY)
                if (d <= radius && d < bestDist) { bestDist = d; best = component.id to i }
            }
        }
        return best
    }

    /** Finds an existing wire whose *input* endpoint is near the touch
     * point, returning the wire and the component id at its *output*
     * end — so the caller can continue the gesture exactly as if a fresh
     * wire-drag had started from that same output pin. */
    private fun findWireInputEndpointNear(worldX: Float, worldY: Float): Pair<WireInstance, Int>? {
        val radius = pinSnapRadius()
        for (wire in circuit.allWires) {
            val to = circuit.componentById(wire.to.componentId) ?: continue
            val (px, py) = to.inputPinWorldPosition(wire.to.pinIndex)
            if (distance(px, py, worldX, worldY) <= radius) {
                return wire to wire.from.componentId
            }
        }
        return null
    }

    private fun wireMinStub(from: ComponentInstance, to: ComponentInstance): Float =
        maxOf(18f, from.width / 2f + 8f, to.width / 2f + 8f)

    private fun findWireNear(worldX: Float, worldY: Float): WireInstance? {
        val tolerance = wireHitTolerance()
        var closest: WireInstance? = null
        var closestDist = Float.MAX_VALUE
        for (wire in circuit.allWires) {
            val from = circuit.componentById(wire.from.componentId) ?: continue
            val to = circuit.componentById(wire.to.componentId) ?: continue
            val (sx, sy) = from.outputPinWorldPosition(wire.from.pinIndex)
            val (ex, ey) = to.inputPinWorldPosition(wire.to.pinIndex)
            val vertices = WireRenderer.routeVertices(sx, sy, ex, ey, wireMinStub(from, to))
            for (i in 0 until vertices.size - 1) {
                val (ax, ay) = vertices[i]
                val (bx, by) = vertices[i + 1]
                val d = distanceToSegment(worldX, worldY, ax, ay, bx, by)
                if (d < tolerance && d < closestDist) {
                    closestDist = d
                    closest = wire
                }
            }
        }
        return closest
    }

    private fun distanceToSegment(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1; val dy = y2 - y1
        val lengthSq = dx * dx + dy * dy
        if (lengthSq < 0.0001f) return distance(px, py, x1, y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lengthSq).coerceIn(0f, 1f)
        return distance(px, py, x1 + t * dx, y1 + t * dy)
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2; val dy = y1 - y2
        return sqrt(dx * dx + dy * dy)
    }

    // --- Drawing -------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(theme.canvasBackground)

        val topLeft = screenToWorld(0f, 0f)
        val bottomRight = screenToWorld(width.toFloat(), height.toFloat())

        canvas.save()
        canvas.translate(offsetX, offsetY)
        canvas.scale(scale, scale)

        GridRenderer.draw(canvas, theme, scale, topLeft.first, topLeft.second, bottomRight.first, bottomRight.second)

        val margin = 200f
        val visibleComponents = circuit.componentsInRect(
            topLeft.first - margin, topLeft.second - margin,
            bottomRight.first + margin, bottomRight.second + margin
        )
        val visibleIds = visibleComponents.map { it.id }.toSet()

        for (wire in circuit.allWires) {
            val from = circuit.componentById(wire.from.componentId) ?: continue
            val to = circuit.componentById(wire.to.componentId) ?: continue
            if (wire.from.componentId !in visibleIds && wire.to.componentId !in visibleIds) continue
            val isHigh = pinStates.outputAt(wire.from.componentId, wire.from.pinIndex)
            WireRenderer.draw(
                canvas, wire, from, to, theme,
                isHigh = isHigh,
                hasError = wire.id in shortCircuitWireIds,
                isSelected = wire.id in selectedWireIds,
                animationPhase = animationPhase
            )
        }

        drawWireDragPreview(canvas)

        for (component in visibleComponents) {
            val hasError = component.id in floatingComponentIds || component.id in oscillatingComponentIds
            val connectedInputPins = if (hasError) {
                circuit.wiresConnectedTo(component.id)
                    .filter { it.to.componentId == component.id }
                    .map { it.to.pinIndex }
                    .toHashSet()
            } else null
            GateRenderer.draw(
                canvas, component, theme, pinStates,
                isSelected = component.id in selection,
                hasError = hasError,
                animationPhase = animationPhase,
                connectedInputPins = connectedInputPins
            )
        }

        canvas.restore()

        drawSelectionGesturePreview(canvas)
        if (minimapEnabled) drawMinimap(canvas) else { minimapRect = null }
    }

    private fun drawWireDragPreview(canvas: Canvas) {
        val (fromId, fromPin) = wireDragStart ?: return
        val from = circuit.componentById(fromId) ?: return
        val target = wireDragCurrentWorld ?: return
        val (sx, sy) = from.outputPinWorldPosition(fromPin)

        // Highlight every nearby compatible input pin so the user can see
        // where a connection will land before lifting their finger, and
        // find the single nearest one within actual snap range.
        val highlightR = pinHighlightRadius()
        val snapR = pinSnapRadius()
        var nearestX = target.first
        var nearestY = target.second
        var nearestDist = Float.MAX_VALUE
        var hasSnapTarget = false

        for (component in nearbyComponents(target.first, target.second, highlightR)) {
            if (component.id == fromId) continue
            for (i in 0 until component.type.inputCount) {
                val (px, py) = component.inputPinWorldPosition(i)
                val d = distance(px, py, target.first, target.second)
                if (d > highlightR) continue
                pinHighlightPaint.color = theme.selectionHighlight
                pinHighlightPaint.alpha = if (d <= snapR) 255 else 110
                canvas.drawCircle(px, py, 10f, pinHighlightPaint)
                if (d <= snapR && d < nearestDist) {
                    nearestDist = d
                    nearestX = px; nearestY = py
                    hasSnapTarget = true
                }
            }
        }

        wireDragPreviewPaint.color = theme.selectionHighlight
        if (hasSnapTarget) {
            wireDragPreviewPaint.pathEffect = null
            wireDragPreviewPaint.strokeWidth = 4.5f
        } else {
            wireDragPreviewPaint.pathEffect = dashEffect
            wireDragPreviewPaint.strokeWidth = 3f
        }
        val endX = if (hasSnapTarget) nearestX else target.first
        val endY = if (hasSnapTarget) nearestY else target.second
        canvas.drawLine(sx, sy, endX, endY, wireDragPreviewPaint)
    }

    private fun drawSelectionGesturePreview(canvas: Canvas) {
        selectionBoxStart?.let { (sx, sy) ->
            val (cx, cy) = selectionBoxCurrent ?: (sx to sy)
            val (screenSX, screenSY) = worldToScreen(sx, sy)
            val (screenCX, screenCY) = worldToScreen(cx, cy)
            selectionOutlinePaint.color = theme.selectionHighlight
            canvas.drawRect(
                min(screenSX, screenCX), min(screenSY, screenCY),
                max(screenSX, screenCX), max(screenSY, screenCY),
                selectionOutlinePaint
            )
            return
        }

        val points = lassoPoints ?: return
        if (points.size < 2) return
        val path = Path()
        val (startX, startY) = worldToScreen(points[0].first, points[0].second)
        path.moveTo(startX, startY)
        for (i in 1 until points.size) {
            val (sx, sy) = worldToScreen(points[i].first, points[i].second)
            path.lineTo(sx, sy)
        }
        lassoFillPaint.color = theme.selectionHighlight
        lassoFillPaint.alpha = 40
        canvas.drawPath(path, lassoFillPaint)
        selectionOutlinePaint.color = theme.selectionHighlight
        canvas.drawPath(path, selectionOutlinePaint)
    }

    // --- Minimap --------------------------------------------------------------

    private fun drawMinimap(canvas: Canvas) {
        val bounds = circuit.approximateContentBounds()
        if (bounds == null || width == 0 || height == 0) { minimapRect = null; return }

        val sizePx = 120f * density
        val marginPx = 12f * density
        val rect = RectF(width - sizePx - marginPx, marginPx, width - marginPx, marginPx + sizePx)
        minimapRect = rect
        minimapContentBounds = bounds

        minimapBgPaint.color = theme.componentFill
        minimapBgPaint.alpha = 230
        canvas.drawRoundRect(rect, 10f, 10f, minimapBgPaint)
        minimapBorderPaint.color = theme.componentOutline
        canvas.drawRoundRect(rect, 10f, 10f, minimapBorderPaint)

        val (minX, minY, maxX, maxY) = bounds
        val contentW = (maxX - minX).coerceAtLeast(1f)
        val contentH = (maxY - minY).coerceAtLeast(1f)
        val pad = sizePx * 0.08f
        val innerScale = min((rect.width() - pad * 2) / contentW, (rect.height() - pad * 2) / contentH)

        fun toMinimap(wx: Float, wy: Float): Pair<Float, Float> =
            (rect.left + pad + (wx - minX) * innerScale) to (rect.top + pad + (wy - minY) * innerScale)

        minimapDotPaint.color = theme.componentOutline
        for (component in circuit.allComponents) {
            val (mx, my) = toMinimap(component.x, component.y)
            canvas.drawCircle(mx, my, 2f, minimapDotPaint)
        }

        val viewTopLeft = screenToWorld(0f, 0f)
        val viewBottomRight = screenToWorld(width.toFloat(), height.toFloat())
        val (vx1, vy1) = toMinimap(viewTopLeft.first, viewTopLeft.second)
        val (vx2, vy2) = toMinimap(viewBottomRight.first, viewBottomRight.second)
        minimapViewportPaint.color = theme.selectionHighlight
        canvas.drawRect(
            vx1.coerceIn(rect.left, rect.right), vy1.coerceIn(rect.top, rect.bottom),
            vx2.coerceIn(rect.left, rect.right), vy2.coerceIn(rect.top, rect.bottom),
            minimapViewportPaint
        )
    }

    private operator fun FloatArray.component1() = this[0]
    private operator fun FloatArray.component2() = this[1]
    private operator fun FloatArray.component3() = this[2]
    private operator fun FloatArray.component4() = this[3]

    /** Intercepts touches inside the minimap before any other gesture
     * processing sees them, so tapping or dragging inside it re-centers
     * the main viewport instead of being interpreted as a canvas gesture. */
    private fun handleMinimapTouch(event: MotionEvent): Boolean {
        if (!minimapEnabled) return false
        val rect = minimapRect ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (rect.contains(event.x, event.y)) {
                    minimapDragActive = true
                    navigateFromMinimap(event.x, event.y)
                    return true
                }
            }
            MotionEvent.ACTION_MOVE -> if (minimapDragActive) {
                navigateFromMinimap(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (minimapDragActive) {
                minimapDragActive = false
                return true
            }
        }
        return false
    }

    private fun navigateFromMinimap(screenX: Float, screenY: Float) {
        val rect = minimapRect ?: return
        val bounds = minimapContentBounds ?: return
        val (minX, minY, maxX, maxY) = bounds
        val fx = ((screenX - rect.left) / rect.width()).coerceIn(0f, 1f)
        val fy = ((screenY - rect.top) / rect.height()).coerceIn(0f, 1f)
        val worldX = minX + fx * (maxX - minX)
        val worldY = minY + fy * (maxY - minY)
        centerOn(worldX, worldY)
    }
}
