package com.circuitsandbox.app.simulation

/**
 * Thin JNI wrapper around the native `circuitcore` simulation engine.
 *
 * Every circuit lives entirely in native memory for performance reasons —
 * this class only ever crosses the JNI boundary with primitives and
 * primitive arrays, never per-frame object allocations, so simulation
 * stays cheap even as circuits grow large.
 */
class NativeSimulation {

    private var handle: Long = 0L

    init {
        handle = nativeCreate()
    }

    fun addGate(id: Int, type: Int, numInputs: Int, numOutputs: Int): Int =
        nativeAddGate(handle, id, type, numInputs, numOutputs)

    fun removeGate(gateId: Int) = nativeRemoveGate(handle, gateId)

    fun connect(fromGate: Int, fromPin: Int, toGate: Int, toPin: Int): Boolean =
        nativeConnect(handle, fromGate, fromPin, toGate, toPin)

    fun disconnect(fromGate: Int, fromPin: Int, toGate: Int, toPin: Int) =
        nativeDisconnect(handle, fromGate, fromPin, toGate, toPin)

    fun setManualState(gateId: Int, state: Boolean) = nativeSetManualState(handle, gateId, state)

    fun setClockHalfPeriod(gateId: Int, ticks: Int) = nativeSetClockPeriod(handle, gateId, ticks)

    fun outputState(gateId: Int, pinIndex: Int): Boolean = nativeOutputState(handle, gateId, pinIndex)

    /** Batched read used by the renderer once per frame instead of one JNI call per gate. */
    fun outputsFor(gateIds: IntArray, pinIndices: IntArray): BooleanArray =
        nativeGetOutputs(handle, gateIds, pinIndices)

    fun inputState(gateId: Int, pinIndex: Int): Boolean = nativeInputState(handle, gateId, pinIndex)

    /** Same as [outputsFor] but reads input-pin state — needed for sink-only
     * components (zero output pins) such as the LED, whose visible "lit"
     * state lives on its input pin rather than an output pin. */
    fun inputsFor(gateIds: IntArray, pinIndices: IntArray): BooleanArray =
        nativeGetInputs(handle, gateIds, pinIndices)

    fun step(maxIterations: Int = 64): StepReport {
        val packed = nativeStep(handle, maxIterations)
        if (packed.isEmpty()) return StepReport()
        var i = 0
        val hasOscillation = packed[i++] == 1
        val hasFloatingInput = packed[i++] == 1
        val hasShortCircuit = packed[i++] == 1
        val oscillatingCount = packed[i++]
        val oscillating = IntArray(oscillatingCount) { packed[i + it] }
        i += oscillatingCount
        val floatingCount = packed[i++]
        val floating = IntArray(floatingCount) { packed[i + it] }
        i += floatingCount
        val shortCircuitPairCount = packed[i++]
        val shortCircuitPins = ArrayList<Pair<Int, Int>>(shortCircuitPairCount)
        repeat(shortCircuitPairCount) {
            val gateId = packed[i++]
            val pinIndex = packed[i++]
            shortCircuitPins.add(gateId to pinIndex)
        }
        return StepReport(hasOscillation, hasFloatingInput, hasShortCircuit, oscillating, floating, shortCircuitPins)
    }

    fun reset() = nativeReset(handle)

    /** Must be called when the owning controller is done with this circuit,
     * or the native engine instance leaks for the lifetime of the process. */
    fun release() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    class StepReport(
        val hasOscillation: Boolean = false,
        val hasFloatingInput: Boolean = false,
        val hasShortCircuit: Boolean = false,
        val oscillatingGateIds: IntArray = IntArray(0),
        val floatingInputGateIds: IntArray = IntArray(0),
        /** Each pair is (gateId, inputPinIndex) for an input pin currently
         * driven by two or more conflicting wires. */
        val shortCircuitGatePins: List<Pair<Int, Int>> = emptyList()
    )

    private external fun nativeCreate(): Long
    private external fun nativeDestroy(handle: Long)
    private external fun nativeAddGate(handle: Long, id: Int, type: Int, numInputs: Int, numOutputs: Int): Int
    private external fun nativeRemoveGate(handle: Long, gateId: Int)
    private external fun nativeConnect(handle: Long, fromGate: Int, fromPin: Int, toGate: Int, toPin: Int): Boolean
    private external fun nativeDisconnect(handle: Long, fromGate: Int, fromPin: Int, toGate: Int, toPin: Int)
    private external fun nativeSetManualState(handle: Long, gateId: Int, state: Boolean)
    private external fun nativeSetClockPeriod(handle: Long, gateId: Int, halfPeriodTicks: Int)
    private external fun nativeOutputState(handle: Long, gateId: Int, pinIndex: Int): Boolean
    private external fun nativeGetOutputs(handle: Long, gateIds: IntArray, pinIndices: IntArray): BooleanArray
    private external fun nativeInputState(handle: Long, gateId: Int, pinIndex: Int): Boolean
    private external fun nativeGetInputs(handle: Long, gateIds: IntArray, pinIndices: IntArray): BooleanArray
    private external fun nativeStep(handle: Long, maxIterations: Int): IntArray
    private external fun nativeReset(handle: Long)

    companion object {
        init {
            System.loadLibrary("circuitcore")
        }
    }
}
