#pragma once
#include "Tensor.h"
#include "ThreadPool.h"

namespace novallm {

// 2D matrix helpers built on top of Tensor.
// Convention: Tensor with shape {rows, cols}, row-major.
// These are naive O(n^3) / O(n^2) reference implementations.
// Correctness first - blocking/SIMD/NEON come later as their own pass.
namespace matrix {

// C = A * B, A is {m,k}, B is {k,n}, C is {m,n}. Uses ThreadPool::shared()
// internally (see the (a, b, pool) overload below) - transparent to every
// existing caller, same result either way (see that overload's comment
// for why it's bit-exact, not an approximation).
Tensor matmul(const Tensor& a, const Tensor& b);

// Same as matmul(a, b), but against an explicit pool instead of the
// process-wide shared() one. Exists mainly so tests can force a
// multi-worker pool and exercise the actual parallel path even on a
// single-core machine (see ThreadPool's constructor comment) - any
// caller that genuinely needs a specific pool can use this directly too.
Tensor matmul(const Tensor& a, const Tensor& b, ThreadPool& pool);

// C = A + B (elementwise, same shape)
Tensor add(const Tensor& a, const Tensor& b);

// Add a bias vector (size == cols) to every row of A ({rows, cols})
Tensor addBias(const Tensor& a, const Tensor& bias);

// B = A^T
Tensor transpose(const Tensor& a);

// C = A * scalar
Tensor scale(const Tensor& a, float scalar);

// Numerically-stable row-wise softmax, in place: each row of x ({rows,
// cols}) becomes its own softmax distribution. Shared by attention
// (attention-weight rows) and, later, the decoder's output logits.
void softmaxRows(Tensor& x);

// Extracts columns [startCol, startCol+numCols) from a ({rows, colsA}).
Tensor sliceColumns(const Tensor& a, int startCol, int numCols);

// Writes src ({rows, numCols}) into dst's columns [startCol, ...), in place.
void setColumns(Tensor& dst, int startCol, const Tensor& src);

// True if this build was compiled with NEON acceleration for matmul's
// inner loop active (see Matrix.cpp's axpyRow) - false on any non-ARM
// build, including this project's own build sandbox. Purely diagnostic:
// lets an on-device test report whether NEON is actually active,
// rather than only being inferable from build flags after the fact.
bool neonEnabled();

} // namespace matrix
} // namespace novallm

