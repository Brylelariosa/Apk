#include "Matrix.h"
#include <stdexcept>
#include <cmath>
#include <algorithm>

#if defined(__ARM_NEON) || defined(__ARM_NEON__)
#include <arm_neon.h>
#define NOVALLM_HAVE_NEON 1
#endif

namespace novallm {
namespace matrix {
namespace {

// orow[j] += av * brow[j] for j in [colBegin, colEnd) - matmul's
// innermost accumulate step, split out so it can carry a NEON-
// accelerated implementation (4 float32 columns per instruction)
// without touching matmul's own i-p-j loop structure at all.
//
// The #else branch is exactly the one-column-at-a-time loop that lived
// directly in matmul before NEON existed, completely unconditionally -
// on any platform without __ARM_NEON defined (this project's own build
// sandbox included, which has no ARM toolchain at all), this function
// compiles to precisely that and nothing else, so every existing test's
// byte-exact results are provably unaffected by this function existing.
// Confirmed by re-running the full suite after adding it: zero
// regressions, because on this sandbox nothing here actually changed.
//
// Deliberately vmulq_f32 + vaddq_f32 (separate multiply, then separate
// add), NOT vmlaq_f32: on AArch64, vmlaq_f32 compiles to FMLA, a truly
// FUSED multiply-add (one rounding) - despite the "non-fused" name it
// inherited from 32-bit ARM, where VMLA.F32 really was non-fused.
// Whether the *scalar* comparison path below also gets fused into an
// FMA depends on the compiler's -ffp-contract setting for this specific
// NDK toolchain, which isn't something this sandbox can check - so
// forcing NEON through separate multiply+add, matching what a plain
// `orow[j] += av*brow[j]` most commonly compiles to without explicit
// fast-math flags, is the safer choice for the two paths to actually
// agree, not just be "each individually correct but different by an
// FMA-sized rounding difference." Cross-checked (SSE stand-in, since
// this sandbox can compile and run x86 but not ARM intrinsics): 12,341
// cases sweeping every buffer size 0-40 and every colBegin/colEnd pair
// - including non-4-aligned colBegin, which parallelFor's chunk
// boundaries don't guarantee against - bit-exact against the scalar
// loop in all of them. That validates the loop/remainder structure and
// the separate-mul-add choice; it does NOT validate the actual ARM
// intrinsics below, which only a real device can compile at all. See
// the part-4 ROADMAP.md entry for the full reasoning and exactly what
// still needs an on-device run to confirm.
#ifdef NOVALLM_HAVE_NEON
inline void axpyRow(float* orow, const float* brow, float av, int colBegin, int colEnd) {
    float32x4_t avVec = vdupq_n_f32(av);
    int j = colBegin;
    for (; j + 4 <= colEnd; j += 4) {
        float32x4_t bVec = vld1q_f32(brow + j);
        float32x4_t oVec = vld1q_f32(orow + j);
        float32x4_t prod = vmulq_f32(avVec, bVec);
        oVec = vaddq_f32(oVec, prod);
        vst1q_f32(orow + j, oVec);
    }
    for (; j < colEnd; ++j) { // 0-3 leftover columns when the chunk width isn't a multiple of 4
        orow[j] += av * brow[j];
    }
}
#else
inline void axpyRow(float* orow, const float* brow, float av, int colBegin, int colEnd) {
    for (int j = colBegin; j < colEnd; ++j) {
        orow[j] += av * brow[j];
    }
}
#endif

} // namespace

Tensor matmul(const Tensor& a, const Tensor& b) {
    return matmul(a, b, ThreadPool::shared());
}

Tensor matmul(const Tensor& a, const Tensor& b, ThreadPool& pool) {
    if (a.rank() != 2 || b.rank() != 2) {
        throw std::invalid_argument("matmul: both tensors must be rank 2");
    }
    int m = a.dim(0);
    int k = a.dim(1);
    int k2 = b.dim(0);
    int n = b.dim(1);
    if (k != k2) {
        throw std::invalid_argument("matmul: inner dimensions do not match");
    }

    Tensor out({m, n});
    const float* ad = a.data();
    const float* bd = b.data();
    float* od = out.data();

    // Parallelized over OUTPUT COLUMNS (n), not rows (m): unlike rows, n
    // (embedDim / ffnHiddenDim / vocabSize in this project) stays
    // substantial even when m collapses to 1 - the common case for every
    // generated token after the first during incremental decoding.
    // Splitting by rows would give that dominant, latency-critical
    // workload zero benefit from threading; splitting by columns helps
    // it exactly as much as it helps a large-m training batch. Two
    // different chunks never write the same output column, so this
    // needs no synchronization beyond parallelFor's own join.
    //
    // Same i-p-j loop order and zero-skip as before within each chunk -
    // cache-friendly, doesn't touch B or the output outside its own
    // column range. Accumulation order for any single output element
    // never changes (still strictly p = 0..k-1) - only WHICH thread
    // computes which column does, and (on ARM) whether axpyRow's inner
    // 4-wide step runs through NEON or the scalar loop - so results
    // should match the pre-threading, pre-NEON baseline for the same
    // reason the pure-threading change was bit-exact (see
    // tests/test_thread_pool.cpp): nothing here reorders what gets
    // summed, only who computes each already-fixed step. Threading
    // alone still IS bit-exact, confirmed on real hardware. NEON adds
    // one more variable this sandbox can't rule out - see axpyRow's own
    // comment for why it deliberately avoids vmlaq_f32/FMA to keep that
    // risk as small as possible, and the part-4 ROADMAP.md entry for
    // what's actually confirmed vs. still needs an on-device run.
    pool.parallelFor(n, [&](int colBegin, int colEnd) {
        for (int i = 0; i < m; ++i) {
            float* orow = od + static_cast<size_t>(i) * n;
            for (int p = 0; p < k; ++p) {
                float av = ad[static_cast<size_t>(i) * k + p];
                if (av == 0.0f) continue;
                const float* brow = bd + static_cast<size_t>(p) * n;
                axpyRow(orow, brow, av, colBegin, colEnd);
            }
        }
    });
    return out;
}

Tensor add(const Tensor& a, const Tensor& b) {
    if (a.shape() != b.shape()) {
        throw std::invalid_argument("add: shape mismatch");
    }
    Tensor out(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        out.data()[i] = a.data()[i] + b.data()[i];
    }
    return out;
}

Tensor addBias(const Tensor& a, const Tensor& bias) {
    if (a.rank() != 2) throw std::invalid_argument("addBias: a must be rank 2");
    int rows = a.dim(0);
    int cols = a.dim(1);
    if (static_cast<int>(bias.size()) != cols) {
        throw std::invalid_argument("addBias: bias size must equal column count");
    }
    Tensor out({rows, cols});
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            out.data()[static_cast<size_t>(i) * cols + j] =
                a.data()[static_cast<size_t>(i) * cols + j] + bias.data()[j];
        }
    }
    return out;
}

Tensor transpose(const Tensor& a) {
    if (a.rank() != 2) throw std::invalid_argument("transpose: a must be rank 2");
    int rows = a.dim(0);
    int cols = a.dim(1);
    Tensor out({cols, rows});
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            out.data()[static_cast<size_t>(j) * rows + i] =
                a.data()[static_cast<size_t>(i) * cols + j];
        }
    }
    return out;
}

Tensor scale(const Tensor& a, float scalar) {
    Tensor out(a.shape());
    for (size_t i = 0; i < a.size(); ++i) {
        out.data()[i] = a.data()[i] * scalar;
    }
    return out;
}

void softmaxRows(Tensor& x) {
    if (x.rank() != 2) throw std::invalid_argument("softmaxRows: x must be rank 2");
    int rows = x.dim(0);
    int cols = x.dim(1);
    for (int i = 0; i < rows; ++i) {
        float* row = x.data() + static_cast<size_t>(i) * cols;
        float maxVal = row[0];
        for (int j = 1; j < cols; ++j) maxVal = std::max(maxVal, row[j]);
        float sum = 0.0f;
        for (int j = 0; j < cols; ++j) {
            row[j] = std::exp(row[j] - maxVal);
            sum += row[j];
        }
        for (int j = 0; j < cols; ++j) row[j] /= sum;
    }
}

Tensor sliceColumns(const Tensor& a, int startCol, int numCols) {
    if (a.rank() != 2) throw std::invalid_argument("sliceColumns: a must be rank 2");
    int rows = a.dim(0);
    int colsA = a.dim(1);
    if (startCol < 0 || numCols < 0 || startCol + numCols > colsA) {
        throw std::out_of_range("sliceColumns: column range out of bounds");
    }
    Tensor out({rows, numCols});
    for (int i = 0; i < rows; ++i) {
        const float* src = a.data() + static_cast<size_t>(i) * colsA + startCol;
        float* dst = out.data() + static_cast<size_t>(i) * numCols;
        for (int j = 0; j < numCols; ++j) dst[j] = src[j];
    }
    return out;
}

void setColumns(Tensor& dst, int startCol, const Tensor& src) {
    if (dst.rank() != 2 || src.rank() != 2) throw std::invalid_argument("setColumns: rank must be 2");
    int rows = dst.dim(0);
    int colsDst = dst.dim(1);
    int numCols = src.dim(1);
    if (src.dim(0) != rows) throw std::invalid_argument("setColumns: row count mismatch");
    if (startCol < 0 || startCol + numCols > colsDst) {
        throw std::out_of_range("setColumns: column range out of bounds");
    }
    for (int i = 0; i < rows; ++i) {
        const float* srcRow = src.data() + static_cast<size_t>(i) * numCols;
        float* dstRow = dst.data() + static_cast<size_t>(i) * colsDst + startCol;
        for (int j = 0; j < numCols; ++j) dstRow[j] = srcRow[j];
    }
}

bool neonEnabled() {
#ifdef NOVALLM_HAVE_NEON
    return true;
#else
    return false;
#endif
}

} // namespace matrix
} // namespace novallm
