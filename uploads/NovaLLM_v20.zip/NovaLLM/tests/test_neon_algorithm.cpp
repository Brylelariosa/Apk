// Validates the LOOP/REMAINDER STRUCTURE that core/math/Matrix.cpp's
// NEON axpyRow uses (subsystem 8, part 4), via an x86 SSE stand-in -
// this sandbox has no ARM toolchain, so it cannot compile or run the
// actual NEON intrinsics at all. This is NOT a substitute for an
// on-device run: it proves the loop bounds and remainder handling are
// right (same 4-wide-vector-plus-scalar-tail shape, same unaligned
// colBegin exposure that parallelFor's chunk boundaries create), and
// that using separate multiply+add (not a fused multiply-add) is
// bit-exact with the scalar reference - it says nothing about whether
// the actual arm_neon.h intrinsics compile correctly or produce the
// same result on real ARM hardware. See the part-4 ROADMAP.md entry and
// Matrix.cpp's axpyRow comment for what's confirmed vs. still open.
//
// No Android/JNI needed; x86_64/i386 only (see the #if guard below) -
// compiles to a no-op elsewhere rather than failing the build.
#include <cstdio>

#if defined(__x86_64__) || defined(__i386__)
#include <immintrin.h>
#include <cstdlib>
#include <vector>

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

// The scalar reference - identical to Matrix.cpp's #else branch and to
// its NEON branch's own scalar remainder tail.
void axpyRowScalar(float* orow, const float* brow, float av, int colBegin, int colEnd) {
    for (int j = colBegin; j < colEnd; ++j) orow[j] += av * brow[j];
}

// Mirrors Matrix.cpp's NEON axpyRow 1:1, intrinsic for intrinsic, with
// SSE standing in for NEON: vdupq_n_f32->_mm_set1_ps,
// vld1q_f32->_mm_loadu_ps (unaligned, like NEON's vld1q always is),
// vmulq_f32->_mm_mul_ps, vaddq_f32->_mm_add_ps,
// vst1q_f32->_mm_storeu_ps. Deliberately separate mul+add, not a fused
// multiply-add (_mm_fmadd_ps) - see Matrix.cpp's axpyRow comment for
// why matching that choice matters here.
void axpyRowSseStandIn(float* orow, const float* brow, float av, int colBegin, int colEnd) {
    __m128 avVec = _mm_set1_ps(av);
    int j = colBegin;
    for (; j + 4 <= colEnd; j += 4) {
        __m128 bVec = _mm_loadu_ps(brow + j);
        __m128 oVec = _mm_loadu_ps(orow + j);
        __m128 prod = _mm_mul_ps(avVec, bVec);
        oVec = _mm_add_ps(oVec, prod);
        _mm_storeu_ps(orow + j, oVec);
    }
    for (; j < colEnd; ++j) orow[j] += av * brow[j];
}

void testMatchesScalarAcrossEverySizeAndBoundaryPair() {
    bool allMatch = true;
    int cases = 0;
    srand(42);
    // Every size 0-40 and every (colBegin, colEnd) pair within it -
    // specifically including non-4-aligned colBegin, since parallelFor
    // chunk boundaries give axpyRow no alignment guarantee at all.
    for (int size = 0; size <= 40 && allMatch; ++size) {
        for (int colBegin = 0; colBegin <= size && allMatch; ++colBegin) {
            for (int colEnd = colBegin; colEnd <= size && allMatch; ++colEnd) {
                std::vector<float> brow(static_cast<size_t>(size));
                std::vector<float> orowRef(static_cast<size_t>(size));
                std::vector<float> orowSse(static_cast<size_t>(size));
                for (int i = 0; i < size; ++i) {
                    brow[static_cast<size_t>(i)] = static_cast<float>(rand() % 2000 - 1000) / 137.0f;
                    float v = static_cast<float>(rand() % 2000 - 1000) / 97.0f;
                    orowRef[static_cast<size_t>(i)] = v;
                    orowSse[static_cast<size_t>(i)] = v;
                }
                float av = static_cast<float>(rand() % 2000 - 1000) / 211.0f;

                axpyRowScalar(orowRef.data(), brow.data(), av, colBegin, colEnd);
                axpyRowSseStandIn(orowSse.data(), brow.data(), av, colBegin, colEnd);

                cases++;
                if (orowRef != orowSse) allMatch = false;
            }
        }
    }
    std::printf("(%d size/boundary combinations checked)\n", cases);
    expectTrue(allMatch, "axpyRow structure (SSE stand-in): bit-exact with the scalar reference across every size and colBegin/colEnd pair, including unaligned starts");
}

int main() {
    testMatchesScalarAcrossEverySizeAndBoundaryPair();
    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    std::printf("(this validates the loop/remainder ALGORITHM via an x86 stand-in only "
                "- see this file's header comment for what it does not prove)\n");
    return g_failures == 0 ? 0 : 1;
}

#else // not x86 - nothing to stand in with here; not a failure, just out of scope.

int main() {
    std::printf("skipped: no SSE stand-in available on this architecture (see file header)\n");
    return 0;
}

#endif
