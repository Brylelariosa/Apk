package com.bru.systemmonitor.domain

import com.bru.systemmonitor.domain.model.SystemSnapshot
import kotlinx.coroutines.flow.Flow

interface SystemStatsRepository {
    fun observeSnapshot(intervalMs: Long): Flow<SystemSnapshot>
    fun isRootAvailable(): Boolean
    fun isUsageAccessGranted(): Boolean
}
