package com.bru.systemmonitor.data

import java.io.File

/**
 * CPU usage of this app's own process, expressed as % of a single core
 * (matches `top`'s convention — can exceed 100% under multi-threaded work).
 * Every process can read its own /proc/self/stat, so this is the one
 * CPU-usage figure Android guarantees without root.
 */
class SelfProcessCpuReader {

    private val clockTicksPerSecond = 100L // USER_HZ; standard on Android ARM/x86 kernels

    fun readTicks(): Long? = runCatching {
        val stat = File("/proc/self/stat").readText()
        // Skip "pid (comm) " — use substringAfterLast in case comm itself contains ')'.
        val fields = stat.substringAfterLast(") ").trim().split(" ")
        val utime = fields[11].toLong()
        val stime = fields[12].toLong()
        utime + stime
    }.getOrNull()

    fun percentBetween(previousTicks: Long, currentTicks: Long, elapsedMs: Long): Float? {
        if (elapsedMs <= 0) return null
        val deltaTicks = currentTicks - previousTicks
        val deltaSeconds = elapsedMs / 1000f
        return (deltaTicks / clockTicksPerSecond.toFloat()) / deltaSeconds * 100f
    }
}
