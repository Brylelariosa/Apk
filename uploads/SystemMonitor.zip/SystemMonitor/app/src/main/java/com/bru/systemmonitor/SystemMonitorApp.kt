package com.bru.systemmonitor

import android.app.Application
import android.content.ContentValues
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.bru.systemmonitor.di.AppContainer
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SystemMonitorApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
        container = AppContainer(this)
    }

    /**
     * No ADB or root on the target device, so there's no normal way to pull
     * logcat after a crash. Any uncaught exception gets written to a plain
     * text file in Downloads (API 29+, via MediaStore — no permission
     * needed) or the app's own external files dir on older API levels,
     * so it can be grabbed with a file manager and sent back instead of
     * debugging blind from build logs alone. Re-throws afterward so normal
     * crash behavior (and the system's own crash dialog) is unchanged.
     */
    private fun installCrashLogger() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            runCatching { writeCrashLog(throwable) }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun writeCrashLog(throwable: Throwable) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "SystemMonitor_crash_$stamp.txt"
        val stackTrace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            uri?.let { target ->
                contentResolver.openOutputStream(target)?.use { it.write(stackTrace.toByteArray()) }
            }
        } else {
            val dir = getExternalFilesDir(null) ?: filesDir
            File(dir, fileName).writeText(stackTrace)
        }
    }
}
