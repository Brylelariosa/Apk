package com.bru.systemmonitor

import android.app.Application
import com.bru.systemmonitor.di.AppContainer

class SystemMonitorApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
