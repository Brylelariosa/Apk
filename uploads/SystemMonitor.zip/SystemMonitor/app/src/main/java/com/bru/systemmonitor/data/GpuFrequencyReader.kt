package com.bru.systemmonitor.data

import java.io.File

/**
 * Best-effort GPU clock reader. Unlike CPU cpufreq, mobile GPU sysfs exposure
 * is vendor-specific and unstandardized.
 *
 * Tries a handful of known fixed paths first (Adreno's kgsl, and common
 * MediaTek/Unisoc devfreq aliases), then falls back to scanning
 * /sys/class/devfreq for any GPU-like node. The scan is what actually finds
 * the clock on Mali-based chipsets (e.g. Unisoc T610 / Mali-G52) since the
 * exact devfreq node name varies by OEM kernel build and can't be hardcoded
 * reliably.
 */
class GpuFrequencyReader {

    private val knownPaths = listOf(
        "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq",           // Adreno (Qualcomm)
        "/sys/class/devfreq/gpufreq/cur_freq",                  // common MediaTek/Unisoc devfreq alias
        "/sys/devices/platform/gpu.0/devfreq/gpu.0/cur_freq",   // Unisoc-pattern platform device
        "/sys/kernel/gpu/gpu_clock"                             // some MediaTek kernels
    )

    fun read(): GpuReading {
        for (path in knownPaths) {
            readFreqFile(path)?.let { return GpuReading(it, path) }
        }
        return scanDevfreq() ?: GpuReading(null, null)
    }

    private fun scanDevfreq(): GpuReading? {
        val nodes = runCatching { File("/sys/class/devfreq").listFiles() }.getOrNull() ?: return null
        val gpuNode = nodes.firstOrNull { node ->
            val name = node.name.lowercase()
            name.contains("gpu") || name.contains("mali") || name.contains("kgsl")
        } ?: return null
        val path = "${gpuNode.path}/cur_freq"
        return readFreqFile(path)?.let { GpuReading(it, path) }
    }

    private fun readFreqFile(path: String): Int? = runCatching {
        val raw = File(path).readText().trim().toLong()
        // devfreq normally reports Hz; a few custom kernels already report MHz directly.
        val mhz = if (raw > 100_000) raw / 1_000_000 else raw
        mhz.toInt()
    }.getOrNull()?.takeIf { it > 0 }
}

data class GpuReading(val currentMhz: Int?, val sourcePath: String?)
