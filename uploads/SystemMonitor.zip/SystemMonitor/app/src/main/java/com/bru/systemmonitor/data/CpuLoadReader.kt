package com.bru.systemmonitor.data

import java.io.File

/**
 * Computes aggregate system-wide CPU utilization from /proc/stat deltas.
 * Two consecutive reads are required — call [readTimes] on each poll tick
 * and diff it against the previous [CpuTimes] via [percentBetween].
 */
class CpuLoadReader {

    fun readTimes(): CpuTimes? = runCatching {
        val line = File("/proc/stat").bufferedReader().readLine() ?: return null
        val parts = line.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
        val idle = parts[3] + parts.getOrElse(4) { 0L }
        CpuTimes(total = parts.sum(), idle = idle)
    }.getOrNull()

    fun percentBetween(previous: CpuTimes, current: CpuTimes): Float? {
        val totalDelta = current.total - previous.total
        val idleDelta = current.idle - previous.idle
        if (totalDelta <= 0) return null
        return ((totalDelta - idleDelta).toFloat() / totalDelta) * 100f
    }
}

data class CpuTimes(val total: Long, val idle: Long)
