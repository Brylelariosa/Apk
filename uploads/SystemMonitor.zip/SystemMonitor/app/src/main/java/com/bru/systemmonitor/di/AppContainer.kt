package com.bru.systemmonitor.di

import android.content.Context
import com.bru.systemmonitor.data.SystemStatsRepositoryImpl
import com.bru.systemmonitor.domain.SystemStatsRepository

/**
 * Minimal manual DI container. A single-screen utility app doesn't warrant
 * a DI framework; this keeps object construction centralized and swappable
 * for tests without adding Hilt/Koin as a build dependency.
 */
class AppContainer(context: Context) {

    val systemStatsRepository: SystemStatsRepository by lazy {
        SystemStatsRepositoryImpl(context.applicationContext)
    }
}
