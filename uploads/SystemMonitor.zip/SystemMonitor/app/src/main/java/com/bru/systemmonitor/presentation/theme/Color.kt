package com.bru.systemmonitor.presentation.theme

import androidx.compose.ui.graphics.Color

val AccentGreen = Color(0xFF34D399)
val SurfaceDark = Color(0xFF121417)
val SurfaceCardDark = Color(0xFF1C1F24)
