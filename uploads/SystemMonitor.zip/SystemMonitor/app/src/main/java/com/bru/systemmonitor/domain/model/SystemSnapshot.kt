package com.bru.systemmonitor.domain.model

data class CpuCoreInfo(
    val coreIndex: Int,
    val currentMhz: Int?,
    val maxMhz: Int?
)

data class GpuInfo(
    val currentMhz: Int?,
    val sourcePath: String?
)

/** Live per-process CPU%, only ever populated when the device is rooted. */
data class ProcessUsage(
    val pid: Int,
    val packageName: String,
    val label: String,
    val cpuPercent: Float
)

/** Foreground TIME (not load) over the last 24h — the no-root fallback signal. */
data class RecentAppUsage(
    val packageName: String,
    val label: String,
    val foregroundMinutesToday: Long
)

data class SystemSnapshot(
    val cpuCores: List<CpuCoreInfo>,
    val gpu: GpuInfo,
    val systemCpuLoadPercent: Float?,
    val selfCpuPercent: Float?,
    val topProcesses: List<ProcessUsage>,
    val recentApps: List<RecentAppUsage>,
    val rootAvailable: Boolean,
    val usageAccessGranted: Boolean
)
