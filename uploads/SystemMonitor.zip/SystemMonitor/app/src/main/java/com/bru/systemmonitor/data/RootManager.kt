package com.bru.systemmonitor.data

/**
 * Detects root availability and runs shell commands through `su` when present.
 * Per-app CPU visibility on Android 7+ requires root — the OS blocks reads of
 * other processes' /proc/[pid]/stat for unprivileged apps.
 */
class RootManager {

    @Volatile
    private var cachedRootAvailable: Boolean? = null

    fun isRootAvailable(): Boolean {
        cachedRootAvailable?.let { return it }
        val available = runCommand("id")?.contains("uid=0") == true
        cachedRootAvailable = available
        return available
    }

    fun runCommand(command: String): String? = runCatching {
        val process = ProcessBuilder("su", "-c", command)
            .redirectErrorStream(true)
            .start()
        val output = process.inputStream.bufferedReader().readText()
        process.waitFor()
        output
    }.getOrNull()
}
