package com.bru.systemmonitor.data

import android.app.usage.UsageStatsManager
import android.content.Context
import com.bru.systemmonitor.domain.model.RecentAppUsage

/**
 * Foreground-time ranking for the last 24h — a no-root fallback signal for
 * "which apps have actually been active." This is usage TIME, not CPU load,
 * and the UI keeps that distinction explicit rather than implying it's load.
 */
class UsageStatsProvider(
    private val context: Context,
    private val appResolver: InstalledAppResolver
) {

    fun queryTopAppsLast24h(limit: Int = 10): List<RecentAppUsage> {
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return emptyList()

        val end = System.currentTimeMillis()
        val start = end - 24 * 60 * 60 * 1000

        val stats = runCatching {
            usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
        }.getOrNull() ?: return emptyList()

        return stats
            .filter { it.totalTimeInForeground > 0 }
            .sortedByDescending { it.totalTimeInForeground }
            .take(limit)
            .mapNotNull { usage ->
                val resolved = appResolver.resolve(usage.packageName) ?: return@mapNotNull null
                RecentAppUsage(
                    packageName = resolved.packageName,
                    label = resolved.label,
                    foregroundMinutesToday = usage.totalTimeInForeground / 60000
                )
            }
    }
}
