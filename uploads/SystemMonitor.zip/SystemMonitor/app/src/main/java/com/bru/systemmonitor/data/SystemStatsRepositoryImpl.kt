package com.bru.systemmonitor.data

import android.app.AppOpsManager
import android.content.Context
import android.os.Process
import com.bru.systemmonitor.domain.SystemStatsRepository
import com.bru.systemmonitor.domain.model.CpuCoreInfo
import com.bru.systemmonitor.domain.model.GpuInfo
import com.bru.systemmonitor.domain.model.SystemSnapshot
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class SystemStatsRepositoryImpl(
    private val context: Context,
    private val cpuFrequencyReader: CpuFrequencyReader = CpuFrequencyReader(),
    private val gpuFrequencyReader: GpuFrequencyReader = GpuFrequencyReader(),
    private val cpuLoadReader: CpuLoadReader = CpuLoadReader(),
    private val selfProcessCpuReader: SelfProcessCpuReader = SelfProcessCpuReader(),
    private val rootManager: RootManager = RootManager(),
    appResolver: InstalledAppResolver = InstalledAppResolver(context.packageManager),
    private val rootProcessStatsReader: RootProcessStatsReader = RootProcessStatsReader(rootManager, appResolver),
    private val usageStatsProvider: UsageStatsProvider = UsageStatsProvider(context, appResolver)
) : SystemStatsRepository {

    override fun observeSnapshot(intervalMs: Long): Flow<SystemSnapshot> = flow {
        var previousSystemTimes = cpuLoadReader.readTimes()
        var previousSelfTicks = selfProcessCpuReader.readTicks()
        var previousTimestamp = System.currentTimeMillis()

        while (true) {
            delay(intervalMs)

            val currentTimestamp = System.currentTimeMillis()
            val elapsedMs = currentTimestamp - previousTimestamp

            val currentSystemTimes = cpuLoadReader.readTimes()
            val systemLoad = if (previousSystemTimes != null && currentSystemTimes != null) {
                cpuLoadReader.percentBetween(previousSystemTimes, currentSystemTimes)
            } else null

            val currentSelfTicks = selfProcessCpuReader.readTicks()
            val selfCpu = if (previousSelfTicks != null && currentSelfTicks != null) {
                selfProcessCpuReader.percentBetween(previousSelfTicks, currentSelfTicks, elapsedMs)
            } else null

            val rootAvailable = rootManager.isRootAvailable()
            val topProcesses = if (rootAvailable) rootProcessStatsReader.readTopProcesses() else emptyList()
            val usageGranted = isUsageAccessGranted()

            emit(
                SystemSnapshot(
                    cpuCores = cpuFrequencyReader.readCores().map {
                        CpuCoreInfo(it.coreIndex, it.currentMhz, it.maxMhz)
                    },
                    gpu = gpuFrequencyReader.read().let { GpuInfo(it.currentMhz, it.sourcePath) },
                    systemCpuLoadPercent = systemLoad,
                    selfCpuPercent = selfCpu,
                    topProcesses = topProcesses,
                    recentApps = if (usageGranted) usageStatsProvider.queryTopAppsLast24h() else emptyList(),
                    rootAvailable = rootAvailable,
                    usageAccessGranted = usageGranted
                )
            )

            previousSystemTimes = currentSystemTimes
            previousSelfTicks = currentSelfTicks
            previousTimestamp = currentTimestamp
        }
    }

    override fun isRootAvailable(): Boolean = rootManager.isRootAvailable()

    @Suppress("DEPRECATION")
    override fun isUsageAccessGranted(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
