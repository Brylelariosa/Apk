package com.bru.systemmonitor.presentation

import java.util.Locale

fun Float?.asPercentOrNA(): String =
    this?.let { String.format(Locale.US, "%.1f%%", it) } ?: "N/A"

fun Int?.asMhzOrNA(): String =
    this?.let { "$it MHz" } ?: "N/A"
