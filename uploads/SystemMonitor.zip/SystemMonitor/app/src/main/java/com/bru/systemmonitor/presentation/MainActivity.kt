package com.bru.systemmonitor.presentation

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.bru.systemmonitor.SystemMonitorApp
import com.bru.systemmonitor.presentation.theme.SystemMonitorTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MonitorViewModel by viewModels {
        MonitorViewModel.Factory((application as SystemMonitorApp).container.systemStatsRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SystemMonitorTheme {
                MonitorScreen(
                    viewModel = viewModel,
                    onRequestUsageAccess = { openUsageAccessSettings() }
                )
            }
        }
    }

    private fun openUsageAccessSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }
}
