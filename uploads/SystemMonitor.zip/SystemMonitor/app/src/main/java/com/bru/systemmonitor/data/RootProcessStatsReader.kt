package com.bru.systemmonitor.data

import com.bru.systemmonitor.domain.model.ProcessUsage

/**
 * Parses `top -bn1` output for per-process CPU%, available only when rooted.
 * Toybox/BusyBox `top` layouts vary slightly by OEM, so columns are located
 * by header name rather than fixed offsets.
 */
class RootProcessStatsReader(
    private val rootManager: RootManager,
    private val appResolver: InstalledAppResolver
) {

    fun readTopProcesses(limit: Int = 10): List<ProcessUsage> {
        val raw = rootManager.runCommand("top -bn1") ?: return emptyList()
        val lines = raw.lines()
        val headerIndex = lines.indexOfFirst {
            it.contains("PID", ignoreCase = true) && it.contains("CPU", ignoreCase = true)
        }
        if (headerIndex == -1) return emptyList()

        val headerCols = lines[headerIndex].trim().split(Regex("\\s+"))
        val pidCol = headerCols.indexOfFirst { it.equals("PID", ignoreCase = true) }
        val cpuCol = headerCols.indexOfFirst { it.contains("CPU", ignoreCase = true) }
        val nameCol = headerCols.size - 1 // process name/cmdline is reliably the last column
        if (pidCol == -1 || cpuCol == -1) return emptyList()

        return lines.drop(headerIndex + 1)
            .mapNotNull { line -> parseRow(line, pidCol, cpuCol, nameCol) }
            .sortedByDescending { it.cpuPercent }
            .take(limit)
    }

    private fun parseRow(line: String, pidCol: Int, cpuCol: Int, nameCol: Int): ProcessUsage? {
        val cols = line.trim().split(Regex("\\s+"))
        if (cols.size <= maxOf(pidCol, cpuCol, nameCol)) return null
        val pid = cols[pidCol].toIntOrNull() ?: return null
        val cpu = cols[cpuCol].removeSuffix("%").toFloatOrNull() ?: return null
        val processName = cols[nameCol]
        val resolved = appResolver.resolve(processName)
        return ProcessUsage(
            pid = pid,
            packageName = resolved?.packageName ?: processName,
            label = resolved?.label ?: processName,
            cpuPercent = cpu
        )
    }
}
