package com.bru.systemmonitor.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.bru.systemmonitor.domain.SystemStatsRepository
import com.bru.systemmonitor.domain.model.SystemSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

private const val POLL_INTERVAL_MS = 1500L

class MonitorViewModel(private val repository: SystemStatsRepository) : ViewModel() {

    private val _snapshot = MutableStateFlow<SystemSnapshot?>(null)
    val snapshot: StateFlow<SystemSnapshot?> = _snapshot

    init {
        viewModelScope.launch {
            repository.observeSnapshot(POLL_INTERVAL_MS).collect { _snapshot.value = it }
        }
    }

    class Factory(private val repository: SystemStatsRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MonitorViewModel(repository) as T
    }
}
