package com.bru.systemmonitor.data

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

/**
 * Maps a process/package name to its installed-app label, caching results
 * since PackageManager lookups are relatively expensive to repeat every poll tick.
 */
class InstalledAppResolver(private val packageManager: PackageManager) {

    data class ResolvedApp(val packageName: String, val label: String)

    private val cache = mutableMapOf<String, ResolvedApp?>()

    @Suppress("DEPRECATION")
    fun resolve(processName: String): ResolvedApp? = cache.getOrPut(processName) {
        // Secondary process names look like "package.name:service" — strip the suffix.
        val basePackage = processName.substringBefore(':')
        runCatching {
            val info: ApplicationInfo = packageManager.getApplicationInfo(basePackage, 0)
            ResolvedApp(
                packageName = basePackage,
                label = packageManager.getApplicationLabel(info).toString()
            )
        }.getOrNull()
    }
}
