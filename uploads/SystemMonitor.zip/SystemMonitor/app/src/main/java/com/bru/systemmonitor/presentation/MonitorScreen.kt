package com.bru.systemmonitor.presentation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bru.systemmonitor.domain.model.SystemSnapshot

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonitorScreen(
    viewModel: MonitorViewModel,
    onRequestUsageAccess: () -> Unit
) {
    val snapshot by viewModel.snapshot.collectAsStateWithLifecycle()
    val data = snapshot

    Scaffold(
        topBar = { TopAppBar(title = { Text("System Monitor") }) }
    ) { padding ->
        if (data == null) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { CpuSection(data) }
            item { GpuSection(data) }
            item { SelfUsageSection(data) }
            item { ProcessSection(data) }
            item { RecentAppsSection(data, onRequestUsageAccess) }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun CpuSection(data: SystemSnapshot) {
    SectionCard("CPU") {
        Text("System load: ${data.systemCpuLoadPercent.asPercentOrNA()}", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(8.dp))
        data.cpuCores.forEach { core ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Core ${core.coreIndex}")
                Text(core.currentMhz.asMhzOrNA())
            }
        }
    }
}

@Composable
private fun GpuSection(data: SystemSnapshot) {
    SectionCard("GPU") {
        Text(data.gpu.currentMhz?.let { "$it MHz" } ?: "Unavailable on this device")
        data.gpu.sourcePath?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SelfUsageSection(data: SystemSnapshot) {
    SectionCard("This App") {
        Text("CPU: ${data.selfCpuPercent.asPercentOrNA()} of one core", style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun ProcessSection(data: SystemSnapshot) {
    SectionCard("Per-App CPU") {
        if (!data.rootAvailable) {
            Text("Root access required for live per-app CPU usage. See foreground activity below instead.")
            return@SectionCard
        }
        if (data.topProcesses.isEmpty()) {
            Text("No process data yet.")
            return@SectionCard
        }
        data.topProcesses.forEach { proc ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(proc.label, maxLines = 1)
                Text(proc.cpuPercent.asPercentOrNA())
            }
        }
    }
}

@Composable
private fun RecentAppsSection(data: SystemSnapshot, onRequestUsageAccess: () -> Unit) {
    SectionCard("Foreground Time (24h)") {
        if (!data.usageAccessGranted) {
            Text("Grant usage access to see which apps have been active recently.")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onRequestUsageAccess) { Text("Grant Access") }
            return@SectionCard
        }
        if (data.recentApps.isEmpty()) {
            Text("No usage data yet.")
            return@SectionCard
        }
        data.recentApps.forEach { app ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(app.label, maxLines = 1)
                Text("${app.foregroundMinutesToday} min")
            }
        }
    }
}
