package com.bru.systemmonitor.data

import java.io.File

/**
 * Reads current per-core CPU clock speed from sysfs.
 * Falls back across known kernel exposure paths; returns null per-core
 * when the OS denies access (happens on some locked-down OEM builds).
 */
class CpuFrequencyReader {

    private val coreCount = Runtime.getRuntime().availableProcessors()

    fun readCores(): List<CpuCoreReading> = (0 until coreCount).map { core ->
        CpuCoreReading(
            coreIndex = core,
            currentMhz = readKhzFile("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_cur_freq")
                ?: readKhzFile("/sys/devices/system/cpu/cpufreq/policy$core/scaling_cur_freq"),
            maxMhz = readKhzFile("/sys/devices/system/cpu/cpu$core/cpufreq/scaling_max_freq")
                ?: readKhzFile("/sys/devices/system/cpu/cpufreq/policy$core/scaling_max_freq")
        )
    }

    private fun readKhzFile(path: String): Int? = runCatching {
        (File(path).readText().trim().toLong() / 1000).toInt()
    }.getOrNull()
}

data class CpuCoreReading(val coreIndex: Int, val currentMhz: Int?, val maxMhz: Int?)
