# Add project specific ProGuard rules here.
# Minification is disabled for this build (release APKs ship unshrunk);
# flip android.buildTypes.release.isMinifyEnabled once verified stable.
