#pragma once

class Noise {
public:
    explicit Noise(int seed = 12345);

    // Single-octave noise in [-1, 1]
    float noise2D(float x, float y) const;

    // Fractional Brownian Motion: sum of octaves
    float fbm(float x, float y, int octaves, float lacunarity = 2.0f, float gain = 0.5f) const;

private:
    int perm[512];
    float grad(int hash, float x, float y) const;
    static float fade(float t) { return t * t * t * (t * (t * 6.f - 15.f) + 10.f); }
    static float lerp(float a, float b, float t) { return a + t * (b - a); }
};
