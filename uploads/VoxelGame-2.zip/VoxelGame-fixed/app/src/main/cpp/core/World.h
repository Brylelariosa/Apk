#pragma once
#include <unordered_map>
#include <memory>
#include <thread>
#include <vector>
#include <queue>
#include <mutex>
#include <functional>
#include "Chunk.h"
#include "Noise.h"
#include "Math3D.h"

struct ChunkKey {
    int cx, cz;
    bool operator==(const ChunkKey& o) const { return cx == o.cx && cz == o.cz; }
};

struct ChunkKeyHash {
    size_t operator()(const ChunkKey& k) const {
        return std::hash<int>()(k.cx) ^ (std::hash<int>()(k.cz) * 2654435761u);
    }
};

class World {
public:
    static constexpr int RENDER_RADIUS = 5;  // 11x11 = 121 chunks ≈ 100

    World();
    ~World();

    // Initialize with noise seed, generate all chunks
    void init(int seed = 42);

    // Per-frame: upload any newly meshed chunks (call on GL thread)
    void updateGPU();

    // Render all READY chunks visible in frustum
    void render(const Frustum& frustum);

    // Get a block in world coordinates (used for neighbor lookup)
    BlockType getBlock(int wx, int wy, int wz) const;

    // Get chunk pointer (may return nullptr)
    Chunk* getChunk(int cx, int cz) const;

    int getChunkCount()  const { return (int)chunks.size(); }
    int getVisibleCount() const { return lastVisibleCount; }

private:
    Noise noise;
    std::unordered_map<ChunkKey, std::unique_ptr<Chunk>, ChunkKeyHash> chunks;

    // Thread pool for chunk generation + meshing
    std::vector<std::thread>      workers;
    std::queue<std::function<void()>> taskQueue;
    std::mutex                    queueMutex;
    bool                          stopWorkers = false;

    mutable int lastVisibleCount = 0;

    void workerLoop();
    void enqueueTask(std::function<void()> task);
    void rebuildChunkMesh(Chunk* chunk);
};
