#pragma once
#include <cstdint>

// ── Block types ───────────────────────────────────────────────────────────────
enum BlockType : uint8_t {
    BLOCK_AIR    = 0,
    BLOCK_GRASS  = 1,
    BLOCK_DIRT   = 2,
    BLOCK_STONE  = 3,
    BLOCK_SAND   = 4,
    BLOCK_SNOW   = 5,
    BLOCK_WOOD   = 6,
    BLOCK_LEAVES = 7,
    BLOCK_WATER  = 8,
    BLOCK_GRAVEL = 9,
    BLOCK_COUNT  = 10
};

inline bool blockIsOpaque(BlockType t) {
    // LEAVES must be opaque so the greedy mesher generates faces for them.
    // When they were treated as transparent (same as AIR), every leaf-to-air
    // transition had op0==op1 → no face → invisible tree canopies.
    return t != BLOCK_AIR && t != BLOCK_WATER;
}
inline bool blockIsSolid(BlockType t) {
    return t != BLOCK_AIR && t != BLOCK_WATER;
}
inline bool blockIsTransparent(BlockType t) {
    return !blockIsOpaque(t);
}

// ── Per-face directional light multipliers ────────────────────────────────────
// faces: 0=+X, 1=-X, 2=+Y(top), 3=-Y(bottom), 4=+Z, 5=-Z
static const float FACE_LIGHT[6] = {
    0.65f,  // +X
    0.65f,  // -X
    1.00f,  // +Y (top, fully lit)
    0.35f,  // -Y (bottom, very dark)
    0.80f,  // +Z
    0.80f,  // -Z
};

// ── Per-block per-face RGB colors (pre-multiplied with sky light) ─────────────
// face: 2 = top, 3 = bottom, 0/1/4/5 = sides
struct BlockColor { float r, g, b; };

inline BlockColor getBlockColor(BlockType t, int face) {
    bool isTop    = (face == 2);
    bool isBottom = (face == 3);

    switch (t) {
        case BLOCK_GRASS:
            if (isTop)    return {0.29f, 0.68f, 0.18f};
            if (isBottom) return {0.55f, 0.38f, 0.22f};
            return {0.55f, 0.38f, 0.22f};

        case BLOCK_DIRT:   return {0.55f, 0.38f, 0.22f};

        case BLOCK_STONE:  return {0.50f, 0.50f, 0.50f};

        case BLOCK_SAND:   return {0.89f, 0.82f, 0.56f};

        case BLOCK_SNOW:
            if (isTop) return {0.96f, 0.96f, 1.00f};
            return {0.82f, 0.82f, 0.82f};  // pure gray - was blue-tinted causing blue lines

        case BLOCK_WOOD:
            if (isTop || isBottom) return {0.52f, 0.39f, 0.25f};
            return {0.45f, 0.32f, 0.18f};

        case BLOCK_LEAVES: return {0.20f, 0.52f, 0.12f};

        case BLOCK_WATER:  return {0.18f, 0.45f, 0.78f};

        case BLOCK_GRAVEL: return {0.55f, 0.52f, 0.50f};

        default:           return {1.00f, 0.00f, 1.00f}; // magenta = missing
    }
}
