#include "Camera.h"
#include <cmath>
#include <algorithm>

static constexpr float PI    = 3.14159265f;
static constexpr float HALF_PI = PI * 0.5f;

Vec3 Camera::getForward() const {
    float cosPitch = cosf(pitch);
    return Vec3(
        cosf(yaw) * cosPitch,
        sinf(pitch),
        sinf(yaw) * cosPitch
    ).normalize();
}

Vec3 Camera::getRight() const {
    // Right = forward × up
    Vec3 f = getForward();
    Vec3 up{0, 1, 0};
    return f.cross(up).normalize();
}

Mat4 Camera::getView() const {
    Vec3 eye    = position;
    Vec3 target = position + getForward();
    return Mat4::lookAt(eye, target, {0, 1, 0});
}

Mat4 Camera::getProjection() const {
    return Mat4::perspective(fovY, aspect, nearPlane, farPlane);
}

Mat4 Camera::getVP() const {
    return getProjection() * getView();
}

Frustum Camera::getFrustum() const {
    Frustum f;
    f.extractFromVP(getVP());
    return f;
}

void Camera::update(float dt, float speedMultiplier) {
    // Consume look delta
    float dy = 0, dp = 0;
    {
        std::lock_guard<std::mutex> lk(lookMutex);
        dy = lookDyaw;   lookDyaw   = 0;
        dp = lookDpitch; lookDpitch = 0;
    }

    yaw   += dy;
    pitch -= dp;
    pitch  = std::max(-HALF_PI * 0.99f, std::min(HALF_PI * 0.99f, pitch));
    // Keep yaw in [0, 2π)
    while (yaw >  PI * 2.f) yaw -= PI * 2.f;
    while (yaw < -PI * 2.f) yaw += PI * 2.f;

    // Consume movement input
    float fwd    = inputForward.load(std::memory_order_relaxed);
    float strafe = inputStrafe.load(std::memory_order_relaxed);

    Vec3 forward = getForward();
    Vec3 right   = getRight();

    // Clamp to horizontal plane for movement
    Vec3 flatFwd{forward.x, 0, forward.z};
    float len = flatFwd.length();
    if (len > 1e-4f) flatFwd = flatFwd * (1.f / len);

    position += flatFwd  * (fwd    * speedMultiplier * dt);
    position += right    * (strafe * speedMultiplier * dt);
}

void Camera::setLookDelta(float dyaw, float dpitch) {
    std::lock_guard<std::mutex> lk(lookMutex);
    lookDyaw   += dyaw;
    lookDpitch += dpitch;
}

void Camera::setMovement(float forward, float strafe) {
    inputForward.store(forward, std::memory_order_relaxed);
    inputStrafe.store(strafe,  std::memory_order_relaxed);
}
