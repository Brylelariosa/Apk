#pragma once
#include <cmath>
#include <algorithm>

// ── Vec3 ──────────────────────────────────────────────────────────────────────
struct Vec3 {
    float x = 0, y = 0, z = 0;
    Vec3() = default;
    Vec3(float x, float y, float z) : x(x), y(y), z(z) {}

    Vec3 operator+(const Vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    Vec3 operator*(float s)       const { return {x*s,   y*s,   z*s};   }
    Vec3 operator-()              const { return {-x,    -y,    -z};     }
    Vec3& operator+=(const Vec3& o){ x+=o.x; y+=o.y; z+=o.z; return *this; }

    float dot(const Vec3& o)  const { return x*o.x + y*o.y + z*o.z; }
    Vec3  cross(const Vec3& o)const { return {y*o.z-z*o.y, z*o.x-x*o.z, x*o.y-y*o.x}; }
    float lengthSq()          const { return dot(*this); }
    float length()            const { return sqrtf(lengthSq()); }
    Vec3  normalize()         const { float l = length(); return l > 1e-6f ? *this * (1.f/l) : Vec3(0,1,0); }
};

// ── Mat4 (column-major, OpenGL layout) ────────────────────────────────────────
// m[col*4 + row], same as OpenGL
struct Mat4 {
    float m[16];

    Mat4() {
        for (int i = 0; i < 16; i++) m[i] = 0.f;
        m[0] = m[5] = m[10] = m[15] = 1.f;
    }

    // Access element at (row, col)
    float& at(int row, int col) { return m[col*4 + row]; }
    float  at(int row, int col) const { return m[col*4 + row]; }

    Mat4 operator*(const Mat4& b) const {
        Mat4 r;
        for (int col = 0; col < 4; col++) {
            for (int row = 0; row < 4; row++) {
                float s = 0;
                for (int k = 0; k < 4; k++) s += at(row,k) * b.at(k,col);
                r.at(row,col) = s;
            }
        }
        return r;
    }

    static Mat4 perspective(float fovY, float aspect, float zNear, float zFar) {
        Mat4 r;
        float f = 1.f / tanf(fovY * 0.5f);
        r.at(0,0) = f / aspect;
        r.at(1,1) = f;
        r.at(2,2) = (zFar + zNear) / (zNear - zFar);
        r.at(3,2) = -1.f;
        r.at(2,3) = (2.f * zFar * zNear) / (zNear - zFar);
        r.at(3,3) = 0.f;
        return r;
    }

    static Mat4 lookAt(Vec3 eye, Vec3 center, Vec3 worldUp) {
        Vec3 f = (center - eye).normalize();
        Vec3 r = f.cross(worldUp).normalize();
        Vec3 u = r.cross(f);
        Mat4 m;
        m.at(0,0)=r.x; m.at(0,1)=r.y; m.at(0,2)=r.z; m.at(0,3)=-r.dot(eye);
        m.at(1,0)=u.x; m.at(1,1)=u.y; m.at(1,2)=u.z; m.at(1,3)=-u.dot(eye);
        m.at(2,0)=-f.x;m.at(2,1)=-f.y;m.at(2,2)=-f.z;m.at(2,3)= f.dot(eye);
        m.at(3,0)=0;   m.at(3,1)=0;   m.at(3,2)=0;   m.at(3,3)=1;
        return m;
    }

    static Mat4 translate(Vec3 t) {
        Mat4 r;
        r.at(0,3) = t.x; r.at(1,3) = t.y; r.at(2,3) = t.z;
        return r;
    }
};

// ── Plane (for frustum culling) ───────────────────────────────────────────────
struct Plane {
    float a, b, c, d; // ax+by+cz+d >= 0 means inside

    void normalize() {
        float len = sqrtf(a*a + b*b + c*c);
        if (len > 1e-6f) { a/=len; b/=len; c/=len; d/=len; }
    }

    // Distance from point to plane (positive = inside)
    float distanceTo(Vec3 p) const { return a*p.x + b*p.y + c*p.z + d; }
};

// ── Frustum ───────────────────────────────────────────────────────────────────
struct Frustum {
    Plane planes[6]; // left, right, bottom, top, near, far

    // Build from VP matrix using Gribb-Hartmann method
    void extractFromVP(const Mat4& vp) {
        // Row i of the matrix
        auto row = [&](int i) -> float* {
            static float tmp[4];
            // column-major: row i is m[i], m[i+4], m[i+8], m[i+12]
            tmp[0]=vp.m[i]; tmp[1]=vp.m[i+4]; tmp[2]=vp.m[i+8]; tmp[3]=vp.m[i+12];
            return tmp;
        };

        // Helper: row[r] coefficients
        float r0[4] = {vp.m[0], vp.m[4], vp.m[8],  vp.m[12]};
        float r1[4] = {vp.m[1], vp.m[5], vp.m[9],  vp.m[13]};
        float r2[4] = {vp.m[2], vp.m[6], vp.m[10], vp.m[14]};
        float r3[4] = {vp.m[3], vp.m[7], vp.m[11], vp.m[15]};

        // Left:   r3 + r0
        planes[0] = {r3[0]+r0[0], r3[1]+r0[1], r3[2]+r0[2], r3[3]+r0[3]};
        // Right:  r3 - r0
        planes[1] = {r3[0]-r0[0], r3[1]-r0[1], r3[2]-r0[2], r3[3]-r0[3]};
        // Bottom: r3 + r1
        planes[2] = {r3[0]+r1[0], r3[1]+r1[1], r3[2]+r1[2], r3[3]+r1[3]};
        // Top:    r3 - r1
        planes[3] = {r3[0]-r1[0], r3[1]-r1[1], r3[2]-r1[2], r3[3]-r1[3]};
        // Near:   r3 + r2
        planes[4] = {r3[0]+r2[0], r3[1]+r2[1], r3[2]+r2[2], r3[3]+r2[3]};
        // Far:    r3 - r2
        planes[5] = {r3[0]-r2[0], r3[1]-r2[1], r3[2]-r2[2], r3[3]-r2[3]};

        for (auto& p : planes) p.normalize();
    }

    // Test AABB (min, max corners) against frustum — true if potentially visible
    bool testAABB(Vec3 mn, Vec3 mx) const {
        for (const auto& pl : planes) {
            // Find the "positive vertex" (most aligned with plane normal)
            float px = pl.a >= 0 ? mx.x : mn.x;
            float py = pl.b >= 0 ? mx.y : mn.y;
            float pz = pl.c >= 0 ? mx.z : mn.z;
            if (pl.a*px + pl.b*py + pl.c*pz + pl.d < 0) return false;
        }
        return true;
    }
};
