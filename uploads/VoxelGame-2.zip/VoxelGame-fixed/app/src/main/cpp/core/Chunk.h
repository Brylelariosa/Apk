#pragma once
#include <cstdint>
#include <vector>
#include <atomic>
#include <mutex>
#include <GLES3/gl3.h>
#include "Block.h"
#include "Noise.h"

// ── Chunk dimensions ──────────────────────────────────────────────────────────
static constexpr int CHUNK_W = 16;
static constexpr int CHUNK_H = 64;
static constexpr int CHUNK_D = 16;

// ── Packed vertex: 5 floats (position + color) ────────────────────────────────
struct Vertex {
    float x, y, z;   // world-space position (chunk-local offset added at build time)
    float r, g, b;   // pre-lit color
};

// ── Chunk states ──────────────────────────────────────────────────────────────
enum class ChunkState : int {
    EMPTY     = 0,
    GENERATED = 1,   // block data filled
    MESHED    = 2,   // CPU mesh ready to upload
    READY     = 3,   // GPU buffers uploaded
};

class World; // forward declaration

// ── Chunk ─────────────────────────────────────────────────────────────────────
class Chunk {
public:
    int cx, cz;   // chunk coordinates (world tile index, not pixel)

    // Block data
    BlockType blocks[CHUNK_W * CHUNK_H * CHUNK_D];

    // CPU-side mesh (built on any thread, uploaded on GL thread)
    std::vector<Vertex>   vertices;
    std::vector<uint32_t> indices;
    std::mutex            meshMutex;

    // GL objects
    GLuint vao = 0, vbo = 0, ebo = 0;
    int    indexCount = 0;

    std::atomic<ChunkState> state{ChunkState::EMPTY};

    Chunk(int cx, int cz);
    ~Chunk();

    // ── Block accessors ───────────────────────────────────────────────────────
    BlockType getBlock(int x, int y, int z) const;
    void      setBlock(int x, int y, int z, BlockType t);

    // ── Generation ────────────────────────────────────────────────────────────
    void generate(const Noise& noise);

    // ── Mesh building (greedy meshing, thread-safe output) ────────────────────
    // Pass adjacent chunk pointers (may be nullptr → assume solid at edge)
    void buildMesh(const Chunk* nx, const Chunk* px,
                   const Chunk* nz, const Chunk* pz);

    // ── GPU upload (must be called on GL thread) ──────────────────────────────
    void uploadMesh();

    // ── Render ────────────────────────────────────────────────────────────────
    void render() const;

    // ── AABB helpers ─────────────────────────────────────────────────────────
    void getAABB(float& minX, float& minY, float& minZ,
                 float& maxX, float& maxY, float& maxZ) const;

private:
    static int blockIdx(int x, int y, int z) {
        return x + CHUNK_W * (z + CHUNK_D * y);
    }

    // Get block from neighbor chunk (handles out-of-range x/z)
    BlockType neighborBlock(int x, int y, int z,
                            const Chunk* nx, const Chunk* px,
                            const Chunk* nz, const Chunk* pz) const;

    // Add a quad (4 verts, 2 tris) into the mesh vectors
    void addQuad(float x0, float y0, float z0,
                 float dx1, float dy1, float dz1,
                 float dx2, float dy2, float dz2,
                 BlockType type, int face,
                 std::vector<Vertex>& verts,
                 std::vector<uint32_t>& inds) const;
};
