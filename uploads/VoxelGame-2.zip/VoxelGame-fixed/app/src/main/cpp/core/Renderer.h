#pragma once
#include <GLES3/gl3.h>
#include "Camera.h"
#include "World.h"

class Renderer {
public:
    Camera camera;
    World  world;

    bool initialized = false;

    // Call once on GL thread after surface creation
    void init();

    // Call when surface size changes
    void resize(int width, int height);

    // Call every frame (on GL thread)
    void render(float dt);

    ~Renderer();

private:
    GLuint shaderProgram = 0;
    GLint  uMVP          = -1;

    // Sky / fog color
    static constexpr float SKY_R = 0.52f;
    static constexpr float SKY_G = 0.77f;
    static constexpr float SKY_B = 0.95f;

    // HUD: simple crosshair overlay
    GLuint hudShader  = 0;
    GLuint hudVao     = 0;
    GLuint hudVbo     = 0;
    void   initHUD();
    void   renderHUD();

    GLuint compileShader(GLenum type, const char* src);
    GLuint linkProgram(GLuint vert, GLuint frag);
};
