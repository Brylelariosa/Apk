package com.voxelgame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

/**
 * Transparent overlay drawn on top of the GLSurfaceView.
 * Renders virtual joystick circles; all touch events fall through to the surface below.
 */
public class JoystickOverlay extends View {

    // --- visual constants ---
    private static final float BASE_RADIUS  = 110f;  // outer ring radius  (px)
    private static final float THUMB_RADIUS =  48f;  // inner knob radius  (px)
    private static final float STROKE_W     =   5f;

    private final Paint ringPaint  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint   = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Left joystick state
    private boolean leftActive;
    private float   leftBaseX, leftBaseY, leftThumbX, leftThumbY;

    // Right joystick state
    private boolean rightActive;
    private float   rightBaseX, rightBaseY, rightThumbX, rightThumbY;

    public JoystickOverlay(Context context) {
        super(context);
        setFocusable(false);
        setClickable(false);

        // Outer ring: semi-transparent white outline
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(STROKE_W);
        ringPaint.setColor(Color.argb(160, 255, 255, 255));

        // Filled knob
        thumbPaint.setStyle(Paint.Style.FILL);
        thumbPaint.setColor(Color.argb(130, 255, 255, 255));

        // Centre dot of the base ring
        dotPaint.setStyle(Paint.Style.FILL);
        dotPaint.setColor(Color.argb(90, 255, 255, 255));
    }

    // ── State update methods (called from GameSurfaceView on the UI thread) ──

    public void updateLeft(boolean active,
                           float baseX, float baseY,
                           float thumbX, float thumbY) {
        leftActive = active;
        leftBaseX  = baseX;  leftBaseY  = baseY;
        leftThumbX = thumbX; leftThumbY = thumbY;
        postInvalidate();
    }

    public void updateRight(boolean active,
                            float baseX, float baseY,
                            float thumbX, float thumbY) {
        rightActive = active;
        rightBaseX  = baseX;  rightBaseY  = baseY;
        rightThumbX = thumbX; rightThumbY = thumbY;
        postInvalidate();
    }

    // ── Drawing ──────────────────────────────────────────────────────────────

    @Override
    protected void onDraw(Canvas canvas) {
        if (leftActive) {
            // Base ring + centre dot
            canvas.drawCircle(leftBaseX,  leftBaseY,  BASE_RADIUS,  ringPaint);
            canvas.drawCircle(leftBaseX,  leftBaseY,  8f,           dotPaint);
            // Thumb knob
            canvas.drawCircle(leftThumbX, leftThumbY, THUMB_RADIUS, thumbPaint);
        }
        if (rightActive) {
            canvas.drawCircle(rightBaseX,  rightBaseY,  BASE_RADIUS,  ringPaint);
            canvas.drawCircle(rightBaseX,  rightBaseY,  8f,           dotPaint);
            canvas.drawCircle(rightThumbX, rightThumbY, THUMB_RADIUS, thumbPaint);
        }
    }

    // ── Pass all touches through to the GLSurfaceView below ─────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return false;
    }
}
