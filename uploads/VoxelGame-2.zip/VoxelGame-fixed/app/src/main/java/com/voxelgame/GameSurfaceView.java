package com.voxelgame;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameSurfaceView extends GLSurfaceView {

    private final GameRenderer renderer;

    // ── Joystick overlay (set by MainActivity after construction) ─────────────
    private JoystickOverlay joystickOverlay;

    // ── Touch state (dual virtual joystick) ───────────────────────────────────
    private int   leftPointerId  = -1;
    private int   rightPointerId = -1;
    private float leftOriginX,  leftOriginY;
    private float rightOriginX, rightOriginY;

    private static final float DEAD_ZONE   = 10f;    // pixels
    private static final float MAX_RADIUS  = 110f;   // pixels (matches overlay BASE_RADIUS)
    private static final float LOOK_SENS   = 0.003f; // radians per pixel

    public GameSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);

        // RGBA8 + 24-bit depth – alpha=8 fixes incorrect compositing on screenshot
        setEGLConfigChooser(8, 8, 8, 8, 24, 0);

        // Keep the GL context alive during onPause so nativeInit is NOT called
        // again when the system takes a screenshot or the screen briefly blanks.
        // Without this, World::~World() sets g_pool.stop=true and the new World
        // created by the next nativeInit hangs in its busy-wait forever,
        // turning the screen solid sky-blue and appearing to crash.
        setPreserveEGLContextOnPause(true);

        renderer = new GameRenderer();
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    /** Called by MainActivity so the overlay can be updated from touch events. */
    public void setJoystickOverlay(JoystickOverlay overlay) {
        joystickOverlay = overlay;
    }

    // ── Touch handling ────────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final int action    = event.getActionMasked();
        final int actionIdx = event.getActionIndex();
        final int pid       = event.getPointerId(actionIdx);
        final float x       = event.getX(actionIdx);
        final float y       = event.getY(actionIdx);
        final float halfW   = getWidth() * 0.5f;

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (x < halfW && leftPointerId == -1) {
                    leftPointerId = pid;
                    leftOriginX = x;
                    leftOriginY = y;
                    if (joystickOverlay != null)
                        joystickOverlay.updateLeft(true, x, y, x, y);
                } else if (x >= halfW && rightPointerId == -1) {
                    rightPointerId = pid;
                    rightOriginX = x;
                    rightOriginY = y;
                    if (joystickOverlay != null)
                        joystickOverlay.updateRight(true, x, y, x, y);
                }
                break;

            case MotionEvent.ACTION_MOVE: {
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int   p  = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);

                    if (p == leftPointerId) {
                        // Movement joystick (forward / strafe)
                        float dx   = px - leftOriginX;
                        float dy   = py - leftOriginY;
                        float dist = (float) Math.sqrt(dx * dx + dy * dy);

                        float cdx = dx, cdy = dy;
                        if (dist > MAX_RADIUS) {
                            float scale = MAX_RADIUS / dist;
                            cdx *= scale;
                            cdy *= scale;
                        }

                        float fwd    = -cdy / MAX_RADIUS;
                        float strafe =  cdx / MAX_RADIUS;
                        if (dist < DEAD_ZONE) { fwd = 0; strafe = 0; }
                        nativeSetMovement(fwd, strafe);

                        if (joystickOverlay != null)
                            joystickOverlay.updateLeft(true,
                                    leftOriginX, leftOriginY,
                                    leftOriginX + cdx, leftOriginY + cdy);

                    } else if (p == rightPointerId) {
                        // Look joystick (delta-based)
                        float dx = px - rightOriginX;
                        float dy = py - rightOriginY;
                        rightOriginX = px;
                        rightOriginY = py;
                        nativeSetLook(dx * LOOK_SENS, dy * LOOK_SENS);

                        // Thumb drifts from fixed origin, clamped to MAX_RADIUS
                        // We track cumulative offset for the visual.
                        // For simplicity: show thumb at current finger, clamped from base.
                        if (joystickOverlay != null) {
                            // base stays at the first-touch position; compute offset from it
                            float ox = px - (rightOriginX - dx);
                            float oy = py - (rightOriginY - dy);
                            float d2 = (float) Math.sqrt(ox * ox + oy * oy);
                            if (d2 > MAX_RADIUS) {
                                float s = MAX_RADIUS / d2;
                                ox *= s; oy *= s;
                            }
                            joystickOverlay.updateRight(true,
                                    rightOriginX - dx, rightOriginY - dy,
                                    (rightOriginX - dx) + ox,
                                    (rightOriginY - dy) + oy);
                        }
                    }
                }
                break;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pid == leftPointerId) {
                    leftPointerId = -1;
                    nativeSetMovement(0f, 0f);
                    if (joystickOverlay != null)
                        joystickOverlay.updateLeft(false, 0, 0, 0, 0);
                } else if (pid == rightPointerId) {
                    rightPointerId = -1;
                    if (joystickOverlay != null)
                        joystickOverlay.updateRight(false, 0, 0, 0, 0);
                }
                break;
        }
        return true;
    }

    // ── JNI (implemented in jni_bridge.cpp) ───────────────────────────────────
    public native void nativeSetMovement(float forward, float strafe);
    public native void nativeSetLook(float dyaw, float dpitch);
}
