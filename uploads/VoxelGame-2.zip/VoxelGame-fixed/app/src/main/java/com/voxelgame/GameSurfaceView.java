package com.voxelgame;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

/**
 * ONE fixed-position movement joystick on the left half.
 *   • "Locked"   – the base never moves; it sits at a fixed screen position.
 *   • "Infinite" – there is no MAX_RADIUS clamp.  The direction is always
 *                  normalised so movement speed is constant regardless of how
 *                  far the finger drifts from the base.  The visual thumb is
 *                  clamped to the ring for display only.
 *
 * Right half = free-look swipe zone, no joystick visual shown there.
 */
public class GameSurfaceView extends GLSurfaceView {

    private final GameRenderer renderer;

    private JoystickOverlay joystickOverlay;

    // ── Fixed joystick centre ─────────────────────────────────────────────────
    private float joyCX = 0f, joyCY = 0f;  // initialised in onSizeChanged
    private static final float VISUAL_RADIUS = 100f; // pixels – thumb clamp for display
    private static final float DEAD_ZONE     =  12f; // pixels

    // ── Touch state ───────────────────────────────────────────────────────────
    private int   leftPid  = -1;   // movement finger
    private int   rightPid = -1;   // look finger

    private float rightPrevX, rightPrevY;
    private static final float LOOK_SENS = 0.003f;

    public GameSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 24, 0);

        // Preserve EGL context across onPause so nativeInit is not called again
        // on screenshot, preventing the g_pool re-init hang / blue-screen crash.
        setPreserveEGLContextOnPause(true);

        renderer = new GameRenderer();
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    public void setJoystickOverlay(JoystickOverlay overlay) {
        joystickOverlay = overlay;
        // If size is already known, push the centre immediately
        if (joyCX > 0) overlay.setCenter(joyCX, joyCY);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // Fixed joystick: bottom-left quadrant, well clear of edges
        joyCX = w * 0.14f;
        joyCY = h * 0.75f;
        if (joystickOverlay != null) joystickOverlay.setCenter(joyCX, joyCY);
    }

    // ── Touch ─────────────────────────────────────────────────────────────────

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        final int action    = event.getActionMasked();
        final int actionIdx = event.getActionIndex();
        final int pid       = event.getPointerId(actionIdx);
        final float x       = event.getX(actionIdx);
        final float y       = event.getY(actionIdx);
        final float halfW   = getWidth() * 0.5f;

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if (x < halfW && leftPid == -1) {
                    leftPid = pid;
                    handleMovement(x, y);
                } else if (x >= halfW && rightPid == -1) {
                    rightPid   = pid;
                    rightPrevX = x;
                    rightPrevY = y;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < event.getPointerCount(); i++) {
                    int   p  = event.getPointerId(i);
                    float px = event.getX(i);
                    float py = event.getY(i);

                    if (p == leftPid) {
                        handleMovement(px, py);
                    } else if (p == rightPid) {
                        float dx = px - rightPrevX;
                        float dy = py - rightPrevY;
                        rightPrevX = px;
                        rightPrevY = py;
                        nativeSetLook(dx * LOOK_SENS, dy * LOOK_SENS);
                    }
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL:
                if (pid == leftPid) {
                    leftPid = -1;
                    nativeSetMovement(0f, 0f);
                    if (joystickOverlay != null)
                        joystickOverlay.update(false, joyCX, joyCY);
                } else if (pid == rightPid) {
                    rightPid = -1;
                }
                break;
        }
        return true;
    }

    /**
     * Infinite joystick: direction is always normalised (constant speed).
     * The base is fixed at (joyCX, joyCY) regardless of where the finger lands.
     */
    private void handleMovement(float fx, float fy) {
        float dx   = fx - joyCX;
        float dy   = fy - joyCY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        float fwd = 0f, strafe = 0f;
        if (dist > DEAD_ZONE) {
            // Normalise → infinite radius (always full speed)
            fwd    = -dy / dist;
            strafe =  dx / dist;
        }
        nativeSetMovement(fwd, strafe);

        // Visual: clamp thumb to ring radius for display purposes only
        float vx = joyCX, vy = joyCY;
        if (dist > DEAD_ZONE) {
            float clamp = Math.min(dist, VISUAL_RADIUS);
            vx = joyCX + dx / dist * clamp;
            vy = joyCY + dy / dist * clamp;
        }
        if (joystickOverlay != null)
            joystickOverlay.update(true, vx, vy);
    }

    // ── JNI ───────────────────────────────────────────────────────────────────
    public native void nativeSetMovement(float forward, float strafe);
    public native void nativeSetLook(float dyaw, float dpitch);
}
