// CodeWave Studio - audio -> script analysis.
//
// Takes decoded mono PCM (from an mp3 / m4a / wav ... decoded by the platform) and writes a
// CodeWave script that approximates it:
//   * tones  - sinusoidal partials found by short-time spectral analysis and tracked over time
//              (each becomes one layer: oscillator + optional sweep + custom envelope), with
//              harmonic stacks collapsed into saw / square / triangle oscillators where the
//              harmonic amplitudes fit;
//   * noise  - what is left (drums, breath, hiss, rumble) as a few band-passed noise layers whose
//              level over time is fitted with envelope.custom.
// The result is an approximation, not a copy: it is the same kind of code a person would write
// to imitate the sound, and it always stays inside the engine's script limits.
#pragma once

#include <cstddef>
#include <string>

namespace cw {

struct AnalyzeOptions {
  int detail = 1;             // 0 = simple, 1 = normal, 2 = detailed
  std::string name;           // source name for the header comment (sanitised before use)
  double startSeconds = 0.0;  // where in the source file the analysed part starts (header only)
};

struct AnalyzeResult {
  bool ok = false;
  std::string error;    // set when !ok
  std::string script;   // set when ok
  std::string summary;  // one line for the UI, e.g. "42 tones + 5 noise bands, 3.2 s"
  int tones = 0;
  int noiseBands = 0;
  int commands = 0;
  double seconds = 0.0;
};

// `mono` holds `frames` samples at `sampleRate` Hz. At most the first 120 seconds are used.
AnalyzeResult analyzeAudioToScript(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt);

}  // namespace cw
