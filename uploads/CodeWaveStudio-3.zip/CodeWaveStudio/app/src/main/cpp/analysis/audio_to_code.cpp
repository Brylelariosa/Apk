// CodeWave Studio - audio -> script analysis. See audio_to_code.h.
//
// Pipeline (all on a worker thread, a few hundred ms for 30 s of audio):
//   1. clean-up   : DC removal, peak normalise, trim leading / trailing silence, <= 120 s
//   2. tones      : long-window STFT -> sinusoidal peaks -> partial tracks -> one layer per track
//   3. harmonics  : stacks of partials that look like a saw / square / triangle become one oscillator
//   4. noise      : short-window STFT, tonal energy removed, band levels fitted with non-negative
//                   least squares against the real band-pass filters -> filtered-noise layers
//   5. emit       : strongest parts first until a command / size / CPU budget is used up
#include "audio_to_code.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <new>
#include <numeric>
#include <string>
#include <utility>
#include <vector>

#include "../dsp/dsp.h"

namespace cw {
namespace {

constexpr double kMaxAnalysisSec = 120.0;  // the engine's longest sound
constexpr int kMaxCommandsUsed = 1900;   // engine limit is 2000
constexpr int kMaxLayersUsed = 950;      // engine limit is 1024 layer instances
constexpr size_t kMaxScriptChars = 88000;  // editor limit is 100000, engine limit 128 KB
constexpr double kProminence = 4.0;        // a tone peak must stand this far above its spectral neighbourhood

// ------------------------------------------------------------------ detail levels
struct Params {
  double dynDb;        // a frame's peaks must be within this of the frame's strongest peak
  double floorDb;      // absolute floor for tone peaks, relative to the (normalised) input peak
  double toneRelDb;    // keep tones whose peak is within this of the strongest tone
  int maxPeaks;        // peaks kept per frame
  int minFrames;       // shortest tone, in analysis frames
  int envPoints;       // envelope points per tone (engine allows 16)
  double envTolDb;     // envelope fit tolerance
  int nBands;          // noise bands
  double noiseRelDb;   // noise bands below this (vs the loudest part) are dropped
  int noiseChunksPerBand;
  int cmdBudget;
  double layerSecBudget;  // total layer-seconds, keeps the render fast on phones
  const char* label;
};

const Params& paramsFor(int detail) {
  static const Params kP[3] = {
      {30, -50, 24, 8, 4, 10, 4.0, 4, 30, 2, 420, 120, "Simple"},
      {40, -60, 32, 16, 3, 12, 2.5, 6, 38, 5, 1100, 260, "Normal"},
      {50, -70, 44, 28, 2, 16, 1.5, 8, 46, 9, 1850, 440, "Detailed"},
  };
  return kP[detail < 0 ? 0 : (detail > 2 ? 2 : detail)];
}

inline int nextPow2(int v) {
  int p = 1;
  while (p < v) p <<= 1;
  return p;
}

// ------------------------------------------------------------------ formatting
std::string fmt(double v, int decimals) {
  char buf[64];
  std::snprintf(buf, sizeof buf, "%.*f", decimals, v);
  std::string s(buf);
  if (s.find('.') != std::string::npos) {
    while (!s.empty() && s.back() == '0') s.pop_back();
    if (!s.empty() && s.back() == '.') s.pop_back();
  }
  if (s.empty() || s == "-0") s = "0";
  return s;
}
inline double round3(double v) { return std::round(v * 1000.0) / 1000.0; }
std::string fmtHz(double hz) { return fmt(hz, hz >= 100.0 ? 1 : 2); }
std::string fmtVol(double v) { return fmt(v, v < 0.01 ? 4 : 3); }

std::string noteName(double hz) {
  static const char* names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
  if (hz < 8.0) return "";
  const long m = std::lround(69.0 + 12.0 * std::log2(hz / 440.0));
  const long pc = ((m % 12) + 12) % 12;
  const long oct = (m - pc) / 12 - 1;
  return std::string(names[pc]) + std::to_string(oct);
}

std::string clock(double sec) {
  char buf[32];
  if (sec < 100.0) {
    std::snprintf(buf, sizeof buf, "%.1f s", sec);
  } else {
    const int s = (int)std::floor(sec + 0.5);
    std::snprintf(buf, sizeof buf, "%d:%02d", s / 60, s % 60);
  }
  return buf;
}

// Keeps the name safe for a one-line comment: printable ASCII only, no newlines, short.
std::string sanitizeName(const std::string& in) {
  std::string out;
  size_t from = in.find_last_of("/\\");
  from = from == std::string::npos ? 0 : from + 1;
  for (size_t i = from; i < in.size(); ++i) {
    const char c = in[i];
    if (out.size() >= 48) break;
    const unsigned char u = (unsigned char)c;
    out += (u >= 32 && u < 127 && c != '"' && c != '\\') ? c : '_';
  }
  return out;
}

// ------------------------------------------------------------------------- FFT
struct Fft {
  int n;
  std::vector<double> c, s;
  std::vector<int> rev;
  explicit Fft(int size) : n(size), c(size / 2), s(size / 2), rev(size) {
    for (int i = 0; i < n / 2; ++i) {
      c[i] = std::cos(kTwoPi * i / n);
      s[i] = -std::sin(kTwoPi * i / n);
    }
    int bits = 0;
    while ((1 << bits) < n) ++bits;
    for (int i = 0; i < n; ++i) {
      int r = 0;
      for (int b = 0; b < bits; ++b)
        if (i & (1 << b)) r |= 1 << (bits - 1 - b);
      rev[i] = r;
    }
  }
  void run(double* re, double* im) const {
    for (int i = 0; i < n; ++i) {
      const int j = rev[i];
      if (j > i) {
        std::swap(re[i], re[j]);
        std::swap(im[i], im[j]);
      }
    }
    for (int len = 2; len <= n; len <<= 1) {
      const int half = len / 2, step = n / len;
      for (int i = 0; i < n; i += len) {
        for (int k = 0; k < half; ++k) {
          const double wr = c[k * step], wi = s[k * step];
          const int a = i + k, b = a + half;
          const double xr = re[b] * wr - im[b] * wi;
          const double xi = re[b] * wi + im[b] * wr;
          re[b] = re[a] - xr;
          im[b] = im[a] - xi;
          re[a] += xr;
          im[a] += xi;
        }
      }
    }
  }
};

// Hann-window STFT. Frame f is centred on sample f*H (zero padded at both ends). Two real frames
// share one complex FFT. cb(frame, |X|[0..N/2]) gets the raw (unnormalised) magnitudes.
// Normalisation for Hann: amplitude of a sine = |X| * 4/N ; variance share = |X|^2 * 16/(3 N^2) / (N/2 bins).
template <class Fn>
void forEachFrame(const std::vector<float>& x, int N, int H, Fn cb) {
  Fft fft(N);
  std::vector<double> win(N);
  for (int i = 0; i < N; ++i) win[i] = 0.5 - 0.5 * std::cos(kTwoPi * i / N);
  const long n = (long)x.size();
  const int frames = (int)(n / H) + 2;
  std::vector<double> re(N), im(N);
  std::vector<float> ma(N / 2 + 1), mb(N / 2 + 1);
  for (int f = 0; f < frames; f += 2) {
    const bool hasB = f + 1 < frames;
    for (int i = 0; i < N; ++i) {
      const long ia = (long)f * H - N / 2 + i;
      const long ib = (long)(f + 1) * H - N / 2 + i;
      re[i] = (ia >= 0 && ia < n) ? x[(size_t)ia] * win[i] : 0.0;
      im[i] = (hasB && ib >= 0 && ib < n) ? x[(size_t)ib] * win[i] : 0.0;
    }
    fft.run(re.data(), im.data());
    for (int k = 0; k <= N / 2; ++k) {
      const int m = (N - k) & (N - 1);
      const double zr = re[k], zi = im[k], yr = re[m], yi = im[m];
      ma[k] = (float)(0.5 * std::hypot(zr + yr, zi - yi));
      mb[k] = (float)(0.5 * std::hypot(zr - yr, zi + yi));
    }
    cb(f, ma.data());
    if (hasB) cb(f + 1, mb.data());
  }
}

// ------------------------------------------------------------------ noise bands
struct Bands {
  int nb = 0;
  std::vector<double> edge;    // nb + 1
  std::vector<double> center;  // nb
  std::vector<double> q;       // nb (per biquad, 2 biquads in series)
};

Bands makeBands(int nb, int sr) {
  Bands B;
  const double flo = 60.0;
  const double fhi = std::min(0.45 * sr, 16000.0);
  while (nb > 2 && fhi / flo < std::pow(1.8, nb)) --nb;
  B.nb = nb;
  B.edge.resize(nb + 1);
  for (int j = 0; j <= nb; ++j) B.edge[j] = flo * std::pow(fhi / flo, (double)j / nb);
  for (int j = 0; j < nb; ++j) {
    const double lo = B.edge[j], hi = B.edge[j + 1];
    const double fc = std::sqrt(lo * hi);
    B.center.push_back(fc);
    B.q.push_back(clampd(0.7 * fc / (hi - lo), 0.3, 12.0));
  }
  return B;
}

std::vector<int> bandOfBin(const Bands& B, int N, int sr) {
  std::vector<int> r(N / 2 + 1, -1);
  for (int k = 1; k <= N / 2; ++k) {
    const double f = (double)k * sr / N;
    for (int j = 0; j < B.nb; ++j)
      if (f >= B.edge[j] && f < B.edge[j + 1]) {
        r[k] = j;
        break;
      }
  }
  return r;
}

// M[j][i]: share of the variance of white noise, filtered by band filter i, that lands in analysis band j.
std::vector<double> bandMixMatrix(const Bands& B, int sr) {
  const int G = 4096;
  std::vector<double> M((size_t)B.nb * B.nb, 0.0);
  for (int i = 0; i < B.nb; ++i) {
    const BiquadCoef co = designBiquad(FilterType::Band, B.center[i], B.q[i], sr);
    for (int g = 0; g < G; ++g) {
      const double w = kPi * (g + 0.5) / G;
      const double f = w * sr / kTwoPi;
      int j = -1;
      for (int t = 0; t < B.nb; ++t)
        if (f >= B.edge[t] && f < B.edge[t + 1]) {
          j = t;
          break;
        }
      if (j < 0) continue;
      const double c1 = std::cos(w), s1 = std::sin(w), c2 = std::cos(2 * w), s2 = std::sin(2 * w);
      const double nr = co.b0 + co.b1 * c1 + co.b2 * c2, ni = -(co.b1 * s1 + co.b2 * s2);
      const double dr = 1.0 + co.a1 * c1 + co.a2 * c2, di = -(co.a1 * s1 + co.a2 * s2);
      const double h2 = (nr * nr + ni * ni) / (dr * dr + di * di);
      M[(size_t)j * B.nb + i] += h2 * h2 / G;  // two biquads in series
    }
  }
  return M;
}

// ---------------------------------------------------------------- tonal analysis
struct Peak {
  float freq, amp, var;  // Hz, linear amplitude (input peak = 1), variance within +-2 bins
  bool used;             // belongs to a kept tone (its energy is removed from the noise estimate)
};

struct Tonal {
  int N = 0, H = 0, F = 0;
  double binHz = 0, hopSec = 0;
  std::vector<std::vector<Peak>> peaks;  // per frame
  std::vector<float> bandVar;            // F * nb, long-window variance share per noise band
};

void analyseTonal(const std::vector<float>& x, int sr, double dur, const Params& P, const Bands& B, Tonal& T) {
  const int n = (int)x.size();
  T.N = std::min(8192, std::max(512, nextPow2((int)std::lround((dur > 4.0 ? 0.09 : (dur > 1.5 ? 0.046 : 0.023)) * sr))));
  T.H = T.N / 4;
  T.F = n / T.H + 2;
  T.binHz = (double)sr / T.N;
  T.hopSec = (double)T.H / sr;
  T.peaks.assign((size_t)T.F, std::vector<Peak>());
  T.bandVar.assign((size_t)T.F * B.nb, 0.0f);
  const std::vector<int> bandOf = bandOfBin(B, T.N, sr);
  const int half = T.N / 2;
  const double ampScale = 4.0 / T.N;
  const double powNorm = 16.0 / (3.0 * (double)T.N * (double)T.N);
  const int kMin = std::max(3, (int)std::ceil(30.0 / T.binHz));
  const int kMax = std::min(half - 3, (int)std::floor(std::min(0.45 * sr, 14000.0) / T.binHz));
  const double absFloor = std::pow(10.0, P.floorDb / 20.0);
  const double dynMul = std::pow(10.0, -P.dynDb / 20.0);
  std::vector<double> pre((size_t)half + 2);

  forEachFrame(x, T.N, T.H, [&](int f, const float* mag) {
    float* bv = &T.bandVar[(size_t)f * B.nb];
    for (int k = 1; k <= half; ++k) {
      const int b = bandOf[k];
      if (b >= 0) bv[b] += (float)((double)mag[k] * mag[k] * powNorm);
    }
    pre[0] = 0.0;
    for (int k = 0; k <= half; ++k) pre[(size_t)k + 1] = pre[(size_t)k] + mag[k];
    float mx = 0.0f;
    for (int k = kMin; k <= kMax; ++k) mx = std::max(mx, mag[k]);
    if (mx * ampScale < absFloor) return;
    const float thr = (float)std::max((double)mx * dynMul, absFloor / ampScale);
    std::vector<Peak>& out = T.peaks[(size_t)f];
    for (int k = kMin; k <= kMax; ++k) {
      const float m = mag[k];
      if (m < thr || m <= mag[k - 1] || m < mag[k + 1]) continue;
      // A windowed sinusoid has a narrow main lobe; noise peaks do not.
      if (mag[k - 2] > 0.4f * m || mag[k + 2] > 0.4f * m) continue;
      const int lo = std::max(0, k - 16), hi = std::min(half, k + 16);
      const double local = (pre[(size_t)hi + 1] - pre[(size_t)lo]) - (pre[(size_t)k + 3] - pre[(size_t)k - 2]);
      const int cnt = (hi - lo + 1) - 5;
      if (cnt > 0 && (double)m < kProminence * local / cnt) continue;
      const double a = std::log((double)mag[k - 1] + 1e-12), b = std::log((double)m + 1e-12),
                   c = std::log((double)mag[k + 1] + 1e-12);
      const double den = a - 2.0 * b + c;
      const double p = den < -1e-9 ? clampd(0.5 * (a - c) / den, -0.5, 0.5) : 0.0;
      Peak pk;
      pk.freq = (float)((k + p) * T.binHz);
      pk.amp = (float)(std::exp(b - 0.25 * (a - c) * p) * ampScale);
      double v = 0.0;
      for (int j = k - 2; j <= k + 2; ++j) v += (double)mag[j] * mag[j];
      pk.var = (float)(v * powNorm);
      pk.used = false;
      out.push_back(pk);
    }
    std::sort(out.begin(), out.end(), [](const Peak& a, const Peak& b) { return a.amp > b.amp; });
    if ((int)out.size() > P.maxPeaks) out.resize((size_t)P.maxPeaks);
  });
}

// ------------------------------------------------------------------- tracking
struct TrackPt {
  int frame, pk;
  float freq, amp;
};
struct Track {
  std::vector<TrackPt> pts;
  double lastSt = 0.0, vel = 0.0;
  int lastFrame = 0, missed = 0;
  bool ended = false;
};

inline double semis(double hz) { return 12.0 * std::log2(hz); }

std::vector<Track> trackPartials(const Tonal& T, const Params& P) {
  std::vector<Track> done, act;
  struct Cand {
    float d;
    int t, p;
  };
  std::vector<Cand> cands;
  std::vector<char> pkUsed, trUsed;
  const int maxGap = 2;

  for (int f = 0; f < T.F; ++f) {
    const std::vector<Peak>& pk = T.peaks[(size_t)f];
    cands.clear();
    for (size_t t = 0; t < act.size(); ++t) {
      const Track& tr = act[t];
      const double pred = tr.lastSt + tr.vel * (f - tr.lastFrame);
      const size_t len = tr.pts.size();
      const double tol = (len == 1 ? 8.0 : (len == 2 ? 3.0 : 1.3)) + 0.4 * tr.missed;
      for (size_t p = 0; p < pk.size(); ++p) {
        const double d = std::fabs(semis(pk[p].freq) - pred);
        if (d <= tol) cands.push_back({(float)d, (int)t, (int)p});
      }
    }
    std::sort(cands.begin(), cands.end(), [](const Cand& a, const Cand& b) { return a.d < b.d; });
    pkUsed.assign(pk.size(), 0);
    trUsed.assign(act.size(), 0);
    std::vector<Track> spawn;
    for (const Cand& c : cands) {
      if (pkUsed[(size_t)c.p] || trUsed[(size_t)c.t]) continue;
      pkUsed[(size_t)c.p] = 1;
      trUsed[(size_t)c.t] = 1;
      Track& tr = act[(size_t)c.t];
      const Peak& p = pk[(size_t)c.p];
      const size_t n = tr.pts.size();
      const double st = semis(p.freq);
      // A sharp new attack on an already decaying / steady partial starts a new note.
      if (n >= 3) {
        const float a1 = tr.pts[n - 1].amp, a2 = tr.pts[n - 2].amp;
        if (p.amp >= 1.7f * a1 && a1 <= 1.1f * a2) {
          tr.ended = true;
          Track nt;
          nt.pts.push_back({f, c.p, p.freq, p.amp});
          nt.lastSt = st;
          nt.lastFrame = f;
          spawn.push_back(std::move(nt));
          continue;
        }
      }
      const double v = (st - tr.lastSt) / (double)(f - tr.lastFrame);
      tr.vel = clampd(n == 1 ? v : 0.6 * tr.vel + 0.4 * v, -4.0, 4.0);
      tr.lastSt = st;
      tr.lastFrame = f;
      tr.missed = 0;
      tr.pts.push_back({f, c.p, p.freq, p.amp});
    }
    for (size_t t = 0; t < act.size(); ++t)
      if (!trUsed[t]) ++act[t].missed;
    for (size_t p = 0; p < pk.size(); ++p) {
      if (pkUsed[p]) continue;
      Track nt;
      nt.pts.push_back({f, (int)p, pk[p].freq, pk[p].amp});
      nt.lastSt = semis(pk[p].freq);
      nt.lastFrame = f;
      spawn.push_back(std::move(nt));
    }
    std::vector<Track> next;
    next.reserve(act.size() + spawn.size());
    for (Track& tr : act) {
      if (tr.ended || tr.missed > maxGap) {
        if ((int)tr.pts.size() >= P.minFrames) done.push_back(std::move(tr));
      } else {
        next.push_back(std::move(tr));
      }
    }
    for (Track& tr : spawn) next.push_back(std::move(tr));
    act.swap(next);
  }
  for (Track& tr : act)
    if ((int)tr.pts.size() >= P.minFrames) done.push_back(std::move(tr));
  return done;
}

// Noise links jump around; real partials (steady, gliding or vibrato) have a smooth pitch curve.
bool smoothPitch(const Track& tr) {
  const size_t n = tr.pts.size();
  if (n < 3) return true;
  std::vector<double> d2;
  for (size_t i = 2; i < n; ++i) {
    const double a = semis(tr.pts[i].freq), b = semis(tr.pts[i - 1].freq), c = semis(tr.pts[i - 2].freq);
    d2.push_back(std::fabs(a - 2.0 * b + c));
  }
  std::nth_element(d2.begin(), d2.begin() + (long)d2.size() / 2, d2.end());
  const double med = d2[d2.size() / 2];
  return med < (n == 3 ? 0.8 : 0.5);
}

// -------------------------------------------------------------------- tones
using Pt2 = std::pair<double, double>;

struct Tone {
  double t0 = 0, len = 0;           // layer start / length, seconds
  double f0 = 0, f1 = 0, curve = 1; // Hz at the start / end of the layer (sweep when they differ)
  double amp = 0;                   // peak amplitude, input peak = 1
  std::vector<Pt2> env;             // (time since t0, 0..1)
  double score = 0;                 // energy, used to rank tones
  int wave = 0;                     // 0 sine, 1 saw, 2 square, 3 triangle, 4 pulse
  double width = 0.25;              // pulse width (wave 4)
  double lowpass = 0;               // Hz, 0 = none
  int harmonics = 0;                // number of partials merged into this oscillator
  bool dropped = false;
};

// Greedy piece-wise-linear fit of an envelope: keeps adding the point with the biggest error (in dB,
// judged against how the engine will interpolate - linearly in amplitude) until it is within `tolDb`.
std::vector<Pt2> simplifyEnvelope(const std::vector<Pt2>& in, int maxPts, double tolDb, double floorV) {
  const int n = (int)in.size();
  if (n <= 2) return in;
  auto dbv = [floorV](double v) { return 20.0 * std::log10(std::max(v, floorV)); };
  std::vector<int> sel = {0, n - 1};
  while ((int)sel.size() < maxPts) {
    double worst = 0.0;
    int wi = -1;
    for (size_t s = 0; s + 1 < sel.size(); ++s) {
      const int a = sel[s], b = sel[s + 1];
      const double span = std::max(1e-9, in[(size_t)b].first - in[(size_t)a].first);
      for (int i = a + 1; i < b; ++i) {
        const double u = (in[(size_t)i].first - in[(size_t)a].first) / span;
        const double v = in[(size_t)a].second + (in[(size_t)b].second - in[(size_t)a].second) * u;
        const double e = std::fabs(dbv(v) - dbv(in[(size_t)i].second));
        if (e > worst) {
          worst = e;
          wi = i;
        }
      }
    }
    if (wi < 0 || worst <= tolDb) break;
    sel.insert(std::upper_bound(sel.begin(), sel.end(), wi), wi);
  }
  std::vector<Pt2> out;
  out.reserve(sel.size());
  for (int i : sel) out.push_back(in[(size_t)i]);
  return out;
}

double sweepProg(double x, double curve) {
  x = clampd(x, 0.0, 1.0);
  return curve == 1.0 ? x : 1.0 - std::pow(1.0 - x, curve);
}

bool makeTone(const Track& tr, const Tonal& T, const Params& P, double dur, Tone& out) {
  int first = 0, last = (int)tr.pts.size() - 1;
  const std::vector<TrackPt>& pts = tr.pts;
  // Window smearing makes a note appear a little early / late with a tiny amplitude: trim that.
  while (last - first + 1 > P.minFrames && pts[(size_t)first].amp < 0.3f * pts[(size_t)first + 1].amp) ++first;
  while (last - first + 1 > P.minFrames && pts[(size_t)last].amp < 0.3f * pts[(size_t)last - 1].amp) --last;
  const int n = last - first + 1;
  if (n < 1) return false;
  double peak = 0.0, energy = 0.0;
  for (int i = first; i <= last; ++i) {
    peak = std::max(peak, (double)pts[(size_t)i].amp);
    energy += (double)pts[(size_t)i].amp * pts[(size_t)i].amp;
  }
  if (peak <= 0.0) return false;
  const double hop = T.hopSec;
  const double tFirst = pts[(size_t)first].frame * hop, tLast = pts[(size_t)last].frame * hop;
  const double ts = tFirst - 0.8 * hop, te = tLast + 0.8 * hop;
  const double t0 = round3(std::max(0.0, ts)), t1 = round3(std::min(dur, te));
  if (t1 - t0 < 0.01) return false;

  Tone t;
  t.t0 = t0;
  t.len = round3(t1 - t0);
  t.amp = peak;
  t.score = energy;

  // ---- envelope
  std::vector<Pt2> env;
  env.push_back({0.0, ts <= 0.0 ? (double)pts[(size_t)first].amp / peak : 0.0});
  for (int i = first; i <= last; ++i)
    env.push_back({std::max(0.0, std::min(t.len, pts[(size_t)i].frame * hop - t0)), (double)pts[(size_t)i].amp / peak});
  env.push_back({t.len, te >= dur ? (double)pts[(size_t)last].amp / peak : 0.0});
  for (size_t i = 1; i < env.size(); ++i) env[i].first = std::max(env[i].first, env[i - 1].first);
  t.env = simplifyEnvelope(env, P.envPoints, P.envTolDb, 0.01);

  // ---- pitch: steady, or one glide fitted with the engine's own sweep curve
  auto wmean = [&](int a, int b) {
    double sw = 0.0, ss = 0.0;
    for (int i = a; i <= b; ++i) {
      const double w = pts[(size_t)i].amp;
      sw += w;
      ss += w * semis(pts[(size_t)i].freq);
    }
    return ss / std::max(1e-12, sw);
  };
  double stMean = wmean(first, last);
  t.f0 = t.f1 = std::exp2(stMean / 12.0);
  if (n >= 4) {
    const int k = std::max(1, n / 4);
    const double stA = wmean(first, first + k - 1), stB = wmean(last - k + 1, last);
    if (std::fabs(stB - stA) >= 0.45) {
      // Extend the end-point averages to the layer edges (they sit about half a window inside).
      const double tA = pts[(size_t)first + (size_t)(k - 1) / 2].frame * hop;
      const double tB = pts[(size_t)last - (size_t)(k - 1) / 2].frame * hop;
      const double slope = (tB > tA) ? (stB - stA) / (tB - tA) : 0.0;
      const double stFrom = stA + slope * (t0 - tA), stTo = stB + slope * (t1 - tB);
      double bestErr = 1e300, bestC = 1.0;
      const double curves[] = {0.4, 0.6, 0.8, 1.0, 1.3, 1.7, 2.2, 3.0, 4.0};
      for (double c : curves) {
        double err = 0.0;
        for (int i = first; i <= last; ++i) {
          const double x = (pts[(size_t)i].frame * hop - t0) / t.len;
          const double pred = stFrom + (stTo - stFrom) * sweepProg(x, c);
          const double d = semis(pts[(size_t)i].freq) - pred;
          err += pts[(size_t)i].amp * d * d;
        }
        if (err < bestErr) {
          bestErr = err;
          bestC = c;
        }
      }
      t.f0 = std::exp2(stFrom / 12.0);
      t.f1 = std::exp2(stTo / 12.0);
      t.curve = bestC;
    }
  }
  t.f0 = clampd(t.f0, 20.0, 19000.0);
  t.f1 = clampd(t.f1, 20.0, 19000.0);
  out = std::move(t);
  return true;
}

// ----------------------------------------------------------------- harmonics
bool isSweep(const Tone& t) { return std::fabs(semis(t.f1) - semis(t.f0)) >= 0.45; }

// Amplitude of harmonic k relative to the fundamental, for the engine's oscillator shapes.
double harmonicTemplate(int wave, double width, int k) {
  switch (wave) {
    case 1: return 1.0 / k;                                 // saw
    case 2: return (k & 1) ? 1.0 / k : 0.0;                 // square
    case 3: return (k & 1) ? 1.0 / ((double)k * k) : 0.0;   // triangle
    default:                                                // pulse (DC-free)
      return std::fabs(std::sin(kPi * k * width)) / (k * std::sin(kPi * width));
  }
}
// Amplitude of the fundamental of a +-1 wave of that shape.
double fundamentalAmp(int wave, double width) {
  switch (wave) {
    case 1: return 2.0 / kPi;
    case 2: return 4.0 / kPi;
    case 3: return 8.0 / (kPi * kPi);
    default: return 2.0 / kPi * std::sin(kPi * width);
  }
}

// A stack of steady partials at 1x, 2x, 3x ... that starts and stops together and whose amplitudes follow
// a saw / square / triangle spectrum is replaced by that one oscillator (plus a low-pass when the stack
// stops short). Anything that does not fit stays a set of sine partials.
void groupHarmonics(std::vector<Tone>& tones) {
  const int n = (int)tones.size();
  std::vector<int> order((size_t)n);
  std::iota(order.begin(), order.end(), 0);
  std::sort(order.begin(), order.end(), [&](int a, int b) { return tones[(size_t)a].f0 < tones[(size_t)b].f0; });
  std::vector<double> sortedF((size_t)n);
  for (int i = 0; i < n; ++i) sortedF[(size_t)i] = tones[(size_t)order[(size_t)i]].f0;
  std::vector<char> claimed((size_t)n, 0);
  const int kSearch = 48;
  for (int idx : order) {
    Tone& A = tones[(size_t)idx];
    if (claimed[(size_t)idx] || A.dropped || A.wave != 0 || isSweep(A)) continue;
    std::vector<std::pair<int, int>> found;  // (harmonic number, tone index)
    for (int k = 2; k <= kSearch; ++k) {
      if (k * A.f0 > 19500.0) break;
      // absolute tolerance: at high harmonic numbers a relative one would accept almost any pitch
      const double tol = std::min(0.015 * k * A.f0, 0.12 * A.f0);
      const size_t lo = (size_t)(std::lower_bound(sortedF.begin(), sortedF.end(), k * A.f0 - tol) - sortedF.begin());
      const size_t hi = (size_t)(std::upper_bound(sortedF.begin(), sortedF.end(), k * A.f0 + tol) - sortedF.begin());
      int best = -1;
      for (size_t q = lo; q < hi; ++q) {
        const int j = order[q];
        if (j == idx || claimed[(size_t)j]) continue;
        const Tone& B = tones[(size_t)j];
        if (B.dropped || B.wave != 0 || isSweep(B)) continue;
        // a real harmonic starts and stops with its fundamental
        if (std::fabs(A.t0 - B.t0) > std::max(0.06, 0.15 * A.len)) continue;
        if (std::fabs((A.t0 + A.len) - (B.t0 + B.len)) > std::max(0.08, 0.25 * A.len)) continue;
        if (best < 0 || B.amp > tones[(size_t)best].amp) best = j;
      }
      if (best >= 0) found.push_back({k, best});
    }
    if (found.size() < 2) continue;
    const int kmax = found.back().first;
    if (kmax < 3) continue;
    struct Cand {
      int wave;
      double width;
    };
    static const Cand kCands[] = {{1, 0}, {2, 0}, {3, 0}, {4, 0.25}, {4, 0.125}, {4, 0.375}, {4, 0.2}, {4, 0.3333}, {4, 0.1}};
    int bestWave = 0;
    double bestWidth = 0.25, bestErr = 1e9;
    for (const Cand& cd : kCands) {
      double err = 0.0;
      int cnt = 0;
      for (int k = 2; k <= kmax; ++k) {
        double r = 0.03;
        for (const auto& f : found)
          if (f.first == k) r = std::max(0.03, tones[(size_t)f.second].amp / A.amp);
        const double t = std::max(0.03, harmonicTemplate(cd.wave, cd.width, k));
        err += std::fabs(20.0 * std::log10(r) - 20.0 * std::log10(t));
        ++cnt;
      }
      err /= std::max(1, cnt);
      if (err < bestErr - 0.3) {  // ties go to the simpler shape listed first
        bestErr = err;
        bestWave = cd.wave;
        bestWidth = cd.width;
      }
    }
    if (bestErr > 4.5) continue;
    A.wave = bestWave;
    A.width = bestWidth;
    A.amp = A.amp / fundamentalAmp(bestWave, bestWidth);
    A.lowpass = kmax >= 10 ? 0.0 : std::min(19000.0, (kmax + 1.5) * A.f0);
    A.harmonics = (int)found.size();
    for (const auto& f : found) {
      A.score += tones[(size_t)f.second].score;
      tones[(size_t)f.second].dropped = true;
      claimed[(size_t)f.second] = 1;
    }
    claimed[(size_t)idx] = 1;
  }
}

// -------------------------------------------------------------------- noise
struct NoiseChunk {
  double t0 = 0, len = 0;
  int band = 0;
  std::vector<Pt2> env;  // (time since t0, 0..1 of the band's loudest level)
};
struct NoiseBand {
  double vmax = 0;  // white-noise volume at the band's loudest moment (input peak = 1)
  std::vector<NoiseChunk> chunks;
};

// Fits, for every short frame, non-negative white-noise levels feeding the band filters so that the
// filtered result has the measured (tone-free) energy in every band. Multiplicative KL updates.
std::vector<std::vector<float>> analyseNoise(const std::vector<float>& x, int sr, const Bands& B, const Tonal& T,
                                             double* hopSecOut) {
  const int n = (int)x.size();
  const int nb = B.nb;
  const int Ns = std::min(2048, std::max(256, nextPow2((int)std::lround(0.02 * sr))));
  const int Hs = Ns / 4;
  const int Fs = n / Hs + 2;
  *hopSecOut = (double)Hs / sr;
  const std::vector<int> bandOfS = bandOfBin(B, Ns, sr);
  const std::vector<int> bandOfL = bandOfBin(B, T.N, sr);
  const double powNormS = 16.0 / (3.0 * (double)Ns * (double)Ns);

  // fraction of every long-window band that is NOT explained by kept tones
  std::vector<float> phi((size_t)T.F * nb, 1.0f);
  for (int f = 0; f < T.F; ++f) {
    std::vector<double> tv((size_t)nb, 0.0);
    for (const Peak& p : T.peaks[(size_t)f]) {
      if (!p.used) continue;
      const int k = (int)std::lround(p.freq / T.binHz);
      if (k >= 1 && k < (int)bandOfL.size() && bandOfL[(size_t)k] >= 0) tv[(size_t)bandOfL[(size_t)k]] += p.var;
    }
    for (int b = 0; b < nb; ++b) {
      const double tot = T.bandVar[(size_t)f * nb + b];
      double v = tot > 1e-14 ? 1.0 - tv[(size_t)b] / tot : 1.0;
      if (v < 0.04) v = 0.0;
      phi[(size_t)f * nb + b] = (float)clampd(v, 0.0, 1.0);
    }
  }

  std::vector<double> V((size_t)Fs * nb, 0.0);
  forEachFrame(x, Ns, Hs, [&](int f, const float* mag) {
    double* v = &V[(size_t)f * nb];
    for (int k = 1; k <= Ns / 2; ++k) {
      const int b = bandOfS[(size_t)k];
      if (b >= 0) v[b] += (double)mag[k] * mag[k] * powNormS;
    }
    const double u = (double)f * Hs / T.H;
    const int i0 = std::min(T.F - 1, (int)std::floor(u));
    const int i1 = std::min(T.F - 1, i0 + 1);
    const double fr = u - std::floor(u);
    for (int b = 0; b < nb; ++b) {
      const double ph = (1.0 - fr) * phi[(size_t)i0 * nb + b] + fr * phi[(size_t)i1 * nb + b];
      v[b] *= ph;
    }
  });
  // light smoothing over time (noise estimates from one short frame fluctuate a lot)
  std::vector<double> S((size_t)Fs * nb, 0.0);
  for (int f = 0; f < Fs; ++f)
    for (int b = 0; b < nb; ++b) {
      const double a = V[(size_t)std::max(0, f - 1) * nb + b], c = V[(size_t)f * nb + b],
                   d = V[(size_t)std::min(Fs - 1, f + 1) * nb + b];
      S[(size_t)f * nb + b] = 0.25 * a + 0.5 * c + 0.25 * d;
    }

  const std::vector<double> M = bandMixMatrix(B, sr);
  std::vector<double> colSum((size_t)nb, 0.0);
  for (int i = 0; i < nb; ++i)
    for (int j = 0; j < nb; ++j) colSum[(size_t)i] += M[(size_t)j * nb + i];
  std::vector<std::vector<float>> out((size_t)nb, std::vector<float>((size_t)Fs, 0.0f));
  std::vector<double> a((size_t)nb), est((size_t)nb);
  for (int f = 0; f < Fs; ++f) {
    const double* v = &S[(size_t)f * nb];
    double tot = 0.0;
    for (int j = 0; j < nb; ++j) tot += v[j];
    if (tot < 1e-14) continue;
    for (int i = 0; i < nb; ++i) a[(size_t)i] = v[i] / std::max(0.05, M[(size_t)i * nb + i]) + 1e-12;
    for (int it = 0; it < 24; ++it) {
      for (int j = 0; j < nb; ++j) {
        double e = 1e-20;
        for (int i = 0; i < nb; ++i) e += M[(size_t)j * nb + i] * a[(size_t)i];
        est[(size_t)j] = e;
      }
      for (int i = 0; i < nb; ++i) {
        double num = 0.0;
        for (int j = 0; j < nb; ++j) num += M[(size_t)j * nb + i] * v[j] / est[(size_t)j];
        a[(size_t)i] *= num / std::max(1e-12, colSum[(size_t)i]);
      }
    }
    for (int i = 0; i < nb; ++i) out[(size_t)i][(size_t)f] = (float)std::sqrt(3.0 * std::max(0.0, a[(size_t)i]));
  }
  return out;
}

// ------------------------------------------------------------------- emission
std::string envText(const std::vector<Pt2>& env) {
  std::string s = "envelope.custom(";
  for (size_t i = 0; i < env.size(); ++i) {
    if (i) s += ", ";
    s += fmt(round3(env[i].first), 3) + ", " + fmt(clampd(env[i].second, 0.0, 4.0), 3);
  }
  return s + ");";
}

const char* waveName(int w) {
  switch (w) {
    case 1: return "saw";
    case 2: return "square";
    case 3: return "triangle";
    case 4: return "pulse";
    default: return "sine";
  }
}

int toneCommands(const Tone& t) { return 4 + (isSweep(t) ? 1 : 0) + (t.lowpass > 0.0 ? 1 : 0); }

std::string emitTone(const Tone& t, double S) {
  const double vol = clampd(t.amp / S, 0.0, 4.0);
  std::string s = "layer.begin(" + fmt(t.t0, 3) + ", " + fmt(t.len, 3) + ");   // " + noteName(t.f0);
  if (t.harmonics > 0) s += std::string(" ") + waveName(t.wave) + " + " + std::to_string(t.harmonics) + " harmonics";
  s += "\n  oscillator." + std::string(waveName(t.wave)) + "(" + fmtHz(t.f0) + ", " + fmtVol(vol) +
       (t.wave == 4 ? ", " + fmt(t.width, 3) : std::string()) + ");\n";
  if (isSweep(t)) {
    s += "  sweep.frequency(" + fmtHz(t.f0) + ", " + fmtHz(t.f1) + ", " + fmt(t.len, 3);
    if (t.curve != 1.0) s += ", " + fmt(t.curve, 2);
    s += ");\n";
  }
  if (t.lowpass > 0.0) s += "  filter.lowpass(" + fmt(t.lowpass, 0) + ", 0.707, order = 2);\n";
  s += "  " + envText(t.env) + "\n";
  s += "layer.end();\n";
  return s;
}

std::string emitNoise(const NoiseBand& nb, const NoiseChunk& c, const Bands& B, double S) {
  const double vol = clampd(nb.vmax / S, 0.0, 4.0);
  const int j = c.band;
  std::string s = "layer.begin(" + fmt(c.t0, 3) + ", " + fmt(c.len, 3) + ");   // noise " + fmt(B.edge[(size_t)j], 0) +
                  "-" + fmt(B.edge[(size_t)j + 1], 0) + " Hz\n";
  s += "  noise.add(" + fmtVol(vol) + ");\n";
  s += "  filter.bandpass(" + fmt(B.center[(size_t)j], 0) + ", " + fmt(B.q[(size_t)j], 2) + ", order = 2);\n";
  s += "  " + envText(c.env) + "\n";
  s += "layer.end();\n";
  return s;
}

AnalyzeResult analyseImpl(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  AnalyzeResult R;
  const Params& P = paramsFor(opt.detail);
  if (!mono || frames < 1024 || sampleRate < 4000 || sampleRate > 400000) {
    R.error = "The audio is too short to analyse.";
    return R;
  }

  // ---- 1. clean-up
  std::vector<float> x;
  int sr = sampleRate;
  const size_t nUse = std::min(frames, (size_t)(kMaxAnalysisSec * sampleRate));
  x.assign(mono, mono + nUse);
  for (float& v : x)
    if (!std::isfinite(v)) v = 0.0f;
  while (sr > 50000 && x.size() > 8) {  // 88.2 / 96 kHz -> half rate (only < 16 kHz matters here)
    std::vector<float> y(x.size() / 2);
    for (size_t i = 0; i < y.size(); ++i) {
      const float a = x[i == 0 ? 0 : 2 * i - 1], b = x[2 * i], c = x[std::min(x.size() - 1, 2 * i + 1)];
      y[i] = 0.25f * a + 0.5f * b + 0.25f * c;
    }
    x.swap(y);
    sr /= 2;
  }
  double mean = 0.0;
  for (float v : x) mean += v;
  mean /= (double)x.size();
  double peak = 0.0;
  for (float& v : x) {
    v = (float)(v - mean);
    peak = std::max(peak, (double)std::fabs(v));
  }
  if (peak < 1e-4) {
    R.error = "The audio is silent.";
    return R;
  }
  for (float& v : x) v = (float)(v / peak);

  // trim silence (below -50 dB of the loudest 10 ms) at both ends
  {
    const int blk = std::max(1, sr / 100);
    const size_t nBlk = x.size() / (size_t)blk;
    std::vector<double> rms(nBlk, 0.0);
    double mx = 0.0;
    for (size_t b = 0; b < nBlk; ++b) {
      double s = 0.0;
      for (int i = 0; i < blk; ++i) s += (double)x[b * blk + i] * x[b * blk + i];
      rms[b] = std::sqrt(s / blk);
      mx = std::max(mx, rms[b]);
    }
    const double thr = mx * 0.00316;
    size_t fb = 0, lb = nBlk;
    while (fb < nBlk && rms[fb] < thr) ++fb;
    while (lb > fb && rms[lb - 1] < thr) --lb;
    if (lb > fb) {
      const long s0 = std::max(0L, (long)(fb * blk) - (long)(0.015 * sr));
      const long s1 = std::min((long)x.size(), (long)(lb * blk) + (long)(0.06 * sr));
      if (s1 - s0 >= (long)(0.05 * sr)) x = std::vector<float>(x.begin() + s0, x.begin() + s1);
    }
  }
  const double dur = (double)x.size() / sr;
  R.seconds = dur;

  // ---- 2. tones
  const Bands B = makeBands(P.nBands, sr);
  Tonal T;
  analyseTonal(x, sr, dur, P, B, T);
  std::vector<Track> tracks = trackPartials(T, P);
  double strongest = 0.0;
  std::vector<const Track*> smooth;
  for (const Track& tr : tracks) {
    if (!smoothPitch(tr)) continue;
    smooth.push_back(&tr);
    for (const TrackPt& p : tr.pts) strongest = std::max(strongest, (double)p.amp);
  }
  const double keepAmp = strongest * std::pow(10.0, -P.toneRelDb / 20.0);
  std::vector<Tone> tones;
  for (const Track* tr : smooth) {
    double pk = 0.0;
    for (const TrackPt& p : tr->pts) pk = std::max(pk, (double)p.amp);
    if (pk < keepAmp) continue;
    Tone t;
    if (!makeTone(*tr, T, P, dur, t)) continue;
    if (!std::isfinite(t.f0) || !std::isfinite(t.amp)) continue;
    for (const TrackPt& p : tr->pts) T.peaks[(size_t)p.frame][(size_t)p.pk].used = true;
    tones.push_back(std::move(t));
  }

  // ---- 3. harmonic stacks
  groupHarmonics(tones);

  // ---- 4. noise
  double hopS = 0.0;
  const std::vector<std::vector<float>> nv = analyseNoise(x, sr, B, T, &hopS);
  double toneRms = 0.0;
  for (const Tone& t : tones)
    if (!t.dropped) toneRms = std::max(toneRms, t.amp * (t.wave ? fundamentalAmp(t.wave, t.width) : 1.0) / std::sqrt(2.0));
  std::vector<double> bandMax((size_t)B.nb, 0.0);
  double ref = toneRms;
  for (int i = 0; i < B.nb; ++i) {
    for (float v : nv[(size_t)i]) bandMax[(size_t)i] = std::max(bandMax[(size_t)i], (double)v);
    ref = std::max(ref, bandMax[(size_t)i] / std::sqrt(3.0));
  }
  std::vector<NoiseBand> bands((size_t)B.nb);
  int usedBands = 0;
  for (int i = 0; i < B.nb; ++i) {
    NoiseBand& nb = bands[(size_t)i];
    if (bandMax[(size_t)i] / std::sqrt(3.0) < ref * std::pow(10.0, -P.noiseRelDb / 20.0)) continue;
    nb.vmax = bandMax[(size_t)i];
    std::vector<Pt2> env;
    const std::vector<float>& v = nv[(size_t)i];
    for (size_t m = 0; m < v.size(); ++m) {
      const double t = std::min(dur, (double)m * hopS);
      if (!env.empty() && t <= env.back().first && m + 1 < v.size()) continue;
      env.push_back({std::max(t, env.empty() ? 0.0 : env.back().first), (double)v[m] / nb.vmax});
    }
    if (env.size() < 2) continue;
    const std::vector<Pt2> pl = simplifyEnvelope(env, P.noiseChunksPerBand * 15 + 1, P.envTolDb + 0.5, 0.02);
    for (size_t s = 0; s + 1 < pl.size(); s += 15) {
      const size_t e = std::min(s + 15, pl.size() - 1);
      double hi = 0.0;
      for (size_t k = s; k <= e; ++k) hi = std::max(hi, pl[k].second);
      if (hi < 0.03) continue;
      NoiseChunk c;
      c.band = i;
      c.t0 = round3(pl[s].first);
      const double end = round3(pl[e].first);
      c.len = round3(end - c.t0);
      if (c.len < 0.01 || c.t0 >= dur) continue;
      for (size_t k = s; k <= e; ++k) c.env.push_back({std::max(0.0, std::min(c.len, round3(pl[k].first - c.t0))), pl[k].second});
      nb.chunks.push_back(std::move(c));
    }
    if (!nb.chunks.empty()) ++usedBands;
  }

  // ---- 5. choose what fits, emit
  double S = 1e-9;
  for (const Tone& t : tones)
    if (!t.dropped) S = std::max(S, t.amp * (t.wave ? fundamentalAmp(t.wave, t.width) : 1.0));
  for (const NoiseBand& nb : bands)
    if (!nb.chunks.empty()) S = std::max(S, nb.vmax);

  // Long sounds may use proportionally more layer-seconds (up to 3x), still far below the engine CPU budget.
  const double layerSecBudget = P.layerSecBudget * clampd(dur / 30.0, 1.0, 3.0);
  int cmds = 3, layers = 0;  // sound.begin, sound.normalize, sound.end
  double layerSec = 0.0;
  size_t chars = 1400;  // header + footer
  std::string noiseText;
  for (const NoiseBand& nb : bands)
    for (const NoiseChunk& c : nb.chunks) {
      const std::string s = emitNoise(nb, c, B, S);
      if (cmds + 5 > P.cmdBudget || layers + 1 > kMaxLayersUsed || chars + s.size() > kMaxScriptChars) continue;
      noiseText += s;
      cmds += 5;
      ++layers;
      layerSec += c.len;
      chars += s.size();
    }
  std::vector<const Tone*> order;
  for (const Tone& t : tones)
    if (!t.dropped) order.push_back(&t);
  std::sort(order.begin(), order.end(), [](const Tone* a, const Tone* b) { return a->score > b->score; });
  std::vector<std::pair<const Tone*, std::string>> chosen;
  for (const Tone* t : order) {
    if (cmds + 4 > P.cmdBudget || layers + 1 > kMaxLayersUsed) break;
    if (t->amp / S < 0.0003) continue;
    const int c = toneCommands(*t);
    if (cmds + c > P.cmdBudget || layerSec + t->len > layerSecBudget) continue;
    std::string s = emitTone(*t, S);
    if (chars + s.size() > kMaxScriptChars) continue;
    cmds += c;
    ++layers;
    layerSec += t->len;
    chars += s.size();
    chosen.push_back({t, std::move(s)});
  }
  std::sort(chosen.begin(), chosen.end(), [](const auto& a, const auto& b) {
    return a.first->t0 != b.first->t0 ? a.first->t0 < b.first->t0 : a.first->f0 < b.first->f0;
  });
  if (chosen.empty() && noiseText.empty()) {
    R.error = "No clear sound could be found in this audio.";
    return R;
  }

  double topHz = 0.0, topAmp = 0.0;
  for (const auto& c : chosen)
    if (c.first->amp > topAmp) {
      topAmp = c.first->amp;
      topHz = c.first->f0;
    }

  int noiseBandsOut = 0;
  for (const NoiseBand& nb : bands)
    if (!nb.chunks.empty()) ++noiseBandsOut;
  (void)usedBands;

  std::string name = sanitizeName(opt.name);
  if (name.empty()) name = "audio";
  std::string out;
  out.reserve(chars + 256);
  out += "// CodeWave script made from \"" + name + "\" (" + clock(opt.startSeconds) + " - " +
         clock(opt.startSeconds + dur) + ")\n";
  out += std::string("// ") + P.label + " detail: " + std::to_string(chosen.size()) + " tones + " +
         std::to_string(noiseBandsOut) + " noise bands. An approximation of the audio, not a copy.\n";
  if (topHz > 0.0) out += "// Strongest tone: " + noteName(topHz) + " (" + fmtHz(topHz) + " Hz)\n";
  out += "// tones = oscillator layers with a pitch and a volume envelope\n";
  out += "// noise = band-passed noise layers with a volume envelope (drums, hiss, rumble)\n";
  out += "sound.begin(" + fmt(round3(std::max(0.05, dur)), 3) + ");\n";
  if (!chosen.empty()) out += "\n// ---- tones\n";
  for (const auto& c : chosen) out += c.second;
  if (!noiseText.empty()) out += "\n// ---- noise\n" + noiseText;
  out += "\nsound.normalize(0.9);\nsound.end();\n";

  R.ok = true;
  R.script = std::move(out);
  R.tones = (int)chosen.size();
  R.noiseBands = noiseBandsOut;
  R.commands = cmds;
  char sum[160];
  std::snprintf(sum, sizeof sum, "%d tones + %d noise bands, %.1f s", R.tones, R.noiseBands, dur);
  R.summary = sum;
  return R;
}

}  // namespace

AnalyzeResult analyzeAudioToScript(const float* mono, size_t frames, int sampleRate, const AnalyzeOptions& opt) {
  try {
    return analyseImpl(mono, frames, sampleRate, opt);
  } catch (const std::bad_alloc&) {
    AnalyzeResult r;
    r.error = "Not enough memory to analyse this audio.";
    return r;
  } catch (...) {
    AnalyzeResult r;
    r.error = "The audio could not be analysed.";
    return r;
  }
}

}  // namespace cw
