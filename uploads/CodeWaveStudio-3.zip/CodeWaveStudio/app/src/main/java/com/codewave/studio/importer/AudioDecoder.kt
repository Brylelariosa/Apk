package com.codewave.studio.importer

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import java.nio.ByteOrder

/**
 * Decodes the first audio track of any file this device can play (mp3, m4a / aac, wav, ogg, flac,
 * even the sound of an mp4 video) to mono float PCM. Android framework only (MediaExtractor +
 * MediaCodec): no library, no permission - the file arrives through the system file picker.
 */
object AudioDecoder {

    class Decoded(val pcm: FloatArray, val length: Int, val sampleRate: Int, val fileSeconds: Double)

    class DecodeException(message: String) : Exception(message)

    class DecodeCancelled : Exception()

    /**
     * Decodes up to [maxSeconds] starting at [startSeconds]. [cancelled] is polled between buffers.
     * [progress] receives 0..1 (share of [maxSeconds] decoded). Blocking: call from a worker thread.
     */
    fun decode(
        context: Context,
        uri: Uri,
        startSeconds: Double,
        maxSeconds: Double,
        cancelled: () -> Boolean,
        progress: (Float) -> Unit
    ): Decoded {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            try {
                extractor.setDataSource(context, uri, null)
            } catch (e: Exception) {
                throw DecodeException("This file could not be opened.")
            }

            var trackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val m = f.getString(MediaFormat.KEY_MIME)
                if (m != null && m.startsWith("audio/")) {
                    trackIndex = i
                    trackFormat = f
                    break
                }
            }
            val format = trackFormat ?: throw DecodeException("This file has no audio track.")
            val mime = format.getString(MediaFormat.KEY_MIME) ?: throw DecodeException("Unknown audio format.")
            extractor.selectTrack(trackIndex)

            val fileSeconds =
                if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) / 1_000_000.0 else 0.0
            if (fileSeconds > 0.0 && startSeconds >= fileSeconds) {
                throw DecodeException(
                    String.format(java.util.Locale.US, "The start time is past the end of the file (%.1f s long).", fileSeconds)
                )
            }

            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var encoding = AudioFormat.ENCODING_PCM_16BIT

            val c: MediaCodec = try {
                val created = MediaCodec.createDecoderByType(mime)
                codec = created
                created.configure(format, null, null, 0)
                created.start()
                created
            } catch (e: Exception) {
                throw DecodeException("This device cannot decode this audio format ($mime).")
            }

            val startUs = (startSeconds * 1_000_000.0).toLong()
            if (startUs > 0L) extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val endUs = startUs + ((maxSeconds + 1.0) * 1_000_000.0).toLong()

            var maxFrames = (maxSeconds * sampleRate).toInt()
            var out = FloatArray(maxFrames)
            var outLen = 0
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var idle = 0
            var lastReported = -1f

            while (!outputDone && outLen < maxFrames) {
                if (cancelled()) throw DecodeCancelled()
                var worked = false

                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        worked = true
                        val inBuf = c.getInputBuffer(inIdx)
                        val size = if (inBuf != null) extractor.readSampleData(inBuf, 0) else -1
                        val t = extractor.sampleTime
                        if (size < 0 || t < 0L || t > endUs) {
                            c.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, size, t, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = c.dequeueOutputBuffer(info, 5_000L)
                if (outIdx >= 0) {
                    worked = true
                    val buf = c.getOutputBuffer(outIdx)
                    if (buf != null && info.size > 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        buf.order(ByteOrder.nativeOrder())
                        val ch = if (channels < 1) 1 else channels
                        val fb = if (encoding == AudioFormat.ENCODING_PCM_FLOAT) buf.asFloatBuffer() else null
                        val sb = if (encoding == AudioFormat.ENCODING_PCM_16BIT) buf.asShortBuffer() else null
                        val total = when {
                            fb != null -> fb.remaining()
                            sb != null -> sb.remaining()
                            else -> buf.remaining()
                        }
                        val frames = total / ch
                        var skip = 0
                        if (startUs > 0L) {
                            val bufStartFrame = info.presentationTimeUs.toDouble() * sampleRate / 1_000_000.0
                            val wantFrame = startUs.toDouble() * sampleRate / 1_000_000.0
                            skip = (wantFrame - bufStartFrame).toInt()
                            if (skip < 0) skip = 0
                            if (skip > frames) skip = frames
                        }
                        var f = skip
                        while (f < frames && outLen < maxFrames) {
                            var sum = 0f
                            for (k in 0 until ch) {
                                val idx = f * ch + k
                                sum += when {
                                    fb != null -> fb.get(idx)
                                    sb != null -> sb.get(idx) / 32768f
                                    else -> ((buf.get(info.offset + idx).toInt() and 0xFF) - 128) / 128f
                                }
                            }
                            out[outLen] = sum / ch
                            outLen++
                            f++
                        }
                    }
                    c.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    worked = true
                    val newFormat = c.outputFormat
                    if (newFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (newFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (Build.VERSION.SDK_INT >= 24 && newFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        encoding = newFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    val newMax = (maxSeconds * sampleRate).toInt()
                    if (newMax != maxFrames) {
                        maxFrames = newMax
                        if (out.size < maxFrames) out = out.copyOf(maxFrames)
                    }
                }

                if (worked) idle = 0 else if (++idle > 400) break  // about 2 s without any progress

                val frac = if (maxFrames > 0) outLen.toFloat() / maxFrames else 1f
                if (frac - lastReported >= 0.02f) {
                    lastReported = frac
                    progress(if (frac > 1f) 1f else frac)
                }
            }

            if (outLen < 1024) throw DecodeException("Not enough audio could be decoded from this file.")
            return Decoded(out, outLen, sampleRate, fileSeconds)
        } finally {
            try {
                codec?.stop()
            } catch (e: Exception) {
                // already stopped
            }
            try {
                codec?.release()
            } catch (e: Exception) {
                // nothing left to release
            }
            try {
                extractor.release()
            } catch (e: Exception) {
                // nothing left to release
            }
        }
    }
}
