package com.codewave.studio.importer

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.codewave.studio.crash.CrashLog
import com.codewave.studio.engine.NativeBridge
import java.util.concurrent.atomic.AtomicBoolean

/**
 * "Import audio, get code": decodes an audio file (up to 2 minutes) and asks the native analyser to write
 * a CodeWave script that imitates it. Runs on a worker thread; like [com.codewave.studio.SoundSession]
 * it survives Activity re-creation - a result that arrives while no screen is attached waits in
 * [takePending]. Main thread only (except the worker body).
 */
object AudioToCode {

    /** Longest part of a file that is converted (the engine's longest sound is 120 s). */
    const val MAX_SECONDS = 120.0

    interface Listener {
        fun onImportProgress(fraction: Float)
        fun onImportFinished(outcome: Outcome)
    }

    sealed class Outcome {
        class Success(val script: String, val summary: String) : Outcome()
        class Failure(val message: String) : Outcome()
        object Cancelled : Outcome()
    }

    private val main = Handler(Looper.getMainLooper())
    private var token = 0
    private var cancelFlag = AtomicBoolean(false)
    private var pending: Outcome? = null

    var listener: Listener? = null

    var running: Boolean = false
        private set

    var progress: Float = 0f
        private set

    /** [detail]: 0 simple, 1 normal, 2 detailed. */
    fun start(context: Context, uri: Uri, displayName: String, startSeconds: Double, detail: Int) {
        if (running) return
        running = true
        progress = 0f
        pending = null
        val mine = ++token
        val flag = AtomicBoolean(false)
        cancelFlag = flag
        val app = context.applicationContext
        CrashLog.note("Import audio: detail=$detail, start=$startSeconds s")
        Thread({
            val outcome = work(app, uri, displayName, startSeconds, detail, flag) { f ->
                main.post {
                    if (token == mine && running) {
                        progress = f
                        listener?.onImportProgress(f)
                    }
                }
            }
            main.post { finish(mine, outcome) }
        }, "cw-import").start()
    }

    fun cancel() {
        if (!running) return
        cancelFlag.set(true)
        token++
        running = false
        progress = 0f
        CrashLog.note("Import cancelled")
        listener?.onImportFinished(Outcome.Cancelled)
    }

    /** A result that arrived while no screen was listening (e.g. during rotation), or null. */
    fun takePending(): Outcome? {
        val p = pending
        pending = null
        return p
    }

    private fun finish(mine: Int, outcome: Outcome) {
        if (mine != token) return
        running = false
        progress = 0f
        CrashLog.note(
            when (outcome) {
                is Outcome.Success -> "Import OK: ${outcome.summary}"
                is Outcome.Failure -> "Import failed: ${outcome.message}"
                Outcome.Cancelled -> "Import cancelled"
            }
        )
        val l = listener
        if (l != null) l.onImportFinished(outcome) else pending = outcome
    }

    private fun work(
        app: Context,
        uri: Uri,
        displayName: String,
        startSeconds: Double,
        detail: Int,
        flag: AtomicBoolean,
        report: (Float) -> Unit
    ): Outcome {
        if (!NativeBridge.available) {
            return Outcome.Failure("The native audio engine could not be loaded on this device.")
        }
        try {
            val decoded = AudioDecoder.decode(
                app, uri, startSeconds, MAX_SECONDS,
                { flag.get() },
                { f -> report(f * 0.85f) }
            )
            if (flag.get()) return Outcome.Cancelled
            report(0.9f)
            val reply = NativeBridge.analyzeAudio(
                decoded.pcm, decoded.length, decoded.sampleRate, detail, displayName, startSeconds.toFloat()
            )
            if (flag.get()) return Outcome.Cancelled
            val nl = reply.indexOf('\n')
            val head = if (nl >= 0) reply.substring(0, nl) else reply
            val rest = if (nl >= 0) reply.substring(nl + 1) else ""
            if (head == "OK") {
                val nl2 = rest.indexOf('\n')
                val summary = if (nl2 >= 0) rest.substring(0, nl2) else rest
                val script = if (nl2 >= 0) rest.substring(nl2 + 1) else ""
                if (script.isEmpty()) return Outcome.Failure("The conversion produced no code.")
                report(1f)
                return Outcome.Success(script, summary)
            }
            return Outcome.Failure(if (rest.isEmpty()) "The audio could not be converted." else rest)
        } catch (e: AudioDecoder.DecodeCancelled) {
            return Outcome.Cancelled
        } catch (e: AudioDecoder.DecodeException) {
            return Outcome.Failure(e.message ?: "The audio could not be decoded.")
        } catch (e: OutOfMemoryError) {
            return Outcome.Failure("Not enough memory to convert this audio.")
        } catch (t: Throwable) {
            return Outcome.Failure("The audio could not be converted (" + t.javaClass.simpleName + ").")
        }
    }
}
