// Desktop test for the audio -> script analyser (no Android needed).
//   ./a2c_test in.wav out.cws [detail 0..2] [resynth.wav]
// in.wav: PCM16 / PCM24 / float32 WAV (e.g. `ffmpeg -i song.mp3 in.wav`). The generated script is
// parsed and rendered by the real engine, so this also proves that the script is valid and inside the
// limits. See tools/build_and_test.sh.
#include <fcntl.h>
#include <unistd.h>

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

#include "analysis/audio_to_code.h"
#include "audio/audio_io.h"
#include "engine/engine.h"

static bool readWav(const char* path, std::vector<float>& mono, int& sr) {
  std::ifstream in(path, std::ios::binary);
  if (!in) return false;
  std::vector<uint8_t> b((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
  if (b.size() < 44 || std::memcmp(b.data(), "RIFF", 4) != 0) return false;
  auto u16 = [&](size_t o) { return (int)(b[o] | (b[o + 1] << 8)); };
  auto u32 = [&](size_t o) { return (uint32_t)(b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | ((uint32_t)b[o + 3] << 24)); };
  int fmtTag = 0, ch = 0, bits = 0;
  size_t pos = 12;
  while (pos + 8 <= b.size()) {
    const uint32_t sz = u32(pos + 4);
    if (!std::memcmp(&b[pos], "fmt ", 4)) {
      fmtTag = u16(pos + 8);
      ch = u16(pos + 10);
      sr = (int)u32(pos + 12);
      bits = u16(pos + 22);
    } else if (!std::memcmp(&b[pos], "data", 4)) {
      const size_t n = std::min<size_t>(sz, b.size() - pos - 8);
      const uint8_t* d = &b[pos + 8];
      const size_t bytes = (size_t)bits / 8;
      if (ch < 1 || bytes < 2) return false;
      const size_t frames = n / (bytes * ch);
      mono.assign(frames, 0.0f);
      for (size_t i = 0; i < frames; ++i) {
        double s = 0;
        for (int c = 0; c < ch; ++c) {
          const uint8_t* p = d + (i * ch + c) * bytes;
          if (fmtTag == 3 && bits == 32) { float f; std::memcpy(&f, p, 4); s += f; }
          else if (bits == 16) s += (int16_t)(p[0] | (p[1] << 8)) / 32768.0;
          else if (bits == 24) s += (int32_t)((p[0] << 8) | (p[1] << 16) | ((uint32_t)p[2] << 24)) / 2147483648.0;
        }
        mono[i] = (float)(s / ch);
      }
      return true;
    }
    pos += 8 + sz + (sz & 1);
  }
  return false;
}

int main(int argc, char** argv) {
  if (argc < 3) {
    std::fprintf(stderr, "usage: %s in.wav out.cws [detail 0..2] [resynth.wav]\n", argv[0]);
    return 2;
  }
  std::vector<float> mono;
  int sr = 0;
  if (!readWav(argv[1], mono, sr)) {
    std::fprintf(stderr, "cannot read %s\n", argv[1]);
    return 2;
  }
  cw::AnalyzeOptions opt;
  opt.detail = argc > 3 ? std::atoi(argv[3]) : 1;
  opt.name = argv[1];
  const cw::AnalyzeResult r = cw::analyzeAudioToScript(mono.data(), mono.size(), sr, opt);
  if (!r.ok) {
    std::printf("ANALYSIS FAILED: %s\n", r.error.c_str());
    return 1;
  }
  { std::ofstream o(argv[2]); o << r.script; }
  std::printf("analysis ok: %s | commands=%d chars=%zu\n", r.summary.c_str(), r.commands, r.script.size());

  cw::Engine engine;
  cw::GenerateSettings gs;
  gs.sampleRate = sr == 22050 || sr == 48000 ? sr : 44100;
  gs.channels = 1;
  const cw::GenStatus st = engine.generate(r.script, gs, nullptr);
  if (st != cw::GenStatus::Ok) {
    std::printf("ENGINE REJECTED THE SCRIPT status=%d line=%d\n%s\n", (int)st, engine.lastErrorLine(), engine.lastError().c_str());
    return 1;
  }
  auto snd = engine.sound();
  std::printf("render ok: %.2f s, %d ms, warnings=[%s]\n", snd->frames / (double)snd->sampleRate, engine.lastRenderMillis(),
              engine.lastWarnings().c_str());
  if (argc > 4) {
    const int fd = ::open(argv[4], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0 || cw::writeWav(*snd, fd, 16) != 0) return 1;
    ::close(fd);
  }
  return 0;
}
