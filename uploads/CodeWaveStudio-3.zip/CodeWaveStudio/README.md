# CodeWave Studio

Native Android procedural-audio tool. Paste a script written by Claude (or any assistant), press
**Generate**, look at the real waveform, play it, tweak the code, and save a WAV.

```
Claude writes a script -> you paste it -> GENERATE -> C++ engine renders PCM
-> waveform -> PLAY / PAUSE / STOP / SEEK / LOOP -> edit -> Save WAV
```

Kotlin (UI + controller) -> JNI -> C++ audio engine -> PCM -> AudioTrack / WAV exporter.
No WebView, no frameworks, **no third-party libraries** (Android framework + Kotlin stdlib only),
**no permissions**, no network.

## Using it with Claude

Tap the **?** button in the app, then **Copy AI prompt**. Paste that into Claude and finish the
sentence with the sound you want ("a heavy sci-fi door", "robot saying hello"). Copy Claude's
code block, open CodeWave Studio, tap **Paste**, then **Generate**.

## Import audio -> get the code (new)

Pick any **mp3 / m4a (AAC) / wav / ogg / flac** file (anything the phone can play; the sound of an mp4
video works too) and CodeWave writes a script that imitates it:

```
Import audio -> choose file -> Detail (Simple / Normal / Detailed) + Length + optional "Start at" seconds
-> Convert -> the code appears in the editor and is rendered automatically -> Play / Copy / Save WAV
```

* The **Import audio** button is under the editor. **Copy** (next to Paste / Clear) copies the whole script.
* **Length** (default 30 s, up to 2 minutes) and **Start at** choose which part of the file is converted. The code gets
  rougher per second the longer the part, because a script can only hold so much text (about 250 000
  characters): convert 10 to 30 seconds at a time for the closest match. A full produced song (vocals, drums,
  reverb) can never sound identical - it becomes a recognisable imitation of its rhythm, bass, chords and tone.
* It is an **approximation, not a copy**: the code is what a person would write to imitate the sound.
  - **Tones**: steady notes become `oscillator.*` layers with a volume envelope (a stack of harmonics collapses
    into one saw / square / triangle / pulse oscillator) and glides become `sweep.frequency`. Tones are ranked
    by how audible they are (hearing-weighted), so quiet sub-bass does not eat the budget.
  - **Noise bands**: everything the emitted tones do not explain (drums, hats, breath, voices, reverb, hiss)
    becomes 6 to 16 band-passed `noise.add` layers whose level over time is fitted with long
    `envelope.custom` lists - this is what keeps the rhythm and the overall tone colour.
  - Budgets are per second of audio: Simple about 8 tones / 8 envelope points per band per second, Normal
    14 / 18, Detailed 30 / 30 (with floors for very short sounds). Long clips use fewer, wider bands so each
    band can still follow the beat.
* The generated code always stays inside the engine limits and is checked by the real parser in the
  desktop tests (stereo 48 kHz renders of 2-minute results take under a second on a desktop).
* Very large scripts: the editor shows scripts over 150 000 characters without syntax colours, and **Copy**
  tells you if the clipboard refuses text that big (use a shorter part or Simple detail).
* Decoding uses `MediaExtractor` + `MediaCodec` (Android framework, no library) and the file comes
  through the system file picker, so there is still **no permission** and no network. DRM-protected
  files and codecs the phone cannot decode (e.g. Apple Lossless) are reported with a clear message.
* Code: `importer/AudioDecoder.kt` (decode), `importer/AudioToCode.kt` (background job, survives rotation),
  `cpp/analysis/audio_to_code.cpp` (analysis -> script). Tests: `tools/audio_to_code_test.cpp`, fuzzer
  `tools/audio_to_code_fuzz.cpp`.

## The scripting language

A tiny audio-only language. Every command is `group.method(values);` and must exist in the
command table (`app/src/main/cpp/parser/commands.cpp`) - anything else is rejected with a
line-numbered error such as:

```
Line 4:
Unknown command: oscillator.xyz

Expected:
sine
square
triangle
saw
pulse
noise
```

```
sound.begin(1.2);
oscillator.saw(90, 0.7);          // source
fm.modulate(35, 4.0);             // modifies the oscillator above
noise.add(0.08);
filter.lowpass(2400);             // processes everything so far
distortion.amount(0.15);
envelope.adsr(0.01, 0.12, 0.65, 0.3);
sound.end();
```

Supported: oscillators (sine, square, triangle, saw, pulse, noise + pink/brown), FM / AM / ring
modulation, vibrato, pitch and frequency sweeps, pitch quantisation, ADSR / exponential / linear /
custom envelopes, low/high/band-pass and notch filters (with cutoff sweeps), distortion
(soft/hard/fold), saturation, bit-crusher, delay, reverb, tremolo, chorus, compressor, layers,
repeats, normalize, fade, reverse, pitch shift, time stretch, pan/gain, and a voice section
(synthetic human vowels with formant morphing, formant filter, vocoder, metallic resonance).
Variables (`let base = 220;`), arithmetic and note names (`A4`, `C#3`) are supported.
The full reference is `app/src/main/assets/reference.txt` (generated from the command table by
`tools/dump_reference.cpp`, so it cannot drift from the parser).

The voice tools make *stylised synthetic* human/robot sounds. They are not speech synthesis.

### Safety model

Scripts are parsed and fully validated **before** any audio is rendered, and can only call commands
from the table. There is no file, network, shell, JNI, intent or system access in the language.
Hard limits: 1 MB script, 30000 commands, 120 s per sound, 2048 points per envelope.custom,
16 oscillators per layer, 4 nested layers, 128 repeats / 12000 layer instances, 96 MB memory budget, and a CPU work budget. Rendering
runs on a worker thread with progress and a **Cancel** button; C++ exceptions never cross the JNI
boundary. A failed generation keeps the previous waveform and audio.

## Project layout

```
app/src/main/cpp/
  dsp/       oscillators, filters, envelopes, effects, voice, utilities  (+ common.h, audio_buf.h)
  parser/    command table, lexer/parser/validator
  engine/    renderer (executes a validated program), Engine (result ownership, errors)
  analysis/  audio -> script (spectral analysis, partial tracking, noise-band fitting)
  audio/     PCM16 copy, waveform peaks, WAV writer (16-bit PCM / 32-bit float)
  crash/     native crash reporter (signal handler + backtrace)
  jni_bridge.cpp
app/src/main/java/com/codewave/studio/
  engine/    NativeBridge (JNI surface), AudioEngine (async facade)
  importer/  AudioDecoder (MediaCodec -> mono PCM), AudioToCode (import job)
  player/    PcmPlayer (AudioTrack streaming, exact position, loop, seek)
  ui/        CodeEditorView, WaveformView, SyntaxHighlighter
  data/      AppSettings, PresetLibrary, LanguageReference, Themes
  crash/     CrashLog (Java + native crash capture), CrashReportActivity (separate process)
  SoundSession.kt (survives rotation), MainActivity.kt, SettingsActivity.kt
app/src/main/assets/   presets/*.cws (19 text scripts), reference.txt
tools/       desktop test harness, mutation fuzzer, crash-reporter test, reference generator,
             audio->code test + fuzzer
```

## Building

Matches the existing GitHub Actions workflow: JDK 17, Gradle 8.6, AGP 8.2.2, Kotlin 1.9.22,
NDK 25.2.9519653, CMake 3.22.1, compileSdk/targetSdk 34, minSdk 23. Zip the folder, put the ZIP in
`uploads/`, push. `./gradlew assembleDebug` and `./gradlew assembleRelease` need no signing
configuration (release is unsigned unless the workflow passes `-Pandroid.injected.signing.*`).

* `gradle/wrapper/gradle-wrapper.jar` is a binary and is not in the ZIP; the workflow downloads it
  ("Fetch gradle-wrapper.jar"). For a local build run `gradle wrapper --gradle-version 8.6` once.
* One universal APK, **no ABI splits**. ABIs built: `armeabi-v7a` + `arm64-v8a` (phones). Emulator
  ABIs are left out to save size - add `'x86_64'` to `abiFilters` in `app/build.gradle` if needed.
* Size: R8 (`minifyEnabled true`) + `shrinkResources true`, no dependencies, vector drawables only,
  compressed native libs, `-O2`, hidden symbols, `--gc-sections`, static libc++. JNI entry points and
  the progress callback are protected in `proguard-rules.pro`.
* Debug builds also compile the DSP at `-O2` (CMake would otherwise use `-O0`).

## Desktop tests (no Android needed)

```
sh tools/build_and_test.sh          # builds the engine for Linux/macOS and renders every preset to WAV
```

`tools/fuzz_test.cpp` mutates the presets (and feeds binary garbage); build it with
`-fsanitize=address,undefined` to hunt for crashes.

## Crash log (no root, Shizuku or PC)

* Java/Kotlin crashes **and native C++ crashes** (SIGSEGV, SIGABRT, ...) are caught by the app itself.
* After a crash a report screen opens by itself (it runs in a separate process and is built from
  plain views, so it works even if the main screen is what crashed). A native crash is shown the next
  time you start the app.
* Every report is saved privately inside the app **and**, on Android 10+, as a text file in
  `Download/CodeWaveStudio/` (not Android/data) - open it with any file manager.
* The screen has Copy, Share, Save as..., Older reports and Restart app. Reports include device,
  Android version, the stack trace and the last ~80 app events (generate, play, export, lifecycle).
* Settings > Diagnostics: view/clear reports and a **Test the crash logger** button.
* Nothing is ever sent anywhere and no permission is needed.

## Settings

Sample rate (22.05 / 44.1 / 48 kHz), mono/stereo, default sound duration (used by `sound.begin()`
without arguments), audio buffer size, default export format (16-bit PCM or 32-bit float WAV),
theme (dark / light / system), About. Engine settings apply on the next Generate.

## Not included

* **OGG export**: Android has no built-in Vorbis encoder; adding one would mean a native library
  and a bigger APK, so only WAV (16-bit PCM or 32-bit float) is offered.
