# Menu Shell

A landscape main-menu shell: title + Play/Settings, immersive fullscreen,
locked to landscape/reverse-landscape, laid out to avoid the display cutout.

## Structure

- `ImmersiveActivity` — base class that hides the system bars and sets
  `LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER` so content never sits behind the
  camera cutout. Extend this for any new screen (gameplay, settings) instead
  of re-adding the window flags.
- `MainActivity` — the menu itself. `Play` now launches `GameActivity`;
  `Settings` still just shows a placeholder Toast until there's a real
  screen to send it to.
- `GameActivity` — what `Play` opens. For now it just hosts a
  `BilliardsTableView` full screen (see `billiards/` below) — no ball or
  cue yet.
- `billiards/` — the table, kept independent of any one screen so it's
  reusable once gameplay is added. `Vec2`, `Pocket`, `Cushion`, and
  `TableGeometry` are plain Kotlin with no Android dependency — that's
  where the real collision/pocket math lives (`Cushion.reflect()`,
  `Pocket.captures()`). `BilliardsTableView` is just the Canvas rendering
  of that geometry. A future ball only needs to call
  `TableGeometry.cushionColliding(...)` / `.pocketCapturing(...)` each step.

## Orientation

`android:screenOrientation="sensorLandscape"` locks out portrait but lets
the OS flip between landscape and reverse-landscape based on the sensor.
Both share the same `layout/activity_main.xml` (no separate `-land`
resources needed), and `configChanges` keeps the Activity from restarting
on that flip.

## Build

Fits the provided GitHub Actions workflow unmodified: zip this folder,
push it to `uploads/` in the repo, and the workflow builds a debug APK
(release if `KEYSTORE_BASE64` etc. are set as secrets).

Pinned versions: Gradle 8.6 (matches the workflow's wrapper-jar fetch),
AGP 8.4.2, Kotlin 1.9.24 — AGP 8.4.x is the release whose minimum required
Gradle version is 8.6, so this is the closest matched pairing rather than
an arbitrary "latest" pick.

`gradlew` here is a short custom launcher, not the stock Gradle-generated
script — it only needs to work on the Ubuntu CI runner, so it skips the
Windows/Cygwin/symlink-resolution branches the stock script carries and
just execs `java` against `gradle-wrapper.jar` with `JAVA_HOME` from
`setup-java`.
