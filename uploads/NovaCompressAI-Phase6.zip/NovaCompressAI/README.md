# NovaCompress AI — Phases 1-6

A real, working, buildable Android app implementing the large majority of
the NovaCompress AI spec's core functionality: the compression engine, a
genuinely working genome Evolution Engine + Benchmark Laboratory, eight
compression plugins, thermal/battery/memory-aware background research,
checkpoint/resume, archive repair mode, knowledge export/import, and
external app integration. It is not the *entire* spec (multi-file
archives, the dictionary section, and a formal dynamic Plugin SDK remain)
— see [PROGRESS.md](PROGRESS.md) for the full phase-by-phase breakdown of
what's here vs. what's next.

## What actually works right now

**Compression engine**
- Eight real, lossless plugins: Delta, Run-Length Encoding, Huffman,
  LZ77, Move-To-Front, Burrows-Wheeler Transform (suffix array via
  prefix-doubling, no sentinel byte - cross-validated byte-for-byte
  against a brute-force reference implementation), Arithmetic Coding
  (Witten-Neal-Cleary, stress-tested across 300 configurations), and
  Predictive Coding (second-order linear predictor). Every plugin was
  prototyped and round-trip-tested in Python before being ported to
  Kotlin.
- Seven genome presets built from these plugins, covering general-purpose,
  maximum-compression, fast, low-power, block-sorting (bzip2-style),
  research-mode (arithmetic-coding-based), and signal/trend-optimized use
  cases.
- A pipeline engine that chains plugins and correctly rejects invalid
  combinations (empty, over the 16-stage limit, unknown plugin, or
  duplicate plugins).

**Archive format**
- A real, chunked, streaming `.nova` format with per-chunk and whole-file
  SHA-256 verification - corruption, truncation, and tampering are all
  caught and reported, never silently ignored.
- **Archive Inspector**: reads metadata without decompressing.
- **Archive Repair Mode**: best-effort partial recovery of a corrupted
  archive - salvages whichever chunks still pass their hash check,
  zero-fills the rest, and reports precisely what could and couldn't be
  recovered (including the honest limit: a chunk whose *size field itself*
  is corrupted can't be located, so nothing after it is recoverable
  either).
- **Checkpoint/resume**: if the app crashes or is killed mid-compression,
  retrying the same file resumes from the last completed chunk instead of
  starting over - verified by constructing genuinely truncated partial
  archives in tests and confirming byte-for-byte identical results to an
  uninterrupted write.
- Real progress reporting (determinate progress bars, not spinners) for
  both compress and decompress.

**The AI core**
- A real Benchmark Laboratory: every candidate genome is actually
  compressed, decompressed, timed, and verified against real data - never
  an estimate.
- A real Evolution Engine: mutation and crossover, both guaranteed to
  produce structurally valid, duplicate-free pipelines. Every compression
  job benchmarks the best known genomes plus fresh candidates, records
  every result as permanent knowledge, and picks the genuinely measured
  winner.
- A Knowledge Database whose growth is actually bounded to match the
  spec's own stated limits (128 MB, ~500 active genomes) - old benchmark
  records pruned, weak genomes retired rather than accumulating forever.
- Thermal/battery/memory-aware background research via WorkManager,
  running against synthetic samples when there's no real file to learn
  from, toggleable from Settings.
- Knowledge Export/Import (`.nova-backup`): merges on import without ever
  overwriting existing genomes.

**Android app**
- Six Compose screens: Dashboard, Compress, Decompress, Research Lab
  (species chart + Genome Explorer), Settings (background learning toggle
  + knowledge backup), plus the Archive Inspector and Repair flows folded
  into Decompress.
- "Share to compress" and "Open with" for `.nova` files, both fully wired
  to pre-fill the right screen.
- R8/minification enabled for release builds with real (deliberately
  broad) keep rules; CI builds the release variant to catch build-time
  shrinking mistakes.
- **100 JUnit test methods**, including a from-scratch brute-force BWT
  reference implementation, a 150-configuration arithmetic-coding stress
  test, genuinely-truncated-archive resume/repair tests, and the full
  scheduling/checkpoint/backup logic.

## What's deliberately not here yet

Multi-file archives (folder trees, independent per-file chunk tables),
the dictionary section (shared/preset dictionaries), a formal dynamic
Plugin SDK with sandboxing, Hilt, "Bit Packing" as its own plugin, and the
spec's more elaborate visualizations (AI Brain Visualization, Mutation
Timeline animations, zoomable interactive charts) or Developer Mode
(live thread/memory monitors, database browser). See PROGRESS.md.

## About the Gradle Wrapper

The build environment for this project is GitHub Actions, per the project's
own build instructions. The sandbox this project was generated in has **no
network access and no local Gradle/Android SDK/Kotlin compiler** — so a
`gradle-wrapper.jar` binary (normally produced by running `gradle wrapper`
against a real Gradle install) could not be generated or verified here.

Rather than commit a guessed-at binary that might be silently wrong, the
CI workflow (`.github/workflows/android-ci.yml`) installs a real Gradle
distribution first and runs `gradle wrapper --gradle-version 8.6` as its
first step, regenerating `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar`
before anything else runs.

If you clone this locally and want to run `./gradlew` directly, you'll need
to run `gradle wrapper --gradle-version 8.6` yourself once (with any Gradle
8.x install), or just use your own `gradle` command directly.

## Verified version matrix

| Component | Version |
|---|---|
| Gradle | 8.6 (per the project's own pinned target) |
| Android Gradle Plugin | 8.4.0 |
| Kotlin | 1.9.24 |
| Compose Compiler extension | 1.5.14 |
| KSP | 1.9.24-1.0.20 |
| compileSdk / targetSdk | 34 |
| minSdk | 26 (Android 8.0) |

As of mid-2026 the ecosystem has moved on to Gradle 9.x / AGP 9.x, which
changes Kotlin integration significantly. This project deliberately stays
on the version matrix the project's own build spec pinned rather than
jumping to the newer major versions.

## Building

Push to GitHub and let `.github/workflows/android-ci.yml` build it, or
locally:

```bash
gradle wrapper --gradle-version 8.6   # one-time, if gradlew isn't already valid
./gradlew testDebugUnitTest            # run the 100 unit tests
./gradlew assembleDebug                # produce app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease              # produce the minified release APK (unsigned)
```

## Project layout

```
app/src/main/java/com/novacompress/ai/
  core/
    analyzer/     FileAnalyzer, FeatureVector
    plugins/      8 CompressionPlugin implementations + PluginRegistry
    pipeline/     PipelineDescriptor, CompressionPipeline
    genome/       CompressionGenome, GenomeStatus, GenomePresets, GenomeSelector
    verification/ VerificationEngine
    archive/      Writer/Reader/Resumer/Repairer/Inspector, ArchiveMetadata
    benchmark/    BenchmarkLaboratory, BenchmarkResult, FitnessCalculator
    evolution/    EvolutionEngine, MutationEngine, CrossoverEngine, GenomeRepository (interface)
    scheduler/    Battery/Thermal/Memory status providers, ResearchScheduler
    backup/       KnowledgeBackupCodec, backup data records
    service/      CompressionService, DecompressionService, ArchiveRepairService, checkpointing
    common/       Constants, EngineResult, BinaryIO, ByteCursor
  data/           Room database (history + genomes + benchmarks), DAOs, repositories
  di/             ServiceLocator + ViewModel factory (no Hilt yet, see below)
  work/           BackgroundResearchWorker + scheduler
  ui/             Compose screens + ViewModels
app/src/test/java/com/novacompress/ai/   100 JUnit tests mirroring the above
```

## Notable engineering decisions

- **`NovaArchiveResumer` and `NovaArchiveRepairer` are separate objects
  from `NovaArchiveWriter`/`NovaArchiveReader`**, not refactors that share
  their chunk loops. The writer/reader are the single most safety-critical
  pieces of this app; duplicating logic was a small, deliberate cost next
  to any risk of regressing their already-thoroughly-tested behavior.
- **Checkpoints are plain `java.util.Properties` files**, not JSON or
  SharedPreferences - both have Android-testing gotchas (`org.json` throws
  "not mocked" in plain JVM unit tests; SharedPreferences is also
  framework-stubbed), while `Properties` is plain JVM and behaves
  identically in tests and production. The `.nova-backup` format uses the
  same length-prefixed-field philosophy as archive metadata for the same
  reason.
- **R8 keep rules are deliberately broad**, not minimal. A wrong keep rule
  is a runtime crash this sandbox cannot detect (no device/emulator to
  install the shrunk APK on); CI building `assembleRelease` catches
  build-time mistakes but not runtime ones.
- **Archive repair has an honest, stated limit.** Chunks are stored inline
  (each preceded by its own size field), not behind an independent chunk
  directory, so recovery can only continue past a damaged chunk if that
  chunk's size field is still intact. A corrupted size field halts
  structural parsing at that exact point rather than guessing.
- **`GenomeRepository` is an interface** specifically so `EvolutionEngine`'s
  mutation/crossover/selection logic can be unit tested against an
  in-memory fake instead of requiring Room's real SQLite backing, which
  doesn't work in plain JVM unit tests without adding Robolectric.
- **The Knowledge Database's growth is actively bounded**, not left to
  accumulate - background research runs every 6 hours indefinitely, so
  `KnowledgeMaintenanceService` prunes old benchmark records and retires
  (never deletes) genomes beyond a 500-genome population cap.
- **No Hilt yet.** A handful of hand-wired singletons doesn't justify the
  KSP/annotation-processor surface area; `ServiceLocator` is a plain
  Kotlin class, and `BackgroundResearchWorker` reaches it via a plain
  `applicationContext` cast. Fine for one Worker with no constructor
  dependencies of its own; worth revisiting if a second Worker needs real
  constructor-injected dependencies.
- **Files are saved to app-scoped external storage**
  (`getExternalFilesDir()`), not a user-chosen SAF destination (except for
  the backup export/import, which does use SAF since it's inherently a
  "save this specific file somewhere the user chooses" action), so no
  storage permissions are needed for ordinary compress/decompress.
