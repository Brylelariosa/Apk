package com.novacompress.ai.testutil

import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.evolution.GenomeRepository
import com.novacompress.ai.core.genome.CompressionGenome

class InMemoryGenomeRepository : GenomeRepository {

    private data class Record(var genome: CompressionGenome, var bestFitness: Double)

    private val genomes = LinkedHashMap<String, Record>()
    private var benchmarksRecorded = 0

    override suspend fun ensureSeeded(seeds: List<CompressionGenome>) {
        if (genomes.isEmpty()) {
            seeds.forEach { genomes[it.genomeId] = Record(it, 0.0) }
        }
    }

    override suspend fun topGenomesByFitness(limit: Int): List<CompressionGenome> =
        genomes.values.sortedByDescending { it.bestFitness }.take(limit).map { it.genome }

    override suspend fun recordBenchmark(result: BenchmarkResult, fitness: Double) {
        benchmarksRecorded++
        val existing = genomes[result.genome.genomeId]
        if (existing == null) {
            genomes[result.genome.genomeId] = Record(result.genome, fitness)
        } else if (fitness > existing.bestFitness) {
            existing.bestFitness = fitness
        }
    }

    override suspend fun genomeCount(): Int = genomes.size

    override suspend fun benchmarkCount(): Int = benchmarksRecorded
}
