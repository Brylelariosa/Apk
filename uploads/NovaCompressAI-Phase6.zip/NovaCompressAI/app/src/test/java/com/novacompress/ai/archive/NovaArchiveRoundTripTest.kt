package com.novacompress.ai.archive

import com.novacompress.ai.core.archive.ArchiveReadResult
import com.novacompress.ai.core.archive.NovaArchiveReader
import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class NovaArchiveRoundTripTest {

    private val smallChunkSize = 64 // deliberately small so short test samples still span multiple chunks

    @Test
    fun `archive round trips every sample with full verification`() {
        for ((label, data) in TestSamples.all()) {
            val archiveBytes = ByteArrayOutputStream().also { out ->
                NovaArchiveWriter.write(
                    output = out,
                    input = ByteArrayInputStream(data),
                    originalFileName = "$label.bin",
                    originalSize = data.size.toLong(),
                    genome = GenomePresets.BALANCED,
                    chunkSize = smallChunkSize
                )
            }.toByteArray()

            val recovered = ByteArrayOutputStream()
            val result = NovaArchiveReader.readAndVerify(ByteArrayInputStream(archiveBytes), recovered)

            assertTrue("expected Success for sample $label but got $result", result is ArchiveReadResult.Success)
            assertArrayEquals("recovered bytes did not match original for sample $label", data, recovered.toByteArray())
        }
    }

    @Test
    fun `metadata is preserved through the archive`() {
        val data = "NovaCompress AI research platform. ".repeat(500).toByteArray()
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(
                output = out,
                input = ByteArrayInputStream(data),
                originalFileName = "notes.txt",
                originalSize = data.size.toLong(),
                genome = GenomePresets.MAXIMUM_COMPRESSION,
                chunkSize = 4096
            )
        }.toByteArray()

        val recovered = ByteArrayOutputStream()
        val result = NovaArchiveReader.readAndVerify(ByteArrayInputStream(archiveBytes), recovered) as ArchiveReadResult.Success

        assertEquals("notes.txt", result.metadata.originalFileName)
        assertEquals(data.size.toLong(), result.metadata.originalSize)
        assertEquals("max_compression", result.metadata.genomeId)
        assertEquals(listOf("lz77", "huffman"), result.metadata.pipelinePluginIds)
    }

    @Test
    fun `progress callback fires once per chunk with correct counts, for both writing and reading`() {
        val data = TestSamples.randomBytes(1000, seed = 44)
        val chunkSize = 64
        val expectedChunks = (data.size + chunkSize - 1) / chunkSize

        val writeProgressCalls = mutableListOf<Pair<Int, Int>>()
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(
                output = out,
                input = ByteArrayInputStream(data),
                originalFileName = "progress.bin",
                originalSize = data.size.toLong(),
                genome = GenomePresets.FAST,
                chunkSize = chunkSize,
                onChunkComplete = { done, total -> writeProgressCalls.add(done to total) }
            )
        }.toByteArray()

        assertEquals(expectedChunks, writeProgressCalls.size)
        assertEquals((1..expectedChunks).map { it to expectedChunks }, writeProgressCalls)

        val readProgressCalls = mutableListOf<Pair<Int, Int>>()
        val recovered = ByteArrayOutputStream()
        NovaArchiveReader.readAndVerify(
            ByteArrayInputStream(archiveBytes),
            recovered,
            onChunkComplete = { done, total -> readProgressCalls.add(done to total) }
        )

        assertEquals(expectedChunks, readProgressCalls.size)
        assertEquals((1..expectedChunks).map { it to expectedChunks }, readProgressCalls)
    }

    @Test
    fun `a single flipped byte anywhere in the archive is detected as corruption`() {
        val data = "corruption test data ".repeat(500).toByteArray()
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(
                output = out,
                input = ByteArrayInputStream(data),
                originalFileName = "corrupt.bin",
                originalSize = data.size.toLong(),
                genome = GenomePresets.BALANCED,
                chunkSize = smallChunkSize
            )
        }.toByteArray()

        val mid = archiveBytes.size / 2
        archiveBytes[mid] = (archiveBytes[mid].toInt() xor 0xFF).toByte()

        val recovered = ByteArrayOutputStream()
        val result = NovaArchiveReader.readAndVerify(ByteArrayInputStream(archiveBytes), recovered)

        assertTrue("corruption was not detected!", result is ArchiveReadResult.Corrupted)
    }

    @Test
    fun `truncated archive is reported as corrupted, not as a crash`() {
        val data = TestSamples.randomBytes(2000)
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(
                output = out,
                input = ByteArrayInputStream(data),
                originalFileName = "truncated.bin",
                originalSize = data.size.toLong(),
                genome = GenomePresets.FAST,
                chunkSize = smallChunkSize
            )
        }.toByteArray()

        val truncated = archiveBytes.copyOf(archiveBytes.size / 2)
        val recovered = ByteArrayOutputStream()
        val result = NovaArchiveReader.readAndVerify(ByteArrayInputStream(truncated), recovered)

        assertTrue(result is ArchiveReadResult.Corrupted)
    }
}
