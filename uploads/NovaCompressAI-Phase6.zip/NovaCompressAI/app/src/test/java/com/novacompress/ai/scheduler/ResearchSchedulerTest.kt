package com.novacompress.ai.scheduler

import com.novacompress.ai.core.scheduler.BatteryStatusProvider
import com.novacompress.ai.core.scheduler.MemoryStatusProvider
import com.novacompress.ai.core.scheduler.ResearchGate
import com.novacompress.ai.core.scheduler.ResearchScheduler
import com.novacompress.ai.core.scheduler.ThermalStatusProvider
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeBattery(val charging: Boolean, val percent: Int) : BatteryStatusProvider {
    override fun isCharging() = charging
    override fun batteryPercent() = percent
}

private class FakeThermal(val throttled: Boolean) : ThermalStatusProvider {
    override fun isThrottled() = throttled
}

private class FakeMemory(val low: Boolean) : MemoryStatusProvider {
    override fun isLowMemory() = low
}

class ResearchSchedulerTest {

    @Test
    fun `research is allowed when charging, battery high, cool, and memory is fine`() {
        val scheduler = ResearchScheduler(FakeBattery(true, 80), FakeThermal(false), FakeMemory(false))
        assertTrue(scheduler.shouldRunResearch() is ResearchGate.Allowed)
    }

    @Test
    fun `research is blocked when not charging`() {
        val scheduler = ResearchScheduler(FakeBattery(false, 90), FakeThermal(false), FakeMemory(false))
        assertTrue(scheduler.shouldRunResearch() is ResearchGate.Blocked)
    }

    @Test
    fun `research is blocked when battery is below the threshold even while charging`() {
        val scheduler = ResearchScheduler(FakeBattery(true, 20), FakeThermal(false), FakeMemory(false), minBatteryPercent = 50)
        assertTrue(scheduler.shouldRunResearch() is ResearchGate.Blocked)
    }

    @Test
    fun `research is blocked when the device is thermally throttled`() {
        val scheduler = ResearchScheduler(FakeBattery(true, 90), FakeThermal(true), FakeMemory(false))
        assertTrue(scheduler.shouldRunResearch() is ResearchGate.Blocked)
    }

    @Test
    fun `research is blocked when the device is low on memory`() {
        val scheduler = ResearchScheduler(FakeBattery(true, 90), FakeThermal(false), FakeMemory(true))
        assertTrue(scheduler.shouldRunResearch() is ResearchGate.Blocked)
    }

    @Test
    fun `battery threshold is configurable`() {
        val lenient = ResearchScheduler(FakeBattery(true, 30), FakeThermal(false), FakeMemory(false), minBatteryPercent = 25)
        assertTrue(lenient.shouldRunResearch() is ResearchGate.Allowed)
    }
}
