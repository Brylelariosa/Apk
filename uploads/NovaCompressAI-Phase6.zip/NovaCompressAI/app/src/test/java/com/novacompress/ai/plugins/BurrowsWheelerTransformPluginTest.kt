package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test
import kotlin.random.Random

class BurrowsWheelerTransformPluginTest {

    private val plugin = BurrowsWheelerTransformPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `large and highly periodic data round trips correctly`() {
        val samples = listOf(
            TestSamples.randomBytes(50_000, seed = 12),
            ByteArray(20_000) { 7 }, // fully periodic, exercises the tie-break path
            ByteArray(20_000) { (it % 2).toByte() },
            ("the quick brown fox jumps over the lazy dog. ".repeat(500)).toByteArray()
        )
        for (data in samples) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals(data, decompressed)
        }
    }

    /**
     * Brute-force ground truth: build every rotation, sort them, take the
     * last column - the textbook definition of BWT. Used only in tests, to
     * confirm the plugin's efficient suffix-array-based construction
     * produces byte-for-byte the same transform (not just *a* valid
     * invertible permutation), mirroring how the Python prototype was
     * validated before this Kotlin port was written.
     */
    private fun naiveBwt(data: ByteArray): Pair<ByteArray, Int> {
        val n = data.size
        if (n == 0) return ByteArray(0) to 0

        val unsignedByteArrayComparator = Comparator<ByteArray> { a, b ->
            var result = 0
            for (idx in 0 until n) {
                val cmp = (a[idx].toInt() and 0xFF) - (b[idx].toInt() and 0xFF)
                if (cmp != 0) {
                    result = cmp
                    break
                }
            }
            result
        }

        val rotations = (0 until n)
            .map { start -> ByteArray(n) { k -> data[(start + k) % n] } to start }
            .sortedWith(compareBy(unsignedByteArrayComparator) { it.first })

        val transformed = ByteArray(n) { k -> rotations[k].first[n - 1] }
        val primaryIndex = rotations.indexOfFirst { it.second == 0 }
        return transformed to primaryIndex
    }

    @Test
    fun `matches the brute-force textbook definition on small inputs`() {
        val random = Random(21)
        val samples = mutableListOf(
            byteArrayOf(),
            byteArrayOf(1),
            byteArrayOf(1, 2),
            "banana".toByteArray(),
            "abracadabra".toByteArray(),
            "mississippi".toByteArray(),
            ByteArray(8) { 5 }
        )
        repeat(100) {
            val length = random.nextInt(13)
            samples.add(ByteArray(length) { random.nextInt(4).toByte() }) // small alphabet -> lots of ties
        }

        for (data in samples) {
            val expected = naiveBwt(data)
            val compressed = plugin.compress(data)
            // Decode the plugin's own wire format to compare transform + index directly.
            val primaryIndex = ((compressed[0].toInt() and 0xFF) shl 24) or
                ((compressed[1].toInt() and 0xFF) shl 16) or
                ((compressed[2].toInt() and 0xFF) shl 8) or
                (compressed[3].toInt() and 0xFF)
            val transformed = compressed.copyOfRange(4, compressed.size)

            assertArrayEquals("transform mismatch for ${data.toList()}", expected.first, transformed)
            assertEquals("primary index mismatch for ${data.toList()}", expected.second, primaryIndex)
        }
    }

    @Test
    fun `output is always exactly 4 bytes longer than the input`() {
        for ((_, data) in TestSamples.all()) {
            assertEquals(data.size + 4, plugin.compress(data).size)
        }
    }
}
