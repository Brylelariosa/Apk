package com.novacompress.ai.service

import com.novacompress.ai.core.service.CompressionService
import com.novacompress.ai.core.service.DecompressionOutcome
import com.novacompress.ai.core.service.DecompressionService
import com.novacompress.ai.testutil.TestSamples
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File

class ServiceRoundTripTest {

    // No EvolutionEngine supplied: compress() falls back to the fast heuristic
    // selector, which is all this test needs to exercise the archive/service
    // plumbing without requiring a real Room-backed genome repository.
    private val compressionService = CompressionService()
    private val decompressionService = DecompressionService()

    @Test
    fun `compress then decompress reproduces the original bytes for every sample`() = runTest {
        for ((label, data) in TestSamples.all()) {
            val archiveFile = File.createTempFile("nova_test_$label", ".nova")
            val restoredFile = File.createTempFile("nova_test_restored_$label", ".bin")
            try {
                val outcome = compressionService.compress(
                    openStream = { ByteArrayInputStream(data) },
                    originalFileName = "$label.bin",
                    originalSize = data.size.toLong(),
                    tempDestination = archiveFile
                )
                assertTrue(outcome.metadata.originalSize == data.size.toLong())

                val result = decompressionService.decompress(
                    openStream = { archiveFile.inputStream() },
                    tempDestination = restoredFile
                )

                assertTrue("decompression failed for $label: $result", result is DecompressionOutcome.Success)
                assertArrayEquals(
                    "restored bytes did not match original for sample $label",
                    data,
                    restoredFile.readBytes()
                )
            } finally {
                archiveFile.delete()
                restoredFile.delete()
            }
        }
    }

    @Test
    fun `a corrupted archive file is reported as failure and the temp output is cleaned up`() = runTest {
        val data = "some real data to compress ".repeat(200).toByteArray()
        val archiveFile = File.createTempFile("nova_test_corrupt", ".nova")
        val restoredFile = File.createTempFile("nova_test_corrupt_restored", ".bin")
        try {
            compressionService.compress(
                openStream = { ByteArrayInputStream(data) },
                originalFileName = "doc.txt",
                originalSize = data.size.toLong(),
                tempDestination = archiveFile
            )

            // Flip a byte roughly in the middle of the archive file.
            val bytes = archiveFile.readBytes()
            bytes[bytes.size / 2] = (bytes[bytes.size / 2].toInt() xor 0xFF).toByte()
            archiveFile.writeBytes(bytes)

            val result = decompressionService.decompress(
                openStream = { archiveFile.inputStream() },
                tempDestination = restoredFile
            )

            assertTrue(result is DecompressionOutcome.Failed)
            assertTrue("temp output should be deleted after a failed verification", !restoredFile.exists())
        } finally {
            archiveFile.delete()
            restoredFile.delete()
        }
    }
}
