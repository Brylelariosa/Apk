package com.novacompress.ai.service

import com.novacompress.ai.core.service.TempFileJanitor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class TempFileJanitorTest {

    @Test
    fun `removes old orphaned temp files but leaves recent ones and unrelated files alone`() {
        val dir = File.createTempFile("janitor_test", "").let {
            it.delete()
            it.mkdirs()
            it
        }
        try {
            val oldCompressing = File(dir, "compressing_111.tmp").apply { writeText("x") }
            val oldDecompressing = File(dir, "decompressing_222.tmp").apply { writeText("x") }
            val recentCompressing = File(dir, "compressing_333.tmp").apply { writeText("x") }
            val unrelatedFile = File(dir, "notes.txt").apply { writeText("keep me") }

            val twoHoursAgo = System.currentTimeMillis() - java.util.concurrent.TimeUnit.HOURS.toMillis(2)
            oldCompressing.setLastModified(twoHoursAgo)
            oldDecompressing.setLastModified(twoHoursAgo)
            // recentCompressing and unrelatedFile keep their just-created (recent) timestamp

            val removed = TempFileJanitor.cleanOrphans(dir)

            assertEquals(2, removed)
            assertFalse(oldCompressing.exists())
            assertFalse(oldDecompressing.exists())
            assertTrue("a recent temp file should not be removed", recentCompressing.exists())
            assertTrue("an unrelated file should never be touched", unrelatedFile.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `an old temp file with a matching checkpoint companion is preserved, not deleted`() {
        val dir = File.createTempFile("janitor_test_checkpoint", "").let {
            it.delete()
            it.mkdirs()
            it
        }
        try {
            val resumableTemp = File(dir, "compressing_444.tmp").apply { writeText("partial archive bytes") }
            val checkpointCompanion = File(dir, "compressing_444.tmp.checkpoint").apply { writeText("checkpoint data") }
            val orphanWithoutCheckpoint = File(dir, "compressing_555.tmp").apply { writeText("truly orphaned") }

            val twoHoursAgo = System.currentTimeMillis() - java.util.concurrent.TimeUnit.HOURS.toMillis(2)
            resumableTemp.setLastModified(twoHoursAgo)
            orphanWithoutCheckpoint.setLastModified(twoHoursAgo)

            val removed = TempFileJanitor.cleanOrphans(dir)

            assertEquals(1, removed)
            assertTrue("a temp file with a checkpoint companion must survive regardless of age", resumableTemp.exists())
            assertTrue("the checkpoint companion itself is never touched by the janitor", checkpointCompanion.exists())
            assertFalse("a temp file with no checkpoint companion is still cleaned up as before", orphanWithoutCheckpoint.exists())
        } finally {
            dir.deleteRecursively()
        }
    }

    @Test
    fun `does nothing and does not throw on an empty or missing directory`() {
        val emptyDir = File.createTempFile("janitor_empty", "").let {
            it.delete()
            it.mkdirs()
            it
        }
        try {
            assertEquals(0, TempFileJanitor.cleanOrphans(emptyDir))
        } finally {
            emptyDir.deleteRecursively()
        }

        val missingDir = File(emptyDir, "does_not_exist")
        assertEquals(0, TempFileJanitor.cleanOrphans(missingDir))
    }
}
