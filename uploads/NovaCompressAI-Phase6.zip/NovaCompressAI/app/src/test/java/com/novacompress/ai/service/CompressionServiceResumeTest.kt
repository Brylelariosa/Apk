package com.novacompress.ai.service

import com.novacompress.ai.core.archive.ArchiveReadResult
import com.novacompress.ai.core.archive.NovaArchiveReader
import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.service.CompressionCheckpoint
import com.novacompress.ai.core.service.CompressionCheckpointStore
import com.novacompress.ai.core.service.CompressionService
import com.novacompress.ai.testutil.TestSamples
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

class CompressionServiceResumeTest {

    private fun offsetAfterNChunks(archiveBytes: ByteArray, chunksToKeep: Int): Int {
        var pos = 4 + 1
        val metaLen = BinaryIO.readU32(archiveBytes, pos)
        pos += 4 + metaLen
        pos += 4
        repeat(chunksToKeep) {
            val compSize = BinaryIO.readU32(archiveBytes, pos)
            pos += 4 + compSize + 32
        }
        return pos
    }

    @Test
    fun `compress detects and resumes a checkpoint left behind by a simulated crash`() = runTest {
        // No EvolutionEngine supplied: uses the deterministic heuristic selector,
        // so the same data always picks the same genome - needed to construct a
        // matching manual checkpoint below.
        val service = CompressionService()
        val data = TestSamples.randomBytes(3000, seed = 91)

        // 1. A normal, uninterrupted compression - our reference for "what should
        //    the final archive look like", and to learn which genome gets picked.
        val referenceFile = File.createTempFile("nova_resume_ref", ".nova")
        val referenceOutcome = service.compress(
            openStream = { ByteArrayInputStream(data) },
            originalFileName = "video.bin",
            originalSize = data.size.toLong(),
            tempDestination = referenceFile
        )
        val completeArchiveBytes = referenceFile.readBytes()
        assertFalse(referenceOutcome.resumed)

        // 2. Simulate a crash partway through a *different* attempt: truncate a
        //    copy of the complete archive after some early chunk, and write a
        //    checkpoint file that claims that much progress.
        val totalChunks = referenceOutcome.metadata.chunkCount
        val chunksAlreadyDone = (totalChunks / 3).coerceAtLeast(1)
        val truncateAt = offsetAfterNChunks(completeArchiveBytes, chunksAlreadyDone)

        val crashedTempFile = File.createTempFile("compressing_crashed", ".tmp")
        crashedTempFile.writeBytes(completeArchiveBytes.copyOf(truncateAt))

        val checkpointFile = File(crashedTempFile.parentFile, "${crashedTempFile.name}.checkpoint")
        CompressionCheckpointStore.save(
            checkpointFile,
            CompressionCheckpoint(
                sourceKey = "video.bin:${data.size}",
                originalFileName = "video.bin",
                originalSize = data.size.toLong(),
                genomeId = referenceOutcome.chosenGenome.genome.genomeId,
                pipelinePluginIds = referenceOutcome.chosenGenome.genome.pipeline.pluginIds,
                chunkSize = Constants.DEFAULT_CHUNK_SIZE,
                chunkCount = totalChunks,
                chunksCompleted = chunksAlreadyDone,
                tempArchivePath = crashedTempFile.absolutePath,
                createdAtEpochMillis = System.currentTimeMillis()
            )
        )

        try {
            // 3. "Retry" the same logical compression, with the same resumeKey and
            //    the same tempDestination the checkpoint references - this must be
            //    detected as a resumable checkpoint rather than starting fresh.
            val progressCalls = mutableListOf<Pair<Int, Int>>()
            val resumedOutcome = service.compress(
                openStream = { ByteArrayInputStream(data) },
                originalFileName = "video.bin",
                originalSize = data.size.toLong(),
                tempDestination = crashedTempFile,
                resumeKey = "video.bin:${data.size}",
                onProgress = { done, total -> progressCalls.add(done to total) }
            )

            assertTrue("expected the checkpoint to be detected and resumed", resumedOutcome.resumed)
            assertTrue(progressCalls.isNotEmpty())
            assertTrue(
                "every progress callback during resume should report a chunk index past what was already done",
                progressCalls.all { it.first > chunksAlreadyDone }
            )

            val finalBytes = crashedTempFile.readBytes()
            assertArrayEquals(
                "resumed archive should exactly match an uninterrupted compression",
                completeArchiveBytes,
                finalBytes
            )

            val recovered = ByteArrayOutputStream()
            val result = NovaArchiveReader.readAndVerify(ByteArrayInputStream(finalBytes), recovered)
            assertTrue(result is ArchiveReadResult.Success)
            assertArrayEquals(data, recovered.toByteArray())

            assertFalse("checkpoint should be cleaned up after a successful resume", checkpointFile.exists())
        } finally {
            referenceFile.delete()
            crashedTempFile.delete()
            checkpointFile.delete()
        }
    }

    @Test
    fun `a mismatched checkpoint (different file) is ignored and a fresh compression proceeds normally`() = runTest {
        val service = CompressionService()
        val data = TestSamples.randomBytes(1000, seed = 12)

        val tempFile = File.createTempFile("nova_resume_mismatch", ".tmp")
        val checkpointFile = File(tempFile.parentFile, "${tempFile.name}.checkpoint")
        // A checkpoint that does NOT match this file's name/size at all.
        CompressionCheckpointStore.save(
            checkpointFile,
            CompressionCheckpoint(
                sourceKey = "unrelated-key",
                originalFileName = "totally_different_file.bin",
                originalSize = 999_999L,
                genomeId = "balanced",
                pipelinePluginIds = listOf("delta", "rle", "huffman"),
                chunkSize = Constants.DEFAULT_CHUNK_SIZE,
                chunkCount = 10,
                chunksCompleted = 5,
                tempArchivePath = tempFile.absolutePath,
                createdAtEpochMillis = System.currentTimeMillis()
            )
        )

        try {
            val outcome = service.compress(
                openStream = { ByteArrayInputStream(data) },
                originalFileName = "my_real_file.bin",
                originalSize = data.size.toLong(),
                tempDestination = tempFile,
                resumeKey = "my_real_file.bin:${data.size}"
            )

            assertFalse("a non-matching checkpoint must never be resumed", outcome.resumed)
            assertEquals(data.size.toLong(), outcome.metadata.originalSize)

            val recovered = ByteArrayOutputStream()
            val result = NovaArchiveReader.readAndVerify(tempFile.inputStream(), recovered)
            assertTrue(result is ArchiveReadResult.Success)
            assertArrayEquals(data, recovered.toByteArray())
        } finally {
            tempFile.delete()
            checkpointFile.delete()
        }
    }
}
