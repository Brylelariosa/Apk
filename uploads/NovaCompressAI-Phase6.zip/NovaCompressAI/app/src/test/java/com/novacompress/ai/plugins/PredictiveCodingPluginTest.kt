package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PredictiveCodingPluginTest {

    private val plugin = PredictiveCodingPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `output length always equals input length`() {
        for ((_, data) in TestSamples.all()) {
            assert(plugin.compress(data).size == data.size)
        }
    }

    @Test
    fun `a steady linear ramp produces an almost entirely zero residual stream`() {
        val data = ByteArray(768) { (it % 256).toByte() } // three full 0..255 ramps back to back
        val compressed = plugin.compress(data)
        val zeroCount = compressed.count { it.toInt() == 0 }
        assertTrue(
            "expected the linear predictor to zero out almost all residuals on a steady ramp, got $zeroCount/${compressed.size}",
            zeroCount >= compressed.size - 2
        )
        assertArrayEquals(data, plugin.decompress(compressed))
    }

    @Test
    fun `wrapping linear ramp across the byte boundary still round trips`() {
        val data = byteArrayOf(200.toByte(), 150.toByte(), 100.toByte(), 50.toByte(), 0, 206.toByte(), 156.toByte(), 106.toByte(), 56.toByte(), 6)
        assertArrayEquals(data, plugin.decompress(plugin.compress(data)))
    }
}
