package com.novacompress.ai.archive

import com.novacompress.ai.core.archive.ArchiveReadResult
import com.novacompress.ai.core.archive.NovaArchiveReader
import com.novacompress.ai.core.archive.NovaArchiveResumer
import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile

class NovaArchiveResumerTest {

    private val chunkSize = 64

    /**
     * Parses a complete archive up through the header and the first
     * [chunksToKeep] chunks (mirroring [NovaArchiveReader]'s own parsing),
     * returning the byte offset right after the [chunksToKeep]-th chunk's
     * hash - exactly where a real interruption after that many chunks
     * would have left off. Lets tests construct a genuinely truncated
     * "partial archive" fixture rather than trusting resume() to agree
     * with itself about where chunks end.
     */
    private fun offsetAfterNChunks(archiveBytes: ByteArray, chunksToKeep: Int): Int {
        var pos = 4 // magic
        pos += 1 // version
        val metaLen = BinaryIO.readU32(archiveBytes, pos)
        pos += 4 + metaLen
        pos += 4 // chunk count header field
        repeat(chunksToKeep) {
            val compSize = BinaryIO.readU32(archiveBytes, pos)
            pos += 4 + compSize + 32 // size field + compressed bytes + SHA-256 hash
        }
        return pos
    }

    /**
     * Appends to [file] starting at its current end, via a raw
     * RandomAccessFile-backed FileOutputStream - deliberately does NOT
     * close the returned stream itself (that would close the shared file
     * descriptor); the caller closes [RandomAccessFile] once, at the end.
     */
    private fun openForAppend(file: File): Pair<RandomAccessFile, FileOutputStream> {
        val raf = RandomAccessFile(file, "rw")
        raf.seek(file.length())
        return raf to FileOutputStream(raf.fd)
    }

    @Test
    fun `resuming from a genuinely truncated partial archive reproduces the exact same complete archive`() {
        val data = TestSamples.randomBytes(2000, seed = 33)
        val genome = GenomePresets.BALANCED

        val completeArchive = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(
                output = out,
                input = ByteArrayInputStream(data),
                originalFileName = "resume_test.bin",
                originalSize = data.size.toLong(),
                genome = genome,
                chunkSize = chunkSize
            )
        }.toByteArray()

        val totalChunks = (data.size + chunkSize - 1) / chunkSize
        val chunksAlreadyWritten = totalChunks / 2
        assertTrue("test setup needs at least 2 chunks to be meaningful", chunksAlreadyWritten in 1 until totalChunks)

        val truncateAt = offsetAfterNChunks(completeArchive, chunksAlreadyWritten)
        val partialArchiveFile = File.createTempFile("nova_resume_test", ".bin")
        try {
            partialArchiveFile.writeBytes(completeArchive.copyOf(truncateAt))

            val (raf, appendStream) = openForAppend(partialArchiveFile)
            val progressCalls = mutableListOf<Pair<Int, Int>>()
            try {
                NovaArchiveResumer.resume(
                    output = appendStream,
                    input = ByteArrayInputStream(data), // fresh stream from the very start, as required
                    genome = genome,
                    chunkSize = chunkSize,
                    chunkCount = totalChunks,
                    chunksAlreadyWritten = chunksAlreadyWritten,
                    onChunkComplete = { done, total -> progressCalls.add(done to total) }
                )
            } finally {
                raf.close()
            }

            assertEquals(totalChunks - chunksAlreadyWritten, progressCalls.size)
            assertEquals(totalChunks, progressCalls.last().second)
            assertEquals(totalChunks, progressCalls.last().first)

            val resumedArchiveBytes = partialArchiveFile.readBytes()

            assertArrayEquals(
                "resumed archive should be byte-for-byte identical to an uninterrupted write",
                completeArchive,
                resumedArchiveBytes
            )

            val recovered = ByteArrayOutputStream()
            val result = NovaArchiveReader.readAndVerify(ByteArrayInputStream(resumedArchiveBytes), recovered)
            assertTrue(result is ArchiveReadResult.Success)
            assertArrayEquals(data, recovered.toByteArray())
        } finally {
            partialArchiveFile.delete()
        }
    }

    @Test
    fun `resuming from zero chunks already written behaves like a fresh write`() {
        val data = "resume from scratch test ".repeat(100).toByteArray()
        val genome = GenomePresets.FAST
        val totalChunks = (data.size + chunkSize - 1) / chunkSize

        val completeArchive = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(out, ByteArrayInputStream(data), "scratch.bin", data.size.toLong(), genome, chunkSize)
        }.toByteArray()
        val truncateAt = offsetAfterNChunks(completeArchive, 0)
        val partialFile = File.createTempFile("nova_resume_test", ".bin")
        try {
            partialFile.writeBytes(completeArchive.copyOf(truncateAt))

            val (raf, appendStream) = openForAppend(partialFile)
            try {
                NovaArchiveResumer.resume(
                    output = appendStream,
                    input = ByteArrayInputStream(data),
                    genome = genome,
                    chunkSize = chunkSize,
                    chunkCount = totalChunks,
                    chunksAlreadyWritten = 0
                )
            } finally {
                raf.close()
            }

            assertArrayEquals(completeArchive, partialFile.readBytes())
        } finally {
            partialFile.delete()
        }
    }

    @Test
    fun `resuming from all-but-the-last chunk still round trips correctly`() {
        val data = TestSamples.randomBytes(500, seed = 5)
        val genome = GenomePresets.MAXIMUM_COMPRESSION
        val totalChunks = (data.size + chunkSize - 1) / chunkSize

        val completeArchive = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(out, ByteArrayInputStream(data), "almost_done.bin", data.size.toLong(), genome, chunkSize)
        }.toByteArray()

        val truncateAt = offsetAfterNChunks(completeArchive, totalChunks - 1)
        val partialFile = File.createTempFile("nova_resume_test", ".bin")
        try {
            partialFile.writeBytes(completeArchive.copyOf(truncateAt))

            val (raf, appendStream) = openForAppend(partialFile)
            try {
                NovaArchiveResumer.resume(
                    output = appendStream,
                    input = ByteArrayInputStream(data),
                    genome = genome,
                    chunkSize = chunkSize,
                    chunkCount = totalChunks,
                    chunksAlreadyWritten = totalChunks - 1
                )
            } finally {
                raf.close()
            }

            assertArrayEquals(completeArchive, partialFile.readBytes())
        } finally {
            partialFile.delete()
        }
    }
}
