package com.novacompress.ai.benchmark

import com.novacompress.ai.core.benchmark.BenchmarkLaboratory
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BenchmarkLaboratoryTest {

    @Test
    fun `benchmarking a real genome on real data reports verified with a real ratio`() {
        val data = "benchmark test data ".repeat(500).toByteArray()
        val result = BenchmarkLaboratory.benchmark(GenomePresets.BALANCED, data)

        assertTrue(result.verified)
        assertEquals(data.size, result.originalSize)
        assertTrue(result.compressedSize > 0)
        assertTrue(result.ratio > 0.0)
        assertTrue("expected a nonzero compression time to actually be measured", result.compressionTimeNanos >= 0)
        assertTrue("expected a nonzero decompression time to actually be measured", result.decompressionTimeNanos >= 0)
    }

    @Test
    fun `every genome preset verifies on every sample`() {
        for (genome in GenomePresets.all) {
            for ((label, data) in TestSamples.all()) {
                val result = BenchmarkLaboratory.benchmark(genome, data)
                assertTrue("genome ${genome.genomeId} failed verification on sample $label: ${result.failureReason}", result.verified)
            }
        }
    }
}
