package com.novacompress.ai.service

import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.core.service.ArchiveRepairService
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

class ArchiveRepairServiceTest {

    private val service = ArchiveRepairService()

    @Test
    fun `repairing an intact archive fully recovers it and produces an output file`() {
        val data = TestSamples.randomBytes(2000, seed = 71)
        val archiveBytes = ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(out, ByteArrayInputStream(data), "x.bin", data.size.toLong(), GenomePresets.FAST)
        }.toByteArray()

        val outFile = File.createTempFile("nova_repair_test", ".bin")
        try {
            val outcome = service.repair({ ByteArrayInputStream(archiveBytes) }, outFile)
            assertTrue(outcome.report.fullyRecovered)
            assertNotNull(outcome.outputFile)
            assertTrue(outFile.readBytes().contentEquals(data))
        } finally {
            outFile.delete()
        }
    }

    @Test
    fun `repairing something that isn't a nova archive at all recovers nothing and cleans up`() {
        val garbage = "this is not a nova archive".toByteArray()
        val outFile = File.createTempFile("nova_repair_garbage", ".bin")
        try {
            val outcome = service.repair({ ByteArrayInputStream(garbage) }, outFile)
            assertNull(outcome.outputFile)
            assertNull(outcome.report.metadata)
            assertTrue("temp file should be cleaned up when nothing was recovered", !outFile.exists())
        } finally {
            outFile.delete()
        }
    }
}
