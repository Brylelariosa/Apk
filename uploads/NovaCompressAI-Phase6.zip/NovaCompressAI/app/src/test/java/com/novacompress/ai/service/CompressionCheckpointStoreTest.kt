package com.novacompress.ai.service

import com.novacompress.ai.core.service.CompressionCheckpoint
import com.novacompress.ai.core.service.CompressionCheckpointStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.File

class CompressionCheckpointStoreTest {

    private val sample = CompressionCheckpoint(
        sourceKey = "key123",
        originalFileName = "video.mp4",
        originalSize = 123_456_789L,
        genomeId = "gen_abcdef",
        pipelinePluginIds = listOf("bwt", "mtf", "rle", "huffman"),
        chunkSize = 262_144,
        chunkCount = 471,
        chunksCompleted = 200,
        tempArchivePath = "/data/data/com.novacompress.ai/cache/compressing_1.tmp",
        createdAtEpochMillis = 1_700_000_000_000L
    )

    @Test
    fun `save then load reproduces the exact same checkpoint`() {
        val file = File.createTempFile("nova_checkpoint_test", ".properties")
        try {
            CompressionCheckpointStore.save(file, sample)
            val loaded = CompressionCheckpointStore.load(file)
            assertEquals(sample, loaded)
        } finally {
            file.delete()
        }
    }

    @Test
    fun `load returns null for a missing file`() {
        val file = File("/tmp/definitely_does_not_exist_${System.nanoTime()}.properties")
        assertNull(CompressionCheckpointStore.load(file))
    }

    @Test
    fun `load returns null rather than throwing for a corrupt or incomplete file`() {
        val file = File.createTempFile("nova_checkpoint_corrupt", ".properties")
        try {
            file.writeText("genomeId=only_one_field_present")
            assertNull(CompressionCheckpointStore.load(file))
        } finally {
            file.delete()
        }
    }

    @Test
    fun `delete removes the file`() {
        val file = File.createTempFile("nova_checkpoint_delete", ".properties")
        CompressionCheckpointStore.save(file, sample)
        CompressionCheckpointStore.delete(file)
        assertNull(CompressionCheckpointStore.load(file))
    }
}
