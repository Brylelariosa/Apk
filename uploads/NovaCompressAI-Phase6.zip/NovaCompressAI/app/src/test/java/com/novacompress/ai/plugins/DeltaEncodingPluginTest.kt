package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Test

class DeltaEncodingPluginTest {

    private val plugin = DeltaEncodingPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `output length always equals input length`() {
        for ((_, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            assert(compressed.size == data.size)
        }
    }
}
