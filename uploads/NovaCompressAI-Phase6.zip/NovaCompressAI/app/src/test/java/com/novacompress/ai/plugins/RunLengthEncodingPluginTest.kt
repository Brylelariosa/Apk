package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Test

class RunLengthEncodingPluginTest {

    private val plugin = RunLengthEncodingPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `decoder accepts the reserved no-op control byte without crashing`() {
        // Byte value 128 is reserved as a no-op; a correct decoder must not
        // throw or read extra bytes for it even though the encoder never emits it.
        val decompressed = plugin.decompress(byteArrayOf(128.toByte()))
        assertArrayEquals(ByteArray(0), decompressed)
    }

    @Test
    fun `long run is split across multiple run tokens`() {
        val data = ByteArray(500) { 42 }
        val compressed = plugin.compress(data)
        // Each run token can cover at most 128 repeats, so 500 bytes needs at least ceil(500/128) tokens.
        assert(compressed.size >= 8)
        assertArrayEquals(data, plugin.decompress(compressed))
    }
}
