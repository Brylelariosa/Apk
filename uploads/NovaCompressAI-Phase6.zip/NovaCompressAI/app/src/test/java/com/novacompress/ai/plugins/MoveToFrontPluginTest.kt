package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Test

class MoveToFrontPluginTest {

    private val plugin = MoveToFrontPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `output length always equals input length`() {
        for ((_, data) in TestSamples.all()) {
            assert(plugin.compress(data).size == data.size)
        }
    }

    @Test
    fun `a repeated byte immediately after itself encodes as zero`() {
        val data = byteArrayOf(42, 42, 42)
        val compressed = plugin.compress(data)
        // First occurrence's index depends on initial table position (42),
        // but every occurrence after the first repeat must encode as 0.
        assert(compressed[1].toInt() == 0)
        assert(compressed[2].toInt() == 0)
    }
}
