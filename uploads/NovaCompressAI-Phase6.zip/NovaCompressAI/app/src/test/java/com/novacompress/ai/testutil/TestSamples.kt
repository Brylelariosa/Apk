package com.novacompress.ai.testutil

import kotlin.random.Random

/** Sample byte arrays shared across round-trip tests, covering the edge cases that matter for lossless correctness. */
object TestSamples {

    fun all(): List<Pair<String, ByteArray>> {
        val random = Random(42)
        return listOf(
            "empty" to ByteArray(0),
            "single_byte" to byteArrayOf(7),
            "all_same_255" to ByteArray(255) { 5 },
            "all_same_1000" to ByteArray(1000) { 9 },
            "all_zero_500" to ByteArray(500),
            "random_2000" to ByteArray(2000) { random.nextInt(256).toByte() },
            "text" to "The quick brown fox jumps over the lazy dog. ".repeat(50).toByteArray(Charsets.UTF_8),
            "mixed_runs_and_literals" to (
                byteArrayOf(1, 2, 3) + ByteArray(10) { 9 } + byteArrayOf(1, 2, 3, 4, 5, 6, 7) +
                    ByteArray(300) + byteArrayOf(-56, -55) // 200, 201 as signed bytes
                ),
            "two_run_edge" to byteArrayOf(7, 7),
            "three_run_edge" to byteArrayOf(7, 7, 7),
            "max_run_plus_one" to ByteArray(129) { 3 },
            "max_literal_plus_one" to ByteArray(129) { random.nextInt(256).toByte() },
            "all_256_values_once" to ByteArray(256) { it.toByte() },
            "skewed" to (ByteArray(900) + ByteArray(80) { 1 } + ByteArray(15) { 2 } + ByteArray(4) { 3 } + byteArrayOf(4))
        )
    }

    fun randomBytes(size: Int, seed: Int = 1): ByteArray {
        val random = Random(seed)
        return ByteArray(size) { random.nextInt(256).toByte() }
    }
}
