package com.novacompress.ai.archive

import com.novacompress.ai.core.archive.ArchiveReadResult
import com.novacompress.ai.core.archive.NovaArchiveInspector
import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.genome.GenomePresets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class NovaArchiveInspectorTest {

    private fun buildArchive(data: ByteArray, fileName: String, genome: com.novacompress.ai.core.genome.CompressionGenome, chunkSize: Int = 4096): ByteArray {
        val out = ByteArrayOutputStream()
        NovaArchiveWriter.write(
            output = out,
            input = ByteArrayInputStream(data),
            originalFileName = fileName,
            originalSize = data.size.toLong(),
            genome = genome,
            chunkSize = chunkSize
        )
        return out.toByteArray()
    }

    @Test
    fun `peek reports correct metadata without needing to process any chunk data`() {
        val data = ("inspector test data " .repeat(2000)).toByteArray()
        val archiveBytes = buildArchive(data, "big_document.txt", GenomePresets.RESEARCH_MODE)

        // Corrupt every chunk's compressed bytes (well past the header) - peek
        // must still succeed, since it never touches chunk data at all.
        val corrupted = archiveBytes.copyOf()
        for (i in corrupted.size / 2 until corrupted.size) {
            corrupted[i] = (corrupted[i].toInt() xor 0x55).toByte()
        }

        val result = NovaArchiveInspector.peek(ByteArrayInputStream(corrupted))
        assertTrue("peek should ignore chunk corruption entirely: $result", result is ArchiveReadResult.Success)
        val metadata = (result as ArchiveReadResult.Success).metadata
        assertEquals("big_document.txt", metadata.originalFileName)
        assertEquals(data.size.toLong(), metadata.originalSize)
        assertEquals("research_mode", metadata.genomeId)
        assertEquals(listOf("bwt", "mtf", "arithmetic"), metadata.pipelinePluginIds)
    }

    @Test
    fun `peek detects a corrupted header even though it never checks chunk hashes`() {
        val data = "short header corruption test".toByteArray()
        val archiveBytes = buildArchive(data, "note.txt", GenomePresets.FAST).copyOf()
        archiveBytes[0] = 'X'.code.toByte() // corrupt the magic header itself

        val result = NovaArchiveInspector.peek(ByteArrayInputStream(archiveBytes))
        assertTrue(result is ArchiveReadResult.Corrupted)
    }

    @Test
    fun `peek works correctly on an empty original file`() {
        val archiveBytes = buildArchive(ByteArray(0), "empty.bin", GenomePresets.BALANCED)
        val result = NovaArchiveInspector.peek(ByteArrayInputStream(archiveBytes))
        assertTrue(result is ArchiveReadResult.Success)
        assertEquals(0L, (result as ArchiveReadResult.Success).metadata.originalSize)
    }
}
