package com.novacompress.ai.backup

import com.novacompress.ai.core.backup.BenchmarkBackupRecord
import com.novacompress.ai.core.backup.GenomeBackupRecord
import com.novacompress.ai.core.backup.KnowledgeBackup
import com.novacompress.ai.core.backup.KnowledgeBackupCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class KnowledgeBackupCodecTest {

    private val sampleGenome = GenomeBackupRecord(
        genomeId = "gen_abc123",
        displayName = "Evolved (Delta \u2192 Huffman)",
        pluginIdsCsv = "delta,huffman",
        rationale = "Produced by mutating gen_seed1.",
        generation = 3,
        species = "general",
        status = "VERIFIED",
        parentIdsCsv = "gen_seed1",
        bestFitness = 2.3456,
        bestRatio = 2.5,
        benchmarkCount = 7,
        createdAtEpochMillis = 1_700_000_000_000L
    )

    private val sampleBenchmark = BenchmarkBackupRecord(
        genomeId = "gen_abc123",
        originalSize = 65536,
        compressedSize = 26214,
        compressionTimeNanos = 1_234_567L,
        decompressionTimeNanos = 234_567L,
        verified = true,
        fitnessScore = 2.3456,
        createdAtEpochMillis = 1_700_000_001_000L
    )

    @Test
    fun `encode then decode reproduces an empty backup exactly`() {
        val backup = KnowledgeBackup(1_700_000_000_000L, emptyList(), emptyList())
        val decoded = KnowledgeBackupCodec.decode(KnowledgeBackupCodec.encode(backup))
        assertEquals(backup, decoded)
    }

    @Test
    fun `encode then decode reproduces genomes and benchmarks exactly`() {
        val backup = KnowledgeBackup(
            exportedAtEpochMillis = 1_700_000_002_000L,
            genomes = listOf(sampleGenome, sampleGenome.copy(genomeId = "gen_def456", status = "RETIRED")),
            benchmarks = listOf(sampleBenchmark, sampleBenchmark.copy(verified = false, fitnessScore = 0.0))
        )
        val decoded = KnowledgeBackupCodec.decode(KnowledgeBackupCodec.encode(backup))
        assertEquals(backup, decoded)
    }

    @Test
    fun `decode rejects a file with the wrong magic header`() {
        val bytes = "not a backup file at all, just plain text".toByteArray()
        assertThrows(IllegalArgumentException::class.java) {
            KnowledgeBackupCodec.decode(bytes)
        }
    }

    @Test
    fun `decode rejects a truncated file gracefully with an exception, not a crash`() {
        val backup = KnowledgeBackup(1L, listOf(sampleGenome), listOf(sampleBenchmark))
        val encoded = KnowledgeBackupCodec.encode(backup)
        val truncated = encoded.copyOf(encoded.size / 2)
        assertThrows(Exception::class.java) {
            KnowledgeBackupCodec.decode(truncated)
        }
    }
}
