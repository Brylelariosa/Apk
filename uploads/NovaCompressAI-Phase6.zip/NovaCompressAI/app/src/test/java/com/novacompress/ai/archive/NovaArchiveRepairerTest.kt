package com.novacompress.ai.archive

import com.novacompress.ai.core.archive.NovaArchiveRepairer
import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class NovaArchiveRepairerTest {

    private val chunkSize = 64

    /** Byte offset where chunk [chunkIndex]'s 4-byte size field begins. */
    private fun chunkSizeFieldOffset(archiveBytes: ByteArray, chunkIndex: Int): Int {
        var pos = 4 + 1
        val metaLen = BinaryIO.readU32(archiveBytes, pos)
        pos += 4 + metaLen
        pos += 4
        repeat(chunkIndex) {
            val compSize = BinaryIO.readU32(archiveBytes, pos)
            pos += 4 + compSize + 32
        }
        return pos
    }

    private fun chunkContentOffset(archiveBytes: ByteArray, chunkIndex: Int): Int =
        chunkSizeFieldOffset(archiveBytes, chunkIndex) + 4

    private fun buildArchive(data: ByteArray, genome: com.novacompress.ai.core.genome.CompressionGenome = GenomePresets.FAST): ByteArray =
        ByteArrayOutputStream().also { out ->
            NovaArchiveWriter.write(out, ByteArrayInputStream(data), "repair_test.bin", data.size.toLong(), genome, chunkSize)
        }.toByteArray()

    @Test
    fun `a fully intact archive is fully recovered`() {
        val data = TestSamples.randomBytes(1000, seed = 61)
        val archiveBytes = buildArchive(data)

        val recovered = ByteArrayOutputStream()
        val report = NovaArchiveRepairer.repair(ByteArrayInputStream(archiveBytes), recovered)

        assertTrue(report.fullyRecovered)
        assertNull(report.structurallyTruncatedAtChunk)
        assertTrue(report.chunkStatuses.all { it.recovered })
        assertArrayEquals(data, recovered.toByteArray())
    }

    @Test
    fun `corrupting one chunk's content still recovers every other chunk with the gap zero-filled`() {
        val data = TestSamples.randomBytes(1000, seed = 62)
        val archiveBytes = buildArchive(data).copyOf()

        val totalChunks = (data.size + chunkSize - 1) / chunkSize
        assertTrue("test needs at least 3 chunks", totalChunks >= 3)
        val victimChunk = 1

        // Flip a byte inside the victim chunk's compressed content (not its size field).
        val contentOffset = chunkContentOffset(archiveBytes, victimChunk)
        archiveBytes[contentOffset] = (archiveBytes[contentOffset].toInt() xor 0xFF).toByte()

        val recovered = ByteArrayOutputStream()
        val report = NovaArchiveRepairer.repair(ByteArrayInputStream(archiveBytes), recovered)

        assertNull("size fields are all intact, so nothing should be structurally truncated", report.structurallyTruncatedAtChunk)
        assertEquals(totalChunks, report.chunkStatuses.size)
        assertEquals(false, report.chunkStatuses[victimChunk].recovered)
        for (i in report.chunkStatuses.indices) {
            if (i != victimChunk) assertTrue("chunk $i should have been recovered", report.chunkStatuses[i].recovered)
        }

        // Overall output length must still match the original (zero-filled gap preserves layout).
        assertEquals(data.size, recovered.toByteArray().size)

        // Everything outside the victim chunk's byte range should match the original exactly.
        val recoveredBytes = recovered.toByteArray()
        val victimStart = victimChunk * chunkSize
        val victimEnd = minOf(victimStart + chunkSize, data.size)
        for (i in data.indices) {
            if (i < victimStart || i >= victimEnd) {
                assertEquals("mismatch outside the corrupted chunk at byte $i", data[i], recoveredBytes[i])
            }
        }
    }

    @Test
    fun `a truncated archive recovers everything up to the truncation point and reports where it stopped`() {
        val data = TestSamples.randomBytes(1000, seed = 63)
        val archiveBytes = buildArchive(data)
        val totalChunks = (data.size + chunkSize - 1) / chunkSize
        assertTrue(totalChunks >= 3)

        val keepChunks = totalChunks - 1
        val truncateAt = chunkSizeFieldOffset(archiveBytes, keepChunks)
        val truncated = archiveBytes.copyOf(truncateAt)

        val recovered = ByteArrayOutputStream()
        val report = NovaArchiveRepairer.repair(ByteArrayInputStream(truncated), recovered)

        assertEquals(keepChunks, report.structurallyTruncatedAtChunk)
        assertEquals(keepChunks, report.chunkStatuses.size)
        assertTrue(report.chunkStatuses.all { it.recovered })
    }

    @Test
    fun `a corrupted size field stops structural parsing at that exact chunk`() {
        val data = TestSamples.randomBytes(1000, seed = 64)
        val archiveBytes = buildArchive(data).copyOf()
        val totalChunks = (data.size + chunkSize - 1) / chunkSize
        assertTrue(totalChunks >= 3)

        val victimChunk = 1
        val sizeFieldOffset = chunkSizeFieldOffset(archiveBytes, victimChunk)
        // Write an implausibly large size field - unreadable/untrustworthy, not just "wrong".
        archiveBytes[sizeFieldOffset] = 0x7F
        archiveBytes[sizeFieldOffset + 1] = 0x7F
        archiveBytes[sizeFieldOffset + 2] = 0x7F
        archiveBytes[sizeFieldOffset + 3] = 0x7F.toByte()

        val recovered = ByteArrayOutputStream()
        val report = NovaArchiveRepairer.repair(ByteArrayInputStream(archiveBytes), recovered)

        assertEquals(victimChunk, report.structurallyTruncatedAtChunk)
        assertEquals(victimChunk, report.chunkStatuses.size)
        assertTrue(report.chunkStatuses.all { it.recovered })
        assertFalse(report.fullyRecovered)
    }

    @Test
    fun `a bad magic header is reported immediately with no metadata and no recoverable chunks`() {
        val data = "irrelevant".toByteArray()
        val archiveBytes = buildArchive(data).copyOf()
        archiveBytes[0] = 'X'.code.toByte()

        val recovered = ByteArrayOutputStream()
        val report = NovaArchiveRepairer.repair(ByteArrayInputStream(archiveBytes), recovered)

        assertNull(report.metadata)
        assertEquals(0, report.structurallyTruncatedAtChunk)
        assertTrue(report.chunkStatuses.isEmpty())
        assertFalse(report.fullyRecovered)
    }
}
