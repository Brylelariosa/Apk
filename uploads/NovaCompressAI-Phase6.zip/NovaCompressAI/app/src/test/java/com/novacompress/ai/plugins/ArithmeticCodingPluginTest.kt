package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ArithmeticCodingPluginTest {

    private val plugin = ArithmeticCodingPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `empty input encodes to a single magic byte`() {
        val compressed = plugin.compress(ByteArray(0))
        assertTrue(compressed.size == 1)
        assertArrayEquals(ByteArray(0), plugin.decompress(compressed))
    }

    @Test
    fun `a single repeated symbol compresses to nearly nothing`() {
        val data = ByteArray(10_000) { 42 }
        val compressed = plugin.compress(data)
        // Header (magic + 1 symbol entry + length) is a small fixed cost;
        // the actual entropy-coded payload for a single-symbol stream should
        // be tiny regardless of how many times it repeats.
        assertTrue("expected near-total compression for a single repeated symbol, got ${compressed.size} bytes", compressed.size < 20)
        assertArrayEquals(data, plugin.decompress(compressed))
    }

    @Test
    fun `all 256 distinct byte values round trip correctly`() {
        val data = ByteArray(256) { it.toByte() }
        assertArrayEquals(data, plugin.decompress(plugin.compress(data)))
    }

    /**
     * Mirrors the Python prototype's stress test: many random seeds, varying
     * alphabet sizes and lengths (including alphabet size 1, which forces
     * the interval to never shrink, and length 0/1 boundary cases).
     */
    @Test
    fun `stress test across many random alphabet sizes and lengths`() {
        var trials = 0
        for (seed in 0 until 150) {
            val random = Random(seed)
            val length = random.nextInt(0, 500)
            val alphabet = listOf(1, 2, 3, 5, 16, 256).random(random)
            val data = ByteArray(length) { random.nextInt(alphabet).toByte() }

            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            trials++
            assertArrayEquals(
                "stress test failed: seed=$seed length=$length alphabet=$alphabet",
                data,
                decompressed
            )
        }
        assertTrue(trials == 150)
    }

    @Test
    fun `highly skewed frequency distribution round trips correctly`() {
        val data = ByteArray(9000) { 0 } + ByteArray(900) { 1 } + ByteArray(90) { 2 } + ByteArray(9) { 3 } + byteArrayOf(4)
        assertArrayEquals(data, plugin.decompress(plugin.compress(data)))
    }
}
