package com.novacompress.ai.evolution

import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.evolution.MutationEngine
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import com.novacompress.ai.core.plugins.PluginRegistry
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class MutationEngineTest {

    @Test
    fun `mutating any valid pipeline always produces another valid pipeline`() {
        val startingPipelines = listOf(
            PipelineDescriptor.of("delta"),
            PipelineDescriptor.of("delta", "rle", "huffman"),
            PipelineDescriptor.of("lz77", "huffman"),
            PipelineDescriptor.of("rle", "huffman", "mtf", "delta", "lz77")
        )
        val random = Random(123)

        for (pipeline in startingPipelines) {
            repeat(200) {
                val mutated = MutationEngine.mutate(pipeline, random)
                assertTrue(mutated.pluginIds.isNotEmpty())
                assertTrue(mutated.pluginIds.size <= Constants.MAX_PIPELINE_STAGES)
                assertTrue("mutation produced a duplicate plugin id: ${mutated.pluginIds}", mutated.pluginIds.size == mutated.pluginIds.toSet().size)
            }
        }
    }

    @Test
    fun `mutating a single-plugin pipeline never deletes down to zero plugins`() {
        val pipeline = PipelineDescriptor.of("huffman")
        val random = Random(7)
        repeat(500) {
            val mutated = MutationEngine.mutate(pipeline, random)
            assertTrue(mutated.pluginIds.isNotEmpty())
        }
    }

    @Test
    fun `mutating a pipeline that already uses every registered plugin stays valid`() {
        val allPluginsPipeline = PipelineDescriptor(PluginRegistry.all().map { it.id })
        val random = Random(9)
        repeat(500) {
            val mutated = MutationEngine.mutate(allPluginsPipeline, random)
            assertTrue(mutated.pluginIds.isNotEmpty())
            assertTrue(mutated.pluginIds.size <= Constants.MAX_PIPELINE_STAGES)
            assertTrue("mutation produced a duplicate plugin id: ${mutated.pluginIds}", mutated.pluginIds.size == mutated.pluginIds.toSet().size)
        }
    }
}
