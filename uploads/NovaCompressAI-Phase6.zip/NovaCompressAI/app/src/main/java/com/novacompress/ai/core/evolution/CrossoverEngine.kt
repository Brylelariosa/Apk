package com.novacompress.ai.core.evolution

import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import kotlin.random.Random

/**
 * Combines two parent pipelines by taking a prefix of one and a suffix of
 * the other, e.g. parent A = [delta, dictionary, lz77, huffman] and
 * parent B = [tileSplit, predictor, arithmetic] could produce a child
 * [delta, predictor, arithmetic] - directly mirroring the spec's Crossover
 * example.
 */
object CrossoverEngine {

    fun crossover(parentA: PipelineDescriptor, parentB: PipelineDescriptor, random: Random = Random.Default): PipelineDescriptor {
        val a = parentA.pluginIds
        val b = parentB.pluginIds

        val cutA = random.nextInt(a.size) + 1 // always >= 1, so the prefix is never empty
        val cutB = random.nextInt(b.size + 1) // may be b.size, i.e. contribute nothing from B

        // Parent prefix/suffix can share a plugin id (e.g. both use "huffman"); de-duplicate
        // while preserving first-occurrence order so the child stays a valid pipeline.
        val combined = (a.take(cutA) + b.drop(cutB)).distinct().take(Constants.MAX_PIPELINE_STAGES)
        return PipelineDescriptor(combined)
    }
}
