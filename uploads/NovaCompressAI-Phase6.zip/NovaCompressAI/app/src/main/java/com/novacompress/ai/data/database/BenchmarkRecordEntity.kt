package com.novacompress.ai.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One benchmark experiment. Nothing is ever overwritten or deleted here - "knowledge grows forever" per the spec. */
@Entity(tableName = "benchmark_records")
data class BenchmarkRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val genomeId: String,
    val originalSize: Int,
    val compressedSize: Int,
    val compressionTimeNanos: Long,
    val decompressionTimeNanos: Long,
    val verified: Boolean,
    val fitnessScore: Double,
    val createdAtEpochMillis: Long
)
