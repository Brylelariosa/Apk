package com.novacompress.ai.core.plugins

/**
 * Move-To-Front: maintains a 256-entry table of byte values, replacing each
 * input byte with its current index in the table, then moving that value
 * to the front. Bytes that recur soon after their last occurrence produce
 * small indices (lots of 0s/1s), which is exactly what RLE and Huffman
 * downstream are good at collapsing further.
 *
 * Output length always equals input length (one index byte per input byte).
 */
class MoveToFrontPlugin : CompressionPlugin {

    override val id: String = "mtf"
    override val displayName: String = "Move-To-Front"
    override val version: Int = 1

    override fun compress(input: ByteArray): ByteArray {
        val table = IntArray(256) { it }
        val out = ByteArray(input.size)
        for (i in input.indices) {
            val value = input[i].toInt() and 0xFF
            val pos = indexOf(table, value)
            out[i] = pos.toByte()
            moveToFront(table, pos)
        }
        return out
    }

    override fun decompress(input: ByteArray): ByteArray {
        val table = IntArray(256) { it }
        val out = ByteArray(input.size)
        for (i in input.indices) {
            val pos = input[i].toInt() and 0xFF
            val value = table[pos]
            out[i] = value.toByte()
            moveToFront(table, pos)
        }
        return out
    }

    private fun indexOf(table: IntArray, value: Int): Int {
        for (i in table.indices) {
            if (table[i] == value) return i
        }
        error("value not found in MTF table - table is corrupt (should be unreachable)")
    }

    /** Removes the entry at [pos] and reinserts it at the front, shifting everything between. */
    private fun moveToFront(table: IntArray, pos: Int) {
        val value = table[pos]
        for (i in pos downTo 1) {
            table[i] = table[i - 1]
        }
        table[0] = value
    }
}
