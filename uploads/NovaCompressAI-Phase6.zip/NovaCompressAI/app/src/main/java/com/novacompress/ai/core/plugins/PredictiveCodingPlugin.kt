package com.novacompress.ai.core.plugins

/**
 * Predictive Coding: a second-order linear predictor. Where Delta Encoding
 * assumes "the next byte is probably like the last one", this assumes "the
 * next byte probably continues the trend set by the last two" - i.e. it
 * linearly extrapolates. This makes it noticeably better than Delta on data
 * with a steady ramp (sensor readings, audio envelopes, gradients) while
 * being no worse in the worst case than any other single-byte predictor:
 * both encode to a residual stream of the same length as the input.
 *
 * Output length always equals input length. No header needed.
 */
class PredictiveCodingPlugin : CompressionPlugin {

    override val id: String = "predictive"
    override val displayName: String = "Predictive Coding"
    override val version: Int = 1

    private fun predict(prev1: Int, prev2: Int): Int = (2 * prev1 - prev2) and 0xFF

    override fun compress(input: ByteArray): ByteArray {
        val n = input.size
        val out = ByteArray(n)
        for (i in 0 until n) {
            val current = input[i].toInt() and 0xFF
            val predicted = when (i) {
                0 -> 0
                1 -> input[0].toInt() and 0xFF
                else -> predict(input[i - 1].toInt() and 0xFF, input[i - 2].toInt() and 0xFF)
            }
            out[i] = ((current - predicted) and 0xFF).toByte()
        }
        return out
    }

    override fun decompress(input: ByteArray): ByteArray {
        val n = input.size
        val out = ByteArray(n)
        for (i in 0 until n) {
            val predicted = when (i) {
                0 -> 0
                1 -> out[0].toInt() and 0xFF
                else -> predict(out[i - 1].toInt() and 0xFF, out[i - 2].toInt() and 0xFF)
            }
            val residual = input[i].toInt() and 0xFF
            out[i] = ((residual + predicted) and 0xFF).toByte()
        }
        return out
    }
}
