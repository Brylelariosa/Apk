package com.novacompress.ai.core.service

import java.io.File
import java.util.Properties

/**
 * Enough state to resume an interrupted compression from the last
 * completed chunk, per the spec's "Continue from Last completed chunk.
 * No work should be lost." [sourceKey] is a caller-supplied stable
 * identifier for "is this the same source file" (this class doesn't care
 * how it's derived) - a checkpoint is only ever resumed if it matches
 * both [sourceKey] and the original file name/size exactly.
 */
data class CompressionCheckpoint(
    val sourceKey: String,
    val originalFileName: String,
    val originalSize: Long,
    val genomeId: String,
    val pipelinePluginIds: List<String>,
    val chunkSize: Int,
    val chunkCount: Int,
    val chunksCompleted: Int,
    val tempArchivePath: String,
    val createdAtEpochMillis: Long
)

/**
 * Persists a single [CompressionCheckpoint] as a simple key-value
 * properties file. Deliberately not JSON (Android's org.json throws
 * "not mocked" in plain JVM unit tests without a second test-only
 * implementation) and not SharedPreferences (also Android-framework-
 * stubbed in unit tests) - `java.util.Properties` is plain JVM and behaves
 * identically in tests and production.
 */
object CompressionCheckpointStore {

    fun save(file: File, checkpoint: CompressionCheckpoint) {
        val props = Properties()
        props.setProperty("sourceKey", checkpoint.sourceKey)
        props.setProperty("originalFileName", checkpoint.originalFileName)
        props.setProperty("originalSize", checkpoint.originalSize.toString())
        props.setProperty("genomeId", checkpoint.genomeId)
        props.setProperty("pipelinePluginIds", checkpoint.pipelinePluginIds.joinToString(","))
        props.setProperty("chunkSize", checkpoint.chunkSize.toString())
        props.setProperty("chunkCount", checkpoint.chunkCount.toString())
        props.setProperty("chunksCompleted", checkpoint.chunksCompleted.toString())
        props.setProperty("tempArchivePath", checkpoint.tempArchivePath)
        props.setProperty("createdAtEpochMillis", checkpoint.createdAtEpochMillis.toString())
        file.outputStream().use { props.store(it, "NovaCompress compression checkpoint") }
    }

    fun load(file: File): CompressionCheckpoint? {
        if (!file.exists()) return null
        return try {
            val props = Properties()
            file.inputStream().use { props.load(it) }
            CompressionCheckpoint(
                sourceKey = props.getProperty("sourceKey") ?: return null,
                originalFileName = props.getProperty("originalFileName") ?: return null,
                originalSize = props.getProperty("originalSize")?.toLongOrNull() ?: return null,
                genomeId = props.getProperty("genomeId") ?: return null,
                pipelinePluginIds = props.getProperty("pipelinePluginIds")
                    ?.split(",")?.filter { it.isNotBlank() } ?: return null,
                chunkSize = props.getProperty("chunkSize")?.toIntOrNull() ?: return null,
                chunkCount = props.getProperty("chunkCount")?.toIntOrNull() ?: return null,
                chunksCompleted = props.getProperty("chunksCompleted")?.toIntOrNull() ?: return null,
                tempArchivePath = props.getProperty("tempArchivePath") ?: return null,
                createdAtEpochMillis = props.getProperty("createdAtEpochMillis")?.toLongOrNull() ?: return null
            )
        } catch (e: Exception) {
            null
        }
    }

    fun delete(file: File) {
        file.delete()
    }
}
