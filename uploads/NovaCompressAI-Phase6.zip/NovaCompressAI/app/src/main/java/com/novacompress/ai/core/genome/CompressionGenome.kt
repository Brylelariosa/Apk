package com.novacompress.ai.core.genome

import com.novacompress.ai.core.pipeline.PipelineDescriptor

/**
 * A complete compression strategy.
 *
 * Phase 1 shipped this as a small fixed set of hand-crafted presets
 * (generation 0, "seed" genomes). Phase 2's Evolution Engine now mutates
 * and recombines these to produce new genomes - [generation], [species],
 * [status], and [parentIds] exist specifically to support that; they all
 * default sensibly so Phase 1's preset construction sites don't need to
 * change.
 */
data class CompressionGenome(
    val genomeId: String,
    val displayName: String,
    val pipeline: PipelineDescriptor,
    val rationale: String,
    val generation: Int = 0,
    val species: String = "general",
    val status: GenomeStatus = GenomeStatus.STABLE,
    val parentIds: List<String> = emptyList()
) {
    fun describe(): String = "$displayName (${pipeline.describe()})"
}
