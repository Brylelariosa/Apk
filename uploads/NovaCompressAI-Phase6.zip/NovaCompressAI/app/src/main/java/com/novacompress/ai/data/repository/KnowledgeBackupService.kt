package com.novacompress.ai.data.repository

import com.novacompress.ai.core.backup.BenchmarkBackupRecord
import com.novacompress.ai.core.backup.GenomeBackupRecord
import com.novacompress.ai.core.backup.KnowledgeBackup
import com.novacompress.ai.data.database.BenchmarkRecordDao
import com.novacompress.ai.data.database.BenchmarkRecordEntity
import com.novacompress.ai.data.database.GenomeDao
import com.novacompress.ai.data.database.GenomeEntity

data class ImportSummary(
    val genomesAdded: Int,
    val genomesAlreadyPresent: Int,
    val benchmarksAdded: Int,
    val benchmarksAlreadyPresent: Int
)

/**
 * Export/Import for the Knowledge Database, per the spec's "Users may
 * export Knowledge Database, Genome Library... Import never overwrites
 * without confirmation. Merge intelligently."
 *
 * Merge semantics: genomes are matched by their natural `genomeId` key -
 * an existing genome is never overwritten by an imported one, only
 * genuinely new genomes are added. Benchmark records have no natural key
 * of their own (their `id` is a local auto-increment, meaningless across
 * devices), so a `(genomeId, createdAtEpochMillis)` pair is used as a
 * practical duplicate check instead - two distinct benchmark runs landing
 * on the exact same millisecond timestamp is not a realistic concern.
 */
class KnowledgeBackupService(
    private val genomeDao: GenomeDao,
    private val benchmarkRecordDao: BenchmarkRecordDao
) {
    suspend fun export(): KnowledgeBackup {
        val genomes = genomeDao.getAll().map { it.toBackupRecord() }
        val benchmarks = benchmarkRecordDao.getAll().map { it.toBackupRecord() }
        return KnowledgeBackup(
            exportedAtEpochMillis = System.currentTimeMillis(),
            genomes = genomes,
            benchmarks = benchmarks
        )
    }

    suspend fun import(backup: KnowledgeBackup): ImportSummary {
        var genomesAdded = 0
        var genomesAlreadyPresent = 0
        for (g in backup.genomes) {
            val rowId = genomeDao.insertIfNew(g.toEntity())
            if (rowId == -1L) genomesAlreadyPresent++ else genomesAdded++
        }

        var benchmarksAdded = 0
        var benchmarksAlreadyPresent = 0
        for (b in backup.benchmarks) {
            val alreadyExists = benchmarkRecordDao.existsWithTimestamp(b.genomeId, b.createdAtEpochMillis) > 0
            if (alreadyExists) {
                benchmarksAlreadyPresent++
            } else {
                benchmarkRecordDao.insert(b.toEntity())
                benchmarksAdded++
            }
        }

        return ImportSummary(genomesAdded, genomesAlreadyPresent, benchmarksAdded, benchmarksAlreadyPresent)
    }
}

private fun GenomeEntity.toBackupRecord() = GenomeBackupRecord(
    genomeId = genomeId,
    displayName = displayName,
    pluginIdsCsv = pluginIdsCsv,
    rationale = rationale,
    generation = generation,
    species = species,
    status = status,
    parentIdsCsv = parentIdsCsv,
    bestFitness = bestFitness,
    bestRatio = bestRatio,
    benchmarkCount = benchmarkCount,
    createdAtEpochMillis = createdAtEpochMillis
)

private fun GenomeBackupRecord.toEntity() = GenomeEntity(
    genomeId = genomeId,
    displayName = displayName,
    pluginIdsCsv = pluginIdsCsv,
    rationale = rationale,
    generation = generation,
    species = species,
    status = status,
    parentIdsCsv = parentIdsCsv,
    bestFitness = bestFitness,
    bestRatio = bestRatio,
    benchmarkCount = benchmarkCount,
    createdAtEpochMillis = createdAtEpochMillis
)

private fun BenchmarkRecordEntity.toBackupRecord() = BenchmarkBackupRecord(
    genomeId = genomeId,
    originalSize = originalSize,
    compressedSize = compressedSize,
    compressionTimeNanos = compressionTimeNanos,
    decompressionTimeNanos = decompressionTimeNanos,
    verified = verified,
    fitnessScore = fitnessScore,
    createdAtEpochMillis = createdAtEpochMillis
)

private fun BenchmarkBackupRecord.toEntity() = BenchmarkRecordEntity(
    genomeId = genomeId,
    originalSize = originalSize,
    compressedSize = compressedSize,
    compressionTimeNanos = compressionTimeNanos,
    decompressionTimeNanos = decompressionTimeNanos,
    verified = verified,
    fitnessScore = fitnessScore,
    createdAtEpochMillis = createdAtEpochMillis
)
