package com.novacompress.ai.core.benchmark

import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.pipeline.CompressionPipeline
import com.novacompress.ai.core.verification.VerificationEngine

/**
 * Runs one candidate genome through compression, decompression, and
 * verification against a real byte sample, measuring real wall-clock time
 * for each stage. No candidate's ranking is ever based on an estimate -
 * every number in [BenchmarkResult] came from actually running the
 * pipeline.
 */
object BenchmarkLaboratory {

    fun benchmark(genome: CompressionGenome, sample: ByteArray): BenchmarkResult {
        val pipeline = CompressionPipeline(genome.pipeline)

        val compressed: ByteArray
        val compressionTimeNanos: Long
        try {
            val start = System.nanoTime()
            compressed = pipeline.compress(sample)
            compressionTimeNanos = System.nanoTime() - start
        } catch (e: Exception) {
            return BenchmarkResult(
                genome = genome,
                originalSize = sample.size,
                compressedSize = 0,
                compressionTimeNanos = 0,
                decompressionTimeNanos = 0,
                verified = false,
                failureReason = "Compression threw: ${e.message}"
            )
        }

        val decompressed: ByteArray
        val decompressionTimeNanos: Long
        try {
            val start = System.nanoTime()
            decompressed = pipeline.decompress(compressed)
            decompressionTimeNanos = System.nanoTime() - start
        } catch (e: Exception) {
            return BenchmarkResult(
                genome = genome,
                originalSize = sample.size,
                compressedSize = compressed.size,
                compressionTimeNanos = compressionTimeNanos,
                decompressionTimeNanos = 0,
                verified = false,
                failureReason = "Decompression threw: ${e.message}"
            )
        }

        val verified = decompressed.contentEquals(sample) &&
            VerificationEngine.sha256(decompressed).contentEquals(VerificationEngine.sha256(sample))

        return BenchmarkResult(
            genome = genome,
            originalSize = sample.size,
            compressedSize = compressed.size,
            compressionTimeNanos = compressionTimeNanos,
            decompressionTimeNanos = decompressionTimeNanos,
            verified = verified,
            failureReason = if (!verified) "Decompressed output did not match the original sample." else null
        )
    }
}
