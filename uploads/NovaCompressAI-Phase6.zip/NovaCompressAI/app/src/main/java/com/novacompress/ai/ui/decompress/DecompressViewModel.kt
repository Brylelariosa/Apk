package com.novacompress.ai.ui.decompress

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.core.archive.ArchiveMetadata
import com.novacompress.ai.core.archive.ArchiveReadResult
import com.novacompress.ai.core.archive.NovaArchiveInspector
import com.novacompress.ai.core.plugins.PluginRegistry
import com.novacompress.ai.core.service.ArchiveRepairService
import com.novacompress.ai.core.service.DecompressionOutcome
import com.novacompress.ai.core.service.DecompressionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

enum class DecompressStage { IDLE, FILE_SELECTED, PROCESSING, SUCCESS, ERROR, REPAIRING, REPAIRED }

data class InspectedArchive(
    val metadata: ArchiveMetadata,
    val pipelineDescription: String
)

data class RepairSummary(
    val chunksRecovered: Int,
    val chunksTotal: Int,
    val fullyRecovered: Boolean,
    val restoredPath: String?
)

data class DecompressUiState(
    val stage: DecompressStage = DecompressStage.IDLE,
    val fileName: String? = null,
    val restoredFileName: String? = null,
    val restoredPath: String? = null,
    val errorMessage: String? = null,
    val inspected: InspectedArchive? = null,
    val inspectionFailed: String? = null,
    val chunksDone: Int = 0,
    val chunksTotal: Int = 0,
    val repairResult: RepairSummary? = null
) {
    val progressFraction: Float
        get() = if (chunksTotal == 0) 0f else chunksDone.toFloat() / chunksTotal.toFloat()
}

class DecompressViewModel(
    private val application: Application,
    private val decompressionService: DecompressionService,
    private val archiveRepairService: ArchiveRepairService = ArchiveRepairService()
) : ViewModel() {

    private val _uiState = MutableStateFlow(DecompressUiState())
    val uiState: StateFlow<DecompressUiState> = _uiState.asStateFlow()

    private var pendingUri: Uri? = null

    fun onFileSelected(uri: Uri) {
        pendingUri = uri
        viewModelScope.launch(Dispatchers.IO) {
            val name = queryFileName(uri)
            _uiState.value = DecompressUiState(stage = DecompressStage.FILE_SELECTED, fileName = name)
        }
    }

    /**
     * Reads the archive's metadata (magic, version, pipeline, original
     * size, genome) without decompressing or verifying any chunk - matches
     * the spec's Archive Inspector: "view without extracting."
     */
    fun inspect(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = application.contentResolver.openInputStream(uri)?.use { input ->
                NovaArchiveInspector.peek(input)
            } ?: ArchiveReadResult.Corrupted("Could not open the selected file.")

            when (result) {
                is ArchiveReadResult.Success -> {
                    val pipelineDescription = result.metadata.pipelinePluginIds.joinToString(" \u2192 ") { id ->
                        if (PluginRegistry.exists(id)) PluginRegistry.get(id).displayName else id
                    }
                    _uiState.value = _uiState.value.copy(
                        inspected = InspectedArchive(result.metadata, pipelineDescription),
                        inspectionFailed = null
                    )
                }
                is ArchiveReadResult.Corrupted -> {
                    _uiState.value = _uiState.value.copy(inspected = null, inspectionFailed = result.reason)
                }
            }
        }
    }

    fun decompress(uri: Uri) {
        pendingUri = uri
        val current = _uiState.value
        val fileName = current.fileName ?: return
        _uiState.value = current.copy(stage = DecompressStage.PROCESSING, errorMessage = null)

        viewModelScope.launch(Dispatchers.IO) {
            val restoredDir = File(application.getExternalFilesDir(null), "NovaCompressRestored")
            restoredDir.mkdirs()
            val outputName = fileName.removeSuffix(".nova")
            val tempFile = File(application.cacheDir, "decompressing_${System.currentTimeMillis()}.tmp")

            when (
                val result = decompressionService.decompress(
                    openStream = { application.contentResolver.openInputStream(uri)!! },
                    tempDestination = tempFile,
                    onProgress = { chunksDone, chunksTotal ->
                        _uiState.value = _uiState.value.copy(chunksDone = chunksDone, chunksTotal = chunksTotal)
                    }
                )
            ) {
                is DecompressionOutcome.Success -> {
                    val finalFile = File(restoredDir, outputName)
                    tempFile.copyTo(finalFile, overwrite = true)
                    tempFile.delete()
                    _uiState.value = DecompressUiState(
                        stage = DecompressStage.SUCCESS,
                        fileName = fileName,
                        restoredFileName = result.metadata.originalFileName,
                        restoredPath = finalFile.absolutePath
                    )
                }
                is DecompressionOutcome.Failed -> {
                    _uiState.value = _uiState.value.copy(
                        stage = DecompressStage.ERROR,
                        errorMessage = result.reason
                    )
                }
            }
        }
    }

    /**
     * Best-effort recovery after normal decompression has already failed
     * verification - only ever offered as a fallback, never instead of the
     * fully-verified path. See [com.novacompress.ai.core.archive.NovaArchiveRepairer]
     * for exactly what is and isn't recoverable.
     */
    fun attemptRepair() {
        val uri = pendingUri ?: return
        val current = _uiState.value
        val fileName = current.fileName ?: return
        _uiState.value = current.copy(stage = DecompressStage.REPAIRING)

        viewModelScope.launch(Dispatchers.IO) {
            val restoredDir = File(application.getExternalFilesDir(null), "NovaCompressRepaired")
            restoredDir.mkdirs()
            val outputName = "repaired_" + fileName.removeSuffix(".nova")
            val tempFile = File(application.cacheDir, "repairing_${System.currentTimeMillis()}.tmp")

            val outcome = archiveRepairService.repair(
                openStream = { application.contentResolver.openInputStream(uri)!! },
                tempDestination = tempFile
            )

            var restoredPath: String? = null
            if (outcome.outputFile != null) {
                val finalFile = File(restoredDir, outputName)
                outcome.outputFile.copyTo(finalFile, overwrite = true)
                outcome.outputFile.delete()
                restoredPath = finalFile.absolutePath
            }

            _uiState.value = _uiState.value.copy(
                stage = DecompressStage.REPAIRED,
                repairResult = RepairSummary(
                    chunksRecovered = outcome.report.chunkStatuses.count { it.recovered },
                    chunksTotal = outcome.report.metadata?.chunkCount ?: 0,
                    fullyRecovered = outcome.report.fullyRecovered,
                    restoredPath = restoredPath
                )
            )
        }
    }

    fun reset() {
        pendingUri = null
        _uiState.value = DecompressUiState()
    }

    private fun queryFileName(uri: Uri): String {
        var name = "archive.nova"
        application.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                name = cursor.getString(nameIndex) ?: name
            }
        }
        return name
    }
}
