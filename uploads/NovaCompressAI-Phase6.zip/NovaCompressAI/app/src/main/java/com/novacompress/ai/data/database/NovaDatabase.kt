package com.novacompress.ai.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CompressionRecordEntity::class,
        GenomeEntity::class,
        BenchmarkRecordEntity::class
    ],
    version = 1,
    // Schema export is off for Phase 1/2 (nothing has shipped to real users
    // yet, so there's no migration to test against a recorded snapshot).
    // Turn this on and wire a room.schemaLocation KSP arg once a version 2
    // migration needs to be tested for real.
    exportSchema = false
)
abstract class NovaDatabase : RoomDatabase() {

    abstract fun compressionRecordDao(): CompressionRecordDao
    abstract fun genomeDao(): GenomeDao
    abstract fun benchmarkRecordDao(): BenchmarkRecordDao

    /**
     * Reclaims disk space after [KnowledgeMaintenanceService][com.novacompress.ai.data.repository.KnowledgeMaintenanceService]
     * prunes old rows - SQLite does not shrink its file automatically after
     * DELETE/UPDATE. Best-effort: VACUUM has real requirements (no open
     * transaction, needs free disk headroom roughly equal to the DB size)
     * that can occasionally fail on a constrained device, so callers should
     * treat failure here as non-fatal.
     */
    fun vacuum() {
        openHelper.writableDatabase.execSQL("VACUUM")
    }

    companion object {
        @Volatile
        private var instance: NovaDatabase? = null

        fun getInstance(context: Context): NovaDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    NovaDatabase::class.java,
                    "nova_knowledge.db"
                ).build().also { instance = it }
            }
    }
}
