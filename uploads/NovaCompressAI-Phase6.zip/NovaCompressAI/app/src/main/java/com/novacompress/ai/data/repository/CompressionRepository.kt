package com.novacompress.ai.data.repository

import com.novacompress.ai.data.database.CompressionRecordDao
import com.novacompress.ai.data.database.CompressionRecordEntity
import kotlinx.coroutines.flow.Flow

class CompressionRepository(private val dao: CompressionRecordDao) {

    suspend fun recordCompression(
        originalFileName: String,
        originalSize: Long,
        compressedSize: Long,
        genomeId: String,
        pipelineDescription: String,
        archiveFilePath: String
    ) {
        dao.insert(
            CompressionRecordEntity(
                originalFileName = originalFileName,
                originalSize = originalSize,
                compressedSize = compressedSize,
                genomeId = genomeId,
                pipelineDescription = pipelineDescription,
                archiveFilePath = archiveFilePath,
                createdAtEpochMillis = System.currentTimeMillis()
            )
        )
    }

    fun observeRecent(limit: Int = 10): Flow<List<CompressionRecordEntity>> = dao.observeRecent(limit)

    fun observeAll(): Flow<List<CompressionRecordEntity>> = dao.observeAll()

    fun observeTotalCount(): Flow<Int> = dao.observeTotalCount()

    fun observeTotalBytesSaved(): Flow<Long> = dao.observeTotalBytesSaved()
}
