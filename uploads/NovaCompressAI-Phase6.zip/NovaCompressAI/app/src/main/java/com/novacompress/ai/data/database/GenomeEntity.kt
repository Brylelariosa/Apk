package com.novacompress.ai.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A genome as persisted in the Knowledge Database. Plugin id sequences and
 * parent lineage are stored as comma-separated strings rather than a
 * separate join table - simple, sufficient for the pipeline lengths this
 * app deals with (<=16 stages), and avoids a second table + relation query
 * for what is really just an ordered list of short identifiers.
 */
@Entity(tableName = "genomes")
data class GenomeEntity(
    @PrimaryKey val genomeId: String,
    val displayName: String,
    val pluginIdsCsv: String,
    val rationale: String,
    val generation: Int,
    val species: String,
    val status: String,
    val parentIdsCsv: String,
    val bestFitness: Double,
    val bestRatio: Double,
    val benchmarkCount: Int,
    val createdAtEpochMillis: Long
)
