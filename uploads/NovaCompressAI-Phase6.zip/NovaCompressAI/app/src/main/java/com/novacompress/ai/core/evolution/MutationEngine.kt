package com.novacompress.ai.core.evolution

import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import com.novacompress.ai.core.plugins.PluginRegistry
import kotlin.random.Random

private enum class MutationOp { INSERT, DELETE, SWAP, REPLACE }

/**
 * Produces a small, always-structurally-valid mutation of a pipeline:
 * insert a plugin, delete one, swap two positions, or replace one plugin
 * with another. Every possible outcome satisfies [PipelineDescriptor]'s own
 * validity rules (1..MAX_PIPELINE_STAGES, only known plugin ids), so the
 * caller never needs to catch a validation exception from a mutation.
 */
object MutationEngine {

    fun mutate(pipeline: PipelineDescriptor, random: Random = Random.Default): PipelineDescriptor {
        val ids = pipeline.pluginIds.toMutableList()
        val allPluginIds = PluginRegistry.all().map { it.id }
        val unusedPluginIds = allPluginIds.filter { it !in ids }

        val possibleOps = buildList {
            if (ids.size < Constants.MAX_PIPELINE_STAGES && unusedPluginIds.isNotEmpty()) add(MutationOp.INSERT)
            if (ids.size > 1) add(MutationOp.DELETE)
            if (ids.size >= 2) add(MutationOp.SWAP)
            if (unusedPluginIds.isNotEmpty()) add(MutationOp.REPLACE)
        }

        // If the pipeline already uses every registered plugin and has only one stage,
        // no mutation is possible (nothing to insert/replace with, nothing to delete
        // down to, nothing to swap) - return the pipeline unchanged rather than crash.
        if (possibleOps.isEmpty()) return pipeline

        return when (possibleOps[random.nextInt(possibleOps.size)]) {
            MutationOp.INSERT -> {
                val position = random.nextInt(ids.size + 1)
                ids.add(position, unusedPluginIds[random.nextInt(unusedPluginIds.size)])
                PipelineDescriptor(ids)
            }
            MutationOp.DELETE -> {
                ids.removeAt(random.nextInt(ids.size))
                PipelineDescriptor(ids)
            }
            MutationOp.SWAP -> {
                val i = random.nextInt(ids.size)
                var j = random.nextInt(ids.size)
                while (j == i) j = random.nextInt(ids.size)
                val tmp = ids[i]
                ids[i] = ids[j]
                ids[j] = tmp
                PipelineDescriptor(ids)
            }
            MutationOp.REPLACE -> {
                val position = random.nextInt(ids.size)
                ids[position] = unusedPluginIds[random.nextInt(unusedPluginIds.size)]
                PipelineDescriptor(ids)
            }
        }
    }
}
