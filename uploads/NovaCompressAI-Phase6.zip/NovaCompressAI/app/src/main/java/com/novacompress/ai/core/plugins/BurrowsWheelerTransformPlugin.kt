package com.novacompress.ai.core.plugins

import com.novacompress.ai.core.common.BinaryIO
import java.io.ByteArrayOutputStream

/**
 * Burrows-Wheeler Transform.
 *
 * BWT does not itself reduce size (output is the same length plus a 4-byte
 * primary index) - it groups similar contexts together so a downstream
 * pass (Move-To-Front + RLE + Huffman is the classic combination) can
 * compress much better. This plugin is only useful as part of a larger
 * pipeline; on its own it slightly *expands* data by construction.
 *
 * Construction avoids needing a sentinel byte (impossible here anyway,
 * since all 256 byte values are already valid input) by building a suffix
 * array of the *cyclic* rotations directly: prefix-doubling over rank
 * arrays, comparing (rank[i], rank[(i+k) mod n]) each round and doubling k
 * until every rotation has a distinct rank or k reaches n (at which point
 * any remaining ties are genuine - the data is periodic - and are resolved
 * by the stable sort's preserved relative order, consistently between
 * encode and decode).
 *
 * Stream format: [primaryIndex: 4 bytes BE][transformed bytes, same length as input]
 */
class BurrowsWheelerTransformPlugin : CompressionPlugin {

    override val id: String = "bwt"
    override val displayName: String = "Burrows-Wheeler Transform"
    override val version: Int = 1

    override fun compress(input: ByteArray): ByteArray {
        val n = input.size
        val out = ByteArrayOutputStream(n + 4)

        if (n == 0) {
            BinaryIO.writeU32(out, 0)
            return out.toByteArray()
        }
        if (n == 1) {
            BinaryIO.writeU32(out, 0)
            out.write(input[0].toInt() and 0xFF)
            return out.toByteArray()
        }

        val rotationOrder = buildRotationOrder(input)
        val transformed = ByteArray(n) { k -> input[((rotationOrder[k] - 1 + n) % n)] }
        val primaryIndex = rotationOrder.indexOf(0)

        BinaryIO.writeU32(out, primaryIndex)
        out.write(transformed)
        return out.toByteArray()
    }

    override fun decompress(input: ByteArray): ByteArray {
        val primaryIndex = BinaryIO.readU32(input, 0)
        val transformed = input.copyOfRange(4, input.size)
        return inverseBwt(transformed, primaryIndex)
    }

    /**
     * Builds the permutation of rotation-start-indices (0..n-1) sorted by
     * rotation content, using prefix doubling. Returns `rotationOrder`
     * where `rotationOrder[k]` is the starting index of the k-th
     * rotation in sorted order.
     */
    private fun buildRotationOrder(data: ByteArray): IntArray {
        val n = data.size
        var rank = IntArray(n) { data[it].toInt() and 0xFF }
        var sa: Array<Int> = Array(n) { it }
        var k = 1

        while (true) {
            val currentRank = rank
            val currentK = k
            fun keyFirst(i: Int) = currentRank[i]
            fun keySecond(i: Int) = currentRank[(i + currentK) % n]

            sa.sortWith(compareBy({ keyFirst(it) }, { keySecond(it) }))

            val newRank = IntArray(n)
            newRank[sa[0]] = 0
            for (idx in 1 until n) {
                val prev = sa[idx - 1]
                val curr = sa[idx]
                val same = keyFirst(prev) == keyFirst(curr) && keySecond(prev) == keySecond(curr)
                newRank[curr] = newRank[prev] + if (same) 0 else 1
            }
            rank = newRank

            if (rank[sa[n - 1]] == n - 1) break // fully distinct ranks - sorted order is final
            k *= 2
            if (k >= n) break // any remaining ties are genuine (periodic data); stable sort already resolved them consistently
        }

        return IntArray(n) { sa[it] }
    }

    private fun inverseBwt(transformed: ByteArray, primaryIndex: Int): ByteArray {
        val n = transformed.size
        if (n == 0) return ByteArray(0)
        if (n == 1) return transformed.copyOf()

        val count = IntArray(256)
        val occurrenceRank = IntArray(n)
        for (i in 0 until n) {
            val b = transformed[i].toInt() and 0xFF
            occurrenceRank[i] = count[b]
            count[b] = count[b] + 1
        }

        val cumulative = IntArray(257)
        for (c in 0 until 256) {
            cumulative[c + 1] = cumulative[c] + count[c]
        }

        val lf = IntArray(n) { i ->
            val b = transformed[i].toInt() and 0xFF
            cumulative[b] + occurrenceRank[i]
        }

        val out = ByteArray(n)
        var current = primaryIndex
        for (i in 0 until n) {
            out[i] = transformed[current]
            current = lf[current]
        }
        out.reverse()
        return out
    }
}
