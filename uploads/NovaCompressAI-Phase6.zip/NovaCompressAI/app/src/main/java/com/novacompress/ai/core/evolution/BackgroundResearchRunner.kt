package com.novacompress.ai.core.evolution

data class ResearchPassResult(
    val samplesExplored: Int,
    val totalCandidatesConsidered: Int
)

/**
 * Runs one bounded idle-time research pass: for each synthetic sample,
 * asks [EvolutionEngine] to select a genome, which as a side effect
 * mutates/crosses over the current best genomes and benchmarks the
 * results for real - exactly the same mechanism a live compression job
 * uses, just triggered by a background schedule instead of a user action.
 * Deliberately plain Kotlin (no WorkManager/Android dependency) so it is
 * directly unit-testable; [com.novacompress.ai.work.BackgroundResearchWorker]
 * is the thin Android adapter that decides *when* to call this.
 */
class BackgroundResearchRunner(private val evolutionEngine: EvolutionEngine) {

    suspend fun runResearchPass(
        samples: List<Pair<String, ByteArray>> = SyntheticSampleGenerator.samples()
    ): ResearchPassResult {
        var totalCandidates = 0
        for ((_, sample) in samples) {
            val selection = evolutionEngine.selectGenomeForCompression(sample)
            totalCandidates += selection.candidatesConsidered
        }
        return ResearchPassResult(
            samplesExplored = samples.size,
            totalCandidatesConsidered = totalCandidates
        )
    }
}
