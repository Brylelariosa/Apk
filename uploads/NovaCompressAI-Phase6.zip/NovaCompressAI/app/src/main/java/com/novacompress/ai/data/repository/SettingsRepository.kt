package com.novacompress.ai.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "nova_settings")

/**
 * App-wide settings backed by Jetpack DataStore. Starts with just the one
 * preference Phase 4 needs; more Settings categories from the spec
 * (research budget, thermal/battery limits, plugin permissions) get added
 * here alongside the features that actually read them.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val BACKGROUND_LEARNING_ENABLED = booleanPreferencesKey("background_learning_enabled")
    }

    /** Whether idle-time background research is allowed to run at all. Defaults to on, gated by [com.novacompress.ai.core.scheduler.ResearchScheduler] regardless. */
    val backgroundLearningEnabled: Flow<Boolean> = context.dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs[Keys.BACKGROUND_LEARNING_ENABLED] ?: true }

    suspend fun setBackgroundLearningEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[Keys.BACKGROUND_LEARNING_ENABLED] = enabled }
    }
}
