package com.novacompress.ai.ui.common

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novacompress.ai.di.NovaViewModelFactory

@Composable
inline fun <reified VM : ViewModel> novaViewModel(): VM {
    val application = LocalContext.current.applicationContext as Application
    val factory = remember(application) { NovaViewModelFactory(application) }
    return viewModel(factory = factory)
}
