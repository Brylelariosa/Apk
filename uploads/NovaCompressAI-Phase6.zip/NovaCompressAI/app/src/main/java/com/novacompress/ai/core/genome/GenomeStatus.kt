package com.novacompress.ai.core.genome

/**
 * Lifecycle status of a genome. Only VERIFIED, STABLE, or ELITE genomes may
 * compress user files; EXPERIMENTAL genomes are benchmarked but never
 * chosen as the winner until they've proven themselves at least once.
 */
enum class GenomeStatus {
    EXPERIMENTAL,
    VERIFIED,
    STABLE,
    ELITE,
    RETIRED
}
