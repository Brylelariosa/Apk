package com.novacompress.ai

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.novacompress.ai.ui.navigation.NovaNavHost
import com.novacompress.ai.ui.theme.NovaCompressTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val launchIntent = resolveLaunchIntent(intent)
        setContent {
            NovaCompressTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NovaNavHost(launchIntent = launchIntent)
                }
            }
        }
    }

    /**
     * Resolves how this Activity was launched into a [LaunchIntent], so
     * [NovaNavHost] can route straight to the Compress screen (for a
     * shared file) or Decompress screen (for an opened `.nova` file)
     * instead of always starting at the Dashboard.
     */
    private fun resolveLaunchIntent(intent: Intent?): LaunchIntent {
        if (intent == null) return LaunchIntent.None
        return when (intent.action) {
            Intent.ACTION_SEND -> {
                val uri = extractParcelableExtra(intent, Intent.EXTRA_STREAM)
                uri?.let { LaunchIntent.ShareToCompress(it) } ?: LaunchIntent.None
            }
            Intent.ACTION_VIEW -> {
                intent.data?.let { LaunchIntent.OpenToDecompress(it) } ?: LaunchIntent.None
            }
            else -> LaunchIntent.None
        }
    }

    private fun extractParcelableExtra(intent: Intent, key: String): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(key, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(key)
        }
    }
}
