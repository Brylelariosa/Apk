package com.novacompress.ai.core.scheduler

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

class AndroidBatteryStatusProvider(private val context: Context) : BatteryStatusProvider {
    private val batteryManager: BatteryManager
        get() = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    override fun isCharging(): Boolean {
        val status = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
        return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    override fun batteryPercent(): Int =
        batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}

class AndroidThermalStatusProvider(private val context: Context) : ThermalStatusProvider {
    override fun isThrottled(): Boolean {
        // Thermal status reporting was added in API 29; treat older devices
        // as never throttled rather than guessing from indirect signals.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE
    }
}

class AndroidMemoryStatusProvider(private val context: Context) : MemoryStatusProvider {
    override fun isLowMemory(): Boolean {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(info)
        return info.lowMemory
    }
}
