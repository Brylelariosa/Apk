package com.novacompress.ai.core.genome

import com.novacompress.ai.core.pipeline.PipelineDescriptor

/** Fixed seed population of genomes shipped with Phase 1. */
object GenomePresets {

    val BALANCED = CompressionGenome(
        genomeId = "balanced",
        displayName = "Balanced",
        pipeline = PipelineDescriptor.of("delta", "rle", "huffman"),
        rationale = "General-purpose pipeline: smooths gradual byte changes, collapses short runs, then entropy-codes what remains."
    )

    val MAXIMUM_COMPRESSION = CompressionGenome(
        genomeId = "max_compression",
        displayName = "Maximum Compression",
        pipeline = PipelineDescriptor.of("lz77", "huffman"),
        rationale = "Dictionary matching followed by entropy coding; favors files with repeated blocks or dictionary-like structure (text, markup, structured binaries)."
    )

    val FAST = CompressionGenome(
        genomeId = "fast",
        displayName = "Fast Compression",
        pipeline = PipelineDescriptor.of("rle", "huffman"),
        rationale = "Cheap run detection plus entropy coding; lower CPU cost than dictionary matching, still effective on repetitive data."
    )

    val BATTERY_SAVER = CompressionGenome(
        genomeId = "battery_saver",
        displayName = "Battery Saver",
        pipeline = PipelineDescriptor.of("rle"),
        rationale = "Single lightweight pass; lowest CPU/battery cost, most useful when the device is on low battery or the data is already near-random."
    )

    val BLOCK_SORTING = CompressionGenome(
        genomeId = "block_sorting",
        displayName = "Block Sorting",
        pipeline = PipelineDescriptor.of("bwt", "mtf", "rle", "huffman"),
        rationale = "The classic bzip2-style pipeline: BWT groups similar contexts together, Move-To-Front turns those clusters into runs of small numbers, RLE collapses the runs, and Huffman entropy-codes what's left. Strong on structured text and source code; costs more CPU than the other presets."
    )

    val RESEARCH_MODE = CompressionGenome(
        genomeId = "research_mode",
        displayName = "Research Mode",
        pipeline = PipelineDescriptor.of("bwt", "mtf", "arithmetic"),
        rationale = "Swaps Huffman for arithmetic coding after BWT+MTF, since arithmetic coding isn't restricted to whole-bit code lengths and typically edges out Huffman on skewed distributions - at a higher CPU cost. Meant for exploring the upper bound of what this plugin set can achieve, not everyday use."
    )

    val SIGNAL_OPTIMIZED = CompressionGenome(
        genomeId = "signal_optimized",
        displayName = "Signal Optimized",
        pipeline = PipelineDescriptor.of("predictive", "rle", "huffman"),
        rationale = "Second-order linear prediction turns steady trends (sensor readings, audio envelopes, gradients) into a near-zero residual stream, which RLE and Huffman then compress very effectively. Weaker than Delta-based pipelines on data without a real linear trend."
    )

    val all: List<CompressionGenome> = listOf(BALANCED, MAXIMUM_COMPRESSION, FAST, BATTERY_SAVER, BLOCK_SORTING, RESEARCH_MODE, SIGNAL_OPTIMIZED)

    fun byId(id: String): CompressionGenome =
        all.firstOrNull { it.genomeId == id } ?: BALANCED
}
