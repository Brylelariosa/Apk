package com.novacompress.ai.core.evolution

import com.novacompress.ai.core.benchmark.BenchmarkLaboratory
import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.benchmark.FitnessCalculator
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.genome.GenomePresets
import com.novacompress.ai.core.genome.GenomeStatus
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import java.util.UUID
import kotlin.random.Random

data class EvolutionSelection(
    val genome: CompressionGenome,
    val benchmark: BenchmarkResult,
    val explanation: String,
    val candidatesConsidered: Int
)

/**
 * The Evolution Engine described in Part 3 of the spec, scoped to what a
 * single compression job can afford to benchmark synchronously: rather
 * than maintaining a population of hundreds/thousands and running idle-time
 * research (that's Phase 4's background WorkManager job), Phase 2 pulls the
 * best few known genomes, mutates/recombines them, benchmarks all of it for
 * real against the actual file, and records every result as knowledge -
 * "every benchmark becomes knowledge" - before picking the genuine winner.
 */
class EvolutionEngine(
    private val repository: GenomeRepository,
    private val seeds: List<CompressionGenome> = GenomePresets.all,
    private val random: Random = Random.Default
) {

    suspend fun selectGenomeForCompression(sample: ByteArray): EvolutionSelection {
        repository.ensureSeeded(seeds)

        val known = repository.topGenomesByFitness(limit = 3).ifEmpty { seeds }
        val bestKnown = known.first()

        // Candidates: every known top genome, plus fresh exploration around the best one.
        val candidates = LinkedHashMap<List<String>, CompressionGenome>()
        known.forEach { candidates[it.pipeline.pluginIds] = it }

        val mutated = deriveGenome(
            pipeline = MutationEngine.mutate(bestKnown.pipeline, random),
            parents = listOf(bestKnown)
        )
        candidates[mutated.pipeline.pluginIds] = mutated

        if (known.size >= 2) {
            val secondBest = known[1]
            val child = deriveGenome(
                pipeline = CrossoverEngine.crossover(bestKnown.pipeline, secondBest.pipeline, random),
                parents = listOf(bestKnown, secondBest)
            )
            candidates[child.pipeline.pluginIds] = child
        }

        val results = candidates.values.map { genome -> BenchmarkLaboratory.benchmark(genome, sample) }
        results.forEach { repository.recordBenchmark(it, FitnessCalculator.calculate(it)) }

        val ranked = results.filter { it.verified }.sortedByDescending { FitnessCalculator.calculate(it) }
        // Every shipped plugin always verifies on any input by construction (see Phase 1's
        // round-trip test suite), so `ranked` being empty is not expected in practice; this
        // fallback exists only so a future misbehaving experimental plugin can never crash
        // a compression job instead of just losing the benchmark round.
        val winner = ranked.firstOrNull() ?: results.first()

        return EvolutionSelection(
            genome = winner.genome,
            benchmark = winner,
            explanation = explain(winner, candidates.size),
            candidatesConsidered = candidates.size
        )
    }

    private fun deriveGenome(pipeline: PipelineDescriptor, parents: List<CompressionGenome>): CompressionGenome {
        val parentGeneration = parents.maxOf { it.generation }
        return CompressionGenome(
            genomeId = "gen_${UUID.randomUUID()}",
            displayName = "Evolved (${pipeline.describe()})",
            pipeline = pipeline,
            rationale = "Produced by mutating/recombining ${parents.joinToString { it.genomeId }}.",
            generation = parentGeneration + 1,
            species = classify(pipeline),
            status = GenomeStatus.EXPERIMENTAL,
            parentIds = parents.map { it.genomeId }
        )
    }

    private fun classify(pipeline: PipelineDescriptor): String = when {
        "lz77" in pipeline.pluginIds -> "dictionary"
        "mtf" in pipeline.pluginIds -> "transform"
        "rle" in pipeline.pluginIds -> "repetitive"
        else -> "general"
    }

    private fun explain(winner: BenchmarkResult, candidateCount: Int): String {
        val ratioText = "%.2f\u00d7".format(winner.ratio)
        val compressMs = winner.compressionTimeNanos / 1_000_000.0
        val decompressMs = winner.decompressionTimeNanos / 1_000_000.0
        return "Benchmarked $candidateCount candidate pipeline(s) against this file; " +
            "${winner.genome.describe()} won with a measured $ratioText ratio " +
            "(compress %.1fms, decompress %.1fms).".format(compressMs, decompressMs)
    }
}
