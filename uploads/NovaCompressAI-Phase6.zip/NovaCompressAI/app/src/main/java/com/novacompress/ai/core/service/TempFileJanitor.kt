package com.novacompress.ai.core.service

import java.io.File
import java.util.concurrent.TimeUnit

/**
 * [CompressionService] and [DecompressionService] both delete their temp
 * file on any *catchable* failure, but a hard process death (crash, OS
 * kill, force-stop) mid-operation skips that cleanup entirely, leaving an
 * orphaned `compressing_*.tmp` / `decompressing_*.tmp` file behind forever
 * - a slow but real storage leak. This runs once at app startup and
 * removes anything old enough that it clearly isn't part of an actively
 * running operation.
 *
 * A temp file with a matching `<name>.checkpoint` companion is left alone
 * regardless of age - that combination means [CompressionCheckpointStore]
 * considers it resumable, and deleting it here would silently break the
 * "no work should be lost" resume feature for a file the user just hasn't
 * gotten around to retrying yet.
 */
object TempFileJanitor {

    private val ORPHAN_AGE = 1L to TimeUnit.HOURS
    private val PREFIXES = listOf("compressing_", "decompressing_")

    fun cleanOrphans(cacheDir: File): Int {
        val cutoff = System.currentTimeMillis() - ORPHAN_AGE.second.toMillis(ORPHAN_AGE.first)
        val files = cacheDir.listFiles() ?: return 0

        var removed = 0
        for (file in files) {
            if (!file.isFile) continue
            if (PREFIXES.none { file.name.startsWith(it) }) continue
            if (File(file.parentFile, "${file.name}.checkpoint").exists()) continue
            if (file.lastModified() < cutoff) {
                if (file.delete()) removed++
            }
        }
        return removed
    }
}
