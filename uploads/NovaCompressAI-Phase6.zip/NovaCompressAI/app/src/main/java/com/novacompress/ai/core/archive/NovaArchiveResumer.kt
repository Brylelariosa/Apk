package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.pipeline.CompressionPipeline
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest

/**
 * Resumes writing chunks into an archive that was interrupted partway
 * through (app crash, process kill, reboot) - per the spec's "Continue
 * from Last completed chunk. No work should be lost."
 *
 * Deliberately a separate object from [NovaArchiveWriter] rather than a
 * refactor of its chunk loop into a shared resumable helper: duplicating
 * the loop is a small cost next to the risk of regressing
 * [NovaArchiveWriter.write]'s already-thoroughly-tested behavior, which is
 * the single most safety-critical piece of this app (see
 * [com.novacompress.ai.core.verification.VerificationEngine]).
 */
object NovaArchiveResumer {

    /**
     * @param output must already be open in *append* mode on a file that
     *   contains a valid header + [chunksAlreadyWritten] complete chunks
     *   (and nothing after that - no partial chunk, no footer).
     * @param input must be a fresh stream from the very start of the
     *   original source. This function itself skips past and re-hashes
     *   the bytes belonging to already-written chunks (not re-compressing
     *   them - their compressed bytes are already on disk) to catch the
     *   running whole-file digest up to where it left off, since a
     *   [MessageDigest]'s internal state can't portably survive a process
     *   restart the way the compressed bytes it already produced can.
     */
    fun resume(
        output: OutputStream,
        input: InputStream,
        genome: CompressionGenome,
        chunkSize: Int,
        chunkCount: Int,
        chunksAlreadyWritten: Int,
        onChunkComplete: (chunksDone: Int, chunksTotal: Int) -> Unit = { _, _ -> }
    ) {
        val pipeline = CompressionPipeline(genome.pipeline)
        val wholeDigest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(chunkSize)

        // Re-hash (never re-compress - those bytes are already committed to
        // disk) the already-completed portion to catch the digest up.
        var chunksToSkip = chunksAlreadyWritten
        while (chunksToSkip > 0) {
            var readTotal = 0
            while (readTotal < chunkSize) {
                val r = input.read(buffer, readTotal, chunkSize - readTotal)
                if (r == -1) break
                readTotal += r
            }
            if (readTotal == 0) break
            wholeDigest.update(buffer, 0, readTotal)
            chunksToSkip--
        }

        var chunksWritten = chunksAlreadyWritten
        while (chunksWritten < chunkCount) {
            var readTotal = 0
            while (readTotal < chunkSize) {
                val r = input.read(buffer, readTotal, chunkSize - readTotal)
                if (r == -1) break
                readTotal += r
            }
            if (readTotal == 0) break

            val chunk = if (readTotal == buffer.size) buffer else buffer.copyOf(readTotal)
            wholeDigest.update(chunk)

            val compressed = pipeline.compress(chunk)

            val roundTripOk = try {
                pipeline.decompress(compressed).contentEquals(chunk)
            } catch (e: Exception) {
                throw PipelineVerificationException(
                    "Chunk $chunksWritten failed verification while resuming with pipeline ${genome.pipeline.describe()}: decompression threw ${e.message}"
                )
            }
            if (!roundTripOk) {
                throw PipelineVerificationException(
                    "Chunk $chunksWritten failed verification while resuming with pipeline ${genome.pipeline.describe()}: decompressed output did not match the original."
                )
            }

            val chunkHash = MessageDigest.getInstance("SHA-256").digest(compressed)
            writeU32Direct(output, compressed.size)
            output.write(compressed)
            output.write(chunkHash)

            chunksWritten++
            onChunkComplete(chunksWritten, chunkCount)
        }

        output.write(wholeDigest.digest())
        output.write(NovaArchiveFormat.FOOTER_MAGIC)
        output.flush()
    }

    private fun writeU32Direct(output: OutputStream, value: Int) {
        val buf = ByteArrayOutputStream(4)
        BinaryIO.writeU32(buf, value)
        output.write(buf.toByteArray())
    }
}
