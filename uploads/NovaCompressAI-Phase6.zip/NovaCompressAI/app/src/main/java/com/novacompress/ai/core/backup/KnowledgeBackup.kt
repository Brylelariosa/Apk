package com.novacompress.ai.core.backup

data class GenomeBackupRecord(
    val genomeId: String,
    val displayName: String,
    val pluginIdsCsv: String,
    val rationale: String,
    val generation: Int,
    val species: String,
    val status: String,
    val parentIdsCsv: String,
    val bestFitness: Double,
    val bestRatio: Double,
    val benchmarkCount: Int,
    val createdAtEpochMillis: Long
)

data class BenchmarkBackupRecord(
    val genomeId: String,
    val originalSize: Int,
    val compressedSize: Int,
    val compressionTimeNanos: Long,
    val decompressionTimeNanos: Long,
    val verified: Boolean,
    val fitnessScore: Double,
    val createdAtEpochMillis: Long
)

/** Everything a `.nova-backup` file carries - the genome population plus its benchmark history. */
data class KnowledgeBackup(
    val exportedAtEpochMillis: Long,
    val genomes: List<GenomeBackupRecord>,
    val benchmarks: List<BenchmarkBackupRecord>
)
