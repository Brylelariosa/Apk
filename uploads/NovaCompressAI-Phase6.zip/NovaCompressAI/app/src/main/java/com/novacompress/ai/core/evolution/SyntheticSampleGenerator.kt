package com.novacompress.ai.core.evolution

import kotlin.random.Random

/**
 * Generates a small, fixed set of representative byte samples for
 * background research to benchmark against, matching the spec's "Run
 * synthetic benchmarks" research task. Background research runs between
 * compression jobs, when there's no real user file at hand - synthetic
 * samples covering a few common data "shapes" (random/incompressible,
 * repetitive, text-like, structured/mixed) let the Evolution Engine keep
 * discovering and validating genomes anyway.
 */
object SyntheticSampleGenerator {

    private const val SAMPLE_SIZE = 32 * 1024

    fun samples(seed: Int = 1): List<Pair<String, ByteArray>> {
        val random = Random(seed)
        return listOf(
            "random" to randomSample(random),
            "repetitive" to repetitiveSample(),
            "text_like" to textLikeSample(),
            "structured" to structuredSample(random)
        )
    }

    private fun randomSample(random: Random): ByteArray =
        ByteArray(SAMPLE_SIZE) { random.nextInt(256).toByte() }

    private fun repetitiveSample(): ByteArray {
        val pattern = byteArrayOf(0, 0, 0, 1, 2, 0, 0, 0)
        return ByteArray(SAMPLE_SIZE) { pattern[it % pattern.size] }
    }

    private fun textLikeSample(): ByteArray {
        val phrase = "NovaCompress AI researches, benchmarks, and evolves compression pipelines entirely offline. "
        val bytes = phrase.toByteArray(Charsets.UTF_8)
        return ByteArray(SAMPLE_SIZE) { bytes[it % bytes.size] }
    }

    private fun structuredSample(random: Random): ByteArray {
        // Alternate blocks of low-entropy "header-like" bytes with blocks of
        // higher-entropy "payload-like" bytes, loosely mimicking the mixed
        // structure of a real container format (APK, ROM, archive).
        val out = ByteArray(SAMPLE_SIZE)
        var i = 0
        var headerLike = true
        while (i < out.size) {
            val blockSize = minOf(512, out.size - i)
            if (headerLike) {
                for (k in 0 until blockSize) out[i + k] = (k % 16).toByte()
            } else {
                for (k in 0 until blockSize) out[i + k] = random.nextInt(256).toByte()
            }
            i += blockSize
            headerLike = !headerLike
        }
        return out
    }
}
