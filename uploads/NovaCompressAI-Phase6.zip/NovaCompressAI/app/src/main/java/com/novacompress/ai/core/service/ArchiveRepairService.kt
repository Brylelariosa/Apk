package com.novacompress.ai.core.service

import com.novacompress.ai.core.archive.ArchiveRepairReport
import com.novacompress.ai.core.archive.NovaArchiveRepairer
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

data class RepairOutcome(
    val report: ArchiveRepairReport,
    /** The partially (or fully) recovered file, if anything at all was recovered; null if nothing could be salvaged. */
    val outputFile: File?
)

/** Best-effort recovery for an archive that failed normal verification - see [NovaArchiveRepairer] for what is and isn't actually recoverable. */
class ArchiveRepairService {

    fun repair(openStream: () -> InputStream, tempDestination: File): RepairOutcome {
        return try {
            val report = openStream().use { input ->
                FileOutputStream(tempDestination).use { output ->
                    NovaArchiveRepairer.repair(input, output)
                }
            }
            if (report.recoveredByteCount > 0) {
                RepairOutcome(report, tempDestination)
            } else {
                tempDestination.delete()
                RepairOutcome(report, outputFile = null)
            }
        } catch (e: Exception) {
            tempDestination.delete()
            RepairOutcome(
                report = ArchiveRepairReport(
                    metadata = null,
                    chunkStatuses = emptyList(),
                    recoveredByteCount = 0,
                    structurallyTruncatedAtChunk = 0
                ),
                outputFile = null
            )
        }
    }
}
