package com.novacompress.ai.data.repository

import android.content.Context
import com.novacompress.ai.data.database.BenchmarkRecordDao
import com.novacompress.ai.data.database.GenomeDao
import com.novacompress.ai.data.database.NovaDatabase
import java.util.concurrent.TimeUnit

/**
 * Keeps the Knowledge Database within the spec's explicit limits ("Memory
 * Limits: Knowledge database Maximum 128 MB", "Population: Normal 500
 * genomes... The AI automatically removes weak genomes").
 *
 * This matters because background research ([com.novacompress.ai.work.BackgroundResearchWorker])
 * runs every few hours indefinitely - without bounding, benchmark history
 * and the genome population would both grow forever. This runs as part of
 * every background research pass (an already battery/thermal-gated point)
 * rather than as a separate scheduled job.
 */
class KnowledgeMaintenanceService(
    private val context: Context,
    private val database: NovaDatabase,
    private val genomeDao: GenomeDao,
    private val benchmarkRecordDao: BenchmarkRecordDao
) {
    companion object {
        /** Matches the spec's "Population: Normal 500 genomes". */
        const val MAX_ACTIVE_GENOMES = 500

        /** Benchmark records older than this are pruned regardless of how "good" they were. */
        val BENCHMARK_RETENTION = 30L to TimeUnit.DAYS

        /** Matches the spec's "Knowledge database Maximum 128 MB". */
        const val MAX_KNOWLEDGE_DB_BYTES = 128L * 1024 * 1024
    }

    suspend fun runMaintenance() {
        pruneOldBenchmarkRecords()
        capGenomePopulation()
        vacuumIfOverBudget()
    }

    private suspend fun pruneOldBenchmarkRecords() {
        val retentionMillis = BENCHMARK_RETENTION.second.toMillis(BENCHMARK_RETENTION.first)
        val cutoff = System.currentTimeMillis() - retentionMillis
        benchmarkRecordDao.pruneRecordsOlderThan(cutoff)
    }

    private suspend fun capGenomePopulation() {
        val activeCount = genomeDao.activeGenomeCount()
        if (activeCount <= MAX_ACTIVE_GENOMES) return

        val excess = activeCount - MAX_ACTIVE_GENOMES
        val weakestIds = genomeDao.weakestActiveGenomeIds(excess)
        // Retired rather than deleted, per the spec's "not deleted immediately... move to Archive" -
        // they stay queryable (e.g. for a future Archive view) but are excluded from
        // topGenomesByFitness and so can no longer be selected as a compression winner.
        if (weakestIds.isNotEmpty()) {
            genomeDao.retireGenomesById(weakestIds)
        }
    }

    private fun vacuumIfOverBudget() {
        val dbFile = context.getDatabasePath("nova_knowledge.db")
        if (!dbFile.exists() || dbFile.length() <= MAX_KNOWLEDGE_DB_BYTES) return
        try {
            database.vacuum()
        } catch (e: Exception) {
            // Non-fatal: VACUUM needs headroom roughly equal to the DB size and no
            // open transaction; if it fails, the next maintenance pass tries again.
        }
    }
}
