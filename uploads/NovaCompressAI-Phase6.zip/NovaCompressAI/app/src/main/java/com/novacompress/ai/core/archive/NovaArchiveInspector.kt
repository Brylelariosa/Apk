package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import java.io.EOFException
import java.io.InputStream

/**
 * Reads just enough of a .nova archive to report its metadata - magic,
 * version, and the self-describing metadata block - without decompressing
 * or verifying any chunk. Matches the spec's "Archive Inspector: display
 * metadata, compression ratio, plugin chain... without extraction."
 *
 * This deliberately does NOT verify chunk hashes or the whole-file SHA-256
 * (that's what [NovaArchiveReader.readAndVerify] is for); it exists purely
 * for fast, read-only inspection of a possibly-large archive without
 * touching most of its bytes.
 */
object NovaArchiveInspector {

    fun peek(input: InputStream): ArchiveReadResult {
        return try {
            val magic = readFully(input, 4)
            if (!magic.contentEquals(NovaArchiveFormat.MAGIC)) {
                return ArchiveReadResult.Corrupted("Not a NovaCompress archive (bad magic header).")
            }

            val version = input.read()
            if (version != com.novacompress.ai.core.common.Constants.ARCHIVE_FORMAT_VERSION) {
                return ArchiveReadResult.Corrupted("Unsupported archive format version: $version")
            }

            val metaLen = BinaryIO.readU32(readFully(input, 4), 0)
            if (metaLen < 0 || metaLen > 10 * 1024 * 1024) {
                // Metadata blocks are a handful of short strings/ints; anything
                // implausibly large indicates a corrupted or malicious length field.
                return ArchiveReadResult.Corrupted("Implausible metadata length: $metaLen")
            }
            val metaBytes = readFully(input, metaLen)
            val metadata = ArchiveMetadataCodec.decode(metaBytes)

            val chunkCountFromHeader = BinaryIO.readU32(readFully(input, 4), 0)
            if (chunkCountFromHeader != metadata.chunkCount) {
                return ArchiveReadResult.Corrupted("Chunk count mismatch between header and metadata.")
            }

            ArchiveReadResult.Success(metadata)
        } catch (e: EOFException) {
            ArchiveReadResult.Corrupted("Archive is truncated: ${e.message}")
        } catch (e: Exception) {
            ArchiveReadResult.Corrupted("Unexpected error while inspecting archive: ${e.message}")
        }
    }

    private fun readFully(input: InputStream, length: Int): ByteArray {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val r = input.read(buffer, offset, length - offset)
            if (r == -1) throw EOFException("expected $length bytes, got $offset")
            offset += r
        }
        return buffer
    }
}
