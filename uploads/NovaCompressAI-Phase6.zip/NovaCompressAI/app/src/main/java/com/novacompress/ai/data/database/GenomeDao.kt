package com.novacompress.ai.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface GenomeDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfNew(genome: GenomeEntity): Long

    @Query("SELECT COUNT(*) FROM genomes")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM genomes")
    fun observeCount(): Flow<Int>

    @Query("SELECT * FROM genomes WHERE status != 'RETIRED' ORDER BY bestFitness DESC LIMIT :limit")
    suspend fun topByFitness(limit: Int): List<GenomeEntity>

    @Query("SELECT * FROM genomes ORDER BY bestFitness DESC")
    fun observeAll(): Flow<List<GenomeEntity>>

    @Query("SELECT * FROM genomes")
    suspend fun getAll(): List<GenomeEntity>

    @Query("UPDATE genomes SET bestFitness = :fitness, bestRatio = :ratio WHERE genomeId = :genomeId AND :fitness > bestFitness")
    suspend fun updateFitnessIfBetter(genomeId: String, fitness: Double, ratio: Double)

    @Query("UPDATE genomes SET benchmarkCount = benchmarkCount + 1 WHERE genomeId = :genomeId")
    suspend fun incrementBenchmarkCount(genomeId: String)

    @Query("SELECT COUNT(*) FROM genomes WHERE status != 'RETIRED'")
    suspend fun activeGenomeCount(): Int

    @Query("SELECT genomeId FROM genomes WHERE status != 'RETIRED' ORDER BY bestFitness ASC LIMIT :count")
    suspend fun weakestActiveGenomeIds(count: Int): List<String>

    @Query("UPDATE genomes SET status = 'RETIRED' WHERE genomeId IN (:genomeIds)")
    suspend fun retireGenomesById(genomeIds: List<String>)

    @Query("UPDATE genomes SET status = :status WHERE genomeId = :genomeId")
    suspend fun updateStatus(genomeId: String, status: String)
}
