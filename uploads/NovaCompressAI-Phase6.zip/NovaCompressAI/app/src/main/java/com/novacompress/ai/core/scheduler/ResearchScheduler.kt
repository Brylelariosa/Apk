package com.novacompress.ai.core.scheduler

sealed class ResearchGate {
    object Allowed : ResearchGate()
    data class Blocked(val reason: String) : ResearchGate()
}

/**
 * Decides whether idle-time background research is currently allowed to
 * run, per the spec's Background Research rules: only while charging,
 * battery above a threshold, and the device isn't thermally throttled or
 * low on memory. Pure Kotlin against the [BatteryStatusProvider] /
 * [ThermalStatusProvider] / [MemoryStatusProvider] interfaces, so this is
 * fully unit-testable without touching Android's BatteryManager/
 * PowerManager/ActivityManager APIs.
 */
class ResearchScheduler(
    private val battery: BatteryStatusProvider,
    private val thermal: ThermalStatusProvider,
    private val memory: MemoryStatusProvider,
    private val minBatteryPercent: Int = 50
) {
    fun shouldRunResearch(): ResearchGate {
        if (!battery.isCharging()) {
            return ResearchGate.Blocked("Device is not charging")
        }
        if (battery.batteryPercent() < minBatteryPercent) {
            return ResearchGate.Blocked("Battery is below $minBatteryPercent%")
        }
        if (thermal.isThrottled()) {
            return ResearchGate.Blocked("Device is running hot")
        }
        if (memory.isLowMemory()) {
            return ResearchGate.Blocked("Device is low on memory")
        }
        return ResearchGate.Allowed
    }
}
