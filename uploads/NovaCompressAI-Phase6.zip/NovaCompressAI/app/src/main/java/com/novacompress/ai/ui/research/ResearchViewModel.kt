package com.novacompress.ai.ui.research

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.data.repository.EvolutionStatsRepository
import com.novacompress.ai.data.repository.GenomeSummary
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class SpeciesSummary(
    val species: String,
    val genomeCount: Int,
    val averageFitness: Double,
    val bestFitness: Double
)

data class ResearchUiState(
    val genomes: List<GenomeSummary> = emptyList(),
    val species: List<SpeciesSummary> = emptyList(),
    val totalGenomes: Int = 0,
    val totalBenchmarks: Int = 0
)

class ResearchViewModel(evolutionStatsRepository: EvolutionStatsRepository) : ViewModel() {

    val uiState: StateFlow<ResearchUiState> = combine(
        evolutionStatsRepository.observeGenomeSummaries(),
        evolutionStatsRepository.observeBenchmarkCount()
    ) { genomes, benchmarkCount ->
        val sortedGenomes = genomes.sortedByDescending { it.bestFitness }
        val species = sortedGenomes.groupBy { it.species }
            .map { (species, members) ->
                SpeciesSummary(
                    species = species,
                    genomeCount = members.size,
                    averageFitness = members.map { it.bestFitness }.average(),
                    bestFitness = members.maxOf { it.bestFitness }
                )
            }
            .sortedByDescending { it.bestFitness }

        ResearchUiState(
            genomes = sortedGenomes,
            species = species,
            totalGenomes = genomes.size,
            totalBenchmarks = benchmarkCount
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ResearchUiState()
    )
}
