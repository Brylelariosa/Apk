package com.novacompress.ai.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.core.backup.KnowledgeBackupCodec
import com.novacompress.ai.data.repository.KnowledgeBackupService
import com.novacompress.ai.data.repository.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.InputStream
import java.io.OutputStream

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val knowledgeBackupService: KnowledgeBackupService
) : ViewModel() {

    val backgroundLearningEnabled: StateFlow<Boolean> = settingsRepository.backgroundLearningEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initialValue = true)

    private val _backupMessage = MutableStateFlow<String?>(null)
    val backupMessage: StateFlow<String?> = _backupMessage.asStateFlow()

    fun setBackgroundLearningEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setBackgroundLearningEnabled(enabled)
        }
    }

    /** Exports the full genome population + benchmark history to a `.nova-backup` file at [openOutputStream]. */
    fun exportKnowledge(openOutputStream: () -> OutputStream?) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stream = openOutputStream() ?: run {
                    _backupMessage.value = "Could not open the destination file."
                    return@launch
                }
                val backup = knowledgeBackupService.export()
                val bytes = KnowledgeBackupCodec.encode(backup)
                stream.use { it.write(bytes) }
                _backupMessage.value = "Exported ${backup.genomes.size} genome(s) and ${backup.benchmarks.size} benchmark record(s)."
            } catch (e: Exception) {
                _backupMessage.value = "Export failed: ${e.message}"
            }
        }
    }

    /** Imports a `.nova-backup` file, merging into the existing population without overwriting anything. */
    fun importKnowledge(openInputStream: () -> InputStream?) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val stream = openInputStream() ?: run {
                    _backupMessage.value = "Could not open the selected file."
                    return@launch
                }
                val bytes = stream.use { it.readBytes() }
                val backup = KnowledgeBackupCodec.decode(bytes)
                val summary = knowledgeBackupService.import(backup)
                _backupMessage.value = "Imported ${summary.genomesAdded} new genome(s) " +
                    "(${summary.genomesAlreadyPresent} already present), " +
                    "${summary.benchmarksAdded} new benchmark record(s) " +
                    "(${summary.benchmarksAlreadyPresent} already present)."
            } catch (e: Exception) {
                _backupMessage.value = "Import failed: ${e.message}"
            }
        }
    }

    fun clearBackupMessage() {
        _backupMessage.value = null
    }
}
