package com.novacompress.ai.core.common

/**
 * Sequential reader over a byte array. Keeps archive/metadata decoding code
 * free of manual offset bookkeeping.
 */
class ByteCursor(private val data: ByteArray, startOffset: Int = 0) {

    var position: Int = startOffset
        private set

    fun readByte(): Int {
        val v = data[position].toInt() and 0xFF
        position += 1
        return v
    }

    fun readBoolean(): Boolean = readByte() != 0

    fun readU16(): Int {
        val v = BinaryIO.readU16(data, position)
        position += 2
        return v
    }

    fun readU32(): Int {
        val v = BinaryIO.readU32(data, position)
        position += 4
        return v
    }

    fun readLong(): Long {
        val v = BinaryIO.readLong(data, position)
        position += 8
        return v
    }

    fun readDouble(): Double {
        val v = BinaryIO.readDouble(data, position)
        position += 8
        return v
    }

    fun readBytes(length: Int): ByteArray {
        val out = data.copyOfRange(position, position + length)
        position += length
        return out
    }

    fun readString(): String {
        val length = readU32()
        return String(readBytes(length), Charsets.UTF_8)
    }

    fun readStringList(): List<String> {
        val count = readU32()
        return List(count) { readString() }
    }
}
