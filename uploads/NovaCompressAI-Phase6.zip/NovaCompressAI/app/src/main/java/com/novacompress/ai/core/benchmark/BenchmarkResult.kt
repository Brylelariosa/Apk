package com.novacompress.ai.core.benchmark

import com.novacompress.ai.core.genome.CompressionGenome

/**
 * The measured outcome of benchmarking one genome against one data sample.
 * Every field here is an actual measurement (wall-clock nanoseconds, real
 * byte counts, a real round-trip check) - never an estimate.
 */
data class BenchmarkResult(
    val genome: CompressionGenome,
    val originalSize: Int,
    val compressedSize: Int,
    val compressionTimeNanos: Long,
    val decompressionTimeNanos: Long,
    val verified: Boolean,
    val failureReason: String? = null
) {
    val ratio: Double
        get() = if (compressedSize <= 0) 0.0 else originalSize.toDouble() / compressedSize.toDouble()
}
