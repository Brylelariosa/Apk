package com.novacompress.ai.data.repository

import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.genome.GenomeStatus
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import com.novacompress.ai.core.plugins.PluginRegistry
import com.novacompress.ai.data.database.GenomeEntity

fun CompressionGenome.toEntity(bestFitness: Double, bestRatio: Double, createdAtEpochMillis: Long = System.currentTimeMillis()): GenomeEntity =
    GenomeEntity(
        genomeId = genomeId,
        displayName = displayName,
        pluginIdsCsv = pipeline.pluginIds.joinToString(","),
        rationale = rationale,
        generation = generation,
        species = species,
        status = status.name,
        parentIdsCsv = parentIds.joinToString(","),
        bestFitness = bestFitness,
        bestRatio = bestRatio,
        benchmarkCount = 0,
        createdAtEpochMillis = createdAtEpochMillis
    )

fun GenomeEntity.toDomain(): CompressionGenome = CompressionGenome(
    genomeId = genomeId,
    displayName = displayName,
    pipeline = PipelineDescriptor(pluginIdsCsv.split(",").filter { it.isNotBlank() }),
    rationale = rationale,
    generation = generation,
    species = species,
    status = GenomeStatus.valueOf(status),
    parentIds = if (parentIdsCsv.isBlank()) emptyList() else parentIdsCsv.split(",")
)

/**
 * A genome plus its persisted performance stats, for the Research /
 * Genome Explorer UI. Deliberately separate from [CompressionGenome]:
 * bestFitness/bestRatio/benchmarkCount describe how a genome has
 * *performed*, not what it fundamentally *is*, and the evolutionary logic
 * in `core.evolution` has no need for them.
 */
data class GenomeSummary(
    val genomeId: String,
    val displayName: String,
    val pipelineDescription: String,
    val rationale: String,
    val generation: Int,
    val species: String,
    val status: GenomeStatus,
    val bestFitness: Double,
    val bestRatio: Double,
    val benchmarkCount: Int,
    val parentIds: List<String>
)

fun GenomeEntity.toSummary(): GenomeSummary {
    val pluginIds = pluginIdsCsv.split(",").filter { it.isNotBlank() }
    val pipelineDescription = pluginIds.joinToString(" \u2192 ") { id ->
        if (PluginRegistry.exists(id)) PluginRegistry.get(id).displayName else id
    }
    return GenomeSummary(
        genomeId = genomeId,
        displayName = displayName,
        pipelineDescription = pipelineDescription,
        rationale = rationale,
        generation = generation,
        species = species,
        status = GenomeStatus.valueOf(status),
        bestFitness = bestFitness,
        bestRatio = bestRatio,
        benchmarkCount = benchmarkCount,
        parentIds = if (parentIdsCsv.isBlank()) emptyList() else parentIdsCsv.split(",")
    )
}
