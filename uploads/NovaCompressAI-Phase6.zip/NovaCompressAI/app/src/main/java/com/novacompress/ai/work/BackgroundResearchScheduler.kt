package com.novacompress.ai.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Enqueues or cancels [BackgroundResearchWorker] as a periodic job.
 * `setRequiresCharging`/`setRequiresBatteryNotLow` are WorkManager's own
 * constraints - the OS won't even start the worker unless they hold, which
 * is a stronger and more battery-friendly guarantee than checking from
 * inside `doWork()` alone. [com.novacompress.ai.core.scheduler.ResearchScheduler]
 * is still checked inside the worker for the signals WorkManager has no
 * built-in constraint for (thermal state, memory pressure).
 */
object BackgroundResearchScheduler {

    private const val UNIQUE_WORK_NAME = "nova_background_research"
    private val REPEAT_INTERVAL = 6L to TimeUnit.HOURS

    fun enable(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiresCharging(true)
            .setRequiresBatteryNotLow(true)
            .build()

        val request = PeriodicWorkRequestBuilder<BackgroundResearchWorker>(REPEAT_INTERVAL.first, REPEAT_INTERVAL.second)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun disable(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_WORK_NAME)
    }
}
