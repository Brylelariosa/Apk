package com.novacompress.ai.core.service

import com.novacompress.ai.core.analyzer.FeatureVector
import com.novacompress.ai.core.analyzer.FileAnalyzer
import com.novacompress.ai.core.archive.ArchiveMetadata
import com.novacompress.ai.core.archive.NovaArchiveResumer
import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.genome.GenomeSelector
import com.novacompress.ai.core.genome.HeuristicGenomeSelector
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.RandomAccessFile

/** The genome ultimately used, with a human-readable explanation for the UI - shape is the same whether it came from the Evolution Engine or the low-power fallback heuristic. */
data class ChosenGenome(
    val genome: CompressionGenome,
    val confidencePercent: Int,
    val explanation: String
)

data class CompressionOutcome(
    val metadata: ArchiveMetadata,
    val chosenGenome: ChosenGenome,
    val features: FeatureVector,
    /** Present when the Evolution Engine (rather than the low-power fallback heuristic) chose the genome. */
    val benchmark: BenchmarkResult? = null,
    /** True if this outcome came from resuming an interrupted previous attempt rather than starting fresh. */
    val resumed: Boolean = false
)

/**
 * Orchestrates a full compress job: analyze a sample, choose a genome
 * (via the real [EvolutionEngine] by default, or a fast heuristic when
 * [preferLowPower] is set or no engine is supplied), stream-compress to a
 * temp file with per-chunk verification, and only then hand back a
 * finished archive. Plain Kotlin (no Android framework dependency), so
 * it is directly exercised from JVM unit tests; the UI layer supplies
 * stream factories bound to a real content Uri/File.
 *
 * When [resumeKey] is supplied, a checkpoint is saved after every chunk
 * (see [CompressionCheckpointStore]); if a matching checkpoint from a
 * previous, interrupted attempt is found on the next call with the same
 * key, this resumes from the last completed chunk via [NovaArchiveResumer]
 * instead of starting over, per the spec's "Continue from Last completed
 * chunk. No work should be lost."
 */
class CompressionService(
    private val analyzer: FileAnalyzer = FileAnalyzer(),
    private val evolutionEngine: EvolutionEngine? = null,
    private val fallbackSelector: GenomeSelector = HeuristicGenomeSelector()
) {
    companion object {
        const val ANALYSIS_SAMPLE_BYTES = 1 * 1024 * 1024
    }

    /**
     * @param openStream must support being invoked twice (three times when
     *   resuming): once to read an analysis sample, and once more for each
     *   full pass over the source from the very start.
     * @param tempDestination where the archive is written. Only considered
     *   final once this function returns successfully; on any failure
     *   (including a chunk failing verification) the temp file - and any
     *   checkpoint referencing it - is deleted and the exception is
     *   rethrown for the caller to surface to the UI.
     * @param preferLowPower skips the Evolution Engine's multi-candidate
     *   benchmarking (real but relatively CPU-hungry) in favor of the
     *   Phase 1 heuristic's instant, feature-based guess. Also disables
     *   checkpointing for this call, since low-power jobs are expected to
     *   be quick.
     * @param resumeKey a caller-supplied stable identifier for "this is the
     *   same source file" (e.g. derived from a content Uri + file size).
     *   Pass the same key across attempts at the same file to enable
     *   resuming an interrupted attempt; pass null (the default) to
     *   disable checkpointing entirely for this call.
     */
    suspend fun compress(
        openStream: () -> InputStream,
        originalFileName: String,
        originalSize: Long,
        tempDestination: File,
        preferLowPower: Boolean = false,
        resumeKey: String? = null,
        onProgress: (chunksDone: Int, chunksTotal: Int) -> Unit = { _, _ -> }
    ): CompressionOutcome {
        val checkpointFile = File(tempDestination.parentFile, "${tempDestination.name}.checkpoint")
        val effectiveResumeKey = resumeKey.takeUnless { preferLowPower }

        val sample = openStream().use { readUpTo(it, ANALYSIS_SAMPLE_BYTES) }
        val features = analyzer.analyze(sample)

        val checkpoint = effectiveResumeKey?.let { key ->
            CompressionCheckpointStore.load(checkpointFile)?.takeIf { cp ->
                cp.sourceKey == key &&
                    cp.originalFileName == originalFileName &&
                    cp.originalSize == originalSize &&
                    File(cp.tempArchivePath).exists()
            }
        }

        if (checkpoint != null) {
            return resumeFromCheckpoint(checkpoint, checkpointFile, openStream, features, onProgress)
        }

        var benchmark: BenchmarkResult? = null
        val chosen: ChosenGenome = if (!preferLowPower && evolutionEngine != null) {
            val evolutionResult = evolutionEngine.selectGenomeForCompression(sample)
            benchmark = evolutionResult.benchmark
            ChosenGenome(
                genome = evolutionResult.genome,
                // The Evolution Engine's pick is based on real, measured benchmarks
                // rather than a heuristic guess, so it's shown with high confidence.
                confidencePercent = 95,
                explanation = evolutionResult.explanation
            )
        } else {
            val heuristic = fallbackSelector.select(features, preferLowPower)
            ChosenGenome(
                genome = heuristic.genome,
                confidencePercent = heuristic.confidencePercent,
                explanation = heuristic.explanation
            )
        }

        try {
            openStream().use { input ->
                FileOutputStream(tempDestination).use { output ->
                    val metadata = NovaArchiveWriter.write(
                        output = output,
                        input = input,
                        originalFileName = originalFileName,
                        originalSize = originalSize,
                        genome = chosen.genome,
                        onChunkComplete = { done, total ->
                            onProgress(done, total)
                            if (effectiveResumeKey != null) {
                                CompressionCheckpointStore.save(
                                    checkpointFile,
                                    CompressionCheckpoint(
                                        sourceKey = effectiveResumeKey,
                                        originalFileName = originalFileName,
                                        originalSize = originalSize,
                                        genomeId = chosen.genome.genomeId,
                                        pipelinePluginIds = chosen.genome.pipeline.pluginIds,
                                        chunkSize = Constants.DEFAULT_CHUNK_SIZE,
                                        chunkCount = total,
                                        chunksCompleted = done,
                                        tempArchivePath = tempDestination.absolutePath,
                                        createdAtEpochMillis = System.currentTimeMillis()
                                    )
                                )
                            }
                        }
                    )
                    if (effectiveResumeKey != null) checkpointFile.delete() // completed normally; no longer needed
                    return CompressionOutcome(metadata, chosen, features, benchmark, resumed = false)
                }
            }
        } catch (e: Exception) {
            tempDestination.delete()
            checkpointFile.delete()
            throw e
        }
    }

    private fun resumeFromCheckpoint(
        checkpoint: CompressionCheckpoint,
        checkpointFile: File,
        openStream: () -> InputStream,
        features: FeatureVector,
        onProgress: (chunksDone: Int, chunksTotal: Int) -> Unit
    ): CompressionOutcome {
        val resumeGenome = CompressionGenome(
            genomeId = checkpoint.genomeId,
            displayName = "Resumed",
            pipeline = PipelineDescriptor(checkpoint.pipelinePluginIds),
            rationale = "Resumed from an interrupted compression at chunk ${checkpoint.chunksCompleted}/${checkpoint.chunkCount}."
        )
        val tempFile = File(checkpoint.tempArchivePath)

        try {
            val raf = RandomAccessFile(tempFile, "rw")
            try {
                raf.seek(tempFile.length())
                val appendStream = FileOutputStream(raf.fd)
                openStream().use { input ->
                    NovaArchiveResumer.resume(
                        output = appendStream,
                        input = input,
                        genome = resumeGenome,
                        chunkSize = checkpoint.chunkSize,
                        chunkCount = checkpoint.chunkCount,
                        chunksAlreadyWritten = checkpoint.chunksCompleted,
                        onChunkComplete = { done, total ->
                            onProgress(done, total)
                            CompressionCheckpointStore.save(checkpointFile, checkpoint.copy(chunksCompleted = done))
                        }
                    )
                }
            } finally {
                raf.close()
            }
        } catch (e: Exception) {
            tempFile.delete()
            checkpointFile.delete()
            throw e
        }

        checkpointFile.delete()

        val metadata = ArchiveMetadata(
            originalFileName = checkpoint.originalFileName,
            originalSize = checkpoint.originalSize,
            chunkSize = checkpoint.chunkSize,
            chunkCount = checkpoint.chunkCount,
            createdAtEpochMillis = checkpoint.createdAtEpochMillis,
            genomeId = checkpoint.genomeId,
            pipelinePluginIds = checkpoint.pipelinePluginIds
        )
        val chosen = ChosenGenome(
            genome = resumeGenome,
            confidencePercent = 100,
            explanation = "Resumed an interrupted compression from chunk ${checkpoint.chunksCompleted} of ${checkpoint.chunkCount}."
        )
        return CompressionOutcome(metadata, chosen, features, benchmark = null, resumed = true)
    }

    private fun readUpTo(input: InputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArray(maxBytes)
        var total = 0
        while (total < maxBytes) {
            val r = input.read(buffer, total, maxBytes - total)
            if (r == -1) break
            total += r
        }
        return if (total == buffer.size) buffer else buffer.copyOf(total)
    }
}
