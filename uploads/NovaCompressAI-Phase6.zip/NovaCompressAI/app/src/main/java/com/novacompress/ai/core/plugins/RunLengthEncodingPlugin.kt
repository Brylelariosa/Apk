package com.novacompress.ai.core.plugins

/**
 * Run-Length Encoding, PackBits-style.
 *
 * Control byte c (read as unsigned 0..255):
 *   - 0..127   -> literal run: copy the next (c+1) bytes verbatim.
 *   - 129..255 -> run: repeat the single following byte (257-c) times.
 *   - 128      -> no-op (reserved; never emitted by this encoder, but a
 *                 correct decoder must still accept it without crashing).
 *
 * A run is only emitted when it is at least [MIN_RUN] bytes long, since
 * shorter runs cost more as a run token (2 bytes) than as literals.
 */
class RunLengthEncodingPlugin : CompressionPlugin {

    override val id: String = "rle"
    override val displayName: String = "Run-Length Encoding"
    override val version: Int = 1

    private companion object {
        const val MIN_RUN = 3
        const val MAX_LITERAL = 128
        const val MAX_RUN = 128
    }

    override fun compress(input: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream(input.size)
        val literalBuf = java.io.ByteArrayOutputStream()

        fun flushLiteral() {
            val bytes = literalBuf.toByteArray()
            var pos = 0
            while (pos < bytes.size) {
                val chunkLen = minOf(MAX_LITERAL, bytes.size - pos)
                out.write(chunkLen - 1)
                out.write(bytes, pos, chunkLen)
                pos += chunkLen
            }
            literalBuf.reset()
        }

        var i = 0
        val n = input.size
        while (i < n) {
            var j = i + 1
            val currentByte = input[i]
            while (j < n && input[j] == currentByte && (j - i) < MAX_RUN) {
                j++
            }
            val runLen = j - i
            if (runLen >= MIN_RUN) {
                flushLiteral()
                out.write(257 - runLen) // in [129,255] since runLen in [3, MAX_RUN]
                out.write(currentByte.toInt() and 0xFF)
                i = j
            } else {
                literalBuf.write(currentByte.toInt() and 0xFF)
                i++
            }
        }
        flushLiteral()
        return out.toByteArray()
    }

    override fun decompress(input: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream(input.size)
        var i = 0
        val n = input.size
        while (i < n) {
            val c = input[i].toInt() and 0xFF
            i++
            when {
                c <= 127 -> {
                    val length = c + 1
                    out.write(input, i, length)
                    i += length
                }
                c == 128 -> {
                    // no-op, no data follows
                }
                else -> {
                    val runLen = 257 - c
                    val value = input[i].toInt() and 0xFF
                    i++
                    repeat(runLen) { out.write(value) }
                }
            }
        }
        return out.toByteArray()
    }
}
