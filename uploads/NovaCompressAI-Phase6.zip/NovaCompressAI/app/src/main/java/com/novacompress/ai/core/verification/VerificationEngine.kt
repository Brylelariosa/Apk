package com.novacompress.ai.core.verification

import com.novacompress.ai.core.pipeline.CompressionPipeline
import java.security.MessageDigest

data class VerificationResult(
    val passed: Boolean,
    val reason: String? = null
)

/**
 * Enforces the project's Fundamental Rule: a pipeline's output is never
 * trusted until it has been compressed, decompressed, and compared
 * byte-for-byte (and by SHA-256) against the original. Used both inline
 * during archive writing (per chunk) and, in a later phase, by the
 * Benchmark Laboratory when ranking candidate genomes.
 */
object VerificationEngine {

    fun verifyRoundTrip(original: ByteArray, pipeline: CompressionPipeline): VerificationResult {
        val compressed = try {
            pipeline.compress(original)
        } catch (e: Exception) {
            return VerificationResult(false, "Compression threw an exception: ${e.message}")
        }

        val decompressed = try {
            pipeline.decompress(compressed)
        } catch (e: Exception) {
            return VerificationResult(false, "Decompression threw an exception: ${e.message}")
        }

        if (!decompressed.contentEquals(original)) {
            return VerificationResult(false, "Decompressed output does not match the original byte-for-byte.")
        }

        val originalHash = sha256(original)
        val decompressedHash = sha256(decompressed)
        if (!originalHash.contentEquals(decompressedHash)) {
            // Unreachable if contentEquals above passed, but kept as an explicit,
            // independent check per the project's "SHA-256 verification" step -
            // defense in depth against a future bug in the byte comparison path.
            return VerificationResult(false, "SHA-256 mismatch after round trip.")
        }

        return VerificationResult(true)
    }

    fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)
}
