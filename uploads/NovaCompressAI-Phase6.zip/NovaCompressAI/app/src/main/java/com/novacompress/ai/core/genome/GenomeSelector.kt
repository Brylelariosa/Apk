package com.novacompress.ai.core.genome

import com.novacompress.ai.core.analyzer.FeatureVector
import kotlin.math.roundToInt

/** The chosen genome for a compression job, plus a human-readable explanation for the UI. */
data class GenomeSelection(
    val genome: CompressionGenome,
    val confidencePercent: Int,
    val explanation: String
)

/**
 * Chooses a genome for a given file's [FeatureVector].
 *
 * This is intentionally a small interface: Phase 1 implements it with a
 * hand-written heuristic ([HeuristicGenomeSelector]); a later phase can
 * introduce an evolutionary/learned selector that implements the same
 * interface without any change to callers (CompressViewModel only ever
 * depends on [GenomeSelector], never on the concrete heuristic).
 */
interface GenomeSelector {
    fun select(features: FeatureVector, preferLowPower: Boolean = false): GenomeSelection
}

class HeuristicGenomeSelector : GenomeSelector {

    override fun select(features: FeatureVector, preferLowPower: Boolean): GenomeSelection {
        if (preferLowPower) {
            return GenomeSelection(
                genome = GenomePresets.BATTERY_SAVER,
                confidencePercent = 70,
                explanation = "Low-power mode is on, so the lightest available pipeline was chosen."
            )
        }

        if (features.looksAlreadyRandom) {
            return GenomeSelection(
                genome = GenomePresets.FAST,
                confidencePercent = 55,
                explanation = "Entropy is high (%.1f bits/byte) and blocks rarely repeat, so this data is likely already compressed or encrypted. Using the fast pipeline, since heavier dictionary matching is unlikely to help."
                    .format(features.entropyBitsPerByte)
            )
        }

        if (features.repeatedBlockScore > 0.15) {
            return GenomeSelection(
                genome = GenomePresets.MAXIMUM_COMPRESSION,
                confidencePercent = 88,
                explanation = "Many repeated 8-byte blocks were found (%.0f%% of blocks recur), so dictionary matching should compress this well."
                    .format(features.repeatedBlockScore * 100)
            )
        }

        if (features.runLengthScore > 0.25) {
            return GenomeSelection(
                genome = GenomePresets.FAST,
                confidencePercent = 80,
                explanation = "Long runs of repeated bytes were found (%.0f%% of sampled bytes), so run-length encoding should be very effective here."
                    .format(features.runLengthScore * 100)
            )
        }

        return GenomeSelection(
            genome = GenomePresets.BALANCED,
            confidencePercent = 65,
            explanation = "No single dominant pattern was detected, so the balanced general-purpose pipeline was chosen."
        )
    }
}

/** Rounds a raw compression ratio (originalSize / compressedSize) to one decimal place for display. */
fun Double.roundedRatio(): Double = (this * 10).roundToInt() / 10.0
