package com.novacompress.ai.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novacompress.ai.R
import com.novacompress.ai.data.database.CompressionRecordEntity
import com.novacompress.ai.ui.common.novaViewModel
import java.text.DateFormat
import java.util.Date

@Composable
fun DashboardScreen() {
    val viewModel: DashboardViewModel = novaViewModel()
    val uiState by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(stringResource(R.string.dashboard_title), style = MaterialTheme.typography.headlineMedium)
                Text(
                    stringResource(R.string.dashboard_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = stringResource(R.string.dashboard_total_archives),
                    value = uiState.totalArchives.toString()
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = stringResource(R.string.dashboard_total_saved),
                    value = formatBytes(uiState.totalBytesSaved)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = stringResource(R.string.dashboard_genomes_discovered),
                    value = uiState.genomesDiscovered.toString()
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = stringResource(R.string.dashboard_benchmarks_run),
                    value = uiState.benchmarksRun.toString()
                )
            }
        }

        item {
            Text(stringResource(R.string.dashboard_recent_activity), style = MaterialTheme.typography.titleMedium)
        }

        if (uiState.recentRecords.isEmpty()) {
            item {
                Text(
                    stringResource(R.string.dashboard_no_activity),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(uiState.recentRecords, key = { it.id }) { record ->
                RecentRecordRow(record)
            }
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier = Modifier, label: String, value: String) {
    ElevatedCard(modifier = modifier) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge)
            Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RecentRecordRow(record: CompressionRecordEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(record.originalFileName, style = MaterialTheme.typography.titleMedium)
            Text(
                record.pipelineDescription,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("%.2f\u00d7".format(record.compressionRatio), style = MaterialTheme.typography.labelLarge)
                Text(
                    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                        .format(Date(record.createdAtEpochMillis)),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes / 1024.0
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.size - 1) {
        value /= 1024
        unitIndex++
    }
    return "%.1f %s".format(value, units[unitIndex])
}
