package com.novacompress.ai

import android.net.Uri

/** How MainActivity was launched, resolved once at startup from the incoming Intent. */
sealed class LaunchIntent {
    object None : LaunchIntent()
    data class ShareToCompress(val uri: Uri) : LaunchIntent()
    data class OpenToDecompress(val uri: Uri) : LaunchIntent()
}
