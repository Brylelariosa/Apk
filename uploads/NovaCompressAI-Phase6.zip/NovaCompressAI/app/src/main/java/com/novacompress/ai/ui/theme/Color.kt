package com.novacompress.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Core accent - matches the launcher icon's compression chevrons.
val NovaCyan = Color(0xFF5CE1E6)
val NovaCyanDark = Color(0xFF2AACB2)

val NovaInkDark = Color(0xFF1B1F3B)
val NovaInkLight = Color(0xFFF4F6FB)

val NovaSurfaceDark = Color(0xFF23283F)
val NovaSurfaceLight = Color(0xFFFFFFFF)

val NovaSuccess = Color(0xFF4CD97B)
val NovaWarning = Color(0xFFF2B33D)
val NovaError = Color(0xFFEF5C5C)
