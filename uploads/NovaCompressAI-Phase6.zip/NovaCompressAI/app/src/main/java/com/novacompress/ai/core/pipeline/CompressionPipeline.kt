package com.novacompress.ai.core.pipeline

import com.novacompress.ai.core.plugins.PluginRegistry

/**
 * Executes a [PipelineDescriptor] against real data. Compression runs
 * plugins in declared order; decompression runs them in reverse, each
 * plugin undoing exactly its own transform.
 */
class CompressionPipeline(private val descriptor: PipelineDescriptor) {

    fun compress(input: ByteArray): ByteArray {
        var data = input
        for (id in descriptor.pluginIds) {
            data = PluginRegistry.get(id).compress(data)
        }
        return data
    }

    fun decompress(input: ByteArray): ByteArray {
        var data = input
        for (id in descriptor.pluginIds.asReversed()) {
            data = PluginRegistry.get(id).decompress(data)
        }
        return data
    }

    companion object {
        fun from(pluginIds: List<String>) = CompressionPipeline(PipelineDescriptor(pluginIds))
    }
}
