package com.novacompress.ai.ui.research

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * A minimal bar chart made from proportionally-sized rounded boxes rather
 * than a Canvas draw or an external charting library - real, working, and
 * dependency-free. Good enough for the Statistics Center's simple
 * comparisons (species fitness, genome ratios); a later phase can upgrade
 * to a full interactive Canvas chart (zoom/pan/tooltips) if that's ever
 * worth the added complexity.
 */
@Composable
fun SimpleBarChart(
    values: List<Pair<String, Double>>,
    modifier: Modifier = Modifier,
    valueFormat: (Double) -> String = { "%.2f".format(it) }
) {
    val maxValue = (values.maxOfOrNull { it.second } ?: 0.0).coerceAtLeast(0.0001)
    Column(modifier = modifier) {
        values.forEach { (label, value) ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Text(
                    label,
                    modifier = Modifier.width(96.dp),
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(18.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                ) {
                    val fraction = (value / maxValue).toFloat().coerceIn(0f, 1f)
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(fraction = fraction)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(valueFormat(value), style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
