package com.novacompress.ai.data.repository

import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.evolution.GenomeRepository
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.genome.GenomeStatus
import com.novacompress.ai.data.database.BenchmarkRecordDao
import com.novacompress.ai.data.database.BenchmarkRecordEntity
import com.novacompress.ai.data.database.GenomeDao

class RoomGenomeRepository(
    private val genomeDao: GenomeDao,
    private val benchmarkRecordDao: BenchmarkRecordDao
) : GenomeRepository {

    override suspend fun ensureSeeded(seeds: List<CompressionGenome>) {
        if (genomeDao.count() == 0) {
            seeds.forEach { genomeDao.insertIfNew(it.toEntity(bestFitness = 0.0, bestRatio = 0.0)) }
        }
    }

    override suspend fun topGenomesByFitness(limit: Int): List<CompressionGenome> =
        genomeDao.topByFitness(limit).map { it.toDomain() }

    override suspend fun recordBenchmark(result: BenchmarkResult, fitness: Double) {
        val genome = result.genome

        // Ignored if this genome already exists; the two updates below then
        // apply correctly either way (fresh insert or pre-existing row).
        genomeDao.insertIfNew(genome.toEntity(bestFitness = fitness, bestRatio = result.ratio))
        genomeDao.updateFitnessIfBetter(genome.genomeId, fitness, result.ratio)
        genomeDao.incrementBenchmarkCount(genome.genomeId)

        if (fitness > 0.0 && genome.status == GenomeStatus.EXPERIMENTAL) {
            genomeDao.updateStatus(genome.genomeId, GenomeStatus.VERIFIED.name)
        }

        benchmarkRecordDao.insert(
            BenchmarkRecordEntity(
                genomeId = genome.genomeId,
                originalSize = result.originalSize,
                compressedSize = result.compressedSize,
                compressionTimeNanos = result.compressionTimeNanos,
                decompressionTimeNanos = result.decompressionTimeNanos,
                verified = result.verified,
                fitnessScore = fitness,
                createdAtEpochMillis = System.currentTimeMillis()
            )
        )
    }

    override suspend fun genomeCount(): Int = genomeDao.count()

    override suspend fun benchmarkCount(): Int = benchmarkRecordDao.count()
}
