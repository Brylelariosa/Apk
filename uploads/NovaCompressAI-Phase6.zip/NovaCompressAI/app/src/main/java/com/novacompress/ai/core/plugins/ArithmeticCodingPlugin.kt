package com.novacompress.ai.core.plugins

import com.novacompress.ai.core.common.BinaryIO
import java.io.ByteArrayOutputStream

/**
 * Static order-0 arithmetic coding (Witten-Neal-Cleary integer
 * implementation). Builds a byte-frequency model from the whole input up
 * front (like Huffman does), then encodes the entire input as a single
 * high-precision interval, renormalizing with the standard E1/E2/E3 scaling
 * so 32-bit integer arithmetic never underflows or overflows.
 *
 * All interval arithmetic uses [Long] rather than [Int]: intermediate
 * products like `range * cumulativeFrequency` can reach roughly 2^50
 * (32-bit range times a frequency up to a few hundred thousand for
 * realistic chunk sizes), which overflows a 32-bit Int but fits
 * comfortably in a 64-bit Long.
 *
 * Stream format:
 *   [magic: 1 byte] 0 = EMPTY (no further data), 1 = NORMAL
 *   NORMAL:
 *     [symbolCount: 2 bytes BE]
 *     symbolCount * [symbol: 1 byte][frequency: 4 bytes BE]  (sorted by symbol value ascending)
 *     [originalLength: 4 bytes BE]
 *     [encoded bitstream, MSB-first per byte]
 */
class ArithmeticCodingPlugin : CompressionPlugin {

    override val id: String = "arithmetic"
    override val displayName: String = "Arithmetic Coding"
    override val version: Int = 1

    private companion object {
        const val MAGIC_EMPTY = 0
        const val MAGIC_NORMAL = 1

        const val CODE_BITS = 32
        const val TOP_VALUE = 0xFFFFFFFFL
        val FIRST_QTR = (TOP_VALUE / 4) + 1
        val HALF = 2 * FIRST_QTR
        val THIRD_QTR = 3 * FIRST_QTR
        const val MASK = 0xFFFFFFFFL
    }

    // --- Bit I/O -------------------------------------------------------------

    private class BitWriter {
        val out = ByteArrayOutputStream()
        private var cur = 0
        private var nbits = 0
        private var pending = 0

        fun writeBit(bit: Int) {
            cur = (cur shl 1) or bit
            nbits++
            if (nbits == 8) {
                out.write(cur and 0xFF)
                cur = 0
                nbits = 0
            }
        }

        fun outputBitPlusPending(bit: Int) {
            writeBit(bit)
            repeat(pending) { writeBit(1 - bit) }
            pending = 0
        }

        fun addPending() {
            pending++
        }

        fun finish(): ByteArray {
            if (nbits > 0) {
                cur = cur shl (8 - nbits)
                out.write(cur and 0xFF)
                nbits = 0
            }
            return out.toByteArray()
        }
    }

    private class BitReader(private val data: ByteArray) {
        private var bitPos = 0
        fun readBit(): Int {
            val byteIndex = bitPos / 8
            if (byteIndex >= data.size) {
                bitPos++
                return 0 // pad with zeros past the end, standard practice for arithmetic decoders
            }
            val bitIndex = 7 - (bitPos % 8)
            val bit = (data[byteIndex].toInt() shr bitIndex) and 1
            bitPos++
            return bit
        }
    }

    // --- Frequency model -------------------------------------------------

    /** symbols sorted ascending; cumulative[i] = sum of frequencies of all symbols before symbols[i]. */
    private class Model(val symbols: IntArray, val frequencies: IntArray, val cumulative: LongArray, val total: Long) {
        private val symbolToIndex: Map<Int, Int> = symbols.withIndex().associate { (i, sym) -> sym to i }

        fun rangeOf(symbol: Int): Triple<Long, Long, Long> {
            val idx = symbolToIndex.getValue(symbol)
            val low = cumulative[idx]
            val high = low + frequencies[idx]
            return Triple(low, high, total)
        }

        /** Finds which symbol's cumulative range contains [scaledValue] (decode-side lookup). */
        fun symbolAt(scaledValue: Long): IntArray {
            // Linear scan over at most 256 symbols; a binary search over the
            // sorted cumulative array would be asymptotically better, but
            // adds real risk of an off-by-one bug in the interval-boundary
            // logic that would need its own separate Python-validated
            // prototype to justify - not worth it at this alphabet size.
            for (i in symbols.indices) {
                val low = cumulative[i]
                val high = low + frequencies[i]
                if (scaledValue in low until high) {
                    return intArrayOf(symbols[i], low.toInt(), high.toInt())
                }
            }
            throw IllegalArgumentException("corrupt arithmetic stream: scaled value out of range")
        }

        companion object {
            fun fromFrequencies(freqMap: Map<Int, Int>): Model {
                val symbols = freqMap.keys.sorted().toIntArray()
                val frequencies = IntArray(symbols.size) { freqMap.getValue(symbols[it]) }
                val cumulative = LongArray(symbols.size)
                var running = 0L
                for (i in symbols.indices) {
                    cumulative[i] = running
                    running += frequencies[i]
                }
                return Model(symbols, frequencies, cumulative, running)
            }
        }
    }

    // --- Public API ------------------------------------------------------

    override fun compress(input: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        val n = input.size
        if (n == 0) {
            out.write(MAGIC_EMPTY)
            return out.toByteArray()
        }

        val freqMap = HashMap<Int, Int>()
        for (b in input) {
            val sym = b.toInt() and 0xFF
            freqMap[sym] = (freqMap[sym] ?: 0) + 1
        }
        val model = Model.fromFrequencies(freqMap)

        out.write(MAGIC_NORMAL)
        BinaryIO.writeU16(out, model.symbols.size)
        for (i in model.symbols.indices) {
            out.write(model.symbols[i])
            BinaryIO.writeU32(out, model.frequencies[i])
        }
        BinaryIO.writeU32(out, n)

        val encoded = encodeSymbols(input, model)
        out.write(encoded)
        return out.toByteArray()
    }

    override fun decompress(input: ByteArray): ByteArray {
        val magic = input[0].toInt() and 0xFF
        if (magic == MAGIC_EMPTY) return ByteArray(0)
        require(magic == MAGIC_NORMAL) { "corrupt arithmetic stream: bad magic $magic" }

        var pos = 1
        val symbolCount = BinaryIO.readU16(input, pos)
        pos += 2
        val symbols = IntArray(symbolCount)
        val frequencies = IntArray(symbolCount)
        for (i in 0 until symbolCount) {
            symbols[i] = input[pos].toInt() and 0xFF
            pos += 1
            frequencies[i] = BinaryIO.readU32(input, pos)
            pos += 4
        }
        val originalLength = BinaryIO.readU32(input, pos)
        pos += 4

        val cumulative = LongArray(symbolCount)
        var running = 0L
        for (i in symbols.indices) {
            cumulative[i] = running
            running += frequencies[i]
        }
        val model = Model(symbols, frequencies, cumulative, running)

        val encodedBits = input.copyOfRange(pos, input.size)
        return decodeSymbols(encodedBits, model, originalLength)
    }

    private fun encodeSymbols(input: ByteArray, model: Model): ByteArray {
        val bw = BitWriter()
        var low = 0L
        var high = TOP_VALUE

        for (b in input) {
            val symbol = b.toInt() and 0xFF
            val (symLow, symHigh, total) = model.rangeOf(symbol)
            val range = high - low + 1
            high = low + (range * symHigh) / total - 1
            low = low + (range * symLow) / total

            while (true) {
                when {
                    high < HALF -> bw.outputBitPlusPending(0)
                    low >= HALF -> {
                        bw.outputBitPlusPending(1)
                        low -= HALF
                        high -= HALF
                    }
                    low >= FIRST_QTR && high < THIRD_QTR -> {
                        bw.addPending()
                        low -= FIRST_QTR
                        high -= FIRST_QTR
                    }
                    else -> break
                }
                low *= 2
                high = high * 2 + 1
            }
        }

        bw.addPending()
        if (low < FIRST_QTR) bw.outputBitPlusPending(0) else bw.outputBitPlusPending(1)

        return bw.finish()
    }

    private fun decodeSymbols(encoded: ByteArray, model: Model, symbolCount: Int): ByteArray {
        val br = BitReader(encoded)
        var low = 0L
        var high = TOP_VALUE
        var value = 0L
        repeat(CODE_BITS) {
            value = (value shl 1) or br.readBit().toLong()
        }

        val out = ByteArray(symbolCount)
        for (i in 0 until symbolCount) {
            val range = high - low + 1
            val total = model.total
            val scaledValue = ((value - low + 1) * total - 1) / range
            val symbolInfo = model.symbolAt(scaledValue)
            val symbol = symbolInfo[0]
            val symLow = symbolInfo[1].toLong()
            val symHigh = symbolInfo[2].toLong()
            out[i] = symbol.toByte()

            high = low + (range * symHigh) / total - 1
            low = low + (range * symLow) / total

            while (true) {
                when {
                    high < HALF -> { /* no-op */ }
                    low >= HALF -> {
                        value -= HALF
                        low -= HALF
                        high -= HALF
                    }
                    low >= FIRST_QTR && high < THIRD_QTR -> {
                        value -= FIRST_QTR
                        low -= FIRST_QTR
                        high -= FIRST_QTR
                    }
                    else -> break
                }
                low *= 2
                high = high * 2 + 1
                value = (value * 2 + br.readBit().toLong()) and MASK
            }
        }
        return out
    }
}
