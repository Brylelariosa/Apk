package com.novacompress.ai.core.benchmark

/**
 * Fitness is multidimensional per the spec, but candidates still need a
 * single ranking number. This combines compression ratio (the dominant
 * term) with a mild penalty for slow pipelines, so an enormously slower
 * pipeline needs a meaningfully better ratio to win - matching the spec's
 * "Compression Ratio x Prediction Confidence x Reliability x ... x Battery
 * Score" ranking idea in a simplified, explainable Phase 2 form.
 */
object FitnessCalculator {

    fun calculate(result: BenchmarkResult): Double {
        if (!result.verified) return 0.0

        val totalTimeMs = (result.compressionTimeNanos + result.decompressionTimeNanos) / 1_000_000.0
        // Halves the speed multiplier every ~50ms of combined compress+decompress time,
        // so a pipeline that is merely a bit slower barely loses ground, while one that
        // is drastically slower needs a correspondingly better ratio to still win.
        val speedMultiplier = 50.0 / (50.0 + totalTimeMs)

        return result.ratio * (0.85 + 0.15 * speedMultiplier)
    }
}
