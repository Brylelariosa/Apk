package com.novacompress.ai.di

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.novacompress.ai.NovaCompressApplication
import com.novacompress.ai.ui.compress.CompressViewModel
import com.novacompress.ai.ui.dashboard.DashboardViewModel
import com.novacompress.ai.ui.decompress.DecompressViewModel
import com.novacompress.ai.ui.research.ResearchViewModel
import com.novacompress.ai.ui.settings.SettingsViewModel

class NovaViewModelFactory(private val application: Application) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val locator = (application as NovaCompressApplication).serviceLocator
        return when {
            modelClass.isAssignableFrom(DashboardViewModel::class.java) ->
                DashboardViewModel(locator.repository, locator.evolutionStatsRepository) as T

            modelClass.isAssignableFrom(CompressViewModel::class.java) ->
                CompressViewModel(application, locator.compressionService, locator.repository) as T

            modelClass.isAssignableFrom(DecompressViewModel::class.java) ->
                DecompressViewModel(application, locator.decompressionService, locator.archiveRepairService) as T

            modelClass.isAssignableFrom(ResearchViewModel::class.java) ->
                ResearchViewModel(locator.evolutionStatsRepository) as T

            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(locator.settingsRepository, locator.knowledgeBackupService) as T

            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
