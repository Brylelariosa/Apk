package com.novacompress.ai.ui.compress

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novacompress.ai.R
import com.novacompress.ai.ui.common.novaViewModel

@Composable
fun CompressScreen(initialUri: Uri? = null, onInitialUriConsumed: () -> Unit = {}) {
    val viewModel: CompressViewModel = novaViewModel()
    val uiState by viewModel.uiState.collectAsState()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(initialUri) {
        if (initialUri != null) {
            selectedUri = initialUri
            viewModel.onFileSelected(initialUri)
            onInitialUriConsumed()
        }
    }

    val pickFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            viewModel.onFileSelected(uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(stringResource(R.string.compress_title), style = MaterialTheme.typography.headlineMedium)

        when (uiState.stage) {
            CompressStage.IDLE -> {
                Button(onClick = { pickFileLauncher.launch("*/*") }) {
                    Text(stringResource(R.string.compress_pick_file))
                }
            }

            CompressStage.FILE_SELECTED -> {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(stringResource(R.string.compress_selected_file, uiState.fileName ?: ""))
                        Text(
                            formatBytes(uiState.fileSize),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(onClick = { selectedUri?.let { viewModel.compress(it) } }) {
                    Text(stringResource(R.string.compress_start))
                }
                OutlinedButton(onClick = { pickFileLauncher.launch("*/*") }) {
                    Text(stringResource(R.string.compress_pick_file))
                }
            }

            CompressStage.PROCESSING -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (uiState.chunksTotal > 0) {
                        LinearProgressIndicator(
                            progress = uiState.progressFraction,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("${uiState.chunksDone} / ${uiState.chunksTotal} chunks")
                    } else {
                        CircularProgressIndicator(modifier = Modifier.size(48.dp))
                    }
                    Text(stringResource(R.string.compress_in_progress))
                }
            }

            CompressStage.SUCCESS -> {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            stringResource(R.string.compress_done, "${uiState.fileName}.nova"),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(stringResource(R.string.compress_ratio_label, uiState.ratio))
                        Text(stringResource(R.string.compress_pipeline_label, uiState.pipelineDescription ?: ""))
                        uiState.confidencePercent?.let {
                            Text(stringResource(R.string.compress_confidence_label, it))
                        }
                        uiState.explanation?.let {
                            Text(
                                it,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Button(onClick = {
                    viewModel.reset()
                    selectedUri = null
                }) {
                    Text(stringResource(R.string.compress_pick_file))
                }
            }

            CompressStage.ERROR -> {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            stringResource(R.string.compress_failed, uiState.errorMessage ?: ""),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                Button(onClick = {
                    viewModel.reset()
                    selectedUri = null
                }) {
                    Text(stringResource(R.string.compress_pick_file))
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes / 1024.0
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.size - 1) {
        value /= 1024
        unitIndex++
    }
    return "%.1f %s".format(value, units[unitIndex])
}
