package com.novacompress.ai.core.scheduler

/** Battery charge state. Abstracted behind an interface so scheduling logic is testable with fakes. */
interface BatteryStatusProvider {
    fun isCharging(): Boolean
    /** 0..100. */
    fun batteryPercent(): Int
}

/** Device thermal state. */
interface ThermalStatusProvider {
    /** True when the device is running hot enough that background work should back off. */
    fun isThrottled(): Boolean
}

/** System memory pressure. */
interface MemoryStatusProvider {
    fun isLowMemory(): Boolean
}
