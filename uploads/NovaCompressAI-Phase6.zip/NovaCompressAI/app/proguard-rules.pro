# NovaCompress AI - R8 / ProGuard keep rules (Phase 6)
#
# Philosophy: this sandbox has no Android SDK/emulator to actually run the
# shrunk release APK, so a wrong keep rule here would be a runtime crash
# nobody catches until a real device hits it. Every rule below is
# deliberately broader than the strict minimum, trading a somewhat larger
# APK for confidence that reflection-based framework code (Room, WorkManager)
# keeps working exactly as it does in the unshrunk debug build.

# --- WorkManager ---
# WorkManager instantiates Worker subclasses via reflection using the
# public (Context, WorkerParameters) constructor - it never calls `new`
# directly, so R8 cannot see this usage as an ordinary reference and could
# otherwise strip or rename that constructor.
-keep class com.novacompress.ai.work.** extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
-keep class com.novacompress.ai.work.** { *; }

# --- Room ---
# Room's own AAR ships consumer rules for its generated *_Impl classes,
# but the entities/DAOs/database class themselves are kept broadly here
# too: Room binds SQL columns to fields by name via reflection, so field
# renaming (even without removal) would silently break data mapping in a
# way no test in this project could catch without an actual device.
-keep class com.novacompress.ai.data.database.** { *; }

# --- Compression engine ---
# Plugins are looked up by their string `id` via PluginRegistry rather
# than by reflection today, so this is precautionary rather than strictly
# required - but it's small, and keeps the door open for the planned
# Plugin SDK (dynamic plugin loading) without needing a rule change later.
-keep class com.novacompress.ai.core.plugins.** { *; }
-keep class com.novacompress.ai.core.archive.** { *; }
-keep class com.novacompress.ai.core.genome.** { *; }

# --- Application class ---
# Referenced by fully-qualified name from AndroidManifest.xml.
-keep class com.novacompress.ai.NovaCompressApplication { *; }

# --- General Kotlin metadata ---
# Keeps Kotlin reflection metadata (data class copy()/component1() etc.
# remain callable, enum valueOf/values() keep working) without disabling
# shrinking of everything else.
-keepclassmembers class kotlin.Metadata { *; }
-keep class kotlin.Unit
-dontwarn kotlin.**
