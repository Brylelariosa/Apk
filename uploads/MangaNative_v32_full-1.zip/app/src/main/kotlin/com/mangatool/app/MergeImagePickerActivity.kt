package com.mangatool.app

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MergeImagePickerActivity : AppCompatActivity() {

    companion object {
        const val RESULT_URIS        = "selected_uris"
        const val RESULT_FOLDER_NAME = "folder_name"
        // Selection-only payload for PickerAdapter partial rebind.
        // Defined here because inner classes cannot have companion objects in Kotlin.
        private const val PAYLOAD_SELECTION = "sel"
    }

    private lateinit var albumsRecycler: RecyclerView
    private lateinit var photosRecycler: RecyclerView
    private lateinit var btnAdd:       Button
    private lateinit var btnSelectAll: Button
    private lateinit var selectionBar: TextView
    private lateinit var tvCount:      TextView
    private lateinit var tvTitle:      TextView

    data class Album(
        val bucketId:     Long,
        val bucketName:   String,
        val count:        Int,
        val thumbnailUri: Uri,
        val isAllPhotos:  Boolean = false
    )
    data class DeviceImage(val uri: Uri, val id: Long, val bucketId: Long)

    private enum class ViewState { ALBUMS, PHOTOS }
    private var viewState = ViewState.ALBUMS

    private val allImages     = mutableListOf<DeviceImage>()
    private val currentPhotos = mutableListOf<DeviceImage>()
    private val albums        = mutableListOf<Album>()

    private val selectedUris  = linkedSetOf<String>()
    private var currentAlbum: Album? = null
    private var rangeAnchor   = -1

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.any { it }) loadMedia()
        else tvCount.text = "Storage permission denied"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_merge_picker)

        albumsRecycler = findViewById(R.id.picker_albums)
        photosRecycler = findViewById(R.id.picker_grid)
        btnAdd         = findViewById(R.id.btn_add_selected)
        btnSelectAll   = findViewById(R.id.btn_select_all)
        selectionBar   = findViewById(R.id.tv_selection_bar)
        tvCount        = findViewById(R.id.tv_picker_count)
        tvTitle        = findViewById(R.id.tv_picker_title)

        // Back button
        findViewById<ImageButton>(R.id.btn_picker_back).setOnClickListener { handleBack() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { handleBack() }
        })

        // Add button — return directly without asking for folder name (set in Settings)
        btnAdd.isEnabled = false
        btnAdd.setOnClickListener { returnSelected("") }

        btnSelectAll.setOnClickListener { toggleSelectAll() }

        checkAndLoad()
    }

    private fun handleBack() {
        when (viewState) {
            ViewState.ALBUMS -> finish()
            ViewState.PHOTOS -> showAlbumsView()
        }
    }

    // ── View transitions ───────────────────────────────────────────────────────
    private fun showAlbumsView() {
        viewState    = ViewState.ALBUMS
        currentAlbum = null
        rangeAnchor  = -1

        // Slide out photos, slide in albums
        photosRecycler.animate().alpha(0f).translationX(80f).setDuration(180)
            .withEndAction {
                photosRecycler.visibility = View.GONE
                photosRecycler.alpha = 1f
                photosRecycler.translationX = 0f
            }.start()

        albumsRecycler.translationX = -80f
        albumsRecycler.alpha = 0f
        albumsRecycler.visibility = View.VISIBLE
        albumsRecycler.animate().alpha(1f).translationX(0f)
            .setDuration(200).setInterpolator(DecelerateInterpolator()).start()

        selectionBar.visibility   = View.GONE
        btnSelectAll.visibility   = View.GONE
        tvTitle.text = "Albums"
        tvCount.text = "${albums.size} albums"
    }

    private fun openAlbum(album: Album) {
        currentAlbum = album
        viewState    = ViewState.PHOTOS
        rangeAnchor  = -1

        currentPhotos.clear()
        currentPhotos.addAll(
            if (album.isAllPhotos) allImages
            else allImages.filter { it.bucketId == album.bucketId }
        )

        // Slide in photos
        albumsRecycler.animate().alpha(0f).translationX(-80f).setDuration(180)
            .withEndAction {
                albumsRecycler.visibility = View.GONE
                albumsRecycler.alpha = 1f
                albumsRecycler.translationX = 0f
            }.start()

        photosRecycler.translationX = 80f
        photosRecycler.alpha = 0f
        photosRecycler.visibility = View.VISIBLE
        photosRecycler.animate().alpha(1f).translationX(0f)
            .setDuration(200).setInterpolator(DecelerateInterpolator()).start()

        selectionBar.visibility = View.VISIBLE
        btnSelectAll.visibility = View.VISIBLE

        tvTitle.text = album.bucketName
        updateSelectAllLabel()
        refreshPhotosUI()
        setupPhotosGrid()
    }

    private fun returnSelected(folderName: String) {
        if (selectedUris.isEmpty()) { finish(); return }
        setResult(Activity.RESULT_OK, Intent().apply {
            putStringArrayListExtra(RESULT_URIS, ArrayList(selectedUris))
            putExtra(RESULT_FOLDER_NAME, folderName)
        })
        finish()
    }

    // ── Media loading ──────────────────────────────────────────────────────────
    private fun checkAndLoad() {
        val needed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val ok = needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
        if (ok) loadMedia() else permLauncher.launch(needed)
    }

    private fun loadMedia() {
        lifecycleScope.launch {
            tvCount.text = "Loading..."

            val images = withContext(Dispatchers.IO) {
                val result = mutableListOf<DeviceImage>()
                val proj = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.BUCKET_ID,
                    MediaStore.Images.Media.DATE_ADDED
                )
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    proj, null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { cursor ->
                    val idCol     = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val bucketCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                    while (cursor.moveToNext()) {
                        val id  = cursor.getLong(idCol)
                        val bId = cursor.getLong(bucketCol)
                        result.add(DeviceImage(
                            ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                            id, bId
                        ))
                    }
                }
                result
            }

            allImages.clear(); allImages.addAll(images)

            val bucketMap = withContext(Dispatchers.IO) {
                val map = linkedMapOf<Long, String>()
                val proj2 = arrayOf(MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj2, null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { cursor ->
                    val bIdCol   = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
                    val bNameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                    while (cursor.moveToNext())
                        map.putIfAbsent(cursor.getLong(bIdCol), cursor.getString(bNameCol) ?: "Unknown")
                }
                map
            }

            albums.clear()
            if (allImages.isNotEmpty())
                albums.add(Album(-1L, "All Photos", allImages.size, allImages.first().uri, isAllPhotos = true))
            bucketMap.forEach { (bId, bName) ->
                val photos = allImages.filter { it.bucketId == bId }
                if (photos.isNotEmpty()) albums.add(Album(bId, bName, photos.size, photos.first().uri))
            }

            tvCount.text = "${albums.size} albums"
            setupAlbumsGrid()
        }
    }

    // ── Albums grid ────────────────────────────────────────────────────────────
    private fun setupAlbumsGrid() {
        val screenW  = resources.displayMetrics.widthPixels
        val cols     = if (screenW >= 900) 4 else 3
        val cellSize = (screenW - (cols + 1) * 6.dpToPx) / cols
        albumsRecycler.layoutManager = GridLayoutManager(this, cols)
        albumsRecycler.adapter = AlbumAdapter(cellSize)
    }

    inner class AlbumAdapter(private val cellSize: Int) : RecyclerView.Adapter<AlbumAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb:      ImageView = v.findViewById(R.id.album_thumb)
            val name:       TextView  = v.findViewById(R.id.album_name)
            val countBadge: TextView  = v.findViewById(R.id.album_count)
            // No loadJob — Glide manages request lifecycle
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_album, parent, false)
            v.findViewById<View>(R.id.album_thumb_container).layoutParams =
                v.findViewById<View>(R.id.album_thumb_container).layoutParams.also { it.height = cellSize }
            return VH(v)
        }
        override fun getItemCount() = albums.size
        override fun onBindViewHolder(holder: VH, position: Int) {
            val album = albums[position]
            holder.name.text       = album.bucketName
            holder.countBadge.text = "${album.count}"

            holder.itemView.setOnClickListener { openAlbum(album) }

            // Thumbnail — Glide loads content:// URIs natively, no readBytes() needed
            Glide.with(holder.itemView)
                .load(album.thumbnailUri)
                .override(140)
                .format(com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565)
                .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.RESOURCE)
                .skipMemoryCache(false)
                .dontAnimate()
                .into(holder.thumb)
        }
        override fun onViewRecycled(holder: VH) { Glide.with(holder.thumb).clear(holder.thumb); super.onViewRecycled(holder) }
    }

    // ── Photos grid ────────────────────────────────────────────────────────────
    private fun setupPhotosGrid() {
        val cellSize = resources.displayMetrics.widthPixels / 3
        photosRecycler.layoutManager = GridLayoutManager(this, 3)
        photosRecycler.adapter = PickerAdapter(cellSize)
    }

    private fun toggleSelectAll() {
        val allSelected = currentPhotos.all { it.uri.toString() in selectedUris }
        if (allSelected) currentPhotos.forEach { selectedUris.remove(it.uri.toString()) }
        else             currentPhotos.forEach { selectedUris.add(it.uri.toString()) }
        rangeAnchor = -1

        // v24: Replace notifyDataSetChanged() with a payload-carrying range change.
        //
        // notifyDataSetChanged() caused every visible ViewHolder to receive a FULL
        // rebind: Glide was called again for EVERY thumbnail even though no image
        // changed — only the selection overlay/checkmark state changed.
        // On a 3-column grid with 9 visible cells, that was 9 redundant Glide
        // requests fired simultaneously just to update a visibility flag.
        //
        // notifyItemRangeChanged(0, N, PAYLOAD_SELECTION) delivers the same change
        // notification but routes through the payload-aware onBindViewHolder overload.
        // That overload only updates the three overlay/check/badge Views — Glide
        // is never called, no thumbnail re-decode occurs, and the UI updates in
        // one draw pass (<1 ms) instead of waiting for 9 Glide cache lookups.
        val adapter = photosRecycler.adapter ?: return
        adapter.notifyItemRangeChanged(0, adapter.itemCount, PAYLOAD_SELECTION)
        refreshPhotosUI()
    }

    private fun updateSelectAllLabel() {
        val allSelected = currentPhotos.isNotEmpty() && currentPhotos.all { it.uri.toString() in selectedUris }
        btnSelectAll.text = if (allSelected) "None" else "All"
    }

    private fun refreshPhotosUI() {
        val n       = selectedUris.size
        val inAlbum = currentPhotos.count { it.uri.toString() in selectedUris }
        btnAdd.isEnabled = n > 0
        btnAdd.text = if (n > 0) "Add $n image${if (n == 1) "" else "s"}" else "Add"
        selectionBar.text = when {
            n == 0      -> "Tap to select  \u00B7  long-press to range-select"
            inAlbum > 0 -> "$inAlbum selected here  \u00B7  $n total  \u00B7  long-press to range-select"
            else        -> "$n selected  \u00B7  long-press to range-select"
        }
        tvCount.text = "${currentPhotos.size} photos" + if (inAlbum > 0) "  \u00B7  $inAlbum selected" else ""
        updateSelectAllLabel()
    }

    inner class PickerAdapter(private val cellSize: Int) : RecyclerView.Adapter<PickerAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val image:   ImageView = v.findViewById(R.id.picker_thumb)
            val check:   View      = v.findViewById(R.id.picker_check)
            val overlay: View      = v.findViewById(R.id.picker_overlay)
            val badge:   TextView  = v.findViewById(R.id.picker_badge)
            // No loadJob — Glide manages request lifecycle
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_picker_thumb, parent, false)
            v.layoutParams = v.layoutParams.also { it.height = cellSize }
            return VH(v)
        }

        override fun getItemCount() = currentPhotos.size

        /**
         * Payload-aware partial rebind — only updates selection state.
         *
         * Called when payload = [PAYLOAD_SELECTION]. Updates overlay/check/badge
         * without re-issuing a Glide request. Thumbnail image is unchanged.
         * Falls through to full onBindViewHolder(holder, position) for any other
         * payload (or no payload).
         */
        override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
            if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_SELECTION }) {
                val uriStr  = currentPhotos.getOrNull(position)?.uri?.toString() ?: return
                val selected = uriStr in selectedUris
                holder.overlay.visibility = if (selected) View.VISIBLE else View.GONE
                holder.check.visibility   = if (selected) View.VISIBLE else View.GONE
                val selIdx = selectedUris.indexOf(uriStr)
                holder.badge.visibility = if (selIdx >= 0) View.VISIBLE else View.GONE
                if (selIdx >= 0) holder.badge.text = "${selIdx + 1}"
                return
            }
            // No relevant payload — full rebind
            super.onBindViewHolder(holder, position, payloads)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            // Capture the image at bind time — used directly in click handler
            // so we never depend on a potentially-stale position index.
            val img     = currentPhotos[position]
            val uriStr  = img.uri.toString()
            val selected = uriStr in selectedUris

            // Selection state
            holder.overlay.visibility = if (selected) View.VISIBLE else View.GONE
            holder.check.visibility   = if (selected) View.VISIBLE else View.GONE
            val selIdx = selectedUris.indexOf(uriStr)
            holder.badge.visibility = if (selIdx >= 0) View.VISIBLE else View.GONE
            if (selIdx >= 0) holder.badge.text = "${selIdx + 1}"

            // ── Click: toggle using captured img (safe even during re-layout) ──
            holder.itemView.setOnClickListener {
                val toggleUri = img.uri.toString()   // always correct — img captured at bind
                val wasSelected = toggleUri in selectedUris
                if (wasSelected) selectedUris.remove(toggleUri)
                else             selectedUris.add(toggleUri)

                // Bounce animation on the checkmark
                if (!wasSelected) animateSelect(holder.check)

                // Use bindingAdapterPosition only for rangeAnchor (needs a position)
                val livePos = holder.bindingAdapterPosition
                if (livePos >= 0) rangeAnchor = livePos

                notifyItemChanged(holder.bindingAdapterPosition.takeIf { it >= 0 } ?: position)
                refreshPhotosUI()
            }

            // ── Long press: range select ──────────────────────────────────────
            holder.itemView.setOnLongClickListener {
                val livePos = holder.bindingAdapterPosition.takeIf { it >= 0 } ?: return@setOnLongClickListener true
                val toggleUri = currentPhotos[livePos].uri.toString()
                if (rangeAnchor < 0 || rangeAnchor == livePos) {
                    rangeAnchor = livePos
                    if (toggleUri !in selectedUris) {
                        selectedUris.add(toggleUri); notifyItemChanged(livePos)
                    }
                } else {
                    val lo = minOf(rangeAnchor, livePos); val hi = maxOf(rangeAnchor, livePos)
                    val anchorSelected = currentPhotos[rangeAnchor].uri.toString() in selectedUris
                    for (i in lo..hi) {
                        val u = currentPhotos[i].uri.toString()
                        if (anchorSelected) selectedUris.add(u) else selectedUris.remove(u)
                    }
                    notifyItemRangeChanged(lo, hi - lo + 1)
                    rangeAnchor = livePos
                }
                refreshPhotosUI()
                true
            }

            // ── Thumbnail ─────────────────────────────────────────────────────
            Glide.with(holder.itemView)
                .load(img.uri)
                .override(140)
                .format(com.bumptech.glide.load.DecodeFormat.PREFER_RGB_565)
                .diskCacheStrategy(com.bumptech.glide.load.engine.DiskCacheStrategy.RESOURCE)
                .skipMemoryCache(false)
                .dontAnimate()
                .into(holder.image)
        }

        override fun onViewRecycled(holder: VH) { Glide.with(holder.image).clear(holder.image); super.onViewRecycled(holder) }
    }

    // ── Animations ─────────────────────────────────────────────────────────────
    private fun animateSelect(view: View) {
        view.visibility = View.VISIBLE
        val scaleX = ObjectAnimator.ofFloat(view, "scaleX", 0f, 1.3f, 1f)
        val scaleY = ObjectAnimator.ofFloat(view, "scaleY", 0f, 1.3f, 1f)
        AnimatorSet().apply {
            playTogether(scaleX, scaleY)
            duration = 250
            interpolator = OvershootInterpolator(3f)
            start()
        }
    }

    private val Int.dpToPx get() = (this * resources.displayMetrics.density + 0.5f).toInt()
}

private fun <T> LinkedHashSet<T>.indexOf(element: T): Int {
    var i = 0; for (e in this) { if (e == element) return i; i++ }; return -1
}
