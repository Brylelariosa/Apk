package com.mangatool.app

import com.mangatool.app.model.ImageGroup
import java.io.File

// ── Mode enum ─────────────────────────────────────────────────────────────────
enum class AppMode { EXTRACT, MERGE }

object AppState {

    /** Extract mode has its own group list */
    val extractGroups: MutableList<ImageGroup> = mutableListOf()
    /** Merge mode has its own completely separate group list */
    val mergeGroups: MutableList<ImageGroup> = mutableListOf()

    /** Per-mode URI dedup sets — prevents the same file being imported twice */
    private val seenUrisExtract: MutableSet<String> = mutableSetOf()
    private val seenUrisMerge:   MutableSet<String> = mutableSetOf()
    val seenUris: MutableSet<String>
        get() = if (currentMode == AppMode.MERGE) seenUrisMerge else seenUrisExtract

    var currentMode: AppMode  = AppMode.EXTRACT
    var minSizeKb: Int        = 40
    var excludeGifs: Boolean  = true
    var reverseOrder: Boolean = false
    /** Minimum pixel dimensions — 0 disables that axis's check. User-typed in Filters. */
    var minWidth: Int  = 0
    var minHeight: Int = 0
    /** Master on/off switch for the dimension filter — values are kept even when off. */
    var minDimsEnabled: Boolean = false

    /** Convenience: returns the active mode's list */
    val groups: MutableList<ImageGroup>
        get() = if (currentMode == AppMode.MERGE) mergeGroups else extractGroups

    // ── Thumbnail cache removed in v19 ────────────────────────────────────────
    // AppState.thumbCache (LruCache<String, Bitmap>) was a manual bitmap cache
    // consulted by ImageThumbAdapter, ChapterAdapter, and FilteredThumbAdapter.
    // All three now use Glide, which maintains its own two-tier cache:
    //   • Memory: LruResourceCache (≈ 8% of max heap) — instant re-bind on scroll
    //   • Disk:   DiskLruCache in app-private dir — fast re-load after scroll off
    //
    // Memory pressure response is handled by calling
    //   Glide.get(context).trimMemory(level)
    // from Activity.onTrimMemory(), which Glide maps to its own cache trim logic.
    //
    // BitmapUtils.decodeDispatcher is still used for the dimension-decode pass
    // and for full-resolution merge compositing — those are not Glide operations.

    /** Set once in MainActivity.onCreate — used to clean up temp image files on reset. */
    var imgCacheDir: File? = null

    fun reset() {
        groups.clear()
        seenUris.clear()
    }

    fun resetAll() {
        extractGroups.clear()
        mergeGroups.clear()
        seenUrisExtract.clear()
        seenUrisMerge.clear()
        // Delete all cached image temp files — safe because no ImageItem references remain.
        imgCacheDir?.deleteRecursively()
        filterFingerprints.clear()
    }

    /**
     * Reclaims img_cache subdirectories left behind by PREVIOUS app sessions.
     *
     * Each img_cache/<dir> is created once, at extraction time, and is only
     * ever referenced from the in-memory [extractGroups]/[mergeGroups] lists —
     * nothing about a chapter is restored from disk on a fresh process start.
     * So at the moment this runs, any subdirectory NOT referenced by a
     * currently-loaded group can only be a leftover from a session that has
     * already ended (the user closed/killed the app without hitting Reset).
     *
     * Before this existed, those leftovers were only ever cleared by the
     * Reset button or an OS-level "clear data" — for someone who never taps
     * Reset, img_cache grows without bound across every session. This is the
     * main driver of the app's on-disk cache size creeping up over time.
     *
     * Safety, so this can never interfere with an in-progress share/save:
     *   • Never touches a directory referenced by any image in a currently
     *     loaded group — checked live at call time, so anything added to the
     *     library since app start is protected even if this runs mid-session.
     *   • Skips any directory younger than [minAgeMs]. A directory's mtime
     *     updates whenever a file is added/removed inside it, i.e. at the end
     *     of its extraction — so this protects against the narrow case of the
     *     sweep running moments after a chapter was extracted or an old
     *     session's share is still being read by another app.
     *   • Only ever deletes; never renames or truncates a file still in use.
     *
     * Must be called off the main thread (recursive listing + delete is disk
     * IO), ideally from a low-priority dispatcher so it never competes with
     * active scrolling or extraction — see MainActivity's precacheDispatcher.
     */
    fun sweepOrphanedImgCache(cacheRoot: File, minAgeMs: Long = 90_000L) {
        val dir = File(cacheRoot, "img_cache")
        val children = dir.listFiles() ?: return
        if (children.isEmpty()) return

        val activeDirs: Set<String> = (extractGroups + mergeGroups)
            .asSequence()
            .flatMap { it.allImages.asSequence() }
            .mapNotNull { runCatching { File(it.filePath).parentFile?.canonicalPath }.getOrNull() }
            .toSet()

        val now = System.currentTimeMillis()
        for (child in children) {
            if (!child.isDirectory) continue
            val path = runCatching { child.canonicalPath }.getOrNull() ?: continue
            if (path in activeDirs) continue
            if (now - child.lastModified() < minAgeMs) continue
            child.deleteRecursively()
        }
    }

    /**
     * Fingerprint of the last applyFilters() call per group.
     * If settings haven't changed and the group's allImages hasn't changed,
     * we skip the full rebuild — eliminates redundant allocations on slider drags.
     */
    private val filterFingerprints = mutableMapOf<Long, Long>()

    private fun groupFingerprint(group: ImageGroup): Long =
        31L * (31L * (31L * (31L * (31L * (31L * minSizeKb.toLong() + excludeGifs.hashCode().toLong()) + reverseOrder.hashCode().toLong()) + minWidth.toLong()) + minHeight.toLong()) + minDimsEnabled.hashCode().toLong()) +
        group.allImages.sumOf { it.originalIdx.toLong() + (if (it.userDeleted) 1L else 0L) + (if (it.forceKeep) 2L else 0L) + it.width.toLong() }

    fun applyFilters() {
        groups.forEach { group ->
            if (currentMode == AppMode.MERGE) {
                val fp = groupFingerprint(group)
                if (filterFingerprints[group.id] == fp) return@forEach
                filterFingerprints[group.id] = fp
                // PERF: skip copy() when name stamp already matches.
                // applyFilters() is called on every filter slider tick.  The old code
                // called img.copy(...) unconditionally — 1 allocation per image even
                // when the stamp was already correct.  For 50 groups × 30 images =
                // 1 500 short-lived ImageItem allocations per tick.  These trigger a
                // minor GC cycle that competes with the RecyclerView layout pass and
                // produces the micro-stutter visible on rapid slider drags.
                //
                // Fix: compare the existing name with the expected stamp first.
                // On a second call with unchanged data, zero copies are made.
                group.displayImages = group.allImages.mapIndexed { i, img ->
                    val expectedName = "${(i + 1).toString().padStart(3, '0')}.${img.ext}"
                    if (img.name == expectedName) img else img.copy(name = expectedName)
                }
                group.filteredImages = emptyList()
                return@forEach
            }

            val fp = groupFingerprint(group)
            if (filterFingerprints[group.id] == fp) return@forEach
            filterFingerprints[group.id] = fp

            val valid    = mutableListOf<com.mangatool.app.model.ImageItem>()
            val filtered = mutableListOf<com.mangatool.app.model.ImageItem>()
            val minBytes = minSizeKb * 1024

            group.allImages.forEach { img ->
                val tooSmallDims = minDimsEnabled && (minWidth > 0 || minHeight > 0) && img.width > 0 &&
                    (img.width < minWidth || img.height < minHeight)
                val reason = when {
                    img.userDeleted -> "Manually Deleted"
                    img.forceKeep  -> null
                    img.size < minBytes -> "Too Small (${img.size / 1024}KB)"
                    tooSmallDims -> "Too Small (${img.width}×${img.height}px)"
                    excludeGifs && img.ext.equals("gif", true) -> "GIF Excluded"
                    else -> null
                }
                if (reason != null) filtered.add(img.copy(filterReason = reason))
                else valid.add(img)
            }
            if (reverseOrder) valid.reverse()
            // PERF: same name-stamp skip optimisation for extract mode.
            group.displayImages = valid.mapIndexed { i, img ->
                val expectedName = "${(i + 1).toString().padStart(3, '0')}.${img.ext}"
                if (img.name == expectedName) img else img.copy(name = expectedName)
            }
            group.filteredImages = filtered
        }
    }

    fun invalidateFilter(group: ImageGroup) { filterFingerprints.remove(group.id) }
    fun invalidateAllFilters() { filterFingerprints.clear() }
}
