package com.mangatool.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher

object BitmapUtils {

    /**
     * Adaptive thread pool for bitmap decode work.
     *
     * Old value was hardcoded 3 — left most phone cores idle.
     * New: half the available cores, clamped to [2, 6].
     * A Snapdragon 8-core gets 4 threads; a budget 4-core gets 2.
     * Dispatchers.IO (64 threads) was too aggressive — thrashes the CPU
     * and causes GC spikes when every thumbnail loads simultaneously.
     */
    val decodeDispatcher = Executors.newFixedThreadPool(
        (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 6)
    ).asCoroutineDispatcher()

    // ── File path API — always prefer these ──────────────────────────────────
    // BitmapFactory.decodeFile() streams from the file descriptor and does NOT
    // allocate a ByteArray — only decoded pixel data hits the heap.

    /** Decode pixel dimensions without loading any pixel data. */
    fun decodeDimensions(filePath: String): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        return opts.outWidth to opts.outHeight
    }

    /**
     * Decode a thumbnail ≤ [maxPx] using RGB_565 (half the RAM of ARGB_8888).
     * Manga pages are JPEGs with no alpha — identical visual quality at 2× cache density.
     *
     * 1. inSampleSize coarse decode → ~2× target (minimises pixel data loaded)
     * 2. Bilinear createScaledBitmap → smooth final size
     */
    fun decodeThumbnail(filePath: String, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeFile(filePath, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /**
     * Decode for on-screen preview, scaled to fit within [maxPx] on the longest axis.
     *
     * Uses ARGB_8888 (full color — no RGB_565 dithering) so preview fidelity is
     * identical to the source. Source files on disk are NEVER modified; lossless
     * quality is fully preserved for saving.
     *
     * A 1600×2400 px page → 1080 px fits in ~4 MB instead of ~14 MB at full res,
     * and decodes ~4× faster. Pages already smaller than [maxPx] are decoded at
     * their original size with no upsampling.
     */
    fun decodeForDisplay(filePath: String, maxPx: Int = 1080): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(filePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        // Already fits on screen — decode at full resolution, no scaling needed.
        if (maxOf(opts.outWidth, opts.outHeight) <= maxPx) return BitmapFactory.decodeFile(filePath)

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeFile(filePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            // ARGB_8888 default — intentionally NOT RGB_565 here (preview should be full color)
        }) ?: return null

        val roughLargest = maxOf(rough.width, rough.height)
        if (roughLargest <= maxPx) return rough

        val scale = maxPx.toFloat() / roughLargest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }

    /** Decode at full resolution for merge compositing only (not preview). */
    fun decodeFull(filePath: String): Bitmap? = BitmapFactory.decodeFile(filePath)

    // ── ByteArray overload — only for Uri streams (MergeImagePickerActivity) ─
    // Images in the picker come from content:// URIs before import, so there's
    // no temp file yet. This overload keeps that path working.

    fun decodeThumbnail(bytes: ByteArray, maxPx: Int = 256): Bitmap? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        var sample = 1
        while (opts.outWidth / (sample * 2) >= maxPx && opts.outHeight / (sample * 2) >= maxPx)
            sample *= 2

        val rough = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply {
            inSampleSize      = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }) ?: return null

        val largest = maxOf(rough.width, rough.height)
        if (largest <= maxPx) return rough

        val scale = maxPx.toFloat() / largest
        val w = (rough.width  * scale).toInt().coerceAtLeast(1)
        val h = (rough.height * scale).toInt().coerceAtLeast(1)
        val scaled = Bitmap.createScaledBitmap(rough, w, h, true)
        if (scaled !== rough) rough.recycle()
        return scaled
    }
}
