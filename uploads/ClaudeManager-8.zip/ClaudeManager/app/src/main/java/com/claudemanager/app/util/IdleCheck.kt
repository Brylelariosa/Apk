package com.claudemanager.app.util

import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project

/** One thing that still stops an account from being idle. */
sealed interface IdleReason {

    /** When this reason stops holding the account back, or null when only a status change ends it. */
    val endsAt: Long?

    /**
     * A project is RUNNING, BUILDING, TESTING or has a custom status (or is WAITING with no reset
     * time set). The account is in use for as long as that status stays, however long that is:
     * the app cannot tell a forgotten project from one that is still being worked on, and showing
     * IDLE while the account is in use is the worse mistake. [since] is when the status was set.
     */
    data class Working(val project: Project, val since: Long) : IdleReason {
        override val endsAt: Long?
            get() = null
    }

    /** The project's reset time has not been reached yet. */
    data class ResetPending(val project: Project, override val endsAt: Long) : IdleReason

    /** A project of this account was deleted; the account stays in use until [endsAt]. */
    data class DeleteHold(override val endsAt: Long) : IdleReason
}

class IdleReport(val reasons: List<IdleReason>) {

    /** True only when every check passed. */
    val isIdle: Boolean
        get() = reasons.isEmpty()

    /** True when a reason has no end time: the account stays in use until a status is changed. */
    val isOpenEnded: Boolean
        get() = reasons.any { it.endsAt == null }

    /**
     * When the account turns idle by itself, as long as it is not used again: the latest end time
     * among the reasons. Null when it is already idle, and null when it is [isOpenEnded] (only
     * changing a status can free it, so there is no time to give).
     */
    val idleAt: Long?
        get() {
            var latest: Long? = null
            for (reason in reasons) {
                val end = reason.endsAt ?: return null
                val best = latest
                if (best == null || end > best) latest = end
            }
            return latest
        }
}

/**
 * "Is this account really idle?" An account is idle only when ALL of these hold:
 *
 *   1. No project is RUNNING, BUILDING, TESTING or has a custom status. Those statuses mean the
 *      account is being used, and they last until you change them.
 *   2. Every project's reset time has passed (or was never set). A WAITING project is waiting for
 *      exactly that reset time; with none set, it keeps the account in use by itself.
 *   3. The hold after a deleted project is over.
 *
 * READY, FINISHED and ERROR projects do not block by themselves; their reset time (2) still does.
 * A FINISHED project's reset time is the window DONE just started (see FinishRule), so a finished
 * account stays in use for the full window instead of turning idle at once.
 *
 * Pure Kotlin on purpose: the clock is passed in, so the result depends on nothing else.
 */
object IdleCheck {

    /**
     * How long an account is held after one of its projects is deleted: one Claude usage window.
     * Deleting a project counts as use, so the account must not look free the moment it is gone.
     */
    const val DELETE_HOLD_MILLIS: Long = 5L * 60L * 60L * 1000L

    /**
     * When [project]'s current status was set: its latest status change or start, or its creation
     * for a project that has neither.
     */
    fun statusSince(project: Project): Long =
        project.lastActivityChangeAt ?: project.lastStartedAt ?: project.createdAt

    fun report(account: Account, projects: List<Project>, now: Long): IdleReport {
        val working = mutableListOf<IdleReason.Working>()
        val resets = mutableListOf<IdleReason.ResetPending>()

        for (p in projects) {
            if (p.accountId != account.id) continue

            when (p.activityStatus) {
                ActivityStatus.RUNNING,
                ActivityStatus.BUILDING,
                ActivityStatus.TESTING,
                ActivityStatus.CUSTOM -> {
                    working.add(IdleReason.Working(p, statusSince(p)))
                }

                // Waiting for the reset time, which is checked below. Without one nothing says
                // when the wait ends, so the status itself keeps the account in use.
                ActivityStatus.WAITING -> {
                    if (p.timerEndTimestamp == null) {
                        working.add(IdleReason.Working(p, statusSince(p)))
                    }
                }

                ActivityStatus.READY,
                ActivityStatus.FINISHED,
                ActivityStatus.ERROR -> Unit
            }

            val end = p.timerEndTimestamp
            if (end != null && end > now) resets.add(IdleReason.ResetPending(p, end))
        }

        val reasons = mutableListOf<IdleReason>()
        reasons.addAll(working)
        reasons.addAll(resets.sortedBy { it.endsAt })

        val hold = account.holdUntil
        if (hold != null && hold > now) reasons.add(IdleReason.DeleteHold(hold))

        return IdleReport(reasons)
    }
}
