package com.claudemanager.app.ui

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.claudemanager.app.data.Account
import com.claudemanager.app.data.ActivityStatus
import com.claudemanager.app.data.Project
import com.claudemanager.app.data.Settings
import com.claudemanager.app.data.displayName
import com.claudemanager.app.util.IdleCheck
import com.claudemanager.app.util.IdleReason
import com.claudemanager.app.util.IdleReport
import com.claudemanager.app.util.TimeUtil

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

/** Most reason lines one account card shows; the rest is summed up as "+N more". */
private const val MAX_REASON_LINES = 4

@Composable
fun AccountsScreen(
    accounts: List<Account>,
    projects: List<Project>,
    now: Long,
    onBack: () -> Unit,
    onSave: (Long?, String) -> Unit,
    onDelete: (Long) -> Unit,
    onClearHold: (Long) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var deleting by remember { mutableStateOf<Account?>(null) }

    // An account is idle only when the whole idle check passes (see IdleCheck): nothing running,
    // every reset over, no hold after a deleted project. Idle accounts go first, then the
    // ones that free up soonest, so the free ones are obvious.
    val reports = remember(accounts, projects, now) {
        accounts.associate { it.id to IdleCheck.report(it, projects, now) }
    }
    val ordered = remember(accounts, reports) {
        accounts.sortedWith(
            compareByDescending<Account> { reports[it.id]?.isIdle == true }
                .thenBy { reports[it.id]?.idleAt ?: Long.MAX_VALUE }
                .thenBy { it.displayName.lowercase() }
        )
    }
    val idleCount = ordered.count { reports[it.id]?.isIdle == true }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { adding = true },
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add account")
            }
        }
    ) { inner ->
        Column(Modifier.fillMaxSize().padding(inner)) {
            ScreenHeader("Accounts", onBack)
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (accounts.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            text = "No accounts yet. Add the email of each Claude account you switch between, then pick one when you create a project.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = cs.onSurfaceVariant
                        )
                    }
                } else {
                    item(key = "summary") {
                        Column(Modifier.padding(start = 4.dp, bottom = 2.dp)) {
                            Row {
                                Text(
                                    text = "$idleCount idle",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (idleCount > 0) ResetGreen else cs.onSurfaceVariant
                                )
                                Text(
                                    text = " \u00B7 ${accounts.size - idleCount} in use",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = cs.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "Idle means nothing is running or waiting, every reset time has passed, " +
                                    "and no project was just deleted.",
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSurfaceVariant
                            )
                        }
                    }
                }
                items(ordered, key = { it.id }) { a ->
                    val report = reports[a.id]
                    val idle = report == null || report.isIdle
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = cs.surface),
                        border = BorderStroke(
                            1.dp,
                            if (idle) ResetGreen.copy(alpha = 0.55f) else cs.outlineVariant
                        )
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = a.displayName,
                                        modifier = Modifier.weight(1f, fill = false),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    if (idle) IdleBadge() else InUseBadge()
                                }
                                TextButton(onClick = { editing = a }) { Text("Edit") }
                                TextButton(onClick = { deleting = a }) {
                                    Text("Delete", color = cs.error)
                                }
                            }
                            // Not idle: say exactly what is still in the way.
                            if (report != null && !report.isIdle) {
                                IdleReasons(
                                    report = report,
                                    now = now,
                                    onClearHold = { onClearHold(a.id) },
                                    modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (adding) {
        AccountDialog(
            initial = null,
            accounts = accounts,
            onSave = { email ->
                onSave(null, email)
                adding = false
            },
            onDismiss = { adding = false }
        )
    }

    val editTarget = editing
    if (editTarget != null) {
        AccountDialog(
            initial = editTarget,
            accounts = accounts,
            onSave = { email ->
                onSave(editTarget.id, email)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }

    val deleteTarget = deleting
    if (deleteTarget != null) {
        val count = projects.count { it.accountId == deleteTarget.id }
        ConfirmDialog(
            title = "Delete ${deleteTarget.displayName}?",
            message = if (count == 0) {
                "This account has no projects."
            } else {
                "Its projects stay, but they will have no account."
            },
            confirmLabel = "Delete",
            onConfirm = {
                onDelete(deleteTarget.id)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}

private class ReasonText(val color: Color, val text: String)

private fun projectLabel(p: Project): String = p.name.trim().ifEmpty { "Untitled project" }

/** "3:30 PM (in 2h 10m)", with the weekday in front when it is not today. */
private fun clockAndLeft(context: Context, ms: Long, now: Long): String =
    "${TimeUtil.formatClock(context, ms, now)} (in ${TimeUtil.formatRemaining(ms - now)})"

/** The failed checks of one account, then when it will be idle. */
@Composable
private fun IdleReasons(
    report: IdleReport,
    now: Long,
    onClearHold: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current
    // A running project (or a wait with no reset time) has no end time: only changing its status
    // frees the account, so there is no clock time to show.
    val idleAt = report.idleAt
    val shown = report.reasons.take(MAX_REASON_LINES)
    val hidden = report.reasons.size - shown.size
    val summary = if (idleAt != null) {
        "Idle at ${TimeUtil.formatClock(context, idleAt, now)} \u00B7 in ${TimeUtil.formatRemaining(idleAt - now)}"
    } else {
        "In use until its status changes"
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (reason in shown) {
            ReasonLine(reason, now, onClearHold)
        }
        if (hidden > 0) {
            Text(
                text = "+$hidden more",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
        Text(
            text = summary,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = cs.primary
        )
    }
}

@Composable
private fun ReasonLine(reason: IdleReason, now: Long, onClearHold: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val context = LocalContext.current

    val line: ReasonText = when (reason) {
        is IdleReason.Working -> {
            val p = reason.project
            val how = if (p.activityStatus == ActivityStatus.WAITING) {
                "no reset time set"
            } else {
                "for ${TimeUtil.formatRemaining(now - reason.since)}"
            }
            ReasonText(
                statusColor(p.activityStatus),
                "${projectLabel(p)} \u00B7 ${statusLabel(p.activityStatus, p.customStatusLabel)} \u00B7 $how"
            )
        }
        is IdleReason.ResetPending -> ReasonText(
            cs.primary,
            "${projectLabel(reason.project)} \u00B7 resets ${clockAndLeft(context, reason.endsAt, now)}"
        )
        is IdleReason.DeleteHold -> ReasonText(
            cs.outline,
            "Project deleted \u00B7 held until ${clockAndLeft(context, reason.endsAt, now)}"
        )
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        StatusDot(line.color, 7.dp)
        Spacer(Modifier.width(8.dp))
        Text(
            text = line.text,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurface,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (reason is IdleReason.DeleteHold) {
            TextButton(onClick = onClearHold) { Text("Clear hold") }
        }
    }
}

@Composable
fun SettingsScreen(
    settings: Settings,
    onBack: () -> Unit,
    onChange: (Settings) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var hours by remember { mutableStateOf((settings.defaultDurationMillis / 3_600_000L).toString()) }
    var minutes by remember { mutableStateOf(((settings.defaultDurationMillis / 60_000L) % 60L).toString()) }
    var limit by remember { mutableStateOf(settings.historyLimit.toString()) }

    fun push(h: String, m: String, l: String) {
        val millis = durationMillisOf(h, m)
        val keep = l.toIntOrNull() ?: 0
        if (millis > 0L && keep in 1..500) {
            onChange(settings.copy(defaultDurationMillis = millis, historyLimit = keep))
        }
    }

    Scaffold { inner ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .verticalScroll(rememberScrollState())
        ) {
            ScreenHeader("Settings", onBack)
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Default timer",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "New projects start with this length. You can change it per project.",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                    DurationFields(
                        hours = hours,
                        minutes = minutes,
                        onHoursChange = {
                            hours = it
                            push(it, minutes, limit)
                        },
                        onMinutesChange = {
                            minutes = it
                            push(hours, it, limit)
                        }
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Activity history",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    OutlinedTextField(
                        value = limit,
                        onValueChange = { v ->
                            val digits = v.filter { c -> c.isDigit() }.take(3)
                            limit = digits
                            push(hours, minutes, digits)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Entries kept per project") },
                        supportingText = { Text("Between 1 and 500. Older entries are dropped.") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Reset alarm",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Rings at each project's reset time, like an alarm clock.",
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Switch(
                        checked = settings.notificationsEnabled,
                        onCheckedChange = { onChange(settings.copy(notificationsEnabled = it)) }
                    )
                }
            }
        }
    }
}
