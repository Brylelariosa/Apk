package com.zsurvival.app.game.weapon

/**
 * Pure data — firing behavior lives in GameSimulation so it has access to
 * the bullet list / id generator. Add SHOTGUN, SMG, ASSAULT_RIFLE, SNIPER,
 * LMG, FLAMETHROWER, ROCKET_LAUNCHER here later; GameSimulation.tryFire()
 * and the shop are the places that would need to know about them next.
 */
enum class WeaponType(
    val displayName: String,
    val damage: Int,
    val fireCooldownMs: Long,
    val magazineSize: Int,
    val reloadTimeMs: Long,
    val bulletSpeed: Float,
    val range: Float
) {
    PISTOL(
        displayName = "Pistol",
        damage = 18,
        fireCooldownMs = 260,
        magazineSize = 12,
        reloadTimeMs = 1100,
        bulletSpeed = 900f,
        range = 750f
    )
}
