package com.quickshare

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

// Placeholder — receive logic lives in MainActivity for now.
// This activity can be extended later for dedicated receive mode.
class ReceiveActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        finish() // redirect back
    }
}
