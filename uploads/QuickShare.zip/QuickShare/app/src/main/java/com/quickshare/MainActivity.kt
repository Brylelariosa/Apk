package com.quickshare

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.quickshare.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.text.DecimalFormat

class MainActivity : AppCompatActivity(), WifiP2pManager.ChannelListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var manager: WifiP2pManager
    private lateinit var channel: WifiP2pManager.Channel
    private lateinit var receiver: BroadcastReceiver

    private var isWifiP2pEnabled = false
    private var connectedDeviceInfo: WifiP2pInfo? = null
    private val peers = mutableListOf<WifiP2pDevice>()
    private lateinit var deviceAdapter: DeviceAdapter

    private var selectedFileUri: Uri? = null
    private var selectedFileName: String = ""
    private var selectedFileSize: Long = 0L

    private val SERVER_PORT = 8988
    private val BUFFER_SIZE = 65536 // 64KB buffer for fast transfer

    private var serverJob: Job? = null
    private var isReceiving = false

    companion object {
        private const val TAG = "QuickShare"
    }

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            initWifiDirect()
        } else {
            showToast("Permissions required for WiFi Direct")
        }
    }

    // File picker launcher
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedFileUri = it
            val (name, size) = getFileInfo(it)
            selectedFileName = name
            selectedFileSize = size
            binding.tvSelectedFile.text = "$name (${formatSize(size)})"
            binding.btnSendFile.isEnabled = connectedDeviceInfo != null
            binding.cardSelectedFile.visibility = View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        checkPermissionsAndInit()
    }

    private fun setupUI() {
        // Device list
        deviceAdapter = DeviceAdapter(peers) { device ->
            connectToDevice(device)
        }
        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = deviceAdapter

        // Discover button
        binding.btnDiscover.setOnClickListener {
            if (!isWifiP2pEnabled) {
                showToast("Please enable WiFi")
                return@setOnClickListener
            }
            discoverPeers()
        }

        // Pick file button
        binding.btnPickFile.setOnClickListener {
            filePickerLauncher.launch("*/*")
        }

        // Send file button
        binding.btnSendFile.setOnClickListener {
            selectedFileUri?.let { uri ->
                connectedDeviceInfo?.let { info ->
                    sendFile(uri, info)
                } ?: showToast("Not connected to any device")
            } ?: showToast("Please select a file first")
        }

        // Receive mode button
        binding.btnReceive.setOnClickListener {
            if (!isReceiving) {
                startReceiveServer()
            } else {
                stopReceiveServer()
            }
        }

        // Disconnect button
        binding.btnDisconnect.setOnClickListener {
            disconnectFromPeer()
        }

        updateStatus("Ready — Tap Discover to find nearby devices")
        updateConnectionUI(false)
    }

    private fun checkPermissionsAndInit() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            initWifiDirect()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun initWifiDirect() {
        manager = getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        channel = manager.initialize(this, mainLooper, this)

        receiver = WiFiDirectBroadcastReceiver(manager, channel, this)

        val intentFilter = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        }
        registerReceiver(receiver, intentFilter)
    }

    override fun onResume() {
        super.onResume()
        if (::receiver.isInitialized) {
            val intentFilter = IntentFilter().apply {
                addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
            }
            registerReceiver(receiver, intentFilter)
        }
    }

    override fun onPause() {
        super.onPause()
        if (::receiver.isInitialized) {
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serverJob?.cancel()
    }

    // ── WiFi Direct ──────────────────────────────────────────────────────────

    fun setWifiP2pEnabled(enabled: Boolean) {
        isWifiP2pEnabled = enabled
        if (!enabled) {
            updateStatus("WiFi is OFF — please enable WiFi")
            updateConnectionUI(false)
        }
    }

    private fun discoverPeers() {
        updateStatus("Discovering nearby devices...")
        binding.progressBar.visibility = View.VISIBLE

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            showToast("Location permission needed")
            return
        }

        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                updateStatus("Scanning for devices...")
            }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                val msg = when (reason) {
                    WifiP2pManager.P2P_UNSUPPORTED -> "WiFi Direct not supported"
                    WifiP2pManager.BUSY -> "System busy, try again"
                    else -> "Discovery failed ($reason)"
                }
                updateStatus(msg)
                showToast(msg)
            }
        })
    }

    fun updatePeerList(deviceList: Collection<WifiP2pDevice>) {
        binding.progressBar.visibility = View.GONE
        peers.clear()
        peers.addAll(deviceList)
        deviceAdapter.notifyDataSetChanged()

        if (peers.isEmpty()) {
            updateStatus("No devices found — make sure both devices have QuickShare open")
            binding.tvNoPeers.visibility = View.VISIBLE
        } else {
            updateStatus("Found ${peers.size} device(s) — tap to connect")
            binding.tvNoPeers.visibility = View.GONE
        }
    }

    private fun connectToDevice(device: WifiP2pDevice) {
        val config = WifiP2pConfig().apply {
            deviceAddress = device.deviceAddress
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) return

        updateStatus("Connecting to ${device.deviceName}...")
        binding.progressBar.visibility = View.VISIBLE

        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                showToast("Connection request sent to ${device.deviceName}")
            }
            override fun onFailure(reason: Int) {
                binding.progressBar.visibility = View.GONE
                showToast("Connection failed: $reason")
                updateStatus("Connection failed. Try again.")
            }
        })
    }

    fun onConnectionInfoAvailable(info: WifiP2pInfo) {
        binding.progressBar.visibility = View.GONE
        connectedDeviceInfo = info

        if (info.groupFormed) {
            val role = if (info.isGroupOwner) "Host" else "Client"
            val hostIp = info.groupOwnerAddress?.hostAddress ?: "unknown"
            updateStatus("✓ Connected as $role — Host IP: $hostIp")
            updateConnectionUI(true)

            // Auto-start receiver if we are the group owner
            if (info.isGroupOwner && !isReceiving) {
                startReceiveServer()
            }
        }
    }

    private fun disconnectFromPeer() {
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                connectedDeviceInfo = null
                updateConnectionUI(false)
                updateStatus("Disconnected")
                stopReceiveServer()
            }
            override fun onFailure(reason: Int) {
                showToast("Disconnect failed: $reason")
            }
        })
    }

    override fun onChannelDisconnected() {
        showToast("Channel lost. Reconnecting...")
        if (::manager.isInitialized && ::channel.isInitialized) {
            channel = manager.initialize(this, mainLooper, this)
        }
    }

    // ── File Transfer ─────────────────────────────────────────────────────────

    private fun startReceiveServer() {
        isReceiving = true
        binding.btnReceive.text = "⏹ Stop Receiving"
        binding.btnReceive.setBackgroundColor(getColor(R.color.red))
        updateStatus("Waiting to receive files on port $SERVER_PORT...")

        serverJob?.cancel()
        serverJob = lifecycleScope.launch(Dispatchers.IO) {
            var serverSocket: ServerSocket? = null
            try {
                serverSocket = ServerSocket(SERVER_PORT)
                serverSocket.reuseAddress = true
                Log.d(TAG, "Server started on port $SERVER_PORT")

                while (isActive && isReceiving) {
                    try {
                        val client = serverSocket.accept()
                        launch { handleIncomingFile(client) }
                    } catch (e: Exception) {
                        if (isActive) Log.e(TAG, "Accept error: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server error: ${e.message}")
                withContext(Dispatchers.Main) {
                    showToast("Receive server error: ${e.message}")
                }
            } finally {
                serverSocket?.close()
            }
        }
    }

    private fun stopReceiveServer() {
        isReceiving = false
        serverJob?.cancel()
        binding.btnReceive.text = "📥 Start Receiving"
        binding.btnReceive.setBackgroundColor(getColor(R.color.green))
    }

    private suspend fun handleIncomingFile(socket: Socket) {
        try {
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))

            // Read header: filename length, filename, file size
            val nameLen = input.readInt()
            val nameBytes = ByteArray(nameLen)
            input.readFully(nameBytes)
            val fileName = String(nameBytes, Charsets.UTF_8)
            val fileSize = input.readLong()

            Log.d(TAG, "Receiving: $fileName ($fileSize bytes)")

            withContext(Dispatchers.Main) {
                updateStatus("Receiving: $fileName (${formatSize(fileSize)})...")
                showProgressUI(true, fileName, fileSize)
            }

            // Save to Downloads
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            downloadsDir.mkdirs()
            val outFile = File(downloadsDir, getUniqueFileName(downloadsDir, fileName))

            val output = BufferedOutputStream(FileOutputStream(outFile), BUFFER_SIZE)
            val buffer = ByteArray(BUFFER_SIZE)
            var bytesRead: Int
            var totalReceived = 0L
            val startTime = System.currentTimeMillis()

            while (totalReceived < fileSize) {
                bytesRead = input.read(buffer, 0, minOf(buffer.size, (fileSize - totalReceived).toInt()))
                if (bytesRead == -1) break
                output.write(buffer, 0, bytesRead)
                totalReceived += bytesRead

                val progress = ((totalReceived * 100) / fileSize).toInt()
                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                val speed = if (elapsed > 0) totalReceived / elapsed / 1024 / 1024 else 0.0

                withContext(Dispatchers.Main) {
                    updateProgress(progress, totalReceived, fileSize, speed)
                }
            }

            output.flush()
            output.close()
            input.close()
            socket.close()

            val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
            val avgSpeed = totalReceived / elapsed / 1024 / 1024

            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("✅ Received: $fileName\nSaved to Downloads — ${formatSize(totalReceived)} at ${String.format("%.1f", avgSpeed)} MB/s")
                showToast("File saved: ${outFile.name}")
            }

        } catch (e: Exception) {
            Log.e(TAG, "Receive error: ${e.message}")
            withContext(Dispatchers.Main) {
                showProgressUI(false, "", 0)
                updateStatus("❌ Receive failed: ${e.message}")
            }
        }
    }

    private fun sendFile(uri: Uri, info: WifiP2pInfo) {
        val hostIp = info.groupOwnerAddress?.hostAddress ?: run {
            showToast("Cannot determine host IP")
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            try {
                withContext(Dispatchers.Main) {
                    updateStatus("Connecting to host...")
                    showProgressUI(true, selectedFileName, selectedFileSize)
                }

                socket = Socket()
                socket.setPerformancePreferences(0, 0, 1) // maximize bandwidth
                socket.sendBufferSize = BUFFER_SIZE
                socket.connect(InetSocketAddress(hostIp, SERVER_PORT), 5000)

                val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

                // Write header
                val nameBytes = selectedFileName.toByteArray(Charsets.UTF_8)
                output.writeInt(nameBytes.size)
                output.write(nameBytes)
                output.writeLong(selectedFileSize)

                // Write file data
                val input = contentResolver.openInputStream(uri)
                    ?: throw IOException("Cannot open file")

                val buffer = ByteArray(BUFFER_SIZE)
                var bytesRead: Int
                var totalSent = 0L
                val startTime = System.currentTimeMillis()

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                    totalSent += bytesRead

                    val progress = if (selectedFileSize > 0) ((totalSent * 100) / selectedFileSize).toInt() else 0
                    val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                    val speed = if (elapsed > 0) totalSent / elapsed / 1024 / 1024 else 0.0

                    withContext(Dispatchers.Main) {
                        updateProgress(progress, totalSent, selectedFileSize, speed)
                    }
                }

                output.flush()
                input.close()
                output.close()
                socket.close()

                val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                val avgSpeed = totalSent / elapsed / 1024 / 1024

                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("✅ Sent: $selectedFileName\n${formatSize(totalSent)} at ${String.format("%.1f", avgSpeed)} MB/s")
                    showToast("File sent successfully!")
                }

            } catch (e: Exception) {
                Log.e(TAG, "Send error: ${e.message}")
                withContext(Dispatchers.Main) {
                    showProgressUI(false, "", 0)
                    updateStatus("❌ Send failed: ${e.message}")
                    showToast("Send failed: ${e.message}")
                }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    // ── UI Helpers ─────────────────────────────────────────────────────────────

    private fun updateStatus(msg: String) {
        binding.tvStatus.text = msg
    }

    private fun updateConnectionUI(connected: Boolean) {
        binding.btnDisconnect.visibility = if (connected) View.VISIBLE else View.GONE
        binding.btnSendFile.isEnabled = connected && selectedFileUri != null
        if (!connected) {
            connectedDeviceInfo = null
        }
    }

    private fun showProgressUI(show: Boolean, fileName: String, fileSize: Long) {
        binding.cardProgress.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            binding.tvProgressFile.text = fileName
            binding.tvProgressSize.text = formatSize(fileSize)
            binding.progressTransfer.progress = 0
            binding.tvProgressPercent.text = "0%"
            binding.tvProgressSpeed.text = ""
        }
    }

    private fun updateProgress(percent: Int, transferred: Long, total: Long, speedMBps: Double) {
        binding.progressTransfer.progress = percent
        binding.tvProgressPercent.text = "$percent%"
        binding.tvProgressTransferred.text = "${formatSize(transferred)} / ${formatSize(total)}"
        binding.tvProgressSpeed.text = "${String.format("%.1f", speedMBps)} MB/s"
    }

    private fun getFileInfo(uri: Uri): Pair<String, Long> {
        var name = "unknown_file"
        var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx)
            }
        }
        return Pair(name, size)
    }

    private fun getUniqueFileName(dir: File, name: String): String {
        var result = name
        var counter = 1
        while (File(dir, result).exists()) {
            val dot = name.lastIndexOf('.')
            result = if (dot > 0) {
                "${name.substring(0, dot)}($counter)${name.substring(dot)}"
            } else {
                "$name($counter)"
            }
            counter++
        }
        return result
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val df = DecimalFormat("#,##0.#")
        return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
