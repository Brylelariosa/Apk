# HexManiac for Android

Android port of HexManiacAdvance (the GBA ROM hex, table, script, map and image editor), version 0.7.0.
One universal APK: no native code, no ABI or density splits, no AndroidX. All sources are ASCII only.

Build it with the "Build APK" GitHub Actions workflow: zip this folder, push the zip to `uploads/`, download the APK
artifact. Locally: `./gradlew assembleDebug` (or `assembleRelease`). The engine tests run on any JVM:
`./gradlew :core:test`.

## How it is built

- `core` is the engine: a pure JVM Kotlin module without Android classes. It is a member-by-member translation of the C#
  code of HexManiacAdvance: the ROM model and its runs (pointers, tables, text, sprites, palettes, tilemaps, maps, scripts),
  the table-format and metadata language, the text codec, the patcher, the script and Thumb parsers, the view models of
  every tab and tool, the map editor, the image editor and the quick edits (about 185 files and 6200 members). The xunit
  tests of the original were translated to JUnit (1473 tests in `core/src/test`).
- `app` is the Android UI (about 10,000 lines): programmatic views, no layout XML, drawn after the WPF layout and theme of
  the original (angled buttons, the same colors, the same panels). It binds the engine's view models to Android views.
- Threading: the engine's view models were written for one UI thread, so on Android a dedicated engine thread plays that
  role. The Android UI thread only reads view-model state under a lock and posts every change to the engine thread, so
  dialogs and file pickers that the engine waits for never block the screen.

## What is in the app

- Shell: tab strip (new, close, duplicate, diff with the left or right neighbour), start screen with recent files, toolbar,
  the full menu as an accordion sheet (File, Edit, View, Developer, Utilities, Tools, Help), find bar, goto bar, hex
  converter, message and error bars, the automation panel, tutorials, and the theme editor (hue, saturation, brightness and
  every color). Open files through the system file picker or from a file manager (`.gba`).
- Hex tab: the data is drawn on a canvas with the formats of the engine (pointers, text, tables, sprites, palettes, scripts,
  ...), the current row and the selection highlighted. Tap selects, double-tap follows a pointer, dragging scrolls (with
  fling) and the right edge is a fast scroll bar. Long-press and then drag extends the selection; long-press and
  release opens the context menu (the right-click menu of the original). Typing works with the system keyboard or the
  built-in hex keypad, with autocomplete. Pinch zooms.
- Tool panels of the hex tab: Table tool (every field type: numbers, enums with search, flags, bit lists, tuples, text
  streams, sprites, palettes, trainer teams, maps options, buttons, calculated values), Text tool, Image tool (sprites,
  palettes, import and export of indexed PNG files), Code tool (event scripts, battle and animation scripts, Thumb) and
  the Logs.
- Map editor tab: map canvas with draw, rectangle, fill, pan and select modes (one finger acts by mode, two fingers pan
  and pinch-zoom), block picker, event creation (object, warp, script, signpost, fly), event forms, map header with its
  scripts and connections, tile and block editors, border editor, wild Pokemon, object templates, data operations
  (repoint, expand, import, export), export image. Wide screens show the panels next to the map.
- Image editor tab: pan, select, draw, fill, pick and tile palette tools, palette editing, import and export.
- Pokedex reorder tab: reorder the Pokedex with the sprites on screen, pinch to resize them.
- Quick edits: all of the original (expand the ROM, make items, moves, TMs, tutors and Pokemon expandable, decap names,
  update dex, tileset animations, level-up move sorter, ...).
- Files use the Android storage access framework; the metadata (`.toml`) of a ROM and the settings live in app-private
  storage. Undo and redo, save, save as, save all and export backup follow the original. IPS and UPS patches are applied
  by opening them and created from the tab menu.

## Limitations (please read)

- This version was compiled against the Android 34 API and its engine is tested on the JVM (1473 tests), but the app has
  not been run on a device or emulator by its author. Expect rough edges in the touch handling and layouts; they are the
  first thing to check.
- The original embeds IronPython. That cannot run on Android, so the Python tool is an inert stub (the engine has a
  `scriptRunner` hook where a Python host could be plugged in).
- The Complete FireRed Upgrade patch of the "Apply HUBOL DPE CFRU" quick edit is 17 MB and is not bundled. The quick edit
  asks you to pick `hubol_dpe_cfru.ups` (it is in the `resources` folder of HexManiacAdvance).
- Not ported: the integration tests of the original (they need real ROMs), PythonTests, SearchTreeTests and BrailleTests,
  and the desktop-only parts of the shell (several windows, drag and drop, the Windows updater). Mouse hover tooltips are
  reached with long-press instead. Keyboard shortcuts work with a hardware keyboard.

## APK size

- R8 shrinking, optimization and obfuscation plus resource shrinking, in the debug build as well as the release build.
  Debug keeps names (`-dontobfuscate`).
- No AndroidX or AppCompat: the app uses the framework `Activity`, programmatic views and one vector drawable. The only
  libraries are the Kotlin standard library (shrunk by R8) and the `core` module.
- The data files inside the engine jar are exactly the ones named in `core/src/main/resources/hma/index.txt`; the rest of
  that folder is reference data the app does not read yet. List a file in the index when the feature that needs it lands.

## Project layout

- `core/src/main/kotlin/dev/hexmaniac/core` - the engine (`models`, `viewmodels`, `system`, ...)
- `core/src/main/resources/hma` - reference data of HexManiacAdvance (character sets, table and metadata definitions, ...)
- `core/src/test` - the translated unit tests and their data files
- `app/src/main/kotlin/dev/hexmaniac/android/host` - engine thread, storage access, PNG codec, dialogs host
- `app/src/main/kotlin/dev/hexmaniac/android/ui` - screens: shell, hex view, tool panels, map editor, image editor, dex reorder

See `NOTICE.md` for the license of HexManiacAdvance, from which the engine and its data are derived.
