@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ViewPortCursorTests {
      private fun NewViewPort(file: LoadedFile): ViewPort = ViewPort(file).also { it.allowMultipleElementsPerLine = true; it.width = 5; it.height = 5 }
      @Test fun CursorCanMoveAllFourDirections() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }
         viewPort.selectionStart  = Point(3, 0)

         viewPort.moveSelectionStart.execute(Direction.Right)
         viewPort.moveSelectionStart.execute(Direction.Down)
         viewPort.moveSelectionStart.execute(Direction.Left)
         viewPort.moveSelectionStart.execute(Direction.Up)

         Assert.equal(Point(3, 0), viewPort.selectionStart)
      }
      @Test fun CursorCannotMoveAboveTopRow() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }
         viewPort.selectionStart  = Point(3, 0)

         viewPort.moveSelectionStart.execute(Direction.Up)

         Assert.equal(Point(0, 0), viewPort.selectionStart) // coerced to first byte
      }
      @Test fun MovingCursorRightFromRightEdgeMovesToNextLine() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }
         viewPort.selectionStart  = Point(4, 0)

         viewPort.moveSelectionStart.execute(Direction.Right)

         Assert.equal(Point(0, 1), viewPort.selectionStart)
      }
      @Test fun MovingCursorDownFromBottomRowScrolls() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 4 }
         viewPort.selectionStart  = Point(0, 3)

         viewPort.moveSelectionStart.execute(Direction.Down)

         Assert.equal(1, viewPort.scrollValue)
      }
      @Test fun CursorCanMoveOutsideDataRangeButNotOutsideScrollRange() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }
         viewPort.scroll.execute(Direction.Right)
         viewPort.selectionStart  = Point(0, 0)

         viewPort.moveSelectionStart.execute(Direction.Up)
         viewPort.moveSelectionStart.execute(Direction.Up)

         Assert.equal(Point(4, 0), viewPort.selectionStart)
         Assert.equal(0, viewPort.scrollValue)

         viewPort.selectionStart  = Point(4, 4)
         viewPort.moveSelectionStart.execute(Direction.Down)
         viewPort.moveSelectionStart.execute(Direction.Down)

         Assert.equal(Point(4, 4), viewPort.selectionStart)
         Assert.equal(1, viewPort.scrollValue) // I can scroll lower using Scroll.Execute, but I cannot select lower.
      }
      @Test fun MoveSelectionEndWorks() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }
         viewPort.selectionStart  = Point(0, 0)

         viewPort.moveSelectionStart.execute(Direction.Right)
         viewPort.moveSelectionEnd.execute(Direction.Down)

         Assert.equal(Point(1, 1), viewPort.selectionEnd)
      }
      @Test fun SetSelectionStartResetsSelectionEnd() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }
         viewPort.selectionStart  = Point(0, 0)

         viewPort.selectionEnd  = Point(3, 3)
         viewPort.selectionStart  = Point(1, 0)

         Assert.equal(Point(1, 0), viewPort.selectionEnd)
      }
      @Test fun ScrollingUpdatesSelection() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = NewViewPort(loadedFile)

         viewPort.selectionStart  = Point(0, 2)
         viewPort.selectionEnd  = Point(4, 2)
         viewPort.scroll.execute(Direction.Down)

         Assert.equal(Point(0, 1), viewPort.selectionStart)
         Assert.equal(Point(4, 1), viewPort.selectionEnd)
      }
      @Test fun ForwardSelectionWorks() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = NewViewPort(loadedFile)

         viewPort.selectionStart  = Point(2, 1)
         viewPort.selectionEnd  = Point(3, 3)

         Assert.isTrue(viewPort.isSelected(Point(4, 2)))
      }
      @Test fun BackSelectionWorks() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = NewViewPort(loadedFile)

         viewPort.selectionStart  = Point(3, 3)
         viewPort.selectionEnd  = Point(2, 1)

         Assert.isTrue(viewPort.isSelected(Point(4, 2)))
      }
      @Test fun ScrollingBeforeStartOfDataMovesSelectionOnlyWhenDataMoves() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }

         viewPort.scroll.execute(Direction.Right); // move the first byte out of view
         viewPort.scroll.execute(Direction.Up);    // scroll up, so we can see the first byte again

         // Example of what it should look like right now:
         // .. .. .. 00 <- this is the top line in the view
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00

         viewPort.scroll.execute(Direction.Left); // try to scroll further. Should fail, because then the whole top row would be empty.
         Assert.equal(Point(4, 0), viewPort.selectionStart) // first byte of data should still be selected.
      }
      @Test fun ChangingWidthKeepsSameDataSelected() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }
         viewPort.selectionEnd  = Point(2, 2); // 13 cells selected
         viewPort.width  += 1

         Assert.equal(Point(0, 2), viewPort.selectionEnd) // 13 cells selected
      }
      @Test fun CannotSelectBeforeFirstByte() {
         var loadedFile = LoadedFile("test", ByteArray(30))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }

         // view the cell left of the first byte
         viewPort.scroll.execute(Direction.Left)

         // try to select the cell left of the first byte
         viewPort.moveSelectionStart.execute(Direction.Left)

         // assert that the selection is still on the first byte, not the first cell
         Assert.equal(Point(1, 0), viewPort.selectionStart)
      }
      @Test fun CannotSelectFarAfterLastByte() {
         var loadedFile = LoadedFile("test", ByteArray(20))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }

         viewPort.selectionStart  = Point(4, 4)

         Assert.equal(Point(0, 4), viewPort.selectionStart)
      }
      @Test fun MovingSelectionInAnUnsizedPanelAutoSizesThePanel() {
         var viewPort = ViewPort()

         viewPort.selectionStart  = Point(4, 4)

         Assert.notEqual(0, viewPort.width)
         Assert.notEqual(0, viewPort.height)
      }
      @Test fun CannotMoveSelectEndFarPassedEndOfFile() {
         var selection = Selection(ScrollRegion().also { it.dataLength = 8 }, BasicModel(ByteArray(8)), ChangeHistory<ModelDelta>({ it }))

         selection.selectionEnd  = Point(3, 3)

         Assert.equal(Point(0, 2), selection.selectionEnd)
      }
      @Test fun CanExpandSelection() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.edit("FF @00 ^word\"\" \"bob\"")
         viewPort.value.selectionStart  = Point(1, 0)
         viewPort.value.expandSelection(1, 0)

         Assert.isTrue(viewPort.value.isSelected(Point(0, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(1, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(2, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(3, 0)))
         Assert.isFalse(viewPort.value.isSelected(Point(4, 0)))
      }
      fun SelectingAnyOfAPointerSelectsAllOfAPointer(index: Int) {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(index, 0)

         Assert.isTrue(viewPort.value.isSelected(Point(0, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(1, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(2, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(3, 0)))
      }
    @Test fun SelectingAnyOfAPointerSelectsAllOfAPointer_1() { SelectingAnyOfAPointerSelectsAllOfAPointer(0) }
    @Test fun SelectingAnyOfAPointerSelectsAllOfAPointer_2() { SelectingAnyOfAPointerSelectsAllOfAPointer(1) }
    @Test fun SelectingAnyOfAPointerSelectsAllOfAPointer_3() { SelectingAnyOfAPointerSelectsAllOfAPointer(2) }
    @Test fun SelectingAnyOfAPointerSelectsAllOfAPointer_4() { SelectingAnyOfAPointerSelectsAllOfAPointer(3) }
      @Test fun SelectLeftSelectsWholePointer() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(4, 0)
         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(8, 0)
         viewPort.value.moveSelectionStart.execute(Direction.Left)

         Assert.isTrue(viewPort.value.isSelected(Point(4, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(5, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(6, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(7, 0)))
      }
      @Test fun SelectRightSelectsWholePointer() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(4, 0)
         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(3, 0)
         viewPort.value.moveSelectionStart.execute(Direction.Right)

         Assert.isTrue(viewPort.value.isSelected(Point(4, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(5, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(6, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(7, 0)))
      }
      @Test fun SelectUpSelectsWholePointer() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(4, 0)
         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(5, 1)
         viewPort.value.moveSelectionStart.execute(Direction.Up)

         Assert.isTrue(viewPort.value.isSelected(Point(4, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(5, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(6, 0)))
         Assert.isTrue(viewPort.value.isSelected(Point(7, 0)))
      }
      @Test fun SelectDownSelectsWholePointer() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(4, 1)
         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(5, 0)
         viewPort.value.moveSelectionStart.execute(Direction.Down)

         Assert.isTrue(viewPort.value.isSelected(Point(4, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(5, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(6, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(7, 1)))
      }
      @Test fun HighlightLeftSelectsWholePointer() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(4, 1)
         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(6, 1)
         viewPort.value.selectionEnd  = Point(2, 1)

         Assert.isTrue(viewPort.value.isSelected(Point(4, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(5, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(6, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(7, 1)))
      }
      @Test fun HighlightRightSelectsWholePointer() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(4, 1)
         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(6, 1)
         viewPort.value.selectionEnd  = Point(10, 1)

         Assert.isTrue(viewPort.value.isSelected(Point(4, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(5, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(6, 1)))
         Assert.isTrue(viewPort.value.isSelected(Point(7, 1)))
      }
      @Test fun ContextMenuContainsCopyPaste() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)

         viewPort.value.selectionStart  = Point(2, 2)
         viewPort.value.selectionEnd  = Point(5, 2)
         var items = viewPort.value.getContextMenuItems(viewPort.value.selectionStart)
         items.single({ item -> item.text == "Copy" })
         items.single({ item -> item.text == "Paste" })

         viewPort.value.edit("<000100>")
         viewPort.value.selectionStart  = Point(3, 2)
         items  = viewPort.value.getContextMenuItems(viewPort.value.selectionStart)
         items.single({ item -> item.text == "Copy" })
         items.single({ item -> item.text == "Paste" })

         viewPort.value.clearAnchor()
         viewPort.value.model.writeMultiByteValue(0x22, 4, ModelDelta(), 0x000000FF)
         viewPort.value.edit("^text\"\" Hello World!\"")
         viewPort.value.selectionStart  = Point(5, 2)
         viewPort.value.expandSelection(5, 2)
         items  = viewPort.value.getContextMenuItems(viewPort.value.selectionStart)
         items.single({ item -> item.text == "Copy" })
         items.single({ item -> item.text == "Paste" })
      }
      @Test fun CanForkData() {
         val viewPort = Ref<ViewPort>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val data = Ref<ByteArray>(nullOf())
         CreateStandardTestSetup(viewPort, model, data)
         viewPort.value.edit("<000008> <000008> FF @08 ^text\"\" Test\" @00")
         viewPort.value.selectionStart  = Point()
         var items = viewPort.value.getContextMenuItems(Point())

         var group = (items.single({ menuItem -> menuItem.text == "Pointer Operations" }) as ContextItemGroup)
         group.single({ item -> item.text!!.startsWith("Repoint") }).command.execute()

         Assert.notEqual(0x08, model.value.readPointer(0))
         var originalRun = (model.value.getNextRun(8) as PCSRun)
         var newRun = ((model.value.getNextRun(model.value.readPointer(0))) as PCSRun)
         Assert.equal(originalRun.serializeRun(), newRun.serializeRun())
      }
      @Test fun AnchorWithData_SelectMiddleOfAnchor_CanSeeAnchorContents() {
         var test = BaseViewModelTestClass()
         test.SetFullModel(0xFF)

         test.ViewPort.edit("^text\"\" \"Hello, World\"")
         test.ViewPort.goto!!.execute(5)

         Assert.isTrue(test.ViewPort.anchorTextVisible)
         Assert.equal("^text\"\"", test.ViewPort.anchorText)
      }
      @Test fun SelectDataInBottomRow_MoveSelectionEndDown_DataScrolls() {
         var test = BaseViewModelTestClass()

         test.ViewPort.selectionStart  = Point(0, 15)
         test.ViewPort.selectionEnd  = Point(0, 16)

         Assert.equal(0x10, test.ViewPort.dataOffset)
      }
      @Test fun SelectDataInTopRow_MoveSelectionEndUp_DataScrolls() {
         var test = BaseViewModelTestClass()
         test.ViewPort.goto!!.execute(0x10)

         test.ViewPort.selectionStart  = Point(0, 0)
         test.ViewPort.selectionEnd  = Point(0, -1)

         Assert.equal(0, test.ViewPort.dataOffset)
      }
      @Test fun CursorAtEndOfFile_MakeFileSmaller_CursorMoves() {
         var test = BaseViewModelTestClass()
         test.ViewPort.goto!!.execute(test.Model.count - 1)

         test.Model.contractData(test.Token, 0x100)
         test.ViewPort.refresh()

         Assert.equal(0x101, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionStart))
      }
      @Test fun SelectByte_SetSelectionLength_SelectMoreBytes() {
         var test = BaseViewModelTestClass()

         test.ViewPort.selectedAddress  = "000100"
         test.ViewPort.selectedLength  = "3"

         Assert.equal(0x000100, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionStart))
         Assert.equal(0x000102, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionEnd))
      }
      @Test fun SelectLeft_SetSelectionLength_ChangeSelectionEndToSelectionStart() {
         var test = BaseViewModelTestClass()

         test.ViewPort.selectionStart  = newOf(2, 0)
         test.ViewPort.selectionEnd  = newOf(1, 0)
         test.ViewPort.selectedLength  = "3"

         Assert.equal(1, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionStart))
         Assert.equal(3, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionEnd))
      }

      private fun CreateStandardTestSetup(viewPort: Ref<ViewPort>, model: Ref<PokemonModel>, data: Ref<ByteArray>) {
         data.value  = ByteArray(0x200)
         model.value  = PokemonModel(data.value)
         viewPort.value  = AutoSearchTests.newViewPort("file.txt", model.value)
         viewPort.value.width  = 0x10
         viewPort.value.height  = 0x10
      }
   }
