@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ImageTests : BaseViewModelTestClass() {
      @Test fun ValidHeaderIsRecognized() {
         var data = bytes( 0x10, 8, 0, 0, 0x0, 0, 0, 0, 0, 0, 0, 0, 0)
         Assert.notEqual(-1, LZRun.isCompressedLzData(data.asByteList(), 0))
      } // compressed bytes cannot start further back than the start of the stream
      fun InvalidHeaderIsInvalid(data: ByteArray) {
         Assert.equal(-1, LZRun.isCompressedLzData(data.asByteList(), 0))
      }
    @Test fun InvalidHeaderIsInvalid_1() { InvalidHeaderIsInvalid(bytes( 0x00, 8, 0, 0, 0x0, 0, 0, 0, 0, 0, 0, 0, 0)) }
    @Test fun InvalidHeaderIsInvalid_2() { InvalidHeaderIsInvalid(bytes( 0x10, 8, 1, 0, 0x0, 0, 0, 0, 0, 0, 0, 0, 0)) }
    @Test fun InvalidHeaderIsInvalid_3() { InvalidHeaderIsInvalid(bytes( 0x10, 6, 0, 0, 0x1, 0, 0, 0, 0, 0, 0, 0, 0)) }
    @Test fun InvalidHeaderIsInvalid_4() { InvalidHeaderIsInvalid(bytes( 0x10, 7, 0, 0, 0x80, 0, 0, 0, 0, 0, 0, 0, 0)) }
    @Test fun InvalidHeaderIsInvalid_5() { InvalidHeaderIsInvalid(bytes( 0x10, 7, 0, 0, 0x40, 0, 0, 4, 0, 0, 0, 0, 0)) }
      fun Decompress(compressed: ByteArray, uncompressed: ByteArray) {
         var result = LZRun.decompress(compressed.asByteList(), 0)
         Assert.equal(uncompressed, result)
      }
    @Test fun Decompress_1() { Decompress(
         bytes( 0x10, 8, 0, 0, 0x0, 0, 0, 0, 0, 0, 0, 0, 0),
         bytes( 0, 0, 0, 0, 0, 0, 0, 0)) }
      @Test fun RunHasExpectedLength() {
         var data = bytes( 0x10, 8, 0, 0, 0x0, 0, 0, 0, 0, 0, 0, 0, 0)
         var model = PokemonModel(data)
         var run = LZRun(model, 0)
         Assert.equal(13, run.length)
      }
      @Test fun RunHasExpectedDataFormats() {
         var data = bytes(
            0x10, 4, 0, 0, // header
            0x40,    // group
            0x30,          // uncompressed 30
            0x00, 0x00,); // biases should make the compressed token length 3, offset 1 (3:1)
         for (i in 0 until data.size) Model[i]  = data[i].u8()
         var run = LZRun(Model, 0)

         (ModelCacheScope.createScope(Model)).use { _ ->
            Assert.isType<LzMagicIdentifier>(run.createDataFormat(Model, 0))
            Assert.isType<Integer>(run.createDataFormat(Model, 1))
            Assert.isType<Integer>(run.createDataFormat(Model, 2))
            Assert.isType<Integer>(run.createDataFormat(Model, 3))
            Assert.isType<LzGroupHeader>(run.createDataFormat(Model, 4))
            Assert.isType<LzUncompressed>(run.createDataFormat(Model, 5))
            Assert.isType<LzCompressed>(run.createDataFormat(Model, 6))
            Assert.isType<LzCompressed>(run.createDataFormat(Model, 7))
          }
      }
      @Test fun EditUncompressedCellMovesCursorByOne() {
         var compressed = LZRun.compress(bytes( 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0).asByteList(), 0, 16).toTypedArray()
         arrayCopy(compressed, Model.rawData, compressed.size)
         Model.observeRunWritten(ModelDelta(), LZRun(Model, 0))
         ViewPort.refresh()

         ViewPort.selectionStart  = Point(5, 0)
         ViewPort.edit("00 ")

         Assert.equal(Point(6, 0), ViewPort.selectionStart)
      }
      @Test fun ExtendCompressedLzTokenShortensLzRun() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 13, 0, 0, // header
            0x70,    // group
            0x30,          // uncompressed 30
            0x00, 0x00,    // compressed   3:1    (we're going to make this one longer)
            0x20, 0x00,    // compressed   5:1    (this one will end up shorter)
            0x00, 0x00,    // compressed   3:1    (this one should go away, which means the group header needs to be changed)
            0x30)

         // make the actual edit
         ViewPort.edit("@07 8:1 "); // after this run we expect 2 more compressed runs but have only 4 more bytes
         // edit should fail

         Assert.single(Errors)

         // make the actual edit
         ViewPort.edit("@07 6:1 "); // after this run we expect 2 more compressed runs, so they should both be length 3

         // check that compressed segment is 6:1
         Assert.equal(0x30, Model[6])
         Assert.equal(0x00, Model[7])

         // check that compressed segment is 3:1
         Assert.equal(0x00, Model[8])
         Assert.equal(0x00, Model[9])

         // check that compressed segment is 3:1
         Assert.equal(0x00, Model[10])
         Assert.equal(0x00, Model[11])

         // check that the final uncompressed segment is gone
         Assert.equal(0xFF, Model[12])
      }
      @Test fun ExtendLastCompressedTokenBeyondLengthErrors() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 4, 0, 0, // header (uncompressed length = 4)
            0x40,     // group
            0x30,           // uncompressed 30
            0x00, 0x00);    // compressed   3:1

         ViewPort.edit("@06 4:1 "); // too long! You said you only want 3 more bytes, but this is 4 bytes!

         Assert.single(Errors)
      }
      @Test fun ContractCompressedLzTokenLengthensAndRepoints() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 6, 0, 0, // header (uncompressed length = 6)
            0x40,     // group
            0x30,           // uncompressed 30
            0x20, 0x00);    // compressed   5:1
         Model[8]  = 0xBA;   // random byte that we don't want to overwrite

         ViewPort.edit("@00 ^bob @06 4:1 "); // too short! We need 1 more byte at the end!

         var address = Model.getAddressFromAnchor(ViewPort.currentChange, -1, "bob")
         var run = (Model.getNextRun(address) as LZRun)

         Assert.equal(9, run.length)
         Assert.single(Messages) // message about the repoint
      }
      @Test fun CanTypeLZOverHeader() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 6, 0, 0, // header (uncompressed length = 6)
            0x40,     // group
            0x30,           // uncompressed 30
            0x20, 0x00);    // compressed   5:1

         ViewPort.edit("@20 @00 lz "); // too short! We need 1 more byte at the end!

         Assert.equal(Point(1, 0), ViewPort.selectionStart)
         Assert.equal(Point(3, 0), ViewPort.selectionEnd)
      }
      @Test fun CanEditDecompressedLengthInCompressedData() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 6, 0, 0, // header (uncompressed length = 6)
            0x40,     // group
            0x30,           // uncompressed 30
            0x20, 0x00);    // compressed   5:1

         ViewPort.edit("@01 8 "); // overall data should be longer now

         Assert.equal(8, LZRun.decompress(Model, 0)!!.size)
      }
      @Test fun CanEditLzGroupHeaderBitfield() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 6, 0, 0, // header (uncompressed length = 6)
            0x40,     // group
            0x30,           // uncompressed 30
            0x20, 0x00);    // compressed   5:1

         ViewPort.edit("@04 00 "); // override bitfield to be 'none compressed'
         // there were 3 bytes after the group header, so an additional 3 bytes are needed to make the uncompressed data length 6

         Assert.equal(4 + 1 + 3 + 3, Model.getNextRun(0).length); // header, group header, 3 uncompressed bytes, auto-fill with 3 more uncompressed bytes to match the existing group header
         Assert.equal(0x00, Model[4]); // the 'none compressed' write was respected

         ViewPort.edit("@04 10 "); // address 8-9 are now read as a compressed pair (0000=3:1) which gets us exactly to our expected length.

         Assert.equal(4 + 1 + 3 + 2, Model.getNextRun(0).length); // header, group header, 3 uncompressed bytes, then 2 compressed bytes
         Assert.equal(0x10, Model[4])
      }
      @Test fun CanEditLzDataViaStreamTool() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 8, 0, 0, // header (uncompressed length = 8)
            0x40,     // group
            0x30,           // uncompressed 30
            0x40, 0x00);    // compressed   7:1

         ViewPort.edit("@04 ")
         Assert.equal("30 30 30 30 30 30 30 30", ViewPort.tools!!.stringTool!!.content)

         ViewPort.tools!!.stringTool!!.content  = "30 20 30 30 30 30 30 30"; // should result in 30 20 30 30 (4:2)

         var run = Model.getNextRun(0)
         Assert.equal(0x8, Model[4])
         Assert.equal(0x30, Model[5])
         Assert.equal(0x20, Model[6])
         Assert.equal(0x30, Model[7])
         Assert.equal(0x30, Model[8])
         Assert.equal(0x10, Model[9])
         Assert.equal(0x01, Model[10])
         Assert.equal(11, run.length)
         Assert.isAssignableFrom<IStreamRun>(run)
      }
      @Test fun CanSelectWholeCompressedRun() {
         SetFullModel(0xFF)
         CreateLzRun(0,
            0x10, 6, 0, 0, // header (uncompressed length = 6)
            0x40,     // group
            0x30,           // uncompressed 30
            0x20, 0x00);    // compressed   5:1

         ViewPort.expandSelection(0, 0)

         Assert.isTrue(ViewPort.isSelected(Point(7, 0)))
      }
      @Test fun ImageToolExists() {
         Model.observeRunWritten(ViewPort.currentChange, SpriteRun(Model, 0x10, SpriteFormat(4, 2, 2, null)))
         Model.observeRunWritten(ViewPort.currentChange, PaletteRun(0x100, PaletteFormat(4, 1)))
         ViewPort.selectionStart  = Point(2, 2)
         var tools = ViewPort.tools

         Assert.equal(tools!!.indexOf(tools!!.spriteTool), tools!!.selectedIndex)
         Assert.equal(0x10, tools!!.spriteTool!!.spriteAddress)
         Assert.equal(Pointer.null_, tools!!.spriteTool!!.paletteAddress)
         Assert.isFalse(tools!!.spriteTool!!.previousSpritePage.canExecute(null))
         Assert.isFalse(tools!!.spriteTool!!.nextSpritePage.canExecute(null))
         Assert.isFalse(tools!!.spriteTool!!.previousPalettePage.canExecute(null))
         Assert.isFalse(tools!!.spriteTool!!.nextPalettePage.canExecute(null))
      }
      @Test fun CanAddUncompressedImageRunsFromViewPort() {
         ViewPort.edit("^sprite`ucs4x2x2`")
         var run = Model.getNextRun(0)
         Assert.equal(32 * 2 * 2, run.length)
         Assert.isAssignableFrom<ISpriteRun>(run)

         ViewPort.edit("@100 ^pal`ucp4`")
         run  = Model.getNextRun(0x100)
         Assert.equal(32, run.length)
         Assert.isAssignableFrom<IPaletteRun>(run)
      }
      @Test fun CanCopyCompressedSprite() {
         ViewPort.edit("10 20 @00 ^run`lzs4x1x1`")
         var fileSystem = StubFileSystem()
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fileSystem)
         Assert.contains("^run`lzs4x1x1` lz 32 00 ", fileSystem.copyText)
      }
      @Test fun CanCopyCompressedPalette() {
         ViewPort.edit("10 20 @00 ^run`lzp4`")
         var fileSystem = StubFileSystem()
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fileSystem)
         Assert.contains("^run`lzp4` lz 32 00 ", fileSystem.copyText)
      }
      @Test fun CanCopyUncompressedSprite() {
         ViewPort.edit("^run`ucs4x1x1`")
         var fileSystem = StubFileSystem()
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fileSystem)
         var emptyBlock = " ".join(32.range().map({ i -> "00" }))
         Assert.startsWith("^run`ucs4x1x1` ${emptyBlock}", fileSystem.copyText)
      }
      @Test fun CanCopyUncompressedPalette() {
         ViewPort.edit("^run`ucp4`")
         var fileSystem = StubFileSystem()
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fileSystem)
         Assert.startsWith("^run`ucp4` 0:0:0 ", fileSystem.copyText)
      }
      @Test fun CanAddLzTilesetAndTilemapFromViewPort() {
         Model.expandData(ViewPort.currentChange, 0x400)
         ViewPort.refresh()

         // Arrange tileset data
         var tileByteLength = 8 * 8 / 2
         var tileCount = 11
         var lzData = LZRun.compress(ByteArray(tileByteLength * tileCount).asByteList(), 0, tileByteLength * tileCount)
         for (i in 0 until lzData.count) Model[0x20 + i]  = lzData[i]

         // Act: add tileset run
         ViewPort.edit("<20> @20 ^tileset`lzt4`"); // 4 bits per pixel

         // Assert: tilesets show up as ISpriteRuns for the image tool
         var run = Model.getNextRun(0x20) as ISpriteRun

         // Assert: tilesets have 1 page
         Assert.equal(1, run.pages)

         // Assert: tilesets figure out dimensions dynamically.
         // They attempt to show in a square if possible,
         //   then add extra needed full columns,
         //   then add extra single tiles in a bottom row.
         Assert.equal(4, run.spriteFormat.tileWidth)
         Assert.equal(3, run.spriteFormat.tileHeight)


         // Arrange tilemap data
         lzData  = LZRun.compress(ByteArray(2 * 16).asByteList(), 0, 2 * 16)
         for (i in 0 until lzData.count) Model[0x200 + i]  = lzData[i]

         // Act: add tilemap run
         ViewPort.edit("@10 <200> @0200 ^tilemap`lzm4x4x4|tileset`"); // 4 bits per pixel, 4 tiles wide, 4 tiles tall.

         // Assert: tilemaps show up as ISpriteRun for the image tool
         run  = Model.getNextRun(0x200) as ISpriteRun

         // Assert: tilemaps have 1 page
         Assert.equal(1, run.pages)

         // Assert: tilemaps have the specified dimensions.
         Assert.equal(4, run.spriteFormat.tileWidth)
         Assert.equal(4, run.spriteFormat.tileHeight)
      }
      @Test fun DoNotRenameAnchorWhenCreatingAPaletteAutomatically() {
         ViewPort.edit("^bob @20 ^tom @bob ")
         var items = ViewPort.getContextMenuItems(Point(0, 0))
         var item = items.single({ element -> element.text == "Display As..." })
         item  = ((item as ContextItemGroup)).single({ element -> element.text == "Color Palette" })
         item.command.execute()

         var anchor = Model.getAnchorFromAddress(-1, 0)
         Assert.equal("bob", anchor)
      }
      @Test fun LoosePaletteCanFindSpriteThatUsesIt() {
         // setup an lz run header at 0x80
         Model[0x80]  = 0x10
         Model[0x81]  = 32

         ViewPort.edit("@00 ^pal`ucp4`")
         ViewPort.edit("@40 ^sprite`ucs4x1x1|pal`")
         ViewPort.edit("@80 ^tiles`lzt4|pal`")

         var run = (Model.getNextRun(0x00) as IPaletteRun)
         var sprites: List<ISpriteRun> = run.findDependentSprites(Model)

         sprites  = sprites.sortedBy({ sprite -> sprite.start }).toMutableList()
         Assert.equal(0x40, sprites[0].start)
         Assert.equal(0x80, sprites[1].start)
      }
      @Test fun TablePaletteCanFindSpritesThatUseIt() {
         CreateTextTable("names", 0, "Adam", "Bob")
         ViewPort.edit("@10 <0020> <0040> @10 ^sprites[pointer<`ucs4x1x1`>]names "); // note that the sprite doesn't reference the palette by name.
         ViewPort.edit("@60 <0070> <0090> @60 ^palettes[pointer<`ucp4`>]names ");    // the palette should pick it up by index

         var run = (Model.getNextRun(0x70) as IPaletteRun)
         var sprite1 = run.findDependentSprites(Model).single()
         Assert.equal(0x20, sprite1.start)

         run  = (Model.getNextRun(0x90) as IPaletteRun)
         var sprite2 = run.findDependentSprites(Model).single()
         Assert.equal(0x40, sprite2.start)
      }
      @Test fun IndexPaletteCanFindSpritesThatUseIt() {
         CreateTextTable("names", 0, "Adam", "Bob")
         ViewPort.edit("@10 <0020> <0040> @10 ^palettes[pointer<`ucp4`>]2 ")
         ViewPort.edit("@60 ^palindex[id:palettes]names 1 0 ")
         ViewPort.edit("@70 <0080> <00A0> @70 ^sprites[pointer<`ucs4x1x1|palindex`>]names ")

         var run = (Model.getNextRun(0x20) as IPaletteRun); // palette 0, used by Bob
         var sprite = run.findDependentSprites(Model).single()
         Assert.equal(0xA0, sprite.start)
      }
      @Test fun CanFindPalettesForSpriteInTable() {
         CreateTextTable("names", 0, "Adam", "Bob")
         ViewPort.edit("@10 <0020> <0040> @10 ^sprites[pointer<`ucs4x1x1`>]names "); // note that the sprite doesn't reference the palette by name.
         ViewPort.edit("@60 <0070> <0090> @60 ^palettes[pointer<`ucp4`>]names ");    // the palette should pick it up by index

         var run = (Model.getNextRun(0x20) as ISpriteRun)
         var palette = run.findRelatedPalettes(Model).single()

         Assert.equal(0x70, palette.start)
      }
      @Test fun CanFindPalettesForSpriteOutsideTable() {
         ViewPort.edit("@00 ^pal`ucp4`")
         ViewPort.edit("@40 ^sprite`ucs4x1x1|pal`")

         var run = (Model.getNextRun(0x40) as ISpriteRun)
         var palette = run.findRelatedPalettes(Model).single()

         Assert.equal(0x0, palette.start)
      }
      @Test fun CanReplaceTilemapWithSprite() {
         ViewPort.edit("@00 10 20 00 00 @00 ^data`lzm4x4x4`")
         ViewPort.refresh()

         ViewPort.tools!!.spriteTool!!.spriteIsTilemap  = false

         Assert.isType<LzSpriteRun>(Model.getNextRun(0))
      }
      @Test fun UncompressedImagesFormatIncludesPaletteHint() {
         ViewPort.edit("^data`ucs4x4x4|pal`")
         Assert.equal("`ucs4x4x4|pal`", Model.getNextRun(0).formatString)
      }
      @Test fun EditPaletteUpdatesMatchingSprites() {
         ViewPort.edit("01 @00 ^sprite`ucs4x1x1|pal`")
         ViewPort.edit("@80 <pal> @20 ^pal`ucp4`")
         ViewPort.refresh()

         ViewPort.tools!!.spriteTool!!.colors.handleMove(0, 1)
         ViewPort.tools!!.spriteTool!!.colors.completeCurrentInteraction()

         Assert.equal(0x10, Model[0]); // 01 changes to 10
         Assert.equal(0x11, Model[1]) // 00 changes to 11
      }
      @Test fun CanCreateGradientForSelectedColors() {
         ViewPort.edit("@80 <palette> @00 ^palette`ucp4` 0:0:0 0:0:0 30:30:30 ")

         ViewPort.tools!!.spriteTool!!.colors.selectionStart  = 0
         ViewPort.tools!!.spriteTool!!.colors.selectionEnd  = 2
         ViewPort.tools!!.spriteTool!!.colors.createGradient.execute()

         var color = ((ViewPort[2, 0].format) as UncompressedPaletteColor)
         Assert.equal("12:12:12", color.toString())
      }
      @Test fun AutoPaletteFailsIfHighBitsSet() {
         ViewPort.edit("FF FF @20 ^somedata @00 ^pal ")

         var items = ViewPort.getContextMenuItems(Point(0, 0))
         var item = items.single({ element -> element.text == "Display As..." })
         item  = ((item as ContextItemGroup)).single({ element -> element.text == "Color Palette" })
         var makePalette = item.command
         makePalette.execute()

         Assert.notEmpty(Errors)
      }
      @Test fun AutoPaletteNameHasNamespace() {
         ViewPort.edit("@20 ^somedata @30 <000> @00 ")

         var items = ViewPort.getContextMenuItems(Point(0, 0))
         var item = items.single({ element -> element.text == "Display As..." })
         item  = ((item as ContextItemGroup)).single({ element -> element.text == "Color Palette" })
         var makePalette = item.command
         makePalette.execute()

         var anchor = Model.getAnchorFromAddress(-1, 0)
         Assert.equal("${HardcodeTablesModel.defaultPaletteNamespace}.000000", anchor)
      }
      @Test fun AutoPaletteNameFromImageToolHasNamespace() {
         ViewPort.edit("@20 ^somedata @30 <000> @00 ")

         ViewPort.tools!!.spriteTool!!.paletteAddress  = 0
         ViewPort.tools!!.spriteTool!!.gotoPaletteAddress.execute()

         var anchor = Model.getAnchorFromAddress(-1, 0)
         Assert.equal("${HardcodeTablesModel.defaultPaletteNamespace}.000000", anchor)
      }
      @Test fun AutoSpriteNameFromImageToolHasNamespace() {
         ViewPort.edit("@20 ^somedata @30 <000> @00 ")

         ViewPort.tools!!.spriteTool!!.spriteAddress  = 0
         ViewPort.tools!!.spriteTool!!.gotoSpriteAddress.execute()

         var anchor = Model.getAnchorFromAddress(-1, 0)
         Assert.equal("${HardcodeTablesModel.defaultSpriteNamespace}.000000", anchor)
      }
      @Test fun CanFindPaletteInTableUsingField() {
         // make two palettes in a table with keys 0012 and 0055
         ViewPort.edit("^pals[id:|h pointer<`ucp4`>]4 0012 @{ @} 0055 @{ 0:0:0 3:3:3 @} "); // set the 2nd color of the 2nd palette

         // make a sprite that uses the 2nd palette
         ViewPort.edit("@20 ^sprite`ucs4x1x1|pals:id=0055` 11 "); // set this sprite to use the 2nd color for its first pixel

         var spriteRun = (Model.getNextRun(0x20) as ISpriteRun)
         var paletteRun = spriteRun.findRelatedPalettes(Model).single()

         Assert.equal("3:3:3", paletteRun.createDataFormat(Model, paletteRun.start + 2).toString())
         Assert.notEqual(0, ViewPort.tools!!.spriteTool!!.pixelData[0]) // sprite is rendered with correct palette
      }
      @Test fun CanCreateOverworldSpriteList() {
         // setup data elements
         ViewPort.edit("@00 00 00 11 00 00 00 40 00 08 00 08 00 00 00 00 00 <null> <null> <null> <060> <null>");     // parent (start, id, backup_id, length, width, height)
         ViewPort.edit("@30 <040> 11 00 00 00 @30 ^${HardcodeTablesModel.overworldPalettes}[p<`ucp4`> id:|h unused:]1 ");   // palette table. Palette goes from 40 to 60.
         ViewPort.edit("@60 <080> 20 00 00 00 <0A0> 20 00 00 00 ");                    // sprite list. Sprites go 80-A0 and A0-C0 (2 sprites)

         // add format to parent
         // starterbytes:|h paletteid:|h secondid:|h length: width: height: slot.|h overwrite. unused: distribution<> sizedraw<> animation<> sprites<> ramstore<>
         ViewPort.edit("@0000 ^parent[starterbytes: paletteid:|h secondid: length: width: height: other:: a<> b<> c<> sprites<`osl`> e<>]1 "); // sprites<`osl`> eventually

         // verify that the correct number of sprites were found
         var table = Model.getNextRun(0x60) as ITableRun
         Assert.equal(2, table.elementCount)

         // verify that the sprite runs were added as expected.
         var sprite1 = Model.getNextRun(0x80) as ISpriteRun
         Assert.equal(1, sprite1.spriteFormat.tileWidth)
         Assert.equal(1, sprite1.spriteFormat.tileHeight)
         Assert.equal("${HardcodeTablesModel.overworldPalettes}:id=0011", sprite1.spriteFormat.paletteHint)

         Assert.isType<SpriteRun>(Model.getNextRun(0xA0))
      }
      @Test fun CanAddPageToCompressedSpritesAndPalettes() {
         // Arrange: place some sprites and palettes, linked to a name table
         // 000-010  : pokenames table
         // 010-020  : sprite/palette tables (each is a single pointer)
         // 100-130  : front sprites
         // 130-160  : back sprites
         // 160-190  : normal palettes
         // 190-1B0  : shiny palettes
         ViewPort.edit("FF @00 ^${HardcodeTablesModel.pokemonNameTable}[name\"\"15]1 Castform\"")
         ViewPort.edit("@100 10 20 @130 10 20 @160 10 20 @190 10 20 @10 ")
         ViewPort.edit("^front.sprites[sprite<`lzs4x1x1`>]${HardcodeTablesModel.pokemonNameTable} <100>")
         ViewPort.edit("^back.sprites[sprite<`lzs4x1x1`>]${HardcodeTablesModel.pokemonNameTable} <130>")
         ViewPort.edit("^normal.palette[pal<`lzp4`>]${HardcodeTablesModel.pokemonNameTable} <160>")
         ViewPort.edit("^shiny.palette[pal<`lzp4`>]${HardcodeTablesModel.pokemonNameTable} <190>")

         // Act: expand each by a single page
         ViewPort.goto!!.execute(HardcodeTablesModel.pokemonNameTable)
         var sevm = (ViewPort.tools!!.tableTool!!.children.first({ child -> child is SpriteElementViewModel }) as SpriteElementViewModel)
         sevm.addPage.execute()

         // Assert: each has 2 pages now
         for (child in ViewPort.tools!!.tableTool!!.children) {
            if (child  is IPagedViewModel) {
               Assert.equal(2, (child as IPagedViewModel).pages)
               Assert.equal(1, (child as IPagedViewModel).currentPage)
            }
         }
      }
      @Test fun CanDeletePageFromCompressedSpritesAndPalettes() {
         // Arrange: place some sprites and palettes, linked to a name table
         // 000-010  : pokenames table
         // 010-020  : sprite/palette tables (each is a single pointer)
         // 040-0A0  : front sprites
         // 0A0-100  : back sprites
         // 100-160  : normal palettes
         // 160-1C0  : shiny palettes
         ViewPort.edit("FF @00 ^${HardcodeTablesModel.pokemonNameTable}[name\"\"15]1 Castform\"")
         ViewPort.edit("@040 10 40 @0A0 10 40 @100 10 40 @160 10 40 @10 ")
         ViewPort.edit("^front.sprites[sprite<`lzs4x1x1`>]${HardcodeTablesModel.pokemonNameTable} <040>")
         ViewPort.edit("^back.sprites[sprite<`lzs4x1x1`>]${HardcodeTablesModel.pokemonNameTable} <0A0>")
         ViewPort.edit("^normal.palette[pal<`lzp4`>]${HardcodeTablesModel.pokemonNameTable} <100>")
         ViewPort.edit("^shiny.palette[pal<`lzp4`>]${HardcodeTablesModel.pokemonNameTable} <160>")

         // Act: contract each by a single page
         ViewPort.goto!!.execute(HardcodeTablesModel.pokemonNameTable)
         var sevm = (ViewPort.tools!!.tableTool!!.children.first({ child -> child is SpriteElementViewModel }) as SpriteElementViewModel)
         sevm.deletePage.execute()

         // Assert: each has 1 page now
         for (child in ViewPort.tools!!.tableTool!!.children) {
            if (child  is IPagedViewModel) {
               Assert.equal(1, (child as IPagedViewModel).pages)
            }
         }
      }
      @Test fun ManuallyTypingPaletteChannelsWorks() {
         ViewPort.edit("^pal`ucp4` 1:2:3 ")

         var format = ViewPort[1, 0].format
         var content = format.toString()
         Assert.equal("1:2:3", content)
      }
      @Test fun CanCreateSpriteFromRightClick() {
         ViewPort.edit("^anchor 10 20 00 00")

         ViewPort.selectionStart  = Point(1, 0)
         var group = ((ViewPort.getContextMenuItems(Point(1, 0)).single({ item -> item.text == "Display As..." })) as ContextItemGroup)
         var contextItem = group.single({ item -> item.text == "Sprite" })
         contextItem.command.execute()

         Assert.equal(ViewPort.tools!!.spriteTool, ViewPort.tools!!.selectedTool)
         Assert.isType<LzSpriteRun>(Model.getNextRun(0))
      }
      @Test fun CanCreatePaletteFromRightClick() {
         ViewPort.edit("^anchor 10 20 00 00")

         ViewPort.selectionStart  = Point(1, 0)
         var group = ((ViewPort.getContextMenuItems(Point(1, 0)).single({ item -> item.text == "Display As..." })) as ContextItemGroup)
         var contextItem = group.single({ item -> item.text == "Color Palette" })
         contextItem.command.execute()

         Assert.equal(ViewPort.tools!!.spriteTool, ViewPort.tools!!.selectedTool)
         Assert.isType<LzPaletteRun>(Model.getNextRun(0))
      }
      @Test fun Freespace_InsertNewEmptyCompressedData_DataChanges() {
         SetFullModel(0xFF)
         ViewPort.refresh()

         ViewPort.edit("@!lz(32) "); // make sure that the next bytes represent 32 lz compressed bytes.

         var decompressed = LZRun.decompress(Data.asByteList(), 0)
         Assert.equal(32, decompressed!!.size)
      }
      @Test fun CompressedData_InsertNewEmptyCompressedData_DataDoesNotChange() {
         var rnd = java.util.Random(1234L)
         SetFullModel(0xFF)
         var decompressed = ByteArray(32)
         rnd.nextBytes(decompressed)
         var compressed = LZRun.compress(decompressed.asByteList(), 0, decompressed.size)
         for (i in 0 until compressed.count) Data[i]  = compressed[i].toByte()
         Model.resetChanges()
         ViewPort.refresh()

         ViewPort.edit("@!lz(32) ")

         Assert.equal(Point(0, 0), ViewPort.selectionStart)
         Assert.all(compressed.count.range(), { i -> Assert.isFalse(Model.hasChanged(i)) })
         Assert.empty(Errors)
      }
      @Test fun NonCompressedData_InsertNewEmptyCompressedData_Error() {
         ViewPort.edit("@!lz(32) ")

         Assert.single(Errors)
      }
      @Test fun Freespace_GotoCommandFollowedByExecuteCommand_BothCommandsPerformed() {
         SetFullModel(0xFF)
         ViewPort.refresh()

         ViewPort.edit("@100!lz(32) ")

         var decompressed = LZRun.decompress(Data.asByteList(), 0x100)
         Assert.equal(32, decompressed!!.size)
      }
      @Test fun CompressedPalette_Copy_CopyMetacommandToCreateCompressedRun() {
         SetFullModel(0xFF)
         var fs = StubFileSystem()
         ViewPort.edit("@!lz(32) ^pal`lzp4`")

         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(ViewPort.model.getNextRun(0)!!.length - 1)
         ViewPort.copy!!.execute(fs)

         Assert.startsWith("@!lz(32) ^pal`lzp4` lz ", fs.copyText)
      }
      @Test fun MultiPageSprite_InImageTool_CanExportMany() {
         WriteCompressedData(0, 0x20);      // palette
         WriteCompressedData(0x40, 0x40);   // sprite

         ViewPort.edit("@00 ^pal`lzp4` @40 ^sprite`lzs4x1x1|pal`")
         ViewPort.tools!!.selectedIndex  = ViewPort.tools!!.indexOf(ViewPort.tools!!.spriteTool)

         Assert.isTrue(ViewPort.tools!!.spriteTool!!.canExportMany)
      }
      @Test fun MultiPageSprite_ExportHorizontal_ReturnsHorizontal() {
         WriteCompressedData(0, 0x20);      // palette
         WriteCompressedData(0x40, 0x40);   // sprite
         ViewPort.edit("@00 ^pal`lzp4` @40 ^sprite`lzs4x1x1|pal`")
         ViewPort.tools!!.selectedIndex  = ViewPort.tools!!.indexOf(ViewPort.tools!!.spriteTool)

         var imageData: Array<IntArray>? = null
         var fs = StubFileSystem().also { it.showOptions = { title, text, details, options -> 0 }; it.saveIndexedImage = { pixels, palette, name -> imageData  = pixels } }

         ViewPort.tools!!.spriteTool!!.exportMany.execute(fs)

         Assert.equal(8 * 2, imageData!!.getLength(0))
         Assert.equal(8, imageData!!.getLength(1))
      }
      @Test fun MultiPageSprite_ExportVertical_ReturnsVertical() {
         WriteCompressedData(0, 0x20);      // palette
         WriteCompressedData(0x40, 0x40);   // sprite
         ViewPort.edit("@00 ^pal`lzp4` @40 ^sprite`lzs4x1x1|pal`")
         ViewPort.tools!!.selectedIndex  = ViewPort.tools!!.indexOf(ViewPort.tools!!.spriteTool)

         var imageData: Array<IntArray>? = null
         var fs = StubFileSystem().also { it.showOptions = { title, text, details, options -> 1 }; it.saveIndexedImage = { pixels, palette, name -> imageData  = pixels } }

         ViewPort.tools!!.spriteTool!!.exportMany.execute(fs)

         Assert.equal(8, imageData!!.getLength(0))
         Assert.equal(8 * 2, imageData!!.getLength(1))
      }
      @Test fun OneByteTilemap_Write_Works() {
         WriteCompressedData(0, 32)
         WriteCompressedData(0x20, 32)
         WriteCompressedData(0x40, 1)
         ViewPort.edit("@00 ^pal`lzp4` @20 ^tileset`lzt4|pal` @40 ^tilemap`lzm4x1x1|tileset`")

         var tilemap = ((Model.getNextRun(Model.getAddressFromAnchor(ViewPort.currentChange, -1, "tilemap"))) as ITilemapRun)
         var pixels = tilemap.getPixels(Model, 0)
         pixels!![2][2]  = 1
         tilemap.setPixels(Model, ViewPort.currentChange, 0, pixels!!)

         var tileset = ((Model.getNextRun(Model.getAddressFromAnchor(ViewPort.currentChange, -1, "tileset"))) as LzTilesetRun)
         pixels  = tileset.getPixels(Model, 0)
         pixels  = LzTilemapRun.tilize(pixels!!, 4)[1][0].pixels; // extract only tile 1, because tile 0 is the 'always blank' tile
         Assert.equal(1, pixels!![2][2])
      }
      @Test fun TwoUncompressedPalettes_Copy_32ColorsCopied() {
         var fs = StubFileSystem()
         ViewPort.edit("@00 ^a`ucp4` @20 ^b`ucp4` @00 ")
         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0)
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(0x40 - 1)

         ViewPort.copy!!.execute(fs)

         var colorCount = fs.copyText.value!!.split("0:0:0").size - 1
         Assert.equal(32, colorCount)
      }
      @Test fun UncompressedPalette_DeleteColor_BecomesBlack() {
         SetFullModel(0x55)
         Model.observeRunWritten(NoDataChangeDeltaModel(), PaletteRun(0, PaletteFormat(4, 1)))
         ViewPort.refresh()

         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(2)
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(3)
         ViewPort.clear!!.execute()

         Assert.equal(0, Model.readMultiByteValue(2, 2))
         Assert.isType<PaletteRun>(Model.getNextRun(0))
      }
      @Test fun PointerToCompressedData_EditAnchorFromPointer_AnchorEdited() {
         Token.changeData(Model, 0x100, LZRun.compress(ByteArray(0x20 * 4).asByteList()))
         AddPointer(0, 0x100)
         ViewPort.goto!!.execute(0x100)
         ViewPort.shortcuts.displayAsSprite.execute()

         ViewPort.goto!!.execute(0)
         ViewPort.anchorText  = "^graphics.test`lzs4x2x2`"

         ViewPort.goto!!.execute(0x100)
         Assert.equal("^graphics.test`lzs4x2x2`", ViewPort.anchorText)
         Assert.empty(Errors)
      }
      @Test fun TwoImages_Copy_ClipBoardContainsSpriteData() {
         var filesystem = StubFileSystem()
         ViewPort.edit("@00 ^sprite1`ucs4x1x1` @20 ^sprite2`ucs4x1x1`")
         var emptyBlock = " ".join(32.range().map({ i -> "00" }))

         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0x00)
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(0x3F)
         ViewPort.copy!!.execute(filesystem)

         var copiedData = filesystem.copyText.value
         var expectedData = "^sprite1`ucs4x1x1` ${emptyBlock} ^sprite2`ucs4x1x1` ${emptyBlock}"
         Assert.equal(expectedData, copiedData)
      }
      @Test fun TilemapFormat_CreateNewTilemap_DataIsLargeEnoughForManyTiles() {
         val (tileWidth, tileHeight, bytesPerTile) = Triple(32, 24, 2)
         var format = TilemapFormat(4, tileWidth, tileHeight, "")
         var strategy = LzTilemapRunContentStrategy(format)

         var newRun = (strategy.writeNewRun(Model, Token, 0, 0, "", emptyList()) as LzTilemapRun)

         Assert.equal(bytesPerTile, newRun.bytesPerTile)
         Assert.equal(tileWidth * tileHeight * bytesPerTile, newRun.decompressedLength)
      }

      val Ruby_240C3C: String = "10 C0 07 00 33 00 00 F0 01 90 01 FF FF F0 01 90 01 00 88 88 88 88 28 27 22 22 80 10 03 78 77 77 77 C8 AA AA 48 9A 00 03 AA D8 10 03 DD DD DD 98 10 1F 22 22 30 01 00 1E 77 99 99 28 99 7C 10 03 9A 00 03 DD CC CC 7F 7C D0 1F 10 01 10 13 20 08 00 53 F0 1F 70 1F 00 22 22 72 77 66 66 66 66 7F E6 00 67 F0 03 30 03 10 1F 00 06 F0 01 40 01 E2 F0 1F F0 1F 00 A7 6C DD CD 00 03 DD AF 10 03 CD 00 03 DD 60 03 F0 9F 90 9F 50 BF 21 72 82 10 03 77 77 87 87 10 03 C0 00 12 20 07 32 33 83 87 11 B1 00 BB BB 11 AB AA AA B1 4A 10 44 44 B1 01 33 AB 44 44 44 C2 50 03 10 0F BB BB BB 2B 00 06 BA BF 00 0E B4 50 07 50 03 10 0F F1 B1 F0 01 F0 01 C2 70 01 11 B3 E8 BB BB 9B 00 03 AB 8B 20 03 EE EE DE 00 03 2E 20 07 00 0F 81 F1 B3 CC 7C 2E DE D2 72 01 0B 41 7C 01 EA 7C E8 E2 E2 E2 11 E7 D4 21 EF 80 03 28 00 B8 28 00 FF E2 D2 ED 70 2B 00 16 10 03 7D 10 03 00 1E 7B 00 1E 79 72 10 5F D2 33 90 53 F0 7F CC 7C 90 53 A1 91 EB 76 00 2B E6 EE EE EE 10 07 7D D6 00 07 10 0B 91 CB 10 4B 00 12 EE 40 07 77 7E 10 03 F0 1F 30 1F E7 00 07 10 03 91 EB AB 00 16 67 00 12 6E 40 07 6D 40 0B 21 EF FA 51 FF D0 0B 51 EF 11 EB B0 0B 77 10 0B 88 FF D1 EF D0 0F D1 EF F1 FF F0 01 F0 01 F0 01 50 01 E6 61 F7 00 03 F3 BF DD DD 91 B3 F1 8B CC 7F 7C 11 E3 10 03 10 3B 51 F3 90 13 11 E3 51 E7 FF 51 F3 90 13 F2 33 B0 3F F2 33 B0 3F 51 E7 50 03 97 51 FB 76 EE 21 5E 88 01 E2 01 E7 10 03 F7 31 EF 51 E3 20 1C 00 01 E7 01 E4 20 03 41 EF F0 D0 1F 51 E7 50 03 51 FB 88 78 EE 67 8E 00 1E 78 11 11 70 01 11 F7 D0 0F 33 1A 33 33 83 50 03 00 0E 82 00 16 81 FF 50 03 10 0F F1 FF F1 FF F1 FF F1 FF F0 01 F0 01 FF F0 01 01 FF F3 BF F3 BF F3 BF 61 8B 00 D7 60 01 FE F0 FF F0 0F D0 0F F0 FF 00 07 05 0B 15 13 22 1F B2 BB BB F0 FF 70 0B 15 1B F0 7F E1 7F F0 F0 1F F0 1F F0 1F 70 1F 12 33 33 23 73 11 00 06 F0 BF F0 0F 22 38 00 2C 90 03 FC D1 EF F1 FF F0 FF F1 FF F0 FF F1 FF"
      @Test fun TilesetWithLengthError_AddTilesetFormatAllowingLengthErrors_CanCreateMetadata() {
         ViewPort.edit(Ruby_240C3C)

         ViewPort.edit("@00 ^tileset`lzt4!` ")

         Assert.empty(Errors)
         Assert.isType<LzTilesetRun>(Model.getNextRun(0))
      }
      @Test fun TilesetWithLengethError_ErrorMessage_MakesSense() {
         ViewPort.edit(Ruby_240C3C)

         ViewPort.edit("@00 ^tileset`lzt4` "); // this should produce an error

         Assert.single(Errors)
         Assert.equal("Decompressed more bytes than expected. Add a ! to override this.", Errors[0])
      }
      fun ImageFormatWithZeroDimensionErrors(format: String) {
         WriteCompressedData(0, 0x20)
         ViewPort.edit("^image${format} ")
         Assert.single(Errors)
      }
    @Test fun ImageFormatWithZeroDimensionErrors_1() { ImageFormatWithZeroDimensionErrors("`ucs4x0x1`") }
    @Test fun ImageFormatWithZeroDimensionErrors_2() { ImageFormatWithZeroDimensionErrors("`ucs4x1x0`") }
    @Test fun ImageFormatWithZeroDimensionErrors_3() { ImageFormatWithZeroDimensionErrors("`uct4x0`") }
    @Test fun ImageFormatWithZeroDimensionErrors_4() { ImageFormatWithZeroDimensionErrors("`lzs4x0x1`") }
    @Test fun ImageFormatWithZeroDimensionErrors_5() { ImageFormatWithZeroDimensionErrors("`lzs4x1x0`") }
    @Test fun ImageFormatWithZeroDimensionErrors_6() { ImageFormatWithZeroDimensionErrors("`lzt4x0`") }
      fun InvalidFormat_WithinPointerInTable_FailToWrite(format: String) {
         ViewPort.edit("^table[pointer<${format}>]1 ")
         Assert.single(Errors)
      }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_1() { InvalidFormat_WithinPointerInTable_FailToWrite("`lzs9x1x1`") }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_2() { InvalidFormat_WithinPointerInTable_FailToWrite("`ucs9x1x1`") }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_3() { InvalidFormat_WithinPointerInTable_FailToWrite("`lzm9x1x1`") }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_4() { InvalidFormat_WithinPointerInTable_FailToWrite("`lzt9`") }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_5() { InvalidFormat_WithinPointerInTable_FailToWrite("`uct9x1`") }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_6() { InvalidFormat_WithinPointerInTable_FailToWrite("`lzp9`") }
    @Test fun InvalidFormat_WithinPointerInTable_FailToWrite_7() { InvalidFormat_WithinPointerInTable_FailToWrite("`ucp9`") }

      private fun WriteCompressedData(start: Int, length: Int) {
         var compressedData = LZRun.compress(ByteArray(length).asByteList(), 0, length)
         for (i in 0 until compressedData.count) Model[start + i]  = compressedData[i]
      }

      private fun CreateLzRun(start: Int, vararg data: Int) {
         for (i in 0 until data.size) Model[start + i]  = data[i]
         var run = LZRun(Model, start)
         Model.observeRunWritten(ViewPort.currentChange, run)
      }
   }
