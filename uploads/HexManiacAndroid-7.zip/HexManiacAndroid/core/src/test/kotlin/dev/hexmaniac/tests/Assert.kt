@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST")

package dev.hexmaniac.tests

import dev.hexmaniac.core.system.*

/** xunit-like assertions. C# names are lower-first ("True"/"False"/"Null" get an "is" prefix because of Kotlin keywords). */
object Assert {
    private fun show(v: Any?): String = when (v) {
        null -> "null"
        is ByteArray -> v.joinToString(prefix = "[", postfix = "]") { (it.toInt() and 0xFF).toString() }
        is IntArray -> v.joinToString(prefix = "[", postfix = "]")
        is Array<*> -> v.joinToString(prefix = "[", postfix = "]") { show(it) }
        is String -> "\"" + v + "\""
        else -> v.toString()
    }

    private fun toSeq(v: Any?): List<Any?>? = when (v) {
        is ByteArray -> v.map { it.toInt() and 0xFF }
        is IntArray -> v.toList()
        is ShortArray -> v.toList()
        is LongArray -> v.toList()
        is DoubleArray -> v.toList()
        is BooleanArray -> v.toList()
        is CharArray -> v.toList()
        is Array<*> -> v.toList()
        is String -> null
        is Map<*, *> -> null
        is Iterable<*> -> v.toList()
        is ByteList -> (0 until v.count).map { v[it] }
        else -> null
    }

    /** C# value tuples are structural; the port represents them as Pair/Triple or as small data classes named *Tuple. */
    private fun partsOf(v: Any?): List<Any?>? {
        when (v) {
            null -> return null
            is Pair<*, *> -> return listOf(v.first, v.second)
            is Triple<*, *, *> -> return listOf(v.first, v.second, v.third)
            is dev.hexmaniac.core.models.Point -> return listOf(v.x, v.y)
        }
        val cls = v.javaClass
        if (!cls.simpleName.endsWith("Tuple")) return null
        val result = ArrayList<Any?>()
        var i = 1
        while (true) {
            val m = try { cls.getMethod("component$i") } catch (e: NoSuchMethodException) { null } ?: break
            result.add(m.invoke(v)); i++
        }
        return if (result.isEmpty()) null else result
    }

    fun areEqual(expected0: Any?, actual0: Any?): Boolean {
        // C# bytes are unsigned; Kotlin Bytes (elements of ByteArray) are not
        val expected = if (expected0 is Byte) (expected0.toInt() and 0xFF) else expected0
        val actual = if (actual0 is Byte) (actual0.toInt() and 0xFF) else actual0
        if (expected === actual) return true
        if (expected == null || actual == null) return false
        // C# RowHeader has an implicit conversion from string
        if (expected is String && actual is dev.hexmaniac.core.viewmodels.RowHeader) return expected == actual.content
        if (actual is String && expected is dev.hexmaniac.core.viewmodels.RowHeader) return actual == expected.content
        if (expected is Number && actual is Number) {
            if (expected is Double || expected is Float || actual is Double || actual is Float) return expected.toDouble() == actual.toDouble()
            return expected.toLong() == actual.toLong()
        }
        if (expected is Pair<*, *> || expected is Triple<*, *, *> || actual is Pair<*, *> || actual is Triple<*, *, *>) {
            val pa = partsOf(expected)
            val pb = partsOf(actual)
            if (pa != null && pb != null) {
                if (pa.size != pb.size) return false
                for (i in pa.indices) if (!areEqual(pa[i], pb[i])) return false
                return true
            }
        }
        if (expected is Char && actual is Number) return expected.code.toLong() == actual.toLong()
        if (expected is Number && actual is Char) return expected.toLong() == actual.code.toLong()
        val a = toSeq(expected)
        val b = toSeq(actual)
        if (a != null && b != null) {
            if (a.size != b.size) return false
            for (i in a.indices) if (!areEqual(a[i], b[i])) return false
            return true
        }
        return expected == actual
    }

    fun <T> equal(expected: T, actual: T, comparer: IEqualityComparer<T>) {
        if (!comparer.equals(expected, actual)) throw AssertionError("Assert.Equal() Failure (custom comparer)\nExpected: " + show(expected) + "\nActual:   " + show(actual))
    }
    fun equal(expected: Any?, actual: Any?) {
        if (!areEqual(expected, actual)) throw AssertionError("Assert.Equal failure\nExpected: " + show(expected) + "\nActual:   " + show(actual))
    }
    fun equal(expected: Double, actual: Double, precision: Int) {
        val f = Math.pow(10.0, precision.toDouble())
        if (Math.round(expected * f) != Math.round(actual * f)) throw AssertionError("Assert.Equal failure\nExpected: $expected\nActual:   $actual")
    }
    fun notEqual(expected: Any?, actual: Any?) {
        if (areEqual(expected, actual)) throw AssertionError("Assert.NotEqual failure\nValue: " + show(actual))
    }
    fun isTrue(condition: Boolean) { if (!condition) throw AssertionError("Assert.True() Failure") }
    fun isTrue(condition: Boolean, message: String?) { if (!condition) throw AssertionError("Assert.True() Failure: " + message) }
    fun isFalse(condition: Boolean) { if (condition) throw AssertionError("Assert.False() Failure") }
    fun isFalse(condition: Boolean, message: String?) { if (condition) throw AssertionError("Assert.False() Failure: " + message) }
    fun isNull(value: Any?) { if (value != null) throw AssertionError("Assert.Null() Failure\nValue: " + show(value)) }
    fun notNull(value: Any?) { if (value == null) throw AssertionError("Assert.NotNull() Failure") }
    fun same(expected: Any?, actual: Any?) { if (expected !== actual) throw AssertionError("Assert.Same() Failure") }
    fun notSame(expected: Any?, actual: Any?) { if (expected === actual) throw AssertionError("Assert.NotSame() Failure") }

    fun empty(collection: Any?) {
        val s = when (collection) {
            is String -> collection.length
            is Map<*, *> -> collection.size
            else -> toSeq(collection)?.size ?: throw AssertionError("Assert.Empty: not a collection")
        }
        if (s != 0) throw AssertionError("Assert.Empty() Failure: collection has $s items: " + show(collection))
    }
    fun notEmpty(collection: Any?) {
        val s = when (collection) {
            is String -> collection.length
            is Map<*, *> -> collection.size
            else -> toSeq(collection)?.size ?: throw AssertionError("Assert.NotEmpty: not a collection")
        }
        if (s == 0) throw AssertionError("Assert.NotEmpty() Failure")
    }
    fun <T> single(collection: Iterable<T>?): T {
        if (collection == null) throw AssertionError("Assert.Single() Failure: collection is null")
        val list = collection.toList()
        if (list.size != 1) throw AssertionError("Assert.Single() Failure: collection contains ${list.size} items: " + show(list))
        return list[0]
    }
    fun <T> single(collection: Array<T>): T = single(collection.asIterable())
    fun single(collection: IntArray): Int = single(collection.asIterable())
    fun single(collection: ByteArray): Int = single(collection.map { it.toInt() and 0xFF })
    fun <T> single(collection: Iterable<T>, expected: T): T {
        val list = collection.filter { areEqual(expected, it) }
        if (list.size != 1) throw AssertionError("Assert.Single() Failure: ${list.size} items equal ${show(expected)}")
        return list[0]
    }
    fun isType(expectedType: Class<*>, value: Any?) {
        if (value == null || value.javaClass != expectedType) throw AssertionError("Assert.IsType() Failure\nExpected: ${expectedType.name}\nActual:   ${value?.javaClass?.name}")
    }
    fun <T> single(collection: Iterable<T>, predicate: (T) -> Boolean): T {
        val list = collection.filter(predicate)
        if (list.size != 1) throw AssertionError("Assert.Single() Failure: ${list.size} items match")
        return list[0]
    }
    fun <T> contains(expected: T, collection: Iterable<T>?) {
        if (collection == null) throw AssertionError("Assert.Contains() Failure: collection is null")
        if (!collection.any { areEqual(expected, it) }) throw AssertionError("Assert.Contains() Failure\nNot found: " + show(expected) + "\nIn value:  " + show(collection.toList()))
    }
    fun <T> contains(expected: T, collection: Array<T>) = contains(expected, collection.asIterable())
    fun <K, V> contains(expected: K, dictionary: Map<K, V>) {
        if (!dictionary.containsKey(expected)) throw AssertionError("Assert.Contains() Failure: key not found: " + show(expected))
    }
    fun contains(expectedSubstring: String, actualString: String?) {
        if (actualString == null || !actualString.contains(expectedSubstring)) throw AssertionError("Assert.Contains() Failure\nNot found: " + show(expectedSubstring) + "\nIn value:  " + show(actualString))
    }
    fun <T> contains(collection: Iterable<T>, filter: (T) -> Boolean) {
        if (!collection.any(filter)) throw AssertionError("Assert.Contains() Failure: no item matches the filter: " + show(collection.toList()))
    }
    fun <T> doesNotContain(expected: T, collection: Iterable<T>?) {
        if (collection == null) return
        if (collection.any { areEqual(expected, it) }) throw AssertionError("Assert.DoesNotContain() Failure\nFound: " + show(expected))
    }
    fun <T> doesNotContain(expected: T, collection: Array<T>) = doesNotContain(expected, collection.asIterable())
    fun doesNotContain(expectedSubstring: String, actualString: String?) {
        if (actualString != null && actualString.contains(expectedSubstring)) throw AssertionError("Assert.DoesNotContain() Failure\nFound: " + show(expectedSubstring))
    }
    fun <T> doesNotContain(collection: Iterable<T>, filter: (T) -> Boolean) {
        if (collection.any(filter)) throw AssertionError("Assert.DoesNotContain() Failure: an item matches the filter")
    }
    fun startsWith(expectedStart: String, actual: String?) {
        if (actual == null || !actual.startsWith(expectedStart)) throw AssertionError("Assert.StartsWith() Failure\nExpected start: " + show(expectedStart) + "\nActual:         " + show(actual))
    }
    fun endsWith(expectedEnd: String, actual: String?) {
        if (actual == null || !actual.endsWith(expectedEnd)) throw AssertionError("Assert.EndsWith() Failure\nExpected end: " + show(expectedEnd) + "\nActual:       " + show(actual))
    }
    fun <T> all(collection: Iterable<T>, action: (T) -> Unit) { for (item in collection) action(item) }
    fun <T> all(collection: Array<T>, action: (T) -> Unit) { for (item in collection) action(item) }
    fun all(collection: IntArray, action: (Int) -> Unit) { for (item in collection) action(item) }
    fun <T> collection(collection: Iterable<T>, vararg inspectors: (T) -> Unit) {
        val list = collection.toList()
        if (list.size != inspectors.size) throw AssertionError("Assert.Collection() Failure: expected ${inspectors.size} items but found ${list.size}")
        for (i in list.indices) inspectors[i](list[i])
    }
    fun <T : Comparable<T>> inRange(actual: T, low: T, high: T) {
        if (actual < low || actual > high) throw AssertionError("Assert.InRange() Failure\nRange: ($low - $high)\nActual: $actual")
    }
    fun <T : Comparable<T>> notInRange(actual: T, low: T, high: T) {
        if (actual >= low && actual <= high) throw AssertionError("Assert.NotInRange() Failure\nRange: ($low - $high)\nActual: $actual")
    }
    inline fun <reified T> isType(value: Any?): T {
        if (value == null || value.javaClass != T::class.java) throw AssertionError("Assert.IsType() Failure\nExpected: " + T::class.java.name + "\nActual:   " + (value?.javaClass?.name ?: "null"))
        return value as T
    }
    inline fun <reified T> isNotType(value: Any?) {
        if (value != null && value.javaClass == T::class.java) throw AssertionError("Assert.IsNotType() Failure\nType: " + T::class.java.name)
    }
    inline fun <reified T> isAssignableFrom(value: Any?): T {
        if (value !is T) throw AssertionError("Assert.IsAssignableFrom() Failure\nExpected: " + T::class.java.name + "\nActual:   " + (value?.javaClass?.name ?: "null"))
        return value
    }
    inline fun <reified T : Throwable> throws(action: () -> Unit): T {
        try {
            action()
        } catch (e: Throwable) {
            if (e is T) return e
            throw AssertionError("Assert.Throws() Failure\nExpected: " + T::class.java.name + "\nActual:   " + e.javaClass.name + ": " + e.message)
        }
        throw AssertionError("Assert.Throws() Failure: no exception was thrown (expected " + T::class.java.name + ")")
    }
    fun fail(message: String): Nothing = throw AssertionError(message)
}

/** `new byte[] { ... }` with values 0..255. */
fun bytes(vararg values: Int): ByteArray = ByteArray(values.size) { values[it].toByte() }
