@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class EggMoveTests {
      private lateinit var data: ByteArray
      private lateinit var model: PokemonModel
      private lateinit var viewPort: ViewPort
      private var messages: MutableList<String> = ArrayList<String>()

      //#region Setup

      init {
         data  = 0x200.range().map({ i -> 0xFF.u8() }).toByteArr()
         model  = PokemonModel(data)
         viewPort  = ViewPort("file.gba", model, InstantDispatch.instance)

         viewPort.goto!!.execute("000080")
         viewPort.edit("^${HardcodeTablesModel.pokemonNameTable}[name\"\"8]8 \"Bob\" \"Steve\" \"Carl\" \"Sam\" \"Bryan\" \"Ryan\" \"Ian\" \"Matt\"")

         viewPort.goto!!.execute("000100")
         viewPort.edit("^${HardcodeTablesModel.moveNamesTable}[name\"\"8]9 \"Fire\" \"Water\" \"Earth\" \"Wind\" \"Light\" \"Dark\" \"Normal\" \"Magic\" \"Th is\"")

         viewPort.goto!!.execute("000180")
         viewPort.edit("<000000> Dead Beef 01 00 00 00 <000000>"); // limiter is at 188 for an eggrun at 000

         viewPort.goto!!.execute("000000")

         viewPort.onMessage  += { sender, e -> messages.add(e) }
      }

      private fun CreateSimpleRun() {
         var token = ModelDelta()
         model.writeMultiByteValue(0, 2, token, EggMoveRun.magicNumber + 2); // Carl
         model.writeMultiByteValue(2, 2, token, 3);                          // Wind

         viewPort.edit("^${HardcodeTablesModel.eggMovesTableName}`egg` ")
      }

      private fun SplitLines(lines: String): String = "\n".join(lines.split(";").toList())
      @Test fun CanCreateEggMoveStream() {
         viewPort.edit("^${HardcodeTablesModel.eggMovesTableName}`egg` ")

         Assert.equal(2, model.getNextRun(0).length)
      }
      @Test fun CanSeeEggMoveStreamWithCorrectFormat() {
         CreateSimpleRun()

         Assert.equal(6, model.getNextRun(0).length)
         var section = ((viewPort[1, 0].format) as EggSection)
         var item = ((viewPort[2, 0].format) as EggItem)
         var endSection = ((viewPort[5, 0].format) as EggSection)
         Assert.equal("[Carl]", section.sectionName)
         Assert.equal("Wind", item.itemName)
         Assert.equal("[]", endSection.sectionName)
      }
      @Test fun SelectionDoneInPairs() {
         CreateSimpleRun()

         viewPort.selectionStart  = Point(2, 0); // should select "Wind"
         Assert.isTrue(viewPort.isSelected(Point(3, 0)))

         viewPort.moveSelectionStart.execute(Direction.Right); // should select "[]"
         Assert.isTrue(viewPort.isSelected(Point(4, 0)))
         Assert.isTrue(viewPort.isSelected(Point(5, 0)))
      }
      @Test fun CanEditEggStreamManually() {
         CreateSimpleRun()

         viewPort.edit("Dark ")
         Assert.equal(5, model[0])

         viewPort.edit("[Bryan]")
         Assert.equal(EggMoveRun.magicNumber + 4, model.readMultiByteValue(2, 2))
      }
      @Test fun CanCopyPaste() {
         CreateSimpleRun()
         var fileSystem = StubFileSystem()

         viewPort.selectionStart  = Point(2, 0)
         viewPort.selectionEnd  = Point(4, 0)
         viewPort.copy!!.execute(fileSystem)

         Assert.equal("Wind []", fileSystem.copyText.value)
      }
      @Test fun RunAutoExtends() {
         CreateSimpleRun()
         viewPort.selectionStart  = Point(4, 0)
         viewPort.edit("[Carl]")

         Assert.equal(8, model.getNextRun(0).length)
         Assert.equal(2, model.readMultiByteValue(0x188, 4))
      }
      @Test fun RunAutoMoves() {
         viewPort.edit("^${HardcodeTablesModel.eggMovesTableName}`egg` ")
         model.writeMultiByteValue(2, 2, ModelDelta(), 0x0206)
         viewPort.edit("[Carl]")

         Assert.single(messages)
      }
      @Test fun RunAutoShortens() {
         CreateSimpleRun()
         viewPort.selectionStart  = Point(2, 0)
         viewPort.edit("[]")

         Assert.equal(4, model.getNextRun(0).length)
         Assert.equal(0, model.readMultiByteValue(0x188, 4))
      }
      @Test fun CanViewInTextTool() {
         CreateSimpleRun()
         viewPort.selectionStart  = Point(2, 2); // select off it
         viewPort.selectionStart  = Point(2, 0); // and then back on
         viewPort.tools!!.stringToolCommand.execute()

         Assert.equal(SplitLines("[Carl];Wind"), viewPort.tools!!.stringTool!!.content)

         viewPort.tools!!.stringTool!!.content  = SplitLines("[Carl];Earth;Light;[Ryan];Fire;Water")

         Assert.equal(14, model.getNextRun(0).length)
         Assert.equal(5, model.readMultiByteValue(0x188, 4))
      }
      @Test fun FollowLinkOpensTextTool() {
         CreateSimpleRun()
         viewPort.selectionStart  = Point(2, 0)
         viewPort.followLink(2, 0)

         Assert.equal(viewPort.tools!!.indexOf(viewPort.tools!!.stringTool), viewPort.tools!!.selectedIndex)
      }
      @Test fun RightClickOptionToOpenTextTool() {
         CreateSimpleRun()
         viewPort.selectionStart  = Point(2, 0)
         var items = viewPort.getContextMenuItems(viewPort.selectionStart)
         Assert.contains(items, { item -> item.shortcutText == "Ctrl+Click" })
      }
      @Test fun ToolCursorChangesCauseSelectionChanges() {
         CreateSimpleRun()
         viewPort.selectionStart  = Point(2, 0)
         viewPort.tools!!.stringToolCommand.execute()
         viewPort.tools!!.stringTool!!.contentIndex  = 5

         Assert.isTrue(viewPort.isSelected(Point(0, 0)))
         Assert.isTrue(viewPort.isSelected(Point(1, 0)))
      }
      @Test fun SearchFindsEggMoveData() {
         CreateSimpleRun()

         var pairs = viewPort.find("wind")
         Assert.contains(Pair(2, 3), pairs)

         pairs  = viewPort.find("carl")
         Assert.contains(Pair(0, 1), pairs)
      }
      @Test fun BackspaceWorks() {
         CreateSimpleRun()

         viewPort.selectionStart  = Point(2, 0)
         viewPort.edit(ConsoleKey.Backspace)

         var format = ((viewPort[2, 0].format) as UnderEdit)
         Assert.equal("Win", format.currentText) // Wind, but backspaced
      }
      @Test fun SelectLeftThenBackspaceThenDownCompletesEdits() {
         CreateSimpleRun()

         viewPort.selectionStart  = Point(2, 0)
         viewPort.moveSelectionStart.execute(Direction.Left)
         viewPort.edit(ConsoleKey.Backspace)
         viewPort.moveSelectionStart.execute(Direction.Down)

         Assert.isNotType<UnderEdit>(viewPort[1, 0].format)
      }
      @Test fun CanClearCellContent() {
         CreateSimpleRun()

         viewPort.selectionStart  = Point(2, 0)
         viewPort.edit(ConsoleKey.Backspace); // d
         viewPort.edit(ConsoleKey.Backspace); // n
         viewPort.edit(ConsoleKey.Backspace); // i
         viewPort.edit(ConsoleKey.Backspace); // W

         var format = ((viewPort[2, 0].format) as UnderEdit)
         Assert.equal("", format.currentText)
      }
      @Test fun CanRemoveEggMoveFormatFromContextMenu() {
         CreateSimpleRun()

         viewPort.selectionStart  = Point(2, 0)
         var items = viewPort.getContextMenuItems(viewPort.selectionStart)
         items.single({ item -> item.text == "Clear Format" })
      }
      @Test fun EggMoves_AutocompletePokemon_GetPokemonOptions() {
         CreateSimpleRun()
         var run = (model.getNextRun(0) as EggMoveRun)

         var options = run.getAutoCompleteOptions("[an", 3, 3)

         Assert.equal(3, options.size)
         Assert.equal("[Bryan]", options[0].text)
         Assert.equal("[Ryan]", options[1].text)
         Assert.equal("[Ian]", options[2].text)
         Assert.all(options, { option -> Assert.equal(option.text, option.lineText) })
      }
      @Test fun EggMoves_AutocompleteMove_GetMoveOptions() {
         CreateSimpleRun()
         var run = (model.getNextRun(0) as EggMoveRun)

         var options = run.getAutoCompleteOptions("er", 2, 2)

         Assert.equal(2, options.size)
         Assert.equal("Water", options[0].text)
         Assert.equal("Earth", options[1].text)
         Assert.all(options, { option -> Assert.equal(option.text, option.lineText) })
      }
      @Test fun EggMovesWithQuotes_Autocomplete_NoQuotes() {
         CreateSimpleRun()
         var run = (model.getNextRun(0) as EggMoveRun)

         var options = run.getAutoCompleteOptions("this", 2, 4)

         Assert.equal("Th is", options[0].lineText)
      }
   }
