@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore


   open class ToolTests : BaseViewModelTestClass() {
      private lateinit var parser: ThumbParser
      init {
         parser  = ThumbParser(Singletons)
         ViewPort.tools!!.codeTool!!.isSelected  = true
      }
      @Test fun ViewPortHasTools() {
         var viewPort = ViewPort(LoadedFile("file.txt", ByteArray(100)))
         Assert.isTrue(viewPort.hasTools)
      }
      @Test fun TextData_DoubleClick_OpenTextTool() {
         SetFullModel(0xFF)
         ViewPort.edit("^bob\"\" \"Some Text\"")
         ViewPort.tools!!.selectedIndex  = -1
         var view = StubView(ViewPort.tools!!)

         ViewPort.followLink(0, 0)

         Assert.contains("selectedIndex", view.propertyNotifications)
         Assert.isType<PCSTool>(ViewPort.tools!![ViewPort.tools!!.selectedIndex])
      }
      @Test fun StringToolEditsAreReflectedInViewPort() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^bob\"\" \"Some Text\" 00 <000100>")
         viewPort.tools!!.stringTool!!.address  = 0

         viewPort.tools!!.stringTool!!.content  = "Some Test"; // Text -> Test
         var pcs = ((viewPort[7, 0].format) as PCS)
         Assert.equal("s", pcs.thisCharacter)
      }
      @Test fun StringToolCanMoveData() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^bob\"\" \"Some Text\" 00 <000100>")
         var toolProperties = ArrayList<String>()
         viewPort.tools!!.stringTool!!.propertyChanged  += { sender, e -> toolProperties.add(e.propertyName!!) }
         viewPort.tools!!.stringTool!!.address  = 0

         toolProperties.clear()
         viewPort.tools!!.stringTool!!.content  = "Some More Text"
         Assert.contains("address", toolProperties)
      }
      @Test fun ViewPortMovesWhenStringToolMovesData() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         viewPort.edit("^bob\"\" \"Some Text\" 00 <000100>")
         viewPort.goto!!.execute(0)

         viewPort.tools!!.stringTool!!.content  = "Some More Text"
         Assert.notEqual(0, viewPort.headers!![0].content.toInt(16))
      }
      @Test fun StringToolMultiCharacterDeleteCleansUpUnusedBytes() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^bob\"\" \"Some Text\" 00 <000100>")
         viewPort.tools!!.stringTool!!.address  = 0

         viewPort.tools!!.stringTool!!.content  = "Some "; // removed 'Text' from the end

         Assert.equal(0xFF, Model[7])
      }
      @Test fun HideCommandClosesAnyOpenTools() {
         var tools = ViewPort.tools
         tools!!.selectedIndex  = 1
         tools!!.hideCommand.execute()

         Assert.equal(-1, tools!!.selectedIndex)
      }
      @Test fun StringToolContentUpdatesWhenViewPortChange() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^bob\"\" \"Some Text\"")

         viewPort.selectionStart  = Point(3, 0);   // select the 'e' in 'Some'
         viewPort.followLink(3, 0);                   // open the string tool
         viewPort.edit("i");                          // change the 'e' to 'i'

         Assert.equal("Somi Text", viewPort.tools!!.stringTool!!.content)
      }
      @Test fun ToolSelectionChangeUpdatesViewPortSelection() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^bob\"\" \"Some Text\"")
         viewPort.selectionStart  = Point(3, 0)
         viewPort.followLink(3, 0)

         viewPort.tools!!.stringTool!!.contentIndex  = 4

         Assert.equal(Point(4, 0), viewPort.selectionStart)
      }
      @Test fun SelectingAPointerAddressInStringToolDisablesTheTool() {
         Model.writePointer(Token, 16, 100)
         Model.observeRunWritten(Token, PointerRun(16))
         var tool = PCSTool(
            ViewPort,
            ViewPort.changeHistory,
            null).also { it.address = 18 }

         Assert.equal(18, tool.address); // address updated correctly
         Assert.isFalse(tool.enabled)     // run is not one that this tool knows how to edit
      }
      @Test fun TableToolUpdatesWhenTextToolDataChanges() {
         // Arrange
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^array[name\"\"16]3 ")
         viewPort.selectionStart  = Point(8, 1)

         // Act: Update via the Text Tool
         viewPort.tools!!.selectedIndex  = 10.range().first({ i -> viewPort.tools!![i] == viewPort.tools!!.stringTool })
         viewPort.tools!!.stringTool!!.content  = "\n" + "Larry"

         // Assert: Table Tool is updated
         viewPort.tools!!.selectedIndex  = 10.range().first({ i -> viewPort.tools!![i] == viewPort.tools!!.tableTool })
         var field = ((viewPort.tools!!.tableTool!!.children[1]) as FieldArrayElementViewModel)
         Assert.equal("Larry", field.content)
      }
      @Test fun TextToolToolUpdatesWhenTableToolDataChanges() {
         // Arrange
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^array[name\"\"16]3 ")
         viewPort.selectionStart  = Point(8, 1)

         // Act: Update via the Table Tool
         viewPort.tools!!.selectedIndex  = 10.range().first({ i -> viewPort.tools!![i] == viewPort.tools!!.tableTool })
         var field = ((viewPort.tools!!.tableTool!!.children[1]) as FieldArrayElementViewModel)
         field.content  = "Larry"

         // Assert: Text Tool is updated
         viewPort.tools!!.selectedIndex  = 10.range().first({ i -> viewPort.tools!![i] == viewPort.tools!!.stringTool })
         var textToolContent = viewPort.tools!!.stringTool!!.content.split("\n")[1]
         Assert.equal("Larry", textToolContent)
      }
      @Test fun TableToolUpdatesIndexOnCursorMove() {
         // Arrange
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^array[name\"\"16]3 ")

         // Act: move the cursor to change the selected table item
         viewPort.selectionStart  = Point(8, 1)

         // Assert: table item index 1 is selected
         Assert.contains("1", viewPort.tools!!.tableTool!!.currentElementName)
      }
      @Test fun ContentUpdateFromAnotherToolDoesNotResetCaretInStringTool() {
         // Arrange
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^array[name\"\"16]3 ")

         // mock the view: whenever the stringtool content changes,
         // reset the cursor to the start position.
         viewPort.tools!!.stringTool!!.propertyChanged  += lm1@{ sender, e ->
            if (e.propertyName == "Content") viewPort.tools!!.stringTool!!.contentIndex  = 0
         }

         viewPort.selectionStart  = Point(8, 1);                                                                         // move the cursor
         viewPort.tools!!.selectedIndex  = 10.range().first({ i -> viewPort.tools!![i] == viewPort.tools!!.stringTool }); // open the string tool
         viewPort.tools!!.stringTool!!.contentIndex  = 12;                                                                       // place the cursor somewhere, like the UI would
         viewPort.tools!!.selectedIndex  = 10.range().first({ i -> viewPort.tools!![i] == viewPort.tools!!.tableTool });  // open the table tool
         var field = ((viewPort.tools!!.tableTool!!.children[1]) as FieldArrayElementViewModel)
         field.content  = "Larry";                                                                                           // make a change with the table tool

         Assert.notEqual(Point(), viewPort.selectionStart)
      }
      @Test fun TableToolCanExtendTable() {
         // Arrange
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^array[name\"\"16]3 ")
         viewPort.tools!!.selectedIndex  = viewPort.tools!!.size.range().single({ i -> viewPort.tools!![i] == viewPort.tools!!.tableTool })
         Assert.isTrue(viewPort.tools!!.tableTool!!.next.canExecute(null)); // table has 3 entries

         // Act: move to end of table
         while (viewPort.tools!!.tableTool!!.next.canExecute(null)) viewPort.tools!!.tableTool!!.next.execute()

         Assert.isTrue(viewPort.tools!!.tableTool!!.append.canExecute(null))
         viewPort.tools!!.tableTool!!.append.execute()
         Assert.contains("3", viewPort.tools!!.tableTool!!.currentElementName)
         Assert.equal(16 * 4, Model.getNextRun(0).length)
      }
      @Test fun TableToolNotOfferedOnNormalText() {
         // Arrange
         SetFullModel(0xFF)
         var viewPort = ViewPort
         viewPort.edit("^array[name\"\"16]3 ")
         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("^text\"\" Some Text\"")

         // Act
         viewPort.selectionStart  = Point(2, 4)
         var items = viewPort.getContextMenuItems(viewPort.selectionStart)

         // Assert
         var matches = items.filter({ item -> item.text!!.contains("Table") })
         Assert.empty(matches)
      }
      fun ThumbDecompilerTests(input: Int, output: String) {
         var bytes = arrayOf( input.u8(), (input  shr  8).u8())
         var model = PokemonModel(bytes.toByteArr())
         var result = parser.parse(model, 0, 2).split("\n")[1].trim()
         Assert.equal(output, result)
      }
    @Test fun ThumbDecompilerTests_1() { ThumbDecompilerTests(0x0000, "nop") }
    @Test fun ThumbDecompilerTests_2() { ThumbDecompilerTests(0x1888, "add   r0, r1, r2") }
    @Test fun ThumbDecompilerTests_3() { ThumbDecompilerTests(0x111, "lsl   r1, r2, #4") }
    @Test fun ThumbDecompilerTests_4() { ThumbDecompilerTests(0xD00C, "beq   <00001C>") }
    @Test fun ThumbDecompilerTests_5() { ThumbDecompilerTests(0x4647, "mov   r7, r8") }
    @Test fun ThumbDecompilerTests_6() { ThumbDecompilerTests(0xDF00, "swi   #0") }
      @Test fun DecompileThumbRoutineTest() {
         // sample routine: If r0 is true, return double r1. Else, return 0
         var code = arrayOf<Int>(
         // 000000:
            0xB530,    // push  lr, {r4, r5}         (note that for push, r0-r7 run right-left)
            0x2801,   // cmp   r0, 1
            0xD100,   // bne   pc(4)+(0)*2+4 = 8
            0x1848,  // add   r0, r1, r1
         // 000008:
            0xBD30,)

         var bytes = code.flatMap({ pair -> listOf( pair.u8(), (pair  shr  8).u8()) }).toTypedArray()
         var model = PokemonModel(bytes.toByteArr())
         var lines = parser.parse(model, 0, bytes.size).split('\n', '\r').filter { it.isNotEmpty() }
         Assert.equal(7, lines.size)
         Assert.equal("000000:", lines[0])
         Assert.equal("    push  {r4-r5, lr}", lines[1])
         Assert.equal("    cmp   r0, #1", lines[2])
         Assert.equal("    bne   <000008>", lines[3])
         Assert.equal("    add   r0, r1, r1", lines[4])
         Assert.equal("000008:", lines[5])
         Assert.equal("    pop   {r4-r5, pc}", lines[6])
      }
      @Test fun ShowDataTest() {
         var code = arrayOf<Int>(
         // 000000: first code part
            0x4800,  // ldr   r0, pc(0)+(0)*4+4 = 4
            0xE003,   // b     pc(2)+(3)*2+4 = 12
         // 000004: some data and some skipped bytes
            0x1234,                // (loaded)
            0x5678,                // (loaded)
            0x0000,                // (skipped)
            0x0000,                // (skipped)
         // 00000C: more code that uses the data
            0x4700)

         var bytes = code.flatMap({ pair -> listOf( pair.u8(), (pair  shr  8).u8()) }).toTypedArray()
         var model = PokemonModel(bytes.toByteArr())
         var lines = parser.parse(model, 0, bytes.size).split('\n', '\r').filter { it.isNotEmpty() }
         Assert.equal(7, lines.size)
         Assert.equal("000000:", lines[0])
         Assert.equal("    ldr   r0, [pc, <000004>]  @ = 0x56781234", lines[1])
         Assert.equal("    b     <00000C>", lines[2])
         Assert.equal("000004:", lines[3])
         Assert.equal("    .word 0x56781234", lines[4])
         Assert.equal("00000C:", lines[5])
         Assert.equal("    bx    r0", lines[6])
      }
      @Test fun LoadRegisterCommmandsLoadWordAligned() {
         //01101 # rn rd
         var code = arrayOf<Int>(
            0x0,  // nop
            0x4801,   // ldr #1 <-- 8, not 10
            0xBD00,    // pop pc {}
            0x0,    // nop
            0xBEEF,  // .word
            0xDEAD,)

         var bytes = code.flatMap({ pair -> listOf( pair.u8(), (pair  shr  8).u8()) }).toTypedArray()
         var model = PokemonModel(bytes.toByteArr())
         var lines = parser.parse(model, 0, bytes.size).split('\n', '\r').filter { it.isNotEmpty() }

         Assert.equal(6, lines.size)
         Assert.equal("000000:", lines[0])
         Assert.equal("    nop", lines[1])
         Assert.equal("    ldr   r0, [pc, <000008>]  @ = 0xDEADBEEF", lines[2])
         Assert.equal("    pop   {pc}", lines[3])
         Assert.equal("000008:", lines[4])
         Assert.equal("    .word 0xDEADBEEF", lines[5])
      }
      @Test fun BranchLinkInstructionsTakeDoubleSpace() {
         var model = PokemonModel(ByteArray(20))
         model.writeValue(ModelDelta(), 0, (0xF804F000L.toInt())); // bl

         var lines = parser.parse(model, 0, 20).split("\n").filter({ s -> !isNullOrEmpty_(s) }).toTypedArray(); // pc(0)+#(4)*2+4 = C

         Assert.equal(11, lines.size)
         Assert.equal("000000:", lines[0])
         Assert.equal("    bl    <00000C>", lines[1])
         Assert.equal("    nop", lines[2])
         Assert.equal("    nop", lines[3])
         Assert.equal("    nop", lines[4])
         Assert.equal("    nop", lines[5])
         Assert.equal("00000C:", lines[6])
         Assert.equal("    nop", lines[7])
         Assert.equal("    nop", lines[8])
         Assert.equal("    nop", lines[9])
         Assert.equal("    nop", lines[10])
      }
      fun ThumbCompilerTests(input: String, output: Long) {
         var bytes = mutableListOf<Int>( output.u8(), (output  shr  8).u8())
         var model = PokemonModel(ByteArray(0x200))
         model.observeAnchorWritten(ModelDelta(), "bob", NoInfoRun(0x80)); // random anchor so we can test stuff that points to anchors
         var result = parser.compile(model, 0x100, input)

         Assert.equal(bytes[0], result[0])
         Assert.equal(bytes[1], result[1])

         if (result.count > 2) {
            bytes.add((output  shr  16).u8())
            bytes.add((output  shr  24).u8())
            Assert.equal(bytes[2], result[2])
            Assert.equal(bytes[3], result[3])
         }
      }
    @Test fun ThumbCompilerTests_1() { ThumbCompilerTests("mov   r2, #3", 0x2203) }
    @Test fun ThumbCompilerTests_2() { ThumbCompilerTests("mov   r2 #3", 0x2203) }
    @Test fun ThumbCompilerTests_3() { ThumbCompilerTests("r2 = 3", 0x2203) }
    @Test fun ThumbCompilerTests_4() { ThumbCompilerTests("add   r0, r1, r2", 0x1888) }
    @Test fun ThumbCompilerTests_5() { ThumbCompilerTests("add   r0, r1",     0x1840) }
    @Test fun ThumbCompilerTests_6() { ThumbCompilerTests("add   r8, r0",     0x4480) }
    @Test fun ThumbCompilerTests_7() { ThumbCompilerTests("add   r0, r1, #4", 0x1D08) }
    @Test fun ThumbCompilerTests_8() { ThumbCompilerTests("mul   r0, r0, r1", 0x4348) }
    @Test fun ThumbCompilerTests_9() { ThumbCompilerTests("add   r2, r2, #4", 0x3204) }
    @Test fun ThumbCompilerTests_10() { ThumbCompilerTests("lsl   r1, r2, #4", 0x111) }
    @Test fun ThumbCompilerTests_11() { ThumbCompilerTests("lsl   r1, #4",     0x109) }
    @Test fun ThumbCompilerTests_12() { ThumbCompilerTests("bls   <000120>", 0xD90E) }
    @Test fun ThumbCompilerTests_13() { ThumbCompilerTests("push  lr, {}", 0xB500) }
    @Test fun ThumbCompilerTests_14() { ThumbCompilerTests("bl    <000120>", 0xF80EF000L) }
    @Test fun ThumbCompilerTests_15() { ThumbCompilerTests(".word 00004000", 0x4000) }
    @Test fun ThumbCompilerTests_16() { ThumbCompilerTests(".word <004000>", 0x8004000) }
    @Test fun ThumbCompilerTests_17() { ThumbCompilerTests(".word <bob>", 0x8000080) }
    @Test fun ThumbCompilerTests_18() { ThumbCompilerTests("ldr   r0, [pc, <bob>]", 0x48DF) }
    @Test fun ThumbCompilerTests_19() { ThumbCompilerTests("ldr   r0, bob", 0x48DF) }
    @Test fun ThumbCompilerTests_20() { ThumbCompilerTests("ldrb  r1, [r1, r2]", 0x5C89) }
    @Test fun ThumbCompilerTests_21() { ThumbCompilerTests("ldrh  r2, [r1, #0]", 0x880A) }
    @Test fun ThumbCompilerTests_22() { ThumbCompilerTests("lsl   r1, r2", 0x4091) }
    @Test fun ThumbCompilerTests_23() { ThumbCompilerTests("lsl   r1, r2 @ comment", 0x4091) }
    @Test fun ThumbCompilerTests_24() { ThumbCompilerTests("mov   r7, r8", 0x4647) }
    @Test fun ThumbCompilerTests_25() { ThumbCompilerTests("bx lr", 0x4770) }
    @Test fun ThumbCompilerTests_26() { ThumbCompilerTests("ldr   r1, [r2]", 0x6811) }
    @Test fun ThumbCompilerTests_27() { ThumbCompilerTests("lsl   r1, r2, #0x4", 0x111) }
    @Test fun ThumbCompilerTests_28() { ThumbCompilerTests("sub   sp, #4", 0xB081) }
    @Test fun ThumbCompilerTests_29() { ThumbCompilerTests("mov   r3, sp", 0x466B) }
    @Test fun ThumbCompilerTests_30() { ThumbCompilerTests("push {r0-r2, lr}", 0xB507) }
    @Test fun ThumbCompilerTests_31() { ThumbCompilerTests("ldrb r1, [r1, 0]", 0x7809) }
    @Test fun ThumbCompilerTests_32() { ThumbCompilerTests("ldrb r1, [r1]", 0x7809) }
    @Test fun ThumbCompilerTests_33() { ThumbCompilerTests("strb r3, [r4]", 0x7023) }
    @Test fun ThumbCompilerTests_34() { ThumbCompilerTests("str  r2, [r0]", 0x6002) }
    @Test fun ThumbCompilerTests_35() { ThumbCompilerTests("ldr  r1, [r2]", 0x6811) }
    @Test fun ThumbCompilerTests_36() { ThumbCompilerTests("strh r1, [r2]", 0x8011) }
    @Test fun ThumbCompilerTests_37() { ThumbCompilerTests("ldrh r1, [r2]", 0x8811) }
    @Test fun ThumbCompilerTests_38() { ThumbCompilerTests("str  r1, [sp]", 0x9100) }
    @Test fun ThumbCompilerTests_39() { ThumbCompilerTests("ldr  r1, [sp]", 0x9900) }
    @Test fun ThumbCompilerTests_40() { ThumbCompilerTests(".word <bob+10>", 0x8000090) }
    @Test fun ThumbCompilerTests_41() { ThumbCompilerTests("b <bob+10>", 0xE7C6) }
    @Test fun ThumbCompilerTests_42() { ThumbCompilerTests("bl 0x200", 0xF87EF000L) }
    @Test fun ThumbCompilerTests_43() { ThumbCompilerTests("bl 0x08000200", 0xF87EF000L) }
    @Test fun ThumbCompilerTests_44() { ThumbCompilerTests("stmia  r0, {r1}", 0xC002) }
    @Test fun ThumbCompilerTests_45() { ThumbCompilerTests("stm   r0!, {r1}", 0xC002) }
    @Test fun ThumbCompilerTests_46() { ThumbCompilerTests("mov\tr0, #7", 0x2007) }
      @Test fun ThumbLabelWithLeadingDot_Compile_CreatesCorrectCode() {
         var expected = bytes(
            0, 0x48,
            ((-3).u8()), 0xE7,
            0x78, 0x56, 0x34, 0x08,)

         var result = ViewPort.tools!!.codeTool!!.parser.compile(Model, 0, "top:", "ldr r0, .Name", "b top", ".Name:", ".word 0x08345678")

         Assert.equal(expected, result.toTypedArray())
      }
      @Test fun ThumbCompilerLabelTest() {
         var model = PokemonModel(ByteArray(0x200))
         model.observeAnchorWritten(ModelDelta(), "DoStuff", NoInfoRun(0x40))
         var result = parser.compile(model, 0x100, "push lr, {}", "mov r1, #1", "mov r0, #0", "Loop:", "add r0, r0, r1", "cmp r1, #10", "bne <loop>", "bl <DoStuff>", "pop pc, {}")

         var expected = bytes(
            0x00, 0xB5,
            0x01, 0x21,
            0x00, 0x20,
            // loop
            0x40, 0x18,  // 0001100_001_000_000
            0x0A, 0x29,
            0xFC, 0xD1,
            0xFF, 0xF7, 0x98, 0xFF,  // (sbyte)0x98 = -68
            0x00, 0xBD,)

         Assert.equal(expected.size, result.count)
         for (i in 0 until expected.size) Assert.equal(expected[i], result[i])
      }
      @Test fun ThumbCompilerLoadRegisterOffsetTest() {
         var model = PokemonModel(ByteArray(0x200))
         var result = parser.compile(model, 0x100,
                  "    ldr  r0, [pc, <abc>]",
                  "    ldr  r1, [pc, <def>]",
                  "    ldr  r2, [pc, <ghi>]",
                  "    ldr  r3, [pc, <jkl>]",
                  "abc:",
                  "    .word 1234",
                  "def:",
                  "    .word 5678",
                  "ghi:",
                  "    .word 9abc",
                  "jkl:",
                  "    .word def0")

         var expected = bytes(
            0x01, 0x48,
            0x02, 0x49,
            0x02, 0x4A,
            0x03, 0x4B,)

         for (i in 0 until expected.size) Assert.equal(expected[i], result[i])
      }
      @Test fun CanCompileCodeWithNopAlignment() {
         var model = PokemonModel(ByteArray(0x200))
         var result = parser.compile(model, 0x100,
                  "    ldr  r0, [pc, <abc>]",
                  "    mov  r0, #0",
                  "    b    <end>",
                  "abc:",
                  "    .word 1234",
                  "end:",
                  "    pop pc, {}")

         var expected = bytes(
            0x01, 0x48,
            0x00, 0x20,
            0x02, 0xE0,
            0x00, 0x0, // inserted nop to align for .word value
            0x34, 0x12, 0,  0,
            0x00, 0xBD,)

         for (i in 0 until expected.size) Assert.equal(expected[i], result[i])
      }
      @Test fun ThumbCode_InlineLoad_Compiles() {
         var model = PokemonModel(ByteArray(0x200))
         var result = parser.compile(model, 0x100,
            "    ldr  r0, =256",
            "    mov  r0, #0",
            "    b    <end>",
            // implicit nop for alignment
            // implicit .word 256
            "end:",
            "    pop pc, {}")

         var expected = bytes(
            0x01, 0x48,
            0x00, 0x20,
            0x02, 0xE0,
            0x00, 0x0, // inserted nop to align for .word value
            0, 1, 0, 0,        // inserted word
            0x00, 0xBD,)

         for (i in 0 until expected.size) Assert.equal(expected[i], result[i])
      }
      @Test fun ThumbCode_InlineSet_TransformToLoad() {
         var model = PokemonModel(ByteArray(0x200))
         var result = parser.compile(model, 0x100,
            "    r0 = 512",
            "    mov  r0, #0",
            "    b    <end>",
            // implicit nop for alignment
            // implicit .word 256
            "end:",
            "    pop pc, {}")

         var expected = bytes(
            0x01, 0x48,
            0x00, 0x20,
            0x02, 0xE0,
            0, 0,              // inserted nop to align for .word value
            0, 2, 0, 0,        // inserted word
            0x00, 0xBD,)

         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], result[i]) })
      }
      fun ThumbCode_Math_Compiles(math: String, code: String) {
         var model = PokemonModel(ByteArray(0x200))
         model.observeAnchorWritten(newOf(), "table", NoInfoRun(0x80))
         var result = parser.compile(model, 0x100, math)

         var expected = parser.compile(model, 0x100, *code.split(';').toTypedArray())
         Assert.equal(expected, result)
      }
    @Test fun ThumbCode_Math_Compiles_1() { ThumbCode_Math_Compiles("r0 = 3 + 4", "mov r0, #3; add r0, #4") }
    @Test fun ThumbCode_Math_Compiles_2() { ThumbCode_Math_Compiles("r0 = 7 - 3", "mov r0, #7; sub r0, #3") }
    @Test fun ThumbCode_Math_Compiles_3() { ThumbCode_Math_Compiles("r0=12+2", "mov r0, #12; add r0, #2") }
    @Test fun ThumbCode_Math_Compiles_4() { ThumbCode_Math_Compiles("r0=12-2+3", "mov r0, #12; sub r0, #2; add r0, #3") }
    @Test fun ThumbCode_Math_Compiles_5() { ThumbCode_Math_Compiles("r0 += 5", "add r0, #5") }
    @Test fun ThumbCode_Math_Compiles_6() { ThumbCode_Math_Compiles("r0-=5", "sub r0, #5") }
    @Test fun ThumbCode_Math_Compiles_7() { ThumbCode_Math_Compiles("100(r0, 3)", "r1=3;bl <100>") }
    @Test fun ThumbCode_Math_Compiles_8() { ThumbCode_Math_Compiles("r1 = 100() + 3", "bl <100>; mov r1, r0; add r1, #3") }
    @Test fun ThumbCode_Math_Compiles_9() { ThumbCode_Math_Compiles("r1 |= r2", "orr r1, r2") }
    @Test fun ThumbCode_Math_Compiles_10() { ThumbCode_Math_Compiles("r1 ^= r2", "xor r1, r2") }
    @Test fun ThumbCode_Math_Compiles_11() { ThumbCode_Math_Compiles("r1 ^= r2", "eor r1, r2") }
    @Test fun ThumbCode_Math_Compiles_12() { ThumbCode_Math_Compiles("r1 &= r2", "and r1, r2") }
    @Test fun ThumbCode_Math_Compiles_13() { ThumbCode_Math_Compiles("r1 *= r2", "mul r1, r2") }
    @Test fun ThumbCode_Math_Compiles_14() { ThumbCode_Math_Compiles("r1 <<= r2", "lsl r1, r2") }
    @Test fun ThumbCode_Math_Compiles_15() { ThumbCode_Math_Compiles("r1 >>= r2", "lsr r1, r2") }
    @Test fun ThumbCode_Math_Compiles_16() { ThumbCode_Math_Compiles("r1 >>= 2", "lsr r1, #2") }
    @Test fun ThumbCode_Math_Compiles_17() { ThumbCode_Math_Compiles("lsr r1, #2", "lsr r1, r1, #2") }
    @Test fun ThumbCode_Math_Compiles_18() { ThumbCode_Math_Compiles("r0 = <table>", "ldr r0, =<table>") }
      @Test fun ThumbCode_InlineLoadLastSection_Compiles() {
         var model = PokemonModel(ByteArray(0x200))
         var result = parser.compile(model, 0x100,
            "    push {lr}",
            "    ldr  r0, =1",
            "    pop  {pc}").toTypedArray()

         var expected = bytes(
            0x00, 0xB5,
            0x01, 0x48,
            0x00, 0xBD,
            0, 0,              // nop
            1, 0, 0, 0,)

         Assert.equal(expected, result)
      }
      @Test fun ThumbCode_InlinePointerLoad_Compiles() {
         Model.observeAnchorWritten(ModelDelta(), "destination", NoInfoRun(0x20))
         var result = parser.compile(ModelDelta(), Model, 0x100,
            "    ldr  r0, =<destination>",
            "    mov  r0, #0",
            "    b    <end>",
            // implicit nop for alignment
            // implicit .word <destination>
            "end:",
            "    pop pc,  {}")

         var expected = bytes(
            0x01, 0x48,
            0x00, 0x20,
            0x02, 0xE0,
            0x00, 0x0, // inserted nop to align for .word value
            0x20, 0, 0, 8,     // inserted word
            0x00, 0xBD,)

         // assert that the data is correct
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], result[i]) })

         // assert that a pointer run has been added
         var pointerRun = Model.getNextRun(0x100)
         Assert.equal(0x108, pointerRun.start)
         Assert.isType<PointerRun>(pointerRun)
      }
      @Test fun ThumbCode_OverwritePointer_RemovePointerRun() {
         ViewPort.edit("<100>")
         var tools = ViewPort.tools
         tools!!.selectedIndex  = tools!!.indexOf(tools!!.codeTool)
         tools!!.codeTool!!.mode  = CodeMode.Thumb
         ViewPort.selectionStart  = Point(0, 0)

         tools!!.codeTool!!.content  = "push lr" + "\n" + "pop pc"

         // pointer run should be removed
         Assert.notEqual(0, Model.getNextRun(0).start)
      }
      @Test fun ThumbCode_MultipleInlineLoads_OnlyOneValueAdded() {
         var model = PokemonModel(ByteArray(0x200))
         model.observeAnchorWritten(ModelDelta(), "destination", NoInfoRun(0x20))
         var result = parser.compile(model, 0x100,
            "    ldr  r0, =256",
            "    ldr  r0, =256",
            "    b    <end>",
            // implict nop for alignment
            // implicit .word 256 (only once!)
            "end:",
            "    pop pc,  {}")

         var expected = bytes(
            0x01, 0x48, // payload is 4 instructions away: ceil(4/2)-1 = 0x01
            0x01, 0x48, // payload is 3 instructions away: ceil(3/2)-1 = 0x01
            0x02, 0xE0,
            0, 0,              // inserted nop to align for .word value
            0, 1, 0, 0,        // word inserted only once
            0x00, 0xBD,)

         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], result[i]) })
      }
      @Test fun ThumbCode_InlineWithOffset_Compiles() {
         var model = PokemonModel(ByteArray(0x200))
         var result = parser.compile(model, 0x100,
            "    ldr  r0, =(0xFF+1)",
            "    mov  r0, #0",
            "    b    <end>",
            // implicit nop for alignment
            // implicit .word 256
            "end:",
            "    pop pc, {}")

         var expected = bytes(
            0x01, 0x48,
            0x00, 0x20,
            0x02, 0xE0,
            0x00, 0x0, // inserted nop to align for .word value
            0, 1, 0, 0,        // inserted word
            0x00, 0xBD,)

         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], result[i]) })
      }
      @Test fun RawCodeToolWorks() {
         var viewPort = ViewPort(LoadedFile("file.txt", ByteArray(100))).also { it.tools!!.codeTool!!.isSelected = true }
         viewPort.tools!!.codeTool!!.mode  = CodeMode.Raw
         viewPort.selectionEnd  = Point(3, 0)
         Assert.equal("00 00 00 00", viewPort.tools!!.codeTool!!.content.trim())
      }
      @Test fun TableToolContainsListOfAllTables() {
         var test = BaseViewModelTestClass()

         test.ViewPort.edit("^table1[data\"\"6]4 @30 ^table2[data\"\"6]4 ")
         Assert.equal(2, test.ViewPort.tools!!.tableTool!!.tableSections.count())

         test.ViewPort.tools!!.tableTool!!.selectedTableSection  = 1
         Assert.equal("000030", test.ViewPort.headers!![0])
      }
      @Test fun TextToolSearchTest() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("FF @00 ^text\"\" Hello World Worble!")
         test.ViewPort.selectionStart  = Point()
         var tool = test.ViewPort.tools!!.stringTool

         tool!!.searchText  = "wor"
         tool!!.search.execute()
         Assert.equal(6, tool!!.contentIndex)
         Assert.equal(3, tool!!.contentSelectionLength)

         tool!!.search.execute()
         Assert.equal(12, tool!!.contentIndex)
         Assert.equal(3, tool!!.contentSelectionLength)
      }
      @Test fun ToolSelectionDoesNotAutoChangeForCodeToolHexView() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("FF @00 ^text\"\" Hello World!")
         test.ViewPort.tools!!.codeToolCommand.execute()
         test.ViewPort.tools!!.codeTool!!.mode  = CodeMode.Raw

         test.ViewPort.selectionStart  = Point(0, 1)
         test.ViewPort.selectionStart  = Point(0, 0)

         Assert.equal(test.ViewPort.tools!!.codeTool, test.ViewPort.tools!!.selectedTool)
      }
      @Test fun NextElementInTableToolWorksEvenIfOtherDataIsCurrentlySelected() {
         ViewPort.edit("^table[data<>]3 <020> <030> <040> @04 ")
         ViewPort.expandSelection(0, 0); // follows the pointer to 030
         var tableTool = ViewPort.tools!!.tableTool

         ViewPort.tools!!.selectedIndex  = ViewPort.tools!!.indexOf(tableTool!!)
         tableTool!!.next.execute()

         Assert.endsWith("/2", tableTool!!.currentElementName)
      }
      @Test fun ClearTable_CheckTableTool_NoTable() {
         CreateTextTable("names", 0, "adam", "bob", "carl", "dave")

         ViewPort.goto!!.execute(0)
         ViewPort.getContextMenuItems(Point(0, 0))
            .single({ item -> item.text == "Clear Format" })
            .command.execute()

         var tableTool = ViewPort.tools!!.tableTool
         Assert.equal(0, tableTool!!.address)
         Assert.empty(tableTool!!.children)
      }
      @Test fun PointerTable_ThreePointersToSameText_CanRepointAll() {
         SetFullModel(0xFF)
         ViewPort.edit("^text\"\" Test\" @010!00(12) ^table[name<\"\">]3 <text> <text> <text>")

         ViewPort.goto!!.execute(0x10)

         var element = ViewPort.tools!!.tableTool!!.children.firstOfType<IStreamArrayElementViewModel>()
         Assert.isTrue(element.canRepointAll)
      }
      @Test fun PointerTable_TwoPointersToSameText_CannotRepointAll() {
         SetFullModel(0xFF)
         ViewPort.edit("^text\"\" Test\" @010!00(12) ^table[name<\"\">]2 <text> <text>")

         ViewPort.goto!!.execute(0x10)

         var element = ViewPort.tools!!.tableTool!!.children.firstOfType<IStreamArrayElementViewModel>()
         Assert.isFalse(element.canRepointAll)
      }
      @Test fun PointerTable_RepointAll_NoPointersShareTheSameValue() {
         SetFullModel(0xFF)
         ViewPort.edit("^text\"\" Test\" @010!00(12) ^table[name<\"\">]3 <text> <text> <text>")

         ViewPort.goto!!.execute(0x10)
         var element = ViewPort.tools!!.tableTool!!.children.firstOfType<IStreamArrayElementViewModel>()
         element.repointAll.execute()

         var set = LinkedHashSet<Int>()
         set.add(Model.readPointer(0x10))
         set.add(Model.readPointer(0x14))
         set.add(Model.readPointer(0x18))

         Assert.equal(3, set.size)
      }
      @Test fun TableTool_FilterTupleFieldName_TupleVisible() {
         var tool = ViewPort.tools!!.tableTool
         tool!!.groups.clear()
         tool!!.groups.add(newOf(ViewPort))
         var section = SplitterArrayElementViewModel(ViewPort, "section", 0)
         var tuple = TupleArrayElementViewModel(ViewPort, ArrayRunTupleSegment("tuples", "|abc:|def:|ijk:|xyz:", 4), 0)

         tool!!.groups[0].members.add(section)
         tool!!.groups[0].members.add(tuple)

         section.updateCollapsed("ijk")

         Assert.isTrue(tuple.visible)
      }
      @Test fun AllZeroes_FindLength_Zero() {
         Model[0x40]  = 0x02; // end command

         var length = ViewPort.tools!!.codeTool!!.scriptParser.findLength(Model, 0)

         Assert.equal(0, length)
      }
      @Test fun AllZeroes_DecodeAsScript_NotManyNops() {
         Model[0x40]  = 0x02; // end command

         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script
         ViewPort.tools!!.codeTool!!.updateContent()
         var content = ViewPort.tools!!.codeTool!!.contents[0].content

         Assert.single(content.split("\n"))
      }
      @Test fun ExcessLabels_Compile_RightBytes() {
         var expected = "01 48 00 00 00 00 00 00 11 11 11 11".parseHexBytes()

         var results = parser.compile(Model, 0,
            "ldr r0, bob",
            "nop",
            "nop",
            "label:",
            "bob: .word 0x11111111")

         Assert.equal(expected, results)
      }
      @Test fun LdrInlineAddition_Compile_AdditionPerformed() {
         var expected = parser.compile(Model, 0, "ldr r0, =0x11")
         var actual = parser.compile(Model, 0, "ldr r0, =0x10+1")
         Assert.equal(expected, actual)
      }
      @Test fun NotAligned_WriteLdrWithDynamicWord_CompilesToCorrectAddress() {
         parser.compile(Token, Model, 2, "ldr r0, =0", "bx r0")

         var lines = parser.parse(Model, 2, 10).splitLines(); // ldr, bx, nop, .word
         Assert.contains("ldr", lines[1])
         Assert.contains("8>", lines[1])
      }
      @Test fun TableWithNullPointer_LoadTableTool_CannotJumpToNull() {
         ViewPort.edit("^table[ptr<>]1 ")
         ViewPort.refresh()

         var field = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<FieldArrayElementViewModel>()

         Assert.isFalse(field.canAccept())
      }
      @Test fun TableWithNullPointer_ReloadTableTool_NotifyCannotAccept() {
         ViewPort.edit("^table[ptr<>]2 <100> @000 ")
         ViewPort.refresh()
         var field = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<FieldArrayElementViewModel>()
         var counter = 0
         field.canAcceptChanged  += { sender, e -> counter  += 1 }

         ViewPort.tools!!.tableTool!!.next.execute()

         Assert.equal(1, counter)
      }
      @Test fun PointerToThumbRoutinePlusOne_EditThumb_StillPointer() {
         ViewPort.edit("@100 <011> ")

         ViewPort.edit("@10 .thumb\n            push {lr}\n            pop  {pc}\n         .end")

         Assert.isType<PointerRun>(Model.getNextRun(0x100))
      }
      @Test fun LdrToAnchorPlusOneOutsideBraces_Compile_PointerIsCorrect() {
         Model.observeAnchorWritten(Token, "anchor", NoInfoRun(0x100))

         ViewPort.tools!!.codeTool!!.parser.compile(Token, Model, 0, "ldr r0, =<anchor>+1", "bx r0")

         Assert.equal(0x101, Model.readPointer(4))
      }
      @Test fun LdrToAnchorPlusOneInsideBraces_Compile_PointerIsCorrect() {
         Model.observeAnchorWritten(Token, "anchor", NoInfoRun(0x100))

         ViewPort.tools!!.codeTool!!.parser.compile(Token, Model, 0, "ldr r0, =<anchor+1>", "bx r0")

         Assert.equal(0x101, Model.readPointer(4))
      }
      fun ScriptWithGameSpecificCommand_Compile_Works(gameCode: String, script: String, bytes: String) {
         SetGameCode(gameCode)
         ViewPort.tools!!.codeTool!!.scriptParser.refreshGameHash(Model)
         var parser = ViewPort.tools!!.codeTool!!.scriptParser

         var compiled = parser.compile(Token, Model, 0, Ref(script), Ref(nullOf()))

         Assert.equal(bytes.parseHexBytes(), compiled)
      }
    @Test fun ScriptWithGameSpecificCommand_Compile_Works_1() { ScriptWithGameSpecificCommand_Compile_Works("BPRE0", "updatemoney 1 1 1\r\nend", "95 01 01 01 02") }
    @Test fun ScriptWithGameSpecificCommand_Compile_Works_2() { ScriptWithGameSpecificCommand_Compile_Works("AXPE0", "updatemoney 1 1\r\nend", "95 01 01 02") }
      fun ScriptWithGameSpecificCommand_Decompile_Works(gameCode: String, script: String, bytes: String) {
         SetGameCode(gameCode)
         ViewPort.tools!!.codeTool!!.scriptParser.refreshGameHash(Model)
         var code = bytes.parseHexBytes()
         Token.changeData(Model, 0, code)

         var text = ViewPort.tools!!.codeTool!!.scriptParser.parse(Model, 0, code.size)

         var expected = script.splitLines().trimAll().toTypedArray()
         var actual = text.splitLines().trimAll().toTypedArray()
         Assert.equal(expected, actual)
      }
    @Test fun ScriptWithGameSpecificCommand_Decompile_Works_1() { ScriptWithGameSpecificCommand_Decompile_Works("BPRE0", "updatemoney 1 1 1\r\nend", "95 01 01 01 02") }
    @Test fun ScriptWithGameSpecificCommand_Decompile_Works_2() { ScriptWithGameSpecificCommand_Decompile_Works("AXPE0", "updatemoney 1 1\r\nend", "95 01 01 02") }
      fun HexConverter_HexOperators_DoMath(input: String, output: String) {
         var editor = EditorViewModel(FileSystem, InstantDispatch.instance, false)
         editor.hexText  = input
         Assert.equal(output, editor.decText)
      }
    @Test fun HexConverter_HexOperators_DoMath_1() { HexConverter_HexOperators_DoMath("10+10", "32") }
    @Test fun HexConverter_HexOperators_DoMath_2() { HexConverter_HexOperators_DoMath("10-8", "8") }
    @Test fun HexConverter_HexOperators_DoMath_3() { HexConverter_HexOperators_DoMath("18-8+10", "32") }
      fun HexConverter_DecimalOperators_DoMath(input: String, output: String) {
         var editor = EditorViewModel(FileSystem, InstantDispatch.instance, false)
         editor.decText  = input
         Assert.equal(output, editor.hexText)
      }
    @Test fun HexConverter_DecimalOperators_DoMath_1() { HexConverter_DecimalOperators_DoMath("10+10", "14") }
    @Test fun HexConverter_DecimalOperators_DoMath_2() { HexConverter_DecimalOperators_DoMath("10-8", "2") }
    @Test fun HexConverter_DecimalOperators_DoMath_3() { HexConverter_DecimalOperators_DoMath("18-8+10", "14") }
      @Test fun FreeSpace_InsertNewText_ReasonableDefaultName() {
         SetFullModel(0xFF)
         SetGameCode("FAKE0")
         ViewPort.goto!!.execute(0x10)

         ViewPort.tools!!.stringTool!!.insertText.execute()

         var name = Model.getAnchorFromAddress(-1, 0x10)
         Assert.equal("scripts.text.FAKE0000010", name)
      }
      @Test fun Thumb_GetValueFromTable_Compiles() {
         ViewPort.edit("^some.table[a: b: c::]3 ")

         var actual = ViewPort.tools!!.codeTool!!.parser.compile(Model, 0x100, "r0 = some.table[r1].b")
         var expected = ViewPort.tools!!.codeTool!!.parser.compile(Model, 0x100,
            "push {r1}",
            "r0 = 8",          // width of element
            "r0 *= r1",
            "r1 = 0x08000000", // table start
            "r0 += r1",
            "r1 = 2",          // index of requested field
            "ldrh r0, [r0, r1]",
            "pop {r1}")

         Assert.equal(expected, actual)
      }
   }
