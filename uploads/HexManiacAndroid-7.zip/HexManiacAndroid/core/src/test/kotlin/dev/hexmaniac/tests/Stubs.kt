@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.viewmodels.tools.*

/** Test-only stand-ins for the AutoImplement generated Stub* classes of the C# project. */

open class StubFileSystem : IFileSystem {
    override var copyText: String? = null
    override var copyImage: IFileSystemCopyImageTuple = IFileSystemCopyImageTuple(ShortArray(0), 0)

    var requestNewName: ((String, String?, Array<out String>) -> String?)? = null
    var openFile: ((String?, Array<out String>) -> LoadedFile?)? = null
    var openFolder: (() -> String?)? = null
    var exists: ((String) -> Boolean)? = null
    var launchProcess: ((String, String?) -> Unit)? = null
    var loadFile: ((String) -> LoadedFile?)? = null
    var addListenerToFile: ((String, (IFileSystem) -> Unit) -> Unit)? = null
    var removeListenerForFile: ((String, (IFileSystem) -> Unit) -> Unit)? = null
    var save: ((LoadedFile) -> Boolean)? = null
    var saveMetadata: ((String, Array<String>?) -> Boolean)? = null
    var trySavePrompt: ((LoadedFile) -> Boolean?)? = null
    var metadataFor: ((String) -> Array<String>?)? = null
    var loadImage: ((String?) -> IFileSystemLoadImageTuple)? = null
    var saveImage: ((ShortArray, Int, String?) -> Unit)? = null
    var saveIndexedImage: ((Array<IntArray>, List<Short>, String?) -> Unit)? = null
    var tryLoadIndexImage: ((Ref<String?>, Ref<Array<IntArray>?>, Ref<List<Short>?>) -> Boolean)? = null
    var showOptions: ((String, String, List<List<Any>>?, Array<out VisualOption>) -> Int)? = null
    var requestText: ((String, String) -> String?)? = null
    var showCustomMessageBox: ((String, Boolean, Array<out ProcessModel>) -> Boolean?)? = null

    override fun requestNewName(currentName: String, extensionDescription: String?, vararg extensionOptions: String): String? =
        requestNewName?.invoke(currentName, extensionDescription, extensionOptions)
    override fun openFile(extensionDescription: String?, vararg extensionOptions: String): LoadedFile? =
        openFile?.invoke(extensionDescription, extensionOptions)
    override fun openFolder(): String? = openFolder?.invoke()
    override fun exists(file: String): Boolean = exists?.invoke(file) ?: false
    override fun launchProcess(file: String, arguments: String?) { launchProcess?.invoke(file, arguments) }
    override fun loadFile(fileName: String): LoadedFile? = loadFile?.invoke(fileName)
    override fun addListenerToFile(fileName: String, listener: (IFileSystem) -> Unit) { addListenerToFile?.invoke(fileName, listener) }
    override fun removeListenerForFile(fileName: String, listener: (IFileSystem) -> Unit) { removeListenerForFile?.invoke(fileName, listener) }
    override fun save(file: LoadedFile): Boolean = save?.invoke(file) ?: false
    override fun saveMetadata(originalFileName: String, metadata: Array<String>?): Boolean = saveMetadata?.invoke(originalFileName, metadata) ?: false
    override fun trySavePrompt(file: LoadedFile): Boolean? = trySavePrompt?.invoke(file)
    override fun metadataFor(fileName: String): Array<String>? = metadataFor?.invoke(fileName)
    override fun loadImage(fileName: String?): IFileSystemLoadImageTuple = loadImage?.invoke(fileName) ?: IFileSystemLoadImageTuple(null, 0)
    override fun tryLoadIndexedImage(fileName: Ref<String?>, image: Ref<Array<IntArray>?>, palette: Ref<List<Short>?>): Boolean = tryLoadIndexImage?.invoke(fileName, image, palette) ?: false
    override fun saveImage(image: ShortArray, width: Int, fileName: String?) { saveImage?.invoke(image, width, fileName) }
    override fun saveImage(image: Array<IntArray>, palette: List<Short>, fileName: String?) { saveIndexedImage?.invoke(image, palette, fileName) }
    override fun showOptions(title: String, prompt: String, additionalDetails: List<List<Any>>?, vararg options: VisualOption): Int =
        showOptions?.invoke(title, prompt, additionalDetails, options) ?: 0
    override fun requestText(title: String, prompt: String): String? = requestText?.invoke(title, prompt)
    override fun showCustomMessageBox(message: String, showYesNoCancel: Boolean, vararg links: ProcessModel): Boolean? =
        showCustomMessageBox?.invoke(message, showYesNoCancel, links)
}

open class StubMetadataInfo : IMetadataInfo {
    override var versionNumber: String? = null
    override var isPublicRelease: Boolean = false
}

open class StubQuickEditItem : IQuickEditItem {
    override var name: String? = null
    override var description: String? = null
    override var wikiLink: String? = null
    override val canRunChanged = Event<EventArgs>()
    var canRun: ((IViewPort) -> Boolean)? = null
    var run: ((IViewPort) -> Task<ErrorInfo>?)? = null
    var tabChanged: (() -> Unit)? = null
    override fun canRun(viewPort: IViewPort): Boolean = canRun?.invoke(viewPort) ?: false
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? = run?.invoke(viewPort)
    override fun tabChanged() { tabChanged?.invoke() }
}

open class StubTabContent : ITabContent {
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override var name: String = ""
    override var isMetadataOnlyChange: Boolean = false
    override var save: ICommand? = null
    override var saveAs: ICommand = StubCommand()
    override var exportBackup: ICommand = StubCommand()
    override var undo: ICommand = StubCommand()
    override var redo: ICommand = StubCommand()
    override var copy: ICommand? = null
    override var deepCopy: ICommand = StubCommand()
    override var clear: ICommand? = null
    override var selectAll: ICommand = StubCommand()
    override var goto: ICommand? = null
    override var resetAlignment: ICommand = StubCommand()
    override var back: ICommand = StubCommand()
    override var forward: ICommand = StubCommand()
    override var close: ICommand = StubCommand()
    override var diff: ICommand = StubCommand()
    override var diffLeft: ICommand = StubCommand()
    override var diffRight: ICommand = StubCommand()
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override var spartanMode: Boolean = false
    override var canIpsPatchRight: Boolean = false
    override var canUpsPatchRight: Boolean = false
    override var canDuplicate: Boolean = false
    var ipsPatchRight: (() -> Unit)? = null
    var upsPatchRight: (() -> Unit)? = null
    var duplicate: (() -> Unit)? = null
    var refresh: (() -> Unit)? = null
    var tryImport: ((LoadedFile, IFileSystem) -> Boolean)? = null
    override fun ipsPatchRight() { ipsPatchRight?.invoke() }
    override fun upsPatchRight() { upsPatchRight?.invoke() }
    override fun duplicate() { duplicate?.invoke() }
    override fun refresh() { refresh?.invoke() }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean = tryImport?.invoke(file, fileSystem) ?: false
}

open class StubViewPort : StubTabContent(), IViewPort {
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    override val previewScrollChanged = Event<EventArgs>()
    override val requestCloseOtherViewports = Event<IDataModel>()
    override var toolPanelWidth: Double = 0.0
    override var fileName: String = ""
    override var fullFileName: String = ""
    override var width: Int = 0
    override var height: Int = 0
    override var autoAdjustDataWidth: Boolean = false
    override var stretchData: Boolean = false
    override var allowMultipleElementsPerLine: Boolean = false
    override var base10Length: Boolean = false
    override var useCustomHeaders: Boolean = false
    override var minimumScroll: Int = 0
    override var scrollValue: Int = 0
    override var maximumScroll: Int = 0
    override var headers: ObservableCollection<RowHeader>? = null
    override var columnHeaders: ObservableCollection<ColumnHeaderRow> = ObservableCollection()
    override var dataOffset: Int = 0
    override var scroll: ICommand = StubCommand()
    override var progress: Double = 0.0
    override var updateInProgress: Boolean = false
    override var canFindFreeSpace: Boolean = false
    override var selectedAddress: String = ""
    override var selectedBytes: String? = null
    override var anchorText: String = ""
    override var anchorTextVisible: Boolean = false
    override var findBytes: ByteArray? = null
    override var model: IDataModel? = null
    override var hasTools: Boolean = false
    override var changeHistory: ChangeHistory<ModelDelta> = ChangeHistory<ModelDelta>({ t -> t }, 100, { ModelDelta() })
    override var tools: IToolTrayViewModel? = null
    var find: ((String, Boolean) -> List<IViewPortFindTuple>)? = null
    var getElement: ((Int, Int) -> HexElement)? = null
    var modelFor: ((Point) -> IDataModel?)? = null
    var isSelected: ((Point) -> Boolean)? = null
    var isTable: ((Point) -> Boolean)? = null
    var findFreeSpace: ((IFileSystem) -> Unit)? = null
    var createChildView: ((Int, Int) -> IChildViewPort)? = null
    var followLink: ((Int, Int) -> Unit)? = null
    var expandSelection: ((Int, Int) -> Unit)? = null
    var considerReload: ((IFileSystem) -> Unit)? = null
    var findAllSources: ((Int, Int) -> Unit)? = null
    var getContextMenuItems: ((Point) -> List<IContextItem>)? = null
    override operator fun get(x: Int, y: Int): HexElement = getElement?.invoke(x, y) ?: HexElement(0, false, None.instance)
    override fun modelFor(point: Point): IDataModel? = modelFor?.invoke(point) ?: model
    override fun isSelected(point: Point): Boolean = isSelected?.invoke(point) ?: false
    override fun isTable(point: Point): Boolean = isTable?.invoke(point) ?: false
    override fun find(search: String, matchExactCase: Boolean): List<IViewPortFindTuple> = find?.invoke(search, matchExactCase) ?: emptyList()
    override fun findFreeSpace(fileSystem: IFileSystem) { findFreeSpace?.invoke(fileSystem) }
    override fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort = createChildView?.invoke(startAddress, endAddress) ?: throw NotImplementedError()
    override fun followLink(x: Int, y: Int) { followLink?.invoke(x, y) }
    override fun expandSelection(x: Int, y: Int) { expandSelection?.invoke(x, y) }
    override fun considerReload(fileSystem: IFileSystem) { considerReload?.invoke(fileSystem) }
    override fun findAllSources(x: Int, y: Int) { findAllSources?.invoke(x, y) }
    override fun getContextMenuItems(point: Point, fileSystem: IFileSystem?): List<IContextItem> = getContextMenuItems?.invoke(point) ?: emptyList()
}

/** Core/StubView.cs: records the notifications raised by a view model. Uses Java reflection on the getters. */
class StubView(viewModel: INotifyPropertyChanged) {
    val propertyNotifications = ArrayList<String>()
    val commandCanExecuteChangedNotifications = ArrayList<String>()
    val eventNotifications = ArrayList<String>()

    init {
        viewModel.propertyChanged += { _, e -> propertyNotifications.add(e.propertyName ?: "") }
        for (m in viewModel.javaClass.methods) {
            if (m.parameterCount != 0 || !m.name.startsWith("get") || m.name.length < 4) continue
            val propName = m.name.substring(3, 4).lowercase() + m.name.substring(4)
            try {
                if (ICommand::class.java.isAssignableFrom(m.returnType)) {
                    val command = m.invoke(viewModel) as? ICommand ?: continue
                    command.canExecuteChanged += { _, _ -> commandCanExecuteChangedNotifications.add(propName) }
                } else if (m.returnType == Event::class.java) {
                    val ev = m.invoke(viewModel) as? Event<Any?> ?: continue
                    if (propName == "propertyChanged") {
                        (ev as Event<PropertyChangedEventArgs>) += { _, _ -> eventNotifications.add(propName) }
                    } else {
                        ev += { _, _ -> eventNotifications.add(propName) }
                    }
                }
            } catch (ex: Exception) {
                // failed to add event handler, that's ok
            }
        }
    }
}
