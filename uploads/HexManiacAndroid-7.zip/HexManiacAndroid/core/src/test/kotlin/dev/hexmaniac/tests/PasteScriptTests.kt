@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class PasteScriptTests : BaseViewModelTestClass() {
      @Test fun ThumbPasteScript_Paste_Compiles() {
         ViewPort.edit("\n@10\n.thumb\npush {lr}\npop  {pc}\n.end\n30\n")

         Assert.equal(0xB500, Model.readMultiByteValue(0x10, 2))
         Assert.equal(0xBD00, Model.readMultiByteValue(0x12, 2))
         Assert.equal(0x30, Model[0x14])
      }
      @Test fun ThumbPasteScript_OddOffset_WordsAlignCorrectly() {
         ViewPort.edit("\n@12\n.thumb\n  b <12>\ncontent:\n  .word 0x08123456\n.end\n")

         var expectedBranchCommand = ViewPort.tools!!.codeTool!!.parser.compile(Model, 0x12, "b <12>").readMultiByteValue(0, 2)
         var actualBranchCommand = Model.readMultiByteValue(0x12, 2)
         Assert.equal(expectedBranchCommand, actualBranchCommand)
         Assert.equal(0x08123456, Model.readMultiByteValue(0x14, 4))
      }
      @Test fun Run_Paste00DirectiveWithSameFormat_NoError() {
         arrayCopy(PCSString.convert("Hello World")!!, Model.rawData, 12)
         Model.observeRunWritten(ModelDelta(), PCSRun(Model, 0, 12))
         ViewPort.refresh()

         ViewPort.edit("@!00(12) ^anchor\"\" ")

         Assert.empty(Errors)
      }
      @Test fun TableWithPointer_ClearPointer_ClearAnchor() {
         ViewPort.edit("^table[pointer<>]1 <010> ")

         ViewPort.edit("@000 @!00(4) ")

         var run = Model.getNextRun(0x10)
         Assert.notEqual(0x10, run.start)
      }
   }
