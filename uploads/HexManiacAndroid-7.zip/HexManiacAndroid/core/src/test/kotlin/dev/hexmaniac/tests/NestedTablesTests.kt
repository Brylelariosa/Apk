@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class NestedTablesTests {
      private lateinit var viewPort: ViewPort
      private lateinit var model: PokemonModel
      private var token: ModelDelta = ModelDelta()
      private var data: ByteArray = ByteArray(0x200)
      private var messages: MutableList<String> = ArrayList<String>()
      private var errors: MutableList<String> = ArrayList<String>()

      init {
         model  = PokemonModel(data)
         viewPort  = ViewPort("file.txt", model, InstantDispatch.instance).also { it.allowMultipleElementsPerLine = true; it.width = 0x10; it.height = 0x10 }
         viewPort.onError  += { sender, e -> errors.add(e) }
         viewPort.onMessage  += { sender, e -> messages.add(e) }
      }
      @Test fun SupportNestedTextStreams() {
         val table = Ref<ITableRun?>(null)
         // can parse
         var info = ArrayRun.tryParse(model, "[description<\"\">]4", 0, null, table)
         Assert.isFalse(info.hasError)

         model.observeAnchorWritten(token, "table", table.value!!)

         // displays pointers
         viewPort.goto!!.execute("000100")
         viewPort.goto!!.execute("000000")
         Assert.isType<Pointer>(viewPort[4, 0].format)

         // can't update to point to non-text
         viewPort.selectionStart  = Point(5, 0)
         errors.clear()
         viewPort.edit("000100 "); // expected failure point
         Assert.single(errors)

         // can update to point to text
         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("FF"); // have to put the FF first, or trying to create a text run will fail
         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("^text\"\" Hello World!\"")
         viewPort.selectionStart  = Point(5, 0)
         errors.clear()
         viewPort.edit("000040 ")
         Assert.empty(errors)

         // can update to point to null
         viewPort.selectionStart  = Point(5, 0)
         errors.clear()
         viewPort.edit("null ")
         Assert.empty(errors)
      }
      @Test fun SupportChangingPointerToWhereAFormatCouldBe() {
         viewPort.edit("FF"); // have to put the FF first, or trying to create a text run will fail
         viewPort.moveSelectionStart.execute(Direction.Left)
         viewPort.edit("^text1\"\" Hello World!\"")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^ "); // remove the format. So we have text data, but no format for it.

         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("FF"); // have to put the FF first, or trying to create a text run will fail
         viewPort.moveSelectionStart.execute(Direction.Left)
         viewPort.edit("^text2\"\" Other Text\"")
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^text2 "); // remove the format, but keep the anchor

         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("^table[description<\"\">]4 ")
         viewPort.goto!!.execute("000000");  // scroll back: making a table auto-scrolled
         viewPort.selectionStart  = Point(0, 4)
         errors.clear()

         // test 1: pointing to data that is the right format, but with no anchor, works
         viewPort.edit("000000 ")
         Assert.empty(errors)
         Assert.isType<PCS>(viewPort[1, 0].format)

         // test 2: pointing to data that is the right format, but with a NoInfo anchor, works
         viewPort.edit("text2 ")
         Assert.empty(errors)
         Assert.isType<PCS>(viewPort[1, 2].format)
      }
      @Test fun SupportAutomaticallyAddingFormatsBasedOnPointerFormat() {
         viewPort.edit("FF"); // have to put the FF first, or trying to create a text run will fail
         viewPort.moveSelectionStart.execute(Direction.Left)
         viewPort.edit("^text\"\" Some Text\"")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^ "); // remove the anchor. Keeps the data though.

         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("00 00 00 08")
         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("^table[description<\"\">]4 "); // adding this should automatically add a format at 000000, since a pointer points there.

         viewPort.goto!!.execute("000000"); // scroll back to top
         Assert.isType<PCSRun>(model.getNextRun(0))
      }
      @Test fun AddTableSuchThatPointerLeadsToBadDataDoesNotAddFormat() {
         viewPort.edit("10 00 00 08"); // point to second line, which is all zeros
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^table[description<\"\">]4 "); // adding this tries to add a format at the second line, but realizes that it's the wrong format, so it doesn't.

         Assert.isType<None>(viewPort[1, 1].format) // no PCS format was added
      }
      @Test fun TableToolAllowsEditingTextContent() {
         viewPort.edit("FF"); // have to put the FF first, or trying to create a text run will fail
         viewPort.moveSelectionStart.execute(Direction.Left)
         viewPort.edit("^text\"\" Some Text\"")

         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("^table[description<\"\">]4 <000000>"); // note that this auto-scrolls, since a table was created
         viewPort.moveSelectionStart.execute(Direction.Left);  // select the pointer we just completed

         Assert.equal(3, viewPort.tools!!.tableTool!!.children.size); // header, pointer, content
         Assert.isType<TextStreamElementViewModel>(viewPort.tools!!.tableTool!!.children[2])
      }
      @Test fun UpdateViaToolStreamFieldThatCausesMoveAlsoUpdatesToolPointerField() {
         viewPort.edit("FF 00 23"); // put a valid end, then a spare byte, then some junk. This'll cause a move after adding enough characters.
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^text\"\" ?\"")

         viewPort.selectionStart  = Point(0, 4)
         viewPort.edit("^table[description<\"\">]4 <000000>"); // note that this auto-scrolls, since a table was created
         viewPort.selectionStart  = Point(0, 0)
         var textViewModel = (viewPort.tools!!.tableTool!!.children.single({ child -> child is TextStreamElementViewModel }) as TextStreamElementViewModel)

         // act: use the tool to change the content, forcing a repoint
         messages.clear()
         textViewModel.content  = "Xyz"
         var pointerViewModel = (viewPort.tools!!.tableTool!!.children.single({ child -> child is FieldArrayElementViewModel }) as FieldArrayElementViewModel)

         Assert.single(messages);                               // we repointed
         Assert.notEqual("<000000>", pointerViewModel.content) // other tool field was updated
      }
      @Test fun SupportsUnnamedPlmStreams() {
         model.writeMultiByteValue(0x100, 2, ModelDelta(), 0x0202); // move two at level 1
         model.writeMultiByteValue(0x102, 2, ModelDelta(), 0x1404); // move four at level 10 (8+2, shifted once -> 14)
         model.writeMultiByteValue(0x104, 2, ModelDelta(), 0xFFFF); // end stream
         viewPort.edit("<000100>"); // setup something to point at 000100, so we can have an unnamed stream there

         SetupMoveTable(0x20)
         viewPort.goto!!.execute("000100")

         errors.clear()
         viewPort.edit("^`plm`")

         Assert.empty(errors)
         var run = model.getNextRun(0x100)
         Assert.isType<PLMRun>(run)
         Assert.equal(6, run.length)
         var format = ((viewPort[1, 0].format) as PlmItem)
         Assert.equal(1, format.level)
         Assert.equal(2, format.move)
         Assert.equal("Two", format.moveName)

         viewPort.selectionStart  = Point(1, 0)
         Assert.isTrue(viewPort.isSelected(Point(0, 0)))
      }
      @Test fun PlmStreamAutocomplete() {
         SetupMoveTable(0x20); // goes from 20 to 60
         viewPort.goto!!.execute("000070")

         viewPort.edit("FFFF")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^stream`plm` 3 T"); // Two, Three
         var format = ((viewPort[0, 0].format) as UnderEdit)
         Assert.equal(2, format.autocompleteOptions!!.size)
      }
      @Test fun PlmStreamBackspaceWorks() {
         model.writeMultiByteValue(0x100, 2, ModelDelta(), 0x0202); // move two at level 1
         model.writeMultiByteValue(0x102, 2, ModelDelta(), 0x1404); // move four at level 10 (8+2, shifted once -> 14)
         model.writeMultiByteValue(0x104, 2, ModelDelta(), 0xFFFF); // end stream
         viewPort.edit("<000100>"); // setup something to point at 000100, so we can have an unnamed stream there
         SetupMoveTable(0x20)
         viewPort.goto!!.execute("000100")
         errors.clear()
         viewPort.edit("^`plm`")

         viewPort.goto!!.execute("000102")
         viewPort.edit(ConsoleKey.Backspace)
         var format = ((viewPort[2, 0].format) as UnderEdit)
         Assert.equal("10 Fou", format.currentText)
      }
      @Test fun PlmStreamsAppearInTextTool() {
         SetupMoveTable(0x20)
         SetupPlmStream(0x70, 4)
         viewPort.goto!!.execute("000000")

         viewPort.selectionStart  = Point(2, 7)
         viewPort.followLink(2, 7)

         Assert.equal(viewPort.tools!!.indexOf(viewPort.tools!!.stringTool), viewPort.tools!!.selectedIndex)
         var itemCount = viewPort.tools!!.stringTool!!.content.split("\n").size
         Assert.equal(4, itemCount)

         viewPort.tools!!.stringTool!!.contentIndex  = 17; // third line
         Assert.isTrue(viewPort.isSelected(Point(4, 7)))
         Assert.isTrue(viewPort.isSelected(Point(5, 7)))
      }
      @Test fun PlmStreamGetsStreamNameInAddressBarAndTextToolIfPointedToFromAMatchedLengthTable() {
         // setup text tables
         SetupNameTable(0x40)
         SetupMoveTable(0x80)

         // setup pointers that will eventually be in the lvlmoves table
         viewPort.goto!!.execute("000000")
         viewPort.edit("<000100><000110><000120><000130><000140><000150><000160><000170>")

         // setup data that lvlmoves pointers will point to
         for (i in 0x100 until 0x180 step 0x10) SetupPlmStream(i, 6, withName = false)

         // add lvlmoves table
         viewPort.goto!!.execute("000000")
         viewPort.edit("^${HardcodeTablesModel.levelMovesTableName}[data<`plm`>]${HardcodeTablesModel.pokemonNameTable} ")

         viewPort.goto!!.execute("000110"); // jump to the anchor for Bob's moves
         Assert.contains("${HardcodeTablesModel.levelMovesTableName}/Bob/data", viewPort.selectedElementName)
      }
      @Test fun CanSearchForTextWithinPlmStream() {
         // setup text tables
         SetupNameTable(0x40)
         SetupMoveTable(0x80)

         // setup pointers that will eventually be in the lvlmoves table
         viewPort.goto!!.execute("000000")
         viewPort.edit("<000100><000110><000120><000130><000140><000150><000160><000170>")

         // setup data that lvlmoves pointers will point to
         for (i in 0x100 until 0x180 step 0x10) SetupPlmStream(i, 6, withName = false)

         // add lvlmoves table
         viewPort.goto!!.execute("000000")
         viewPort.edit("^${HardcodeTablesModel.levelMovesTableName}[data<`plm`>]${HardcodeTablesModel.pokemonNameTable} ")

         var results = viewPort.find("Three")
         Assert.equal(9, results.size) // the actual text + entries for the 8 pokemon
      }
      @Test fun EditPlmInMainViewUpdatesTextTool() {
         SetupMoveTable(0x00)
         SetupPlmStream(0x50, 8)

         viewPort.goto!!.execute("000000")
         viewPort.selectionStart  = Point(2, 5); // should select '2 One'
         viewPort.edit("3 One ")

         Assert.isNotType<UnderEdit>(viewPort[2, 5].format)
         Assert.contains("3 One", viewPort.tools!!.stringTool!!.content)
      }
      @Test fun AutoCompletePlmMoveNameContainingSpaceWorksWithNoQuotes() {
         SetupMoveTable(0x00)
         viewPort.selectionStart  = Point(0, 1); // start of move "Two"
         viewPort.edit("Bob Par")
         SetupPlmStream(0x50, 8)

         viewPort.goto!!.execute("000000")
         viewPort.selectionStart  = Point(2, 5); // should select '2 One'
         viewPort.edit("2 bobpar ")

         Assert.isNotType<UnderEdit>(viewPort[2, 5].format)
         Assert.contains("2 \"Bob Par\"", viewPort.tools!!.stringTool!!.content)
      }
      @Test fun MultilinePlmPasteWorks() {
         SetupMoveTable(0x00)
         SetupPlmStream(0x50, 2)
         viewPort.edit("@000050\n4 Three\n6 Five\n10 Zero\n[]\n")

         Assert.equal(0x803, model.readMultiByteValue(0x50, 2))
         Assert.equal(0xC05, model.readMultiByteValue(0x52, 2))
         Assert.equal(0x1400, model.readMultiByteValue(0x54, 2))
         Assert.equal(0xFFFF, model.readMultiByteValue(0x56, 2))
      }
      @Test fun ChoosingAutoCompleteOptionClosesPlmEdit() {
         SetupMoveTable(0x00)
         viewPort.selectionStart  = Point(0, 1); // start of move "Two"
         viewPort.edit("Bob Par")
         SetupPlmStream(0x50, 8)

         viewPort.goto!!.execute("000000")
         viewPort.selectionStart  = Point(2, 5); // should select '2 One'
         viewPort.edit("3 \"Bo")

         var format = ((viewPort[2, 5].format) as UnderEdit)
         viewPort.autocomplete(format.autocompleteOptions!![0].completionText)

         Assert.isNotType<UnderEdit>(viewPort[2, 5].format)
         Assert.contains("3 \"Bob Par\"", viewPort.tools!!.stringTool!!.content)
      }
      @Test fun CanUseBitArraysInFormats() {
         SetupMoveTable(0x00)
         SetupNameTable(0x40)

         // setup a table for 5 tutor moves
         viewPort.goto!!.execute("000080")
         viewPort.edit("^tutormoves[move:${HardcodeTablesModel.moveNamesTable}]5 One Two Four Five Seven ")

         // create a table that uses tutormoves as a bit array. Note 5 moves should take up 1 byte, so the overall table should by 8 bytes long (because there are 8 pokemon)
         viewPort.goto!!.execute("0000090")
         viewPort.edit("^table[moves|b[]tutormoves]${HardcodeTablesModel.pokemonNameTable} ")
         var run = (model.getNextRun(0x90) as ArrayRun)
         var segment = ((run.elementContent[0]) as ArrayRunBitArraySegment)
         Assert.equal("tutormoves", segment.sourceArrayName)
         Assert.equal(8, run.length)

         var bitList = (viewPort.tools!!.tableTool!!.children.single({ child -> child is BitListArrayElementViewModel }) as BitListArrayElementViewModel)
         Assert.equal("Four", bitList[2].bitLabel)

         bitList[2].isChecked  = true;      // "Adam" should be able to learn "Four"
         Assert.equal(0x04, model[0x90]);  // the third bit up is set because "Four" is the first tutor move

         Assert.isType<BitArray>((((viewPort[0, 0].format) as Anchor)).originalFormat)
      }
      @Test fun BitArraySelectionSelectsAllBytesInCurrentBitArray() {
         SetupMoveTable(0x00)
         SetupNameTable(0x40)

         // setup a table for 5 tutor moves
         viewPort.goto!!.execute("000080")
         viewPort.edit("^tutormoves[move:${HardcodeTablesModel.moveNamesTable}]10 One One Two Two Four Four Five Five Seven Seven "); // note that 10 bits takes 2 bytes

         viewPort.goto!!.execute("0000100")
         viewPort.edit("^table[moves|b[]tutormoves]${HardcodeTablesModel.pokemonNameTable} ")
         var run = (model.getNextRun(0x100) as ArrayRun)
         Assert.equal(16, run.length); // 2 bytes each for 8 pokemon

         viewPort.selectionStart  = Point(4, 0)
         Assert.isTrue(viewPort.isSelected(Point(5, 0)))
      }
      @Test fun CanExpandBitArrays() {
         // Arrange a table with 8 elements
         // and a second table that uses those elements as bits
         SetupMoveTable(0x00)
         viewPort.edit("@40 ^mymoves[move:${HardcodeTablesModel.moveNamesTable}]8 "); // setup a table that uses 'movenames' as an enum
         viewPort.edit("@60 ^table[data|b[]mymoves]4 @61 FF "); // set all 8 name bits to true for the table[1]    // 60 - 64

         // Act: expand the enum table to have 9 entries
         viewPort.edit("@50 +")

         // Assert that the 8 true bits moved based on the expansion, and the new table uses 2 bytes per element.
         Assert.equal(0xFF, data[0x62])
         Assert.equal(8, model.getNextRun(0x60).length)
      }
      @Test fun EnumFromEnumFromStringUsesIndexValueAsOptions() {
         SetupNameTable(0x180)
         viewPort.edit("@00 ^enum1[value.]${HardcodeTablesModel.pokemonNameTable}-1 2 3 4 5 6 7 1 ")
         (ModelCacheScope.createScope(model)).use { _ ->
            var options = ModelCacheScope.getCache(model).getOptions("enum1")
            Assert.equal("Horton", options[1]); // option 0 should be Horton because enum[Horton] = 0
            Assert.equal("Bob", options[2])
            Assert.equal("Carl", options[3])
            Assert.equal("Dave", options[4])
            Assert.equal("Elen", options[5])
            Assert.equal("Fred", options[6])
            Assert.equal("Gary", options[7])
            Assert.equal(8, options.size)
          }
      }
      @Test fun TableWithTableStreamPointers_RepointToMiddleOfAnotherRun_NoAssert() {
         var test = BaseViewModelTestClass()
         test.Model[5]  = 5
         test.ViewPort.edit("@100 ^table[ptr<[a.]!05>]2 <000> ")

         test.ViewPort.edit("<002> ")

         var streamRun = (test.Model.getNextRun(0) as TableStreamRun)
         Assert.equal(0, streamRun.start)
         Assert.equal(6, streamRun.length)
      }
      @Test fun TableWithTableStreamPointers_RepointToContainingAnotherRun_NoAssert() {
         var test = BaseViewModelTestClass()
         test.Model[5]  = 5
         test.ViewPort.edit("@100 ^table[ptr<[a.]!05>]2 <002> ")

         test.ViewPort.edit("<000> ")

         var streamRun = (test.Model.getNextRun(0) as TableStreamRun)
         Assert.equal(0, streamRun.start)
         Assert.equal(6, streamRun.length)
      }

      // creates a move table that is 0x40 bytes long
      private fun SetupMoveTable(start: Int) {
         viewPort.goto!!.execute(start.toString("X6"))
         viewPort.edit("^" + HardcodeTablesModel.moveNamesTable + "[name\"\"8]8 Zero\" One\" Two\" Three\" Four\" Five\" Six\" Seven\"")
      }

      // creates a name table that is 0x40 bytes long
      private fun SetupNameTable(start: Int) {
         viewPort.goto!!.execute(start.toString("X6"))
         viewPort.edit("^" + HardcodeTablesModel.pokemonNameTable + "[name\"\"8]8 Adam\" Bob\" Carl\" Dave\" Elen\" Fred\" Gary\" Horton\"")
      }

      // creates a plm stream named 'stream' that is <0x20 bytes long. Length should be <9.
      private fun SetupPlmStream(start: Int, length: Int, withName: Boolean = true) {
         // make sure we terminate first. This will move as needed, but it allows us to add the stream cleanly by just editing inline.
         model.writeMultiByteValue(start, 2, ModelDelta(), 0xFFFF)
         viewPort.goto!!.execute(start.toString("X6"))
         if (withName) viewPort.edit("^stream`plm`")
         else viewPort.edit("^`plm`")
         for (i in 0 until length) {
            viewPort.edit("${i + 1} ${i} ")
         }
      }
   }
