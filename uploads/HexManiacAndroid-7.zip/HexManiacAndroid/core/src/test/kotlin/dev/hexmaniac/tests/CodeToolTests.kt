@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class CodeToolTests : BaseViewModelTestClass() {
      private val Tool: CodeTool get() = ViewPort.tools!!.codeTool!!
      private var EventScript: String
         get() = ";".join(Tool.contents[0].content.splitLines().filter({ line -> !line.isNullOrBlank() }).map({ line -> line.trim() }))
         set(value) {
            Tool.mode = CodeMode.Script
            Tool.contents[0].content = value.replace(";", "\n")
         }
      private var TrainerAiScript: String
         get() = ";".join(Tool.contents[0].content.splitLines().map({ line -> line.trim() }))
         set(value) {
            Tool.mode = CodeMode.TrainerAiScript
            Tool.contents[0].content = value.replace(";", "\n")
         }
      private var ThumbScript: String
         get() = Tool.content
         set(value) { Tool.content = value.replace(";", "\n") }
      private fun GetContent(index: Int): String = Tool.contents[index].content
      private fun SetContent(index: Int, content: String) { Tool.contents[index].content = content.replace(";", "\n") }

      private fun AddScriptFormat(index: Int) {
         ViewPort.goto!!.execute(index)
         var point = ViewPort.convertAddressToViewPoint(index)
         var contextItems = ContextItemFactory(ViewPort)
         ViewPort[point].format!!.visit(contextItems, 0xFF)
         var group = ((contextItems.results.single({ result -> result.text!!.startsWith("Create New") })) as ContextItemGroup)
         group.single({ item -> item.text!!.startsWith("Event Script") }).command.execute()
      }

      init {
         Model.loadMetadata(BaseModel.getDefaultMetadatas().first()); // load default script-related lists, like script_compare
         SetFullModel(0xFF)
         Tool.isSelected  = true
      }
      @Test fun AddAndRemoveAnchorInSameToken_Undo_NoAnchor() {
         WriteEventScript(0x10, "end")
         WriteEventScript(0x20, "goto <010>")

         EventScript  = "goto <00000>"
         EventScript  = "goto <000030>"
         EventScript  = "goto <00000>"
         EventScript  = "goto <000010>"

         ViewPort.undo.execute()

         var run = Model.getNextRun(0x30)
         Assert.notEqual(0x30, run.start)
      }
      @Test fun ScriptWithCallAndLabel_Expand_NoError() {
         Tool.mode  = CodeMode.Script
         EventScript  = "call <routine>;end;routine:;end"

         // since the routine is part of the script, it doesn't need to be a separate content box
         Assert.single(Tool.contents)

         EventScript  = "call <routine>;nop;end;routine:;end"

         Assert.isFalse(Tool.showErrorText)
      }
      @Test fun ScriptWithTwoEnds_ChangeEndToNop_NoErrors() {
         Tool.mode  = CodeMode.Script

         EventScript  = "nop;end;end"
         EventScript  = "nop;nop;end"

         Assert.isFalse(Tool.showErrorText)
      }
      @Test fun FireRedSpecial_Decode_HasLabel() {
         SetGameCode("BPRE0")
         for (meta in BaseModel.getDefaultMetadatas("bpre")) Model.loadMetadata(meta)
         Token.changeData(Model, 0, "25 9E 00 02".parseHexBytes())

         var script = Tool.scriptParser.parse(Model, 0, 4).splitLines()[0].trim()

         Assert.equal("special ChangePokemonNickname", script)
      }
      @Test fun ThumbCode_HasComment_Compiles() {
         var result = Tool.parser.compile(Model, 0,
            "nop/*",
            "nop",
            "*/nop",
            "nop")
         Assert.equal(6, result.count)
      }
      @Test fun EquDirective_Compile_DoesTextSubstitution() {
         var result = Tool.parser.compile(Model, 0,
            ".equ candy, 7",
            "mov  r0, candy")
         Assert.equal(2, result.count)
         Assert.equal(0x2007, result.readMultiByteValue(0, 2))
      }
      @Test fun ByteDirective_Compile_Supported() {
         var result = Tool.parser.compile(Model, 0, ".byte 10", ".byte 0x10")
         Assert.equal(bytes( 10, 0x10), result)
      }
      @Test fun ByteDirective_ThenCode_AlignmentAdded() {
         var result = Tool.parser.compile(Model, 0, ".byte 10", "nop")
         Assert.equal(bytes( 10, 0, 0, 0), result)
      }
      @Test fun HalfWordDirective_Compile_Supported() {
         var result = Tool.parser.compile(Model, 0, ".hword 10", ".hword 0x10")
         Assert.equal(bytes( 10, 0, 0x10, 0), result)
      }
      @Test fun CommandWithPointerToValidData_ChangePointerToUnknown_CreateNewCopyOfExistingData() {
         Tool.mode  = CodeMode.Script
         EventScript  = "loadpointer 0 <40>;{;test;};end"

         EventScript  = "loadpointer 0 <??????>;{;test;};end"

         var run = ((Model.getNextRun(Model.readPointer(2))) as PCSRun)
         Assert.notEqual(0x40, run.start)
         Assert.equal("test", run.serializeRun())
         Assert.equal(2, EventScript.count({ c -> "{}".contains(c) }))
      }
      @Test fun OutOfOrderJumps_EditBottomScript_ScriptCountRemainsSame() {
         Tool.mode  = CodeMode.Script
         AddScriptFormat(0)
         EventScript  = "if2 = <028>; if2 = <018>; if2 = <020>; end"
         ViewPort.edit("@018 02 @020 02 @028 02 @000 ")
         ViewPort.expandSelection(0, 0)

         SetContent(2, GetContent(2) + " ")

         Assert.equal(4, Tool.contents.size)
      }
      @Test fun ScriptWithInnerAnchor_AddScriptFormat_AnchorKept() {
         Tool.mode  = CodeMode.Script
         EventScript  = "lock;faceplayer;end"
         ViewPort.edit("@010 <001>")

         ViewPort.goto!!.execute(0)
         ViewPort.edit("^`xse`")

         Assert.isType<PointerRun>(Model.getNextRun(0x10))
      }
      @Test fun ScriptWithInnerAnchor_AddPointerAtThatLocation_AnchorRemoved() {
         Tool.mode  = CodeMode.Script
         EventScript  = "lock;if1 = <100>;end"
         ViewPort.edit("@010 <005>"); // points into the pointer

         ViewPort.goto!!.execute(0)
         ViewPort.edit("^`xse`")

         Assert.isType<PointerRun>(Model.getNextRun(5))
         Model.resolveConflicts()
      }
      @Test fun AddWithTwoSameRegisters_AddWithOneRegister_SameCode() {
         ThumbScript  = "add r3,r3,#6; add r3, #6"
         Assert.equal(Model.readMultiByteValue(0, 2), Model.readMultiByteValue(2, 2))
      }
      @Test fun Word_PlusOne_Compiles() {
         ThumbScript  = ".word 0x8123456+1"
         Assert.equal(0x57, Model[0])
      }
      @Test fun TrainerScript_Decompile_MultipleFormatSections() {
         // 5C trainerbattle 00 trainer:data.trainers.stats arg: start<""> playerwin<"">
         SetFullModel(0xFF)
         ViewPort.edit("5C 00 0000 0000 <100> <110> 02 @100 ^start\"\"Start\" @110 ^win\"\"Win\"")
         ViewPort.cascadeScript(0)
         var code = ViewPort.tools!!.codeTool!!.scriptParser.parse(Model, 0, 15).splitLines().map({ line -> line.trim() }).toTypedArray()
         var expected = arrayOf(
            "single.battle 0 <000100> <000110>",
            "{",
            "Start",
            "}",
            "{",
            "Win",
            "}",
            "end",
            "",)
         Assert.all(code.size.range(), { i -> Assert.equal(expected[i], code[i]) })
      }
      @Test fun TrainerScript_MultipleFormatSections_Compiles() {
         SetFullModel(0xFF)
         Tool.mode  = CodeMode.Script

         EventScript  = "trainerbattle 0 0 0 <100> <110>;{;Start;};{;Win;};end"

         var results = ByteArray(16)
         arrayCopy(Model.rawData, 0, results, 0, 16)
         Assert.equal(bytes( 0x5C, 0, 0,0, 0,0, 0,1,0,8, 0x10,1,0,8, 2, 0xFF), results)
         Assert.equal("\"Start\"", Model.textConverter.convert(Model, 0x100, 0x20))
         Assert.equal("\"Win\"", Model.textConverter.convert(Model, 0x110, 0x20))
      }
      fun Macro_Compile_Compiles(type: String, value: Int) {
         SetFullModel(0xFF)
         Tool.mode  = CodeMode.Script

         EventScript  = "msgbox.${type} <100>;end"

         var expected = "0F 00 00 01 00 08 09 ${(value).toHex(2)} 02".parseHexBytes()
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], Model[i]) })
      }
    @Test fun Macro_Compile_Compiles_1() { Macro_Compile_Compiles("npc", 2) }
    @Test fun Macro_Compile_Compiles_2() { Macro_Compile_Compiles("sign", 3) }
    @Test fun Macro_Compile_Compiles_3() { Macro_Compile_Compiles("default", 4) }
    @Test fun Macro_Compile_Compiles_4() { Macro_Compile_Compiles("yesno", 5) }
    @Test fun Macro_Compile_Compiles_5() { Macro_Compile_Compiles("autoclose", 6) }
      fun Macro_Decompile_Decompiles(type: String, value: Int) {
         SetFullModel(0xFF)
         "0F 00 00 01 00 08 09 ${(value).toHex(2)} 02".parseHexBytes().writeInto(Model.rawData, 0)
         var lines = Tool.scriptParser.parse(Model, 0, 9).splitLines()
         Assert.equal("msgbox.${type} <000100>", lines[0].trim())
      }
    @Test fun Macro_Decompile_Decompiles_1() { Macro_Decompile_Decompiles("npc", 2) }
    @Test fun Macro_Decompile_Decompiles_2() { Macro_Decompile_Decompiles("sign", 3) }
    @Test fun Macro_Decompile_Decompiles_3() { Macro_Decompile_Decompiles("default", 4) }
    @Test fun Macro_Decompile_Decompiles_4() { Macro_Decompile_Decompiles("yesno", 5) }
    @Test fun Macro_Decompile_Decompiles_5() { Macro_Decompile_Decompiles("autoclose", 6) }
      @Test fun BranchlinkOutOfReach_ConvertToLongBranchLink() {
         ThumbScript  = "push {lr}; bl <C00000>; pop {pc}"

         // we want to branch to C00000
         // but that's beyond the maximum branch distance!
         // install a 'universal-branch-link' command to allow it.

         // the universal-branch-link is a normal branch-link,
         // but instead of going where we want to go, it goes
         // to a bit of long-jump code first.
         // (1) push r0 for extra space, and push r1 so we can use the register.
         // (2) fill r1 with the destination we want to branch to (+1)
         // (3) store the value from r1 to the stack
         // (4) pop to restore the value of r1, and also jump to the address on the stack

         var expected = bytes(
            0x00, 0xB5,        // push {lr}
            0x00, 0xF0, 0x01, 0xF8, // bl round4(pc+4+2*1)
            0x00, 0xBD,            // pop {pc}
            // the magic part
            0x3, 0xB4,            // push {r0, r1}
            0x01, 0x48,     // ldr r0, pc+4+4* 1
            0x01, 0x90,     // str r0, sp+4*   1
            0x1, 0xBD,            // pop {r0, pc}
            0x01, 0x00, 0xC0, 0x08)

         var result = ByteArray(expected.size)
         arrayCopy(Model.rawData, 0, result, 0, result.size)
         Assert.all(result.size.range(), { i -> Assert.equal(expected[i], result[i]) })
      }
      @Test fun BranchLinksOutOfReach_TwoDistinctAddresses_TwoLongBranchLinks() {
         ThumbScript  = "push {lr}; bl <C00000>; bl <D00000>; pop {pc}"

         var expectedLength = 12 + 12 * 2; // 12 bytes for the initial command, 12 bytes for each long-branch-link
         Assert.notEqual(0xFF, Model.rawData[expectedLength - 1])
         Assert.equal(0xFF, Model.rawData[expectedLength])
      }
      @Test fun BranchLinksOutOfReach_TwoIdenticalAddresses_OneLongBranchLink() {
         ThumbScript  = "push {lr}; bl <C00000>; bl <C00000>; pop {pc}"

         var expectedLength = 12 + 12 * 1; // 12 bytes for the initial command, 12 bytes for a single long-branch-link
         Assert.notEqual(0xFF, Model.rawData[expectedLength - 1])
         Assert.equal(0xFF, Model.rawData[expectedLength])
      }
      @Test fun ExactlyOneThumbRoutine_Cut_UniversalBranchLinkLeftBehind() {
         ThumbScript  = "push {lr}; nop; nop; nop; nop; nop; nop; nop; nop; pop {pc}; push {lr}"

         ViewPort.selectionStart  = Point(0, 0); // 2nd byte of selection is B5
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(0x13); // 2nd byte after selection is B5
         ViewPort.cut(FileSystem)

         var text = FileSystem.copyText.value
         var anchor = text!!.split((' ').toString())[0].substring(1); // something like ^thumb.misc.000000
         var expected = "03 B4 01 49 01 91 02 BD".parseHexBytes()
         Assert.contains(".thumb", text)
         Assert.contains(".end", text)
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], Model[i]) })
         var run = (Model.getNextRun(0x8) as OffsetPointerRun)
         Assert.equal(1, run.offset)
         Assert.equal(0x8, Model.getUnmappedSourcesToAnchor(anchor).single())
      }
      fun NotExactSelection_Cut_DataCleared(start: Int) {
         ThumbScript  = "nop; push {lr}; nop; nop; nop; nop; nop; nop; nop; nop; pop {pc}; push {lr}"
         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(start)
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(start + 3)

         ViewPort.cut(FileSystem)

         var expected = "FF FF FF FF".parseHexBytes()
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], Model[start + i]) })
      }
    @Test fun NotExactSelection_Cut_DataCleared_1() { NotExactSelection_Cut_DataCleared(0) }
    @Test fun NotExactSelection_Cut_DataCleared_2() { NotExactSelection_Cut_DataCleared(2) }
    @Test fun NotExactSelection_Cut_DataCleared_3() { NotExactSelection_Cut_DataCleared(4) }
    @Test fun NotExactSelection_Cut_DataCleared_4() { NotExactSelection_Cut_DataCleared(9 * 2) }
    @Test fun NotExactSelection_Cut_DataCleared_5() { NotExactSelection_Cut_DataCleared(10 * 2) }
      @Test fun SelectStartOfThumbRoutine_ExpandSelection_SelectThumbRoutine() {
         ThumbScript  = "push {lr}; nop; nop; nop; nop; nop; nop; nop; nop; pop {pc}; push {lr}"

         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.expandSelection(0, 0)

         Assert.equal(19, ViewPort.convertViewPointToAddress(ViewPort.selectionEnd))
      }
      @Test fun LongBranchLink_OddNumberOfCommands_NopInsertedBeforeLongBranchLinkCode() {
         ThumbScript  = "bl <C00000>; bx r0"
         Assert.equal(0, Model.readMultiByteValue(6, 2))
      }
      @Test fun LongBranchLinkOddNumberCommands_StartsAtMultipleOfTwo_NoNopInserted() {
         ViewPort.goto!!.execute(2)
         ThumbScript  = "bl <C00000>; bx r0"
         Assert.notEqual(0, Model.readMultiByteValue(8, 2))
      }
      @Test fun CodeWithPointer_DoubleClick_SelectCodeAndPointer() {
         ThumbScript  = "push {lr}; ldr r0, =<800000>; pop {pc}"
         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(12)
         ThumbScript  = "push {lr}"

         ViewPort.goto!!.execute(0)
         ViewPort.expandSelection(0, 0)

         Assert.isType<PointerRun>(Model.getNextRun(8))
         Assert.equal(11, ViewPort.convertViewPointToAddress(ViewPort.selectionEnd))
      }
      @Test fun CodeWithPointer_ReplaceWithLongBranchLink_Success() {
         ThumbScript  = "push {lr}; ldr r0, =<800000>; pop {pc}"
         ViewPort.goto!!.execute(12)
         ThumbScript  = "push {lr}"

         ViewPort.goto!!.execute(0)
         ViewPort.expandSelection(0, 0)
         ViewPort.cut(FileSystem)

         // if we succeeded, then the value at 0x8 should be <null>
         Assert.equal(0, Model.readMultiByteValue(8, 4))
      }
      @Test fun AnchorAtStart_ExpandSelectionToThumbRoutine_SelectionExpanded() {
         ThumbScript  = "push {lr}; pop {pc}; push {lr}"
         ViewPort.edit("^some.anchor ")

         ViewPort.expandSelection(0, 0)

         Assert.equal(3, ViewPort.convertViewPointToAddress(ViewPort.selectionEnd))
      }
      @Test fun ThumbRoutineWithPointer_Cut_RemovePointerFormat() {
         ThumbScript  = "push {lr}; nop; nop; nop; nop; nop; nop; nop; nop; nop; nop; ldr r0, =<800000>; pop {pc}"

         ViewPort.expandSelection(0, 0)
         ViewPort.cut(FileSystem)

         Assert.isType<OffsetPointerRun>(Model.getNextRun(8))
         Assert.isNotType<PointerRun>(Model.getNextRun(0xC))
      }
      @Test fun AutoPointer_CreateText_DirectlyAfterScript() {
         Tool.mode  = CodeMode.Script

         EventScript  = "loadpointer 0 <auto>;{;text;};end"

         Assert.isType<PCSRun>(Model.getNextRun(7))
      }
      @Test fun Text_DirectlyAfterScript_InterpretAsAutoPointer() {
         ViewPort.edit("0F 00 <007> 02 ^\"\" text\" @000 ^script.start`xse`")

         var script = EventScript

         Assert.contains("<auto>", script)
      }
      @Test fun ScriptIfElseShape_Decompile_OneTextBoxWithFullScript() {
         EventScript  = "\nif1 = <part2>\n  nop\n  goto <part3>\npart2:\n  nop\npart3:\n  nop\n  end\n"

         var length = Tool.scriptParser.getScriptSegmentLength(Model, 0)
         var content = Tool.scriptParser.parse(Model, 0, length)

         Assert.equal(15, length)
         Assert.single(Tool.contents)
         Assert.contains("end", content)
      }
      @Test fun Mart_Auto_Compiles() {
         EventScript  = "\npokemart <auto>\n{\n1\n2\n3\n}\n  end\n"

         var run = Model.getNextRun(6)
         Assert.isAssignableFrom<ITableRun>(run)
         Assert.equal(0, Model.readMultiByteValue(6, 2)); // alignment
         Assert.equal(1, Model.readMultiByteValue(8, 2))
         Assert.equal(2, Model.readMultiByteValue(10, 2))
         Assert.equal(3, Model.readMultiByteValue(12, 2))
         Assert.equal(0, Model.readMultiByteValue(14, 2))
      }
      @Test fun Mart_Decompile_Auto() {
         ViewPort.edit("^some.script`xse` 86 <006> 02 01 00 02 00 03 00 00 00 @006 ^[item:${HardcodeTablesModel.itemsTableName}]!0000")

         ViewPort.goto!!.execute(0)
         var script = EventScript

         Assert.contains("<auto>", script)
      }
      @Test fun Movement_Auto_Compiles() {
         EventScript  = "\napplymovement 0 <auto>\n{\n1\n2\n3\n}\n  end\n"

         var run = Model.getNextRun(9)
         Assert.isAssignableFrom<ITableRun>(run)
         Assert.equal(1, Model[8])
         Assert.equal(2, Model[9])
         Assert.equal(3, Model[10])
         Assert.equal(0xFE, Model[11])
      }
      @Test fun Movement_Decompile_Auto() {
         ViewPort.edit("^some.script`xse` 4F 00 00 <008> 02 01 02 03 FE @008 ^[move.movementtypes]!FE")

         ViewPort.goto!!.execute(0)
         var script = EventScript

         Assert.contains("<auto>", script)
      }
      @Test fun ScriptWithTextAfterBranch_Decompile_IncludedInLength() {
         EventScript  = "\n  lock\n  msgbox.yesno <auto>\n{\nIs the answer yes?\n}\n  if.compare.goto 0x800D = 1 <yes>\n  if.compare.goto 0x800D = 0 <no>\n  release\n  end\nyes:\n  msgbox.default <auto>\n{\nYou said yes!\n}\n  release\n  end\nno:\n  msgbox.default <auto>\n{\nYou said no!\n}\n  release\n  end"

         var length = Tool.scriptParser.findLength(Model, 0)

         Assert.equal(99, length)
      }
      @Test fun ScriptBranchesToAnotherScriptDirectlyAfter_Decompile_OneContentBox() {
         ViewPort.edit("06 00 <007> 02 00 02 @007 ^`xse` ")

         Tool.mode  = CodeMode.Script
         ViewPort.goto!!.execute(0)

         Assert.single(Tool.contents)
      }
      @Test fun Macro_GameSpecific_Compiles() {
         var line = MacroScriptLine("[BPRE_BPGE] some.command 01 varible: 33 # comment")
         Assert.isTrue(line.matchesGame(ScriptLine.convertAscii("BPRE")))
         Assert.isFalse(line.matchesGame(ScriptLine.convertAscii("BPEE")))
      }
      @Test fun PointerToUnformattedAnchor_ScriptExpected_NoAuto() {
         ViewPort.edit("05 <005> @000 ")
         Tool.mode  = CodeMode.Script
         Assert.doesNotContain("<auto>", EventScript)
      }
      @Test fun BranchToScriptAfterCurrentAddress_SecondScriptHasGoto_DestinationInNewScriptContent() {
         Tool.mode  = CodeMode.Script
         EventScript  = "if1 = <later>;end;later:;goto <000100>"
         ViewPort.goto!!.execute(0x100)
         EventScript  = "nop;end"

         ViewPort.goto!!.execute(0)

         Assert.equal(2, Tool.contents.size)
      }
      @Test fun AnimationScript_PlaySeWithPan_CanDecode() {
         var animationpan = ArrayList<String?>(List<String?>(192) { null })
         animationpan[63]  = "sound_pan_target"
         ViewPort.model.setList("animationpan", animationpan as List<String>)

         ViewPort.edit("19 00 00 00 ")
         Tool.mode  = CodeMode.AnimationScript
         ViewPort.goto!!.execute(0)
         var help = Tool.animationScriptParser.getHelp(ViewPort.model, HelpContext("playsewithpan mus_dummy ", 24))

         Assert.notNull(help)
      }
      @Test fun Script_UnusedLabel_LabelAppendedToEndOfScript() {
         EventScript  = "if1 = <go1>;if1 = <go2>;end"; // the end is at 12

         Assert.equal(13, Model.readPointer(2))
         Assert.equal(14, Model.readPointer(8))
      }
      @Test fun Script_EndsInLabel_AutoIncludeEndCommand() {
         EventScript  = "if1 = <go1>;end;go1:"

         Assert.equal(7, Model.readPointer(2))
         Assert.equal(2, Model[7])
      }
      @Test fun Script_Unfinished_EndsWithEndCommand() {
         EventScript  = "nop"
         Assert.equal(2, Model[1])
      }
      @Test fun Script_EndsWithGoto_DoesNotIncludeClosingEnd() {
         EventScript  = "goto <100>"
         Assert.equal(0xFF, Model[5])
      }
      @Test fun ApplyMovementWithEmptyMovementStream_NoopEdit_MovementStreamStillEmpty() {
         EventScript  = "applymovement 0 <??????>"

         EventScript  += " "

         var address = Model.readPointer(3)
         Assert.equal(0xFE, Model[address])
      }
      @Test fun ScriptPointingToFreeSpace_EditScript_2CodeSections() {
         EventScript  = "if1 = <100>"
         Assert.equal(2, Tool.contents.size)
      }
      @Test fun Script_MultipleIfsEachWithGoto_ContentSectionsAddedForEachGoto() {
         EventScript  = "if1 = <label1>;if1 = <label2>;end\nlabel1:;goto <000040>;end\nlabel2:;goto <000050>;end"; // label2 gets included even though there's an extra `end` command

         Assert.equal(3, Tool.contents.size) // main script, label2, 040, and 050
      }
      @Test fun SubscriptsWithEndAfterGoto_Decompile_DecompileFullScriptWithoutEndCommands() {
         EventScript  = "if1 = <label1>;if1 = <label2>;end\nlabel1:;goto <000040>;end\nlabel2:;goto <000050>;end"

         ViewPort.selectionStart  = newOf(0, 3)
         ViewPort.selectionStart  = newOf(0, 0)

         // should contain 2 if statements and 2 gotos
         var script = EventScript.split(";").toList().trimAll().toMutableList()
         Assert.equal(2, script.count({ line -> line.contains("if1") }))
         Assert.equal(2, script.count({ line -> line.contains("goto") }))
      }
      @Test fun TrianerBattleCommand_01_PointerToAfterScriptHasCorrectAddress() {
         EventScript  = "trainerbattle 01 0 0 <000020> <000030> <part2>;end;part2:;end"
         var destination = Model.readPointer(0x0E)
         Assert.equal(0x13, destination)
      }
      @Test fun Script_NoopChange_NoChange() {
         ViewPort.edit("^script`xse`")
         EventScript  = "msgbox.npc <auto>;{;text;};"
         ViewPort.changeHistory.tagAsSaved()

         EventScript  = "msgbox.npc  <auto>;{;text;};"
         Assert.isFalse(ViewPort.changeHistory.currentChange.hasAnyChange)
      }
      @Test fun TrainerAIScript_NoOpEditCreatesPointersToScripts_NoOrphansAndPointsToTrainerAIScript() {
         "37 01 00 01 00 08 5A".parseHexBytes().writeInto(Model.rawData, 0)
         "5A".parseHexBytes().writeInto(Model.rawData, 0x100)
         ViewPort.edit("^script`tse`")

         TrainerAiScript  += " "

         Assert.all(Model.anchors, { anchor -> Assert.doesNotContain("orphan", anchor) })
         Assert.isType<TSERun>(Model.getNextRun(0x100))
      }
      @Test fun UnformattedScriptWithInnerAnchor_FormatThenExpand_Repoint() {
         SetFullModel(0xFF)
         "06 00 07 00 00 08 02 02".parseHexBytes().writeInto(Model.rawData, 0)
         Model.observeAnchorWritten(Token, "parent", XSERun(0))
         Tool.mode  = CodeMode.Script

         EventScript  += " "
         EventScript  += ";end"

         Assert.single(Messages)
      }
      fun ScriptWithPointerToPointer_Format_FixBrokenPointer(destination: String) {
         SetFullModel(0xFF)
         "06 00 ${destination} 00 00 08 02".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("^script`xse`")

         EventScript  += " "; // force formatting

         var run = Model.getNextRun(1)
         Assert.equal(7, Model.readPointer(2)) // auto-update pointer to something reasonable
      }
    @Test fun ScriptWithPointerToPointer_Format_FixBrokenPointer_1() { ScriptWithPointerToPointer_Format_FixBrokenPointer("02") }
    @Test fun ScriptWithPointerToPointer_Format_FixBrokenPointer_2() { ScriptWithPointerToPointer_Format_FixBrokenPointer("03") }
    @Test fun ScriptWithPointerToPointer_Format_FixBrokenPointer_3() { ScriptWithPointerToPointer_Format_FixBrokenPointer("04") }
    @Test fun ScriptWithPointerToPointer_Format_FixBrokenPointer_4() { ScriptWithPointerToPointer_Format_FixBrokenPointer("05") }
      fun ScriptWithPointerToFuturePointer_Format_FixBrokenPointer(destination: String) {
         SetFullModel(0xFF)
         "06 00 ${destination} 00 00 08 06 00 00 01 00 08 02".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("^script`xse`")

         EventScript  += " "; // force formatting

         var run = Model.getNextRun(1)
         Assert.equal(13, Model.readPointer(2)) // auto-update pointer to something reasonable
      }
    @Test fun ScriptWithPointerToFuturePointer_Format_FixBrokenPointer_1() { ScriptWithPointerToFuturePointer_Format_FixBrokenPointer("09") }
    @Test fun ScriptWithPointerToFuturePointer_Format_FixBrokenPointer_2() { ScriptWithPointerToFuturePointer_Format_FixBrokenPointer("0A") }
    @Test fun ScriptWithPointerToFuturePointer_Format_FixBrokenPointer_3() { ScriptWithPointerToFuturePointer_Format_FixBrokenPointer("0B") }
      @Test fun ScriptWithPointerIntoExistingData_Format_DoNotFormatPointer() {
         SetFullModel(0xFF)
         CreateTextTable("names", 0x100, "Adam", "Brad", "Carl", "Dave", "Eric", "Fred")
         "06 00 02 01 00 08 02".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("@000 ^script`xse`")

         EventScript  += " "; // force formatting

         Model.resolveConflicts() // no conflicts = pass
      }
      @Test fun Script_AddOpenBrace_AutoAddCloseBrace() {
         EventScript  = "loadpointer 0 <100>;end"

         EventScript  = "loadpointer 0 <100>;{;end"

         Assert.equal("loadpointer 0 <100>;{;};end", EventScript)
      }
      @Test fun ApplyMovement_UseFreespaceAddress_AutoWriteEmptyContent() {
         SetFullModel(0xFF)

         EventScript  = "applymovement 0 <000080>;end"

         Assert.equal(0xFE, Model[0x80])
      }
      @Test fun Script_PointerToScriptDirectlyAfter_NoAuto() {
         SetFullModel(0xFF)

         EventScript  = "goto <auto>"

         Assert.isTrue(Tool.contents[0].hasError)
      }
      @Test fun PokeMart_FreespaceAddress_InsertReasonableScript() {
         SetFullModel(0xFF)
         Model.writeMultiByteValue(0x100, 2, Token, 0); // correct end token so that it looks _just barely_ like mart data
         EventScript  = "pokemart <0000C0>;{;1;};end"

         var martData = (Model.getNextRun(0xC0) as TableStreamRun)
         Assert.equal(2, martData.length)
      }
      @Test fun EventWithGoto_AddCommandBeforeGoto_PointerFormatShifts() {
         SetFullModel(0xFF)
         EventScript  = "goto <000000>"

         EventScript  = "addvar 1 1;goto <000000>"

         Assert.equal(6, Model.getNextRun(1).start)
      }
      @Test fun SelfReferenceScript_Compile_CorrectAnchorFormat() {
         SetFullModel(0xFF)
         EventScript  = "top:;goto top"
         Assert.isType<XSERun>(Model.getNextRun(0))
      }
      @Test fun TrainerScript_ManyAutos_AllTextPointersAreCorrect() {
         SetFullModel(0xFF)
         EventScript  = ";".join(arrayOf(
            "if.flag.set.goto 206 <section1>", // 9
            "msgbox.npc <auto>;{;Text1;};",    // 8
            "end",                             // 1

            "section1:",
            "trainerbattle 1 1 0 <auto> <auto> <section2>",  // 18 (2+2+2+4+4+4)
            "{;Intro;}",
            "{;Defeat;}",
            "end",

            "section2:;end"))

         var text1 = Model.textConverter.convert(Model, Model.readPointer(11), 10)
         var intro = Model.textConverter.convert(Model, Model.readPointer(24), 10)
         var defeat = Model.textConverter.convert(Model, Model.readPointer(28), 10)
         Assert.equal("Text1", text1!!.trim('"'))
         Assert.equal("Intro", intro!!.trim('"'))
         Assert.equal("Defeat", defeat!!.trim('"'))
      }
      fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1(comparisonOperator: String, comparisonBytes: Int) {
         var expected = "21 0D 80 64 00 06 ${(comparisonBytes).toHex(2)} 00 01 00 08".parseHexBytes()

         EventScript  = "if.compare.goto 0x800D ${comparisonOperator} 100 <100>"

         var actual = Model.take(expected.size).toTypedArray()
         Assert.equal(expected, actual)
      }
    @Test fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1_1() { IfCompareGotoMacro_Comparisons_CompilesToCompareIf1("<", 0) }
    @Test fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1_2() { IfCompareGotoMacro_Comparisons_CompilesToCompareIf1("=", 1) }
    @Test fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1_3() { IfCompareGotoMacro_Comparisons_CompilesToCompareIf1(">", 2) }
    @Test fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1_4() { IfCompareGotoMacro_Comparisons_CompilesToCompareIf1("<=", 3) }
    @Test fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1_5() { IfCompareGotoMacro_Comparisons_CompilesToCompareIf1(">=", 4) }
    @Test fun IfCompareGotoMacro_Comparisons_CompilesToCompareIf1_6() { IfCompareGotoMacro_Comparisons_CompilesToCompareIf1("!=", 5) }
      @Test fun InvalidCommand_Compile_HasError() {
         EventScript  = "not_a_command"

         Assert.isTrue(Tool.contents[0].hasError)
      }
      @Test fun FireRed_ShowMoney_Reserve4Bytes() {
         SetGameCode("BPRE0")
         Tool.scriptParser.refreshGameHash(Model)

         val script = Ref("if1 0 <section2>;showmoney 5 6 7;section2:;end".replace(";", "\n"))
         var bytes = Tool.scriptParser.compile(Token, Model, 0, script, Ref(nullOf()))

         Assert.equal(10, bytes!![2])
      }
      @Test fun ScriptStartsWithEnd_ScriptContainsPointer_PointerFormatted() {
         EventScript  = "end;if.yes.goto <section1>;end;section1:;end"
         var run = Model.getNextRun(1)
         Assert.equal(8, run.start)
         Assert.isType<PointerRun>(run)
      }
      @Test fun ScriptGotoBeforeScriptStarts_Reload_IncludesSubScript() {
         EventScript  = "end"
         ViewPort.goto!!.execute(0x10)

         EventScript  = "if.yes.goto <section1>;end;section1:;if.yes.goto <000000>;end"

         Assert.equal(2, Tool.contents.size)
      }
      @Test fun Compare_SingleEquals_CompilesToDoubleEquals() {
         EventScript  = "if.compare.goto 0x4000 = 7 <720010>"
         var expected = "21 00 40 07 00 06 01 10 00 72 08 02".parseHexBytes()
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], Model[i]) })
      }
      @Test fun EntireScriptSelected_SelectLastByte_ShownScriptUpdated() {
         EventScript  = "nop;end"
         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.selectionEnd  = newOf(1, 0)

         ViewPort.selectionStart  = newOf(1, 0)

         Assert.equal("end", EventScript)
      }
   }
