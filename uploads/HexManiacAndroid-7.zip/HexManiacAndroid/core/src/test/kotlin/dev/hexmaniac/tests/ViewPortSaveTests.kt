@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ViewPortSaveTests : BaseViewModelTestClass() {

      private lateinit var fileSystem: StubFileSystem
      private var name: String = ""

      init {
         fileSystem  = StubFileSystem().also { it.requestNewName = lm1@{ previousName, description, extensions -> name  = "file.txt"; return@lm1 name }; it.trySavePrompt = lm2@{ loadedFile -> name  = loadedFile.name; return@lm2 true } }
      }
      @Test fun SaveAsRequestsNewName() {
         var viewPort = ViewPort()
         viewPort.saveAs.execute(fileSystem)

         Assert.equal("file.txt", name)
      }
      @Test fun SaveRequestsNewNameIfFileIsNew() {
         var viewPort = ViewPort()

         viewPort.edit("01 23 45")
         viewPort.save!!.execute(fileSystem)

         Assert.equal("file.txt", name)
      }
      @Test fun SaveDoesNotRequestNewNameIfFileIsNotNew() {
         var viewPort = ViewPort(LoadedFile("input.txt", ByteArray(0)))
         fileSystem.save  = lm3@{ loadedFile -> name  = loadedFile.name; return@lm3 true }

         viewPort.edit("01 23 45")
         viewPort.save!!.execute(fileSystem)

         Assert.equal("input.txt", name)
      }
      @Test fun SaveDoesNotCallFileSystemTrySavePromptIfNoChanges() {
         var viewPort1 = ViewPort()
         var viewPort2 = ViewPort(LoadedFile("input1.txt", ByteArray(10)))
         var viewPort3 = ViewPort(LoadedFile("input2.txt", ByteArray(10)))

         Assert.isFalse(viewPort1.save!!.canExecute(fileSystem))
         viewPort1.save!!.execute(fileSystem)

         Assert.isFalse(viewPort2.save!!.canExecute(fileSystem))
         viewPort2.save!!.execute(fileSystem)

         viewPort3.edit("01 23 45 67 89")
         viewPort3.undo.execute()
         Assert.isFalse(viewPort3.save!!.canExecute(fileSystem))
         viewPort3.save!!.execute(fileSystem)

         Assert.equal("", name) // none should have called TrySave
      }
      @Test fun EditedFilePromptsForSaveOnExit() {
         var triedToSave: Boolean = false
         var viewPort = ViewPort()
         viewPort.edit("ab cd ef")
         fileSystem.trySavePrompt  = lm4@{ loadedFile -> triedToSave  = true; return@lm4 true }

         viewPort.close.execute(fileSystem)

         Assert.isTrue(triedToSave)
      }
      @Test fun NonEditedFileDoesNotPromptForSaveOnExit() {
         var triedToSave: Boolean = false
         var viewPort = ViewPort(LoadedFile("input.txt", ByteArray(10)))
         fileSystem.trySavePrompt  = lm5@{ loadedFile -> triedToSave  = true; return@lm5 true }

         Assert.isFalse(viewPort.save!!.canExecute(fileSystem))
         viewPort.close.execute(fileSystem)

         Assert.isFalse(triedToSave)
      }
      @Test fun FileRaisesCloseEventIfClosedWithoutEdit() {
         var closed: Int = 0
         var viewPort = ViewPort()
         viewPort.closed  += { sender, e -> closed++ }

         viewPort.close.execute(fileSystem)

         Assert.equal(1, closed)
      }
      @Test fun FileRaisesCloseEventIfSavedAfterEdit() {
         var closed: Int = 0
         var viewPort = ViewPort()
         viewPort.closed  += { sender, e -> closed++ }
         fileSystem.trySavePrompt  = { loadedFile -> true }

         viewPort.edit("12")
         viewPort.close.execute(fileSystem)

         Assert.equal(1, closed)
      }
      @Test fun FileRaisesCloseEventIfNotSavedAfterEdit() {
         var closed: Int = 0
         var viewPort = ViewPort()
         viewPort.closed  += { sender, e -> closed++ }
         fileSystem.trySavePrompt  = { loadedFile -> false }

         viewPort.edit("12")
         viewPort.close.execute(fileSystem)

         Assert.equal(1, closed)
      }
      @Test fun FileDoesNotRaiseCloseEventIfSaveCanceled() {
         var closed: Int = 0
         var viewPort = ViewPort()
         viewPort.closed  += { sender, e -> closed++ }
         fileSystem.trySavePrompt  = { loadedFile -> null }

         viewPort.edit("12")
         viewPort.close.execute(fileSystem)

         Assert.equal(0, closed)
      }
      @Test fun CallingSaveMultipleTimesOnlySavesOnce() {
         var count: Int = 0
         var viewPort = ViewPort()
         fileSystem.save  = lm6@{ loadedFile -> count++; return@lm6 true }

         viewPort.edit("00 01 02")
         viewPort.save!!.execute(fileSystem)
         viewPort.save!!.execute(fileSystem)

         Assert.equal(1, count)
      }
      @Test fun SaveCanExecuteChangesOnEdit() {
         var canExecuteChangedCount: Int = 0
         var viewPort = ViewPort(LoadedFile("input.txt", ByteArray(20)))
         viewPort.save!!.canExecuteChanged  += { sender, e -> canExecuteChangedCount++ }

         viewPort.edit("aa bb cc")

         Assert.equal(1, canExecuteChangedCount)
      }
      @Test fun SaveCanExecuteChangesOnUndo() {
         var canExecuteChangedCount: Int = 0
         var viewPort = ViewPort(LoadedFile("input.txt", ByteArray(20)))
         viewPort.save!!.canExecuteChanged  += { sender, e -> canExecuteChangedCount++ }

         viewPort.edit("aa bb cc")
         viewPort.undo.execute()

         Assert.equal(2, canExecuteChangedCount)
      }
      @Test fun ViewPortNameDoesNotContainPathOrExension() {
         var viewPort = ViewPort(LoadedFile("path/to/myfile.txt", ByteArray(10)))

         Assert.equal("myfile", viewPort.name)
      }
      @Test fun ViewPortNameEndsWithStarIfNeedsSave() {
         var viewPort = ViewPort(LoadedFile("path/to/myfile.txt", ByteArray(10)))
         var nameChangedCount: Int = 0
         viewPort.propertyChanged  += lm7@{ sender, e -> if (e.propertyName == "name") nameChangedCount++ }

         viewPort.edit("12 34 56")

         Assert.endsWith("*", viewPort.name)
         Assert.equal(1, nameChangedCount)
      }
      @Test fun ViewPortHasDefaultNameBeforeFirstSave() {
         var viewPort = ViewPort()

         Assert.notEqual("", viewPort.name)
         Assert.notNull(viewPort.name)
      }
      @Test fun EditDefaultFileStillShowsStar() {
         var viewPort = ViewPort()
         var name = viewPort.name

         viewPort.edit("11 22 33")

         Assert.equal("${name}*", viewPort.name)
      }
      @Test fun ViewPortTakesNewNameOnSave() {
         var fileSystem = StubFileSystem().also { it.requestNewName = { originalName, description, extensions -> "path/to/newfile.txt" }; it.save = { loadedFile -> true } }
         var viewPort = ViewPort()
         var nameChangedCount: Int = 0
         viewPort.propertyChanged  += lm8@{ sender, e -> if (e.propertyName == "name") nameChangedCount++ }

         viewPort.edit("012345")
         Assert.equal(1, nameChangedCount)
         viewPort.save!!.execute(fileSystem)

         Assert.equal("newfile", viewPort.name)
         Assert.equal(3, nameChangedCount)
      }
      @Test fun ViewPortRequestsDelayedReloadIfReloadFails() {
         var viewPort = ViewPort(LoadedFile("file.txt", ByteArray(50)))
         var fileSystem = StubFileSystem().also { it.loadFile = { fileName -> throw IOException() } }

         var retryCount = 0
         viewPort.requestDelayedWork  += { sender, e -> retryCount++ }

         viewPort.considerReload(fileSystem)

         Assert.equal(1, retryCount)
      }
      @Test fun ViewPortAdjustsSelectionWhenLoadingAShorterFile() {
         var viewPort = ViewPort(LoadedFile("file.txt", ByteArray(12))).also { it.selectionStart = Point(3, 3) }
         Assert.equal(4, viewPort.width)
         Assert.equal(4, viewPort.height)
         Assert.equal(Point(0, 3), viewPort.selectionStart)

         var fileSystem = StubFileSystem().also { it.loadFile = { filename -> LoadedFile("file.txt", ByteArray(10)) } }
         viewPort.considerReload(fileSystem)

         Assert.equal(Point(2, 2), viewPort.selectionStart)
      }
      @Test fun ViewPortNotifiesOnFileNameChange() {
         var properties = ArrayList<String>()

         var fileSystem = StubFileSystem().also { it.requestNewName = { currentName, description, extensionOptions -> "file.txt" }; it.save = { file -> true } }
         var viewPort = ViewPort()
         viewPort.propertyChanged  += { sender, e -> properties.add(e.propertyName!!) }

         viewPort.edit("01 23 45 67")
         viewPort.saveAs.execute(fileSystem)

         Assert.contains("fileName", properties)
         Assert.equal("file.txt", viewPort.fileName)
      }
      @Test fun EditorUpdatesFileSystemWatchesWhenViewPortFileNameChanges() {
         var fileSystem = StubFileSystem()
         var addCalls: Int = 0; var removeCalls: Int = 0
         fileSystem.addListenerToFile  = { fileName, action -> addCalls++ }
         fileSystem.removeListenerForFile  = { fileName, action -> removeCalls++ }
         var editor = EditorViewModel(fileSystem)
         var tab = StubViewPort()

         editor.add(tab)
         Assert.equal(0, addCalls)
         Assert.equal(0, removeCalls)

         tab.fileName  = "file.txt"
         tab.propertyChanged.invoke(tab, ExtendedPropertyChangedEventArgs<String?>(null, "fileName"))
         Assert.equal(1, addCalls)
         Assert.equal(0, removeCalls)

         tab.fileName  = "file2.txt"
         tab.propertyChanged.invoke(tab, ExtendedPropertyChangedEventArgs<String>("file.txt", "fileName"))
         Assert.equal(2, addCalls)
         Assert.equal(1, removeCalls)
      }
      @Test fun CanSaveAndLoadNamesAndFormats() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         var metadata: StoredMetadata? = null
         var fileSystem = StubFileSystem().also { it.save = { file -> true }; it.saveMetadata = lm9@{ file, md -> metadata  = StoredMetadata(md!!); return@lm9 true } }

         viewPort.edit("^bob\"\" \"Hello\"")
         viewPort.save!!.execute(fileSystem)

         var model2 = PokemonModel(Model.rawData, metadata)
         var viewPort2 = AutoSearchTests.newViewPort("file.txt", model2)

         Assert.equal("bob", (((viewPort2[0, 0].format) as Anchor)).name)
      }
      @Test fun FormattingChangesDoNotMakeFileDirty() {
         var buffer = Enumerable.Repeat(0xFF.u8(), 0x200).toTypedArray()
         var model = PokemonModel(buffer.toByteArr())
         var viewPort = AutoSearchTests.newViewPort("file.txt", model)
         var fileSystem = StubFileSystem()

         viewPort.edit("^bob ")

         Assert.isTrue(viewPort.save!!.canExecute(fileSystem))
         Assert.doesNotContain("*", viewPort.name)
      }
      @Test fun UndoRedoRestoresSaveStar() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         var nameChangedCount: Int = 0
         viewPort.propertyChanged  += lm10@{ sender, e -> if (e.propertyName == "name") nameChangedCount++ }
         var fileSystem = StubFileSystem()

         viewPort.edit("AA");       // notify 1 -> adding the star
         viewPort.undo.execute();   // notify 2 -> removing the star
         viewPort.redo.execute();   // notify 3 -> re-adding the star

         Assert.contains("*", viewPort.name)
         Assert.equal(3, nameChangedCount)
      }
      @Test fun ViewPortWarnsIfLoadedMatchedWordValueDoesNotMatch() {
         // Arrange
         var data = ByteArray(0x200)
         var model = PokemonModel(data)
         var change = ModelDelta()
         var dispatcher = ControlledDispatch()
         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[a:]8", 0x10, null, table)
         model.observeAnchorWritten(change, "table", table.value!!)
         change.addMatchedWord(model, 0, "table", 4)
         model.observeRunWritten(change, WordRun(0, "table", 4, 0, 1))

         fileSystem.metadataFor  = { name -> model.exportMetadata(BaseViewModelTestClass.Singletons.metadataInfo)!!.serialize() }
         fileSystem.openFile  = { name, extensions -> LoadedFile(name!!, data) }
         var editor = EditorViewModel(fileSystem, dispatcher)

         // change the data so that the viewPort will notice something weird
         change.changeData(model, 0, 4)

         // Act
         editor.open.execute("text.gba")
         dispatcher.runAllWorkloads()

         // Assert
         Assert.isTrue(editor.showMessage)
      }
      @Test fun UpdateOldTableWithNewNameTest() {
         // setup data with a pointer from 0x60 to 0x10
         var data = ByteArray(0x200)
         data[0x63]  = 0x08

         // setup the metadata loaded from file
         var anchor1 = StoredAnchor(0x00, "bob",   "[number::]4")
         var anchor2 = StoredAnchor(0x20, "user1", "[number::bob]4")
         var anchor3 = StoredAnchor(0x40, "user2", "[number::]bob")
         var metadataInfo = StubMetadataInfo().also { it.versionNumber = "0.3.0.0" }
         var metadata = StoredMetadata(listOf( anchor1, anchor2, anchor3), null, null, null, null, null, metadataInfo, 0, 0, 0)

         // setup the current reference, loaded from singletons
         var gameReferenceTables = GameReferenceTables(listOf( ReferenceTable("tom", 0, 0x60, "[number::]4")))
         var singletons = Singletons(
            StubMetadataInfo().also { it.versionNumber = "0.4.0.0" },
            linkedMapOf<String, GameReferenceTables>(string(0.toChar(), 4) + "0" to gameReferenceTables))

         // create a model, which should notice and resolve the conflict
         var model = PokemonModel(data, metadata, singletons)

         // 'bob' updated to 'tom'
         Assert.equal("tom", model.getAnchorFromAddress(-1, 0x00))
         Assert.equal("tom", ((((model.getNextRun(0x20) as ITableRun)).elementContent[0] as ArrayRunEnumSegment)).enumName)
         Assert.equal("tom", ((model.getNextRun(0x40) as ArrayRun)).lengthFromAnchor)
      }
      @Test fun UpdateOldTableWithNewName_UpdatesBitArrays() {
         // setup data with a pointer from 0x60 to 0x00 and some strings from 0x00 to 0x10
         var data = ByteArray(0x200)
         data[0x60]  = 0x10
         data[0x63]  = 0x08
         var i: Int = 0
         for (b in PCSString.convert("aaa")!!) data[i++]  = b.toByte()
         for (b in PCSString.convert("bbb")!!) data[i++]  = b.toByte()
         for (b in PCSString.convert("ccc")!!) data[i++]  = b.toByte()
         for (b in PCSString.convert("ddd")!!) data[i++]  = b.toByte()

         // setup the metadata loaded from file
         var anchor1 = StoredAnchor(0x00, "names", "[name\"\"4]4")
         var anchor2 = StoredAnchor(0x10, "bob", "[number::]names")
         var anchor3 = StoredAnchor(0x20, "user1", "[number|b[]bob]4"); // should be 4 bytes long
         var metadataInfo = StubMetadataInfo().also { it.versionNumber = "0.3.0.0" }
         var metadata = StoredMetadata(listOf( anchor1, anchor2, anchor3), null, null, null, null, null, metadataInfo, 0, 0, 0)

         // setup the current reference, loaded from singletons
         var gameReferenceTables = GameReferenceTables(listOf( ReferenceTable("tom", 0, 0x60, "[number::]names")))
         var singletons = Singletons(
            StubMetadataInfo().also { it.versionNumber = "0.4.0.0" },
            linkedMapOf<String, GameReferenceTables>(string(0.toChar(), 4) + "0" to gameReferenceTables))

         // create a model, which should notice and resolve the conflict
         var model = PokemonModel(data, metadata, singletons)

         // 'bob' updated to 'tom'
         Assert.equal("tom", ((((model.getNextRun(0x20) as ITableRun)).elementContent[0] as ArrayRunBitArraySegment)).sourceArrayName)
      }
      @Test fun UpdateOldTableWithNewName_MatchedLengthTableWithLengthModifier_UpdatesLengthCorrectly() {
         var data = ByteArray(0x200)
         data[0x33]  = 0x08; // pointer from 0x30 to 0x00

         // metadata, loaded from the file
         var metadata = StoredMetadata(
            listOf(
               StoredAnchor(0x00, "bob", "[data:]4"),
               StoredAnchor(0x10, "sam", "[data:]bob+2")),
            null, null, null, null, null,
            StubMetadataInfo().also { it.versionNumber = "0.3.0.0" },
            0,
            0,
            0)

         // setup the current reference, loaded from singletons
         var gameReferenceTables = GameReferenceTables(listOf( ReferenceTable("tom", 0, 0x30, "[data:]4")))
         var singletons = Singletons(
            StubMetadataInfo().also { it.versionNumber = "0.4.0.0" },
            linkedMapOf<String, GameReferenceTables>(string(0.toChar(), 4) + "0" to gameReferenceTables))

         // create a model, which should notice and resolve the conflict
         var model = PokemonModel(data, metadata, singletons)

         // 'bob' updated to 'tom' in sam's length
         Assert.equal("[data:]tom+2", model.getNextRun(0x10).formatString)
      }
      @Test fun UpdateOldTableWithNewName_UpdatesTilemapTilesetHints() {
         var data = ByteArray(0x200)

         // header for compressed tilemap
         data[0]  = 0x10
         data[1]  = 2; // 2 bytes = 1 tile. 0000 = use tile 0, palette 0. Next 3 bytes represent the compressed data.

         // header for the compressed tileset
         data[8]  = 0x10
         data[9]  = 0x20; // 0x20 bytes = 1 tile. Next 0x24 bytes represent the compressed data.

         run { val tt_ = listOf(0x08, 0x00, 0x00, 0x00); data[0x33] = tt_.component1().toByte(); data[0x32] = tt_.component2().toByte(); data[0x31] = tt_.component3().toByte(); data[0x30] = tt_.component4().toByte() }; // pointer to tilemap
         run { val tt_ = listOf(0x08, 0x00, 0x00, 0x08); data[0x37] = tt_.component1().toByte(); data[0x36] = tt_.component2().toByte(); data[0x35] = tt_.component3().toByte(); data[0x34] = tt_.component4().toByte() }; // pointer to tileset

         // metadata, loaded from the file
         var metadata = StoredMetadata(
            listOf(
               StoredAnchor(0x00, "bob", "`lzm4x1x1|tileset1`"),
               StoredAnchor(0x08, "tileset1", "`lzt4`")),
            null, null, null, null, null,
            StubMetadataInfo().also { it.versionNumber = "0.3.0.0" },
            0,
            0,
            0)

         // setup the current reference, loaded from singletons
         var gameReferenceTables = GameReferenceTables(listOf( ReferenceTable("tileset2", 0, 0x34, "`lzt4`")))
         var singletons = Singletons(
            StubMetadataInfo().also { it.versionNumber = "0.4.0.0" },
            linkedMapOf<String, GameReferenceTables>(string(0.toChar(), 4) + "0" to gameReferenceTables))

         // create a model, which should notice and resolve the conflict
         var model = PokemonModel(data, metadata, singletons)

         // assert that 'tileset1' was replaced with 'tileset2'
         Assert.equal("`lzm4x1x1|tileset2`", model.getNextRun(0x00).formatString)
      }
      @Test fun Model_OffsetPointerMetadata_ContainsOffsetPointers() {
         var storedOffsetPointer = StoredOffsetPointer(0x100, Pointer.null_)
         var singletons = BaseViewModelTestClass.Singletons
         var metadata = StoredMetadata(null, null, null, listOf( storedOffsetPointer), null, null, singletons.metadataInfo, 0, 0, 0)

         var model = PokemonModel(ByteArray(0x200), metadata, singletons)

         // assert that the offset pointer was created
         var run = (model.getNextRun(0x100) as OffsetPointerRun)
         Assert.equal(Pointer.null_, run.offset)

         // assert that the destination knows about it
         var anchor = model.getNextRun(0)
         Assert.equal(0, anchor.start)
         Assert.equal(0x100, anchor.pointerSources!!.single())
      }
      @Test fun CustomBufferSpace_MoveData_LessSpaceIsWasted() {
         Model.expandData(ModelDelta(), 0x400)
         SetFullModel(0xFF)
         Model[2]  = 0x10
         Model[0x100]  = 0x10
         var metadata = Model.exportMetadata(Singletons.metadataInfo)
         metadata  = StoredMetadata(metadata!!.namedAnchors,
            metadata!!.unmappedPointers,
            metadata!!.matchedWords,
            metadata!!.offsetPointers,
            metadata!!.lists,
            metadata!!.unmappedConstants,
            Singletons.metadataInfo,
            metadata!!.freeSpaceSearch,
            0x10,
            metadata!!.nextExportID)

         Model.loadMetadata(metadata)
         ViewPort.refresh()
         ViewPort.edit("^table[a:]1 2 +")

         var table = Model.getTable("table")
         Assert.inRange(table!!.start, 0x100, 0x180)
      }
      @Test fun StaticVariable_Serialize_Serialized() {
         ViewPort.edit("@somevariable=0x12345678 ")

         var metadata = Model.exportMetadata(Singletons.metadataInfo)

         Assert.single(metadata!!.unmappedConstants)
         Assert.equal("somevariable", metadata!!.unmappedConstants[0].name)
         Assert.equal(0x12345678, metadata!!.unmappedConstants[0].value)
      }
      @Test fun UnmappedConstantInMetadata_Deserialize_UnmappedConstantInModel() {
         Model.load(ByteArray(0x200), StoredMetadata(unmappedConstants = mutableListOf<StoredUnmappedConstant>( StoredUnmappedConstant("somevar", 0x12345678))))

         val value = Ref<Int>(0)
         Model.tryGetUnmappedConstant("somevar", value)

         Assert.equal(0x12345678, value.value)
      }
      @Test fun MetadataChangeThenUndo_ChangeTableLengthFromAnchor_CanSave() {
         var fs = StubFileSystem().also { it.save = { arg -> true } }
         ViewPort.edit("^table[a:]4 ")
         ViewPort.save!!.execute(fs)
         ViewPort.refresh()
         ViewPort.anchorText  = "^table[a:]3 "
         ViewPort.undo.execute()
         ViewPort.refresh()

         var notifyCanExecuteChange: Boolean = false
         ViewPort.save!!.canExecuteChanged  += { sender, e -> notifyCanExecuteChange  = true }
         ViewPort.anchorText  = "^table[a:]3 "

         Assert.isTrue(notifyCanExecuteChange)
         Assert.isTrue(ViewPort.save!!.canExecute(fs))
      }
      @Test fun SavedMetadata_MetadataChange_ToolbarCanSave() {
         var fs = StubFileSystem().also { it.save = { arg -> true } }
         ViewPort.edit("^table[a:]4 ")
         ViewPort.save!!.execute(fs)
         ViewPort.refresh()
         var editor = EditorViewModel(fs, Singletons.workDispatcher)
         editor.add(ViewPort)

         var notifyCanExecuteChange: Boolean = false
         editor.save.canExecuteChanged  += { sender, e -> notifyCanExecuteChange  = true }
         ViewPort.anchorText  = "^table[a:]3 "

         Assert.isTrue(notifyCanExecuteChange)
         Assert.isTrue(editor.save.canExecute(fs))
      }
      @Test fun MetadataChange_CheckChange_IsMetadataOnlyChange() {
         var view = StubView(ViewPort)

         ViewPort.edit("^test ")

         Assert.isTrue(ViewPort.isMetadataOnlyChange)
         Assert.contains("isMetadataOnlyChange", view.propertyNotifications)
      }
      @Test fun GotoShortcut_WriteSameShortcutTwice_MetadataContainsOneCopy() {
         var shortcuts = listOf( StoredGotoShortcut("name", "image", "destination"))
         var metadata = StoredMetadata(null, null, null, null, null, null, shortcuts, Singletons.metadataInfo, null)

         Model.loadMetadata(metadata)
         Model.loadMetadata(metadata)

         Assert.single(Model.exportMetadata(Singletons.metadataInfo)!!.gotoShortcuts)
      }
      @Test fun MetadataWithShowRawIVByteForTrainer_CreateTrainerRun_ShowRawIVByteForTrainer() {
         var metadata = StoredMetadata(null, null, null, null, null, null, null, Singletons.metadataInfo, StoredMetadataFields().also { it.showRawIVByteForTrainer = true })
         var model = PokemonModel(ByteArray(0x200), metadata)

         var newRun = ((model.formatRunFactory.getStrategy("`tpt`")!!.writeNewRun(model, Token, Pointer.null_, 0, "test", emptyList())) as IStreamRun)
         model[0]  = 100

         Assert.contains("IVs=100", newRun.serializeRun())
      }
      @Test fun DefaultMetadata_DoNotShowIVByteForTrainer() {
         var metadata = StoredMetadata(emptyArray<String>())
         Assert.isFalse(metadata.showRawIVByteForTrainer)
      }
      @Test fun DoNotShowIVByteForTrainerContentInText_Parse_MetadataContainsFlag() {
         var metadata = StoredMetadata(arrayOf( "ShowRawIVByteForTrainer = True"))
         Assert.isTrue(metadata.showRawIVByteForTrainer)
      }
      @Test fun StoredListWithCustomHash_ExportMetadata_HashSaved() {
         Model.setList(Token, "list", listOf( "a", "b", "c"), "0")

         var metadata = Model.exportMetadata(Singletons.metadataInfo)

         var list = metadata!!.lists[0]
         Assert.equal("list", list.name)
         Assert.equal("0", list.hash)
         Assert.isFalse(list.hashMatches)
      }
      @Test fun TableGroup_ExportMetadata_ExportHash() {
         var items = arrayOf( "a", "b", "c")
         Model.appendTableGroup(Token, "group", items.toList(), null)

         var metadata = Model.exportMetadata(Singletons.metadataInfo)
         var lines = metadata!!.serialize()

         var line = lines.single({ line -> line.startsWith("DefaultHash") })
         var expectedHash = StoredList.generateHash(items.toList())
         Assert.equal("DefaultHash = '''${expectedHash}'''", line)
      }
      @Test fun LoadShortcut_SameTableAlreadyInShortcut_NoLoad() {
         var shortcut1 = StoredGotoShortcut("name1", "image1", "destination/1")
         Model.loadMetadata(StoredMetadata(gotoShortcuts = listOf( shortcut1)))

         var shortcut2 = StoredGotoShortcut("name2", "image2", "destination/2")
         Model.loadMetadata(StoredMetadata(gotoShortcuts = listOf( shortcut2)))

         Assert.single(Model.gotoShortcuts)
      }
      @Test fun TableWithOriginalFormat_LoadNewFormat_Updates() {
         SetFullModel(0xFF)
         SetGameCode("ABCD0")
         var constants = LinkedHashMap<String, GameReferenceConstants>()
         ViewPort.edit("@100 <180> @180 01 00 02 00 10 00 20 00 ")

         var refTables = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[a: b:]2")))
         var refForGame = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         var info = StubMetadataInfo().also { it.versionNumber = "0.1.0" }
         var model: IDataModel = HardcodeTablesModel(Singletons(info, refForGame, constants), Model.rawData, StoredMetadata())
         var metadata = model.exportMetadata(refTables, info)

         refTables  = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[x: y:]2")))
         refForGame  = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         info  = StubMetadataInfo().also { it.versionNumber = "0.2.0" }
         model  = PokemonModel(Model.rawData, metadata, Singletons(info, refForGame, constants))

         Assert.equal("[x: y:]2", model.getNextRun(0x180).formatString)
      }
      @Test fun TableWithOriginalNoLengthFormat_LoadNewNoLengthFormat_Updates() {
         SetFullModel(0xFF)
         SetGameCode("ABCD0")
         var constants = LinkedHashMap<String, GameReferenceConstants>()
         ViewPort.edit("@100 <180> @180 01 00 02 00 10 00 20 00 ")

         var refTables = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[a:100 b:100]")))
         var refForGame = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         var info = StubMetadataInfo().also { it.versionNumber = "0.1.0" }
         var model: IDataModel = HardcodeTablesModel(Singletons(info, refForGame, constants), Model.rawData, StoredMetadata())
         var metadata = model.exportMetadata(refTables, info)

         refTables  = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[x:100 y:100]")))
         refForGame  = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         info  = StubMetadataInfo().also { it.versionNumber = "0.2.0" }
         model  = PokemonModel(Model.rawData, metadata, Singletons(info, refForGame, constants))

         Assert.equal("[x:100 y:100]2", model.getNextRun(0x180).formatString)
      }
      @Test fun TableWithEditedFormat_LoadNewFormat_DoesNotUpdate() {
         SetFullModel(0xFF)
         SetGameCode("ABCD0")
         var constants = LinkedHashMap<String, GameReferenceConstants>()
         ViewPort.edit("@100 <180> @180 01 00 02 00 10 00 20 00 ")

         var refTables = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[a: b:]2")))
         var refForGame = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         var info = StubMetadataInfo().also { it.versionNumber = "0.1.0" }
         var singletons = Singletons(info, refForGame, constants)
         var model: IDataModel = HardcodeTablesModel(singletons, Model.rawData, StoredMetadata())
         var viewPort = ViewPort("", model, Singletons.workDispatcher, singletons)
         viewPort.edit("@180 ^name[i: j:]2 ")
         var metadata = model.exportMetadata(refTables, info)

         refTables  = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[x: y:]2")))
         refForGame  = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         info  = StubMetadataInfo().also { it.versionNumber = "0.2.0" }
         model  = PokemonModel(Model.rawData, metadata, Singletons(info, refForGame, constants))

         Assert.equal("[i: j:]2", model.getNextRun(0x180).formatString)
      }
      fun TableWithNoHash_LoadNewFormat_Updates(defaultValue: String) {
         SetFullModel(0xFF)
         SetGameCode("ABCD0")
         var constants = LinkedHashMap<String, GameReferenceConstants>()
         ViewPort.edit("@100 <180> @180 01 00 02 00 10 00 20 00 ")

         var metadata = StoredMetadata(listOf( StoredAnchor(0x180, "name", "[i: j:]2", defaultValue)))

         var refTables = GameReferenceTables(listOf( ReferenceTable("name", 0, 0x100, "[x: y:]2")))
         var refForGame = linkedMapOf<String, GameReferenceTables>("ABCD0" to refTables)
         var info = StubMetadataInfo().also { it.versionNumber = "0.2.0" }
         var model = PokemonModel(Model.rawData, metadata, Singletons(info, refForGame, constants))

         Assert.equal("[x: y:]2", model.getNextRun(0x180).formatString)
      }
    @Test fun TableWithNoHash_LoadNewFormat_Updates_1() { TableWithNoHash_LoadNewFormat_Updates("") }
    @Test fun TableWithNoHash_LoadNewFormat_Updates_2() { TableWithNoHash_LoadNewFormat_Updates("") }
      @Test fun Patch_Apply_CanSave() {
         SetFullModel(0xFF)

         var patch = ArrayList<Int>()
         patch.addAll("PATCH".map({ c -> c.u8() }))
         patch.addAll(Patcher.buildChunk(ByteArray(0x200), 0x100, 0x10).map { it.toInt() and 0xFF }); // offset
         patch.addAll("EOF".map({ c -> c.u8() }))

         ViewPort.tryImport(LoadedFile("patch.ips", patch.toByteArrayU()), FileSystem)

         Assert.isFalse(ViewPort.changeHistory.isSaved)
      }
   }
