@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ItemEffectTests : BaseViewModelTestClass() {
      private lateinit var run: PIERun
      init {
         run  = PIERun(Model, 0, SortedSpan<Int>.none())
         Model.observeRunWritten(Token, run)
         Model.writeValue(Token, run.length, -1)
      }
      @Test fun NoLabel_Autocomplete_NoOptions() {
         var options = run.getAutoCompleteOptions("some text", 0, 9)
         Assert.empty(options)
      }
      @Test fun ApplyToFirstPokemon_Autocomplete_BoolOptions() {
         var options = run.getAutoCompleteOptions("ApplyToFirstPokemonOnly=", 0, 24)

         Assert.equal("false", options[0].text)
         Assert.equal("ApplyToFirstPokemonOnly = true", options[1].lineText)
      }
      @Test fun Arg_Autocomplete_ArgOptions() {
         var options = run.getAutoCompleteOptions("Arg=", 0, 4)

         Assert.equal("LevelUpHealth", options[0].text)
         Assert.equal("Half", options[1].text)
         Assert.equal("Arg = Max", options[2].lineText)
      }
      @Test fun General_AutoCompleteBeforeEquals_NoOptions() {
         var options = run.getAutoCompleteOptions("General = {", 0, 8)
         Assert.empty(options)
      }
      @Test fun General_AutoCompleteAfterCurly_RemainingOptions() {
         var options = run.getAutoCompleteOptions("General = { GuardSpec,  LevelUp }", 0, 23)
         Assert.equal(4, options.size)
         Assert.equal("HealHealth", options[0].text)
         Assert.equal("General = { GuardSpec, HealPowerPoints, LevelUp }", options[1].lineText)
      }
      @Test fun General_AutoCompleteMidWord_FilteredOptions() {
         var options = run.getAutoCompleteOptions("General = { heal }", 0, 16)
         Assert.equal(3, options.size)
         Assert.equal("HealHealth", options[0].text)
         Assert.equal("General = { HealPowerPoints }", options[1].lineText)
      }
      @Test fun ClearStat_AutoComplete_StatusEffectOptions() {
         var options = run.getAutoCompleteOptions("ClearStat = {}", 0, 13)
         Assert.equal(7, options.size)
         Assert.all(arrayOf( "Infatuation", "Sleep", "Poison", "Burn", "Ice", "Paralyze", "Confusion"),
            { option -> Assert.contains(option, options.map({ o -> o.text })) })
      }
      @Test fun IncreaseStat_AutoComplete_StatOptions() {
         var options = run.getAutoCompleteOptions("IncreaseStat = {  }", 0, 17)
         Assert.equal(8, options.size)
         Assert.all(arrayOf( "HpEv", "AttackEv", "DefenseEv", "SpecialAttackEv", "SpecialDefenseEv", "SpeedEv", "MaxPowerPoints", "PowerPointsToMax"),
            { option -> Assert.contains(option, options.map({ o -> o.text })) })
      }
      @Test fun ChangeHappiness_AutoComplete_RangeOptions() {
         var options = run.getAutoCompleteOptions("ChangeHappiness = { }", 0, 18)
         Assert.equal(3, options.size)
         Assert.all(arrayOf( "Low", "Mid", "High"),
            { option -> Assert.contains(option, options.map({ o -> o.text })) })
      }
      @Test fun AddBitRequiringArg_RunExtended() {
         ViewPort.goto!!.execute(4)

         ViewPort.edit("4 ")

         Assert.equal(7, Model.getNextRun(0).length)
      }
      @Test fun RemoveBitRequiringArg_Contract() {
         (run.createEditScope(Token)).use { _ ->run.healHealth  = true }
         var newRun: PIERun = PIERun(Model, 0, SortedSpan<Int>.none())
         Model.observeRunWritten(Token, newRun)

         ViewPort.goto!!.execute(4)
         ViewPort.edit("0 ")

         Assert.equal(6, Model.getNextRun(0).length)
      }
      @Test fun Copy_CopiesBytes() {
         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.selectionEnd  = newOf(5, 0)

         ViewPort.copy!!.execute(FileSystem)

         Assert.contains("00 00 00 00 00 00 ", FileSystem.copyText.value)
      }
      @Test fun ItemEffectContent_Paste_DataChanges() {
         SetFullModel(0xFF)

         ViewPort.edit("@010 ^misc._252705`pie` 00 00 00 20 00 00 ")

         var data = Model.rawData.drop(0x10).take(7).toTypedArray()
         Assert.equal(bytes( 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0xFF), data)
      }
      @Test fun TextTool_EditItemEffect_ChangeModel() {
         ViewPort.edit("00 00 00 00 04 00 14 @000 ^run`pie` ")
         var textTool = ViewPort.tools!!.stringTool

         var lines = textTool!!.content.splitLines()
         var lineIndex = lines.indexOfPartial("Arg =")
         lines[lineIndex]  = "Arg = 30"
         textTool!!.content  = "\n".join(lines.toList())

         Assert.equal(30, Model[6])
      }
      @Test fun TableTool_EditArgWithNamedValue_ChangeModel() {
         ViewPort.edit("00 00 00 00 04 00 14 @000 ^run`pie` @100 <run> @100 ^table[ptr<`pie`>]1 ")

         var stream = ViewPort.tools!!.tableTool!!.groups[1].members.singleOf<TextStreamElementViewModel>()
         var lines = stream.content.splitLines()
         var lineIndex = lines.indexOfPartial("Arg =")
         lines[lineIndex]  = "Arg = Half"
         stream.content  = "\n".join(lines.toList())

         Assert.equal(PIERun.healthRestore_Half, Model[6])
      }
   }
