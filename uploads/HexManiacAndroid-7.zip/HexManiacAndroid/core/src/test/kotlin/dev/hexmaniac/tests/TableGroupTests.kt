@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class TableGroupTests : BaseViewModelTestClass() {
      @Test fun TableGroup_LoadTable_TableToolContainsGroup() {
         ViewPort.edit("@10 ^table1[data:]4 @20 ^table2[data:]table1 @30 ^table3[data:]table1 @40 ^table4[data:]table1 ")
         Model.appendTableGroup(Token, "tables", listOf( "table1", "table2"), "")

         ViewPort.goto!!.execute(0x10)
         var groups = ViewPort.tools!!.tableTool!!.groups

         Assert.equal(2, groups.size)
         Assert.equal("tables", groups[0].groupName)
         Assert.equal("Other", groups[1].groupName)
      }
      @Test fun TableGroupInMetadata_Load_TableGroupInModel() {
         Model.load(ByteArray(0x200), StoredMetadata(
            anchors = listOf(
               StoredAnchor( 0, "table1", "[data:]4"),
               StoredAnchor(20, "table2", "[data:]table1"),
               StoredAnchor(40, "table3", "[data:]table1"),
               StoredAnchor(60, "table4", "[data:]table1"),),
            tableGroups = listOf(
               TableGroup("group1", listOf( "table1", "table2")),
               TableGroup("group2", listOf( "table3", "table4")),)))

         var groups = Model.getTableGroups("table1")

         Assert.equal(arrayOf( "group1", "group2"), groups!!.map({ group -> group.groupName }))
         Assert.equal(arrayOf( "table1", "table2"), groups!![0].tables)
         Assert.equal(arrayOf( "table3", "table4"), groups!![1].tables)
      }
      @Test fun Text_LoadMetadata_ContainsTableGroups() {
         var metadata = StoredMetadata(arrayOf(
            "[[TableGroup]]",
            "Name = '''group1'''",
            "0 = [",
            "   '''table1''',",
            "   '''table2''',",
            "]",))

         Assert.single(metadata.tableGroups)
         Assert.equal("group1", metadata.tableGroups[0].groupName)
         Assert.equal(arrayOf( "table1", "table2"), metadata.tableGroups[0].tables)
      }
      @Test fun Metadata_Export_ContainsTableGroups() {
         var initialMetadata = StoredMetadata(tableGroups = listOf( TableGroup("group1", listOf( "table1"))))
         Model.load(ByteArray(0x200), initialMetadata)

         var newMetadata = Model.exportMetadata(Singletons.metadataInfo)
         var text = newMetadata!!.serialize()

         Assert.contains("[[TableGroup]]", text)
      }
      @Test fun NoGroups_UpdateVersion_Groups() {
         SetGameCode(HardcodeTablesModel.fireRed)
         var metadata = StoredMetadata(
            anchors = listOf( StoredAnchor(0x100, "anchor", "")),
            generalInfo = New.earliestVersionInfo)

         var model = New.pokemonModel(Model.rawData, metadata)

         var groups = model.exportMetadata(Singletons.metadataInfo)!!.tableGroups
         Assert.notEmpty(groups)
      }
      @Test fun TableGroup_GenerateHash_HashMatches() {
         var group = TableGroup("group", listOf( "table1", "table2"))
         Assert.isTrue(group.hashMatches)
      }
      @Test fun TableGroup_IncludeWrongHash_HashDoesNotMatch() {
         var group = TableGroup("group", listOf( "table1", "table2"), "0")
         Assert.isFalse(group.hashMatches)
      }
      @Test fun Groups_UpdateVersion_NoDuplicates() {
         // calculate 'default' TableGroups
         SetGameCode(HardcodeTablesModel.fireRed)
         var model = New.hardcodeTablesModel(Model.rawData)
         var metadata = model.exportMetadata(Singletons.metadataInfo)
         var tableGroups = metadata!!.tableGroups

         // upgrade version
         metadata  = StoredMetadata(
            tableGroups = tableGroups,
            generalInfo = New.earliestVersionInfo)
         model  = New.pokemonModel(model.rawData, metadata)

         var newGroups = model.exportMetadata(Singletons.metadataInfo)!!.tableGroups
         Assert.equal(tableGroups.size, newGroups.size)
         for (i in 0 until newGroups.size) {
            Assert.equal(tableGroups[i].groupName, newGroups[i].groupName)
            Assert.equal(tableGroups[i].hash, newGroups[i].hash)
         }
      }
      @Test fun TableGroupWithEditedHash_UpdateVersion_DoNotAddGroupsWithSameTables() {
         SetGameCode(HardcodeTablesModel.fireRed)
         var metadata = StoredMetadata(
            tableGroups = listOf( TableGroup("custom", listOf( HardcodeTablesModel.pokemonNameTable), "0")),
            generalInfo = New.earliestVersionInfo)

         var model = New.pokemonModel(Model.rawData, metadata)
         var groups = model.exportMetadata(Singletons.metadataInfo)!!.tableGroups

         var group = groups.single({ group -> group.groupName == "custom" })
         Assert.single(group.tables)
         Assert.single(groups.filter({ group -> group.tables.contains(HardcodeTablesModel.pokemonNameTable) }))
      }
      @Test fun Text_LoadMetadata_CaptureHash() {
         var text = SplitLines("[[TableGroup]];Name = '''custom''';DefaultHash = '''0''';0 = [;   '''table''',;]")

         var metadata = StoredMetadata(text.splitLines())

         Assert.equal("0", metadata.tableGroups.single().hash)
      }
      @Test fun SplitTable_HasSplitSegment() {
         val table = Ref<ITableRun?>(null)
         var error = ArrayRun.tryParse(Model, "[data: | more:]4", 0, SortedSpan<Int>.none(), table)

         Assert.isFalse(error.hasError)
         Assert.isType<ArrayRunSplitterSegment>(table.value!!.elementContent[1])
      }
      @Test fun SplitTable_SplitGroup_LoadMultipleGroups() {
         Model.load(ByteArray(0x200), StoredMetadata(
            anchors = listOf(
               StoredAnchor(0, "table1", "[data: | more:]4"),),
            tableGroups = listOf(
               TableGroup("group1", listOf( "table1|0")),
               TableGroup("group2", listOf( "table1|1")),)))

         var groups = Model.getTableGroups("table1")

         Assert.equal(arrayOf( "group1", "group2"), groups!!.map({ group -> group.groupName }))
         Assert.equal(arrayOf( "table1|0"), groups!![0].tables)
         Assert.equal(arrayOf( "table1|1"), groups!![1].tables)
      }
      @Test fun SplitTable_LoadTableTool_LoadMultipleGroups() {
         Model.load(ByteArray(0x200), StoredMetadata(
            anchors = listOf(
               StoredAnchor(0, "table1", "[data: | more:]4"),),
            tableGroups = listOf(
               TableGroup("group1", listOf( "table1|0")),
               TableGroup("group2", listOf( "table1|1")),)))

         ViewPort.goto!!.execute(4)

         var groups = ViewPort.tools!!.tableTool!!.groups

         Assert.equal(2, groups.size)
         Assert.equal("data", groups[0].members.singleOf<FieldArrayElementViewModel>().name)
         Assert.equal("more", groups[1].members.singleOf<FieldArrayElementViewModel>().name)
      }
      @Test fun SingleTableGroup_TableToolRefresh_StreamGroupObjectRemainsTheSame() {
         SetFullModel(0xFF)
         Model.writeValue(Token, 0, 0)
         Model.writeValue(Token, 4, 0)
         ViewPort.edit("^table[ptr<\"\">]2 @{ Adam\" @} @{ Bob\" @} ")

         ViewPort.goto!!.execute(0)
         var oldGroup = ViewPort.tools!!.tableTool!!.groups[1]

         ViewPort.goto!!.execute(4)
         var newGroup = ViewPort.tools!!.tableTool!!.groups[1]

         Assert.equal(oldGroup, newGroup, TableGroupReferenceComparer())
         Assert.single(newGroup.members)
      }
      @Test fun StreamTable_RefreshTableTool_StreamGroupObjectRemainsTheSame() {
         SetFullModel(0xFF)
         Model.writeValue(Token, 0, 0)
         Model.writeValue(Token, 4, 0)
         ViewPort.edit("^table[ptr<\"\">]!FFFF @{ Adam\" @} @{ Bob\" @} ")

         ViewPort.goto!!.execute(0)
         var oldGroup = ViewPort.tools!!.tableTool!!.groups[1]

         ViewPort.goto!!.execute(4)
         var newGroup = ViewPort.tools!!.tableTool!!.groups[1]

         Assert.equal(oldGroup, newGroup, TableGroupReferenceComparer())
         Assert.single(newGroup.members)
      }
   }

   open class TableGroupReferenceComparer : IEqualityComparer<TableGroupViewModel> {
      override fun equals(x: TableGroupViewModel?, y: TableGroupViewModel?): Boolean = x === y

      override fun getHashCode(obj: TableGroupViewModel): Int = throw NotImplementedException()
   }
