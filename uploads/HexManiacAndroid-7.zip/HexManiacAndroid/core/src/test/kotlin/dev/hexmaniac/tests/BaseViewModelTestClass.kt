@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST", "PropertyName", "FunctionName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*

/** Lots of view model tests have similar setups (BaseViewModelTestClass.cs). Members keep their C# (PascalCase) names. */
open class BaseViewModelTestClass(modelLength: Int = 0x200) {
    val FileSystem: StubFileSystem = StubFileSystem()
    val New: New = New(FileSystem, Singletons)
    val Data: ByteArray = ByteArray(modelLength)
    val Model: PokemonModel = PokemonModel(Data, null, Singletons)
    val ViewPort: ViewPort = ViewPort("file.txt", Model, InstantDispatch.instance, Singletons)
    val Messages: ArrayList<String> = ArrayList()
    val Errors: ArrayList<String> = ArrayList()
    open val Token: ModelDelta = ModelDelta()

    init {
        ViewPort.allowMultipleElementsPerLine = true
        ViewPort.width = 0x10
        ViewPort.height = 0x10
        ViewPort.onError += { _, e -> if (!e.isNullOrEmpty()) Errors.add(e) }
        ViewPort.onMessage += { _, e -> Messages.add(e) }

        // turn off full-address-required for most tests
        ViewPort.tools!!.codeTool!!.scriptParser.requireCompleteAddresses = false
        ViewPort.tools!!.codeTool!!.battleScriptParser.requireCompleteAddresses = false
        ViewPort.tools!!.codeTool!!.battleAIScriptParser.requireCompleteAddresses = false
    }

    /** Text Tables are pretty simple. Each entry is X bytes long, which is just a single field of text. */
    fun CreateTextTable(tableName: String, address: Int, vararg entries: String) {
        val length = entries.maxOf { name -> name.length } + 1 // +1 for the end-string character
        ViewPort.goto!!.execute(address.toHex(2))
        ViewPort.edit("^$tableName[name\"\"$length]${entries.size} ")
        for (entry in entries) ViewPort.edit(entry + "\"")
    }

    fun CreateTextTableWithInnerPointers(tablename: String, address: Int, vararg entries: String) =
        CreateTextTable(tablename + "^", address, *entries)

    /** Enum tables are a bit more complex. Each entry is 2 bytes long, but the text that you see is an entry from another table. */
    fun CreateEnumTable(tableName: String, address: Int, sourceTable: String, vararg entries: Int) {
        for (i in entries.indices) {
            Data[address + i * 2 + 0] = (entries[i] shr 0).toByte()
            Data[address + i * 2 + 1] = (entries[i] shr 8).toByte()
        }
        ViewPort.goto!!.execute(address.toHex(2))
        ViewPort.edit("^$tableName[data:$sourceTable]${entries.size} ")
    }

    /** BitArray tables are fairly confusing. Each entry is X bits long, where X is the length of a matched enum table. X is rounded up to the nearest 8. */
    fun CreateBitArrayTable(tableName: String, address: Int, sourceTable: String, vararg encoding: Int) {
        val token = ModelDelta()
        val sourceAddress = Model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, sourceTable)
        val sourceRun = Model.getNextRun(sourceAddress) as ArrayRun
        val bytesToEncode = Math.ceil(sourceRun.elementCount / 8.0).toInt()
        for (i in encoding.indices) {
            Model.writeMultiByteValue(address + i * bytesToEncode, bytesToEncode, token, encoding[i])
        }
        ViewPort.goto!!.execute(address.toHex(2))
        ViewPort.edit("^$tableName[data${BitArray.sharedFormatString}$sourceTable]${encoding.size} ")
    }

    fun SetFullModel(value: Int) {
        for (i in 0 until Model.count) Model[i] = value
    }

    fun SetGameCode(code: String) {
        val bytes = code.substring(0, 4).toByteArray(Charsets.ISO_8859_1)
        System.arraycopy(bytes, 0, Model.rawData, dev.hexmaniac.core.models.IDataModelExtensions.gameCodeStart, 4)
        Model[dev.hexmaniac.core.models.IDataModelExtensions.gameVersionStart] = code[4] - '0'
    }

    fun AddPointer(source: Int, destination: Int) {
        Model.writePointer(Token, source, destination)
        Model.observeRunWritten(Token, PointerRun(source))
    }

    fun WriteEventScript(address: Int, script: String) {
        val text = Ref(script.replace(";", "\n"))
        val bytes = ViewPort.tools!!.codeTool!!.scriptParser.compile(Token, Model, address, text, Ref<List<ScriptParserCompileMovedDataTuple>?>(null), Ref(0))
        Token.changeData(Model, address, bytes!!.asByteList())
        Model.observeRunWritten(Token, XSERun(address))
        ViewPort.goto!!.execute(address)
    }

    protected fun SplitLines(lines: String): String = lines.split(";").joinToString("\n")

    companion object {
        val Singletons: Singletons = Singletons()
    }
}
