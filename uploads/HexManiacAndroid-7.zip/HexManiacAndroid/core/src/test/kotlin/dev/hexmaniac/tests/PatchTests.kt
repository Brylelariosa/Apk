@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class PatchTests : BaseViewModelTestClass() {
      @Test fun EmptyPatch_TryApply_NoMetadataChange() {
         var sourceData = ByteArray(0x200).fluent({ array -> array[1]  = 1 })
         var destinationData = ByteArray(0x200).fluent({ array -> array[2]  = 2 })
         var patch = Patcher.buildUpsPatch(sourceData, destinationData)
         var patchFile = LoadedFile("patch.ups", patch)
         FileSystem.showOptions  = { _, _, _, _ -> 1 }

         ViewPort.tryImport(patchFile, FileSystem)

         Assert.isTrue(ViewPort.changeHistory.isSaved)
         Assert.isFalse(ViewPort.changeHistory.hasDataChange)
      }
      fun WriteVariableWidthInteger_ReadVariableWidthInteger_SameValue(targetValue: Int) {
         var content = Patcher.writeVariableWidthInteger(targetValue).toTypedArray()

         val index = Ref<Int>(0)
         var result = Patcher.readVariableWidthInteger(content.toByteArr(), index)

         Assert.equal(content.size, index.value)
         Assert.equal(result, targetValue)
      }
    @Test fun WriteVariableWidthInteger_ReadVariableWidthInteger_SameValue_1() { WriteVariableWidthInteger_ReadVariableWidthInteger_SameValue(0x1000000) }
   }
