@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class PointerModelTests : BaseViewModelTestClass() {
      @Test fun PointerModelFindsNoPointersInRandomData() {
         var rnd = java.util.Random(0xCafeL)
         var buffer = ByteArray(0x10000); // 64KB
         rnd.nextBytes(buffer)
         for (i in 0 until buffer.size) if (buffer[i].toInt() == 0x08) buffer[i]  = 0x10

         var model = PokemonModel(buffer)

         Assert.equal(NoInfoRun.nullRun, model.getNextRun(0))
      }
      @Test fun PointerModelFindsPointersInRange() {
         var rnd = java.util.Random(0xCafeL)
         var buffer = ByteArray(0x10000); // 64KB
         rnd.nextBytes(buffer)
         for (i in 0 until buffer.size) if (buffer[i].toInt() == 0x08) buffer[i]  = 0x10

         // write two specific pointers
         var model = PokemonModel(buffer)
         var token = ModelDelta()
         model.writePointer(token, 0x204, 0x4050)
         model.writePointer(token, 0x4070, 0x101C)
         model  = PokemonModel(buffer)

         Assert.equal(0x204, model.getNextRun(0).start)
         Assert.isType<PointerRun>(model.getNextRun(0x206))

         Assert.isType<NoInfoRun>(model.getNextRun(0x208))
         Assert.single(model.getNextRun(0x400).pointerSources)

         Assert.equal(0x4050, model.getNextRun(0x4050).start)
         Assert.equal(4, model.getNextRun(0x4071).length)
      }
      @Test fun PointerModelFindsSelfReferences() {
         var buffer = ByteArray(0x20)
         var model = PokemonModel(buffer)
         var token = ModelDelta()
         model.writePointer(token, 0xC, 0xC)
         model  = PokemonModel(buffer)

         var run = model.getNextRun(0)
         var nextRun = model.getNextRun(run.start + run.length)

         Assert.notNull(run)
         Assert.equal(NoInfoRun.nullRun, nextRun)
      }
      @Test fun PointerModelMergesDuplicates() {
         var buffer = ByteArray(0x20)
         var model = PokemonModel(buffer)
         var token = ModelDelta()
         model.writePointer(token, 0x0C, 0x14)
         model.writePointer(token, 0x1C, 0x14)
         model  = PokemonModel(buffer)

         var run = model.getNextRun(0x14)
         Assert.equal(2, run.pointerSources!!.size)
      }
      @Test fun ModelUpdatesWhenViewPortChanges() {
         ViewPort.edit("<000020>")

         Assert.equal(0, Model.getNextRun(0).start)
         Assert.equal(0x20, Model.getNextRun(10).start)
      }
      @Test fun WritingNamedAnchorFollowedByPointerToNameWorks() {
         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.edit("^bob ")
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("<bob>")

         Assert.equal(ViewPort.width, ViewPort[0, 2].value)
      }
      @Test fun WritingPointerToNameFollowedByNamedAnchorWorks() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("<bob>")
         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.edit("^bob ")

         Assert.equal(ViewPort.width, ViewPort[0, 2].value)
      }
      @Test fun CanWriteAnchorToSameLocationAsPointerWithoutRemovingPointer() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("<000040>")
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("^bob ")

         Assert.isType<Anchor>(ViewPort[0, 2].format)
      }
      @Test fun CanWriteAnchorToSameLocationAsPointerPointingToThatAnchor() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("<bob>")
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("^bob ")

         Assert.isType<Anchor>(ViewPort[0, 2].format)
         Assert.equal(0x20, ViewPort[0, 2].value)
      }
      @Test fun WritingAnAnchorUpdatesPointersToUseThatName() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("<000010>")
         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.edit("^bob ")

         Assert.equal("bob", (((ViewPort[0, 2].format) as Pointer)).destinationName)
      }
      @Test fun WritingAPointerOverlappingAPointerRemovesOriginalPointer() {
         var buffer = ByteArray(0x100)
         var model = PokemonModel(buffer)
         var token = ModelDelta()

         model.writePointer(token, 16, 100)
         model.observeRunWritten(token, PointerRun(16))
         Assert.equal(16, model.getNextRun(10).start)
         Assert.equal(16, model.getNextRun(17).start)
         Assert.equal(16, model.getNextRun(19).start)
         Assert.equal(100, model.getNextRun(20).start); // the reference at 100 has been added

         model.clearFormat(token, 14, 4)
         model.writePointer(token, 14, 200)
         model.observeRunWritten(token, PointerRun(14))
         Assert.equal(14, model.getNextRun(10).start)
         Assert.equal(14, model.getNextRun(15).start)
         Assert.equal(14, model.getNextRun(16).start)
         Assert.equal(14, model.getNextRun(17).start)
         Assert.equal(200, model.getNextRun(18).start) // the reference at 100 has been erased, and there's a new one at 200
      }
      @Test fun WritingAnchorIntoAPointerRemovesThatPointer() {
         var buffer = ByteArray(0x100)
         var model = PokemonModel(buffer)
         var token = ModelDelta()

         model.writePointer(token, 16, 12)
         model.observeRunWritten(token, PointerRun(16))
         model.observeAnchorWritten(token, "bob", NoInfoRun(18))

         Assert.equal(18, model.getNextRun(10).start)
      }
      @Test fun WritingOverAnAnchorDeletesThatAnchor() {
         var buffer = ByteArray(0x100)
         var model = PokemonModel(buffer)
         var token = ModelDelta()

         model.writePointer(token, 16, 32)
         model.observeRunWritten(token, PointerRun(16))

         model.clearFormat(token, 30, 4);   // this format clear removes the anchor that was auto-generated from the pointer. Which means the data from before must not be a pointer.
         model.writePointer(token, 30, 64)
         model.observeRunWritten(token, PointerRun(30))

         Assert.equal(30, model.getNextRun(10).start); // original pointer at 16 is no longer there. The new first data is the anchor at 30
         Assert.equal(32, model.readPointer(16));      // but the data at 16 still looks like a pointer: only the format is gone
         Assert.equal(64, model.getNextRun(34).start) // next data is the anchor from the pointer at 30
      }
      @Test fun PointerCanPointToNameAfterThatNameGetsDeleted() {
         var viewPort = ViewPort
         var token = ModelDelta()

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^bob ")
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("<bob>")
         viewPort.selectionStart  = Point(0, 1)

         // as an alternative to being able to delete an anchor from the viewPort,
         // just edit the model directly and then scroll to force the viewPort to refresh
         Model.clearFormat(token, 0x10, 1)
         viewPort.scrollValue  = 1
         viewPort.scrollValue  = 0

         Assert.equal("bob", (((viewPort[0, 2].format) as Pointer)).destinationName)
      }
      @Test fun PointerGetsSetToZeroAfterAnchorGetsDeleted() {
         var viewPort = ViewPort
         var token = ModelDelta()

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^bob ")
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("<bob>")
         viewPort.selectionStart  = Point(0, 1)

         // as an alternative to being able to delete an anchor from the viewPort,
         // just edit the model directly and then scroll to force the viewPort to refresh
         Model.clearFormatAndData(token, 0xF, 2)
         viewPort.scrollValue  = 1
         viewPort.scrollValue  = 0

         Assert.equal(Pointer.null_, (((viewPort[0, 2].format) as Pointer)).destination)
      }
      @Test fun AnchorCarriesSourceInformation() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("<000020>")
         var anchor = ((viewPort[0, 2].format) as Anchor)
         Assert.contains(16, anchor.sources)
      }
      @Test fun StartingAnAnchorAndGivingItNoNameClearsAnyAnchorNameAtThatPosition() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("<bob>")
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^bob ")
         viewPort.edit("^ ")

         var format = ((viewPort[0, 1].format) as Pointer)
         Assert.equal(0x20, format.destination)
         Assert.equal("", format.destinationName)
         var address = Model.getAddressFromAnchor(ModelDelta(), -1, "")
         Assert.equal(Pointer.null_, address)
      }
      @Test fun CanRemoveAnchorWithNoReferences() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^bob ^ ")

         Assert.equal(NoInfoRun.nullRun, Model.getNextRun(0))
      }
      @Test fun BackspaceClearsDataButNotFormats() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("01 02 03 04");                // 2x4 characters to clear
         viewPort.edit("<000020>");                   // 8 characters to clear
         viewPort.edit("<000030>");                   // 8 characters to clear
         viewPort.selectionStart  = Point(10, 1);  // within <000030>

         for (i in 0 until 21) viewPort.edit(ConsoleKey.Backspace); // should clear both pointers (16) and 2 bytes (4)
         viewPort.moveSelectionStart.execute(Direction.Up)

         Assert.equal(Pointer.null_, (((viewPort[8, 1].format) as Pointer)).destination)
         Assert.equal(Pointer.null_, (((viewPort[4, 1].format) as Pointer)).destination)
         Assert.equal(0x01, viewPort[0, 1].value)
         Assert.equal(0x00, viewPort[1, 1].value); // committed a '0' when the selection moved, because a '0' was all that was left
         Assert.equal(0xFF, viewPort[2, 1].value)
         Assert.equal(0xFF, viewPort[3, 1].value)
      }
      @Test fun WritingOverTwoPointersWorks() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("<000020>")
         viewPort.edit("<000030>")
         viewPort.selectionStart  = Point(2, 1); // note that this will select all four bytes of <000020>
         viewPort.clear!!.execute();  // this should clear the data and formatting of the first pointer
         viewPort.selectionStart  = Point(2, 1); // this selects just the one byte
         viewPort.edit("<000040>"); // this should remove the second pointer

         Assert.equal(0xFF, viewPort[0, 1].value)
         Assert.equal(0xFF, viewPort[1, 1].value)
         Assert.equal(0x40, viewPort[2, 1].value)
         Assert.equal(0x00, viewPort[3, 1].value)
         Assert.equal(0x00, viewPort[4, 1].value)
         Assert.equal(0x08, viewPort[5, 1].value)
         Assert.equal(0x00, viewPort[6, 1].value); // leftover data from the pointer <000030> when we 'fixed' its format
         Assert.equal(0x08, viewPort[7, 1].value)

         Assert.isNotType<Pointer>(viewPort[1, 1].format)
         Assert.isType<Pointer>(viewPort[2, 1].format)
         Assert.isType<Pointer>(viewPort[5, 1].format)
         Assert.isNotType<Pointer>(viewPort[6, 1].format)

         // verify that there is no anchor at 20 and 30, but there is an anchor at 40
         Assert.equal(0x40, Model.getNextAnchor(0x20).start)
      }
      @Test fun PointerToUnknownLocationShowsUpDifferent() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(2, 1)
         viewPort.edit("<bob>")

         var pointer = ((viewPort[2, 1].format) as Pointer)
         Assert.equal("bob", pointer.destinationName)
         Assert.equal(Pointer.null_, pointer.destination)
      }
      @Test fun AddingANewNamedPointerToNoLocationOverExistingNamedPointerToNoLocationWorks() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(2, 1)
         viewPort.edit("<bob>")

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("<tom>")

         Assert.isNotType<Pointer>(viewPort[4, 1].format)
      }
      @Test fun CanGotoAnchorName() {
         var viewPort = ViewPort

         var errorCalls: Int = 0
         viewPort.onError  += { sender, e -> errorCalls++ }

         viewPort.selectionStart  = Point(2, 1)
         viewPort.edit("^bob ")
         viewPort.goto!!.execute("bob")

         Assert.equal(0, errorCalls)
      }
      @Test fun CanFindPointer() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(4, 1)
         viewPort.edit("<000058> 23 19")
         var results = viewPort.find("<000058> 23 19")

         Assert.single(results)
      }
      @Test fun CanUsePointerAsLink() {
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(4, 1)
         viewPort.edit("<000120>")
         viewPort.followLink(4, 1)

         Assert.equal("000120", viewPort.headers!![0])
      }
      @Test fun FindAllSourcesWorks() {
         var viewPort = ViewPort
         var editor = New.editorViewModel()
         editor.add(viewPort)

         viewPort.selectionStart  = Point(4, 1)
         viewPort.edit("<000120>")
         viewPort.followLink(4, 1)

         viewPort.findAllSources(0, 0)

         Assert.equal(1, editor.selectedIndex)
      }
      @Test fun NewAnchorWithSameNameDoesNotMovePointersToNewAnchor() {
         var viewPort = ViewPort

         // put some pointers in the file
         viewPort.selectionStart  = Point(4, 1)
         viewPort.edit("<bob>")
         viewPort.selectionStart  = Point(4, 3)
         viewPort.edit("<bob>")

         // make them point somewhere real
         viewPort.selectionStart  = Point(8, 2)
         viewPort.edit("^bob ")

         // make a new anchor with the same name (should auto-rename)
         viewPort.selectionStart  = Point(8, 4)
         viewPort.edit("^bob ")

         Assert.equal(0x28, (((viewPort[4, 1].format) as Pointer)).destination)
         Assert.equal(0x28, (((viewPort[4, 3].format) as Pointer)).destination)
      }
      @Test fun CanCopyAndPastePointers() {
         var fileSystem = StubFileSystem()
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(0, 2)

         viewPort.edit("<000058>")
         viewPort.edit("FF FF")
         viewPort.selectionStart  = Point(0, 2)
         viewPort.selectionEnd  = Point(5, 2)

         viewPort.copy!!.execute(fileSystem)
         Assert.equal("<000058> FF FF", fileSystem.copyText)
      }
      @Test fun CanWriteNullPointer() {
         var buffer = ByteArray(0x200)
         var model = PokemonModel(buffer)
         var token = ModelDelta()

         model.observeRunWritten(token, PointerRun(0x10))

         var format = ((model.getNextRun(0x10).createDataFormat(model, 0x10)) as Pointer)
         Assert.equal("null", format.destinationName)
      }
      @Test fun CanWriteNameOverNullPointer() {
         var viewPort = ViewPort

         viewPort.edit("<null>")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("<bob>")

         var format = ((Model.getNextRun(0x0).createDataFormat(Model, 0x00)) as Pointer)
         Assert.equal("bob", format.destinationName)
      }
      @Test fun FormatClearDoesNotClearAnchorIfUnnamedAnchorIsAtStartOfClear() {
         var buffer = ByteArray(0x200)
         var model = PokemonModel(buffer)
         var token = ModelDelta()

         model.writePointer(token, 0, 0x10)
         model.observeRunWritten(token, PointerRun(0))
         model.clearFormat(token, 0x10, 1)

         Assert.equal(0x10, model.getNextRun(0x10).start)
      }
      @Test fun ArrowMovementWhileTypingAnchorCommitsChange() {
         var viewPort = ViewPort

         viewPort.edit("^bob"); // no trailing space: still under edit

         viewPort.selectionStart  = Point(1, 1)

         Assert.isNotType<None>(viewPort[0, 0].format)
      }
      @Test fun EscapeWhileTypingAnchorCancelsChange() {
         var viewPort = ViewPort

         viewPort.edit("^bob"); // no trailing space: still under edit
         viewPort.edit(ConsoleKey.Escape)

         Assert.isType<None>(viewPort[0, 0].format)
         Assert.equal(NoInfoRun.nullRun, Model.getNextRun(0))
      }
      @Test fun StartingAnAnchorOverAnAnchorClearsTheExistingAnchorInfo() {
         var viewPort = ViewPort

         viewPort.edit("^bob ")
         Assert.equal("^bob", viewPort.anchorText)

         viewPort.edit("^")

         var format = ((viewPort[0, 0].format) as UnderEdit)
         Assert.equal("^", format.currentText)
         Assert.equal("^", viewPort.anchorText)
      }
      @Test fun AnchorEditTextUpdatesWithSelectionChange() {
         var viewPort = ViewPort
         Model.observeAnchorWritten(ModelDelta(), "bob", NoInfoRun(0x08))

         viewPort.selectionStart  = Point(0x08, 0)

         Assert.isTrue(viewPort.anchorTextVisible)
         Assert.equal("^bob", viewPort.anchorText)
      }
      @Test fun AnchorEditTextUpdatesWhenTypingAnAnchor() {
         var viewPort = ViewPort

         viewPort.edit("^partialTe"); // in the middle of typing 'partialText'

         Assert.isTrue(viewPort.anchorTextVisible)
         Assert.equal("^partialTe", viewPort.anchorText)
      }
      @Test fun ModifyingAnchorTextUpdatesTheAnchor() {
         SetFullModel(0xFF)
         var viewPort = ViewPort
         Model.observeAnchorWritten(ModelDelta(), "bob", NoInfoRun(0x08))

         viewPort.selectionStart  = Point(0x08, 0)
         viewPort.anchorText  = "^bob\"\""

         Assert.isType<PCSRun>(Model.getNextRun(0x08))
      }
      @Test fun AnchorTextAlwaysCoercesToStartWithAnchorCharacter() {
         var viewPort = ViewPort
         Model.observeAnchorWritten(ModelDelta(), "bob", NoInfoRun(0x08))

         viewPort.selectionStart  = Point(0x08, 0)
         viewPort.anchorText  = "tom\"\""

         Assert.equal("^tom\"\"", viewPort.anchorText) // not that the ^ was added to the front
      }
      @Test fun GivenTwoPointersCanRemoveAndUndoTheFirstWithoutEffectingTheSecond() {
         val (model, viewPort) = Pair(Model, ViewPort)
         model.writePointer(ModelDelta(), 0x010, 0x100)
         model.observeRunWritten(ModelDelta(), PointerRun(0x010))
         model.writePointer(ModelDelta(), 0x014, 0x120)
         model.observeRunWritten(ModelDelta(), PointerRun(0x014))

         viewPort.selectionStart  = Point(0, 2); // 0x010
         viewPort.edit("00"); // this should remove the first pointer
         viewPort.undo.execute()

         Assert.equal(0x014, model.getNextRun(0x014).start)
      }
      @Test fun CreatingAnOffsetPointerShouldCoerceToTheStartOfExistingPointer() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("<000100>")
         viewPort.selectionStart  = Point(2, 0)
         viewPort.edit("<000050>")

         // note that the second pointer should be right where the first one was
         // because trying to start a pointer edit mid-pointer should move you to the start of the pointer.
         Assert.equal(0x50, Model[0])
      }
      @Test fun CreatingAPointerOutsideTheDataRangeErrors() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("<000400>")

         Assert.single(Errors)
      }
      @Test fun ClearingAPointerAlsoRemovesItsAnchor() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("<000100>")
         model.clearFormat(ModelDelta(), 0x00, 4)

         Assert.notInRange(model.getNextRun(0x00).start, 0, Model.count)
      }
      @Test fun TypingBracesOnDataTriesToInterpretThatDataAsPointer() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("00 01 00 08")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("<>");   // typing this should interpret the bytes as a pointer and add it.

         Assert.equal(0x100, (((viewPort[0, 0].format) as Pointer)).destination)
      }
      @Test fun StartingPointerEditAndThenMovingClearsAllEditedCells() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("<")
         viewPort.selectionStart  = Point(2, 2)

         for (x in 0 until 0x10) {
            for (y in 0 until 0x10) {
               Assert.isNotType<UnderEdit>(viewPort[x, y].format)
            }
         }
      }
      @Test fun AddingAnchorShouldSearchForPointersToThatLocation() {
         val (model, viewPort) = Pair(Model, ViewPort)
         var change = ModelDelta()
         model.writePointer(change, 0x23, 0x050); // a pointer that isn't 4-byte aligned, pointing to data that is
         model.writePointer(change, 0x10, 0x087); // a pointer that is 4-byte aligned, but pointing to something that isn't
         model.writePointer(change, 2, 0xA2);    // a pointer that isn't 4-byte aligned, pointing to something not 4-byte aligned

         // got to 50 and write an anchor
         viewPort.selectionStart  = Point(0x0, 0x5)
         viewPort.edit("^test1 ")
         Assert.isType<Pointer>(viewPort[0x3, 0x2].format)
         Assert.single((((viewPort[0x0, 0x5].format) as Anchor)).sources)

         // go to 87 and write an anchor
         viewPort.selectionStart  = Point(0x7, 0x8)
         viewPort.edit("^test2 ")
         Assert.isType<Pointer>(viewPort[0x0, 0x1].format)
         Assert.single((((viewPort[0x7, 0x8].format) as Anchor)).sources)

         // go to A2 and write an anchor
         viewPort.selectionStart  = Point(0x2, 0xA)
         viewPort.edit("^test3 ")
         Assert.isType<Pointer>(viewPort[0x2, 0x0].format)
         Assert.single((((viewPort[0x2, 0xA].format) as Anchor)).sources)
      }
      @Test fun ReplacingAPointerWithAnAnchorKeepsKnowledgeOfThatPointer() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         viewPort.value.edit("<000040><000040><000040>")
         viewPort.value.goto!!.execute("000004")
         viewPort.value.edit("^bob "); // adding the anchor will remove the pointer

         Assert.equal(3, model.value.getNextRun(0x40).pointerSources!!.size) // since the pointer was removed, the anchor should only have 2 things pointing to it.
      }
      @Test fun ClearingAnAnchorFormatShouldRemovePointersToTheAnchorButNotPointersToThosePointers() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)

         viewPort.value.edit("<000010> <000000>")
         viewPort.value.selectionStart  = Point(0xE, 0)
         viewPort.value.edit("<000020>"); // this overwrites (and removes) the anchor at 000010

         var run = model.value.getNextRun(0)
         Assert.equal(0, run.start);    // there should still be an anchor at 000000, even though it's not a pointer anymore
         Assert.isType<NoInfoRun>(run)

         run  = model.value.getNextRun(4)
         Assert.equal(4, run.start);    // there should still be a pointer a 000004 that points to 000000
         Assert.isType<PointerRun>(run)
      }
      @Test fun AnchorWithNoFormatContextMenuContainsRemoveOption() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("<000020> @20 "); // add a pointer to 0x20 and go there

         test.ViewPort.selectionStart  = Point()
         var contextItems = test.ViewPort.getContextMenuItems(Point())
         var clearFormatItem = contextItems.single({ item -> item.text == "Clear Format" })
         clearFormatItem.command.execute()

         // verify that there is no longer a run starting at 0x20
         Assert.notEqual(0x20, test.Model.getNextRun(0x20).start)
      }
      @Test fun AnchorCanContaintDots() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("^This.name.Is.valid ")
         Assert.empty(test.Errors)
         var address = test.Model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, "This.name.Is.valid")
         Assert.equal(0, address)

         test.ViewPort.anchorText  = "^This_name_is_Also_valid"
         Assert.empty(test.Errors)
         address  = test.Model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, "This_name_is_Also_valid")
         Assert.equal(0, address)
      }
      @Test fun OffsetPointersWork() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         StandardSetup(data, model, Ref(nullOf()))

         data.value[0]  = 0x60
         data.value[3]  = 8
         model.value.observeRunWritten(ModelDelta(), OffsetPointerRun(0, 0x30))

         Assert.equal(0x08000060, model.value.readMultiByteValue(0, 4))
         Assert.equal(0x30, model.value.readPointer(0))
         Assert.isType<NoInfoRun>(model.value.getNextRun(0x30))
         Assert.equal(0x30, model.value.getNextRun(0x30).start)
      }
      @Test fun CanUndoOffsetPointerChange() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         var metaInfo = StubMetadataInfo().also { it.versionNumber = "" }

         data.value[0]  = 0x60
         data.value[3]  = 8
         model.value.observeRunWritten(viewPort.value.currentChange, OffsetPointerRun(0, 0x30))

         Assert.single(model.value.exportMetadata(metaInfo)!!.offsetPointers)

         viewPort.value.undo.execute()

         var metadata = model.value.exportMetadata(metaInfo)
         Assert.empty(metadata!!.offsetPointers)
      }
      @Test fun CanCreateOffsetPointerFromViewModel() {
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(Ref(nullOf()), model, viewPort)
         viewPort.value.edit("<000100+20>")
         Assert.equal(0x08000120, model.value.readMultiByteValue(0, 4))
         Assert.equal(0x100, model.value.readPointer(0))
      }
      @Test fun CanOffsetPointToAnchor() {
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(Ref(nullOf()), model, viewPort)

         model.value.writePointer(viewPort.value.currentChange, 0, 0x10)
         model.value.observeAnchorWritten(viewPort.value.currentChange, "bob", NoInfoRun(0x20))
         model.value.observeRunWritten(viewPort.value.currentChange, OffsetPointerRun(0, -0x10)); // with a value of 0x10 and an offset of 0x10, this should now point to bob

         // move the anchor
         model.value.clearFormat(viewPort.value.currentChange, 0x20, 1); // clear the anchor
         viewPort.value.edit("@40 ^bob ")

         // pointer should point to the new location (with offset)
         Assert.equal(0x08000030, model.value.readValue(0))
         Assert.equal(0x40, model.value.readPointer(0))
      }
      @Test fun Anchor_CreateOffsetPointer_NoError() {
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(Ref(nullOf()), model, viewPort)

         viewPort.value.edit("@40 ^anchor @0 <anchor+2>")

         Assert.equal(0x08000042, model.value.readValue(0))
         Assert.equal(0x40, model.value.readPointer(0))
      }
      @Test fun RunSelected_EditAnchor_AnchorChanges() {
         ViewPort.edit("^text`asc`8 @04 ")

         ViewPort.anchorText  = "^text`asc`12 "

         Assert.empty(Errors)
         Assert.equal(0, Model.getNextRun(0).start)
         Assert.equal(12, Model.getNextRun(0).length)
      }
      @Test fun PointerTable_Delete_PointerIsNull() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 ^text1\"\" Adam\"")
         ViewPort.edit("@120 ^text2\"\" Bob\"")
         ViewPort.edit("@140 ^text3\"\" Carl\"")
         ViewPort.edit("@160 ^text4\"\" Dave\"")
         ViewPort.edit("@00 <text1> <text2> <text3> <text4> @00 ^table[text<\"\">]4 ")

         ViewPort.selectionStart  = Point(4, 0)
         ViewPort.clear!!.execute()

         Assert.equal(Model.getAddressFromAnchor(ViewPort.currentChange, -1, "text1"), Model.readPointer(0))
         Assert.equal(Pointer.null_, Model.readPointer(4))
      }
      @Test fun PointerTable_DeleteMultiplePointers_OnlyThoseAreNull() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 ^text1\"\" Adam\"")
         ViewPort.edit("@120 ^text2\"\" Bob\"")
         ViewPort.edit("@140 ^text3\"\" Carl\"")
         ViewPort.edit("@160 ^text4\"\" Dave\"")
         ViewPort.edit("@00 <text1> <text2> <text3> <text4> @00 ^table[text<\"\">]4 ")

         ViewPort.selectionStart  = Point(4, 0)
         ViewPort.selectionEnd  = Point(11, 0)
         ViewPort.clear!!.execute()

         Assert.equal(Model.getAddressFromAnchor(ViewPort.currentChange, -1, "text1"), Model.readPointer(0))
         Assert.equal(Pointer.null_, Model.readPointer(4))
         Assert.equal(Pointer.null_, Model.readPointer(8))
         Assert.equal(Model.getAddressFromAnchor(ViewPort.currentChange, -1, "text4"), Model.readPointer(12))
      }
      @Test fun SelfReferentialPointer_Delete_NoError() {
         ViewPort.edit("@010 <010> @010 ")

         ViewPort.clear!!.execute()

         Assert.equal(-1, Model.readMultiByteValue(0x10, 4))
         Assert.isType<None>(ViewPort[0, 0].format)
      }
      @Test fun PointerToTextWithinTable_DeepCopy_OnlyCopyOneElement() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 ^names^[content\"\"7]4 adam\" bob\" carl\" dave\"")
         ViewPort.edit("@000 @!00(16) ^table[pointer<>]4 <names/0> <names/1> <names/2> <names/3>")

         ViewPort.goto!!.execute(8)
         ViewPort.deepCopy.execute(FileSystem)

         Assert.contains("carl", FileSystem.copyText.value)
         Assert.doesNotContain("bob", FileSystem.copyText.value)
         Assert.doesNotContain("dave", FileSystem.copyText.value)
      }
      @Test fun Bytes_WriteSameBytesAsPointer_ModelDoesNotThinkBytesWereChanged() {
         Model.rawData[3]  = 0x08

         ViewPort.edit("<000>")

         Assert.all(4.range(), { i -> Assert.isFalse(Model.hasChanged(i)) })
      }
      @Test fun UnmappedPointerInMetadata_Load_NullPointer() {
         var pointers = arrayOf( StoredUnmappedPointer(0x20, "name"))
         var metadata = StoredMetadata(unmappedPointers = pointers.toList())

         var model = PokemonModel(ByteArray(0x200), metadata, Singletons)

         var run = model.getNextRun(0x20)
         Assert.isType<PointerRun>(run)
         Assert.equal(0x20, run.start)
      }
      @Test fun UnmappedPointerInMetadata_WriteAnchor_ModelUpdates() {
         var pointers = arrayOf( StoredUnmappedPointer(0x20, "name"))
         var metadata = StoredMetadata(unmappedPointers = pointers.toList())

         var model = PokemonModel(ByteArray(0x200), metadata, Singletons)
         model.observeAnchorWritten(Token, "name", NoInfoRun(0x80))

         Assert.equal(0x80, model.readPointer(0x20))
      }
      @Test fun PointerWithAnchor_CheckAnchorText_IsFromThisPointerNotDestination() {
         ViewPort.edit("<100> ^destination @100 <004> ")

         ViewPort.goto!!.execute(0x100)

         Assert.equal("^", ViewPort.anchorText)
      }
      @Test fun PointerWithAnchor_WriteAnchorIntoViewPort_EditsPointer() {
         ViewPort.edit("<100> @100 <180> @100 ")

         ViewPort.anchorText  = "^some.name"

         Assert.equal("some.name", Model.getAnchorFromAddress(-1, 0x100))
      }
      @Test fun OffsetPointerOutOfRange_InitMetadata_NoOffsetPointer() {
         var metadata = StoredMetadata(offsetPointers = listOf( StoredOffsetPointer(0x300, 1)))

         var model = New.pokemonModel(Data, metadata)

         Assert.equal(Int.MAX_VALUE, model.getNextRun(0)!!.start)
      }
      @Test fun OffsetPointerOutOfRange_LoadMetadata_NoOffsetPointer() {
         var metadata = StoredMetadata(offsetPointers = listOf( StoredOffsetPointer(0x300, 1)))

         Model.loadMetadata(metadata)

         Assert.equal(Int.MAX_VALUE, Model.getNextRun(0).start)
      }
      @Test fun RawBytes_WriteSameBytesAsOffsetPointer_MetadataOnlyChange() {
         Model.writePointer(Token, 0, 0x104)
         Model.observeAnchorWritten(Token, "anchor", NoInfoRun(0x100))
         ViewPort.refresh()

         ViewPort.edit("<anchor+4>")

         Assert.isTrue(ViewPort.isMetadataOnlyChange)
      }
      @Test fun DefaultAnchorNameInPuse_CreateDefaultAnchor_UsesDifferentName() {
         SetFullModel(0xFF)
         ViewPort.edit("@20 ^misc.temp._000100 @00!00(8) ^table[ptr<>]2 <100> ")

         ViewPort.goto!!.execute("100")
         ViewPort.selectionEnd  = newOf(3, 0)
         ViewPort.cut(FileSystem)

         Assert.equal(0x20, Model.getAddressFromAnchor(newOf(), -1, "misc.temp._000100")); // old anchor is still there
         Assert.equal("^misc.temp._000100_1 FF FF FF FF", FileSystem.copyText.value);    // copy includes new anchor
         Assert.equal(arrayOf( 0x00), Model.getUnmappedSourcesToAnchor("misc.temp._000100_1")) // address 0 should point to the new anchor
      }
      @Test fun TempAnchor_ExportMetadata_DoNotIncludeTempAnchor() {
         ViewPort.edit("^misc.temp.stuff ")

         var metadata = Model.exportMetadata(Singletons.metadataInfo)

         var anchors = metadata!!.namedAnchors.map({ anchor -> anchor.name }).toMutableList()
         Assert.doesNotContain("misc.temp.stuff", anchors)
      }
      @Test fun PointerToTempAnchor_ExportMetadata_DoIncludeUnmappedPointer() {
         ViewPort.edit("<misc.temp.stuff>")

         var metadata = Model.exportMetadata(Singletons.metadataInfo)

         var unmappedPointers = metadata!!.unmappedPointers.map({ up -> up.name }).toMutableList()
         Assert.contains("misc.temp.stuff", unmappedPointers)
      }
      @Test fun RunWithContent_ClearFromMiddle_AnchorWithPointersRemains() {
         SetFullModel(0xFF)
         Model.writePointer(Token, 0, 0x10)
         Model.writePointer(Token, 4, 0x10)
         ViewPort.edit("@10 ^text\"\" Hello World!\"")

         Model.clearFormat(Token, 0x18, 1)

         var run = Model.getNextRun(0x10)
         Assert.equal(0x10, run.start)
         Assert.equal(2, run.pointerSources!!.size)
         Assert.isType<NoInfoRun>(run)
         var p1 = Model.getNextRun(0)
         Assert.equal(0, p1.start)
         Assert.isType<PointerRun>(p1)
         var p2 = Model.getNextRun(4)
         Assert.equal(4, p2.start)
         Assert.isType<PointerRun>(p2)
      }
      @Test fun PointerToLocation_AddAnchorToPointer_NoError() {
         ViewPort.edit("<100> ")

         ViewPort.edit("@000 ^ ")

         Assert.isNull(Model.getNextRun(0).pointerSources)
         Assert.empty(Errors)
      }
      @Test fun NoChanges_StartChangeThenCancel_NoSaveOption() {
         ViewPort.edit("<")

         Assert.isFalse(ViewPort.save!!.canExecute(FileSystem))
      }
      @Test fun DataInTableLooksLikePointerToAddress_AddAnchorAtAddress_PointerSourceFromTableNotAdded() {
         Model.expandData(Token, 0x1000)
         ViewPort.refresh()
         SetFullModel(0xFF)
         ViewPort.edit("^table[a: unused: pointer<>]1 0 256 <000800> ")

         ViewPort.goto!!.execute(0x100)
         ViewPort.edit("^anchor ")

         var run = Model.getNextRun(0x100)
         Assert.empty(run.pointerSources)
      }
      @Test fun Anchor_WriteOffsetPointerToAnchorFromTable_OffsetWritten() {
         ViewPort.edit("@100 ^anchor @000 ^table[pointer<>]1 ")

         ViewPort.edit("<anchor+1>")

         Assert.equal(0x101, Model.readPointer(0))
      }
      @Test fun OffsetPointer_UpdateToDifferentComboSameTotal_MetadataOnlyChange() {
         ViewPort.edit("<000102+4>")
         ViewPort.changeHistory.tagAsSaved()

         ViewPort.edit("@000 <000104+2>")

         Assert.isFalse(ViewPort.changeHistory.currentChange.hasDataChange)
      }

      private fun StandardSetup(data: Ref<ByteArray>, model: Ref<PokemonModel>, viewPort: Ref<ViewPort>) {
         data.value  = ByteArray(0x200)
         model.value  = PokemonModel(data.value)
         viewPort.value  = ViewPort("file.txt", model.value, InstantDispatch.instance, BaseViewModelTestClass.Singletons).also { it.width = 0x10; it.height = 0x10 }
      }
   }
