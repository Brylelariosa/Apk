@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class SingleTableModeTests : BaseViewModelTestClass() {
      init {
         ViewPort.allowSingleTableMode  = true
      }
      @Test fun TableWithOneElement_AddMoreCausesRepoint_CanSeeAllElements() {
         SetFullModel(0xFF)
         ViewPort.edit("^table[a: b: c: d:]1 ")
         Model[8]  = 1; // to force the repoint
         var tableTool = ViewPort.tools!!.tableTool

         tableTool!!.addCount  = 3
         tableTool!!.append.execute()

         var viewStart = ViewPort.dataOffset
         var table = (Model.getNextRun(viewStart) as ITableRun)
         Assert.equal(table.start, viewStart)
      }
      @Test fun SelectionInMiddleOfScreen_FollowPointerThenGoBack_SelectionStillInMiddleOfScreen() {
         ViewPort.selectionStart  = Point(0, 2)

         ViewPort.goto!!.execute(0x100)
         ViewPort.back.execute()

         Assert.equal(Point(0, 2), ViewPort.selectionStart)
      }
      @Test fun FocusTable_ClearFormat_SelectionDoesNotMoveSeeRawBytes() {
         ViewPort.edit("@40 ^table[a:: b:: c:: d::]20 ")

         var menuItem = ViewPort.getContextMenuItems(Point(0, 0)).single({ item -> item.text == "Clear Format" })
         menuItem.command.execute()

         Assert.equal(0, ViewPort.minimumScroll)
         Assert.equal(4, ViewPort.scrollValue)
         Assert.equal(0x20 - 1, ViewPort.maximumScroll)
      }
   }
