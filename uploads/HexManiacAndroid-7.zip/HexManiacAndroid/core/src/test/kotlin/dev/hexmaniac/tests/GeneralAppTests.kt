@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class GeneralAppTests : BaseViewModelTestClass() {
      private lateinit var editor: EditorViewModel
      private lateinit var fileSystem: StubFileSystem

      init {
         fileSystem  = FileSystem
         editor  = New.editorViewModel()
      }
      @Test fun ApplicationOpensWithNoTabs() {
         Assert.equal(0, editor.count)
         Assert.equal(-1, editor.selectedIndex)
      }
      @Test fun CanAddTabs() {
         var viewPort = ViewPort()
         editor.add(viewPort)
         Assert.equal(1, editor.count)
         Assert.equal(0, editor.selectedIndex)
      }
      @Test fun CanReorderTabs() {
         var viewPort1 = ViewPort(LoadedFile("file1", ByteArray(0)))
         var viewPort2 = ViewPort(LoadedFile("file2", ByteArray(0)))
         editor.add(viewPort1)
         editor.add(viewPort2)
         Assert.equal(2, editor.count)
         Assert.equal(1, editor.selectedIndex)

         editor.swapTabs(0, 1)

         Assert.equal("file2", editor[0].name)
         Assert.equal("file1", editor[1].name)
         Assert.equal(0, editor.selectedIndex)
      }
      @Test fun UndoRunsForCurrentTab() {
         var executeCounter: Int = 0
         editor.add(StubTabContent())
         editor.add(StubTabContent().also { it.undo = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> executeCounter++ } } })

         editor.undo.execute()
         Assert.equal(1, executeCounter)

         editor.selectedIndex  = 0
         Assert.isFalse(editor.undo.canExecute(null))
      }
      @Test fun SaveRunsForCurrentTab() {
         var executeCount: Int = 0
         editor.add(StubTabContent().also { it.save = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> executeCount  += 1 } } })
         editor.add(StubTabContent().also { it.save = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> executeCount  += 10 } } })

         editor.save.execute()
         Assert.equal(10, executeCount)

         executeCount  = 0
         editor.saveAll.execute()
         Assert.equal(11, executeCount)
      }
      @Test fun SaveAsRunsForCurrentTab() {
         var executeCount: Int = 0
         editor.add(StubTabContent().also { it.saveAs = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> executeCount  += 1 } } })
         editor.add(StubTabContent().also { it.saveAs = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> executeCount  += 10 } } })

         editor.saveAs.execute()
         Assert.equal(10, executeCount)
      }
      @Test fun SaveAllSavesAllDocumentsThatNeedSaving() {
         var executeCount: Int = 0

         var save = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> executeCount++ } }
         var noSave = StubCommand().also { it.canExecute = { arg -> false }; it.execute = { arg -> executeCount++ } }
         editor.add(StubTabContent().also { it.save = save })
         editor.add(StubTabContent().also { it.save = noSave })
         editor.add(StubTabContent().also { it.save = save })

         editor.saveAll.execute()
         Assert.equal(2, executeCount)
      }
      @Test fun ClosingCurrentTabSelectsAnotherTab() {
         editor.add(CreateClosableTab())
         editor.add(CreateClosableTab())
         editor.add(CreateClosableTab())

         editor.close.execute()

         Assert.equal(1, editor.selectedIndex)
      }
      @Test fun ClosingAllTabsWorks() {
         editor.add(CreateClosableTab())
         editor.add(CreateClosableTab())
         editor.add(CreateClosableTab())

         editor.closeAll.execute()

         Assert.equal(-1, editor.selectedIndex)
         Assert.equal(0, editor.count)
      }
      @Test fun NewAddsATab() {
         editor.new.execute()

         Assert.equal(1, editor.count)
      }
      @Test fun OpenCanAddTab() {
         fileSystem.openFile  = { description, extensions -> LoadedFile("chosenFile.txt", ByteArray(0x200)) }

         editor.open.execute()

         Assert.equal(1, editor.count)
      }
      @Test fun OpenDoesNotAddTabIfUserCancels() {
         fileSystem.openFile  = { description, extensions -> null }

         editor.open.execute()

         Assert.equal(0, editor.count)
      }
      @Test fun SaveCommandsPassInFileSystemAsParameter() {
         var count: Int = 0
         fun checkIfArgIsFileSystem(arg: Any?) { if (arg is IFileSystem) count++ }
         fun canExecuteWrapper(arg: Any?): Boolean { checkIfArgIsFileSystem(arg); return true }
         var save = StubCommand().also { it.canExecute = ::canExecuteWrapper; it.execute = ::checkIfArgIsFileSystem }

         editor.add(StubTabContent().also { it.save = save; it.saveAs = save })
         editor.add(StubTabContent().also { it.save = save; it.saveAs = save })
         editor.add(StubTabContent().also { it.save = save; it.saveAs = save })

         editor.save.execute(); // once
         editor.saveAs.execute(); // once
         editor.saveAll.execute(); // 6 times, since SaveAll should also check CanExecute

         Assert.equal(8, count)
      }
      @Test fun CloseCommandsPassInFileSystemAsParameter() {
         var count: Int = 0
         fun checkIfArgIsFileSystem(arg: Any?) { if (arg is IFileSystem) count++ }
         fun canExecuteWrapper(arg: Any?): Boolean { checkIfArgIsFileSystem(arg); return true }
         var close = StubCommand().also { it.canExecute = ::canExecuteWrapper; it.execute = ::checkIfArgIsFileSystem }

         editor.add(StubTabContent().also { it.close = close })
         editor.add(StubTabContent().also { it.close = close })
         editor.add(StubTabContent().also { it.close = close })

         editor.close.execute(); // once
         editor.closeAll.execute(); // 6 times, since SaveAll should also check CanExecute

         Assert.equal(7, count)
      }
      fun EditorNotifiesCanExecuteChangedOnTabChange(commandName: String) {
         var count: Int = 0
         var command = ((editor.javaClass.getMethod("get" + commandName.replaceFirstChar { it.uppercase() }).invoke(editor)) as ICommand)
         command.canExecuteChanged  += { sender, e -> count++ }
         var tab = StubTabContent()
         tab.close  = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> tab.closed.invoke(tab, EventArgs.empty) } }

         editor.add(tab)
         Assert.equal(1, count)

         count  = 0
         editor.close.execute()
         Assert.equal(1, count)
      }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_1() { EditorNotifiesCanExecuteChangedOnTabChange("copy") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_2() { EditorNotifiesCanExecuteChangedOnTabChange("delete") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_3() { EditorNotifiesCanExecuteChangedOnTabChange("save") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_4() { EditorNotifiesCanExecuteChangedOnTabChange("saveAs") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_5() { EditorNotifiesCanExecuteChangedOnTabChange("close") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_6() { EditorNotifiesCanExecuteChangedOnTabChange("undo") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_7() { EditorNotifiesCanExecuteChangedOnTabChange("redo") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_8() { EditorNotifiesCanExecuteChangedOnTabChange("back") }
    @Test fun EditorNotifiesCanExecuteChangedOnTabChange_9() { EditorNotifiesCanExecuteChangedOnTabChange("forward") }
      @Test fun EditorNotifiesWhenUndoCanExecuteChange() {
         var count: Int = 0
         var undo = StubCommand()
         var tab = StubTabContent().also { it.undo = undo }
         editor.add(tab)
         editor.undo.canExecuteChanged  += { sender, e -> count++ }

         undo.canExecute  = { arg -> true }
         undo.canExecuteChanged.invoke(undo, EventArgs.empty)

         Assert.equal(1, count)
      }
      @Test fun SaveAllChangesWhenCurrentFileChanges() {
         var count: Int = 0
         var save = StubCommand()
         var tab = StubTabContent().also { it.save = save }
         editor.add(tab)
         editor.saveAll.canExecuteChanged  += { sender, e -> count++ }

         save.canExecute  = { arg -> true }
         save.canExecuteChanged.invoke(save, EventArgs.empty)

         Assert.equal(1, count)
      }
      @Test fun EditorShowsErrors() {
         var tab = StubTabContent()
         editor.add(tab)
         var clearErrorChangedNotifications = 0
         editor.clearError.canExecuteChanged  += { sender, e -> clearErrorChangedNotifications  += 1 }

         tab.onError.invoke(tab, "Some Message")

         Assert.isTrue(editor.showError)
         Assert.equal("Some Message", editor.errorMessage)
         Assert.equal(1, clearErrorChangedNotifications)
      }
      @Test fun EditorCanClearErrors() {
         var tab = StubTabContent()
         editor.add(tab)
         var clearErrorChangedNotifications = 0
         editor.clearError.canExecuteChanged  += { sender, e -> clearErrorChangedNotifications  += 1 }

         tab.onError.invoke(tab, "Some Message")
         editor.clearError.execute()

         Assert.isFalse(editor.showError)
         Assert.equal(editor.errorMessage, "")
         Assert.equal(2, clearErrorChangedNotifications)
      }
      @Test fun ShowingGotoClearsErrors() {
         var tab = StubTabContent()
         editor.add(tab)

         tab.onError.invoke(tab, "Some Message")
         editor.gotoViewModel.showGoto.execute(true)

         Assert.isTrue(editor.gotoViewModel.controlVisible)
         Assert.isFalse(editor.showError)
      }
      @Test fun ActiveTabCanTellEditorToSwitch() {
         var tab0 = StubTabContent()
         var tab1 = StubTabContent()
         editor.add(tab0)
         editor.add(tab1)

         tab1.requestTabChange.invoke(tab1, newOf(tab0)); // tab 1 is requesting that the editor switch to tab 0

         Assert.equal(0, editor.selectedIndex)
      }
      @Test fun NonActiveTabSwitchesAreIgnored() {
         var tab0 = StubTabContent()
         var tab1 = StubTabContent()
         editor.add(tab0)
         editor.add(tab1)

         tab1.requestTabChange.invoke(tab0, newOf(tab0)); // tab 0 is trying to force itself to be focused

         Assert.equal(1, editor.selectedIndex)
      }
      @Test fun EditorAddsOpenedFilesToFileSystemWatch() {
         var fileSystem = StubFileSystem()
         var name: String = ""
         fileSystem.addListenerToFile  = { fileName, action -> name  = fileName }
         var editor = EditorViewModel(fileSystem)

         editor.open.execute(LoadedFile("InputFile.txt", ByteArray(0x200)))

         Assert.equal("InputFile.txt", name)
      }
      @Test fun EditorRemovesFileSystemWatchWhenTabsClose() {
         var fileSystem = StubFileSystem()
         var name: String = ""
         fileSystem.removeListenerForFile  = { fileName, listener -> name  = fileName }
         var editor = EditorViewModel(fileSystem)
         editor.open.execute(LoadedFile("InputFile.txt", ByteArray(0x200)))

         editor.close.execute()

         Assert.equal("InputFile.txt", name)
      }
      @Test fun ViewPortReloadsIfNoLocalChangesWhenFileChanges() {
         var fileSystem = StubFileSystem()
         var file: String = ""
         fileSystem.loadFile  = lm1@{ input -> file  = input; return@lm1 LoadedFile(input, bytes( 0x10, 0x20)) }
         var viewPort = ViewPort(LoadedFile("file.txt", bytes( 0x00, 0x00)))

         viewPort.considerReload(fileSystem)

         Assert.equal("file.txt", file)
         Assert.equal(0x10, viewPort[0, 0].value)
      }
      @Test fun ViewPortDoesNotReloadIfLocalChangesWhenFileChanges() {
         var fileSystem = StubFileSystem()
         var file: String? = null
         fileSystem.loadFile  = lm2@{ input -> file  = input; return@lm2 LoadedFile(input, bytes( 0x10, 0x20)) }
         var viewPort = ViewPort(LoadedFile("file.txt", bytes( 0x00, 0x00)))

         viewPort.edit("05")
         viewPort.considerReload(fileSystem)

         Assert.isNull(file)
         Assert.equal(0x05, viewPort[0, 0].value)
      }
      @Test fun EditorForwardsTabDelayedWork() {
         val SomeAction: () -> Unit = { }
         var work: () -> Unit = { }
         var editor = EditorViewModel(StubFileSystem())
         var tab = StubTabContent()
         editor.add(tab)

         editor.requestDelayedWork  += { sender, e -> work  = e }
         tab.requestDelayedWork.invoke(tab, SomeAction)

         Assert.same(SomeAction, work)
      }
      @Test fun FirstFileOpenAutomaticallySavesItsMetadata() {
         var fileSystem = StubFileSystem()
         var editor = EditorViewModel(fileSystem)
         var saveCount = 0
         fileSystem.saveMetadata  = lm3@{ fileName, data -> saveCount  += 1; return@lm3 true }

         fileSystem.openFile  = { type, exensions -> LoadedFile("file.gba", ByteArray(0x200)) }
         editor.open.execute()

         Assert.equal(1, saveCount)
      }
      @Test fun ZoomCanReset() {
         var fileSystem = StubFileSystem()
         var editor = EditorViewModel(fileSystem).also { it.zoomLevel = 24 }

         editor.resetZoom.execute()

         Assert.equal(16, editor.zoomLevel)
      }
      @Test fun ThemeCanReset() {
         var editor = EditorViewModel(StubFileSystem())
         var defaultValue = editor.theme.accentValue

         editor.theme.accentValue  += 1
         Assert.equal(defaultValue + 1, editor.theme.accentValue)

         editor.resetTheme.execute()
         Assert.equal(defaultValue, editor.theme.accentValue)
      }
      @Test fun CanOpenSecondTabWithSameModel() {
         var test = BaseViewModelTestClass()
         editor.add(test.ViewPort)
         test.ViewPort.edit("<000100> @00 "); // create a pointer for us to follow

         var group = ((test.ViewPort.getContextMenuItems(Point()).single({ menuItem -> menuItem.text == "Pointer Operations" })) as ContextItemGroup)
         var item = group.single({ menuItem -> menuItem.text == "Open in New Tab" })
         item.command.execute()

         var newTab = ((editor[1]) as ViewPort)
         Assert.equal(test.ViewPort.currentChange, newTab.currentChange); // they have the same change history
         Assert.equal(test.ViewPort.model, newTab.model);                 // they have the same model
         Assert.equal(0x100, newTab.dataOffset)                          // the new tab is scrolled to the desired location
      }
      @Test fun TabGetsRefreshedWhenSwitchedIn() {
         var count: Int = 0
         var tab1 = StubTabContent().also { it.refresh = { count++ } }
         var tab2 = StubTabContent()
         editor.add(tab1)
         count  = 0

         tab1.requestTabChange?.invoke(tab1, newOf(tab2))
         editor.selectedIndex  = 0

         Assert.equal(1, count)
      }
      @Test fun CanLoadVersionFromToml() {
         var file = "\n[General]\nApplicationVersion = '''0.1.0'''\n"
         var metadata = StoredMetadata(file.split('\n', '\r').toTypedArray())
         Assert.equal("0.1.0", metadata.version)
      }
      @Test fun CanSaveVersionToToml() {
         var metadata = StoredMetadata(null, null, null, null, null, null, StubMetadataInfo().also { it.versionNumber = "0.1.0" }, 0, 0, 0)
         var lines = metadata.serialize()
         Assert.contains("[General]", lines)
         Assert.contains("ApplicationVersion = '''0.1.0'''", lines)
      }
      @Test fun NullVersionIsNotSavedToToml() {
         var metadata = StoredMetadata(null, null, null, null, null, null, StubMetadataInfo(), 0, 0, 0)
         var lines = metadata.serialize()
         Assert.all(lines, { line -> Assert.doesNotContain("ApplicationVersion = '''", line) })
      }
      @Test fun ClosingTabUpdatesQuickEdits() {
         var tabChangedCalls: Int = 0
         var qItem = StubQuickEditItem().also { it.tabChanged = { tabChangedCalls  += 1 } }
         var editor = EditorViewModel(StubFileSystem(), utilities = listOf( qItem))
         var tabToClose = StubTabContent()
         editor.add(StubTabContent())
         editor.add(tabToClose)

         tabChangedCalls  = 0
         tabToClose.closed.invoke(tabToClose, EventArgs.empty)

         Assert.equal(1, tabChangedCalls)
      }
      @Test fun TableReference_Load_NoNamesPrefixOtherNames() {
         var tableNames = BaseViewModelTestClass.Singletons.gameReferenceTables.values.flatMap({ tables -> tables.map({ table -> table.name.lowercase() }) })
            .plus(BaseViewModelTestClass.Singletons.gameReferenceConstants!!.values.flatMap({ constants -> constants.map({ constant -> constant.name.lowercase() }) }))
            .distinct().toTypedArray()
         for (i in 0 until tableNames.size) {
            Assert.all(tableNames.size.range(), lm4@{ j ->
               if (i == j) return@lm4
               Assert.isFalse(tableNames[i].startsWith(tableNames[j] + "."), "${tableNames[i]} contains name ${tableNames[j]}!")
            })
         }
      }
      @Test fun NewTab_Backspace_DoNothing() {
         editor.new.execute()

         var viewPort = ((editor[0]) as ViewPort)
         for (i in 0 until 5)
            viewPort.edit(ConsoleKey.Backspace)

         // no asserts: if it doesn't crash, we pass
      }
      @Test fun Tab_Edit_CanRunChanged() {
         var test = BaseViewModelTestClass()
         editor.add(test.ViewPort)
         Assert.isTrue(editor.runFile.canExecute(null))

         var view = StubView(editor)
         test.ViewPort.edit("aa ")

         Assert.contains("runFile", view.commandCanExecuteChangedNotifications)
         Assert.isFalse(editor.runFile.canExecute(null))
      }
      @Test fun Tab_Duplicate_Duplicated() {
         var tab = StubTabContent().also { it.canDuplicate = true }
         tab.duplicate  = { tab.requestTabChange.invoke(tab, newOf(StubTabContent())) }

         editor.add(tab)
         editor.duplicateCurrentTab.execute()

         Assert.equal(2, editor.count)
         Assert.isTrue(editor.gotoViewModel.controlVisible)
      }
      @Test fun TabWithoutDuplicate_SwitchToTabWithDuplicate_Notify() {
         editor.add(StubTabContent().also { it.canDuplicate = false })
         editor.add(StubTabContent().also { it.canDuplicate = true })
         editor.selectedIndex  = 0
         var view = StubView(editor)

         editor.selectedIndex  = 1

         Assert.contains("duplicateCurrentTab", view.commandCanExecuteChangedNotifications)
      }
      @Test fun CleanTab_MetadataOnlyEdit_EditorPropertiesMatch() {
         var tab = StubTabContent()
         var save = StubCommand()
         tab.save  = save
         editor.add(tab)
         var view = StubView(editor)

         tab.isMetadataOnlyChange  = true
         save.canExecute  = { arg -> true }
         tab.propertyChanged.invoke(tab, PropertyChangedEventArgs("isMetadataOnlyChange"))
         save.canExecuteChanged.invoke(save, EventArgs.empty)

         Assert.isTrue(editor.isMetadataOnlyChange)
         Assert.contains("isMetadataOnlyChange", view.propertyNotifications)
      }
      @Test fun Editor_SwapTabs_GotoHasRightShortcuts() {
         var singletons = BaseViewModelTestClass.Singletons
         var viewPort = ViewPort("file.gba", PokemonModel(ByteArray(0x200), null, singletons), InstantDispatch.instance, singletons)
         var shortcuts = listOf( StoredGotoShortcut("name", "image", "destination"))
         viewPort.model.loadMetadata(StoredMetadata(null, null, null, null, null, null, shortcuts, singletons.metadataInfo, null))
         viewPort.edit("^destination ")

         editor.add(viewPort)
         editor.add(StubTabContent())
         editor.selectedIndex  = 0

         Assert.isFalse(editor.gotoViewModel.loading)
         Assert.single(editor.gotoViewModel.shortcuts)
      }
      @Test fun TabWithMetadataChange_SwitchTabs_SaveIconUpdates() {
         editor.add(StubTabContent().also { it.isMetadataOnlyChange = true })
         editor.add(StubTabContent().also { it.isMetadataOnlyChange = false })
         editor.selectedIndex  = 0
         var view = StubView(editor)

         editor.selectedIndex  = 1

         Assert.isFalse(editor.isMetadataOnlyChange)
         Assert.contains("isMetadataOnlyChange", view.propertyNotifications)
      }
      @Test fun Editor_OpenFile_NotifyRecentFileMenuEnabled() {
         var view = StubView(editor)

         editor.open.execute(LoadedFile("TestRom.gba", ByteArray(0x200)))

         Assert.contains("recentFileMenuEnabled", view.propertyNotifications)
      }
      @Test fun Editor_New_PokemonModel() {
         editor.new.execute()
         var viewPort = (editor.selectedTab as IViewPort)
         Assert.isType<PokemonModel>(viewPort.model)
      }
      @Test fun Tab_SaveAs_UpdatesRecentFiles() {
         var filename = "Test.gba"

         editor.add(StubViewPort().also { it.fileName = filename; it.saveAs = StubCommand().also { it.canExecute = { arg -> true } } })

         editor.saveAs.execute()
         Assert.contains(filename, editor.recentFiles)
      }

      private fun CreateClosableTab(): StubTabContent {
         var tab = StubTabContent()
         var close = StubCommand().also { it.canExecute = { arg -> true } }
         close.execute  = { arg -> tab.closed.invoke(tab, EventArgs.empty) }
         tab.close  = close
         return tab
      }
   }
