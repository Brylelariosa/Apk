@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ListTests : BaseViewModelTestClass() {
      @Test fun MetadataCanLoadList() {
         var lines = ArrayList<String>()
         lines.add("[[List]]")
         lines.add("Name = '''moveeffects'''")
         lines.add("1 = [")
         lines.add("   '''abc''',")
         lines.add("   '''\"def\"''',")
         lines.add("]")
         lines.add("5 = ['''xyz''']")
         lines.add("7 = '''bob'''")

         var metadata = StoredMetadata(lines.toTypedArray())

         var moveEffects = metadata.lists.single({ list -> list.name == "moveeffects" })
         Assert.equal(8, moveEffects.size)
         Assert.equal("0", moveEffects[0])
         Assert.equal("abc", moveEffects[1])
         Assert.equal("\"def\"", moveEffects[2])
         Assert.equal("3", moveEffects[3])
         Assert.equal("4", moveEffects[4])
         Assert.equal("xyz", moveEffects[5])
         Assert.equal("6", moveEffects[6])
         Assert.equal("bob", moveEffects[7])
      }
      @Test fun MetadataCanSaveList() {
         var input = mutableListOf<String?>(
            "bob",
            "tom",
            null,
            "sam",
            "fry",
            "kevin",
            null,
            null,
            "carl",)
         var list = New.storedList("Input", input as List<String>)

         var lines = ArrayList<String>()
         list.appendContents(lines)
         lines  = ArrayList(lines.filter({ line -> line.length > 0 }))

         Assert.equal("[[List]]\nName = '''Input'''\nDefaultHash = '''0BEEDA92'''\n0 = [\n   '''bob''',\n   '''tom''',\n]\n3 = [\n   '''sam''',\n   '''fry''',\n   '''kevin''',\n]\n8 = '''carl'''\n".split('\n', '\r').filter { it.isNotEmpty() }.toMutableList(), lines)
      }
      @Test fun ListWithPipe_WritePipeInEnum_EditWorks() {
         Model.setList("list", mutableListOf<String>( "some|text", "other|text", "content"))
         ViewPort.edit("^table[a:list]2 ")

         ViewPort.edit("other|text ")

         Assert.equal(1, Model.readMultiByteValue(0, 2))
      }
      @Test fun ListWithSpaceAndComma_WriteInEnum_EditWorks() {
         Model.setList("list", mutableListOf<String>( "some|text", "other, text", "content"))
         ViewPort.edit("^table[a:list]2 ")

         ViewPort.edit("\"other, text\" ")

         Assert.equal(1, Model.readMultiByteValue(0, 2))
         Assert.equal(2, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun ListLengthTable_Append_CanAppend() {
         Model.setList(ModelDelta(), "list", "item1", "item2")

         ViewPort.edit("^table[a:]list ")
         var table = Model.getTable("table")

         Assert.isTrue(table!!.canAppend)
      }
      @Test fun ModelDelta_ExpressListChange_HasChange() {
         var token = ModelDelta()
         token.changeList("list", arrayOf( "oldcontents"), arrayOf( "newcontents"))
         Assert.isFalse(token.hasDataChange)
         Assert.isTrue(token.hasAnyChange)
      }
      @Test fun Model_ChangeList_TokenSeesChange() {
         Model.setList(ModelDelta(), "name", "a", "b")

         var token = ModelDelta()
         Model.setList(token, "name", "a", "b", "c")

         Assert.isTrue(token.hasAnyChange)
      }
      @Test fun DeltaObjectWithListChange_ProcessWithModel_ListChanged() {
         Model.setList(ModelDelta(), "name", "a", "b")

         var token = ModelDelta()
         token.changeList("name", arrayOf( "a"), arrayOf( "a", "b"))
         token.revert(Model)

         val list = Ref<ValidationList?>(null)
         Model.tryGetList("name", list)
         Assert.equal(arrayOf( "a"), list.value)
      }
      @Test fun ListLengthArray_Append_ListGrows() {
         Model.setList(ModelDelta(), "list", "a", "b")
         ViewPort.edit("^table[x:]list ")

         ViewPort.goto!!.execute(4)
         ViewPort.edit("+")

         val list = Ref<ValidationList?>(null)
         Model.tryGetList("list", list)
         var table = Model.getTable("table")
         Assert.equal(list.value, arrayOf( "a", "b", "unnamed2"))
      }
      @Test fun OneListLengthTable_EnumsUseList_AllowJumpToTable() {
         Model.setList("list", listOf( "a", "b"))
         ViewPort.edit("@00 ^table1[x:]list ")

         ViewPort.edit("@100 ^table2[y:list]2 ")
         var tool = ((ViewPort.tools!!.tableTool!!.children.single({ e -> e  is ComboBoxArrayElementViewModel && (e as ComboBoxArrayElementViewModel).name == "y" })) as ComboBoxArrayElementViewModel)
         tool.gotoSource.execute()

         Assert.equal(0, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun ElementWithSpace_CopyBitFlags_ResultHasQuotes() {
         Model.setList("list", listOf( "noSpaces", "with spaces"))
         Model[0]  = 2
         var segment = ArrayRunBitArraySegment("name", 1, "list")

         var text = segment.toText(Model, 0, 0)

         Assert.equal("- \"with spaces\" /", text)
      }
      @Test fun DefaultToml_LoadList_HashMatches() {
         var metadatas = BaseModel.getDefaultMetadatas("AXVE0", "BPRE", "BPEE0")

         for (list in metadatas.flatMap({ metadata -> metadata.lists })) {
            Assert.isTrue(list.hashMatches)
         }
      }
      @Test fun DefaultList_ChangeContent_HashDoesNotMatch() {
         var text = ArrayList<String>()
         BaseModel.getDefaultMetadatas().first().lists[0].appendContents(text)

         var hashLine = text.single({ line -> line.trim().startsWith("DefaultHash = '''") })
         text[text.indexOf(hashLine)]  = "DefaultHash = '''0'''"
         var metadata = StoredMetadata(text.toTypedArray())

         Assert.isFalse(metadata.lists[0].hashMatches)
      }
      @Test fun DefaultList_HashMatches() {
         var list = BaseModel.getDefaultMetadatas().first().lists[0]

         Assert.isTrue(list.hashMatches)
      }
      @Test fun HashMatches_UpdateVersion_ListUpdates() {
         var someRealList = BaseModel.getDefaultMetadatas().first().lists.first()
         SetGameCode("BPRE0")

         var content = arrayOf( "some", "content")
         var metadata = StoredMetadata(
            generalInfo = StubMetadataInfo().also { it.versionNumber = "0.0.1" },
            lists = listOf( New.storedList(someRealList.name, content.toList(), StoredList.generateHash(content.toList()))))
         var model = PokemonModel(Model.rawData, metadata, Singletons)

         val list = Ref<ValidationList?>(null)
         model.tryGetList(someRealList.name, list)
         Assert.equal(someRealList.contents, list.value!!.toMutableList())
      }
      @Test fun HashDoesNotMatch_UpdateVersion_ListDoesNotUpdate() {
         var someRealList = BaseModel.getDefaultMetadatas().first().lists.first()
         SetGameCode("BPRE0")

         var content = arrayOf( "some", "content")
         var metadata = StoredMetadata(
            generalInfo = StubMetadataInfo().also { it.versionNumber = "0.0.1" },
            lists = listOf( New.storedList(someRealList.name, content.toList(), hash = "0")))
         var model = PokemonModel(Model.rawData, metadata, Singletons)

         val list = Ref<ValidationList?>(null)
         model.tryGetList(someRealList.name, list)
         Assert.equal(content, list.value!!.toMutableList())
      }
      @Test fun ListWithNullEntries_AutoComplete_NoThrow() {
         Model.setList("list", listOf<String?>( "zero", "one", null, "three") as List<String>)
         ViewPort.edit("^table[a:list]2 ")

         var visitor = AutocompleteCell(Model, "e", 0)
         ViewPort[0, 0].format!!.visit(visitor, 0)
         var result = visitor.result!!.map({ item -> item.displayText.trim() }).toTypedArray()

         Assert.equal(arrayOf( "zero", "one", "three"), result)
      }
      @Test fun ListWithNullEntries_FilterOptionInTableTool_FilterOptions() {
         Model.setList("list", listOf<String?>( "zero", "one", null, "three") as List<String>)
         ViewPort.edit("^table[a:list]2 ")
         ViewPort.refresh()

         var item = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<ComboBoxArrayElementViewModel>()
         item.filterText  = "r"

         Assert.equal(arrayOf( "zero", "three"), item.options.map({ option -> option.text }))
      }
      @Test fun ListWithNullEntries_NoFilter_DoNotShowNullOptions() {
         Model.setList("list", listOf<String?>( "zero", "one", null, "three") as List<String>)
         ViewPort.edit("^table[a:list]2 ")
         ViewPort.refresh()

         var item = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<ComboBoxArrayElementViewModel>()

         Assert.equal(arrayOf( "zero", "one", "three"), item.options.map({ option -> option.text }))
      }
      @Test fun ListWithNullEntries_ByteHasNullName_ShowAsNumber() {
         Model[0]  = 2
         Model.setList("list", listOf<String?>( "zero", "one", null, "three") as List<String>)
         ViewPort.edit("^table[a:list]2 ")
         ViewPort.refresh()

         var item = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<ComboBoxArrayElementViewModel>()

         Assert.equal(arrayOf( "zero", "one", "2", "three"), item.options.map({ option -> option.text }))
      }
      @Test fun ListWithNullEntries_SelectValueInTableTool_CorrectValueInModel() {
         Model.setList("list", listOf<String?>( "zero", "one", null, "three") as List<String>)
         ViewPort.edit("^table[a:list]2 ")
         ViewPort.refresh()

         var item = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<ComboBoxArrayElementViewModel>()
         item.selectedIndex  = 2; // "three"

         Assert.equal(3, Model[0])
      }
      @Test fun ListWithNullEntries_ValueAfterNullInModel_ShowInTableTool() {
         Model[0]  = 3
         Model.setList("list", listOf<String?>( "zero", "one", null, "three") as List<String>)
         ViewPort.edit("^table[a:list]2 ")
         ViewPort.refresh()

         var item = ViewPort.tools!!.tableTool!!.groups[0].members.singleOf<ComboBoxArrayElementViewModel>()

         Assert.equal("three", item.filterText)
      }
      @Test fun ListWithHexIndex_Load_ListLoaded() {
         var input = mutableListOf<String>(
            "[[List]]",
            "Name = '''test'''",
            "0x00 = '''name0'''",
            "0x02 = '''name2'''",)

         var metadata = StoredMetadata(input.toTypedArray())

         var list = metadata.lists.single()
         Assert.equal("name0", list[0])
         Assert.equal("1", list[1])
         Assert.equal("name2", list[2])
         Assert.equal(3, list.size)
      }
      @Test fun ListWithApostrophe_TypeIntoBitFieldFromList_AcceptsApostrophe() {
         Model.setList("list", listOf( "Item", "Arby's", "Content"))
         ViewPort.edit("^table[content|b[]list]1 ")

         ViewPort.edit("arby'")

         Assert.isType<UnderEdit>(ViewPort[0, 0].format)
      }
   }
