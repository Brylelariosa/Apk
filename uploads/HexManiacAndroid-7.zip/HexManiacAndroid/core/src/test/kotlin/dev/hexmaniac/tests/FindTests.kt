@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class FindTests {
      private fun CreateCreateChildView(tab: () -> IViewPort): (Int, Int) -> ChildViewPort = { start, end -> ChildViewPort(tab(), InstantDispatch.instance, BaseViewModelTestClass.Singletons) }
      private fun NewViewPort(model: IDataModel): ViewPort = ViewPort("test.gba", model, InstantDispatch.instance, BaseViewModelTestClass.Singletons)
      private fun DefaultFind(vararg results: IViewPortFindTuple): (String, Boolean) -> List<IViewPortFindTuple> = { text, matchExactCase -> results.toList() }
      @Test fun FindCanFindSingle() {
         var array = ByteArray(0x1000)
         bytes( 0x84, 0x23, 0xBB, 0x21).copyInto(array, 0x240)
         var port = ViewPort(LoadedFile("test", array))

         var results = port.find("84 23 BB 21")

         Assert.single(results)
         Assert.equal(0x240, results[0].start)
      }
      @Test fun FindCanFindMultiple() {
         var array = ByteArray(0x1000)
         var searchFor = bytes( 0x84, 0x23, 0xBB, 0x21)
         searchFor.copyInto(array, 0x240)
         searchFor.copyInto(array, 0xA70)
         var port = ViewPort(LoadedFile("test", array))

         var results = port.find("84 23 BB 21").map({ result -> result.start }).toMutableList()

         Assert.equal(2, results.size)
         Assert.contains(0x240, results)
         Assert.contains(0xA70, results)
      }
      @Test fun EditorShowsErrorIfNoneFound() {
         var tab = StubViewPort()
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab) }

         tab.find  = DefaultFind()
         editor.find.execute("something")

         Assert.isTrue(editor.showError)
         Assert.isFalse(isNullOrEmpty_(editor.errorMessage))
      }
      @Test fun EditorJumpsToResultIfSingleResult() {
         var tab = StubViewPort()
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab) }
         var gotoArg: String = ""

         tab.find  = DefaultFind(IViewPortFindTuple(0x54, 0x54))
         tab.goto  = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> gotoArg  = (arg as String) } }
         editor.find.execute("something")

         Assert.isFalse(editor.showError)
         Assert.equal("54", gotoArg)
      }
      @Test fun EditorOpensHelperTabIfMultipleResult() {
         var tab = StubViewPort()
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab) }
         var count = 0

         tab.find  = DefaultFind(IViewPortFindTuple(0x54, 0x54), IViewPortFindTuple(0x154, 0x154))
         tab.model  = BasicModel(ByteArray(0x200))
         tab.createChildView  = lm1@{ startAddress: Int, endAddress: Int ->
            var child = ChildViewPort(tab, InstantDispatch.instance, BaseViewModelTestClass.Singletons)
            count++
            return@lm1 child
         }
         editor.find.execute("something")

         Assert.equal(2, count); // since there were 2 results, editor should've asked for 2 child views
         Assert.equal(2, editor.count)
         Assert.equal(1, editor.selectedIndex)
         Assert.isType<SearchResultsViewPort>(editor[1])
      }
      @Test fun EditorHasShortcutsToGetPreviousOrNextFindResult() {
         var gotoCount: Int = 0
         lateinit var tab: StubViewPort
         tab  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x54, 0x54), IViewPortFindTuple(0x154, 0x154)); it.model = BasicModel(ByteArray(0x200)); it.goto = StubCommand().also { it.canExecute = { arg -> true }; it.execute = { arg -> gotoCount++ } }; it.createChildView = { start, end -> ChildViewPort(tab, InstantDispatch.instance, BaseViewModelTestClass.Singletons) }; it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab) }

         editor.find.execute("something")
         editor.selectedIndex  = 0
         editor.findNext.execute("something")
         editor.findPrevious.execute("something")

         Assert.equal(2, gotoCount) // findNext / findPrevious use goto
      }
      @Test fun EditorFindNextDoesNotSwitchTabs() {
         lateinit var tab1: StubViewPort
         tab1  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x60, 0x60)); it.goto = StubCommand(); it.model = BasicModel(ByteArray(0x200)); it.createChildView = CreateCreateChildView({ tab1 }); it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         lateinit var tab2: StubViewPort
         tab2  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x50, 0x50), IViewPortFindTuple(0x70, 0x70)); it.goto = StubCommand(); it.model = BasicModel(ByteArray(0x200)); it.createChildView = CreateCreateChildView({ tab2 }); it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab1); it.add(tab2) }

         editor.find.execute("something")

         editor.findNext.execute("something")
         Assert.equal(2, editor.selectedIndex); // results still selected

         editor.selectedIndex  = 0
         editor.findNext.execute("something")
         Assert.equal(0, editor.selectedIndex); // results in first tab selected

         editor.selectedIndex  = 1
         editor.findNext.execute("something")
         Assert.equal(1, editor.selectedIndex) // results in second tab selected
      }
      @Test fun FindResultsHasHeadersAndGaps() {
         lateinit var tab: StubViewPort
         tab  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x50, 0x50), IViewPortFindTuple(0x70, 0x70)); it.goto = StubCommand(); it.model = BasicModel(ByteArray(0x200)); it.createChildView = CreateCreateChildView({ tab }); it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab) }

         editor.find.execute("something")
         var results = ((editor[1]) as IViewPort)
         results.height  = 9; // both children are size 4, one space inbetween
         Assert.isFalse(results.headers!!.map({ s -> s.content }).all(::isNullOrEmpty_)); // not all the headers are blank
         Assert.contains(results.headers!!.map({ s -> s.content }), ::isNullOrEmpty_)  // blank lines have blank headers
      }
      @Test fun FindClosesAfterRun() {
         lateinit var tab: StubViewPort
         tab  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x50, 0x50), IViewPortFindTuple(0x70, 0x70)); it.goto = StubCommand(); it.model = BasicModel(ByteArray(0x200)); it.createChildView = CreateCreateChildView({ tab }); it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab) }

         editor.showFind.execute(true)
         editor.find.execute("something")

         Assert.isFalse(editor.findControlVisible)
      }
      @Test fun CompositeCanScroll() {
         var composite = SearchResultsViewPort("search").also { it.height = 0x10 }
         var parentData = ByteArray(0x100)
         var parent = StubViewPort().also { it.width = 0x10; it.height = 0x10; it.model = BasicModel(parentData) }
         composite.add(CreateCreateChildView({ parent })(0, 0), 0, 0)

         var bodyChanged = false
         var headerChanged = false
         composite.headers!!.collectionChanged  += { sender, e -> headerChanged  = true }
         composite.collectionChanged  += { sender, e -> bodyChanged  = true }

         composite.scrollValue  = 4

         Assert.isTrue(bodyChanged)
         Assert.isTrue(headerChanged)
      }
      @Test fun FindOrderShouldBeBasedOnCurrentSelection() {
         var data = ByteArray(0x100)
         var dataToFind = bytes( 0x52, 0xDC, 0xFF, 0x79)
         dataToFind.copyInto(data, 0x2)
         dataToFind.copyInto(data, 0x62)
         dataToFind.copyInto(data, 0xA8)
         dataToFind.copyInto(data, 0xCC)
         var viewPort = ViewPort(LoadedFile("test", data)).also { it.width = 8; it.height = 8 }
         viewPort.selectionStart  = Point(0, 2); // select byte 0x10

         var results = viewPort.find("52 DC FF 79").map({ result -> result.start }).toMutableList()

         // the earliest match is at the end because the search started where the cursor was and looped around.
         Assert.isTrue(results == listOf( 0x62, 0xA8, 0xCC, 0x02))
      }
      @Test fun FindSwitchesTabIfSingleResultIsOnAnotherTab() {
         var tab0 = StubViewPort().also { it.goto = StubCommand() }
         var tab1 = StubTabContent()
         var editor = EditorViewModel(StubFileSystem()).also { it.add(tab0); it.add(tab1) }

         tab0.find  = DefaultFind(IViewPortFindTuple(0x50, 0x50))
         editor.find.execute("search")

         Assert.equal(0, editor.selectedIndex)
      }
      @Test fun FindNextFindPreviousDisabledIfNoResults() {
         var editor = EditorViewModel(StubFileSystem())

         Assert.isFalse(editor.findPrevious.canExecute("text"))
         Assert.isFalse(editor.findNext.canExecute("text"))
      }
      @Test fun FindNextAndPreviousBecomePossibleAfterFindSingleResult() {
         var editor = EditorViewModel(StubFileSystem())
         lateinit var tab: StubViewPort
         tab  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x50, 0x50)); it.goto = StubCommand(); it.createChildView = CreateCreateChildView({ tab }); it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         editor.add(tab)

         editor.find.execute("text")

         Assert.isTrue(editor.findPrevious.canExecute("text"))
         Assert.isTrue(editor.findNext.canExecute("text"))
      }
      @Test fun FindNextAndPreviousBecomePossibleAfterTabSwitchAfterFindMultiResult() {
         var editor = EditorViewModel(StubFileSystem())
         lateinit var tab: StubViewPort
         tab  = StubViewPort().also { it.find = DefaultFind(IViewPortFindTuple(0x50, 0x50), IViewPortFindTuple(0x70, 0x70)); it.goto = StubCommand(); it.model = BasicModel(ByteArray(0x200)); it.createChildView = CreateCreateChildView({ tab }); it.headers = ObservableCollection<RowHeader>().also { "00"; "01"; "02"; "03" }; it.width = 4; it.height = 4 }
         editor.add(tab)

         editor.find.execute("text")
         Assert.isFalse(editor.findPrevious.canExecute("text"))
         Assert.isFalse(editor.findNext.canExecute("text"))

         editor.selectedIndex  = 0
         Assert.isTrue(editor.findPrevious.canExecute("text"))
         Assert.isTrue(editor.findNext.canExecute("text"))
      }
      @Test fun FindRaisesMessageForGoodResults() {
         var editor = EditorViewModel(StubFileSystem())
         var data = ByteArray(0x100)
         var dataToFind = bytes( 0x52, 0xDC, 0xFF, 0x79)
         dataToFind.copyInto(data, 0x2)
         var viewPort = ViewPort(LoadedFile("test", data)).also { it.width = 8; it.height = 8 }
         editor.add(viewPort)
         editor.find.execute("52 DC FF 79")

         Assert.isTrue(editor.showMessage)
      }
      @Test fun SearchResultsHaveFullResultsSelected() {
         var text = "This is the song that never ends."
         var bytes = PCSString.convert(text)!!.toTypedArray()
         var buffer = ByteArray(0x200)
         arrayCopy(bytes, 0, buffer, 0x30, bytes.size);                // two copies of the data
         arrayCopy(bytes, 0, buffer, 0x60, bytes.size);                // at reasonable locations
         var model = PokemonModel(buffer)
         var viewPort = ViewPort("test.gba", model, InstantDispatch.instance, BaseViewModelTestClass.Singletons).also { it.width = 0x10; it.height = 0x10 }
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort)

         editor.find.execute("This is the song")
         var resultsTab = ((editor[editor.selectedIndex]) as IViewPort)
         resultsTab.width  = 0x10
         resultsTab.height  = 0x10

         var selectedCellCount: Int = 0
         for (x in 0 until resultsTab.width) {
            selectedCellCount  += resultsTab.height.range()
               .map({ y -> Point(x, y) })
               .count({ p -> resultsTab.isSelected(p) })
         }

         Assert.inRange(selectedCellCount, 30, 40)
      }
      @Test fun FollowingASearchResultSelectsEntireResult() {
         var text = "This is the song that never ends."
         var bytes = PCSString.convert(text)!!.toTypedArray()
         var buffer = ByteArray(0x200)
         arrayCopy(bytes, 0, buffer, 0x30, bytes.size);                // two copies of the data
         arrayCopy(bytes, 0, buffer, 0x60, bytes.size);                // at reasonable locations
         var model = PokemonModel(buffer)
         var viewPort = NewViewPort(model)
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort)

         editor.find.execute("This is the song")
         var resultsTab = ((editor[editor.selectedIndex]) as IViewPort)
         resultsTab.followLink(0, 1)

         Assert.notEqual(viewPort.selectionStart, viewPort.selectionEnd)
      }
      @Test fun SearchCanFindTableRows() {
         // Arrange two tables, one that depends on the other
         var data = 0x200.range().map({ i -> 0xFF.u8() }).toTypedArray()
         var model = PokemonModel(data.toByteArr())
         var viewPort = NewViewPort(model)
         viewPort.edit("^names[entry\"\"8] +\"bob\" +\"sam\" +\"carl\" +\"steve\" ")
         viewPort.edit("@50 ^table[x: y:]names ")

         // Act: do a search that should return a table entry as a result
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort)
         editor.find.execute("carl")

         // Assert: there are 2 results, one for the text and one for the table
         Assert.contains("2", editor.informationMessage)
      }
      @Test fun SearchCanFindEnumUsages() {
         // Arrange two tables, one that depends on the other
         var data = 0x200.range().map({ i -> 0xFF.u8() }).toTypedArray()
         var model = PokemonModel(data.toByteArr())
         var viewPort = NewViewPort(model)
         viewPort.edit("^names[entry\"\"8] +\"bob\" +\"sam\" +\"carl\" +\"steve\" ")
         viewPort.edit("@50 ^table[x: y:names]2 12 sam 100 steve ")

         // Act: do a search that should return a table entry as a result
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort)
         editor.find.execute("steve")

         // Assert: there are 2 results, one for the text and one for the enum
         Assert.contains("2", editor.informationMessage)
      }
      @Test fun FindingSingleResultHighlightsEntireResult() {
         var data = 0x100.range().map({ i -> i.u8() }).toTypedArray()
         var model = PokemonModel(data.toByteArr())
         var viewPort = NewViewPort(model)
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort)

         editor.find.execute("05 06 07 08")

         Assert.notEqual(viewPort.selectionStart, viewPort.selectionEnd)
      }
      @Test fun SameModelDoesNotGetSearchedMultipleTimes() {
         var findCalls: Int = 0
         fun Find(input: String, matchExactCase: Boolean = false): List<IViewPortFindTuple> {
            findCalls  += 1
            return ArrayList<IViewPortFindTuple>()
         }
         var viewPort1 = StubViewPort().also { it.model = SelfEqualStub(); it.find = ::Find }
         var viewPort2 = StubViewPort().also { it.model = viewPort1.model; it.find = ::Find }
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort1)
         editor.add(viewPort2)

         editor.find.execute("sample")

         Assert.equal(1, findCalls)
      }
      @Test fun DifferentModelsAllGetSearched() {
         var findCalls: Int = 0
         fun Find(input: String, matchExactCase: Boolean = false): List<IViewPortFindTuple> {
            findCalls  += 1
            return ArrayList<IViewPortFindTuple>()
         }
         var viewPort1 = StubViewPort().also { it.model = SelfEqualStub(); it.find = ::Find }
         var viewPort2 = StubViewPort().also { it.model = SelfEqualStub(); it.find = ::Find }
         var editor = EditorViewModel(StubFileSystem())
         editor.add(viewPort1)
         editor.add(viewPort2)

         editor.find.execute("sample")

         Assert.equal(2, findCalls)
      }
      @Test fun FindText_CloseFind_StopVisuallyFiltering() {
         var editor = EditorViewModel(StubFileSystem())

         editor.showFind.execute(true)
         editor.findText  = "40"
         Assert.equal(0x40, editor.searchBytes!![0])

         editor.showFind.execute(false)
         Assert.isNull(editor.searchBytes)
      }
      @Test fun TryParseBytes_MultipleBytes_Parse() {
         val results = Ref<ByteArray?>(null)
         Assert.isTrue(EditorViewModel.tryParseBytes("12 CD", results))
         Assert.equal(bytes( 0x12, 0xCD), results.value)
      }
      @Test fun ViewPort_FindBytes_EditorSendsBytesToViewPort() {
         var editor = EditorViewModel(StubFileSystem())
         var tab = StubViewPort()

         editor.add(tab)
         editor.showFind.execute(true)
         editor.findText  = "12 CD"

         Assert.equal(bytes( 0x12, 0xCD), tab.findBytes.value)
      }
      @Test fun FindBytes_SwitchTabs_EditorSendsBytesToViewPort() {
         var editor = EditorViewModel(StubFileSystem())
         var tab = StubViewPort()

         editor.showFind.execute(true)
         editor.findText  = "12 CD"
         editor.add(tab)

         Assert.equal(bytes( 0x12, 0xCD), tab.findBytes.value)
      }
      @Test fun SearchText_ContainsWildcard_SearchForMatches() {
         var test = BaseViewModelTestClass()
         arrayCopy(bytes( 0x20, 0x30, 0x40, 0x50), test.Model.rawData, 4)

         var results = test.ViewPort.find("20 30 XX 50")

         Assert.single(results)
         Assert.equal(0, results[0].start)
         Assert.equal(3, results[0].end)
      }
      @Test fun MultipleResults_CloseTogether_CombineTogether() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable("options", 0x100, "abc", "def", "ijk", "lmn", "qrs", "tuv", "xyz")
         test.ViewPort.edit("^table[a::options b:: c:: d::]4 ")
         var editor = EditorViewModel(StubFileSystem(), InstantDispatch.instance)
         editor.add(test.ViewPort)

         editor.find.execute("\"abc\"")

         var results = ((editor[1]) as SearchResultsViewPort)
         Assert.equal(5, results.resultCount)
         Assert.equal(2, results.childViewCount)
         Assert.inRange(results.maximumScroll, 5, 12)
      }
      fun Text_SearchTerm_Find(text: String, searchTerm: String) {
         var test = BaseViewModelTestClass()
         var bytes = PCSString.convert(text)!!.toTypedArray()
         arrayCopy(bytes.toByteArr(), test.Model.rawData, bytes.size)

         var results = test.ViewPort.find(searchTerm)

         Assert.single(results)
      }
    @Test fun Text_SearchTerm_Find_1() { Text_SearchTerm_Find("POK\u00E9BALL", "POK\u00E9BALL") }
    @Test fun Text_SearchTerm_Find_2() { Text_SearchTerm_Find("POK\u00E9BALL", "POKeBALL") }
    @Test fun Text_SearchTerm_Find_3() { Text_SearchTerm_Find("POKeBALL", "POK\u00E9BALL") }
    @Test fun Text_SearchTerm_Find_4() { Text_SearchTerm_Find("POKeBALL", "POKeBALL") }
      @Test fun MatchCaseTurnedOn_FindText_OnlyFindsText() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable("names", 0x100, "ELEMENT", "element");        // insert at 0x100
         test.CreateEnumTable("enums", 0, "names", 0, 1);                   // insert element we should miss at 0 and 1
         PCSString.convert("ELEMENT")!!.writeInto(test.Model.rawData, 0x180); // insert unformatted text at 0x180

         var results = test.ViewPort.find("ELEMENT", matchExactCase = true).map({ pair -> pair.start }).toTypedArray()

         Assert.equal(arrayOf( 0x100, 0x180), results)
      }
      @Test fun MultipleTabs_Find_ResultCountIsAccurate() {
         var editor = EditorViewModel(StubFileSystem(), InstantDispatch.instance)
         editor.add(Create("file1.gba", 2, 20))
         editor.add(Create("file2.gba", 4, 40))

         editor.find.execute("00 01 00")

         Assert.isTrue(editor.showMessage)
         Assert.contains("4", editor.informationMessage)
      }
      @Test fun Word_Find_Found() {
         var test = BaseViewModelTestClass()
         test.Model.writeMultiByteValue(0x10, 4, test.Token, 0x12345678)

         var results = test.ViewPort.find("12345678").map({ result -> result.start })

         Assert.single(results, 0x10)
      }
      @Test fun ExtraWhitespace_Find_IgnoreWhitespace() {
         var test = BaseViewModelTestClass()
         test.Model.writePointer(test.Token, 0x10, 0x123456)

         var results = test.ViewPort.find(" 123456 ").map({ result -> result.start })

         Assert.single(results, 0x10)
      }
      @Test fun ThreeF_ParseBytes_NoMatch() {
         Assert.isFalse(EditorViewModel.tryParseBytes("FF F", Ref(nullOf())))
      }
      @Test fun SearchBytes_MatchPartiallyOffscreen_NoError() {
         var test = BaseViewModelTestClass()
         test.ViewPort.findBytes  = bytes( 0x00, 0x01)
         // no crash -> pass
      }

      private fun Create(name: String, vararg changeAddresses: Int): ViewPort {
         var metadata = StoredMetadata(emptyArray<String>())
         var singletons = BaseViewModelTestClass.Singletons
         var vp = ViewPort(name, PokemonModel(ByteArray(0x200), metadata, singletons), InstantDispatch.instance, singletons)
         for (i in changeAddresses) vp.model[i]  = 1
         return vp
      }

      private fun SelfEqualStub(): IDataModel {
         // the original used an auto-generated stub whose Equals was reference-equality; BasicModel already has that behavior.
         return BasicModel(ByteArray(0x10))
      }
   }
