@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

typealias Span = SortedSpan<Int>

   open class SortedSpanTests {
      @Test fun Empty_IsEmpty() {
         Assert.empty(Span.none<Int>())
      }
      @Test fun Empty_AddOne_HasOne() {
         Assert.single(Span.none<Int>().add1(1))
      }
      @Test fun One_AddDifferent_Two() {
         Assert.equal(2, Span(1).add1(2).size)
      }
      @Test fun One_AddSame_One() {
         Assert.single(Span(1).add1(1))
      }
      @Test fun Many_AddOthers_Sorted() {
         var set1 = Span(listOf( 1,3,5))
         var set2 = Span(listOf( 2, 3, 4))
         var result = set1.add(set2)

         Assert.equal(arrayOf( 1, 2, 3, 4, 5), result)
      }
   }
