@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class TilemapTableTests : BaseViewModelTestClass() {
      init {
         SetFullModel(0xFF)

         // setup palette, tileset, and tilemap data
         ViewPort.edit("@80!00(32) ^pal`ucp4`")
         ViewPort.edit("@C0!lz(128) ^tileset`lzt4|pal`")
         ViewPort.edit("@180!lz(32) ^tilemap`lzm4x4x4|tileset`")
         ViewPort.goto!!.execute(0)
      }
      @Test fun Tilemap_CreateTable_RunExists() {
         ViewPort.edit("^table[value.]tilemap ")

         var table = Model.getTable("table")
         Assert.isType<TilemapTableRun>(table)
         Assert.equal(4, table!!.elementLength)
         Assert.equal(4, table!!.elementCount)
         Assert.equal(4, table!!.elementContent.size)
         Assert.equal("[value.]tilemap", table!!.formatString)
      }
      @Test fun TilemapTable_NegativeWidthMargins_WidthReduced() {
         ViewPort.edit("^table[value.]tilemap-1-0-1-0 ")

         var table = Model.getTable("table")
         Assert.equal(2, table!!.elementLength)
         Assert.equal(4, table!!.elementCount)
         Assert.equal(2, table!!.elementContent.size)
         Assert.equal("[value.]tilemap-1+0-1+0", table!!.formatString)
      }
      @Test fun TilemapTable_NegativeHeightMargins_HeightReduced() {
         ViewPort.edit("^table[value.]tilemap-0-1-0-1 ")

         var table = Model.getTable("table")
         Assert.equal(4, table!!.elementLength)
         Assert.equal(2, table!!.elementCount)
         Assert.equal(4, table!!.elementContent.size)
         Assert.equal("[value.]tilemap+0-1+0-1", table!!.formatString)
      }
      @Test fun TilemapTable_CheckDataFormat_IsSpriteDecorator() {
         ViewPort.edit("^table[value.]tilemap ")

         var anchor = ((ViewPort[0, 0].format) as Anchor)
         var format = (anchor.originalFormat as SpriteDecorator)
         Assert.equal(4, format.cellWidth)
         Assert.equal(4, format.cellHeight)
         Assert.equal(4 * 8, format.pixels.pixelWidth)
         Assert.equal(4 * 8, format.pixels.pixelHeight)
      }
      @Test fun FormatWithLengthMultiplier_Parse_LargerTable() {
         ViewPort.edit("^table[value.]tilemap*2-0-1-0-1 ")
         ViewPort.width  = 4

         var table = Model.getTable("table")
         Assert.equal(4, table!!.elementContent.size)
         Assert.equal(4, table!!.elementCount)
         Assert.equal("[value.]tilemap*2+0-1+0-1", table!!.formatString)
      }
   }
