@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ArrayRunTests : BaseViewModelTestClass() {
      @Test fun CanParseStringArrayRun() {
         var model = PokemonModel(ByteArray(0x200))
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[name\"\"10]13", 12, null, arrayRun)

         Assert.equal(12, arrayRun.value!!.start)
         Assert.equal(130, arrayRun.value!!.length)
         Assert.equal(13, arrayRun.value!!.elementCount)
         Assert.equal(1, arrayRun.value!!.elementContent.size)
         Assert.equal("name", arrayRun.value!!.elementContent[0].name)
         Assert.equal(ElementContentType.PCS, arrayRun.value!!.elementContent[0].type)
         Assert.equal(10, arrayRun.value!!.elementContent[0].length)
      }
      @Test fun ArrayElementsMustHaveNames() {
         var model = PokemonModel(ByteArray(0x200))
         var errorInfo = ArrayRun.tryParse(model, "[\"\"10]13", 12, null, Ref(nullOf())); // no name given for the format member

         Assert.notEqual(ErrorInfo.noError, errorInfo)
      }
      @Test fun CanParseMultiStringArrayRun() {
         var model = PokemonModel(ByteArray(0x200))
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[name\"\"10 detail\"\"12]13", 20, null, arrayRun)

         Assert.equal(20, arrayRun.value!!.start)
         Assert.equal((10 + 12) * 13, arrayRun.value!!.length)
         Assert.equal(13, arrayRun.value!!.elementCount)
         Assert.equal(2, arrayRun.value!!.elementContent.size)
         Assert.equal("name", arrayRun.value!!.elementContent[0].name)
         Assert.equal("detail", arrayRun.value!!.elementContent[1].name)
         Assert.equal(ElementContentType.PCS, arrayRun.value!!.elementContent[0].type)
         Assert.equal(ElementContentType.PCS, arrayRun.value!!.elementContent[1].type)
         Assert.equal(10, arrayRun.value!!.elementContent[0].length)
         Assert.equal(12, arrayRun.value!!.elementContent[1].length)
      }
      @Test fun ViewModelArrayRunAppearsLikeABunchOfStrings() {
         SetFullModel(0xFF)
         ViewPort.preferredWidth  = -1
         ViewPort.width  = 12
         ViewPort.height  = 20
         val (model, viewPort) = Pair(Model, ViewPort)
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[name\"\"12]13", 12, null, arrayRun)
         model.observeAnchorWritten(ModelDelta(), "table", arrayRun.value!!)

         // spot checks: it should look like a string that starts where the segment starts
         var pcs = ((viewPort[0, 4].format) as PCS)
         Assert.equal(0, pcs.position)
         Assert.equal(4 * 12, pcs.source)

         pcs  = ((viewPort[6, 6].format) as PCS)
         Assert.equal(6, pcs.position)
         Assert.equal(6 * 12, pcs.source)

         // typing a " should close the current string, 0 out the rest of this segment, and move to the next segment
         viewPort.selectionStart  = Point(6, 6)
         viewPort.edit("\"")
         pcs  = ((viewPort[7, 6].format) as PCS)
         Assert.equal(" ", pcs.thisCharacter)
         Assert.equal(Point(0, 7), viewPort.selectionStart)

         // typing Enter should move to the start of the same segment in the next element
         viewPort.edit(ConsoleKey.Enter)
         Assert.equal(Point(0, 8), viewPort.selectionStart)

         // typing Tab should move to the start of the next segment
         viewPort.edit(ConsoleKey.Tab)
         Assert.equal(Point(0, 9), viewPort.selectionStart)
      }
      @Test fun CanParseArrayAnchorAddedFromViewPort() {
         ViewPort.edit("^bob[name\"\"14]12 ")

         Assert.isType<ArrayRun>(Model.getNextRun(0))
      }
      @Test fun ChangingAnchorTextWhileAnchorStartIsOutOfViewWorks() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^bob[name\"\"16]16 ")

         viewPort.scrollValue  = 2
         viewPort.anchorText  = "^bob[name\"\"16]18"

         Assert.equal(16 * 18, model.getNextRun(0).length)
      }
      @Test fun CanAutoFindArrayLength() {
         WriteStrings(Model.rawData, 0x00, "bob", "tom", "sam", "car", "pal", "egg")
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^words[word\"\"4] "); // notice, no length is given

         var run = (model.getNextRun(0) as ArrayRun)
         Assert.equal(6, run.elementCount)
      }
      @Test fun WidthRestrictedAfterGotoArrayAnchor() {
         WriteStrings(Model.rawData, 100, "bobb", "tomm", "samm", "carr", "pall", "eggg")

         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^words[word\"\"5] "); // notice, no length is given

         viewPort.goto!!.execute("words")
         Assert.equal(0, viewPort.width % 5)
      }
      @Test fun CanCopyArray() {
         WriteStrings(Model.rawData, 0, "bobb", "tomm", "samm", "carr", "pall", "eggg")
         var delta = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[word\"\"5]", 0, null, arrayRun)
         model.observeAnchorWritten(delta, "words", arrayRun.value!!)

         var text = model.copy({ delta }, 0, 0x20)

         Assert.contains("^words[word\"\"5]", text)
      }
      @Test fun CanEditArray() {
         WriteStrings(Model.rawData, 0, "bobb", "tomm", "samm", "carr", "pall", "eggg")

         val (model, viewPort) = Pair(Model, ViewPort)
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[word\"\"5]", 0, null, arrayRun)
         model.observeAnchorWritten(ModelDelta(), "words", arrayRun.value!!)
         viewPort.selectionStart  = Point(6, 0)

         viewPort.edit("a"); // change "tomm" to "tamm"

         Assert.equal("a", (((viewPort[6, 0].format) as PCS)).thisCharacter)
      }
      @Test fun CanPasteArray() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^strings[name\"\"16] ")
         viewPort.edit("+\"bob\" +\"sam\" +\"steve\" +\"kevin\"")

         Assert.equal(0x40, model.getNextRun(0).length)
         Assert.equal("\"", (((viewPort[3, 0].format) as PCS)).thisCharacter)
      }
      @Test fun PastingArrayLeavesArrayFormat() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^${HardcodeTablesModel.pokemonNameTable}[name\"\"11] +\"??????????\"+\"BULBASAUR\"")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.followLink(0, 0)

         Assert.equal("^${HardcodeTablesModel.pokemonNameTable}[name\"\"11]2", viewPort.anchorText); // you don't need a length to make one, but a length gets automatically added.
         Assert.equal("BULBASAUR", viewPort.tools!!.stringTool!!.content.split("\n").last())
      }
      @Test fun ArrayIsRecognizedByStringTool() {
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         WriteStrings(model.rawData, 100, "bobb", "tomm", "samm", "carr", "pall", "eggg")

         model.writePointer(changeToken, 200, 100)
         model.observeRunWritten(changeToken, PointerRun(200))

         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[word\"\"5]", 100, null, arrayRun)
         model.observeAnchorWritten(ModelDelta(), "words", arrayRun.value!!)

         viewPort.followLink(0, 7); // 7*16 = 112, right in the middle of our data
         // note that this will change our width to 15, because we're linking to data of width 5 when our maxwidth is 16.

         Assert.equal(viewPort.tools!!.indexOf(viewPort.tools!!.stringTool), viewPort.tools!!.selectedIndex); // string tool is selected
         Assert.equal(100, viewPort.tools!!.stringTool!!.address)
         var lineCount = viewPort.tools!!.stringTool!!.content.split("\n").size
         Assert.equal(6, lineCount)

         viewPort.tools!!.stringTool!!.contentIndex  = viewPort.tools!!.stringTool!!.content.indexOf("pall")
         Assert.equal(Point(120 % 16, 120 / 16), viewPort.selectionStart)
      }
      @Test fun EditingStringToolEditsArray() {
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         WriteStrings(model.rawData, 100, "bobb", "tomm", "samm", "carr", "pall", "eggg")

         model.writePointer(changeToken, 200, 100)
         model.observeRunWritten(changeToken, PointerRun(200))

         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[word\"\"5]", 100, null, arrayRun)
         model.observeAnchorWritten(ModelDelta(), "words", arrayRun.value!!)

         viewPort.followLink(0, 7); // 7*16 = 112, right in the middle of our data

         var writer = StringBuilder()
         writer.appendLine(viewPort.tools!!.stringTool!!.content)
         writer.append("carl")
         viewPort.tools!!.stringTool!!.content  = writer.toString()

         Assert.equal(7 * 5, model.getNextRun(100).length)
      }
      @Test fun CanCutPasteArrayToFreeSpace() {
         // arrange
         var delta = ModelDelta()
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         ViewPort.edit("<020> ")
         var elements = arrayOf( "123", "alice", "candy land", "hello world", "fortify")
         CreateTextTable("testdata", 0x20, *elements)
         viewPort.goto!!.execute(0)

         // act -> cut
         var fileSystem = StubFileSystem()
         viewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0x20)
         viewPort.moveSelectionEnd.execute(Direction.End); // select entire table
         viewPort.copy!!.execute(fileSystem)
         viewPort.clear!!.execute()
         var text: String = fileSystem.copyText!!

         // act -> paste
         viewPort.selectionStart  = Point(0, 8)
         viewPort.edit(text)

         // assert -> pointer moved
         var destination = model.readPointer(0x00)
         Assert.equal(0x80, destination)

         // assert -> anchor moved
         var run = model.getNextRun(0x10)
         Assert.equal(0x80, run.start)
         Assert.equal("testdata", model.getAnchorFromAddress(-1, run.start))
         Assert.equal(5, ((run as ArrayRun)).elementCount)
         var lines = viewPort.tools!!.stringTool!!.content.split("\n")
         Assert.all(elements, { element -> Assert.contains(element, lines) })

         // assert -> nothing left behind
         Assert.all(Enumerable.Range(0x20, 0x50), { i -> Assert.equal(0xFF, model[i]) })
      }
      @Test fun CannotCutPasteArrayToMakeItHitAnotherAnchor() {
         // arrange
         var delta = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         var errors = ArrayList<String>()
         var elements = arrayOf( "123", "alice", "candy land", "hello world", "fortify")
         for (i in 0 until elements.size) {
            var content = PCSString.convert(elements[i])
            while (content!!.size < 0x10) content!!.add(0x00)
            arrayCopy(content!!.toTypedArray(), 0, model.rawData, 0x10 * i + 0x20, 0x10)
         }
         model.writePointer(delta, 0x00, 0x20)
         model.observeRunWritten(delta, PointerRun(0x00))
         model.writePointer(delta, 0x04, 0x90)
         model.observeRunWritten(delta, PointerRun(0x04)); // the anchor at 0x90 should prevent a paste overwrite
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^testdata[name\"\"16]5 ")
         viewPort.goto!!.execute("000000")
         viewPort.onError  += { sender, message -> errors.add(message) }

         // act -> cut
         var fileSystem = StubFileSystem()
         viewPort.selectionStart  = Point(0, 2)
         viewPort.selectionEnd  = Point(0xF, 6); // select all 5 elements
         viewPort.copy!!.execute(fileSystem)
         viewPort.clear!!.execute()
         var text: String = fileSystem.copyText!!

         // act -> paste
         viewPort.selectionStart  = Point(0, 8)
         viewPort.edit(text)

         // assert: could not paste
         Assert.single(errors)
      }
      @Test fun CanCutPasteArrayOverItself() {
         // arrange
         var delta = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         var errors = ArrayList<String>()
         var elements = arrayOf( "123", "alice", "candy land", "hello world", "fortify")
         for (i in 0 until elements.size) {
            var content = PCSString.convert(elements[i])
            while (content!!.size < 0x10) content!!.add(0x00)
            arrayCopy(content!!.toTypedArray(), 0, model.rawData, 0x10 * i + 0x20, 0x10)
         }
         model.writePointer(delta, 0x00, 0x20)
         model.observeRunWritten(delta, PointerRun(0x00))
         model.writePointer(delta, 0x04, 0x90)
         model.observeRunWritten(delta, PointerRun(0x04)); // the anchor at 0x90 should prevent a paste overwrite
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^testdata[name\"\"16]5 ")
         viewPort.goto!!.execute("000000")
         viewPort.onError  += { sender, message -> errors.add(message) }

         // act -> cut
         var fileSystem = StubFileSystem()
         viewPort.selectionStart  = Point(0, 2)
         viewPort.selectionEnd  = Point(0xF, 6); // select all 5 elements
         viewPort.copy!!.execute(fileSystem)
         viewPort.clear!!.execute()
         var text: String = fileSystem.copyText!!

         // act -> paste
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit(text)

         // assert: no errors
         Assert.empty(errors)
         Assert.equal("testdata", model.getAnchorFromAddress(-1, 0x20))
      }
      @Test fun AddingToAnArrayWithFixedLengthUpdatesTheAnchorFormat() {
         // arrange
         val (model, viewPort) = Pair(Model, ViewPort)
         var delta = ModelDelta()
         var errors = ArrayList<String>()
         var elements = arrayOf( "123", "alice", "candy land", "hello world", "fortify")
         for (i in 0 until elements.size) {
            var content = PCSString.convert(elements[i])
            while (content!!.size < 0x10) content!!.add(0x00)
            arrayCopy(content!!.toTypedArray(), 0, model.rawData, 0x10 * i + 0x20, 0x10)
         }
         model.writePointer(delta, 0x00, 0x20)
         model.observeRunWritten(delta, PointerRun(0x00))
         model.writePointer(delta, 0x04, 0x90)
         model.observeRunWritten(delta, PointerRun(0x04)); // the anchor at 0x90 should prevent a paste overwrite
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^testdata[name\"\"16]5 ")
         viewPort.goto!!.execute("000000")
         viewPort.onError  += { sender, message -> errors.add(message) }

         // act -> add an element
         viewPort.selectionStart  = Point(0, 7)
         viewPort.edit("+\"crab\"")

         // assert -> length changed
         viewPort.selectionStart  = Point(0, 2)
         Assert.isTrue(viewPort.anchorTextVisible)
         Assert.equal("^testdata[name\"\"16]6", viewPort.anchorText)
      }
      @Test fun ArarysSupportIntegers() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^sample[initials\"\"5 age. shoeSize: extension. zip:. flog::]16 ")

         Assert.empty(Errors)
         Assert.equal(0x100, model.getNextRun(0).length)
      }
      @Test fun ArrayExtendsIfBasedOnAnotherNameWhichIsExtended() {
         val (model, viewPort) = Pair(Model, ViewPort)
         var errors = ArrayList<String>()
         viewPort.onError  += { sender, e -> errors.add(e) }

         viewPort.edit("^sample[name\"\"8]8 "); // should cover the first 4 lines

         viewPort.selectionStart  = Point(0, 8)
         viewPort.edit("^derived[index.]sample "); // should be the same length as sample: 8
         viewPort.goto!!.execute("000000")

         // test 1: enbiggen derived should enbiggen sample
         viewPort.selectionStart  = Point(8, 8)
         viewPort.edit("+")
         Assert.equal(8 * 9, model.getNextRun(0).length)

         // test 2: enbiggen sample should enbiggen derived
         viewPort.selectionStart  = Point(8, 4)
         viewPort.edit("+")
         Assert.equal(1 * 10, model.getNextRun(0x80).length)
      }
      @Test fun CanEditIntsInArray() {
         val (model, viewPort) = Pair(Model, ViewPort)
         viewPort.edit("^sample[code:]8 ")

         viewPort.edit("1 20 300 4000 50000 6000000 ")

         Assert.equal(Point(12, 0), viewPort.selectionStart)
         Assert.single(Errors); // should've gotten one error for the 6 digit number
         Assert.equal(1, model[5])
      }
      @Test fun ArraysSupportPointers() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^characters[name\"\"8 age. gender. weight: catchphrase<>]16 ")

         Assert.empty(Errors)
         Assert.equal(0x100, model.getNextRun(0).length)
      }
      @Test fun CanEditPointersInArrays() {
         val (model, viewPort) = Pair(Model, ViewPort)
         viewPort.edit("^sample[name<>]8 ")

         viewPort.edit("<000100> <110> <000120>")

         Assert.equal(0x20, model.getNextRun(0).length); // 4 bytes per pointer * 8 pointers = 8*4 = x10*2 = x20 bytes
         Assert.equal(Point(0xC, 0), viewPort.selectionStart)
         Assert.empty(Errors)
         Assert.equal(0x120, model.readPointer(0x8))
      }
      @Test fun ArraysWithInnerAnchorsRenderAnchors() {
         val (model, viewport) = Pair(Model, ViewPort)
         var changeToken = ModelDelta()

         // arrange: setup data with a bunch of pointers pointing into an array of strings
         model.writePointer(changeToken, 0x00, 0x80)
         model.observeRunWritten(changeToken, PointerRun(0x00))
         model.writePointer(changeToken, 0x08, 0x84)
         model.observeRunWritten(changeToken, PointerRun(0x08))
         model.writePointer(changeToken, 0x10, 0x88)
         model.observeRunWritten(changeToken, PointerRun(0x10))
         model.writePointer(changeToken, 0x18, 0x8C)
         model.observeRunWritten(changeToken, PointerRun(0x18))

         // arrange: setup the array of strings
         WriteStrings(model.rawData, 0x80, "cat", "bat", "hat", "sat")
         var existingAnchor = model.getNextAnchor(0x80)
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x80, existingAnchor.pointerSources, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // arrange: create the viewmodel
         viewport.refresh()

         // assert: viewmodel renders anchors within the array
         // note that the strings are only 4 bytes long
         Assert.isType<Anchor>(viewport[0, 8].format)
         Assert.isType<Anchor>(viewport[4, 8].format)
         Assert.isType<Anchor>(viewport[8, 8].format)
         Assert.isType<Anchor>(viewport[12, 8].format)
         Assert.isNotType<Anchor>(viewport[0, 9].format)

         // assert: viewmodel renders pointers with names into the array
         Assert.equal("sample", (((viewport[0, 0].format) as Pointer)).destinationName)
         Assert.equal("sample/1", (((viewport[8, 0].format) as Pointer)).destinationName)
         Assert.equal("sample/2", (((viewport[0, 1].format) as Pointer)).destinationName)
         Assert.equal("sample/3", (((viewport[8, 1].format) as Pointer)).destinationName)
      }
      @Test fun CanGotoIndexInArray() {
         val (model, viewport) = Pair(Model, ViewPort)
         var changeToken = ModelDelta()

         // arrange: setup the array of strings
         WriteStrings(model.rawData, 0x80, "cat", "bat", "hat", "sat")
         var existingAnchor = model.getNextAnchor(0x80)
         val arrayRun = Ref<ITableRun?>(null)
         var error = ArrayRun.tryParse(model, "[name\"\"4]4", 0x80, existingAnchor.pointerSources, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         viewport.goto!!.execute("sample/2")

         Assert.empty(Errors)
      }
      @Test fun CanRemovePointerToWithinArray() {
         var data = ByteArray(0x200)
         var changeToken = ModelDelta()

         // arrange: setup data with a bunch of pointers pointing into an array of strings
         var model = PokemonModel(data)
         model.writePointer(changeToken, 0x00, 0x80)
         model.observeRunWritten(changeToken, PointerRun(0x00))
         model.writePointer(changeToken, 0x08, 0x84)
         model.observeRunWritten(changeToken, PointerRun(0x08))
         model.writePointer(changeToken, 0x10, 0x88)
         model.observeRunWritten(changeToken, PointerRun(0x10))
         model.writePointer(changeToken, 0x18, 0x8C)
         model.observeRunWritten(changeToken, PointerRun(0x18))

         // arrange: setup the array of strings
         WriteStrings(data, 0x80, "cat", "bat", "hat", "sat")
         var existingAnchor = model.getNextAnchor(0x80)
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x80, existingAnchor.pointerSources, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // act: clear the pointer
         model.clearFormat(changeToken, 0x08, 4)

         // assert: array doesn't have pointer anymore
         var array = (model.getNextAnchor(0x80) as ArrayRun)
         Assert.empty(array.pointerSourcesForInnerElements!![1])
      }
      @Test fun CanCreateArraySupportingInnerAnchorsFromViewModel() {
         val (model, viewport) = Pair(Model, ViewPort)

         viewport.edit("^array^[content\"\"16]16 ")
         var run = (model.getNextRun(0) as ArrayRun)

         Assert.startsWith("^", run.formatString)
      }
      @Test fun CanCreateNewPointerUsingArrayNameAndIndex() {
         val (model, viewport) = Pair(Model, ViewPort)

         viewport.edit("^array^[content\"\"8]8 ")

         viewport.selectionStart  = Point(0, 6)
         viewport.edit("<array/3>")

         var run = (model.getNextRun(0) as ArrayRun)
         Assert.single(run.pointerSourcesForInnerElements!![3])
      }
      @Test fun ArraysSupportEnums() {
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "hat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // arrange: setup the anchor with the data
         ArrayRun.tryParse(model, "[option:sample]4", 0x40, null, arrayRun)
         model.observeAnchorWritten(changeToken, "data", arrayRun.value!!)

         changeToken.changeData(model, 0x42, 2)

         // act: see that the arrayRun can parse according to the enum
         arrayRun.value  = (model.getNextRun(0x40) as ArrayRun)
         Assert.equal("cat", arrayRun.value!!.elementContent[0].toText(model, 0x40))
         Assert.equal("hat", arrayRun.value!!.elementContent[0].toText(model, 0x42))

         viewPort.refresh()
         var enumViewModel = ((((viewPort[0, 4].format) as Anchor)).originalFormat as IntegerEnum)
         Assert.equal("cat", enumViewModel.valueNew)
      }
      @Test fun ArraysSupportEditingEnums() {
         Model[0x42]  = 2; // hat
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "hat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // arrange: setup the anchor with the data
         ArrayRun.tryParse(model, "[option.sample]4", 0x40, null, arrayRun)
         model.observeAnchorWritten(changeToken, "data", arrayRun.value!!)

         // act: use a viewmodel to change 0x41 to 'bat'
         ViewPort.refresh()
         viewPort.selectionStart  = Point(1, 4); // select space 0x41
         viewPort.edit("bat ")

         Assert.equal(1, Model[0x41])
      }
      @Test fun ViewModelReturnsErrorWhenEnumIsNotValidValue() {
         Model[0x42]  = 2; // hat
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "hat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         var error = ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // arrange: setup the anchor with the data
         error  = ArrayRun.tryParse(model, "[option.sample]4", 0x40, null, arrayRun)
         model.observeAnchorWritten(changeToken, "data", arrayRun.value!!)

         // act: use a viewmodel to try to change 41 to 'pat' (invalid)
         ViewPort.refresh()
         viewPort.selectionStart  = Point(1, 4); // select space 0x41
         var errors = ArrayList<String>()
         viewPort.onError  += { sender, e -> errors.add(e) }

         viewPort.edit("pat ")
         Assert.single(errors)
      }
      @Test fun MultipleEnumValuesWithSameContentAreDistinguishable() {
         Model[0x42]  = 2; // bat~2
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "bat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // arrange: setup the anchor with the data
         ArrayRun.tryParse(model, "[option.sample]4", 0x40, null, arrayRun)
         model.observeAnchorWritten(changeToken, "data", arrayRun.value!!)

         // act: setup a viewmodel
         ViewPort.refresh()

         // assert: viewmodel should render bat~2 at 0x42
         var format = ((viewPort[2, 4].format) as IntegerEnum)
         Assert.equal("bat~2", format.valueNew)
      }
      @Test fun CanEditToSecondEnumWithSameContent() {
         Model[0x42]  = 3; // sat
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "bat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // arrange: setup the anchor with the data
         ArrayRun.tryParse(model, "[option.sample]4", 0x40, null, arrayRun)
         model.observeAnchorWritten(changeToken, "data", arrayRun.value!!)

         // act: setup a viewmodel and change 0x41 to bat~2
         ViewPort.refresh()
         viewPort.selectionStart  = Point(1, 4); // select space 0x41
         viewPort.edit("bat~2 ")

         // assert: viewmodel should render bat~2 at 0x42
         Assert.equal(2, model.rawData[0x41])
      }
      @Test fun EditingWithTableToolUpdatesMainContent() {
         Model[0x42]  = 3; // sat
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "bat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         var error = ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // act: setup a viewmodel and show table tool
         ViewPort.refresh()
         viewPort.tools!!.selectedIndex  = 1

         // act: change the table contents
         viewPort.selectionStart  = Point(1, 0)
         var element = ((viewPort.tools!!.tableTool!!.children.single({ child -> child  is FieldArrayElementViewModel && (child as FieldArrayElementViewModel).name == "name" })) as FieldArrayElementViewModel)
         element.content  = "dog"

         // assert: main view was updated
         Assert.equal("o", (((viewPort[1, 0].format) as PCS)).thisCharacter)
      }
      @Test fun EditingMainContentUpdatesTableTool() {
         Model[0x42]  = 3; // sat
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "bat", "sat")
         val arrayRun = Ref<ITableRun?>(null)
         var error = ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, arrayRun)
         model.observeAnchorWritten(changeToken, "sample", arrayRun.value!!)

         // act: setup a viewmodel and show table tool
         ViewPort.refresh()
         viewPort.tools!!.selectedIndex  = 1

         // act: change the table contents
         viewPort.selectionStart  = Point(1, 0)
         viewPort.edit("u")

         // assert: main view was updated
         var element = ((viewPort.tools!!.tableTool!!.children.single({ child -> child  is FieldArrayElementViewModel && (child as FieldArrayElementViewModel).name == "name" })) as FieldArrayElementViewModel)
         Assert.equal("cut", element.content)
      }
      @Test fun CustomHeadersWork() {
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)

         // arrange: setup the anchor used for the enums
         WriteStrings(model.rawData, 0x00, "cat", "bat", "bat", "sat")
         val parentArray = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[name\"\"4]4", 0x00, null, parentArray)
         model.observeAnchorWritten(changeToken, "parent", parentArray.value!!)
         val childArray = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[a:: b:: c:: d::]parent", 0x20, null, childArray)
         model.observeAnchorWritten(changeToken, "child", childArray.value!!)
         ViewPort.refresh()

         // act/assert: check that the headers are the names when custom headers are turned on
         viewPort.useCustomHeaders  = true
         Assert.equal("cat", viewPort.headers!![2])

         // act/assert: check that the headers are normal when custom headers are turned off
         viewPort.useCustomHeaders  = false
         Assert.equal("000020", viewPort.headers!![2])
      }
      @Test fun CanAddTextFormatToAnchorUsedOnlyByAnArrayAtStart() {
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         WriteStrings(model.rawData, 0x10, "This is a song!")
         val array = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[content<>]1", 0x00, null, array)
         model.writePointer(changeToken, 0x00, 0x10)
         model.observeAnchorWritten(changeToken, "array", array.value!!)

         // there is a pointer at 0x00 that points to 0x10
         // but we know about it via an array
         // at 0x10 is text
         // but we don't know that it's text
         ViewPort.refresh()
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^\"\" ")

         // adding the format should've stuck
         Assert.empty(Errors)
         Assert.isType<PCS>(viewPort[1, 1].format)
      }
      @Test fun CanAddTextFormatToAnchorUsedOnlyByAnArray() {
         var changeToken = ModelDelta()
         val (model, viewPort) = Pair(Model, ViewPort)
         WriteStrings(model.rawData, 0x10, "This is a song!")
         val array = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "^[content<>]4", 0x00, null, array)
         model.writePointer(changeToken, 0x04, 0x10)
         model.observeAnchorWritten(changeToken, "array", array.value!!)

         // there is a pointer at 0x00 that points to 0x10
         // but we know about it via an array
         // at 0x10 is text
         // but we don't know that it's text
         ViewPort.refresh()
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^\"\" ")

         // adding the format should've stuck
         Assert.empty(Errors)
         Assert.isType<PCS>(viewPort[1, 1].format)
      }
      @Test fun EditingMultibyteTableEntryMovesEditToFirstByte() {
         // Arrange
         val (model, viewPort) = Pair(Model, ViewPort)
         viewPort.edit("^names[name\"\"8]8 \"bob\" \"sam\" \"john\" \"mike\" \"tommy\"")
         viewPort.selectionStart  = Point(0, 5)
         viewPort.edit("^table[a: b:names]8 "); // note that making a table like this does an automatic goto for the table

         // Act: try to edit a
         viewPort.selectionStart  = Point(1, 0)
         viewPort.edit("3")

         // Assert: selection moved
         Assert.isTrue(viewPort.isSelected(Point(0, 0)))
         Assert.isType<UnderEdit>(viewPort[0, 0].format)

         // Act: try to edit b
         viewPort.selectionStart  = Point(3, 0)
         viewPort.edit("john")

         // Assert: selection moved
         Assert.isTrue(viewPort.isSelected(Point(2, 0)))
         Assert.isType<UnderEdit>(viewPort[2, 0].format)
      }
      @Test fun CanBackspaceEnum() {
         // Arrange
         val (model, viewPort) = Pair(Model, ViewPort)
         model[0x51]  = 3; // 'john'
         viewPort.edit("^names[name\"\"8]8 \"bob\" \"sam\" \"john\" \"mike\" \"tommy\"")
         viewPort.selectionStart  = Point(0, 5)
         viewPort.edit("^table[a:names b:]8 "); // note that making a table like this does an automatic goto for the table

         // Act: try to backspace the a enum
         viewPort.selectionStart  = Point(2, 1); // just to the left of "john"
         viewPort.edit(ConsoleKey.Backspace)
         viewPort.edit(ConsoleKey.Backspace)
         viewPort.edit(ConsoleKey.Backspace)
         viewPort.edit(ConsoleKey.Backspace)
         viewPort.edit(ConsoleKey.Backspace)

         Assert.equal("bob", (((viewPort[0, 1].format) as IntegerEnum)).valueNew)
         Assert.isTrue(viewPort.isSelected(Point(0xF, 0))); // selection has moved to last row
         Assert.isTrue(viewPort.isSelected(Point(0xE, 0))) // two selected bytes, since the previous entry is 2 bytes long
      }
      @Test fun CanBackspaceInt() {
         // Arrange
         val (model, viewPort) = Pair(Model, ViewPort)
         model[0x53]  = 9
         viewPort.edit("^names[name\"\"8]8 \"bob\" \"sam\" \"john\" \"mike\" \"tommy\"")
         viewPort.selectionStart  = Point(0, 5)
         viewPort.edit("^table[a:names b:]8 "); // note that making a table like this does an automatic goto for the table

         // Act: try to backspace the a int
         viewPort.selectionStart  = Point(3, 1); // selected "9"
         viewPort.edit(ConsoleKey.Backspace)
         viewPort.edit(ConsoleKey.Backspace)

         Assert.equal(0, (((viewPort[2, 1].format) as Integer)).value)
         Assert.isTrue(viewPort.isSelected(Point(0, 1))); // selection has moved to previous element
         Assert.isTrue(viewPort.isSelected(Point(1, 1))) // two selected bytes, since the previous entry is 2 bytes long
      }
      @Test fun ArrayLengthUpdatesWhenSourceTableLengthChanges() {
         // Arrange
         var data = ByteArray(0x200)
         var model = PokemonModel(data)

         val table = Ref<ITableRun?>(null)
         // Act
         ArrayRun.tryParse(model, "[a: b:]names", 0, null, table)
         model.observeAnchorWritten(ModelDelta(), "table", table.value!!)
         val names = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[name\"\"8]8", 0x30, null, names)
         model.observeAnchorWritten(ModelDelta(), "names", names.value!!)

         // Assert that the table is now longer based on the names table
         Assert.equal(8 * 4, model.getNextRun(0).length)
      }
      @Test fun ArrayLengthRightClickOptionWhenClickingInLastRow() {
         // Arrange
         val (model, viewPort) = Pair(Model, ViewPort)
         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[a: b:]8", 0, null, table)
         model.observeAnchorWritten(ModelDelta(), "table", table.value!!)
         ViewPort.refresh()

         // Act
         viewPort.selectionStart  = Point(0xD, 1)
         var items = viewPort.getContextMenuItems(viewPort.selectionStart)
         var extendItem = items.single({ item -> item.text!!.contains("Extend Table") })
         extendItem.command.execute()

         // Assert
         Assert.equal(9, ((model.getNextRun(0) as ArrayRun)).elementCount)
      }
      @Test fun ParentTableAutoMoveNotifies() {
         // Arrange
         SetFullModel(0x42)
         val (model, viewPort) = Pair(Model, ViewPort)

         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[a: b:]8", 0x20, null, table); // parent table starts directly after child table
         model.observeAnchorWritten(ModelDelta(), "parent", table.value!!)

         ArrayRun.tryParse(model, "[a: b:]parent", 0x00, null, table)
         model.observeAnchorWritten(ModelDelta(), "child", table.value!!)

         ViewPort.refresh()

         // Act
         viewPort.selectionStart  = Point(0xD, 1)
         viewPort.tools!!.selectedIndex  = viewPort.tools!!.indexOf(viewPort.tools!!.tableTool)
         viewPort.tools!!.tableTool!!.append.execute()

         // Assert
         Assert.equal(0, model.getNextRun(0).start); // the run being edit did not move
         Assert.single(Messages)                    // user was notified about the other move
      }
      @Test fun CanHaveLooseWordRunsReferingToTables() {
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(Ref(nullOf()), model, viewPort)

         viewPort.value.edit("^table[a:: b::]4 "); // 0x20 bytes
         viewPort.value.selectionStart  = Point(0, 5)
         viewPort.value.edit("::table ");                  // should create a new 4-byte run that stays in sync with the table

         var run = model.value.getNextRun(0x50)
         Assert.isType<WordRun>(run)
         Assert.isType<MatchedWord>(viewPort.value[1, 5].format)
         Assert.equal(Point(4, 5), viewPort.value.selectionStart)

         var length = model.value.readValue(0x50)
         Assert.equal(4, length)

         viewPort.value.selectionStart  = Point(0, 2)
         viewPort.value.edit("+");                         // should add a new element to the table

         Assert.equal(5, ((model.value.getNextRun(0) as ArrayRun)).elementCount)
         length  = model.value.readValue(0x50)
         Assert.equal(5, length)
      }
      @Test fun CanRemoveLooseWordRuns() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         viewPort.value.edit("^table[a:: b::]4 "); // 0x20 bytes

         // add the format
         viewPort.value.selectionStart  = Point(0, 5)
         viewPort.value.edit("::table ");                  // should create a new 4-byte run that stays in sync with the table

         // remove the format
         viewPort.value.selectionStart  = Point(0, 5)
         var items = viewPort.value.getContextMenuItems(Point(0, 5))
         var contextItem = items.single({ item -> item.text == "Clear Format" })
         contextItem.command.execute()

         // extend the table
         viewPort.value.selectionStart  = Point(0, 2)
         viewPort.value.edit("+")

         // verify that the table was extended, but the value at 0x50 was NOT (no longer tied together)
         Assert.equal(5, ((model.value.getNextRun(0) as ArrayRun)).elementCount)
         var length = model.value.readValue(0x50)
         Assert.equal(4, length)
      }
      @Test fun CanSaveLooseWordRuns() {
         var fileSystem = StubFileSystem()
         var metadata: Array<String>? = null
         fileSystem.save  = { file -> true }
         fileSystem.saveMetadata  = lm1@{ file, lines -> metadata  = lines!!; return@lm1 true }
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)

         viewPort.value.edit("::test ")
         viewPort.value.save!!.execute(fileSystem)

         var storedMetadata = StoredMetadata(metadata!!)
         var matchedWord = storedMetadata.matchedWords.first()
         Assert.equal(0, matchedWord.address)
         Assert.equal("test", matchedWord.name)
      }
      @Test fun AppendToTableMovesTableIfConflictingWithAnchor() {
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(Ref(nullOf()), model, viewPort)
         viewPort.value.edit("@0 ^table[data:]parent ")
         viewPort.value.edit("@10 ^stuff @20 ^parent[data:]8 ")

         // try to extend table via tool
         viewPort.value.selectionStart  = Point(0xF, 0)
         viewPort.value.tools!!.selectedIndex  = viewPort.value.tools!!.indexOf(viewPort.value.tools!!.tableTool)
         viewPort.value.tools!!.tableTool!!.append.execute()

         // assert that the run moved
         Assert.notEqual(0, model.value.getNextRun(0).start)
      }
      @Test fun PlmPointersMoveWhenPlmTableSourceMoves() {
         var source = BaseViewModelTestClass()
         source.CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x100, *("A B C D E F G".split(' ')).toTypedArray())

         // Arrange: write the data for a table @0 pointing to PLM run @4.
         source.Model.writeMultiByteValue(4, 2, ModelDelta(), 0x0404); // learn E at level 2
         source.Model.writeMultiByteValue(6, 2, ModelDelta(), 0xFFFF); // end of stream
         source.Model.writePointer(ModelDelta(), 0, 4);                // @0 <000004>
         source.ViewPort.goto!!.execute("00")
         source.ViewPort.edit("^${HardcodeTablesModel.levelMovesTableName}[moves<${PLMRun.sharedFormatString}>]1 ")

         // Act: extend the PLM table. Note that this will automatically move it to avoid hitting the data @4.
         source.ViewPort.goto!!.execute("04")
         source.ViewPort.edit("+")

         // Assert: the PLMRun at 04 should not have moved. There should be two things pointing to it, since the extended table got a new pointer.
         var newTableStart = source.Model.getAddressFromAnchor(ModelDelta(), -1, HardcodeTablesModel.levelMovesTableName)
         var plmRun = (source.Model.getNextRun(4) as PLMRun)
         Assert.equal(2, plmRun.pointerSources!!.size)
         Assert.equal(newTableStart, plmRun.pointerSources!![0])
      }
      @Test fun CanExtendTableWithInnerPointers() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("^table^[data\"\"4]3 ")
         test.ViewPort.selectionStart  = Point(0xC, 0)

         test.ViewPort.edit("+")

         Assert.equal(0x10, test.Model.getNextRun(0).length)
      }
      @Test fun ExtendingTableWithLengthMinusOneFromParentOnlyAddsOneElement() {
         var data = ByteArray(0x200)
         var model = PokemonModel(data)
         var token = ModelDelta()

         val parent = Ref<ITableRun?>(null)
         // Arrange - 2 tables, a parent and a child. The child is one shorter than the parent.
         ArrayRun.tryParse(model, "[element:]10", 0x20, null, parent)
         model.observeAnchorWritten(token, "parent", parent.value!!)
         val child = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[element:]parent-1", 0x40, null, child)
         model.observeAnchorWritten(token, "child", child.value!!)
         Assert.equal(9, child.value!!.elementCount)

         // Adding via the child should extend the child by 1.
         child.value  = model.getTable("child")
         var errorInfo = model.completeArrayExtension(token, 1, child)
         Assert.equal(ErrorInfo.noError, errorInfo)
         Assert.equal(10, child.value!!.elementCount)

         // Adding via the parent should extend the child by 1.
         parent.value  = model.getTable("parent")
         errorInfo  = model.completeArrayExtension(token, 1, parent)
         child.value  = model.getTable("child")
         Assert.equal(ErrorInfo.noError, errorInfo)
         Assert.equal(11, child.value!!.elementCount)
      }
      @Test fun AutocompletePicksExpectedElementAndMovesToNextElement() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x100, "Tackle", "Fire Punch", "Earthquake", "Psycho Boost")
         test.CreateEnumTable("pokemoves", 0x00, HardcodeTablesModel.moveNamesTable, 0, 1, 2, 3)

         test.ViewPort.edit("@04 firepunch ")
         Assert.equal(1, test.Model.readMultiByteValue(0x04, 2))
         Assert.equal(Point(2, 0), test.ViewPort.selectionStart)
         Assert.equal("pokemoves/3", test.ViewPort.tools!!.tableTool!!.currentElementName)
      }
      @Test fun NullPointer_MakeSmallTable_TableAdded() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("<null> @00 ^table[pointer<>]1 ")
         var table = test.Model.getTable("table")

         Assert.equal(0, table!!.start)
         Assert.equal(4, table.length)
         Assert.single(table!!.elementContent)
      }
      @Test fun SingleQuote_TryMatch_NoMatch() {
         var options = arrayOf( "abc", "xyz")
         val discard = Ref<Int>(0)
         var match = ArrayRunEnumSegment.tryMatch("\"", options.toList(), discard)
         Assert.isFalse(match)
      }
      @Test fun TextWithStartingQuote_TryMatchTextWithNoQuote_Matches() {
         var options = arrayOf( "abc", "xyz")
         val discard = Ref<Int>(0)
         var match = ArrayRunEnumSegment.tryMatch("\"ab", options.toList(), discard)
         Assert.isTrue(match)
      }
      @Test fun BitFieldWithUnknownBitSet_CopyPaste_CorrectBitsSet() {
         var fileSystem = StubFileSystem()
         Model.setList(ModelDelta(), "bits", "adam", "bob", "carl", "dave")
         ViewPort.edit("^table[a|b[]bits]3 00 10 ")

         ViewPort.selectionStart  = Point(1, 0)
         ViewPort.copy!!.execute(fileSystem)

         ViewPort.selectionStart  = Point(2, 0)
         ViewPort.edit(fileSystem.copyText!!)

         Assert.equal(0x10, Model[2])
      }
      @Test fun TableAPointsAtElementsOfTableB_ExpandTableA_TableBPointerKnowledgeCorrect() {
         ViewPort.edit("@060 ^tableB^[a: b: c.]4 @020 <060> <065> <06A> <null> DD @020 ^tableA[entry<>]4 ")
         Assert.single(Model.getTable("tableB")!!.pointerSources); // precondition: 1 thing points to tableB

         var tableA = Model.getTable("tableA")
         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(tableA!!.start + tableA.length - 1)
         ViewPort.tools!!.tableTool!!.append.execute()

         tableA  = Model.getTable("tableA")
         var tableB = Model.getTable("tableB")
         Assert.notEqual(0x20, tableA!!.start)
         Assert.equal(0x60, tableB!!.start)
         Assert.single(tableB!!.pointerSources)
      }
      @Test fun IdTableWithOrderedValues_Append_OrderedValues() {
         ViewPort.edit("^table[id:]4 5 6 7 8 ")

         ViewPort.edit("@table/4 +")

         Assert.equal(9, Model.getTable("table")!!.readValue(Model, 4))
      }
      @Test fun MatchedIdTableWithExtraEndElements_Append_OrderedValues() {
         SetFullModel(0xFF)
         ViewPort.edit("^table1[content:]4 @10 ^table2[id:]table1+2 3 4 5 6 7 8 ")

         ViewPort.edit("@table1/4 +")

         var table = Model.getTable("table2")
         var values = table!!.elementCount.range().map({ i -> table!!.readValue(Model, i) }).toTypedArray()
         Assert.equal(arrayOf( 3, 4, 5, 6, 9, 7, 8), values)
      }
      @Test fun TableWithOutOfOrderIds_Append_InsertIDs() {
         ViewPort.edit("^table[id:]4 5 8 6 7 ")

         ViewPort.edit("@table/4 +")

         var table = Model.getTable("table")
         var values = table!!.elementCount.range().map({ i -> table!!.readValue(Model, i) }).toTypedArray()
         Assert.equal(arrayOf( 5, 9, 6, 7, 8), values)
      }

      private fun StandardSetup(data: Ref<ByteArray>, model: Ref<PokemonModel>, viewPort: Ref<ViewPort>) {
         data.value  = ByteArray(0x200)
         model.value  = PokemonModel(data.value)
         viewPort.value  = ViewPort("file.txt", model.value, InstantDispatch.instance, BaseViewModelTestClass.Singletons).also { it.allowMultipleElementsPerLine = true; it.width = 0x10; it.height = 0x10 }
      }

      private fun WriteStrings(buffer: ByteArray, start: Int, vararg content: String) { var start = start
         for (item in content) {
            var bytes = PCSString.convert(item)!!.toTypedArray()
            arrayCopy(bytes, 0, buffer, start, bytes.size)
            start  += bytes.size
         }
      }
   }
