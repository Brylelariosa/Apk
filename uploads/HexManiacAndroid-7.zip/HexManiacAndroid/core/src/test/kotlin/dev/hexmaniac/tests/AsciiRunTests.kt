@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class AsciiRunTests : BaseViewModelTestClass() {
      @Test fun CanCreateAsciiRun() {
         val (model, viewPort) = Pair(Model, ViewPort)
         model[0x10]  = ('a').u8()
         model[0x11]  = ('b').u8()
         model[0x12]  = ('c').u8()
         model[0x13]  = ('d').u8()

         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^data`asc`4 ")

         var format = ((viewPort[1, 1].format) as Ascii)
         Assert.equal("b", format.thisCharacter)
      }
      @Test fun CanEditAsciiRun() {
         val (model, viewPort) = Pair(Model, ViewPort)
         model[0x10]  = ('a').u8()
         model[0x11]  = ('b').u8()
         model[0x12]  = ('c').u8()
         model[0x13]  = ('d').u8()

         model.observeRunWritten(ModelDelta(), AsciiRun(model, 0x10, 4))

         viewPort.selectionStart  = Point(1, 1)
         viewPort.edit("3")

         var format = ((viewPort[1, 1].format) as Ascii)
         Assert.equal("3", format.thisCharacter)
         Assert.equal(Point(2, 1), viewPort.selectionStart)
      }
      @Test fun AsciiText_TypeSpace_NoChange() {
         ViewPort.edit("^test`asc`7  ")
         Assert.equal(0, Model[0])
         Assert.equal(0, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun AsciiText_EscapeCharacter_EditCharacter() {
         ViewPort.edit("^test`asc`7 \\")
         var format = ((ViewPort[0, 0].format) as UnderEdit)
         Assert.equal("\\", format.currentText)
      }
      @Test fun AsciiText_EscapeSpace_OneChange() {
         ViewPort.edit("^test`asc`7  \\ ")
         Assert.equal((' ').u8(), Model[0])
         Assert.equal(1, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun AsciiText_NoEscapeAnchor_AnchorEdit() {
         ViewPort.edit("^test`asc`7 ^")
         Assert.isType<UnderEdit>(ViewPort[0, 0].format)
      }
      @Test fun AsciiText_EscapeAnchor_WriteCharacter() {
         ViewPort.edit("^test`asc`7 \\^")
         Assert.equal(('^').u8(), Model[0])
         Assert.equal(1, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun AsciiText_EscapeEscape_WriteOneCharacter() {
         ViewPort.edit("^test`asc`7 \\\\")
         Assert.equal(('\\').u8(), Model[0])
         Assert.equal(1, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun AsciiFormat_ZeroLength_ConvertToLength1() {
         ViewPort.edit("^test`asc`0 ")
         Assert.equal(1, Model.getNextRun(0).length)
      }

      // TODO 'copy' should work correctly when including escape characters, like a leading space, ^, or \
   }
