@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*

/** Hand port of TestExtensions.cs */

fun IDataModel.setList(name: String, list: List<String>) = this.setList(NoDataChangeDeltaModel(), name, list, null)
fun IDataModel.setList(token: ModelDelta, name: String, list: List<String>, hash: String?) = this.setList(token, name, list, LinkedHashMap<Int, String>(), hash ?: "")

fun List<IContextItem>.getSubmenu(content: String): ContextItemGroup = this.single { it.text == content } as ContextItemGroup

fun IDataModel.bytesFrom(run: IFormattedRun): ByteArray {
    val data = ByteArray(run.length)
    System.arraycopy(this.rawData, run.start, data, 0, run.length)
    return data
}

fun ISpriteRun.getPixels(model: IDataModel, page: Int): Array<IntArray>? = this.getPixels(model, page, -1)

fun IDataModel.readSprite(address: Int): Array<IntArray>? {
    val sprite = this.getNextRun(address) as ISpriteRun
    return sprite.getPixels(this, 0)
}

fun IStreamRun.deserializeRun(content: String, token: ModelDelta): IStreamRun = this.deserializeRun(content, token, Ref(null), Ref(null))
fun TrainerPokemonTeamRun.deserializeRun(content: String, token: ModelDelta, setDefaultMoves: Boolean, setDefaultItems: Boolean): TrainerPokemonTeamRun =
    this.deserializeRun(content, token, setDefaultMoves, setDefaultItems, Ref(null))
fun TableStreamRun.deserializeRun(content: String, token: ModelDelta): TableStreamRun = this.deserializeRun(content, token, Ref(null), Ref(null)) as TableStreamRun

fun ModelDelta.changeList(name: String, oldValues: Array<String>, newValues: Array<String>) {
    this.changeList(name, New.validationList(null, oldValues.toList()), New.validationList(null, newValues.toList()))
}

inline fun <reified T> ObservableCollection<IArrayElementViewModel>.singleOf(): T = this.single { it is T } as T

fun IDataModel.exportMetadata(info: IMetadataInfo): StoredMetadata? = this.exportMetadata(null, info)

inline fun <reified TRun> IDataModel.getTyped(name: String): TRun {
    val address = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, name)
    val run = this.getNextRun(address)
    Assert.equal(run!!.start, address)
    return run as TRun
}

fun ScriptParser.compile(token: ModelDelta, model: IDataModel, start: Int, script: Ref<String>, movedData: Ref<List<ScriptParserCompileMovedDataTuple>?>): ByteArray? =
    this.compile(token, model, start, script, movedData, Ref(0))

/** Force the evaluation of all properties to check for exceptions that would normally occur during binding. */
fun INotifyPropertyChanged.readAllProperties() {
    val self: Any = this
    for (m in self.javaClass.methods) {
        if (m.parameterCount != 0) continue
        if (!(m.name.startsWith("get") && m.name.length > 3) && !(m.name.startsWith("is") && m.name.length > 2)) continue
        if (java.lang.reflect.Modifier.isStatic(m.modifiers)) continue
        try {
            m.invoke(self)
        } catch (e: java.lang.reflect.InvocationTargetException) {
            throw e.targetException ?: e
        }
    }
}

fun ScriptParser.parse(data: IDataModel, start: Int, length: Int, updateBody: CodeBody? = null): String {
    val count = Ref(0)
    return this.parse(data, start, length, count, updateBody)
}

fun ThumbParser.compile(model: IDataModel, start: Int, vararg lines: String): ByteList =
    this.compile(model, start, Ref<List<IFormattedRun>?>(null), *lines)

class ListByteList(val list: List<Int>) : ByteList {
    override val count: Int get() = list.size
    override operator fun get(index: Int): Int = list[index]
}
fun ModelDelta.changeData(model: IDataModel, index: Int, array: ByteArray): Boolean = this.changeData(model, index, array.asByteList())
fun ModelDelta.changeData(model: IDataModel, index: Int, array: List<Int>): Boolean = this.changeData(model, index, ListByteList(array))
fun ByteList.toTypedArray(): ByteArray { val r = ByteArray(count); for (i in 0 until count) r[i] = this[i].toByte(); return r }
fun ByteList.toList(): List<Int> = (0 until count).map { this[it] }
fun ByteArray.writeInto(dest: ByteArray, index: Int) { System.arraycopy(this, 0, dest, index, this.size) }
fun List<Int>.writeInto(dest: ByteArray, index: Int) { for (i in indices) dest[index + i] = this[i].toByte() }
fun List<Int>?.copyInto(destination: ByteArray, destinationOffset: Int) { val l = this!!; for (i in l.indices) destination[destinationOffset + i] = l[i].toByte() }
fun Array<String>.indexOfPartial(input: String): Int = this.asList().indexOfPartial(input)

fun String.join(items: Array<String>): String = items.joinToString(this)

fun Array<String>.trimAll(): List<String> = this.asList().trimAll().toList()

// C# int[,] indexing: a[x, y] on an Array<IntArray> stored as a[x][y]
operator fun Array<IntArray>.get(x: Int, y: Int): Int = this[x][y]
operator fun Array<IntArray>.set(x: Int, y: Int, value: Int) { this[x][y] = value }

fun ByteList.writeInto(target: ByteArray, start: Int) { for (i in 0 until count) target[start + i] = get(i).toByte() }
