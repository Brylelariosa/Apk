@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class BaseImageEditorTests {
      protected lateinit var model: IDataModel
      protected lateinit var history: ChangeHistory<ModelDelta>
      protected lateinit var editor: ImageEditorViewModel

      private var Revert: ((ModelDelta) -> ModelDelta)? = null

      private fun RevertHistoryChange(change: ModelDelta): ModelDelta {
         return Revert?.invoke(change)  ?:  change.revert(model)
      }

      //#region Test Helper Methods

      protected fun DrawBox(colorIndex: Int, start: Point, width: Int, height: Int) { var start = start
         editor.palette.selectionStart  = colorIndex

         editor.toolDown(start)
         for (x in 1 until width) { start = Point(start.x + 1, start.y); editor.hover(start) }
         for (y in 1 until height) { start = Point(start.x, start.y + 1); editor.hover(start) }
         for (x in 1 until width) { start = Point(start.x - 1, start.y); editor.hover(start) }
         for (y in 1 until height) { start = Point(start.x, start.y - 1); editor.hover(start) }
         editor.toolUp(start)
      }

      protected fun DrawPixel(index: Int, color: Short, vararg points: Point) {
         editor.palette.elements[index].color  = color
         editor.palette.selectionStart  = index
         ToolMove(*points)
      }

      protected fun ToolMove(vararg motion: Point) {
         editor.toolDown(motion[0])
         for (i in 1 until motion.size) editor.hover(motion[i])
         editor.toolUp(motion[motion.size - 1])
      }

      companion object {
         fun Rgb(r: Int, g: Int, b: Int): Short = (((r  shl  10)) or ((g  shl  5)) or (b)).toShort()
         fun Rgb(color: Short): Triple<Int, Int, Int> { val c = color.toInt(); return Triple(c shr 10, (c shr 5) and 31, c and 31) }
      }
      protected fun GetPixel(x: Int, y: Int): Short = editor.pixelData[editor.pixelIndex(Point(x, y))]

      //#endregion

      protected var Black: Short = Rgb(0, 0, 0)
      protected var White: Short = Rgb(31, 31, 31)
      protected var Red: Short = Rgb(31, 0, 0)
      protected var Blue: Short = Rgb(0, 0, 31)

      protected var SpriteStart: Int = 0x00

      protected var SpritePointerStart: Int = 0x80
      protected var PaletteStart: Int = 0x40
      protected var PalettePointerStart: Int = 0x88

      init {
         model  = PokemonModel(ByteArray(0x200), singletons = BaseViewModelTestClass.Singletons)
         history  = ChangeHistory<ModelDelta>(::RevertHistoryChange)

         model.writePointer(history.currentChange, SpritePointerStart, SpriteStart)
         model.writePointer(history.currentChange, PalettePointerStart, PaletteStart)

         var sprite = SpriteRun(model, SpriteStart, SpriteFormat(4, 1, 1, "palette"), SortedSpan<Int>(SpritePointerStart))
         model.observeAnchorWritten(history.currentChange, "sprite", sprite)

         var palette = PaletteRun(PaletteStart, PaletteFormat(4, 1), SortedSpan<Int>(PalettePointerStart))
         model.observeAnchorWritten(history.currentChange, "palette", palette)

         model[0x20]  = 0x23; // random data after the sprite, so expanding it causes a repoint
         model[0x60]  = 0x23; // random data after the palette, so expanding it causes a repoint

         editor  = ImageEditorViewModel(history, model, SpriteStart)
         editor.spriteScale  = 1.toDouble()
      }
   }

   open class ImageEditorTests : BaseImageEditorTests() {
      private fun Insert64CompressedBytes(start: Int) {
         // header: 10 40 00 00
         // body: 0b00111000 00 00 1F0 1F0 1F0 00 00 00
         //       0x00       00 00 00 00 00
         model.writeValue(history.currentChange, start, 0x4010)
         model[start + 4]  = 0x38
         model.writeMultiByteValue(start + 7, 2, history.currentChange, 0x1F0)
         model.writeMultiByteValue(start + 9, 2, history.currentChange, 0x1F0)
         model.writeMultiByteValue(start + 11, 2, history.currentChange, 0x1F0)
      }

      private fun InsertCompressedData(start: Int, length: Int) {
         var compressedData = LZRun.compress(ByteArray(length).asByteList(), 0, length)
         for (i in 0 until compressedData.count) model[start + i]  = compressedData[i]
      }

      private fun Create2PageCompressedSprite() {
         Insert64CompressedBytes(SpriteStart)

         var sprite = LzSpriteRun(SpriteFormat(4, 1, 1, "palette"), model, SpriteStart, SortedSpan<Int>(SpritePointerStart))
         model.observeAnchorWritten(history.currentChange, "sprite", sprite)

         editor.refresh()
      }

      private fun Create2PageCompressedPalette(initialBlankPages: Int = 0) {
         Insert64CompressedBytes(PaletteStart)

         var pal = LzPaletteRun(PaletteFormat(4, 2, initialBlankPages), model, PaletteStart, SortedSpan<Int>(PalettePointerStart))
         model.observeAnchorWritten(history.currentChange, "palette", pal)

         editor.refresh()
      }

      private fun Create256ColorCompressedSprite() {
         Insert64CompressedBytes(SpriteStart)

         var sprite = LzSpriteRun(SpriteFormat(8, 1, 1, "palette"), model, SpriteStart, SortedSpan<Int>(SpritePointerStart))
         model.observeAnchorWritten(history.currentChange, "sprite", sprite)

         editor.refresh()
      }

      private fun WriteArray(address: Int, name: String, format: String) {
         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, format, address, SortedSpan<Int>.none(), table)
         model.observeAnchorWritten(history.currentChange, name, table.value!!)
      }
      @Test fun Palette_Default_Color0Selected() {
         Assert.single(editor.palette.elements.filter({ sc -> sc.selected }))
         Assert.isTrue(editor.palette.elements[0].selected)
      }
      @Test fun Palette_ChangeColor_PixelsUpdate() {
         var notifyPixelData = 0
         editor.bind("pixelData", { sender, e -> notifyPixelData  += 1 })
         editor.palette.elements[0].color  = Rgb(1, 1, 1)

         Assert.equal(Triple(1, 1, 1), Rgb(GetPixel(0, 0)))
         Assert.equal(1, notifyPixelData)
      }
      @Test fun NewColor_Draw_PixelsChange() {
         var palette = editor.palette
         palette.selectionStart  = 1
         palette.elements[1].color  = Rgb(31, 31, 31)
         var notifyPixelData = 0
         editor.bind("pixelData", { sender, e -> notifyPixelData  += 1 })

         ToolMove(Point())

         Assert.equal(Triple(31, 31, 31), Rgb(GetPixel(4, 4)))
         Assert.equal(1, ((model.getNextRun(SpriteStart) as ISpriteRun)).getPixels(model, 0)!![4, 4])
         Assert.equal(Rgb(31, 31, 31), ((model.getNextRun(PaletteStart) as IPaletteRun)).getPalette(model, 0)!![1])
         Assert.equal(1, notifyPixelData)
      }
      @Test fun Zoom_UpperLeft_StaysPut() {
         editor.zoomIn(Point(-4, -4))

         Assert.equal(2, editor.spriteScale)
         Assert.equal(4, editor.xOffset)
         Assert.equal(4, editor.yOffset)
      }
      @Test fun Zoom_Zoom24_NoZoom() {
         for (i in 0 until 25) editor.zoomIn(Point(0, 0))
         Assert.equal(24, editor.spriteScale)
      }
      @Test fun ZoomOut_NoZoom_NoZoom() {
         editor.zoomOut(Point(0, 0))
         Assert.equal(1, editor.spriteScale)
      }
      @Test fun ZoomIn_ZoomOut_DefaultZoom() {
         editor.zoomIn(Point())
         editor.zoomOut(Point())
         Assert.equal(1, editor.spriteScale)
      }
      @Test fun Center_Pan2_Offset2() {
         editor.selectedTool  = ImageEditorTools.Pan

         ToolMove(Point(), Point(2, 0))

         Assert.equal(2, editor.xOffset)
      }
      @Test fun Zoom_Pan2_Offset2() {
         editor.selectedTool  = ImageEditorTools.Pan

         editor.zoomIn(Point(0, 0))
         ToolMove(Point(), Point(2, 0))

         Assert.equal(2, editor.xOffset)
      }
      @Test fun Pan2_Zoom_Offset4() {
         editor.selectedTool  = ImageEditorTools.Pan

         editor.toolDown(Point(0, 0))
         editor.hover(Point(2, 0))
         editor.toolUp(Point(2, 0))
         editor.zoomIn(Point(0, 0))

         Assert.equal(4, editor.xOffset)
      }
      fun Zoom_Unzoom_Symmetric(x: Int, y: Int) {
         editor.zoomIn(Point(x, y))
         editor.zoomIn(Point(x, y))
         editor.zoomOut(Point(x, y))
         editor.zoomOut(Point(x, y))

         Assert.equal(0, editor.xOffset)
         Assert.equal(0, editor.yOffset)
      }
    @Test fun Zoom_Unzoom_Symmetric_1() { Zoom_Unzoom_Symmetric(-4, -4) }
    @Test fun Zoom_Unzoom_Symmetric_2() { Zoom_Unzoom_Symmetric(3, 3) }
    @Test fun Zoom_Unzoom_Symmetric_3() { Zoom_Unzoom_Symmetric(-4, 3) }
    @Test fun Zoom_Unzoom_Symmetric_4() { Zoom_Unzoom_Symmetric(3, -4) }
      @Test fun Draw_Drag_Line() {
         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         editor.selectedTool  = ImageEditorTools.Draw

         ToolMove(Point(), Point(1, 0))

         Assert.equal(Triple(31, 31, 31), Rgb(GetPixel(4, 4)))
         Assert.equal(Triple(31, 31, 31), Rgb(GetPixel(5, 4)))
      }
      @Test fun Fill_Blank_FillAll() {
         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         editor.selectedTool  = ImageEditorTools.Fill

         ToolMove(Point())

         Assert.all(64.range(),
            { i -> Assert.equal(Triple(31, 31, 31), Rgb(GetPixel(i % 8, i / 8))) })
      }
      @Test fun EyeDropper_SelectColor_ColorSelected() {
         editor.palette.selectionStart  = 1

         editor.eyeDropperDown(Point())
         editor.eyeDropperUp(Point())

         Assert.isTrue(editor.palette.elements[0].selected)
         Assert.isFalse(editor.palette.elements[1].selected)
      }
      @Test fun EyeDropper_OutOfRange_Noop() {
         editor.eyeDropperDown(Point(-50, 0))
         editor.eyeDropperUp(Point(-50, 0))
      }
      @Test fun BigPan_SmallImage_PanHitsLimit() {
         editor.toolDown(Point(0, 0))
         editor.hover(Point(50, 0))
         editor.toolUp(Point(50, 0))

         Assert.equal(4, editor.xOffset)
      }
      @Test fun Editor_Close_InvokesClosed() {
         var count = 0
         editor.closed  += { sender, e -> count  += 1 }

         editor.close.execute()

         Assert.equal(1, count)
      }
      @Test fun Pan_SelectFill_FillSelected() {
         editor.selectTool.execute(ImageEditorTools.Fill)

         Assert.equal(ImageEditorTools.Fill, editor.selectedTool)
      }
      @Test fun NoZoom_Zoom_OffsetChangeNotify() {
         var xOffsetNotify: Int = 0; var yOffsetNotify: Int = 0
         editor.bind("xOffset", { sender, e -> xOffsetNotify  += 1 })
         editor.bind("yOffset", { sender, e -> yOffsetNotify  += 1 })

         editor.zoomIn(Point(-4, 3))

         Assert.equal(1, xOffsetNotify)
         Assert.equal(1, yOffsetNotify)
      }
      @Test fun Image_Repoint_ToolStillWorks() {
         var destination = model.readPointer(editor.spritePointer)
         var spriteRun = (model.getNextRun(destination) as ISpriteRun)

         spriteRun  = model.relocateForExpansion(history.currentChange, spriteRun, spriteRun.length + 1)

         // if this doesn't throw, we're happy
         editor.selectedTool  = ImageEditorTools.Draw
         ToolMove(Point())
      }
      @Test fun Palette_Repoint_AdressUpdate() {
         var destination = model.readPointer(editor.palettePointer)
         var palRun = (model.getNextRun(destination) as IPaletteRun)

         palRun  = model.relocateForExpansion(history.currentChange, palRun, palRun.length + 1)

         editor.palette.elements[0].color  = Rgb(31, 31, 31)
         Assert.equal(Rgb(31, 31, 31), model.readMultiByteValue(palRun.start, 2))
      }
      @Test fun Zoom_Draw_ColorChanges() {
         editor.zoomIn(-4, -4)

         editor.palette.selectionStart  = 1
         ToolMove(Point(-4, -4))

         Assert.equal(1, model[0])
      }
      @Test fun Draw_OutOfBounds_Noop() {
         editor.palette.selectionStart  = 1

         ToolMove(Point(50, 50))

         Assert.all(0x20.range(), { i -> Assert.equal(0, model[0]) })
      }
      @Test fun New_NothingSelected() {
         Assert.all(64.range(), { i -> Assert.isFalse(editor.showSelectionRect(i % 8, i / 8)) })
      }
      @Test fun DrawTool_Hover_ShowSelectionRect() {
         editor.selectedTool  = ImageEditorTools.Draw

         editor.hover(0, 0)

         Assert.isTrue(editor.showSelectionRect(4, 4))
      }
      @Test fun DrawToolAndZoom_Hover_ShowLargeSelectionRect() {
         editor.selectedTool  = ImageEditorTools.Draw
         editor.zoomIn(Point())

         editor.hover(0, 0)

         Assert.isTrue(editor.showSelectionRect(4, 4))
         Assert.isFalse(editor.showSelectionRect(4, 5))
         Assert.isFalse(editor.showSelectionRect(4, 3))
         Assert.isFalse(editor.showSelectionRect(5, 4))
         Assert.isFalse(editor.showSelectionRect(3, 4))
      }
      @Test fun SelectTool_Drag_ShowSelectionRect() {
         editor.selectedTool  = ImageEditorTools.Select

         ToolMove(Point(), Point(2, 1))

         Assert.isTrue(editor.showSelectionRect(4, 4))
         Assert.isTrue(editor.showSelectionRect(5, 4))
         Assert.isTrue(editor.showSelectionRect(6, 4))
         Assert.isTrue(editor.showSelectionRect(4, 5))
         Assert.isTrue(editor.showSelectionRect(5, 5))
         Assert.isTrue(editor.showSelectionRect(6, 5))
      }
      @Test fun Select_Drag_MovePixels() {
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         DrawBox(1, Point(-4, -4), 2, 2)
         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(-4, -4), Point(-3, -3))

         ToolMove(Point(-3, -3), Point(-2, -3))

         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(Point(2, 1))])
      }
      @Test fun SelectDrag_DragBack_OriginalPixelsBack() {
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         DrawBox(1, Point(-4, -4), 2, 2)
         ToolMove(Point(-2, -4)); // sentinel pixel
         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(-4, -4), Point(-3, -3))

         // move it back and forth
         ToolMove(Point(-4, -4), Point(-3, -4))
         ToolMove(Point(-3, -4), Point(-4, -4))

         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(Point(2, 0))])
      }
      @Test fun Selection_MidInteraction_SelectionRectIsCorrect() {
         editor.selectedTool  = ImageEditorTools.Select

         editor.toolDown(Point())
         editor.hover(Point(-1, 0))

         Assert.isFalse(editor.showSelectionRect(2, 4))
         Assert.isTrue(editor.showSelectionRect(3, 4))
         Assert.isTrue(editor.showSelectionRect(4, 4))
         Assert.isFalse(editor.showSelectionRect(5, 4))
      }
      @Test fun Color1Selected_EyeDropColor0_Color0Selected() {
         editor.palette.selectionStart  = 1
         editor.selectedTool  = ImageEditorTools.EyeDropper

         ToolMove(Point(0, 0))

         Assert.equal(0, editor.palette.selectionStart)
         Assert.equal(0, editor.palette.selectionEnd)
      }
      @Test fun EyeDropper_Drag_DrawBlock() {
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         DrawBox(1, Point(-4, -4), 2, 2)

         editor.eyeDropperDown(-4, -4)
         editor.hover(-3, -3)
         editor.eyeDropperUp(-3, -3)
         ToolMove(Point(0, 0))

         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(4, 4)])
         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(4, 5)])
         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(5, 4)])
         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(5, 5)])
      }
      @Test fun ModelChange_Refresh_PixelsChanged() {
         editor.palette.elements[15].color  = Rgb(31, 31, 31)
         editor.palette.pushColorsToModel()
         model[0]  = 0xFF

         editor.refresh()

         Assert.equal(Rgb(31, 31, 31), editor.pixelData[0])
         Assert.equal(Rgb(31, 31, 31), editor.pixelData[1])
      }
      @Test fun DrawTool_Hover_RaiseRefreshSelection() {
         editor.selectedTool  = ImageEditorTools.Draw
         var refreshCount = 0
         editor.refreshSelection  += { sender, e -> refreshCount  += 1 }

         editor.hover(Point())

         Assert.equal(1, refreshCount)
      }
      @Test fun Zoom_OddPixel_RoundLeft() {
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         editor.palette.selectionStart  = 1
         editor.zoomIn(Point())
         editor.zoomIn(Point())

         ToolMove(Point(-1, -1))

         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(3, 3)])
      }
      @Test fun DrawToolSelected_PanMethod_Pan() {
         editor.selectedTool  = ImageEditorTools.Draw

         editor.panDown(Point())
         editor.hover(2, 0)
         editor.panUp(2, 0)

         Assert.equal(2, editor.xOffset)
      }
      @Test fun FillTool_SelectColor_FilToolStillSelected() {
         editor.selectedTool  = ImageEditorTools.Fill

         editor.palette.selectionStart  = 1

         Assert.equal(ImageEditorTools.Fill, editor.selectedTool)
      }
      @Test fun FillTool_Hover_Selection() {
         editor.selectedTool  = ImageEditorTools.Fill

         editor.hover(Point())

         Assert.isTrue(editor.showSelectionRect(4, 4))
      }
      @Test fun Change_Undo_Refresh() {
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         editor.palette.selectionStart  = 1
         ToolMove(Point(0, 0))

         editor.undo.execute()

         Assert.equal(0, editor.pixelData[editor.pixelIndex(4, 4)])
      }
      @Test fun DifferentPixel_HoverColor_SelectPixel() {
         editor.palette.elements[1].color  = Rgb(31, 31, 31)
         editor.palette.selectionStart  = 1
         ToolMove(Point(0, 0))

         editor.palette.hoverIndex  = 1

         Assert.isTrue(editor.showSelectionRect(4, 4))
      }
      @Test fun EyeDropper_Hover_ShowSelection() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         editor.hover(0, 0)

         Assert.isTrue(editor.showSelectionRect(4, 4))
      }
      @Test fun EyeDropper_Drag_ShowSelection() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         editor.toolDown(0, 0)
         editor.hover(1, 1)

         Assert.all(arrayOf(
            Point(4, 4), Point(4, 5), Point(5, 4), Point(5, 5),), { point -> Assert.isTrue(editor.showSelectionRect(point)) })
      }
      @Test fun BlockPreview_Default_NotEnabled() {
         Assert.isFalse(editor.blockPreview.enabled)
      }
      @Test fun EyeDropper_BlockSelected_BlockPreview() {
         editor.palette.elements[0].color  = Rgb(31, 31, 31)
         editor.selectedTool  = ImageEditorTools.EyeDropper

         ToolMove(Point(0, 0), Point(1, 1))

         Assert.isTrue(editor.blockPreview.enabled)
         Assert.equal(2, editor.blockPreview.pixelWidth)
         Assert.equal(2, editor.blockPreview.pixelHeight)
         Assert.equal(4, editor.blockPreview.pixelData.size)
         Assert.all(4.range(), { i -> Assert.equal(Rgb(31, 31, 31), editor.blockPreview.pixelData[i]) })
      }
      @Test fun BlockSelected_ColorSelected_BlockCleared() {
         editor.selectedTool  = ImageEditorTools.EyeDropper
         ToolMove(Point(0, 0), Point(1, 1))

         editor.palette.selectionStart  = 0

         Assert.isFalse(editor.blockPreview.enabled)
      }
      @Test fun BlockSelected_EyeDropperSinglePixel_BlockCleared() {
         editor.selectedTool  = ImageEditorTools.EyeDropper
         ToolMove(Point(0, 0), Point(1, 1))

         ToolMove(Point(-1, -1))

         Assert.isFalse(editor.blockPreview.enabled)
      }
      @Test fun BlockSelected_Small_LargeScale() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         ToolMove(Point(0, 0), Point(1, 1))

         Assert.equal(32, editor.blockPreview.spriteScale)
      }
      @Test fun BlockSelected_Large_SmallScale() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         ToolMove(Point(-4, -4), Point(3, 3))

         Assert.equal(8, editor.blockPreview.spriteScale)
      }
      @Test fun EyeDropper_SelectSquare_SelectionIsSquare() {
         editor.eyeDropperDown(0, 0)
         editor.hover(2, 2)

         Assert.isTrue(editor.showSelectionRect(6, 4))
      }
      @Test fun EyeDropper_SelectRect_SelectionIsRect() {
         editor.eyeDropperDown(0, 0)
         editor.hover(3, 2)

         Assert.isTrue(editor.showSelectionRect(7, 4))
      }
      @Test fun EyeDropper_SelectUpRight_RectangleAnchorsToBottomLeft() {
         editor.eyeDropperDown(0, 0)
         editor.hover(1, -2)

         Assert.isTrue(editor.showSelectionRect(4, 2))
      }
      @Test fun Draw_SetCursorSize_LargeCursor() {
         editor.selectedTool  = ImageEditorTools.Draw

         editor.setCursorSize.execute("2")
         editor.hover(Point())

         Assert.all(arrayOf(
            Point(4, 4),
            Point(4, 5),
            Point(5, 4),
            Point(5, 5),), { p -> Assert.isTrue(editor.showSelectionRect(p)) })
      }
      @Test fun EyeDropperBlock_SelectColor_DrawSinglePixel() {
         editor.eyeDropperDown(0, 0)
         editor.hover(1, 1)
         editor.eyeDropperUp(1, 1)

         editor.palette.selectionStart  = 1
         editor.hover(0, 0)

         Assert.all(arrayOf(
            Point(4, 5),
            Point(5, 4),
            Point(5, 5),), { p -> Assert.isFalse(editor.showSelectionRect(p)) })
      }
      @Test fun FillTool_HorizontalDrag_FillAreaWithHorizontalGradient() {
         editor.palette.elements[1].color  = White
         editor.palette.elements[2].color  = Red
         editor.palette.elements[3].color  = Blue
         DrawBox(1, Point(), 4, 4)

         editor.palette.selectionStart  = 2
         editor.palette.selectionEnd  = 3
         editor.selectedTool  = ImageEditorTools.Fill
         ToolMove(Point(1, 1), Point(2, 1))

         Assert.equal(Red, editor.pixelData[editor.pixelIndex(5, 5)])
         Assert.equal(Blue, editor.pixelData[editor.pixelIndex(5, 6)])
         Assert.equal(Blue, editor.pixelData[editor.pixelIndex(6, 5)])
         Assert.equal(Blue, editor.pixelData[editor.pixelIndex(6, 6)])
      }
      @Test fun FillTool_Drag_UpdateCursor() {
         editor.selectedTool  = ImageEditorTools.Fill

         editor.toolDown(Point())
         editor.hover(1, 1)

         Assert.isTrue(editor.showSelectionRect(5, 5))
      }
      @Test fun TwoPageSprite_RequestSecondPage_EditsSecondPage() {
         Create2PageCompressedSprite()
         editor.spritePage  = 1
         editor.palette.elements[1].color  = White
         editor.palette.selectionStart  = 1

         ToolMove(Point(-4, -4))

         var decompress = LZRun.decompress(model, 0)
         Assert.equal(1, (decompress!![0x20].toInt()) and (0xF))
      }
      @Test fun TwoPagePalette_RequestSecondPalette_EditsSecondPage() {
         Create2PageCompressedPalette()
         editor.palettePage  = 1

         editor.palette.elements[0].color  = White

         var decompress = LZRun.decompress(model, PaletteStart)
         Assert.equal(White, decompress!!.asByteList().readMultiByteValue(0x20, 2))
      }
      @Test fun TwoPageContent_CheckPageCount_ReturnsTwo() {
         Create2PageCompressedSprite()
         Create2PageCompressedPalette()

         Assert.equal(2, editor.spritePages)
         Assert.equal(2, editor.palettePages)
      }
      @Test fun TwoPageContent_SwitchPageCommand_SwitchPages() {
         Create2PageCompressedSprite()
         Create2PageCompressedPalette()

         editor.spritePageOptions[1].selected  = true
         editor.palettePageOptions[1].selected  = true

         Assert.equal(1, editor.spritePage)
         Assert.equal(1, editor.palettePage)
      }
      @Test fun Sprite256Color_Draw2ndPagePalette_ExpectedBytesChange() {
         Create256ColorCompressedSprite()
         Create2PageCompressedPalette(2)

         editor.palettePage  = 1
         editor.palette.selectionStart  = 1;  // page 2+1, index 1 -> color 0x31
         editor.selectedTool  = ImageEditorTools.Draw
         ToolMove(Point(-4, -4))

         var data = LZRun.decompress(model, 0)
         Assert.equal(0x31, data!![0])
      }
      @Test fun Empty_PasteExistingColors_PixelsPaste() {
         var fileSystem = StubFileSystem()
         fileSystem.copyImage  = IFileSystemCopyImageTuple(shortArrayOf( Black, Red, Blue, White), 2)
         editor.palette.elements[1].color  = Red
         editor.palette.elements[2].color  = Blue
         editor.palette.elements[3].color  = White

         editor.paste.execute(fileSystem)

         // pasted content should be centered
         Assert.equal(Black, GetPixel(3, 3))
         Assert.equal(Red, GetPixel(4, 3))
         Assert.equal(Blue, GetPixel(3, 4))
         Assert.equal(White, GetPixel(4, 4))

         // selection tool is active
         Assert.equal(ImageEditorTools.Select, editor.selectedTool)
         Assert.isTrue(editor.showSelectionRect(3, 3))
         Assert.isTrue(editor.showSelectionRect(4, 3))
         Assert.isTrue(editor.showSelectionRect(3, 4))
         Assert.isTrue(editor.showSelectionRect(4, 4))
      }
      @Test fun Data_Copy_FileSystemImageContainsCopy() {
         var fileSystem = StubFileSystem()
         DrawPixel(1, Red, Point(0, -1))
         DrawPixel(2, Blue, Point(-1, 0))
         DrawPixel(3, White, Point(0, 0))

         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(-1, -1), Point(0, 0))
         editor.copy!!.execute(fileSystem)

         val (image, width) = fileSystem.copyImage.value
         Assert.equal(2, width)
         Assert.equal(arrayOf( Black, Red, Blue, White), image)
      }
      @Test fun Selection_FlipVertical_DataFlips() {
         DrawPixel(1, Red, Point(0, -1))
         DrawPixel(2, Blue, Point(-1, 0))
         DrawPixel(3, White, Point(0, 0))

         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(-1, -1), Point(0, 0))
         editor.flipVertical.execute()

         Assert.equal(Blue, GetPixel(3, 3))
         Assert.equal(White, GetPixel(4, 3))
         Assert.equal(Black, GetPixel(3, 4))
         Assert.equal(Red, GetPixel(4, 4))
      }
      @Test fun Selection_FlipHorizontal_DataFlips() {
         DrawPixel(1, Red, Point(0, -1))
         DrawPixel(2, Blue, Point(-1, 0))
         DrawPixel(3, White, Point(0, 0))

         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(-1, -1), Point(0, 0))
         editor.flipHorizontal.execute()

         Assert.equal(Red, GetPixel(3, 3))
         Assert.equal(Black, GetPixel(4, 3))
         Assert.equal(White, GetPixel(3, 4))
         Assert.equal(Blue, GetPixel(4, 4))
      }
      @Test fun EyeDropper_4PixelCursorHover_4PixelSelection() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         editor.cursorSize  = 4
         editor.hover(0, 0)

         Assert.equal(ImageEditorTools.EyeDropper, editor.selectedTool)
         Assert.isTrue(editor.showSelectionRect(7, 7))
      }
      @Test fun ColorSelection_SelectNew_DisjointSelection() {
         editor.palette.selectionStart  = 0
         editor.palette.selectionEnd  = 2

         editor.palette.toggleSelection(5)

         Assert.isTrue(editor.palette.elements[2].selected)
         Assert.isFalse(editor.palette.elements[3].selected)
         Assert.isTrue(editor.palette.elements[5].selected)
      }
      @Test fun ColorSelection_DeselectColor_DisjointSelection() {
         editor.palette.selectionStart  = 0
         editor.palette.selectionEnd  = 2

         editor.palette.toggleSelection(1)

         Assert.isTrue(editor.palette.elements[0].selected)
         Assert.isFalse(editor.palette.elements[1].selected)
         Assert.isTrue(editor.palette.elements[2].selected)
      }
      @Test fun FillToolSelected_GrabColor_ColorGrabbed() {
         editor.setCursorSize.execute("2")
         editor.palette.selectionStart  = 3
         editor.selectedTool  = ImageEditorTools.Fill

         editor.eyeDropperDown(0, 0)
         editor.eyeDropperUp(0, 0)

         Assert.isTrue(editor.palette.elements[0].selected)
         Assert.all(Enumerable.Range(1, 15), { i -> Assert.isFalse(editor.palette.elements[i].selected) })
         Assert.isFalse(editor.blockPreview.enabled)
      }
      @Test fun MultiplePalettesAvailable_SelectSecondOption_SwitchPalettes() {
         var PalettePointer2Start: Int = 0x90; var Palette2Start: Int = 0x100
         model.clearFormat(NoDataChangeDeltaModel(), 0, model.count)
         model.writePointer(history.currentChange, PalettePointer2Start, Palette2Start)

         InsertCompressedData(SpriteStart, 0x20)
         InsertCompressedData(PaletteStart, 0x20)
         InsertCompressedData(Palette2Start, 0x20)
         WriteArray(SpritePointerStart, "sprites", "[sprite<`lzs4x1x1`>]1")
         WriteArray(PalettePointerStart, "palettes1", "[pal<`lzp4`>]sprites")
         WriteArray(PalettePointer2Start, "palettes2", "[pal<`lzp4`>]sprites")
         var editor = ImageEditorViewModel(history, model, SpriteStart)

         editor.selectedEditOption  = 1

         Assert.isTrue(editor.hasMultipleEditOptions)
         Assert.equal(PalettePointer2Start, editor.palettePointer)
         Assert.equal(2, editor.editOptions.size)
      }
      @Test fun TwoPageSpriteAndOnePageSprite_SelectSecondPageThenSwitchSprites_SelectPageZero() {
         var SpritePointer2Start: Int = 0x90; var Sprite2Start: Int = 0x100
         model.clearFormat(NoDataChangeDeltaModel(), 0, model.count)
         model.writePointer(history.currentChange, SpritePointer2Start, Sprite2Start)

         InsertCompressedData(SpriteStart, 0x40); // 2 pages
         InsertCompressedData(Sprite2Start, 0x20); // 1 page
         WriteArray(SpritePointerStart, "sprites", "[sprite<`lzs4x1x1`>]1")
         WriteArray(PalettePointerStart, "palettes", "[pal<`ucp4`>]sprites")
         WriteArray(SpritePointer2Start, "sprites2", "[sprite<`lzs4x1x1`>]sprites")
         var editor = ImageEditorViewModel(history, model, SpriteStart)

         editor.spritePage  = 1
         editor.selectedEditOption  = 1

         Assert.equal(0, editor.spritePage)
      }
      @Test fun LargeSelection_DrawOutOfBounds_LimitDrawPixels() {
         editor.eyeDropperDown(0, 0)
         editor.hover(2, 2)
         editor.eyeDropperUp(2, 2)
         editor.selectedTool  = ImageEditorTools.Draw

         ToolMove(Point(3, 3))

         // nothing to assert: if it didn't crash, we're good.
      }
      @Test fun Sprite_CanEditTilePalettes_False() {
         Assert.isFalse(editor.canEditTilePalettes)
      }
      @Test fun EyeDropper_SelectFromLeftOfImage_DoNothing() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         editor.toolDown(-6, 0)
         editor.hover(-1, 3)
         editor.toolUp(-1, 3)

         Assert.isFalse(editor.blockPreview.enabled)
      }
      @Test fun EyeDropper_SelectFromBelowImage_DoNothing() {
         editor.selectedTool  = ImageEditorTools.EyeDropper

         editor.toolDown(0, 6)
         editor.hover(2, 3)
         editor.toolUp(2, 3)

         Assert.isFalse(editor.blockPreview.enabled)
      }
      @Test fun TallEyeDropper_Draw_DrawTallRect() {
         // draw a vertical line
         editor.palette.elements[1].color  = White
         editor.palette.selectionStart  = 1
         ToolMove(Point(0, -1), Point(0, 0), Point(0, 1))

         // grab the vertical line and click to draw it somewhere else
         editor.selectedTool  = ImageEditorTools.EyeDropper
         ToolMove(Point(0, -1), Point(0, 0), Point(0, 1))
         editor.selectedTool  = ImageEditorTools.Draw
         ToolMove(Point(-2, -1))

         Assert.equal(White, editor.pixelData[editor.pixelIndex(2, 3)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(2, 4)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(2, 5)])
      }
      @Test fun Selection_ControlPlusDrag_OriginalPixelsRemainTheSame() {
         editor.palette.elements[1].color  = White
         editor.palette.selectionStart  = 1
         editor.cursorSize  = 2
         ToolMove(Point(0, 0))
         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(0, 0), Point(1, 1))

         editor.toolDown(Point(0, 0), altBehavior = true)
         editor.hover(Point(-4, -4))
         editor.toolUp(-4, -4)

         Assert.equal(White, editor.pixelData[editor.pixelIndex(0, 0)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(4, 4)])
      }
      fun Copy_PasteInCorner_NewPixelsInCorner(hoverX: Int, hoverY: Int, pixelX: Int, pixelY: Int) {
         var fileSystem = StubFileSystem()
         editor.palette.elements[1].color  = White
         fileSystem.copyImage  = IFileSystemCopyImageTuple(shortArrayOf( White, White, White, White), 2)

         editor.hover(hoverX, hoverY)
         editor.paste.execute(fileSystem)

         Assert.equal(White, editor.pixelData[editor.pixelIndex(pixelX + 0, pixelY + 0)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(pixelX + 1, pixelY + 0)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(pixelX + 0, pixelY + 1)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(pixelX + 1, pixelY + 1)])
      }
    @Test fun Copy_PasteInCorner_NewPixelsInCorner_1() { Copy_PasteInCorner_NewPixelsInCorner(-4, -4, 0, 0) }
    @Test fun Copy_PasteInCorner_NewPixelsInCorner_2() { Copy_PasteInCorner_NewPixelsInCorner(3, -4, 6, 0) }
    @Test fun Copy_PasteInCorner_NewPixelsInCorner_3() { Copy_PasteInCorner_NewPixelsInCorner(-4, 3, 0, 6) }
    @Test fun Copy_PasteInCorner_NewPixelsInCorner_4() { Copy_PasteInCorner_NewPixelsInCorner(3, 3, 6, 6) }
      @Test fun EyeDropperSize4_ClickDrag_Select4x4Tiles() {
         editor.selectedTool  = ImageEditorTools.EyeDropper
         editor.cursorSize  = 4

         editor.toolDown(-2, -2)
         editor.hover(2, -2)
         editor.toolUp(2, -2)

         Assert.equal(8, editor.blockPreview.pixelWidth)
         Assert.equal(4, editor.blockPreview.pixelHeight)
         Assert.equal(editor.blockPreview.pixelData, editor.pixelData.take(editor.blockPreview.pixelData.size).toTypedArray())
      }
      @Test fun EyeDropper_TallSelection_BlockPreviewSpriteScaleIsReasonable() {
         editor.eyeDropperDown(-4, -4)
         editor.hover(-4, 3)
         editor.eyeDropperUp(-4, 3)
         Assert.inRange(editor.blockPreview.spriteScale, 4.0, 8.0)
      }
      @Test fun Selection_Delete_FillWithBlack() {
         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = White
         ToolMove(Point(0, 0))

         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(0, 0), Point(1, 1))

         editor.deleteSelection()

         Assert.equal(Black, editor.pixelData[editor.pixelIndex(4, 4)])
      }
   }

   open class ImageEditorSingleSpriteMultiplePalettesTests : BaseImageEditorTests() {
      init {
         var newPaletteData = LZRun.compress(ByteArray(0x40).asByteList(), 0, 0x40).toTypedArray()
         arrayCopy(newPaletteData, 0, model.rawData, PaletteStart, newPaletteData.size)
         model.observeRunWritten(ModelDelta(), LzPaletteRun(PaletteFormat(4, 2), model, PaletteStart))
         editor.refresh()
      }
      @Test fun SingleSpriteMultiplePalette_BucketToolWithSecondPalette_FillWorks() {
         editor.palettePage  = 1
         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = White

         editor.selectedTool  = ImageEditorTools.Fill
         ToolMove(Point(0, 0))

         Assert.equal(White, editor.pixelData[editor.pixelIndex(0, 0)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(0, 7)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(7, 0)])
         Assert.equal(White, editor.pixelData[editor.pixelIndex(7, 7)])
         Assert.equal(1, editor.readRawPixel(4, 4))
      }
      @Test fun SingleSpriteMultiplePalette_Draw8x8WithPalette1_DoNotSwitchPalette() {
         editor.palettePage  = 1
         editor.selectedTool  = ImageEditorTools.Draw

         editor.cursorSize  = 8
         ToolMove(Point(0, 0))

         Assert.equal(1, editor.palettePage)
      }
      @Test fun SingleSpriteMutltiplePalettes_EyeDropToolOnSecondPalette_SecondPaletteStillSelected() {
         editor.palettePage  = 1
         editor.palette.selectionStart  = 1

         editor.eyeDropperDown(0, 0)
         editor.eyeDropperUp(0, 0)

         Assert.equal(0, editor.palette.selectionStart)
         Assert.equal(1, editor.palettePage)
      }
      @Test fun SingleSpriteMultiplePalettes_DrawPalette2_ColorsAreInRangeForPalette1() {
         editor.palettePage  = 1

         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = White
         ToolMove(Point(0, 0))

         Assert.equal(1, editor.readRawPixel(4, 4))
      }
      @Test fun SingleSpriteMultiplePalettes_SelectDragOnSecondPalette_SpriteStillShowsSecondPalette() {
         editor.palettePage  = 1
         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = White
         ToolMove(Point(0, 0))

         editor.selectedTool  = ImageEditorTools.Select
         ToolMove(Point(0, 0), Point(1, 1))
         ToolMove(Point(0, 0), Point(-1, 0))

         Assert.equal(White, editor.pixelData[editor.pixelIndex(3, 4)])
      }
   }

   open class ImageEditorTilemapTests {
      private var model: IDataModel = PokemonModel(ByteArray(0x200), singletons = BaseViewModelTestClass.Singletons)
      private lateinit var history: ChangeHistory<ModelDelta>
      private lateinit var editor: ImageEditorViewModel
      private fun RevertHistoryChange(change: ModelDelta): ModelDelta = change.revert(model)

      val TilemapStart: Int = 0x00

      val TilesetStart: Int = 0x40

      val PaletteStart: Int = 0x80

      private fun Rgb(r: Int, g: Int, b: Int): Short = (((r  shl  10)) or ((g  shl  5)) or (b)).toShort()
      private fun GetPixel(x: Int, y: Int): Short = editor.pixelData[editor.pixelIndex(Point(x, y))]
      private fun InsertCompressedData(start: Int, data: ByteArray) {
         var compressedData = LZRun.compress(data.asByteList(), 0, data.size)
         for (i in 0 until compressedData.count) model[start + i]  = compressedData[i]
      }

      init {
         history  = ChangeHistory<ModelDelta>(::RevertHistoryChange)

         model.writePointer(history.currentChange, 0x160, TilemapStart)
         model.writePointer(history.currentChange, 0x164, TilesetStart)
         model.writePointer(history.currentChange, 0x168, PaletteStart)

         InsertCompressedData(TilemapStart, bytes(
            0x00, 0x20, // use 2 tiles with the 1st palette (page 2)
            0x01, 0x20,
            0x02, 0x30, // use 2 tiles with the 2nd palette (page 3)
            0x03, 0x30)); // 2000 is page 2, tile 0
         InsertCompressedData(TilesetStart, ByteArray(0x20 * 4));      // 4 tile
         InsertCompressedData(PaletteStart, ByteArray(0x20 * 2));      // 2 pages

         model.observeAnchorWritten(history.currentChange, "tilemap", LzTilemapRun(TilemapFormat(4, 2, 2, "tileset"), model, TilemapStart))
         model.observeAnchorWritten(history.currentChange, "tileset", LzTilesetRun(TilesetFormat(4, "palette"), model, TilesetStart))
         model.observeAnchorWritten(history.currentChange, "palette", LzPaletteRun(PaletteFormat(4, 2, 2), model, PaletteStart)); // pages are 2 and 3

         editor  = ImageEditorViewModel(history, model, TilemapStart)
         editor.spriteScale  = 1.toDouble()

         // everything is black, split between 2 palettes where all 16 colors are black
      }
      @Test fun Tilemap_Edit_SeePalettePagePerTile() {
         Assert.isTrue(editor.canEditTilePalettes)
         Assert.equal(2, editor.tilePalettes[0])
         Assert.equal(2, editor.tilePalettes[1])
         Assert.equal(3, editor.tilePalettes[2])
         Assert.equal(3, editor.tilePalettes[3])

         Assert.equal(0, editor.palettePage)
         Assert.equal(arrayOf( -2, 0, 1), editor.palettePageOptions.map({ option -> option.index }).toTypedArray())
      }
      @Test fun Tilemap_EditTilePalettes_SeeTilePalettesChange() {
         editor.tilePalettes[0]  = 3

         var mapData = LZRun.decompress(model, TilemapStart)
         val (pal, _, _, _) = LzTilemapRun.readTileData(mapData!!, 0, 2)
         Assert.equal(3, pal)
      }
      @Test fun Tilemap_UseTilePaletteTool_TilePaletteChanged() {
         editor.selectedTool  = ImageEditorTools.TilePalette
         editor.palettePage  = 1

         editor.toolDown(-4, -4)
         editor.toolUp(-4, -4)

         var mapData = LZRun.decompress(model, TilemapStart)
         val (pal, _, _, _) = LzTilemapRun.readTileData(mapData!!, 0, 2)
         Assert.equal(3, pal)
      }
      @Test fun Tilemap_RightClickFromTilePaletteTool_SelectedTilePaletteIndexUpdates() {
         editor.selectedTool  = ImageEditorTools.TilePalette

         editor.eyeDropperDown(4, 4)
         editor.eyeDropperUp(4, 4)

         Assert.equal(1, editor.palettePage)
      }
      @Test fun TilePaletteTool_Hover_ShowEntireTileAsSelected() {
         editor.selectedTool  = ImageEditorTools.TilePalette

         editor.hover(4, 4)

         Assert.isTrue(editor.showSelectionRect(8, 8))
         Assert.isTrue(editor.showSelectionRect(15, 15))
      }
      @Test fun WhitePalette_ChangePalette_PixelsChange() {
         editor.palettePageOptions.last().selected  = true
         editor.palette.elements[0].color  = Rgb(31, 31, 31)
         editor.selectedTool  = ImageEditorTools.TilePalette

         editor.toolDown(4, -4)
         editor.toolUp(4, -4)

         Assert.equal(Rgb(0, 0, 0), GetPixel(2, 2))
         Assert.equal(Rgb(31, 31, 31), GetPixel(12, 3))
      }
      @Test fun ChangePalette_RequiresRepoint_NoThrow() {
         // make a 4x2 image, since compression won't happen with a 2x2 image
         InsertCompressedData(TilemapStart, bytes(
            0x00, 0x20,
            0x00, 0x20,
            0x00, 0x20,
            0x00, 0x20,
            0x00, 0x20,
            0x00, 0x20,
            0x00, 0x20,
            0x00, 0x20,)); // 2000 is page 2, tile 0. Repeate for 8 tiles, 4x2
         model.observeAnchorWritten(history.currentChange, "tilemap", LzTilemapRun(TilemapFormat(4, 4, 2, "tileset"), model, TilemapStart))
         var editor = ImageEditorViewModel(history, model, TilemapStart)
         var tilemap = (model.getNextRun(TilemapStart) as LzTilemapRun)
         model[tilemap.start + tilemap.length]  = 32; // there's data after the run, so if it grows it needs to repoint

         // change a tile in a way that causes a repoint
         editor.selectedTool  = ImageEditorTools.TilePalette
         editor.palettePage  = 1
         editor.toolDown(0, 0)
         editor.toolUp(0, 0)
      }
      @Test fun DrawTool_DrawOnTileWithDifferentPalette_NoEffect() {
         editor.palettePage  = 1
         editor.palette.elements[1].color  = Rgb(31, 0, 0)
         editor.palette.selectionStart  = 1
         editor.selectedTool  = ImageEditorTools.Draw

         editor.toolDown(-8, -8)
         editor.toolUp(-8, -8)

         Assert.equal(Rgb(0, 0, 0), editor.pixelData[editor.pixelIndex(0, 0)])
      }
      @Test fun DrawTool_DrawOnTileWithSamePalette_Effect() {
         editor.palettePage  = 0
         editor.palette.elements[1].color  = Rgb(31, 0, 0)
         editor.palette.selectionStart  = 1
         editor.selectedTool  = ImageEditorTools.Draw

         editor.toolDown(-8, -8)
         editor.toolUp(-8, -8)

         Assert.equal(Rgb(31, 0, 0), editor.pixelData[editor.pixelIndex(0, 0)])
      }
      @Test fun DrawTool_HoverOnTileWithDifferentPalette_NoHoverSelection() {
         editor.palettePage  = 1
         editor.selectedTool  = ImageEditorTools.Draw

         editor.hover(-8, -8)

         Assert.isFalse(editor.showSelectionRect(0, 0))
      }
      @Test fun EyeDropperTool_PickPalette1Tile_SelectPalette1() {
         editor.eyeDropperDown(4, 4)
         editor.eyeDropperUp(4, 4)

         Assert.equal(1, editor.palettePage)
      }
      @Test fun EyeDropperPalette1Tile_DrawPalette0Tile_NoDraw() {
         editor.palettePage  = 1
         editor.palette.elements[0].color  = Rgb(31, 0, 0); // set the bottom two tiles to red
         editor.eyeDropperDown(4, 4)
         editor.eyeDropperUp(4, 4)

         editor.toolDown(-8, -8)
         editor.toolUp(-8, -8)

         Assert.equal(Rgb(0, 0, 0), editor.pixelData[editor.pixelIndex(0, 0)])
      }
      @Test fun FillTool_FillPalette1_TilesUsingPalette0Unaffected() {
         editor.palettePage  = 1
         editor.palette.elements[1].color  = Rgb(31, 0, 0); // set the bottom two tiles to red
         editor.palette.selectionStart  = 1
         editor.selectedTool  = ImageEditorTools.Fill

         editor.toolDown(4, 4)
         editor.toolUp(4, 4)

         Assert.all(128.range(), { i -> Assert.equal(Rgb(0, 0, 0), editor.pixelData[i]) })
         Assert.all(128.range(), { i -> Assert.equal(Rgb(31, 0, 0), editor.pixelData[i + 128]) })
      }
      @Test fun PaletteHover_HoverOnPage1_OnlyPage1PixelsHighlight() {
         editor.palettePage  = 1

         editor.palette.hoverIndex  = -1
         editor.palette.hoverIndex  = 0

         Assert.isFalse(editor.showSelectionRect(0, 0))
         Assert.isTrue(editor.showSelectionRect(12, 12))
      }
      @Test fun EyeDropperTool_ClickAndDrag_OnlyInitialPixelMattersForSelection() {
         editor.selectedTool  = ImageEditorTools.EyeDropper
         editor.cursorSize  = 2

         editor.toolDown(4, 4)
         editor.hover(6, 6)
         editor.toolUp(6, 6)

         Assert.equal(2, editor.blockPreview.pixelWidth)
         Assert.equal(2, editor.blockPreview.pixelHeight)
      }
      @Test fun EyeDropperTool_SelectEntireTile_CanDrawOverAnotherPalette() {
         editor.selectedTool  = ImageEditorTools.Draw
         editor.cursorSize  = 8

         editor.eyeDropperDown(4, 4)
         editor.eyeDropperUp(4, 4)

         editor.toolDown(-8, -8)
         editor.toolUp(-8, -8)

         var mapData = LZRun.decompress(model, TilemapStart)
         val (pal, _, _, _) = LzTilemapRun.readTileData(mapData!!, 0, 2)
         Assert.equal(3, pal)
      }
      @Test fun EyeDropperTool_SelectEntireTile_HoverDifferentPaletteShowsSelection() {
         editor.selectedTool  = ImageEditorTools.Draw
         editor.cursorSize  = 8

         editor.eyeDropperDown(4, 4)
         editor.eyeDropperUp(4, 4)

         editor.hover(-6, -6)

         Assert.isTrue(editor.showSelectionRect(3, 3))
      }
      @Test fun Selection_DragIntoTileWithDifferentPalette_ColorsFromNewPaletteAreUsed() {
         // draw red dots at (-4,-4) and (-3,-3)
         editor.selectedTool  = ImageEditorTools.Draw
         editor.palette.elements[1].color  = Rgb(31, 0, 0)
         editor.palette.selectionStart  = 1
         editor.toolDown(-4, -4)
         editor.toolUp(-4, -4)
         editor.toolDown(-3, -3)
         editor.toolUp(-3, -3)

         // set color 1 of palette page 1 to green
         editor.palettePage  = 1
         editor.palette.elements[1].color  = Rgb(0, 31, 0)

         // select the 2x2 square from (-4,-4) to (-3,-3)
         editor.selectedTool  = ImageEditorTools.Select
         editor.toolDown(-4, -4)
         editor.hover(-3, -3)
         editor.toolUp(-3, -3)

         // drag to the bottom left tile
         editor.toolDown(-4, -4)
         editor.hover(-4, 4)
         editor.toolUp(-4, 4)

         // check that the pixels are green after being dragged
         Assert.equal(Rgb(0, 31, 0), editor.pixelData[editor.pixelIndex(4, 12)])
         Assert.equal(Rgb(0, 31, 0), editor.pixelData[editor.pixelIndex(5, 13)])
         Assert.equal(Rgb(0, 0, 0), editor.pixelData[editor.pixelIndex(4, 13)])
         Assert.equal(Rgb(0, 0, 0), editor.pixelData[editor.pixelIndex(5, 12)])
      }
      @Test fun Selection_FlipBetweenTilesWithDifferentPalettes_ColorsFromNewPaletteAreUsed() {
         // draw red dots at (-4,-4) and (-3,-3)
         editor.selectedTool  = ImageEditorTools.Draw
         editor.palette.elements[1].color  = Rgb(31, 0, 0)
         editor.palette.selectionStart  = 1
         editor.toolDown(-4, -4)
         editor.toolUp(-4, -4)
         editor.toolDown(-3, -3)
         editor.toolUp(-3, -3)

         // set color 1 of palette page 1 to green
         editor.palettePage  = 1
         editor.palette.elements[1].color  = Rgb(0, 31, 0)

         // select a tall rectangle that spans two tiles
         editor.selectedTool  = ImageEditorTools.Select
         editor.toolDown(-4, -4)
         editor.hover(-3, 4)
         editor.toolUp(-3, 4)

         editor.flipVertical.execute()

         // check that the pixels are green after being flipped
         Assert.equal(Rgb(0, 31, 0), editor.pixelData[editor.pixelIndex(4, 12)])
         Assert.equal(Rgb(0, 31, 0), editor.pixelData[editor.pixelIndex(5, 11)])
         Assert.equal(Rgb(0, 0, 0), editor.pixelData[editor.pixelIndex(4, 11)])
         Assert.equal(Rgb(0, 0, 0), editor.pixelData[editor.pixelIndex(5, 12)])
      }
      @Test fun FillTool_FillTileWithDifferentPalette_NothingHappens() {
         // page 3, color 0 = white
         editor.palettePage  = 1
         editor.palette.elements[0].color  = Rgb(31, 31, 31)

         // fill with page 2, color 0 (black)
         editor.palettePage  = 0
         editor.selectedTool  = ImageEditorTools.Fill
         editor.toolDown(5, 5)
         editor.toolUp(5, 5)

         // tile was using palette page 3, so the color wasn't changed
         Assert.equal(Rgb(31, 31, 31), editor.pixelData[editor.pixelIndex(13, 13)])
      }
      @Test fun Tilemap_PaintSameTileWithTilePaletteTool_NoTilesChanged() {
         editor.selectedTool  = ImageEditorTools.TilePalette
         editor.tilePaletteMode  = TilePaletteMode.Fill
         editor.palettePage  = 0

         editor.toolDown(-4, -4)
         editor.toolUp(-4, -4)

         var mapData = LZRun.decompress(model, TilemapStart)
         var tilePalette = 4.range().map({ i -> LzTilemapRun.readTileData(mapData!!, i, 2).paletteIndex }).toMutableList()
         Assert.equal(arrayOf( 2, 2, 3, 3), tilePalette)
      }
      @Test fun Tilemap_PaintDifferentTileWithTilePaletteTool_TilesChanged() {
         editor.selectedTool  = ImageEditorTools.TilePalette
         editor.tilePaletteMode  = TilePaletteMode.Fill
         editor.palettePage  = 1

         editor.toolDown(-4, -4)
         editor.toolUp(-4, -4)

         var mapData = LZRun.decompress(model, TilemapStart)
         var tilePalette = 4.range().map({ i -> LzTilemapRun.readTileData(mapData!!, i, 2).paletteIndex }).toMutableList()
         Assert.equal(arrayOf( 3, 3, 3, 3), tilePalette)
      }
   }

   open class ImageEditor8BitTilemapTests : BaseViewModelTestClass() {

      private val PaletteStart: Int = 0x000

      private val TilesetStart: Int = 0x080

      private val TilemapStart: Int = 0x100
      private var Black: Short = UncompressedPaletteColor.pack(0, 0, 0)
      private var White: Short = UncompressedPaletteColor.pack(31, 31, 31)
      private var Red: Short = UncompressedPaletteColor.pack(31, 0, 0)

      private lateinit var editor: ImageEditorViewModel

      init {
         SetFullModel(0xFF)
         LZRun.compress(ByteArray(0x40).asByteList()).writeInto(Model.rawData, PaletteStart)
         LZRun.compress(ByteArray(0x40).asByteList()).writeInto(Model.rawData, TilesetStart)
         LZRun.compress(ByteArray(0x08).asByteList()).writeInto(Model.rawData, TilemapStart)

         Model.writePointer(ViewPort.currentChange, 0x180, PaletteStart)
         Model.writePointer(ViewPort.currentChange, 0x184, TilesetStart)
         Model.writePointer(ViewPort.currentChange, 0x188, TilemapStart)

         Model.observeAnchorWritten(ViewPort.currentChange, "palette", LzPaletteRun(PaletteFormat(4, 2, 2), Model, PaletteStart)); // pages are 2 and 3
         Model.observeAnchorWritten(ViewPort.currentChange, "tileset", LzTilesetRun(TilesetFormat(8, "palette"), Model, TilesetStart))
         Model.observeAnchorWritten(ViewPort.currentChange, "tilemap", LzTilemapRun(TilemapFormat(8, 2, 2, "tileset"), Model, TilemapStart))

         editor  = ImageEditorViewModel(ViewPort.changeHistory, Model, TilemapStart).also { it.spriteScale = 1.toDouble() }
      }
      @Test fun Tileset_8BPP_CannotEditTilePalettes() {
         Assert.isFalse(editor.canEditTilePalettes)
      }
      @Test fun Bucket_Fill_Filled() {
         editor.palette.selectionStart  = 1
         editor.palette.elements[1].color  = White
         editor.selectedTool  = ImageEditorTools.Fill

         editor.toolDown(0, 0)
         editor.toolUp(0, 0)

         Assert.equal(White, editor.pixelData[editor.pixelIndex(0, 0)])
      }
      @Test fun ImageWithMoreThan16ColorsInATile_Import_ColorsAreImportedCorrectly() {
         var tool = ViewPort.tools!!.spriteTool
         ViewPort.tools!!.selectedIndex  = ViewPort.tools!!.indexOf(tool!!)
         tool!!.spriteAddress  = TilemapStart
         tool!!.paletteAddress  = PaletteStart
         var imageToImport = ShortArray(16 * 16)
         for (i in 0 until 32) imageToImport[i / 8 * 16 + i % 8]  = UncompressedPaletteColor.pack(i, i, i)

         var filesystem = StubFileSystem().also { it.tryLoadIndexImage = lm1@{ filename, imageData, paletteData ->
               filename.value = "chosefile.png"
               imageData.value = null
               paletteData.value = null
               return@lm1 false
            }; it.loadImage = { filename -> IFileSystemLoadImageTuple(imageToImport, 16) } }
         tool!!.importPair.execute(filesystem)

         var tilesetData = ((Model.getNextRun(TilesetStart) as ITilesetRun)).getPixels(Model, 0)
         var palette = (Model.getNextRun(PaletteStart) as IPaletteRun)
         var paletteData = palette.allColors(Model)
         var pixels = SpriteTool.render(tilesetData, paletteData, palette.paletteFormat.initialBlankPages, 0)
         Assert.all(32.range(), lm2@{ i ->
            var pixel = pixels[8 + i + (i / 8) * 8]
            Assert.equal(i, UncompressedPaletteColor.toRGB(pixel).r)
         })
      }
   }

   open class ImageEditorOneBitImageTests : BaseViewModelTestClass() {
      private var model: IDataModel = PokemonModel(ByteArray(0x200), singletons = Singletons)
      private lateinit var history: ChangeHistory<ModelDelta>
      private lateinit var editor: ImageEditorViewModel
      private fun RevertHistoryChange(change: ModelDelta): ModelDelta = change.revert(model)

      private val ImageStart: Int = 0

      init {
         history  = ChangeHistory<ModelDelta>(::RevertHistoryChange)

         model.writePointer(history.currentChange, 0x160, ImageStart)

         model.observeAnchorWritten(history.currentChange, "image", SpriteRun(model, 0, SpriteFormat(1, 1, 1, "")))

         editor  = ImageEditorViewModel(history, model, ImageStart)
      }
      @Test fun InitialState_PaletteHas2Colors() {
         Assert.equal(2, editor.palette.elements.size)
         Assert.isFalse(editor.palette.canEditColors)
      }
   }

   open class ImageEditorOneByteTilemapTests {
      private val PaletteStart: Int = 0x00
      private val TilesetStart: Int = 0x20
      private val TilemapStart: Int = 0x100

      private var model: IDataModel = PokemonModel(ByteArray(0x200), singletons = BaseViewModelTestClass.Singletons)
      private lateinit var history: ChangeHistory<ModelDelta>
      private lateinit var editor: ImageEditorViewModel

      private fun InsertCompressedData(start: Int, length: Int) {
         var compressedData = LZRun.compress(ByteArray(length).asByteList(), 0, length)
         for (i in 0 until compressedData.count) model[start + i]  = compressedData[i]
      }

      init {
         history  = ChangeHistory<ModelDelta>({ change -> change.revert(model) })
         model.writePointer(history.currentChange, 0x160, PaletteStart)
         model.writePointer(history.currentChange, 0x164, TilesetStart)
         model.writePointer(history.currentChange, 0x168, TilemapStart)
         InsertCompressedData(PaletteStart, 32)
         InsertCompressedData(TilesetStart, 64)
         InsertCompressedData(TilemapStart, 2)

         PokemonModel.applyAnchor(model, history.currentChange, PaletteStart, "^pal`lzp4:1`")
         PokemonModel.applyAnchor(model, history.currentChange, TilesetStart, "^tiles`lzt8|pal`")
         PokemonModel.applyAnchor(model, history.currentChange, TilemapStart, "^map`lzm8x2x1|tiles`")
         editor  = ImageEditorViewModel(history, model, TilemapStart).also { it.spriteScale = 1.toDouble() }
      }
      @Test fun InitialState_Valid() {
         Assert.equal(2, editor.tileWidth)
         Assert.equal(1, editor.tileHeight)
         Assert.equal(2, editor.tilePalettes.size)
      }
      @Test fun SelectColor1_Hover_CanDraw() {
         editor.palette.selectionStart  = 1
         editor.hover(-4, 0)
         Assert.isTrue(editor.showSelectionRect(4, 4))
      }
      @Test fun SelectColor1_Draw_PixelChanges() {
         editor.palette.selectionStart  = 1

         editor.toolDown(-4, 0)
         editor.toolUp(-4, 0)

         var tilemap = (model.getNextRun(TilemapStart) as ITilemapRun)
         var data = tilemap.getTilemapData()
         Assert.equal(2, data.size)
         Assert.notEqual(data[0], data[1])
      }
   }

   open class ImageEditorTilesetTests : BaseViewModelTestClass() {
      @Test fun NoPalette_LoadInEditor_EditorLoadsSelectedPalette() {
         SetFullModel(0xFF)
         var parent = EditorViewModel(StubFileSystem(), Singletons.workDispatcher).also { it.add(ViewPort) }
         ViewPort.edit("@00 <020> <100> ")
         ViewPort.edit("@20!lz(1024) ^tileset`lzt4` ")
         ViewPort.edit("@100!lz(32)  ^pal`lzp4` ")

         ViewPort.tools!!.spriteTool!!.openInImageTab.execute()

         var editor = (parent.selectedTab as ImageEditorViewModel)
         Assert.equal(4, editor.palettePointer)
      }
   }

   open class ImageEditorRealDataTests {
      private var pal: ByteArray = "00 00 00 00 1F 02 1F 21 70 7A 42 7C 32 4A FF 7F 00 03 16 36 1B 70 F3 7F 9C 73 8E 14 08 26 19 2A".parseHexBytes()
      private var tileset: ByteArray = "10 00 08 00 33 00 00 F0 01 90 01 77 77 F0 01 D0 01 09 37 33 33 73 F0 03 33 73 50 1F 09 F7 FF FF 7F F0 03 FF 7F 50 1F 09 27 22 22 72 F0 03 22 72 50 1F 09 57 55 55 75 F0 03 55 75 50 1F 09 67 66 66 76 F0 03 66 76 10 1B 30 88 88 F0 01 90 01 77 97 79 77 9F 50 03 99 99 30 01 90 13 90 E7 60 1F 90 14 FF 90 2B F0 03 F0 03 F0 01 A0 61 30 03 F0 01 F0 1D E7 F0 01 F0 8F B0 03 99 99 30 03 F0 2F 50 03 FF 10 FB F0 61 70 2B 40 1F F0 CF 40 9F 40 5F F0 7B FF B1 5F F0 7F B0 9F F0 3B B0 9F F0 7F B1 9F C0 1F 09 A7 AA AA 7A F0 03 AA 7A 10 1B 33 BB BB F0 01 90 01 CC CC F0 01 90 01 3E DD DD F0 01 90 01 90 2B 50 9F A0 40 9C 67 C9 F0 03 80 03 EE EE F0 01 90 01 10 C3 09 47 44 44 74 F0 03 44 74 10 1B FF F3 D1 F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 FF F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 FF F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 FE F0 01 F0 01 F0 01 F0 01 F0 01 F0 01 50 01 30 13 33 33 03 F0 03 33 03 30 1D 00 06 01 30 30 03 00 03 03 33 00 12 FC 00 07 00 11 10 06 00 03 70 41 10 1A 30 00 69 30 00 07 10 05 03 20 03 00 33 50 1D 7F 03 30 4A 10 31 10 08 10 50 50 13 30 7F 30 40 ED 40 39 20 0F 00 11 03 70 3F 00 A1 00 00 5F FF 00 03 00 07 30 23 20 44 60 1F 40 03 20 A0 30 0B E1 F0 01 F0 01 50 01 50 55 55 05 F0 03 2D 55 05 80 1F 50 00 05 40 03 05 30 03 3F 55 00 00 07 70 21 30 06 40 03 00 39 00 1E D5 30 13 20 17 50 40 01 05 10 0A 05 10 41 F3 A0 3D 00 30 10 03 20 38 00 05 10 59 30 01 C3 50 20 30 8A 05 05 55 05 40 24 00 1A FF 70 9E 80 26 00 5A 00 25 10 4E 00 C1 40 20 20 90 E0 10 CF D0 A0 20 1D".parseHexBytes()
      private var tilemaps: Array<ByteArray> = arrayOf(
         "10 C8 00 00 3A 07 30 F0 01 F0 01 30 01 17 00 01 01 2B 30 02 00 03 05 C0 13 0E 20 03 50 13 58 01 20 01 0A 20 03 B0 13 10 30 09 35 30 13 20 09 10 13 03 20 09 06 20 03 F8 B0 27 30 01 F0 81 F0 01 50 01".parseHexBytes(),
         "10 C8 00 00 3B 07 30 F0 01 F0 01 30 01 01 80 01 50 13 56 06 00 0B 04 00 03 02 80 13 10 1F 0E C0 40 03 50 0F 0C 30 09 30 13 30 54 16 00 03 0D 60 3F 01 20 3D 0A 30 47 05 C0 3B 01 30 10 20 25 F0 81 F0 01 80 50 01".parseHexBytes(),
         "10 C8 00 00 3B 07 30 F0 01 F0 01 70 01 06 40 01 50 0F 00 02 30 01 30 11 30 09 30 14 16 30 12 20 0F 01 40 01 0B 30 5A 03 00 03 0B 20 0B 10 17 05 00 07 06 F6 20 0D 70 3B 10 0D 10 3B 09 40 3B 50 13 0B F8 20 09 30 05 F0 01 F0 01 10 01".parseHexBytes(),)

      lateinit var ViewPort: ViewPort
      val Model: IDataModel get() = ViewPort.model
      lateinit var Editor: ImageEditorViewModel
      init {
         var data = ByteArray(0x1000)
         for (i in 0 until data.size) data[i]  = 0xFF.toByte()

         pal.writeInto(data, 0)
         tileset.writeInto(data, 0x100)
         tilemaps[0].writeInto(data, 0x800)
         tilemaps[1].writeInto(data, 0x900)
         tilemaps[2].writeInto(data, 0xA00)

         var singletons = BaseViewModelTestClass.Singletons
         var model = PokemonModel(data, null, singletons)
         ViewPort  = ViewPort("Name", model, singletons.workDispatcher, singletons)
         ViewPort.edit("@00 ^pal`ucp4:3` @30 <000> @100 ^tileset`lzt4|pal` @B00 <800> <900> <A00> @B00 ^tilemaps[tilemap<`lzm4x10x10|tileset`>]3 @800 ")
         ViewPort.save!!.execute(StubFileSystem().also { it.save = { file -> true } })
         ViewPort  = ViewPort("Name", model, singletons.workDispatcher, singletons); // make a new ViewPort with a new history tracker

         ViewPort.requestTabChange  += { sender, args -> Editor  = (args.newTab as ImageEditorViewModel) }
         ViewPort.openImageEditorTab(0x800, 0, 0)
      }

      fun point(x: Int, y: Int): Point = Editor.fromSpriteSpace(Point(x  shl  3, y  shl  3))
      @Test fun TilemapTableWithSharedTileset_Edit8x8_TilesetUnchanged() {
         var tilesetData = (Model.getNextAnchor("tileset") as LzTilesetRun)
         var before = tilesetData.getData()

         // select an 8x8 region at tile (3,3), draw that tile at (4,3)
         Editor.selectedTool  = ImageEditorTools.Draw
         Editor.cursorSize  = 8
         Editor.eyeDropperDown(point(3, 3))
         Editor.eyeDropperUp(point(3, 3))
         Editor.toolDown(point(3, 4))
         Editor.toolUp(point(3, 4))

         //      check that the tileset is not edited
         tilesetData  = (Model.getNextAnchor("tileset") as LzTilesetRun)
         var after = tilesetData.getData()
         Assert.equal(before, after)
         Assert.equal(tilemaps[1], Model.bytesFrom(Model.getNextRun(0x900)!!))
         Assert.equal(tilemaps[2], Model.bytesFrom(Model.getNextRun(0xA00)!!))
      }
      @Test fun TilemapTableWithSharedTileset_EditOneTilemap_OtherTilemapsUnchanged() {
         var oldPixels = arrayOf( Model.readSprite(0x900), Model.readSprite(0xA00))
         Editor.selectedTool  = ImageEditorTools.Draw
         Editor.palette.selectionStart  = 1

         Editor.toolDown(point(4, 4))
         Editor.toolUp(point(4, 4))

         var newPixels = arrayOf( Model.readSprite(0x900), Model.readSprite(0xA00))
         Assert.equal(oldPixels, newPixels)
      }
      @Test fun Palette_Edit_CanUndo() {
         var watcher = EventWatcher({ handler -> Editor.undo.canExecuteChanged  += handler })
         Assert.isFalse(Editor.undo.canExecute(null))

         Editor.palette.elements[1].color  = BaseImageEditorTests.Rgb(31, 31, 31)

         Assert.equal(1, watcher.count)
      }
   }
