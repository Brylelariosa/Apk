@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ThumbRepointTests : BaseViewModelTestClass() {
      val Tool: CodeTool get() = ViewPort.tools!!.codeTool!!
      val Parser: ThumbParser get() = Tool.parser
      override val Token: ModelDelta get() = ViewPort.currentChange

      init {
         Model.expandData(ViewPort.currentChange, 0x400)
         SetFullModel(0xFF)
         Model.freeSpaceBuffer  = 0
         Model.freeSpaceStart  = 0x100
         ViewPort.refresh()
      }

      private fun ToPoint(address: Int): Point = ViewPort.convertAddressToViewPoint(address)
      private fun ToAddress(p: Point): Int = ViewPort.convertViewPointToAddress(p)
      private fun SelectRange(start: Int, length: Int) = run { val tt_ = Pair(ToPoint(start), ToPoint(start + length - 1)); ViewPort.selectionStart = tt_.component1(); ViewPort.selectionEnd = tt_.component2() }
      fun RepointThumb_Not8BytesSelected_Disabled(length: Int) {
         SelectRange(0, length)

         Assert.isFalse(Tool.canRepointThumb)
      }
    @Test fun RepointThumb_Not8BytesSelected_Disabled_1() { RepointThumb_Not8BytesSelected_Disabled(7) }
    @Test fun RepointThumb_Not8BytesSelected_Disabled_2() { RepointThumb_Not8BytesSelected_Disabled(9) }
      @Test fun RepointThumb_NoMovCommand_Disabled() {
         Parser.compile(Token, Model, 0, "nop", "nop", "nop", "nop")

         SelectRange(0, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
      @Test fun RepointThumb_Not4Commands_Disabled() {
         Parser.compile(Token, Model, 0, "bl <100>", "bl <100>")

         SelectRange(0, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
      @Test fun RepointThumb_RegisterValueNeededBeforeMove_Disabled() {
         Parser.compile(Token, Model, 0, "add r1, r0", "mov r0, #0", "nop", "nop")

         SelectRange(0, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
      fun RepointThumb_NotAligned_Disabled(start: Int) {
         Parser.compile(Token, Model, start, "mov r0, #0", "nop", "nop", "nop")

         SelectRange(start, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
    @Test fun RepointThumb_NotAligned_Disabled_1() { RepointThumb_NotAligned_Disabled(1) }
    @Test fun RepointThumb_NotAligned_Disabled_2() { RepointThumb_NotAligned_Disabled(2) }
      @Test fun RepointThumb_Last2BytesAreBranchLink_Disabled() {
         Parser.compile(Token, Model, 0, "mov r0, #0", "nop", "nop", "bl <080>")

         SelectRange(0, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
      @Test fun RepointThumb_LdrFromPc_Disabled() {
         Parser.compile(Token, Model, 0, "mov r0, #0", "ldr r1, [pc, <030>]", "nop", "nop")

         SelectRange(0, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
      @Test fun RepointThumb_NotInstruction_Disabled() {
         Parser.compile(Token, Model, 0, "mov r0, #0", "nop", "nop"); // 4th instruction is FFFF

         SelectRange(0, 8)

         Assert.isFalse(Tool.canRepointThumb)
      }
      @Test fun RepointThumb_CorrectSelection_Enabled() {
         Parser.compile(Token, Model, 0, "mov r0, #0", "nop", "nop", "nop")
         ViewPort.tools!!.selectedTool  = Tool
         var view = StubView(Tool)

         SelectRange(0, 8)

         Assert.isTrue(Tool.canRepointThumb)
         Assert.contains("canRepointThumb", view.propertyNotifications)
      }
      fun RepointThumb_ValidSelection_Repoints(register: Int) {
         Parser.compile(Token, Model, 0, "mov r${register}, #0", "nop", "nop", "nop")

         SelectRange(0, 8)
         Tool.repointThumb()

         var expectedCode = Parser.compile(Model, 0,
            "ldr   r${register}, [pc, <000004>]",
            "bx r${register}",
            "000004: .word <101>"); // destination + 1
         Assert.all(Enumerable.Range(0, expectedCode.count), { i -> Assert.equal(expectedCode[i], Model[i]) })
         expectedCode  = Parser.compile(Model, 0x100,
            "ldr r${register}, [pc, <110>]",
            "mov lr, r${register}",
            "mov r${register}, #0",
            "nop", "nop", "nop",
            "bx lr",
            "110: .word <9>"); // destination + 1
         Assert.all(Enumerable.Range(0, expectedCode.count), { i -> Assert.equal(expectedCode[i], Model[0x100 + i]) })

         Assert.single(Messages)
         Assert.equal(0x100, ViewPort.dataOffset)
         Assert.equal(0x100, ToAddress(ViewPort.selectionStart))
         Assert.equal(0x113, ToAddress(ViewPort.selectionEnd))
         Assert.isType<PointerRun>(Model.getNextRun(0x110))
      }
    @Test fun RepointThumb_ValidSelection_Repoints_1() { RepointThumb_ValidSelection_Repoints(0) }
    @Test fun RepointThumb_ValidSelection_Repoints_2() { RepointThumb_ValidSelection_Repoints(1) }

      // TODO allow repointing to use mov rX, rY scratch registers
      // TODO allow repointing 4+ commands (instead of exactly 4) so long as they still fit the no-branch criteria
      // TODO allow repointing starting on an odd instruction (multiple of 2 instead of multiple of 4) if enough commands are selected
      // TODO allow repointing ldr-pc commands by copying the needed pc data to the new destination
      // TODO allow repointing without a scratch register if the number of commands is enough to add a push
   }
