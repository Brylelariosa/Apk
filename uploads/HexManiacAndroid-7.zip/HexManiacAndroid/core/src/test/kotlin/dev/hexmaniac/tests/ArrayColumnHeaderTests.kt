@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ArrayColumnHeaderTests : BaseViewModelTestClass() {
      init {
         ViewPort.edit("^array[data1. data2.]8 ")
      }
      @Test fun AnchorFormatAutoCompletesToSingleByte() {
         ViewPort.anchorText  = "^array[data1. b data2.]8"
         var array = (Model.getNextRun(0) as ArrayRun)
         Assert.equal(3, array.elementLength)
         Assert.empty(Errors)
      }
      @Test fun HeadersChangeWhenAnchorChanges() {
         ViewPort.anchorText  = "^array[data1. b data2.]8"
         Assert.equal(0, ViewPort.columnHeaders[0].columnHeaders.size % 3)

         ViewPort.anchorText  = "^array[data1. bc data2.]8"
         Assert.equal("bc", ViewPort.columnHeaders[0].columnHeaders[1].columnTitle)
         Assert.equal(1, ViewPort.columnHeaders[0].columnHeaders[1].byteWidth)
      }
      @Test fun TableToolUpdatesAfterAnchorChange() {
         ViewPort.anchorText  = "^array[data1. b data2.]8"
         Assert.equal(4, ViewPort.tools!!.tableTool!!.children.size); // header + 3 elements

         ViewPort.anchorText  = "^array[data1. bc data2.]8"
         Assert.equal("bc", (((ViewPort.tools!!.tableTool!!.children[2]) as FieldArrayElementViewModel)).name)
      }
   }
