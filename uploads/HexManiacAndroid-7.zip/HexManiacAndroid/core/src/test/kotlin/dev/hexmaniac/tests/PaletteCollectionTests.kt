@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class PaletteCollectionTests : BaseViewModelTestClass() {
      private var fileSystem: StubFileSystem = StubFileSystem()

      init {
         ViewPort.edit("@80 <pal> @00 ^pal`ucp4`")
      }
      @Test fun CanCopy() {
         var collection = ViewPort.tools!!.spriteTool!!.colors

         collection.selectionStart  = 0
         collection.copy.execute(fileSystem)

         Assert.equal("0:0:0", fileSystem.copyText)
      }
      @Test fun CanPaste() {
         var collection = ViewPort.tools!!.spriteTool!!.colors

         collection.selectionStart  = 0
         fileSystem.copyText  = "1:1:1"
         collection.paste.execute(fileSystem)

         Assert.equal(0x421, Model.readMultiByteValue(0, 2))
      }
      @Test fun CompleteDoesNotChangeDataIfNoReorder() {
         ViewPort.edit("@00 10 20 00 00 @00 ^pal`lzp4`")
         var collection = ViewPort.tools!!.spriteTool!!.colors

         collection.selectionStart  = 2
         collection.handleMove(2, 2)
         collection.completeCurrentInteraction()

         Assert.equal(0x00, Model[4])
      }
      @Test fun CompressedDataWithBadLength_Reorder_DataRepointed() {
         Model.clearFormat(Token, 0, Model.count)
         SetFullModel(0xFF)
         // good palette
         ViewPort.edit("@40 10 20 00 00 00 4F 4F BE 21 1B 43 A5 5E 00 E4 49 43 39 9F 4F 5E 47 00 FE 12 42 08 1F 33 5F 22 00 BA 29 15 01 5A 6B FF 7F ")
         // bad palette
         ViewPort.edit("@80 10 20 00 00 00 4F 4F BE 21 1B 43 A5 5E 00 E4 49 43 39 9F 4F 5E 47 00 FE 12 42 08 1F 33 5F 22 08 BA 29 FF 7F 30 01 ")
         // pointers in collections to 'sync' the palettes
         ViewPort.edit("@04 <040> <080> @04 ")
         ViewPort.edit("^table1[ptr<`lzp4`>]1 @08 ^table2[ptr<`lzp4`>]table1 @40 ")

         var paletteViewModel = (ViewPort.tools!!.tableTool!!.children.last({ child -> child is PaletteElementViewModel }) as PaletteElementViewModel)
         var collection = paletteViewModel.colors
         collection.selectionStart  = 2
         collection.handleMove(2, 3)
         collection.completeCurrentInteraction()

         Assert.notEqual(0x80, Model.readPointer(0x8))
         Assert.single(Messages)
         Assert.empty(Errors)
      }
   }
