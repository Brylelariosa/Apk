@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   /// <summary>
   /// Test that tupels in tables work correctly.
   /// </summary>
   open class TupleTests : BaseViewModelTestClass() {
      @Test fun TupleSegment_Parse_GetTupleSegment() {
         var segments = ArrayRun.parseSegments("value:|t", Model)
         var segment = ((segments[0]) as ArrayRunTupleSegment)
         Assert.empty(segment.elements)
      }
      @Test fun TableFormat_TupleSpecified_CreatesTuple() {
         ViewPort.edit("^table[value:|t]1 ")

         Assert.isType<ArrayRunTupleSegment>(Model.getTable("table")!!.elementContent[0])
      }
      @Test fun TupleSegmentWithSingleBitLength_Parse_GetTupleSegmentWithSingleBitLength() {
         var segment = ArrayRunTupleSegment("tuple", "|a.", 2)
         Assert.single(segment.elements)
         Assert.equal("a", segment.elements[0].name)
         Assert.equal(1, segment.elements[0].bitWidth)
      }
      @Test fun TupleSegmentWithTwoBitLength_Parse_GetTupleSegmentWithTwoBitLength() {
         var segment = ArrayRunTupleSegment("tuple", "|a:", 2)
         Assert.single(segment.elements)
         Assert.equal("a", segment.elements[0].name)
         Assert.equal(2, segment.elements[0].bitWidth)
      }
      @Test fun SingleByteTupleSegmentWith9BitsOfData_Parse_Error() {
         Assert.throws<ArrayRunParseException>({ ArrayRunTupleSegment("tuple", "|a:.|b:.|c:.", 1) })
      }
      @Test fun TupleTable_TableTool_TupleSegment() {
         ViewPort.edit("^table[value:|t|a:|b:]1 ")
         Assert.equal(2, TupleTable.children.size)
         Assert.equal("a", TupleTable.children[0].name)
         Assert.equal(0, TupleTable.children[0].bitOffset)
         Assert.equal(2, TupleTable.children[1].bitOffset)
      }
      @Test fun TupleTable_ReadFromTableTool_CorrectResult() {
         Model[0]  = 0xB

         ViewPort.edit("^table[value:|t|a:|b:]1 ")
         var a = ((TupleTable.children[0]) as NumericTupleElementViewModel)
         var b = ((TupleTable.children[1]) as NumericTupleElementViewModel)

         Assert.equal(3, a.content)
         Assert.equal(2, b.content)
      }
      @Test fun TupleTable_WriteToTableTool_CorrectResult() {
         ViewPort.edit("^table[value:|t|a:|b:]1 ")
         var a = ((TupleTable.children[0]) as NumericTupleElementViewModel)
         var b = ((TupleTable.children[1]) as NumericTupleElementViewModel)

         a.content  = 3
         b.content  = 2

         Assert.equal(0xB, Model[0])
      }
      @Test fun TupleTable_ReadFromCheckBox_CorrectResult() {
         Model[0]  = 0x2

         ViewPort.edit("^table[value:|t|a.|b.]1 ")
         var a = ((TupleTable.children[0]) as CheckBoxTupleElementViewModel)
         var b = ((TupleTable.children[1]) as CheckBoxTupleElementViewModel)

         Assert.isFalse(a.isChecked)
         Assert.isTrue(b.isChecked)
      }
      @Test fun TupleTable_WriteToCheckBox_CorrectResult() {
         ViewPort.edit("^table[value:|t|a.|b.]1 ")
         var a = ((TupleTable.children[0]) as CheckBoxTupleElementViewModel)
         var b = ((TupleTable.children[1]) as CheckBoxTupleElementViewModel)

         a.isChecked  = true
         b.isChecked  = true

         Assert.equal(0x3, Model[0])
      }
      @Test fun TupleTable_SelectNextElement_SameElement() {
         ViewPort.edit("^table[value:|t|a:|b:]2 ")
         var tool = ViewPort.tools!!.tableTool
         var tupleChild1 = TupleTable.children[0]

         tool!!.next.execute()

         var tupleChild2 = TupleTable.children[0]
         Assert.isTrue(ReferenceEquals(tupleChild1, tupleChild2))
      }
      @Test fun TupleTable_LengthEnumFormat_EnumTupleCreated() {
         ViewPort.edit("^table[value:|t|a:|b:3|c:]1 ")
         var child = ((TupleTable.children[1]) as EnumTupleElementViewModel)

         child.filteringComboOptions.selectedIndex  = 2

         Assert.equal(arrayOf( "0", "1", "2"), child.filteringComboOptions.filteredOptions.map({ option -> option.text }).toTypedArray())
         Assert.equal(0x8, Model[0])
      }
      @Test fun TupleStream_Serialize_ElementsAreWrappedInParenthesis() {
         Model[10]  = 0xFF
         Model[11]  = 0xFF
         ViewPort.edit("^table[value.|t|a:|b. next.|h]!FFFF ")

         var text = ((Model.getNextRun(0) as IStreamRun)).serializeRun()

         var lines = text!!.split("\n")
         Assert.equal("(0 false), 00", lines[0])
         Assert.equal(5, lines.size)
      }
      @Test fun TupleStream_Deserialize_ValuesAreUpdated() {
         Model[4]  = 0xFF
         Model[5]  = 0xFF
         ViewPort.edit("^table[value.|t|a:|b. next.|h]!FFFF ")

         var run = (Model.getNextRun(0) as TableStreamRun)
         run  = run.deserializeRun("\n(2 true), 04\n", ViewPort.currentChange)

         Assert.equal(1, run.elementCount)
         Assert.equal(0x6, Model[0])
         Assert.equal(0x04, Model[1])
      }
      @Test fun TupleStream_SerializeEnum_ProducesText() {
         Model.setList("options", listOf( "None", "Something Else"))
         arrayCopy(bytes( 0, 0x29, 0xFF), Model.rawData, 3)
         ViewPort.edit("^table[value.|t|a:options|b:options|c:4]!FF ")

         var result = ((Model.getNextRun(0) as TableStreamRun)).serializeRun()

         var lines = result!!.splitLines()
         Assert.equal("(None None 0)", lines[0])
         Assert.equal("(\"Something Else\" 2 2)", lines[1])
      }
      @Test fun TupleStream_DeserializeEnum_ProducesEnum() {
         Model.setList("options", listOf( "None", "Something Else"))
         Model[2]  = 0xFF
         ViewPort.edit("^table[value.|t|a:options|b:options|c:options|d:4]!FF ")

         var run = (Model.getNextRun(0) as TableStreamRun)
         run.deserializeRun("(\"Some Else\", somethels 0, 3)", ViewPort.currentChange)

         Assert.equal(0xC5, Model[0])
      }
      @Test fun TupleStream_EnumDependency_DependencyRecognized() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         CreateEnumTable("enums", 0x80, "names", 0, 1, 2, 3)
         Model[1]  = 0xFF

         ViewPort.edit("@00 ^table[value.|t|a:|b:enums]!FF ")

         var run = (Model.getNextRun(0) as IStreamRun)
         Assert.isTrue(run.dependsOn("enums"))
      }
      @Test fun EmptyTupleSegmentName_CheckTableTool_DoesNotContainEmptyNameElements() {
         ViewPort.edit("^table[a.|t|.|x:|.|y:]1 ")

         Assert.equal(2, TupleTable.children.size)
         Assert.equal("x", TupleTable.children[0].name)
         Assert.equal("y", TupleTable.children[1].name)
      }
      @Test fun EmptyTupleSegmentName_Serialize_DoesNotContainEmptyNameElements() {
         Model[1]  = 0xFF
         ViewPort.edit("^table[a.|t|.|x:|.|y:]!FF ")

         var run = (Model.getNextRun(0) as TableStreamRun)
         var text = run.serializeRun()

         Assert.equal("(0 0)", text)
      }
      @Test fun EmptyTupleSegmentName_Deserialize_DoesNotExpectEmptyNameElements() {
         Model[1]  = 0xFF
         ViewPort.edit("^table[a.|t|.|x:|.|y:]!FF ")

         var run = (Model.getNextRun(0) as TableStreamRun)
         run.deserializeRun("(1, 1)", ViewPort.currentChange)

         Assert.equal(0x12, Model[0])
      }
      @Test fun Tuple_GetDataFormat_ReadsTuple() {
         ViewPort.edit("^table[a.|t|.|x:|.|y:]1 ")

         var anchor = ((ViewPort[0, 0].format) as Anchor)
         var tuple = (anchor.originalFormat as Tuple)

         Assert.equal("(0 0)", tuple.toString())
      }
      @Test fun Tuple_EditText_WritesTuple() {
         ViewPort.edit("^table[a.|t|.|x:|.|y:]1 ")

         ViewPort.edit("1 1 ")

         Assert.equal(0x12, Model[0])
         Assert.equal(1, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun Tuple_EditInline_AutocompleteForFirstElement() {
         Model.setList("options", listOf( "matchX", "Xmatch", "matXch", "other"))
         ViewPort.edit("^table[a:|t|x::options|y::]2 ")

         ViewPort.edit("match")

         var cell = ((ViewPort[0, 0].format) as UnderEdit)
         var options = cell.autocompleteOptions!!.map({ item -> item.displayText }).toTypedArray()
         Assert.equal(arrayOf( "matchX", "matXch", "Xmatch"), options) // sorted
      }
      @Test fun Tuple_ChooseInlineAutocompleteOption_StillEditing() {
         Model.setList("options", listOf( "matchX", "Xmatch", "matXch", "other"))
         ViewPort.edit("^table[a:|t|x::options|y::]2 ")

         ViewPort.edit("match")
         var cell = ((ViewPort[0, 0].format) as UnderEdit)
         ViewPort.autocomplete(cell.autocompleteOptions!![1].completionText)

         Assert.isType<UnderEdit>(ViewPort[0, 0].format)
      }
      @Test fun Tuple_ChooseFinalInlineAutocompleteOption_DoneEditing() {
         Model.setList("options", listOf( "matchX", "Xmatch", "matXch", "other"))
         ViewPort.edit("^table[a:|t|x::|y::options]2 ")

         ViewPort.edit("(3 match")
         var cell = ((ViewPort[0, 0].format) as UnderEdit)
         ViewPort.autocomplete(cell.autocompleteOptions!![1].completionText)

         Assert.isNotType<UnderEdit>(ViewPort[0, 0].format)
      }
      @Test fun Tuple_WriteWithNoParen_Commit() {
         Model.setList("options", listOf( "matchX", "Xmatch", "matXch", "other"))
         ViewPort.edit("^table[a:|t|x::|y::options]2 ")

         ViewPort.edit("3 Xmatch ")

         Assert.equal(0x13, Model[0])
      }
      @Test fun ElementsWithSpaces_TypeTuple_Works() {
         Model.setList("options", listOf( "simple", "with space", "other"))
         ViewPort.edit("^table[a:|t|x::options|y::]2 ")

         ViewPort.edit("(\"with space\" 2)")

         Assert.equal(0x21, Model[0])
      }
      @Test fun Tuple_TypeSpace_NoEdit() {
         ViewPort.edit("^table[a:|t|x::|y::]2 ")

         ViewPort.edit(" ")

         var cell = ViewPort[0, 0].format
         Assert.isNotType<UnderEdit>(cell)
      }
      @Test fun Tuple_TypePlus_NoEdit() {
         ViewPort.edit("^table[a:|t|x::|y::]2 ")

         ViewPort.edit("+")

         var cell = ViewPort[0, 0].format
         Assert.isNotType<UnderEdit>(cell)
      }
      @Test fun TupleInTableStream_TypeEndStreamAtStartOfElement_TruncateStream() {
         ViewPort.edit("@!put(FFFF) ^table[a:|t|x::|y::]!FFFF +(2 3) +(3 4) @02 ")

         ViewPort.edit("[]")

         var run = (Model.getNextRun(0) as TableStreamRun)
         Assert.equal(1, run.elementCount)
      }
      @Test fun TupleSyntax_ApplyToNormalElements_StillWorks() {
         Model.setList("options", listOf( "adam", "brad", "carl", "dave"))
         ViewPort.edit("^table[number: name:options]4 ")

         ViewPort.edit("(10 brad) (20 carl)")

         Assert.equal(10, Model[0])
         Assert.equal(1,  Model[2])
         Assert.equal(20, Model[4])
         Assert.equal(2,  Model[6])
      }
      @Test fun EnumTuple_Create_HasFilteredText() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         var tuple = EnumTupleElementViewModel(ViewPort, 0, 0, TupleSegment("name", 8, "names"), { }, { })
         Assert.equal("adam", tuple.filteringComboOptions.displayText)
      }
      @Test fun EnumTuple_ValueOutsideOptionsRange_FilteredTextIsNumber() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         Model[0]  = 9

         var tuple = EnumTupleElementViewModel(ViewPort, 0, 0, TupleSegment("name", 8, "names"), { }, { })

         Assert.equal("9", tuple.filteringComboOptions.displayText)
      }
      @Test fun TupleFormat_NoLengthForTupleValues_Error() {
         ViewPort.edit("^table[content:|t|a|b|c]1 ")
         Assert.single(Errors)
      }
      @Test fun TupleFormat_Serialize_ContainsLengthForFormat() {
         var segment = ArrayRunTupleSegment("evs", "|hp:|atk:|def:|spd:|spatk:|spdef:", 2)
         Assert.equal("evs:|t|hp:|atk:|def:|spd:|spatk:|spdef:", segment.serializeFormat)
      }

      private val TupleTable: TupleArrayElementViewModel get() = ((ViewPort.tools!!.tableTool!!.children.filter({ child -> child is TupleArrayElementViewModel }).single()) as TupleArrayElementViewModel)
   }
