@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class TableTests : BaseViewModelTestClass() {
      @Test fun TableCanHaveNumericLimitOnField() {
         ViewPort.edit("^table[data.4]8 ")
         Assert.empty(Errors)

         ViewPort.selectionStart  = Point(2, 0)
         ViewPort.edit("5 "); // you should still be able to manually enter bad values
         Assert.equal(5, Model[0x02])

         // a combobox is used for numeric limit fields
         ViewPort.tools!!.tableTool!!.children.single({ child -> child is ComboBoxArrayElementViewModel })
      }
      @Test fun TrainerPokemonTeamEnumSelectionSelectsEntireEnum() {
         ArrangeTrainerPokemonTeamData(0, 1)

         ViewPort.selectionStart  = Point(0, 6)

         Assert.equal(Point(1, 6), ViewPort.selectionEnd)
      }
      @Test fun HexEditingWorksForTrainerPokemon() {
         ArrangeTrainerPokemonTeamData(0, 1)

         ViewPort.selectionStart  = Point(TrainerPokemonTeamRun.pokemonFormat_PokemonStart, 6)
         ViewPort.edit("C ")

         Assert.equal(2, Model[0x60 + TrainerPokemonTeamRun.pokemonFormat_PokemonStart])
      }
      @Test fun CanExtendTrainerTeamViaStream() {
         ArrangeTrainerPokemonTeamData(0, 1)
         Model[0x6C]  = 0x0B; // add a random data value so that extending will cause moving

         ViewPort.selectionStart  = Point(0, 6)
         var streamTool = ViewPort.tools!!.stringTool
         streamTool!!.content  = "10 A${"\n"}10 B"

         Assert.notEqual(0x60, Model.readPointer(0x24))
      }
      @Test fun CanContractTrainerTeamViaStream() {
         ArrangeTrainerPokemonTeamData(0, 4)

         ViewPort.selectionStart  = Point(0, 6)
         var streamTool = ViewPort.tools!!.stringTool
         streamTool!!.content  = "10 A"

         Assert.equal(1, Model[TrainerPokemonTeamRun.trainerFormat_PokemonCountOffset])
      }
      @Test fun AppendViaTableToolUpdatesParent() {
         ArrangeTrainerPokemonTeamData(0, 2, 1)

         ViewPort.edit("@A8 "); // select last pokemon
         var tableTool = ViewPort.tools!!.tableTool
         tableTool!!.append.execute()

         Assert.equal(3, Model[TrainerPokemonTeamRun.trainerFormat_PokemonCountOffset])
      }
      @Test fun ChangePokemonCountUpdatesTrainerTeam() {
         ArrangeTrainerPokemonTeamData(0, 2, 2)

         // update count via table: child run should update
         var tool = ViewPort.tools!!.tableTool
         var childCountField = ((tool!!.children[tool!!.children.size - 3]) as FieldArrayElementViewModel)
         childCountField.content  = "3"
         Assert.equal(3, ((Model.getNextRun(0xA0) as ITableRun)).elementCount)

         // update count via inline: child run should update
         ViewPort.edit("@20 1 ")
         Assert.equal(1, ((Model.getNextRun(0xA0) as ITableRun)).elementCount)
      }
      @Test fun ChangePokemonCountChangesOtherTeamsWithSamePointer() {
         ArrangeTrainerPokemonTeamData(0, 2, 2)
         ViewPort.edit("@4C <0A0>")

         // update count via table: sibling should update
         var tool = ViewPort.tools!!.tableTool
         var childCountField = ((tool!!.children[tool!!.children.size - 3]) as FieldArrayElementViewModel)
         childCountField.content  = "3"
         Assert.equal(3, Model[0x48])

         // update count via inline: sibling should update
         ViewPort.edit("@20 1 ")
         Assert.equal(1, Model[0x48])
      }
      @Test fun ChangeStructTypeChangesTrainerTeam() {
         ArrangeTrainerPokemonTeamData(0, 2, 2)

         // update count via table: child run should update
         var tool = ViewPort.tools!!.tableTool
         var childCountField = ((tool!!.children[1]) as ComboBoxArrayElementViewModel)
         childCountField.selectedIndex  = 3
         Assert.equal(0x10, ((Model.getNextRun(0xA0) as ITableRun)).elementLength)

         // update count via inline: child run should update
         ViewPort.edit("@00 2 ")
         Assert.equal(0x08, ((Model.getNextRun(0xA0) as ITableRun)).elementLength)
      }
      @Test fun ChangeStructTypeChangesOtherTeamsWithSamePointer() {
         ArrangeTrainerPokemonTeamData(0, 2, 2)
         ViewPort.edit("@4C <0A0>")

         // update count via table: sibling should update
         var tool = ViewPort.tools!!.tableTool
         var childCountField = ((tool!!.children[1]) as ComboBoxArrayElementViewModel)
         childCountField.selectedIndex  = 3
         Assert.equal(3, Model[0x28])

         // update count via inline: sibling should update
         ViewPort.edit("@00 2 ")
         Assert.equal(2, Model[0x28])
      }
      @Test fun SimplifyStructTypeClearsExtraUnusedData() {
         ArrangeTrainerPokemonTeamData(TrainerPokemonTeamRun.include_MOVES, 2, 1)
         ViewPort.edit("@A0 ")
         var tool = ViewPort.tools!!.stringTool

         tool!!.content  = "10 A"

         Assert.equal(0, Model[TrainerPokemonTeamRun.trainerFormat_StructTypeOffset]); // the parent updated to type 0
         for (i in 8 until 0x20) { // 0x10 per pokemon for 2 pokemon
            Assert.equal(0xFF, Model[0xA0 + i]) // the child is just 8 bytes long but used to be 0x20 bytes long, so bytes 8 to 0x20 are all FF
         }
      }
      @Test fun ChangingTypeFromMovesToMovesAndItemsKeepsSameMoves() {
         ArrangeTrainerPokemonTeamData(TrainerPokemonTeamRun.include_MOVES, 1, 1)
         ViewPort.edit("@A0 ")
         var tool = ViewPort.tools!!.stringTool

         tool!!.content  = SplitLines("10 A;- w;- x;- y;- q")

         ViewPort.edit("@00 3 @trainertable/0/pokemon/0 ")

         var moves = tool!!.content.csSplit(charArrayOf( '\n', '\r'), 2)[1].trimEnd()
         Assert.equal("\n".join(listOf( "- w", "- x", "- y", "- q")), moves)
      }
      @Test fun CanCreateCustomNamedStreamsWithEndToken() {
         // Arrange: create some data near the start that could be a custom stream
         CreateTextTable("info", 0x100, *(Enumerable.Range(('a').code, 20).map({ c -> (c.toChar()).toString() }).toTypedArray()))
         Model[0x10]  = 0xFF
         Model[0x11]  = 0xFF

         // Act: create the custom stream
         ViewPort.edit("@00 ^bob[number: category:info]!FFFF ")

         // Assert: make sure the custom stream looks right
         var run = (Model.getNextRun(0) as ITableRun)
         Assert.equal(0x12, run.length)
         Assert.isAssignableFrom<IStreamRun>(run)
         Assert.equal(4, run.elementCount)
         Assert.equal(4, run.elementLength)

         var format = (run.createDataFormat(Model, 0x11) as EndStream)
         Assert.equal(0x10, format.source)
         Assert.equal(1, format.position)
         Assert.equal(2, format.length)

         // Assert: selecting the end token selects the entire token
         ViewPort.edit("@10 ")
         Assert.notEqual(ViewPort.selectionStart, ViewPort.selectionEnd)
      }
      @Test fun CanCreateTableStreamWithLengthFromParent() {
         // arrange: write the data for the table
         Model.writePointer(ViewPort.currentChange, 0x80, 0x00)
         Model.writeMultiByteValue(0x84, 4, ViewPort.currentChange, 4)

         // act: add the run
         ViewPort.edit("@80 ^table[data<[category.]/count> count::]1 ")

         // assert: make sure the custom stream looks right
         var run = (Model.getNextRun(0) as ITableRun)
         Assert.equal(4, run.length)
         Assert.isAssignableFrom<IStreamRun>(run)
         Assert.equal(4, run.elementCount)
         Assert.equal(1, run.elementLength)
      }
      @Test fun CanExtendTableStreamWithEndToken() {
         ViewPort.edit("@10 FF FF FF FF @00 ^bob[number.]!FF ")

         ViewPort.edit("@10 +")

         var run = (Model.getNextRun(0) as ITableRun)
         Assert.equal(0x11, run.elementCount)
      }
      @Test fun CanExtendTableStreamWithLengthFromParent() {
         ViewPort.edit("FF FF FF FF FF FF FF FF @80 <0> 02 @80 ^table[data<[value.]/count> count::]1 ")

         ViewPort.edit("@02 +")

         var run = (Model.getNextRun(0) as ITableRun)
         Assert.equal(3, run.elementCount)
         Assert.equal(3, Model[0x84])
      }
      @Test fun CanExtendTableStreamWithLengthFromParentFromParent() {
         ViewPort.edit("FF FF FF FF FF FF FF FF @80 <0> 02 @80 ^table[data<[value.]/count> count::]1 ")

         ViewPort.edit("@84 3 ")

         var run = (Model.getNextRun(0) as ITableRun)
         Assert.equal(3, run.elementCount)
         Assert.equal(3, Model[0x84])
      }
      @Test fun CannotExtendLengthOfFixedLengthStreamViaTool() {
         // Arrange
         ViewPort.edit("FF FF FF FF FF FF FF FF @80 <0> @80 ^table[data<[value.]5>]1 ")
         var segment = ViewPort.tools!!.tableTool!!.children.filterIsInstance<TextStreamElementViewModel>().single()

         // precondition: the format is as expected
         Assert.equal(SplitLines("255;255;255;255;255"), segment.content)

         // Act: change the content in a way that would change the length of a more dynamic stream.
         segment.content  = "12"

         // Assert that the stream length is still 5.
         var result = (Model.getNextRun(0) as ITableRun)
         Assert.equal(5, result.elementCount)
      }
      @Test fun AddingArrayWithPointerToStreamWithPointersAlsoAddsAnchorsForThosePointers() {
         ViewPort.edit("1A 00 00 08 @33 08"); // 00 will point to 1A, 30 will point to 00

         ViewPort.edit("@30 ^table[pointer<[inner<>]1>]1 "); // this table is a pointer that points to a pointer

         Assert.equal(0x1A, Model.getNextRun(0x1A).start)
      }
      @Test fun CanCreateDataFromNull() {
         for (i in 0x80 until Model.rawData.size) Model.rawData[i]  = 0xFF.toByte()
         ViewPort.edit("^table[number: value: pointer<\"\">]8 @04 ")

         // verify that it's in the context menu
         var items = ViewPort.getContextMenuItems(Point(4, 0)).toMutableList()
         var group = (items.single({ menuItem -> menuItem.text == "Pointer Operations" }) as ContextItemGroup)
         var createNewItem = group.single({ item -> item.text == "Create New Data" })

         // verify that it's in the table
         var toolElements = ViewPort.tools!!.tableTool!!.children
         var createNewTool = ((toolElements.single({ element -> element  is TextStreamElementViewModel && (element as TextStreamElementViewModel).canCreateNew })) as TextStreamElementViewModel)

         // verify that the command works
         createNewItem.command.execute()
         Assert.notEqual(0, Model.readValue(0x04))
         var run = ((Model.getNextRun(Model.readPointer(0x04))) as PCSRun)
         Assert.equal(1, run.length)

         // verify that you can't use the table tool's version anymore
         Assert.isFalse(createNewTool.canRepoint)
      }
      @Test fun CanGetOptionsFromStringPointerTable() {
         ViewPort.edit("^aSpot FF @aSpot ^aSpot\"\" Content1\""); // 9 bytes
         ViewPort.edit("^bSpot FF @bSpot ^bSpot\"\" Content2\""); // 9 bytes
         ViewPort.edit("^cSpot FF @cSpot ^cSpot\"\" Content3\""); // 9 bytes
         ViewPort.edit("@20 <aSpot> <bSpot> <cSpot> @20 ")
         ViewPort.edit("^table[pointer<\"\">]3 "); // 12 bytes

         (ModelCacheScope.createScope(Model)).use { _ ->
            var options = ModelCacheScope.getCache(Model).getOptions("table")
            Assert.equal(3, options.size)
            Assert.equal("Content1", options[0])
            Assert.equal("Content2", options[1])
            Assert.equal("Content3", options[2])
          }
      }
      @Test fun CanClearBitOptions() {
         CreateTextTable("source", 0x100, "Apple", "Banana", "Coconut", "Durian")
         CreateBitArrayTable("test", 0x20, "source", 0x5, 0xA, 0xC, 0x3)

         ViewPort.edit("@test/1 -")
         Assert.equal(0x0, Model[0x21])
      }
      @Test fun CanSetBitOptions() {
         CreateTextTable("source", 0x100, "Apple", "Banana", "Coconut", "Durian")
         CreateBitArrayTable("test", 0x20, "source", 0x5, 0xA, 0xC, 0x3)

         ViewPort.edit("@test/1 apple ")
         Assert.equal(0xB, Model[0x21])
      }
      @Test fun EnumFromRandomTableHasValues() {
         ViewPort.edit("^primes[value.]10 @20 ^child[element:primes]13 ")
         var viewModel = (ViewPort.tools!!.tableTool!!.children.single({ child -> child is ComboBoxArrayElementViewModel }) as ComboBoxArrayElementViewModel)
         Assert.equal(10, viewModel.options.size)
      }
      @Test fun CanEditInlineWithCommas() {
         ViewPort.edit("^table[a. b.]10 0,0 1,1 2,2 3,3 4,4 5,5 6,6 7,7 8,8 ")
         Assert.equal(4, Model[8])
      }
      @Test fun EnumGotoJumpsToSelectedElement() {
         CreateTextTable("names", 0x00, "Adam", "Bob", "Carl")
         CreateEnumTable("enums", 0x10, "names", 2, 2, 2)

         ViewPort.goto!!.execute(0x10)
         var enumSegment = ViewPort.tools!!.tableTool!!.children.filterIsInstance<ComboBoxArrayElementViewModel>().single()
         enumSegment.gotoSource.execute()

         Assert.equal(10, ViewPort.dataOffset)
      }
      @Test fun AddNewToTableWithPlusLength() {
         // arrange: make a table, and then another table with +1 length
         CreateTextTable("names", 0x00, "Adam", "Bob", "Carl")
         ViewPort.edit("@20 ^data[value:]names+1 00 10 20 40 ")

         // act: extend both tables
         ViewPort.edit("@0F +")

         // assert: the new element was inserted, not appended, to the +1 table.
         // this keeps the +1 element at the end.
         Assert.equal(20, Model.readMultiByteValue(0x20 + 2 * 3, 2))
         Assert.equal(40, Model.readMultiByteValue(0x20 + 2 * 4, 2))
      }
      @Test fun RepointToOffScreenScrollsWell() {
         ViewPort.useCustomHeaders  = false
         CreateTextTable("names", 0x00, "Audacity", "Bloomer", "Captain", "Dodongo", "Elephant")
         ViewPort.edit("@30 22 "); // data at 48, to get in the way of an expand

         ViewPort.edit("@names/5 +"); // do an expand

         var table = Model.getTable("names")
         var newAddress = table!!.start + table!!.elementLength * 5
         Assert.equal(0, ViewPort.selectionStart.x); // new element should be at start of line
         Assert.equal(ViewPort.headers!![ViewPort.selectionStart.y], newAddress.toString("X6")) // selection should be at start of new element
      }
      @Test fun ExpandTableViaAnchorEditorDoesNotRepointTables() {
         // setup some default tables
         ViewPort.edit("@00 ^parent[items:]10 ")
         ViewPort.edit("@40 ^child[items:]parent ")

         // setup some data that's part of the tables, but wasn't recognized.
         ViewPort.edit("@14 20 00 @54 20 00 ")

         // Act: edit the anchor, which should not change any data, but just is a way for the user to express that the anchor was wrong.
         ViewPort.edit("@00 ")
         ViewPort.anchorText  = "parent[items:]12"

         // Assert: the tables didn't move, but are longer
         Assert.equal(0x00, Model.getAddressFromAnchor(ViewPort.currentChange, -1, "parent"))
         Assert.equal(0x40, Model.getAddressFromAnchor(ViewPort.currentChange, -1, "child"))
         Assert.equal(12 * 2, Model.getNextRun(0x00).length)
         Assert.equal(12 * 2, Model.getNextRun(0x40).length)
      }
      @Test fun Enum_Tooltip_ShowsText() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl")
         CreateEnumTable("enums", 0, "names", 0, 1, 2)
         ViewPort.refresh()
         var cell = ViewPort[1, 0]

         var tooltipVisitor = ToolTipContentVisitor(Model)
         cell.format!!.visit(tooltipVisitor, cell.value)
         var content = tooltipVisitor.content.single().toString()

         Assert.equal("adam", content)
      }
      @Test fun TrainerTeam_ExpandPokemon_NewPokemonHasValidValues() {
         ArrangeTrainerPokemonTeamData(0, 3, 3)

         ViewPort.edit("@trainertable/0/pokemon/3 10 ");       // put some random data after the run, so that expanding causes a repoint
         ViewPort.edit("@trainertable/0/pokemon/2 0 10 F 0 "); // write some dummy data to the run so it's not just all 0's
         var currentLocation = ViewPort.dataOffset
         ViewPort.edit("+");                                   // expand the trainer's pokemon

         var trainers = (Model.getNextRun(0) as ITableRun)
         var destination = Model.readPointer(trainers.elementLength - 4)
         var team = (Model.getNextRun(destination) as ITableRun)

         Assert.all(Enumerable.Range(team.start + team.elementLength * 3, team.elementLength),
            { i -> Assert.equal(Model[i - team.elementLength], Model[i]) })
         Assert.notEqual(currentLocation, ViewPort.dataOffset)
      }
      @Test fun BitArray_Edit_Autocomplete() {
         CreateTextTable("names", 0x100, "beforeTEXT", "TEXTafter", "TEmiddleXT", "somethingelse")
         CreateEnumTable("enums", 0x180, "names", 0, 1, 2, 3)
         CreateBitArrayTable("bits", 0, "enums", 0x1, 0x2, 0x4, 0x8)
         ViewPort.refresh()

         ViewPort.edit("TEXT")

         var cell = ((ViewPort[0, 0].format) as UnderEdit)
         var options = cell.autocompleteOptions!!.map({ option -> option.completionText.trim() }).toTypedArray()
         Assert.equal(arrayOf( "TEXTafter", "TEmiddleXT", "beforeTEXT"), options) // sorted
      }
      @Test fun Table_DeepCopy_IncludesMetacommandToBlankTheData() {
         SetFullModel(0xFF)
         var fs = StubFileSystem()
         CreateTextTable("names", 0, "adam", "bob", "carl", "dave"); // 5*4 bytes long
         ViewPort.refresh()

         ViewPort.edit("@00 ")
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(Model.getNextRun(0).length - 1)
         ViewPort.deepCopy.execute(fs)

         Assert.startsWith("@!00(20) ^names", fs.copyText)
      }
      @Test fun MultipleTables_CheckTableSelector_TablesSortedAlphabetically() {
         CreateTextTable("xxx.yyy.zzz", 0x40, "adam", "bob", "carl", "steve")
         CreateTextTable("iii.jjj.kkk", 0x80, "adam", "bob", "carl", "steve")
         CreateTextTable("aaa.bbb.ccc", 0xC0, "adam", "bob", "carl", "steve")

         var tableSections = ViewPort.tools!!.tableTool!!.tableSections
         var sortedSection = tableSections.toMutableList()
         sortedSection.sort()

         Assert.all(tableSections.size.range(), { i -> Assert.equal(sortedSection[i], tableSections[i]) })
      }
      @Test fun MultipleTableList_CheckTableList_TablesSortedAlphabetically() {
         CreateTextTable("aaa.bbb.zzz", 0x40, "adam", "bob", "carl", "steve")
         CreateTextTable("aaa.bbb.kkk", 0x80, "adam", "bob", "carl", "steve")
         CreateTextTable("aaa.bbb.ccc", 0xC0, "adam", "bob", "carl", "steve")
         ViewPort.tools!!.tableTool!!.selectedTableSection  = 0

         var tableList = ViewPort.tools!!.tableTool!!.tableList
         var sortedTables = tableList.toMutableList()
         sortedTables.sort()

         Assert.all(tableList.size.range(), { i -> Assert.equal(sortedTables[i], tableList[i]) })
      }
      @Test fun PointersToTextInTable_RepointTable_PointersUpdate() {
         SetFullModel(0xFF)
         CreateTextTableWithInnerPointers("table", 0x20, "adam", "bob", "carl", "1234567")
         ViewPort.edit("@00!00(16) ^pointers[ptr<>]4 <000048> <000028> <000030> <000010> @40 10")
         var table = (Model.getTable("table") as ArrayRun)
         Assert.equal(arrayOf( 0, 1, 1, 0), table.pointerSourcesForInnerElements!!.map({ sources -> sources.size }).toTypedArray())

         ViewPort.goto!!.execute("table")
         ViewPort.edit(ConsoleKey.End)
         ViewPort.tools!!.tableTool!!.append.execute()

         table  = (Model.getTable("table") as ArrayRun)
         Assert.equal(table.start + table.elementLength, Model.readPointer(4))
         Assert.equal(table.start + table.elementLength * 2, Model.readPointer(8))
      }
      @Test fun BitArray_SetValueIn5thByte_ByteChanges() {
         CreateTextTable("text", 0x40, *38.range().map({ i -> "entry" + i }).toTypedArray())
         CreateEnumTable("enums", 0x180, "text", *38.range().toList().toIntArray())
         CreateBitArrayTable("bits", 0, "enums", 0, 0, 0, 0)
         ViewPort.refresh()

         ViewPort.edit("entry34 ")

         Assert.equal(0x4, Model[4])
      }
      @Test fun TextTable_MakeEnumTableWithOffset_ValuesAppearCorrectly() {
         CreateTextTable("text", 0x80, *10.range().map({ i -> "entry" + i }).toTypedArray())
         ViewPort.refresh()

         ViewPort.edit("@00 0A 0B 0C")
         ViewPort.edit("@00 ^enums[entry.text+10]3 ")

         var segment = ((Model.getTable("enums")!!.elementContent[0]) as ArrayRunEnumSegment)
         Assert.equal("text", segment.enumName)
         Assert.equal(10, segment.valueOffset)
         var cell = ((ViewPort[1, 0].format) as IntegerEnum)
         Assert.equal("entry1", cell.displayValue)
      }
      @Test fun EnumTableWithOffset_Edit_ValueAppearsCorrectly() {
         CreateTextTable("text", 0x80, *10.range().map({ i -> "entry" + i }).toTypedArray())
         ViewPort.refresh()
         ViewPort.edit("@00 0A 0B 0C")
         ViewPort.edit("@00 ^enums[entry.text+10]3 ")

         ViewPort.selectionStart  = Point(1, 0)
         ViewPort.edit("entry7 ")

         var cell = ((ViewPort[1, 0].format) as IntegerEnum)
         Assert.equal("entry7", cell.displayValue)
      }
      @Test fun MatchedTable_MinusFrontAndBack_ElementsCorrect() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")

         ViewPort.edit("@00 ^table[field.]names-1-1 ")

         var table = (Model.getTable("table") as ArrayRun)
         Assert.equal(2, table.elementCount)
         Assert.equal("bob", table.elementNames!![0])
         Assert.equal("carl", table.elementNames!![1])
      }
      @Test fun MatchedTableWithMinusEnd_AppendTwo_NoMinus() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         ViewPort.edit("@00 ^table[field.]names-0-2 ")

         ViewPort.goto!!.execute("names")
         for (d in arrayOf<Any>( Direction.End, Direction.Right)) ViewPort.moveSelectionStart.execute(d)
         ViewPort.edit("+")

         var table = (Model.getTable("table") as ArrayRun)
         Assert.equal(ParentOffset.default, table.parentOffset)
         Assert.endsWith("names", table.formatString)
         Assert.equal(5, table.elementCount)
      }
      @Test fun TextTable_QuoteTwice_MoveToNextElement() {
         CreateTextTable("names", 0x0, "adam", "bob", "carl", "dave")
         ViewPort.goto!!.execute(0)

         ViewPort.edit("\"\"")

         var selectedAddress = ViewPort.convertViewPointToAddress(ViewPort.selectionStart)
         Assert.equal(5, selectedAddress)
      }
      @Test fun TextTableWithInnerPointers_CutPaste_InnerPointersMove() {
         SetFullModel(0xFF)
         var fileSystem = StubFileSystem()
         ViewPort.edit("^table^[name\"\"16]2 \"Alpha\" \"Beta\"")
         ViewPort.edit("@40 <0000> <0010>")

         // cut
         ViewPort.goto!!.execute(0)
         ViewPort.selectionEnd  = ViewPort.convertAddressToViewPoint(0x20 - 1)
         ViewPort.copy!!.execute(fileSystem)
         ViewPort.clear!!.execute()

         // paste
         ViewPort.goto!!.execute(0x60)
         ViewPort.edit(fileSystem.copyText!!)

         Assert.equal(0x60, Model.readPointer(0x40))
         Assert.equal(0x70, Model.readPointer(0x44))
      }
      @Test fun TableWithNegativeOffset_ShrinkParentTableSuchThatChildTableHasNegativeLength_ChildTableHasLengthOne() {
         CreateTextTable("names", 0, "adam", "bob", "carl", "dave")
         ViewPort.edit("@100 ^child[a.]names-1-1 ")

         ViewPort.goto!!.execute(0)
         var text = ViewPort.anchorText
         ViewPort.anchorText  = text.substring(0, text.length - 1) + "1"

         var table = Model.getTable("child")
         Assert.equal(1, table!!.elementCount)
      }
      @Test fun TableWithNegativeOffset_ShrinkAndGrowParent_ChildLengthRestored() {
         CreateTextTable("names", 0, "adam", "bob", "carl", "dave")
         ViewPort.edit("@100 ^child[a.]names-1-1 ")

         ViewPort.goto!!.execute(0)
         var text = ViewPort.anchorText
         text  = text.substring(0, text.length - 1)
         ViewPort.anchorText  = text + "1"
         ViewPort.anchorText  = text + "4"

         var table = Model.getTable("child")
         Assert.equal(2, table!!.elementCount)
      }
      @Test fun IntTable_Sort_ValuesSorted() {
         ViewPort.edit("^table[a:]3 10 12 11 ")

         var table = Model.getTable("table")
         var newData = table!!.sort(Model, 0)
         ViewPort.currentChange.changeData(Model, 0, newData)

         Assert.equal(10, Model.readMultiByteValue(0, 2))
         Assert.equal(11, Model.readMultiByteValue(2, 2))
         Assert.equal(12, Model.readMultiByteValue(4, 2))
      }
      @Test fun PointerTable_RequestHeaderForDestination_GetTableIndexName() {
         Model.setList("options", listOf( "Adam", "Bob", "Carl", "Dave"))
         ViewPort.edit("^table[entry<>]options <100> <120> <140> <160>")

         val header = Ref<String?>(null)
         Model.tryGetUsefulHeader(0x120, header)

         Assert.equal("Bob", header.value)
      }
      @Test fun CalculatedSegment_CheckValue_IsCalculated() {
         ViewPort.edit("^table[a: c|=a*b b:]2 3 4 @table ")
         var table = Model.getTable("table")
         var segment = ((table!!.elementContent[1]) as ArrayRunCalculatedSegment)
         var viewmodel = (ViewPort.tools!!.tableTool!!.children.single({ vm -> vm is CalculatedElementViewModel }) as CalculatedElementViewModel)

         Assert.equal(12, segment.calculatedValue(0))
         Assert.equal(12, table!!.readValue(Model, 0, "c"))
         Assert.equal("12", viewmodel.calculatedValue)
      }
      @Test fun CalculatedSegment_CalculateSource_GetSource() {
         ViewPort.edit("^table[a: c|=a*b b:]2 3 4 ")
         var table = Model.getTable("table")

         var source: Int = ArrayRunCalculatedSegment.calculateSource(Model, table, 0, "b")

         Assert.equal(2, source)
      }
      @Test fun CalculatedSegment_CheckNestedValueFromEnum_IsCalculated() {
         CreateTextTable("names", 0x180, "adam", "bob", "carl")
         ViewPort.edit("@100 ^correlate[data:names number:]4 carl 10 bob 5 ")
         ViewPort.edit("@00 ^table[thing:names calc|=(correlate/data=thing)/number]2 bob ")

         var table = Model.getTable("table")
         var segment = ((table!!.elementContent[1]) as ArrayRunCalculatedSegment)
         var value = segment.calculatedValue(0)

         Assert.equal(5, value)
      }
      @Test fun CalculatedSegment_CheckNestedValueFromPointer_IsCalculated() {
         ViewPort.edit("@100 ^destination[data: number:]4 1 2 3 4 ")
         ViewPort.edit("@00 ^table[thing<> calc|=thing/1/data]2 <100> ")

         var table = Model.getTable("table")
         var segment = ((table!!.elementContent[1]) as ArrayRunCalculatedSegment)
         var value = segment.calculatedValue(0)

         Assert.equal(3, value)
      }
      @Test fun CalculatedSegment_SourceTableDoesNotExist_NoSource() {
         var contract = "(not.a.table/field1=content)/field2"

         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "[content:]1", 0, null, table)
         var source = ArrayRunCalculatedSegment.calculateSource(Model, table.value, 0, contract)

         Assert.equal(Pointer.null_, source)
      }
      @Test fun CalculatedSegment_SourceTableDoesNotExist_NoJump() {
         var contract = "(not.a.table/field1=content)/field2"

         var segment = ArrayRunCalculatedSegment(Model, "name", contract)
         var viewModel = CalculatedElementViewModel(ViewPort, segment, 0)

         Assert.isFalse(viewModel.operands[0].jumpTo.canExecute(null))
      }
      @Test fun CalculatedSegment_SourceTableDoesNotExist_CanCalculate() {
         var contract = "(not.a.table/field1=content)/field2"
         Model.observeRunWritten(Token, TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[content:]", null, FixedLengthStreamStrategy(1)))
         var segment = ArrayRunCalculatedSegment(Model, "name", contract)

         var value = segment.calculatedValue(0)

         Assert.equal(0, value)
      }
      @Test fun CalculatedSegment_SourceTableDoesNotHaveMatch_UseLastValue() {
         ViewPort.edit("@100 ^some.table[key: value:]2 1 1 2 2 ")
         var contract = "(some.table/key=content)/value"
         Model.observeRunWritten(Token, TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[content:]", null, FixedLengthStreamStrategy(1)))
         var segment = ArrayRunCalculatedSegment(Model, "name", contract)

         var value = segment.calculatedValue(0)

         Assert.equal(2, value)
      }
      @Test fun ZeroWidthSegment_GetColumnHeaders_NoHeaderForZeroWidthColumn() {
         ViewPort.edit("^table[a: b|=a c:]2 ")
         var table = (Model.getTable("table") as ArrayRun)

         var headers = table.getColumnHeaders(4, 0)!![0].columnHeaders
         Assert.equal(2, headers.size)
         Assert.equal("a", headers[0].columnTitle)
         Assert.equal("c", headers[1].columnTitle)
      }
      @Test fun TextTable_ChangeText_HeaderChanges() {
         ViewPort.allowMultipleElementsPerLine  = false
         ViewPort.useCustomHeaders  = true
         CreateTextTable("table", 0, "adam", "bob", "carl", "dave")
         ViewPort.goto!!.execute("table/bob ")

         ViewPort.edit("B")

         Assert.equal("Bob", ViewPort.headers!![0])
      }
      @Test fun CalculatedSegment_Serialize_ReasonableText() {
         var segment = ArrayRunCalculatedSegment(Model, "bob", "4+a")
         Assert.equal("bob|=4+a", segment.serializeFormat)
      }
      @Test fun CreateTable_BadEndTokenFormat_NoCrash() {
         ViewPort.edit("^table[a:]1 ")
         ViewPort.anchorText  = "^table[a:]!"
         Assert.single(Errors)
      }
      @Test fun Table_SignedIntFormat_NumbersCanBeNegative() {
         ViewPort.edit("^table[a.|z b:|z c::|z]1 -1 -2 -3 ")
         var table = Model.getTable("table")
         Assert.equal(0xFF, Model[0])
         Assert.equal(0xFFFF - 1, table!!.readValue(Model, 0, 1))
         Assert.equal(-3, Model.readValue(3))
         Assert.equal(-2, (((ViewPort[1, 0].format) as Integer)).value)
      }
      @Test fun TableMatchedToConstant_IncreaseConstantCausesRepoint_NotifyUserOfRepoint() {
         SetFullModel(0xFF)
         ViewPort.edit("@10 .table.count 12 @20 ^table[data::]table.count @50 DEADBEEF ")
         var count = 0
         ViewPort.onMessage  += { sender, e -> count  += 1 }

         ViewPort.edit("@10 13 ")

         Assert.equal(1, count)
      }
      @Test fun TableWithLengthOffset_FindElementReferences_NewTabNameCorrect() {
         var newTab: IViewPort? = null
         ViewPort.requestTabChange  += { sender, tab -> newTab  = (tab.newTab as IViewPort) }
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave", "erik", "fred", "greg", "hal")
         ViewPort.edit("@00 ^table1[data:]names-1 @20 ^table2[value:names]4 dave carl erik dave ")

         ViewPort.goto!!.execute("table1/dave"); // goto 'dave' in table1
         var buttons = ViewPort.tools!!.tableTool!!.usageChildren.filter({ child -> child is ButtonArrayElementViewModel }).filterIsInstance<ButtonArrayElementViewModel>().toMutableList()
         buttons.single({ button -> button.text!!.contains("table2") }).command.execute()

         Assert.contains("dave", newTab!!.name)
      }
      @Test fun TableWithEndToken_TypeEndToken_MoveCursor() {
         ViewPort.edit("^table[content:]!0000 ")

         ViewPort.edit("[]")

         Assert.equal(Point(2, 0), ViewPort.selectionStart)
      }
      @Test fun Anchor_UpdateTablePointerToAnchor_AnchorExists() {
         ViewPort.edit("@00 ^inner ")
         ViewPort.edit("@10 ^outer[ptr<[a.]1>]1 ")

         ViewPort.edit("<inner>")

         Assert.equal(0, Model.readPointer(0x10))
         Assert.equal("inner", Model.getAnchorFromAddress(-1, 0))
      }
      @Test fun TablePointingToNamedAnchor_Extend_AnchorIsStillNamed() {
         ViewPort.edit("@00 ^inner ")
         ViewPort.edit("@10 ^outer[ptr<[a.]1>]1 <inner> ")

         ViewPort.edit("+")

         Assert.equal(0, Model.readPointer(0x10))
         Assert.equal(0, Model.readPointer(0x14))
         Assert.equal("inner", Model.getAnchorFromAddress(-1, 0))
      }
      @Test fun TwoTablePointersToSameAddress_ReplaceOneWithNull_DestinationUpdates() {
         ViewPort.edit("^table[ptr<>]2 <010> <010> ")

         ViewPort.edit("@table <null> ")

         var run = Model.getNextRun(0x10)
         Assert.single(run.pointerSources)
      }
      @Test fun SplitterSegment_Serialize_NoCrash() {
         var segment = ArrayRunSplitterSegment()

         var format = segment.serializeFormat

         Assert.equal("|", format)
      }
      @Test fun TableWithNoName_FindRelatedTables_NoTablesRelated() {
         val table1 = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "[data:]4", 0x100, SortedSpan<Int>.none(), table1)
         val table2 = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "[data:]4", 0x180, SortedSpan<Int>.none(), table2)
         Model.observeAnchorWritten(Token, "", table1.value!!)
         Model.observeAnchorWritten(Token, "some.name", table2.value!!)

         var related = Model.getRelatedArrays((table1.value as ArrayRun)).toMutableList()

         Assert.equal(arrayOf( (table1.value as ArrayRun)), related)
      }
      @Test fun TableWithPointersToSelf_Repoint_AnchorUpdated() {
         SetFullModel(0xFF)
         ViewPort.edit("^table[data:: ptr<>]2 13 <table> 14 <table> DEADBEEF ")

         ViewPort.edit("@010 +")

         var table = Model.getTable("table")
         var source1 = table!!.start + 4
         var source2 = table!!.start + 12
         var source3 = table!!.start + 20
         Assert.equal(arrayOf( source1, source2, source3), table!!.pointerSources)
      }
      @Test fun TablePointersToNamedSprites_UpdatePointerToNamedSprite_NoNull() {
         Token.changeData(Model, 0, LZRun.compress(ByteArray(32).asByteList()))
         ViewPort.refresh()
         ViewPort.shortcuts.displayAsSprite.execute()
         ViewPort.edit("@100 ^table[ptr<`lzs4x1x1`>]2 <000> <null> ")
         ViewPort.edit("@000 ^some.name ")

         ViewPort.edit("@104 <some.name> ")

         Assert.equal("some.name", Model.getAnchorFromAddress(-1, 0))
         Assert.equal(0, Model.readPointer(0x100))
         Assert.equal(0, Model.readPointer(0x104))
      }
      @Test fun MetadataHasTwoCloseTablesWithOverlappingConstantLength_Load_KeepSecondTableWithPointer() {
         Model.writePointer(Token, 0x100, 0x10); // pointer to table1
         Model.writePointer(Token, 0x110, 0x20); // pointer to table2 (16 bytes after table1)
         Model[0x120]  = 6;                       // table length (24 bytes)

         var metadata = StoredMetadata(
            anchors = (arrayOf<StoredAnchor>( StoredAnchor(0x10, "table1", "[a::]constant"), StoredAnchor(0x20, "table2", "[b::]constant"))).toList(),
            matchedWords = listOf( StoredMatchedWord(0x120, "constant", 1, 0, 1, "note")))
         var model = PokemonModel(Model.rawData, metadata, Singletons)

         var pointerRun = model.getNextRun(0x110)
         Assert.isType<PointerRun>(pointerRun)
         Assert.equal(0x110, pointerRun.start)
      }
      @Test fun MetadataHasTwoCloseTablesWithBarelyOverlappingConstantLength_Load_KeepSecondTableWithPointer() {
         Model.writePointer(Token, 0x100, 0x10); // pointer to table1
         Model.writePointer(Token, 0x110, 0x20); // pointer to table2 (16 bytes after table1)
         Model[0x120]  = 5;                       // table length (24 bytes)

         var metadata = StoredMetadata(
            anchors = (arrayOf<StoredAnchor>( StoredAnchor(0x10, "table1", "[a::]constant"), StoredAnchor(0x20, "table2", "[b::]constant"))).toList(),
            matchedWords = listOf( StoredMatchedWord(0x120, "constant", 1, 0, 1, "note")))
         var model = PokemonModel(Model.rawData, metadata, Singletons)

         var pointerRun = model.getNextRun(0x110)
         Assert.isType<PointerRun>(pointerRun)
         Assert.equal(0x110, pointerRun.start)
      }
      @Test fun MetadataHasTwoCloseTablesWithOverlappingParentTableLength_ParentTableConstantLoad_KeepSecondTableWithPointer() {
         ViewPort.edit("@000 ^child1[a::]parent @010 ^child2[b::]parent @080 <child1> <child2> ")

         val parent = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "[a::]5", 0x100, SortedSpan<Int>.none(), parent)
         Model.observeAnchorWritten(NoDataChangeDeltaModel(), "parent", parent.value!!)

         Model.resolveConflicts()
         Assert.isType<NoInfoRun>(Model.getNextRun(0))
         Assert.isAssignableFrom<ITableRun>(Model.getNextRun(0x10))
      }
      @Test fun ChildWithLengthFromParent_ParentWithConstantLength_GetRelatedArraysFindsChild() {
         ViewPort.edit("@00 .some.constant 5 ")
         ViewPort.edit("@10 ^parent[a:]some.constant ")
         ViewPort.edit("@20 ^child[a:]parent ")

         var relatedArrays = Model.getRelatedArrays((Model.getTable("parent") as ArrayRun)).toMutableList()

         Assert.equal(2, relatedArrays.size)
      }
      @Test fun AnchorFormat_TableWithNoContent_DoesNotParse() {
         var error = ArrayRun.tryParse(Model, "[]3", 0, SortedSpan<Int>.none(), Ref(nullOf()))
         Assert.isTrue(error.hasError)
      }
      @Test fun AnchorFormat_TableStreamWithNoContent_DoesNotParse() {
         val table = Ref<ITableRun?>(null)
         var error = ArrayRun.tryParse(Model, "[]!00", 0, SortedSpan<Int>.none(), table)
         Assert.isTrue(error.hasError)
      }
      @Test fun TableContent_CopyNotWholeTable_DoNotIncludeAnchorContentInClipboard() {
         var nl = "\n"
         ViewPort.edit("^table[a: b:]3 1 2 3 4 5 6 ")

         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.selectionEnd  = newOf(7, 0)
         ViewPort.copy!!.execute(FileSystem)

         Assert.equal("1, 2${nl}+3, 4${nl}", FileSystem.copyText.value)
      }
      @Test fun NameWithDash_Goto_Goto() {
         CreateTextTable("table", 0x100, "some", "option", "ho-oh", "steve")

         ViewPort.goto!!.execute("ho-oh")

         Assert.equal(2, ViewPort.tools!!.tableTool!!.currentElementSelector.selectedIndex)
      }
      @Test fun OptionsWithPercentSign_EnterOption_ValueChanges() {
         Model.setList(Token, "gender", "10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%")

         ViewPort.edit("^table[option:gender]2 30% ")

         Assert.equal(2, Model[0])
      }
      @Test fun OptionsWithAmpersand_EnterOption_ValueChanges() {
         Model.setList(Token, "gender", "1&2", "3&4", "5&6", "7&8")

         ViewPort.edit("^table[option:gender]2 5&6 ")

         Assert.equal(2, Model[0])
      }
      @Test fun TableWithTableStreamChild_IncreaseLengthCausesRepoint_NoAssert() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 <180> <1C0> DEAD @00 <100> 02 @00 ^table[child<[text<\"\">]/count> count.]1 ")

         ViewPort.edit("@04 3 ")

         Model.resolveConflicts()
      }
      @Test fun TableStreamRun_Clone_SameLength() {
         SetFullModel(0xFF)
         ViewPort.edit("<100> 01 @00 ^parent[child<[a.]/count> count.]1 ")
         Model.rawData[4]  = 2

         var childTable = (Model.getNextRun(0x100) as ITableRun)
         var clone = (childTable.duplicate(0x100, childTable.pointerSources) as ITableRun)

         Assert.equal(childTable.elementCount, clone.elementCount)
      }
      @Test fun SingleTableMode_AppendMoveTableStream_SelectionFollowsTable() {
         SetFullModel(0xFF)
         ViewPort.allowSingleTableMode  = true
         ViewPort.freeSpaceStart  = 0x100
         ViewPort.edit("01 02 03 FF DEAD @00 ^table[a.]!FF ")

         ViewPort.edit("@03 +")

         Assert.single(Messages)
         Assert.inRange(ViewPort.dataOffset, 0x10, 0x200)
      }
      @Test fun SingleTableMode_ExtendTableNoRepoint_VisibleSpaceExpands() {
         SetFullModel(0xFF)
         ViewPort.allowSingleTableMode  = true
         ViewPort.edit("01 02 03 @00 ^table[a.]!FF ")

         ViewPort.edit("@03 +")

         Assert.isType<EndStream>(ViewPort[1, 0].format)
      }
      @Test fun TwoTablesWithLengthFromConstant_ExpandOneTable_BothTablesAndConstantChanged() {
         SetFullModel(0xFF)
         Model[0x20]  = 2
         ViewPort.edit("@20 .constant.value ")
         ViewPort.edit("@00 ^table1[a.]constant.value ")
         ViewPort.edit("@10 ^table2[b.]constant.value ")

         ViewPort.edit("@02 +")

         Assert.equal(3, Model.getTable("table1")!!.elementCount)
         Assert.equal(3, Model.getTable("table2")!!.elementCount)
         Assert.equal(3, Model[0x20])
      }
      @Test fun TwoTablesWithLengthFromContstant_ExpandConstant_BothTablesAndConstantChanged() {
         SetFullModel(0xFF)
         Model[0x20]  = 2
         ViewPort.edit("@20 .constant.value ")
         ViewPort.edit("@00 ^table1[a.]constant.value ")
         ViewPort.edit("@10 ^table2[b.]constant.value ")

         ViewPort.edit("@20 3 ")

         Assert.equal(3, Model.getTable("table1")!!.elementCount)
         Assert.equal(3, Model.getTable("table2")!!.elementCount)
         Assert.equal(3, Model[0x20])
      }
      @Test fun TableWithSplitterSegment_Copy_SplitterSegmentNotCopied() {
         ViewPort.edit("^table[a:: b:: | c:: d::]3 ")
         ViewPort.selectionStart  = newOf(4, 1)
         ViewPort.selectionEnd  = newOf(11, 1)

         ViewPort.copy!!.execute(FileSystem)

         Assert.equal("0, 0,", FileSystem.copyText.value!!.trim())
      }
      @Test fun TableWithHexLength_Parse_NoError() {
         ViewPort.edit("^table[a:: b::]0x10 ")
         Assert.equal(8 * 16, Model.getNextRun(0).length)
      }
      @Test fun TableWithHexEnum_Parse_NoErrors() {
         ViewPort.edit("^table[a::0x10 b::]10 ")
         var table = Model.getTable("table")
         var seg = ((table!!.elementContent[0]) as ArrayRunEnumSegment)
         Assert.equal(16, seg.getOptions(Model).count())
      }
      @Test fun Table_UpdateLastElement_TableToolUpdates() {
         ViewPort.edit("^table[a: b:]4 ")

         ViewPort.goto!!.execute(0xF)
         ViewPort.edit("10 ")

         var field = (ViewPort.tools!!.tableTool!!.children.last() as FieldArrayElementViewModel)
         Assert.equal("10", field.content)
      }
      @Test fun Table_PasteMultipleFieldsButNoSpaceAtEnd_LastFieldChanged() {
         var editor = EditorViewModel(FileSystem, InstantDispatch.instance)
         editor.add(ViewPort)
         ViewPort.isFocused  = true
         ViewPort.edit("^table[a:: b:: c:: d::]4 ")

         FileSystem.copyText  = "1 2 3 4"
         editor.paste.execute()

         Assert.equal(4, Model.readMultiByteValue(12, 4))
      }
      @Test fun PaletteTablePointingToNamedAnchor_AppendAndRepoint_KeepDestinationsAndNames() {
         ViewPort.edit("^table[ptr<`ucp4`>]2 <008> <028> @28 ^child.name @table/1 ")

         ViewPort.tools!!.tableTool!!.append.execute()

         var table = Model.getTableModel("table")
         Assert.equal(3, table!!.size)
         Assert.equal(0x28, table!![1].getAddress("ptr"))
         Assert.equal(0x28, table!![2].getAddress("ptr"))
         Assert.equal(0x28, Model.getAddressFromAnchor(Token, -1, "child.name"))
         Assert.equal(arrayOf( table!!.run.start + 4, table!!.run.start + 8), Model.getNextRun(0x28).pointerSources)
      }
      @Test fun TableWithInnerPointers_CheckInnerAnchor_PointersPointToThis() {
         ViewPort.edit("<100> <100> <108> <108> ")
         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "^[a. b. c. d.]4", 0x100, null, table)

         Model.observeAnchorWritten(Token, "table", table.value!!)
         var array = (Model.getNextRun(table.value!!.start) as ArrayRun)

         var sources = array.pointerSourcesForInnerElements!![2]
         Assert.equal(arrayOf( 0x8, 0xC), sources.toTypedArray())
      }
      @Test fun TableWithInnerPointers_ContextItemGotoOptions_TargetsPointToThis() {
         ViewPort.edit("<100> <100> <108> <108> ")
         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "^[a. b. c. d.]4", 0x100, null, table)
         Model.observeAnchorWritten(Token, "table", table.value!!)

         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0x108)
         var menu = ContextItemFactory(ViewPort)
         ViewPort[ViewPort.selectionStart].format!!.visit(menu, ViewPort[ViewPort.selectionStart].value)

         var group = ((menu.results[0]) as ContextItemGroup)
         Assert.equal(arrayOf( "000008", "00000C"), arrayOf( group[1].text, group[2].text))
      }
      @Test fun ExpandPointerTable_EditLastPointer_PointerSourcesUpdated() {
         SetFullModel(0xFF)
         CreateTextTableWithInnerPointers("names", 0x100, "adam", "bob", "charles", "dave", "eric", "fred")
         ViewPort.edit("@000 <null> @000 ^table[ptr<\"\">]1 <names/3>")

         ViewPort.edit("+ <names/4>")

         var run = (Model.getNextRun(0x100) as ArrayRun)
         Assert.equal(arrayOf( 0x0), run.pointerSourcesForInnerElements!![3].toTypedArray())
         Assert.equal(arrayOf( 0x4), run.pointerSourcesForInnerElements!![4].toTypedArray())
      }
      @Test fun ChildTableLengthOne_ChangeLengthToZeroInParent_ReplaceChildPointerWithNull() {
         SetFullModel(0xFF)
         Model.freeSpaceBuffer  = 0
         ViewPort.edit("@100 02 00 @000 01 00 00 00 00 01 00 08 @000 ^parent[count:: child<[a. b.]/count>]1 ")

         ViewPort.edit("@000 0 ")

         Assert.equal(-1, Model.readMultiByteValue(0x100, 4))
         Assert.equal(Int.MAX_VALUE, Model.getNextRun(0x100).start)
         Assert.empty(Errors)
         Assert.equal(0, Model.readMultiByteValue(0, 4))
         Assert.equal(0, Model.readMultiByteValue(4, 4))
      }
      @Test fun ChildTableLengthZero_ChangeLengthToOneInParent_AddNewDataForChild() {
         SetFullModel(0xFF)
         Model.freeSpaceBuffer  = 0
         ViewPort.edit("@000 00 00 00 00 <null> @000 ^parent[count:: child<[a. b.]/count>]1 ")

         ViewPort.edit("@000 1 ")

         var child = (Model.getNextRun(0x8) as ITableRun)
         Assert.equal(2, child.length)
         Assert.equal(1, Model.readMultiByteValue(0, 4))
         Assert.equal(0, Model.readMultiByteValue(child.start, 2))
      }
      @Test fun ChildPointerNull_CreateChildData_ParentCountChanges() {
         SetFullModel(0xFF)
         ViewPort.edit("@000 00 00 00 00 <null> @000 ^parent[count:: child<[a. b.]/count>]1 ")

         ViewPort.edit("@004 @{ ")

         var child = (Model.getNextRun(0x10) as ITableRun)
         Assert.equal(2, child.length)
         Assert.equal(1, Model.readMultiByteValue(0, 4))
         Assert.equal(0, Model.readMultiByteValue(child.start, 2))
      }
      @Test fun DataBeforeChildTable_ChangeChildLengthToNegative_DataNotDeleted() {
         SetFullModel(0xFF)
         ViewPort.edit("@0FE 01 02 03 04 @000 <100> 02 00 00 00 @000 ^parent[child<[data.]/count> count::]1 ")

         ViewPort.edit("@004 -1 ")

         Assert.equal(bytes( 0x01, 0x02, 0xFF, 0xFF), 4.range({ i -> Model[0xFE + i] }).toTypedArray())
      }
      @Test fun ChildTable_UnreasonablyLargeLength_LimitLength() {
         SetFullModel(0xFF)
         ViewPort.edit("@0FE 01 02 03 04 @000 <100> 02 00 00 00 @000 ^parent[child<[data.]/count> count::]1 ")

         ViewPort.edit("@004 2000 ")

         var address = Model.readPointer(0)
         var run = (Model.getNextRun(address) as ITableRun)
         Assert.equal(1000, run.elementCount)
      }
      @Test fun SwitchType_DependsOn_UsedEnum() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")

         ViewPort.edit("@000 ^table[arg: info:|s=arg(4=names)]2 4 )")

         var table = Model.getTable("table")
         Assert.isTrue(table!!.dependsOn("names"))
         Assert.single(table!!.search(Model, "names", 0))
      }
      @Test fun PointersToTextTable_ChangeToPointToMiddleOfText_NoErrorsRedPointer() {
         SetFullModel(0xFF)
         ViewPort.edit("<null> <null> <null> @000 ^table[ptr<\"\">]3 <100> @100 Content ")

         ViewPort.edit("@004 <102>"); // points to middle of existing content

         ViewPort.goto!!.execute(0)
         var pFormat = ((ViewPort[4, 0].format) as Pointer)
         Assert.isTrue(pFormat.hasError); // points to the middle of existing content = error pointer
         Assert.equal(0x100, Model.getNextRun(0x102).start) // text run still starts at 0x100
      }
      @Test fun PointerToMissingName_AddTableStreamAnchorWithThatName_Works() {
         SetFullModel(0xFF)

         ViewPort.edit("@100 <table.name> @000 @!put(0000) ^table.name[item:]!0000 ")

         Assert.empty(Errors)
      }
      @Test fun TableWithSingleQuoteName_GotoDirective_CanGotoName() {
         CreateTextTable("names", 0x100, "abc", "def", "i'j", "xyz")

         ViewPort.edit("@000 @names/i'j ")

         Assert.empty(Errors)
         Assert.equal(0x108, ViewPort.convertViewPointToAddress(ViewPort.selectionStart))
      }
      @Test fun SwitchFormat_EditEnum_NoError() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         ViewPort.edit("@000 ^table[input: arg:|s=input(0=names)]2 ")

         ViewPort.edit("@002 carl ")

         Assert.equal(2, Model[2])
      }
      fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent(target: String, address: Int) {
         CreateTextTable("names", 0x100, "thename", "THENAME")

         ViewPort.goto!!.execute(target)

         var selected = ViewPort.convertViewPointToAddress(ViewPort.selectionStart)
         Assert.equal(address, selected)
         Assert.empty(Errors)
      }
    @Test fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent_1() { TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent("thename", 0x100) }
    @Test fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent_2() { TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent("thename~1", 0x100) }
    @Test fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent_3() { TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent("thename~2", 0x108) }
    @Test fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent_4() { TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent("THENAME", 0x100) }
    @Test fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent_5() { TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent("THENAME~1", 0x100) }
    @Test fun TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent_6() { TwoNamesSameExceptCase_Goto_ConsidersNamesEquivalent("THENAME~2", 0x108) }
      @Test fun TableWithInnerAnchors_ClearFormat_RemovePointersToInnerAnchors() {
         ViewPort.edit("^table^[a::]4 @100 <000> <004> ")

         ViewPort.goto!!.execute(8)
         var item = ViewPort.getContextMenuItems(ViewPort.selectionStart).single({ context -> context.text == "Clear Format" })
         item.command.execute()

         Assert.equal(0x100, Model.getNextRun(0x100).start)
         Assert.notInRange(Model.getNextRun(0x104).start, 0x100, 0x108)
      }
      @Test fun InvalidTextInTable_ReadTextFromTableModel_EscapedText() {
         SetFullModel(0xFF)
         ViewPort.edit("^table[text\"\"8]2 Text")
         Model[0]  = 0x69

         var table = Model.getTableModel("table")
         var text = table!![0].getStringValue("text")

         Assert.equal("\\!69ext", text)
      }
      @Test fun TableWithLengthFromParent_AddNameViaAnchorText_DoesNotChangeLength() {
         ViewPort.edit("<100> 03 @000 ^parent[child<[content:]/length> length::]1 ")

         ViewPort.goto!!.execute("100")
         ViewPort.anchorText  = ViewPort.anchorText.replace("^", "^name")

         var child = (Model.getNextRun(0x100) as ITableRun)
         Assert.equal(3, child.elementCount)
      }
      @Test fun TableWithPointerRecord_GetConcrete_ReturnsPointerFormat() {
         ViewPort.edit("^parent[arg:: target::|s=arg(2=<>)]2 ")

         ViewPort.edit("2 ")
         var table = Model.getTable("parent")
         var raw = ((table!!.elementContent[1]) as ArrayRunRecordSegment)
         var segment = raw.createConcrete(Model, 4)

         Assert.equal(ElementContentType.Pointer, segment.type)
         Assert.isType<Pointer>(ViewPort[ViewPort.convertAddressToViewPoint(4)].format)
      }
      @Test fun TableWithPointerRecord_DestinationKnowsAboutRecord() {
         ViewPort.edit("^parent[target::|s=arg(0=<>) arg::]1 ")
         ViewPort.edit("<100>")
         Model.resolveConflicts()
         var source = Model.getNextRun(0x100).pointerSources!!.single()
         Assert.equal(0, source)
      }
      @Test fun RecordPointer_BecomesPointer_PointerAddedToExistingAnchor() {
         SetFullModel(0xFF)
         "00 00 00 00 00 01 00 08".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("^parent[arg:: target::|s=arg(2=<>)]1 @080 <100>")

         ViewPort.edit("@000 2 ")

         Assert.equal(2, Model.getNextRun(0x100).pointerSources!!.size)
      }
      @Test fun RecordPointer_BecomesPointer_CreateNewAnchor() {
         SetFullModel(0xFF)
         "00 00 00 00 00 01 00 08".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("^parent[arg:: target::|s=arg(2=<>)]1 ")

         ViewPort.edit("@000 2 ")

         Assert.equal(4, Model.getNextRun(0x100).pointerSources!!.single())
      }
      @Test fun RecordPointer_CreateAsPointer_CreateNewAnchor() {
         SetFullModel(0xFF)
         "02 00 00 00 00 01 00 08".parseHexBytes().writeInto(Model.rawData, 0)

         ViewPort.edit("@000 ^parent[arg:: target::|s=arg(2=<>)]1 ")

         Assert.equal(4, Model.getNextRun(0x100).pointerSources!!.single())
      }
      @Test fun RecordPointer_CreateAsPointer_PointerAddedToExistingAnchor() {
         SetFullModel(0xFF)
         "02 00 00 00 00 01 00 08".parseHexBytes().writeInto(Model.rawData, 0)

         ViewPort.edit("@080 <100> @000 ^parent[arg:: target::|s=arg(2=<>)]1 ")

         Assert.equal(2, Model.getNextRun(0x100).pointerSources!!.size)
      }
      @Test fun RecordPointer_CeaseBeingPointer_PointerRemovedFromExistingAnchor() {
         SetFullModel(0xFF)
         "02 00 00 00 00 01 00 08".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("@080 <100> @000 ^parent[arg:: target::|s=arg(2=<>)]1 ")

         ViewPort.edit("@000 0 ")

         Assert.single(Model.getNextRun(0x100).pointerSources)
      }
      @Test fun RecordPointerToText_RepointText_UpdateRecord() {
         SetFullModel(0xFF)
         "00 00 00 00 00 00 00 00".parseHexBytes().writeInto(Model.rawData, 0)
         ViewPort.edit("^parent[arg:: target::|s=arg(2=<\"\">)]1 2 <100> @100 Hello\" @108 dead")

         // cause the repoint
         ViewPort.edit("@100 Hello World!")

         var destination = Model.readPointer(4)
         Assert.notEqual(0x100, destination)
      }
      @Test fun TextTable_PointerIntoTable_NoAssert() {
         ViewPort.edit("^table[a: b:]20 ")

         ViewPort.edit("@100 <006> ")

         Model.resolveConflicts()
         var p = ((ViewPort[ViewPort.convertAddressToViewPoint(0x100)].format) as Pointer)
         Assert.isTrue(p.hasError)
      }
      @Test fun Singletons_BanksFormat_ContainsLayoutFormat() {
         Assert.all(Singletons.gameReferenceTables.keys, lm1@{ key ->
            var refTables = Singletons.gameReferenceTables[key]
            var layoutReference = refTables!![HardcodeTablesModel.mapLayoutTable]
            var bankReference = refTables!![HardcodeTablesModel.mapBankTable]
            var innerFormat = layoutReference!!.format!!.trim(*"[]0123456789".toCharArray())
            Assert.contains(innerFormat, bankReference!!.format)
         })
      }
      @Test fun TableFormatWithPointers_MakeElementsShorter_ClearFormatsNoLongerWithinTable() {
         ViewPort.edit("^table[a: ptr<>]4 @table/3/ptr <100> @000 ")

         ViewPort.anchorText  = ViewPort.anchorText.replace(":", "")

         Assert.notEqual(0x100, Model.getNextRun(0x100).start)
      }
      @Test fun TableOfScripts_ChangeAddressToFreespaceAndBack_NoAnchorLeftBehind() {
         SetFullModel(0xFF)
         ViewPort.edit("<null> @000 ^table[script<`bse`>]1 <100> ")

         ViewPort.edit("@table <180>")

         Assert.equal(0x180, Model.getNextRun(0x100).start)
      }
      @Test fun PointerRecord_Copy_CopyAsPointer() {
         ViewPort.edit("^table[kind:: arg::|s=kind(0=<>)]1 0 <100> ")

         ViewPort.goto!!.execute(0)
         ViewPort.selectionEnd  = newOf(7, 0)
         ViewPort.copy!!.execute(FileSystem)

         Assert.contains("<000100>", FileSystem.copyText.value)
      }
      @Test fun TableToPointers_ClearPointerFormatAndReadd_AnchorKnowsAboutAllTablePointers() {
         SetFullModel(0xFF)
         ViewPort.edit("@00 <100> <100> @00 ^table1[pointer<>]1  @04 ^table2[pointer<>]1 ")

         ViewPort.goto!!.execute(0x100)
         Model.clearAnchor(Token, 0x100, 1)
         ViewPort.edit("@08 <100>")

         var anchor = Model.getNextAnchor(0x100)
         Assert.equal(3, anchor.pointerSources!!.size)
      }

      private fun ArrangeTrainerPokemonTeamData(structType: Int, pokemonCount: Int, trainerCount: Int) {
         CreateTextTable(HardcodeTablesModel.pokemonNameTable, 0x180, *("ABCDEFGHIJKLMNOP".map({ c -> c.toString() }).toTypedArray()))
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x1B0, *("qrstuvwxyz".map({ c -> c.toString() }).toTypedArray()))
         CreateTextTable(HardcodeTablesModel.itemsTableName, 0x1D0, *("0123456789".map({ c -> c.toString() }).toTypedArray()))

         // trainers start at 00. There is room for up to 4.
         // teams start at A0.    There is room for up to 3 pokemon on each team.
         for (i in 0 until trainerCount) {
            var initialOffset = i * TrainerPokemonTeamRun.trainerFormat_Width
            Model[initialOffset + TrainerPokemonTeamRun.trainerFormat_StructTypeOffset]  = structType
            Model[initialOffset + TrainerPokemonTeamRun.trainerFormat_PokemonCountOffset]  = pokemonCount
            Model.writePointer(ModelDelta(), initialOffset + TrainerPokemonTeamRun.trainerFormat_PointerOffset, 0xA0 + 0x30 * i)
         }

         ViewPort.edit("@00 ^trainertable[structType.4 class.data.trainers.classes.names introMusic. sprite. name\"\"12 " +
            "item1:${HardcodeTablesModel.itemsTableName} item2:${HardcodeTablesModel.itemsTableName} item3:${HardcodeTablesModel.itemsTableName} item4:${HardcodeTablesModel.itemsTableName} " +
            "doubleBattle:: ai:: pokemonCount:: pokemon<${TrainerPokemonTeamRun.sharedFormatString}>]${trainerCount} @00")
         ViewPort.resetAlignment.execute()
      }

      private fun ArrangeTrainerPokemonTeamData(structType: Int, pokemonCount: Int) {
         CreateTextTable(HardcodeTablesModel.pokemonNameTable, 0x100, *("ABCDEFGHIJKLMNOP".map({ c -> c.toString() }).toTypedArray()))
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x140, *("qrstuvwxyz".map({ c -> c.toString() }).toTypedArray()))
         CreateTextTable(HardcodeTablesModel.itemsTableName, 0x180, *("0123456789".map({ c -> c.toString() }).toTypedArray()))

         Model[TrainerPokemonTeamRun.trainerFormat_StructTypeOffset]  = structType
         Model[TrainerPokemonTeamRun.trainerFormat_PokemonCountOffset]  = pokemonCount
         Model.writePointer(ModelDelta(), TrainerPokemonTeamRun.trainerFormat_PointerOffset, 0x60)

         ViewPort.goto!!.execute("00")
         ViewPort.selectionStart  = Point(4, 2)
         ViewPort.edit("^trainertable[team<${TrainerPokemonTeamRun.sharedFormatString}>]1 ")

         ViewPort.goto!!.execute("00")
      }
   }

   open class TableToolTestExtensions {
      fun GetField(table: TableTool, name: String): FieldArrayElementViewModel {
         var child = table.children.single({ vm -> vm  is FieldArrayElementViewModel && (vm as FieldArrayElementViewModel).name == name })
         return (child as FieldArrayElementViewModel)
      }
   }
