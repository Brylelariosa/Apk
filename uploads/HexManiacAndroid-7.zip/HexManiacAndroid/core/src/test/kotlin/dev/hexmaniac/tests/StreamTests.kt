@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class StreamTests : BaseViewModelTestClass() {
      @Test fun ParseErrorInPlmRunDeserializeGetsSkipped() {
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0, "A", "B", "\"C C\"", "D")
         Model.writeMultiByteValue(0x40, 2, ModelDelta(), 0xFFFF)
         ViewPort.edit("@40 ^bob`plm` 5 a 6 b 7 c 8 d ")

         ViewPort.tools!!.stringTool!!.content  = SplitLines("5 a;6 b;7\"c c\";8 d")

         // Assert that the run length is still 8 (was 10).
         Assert.equal(8, Model.getNextRun(0x40).length)
      }
      @Test fun ShortenPlmRunClearsExtraUnusedBytes() {
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0, "A", "B", "\"C C\"", "D")
         Model.writeMultiByteValue(0x40, 2, ModelDelta(), 0xFFFF)
         ViewPort.edit("@40 ^bob`plm` 5 a 6 b 7 c 8 d ")

         ViewPort.tools!!.stringTool!!.content  = SplitLines("5 a;8 d")

         // assert that bytes 7/8 are FF
         Assert.equal(0xFFFF, Model.readMultiByteValue(0x46, 2))
      }
      @Test fun CanCopyPlmStream() {
         var fileSystem = StubFileSystem()
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x100, "Punch", "Kick", "Bite", "Snarl", "Smile", "Cry")
         ViewPort.edit("@00 FFFF @00 ^someMoves`plm` 3 Punch 5 Kick 7 Bite 11 Snarl ")

         ViewPort.selectionStart  = Point(2, 0)
         ViewPort.selectionEnd  = Point(7, 0)
         ViewPort.copy!!.execute(fileSystem)

         Assert.equal("5 Kick, 7 Bite, 11 Snarl,", fileSystem.copyText)
      }
      @Test fun CanShortenPlmStream() {
         var fileSystem = StubFileSystem()
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x100, "Punch", "Kick", "Bite", "Snarl", "Smile", "Cry")
         ViewPort.edit("@00 FFFF @00 ^someMoves`plm` 3 Punch 5 Kick 7 Bite 11 Snarl ")

         ViewPort.edit("@04 []")

         Assert.equal(6, Model.getNextRun(0).length)
         Assert.equal(Point(6, 0), ViewPort.selectionStart)
      }
      @Test fun ExtendingTableStreamRepoints() {
         ViewPort.edit("00 01 02 03 FF ^bob CC @00 ^table[value.]!FF ")
         ViewPort.tools!!.selectedIndex  = ViewPort.tools!!.indexOf(ViewPort.tools!!.stringTool)
         Assert.equal(SplitLines("0;1;2;3"), ViewPort.tools!!.stringTool!!.content)

         ViewPort.tools!!.stringTool!!.content  = SplitLines("0;1;2;3;4")

         Assert.notEmpty(Messages)
         var anchorAddress = Model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, "table")
         Assert.notEqual(0, anchorAddress)
      }
      @Test fun CanDeepCopy() {
         ViewPort.edit("^table[pointer<\"\">]1 @{ Hello World!\" @} @00 ")

         var fileSystem = StubFileSystem()
         var menuItem = ViewPort.getContextMenuItems(ViewPort.selectionStart).single({ item -> item.text == "Deep Copy" })
         menuItem.command.execute(fileSystem)

         Assert.equal("@!00(4) ^table[pointer<\"\">]1 #\"Hello World!\"#, @{ \"Hello World!\" @}", fileSystem.copyText)
      }
      @Test fun CanCopyLvlMovesData() {
         CreateTextTable(HardcodeTablesModel.pokemonNameTable, 0x100, "Adam", "Bob", "Carl", "Dave")
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x180, "Ate", "Bumped", "Crossed", "Dropped")
         ViewPort.edit("@00 FF FF @00 ^table`plm` 3 Ate 4 Bumped 5 Crossed @00 ")
         var content = Model.copy({ ViewPort.currentChange }, 0, 8)
         Assert.equal("^table`plm` 3 Ate, 4 Bumped, 5 Crossed, []", content)
      }
      @Test fun StreamRunSerializeDeserializeIsSymmetric() {
         CreateTextTable(HardcodeTablesModel.pokemonNameTable, 0x100, "Adam", "Bob", "Carl", "Dave")

         ViewPort.edit("@00 00 00 01 01 02 02 03 03 FF FF @00 ^table[enum.${HardcodeTablesModel.pokemonNameTable} content.]!FFFF ")
         var stream = (Model.getNextRun(0) as IStreamRun)

         var text = stream.serializeRun()
         Model.observeRunWritten(ViewPort.currentChange, stream.deserializeRun(text!!, ViewPort.currentChange))

         var result = bytes( 0, 0, 1, 1, 2, 2, 3, 3, 255, 255)
         Assert.all(result.size.range(), { i -> Assert.equal(Model[i], result[i]) })
      }
      @Test fun ViewPort_PutMetacommand_DataChangesButSelectionDoesNot() {
         ViewPort.edit("@!put(1234) ")

         Assert.equal(Point(0, 0), ViewPort.selectionStart)
         Assert.equal(0x12, Model[0])
         Assert.equal(0x34, Model[1])
      }
      @Test fun StreamWithCustomEnd_CutPaste_DataUpdates() {
         SetFullModel(0xFF)
         var fileSystem = StubFileSystem()
         arrayCopy(bytes( 2, 2, 2, 3, 3, 3, 0xFF, 0xFF, 0x00), Model.rawData, 9)
         ViewPort.edit("^table[a. b. c.]!FFFF00 ")

         // cut
         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0)
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fileSystem)
         ViewPort.clear!!.execute()

         // paste
         ViewPort.goto!!.execute(0x10)
         ViewPort.edit(fileSystem.copyText!!)

         var table = Model.getTable("table")
         Assert.equal(0x10, table!!.start)
         Assert.equal(2, table!!.elementCount)
         Assert.equal(3, table!!.elementLength)
         Assert.equal(9, table.length)
      }
      @Test fun NonEmptyData_MetaCommandFillZeros_RaiseErrorAndStopWriting() {
         ViewPort.edit("@!00(10) 22 ")

         Assert.single(Errors)
         Assert.equal(0x00, Model[0])
      }
      @Test fun StreamWithEnum_RequestAutocompleteAtEnum_GetOptions() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[a:options b:]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("match, 3", caretLineIndex = 0, caretCharacterIndex = 5)!!.map({ option -> option.text }).toTypedArray()

         Assert.equal(arrayOf( "matchX", "matXch", "Xmatch"), options) // results are sorted
      }
      @Test fun TableStreamRunAutoCompleteOption_Execute_TextChanges() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[a:options b:]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("match, 3", caretLineIndex = 0, caretCharacterIndex = 5)!!.toTypedArray()

         Assert.equal("matchX, 3", options[0].lineText)
      }
      @Test fun TableStreamRunAutoCompleteOption_MoreElementsNeededOnLine_MovesToNextElement() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[a:options b:]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("match", caretLineIndex = 0, caretCharacterIndex = 5)!!.toTypedArray()

         Assert.equal("Xmatch, ", options[2].lineText)
      }
      @Test fun SingleElementTableStreamRun_AutoCompleteField_OptionsMakeSense() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc: xyz:options]", null, FixedLengthStreamStrategy(1))

         var options = stream.getAutoCompleteOptions("xyz: match", caretLineIndex = 0, caretCharacterIndex = 10)!!.toTypedArray()

         Assert.equal("xyz: matchX", options[1].lineText)
      }
      @Test fun TupleInTableStream_AutoCompleteField_OptionCompletesSubContent() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc:|t|i:options|j:options]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("match", 0, 5)!!.toTypedArray()

         Assert.equal("matchX", options[0].text)
         Assert.equal("(matchX ", options[0].lineText)
      }
      @Test fun TupleInTableStream_AutoCompleteSecondField_OptionCompletesSubContent() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc:|t|i:options|j:options]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("(Xmatch match", 0, 13)!!.toTypedArray()

         Assert.equal("matchX", options[0].text)
         Assert.equal("(Xmatch matchX)", options[0].lineText)
      }
      @Test fun TupleInTableStream_AutoCompleteExtraField_NoOptions() {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc:|t|i:options|j:options]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("(Xmatch match ma", 0, 16)!!.toTypedArray()

         Assert.empty(options)
      }
      @Test fun TupleInTableStream_AutoCompleteBoolean_BooleanOptions() {
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.|t|i:|j.]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("(2 e", 0, 4)!!.toTypedArray()

         Assert.equal(2, options.size)
         Assert.equal("false", options[0].text)
         Assert.equal("(2 true)", options[1].lineText)
      }
      fun TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch(inputLine: String, outputText: String, outputLine: String) {
         Model.setList("options", listOf( "Xmatch", "matchX", "matXch", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.|t|i:options|j:options|k.]", null, FixedLengthStreamStrategy(1))

         var options = stream.getAutoCompleteOptions(inputLine, 0, inputLine.length)!!.toTypedArray()

         Assert.equal(outputText, options[0].text)
         Assert.equal(outputLine, options[0].lineText)
      }
    @Test fun TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch_1() { TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch("abc: match", "Xmatch", "abc: (Xmatch ") }
    @Test fun TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch_2() { TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch("abc: (Xmatch match", "Xmatch", "abc: (Xmatch Xmatch ") }
    @Test fun TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch_3() { TupleInSingleElementTableStream_AutoCompleteInitialField_OptionsMatch("abc: (Xmatch Xmatch tr", "true", "abc: (Xmatch Xmatch true)") }
      @Test fun OptionsWithNoQuote_StartTupleWithLeadingQuote_StillFindAutocompleteOption() {
         Model.setList("options", listOf( "PoisonPowder", "\"Poison Gas\"", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.|t|i::options|j::]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("(\"Poison", 0, 8)!!.toTypedArray()

         Assert.equal(2, options.size)
         Assert.equal("PoisonPowder", options[0].text)
         Assert.equal("\"Poison Gas\"", options[1].text)
      }
      @Test fun OptionsWithNoQuote_StartEnumWithLeadingQuote_StillFindAutocompleteOption() {
         Model.setList("options", listOf( "PoisonPowder", "\"Poison Gas\"", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.options]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("\"Poison", 0, 7)!!.toTypedArray()

         Assert.equal(2, options.size)
         Assert.equal("PoisonPowder", options[0].text)
         Assert.equal("\"Poison Gas\"", options[1].text)
      }
      @Test fun ParenthesisAndTupleElementWithQuotes_Autocomplete_OptionsAreFiltered() {
         Model.setList("options", listOf( "\"Poison Gas\"", "\"Poison Sting\"", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.|t|a:options|b:]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("(\"Poison sti 4)", 0, 12)!!.toTypedArray()

         Assert.single(options)
         Assert.equal("\"Poison Sting\"", options[0].text)
         Assert.equal("(\"Poison Sting\" 4)", options[0].lineText)
      }
      @Test fun SingleElementStream_AutocompleteWithExtraWhitespaceBetweenElements_Works() {
         Model.setList("options", listOf( "\"Poison Gas\"", "\"Poison Sting\"", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc:options xyz:]", null, FixedLengthStreamStrategy(1))

         var options = stream.getAutoCompleteOptions("abc:     Poison", 0, 15)!!.toTypedArray()

         Assert.equal("\"Poison Gas\"", options[0].text)
         Assert.equal("\"Poison Sting\"", options[1].text)
      }
      @Test fun SingleElementStream_AutocompleteWithLeadingWhitespace_Works() {
         Model.setList("options", listOf( "\"Poison Gas\"", "\"Poison Sting\"", "other"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc:options xyz:]", null, FixedLengthStreamStrategy(1))

         var options = stream.getAutoCompleteOptions("  abc: Poison", 0, 13)!!.toTypedArray()

         Assert.equal("\"Poison Gas\"", options[0].text)
         Assert.equal("\"Poison Sting\"", options[1].text)
      }
      @Test fun StreamElementViewModel_CallAutocomplete_ZIndexChanges() {
         Model.setList("options", listOf( "PoisonPowder", "\"Poison Gas\"", "other"))
         Model.writePointer(ViewPort.currentChange, 0x100, 0)
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.options]", null, FixedLengthStreamStrategy(2))
         Model.observeRunWritten(NoDataChangeDeltaModel(), stream)
         var vm = TextStreamElementViewModel(ViewPort, "", 0x100, stream.formatString)
         var view = StubView(vm)
         Assert.equal(0, vm.zIndex)

         vm.getAutoCompleteOptions("o", 0, 0)
         Assert.equal(1, vm.zIndex)

         vm.clearAutocomplete()
         Assert.equal(0, vm.zIndex)
         Assert.equal(2, view.propertyNotifications.count({ pname -> pname == "zIndex" }))
      }
      @Test fun StreamElementViewModel_AutocompleteWithNoCompletion_ZIndexDoesNotChange() {
         Model.setList("options", listOf( "PoisonPowder", "\"Poison Gas\"", "other"))
         Model.writePointer(ViewPort.currentChange, 0x100, 0)
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[abc.options]", null, FixedLengthStreamStrategy(2))
         Model.observeRunWritten(NoDataChangeDeltaModel(), stream)
         var vm = TextStreamElementViewModel(ViewPort, "", 0x100, stream.formatString)

         vm.getAutoCompleteOptions("xzy", 0, 3)

         Assert.equal(0, vm.zIndex)
      }
      @Test fun SingleElementStreamRunWithTuple_Serialize_TupleAppearsAsTuple() {
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[index::|t|:.|i::::::. unknown:|h unused:|h]", null, FixedLengthStreamStrategy(1))

         var lines = stream.serializeRun()!!.splitLines()

         var tokenLines = lines.map({ line -> line.split(' ').filter { it.isNotEmpty() } })
         lines  = tokenLines.map({ tokens -> tokens.joinToString(" ") }).toTypedArray()
         Assert.equal("index : (0)", lines[0])
         Assert.equal("unknown : 0x0000", lines[1])
         Assert.equal("unused : 0x0000", lines[2])
      }
      @Test fun TupleSkip3Bits_Write23_Write184() {
         SetFullModel(0xFF)
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[index::|t|:.|i::::::.]", null, FixedLengthStreamStrategy(2))
         Model.observeRunWritten(ViewPort.currentChange, stream)
         ViewPort.refresh()

         ViewPort.edit("23 ")

         Assert.equal(23 * 8, Model[0])
         Assert.equal(0, Model[1])
         Assert.equal(0, Model[2])
         Assert.equal(0, Model[3])
      }
      @Test fun TableWithPointerToStream_StreamContainsOffsetEnumSegment_ChildStreamsAdded() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl")
         Model[0]  = 7;       // 0x0:  carl + 5
         Model[0x13]  = 0x08; // 0x10: <000>

         ViewPort.edit("@10 ^table[sub<[element:names+5]1>]1 ")

         var childTable = (Model.getNextRun(0) as TableStreamRun)
         var enumSegment = ((childTable.elementContent[0]) as ArrayRunEnumSegment)
         Assert.equal(5, enumSegment.valueOffset)

         var cell = ((Model.getNextRun(0x11).createDataFormat(Model, 0x11)) as Pointer)
         Assert.isFalse(cell.hasError)
      }
      @Test fun TableStream_CreateChildTab_StreamIsOneLine() {
         ViewPort.edit("@0A FF @06 ^table[data.]!FF ")

         var child = ViewPort.createChildView(7, 7)

         Assert.equal(5, child.width)
         Assert.equal(6, child.dataOffset)
         Assert.equal(1, child.height)
         Assert.isTrue(child.isSelected(Point(1, 0)))
      }
      @Test fun DynamicStreamLength_AddFormat_ChildrenHaveDifferentLengths() {
         var token = ModelDelta()
         ViewPort.edit("@000 <010> <020> <030> ")
         ViewPort.edit("@010 03 00 05 00 02 00 01 00 00 00 04 00 05 00 03 00 "); // table A buts up against table 2 (8 elements)
         ViewPort.edit("@020 03 00 05 00 02 00 01 00 FF FF FF FF FF FF FF FF "); // table B ends short (4 elements)
         ViewPort.edit("@030 03 00 05 00 02 00 01 00 00 00 ^conflict ");         // table C ends at another anchor (5 elements)
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave", "eric", "fred", "gary")

         ViewPort.edit("@000 ^table[child<[entry:names]?>]3 "); // create a table where each entry is a pointer to a table of unknown length

         var table = Model.getTable("table")
         var childA = Model.getNextRun(table!!.readPointer(Model, 0)) as ITableRun
         var childB = Model.getNextRun(table!!.readPointer(Model, 1)) as ITableRun
         var childC = Model.getNextRun(table!!.readPointer(Model, 2)) as ITableRun

         Assert.equal(8, childA.elementCount)
         Assert.equal(4, childB.elementCount)
         Assert.equal(5, childC.elementCount)
      }
      @Test fun TableStreamRun_GetAutoCompleteOptions_OptionsContainSpaces() {
         Model.setList("names", listOf( "adam", "bob", "carl", "dave"))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[a: b: c::names]", null, FixedLengthStreamStrategy(2))

         var options = stream.getAutoCompleteOptions("1, 2, a", 0, 7)

         Assert.equal(3, options!!.size)
         Assert.equal("1, 2, adam", options!![0].lineText)
         Assert.equal("1, 2, carl", options!![1].lineText)
         Assert.equal("1, 2, dave", options!![2].lineText)
      }
      @Test fun TableWithEnumAndNumber_InputTuple_ParsesData() {
         Model.setList("list", listOf( "adam", "bob", "carl", "dave"))
         var table = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[a:list b:]", null, FixedLengthStreamStrategy(2))

         table.deserializeRun("\n".join(listOf( "(bob 3)", "(carl 4)")), ViewPort.currentChange)

         Assert.equal(1, table.readValue(Model, 0, "a"))
         Assert.equal(3, table.readValue(Model, 0, "b"))
         Assert.equal(2, table.readValue(Model, 1, "a"))
         Assert.equal(4, table.readValue(Model, 1, "b"))
      }
      @Test fun Stream_Copy_IncludeEndToken() {
         SetFullModel(0xFF)
         ViewPort.edit("^table[data:]!FFFF +13 +25 ")

         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.moveSelectionEnd.execute(Direction.End)
         ViewPort.copy!!.execute(FileSystem)

         Assert.contains("[]", FileSystem.copyText.value)
      }
      @Test fun StreamWithLengthFromParentWithNonFreeSpaceAfter_ChangeLengthInParent_RepointChildStream() {
         SetFullModel(0xFF)
         Model.writePointer(Token, 0, 0x100);                 // 000: <100> 2
         Model.writeMultiByteValue(4, 4, Token, 2)
         Model.writeMultiByteValue(0x108, 4, Token, 0xDEAD);  // 108: 00 00 00 00
         ViewPort.edit("^table[ptr<[a: b:]/count> count::]1 ")
         ViewPort.refresh()

         // editing the 'count' parameter should try to expand the child table, which should cause a repoint
         ViewPort.edit("@004 3 ")

         Assert.notEqual(0x100, Model.readPointer(0))
         Assert.single(Messages)
      }
      @Test fun TableStream_Append_CopyLastElement() {
         SetFullModel(0xFF)
         Token.changeData(Model, 0, ByteArray(8))
         ViewPort.edit("^parent[ptr<[pointer<> data::]/count> count::]1 ")

         ViewPort.edit("@{ <100> 4 +")

         var table = ModelTable(Model, Model.readPointer(0))
         Assert.equal(0x100, table[1].getAddress("pointer"))
         Assert.equal(4, table[1].getValue("data"))
      }
      @Test fun TableStreamRun_DeserializeNewPointerToText_NewTextRunAdded() {
         SetFullModel(0xFF)
         Token.changeData(Model, 0, ByteArray(8))
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[text<\"\">]", null, FixedLengthStreamStrategy(2))
         Model.observeRunWritten(Token, stream)

         var text = "\n".join(listOf( "<100>", "<null>"))
         val changedOffsets = Ref<List<Int>?>(null)
         stream.deserializeRun(text, Token, changedOffsets, Ref(nullOf()))

         var destinationRun = Model.getNextRun(0x100)
         Assert.equal(0x100, destinationRun.start)
         Assert.isType<PCSRun>(destinationRun)
         Assert.equal(0, destinationRun.pointerSources!!.single())
      }
      @Test fun TableStreamRun_DeserializeNewPointerDestination_OldAnchorRemovedNewAnchorAdded() {
         SetFullModel(0xFF)
         Token.changeData(Model, 0, ByteArray(4))
         Model.writePointer(Token, 4, 0x100)
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[pointer<>]", null, FixedLengthStreamStrategy(2))
         Model.observeRunWritten(Token, stream)

         var text = "\n".join(listOf( "<180>", "<null>"))
         stream.deserializeRun(text, Token, Ref(nullOf()), Ref(nullOf()))

         var destinationRun = Model.getNextRun(0x100)
         Assert.equal(0x180, destinationRun.start)
         Assert.equal(0, destinationRun.pointerSources!!.single())
      }
      @Test fun TableStreamRun_DeserializeNewPointerDestinationToIncorrectFormat_OldAnchorRemovedNewAnchorAdded() {
         SetFullModel(0xFF)
         Token.changeData(Model, 0, ByteArray(4))
         Model.writePointer(Token, 4, 0x100)
         var stream = TableStreamRun(Model, 0, SortedSpan<Int>.none(), "[pointer<\"\">]", null, FixedLengthStreamStrategy(2))
         Model.observeRunWritten(Token, stream)

         Model[0x180]  = 0x40; // invalid text byte
         var text = "\n".join(listOf( "<180>", "<null>"))
         stream.deserializeRun(text, Token, Ref(nullOf()), Ref(nullOf()))

         var destinationRun = Model.getNextRun(0x100)
         Assert.equal(0x180, destinationRun.start)
         Assert.isType<NoInfoRun>(destinationRun)
         Assert.equal(0, destinationRun.pointerSources!!.single())
      }
      @Test fun TableStream_Copy_FirstElementStartsWithPlus() {
         SetFullModel(0xFF)
         ViewPort.edit("^stream[a: b:]!FFFF +1,2 +3,4 +5,6 ")
         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.moveSelectionEnd.execute(Direction.End)

         ViewPort.copy!!.execute(FileSystem)

         var text: String = FileSystem.copyText!!
         var addCount = text.toCharArray().filter({ c -> c == '+' }).count()
         Assert.equal(3, addCount)
      }
      @Test fun TableStream_DeepCopyPointer_CloseElementIncludedOnce() {
         SetFullModel(0xFF)
         ViewPort.edit("^stream[a: b:]!FFFF +1,2 +3,4 +5,6 ")
         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.moveSelectionEnd.execute(Direction.End)

         ViewPort.edit("@100 <stream> @100 ^table[ptr<>]1 ")
         ViewPort.deepCopy.execute(FileSystem)

         var text: String = FileSystem.copyText!!
         Assert.equal(text.indexOf("[]"), text.lastIndexOf("[]"))
      }
      @Test fun StreamWithEndToken_AppendNegative_DataCleared() {
         SetFullModel(0xFF)
         ViewPort.edit("01 02 03 04 C0 @00 ^table[data.]!C0 ")

         var run = (Model.getNextRun(0) as ITableRun)
         run.append(Token, -1)

         Assert.equal(0xFF, Model[4])
      }
      @Test fun TableStreamWithEndToken_AppendAfterCloseToken_Noop() {
         SetFullModel(0xFF)
         ViewPort.edit("FE @00 ^table[data.]!FE +13 +15 +17 ")

         ViewPort.edit("@04 +")

         var table = Model.getTableModel("table")
         Assert.equal(3, table!!.size)
      }
      @Test fun ParentLengthStreamWithNoParent_Append_StillWorks() {
         ViewPort.edit("^table[content<> unused::]/count <100> 0 ")

         ViewPort.edit("+<180> 0 ")

         var table = Model.getTableModel("table")
         Assert.equal(2, table!!.size)
      }
      @Test fun TableOfPointers_PointerToTextInTable_NoAsserts() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 ^stats[name\"\"8 a:: b::]8 \"0123\" 0 0 \"adam\" 0 0 \"bob\" 0 0 \"carl\" 0 0 \"dave\" 0 0 \"eric\" 0 0 ")

         ViewPort.edit("@000 <null> <null> <null> <null> @000 ^table[pointer<\"\">]4 <080> <stats/2> <090> <060> ")

         Assert.empty(Errors)
         Model.resolveConflicts()
      }
      @Test fun TableOfPointers_PointerToTextInTableFromTableTool_NoAsserts() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 ^stats[name\"\"8 a:: b::]8 \"0123\" 0 0 \"adam\" 0 0 \"bob\" 0 0 \"carl\" 0 0 \"dave\" 0 0 \"eric\" 0 0 ")

         ViewPort.edit("@000 <null> <null> <null> <null> @000 ^table[pointer<\"\">]4 @008 ")
         var field = ViewPort.tools!!.tableTool!!.children.filterIsInstance<FieldArrayElementViewModel>().single({ field -> field.name == "pointer" })
         field.content  = "<120>"

         Assert.empty(Errors)
         Model.resolveConflicts()
      }
   }
