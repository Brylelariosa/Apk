package dev.hexmaniac.core.system

import dev.hexmaniac.core.viewmodels.ExtendedPropertyChangedEventArgs
import dev.hexmaniac.core.viewmodels.ViewModelCore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FoundationTest {
    private class Sample : ViewModelCore() {
        var count: Int by notifying(0)
        private var nameField = ""
        var name: String
            get() = nameField
            set(value) { tryUpdate(nameField, value, "name") { nameField = it } }
        fun notifyBoth() = notifyPropertiesChanged("count", "name")
    }

    @Test
    fun eventSubscribeRaiseUnsubscribe() {
        val e = Event<Int>()
        val seen = ArrayList<Int>()
        val h: (Any?, Int) -> Unit = { _, v -> seen.add(v) }
        e += h
        e(this, 1)
        e -= h
        e(this, 2)
        assertEquals(listOf(1), seen)
        assertFalse(e.hasListeners)
    }

    @Test
    fun propertyDelegateNotifiesWithOldValue() {
        val s = Sample()
        val events = ArrayList<PropertyChangedEventArgs>()
        s.propertyChanged += { _, a -> events.add(a) }
        s.count = 5
        s.count = 5 // no change, no event
        s.name = "x"
        assertEquals(2, events.size)
        assertEquals("count", events[0].propertyName)
        assertEquals(0, (events[0] as ExtendedPropertyChangedEventArgs<*>).oldValue)
        assertEquals("name", events[1].propertyName)
    }

    @Test
    fun silenceAndDeferPropertyNotifications() {
        val s = Sample()
        var raised = 0
        s.propertyChanged += { _, _ -> raised++ }
        s.deferPropertyNotifications().using {
            s.count = 1
            s.count = 2
            s.name = "a"
            assertEquals(0, raised)
        }
        assertEquals(2, raised) // one per distinct property
    }

    @Test
    fun asyncTaskRunsInlineAndAwaitsCompletedTasks() {
        var steps = 0
        val t = asyncTask {
            steps++
            val x = Task.fromResult(20).await()
            steps++
            Task.completedTask.await()
            x + 22
        }
        assertTrue(t.isCompleted)
        assertEquals(42, t.result)
        assertEquals(2, steps)
    }

    @Test
    fun asyncTaskResumesWhenPendingTaskCompletes() {
        val gate = Task<Int>()
        var after = 0
        val t = asyncTask { after = gate.await() + 1; after }
        assertFalse(t.isCompleted)
        gate.setResult(9)
        assertTrue(t.isCompleted)
        assertEquals(10, after)
    }

    @Test
    fun asyncTaskPropagatesExceptions() {
        val t = asyncTask<Int> { throw IllegalStateException("boom") }
        assertTrue(t.isFaulted)
        try {
            t.result
            throw AssertionError("expected exception")
        } catch (e: IllegalStateException) {
            assertEquals("boom", e.message)
        }
    }

    @Test
    fun hexFormatting() {
        assertEquals("0A", 10.toHex(2))
        assertEquals("FF", 255.toHex(2))
        assertEquals("1000", 0x1000.toHex(1))
        assertEquals("08000000", 0x08000000.toHex(8))
        assertEquals("FFFFFFFF", (-1).toHex(2))
        assertEquals("0000A5", 0xA5.toHex(6))
        assertEquals("A5", 0xA5.toHexByte())
        val r = Ref(0)
        assertTrue(tryParseHexInt("FFFFFFFF", r)); assertEquals(-1, r.value)
        assertTrue(tryParseHexInt(" 1a ", r)); assertEquals(0x1A, r.value)
        assertFalse(tryParseHexInt("xyz", r))
    }

    @Test
    fun observableCollectionRaisesEvents() {
        val c = ObservableCollection<String>()
        val actions = ArrayList<NotifyCollectionChangedAction>()
        c.collectionChanged += { _, a -> actions.add(a.action) }
        c.add("a"); c.add("b"); c[0] = "z"; c.move(0, 1); c.removeAt(0); c.clear()
        assertEquals(
            listOf(
                NotifyCollectionChangedAction.Add, NotifyCollectionChangedAction.Add, NotifyCollectionChangedAction.Replace,
                NotifyCollectionChangedAction.Move, NotifyCollectionChangedAction.Remove, NotifyCollectionChangedAction.Reset,
            ),
            actions,
        )
    }
}
