@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ViewPortEditTests : BaseViewModelTestClass() {
      @Test fun CanEditData() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("A")
         ViewPort.edit("D")

         Assert.equal(0xAD, ViewPort[2, 2].value)
         Assert.equal(Point(3, 2), ViewPort.selectionStart)
      }
      @Test fun CanEditMultipleBytesInARow() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("DEADBEEF")

         Assert.equal(0xDE, ViewPort[2, 2].value)
         Assert.equal(0xAD, ViewPort[3, 2].value)
         Assert.equal(0xBE, ViewPort[4, 2].value)
         Assert.equal(0xEF, ViewPort[5, 2].value)
      }
      @Test fun CanUndoEdit() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("AD")
         ViewPort.undo.execute()

         Assert.equal(0x00, ViewPort[2, 2].value)
      }
      @Test fun UndoCanReverseMultipleByteChanges() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("DEADBEEF")
         ViewPort.undo.execute()

         Assert.equal(0x00, ViewPort[2, 2].value)
         Assert.equal(0x00, ViewPort[2, 3].value)
         Assert.equal(0x00, ViewPort[2, 4].value)
         Assert.equal(0x00, ViewPort[2, 5].value)
      }
      @Test fun MovingBetweenChangesCausesSeparateUndo() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("01")
         ViewPort.selectionStart  = Point(2, 3)
         ViewPort.edit("02")
         ViewPort.undo.execute()

         Assert.equal(0x01, ViewPort[2, 2].value)
         Assert.equal(0x00, ViewPort[2, 3].value)
      }
      @Test fun CanRedo() {
         ViewPort.edit("DEADBEEF")
         Assert.isFalse(ViewPort.redo.canExecute(null))

         ViewPort.undo.execute()
         Assert.isTrue(ViewPort.redo.canExecute(null))

         ViewPort.redo.execute()
         Assert.isFalse(ViewPort.redo.canExecute(null))
      }
      @Test fun UndoFixesCorrectDataAfterScroll() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("FF")

         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("EE")
         ViewPort.scroll.execute(Direction.Down)
         ViewPort.undo.execute()

         Assert.equal(1, ViewPort.scrollValue)
         Assert.equal(0xFF, ViewPort[2, 1].value)
      }
      @Test fun EditMovesSelection() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("FF")

         Assert.equal(Point(3, 2), ViewPort.selectionStart)
      }
      @Test fun UndoDoesNotMoveSelection() {
         ViewPort.selectionStart  = Point(2, 2)
         ViewPort.edit("FF")
         ViewPort.undo.execute()

         Assert.equal(Point(3, 2), ViewPort.selectionStart)
      }
      @Test fun UndoDoesNotCauseScrolling() {
         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.edit("FF")
         ViewPort.scroll.execute(Direction.Down)
         ViewPort.undo.execute()

         Assert.equal(1, ViewPort.scrollValue)
      }
      @Test fun SingleCharacterEditChangesToUnderEditFormat() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("F")

         Assert.isType<UnderEdit>(ViewPort[0, 2].format)
         Assert.equal("F", (((ViewPort[0, 2].format) as UnderEdit)).currentText)
      }
      @Test fun UnsupportedCharacterRevertsChangeWithoutAddingUndoOperation() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("F")
         ViewPort.edit("|")

         Assert.isType<None>(ViewPort[0, 2].format)
         Assert.equal(Point(0, 2), ViewPort.selectionStart)
         Assert.equal(0, ViewPort[0, 2].value)
         Assert.isFalse(ViewPort.undo.canExecute(null))
      }
      @Test fun EscapeRevertsChangeWithoutAddingUndoOperation() {
         ViewPort.selectionStart  = Point(0, 2)
         ViewPort.edit("F")
         ViewPort.edit(ConsoleKey.Escape)

         Assert.isType<None>(ViewPort[0, 2].format)
         Assert.equal(Point(0, 2), ViewPort.selectionStart)
         Assert.equal(0, ViewPort[0, 2].value)
         Assert.isFalse(ViewPort.undo.canExecute(null))
      }
      @Test fun SelectionChangeDuringEditNotifiesCollectionChange() {
         var collectionNotifications: Int = 0
         ViewPort.collectionChanged  += { sender, e -> collectionNotifications++ }

         ViewPort.selectionStart  = Point(4, 4)
         ViewPort.edit("F")
         Assert.equal(1, collectionNotifications)

         ViewPort.moveSelectionStart.execute(Direction.Up)
         Assert.equal(3, collectionNotifications) // should have been notified since the visual data changed.
      }
      @Test fun UndoNotifiesCollectionChange() {
         var collectionNotifications: Int = 0
         ViewPort.collectionChanged  += { sender, e -> collectionNotifications++ }

         ViewPort.edit("0102030405")
         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.edit("060708090A")
         collectionNotifications  = 0
         ViewPort.undo.execute()

         Assert.equal(1, collectionNotifications)
      }
      @Test fun UndoRestoresOriginalDataFormat() {
         var originalFormat = ViewPort[0, 0].format
         ViewPort.edit("ff")
         ViewPort.undo.execute()

         Assert.isType(originalFormat!!.javaClass, ViewPort[0, 0].format)
      }
      @Test fun CanEnterDataAfterLastByte() {
         ViewPort.selectionStart  = Point(0, 4)
         ViewPort.edit("00")

         Assert.notEqual(Undefined.instance, ViewPort[0, 4].format)
         Assert.equal(Point(1, 4), ViewPort.selectionStart)
      }
      @Test fun CanClearData() {
         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.selectionEnd  = Point(3, 3)
         ViewPort.clear!!.execute()

         Assert.equal(0xFF, ViewPort[2, 2].value)
         Assert.isTrue(ViewPort.save!!.canExecute(StubFileSystem()))
      }
      @Test fun CanCopyData() {
         var fileSystem = StubFileSystem()

         ViewPort.edit("Cafe Babe")
         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.selectionEnd  = Point(3, 0)
         ViewPort.copy!!.execute(fileSystem)

         Assert.equal("CA FE BA BE", fileSystem.copyText)
      }
      @Test fun CanBackspaceOnEdits() {
         for (i in 0 until 255) Data[i]  = i.toByte()

         ViewPort.selectionStart  = Point(4, 4); // current value: 0x44
         ViewPort.edit("C")
         ViewPort.edit(ConsoleKey.Backspace)

         var editFormat = ((ViewPort[4, 4].format) as UnderEdit)
         Assert.equal("", editFormat.currentText)

         ViewPort.moveSelectionStart.execute(Direction.Down); // any movement should change the value based on what's left in the cell
         Assert.equal(0xFF, ViewPort[4, 4].value) // note that the cell was empty, so it got the 'empty' value of FF
      }
      @Test fun BackspaceBeforeEditChangesPreviousCurrentCell() {
         for (i in 0 until 255) Data[i]  = i.toByte()

         ViewPort.selectionStart  = Point(4, 4); // current value: 0x44
         ViewPort.edit(ConsoleKey.Backspace)
         Assert.equal(Point(4, 4), ViewPort.selectionStart)

         ViewPort.edit(ConsoleKey.Backspace); // if I hit an arrow key now, it'll give up on the edit and just make the value something reasonable
         ViewPort.edit(ConsoleKey.Backspace); // but since I hit backspace, it commits the erasure and starts erasing the next cell
         Assert.equal(0xFF, ViewPort[4, 4].value)
      }
      @Test fun ClearRemovesFormats() {
         ViewPort.edit("<000100>")
         ViewPort.selectionStart  = Point(2, 0)
         ViewPort.clear!!.execute()

         Assert.equal(Int.MAX_VALUE, Model.getNextRun(0).start)
      }
      @Test fun TypingIntoPointerAutoInsertsStartOfPointer() {
         ViewPort.edit("<000100>")
         ViewPort.selectionStart  = Point(0, 0)

         ViewPort.edit("000060")
         ViewPort.edit(ConsoleKey.Enter)

         Assert.equal(0x60, Model[0])
      }
      @Test fun TypingTwoHexDigitsIntoPointerWithSpaceCanRemoveFormat() {
         ViewPort.edit("<000100>")
         ViewPort.selectionStart  = Point(0, 0)

         ViewPort.edit("20 ")

         Assert.equal(0x20, Model[0])
         Assert.notInRange(Model.getNextRun(0).start, 0, 0x200)
      }
      @Test fun UnderEditCellsKnowTheirEditLength() {
         ViewPort.edit("^array[a: b. c. d<>]4 ")

         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.edit("2")
         Assert.equal(2, (((ViewPort[0, 0].format) as UnderEdit)).editWidth)

         ViewPort.selectionStart  = Point(6, 0)
         ViewPort.edit("2")
         Assert.equal(4, (((ViewPort[4, 0].format) as UnderEdit)).editWidth)

         ViewPort.selectionStart  = Point(8, 6)
         ViewPort.edit("^")
         Assert.equal(4, (((ViewPort[8, 6].format) as UnderEdit)).editWidth)
      }
      @Test fun CanCopyPasteBitArray() {
         var fileSystem = StubFileSystem()
         CreateTextTable("names", 0x10, "Adam", "Bob", "Carl", "David", "Evan", "Fred", "Greg", "Holly", "Iggy", "Jay", "Kelly", "Lucy", "Mary", "Nate", "Ogre", "Phil"); // 0x60
         CreateEnumTable("enums", 0x80, "names", *12.range().toList().toIntArray())
         CreateBitArrayTable("bitArray", 0xB0, "enums", 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80)

         // verify that copy works
         ViewPort.goto!!.execute("00")
         ViewPort.selectionStart  = Point(0x4, 0xB)
         ViewPort.copy!!.execute(fileSystem)
         Assert.contains("Carl", fileSystem.copyText)

         // verify that direct entry works
         ViewPort.edit("0100")
         Assert.equal(Point(0x6, 0xB), ViewPort.selectionStart)
         Assert.equal(0x0001, Model.readMultiByteValue(0xB4, 2))

         // verify that direct entry works with spaces
         ViewPort.edit("02 03")
         Assert.equal(0x0302, Model.readMultiByteValue(0xB6, 2))
      }
      @Test fun PlmRunsContainingNamesWithSpacesCanBeCorrectlyEditedWithTheTextTool() {
         var tool = ViewPort.tools!!.stringTool
         var delta = ModelDelta()
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x00, "Option0", "Option1", "Option2 More", "Option3 More", "Option4")
         for (i in 0 until 4) Model.writeMultiByteValue(0x50 + i * 2, 2, delta, 0x0201)
         Model.writeMultiByteValue(0x58, 2, ModelDelta(), 0xFFFF)
         ViewPort.goto!!.execute("50")
         ViewPort.edit("^sample`plm` ")

         Assert.equal(SplitLines("1 Option1;1 Option1;1 Option1;1 Option1"), tool!!.content)

         tool!!.content  = SplitLines("1 Option1;2 \"Option2 More\";2 Option4;2 Option4")

         Assert.equal(SplitLines("1 Option1;2 \"Option2 More\";2 Option4;2 Option4"), tool!!.content)

         var plm = (Model.getNextRun(0x50) as PLMRun)
         Assert.equal(10, plm.length)

         Assert.equal(0x0201, Model.readMultiByteValue(0x50, 2))
         Assert.equal(0x0402, Model.readMultiByteValue(0x52, 2))
         Assert.equal(0x0404, Model.readMultiByteValue(0x54, 2))
         Assert.equal(0x0404, Model.readMultiByteValue(0x56, 2))
      }
      @Test fun CopyFirstTableElementDoesNotIncludeAppendCharacter() {
         var fileSystem = StubFileSystem()
         CreateTextTable("names", 0x10, "Adam", "Bob", "Carl", "David", "Evan", "Fred", "Greg", "Holly", "Iggy", "Jay", "Kelly", "Lucy", "Mary", "Nate", "Ogre", "Phil"); // 0x60

         // copy
         ViewPort.goto!!.execute("00")
         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.selectionEnd  = Point(5, 1); // select the first entry
         ViewPort.copy!!.execute(fileSystem)

         // check
         Assert.doesNotContain("+", fileSystem.copyText)
      }
      @Test fun ExtendingPokemonNameArrayDoesNotChangeBitsInBitArray() {
         CreateTextTable("names", 0x0, *("ABCDEFGHIJKLMNOP".toCharArray().map({ c -> c.toString() }).toTypedArray())); // 16 entries, 2 bytes each
         CreateEnumTable("enums", 0x40, "names", 0, 1, 2, 3); // note that the enum uses 4 bits
         ViewPort.goto!!.execute("80")
         ViewPort.edit("^bits[pokemon|b[]enums]names "); // each entry is 1 byte long, 16 entries.

         // precondition
         var bitArray = (((Model.getNextRun(0x80) as ArrayRun)).elementContent[0] as ArrayRunBitArraySegment)
         Assert.equal(1, bitArray.length)

         // extend the name table with a new entry
         ViewPort.goto!!.execute("20")
         ViewPort.edit("+")

         // postcondition
         bitArray  = (((Model.getNextRun(0x80) as ArrayRun)).elementContent[0] as ArrayRunBitArraySegment)
         Assert.equal(1, bitArray.length)
      }
      @Test fun ClearTableClearsCurrentItemOnly() {
         CreateTextTable("table", 0, *("A B C D E F G".split(' ')).toTypedArray())
         ViewPort.selectionStart  = Point(4, 0)
         ViewPort.clear!!.execute()

         Assert.isType<PCS>(ViewPort[2, 0].format)
      }
      @Test fun BackspaceEditsSingleCellWhenNoFormats() {
         Model.observeRunWritten(ModelDelta(), AsciiRun(Model, 0x20, 0x10))
         Model[0]  = 0xA0
         Model[1]  = 0xA1
         Model[2]  = 0xA2

         ViewPort.selectionStart  = Point(1, 0)
         ViewPort.edit(ConsoleKey.Backspace)

         Assert.equal(0xA2, Model[2])
      }
      @Test fun ClearFormatOnNamedAnchorRemovesAnchorButDoesNotClearFalsePointers() {
         ViewPort.edit("<000004> ^fake ")

         var items = ViewPort.getContextMenuItems(Point(4, 0))
         var clear = items.single({ item -> item.text!!.contains("Clear Format") })
         clear.command.execute()

         Assert.equal(4, Model[0])
      }
      @Test fun CanIncludeCommentsInPasteScripts() {
         var nl = "\n"
         ViewPort.edit("FF @00 ^text\"\" Some # Comment Here ${nl}Text")
         var matches = ViewPort.find("Some Text")
         Assert.single(matches)
      }
      @Test fun CanEndCommentWithPound() {
         ViewPort.edit("FF @00 ^text\"\" Some # Comment Here #Text")
         var matches = ViewPort.find("Some Text")
         Assert.single(matches)
      }
      @Test fun HexSegment_Copy_CopyHexBytes() {
         var filesystem = StubFileSystem()
         val arrayRun = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "[some: data:|h]4", 0, null, arrayRun)
         Model.observeRunWritten(ViewPort.currentChange, arrayRun.value!!)
         ViewPort.refresh()

         ViewPort.selectionStart  = Point(2, 0)
         ViewPort.copy!!.execute(filesystem)

         Assert.equal("0000", filesystem.copyText.value!!.trim())
      }
      @Test fun Freespace_WriteBlankViaMetacommand_DataIsWritten() {
         SetFullModel(0xFF)

         ViewPort.edit("@!00(32) ")

         Assert.all(32.range(), { i -> Assert.equal(0x00, Model[i]) })
      }
      @Test fun NonEmptyModel_WriteBlankViaMetacommand_Fail() {
         ViewPort.edit("@!00(32) ")

         Assert.single(Errors)
      }
      @Test fun ViewPort_Align_MoveSelection() {
         ViewPort.moveSelectionStart.execute(Direction.Right)
         ViewPort.edit(".align 2 ")
         Assert.equal(Point(2, 0), ViewPort.selectionStart)
      }
      @Test fun ViewPort_TextDirective_DoesNothing() {
         ViewPort.edit(".text ")

         Assert.empty(Errors)
         Assert.empty(Messages)
         Assert.equal(Point(), ViewPort.selectionStart)
         Assert.isType<None>(ViewPort[0, 0].format)
      }
      @Test fun ViewPort_ThumbDirective_DoesNothing() {
         ViewPort.edit(".thumb ")

         Assert.empty(Errors)
         Assert.empty(Messages)
         Assert.equal(Point(), ViewPort.selectionStart)
         Assert.isType<None>(ViewPort[0, 0].format)
      }
      @Test fun ViewPort_Edit_RaiseUndoChanged() {
         var lastCanExecuteResult: Boolean = ViewPort.undo.canExecute(null)
         ViewPort.undo.canExecuteChanged  += { sender, e -> lastCanExecuteResult  = ViewPort.undo.canExecute(null) }

         ViewPort.edit("11 ")

         Assert.isTrue(lastCanExecuteResult)
      }
      @Test fun AddConstant_Undo_NoConstant() {
         Model.setUnmappedConstant(ViewPort.currentChange, "bob", 3)

         ViewPort.undo.execute()

         Assert.isFalse(Model.tryGetUnmappedConstant("bob", Ref(nullOf())))
      }
      @Test fun EditingNumberCellOnBottomRow_SelectDown_CompleteCurrentChange() {
         ViewPort.edit("@0F0 ^table[a:: b:: c:: d::]1 @000 "); // make a table
         ViewPort.selectionStart  = Point(0, 15); // select bottom row
         ViewPort.edit("3");                         // start an edit

         ViewPort.moveSelectionStart.execute(Direction.Down); // scroll down

         var table = Model.getTable("table")
         Assert.equal(3, Model[table!!.start])
      }
      fun Anchor_BadFormat_NoCrash(text: String) {
         ViewPort.edit(text)
         Assert.single(Errors)
      }
    @Test fun Anchor_BadFormat_NoCrash_1() { Anchor_BadFormat_NoCrash("^anchor[[]] ") }
      @Test fun Constant_TwoBytes_HasRightFormat() {
         var word = WordRun(0, "name", 2, 0, 1)
         Assert.equal(":", word.formatString)
      }
      @Test fun CursorAtEndOfFile_DeleteThenGoto_CannotUndo() {
         ViewPort.goto!!.execute(0x1FF)
         ViewPort.moveSelectionStart.execute(Direction.Right)

         ViewPort.clear!!.execute()
         ViewPort.goto!!.execute(0)

         Assert.isFalse(ViewPort.undo.canExecute(null))
      }
      @Test fun SelectMultipleBytesIncludingEndOfFile_Delete_NoEdit() {
         ViewPort.goto!!.execute(0x1FF)
         ViewPort.moveSelectionEnd.execute(Direction.Right)

         ViewPort.clear!!.execute()

         Assert.equal(0x200, Model.rawData.size)
      }
   }
