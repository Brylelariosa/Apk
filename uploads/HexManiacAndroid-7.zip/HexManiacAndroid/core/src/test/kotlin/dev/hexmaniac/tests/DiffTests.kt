@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class DiffTests {
      private lateinit var editor: EditorViewModel
      private var fs: StubFileSystem = StubFileSystem()

      init {
         editor  = EditorViewModel(fs, InstantDispatch.instance)
         editor.open.execute(LoadedFile("Left.gba", ByteArray(0x200)))
         editor.open.execute(LoadedFile("Right.gba", ByteArray(0x200)))
         ViewModel0.width  = 16
         ViewModel1.width  = 16
         ViewModel0.height  = 16
         ViewModel1.height  = 16
      }

      private val ViewModel0: IEditableViewPort get() = ((editor[0]) as IEditableViewPort)
      private val ViewModel1: IEditableViewPort get() = ((editor[1]) as IEditableViewPort)
      private val ViewModel2: DiffViewPort get() = ((editor[2]) as DiffViewPort)
      private val Model0: IDataModel get() = ViewModel0.model!!
      private val Model1: IDataModel get() = ViewModel1.model!!
      private fun Edit0(text: String) = (((editor[0]) as ViewPort)).edit(text)
      private fun Edit1(text: String) = (((editor[1]) as ViewPort)).edit(text)
      @Test fun TwoTabs_Diff_NameIsFromBothTabs() {
         Model1[0]  = 1

         editor.diffRight.execute(editor[0])

         Assert.equal("Left -> Right", editor[2].name)
      }
      @Test fun TwoTabsWithSameData_Diff_NoNewTab() {
         editor.diffRight.execute(editor[0])
         Assert.equal(2, editor.count)
      }
      @Test fun TwoTabs_Diff_FullWidthPlusOne() {
         Model1[0]  = 1

         editor.diffRight.execute(editor[0])

         Assert.equal(16 + 1 + 16, (((editor[2]) as IViewPort)).width)
      }
      @Test fun TwoTabs_Diff_DiffBytesAreSelected() {
         Model1[0]  = 1

         editor.diffRight.execute(editor[0])

         Assert.isTrue(ViewModel2.isSelected(Point(17, 0)))
      }
      @Test fun TwoTabs_DifferentFormatsForDiff_AlignmentStillMatches() {
         Edit1("^table[a: b: c:]4 1 2 3 4 5 6 7 8 9 10 11 12 ")
         Model1[0x100]  = 1

         editor.diffRight.execute(editor[0])

         Assert.all(10.range(), lm1@{ y ->
            var leftIsUndefined = ViewModel2[0, y].format == Undefined.instance
            var rightIsUndefined = ViewModel2[17, y].format == Undefined.instance
            Assert.equal(leftIsUndefined, rightIsUndefined)
         })
      }
      @Test fun TwoTabs_TwoDifferences_SeeBothDifferences() {
         Model1[0x000]  = 10
         Model1[0x100]  = 20

         editor.diffRight.execute(editor[0])

         Assert.isNotType<Undefined>(ViewModel2[0, 6].format)
      }
      @Test fun DiffTab_PageDown_MoveDownOnePage() {
         for (address in 7.range().map({ i -> i * 0x50 }))
            Model1[address]  = 1
         editor.diffRight.execute(editor[0])

         ViewModel2.scroll.execute(Direction.PageDown)

         Assert.equal(16, ViewModel2.scrollValue)
      }
      @Test fun LeftMostTab_DiffLeft_CanNotExecute() {
         Assert.isFalse(editor.diffLeft.canExecute(ViewModel0))
      }
      @Test fun RightMostTab_DiffRight_CanNotExecute() {
         Assert.isFalse(editor.diffRight.canExecute(ViewModel1))
      }
      @Test fun LeftMostTab_ExecuteDiffLeft_NoTabAdded() {
         editor.diffLeft.execute(ViewModel0)
         Assert.equal(2, editor.count)
      }
      @Test fun RightMostTab_ExecuteDiffRight_NoTabAdded() {
         editor.diffRight.execute(ViewModel1)
         Assert.equal(2, editor.count)
      }
      @Test fun NonViewPortTab_TryDiffFromNonViewPort_NoDiff() {
         editor.add(StubTabContent())

         editor.diffLeft.execute(editor[2])

         Assert.isFalse(editor.diffLeft.canExecute(editor[2]))
         Assert.equal(3, editor.count)
      }
      @Test fun NonViewPortTab_TryDiffToNonViewPort_NoDiff() {
         editor.add(StubTabContent())

         editor.diffRight.execute(editor[1])

         Assert.isFalse(editor.diffRight.canExecute(editor[1]))
         Assert.equal(3, editor.count)
      }
      @Test fun DiffTab_SaveAll_NoCrash() {
         Model1[1]  = 1
         ViewModel0.diffRight.execute()

         editor.saveAll.execute()
      }
      @Test fun DiffTab_Close_Closes() {
         Model1[1]  = 1
         ViewModel0.diffRight.execute()

         editor.close.execute()

         Assert.equal(2, editor.count)
      }
      fun DiffTab_ExpandSelection_GotoInNewTab(x: Int, y: Int, targetTab: Int, newSelectionStart: Int) {
         Model1[1]  = 1
         ViewModel0.diffRight.execute()

         ViewModel2.expandSelection(x, y)

         Assert.equal(targetTab, editor.selectedIndex)
         var selectedTab = (editor.selectedTab as ViewPort)
         var selectedAddress = selectedTab.convertViewPointToAddress(selectedTab.selectionStart)
         Assert.equal(newSelectionStart, selectedAddress)
      }
    @Test fun DiffTab_ExpandSelection_GotoInNewTab_1() { DiffTab_ExpandSelection_GotoInNewTab(2, 2, 0, 34) }
    @Test fun DiffTab_ExpandSelection_GotoInNewTab_2() { DiffTab_ExpandSelection_GotoInNewTab(19, 2, 1, 34) }
      @Test fun ManyChanges_Diff_LimitTo1000Changes() {
         editor.maximumDiffSegments  = 2
         Model1[1]  = 1
         Model1[30]  = 1
         Model1[60]  = 1

         ViewModel0.diffRight.execute()

         Assert.contains("+", editor.informationMessage)
      }
      @Test fun WideViewPorts_Diff_LimitTotalWidth() {
         ViewModel0.edit("^table[a1:: a2:: a3:: a4:: b1:: b2:: b3:: b4:: c1:: c2:: c3:: c4::]2 ")
         ViewModel1.edit("^table[a1:: a2:: a3:: a4:: b1:: b2:: b3:: b4:: c1:: c2:: c3:: c4::]2 ")
         Model1[1]  = 1

         ViewModel0.diffRight.execute()

         Assert.equal(32 + 1 + 32, ViewModel2.width)
      }
      @Test fun DifferentLengthFiles_Diff_Error() {
         Model1.expandData(ModelDelta(), 0x300)

         ViewModel0.diffRight.execute()

         Assert.isTrue(editor.showError)
      }
      @Test fun MultipleCloseChanges_Diff_MultipleSections() {
         for (i in 0 until 0x10 * 5) Model1[i]  = 1

         ViewModel0.diffRight.execute()

         Assert.all(Enumerable.Range(0, 5),
            { i -> Assert.isNotType<Undefined>(ViewModel2[0, i].format) })
      }
      @Test fun Diff_ContextMenu_HasCopyAddress() {
         Model1[1]  = 1
         ViewModel0.diffRight.execute()

         var items = ViewModel2.getContextMenuItems(Point(0, 0), null)
         var itemText = items.map({ item -> item.text }).toMutableList()

         Assert.single(itemText, "Copy Address")
      }
      @Test fun HideKnownPointerChanges_Diff_PointerChangesExcluded() {
         ViewModel0.edit("@00 <200> @100 3 ")

         editor.hideDiffPointerChanges  = true
         ViewModel0.diffRight.execute()

         Assert.equal(1, ViewModel2.childCount)
      }
      @Test fun TwoCloseChanges_Diff_CombineResults() {
         ViewModel0.edit("01 02 03 04 @10 01 02 03 04 ")

         ViewModel0.diffRight.execute()

         Assert.equal(1, ViewModel2.childCount)
      }
      @Test fun LongChange_Diff_SeeWholeChange() {
         for (i in 0 until 0x50) ViewModel0.edit("11 ")
         ViewModel0.edit("@00 ^table[a:: b:: c:: d::]5 ")

         ViewModel0.diffRight.execute()

         Assert.equal(5, ViewModel2.leftHeight(0))
         Assert.equal(5, ViewModel2.rightHeight(0))
      }
      @Test fun DiffTab_OpenFile_NoCrash() {
         ViewModel0.edit("11 ")
         ViewModel0.diffRight.execute()

         editor.open.execute(LoadedFile("file.gba", ByteArray(0x800)))

         // no exceptions -> pass
      }
      @Test fun DiffTab_HasHeader() {
         ViewModel0.edit("11 ")

         ViewModel0.diffRight.execute()

         Assert.empty(ViewModel2.fileName)
         Assert.notEmpty(ViewModel2.fullFileName)
      }
      @Test fun TwoTabs_SwapTabs_DiffOptionsUpdated() {
         var notifyCount: Int = 0
         ViewModel0.diffLeft.canExecuteChanged  += { sender, e -> notifyCount  += 1 }
         ViewModel0.diffRight.canExecuteChanged  += { sender, e -> notifyCount  += 1 }
         ViewModel1.diffLeft.canExecuteChanged  += { sender, e -> notifyCount  += 1 }
         ViewModel1.diffRight.canExecuteChanged  += { sender, e -> notifyCount  += 1 }

         editor.swapTabs(0, 1)

         Assert.isFalse(ViewModel0.diffLeft.canExecute(null))
         Assert.isTrue(ViewModel0.diffRight.canExecute(null))
         Assert.isTrue(ViewModel1.diffLeft.canExecute(null))
         Assert.isFalse(ViewModel1.diffRight.canExecute(null))
         Assert.equal(4, notifyCount)
      }
      @Test fun OneTab_AddNewTab_DiffOptionsUpdate() {
         editor[1].close.execute()
         var notifyCount: Int = 0
         ViewModel0.diffRight.canExecuteChanged  += { sender, e -> notifyCount  += 1 }

         editor.open.execute(LoadedFile("file2.gba", ByteArray(0x1000)))

         Assert.equal(1, notifyCount)
      }
      fun TwoTabsSameModel_SaveAsTab_OtherTabClosed(tabToEdit: Int) {
         fs.requestNewName  = { _, _, _ -> "new.gba" }
         fs.save  = { _ -> true }
         ViewModel1.close.execute()
         ViewModel0.duplicate()
         var viewport = ((editor[tabToEdit]) as IEditableViewPort)

         viewport.edit("@00 01 ")
         viewport.saveAs.execute(fs)

         Assert.single(editor)
         Assert.isTrue(editor.showMessage)
      }
    @Test fun TwoTabsSameModel_SaveAsTab_OtherTabClosed_1() { TwoTabsSameModel_SaveAsTab_OtherTabClosed(0) }
    @Test fun TwoTabsSameModel_SaveAsTab_OtherTabClosed_2() { TwoTabsSameModel_SaveAsTab_OtherTabClosed(1) }
      @Test fun SecondByte7F_ReadVariableWidthInteger_DecodeCorrectly() {
         var data = bytes( 0x00, 0x7F, 0x81)
         val start = Ref<Int>(0)

         var result = Patcher.readVariableWidthInteger(data, start)

         Assert.equal("C000", result.toString("X4"))
         Assert.equal(3, start.value)
      }
      @Test fun SelectLeft_CloseRight_CannotDiffRight() {
         editor.selectedIndex  = 0

         var view = StubView(editor)
         ViewModel1.close.execute()

         Assert.isFalse(editor.diffRight.canExecute(null))
         Assert.contains("diffRight", view.commandCanExecuteChangedNotifications)
      }

      // TODO Can I use this pointer information to then show diffs between dynamic addresses?
      //      If a pointer is recognized as moved, show a diff for the two destinations together, instead of just based on linear address
      //      i.e. instead of diffing 720000 with 720000, diff <720000> with <840000> (because of a pointer difference found)
   }
