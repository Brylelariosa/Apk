@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ViewPortTests : BaseViewModelTestClass() {
      @Test fun ViewPortNotifiesOnSizeChange() {
         var viewPort = ViewPort()
         var changedProperties = ArrayList<String>()
         viewPort.propertyChanged  += { sender, e -> changedProperties.add(e.propertyName!!) }

         viewPort.width  = 12
         viewPort.height  = 50

         Assert.contains("width", changedProperties)
         Assert.contains("height", changedProperties)
      }
      @Test fun ViewPortStartsEmpty() {
         var viewPort = ViewPort()

         Assert.equal(HexElement.undefined, viewPort[0, 0])
         Assert.equal(0, viewPort.minimumScroll)
         Assert.equal(0, viewPort.maximumScroll)
      }
      @Test fun ViewPortScrollStartsAtTopRow() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }

         Assert.equal(0, viewPort.scrollValue)
      }
      @Test fun ViewPortScrollingDoesNotAllowEmptyScreen() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }

         Assert.equal(0, viewPort.minimumScroll)
         Assert.equal(4, viewPort.maximumScroll)
      }
      @Test fun ViewPortCannotScrollLowerThanMinimumScroll() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }

         viewPort.scrollValue  = Int.MIN_VALUE

         Assert.equal(viewPort.minimumScroll, viewPort.scrollValue)
      }
      @Test fun ChangingWidthUpdatesScrollValueIfNeededOnScrollRegion() {
         var scroll = ScrollRegion().also { it.dataLength = 25; it.width = 5; it.height = 5 }

         scroll.scrollValue++
         scroll.width--

         Assert.equal(2, scroll.scrollValue)
         Assert.equal(6, scroll.maximumScroll)
      }
      @Test fun ChangingWidthUpdatesScrollValueIfNeeded() {
         // ScrollValue=0 is always the line that contains the first byte of the file.
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }

         viewPort.scrollValue++; // scroll down one line
         viewPort.width--;      // decrease the width so that there is data 2 lines above

         // Example of what it should look like:
         // .. .. .. ..
         // .. .. .. 00
         // 00 00 00 00
         // 00 00 00 00 <- this is the top line in view
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00 <- this is the bottom line in view
         // .. .. .. ..
         Assert.equal(2, viewPort.scrollValue)
         Assert.equal(6, viewPort.maximumScroll)
      }
      @Test fun ResizingCannotLeaveTotallyBlankLineAtTop() {
         var loadedFile = LoadedFile("test", ByteArray(36))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 6; it.height = 6 }

         viewPort.scrollValue++;   // scroll down one line
         viewPort.width--;         // decrease the width so that there is data 2 lines above

         // Example of what it should look like right now:
         // .. .. .. ..
         // .. .. .. 00
         // 00 00 00 00
         // 00 00 00 00 <- this is the top line in view
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00 <- this is the bottom line in view
         // .. .. .. ..

         viewPort.scrollValue  = viewPort.minimumScroll; // scroll up to top
         viewPort.width--;                              // decrease the width to hide the last visible byte in the top row

         // expected: viewPort should auto-scroll here to make the top line full of data again
         Assert.equal(0, viewPort.scrollValue)
         Assert.notEqual(HexElement.undefined, viewPort[0, 0])
      }
      @Test fun RequestingOutOfRangeDataReturnsUndefinedFormat() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }

         Assert.equal(HexElement.undefined, viewPort[0, -1])
         Assert.equal(HexElement.undefined, viewPort[5, 0])
         Assert.equal(HexElement.undefined, viewPort[0, 5])
         Assert.equal(HexElement.undefined, viewPort[-1, 0])
      }
      @Test fun MaximumScrollChangesBasedOnDataOffset() {
         var loadedFile = LoadedFile("test", ByteArray(26))
         var viewPort = ViewPort(loadedFile).also { it.preferredWidth = -1; it.width = 5; it.height = 5 }

         // initial condition: given 4 data per row, there should be 7 rows (0-6) because 7*4=28
         viewPort.width--
         Assert.equal(6, viewPort.maximumScroll)
         viewPort.width++

         viewPort.scrollValue++;   // scroll down one line
         viewPort.width--;         // decrease the width so that there is data 2 lines above

         // Example of what it should look like right now:
         // .. .. .. 00
         // 00 00 00 00
         // 00 00 00 00 <- this is the top line in view
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00
         // 00 00 00 00 <- this is the bottom line in view
         // 00 .. .. ..

         // notice from the diagram above that there should now be _8_ rows (0-7).
         Assert.equal(7, viewPort.maximumScroll)
      }
      @Test fun ScrollingRightUpdatesScrollValueIfNeeded() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }
         var changeCount = 0

         viewPort.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.scroll.execute(Direction.Right)

         Assert.equal(1, viewPort.scrollValue)
         Assert.notEqual(0, changeCount)
      }
      @Test fun ScrollingRightAndLeftCancel() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         loadedFile.contents[3]  = 0x10
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }

         viewPort.scroll.execute(Direction.Left)
         viewPort.scroll.execute(Direction.Right)

         Assert.equal(0x10, viewPort[3, 0].value)
      }
      @Test fun EmptyFileMaximumScrollMatchesMinimumScroll() {
         var viewPort = ViewPort()

         Assert.equal(viewPort.minimumScroll, viewPort.maximumScroll)
      }
      @Test fun EmptyFileCannotScroll() {
         var viewPort = ViewPort()

         Assert.isFalse(viewPort.scroll.canExecute(Direction.Left))
         Assert.isFalse(viewPort.scroll.canExecute(Direction.Right))
         Assert.isFalse(viewPort.scroll.canExecute(Direction.Up))
         Assert.isFalse(viewPort.scroll.canExecute(Direction.Down))
      }
      @Test fun NotifyCollectionChangeAfterScrolling() {
         var loadedFile = LoadedFile("test", ByteArray(25))
         var viewPort = ViewPort(loadedFile).also { it.width = 5; it.height = 5 }
         var propertyNotifications = ArrayList<String>()
         viewPort.propertyChanged  += { sender, e -> propertyNotifications.add(e.propertyName!!) }
         var collectionNotifications: Int = 0
         viewPort.collectionChanged  += { sender, e -> collectionNotifications++ }

         viewPort.scroll.execute(Direction.Down)

         Assert.equal(1, collectionNotifications)
      }
      @Test fun ViewPort_GotoWithOffset_Goto() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("@100+10 ")
         Assert.equal(0x110, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionStart))
      }
      @Test fun ViewPort_GotoNonExistingAnchorWithSizeSpecified_AnchorCreated() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("@newAnchor(10) ")
         var destination = test.Model.getAddressFromAnchor(ModelDelta(), -1, "newAnchor")
         Assert.notEqual(Pointer.null_, destination)
      }
      @Test fun ScrollWithSingleTableView_SelectCellBeforeStartOfTable_FirstCellOfTableSelected() {
         var scroll = ScrollRegion().also { it.allowSingleTableMode = true; it.width = 16; it.height = 16 }
         var select = Selection(scroll, PokemonModel(ByteArray(0x200)), ChangeHistory<ModelDelta>({ p -> p }))
         scroll.setTableMode(8, 24)

         select.selectionStart  = Point(4, 0)

         Assert.equal(Point(8, 0), select.selectionStart)
      }
      @Test fun ScrollWithSingleTableView_SelectionEndBeforeStartOfTable_FirstCellOfTableSelected() {
         var scroll = ScrollRegion().also { it.allowSingleTableMode = true; it.width = 16; it.height = 16 }
         var select = Selection(scroll, PokemonModel(ByteArray(0x200)), ChangeHistory<ModelDelta>({ p -> p }))
         scroll.setTableMode(8, 24)

         select.selectionStart  = Point(4, 0)
         select.selectionEnd  = Point(4, 0)

         Assert.equal(Point(8, 0), select.selectionEnd)
      }
      @Test fun ScrollWithSingleTableView_SelectAfterTable_CoerceSelectionIntoTable() {
         var scroll = ScrollRegion().also { it.allowSingleTableMode = true; it.width = 16; it.height = 16 }
         var select = Selection(scroll, PokemonModel(ByteArray(0x200)), ChangeHistory<ModelDelta>({ p -> p }))
         scroll.setTableMode(8, 24)

         select.selectionStart  = Point(0, 2)
         Assert.equal(Point(15, 1), select.selectionStart)
      }
      @Test fun ScrollWithinSingleTableView_SelectEndAfterTable_CoerceSelectionEndIntoTable() {
         var scroll = ScrollRegion().also { it.allowSingleTableMode = true; it.width = 16; it.height = 16 }
         var select = Selection(scroll, PokemonModel(ByteArray(0x200)), ChangeHistory<ModelDelta>({ p -> p }))
         scroll.setTableMode(8, 24)

         select.selectionEnd  = Point(0, 2)
         Assert.equal(Point(15, 1), select.selectionEnd)
      }
      @Test fun ClosedTools_SelectPointer_AnchorTextUpdates() {
         ViewPort.tools!!.selectedIndex  = -1
         ViewPort.edit("@100 ^anchor @00 <100> ")

         ViewPort.goto!!.execute(0)

         Assert.isTrue(ViewPort.anchorTextVisible)
         Assert.equal("^anchor", ViewPort.anchorText)
      }
      @Test fun FindBytes_2Matches_BothGetHighlighted() {
         Model.writeMultiByteValue(0x10, 4, Token, 0x12345678)
         Model.writeMultiByteValue(0x24, 4, Token, 0x12345678)

         ViewPort.findBytes  = bytes( 0x78, 0x56, 0x34, 0x12)

         Assert.isFalse((((ViewPort[0, 0].format) as None)).isSearchResult)
         Assert.isFalse((((ViewPort[15, 15].format) as None)).isSearchResult)

         Assert.isTrue((((ViewPort[0, 1].format) as None)).isSearchResult)
         Assert.isTrue((((ViewPort[3, 1].format) as None)).isSearchResult)
         Assert.isFalse((((ViewPort[4, 1].format) as None)).isSearchResult)

         Assert.isFalse((((ViewPort[3, 2].format) as None)).isSearchResult)
         Assert.isTrue((((ViewPort[4, 2].format) as None)).isSearchResult)
         Assert.isTrue((((ViewPort[7, 2].format) as None)).isSearchResult)
         Assert.isFalse((((ViewPort[8, 2].format) as None)).isSearchResult)
      }
      @Test fun GotoTwice_GoBack_GoBack() {
         ViewPort.goto!!.execute(0x24)
         ViewPort.goto!!.execute(0x24)

         ViewPort.back.execute()

         Assert.equal(0, ViewPort.dataOffset)
      }
      @Test fun EditToExpand_Undo_SizeResets() {
         var initialCount = Model.count
         ViewPort.goto!!.execute(Model.count - 1)
         ViewPort.edit("AA AA AA AA AA AA AA AA ")

         ViewPort.undo.execute()

         Assert.equal(initialCount, Model.count)
      }
      @Test fun PointerToDataInSecondHalf_ContractFile_FormatsCleared() {
         Model.expandData(NoTrackChange(), 0x200000)
         ViewPort.edit("<180000>")
         var tool = ExpandRom(FileSystem)

         FileSystem.requestText  = { title, content -> "100000" }
         var result = tool.run(ViewPort)!!.result

         Assert.equal(ErrorInfo.noError, result)
         Model.resolveConflicts()
         Assert.equal(Int.MAX_VALUE, Model.getNextRun(0x0).start)
      }
      @Test fun SingleTableFocus_ExpandTableStreamWithoutRepoint_SeeFullStream() {
         SetFullModel(0xFF)
         ViewPort.edit("@100 00 00 11 11 22 22 @100 ^table[a. b.]!FFFF @000 ")
         ViewPort.allowSingleTableMode  = true
         ViewPort.goto!!.execute("table")

         Assert.equal(8, ViewPort.dataLength)

         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0x104)
         ViewPort.tools!!.tableTool!!.append.execute()

         Assert.equal(10, ViewPort.dataLength)
      }
      fun EndOfModel_LongRunFormat_Error(format: String) {
         ViewPort.goto!!.execute(0x1F0)
         ViewPort.edit(format)
         Assert.single(Errors)
      }
    @Test fun EndOfModel_LongRunFormat_Error_1() { EndOfModel_LongRunFormat_Error("^table[a: b: c: d: e:]3 ") }
    @Test fun EndOfModel_LongRunFormat_Error_2() { EndOfModel_LongRunFormat_Error("^text`asc`20 ") }
      @Test fun FormatWithinSelection_RightClick_CanClearFormat() {
         ViewPort.edit("@004 <null> @000 ")

         ViewPort.selectionEnd  = Point(11, 0)

         var context = ViewPort.getContextMenuItems(Point(0, 0), FileSystem)[1]
         Assert.equal("Clear Format", context.text)
      }
      @Test fun CopyPastedAnchor_AlreadyExists_RenamedUnique() {
         ViewPort.selectionStart  = newOf(4, 0)
         ViewPort.edit("^anchor.data ")

         ViewPort.selectionStart  = newOf(4, 1)
         ViewPort.edit("^anchor.data ")

         Assert.equal("^anchor.data_copy1", ViewPort.anchorText)
         Assert.notEmpty(Messages) // test that the user was informed about the auto-name change
      }
      @Test fun CopyPastedAnchor_AlreadyExists_UniqueIncrement() {
         ViewPort.selectionStart  = newOf(4, 0)
         ViewPort.edit("^anchor.data_copy999 ")

         ViewPort.selectionStart  = newOf(4, 1)
         ViewPort.edit("^anchor.data_copy999 ")

         Assert.equal("^anchor.data_copy1000", ViewPort.anchorText)
         Assert.notEmpty(Messages) // test that the user was informed about the auto-name change
      }
   }
