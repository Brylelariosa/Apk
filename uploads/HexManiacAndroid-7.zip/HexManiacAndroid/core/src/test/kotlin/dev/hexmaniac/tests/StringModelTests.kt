@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class StringModelTests : BaseViewModelTestClass() {
      @Test fun CanRecognizeString() {
         var buffer = ByteArray(0x100)
         var model = PokemonModel(buffer)
         var token = ModelDelta()

         var data = PCSString.convert("Hello World!")!!.toTypedArray()
         arrayCopy(data, 0, buffer, 0x10, data.size)
         model.observeRunWritten(token, PCSRun(model, 0x10, data.size))

         var run = (model.getNextRun(0) as PCSRun)
         Assert.equal(data.size, run.length)
      }
      @Test fun CanWriteString() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^bob\"\" \"Hello World!\"")

         var run = (model.getNextRun(0) as PCSRun)
         Assert.equal(13, run.length)
      }
      @Test fun CanFindStringsInData() {
         var buffer = ByteArray(0x100) { 0xFF.toByte() }
         var data = PCSString.convert("Hello World!")!!
         for (i in data.indices) buffer[0x10 + i] = data[i].toByte()
         var model1 = PokemonModel(buffer)
         var token = ModelDelta()
         model1.writePointer(token, 0x00, 0x10)

         var model = PokemonModel(buffer)

         Assert.isType<PCSRun>(model.getNextRun(0x10))
      }
      @Test fun TryingToWriteStringFormatToNonStringFormatDataFails() {
         ViewPort.edit("^\"\" ")

         Assert.notEmpty(Errors) // should get an error, because the data located at the cursor could not convert to a string.
      }
      @Test fun CanTruncateString() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^bob\"\" \"Hello World!\"")

         viewPort.selectionStart  = Point("Hello".length, 0)

         viewPort.edit("\"")

         var run = (model.getNextRun(0) as PCSRun)
         Assert.equal(6, run.length)
         Assert.all(arrayOf( 7, 8, 9, 10, 11, 12, 13), { i -> Assert.equal(0xFF, model[i]) })
      }
      @Test fun CanAutoMoveWhenHittingAnchor() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.selectionStart  = Point(8, 0)
         viewPort.edit("^bob FF FF FF FF <tom>")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^tom\"\" \"Some really long string\"")

         // the run was moved
         var run = model.getNextRun(0x10)
         Assert.isType<PCSRun>(run)

         // the original data is now cleared
         Assert.all(arrayOf( 0, 1, 2, 3), { i -> Assert.equal(0xFF, model[i]) })

         // pointer should be updated
         Assert.equal(run.start, model.readPointer(0xC))
      }
      @Test fun CanAutoMoveWhenHittingData() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.selectionStart  = Point(8, 0)
         viewPort.edit("A1 B3 64 18 <tom>")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^tom\"\" \"Some really long string\"")

         // the run was moved
         var run = model.getNextRun(0x10)
         Assert.isType<PCSRun>(run)
         Assert.equal(24, run.length)

         // the original data is now cleared
         Assert.equal(0xFF, model[0])
         Assert.equal(0xFF, model[1])
         Assert.equal(0xFF, model[2])
         Assert.equal(0xFF, model[3])

         // pointer should be updated
         Assert.equal(run.start, model.readPointer(0xC))
      }
      @Test fun AnchorWithNoNameIsNotValidIfNothingPointsToIt() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^ ")
         Assert.equal(NoInfoRun.nullRun, model.getNextRun(0))
         Assert.single(Errors)
         Assert.isType<None>(viewPort[0, 0].format)

         Errors.clear()

         viewPort.edit("^\"\" ")
         Assert.equal(NoInfoRun.nullRun, model.getNextRun(0))
         Assert.single(Errors)
      }
      @Test fun OpeningStringFormatIncludesOpeningQuote() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^bob\"\" \"Hello World!\"")
         var anchor = ((viewPort[0, 0].format) as Anchor)
         var innerFormat = (anchor.originalFormat as PCS)
         Assert.equal("\"H", innerFormat.thisCharacter)
      }
      @Test fun CannotAddNewStringAnchorUnlessItEndsBeforeNextKnownAnchor() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         for (i in 0 until 0x10) model[i]  = 0x00

         // add an anchor with some data on the 2nd line
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^bob\"\" \"Hello World!\"")

         // but now, try to add a string format in the middle of all the 00 bytes
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^tom\"\" ")

         // trying to add a string anchor should've failed
         Assert.single(Errors)
         Assert.equal(0x10, model.getNextRun(1).start)
         Assert.isType<None>(viewPort[0, 0].format)
      }
      @Test fun UsingBackspaceMidStringMakesTheStringEndThere() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         for (i in 0 until 0x10) model[i]  = 0x00

         // add an anchor with some data on the 2nd line
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^bob\"\" \"Hello World!\"")
         viewPort.selectionStart  = Point(6, 1)
         viewPort.edit(ConsoleKey.Backspace)

         Assert.equal("\"Hello \"", PCSString.convert(model, 0x10, PCSString.readString(model, 0x10, true)))
      }
      @Test fun UsingEscapeSequencesWorks() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         for (i in 0 until 0x10) model[i]  = 0x00

         viewPort.edit("^bob\"\" \"Some Content \\\\03More Content\"")

         Assert.equal(28, model.getNextRun(0).length)
         Assert.isType<EscapedPCS>(viewPort[14, 0].format)
      }
      @Test fun CanCopyStrings() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         for (i in 0 until 0x10) model[i]  = 0x00
         var fileSystem = StubFileSystem()

         viewPort.edit("^bob\"\" \"Hello World!\"")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.selectionEnd  = Point(12, 0)
         viewPort.copy!!.execute(fileSystem)

         Assert.equal("^bob\"\" \"Hello World!\"", fileSystem.copyText)
      }
      @Test fun FindForStringsIsNotCaseSensitive() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         for (i in 0 until 0x10) model[i]  = 0x00
         viewPort.edit("^bob\"\" \"Text and BULBASAUR!\"")

         var results = viewPort.find("\"bulbasaur\"").map({ result -> result.start }).toMutableList()
         Assert.single(results)
         Assert.equal(9, results[0])
      }
      @Test fun FindForStringsWorksWithoutQuotes() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         for (i in 0 until 0x10) model[i]  = 0x00
         viewPort.edit("^bob\"\" \"Text and BULBASAUR!\"")

         var results = viewPort.find("bulbasaur").map({ result -> result.start }).toMutableList()
         Assert.single(results)
         Assert.equal(9, results[0])
      }
      @Test fun CanNameExistingStringAnchor() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         var bytes = PCSString.convert("Hello World!")!!.toTypedArray()
         model[0]  = 0x08
         model[1]  = 0x00
         model[2]  = 0x00
         model[3]  = 0x08
         arrayCopy(bytes, 0, model.rawData, 0x08, bytes.size)

         viewPort.selectionStart  = Point(0x08, 0)
         viewPort.edit("^")
         viewPort.edit("bob\"\" ")

         Assert.equal("bob", (((viewPort[0, 0].format) as Pointer)).destinationName)
      }
      @Test fun FormatIsRemovedWhenEditingAnAnchor() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         var bytes = PCSString.convert("Hello World!")!!.toTypedArray()
         model[0]  = 0x08
         model[1]  = 0x00
         model[2]  = 0x00
         model[3]  = 0x08
         arrayCopy(bytes, 0, model.rawData, 0x08, bytes.size)

         viewPort.selectionStart  = Point(0x08, 0)
         viewPort.edit("^")

         var underEdit = ((viewPort[8, 0].format) as UnderEdit)
         Assert.equal("^", underEdit.currentText)
      }
      @Test fun UsingTheAnchorEditorToSetStringFormatChangesVisibleData() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         var bytes = PCSString.convert("Hello World!")!!.toTypedArray()
         arrayCopy(bytes, 0, model.rawData, 0x08, bytes.size)
         viewPort.selectionStart  = Point(0x08, 0)
         viewPort.edit("^bob ")

         viewPort.anchorText  = "^bob\"\""

         var anchor = ((viewPort[8, 0].format) as Anchor)
         Assert.isType<PCS>(anchor.originalFormat)
      }
      @Test fun CanUndoStringTruncate() {
         SetFullModel(0xFF)
         ViewPort.edit("<008> @08 ^text\"\" \"Hello World!\" ")

         ViewPort.selectionStart  = Point(0x0C, 0)
         ViewPort.edit(ConsoleKey.Backspace)
         ViewPort.undo.execute()

         Assert.equal(13, Model.getNextRun(0x08).length)
         Assert.equal("\"Hello World!\"", (((ViewPort[0x0C, 0].format) as PCS)).fullString)
      }
      @Test fun PointersPastEndOfDataDoNotCountAsPointers() {
         var buffer = Enumerable.Repeat(0xFF.u8(), 0x200).toTypedArray()
         buffer[4]  = 0x20
         buffer[5]  = 0x20
         buffer[6]  = 0x20
         buffer[7]  = 0x08

         // it should realize that the data starting at 4 isn't a pointer
         // because 202020 is after the end of the data
         var model = PokemonModel(buffer.toByteArr())

         Assert.equal(Int.MAX_VALUE, model.getNextRun(0).start)
      }
      @Test fun StringSearchAutomaticallySearchesForPointersToResults() {
         var text = "This is the song that never ends."
         var bytes = PCSString.convert(text)!!.toTypedArray()
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         arrayCopy(bytes, 0, model.rawData, 0x32, bytes.size);                // the data itself, positioned at x32 (won't be automatically found on load)
         arrayCopy(bytes( 0x32, 0, 0, 0x08), 0, model.rawData, 0x10, 4); // the pointer to the data. Pointer is aligned, but data is not.

         // the act of searching should find the anchor
         var results = viewPort.find("this is the song")

         Assert.single(results)
         Assert.single(model.getNextRun(0x32).pointerSources)
      }
      @Test fun UnnamedStringAnchorAutomaticallySearchesForPointersToAnchor() {
         var text = "This is the song that never ends."
         var bytes = PCSString.convert(text)!!.toTypedArray()
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         arrayCopy(bytes, 0, model.rawData, 0x32, bytes.size);                // the data itself, positioned at x32 (won't be automatically found on load)
         arrayCopy(bytes( 0x32, 0, 0, 0x08), 0, model.rawData, 0x10, 4); // the pointer to the data. Pointer is aligned, but data is not.

         // the act of dropping an anchor should search for pointers
         viewPort.selectionStart  = Point(2, 3)
         viewPort.edit("^\"\" ")

         Assert.equal(0x32, model.getNextRun(0x32).start)
         Assert.single(model.getNextRun(0x32).pointerSources)
      }
      @Test fun CopyAnUnnamedStringInsertsAName() {
         var text = "This is the song that never ends."
         var bytes = PCSString.convert(text)!!.toTypedArray()
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         arrayCopy(bytes, 0, model.rawData, 0x30, bytes.size)
         arrayCopy(bytes( 0x30, 0, 0, 0x08), 0, model.rawData, 0x10, 4); // the pointer to the data. Pointer is aligned, but data is not.
         var fileSystem = StubFileSystem()
         model.load(model.rawData, null)
         ViewPort.refresh()

         viewPort.selectionStart  = Point(0, 3)
         viewPort.expandSelection(0, 3)
         viewPort.copy!!.execute(fileSystem)

         Assert.contains(".This", fileSystem.copyText)
         Assert.contains("\"\" \"This", fileSystem.copyText) // format, then space, then start of text
      }
      @Test fun AddingNewAnchorWithSameNameRenamesNewAnchorWithMessage() {
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("^anchor ")
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^anchor ")

         Assert.notEqual("anchor", (((viewPort[0, 1].format) as Anchor)).name)
         Assert.single(Messages)
      }
      @Test fun CanUseViewPortToAutoFindTextWithoutKnowingAboutPointersToIt() {
         var text = PCSString.convert("This is some text.")
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         text.copyInto(model.rawData, 0x10)
         model.writePointer(ModelDelta(), 0x00, 0x10)

         viewPort.selectionStart  = Point(3, 1); // just a random byte in the middle of the text

         viewPort.isText.execute(); // this line should find the start of the text and add a run, even with no pointer to it

         Assert.isType<PCS>(viewPort[3, 1].format)
      }
      @Test fun ChangingTerminalByteInTableTextAddsNewTerminalByteAfter() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)
         model[3]  = 0xFF
         viewPort.edit("^table[text\"\"8]1 ")

         viewPort.edit("abcd")

         Assert.equal(0xFF, model[4])
      }
      @Test fun CopyTextArrayEntryDoesNotCopyMultipleEndOfStreams() {
         var model = PokemonModel(ByteArray(0x200) { 0xFF.toByte() })
         val run = Ref<ITableRun?>(null)
         ArrayRun.tryParse(model, "[name\"\"6]4", 0, null, run)
         model.observeAnchorWritten(ModelDelta(), "table", run.value!!)

         var text = model.copy({ ModelDelta() }, 6, 6).trim()

         Assert.equal("+\"\"", text)
      }
      @Test fun CanAutoDetectMultipleTextRunsAtOnce() {
         var test = BaseViewModelTestClass()
         var token = test.ViewPort.currentChange

         // Arrange some undetected pointers to some undetected text
         test.Model.writePointer(token, 0, 0x10)
         test.Model.writePointer(token, 4, 0x15)
         var write: Int = 0x10
         test.Model[0xF]  = 0xFF
         PCSString.convert("text")!!.forEach({ b -> test.Model[write++]  = b })
         PCSString.convert("more")!!.forEach({ b -> test.Model[write++]  = b })

         // add some more text/pointers later on that *are* detected
         test.Model.writePointer(token, 8, 0x40)
         test.Model[0x40]  = 0xFF
         test.ViewPort.edit("@40 ^discovered\"\" Blob\" @00 ")

         // select from partway through the first text to partway through the second text and "Display as Text"
         test.ViewPort.selectionStart  = Point(1, 1)
         test.ViewPort.selectionEnd  = Point(7, 1)
         var group = ((test.ViewPort.getContextMenuItems(Point(4, 1)).single({ item -> item.text == "Display As..." })) as ContextItemGroup)
         var button = group.single({ item -> item.text == "Text" })
         button.command.execute()

         // Verify that we found both
         Assert.equal(0, test.Model.getNextRun(0).start);       // first pointer
         Assert.equal(4, test.Model.getNextRun(4).start);       // second pointer
         Assert.equal(0x10, test.Model.getNextRun(0x10).start); // first text
         Assert.equal(0x15, test.Model.getNextRun(0x15).start) // second text
      }
      @Test fun PCSStringControlCodeForFuncionEscapesIsEscaped() {
         Assert.isTrue(PCSString.isEscaped(bytes( PCSString.functionEscape, 0x0A).asByteList(), 1))
      }
      @Test fun ControlCode_Pause_OneByteIsEscaped() {
         var test = BaseViewModelTestClass()
         val i = Ref<Int>(0)
         Write(test.Model, i, "ABC")
         test.Model[i.value++]  = PCSString.functionEscape
         test.Model[i.value++]  = 0x09; //pause: no variables
         Write(test.Model, i, "XYZ\"")

         test.ViewPort.edit("^text\"\"")

         Assert.isType<EscapedPCS>(test.ViewPort[4, 0].format)
         Assert.isNotType<EscapedPCS>(test.ViewPort[5, 0].format)
         Assert.equal("ABC\\CC09XYZ", ((test.Model.getNextRun(0) as PCSRun)).serializeRun())
      }
      @Test fun StringWithControlCode_Parsed_CorrectBytes() {
         var model = PokemonModel(ByteArray(0x100))
         val i = Ref<Int>(0)
         Write(model, i, "ABC")
         model[i.value++]  = PCSString.functionEscape
         model[i.value++]  = 0x09; //pause: no variables
         Write(model, i, "XYZ\"")
         var target = model.take(i.value).toTypedArray()

         var result = PCSString.convert("ABC\\CC09XYZ")!!.toTypedArray()

         Assert.equal(target, result)
      }
      @Test fun Text_TypeDot_DotAdded() {
         var test = BaseViewModelTestClass()
         arrayCopy(PCSString.convert("Hello World")!!, test.Model.rawData, 12)
         test.Model.observeRunWritten(test.ViewPort.currentChange, PCSRun(test.Model, 0, 12))
         test.ViewPort.refresh()

         test.ViewPort.edit("@01 .")

         Assert.equal(2, test.ViewPort.convertViewPointToAddress(test.ViewPort.selectionStart))
         Assert.equal("\"H.llo World\"", PCSString.convert(test.Model, 0, 12))
      }
      @Test fun TextWithEscape_Search_Find() {
         var text = "Some\\nText"
         PCSString.convert(text)!!.writeInto(Model.rawData, 0x20)

         var results = ViewPort.find(text)

         Assert.equal(0x20, results.single().start)
      }
      @Test fun DisplayAsText_PreviousByteRandom_StillFindTextStartingHere() {
         PCSString.convert("Some Content")!!.writeInto(Model.rawData, 0x21)
         Model.writePointer(ModelDelta(), 3, 0x21)
         ViewPort.goto!!.execute(0x21)

         var menu = ViewPort.getContextMenuItems(ViewPort.selectionStart)
         menu  = menu.getSubmenu("Display As...")
         var displayText = menu.single({ item -> item.text == "Text" })
         displayText.command.execute()

         Assert.isType<PCSRun>(Model.getNextRun(0x21))
      }
      @Test fun NamelessAnchor_Copy_StillHasNoName() {
         var fs = StubFileSystem()
         ViewPort.edit("<100> @100 @!put(FF) ^\"\" text")

         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fs)

         Assert.contains("misc", fs.copyText.value)
         Assert.equal("^\"\"", ViewPort.anchorText)
      }
      @Test fun NamelessAnchor_Cut_PointerGetsName() {
         var fs = StubFileSystem()
         ViewPort.edit("<100> @100 @!put(FF) ^\"\" text")

         ViewPort.expandSelection(0, 0)
         ViewPort.cut(fs)

         var pointer = Model.exportMetadata(Singletons.metadataInfo)!!.unmappedPointers.single()
         Assert.equal(0, pointer.address)
         Assert.contains("misc", pointer.name)
      }
      @Test fun RedoAvailable_Copy_CanRedo() {
         var fs = StubFileSystem()
         ViewPort.edit("<020> @20 @!put(FF) ^\"\" text @180 DEADBEEF")
         ViewPort.undo.execute()

         ViewPort.goto!!.execute(0x20)
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(fs)

         Assert.isTrue(ViewPort.redo.canExecute(null))
      }
      @Test fun TextTable_Backspace_UpdateHeaders() {
         ViewPort.useCustomHeaders  = true
         CreateTextTable("table", 0, "adam", "bob", "carl", "dave")

         ViewPort.goto!!.execute(2)
         ViewPort.edit(ConsoleKey.Backspace)

         Assert.notEqual("adam", ViewPort.headers!![0])
      }
      @Test fun TextTable_Delete_UpdateHeaders() {
         ViewPort.useCustomHeaders  = true
         CreateTextTable("table", 0, "adam", "bob", "carl", "dave")

         ViewPort.goto!!.execute(2)
         ViewPort.clear!!.execute()

         Assert.notEqual("adam", ViewPort.headers!![0])
      }
      @Test fun TextTable_EditViaTableTool_UpdateHeaders() {
         ViewPort.useCustomHeaders  = true
         CreateTextTable("table", 0, "adam", "bob", "carl", "dave")

         ViewPort.goto!!.execute(2)
         var vm = ((ViewPort.tools!!.tableTool!!.children[1]) as FieldArrayElementViewModel)
         vm.content  = "am"

         Assert.notEqual("adam", ViewPort.headers!![0])
      }
      @Test fun ControlCharacterText_CopyPaste_SameBytesPasted() {
         SetFullModel(0xFF)
         //             T  M  1  3  cc 13 48  4  ,  0  0  0     C  O  I  N  S
         var payload = "CE C7 A2 A4 FC 13 48 A5 B8 A1 A1 A1 00 BD C9 C3 C8 CD FF".parseHexBytes()
         Token.changeData(Model, 0, payload)
         ViewPort.edit("^text\"\" ")

         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(FileSystem)
         ViewPort.goto!!.execute(0x100)
         ViewPort.edit(FileSystem.copyText!!)

         var result = payload.size.range().map({ i -> Model[i + 0x100] }).toTypedArray()
         Assert.equal(payload, result)
      }
      @Test fun TextList_Goto_PreferExactMatch() {
         this.CreateTextTable("names", 0x100, "content", "THUNDERPUNCH", "other", "THUNDER", "something")

         ViewPort.goto!!.execute("thunder")

         Assert.equal(3, ViewPort.tools!!.tableTool!!.currentElementSelector.selectedIndex)
      }
      fun TextWithMacro_Convert_CorrectBytes(gameCode: String, macro: String, bytes: String) {
         val containsBadCharacters = Ref<Boolean>(false)
         var result = PCSString.convert(macro, gameCode, containsBadCharacters)
         Assert.isFalse(containsBadCharacters.value)
         Assert.equal(bytes.parseHexBytes(), result)
      }
    @Test fun TextWithMacro_Convert_CorrectBytes_1() { TextWithMacro_Convert_CorrectBytes("BPRE", "[white]", "FC 01 00 FF") }
      fun BytesWithMacro_Convert_CorrectText(gameCode: String, macro: String, bytesAsText: String) {
         var bytes = bytesAsText.parseHexBytes()
         var result = PCSString.convert(gameCode, bytes.asByteList(), 0, bytes.size)
         Assert.equal(macro, result)
      }
    @Test fun BytesWithMacro_Convert_CorrectText_1() { BytesWithMacro_Convert_CorrectText("BPEE", "\"[orange]\"", "FC 01 05 FF") }
      @Test fun TextWithMacro_ShowInHexContent_FirstByteDoesNotShowMacro() {
         SetFullModel(0xFF)
         HackTextConverter("BPRE")

         Token.changeData(Model, 0, bytes( 0xFC, 0x01, 0x05, 0xFF))
         Model.observeRunWritten(Token, PCSRun(Model, 0, 4))
         ViewPort.refresh()
         var cell = ((ViewPort[0, 0].format) as PCS)

         Assert.equal("\"\\CC", cell.thisCharacter)
      }
      @Test fun SearchText_NoResults_NoMetadataChange() {
         var results = ViewPort.find("Not in file")
         Assert.empty(results)
         Assert.isTrue(ViewPort.changeHistory.isSaved)
      }
      @Test fun TextAnchor_ChangeToNoInfoAnchor_NoNameIsError() {
         SetFullModel(0xFF)
         ViewPort.edit("^text\"\" ")

         ViewPort.anchorText  = "^"

         Assert.notEmpty(Errors)
      }
      @Test fun AddTextAnchorName_EditWithTextTool_BytesUpdate() {
         Model[4]  = 0xFF
         Token.changeData(Model, 5, PCSString.convert("test")!!)
         Model.writePointer(Token, 0x100, 5)
         ViewPort.selectionStart  = newOf(6, 0)
         ViewPort.shortcuts.displayAsText.execute()

         ViewPort.selectionStart  = newOf(5, 0)
         ViewPort.anchorText  = "^name\"\""

         ViewPort.tools!!.stringTool!!.contentIndex  = 1
         ViewPort.tools!!.stringTool!!.content  = "tst"

         Assert.equal("tst", PCSString.convert(Model, 5, 5)!!.trim('"'))
      }
      @Test fun BytesWithColorMacro_CopyTextThenPaste_SameBytes() {
         SetFullModel(0xFF)
         HackTextConverter("BPRE")
         var bytes = "CD E3 E1 D9 FC 01 06 CE D9 EC E8 FF".parseHexBytes(); // Some[green]Text
         Token.changeData(Model, 0, bytes)
         ViewPort.refresh()
         ViewPort.edit("^text\"\"")

         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(FileSystem)
         ViewPort.goto!!.execute(0x30)
         ViewPort.edit(FileSystem.copyText!!)

         ViewPort.goto!!.execute(0x30)
         ViewPort.expandSelection(0, 0)
         ViewPort.copyBytes.execute(FileSystem)
         var result = FileSystem.copyText.value!!.parseHexBytes()
         Assert.equal(bytes, result)
      }
      @Test fun SpecialCharacters_MatchAgainstNormalCharacters_Match() {
         Assert.isTrue("\u00E1.\u00E9".matchesPartialWithReordering("ea"))
         Assert.isTrue("a.e".matchesPartialWithReordering("\u00E9\u00E1"))
      }
      @Test fun AsciiText_LastEdit_Notify() {
         SetFullModel(0xFF)
         ViewPort.edit("^test`asc`7 123456")

         var view = StubView(ViewPort.tools!!.stringTool!!)
         ViewPort.edit("7")

         Assert.equal("1234567", ViewPort.tools!!.stringTool!!.content)
         Assert.contains("content", view.propertyNotifications)
      }
      @Test fun FalsePointer_FindText_Works() {
         ViewPort.edit("<100> 01 00 08 "); // looks like a pointer 0->100, but is actually a pointer 3->108
         Token.changeData(Model, 0x108, PCSString.convert("Some Content")!!)

         ViewPort.goto!!.execute(0x108)
         ViewPort.shortcuts.displayAsText.execute()

         Assert.equal(3, Model.getNextRun(0).start)
         Assert.isType<PCSRun>(Model.getNextRun(0x108))
      }
      @Test fun FalseRuns_FindText_Works() {
         Token.changeData(Model, 0x109, PCSString.convert("Some Content")!!)
         ViewPort.edit("<10E> 00 09 01 00 08")

         ViewPort.goto!!.execute(0x109)
         ViewPort.shortcuts.displayAsText.execute()

         Assert.equal(5, Model.getNextRun(0).start)
         Assert.equal(13, Model.getNextRun(0x109).length)
      }
      @Test fun TextPointerInTable_FormatText_TableStillExists() {
         ViewPort.edit("^table[ptr<>]4 ")
         ViewPort.edit("<100> <108> <090> <080> ")
         Token.changeData(Model, 0x108, PCSString.convert("Some Content")!!)

         ViewPort.goto!!.execute(0x108)
         ViewPort.shortcuts.displayAsText.execute()

         Assert.isAssignableFrom<ITableRun>(Model.getNextRun(0))
      }
      @Test fun TableWithZeroLengthString_Error() {
         ViewPort.edit("^table[text\"\"0]1 ")
         Assert.single(Errors)
      }
      @Test fun Table_OnlyZeroLengthSegments_Error() {
         ViewPort.edit("^table[field|=() ]1 ")
         Assert.single(Errors)
      }
      @Test fun TextTable_LongText_Error() {
         var vm = BaseViewModelTestClass(0x4000)
         vm.SetFullModel(0xFF)
         vm.ViewPort.edit("^table[text\"\"2000]1 ")
         Assert.notEmpty(vm.Errors)
      }
      @Test fun ListWithNoMatches_LookForBestPartialMatch_PreferTextStartsTheSame() {
         var list = mutableListOf<String>( "abc", "cde", "xyz")
         val value = Ref<Int>(0)
         var foundMatch = ArrayRunEnumSegment.tryMatch("c", list, value)

         Assert.isTrue(foundMatch)
         Assert.equal(1, value.value) // matches "cde" over "abc" because it starts with "c"
      }
      @Test fun TextContainsNewline_Copy_IncludeNewlines() {
         SetFullModel(0xFF)
         ViewPort.edit("^text\"\" Line1\\nLine2")

         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.expandSelection(0, 0)
         ViewPort.copy!!.execute(FileSystem)

         Assert.contains("\\n", FileSystem.copyText.value)
      }

      private fun HackTextConverter(game: String) {
         var converter = New.pcsConverter(game)
         (Model as BaseModel).textConverter = converter
      }

      private fun Write(model: IDataModel, i: Ref<Int>, characters: String) {
         for (c in characters.toCharArray())
            model[i.value++]  = (PCSString.pcs.indexOf(c.toString())).u8()
      }
   }
