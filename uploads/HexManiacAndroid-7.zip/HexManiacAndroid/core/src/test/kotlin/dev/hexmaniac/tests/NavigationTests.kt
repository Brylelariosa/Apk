@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class NavigationTests : BaseViewModelTestClass() {
      @Test fun AddressesAreCorrect() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.width = 0x10; it.height = 0x10 }

         Assert.equal("000000", viewPort.headers!![0])
         Assert.equal("000010", viewPort.headers!![1])
         Assert.equal(viewPort.height, viewPort.headers!!.size)
      }
      @Test fun AddressUpdateOnWidthChanged() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.preferredWidth = -1; it.width = 0x10; it.height = 0x10 }
         var changeCount = 0
         viewPort.headers!!.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.width++

         Assert.inRange(changeCount, 1, viewPort.height)
         Assert.equal("000011", viewPort.headers!![1])
      }
      @Test fun AddressUpdateOnScroll() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.width = 0x10; it.height = 0x10 }
         var changeCount = 0
         viewPort.headers!!.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.scrollValue++

         Assert.inRange(changeCount, 1, viewPort.height)
         Assert.equal("000020", viewPort.headers!![1])
      }
      @Test fun AddressExtendOnHeightChanged() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.width = 0x10; it.height = 0x10 }
         var changeCount = 0
         viewPort.headers!!.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.height++

         Assert.inRange(changeCount, 1, viewPort.height)
         Assert.equal(viewPort.height, viewPort.headers!!.size)
      }
      @Test fun AddressMissingIfBeforeFile() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.width = 0x10; it.height = 0x10 }
         var changeCount = 0
         viewPort.headers!!.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.scroll.execute(Direction.Left)

         Assert.inRange(changeCount, 1, viewPort.height)
         Assert.equal("", viewPort.headers!![0])
         Assert.equal("00000F", viewPort.headers!![1])
      }
      @Test fun AddressMissingIfAfterEndOfFile() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.width = 0x10; it.height = 0x10 }
         var changeCount = 0
         viewPort.headers!!.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.scrollValue  = viewPort.maximumScroll

         Assert.inRange(changeCount, 1, viewPort.height)
         Assert.equal("0001F0", viewPort.headers!![0])
         Assert.equal("", viewPort.headers!![1])
      }
      @Test fun AddressAddedIfFileGrows() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x200))).also { it.width = 0x10; it.height = 0x10 }
         var changeCount = 0
         viewPort.headers!!.collectionChanged  += { sender, e -> changeCount  += 1 }

         viewPort.scrollValue  = viewPort.maximumScroll
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("FF")

         Assert.equal("000200", viewPort.headers!![1])
      }
      @Test fun GotoWorks() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }

         viewPort.goto!!.execute("000300")

         Assert.equal("000300", viewPort.headers!![0])
      }
      @Test fun GotoIsNotCaseSensitive() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }

         viewPort.goto!!.execute("000a00")

         Assert.equal("000A00", viewPort.headers!![0])
      }
      @Test fun GotoIsReversable() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }

         var changeCount = 0
         viewPort.forward.canExecuteChanged  += { sender, e -> changeCount++ }

         viewPort.goto!!.execute("000A00")
         Assert.equal(0, changeCount)

         viewPort.back.execute()
         Assert.equal(1, changeCount)

         Assert.equal("000000", viewPort.headers!![0])
      }
      @Test fun BackIsReversable() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }

         var changeCount = 0
         viewPort.back.canExecuteChanged  += { sender, e -> changeCount++ }

         viewPort.goto!!.execute("000A00")
         Assert.equal(1, changeCount)

         viewPort.back.execute()
         Assert.equal(2, changeCount)

         viewPort.forward.execute()
         Assert.equal(3, changeCount)

         Assert.equal("000A00", viewPort.headers!![0])
      }
      @Test fun CannotBackFromSearchTab() {
         var searchTab = SearchResultsViewPort("bob")
         Assert.isFalse(searchTab.back.canExecute(null))
         Assert.isFalse(searchTab.forward.canExecute(null))
      }
      @Test fun BackRecallsYourLastScrollPosition() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }
         viewPort.selectionStart  = Point(0, 4)

         viewPort.scrollValue++
         viewPort.goto!!.execute("000A00")
         viewPort.scrollValue++
         viewPort.back.execute()
         Assert.equal("000010", viewPort.headers!![0])

         viewPort.forward.execute()
         Assert.equal("000A10", viewPort.headers!![0])
      }
      @Test fun GotoMovesScroll() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }

         viewPort.goto!!.execute("000A00")

         Assert.notEqual(0, viewPort.scrollValue)
      }
      @Test fun GotoErrorsOnBadAddress() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }
         var errorCount: Int = 0
         viewPort.onError  += { sender, e -> errorCount  += 1 }

         viewPort.goto!!.execute("BadAddress")

         Assert.equal(1, errorCount)
      }
      @Test fun GotoMovesSelection() {
         var viewPort = ViewPort(LoadedFile("test.txt", ByteArray(0x1000))).also { it.width = 0x10; it.height = 0x10 }

         viewPort.goto!!.execute("000C00")

         Assert.equal(Point(0, 0), viewPort.selectionStart)
      }
      @Test fun SearchFor6BytesAlsoFindsPointers() {
         var test = BaseViewModelTestClass(0x1200)

         test.ViewPort.edit("<001060>")
         var results = test.ViewPort.find("001060")

         Assert.single(results)
      }
      @Test fun CanGotoUsingAtSymbol() {
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(Ref<ByteArray>(nullOf()), Ref<PokemonModel>(nullOf()), viewPort)

         viewPort.value.edit("@100 ")

         Assert.equal("000100", viewPort.value.headers!![0])
      }
      @Test fun CanGotoAddressWith08Prepended() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         var errors = ArrayList<String>()
         viewPort.value.onError  += { sender, e -> errors.add(e) }

         viewPort.value.goto!!.execute("8000100")

         Assert.empty(errors)
         Assert.equal(0x100, viewPort.value.dataOffset)
      }
      @Test fun CanGotoAddressWithAngleBraces() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         var errors = ArrayList<String>()
         viewPort.value.onError  += { sender, e -> errors.add(e) }

         viewPort.value.goto!!.execute("<000100>")

         Assert.empty(errors)
         Assert.equal(0x100, viewPort.value.dataOffset)
      }
      @Test fun GotoBadPointerErrors() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         var errors = ArrayList<String>()
         viewPort.value.onError  += { sender, e -> errors.add(e) }

         viewPort.value.edit("^table[p<>]2 ")
         viewPort.value.followLink(1, 0)

         Assert.single(errors)
      }
      @Test fun TableLengthChangeShouldNotCauseGoto() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)

         viewPort.value.selectionStart  = Point(0, 2)
         viewPort.value.edit("^bob[data.]10 ");             // auto scroll (table format change)
         viewPort.value.goto!!.execute("000000")
         viewPort.value.selectionStart  = Point(0, 2)
         viewPort.value.anchorText  = "^bob[data.]12";       // no auto scroll (table length change)

         Assert.equal("000000", viewPort.value.headers!![0])
      }
      @Test fun CanResetAlignment() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         var editor = New.editorViewModel()
         editor.add(viewPort.value!!)

         viewPort.value.goto!!.execute("10")
         viewPort.value.edit("^moves[name\"\"8]8 Adam\" Bob\" Carl\" Dave\" Elen\" Fred\" Gary\" Horton\"")
         viewPort.value.width  = 25
         Assert.equal(24, viewPort.value.width); // closest smaller multiple of 8

         editor.resetAlignment.execute()
         Assert.equal(16, viewPort.value.width) // closest smaller multiple of 16
      }
      @Test fun GotoAutocompleteIncludesTableFields() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("^table[field1:: field2<>]2 ")

         (ModelCacheScope.createScope(test.Model)).use { _ ->
            var options = test.Model.getAutoCompleteAnchorNameOptions("table/0/")

            Assert.contains("table/0/field1", options)
            Assert.contains("table/0/field2", options)

            options  = test.Model.getAutoCompleteAnchorNameOptions("table//field2/")

            Assert.contains("table/0/field2/", options)
            Assert.contains("table/1/field2/", options)
          }
      }
      @Test fun CanSearchForBranchLink() {
         var test = BaseViewModelTestClass()
         var command1 = test.ViewPort.tools!!.codeTool!!.parser.compile(test.Model, 0x0010, "bl <000060>").toTypedArray()
         var command2 = test.ViewPort.tools!!.codeTool!!.parser.compile(test.Model, 0x0100, "bl <000060>").toTypedArray()
         arrayCopy(command1, 0, test.Model.rawData, 0x0010, command1.size)
         arrayCopy(command2, 0, test.Model.rawData, 0x0100, command2.size)

         var results = test.ViewPort.find("bl <000060>").toMutableList()

         Assert.equal(2, results.size)
         Assert.equal(0x010, results[0].start)
         Assert.equal(0x100, results[1].start)
      }
      @Test fun SelectionLengthIsPositiveWhenSelectingLeft() {
         var test = BaseViewModelTestClass()

         test.ViewPort.selectionStart  = Point(3, 0)
         test.ViewPort.selectionEnd  = Point(0, 0)

         Assert.contains("4", test.ViewPort.selectedLength)
      }
      @Test fun CanPrefixAddressWith0xDuringGoto() {
         var editor = EditorViewModel(StubFileSystem())
         var test = BaseViewModelTestClass()
         editor.add(test.ViewPort)

         editor.gotoViewModel.goto!!.execute("0x0030")

         Assert.equal(0x30, test.ViewPort.dataOffset)
      }
      @Test fun CanGotoNamedElements() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable("names", 0x100, *("Adam Bob Carl Dave Eric Fred Greg Hal Jim".split(" ")))
         test.ViewPort.edit("@00 ^table[content.]names ")

         test.ViewPort.goto!!.execute("table/Eric")

         Assert.equal(4, test.ViewPort.dataOffset)
      }
      @Test fun CanGotoSecondNamedElementWithSameName() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable("names", 0x100, *("Adam Bob Carl Dave Eric Dave Fred Greg Hal Jim".split(" ")))
         test.ViewPort.edit("@00 ^table[content.]names ")

         test.ViewPort.goto!!.execute("table/Dav~2")

         Assert.equal(5, test.ViewPort.dataOffset)
      }
      @Test fun CanFollowPointerInline() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("00 01 02 03 <000100> @04 @{ 80 @} ")
         Assert.equal(0, test.ViewPort.dataOffset)
         Assert.equal(Point(8, 0), test.ViewPort.selectionStart)
         Assert.equal(0x80, test.Model[0x100])
      }
      @Test fun CanCreatePointerInline() {
         var test = BaseViewModelTestClass()

         test.ViewPort.edit("^table[content<\"\">]2 @{ Hello!\" @}")
         var matches = test.ViewPort.find("Hello!")

         Assert.equal(4, test.ViewPort.dataOffset)
         Assert.equal(Point(0, 0), test.ViewPort.selectionStart)
         Assert.single(matches)
      }
      @Test fun CanGotoSingleOptionEvenWithoutPerfectMatch() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("^pizza @piza ")
         Assert.empty(test.Errors)

         test.ViewPort.edit("@20 ^candy ")
         var editor = EditorViewModel(StubFileSystem())
         editor.add(test.ViewPort)
         editor.gotoViewModel.text  = "cady"
         editor.gotoViewModel.goto!!.execute()

         Assert.empty(test.Errors)
      }
      @Test fun NoNamespaceHasMoreThanNineElements() {
         var singletons = BaseViewModelTestClass.Singletons
         for (game in singletons.gameReferenceTables.keys) {
            var gameTables = singletons.gameReferenceTables[game]
            var namespaces = LinkedHashMap<String, MutableSet<String>>()
            for (table in gameTables!!) {
               var tokens = table.name.split(".")
               for (i in 1 until tokens.size) {
                  var prefix = ".".join(tokens.take(i))
                  if (!namespaces.containsKey(prefix)) namespaces[prefix]  = newOf()
                  namespaces[prefix]!!.add(tokens[i])
               }
            }
            var exempt = arrayOf(
               "data.pokemon.moves",
               "data.pokemon",
               "graphics.menu",
               "graphics",)
            Assert.all(namespaces.keys, lm1@{ currentNamespace ->
               var elements = namespaces[currentNamespace]
               var limit = if (currentNamespace.contains('.')) 9 else 16
               if (exempt.contains(currentNamespace)) limit  += 4
               Assert.isTrue(elements!!.size.inRange(0, limit + 1), "${game}: ${currentNamespace} has ${elements!!.size} entries, but shouldn't have more than ${limit}.")
            })
         }
      }
      @Test fun NamedConstant_PasteScriptAtEquals_ValueChange() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         viewPort.value.edit("@00 .some.number @10 .some.number @20 ")

         viewPort.value.edit("@some.number=7 ")

         Assert.equal(7, model.value[0x00])
         Assert.equal(7, model.value[0x10])
      }
      @Test fun NamedConstant_PasteScriptGotoSpecifyIndex2_GotoSecondInstance() {
         val data = Ref<ByteArray>(nullOf())
         val model = Ref<PokemonModel>(nullOf())
         val viewPort = Ref<ViewPort>(nullOf())
         StandardSetup(data, model, viewPort)
         viewPort.value.edit("@00 .some.number @10 .some.number @20 ")

         viewPort.value.edit("@some.number~2 ")

         Assert.equal(0x10, viewPort.value.convertViewPointToAddress(viewPort.value.selectionStart))
      }
      @Test fun FreeSpaceStart_GotoFreeSpaceStart() {
         var test = BaseViewModelTestClass()

         test.ViewPort.freeSpaceStart  = 0x100
         test.ViewPort.gotoFreeSpaceStart.execute()

         Assert.equal(0x100, test.ViewPort.dataOffset)
      }
      @Test fun AnchorWithPluralNamePart_GotoSinglularVersion_Works() {
         var test = BaseViewModelTestClass()
         test.ViewPort.edit("@100 ^test.abilities.text @00 ")

         test.ViewPort.goto!!.execute("ability.tex")

         Assert.empty(test.Errors)
         Assert.equal(0x100, test.ViewPort.dataOffset)
      }

      private fun StandardSetup(data: Ref<ByteArray>, model: Ref<PokemonModel>, viewPort: Ref<ViewPort>) {
         data.value  = Enumerable.Repeat(0xFF.u8(), 0x200).toByteArr()
         model.value  = PokemonModel(data.value)
         viewPort.value  = ViewPort("file.txt", model.value, InstantDispatch.instance, BaseViewModelTestClass.Singletons).also { it.allowMultipleElementsPerLine = true; it.width = 0x10; it.height = 0x10 }
      }
   }
