@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST")

package dev.hexmaniac.tests

import dev.hexmaniac.core.system.*

class EventWatcher(handlerAction: ((Any?, EventArgs) -> Unit) -> Unit) {
    var count: Int = 0
        private set
    init {
        handlerAction({ _, _ -> count += 1 })
    }
}

class CommandWatcher(command: ICommand, parameter: Any? = null) {
    var lastCanExecute: Boolean = command.canExecute(parameter)
        private set
    init {
        command.canExecuteChanged += { _, _ -> lastCanExecute = command.canExecute(parameter) }
    }
}
