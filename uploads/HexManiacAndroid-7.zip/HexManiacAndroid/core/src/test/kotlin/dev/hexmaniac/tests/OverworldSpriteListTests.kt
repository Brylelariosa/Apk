@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class OverworldSpriteListTests : BaseViewModelTestClass() {
      val SpriteStart: Int = 0x00
      val Pal1Start: Int = 0x20
      val Pal2Start: Int = 0x40
      val PalTable: Int = 0x60
      val SpriteList: Int = 0x80
      val Parent: Int = 0xA0

      init {
         ViewPort.edit("@${(PalTable).toHex(2)} <020> 00 00 <040> 01 00 @${(PalTable).toHex(2)} ^${HardcodeTablesModel.overworldPalettes}[pal<`ucp4`> id:|h]2 ")
         ViewPort.edit("@${(SpriteList).toHex(2)} <000> 20 ")
         ViewPort.edit("@${(Parent).toHex(2)} FF FF 00 00 40 00 08 00 08 00 <080>")
         ViewPort.edit("@${(Parent).toHex(2)} ^parent[starterbytes:|h paletteid:|h length: width: height: sprites<`osl`>]1 ")
      }
      @Test fun Setup_MatchesExpected() {
         Assert.isAssignableFrom<ISpriteRun>(Model.getNextRun(0x00))
         Assert.isAssignableFrom<IPaletteRun>(Model.getNextRun(0x20))
         Assert.isAssignableFrom<IPaletteRun>(Model.getNextRun(0x40))
         Assert.isAssignableFrom<ITableRun>(Model.getNextRun(0x60))
         Assert.isAssignableFrom<OverworldSpriteListRun>(Model.getNextRun(0x80))
         Assert.isAssignableFrom<ITableRun>(Model.getNextRun(0xA0))
      }
      @Test fun OverworldSpriteList_UpdatePaletteIDInline_UpdateSpriteFormatWithNewPaletteID() {
         ViewPort.edit("@${(Parent + 2).toHex(2)} 0001 ")

         var run = (Model.getNextRun(SpriteStart) as ISpriteRun)
         Assert.equal(0x0001, Model.readMultiByteValue(0xA2, 2))
         Assert.equal("${HardcodeTablesModel.overworldPalettes}:id=0001", run.spriteFormat.paletteHint)
      }
      @Test fun OverworldSpriteList_UpdatePaletteIDFromTable_UpdateSpriteFormatWithNewPaletteID() {
         ViewPort.goto!!.execute(Parent)

         var paletteID = ViewPort.tools!!.tableTool!!.children
            .filter({ child -> child is FieldArrayElementViewModel })
            .filterIsInstance<FieldArrayElementViewModel>()
            .single({ vm -> vm.name == "paletteid" })
         paletteID.content  = "0001"

         var run = (Model.getNextRun(SpriteStart) as ISpriteRun)
         Assert.equal(0x0001, Model.readMultiByteValue(0xA2, 2))
         Assert.equal("${HardcodeTablesModel.overworldPalettes}:id=0001", run.spriteFormat.paletteHint)
      }
      @Test fun OverworldSpriteList_UpdatePaletteIDInline_SpriteToolPaletteUpdates() {
         ViewPort.goto!!.execute(SpriteList)
         ViewPort.edit("@${(Parent + 2).toHex(2)} 0001 ")
         ViewPort.goto!!.execute(SpriteList)

         Assert.equal("${HardcodeTablesModel.overworldPalettes}:id=0001", ViewPort.tools!!.spriteTool!!.spritePaletteHint)
         Assert.equal(Pal2Start, ViewPort.tools!!.spriteTool!!.paletteAddress)
      }
   }
