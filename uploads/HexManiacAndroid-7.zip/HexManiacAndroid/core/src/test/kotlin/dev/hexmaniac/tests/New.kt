@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.viewmodels.*

/** Exists as an indirection layer for constructors called by all tests (see New.cs). */
open class New(private val fs: IFileSystem, private val singletons: Singletons) {
    fun editorViewModel(): EditorViewModel = EditorViewModel(fs, singletons.workDispatcher, false).also { it.allowMultipleElementsPerLine = true }
    fun pokemonModel(data: ByteArray, metadata: StoredMetadata? = null): IDataModel = PokemonModel(data, metadata, singletons)
    fun hardcodeTablesModel(rawData: ByteArray, metadata: StoredMetadata? = null): IDataModel = HardcodeTablesModel(singletons, rawData, metadata)
    fun pcsConverter(gameCode: String): PCSConverter = PCSConverter(gameCode, null)
    fun storedList(name: String, contents: List<String>, hash: String? = null): StoredList = Companion.storedList(name, contents, hash)
    fun validationList(hash: String?, content: List<String>): ValidationList = Companion.validationList(hash, content)
    val earliestVersionInfo: IMetadataInfo get() = Companion.earliestVersionInfo

    companion object {
        fun storedList(name: String, contents: List<String>, hash: String? = null): StoredList = StoredList(name, contents, LinkedHashMap(), hash)
        fun validationList(hash: String?, content: List<String>): ValidationList = ValidationList(hash ?: "", content, LinkedHashMap())
        val earliestVersionInfo: IMetadataInfo get() = StubMetadataInfo().also { it.versionNumber = "0.0.1" }
    }
}
