@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ConstantTests : BaseViewModelTestClass() {
      @Test fun ConstantFormat_TypeConstantFormat_AcceptInput() {
         ViewPort.edit(".some.number ")

         ViewPort.edit(".some.number")

         var edit = ((ViewPort[0, 0].format) as UnderEdit)
         Assert.equal(".some.number", edit.currentText)
      }
      @Test fun ConstantFormat_TypeSameFormatOver_Unchanged() {
         ViewPort.edit(".some.number-1 ")

         ViewPort.edit(".some.number-1 ")

         var format = ((ViewPort[0, 0].format) as Integer)
         Assert.equal(0, format.value)
      }
      @Test fun ConstantFormat_EnterNewConstantOnByteWithDifferentValue_CurrentValueCHangesToMatchConstant() {
         ViewPort.edit("@100 03 @100 .some.number+1 ")

         ViewPort.edit("@000 .some.number ")

         Assert.equal(2, Model[0])
      }
      @Test fun NameTableWithInnerPointers_LowerConstant_ShorterTableKeepsInnerPointers() {
         SetFullModel(0xFF)
         CreateTextTableWithInnerPointers("names", 0x100, "adam", "bob", "carl", "dave", "eric", "fred", "0123456789ABDCE")
         ViewPort.edit("@000 <100> <110> <120> <130> <140> <150> <160> ")
         ViewPort.edit("@080 07 @080 .some.number @100 ^names^[name\"\"16]some.number ")

         Assert.empty(Errors)

         ViewPort.edit("@080 6 ")

         var array = (Model.getNextRun(0x100) as ArrayRun)
         Assert.all(array.pointerSourcesForInnerElements!!, { span -> Assert.single(span) })
         Assert.isType<NoInfoRun>(Model.getNextRun(0x100 + 0x60))
      }
   }
