@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ViewPortAutocompleteEditTests {
      private var errors: MutableList<String> = ArrayList<String>()
      private lateinit var viewPort: ViewPort

      init {
         var model = PokemonModel(ByteArray(0x200))
         viewPort  = AutoSearchTests.newViewPort("name.txt", model)
         viewPort.height  = 0x10
         viewPort.width  = 0x10
         viewPort.onError  += { sender, e -> errors.add(e) }

         viewPort.selectionStart  = Point(0, 8)
         viewPort.edit("^label ")

         viewPort.selectionStart  = Point(4, 8)
         viewPort.edit("^labwork ")

         viewPort.selectionStart  = Point(8, 8)
         viewPort.edit("^othertext ")

         viewPort.selectionStart  = Point(12, 8)
         viewPort.edit("^sometext[name\"\"6]6 \"crazy\" \"crozy\" \"short\" \"shoot\" ")
         viewPort.goto!!.execute("0"); // after making a table, reset the view

         viewPort.selectionStart  = Point(0, 12)
         viewPort.edit("^table[num:sometext]6 ")
         viewPort.goto!!.execute("0"); // after making a table, reset the view

         viewPort.selectionStart  = Point()
      }
      @Test fun UnderEditLoosePointerGetsAutoComplete() {
         viewPort.edit("<labe")

         var format = ((viewPort[0, 0].format) as UnderEdit)
         Assert.single(format.autocompleteOptions)

         format  = ((viewPort[1, 0].format) as UnderEdit)
         Assert.isNull(format.autocompleteOptions)
      }
      @Test fun BackspaceWidensAutocompleteResults() {
         viewPort.edit("<labe")
         viewPort.edit(ConsoleKey.Backspace)

         var format = ((viewPort[0, 0].format) as UnderEdit)
         Assert.equal(2, format.autocompleteOptions!!.size)
      }
      @Test fun UpDownDuringAutoCompleteSelectsResults() {
         viewPort.edit("<lab")
         viewPort.moveSelectionStart.execute(Direction.Down)

         var format = ((viewPort[0, 0].format) as UnderEdit)
         Assert.isTrue(format.autocompleteOptions!![0].isSelected)
      }
      @Test fun EmptyAutoCompleteArrowsActNormally() {
         viewPort.edit("<xyz")
         viewPort.moveSelectionStart.execute(Direction.Down)

         Assert.isNotType<UnderEdit>(viewPort[0, 0].format)
      }
      @Test fun SelectAutoCompleteOptionAndHitEnterUsesThatResult() {
         viewPort.edit("<lab")
         viewPort.moveSelectionStart.execute(Direction.Down)
         viewPort.edit(ConsoleKey.Enter)

         var format = ((viewPort[0, 0].format) as Pointer)
         Assert.equal("label", format.destinationName)
      }
      @Test fun AutocompleteWorksForEnums() {
         viewPort.selectionStart  = Point(2, 12)
         viewPort.edit("sho")

         var format = ((viewPort[2, 12].format) as UnderEdit)
         Assert.equal(2, format.autocompleteOptions!!.size)
      }
      @Test fun AutocompleteWorksForInlineGoto() {
         viewPort.edit("@lab")

         var format = ((viewPort[0, 0].format) as UnderEdit)
         Assert.equal(2, format.autocompleteOptions!!.size)
      }
      @Test fun NoErrorWhenClickingOffOfAnEmptyPointerEdit() {
         viewPort.edit("<")
         viewPort.selectionStart  = Point(4, 4)

         Assert.empty(errors);                                   // no errors
         Assert.notEqual(0, viewPort.model.getNextRun(0)!!.start) // no run was added
      }
      fun StringMatchingTests(full: String, partial: String) {
         Assert.isTrue(full.matchesPartial(partial, true))
      }
    @Test fun StringMatchingTests_1() { StringMatchingTests("SAND-ATTACK", "sand attack") }
      @Test fun NameList_TypeNameWithSingleQuote_AutocompleteCorrect() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable("names", 0x100, "Basic", "Quote'n'space Element")
         test.CreateEnumTable("enums", 0, "names", 0, 0)
         test.ViewPort.goto!!.execute(0)

         test.ViewPort.edit("\"Quote'\"")

         Assert.equal(1, test.Model[0])
      }
      @Test fun NameListWithTwoOfSameElementWithSpace_EnterSecondOption_CompleteCorrect() {
         var test = BaseViewModelTestClass()
         test.CreateTextTable("names", 0x100, "default", "Some Element", "Some Element")
         test.CreateEnumTable("enums", 0, "names", 0, 0)
         test.ViewPort.goto!!.execute(0)

         test.ViewPort.edit("\"Some Element~2\"")

         Assert.equal(2, test.Model[0])
      }
      @Test fun UnderscoresInListElements_TypeUnderscore_StillUnderEdit() {
         viewPort.model.setList("list", listOf( "option_abc", "option_xyz"))
         viewPort.edit("^table[a.list]1 ")

         viewPort.edit("option_")

         var cell = ((viewPort[0, 0].format) as UnderEdit)
         var options = cell.autocompleteOptions!!.map({ option -> option.completionText.trim() })
         Assert.equal(arrayOf( "option_abc", "option_xyz"), options)
      }
      @Test fun LongWordBeforeShortWord_ShortWordIsBetterMatch_MatchShortWord() {
         var options = arrayOf( "TRI-ATTACK", "TRICK")
         var best = ArrayRunEnumSegment.getBestOptions(options.toList(), "trick").first()
         Assert.equal("TRICK", best)
      }
   }
