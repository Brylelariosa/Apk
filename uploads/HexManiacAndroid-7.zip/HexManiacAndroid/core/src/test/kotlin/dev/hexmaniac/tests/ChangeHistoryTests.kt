@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class FakeChangeToken : java.util.ArrayList<Int>, IChangeToken {
      constructor() : super()
      constructor(source: Collection<Int>) : super(source)
      override val onNewChange = Event<EventArgs>()
      override val hasDataChange: Boolean get() = size > 0
      override val hasAnyChange: Boolean get() = true

      override fun add(element: Int): Boolean {
         val result = super.add(element)
         onNewChange.invoke(this, EventArgs.empty)
         return result
      }
   }

   open class ChangeHistoryTests : BaseViewModelTestClass() {

      private lateinit var history: ChangeHistory<FakeChangeToken>
      private var callCount: Int = 0
      private lateinit var recentChanges: MutableList<Int>

      init {
         history  = ChangeHistory<FakeChangeToken>(createToken = { FakeChangeToken() }, revertChange = lm1@{ changes ->
            callCount++
            recentChanges  = changes
            return@lm1 FakeChangeToken(changes.map({ i -> -i }))
         })
      }
      @Test fun CannotUndoByDefault() {
         Assert.isFalse(history.undo.canExecute(null))
      }
      @Test fun CallingUndoWhenStackIsEmptyDoesNothing() {
         history.undo.execute()
         history.redo.execute()
         Assert.equal(0, callCount)
      }
      @Test fun CanUndoAfterCheckingCurrentTransaction() {
         history.currentChange.count()
         Assert.isTrue(history.undo.canExecute(null))
         Assert.isFalse(history.redo.canExecute(null))
      }
      @Test fun UndoCallsRevertDelegate() {
         history.currentChange.count()
         history.undo.execute()
         Assert.equal(1, callCount)
         Assert.isFalse(history.undo.canExecute(null))
         Assert.isTrue(history.redo.canExecute(null))
      }
      @Test fun UndoPassesInRecentChanges() {
         history.currentChange.add(3)
         history.undo.execute()

         Assert.notNull(recentChanges)
         Assert.single(recentChanges)
         Assert.equal(3, recentChanges[0])
      }
      @Test fun RedoPassesInRecentChanges() {
         history.currentChange.add(3)
         history.undo.execute()
         history.redo.execute()

         Assert.notNull(recentChanges)
         Assert.single(recentChanges)
         Assert.equal(-3, recentChanges[0])
      }
      @Test fun CannotRedoAfterNewChange() {
         history.currentChange.add(3)
         history.undo.execute()
         history.currentChange.add(4)

         Assert.isTrue(history.undo.canExecute(null))
         Assert.isFalse(history.redo.canExecute(null))
      }
      @Test fun ClosingEmptyChangeDoesNotAddUndoItem() {
         history.changeCompleted()

         Assert.isFalse(history.undo.canExecute(null))
      }
      @Test fun ClosingChangesAllowsForMultipleUndos() {
         history.currentChange.add(3)
         history.changeCompleted()
         history.currentChange.add(4)

         history.undo.execute()
         Assert.equal(4, recentChanges[0])

         history.undo.execute()
         Assert.equal(3, recentChanges[0])
      }
      @Test fun UndoCanExecuteChangeFiresCorrectly() {
         var canExecuteChangeCalled = 0
         history.undo.canExecuteChanged  += { sender, e -> canExecuteChangeCalled++ }

         history.currentChange.add(3)
         Assert.equal(1, canExecuteChangeCalled)

         history.undo.execute()
         Assert.equal(2, canExecuteChangeCalled)
      }
      @Test fun RedoCanExecuteChangeFiresCorrectlyForRedoOperation() {
         var canExecuteChangeCalled = 0
         history.redo.canExecuteChanged  += { sender, e -> canExecuteChangeCalled++ }

         history.currentChange.add(3)
         Assert.equal(0, canExecuteChangeCalled)

         history.undo.execute()
         Assert.equal(1, canExecuteChangeCalled)

         history.redo.execute()
         Assert.equal(2, canExecuteChangeCalled)
      }
      @Test fun RedoCanExecuteChangeFiresCorrectlyForNewChange() {
         var canExecuteChangeCalled = 0
         history.redo.canExecuteChanged  += { sender, e -> canExecuteChangeCalled++ }

         history.currentChange.add(3)
         Assert.equal(0, canExecuteChangeCalled)

         history.undo.execute()
         Assert.equal(1, canExecuteChangeCalled)

         history.currentChange.add(4); // adding another change clears the redo stack
         Assert.equal(2, canExecuteChangeCalled)
      }
      @Test fun ThrowExceptionIfChangeStartsDuringUndo() {
         // setup a revert call that tries to access a change during revert
         lateinit var history: ChangeHistory<FakeChangeToken>
         history  = ChangeHistory<FakeChangeToken>(createToken = { FakeChangeToken() }, revertChange = { token -> history.currentChange })

         history.currentChange.toString(); // create current change
         Assert.throws<InvalidOperationException>({ history.undo.execute() })
      }
      @Test fun ThrowExceptionIfChangeCompletedDuringUndo() {
         lateinit var history: ChangeHistory<FakeChangeToken>
         history  = ChangeHistory<FakeChangeToken>(createToken = { FakeChangeToken() }, revertChange = lm2@{ token ->
            history.currentChange.toString()
            history.changeCompleted()
            return@lm2 FakeChangeToken()
         })

         history.currentChange.toString(); // create current change
         Assert.throws<InvalidOperationException>({ history.undo.execute() })
      }
      @Test fun IsSavedIsRecalledCorrectlyWhenSavingAfterUndo() {
         history.currentChange.add(1); // 1
         history.changeCompleted()
         history.currentChange.add(2); // 1 2
         history.changeCompleted()
         history.currentChange.add(3); // 1 2 3
         history.changeCompleted()

         history.undo.execute();       // 1 2  |  3
         history.undo.execute();       // 1  |  2 3
         history.tagAsSaved()

         history.redo.execute();       // 1 2  |  3
         history.currentChange.add(4); // 1 2 4
         history.changeCompleted()

         history.undo.execute(); // 1 2  |  4
         history.undo.execute(); // 1  | 2 4

         // even though the redo history is different,
         // the current state is the same as when we last saved
         Assert.isTrue(history.isSaved)
      }
      @Test fun CanUndoFormatChange() {
         SetFullModel(0xFF)
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(4, 0)
         viewPort.edit("<000030>")
         Assert.equal(0x04, Model.getNextRun(0).start)

         viewPort.undo.execute()
         Assert.equal(Int.MAX_VALUE, Model.getNextRun(0).start)
      }
      @Test fun CanUndoDataMove() {
         SetFullModel(0xFF)
         var viewPort = ViewPort

         viewPort.selectionStart  = Point(8, 0)
         viewPort.edit("<000030>")

         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("^bob\"\" \"Hello World!\"")

         viewPort.undo.execute(); // should undo the entire last edit transaction

         Assert.equal(0xFF, Model[0])
         Assert.equal(8, Model.getNextRun(0).start)
         Assert.equal(0x30, Model.getNextRun(0x10).start)
         Assert.equal(Int.MAX_VALUE, Model.getNextRun(0x31).start)
      }
      @Test fun CanUndoFromToolChange() {
         SetFullModel(0xFF)
         var viewPort = ViewPort

         viewPort.edit("^bob\"\" ")
         var bobRun = Model.getNextRun(0)
         Assert.equal(1, bobRun.length)

         // move the selection to force a break in the undo history
         viewPort.selectionStart  = Point(3, 3)
         viewPort.selectionStart  = Point(0, 0)

         viewPort.tools!!.stringTool!!.address  = 0
         viewPort.tools!!.stringTool!!.content  = "Hello World!"
         viewPort.undo.execute(); // should undo only the tool change, not the name change

         Assert.equal(0xFF, Model[0])
         Assert.isTrue(viewPort.undo.canExecute(null))
      }
      @Test fun UndoCanHandleNameMove() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         // operation 1
         viewPort.edit("<bob> 03 08 24 16 <bob>")

         // operation 2
         viewPort.selectionStart  = Point(0, 1)
         viewPort.edit("^bob ")

         Assert.equal(0x10, model.readPointer(0x00))
         Assert.equal("bob", (((viewPort[0, 0].format) as Pointer)).destinationName)

         // undo operation 2
         viewPort.undo.execute()
         Assert.equal(Pointer.null_, model.readPointer(0x00))
         Assert.equal("bob", (((viewPort[0, 0].format) as Pointer)).destinationName)

         // operation 3
         viewPort.selectionStart  = Point(0, 2)
         viewPort.edit("^bob ")

         Assert.equal(0x20, model.readPointer(0x00))
         Assert.equal("bob", (((viewPort[0, 0].format) as Pointer)).destinationName)

         // undo operation 3
         viewPort.undo.execute()
         Assert.equal(Pointer.null_, model.readPointer(0x00))
         Assert.equal("bob", (((viewPort[0, 0].format) as Pointer)).destinationName)
      }
      @Test fun UndoWorksAfterMidPointerEdit() {
         SetFullModel(0xFF)
         val (model, viewPort) = Pair(Model, ViewPort)

         viewPort.edit("<000100>")
         viewPort.selectionStart  = Point(1, 0)
         viewPort.edit("<000180>")
         viewPort.undo.execute()

         Assert.equal(0x000100, model.readPointer(0))
      }
      @Test fun UndoRedoRestoresUnmappedNames() {
         SetFullModel(0xFF)
         var viewPort = ViewPort

         viewPort.edit("<bob>")
         viewPort.selectionStart  = Point(0, 0)
         viewPort.edit("<tom>")

         viewPort.undo.execute()
         Assert.equal("bob", (((viewPort[0, 0].format) as Pointer)).destinationName)

         viewPort.redo.execute()
         Assert.equal("tom", (((viewPort[0, 0].format) as Pointer)).destinationName)
      }
      @Test fun CanOverrideChangeCompletion() {
         // arrange: change, then "don't" complete, then change
         history.currentChange.add(1)
         (history.continueCurrentTransaction()).use { _ ->history.changeCompleted() }
         history.currentChange.add(2)

         // act: undo
         history.undo.execute()

         // assert: that was the only thing in the undo stack
         Assert.isFalse(history.undo.canExecute(null))
      }
      @Test fun LargeViewPortEdit_Complete_CountsAsSingleChange() {
         SetFullModel(0xFF)
         ViewPort.edit("@!00(8) ^table[content<\"\">]2 @{ \"Something\" @} @{ \"Else\" @} ")

         ViewPort.undo.execute()

         Assert.isFalse(ViewPort.undo.canExecute(null))
      }
      @Test fun Transaction_InsertCustomChange_Throws() {
         Assert.throws<InvalidOperationException>(lm3@{ 
            (history.continueCurrentTransaction()).use { _ ->
               history.insertCustomChange(FakeChangeToken())
             }
         })
      }
      @Test fun TextBytes_FormatAsText_CanUndo() {
         "FF EB D5 ED AB FF".parseHexBytes().writeInto(Model.rawData, 0)
         Model.writePointer(ModelDelta(), 6, 1); // needs a pointer in order to get recognized by the algorithm
         var watcher = CommandWatcher(ViewPort.undo)

         ViewPort.selectionStart  = Point(1, 0)
         var items = ViewPort.getContextMenuItems(ViewPort.selectionStart)
         items  = (items.single({ item -> item.text == "Display As..." }) as ContextItemGroup)
         items.single({ item -> item.text == "Text" }).command.execute()

         Assert.isTrue(watcher.lastCanExecute)
      }
      @Test fun ChangeTextWithTextTool_Undo_TextToolUpdates() {
         ViewPort.edit("FF @00 ^text\"\" Test\" ")
         ViewPort.goto!!.execute(0)
         ViewPort.tools!!.stringTool!!.content  = "Blah"

         ViewPort.undo.execute()

         Assert.equal("Test", ViewPort.tools!!.stringTool!!.content)
      }
      @Test fun Undo_CustomChange_CannotRedo() {
         history.currentChange.add(1)
         history.undo.execute()

         history.insertCustomChange(FakeChangeToken())

         Assert.isFalse(history.redo.canExecute(null))
      }
      @Test fun TextTable_ChangeAndUndo_HeadersUpdate() {
         ViewPort.useCustomHeaders  = true
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         ViewPort.goto!!.execute(0x102)

         ViewPort.edit(ConsoleKey.Backspace)
         ViewPort.undo.execute()

         Assert.equal("adam", ViewPort.headers!![0])
      }
      @Test fun TextTable_UndoAndRedo_HeadersUpdate() {
         ViewPort.useCustomHeaders  = true
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         ViewPort.goto!!.execute(0x102)

         ViewPort.edit(ConsoleKey.Backspace)
         ViewPort.undo.execute()
         ViewPort.redo.execute()

         Assert.equal("ad", ViewPort.headers!![0])
      }
      @Test fun Rom_Expand_CanUndo() {
         Model.expandData(ViewPort.currentChange, 0x400 - 1)

         Assert.isTrue(ViewPort.changeHistory.undo.canExecute(null))
      }
      @Test fun ExpandRom_Undo_RomShrinks() {
         Model.expandData(ViewPort.currentChange, 0x400 - 1)

         ViewPort.undo.execute()

         Assert.equal(0x200, Model.count)
      }
      @Test fun UndoExpandedRom_Redo_ExpandRom() {
         Model.expandData(ViewPort.currentChange, 0x400 - 1)
         ViewPort.undo.execute()

         ViewPort.redo.execute()

         Assert.equal(0x400, Model.count)
      }
      @Test fun MassUpdateFromDelta_DataOutOfRange_NoFail() {
         var token = ModelDelta()
         Model.expandData(token, 0x400)
         token.changeData(Model, 0x300, 1)

         var reverse = token.revert(Model)
         var original = reverse.revert(Model)

         // if no error, then we're fine
      }
      @Test fun Anchor_ChangeFormat_CanUndo() {
         val table = Ref<ITableRun?>(null)
         ArrayRun.tryParse(Model, "[something:]2", 0x20, SortedSpan<Int>.none(), table)
         Model.observeAnchorWritten(Token, "anchor", table.value!!)
         var editor = EditorViewModel(FileSystem, Singletons.workDispatcher).also { it.add(ViewPort) }
         var view = StubView(editor)

         ViewPort.goto!!.execute(0x20)
         ViewPort.anchorText  = "^anchor[a. b.]2"

         Assert.isTrue(editor.undo.canExecute(null))
         Assert.contains("undo", view.commandCanExecuteChangedNotifications)
      }
      @Test fun Edit_Close_Saved() {
         FileSystem.trySavePrompt  = { arg -> true }
         ViewPort.edit("11 ")

         ViewPort.close.execute(FileSystem)

         Assert.isTrue(ViewPort.changeHistory.isSaved)
      }
      @Test fun Scope_NestScope_Works() {
         (history.continueCurrentTransaction()).use { _ ->
            history.currentChange.add(0)
            (history.continueCurrentTransaction()).use { _ ->
               history.currentChange.add(1)
               history.changeCompleted()
             }
            history.changeCompleted()
            history.currentChange.add(2)
          }
         history.changeCompleted()

         history.undo.execute()

         Assert.equal(3, recentChanges.size)
      }
      @Test fun DataChange_Name_ContainsAstrisk() {
         var view = StubView(ViewPort)

         ViewPort.edit("03")

         Assert.endsWith("*", ViewPort.name)
         Assert.isTrue(ViewPort.changeHistory.hasDataChange)
         Assert.contains("name", view.propertyNotifications)
         Assert.contains("save", view.commandCanExecuteChangedNotifications)
      }
      @Test fun NonDataChange_Name_NoAstrisk() {
         var view = StubView(ViewPort)

         ViewPort.edit("^test ")

         Assert.isFalse(ViewPort.name.endsWith("*"))
         Assert.isFalse(ViewPort.changeHistory.hasDataChange)
         Assert.contains("save", view.commandCanExecuteChangedNotifications)
      }
      @Test fun SavedDataChange_NonDataChanges_DoesNotReportUnsavedDataChange() {
         history.currentChange.add(1)
         history.tagAsSaved()

         var change = history.currentChange
         history.changeCompleted()
         change  = history.currentChange

         Assert.isFalse(history.hasDataChange)
      }
   }
