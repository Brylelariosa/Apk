@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ToolTipTests : BaseViewModelTestClass() {
      private lateinit var visitor: ToolTipContentVisitor

      init { visitor  = ToolTipContentVisitor(Model) }
      @Test fun Pointer_DisplayText_ContentIncludes() {
         var format = Pointer(0, 0, 0, 0, "SomeLocation", false)

         format.visit(visitor, 0)

         Assert.equal("<SomeLocation>", visitor.content.single())
      }
      @Test fun MatchedWord_ToolTip_DisplaysParentTableName() {
         var format = MatchedWord(0, 0, "table")

         format.visit(visitor, 0)

         Assert.equal("table", visitor.content.single())
      }
      @Test fun IntEnum_HasDisplayValue_ShowInTooltip() {
         var format = IntegerEnum(0, 0, "Craig", 0)

         format.visit(visitor, 0)

         Assert.equal("Craig", visitor.content.single())
      }
      @Test fun Integer_IsNamedConstant_HasTooltip() {
         var format = Integer(0, 0, 150, 0)
         Model.observeRunWritten(ViewPort.currentChange, WordRun(0, "value", 2, -2, 1, "note"))

         format.visit(visitor, 0)

         Assert.equal(
            "\n".join(arrayOf(
               "value-2",
               "note",
               "Changing one copy of a constant will automatically update all other copies.")),
            visitor.content.single())
      }
      @Test fun BitArray_HasValues_ShowInToolTip() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         CreateEnumTable("enums", 0x180, "names", 0, 1, 2, 3)
         CreateBitArrayTable("bits", 0, "enums", 0xF)
         var format = BitArray(0, 0, 1, "")

         format.visit(visitor, Model[0])

         Assert.equal(arrayOf( "adam", "bob", "carl", "dave"), visitor.content)
      }
      @Test fun BitArray_Empty_ShowNoneInToolTip() {
         CreateTextTable("names", 0x100, "adam", "bob", "carl", "dave")
         CreateEnumTable("enums", 0x180, "names", 0, 1, 2, 3)
         CreateBitArrayTable("bits", 0, "enums", 0)
         var format = BitArray(0, 0, 1, "")

         format.visit(visitor, Model[0])

         Assert.equal("- None -", visitor.content.single())
      }
   }
