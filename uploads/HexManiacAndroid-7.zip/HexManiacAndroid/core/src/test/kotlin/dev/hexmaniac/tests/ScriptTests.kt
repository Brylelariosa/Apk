@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class ScriptTests : BaseViewModelTestClass() {
      private lateinit var battle: ScriptParser

      init {
         Model.loadMetadata(BaseModel.getDefaultMetadatas().first()); // load default script-related lists, like script_compare
         battle  = ViewPort.tools!!.codeTool!!.battleScriptParser
         ViewPort.tools!!.codeTool!!.isSelected  = true
      }
      @Test fun DecompiledScriptsContainLabels() {
         Model.clearFormat(newOf(), 0, Model.count)
         val script = Ref(Script("jumpiftype 0 0 <0007>", "end"))
         var code = battle.compile(ViewPort.currentChange, Model, 0, script, Ref(nullOf()))
         arrayCopy(code!!, Model.rawData, code!!.size)
         battle.formatScript<BSERun>(ModelDelta(), Model, 0)

         var lines = battle.parse(Model, 0, code!!.size).splitLines()

         Assert.equal(arrayOf<String>(
            "  jumpiftype target 0 <section0>",
            "",
            "section0: # 000007",
            "  end",
            "",), lines)
      }
      @Test fun BattleScriptsInnerPointersDecompileToRelativeOffsets() {
         val script = Ref(Script("jumpiftype 00 00 <000007>", "000007:", "end"))

         var code = battle.compile(ViewPort.currentChange, Model, 0x10, script, Ref(nullOf()))
         arrayCopy(code!!, 0, Model.rawData, 0x10, code!!.size)
         battle.formatScript<BSERun>(ModelDelta(), Model, 0x10)

         var run = (Model.getNextRun(0x13) as PointerRun)
         Assert.equal(0x13, run.start)
         Assert.equal(0x17, Model.readPointer(0x13))
      }
      @Test fun CanCreateXseScriptFromContextMenu() {
         Model[0x22]  = 0xFF
         ViewPort.refresh()

         ViewPort.selectionStart  = Point(2, 2)
         var group = ((ViewPort.getContextMenuItems(Point(2, 2)).single({ cmi -> cmi.text == "Create New..." })) as ContextItemGroup)
         var item = group.single({ cmi -> cmi.text == "Event Script" })
         item.command.execute()

         Assert.equal(ViewPort.tools!!.codeTool, ViewPort.tools!!.selectedTool)
         Assert.equal(CodeMode.Script, ViewPort.tools!!.codeTool!!.mode)
         Assert.endsWith("end", ViewPort.tools!!.codeTool!!.contents.single().content.trim())
         Assert.isType<XSERun>(Model.getNextRun(0x22))
         var anchorName = Model.getAnchorFromAddress(-1, 0x22)
         Assert.notEmpty(anchorName)
         Assert.equal(anchorName, ViewPort.anchorText.substring(ViewPort.anchorTextSelectionStart, ViewPort.anchorTextSelectionStart + ViewPort.anchorTextSelectionLength))
      }
      @Test fun ScriptLine_MultibyteEnum_Loads() {
         var scriptLine = Singletons.scriptLines.single({ line -> line.lineCode.count == 1 && line.lineCode[0] == 0x44 })
         var args = scriptLine.args

         Assert.equal(HardcodeTablesModel.itemsTableName, args[0].enumTableName)
         Assert.equal(2, args[0].length(null, 0))
      }
      @Test fun TrainerBattle3_Decode_Has3Arguments() {
         Model[0]  = 0x5C
         Model[1]  = 3
         Model[4]  = 1; // so it doesn't use the macro
         Model[10]  = 2
         Model[14]  = 2

         var scriptText = ViewPort.tools!!.codeTool!!.scriptParser.parse(Model, 0, 2)

         var trainerBattleLine = scriptText.splitLines()[0].trim()
         var parts = trainerBattleLine.split(' ')
         Assert.equal(5, parts.size)
      }
      fun Asm_Compile_Thumb(filename: String) {
         var inFile = "test_code/${filename}.asm"
         var outFile = "test_compiled/${filename}.bin"
         var lines = File.readAllLines(inFile)
         var expected = File.readAllBytes(outFile)

         var result = ViewPort.tools!!.codeTool!!.parser.compile(Model, 0, *lines)

         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], result[i]) })
      }
    @Test fun Asm_Compile_Thumb_1() { Asm_Compile_Thumb("Expand01_-_Move_Stats") }
    @Test fun Asm_Compile_Thumb_2() { Asm_Compile_Thumb("Expand02_-_Pokemon_Move_Learn_Table") }
    @Test fun Asm_Compile_Thumb_3() { Asm_Compile_Thumb("Expand03_-_Relearner_move_tutor") }
      fun XSECompileScriptToBytes(script: String, bytes: String) {
         SetFullModel(0xFF)

         var actual = ViewPort.tools!!.codeTool!!.scriptParser.compile(ModelDelta(), Model, 0, Ref(script), Ref(nullOf()))

         var expected = bytes.parseHexBytes()
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], actual!![i]) })
      }
    @Test fun XSECompileScriptToBytes_1() { XSECompileScriptToBytes("trainerbattle 02 0x009B 0000 <2967AD> <2967D8> <1EE5D8>", "5C 02 9B 00 00 00 AD 67 29 08 D8 67 29 08 D8 E5 1E 08") }
    @Test fun XSECompileScriptToBytes_2() { XSECompileScriptToBytes("trainerbattle 00 0x009B 0000 <2967AD> <2967D8>", "5C 00 9B 00 00 00 AD 67 29 08 D8 67 29 08") }
      @Test fun TextWithNamedAnchor_EditScript_KeepsAnchor() {
         SetFullModel(0xFF)
         ViewPort.edit("@10 ^text\"\" \"Hello\" @00 02 @00 ^script`xse` 0F 00 <010> 02 ")
         ViewPort.selectionStart  = ViewPort.convertAddressToViewPoint(0)

         var tool = ViewPort.tools!!.codeTool!!.contents[0]
         var lines = tool.content.splitLines()
         lines[3]  = "Hello!"
         tool.content  = "\n".join(lines.toList())

         Assert.equal(0x10, Model.getAddressFromAnchor(ModelDelta(), -1, "text"))
      }
      @Test fun BranchLinkToKnownName_Decompile_BranchLinkContainsKnownName() {
         Model.observeAnchorWritten(ViewPort.currentChange, "bob", NoInfoRun(0x100))
         var thumb = ViewPort.tools!!.codeTool!!.parser
         arrayCopy(thumb.compile(Model, 0, "bl <bob>").toTypedArray(), Model.rawData, 4)

         var decompile = thumb.parse(Model, 0, 4).split("\n")

         Assert.equal("<bob>", decompile[1].trim().substring(2).trim())
      }
      @Test fun GameCode_GameCommandWithThatCode_EditsAreMade() {
         SetGameCode("XXXX0")

         ViewPort.edit("@!game(xxxx0) 11 ")

         Assert.equal(0x11, Model[0])
      }
      @Test fun GameCode_GameCommandWithDifferentCode_EditsAreNotMade() {
         SetGameCode("XXXX0")

         ViewPort.edit("@!game(yyyy0) 11 ")

         Assert.equal(0x00, Model[0])
      }
      @Test fun GameCode_GameCommandWithThatCodeAndOthers_EditsAreMade() {
         SetGameCode("XXXX0")

         ViewPort.edit("@!game(xxxx0_yyyy0) 11 ")

         Assert.equal(0x11, Model[0])
      }
      @Test fun Insert00_Insert_SelectionTextMatchesSelection() {
         SetFullModel(0xFF)
         var lazyGuard = ViewPort.selectedBytes

         var view = StubView(ViewPort)
         ViewPort.edit("@!00(8) ")

         Assert.equal(Point(0, 0), ViewPort.selectionStart)
         Assert.equal(Point(3, 0), ViewPort.selectionEnd)
         Assert.equal("Selected Bytes: 00 00 00 00", ViewPort.selectedBytes!!.trim())
         Assert.contains("selectedBytes", view.propertyNotifications)
      }
      @Test fun EventScriptWithText_ClearText_ScriptIsUnchanged() {
         ViewPort.edit("@100!put(FF) ^text\"\" Hello")
         val script = Ref("\nloadpointer 00 <100>\n{\n\n}\nend\n")
         var code = ViewPort.tools!!.codeTool!!.scriptParser.compile(ViewPort.currentChange, Model, 0, script, Ref(nullOf()))

         Assert.equal(7, code!!.size)
         Assert.equal("\"\"", PCSString.convert(Model, 0x100, 0x100))
      }
      @Test fun LoadPointerCommand_StartsWithWhitespace_StillGetHelp() {
         Assert.notEmpty(ViewPort.tools!!.codeTool!!.scriptParser.getHelp(Model, HelpContext("  loadpointer ", 14)))
      }
      @Test fun StaticVariable_UseInThumb_ValueIsChanged() {
         ViewPort.edit("@somevariable=0x12345678 ")
         var codeText = ".word somevariable"
         var codeBytes = ViewPort.tools!!.codeTool!!.parser.compile(Model, 0, codeText)
         Assert.equal(0x12345678, codeBytes.readMultiByteValue(0, 4))
      }
      @Test fun AnimationScript_Write_Written() {
         SetFullModel(0xFF)
         ViewPort.refresh()
         var tool = ViewPort.tools!!.codeTool
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.selectionStart  = Point(0, 0)
         tool!!.mode  = CodeMode.AnimationScript

         var script = "\nScript:\n   delay 0x10\n   end"
         tool!!.contents[0].content  = script

         // 04 delay time.
         // 08 end
         var result = Model.take(3).toTypedArray()
         Assert.equal(bytes( 0x04, 0x10, 0x08), result)
      }
      @Test fun AnimationScript_CreateVisualTask_ArgumentsReadCorrectly() {
         SetFullModel(0xFF)
         ViewPort.refresh()
         var tool = ViewPort.tools!!.codeTool
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.selectionStart  = Point(0, 0)
         tool!!.mode  = CodeMode.AnimationScript

         var script = "\nScript:\n   createvisualtask <0BA7F9> 0x0A 0001 0000 0006 0000 0000\n   end\n"
         tool!!.contents[0].content  = script

         // 03 createvisualtask address<> priority. [argv:]
         // 08 end
         var result = Model.take(1 + 4 + 1 + (1 + 5 * 2) + 1).toTypedArray()
         //                          op    pointer               prir arg  0             1          2           3           4          end
         Assert.equal(bytes( 0x03, 0xF9, 0xA7, 0x0B, 0x08, 0x0A, 5, 0x01, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08), result)
      }
      @Test fun AnimationScript_LinkToBody_EncodeCorrectly() {
         //                     createSprite  <100>       2  (1arg)  0  end
         var compiledScript = bytes( 2, 128, 0, 0, 8, 2, 1, 0, 0, 8)
         arrayCopy(compiledScript, 0, Model.rawData, 0, compiledScript.size)

         var spriteData = bytes(
            /*tileTag*/ 1, 0,
            /*paletteTag*/ 2, 0,
            /*oam*/ 3, 1, 0, 8,
            /*anims*/ 4, 1, 0, 8,
            /*images*/ 5, 1, 0, 8,
            /*affineAnims*/ 6, 1, 0, 8,
            /*callback*/ 7, 1, 0, 8)
         arrayCopy(spriteData, 0, Model.rawData, 0x80, spriteData.size)

         Model.observeRunWritten(ViewPort.currentChange, PointerRun(1))
         var stream = TableStreamRun(
            Model,
            0x80,
            SortedSpan<Int>(1),
            "[tileTag: paletteTag: oam<> anims<> images<> affineAnims<> callback<>]",
            null,
            FixedLengthStreamStrategy(1))
         Model.observeRunWritten(ViewPort.currentChange, stream)

         val script = Ref(ViewPort.tools!!.codeTool!!.animationScriptParser.parse(Model, 0, compiledScript.size))
         Model.resetChanges()

         val movedData = Ref<List<ScriptParserCompileMovedDataTuple>?>(null)
         ViewPort.tools!!.codeTool!!.animationScriptParser.compile(ViewPort.currentChange, Model, 0, script, movedData)
         Assert.contains("{", script.value)
         Assert.equal(0, Model.changeCount)
      }
      @Test fun EventScript_SingleSpaceOnLine_NoIssue() {
         SetFullModel(0xFF)
         ViewPort.refresh()
         var tool = ViewPort.tools!!.codeTool
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.selectionStart  = Point()
         tool!!.mode  = CodeMode.Script

         var script = "Script:\n "
         tool!!.contents[0].content  = script
         tool!!.contents[0].caretPosition  = script.length

         // if it doesn't crash, we're good
      }
      @Test fun EventScriptThatCallsAnotherScript_ExpandInitialScript_OtherScriptPointerSourceUpdated() {
         ViewPort.edit("@000 02 @100 02 @100 ^script`xse` ")
         var script = Script("if1 = <000000>", "end")
         ViewPort.tools!!.codeTool!!.contents[0].content  = script

         script  = Script("lock", "if1 = <000000>", "end")
         ViewPort.tools!!.codeTool!!.contents[0].content  = script

         var run = Model.getNextRun(0)
         Assert.equal(0x100 + 3, run.pointerSources!!.single())
      }
      @Test fun IncompleteArrayArgLine_Compile_NoException() {
         val line = Ref("createvisualtask <0A9F11> 05")

         var parser = ViewPort.tools!!.codeTool!!.animationScriptParser
         var bytes = parser.compile(ViewPort.currentChange, Model, 0, line, Ref(nullOf()))

         var expected = "03 11 9F 0A 08 05 00".parseHexBytes()
         Assert.all(expected.size.range(), { i -> Assert.equal(expected[i], bytes!![i]) })
      }
      @Test fun ScriptWithDataAfter_AddCommandThatRequestsPointerAndCausesRepoint_RepointAndPointerChooseDifferentOffsets() {
         SetFullModel(0xFF)
         Model.freeSpaceBuffer  = 0x10
         ViewPort.edit("^script`xse` 02 @04 01 @00 ")

         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("loadpointer 0 <??????>", "end")

         var scriptAddress = Model.getAddressFromAnchor(ViewPort.currentChange, -1, "script")
         var loadAddress = Model.readPointer(scriptAddress + 2)
         Assert.isType<XSERun>(Model.getNextRun(scriptAddress))
         Assert.notEqual(scriptAddress, loadAddress)
      }
      @Test fun ScriptWithPointer_Repoint_OldPointerFormatGone() {
         SetFullModel(0xFF)
         Model.freeSpaceBuffer  = 0x10
         ViewPort.edit("^script`xse` 0F 00 <text> 02 FF ^text\"\" \"text\" @00 ")

         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("loadpointer 0 <text>", "additem 0 0", "end")

         Assert.notEqual(2, Model.getNextRun(2).start)
         var text = Model.getNextAnchor("text")
         var script = Model.getNextAnchor("script")
         Assert.doesNotContain(2, text.pointerSources)
         Assert.contains(script.start + 2, text.pointerSources)
      }
      @Test fun ScriptWithShop_EditShopItems_DataUpdates() {
         SetFullModel(0xFF)
         CreateTextTable("data.items.stats", 0x100, "adam", "bob", "carl", "dave", "eric", "fred")
         ViewPort.edit("@00 ^script`xse` ")
         Assert.equal(ViewPort.tools!!.selectedTool, ViewPort.tools!!.codeTool)

         ViewPort.tools!!.codeTool!!.contents[0].content  = "pokemart <000080>"
         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("pokemart <000080>", "{", "carl", "}")

         Assert.equal(2, Model.readMultiByteValue(0x80, 2))
      }
      @Test fun MoveEffectTable_CreateNew_NoCrash() {
         ViewPort.edit("^table[content<`bse`>]1 ")

         var streamElement = (ViewPort.tools!!.tableTool!!.children.single({ child -> child is StreamElementViewModel }) as StreamElementViewModel)
         streamElement.createNew.execute()

         // no assert -> test pass
      }
      @Test fun AnimationScriptTable_CreateNew_NoCrash() {
         ViewPort.edit("^table[content<`ase`>]1 ")

         var streamElement = (ViewPort.tools!!.tableTool!!.children.single({ child -> child is StreamElementViewModel }) as StreamElementViewModel)
         streamElement.createNew.execute()

         // no assert -> test pass
      }
      @Test fun EventScriptWithText_ExpandTextSoItMoves_ScriptPointerUpdates() {
         SetFullModel(0xFF)
         ViewPort.edit("^script`xse` 0F 00 <100> 02 @100 ^text\"\" \"short\" 07 @00 ")

         var tool = ViewPort.tools!!.codeTool!!.contents[0]
         var lines = tool.content.splitLines(); // label, loadpointer, curly, text, curly, end
         lines[3]  = "longer"
         tool.content  = Script(*lines)

         var destination = Model.readPointer(2)
         Assert.equal(destination, Model.getNextRun(destination).start)
         Assert.equal("\"longer\"", PCSString.convert(Model, destination, 10))
         Assert.equal("text", Model.getAnchorFromAddress(-1, destination))
      }
      @Test fun ScriptWithNoInfoAnchor_ExtendScript_NoRepoint() {
         ViewPort.edit("<100> @100 ^script 6A 02 @100 ")
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script

         var tool = ViewPort.tools!!.codeTool!!.contents[0]
         var lines = tool.content.splitLines().toMutableList()
         lines.add(0, "faceplayer")
         tool.content  = Script(*lines.toTypedArray())

         Assert.equal(0x100, Model.getNextAnchor("script").start)
         Assert.equal(0x5A, Model[0x100])
      }
      @Test fun EditScript_ErrorInScript_ShowError() {
         SetFullModel(0xFF)
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script
         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("lock", "end", "lock")

         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("lock", "lock", "end")

         Assert.isTrue(ViewPort.tools!!.codeTool!!.showErrorText)
      }
      @Test fun ErrorInScript_ClickOff_ResetScriptEditor() {
         SetFullModel(0xFF)
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script
         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("lock", "end", "lock")
         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.selectionStart  = Point(0, 0)
         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("lock", "lock", "end")

         ViewPort.selectionStart  = Point(0, 1)
         ViewPort.selectionStart  = Point(0, 0)

         var script = ViewPort.tools!!.codeTool!!.contents[0].content.splitLines()
            .map({ line -> line.trim() }).filter({ line -> line.length > 0 }).toTypedArray()
         Assert.equal(arrayOf( "lock", "end"), script)
         Assert.isFalse(ViewPort.tools!!.codeTool!!.showErrorText)
      }
      @Test fun StartScriptOnOddHalfWord_LoadRegister_ConstantIsByteAligned() {
         SetFullModel(0xFF)

         ViewPort.tools!!.codeTool!!.parser.compile(Token, Model, 2,
            "ldr   r0,  =0x12345678",
            "add   r0, #1",
            "bx    r0")

         Assert.equal(0x12345678, Model.readMultiByteValue(8, 4))
      }
      @Test fun Anchor_WriteThumb_KeepAnchor() {
         SetFullModel(0xFF)
         ViewPort.edit("@04 ^anchor ")

         ViewPort.tools!!.codeTool!!.content  = "nop"

         Assert.equal(0, Model.readMultiByteValue(4, 2))
         Assert.equal("anchor", Model.getAnchorFromAddress(-1, 4))
      }
      @Test fun FireRedScriptWithChange_Parse_NoThrow() {
         var data = "5A 16 01 40 85 00 79 85 00 19 3D 01 FF FF FF FF FF FF FF FF FF 21 0D 80 00 00 02"
            .split(' ').map({ t -> t.toInt(16) }).toIntArray()
         arrayCopy(data.toList().toByteArr(), Model.rawData, data.size)
         var parser = ViewPort.tools!!.codeTool!!.scriptParser

         var length = parser.findLength(Model, 0)
         var text = parser.parse(Model, 0, length)

         // no throw -> pass
      }
      @Test fun AnimationScript_ContainsArgList_WriteDataCorrectly() {
         // 03 createvisualtask address<> priority. [argv:]
         SetFullModel(0xFF)
         val script = Ref(Script("createvisualtask <123456> 5 0x0 0x0", "end"))

         var result = ViewPort.tools!!.codeTool!!.animationScriptParser.compile(Token, Model, 0, script, Ref(nullOf()))

         var expected: ByteArray = arrayOf<ByteArray>(
            bytes( 3),                      // createvisualtask
            bytes( 0x56, 0x34, 0x12, 0x08), // address
            bytes( 5),                      // priority
            bytes( 2),                      // (number of variable args)
            bytes( 0, 0, 0,0),              // variable args (each arg is 2 bytes)
            bytes( 8),).flatMap({ b -> b.asList() }).toByteArray()
         Assert.equal(expected, result)
      }
      @Test fun TrainerBattle_WrongNumberOfArguments_ErrorMessageIncludesTrainerBattleTypeInErrorMessage() {
         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script

         ViewPort.tools!!.codeTool!!.contents[0].content  = "trainerbattle 00"

         var message = "0: Command trainerbattle 00 expects 4 arguments, but received 0 instead."
         Assert.equal(message, ViewPort.tools!!.codeTool!!.contents[0].errorText!!.trim())
      }
      @Test fun Many00AndEnd_DecompileAnimation_GetManyLoadSpriteGfx() {
         Model[18]  = 8

         var length = ViewPort.tools!!.codeTool!!.animationScriptParser.findLength(Model, 0)
         var content = ViewPort.tools!!.codeTool!!.animationScriptParser.parse(Model, 0, length).splitLines()

         Assert.equal(8, content.size)
      }
      @Test fun CreateSpritePointingToNamedAnchor_ChangePointer_NamedAnchorRemains() {
         SetFullModel(0xFF)
         ViewPort.tools!!.codeToolCommand.execute()
         ViewPort.tools!!.codeTool!!.mode  = CodeMode.AnimationScript
         ViewPort.tools!!.codeTool!!.contents[0].content  = "createsprite <100> 0"
         ViewPort.edit("@100 ^somename @000 ")
         ViewPort.tools!!.codeToolCommand.execute()

         var lines = ViewPort.tools!!.codeTool!!.contents[0].content.splitLines()
         lines[0]  = "createsprite <180> 0"
         ViewPort.tools!!.codeTool!!.contents[0].content  = "\n".join(lines.toList())

         lines[0]  = "createsprite <100> 0"
         ViewPort.tools!!.codeTool!!.contents[0].content  = "\n".join(lines.toList())

         Assert.equal("somename", Model.getAnchorFromAddress(-1, 0x100))
      }
      @Test fun ScriptWithPokemonArgument_GiveVariableAsArgument_WriteVariableToRom() {
         SetFullModel(0xFF)

         val script = Ref(Script("showpokepic 0x8004 0 0", "end"))
         var code = ViewPort.tools!!.codeTool!!.scriptParser.compile(Token, Model, 0, script, Ref(nullOf()))

         Assert.equal(0x8004, code!!.asByteList().readMultiByteValue(1, 2))
      }
      @Test fun ScriptCommandWithFillerArgs_Parse_FillerArgsNotShown() {
         Model[0]  = 0x79;  // givePokemon
         Model[15]  = 0x02; // end

         var script = ViewPort.tools!!.codeTool!!.scriptParser.parse(Model, 0, 16).splitLines()

         Assert.equal("givePokemon 0 0 0", script[0].trim())
      }
      @Test fun TablePointsToScript_EditThenUndo_NoNewAnchors() {
         Model.clearFormat(newOf(), 0, Model.count)
         ViewPort.edit("<020> @00 ^table[pointer<`xse`>]1 ")

         ViewPort.edit("<030> ")
         ViewPort.undo.execute()

         var run = Model.getNextRun(0x30)
         Assert.equal(Int.MAX_VALUE, run.start)
      }
      @Test fun ScriptWithPointerSlightlyAfterScript_NoopEdit_NoDataChange() {
         SetFullModel(0xFF)
         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script
         ViewPort.tools!!.codeTool!!.contents[0].content  = Script("msgbox.npc <00000A>", "{", "text", "}", "end")
         ViewPort.changeHistory.tagAsSaved()

         ViewPort.selectionStart  = newOf(0, 1)
         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.tools!!.codeTool!!.contents[0].content  += " "

         var text = Model.textConverter.convert(Model, 0xA, 5); // should not move, there's 1 unused byte between
         Assert.equal("\"text\"", text)
         Assert.isTrue(ViewPort.changeHistory.isSaved)
      }
      @Test fun ScriptPointingToPrecedingFreespaceForMart_EditScript_IntroduceEmptyMartData() {
         SetFullModel(0xFF)
         ViewPort.edit("@010 86 <000000> 02 @010 ")

         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script
         ViewPort.tools!!.codeTool!!.contents[0].content  += " "

         Model.resolveConflicts()
         var table = (Model.getNextRun(0) as ITableRun)
         Assert.equal(0, table.start)
         Assert.equal("86 00 00 00 08 02".parseHexBytes(), Model.drop(0x10).take(6).toTypedArray())
      }
      @Test fun NullPointer_Decompile_Null() {
         ViewPort.edit("67 00 00 00 00 66 6D 03 ")

         ViewPort.tools!!.codeTool!!.mode  = CodeMode.Script
         ViewPort.goto!!.execute(0)
         var content = ViewPort.tools!!.codeTool!!.contents[0].content.splitLines()

         Assert.equal("preparemsg <null>", content[0].trim())
      }

      private fun Script(vararg lines: String): String = lines.asList().combineLines()
   }
