@file:Suppress("UNUSED_PARAMETER", "unused", "UNCHECKED_CAST", "FunctionName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.system.*

/** Small helpers that make machine-converted C# test code compile. */

fun Int.u8(): Int = this and 0xFF
fun Long.u8(): Int = (this and 0xFF).toInt()
fun Byte.u8(): Int = this.toInt() and 0xFF
fun Short.u8(): Int = this.toInt() and 0xFF
fun Char.u8(): Int = this.code and 0xFF
fun Double.u8(): Int = this.toInt() and 0xFF
fun Int.toByteU(): Byte = this.toByte()

fun arrayCopy(src: ByteArray, si: Int, dst: ByteArray, di: Int, len: Int) { System.arraycopy(src, si, dst, di, len) }
fun arrayCopy(src: ByteArray, dst: ByteArray, len: Int) { System.arraycopy(src, 0, dst, 0, len) }
fun arrayCopy(src: IntArray, si: Int, dst: IntArray, di: Int, len: Int) { System.arraycopy(src, si, dst, di, len) }
fun arrayCopy(src: ShortArray, si: Int, dst: ShortArray, di: Int, len: Int) { System.arraycopy(src, si, dst, di, len) }
fun <T> arrayCopy(src: Array<T>, si: Int, dst: Array<T>, di: Int, len: Int) { System.arraycopy(src, si, dst, di, len) }
fun arrayCopy(src: ByteArray, si: Int, dst: MutableList<Int>, di: Int, len: Int) { for (i in 0 until len) dst[di + i] = src[si + i].toInt() and 0xFF }
fun arrayCopy(src: Array<Int>, si: Int, dst: ByteArray, di: Int, len: Int) { for (i in 0 until len) dst[di + i] = src[si + i].toByte() }
fun arrayCopy(src: List<Int>, si: Int, dst: ByteArray, di: Int, len: Int) { for (i in 0 until len) dst[di + i] = src[si + i].toByte() }
fun arrayClear(a: ByteArray, start: Int, len: Int) { java.util.Arrays.fill(a, start, start + len, 0.toByte()) }
fun arrayClear(a: IntArray, start: Int, len: Int) { java.util.Arrays.fill(a, start, start + len, 0) }
fun arrayFill(a: ByteArray, v: Int) { java.util.Arrays.fill(a, v.toByte()) }
inline fun <reified T> arrayEmpty(): Array<T> = emptyArray<T>()

object Enumerable {
    fun Range(start: Int, count: Int): List<Int> = (start until start + count).toList()
    fun <T> Repeat(item: T, count: Int): List<T> = List(count) { item }
    fun <T> Empty(): List<T> = emptyList()
}

inline fun <reified T> Iterable<T>.toTypedArray(): Array<T> { val l = this.toList(); return Array<T>(l.size) { l[it] } }
fun Iterable<Int>.toByteArr(): ByteArray { val l = this.toList(); return ByteArray(l.size) { l[it].toByte() } }
fun Iterable<Int>.asByteList(): ByteList = ByteArrayList(this.toByteArr())

fun <T : IDisposable, R> T.use(block: (T) -> R): R {
    try { return block(this) } finally { this.dispose() }
}

fun isNullOrEmpty_(s: String?): Boolean = s == null || s.isEmpty()
fun joinStrings(sep: String, items: Iterable<Any?>): String = items.joinToString(sep) { it.toString() }
fun joinStrings(sep: String, vararg items: Any?): String = items.joinToString(sep) { it.toString() }
fun formatString(fmt: String, vararg args: Any?): String {
    var r = fmt
    for ((i, a) in args.withIndex()) r = r.replace("{$i}", a.toString())
    return r
}

/** C# target-typed `new(...)`: the type comes from the expected type of the expression. */
inline fun <reified T> newOf(vararg args: Any?): T = newOfClass(T::class.java, args) as T

fun newOfClass(cls: Class<*>, args: Array<out Any?>): Any? {
    if (args.isEmpty()) {
        when {
            cls == java.util.List::class.java || cls == java.util.Collection::class.java || cls == Iterable::class.java -> return ArrayList<Any?>()
            cls == java.util.Map::class.java -> return LinkedHashMap<Any?, Any?>()
            cls == java.util.Set::class.java -> return LinkedHashSet<Any?>()
        }
    }
    fun box(c: Class<*>): Class<*> = when (c) {
        java.lang.Integer.TYPE -> Integer::class.java; java.lang.Long.TYPE -> java.lang.Long::class.java
        java.lang.Short.TYPE -> java.lang.Short::class.java; java.lang.Byte.TYPE -> java.lang.Byte::class.java
        java.lang.Boolean.TYPE -> java.lang.Boolean::class.java; java.lang.Double.TYPE -> java.lang.Double::class.java
        java.lang.Float.TYPE -> java.lang.Float::class.java; java.lang.Character.TYPE -> Character::class.java
        else -> c
    }
    for (ctor in cls.constructors) {
        if (ctor.parameterCount != args.size) continue
        val ok = ctor.parameterTypes.indices.all { i -> args[i] == null || box(ctor.parameterTypes[i]).isInstance(args[i]) }
        if (ok) return ctor.newInstance(*args)
    }
    throw IllegalArgumentException("no constructor on ${cls.name} for ${args.map { it?.javaClass?.simpleName }}")
}

fun Array<Int>.toByteArr(): ByteArray = ByteArray(this.size) { this[it].toByte() }
fun ByteArray.toIntList(): List<Int> = this.map { it.toInt() and 0xFF }
@Suppress("UNCHECKED_CAST")
fun <T> nullOf(): T = null as T

/** The C# stubs expose their auto-properties as PropertyImplementation<T> with a `.value`; tests read it directly. */
val <T> T.value: T get() = this

fun string(c: Char, count: Int): String = c.toString().repeat(count)
fun dev.hexmaniac.core.models.IDataModel.take(n: Int): List<Int> = (0 until n).map { this[it] }
fun dev.hexmaniac.core.models.IDataModel.drop(n: Int): List<Int> = (n until this.count).map { this[it] }

fun ReferenceEquals(a: Any?, b: Any?): Boolean = a === b

private fun fmtNumber(v: Long, fmt: String, bits: Int): String {
    val f = fmt.trim()
    if (f.isEmpty()) return v.toString()
    val c = f[0]
    val width = if (f.length > 1) f.substring(1).toIntOrNull() ?: 0 else 0
    val unsigned = if (bits == 32) (v and 0xFFFFFFFFL) else v
    return when (c) {
        'X' -> java.lang.Long.toHexString(unsigned).uppercase().padStart(width, '0')
        'x' -> java.lang.Long.toHexString(unsigned).padStart(width, '0')
        'D', 'd' -> v.toString().padStart(width, '0')
        'N', 'n' -> v.toString()
        else -> v.toString()
    }
}
fun Int.toString(fmt: String): String = fmtNumber(this.toLong(), fmt, 32)
fun Long.toString(fmt: String): String = fmtNumber(this, fmt, 64)
fun Short.toString(fmt: String): String = fmtNumber(this.toLong() and 0xFFFF, fmt, 64)

object AutoSearchTests {
    fun newViewPort(game: String, model: dev.hexmaniac.core.models.IDataModel): dev.hexmaniac.core.viewmodels.ViewPort =
        dev.hexmaniac.core.viewmodels.ViewPort(game, model, dev.hexmaniac.core.models.InstantDispatch.instance, BaseViewModelTestClass.Singletons)
}

fun arrayCopy(src: List<Int>, dst: ByteArray, len: Int) { for (i in 0 until len) dst[i] = src[i].toByte() }

/** C# string.Split(char[] separators, int count, StringSplitOptions.RemoveEmptyEntries) */
fun String.csSplit(separators: CharArray, count: Int = Int.MAX_VALUE): List<String> {
    val result = ArrayList<String>()
    var start = 0
    var i = 0
    while (i < length && result.size < count - 1) {
        if (this[i] in separators) {
            val piece = substring(start, i)
            if (piece.isNotEmpty()) result.add(piece)
            start = i + 1
        }
        i++
    }
    if (start < length) result.add(substring(start))
    return result
}

/** System.IO.File replacement: reads from the test classpath first, then from the file system. */
object File {
    private fun open(path: String): java.io.InputStream {
        val res = Thread.currentThread().contextClassLoader?.getResourceAsStream(path) ?: ClassLoader.getSystemResourceAsStream(path)
        if (res != null) return res
        return java.io.FileInputStream(path)
    }
    fun readAllBytes(path: String): ByteArray = open(path).use { it.readBytes() }
    fun readAllLines(path: String): Array<String> = String(readAllBytes(path), Charsets.UTF_8).split("\r\n", "\n").let { l -> (if (l.isNotEmpty() && l.last().isEmpty()) l.dropLast(1) else l).toTypedArray() }
    fun readAllText(path: String): String = String(readAllBytes(path), Charsets.UTF_8)
    fun exists(path: String): Boolean = try { open(path).close(); true } catch (e: Exception) { false }
}
