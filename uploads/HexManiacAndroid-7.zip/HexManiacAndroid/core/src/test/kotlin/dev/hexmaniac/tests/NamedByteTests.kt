@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class NamedByteTests : BaseViewModelTestClass() {
      @Test fun TwoByteRuns_ChangeOne_ChangesTheOther() {
         ViewPort.edit(".some.counter @02 .some.counter ")
         var run1 = (Model.getNextRun(0) as WordRun)
         var run2 = (Model.getNextRun(2) as WordRun)

         ViewPort.edit("3 ")

         Assert.equal(0, run1.start)
         Assert.equal(2, run2.start)
         Assert.equal(Model[run1.start], Model[run2.start])
      }
      @Test fun SearchForByteRunName_ReturnsByteRuns() {
         ViewPort.edit(".some.counter @02 .some.counter @00 ")

         var results = ViewPort.find("some.counter")

         Assert.equal(Pair(0, 0), results[0])
         Assert.equal(Pair(2, 2), results[1])
      }

      // [Fact] // test is flakey, seems to fail based on whether documentation is loaded or not
      fun Goto_ByteNamePartialText_ReturnsByteRunName() {
         var editor = New.editorViewModel()
         editor.add(ViewPort)
         ViewPort.edit(".some.counter ")

         editor.gotoViewModel.text  = "some.count"

         Assert.contains("some", editor.gotoViewModel.prefixSelections[0].tokens.map({ token -> token.content }))
      }
      @Test fun ByteName_Goto_CreatesNewTab() {
         var editor = New.editorViewModel()
         editor.add(ViewPort)
         ViewPort.edit(".some.counter @02 .some.counter ")

         ViewPort.goto!!.execute("some.counter")

         Assert.equal(2, editor.count)
      }
      @Test fun ByteRuns_SupportOffset() {
         ViewPort.edit(".some.counter-2 ")

         var format = ((ViewPort[0, 0].format) as Integer)
         Assert.equal(0, format.value) // the display value matches the readback value, which includes the offset
      }
      @Test fun ByteRunOffsetCannotCauseNegativeValue() {
         ViewPort.edit(".some.counter+2 ")
         Assert.single(Errors)
      }
      @Test fun ByteRunOffsetCannotCauseOverflowValue() {
         ViewPort.edit(".some.counter-70 200 ")
         Assert.single(Errors)
      }
      @Test fun ByteRun_CanSerialize() {
         ViewPort.edit(".some.counter-2 ")

         var newModel = PokemonModel(Model.rawData, Model.exportMetadata(Singletons.metadataInfo), Singletons)

         var run = (newModel.getNextRun(0) as WordRun)
         Assert.equal(1, run.length)
         Assert.equal(-2, run.valueOffset)
      }
      @Test fun OldMetadata_UpgradeVersion_LoadConstants() {
         var anchors = listOf( StoredAnchor(0, "bob", ""))
         var info = StubMetadataInfo().also { it.versionNumber = "0.3.0.0" }
         var metadata = StoredMetadata(anchors, null, null, null, null, null, info, 0, 0, 0)
         var gameReferenceTables = GameReferenceTables((emptyArray<ReferenceTable>()).toList())
         var singletons = Singletons(
            StubMetadataInfo().also { it.versionNumber = "0.4.0.0" },
            linkedMapOf<String, GameReferenceTables>("BPRE0" to gameReferenceTables),
            Singletons.gameReferenceConstants)

         var data = ByteArray(0x1000000)
         for (i in 0 until 4) data[0xAC + i]  = ("BPRE"[i]).toByte()
         // constant only gets added if all the values match... but for scripts.shiny.odds, all but 5 instance all have a -1 modifier.
         for (i in arrayOf( 0x0F41DA, 0x0F4218, 0x0F4258, 0x0F42A0, 0x104A24)) data[i]  = 1
         var model = PokemonModel(data, metadata, singletons)

         var matches = model.getMatchedWords("scripts.shiny.odds")
         Assert.equal(10, matches!!.size)
      }
      @Test fun NamedConstant_CreateTableWithMatchingLength_TableHasExpectedLength() {
         ViewPort.edit(".some.length 12 @04 ^table[a:]some.length ")

         Assert.equal(12, Model.getTable("table")!!.elementCount)
      }
      @Test fun TableWithNamedConstantLength_ExpandTable_ConstantUpdates() {
         ViewPort.edit(".some.length 12 @04 ^table[a:]some.length ")

         ViewPort.edit("@1C +")

         var table = Model.getTable("table")
         Assert.equal(13, table!!.elementCount)
         Assert.equal(13, Model[0])
      }
      @Test fun TableWithNamedConstantLength_DecreaseConstant_TableLengthChanges() {
         ViewPort.edit(".some.length 12 @04 ^table[a:]some.length ")

         ViewPort.edit("@00 11 ")

         var table = Model.getTable("table")
         Assert.equal(11, Model[0])
         Assert.equal(11, table!!.elementCount)
      }
      @Test fun TableWithNamedConstantLength_IncreaseConstant_TableLengthChanges() {
         ViewPort.edit(".some.length 12 @04 ^table[a:]some.length ")

         ViewPort.edit("@00 13 ")

         var table = Model.getTable("table")
         Assert.equal(13, Model[0])
         Assert.equal(13, table!!.elementCount)
      }
      fun ByteToken_NoName_Error(edit: String) {
         ViewPort.edit(edit)

         Assert.single(Errors)
      }
    @Test fun ByteToken_NoName_Error_1() { ByteToken_NoName_Error(":: ") }
    @Test fun ByteToken_NoName_Error_2() { ByteToken_NoName_Error(": ") }
    @Test fun ByteToken_NoName_Error_3() { ByteToken_NoName_Error(". ") }
      @Test fun MatchedWordOutOfRange_InitMetadata_IgnoreMatchedWord() {
         var metadata = StoredMetadata(matchedWords = listOf( StoredMatchedWord(0x300, "name", 2, 0, 1, null)))

         var model = New.pokemonModel(Data, metadata)

         Assert.empty(model.getMatchedWords("name"))
      }
      @Test fun MatchedWordOutOfRange_LoadMetadata_IgnoreMatchedWords() {
         var metadata = StoredMetadata(matchedWords = listOf( StoredMatchedWord(0x300, "name", 2, 0, 1, null)))

         Model.loadMetadata(metadata)

         Assert.empty(Model.getMatchedWords("name"))
      }
      @Test fun TypingConstant_TypeEquals_SetsValue() {
         ViewPort.edit(".some.constant=3 ")
         Assert.equal(3, Model[0])
         Assert.equal(Point(1, 0), ViewPort.selectionStart)
      }
      @Test fun TypingConstantWithOffset_TypeEquals_SetsValue() {
         ViewPort.edit(".some.constant+4=12 ")
         Assert.equal(12, Model[0])
      }
      @Test fun NamedConstant_Copy_CopyConstantFormat() {
         ViewPort.edit(".some.constant ")

         ViewPort.selectionStart  = newOf(0, 0)
         ViewPort.selectionEnd  = newOf(0, 0)
         ViewPort.copy!!.execute(FileSystem)

         Assert.equal(".some.constant=0 ", FileSystem.copyText.value)
      }
   }
