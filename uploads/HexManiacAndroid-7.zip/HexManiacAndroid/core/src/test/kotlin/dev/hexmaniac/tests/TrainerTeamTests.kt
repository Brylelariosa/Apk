@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "PropertyName", "FunctionName", "VARIABLE_WITH_REDUNDANT_INITIALIZER", "RedundantExplicitType", "USELESS_CAST", "UNNECESSARY_NOT_NULL_ASSERTION", "UNNECESSARY_SAFE_CALL", "SENSELESS_COMPARISON", "DEPRECATION", "UNREACHABLE_CODE", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE", "ClassName")

package dev.hexmaniac.tests

import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.system.*
import org.junit.Test
import org.junit.Ignore

   open class TrainerTeamTests : BaseViewModelTestClass() {
      private lateinit var run: TrainerPokemonTeamRun

      init {
         CreateTextTable(HardcodeTablesModel.itemsTableName, 0x100, "potion", "hyper potion", "rare candy", "masterball", "go-goggles", "king's rock")
         CreateTextTable(HardcodeTablesModel.pokemonNameTable, 0x150, "bulbasaur", "farfetch'd", "nidoran \\sm", "mr. mime", "ho-oh")
         CreateTextTable(HardcodeTablesModel.moveNamesTable, 0x1A0, "tackle", "scratch", "hyper beam", "rest", "name-with-dash")
         run  = TrainerPokemonTeamRun(Model, 0, false, SortedSpan<Int>.none())
      }
      @Test fun TrainerTeam_RequestAutocompletePokemonLevel_NoOptions() {
         var options = run.getAutoCompleteOptions("1 bulbasaur (3)", 0, 1)

         Assert.empty(options)
      }
      @Test fun TrainerTeam_RequestAutocompletePokemonSpecies_CorrectOptions() {
         var options = run.getAutoCompleteOptions("1 i (3) @potion", 0, 3)

         Assert.equal(2, options.size)
         Assert.equal("1 \"nidoran \\sm\" (3) @potion", options[0].lineText)
         Assert.equal("\"mr. mime\"", options[1].text)
      }
      @Test fun TrainerTeam_RequestAutocompletePokemonIVs_NoOptions() {
         var options = run.getAutoCompleteOptions("1 i (3) @potion", 0, 6)

         Assert.empty(options)
      }
      @Test fun TrainerTeam_RequestAutocompleteItem_CorrectOptions() {
         var options = run.getAutoCompleteOptions("1 i (3) @potion", 0, 12)

         Assert.equal(2, options.size)
         Assert.equal("1 i (3) @potion", options[0].lineText)
         Assert.equal("\"hyper potion\"", options[1].text)
      }
      @Test fun TrainerTeam_RequestAutocompleteMove_CorrectOptions() {
         var options = run.getAutoCompleteOptions("- t", 0, 12)

         Assert.equal(4, options.size)
         Assert.equal("- tackle", options[0].lineText)
         Assert.equal("scratch", options[1].text)
         Assert.equal("rest", options[2].text)
         Assert.equal("name-with-dash", options[3].text)
      }
      @Test fun TrainerData_Serialize_SeeIVLabel() {
         var parent = SetupTrainerTable(0x100, 1)
         parent.writeValue(4, Model, ViewPort.currentChange, 0, "pokemonCount")
         parent.writePointer(0x80, Model, ViewPort.currentChange, 0, "pokemon")
         var teamRun = TrainerPokemonTeamRun(Model, 0x80, false, SortedSpan<Int>(0x100 + 36))
         Model.observeRunWritten(ViewPort.currentChange, teamRun)

         var text = teamRun.serializeRun()

         Assert.contains("(IVs=0)", text)
      }
      @Test fun TrainerData_DeserializeWithIVLabel_IVChanges() {
         var parent = SetupTrainerTable(0x100, 1)
         parent.writeValue(4, Model, ViewPort.currentChange, 0, "pokemonCount")
         parent.writePointer(0x80, Model, ViewPort.currentChange, 0, "pokemon")
         var teamRun = TrainerPokemonTeamRun(Model, 0x80, false, SortedSpan<Int>(0x100 + 36))
         Model.observeRunWritten(ViewPort.currentChange, teamRun)

         var newRun = teamRun.deserializeRun("1 bulbasaur (IVs=12) ", ViewPort.currentChange, false, false)

         Assert.inRange(newRun.readValue(Model, 0, "ivSpread"), 12 * 8, 12 * 8 + 7)
      }
      @Test fun TrainerWithTwoPokemon_ChangePokemonCountToThree_PokemonTeamRepoints() {
         // write data for two trainers
         Model[TrainerTablePokemonCountOffset]  = 2
         Model.writePointer(ModelDelta(), TrainerTablePokemonPointerOffset, 0x80)
         WriteBasicTrainerPokmeon(0x80, 0, 5, 0)
         WriteBasicTrainerPokmeon(0x88, 0, 5, 0)
         Model[TrainerTableElementLength + TrainerTablePokemonCountOffset]  = 2
         Model.writePointer(ModelDelta(), TrainerTableElementLength + TrainerTablePokemonPointerOffset, 0x88)
         WriteBasicTrainerPokmeon(0x90, 0, 5, 0)
         WriteBasicTrainerPokmeon(0x98, 0, 5, 0)

         SetupTrainerTable(0, 2)

         // set the trainer to have 3 pokemon
         ViewPort.refresh()
         var tool = ((ViewPort.tools!!.tableTool!!.children.single({ child -> child  is FieldArrayElementViewModel && (child as FieldArrayElementViewModel).name == "pokemonCount" })) as FieldArrayElementViewModel)
         tool.content  = "3"

         Assert.single(Messages)
         Assert.notEqual(0x80, Model.getNextRun(0x80).start); // run should've repointed
         Assert.notEqual(0x80, Model.readPointer(TrainerTablePokemonPointerOffset))
      }
      @Test fun DashWithSpace_AutoComplete_NoOptions() {
         var options = run.getAutoCompleteOptions("- ", 2, 2).toMutableList()
         Assert.empty(options)
      }
      @Test fun DashSpaceDash_AutoComplete_HaveOptions() {
         var options = run.getAutoCompleteOptions("- -", 3, 3).toMutableList()
         Assert.notEmpty(options)
      }
      @Test fun DashInName_AutoComplete_AutoCompleteOptionsHaveDash() {
         var options = run.getAutoCompleteOptions("- -", 3, 3).toMutableList()
         Assert.all(options, { option -> Assert.contains("-", option.text) })
      }
      fun SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter(specialCharacter: String) {
         var options = run.getAutoCompleteOptions("12 " + specialCharacter, 4, 4).toMutableList()
         Assert.notEmpty(options)
         Assert.all(options, { option -> Assert.contains(specialCharacter, option.text) })
      }
    @Test fun SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter_1() { SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter("-") }
    @Test fun SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter_2() { SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter("'") }
    @Test fun SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter_3() { SpecialCharacterInPokemonName_AutoComplete_ListContainsOnlyElementsWithThatCharacter(".") }
      fun SpecialCharacterInItemName_AutoComplete_ListContainsOnlyElementsWithThatCharacter(specialCharacter: String) {
         var options = run.getAutoCompleteOptions("12 bulbsaur @" + specialCharacter, 14, 14).toMutableList()
         Assert.notEmpty(options)
         Assert.all(options, { option -> Assert.contains(specialCharacter, option.text) })
      }
    @Test fun SpecialCharacterInItemName_AutoComplete_ListContainsOnlyElementsWithThatCharacter_1() { SpecialCharacterInItemName_AutoComplete_ListContainsOnlyElementsWithThatCharacter("-") }
    @Test fun SpecialCharacterInItemName_AutoComplete_ListContainsOnlyElementsWithThatCharacter_2() { SpecialCharacterInItemName_AutoComplete_ListContainsOnlyElementsWithThatCharacter("'") }
      @Test fun TeamWithIVScalingOff_255IVs_Show255() {
         var run = TrainerPokemonTeamRun(Model, 0, true, SortedSpan<Int>.none())
         Model.writeMultiByteValue(0, 2, Token, 255)

         Assert.isNotType<ArrayRunTupleSegment>(run.elementContent[0])
         Assert.contains("IVs=255", run.serializeRun())
      }
      @Test fun TrainerWithOnePokemon_ChangeCountToZero_NullPointer() {
         Token.changeData(Model, 0, 0x80.range({ i -> 0xFF.u8() }).toMutableList())
         Model.freeSpaceBuffer  = 0
         SetupTrainerTable(0x80, 2)

         ViewPort.edit("@trainertable/0/pokemonCount 1 ")

         Assert.notEqual(Pointer.null_, Model.readPointer(0x80 + 36))
      }
      @Test fun TrainerWithNullPokemon_ChangeCountToOne_OnePokemon() {
         Token.changeData(Model, 0, 0x80.range({ i -> 0xFF.u8() }).toMutableList())
         Model.freeSpaceBuffer  = 0
         SetupTrainerTable(0x80, 2)

         ViewPort.edit("@trainertable/0/pokemonCount 1 ")
         ViewPort.edit("@trainertable/0/pokemonCount 0 ")

         Assert.equal(Pointer.null_, Model.readPointer(0x80 + 36))
      }

      /// <summary>
      /// Basic trainer pokemon are 8 bytes
      /// </summary>
      private fun WriteBasicTrainerPokmeon(address: Int, ivs: Int, level: Int, species: Int) {
         var token = ModelDelta()
         Model.writeMultiByteValue(address + 0, 2, token, ivs)
         Model.writeMultiByteValue(address + 2, 2, token, level)
         Model.writeMultiByteValue(address + 4, 2, token, species)
         Model.writeMultiByteValue(address + 6, 2, token, 0)
      }

      val TrainerTablePokemonCountOffset: Int = 32
      val TrainerTablePokemonPointerOffset: Int = 36
      val TrainerTableElementLength: Int = 40
      private fun SetupTrainerTable(address: Int, elementCount: Int): ITableRun {
         ViewPort.goto!!.execute(address)
         // 40 bytes per trainer
         //                                                      4          16      20      24             28   32             36
         ViewPort.edit("^trainertable[structType. class. stuff: name\"\"12 items:: items:: doubleBattle:: ai:: pokemonCount:: pokemon<`tpt`>]${elementCount} ")
         return Model.getTable("trainertable")!!
      }
   }
