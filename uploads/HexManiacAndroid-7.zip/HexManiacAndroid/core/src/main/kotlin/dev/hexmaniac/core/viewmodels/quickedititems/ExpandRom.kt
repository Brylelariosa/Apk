// Port of ViewModels/QuickEditItems/ExpandRom.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*

open class ExpandRom : IQuickEditItem { // cs:7-60
    override val name: String?
        get() { /*@DONE ExpandRom.Name.get cs:8-8*/
            return "Expand Rom"
        }
    override val description: String?
        get() { /*@DONE ExpandRom.Description.get cs:10-12*/
            return "Change the size of the gba file (make it bigger or smaller)." + NEW_LINE +
                "Warning: Decreasing the size of your ROM will permanently delete some data." + NEW_LINE +
                "Edit your ROM size carefully!"
        }
    override val wikiLink: String?
        get() { /*@DONE ExpandRom.WikiLink.get cs:14-14*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Rom-Expansion-Explained"
        }
    lateinit var fileSystem: IFileSystem
        private set
    override val canRunChanged = Event<EventArgs>()
    constructor(fs: IFileSystem) { /*@DONE ExpandRom.<init>/1 cs:20-20*/
        this.fileSystem = fs
    }
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE ExpandRom.CanRun/1 cs:22-24*/
        return viewPort is IEditableViewPort && viewPort.fileName.endsWith(".gba")
    }
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? { /*@DONE ExpandRom.Run/1 cs:26-55*/
        val editableViewPort = viewPort as IEditableViewPort
        val text: String? = fileSystem.requestText(
            "New File Length",
            arrayOf(
                "What length would you like to expand your file to?",
                "If you choose a length shorter than the current length, the file will be truncated.",
                "Enter a number of bytes (hexadecimal) or megabytes (decimal)."
            ).joinToString(NEW_LINE))
        if (text.isNullOrEmpty()) return Task.fromResult(ErrorInfo.noError)

        val trimmed = text.trim()
        val isHex = trimmed.isNotEmpty() && trimmed.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }
        val significant = trimmed.trimStart('0')
        if (!isHex || significant.length > 8) {
            return Task.fromResult(ErrorInfo(text + " is not a valid hex length"))
        }
        var length: Long = if (significant.isEmpty()) 0L else significant.toLong(16)
        if (length < 1) length = 1
        if (length < 0x100000) {
            val decimal = if (trimmed.all { it in '0'..'9' }) trimmed.toLongOrNull() else null
            if (decimal == null) return Task.fromResult(ErrorInfo("The file must be at least 0x100_000 bytes long."))
            length = decimal * 1024 * 1024 // assume the number is in decimal MBs
            if (length < 0x100000) return Task.fromResult(ErrorInfo("The file must be at least 0x100_000 bytes long."))
        }
        if (length > 0x2000000) {
            return Task.fromResult(ErrorInfo("GBA games can only be 0x2_000_000 bytes (32 MB) long."))
        }

        val model = viewPort.model ?: return Task.fromResult(ErrorInfo.noError)
        val change = editableViewPort.changeHistory.currentChange
        model.expandData(change, (length - 1).toInt())
        model.clearFormat(change, length.toInt(), (model.count - length).toInt())
        model.contractData(change, (length - 1).toInt())
        viewPort.refresh()

        return Task.fromResult(ErrorInfo.noError)
    }
    override fun tabChanged() { /*@DONE ExpandRom.TabChanged/1 cs:57-59*/
        canRunChanged(this, EventArgs.empty)
    }
    /*@END ExpandRom*/
}
