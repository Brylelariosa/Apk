// Port of ViewModels/Tools/SelectionViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

open class SelectionViewModel : ViewModelCore() { // cs:2-11
    private var _selected: Boolean = false
    var selected: Boolean
        get() { /*@DONE SelectionViewModel.Selected.get cs:4-4*/
            return _selected
        }
        set(value) { /*@DONE SelectionViewModel.Selected.set cs:4-4*/
            set(_selected, value, "selected", { _selected = it })
        }
    private var _name: String = ""
    var name: String
        get() { /*@DONE SelectionViewModel.Name.get cs:7-7*/
            return _name
        }
        set(value) { /*@DONE SelectionViewModel.Name.set cs:7-7*/
            set(_name, value, "name", { _name = it })
        }
    private var _index: Int = 0
    var index: Int
        get() { /*@DONE SelectionViewModel.Index.get cs:10-10*/
            return _index
        }
        set(value) { /*@DONE SelectionViewModel.Index.set cs:10-10*/
            set(_index, value, "index", { _index = it })
        }
    /*@END SelectionViewModel*/
}
