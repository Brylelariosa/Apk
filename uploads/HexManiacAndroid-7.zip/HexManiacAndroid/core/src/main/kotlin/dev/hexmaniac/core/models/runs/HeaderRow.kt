// Port of Models/Runs/HeaderRow.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*

open class ColumnHeader : ViewModelCore { // cs:6-14
    var columnTitle: String = ""
        private set
    var byteWidth: Int = 0
        private set
    private var _isSelected: Boolean = false
    var isSelected: Boolean
        get() { /*@DONE ColumnHeader.IsSelected.get cs:11-11*/
            return _isSelected
        }
        set(value) { /*@DONE ColumnHeader.IsSelected.set cs:11-11*/
            set(_isSelected, value, "isSelected", { _isSelected = it })
        }
    constructor(title: String, byteWidth: Int = 1, isSelected: Boolean = false) { /*@DONE ColumnHeader.<init>/1 cs:13-13*/
        this.columnTitle = title
        this.byteWidth = byteWidth
    }
    /*@END ColumnHeader*/
}

open class ColumnHeaderRow : ViewModelCore { // cs:20-67
    var columnHeaders: List<ColumnHeader> = ArrayList()
        private set
    constructor(source: ArrayRun, byteStart: Int, length: Int) { /*@DONE ColumnHeaderRow.<init>/1 cs:23-49*/
        val headers = ArrayList<ColumnHeader>()
        // we know which 'byte' to start at, but we want to know what 'index' to start at
        // basically, count off each element to figure out how big it is
        val elementContent = source.elementContent!!
        var currentByte = 0
        var startIndex = 0
        while (currentByte < byteStart) {
            currentByte += elementContent[startIndex % elementContent.size].length
            startIndex++
        }
        var initialPartialSegmentLength = currentByte - byteStart
        if (initialPartialSegmentLength > 0) startIndex--
        currentByte = 0
        var i = 0
        while (currentByte < length) {
            val segment = elementContent[(startIndex + i) % elementContent.size]
            if (segment.length == 0) {
                i++
                continue
            }
            if (initialPartialSegmentLength != 0) {
                headers.add(ColumnHeader(segment.name, initialPartialSegmentLength))
                currentByte += initialPartialSegmentLength
            } else {
                headers.add(ColumnHeader(segment.name, segment.length))
                currentByte += segment.length
            }
            initialPartialSegmentLength = 0
            i++
        }
        columnHeaders = headers
    }
    constructor(start: Int, length: Int) { /*@DONE ColumnHeaderRow.<init>/2 cs:51-57*/
        var begin = start
        while (begin < 0) begin += length
        val hex = "0123456789ABCDEF"
        val headers = ArrayList<ColumnHeader>()
        for (i in 0 until length) headers.add(ColumnHeader(hex[(begin + i) % 0x10].toString()))
        columnHeaders = headers
    }
    constructor(token: String, length: Int) { /*@DONE ColumnHeaderRow.<init>/3 cs:59-59*/
        columnHeaders = listOf(ColumnHeader(token, length))
    }
    companion object {
        fun getDefaultColumnHeaders(columnCount: Int, startingDataIndex: Int): List<ColumnHeaderRow> { /*@DONE ColumnHeaderRow.GetDefaultColumnHeaders/1 cs:61-66*/
            if (columnCount > 0x10 && columnCount % 0x10 != 0) return ArrayList()
            if (columnCount < 0x10 && 0x10 % columnCount != 0) return ArrayList()
            if (columnCount >= 0x10) return listOf(ColumnHeaderRow(startingDataIndex, columnCount))
            return (0 until 0x10 / columnCount).map { i -> ColumnHeaderRow(columnCount * i + startingDataIndex, columnCount) }
        }
        /*@END ColumnHeaderRow.Companion*/
    }
    /*@END ColumnHeaderRow*/
}
