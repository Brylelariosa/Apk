// Port of Models/Runs/Factory/TilesetRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class TilesetRunContentStrategy : RunStrategy { // cs:6-42
    var tilesetFormat: TilesetFormat = TilesetFormat()
        private set
    constructor(format: TilesetFormat) { /*@DONE TilesetRunContentStrategy.<init>/1 cs:8-8*/
        tilesetFormat = format
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE TilesetRunContentStrategy.LengthForNewRun/1 cs:10-10*/
        return tilesetFormat.tiles * tilesetFormat.bitsPerPixel * 8
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE TilesetRunContentStrategy.TryAddFormatAtDestination/1 cs:12-17*/
        val newRun = TilesetRun(tilesetFormat, owner, destination)
        if ((owner.getNextRun(destination + 1) ?: NoInfoRun.nullRun).start < destination + newRun.length) return false
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, newRun)
        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE TilesetRunContentStrategy.Matches/1 cs:19-19*/
        return run is TilesetRun && run.tilesetFormat.bitsPerPixel == tilesetFormat.bitsPerPixel && run.tilesetFormat.tiles == tilesetFormat.tiles
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE TilesetRunContentStrategy.WriteNewRun/1 cs:21-24*/
        val newRun = TilesetRun(tilesetFormat, owner, destination, SortedSpanStatic.one(source))
        return newRun
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE TilesetRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:26-31*/
        val newRun = TilesetRun(tilesetFormat, model, run.value.start, run.value.pointerSources)
        if ((model.getNextRun(run.value.start + 1) ?: NoInfoRun.nullRun).start < run.value.start + newRun.length) return
        model.clearFormat(token, newRun.start, newRun.length)
        run.value = newRun
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE TilesetRunContentStrategy.TryParseData/1 cs:33-41*/
        val error = SpriteRunContentStrategy.isValid(tilesetFormat)
        if (error.hasError) return error
        val current = run.value
        val start = current?.start ?: dataIndex
        val newRun = TilesetRun(tilesetFormat, model, start, current?.pointerSources)
        val nextRun = model.getNextRun(start + 1) ?: NoInfoRun.nullRun
        if (start < nextRun.start && nextRun.start < start + newRun.length) return ErrorInfo("Format was specified as a tileset with " + tilesetFormat.tiles + " tiles, but there wasn't enough space.")
        run.value = newRun
        return ErrorInfo.noError
    }
    /*@END TilesetRunContentStrategy*/
}
