// Port of Models/ModelTable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class ModelTable : DynamicObject, ReadOnlyListMixin<ModelArrayElement> { // cs:14-61
    private lateinit var model: IDataModel
    private var arrayAddress: Int = 0
    private lateinit var tokenFactory: () -> ModelDelta
    private var _run: ITableRun? = null
    override val size: Int
        get() { /*@DONE ModelTable.Count.get cs:20-20*/
            return _run?.elementCount ?: 0
        }
    fun __len__(): Int { /*@DONE ModelTable.__len__/1 cs:21-21*/
        return size
    }
    val run: ITableRun
        get() { /*@DONE ModelTable.Run.get cs:23-23*/
            return _run!!
        }
    override operator fun get(value: Int): ModelArrayElement { /*@DONE ModelTable.this/1.get cs:26-28*/
        return ModelArrayElement(model, arrayAddress, value, tokenFactory, _run)
    }
    operator fun get(value: String): ModelArrayElement { /*@DONE ModelTable.this/2.get cs:32-39*/
        val table = run
        val index = Ref(0)
        if (ArrayRunEnumSegment.tryMatch(value, table.elementNames ?: emptyList(), index)) {
            return this[index.value]
        } else {
            throw NotImplementedError()
        }
    }
    constructor(model: IDataModel, table: ITableRun, tokenFactory: (() -> ModelDelta)? = null) : this(model, table.start, tokenFactory, table) { /*@DONE ModelTable.<init>/1 cs:42-42*/
        // all of the work is done by the delegated constructor
    }
    constructor(model: IDataModel, address: Int, tokenFactory: (() -> ModelDelta)? = null, tableRun: ITableRun? = null) { /*@DONE ModelTable.<init>/2 cs:44-48*/
        this.model = model
        this.arrayAddress = address
        _run = tableRun ?: (model.getNextRun(address) as? ITableRun)
        this.tokenFactory = tokenFactory ?: { NoDataChangeDeltaModel() }
    }
    override fun tryGetMember(binder: GetMemberBinder, result: Ref<Any?>): Boolean { /*@DONE ModelTable.TryGetMember/1 cs:50-53*/
        result.value = this[binder.name]
        return true
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END ModelTable*/
}

open class ModelArrayElement : DynamicObject { // cs:63-419
    private lateinit var _model: IDataModel
    private var arrayAddress: Int = 0
    private var _arrayIndex: Int = 0
    private lateinit var _table: ITableRun
    private lateinit var tokenFactory: () -> ModelDelta
    val start: Int
        get() { /*@DONE ModelArrayElement.Start.get cs:70-70*/
            return table.start + table.elementLength * arrayIndex
        }
    val arrayIndex: Int
        get() { /*@DONE ModelArrayElement.ArrayIndex.get cs:71-71*/
            return _arrayIndex
        }
    val length: Int
        get() { /*@DONE ModelArrayElement.Length.get cs:72-72*/
            return table.elementLength
        }
    val address: String
        get() { /*@DONE ModelArrayElement.Address.get cs:73-73*/
            return start.toAddress()
        }
    val table: ITableRun
        get() { /*@DONE ModelArrayElement.Table.get cs:74-74*/
            return _table
        }
    val model: IDataModel?
        get() { /*@DONE ModelArrayElement.Model.get cs:75-75*/
            return _model
        }
    val token: ModelDelta
        get() { /*@DONE ModelArrayElement.Token.get cs:76-76*/
            return tokenFactory()
        }
    constructor(model: IDataModel, address: Int, index: Int, tokenFactory: () -> ModelDelta, table: ITableRun?) { /*@DONE ModelArrayElement.<init>/1 cs:78-82*/
        _model = model
        arrayAddress = address
        _arrayIndex = index
        _table = table ?: (model.getNextRun(address) as ITableRun)
        this.tokenFactory = tokenFactory
    }
    fun hasField(name: String): Boolean { /*@DONE ModelArrayElement.HasField/1 cs:84-84*/
        return table.elementContent.any { field -> field.name == name }
    }
    fun getFieldName(index: Int): String { /*@DONE ModelArrayElement.GetFieldName/1 cs:86-86*/
        return table.elementContent[index].name
    }
    fun getStringValue(fieldName: String): String { /*@DONE ModelArrayElement.GetStringValue/1 cs:88-103*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        var valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg.type == ElementContentType.PCS) {
            return (model.textConverter.convert(model, valueAddress, seg.length) ?: "").trim('"')
        } else if (seg.type == ElementContentType.Pointer) {
            valueAddress = model.readPointer(valueAddress)
            if (valueAddress < 0 || valueAddress >= model.count) return ""
            val length = PCSString.readString(model, valueAddress, true)
            if (length < 1) return ""
            return (model.textConverter.convert(model, valueAddress, length) ?: "").trim('"')
        } else {
            throw NotImplementedError()
        }
    }
    fun serialize(fieldName: String): String { /*@DONE ModelArrayElement.Serialize/1 cs:105-123*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg.type == ElementContentType.Pointer) {
            val destination = model.readPointer(valueAddress)
            if (destination == Pointer.null_) return "null"
            var run: IFormattedRun = model.getNextRun(destination) ?: NoInfoRun.nullRun
            val tRun = run as? ArrayRun
            if (tRun != null) {
                run = TableStreamRun(model, tRun.start, tRun.pointerSources, tRun.formatString, tRun.elementContent, FixedLengthStreamStrategy(tRun.elementCount))
            }
            val sRun = run as? IStreamRun
            if (sRun != null) return sRun.serializeRun() ?: ""
            return destination.toAddress()
        }
        if (seg.type == ElementContentType.PCS) return getStringValue(fieldName)
        if (seg is ArrayRunEnumSegment) return getEnumValue(fieldName)
        return getValue(fieldName).toString()
    }
    fun getSprite(fieldName: String): Array<IntArray>? { /*@DONE ModelArrayElement.GetSprite/1 cs:125-141*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg is ArrayRunPointerSegment) {
            val destination = model.readPointer(valueAddress)
            var spriteRun = model.getNextRun(destination) as? ISpriteRun
            if (spriteRun == null) {
                val tempRun = Ref<IFormattedRun?>(NoInfoRun(destination, SortedSpan(valueAddress)))
                model.formatRunFactory.getStrategy(seg.innerFormat)?.tryParseData(model, "", destination, tempRun)
                spriteRun = tempRun.value as? ISpriteRun
                if (spriteRun == null) return null
            }
            return spriteRun.getPixels(model, 0, arrayIndex)
        } else {
            throw NotImplementedError()
        }
    }
    fun getPalette(fieldName: String): List<Short>? { /*@DONE ModelArrayElement.GetPalette/1 cs:143-159*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg is ArrayRunPointerSegment) {
            val destination = model.readPointer(valueAddress)
            var palRun = model.getNextRun(destination) as? IPaletteRun
            if (palRun == null) {
                val tempRun = Ref<IFormattedRun?>(NoInfoRun(destination, SortedSpan(valueAddress)))
                model.formatRunFactory.getStrategy(seg.innerFormat)?.tryParseData(model, "", destination, tempRun)
                palRun = tempRun.value as? IPaletteRun
                if (palRun == null) return null
            }
            return palRun.getPalette(model, 0)
        } else {
            throw NotImplementedError()
        }
    }
    fun getValue(fieldName: String): Int { /*@DONE ModelArrayElement.GetValue/1 cs:161-174*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.firstOrNull { segment -> segment.name == fieldName } ?: return -1
        if (seg.type == ElementContentType.Integer && seg is ArrayRunSignedSegment) {
            return seg.readValue(model, valueAddress)
        }
        if (seg.type == ElementContentType.Integer) {
            return model.readMultiByteValue(valueAddress, seg.length)
        } else {
            return model.readMultiByteValue(valueAddress, seg.length.limitToRange(0, 3))
        }
    }
    fun getValue(fieldIndex: Int): Int { /*@DONE ModelArrayElement.GetValue/2 cs:176-185*/
        val model = _model
        val elementOffset = table.elementContent.take(Math.max(0, fieldIndex)).sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent[fieldIndex]
        if (seg.type == ElementContentType.Integer) {
            return model.readMultiByteValue(valueAddress, seg.length)
        } else {
            throw NotImplementedError()
        }
    }
    fun tryGetValue(fieldName: String, value: Ref<Int>): Boolean { /*@DONE ModelArrayElement.TryGetValue/1 cs:187-192*/
        value.value = -1
        if (!hasField(fieldName)) return false
        value.value = getValue(fieldName)
        return true
    }
    fun getAddress(fieldName: String): Int { /*@DONE ModelArrayElement.GetAddress/1 cs:194-206*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.firstOrNull { segment -> segment.name == fieldName } ?: return Pointer.null_
        if (seg.type == ElementContentType.Pointer) {
            return model.readPointer(valueAddress)
        } else if (seg.type == ElementContentType.Integer && seg.length == 4) {
            return model.readPointer(valueAddress) // user wants a pointer, read it like a pointer
        } else {
            throw NotImplementedError()
        }
    }
    fun getEnumValue(fieldName: String): String { /*@DONE ModelArrayElement.GetEnumValue/1 cs:208-219*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg is ArrayRunEnumSegment) {
            ModelCacheScope.createScope(model).using {
                return (seg.toText(model, valueAddress, 0) ?: "").trim('"')
            }
        } else {
            throw NotImplementedError()
        }
    }
    fun getTuple(fieldName: String): ModelTupleElement { /*@DONE ModelArrayElement.GetTuple/1 cs:221-229*/
        val model = _model
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        val segmentOffset = table.elementContent.until { s -> s === seg }.sumOf { s -> s.length }
        if (seg is ArrayRunBitArraySegment) {
            return ModelTupleElement(model, table, arrayIndex, segmentOffset, seg, tokenFactory)
        } else {
            return ModelTupleElement(model, table, arrayIndex, segmentOffset, seg as ArrayRunTupleSegment, tokenFactory)
        }
    }
    fun __getindex__(key: String): Any? { /*@DONE ModelArrayElement.__getindex__/1 cs:231-231*/
        return this[key]
    }
    fun __setindex__(key: String, value: Any) { /*@DONE ModelArrayElement.__setindex__/1 cs:232-232*/
        this[key] = value
    }
    operator fun get(fieldName: String): Any? { /*@DONE ModelArrayElement.this/1.get cs:234-254*/
        val model = _model
        val seg = table.elementContent.firstOrNull { segment -> segment.name == fieldName } ?: return null
        val segmentOffset = table.elementContent.until { s -> s === seg }.sumOf { s -> s.length }
        if (seg is ArrayRunEnumSegment) return getEnumValue(fieldName)
        if (seg.type == ElementContentType.Pointer) {
            val address = getAddress(fieldName)
            val table1 = model.getNextRun(address) as? ITableRun
            if (table1 != null) {
                return ModelTable(model, table1.start, tokenFactory)
            }
            return address
        }
        if (seg.type == ElementContentType.PCS) return getStringValue(fieldName)
        if (seg is ArrayRunTupleSegment) {
            return ModelTupleElement(model, table, arrayIndex, segmentOffset, seg, tokenFactory)
        }
        if (seg is ArrayRunBitArraySegment) {
            return ModelTupleElement(model, table, arrayIndex, segmentOffset, seg, tokenFactory)
        }
        return getValue(fieldName)
    }
    operator fun set(fieldName: String, value: Any?) { /*@DONE ModelArrayElement.this/1.set cs:255-269*/
        val seg = table.elementContent.firstOrNull { segment -> segment.name == fieldName }
            ?: throw IllegalArgumentException("Couldn't find a member named " + fieldName)
        if (seg is ArrayRunEnumSegment) {
            if (value is String) setEnumValue(fieldName, value)
            else if (value is java.math.BigInteger) setValue(fieldName, value.toInt())
            else setValue(fieldName, (value as Number).toInt())
        } else if (seg.type == ElementContentType.Pointer) {
            if (value is String) {
                setStringValue(fieldName, value)
            } else {
                setAddress(fieldName, (value as Number).toInt())
            }
        } else if (seg.type == ElementContentType.PCS) setStringValue(fieldName, value as String)
        else setValue(fieldName, (value as Number).toInt())
    }
    fun setEnumValue(fieldName: String, valueText: String) { /*@DONE ModelArrayElement.SetEnumValue/1 cs:272-284*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg is ArrayRunEnumSegment) {
            val value = Ref(0)
            if (seg.tryParse(model, valueText, value)) {
                model.writeMultiByteValue(valueAddress, seg.length, tokenFactory(), value.value)
                table.notifyChildren(model, tokenFactory(), arrayIndex, table.elementContent.indexOf(seg))
            }
        } else {
            throw NotImplementedError()
        }
    }
    fun setAddress(fieldName: String, value: Int, writeDestinationFormat: Boolean = true) { /*@DONE ModelArrayElement.SetAddress/1 cs:286-298*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        var seg: ArrayRunElementSegment = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg is ArrayRunRecordSegment) seg = seg.createConcrete(model, table, valueAddress)
        if (seg.type == ElementContentType.Pointer) {
            model.updateArrayPointer(token, seg, table.elementContent, arrayIndex, valueAddress, value, writeDestinationFormat)
        } else {
            // it's not a pointer so don't update any formats to think that this points to them
            // bet we should still update the value.
            model.writePointer(token, valueAddress, value)
        }
    }
    fun setStringValue(fieldName: String, value: String) { /*@DONE ModelArrayElement.SetStringValue/1 cs:300-322*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        var valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        val token = tokenFactory()
        if (seg.type == ElementContentType.PCS) {
            val bytes = model.textConverter.convert(value, Ref(false)) ?: ArrayList<Int>()
            while (bytes.size > seg.length) bytes.removeAt(bytes.size - 1)
            bytes[bytes.size - 1] = 0xFF
            while (bytes.size < seg.length) bytes.add(0)
            token.changeData(model, valueAddress, bytes.toByteArrayU().asByteList())
        } else if (seg.type == ElementContentType.Pointer) {
            valueAddress = model.readPointer(valueAddress)
            val length = PCSString.readString(model, valueAddress, true)
            val bytes = model.textConverter.convert(value, Ref(false)) ?: ArrayList<Int>()
            var pcsRun = model.getNextRun(valueAddress) as PCSRun
            pcsRun = model.relocateForExpansion(token, pcsRun, bytes.size)
            pcsRun = pcsRun.deserializeRun(value, token, Ref<List<Int>?>(null), Ref<List<Int>?>(null)) as PCSRun
            model.observeRunWritten(token, pcsRun)
        } else {
            throw NotImplementedError()
        }
    }
    fun setValue(fieldName: String, value: Int) { /*@DONE ModelArrayElement.SetValue/1 cs:324-334*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent.single { segment -> segment.name == fieldName }
        if (seg.type == ElementContentType.Integer || seg.type == ElementContentType.BitArray) {
            model.writeMultiByteValue(valueAddress, seg.length, tokenFactory(), value)
            table.notifyChildren(model, tokenFactory(), arrayIndex, table.elementContent.indexOf(seg))
        } else {
            throw NotImplementedError()
        }
    }
    fun setValue(fieldIndex: Int, value: Int) { /*@DONE ModelArrayElement.SetValue/2 cs:336-345*/
        val model = _model
        val elementOffset = table.elementContent.take(Math.max(0, fieldIndex)).sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        val seg = table.elementContent[fieldIndex]
        if (seg.type == ElementContentType.Integer || seg.type == ElementContentType.BitArray) {
            model.writeMultiByteValue(valueAddress, seg.length, tokenFactory(), value)
        } else {
            throw NotImplementedError()
        }
    }
    fun tryGetSubTable(fieldName: String, table: Ref<ModelTable?>): Boolean { /*@DONE ModelArrayElement.TryGetSubTable/1 cs:347-350*/
        table.value = getSubTable(fieldName)
        return table.value != null
    }
    fun getSubTable(fieldName: String): ModelTable? { /*@DONE ModelArrayElement.GetSubTable/1 cs:352-374*/
        val model = _model
        val elementOffset = table.elementContent.until { segment -> segment.name == fieldName }.sumOf { segment -> segment.length }
        val valueAddress = table.start + table.elementLength * arrayIndex + elementOffset
        if (valueAddress < 0 || valueAddress >= model.count) return null
        val seg = table.elementContent.firstOrNull { segment -> segment.name == fieldName } ?: return null
        if (seg is ArrayRunPointerSegment) {
            val destination = model.readPointer(valueAddress)
            if (destination < 0 || destination >= model.count) return null
            val childRef = Ref<ITableRun?>(null)
            var error = ArrayRun.tryParse(model, fieldName, seg.innerFormat, destination, SortedSpanStatic.one(valueAddress), table.elementContent, childRef)
            var childTable = childRef.value
            if (error.hasError) {
                childTable = model.getNextRun(destination) as? ITableRun
            }
            if (childTable == null) {
                // one last try, with validation turned off
                childRef.value = null
                error = ArrayRun.tryParse(model, fieldName, seg.innerFormat, destination, SortedSpanStatic.one(valueAddress), table.elementContent, false, childRef)
                childTable = childRef.value
                if (error.hasError) return null
            }
            return ModelTable(model, destination, tokenFactory, childTable)
        } else {
            return null // format didn't match expected, give up
        }
    }
    fun render(fieldName: String): ReadonlyPixelViewModel? { /*@DONE ModelArrayElement.Render/1 cs:379-385*/
        val model = _model
        if (arrayIndex < 0 || arrayIndex >= table.elementCount || !hasField(fieldName)) return null
        val address = getAddress(fieldName)
        val spriteRun = model.getNextRun(address) as? ISpriteRun ?: return null
        return ReadonlyPixelViewModel.create(model, spriteRun, start, true)
    }
    override fun tryGetMember(binder: GetMemberBinder, result: Ref<Any?>): Boolean { /*@DONE ModelArrayElement.TryGetMember/1 cs:389-397*/
        result.value = null
        val seg = table.elementContent.firstOrNull { segment -> segment.name == binder.name }
        if (seg == null) {
            throw IllegalArgumentException("Couldn't find a member named " + binder.name + ". Available members include: " + table.elementContent.joinToString(", ") { s -> s.name })
        }
        result.value = this[seg.name]
        return true
    }
    override fun trySetMember(binder: SetMemberBinder, value: Any?): Boolean { /*@DONE ModelArrayElement.TrySetMember/1 cs:399-404*/
        val seg = table.elementContent.firstOrNull { segment -> segment.name == binder.name }
        if (seg == null) return super.trySetMember(binder, value)
        this[seg.name] = value
        return true
    }
    override fun toString(): String { /*@DONE ModelArrayElement.ToString/1 cs:406-416*/
        val result = StringBuilder("{ ")
        var first = true
        for (seg in table.elementContent) {
            if (!first) result.append(", ")
            first = false
            result.append(seg.name + ": " + (this[seg.name] ?: ""))
        }
        result.append(" }")
        return result.toString()
    }
    /*@END ModelArrayElement*/
}

open class ModelTupleElement : DynamicObject { // cs:421-547
    private lateinit var model: IDataModel
    private lateinit var table: ITableRun
    private var arrayIndex: Int = 0
    private var segmentOffset: Int = 0
    private lateinit var tuple: ArrayRunTupleSegment
    private lateinit var tokenFactory: () -> ModelDelta
    constructor(model: IDataModel, table: ITableRun, arrayIndex: Int, segmentOffset: Int, tuple: ArrayRunTupleSegment, tokenFactory: () -> ModelDelta) { /*@DONE ModelTupleElement.<init>/1 cs:428-435*/
        this.model = model
        this.table = table
        this.arrayIndex = arrayIndex
        this.segmentOffset = segmentOffset
        this.tuple = tuple
        this.tokenFactory = tokenFactory
    }
    constructor(model: IDataModel, table: ITableRun, arrayIndex: Int, segmentOffset: Int, bits: ArrayRunBitArraySegment, tokenFactory: () -> ModelDelta) { /*@DONE ModelTupleElement.<init>/2 cs:437-446*/
        val contract = (bits.getOptions(model) ?: emptyList<String>()).map { option -> option + "." }.joinToString("|")

        this.model = model
        this.table = table
        this.arrayIndex = arrayIndex
        this.segmentOffset = segmentOffset
        this.tuple = ArrayRunTupleSegment(bits.name, contract, bits.length)
        this.tokenFactory = tokenFactory
    }
    operator fun get(fieldName: String): Any? { /*@DONE ModelTupleElement.this/1.get cs:449-455*/
        val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, fieldName).first()
        val tup = tuple.elements.first { seg -> seg.name == matchName }
        val value = getValue(tup)
        if (!tup.sourceName.isNullOrEmpty()) return getEnumValue(tup, value)
        return value
    }
    operator fun set(fieldName: String, value: Any?) { /*@DONE ModelTupleElement.this/1.set cs:456-464*/
        var v: Any? = value
        if (v is Boolean) v = if (v) 1 else 0
        if (v is String) {
            val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, fieldName).first()
            val tup = tuple.elements.first { seg -> seg.name == matchName }
            val result = Ref(0)
            if (tryConvertEnumTextToValue(tup, v, result)) v = result.value
        }
        setValue(fieldName, (v as Number).toInt())
    }
    val fieldCount: Int
        get() { /*@DONE ModelTupleElement.FieldCount.get cs:466-466*/
            return tuple.elements.size
        }
    fun hasField(name: String): Boolean { /*@DONE ModelTupleElement.HasField/1 cs:467-467*/
        return tuple.elements.any { field -> field.name == name }
    }
    fun getValue(fieldName: String): Int { /*@DONE ModelTupleElement.GetValue/1 cs:469-473*/
        val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, fieldName).first()
        val tup = tuple.elements.first { seg -> seg.name == matchName }
        return getValue(tup)
    }
    private fun getValue(tup: TupleSegment): Int { /*@DONE ModelTupleElement.GetValue/2 cs:475-480*/
        var start = table.start + table.elementLength * arrayIndex
        start += table.elementContent.until { seg -> seg.name == tuple.name }.sumOf { seg -> seg.length }
        val bitOffset = tuple.elements.until { seg -> seg === tup }.sumOf { seg -> seg.bitWidth }
        return tup.read(model, start, bitOffset)
    }
    fun getEnumValue(fieldName: String): String { /*@DONE ModelTupleElement.GetEnumValue/1 cs:482-487*/
        val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, fieldName).first()
        val tup = tuple.elements.first { seg -> seg.name == matchName }
        val value = getValue(tup)
        return getEnumValue(tup, value) ?: ""
    }
    private fun getEnumValue(tup: TupleSegment, value: Int): String? { /*@DONE ModelTupleElement.GetEnumValue/2 cs:489-493*/
        val options = ArrayRunEnumSegment.getOptions(model, tup.sourceName)
        if (value.inRange(0, options.size)) return options[value]
        return null
    }
    fun setValue(fieldName: String, value: Int) { /*@DONE ModelTupleElement.SetValue/1 cs:495-501*/
        val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, fieldName).first()
        val tup = tuple.elements.first { seg -> seg.name == matchName }
        val start = table.start + table.elementLength * arrayIndex + segmentOffset
        val bitOffset = tuple.elements.until { seg -> seg === tup }.sumOf { seg -> seg.bitWidth }
        tup.write(model, tokenFactory(), start, bitOffset, value)
    }
    private fun tryConvertEnumTextToValue(tup: TupleSegment, text: String, result: Ref<Int>): Boolean { /*@DONE ModelTupleElement.TryConvertEnumTextToValue/1 cs:503-511*/
        result.value = 0
        if (!tup.sourceName.isNullOrEmpty()) {
            val options = ArrayRunEnumSegment.getOptions(model, tup.sourceName)
            val option = ArrayRunEnumSegment.getBestOptions(options, text).firstOrNull()
            if (option != null) { result.value = options.indexOf(option); return true }
        }
        return false
    }
    override fun tryGetMember(binder: GetMemberBinder, result: Ref<Any?>): Boolean { /*@DONE ModelTupleElement.TryGetMember/1 cs:515-524*/
        result.value = null
        val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, binder.name).firstOrNull()
        val seg = tuple.elements.firstOrNull { segment -> segment.name == matchName }
        if (seg == null) {
            throw IllegalArgumentException("Couldn't find a member named " + binder.name + ". Available members include: " + table.elementContent.joinToString(", ") { s -> s.name })
        }
        result.value = this[seg.name]
        return true
    }
    override fun trySetMember(binder: SetMemberBinder, value: Any?): Boolean { /*@DONE ModelTupleElement.TrySetMember/1 cs:526-532*/
        val matchName = ArrayRunEnumSegment.getBestOptions(tuple.elements.map { element -> element.name }, binder.name).firstOrNull()
        if (matchName == null) return super.trySetMember(binder, value)
        val seg = tuple.elements.first { segment -> segment.name == matchName }
        this[seg.name] = value
        return true
    }
    override fun toString(): String { /*@DONE ModelTupleElement.ToString/1 cs:534-544*/
        val result = StringBuilder("{ ")
        var first = true
        for (seg in tuple.elements) {
            if (!first) result.append(", ")
            first = false
            result.append(seg.name + ": " + (this[seg.name] ?: ""))
        }
        result.append(" }")
        return result.toString()
    }
    /*@END ModelTupleElement*/
}

open class AnchorGroup : DynamicObject { // cs:549-587
    private lateinit var model: IDataModel
    private lateinit var tokenFactory: () -> ModelDelta
    private var header: String = ""
    constructor(model: IDataModel, tokenFactory: () -> ModelDelta, header: String) { /*@DONE AnchorGroup.<init>/1 cs:564-568*/
        this.model = model
        this.tokenFactory = tokenFactory
        this.header = header
    }
    override fun tryGetMember(binder: GetMemberBinder, result: Ref<Any?>): Boolean { /*@DONE AnchorGroup.TryGetMember/1 cs:570-586*/
        val name = header + "." + binder.name
        val address = model.getAddressFromAnchor(tokenFactory(), -1, name)
        val run = model.getNextRun(address)
        if (address < 0) {
            result.value = AnchorGroup(model, tokenFactory, name)
        } else if (run is ITableRun) {
            result.value = ModelTable(model, run, tokenFactory)
        } else if (run is EggMoveRun) {
            result.value = EggTable(model, tokenFactory, run)
        } else {
            // TODO not a table, but maybe something else (sprite, constant, text, etc)
            return super.tryGetMember(binder, result)
        }

        return true
    }
    companion object {
        fun getTopLevelAnchorGroups(model: IDataModel, tokenFactory: () -> ModelDelta): MutableMap<String, AnchorGroup> { /*@DONE AnchorGroup.GetTopLevelAnchorGroups/1 cs:554-562*/
            val topLevel = LinkedHashSet<String>()
            for (anchor in model.anchors) topLevel.add(anchor.split('.')[0])
            val results = LinkedHashMap<String, AnchorGroup>()
            for (top in topLevel) {
                results[top] = AnchorGroup(model, tokenFactory, top)
            }
            return results
        }
        /*@END AnchorGroup.Companion*/
    }
    /*@END AnchorGroup*/
}

open class EggTable : DynamicObject, ReadOnlyListMixin<EggElement> { // cs:589-615
    private lateinit var model: IDataModel
    private lateinit var tokenFactory: () -> ModelDelta
    private lateinit var eggRun: EggMoveRun
    override val size: Int
        get() { /*@DONE EggTable.Count.get cs:594-594*/
            return eggRun.length / 2
        }
    fun __len__(): Int { /*@DONE EggTable.__len__/1 cs:595-595*/
        return size
    }
    val run: EggMoveRun
        get() { /*@DONE EggTable.Run.get cs:597-597*/
            return eggRun
        }
    override operator fun get(value: Int): EggElement { /*@DONE EggTable.this/1.get cs:600-600*/
        return EggElement(model, eggRun.start + value * 2, tokenFactory, eggRun)
    }
    constructor(model: IDataModel, tokenFactory: (() -> ModelDelta)?, eggRun: EggMoveRun) { /*@DONE EggTable.<init>/1 cs:603-607*/
        this.model = model
        this.tokenFactory = tokenFactory ?: { NoDataChangeDeltaModel() }
        this.eggRun = eggRun
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END EggTable*/
}

open class EggElement : DynamicObject { // cs:617-652
    private lateinit var model: IDataModel
    private var _address: Int = 0
    private lateinit var tokenFactory: () -> ModelDelta
    private lateinit var eggRun: EggMoveRun
    val is_pokemon: Boolean
        get() { /*@DONE EggElement.is_pokemon.get cs:623-623*/
            return eggRun.createDataFormat(model, _address) is EggSection
        }
    val is_move: Boolean
        get() { /*@DONE EggElement.is_move.get cs:624-624*/
            return eggRun.createDataFormat(model, _address) is EggItem
        }
    val address: Int
        get() { /*@DONE EggElement.Address.get cs:625-625*/
            return _address
        }
    constructor(model: IDataModel, address: Int, tokenFactory: () -> ModelDelta, eggRun: EggMoveRun) { /*@DONE EggElement.<init>/1 cs:627-627*/
        this.model = model
        this._address = address
        this.tokenFactory = tokenFactory
        this.eggRun = eggRun
    }
    var name: String
        get() { /*@DONE EggElement.name.get cs:630-635*/
            val format = eggRun.createDataFormat(model, _address)
            if (format is EggSection) return format.sectionName.trim('[', ']')
            if (format is EggItem) return format.itemName
            throw NotImplementedError()
        }
        set(value) { /*@DONE EggElement.name.set cs:636-650*/
            val preferPokemon = value.startsWith("[") || value.endsWith("]")
            val trimmed = value.trim('[', ']')
            val pokeOptions = model.getOptions(HardcodeTablesModel.pokemonNameTable)
            val moveOptions = model.getOptions(HardcodeTablesModel.moveNamesTable)
            val pokeMatches = trimmed.findMatches(pokeOptions)
            val moveMatches = trimmed.findMatches(moveOptions)
            if (moveMatches.size > 0 && !preferPokemon) {
                model.writeMultiByteValue(_address, 2, tokenFactory(), moveMatches[0])
            } else if (pokeMatches.size > 0) {
                model.writeMultiByteValue(_address, 2, tokenFactory(), pokeMatches[0] + EggMoveRun.magicNumber)
            } else {
                throw IllegalStateException("Could not convert " + trimmed + " to a move name or pokemon name.")
            }
        }
    /*@END EggElement*/
}
