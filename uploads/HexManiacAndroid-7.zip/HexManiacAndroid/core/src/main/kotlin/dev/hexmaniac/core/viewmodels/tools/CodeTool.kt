// Port of ViewModels/Tools/CodeTool.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.map.*

enum class CodeMode(val value: Int) { // cs:13-13
    Thumb(0),
    Script(1),
    BattleScript(2),
    AnimationScript(3),
    TrainerAiScript(4),
    Raw(5);
    companion object {
        fun fromValue(value: Int): CodeMode = entries.first { it.value == value }
    }
    /*@END CodeMode*/
}

open class CodeTool : ViewModelCore, IToolViewModel { // cs:15-577
    override val name: String
        get() { /*@DONE CodeTool.Name.get cs:16-16*/
            return "Code Tool"
        }
    private var _mode: CodeMode = CodeMode.Thumb
    private lateinit var singletons: Singletons
    private lateinit var thumb: ThumbParser
    private lateinit var script: ScriptParser
    private lateinit var battleScript: ScriptParser
    private lateinit var animationScript: ScriptParser
    private lateinit var battleAIScript: ScriptParser
    private lateinit var viewPort: ViewPort
    private lateinit var model: IDataModel
    private lateinit var selection: Selection
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var messageTab: IRaiseMessageTab
    private lateinit var recompileTimer: IDelayWorkTimer
    val modelDataChanged = Event<ErrorInfo>()
    val attentionNewContent = Event<EventArgs>()
    val isReadOnly: Boolean
        get() { /*@DONE CodeTool.IsReadOnly.get cs:32-32*/
            return mode == CodeMode.Raw
        }
    val useSingleContent: Boolean
        get() { /*@DONE CodeTool.UseSingleContent.get cs:33-33*/
            return !useMultiContent
        }
    val useMultiContent: Boolean
        get() { /*@DONE CodeTool.UseMultiContent.get cs:34-34*/
            return mode.isAny(CodeMode.Script, CodeMode.BattleScript, CodeMode.AnimationScript, CodeMode.TrainerAiScript)
        }
    var investigator: IDataInvestigator? = null
    private var _isSelected: Boolean = false
    var isSelected: Boolean
        get() { /*@DONE CodeTool.IsSelected.get cs:39-39*/
            return _isSelected
        }
        set(value) { /*@DONE CodeTool.IsSelected.set cs:39-39*/
            set(_isSelected, value, "isSelected", { _isSelected = it }) { _ -> updateContent() }
        }
    private var _insertAutoActive: Boolean = /*@INITAUTO CodeTool.insertAutoActive cs:41-41*/ true /*@ENDINIT*/
    var insertAutoActive: Boolean
        get() { /*@DONE CodeTool.InsertAutoActive.get cs:42-42*/
            return _insertAutoActive
        }
        set(value) { /*@DONE CodeTool.InsertAutoActive.set cs:42-42*/
            tryUpdate(_insertAutoActive, value, "insertAutoActive", { _insertAutoActive = it })
        }
    private var _showErrorText: Boolean = false
    var showErrorText: Boolean
        get() { /*@DONE CodeTool.ShowErrorText.get cs:45-45*/
            return _showErrorText
        }
        private set(value) { /*@DONE CodeTool.ShowErrorText.set cs:45-45*/
            tryUpdate(_showErrorText, value, "showErrorText", { _showErrorText = it })
        }
    private var _errorText: String? = ""
    var errorText: String?
        get() { /*@DONE CodeTool.ErrorText.get cs:48-48*/
            return _errorText
        }
        private set(value) { /*@DONE CodeTool.ErrorText.set cs:48-48*/
            tryUpdate(_errorText, value, "errorText", { _errorText = it })
        }
    private var _fontSize: Int = /*@INITAUTO CodeTool.fontSize cs:50-50*/ 12 /*@ENDINIT*/
    var fontSize: Int
        get() { /*@DONE CodeTool.FontSize.get cs:51-51*/
            return _fontSize
        }
        set(value) { /*@DONE CodeTool.FontSize.set cs:51-51*/
            tryUpdate(_fontSize, value, "fontSize", { _fontSize = it })
        }
    var mode: CodeMode
        get() { /*@DONE CodeTool.Mode.get cs:54-54*/
            return _mode
        }
        set(value) { /*@DONE CodeTool.Mode.set cs:55-61*/
            if (!tryUpdate(_mode, value, "mode", { _mode = it })) return
            updateContent()
            notifyPropertyChanged("isReadOnly")
            notifyPropertyChanged("useSingleContent")
            notifyPropertyChanged("useMultiContent")
        }
    var editor: TextEditorViewModel = /*@INITDONE CodeTool.Editor cs:64-64*/ TextEditorViewModel() /*@ENDINIT*/
        private set
    var content: String
        get() { /*@DONE CodeTool.Content.get cs:67-67*/
            return editor.content
        }
        set(value) { /*@DONE CodeTool.Content.set cs:68-72*/
            if (ignoreContentUpdates) return
            if (editor.content != value) editor.content = value
            else compileChanges()
        }
    var contents: ObservableCollection<CodeBody> = /*@INITAUTO CodeTool.Contents cs:75-75*/ ObservableCollection() /*@ENDINIT*/
        private set
    val parser: ThumbParser
        get() { /*@DONE CodeTool.Parser.get cs:77-77*/
            return thumb
        }
    val scriptParser: ScriptParser
        get() { /*@DONE CodeTool.ScriptParser.get cs:79-79*/
            return script
        }
    val battleScriptParser: ScriptParser
        get() { /*@DONE CodeTool.BattleScriptParser.get cs:81-81*/
            return battleScript
        }
    val animationScriptParser: ScriptParser
        get() { /*@DONE CodeTool.AnimationScriptParser.get cs:83-83*/
            return animationScript
        }
    val battleAIScriptParser: ScriptParser
        get() { /*@DONE CodeTool.BattleAIScriptParser.get cs:85-85*/
            return battleAIScript
        }
    val modelDataMoved = Event<CodeToolModelDataMovedTuple>()
    private var _isEventScript: StubCommand? = null
    val isEventScript: ICommand
        get() { /*@DONE CodeTool.IsEventScript.get cs:90-90*/
            return _isEventScript ?: stubCommand({ executeIsEventScript() }).also { _isEventScript = it }
        }
    private fun executeIsEventScript() { /*@DONE CodeTool.ExecuteIsEventScript/1 cs:91-94*/
        val searchPoint = selection.scroll.viewPointToDataIndex(selection.selectionStart)
        scriptParser.formatScript<XSERun>(history.currentChange, model, searchPoint)
    }
    var singleBoxVerticalOffset: Double = 0.0
    var multiBoxVerticalOffset: Double = 0.0
    constructor(singletons: Singletons, viewPort: ViewPort, selection: Selection, history: ChangeHistory<ModelDelta>, messageTab: IRaiseMessageTab) { /*@DONE CodeTool.<init>/1 cs:100-128*/
        this.singletons = singletons
        recompileTimer = singletons.workDispatcher!!.createDelayTimer()
        val gameHash = viewPort.model.getShortGameCode()
        thumb = ThumbParser(singletons)
        script = ScriptParser(gameHash, singletons.scriptLines, 0x02)
        battleScript = ScriptParser(gameHash, singletons.battleScriptLines, 0x3D)
        animationScript = ScriptParser(gameHash, singletons.animationScriptLines, 0x08)
        battleAIScript = ScriptParser(gameHash, singletons.battleAIScriptLines, 0x5A)
        this.viewPort = viewPort
        this.model = viewPort.model
        this.selection = selection
        this.history = history
        this.messageTab = messageTab
        selection.propertyChanged += { _, e ->
            if (e.propertyName == "selectionStart") {
                if (selection.selectionStart == selection.selectionEnd) updateContent()
            } else if (e.propertyName == "selectionEnd") {
                updateContent()
            }
        }

        setupThumbKeywords(singletons)
        editor.bind("content") { _, _ ->
            if (!ignoreContentUpdates) {
                notifyPropertyChanged("content")
                compileChanges()
            }
        }
    }
    private fun setupThumbKeywords(singletons: Singletons) { /*@DONE CodeTool.SetupThumbKeywords/1 cs:130-149*/
        editor.lineCommentHeader = "@"
        editor.multiLineCommentHeader = "/*"
        editor.multiLineCommentFooter = "*/"

        editor.keywords.clear()
        val set = LinkedHashSet<String>()
        for (template in singletons.thumbInstructionTemplates) {
            if (template is Instruction) {
                set.add(template.operator)
            }
        }
        set.addAll(listOf(".word", ".byte", ".hword", ".align"))
        set.addAll("beq bne bhs blo bcs bcc bmi bpl bvs bvc bhi bls bge blt bgt ble bal bnv".split(' '))
        for (keyword in set) editor.keywords.add(keyword)

        editor.constants.clear()
        for (i in 0..15) editor.constants.add("r" + i)
        for (constant in listOf("lr", "sp", "pc")) editor.constants.add(constant)
    }
    override fun dataForCurrentRunChanged() { /*@DONE CodeTool.DataForCurrentRunChanged/1 cs:151-151*/
        updateContent()
    }
    fun updateContent() { /*@DONE CodeTool.UpdateContent/1 cs:153-189*/
        if (ignoreContentUpdates || !_isSelected) return
        var start = Math.min(model.count - 1, selection.scroll.viewPointToDataIndex(selection.selectionStart))
        var end = Math.min(model.count - 1, selection.scroll.viewPointToDataIndex(selection.selectionEnd))

        if (start > end) {
            val swap = start
            start = end
            end = swap
        }
        val length = end - start + 1

        val guard = scope(ignoreContentUpdates, true, { ignoreContentUpdates = it }) { old -> ignoreContentUpdates = old }
        try {
            if (length > 0x1000) {
                editor.content = "Too many bytes selected."
                notifyPropertyChanged("content")
            } else if (_mode == CodeMode.Raw) {
                editor.content = rawParse(model, start, end - start + 1)
                notifyPropertyChanged("content")
            } else if (length < 2 && _mode == CodeMode.Thumb) {
                editor.content = ""
                notifyPropertyChanged("content")
                updateContents(-1, null)
                canRepointThumb = calculateCanRepointThumb()
            } else if (_mode == CodeMode.Script) {
                updateContents(start, script)
            } else if (_mode == CodeMode.BattleScript) {
                updateContents(start, battleScript)
            } else if (_mode == CodeMode.AnimationScript) {
                updateContents(start, animationScript)
            } else if (_mode == CodeMode.TrainerAiScript) {
                updateContents(start, battleAIScript)
            } else if (_mode == CodeMode.Thumb) {
                editor.content = thumb.parse(model, start, end - start + 1)
                notifyPropertyChanged("content")
                canRepointThumb = calculateCanRepointThumb()
            } else {
                throw UnsupportedOperationException("Unknown code mode.")
            }
        } finally {
            guard.dispose()
        }
    }
    fun clearConstantCache() { /*@DONE CodeTool.ClearConstantCache/1 cs:191-196*/
        script.clearConstantCache()
        battleScript.clearConstantCache()
        animationScript.clearConstantCache()
        battleAIScript.clearConstantCache()
    }
    private fun calculateCanRepointThumb(): Boolean { /*@DONE CodeTool.CalculateCanRepointThumb/1 cs:200-206*/
        var left = selection.scroll.viewPointToDataIndex(selection.selectionStart)
        var right = selection.scroll.viewPointToDataIndex(selection.selectionEnd)
        if (left > right) {
            val swap = left
            left = right
            right = swap
        }
        val length = right - left + 1
        return parser.canRepoint(model, left, length) != -1
    }
    private var _canRepointThumb: Boolean = false
    var canRepointThumb: Boolean
        get() { /*@DONE CodeTool.CanRepointThumb.get cs:209-209*/
            return _canRepointThumb
        }
        private set(value) { /*@DONE CodeTool.CanRepointThumb.set cs:209-209*/
            set(_canRepointThumb, value, "canRepointThumb", { _canRepointThumb = it })
        }
    fun repointThumb() { /*@DONE CodeTool.RepointThumb/1 cs:211-222*/
        var left = selection.scroll.viewPointToDataIndex(selection.selectionStart)
        var right = selection.scroll.viewPointToDataIndex(selection.selectionEnd)
        if (left > right) {
            val swap = left
            left = right
            right = swap
        }
        val register = parser.canRepoint(model, left, right - left + 1)
        if (register != -1) {
            val newAddress = parser.repoint(history.currentChange, model, left, register)
            messageTab.raiseMessage("Thumb code repointed to " + newAddress.toHex(6))
            selection.goto?.execute(newAddress)
            selection.selectionEnd = selection.scroll.dataIndexToViewPoint(newAddress + 0x13)
        }
    }
    private fun updateContents(start: Int, parser: ScriptParser?, currentScriptStart: Int = -1, currentScriptLength: Int = -1) { /*@DONE CodeTool.UpdateContents/1 cs:232-294*/
        if (currentScriptStart == -1) {
            showErrorText = false
            errorText = ""
        }

        val scripts: List<Int> = parser?.collectScripts(model, start) ?: ArrayList<Int>()
        var skippedScripts = 0
        val existingSectionCount = Ref(0)
        for (i in 0 until scripts.size) {
            val activeParser = parser!!
            val scriptStart = scripts[i]
            if (scriptStart == currentScriptStart && contents.size > i && contents[i].address == scriptStart) {
                model.currentCacheScope.getScriptInfo(activeParser, scriptStart, null, existingSectionCount) // mostly to update existingSectionCount
                continue
            }
            if (currentScriptStart < scriptStart && scriptStart < currentScriptStart + currentScriptLength) {
                // this script is included inside the current under-edit script
                // it doesn't need its own content
                skippedScripts += 1
                continue
            }

            val label = scriptStart.toHex(6)
            val body: CodeBody
            if (contents.size > i && contents[i].parser === activeParser) {
                body = contents[i]
            } else {
                body = CodeBody(model, activeParser, investigator)
                body.address = scriptStart
                body.label = label
                activeParser.addKeywords(model, body)
            }

            val info = model.currentCacheScope.getScriptInfo(activeParser, scriptStart, body, existingSectionCount)
            var needsAnimation = false

            if (contents.size > i) {
                body.contentChanged -= scriptChangedHandler
                body.helpSourceChanged -= helpSourceChangedHandler
                body.content = ""
                body.content = info.content
                body.address = scriptStart
                body.compiledLength = info.length
                body.label = label
                body.helpSourceChanged += helpSourceChangedHandler
                body.contentChanged += scriptChangedHandler
                contents[i] = body
            } else {
                body.compiledLength = info.length
                body.content = info.content
                body.contentChanged += scriptChangedHandler
                body.helpSourceChanged += helpSourceChangedHandler
                body.requestShowSearchResult += showSearchResultsHandler
                contents.add(body)
                needsAnimation = currentScriptLength != -1
            }

            if (needsAnimation) attentionNewContent(this, EventArgs.empty)
        }

        while (contents.size > scripts.size - skippedScripts) {
            contents[contents.size - 1].contentChanged -= scriptChangedHandler
            contents.removeAt(contents.size - 1)
        }
    }
    private fun scriptChanged(viewModel: Any?, e: ExtendedPropertyChangedEventArgs<String>) { /*@DONE CodeTool.ScriptChanged/1 cs:296-368*/
        val parser: ScriptParser? = when (_mode) {
            CodeMode.Script -> script
            CodeMode.BattleScript -> battleScript
            CodeMode.AnimationScript -> animationScript
            CodeMode.TrainerAiScript -> battleAIScript
            else -> null
        }
        val body = viewModel as CodeBody
        body.tryCompleteCommandToken()
        if (insertAutoActive && body.tryInsertAuto()) {
            // update the caret later, or weird stuff happens
            val dispatcher = singletons.workDispatcher
            if (dispatcher != null) {
                dispatcher.dispatchWork { dispatcher.blockOnUIWork { body.editor.caretIndex += 6 } }
            }
        }
        if (insertAutoActive) body.tryInsertAuto()
        val delta = body.content.length - e.oldValue.length
        val deltaSize = Math.abs(delta)
        if (body.caretPosition >= deltaSize && body.caretPosition < body.content.length - deltaSize) {
            var start = body.content.substring(0, body.caretPosition + delta)
            if (start.endsWith("<auto>")) insertAutoActive = true
            start = body.content.substring(0, body.caretPosition + delta)
            if (start.endsWith("<auto")) insertAutoActive = false
        }

        val codeContent = Ref(body.content)

        var run = model.getNextRun(body.address)
        if (run != null && run.start != body.address) run = null

        if (parser == null) return
        var length = parser.findLength(model, body.address)
        val action: () -> Unit = {
            var initialStart = selection.scroll.viewPointToDataIndex(selection.selectionStart)
            var initialEnd = selection.scroll.viewPointToDataIndex(selection.selectionEnd)
            if (initialStart > initialEnd) {
                val swap = initialStart
                initialStart = initialEnd
                initialEnd = swap
            }

            if (_mode == CodeMode.Script) {
                compileScriptChanges(XSERun::class.java, body, run, codeContent, e.oldValue, parser, body === contents[0])
            } else if (_mode == CodeMode.AnimationScript) {
                compileScriptChanges(ASERun::class.java, body, run, codeContent, e.oldValue, parser, body === contents[0])
            } else if (_mode == CodeMode.BattleScript) {
                compileScriptChanges(BSERun::class.java, body, run, codeContent, e.oldValue, parser, body === contents[0])
            } else if (_mode == CodeMode.TrainerAiScript) {
                compileScriptChanges(TSERun::class.java, body, run, codeContent, e.oldValue, parser, body === contents[0])
            }

            body.contentChanged -= scriptChangedHandler
            body.helpSourceChanged -= helpSourceChangedHandler
            body.content = codeContent.value
            body.helpSourceChanged += helpSourceChangedHandler
            body.contentChanged += scriptChangedHandler

            // reload
            var start = Math.min(model.count - 1, selection.scroll.viewPointToDataIndex(selection.selectionStart))
            var end = Math.min(model.count - 1, selection.scroll.viewPointToDataIndex(selection.selectionEnd))
            if (start > end) {
                val swap = start
                start = end
                end = swap
            }
            if (initialStart == body.address) {
                length = end - start + 1
                body.address = start // in case of the code getting repointed
            }
            updateContents(start, parser, body.address, length)
        }

        // don't need to run this if they're still typing
        body.caretPosition += ScriptParser.insertMissingClosers(codeContent, body.caretPosition)
        body.content = codeContent.value
        recompileTimer.delayCall(TimeSpan.fromSeconds(0.5), action)
    }
    private fun updateScriptHelpFromLine(sender: Any?, context: HelpContext) { /*@DONE CodeTool.UpdateScriptHelpFromLine/1 cs:370-379*/
        val codeBody = sender as CodeBody
        val help: String?
        if (_mode == CodeMode.Script) help = scriptParser.getHelp(model, codeBody, context)
        else if (_mode == CodeMode.BattleScript) help = battleScriptParser.getHelp(model, codeBody, context)
        else if (_mode == CodeMode.AnimationScript) help = animationScriptParser.getHelp(model, codeBody, context)
        else if (_mode == CodeMode.TrainerAiScript) help = battleAIScriptParser.getHelp(model, codeBody, context)
        else throw UnsupportedOperationException("Help is only available for script modes.")
        codeBody.helpContent = help ?: ""
    }
    private fun showSearchResults(sender: Any?, results: MutableSet<CodeBodyRequestShowSearchResultTuple>) { /*@DONE CodeTool.ShowSearchResults/1 cs:381-383*/
        viewPort.openSearchResultsTab("Script Search Results", results.map { r -> ViewPortOpenSearchResultsTabShowSelectionTuple(r.item1, r.item2) })
    }
    private fun compileChanges() { /*@DONE CodeTool.CompileChanges/1 cs:385-389*/
        val cacheScope = ModelCacheScope.createScope(model)
        try {
            if (_mode == CodeMode.Thumb) compileThumbChanges()
        } finally {
            cacheScope.dispose()
        }
    }
    private fun compileThumbChanges() { /*@DONE CodeTool.CompileThumbChanges/1 cs:391-422*/
        var start = Math.min(model.count - 1, selection.scroll.viewPointToDataIndex(selection.selectionStart))
        var end = Math.min(model.count - 1, selection.scroll.viewPointToDataIndex(selection.selectionEnd))
        if (start > end) {
            val swap = start
            start = end
            end = swap
        }
        var length = end - start + 1
        val originalLength = length
        val newRuns = Ref<List<IFormattedRun>?>(null)
        val lines = content.split("\r\n", "\n")
        val code = thumb.compile(model, start, newRuns, *lines.toTypedArray())

        // if more length is needed and the next available bytes are free, allow it.
        while (code.count > length && model.count > start + length + 1 && model[start + length] == 0xFF && model[start + length + 1] == 0xFF) length += 2

        if (code.count > length) {
            errorText = "Thumb compiled to " + code.count + " bytes, but only " + length + " bytes are available."
            showErrorText = true
            return
        }
        showErrorText = false

        model.clearFormat(history.currentChange, start + 1, length - 1)
        for (i in 0 until code.count) history.currentChange.changeData(model, start + i, code[i])
        for (i in code.count until length) history.currentChange.changeData(model, start + i, 0xFF)
        for (run in newRuns.value ?: ArrayList<IFormattedRun>()) model.observeRunWritten(history.currentChange, run)

        modelDataChanged(this, ErrorInfo.noError)

        if (length > originalLength) {
            val guard = createRecursionGuard()
            try {
                selection.selectionStart = selection.scroll.dataIndexToViewPoint(start)
                selection.selectionEnd = selection.scroll.dataIndexToViewPoint(start + length - 1)
            } finally {
                guard.dispose()
            }
        }
    }
    private fun construct(runType: Class<*>, start: Int, sources: SortedSpan<Int>?): IScriptStartRun { /*@DONE CodeTool.Construct/1 cs:424-430*/
        if (runType == XSERun::class.java) return XSERun(start, sources)
        if (runType == ASERun::class.java) return ASERun(start, sources)
        if (runType == BSERun::class.java) return BSERun(start, sources)
        if (runType == TSERun::class.java) return TSERun(start, sources)
        throw UnsupportedOperationException("Unknown script run type.")
    }
    private var ignoreContentUpdates: Boolean = false
    private fun createRecursionGuard(): IDisposable { /*@DONE CodeTool.CreateRecursionGuard/1 cs:433-437*/
        if (ignoreContentUpdates) return StubDisposable { }
        ignoreContentUpdates = true
        return StubDisposable { ignoreContentUpdates = false }
    }
    private fun compileScriptChanges(runType: Class<*>, body: CodeBody, run: IFormattedRun?, codeContent: Ref<String>, previousText: String, parser: ScriptParser, updateSelection: Boolean) { /*@DONE CodeTool.CompileScriptChanges/1 cs:439-564*/
        showErrorText = false
        errorText = ""
        var currentRun = run
        var sources = run?.pointerSources
        var start = body.address
        val length = body.compiledLength

        val guard = createRecursionGuard()
        try {
            val oldScripts = parser.collectScripts(model, start)
            val originalCodeContent = codeContent.value
            val caret = Ref(body.caretPosition)
            body.clearErrors()
            body.evaluateTextLength()
            val movedDataRef = Ref<List<ScriptParserCompileMovedDataTuple>?>(null)
            val ignoreCharacterCount = Ref(0)
            val errorHandler: (Any?, ScriptErrorInfo) -> Unit = { s, info -> body.watchForCompileErrors(s, info) }
            parser.compileError += errorHandler
            var code: ByteArray? = parser.compile(history.currentChange, model, start, codeContent, caret, body, movedDataRef, ignoreCharacterCount)
            parser.compileError -= errorHandler
            if (originalCodeContent != codeContent.value) body.editor.caretIndex = caret.value + codeContent.value.length - previousText.length - ignoreCharacterCount.value
            if (code == null) {
                return
            }

            if (code.size > length) {
                model.expandData(history.currentChange, start + code.size - 1)
                selection.scroll.dataLength = model.rawData.size
                if (currentRun == null) {
                    var availableLength = length
                    var i = start + length
                    while (i < start + code.size) {
                        // if it's freespace, then it's available
                        if (model[i] == 0xFF) {
                            availableLength++
                            i++
                            continue
                        }
                        val nextRun = model.getNextRun(i)
                        if (nextRun is IScriptStartRun && nextRun.start == i) {
                            // the next byte is a script... maybe it's ok to overwrite it
                            // we can overwrite it if it passes 2 checks
                            // (1) the only pointers to that script are contained within the script we're currently compiling
                            // (2) the script is contained completely within the compiled code (meaning it's actually part of the script as written)
                            val nextSources = nextRun.pointerSources
                            if (nextSources == null || nextSources.all { source -> start < source && source < start + length }) {
                                val scriptLength = parser.findLength(model, nextRun.start, model.currentCacheScope.scriptDestinations(start))
                                if (i + scriptLength <= start + code.size) {
                                    i += scriptLength - 1
                                    availableLength += scriptLength
                                    i++
                                    continue
                                }
                            }
                        }
                        errorText = "Script is " + code.size + " bytes long, but only " + availableLength + " bytes are available."
                        showErrorText = true
                        return
                    }
                } else {
                    if (currentRun is NoInfoRun) currentRun = construct(runType, currentRun.start, currentRun.pointerSources)
                    currentRun = model.relocateForExpansion(history.currentChange, currentRun, body.compiledLength, code.size)
                    if (start != currentRun.start) {
                        modelDataMoved(this, CodeToolModelDataMovedTuple(start, currentRun.start))
                        start = currentRun.start
                        val changedCaret = Ref(body.caretPosition)
                        code = parser.compile(history.currentChange, model, start, codeContent, changedCaret, body, movedDataRef, Ref(0)) // recompile for the new location. Could update pointers.
                        if (code == null) return
                        // assume that changedCaret == body.CaretPosition? But it's probably not important
                        sources = currentRun.pointerSources
                    }
                }
            }

            // pre-clear the format before we change the data
            // waiting beyond this point won't clear anchors correctly, since pointer values will be changed
            var changeStart = code.size
            for (i in 0 until code.size) {
                if (model[start + i] == (code[i].toInt() and 0xFF)) continue
                changeStart = Math.max(1, i) // changeStart should never be zero: we don't want to clear the script anchor
                break
            }
            if (changeStart < code.size) {
                // use a nodatachange token here: we want to keep bytes, not anchor names
                val change = history.insertCustomChange(NoDataChangeDeltaModel())
                model.clearFormat(change, start + changeStart, code.size - changeStart)
            }

            val anyChanges = history.currentChange.changeData(model, start, code.asByteList())
            if (anyChanges || body.compiledLength != code.size) {
                body.compiledLength = code.size
                model.clearFormatAndData(history.currentChange, start + code.size, length - code.size)
            }
            val formatted = parser.formatScriptImpl(runType, history.currentChange, model, start, code.size)
            if (sources != null) {
                for (source in sources) {
                    // skip the source if it's within one of the added scripts: it may have moved, and we've already added it.
                    if (formatted != null && formatted.any { kvp -> source.inRange(kvp.key, kvp.key + kvp.value) }) continue
                    val existingRun = model.getNextRun(source)
                    if (existingRun == null || existingRun.start > source || existingRun !is ITableRun) {
                        model.observeRunWritten(history.currentChange, PointerRun(source))
                    }
                }
            }

            // this change may have orphaned some existing scripts. Don't lose them!
            val newScripts = parser.collectScripts(model, start)
            val orphans = oldScripts.distinct().filter { s -> !newScripts.contains(s) }
            for (orphan in orphans) {
                val orphanRun = model.getNextRun(orphan)
                val orphanSources = orphanRun?.pointerSources
                if (orphanRun != null && orphanRun.start == orphan && (orphanSources == null || orphanSources.size == 0) && model.getAnchorFromAddress(-1, orphan).isNullOrEmpty()) {
                    parser.formatScriptImpl(runType, history.currentChange, model, orphan)
                    if (runType == XSERun::class.java) {
                        model.observeAnchorWritten(history.currentChange, "orphans.xse" + orphan.toHex(6), XSERun(orphan))
                    } else if (runType == BSERun::class.java) {
                        model.observeAnchorWritten(history.currentChange, "orphans.bse" + orphan.toHex(6), BSERun(orphan))
                    } else if (runType == ASERun::class.java) {
                        model.observeAnchorWritten(history.currentChange, "orphans.ase" + orphan.toHex(6), ASERun(orphan))
                    } else if (runType == TSERun::class.java) {
                        model.observeAnchorWritten(history.currentChange, "orphans.tse" + orphan.toHex(6), TSERun(orphan))
                    } else {
                        throw UnsupportedOperationException("Unknown script run type.")
                    }
                }
            }

            if (updateSelection) {
                selection.selectionStart = selection.scroll.dataIndexToViewPoint(start)
                selection.selectionEnd = selection.scroll.dataIndexToViewPoint(start + code.size - 1)
            }

            for (movedResource in movedDataRef.value ?: ArrayList<ScriptParserCompileMovedDataTuple>()) {
                modelDataMoved(this, CodeToolModelDataMovedTuple(movedResource.originalLocation, movedResource.newLocation))
            }
        } finally {
            guard.dispose()
        }

        modelDataChanged(this, ErrorInfo.noError)
    }
    private fun rawParse(model: IDataModel, start: Int, length: Int): String { /*@DONE CodeTool.RawParse/1 cs:566-576*/
        val builder = StringBuilder()
        var remaining = length
        var index = start
        while (remaining > 0) {
            builder.append(model[index].toHexString())
            builder.append(" ")
            remaining--
            index++
            if (index % 16 == 0) builder.append("\n")
        }
        return builder.toString()
    }
    /*@ADD CodeTool#codetool_a.txt*/
    private val scriptChangedHandler: (Any?, ExtendedPropertyChangedEventArgs<String>) -> Unit = { sender, e -> scriptChanged(sender, e) }
    private val helpSourceChangedHandler: (Any?, HelpContext) -> Unit = { sender, context -> updateScriptHelpFromLine(sender, context) }
    private val showSearchResultsHandler: (Any?, MutableSet<CodeBodyRequestShowSearchResultTuple>) -> Unit = { sender, results -> showSearchResults(sender, results) }
    /*@ENDADD CodeTool#codetool_a.txt*/
    /*@END CodeTool*/
}

open class CodeTextFormatter : ITextPreProcessor { // cs:579-594
    override fun format(content: String): Array<TextFormatting> { /*@DONE CodeTextFormatter.Format/1 cs:580-592*/
        val result = Array(content.length) { TextFormatting.None }
        var inText = false
        var inComment = false
        for (i in 0 until content.length) {
            if (inComment && content[i] == '\n') inComment = false
            if (content[i] == '#') inComment = true
            if (inComment) continue
            if (content[i] == '{') inText = true
            else if (content[i] == '}') inText = false
            else if (inText) result[i] = TextFormatting.Text
        }
        return result
    }
    override fun findErrors(content: String): Iterable<TextSegment> { /*@DONE CodeTextFormatter.FindErrors/1 cs:593-593*/
        return emptyList()
    }
    /*@END CodeTextFormatter*/
}

data class HelpContext(val line: String, val index: Int, val contentBoundaryCount: Int = 0, val contentBoundaryIndex: Int = -1, val isSelection: Boolean = false) { // cs:596-596
    /*@END HelpContext*/
}

data class CodeToolModelDataMovedTuple(val originalLocation: Int, val newLocation: Int)
