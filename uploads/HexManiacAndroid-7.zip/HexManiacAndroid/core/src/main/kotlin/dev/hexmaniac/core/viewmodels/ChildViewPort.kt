// Port of ViewModels/ChildViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*

open class ChildViewPort : ViewPort, IChildViewPort { // cs:18-29
    final override var parent: IViewPort? = null
        private set
    constructor(viewPort: IViewPort, dispatcher: IWorkDispatcher, singletons: Singletons) : super(viewPort.fileName, viewPort.model!!, dispatcher, singletons, null, null, null, viewPort.changeHistory) { /*@DONE ChildViewPort.<init>/1 cs:21-26*/
        scrollRegion.deferHeader()
        parent = viewPort
        width = viewPort.width
        viewPort.model!!.referenceCount -= 1 // don't reference count child viewports
    }
    override fun refreshHeaders() { /*@DONE ChildViewPort.RefreshHeaders/1 cs:28-28*/
        scrollRegion.updateDeferedHeader()
    }
    /*@END ChildViewPort*/
}

open class CompositeChildViewPort : ArrayList<IChildViewPort>(), IChildViewPort { // cs:31-220
    override fun refreshHeaders() { /*@DONE CompositeChildViewPort.RefreshHeaders/1 cs:52-52*/
        this[0].refreshHeaders()
    }
    override operator fun get(x: Int, y: Int): HexElement { /*@DONE CompositeChildViewPort.this/1.get cs:76-76*/
        return this[0][x, y]
    }
    override val parent: IViewPort?
        get() { /*@DONE CompositeChildViewPort.Parent.get cs:78-78*/
            return this[0].parent
        }
    override var toolPanelWidth: Double = /*@INITAUTO CompositeChildViewPort.ToolPanelWidth cs:80-80*/ 500.0 /*@ENDINIT*/
    override val fileName: String
        get() { /*@DONE CompositeChildViewPort.FileName.get cs:82-82*/
            return this[0].fileName
        }
    override val fullFileName: String
        get() { /*@DONE CompositeChildViewPort.FullFileName.get cs:84-84*/
            return this[0].fullFileName
        }
    override var spartanMode: Boolean = false
    override var preferredWidth: Int
        get() { /*@DONE CompositeChildViewPort.PreferredWidth.get cs:88-88*/
            return this[0].preferredWidth
        }
        set(value) { /*@DONE CompositeChildViewPort.PreferredWidth.set cs:88-88*/
            for (child in this) child.preferredWidth = value
        }
    override var width: Int
        get() { /*@DONE CompositeChildViewPort.Width.get cs:89-89*/
            return this[0].width
        }
        set(value) { /*@DONE CompositeChildViewPort.Width.set cs:89-89*/
            for (child in this) child.width = value
        }
    override var height: Int
        get() { /*@DONE CompositeChildViewPort.Height.get cs:90-90*/
            return this[0].height
        }
        set(value) { /*@DONE CompositeChildViewPort.Height.set cs:90-90*/
            this[0].height = value
        }
    override var autoAdjustDataWidth: Boolean
        get() { /*@DONE CompositeChildViewPort.AutoAdjustDataWidth.get cs:91-91*/
            return this[0].autoAdjustDataWidth
        }
        set(value) { /*@DONE CompositeChildViewPort.AutoAdjustDataWidth.set cs:91-91*/
            for (child in this) child.autoAdjustDataWidth = value
        }
    override var stretchData: Boolean
        get() { /*@DONE CompositeChildViewPort.StretchData.get cs:92-92*/
            return this[0].stretchData
        }
        set(value) { /*@DONE CompositeChildViewPort.StretchData.set cs:92-92*/
            for (child in this) child.stretchData = value
        }
    override var allowMultipleElementsPerLine: Boolean
        get() { /*@DONE CompositeChildViewPort.AllowMultipleElementsPerLine.get cs:93-93*/
            return this[0].allowMultipleElementsPerLine
        }
        set(value) { /*@DONE CompositeChildViewPort.AllowMultipleElementsPerLine.set cs:93-93*/
            for (child in this) child.allowMultipleElementsPerLine = value
        }
    override var useCustomHeaders: Boolean
        get() { /*@DONE CompositeChildViewPort.UseCustomHeaders.get cs:94-94*/
            return this[0].useCustomHeaders
        }
        set(value) { /*@DONE CompositeChildViewPort.UseCustomHeaders.set cs:94-94*/
            for (child in this) child.useCustomHeaders = value
        }
    override var base10Length: Boolean
        get() { /*@DONE CompositeChildViewPort.Base10Length.get cs:95-95*/
            return this[0].base10Length
        }
        set(value) { /*@DONE CompositeChildViewPort.Base10Length.set cs:95-95*/
            for (child in this) child.base10Length = value
        }
    override val minimumScroll: Int
        get() { /*@DONE CompositeChildViewPort.MinimumScroll.get cs:97-97*/
            return this[0].minimumScroll
        }
    override var scrollValue: Int
        get() { /*@DONE CompositeChildViewPort.ScrollValue.get cs:99-99*/
            return this[0].scrollValue
        }
        set(value) { /*@DONE CompositeChildViewPort.ScrollValue.set cs:99-99*/
            for (child in this) child.scrollValue = value
        }
    override val maximumScroll: Int
        get() { /*@DONE CompositeChildViewPort.MaximumScroll.get cs:101-101*/
            return this[0].maximumScroll
        }
    override val headers: ObservableCollection<RowHeader>?
        get() { /*@DONE CompositeChildViewPort.Headers.get cs:103-103*/
            return this[0].headers
        }
    override val columnHeaders: ObservableCollection<ColumnHeaderRow>
        get() { /*@DONE CompositeChildViewPort.ColumnHeaders.get cs:105-105*/
            return this[0].columnHeaders
        }
    override val dataOffset: Int
        get() { /*@DONE CompositeChildViewPort.DataOffset.get cs:107-107*/
            return this[0].dataOffset
        }
    override val scroll: ICommand
        get() { /*@DONE CompositeChildViewPort.Scroll.get cs:109-109*/
            return this[0].scroll
        }
    override val progress: Double
        get() { /*@DONE CompositeChildViewPort.Progress.get cs:111-111*/
            return this[0].progress
        }
    override val updateInProgress: Boolean
        get() { /*@DONE CompositeChildViewPort.UpdateInProgress.get cs:113-113*/
            return this[0].updateInProgress
        }
    override var selectedAddress: String
        get() { /*@DONE CompositeChildViewPort.SelectedAddress.get cs:115-115*/
            return this[0].selectedAddress
        }
        set(value) { /*@DONE CompositeChildViewPort.SelectedAddress.set cs:115-115*/
            this[0].selectedAddress = value
        }
    override val selectedBytes: String?
        get() { /*@DONE CompositeChildViewPort.SelectedBytes.get cs:117-117*/
            return this[0].selectedBytes
        }
    override val anchorText: String
        get() { /*@DONE CompositeChildViewPort.AnchorText.get cs:119-119*/
            return this[0].anchorText
        }
    override val anchorTextVisible: Boolean
        get() { /*@DONE CompositeChildViewPort.AnchorTextVisible.get cs:121-121*/
            return this[0].anchorTextVisible
        }
    override val model: IDataModel?
        get() { /*@DONE CompositeChildViewPort.Model.get cs:123-123*/
            return this[0].model
        }
    override fun modelFor(p: Point): IDataModel? { /*@DONE CompositeChildViewPort.ModelFor/1 cs:124-124*/
        return this[0].modelFor(p)
    }
    override val hasTools: Boolean
        get() { /*@DONE CompositeChildViewPort.HasTools.get cs:126-126*/
            return this[0].hasTools
        }
    override val changeHistory: ChangeHistory<ModelDelta>
        get() { /*@DONE CompositeChildViewPort.ChangeHistory.get cs:128-128*/
            return this[0].changeHistory
        }
    override val tools: IToolTrayViewModel?
        get() { /*@DONE CompositeChildViewPort.Tools.get cs:130-130*/
            return this[0].tools
        }
    override val name: String
        get() { /*@DONE CompositeChildViewPort.Name.get cs:132-132*/
            return this[0].name
        }
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE CompositeChildViewPort.IsMetadataOnlyChange.get cs:134-134*/
            return false
        }
    override var findBytes: ByteArray? = null
    override val save: ICommand?
        get() { /*@DONE CompositeChildViewPort.Save.get cs:138-138*/
            return this[0].save
        }
    override val saveAs: ICommand
        get() { /*@DONE CompositeChildViewPort.SaveAs.get cs:140-140*/
            return this[0].saveAs
        }
    override val exportBackup: ICommand
        get() { /*@DONE CompositeChildViewPort.ExportBackup.get cs:142-142*/
            return this[0].exportBackup
        }
    override val undo: ICommand
        get() { /*@DONE CompositeChildViewPort.Undo.get cs:144-144*/
            return this[0].undo
        }
    override val redo: ICommand
        get() { /*@DONE CompositeChildViewPort.Redo.get cs:146-146*/
            return this[0].redo
        }
    override val copy: ICommand?
        get() { /*@DONE CompositeChildViewPort.Copy.get cs:148-148*/
            return this[0].copy
        }
    override val deepCopy: ICommand
        get() { /*@DONE CompositeChildViewPort.DeepCopy.get cs:150-150*/
            return this[0].deepCopy
        }
    override val diff: ICommand
        get() { /*@DONE CompositeChildViewPort.Diff.get cs:152-152*/
            return this[0].diff
        }
    override val diffLeft: ICommand
        get() { /*@DONE CompositeChildViewPort.DiffLeft.get cs:153-153*/
            return this[0].diffLeft
        }
    override val diffRight: ICommand
        get() { /*@DONE CompositeChildViewPort.DiffRight.get cs:154-154*/
            return this[0].diffRight
        }
    override val selectAll: ICommand
        get() { /*@DONE CompositeChildViewPort.SelectAll.get cs:156-156*/
            return this[0].selectAll
        }
    override val goto: ICommand?
        get() { /*@DONE CompositeChildViewPort.Goto.get cs:158-158*/
            return this[0].goto
        }
    override val resetAlignment: ICommand
        get() { /*@DONE CompositeChildViewPort.ResetAlignment.get cs:160-160*/
            return this[0].resetAlignment
        }
    override val back: ICommand
        get() { /*@DONE CompositeChildViewPort.Back.get cs:162-162*/
            return this[0].back
        }
    override val forward: ICommand
        get() { /*@DONE CompositeChildViewPort.Forward.get cs:164-164*/
            return this[0].forward
        }
    override val close: ICommand
        get() { /*@DONE CompositeChildViewPort.Close.get cs:166-166*/
            return this[0].close
        }
    override val clear: ICommand?
        get() { /*@DONE CompositeChildViewPort.Clear.get cs:168-168*/
            return this[0].clear
        }
    override val canDuplicate: Boolean
        get() { /*@DONE CompositeChildViewPort.CanDuplicate.get cs:169-169*/
            return false
        }
    override fun duplicate() { /*@DONE CompositeChildViewPort.Duplicate/1 cs:170-170*/
        // composite child views cannot be duplicated
    }
    override val previewScrollChanged = Event<EventArgs>()
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestCloseOtherViewports = Event<IDataModel>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE CompositeChildViewPort.CanIpsPatchRight.get cs:189-189*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE CompositeChildViewPort.CanUpsPatchRight.get cs:190-190*/
            return false
        }
    override fun ipsPatchRight() { /*@DONE CompositeChildViewPort.IpsPatchRight/1 cs:191-191*/
        // not supported
    }
    override fun upsPatchRight() { /*@DONE CompositeChildViewPort.UpsPatchRight/1 cs:192-192*/
        // not supported
    }
    override fun considerReload(fileSystem: IFileSystem) { /*@DONE CompositeChildViewPort.ConsiderReload/1 cs:194-194*/
        // the original throws NotImplementedException here; a child view never reloads, so do nothing
    }
    override fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort { /*@DONE CompositeChildViewPort.CreateChildView/1 cs:196-198*/
        throw NotImplementedError()
    }
    override fun expandSelection(x: Int, y: Int) { /*@DONE CompositeChildViewPort.ExpandSelection/1 cs:200-200*/
        for (child in this) child.expandSelection(x, y)
    }
    override fun find(search: String, matchExactCase: Boolean): List<IViewPortFindTuple> { /*@DONE CompositeChildViewPort.Find/1 cs:202-202*/
        return ArrayList()
    }
    override val canFindFreeSpace: Boolean
        get() { /*@DONE CompositeChildViewPort.CanFindFreeSpace.get cs:204-204*/
            return false
        }
    override fun findFreeSpace(fs: IFileSystem) { /*@DONE CompositeChildViewPort.FindFreeSpace/1 cs:205-205*/
        // not supported
    }
    override fun findAllSources(x: Int, y: Int) { /*@DONE CompositeChildViewPort.FindAllSources/1 cs:207-207*/
        // not supported
    }
    override fun followLink(x: Int, y: Int) { /*@DONE CompositeChildViewPort.FollowLink/1 cs:209-209*/
        // not supported
    }
    override fun getContextMenuItems(point: Point, fileSystem: IFileSystem?): List<IContextItem> { /*@DONE CompositeChildViewPort.GetContextMenuItems/1 cs:211-211*/
        return ArrayList()
    }
    override fun isSelected(point: Point): Boolean { /*@DONE CompositeChildViewPort.IsSelected/1 cs:213-213*/
        return this.any { child -> child.isSelected(point) }
    }
    override fun isTable(point: Point): Boolean { /*@DONE CompositeChildViewPort.IsTable/1 cs:215-215*/
        return this[0].isTable(point)
    }
    override fun refresh() { /*@DONE CompositeChildViewPort.Refresh/1 cs:217-217*/
        for (child in this) child.refresh()
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE CompositeChildViewPort.TryImport/1 cs:219-219*/
        return false
    }
    companion object {
        fun tryCombine(a: IChildViewPort, b: IChildViewPort, result: Ref<CompositeChildViewPort?>): Boolean { /*@DONE CompositeChildViewPort.TryCombine/1 cs:32-50*/
            result.value = null
            if (b is CompositeChildViewPort) return false
            val composite: CompositeChildViewPort = if (a is CompositeChildViewPort) a else CompositeChildViewPort().also { it.add(a) }
            result.value = composite
            if (a.parent !== b.parent) return false
            if (a.width != b.width) return false
            if (b.dataOffset < a.dataOffset) return false
            if ((b.dataOffset - a.dataOffset) % b.width != 0) return false
            val bSelectionLine = (getFirstVisibleSelectedAddress(b) - a.dataOffset) / b.width
            val aSelectionLine = (getLastVisibleSelectedAddress(a) - a.dataOffset) / b.width
            val lineDif = bSelectionLine - aSelectionLine
            if (lineDif > 3) return false
            a.height += lineDif
            b.scrollValue -= (b.dataOffset - a.dataOffset) / b.width
            b.height = a.height
            // Debug.Assert(a.dataOffset == b.dataOffset, "Data Offsets should be the same at this point!")
            composite.add(b)
            return true
        }
        fun getFirstVisibleSelectedAddress(viewPort: IViewPort): Int { /*@DONE CompositeChildViewPort.GetFirstVisibleSelectedAddress/1 cs:54-63*/
            for (y in 0 until viewPort.height) {
                for (x in 0 until viewPort.width) {
                    if (!viewPort.isSelected(Point(x, y))) continue
                    return viewPort.dataOffset + y * viewPort.width + x
                }
            }

            return -1
        }
        fun getLastVisibleSelectedAddress(viewPort: IViewPort): Int { /*@DONE CompositeChildViewPort.GetLastVisibleSelectedAddress/1 cs:65-74*/
            for (y in viewPort.height - 1 downTo 0) {
                for (x in viewPort.width - 1 downTo 0) {
                    if (!viewPort.isSelected(Point(x, y))) continue
                    return viewPort.dataOffset + y * viewPort.width + x
                }
            }

            return -1
        }
        /*@END CompositeChildViewPort.Companion*/
    }
    /*@END CompositeChildViewPort*/
}
