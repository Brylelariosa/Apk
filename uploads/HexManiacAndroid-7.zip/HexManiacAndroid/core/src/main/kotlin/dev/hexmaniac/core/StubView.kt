// Port of Core/StubView.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core

import dev.hexmaniac.core.system.*

open class StubView { // cs:11-68
    var propertyNotifications: MutableList<String> = /*@INITDONE StubView.PropertyNotifications cs:12-12*/ ArrayList() /*@ENDINIT*/
        private set
    var commandCanExecuteChangedNotifications: MutableList<String> = /*@INITDONE StubView.CommandCanExecuteChangedNotifications cs:13-13*/ ArrayList() /*@ENDINIT*/
        private set
    var eventNotifications: MutableList<String> = /*@INITDONE StubView.EventNotifications cs:14-14*/ ArrayList() /*@ENDINIT*/
        private set
    constructor(viewModel: INotifyPropertyChanged) { /*@DONE StubView.<init>/1 cs:15-57*/
        viewModel.propertyChanged += { sender, e -> collect(sender ?: this, e) }
        // The C# version also collects ICommand.CanExecuteChanged and every public event of the view model through reflection.
        // The JVM core has no reflection helpers (stdlib only): only property notifications are collected here;
        // tests that need event notifications subscribe to the events themselves.
    }
    private fun <T2> createNotifier(eventName: String): EventHandlerOf<T2> { /*@DONE StubView.CreateNotifier/1 cs:59-63*/
        return { _, _ -> eventNotifications.add(eventName) }
    }
    private fun collect(sender: Any, e: PropertyChangedEventArgs) { /*@DONE StubView.Collect/1 cs:65-67*/
        propertyNotifications.add(e.propertyName ?: "")
    }
    /*@END StubView*/
}
