// Port of ViewModels/Map/MapSlider.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

abstract class MapSlider : ViewModelCore { // cs:8-51
    protected var _id: Int = 0
    abstract val tooltip: String
    private var _icon: MapSliderIcons = MapSliderIcons.LeftRight
    var icon: MapSliderIcons
        get() { /*@DONE MapSlider.Icon.get cs:15-15*/
            return _icon
        }
        set(value) { /*@DONE MapSlider.Icon.set cs:15-15*/
            tryUpdate(_icon, value, "icon") { _icon = it }
        }
    val enableContextMenu: Boolean
        get() { /*@DONE MapSlider.EnableContextMenu.get cs:17-17*/
            return contextItems.size > 0
        }
    var contextItems: ObservableCollection<IMenuCommand> = /*@INITDONE MapSlider.ContextItems cs:18-18*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _anchorLeftEdge: Boolean = false
    private var _anchorTopEdge: Boolean = false
    private var anchorX: Int = 0
    private var anchorY: Int = 0
    var anchorLeftEdge: Boolean
        get() { /*@DONE MapSlider.AnchorLeftEdge.get cs:22-22*/
            return _anchorLeftEdge // if false, we anchor the right edge instead
        }
        set(value) { /*@DONE MapSlider.AnchorLeftEdge.set cs:22-22*/
            tryUpdate(_anchorLeftEdge, value, "anchorLeftEdge") { _anchorLeftEdge = it }
        }
    var anchorTopEdge: Boolean
        get() { /*@DONE MapSlider.AnchorTopEdge.get cs:23-23*/
            return _anchorTopEdge // if false, we anchor the bottom edge instead
        }
        set(value) { /*@DONE MapSlider.AnchorTopEdge.set cs:23-23*/
            tryUpdate(_anchorTopEdge, value, "anchorTopEdge") { _anchorTopEdge = it }
        }
    var anchorPositionX: Int
        get() { /*@DONE MapSlider.AnchorPositionX.get cs:24-24*/
            return anchorX
        }
        set(value) { /*@DONE MapSlider.AnchorPositionX.set cs:24-24*/
            tryUpdate(anchorX, value, "anchorPositionX") { anchorX = it }
        }
    var anchorPositionY: Int
        get() { /*@DONE MapSlider.AnchorPositionY.get cs:25-25*/
            return anchorY
        }
        set(value) { /*@DONE MapSlider.AnchorPositionY.set cs:25-25*/
            tryUpdate(anchorY, value, "anchorPositionY") { anchorY = it }
        }
    protected constructor(id: Int, icon: MapSliderIcons, left: Int = Int.MIN_VALUE, top: Int = Int.MIN_VALUE, right: Int = Int.MIN_VALUE, bottom: Int = Int.MIN_VALUE) { /*@DONE MapSlider.<init>/1 cs:27-36*/
        anchorPositionX = left
        anchorLeftEdge = anchorPositionX != Int.MIN_VALUE
        if (!anchorLeftEdge) anchorPositionX = -right
        anchorPositionY = top
        anchorTopEdge = anchorPositionY != Int.MIN_VALUE
        if (!anchorTopEdge) anchorPositionY = -bottom
        this.icon = icon
        this._id = id
    }
    abstract fun move(x: Int, y: Int)
    open fun tryUpdate(other: MapSlider?): Boolean { /*@DONE MapSlider.TryUpdate/1 cs:40-50*/
        if (other == null) return false
        if (other._id != _id) return false
        anchorLeftEdge = other.anchorLeftEdge
        anchorTopEdge = other.anchorTopEdge
        anchorPositionX = other.anchorPositionX
        anchorPositionY = other.anchorPositionY
        icon = other.icon
        contextItems.clear()
        for (item in other.contextItems) contextItems.add(item)
        return true
    }
    companion object {
        const val sliderSize: Int = 20
        /*@END MapSlider.Companion*/
    }
    /*@END MapSlider*/
}

enum class MapSliderIcons(val value: Int) { // cs:53-55
    LeftRight(0),
    UpDown(1),
    ExtendLeft(2),
    ExtendRight(3),
    ExtendUp(4),
    ExtendDown(5);
    companion object {
        fun fromValue(value: Int): MapSliderIcons = entries.first { it.value == value }
    }
    /*@END MapSliderIcons*/
}

open class ConnectionSlider : MapSlider { // cs:57-101
    private lateinit var tutorials: MapTutorialsViewModel
    private lateinit var notify: () -> Unit
    private lateinit var connection: ConnectionModel
    override val tooltip: String
        get() { /*@DONE ConnectionSlider.Tooltip.get cs:62-62*/
            return "Drag to adjust the connection between the maps."
        }
    constructor(connection: ConnectionModel, sourceMapInfo: ConnectionSliderInitSourceMapInfoTuple, notify: () -> Unit, id: Int, icon: MapSliderIcons, tutorials: MapTutorialsViewModel, left: Int = Int.MIN_VALUE, top: Int = Int.MIN_VALUE, right: Int = Int.MIN_VALUE, bottom: Int = Int.MIN_VALUE) : super(id, icon, left, top, right, bottom) { /*@DONE ConnectionSlider.<init>/1 cs:64-69*/
        this.notify = notify
        this.connection = connection
        this.tutorials = tutorials
    }
    override fun move(x: Int, y: Int) { /*@DONE ConnectionSlider.Move/1 cs:71-90*/
        val inverse = connection.getInverse()
        if (icon == MapSliderIcons.LeftRight) {
            connection.offset += x
            if (inverse != null) inverse.offset = -connection.offset
            if (x != 0) {
                notify()
                tutorials.complete(Tutorial.DragButtons_AdjustConnection)
            }
        } else if (icon == MapSliderIcons.UpDown) {
            connection.offset += y
            if (inverse != null) inverse.offset = -connection.offset
            if (y != 0) {
                notify()
                tutorials.complete(Tutorial.DragButtons_AdjustConnection)
            }
        } else {
            throw NotImplementedException()
        }
    }
    override fun tryUpdate(that: MapSlider?): Boolean { /*@DONE ConnectionSlider.TryUpdate/1 cs:92-100*/
        if (that !is ConnectionSlider) return false
        val other: ConnectionSlider = that
        if (other.connection.mapNum != connection.mapNum ||
            other.connection.mapGroup != connection.mapGroup) return false
        if (!super.tryUpdate(other)) return false
        notify = other.notify
        connection = other.connection
        return true
    }
    /*@END ConnectionSlider*/
}

open class ExpansionSlider : MapSlider { // cs:103-133
    private lateinit var resize: (MapDirection, Int) -> Unit
    override val tooltip: String
        get() { /*@DONE ExpansionSlider.Tooltip.get cs:106-107*/
            return "Drag to change the " + (if (icon.isAny(MapSliderIcons.ExtendLeft, MapSliderIcons.ExtendRight)) "width" else "height") + " of the map." + NEW_LINE +
                "Right-Click to add or remove a connection."
        }
    constructor(resize: (MapDirection, Int) -> Unit, id: Int, icon: MapSliderIcons, contextItems: Iterable<IMenuCommand>, left: Int = Int.MIN_VALUE, top: Int = Int.MIN_VALUE, right: Int = Int.MIN_VALUE, bottom: Int = Int.MIN_VALUE) : super(id, icon, left, top, right, bottom) { /*@DONE ExpansionSlider.<init>/1 cs:109-112*/
        for (item in contextItems) this.contextItems.add(item)
        this.resize = resize
    }
    override fun move(x: Int, y: Int) { /*@DONE ExpansionSlider.Move/1 cs:114-124*/
        if (icon == MapSliderIcons.ExtendLeft && !anchorLeftEdge) {
            resize(MapDirection.Left, -x)
        } else if (icon == MapSliderIcons.ExtendRight && anchorLeftEdge) {
            resize(MapDirection.Right, x)
        } else if (icon == MapSliderIcons.ExtendUp && !anchorTopEdge) {
            resize(MapDirection.Up, -y)
        } else if (icon == MapSliderIcons.ExtendDown && anchorTopEdge) {
            resize(MapDirection.Down, y)
        }
    }
    override fun tryUpdate(that: MapSlider?): Boolean { /*@DONE ExpansionSlider.TryUpdate/1 cs:126-132*/
        if (that !is ExpansionSlider) return false
        val other: ExpansionSlider = that
        if (!super.tryUpdate(other)) return false
        resize = other.resize
        notifyPropertyChanged("tooltip")
        return true
    }
    /*@END ExpansionSlider*/
}

data class ConnectionSliderInitSourceMapInfoTuple(val group: Int, val num: Int)
