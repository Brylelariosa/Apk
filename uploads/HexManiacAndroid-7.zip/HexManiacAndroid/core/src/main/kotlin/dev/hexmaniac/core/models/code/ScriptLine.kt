// Port of Models/Code/ScriptLine.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.code

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*

interface IScriptLine { // cs:10-46
    val args: List<IScriptArg>
    val lineCode: ByteList
    val lineCommand: String
    val documentation: List<String>?
    val usage: String
    val isEndingCommand: Boolean
    fun matchesGame(gameCodeHash: Int): Boolean
    fun compiledByteLength(model: IDataModel, start: Int, destinationLengths: MutableMap<Int, Int>?): Int
    fun compiledByteLength(model: IDataModel, line: String): Int
    fun matches(gameCodeHash: Int, data: ByteList, index: Int): Boolean
    fun decompile(data: IDataModel, start: Int, labels: DecompileLabelLibrary, streamTypes: MutableList<ExpectedPointerType>): String
    fun canCompile(line: String): Boolean
    fun errorCheck(scriptLine: String, tokens: Ref<Array<String>?>): String?
    fun compile(model: IDataModel, start: Int, scriptLine: String, labels: LabelLibrary, result: Ref<ByteArray?>): String?
    fun addDocumentation(content: String)
    fun countShowArgs(): Int { /*@DONE IScriptLine.CountShowArgs/1 cs:39-45*/
        return args.count { it is ScriptArg }
    }
    /*@END IScriptLine*/
}

open class MacroScriptLine : IScriptLine { // cs:48-319
    private val _documentation: MutableList<String> = /*@INITAUTO MacroScriptLine.documentation cs:50-50*/ ArrayList() /*@ENDINIT*/
    private var hasShortForm: Boolean = false
    private val shortIndexFromLongIndex: MutableMap<Int, Int> = /*@INITDONE MacroScriptLine.shortIndexFromLongIndex cs:53-53*/ LinkedHashMap() /*@ENDINIT*/
    private var matchingGames: List<Int>? = null
    final override var args: List<IScriptArg> = ArrayList()
        private set
    var shortFormArgs: List<IScriptArg>? = null
        private set
    override val lineCode: ByteList
        get() { /*@DONE MacroScriptLine.LineCode.get cs:58-58*/
            return emptyByteList
        }
    override val documentation: List<String>?
        get() { /*@DONE MacroScriptLine.Documentation.get cs:59-59*/
            return _documentation
        }
    final override var lineCommand: String = ""
        private set
    override val isEndingCommand: Boolean
        get() { /*@DONE MacroScriptLine.IsEndingCommand.get cs:61-61*/
            return false
        }
    var isValid: Boolean = /*@INITAUTO MacroScriptLine.IsValid cs:62-62*/ true /*@ENDINIT*/
        private set
    override var usage: String = ""
    constructor(engineLine: String) { /*@DONE MacroScriptLine.<init>/1 cs:76-105*/
        val docSplit = engineLine.split('#', limit = 2)
        if (docSplit.size > 1) _documentation.add("#" + docSplit[1])
        val lineRef = Ref(docSplit[0].trim())
        matchingGames = ScriptLine.extractMatchingGames(lineRef)
        extractShortformInfo(lineRef)
        val engineLine = lineRef.value
        if (!hasShortForm) {
            usage = engineLine.split(' ').filter { token -> token.length != 2 || !token.tryParseHex(Ref(0)) }.joinToString(" ")
        }
        val usageTokens = usage.split(' ').filter { it.isNotEmpty() }
        usage = (usageTokens.firstOrNull() ?: "") + " " + usageTokens.drop(1).joinToString(" ") { t -> t.split('.', ':', '|', '<')[0] }

        val tokens = engineLine.split(' ').filter { it.isNotEmpty() }
        val argList = ArrayList<IScriptArg>()
        lineCommand = tokens.firstOrNull() ?: ""

        for (i in 1 until tokens.size) {
            val token = tokens[i]
            val number = Ref(0)
            if (token.length == 2 && token.tryParseHex(number)) {
                argList.add(SilentMatchArg(number.value and 0xFF))
            } else if (ScriptArg.isValidToken(token)) {
                argList.add(ScriptArg(token))
            } else {
                isValid = false
            }
        }

        this.args = argList
        if (shortFormArgs == null) shortFormArgs = this.args.filter { it !is SilentMatchArg }
    }
    private fun extractShortformInfo(engineLine: Ref<String>) { /*@DONE MacroScriptLine.ExtractShortformInfo/1 cs:111-135*/
        if (!engineLine.value.contains("->")) return
        val parts = engineLine.value.split("->")
        if (parts.size != 2) return
        engineLine.value = parts[1]
        var shortTokens = parts[0].split(' ').filter { it.isNotEmpty() }
        var longTokens = parts[1].split(' ').filter { it.isNotEmpty() }
        if (shortTokens.isEmpty() || longTokens.isEmpty() || shortTokens[0] != longTokens[0]) return
        shortTokens = shortTokens.drop(1)
        longTokens = longTokens.drop(1)

        // for each entry in long, it shows up somewhere in short
        // entries in long can appear multiple times
        // entries in long might not have any exact matches if the short-argument is multiple bytes and is split into multiple single-byte arguments in the long arguments.
        for (i in longTokens.indices) {
            val index = shortTokens.indexOf(longTokens[i])
            if (index == -1) continue
            shortIndexFromLongIndex[i] = index
        }

        // NOTE: short form args do not permit array args, such as with the animation scripts
        shortFormArgs = shortTokens.map { token -> ScriptArg(token) }
        hasShortForm = true
        usage = parts[0]
    }
    override fun matchesGame(game: Int): Boolean { /*@DONE MacroScriptLine.MatchesGame/1 cs:137-137*/
        return matchingGames?.contains(game) ?: true
    }
    override fun compiledByteLength(model: IDataModel, start: Int, destinationLengths: MutableMap<Int, Int>?): Int { /*@DONE MacroScriptLine.CompiledByteLength/1 cs:139-149*/
        var length = lineCode.count
        for (arg in args) {
            if (destinationLengths != null) {
                val argLength = ScriptParser.getArgLength(model, arg, start + length, destinationLengths)
                if (argLength > 0) destinationLengths[model.readPointer(start + length)] = argLength
            }
            length += arg.length(null, -1)
        }
        return length
    }
    override fun compiledByteLength(model: IDataModel, line: String): Int { /*@DONE MacroScriptLine.CompiledByteLength/2 cs:151-158*/
        if (!canCompile(line)) return 0
        var length = lineCode.count
        for (arg in args) {
            length += arg.length(null, -1)
        }
        return length
    }
    override fun matches(gameCodeHash: Int, data: ByteList, index: Int): Boolean { /*@DONE MacroScriptLine.Matches/1 cs:160-184*/
        if (args.size == 0) return false
        if (!matchesGame(gameCodeHash)) return false
        val expectedVariableValues = LinkedHashMap<String, Int>()
        val shortArgs = shortFormArgs ?: args
        var index = index
        for (i in args.indices) {
            val arg = args[i]
            if (arg is SilentMatchArg) {
                if (index < 0 || index >= data.count) return false
                if (data[index] != arg.expectedValue) return false
            } else if (arg is ScriptArg) {
                // if the argument is duplicated through multiple spots,
                // make sure all the spots match the same value.
                val matchingShortArg = shortArgs.firstOrNull { shortArg -> shortArg.name == arg.name }
                val argLength = arg.length(null, -1)
                if ((matchingShortArg?.length(null, -1) ?: 0) == argLength) {
                    if (index < 0 || index + argLength > data.count) return false
                    val value = data.readMultiByteValue(index, argLength)
                    val expectedValue = expectedVariableValues[arg.name]
                    if (expectedValue == null) expectedVariableValues[arg.name] = value
                    else if (expectedValue != value) return false // only match the macro if all the variables match
                }
            } else {
                throw NotImplementedError()
            }
            index += arg.length(null, -1)
        }
        return true
    }
    override fun decompile(data: IDataModel, start: Int, labels: DecompileLabelLibrary, streamTypes: MutableList<ExpectedPointerType>): String { /*@DONE MacroScriptLine.Decompile/1 cs:186-224*/
        val builder = StringBuilder(lineCommand)
        val streamContent = ArrayList<String>()
        val argTexts = ArrayList<String>()
        val shiftNames = LinkedHashMap<String, Int>()
        val carryNames = LinkedHashMap<String, Int>()
        val shortArgs = shortFormArgs ?: args
        var start = start
        var i = 0
        for (arg in args) {
            if (arg is ScriptArg) {
                val tempBuilder = StringBuilder()
                var shift = 0
                var carry = 0
                val argLength = arg.length(data, start)
                val shortIndex = shortIndexFromLongIndex[i]
                if (shortIndex == null) {
                    val shortArg = shortArgs.firstOrNull { it.name == arg.name }
                    if (shortArg != null && shortArg.length(data, start) != argLength) {
                        carry = carryNames[arg.name] ?: 0
                        shift = shiftNames[arg.name] ?: 0
                        shiftNames[arg.name] = shift + 8 * argLength
                        carryNames[arg.name] = carry + (data.readMultiByteValue(start, argLength) shl shift)
                    }
                }
                arg.build(false, data, start, tempBuilder, streamContent, shift, carry, labels, streamTypes)
                argTexts.add(tempBuilder.toString())
                i += 1
            }
            start += arg.length(data, start)
        }
        if (argTexts.size > 0) {
            builder.append(" ")
            builder.append(convertLongFormToShortForm(argTexts.toTypedArray()).joinToString(" "))
        }
        for (content in streamContent) {
            builder.appendLine()
            builder.appendLine("{")
            builder.appendLine(content)
            builder.append("}")
        }
        return builder.toString()
    }
    override fun canCompile(line: String): Boolean { /*@DONE MacroScriptLine.CanCompile/1 cs:226-231*/
        val tokens = ScriptLine.tokenize(line)
        if (tokens.size == 0) return false
        if (tokens[0] != lineCommand) return false
        return true
    }
    override fun errorCheck(scriptLine: String, tokens: Ref<Array<String>?>): String? { /*@DONE MacroScriptLine.ErrorCheck/1 cs:233-252*/
        tokens.value = ScriptLine.tokenize(scriptLine)
        for (i in 1 until scriptLine.length - 1) {
            if (scriptLine[i] != '"') continue
            if (scriptLine[i - 1] != ' ' && scriptLine[i + 1] != ' ') return "Cannot have \"quotes\" in the middle of a name."
        }
        val toks = tokens.value!!
        if (toks[0] != lineCommand) throw IllegalArgumentException("Command " + lineCommand + " was expected, but received " + toks[0] + " instead.")
        var argTokens = toks.drop(1).toTypedArray()
        val shortArgs = argTokens
        val commandText = lineCommand
        val shortCount = shortFormArgs?.size ?: 0
        if (hasShortForm && shortArgs.size != shortCount) {
            return "Command " + commandText + " expects " + shortCount + " arguments, but received " + shortArgs.size + " instead."
        }
        argTokens = convertShortFormToLongForm(argTokens)
        val specifiedArgs = args.count { it is ScriptArg }
        if (!hasShortForm && specifiedArgs != argTokens.size) {
            return "Command " + commandText + " expects " + specifiedArgs + " arguments, but received " + shortArgs.size + " instead."
        }
        return null
    }
    override fun compile(model: IDataModel, start: Int, scriptLine: String, labels: LabelLibrary, result: Ref<ByteArray?>): String? { /*@DONE MacroScriptLine.Compile/1 cs:254-282*/
        result.value = null
        val tokenRef = Ref<Array<String>?>(null)
        val error = errorCheck(scriptLine, tokenRef)
        if (error != null) return error
        var argTokens = tokenRef.value!!.drop(1).toTypedArray()
        argTokens = convertShortFormToLongForm(argTokens)
        val results = ArrayList<Int>()
        var specifiedArgIndex = 0
        val shiftNames = LinkedHashMap<String, Int>()
        for (i in args.indices) {
            val current = args[i]
            if (current is ScriptArg) {
                var shift = 0
                if (!shortIndexFromLongIndex.containsKey(i)) {
                    // the arguments length doesn't match the short version.
                    // pull the current shift
                    shift = shiftNames[current.name] ?: 0
                    shiftNames[current.name] = shift + current.length(model, start + results.size) * 8
                }
                val token = argTokens[specifiedArgIndex]
                val message = current.build(model, start + results.size, token, shift, results, labels)
                if (message != null) return message
                specifiedArgIndex += 1
            } else if (current is SilentMatchArg) {
                results.add(current.expectedValue)
            }
        }
        result.value = results.toByteArrayU()
        return null
    }
    override fun addDocumentation(doc: String) { /*@DONE MacroScriptLine.AddDocumentation/1 cs:284-284*/
        _documentation.add(doc)
    }
    private fun convertShortFormToLongForm(args: Array<String>): Array<String> { /*@DONE MacroScriptLine.ConvertShortFormToLongForm/1 cs:286-300*/
        if (!hasShortForm || args.size == 0) return args
        // build long-form args from this short form
        val longForm = ArrayList<String>()
        val shortArgs = shortFormArgs ?: emptyList()
        for (i in this.args.indices) {
            if (this.args[i] is SilentMatchArg) continue
            val shortIndex = shortIndexFromLongIndex[i]
            if (shortIndex != null) {
                if (shortIndex < args.size) longForm.add(args[shortIndex])
            } else {
                // NOTE: the original lambda parameter shadows the loop index: both lists are indexed by the lambda's index.
                val shortformIndex = shortArgs.indices.firstOrNull { j -> shortArgs[j].name == this.args.getOrNull(j)?.name } ?: 0
                longForm.add(args[shortformIndex])
            }
        }
        return longForm.toTypedArray()
    }
    private fun convertLongFormToShortForm(args: Array<String>): Array<String> { /*@DONE MacroScriptLine.ConvertLongFormToShortForm/1 cs:302-318*/
        if (!hasShortForm) return args
        val shortForm = LinkedHashMap<Int, String>()
        val shortArgs = shortFormArgs ?: emptyList()
        var j = 0

        for (i in this.args.indices) {
            if (this.args[i] is SilentMatchArg) continue
            val shortIndex = shortIndexFromLongIndex[i]
            if (shortIndex != null) {
                shortForm[shortIndex] = args[j] // this prefers to use the last instance of the argument, if the argument appears multiple times. Needs to work this way for split-byte args.
            } else {
                val shortformIndex = shortArgs.indices.firstOrNull { k -> shortArgs[k].name == this.args.getOrNull(k)?.name } ?: 0
                shortForm[shortformIndex] = args[j]
            }
            j += 1
        }
        return Array(shortForm.size) { k -> shortForm[k] ?: "" }
    }
    companion object {
        private val emptyByteList: ByteList = /*@INITAUTO MacroScriptLine.emptyByteList cs:49-49*/ ByteArray(0).asByteList() /*@ENDINIT*/
        fun isMacroLine(engineLine: String): Boolean { /*@DONE MacroScriptLine.IsMacroLine/1 cs:65-74*/
            val engineLine = engineLine.trim()
            val tokens = engineLine.split(' ').filter { it.isNotEmpty() }
            if (tokens.size == 0) return false
            var token = tokens[0]
            if (token.startsWith("[") && tokens.size > 1) token = tokens[1]
            if (token.startsWith("#")) return false
            if (token.length == 2 && token.tryParseHex(Ref(0))) return false
            return true
        }
        /*@END MacroScriptLine.Companion*/
    }
    /*@END MacroScriptLine*/
}

abstract class ScriptLine : IScriptLine { // cs:321-568
    private val _documentation: MutableList<String> = /*@INITAUTO ScriptLine.documentation cs:322-322*/ ArrayList() /*@ENDINIT*/
    private var matchingGames: List<Int>? = null
    final override var args: List<IScriptArg> = ArrayList()
        private set
    final override var lineCode: ByteList = ByteArray(0).asByteList()
        private set
    final override var lineCommand: String = ""
        private set
    override val documentation: List<String>?
        get() { /*@DONE ScriptLine.Documentation.get cs:329-329*/
            return _documentation
        }
    final override var usage: String = ""
        private set
    override val isEndingCommand: Boolean = false
    override fun compiledByteLength(model: IDataModel, start: Int, destinationLengths: MutableMap<Int, Int>?): Int { /*@DONE ScriptLine.CompiledByteLength/1 cs:335-348*/
        var length = lineCode.count
        for (arg in args) {
            if (arg.type == ArgType.Pointer) {
                val destination = model.readPointer(start + length)
                if (destinationLengths != null && !destinationLengths.containsKey(destination)) {
                    val argLength = ScriptParser.getArgLength(model, arg, start + length, destinationLengths)
                    if (argLength > 0) destinationLengths[destination] = argLength
                }
            }
            length += arg.length(model, start + length)
        }
        return length
    }
    override fun compiledByteLength(model: IDataModel, line: String): Int { /*@DONE ScriptLine.CompiledByteLength/2 cs:349-357*/
        var length = lineCode.count
        val tokens = line.trim().split(' ').filter { it.isNotEmpty() }
        for (i in args.indices) {
            val current = args[i]
            if (current is ScriptArg) length += current.length(null, -1)
            if (current is ArrayArg) length += current.convertMany(model, tokens.drop(i + 1)).count() * current.tokenLength + 1
        }
        return length
    }
    protected constructor(engineLine: String) { /*@DONE ScriptLine.<init>/1 cs:359-393*/
        val docSplit = engineLine.split('#', limit = 2)
        if (docSplit.size > 1) _documentation.add("#" + docSplit[1])
        val lineRef = Ref(docSplit[0].trim())
        matchingGames = extractMatchingGames(lineRef)
        val engineLine = lineRef.value
        usage = engineLine.split(' ', limit = 2).last()
        val usageTokens = usage.split(' ').filter { it.isNotEmpty() }
        usage = (usageTokens.firstOrNull() ?: "") + " " + usageTokens.drop(1).joinToString(" ") { t0 ->
            var t = t0
            val hasBraces = t.startsWith('[') && t.endsWith(']')
            if (hasBraces) t = t.substring(1, t.length - 1)
            t = t.split('.', ':', '|', '<')[0]
            if (hasBraces) t = "[" + t + "]"
            t
        }

        val tokens = engineLine.split(' ').filter { it.isNotEmpty() }
        val codeList = ArrayList<Int>()
        val argList = ArrayList<IScriptArg>()

        for (token in tokens) {
            if (token.length == 2 && token.all { c -> ViewPort.allHexCharacters.contains(c) }) {
                codeList.add(token.toInt(16))
            } else if (token.startsWith("[") && token.endsWith("]")) {
                val content = token.substring(1, token.length - 1)
                argList.add(ArrayArg(content))
            } else if (ScriptArg.isValidToken(token)) {
                argList.add(ScriptArg(token))
            } else {
                lineCommand = token
            }
        }

        this.lineCode = codeList.toByteArrayU().asByteList()
        this.args = argList
    }
    override fun matchesGame(game: Int): Boolean { /*@DONE ScriptLine.MatchesGame/1 cs:413-413*/
        return matchingGames?.contains(game) ?: true
    }
    override fun addDocumentation(doc: String) { /*@DONE ScriptLine.AddDocumentation/1 cs:415-415*/
        _documentation.add(doc)
    }
    fun partialMatchLine(line: String): Boolean { /*@DONE ScriptLine.PartialMatchLine/1 cs:417-417*/
        return lineCommand.matchesPartial(line.split(' ')[0])
    }
    override fun matches(gameCodeHash: Int, data: ByteList, index: Int): Boolean { /*@DONE ScriptLine.Matches/1 cs:419-427*/
        if (index < 0 || index + lineCode.count >= data.count) return false
        if (matchesGame(gameCodeHash)) {
            var result = true
            var i = 0
            while (result && i < lineCode.count) {
                result = data[index + i] == lineCode[i] // avoid making lambda for performance
                i++
            }
            return result
        }
        return false
    }
    override fun canCompile(line: String): Boolean { /*@DONE ScriptLine.CanCompile/1 cs:429-441*/
        if (!(line + " ").startsWith(lineCommand + " ", ignoreCase = true)) return false
        if (lineCode.count == 1) return true
        val tokens = tokenize(line).toMutableList()
        if (tokens.size < lineCode.count) return false
        tokens.removeAt(0)
        for (i in 1 until lineCode.count) {
            val value = Ref(0)
            if (!tryParseHexInt(tokens[0], value) || value.value < 0 || value.value > 255) return false
            if (value.value != lineCode[i]) return false
            tokens.removeAt(0)
        }
        return true
    }
    override fun errorCheck(scriptLine: String, tokens: Ref<Array<String>?>): String? { /*@DONE ScriptLine.ErrorCheck/1 cs:443-460*/
        var toks = tokenize(scriptLine)
        tokens.value = toks
        if (!toks[0].equals(lineCommand, ignoreCase = true)) throw IllegalArgumentException("Command " + lineCommand + " was expected, but received " + toks[0] + " instead.")
        var commandText = lineCommand
        for (i in 1 until lineCode.count) commandText += " " + lineCode[i].toHexByte()
        val fillerCount = args.count { it.name == "filler" }
        for (i in 0 until fillerCount) {
            if (toks.size < args.size + lineCode.count) toks = toks + "0"
        }
        tokens.value = toks
        if (args.size > 0 && args.last() is ArrayArg) {
            if (args.size > toks.size) {
                return "Command " + commandText + " expects " + args.size + " arguments, but received " + (toks.size - lineCode.count) + " instead."
            }
        } else if (args.size != toks.size - lineCode.count) {
            return "Command " + commandText + " expects " + args.size + " arguments, but received " + (toks.size - lineCode.count) + " instead."
        }
        return null
    }
    override fun compile(model: IDataModel, start: Int, scriptLine: String, labels: LabelLibrary, result: Ref<ByteArray?>): String? { /*@DONE ScriptLine.Compile/1 cs:462-500*/
        result.value = null
        val tokenRef = Ref<Array<String>?>(null)
        val error = errorCheck(scriptLine, tokenRef)
        if (error != null) return error
        val tokens = tokenRef.value!!
        val results = ArrayList<Int>()
        for (b in 0 until lineCode.count) results.add(lineCode[b])
        var start = start + lineCode.count
        for (i in args.indices) {
            val current = args[i]
            if (current is ScriptArg) {
                val token = tokens[i + lineCode.count]
                val message = current.build(model, start, token, results, labels)
                if (message != null) return message
                start += current.length(model, start)
            } else if (current is ArrayArg) {
                val values = current.convertMany(model, tokens.drop(i + 1)).toList()
                results.add(values.size and 0xFF)
                start += 1
                for (value in values) {
                    if (current.type == ArgType.Byte) {
                        results.add(value and 0xFF)
                        start += 1
                    } else if (current.type == ArgType.Short) {
                        results.add(value and 0xFF)
                        results.add((value shr 8) and 0xFF)
                        start += 2
                    } else if (current.type == ArgType.Word) {
                        results.add(value and 0xFF)
                        results.add((value shr 0x8) and 0xFF)
                        results.add((value shr 0x10) and 0xFF)
                        results.add((value shr 0x18) and 0xFF)
                        start += 4
                    } else {
                        throw NotImplementedError()
                    }
                }
            }
        }
        result.value = results.toByteArrayU()
        return null
    }
    override fun decompile(data: IDataModel, start: Int, labels: DecompileLabelLibrary, streamTypes: MutableList<ExpectedPointerType>): String { /*@DONE ScriptLine.Decompile/1 cs:502-532*/
        for (i in 0 until lineCode.count) {
            if (lineCode[i] != data[start + i]) throw IllegalArgumentException("Data at " + start.toHex(6) + " does not match the " + lineCommand + " command.")
        }
        val allFillerIsZero = isAllFillerZero(data, start)
        var start = start + lineCode.count
        val builder = StringBuilder(lineCommand)
        for (i in 1 until lineCode.count) {
            builder.append(" " + lineCode[i].toHexByte())
        }

        val streamContent = ArrayList<String>()
        for (arg in args) {
            builder.append(" ")
            if (arg is ScriptArg) {
                if (arg.build(allFillerIsZero, data, start, builder, streamContent, labels, streamTypes)) continue
            } else if (arg is ArrayArg) {
                builder.append(arg.convertMany(data, start))
            } else {
                throw NotImplementedError()
            }
            start += arg.length(data, start)
        }
        for (content in streamContent) {
            builder.appendLine()
            builder.appendLine("{")
            builder.appendLine(content)
            builder.append("}")
        }
        return builder.toString()
    }
    private fun isAllFillerZero(data: IDataModel, start: Int): Boolean { /*@DONE ScriptLine.IsAllFillerZero/1 cs:534-544*/
        var start = start + lineCode.count
        for (arg in args) {
            if (arg.name == "filler") {
                val value = data.readMultiByteValue(start, arg.length(data, start))
                if (value != 0) return false
            }
            start += arg.length(data, start)
        }
        return true
    }
    override fun toString(): String { /*@DONE ScriptLine.ToString/1 cs:565-567*/
        val parts = ArrayList<String>()
        for (i in 0 until lineCode.count) parts.add(lineCode[i].toHexByte())
        for (arg in args) parts.add(arg.name)
        return parts.joinToString(" ")
    }
    companion object {
        const val hex: String = "0123456789ABCDEF"
        fun extractMatchingGames(line: Ref<String>): List<Int>? { /*@DONE ScriptLine.ExtractMatchingGames/1 cs:395-402*/
            if (!line.value.startsWith("[")) return null
            val gamesEnd = line.value.indexOf("]")
            if (gamesEnd == -1) return null
            val games = line.value.substring(1, gamesEnd)
            line.value = line.value.substring(gamesEnd + 1).trimStart()
            return games.split('_').map { convertAscii(it) }
        }
        fun getMatchingGames(line: IScriptLine): List<String> { /*@DONE ScriptLine.GetMatchingGames/1 cs:404-407*/
            val names = listOf("AXVE", "AXPE", "BPRE", "BPGE", "BPEE")
            return names.filter { name -> line.matchesGame(convertAscii(name)) }
        }
        fun convertAscii(letters: String): Int { /*@DONE ScriptLine.ConvertAscii/1 cs:409-411*/
            return letters.reversed().fold(0) { current, letter -> (current shl 8) or (letter.code and 0xFF) }
        }
        fun readString(data: IDataModel, start: Int): String { /*@DONE ScriptLine.ReadString/1 cs:546-549*/
            val length = PCSString.readString(data, start, true)
            return data.textConverter.convert(data, start, length) ?: ""
        }
        fun tokenize(scriptLine: String): Array<String> { /*@DONE ScriptLine.Tokenize/1 cs:551-563*/
            val result = ArrayList<String>()
            val quoteCut = scriptLine.split('"')

            for (i in quoteCut.indices) {
                if (i % 2 == 0 && quoteCut[i].length == 0) continue

                if (i % 2 == 1) result.add("\"" + quoteCut[i] + "\"")
                else result.addAll(quoteCut[i].split(' ', '\t').filter { it.isNotEmpty() })
            }

            return result.toTypedArray()
        }
        /*@END ScriptLine.Companion*/
    }
    /*@END ScriptLine*/
}

open class XSEScriptLine : ScriptLine { // cs:570-574
    constructor(engineLine: String) : super(engineLine) { /*@DONE XSEScriptLine.<init>/1 cs:571-571*/ }
    override val isEndingCommand: Boolean
        get() { /*@DONE XSEScriptLine.IsEndingCommand.get cs:573-573*/
            return lineCode.count == 1 && lineCode[0].isAny(0x02, 0x03, 0x05, 0x08, 0x0A, 0x0C, 0x0D)
        }
    /*@END XSEScriptLine*/
}

open class BSEScriptLine : ScriptLine { // cs:576-580
    constructor(engineLine: String) : super(engineLine) { /*@DONE BSEScriptLine.<init>/1 cs:577-577*/ }
    override val isEndingCommand: Boolean
        get() { /*@DONE BSEScriptLine.IsEndingCommand.get cs:579-579*/
            return lineCode.count == 1 && lineCode[0].isAny(0x28, 0x3c, 0x3d, 0x3e, 0x3f, 0xef, 0xf6, 0xf7)
        }
    /*@END BSEScriptLine*/
}

open class ASEScriptLine : ScriptLine { // cs:582-586
    constructor(engineLine: String) : super(engineLine) { /*@DONE ASEScriptLine.<init>/1 cs:583-583*/ }
    override val isEndingCommand: Boolean
        get() { /*@DONE ASEScriptLine.IsEndingCommand.get cs:585-585*/
            return lineCode.count == 1 && lineCode[0].isAny(0x08, 0x0F, 0x11, 0x13)
        }
    /*@END ASEScriptLine*/
}

open class TSEScriptLine : ScriptLine { // cs:588-591
    constructor(engineLine: String) : super(engineLine) { /*@DONE TSEScriptLine.<init>/1 cs:589-589*/ }
    override val isEndingCommand: Boolean
        get() { /*@DONE TSEScriptLine.IsEndingCommand.get cs:590-590*/
            return lineCode.count == 1 && lineCode[0].isAny(0x45, 0x47, 0x59, 0x5A)
        }
    /*@END TSEScriptLine*/
}
