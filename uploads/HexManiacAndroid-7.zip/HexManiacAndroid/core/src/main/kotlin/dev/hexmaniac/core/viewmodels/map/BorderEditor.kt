// Port of ViewModels/Map/BorderEditor.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.images.*

open class BorderEditor : ViewModelCore { // cs:6-180
    private lateinit var changeHistory: ChangeHistory<ModelDelta>
    private lateinit var model: IDataModel
    private lateinit var blockmap: BlockMapViewModel
    private lateinit var tutorials: MapTutorialsViewModel
    val borderChanged = Event<EventArgs>()
    private var showBorder: Boolean = false
    var showBorderPanel: Boolean
        get() { /*@DONE BorderEditor.ShowBorderPanel.get cs:15-15*/
            return showBorder
        }
        set(value) { /*@DONE BorderEditor.ShowBorderPanel.set cs:15-15*/
            tryUpdate(showBorder, value, "showBorderPanel") { showBorder = it }
        }
    fun toggleBorderEditor() { /*@DONE BorderEditor.ToggleBorderEditor/1 cs:17-20*/
        showBorderPanel = !showBorderPanel
        tutorials.complete(Tutorial.ToolbarButton_EditBorderBlock)
    }
    private var _borderRender: CanvasPixelViewModel? = null
    val borderRender: IPixelViewModel
        get() { /*@DONE BorderEditor.BorderRender.get cs:24-29*/
            val existing = _borderRender
            if (existing != null) return existing
            val layout = blockmap.getLayout()
            renderBorder(layout)
            return _borderRender!!
        }
    var hasBorderDimensions: Boolean = false
        private set
    private var _width: Int = /*@INITAUTO BorderEditor.width cs:36-36*/ -1 /*@ENDINIT*/
    private var _height: Int = /*@INITAUTO BorderEditor.height cs:36-36*/ -1 /*@ENDINIT*/
    var width: Int
        get() { /*@DONE BorderEditor.Width.get cs:39-43*/
            if (_width != -1) return _width
            _width = if (hasBorderDimensions) blockmap.getLayout()!!.getValue("borderwidth") else 2
            return _width
        }
        set(value) { /*@DONE BorderEditor.Width.set cs:44-52*/
            if (!hasBorderDimensions) return
            val oldWidth = width
            if (oldWidth == value) return
            _width = value
            val layout = blockmap.getLayout()!!
            layout.setValue("borderwidth", value)
            resize(layout, oldWidth, height, _width, height)
        }
    var height: Int
        get() { /*@DONE BorderEditor.Height.get cs:56-60*/
            if (_height != -1) return _height
            _height = if (hasBorderDimensions) blockmap.getLayout()!!.getValue("borderheight") else 2
            return _height
        }
        set(value) { /*@DONE BorderEditor.Height.set cs:61-69*/
            if (!hasBorderDimensions) return
            val oldHeight = height
            if (oldHeight == value) return
            _height = value
            val layout = blockmap.getLayout()!!
            layout.setValue("borderheight", value)
            resize(layout, width, oldHeight, width, height)
        }
    private fun resize(layout: ModelArrayElement, oldWidth: Int, oldHeight: Int, newWidth: Int, newHeight: Int) { /*@DONE BorderEditor.Resize/1 cs:72-97*/
        val existingData = Array(oldWidth) { IntArray(oldHeight) }
        val oldStart = layout.getAddress("borderblock")
        val considerRepoint = oldWidth * oldHeight < newWidth * newHeight
        val token = changeHistory.currentChange
        for (y in 0 until oldHeight) {
            for (x in 0 until oldWidth) {
                existingData[x][y] = model.readMultiByteValue(oldStart + (y * oldWidth + x) * 2, 2)
                if (considerRepoint) model.writeMultiByteValue(oldStart + (y * oldWidth + x) * 2, 2, token, 0xFFFF)
            }
        }
        var newStart = oldStart
        if (considerRepoint) {
            var run = model.getNextRun(oldStart)
            run = model.relocateForExpansion(token, run!!, newWidth * newHeight * 2)
            newStart = run.start
        }
        for (y in 0 until newHeight) {
            for (x in 0 until newWidth) {
                model.writeMultiByteValue(newStart + (y * newWidth + x) * 2, 2, token, if (x < existingData.size && y < oldHeight) existingData[x][y] else 0)
            }
        }
        renderBorder(layout)
        notifyPropertyChanged("borderRender")
        borderChanged(this, EventArgs.empty)
    }
    constructor(blockmap: BlockMapViewModel, tutorials: MapTutorialsViewModel) { /*@DONE BorderEditor.<init>/1 cs:101-109*/
        this.blockmap = blockmap
        this.tutorials = tutorials
        this.model = blockmap.viewPort.model!!
        this.changeHistory = blockmap.viewPort.changeHistory
        val layout = blockmap.getLayout()
        if (layout == null) return
        hasBorderDimensions = layout.hasField("borderwidth") && layout.hasField("borderheight")
    }
    fun draw(blockIndex: Int, x: Double, y: Double) { /*@DONE BorderEditor.Draw/1 cs:111-125*/
        if (blockIndex < 0 || blockIndex >= blockmap.blockRenders.size) return
        val xx = (x / 16).toInt()
        val yy = (y / 16).toInt()
        val layout = blockmap.getLayout()!!
        val width = this.width
        var address = layout.getAddress("borderblock")
        address += (yy * width + xx) * 2
        val existingValue = model.readMultiByteValue(address, 2)
        if (blockIndex == existingValue) return
        model.writeMultiByteValue(address, 2, changeHistory.currentChange, blockIndex)
        renderBorder(layout)
        notifyPropertyChanged("borderRender")
        borderChanged(this, EventArgs.empty)
    }
    fun draw(tiles: Array<IntArray>, x: Double, y: Double) { /*@DONE BorderEditor.Draw/2 cs:127-149*/
        val xx = (x / 16).toInt()
        val yy = (y / 16).toInt()
        val layout = blockmap.getLayout()!!
        val width = this.width
        val height = this.height
        val startAddress = layout.getAddress("borderblock")
        var redraw = false
        for (dx in 0 until tiles.size) {
            for (dy in 0 until (if (tiles.size == 0) 0 else tiles[0].size)) {
                if (yy + dy >= height) continue
                if (xx + dx >= width) continue
                val address = startAddress + ((yy + dy) * width + xx + dx) * 2
                val existingValue = model.readMultiByteValue(address, 2)
                if (tiles[dx][dy] == existingValue) continue
                model.writeMultiByteValue(address, 2, changeHistory.currentChange, tiles[dx][dy])
                redraw = true
            }
        }
        if (!redraw) return
        renderBorder(layout)
        notifyPropertyChanged("borderRender")
        borderChanged(this, EventArgs.empty)
    }
    fun getBlock(x: Double, y: Double): Int { /*@DONE BorderEditor.GetBlock/1 cs:151-160*/
        val xx = (x / 16).toInt()
        val yy = (y / 16).toInt()
        val layout = blockmap.getLayout()!!
        val width = this.width
        var address = layout.getAddress("borderblock")
        address += (yy * width + xx) * 2
        val existingValue = model.readMultiByteValue(address, 2)
        return existingValue
    }
    private fun renderBorder(layout: ModelArrayElement?) { /*@DONE BorderEditor.RenderBorder/1 cs:162-179*/
        if (layout == null) return
        val width = this.width
        val height = this.height
        val canvas = CanvasPixelViewModel(width * 16, height * 16)
        canvas.spriteScale = 3.0
        val borderStart = layout.getAddress("borderblock")
        for (y in 0 until height) {
            for (x in 0 until width) {
                val index = model.readMultiByteValue(borderStart + (y * width + x) * 2, 2) and 0x3FF
                if (index >= blockmap.blockRenders.size) continue
                canvas.draw(blockmap.blockRenders[index], x * 16, y * 16)
            }
        }
        val existing = _borderRender
        if (existing == null || existing.pixelWidth != canvas.pixelWidth || existing.pixelHeight != canvas.pixelHeight) {
            _borderRender = canvas
        } else {
            existing.draw(canvas, 0, 0)
        }
    }
    /*@END BorderEditor*/
}
