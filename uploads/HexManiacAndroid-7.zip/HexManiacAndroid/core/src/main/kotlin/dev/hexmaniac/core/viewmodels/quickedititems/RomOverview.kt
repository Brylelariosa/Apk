// Port of ViewModels/QuickEditItems/RomOverview.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*

open class RomOverview : IQuickEditItem { // cs:6-25
    override val name: String?
        get() { /*@DONE RomOverview.Name.get cs:7-7*/
            return "Render Rom Overview"
        }
    override val description: String?
        get() { /*@DONE RomOverview.Description.get cs:9-9*/
            return "Render an image that represents the raw bytes in the rom. Serves little useful purpose, but is pretty."
        }
    override val wikiLink: String?
        get() { /*@DONE RomOverview.WikiLink.get cs:11-11*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Rom-Overview-Explained"
        }
    val editSelected = Event<EventArgs>()
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE RomOverview.CanRun/1 cs:17-17*/
        return viewPort is ViewPort
    }
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? { /*@DONE RomOverview.Run/1 cs:19-22*/
        if (viewPort is ViewPort) editSelected(this, EventArgs.empty)
        return Task.fromResult(ErrorInfo.noError)
    }
    override fun tabChanged() { /*@DONE RomOverview.TabChanged/1 cs:24-24*/
        canRunChanged(this, EventArgs.empty)
    }
    /*@END RomOverview*/
}
