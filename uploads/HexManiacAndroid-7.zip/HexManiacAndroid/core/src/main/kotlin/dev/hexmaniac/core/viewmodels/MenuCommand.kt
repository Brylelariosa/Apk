// Port of ViewModels/MenuCommand.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

interface IMenuCommand : ICommand { // cs:7-7
    val text: String?
    /*@END IMenuCommand*/
}

data class MenuCommandNonGeneric(override val text: String?, val execute: (() -> Unit)?, val canExecute: (() -> Boolean)? = null) : INotifyPropertyChanged, IMenuCommand { // cs:9-14
    override val canExecuteChanged = Event<EventArgs>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override fun canExecute(parameter: Any?): Boolean { /*@DONE MenuCommandNonGeneric.CanExecute/1 cs:12-12*/
        return canExecute?.invoke() ?: true
    }
    override fun execute(parameter: Any?) { /*@DONE MenuCommandNonGeneric.Execute/1 cs:13-13*/
        execute?.invoke()
    }
    /*@END MenuCommandNonGeneric*/
}

data class MenuCommand<T>(override val text: String?, val execute: ((T) -> Unit)?, val canExecute: ((T) -> Boolean)? = null) : INotifyPropertyChanged, IMenuCommand { // cs:16-25
    override val canExecuteChanged = Event<EventArgs>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    var parameter: T = portInit()
    override fun canExecute(parameter: Any?): Boolean { /*@DONE MenuCommand.CanExecute/1 cs:22-22*/
        val arg = parameter ?: this.parameter
        if (arg == null) return false
        return canExecute?.invoke(arg as T) ?: true
    }
    override fun execute(parameter: Any?) { /*@DONE MenuCommand.Execute/1 cs:24-24*/
        val arg = parameter ?: this.parameter
        if (arg != null) execute?.invoke(arg as T)
    }
    /*@END MenuCommand*/
}
