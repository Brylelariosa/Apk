// Port of ViewModels/Images/CanvasPixelViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.images

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class CanvasPixelViewModel : ViewModelCore, IPixelViewModel { // cs:5-112
    override var transparent: Short = /*@INITAUTO CanvasPixelViewModel.Transparent cs:6-6*/ -1 /*@ENDINIT*/
    final override var pixelWidth: Int = 0
        private set
    final override var pixelHeight: Int = 0
        private set
    override var pixelData: ShortArray = ShortArray(0)
    private var _spriteScale: Double = /*@INITAUTO CanvasPixelViewModel.spriteScale cs:11-11*/ 1.0 /*@ENDINIT*/
    override var spriteScale: Double
        get() { /*@DONE CanvasPixelViewModel.SpriteScale.get cs:13-13*/
            return _spriteScale
        }
        set(value) { /*@DONE CanvasPixelViewModel.SpriteScale.set cs:14-17*/
            set(_spriteScale, value, "spriteScale", { _spriteScale = it }) { _ ->
                notifyPropertyChanged("scaledWidth")
                notifyPropertyChanged("scaledHeight")
            }
        }
    val scaledWidth: Double
        get() { /*@DONE CanvasPixelViewModel.ScaledWidth.get cs:20-20*/
            return pixelWidth * spriteScale
        }
    val scaledHeight: Double
        get() { /*@DONE CanvasPixelViewModel.ScaledHeight.get cs:21-21*/
            return pixelHeight * spriteScale
        }
    constructor(width: Int, height: Int, data: ShortArray? = null) { /*@DONE CanvasPixelViewModel.<init>/1 cs:23-26*/
        this.pixelWidth = width
        this.pixelHeight = height
        this.pixelData = data ?: ShortArray(width * height)
    }
    fun fill(pixelData: ShortArray) { /*@DONE CanvasPixelViewModel.Fill/1 cs:28-32*/
        if (pixelData.size != this.pixelData.size) throw UnsupportedOperationException("Need " + this.pixelData.size + " pixels to fill, but was given " + pixelData.size + " pixels.")
        this.pixelData = pixelData
        notifyPropertyChanged("pixelData")
    }
    fun draw(foreground: IPixelViewModel?, x: Int, y: Int) { /*@DONE CanvasPixelViewModel.Draw/1 cs:34-59*/
        if (foreground == null) return
        if (x >= pixelWidth || y >= pixelHeight) return
        for (yy in 0 until foreground.pixelHeight) {
            if (y + yy < 0 || y + yy >= pixelHeight) continue
            if (foreground.transparent.toInt() == -1) {
                // copy one row at a time, to account for gaps
                val start = Math.max(x, 0)
                val end = Math.min(x + foreground.pixelWidth, pixelWidth)
                if (end > start) {
                    System.arraycopy(foreground.pixelData, foreground.pixelWidth * yy + start - x, pixelData, pixelWidth * (y + yy) + start, end - start)
                }
            } else {
                // go through each pixel to look for transparency
                for (xx in 0 until foreground.pixelWidth) {
                    val pixel = foreground.pixelData[foreground.pixelWidth * yy + xx]
                    if (pixel == foreground.transparent) continue
                    if (x + xx >= pixelWidth) continue
                    if (x + xx < 0) continue
                    val offset = pixelWidth * (y + yy) + (x + xx)
                    pixelData[offset] = pixel
                }
            }
        }
        notifyPropertyChanged("pixelData")
    }
    fun drawBox(x: Int, y: Int, size: Int, color: Short) { /*@DONE CanvasPixelViewModel.DrawBox/1 cs:61-61*/
        drawRect(x, y, size, size, color)
    }
    fun drawRect(x: Int, y: Int, width: Int, height: Int, color: Short) { /*@DONE CanvasPixelViewModel.DrawRect/1 cs:63-73*/
        if (x + y * pixelWidth >= pixelData.size) return
        val data = pixelData
        // out-of-range pixels are skipped instead of throwing
        fun put(index: Int) { if (index >= 0 && index < data.size) data[index] = color }
        for (i in 0 until width - 1) {
            put(x + i + y * pixelWidth)
            put(x + width - 1 - i + (y + height - 1) * pixelWidth)
        }
        for (i in 0 until height - 1) {
            put(x + (y + height - 1 - i) * pixelWidth)
            put(x + width - 1 + (y + i) * pixelWidth)
        }
    }
    fun darkenRect(x: Int, y: Int, width: Int, height: Int, darkness: Int) { /*@DONE CanvasPixelViewModel.DarkenRect/1 cs:75-87*/
        if (x + y * pixelWidth >= pixelData.size) return
        for (i in 0 until width - 1) {
            val p1 = x + i + y * pixelWidth
            val p2 = x + width - 1 - i + (y + height - 1) * pixelWidth
            if (p1 >= 0 && p1 < pixelData.size) pixelData[p1] = darken(pixelData[p1], darkness)
            if (p2 >= 0 && p2 < pixelData.size) pixelData[p2] = darken(pixelData[p2], darkness)
        }
        for (i in 0 until height - 1) {
            val p1 = x + (y + height - 1 - i) * pixelWidth
            val p2 = x + width - 1 + (y + i) * pixelWidth
            if (p1 >= 0 && p1 < pixelData.size) pixelData[p1] = darken(pixelData[p1], darkness)
            if (p2 >= 0 && p2 < pixelData.size) pixelData[p2] = darken(pixelData[p2], darkness)
        }
    }
    companion object {
        fun darken(color: Short, amount: Int): Short { /*@DONE CanvasPixelViewModel.Darken/1 cs:89-100*/
            // it's faster to do this inline rather than calling UncompressedPaletteColor.ToRGB
            // this method needs to be fast, since it can be called for many pixels on many maps
            var r = (color.toInt() shr 10) and 0x1F
            var g = (color.toInt() shr 5) and 0x1F
            var b = (color.toInt() shr 0) and 0x1F

            r = Math.max(0, r - amount)
            g = Math.max(0, g - amount)
            b = Math.max(0, b - amount)
            return UncompressedPaletteColor.pack(r, g, b)
        }
        fun shiftTowards(color: Short, targetColor: CanvasPixelViewModelShiftTowardsTargetColorTuple, amount: Int): Short { /*@DONE CanvasPixelViewModel.ShiftTowards/1 cs:101-111*/
            val rgb = UncompressedPaletteColor.toRGB(color)
            val dr = java.lang.Integer.signum(targetColor.r - rgb.r)
            val dg = java.lang.Integer.signum(targetColor.g - rgb.g)
            val db = java.lang.Integer.signum(targetColor.b - rgb.b)

            val r = (rgb.r + amount * dr).limitToRange(0, 31)
            val g = (rgb.g + amount * dg).limitToRange(0, 31)
            val b = (rgb.b + amount * db).limitToRange(0, 31)
            return UncompressedPaletteColor.pack(r, g, b)
        }
        /*@END CanvasPixelViewModel.Companion*/
    }
    /*@END CanvasPixelViewModel*/
}

data class CanvasPixelViewModelShiftTowardsTargetColorTuple(val r: Int, val g: Int, val b: Int)
