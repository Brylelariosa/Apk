// Port of ViewModels/Tools/IArrayElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

enum class ElementContentViewModelType(val value: Int) { // cs:11-18
    TextField(0),
    NumericField(1),
    Address(2),
    HexField(3),
    ColorField(4),
    ComboBox(5);
    companion object {
        fun fromValue(value: Int): ElementContentViewModelType = entries.first { it.value == value }
    }
    /*@END ElementContentViewModelType*/
}

interface IFieldArrayElementViewModelStrategy { // cs:20-24
    val type: ElementContentViewModelType
    fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel)
    fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String
    /*@END IFieldArrayElementViewModelStrategy*/
}

open class FieldArrayElementViewModel : ViewModelCore, IMultiEnabledArrayElementViewModel { // cs:26-144
    private lateinit var strategy: IFieldArrayElementViewModelStrategy
    private var _name: String = ""
    private var _start: Int = 0
    private var _length: Int = 0
    private var _dataChanged: EventHandler? = null
    override val dataChanged = Event<EventArgs>()
    private var _dataSelected: EventHandler? = null
    override val dataSelected = Event<EventArgs>()
    lateinit var viewPort: ViewPort
        private set
    lateinit var model: IDataModel
        private set
    override var name: String
        get() { /*@DONE FieldArrayElementViewModel.Name.get cs:40-40*/
            return _name
        }
        set(value) { /*@DONE FieldArrayElementViewModel.Name.set cs:40-40*/
            tryUpdate(_name, value, "name") { _name = it }
        }
    var start: Int
        get() { /*@DONE FieldArrayElementViewModel.Start.get cs:41-41*/
            return _start
        }
        set(value) { /*@DONE FieldArrayElementViewModel.Start.set cs:41-41*/
            tryUpdate(_start, value, "start") { _start = it }
        }
    var length: Int
        get() { /*@DONE FieldArrayElementViewModel.Length.get cs:42-42*/
            return _length
        }
        set(value) { /*@DONE FieldArrayElementViewModel.Length.set cs:42-42*/
            tryUpdate(_length, value, "length") { _length = it }
        }
    private var _visible: Boolean = /*@INITAUTO FieldArrayElementViewModel.visible cs:44-44*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE FieldArrayElementViewModel.Visible.get cs:45-45*/
            return _visible
        }
        set(value) { /*@DONE FieldArrayElementViewModel.Visible.set cs:45-45*/
            set(_visible, value, "visible", { _visible = it })
        }
    val type: ElementContentViewModelType
        get() { /*@DONE FieldArrayElementViewModel.Type.get cs:47-47*/
            return strategy.type
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE FieldArrayElementViewModel.Theme.get cs:49-49*/
            return _theme
        }
        set(value) { /*@DONE FieldArrayElementViewModel.Theme.set cs:49-49*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE FieldArrayElementViewModel.IsInError.get cs:50-50*/
            return _errorText != ""
        }
    private var _errorText: String = ""
    override var errorText: String?
        get() { /*@DONE FieldArrayElementViewModel.ErrorText.get cs:54-54*/
            return _errorText
        }
        set(value) { /*@DONE FieldArrayElementViewModel.ErrorText.set cs:55-57*/
            if (tryUpdate(_errorText, value ?: "", "errorText") { _errorText = it }) notifyPropertyChanged("isInError")
        }
    override val zIndex: Int
        get() { /*@DONE FieldArrayElementViewModel.ZIndex.get cs:60-60*/
            return 0
        }
    private var protectContentChange: Boolean = false
    private var _content: String = ""
    var content: String
        get() { /*@DONE FieldArrayElementViewModel.Content.get cs:65-65*/
            return _content
        }
        set(value) { /*@DONE FieldArrayElementViewModel.Content.set cs:66-81*/
            if (tryUpdate(_content, value, "content") { _content = it }) {
                errorText = ""
                strategy.updateModelFromViewModel(this)
                if (!isInError) {
                    val table = model.getNextRun(start) as? ITableRun
                    if (table != null) {
                        val offsets = table.convertByteOffsetToArrayOffset(start)
                        val info = table.notifyChildren(model, viewPort.currentChange, offsets.elementIndex, offsets.segmentIndex)
                        viewPort.handleErrorInfo(info)
                    }
                    // prevent blapping over 'content' if raising dataChanged causes a TryCopy
                    scope(protectContentChange, true, { protectContentChange = it }, { protectContentChange = it }).using {
                        dataChanged(this, EventArgs.empty)
                    }
                }
            }
        }
    constructor(viewPort: ViewPort, name: String, start: Int, length: Int, strategy: IFieldArrayElementViewModelStrategy) { /*@DONE FieldArrayElementViewModel.<init>/1 cs:84-88*/
        this.strategy = strategy
        this.viewPort = viewPort
        this.model = viewPort.model
        _name = name
        _start = start
        _length = length
        _content = strategy.updateViewModelFromModel(this)
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE FieldArrayElementViewModel.TryCopy/1 cs:90-105*/
        val field = other as? FieldArrayElementViewModel ?: return false
        if (!tryCopy(field)) return false
        if (strategy.type != field.strategy.type) return false

        name = field.name
        start = field.start
        length = field.length
        visible = other.visible
        if (!protectContentChange) tryUpdate(_content, field.content, "content") { _content = it }
        errorText = field.errorText
        dataChanged.copyFrom(field.dataChanged)
        dataSelected.copyFrom(field.dataSelected)
        canAcceptChanged(this, EventArgs.empty)
        return true
    }
    protected open fun tryCopy(other: FieldArrayElementViewModel): Boolean { /*@DONE FieldArrayElementViewModel.TryCopy/2 cs:107-107*/
        return true
    }
    val canAcceptChanged = Event<EventArgs>()
    fun accept() { /*@DONE FieldArrayElementViewModel.Accept/1 cs:111-117*/
        // If we add more accept commands, move this logic into the strategy classes.
        // right now, don't bother, since there's just one.
        if (type == ElementContentViewModelType.Address) {
            viewPort.goto?.execute(content)
        }
    }
    fun canAccept(): Boolean { /*@DONE FieldArrayElementViewModel.CanAccept/1 cs:119-121*/
        return type == ElementContentViewModelType.Address && (viewPort.goto?.canExecute(content) ?: false)
    }
    fun resetContent() { /*@DONE FieldArrayElementViewModel.ResetContent/1 cs:123-123*/
        content = strategy.updateViewModelFromModel(this)
    }
    fun focus() { /*@DONE FieldArrayElementViewModel.Focus/1 cs:125-125*/
        dataSelected(this, EventArgs.empty)
    }
    fun incrementValue() { /*@DONE FieldArrayElementViewModel.IncrementValue/1 cs:129-134*/
        if (strategy !is NumericFieldStrategy) return
        val parsed = Ref(0)
        if (!tryParseInt(_content, parsed)) return
        var number = parsed.value
        number += if (_name.lowercase() == "yoffset") -1 else 1
        content = number.toString()
    }
    fun decrementValue() { /*@DONE FieldArrayElementViewModel.DecrementValue/1 cs:136-141*/
        if (strategy !is NumericFieldStrategy) return
        val parsed = Ref(0)
        if (!tryParseInt(_content, parsed)) return
        var number = parsed.value
        number += if (_name.lowercase() == "yoffset") 1 else -1
        content = number.toString()
    }
    /*@END FieldArrayElementViewModel*/
}

open class ColorFieldArrayElementViewModel : FieldArrayElementViewModel { // cs:146-161
    private var _color: Short = 0.toShort()
    var color: Short
        get() { /*@DONE ColorFieldArrayElementViewModel.Color.get cs:148-148*/
            return _color
        }
        set(value) { /*@DONE ColorFieldArrayElementViewModel.Color.set cs:148-148*/
            set(_color, value, "color", { _color = it }, { old -> handleColorChange(old) })
        }
    constructor(viewPort: ViewPort, name: String, start: Int) : super(viewPort, name, start, 2, ColorFieldStrategy.instance) { /*@DONE ColorFieldArrayElementViewModel.<init>/1 cs:150-152*/
        color = viewPort.model.readMultiByteValue(start, 2).toShort()
    }
    protected override fun tryCopy(other: FieldArrayElementViewModel): Boolean { /*@DONE ColorFieldArrayElementViewModel.TryCopy/1 cs:154-158*/
        val field = other as? ColorFieldArrayElementViewModel ?: return false
        set(_color, field.color, "color", { _color = it })
        return true
    }
    private fun handleColorChange(oldValue: Short) { /*@DONE ColorFieldArrayElementViewModel.HandleColorChange/1 cs:160-160*/
        content = UncompressedPaletteColor.convert(color) ?: ""
    }
    /*@END ColorFieldArrayElementViewModel*/
}

open class TextFieldStrategy : IFieldArrayElementViewModelStrategy { // cs:163-185
    override val type: ElementContentViewModelType
        get() { /*@DONE TextFieldStrategy.Type.get cs:165-165*/
            return ElementContentViewModelType.TextField
        }
    override fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel) { /*@DONE TextFieldStrategy.UpdateModelFromViewModel/1 cs:167-174*/
        val textBytes = viewModel.model.textConverter.convert(viewModel.content, Ref(false)) ?: return
        while (textBytes.size < viewModel.length) textBytes.add(0x00)
        if (textBytes.size > viewModel.length) textBytes[viewModel.length - 1] = 0xFF
        for (i in 0 until viewModel.length) {
            viewModel.viewPort.currentChange.changeData(viewModel.model, viewModel.start + i, textBytes[i])
        }
    }
    override fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String { /*@DONE TextFieldStrategy.UpdateViewModelFromModel/1 cs:176-184*/
        var text = viewModel.model.textConverter.convert(viewModel.model, viewModel.start, viewModel.length)?.trim() ?: ""

        // take off quotes
        if (text.startsWith("\"")) text = text.substring(1)
        if (text.endsWith("\"")) text = text.substring(0, text.length - 1)

        return text
    }
    companion object {
        var instance: TextFieldStrategy = /*@INITAUTO TextFieldStrategy.Instance cs:164-164*/ TextFieldStrategy() /*@ENDINIT*/
            private set
        /*@END TextFieldStrategy.Companion*/
    }
    /*@END TextFieldStrategy*/
}

open class NumericFieldStrategy : IFieldArrayElementViewModelStrategy { // cs:187-208
    override val type: ElementContentViewModelType
        get() { /*@DONE NumericFieldStrategy.Type.get cs:189-189*/
            return ElementContentViewModelType.NumericField
        }
    override fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel) { /*@DONE NumericFieldStrategy.UpdateModelFromViewModel/1 cs:191-201*/
        val parsed = Ref(0)
        if (viewModel.content.tryParseInt(parsed)) {
            viewModel.model.writeMultiByteValue(viewModel.start, viewModel.length, viewModel.viewPort.currentChange, parsed.value)
            val run = viewModel.model.getNextRun(viewModel.start) as ITableRun
            val offsets = run.convertByteOffsetToArrayOffset(viewModel.start)
            val error = run.notifyChildren(viewModel.model, viewModel.viewPort.currentChange, offsets.elementIndex, offsets.segmentIndex)
            if (error.isWarning) viewModel.viewPort.raiseMessage(error.errorMessage ?: "")
        } else {
            viewModel.errorText = viewModel.name + " must be an integer."
        }
    }
    override fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String { /*@DONE NumericFieldStrategy.UpdateViewModelFromModel/1 cs:203-207*/
        val number = viewModel.model.readMultiByteValue(viewModel.start, viewModel.length)

        return number.toString()
    }
    companion object {
        var instance: NumericFieldStrategy = /*@INITAUTO NumericFieldStrategy.Instance cs:188-188*/ NumericFieldStrategy() /*@ENDINIT*/
            private set
        /*@END NumericFieldStrategy.Companion*/
    }
    /*@END NumericFieldStrategy*/
}

open class SignedFieldStrategy : IFieldArrayElementViewModelStrategy { // cs:210-233
    override val type: ElementContentViewModelType
        get() { /*@DONE SignedFieldStrategy.Type.get cs:212-212*/
            return ElementContentViewModelType.NumericField
        }
    override fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel) { /*@DONE SignedFieldStrategy.UpdateModelFromViewModel/1 cs:214-224*/
        val parsed = Ref(0)
        if (viewModel.content.tryParseInt(parsed)) {
            viewModel.model.writeMultiByteValue(viewModel.start, viewModel.length, viewModel.viewPort.currentChange, parsed.value)
            val run = viewModel.model.getNextRun(viewModel.start) as ITableRun
            val offsets = run.convertByteOffsetToArrayOffset(viewModel.start)
            val error = run.notifyChildren(viewModel.model, viewModel.viewPort.currentChange, offsets.elementIndex, offsets.segmentIndex)
            if (error.isWarning) viewModel.viewPort.raiseMessage(error.errorMessage ?: "")
        } else {
            viewModel.errorText = viewModel.name + " must be an integer."
        }
    }
    override fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String { /*@DONE SignedFieldStrategy.UpdateViewModelFromModel/1 cs:226-232*/
        var number = viewModel.model.readMultiByteValue(viewModel.start, viewModel.length)
        if (viewModel.length == 1) number = number.toByte().toInt()
        if (viewModel.length == 2) number = number.toShort().toInt()

        return number.toString()
    }
    companion object {
        var instance: SignedFieldStrategy = /*@INITAUTO SignedFieldStrategy.Instance cs:211-211*/ SignedFieldStrategy() /*@ENDINIT*/
            private set
        /*@END SignedFieldStrategy.Companion*/
    }
    /*@END SignedFieldStrategy*/
}

open class AddressFieldStrategy : IFieldArrayElementViewModelStrategy { // cs:235-287
    override val type: ElementContentViewModelType
        get() { /*@DONE AddressFieldStrategy.Type.get cs:237-237*/
            return ElementContentViewModelType.Address
        }
    override fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel) { /*@DONE AddressFieldStrategy.UpdateModelFromViewModel/1 cs:239-264*/
        val content = viewModel.content

        val start = viewModel.start
        val change = viewModel.viewPort.currentChange
        val model = viewModel.model

        val addressRef = Ref(0)
        if (!tryParse(content, addressRef)) {
            addressRef.value = viewModel.model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, content)
            if (addressRef.value == Pointer.null_ && content != "null") {
                viewModel.errorText = "Address should be hexidecimal or an anchor."
                return
            }
        }
        val address = addressRef.value

        val run = model.getNextRun(start) as ITableRun
        val offsets = run.convertByteOffsetToArrayOffset(start)
        val segment = run.elementContent[offsets.segmentIndex]
        if (segment is ArrayRunPointerSegment) {
            if (!segment.destinationDataMatchesPointerFormat(model, change, offsets.segmentStart, address, run.elementContent, -1)) {
                viewModel.errorText = "This pointer must point to " + segment.innerFormat + " data."
            }
        }

        model.updateArrayPointer(change, segment, run.elementContent, offsets.elementIndex, start, address)
    }
    override fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String { /*@DONE AddressFieldStrategy.UpdateViewModelFromModel/1 cs:266-269*/
        val value = viewModel.model.readPointer(viewModel.start)
        return convertAddressToText(value)
    }
    companion object {
        var instance: AddressFieldStrategy = /*@INITAUTO AddressFieldStrategy.Instance cs:236-236*/ AddressFieldStrategy() /*@ENDINIT*/
            private set
        fun tryParse(content: String, value: Ref<Int>): Boolean { /*@DONE AddressFieldStrategy.TryParse/1 cs:271-280*/
            val trimmed = content.trim(PointerRun.pointerStart, PointerRun.pointerEnd, ' ')

            if (!trimmed.tryParseHex(value)) {
                value.value = Pointer.null_
                if (trimmed.lowercase() != "null") return false
            }

            return true
        }
        fun convertAddressToText(address: Int): String { /*@DONE AddressFieldStrategy.ConvertAddressToText/1 cs:282-286*/
            var text = address.toHex(6)
            if (address == Pointer.null_) text = "null"
            return "" + PointerRun.pointerStart + text + PointerRun.pointerEnd
        }
        /*@END AddressFieldStrategy.Companion*/
    }
    /*@END AddressFieldStrategy*/
}

open class HexFieldStrategy : IFieldArrayElementViewModelStrategy { // cs:289-306
    override val type: ElementContentViewModelType
        get() { /*@DONE HexFieldStrategy.Type.get cs:291-291*/
            return ElementContentViewModelType.HexField
        }
    override fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel) { /*@DONE HexFieldStrategy.UpdateModelFromViewModel/1 cs:293-299*/
        val parsed = Ref(0)
        if (viewModel.content.tryParseInt(parsed)) {
            viewModel.model.writeMultiByteValue(viewModel.start, viewModel.length, viewModel.viewPort.currentChange, parsed.value)
        } else {
            viewModel.errorText = "Value should be hexidecimal."
        }
    }
    override fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String { /*@DONE HexFieldStrategy.UpdateViewModelFromModel/1 cs:301-305*/
        val number = viewModel.model.readMultiByteValue(viewModel.start, viewModel.length)
        val text = number.toHex(viewModel.length * 2)
        return "0x" + text
    }
    companion object {
        var instance: HexFieldStrategy = /*@INITAUTO HexFieldStrategy.Instance cs:290-290*/ HexFieldStrategy() /*@ENDINIT*/
            private set
        /*@END HexFieldStrategy.Companion*/
    }
    /*@END HexFieldStrategy*/
}

open class ColorFieldStrategy : IFieldArrayElementViewModelStrategy { // cs:308-323
    override val type: ElementContentViewModelType
        get() { /*@DONE ColorFieldStrategy.Type.get cs:310-310*/
            return ElementContentViewModelType.ColorField
        }
    override fun updateModelFromViewModel(viewModel: FieldArrayElementViewModel) { /*@DONE ColorFieldStrategy.UpdateModelFromViewModel/1 cs:312-316*/
        val colors = PaletteCollection.parseColor(viewModel.content)
        if (colors == null || colors.size == 0) return
        viewModel.model.writeMultiByteValue(viewModel.start, viewModel.length, viewModel.viewPort.currentChange, colors[0].toInt())
    }
    override fun updateViewModelFromModel(viewModel: FieldArrayElementViewModel): String { /*@DONE ColorFieldStrategy.UpdateViewModelFromModel/1 cs:318-322*/
        val color = viewModel.model.readMultiByteValue(viewModel.start, viewModel.length).toShort()
        val text = UncompressedPaletteColor.convert(color) ?: ""
        return text
    }
    companion object {
        var instance: ColorFieldStrategy = /*@INITAUTO ColorFieldStrategy.Instance cs:309-309*/ ColorFieldStrategy() /*@ENDINIT*/
            private set
        /*@END ColorFieldStrategy.Companion*/
    }
    /*@END ColorFieldStrategy*/
}

open class MultiFieldArrayElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:325-422
    private var _theme: String = ""
    private var _content: String = ""
    private var _visible: Boolean = /*@INITAUTO MultiFieldArrayElementViewModel.visible cs:327-327*/ true /*@ENDINIT*/
    private var fields: MutableList<IMultiEnabledArrayElementViewModel> = /*@INITDONE MultiFieldArrayElementViewModel.fields cs:328-328*/ ArrayList() /*@ENDINIT*/
    override var theme: String
        get() { /*@DONE MultiFieldArrayElementViewModel.Theme.get cs:330-330*/
            return _theme
        }
        set(value) { /*@DONE MultiFieldArrayElementViewModel.Theme.set cs:330-330*/
            set(_theme, value, "theme", { _theme = it })
        }
    override var visible: Boolean
        get() { /*@DONE MultiFieldArrayElementViewModel.Visible.get cs:331-331*/
            return _visible
        }
        set(value) { /*@DONE MultiFieldArrayElementViewModel.Visible.set cs:331-331*/
            set(_visible, value, "visible", { _visible = it })
        }
    override val isInError: Boolean
        get() { /*@DONE MultiFieldArrayElementViewModel.IsInError.get cs:332-332*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE MultiFieldArrayElementViewModel.ErrorText.get cs:333-333*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE MultiFieldArrayElementViewModel.ZIndex.get cs:334-334*/
            return 0
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    lateinit var undo: ICommand
        private set
    lateinit var redo: ICommand
        private set
    constructor(port: ViewPort) { /*@DONE MultiFieldArrayElementViewModel.<init>/1 cs:342-342*/
        undo = port.undo
        redo = port.redo
    }
    fun add(field: IMultiEnabledArrayElementViewModel?) { /*@DONE MultiFieldArrayElementViewModel.Add/1 cs:344-347*/
        if (field == null) return
        fields.add(field)
        recalculateBody()
    }
    fun filter(filter: String): Boolean { /*@DONE MultiFieldArrayElementViewModel.Filter/1 cs:350-355*/
        for (element in fields) {
            if (element.name.matchesPartial(filter)) return true
        }
        return false
    }
    var content: String
        get() { /*@DONE MultiFieldArrayElementViewModel.Content.get cs:358-358*/
            return _content
        }
        set(value) { /*@DONE MultiFieldArrayElementViewModel.Content.set cs:359-374*/
            set(_content, value, "content", { _content = it }, { _ ->
                val lines = _content.splitLines()
                for (i in 0 until fields.size) {
                    if (i >= lines.size) break
                    val parts = lines[i].split(':', limit = 2)
                    if (parts.size == 1) continue
                    val newContent = parts[1].trim()
                    val child = fields[i]
                    if (child is FieldArrayElementViewModel) {
                        child.content = newContent
                    } else if (child is ComboBoxArrayElementViewModel) {
                        child.filteringComboOptions.displayText = newContent
                        child.filteringComboOptions.selectConfirm()
                    }
                }
                dataChanged(this, EventArgs.empty)
            })
        }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE MultiFieldArrayElementViewModel.TryCopy/1 cs:377-380*/
        val that = other as? MultiFieldArrayElementViewModel ?: return false
        return _content == that._content && fields.size == that.fields.size && (0 until fields.size).all { i -> fields[i].tryCopy(that.fields[i]) }
    }
    private fun recalculateBody() { /*@DONE MultiFieldArrayElementViewModel.RecalculateBody/1 cs:382-400*/
        val longestName = fields.map { f -> f.name.length }.max()
        val body = StringBuilder()
        var first = true
        for (field in fields) {
            if (!first) body.append(NEW_LINE)
            else first = false

            body.append(field.name.padEnd(longestName, ' '))
            body.append(" : ")
            if (field is FieldArrayElementViewModel) {
                body.append(field.content)
            } else if (field is ComboBoxArrayElementViewModel) {
                body.append(field.filteringComboOptions.displayText)
            }
        }
        _content = body.toString()
        notifyPropertyChanged("content")
    }
    fun getAutoComplete(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE MultiFieldArrayElementViewModel.GetAutoComplete/1 cs:402-421*/
        val parts = line.split(':', limit = 2)
        if (parts.size != 2) return ArrayList()
        val name = parts[0].trim()
        val field = fields.firstOrNull { f -> f.name == name }
        if (field == null) return ArrayList()

        // right now, the field is always something like free text, free number, or free color
        // no auto-complete makes sense
        // but this method is here as a stub in case we add combobox content into the MultiField.
        if (field is ComboBoxArrayElementViewModel) {
            val content = parts[1].trim()
            field.filteringComboOptions.displayText = content
            return field.filteringComboOptions.filteredOptions
                .map { option ->
                    val optionText = option.text ?: ""
            val item = AutocompleteItem(optionText, parts[0] + ": " + optionText)
                    item.characterOffset = parts[0].length
                    item
                }
                .toList()
        }

        return ArrayList()
    }
    /*@END MultiFieldArrayElementViewModel*/
}
