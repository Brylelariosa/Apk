// Port of ViewModels/Map/MapEditorViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class MapEditorViewModel : ViewModelCore, ITabContent { // cs:49-2298
    private lateinit var _format: Format
    private lateinit var _fileSystem: IFileSystem
    private lateinit var _viewPort: IEditableViewPort
    private lateinit var model: IDataModel
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var singletons: Singletons
    private lateinit var _templates: EventTemplate
    private val rnd: java.util.Random = /*@INITDONE MapEditorViewModel.rnd cs:57-57*/ java.util.Random() /*@ENDINIT*/
    val viewPort: IEditableViewPort
        get() { /*@DONE MapEditorViewModel.ViewPort.get cs:59-59*/
            return _viewPort
        }
    val fileSystem: IFileSystem
        get() { /*@DONE MapEditorViewModel.FileSystem.get cs:60-60*/
            return _fileSystem
        }
    val format: Format?
        get() { /*@DONE MapEditorViewModel.Format.get cs:61-61*/
            return _format
        }
    private var blockset: Long = 0L
    private var blockset1: Int = 0
    private var blockset2: Int = 0
    private var _primaryMap: BlockMapViewModel? = null
    var primaryMap: BlockMapViewModel
        get() { /*@DONE MapEditorViewModel.PrimaryMap.get cs:67-67*/
            return _primaryMap!!
        }
        set(value) { /*@DONE MapEditorViewModel.PrimaryMap.set cs:68-71*/
            if (_primaryMap === value) return
            updatePrimaryMap(value)
        }
    private var _showHeaderPanel: Boolean = false
    var showHeaderPanel: Boolean
        get() { /*@DONE MapEditorViewModel.ShowHeaderPanel.get cs:76-76*/
            return _showHeaderPanel
        }
        set(value) { /*@DONE MapEditorViewModel.ShowHeaderPanel.set cs:77-77*/
            set(_showHeaderPanel, value, "showHeaderPanel", { _showHeaderPanel = it })
        }
    fun toggleHeaderPanel() { /*@DONE MapEditorViewModel.ToggleHeaderPanel/1 cs:80-83*/
        showHeaderPanel = !showHeaderPanel
        tutorials.complete(Tutorial.ToolbarButton_EditMapHeader)
    }
    private var _selectedEvent: IEventViewModel? = null
    var selectedEvent: IEventViewModel?
        get() { /*@DONE MapEditorViewModel.SelectedEvent.get cs:87-87*/
            return _selectedEvent
        }
        set(value) { /*@DONE MapEditorViewModel.SelectedEvent.set cs:88-101*/
            if (_selectedEvent === value) return
            _selectedEvent = value
            notifyPropertyChanged("selectedEvent")
            notifyPropertyChanged("showEventPanel")
            showHeaderPanel = false
            _primaryMap?.blockEditor?.showTiles = false
            drawBlockIndex = -1
            collisionIndex = -1
            drawMultipleTiles = false
            blockEditorVisible = false
            tilesToDraw = null
            if (_selectedEvent == null) _primaryMap?.deselectEvent()
        }
    private var _showTemplateSettings: Boolean = false
    var showTemplateSettings: Boolean
        get() { /*@DONE MapEditorViewModel.ShowTemplateSettings.get cs:106-106*/
            return _showTemplateSettings
        }
        set(value) { /*@DONE MapEditorViewModel.ShowTemplateSettings.set cs:107-109*/
            set(_showTemplateSettings, value, "showTemplateSettings", { _showTemplateSettings = it }) { old ->
                if (_showTemplateSettings) tutorials.complete(Tutorial.ToolbarTemplate_ConfigureObject)
            }
        }
    var showEventPanel: Boolean
        get() { /*@DONE MapEditorViewModel.ShowEventPanel.get cs:113-113*/
            return _selectedEvent != null
        }
        set(value) { /*@DONE MapEditorViewModel.ShowEventPanel.set cs:114-117*/
            // so that the UI can hide the panel
            if (value) return
            selectedEvent = null
        }
    var visibleMaps: ObservableCollection<BlockMapViewModel> = /*@INITDONE MapEditorViewModel.VisibleMaps cs:120-120*/ ObservableCollection() /*@ENDINIT*/
        private set
    var mapButtons: ObservableCollection<MapSlider> = /*@INITDONE MapEditorViewModel.MapButtons cs:122-122*/ ObservableCollection() /*@ENDINIT*/
        private set
    var contextItems: ObservableCollection<MenuCommandNonGeneric> = /*@INITDONE MapEditorViewModel.ContextItems cs:124-124*/ ObservableCollection() /*@ENDINIT*/
        private set
    val templates: EventTemplate
        get() { /*@DONE MapEditorViewModel.Templates.get cs:126-126*/
            return _templates
        }
    private var primaryBlocks: Int = 0
        private set
    private var primaryTiles: Int = 0
        private set
    private var _hoverPoint: String = ""
    private var _zoomLevel: String = ""
    var hoverPoint: String
        get() { /*@DONE MapEditorViewModel.HoverPoint.get cs:132-132*/
            return _hoverPoint
        }
        set(value) { /*@DONE MapEditorViewModel.HoverPoint.set cs:132-132*/
            set(_hoverPoint, value, "hoverPoint", { _hoverPoint = it })
        }
    var zoomLevel: String
        get() { /*@DONE MapEditorViewModel.ZoomLevel.get cs:133-133*/
            return _zoomLevel
        }
        set(value) { /*@DONE MapEditorViewModel.ZoomLevel.set cs:133-133*/
            set(_zoomLevel, value, "zoomLevel", { _zoomLevel = it })
        }
    lateinit var tutorials: MapTutorialsViewModel
        private set
    val models: AllMapsModel
        get() { /*@DONE MapEditorViewModel.Models.get cs:137-137*/
            return AllMapsModel.create(model, { _viewPort.changeHistory.currentChange })
        }
    val blocks: IPixelViewModel?
        get() { /*@DONE MapEditorViewModel.Blocks.get cs:141-141*/
            return _primaryMap?.blockPixels
        }
    private var _drawBlockIndex: Int = /*@INITAUTO MapEditorViewModel.drawBlockIndex cs:143-143*/ -10 /*@ENDINIT*/
    var drawBlockIndex: Int
        get() { /*@DONE MapEditorViewModel.DrawBlockIndex.get cs:145-145*/
            return _drawBlockIndex
        }
        set(value) { /*@DONE MapEditorViewModel.DrawBlockIndex.set cs:146-161*/
            set(_drawBlockIndex, value, "drawBlockIndex", { _drawBlockIndex = it }) { old ->
                drawMultipleTiles = false
                if (_drawBlockIndex >= 0) blockEditorVisible = true
                val currentEditor = _primaryMap?.blockEditor
                if (currentEditor != null) {
                    currentEditor.blockIndex = _drawBlockIndex
                    _drawBlockIndex = Math.min(_drawBlockIndex, currentEditor.blockIndex)
                }
                for (map in visibleMaps) {
                    val mapBlockEditor = map.blockEditor
                    if (mapBlockEditor != null) mapBlockEditor.blockIndex = _drawBlockIndex
                    map.collisionHighlight = _collisionIndex
                }
                selectionFromBlock = false
                notifyPropertiesChanged("highlightBlockX", "highlightBlockY", "highlightBlockWidth", "highlightBlockHeight")
            }
        }
    private var _autoUpdateCollision: Boolean = /*@INITAUTO MapEditorViewModel.autoUpdateCollision cs:164-164*/ true /*@ENDINIT*/
    var autoUpdateCollision: Boolean
        get() { /*@DONE MapEditorViewModel.AutoUpdateCollision.get cs:166-166*/
            return _autoUpdateCollision
        }
        set(value) { /*@DONE MapEditorViewModel.AutoUpdateCollision.set cs:167-167*/
            set(_autoUpdateCollision, value, "autoUpdateCollision", { _autoUpdateCollision = it })
        }
    private var _collisionIndex: Int = /*@INITAUTO MapEditorViewModel.collisionIndex cs:170-170*/ -1 /*@ENDINIT*/
    var collisionIndex: Int
        get() { /*@DONE MapEditorViewModel.CollisionIndex.get cs:172-172*/
            return _collisionIndex
        }
        set(value) { /*@DONE MapEditorViewModel.CollisionIndex.set cs:173-186*/
            set(_collisionIndex, value, "collisionIndex", { _collisionIndex = it })
            for (map in visibleMaps) {
                map.collisionHighlight = value
            }
            val tiles = tilesToDraw
            if (tiles != null) {
                for (x in 0 until tiles.size) {
                    for (y in 0 until tiles[x].size) {
                        tiles[x][y] = tiles[x][y] and 0x3FF
                        tiles[x][y] = tiles[x][y] or (_collisionIndex shl 10)
                    }
                }
            }
        }
    val isSingleBlock: Boolean
        get() { /*@DONE MapEditorViewModel.IsSingleBlock.get cs:189-189*/
            val tiles = tilesToDraw
            return tiles != null && tiles.size == 1 && tiles[0].size == 1
        }
    val blockUsageCount: Int
        get() { /*@DONE MapEditorViewModel.BlockUsageCount.get cs:191-204*/
            if (preferredCollisionsPrimary == null) countCollisionForBlocks()
            val layout = LayoutModel(_primaryMap?.getLayout())
            val primaryAddress = layout.primaryBlockset?.start ?: return -1
            val secondaryAddress = layout.secondaryBlockset?.start ?: return -1
            if (!isSingleBlock) return -1

            val isPrimary = _drawBlockIndex < primaryBlocks
            if (isPrimary) {
                return _blockUsageCount[primaryAddress.toLong()][_drawBlockIndex]
            } else {
                return _blockUsageCount[secondaryAddress.toLong()][_drawBlockIndex]
            }
        }
    var collisionOptions: ObservableCollection<String> = /*@INITDONE MapEditorViewModel.CollisionOptions cs:207-207*/ ObservableCollection() /*@ENDINIT*/
        private set
    var blockSelectionToggle: Boolean = false
        private set
    val highlightBlockX: Double
        get() { /*@DONE MapEditorViewModel.HighlightBlockX.get cs:210-210*/
            val scale = blocks?.spriteScale ?: 1.0
            return (_drawBlockIndex % BlockMapViewModel.blocksPerRow) * scale * 16
        }
    val highlightBlockY: Double
        get() { /*@DONE MapEditorViewModel.HighlightBlockY.get cs:211-211*/
            val scale = blocks?.spriteScale ?: 1.0
            return (_drawBlockIndex / BlockMapViewModel.blocksPerRow) * scale * 16
        }
    val highlightBlockWidth: Double
        get() { /*@DONE MapEditorViewModel.HighlightBlockWidth.get cs:212-212*/
            val scale = blocks?.spriteScale ?: 1.0
            val tiles = tilesToDraw
            return 16 * scale * (if (selectionFromBlock && tiles != null) tiles.size else 1) + 2
        }
    val highlightBlockHeight: Double
        get() { /*@DONE MapEditorViewModel.HighlightBlockHeight.get cs:213-213*/
            val scale = blocks?.spriteScale ?: 1.0
            val tiles = tilesToDraw
            return 16 * scale * (if (selectionFromBlock && tiles != null && tiles.size > 0) tiles[0].size else 1) + 2
        }
    private fun animateBlockSelection() { /*@DONE MapEditorViewModel.AnimateBlockSelection/1 cs:215-218*/
        blockSelectionToggle = !blockSelectionToggle
        notifyPropertyChanged("blockSelectionToggle")
    }
    private lateinit var _close: StubCommand
    private lateinit var _undo: StubCommand
    private lateinit var _redo: StubCommand
    private lateinit var backCommand: StubCommand
    private lateinit var forwardCommand: StubCommand
    override val name: String
        get() { /*@DONE MapEditorViewModel.Name.get cs:226-226*/
            return (_primaryMap?.fullName ?: "Map") + (if (history.hasDataChange) "*" else "")
        }
    val fullFileName: String
        get() { /*@DONE MapEditorViewModel.FullFileName.get cs:227-227*/
            return _viewPort.fullFileName
        }
    override var spartanMode: Boolean = false
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE MapEditorViewModel.IsMetadataOnlyChange.get cs:229-229*/
            return false
        }
    override val save: ICommand?
        get() { /*@DONE MapEditorViewModel.Save.get cs:230-230*/
            return _viewPort.save
        }
    override val saveAs: ICommand
        get() { /*@DONE MapEditorViewModel.SaveAs.get cs:231-231*/
            return _viewPort.saveAs
        }
    override val exportBackup: ICommand
        get() { /*@DONE MapEditorViewModel.ExportBackup.get cs:232-232*/
            return _viewPort.exportBackup
        }
    override val undo: ICommand
        get() { /*@DONE MapEditorViewModel.Undo.get cs:233-240*/
            if (!::_undo.isInitialized) {
                _undo = stubCommand({
                    history.undo.execute()
                    tutorials.complete(Tutorial.ToolbarUndo_Undo)
                    hideEvents = false
                    refresh()
                }, { history.undo.canExecute(null) })
            }
            return _undo
        }
    override val redo: ICommand
        get() { /*@DONE MapEditorViewModel.Redo.get cs:241-247*/
            if (!::_redo.isInitialized) {
                _redo = stubCommand({
                    history.redo.execute()
                    hideEvents = false
                    refresh()
                }, { history.redo.canExecute(null) })
            }
            return _redo
        }
    override val copy: ICommand?
        get() { /*@DONE MapEditorViewModel.Copy.get cs:248-248*/
            return null
        }
    override val deepCopy: ICommand
        get() { /*@DONE MapEditorViewModel.DeepCopy.get cs:249-249*/
            return noCommand
        }
    override val clear: ICommand?
        get() { /*@DONE MapEditorViewModel.Clear.get cs:250-250*/
            return null
        }
    override val selectAll: ICommand
        get() { /*@DONE MapEditorViewModel.SelectAll.get cs:251-251*/
            return noCommand
        }
    override val goto: ICommand?
        get() { /*@DONE MapEditorViewModel.Goto.get cs:252-252*/
            return null
        }
    override val resetAlignment: ICommand
        get() { /*@DONE MapEditorViewModel.ResetAlignment.get cs:253-253*/
            return noCommand
        }
    override val back: ICommand
        get() { /*@DONE MapEditorViewModel.Back.get cs:254-254*/
            if (!::backCommand.isInitialized) backCommand = stubCommand({ executeBack() }, { canExecuteBack() })
            return backCommand
        }
    override val forward: ICommand
        get() { /*@DONE MapEditorViewModel.Forward.get cs:255-255*/
            if (!::forwardCommand.isInitialized) forwardCommand = stubCommand({ executeForward() }, { canExecuteForward() })
            return forwardCommand
        }
    override val close: ICommand
        get() { /*@DONE MapEditorViewModel.Close.get cs:257-257*/
            if (!::_close.isInitialized) _close = stubCommand({ closed(this, EventArgs.empty) })
            return _close
        }
    override val diff: ICommand
        get() { /*@DONE MapEditorViewModel.Diff.get cs:259-259*/
            return noCommand
        }
    override val diffLeft: ICommand
        get() { /*@DONE MapEditorViewModel.DiffLeft.get cs:260-260*/
            return noCommand
        }
    override val diffRight: ICommand
        get() { /*@DONE MapEditorViewModel.DiffRight.get cs:261-261*/
            return noCommand
        }
    override val canDuplicate: Boolean
        get() { /*@DONE MapEditorViewModel.CanDuplicate.get cs:262-262*/
            return true
        }
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    fun raiseRequestTabChange(e: TabChangeRequestedEventArgs) { /*@DONE MapEditorViewModel.RaiseRequestTabChange/1 cs:269-269*/
        requestTabChange(this, e)
    }
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE MapEditorViewModel.CanIpsPatchRight.get cs:278-278*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE MapEditorViewModel.CanUpsPatchRight.get cs:279-279*/
            return false
        }
    override fun ipsPatchRight() { /*@DONE MapEditorViewModel.IpsPatchRight/1 cs:280-280*/
        // not supported in the map editor
    }
    override fun upsPatchRight() { /*@DONE MapEditorViewModel.UpsPatchRight/1 cs:281-281*/
        // not supported in the map editor
    }
    fun launchFileLocation(fileSystem: IFileSystem) { /*@DONE MapEditorViewModel.LaunchFileLocation/1 cs:283-283*/
        fileSystem.launchProcess("explorer.exe", "/select,\"" + fullFileName + "\"")
    }
    override fun duplicate() { /*@DONE MapEditorViewModel.Duplicate/1 cs:285-285*/
        duplicate(primaryMap.mapID / 1000, primaryMap.mapID % 1000)
    }
    private fun duplicate(bank: Int, map: Int) { /*@DONE MapEditorViewModel.Duplicate/2 cs:286-300*/
        val dup = _viewPort.createDuplicate()
        dup.requestTabChange += { _, e -> _viewPort.raiseRequestTabChange(e.newTab) }

        // don't check for the viewPort initilazition workload until the model is initialized (for map duplication, this should never really be an issue)
        _viewPort.initializationWorkload.continueWith { _ ->
            // don't try to use the to tab's map editor until it's been fully initialized.
            dup.initializationWorkload.continueWith { _ ->
                singletons.workDispatcher!!.blockOnUIWork {
                    val dupEditor = dup.mapEditor
                    if (dupEditor != null) {
                        dupEditor.updatePrimaryMap(BlockMapViewModel(_fileSystem, tutorials, _viewPort, _format, _templates, bank, map))
                        requestTabChange(this, TabChangeRequestedEventArgs(dupEditor))
                    }
                }
            }
        }
    }
    private fun openScriptInNewTab(address: Int) { /*@DONE MapEditorViewModel.OpenScriptInNewTab/1 cs:302-311*/
        val dup = _viewPort.createDuplicate()
        dup.requestTabChange += { _, e -> _viewPort.raiseRequestTabChange(e.newTab) }
        _viewPort.initializationWorkload.continueWith { _ ->
            singletons.workDispatcher!!.blockOnUIWork {
                dup.goto?.execute(address)
                requestTabChange(this, TabChangeRequestedEventArgs(dup))
            }
        }
    }
    override fun refresh() { /*@DONE MapEditorViewModel.Refresh/1 cs:313-318*/
        _format.refresh()
        val primary = primaryMap
        primary.clearCaches() // needs to reset first, so the width/height is correct when calculating everything else
        updatePrimaryMap(primary)
        for (map in visibleMaps.filter { m -> m !== primary }) map.clearCaches()
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE MapEditorViewModel.TryImport/1 cs:319-319*/
        return false
    }
    private val forwardStack: MutableList<Int> = /*@INITDONE MapEditorViewModel.forwardStack cs:321-321*/ ArrayList() /*@ENDINIT*/
    private val backStack: MutableList<Int> = /*@INITDONE MapEditorViewModel.backStack cs:321-321*/ ArrayList() /*@ENDINIT*/
    private fun canExecuteBack(): Boolean { /*@DONE MapEditorViewModel.CanExecuteBack/1 cs:322-322*/
        return backStack.size > 0
    }
    private fun canExecuteForward(): Boolean { /*@DONE MapEditorViewModel.CanExecuteForward/1 cs:323-323*/
        return forwardStack.size > 0
    }
    private fun executeBack() { /*@DONE MapEditorViewModel.ExecuteBack/1 cs:324-339*/
        if (backStack.size == 0) return
        val previous = backStack[backStack.size - 1]
        backStack.removeAt(backStack.size - 1)
        if (previous == -1) {
            val request = TabChangeRequestedEventArgs(_viewPort)
            requestTabChange(this, request)
            if (request.requestAccepted) (_viewPort as ViewPort).setJumpForwardTab(this)
            return
        }
        val current = _primaryMap
        if (current != null) forwardStack.add(current.mapID)
        if (forwardStack.size == 1) raiseForwardChanged()
        if (backStack.size == 0) raiseBackChanged()
        navigateTo(previous, false)
        tutorials.complete(Tutorial.BackButton_GoBack)
    }
    private fun executeForward() { /*@DONE MapEditorViewModel.ExecuteForward/1 cs:340-354*/
        if (forwardStack.size == 0) return
        val next = forwardStack[forwardStack.size - 1]
        forwardStack.removeAt(forwardStack.size - 1)
        if (next == -1) {
            val request = TabChangeRequestedEventArgs(_viewPort)
            requestTabChange(this, request)
            if (request.requestAccepted) (_viewPort as ViewPort).setJumpBackTab(this)
            return
        }
        val current = _primaryMap
        if (current != null) backStack.add(current.mapID)
        if (backStack.size == 1) raiseBackChanged()
        if (forwardStack.size == 0) raiseForwardChanged()
        navigateTo(next, false)
    }
    private fun navigateTo(mapID: Int, trackChange: Boolean = true) { /*@DONE MapEditorViewModel.NavigateTo/1 cs:355-355*/
        navigateTo(mapID / 1000, mapID % 1000, trackChange)
    }
    private fun navigateTo(bank: Int, map: Int, trackChange: Boolean = true) { /*@DONE MapEditorViewModel.NavigateTo/2 cs:356-380*/
        // special case
        if (bank == 127 && map == 127) {
            executeBack()
            return
        }

        val current = _primaryMap
        if (trackChange && current != null) {
            backStack.add(current.mapID)
            if (backStack.size == 1) raiseBackChanged()
            if (forwardStack.size > 0) {
                forwardStack.clear()
                raiseForwardChanged()
            }
        }

        val template = visibleMaps.firstOrNull { vm -> vm.mapID == (bank * 1000 + map) }
        visibleMaps.clear() // need to clear in case the navigation takes us to a nearby map
        val newMap = BlockMapViewModel(_fileSystem, tutorials, _viewPort, _format, _templates, bank, map)
        newMap.includeBorders = current?.includeBorders ?: true
        newMap.spriteScale = current?.spriteScale ?: .5
        if (template != null) {
            newMap.leftEdge = template.leftEdge
            newMap.topEdge = template.topEdge
        }
        updatePrimaryMap(newMap)
    }
    fun navigateTo(bank: Int, map: Int, x: Int, y: Int) { /*@DONE MapEditorViewModel.NavigateTo/3 cs:382-404*/
        _viewPort.tools?.logTool?.logMessages?.add("Navigate to (" + x + ", " + y + ") in map " + bank + "." + map)
        val current = _primaryMap
        if (current != null) {
            backStack.add(current.mapID)
            if (backStack.size == 1) raiseBackChanged()
            if (forwardStack.size > 0) {
                forwardStack.clear()
                raiseForwardChanged()
            }
        }

        visibleMaps.clear()
        val newMap = BlockMapViewModel(_fileSystem, tutorials, _viewPort, _format, _templates, bank, map)
        newMap.includeBorders = current?.includeBorders ?: true
        newMap.spriteScale = current?.spriteScale ?: .5
        val width = newMap.pixelWidth / newMap.spriteScale / 16
        val height = newMap.pixelHeight / newMap.spriteScale / 16
        val centerX = width / 2
        val centerY = height / 2
        var targetX = x
        var targetY = y
        if (targetX == Int.MIN_VALUE && targetY == Int.MIN_VALUE) {
            targetX = centerX.toInt()
            targetY = centerY.toInt()
        }
        newMap.leftEdge += ((centerX - targetX) * 16 * newMap.spriteScale).toInt()
        newMap.topEdge += ((centerY - targetY) * 16 * newMap.spriteScale).toInt()
        updatePrimaryMap(newMap)
    }
    val autoscrollTiles = Event<EventArgs>()
    var isValidState: Boolean = false
        private set
    private constructor(fileSystem: IFileSystem, viewPort: IEditableViewPort, singletons: Singletons, tutorials: MapTutorialsViewModel, eventTemplate: EventTemplate) { /*@DONE MapEditorViewModel.<init>/1 cs:422-441*/
        _fileSystem = fileSystem
        _viewPort = viewPort
        this.singletons = singletons
        this.tutorials = tutorials
        model = viewPort.model!!
        history = viewPort.changeHistory
        history.undo.canExecuteChanged += { _, _ -> if (::_undo.isInitialized) _undo.raiseCanExecuteChanged() }
        history.redo.canExecuteChanged += { _, _ -> if (::_redo.isInitialized) _redo.raiseCanExecuteChanged() }
        history.bind("hasDataChange") { _, _ -> notifyPropertyChanged("name") }
        val isFRLG = model.isFRLG()
        primaryTiles = if (isFRLG) 640 else 512
        primaryBlocks = primaryTiles
        _format = Format(model)

        _templates = eventTemplate
        val firstMap = BlockMapViewModel(fileSystem, tutorials, viewPort, _format, _templates, 3, 0)
        firstMap.allOverworldSprites = eventTemplate.overworldGraphics
        updatePrimaryMap(firstMap)
        for (i in 0 until 0x40) collisionOptions.add(i.toHex(2))

        zoomLevel = "1x Zoom"
        fixLayoutTable() // quick 1-time check for adding unknown layouts
    }
    fun switchToViewPortOnNextBackNavigation() { /*@DONE MapEditorViewModel.SwitchToViewPortOnNextBackNavigation/1 cs:445-452*/
        backStack.add(-1)
        if (backStack.size == 1) raiseBackChanged()
        if (forwardStack.size > 0) {
            forwardStack.clear()
            raiseForwardChanged()
        }
    }
    fun addBackNavigation(id: Int) { /*@DONE MapEditorViewModel.AddBackNavigation/1 cs:454-461*/
        backStack.add(id)
        if (forwardStack.size > 0) {
            forwardStack.clear()
            raiseForwardChanged()
        }
        if (backStack.size == 1) raiseBackChanged()
    }
    fun addForwardNavigation(id: Int) { /*@DONE MapEditorViewModel.AddForwardNavigation/1 cs:463-470*/
        forwardStack.add(id)
        if (backStack.size > 0) {
            backStack.clear()
            raiseBackChanged()
        }
        if (forwardStack.size == 1) raiseForwardChanged()
    }
    fun gotoMapNames() { /*@DONE MapEditorViewModel.GotoMapNames/1 cs:472-477*/
        val table = model.getTable(HardcodeTablesModel.mapNameTable) ?: return
        val index = primaryMap.selectedNameIndex
        _viewPort.goto?.execute(table.start + index * table.elementLength)
    }
    private fun updatePrimaryMap(map: BlockMapViewModel?) { /*@DONE MapEditorViewModel.UpdatePrimaryMap/1 cs:479-556*/
        var target: BlockMapViewModel = map ?: return
        if (!target.isValidMap) {
            val existingPrimary = _primaryMap
            if (existingPrimary != null && existingPrimary.isValidMap) return
            val fallback = visibleMaps.firstOrNull { vis -> vis.isValidMap }
            if (fallback == null) {
                onError(this, "Couldn't find a valid visible map.")
                close.execute()
                return
            }
            target = fallback
        }
        if (_primaryMap != null) updateMapShortcut(target)

        blockset = updateBlockset(target.mapID)
        if (blockset == -1L) return
        if (blockset == Pointer.null_.toLong()) return
        // update the primary map
        target.isSelected = true
        val candidate = target
        val loadedMap = visibleMaps.firstOrNull { existing -> existing.updateFrom(candidate) }
        if (loadedMap != null) target = loadedMap
        val previousPrimary = _primaryMap
        if (previousPrimary !== target) {
            if (previousPrimary != null) {
                previousPrimary.neighborsChanged -= neighborsChangedHandler
                previousPrimary.propertyChanged -= propertyChangedHandler
                previousPrimary.collisionHighlight = -1
                previousPrimary.autoscrollTiles -= autoscrollTilesHandler
                previousPrimary.hideSidePanels -= hideSidePanelsHandler
                previousPrimary.requestChangeMap -= requestChangeMapHandler
                previousPrimary.requestClearMapCaches -= clearMapCachesHandler
                previousPrimary.deselectEvent()
                previousPrimary.showBeneath = false
                previousPrimary.isSelected = false
            }
            _primaryMap = target
            target.blockEditor?.blockIndex = _drawBlockIndex
            notifyPropertyChanged("primaryMap")
            target.neighborsChanged += neighborsChangedHandler
            target.propertyChanged += propertyChangedHandler
            target.collisionHighlight = _collisionIndex
            target.autoscrollTiles += autoscrollTilesHandler
            target.hideSidePanels += hideSidePanelsHandler
            target.requestChangeMap += requestChangeMapHandler
            target.requestClearMapCaches += clearMapCachesHandler
            target.showBeneath = showBeneath
            target.isSelected = true
            _selectedEvent = null
            notifyPropertiesChanged("blocks", "name", "showEventPanel")
        }

        // update the neighbor maps
        val oldMaps = visibleMaps.toList()
        var neighborDepth = 1
        if (target.spriteScale <= .5) neighborDepth = 2
        if (target.spriteScale <= .25) neighborDepth = 3
        if (target.spriteScale <= .125) neighborDepth = 4
        if (target.spriteScale <= .0625) neighborDepth = 5
        val gathered = getMapNeighbors(target, neighborDepth).toMutableList()
        gathered.add(target)
        val mapDict = LinkedHashMap<Int, BlockMapViewModel>()
        gathered.forEach { m -> mapDict[m.mapID] = m }
        val newMaps = mapDict.values.toList()
        for (oldM in oldMaps) if (!newMaps.any { newM -> oldM.mapID == newM.mapID }) visibleMaps.remove(oldM)
        for (newM in newMaps) {
            var match = false
            for (existingM in visibleMaps.toList()) {
                if (existingM.updateFrom(newM)) {
                    match = true
                    break
                }
            }
            if (!match) visibleMaps.add(newM)
        }

        refreshConnectionButtons()

        updateBlockBagVisual()
        isValidState = true
    }
    private fun refreshConnectionButtons() { /*@DONE MapEditorViewModel.RefreshConnectionButtons/1 cs:558-565*/
        val newButtons = primaryMap.getMapSliders().toList()
        var i = 0
        while (i < mapButtons.size && i < newButtons.size) {
            if (!mapButtons[i].tryUpdate(newButtons[i])) mapButtons[i] = newButtons[i]
            i++
        }
        for (j in mapButtons.size until newButtons.size) mapButtons.add(newButtons[j])
        while (mapButtons.size > newButtons.size) mapButtons.removeAt(mapButtons.size - 1)
    }
    private fun updateMapShortcut(map: BlockMapViewModel) { /*@DONE MapEditorViewModel.UpdateMapShortcut/1 cs:567-575*/
        val groupIndex = map.mapID / 1000
        val mapIndex = map.mapID % 1000
        val shortcut = model.gotoShortcuts.firstOrNull { item -> item.displayText == "Maps" }
        val index = if (shortcut == null) -1 else model.gotoShortcuts.indexOf(shortcut)
        val newShortcut = GotoShortcutModel("data.maps.banks/" + groupIndex + "/maps/" + mapIndex + "/map/0/layout/0/blockmap/", "maps.bank" + groupIndex + "." + map.fullName, "Maps")
        model.updateGotoShortcut(index, newShortcut)
        requestRefreshGotoShortcuts(this, EventArgs.empty)
    }
    private fun primaryMapNeighborsChanged(sender: Any?, e: EventArgs) { /*@DONE MapEditorViewModel.PrimaryMapNeighborsChanged/1 cs:577-579*/
        updatePrimaryMap(_primaryMap)
    }
    private fun primaryMapPropertyChanged(sender: Any, e: PropertyChangedEventArgs) { /*@DONE MapEditorViewModel.PrimaryMapPropertyChanged/1 cs:581-594*/
        val map = sender as BlockMapViewModel
        if (e.propertyName == "selectedEvent") {
            if (map.selectedEvent !== _selectedEvent) {
                selectedEvent = map.selectedEvent
            }
        } else if (e.propertyName == "fullName") {
            notifyPropertyChanged("name")
        } else if (e.propertyName == "blockPixels") {
            notifyPropertyChanged("blocks")
        } else if (e.propertyName == "blockRenders") {
            fillMultiTileRender()
        }
    }
    private fun getMapNeighbors(map: BlockMapViewModel, recursionLevel: Int): Iterable<BlockMapViewModel> { /*@DONE MapEditorViewModel.GetMapNeighbors/1 cs:596-627*/
        if (recursionLevel < 1) return emptyList()
        if (spartanMode) {
            // return only neighbors based on the current map position
            val centerX = (map.leftEdge + map.rightEdge) / 2
            val centerY = (map.topEdge + map.bottomEdge) / 2
            if (centerX > 0 && map.leftEdge > map.topEdge && map.leftEdge > -map.bottomEdge) return map.getNeighbors(MapDirection.Left)
            if (centerX < 0 && map.rightEdge < map.bottomEdge && map.rightEdge < -map.topEdge) return map.getNeighbors(MapDirection.Right)
            if (centerY > 0) return map.getNeighbors(MapDirection.Up)
            if (centerY < 0) return map.getNeighbors(MapDirection.Down)
            return emptyList()
        }
        val directions = listOf(MapDirection.Up, MapDirection.Down, MapDirection.Left, MapDirection.Right, MapDirection.Dive, MapDirection.Emerge)

        val newMaps = LinkedHashMap<Int, BlockMapViewModel>()
        for (direction in directions) {
            for (child in map.getNeighbors(direction)) {
                if (newMaps.containsKey(child.mapID)) continue
                newMaps[child.mapID] = child
            }
        }
        if (recursionLevel > 1) {
            for (key in newMaps.keys.toList()) {
                val existing = newMaps[key] ?: continue
                if (existing.zIndex < 0) continue
                for (child in getMapNeighbors(existing, recursionLevel - 1)) {
                    if (newMaps.containsKey(child.mapID)) continue
                    newMaps[child.mapID] = child
                }
            }
        }
        return newMaps.values.toList()
    }
    private fun preferLoaded(maps: Iterable<BlockMapViewModel>): Iterable<BlockMapViewModel> { /*@DONE MapEditorViewModel.PreferLoaded/1 cs:629-634*/
        val result = ArrayList<BlockMapViewModel>()
        for (map in maps) {
            val match = visibleMaps.firstOrNull { m -> m.mapID == map.mapID }
            result.add(match ?: map)
        }
        return result
    }
    private var cursorX: Double = 0.0
    private var cursorY: Double = 0.0
    private var deltaX: Double = 0.0
    private var deltaY: Double = 0.0
    val autoscrollBlocks = Event<EventArgs>()
    private var _showHighlightCursor: Boolean = false
    var showHighlightCursor: Boolean
        get() { /*@DONE MapEditorViewModel.ShowHighlightCursor.get cs:642-642*/
            return _showHighlightCursor
        }
        set(value) { /*@DONE MapEditorViewModel.ShowHighlightCursor.set cs:642-642*/
            set(_showHighlightCursor, value, "showHighlightCursor", { _showHighlightCursor = it })
        }
    private var _highlightCursorX: Double = 0.0
    private var _highlightCursorY: Double = 0.0
    private var _highlightCursorWidth: Double = 0.0
    private var _highlightCursorHeight: Double = 0.0
    var highlightCursorX: Double
        get() { /*@DONE MapEditorViewModel.HighlightCursorX.get cs:645-645*/
            return _highlightCursorX
        }
        set(value) { /*@DONE MapEditorViewModel.HighlightCursorX.set cs:645-645*/
            set(_highlightCursorX, value, "highlightCursorX", { _highlightCursorX = it })
        }
    var highlightCursorY: Double
        get() { /*@DONE MapEditorViewModel.HighlightCursorY.get cs:646-646*/
            return _highlightCursorY
        }
        set(value) { /*@DONE MapEditorViewModel.HighlightCursorY.set cs:646-646*/
            set(_highlightCursorY, value, "highlightCursorY", { _highlightCursorY = it })
        }
    var highlightCursorWidth: Double
        get() { /*@DONE MapEditorViewModel.HighlightCursorWidth.get cs:647-647*/
            return _highlightCursorWidth
        }
        set(value) { /*@DONE MapEditorViewModel.HighlightCursorWidth.set cs:647-647*/
            set(_highlightCursorWidth, value, "highlightCursorWidth", { _highlightCursorWidth = it })
        }
    var highlightCursorHeight: Double
        get() { /*@DONE MapEditorViewModel.HighlightCursorHeight.get cs:648-648*/
            return _highlightCursorHeight
        }
        set(value) { /*@DONE MapEditorViewModel.HighlightCursorHeight.set cs:648-648*/
            set(_highlightCursorHeight, value, "highlightCursorHeight", { _highlightCursorHeight = it })
        }
    private var _showBeneath: Boolean = false
    var showBeneath: Boolean
        get() { /*@DONE MapEditorViewModel.ShowBeneath.get cs:651-651*/
            return _showBeneath
        }
        set(value) { /*@DONE MapEditorViewModel.ShowBeneath.set cs:651-651*/
            set(_showBeneath, value, "showBeneath", { _showBeneath = it }) { old -> _primaryMap?.showBeneath = _showBeneath }
        }
    private var _hideEvents: Boolean = false
    var hideEvents: Boolean
        get() { /*@DONE MapEditorViewModel.HideEvents.get cs:655-655*/
            return _hideEvents
        }
        set(value) { /*@DONE MapEditorViewModel.HideEvents.set cs:655-658*/
            set(_hideEvents, value, "hideEvents", { _hideEvents = it }) { old ->
                for (m in visibleMaps) m.showEvents = if (_hideEvents) MapDisplayOptions.NoEvents else MapDisplayOptions.AllEvents
                tutorials.complete(Tutorial.Ctrl_HideEvents)
            }
        }
    fun hover(x: Double, y: Double): Any? { /*@DONE MapEditorViewModel.Hover/1 cs:665-696*/
        val map = mapUnderCursor(x, y) ?: return emptyTooltip
        val tiles = tilesToDraw
        if (use9Grid && isValid9GridSelection) {
            val p = toBoundedMapTilePosition(map, x, y, 2, 2)
            updateHover(map, p.x, p.y, 2, 2)
        } else if (drawMultipleTiles && tiles != null) {
            var p = toBoundedMapTilePosition(map, x, y, tiles.size, tiles[0].size)
            if (interactionType == PrimaryInteractionType.Draw) {
                while (Math.abs(p.x - drawSource.x) % tiles.size != 0) p -= Point(1, 0)
                while (Math.abs(p.y - drawSource.y) % tiles[0].size != 0) p -= Point(0, 1)
            }
            updateHover(map, p.x, p.y, tiles.size, tiles[0].size)
        } else {
            val p = toBoundedMapTilePosition(map, x, y, 1, 1)
            map.hoverPoint = toPixelPosition(map, x, y)
            if (updateHover(map, p.x, p.y, 1, 1)) {
                if (!spartanMode && interactionType == PrimaryInteractionType.None) {
                    val matches = map.eventsUnderCursor(x, y, false).filterIsInstance<BaseEventViewModel>()
                    if (matches.size > 0) {
                        return showEventHover(map, matches)
                    } else {
                        return emptyTooltip
                    }
                } else {
                    return emptyTooltip
                }
            }
            return null
        }
        return emptyTooltip
    }
    private fun updateHover(map: BlockMapViewModel, left: Int, top: Int, width: Int, height: Int): Boolean { /*@DONE MapEditorViewModel.UpdateHover/1 cs:701-727*/
        val prevX = _highlightCursorX
        val prevY = _highlightCursorY
        val prevW = _highlightCursorWidth
        val prevH = _highlightCursorHeight

        val border = map.getBorderThickness()
        showHighlightCursor = true

        // limit selection right/bottom to the map
        val mapWidth = map.pixelWidth / 16 - border.west - border.east
        val mapHeight = map.pixelHeight / 16 - border.north - border.south
        var w = width
        var h = height
        while (left + w > mapWidth && w > 1) w--
        while (top + h > mapHeight && h > 1) h--

        highlightCursorX = (left + border.west + w / 2.0) * 16 * map.spriteScale + map.leftEdge
        highlightCursorY = (top + border.north + h / 2.0) * 16 * map.spriteScale + map.topEdge
        highlightCursorWidth = w * 16 * map.spriteScale + 4
        highlightCursorHeight = h * 16 * map.spriteScale + 4

        hoverPoint = "(" + left + ", " + top + ")"
        if (w > 1 || h > 1) hoverPoint += " [" + w + "x" + h + "]"

        if (prevX != _highlightCursorX) return true
        if (prevY != _highlightCursorY) return true
        if (prevW != _highlightCursorWidth) return true
        return prevH != _highlightCursorHeight
    }
    fun dragDown(x: Double, y: Double) { /*@DONE MapEditorViewModel.DragDown/1 cs:729-734*/
        val primary = primaryMap
        primary.blockEditor?.showTiles = false
        primary.borderEditor.showBorderPanel = false
        cursorX = x
        cursorY = y
        deltaX = 0.0
        deltaY = 0.0
    }
    fun dragMove(x: Double, y: Double, isMiddleClickMap: Boolean) { /*@DONE MapEditorViewModel.DragMove/1 cs:736-746*/
        deltaX += x - cursorX
        deltaY += y - cursorY
        val intX = deltaX.toInt()
        val intY = deltaY.toInt()
        deltaX -= intX
        deltaY -= intY
        cursorX = x
        cursorY = y
        pan(intX, intY)
        if ((intX != 0 || intY != 0) && isMiddleClickMap) tutorials.complete(Tutorial.MiddleClick_PanMap)
        if (isMiddleClickMap) hover(x, y)
    }
    fun dragUp(x: Double, y: Double) { /*@DONE MapEditorViewModel.DragUp/1 cs:748-751*/
        val map = mapUnderCursor(x, y)
        if (map != null) updatePrimaryMap(map)
    }
    private var interactionType: PrimaryInteractionType = PrimaryInteractionType.None
    fun primaryDown(x: Double, y: Double, click: PrimaryInteractionStart) { /*@DONE MapEditorViewModel.PrimaryDown/1 cs:756-782*/
        primaryMap.blockEditor?.showTiles = false
        primaryMap.borderEditor.showBorderPanel = false
        val map = mapUnderCursor(x, y)
        if (map == null) {
            interactionType = PrimaryInteractionType.None
            return
        }
        primaryMap = map

        val prevEvent = selectedEvent
        val ev = map.eventsUnderCursor(x, y)
        if (ev.size > 0) {
            eventDown(ev.last(), click)
            return
        } else {
            if (prevEvent != null) tutorials.complete(Tutorial.ClickMap_UnselectEvent)
            selectedEvent = null
        }

        showHeaderPanel = false
        if (click == PrimaryInteractionStart.DoubleClick && showBeneath) {
            primaryMap.surfConnection.followConnection()
            return
        }
        if (drawDown(x, y, click)) waveFunctionActive?.cancel()
    }
    fun primaryMove(x: Double, y: Double) { /*@DONE MapEditorViewModel.PrimaryMove/1 cs:784-789*/
        if (interactionType == PrimaryInteractionType.Draw) drawMove(x, y)
        if (interactionType == PrimaryInteractionType.RectangleDraw) rectangleDrawMove(x, y)
        if (interactionType == PrimaryInteractionType.Draw9Grid) draw9Grid(x, y)
        if (interactionType == PrimaryInteractionType.Event) eventMove(x, y)
    }
    fun primaryUp(x: Double, y: Double) { /*@DONE MapEditorViewModel.PrimaryUp/1 cs:791-797*/
        if (interactionType == PrimaryInteractionType.Event || withinEventCreationInteraction) eventUp(x, y)
        else if (interactionType == PrimaryInteractionType.Draw) drawUp(x, y)
        else if (interactionType == PrimaryInteractionType.RectangleDraw) drawUp(x, y)
        else if (interactionType == PrimaryInteractionType.Draw9Grid) drawUp(x, y)
        interactionType = PrimaryInteractionType.None
    }
    private var drawSource: Point = Point()
    private var lastDraw: Point = Point()
    private fun drawDown(x: Double, y: Double, click: PrimaryInteractionStart): Boolean { /*@DONE MapEditorViewModel.DrawDown/1 cs:800-832*/
        var didDraw = true
        interactionType = PrimaryInteractionType.Draw
        if ((click.value and PrimaryInteractionStart.ControlClick.value) != 0) interactionType = PrimaryInteractionType.RectangleDraw
        if (use9Grid && isValid9GridSelection) {
            interactionType = PrimaryInteractionType.Draw9Grid
            val grid = tilesToDraw
            if (grid != null) primaryMap.prepareFor9GridDraw(grid)
        }
        val map = mapUnderCursor(x, y)
        if ((click.value and PrimaryInteractionStart.DoubleClick.value) != 0) {
            if (_drawBlockIndex < 0 && _collisionIndex < 0) {
                // nothing to paint
                interactionType = PrimaryInteractionType.None
            } else {
                if (map != null && !drawMultipleTiles) {
                    if (_blockBag.contains(_drawBlockIndex)) {
                        map.paintBlockBag(history.currentChange, _blockBag, _collisionIndex, x, y)
                    } else {
                        map.paintBlock(history.currentChange, _drawBlockIndex, _collisionIndex, x, y)
                    }
                    tutorials.complete(Tutorial.DoubleClick_PaintBlock)
                }
            }
            hover(x, y)
        } else {
            drawSource = if (map == null) Point(0, 0) else toBoundedMapTilePosition(map, x, y, 1, 1)
            lastDraw = drawSource
            if (click == PrimaryInteractionStart.ControlClick) rectangleDrawMove(x, y)
            else if (interactionType == PrimaryInteractionType.Draw9Grid) draw9Grid(x, y)
            else if (click == PrimaryInteractionStart.Click) didDraw = drawMove(x, y)
        }
        return didDraw
    }
    private fun drawMove(x: Double, y: Double): Boolean { /*@DONE MapEditorViewModel.DrawMove/1 cs:834-865*/
        var didDraw = false
        val map = mapUnderCursor(x, y)
        if (map != null) {
            map.deferPropertyNotifications().using {
                val tiles = tilesToDraw
                if (drawMultipleTiles && tiles != null) {
                    val tilePosition = toBoundedMapTilePosition(map, x, y, tiles.size, tiles[0].size)
                    map.drawBlocks(history.currentChange, tiles, drawSource, tilePosition)
                    didDraw = true
                } else {
                    val tilePosition = toBoundedMapTilePosition(map, x, y, 1, 1)
                    if (_drawBlockIndex < 0 && _collisionIndex < 0) {
                        if (lastDraw != tilePosition) {
                            resetFromRectangleBackup()
                            lastDraw = tilePosition
                            fillBackup()
                            swapBlocks(lastDraw, drawSource)
                            didDraw = true
                        }
                    } else if (_blockBag.contains(_drawBlockIndex)) {
                        map.drawBlock(history.currentChange, rnd.from(_blockBag), _collisionIndex, x, y)
                        didDraw = true
                    } else {
                        map.drawBlock(history.currentChange, _drawBlockIndex, _collisionIndex, x, y)
                        didDraw = true
                    }
                }
            }
        }
        hover(x, y)
        return didDraw
    }
    private fun rectangleDrawMove(x: Double, y: Double) { /*@DONE MapEditorViewModel.RectangleDrawMove/1 cs:867-879*/
        val map = _primaryMap
        if (tilesToDraw == null && _drawBlockIndex < 0 && _collisionIndex < 0) {
            interactionType = PrimaryInteractionType.None
        } else if (map != null) {
            resetFromRectangleBackup()
            lastDraw = toBoundedMapTilePosition(map, x, y, 1, 1)
            if (lastDraw != drawSource) tutorials.complete(Tutorial.ControlClick_FillRect)
            fillBackup()
            fillRect()
            updateHover(map, Math.min(drawSource.x, lastDraw.x), Math.min(drawSource.y, lastDraw.y), Math.abs(drawSource.x - lastDraw.x) + 1, Math.abs(drawSource.y - lastDraw.y) + 1)
        }
    }
    private fun draw9Grid(x: Double, y: Double) { /*@DONE MapEditorViewModel.Draw9Grid/1 cs:881-885*/
        val map = mapUnderCursor(x, y)
        val grid = tilesToDraw
        if (map != null && grid != null) map.draw9Grid(history.currentChange, grid, x, y)
        hover(x, y)
    }
    private fun drawUp(x: Double, y: Double) { /*@DONE MapEditorViewModel.DrawUp/1 cs:887-892*/
        rectangleBackup = null
        history.changeCompleted()
        interactionType = PrimaryInteractionType.None
        primaryMap.redrawEvents() // editing blocks in a map can draw over events, we need to redraw events now that we have new blocks
    }
    fun eventDown(ev: IEventViewModel, click: PrimaryInteractionStart) { /*@DONE MapEditorViewModel.EventDown/1 cs:894-939*/
        selectedEvent = ev
        val selected = selectedEvent
        if (selected is WarpEventViewModel && click == PrimaryInteractionStart.DoubleClick) {
            val banks = AllMapsModel.create(model)
            interactionType = PrimaryInteractionType.None
            if (selected.bank == 127 && selected.map == 127) { // special case -> 'warp back'
                navigateTo(selected.bank, selected.map)
                tutorials.complete(Tutorial.DoubleClick_FollowWarp)
            } else if (selected.bank < 0 || selected.bank >= banks.count || banks[selected.bank] == null) {
                onError(this, "Could not load map bank " + selected.bank)
            } else {
                val bankModel = banks[selected.bank]!!
                if (selected.map < 0 || selected.map >= bankModel.count || bankModel[selected.map] == null) {
                    onError(this, "Could not load map " + selected.map + " in bank " + selected.bank)
                } else {
                    navigateTo(selected.bank, selected.map)
                    tutorials.complete(Tutorial.DoubleClick_FollowWarp)
                }
            }
        } else if (click == PrimaryInteractionStart.DoubleClick && selected is ObjectEventViewModel) {
            if (0 <= selected.scriptAddress && selected.scriptAddress < model.count) {
                _viewPort.gotoScript(selected.scriptAddress)
            } else {
                onError(this, "Not a valid script address.")
            }
            tutorials.complete(Tutorial.DoubleClickEvent_SeeScript)
        } else if (click == PrimaryInteractionStart.DoubleClick && selected is ScriptEventViewModel) {
            if (0 <= selected.scriptAddress && selected.scriptAddress < model.count) {
                _viewPort.gotoScript(selected.scriptAddress)
            } else {
                onError(this, "Not a valid script address.")
            }
            tutorials.complete(Tutorial.DoubleClickEvent_SeeScript)
        } else if (
            click == PrimaryInteractionStart.DoubleClick &&
            selected is SignpostEventViewModel &&
            selected.showPointer &&
            selected.pointer >= 0 &&
            selected.pointer < model.count
        ) {
            _viewPort.gotoScript(selected.pointer)
            tutorials.complete(Tutorial.DoubleClickEvent_SeeScript)
        } else {
            tutorials.complete(Tutorial.LeftClick_SelectEvent)
            interactionType = PrimaryInteractionType.Event
        }
    }
    private fun eventMove(x: Double, y: Double) { /*@DONE MapEditorViewModel.EventMove/1 cs:941-951*/
        val map = mapUnderCursor(x, y)
        if (map != null && map === _primaryMap) {
            createEventForCreationInteraction(eventCreationType)
            val current = selectedEvent
            if (current != null) {
                map.updateEventLocation(current, x, y)
                tutorials.complete(Tutorial.DragEvent_MoveEvent)
            }
        }
        hover(x, y)
    }
    fun eventUp(x: Double, y: Double) { /*@DONE MapEditorViewModel.EventUp/1 cs:953-978*/
        val map = mapUnderCursor(x, y)
        val current = selectedEvent
        if (current is ObjectEventViewModel) {
            for (neighbor in preferLoaded(getMapNeighbors(primaryMap, 1))) neighbor.updateClone(primaryMap, current)
        }

        history.changeCompleted()
        if (!withinEventCreationInteraction) return
        withinEventCreationInteraction = false
        updatePrimaryMap(primaryMap) // re-add neighbors
        if (eventCreationType == EventCreationType.Object) {
            // User clicked on the event creation button,
            // but then didn't drag to anywhere.
            // Open the popup.
            showTemplateSettings = true
            eventCreationType = EventCreationType.None
        }
        if (eventCreationType == EventCreationType.WaveFunction) {
            eventCreationType = EventCreationType.None
            // user wants to do a wave function collapse at this position
            if (map == null || map !== primaryMap) return
            if (waveFunctionPrimary == null) calculateWaveCollapseProbabilities()
            val cancellation = CancellationTokenSource()
            waveFunctionActive = cancellation
            map.paintWaveFunction(history.currentChange, x, y, { xx, yy -> runWaveFunctionCollapseWithCollision(xx, yy) }, cancellation.token)
        }
    }
    private var waveFunctionActive: CancellationTokenSource? = null
    private var rectangleBackup: Array<IntArray>? = null
    private fun resetFromRectangleBackup() { /*@DONE MapEditorViewModel.ResetFromRectangleBackup/1 cs:989-997*/
        val backup = rectangleBackup ?: return
        var left = lastDraw.x
        var right = drawSource.x
        var top = lastDraw.y
        var bottom = drawSource.y
        if (left > right) { val swap = left; left = right; right = swap }
        if (top > bottom) { val swap = top; top = bottom; bottom = swap }
        val width = right - left + 1
        val height = bottom - top + 1
        primaryMap.repeatBlocks({ history.currentChange }, backup, left, top, width, height, false)
    }
    private fun fillBackup() { /*@DONE MapEditorViewModel.FillBackup/1 cs:1002-1009*/
        var left = lastDraw.x
        var right = drawSource.x
        var top = lastDraw.y
        var bottom = drawSource.y
        if (left > right) { val swap = left; left = right; right = swap }
        if (top > bottom) { val swap = top; top = bottom; bottom = swap }
        val width = right - left + 1
        val height = bottom - top + 1
        rectangleBackup = primaryMap.readRectangle(left, top, width, height)
    }
    private fun fillRect() { /*@DONE MapEditorViewModel.FillRect/1 cs:1014-1027*/
        var left = lastDraw.x
        var right = drawSource.x
        var top = lastDraw.y
        var bottom = drawSource.y
        if (left > right) { val swap = left; left = right; right = swap }
        if (top > bottom) { val swap = top; top = bottom; bottom = swap }
        val width = right - left + 1
        val height = bottom - top + 1

        val tiles = tilesToDraw
        val singleSelect = tiles == null || (tiles.size == 1 && tiles[0].size == 1)
        if (singleSelect && _blockBag.contains(_drawBlockIndex)) {
            primaryMap.repeatBlock({ history.currentChange }, _blockBag, _collisionIndex, left, top, width, height, true)
        } else {
            primaryMap.repeatBlocks({ history.currentChange }, tiles, left, top, width, height, true)
        }
    }
    private fun swapBlocks(a: Point, b: Point) { /*@DONE MapEditorViewModel.SwapBlocks/1 cs:1029-1035*/
        val p1 = primaryMap.readRectangle(a.x, a.y, 1, 1)
        val p2 = primaryMap.readRectangle(b.x, b.y, 1, 1)
        primaryMap.repeatBlocks({ history.currentChange }, p1, b.x, b.y, 1, 1, false)
        primaryMap.repeatBlocks({ history.currentChange }, p2, a.x, a.y, 1, 1, true)
        if (a != b) tutorials.complete(Tutorial.DragMap_SwapBlock)
    }
    private var withinEventCreationInteraction: Boolean = /*@INITAUTO MapEditorViewModel.withinEventCreationInteraction cs:1041-1041*/ false /*@ENDINIT*/
    private var eventCreationType: EventCreationType = EventCreationType.None
    fun startEventCreationInteraction(type: EventCreationType) { /*@DONE MapEditorViewModel.StartEventCreationInteraction/1 cs:1043-1050*/
        interactionType = PrimaryInteractionType.Event
        visibleMaps.clear()
        visibleMaps.add(primaryMap)
        mapButtons.clear()
        eventCreationType = type
        withinEventCreationInteraction = true
    }
    private fun createEventForCreationInteraction(type: EventCreationType) { /*@DONE MapEditorViewModel.CreateEventForCreationInteraction/1 cs:1052-1099*/
        if (type == EventCreationType.None) return
        if (type == EventCreationType.WaveFunction) return
        eventCreationType = EventCreationType.None
        val primary = primaryMap
        if (type == EventCreationType.Object) {
            val objectEvent = primary.createObjectEvent(0, Pointer.null_) ?: return
            if (_templates.selectedTemplate == TemplateType.Trainer) {
                var dexName = HardcodeTablesModel.regionalDexTableName
                if (_templates.useNationalDex) dexName = HardcodeTablesModel.nationalDexTableName
                if (model.getTable(dexName) == null) {
                    _viewPort.raiseError("Cannot create trainer without pokedex table " + dexName + ".")
                    return
                }
            }
            _templates.applyTemplate(objectEvent, history.currentChange)
            selectedEvent = objectEvent
            if (objectEvent.scriptAddress != Pointer.null_) primary.informCreate(DataMovedEventArgs("Object-Event", objectEvent.scriptAddress))
            tutorials.complete(Tutorial.ToolbarTemplate_CreateObject)
        } else if (type == EventCreationType.Warp) {
            var desiredBank = primary.mapID / 1000
            var desiredMap = primary.mapID % 1000
            if (backStack.size > 0) {
                val last = backStack[backStack.size - 1]
                if (last >= 0) {
                    desiredBank = last / 1000
                    desiredMap = last % 1000
                }
            }
            selectedEvent = primary.createWarpEvent(desiredBank, desiredMap)
            if (selectedEvent == null) return
            tutorials.complete(Tutorial.ToolbarTemplate_CreateEvent)
        } else if (type == EventCreationType.Script) {
            selectedEvent = primary.createScriptEvent()
            if (selectedEvent == null) return
            tutorials.complete(Tutorial.ToolbarTemplate_CreateEvent)
        } else if (type == EventCreationType.Signpost) {
            val signpost = primary.createSignpostEvent()
            if (signpost != null) _templates.applyTemplate(signpost, history.currentChange)
            selectedEvent = signpost
            if (selectedEvent == null) return
            tutorials.complete(Tutorial.ToolbarTemplate_CreateEvent)
            // TODO primaryMap.InformCreate if we created a script
        } else if (type == EventCreationType.Fly) {
            val flySpot = primary.createFlyEvent()
            if (flySpot != null) selectedEvent = flySpot
        } else {
            throw UnsupportedOperationException()
        }
    }
    private var tilesToDraw: Array<IntArray>? = null
    private var selectDownPosition: Point = Point()
    private var _drawMultipleTiles: Boolean = false
    var drawMultipleTiles: Boolean
        get() { /*@DONE MapEditorViewModel.DrawMultipleTiles.get cs:1107-1107*/
            return _drawMultipleTiles
        }
        private set(value) { /*@DONE MapEditorViewModel.DrawMultipleTiles.set cs:1108-1111*/
            set(_drawMultipleTiles, value, "drawMultipleTiles", { _drawMultipleTiles = it }) { old -> notifyPropertyChanged("blockBagVisible") }
            notifyPropertiesChanged("isSingleBlock", "blockUsageCount")
        }
    private var _blockEditorVisible: Boolean = false
    var blockEditorVisible: Boolean
        get() { /*@DONE MapEditorViewModel.BlockEditorVisible.get cs:1115-1115*/
            return _blockEditorVisible
        }
        private set(value) { /*@DONE MapEditorViewModel.BlockEditorVisible.set cs:1115-1115*/
            set(_blockEditorVisible, value, "blockEditorVisible", { _blockEditorVisible = it }) { old -> notifyPropertyChanged("blockBagVisible") }
        }
    val blockBagVisible: Boolean
        get() { /*@DONE MapEditorViewModel.BlockBagVisible.get cs:1117-1117*/
            return _blockEditorVisible && !_drawMultipleTiles
        }
    private lateinit var _multiTileDrawRender: IPixelViewModel
    var multiTileDrawRender: IPixelViewModel
        get() { /*@DONE MapEditorViewModel.MultiTileDrawRender.get cs:1121-1121*/
            return _multiTileDrawRender
        }
        set(value) { /*@DONE MapEditorViewModel.MultiTileDrawRender.set cs:1122-1125*/
            _multiTileDrawRender = value
            notifyPropertyChanged("multiTileDrawRender")
        }
    fun selectDown(x: Double, y: Double): SelectionInteractionResult { /*@DONE MapEditorViewModel.SelectDown/1 cs:1128-1150*/
        primaryMap.blockEditor?.showTiles = false
        primaryMap.borderEditor.showBorderPanel = false
        val map = mapUnderCursor(x, y) ?: return SelectionInteractionResult.None
        primaryMap = map
        showHeaderPanel = false
        val blockResult = map.getBlock(x, y)
        selectedEvent = null
        selectDownPosition = toBoundedMapTilePosition(map, x, y, 1, 1)
        updateHover(primaryMap, selectDownPosition.x, selectDownPosition.y, 1, 1)
        val ev = map.eventsUnderCursor(x, y)
        if (ev.size > 0) {
            showEventContextMenu(ev.last())
            return SelectionInteractionResult.ShowMenu
        }
        if (blockResult.blockIndex >= 0) {
            drawBlockIndex = blockResult.blockIndex
            autoscrollBlocks(this, EventArgs.empty)
        }
        if (blockResult.collisionIndex >= 0) collisionIndex = blockResult.collisionIndex
        return SelectionInteractionResult.None
    }
    fun selectMove(x: Double, y: Double) { /*@DONE MapEditorViewModel.SelectMove/1 cs:1152-1163*/
        val map = mapUnderCursor(x, y)
        if (map == null || map !== _primaryMap) return
        if (x < map.leftEdge || x > map.leftEdge + map.pixelWidth * map.spriteScale) return
        if (y < map.topEdge || y > map.topEdge + map.pixelHeight * map.spriteScale) return
        val selectMovePosition = toBoundedMapTilePosition(map, x, y, 1, 1)
        val left = Math.min(selectDownPosition.x, selectMovePosition.x)
        val top = Math.min(selectDownPosition.y, selectMovePosition.y)
        val width = Math.abs(selectDownPosition.x - selectMovePosition.x) + 1
        val height = Math.abs(selectDownPosition.y - selectMovePosition.y) + 1
        updateHover(map, left, top, width, height)
    }
    fun selectUp(x: Double, y: Double) { /*@DONE MapEditorViewModel.SelectUp/1 cs:1165-1213*/
        interactionType = PrimaryInteractionType.None
        val map = mapUnderCursor(x, y)
        if (map == null || map !== _primaryMap) return
        if (x < map.leftEdge || x > map.leftEdge + map.pixelWidth * map.spriteScale) return
        if (y < map.topEdge || y > map.topEdge + map.pixelHeight * map.spriteScale) return
        val selectMovePosition = toBoundedMapTilePosition(map, x, y, 1, 1)
        val left = Math.min(selectDownPosition.x, selectMovePosition.x)
        val top = Math.min(selectDownPosition.y, selectMovePosition.y)
        var width = Math.abs(selectDownPosition.x - selectMovePosition.x) + 1
        var height = Math.abs(selectDownPosition.y - selectMovePosition.y) + 1
        val tiles = Array(width) { IntArray(height) }
        tilesToDraw = tiles
        if (width == 1 && height == 1) {
            selectSingleBlock()
            updateHover(map, left, top, 1, 1)
            tutorials.complete(Tutorial.RightClickMap_SelectBlock)
            return
        }

        var fillError = false
        for (xx in 0 until width) {
            for (yy in 0 until height) {
                val position = toMapPosition(map, left + xx, top + yy)
                val block = map.getBlock(position.x, position.y)
                if (block.blockIndex == -1 || block.collisionIndex == -1) {
                    fillError = true
                    break
                }
                tiles[xx][yy] = (block.collisionIndex shl 10) or block.blockIndex
            }
        }
        if (fillError) {
            drawMultipleTiles = false
            tilesToDraw = null
            updateHover(map, selectMovePosition.x, selectMovePosition.y, 1, 1)
        } else {
            tutorials.complete(Tutorial.RightDragMap_SelectBlocks)
            fillMultiTileRender()
            if (use9Grid && isValid9GridSelection) {
                drawMultipleTiles = false
                width = 1
                height = 1
            } else {
                drawMultipleTiles = true
            }
            blockEditorVisible = false
            primaryMap.blockEditor?.showTiles = false
            updateHover(map, left, top, width, height)
        }
    }
    private fun selectSingleBlock() { /*@DONE MapEditorViewModel.SelectSingleBlock/1 cs:1215-1222*/
        drawMultipleTiles = false
        blockEditorVisible = true
        var tiles = tilesToDraw
        if (tiles == null) {
            tiles = Array(1) { IntArray(1) }
            tilesToDraw = tiles
        }
        tiles[0][0] = _drawBlockIndex or (_collisionIndex shl 10)
        fillMultiTileRender()
        animateBlockSelection()
    }
    private fun fillMultiTileRender() { /*@DONE MapEditorViewModel.FillMultiTileRender/1 cs:1224-1241*/
        notifyPropertiesChanged("isValid9GridSelection")
        val localCopy = tilesToDraw ?: return
        if (isValid9GridSelection && use9Grid) singletons.workDispatcher!!.dispatchWork { primaryMap.discoverCornersFor9Grid(localCopy) }
        val localRenders = primaryMap.blockRenders
        val width = localCopy.size
        val height = if (localCopy.size > 0) localCopy[0].size else 0
        val scale = if (width < 4 && height < 4) 2 else 1
        val canvas = CanvasPixelViewModel(width * 16, height * 16)
        canvas.spriteScale = scale.toDouble()
        for (xx in 0 until localCopy.size) {
            for (yy in 0 until localCopy[xx].size) {
                var index = localCopy[xx][yy] and 0x3FF
                if (index >= localRenders.size) index = 0
                if (index >= localRenders.size) continue
                canvas.draw(localRenders[index], xx * 16, yy * 16)
            }
        }
        multiTileDrawRender = canvas
    }
    private fun toTilePosition(x: Double, y: Double): Point { /*@DONE MapEditorViewModel.ToTilePosition/1 cs:1243-1248*/
        val tileX = (x - primaryMap.leftEdge) / primaryMap.spriteScale / 16
        val tileY = (y - primaryMap.topEdge) / primaryMap.spriteScale / 16
        val borders = primaryMap.getBorderThickness()
        return Point(Math.floor(tileX).toInt() - borders.west, Math.floor(tileY).toInt() - borders.north)
    }
    private fun toBoundedMapTilePosition(map: BlockMapViewModel, x: Double, y: Double, selectionWidth: Int, selectionHeight: Int): Point { /*@DONE MapEditorViewModel.ToBoundedMapTilePosition/1 cs:1250-1262*/
        val tileX = (x - map.leftEdge) / map.spriteScale / 16
        val tileY = (y - map.topEdge) / map.spriteScale / 16
        val borders = map.getBorderThickness()
        var position = Point(Math.floor(tileX).toInt() - borders.west, Math.floor(tileY).toInt() - borders.north)

        // limit to within the content of this map
        val width = map.pixelWidth / 16 - borders.west - borders.east
        val height = map.pixelHeight / 16 - borders.north - borders.south
        position = Point(position.x.limitToRange(0, Math.max(0, width - 1)), position.y.limitToRange(0, Math.max(0, height - 1)))

        return position
    }
    private fun toPixelPosition(map: BlockMapViewModel, x: Double, y: Double): ImageLocation { /*@DONE MapEditorViewModel.ToPixelPosition/1 cs:1264-1267*/
        val pixelX = (x - map.leftEdge) / map.spriteScale
        val pixelY = (y - map.topEdge) / map.spriteScale
        return ImageLocation(pixelX / map.pixelWidth, pixelY / map.pixelHeight)
    }
    fun toMapPosition(map: BlockMapViewModel, x: Int, y: Int): MapEditorViewModelToMapPositionTuple { /*@DONE MapEditorViewModel.ToMapPosition/1 cs:1269-1274*/
        val borders = map.getBorderThickness()
        val pX = (x + borders.west) * 16 * map.spriteScale + map.leftEdge
        val pY = (y + borders.north) * 16 * map.spriteScale + map.topEdge
        return MapEditorViewModelToMapPositionTuple(pX, pY)
    }
    private var eventContext: IEventViewModel? = null
    private fun showEventContextMenu(ev: IEventViewModel) { /*@DONE MapEditorViewModel.ShowEventContextMenu/1 cs:1282-1303*/
        interactionType = PrimaryInteractionType.None
        eventContext = ev
        contextItems.clear()

        if (ev is ObjectEventViewModel) {
            contextItems.add(MenuCommandNonGeneric("Delete Object", { deleteCurrentEvent() }))
            contextItems.add(MenuCommandNonGeneric("Open in New Tab", { openScriptInNewTab(ev.scriptAddress) }))
        } else if (ev is WarpEventViewModel) {
            contextItems.add(MenuCommandNonGeneric("Create New Map", { createMapForWarp() }))
            contextItems.add(MenuCommandNonGeneric("Open in New Tab", { duplicate(ev.bank, ev.map) }))
            contextItems.add(MenuCommandNonGeneric("Delete Warp", { deleteCurrentEvent() }))
        } else if (ev is ScriptEventViewModel) {
            contextItems.add(MenuCommandNonGeneric("Delete Script", { deleteCurrentEvent() }))
            contextItems.add(MenuCommandNonGeneric("Open in New Tab", { openScriptInNewTab(ev.scriptAddress) }))
        } else if (ev is SignpostEventViewModel) {
            contextItems.add(MenuCommandNonGeneric("Delete Signpost", { deleteCurrentEvent() }))
            if (ev.showPointer && ev.canGotoScript) contextItems.add(MenuCommandNonGeneric("Open in New Tab", { openScriptInNewTab(ev.pointer) }))
        } else if (ev is FlyEventViewModel) {
            contextItems.add(MenuCommandNonGeneric("Delete Fly Spot", { deleteCurrentEvent() }))
        }
    }
    private fun showEventHover(map: BlockMapViewModel, matches: List<BaseEventViewModel>?): Array<Any>? { /*@DONE MapEditorViewModel.ShowEventHover/1 cs:1305-1350*/
        if (matches == null || matches.size == 0) return null
        val tips = ArrayList<Any>() // ReadonlyPixelViewModel and string
        if (matches.size > 1) {
            tips.add("" + matches.size + " events in this cell:")
        }
        for (ev in matches) {
            if (tips.size > 0) tips.add("---------------")
            if (ev is WarpEventViewModel) {
                if (!ev.warpIsOnWarpableBlock(model, LayoutModel(map.getLayout()))) {
                    tips.add("(This block's Behavior doesn't allow warping.)")
                }
                tips.add(ev.targetMapName)
                val banks = AllMapsModel.create(ev.element?.model ?: model, null)
                val bankModel = banks[ev.bank]
                if (bankModel == null) return tips.toTypedArray()
                if (ev.bank >= 0 && ev.bank < banks.count && ev.map >= 0 && ev.map < bankModel.count) {
                    val targetWarp = ev.warpModel.targetWarp
                    if (targetWarp != null) {
                        val image = getMapPreview(ev.bank, ev.map, targetWarp.x, targetWarp.y)
                        if (image != null) {
                            tips.add(ReadonlyPixelViewModel(image.pixelWidth, image.pixelHeight, image.pixelData))
                        }
                    }
                }
            } else if (ev is ObjectEventViewModel) {
                tips.addAll(summarizeScript(ev.scriptAddress))
            } else if (ev is ScriptEventViewModel) {
                tips.addAll(summarizeScript(ev.scriptAddress))
            } else if (ev is SignpostEventViewModel) {
                if (ev.canGotoScript) tips.addAll(summarizeScript(ev.pointer))
                if (ev.showHiddenItemProperties) {
                    val options = model.getOptions(HardcodeTablesModel.itemsTableName)
                    val item = ev.itemID
                    if (item > 0 && item < options.size) {
                        tips.add(options[item])
                        val itemSprites = model.getTableModel(HardcodeTablesModel.itemImagesTableName)
                        if (itemSprites != null && item < itemSprites.size) {
                            val render = itemSprites[item].render("sprite")
                            if (render != null) tips.add(render)
                        }
                    }
                }
            }
        }
        return tips.toTypedArray()
    }
    fun getMapPreview(bank: Int, map: Int, desiredBlockWidth: Int?): ReadonlyPixelViewModel { /*@DONE MapEditorViewModel.GetMapPreview/1 cs:1353-1366*/
        val blockmap = BlockMapViewModel(_fileSystem, tutorials, _viewPort, _format, _templates, bank, map)
        blockmap.allOverworldSprites = primaryMap.allOverworldSprites
        blockmap.includeBorders = false
        if (desiredBlockWidth == null) {
            return ReadonlyPixelViewModel(blockmap.pixelWidth, blockmap.pixelHeight, blockmap.pixelData)
        }

        var dimension = Math.max(blockmap.pixelWidth / 16.0 / desiredBlockWidth, blockmap.pixelHeight / 16.0 / desiredBlockWidth)
        var scale = 1.0
        while (dimension > 1) {
            dimension /= 2
            scale /= 2
        }
        val result = ReadonlyPixelViewModel(blockmap.pixelWidth, blockmap.pixelHeight, blockmap.pixelData)
        result.spriteScale = scale
        return result
    }
    fun getMapPreview(bank: Int, map: Int, x: Int, y: Int): ReadonlyPixelViewModel? { /*@DONE MapEditorViewModel.GetMapPreview/2 cs:1368-1377*/
        val blockmap = BlockMapViewModel(_fileSystem, tutorials, _viewPort, _format, _templates, bank, map)
        blockmap.allOverworldSprites = primaryMap.allOverworldSprites
        blockmap.includeBorders = false
        if (!blockmap.pixelWidth.inRange(16, 0x1000)) return null
        if (!blockmap.pixelHeight.inRange(16, 0x1000)) return null
        val image = blockmap.autoCrop(x, y)
        if (image != null) {
            return ReadonlyPixelViewModel(image.pixelWidth, image.pixelHeight, image.pixelData)
        }
        return null
    }
    private fun summarizeScript(address: Int): Iterable<Any> { /*@DONE MapEditorViewModel.SummarizeScript/1 cs:1380-1524*/
        val renderedAddresses = HashSet<Int>()
        val parser = _viewPort.tools!!.codeTool!!.scriptParser
        val startPoints = listOf(address)
        val scriptSpots = Flags.getAllScriptSpots(model, parser, startPoints,
            0x0F, // loadpointer
            0x67, // preparemsg
            0x1A, // give.item
            0x5C, // trainerbattle
            0x86, // mart
            0xB6, 0x44, // setwildbattle / givepokemon
            0x79) // additem
        val tips = ArrayList<Any>()
        var textIncluded = 0 // prevent the tooltip from getting too long

        val trainerTable = model.getTableModel(HardcodeTablesModel.trainerTableName)
        val icons = model.getTableModel(HardcodeTablesModel.pokeIconsTable)
        val fronts = model.getTableModel(HardcodeTablesModel.frontSpritesTable)
        val trainerSprites = model.getTableModel(HardcodeTablesModel.trainerSpritesName)
        val itemSprites = model.getTableModel(HardcodeTablesModel.itemImagesTableName)
        val itemStats = model.getTableModel(HardcodeTablesModel.itemsTableName)

        val tradeContent = EventTemplate.getTradeContent(model, parser, address)
        if (tradeContent != null && fronts != null && icons != null) {
            val tradeIndex = model.readMultiByteValue(tradeContent.tradeAddress, 2)
            val tradeTable = model.getTableModel(HardcodeTablesModel.tradeTable)
            if (tradeTable != null && tradeIndex >= 0 && tradeIndex < tradeTable.size) {
                val give = tradeTable[tradeIndex].getValue("give")
                val receive = tradeTable[tradeIndex].getValue("receive")
                if (give >= 0 && give < icons.size && receive >= 0 && receive < fronts.size) {
                    val giveRender = icons[give].render("icon")
                    val receiveSprite = fronts[receive].render("sprite")
                    if (giveRender != null && receiveSprite != null) {
                        val giveSprite = ReadonlyPixelViewModel.crop(giveRender, 0, 0, 32, 32)
                        tips.add(ReadonlyPixelViewModel.render(receiveSprite, giveSprite, 32, 32))
                    }
                }
            }
        }

        for (spot in scriptSpots) {
            if (renderedAddresses.contains(spot.address)) continue
            if (model[spot.address] == 0x0F) {
                // loadpointer (text)
                val textStart = model.readPointer(spot.address + 2)
                if (0 <= textStart && textStart < model.count && textIncluded < textCountLimit) {
                    var text = model.textConverter.convert(model, textStart, textSummaryLimit) ?: ""
                    if (text.length >= textSummaryLimit) text += "..."
                    tips.add(text)
                    textIncluded++
                    renderedAddresses.add(spot.address)
                }
            } else if (model[spot.address] == 0x67) {
                // preparemsg (text)
                val textStart = model.readPointer(spot.address + 1)
                if (0 <= textStart && textStart < model.count && textIncluded < textCountLimit) {
                    var text = model.textConverter.convert(model, textStart, textSummaryLimit) ?: ""
                    if (text.length >= textSummaryLimit) text += "..."
                    tips.add(text)
                    textIncluded++
                    renderedAddresses.add(spot.address)
                }
            } else if (model[spot.address] == 0x1A && model[spot.address + 1] == 0x00 && model[spot.address + 2] == 0x80 && itemStats != null && itemSprites != null) {
                // copyvarifnotzero (item), likely give.item macro
                val itemAddress = spot.address + 3
                val itemID = model.readMultiByteValue(itemAddress, 2)
                if (itemID < 0 || itemID >= itemStats.size || !itemStats[0].hasField("name")) continue
                tips.add(itemStats[itemID].getStringValue("name"))
                renderedAddresses.add(spot.address)
                val item = if (itemID < itemSprites.size) itemSprites[itemID].render("sprite") else null
                if (item != null) tips.add(item)
            } else if (
                model[spot.address] == 0x5C &&
                trainerTable != null &&
                trainerTable[0].hasField("sprite") &&
                trainerSprites != null &&
                icons != null &&
                icons[0].hasField("icon") &&
                trainerSprites[0].hasField("sprite")
            ) {
                // trainer
                if (spot.address + 1 != 0x03) {
                    // 5C ** trainer: arg: playerwin<>
                    val textStart = model.readPointer(spot.address + 6)
                    if (0 <= textStart && textStart < model.count) {
                        var text = model.textConverter.convert(model, textStart, textSummaryLimit) ?: ""
                        if (text.length >= textSummaryLimit) text += "..."
                        tips.add(text)
                        textIncluded++
                        renderedAddresses.add(spot.address)
                    }
                }

                val trainerID = model.readMultiByteValue(spot.address + 2, 2)
                val pokemon = ArrayList<IPixelViewModel>()
                val items = ArrayList<IPixelViewModel>()
                val trainer = aggregateTrainerImages(trainerID, pokemon, items)
                if (trainer == null) continue
                tips.add(buildTrainerSummaryImage(trainer, pokemon, items))
                renderedAddresses.add(spot.address)

                if (spot.address + 1 == 0x03) {
                    // 5C ** trainer: arg: playerwin<>
                    val textStart = model.readPointer(spot.address + 6)
                    if (textStart >= 0 && textStart < model.count && textIncluded < textCountLimit) {
                        var text = model.textConverter.convert(model, textStart, textSummaryLimit) ?: ""
                        if (text.length >= textSummaryLimit) text += "..."
                        tips.add(text + "\n")
                        textIncluded++
                        renderedAddresses.add(spot.address)
                    }
                } else {
                    // 5C ** trainer: arg: start<> playerwin<>
                    val textStart = model.readPointer(spot.address + 10)
                    if (textStart >= 0 && textStart < model.count && textIncluded < textCountLimit) {
                        var text = model.textConverter.convert(model, textStart, textSummaryLimit) ?: ""
                        if (text.length >= textSummaryLimit) text += "..."
                        tips.add(text + "\n")
                        textIncluded++
                        renderedAddresses.add(spot.address)
                    }
                }
            } else if (model[spot.address] == 0x86 && itemStats != null) {
                // mart
                val tablePointer = model.readPointer(spot.address + 1)
                if (tablePointer < 0 || tablePointer >= model.count) continue
                val tableRun = model.getNextRun(tablePointer) as? ITableRun
                if (tableRun == null) continue
                val table = ModelTable(model, tableRun)
                var itemCount = 0
                for (martItem in table) {
                    if (itemCount == 5) {
                        tips.add("...")
                        break
                    }
                    val id = martItem.getValue(0)
                    if (id < 0 || id >= itemStats.size) continue
                    val name = itemStats[id].getStringValue("name")
                    tips.add(name)
                    renderedAddresses.add(spot.address)
                    itemCount++
                }
            } else if (model[spot.address] == 0xB6 || model[spot.address] == 0x79) { // setwildbattle, givepokemon
                val pokemonID = model.readMultiByteValue(spot.address + 1, 2)
                if (fronts != null && pokemonID >= 0 && fronts.size > pokemonID) {
                    val pokemonRender = fronts[pokemonID].render("sprite")
                    if (pokemonRender != null) tips.add(pokemonRender)
                }
            } else if (model[spot.address] == 0x44 && itemSprites != null) { // additem
                val itemID = model.readMultiByteValue(spot.address + 1, 2)
                val item = if (itemID >= 0 && itemID < itemSprites.size) itemSprites[itemID].render("sprite") else null
                if (item != null) tips.add(item)
            }
        }
        if (address == Pointer.null_) tips.add("(no script)")
        return tips
    }
    private fun aggregateTrainerImages(trainerID: Int, pokemon: MutableList<IPixelViewModel>, items: MutableList<IPixelViewModel>): IPixelViewModel? { /*@DONE MapEditorViewModel.AggregateTrainerImages/1 cs:1526-1572*/
        val trainerTable = model.getTableModel(HardcodeTablesModel.trainerTableName)
        val pokemonSprites = model.getTableModel(HardcodeTablesModel.pokeIconsTable)
        val trainerSprites = model.getTableModel(HardcodeTablesModel.trainerSpritesName)
        val itemSprites = model.getTableModel(HardcodeTablesModel.itemImagesTableName)
        if (trainerTable == null || pokemonSprites == null || trainerSprites == null || itemSprites == null) return null

        if (trainerID < 0 || trainerID >= trainerTable.size) return null
        val trainerSpriteID = trainerTable[trainerID].getValue("sprite")
        if (trainerSpriteID < 0 || trainerSpriteID >= trainerSprites.size) return null
        val trainerSpriteStart = trainerSprites[trainerSpriteID].getAddress("sprite")
        val trainerSpriteRun = model.getNextRun(trainerSpriteStart) as? ISpriteRun
        if (trainerSpriteRun == null) return null
        val trainerSprite = ReadonlyPixelViewModel.create(model, trainerSpriteRun, true)

        val pokemonData = trainerTable[trainerID].getSubTable("pokemon")
        if (pokemonData != null) {
            for (mon in pokemonData) {
                val species = Ref(0)
                if (!mon.tryGetValue("mon", species)) continue
                if (species.value < 0 || species.value >= pokemonSprites.size) continue
                val iconStart = pokemonSprites[species.value].getAddress("icon")
                val iconRun = model.getNextRun(iconStart) as? ISpriteRun
                if (iconRun == null) continue
                val icon = ReadonlyPixelViewModel.create(model, iconRun, true) ?: continue
                pokemon.add(ReadonlyPixelViewModel.crop(icon, 0, 0, 32, 32))
            }
        }

        // item sprites are optional (they don't even exist for R/S)
        if (itemSprites[0].hasField("sprite")) {
            val itemIDs = ArrayList<Int>()
            val itemRef = Ref(0)
            if (trainerTable[trainerID].tryGetValue("item1", itemRef) && itemRef.value > 0) itemIDs.add(itemRef.value)
            if (trainerTable[trainerID].tryGetValue("item2", itemRef) && itemRef.value > 0) itemIDs.add(itemRef.value)
            if (trainerTable[trainerID].tryGetValue("item3", itemRef) && itemRef.value > 0) itemIDs.add(itemRef.value)
            if (trainerTable[trainerID].tryGetValue("item4", itemRef) && itemRef.value > 0) itemIDs.add(itemRef.value)
            for (item in itemIDs) {
                if (itemSprites.size <= item) continue
                val itemStart = itemSprites[item].getAddress("sprite")
                val itemRun = model.getNextRun(itemStart) as? ISpriteRun
                if (itemRun == null) continue
                val itemImage = ReadonlyPixelViewModel.create(model, itemRun, true) ?: continue
                items.add(itemImage)
            }
        }

        return trainerSprite
    }
    private fun buildTrainerSummaryImage(trainer: IPixelViewModel, pokemon: List<IPixelViewModel>, items: List<IPixelViewModel>): ReadonlyPixelViewModel { /*@DONE MapEditorViewModel.BuildTrainerSummaryImage/1 cs:1574-1593*/
        val pokemonColumns = if (pokemon.size > 2) 2 else 1
        val width = 64 + pokemonColumns * 32
        val height = 64
        val itemOffset = if (items.size > 0) (40 / items.size) else 0
        val pokeOffset1 = if (pokemon.size > 4) 16 else 32
        val pokeOffset2 = if (pokemon.size > 5) 16 else 32
        val pokeCount2 = if (pokemon.size > 2) pokemon.size / 2 else 0
        val pokeCount1 = pokemon.size - pokeCount2
        val data = ShortArray(width * height)
        for (i in 0 until data.size) data[i] = (-2).toShort()
        val canvas = CanvasPixelViewModel(width, height, data)
        canvas.transparent = (-2).toShort()

        canvas.draw(trainer, 0, 0)
        for (i in 0 until items.size) canvas.draw(items[i], i * itemOffset, 40)
        for (i in 0 until pokeCount1) canvas.draw(pokemon[i], 64, i * pokeOffset1)
        for (i in 0 until pokeCount2) canvas.draw(pokemon[i + pokeCount1], 96, i * pokeOffset2)

        return ReadonlyPixelViewModel(width, height, canvas.pixelData, canvas.transparent)
    }
    fun createMapForWarp() { /*@DONE MapEditorViewModel.CreateMapForWarp/1 cs:1595-1599*/
        val warpContext = eventContext as? WarpEventViewModel ?: return
        eventContext = null
        createMapForWarp(warpContext)
    }
    fun createMapForWarp(warpContext: WarpEventViewModel) { /*@DONE MapEditorViewModel.CreateMapForWarp/2 cs:1601-1607*/
        tutorials.complete(Tutorial.RightClick_WarpNewMap)
        val newMap = primaryMap.createMapForWarp(warpContext) ?: return
        navigateTo(newMap.mapID)
        history.changeCompleted()
    }
    fun deleteCurrentEvent() { /*@DONE MapEditorViewModel.DeleteCurrentEvent/1 cs:1609-1613*/
        selectedEvent = eventContext
        eventContext = null
        delete()
    }
    fun zoom(x: Double, y: Double, enlarge: Boolean) { /*@DONE MapEditorViewModel.Zoom/1 cs:1617-1626*/
        val map = mapUnderCursor(x, y) ?: primaryMap
        map.scale(x, y, enlarge)
        map.includeBorders = map.spriteScale <= 3
        updatePrimaryMap(map)
        if (map.spriteScale >= 1) zoomLevel = "" + map.spriteScale.toInt() + "x Zoom"
        else zoomLevel = "1/" + Math.rint(1 / map.spriteScale).toInt() + "x Zoom"
        tutorials.complete(Tutorial.Wheel_ZoomMap)
    }
    fun resetZoom() { /*@DONE MapEditorViewModel.ResetZoom/1 cs:1628-1631*/
        while (primaryMap.spriteScale > 1) zoom(0.0, 0.0, false)
        while (primaryMap.spriteScale < 1) zoom(0.0, 0.0, true)
    }
    private lateinit var _panCommand: StubCommand
    private lateinit var _zoomCommand: StubCommand
    private lateinit var _deleteCommand: StubCommand
    private lateinit var _cancelCommand: StubCommand
    val panCommand: ICommand
        get() { /*@DONE MapEditorViewModel.PanCommand.get cs:1634-1634*/
            if (!::_panCommand.isInitialized) _panCommand = stubCommandOf<MapDirection>({ d -> if (d != null) pan(d) })
            return _panCommand
        }
    val zoomCommand: ICommand
        get() { /*@DONE MapEditorViewModel.ZoomCommand.get cs:1635-1635*/
            if (!::_zoomCommand.isInitialized) _zoomCommand = stubCommandOf<ZoomDirection>({ d -> if (d != null) zoom(d) })
            return _zoomCommand
        }
    val deleteCommand: ICommand
        get() { /*@DONE MapEditorViewModel.DeleteCommand.get cs:1636-1636*/
            if (!::_deleteCommand.isInitialized) _deleteCommand = stubCommand({ delete() })
            return _deleteCommand
        }
    val cancelCommand: ICommand
        get() { /*@DONE MapEditorViewModel.CancelCommand.get cs:1637-1637*/
            if (!::_cancelCommand.isInitialized) _cancelCommand = stubCommand({ cancel() })
            return _cancelCommand
        }
    fun pan(direction: MapDirection) { /*@DONE MapEditorViewModel.Pan/1 cs:1639-1649*/
        var intX = 0
        var intY = 0
        if (direction == MapDirection.Left) intX = -1
        if (direction == MapDirection.Right) intX = 1
        if (direction == MapDirection.Up) intY = -1
        if (direction == MapDirection.Down) intY = 1
        pan(intX * -32, intY * -32)
        val map = mapUnderCursor(0.0, 0.0)
        tutorials.complete(Tutorial.ArrowKeys_PanMap)
        if (map != null) updatePrimaryMap(map)
    }
    fun zoom(direction: ZoomDirection) { /*@DONE MapEditorViewModel.Zoom/2 cs:1651-1651*/
        zoom(0.0, 0.0, direction == ZoomDirection.Enlarge)
    }
    fun delete() { /*@DONE MapEditorViewModel.Delete/1 cs:1653-1666*/
        val current = selectedEvent ?: return
        val success = current.delete()
        if (success) {
            if (current is ObjectEventViewModel) {
                for (neighbor in preferLoaded(getMapNeighbors(primaryMap, 1))) neighbor.updateClone(primaryMap, current, true)
            }
            selectedEvent = null
            primaryMap.redrawEvents()
        } else {
            onError(this, "Event is hard-coded.")
        }
        history.changeCompleted()
    }
    fun cancel() { /*@DONE MapEditorViewModel.Cancel/1 cs:1668-1681*/
        selectedEvent = null
        drawMultipleTiles = false
        blockEditorVisible = false
        tilesToDraw = null
        if (drawBlockIndex != -1) tutorials.complete(Tutorial.EscapeKey_UnselectBlock)
        drawBlockIndex = -1
        collisionIndex = -1
        showHeaderPanel = false
        highlightCursorX -= (highlightCursorWidth - (16 * primaryMap.spriteScale + 4)) / 2
        highlightCursorY -= (highlightCursorHeight - (16 * primaryMap.spriteScale + 4)) / 2
        highlightCursorWidth = 16 * primaryMap.spriteScale + 4
        highlightCursorHeight = 16 * primaryMap.spriteScale + 4
    }
    fun clearSelection() { /*@DONE MapEditorViewModel.ClearSelection/1 cs:1683-1695*/
        showHeaderPanel = false
        drawBlockIndex = -1
        collisionIndex = -1
        selectedEvent = null
        drawMultipleTiles = false
        blockEditorVisible = false
        tilesToDraw = null
        val primary = _primaryMap
        if (primary != null) {
            primary.blockEditor?.showTiles = false
            primary.borderEditor.showBorderPanel = false
        }
    }
    private fun pan(intX: Int, intY: Int) { /*@DONE MapEditorViewModel.Pan/2 cs:1697-1706*/
        for (map in visibleMaps) {
            map.leftEdge += intX
            map.topEdge += intY
        }
        for (button in mapButtons) {
            button.anchorPositionX += if (button.anchorLeftEdge) intX else -intX
            button.anchorPositionY += if (button.anchorTopEdge) intY else -intY
        }
    }
    private fun mapUnderCursor(x: Double, y: Double): BlockMapViewModel? { /*@DONE MapEditorViewModel.MapUnderCursor/1 cs:1708-1722*/
        var closestMap: BlockMapViewModel? = null
        var closestDistance = Int.MAX_VALUE.toDouble()
        for (map in visibleMaps) {
            if (map.zIndex < 0) continue
            val dx = x.limitToRange(map.leftEdge.toDouble(), map.leftEdge + map.pixelWidth * map.spriteScale)
            val dy = y.limitToRange(map.topEdge.toDouble(), map.topEdge + map.pixelHeight * map.spriteScale)
            val distance = (x - dx) * (x - dx) + (y - dy) * (y - dy)
            if (distance == 0.0) return map
            if (distance > closestDistance) continue
            closestDistance = distance
            closestMap = map
        }
        return closestMap
    }
    private val _blockBag: MutableList<Int> = /*@INITDONE MapEditorViewModel.blockBag cs:1728-1728*/ ArrayList() /*@ENDINIT*/
    private var selectionFromBlock: Boolean = /*@INITAUTO MapEditorViewModel.selectionFromBlock cs:1729-1729*/ false /*@ENDINIT*/
    private var blockInteractionStart: Point = Point()
    private var _use9Grid: Boolean = false
    var use9Grid: Boolean
        get() { /*@DONE MapEditorViewModel.Use9Grid.get cs:1735-1735*/
            return _use9Grid
        }
        set(value) { /*@DONE MapEditorViewModel.Use9Grid.set cs:1736-1743*/
            set(_use9Grid, value, "use9Grid", { _use9Grid = it }) { old ->
                val tiles = tilesToDraw
                if (_use9Grid && isValid9GridSelection && tiles != null) {
                    drawMultipleTiles = true
                    singletons.workDispatcher!!.dispatchWork { primaryMap.discoverCornersFor9Grid(tiles) }
                } else {
                    drawMultipleTiles = tiles != null && (tiles.size > 1 || (tiles.size > 0 && tiles[0].size > 1))
                }
            }
        }
    val isValid9GridSelection: Boolean
        get() { /*@DONE MapEditorViewModel.IsValid9GridSelection.get cs:1746-1746*/
            val tiles = tilesToDraw
            return tiles != null && tiles.size == 3 && tiles[0].size == 3
        }
    fun selectBlock(x: Int, y: Int) { /*@DONE MapEditorViewModel.SelectBlock/1 cs:1749-1756*/
        var row = y
        while (row * BlockMapViewModel.blocksPerRow + x > primaryMap.blockRenders.size) row -= 1
        blockInteractionStart = Point(x, row)
        selectionFromBlock = false
        _drawBlockIndex = row * BlockMapViewModel.blocksPerRow + x
        notifyPropertiesChanged("highlightBlockX", "highlightBlockY", "highlightBlockWidth", "highlightBlockHeight")
        tutorials.complete(Tutorial.LeftClickBlock_SelectBlock)
    }
    fun dragBlock(x: Int, y: Int) { /*@DONE MapEditorViewModel.DragBlock/1 cs:1758-1779*/
        selectionFromBlock = true
        var row = y
        while (row * BlockMapViewModel.blocksPerRow + x > primaryMap.blockRenders.size) row -= 1
        var xx = x
        var right = blockInteractionStart.x
        if (xx > right) { val swap = xx; xx = right; right = swap }
        var yy = row
        var bottom = blockInteractionStart.y
        if (yy > bottom) { val swap = yy; yy = bottom; bottom = swap }
        if (bottom * BlockMapViewModel.blocksPerRow + right > primaryMap.blockRenders.size) return
        val width = right - xx + 1
        val height = bottom - yy + 1
        val tiles = Array(width) { IntArray(height) }
        tilesToDraw = tiles
        for (dx in 0 until width) {
            for (dy in 0 until height) {
                tiles[dx][dy] = (yy + dy) * BlockMapViewModel.blocksPerRow + xx + dx
                var preferredCollision = Math.max(_collisionIndex, 0)
                if (_autoUpdateCollision) preferredCollision = getPreferredCollision(tiles[dx][dy])
                tiles[dx][dy] = tiles[dx][dy] or (preferredCollision shl 10)
            }
        }
        _drawBlockIndex = yy * BlockMapViewModel.blocksPerRow + xx
        notifyPropertiesChanged("highlightBlockX", "highlightBlockY", "highlightBlockWidth", "highlightBlockHeight")
        tutorials.complete(Tutorial.DragBlocks_SelectBlocks)
    }
    fun releaseBlock(x: Int, y: Int) { /*@DONE MapEditorViewModel.ReleaseBlock/1 cs:1781-1808*/
        var xx = x
        var right = blockInteractionStart.x
        if (xx > right) { val swap = xx; xx = right; right = swap }
        var yy = y
        var bottom = blockInteractionStart.y
        if (yy > bottom) { val swap = yy; yy = bottom; bottom = swap }
        if (bottom * BlockMapViewModel.blocksPerRow + right > primaryMap.blockRenders.size) return
        val width = right - xx + 1
        val height = bottom - yy + 1
        if (width == 1 && height == 1) {
            drawMultipleTiles = false
            blockEditorVisible = true
            _drawBlockIndex = -1 // we want to run a full update on DrawBlockIndex
            drawBlockIndex = y * BlockMapViewModel.blocksPerRow + x
            val tiles = Array(width) { IntArray(height) }
            tilesToDraw = tiles
            tiles[0][0] = _drawBlockIndex
            fillMultiTileRender()
            if (_autoUpdateCollision) {
                val preferredCollision = getPreferredCollision(drawBlockIndex)
                if (preferredCollision >= 0) collisionIndex = preferredCollision
            }
            if (_collisionIndex >= 0) tiles[0][0] = tiles[0][0] or (_collisionIndex shl 10)
            return
        }
        primaryMap.blockEditor?.showTiles = false
        fillMultiTileRender()
        if (use9Grid && isValid9GridSelection) drawMultipleTiles = false
        else drawMultipleTiles = true
        blockEditorVisible = false
    }
    fun toggleBlockInBag(x: Int, y: Int) { /*@DONE MapEditorViewModel.ToggleBlockInBag/1 cs:1810-1819*/
        var row = y
        while (row * BlockMapViewModel.blocksPerRow + x > primaryMap.blockRenders.size) row -= 1
        val blockIndex = row * BlockMapViewModel.blocksPerRow + x
        if (_blockBag.contains(blockIndex)) {
            _blockBag.remove(blockIndex)
        } else {
            _blockBag.add(blockIndex)
        }
        updateBlockBagVisual()
    }
    fun clearBlockBag() { /*@DONE MapEditorViewModel.ClearBlockBag/1 cs:1821-1824*/
        _blockBag.clear()
        updateBlockBagVisual()
    }
    lateinit var blockBag: IPixelViewModel
        private set
    private fun updateBlockBagVisual() { /*@DONE MapEditorViewModel.UpdateBlockBagVisual/1 cs:1827-1841*/
        // remove blocks from blockbag if the current map doesn't contain the block
        val renders = primaryMap.blockRenders
        val toRemove = _blockBag.filter { block -> block >= renders.size }
        toRemove.forEach { block -> _blockBag.remove(block) }

        val canvas = CanvasPixelViewModel(16 * _blockBag.size, 16)
        var offset = 0
        for (block in _blockBag) {
            val render = renders[block]
            canvas.draw(render, offset, 0)
            offset += 16
        }
        blockBag = canvas
        notifyPropertyChanged("blockBag")
    }
    private var shiftButton: MapSlider? = null
    fun shiftDown(x: Double, y: Double) { /*@DONE MapEditorViewModel.ShiftDown/1 cs:1849-1858*/
        cursorX = x
        cursorY = y
        deltaX = 0.0
        deltaY = 0.0
        shiftButton = buttonUnderCursor(x, y)
        highlightCursorWidth = 0.0
        highlightCursorHeight = 0.0

        val layout = primaryMap.getLayout()
        if (layout != null) {
            val run = model.getNextRun(layout.getAddress("blockmap")) as? BlockmapRun
            run?.storeContentBackupForSizeChange()
        }
    }
    fun shiftMove(x: Double, y: Double) { /*@DONE MapEditorViewModel.ShiftMove/1 cs:1860-1870*/
        val button = shiftButton ?: return
        deltaX += x - cursorX
        deltaY += y - cursorY
        val blockSize = Math.max(1, (16 * primaryMap.spriteScale).toInt())
        val intX = deltaX.toInt() / blockSize
        val intY = deltaY.toInt() / blockSize
        deltaX -= intX * blockSize
        deltaY -= intY * blockSize
        cursorX = x
        cursorY = y
        button.move(intX, intY)
    }
    fun shiftUp(x: Double, y: Double) { /*@DONE MapEditorViewModel.ShiftUp/1 cs:1872-1874*/
        history.changeCompleted()
    }
    private fun buttonUnderCursor(x: Double, y: Double): MapSlider? { /*@DONE MapEditorViewModel.ButtonUnderCursor/1 cs:1876-1896*/
        for (button in mapButtons) {
            val left: Int
            val right: Int
            val top: Int
            val bottom: Int
            if (button.anchorLeftEdge) {
                left = button.anchorPositionX
                right = left + MapSlider.sliderSize
            } else {
                right = -button.anchorPositionX
                left = right - MapSlider.sliderSize
            }
            if (button.anchorTopEdge) {
                top = button.anchorPositionY
                bottom = top + MapSlider.sliderSize
            } else {
                bottom = -button.anchorPositionY
                top = bottom - MapSlider.sliderSize
            }
            if (left <= x && x < right && top <= y && y < bottom) return button
        }
        return null
    }
    fun drawBorder(x: Double, y: Double) { /*@DONE MapEditorViewModel.DrawBorder/1 cs:1902-1909*/
        val borderEditor = primaryMap.borderEditor
        if (!borderEditor.showBorderPanel) return
        if (drawMultipleTiles) {
            val tiles = tilesToDraw
            if (tiles != null) borderEditor.draw(tiles, x, y)
        } else {
            if (_drawBlockIndex != -1) borderEditor.draw(drawBlockIndex, x, y)
        }
    }
    fun completeBorderDraw() { /*@DONE MapEditorViewModel.CompleteBorderDraw/1 cs:1911-1911*/
        _viewPort.changeHistory.changeCompleted()
    }
    fun readBorderBlock(x: Double, y: Double) { /*@DONE MapEditorViewModel.ReadBorderBlock/1 cs:1913-1918*/
        drawBlockIndex = primaryMap.borderEditor.getBlock(x, y)
        tilesToDraw = Array(1) { IntArray(1) }
        autoscrollBlocks(this, EventArgs.empty)
        selectSingleBlock()
    }
    private var waveFunctionPrimary: MutableMap<Long, Array<WaveNeighbors?>>? = null
    private var waveFunctionSecondary: MutableMap<Long, Array<WaveNeighbors?>> = LinkedHashMap()
    private var waveFunctionMixed: MutableMap<Long, Array<WaveNeighbors?>> = LinkedHashMap()
    private fun calculateWaveCollapseProbabilities() { /*@DONE MapEditorViewModel.CalculateWaveCollapseProbabilities/1 cs:1928-1969*/
        val primaryDictionary = LinkedHashMap<Long, Array<WaveNeighbors?>>()
        val secondaryDictionary = LinkedHashMap<Long, Array<WaveNeighbors?>>()
        val mixedDictionary = LinkedHashMap<Long, Array<WaveNeighbors?>>()
        waveFunctionPrimary = primaryDictionary
        waveFunctionSecondary = secondaryDictionary
        waveFunctionMixed = mixedDictionary
        for (bank in AllMapsModel.create(model, { history.currentChange })) {
            for (map in bank) {
                if (map == null) continue
                val layout = map.layout ?: continue
                val cells = map.blocks ?: continue
                val primaryBlockset = layout.primaryBlockset ?: continue
                val secondaryBlockset = layout.secondaryBlockset ?: continue
                val primary = primaryBlockset.start
                val secondary = secondaryBlockset.start
                val mixed = (primary.toLong() shl 32) + secondary
                val primaryWaveNeighbors = primaryDictionary.ensure(primary.toLong()) { arrayOfNulls<WaveNeighbors>(primaryBlocks) }
                val secondaryWaveNeighbors = secondaryDictionary.ensure(secondary.toLong()) { arrayOfNulls<WaveNeighbors>(totalBlocks - primaryBlocks) }
                val mixedWaveNeighbors = mixedDictionary.ensure(mixed) { arrayOfNulls<WaveNeighbors>(totalBlocks) }

                for (x in 0 until cells.width) {
                    for (y in 0 until cells.height) {
                        val center = cells[x, y] ?: continue
                        if (isPrimaryBlock(center)) {
                            checkPrimary(cells, x - 1, y, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.left }
                            checkPrimary(cells, x + 1, y, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.right }
                            checkPrimary(cells, x, y - 1, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.up }
                            checkPrimary(cells, x, y + 1, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.down }
                            checkPrimary(cells, x - 1, y - 1, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.upLeft }
                            checkPrimary(cells, x + 1, y - 1, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.upRight }
                            checkPrimary(cells, x - 1, y + 1, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.downLeft }
                            checkPrimary(cells, x + 1, y + 1, center, primaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.downRight }
                        } else {
                            checkSecondary(cells, x - 1, y, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.left }
                            checkSecondary(cells, x + 1, y, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.right }
                            checkSecondary(cells, x, y - 1, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.up }
                            checkSecondary(cells, x, y + 1, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.down }
                            checkSecondary(cells, x - 1, y - 1, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.upLeft }
                            checkSecondary(cells, x + 1, y - 1, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.upRight }
                            checkSecondary(cells, x - 1, y + 1, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.downLeft }
                            checkSecondary(cells, x + 1, y + 1, center, secondaryWaveNeighbors, mixedWaveNeighbors) { wn -> wn.downRight }
                        }
                    }
                }
            }
        }
    }
    private fun runWaveFunctionCollapseWithCollision(xx: Int, yy: Int): WaveCell { /*@DONE MapEditorViewModel.RunWaveFunctionCollapseWithCollision/1 cs:1971-1974*/
        val probabilities = runWaveFunctionCollapse(xx, yy)
        return WaveCell(probabilities, { tile -> getPreferredCollision(tile) })
    }
    private fun runWaveFunctionCollapse(xx: Int, yy: Int): MutableList<CollapseProbability>? { /*@DONE MapEditorViewModel.RunWaveFunctionCollapse/1 cs:1987-2036*/
        val layout = LayoutModel(primaryMap.getLayout())
        val primary = layout.primaryBlockset?.start ?: return null
        val secondary = layout.secondaryBlockset?.start ?: return null
        val mixed = (primary.toLong() shl 32) + secondary
        if (waveFunctionPrimary == null) calculateWaveCollapseProbabilities()
        val primaryDictionary = waveFunctionPrimary ?: return null
        val primaryWaveNeighbors = primaryDictionary.ensure(primary.toLong()) { arrayOfNulls<WaveNeighbors>(primaryBlocks) }
        val secondaryWaveNeighbors = waveFunctionSecondary.ensure(secondary.toLong()) { arrayOfNulls<WaveNeighbors>(totalBlocks - primaryBlocks) }
        val mixedWaveNeighbors = waveFunctionMixed.ensure(mixed) { arrayOfNulls<WaveNeighbors>(totalBlocks) }

        val cells = layout.blockMap
        // get the list of probabilities based on each neighbor
        val probabilities = ArrayList<MutableList<CollapseProbability>>()
        addProbabilities(probabilities, cells, xx - 1, yy, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.right }
        addProbabilities(probabilities, cells, xx + 1, yy, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.left }
        addProbabilities(probabilities, cells, xx, yy - 1, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.down }
        addProbabilities(probabilities, cells, xx, yy + 1, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.up }
        addProbabilities(probabilities, cells, xx - 1, yy - 1, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.downRight }
        addProbabilities(probabilities, cells, xx + 1, yy - 1, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.downLeft }
        addProbabilities(probabilities, cells, xx - 1, yy + 1, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.upRight }
        addProbabilities(probabilities, cells, xx + 1, yy + 1, primaryWaveNeighbors, secondaryWaveNeighbors, mixedWaveNeighbors) { wv -> wv.upLeft }

        if (probabilities.size == 0) return null // no known neighbors, no restrictions... yet

        // combine the list of probabilities down to a single list by merging from all the neighbors.
        // the block is constrained in options based on _all_ its neighbors together.
        // if the neighbor can only be A/B based on the left and only B/C based on the top, it must be B.
        while (probabilities.size > 1) {
            val last = probabilities[probabilities.size - 1]
            val next = probabilities[probabilities.size - 2]
            probabilities.removeAt(probabilities.size - 1)
            probabilities.removeAt(probabilities.size - 1)

            val merged = ArrayList<CollapseProbability>()
            for (cp1 in last) {
                val cp2 = next.firstOrNull { match -> match.block == cp1.block }
                if (cp2 == null) continue // no match
                val combined = CollapseProbability(cp1.block)
                combined.count = cp1.count + cp2.count
                merged.add(combined)
            }
            if (merged.size != 0) {
                probabilities.add(merged)
            }
        }

        // possible failure state: no probabilities were found. We had probabilities before merging, but none survived.
        // we're returning 'null' if there are no restrictions. This is the opposite: the restrictions are so tight as to have no valid results.
        if (probabilities.size == 0) return ArrayList()

        // new version that returns the current probabilities, which need collapsing
        return probabilities[0]
    }
    private fun addProbabilities(probabilities: MutableList<MutableList<CollapseProbability>>, cells: BlockCells, xx: Int, yy: Int, primaryWaveNeighbors: Array<WaveNeighbors?>, secondaryWaveNeighbors: Array<WaveNeighbors?>, mixedWaveNeighbors: Array<WaveNeighbors?>, reverse: (WaveNeighbors) -> MutableList<CollapseProbability>) { /*@DONE MapEditorViewModel.AddProbabilities/1 cs:2038-2053*/
        if (xx < 0 || yy < 0 || xx >= cells.width || yy >= cells.height) return
        val cell = cells[xx, yy] ?: return
        val edge = cell.tile
        if (edge == 0) return // this block is not yet decided. Do not add any constraints.
        val mergedProbabilities = ArrayList<CollapseProbability>()
        if (isPrimaryBlock(cell)) {
            val primaryNeighbors = primaryWaveNeighbors[edge]
            if (primaryNeighbors != null) mergedProbabilities.addAll(reverse(primaryNeighbors))
            val mixedNeighbors = mixedWaveNeighbors[edge]
            if (mixedNeighbors != null) mergedProbabilities.addAll(reverse(mixedNeighbors))
            probabilities.add(mergedProbabilities)
        } else {
            val secondaryNeighbors = secondaryWaveNeighbors[edge - primaryBlocks]
            if (secondaryNeighbors != null) mergedProbabilities.addAll(reverse(secondaryNeighbors))
            val mixedNeighbors = mixedWaveNeighbors[edge]
            if (mixedNeighbors != null) mergedProbabilities.addAll(reverse(mixedNeighbors))
            probabilities.add(mergedProbabilities)
        }
    }
    private fun checkPrimary(cells: BlockCells, x: Int, y: Int, center: BlockCell, primaryWaveNeighbors: Array<WaveNeighbors?>, mixedWaveNeighbors: Array<WaveNeighbors?>, direction: (WaveNeighbors) -> MutableList<CollapseProbability>) { /*@DONE MapEditorViewModel.CheckPrimary/1 cs:2055-2069*/
        var primaryElement = primaryWaveNeighbors[center.tile]
        var mixedElement = mixedWaveNeighbors[center.tile]
        if (x < 0 || x >= cells.width || y < 0 || y >= cells.height) return
        val edge = cells[x, y] ?: return
        if (isPrimaryBlock(edge)) {
            if (primaryElement == null) {
                primaryElement = newWaveNeighbors()
                primaryWaveNeighbors[center.tile] = primaryElement
            }
            val collapse = direction(primaryElement).ensure({ cp -> cp.block == edge.tile }, CollapseProbability(edge.tile))
            collapse.count += 1
        } else {
            if (mixedElement == null) {
                mixedElement = newWaveNeighbors()
                mixedWaveNeighbors[center.tile] = mixedElement
            }
            val collapse = direction(mixedElement).ensure({ cp -> cp.block == edge.tile }, CollapseProbability(edge.tile))
            collapse.count += 1
        }
    }
    private fun checkSecondary(cells: BlockCells, x: Int, y: Int, center: BlockCell, secondaryWaveNeighbors: Array<WaveNeighbors?>, mixedWaveNeighbors: Array<WaveNeighbors?>, direction: (WaveNeighbors) -> MutableList<CollapseProbability>) { /*@DONE MapEditorViewModel.CheckSecondary/1 cs:2071-2085*/
        var secondaryElement = secondaryWaveNeighbors[center.tile - primaryBlocks]
        var mixedElement = mixedWaveNeighbors[center.tile]
        if (x < 0 || x >= cells.width || y < 0 || y >= cells.height) return
        val edge = cells[x, y] ?: return
        if (isPrimaryBlock(edge)) {
            if (mixedElement == null) {
                mixedElement = newWaveNeighbors()
                mixedWaveNeighbors[center.tile] = mixedElement
            }
            val collapse = direction(mixedElement).ensure({ cp -> cp.block == edge.tile }, CollapseProbability(edge.tile))
            collapse.count += 1
        } else {
            if (secondaryElement == null) {
                secondaryElement = newWaveNeighbors()
                secondaryWaveNeighbors[center.tile - primaryBlocks] = secondaryElement
            }
            val collapse = direction(secondaryElement).ensure({ cp -> cp.block == edge.tile }, CollapseProbability(edge.tile))
            collapse.count += 1
        }
    }
    private fun isPrimaryBlock(cell: BlockCell): Boolean { /*@DONE MapEditorViewModel.IsPrimaryBlock/1 cs:2087-2087*/
        return cell.tile < primaryBlocks
    }
    private val totalBlocks: Int
        get() { /*@DONE MapEditorViewModel.TotalBlocks.get cs:2088-2088*/
            return 1024
        }
    fun fixLayoutTable() { /*@DONE MapEditorViewModel.FixLayoutTable/1 cs:2094-2112*/
        val token = NoDataChangeDeltaModel()
        val layouts = model.getTable(HardcodeTablesModel.mapLayoutTable) as? ArrayRun ?: return
        val firstSegment = layouts.elementContent[0]
        val layoutFormat = if (firstSegment is ArrayRunPointerSegment) firstSegment.innerFormat else null
        if (layoutFormat == null) return
        var excess = 0
        while (true) {
            val start = layouts.start + layouts.length + 4 * excess
            val pRun = model.getNextRun(start) as? PointerRun
            if (pRun == null) break
            if (pRun.start != start) break
            val destination = model.readPointer(start)
            if (!destination.inRange(0, model.count)) break
            val tRun = model.getNextRun(destination) as? ITableRun
            if (tRun == null) break
            if (tRun.formatString != layoutFormat) break
            excess++
        }
        model.clearFormat(token, layouts.start + layouts.length, excess * 4)
        model.observeRunWritten(token, layouts.resizeMetadata(layouts.elementCount + excess))
    }
    private var preferredCollisionsPrimary: MutableMap<Long, IntArray>? = null
    private var preferredCollisionsSecondary: MutableMap<Long, IntArray> = LinkedHashMap()
    private val _blockUsageCount: AutoDictionary<Long, AutoDictionary<Int, Int>> = /*@INITDONE MapEditorViewModel.blockUsageCount cs:2118-2118*/ AutoDictionary<Long, AutoDictionary<Int, Int>>({ _ -> AutoDictionary<Int, Int>({ _ -> 0 }) }) /*@ENDINIT*/
    private fun countCollisionForBlocks() { /*@DONE MapEditorViewModel.CountCollisionForBlocks/1 cs:2119-2200*/
        val primaryPreferences = LinkedHashMap<Long, IntArray>()
        val secondaryPreferences = LinkedHashMap<Long, IntArray>()
        preferredCollisionsPrimary = primaryPreferences
        preferredCollisionsSecondary = secondaryPreferences
        _blockUsageCount.clear()

        // step 1: count the usages of each collision for each block in each blockset
        val banksTable = model.getTable(HardcodeTablesModel.mapBankTable) ?: return
        val banks = ModelTable(model, banksTable.start, null, banksTable)
        val blocksetHistogram1 = LinkedHashMap<Long, Array<MutableMap<Int, Int>>>()
        val blocksetHistogram2 = LinkedHashMap<Long, Array<MutableMap<Int, Int>>>()
        for (bank in banks) {
            val maps = bank.getSubTable("maps") ?: continue
            for (entry in maps) {
                val mapTable = entry.getSubTable("map") ?: continue
                val map = mapTable[0]
                val layoutTable = map.getSubTable("layout") ?: continue
                val layout = layoutTable[0]
                // width:: height:: blockmap<> blockdata1<> blockdata2<>
                val address1 = layout.getAddress("blockdata1")
                val address2 = layout.getAddress("blockdata2")
                val blocks1 = blocksetHistogram1.ensure(address1.toLong()) { Array<MutableMap<Int, Int>>(0x400) { LinkedHashMap() } }
                val blocks2 = blocksetHistogram2.ensure(address2.toLong()) { Array<MutableMap<Int, Int>>(0x400) { LinkedHashMap() } }
                val size = layout.getValue("width") * layout.getValue("height")
                val start = layout.getAddress("blockmap")
                if (start < 0 || start > model.count - size * 2) continue
                for (i in 0 until size) {
                    val pair = model.readMultiByteValue(start + i * 2, 2)
                    val collision = pair shr 10
                    val tile = pair and 0x3FF
                    val isPrimary = tile < primaryTiles
                    if (isPrimary) {
                        val usage = _blockUsageCount[address1.toLong()]
                        usage[tile] = usage[tile] + 1
                        val value = blocks1[tile][collision] ?: 0
                        blocks1[tile][collision] = value + 1
                    } else {
                        val usage = _blockUsageCount[address2.toLong()]
                        usage[tile] = usage[tile] + 1
                        val value = blocks2[tile][collision] ?: 0
                        blocks2[tile][collision] = value + 1
                    }
                }
            }
        }

        // step 2: remember the preferred collision for each block in each blockset
        for (blocksetKey in blocksetHistogram1.keys) {
            val histogram = blocksetHistogram1[blocksetKey]!!
            val preference = IntArray(0x400)
            for (i in 0 until preference.size) {
                var mostUsedCollision = -1
                var useAmount = -1
                for ((tile, amount) in histogram[i]) {
                    if (amount > useAmount) {
                        mostUsedCollision = tile
                        useAmount = amount
                    }
                }
                preference[i] = mostUsedCollision.limitToRange(0, 0x3F)
            }
            primaryPreferences[blocksetKey] = preference
        }
        for (blocksetKey in blocksetHistogram2.keys) {
            val histogram = blocksetHistogram2[blocksetKey]!!
            val preference = IntArray(0x400)
            for (i in 0 until preference.size) {
                var mostUsedCollision = -1
                var useAmount = -1
                for ((tile, amount) in histogram[i]) {
                    if (amount > useAmount) {
                        mostUsedCollision = tile
                        useAmount = amount
                    }
                }
                preference[i] = mostUsedCollision.limitToRange(0, 0x3F)
            }
            secondaryPreferences[blocksetKey] = preference
        }
    }
    private fun updateBlockset(mapID: Int): Long { /*@DONE MapEditorViewModel.UpdateBlockset/1 cs:2202-2224*/
        val banksTable = model.getTable(HardcodeTablesModel.mapBankTable) ?: return -1L
        val banks = ModelTable(model, banksTable.start, null, banksTable)
        val bank = banks[mapID / 1000]
        val maps = bank.getSubTable("maps") ?: return -1L
        val mapsElement = maps[mapID % 1000]
        val map = mapsElement.getSubTable("map") ?: return -1L
        val mapElement = map[0]
        val layoutTable = mapElement.getSubTable(Format.layout) ?: return -1L
        val layout = layoutTable[0]
        val address1 = layout.getAddress(Format.primaryBlockset)
        val address2 = layout.getAddress(Format.secondaryBlockset)
        if (address1 == Pointer.null_ || address2 == Pointer.null_) return Pointer.null_.toLong()
        val combined = (address1 shl 25) or address2
        blockset1 = address1
        blockset2 = address2
        return combined.toLong()
    }
    private fun handleAutoscrollTiles(sender: Any, e: EventArgs) { /*@DONE MapEditorViewModel.HandleAutoscrollTiles/1 cs:2226-2226*/
        autoscrollTiles(this, EventArgs.empty)
    }
    private fun handleHideSidePanels(sender: Any, e: EventArgs) { /*@DONE MapEditorViewModel.HandleHideSidePanels/1 cs:2228-2231*/
        selectedEvent = null
        showHeaderPanel = false
    }
    private fun handleMapChangeRequest(sender: Any, e: ChangeMapEventArgs) { /*@DONE MapEditorViewModel.HandleMapChangeRequest/1 cs:2233-2235*/
        navigateTo(e.bank, e.map)
    }
    private fun handleClearMapCaches(sender: Any, e: EventArgs) { /*@DONE MapEditorViewModel.HandleClearMapCaches/1 cs:2237-2239*/
        for (map in visibleMaps) map.clearCaches()
    }
    private fun getPreferredCollision(tile: Int): Int { /*@DONE MapEditorViewModel.GetPreferredCollision/1 cs:2241-2250*/
        if (preferredCollisionsPrimary == null) countCollisionForBlocks()
        if (tile < primaryTiles) {
            val preference = preferredCollisionsPrimary?.get(blockset1.toLong())
            if (preference != null) return preference[tile]
        } else {
            val preference = preferredCollisionsSecondary[blockset2.toLong()]
            if (preference != null) return preference[tile]
        }
        return -1
    }
    fun exportAllMapImagesNoEvents() { /*@DONE MapEditorViewModel.ExportAllMapImagesNoEvents/1 cs:2252-2252*/
        exportMapImage(true, MapDisplayOptions.NoEvents)
    }
    fun exportAllMapImagesObjectEvents() { /*@DONE MapEditorViewModel.ExportAllMapImagesObjectEvents/1 cs:2253-2253*/
        exportMapImage(true, MapDisplayOptions.ObjectEvents)
    }
    fun exportAllMapImagesAllEvents() { /*@DONE MapEditorViewModel.ExportAllMapImagesAllEvents/1 cs:2254-2254*/
        exportMapImage(true, MapDisplayOptions.AllEvents)
    }
    fun exportMapImageNoEvents() { /*@DONE MapEditorViewModel.ExportMapImageNoEvents/1 cs:2255-2255*/
        exportMapImage(false, MapDisplayOptions.NoEvents)
    }
    fun exportMapImageObjectEvents() { /*@DONE MapEditorViewModel.ExportMapImageObjectEvents/1 cs:2256-2256*/
        exportMapImage(false, MapDisplayOptions.ObjectEvents)
    }
    fun exportMapImageAllEvents() { /*@DONE MapEditorViewModel.ExportMapImageAllEvents/1 cs:2257-2257*/
        exportMapImage(false, MapDisplayOptions.AllEvents)
    }
    fun exportMapImage(includeAllMaps: Boolean, options: MapDisplayOptions) { /*@DONE MapEditorViewModel.ExportMapImage/1 cs:2259-2297*/
        // from the primary map, find all connected maps
        val primary = primaryMap
        val savePrimarySelected = primary.isSelected
        val savePrimaryShowEvents = primary.showEvents

        primary.isSelected = false
        primary.showEvents = options
        val maps = ArrayList<BlockMapViewModel>()
        maps.add(primary)
        val directions = listOf(MapDirection.Left, MapDirection.Up, MapDirection.Right, MapDirection.Down)
        var i = 0
        while (i < maps.size && includeAllMaps) {
            val current = maps[i]
            val neighbors = directions.flatMap { d -> current.getNeighbors(d) }
            for (n in neighbors) {
                if (!maps.any { m -> m.mapID == n.mapID }) maps.add(n)
            }
            i++
        }

        // determine how big the image needs to be
        val left = maps.minOf { map -> map.leftEdge } / primary.spriteScale
        val right = maps.maxOf { map -> map.rightEdge } / primary.spriteScale
        val top = maps.minOf { map -> map.topEdge } / primary.spriteScale
        val bottom = maps.maxOf { map -> map.bottomEdge } / primary.spriteScale
        val width = Math.rint(right - left).toInt()
        val height = Math.rint(bottom - top).toInt()

        // create a canvas that's the right size
        val canvas = CanvasPixelViewModel(width, height)

        // draw all the maps
        for (map in maps) {
            canvas.draw(map, (map.leftEdge / map.spriteScale - left).toInt(), (map.topEdge / map.spriteScale - top).toInt())
        }

        // export it as an image
        fileSystem.copyImage = IFileSystemCopyImageTuple(canvas.pixelData, canvas.pixelWidth)
        viewPort.raiseMessage("Map copied to clipboard")

        primary.isSelected = savePrimarySelected
        primary.showEvents = savePrimaryShowEvents
    }
    companion object {
        fun tryCreateMapEditor(fileSystem: IFileSystem, viewPort: IEditableViewPort, singletons: Singletons?, tutorials: MapTutorialsViewModel?, templates: EventTemplate?, editor: Ref<MapEditorViewModel?>): Boolean { /*@DONE MapEditorViewModel.TryCreateMapEditor/1 cs:414-420*/
            editor.value = null
            val maps = viewPort.model?.getTable(HardcodeTablesModel.mapBankTable)
            if (maps == null || singletons == null || tutorials == null || templates == null) return false
            val created = MapEditorViewModel(fileSystem, viewPort, singletons, tutorials, templates)
            editor.value = created
            return created.isValidState
        }
        private val emptyTooltip: Array<Any> = /*@INITDONE MapEditorViewModel.EmptyTooltip cs:664-664*/ arrayOf<Any>() /*@ENDINIT*/
        const val textSummaryLimit: Int = 60
        const val textCountLimit: Int = 5
        /*@END MapEditorViewModel.Companion*/
    }
    /*@ADD MapEditorViewModel#mapeditor_a.txt*/
    private val neighborsChangedHandler: (Any?, EventArgs) -> Unit = { s, e -> primaryMapNeighborsChanged(s, e) }
    private val propertyChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, e -> if (s != null) primaryMapPropertyChanged(s, e) }
    private val autoscrollTilesHandler: (Any?, EventArgs) -> Unit = { s, e -> handleAutoscrollTiles(s ?: this, e) }
    private val hideSidePanelsHandler: (Any?, EventArgs) -> Unit = { s, e -> handleHideSidePanels(s ?: this, e) }
    private val requestChangeMapHandler: (Any?, ChangeMapEventArgs) -> Unit = { s, e -> handleMapChangeRequest(s ?: this, e) }
    private val clearMapCachesHandler: (Any?, EventArgs) -> Unit = { s, e -> handleClearMapCaches(s ?: this, e) }
    private val noCommand: StubCommand by lazy { stubCommand({ }, { false }) }

    private fun raiseBackChanged() {
        if (::backCommand.isInitialized) backCommand.raiseCanExecuteChanged()
    }

    private fun raiseForwardChanged() {
        if (::forwardCommand.isInitialized) forwardCommand.raiseCanExecuteChanged()
    }
    /*@ENDADD MapEditorViewModel#mapeditor_a.txt*/
    /*@ADD MapEditorViewModel#mapeditor_c.txt*/
    private fun newWaveNeighbors(): WaveNeighbors {
        return WaveNeighbors(ArrayList(), ArrayList(), ArrayList(), ArrayList(), ArrayList(), ArrayList(), ArrayList(), ArrayList())
    }
    /*@ENDADD MapEditorViewModel#mapeditor_c.txt*/
    /*@END MapEditorViewModel*/
}

data class CollapseProbability(val block: Int) { // cs:2300-2300
    var count: Int = 0
    /*@END CollapseProbability*/
}

data class WaveNeighbors(val left: MutableList<CollapseProbability>, val right: MutableList<CollapseProbability>, val up: MutableList<CollapseProbability>, val down: MutableList<CollapseProbability>, val upLeft: MutableList<CollapseProbability>, val upRight: MutableList<CollapseProbability>, val downLeft: MutableList<CollapseProbability>, val downRight: MutableList<CollapseProbability>) { // cs:2301-2304
    /*@END WaveNeighbors*/
}

data class WaveCell(val probabilities: MutableList<CollapseProbability>?, val getCollision: (Int) -> Int) { // cs:2305-2319
    fun collapse(rnd: java.util.Random): Int { /*@DONE WaveCell.Collapse/1 cs:2306-2317*/
        val options = probabilities ?: return 0
        if (options.size == 0) return 0
        var totalOptions = 0
        for (cp in options) totalOptions += cp.count
        var selection = if (totalOptions > 0) rnd.nextInt(totalOptions) else 0
        var index = 0
        while (selection > options[index].count && index < options.size - 1) {
            selection -= options[index].count
            index += 1
        }
        val block = options[index].block
        val collision = getCollision(block)
        return (collision shl 10) or block
    }
    val hasRestrictions: Boolean
        get() { /*@DONE WaveCell.HasRestrictions.get cs:2318-2318*/
            return probabilities != null
        }
    /*@END WaveCell*/
}

enum class SelectionInteractionResult(val value: Int) { // cs:2321-2321
    None(0),
    ShowMenu(1);
    companion object {
        fun fromValue(value: Int): SelectionInteractionResult = entries.first { it.value == value }
    }
    /*@END SelectionInteractionResult*/
}

enum class EventCreationType(val value: Int) { // cs:2323-2323
    None(0),
    Object(1),
    Warp(2),
    Script(3),
    Signpost(4),
    Fly(5),
    WaveFunction(6);
    companion object {
        fun fromValue(value: Int): EventCreationType = entries.first { it.value == value }
    }
    /*@END EventCreationType*/
}

enum class PrimaryInteractionStart(val value: Int) { // cs:2326-2332
    None(0),
    Click(1),
    DoubleClick(2),
    ControlClick(4),
    ShiftClick(8);
    companion object {
        fun fromValue(value: Int): PrimaryInteractionStart = entries.first { it.value == value }
    }
    /*@END PrimaryInteractionStart*/
}

enum class PrimaryInteractionType(val value: Int) { // cs:2333-2333
    None(0),
    Draw(1),
    Event(2),
    RectangleDraw(3),
    Draw9Grid(4);
    companion object {
        fun fromValue(value: Int): PrimaryInteractionType = entries.first { it.value == value }
    }
    /*@END PrimaryInteractionType*/
}

data class BlocksetCache(val primary: ObservableCollection<BlocksetOption>, val secondary: ObservableCollection<BlocksetOption>) { // cs:2335-2356
    fun calculateBlocksetOptions(model: IDataModel) { /*@DONE BlocksetCache.CalculateBlocksetOptions/1 cs:2336-2355*/
        primary.clear()
        secondary.clear()

        val primarySet = HashSet<Int>()
        val secondarySet = HashSet<Int>()

        for (bank in AllMapsModel.create(model, null)) {
            for (map in bank) {
                if (map == null) continue
                val layout = map.layout ?: continue
                val primaryBlockset = layout.primaryBlockset
                if (primaryBlockset != null) primarySet.add(primaryBlockset.start)
                val secondaryBlockset = layout.secondaryBlockset
                if (secondaryBlockset != null) secondarySet.add(secondaryBlockset.start)
            }
        }

        primary.addRange(primarySet.sorted().map { s -> BlocksetOption(model, s) })
        secondary.addRange(secondarySet.sorted().map { s -> BlocksetOption(model, s) })
    }
    /*@END BlocksetCache*/
}

enum class MapDisplayOptions(val value: Int) { // cs:2358-2358
    AllEvents(0),
    ObjectEvents(1),
    NoEvents(2);
    companion object {
        fun fromValue(value: Int): MapDisplayOptions = entries.first { it.value == value }
    }
    /*@END MapDisplayOptions*/
}

data class TileSelection(val tiles: IntArray, val width: Int) { // cs:2360-2360
    /*@END TileSelection*/
}

data class MapEditorViewModelToMapPositionTuple(val x: Double, val y: Double)
