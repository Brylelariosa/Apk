package dev.hexmaniac.core

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.viewmodels.*

/** Represents a simple editable value with change notification (SystemExtensions.EditableValue<T>). */
open class EditableValue<T>(initial: T) : ViewModelCore() {
    var value: T by notifying(initial)
}
