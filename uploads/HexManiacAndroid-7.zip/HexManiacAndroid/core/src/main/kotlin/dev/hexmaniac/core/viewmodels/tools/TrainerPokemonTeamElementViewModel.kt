// Port of ViewModels/Tools/TrainerPokemonTeamElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.runs.*

open class TrainerPokemonTeamElementViewModel : TextStreamElementViewModel { // cs:5-36
    private var _setDefaultMoves: StubCommand? = null
    private var _setDefaultItems: StubCommand? = null
    val setDefaultMoves: ICommand
        get() { /*@DONE TrainerPokemonTeamElementViewModel.SetDefaultMoves.get cs:7-7*/
            return _setDefaultMoves ?: stubCommand({ executeSetDefaultMoves() }).also { _setDefaultMoves = it }
        }
    val setDefaultItems: ICommand
        get() { /*@DONE TrainerPokemonTeamElementViewModel.SetDefaultItems.get cs:8-8*/
            return _setDefaultItems ?: stubCommand({ executeSetDefaultItems() }).also { _setDefaultItems = it }
        }
    lateinit var run: TrainerPokemonTeamRun
        private set
    constructor(viewPort: ViewPort, tptRun: TrainerPokemonTeamRun, parentName: String, itemAddress: Int) : super(viewPort, parentName, itemAddress, tptRun.formatString) { /*@DONE TrainerPokemonTeamElementViewModel.<init>/1 cs:12-15*/
        run = tptRun
    }
    protected override fun tryCopy(other: StreamElementViewModel): Boolean { /*@DONE TrainerPokemonTeamElementViewModel.TryCopy/1 cs:17-23*/
        val that = other as? TrainerPokemonTeamElementViewModel ?: return false
        _setDefaultMoves = that._setDefaultMoves
        _setDefaultItems = that._setDefaultItems
        run = that.run
        return super.tryCopy(other)
    }
    private fun executeSetDefaultMoves() { /*@DONE TrainerPokemonTeamElementViewModel.ExecuteSetDefaultMoves/1 cs:25-29*/
        val changedOffsets = Ref<List<Int>?>(null)
        val result = run.deserializeRun(content, viewPort.currentChange, true, false, changedOffsets)
        handleNewDataStream(run, result, changedOffsets.value ?: ArrayList<Int>(), null)
        viewPort.tools!!.tableTool!!.dataForCurrentRunChanged()
    }
    private fun executeSetDefaultItems() { /*@DONE TrainerPokemonTeamElementViewModel.ExecuteSetDefaultItems/1 cs:31-35*/
        val changedOffsets = Ref<List<Int>?>(null)
        val result = run.deserializeRun(content, viewPort.currentChange, false, true, changedOffsets)
        handleNewDataStream(run, result, changedOffsets.value ?: ArrayList<Int>(), null)
        viewPort.tools!!.tableTool!!.dataForCurrentRunChanged()
    }
    /*@END TrainerPokemonTeamElementViewModel*/
}
