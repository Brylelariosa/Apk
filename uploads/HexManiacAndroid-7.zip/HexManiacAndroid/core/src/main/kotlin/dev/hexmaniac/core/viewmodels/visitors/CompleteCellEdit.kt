// Port of ViewModels/Visitors/CompleteCellEdit.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.models.runs.PCSRun.Companion.stringDelimeter
import dev.hexmaniac.core.models.runs.PCSRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.PCSRun.Companion.createPCSFormat
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerStart
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerEnd

open class CompleteCellEdit : IDataFormatVisitor { // cs:14-1084
    private lateinit var model: IDataModel
    private var memoryLocation: Int = 0
    private var currentText: String = ""
    private lateinit var _currentChange: () -> ModelDelta
    private lateinit var scroll: ScrollRegion
    var result: Boolean = false
        private set
    var newDataIndex: Int = 0
        private set
    var dataMoved: Boolean = false
        private set
    var messageText: String? = null
        private set
    var errorText: String? = null
        private set
    var newCell: HexElement? = null
        private set
    private val currentChange: ModelDelta
        get() { /*@DONE CompleteCellEdit.CurrentChange.get cs:30-30*/
            return _currentChange()
        }
    constructor(model: IDataModel, scroll: ScrollRegion, memoryLocation: Int, currentText: String, currentChange: () -> ModelDelta) { /*@DONE CompleteCellEdit.<init>/1 cs:32-40*/
        this.model = model
        this.scroll = scroll
        this.memoryLocation = memoryLocation
        this.currentText = currentText
        this._currentChange = currentChange

        newDataIndex = memoryLocation
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE CompleteCellEdit.Visit/1 cs:42-42*/
        visit(None.instance, data)
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE CompleteCellEdit.Visit/2 cs:44-66*/
        if (currentText.startsWith(PointerRun.pointerStart.toString())) {
            if (currentText.last() != PointerRun.pointerEnd && currentText.last() != ' ') return
            completePointerEdit()
            result = true
        } else if (currentText.startsWith("::")) {
            if (currentText.last() != ' ') return
            completeWordEdit()
            result = true
        } else if (currentText.startsWith(":")) {
            if (currentText.last() != ' ') return
            completeNamedConstantEdit(2)
            result = true
        } else if (currentText.startsWith(".")) {
            if (currentText.last() != ' ') return
            completeNamedConstantEdit(1)
            result = true
        } else {
            if (currentText.length < 2) return
            completeHexEdit(currentText)
            result = true
        }
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE CompleteCellEdit.Visit/3 cs:68-68*/
        throw NotImplementedException()
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE CompleteCellEdit.Visit/4 cs:70-78*/
        val run = model.getNextRun(memoryLocation)
        if (run is ITableRun && currentText[0] != PointerRun.pointerStart) {
            errorText = "Pointers in tables cannot be removed without removing the table."
            return
        }

        visit(None.instance, data)
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE CompleteCellEdit.Visit/5 cs:80-83*/
        anchor.originalFormat!!.visit(this, data)
        val cell = newCell
        if (cell != null) newCell = HexElement(cell, Anchor(cell.format!!, anchor.name, anchor.format, anchor.sources))
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE CompleteCellEdit.Visit/6 cs:85-85*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE CompleteCellEdit.Visit/7 cs:87-100*/
        if (currentText == "[]") {
            val run = model.getNextRun(memoryLocation) as TableStreamRun
            val newDesiredElementCount = (memoryLocation - run.start) / run.elementLength
            val newRun = run.append(currentChange, newDesiredElementCount - run.elementCount)
            model.observeRunWritten(currentChange, newRun)
            for (i in newRun.length until run.length) currentChange.changeData(model, newRun.start + i, 0xFF)
            val endTokenLength = run.length - run.elementLength * run.elementCount
            newDataIndex = memoryLocation + endTokenLength
            result = true
        } else {
            decorator.originalFormat!!.visit(this, data)
        }
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE CompleteCellEdit.Visit/8 cs:102-102*/
        visitPCS(pcs)
    }
    private fun visitPCS(pcs: IDataFormatStreamInstance) { /*@DONE CompleteCellEdit.VisitPCS/1 cs:104-132*/
        var strippedText = currentText
        if (strippedText.startsWith(PCSRun.stringDelimeter.toString())) strippedText = strippedText.substring(1)
        val stripped = strippedText
        if (pcs.position != 0 && currentText == PCSRun.stringDelimeter.toString()) {
            completeStringEdit()
            result = true
        } else if (pcs.position == 0 && currentText == PCSRun.stringDelimeter.toString() + PCSRun.stringDelimeter) {
            completeStringEdit()
            result = true
        } else if (PCSString.pcs.any { str -> str == stripped }) {
            completeCharacterEdit(pcs)
            result = true
        } else if (stripped.startsWith("\\!") && stripped.length == 4) {
            // raw code
            val raw = stripped.substring(2).uppercase()
            val rawValue = Ref(0)
            if (raw.tryParseHex(rawValue)) {
                handleLastCharacterChange(memoryLocation, model.getNextRun(memoryLocation) ?: NoInfoRun.nullRun, byteArrayOf(rawValue.value.toByte()).asByteList())
                result = true
            }
        } else {
            val containsBadCharacters = Ref(false)
            val converted = model.textConverter.convert(stripped, containsBadCharacters)
            if (converted != null && converted.size > 1 && !containsBadCharacters.value) {
                completeCharacterEdit(pcs)
                result = true
            }
        }

        if (result) scroll.updateHeaders()
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE CompleteCellEdit.Visit/9 cs:134-138*/
        if (currentText.length < 2) return
        completeCharacterEdit(pcs)
        result = true
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE CompleteCellEdit.Visit/10 cs:140-140*/
        visitPCS(pcs)
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE CompleteCellEdit.Visit/11 cs:142-157*/
        // handle escape
        if (currentText == "\\") {
            result = false
            return
        }

        var text = currentText
        if (text.length == 2) text = text.substring(1)
        val content = text[0].code and 0xFF
        currentChange.changeData(model, memoryLocation, content)
        if ((ascii.position == 0 && (text == "^" || text == " ")) || text == "\\") text = "\\" + text
        newCell = HexElement(content, true, Ascii(ascii.source, ascii.position, text))
        newDataIndex = memoryLocation + 1
        result = true
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE CompleteCellEdit.Visit/12 cs:159-172*/
        if (braille.position != 0 && currentText == PCSRun.stringDelimeter.toString()) {
            completeBrailleStringEdit(braille)
        } else if (braille.position == 0 && currentText == PCSRun.stringDelimeter.toString() + PCSRun.stringDelimeter) {
            completeBrailleStringEdit(braille)
        } else {
            completeBrailleCharacterEdit(braille)
        }

        result = true
        scroll.updateHeaders()
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE CompleteCellEdit.Visit/13 cs:174-195*/
        val spriteRun = model.getNextRun(memoryLocation)
        if (currentText == "+" && spriteRun is LzSpriteRun) {
            val newRun = spriteRun.increaseHeight(1, currentChange)
            if (newRun.start != spriteRun.start) {
                messageText = "Sprite was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                dataMoved = true
                newDataIndex = newRun.start + 1
            }
            result = true
        }

        if (currentText.last().isWhitespace() || currentText.last() == ')') {
            if (currentText.startsWith(".")) {
                completeNamedConstantEdit(1)
            } else if (currentText.startsWith(":")) {
                completeNamedConstantEdit(2)
            } else {
                completeIntegerEdit(integer)
            }
            result = true
        }
    }
    override fun visit(integer: IntegerEnum, data: Int) { /*@DONE CompleteCellEdit.Visit/14 cs:197-208*/
        // must end in whitespace or must have matching quotation marks (ex. "Mr. Mime")
        val quoteCount = currentText.count { c -> c == '"' }

        if (quoteCount == 0 && (currentText.last().isWhitespace() || currentText.last() == ')')) {
            completeIntegerEnumEdit()
            result = true
        } else if (quoteCount == 2) {
            completeIntegerEnumEdit()
            result = true
        }
    }
    override fun visit(integerHex: IntegerHex, data: Int) { /*@DONE CompleteCellEdit.Visit/15 cs:210-215*/
        if (currentText.last().isWhitespace() || currentText.last() == ')') {
            completeIntegerHexEdit(integerHex)
            result = true
        }
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE CompleteCellEdit.Visit/16 cs:217-217*/
        completeEggEdit()
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE CompleteCellEdit.Visit/17 cs:219-219*/
        completeEggEdit()
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE CompleteCellEdit.Visit/18 cs:221-262*/
        var location = this.memoryLocation
        val run = model.getNextRun(location) as PLMRun

        // part 1: contraction (if they entered the end token)
        if (currentText == EggMoveRun.groupStart + EggMoveRun.groupEnd) {
            var i = this.memoryLocation
            while (i < run.start + run.length) {
                model.writeMultiByteValue(i, 2, currentChange, 0xFFFF)
                i += 2
            }
            model.observeRunWritten(currentChange, PLMRun(model, run.start))
            newDataIndex = location + 2
            result = true
            return
        }

        // part 2: validation
        if (!currentText.contains(" ")) return
        val quoteCount = currentText.count { c -> c == PCSRun.stringDelimeter }
        if (quoteCount % 2 != 0) return
        if (!currentText.endsWith(PCSRun.stringDelimeter.toString()) && !currentText.endsWith(" ")) return
        val level = Ref(0)
        val move = Ref(0)
        errorText = validatePlmText(run, quoteCount, level, move)
        if (errorText != null || move.value == -1) return

        // part 3: write to the model
        newDataIndex = location + 2
        result = true
        val value = (level.value shl 9) + move.value
        val initialItemValue = model.readMultiByteValue(location, 2)
        model.writeMultiByteValue(location, 2, currentChange, value)

        // part 4: expansion
        if (initialItemValue == 0xFFFF) {
            val newRun = model.relocateForExpansion(currentChange, run, run.length + 2)
            if (newRun.start != run.start) {
                messageText = "Level Up Moves were automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                location += newRun.start - run.start
                newDataIndex = location + 2
                dataMoved = true
            }
            model.writeMultiByteValue(location + 2, 2, currentChange, 0xFFFF)
            val lvlRun = PLMRun(model, newRun.start)
            model.observeRunWritten(currentChange, lvlRun)
        }
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE CompleteCellEdit.Visit/19 cs:264-289*/
        var spaceless = currentText.replace(" ", "")
        if (spaceless.all { c -> ViewPort.allHexCharacters.contains(c) } && spaceless.length == array.length * 2) {
            handleHexChangeToBitArray(array, spaceless)
            return
        }
        if (currentText == "-") {
            handleBitArrayClear(array)
            return
        }
        if (currentText.endsWith(" ") && !currentText.startsWith("\"")) {
            spaceless = currentText.replace(" ", "")
            if (!(spaceless.all { c -> ViewPort.allHexCharacters.contains(c) } && (currentText.count { c -> c == ' ' } > 1 || spaceless.length == 2))) {
                handleBitArrayEntry(currentText)
                return
            }
        }
        if (currentText.startsWith("\"") && currentText.trim().endsWith("\"") && currentText.length > 1) {
            handleBitArrayEntry(currentText)
            return
        }
        if (currentText == "/") {
            newDataIndex = memoryLocation + array.length
            result = true
        }
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE CompleteCellEdit.Visit/20 cs:291-291*/
        visit(None.instance, data)
    }
    override fun visit(endStream: EndStream, data: Int) { /*@DONE CompleteCellEdit.Visit/21 cs:293-320*/
        // the only valid edit for an EndStream is to extend the stream, or to write the end token to move past it.

        if (currentText == "[]") {
            val tableRun = model.getNextRun(memoryLocation) as TableStreamRun
            val endTokenLength = tableRun.length - tableRun.elementLength * tableRun.elementCount
            newDataIndex = memoryLocation + endTokenLength
            result = true
        }
        if (currentText != "+") return

        result = true
        val run = model.getNextRun(memoryLocation) as TableStreamRun
        val newRun = run.append(currentChange, 1)

        if (newRun.start != run.start) {
            messageText = "Stream was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
            newDataIndex = memoryLocation + newRun.start - run.start
            dataMoved = true
        }

        model.observeRunWritten(currentChange, newRun)

        if (newRun.start == run.start) {
            // table was expanded, update the scroll so it knows about the new table length
            scroll.setTableMode(newRun.start, newRun.length)
        }
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE CompleteCellEdit.Visit/22 cs:322-327*/
        if (currentText.lowercase() == "lz") {
            result = true
            newDataIndex = memoryLocation + 1
        }
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE CompleteCellEdit.Visit/23 cs:329-344*/
        if (!currentText.endsWith(" ")) return
        val parsedHeader = Ref(0)
        if (tryParseHexByte(currentText, parsedHeader)) {
            val headerValue = parsedHeader.value
            val oldValue = model[memoryLocation]
            currentChange.changeData(model, memoryLocation, headerValue)
            val runRef = Ref(model.getNextRun(memoryLocation) as LZRun)
            val runIndex = memoryLocation - runRef.value.start
            result = true
            if (!tryFixupLzRun(runRef, runIndex + 1)) {
                currentChange.changeData(model, memoryLocation, oldValue)
                errorText = "Could not write header " + headerValue.toHexByte() + " without making the compressed data invalid."
            } else {
                newDataIndex = runRef.value.start + runIndex + 1
            }
        }
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE CompleteCellEdit.Visit/24 cs:346-372*/
        if (!currentText.endsWith(" ")) return
        val sections = currentText.trim().split(':')
        if (sections.size != 2) return
        val parsedLength = Ref(0)
        val parsedOffset = Ref(0)
        if (!tryParseInt(sections[0], parsedLength)) return
        if (!tryParseInt(sections[1], parsedOffset)) return
        result = true
        val runLength = parsedLength.value
        val runOffset = parsedOffset.value
        if (runLength < 3 || runLength > 18) {
            errorText = "Run Length must be > 2 and < 19"
            return
        } else if (runOffset < 1 || runOffset > 0x1000) {
            errorText = "Run Offset must be > 0 and <= 4096"
            return
        }
        val token = LZRun.compressedToken(runLength, runOffset.toShort())
        val previousValue = model.readMultiByteValue(memoryLocation, 2)
        currentChange.changeData(model, memoryLocation, token[0])
        currentChange.changeData(model, memoryLocation + 1, token[1])
        val runRef = Ref(model.getNextRun(memoryLocation) as LZRun)
        val runIndex = memoryLocation - runRef.value.start
        if (!tryFixupLzRun(runRef, runIndex + 2)) {
            model.writeMultiByteValue(memoryLocation, 2, currentChange, previousValue)
            errorText = "Could not write " + runLength + ":" + runOffset + " without making the compressed data invalid."
        } else {
            newDataIndex = runRef.value.start + runIndex + 2
        }
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE CompleteCellEdit.Visit/25 cs:374-391*/
        val spriteRun = model.getNextRun(memoryLocation)
        if (currentText == "+" && spriteRun is SpriteRun) {
            val newRun = spriteRun.increaseHeight(1, currentChange)
            if (newRun.start != spriteRun.start) {
                messageText = "Sprite was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                dataMoved = true
                newDataIndex = newRun.start + 1
            }
            result = true
        }

        if (!currentText.endsWith(" ")) return
        val parsedValue = Ref(0)
        if (tryParseHexByte(currentText, parsedValue)) {
            currentChange.changeData(model, memoryLocation, parsedValue.value)
            result = true
            newDataIndex = memoryLocation + 1
        }
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE CompleteCellEdit.Visit/26 cs:393-436*/
        if (!currentText.endsWith(" ")) return
        if (currentText.length < 4) return

        // option 1: 4 hex bytes
        val parsedColor = Ref(0)
        if (currentText.length == 5 && tryParseHexInt(currentText.trim(), parsedColor) && parsedColor.value >= 0 && parsedColor.value <= 0xFFFF) {
            model.writeMultiByteValue(memoryLocation, 2, currentChange, parsedColor.value)
            newDataIndex = memoryLocation + 2
            result = true
            return
        }

        // option 2: 2 hex bytes, a space, and 2 more hex bytes
        if (currentText.length == 6) {
            val byte1 = Ref(0)
            if (tryParseHexByte(currentText.substring(0, 2), byte1)) {
                val byte2 = Ref(0)
                if (tryParseHexByte(currentText.substring(3, 5), byte2)) {
                    currentChange.changeData(model, memoryLocation + 0, byte1.value)
                    currentChange.changeData(model, memoryLocation + 1, byte2.value)
                    newDataIndex = memoryLocation + 2
                    result = true
                    return
                }
            }
        }

        // option 3: 3 decimal values, separated by :
        val channels = currentText.trim().split(':')
        val red = Ref(0)
        val green = Ref(0)
        val blue = Ref(0)
        if (channels.size == 3 &&
            tryParseDecimalByte(channels[0], red) &&
            tryParseDecimalByte(channels[1], green) &&
            tryParseDecimalByte(channels[2], blue)) {
            val newColor = (blue.value shl 10) or (green.value shl 5) or red.value
            model.writeMultiByteValue(memoryLocation, 2, currentChange, newColor)
            newDataIndex = memoryLocation + 2
            result = true
            return
        }

        // incomplete
        if (currentText.count { c -> c == ' ' } > 1) {
            result = true
            errorText = "Could not parse " + currentText + " as a palette color."
        }
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE CompleteCellEdit.Visit/27 cs:438-451*/
        val tupleModel = tuple.model!!
        result = currentText.endsWith(")")
        if (currentText.endsWith(" ")) {
            val tokens = currentText.split(' ', '(', ')').filter { token -> token.isNotEmpty() }.toMutableList()
            TableStreamRun.recombine(tokens, "\"", "\"")
            if (tokens.size == tupleModel.visibleElementCount) result = true
        }

        if (result) {
            val text = Ref(currentText)
            tupleModel.write(null, model, currentChange, memoryLocation, text)
            newDataIndex = memoryLocation + tuple.length
        }
    }
    private fun validatePlmText(run: PLMRun, quoteCount: Int, level: Ref<Int>, move: Ref<Int>): String? { /*@DONE CompleteCellEdit.ValidatePlmText/1 cs:457-479*/
        level.value = 0
        move.value = 0
        if (quoteCount == 0) {
            val split = currentText.split(' ').filter { token -> token.isNotEmpty() }
            if (split.size < 2) { move.value = -1; return null } // user hasn't entered a move yet
            if (!currentText.endsWith(" ")) { move.value = -1; return null } // user is still entering a move
            if (!tryParseInt(split[0], level) || level.value < 1 || level.value > PLMRun.maxLearningLevel) {
                return "Could not parse '" + split[0] + "' as a pokemon level."
            } else if (!run.tryGetMoveNumber(split[1], move)) {
                return "Could not parse " + split[1] + " as a pokemon move."
            }
        } else {
            val rawLevel = currentText.substring(0, currentText.indexOf(' '))
            val rawMove = currentText.substring(rawLevel.length + 1)
            if (!tryParseInt(rawLevel, level) || level.value < 1 || level.value > PLMRun.maxLearningLevel) {
                return "Could not parse '" + rawLevel + "' as a pokemon level."
            } else if (!run.tryGetMoveNumber(rawMove, move)) {
                return "Could not parse " + rawMove + " as a pokemon move."
            }
        }

        return null
    }
    private fun completeIntegerHexEdit(integerHex: IntegerHex) { /*@DONE CompleteCellEdit.CompleteIntegerHexEdit/1 cs:481-502*/
        val sanitizedText = currentText.replace(')', ' ')
        val parsed = Ref(0)
        if (!tryParseHexInt(sanitizedText, parsed)) {
            errorText = "Could not parse " + currentText + " as a hex number"
            return
        }

        model.writeMultiByteValue(integerHex.source, integerHex.length, currentChange, parsed.value)
        if (parsed.value.toDouble() >= Math.pow(2.0, integerHex.length * 8.0)) errorText = "Warning: number was too big to fit in the available space."
        val run = model.getNextRun(memoryLocation)
        if (run is PIERun) {
            val newRun = run.refresh(currentChange)
            if (newRun.start != run.start) {
                messageText = "Item effect was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                newDataIndex = memoryLocation + newRun.start - run.start + integerHex.length
                dataMoved = true
            }
            model.observeRunWritten(currentChange, newRun)
            newDataIndex = memoryLocation + newRun.start - run.start + integerHex.length
        } else {
            newDataIndex = integerHex.source + integerHex.length
        }
    }
    private fun completeIntegerEdit(integer: Integer) { /*@DONE CompleteCellEdit.CompleteIntegerEdit/1 cs:504-538*/
        val sanitizedText = currentText.replace(')', ' ')
        val parsed = Ref(0)
        if (!tryParseInt(sanitizedText, parsed)) {
            errorText = "Could not parse " + currentText + " as a number"
            return
        }
        val newValue = parsed.value

        var run: IFormattedRun = model.getNextRun(memoryLocation) ?: NoInfoRun.nullRun
        val wordRun1 = run
        if (wordRun1 is WordRun) {
            val desiredValue = newValue - wordRun1.valueOffset
            val maxValue = (1L shl (wordRun1.length * 8)) - 1
            if (desiredValue < 0 || desiredValue.toLong() > maxValue) {
                errorText = "Virtual value out of range!"
                return
            }
        }
        val previousValue = model.readMultiByteValue(integer.source, integer.length)
        model.writeMultiByteValue(integer.source, integer.length, currentChange, newValue)
        if (newValue.toDouble() >= Math.pow(2.0, integer.length * 8.0)) errorText = "Warning: number was too big to fit in the available space."
        val runIndex = integer.source - run.start
        val lzCandidate = run
        if (lzCandidate is LZRun) {
            val lzRef = Ref(lzCandidate)
            tryFixupLzRun(lzRef, runIndex + integer.length) // this is before the first header: it cannot fail.
            run = lzRef.value
        }
        val tableCandidate = run
        if (tableCandidate is ITableRun) {
            val offset = tableCandidate.convertByteOffsetToArrayOffset(integer.source)
            val info = tableCandidate.notifyChildren(model, currentChange, offset.elementIndex, offset.segmentIndex, previousValue)
            scroll.dataLength = model.count
            if (info != null && info.isWarning) messageText = info.errorMessage
        }
        val updated = updateAllWords(model, run, currentChange, newValue, true)
        newDataIndex = run.start + runIndex + integer.length
        messageText = updated.message ?: messageText
        if (updated.errorIndex >= 0) {
            newDataIndex = updated.errorIndex
            errorText = updated.error
        }
    }
    private fun completeIntegerEnumEdit() { /*@DONE CompleteCellEdit.CompleteIntegerEnumEdit/1 cs:610-627*/
        val sanitizedText = currentText.replace(')', ' ')
        val array = model.getNextRun(memoryLocation) as? ITableRun
        if (array == null) {
            errorText = "Enum does not appear to be in a table."
            return
        }
        val offsets = array.convertByteOffsetToArrayOffset(memoryLocation)
        var contentSegment = array.elementContent[offsets.segmentIndex]
        if (contentSegment is ArrayRunRecordSegment) contentSegment = contentSegment.createConcrete(model, memoryLocation)
        val segment = contentSegment as ArrayRunEnumSegment
        val enumValue = Ref(0)
        if (segment.tryParse(model, sanitizedText, enumValue)) {
            model.writeMultiByteValue(offsets.segmentStart, segment.length, currentChange, enumValue.value)
            newDataIndex = offsets.segmentStart + segment.length
        } else {
            errorText = "Could not parse " + currentText + " as an enum from the " + segment.enumName + " array."
        }
    }
    private fun completeBrailleCharacterEdit(brailleFormat: Braille) { /*@DONE CompleteCellEdit.CompleteBrailleCharacterEdit/1 cs:629-653*/
        var location = this.memoryLocation

        // complete edit on this cell
        // move to next cell, potentially increasing the run length.
        var run = model.getNextRun(location) as BrailleRun
        val content = BrailleRun.deserializeCharacter(currentText[0])
        currentChange.changeData(model, location, content)
        newCell = HexElement(content, true, Braille(brailleFormat.source, brailleFormat.position, currentText[0]))

        if (newDataIndex == run.start + run.length) {
            val newRun = model.relocateForExpansion(currentChange, run, run.length + 1)
            if (newRun !== run) {
                messageText = "Braille text was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                location += newRun.start - run.start
                run = newRun
                dataMoved = true
            }

            run = BrailleRun(model, run.start, run.pointerSources)
            model.observeRunWritten(currentChange, run)
        }

        newDataIndex = location + 1
    }
    private fun completeBrailleStringEdit(format: Braille) { /*@DONE CompleteCellEdit.CompleteBrailleStringEdit/1 cs:655-661*/
        val run = model.getNextRun(memoryLocation) as BrailleRun
        for (i in format.source + format.position until run.start + run.length) currentChange.changeData(model, i, 0xFF)
        newCell = HexElement(0xFF, true, Braille(format.source, format.position, PCSRun.stringDelimeter))
        newDataIndex = memoryLocation + 1
        model.observeRunWritten(currentChange, BrailleRun(model, run.start, run.pointerSources))
    }
    private fun completePointerEdit() { /*@DONE CompleteCellEdit.CompletePointerEdit/1 cs:663-711*/
        // if they just started a pointer and then clicked off, there's nothing to complete
        if (currentText == PointerRun.pointerStart.toString() + " ") return

        val destination = currentText.substring(1, currentText.length - 1)

        if (destination.length == 2 && destination.all { c -> ViewPort.allHexCharacters.contains(c) }) { completeHexEdit(destination); return }

        model.expandData(currentChange, memoryLocation + 3)

        var currentRun: IFormattedRun? = model.getNextRun(memoryLocation)
        if (currentRun != null && currentRun.start > memoryLocation) currentRun = null
        val inArray = currentRun is ITableRun && currentRun.start <= memoryLocation
        var sources = currentRun?.pointerSources
        val previousRawDestination = model.readValue(memoryLocation) - BaseModel.pointerOffset // we care what the bytes are, not the logical destination

        if (!inArray) {
            model.clearFormat(currentChange, memoryLocation, 4)
            sources = null
        }

        val parsedDestination = parseDestination(destination)
        val destinationValue = parsedDestination.first
        val offset = parsedDestination.second
        if (destinationValue + offset != previousRawDestination) {
            model.clearPointer(currentChange, memoryLocation, previousRawDestination)
            model.clearData(currentChange, memoryLocation, 4)
        }

        val fullValue = destinationValue + offset
        if (fullValue == Pointer.null_ || (0 <= fullValue && fullValue < model.count)) {
            if (inArray) {
                updateArrayPointer(currentRun as ITableRun, fullValue)
            } else {
                if (model.readPointer(memoryLocation) != fullValue) {
                    model.writePointer(currentChange, memoryLocation, fullValue)
                }
                var newRun: PointerRun = PointerRun(memoryLocation, sources)
                if (offset != 0) newRun = OffsetPointerRun(memoryLocation, offset, sources)
                model.observeRunWritten(currentChange, newRun)
            }

            newDataIndex = memoryLocation + 4
        } else {
            if (offset == 0) {
                errorText = "Address " + destinationValue.toHex(2) + " is not within the data."
            } else {
                errorText = "Address " + destinationValue.toHex(2) + "+" + offset + " is not within the data."
            }
        }
    }
    private fun parseDestination(destination: String): Pair<Int, Int> { /*@DONE CompleteCellEdit.ParseDestination/1 cs:717-747*/
        var dest = destination
        var destinationValue: Int
        var offset = 0
        if (dest == "") {
            destinationValue = model.readPointer(memoryLocation)
        } else if (dest.all { c -> ViewPort.allHexCharacters.contains(c) } && dest.length <= 7) {
            while (dest.length < 6) dest = "0" + dest
            destinationValue = parseHexInt(dest)
        } else if (dest.contains("+") && !dest.contains("-")) {
            val destinationParts = dest.split('+')
            val parsedDestination = Ref(0)
            if (!tryParseHexInt(destinationParts[0], parsedDestination)) {
                parsedDestination.value = model.getAddressFromAnchor(currentChange, memoryLocation, destinationParts[0])
            }
            destinationValue = parsedDestination.value
            val parsedOffset = Ref(0)
            if (!tryParseHexInt(destinationParts[1], parsedOffset)) {
                errorText = "Could not parse " + destinationParts[0] + "+" + destinationParts[1] + " into an address."
            }
            offset = parsedOffset.value
        } else if (dest.contains("-") && !dest.contains("+")) {
            val destinationParts = dest.split('-')
            val parsedDestination = Ref(0)
            if (!tryParseHexInt(destinationParts[0], parsedDestination)) {
                parsedDestination.value = model.getAddressFromAnchor(currentChange, memoryLocation, destinationParts[0])
            }
            destinationValue = parsedDestination.value
            val parsedOffset = Ref(0)
            if (!tryParseHexInt(destinationParts[1], parsedOffset)) {
                errorText = "Could not parse " + destinationParts[0] + "-" + destinationParts[1] + " into an adress."
            }
            offset = -parsedOffset.value
        } else {
            destinationValue = model.getAddressFromAnchor(currentChange, memoryLocation, dest)
        }

        return Pair(destinationValue, offset)
    }
    private fun completeWordEdit() { /*@DONE CompleteCellEdit.CompleteWordEdit/1 cs:749-761*/
        val parentName = currentText.substring(2).trim()
        if (parentName == "") {
            errorText = "Cannot write constant with no name."
            return
        }

        model.expandData(currentChange, memoryLocation + 3)
        model.clearFormat(currentChange, memoryLocation, 4)
        currentChange.addMatchedWord(model, memoryLocation, parentName, 4)
        model.observeRunWritten(currentChange, WordRun(memoryLocation, parentName, 4, 0, 1))
        newDataIndex = memoryLocation + 4
    }
    private fun completeNamedConstantEdit(byteCount: Int) { /*@DONE CompleteCellEdit.CompleteNamedConstantEdit/1 cs:763-827*/
        var constantName = currentText.substring(1).trim()
        var offset = 0
        var multOffset = 1
        var newValue = Int.MIN_VALUE
        if (constantName.contains("=")) {
            val split = constantName.split('=')
            val parsedNew = Ref(0)
            newValue = if (tryParseInt(split[1], parsedNew)) parsedNew.value else Int.MIN_VALUE
            constantName = split[0]
        }
        if (constantName.contains("+")) {
            val split = constantName.split('+')
            val parsedOffset = Ref(0)
            tryParseInt(split[1], parsedOffset)
            offset = parsedOffset.value
            constantName = split[0]
        }
        if (constantName.contains("-")) {
            val split = constantName.split('-')
            val parsedOffset = Ref(0)
            tryParseInt(split[1], parsedOffset)
            offset = parsedOffset.value
            constantName = split[0]
            offset = -offset
        }
        if (constantName.contains("*")) {
            val split = constantName.split('*')
            val parsedMult = Ref(0)
            tryParseInt(split[1], parsedMult)
            multOffset = parsedMult.value
            constantName = split[0]
            if (multOffset < 1) {
                errorText = "Could not create " + constantName + " with multiplier " + multOffset + ": the multiplier must be positive."
                return
            }
        }
        if (constantName == "") {
            errorText = "Cannot write constant with no name."
            return
        }
        val addresses = model.getMatchedWords(constantName) ?: emptyList<Int>()
        if (currentChange !is NoDataChangeDeltaModel && newValue == Int.MIN_VALUE && addresses.size > 0) {
            val valueSource = model.getNextRun(addresses[0]) as WordRun
            var value = model.readMultiByteValue(valueSource.start, valueSource.length)
            value /= valueSource.multOffset
            value -= valueSource.valueOffset
            model.writeMultiByteValue(memoryLocation, byteCount, currentChange, (value + offset) * multOffset)
            newValue = (value + offset) * multOffset
        }

        // var coreValue = (Model[memoryLocation] / multOffset) - offset;
        var coreValue = model.readMultiByteValue(memoryLocation, byteCount) / multOffset - offset
        if (newValue != Int.MIN_VALUE) coreValue = newValue / multOffset - offset
        val maxValue = (1L shl (byteCount * 8)) - 1
        if (coreValue < 0) {
            if (offset != 0) {
                errorText = "Could not create " + constantName + " with offset " + offset + " because then the virtual value would be below 0."
            } else if (multOffset != 1) {
                errorText = "Could not create " + constantName + " with multiplier " + multOffset + " because then the virtual value would be below 0."
            }
        } else if (coreValue.toLong() > maxValue) {
            if (offset != 0) {
                errorText = "Could not create " + constantName + " with offset " + offset + " because then the virtual value would be above " + maxValue + "."
            } else if (multOffset != 1) {
                errorText = "Could not create " + constantName + " with multiplier " + offset + " because then the virtual value would be above " + maxValue + "."
            }
        } else {
            if (newValue != Int.MIN_VALUE) model.writeMultiByteValue(memoryLocation, byteCount, currentChange, newValue)
            currentChange.addMatchedWord(model, memoryLocation, constantName, byteCount)
            model.observeRunWritten(currentChange, WordRun(memoryLocation, constantName, byteCount, offset, multOffset))
            newDataIndex = memoryLocation + (if (newValue != Int.MIN_VALUE) byteCount else 0)
        }
    }
    private fun completeStringEdit() { /*@DONE CompleteCellEdit.CompleteStringEdit/1 cs:829-853*/
        var location = this.memoryLocation

        // all the bytes are already correct, just move to the next space
        val run = model.getNextRun(location)
        if (run is PCSRun) {
            while (run.start + run.length > location) {
                currentChange.changeData(model, location, 0xFF)
                location++
                newDataIndex = location
                val newRunLength = PCSString.readString(model, run.start, true)
                model.observeRunWritten(currentChange, PCSRun(model, run.start, newRunLength, run.pointerSources))
            }
        } else if (run is ITableRun) {
            val offsets = run.convertByteOffsetToArrayOffset(location)
            currentChange.changeData(model, location, 0xFF)
            location++
            newDataIndex = location
            while (offsets.segmentStart + run.elementContent[offsets.segmentIndex].length > location) {
                currentChange.changeData(model, location, 0x00)
                location++
                newDataIndex = location
            }
        }
    }
    private fun completeCharacterEdit(originalFormat: IDataFormat) { /*@DONE CompleteCellEdit.CompleteCharacterEdit/1 cs:855-876*/
        var editText = currentText
        if (editText.startsWith("\"")) editText = editText.substring(1)
        val escaped = originalFormat as? EscapedPCS
        val run = model.getNextRun(memoryLocation) ?: NoInfoRun.nullRun

        if (model.textConverter.anyMacroStartsWith(editText)) {
            val containsBadCharacters = Ref(false)
            val byteValues = model.textConverter.convert(editText, containsBadCharacters)
            if (!containsBadCharacters.value && byteValues != null && byteValues.size > 2) {
                val trimmed = byteValues.take(byteValues.size - 1) // remove the FF at the end of the convert
                handleLastCharacterChange(memoryLocation, run, trimmed.toByteArrayU().asByteList())
                return
            }
        }

        var byteValue = 0
        if (escaped != null) {
            val parsedByte = Ref(0)
            if (tryParseHexByte(currentText, parsedByte)) byteValue = parsedByte.value
        } else {
            for (i in 0 until 0x100) {
                if (PCSString.pcs[i] == editText) {
                    byteValue = i
                    break
                }
            }
        }

        val streamInstance = originalFormat as? IDataFormatStreamInstance
        val position = if (streamInstance != null) streamInstance.position else escaped!!.position
        handleLastCharacterChange(memoryLocation, editText, run, position, byteValue)
    }
    private fun handleLastCharacterChange(memoryLocation: Int, editText: String, run: IFormattedRun, position: Int, byteValue: Int) { /*@DONE CompleteCellEdit.HandleLastCharacterChange/1 cs:878-911*/
        var location = memoryLocation
        var currentRun = run
        if (currentRun is PCSRun) {
            // if its the last character being edited on a normal string, try to expand
            if (currentRun.length == position + 1) {
                val extraBytesNeeded = if (editText == "\\\\") 2 else 1
                // last character edit: might require relocation
                val newRun = model.relocateForExpansion(currentChange, currentRun, currentRun.length + extraBytesNeeded)
                if (newRun !== currentRun) {
                    messageText = "Text was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                    location += newRun.start - currentRun.start
                    currentRun = newRun
                    dataMoved = true
                }

                currentChange.changeData(model, location + 1, 0xFF)
                if (editText == "\\\\") currentChange.changeData(model, location + 2, 0xFF)
                currentRun = PCSRun(model, currentRun.start, currentRun.length + extraBytesNeeded, currentRun.pointerSources)
                model.observeRunWritten(currentChange, currentRun)
            }
        } else if (currentRun is ITableRun) {
            // if the last character is being edited for an array, truncate
            val offsets = currentRun.convertByteOffsetToArrayOffset(location)
            if (currentRun.elementContent[offsets.segmentIndex].length == position + 1) {
                location-- // move back one byte and edit that one instead
            } else if (model[location] == 0xFF) {
                currentChange.changeData(model, location + 1, 0xFF) // overwrote the closing ", so add a new one after (since there's room)
            }
        } else {
            Debug.fail("Why are we completing a character edit on something other than a PCSRun or an Array?")
        }

        currentChange.changeData(model, location, byteValue)
        newDataIndex = location + 1
    }
    private fun handleLastCharacterChange(memoryLocation: Int, run: IFormattedRun, bytes: ByteList) { /*@DONE CompleteCellEdit.HandleLastCharacterChange/2 cs:913-939*/
        var location = memoryLocation
        var currentRun = run
        if (currentRun is PCSRun) {
            if (currentRun.length < location - currentRun.start + bytes.count + 1) {
                val newRun = model.relocateForExpansion(currentChange, currentRun, currentRun.length + bytes.count)
                if (newRun !== currentRun) {
                    messageText = "Text was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                    location += newRun.start - currentRun.start
                    currentRun = newRun
                    dataMoved = true
                }
                currentChange.changeData(model, location + bytes.count, 0xFF)
                currentRun = PCSRun(model, currentRun.start, location - currentRun.start + bytes.count + 1, currentRun.pointerSources)
                model.observeRunWritten(currentChange, currentRun)
            }
        } else if (currentRun is ITableRun) {
            val offsets = currentRun.convertByteOffsetToArrayOffset(location)
            while (currentRun.elementContent[offsets.segmentIndex].length < location - offsets.segmentStart + bytes.count + 1) {
                location-- // move back one byte and edit that one instead
            }
            var anyClosingQuote = false
            for (i in 0 until bytes.count) {
                if (model[location + i] == 0xFF) anyClosingQuote = true
            }
            if (anyClosingQuote) {
                currentChange.changeData(model, location + bytes.count, 0xFF) // overwrote the closing ", so add a new one after (since there's room)
            }
        }

        currentChange.changeData(model, location, bytes)
        newDataIndex = location + bytes.count
    }
    private fun completeHexEdit(currentText: String) { /*@DONE CompleteCellEdit.CompleteHexEdit/1 cs:941-947*/
        val parsedByte = Ref(0)
        if (!tryParseHexByte(currentText, parsedByte)) {
            errorText = "Could not parse " + currentText + " as a hex byte."
            return
        }
        val run = model.getNextRun(memoryLocation) ?: NoInfoRun.nullRun
        if (!(run is NoInfoRun || run is IScriptStartRun) || run.start != memoryLocation) model.clearFormat(currentChange, memoryLocation, 1)
        currentChange.changeData(model, memoryLocation, parsedByte.value)
        newDataIndex = memoryLocation + 1
    }
    private fun completeEggEdit() { /*@DONE CompleteCellEdit.CompleteEggEdit/1 cs:949-992*/
        val endChar = currentText[currentText.length - 1]
        if (!(EggMoveRun.groupEnd + " " + PCSRun.stringDelimeter).contains(endChar)) return
        if (currentText.count { c -> c == PCSRun.stringDelimeter } % 2 != 0) return

        newDataIndex = memoryLocation + 2
        result = true
        val run = model.getNextRun(memoryLocation) as EggMoveRun

        if (currentText == EggMoveRun.groupStart + EggMoveRun.groupEnd) {
            model.writeMultiByteValue(memoryLocation, 2, currentChange, 0xFFFF)
            // clear all data after this and shorten the run
            var i = memoryLocation + 2
            while (i < run.start + run.length) {
                model.writeMultiByteValue(i, 2, currentChange, 0xFFFF)
                i += 2
            }
            var newRun = EggMoveRun(model, run.start)
            model.observeRunWritten(currentChange, newRun)
            newRun = model.getNextRun(newRun.start) as EggMoveRun
            newRun.updateLimiter(currentChange)
        } else if (currentText.endsWith(EggMoveRun.groupEnd)) {
            val value = run.getPokemonNumber(currentText)
            if (value == -1) {
                errorText = "Could not parse " + currentText + " as a pokemon name"
                newDataIndex -= 2
            } else {
                writeNormalEggEdit(run, value + EggMoveRun.magicNumber)
            }
        } else {
            val text = currentText.trim()
            var value = run.getMoveNumber(text)
            if (value == -1) {
                // wasn't a move... try again as a pokemon even though they didn't use the []
                value = run.getPokemonNumber(text)
                if (value == -1) {
                    errorText = "Could not parse " + text + " as a move name or pokemon name"
                    newDataIndex -= 2
                } else {
                    writeNormalEggEdit(run, value + EggMoveRun.magicNumber)
                }
            } else {
                writeNormalEggEdit(run, value)
            }
        }
    }
    private fun writeNormalEggEdit(run: EggMoveRun, value: Int) { /*@DONE CompleteCellEdit.WriteNormalEggEdit/1 cs:997-1015*/
        var location = this.memoryLocation
        val initialItemValue = model.readMultiByteValue(location, 2)
        model.writeMultiByteValue(location, 2, currentChange, value)
        if (initialItemValue == 0xFFFF) {
            val newRun = model.relocateForExpansion(currentChange, run, run.length + 2)
            if (newRun.start != run.start) {
                messageText = "Egg Moves were automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
                location += newRun.start - run.start
                newDataIndex = location + 2
                dataMoved = true
            }
            model.writeMultiByteValue(location + 2, 2, currentChange, 0xFFFF)
            var eggRun = EggMoveRun(model, newRun.start)
            model.observeRunWritten(currentChange, eggRun)
            eggRun = model.getNextRun(eggRun.start) as EggMoveRun
            eggRun.updateLimiter(currentChange)
        }
    }
    private fun handleHexChangeToBitArray(array: BitArray, currentText: String) { /*@DONE CompleteCellEdit.HandleHexChangeToBitArray/1 cs:1017-1031*/
        val parseArray = IntArray(array.length)

        for (i in 0 until array.length) {
            val parsedByte = Ref(0)
            if (!tryParseHexByte(currentText.substring(i * 2, i * 2 + 2), parsedByte)) {
                errorText = "Could not parse " + this.currentText + " as a bit-array."
                return
            }
            parseArray[i] = parsedByte.value
        }
        for (i in 0 until array.length) currentChange.changeData(model, memoryLocation + i, parseArray[i])

        newDataIndex = memoryLocation + array.length
        result = true
    }
    private fun handleBitArrayClear(array: BitArray) { /*@DONE CompleteCellEdit.HandleBitArrayClear/1 cs:1033-1037*/
        for (i in 0 until array.length) currentChange.changeData(model, memoryLocation + i, 0)
        newDataIndex = memoryLocation
        result = true
    }
    private fun handleBitArrayEntry(currentText: String) { /*@DONE CompleteCellEdit.HandleBitArrayEntry/1 cs:1039-1058*/
        val entryText = currentText.replace("\"", "").trim()
        val run = model.getNextRun(memoryLocation) as ITableRun
        val offset = run.convertByteOffsetToArrayOffset(memoryLocation)
        val segment = run.elementContent[offset.segmentIndex] as ArrayRunBitArraySegment
        val sourceName = segment.sourceArrayName
        val options = model.getBitOptions(sourceName)
        var bit = if (options != null) options.indexOfPartial(entryText) else -1
        if (bit == -1) {
            errorText = "Could not parse " + this.currentText + " as a bit name."
            return
        }

        var dataIndex = memoryLocation
        while (bit >= 8) { dataIndex++; bit -= 8 }
        val newData = model[dataIndex] or (1 shl bit)
        currentChange.changeData(model, dataIndex, newData)
        newDataIndex = memoryLocation
        result = true
    }
    private fun updateArrayPointer(run: ITableRun, pointerDestination: Int) { /*@DONE CompleteCellEdit.UpdateArrayPointer/1 cs:1060-1072*/
        val offsets = run.convertByteOffsetToArrayOffset(memoryLocation)
        var segment = run.elementContent[offsets.segmentIndex]
        if (segment is ArrayRunRecordSegment) segment = segment.createConcrete(model, offsets.segmentStart)
        if (segment is ArrayRunPointerSegment) {
            if (!segment.destinationDataMatchesPointerFormat(model, currentChange, offsets.segmentStart, pointerDestination, run.elementContent, -1)) {
                errorText = "This pointer must point to " + segment.innerFormat + " data."
                return
            }
        }

        model.updateArrayPointer(currentChange, segment, run.elementContent, offsets.elementIndex, memoryLocation, pointerDestination)
    }
    private fun tryFixupLzRun(run: Ref<LZRun>, runIndex: Int): Boolean { /*@DONE CompleteCellEdit.TryFixupLzRun/1 cs:1074-1083*/
        val initialStart = run.value.start
        val newRun = run.value.fixupEnd(model, currentChange, runIndex)
        if (newRun == null) return false

        model.observeRunWritten(currentChange, newRun)
        if (newRun.start != initialStart) messageText = "LZ Compressed data was automatically moved to " + newRun.start.toHex(6) + ". Pointers were updated."
        run.value = newRun
        return true
    }
    companion object {
        fun updateAllWords(model: IDataModel, run: IFormattedRun, token: ModelDelta, value: Int, alsoUpdateArrays: Boolean): CompleteCellEditUpdateAllWordsTuple { /*@DONE CompleteCellEdit.UpdateAllWords/1 cs:540-608*/
            var newDataIndex = -1
            var messageText: String? = null
            var errorText: String? = null

            if (run is WordRun) {
                // update the other word runs with the same token name
                val desiredValue = (value - run.valueOffset) / run.multOffset

                if (alsoUpdateArrays) {
                    val sourceName = run.sourceArrayName
                    for (array in model.arrays.filter { a -> a.lengthFromAnchor == sourceName }.toList()) {
                        val delta = desiredValue - array.elementCount
                        if (delta == 0) continue
                        var newArray: ArrayRun = array
                        if (token !is NoDataChangeDeltaModel) {
                            // relocate if needed
                            newArray = model.relocateForExpansion(token, array, (array.elementCount + delta) * array.elementLength)
                        }
                        newArray = newArray.append(token, delta)
                        if (token is NoDataChangeDeltaModel && newArray.supportsInnerPointers) {
                            // the new 'added' elements may have stuff pointing to them, because they were already there
                            newArray = newArray.addSourcesPointingWithinArray(token)
                        }
                        if (newArray !== array) {
                            var name = newArray.start.toAddress()
                            val anchorName = model.getAnchorFromAddress(-1, newArray.start)
                            if (anchorName.isNotBlank()) name = anchorName
                            if (newArray.start != array.start) {
                                messageText = "Table " + name + " was moved. Pointers have been updated."
                            } else {
                                messageText = "Table " + name + " was resized. Address has not changed."
                            }
                            if (newArray.length > array.length && newArray.start == array.start) {
                                model.clearFormat(token, array.start + array.length, newArray.length - array.length)
                                // edge case: if the run in this spot isn't the run we're about to add, clear that too
                                if ((model.getNextRun(newArray.start) ?: NoInfoRun.nullRun).start != newArray.start) {
                                    model.clearFormat(token, newArray.start, array.length)
                                }
                            }

                            // clear any anchors that would be added as inner-pointers
                            var nextRun: IFormattedRun = model.getNextRun(newArray.start) ?: NoInfoRun.nullRun
                            while (nextRun.start < newArray.start + newArray.length) {
                                if (nextRun.start != newArray.start) model.clearAnchor(token, nextRun.start, nextRun.length)
                                nextRun = model.getNextRun(nextRun.start + nextRun.length) ?: NoInfoRun.nullRun
                            }
                            model.observeRunWritten(token, newArray)

                            // if this run has pointers, those may have been cleared by some earlier update
                            model.insertPointersToRun(token, newArray)
                        }
                    }
                }

                if (token is NoDataChangeDeltaModel) return CompleteCellEditUpdateAllWordsTuple(newDataIndex, messageText, errorText)
                for (address in model.getMatchedWords(run.sourceArrayName) ?: emptyList<Int>()) {
                    if (address == run.start) continue // don't write the current run
                    val currentRun = model.getNextRun(address)
                    if (currentRun !is WordRun) continue
                    val writeValue = desiredValue * currentRun.multOffset + currentRun.valueOffset
                    val maxValue = (1L shl (currentRun.length * 8)) - 1
                    if (writeValue < 0 || writeValue.toLong() > maxValue) {
                        newDataIndex = currentRun.start
                        errorText = currentRun.start.toHex(6) + ": value out of range!"
                    }
                    model.writeMultiByteValue(address, currentRun.length, token, writeValue)
                }
            }

            return CompleteCellEditUpdateAllWordsTuple(newDataIndex, messageText, errorText)
        }
        /*@END CompleteCellEdit.Companion*/
    }
    /*@ADD CompleteCellEdit#vis_2.txt*/
    private fun tryParseHexByte(text: String, byteValue: Ref<Int>): Boolean {
        val parsed = Ref(0)
        if (!tryParseHexInt(text, parsed)) return false
        if (parsed.value < 0 || parsed.value > 0xFF) return false
        byteValue.value = parsed.value
        return true
    }
    private fun tryParseDecimalByte(text: String, byteValue: Ref<Int>): Boolean {
        val parsed = Ref(0)
        if (!tryParseInt(text, parsed)) return false
        if (parsed.value < 0 || parsed.value > 0xFF) return false
        byteValue.value = parsed.value
        return true
    }
    /*@ENDADD CompleteCellEdit#vis_2.txt*/
    /*@END CompleteCellEdit*/
}

data class CompleteCellEditUpdateAllWordsTuple(val errorIndex: Int, val message: String?, val error: String?)
