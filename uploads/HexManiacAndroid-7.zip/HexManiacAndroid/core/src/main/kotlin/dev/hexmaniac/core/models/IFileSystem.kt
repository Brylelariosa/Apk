// Port of Models/IFileSystem.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.images.*

interface IFileSystem { // cs:10-136
    var copyText: String?
    var copyImage: IFileSystemCopyImageTuple
    fun requestNewName(currentName: String, extensionDescription: String? = null, vararg extensionOptions: String): String?
    fun openFile(extensionDescription: String? = null, vararg extensionOptions: String): LoadedFile?
    fun openFolder(): String?
    fun exists(file: String): Boolean
    fun launchProcess(file: String, arguments: String? = null)
    fun loadFile(fileName: String): LoadedFile?
    fun addListenerToFile(fileName: String, listener: (IFileSystem) -> Unit)
    fun removeListenerForFile(fileName: String, listener: (IFileSystem) -> Unit)
    fun save(file: LoadedFile): Boolean
    fun saveMetadata(originalFileName: String, metadata: Array<String>?): Boolean
    fun trySavePrompt(file: LoadedFile): Boolean?
    fun metadataFor(fileName: String): Array<String>?
    fun loadImage(fileName: String? = null): IFileSystemLoadImageTuple
    fun tryLoadIndexedImage(fileName: Ref<String?>, image: Ref<Array<IntArray>?>, palette: Ref<List<Short>?>): Boolean
    fun saveImage(image: ShortArray, width: Int, fileName: String? = null)
    fun saveImage(image: Array<IntArray>, palette: List<Short>, fileName: String? = null)
    fun showOptions(title: String, prompt: String, additionalDetails: List<List<Any>>?, vararg options: VisualOption): Int
    fun requestText(title: String, prompt: String): String?
    fun showCustomMessageBox(message: String, showYesNoCancel: Boolean = true, vararg links: ProcessModel): Boolean?
    /*@END IFileSystem*/
}

data class ProcessModel(val displayText: String, val content: String) { // cs:138-138
    /*@END ProcessModel*/
}

interface IWorkDispatcher { // cs:140-163
    fun waitForRenderingAsync(): Task<Unit>
    fun blockOnUIWork(action: () -> Unit)
    fun dispatchWork(action: (() -> Unit)?): Task<Unit>
    fun runBackgroundWork(action: () -> Unit): Task<Unit>
    fun createDelayTimer(): IDelayWorkTimer
    /*@END IWorkDispatcher*/
}

open class ImmediateWorkTimer : IDelayWorkTimer { // cs:165-174
    override val hasScheduledWork: Boolean
        get() { /*@DONE ImmediateWorkTimer.HasScheduledWork.get cs:166-166*/
            return false
        }
    override fun delayCall(delay: TimeSpan, action: () -> Unit): DelayWorkResult { /*@DONE ImmediateWorkTimer.DelayCall/1 cs:168-171*/
        action.invoke()
        return DelayWorkResult.WorkScheduled
    }
    override fun reset() { /*@DONE ImmediateWorkTimer.Reset/1 cs:173-173*/
        // nothing to reset
    }
    /*@END ImmediateWorkTimer*/
}

open class ManualWorkTimer : IDelayWorkTimer { // cs:176-193
    private var work: (() -> Unit)? = null
    override val hasScheduledWork: Boolean
        get() { /*@DONE ManualWorkTimer.HasScheduledWork.get cs:179-179*/
            return work != null
        }
    override fun delayCall(delay: TimeSpan, action: () -> Unit): DelayWorkResult { /*@DONE ManualWorkTimer.DelayCall/1 cs:181-185*/
        val result = if (work == null) DelayWorkResult.WorkScheduled else DelayWorkResult.WorkScheduledAndPreviousWorkCleared
        work = action
        return result
    }
    override fun reset() { /*@DONE ManualWorkTimer.Reset/1 cs:187-187*/
        work = null
    }
    fun runWork() { /*@DONE ManualWorkTimer.RunWork/1 cs:189-192*/
        work?.invoke()
        work = null
    }
    /*@END ManualWorkTimer*/
}

open class InstantDispatch : IWorkDispatcher { // cs:194-201
    override fun waitForRenderingAsync(): Task<Unit> { /*@DONE InstantDispatch.WaitForRenderingAsync/1 cs:196-196*/
        return Task.completedTask
    }
    override fun blockOnUIWork(action: () -> Unit) { /*@DONE InstantDispatch.BlockOnUIWork/1 cs:197-197*/
        action()
    }
    override fun dispatchWork(action: (() -> Unit)?): Task<Unit> { /*@DONE InstantDispatch.DispatchWork/1 cs:198-198*/
        action?.invoke()
        return Task.completedTask
    }
    override fun runBackgroundWork(action: () -> Unit): Task<Unit> { /*@DONE InstantDispatch.RunBackgroundWork/1 cs:199-199*/
        return dispatchWork(action)
    }
    override fun createDelayTimer(): IDelayWorkTimer { /*@DONE InstantDispatch.CreateDelayTimer/1 cs:200-200*/
        return ImmediateWorkTimer()
    }
    companion object {
        var instance: IWorkDispatcher = /*@INITAUTO InstantDispatch.Instance cs:195-195*/ InstantDispatch() /*@ENDINIT*/
            private set
        /*@END InstantDispatch.Companion*/
    }
    /*@END InstantDispatch*/
}

open class ControlledDispatch : IWorkDispatcher { // cs:203-239
    private data class Dispatch(val action: (() -> Unit)?, val cancellationSource: CancellationTokenSource) { // cs:204-204
        /*@END ControlledDispatch.Dispatch*/
    }
    private val workloads: MutableList<Dispatch> = /*@INITDONE ControlledDispatch.workloads cs:205-205*/ ArrayList<Dispatch>() /*@ENDINIT*/
    var waitForRenderingAsync: Task<Unit> = /*@INITDONE ControlledDispatch.WaitForRenderingAsync cs:207-207*/ Task.completedTask /*@ENDINIT*/
    override fun waitForRenderingAsync(): Task<Unit> { /*@DONE ControlledDispatch.WaitForRenderingAsync/2 cs:208-208*/
        return waitForRenderingAsync
    }
    override fun blockOnUIWork(action: () -> Unit) { /*@DONE ControlledDispatch.BlockOnUIWork/1 cs:210-210*/
        action()
    }
    override fun dispatchWork(action: (() -> Unit)?): Task<Unit> { /*@DONE ControlledDispatch.DispatchWork/1 cs:212-216*/
        val source = CancellationTokenSource()
        workloads.add(Dispatch(action, source))
        return Task.delay(-1, source.token)
    }
    override fun runBackgroundWork(action: () -> Unit): Task<Unit> { /*@DONE ControlledDispatch.RunBackgroundWork/1 cs:218-218*/
        return dispatchWork(action)
    }
    val workloadCount: Int
        get() { /*@DONE ControlledDispatch.WorkloadCount.get cs:220-220*/
            return workloads.size
        }
    fun runWorkloadAndContinuations(index: Int) { /*@DONE ControlledDispatch.RunWorkloadAndContinuations/1 cs:221-226*/
        val workload = workloads[index]
        workloads.removeAt(index)
        workload.action?.invoke()
        workload.cancellationSource.cancel() // ends the delay task, causing any children to run
    }
    fun runAllWorkloads() { /*@DONE ControlledDispatch.RunAllWorkloads/1 cs:228-230*/
        while (workloads.size > 0) runWorkloadAndContinuations(0)
    }
    val delayTimerRequested = Event<ImmediateWorkTimer>()
    override fun createDelayTimer(): IDelayWorkTimer { /*@DONE ControlledDispatch.CreateDelayTimer/1 cs:234-238*/
        val timer = ImmediateWorkTimer()
        delayTimerRequested(this, timer)
        return timer
    }
    /*@END ControlledDispatch*/
}

open class InlineDispatch : INotifyCompletion { // cs:244-251
    private lateinit var dispatcher: IWorkDispatcher
    constructor(dispatcher: IWorkDispatcher) { /*@DONE InlineDispatch.<init>/1 cs:246-246*/
        this.dispatcher = dispatcher
    }
    fun getAwaiter(): InlineDispatch { /*@DONE InlineDispatch.GetAwaiter/1 cs:247-247*/
        return this
    }
    val isCompleted: Boolean
        get() { /*@DONE InlineDispatch.IsCompleted.get cs:248-248*/
            return false
        }
    override fun onCompleted(continuation: () -> Unit) { /*@DONE InlineDispatch.OnCompleted/1 cs:249-249*/
        dispatcher.dispatchWork(continuation)
    }
    fun getResult() { /*@DONE InlineDispatch.GetResult/1 cs:250-250*/
        // nothing to return
    }
    /*@END InlineDispatch*/
}

open class VisualOption : ViewModelCore() { // cs:253-264
    private var _index: Int = 0
    private var _option: String = ""
    private var _shortDescription: String = ""
    private var _description: String = ""
    var index: Int
        get() { /*@DONE VisualOption.Index.get cs:257-257*/
            return _index
        }
        set(value) { /*@DONE VisualOption.Index.set cs:257-257*/
            tryUpdate(_index, value, "index") { _index = it }
        }
    var option: String
        get() { /*@DONE VisualOption.Option.get cs:258-258*/
            return _option
        }
        set(value) { /*@DONE VisualOption.Option.set cs:258-258*/
            tryUpdate(_option, value, "option") { _option = it }
        }
    var shortDescription: String
        get() { /*@DONE VisualOption.ShortDescription.get cs:259-259*/
            return _shortDescription
        }
        set(value) { /*@DONE VisualOption.ShortDescription.set cs:259-259*/
            tryUpdate(_shortDescription, value, "shortDescription") { _shortDescription = it }
        }
    var description: String
        get() { /*@DONE VisualOption.Description.get cs:260-260*/
            return _description
        }
        set(value) { /*@DONE VisualOption.Description.set cs:260-260*/
            tryUpdate(_description, value, "description") { _description = it }
        }
    val hasVisual: Boolean
        get() { /*@DONE VisualOption.HasVisual.get cs:262-262*/
            return visual != null
        }
    var visual: IPixelViewModel? = null
    /*@END VisualOption*/
}

data class IFileSystemCopyImageTuple(val image: ShortArray, val width: Int)

data class IFileSystemLoadImageTuple(val image: ShortArray?, val width: Int)
