// Port of Models/SearchByte.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

interface ISearchByte { // cs:6-8
    fun match(value: Int): Boolean
    /*@END ISearchByte*/
}

open class SearchByte : ISearchByte { // cs:9-15
    private var value: Int = 0
    constructor(value: Int) { /*@DONE SearchByte.<init>/1 cs:12-12*/
        this.value = value and 0xFF
    }
    // conversion from Int: use the companion function below
    fun fromByte(value: Int): SearchByte { /*@DONE SearchByte.op_Explicit/1 cs:13-13*/
        return SearchByte(value)
    }
    override fun match(value: Int): Boolean { /*@DONE SearchByte.Match/1 cs:14-14*/
        return value == this.value
    }
    companion object {
        var wild: ISearchByte = /*@INITDONE SearchByte.Wild cs:11-11*/ WildSearchByte() /*@ENDINIT*/
            private set
        /*@END SearchByte.Companion*/
    }
    /*@END SearchByte*/
}

open class WildSearchByte : ISearchByte { // cs:17-19
    override fun match(value: Int): Boolean { /*@DONE WildSearchByte.Match/1 cs:18-18*/
        return true
    }
    /*@END WildSearchByte*/
}

open class PCSSearchByte : ISearchByte { // cs:21-62
    private var match1: Int = 0
    private var match2: Int = 0
    constructor(value: Int) { /*@DONE PCSSearchByte.<init>/1 cs:37-46*/
        match1 = value and 0xFF
        match2 = match1
        if (PCSString.pcs[match1] == null) return
        val valueAsChar = PCSString.pcs[match1]!![0]
        if (valueAsChar.isUpperCase()) {
            Debug.assert(PCSString.pcs.indexOf("a") - PCSString.pcs.indexOf("A") == 0x1A)
            match2 += 0x1A
        }
    }
    override fun match(value: Int): Boolean { /*@DONE PCSSearchByte.Match/1 cs:48-48*/
        return value == match1 || value == match2
    }
    private open class MatchESearchByte : ISearchByte { // cs:51-55
        private constructor() { /*@DONE PCSSearchByte.MatchESearchByte.<init>/1 cs:53-53*/ }
        override fun match(value: Int): Boolean { /*@DONE PCSSearchByte.MatchESearchByte.Match/1 cs:54-54*/
            return value == capitalE || value == capitalEWithAccent || value == lowerE || value == lowerEWithAccent
        }
        companion object {
            var instance: ISearchByte = /*@INITDONE PCSSearchByte.MatchESearchByte.Instance cs:52-52*/ MatchESearchByte() /*@ENDINIT*/
                private set
            /*@END PCSSearchByte.MatchESearchByte.Companion*/
        }
        /*@END PCSSearchByte.MatchESearchByte*/
    }
    private open class ExactMatchSearchByte : ISearchByte { // cs:57-61
        private var value: Int = 0
        constructor(value: Int) { /*@DONE PCSSearchByte.ExactMatchSearchByte.<init>/1 cs:59-59*/
            this.value = value
        }
        override fun match(value: Int): Boolean { /*@DONE PCSSearchByte.ExactMatchSearchByte.Match/1 cs:60-60*/
            return value == this.value
        }
        /*@END PCSSearchByte.ExactMatchSearchByte*/
    }
    companion object {
        private val capitalEWithAccent: Int = /*@INITDONE PCSSearchByte.CapitalEWithAccent cs:22-22*/ PCSString.pcs.indexOf("\u00c9") /*@ENDINIT*/
        private val lowerEWithAccent: Int = /*@INITDONE PCSSearchByte.LowerEWithAccent cs:23-23*/ PCSString.pcs.indexOf("\u00e9") /*@ENDINIT*/
        private val capitalE: Int = /*@INITDONE PCSSearchByte.CapitalE cs:24-24*/ PCSString.pcs.indexOf("E") /*@ENDINIT*/
        private val lowerE: Int = /*@INITDONE PCSSearchByte.LowerE cs:25-25*/ PCSString.pcs.indexOf("e") /*@ENDINIT*/
        fun create(value: Int, matchExactCase: Boolean): ISearchByte { /*@DONE PCSSearchByte.Create/1 cs:27-35*/
            if (matchExactCase) {
                return ExactMatchSearchByte(value)
            } else if (value == capitalE || value == capitalEWithAccent || value == lowerE || value == lowerEWithAccent) {
                return MatchESearchByte.instance
            } else {
                return PCSSearchByte(value)
            }
        }
        private fun indexOf(pcs: List<String>, value: String): Int { /*@DONE PCSSearchByte.IndexOf/1 cs:49-49*/
            return (0 until 0x100).single { pcs[it] == value }
        }
        /*@END PCSSearchByte.Companion*/
    }
    /*@END PCSSearchByte*/
}
