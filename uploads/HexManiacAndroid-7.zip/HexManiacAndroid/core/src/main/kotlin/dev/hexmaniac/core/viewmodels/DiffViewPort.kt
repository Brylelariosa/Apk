// Port of ViewModels/DiffViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*

open class DiffViewPort : ViewModelCore, IViewPort { // cs:16-307
    private var left: MutableList<IChildViewPort> = ArrayList()
    private var right: MutableList<IChildViewPort> = ArrayList()
    private var leftWidth: Int = 0
    private var rightWidth: Int = 0
    private var startOfNextSegment: MutableList<Int> = ArrayList()
    private var cell: Array<Array<HexElement>> = emptyArray()
    val childCount: Int
        get() { /*@DONE DiffViewPort.ChildCount.get cs:24-24*/
            return left.size
        }
    constructor(leftChildren: Iterable<IChildViewPort>, rightChildren: Iterable<IChildViewPort>) { /*@DONE DiffViewPort.<init>/1 cs:26-53*/
        left = leftChildren.toMutableList()
        right = rightChildren.toMutableList()
        equalizeScroll(left, right)
        // Debug.Assert(left.size == right.size, "Diff views must have the same number of diff elements on each side!")

        // combine similar children
        var i = 0
        while (i < left.size - 1) {
            val leftResult = Ref<CompositeChildViewPort?>(null)
            val rightResult = Ref<CompositeChildViewPort?>(null)
            if (CompositeChildViewPort.tryCombine(left[i], left[i + 1], leftResult) && CompositeChildViewPort.tryCombine(right[i], right[i + 1], rightResult)) {
                left[i] = leftResult.value!!
                right[i] = rightResult.value!!
                left.removeAt(i + 1)
                right.removeAt(i + 1)
                i -= 1
            }
            i++
        }

        leftWidth = if (left.size == 0) 16 else Math.min(maxInnerTabWidth, left.maxOf { child -> child.width })
        rightWidth = if (right.size == 0) 16 else Math.min(maxInnerTabWidth, right.maxOf { child -> child.width })
        startOfNextSegment = ArrayList()
        startOfNextSegment.add(0)
        for (j in 0 until Math.min(left.size, right.size)) {
            startOfNextSegment.add(startOfNextSegment[j] + 1 + Math.max(left[j].height, right[j].height))
        }

        for (child in left) child.refreshHeaders()
        for (child in right) child.refreshHeaders()
    }
    fun leftHeight(index: Int): Int { /*@DONE DiffViewPort.LeftHeight/1 cs:55-55*/
        return left[index].height
    }
    fun rightHeight(index: Int): Int { /*@DONE DiffViewPort.RightHeight/1 cs:56-56*/
        return right[index].height
    }
    override operator fun get(x: Int, y: Int): HexElement { /*@DONE DiffViewPort.this/1.get cs:61-64*/
        if (x < 0 || y < 0 || x >= cell.size || cell.size == 0 || y >= cell[0].size) return HexElement(0, false, Undefined.instance)
        return cell[x][y]
    }
    override var toolPanelWidth: Double = /*@INITAUTO DiffViewPort.ToolPanelWidth cs:67-67*/ 500.0 /*@ENDINIT*/
    override val fileName: String
        get() { /*@DONE DiffViewPort.FileName.get cs:69-69*/
            return ""
        }
    override val fullFileName: String
        get() { /*@DONE DiffViewPort.FullFileName.get cs:71-71*/
            return name
        }
    override var spartanMode: Boolean = false
    override var width: Int
        get() { /*@DONE DiffViewPort.Width.get cs:75-75*/
            return leftWidth + rightWidth + 1
        }
        set(value) { /*@DONE DiffViewPort.Width.set cs:75-75*/
            // the width of a diff view is determined by its children
        }
    private var _height: Int = 0
    override var height: Int
        get() { /*@DONE DiffViewPort.Height.get cs:78-78*/
            return _height
        }
        set(value) { /*@DONE DiffViewPort.Height.set cs:78-78*/
            set(_height, value, "height", { _height = it }, { old -> refresh(old) })
        }
    override var autoAdjustDataWidth: Boolean = false
    override var stretchData: Boolean = false
    override var allowMultipleElementsPerLine: Boolean = false
    override var useCustomHeaders: Boolean = false
    override val minimumScroll: Int
        get() { /*@DONE DiffViewPort.MinimumScroll.get cs:85-85*/
            return 0
        }
    private var _scrollValue: Int = 0
    override var scrollValue: Int
        get() { /*@DONE DiffViewPort.ScrollValue.get cs:88-88*/
            return _scrollValue
        }
        set(value) { /*@DONE DiffViewPort.ScrollValue.set cs:88-88*/
            set(_scrollValue, value.limitToRange(minimumScroll, maximumScroll), "scrollValue", { _scrollValue = it }, { old -> refresh(old) })
        }
    override val maximumScroll: Int
        get() { /*@DONE DiffViewPort.MaximumScroll.get cs:90-90*/
            return startOfNextSegment[startOfNextSegment.size - 1] - 1
        }
    override val headers: ObservableCollection<RowHeader>? = /*@INITAUTO DiffViewPort.Headers cs:92-92*/ ObservableCollection() /*@ENDINIT*/
    override val columnHeaders: ObservableCollection<ColumnHeaderRow>
        get() { /*@DONE DiffViewPort.ColumnHeaders.get cs:94-94*/
            return emptyColumnHeaders
        }
    override val dataOffset: Int
        get() { /*@DONE DiffViewPort.DataOffset.get cs:96-96*/
            return 0
        }
    private lateinit var scrollCommand: StubCommand
    override val scroll: ICommand
        get() { /*@DONE DiffViewPort.Scroll.get cs:99-99*/
            if (!::scrollCommand.isInitialized) scrollCommand = stubCommandOf<Direction>({ direction -> if (direction != null) executeScroll(direction) })
            return scrollCommand
        }
    private fun executeScroll(direction: Direction) { /*@DONE DiffViewPort.ExecuteScroll/1 cs:100-105*/
        if (direction == Direction.Up) scrollValue -= 1
        if (direction == Direction.Down) scrollValue += 1 // the original says Direction.Up here, which cancels out the line above
        if (direction == Direction.PageUp) scrollValue -= _height
        if (direction == Direction.PageDown) scrollValue += _height
    }
    override val progress: Double
        get() { /*@DONE DiffViewPort.Progress.get cs:107-107*/
            return 0.0
        }
    override val updateInProgress: Boolean
        get() { /*@DONE DiffViewPort.UpdateInProgress.get cs:109-109*/
            return false
        }
    override var selectedAddress: String
        get() { /*@DONE DiffViewPort.SelectedAddress.get cs:111-111*/
            return ""
        }
        set(value) { /*@DONE DiffViewPort.SelectedAddress.set cs:111-111*/
            // the selection of a diff cannot be edited
        }
    override val selectedBytes: String?
        get() { /*@DONE DiffViewPort.SelectedBytes.get cs:113-113*/
            return ""
        }
    override var anchorText: String = ""
    override val anchorTextVisible: Boolean
        get() { /*@DONE DiffViewPort.AnchorTextVisible.get cs:117-117*/
            return false
        }
    override val model: IDataModel?
        get() { /*@DONE DiffViewPort.Model.get cs:119-119*/
            return null
        }
    override fun modelFor(p: Point): IDataModel? { /*@DONE DiffViewPort.ModelFor/1 cs:121-126*/
        val (childIndex, childLine) = convertLine(0)
        if (p.x == leftWidth) return null
        if (p.x < leftWidth) return left[childIndex].modelFor(Point(p.x, childLine))
        return right[childIndex].modelFor(Point(p.x - leftWidth - 1, childLine))
    }
    override val hasTools: Boolean
        get() { /*@DONE DiffViewPort.HasTools.get cs:128-128*/
            return false
        }
    override var base10Length: Boolean = false
    override lateinit var changeHistory: ChangeHistory<ModelDelta>
    override val tools: IToolTrayViewModel?
        get() { /*@DONE DiffViewPort.Tools.get cs:134-134*/
            return null
        }
    override var findBytes: ByteArray?
        get() { /*@DONE DiffViewPort.FindBytes.get cs:137-137*/
            return left[0].findBytes
        }
        set(value) { /*@DONE DiffViewPort.FindBytes.set cs:138-142*/
            for (child in left + right) child.findBytes = value
            notifyPropertyChanged("findBytes")
            refresh()
        }
    override val name: String
        get() { /*@DONE DiffViewPort.Name.get cs:145-145*/
            return left[0].parent!!.name.trim('*') + " -> " + right[0].parent!!.name.trim('*')
        }
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE DiffViewPort.IsMetadataOnlyChange.get cs:146-146*/
            return false
        }
    override val save: ICommand? = /*@INITAUTO DiffViewPort.Save cs:147-147*/ StubCommand() /*@ENDINIT*/
    override val saveAs: ICommand
        get() { /*@DONE DiffViewPort.SaveAs.get cs:148-148*/
            return disabledViewPortCommand
        }
    override val exportBackup: ICommand
        get() { /*@DONE DiffViewPort.ExportBackup.get cs:149-149*/
            return disabledViewPortCommand
        }
    override val undo: ICommand
        get() { /*@DONE DiffViewPort.Undo.get cs:150-150*/
            return disabledViewPortCommand
        }
    override val redo: ICommand
        get() { /*@DONE DiffViewPort.Redo.get cs:151-151*/
            return disabledViewPortCommand
        }
    override val copy: ICommand?
        get() { /*@DONE DiffViewPort.Copy.get cs:152-152*/
            return null
        }
    override val deepCopy: ICommand
        get() { /*@DONE DiffViewPort.DeepCopy.get cs:153-153*/
            return disabledViewPortCommand
        }
    override val clear: ICommand?
        get() { /*@DONE DiffViewPort.Clear.get cs:154-154*/
            return null
        }
    override val selectAll: ICommand
        get() { /*@DONE DiffViewPort.SelectAll.get cs:155-155*/
            return disabledViewPortCommand
        }
    override val goto: ICommand?
        get() { /*@DONE DiffViewPort.Goto.get cs:156-156*/
            return null
        }
    override val resetAlignment: ICommand
        get() { /*@DONE DiffViewPort.ResetAlignment.get cs:157-157*/
            return disabledViewPortCommand
        }
    override val back: ICommand
        get() { /*@DONE DiffViewPort.Back.get cs:158-158*/
            return disabledViewPortCommand
        }
    override val forward: ICommand
        get() { /*@DONE DiffViewPort.Forward.get cs:159-159*/
            return disabledViewPortCommand
        }
    private lateinit var _close: StubCommand
    override val close: ICommand
        get() { /*@DONE DiffViewPort.Close.get cs:161-161*/
            if (!::_close.isInitialized) _close = stubCommand({ closed(this, EventArgs.empty) })
            return _close
        }
    override val diff: ICommand
        get() { /*@DONE DiffViewPort.Diff.get cs:162-162*/
            return disabledViewPortCommand
        }
    override val diffLeft: ICommand
        get() { /*@DONE DiffViewPort.DiffLeft.get cs:163-163*/
            return disabledViewPortCommand
        }
    override val diffRight: ICommand
        get() { /*@DONE DiffViewPort.DiffRight.get cs:164-164*/
            return disabledViewPortCommand
        }
    override val canDuplicate: Boolean
        get() { /*@DONE DiffViewPort.CanDuplicate.get cs:165-165*/
            return false
        }
    override fun duplicate() { /*@DONE DiffViewPort.Duplicate/1 cs:166-166*/
        // diff views cannot be duplicated
    }
    override val previewScrollChanged = Event<EventArgs>()
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestCloseOtherViewports = Event<IDataModel>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE DiffViewPort.CanIpsPatchRight.get cs:185-185*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE DiffViewPort.CanUpsPatchRight.get cs:186-186*/
            return false
        }
    override fun ipsPatchRight() { /*@DONE DiffViewPort.IpsPatchRight/1 cs:187-187*/
        // not supported by diff views
    }
    override fun upsPatchRight() { /*@DONE DiffViewPort.UpsPatchRight/1 cs:188-188*/
        // not supported by diff views
    }
    override fun considerReload(fileSystem: IFileSystem) { /*@DONE DiffViewPort.ConsiderReload/1 cs:190-190*/
        // the original throws NotImplementedException here; a diff never reloads, so do nothing
    }
    override fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort { /*@DONE DiffViewPort.CreateChildView/1 cs:192-194*/
        throw NotImplementedError()
    }
    override fun expandSelection(x: Int, y: Int) { /*@DONE DiffViewPort.ExpandSelection/1 cs:196-210*/
        if (x < leftWidth) {
            requestTabChange(this, TabChangeRequestedEventArgs(left[0].parent!!))
            val (childIndex, childLine) = convertLine(y)
            val child = left[childIndex]
            val targetAddress = child.dataOffset + child.width * childLine
            left[0].parent!!.goto?.execute(targetAddress + x)
        } else if (x > leftWidth + 1) {
            requestTabChange(this, TabChangeRequestedEventArgs(right[0].parent!!))
            val (childIndex, childLine) = convertLine(y)
            val child = right[childIndex]
            val targetAddress = child.dataOffset + child.width * childLine
            right[0].parent!!.goto?.execute(targetAddress + x - leftWidth - 1)
        }
    }
    override fun find(search: String, matchExactCase: Boolean): List<IViewPortFindTuple> { /*@DONE DiffViewPort.Find/1 cs:212-212*/
        return ArrayList()
    }
    override val canFindFreeSpace: Boolean
        get() { /*@DONE DiffViewPort.CanFindFreeSpace.get cs:214-214*/
            return false
        }
    override fun findFreeSpace(fs: IFileSystem) { /*@DONE DiffViewPort.FindFreeSpace/1 cs:215-215*/
        // not supported by diff views
    }
    override fun findAllSources(x: Int, y: Int) { /*@DONE DiffViewPort.FindAllSources/1 cs:217-217*/
        // not supported by diff views
    }
    override fun followLink(x: Int, y: Int) { /*@DONE DiffViewPort.FollowLink/1 cs:219-219*/
        // not supported by diff views
    }
    override fun getContextMenuItems(point: Point, fileSystem: IFileSystem?): List<IContextItem> { /*@DONE DiffViewPort.GetContextMenuItems/1 cs:221-231*/
        val results = ArrayList<IContextItem>()
        results.add(ContextItem("Copy Address", { arg ->
            val fs = arg as IFileSystem
            val (childIndex, childLine) = convertLine(point.y)
            var address = left[childIndex].dataOffset + childLine * left[childIndex].width + point.x
            if (point.x > leftWidth) address = right[childIndex].dataOffset + childLine * right[childIndex].width + point.x - leftWidth - 1
            fs.copyText = address.toAddress()
        }))
        return results
    }
    override fun isSelected(point: Point): Boolean { /*@DONE DiffViewPort.IsSelected/1 cs:233-238*/
        val (childIndex, childLine) = convertLine(point.y)
        if (childIndex >= left.size) return false
        if (point.x < leftWidth) return left[childIndex].isSelected(Point(point.x, childLine))
        return right[childIndex].isSelected(Point(point.x - leftWidth - 1, childLine))
    }
    override fun isTable(point: Point): Boolean { /*@DONE DiffViewPort.IsTable/1 cs:240-240*/
        return false
    }
    private fun refresh(unused: Int) { /*@DONE DiffViewPort.Refresh/1 cs:242-242*/
        fillCells()
    }
    override fun refresh() { /*@DONE DiffViewPort.Refresh/2 cs:243-243*/
        fillCells()
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE DiffViewPort.TryImport/1 cs:245-245*/
        return false
    }
    private fun equalizeScroll(left: MutableList<IChildViewPort>, right: MutableList<IChildViewPort>) { /*@DONE DiffViewPort.EqualizeScroll/1 cs:249-261*/
        for (i in 0 until left.size) {
            val leftRun = left[i].model!!.getNextRun(left[i].dataOffset) ?: NoInfoRun.nullRun
            val rightRun = right[i].model!!.getNextRun(right[i].dataOffset) ?: NoInfoRun.nullRun
            val leftIsFormatted = leftRun.start <= left[i].dataOffset && (leftRun is ITableRun || leftRun is IStreamRun)
            val rightIsFormatted = rightRun.start <= right[i].dataOffset && (rightRun is ITableRun || rightRun is IStreamRun)
            if (!leftIsFormatted && rightIsFormatted) {
                equalizeScroll(right[i], left[i])
            } else {
                equalizeScroll(left[i], right[i])
            }
        }
    }
    private fun equalizeScroll(example: IChildViewPort, change: IChildViewPort) { /*@DONE DiffViewPort.EqualizeScroll/2 cs:263-270*/
        while (change.dataOffset > example.dataOffset) change.scroll.execute(Direction.Left)
        while (change.dataOffset < example.dataOffset) change.scroll.execute(Direction.Right)
        change.autoAdjustDataWidth = false
        change.preferredWidth = example.preferredWidth
        change.width = example.width
        change.height = example.height
    }
    private fun convertLine(parentLine: Int): Pair<Int, Int> { /*@DONE DiffViewPort.ConvertLine/1 cs:272-279*/
        val scrollLine = parentLine + _scrollValue
        if (scrollLine < 0) return Pair(0, scrollLine)
        var index = java.util.Collections.binarySearch(startOfNextSegment, scrollLine)
        if (index >= 0) return Pair(index, 0)
        index = index.inv() - 1
        return Pair(index, scrollLine - startOfNextSegment[index])
    }
    private fun fillCells() { /*@DONE DiffViewPort.FillCells/1 cs:281-306*/
        headers!!.clear()
        if (width < 0 || height < 0) return
        val defaultCell = HexElement(0, false, Undefined.instance)
        cell = Array(width) { Array(height) { defaultCell } }

        var childIndex = 0
        var childLine = 0
        val first = convertLine(0)
        childIndex = first.first
        childLine = first.second
        for (y in 0 until height) {
            val childIsValid = childIndex < left.size
            for (x in 0 until leftWidth) {
                cell[x][y] = if (childIsValid) left[childIndex][x, childLine] else defaultCell
            }
            cell[leftWidth][y] = defaultCell
            for (x in 0 until rightWidth) {
                cell[leftWidth + 1 + x][y] = if (childIsValid) right[childIndex][x, childLine] else defaultCell
            }

            val hasHeader = childIsValid && left[childIndex].headers!!.size > childLine
            headers!!.add(if (hasHeader) left[childIndex].headers!![childLine] else RowHeader.fromString(""))
            childLine += 1
            if (childIsValid && y + _scrollValue == startOfNextSegment[childIndex + 1] - 1) {
                childIndex += 1
                childLine = 0
            }
        }
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset))
    }
    companion object {
        const val maxInnerTabWidth: Int = 32
        /*@END DiffViewPort.Companion*/
    }
    /*@ADD DiffViewPort#viewports_a.txt*/
    private val emptyColumnHeaders = ObservableCollection<ColumnHeaderRow>()
    /*@ENDADD DiffViewPort#viewports_a.txt*/
    /*@END DiffViewPort*/
}
