// Port of Models/Runs/ArrayRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.visitors.*

interface IUpdateFromParentRun : IFormattedRun { // cs:14-17
    val repointContentShortName: String
    fun updateFromParent(token: ModelDelta, parentSegmentChange: Int, pointerSource: Int): IUpdateFromParentRun?
    /*@END IUpdateFromParentRun*/
}

interface ITableRun : IAppendToBuilderRun { // cs:19-27
    val elementCount: Int
    val elementLength: Int
    val elementNames: List<String>?
    val elementContent: List<ArrayRunElementSegment>
    val canAppend: Boolean
    fun append(token: ModelDelta, length: Int): ITableRun
    fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun
    /*@END ITableRun*/
}

fun IDataModel.getTable(name: String): ITableRun? { /*@DONE ITableRunExtensions.GetTable/1 cs:30-33*/
    val address = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, name)
    return this.getNextRun(address) as? ITableRun
}
fun IDataModel.getTableModel(name: String?, tokenFactory: (() -> ModelDelta)? = null): ModelTable? { /*@DONE ITableRunExtensions.GetTableModel/1 cs:35-39*/
    val table = this.getTable(name ?: return null) ?: return null
    return ModelTable(this, table, tokenFactory)
}
fun ITableRun.convertByteOffsetToArrayOffset(byteOffset: Int): ArrayOffset { /*@DONE ITableRunExtensions.ConvertByteOffsetToArrayOffset/1 cs:42-51*/
    val offset = byteOffset - this.start
    val elementIndex = offset / this.elementLength
    val elementOffset = offset % this.elementLength
    var segmentIndex = 0
    var segmentOffset = elementOffset
    while (this.elementContent[segmentIndex].length <= segmentOffset) {
        segmentOffset -= this.elementContent[segmentIndex].length
        segmentIndex++
    }
    return ArrayOffset(elementIndex, segmentIndex, byteOffset - segmentOffset, segmentOffset)
}
fun ArrayRunElementSegment.isUnused(): Boolean { /*@DONE ITableRunExtensions.IsUnused/1 cs:53-55*/
    return this is ArrayRunCommentSegment || this.name.startsWith("unused") || this.name.startsWith("padding")
}
fun ITableRun.createSegmentDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE ITableRunExtensions.CreateSegmentDataFormat/1 cs:57-103*/
    val offsets = this.convertByteOffsetToArrayOffset(index)
    val baseSegment = this.elementContent[offsets.segmentIndex]
    val position = index - offsets.segmentStart
    val currentSegment: ArrayRunElementSegment = if (baseSegment is ArrayRunRecordSegment) baseSegment.createConcrete(data, this, index) else baseSegment
    if (currentSegment.type == ElementContentType.Integer) {
        if (currentSegment is ArrayRunEnumSegment) {
            val value = currentSegment.toText(data, offsets.segmentStart, 0) ?: ""
            return IntegerEnum(offsets.segmentStart, position, value, currentSegment.length)
        } else if (currentSegment is ArrayRunTupleSegment) {
            return Tuple(data, currentSegment, offsets.segmentStart, position)
        } else if (currentSegment is ArrayRunHexSegment) {
            val value = data.readMultiByteValue(offsets.segmentStart, currentSegment.length)
            val hex = IntegerHex(offsets.segmentStart, position, value, currentSegment.length)
            hex.isUnused = currentSegment.isUnused()
            return hex
        } else if (currentSegment is ArrayRunColorSegment) {
            val color = data.readMultiByteValue(offsets.segmentStart, currentSegment.length).toShort()
            return UncompressedPaletteColor(offsets.segmentStart, position, color)
        } else if (currentSegment is ArrayRunSignedSegment) {
            val signedValue = currentSegment.readValue(data, offsets.segmentStart)
            return Integer(offsets.segmentStart, position, signedValue, currentSegment.length)
        } else {
            val value = if (offsets.segmentStart < data.count - currentSegment.length) ArrayRunElementSegment.toInteger(data, offsets.segmentStart, currentSegment.length) else 0
            val integer = Integer(offsets.segmentStart, position, value, currentSegment.length)
            integer.isUnused = currentSegment.isUnused()
            return integer
        }
    }

    if (currentSegment.type == ElementContentType.Pointer) {
        val destination = data.readPointer(offsets.segmentStart)
        val destinationName = data.getAnchorFromAddress(offsets.segmentStart, destination)
        val destinationRun = data.getNextRun(destination)
        val hasError = data.pointerHasError(destination, destinationRun, currentSegment)

        return Pointer(offsets.segmentStart, position, destination, 0, destinationName, hasError)
    }

    if (currentSegment.type == ElementContentType.BitArray) {
        val displayValue = currentSegment.length.range().map { i -> data[offsets.segmentStart + i].toHexString() }.joinToString(" ")
        return BitArray(offsets.segmentStart, position, currentSegment.length, displayValue)
    }

    if (currentSegment.type == ElementContentType.PCS) {
        // (the original indexes the character table with the data index itself; the byte at that index is what is meant)
        return PCS(offsets.segmentStart, offsets.segmentOffset, data.textConverter.convert(data, offsets.segmentStart, currentSegment.length) ?: "", PCSString.pcs[data[index]] ?: "")
    }

    throw NotImplementedException()
}
fun IDataModel.pointerHasError(destination: Int, destinationRun: IFormattedRun?, currentSegment: ArrayRunElementSegment? = null): Boolean { /*@DONE ITableRunExtensions.PointerHasError/1 cs:105-127*/
    var hasError = false
    if (destination >= 0 && destination < this.count) {
        if (destinationRun is ArrayRun && destinationRun.supportsInnerPointers) {
            // it's an error unless the arrayRun starts before the destination and the destination is the start of one of the elements
            hasError = !(destinationRun.start <= destination && (destination - destinationRun.start) % destinationRun.elementLength == 0)
        } else {
            val run = Ref<IFormattedRun?>(destinationRun)
            hasError = destinationRun!!.start != destination
            // if the run isn't a ITableRun, parse the data to see if it's valid
            // if it _is_ an ITableRun, skip this step
            if (currentSegment is ArrayRunPointerSegment && destinationRun !is ITableRun) {
                val strategy = this.formatRunFactory.getStrategy(currentSegment.innerFormat)
                if (strategy != null) {
                    hasError = hasError or strategy.tryParseData(this, "", destination, run)!!.hasError
                }
            }
        }
    } else {
        hasError = true
    }
    return hasError
}
fun ITableRun.dependsOn(anchorName: String): Boolean { /*@DONE ITableRunExtensions.DependsOn/1 cs:183-190*/
    for (segment in this.elementContent) {
        if (segment is ArrayRunEnumSegment && segment.enumName == anchorName) return true
        if (segment is ArrayRunTupleSegment && segment.dependsOn(anchorName)) return true
        if (segment is ArrayRunRecordSegment && segment.dependsOn(anchorName)) return true
    }
    return false
}
fun ITableRun.notifyChildren(model: IDataModel, token: ModelDelta, elementIndex: Int, segmentIndex: Int, previousValue: Int = 0xDedBeef): ErrorInfo { /*@DONE ITableRunExtensions.NotifyChildren/1 cs:214-266*/
    var offset = 0
    var info = ErrorInfo.noError
    for (segment in this.elementContent) {
        if (previousValue != 0xDedBeef && segment is ArrayRunRecordSegment && segment.matchField == this.elementContent[segmentIndex].name) {
            ITableRunExtensions.updateRecordType(this, model, token, elementIndex, segmentIndex, segment, previousValue)
        }
        if (segment is ArrayRunPointerSegment) {
            val pointerSource = this.start + elementIndex * this.elementLength + offset
            var destination = model.readPointer(pointerSource)
            var run = model.getNextRun(destination)!!
            if (destination == Pointer.null_) {
                // if the entry that was edited was my length, we want to make new data
                if (
                    segment.innerFormat.endsWith("/" + this.elementContent[segmentIndex].name)
                ||
                    (segment.innerFormat == TrainerPokemonTeamRun.sharedFormatString && this.elementContent[segmentIndex].name == "pokemonCount")
                ) {
                    val length = model.formatRunFactory.getStrategy(segment.innerFormat)!!.lengthForNewRun(model, pointerSource)
                    if (length > 0) {
                        var insert = model.findFreeSpace(0, length)
                        if (insert == -1) {
                            insert = model.count
                            model.expandData(token, model.count + length)
                        }
                        segment.writeNewFormat(model, token, pointerSource, insert, this.elementContent)
                        destination = insert
                        run = model.getNextRun(destination)!!
                    }
                }
            }

            val childRun = run as? IUpdateFromParentRun
            val oslRun = run as? OverworldSpriteListRun
            if (run.start == destination && childRun != null) {
                val newRun = childRun.updateFromParent(token, segmentIndex, pointerSource)
                if (newRun != null) {
                    model.observeRunWritten(token, newRun)
                    if (newRun.start != childRun.start) info = ErrorInfo("${childRun.repointContentShortName} was automatically moved to ${newRun.start.toHex(6)}. Pointers were updated.", isWarningLevel = true)
                } else {
                    info = ErrorInfo("${childRun.repointContentShortName} was automatically deleted. Data set to null.", isWarningLevel = true)
                }
            } else if (run.start == destination && oslRun != null) {
                // overworld sprite list cares about multiple things that could change/repoint, so we need a different method signature.
                val spritesMoved = Ref(false)
                val newRun = oslRun.updateFromParent(token, segmentIndex, pointerSource, spritesMoved)
                model.observeRunWritten(token, newRun)
                if (newRun.start != oslRun.start) info = ErrorInfo("Overworld sprite was automatically moved to ${newRun.start.toHex(6)}. Pointers were updated.", isWarningLevel = true)
                if (spritesMoved.value) info = ErrorInfo("Overworld sprites were automatically moved after resize. Pointers were updated.", isWarningLevel = true)
            }
        }
        offset += segment.length
    }

    return info
}
fun ITableRun.dataFormatMatches(other: ITableRun): Boolean { /*@DONE ITableRunExtensions.DataFormatMatches/1 cs:268-280*/
    if (this.elementContent.size != other.elementContent.size) return false
    for (i in 0 until this.elementContent.size) {
        if (this.elementContent[i].type != other.elementContent[i].type) return false
        if (this.elementContent[i].length != other.elementContent[i].length) return false
        val pSegment = this.elementContent[i]
        if (pSegment is ArrayRunPointerSegment) {
            val pSegment2 = other.elementContent[i]
            if (pSegment2 !is ArrayRunPointerSegment) return false
            if (pSegment.innerFormat != pSegment2.innerFormat) return false
        }
        if (other.elementContent[i] is ArrayRunPointerSegment && this.elementContent[i] !is ArrayRunPointerSegment) return false
    }
    return true
}
fun List<ArrayRunElementSegment>.dataFormatMatches(model: IDataModel, start: Int, elementIndex: Int, deepCheck: Boolean = true): Boolean { /*@DONE ITableRunExtensions.DataFormatMatches/2 cs:282-290*/
    var position = start
    var flags = 0
    if (this.size == 1) flags = ArrayRun.FormatMatchFlags.IsSingleSegment
    for (i in 0 until this.size) {
        if (!ArrayRun.dataMatchesSegmentFormat(model, position, this[i], flags, this, elementIndex, deepCheck)) return false
        position += this[i].length
    }
    return true
}
fun ITableRun.sort(model: IDataModel, fieldIndex: Int): ByteArray { /*@DONE ITableRunExtensions.Sort/1 cs:292-308*/
    val fieldOffset = this.elementContent.take(fieldIndex).sumOf { seg -> seg.length }
    val field = this.elementContent[fieldIndex]
    val indexed = this.elementCount.range().toMutableList()
    fun value(index: Int): Int = model.readMultiByteValue(this.start + this.elementLength * index + fieldOffset, field.length)
    indexed.sortWith(Comparator { i, j -> value(i).compareTo(value(j)) })

    val result = ByteArray(this.elementCount * this.elementLength)
    for (i in 0 until this.elementCount) {
        val sourceIndex = indexed[i]
        for (j in 0 until this.elementLength) {
            result[i * this.elementLength + j] = model[this.start + this.elementLength * sourceIndex + j].toByte()
        }
    }

    return result
}
fun ITableRun.readPointer(model: IDataModel, elementIndex: Int, fieldIndex: Int = 0): Int { /*@DONE ITableRunExtensions.ReadPointer/1 cs:310-313*/
    val fieldOffset = this.elementContent.take(fieldIndex).sumOf { seg -> seg.length }
    return model.readPointer(this.start + this.elementLength * elementIndex + fieldOffset)
}
fun ITableRun.readPointer(model: IDataModel, elementIndex: Int, fieldName: String): Int { /*@DONE ITableRunExtensions.ReadPointer/2 cs:315-319*/
    val field = this.elementContent.single { seg -> seg.name == fieldName }
    val fieldIndex = this.elementContent.indexOf(field)
    return this.readPointer(model, elementIndex, fieldIndex)
}
fun ITableRun.writePointer(destination: Int, model: IDataModel, token: ModelDelta, elementIndex: Int, fieldIndex: Int = 0) { /*@DONE ITableRunExtensions.WritePointer/1 cs:321-324*/
    val fieldOffset = this.elementContent.take(fieldIndex).sumOf { seg -> seg.length }
    model.writePointer(token, this.start + this.elementLength * elementIndex + fieldOffset, destination)
}
fun ITableRun.writePointer(destination: Int, model: IDataModel, token: ModelDelta, elementIndex: Int, fieldName: String) { /*@DONE ITableRunExtensions.WritePointer/2 cs:326-330*/
    val field = this.elementContent.single { seg -> seg.name == fieldName }
    val fieldIndex = this.elementContent.indexOf(field)
    this.writePointer(destination, model, token, elementIndex, fieldIndex)
}
fun ITableRun.readValue(model: IDataModel, elementIndex: Int, fieldIndex: Int = 0): Int { /*@DONE ITableRunExtensions.ReadValue/1 cs:332-338*/
    val fieldOffset = this.elementContent.take(fieldIndex).sumOf { seg -> seg.length }
    val calcSeg = this.elementContent[fieldIndex]
    if (calcSeg.length == 0 && calcSeg is ArrayRunCalculatedSegment) {
        return kotlin.math.round(calcSeg.calculatedValue(this.start + elementIndex * this.elementLength)).toInt()
    }
    return model.readMultiByteValue(this.start + this.elementLength * elementIndex + fieldOffset, this.elementContent[fieldIndex].length)
}
fun ITableRun.readCalculatedValue(elementIndex: Int, calculatedSegmentFieldIndex: Int): Double { /*@DONE ITableRunExtensions.ReadCalculatedValue/1 cs:340-343*/
    val calcSeg = this.elementContent[calculatedSegmentFieldIndex] as ArrayRunCalculatedSegment
    return calcSeg.calculatedValue(this.start + elementIndex * this.elementLength)
}
fun ITableRun.readValue(model: IDataModel, elementIndex: Int, fieldName: String): Int { /*@DONE ITableRunExtensions.ReadValue/2 cs:345-349*/
    val field = this.elementContent.single { seg -> seg.name == fieldName }
    val fieldIndex = this.elementContent.indexOf(field)
    return this.readValue(model, elementIndex, fieldIndex)
}
fun ITableRun.writeValue(value: Int, model: IDataModel, token: ModelDelta, elementIndex: Int, fieldIndex: Int = 0) { /*@DONE ITableRunExtensions.WriteValue/1 cs:351-360*/
    val fieldOffset = this.elementContent.take(fieldIndex).sumOf { seg -> seg.length }
    if (this.elementContent[fieldIndex].length == 0 && this.elementContent[fieldIndex] is ArrayRunCalculatedSegment) {
        throw NotImplementedException("Cannot write value to a calculated field!")
    }
    if (this.elementContent[fieldIndex].length == 0 && this.elementContent[fieldIndex] is ArrayRunOffsetRenderSegment) {
        throw NotImplementedException("Cannot write value to a render field!")
    }
    model.writeMultiByteValue(this.start + this.elementLength * elementIndex + fieldOffset, this.elementContent[fieldIndex].length, token, value)
}
fun ITableRun.writeValue(value: Int, model: IDataModel, token: ModelDelta, elementIndex: Int, fieldName: String) { /*@DONE ITableRunExtensions.WriteValue/2 cs:362-366*/
    val field = this.elementContent.single { seg -> seg.name == fieldName }
    val fieldIndex = this.elementContent.indexOf(field)
    this.writeValue(value, model, token, elementIndex, fieldIndex)
}
fun ITableRun.readText(model: IDataModel, elementIndex: Int, fieldIndex: Int = 0): String { /*@DONE ITableRunExtensions.ReadText/1 cs:368-373*/
    val segOffset = this.elementContent.take(fieldIndex).sumOf { seg -> seg.length }
    val textStart = this.start + this.elementLength * elementIndex + segOffset
    val rawBytes = model.rawData.asByteList()
    val length = PCSString.readString(rawBytes, textStart, true, this.elementContent[fieldIndex].length)
    return model.textConverter.convert(rawBytes, textStart, length) ?: ""
}
fun ITableRun.search(model: IDataModel, baseName: String, index: Int): Iterable<ITableRunExtensionsSearchTuple> { /*@DONE ITableRunExtensions.Search/1 cs:375-411*/
    val self = this
    return sequence<ITableRunExtensionsSearchTuple> {
        var segmentOffset = 0
        for (i in 0 until self.elementContent.size) {
            val recordSeg = self.elementContent[i]
            if (recordSeg is ArrayRunRecordSegment) {
                for (j in 0 until self.elementCount) {
                    val segmentStart = self.start + j * self.elementLength + segmentOffset
                    val enumSeg = recordSeg.createConcrete(model, segmentStart)
                    if (enumSeg !is ArrayRunEnumSegment || enumSeg.enumName != baseName) continue
                    if (model.count < segmentStart + recordSeg.length) continue
                    if (model.readMultiByteValue(segmentStart, recordSeg.length) != index) continue
                    yield(ITableRunExtensionsSearchTuple(segmentStart, segmentStart + recordSeg.length - 1))
                }
            }
            val segment = self.elementContent[i]
            if (segment is ArrayRunEnumSegment && segment.enumName == baseName) {
                for (j in 0 until self.elementCount) {
                    val segmentStart = self.start + j * self.elementLength + segmentOffset
                    if (model.count < segmentStart + segment.length) continue
                    if (model.readMultiByteValue(segmentStart, segment.length) != index + segment.valueOffset) continue
                    yield(ITableRunExtensionsSearchTuple(segmentStart, segmentStart + segment.length - 1))
                }
            }
            val tupSeg = self.elementContent[i]
            if (tupSeg is ArrayRunTupleSegment) {
                var bitOffset = 0
                for (tupleElementIndex in 0 until tupSeg.elements.size) {
                    if (tupSeg.elements[tupleElementIndex].sourceName == baseName) {
                        for (j in 0 until self.elementCount) {
                            val segmentStart = self.start + j * self.elementLength + segmentOffset
                            val enumValue = tupSeg.elements[tupleElementIndex].read(model, segmentStart, bitOffset)
                            if (enumValue != index) continue
                            yield(ITableRunExtensionsSearchTuple(segmentStart, segmentStart + tupSeg.length - 1))
                        }
                    }
                    bitOffset += tupSeg.elements[tupleElementIndex].bitWidth
                }
            }
            segmentOffset += self.elementContent[i].length
        }
    }.asIterable()
}

object ITableRunExtensions { // cs:29-412
    fun appendTo(self: ITableRun, data: IDataModel, text: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE ITableRunExtensions.AppendTo/1 cs:129-170*/
        var remaining = length
        val names = self.elementNames
        var offsets = self.convertByteOffsetToArrayOffset(start)
        remaining += offsets.segmentOffset
        val comments = HashMap<Int, String>()
        for (seg in self.elementContent) {
            if (seg !is ArrayRunCommentSegment) continue
            if (comments.containsKey(seg.index)) {
                comments[seg.index] = comments[seg.index]!! + NEW_LINE + seg.renderCommentLine()
            } else {
                comments[seg.index] = seg.renderCommentLine()
            }
        }
        var i = offsets.elementIndex
        while (i < self.elementCount && remaining > 0) {
            val comment = comments[i]
            if (comment != null) {
                if (i != 0) text.appendLine()
                text.appendLine(comment)
            }
            var offset = offsets.segmentStart
            val couldBeExtension = offsets.elementIndex > 0 || (self is TableStreamRun && self.allowsZeroElements)
            if (offsets.segmentIndex == 0 && couldBeExtension) text.append(ArrayRun.extendArray)
            var j = offsets.segmentIndex
            while (j < self.elementContent.size && remaining > 0) {
                val segment = self.elementContent[j]
                if (j == 0 && segment.type != ElementContentType.PCS && names != null && names.size > i && !names[i].isNullOrEmpty()) {
                    text.append("${ViewPort.commentStart}${names[i]}${ViewPort.commentStart}, ")
                }

                if (segment.length > 0) {
                    if (segment is ArrayRunRecordSegment) {
                        text.append(segment.toText(data, self, offset, depth)?.trim() ?: "")
                    } else {
                        text.append(segment.toText(data, offset, depth)?.trim() ?: "")
                    }
                    if (j + 1 < self.elementContent.size) text.append(", ")
                    offset += segment.length
                    remaining -= segment.length
                }
                j++
            }
            if (i + 1 < self.elementCount) text.append(NEW_LINE)
            offsets = ArrayOffset(i + 1, 0, offset, 0)
            i++
        }
    }
    fun clear(self: ITableRun, data: IDataModel, token: ModelDelta, start: Int, length: Int) { /*@DONE ITableRunExtensions.Clear/1 cs:172-181*/
        for (i in 0 until length) {
            val offset = self.convertByteOffsetToArrayOffset(start + i)
            if (self.elementContent[offset.segmentIndex].type == ElementContentType.PCS) {
                token.changeData(data, start + i, 0xFF)
            } else {
                token.changeData(data, start + i, 0x00)
            }
        }
    }
    fun updateRecordType(self: ITableRun, model: IDataModel, token: ModelDelta, elementIndex: Int, segmentIndex: Int, recordSegment: ArrayRunRecordSegment, previousValue: Int) { /*@DONE ITableRunExtensions.UpdateRecordType/1 cs:192-212*/
        val offset = self.elementContent.take(segmentIndex).sumOf { seg -> seg.length }
        val sourceSegment = self.elementContent[segmentIndex]
        val elementStart = self.start + self.elementLength * elementIndex
        val newValue = model.readMultiByteValue(elementStart + offset, sourceSegment.length)

        if (previousValue == newValue) return
        val previousConcrete = recordSegment.createConcrete(model.formatRunFactory, model.textConverter, previousValue)
        val newConcrete = recordSegment.createConcrete(model.formatRunFactory, model.textConverter, newValue)
        if ((previousConcrete.type == ElementContentType.Pointer) == (newConcrete.type == ElementContentType.Pointer)) return
        val pointerOffset = self.elementContent.until { seg -> seg === recordSegment }.sumOf { seg -> seg.length }
        val pointerDestination = model.readPointer(elementStart + pointerOffset)
        if (previousConcrete.type == ElementContentType.Pointer) {
            // not a pointer anymore, remove format from destination
            model.clearPointer(token, elementStart + pointerOffset, pointerDestination)
        }
        if (newConcrete.type == ElementContentType.Pointer) {
            // now a pointer, add format to destination
            model.updateArrayPointer(token, newConcrete, self.elementContent, elementIndex, elementStart + pointerOffset, pointerDestination)
        }
    }
    /*@END ITableRunExtensions*/
}

open class ArrayOffset { // cs:414-437
    var elementIndex: Int = 0
        private set
    var segmentIndex: Int = 0
        private set
    var segmentStart: Int = 0
        private set
    var segmentOffset: Int = 0
        private set
    constructor(elementIndex: Int, segmentIndex: Int, segmentStart: Int, segmentOffset: Int) { /*@DONE ArrayOffset.<init>/1 cs:431-436*/
        this.elementIndex = elementIndex
        this.segmentIndex = segmentIndex
        this.segmentStart = segmentStart
        this.segmentOffset = segmentOffset
    }
    /*@END ArrayOffset*/
}

open class ParentOffset { // cs:439-490
    var beginningMargin: Int = 0
        private set
    var endMargin: Int = 0
        private set
    constructor(start: Int = 0, end: Int = 0) { /*@DONE ParentOffset.<init>/1 cs:443-443*/
        this.beginningMargin = start
        this.endMargin = end
    }
    override fun toString(): String { /*@DONE ParentOffset.ToString/1 cs:469-484*/
        if (beginningMargin == 0) {
            if (endMargin == 0) return ""
            if (endMargin > 0) return "+" + endMargin
            if (endMargin < 0) return "+0" + endMargin
        }
        if (endMargin == 0) {
            if (beginningMargin > 0) return "+" + beginningMargin + "+0"
            return beginningMargin.toString()
        }
        var text = ""
        if (beginningMargin >= 0) text += "+"
        text += beginningMargin
        if (endMargin >= 0) text += "+"
        return text + endMargin
    }
    override fun equals(obj: Any?): Boolean { /*@DONE ParentOffset.Equals/1 cs:486-486*/
        return obj is ParentOffset && equals(obj)
    }
    fun equals(other: ParentOffset?): Boolean { /*@DONE ParentOffset.Equals/2 cs:487-489*/
        return other != null && other.beginningMargin == beginningMargin && other.endMargin == endMargin
    }
    companion object {
        val default: ParentOffset = /*@INITAUTO ParentOffset.Default cs:440-440*/ ParentOffset() /*@ENDINIT*/
        fun parse(nameToken: Ref<String>): ParentOffset { /*@DONE ParentOffset.Parse/1 cs:444-468*/
            val name = nameToken.value
            val separators = ArrayList<Int>()

            for (i in 0 until name.length) {
                if (name[i].isAny('+', '-')) separators.add(i)
            }
            separators.add(name.length)

            if (separators.size == 1) return default

            val margins = IntArray(separators.size - 1)
            for (i in 0 until margins.size) {
                val textMargin = name.substring(separators[i], separators[i + 1])
                val margin = Ref(0)
                margins[i] = if (tryParseInt(textMargin, margin)) margin.value else 0
            }

            if (margins.size > 2 || margins.size < 1) return default
            nameToken.value = name.substring(0, separators[0])
            if (margins.size == 1 && margins[0] > 0) return ParentOffset(0, margins[0])
            if (margins.size == 1 && margins[0] < 0) return ParentOffset(margins[0], 0)
            if (margins.size == 1) return default
            return ParentOffset(margins[0], margins[1])
        }
        /*@END ParentOffset.Companion*/
    }
    /*@ADD ParentOffset#runs_4.txt*/
    override fun hashCode(): Int = beginningMargin * 31 + endMargin
    /*@ENDADD ParentOffset#runs_4.txt*/
    /*@END ParentOffset*/
}

interface ISupportInnerPointersRun : IFormattedRun { // cs:492-496
    val supportsInnerPointers: Boolean
    fun removeInnerSource(source: Int): ISupportInnerPointersRun
    fun addSourcePointingWithinRun(source: Int): ISupportInnerPointersRun
    /*@END ISupportInnerPointersRun*/
}

open class ArrayRun : BaseRun, ITableRun, ISupportInnerPointersRun { // cs:498-1626
    private lateinit var owner: IDataModel
    final override var length: Int = 0
        private set
    final override var formatString: String = ""
        private set
    final override var elementCount: Int = 0
        private set
    final override var elementLength: Int = 0
        private set
    var lengthFromAnchor: String = ""
        private set
    lateinit var parentOffset: ParentOffset
        private set
    final override var supportsInnerPointers: Boolean = false
        private set
    var pointerSourcesForInnerElements: List<SortedSpan<Int>>? = null
        private set
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    override val elementNames: List<String>?
        get() { /*@DONE ArrayRun.ElementNames.get cs:556-576*/
            val cache = ModelCacheScope.getCache(owner)
            var options = cache.getOptions(lengthFromAnchor)
            if (options.size == 0) {
                val name = owner.getAnchorFromAddress(-1, start)
                options = cache.getOptions(name)
            }

            if (parentOffset.beginningMargin < 0) {
                options = options.drop(-parentOffset.beginningMargin)
            } else if (parentOffset.beginningMargin > 0) {
                options = parentOffset.beginningMargin.range().map { i -> (i - parentOffset.beginningMargin).toString() } + options
            }
            if (parentOffset.endMargin > 0) {
                options = options + (elementCount - parentOffset.endMargin until elementCount).map { i -> i.toString() }
            } else if (parentOffset.endMargin < 0) {
                options = options.take((options.size + parentOffset.endMargin).coerceAtLeast(0))
            }

            return options
        }
    override val canAppend: Boolean
        get() { /*@DONE ArrayRun.CanAppend.get cs:579-579*/
            return true
        }
    private constructor(data: IDataModel, formatText: String, start: Int, pointerSources: SortedSpan<Int>?) : super(start, pointerSources) { /*@DONE ArrayRun.<init>/1 cs:581-639*/
        owner = data
        formatString = formatText
        var format = formatText
        supportsInnerPointers = format.startsWith(BaseRun.anchorStart.toString())
        if (supportsInnerPointers) format = format.substring(1)
        val closeArray = format.lastIndexOf(arrayEnd.toString())
        if (!format.startsWith(arrayStart.toString()) || closeArray == -1) throw ArrayRunParseException("Array Content must be wrapped in $arrayStart$arrayEnd.")
        val segments = format.substring(1, closeArray)
        val lengthText = format.substring(closeArray + 1)
        if (!lengthText.all { c -> isValidTableNameCharacter(c) || c.isAny('-', '+') }) throw ArrayRunParseException("Array length must be an anchor name or a number.") // the name might end with "-1" so also allow +/-
        elementContent = parseSegments(segments, data)
        if (elementContent.size == 0) throw ArrayRunParseException("Array Content must not be empty.")
        elementLength = elementContent.sumOf { e -> e.length }
        if (elementLength == 0) throw ArrayRunParseException("Array Content Length must not be zero.")

        var flags = 0
        if (elementContent.size == 1) flags = flags or FormatMatchFlags.IsSingleSegment

        if (lengthText.length == 0) {
            var nextRun = owner.getNextAnchor(start + elementLength)
            while (true) {
                if (nextRun.start > owner.count) break
                val anchorName = owner.getAnchorFromAddress(-1, nextRun.start)
                if (!anchorName.isNullOrEmpty()) {
                    if ((nextRun.start - start) % elementLength != 0) break
                }
                nextRun = owner.getNextAnchor(nextRun.start + Math.max(1, nextRun.length))
            }
            val thisRun = owner.getNextAnchor(start) as? ArrayRun
            var maxLength = Int.MAX_VALUE
            if (thisRun != null && thisRun.start == start) maxLength = elementLength * thisRun.elementCount
            var byteLength = 0
            var foundCount = 0
            while (start + byteLength + elementLength <= nextRun.start && foundCount < 1500 && dataMatchesElementFormat(owner, start + byteLength, elementContent, foundCount, flags, nextRun)) {
                byteLength += elementLength
                foundCount++
                if (foundCount == junkLimit) flags = flags or FormatMatchFlags.AllowJunkAfterText
                if (byteLength >= maxLength) break
            }
            lengthFromAnchor = ""
            parentOffset = ParentOffset.default
            elementCount = Math.max(1, foundCount) // if the user said there's a format here, then there is, even if the format it wrong.
            formatString += elementCount
        } else {
            val result = Ref(0)
            if (lengthText.tryParseInt(result)) {
                // fixed length is easy
                lengthFromAnchor = ""
                parentOffset = ParentOffset.default
                elementCount = Math.max(1, result.value)
            } else {
                val parsed = parseLengthFromAnchor(lengthText)
                lengthFromAnchor = parsed.first
                parentOffset = parsed.second
                elementCount = parsed.third
                if (elementCount < 1) throw ArrayRunParseException("Tables must have a length of at least 1 element.")
            }
        }

        length = elementLength * elementCount
        if (supportsInnerPointers) {
            val innerPointers = elementCount.range().map { SortedSpan.none<Int>() }.toMutableList()
            innerPointers[0] = pointerSources ?: SortedSpan.none<Int>()
            pointerSourcesForInnerElements = innerPointers
        }
    }
    private constructor(data: IDataModel, format: String, lengthFromAnchor: String, parentOffset: ParentOffset, start: Int, elementCount: Int, segments: List<ArrayRunElementSegment>, pointerSources: SortedSpan<Int>?, pointerSourcesForInnerElements: List<SortedSpan<Int>>?) : super(start, pointerSources) { /*@DONE ArrayRun.<init>/2 cs:641-652*/
        owner = data
        formatString = format
        elementContent = segments
        elementLength = elementContent.sumOf { e -> e.length }
        this.elementCount = elementCount
        this.lengthFromAnchor = lengthFromAnchor
        this.parentOffset = parentOffset
        length = elementLength * elementCount
        supportsInnerPointers = pointerSourcesForInnerElements != null
        this.pointerSourcesForInnerElements = pointerSourcesForInnerElements
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE ArrayRun.Duplicate/1 cs:761-766*/
        var format = segments.map { segment -> segment.serializeFormat }.reduce { a, b -> a + " " + b }
        format = "[" + format + "]" + lengthFromAnchor
        if (lengthFromAnchor.isEmpty()) format += elementCount
        return ArrayRun(owner, format, lengthFromAnchor, parentOffset, start, elementCount, segments, pointerSources, pointerSourcesForInnerElements)
    }
    fun resizeMetadata(newCount: Int): ArrayRun { /*@DONE ArrayRun.ResizeMetadata/1 cs:768-772*/
        var format = elementContent.map { segment -> segment.serializeFormat }.reduce { a, b -> a + " " + b }
        format = "[" + format + "]" + newCount
        return ArrayRun(owner, format, lengthFromAnchor, parentOffset, start, newCount, elementContent, pointerSources, pointerSourcesForInnerElements)
    }
    private var cachedCurrentString: String = ""
    private var currentCachedStartIndex: Int = /*@INITAUTO ArrayRun.currentCachedStartIndex cs:888-888*/ -1 /*@ENDINIT*/
    private var currentCachedIndex: Int = /*@INITAUTO ArrayRun.currentCachedIndex cs:888-888*/ -1 /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE ArrayRun.CreateDataFormat/1 cs:889-903*/
        val offsets = this.convertByteOffsetToArrayOffset(index)
        val currentSegment = elementContent[offsets.segmentIndex]
        if (currentSegment.type == ElementContentType.PCS) {
            if (currentCachedStartIndex != offsets.segmentStart || currentCachedIndex > offsets.segmentOffset) {
                currentCachedStartIndex = offsets.segmentStart
                currentCachedIndex = offsets.segmentOffset
                cachedCurrentString = data.textConverter.convert(data, offsets.segmentStart, currentSegment.length) ?: ""
            }

            return PCSRun.createPCSFormat(data, offsets.segmentStart, index, cachedCurrentString)
        }

        return this.createSegmentDataFormat(data, index)
    }
    // skipped method Append: explicit implementation merged with the public member
    override fun append(token: ModelDelta, elementCount: Int): ArrayRun { /*@DONE ArrayRun.Append/2 cs:906-992*/
        var delta = elementCount
        if (delta == 0) return this
        val lastArrayCharacterIndex = formatString.lastIndexOf(arrayEnd)
        var newFormat = formatString.substring(0, lastArrayCharacterIndex + 1)
        val endElementCount = Math.max(parentOffset.endMargin, 0)
        var newParentOffset = if (parentOffset.endMargin < 0) ParentOffset(parentOffset.beginningMargin, 0) else parentOffset
        if (token is NoDataChangeDeltaModel) newParentOffset = parentOffset
        if (newFormat != formatString) {
            if (!lengthFromAnchor.isEmpty()) {
                newFormat += lengthFromAnchor
                newFormat += newParentOffset.toString()
            } else {
                newFormat += (this.elementCount + delta)
            }
        }
        if (token !is NoDataChangeDeltaModel) delta -= Math.min(parentOffset.endMargin, 0) // if EndMargin is negative, we need to add extra elements to make it 0
        if (this.elementCount + delta < 1) delta = 1 - this.elementCount

        // set default values based on the bytes from the previous element
        if (token !is NoDataChangeDeltaModel) {
            // pull any end elements off the back
            val endElements = ByteArray(endElementCount * elementLength)
            val endElementsPosition = start + length - endElements.size
            System.arraycopy(owner.rawData, endElementsPosition, endElements, 0, endElements.size)

            for (i in 0 until delta) {
                var j = 0
                for (segment in elementContent) {
                    val readPosition = endElementsPosition - elementLength + j
                    val writePosition = endElementsPosition + i * elementLength + j
                    writeSegment(token, segment, owner, readPosition, writePosition)
                    j += segment.length
                }
            }

            // push end elements back on the back
            val endElementsList = endElements.asByteList()
            for (i in 0 until endElementCount) {
                var j = 0
                for (segment in elementContent) {
                    val readPosition = elementLength * i + j
                    val writePosition = endElementsPosition + (delta + i) * elementLength + j
                    writeSegment(token, segment, endElementsList, readPosition, writePosition)
                    j += segment.length
                }
            }

            adjustTableIndexValues(token, delta)
        }

        var newInnerElementsSources: MutableList<SortedSpan<Int>>? = null
        val oldInnerElementsSources = pointerSourcesForInnerElements
        if (oldInnerElementsSources != null) {
            val innerList = ArrayList<SortedSpan<Int>>(oldInnerElementsSources)

            // add extra elements at the back. Since this is a new element being added, it's fair to think that nothing points to it.
            for (i in 0 until delta) {
                innerList.add(SortedSpan.none<Int>())
            }

            // remove extra elements at the back. Add NoInfoRuns for the pointers to point to.
            var firstClear = true
            for (i in 0 until -delta) {
                val sources = innerList[innerList.size - 1]
                innerList.removeAt(innerList.size - 1)

                if (sources.any()) {
                    val sourceStart = start + length - elementLength * (i + 1)
                    // Since we're trying to add a run over space that we currently occupy, clear the existing run before adding this new one
                    if (firstClear) {
                        // clear the whole length, starting at Start, to preserve the pointers
                        owner.clearFormat(token, start, length)
                        firstClear = false
                    } else {
                        // clear only a single byte where we are, to preserve pointers to that element
                        owner.clearFormat(token, sourceStart, 1)
                    }
                    owner.observeRunWritten(token, NoInfoRun(sourceStart, sources))
                }
            }
            newInnerElementsSources = innerList
        }

        delta += this.elementCount // delta is now the full count, not the delta
        val fullCount = Ref(delta)
        updateNamedConstant(token, fullCount, false)
        delta = fullCount.value
        updateList(token, delta)

        return ArrayRun(owner, newFormat, lengthFromAnchor, newParentOffset, start, delta, elementContent, pointerSources, newInnerElementsSources)
    }
    private fun adjustTableIndexValues(token: ModelDelta, newElementCount: Int) { /*@DONE ArrayRun.AdjustTableIndexValues/1 cs:999-1020*/
        for (i in 0 until elementContent.size) {
            if (elementContent[i].type != ElementContentType.Integer) continue
            if (elementContent[i] is ArrayRunRecordSegment || elementContent[i] is ArrayRunHexSegment || elementContent[i] is ArrayRunEnumSegment) continue
            if (elementContent[i].name.lowercase() != "id" && elementContent[i].name.lowercase() != "index") continue

            var currentCount = elementCount
            if (parentOffset.endMargin > 0) currentCount += newElementCount
            val values = currentCount.range().map { j -> this.readValue(owner, j, i) }.toIntArray()
            val maxIndex = values.indexOf(values.max())
            var maxRunStart = maxIndex
            while (maxRunStart > 0 && values[maxRunStart - 1] == values[maxRunStart] - 1) maxRunStart -= 1
            if (maxIndex != currentCount - 1 && maxRunStart != 0) {
                for (j in maxRunStart..maxIndex) this.writeValue(values[j] + newElementCount, owner, token, j, i)
                for (j in 0 until newElementCount) this.writeValue(values[maxRunStart] + j, owner, token, elementCount + j, i)
            } else {
                // put the new values at the end
                val endMargin = Math.max(0, parentOffset.endMargin)
                for (j in 0 until newElementCount) this.writeValue(values[maxIndex] + j + 1, owner, token, elementCount + j - endMargin, i)
            }
        }
    }
    private fun updateNamedConstant(token: ModelDelta, desiredValue: Ref<Int>, alsoUpdateArrays: Boolean) { /*@DONE ArrayRun.UpdateNamedConstant/1 cs:1022-1037*/
        if (token is NoDataChangeDeltaModel) return // nop during initial load
        val addresses = owner.getMatchedWords(lengthFromAnchor)!!
        if (addresses.size == 0) return
        val lengthSource = owner.getNextRun(addresses[0]) as WordRun
        var newLength = desiredValue.value
        if (lengthSource.length == 1 && newLength > 255) {
            newLength = 255
        } else if (newLength < 1) {
            newLength = 1
        }
        desiredValue.value = newLength
        newLength += lengthSource.valueOffset
        owner.writeMultiByteValue(lengthSource.start, lengthSource.length, token, newLength)
        CompleteCellEdit.updateAllWords(owner, lengthSource, token, newLength, alsoUpdateArrays)
    }
    private fun updateList(token: ModelDelta, desiredValue: Int) { /*@DONE ArrayRun.UpdateList/1 cs:1039-1044*/
        val originalListRef = Ref<ValidationList?>(null)
        if (!owner.tryGetList(lengthFromAnchor, originalListRef)) return
        val originalList = originalListRef.value!!
        val newList = originalList.toMutableList()
        while (newList.size < desiredValue) newList.add("unnamed" + newList.size)
        owner.setList(token, lengthFromAnchor, newList, originalList.comments, originalList.storedHash)
    }
    private fun writeSegment(token: ModelDelta, segment: ArrayRunElementSegment, readData: ByteList, readPosition: Int, writePosition: Int) { /*@DONE ArrayRun.WriteSegment/1 cs:1046-1057*/
        if (segment.type == ElementContentType.Pointer) {
            val destination = readData.readMultiByteValue(readPosition, 4) + Pointer.null_
            val offset = this.convertByteOffsetToArrayOffset(writePosition)
            owner.updateArrayPointer(token, segment, elementContent, offset.elementIndex, writePosition, destination)
        } else {
            for (k in 0 until segment.length) {
                val validData = readData[readPosition + k]
                token.changeData(owner, writePosition + k, validData)
            }
        }
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE ArrayRun.AppendTo/1 cs:1059-1059*/
        ITableRunExtensions.appendTo(this, model, builder, start, length, depth)
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE ArrayRun.Clear/1 cs:1061-1063*/
        ITableRunExtensions.clear(this, model, changeToken, start, length)
    }
    fun growBitArraySegment(bitSegmentIndex: Int, additionalBytes: Int): ArrayRun { /*@DONE ArrayRun.GrowBitArraySegment/1 cs:1065-1072*/
        // all the data has been moved already
        // just return a new ArrayRun with the desired change.
        val content = elementContent.toMutableList()
        val oldSegment = content[bitSegmentIndex] as ArrayRunBitArraySegment
        content[bitSegmentIndex] = ArrayRunBitArraySegment(oldSegment.name, oldSegment.length + additionalBytes, oldSegment.sourceArrayName)
        return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, start, elementCount, content, pointerSources, pointerSourcesForInnerElements)
    }
    // skipped method AddSourcePointingWithinRun: explicit implementation merged with the public member
    override fun addSourcePointingWithinRun(source: Int): ArrayRun { /*@DONE ArrayRun.AddSourcePointingWithinRun/2 cs:1075-1085*/
        val destination = owner.readPointer(source)
        val index = (destination - start) / elementLength
        if (index < 0 || index >= elementCount) throw IndexOutOfRangeException()
        val newInnerPointerSources = pointerSourcesForInnerElements!!.toMutableList()
        newInnerPointerSources[index] = newInnerPointerSources[index].add1(source)
        if (index == 0) {
            return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, start, elementCount, elementContent, (pointerSources ?: SortedSpan.none<Int>()).add1(source), newInnerPointerSources)
        }
        return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, start, elementCount, elementContent, pointerSources, newInnerPointerSources)
    }
    fun addSourcesPointingWithinArray(changeToken: ModelDelta): ArrayRun { /*@DONE ArrayRun.AddSourcesPointingWithinArray/1 cs:1087-1125*/
        if (elementCount < 2) return this

        val destinations = IntArray(elementCount - 1)
        for (i in 1 until elementCount) destinations[i - 1] = start + elementLength * i

        val sources = owner.searchForPointersToAnchor(changeToken, false, *destinations)

        val results = ArrayList<SortedSpan<Int>>()
        results.add(pointerSources ?: SortedSpan.none<Int>())
        for (i in 1 until elementCount) results.add(SortedSpan.none<Int>())

        for (source in sources) {
            // if the source is within the table and isn't aligned as a pointer format,
            // then it's not a real pointer and we should ignore it
            if (start <= source && source < start + length) {
                var skip = false
                val offset = this.convertByteOffsetToArrayOffset(source)
                if (offset.segmentOffset != 0) skip = true
                else if (elementContent[offset.segmentIndex].type != ElementContentType.Pointer) skip = true

                // this is within the current table, clear the pointer format regardless of if we're skipping this pointer
                owner.clearFormat(changeToken, source, 1)
                if (skip) continue
            }

            val destination = owner.readPointer(source)
            val destinationIndex = (destination - start) / elementLength
            // destinationIndex is expected to be within the table
            // but if the rom was modified by another program while open in HMA, it might not be.
            if (destinationIndex >= 0 && destinationIndex < results.size) {
                results[destinationIndex] = results[destinationIndex].add1(source)
            }
        }

        val innerSources = ArrayList<SortedSpan<Int>>(results)
        return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, start, elementCount, elementContent, pointerSources, innerSources)
    }
    fun getColumnHeaders(columnCount: Int, startingDataIndex: Int): List<ColumnHeaderRow>? { /*@DONE ArrayRun.GetColumnHeaders/1 cs:1131-1142*/
        // check if it's a multiple of the array width
        if (columnCount >= elementLength) {
            if (columnCount % elementLength != 0) return null
            return listOf(ColumnHeaderRow(this, startingDataIndex - start, columnCount))
        }

        // check if it's a divisor of the array width
        if (elementLength % columnCount != 0) return null
        val segments = elementLength / columnCount
        return segments.range().map { i -> ColumnHeaderRow(this, columnCount * i + startingDataIndex - start, columnCount) }
    }
    fun move(newStart: Int): ArrayRun { /*@DONE ArrayRun.Move/1 cs:1144-1146*/
        return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, newStart, elementCount, elementContent, pointerSources, pointerSourcesForInnerElements)
    }
    override fun removeSource(source: Int): IFormattedRun { /*@DONE ArrayRun.RemoveSource/1 cs:1148-1148*/
        return removeInnerSource(source)
    }
    // skipped method RemoveInnerSource: explicit implementation merged with the public member
    override fun removeInnerSource(source: Int): ArrayRun { /*@DONE ArrayRun.RemoveInnerSource/2 cs:1150-1159*/
        if (!supportsInnerPointers) return super.removeSource(source) as ArrayRun
        val newPointerSources = (pointerSources ?: SortedSpan.none<Int>()).remove1(source)
        val newInnerPointerSources = ArrayList<SortedSpan<Int>>()
        for (list in pointerSourcesForInnerElements!!) {
            newInnerPointerSources.add(list.remove1(source))
        }

        return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, start, elementCount, elementContent, newPointerSources, newInnerPointerSources)
    }
    fun hasSameSegments(other: ArrayRun?): Boolean { /*@DONE ArrayRun.HasSameSegments/1 cs:1161-1178*/
        if (other == null) return false
        if (other.elementContent.size != elementContent.size) return false
        for (i in 0 until elementContent.size) {
            val mine = elementContent[i]
            val theirs = other.elementContent[i]
            if (mine.type != theirs.type || mine.length != theirs.length) return false
            if (mine is ArrayRunEnumSegment) {
                if (theirs !is ArrayRunEnumSegment) return false
                if (mine.enumName != theirs.enumName) return false
            }
            if (mine is ArrayRunPointerSegment) {
                if (theirs !is ArrayRunPointerSegment) return false
                if (mine.innerFormat != theirs.innerFormat) return false
            }
        }
        return true
    }
    fun findAllByteReads(parser: ThumbParser, fieldIndex: Int): Iterable<Int> { /*@DONE ArrayRun.FindAllByteReads/1 cs:1187-1214*/
        Debug.assert(elementContent.size > fieldIndex, "Table does not have $fieldIndex fields.")
        val results = java.util.TreeSet<Int>()
        if (fieldIndex >= elementContent.size) return results
        Debug.assert(elementContent[fieldIndex].length == 1, "${elementContent[fieldIndex].name} is not a byte field.")
        val offset = elementContent.take(fieldIndex).sumOf { seg -> seg.length }
        val sourceList = pointerSources ?: return results
        for (source in sourceList) {
            // ldr rX [pc, XXXXXX]=<address>
            for (load in findAllLoads(owner, parser, source)) {
                // add rY, rX <- rY points to a specific element in the table
                for (add in findAllCommands(owner, parser, load.address + 2, load.register, { line, reg -> line.startsWith("add ") && line.contains(", " + (reg ?: "")) })) {
                    val offsetText = " #" + offset + "]"
                    // ldrb rZ, [rY, #offset] <- rZ now holds the specific byte
                    for (ldrb in findAllCommands(owner, parser, add.address + 2, add.register, { line, reg -> line.startsWith("ldrb ") && line.contains("[" + (reg ?: "") + ", ") && line.contains(offsetText) })) {
                        results.add(ldrb.address)
                    }
                    // mov rA, #offset
                    for (mov in findAllCommands(owner, parser, add.address + 2, "!" + add.register, { line, reg -> line.startsWith("mov ") && line.endsWith(", #" + offset) }, recurse = false)) {
                        // ldrsb rZ, [rY, rA]
                        if (findAllCommands(owner, parser, mov.address + 2, add.register, { line, reg -> line.startsWith("ldrsb ") && line.contains("[" + (reg ?: "") + ", ") && line.contains(", " + mov.register + "]") }).any()) {
                            results.add(mov.address)
                        }
                    }
                }
            }
        }
        return results
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE ArrayRun.Clone/1 cs:1299-1308*/
        // since the inner pointer sources includes the first row, update the first row
        var newInnerPointerSources: MutableList<SortedSpan<Int>>? = null
        val oldInnerPointerSources = pointerSourcesForInnerElements
        if (oldInnerPointerSources != null) {
            val innerList = ArrayList<SortedSpan<Int>>()
            innerList.add(newPointerSources ?: SortedSpan.none<Int>())
            for (i in 1 until oldInnerPointerSources.size) innerList.add(oldInnerPointerSources[i])
            newInnerPointerSources = innerList
        }

        return ArrayRun(owner, formatString, lengthFromAnchor, parentOffset, start, elementCount, elementContent, newPointerSources, newInnerPointerSources)
    }
    private fun parseLengthFromAnchor(length: String): Triple<String, ParentOffset, Int> { /*@DONE ArrayRun.ParseLengthFromAnchor/1 cs:1492-1522*/
        val lengthToken = Ref(length)
        val offsetFromName = ParentOffset.parse(lengthToken)
        val anchorName = lengthToken.value

        // length is based on another array
        val address = owner.getAddressFromAnchor(ModelDelta(), -1, anchorName)
        if (address == Pointer.null_) {
            // the requested name was unknown... is it a list name?
            val nameArray = Ref<ValidationList?>(null)
            if (owner.tryGetList(anchorName, nameArray)) {
                return Triple(anchorName, offsetFromName, nameArray.value!!.size)
            } else {
                //  How about a constant name?
                val constantLocations = owner.getMatchedWords(anchorName)!!
                val constant = if (constantLocations.size > 0) owner.getNextRun(constantLocations[0]) else null
                if (constant is WordRun) {
                    val constantCount = owner.readMultiByteValue(constant.start, constant.length) / constant.multOffset - constant.valueOffset
                    return Triple(anchorName, offsetFromName, constantCount)
                } else {
                    // length is zero for now
                    return Triple(anchorName, offsetFromName, 1)
                }
            }
        }

        val run = owner.getNextRun(address)
        if (run !is ArrayRun || run.start != address) {
            // the requested name was not an array, or did not start where anticipated
            // length is zero for now
            return Triple(anchorName, offsetFromName, 1)
        }

        return Triple(anchorName, offsetFromName, run.elementCount + offsetFromName.beginningMargin + offsetFromName.endMargin)
    }
    object FormatMatchFlags { // cs:1622-1625
        const val IsSingleSegment = 0x01
        const val AllowJunkAfterText = 0x02
        /*@END ArrayRun.FormatMatchFlags*/
    }
    companion object {
        const val extendArray: Char = '+'
        const val arrayStart: Char = '['
        const val arrayEnd: Char = ']'
        const val singleByteIntegerFormat: Char = '.'
        const val doubleByteIntegerFormat: Char = ':'
        const val arrayAnchorSeparator: Char = '/'
        const val signedFormatString: String = "|z"
        const val hexFormatString: String = "|h"
        const val recordFormatString: String = "|s="
        const val tupleFormatString: String = "|t"
        const val colorFormatString: String = "|c"
        const val calculatedFormatString: String = "|="
        const val pythonButtonFormatString: String = "|python="
        const val renderFormatString: String = "|render="
        const val commentFormatString: String = "|comment="
        const val splitterFormatString: String = "|"
        private const val junkLimit: Int = 80
        fun tryParse(data: IDataModel, format: String, start: Int, pointerSources: SortedSpan<Int>?, self: Ref<ITableRun?>): ErrorInfo { /*@DONE ArrayRun.TryParse/1 cs:654-654*/
            return tryParse(data, "UNUSED", format, start, pointerSources, self)
        }
        fun tryParse(data: IDataModel, name: String, format: String, start: Int, pointerSources: SortedSpan<Int>?, self: Ref<ITableRun?>): ErrorInfo { /*@DONE ArrayRun.TryParse/2 cs:656-658*/
            return tryParse(data, name, format, start, pointerSources, null, self)
        }
        fun tryParse(data: IDataModel, name: String, format: String, start: Int, pointerSources: SortedSpan<Int>?, sourceSegments: List<ArrayRunElementSegment>?, self: Ref<ITableRun?>): ErrorInfo { /*@DONE ArrayRun.TryParse/3 cs:660-662*/
            return tryParse(data, name, format, start, pointerSources, sourceSegments, true, self)
        }
        fun tryParse(data: IDataModel, name: String, format: String, start: Int, pointerSources: SortedSpan<Int>?, sourceSegments: List<ArrayRunElementSegment>?, validate: Boolean, self: Ref<ITableRun?>): ErrorInfo { /*@DONE ArrayRun.TryParse/4 cs:664-714*/
            var name = name
            var sourceSegments = sourceSegments
            self.value = null
            val startArray = format.indexOf(arrayStart)
            val closeArray = format.lastIndexOf(arrayEnd)
            if (startArray == -1 || startArray > closeArray) return ErrorInfo("Array Content must be wrapped in " + arrayStart + arrayEnd + ".")
            val length = format.substring(closeArray + 1)

            if (sourceSegments == null) {
                for (source in data.getUnmappedSourcesToAnchor(name)) {
                    val tRun = data.getNextRun(source) as? ITableRun
                    if (tRun == null) continue
                    sourceSegments = tRun.elementContent
                    break
                }
            }
            if (sourceSegments == null && pointerSources != null && pointerSources.size == 1) {
                val parentTable = data.getNextRun(pointerSources[0]) as? ITableRun
                if (parentTable != null) {
                    sourceSegments = parentTable.elementContent
                    if (name == "") name = parentTable.elementContent[parentTable.convertByteOffsetToArrayOffset(pointerSources[0]).segmentIndex].name
                }
            }

            val tilemapTuple = parseTilemapTable(data, format, length)
            if (tilemapTuple != null) {
                // option 0: the length looks like a tilemap, and there's a single segment. Parse as a tilemap table.
                self.value = TilemapTableRun(data, tilemapTuple.item3, tilemapTuple.item1, tilemapTuple.item2, start, pointerSources)
            } else if (length.all { c -> isValidTableNameCharacter(c) || c.isAny('-', '+') }) {
                // option 1: the length looks like a standard table length (or is empty, and thus dynamic). Parse as a table.
                try {
                    ModelCacheScope.createScope(data).using {
                        val array = ArrayRun(data, format, start, pointerSources)
                        self.value = array
                        if (array.elementContent.size == 1 && array.elementContent[0].type == ElementContentType.Pointer) {
                            for (i in 0 until array.elementCount) {
                                if (!checkPointerFormat(data, array.start + array.elementLength * i)) {
                                    return ErrorInfo(name + "[" + i + "] doesn't match the expected format.")
                                }
                            }
                        }
                    }
                } catch (e: ArrayRunParseException) {
                    return ErrorInfo(e.message)
                }
            } else {
                val tableStreamRun = Ref<TableStreamRun?>(null)
                if (TableStreamRun.tryParseTableStream(data, start, pointerSources, name, format, sourceSegments, validate, tableStreamRun)) {
                    // option 2: parse as a table stream, because the length contains characters like / or ! that make it look dependent on
                    self.value = tableStreamRun.value
                } else {
                    // option 3: table parsing failed. Something weird in the length.
                    return ErrorInfo("Table format could not be parsed: " + format)
                }
            }

            return ErrorInfo.noError
        }
        fun trySearch(data: IDataModel, changeToken: ModelDelta, originalFormat: String, self: Ref<ArrayRun?>, runFilter: ((IFormattedRun) -> Boolean)? = null): Boolean { /*@DONE ArrayRun.TrySearch/1 cs:716-744*/
            self.value = null
            var format = originalFormat
            val allowPointersToEntries = format.startsWith(BaseRun.anchorStart.toString())
            if (allowPointersToEntries) format = format.substring(1)
            val closeArray = format.lastIndexOf(arrayEnd.toString())
            if (!format.startsWith(arrayStart.toString()) || closeArray == -1) throw ArrayRunParseException("Array Content must be wrapped in " + arrayStart + arrayEnd)
            val segments = format.substring(1, closeArray)
            val length = format.substring(closeArray + 1)
            val elementContent = parseSegments(segments, data)
            if (elementContent.size == 0) return false
            val elementLength = elementContent.sumOf { e -> e.length }

            ModelCacheScope.createScope(data).using {
                if (length.isEmpty()) {
                    val bestLength = Ref(0)
                    val bestAddress = standardSearch(data, elementContent, elementLength, bestLength, runFilter)
                    if (bestAddress == Pointer.null_) return false
                    self.value = ArrayRun(data, originalFormat + bestLength.value, "", ParentOffset.default, bestAddress, bestLength.value, elementContent, data.getNextRun(bestAddress)!!.pointerSources, null)
                } else {
                    val bestLength = Ref(0)
                    val bestAddress = knownLengthSearch(data, elementContent, elementLength, length, bestLength, runFilter)
                    if (bestAddress == Pointer.null_) return false
                    val lengthFromAnchor = if (tryParseInt(length, Ref(0))) "" else length
                    self.value = ArrayRun(data, originalFormat, lengthFromAnchor, ParentOffset.default, bestAddress, bestLength.value, elementContent, data.getNextRun(bestAddress)!!.pointerSources, null)
                }
            }

            if (allowPointersToEntries) self.value = self.value!!.addSourcesPointingWithinArray(changeToken)
            return true
        }
        fun parseTilemapTable(model: IDataModel, format: String, length: String): ArrayRunParseTilemapTableTuple? { /*@DONE ArrayRun.ParseTilemapTable/1 cs:746-759*/
            val lengthToken = Ref(length)
            val margins = TilemapMargins.extractMargins(lengthToken)
            val anchorName = lengthToken.value

            val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchorName)
            val tilemap = model.getNextRun(address) as? ITilemapRun
            if (tilemap == null || tilemap.start != address) return null

            val closeArray = format.lastIndexOf(arrayEnd.toString())
            if (!format.startsWith(arrayStart.toString()) || closeArray == -1) return null
            val segments = format.substring(1, closeArray)
            val content = parseSegments(segments, model)
            if (content.size != 1) return null
            return ArrayRunParseTilemapTableTuple(content[0], margins, anchorName)
        }
        private fun standardSearch(data: IDataModel, elementContent: MutableList<ArrayRunElementSegment>, elementLength: Int, bestLength: Ref<Int>, runFilter: ((IFormattedRun) -> Boolean)?): Int { /*@DONE ArrayRun.StandardSearch/1 cs:774-826*/
            var bestAddress = Pointer.null_
            bestLength.value = 0

            var run = data.getNextAnchor(0)
            var nextRun = data.getNextAnchor(run.start + run.length)
            while (run.start < Int.MAX_VALUE) {
                var nextArray = nextRun
                var skip = false
                if (run is ArrayRun || run.pointerSources == null) {
                    skip = true
                } else if (runFilter != null && !runFilter(run)) {
                    // some searches allow special conditions on the run. For example, we could only be intersted in runs with >100 pointers leading to it.
                    skip = true
                }

                if (!skip) {
                    var flags = 0
                    if (elementContent.size == 1) flags = flags or FormatMatchFlags.IsSingleSegment

                    var currentLength = 0
                    var currentAddress = run.start
                    while (true) {
                        if (currentLength > junkLimit) flags = flags or FormatMatchFlags.AllowJunkAfterText // we've gone long enough without junk data to be fairly sure that we're looking at something real
                        if (nextArray.start < currentAddress) nextArray = data.getNextAnchor(nextArray.start + 1)
                        if (dataMatchesElementFormat(data, currentAddress, elementContent, currentLength, flags, nextArray)) {
                            currentLength++
                            currentAddress += elementLength
                        } else {
                            break
                        }
                    }

                    // if what we found is just a text array, then remove any trailing elements starting with a space.
                    if (elementContent.size == 1 && elementContent[0].type == ElementContentType.PCS) {
                        while (data[currentAddress - elementLength] == 0x00) {
                            currentLength--
                            currentAddress -= elementLength
                        }
                    }

                    // we think we found some data! Make sure it's not just a bunch of 00's and FF's
                    var dataEmpty = true
                    var i = 0
                    while (i < currentLength && currentLength > bestLength.value && dataEmpty) {
                        dataEmpty = data[run.start + i] == 0xFF || data[run.start + i] == 0x00
                        i++
                    }

                    if (bestLength.value < currentLength && !dataEmpty) {
                        bestLength.value = currentLength
                        bestAddress = run.start
                    }
                }

                run = nextRun
                nextRun = data.getNextAnchor(nextRun.start + nextRun.length)
            }

            return bestAddress
        }
        private fun knownLengthSearch(data: IDataModel, elementContent: MutableList<ArrayRunElementSegment>, elementLength: Int, lengthToken: String, bestLength: Ref<Int>, runFilter: ((IFormattedRun) -> Boolean)?): Int { /*@DONE ArrayRun.KnownLengthSearch/1 cs:828-885*/
            val noChange = NoDataChangeDeltaModel()
            bestLength.value = 0
            if (!tryParseInt(lengthToken, bestLength)) {
                val matchedArrayName = lengthToken
                val matchedArrayAddress = data.getAddressFromAnchor(noChange, -1, matchedArrayName)
                if (matchedArrayAddress == Pointer.null_) return Pointer.null_
                val matchedRun = data.getNextRun(matchedArrayAddress) as? ArrayRun
                if (matchedRun == null) return Pointer.null_
                bestLength.value = matchedRun.elementCount
            }

            var flags = 0
            if (elementContent.size == 1) flags = flags or FormatMatchFlags.IsSingleSegment

            var run: IFormattedRun = data.getNextRun(0)!!
            while (run.start < data.count) {
                val current = run
                run = data.getNextRun(current.start + current.length + 1)!!
                if (current !is PointerRun) continue
                val targetRun = data.getNextRun(data.readPointer(current.start))!!
                if (targetRun is ArrayRun) continue

                // some searches allow special conditions on the run. For example, we could only be intersted in runs with >100 pointers leading to it.
                if (runFilter != null && !runFilter(targetRun)) continue

                // tolerate a few errors in the data. We know what length we're looking for, so if most of the elements match, then
                // most likely we're just looking at the right collection but with some user-created bugs.
                val errorsToTolerate = bestLength.value / 80
                var encounterErrors = 0
                var lastGoodLength = 0
                var currentLength = 0
                var currentAddress = targetRun.start
                var earlyExit = false
                for (i in 0 until bestLength.value) {
                    val nextArray = data.getNextAnchor(currentAddress + 1)
                    val match = dataMatchesElementFormat(data, currentAddress, elementContent, i, flags, nextArray)
                    currentLength++
                    currentAddress += elementLength
                    if (match) {
                        lastGoodLength = currentLength
                    } else {
                        encounterErrors++
                        if (encounterErrors > errorsToTolerate) {
                            // as long as this array is at least 80% of the passed in array, we're fine and can say that these are matched.
                            // (the other one might have bad data at the end that needs to be removed) (example: see Gaia)
                            earlyExit = bestLength.value * .8 > lastGoodLength
                            break
                        }
                    }
                }
                currentLength = lastGoodLength

                if (!earlyExit) {
                    var dataEmpty = true
                    for (i in targetRun.start until targetRun.start + currentLength * elementLength) {
                        val d = data[i]
                        if (d != 0xFF && d != 0x00) {
                            dataEmpty = false
                            break
                        }
                    }
                    if (dataEmpty) continue // don't accept the run if it contains no data
                    bestLength.value = currentLength
                    return targetRun.start
                }
            }

            return Pointer.null_
        }
        fun findAllLoads(owner: IDataModel, parser: ThumbParser, pointerLocation: Int): Iterable<ArrayRunFindAllLoadsTuple> { /*@DONE ArrayRun.FindAllLoads/1 cs:1220-1232*/
            return sequence<ArrayRunFindAllLoadsTuple> {
                var funcStart = pointerLocation - 2
                while (funcStart >= 0 && owner[funcStart + 1] != 0xB5) funcStart -= 2
                if (funcStart < 0) return@sequence
                val pointerText = "<" + pointerLocation.toHex(6) + ">"
                for (i in (funcStart + 2) until pointerLocation step 2) {
                    val loadArrayLine = parser.parse(owner, i, 2).trim().splitLines().last().trim()
                    if (!loadArrayLine.contains(pointerText)) continue
                    if (!loadArrayLine.startsWith("ldr ")) continue
                    val register = loadArrayLine.split(',').first().split(' ').last()
                    yield(ArrayRunFindAllLoadsTuple(i, register))
                }
            }.asIterable()
        }
        fun findAllCommands(owner: IDataModel, parser: ThumbParser, startAddress: Int, registerSource: String?, predicate: (String, String?) -> Boolean, callTrail: List<Int>? = null, recurse: Boolean = true): Iterable<ArrayRunFindAllCommandsTuple> { /*@DONE ArrayRun.FindAllCommands/1 cs:1250-1295*/
            return sequence<ArrayRunFindAllCommandsTuple> {
                var regSource = registerSource
                var watchRegister = regSource
                if (watchRegister != null && watchRegister.startsWith("!")) watchRegister = watchRegister.substring(1)
                if (regSource != null && regSource.startsWith("!")) regSource = null
                val trail: List<Int> = callTrail ?: ArrayList<Int>()
                if (trail.contains(startAddress)) return@sequence
                if (trail.size > 4) return@sequence // only allow so many mov / branch operations before we lose interest. This keeps the routine fast.
                val newTrail = trail + startAddress
                var prevCommandIsCmp = false
                var prevCommandIsBl = false
                var i = startAddress
                while (true) {
                    val commandLine = parser.parse(owner, i, 2).trim().splitLines().last().trim()
                    if (!prevCommandIsBl && commandLine.length == 4 && commandLine.all { c -> ViewPort.allHexCharacters.contains(c) }) break // not a valid command
                    if (commandLine.startsWith("bx ")) break
                    if (commandLine.startsWith("pop ") && commandLine.contains("pc")) break

                    // follow branch logic (avoid recursion)
                    if (recurse && commandLine.startsWith("b") && !commandLine.startsWith("bic ")) {
                        val destination = commandLine.split('<').last().split('>').first()
                        if (destination.length < 8 && destination.all { c -> ViewPort.allHexCharacters.contains(c) }) {
                            val nextStart = parseHexInt(destination)
                            if (commandLine.startsWith("bl ") && owner[nextStart + 1] == 0xB5) {
                                // this is a branch link that pushes the link register
                                // no need to recurse here
                            } else if (prevCommandIsCmp || commandLine.indexOf(" ") != 3) {
                                // This is a b/bl that we want to follow, or it's an actual conditional branch (because it's preceded by cmp).
                                // Either way, we want to recurse.
                                yieldAll(findAllCommands(owner, parser, nextStart, regSource, predicate, newTrail))
                            }
                        }
                        if (commandLine.startsWith("b ")) break
                    }

                    val register = commandLine.split(',').first().split(' ').last()

                    // follow move operations
                    if (recurse && regSource != null && commandLine.startsWith("mov ") && commandLine.endsWith(regSource)) {
                        yieldAll(findAllCommands(owner, parser, i + 2, register, predicate, trail))
                    }

                    // look for the actual instruction we care about
                    if ((regSource == null || commandLine.contains(regSource)) && predicate(commandLine, regSource)) yield(ArrayRunFindAllCommandsTuple(i, register))
                    if (register == regSource || register == watchRegister) break
                    prevCommandIsCmp = commandLine.startsWith("cmp ")
                    prevCommandIsBl = commandLine.startsWith("bl ")
                    i += 2
                }
            }.asIterable()
        }
        private fun isValidFieldNameCharacter(c: Char): Boolean { /*@DONE ArrayRun.IsValidFieldNameCharacter/1 cs:1310-1310*/
            return c.isLetterOrDigit() || c == '_' // field names can contain underscores
        }
        private fun isValidTableNameCharacter(c: Char): Boolean { /*@DONE ArrayRun.IsValidTableNameCharacter/1 cs:1311-1311*/
            return c.isLetterOrDigit() || c.isAny('_', '.') // table names can contain underscores or dots
        }
        fun parseSegments(segments: String, model: IDataModel): MutableList<ArrayRunElementSegment> { /*@DONE ArrayRun.ParseSegments/1 cs:1313-1313*/
            return parseSegments2(segments, model)
        }
        fun parseSegments2(segments: String, model: IDataModel): MutableList<ArrayRunElementSegment> { /*@DONE ArrayRun.ParseSegments/2 cs:1314-1441*/
            val list = ArrayList<ArrayRunElementSegment>()
            var remaining = segments.trim()
            while (remaining.length > 0) {
                if (remaining.startsWith("[")) {
                    val subArrayClose = matchPairIndexOfChars(remaining, '[', ']')
                    if (subArrayClose == -1) throw ArrayRunParseException("Found unmatched open bracket ([).")
                    val innerSegments = parseSegments2(remaining.substring(1, subArrayClose), model)
                    remaining = remaining.substring(subArrayClose + 1)
                    var repeatEnd = remaining.indexOf(' ')
                    if (repeatEnd == -1) repeatEnd = remaining.length
                    val innerCount = Ref(0)
                    if (!tryParseInt(remaining.substring(0, repeatEnd), innerCount)) {
                        throw ArrayRunParseException("Could not parse '" + remaining + "' as a number.")
                    }
                    for (i in 0 until innerCount.value) list.addAll(innerSegments)
                    remaining = remaining.substring(repeatEnd)
                    continue
                }

                if (remaining[0] == ' ') {
                    remaining = remaining.substring(1)
                    continue
                }

                var nameEnd = 0
                while (nameEnd < remaining.length && isValidFieldNameCharacter(remaining[nameEnd])) nameEnd++
                val name = remaining.substring(0, nameEnd)
                remaining = remaining.substring(nameEnd)
                val extracted = extractSingleFormat(remaining, model)
                var format = extracted.first
                val formatLength = extracted.second
                var segmentLength = extracted.third
                if (name == "" && format != ElementContentType.Splitter) throw ArrayRunParseException("expected name, but none was found: " + remaining)
                if (format == ElementContentType.PCS && segmentLength < 1) throw ArrayRunParseException("Cannot have 0-length text: " + name)
                if (format == ElementContentType.PCS && segmentLength > 1000) throw ArrayRunParseException("Cannot have text longer than 1k bytes in a table: " + name)

                // check to see if a name or length is part of the format
                val parsedElementCount = Ref(0)
                if (format == ElementContentType.Integer && remaining.length > formatLength && remaining[formatLength] != ' ') {
                    remaining = remaining.substring(formatLength)
                    if (remaining.startsWith(hexFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunHexSegment(name, segmentLength))
                    } else if (remaining.startsWith(signedFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunSignedSegment(name, segmentLength))
                    } else if (remaining.startsWith(tupleFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val tupleContract = remaining.substring(tupleFormatString.length, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunTupleSegment(name, tupleContract, segmentLength))
                    } else if (remaining.startsWith(commentFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val contract = remaining.substring(commentFormatString.length, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunCommentSegment(name, contract))
                    } else if (remaining.startsWith(colorFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunColorSegment(name))
                    } else if (remaining.startsWith(calculatedFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val contract = remaining.substring(calculatedFormatString.length, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunCalculatedSegment(model, name, contract))
                    } else if (remaining.startsWith(pythonButtonFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val contract = remaining.substring(pythonButtonFormatString.length, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunPythonButtonSegment(model, name, contract))
                    } else if (remaining.startsWith(renderFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val contract = remaining.substring(renderFormatString.length, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunOffsetRenderSegment(name, contract))
                    } else if (remaining.startsWith(recordFormatString)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val contract = remaining.substring(0, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        if (contract.count { c -> c == '(' } != 1 || contract.count { c -> c == ')' } != 1) {
                            throw ArrayRunParseException("Record format is s={name}({number}={enum}|...).")
                        }
                        list.add(ArrayRunRecordSegment(name, segmentLength, contract))
                    } else if (tryParseInt(remaining, parsedElementCount)) {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunEnumSegment(name, segmentLength, parsedElementCount.value.toString()))
                    } else {
                        var endOfToken = remaining.indexOf(' ')
                        if (endOfToken == -1) endOfToken = remaining.length
                        val enumName = remaining.substring(0, endOfToken)
                        remaining = remaining.substring(endOfToken).trim()
                        list.add(ArrayRunEnumSegment(name, segmentLength, enumName))
                    }
                } else if (format == ElementContentType.Pointer && formatLength > 2) {
                    val pointerSegment = ArrayRunPointerSegment(model.formatRunFactory, name, remaining.substring(1, formatLength - 1))
                    if (!pointerSegment.isInnerFormatValid) throw ArrayRunParseException("pointer format '" + pointerSegment.innerFormat + "' was not understood.")
                    list.add(pointerSegment)
                    remaining = remaining.substring(formatLength).trim()
                } else if (format == ElementContentType.BitArray) {
                    val sourceName = remaining.substring(BitArray.sharedFormatString.length, formatLength)
                    remaining = remaining.substring(formatLength).trim()
                    list.add(ArrayRunBitArraySegment(name, segmentLength, sourceName))
                } else if (format == ElementContentType.Splitter) {
                    remaining = remaining.substring(formatLength).trim()
                    list.add(ArrayRunSplitterSegment())
                } else {
                    remaining = remaining.substring(formatLength).trim()
                    if (format == ElementContentType.Unknown) {
                        // default to single byte integer
                        format = ElementContentType.Integer
                        segmentLength = 1
                    }
                    list.add(ArrayRunElementSegment(name, format, segmentLength, model.textConverter))
                }
            }

            return list
        } // FIXME-SKEL renamed overload
        private fun extractSingleFormat(segments: String, model: IDataModel): Triple<ElementContentType, Int, Int> { /*@DONE ArrayRun.ExtractSingleFormat/1 cs:1443-1490*/
            if (segments.length >= 2 && segments.substring(0, 2) == PCSRun.sharedFormatString) {
                val format = ElementContentType.PCS
                var formatLength = 2
                while (formatLength < segments.length && segments[formatLength].isDigit()) formatLength++
                val segmentLength = Ref(0)
                if (tryParseInt(segments.substring(2, formatLength), segmentLength)) {
                    return Triple(format, formatLength, segmentLength.value)
                }
            } else if (segments.startsWith(calculatedFormatString)) {
                return Triple(ElementContentType.Integer, 0, 0)
            } else if (segments.startsWith(renderFormatString)) {
                return Triple(ElementContentType.Integer, 0, 0)
            } else if (segments.startsWith(commentFormatString)) {
                return Triple(ElementContentType.Integer, 0, 0)
            } else if (segments.startsWith(pythonButtonFormatString)) {
                return Triple(ElementContentType.Integer, 0, 0)
            } else if (segments.startsWith("" + doubleByteIntegerFormat + "" + doubleByteIntegerFormat)) {
                return Triple(ElementContentType.Integer, 2, 4)
            } else if (segments.startsWith("" + doubleByteIntegerFormat + "" + singleByteIntegerFormat) || segments.startsWith(".:")) {
                return Triple(ElementContentType.Integer, 2, 3)
            } else if (segments.startsWith(doubleByteIntegerFormat.toString())) {
                return Triple(ElementContentType.Integer, 1, 2)
            } else if (segments.startsWith(singleByteIntegerFormat.toString())) {
                return Triple(ElementContentType.Integer, 1, 1)
            } else if (segments.length > 0 && segments[0] == PointerRun.pointerStart) {
                var openCount = 1
                var endIndex = 1
                while (openCount > 0 && endIndex < segments.length) {
                    if (segments[endIndex] == PointerRun.pointerStart) openCount += 1
                    else if (segments[endIndex] == PointerRun.pointerEnd) openCount -= 1
                    endIndex += 1
                }
                if (openCount > 0) return Triple(ElementContentType.Unknown, 0, 0)
                return Triple(ElementContentType.Pointer, endIndex, 4)
            } else if (segments.startsWith(BitArray.sharedFormatString)) {
                var endIndex = BitArray.sharedFormatString.length
                while (segments.length > endIndex && isValidTableNameCharacter(segments[endIndex])) endIndex++
                val format = segments.substring(0, endIndex)
                val name = format.substring(BitArray.sharedFormatString.length)
                val options = model.getBitOptions(name)
                val count = options?.size ?: 8
                return Triple(ElementContentType.BitArray, format.length, Math.ceil(count / 8.0).toInt())
            } else if (segments.startsWith(splitterFormatString + " ")) {
                return Triple(ElementContentType.Splitter, 1, 0)
            }

            return Triple(ElementContentType.Unknown, 0, 0)
        }
        private fun checkPointerFormat(owner: IDataModel, start: Int): Boolean { /*@DONE ArrayRun.CheckPointerFormat/1 cs:1525-1530*/
            val destination = owner.readPointer(start)
            if (destination == Pointer.null_) return true
            if (destination < 0 || destination >= owner.count) return false
            return true
        }
        private fun dataMatchesElementFormat(owner: IDataModel, start: Int, segments: List<ArrayRunElementSegment>, parentIndex: Int, flags: Int, nextAnchor: IFormattedRun?): Boolean { /*@DONE ArrayRun.DataMatchesElementFormat/1 cs:1532-1540*/
            var position = start
            for (segment in segments) {
                if (position + segment.length > owner.count) return false
                if (nextAnchor != null && position + segment.length > nextAnchor.start && nextAnchor is ArrayRun) return false // don't blap over existing arrays
                if (!dataMatchesSegmentFormat(owner, position, segment, flags, segments, parentIndex)) return false
                position += segment.length
            }
            return true
        }
        fun dataMatchesSegmentFormat(owner: IDataModel, start: Int, segment: ArrayRunElementSegment, flags: Int, sourceSegments: List<ArrayRunElementSegment>, parentIndex: Int, deepCheck: Boolean = true): Boolean { /*@DONE ArrayRun.DataMatchesSegmentFormat/1 cs:1542-1619*/
            if (start < 0 || start >= owner.count - segment.length) return false
            Debug.assert(sourceSegments.contains(segment), "Expected segment to be one among sourceSegments.")

            // if it's a record, we want to check the match against the concrete form
            val concrete: ArrayRunElementSegment
            if (segment is ArrayRunRecordSegment) {
                val segmentOffset = sourceSegments.until { seg -> seg === segment }.sumOf { seg -> seg.length }
                val matchOffset = sourceSegments.until { seg -> seg.name == segment.matchField }.sumOf { seg -> seg.length }
                val matchLength = sourceSegments.firstOrNull { seg -> seg.name == segment.matchField }?.length ?: 1
                val matchValue = owner.readMultiByteValue(start + matchOffset - segmentOffset, matchLength)
                concrete = segment.createConcrete(owner.formatRunFactory, owner.textConverter, matchValue)
            } else {
                concrete = segment
            }

            when (concrete.type) {
                ElementContentType.PCS -> {
                    if (concrete.length > 1) { // don't check for valid termination if we only expect a single byte
                        val readLength = PCSString.readString(owner, start, true, concrete.length)
                        if (readLength < 1) return false
                        if (readLength > concrete.length) return false
                        if ((start until start + concrete.length).all { i -> owner[i] == 0xFF }) return false
                    }

                    // if we end with a space, and the next one starts with a space, we probably have the data width wrong.
                    // We might be the start of a different data segment that is no longer pointed to. (Example: Vega/pokenames)
                    // only do this check if the current element seems useful
                    val isBlank = (start until start + concrete.length).all { i -> owner[i] == 0x00 || owner[i] == 0xFF }
                    if (!isBlank && (flags and FormatMatchFlags.IsSingleSegment) != 0 && start % 4 == 0 && owner[start + concrete.length - 1] == 0x00 && owner[start + concrete.length] == 0x00) {
                        // if the next one starts on a 4-byte boundary, then we probably just skipped a few bytes between different data types, and _this_ section is still part of the _last_ run (example, Emerald Ability names)
                        // if the next one doesn't start on a 4-byte boundary, then we probably have the length wrong
                        val nextWordStart = (start + concrete.length + 3) / 4 * 4
                        if ((start + concrete.length until nextWordStart).any { i -> owner[i] != 0x00 } || owner[nextWordStart] == 0x00) return false
                    }

                    // require that the overall thing still ends with 'FF' or '00' to avoid finding text of the wrong width.
                    // the width check is less important if we have more complex data, so relax the condition (example: Clover)
                    // the width check is less important if we're already known to be in a long run (example: Gaia moves)
                    val lastByteInText = owner[start + concrete.length - 1]
                    val lastByteIsReasonablEnd = lastByteInText == 0x00 || lastByteInText == 0xFF
                    if ((flags and FormatMatchFlags.AllowJunkAfterText) == 0 && !lastByteIsReasonablEnd && (flags and FormatMatchFlags.IsSingleSegment) != 0) return false

                    return true
                }
                ElementContentType.Integer -> {
                    if (concrete is ArrayRunEnumSegment) {
                        val options = concrete.getOptions(owner)
                        // don't verify enums that are based on lists.
                        // There could be more elements in use than elements in the list, especially for edited ROMs with default lists.
                        if (options.size == 0 || parentIndex == 0) return true // unrecognized, so just allow anything
                        if (owner.tryGetList(concrete.enumName, Ref<ValidationList?>(null))) return true
                        val modelValue = owner.readMultiByteValue(start, concrete.length)
                        if (concrete.length == 2 && modelValue.toShort().toInt() == -2) return true // allow FFFE short tokens: they often have special meaning
                        return modelValue - concrete.valueOffset < options.size
                    } else {
                        if ((flags and FormatMatchFlags.AllowJunkAfterText) != 0) return true // don't bother verifying if junk is allowed
                        if (concrete is ArrayRunHexSegment) return true // don't validate raw hex content
                        return concrete.length < 4 || owner[start + 3] < 0x08 || owner[start + 3] > 0x09 // we want an integer, not a pointer
                    }
                }
                ElementContentType.Pointer -> {
                    val destination = owner.readPointer(start)
                    if (destination == Pointer.null_) return true
                    if (0 > destination || destination > owner.count) return false
                    if (concrete is ArrayRunPointerSegment) {
                        // allow the format to not match if the pointer points to zero
                        // this is because AdvanceMap inserts pointers to zero and expects them to act like NULLs
                        if (deepCheck && !concrete.destinationDataMatchesPointerFormat(owner, NoDataChangeDeltaModel(), start, destination, sourceSegments, parentIndex) && destination != 0) return false
                    }
                    return true
                }
                ElementContentType.BitArray -> {
                    val bitArraySegment = concrete as ArrayRunBitArraySegment
                    var bits = bitArraySegment.getOptions(owner)?.size ?: 0
                    bits %= 8
                    if (bits == 0) return true
                    var finalByte = owner[start + bitArraySegment.length - 1]
                    finalByte = finalByte shr bits
                    return finalByte == 0 // all the unneeded bits should be set to zero
                }
                else -> throw NotImplementedException()
            }
        }
        /*@END ArrayRun.Companion*/
    }
    /*@END ArrayRun*/
}

open class ArrayRunCommentSegment : ArrayRunElementSegment { // cs:1628-1638
    var index: Int = 0
        private set
    var comment: String = ""
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunCommentSegment.SerializeFormat.get cs:1631-1631*/
            return "${name}|comment=${index}|${comment}"
        }
    constructor(name: String, contract: String) : super(name, ElementContentType.Integer, 0) { /*@DONE ArrayRunCommentSegment.<init>/1 cs:1632-1636*/
        val parts = contract.split("|", limit = 2)
        val parsedIndex = Ref(0)
        if (parts[0].tryParseInt(parsedIndex)) this.index = parsedIndex.value
        this.comment = parts[1]
    }
    fun renderCommentLine(): String { /*@DONE ArrayRunCommentSegment.RenderCommentLine/1 cs:1637-1637*/
        return "# " + comment.replace('_', ' ')
    }
    /*@END ArrayRunCommentSegment*/
}

open class ArrayRunParseException : Exception { // cs:1640-1642
    constructor(message: String) : super(message) { /*@DONE ArrayRunParseException.<init>/1 cs:1641-1641*/ }
    /*@END ArrayRunParseException*/
}

data class ITableRunExtensionsSearchTuple(val item1: Int, val item2: Int)

data class ArrayRunParseTilemapTableTuple(val item1: ArrayRunElementSegment, val item2: TilemapMargins, val item3: String)

data class ArrayRunFindAllLoadsTuple(val address: Int, val register: String)

data class ArrayRunFindAllCommandsTuple(val address: Int, val register: String)

/*@ADD file:models/runs/ArrayRun.kt#runs_4.txt*/
private fun matchPairIndexOfChars(text: String, start: Char, end: Char): Int {
    var started = false
    var depth = 0
    for (index in 0 until text.length) {
        val c = text[index]
        if (c != start && c != end) continue
        if (c == start) {
            started = true
            depth += 1
            continue
        } else {
            if (!started) continue
            depth -= 1
            if (depth == 0) return index
        }
    }
    return -1
}
/*@ENDADD file:models/runs/ArrayRun.kt#runs_4.txt*/
