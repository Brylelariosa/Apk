// Port of Models/Runs/EggMoveRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flySpawns
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tradeTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapBankTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTableRSE
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.wildTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.specialsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDataTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapLayoutTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.berryTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flyConnections
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.dexInfoTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.naturesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldSprites
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonStatsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.eggMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldPalettes
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.frontSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.contestTypesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokePalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typeChartTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.shinyPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerSpritesName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemImagesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.levelMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemEffectsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.regionalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.nationalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.multichoiceTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDescriptionsName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backupFontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultSpriteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerClassNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.conversionDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultTilemapNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultPaletteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityDescriptionsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPaletteIndexTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticleSpriteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticlePaletteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveInfoListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTargetListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionMethodListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsShapeListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsCategoryListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsPermissionListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emerald
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.hmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTutors
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tutorCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.cfruIgnoreTables
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decodeConstantsFromReference
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.getIsCFRU

open class EggMoveRun : BaseRun, IStreamRun, IAppendToBuilderRun { // cs:13-284
    private lateinit var model: IDataModel
    final override var length: Int = 0
        private set
    override val formatString: String
        get() { /*@DONE EggMoveRun.FormatString.get cs:22-22*/
            return sharedFormatString
        }
    constructor(dataModel: IDataModel, dataIndex: Int, pointerSources: SortedSpan<Int>? = null) : super(dataIndex, pointerSources) { /*@DONE EggMoveRun.<init>/1 cs:24-34*/
        model = dataModel
        length = 0
        if (start < 0) return
        var i = start
        while (i < model.count) {
            if (model[i] == 0xFF && i + 1 < model.count && model[i + 1] == 0xFF) {
                length = i - start + 2
                break
            }
            i += 2
        }
    }
    override fun createDataFormat(data: IDataModel, dataIndex: Int): IDataFormat { /*@DONE EggMoveRun.CreateDataFormat/1 cs:86-108*/
        val cache = ModelCacheScope.getCache(data)
        val cachedPokenames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
        val cachedMovenames = cache.getOptions(HardcodeTablesModel.moveNamesTable)

        var position = dataIndex - start
        val groupOffset = if (position % 2 == 1) position - 1 else position
        position -= groupOffset
        var value = data.readMultiByteValue(start + groupOffset, 2)
        if (value >= magicNumber) {
            value -= magicNumber
            var content = if (cachedPokenames.size > value) cachedPokenames[value] else value.toString()
            if (value == endStream - magicNumber) content = ""
            if (content.startsWith("\"")) content = content.substring(1)
            if (content.endsWith("\"")) content = content.substring(0, content.length - 1)
            return EggSection(groupOffset + start, position, groupStart + content + groupEnd)
        } else {
            val content = if (cachedMovenames.size > value) cachedMovenames[value] else value.toString()
            return EggItem(groupOffset + start, position, content)
        }
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE EggMoveRun.Clone/1 cs:110-110*/
        return EggMoveRun(model, start, newPointerSources)
    }
    fun getPokemonNumber(input: String): Int { /*@DONE EggMoveRun.GetPokemonNumber/1 cs:112-119*/
        val cachedPokenames = model.getOptions(HardcodeTablesModel.pokemonNameTable)

        var text = input
        if (text.startsWith(groupStart)) text = text.substring(1, text.length - 1)
        text = text.lowercase()
        val names = cachedPokenames.map { name -> name.trim('"').lowercase() }
        return names.indexOfPartial(text)
    }
    fun getMoveNumber(input: String): Int { /*@DONE EggMoveRun.GetMoveNumber/1 cs:121-128*/
        val cache = ModelCacheScope.getCache(model)
        val cachedMovenames = cache.getOptions(HardcodeTablesModel.moveNamesTable)

        val text = input.trim('"').lowercase()
        val names = cachedMovenames.map { name -> name.trim('"').lowercase() }
        return names.indexOfPartial(text)
    }
    override fun serializeRun(): String? { /*@DONE EggMoveRun.SerializeRun/1 cs:130-150*/
        val cache = ModelCacheScope.getCache(model)
        val cachedPokenames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
        val cachedMovenames = cache.getOptions(HardcodeTablesModel.moveNamesTable)

        val builder = StringBuilder()
        var i = 0
        while (i < length - 2) {
            val address = start + i
            var value = model.readMultiByteValue(address, 2)
            if (value >= magicNumber) {
                value -= magicNumber
                val pokemonName = if (value < cachedPokenames.size) cachedPokenames[value] else value.toString()
                builder.append(groupStart + pokemonName.trim('"') + groupEnd)
            } else {
                val moveName = if (value < cachedMovenames.size) cachedMovenames[value] else value.toString()
                builder.append(moveName.trim('"'))
            }
            if (i < length - 4) builder.append(NEW_LINE)
            i += 2
        }
        return builder.toString()
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE EggMoveRun.DeserializeRun/1 cs:152-191*/
        val changedAddresses = ArrayList<Int>()
        changedRuns.value = ArrayList<Int>()
        val cache = ModelCacheScope.getCache(model)
        val cachedPokenames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
        val cachedMovenames = cache.getOptions(HardcodeTablesModel.moveNamesTable)

        val data = ArrayList<Int>()
        val pokemonNames = cachedPokenames.map { name -> groupStart + name.trim('"').lowercase() + groupEnd }
        val moveNames = cachedMovenames.map { name -> name.trim('"').lowercase() }
        val lines = content.lowercase().split('\r', '\n').filter { line -> line.length > 0 }
        for (line in lines) {
            var index = pokemonNames.indexOf(line)
            if (index != -1) { data.add(index + magicNumber); continue }
            index = moveNames.indexOf(line)
            if (index != -1) { data.add(index); continue }

            // didn't find an exact match... look for a partial pokemon match
            var matchFound = false
            for (i in 0 until pokemonNames.size) {
                if (pokemonNames[i].contains(line)) { data.add(i + magicNumber); matchFound = true; break }
            }
            if (matchFound) continue

            // look for a partial move match
            for (i in 0 until moveNames.size) {
                if (moveNames[i].contains(line)) { data.add(i); break }
            }
        }
        val run = model.relocateForExpansion(token, this, data.size * 2 + 2)
        for (i in 0 until data.size) {
            val p = run.start + i * 2
            if (model.writeMultiByteValue(p, 2, token, data[i])) changedAddresses.add(p)
        }
        val end = run.start + data.size * 2
        if (model.readMultiByteValue(end, 2) != endStream) model.writeMultiByteValue(end, 2, token, endStream) // write the new end token (untracked)
        for (i in data.size + 1 until length / 2) model.writeMultiByteValue(run.start + i * 2, 2, token, endStream) // fill any remaining old space with FF (untracked)
        changedOffsets.value = changedAddresses
        return EggMoveRun(model, run.start)
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE EggMoveRun.GetAutoCompleteOptions/1 cs:193-214*/
        val result = ArrayList<AutocompleteItem>()
        var text = line.trim()
        var nameTable = HardcodeTablesModel.moveNamesTable
        var wrap: (String) -> String = { option -> option }

        if (text.startsWith("[")) {
            text = text.substring(1)
            if (text.endsWith("]")) text = text.substring(0, text.length - 1)
            nameTable = HardcodeTablesModel.pokemonNameTable
            wrap = { option -> "[" + option + "]" }
        }

        val partialText = text
        result.addAll(
            model.getOptions(nameTable)
                .filter { option -> option.matchesPartial(partialText) }
                .map { option -> option.trim('"') }
                .map(wrap)
                .map { option -> AutocompleteItem(option, option) }
        )

        return result
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE EggMoveRun.Visualizations.get cs:216-216*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    override fun dependsOn(anchorName: String): Boolean { /*@DONE EggMoveRun.DependsOn/1 cs:218-220*/
        return anchorName == HardcodeTablesModel.pokemonNameTable || anchorName == HardcodeTablesModel.moveNamesTable
    }
    fun search(parentArrayName: String, index: Int): Iterable<EggMoveRunSearchTuple> { /*@DONE EggMoveRun.Search/1 cs:222-232*/
        val result = ArrayList<EggMoveRunSearchTuple>()
        var groupStartValue = 0
        if (parentArrayName == HardcodeTablesModel.pokemonNameTable) groupStartValue = magicNumber
        if (parentArrayName == HardcodeTablesModel.pokemonNameTable || parentArrayName == HardcodeTablesModel.moveNamesTable) {
            var i = 0
            while (i < length - 2) {
                if (model.readMultiByteValue(start + i, 2) == index + groupStartValue) {
                    result.add(EggMoveRunSearchTuple(start + i, start + i + 1))
                }
                i += 2
            }
        }
        return result
    }
    fun getAutoCompleteOptions(): Iterable<String> { /*@DONE EggMoveRun.GetAutoCompleteOptions/2 cs:234-242*/
        val cache = ModelCacheScope.getCache(model)
        val cachedPokenames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
        val cachedMovenames = cache.getOptions(HardcodeTablesModel.moveNamesTable)

        val pokenames = cachedPokenames.map { name -> groupStart + name + groupEnd } // closing brace, so no space needed
        val movenames = cachedMovenames.map { name -> name + " " } // autocomplete needs to complete after selection, so add a space
        return pokenames + movenames
    }
    override fun appendTo(model: IDataModel, text: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE EggMoveRun.AppendTo/1 cs:244-265*/
        val cache = ModelCacheScope.getCache(model)
        val cachedPokenames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
        val cachedMovenames = cache.getOptions(HardcodeTablesModel.moveNamesTable)

        var current = start
        var remaining = length
        while (remaining > 0 && current < this.start + this.length) {
            var value = model.readMultiByteValue(current, 2)
            if (value == endStream) {
                text.append(groupStart + groupEnd)
            } else if (value >= magicNumber) {
                value -= magicNumber
                if (value >= cachedPokenames.size) text.append(groupStart + value.toString() + groupEnd)
                else text.append(groupStart + cachedPokenames[value].trim('"') + groupEnd)
            } else {
                if (value >= cachedMovenames.size) text.append(value.toString())
                else text.append(cachedMovenames[value])
            }
            current += 2
            remaining -= 2
            if (remaining > 0 && current < this.start + this.length) text.append(" ")
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE EggMoveRun.Clear/1 cs:267-269*/
        for (i in 0 until length) changeToken.changeData(model, start + i, 0)
    }
    fun updateLimiter(token: ModelDelta): Boolean { /*@DONE EggMoveRun.UpdateLimiter/1 cs:271-283*/
        var expectedPointerCount = 2
        var expectedLimitValue = length / 2 - 2
        if (HardcodeTablesModel.getIsCFRU(model)) {
            expectedPointerCount = 3
            expectedLimitValue = length / 2 - 1
        }

        if (pointerSources?.size != expectedPointerCount) return false
        val address = pointerSources!!.last() - 4
        model.writeMultiByteValue(address, 4, token, expectedLimitValue)
        return true
    }
    companion object {
        const val magicNumber: Int = 0x4E20
        const val endStream: Int = 0xFFFF
        const val groupStart: String = "["
        const val groupEnd: String = "]"
        val sharedFormatString: String = /*@INITDONE EggMoveRun.SharedFormatString cs:18-18*/ AsciiRun.streamDelimeter.toString() + "egg" + AsciiRun.streamDelimeter /*@ENDINIT*/
        fun trySearch(data: IDataModel, token: ModelDelta, eggmoves: Ref<EggMoveRun?>): Boolean { /*@DONE EggMoveRun.TrySearch/1 cs:36-84*/
            eggmoves.value = null
            val pokenames = data.getNextRun(data.getAddressFromAnchor(token, -1, HardcodeTablesModel.pokemonNameTable)) as? ArrayRun
            val movenames = data.getNextRun(data.getAddressFromAnchor(token, -1, HardcodeTablesModel.moveNamesTable)) as? ArrayRun
            if (pokenames == null || movenames == null) return false

            var run = data.getNextRun(0)!!
            while (run.start < Int.MAX_VALUE) {
                val current = run
                run = data.getNextRun(current.start + current.length)!!
                val sources = current.pointerSources
                if (current is ArrayRun || current is PCSRun || sources == null) continue

                // verify expected pointers to this
                if (sources.size < 2 || sources.size > 10) continue

                // verify limiter
                val length = data.readMultiByteValue(sources[1] - 4, 4)

                // we just read the 'length' from basically a random byte... verify that it could make sense as a length
                if (length < 1000 || length > 7000) continue
                if (current.start + length * 2 + 3 < 0) continue
                if (current.start + length * 2 + 3 > data.count) continue

                // verify content
                var possibleMatch = true
                var lastValue = -1
                for (i in 0 until length - 2) {
                    var value = data.readMultiByteValue(current.start + i * 2, 2)

                    // if the same byte pairs are repeated multiple times, then this pokemon is listed twice or has the same egg move twice.
                    // that seems unlikely... this is probably the wrong data.
                    if (value == lastValue) { possibleMatch = false; break }
                    lastValue = value

                    if (value == endStream) break // early exit, the data was edited, but that's ok. Everything still matches up.
                    if (value >= magicNumber) {
                        value -= magicNumber
                        if (value < pokenames.elementCount) continue
                    }
                    if (value < movenames.elementCount) continue
                    possibleMatch = false
                    break
                }
                if (!possibleMatch) continue

                // content is correct, length is correct: this is it!
                eggmoves.value = EggMoveRun(data, current.start)
                return true
            }

            return false
        }
        /*@END EggMoveRun.Companion*/
    }
    /*@END EggMoveRun*/
}

data class EggMoveRunSearchTuple(val item1: Int, val item2: Int)
