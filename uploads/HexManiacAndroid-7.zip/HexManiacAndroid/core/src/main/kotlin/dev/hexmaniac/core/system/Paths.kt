package dev.hexmaniac.core.system

/**
 * Stand-in for System.IO.Path. Both '/' and '\\' count as separators so names coming from desktop metadata still work.
 * Android file names (SAF display names) are plain names, so most results are just the name itself.
 */
object Path {
    const val directorySeparatorChar: Char = '/'

    private fun isSeparator(c: Char): Boolean = c == '/' || c == '\\'

    fun getFileName(path: String?): String? {
        if (path == null) return null
        val i = path.indexOfLast { isSeparator(it) }
        return path.substring(i + 1)
    }

    fun getExtension(path: String?): String? {
        val name = getFileName(path) ?: return null
        val i = name.lastIndexOf('.')
        return if (i < 0 || i == name.length - 1) "" else name.substring(i)
    }

    fun getFileNameWithoutExtension(path: String?): String? {
        val name = getFileName(path) ?: return null
        val i = name.lastIndexOf('.')
        return if (i < 0) name else name.substring(0, i)
    }

    fun getDirectoryName(path: String?): String? {
        if (path == null) return null
        val i = path.indexOfLast { isSeparator(it) }
        if (i < 0) return ""
        if (i == 0) return if (path.length == 1) null else path.substring(0, 1)
        return path.substring(0, i)
    }

    fun getFullPath(path: String): String {
        if (path.isEmpty()) throw ArgumentException("The path is empty.")
        return java.io.File(path).absolutePath
    }

    fun combine(path1: String, path2: String): String {
        if (path2.isNotEmpty() && isSeparator(path2[0])) return path2
        if (path1.isEmpty()) return path2
        if (path2.isEmpty()) return path1
        return if (isSeparator(path1[path1.length - 1])) path1 + path2 else path1 + directorySeparatorChar + path2
    }

    fun changeExtension(path: String?, extension: String?): String? {
        if (path == null) return null
        val nameStart = path.indexOfLast { isSeparator(it) } + 1
        val dot = path.lastIndexOf('.')
        val withoutExtension = if (dot >= nameStart) path.substring(0, dot) else path
        if (extension == null) return withoutExtension
        if (extension.isEmpty()) return withoutExtension
        return withoutExtension + (if (extension.startsWith(".")) "" else ".") + extension
    }

    fun getInvalidFileNameChars(): CharArray {
        val chars = ArrayList<Char>()
        chars.add('"'); chars.add('<'); chars.add('>'); chars.add('|'); chars.add(':'); chars.add('*'); chars.add('?'); chars.add('\\'); chars.add('/')
        for (i in 0..31) chars.add(i.toChar())
        return chars.toCharArray()
    }
}
