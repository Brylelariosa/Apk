// Port of ViewModels/QuickEditItems/MakeItemsExpandable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flySpawns
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tradeTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapBankTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTableRSE
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.wildTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.specialsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDataTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapLayoutTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.berryTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flyConnections
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.dexInfoTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.naturesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldSprites
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonStatsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.eggMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldPalettes
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.frontSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.contestTypesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokePalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typeChartTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.shinyPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerSpritesName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemImagesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.levelMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemEffectsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.regionalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.nationalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.multichoiceTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDescriptionsName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backupFontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultSpriteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerClassNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.conversionDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultTilemapNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultPaletteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityDescriptionsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPaletteIndexTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticleSpriteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticlePaletteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveInfoListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTargetListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionMethodListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsShapeListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsCategoryListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsPermissionListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emerald
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.hmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTutors
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tutorCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.cfruIgnoreTables
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decodeConstantsFromReference
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.getIsCFRU

open class MakeItemsExpandable : IQuickEditItem { // cs:9-70
    override val name: String?
        get() { /*@DONE MakeItemsExpandable.Name.get cs:10-10*/
            return "Make Items Expandable"
        }
    override val description: String?
        get() { /*@DONE MakeItemsExpandable.Description.get cs:12-13*/
            return "The initial games have functions that do out-of-bounds checks on item IDs using a hard-coded number of items." +
                NEW_LINE + "This change will allow HexManiac to update those functions as you to expand the number of items in the game."
        }
    override val wikiLink: String?
        get() { /*@DONE MakeItemsExpandable.WikiLink.get cs:15-15*/
            // the original throws NotImplementedException here; there is no wiki page for this item, so report 'no link'.
            return null
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPortInterface: IViewPort): Boolean { /*@DONE MakeItemsExpandable.CanRun/1 cs:27-37*/
        val viewPort = viewPortInterface as? ViewPort
        if (viewPort == null) return false
        val model = viewPort.model
        val gameCode = model.getGameCode()

        val start = getPrimaryEditAddress(gameCode)
        if (start == -1) return false
        val run = model.getNextRun(start)
        return run !is WordRun
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE MakeItemsExpandable.Run/1 cs:39-67*/
        val viewPort = viewPortInterface as ViewPort
        val model = viewPort.model
        val gameCode = model.getGameCode()
        val start = getPrimaryEditAddress(gameCode)

        // IsItemIDValid(itemID)
        viewPort.edit("@" + start.toHex(6) + " 00 B5 00 04 00 0C 03 49 08 45 00 DB 00 20 02 BC 08 47 00 00 ::" + HardcodeTablesModel.itemsTableName + " ")

        if (gameCode == HardcodeTablesModel.fireRed) {
            // DB: comparison was 'less or same'. Make it 'less than'.
            //     then update the constant after the code to just be the number of items.
            viewPort.edit("@098983 DB @098998 ::" + HardcodeTablesModel.itemsTableName + " ")
        } else if (gameCode == HardcodeTablesModel.leafGreen) {
            // DB: comparison was 'less or same'. Make it 'less than'.
            //     then update the constant after the code to just be the number of items.
            viewPort.edit("@098967 DB @09896C ::" + HardcodeTablesModel.itemsTableName + " ")
        } else if (gameCode == HardcodeTablesModel.emerald) {
            // Emerald code already uses the number of items specifically. Just add the
            //    format so we can update the constant whenever the user adds new items.
            viewPort.edit("@1B0014 ::" + HardcodeTablesModel.itemsTableName + " ")
        }
        // note that we make no updates for Ruby/Sapphire... that's because I don't
        //    know where the item image tables are stored in those games :(

        canRunChanged(this, EventArgs.empty)

        return Task.fromResult(ErrorInfo.noError)
    }
    override fun tabChanged() { /*@DONE MakeItemsExpandable.TabChanged/1 cs:69-69*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        fun getPrimaryEditAddress(gameCode: String): Int { /*@DONE MakeItemsExpandable.GetPrimaryEditAddress/1 cs:19-25*/
            if (gameCode == HardcodeTablesModel.fireRed) return 0x09A8A4
            if (gameCode == HardcodeTablesModel.leafGreen) return 0x09A878
            if (gameCode == HardcodeTablesModel.ruby || gameCode == HardcodeTablesModel.sapphire) return 0x0A98BC
            if (gameCode == HardcodeTablesModel.emerald) return 0xAD745C
            return -1
        }
        /*@END MakeItemsExpandable.Companion*/
    }
    /*@END MakeItemsExpandable*/
}
