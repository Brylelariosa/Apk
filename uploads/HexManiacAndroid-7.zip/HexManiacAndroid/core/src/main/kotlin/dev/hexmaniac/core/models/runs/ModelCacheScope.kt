// Port of Models/Runs/ModelCacheScope.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.tools.*

open class ModelCacheScope : IDisposable { // cs:14-250
    private lateinit var model: IDataModel
    constructor(model: IDataModel) { /*@DONE ModelCacheScope.<init>/1 cs:16-16*/
        this.model = model
    }
    override fun dispose() { /*@DONE ModelCacheScope.Dispose/1 cs:20-20*/
        // nothing to dispose
    }
    private val cachedOptions: MutableMap<String, List<String>> = /*@INITAUTO ModelCacheScope.cachedOptions cs:26-26*/ LinkedHashMap() /*@ENDINIT*/
    private val cachedBitOptions: MutableMap<String, List<String>> = /*@INITAUTO ModelCacheScope.cachedBitOptions cs:27-27*/ LinkedHashMap() /*@ENDINIT*/
    private var cachedMapInfo: List<MapInfo>? = null
    private val cachedImages: MutableMap<Int, IPixelViewModel?> = /*@INITAUTO ModelCacheScope.cachedImages cs:29-29*/ LinkedHashMap() /*@ENDINIT*/
    fun getOptions(table: String): List<String> { /*@DONE ModelCacheScope.GetOptions/1 cs:31-47*/
        val currentModel = model
        if (currentModel is PokemonModel) {
            var result: List<String>? = null
            currentModel.threadlockRuns {
                synchronized(cachedOptions) {
                    if (!cachedOptions.containsKey(table)) cachedOptions[table] = getOptions(currentModel, table) ?: ArrayList()
                    result = cachedOptions[table]
                }
            }
            return result!!
        } else {
            synchronized(cachedOptions) {
                if (!cachedOptions.containsKey(table)) cachedOptions[table] = getOptions(currentModel, table) ?: ArrayList()
                return cachedOptions[table]!!
            }
        }
    }
    private val cachedDependentArrays: MutableMap<String, List<ArrayRun>> = /*@INITDONE ModelCacheScope.cachedDependentArrays cs:49-49*/ LinkedHashMap() /*@ENDINIT*/
    fun getDependantArrays(anchor: String): Iterable<ArrayRun> { /*@DONE ModelCacheScope.GetDependantArrays/1 cs:50-64*/
        val cache = cachedDependentArrays[anchor]
        if (cache != null) return cache

        val results = ArrayList<ArrayRun>()
        for (array in model.arrays) {
            if (array.lengthFromAnchor == anchor) results.add(array)
            for (segment in array.elementContent) {
                if (segment is ArrayRunBitArraySegment) {
                    if (segment.sourceArrayName == anchor) results.add(array)
                }
            }
        }
        cachedDependentArrays[anchor] = results
        return results
    }
    fun getBitOptions(enumName: String): List<String>? { /*@DONE ModelCacheScope.GetBitOptions/1 cs:73-102*/
        val cachedValue = cachedBitOptions[enumName]
        if (cachedValue != null) return cachedValue

        // if it's from a list, then it's not from an enum, but instead from just a string list
        val nameArray = Ref<ValidationList?>(null)
        if (model.tryGetList(enumName, nameArray)) return nameArray.value!!.map { quoteIfNeeded(it) }

        val sourceAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, enumName)
        if (sourceAddress == Pointer.null_) return null
        val sourceRun = model.getNextRun(sourceAddress) as? ArrayRun
        if (sourceRun == null) return null
        val sourceSegment = sourceRun.elementContent[0] as? ArrayRunEnumSegment
        if (sourceSegment == null) {
            if (sourceRun.elementContent[0].type == ElementContentType.PCS) return sourceRun.elementNames
            return null
        }

        val enumOptions = sourceSegment.getOptions(model).toList()

        val results = ArrayList<String>(sourceRun.elementCount)
        for (i in 0 until sourceRun.elementCount) {
            val value = model.readMultiByteValue(sourceRun.start + sourceRun.elementLength * i, sourceSegment.length)
            if (value < enumOptions.size) {
                results.add(enumOptions[value])
            } else {
                results.add(value.toString())
            }
        }

        cachedBitOptions[enumName] = results
        return results
    }
    fun getImage(run: ISpriteRun): IPixelViewModel? { /*@DONE ModelCacheScope.GetImage/1 cs:104-111*/
        synchronized(cachedImages) {
            if (cachedImages.containsKey(run.start)) return cachedImages[run.start]
            val pixels: IPixelViewModel? = SpriteDecorator.buildSprite(model, run)
            cachedImages[run.start] = pixels
            return pixels
        }
    }
    fun getImage(run: BlockmapRun): IPixelViewModel? { /*@DONE ModelCacheScope.GetImage/2 cs:113-120*/
        synchronized(cachedImages) {
            if (cachedImages.containsKey(run.start)) return cachedImages[run.start]
            val pixels: IPixelViewModel? = SpriteDecorator.buildSprite(model, run)
            cachedImages[run.start] = pixels
            return pixels
        }
    }
    fun getAllMaps(): List<MapInfo> { /*@DONE ModelCacheScope.GetAllMaps/1 cs:122-139*/
        val cached = cachedMapInfo
        if (cached != null) return cached
        val results = ArrayList<MapInfo>()
        cachedMapInfo = results
        val bankTable = model.getTable(HardcodeTablesModel.mapBankTable)
        if (bankTable == null) return results
        val banks = ModelTable(model, bankTable.start, null, bankTable)
        for (i in 0 until banks.size) {
            val maps = banks[i].getSubTable("maps")
            if (maps == null) continue
            for (j in 0 until maps.size) {
                val name = BlockMapViewModel.mapIDToText(model, i, j)
                val mapText = "maps.bank$i.$name"
                results.add(MapInfo(i, j, mapText))
            }
        }
        return results
    }
    private var devolutions: Map<Int, Int>? = null
    private var minimumLevel: Map<Int, Int>? = null
    private var eggMoves: Map<Int, List<Int>>? = null
    private var levelupMoves: Map<Int, List<Int>>? = null
    private var tutorMoves: Map<Int, List<Int>>? = null
    private var tmMoves: Map<Int, List<Int>>? = null
    fun getPokemonDevolutions(): Map<Int, Int> { /*@DONE ModelCacheScope.GetPokemonDevolutions/1 cs:143-143*/
        return devolutions ?: Flags.getPokemonDevolutions(model).also { devolutions = it }
    }
    fun getPokemonMinimumLevels(): Map<Int, Int> { /*@DONE ModelCacheScope.GetPokemonMinimumLevels/1 cs:144-144*/
        return minimumLevel ?: Flags.getMinimumLevelForPokemon(model).also { minimumLevel = it }
    }
    fun getPokemonEggMoves(): Map<Int, List<Int>> { /*@DONE ModelCacheScope.GetPokemonEggMoves/1 cs:145-145*/
        return eggMoves ?: (Flags.getPokemonEggMoves(model)?.also { eggMoves = it } ?: emptyMap())
    }
    fun getLevelupMoves(): Map<Int, List<Int>> { /*@DONE ModelCacheScope.GetLevelupMoves/1 cs:146-146*/
        return levelupMoves ?: (Flags.getPokemonLevelupMoves(model)?.also { levelupMoves = it } ?: emptyMap())
    }
    fun getTutorMoves(): Map<Int, List<Int>> { /*@DONE ModelCacheScope.GetTutorMoves/1 cs:147-147*/
        return tutorMoves ?: (Flags.getPokemonTutorMoves(model)?.also { tutorMoves = it } ?: emptyMap())
    }
    fun getTmMoves(): Map<Int, List<Int>> { /*@DONE ModelCacheScope.GetTmMoves/1 cs:148-148*/
        return tmMoves ?: (Flags.getPokemonTmMoves(model)?.also { tmMoves = it } ?: emptyMap())
    }
    private var scriptDestinations: MutableMap<Int, MutableMap<Int, Int>> = /*@INITDONE ModelCacheScope.scriptDestinations cs:153-153*/ LinkedHashMap() /*@ENDINIT*/
    fun scriptDestinations(start: Int): MutableMap<Int, Int> { /*@DONE ModelCacheScope.ScriptDestinations/1 cs:154-160*/
        var destinations = scriptDestinations[start]
        if (destinations == null) {
            destinations = LinkedHashMap()
            scriptDestinations[start] = destinations
        }
        return destinations
    }
    private val cachedScripts: MutableMap<Int, ScriptInfo> = /*@INITDONE ModelCacheScope.cachedScripts cs:163-163*/ LinkedHashMap() /*@ENDINIT*/
    fun getScriptInfo(parser: ScriptParser, scriptStart: Int, updateBody: CodeBody?, existingSectionCount: Ref<Int>): ScriptInfo { /*@DONE ModelCacheScope.GetScriptInfo/1 cs:165-177*/
        val existingScript = cachedScripts[scriptStart]
        if (existingScript != null && existingScript.parser === parser) {
            existingSectionCount.value = existingScript.sectionCount
            return existingScript
        }
        val destinations = scriptDestinations(scriptStart)
        val scriptLength = parser.findLength(model, scriptStart, destinations)
        val content = parser.parse(model, scriptStart, scriptLength, existingSectionCount, updateBody)
        val scriptInfo = ScriptInfo(scriptStart, scriptLength, parser, content, existingSectionCount.value)
        destinations[scriptStart] = scriptLength
        cachedScripts[scriptStart] = scriptInfo
        return scriptInfo
    }
    companion object {
        fun createScope(model: IDataModel): IDisposable { /*@DONE ModelCacheScope.CreateScope/1 cs:17-19*/
            return model.currentCacheScope
        }
        fun getCache(model: IDataModel): ModelCacheScope { /*@DONE ModelCacheScope.GetCache/1 cs:22-24*/
            return model.currentCacheScope
        }
        fun quoteIfNeeded(text: String): String { /*@DONE ModelCacheScope.QuoteIfNeeded/1 cs:67-71*/
            if (!text.contains(" ")) return text
            if (text.contains("\"")) return text
            return "\"$text\""
        }
        private fun getOptions(model: IDataModel, enumName: String): List<String> { /*@DONE ModelCacheScope.GetOptions/2 cs:181-235*/
            val nameArray = Ref<ValidationList?>(null)
            if (model.tryGetList(enumName, nameArray)) return nameArray.value!!

            val enumArrayRef = Ref<ArrayRun?>(null)
            if (!model.tryGetNameArray(enumName, enumArrayRef)) {
                val indexArray = Ref<List<String>?>(null)
                if (model.tryGetIndexNames(enumName, indexArray)) return indexArray.value!!
                val derivedEnumArray = Ref<List<String>?>(null)
                if (model.tryGetDerivedEnumNames(enumName, derivedEnumArray)) return derivedEnumArray.value!!
                val listContent = Ref<List<String>?>(null)
                if (model.tryGetListEnumNames(enumName, listContent)) return listContent.value!!
                return ArrayList()
            }
            val enumArray = enumArrayRef.value!!

            // array must be at least as long as than the current value
            val optionCount = enumArray.elementCount

            // sweet, we can convert from the integer value to the enum value
            val results = ArrayList<String>()
            var textIndex = 0
            var segmentOffset = 0
            while (textIndex < enumArray.elementContent.size) {
                val segmnt = enumArray.elementContent[textIndex]
                if (segmnt.type == ElementContentType.PCS) break
                if (segmnt is ArrayRunPointerSegment && segmnt.innerFormat == PCSRun.sharedFormatString) break
                segmentOffset += segmnt.length
                textIndex++
            }
            if (textIndex == enumArray.elementContent.size) return ArrayList()
            val segment = enumArray.elementContent[textIndex]
            val isPointer = segment.type == ElementContentType.Pointer

            val resultCache = LinkedHashMap<String, Int>()

            for (i in 0 until optionCount) {
                var elementStart = enumArray.start + enumArray.elementLength * i + segmentOffset
                var elementLength = segment.length
                if (isPointer) {
                    elementStart = model.readPointer(elementStart)
                    if (elementStart < 0 || elementStart >= model.count) return ArrayList()
                    elementLength = PCSString.readString(model, elementStart, true)
                    if (elementLength < 1) return ArrayList() // contents must be a valid string to be used as options
                }

                val valueWithQuotes = model.textConverter.convert(model, elementStart, elementLength)?.replace(NEW_LINE, "")?.trim() ?: ""

                if (valueWithQuotes.contains(' ')) {
                    addResult(resultCache, results, valueWithQuotes)
                    continue
                }

                var value = valueWithQuotes
                if (value.startsWith("\"")) value = value.substring(1)
                if (value.endsWith("\"")) value = value.substring(0, value.length - 1)
                addResult(resultCache, results, value)
            }

            return results
        }
        private fun addResult(currentResultsCache: MutableMap<String, Int>, results: MutableList<String>, newResult: String) { /*@DONE ModelCacheScope.AddResult/1 cs:241-249*/
            var result = newResult
            val count = currentResultsCache[result.lowercase()] ?: 1
            currentResultsCache[result.lowercase()] = count + 1
            val hasQuotes = result.startsWith("\"") && result.endsWith("\"")
            if (hasQuotes) result = result.substring(1, result.length - 1)
            if (count > 1) result += "~" + count
            if (hasQuotes) result = "\"$result\""
            results.add(result)
        }
        /*@END ModelCacheScope.Companion*/
    }
    /*@END ModelCacheScope*/
}

open class MapInfo(val group: Int, val map: Int, val name: String) : INotifyPropertyChanged { // cs:252-254
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    /*@END MapInfo*/
}

class JumpMapInfo(group: Int, map: Int, name: String, val jumpAction: (ChangeMapEventArgs) -> Unit) : MapInfo(group, map, name) { // cs:256-258
    fun gotoMap() { /*@DONE JumpMapInfo.GotoMap/1 cs:257-257*/
        jumpAction(ChangeMapEventArgs(group, map))
    }
    /*@END JumpMapInfo*/
}

data class ScriptInfo(override val start: Int, val length: Int, val parser: ScriptParser, val content: String, val sectionCount: Int) : ISearchTreePayload { // cs:260-260
    /*@END ScriptInfo*/
}
