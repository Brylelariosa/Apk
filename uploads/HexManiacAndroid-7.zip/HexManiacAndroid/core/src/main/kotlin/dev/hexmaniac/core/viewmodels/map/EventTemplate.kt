// Port of ViewModels/Map/EventTemplate.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

interface IDataInvestigator { // cs:21-24
    fun findNextUnusedFlag(): Int
    fun findNextUnusedVariable(): Int
    /*@END IDataInvestigator*/
}

open class EventTemplate : ViewModelCore, IDataInvestigator { // cs:26-1106
    private val rnd: java.util.Random = /*@INITDONE EventTemplate.rnd cs:27-27*/ java.util.Random() /*@ENDINIT*/
    private lateinit var model: IDataModel
    private lateinit var parser: ScriptParser
    private var initializationWorkload: Task<Unit> = Task.completedTask
    private var _usedFlags: MutableSet<Int> = LinkedHashSet()
    private var _usedTrainerFlags: MutableSet<Int> = LinkedHashSet()
    private var _usedVariables: MutableSet<Int> = LinkedHashSet()
    private var _trainerPreferences: Map<Int, TrainerPreference>? = null
    private var _minLevel: Map<Int, Int>? = null
    private val usedFlags: MutableSet<Int>
        get() { /*@DONE EventTemplate.UsedFlags.get cs:36-39*/
            initializationWorkload.waitSync()
            return _usedFlags
        }
    private val usedTrainerFlags: MutableSet<Int>
        get() { /*@DONE EventTemplate.UsedTrainerFlags.get cs:42-45*/
            initializationWorkload.waitSync()
            return _usedTrainerFlags
        }
    private val usedVariables: MutableSet<Int>
        get() { /*@DONE EventTemplate.UsedVariables.get cs:48-51*/
            initializationWorkload.waitSync()
            return _usedVariables
        }
    fun useTrainerFlag(flag: Int) { /*@DONE EventTemplate.UseTrainerFlag/1 cs:54-54*/
        usedTrainerFlags.add(flag)
    }
    fun isTrainerFlagInUse(flag: Int): Boolean { /*@DONE EventTemplate.IsTrainerFlagInUse/1 cs:55-55*/
        return usedTrainerFlags.contains(flag)
    }
    private val trainerPreferences: Map<Int, TrainerPreference>
        get() { /*@DONE EventTemplate.TrainerPreferences.get cs:58-61*/
            val cached = _trainerPreferences
            if (cached != null) return cached
            val prefs = Flags.getTrainerPreference(model, parser)
            _trainerPreferences = prefs
            return prefs
        }
    private val minLevel: Map<Int, Int>
        get() { /*@DONE EventTemplate.MinLevel.get cs:65-68*/
            val cached = _minLevel
            if (cached != null) return cached
            val levels = Flags.getMinimumLevelForPokemon(model)
            _minLevel = levels
            return levels
        }
    lateinit var objectTemplateImage: IPixelViewModel
        private set
    var overworldGraphics: List<IPixelViewModel> = ArrayList()
        private set
    constructor(dispatcher: IWorkDispatcher, model: IDataModel, parser: ScriptParser, owGraphics: List<IPixelViewModel>) { /*@DONE EventTemplate.<init>/1 cs:75-97*/
        this.model = model
        this.parser = parser
        refreshLists(owGraphics)
        if (model.isFRLG()) useNationalDex = true

        hmObjectOptions.add("Cut Tree")
        hmObjectOptions.add("Smash Rock")
        hmObjectOptions.add("Strength Boulder")
        trainerOptions.bind("selectedIndex") { options, args ->
            val trainerTable = model.getTableModel(HardcodeTablesModel.trainerTableName)
            val index = trainerOptions.selectedIndex
            if (trainerTable != null && index >= 0 && index < trainerTable.size) {
                val targetSprite = trainerTable[index].getValue("sprite")
                for (key in trainerPreferences.keys) {
                    if (trainerPreferences[key]!!.sprite != targetSprite) continue
                    trainerGraphics = key
                    break
                }
            }
        }

        initializationWorkload = dispatcher.runBackgroundWork {
            _usedFlags = Flags.getUsedItemFlags(model, parser)
            _usedTrainerFlags = Flags.getUsedTrainerFlags(model, parser)
            _usedVariables = Flags.getUsedVariables(model, parser)
        }
    }
    fun refreshLists(owGraphics: List<IPixelViewModel>) { /*@DONE EventTemplate.RefreshLists/1 cs:99-143*/
        overworldGraphics = owGraphics
        availableTemplateTypes.clear()
        availableTemplateTypes.add(TemplateType.None)
        availableTemplateTypes.add(TemplateType.Npc)
        availableTemplateTypes.add(TemplateType.Item)
        availableTemplateTypes.add(TemplateType.Trainer)
        availableTemplateTypes.add(TemplateType.Mart)
        availableTemplateTypes.add(TemplateType.Trade)
        if (model.isFRLG() || model.isEmerald()) availableTemplateTypes.add(TemplateType.Tutor) // Ruby/Sapphire don't have tutors
        availableTemplateTypes.add(TemplateType.Legendary)
        availableTemplateTypes.add(TemplateType.HMObject)

        graphicsOptions.clear()
        for (i in 0 until owGraphics.size) graphicsOptions.add(VisualComboOption.createFromSprite(i.toString(), owGraphics[i].pixelData, owGraphics[i].pixelWidth, i, 2.0, true))

        typeOptions.clear()
        val types = model.getTableModel(HardcodeTablesModel.typesTableName)
        if (types != null) {
            for (type in types) {
                typeOptions.add(type.getStringValue("name"))
            }
        }

        itemOptions.clear()
        val items = model.getTableModel(HardcodeTablesModel.itemsTableName)
        if (items != null) {
            for (item in items) {
                itemOptions.add(item.getStringValue("name"))
            }
        }

        val trainerOptionList = ArrayList<ComboOption>()
        val trainers = model.getTableModel(HardcodeTablesModel.trainerTableName)
        val trainerClasses = model.getTableModel(HardcodeTablesModel.trainerClassNamesTable)
        if (trainers != null && trainerClasses != null) {
            val options = model.getOptions(HardcodeTablesModel.trainerClassNamesTable)
            for (i in 0 until trainers.size) {
                trainerOptionList.add(ObjectEventViewModel.createOption(options, i, trainers[i].getValue(1), trainers[i].getStringValue("name")))
            }
        }
        this.trainerOptions.update(trainerOptionList, this.trainerOptions.selectedIndex)

        updateObjectTemplateImage()
    }
    private var _selectedTemplate: TemplateType = TemplateType.None
    var selectedTemplate: TemplateType
        get() { /*@DONE EventTemplate.SelectedTemplate.get cs:147-147*/
            return _selectedTemplate
        }
        set(value) { /*@DONE EventTemplate.SelectedTemplate.set cs:148-151*/
            set(_selectedTemplate, value, "selectedTemplate", { _selectedTemplate = it }) { old -> updateObjectTemplateImage(old) }
            if (_selectedTemplate == TemplateType.HMObject) updateSpriteFromHMObject()
        }
    var availableTemplateTypes: ObservableCollection<TemplateType> = /*@INITDONE EventTemplate.AvailableTemplateTypes cs:154-154*/ ObservableCollection() /*@ENDINIT*/
        private set
    override fun findNextUnusedFlag(): Int { /*@DONE EventTemplate.FindNextUnusedFlag/1 cs:156-161*/
        var flag = 0x21
        while (usedFlags.contains(flag)) flag++
        usedFlags.add(flag)
        return flag
    }
    override fun findNextUnusedVariable(): Int { /*@DONE EventTemplate.FindNextUnusedVariable/1 cs:163-168*/
        var variable = 0x4034
        while (usedVariables.contains(variable)) variable++
        usedVariables.add(variable)
        return variable
    }
    fun applyTemplate(objectEventModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.ApplyTemplate/1 cs:170-179*/
        if (_selectedTemplate == TemplateType.Trainer) createTrainer(objectEventModel, token)
        if (_selectedTemplate == TemplateType.Npc) createNPC(objectEventModel, token)
        if (_selectedTemplate == TemplateType.Item) createItem(objectEventModel, token)
        if (_selectedTemplate == TemplateType.Mart) createMart(objectEventModel, token)
        if (_selectedTemplate == TemplateType.Tutor) createTutor(objectEventModel, token)
        if (_selectedTemplate == TemplateType.Trade) createTrade(objectEventModel, token)
        if (_selectedTemplate == TemplateType.Legendary) createLegendary(objectEventModel, token)
        if (_selectedTemplate == TemplateType.HMObject) createHMObject(objectEventModel, token)
    }
    var graphicsOptions: ObservableCollection<VisualComboOption> = /*@INITDONE EventTemplate.GraphicsOptions cs:183-183*/ ObservableCollection() /*@ENDINIT*/
        private set
    var typeOptions: ObservableCollection<String> = /*@INITDONE EventTemplate.TypeOptions cs:184-184*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _useExistingTrainer: Boolean = false
    var useExistingTrainer: Boolean
        get() { /*@DONE EventTemplate.UseExistingTrainer.get cs:187-187*/
            return _useExistingTrainer
        }
        set(value) { /*@DONE EventTemplate.UseExistingTrainer.set cs:187-187*/
            tryUpdate(_useExistingTrainer, value, "useExistingTrainer") { _useExistingTrainer = it }
        }
    var trainerOptions: FilteringComboOptions = /*@INITDONE EventTemplate.TrainerOptions cs:189-189*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    private var _trainerGraphics: Int = 0
    private var _maxPokedex: Int = /*@INITAUTO EventTemplate.maxPokedex cs:191-191*/ 25 /*@ENDINIT*/
    private var _maxLevel: Int = /*@INITAUTO EventTemplate.maxLevel cs:191-191*/ 9 /*@ENDINIT*/
    private var _preferredType: Int = /*@INITAUTO EventTemplate.preferredType cs:191-191*/ 6 /*@ENDINIT*/
    var trainerGraphics: Int
        get() { /*@DONE EventTemplate.TrainerGraphics.get cs:193-193*/
            return _trainerGraphics
        }
        set(value) { /*@DONE EventTemplate.TrainerGraphics.set cs:194-203*/
            set(_trainerGraphics, value, "trainerGraphics", { _trainerGraphics = it }) { old ->
                val pref = trainerPreferences[_trainerGraphics] ?: TrainerPreference(0, 0, 0)
                val spriteTable = model.getTableModel(HardcodeTablesModel.trainerSpritesName)
                var spriteRun: ISpriteRun? = null
                if (spriteTable != null && pref.sprite >= 0 && pref.sprite < spriteTable.size) {
                    val spriteAddress = spriteTable[pref.sprite].getAddress("sprite")
                    spriteRun = model.getNextRun(spriteAddress) as? ISpriteRun
                }
                trainerSprite = ReadonlyPixelViewModel.create(model, spriteRun, true)
                notifyPropertyChanged("trainerSprite")
                updateObjectTemplateImage()
            }
        }
    var maxPokedex: Int
        get() { /*@DONE EventTemplate.MaxPokedex.get cs:205-205*/
            return _maxPokedex
        }
        set(value) { /*@DONE EventTemplate.MaxPokedex.set cs:205-205*/
            tryUpdate(_maxPokedex, value, "maxPokedex") { _maxPokedex = it }
        }
    var maxLevel: Int
        get() { /*@DONE EventTemplate.MaxLevel.get cs:206-206*/
            return _maxLevel
        }
        set(value) { /*@DONE EventTemplate.MaxLevel.set cs:206-206*/
            tryUpdate(_maxLevel, value, "maxLevel") { _maxLevel = it }
        }
    var preferredType: Int
        get() { /*@DONE EventTemplate.PreferredType.get cs:207-207*/
            return _preferredType
        }
        set(value) { /*@DONE EventTemplate.PreferredType.set cs:207-207*/
            tryUpdate(_preferredType, value, "preferredType") { _preferredType = it }
        }
    private var _useNationalDex: Boolean = false
    var useNationalDex: Boolean
        get() { /*@DONE EventTemplate.UseNationalDex.get cs:210-210*/
            return _useNationalDex
        }
        set(value) { /*@DONE EventTemplate.UseNationalDex.set cs:210-210*/
            tryUpdate(_useNationalDex, value, "useNationalDex") { _useNationalDex = it }
        }
    var trainerSprite: IPixelViewModel? = null
        private set
    fun createTrainer(objectEventModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateTrainer/1 cs:216-316*/
        val chosenTypeOddsMultiplier = 100

        val trainers = model.getTableModel(HardcodeTablesModel.trainerTableName, { token })
        if (trainers == null) return
        var trainerFlag = 1
        if (useExistingTrainer) {
            trainerFlag = trainerOptions.selectedIndex
            usedTrainerFlags.add(trainerFlag)
        } else {
            // part 1: the team
            val availablePokemon = ArrayList<Int>()
            var dexName = HardcodeTablesModel.regionalDexTableName
            if (_useNationalDex) dexName = HardcodeTablesModel.nationalDexTableName
            val pokedex = model.getTableModel(dexName, { token })
            if (pokedex == null) return
            val pokestats = model.getTableModel(HardcodeTablesModel.pokemonStatsTable, { token })
            for (i in 1 until pokedex.size) {
                if (pokedex[i - 1].getValue(0) > _maxPokedex) continue
                val minimum = minLevel[i]
                if (minimum != null && minimum > _maxLevel) continue
                availablePokemon.add(i)
                if (pokestats != null && i < pokestats.size) {
                    if (pokestats[i].getValue("type1") == _preferredType || pokestats[i].getValue("type2") == _preferredType) {
                        for (j in 0 until chosenTypeOddsMultiplier) availablePokemon.add(i)
                    }
                }
            }

            val teamSize = rnd.nextInt(3) + 1
            val teamStart = model.findFreeSpace(model.freeSpaceStart, 8 * teamSize)
            if (availablePokemon.size == 0) availablePokemon.add(1)
            for (i in 0 until teamSize) {
                // ivSpread: level: mon: padding:
                val pokemon = availablePokemon[rnd.nextInt(availablePokemon.size)]
                var level = _maxLevel
                while (level > _maxLevel - 5 && rnd.nextInt(2) == 1) level--
                model.writeMultiByteValue(teamStart + i * 8 + 0, 2, token, 0)
                model.writeMultiByteValue(teamStart + i * 8 + 2, 2, token, level)
                model.writeMultiByteValue(teamStart + i * 8 + 4, 2, token, pokemon)
                model.writeMultiByteValue(teamStart + i * 8 + 6, 2, token, 0)
            }

            // part 2: the trainer
            while (usedTrainerFlags.contains(trainerFlag)) trainerFlag++
            usedTrainerFlags.add(trainerFlag)

            val trainer = trainers[trainerFlag]
            // structType. class. introMusicAndGender. sprite. name""12 item1: item2: item3: item4: doubleBattle:: ai:: pokemonCount:: pokemon<>
            trainer.setValue("structType", 0)
            trainer.setStringValue("name", "NAME ME")
            trainer.setValue("item1", 0)
            trainer.setValue("item2", 0)
            trainer.setValue("item3", 0)
            trainer.setValue("item4", 0)
            trainer.setValue("doubleBattle", 0)
            trainer.setValue("ai", 0)
            trainer.setValue("pokemonCount", teamSize)
            trainer.setAddress("pokemon", teamStart)
            val pref = trainerPreferences[_trainerGraphics] ?: TrainerPreference(0, 0, 0)
            trainer.setValue("class", pref.trainerClass)
            trainer.setValue("introMusicAndGender", pref.musicAndGender)
            trainer.setValue("sprite", pref.sprite)
        }

        // part 3: the script
        /*
             trainerbattle 00 102 0 <before> <during>
             loadpointer 0 <after>
             callstd 6
             end
         */
        //       2                  6       10          16
        // 5C 00 trainerFlag: 00 00 <before> <win> 0F 00 <after> 09 06 02
        val before = writeText(token, "Let's battle!")
        val win = writeText(token, "You Win!")
        val after = writeText(token, "Post-battle chat!")
        val scriptStart = model.findFreeSpace(model.freeSpaceStart, 24)
        token.changeData(model, scriptStart, "5C 00 00 00 00 00 00 00 00 00 00 00 00 00 0F 00 00 00 00 00 09 06 02 00".parseHexBytes().asByteList())
        model.writeMultiByteValue(scriptStart + 2, 2, token, trainerFlag)
        model.writePointer(token, scriptStart + 6, before)
        model.writePointer(token, scriptStart + 10, win)
        model.writePointer(token, scriptStart + 16, after)
        model.observeRunWritten(token, PointerRun(scriptStart + 6))
        model.observeRunWritten(token, PointerRun(scriptStart + 10))
        model.observeRunWritten(token, PointerRun(scriptStart + 16))
        val factory = PCSRunContentStrategy()
        factory.tryAddFormatAtDestination(model, token, scriptStart + 6, before, "", null, 0)
        factory.tryAddFormatAtDestination(model, token, scriptStart + 10, win, "", null, 0)
        factory.tryAddFormatAtDestination(model, token, scriptStart + 16, after, "", null, 0)

        // part 4: the event
        objectEventModel.graphics = _trainerGraphics
        objectEventModel.elevation = findPreferredTrainerElevation(model, _trainerGraphics)
        objectEventModel.moveType = intArrayOf(7, 8, 9, 10)[rnd.nextInt(4)]
        objectEventModel.rangeX = 1
        objectEventModel.rangeY = 1
        objectEventModel.trainerType = 1
        objectEventModel.trainerRangeOrBerryID = 5
        objectEventModel.scriptAddress = scriptStart
        objectEventModel.flag = 0
        objectEventModel.refreshTrainerOptions()

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(objectEventModel.start + 16)))
    }
    private fun findPreferredTrainerElevation(model: IDataModel, graphics: Int): Int { /*@DONE EventTemplate.FindPreferredTrainerElevation/1 cs:318-333*/
        val histogram = HashMap<Int, Int>()
        val banks = AllMapsModel.create(model, null)
        for (bank in banks) {
            for (map in bank) {
                if (map == null) continue
                for (obj in map.events.objects ?: ArrayList<ObjectEventModel>()) {
                    if (obj.graphics != graphics) continue
                    if (!histogram.containsKey(obj.elevation)) histogram[obj.elevation] = 0
                    histogram[obj.elevation] = histogram[obj.elevation]!! + 1
                }
            }
        }
        return if (histogram.isEmpty()) 0 else histogram.mostCommonKey()
    }
    fun getTrainerContent(eventModel: IEventViewModel): TrainerEventContent? { /*@DONE EventTemplate.GetTrainerContent/1 cs:335-335*/
        return getTrainerContent(model, eventModel)
    }
    fun createNPC(eventModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateNPC/1 cs:394-414*/
        // loadpointer 0 <text>; callstd 2; end; text="I'm an NPC!"
        // 0F 00 <text> 09 02 02 "I'm an NPC!"
        val scriptStart = model.findFreeSpace(model.freeSpaceStart, 24)
        token.changeData(model, scriptStart, "0F 00 00 00 00 00 09 02 02 C3 B4 E1 00 D5 E2 00 C8 CA BD AB FF".parseHexBytes().asByteList())
        model.writePointer(token, scriptStart + 2, scriptStart + 9)
        model.observeRunWritten(token, PointerRun(scriptStart + 2))
        val factory = PCSRunContentStrategy()
        factory.tryAddFormatAtDestination(model, token, scriptStart + 2, scriptStart + 9, "", null, 0)

        eventModel.graphics = _trainerGraphics
        eventModel.elevation = 3
        eventModel.moveType = 2
        eventModel.rangeXY = "(3, 3)"
        eventModel.trainerType = 0
        eventModel.trainerRangeOrBerryID = 0
        eventModel.scriptAddress = scriptStart
        eventModel.flag = 0

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(eventModel.start + 16)))
    }
    fun getNPCTextPointer(eventModel: IEventViewModel): Int { /*@DONE EventTemplate.GetNPCTextPointer/1 cs:416-416*/
        return getNPCTextPointer(model, eventModel)
    }
    var itemOptions: ObservableCollection<String> = /*@INITDONE EventTemplate.ItemOptions cs:439-439*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _itemID: Int = /*@INITAUTO EventTemplate.itemID cs:441-441*/ 20 /*@ENDINIT*/
    var itemID: Int
        get() { /*@DONE EventTemplate.ItemID.get cs:442-442*/
            return _itemID
        }
        set(value) { /*@DONE EventTemplate.ItemID.set cs:442-442*/
            tryUpdate(_itemID, value, "itemID") { _itemID = it }
        }
    fun createItem(objectEventModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateItem/1 cs:444-466*/
        //   copyvarifnotzero 0x8000 item:
        //   copyvarifnotzero 0x8001 1
        //   callstd 1
        //   end
        //                     item:
        val script = "1A 00 80 00 00 1A 01 80 01 00 09 01 02".parseHexBytes()
        val scriptStart = model.findFreeSpace(model.freeSpaceStart, script.size)
        token.changeData(model, scriptStart, script.asByteList())
        model.writeMultiByteValue(scriptStart + 3, 2, token, _itemID)

        val itemFlag = findNextUnusedFlag()

        objectEventModel.graphics = itemGraphics
        objectEventModel.elevation = 3
        objectEventModel.moveType = 8
        objectEventModel.rangeX = 1
        objectEventModel.rangeY = 1
        objectEventModel.trainerType = 0
        objectEventModel.trainerRangeOrBerryID = 0
        objectEventModel.scriptAddress = scriptStart
        objectEventModel.flag = itemFlag

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(objectEventModel.start + 16)))
    }
    fun getItemAddress(eventModel: IEventViewModel): Int { /*@DONE EventTemplate.GetItemAddress/1 cs:468-468*/
        return getItemAddress(model, eventModel)
    }
    private val itemGraphics: Int
        get() { /*@DONE EventTemplate.ItemGraphics.get cs:497-497*/
            return if (model.isFRLG()) 92 else 59
        }
    fun applyTemplate(signpost: SignpostEventViewModel?, token: ModelDelta) { /*@DONE EventTemplate.ApplyTemplate/2 cs:503-521*/
        if (signpost == null) return
        signpost.elevation = 0
        signpost.kind = 0

        // loadpointer 0 <text>; callstd 3; end; text="Signpost Text"
        // 0F 00 <text> 09 03 02 "Signpost Text"
        val scriptStart = model.findFreeSpace(model.freeSpaceStart, 24)
        token.changeData(model, scriptStart, "0F 00 00 00 00 00 09 03 02 CD DD DB E2 E4 E3 E7 E8 00 CE D9 EC E8 FF".parseHexBytes().asByteList())
        model.writePointer(token, scriptStart + 2, scriptStart + 9)
        model.observeRunWritten(token, PointerRun(scriptStart + 2))
        val factory = PCSRunContentStrategy()
        factory.tryAddFormatAtDestination(model, token, scriptStart + 2, scriptStart + 9, "", null, 0)

        // this XSE run has no pointer source, because the signpost Arg isn't always a pointer.
        model.observeRunWritten(token, XSERun(scriptStart, SortedSpan.none<Int>()))

        signpost.pointer = scriptStart
    }
    fun getSignpostTextPointer(eventModel: IEventViewModel): Int { /*@DONE EventTemplate.GetSignpostTextPointer/1 cs:523-523*/
        return getSignpostTextPointer(model, eventModel)
    }
    private val clerkGraphics: Int
        get() { /*@DONE EventTemplate.ClerkGraphics.get cs:546-546*/
            return if (model.isFRLG()) 68 else 83
        }
    fun createMart(objectEventViewModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateMart/1 cs:548-579*/
        // FireRed template:
        // lock faceplayer preparemsg   waitmsg pokemart          loadpointer 0 msg   callstd 4   release end
        // 6A  5A  67  11 62 1A 08      66      86 08 A7 16 08    0F 00 90 51 1A 08   09 04       6C 02
        // 0x20 bytes total
        //                      <pointer>         <pointer>         <pointer>               pokeball/potion/antidote
        val script = "6A 5A 67 00 00 00 00 66 86 00 00 00 00 0F 00 00 00 00 00 09 04 6C 02 FF 04 00 0D 00 0E 00 00 00".parseHexBytes()
        // 3 pointer to start text
        // 9 pointer to mart
        // 15 pointer to end text
        // 24 start of mart data

        val hello = writeText(token, "Hi, there!\\nMay I help you?")
        val goodbye = writeText(token, "Please come again!")

        val scriptStart = model.findFreeSpace(model.freeSpaceStart, script.size)
        token.changeData(model, scriptStart, script.asByteList())
        model.writePointer(token, scriptStart + 3, hello)
        model.writePointer(token, scriptStart + 9, scriptStart + 24)
        model.writePointer(token, scriptStart + 15, goodbye)

        objectEventViewModel.graphics = clerkGraphics
        objectEventViewModel.elevation = 3
        objectEventViewModel.moveType = 10
        objectEventViewModel.rangeX = 0
        objectEventViewModel.rangeY = 0
        objectEventViewModel.trainerType = 0
        objectEventViewModel.trainerRangeOrBerryID = 0
        objectEventViewModel.flag = 0
        objectEventViewModel.scriptAddress = scriptStart

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(objectEventViewModel.start + 16)))
        parser.writeMartStream(model, token, scriptStart + 24, scriptStart + 9)
        for (offset in intArrayOf(3, 9, 15)) model.observeRunWritten(token, PointerRun(scriptStart + offset))
    }
    fun getMartContent(eventModel: ObjectEventViewModel): MartEventContent? { /*@DONE EventTemplate.GetMartContent/1 cs:581-581*/
        return getMartContent(model, parser, eventModel)
    }
    fun createTutor(objectEventViewModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateTutor/1 cs:608-696*/
        /* pseudo code:
         *    if flag: goto end
         *    print "forward text" -> yes/no
         *    if no:   goto failed
         *    print "only can learn once!" -> yes/no
         *    if no:   goto failed
         *    print "which pokemon will learn?"
         *    ChooseMonForMoveTutor
         *    if no:   goto failed
         *    setflag
         * end:
         *    print "done text"
         *    end
         * failed:
         *    print "failed text"
         *    end
         */

        val tutorFlag = findNextUnusedFlag()

        val tutor = 0
        val infoStart = writeText(token, "Want to learn a cool move?")
        val warningStart = writeText(token, "This move can be learned only\\nonce. Is that okay?")
        val whichStart = writeText(token, "Which POK\u00e9MON wants to learn\\nthe move?")
        val doneStart = writeText(token, "Enjoy the move!")
        val failedStart = writeText(token, "I guess not.")
        val fr = model.isFRLG()

        val script = """
           lock
           faceplayer
           checkflag ${tutorFlag}
           if1 = <success>
           loadpointer 0 <${infoStart.toHex(6)}>
           callstd 5
           compare 0x800D 0
           if1 = <failed>
           ${if (fr) "textcolor 3" else ""}
           ${if (fr) "special DisableMsgBoxWalkaway" else ""}
           ${if (fr) "signmsg" else ""}
           loadpointer 0 <${warningStart.toHex(6)}>
           callstd 5
           ${if (fr) "normalmsg" else ""}
           copyvar 0x8012 0x8013
           compare 0x800D 0
           if1 = <failed>
           loadpointer 0 <${whichStart.toHex(6)}>
           callstd 4
           setvar 0x8005 ${tutor}
           special ChooseMonForMoveTutor
           waitstate
           lock
           faceplayer
           compare 0x800D 0
           if1 = <failed>
           setflag ${tutorFlag}
        success:
           loadpointer 0 <${doneStart.toHex(6)}>
           callstd 4
           release
           end
        failed:
           loadpointer 0 <${failedStart.toHex(6)}>
           callstd 4
           release
           end
        """
        // script length = 109
        // note that the condition for recognizing the `warningStart` message is different in
        // the Emerald case, since there's no `signmsg` command to use for reference
        // instead, it's just 0 or 1 pointers, and has `callstd 5` after it.
        // maybe just expect a `callstd 5` after it, since it's the only one after infoStart that has that in both FR and Em

        val scriptStart = model.findFreeSpace(model.freeSpaceStart, 109)
        val content = parser.compileWithoutErrors(token, model, scriptStart, Ref(script))
        if (content != null) token.changeData(model, scriptStart, content.asByteList())

        objectEventViewModel.graphics = _trainerGraphics
        objectEventViewModel.elevation = 3
        objectEventViewModel.moveType = 8
        objectEventViewModel.rangeX = 0
        objectEventViewModel.rangeY = 0
        objectEventViewModel.trainerType = 0
        objectEventViewModel.trainerRangeOrBerryID = 0
        objectEventViewModel.scriptAddress = scriptStart
        objectEventViewModel.flag = 0

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(objectEventViewModel.start + 16)))
        parser.formatScript<XSERun>(token, model, scriptStart)
    }
    fun getTutorContent(parser: ScriptParser, eventModel: ObjectEventViewModel): TutorEventContent? { /*@DONE EventTemplate.GetTutorContent/1 cs:698-698*/
        return getTutorContent(model, parser, eventModel)
    }
    fun createTrade(objectEventViewModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateTrade/1 cs:763-841*/
        val tradeFlag = findNextUnusedFlag()

        val tradeId = 0
        val initialText = writeText(token, "Want to trade your \\\\02\nfor my \\\\03?")
        val thanksText = writeText(token, "Thank you!")
        val successText = writeText(token, "How is my old \\\\03?\\pnYour old \\\\02 is doing great!")
        val failText = writeText(token, "That's too bad.")
        val wrongSpeciesText = writeText(token, "\\.This is no \\\\02.\\pnIf you get one, please trade it\\nfor my \\\\03!")

        val script = """
          lock
          faceplayer
          setvar 0x8008 ${tradeId}
          copyvar 0x8004 0x8008
          special2 0x800D GetInGameTradeSpeciesInfo
          copyvar 0x8009 0x800D
          checkflag ${tradeFlag}
          if1 = <success>
          loadpointer 0 <${initialText.toHex(6)}>
          callstd 5
          compare 0x800D 0
          if1 = <fail>
          special ChoosePartyMon
          waitstate
          lock
          faceplayer
          copyvar 0x800A 0x8004
          compare 0x8004 6
          if1 >= <fail>
          copyvar 0x8005 0x800A
          special2 0x800D GetTradeSpecies
          copyvar 0x800B 0x800D
          comparevars 0x800D 0x8009
          if1 != <wrongspecies>
          copyvar 0x8004 0x8008
          copyvar 0x8005 0x800A
          special CreateInGameTradePokemon
          special DoInGameTradeScene
          waitstate
          lock
          faceplayer
          loadpointer 0 <${thanksText.toHex(6)}>
          callstd 4
          setflag ${tradeFlag}
          release
          end
        success:
          loadpointer 0 <${successText.toHex(6)}>
          callstd 4
          release
          end
        fail:
          loadpointer 0 <${failText.toHex(6)}>
          callstd 4
          release
          end
        wrongspecies:
          loadpointer 0 <${wrongSpeciesText.toHex(6)}>
          callstd 4
          release
          end
        """

        val scriptStart = model.findFreeSpace(model.freeSpaceStart, 160)
        val content = parser.compileWithoutErrors(token, model, scriptStart, Ref(script))
        if (content != null) token.changeData(model, scriptStart, content.asByteList())

        objectEventViewModel.graphics = _trainerGraphics
        objectEventViewModel.elevation = 3
        objectEventViewModel.moveType = 8
        objectEventViewModel.rangeX = 0
        objectEventViewModel.rangeY = 0
        objectEventViewModel.trainerType = 0
        objectEventViewModel.trainerRangeOrBerryID = 0
        objectEventViewModel.scriptAddress = scriptStart
        objectEventViewModel.flag = 0

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(objectEventViewModel.start + 16)))
        parser.formatScript<XSERun>(token, model, scriptStart)
    }
    fun getTradeEventContent(parser: ScriptParser, eventModel: ObjectEventViewModel): TradeEventContent? { /*@DONE EventTemplate.GetTradeEventContent/1 cs:843-843*/
        return getTradeContent(model, parser, eventModel.scriptAddress)
    }
    fun createLegendary(objectEventModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateLegendary/1 cs:899-980*/
        val legendFlag = findNextUnusedFlag()
        val catchFlag = findNextUnusedFlag()

        val cryText = if (model.isFRLG()) writeText(token, "Roar!") else Pointer.null_

        // #region script
        val script = StringBuilder("""
        lock
        faceplayer
        waitsound
        cry 1 2
        setwildbattle 1 50 0
        """)
        if (model.isFRLG()) {
            script.appendLine("preparemsg <${cryText.toHex(6)}>")
            script.appendLine("waitmsg")
        }
        script.appendLine("waitcry")
        script.appendLine("pause 10")
        if (model.isFRLG()) {
            script.appendLine("""
           playsong mus_encounter_gym_leader playOnce
           waitkeypress
           setflag 0x0807
           special 0x138
           waitstate
           clearflag 0x0807
        """)
        } else if (model.isEmerald()) {
            script.appendLine("""
           setflag 0x08C1
           special 0x13B
           waitstate
           clearflag 0x08C1
        """)
        } else {
            script.appendLine("""
           setflag 0x861
           special 0x137
           waitstate
           clearflag 0x861
        """)
        }
        script.appendLine("""
        fadescreen 1
        hidesprite 0x800F
        fadescreen 0
        special2 0x800D GetBattleOutcome
        if.compare.goto 0x800D = 7 <caught>
        bufferPokemon 0 1
        msgbox.default <auto>
        {
        The [buffer1] disappeared!
        }
        release
        end

        caught:
        setflag 0x${catchFlag.toHex(4)}
        release
        end

        """)
        // #endregion

        val scriptStart = model.findFreeSpace(model.freeSpaceStart, 160)
        val scriptText = script.toString()
        val content = parser.compileWithoutErrors(token, model, scriptStart, Ref(scriptText))
        if (content != null) token.changeData(model, scriptStart, content.asByteList())

        objectEventModel.graphics = _trainerGraphics
        objectEventModel.elevation = findPreferredTrainerElevation(model, _trainerGraphics)
        objectEventModel.moveType = 8
        objectEventModel.rangeX = 0
        objectEventModel.rangeY = 0
        objectEventModel.trainerType = 0
        objectEventModel.trainerRangeOrBerryID = 0
        objectEventModel.scriptAddress = scriptStart
        objectEventModel.flag = legendFlag

        model.observeRunWritten(token, XSERun(scriptStart, SortedSpanStatic.one(objectEventModel.start + 16)))
        parser.formatScript<XSERun>(token, model, scriptStart)
    }
    fun getLegendaryEventContent(parser: ScriptParser, eventModel: ObjectEventViewModel): LegendaryEventContent? { /*@DONE EventTemplate.GetLegendaryEventContent/1 cs:982-982*/
        return getLegendaryEventContent(model, parser, eventModel)
    }
    var hmObjectOptions: ObservableCollection<String> = /*@INITDONE EventTemplate.HMObjectOptions cs:1034-1034*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _hmObjectIndex: Int = 0
    var hmObjectIndex: Int
        get() { /*@DONE EventTemplate.HMObjectIndex.get cs:1038-1038*/
            return _hmObjectIndex
        }
        set(value) { /*@DONE EventTemplate.HMObjectIndex.set cs:1039-1042*/
            tryUpdate(_hmObjectIndex, value, "hmObjectIndex") { _hmObjectIndex = it }
            updateSpriteFromHMObject()
        }
    private fun updateSpriteFromHMObject() { /*@DONE EventTemplate.UpdateSpriteFromHMObject/1 cs:1045-1051*/
        if (_hmObjectIndex < 0 || _hmObjectIndex > 2) return
        // FR/LG:  95, 96, 97
        // R/S/EE: 82, 86, 87
        if (model.isFRLG()) trainerGraphics = intArrayOf(95, 96, 97)[_hmObjectIndex]
        else trainerGraphics = intArrayOf(82, 86, 87)[_hmObjectIndex]
    }
    fun createHMObject(objectEventViewModel: ObjectEventViewModel, token: ModelDelta) { /*@DONE EventTemplate.CreateHMObject/1 cs:1053-1069*/
        val scriptAddresses = ArrayList<Int>()
        for (bank in AllMapsModel.create(model, null)) {
            for (map in bank) {
                if (map == null) continue
                for (obj in map.events.objects ?: ArrayList<ObjectEventModel>()) {
                    if (obj.graphics == _trainerGraphics) scriptAddresses.add(obj.scriptAddress)
                }
            }
        }
        val histogram = scriptAddresses.toHistogram()
        val scriptStart = if (histogram.isEmpty()) 0 else histogram.mostCommonKey()

        objectEventViewModel.graphics = _trainerGraphics
        objectEventViewModel.elevation = 3
        objectEventViewModel.moveType = 8
        objectEventViewModel.rangeX = 0
        objectEventViewModel.rangeY = 0
        objectEventViewModel.trainerType = 0
        objectEventViewModel.trainerRangeOrBerryID = 0
        objectEventViewModel.scriptAddress = scriptStart
        objectEventViewModel.flag = (objectEventViewModel.objectID % 0x10) + 0x10
    }
    private fun writeText(token: ModelDelta, text: String): Int { /*@DONE EventTemplate.WriteText/1 cs:1081-1086*/
        val bytes = model.textConverter.convert(text, Ref(false)) ?: ArrayList<Int>()
        val start = model.findFreeSpace(model.freeSpaceStart, bytes.size)
        token.changeData(model, start, bytes.toByteArrayU().asByteList())
        return start
    }
    private fun updateObjectTemplateImage(old: TemplateType = TemplateType.None) { /*@DONE EventTemplate.UpdateObjectTemplateImage/1 cs:1088-1103*/
        if (_selectedTemplate == TemplateType.None) {
            objectTemplateImage = graphicOption(0)
        } else if (_selectedTemplate.isAny(TemplateType.Trainer, TemplateType.Npc, TemplateType.Tutor, TemplateType.Trade, TemplateType.Legendary, TemplateType.HMObject)) {
            objectTemplateImage = graphicOption(_trainerGraphics)
        } else if (_selectedTemplate == TemplateType.Item) {
            objectTemplateImage = graphicOption(itemGraphics)
        } else if (_selectedTemplate == TemplateType.Mart) {
            objectTemplateImage = graphicOption(clerkGraphics)
        }
        if (objectTemplateImage.pixelData.size > 0) {
            objectTemplateImage = ReadonlyPixelViewModel(objectTemplateImage.pixelWidth, objectTemplateImage.pixelHeight, objectTemplateImage.pixelData, objectTemplateImage.pixelData[0])
        }
        objectTemplateImage = objectTemplateImage.autoCrop()
        notifyPropertyChanged("objectTemplateImage")
    }
    companion object {
        fun getTrainerContent(model: IDataModel, eventModel: IEventViewModel): TrainerEventContent? { /*@DONE EventTemplate.GetTrainerContent/2 cs:336-369*/
            if (eventModel !is ObjectEventViewModel) return null
            val address = eventModel.scriptAddress
            if (address < 0) return null
            // 5C 00 trainerFlag: 00 00 <before> <win> 0F 00 <after> 09 06 02
            val expectedValues = linkedMapOf(0 to 0x5C, 1 to 0x00, 4 to 0x00, 5 to 0x00, 14 to 0x0F, 15 to 0x00, 20 to 0x09, 21 to 0x06, 22 to 0x02)
            if (address >= model.count - expectedValues.size) return null
            for ((k, v) in expectedValues) {
                if (model[address + k] != v) return null
            }
            val trainerID = model.readMultiByteValue(address + 2, 2)
            if (trainerID < 0) return null
            val trainers = model.getTableModel(HardcodeTablesModel.trainerTableName, null)
            if (trainers == null || trainerID >= trainers.size) return null

            val beforePointer = address + 6
            val winPointer = address + 10
            val afterPointer = address + 16
            val trainerClassAddress = trainers[trainerID].start + 1
            val trainerNameAddress = trainers[trainerID].start + 4
            val teamPointer = trainers[trainerID].start + 36

            return TrainerEventContent(beforePointer, winPointer, afterPointer, trainerClassAddress, trainerID, address + 2, trainerNameAddress, teamPointer)
        }
        fun getRematchTrainerContent(model: IDataModel, parser: ScriptParser, eventModel: ObjectEventViewModel): RematchTrainerEventContent? { /*@DONE EventTemplate.GetRematchTrainerContent/1 cs:375-388*/
            if (eventModel.scriptAddress < 0) return null
            val spots = Flags.getAllScriptSpots(model, parser, listOf(eventModel.scriptAddress), 0x5C).toList()
            val rematches = spots.filter { spot -> model[spot.address + 1].isAny(5, 7) }
            val trainers = spots.map { spot -> model.readMultiByteValue(spot.address + 2, 2) }.distinct()
            if (rematches.size != 1 || trainers.size != 1) return null
            val beforeTextStart = model.readPointer(rematches[0].address + 6)
            val winTextStart = model.readPointer(rematches[0].address + 10)

            val textSpot = Flags.getAllScriptSpots(model, parser, listOf(eventModel.scriptAddress), 0x0F).firstOrNull()
            val afterTextStart = if (textSpot != null) model.readPointer(textSpot.address + 2) else Pointer.null_

            return RematchTrainerEventContent(trainers[0], beforeTextStart, winTextStart, afterTextStart)
        }
        fun getNPCTextPointer(model: IDataModel, eventModel: IEventViewModel): Int { /*@DONE EventTemplate.GetNPCTextPointer/2 cs:417-433*/
            if (eventModel !is ObjectEventViewModel) return Pointer.null_
            val address = eventModel.scriptAddress
            if (address < 0) return Pointer.null_
            val expectedValues = linkedMapOf(0 to 0x0F, 1 to 0x00, 6 to 0x09, 7 to 0x02, 8 to 0x02)
            if (address >= model.count - expectedValues.size) return Pointer.null_
            for ((k, v) in expectedValues) {
                if (model[address + k] != v) return Pointer.null_
            }
            return address + 2
        }
        fun getItemAddress(model: IDataModel, eventModel: IEventViewModel): Int { /*@DONE EventTemplate.GetItemAddress/2 cs:469-473*/
            if (eventModel !is ObjectEventViewModel) return Pointer.null_
            val address = eventModel.scriptAddress
            return getItemAddress(model, address)
        }
        fun getItemAddress(model: IDataModel, address: Int): Int { /*@DONE EventTemplate.GetItemAddress/3 cs:475-495*/
            if (address < 0) return Pointer.null_
            // 1A 00 80 item: 1A 01 80 01 00 09 01 02
            val expectedValues = linkedMapOf(0 to 0x1A, 1 to 0x00, 2 to 0x80, 5 to 0x1A, 6 to 0x01, 7 to 0x80, 8 to 0x01, 9 to 0x00, 10 to 0x09, 11 to 0x01)
            if (address >= model.count - expectedValues.size) return Pointer.null_
            for ((k, v) in expectedValues) {
                if (model[address + k] != v) return Pointer.null_
            }
            return address + 3
        }
        fun getSignpostTextPointer(model: IDataModel, eventModel: IEventViewModel): Int { /*@DONE EventTemplate.GetSignpostTextPointer/2 cs:524-540*/
            if (eventModel !is SignpostEventViewModel) return Pointer.null_
            if (!eventModel.showPointer) return Pointer.null_
            val address = eventModel.pointer
            val expectedValues = linkedMapOf(0 to 0x0F, 1 to 0x00, 6 to 0x09, 7 to 0x03, 8 to 0x02)
            for ((k, v) in expectedValues) {
                if (address + k < 0 || address + k >= model.count) return Pointer.null_
                if (model[address + k] != v) return Pointer.null_
            }
            return address + 2
        }
        fun getMartContent(model: IDataModel, parser: ScriptParser, eventViewModel: ObjectEventViewModel): MartEventContent? { /*@DONE EventTemplate.GetMartContent/2 cs:582-602*/
            val spots = Flags.getAllScriptSpots(model, parser, listOf(eventViewModel.scriptAddress), 0x67, 0x86, 0x0F) // preparemsg, pokemart, loadpointer
            // look for the first preparemsg, then the first pokemart, then the first loadpointer
            val results = spots.iterator()
            if (!results.hasNext()) return null
            val messageStart = results.next()
            if (model[messageStart.address] != 0x67) return null
            if (!results.hasNext()) return null
            val martStart = results.next()
            if (model[martStart.address] != 0x86) return null
            if (!results.hasNext()) return null
            val loadStart = results.next()
            if (model[loadStart.address] != 0x0F) return null
            val messageAddress = model.readPointer(messageStart.address + 1)
            val martAddress = model.readPointer(martStart.address + 1)
            val loadAddress = model.readPointer(loadStart.address + 2)
            if (messageAddress < 0 || messageAddress >= model.count) return null
            if (martAddress < 0 || martAddress >= model.count) return null
            if (loadAddress < 0 || loadAddress >= model.count) return null
            return MartEventContent(messageStart.address + 1, martStart.address + 1, loadStart.address + 2)
        }
        fun getTutorContent(model: IDataModel, parser: ScriptParser, eventViewModel: ObjectEventViewModel): TutorEventContent? { /*@DONE EventTemplate.GetTutorContent/2 cs:699-757*/
            // tutors must have a `special ChooseMonForMoveTutor`
            val specialsRef = Ref<ValidationList?>(null)
            if (!model.tryGetList("specials", specialsRef)) return null
            val specials = specialsRef.value!!
            val tutorSpecial = specials.indexOf("ChooseMonForMoveTutor")
            if (tutorSpecial == -1) return null
            if (!Flags.getAllScriptSpots(
                model, parser, listOf(eventViewModel.scriptAddress), 0x25
            ).any { spot -> model.readMultiByteValue(spot.address + 1, 2) == tutorSpecial }
            ) return null

            var content = TutorEventContent(Pointer.null_, Pointer.null_, Pointer.null_, Pointer.null_, Pointer.null_)
            val spots = Flags.getAllScriptSpots(model, parser, listOf(eventViewModel.scriptAddress), 0x16, 0x0F) // setvar, loadpointer

            for (spot in spots) {
                if (model[spot.address] == 0x16) {
                    if (content.tutorAddress != Pointer.null_) return null
                    if (model.readMultiByteValue(spot.address + 1, 2) != 0x8005) return null
                    content = content.copy(tutorAddress = spot.address + 3)
                    continue
                }
                if (content.infoPointer == Pointer.null_) {
                    content = content.copy(infoPointer = spot.address + 2)
                    if (!goodPointer(model, spot.address + 2)) return null
                    continue
                }
                if (model[spot.address + 6] == 9 && model[spot.address + 7] == 5) continue // skip warningpointer (has a `callstd 5` after it)

                // it's either which, success, or fail. We can tell by the number of pointers
                val run = model.getNextRun(spot.address)
                if (run == null) return null
                if (spot.address != run.start) {
                    // 0 pointers -> WhichPokemon
                    if (content.whichPokemonPointer != Pointer.null_) return null
                    content = content.copy(whichPokemonPointer = spot.address + 2)
                    if (!goodPointer(model, spot.address + 2)) return null
                    continue
                }
                val sources = run.pointerSources
                if (sources == null) return null
                if (sources.size == 3) {
                    // 3 pointers -> Failed
                    if (content.failedPointer != Pointer.null_) return null
                    content = content.copy(failedPointer = spot.address + 2)
                    if (!goodPointer(model, spot.address + 2)) return null
                    continue
                }
                if (sources.size.isAny(1, 2)) {
                    // 1 or 2 pointers -> Success
                    if (content.successPointer == spot.address + 2) continue
                    if (content.successPointer != Pointer.null_) return null
                    content = content.copy(successPointer = spot.address + 2)
                    if (!goodPointer(model, spot.address + 2)) return null
                    continue
                }
                return null
            }

            if (Pointer.null_.isAny(content.infoPointer, content.whichPokemonPointer, content.successPointer, content.failedPointer, content.tutorAddress)) return null
            return content
        }
        fun getTradeContent(model: IDataModel, parser: ScriptParser, scriptAddress: Int): TradeEventContent? { /*@DONE EventTemplate.GetTradeContent/1 cs:844-893*/
            // tardes must have a `special CreateInGameTradePokemon`
            val specialsRef = Ref<ValidationList?>(null)
            if (!model.tryGetList("specials", specialsRef)) return null
            val specials = specialsRef.value!!
            val tradeSpecial = specials.indexOf("CreateInGameTradePokemon")
            if (tradeSpecial == -1) return null
            if (!Flags.getAllScriptSpots(
                model, parser, listOf(scriptAddress), 0x25
            ).any { spot -> model.readMultiByteValue(spot.address + 1, 2) == tradeSpecial }
            ) return null

            var content = TradeEventContent(Pointer.null_, Pointer.null_, Pointer.null_, Pointer.null_, Pointer.null_, Pointer.null_)
            val spots = Flags.getAllScriptSpots(model, parser, listOf(scriptAddress), 0x16, 0x0F) // setvar, loadpointer

            for (spot in spots) {
                // TradeAddress is the only `setvar 0x8008` command
                if (model[spot.address] == 0x16) {
                    if (model.readMultiByteValue(spot.address + 1, 2) != 0x8008) continue
                    if (content.tradeAddress != Pointer.null_) return null
                    content = content.copy(tradeAddress = spot.address + 3)
                    continue
                }

                // loadpointer InfoPointer is right before callstd 5
                if (model[spot.address + 7] == 5) {
                    if (content.infoPointer != Pointer.null_) return null
                    content = content.copy(infoPointer = spot.address + 2)
                    continue
                }

                // ThanksPointer, SuccessPointer, FailedPointer, and WrongSpecies all look exactly the same, but come in that order
                if (content.thanksPointer == Pointer.null_) {
                    content = content.copy(thanksPointer = spot.address + 2)
                    continue
                } else if (content.successPointer == Pointer.null_) {
                    content = content.copy(successPointer = spot.address + 2)
                    continue
                } else if (content.failedPointer == Pointer.null_) {
                    content = content.copy(failedPointer = spot.address + 2)
                    continue
                } else if (content.wrongSpeciesPointer == Pointer.null_) {
                    content = content.copy(wrongSpeciesPointer = spot.address + 2)
                    continue
                }
                return null
            }

            if (Pointer.null_.isAny(content.infoPointer, content.thanksPointer, content.successPointer, content.failedPointer, content.wrongSpeciesPointer, content.tradeAddress)) return null
            return content
        }
        fun getLegendaryEventContent(model: IDataModel, parser: ScriptParser, ev: ObjectEventViewModel): LegendaryEventContent? { /*@DONE EventTemplate.GetLegendaryEventContent/2 cs:983-1028*/
            var content = LegendaryEventContent(Pointer.null_, Pointer.null_, null, null, Pointer.null_)
            /*
               67 preparemsg text<"">
               A1 cry species:data.pokemon.names effect:
               B6 setwildbattle species: level. item:
               29 setflag flag:
               2A clearflag flag:
               7D bufferPokemon buffer.3 species:data.pokemon.names
            */
            val spots = Flags.getAllScriptSpots(model, parser, listOf(ev.scriptAddress), false, 0x67, 0xA1, 0xB6, 0x29, 0x2A, 0x7D)
            val flagsSet = LinkedHashMap<Int, Int>() // address of flag -> flag value
            val flagsCleared = LinkedHashMap<Int, Int>() // address of flag -> flag value
            val bufferSpots = LinkedHashMap<Int, Int>() // address of buffer -> pokemon to buffer
            for (spot in spots) {
                val code = spot.line.lineCode[0]
                if (code == 0x29) {
                    flagsSet[spot.address + 1] = model.readMultiByteValue(spot.address + 1, 2)
                } else if (code == 0x2A) {
                    flagsCleared[spot.address + 1] = model.readMultiByteValue(spot.address + 1, 2)
                } else if (code == 0x7D) {
                    bufferSpots[spot.address + 2] = model.readMultiByteValue(spot.address + 2, 2)
                } else {
                    content = when (code) {
                        0x67 -> content.copy(cryTextPointer = spot.address + 1)
                        0xA1 -> content.copy(cry = spot.address)
                        0xB6 -> content.copy(setWildBattle = spot.address)
                        else -> throw NotImplementedException()
                    }
                }
            }
            if (content.cry == Pointer.null_) return null
            if (content.setWildBattle == Pointer.null_) return null
            val setOnlyFlags = flagsSet.values.toSet() - flagsCleared.values.toSet()
            if (setOnlyFlags.size != 1) return null
            val bufferPokemon = ArrayList<Int>()
            for ((key, value) in bufferSpots) {
                if (value == model.readMultiByteValue(content.setWildBattle + 1, 2)) bufferPokemon.add(key - 2)
            }

            val legendFlag = setOnlyFlags.single()
            val legendFlagAddress = flagsSet.keys.filter { key -> flagsSet[key] == legendFlag }
            content = content.copy(setFlag = legendFlagAddress.map { flag -> flag - 1 })
            content = content.copy(bufferPokemon = bufferPokemon)

            return content
        }
        private fun goodPointer(model: IDataModel, address: Int): Boolean { /*@DONE EventTemplate.GoodPointer/1 cs:1075-1079*/
            if (address < 0 || address >= model.count - 3) return false
            val destination = model.readPointer(address)
            return 0 <= destination && destination < model.count
        }
        /*@END EventTemplate.Companion*/
    }
    /*@ADD EventTemplate#eventtemplate_a.txt*/
    private fun graphicOption(index: Int): IPixelViewModel {
        return if (index >= 0 && index < graphicsOptions.size) graphicsOptions[index] else ReadonlyPixelViewModel(16, 16)
    }
    /*@ENDADD EventTemplate#eventtemplate_a.txt*/
    /*@END EventTemplate*/
}

data class TrainerEventContent(val beforeTextPointer: Int, val winTextPointer: Int, val afterTextPointer: Int, val trainerClassAddress: Int, val trainerIndex: Int, val trainerIndexAddress: Int, val trainerNameAddress: Int, val teamPointer: Int) { // cs:1108-1108
    /*@END TrainerEventContent*/
}

data class RematchTrainerEventContent(val trainerID: Int, val beforeTextPointer: Int, val winTextPointer: Int, val afterTextPointer: Int) { // cs:1110-1110
    /*@END RematchTrainerEventContent*/
}

data class MartEventContent(val helloPointer: Int, val martPointer: Int, val goodbyePointer: Int) { // cs:1112-1112
    /*@END MartEventContent*/
}

data class TutorEventContent(val infoPointer: Int, val whichPokemonPointer: Int, val failedPointer: Int, val successPointer: Int, val tutorAddress: Int) { // cs:1114-1114
    /*@END TutorEventContent*/
}

data class TradeEventContent(val infoPointer: Int, val thanksPointer: Int, val successPointer: Int, val failedPointer: Int, val wrongSpeciesPointer: Int, val tradeAddress: Int) { // cs:1116-1116
    /*@END TradeEventContent*/
}

data class LegendaryEventContent(val cry: Int, val setWildBattle: Int, val bufferPokemon: List<Int>?, val setFlag: List<Int>?, val cryTextPointer: Int) { // cs:1118-1118
    /*@END LegendaryEventContent*/
}

enum class TemplateType(val value: Int) { // cs:1120-1120
    None(0),
    Npc(1),
    Item(2),
    Trainer(3),
    Mart(4),
    Tutor(5),
    Trade(6),
    Legendary(7),
    HMObject(8);
    companion object {
        fun fromValue(value: Int): TemplateType = entries.first { it.value == value }
    }
    /*@END TemplateType*/
}
