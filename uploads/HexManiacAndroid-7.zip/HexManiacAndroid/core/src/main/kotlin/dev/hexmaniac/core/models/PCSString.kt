// Port of Models/PCSString.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*

interface ITextConverter { // cs:11-21
    fun convert(text: String, containsBadCharacters: Ref<Boolean>): MutableList<Int>?
    fun convert(data: ByteList, startIndex: Int, length: Int, includeNewlineCharacters: Boolean = false): String?
    fun anyMacroStartsWith(input: String): Boolean
    fun getOverflow(input: String, maxWidth: Int): List<TextSegment>
    /*@END ITextConverter*/
}

open class PCSConverter : ITextConverter { // cs:23-62
    private var gameCode: String = ""
    private var model: IDataModel? = null
    private var fontWidth: Lazy<IntArray>? = null
    constructor(gameCode: String, model: IDataModel?) { /*@DONE PCSConverter.<init>/1 cs:28-33*/
        this.gameCode = gameCode
        if (this.gameCode.length > 4) this.gameCode = gameCode.substring(4)
        this.model = model
        fontWidth = lazy { updateFontWidthCache() }
    }
    override fun convert(text: String, containsBadCharacters: Ref<Boolean>): MutableList<Int>? { /*@DONE PCSConverter.Convert/1 cs:35-37*/
        return PCSString.convert(text, gameCode, containsBadCharacters)
    }
    override fun convert(data: ByteList, startIndex: Int, length: Int, includeNewlineCharacters: Boolean): String? { /*@DONE PCSConverter.Convert/2 cs:39-41*/
        return PCSString.convert(gameCode, data, startIndex, length, includeNewlineCharacters)
    }
    override fun anyMacroStartsWith(input: String): Boolean { /*@DONE PCSConverter.AnyMacroStartsWith/1 cs:43-46*/
        val macros = PCSString.textMacros[gameCode] ?: return false
        return macros.keys.any { key -> key.startsWith(input) }
    }
    override fun getOverflow(input: String, maxWidth: Int): List<TextSegment> { /*@DONE PCSConverter.GetOverflow/1 cs:48-52*/
        val macros: Map<String, ByteArray> = PCSString.textMacros[gameCode] ?: LinkedHashMap()
        return PCSString.getOverflow(macros, fontWidth!!.value, input, maxWidth)
    }
    private fun updateFontWidthCache(): IntArray { /*@DONE PCSConverter.UpdateFontWidthCache/1 cs:54-61*/
        val model = this.model ?: return IntArray(0)
        val table = model.getTable(HardcodeTablesModel.fontWidthTable) ?: model.getTable(HardcodeTablesModel.backupFontWidthTable)
        if (table == null) return IntArray(0)
        val result = IntArray(table.elementCount)
        for (i in 0 until result.size) result[i] = model[table.start + i]
        return result
    }
    /*@END PCSConverter*/
}

object PCSString { // cs:64-628
    private const val textReferenceFileName: String = "resources/pcsReference.txt"
    var pcs: List<String?> = ArrayList()
    var validInProgressEscapes: Set<String> = LinkedHashSet()
    var newlines: ByteList = ByteArray(0).asByteList()
    var controlCodeLengths: Map<Int, Int> = LinkedHashMap()
    var textMacros: Map<String, Map<String, ByteArray>> = LinkedHashMap()
    var textMacrosIndex: Map<String, List<Map<String, ByteArray>?>> = LinkedHashMap()
    val dynamicEscape: Int = /*@INITAUTO PCSString.DynamicEscape cs:74-74*/ 0xF7 /*@ENDINIT*/
    val functionEscape: Int = /*@INITAUTO PCSString.FunctionEscape cs:75-75*/ 0xFC /*@ENDINIT*/
    val buttonEscape: Int = /*@INITAUTO PCSString.ButtonEscape cs:76-76*/ 0xF8 /*@ENDINIT*/
    val specialCharacterEscape: Int = /*@INITAUTO PCSString.SpecialCharacterEscape cs:77-77*/ 0xF9 /*@ENDINIT*/
    val escape: Int = /*@INITAUTO PCSString.Escape cs:78-78*/ 0xFD /*@ENDINIT*/
    init { /*@DONE PCSString.<cctor>/1 cs:80-99*/
        if (Resources.exists(textReferenceFileName)) {
            val referenceText = Resources.readAllLines(textReferenceFileName).toTypedArray()
            pcs = getPCSFromReference(referenceText)
            controlCodeLengths = getControlCodeLengthsFromReference(referenceText)
            textMacros = getTextMacrosFromReference(referenceText)
            textMacrosIndex = buildTextMacrosIndex(textMacros)
        } else {
            pcs = getDefaultPCS()
            controlCodeLengths = getDefaultControlCodeLengths()
            textMacros = LinkedHashMap()
            textMacrosIndex = buildTextMacrosIndex(textMacros)
        }

        val escapes = LinkedHashSet<String>()
        for (c in pcs) {
            if (c == null || !c.startsWith("\\")) continue
            for (i in 0 until c.length - 1) escapes.add(c.substring(0, i + 1))
        }
        validInProgressEscapes = escapes

        newlines = byteArrayOf(0xFA.toByte(), 0xFB.toByte(), 0xFE.toByte()).asByteList()
    }
    private fun getPCSFromReference(reference: Array<String>): List<String?> { /*@DONE PCSString.GetPCSFromReference/1 cs:101-121*/
        val pcs = arrayOfNulls<String>(0x100)

        for (i in 0 until reference.size) {
            if (!reference[i].startsWith("0x")) continue
            val line = reference[i].substring(2).split('#').first().trim()
            val parts = line.split("=", limit = 2).toMutableList()
            if (parts.size != 2) continue
            parts[0] = parts[0].trim()
            parts[1] = parts[1].trim()
            val start = Ref(0)
            if (!tryParseHexInt(parts[0], start)) continue
            if (parts[1].length > 1 && parts[1].startsWith("\"") && parts[1].endsWith("\"")) {
                parts[1] = parts[1].substring(1, parts[1].length - 1)
                for (j in 0 until parts[1].length) pcs[start.value + j] = parts[1][j].toString()
            } else {
                pcs[start.value] = parts[1]
            }
        }

        return pcs.asList()
    }
    private fun getControlCodeLengthsFromReference(reference: Array<String>): Map<Int, Int> { /*@DONE PCSString.GetControlCodeLengthsFromReference/1 cs:123-137*/
        val lengths = LinkedHashMap<Int, Int>()

        for (i in 0 until reference.size) {
            if (!reference[i].startsWith("CC_")) continue
            val line = reference[i].substring(3).split('#').first().trim()
            val parts = line.split("=", limit = 2)
            if (parts.size != 2) continue
            val code = Ref(0)
            if (!tryParseHexInt(parts[0].trim(), code) || code.value < 0 || code.value > 0xFF) continue
            val argCount = Ref(0)
            if (!tryParseInt(parts[1].trim(), argCount) || argCount.value < 0 || argCount.value > 0xFF) continue
            lengths[code.value] = (argCount.value + 1) and 0xFF
        }

        return lengths
    }
    private fun getTextMacrosFromReference(reference: Array<String>): Map<String, Map<String, ByteArray>> { /*@DONE PCSString.GetTextMacrosFromReference/1 cs:139-145*/
        val macros = LinkedHashMap<String, Map<String, ByteArray>>()
        for (game in arrayOf("AXVE", "AXPE", "BPRE", "BPGE", "BPEE")) {
            macros[game] = getTextMacrosFromReference(reference, game)
        }
        return macros
    }
    private fun buildTextMacrosIndex(allMacros: Map<String, Map<String, ByteArray>>): Map<String, List<Map<String, ByteArray>?>> { /*@DONE PCSString.BuildTextMacrosIndex/1 cs:147-161*/
        val allIndex = LinkedHashMap<String, List<Map<String, ByteArray>?>>()
        for (macroKvp in allMacros) {
            val index = arrayOfNulls<LinkedHashMap<String, ByteArray>>(256)
            for (macro in macroKvp.value) {
                val text = macro.key
                val bytes = macro.value
                if (bytes.size < 1) continue
                val lead = bytes[0].toInt() and 0xFF
                if (index[lead] == null) index[lead] = LinkedHashMap()
                index[lead]!![text] = bytes
            }
            allIndex[macroKvp.key] = index.asList()
        }
        return allIndex
    }
    private fun getTextMacrosFromReference(reference: Array<String>, gameCode: String): Map<String, ByteArray> { /*@DONE PCSString.GetTextMacrosFromReference/2 cs:163-178*/
        var isInMacroSection = true
        val results = LinkedHashMap<String, ByteArray>()

        for (i in 0 until reference.size) {
            if (reference[i].trim().startsWith("@!game(")) isInMacroSection = reference[i].contains(gameCode)
            if (!isInMacroSection) continue
            if (!reference[i].startsWith("[")) continue
            val endOfMacro = reference[i].indexOf("]")
            val bytes = reference[i].substring(endOfMacro + 1).split("#")[0].trim().parseHexBytes()
            val name = reference[i].substring(0, endOfMacro + 1)
            results[name] = bytes
        }

        return results
    }
    private fun getDefaultPCS(): List<String?> { /*@DONE PCSString.GetDefaultPCS/1 cs:180-228*/
        val pcs = arrayOfNulls<String>(0x100)

        pcs[0] = " "
        fill(pcs, "\u00c0\u00c1\u00c2\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc", 0x01)
        fill(pcs, "\u00ce\u00cf\u00d2\u00d3\u00d4", 0x0B)
        fill(pcs, "\u0152\u00d9\u00da\u00db\u00d1\u00df\u00e0\u00e1", 0x10)
        fill(pcs, "\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec", 0x19)
        fill(pcs, "\u00ee\u00ef\u00f2\u00f3\u00f4\u0153\u00f9\u00fa\u00fb\u00f1\u00ba\u00aa", 0x20)
        pcs[0x2C] = "\\e"
        fill(pcs, "& \\+", 0x2D)
        fill(pcs, "\\Lv = ;", 0x34)


        pcs[0x48] = "\\r" // right?

        fill(pcs, "\u00bf \u00a1 \\pk \\mn \\Po \\Ke \\Bl \\Lo \\Ck \u00cd", 0x51)

        fill(pcs, "%()", 0x5B)

        pcs[0x68] = "\u00e2"
        pcs[0x6F] = "\u00ed"

        fill(pcs, "\\au \\ad \\al \\ar", 0x79) // arrows

        pcs[0x84] = "\\d"
        fill(pcs, "\\< \\>", 0x85)

        fill(pcs, "0123456789", 0xA1)
        // \. -> ellipsis   \qo \qc -> quote open/close    \sm \sf -> male/female symbols
        fill(pcs, "! ? . - \u2027 \\. \\qo \\qc \u2018 ' \\sm \\sf \$ , * /", 0xAB)

        fill(pcs, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", 0xBB)
        fill(pcs, "abcdefghijklmnopqrstuvwxyz", 0xD5)

        fill(pcs, ":\u00c4\u00d6\u00dc\u00e4\u00f6\u00fc", 0xF0)

        pcs[0xF7] = "\\?" // decomp 'dynamic', another placeholder mechanism. Expects a single-byte argument
        pcs[0xF8] = "\\btn" // button escape: next byte is read as a button ID. order is [A, B, L, R, START, SELECT, UP, DOWN, LEFT, RIGHT, UP_DOWN, LEFT_RIGHT, DPAD]
        pcs[0xF9] = "\\9"
        pcs[0xFA] = "\\l"
        pcs[0xFB] = "\\pn"
        pcs[0xFC] = "\\CC" // control code: next byte is a control code (function escape), followed by some number of argument bytes
        pcs[0xFD] = "\\\\" // escape character: next byte is interpreted raw
        pcs[0xFE] = "\\n"
        pcs[0xFF] = "\""

        return pcs.asList()
    }
    private fun getDefaultControlCodeLengths(): Map<Int, Int> { /*@DONE PCSString.GetDefaultControlCodeLengths/1 cs:230-239*/
        val lengths = LinkedHashMap<Int, Int>()
        lengths[0x04] = 4 // (text, shadow, highlight) -> 3 params
        lengths[0x09] = 1 // pause : no variables
        lengths[0x0A] = 1 // wait for sound effect
        lengths[0x0B] = 3 // play background music : 1 variable, but it takes 2 bytes
        lengths[0x10] = 3 // play sound effects : 2 variables
        return lengths
    }
    fun convert(data: ByteList, startIndex: Int, length: Int): String? { /*@DONE PCSString.Convert/1 cs:241-241*/
        return convert("", data, startIndex, length)
    }
    fun convert(macroSet: String, data: ByteList, startIndex: Int, length: Int, includeNewlineCharacters: Boolean = false): String? { /*@DONE PCSString.Convert/2 cs:243-301*/
        val result = StringBuilder("\"")
        val macrosIndex = textMacrosIndex[macroSet]

        var nextExpectedNewline = NewlineMode.Wrap

        var i = 0
        while (i < length) {
            // check macros
            if (macrosIndex != null) {
                val macro = findMacro(macrosIndex, data, startIndex + i)
                if (macro != null) {
                    result.append(macro)
                    i += textMacros[macroSet]!![macro]!!.size - 1
                    i++
                    continue
                }
            }

            val currentByte = data[startIndex + i]

            // this line optimized for maximum speed. Otherwise would like to use the Newlines array.
            if (length > 1 && (currentByte == 0xFA || currentByte == 0xFB || currentByte == 0xFE)) {
                if (currentByte == 0xFB) { // paragraph
                    if (includeNewlineCharacters) result.append("\\pn")
                    result.append(NEW_LINE).append(NEW_LINE)
                    nextExpectedNewline = NewlineMode.Wrap
                } else if (currentByte == 0xFE && nextExpectedNewline == NewlineMode.Wrap) {
                    if (includeNewlineCharacters) result.append("\\n")
                    result.append(NEW_LINE)
                    nextExpectedNewline = NewlineMode.Feed
                } else if (currentByte == 0xFA && nextExpectedNewline == NewlineMode.Feed) {
                    if (includeNewlineCharacters) result.append("\\l")
                    result.append(NEW_LINE)
                    nextExpectedNewline = NewlineMode.Feed
                } else {
                    result.append(pcs[currentByte] ?: "").append(NEW_LINE)
                    nextExpectedNewline = NewlineMode.Feed
                }
            } else if (pcs[currentByte] == null) {
                result.append("\\!" + currentByte.toHexString())
            } else {
                result.append(pcs[currentByte])
            }

            if (length == 1) break

            if ((currentByte == escape || currentByte == dynamicEscape || currentByte == buttonEscape || currentByte == specialCharacterEscape) && i < length - 1) {
                result.append(data[startIndex + i + 1].toHex(2))
                i++
            }
            if (currentByte == functionEscape) {
                val escapeLength = getLengthForControlCode(data[startIndex + i + 1])
                for (j in 0 until escapeLength) result.append(data[startIndex + i + 1 + j].toHex(2))
                i += escapeLength
            }

            if (currentByte == 0xFF) break
            i++
        }
        return result.toString()
    }
    private enum class NewlineMode(val value: Int) { // cs:310-310
        None(0),
        Explicit(1),
        Wrap(2),
        Feed(3),
        Paragraph(4);
        companion object {
            fun fromValue(value: Int): NewlineMode = entries.first { it.value == value }
        }
        /*@END PCSString.NewlineMode*/
    }
    private val doubleNewline: String = /*@INITDONE PCSString.doubleNewline cs:311-311*/ NEW_LINE + NEW_LINE /*@ENDINIT*/
    fun convert(input: String): MutableList<Int>? { /*@DONE PCSString.Convert/3 cs:313-313*/
        return convert(input, Ref(false))
    }
    fun convert(input: String, containsBadCharacters: Ref<Boolean>): MutableList<Int>? { /*@DONE PCSString.Convert/4 cs:314-314*/
        return convert(input, "", containsBadCharacters)
    }
    fun convert(input: String, macroSet: String, containsBadCharacters: Ref<Boolean>): MutableList<Int>? { /*@DONE PCSString.Convert/5 cs:315-441*/
        var text = input
        if (text.startsWith("\"")) text = text.substring(1) // trim leading " at start of string
        val result = ArrayList<Int>()
        containsBadCharacters.value = false

        var lastNewLine = NewlineMode.None
        var nextNewline = NewlineMode.Wrap

        val macros = textMacros[macroSet]

        var index = 0
        while (index < text.length) {
            var foundMatch = false

            // check macros
            if (text[index] == '[' && macros != null) {
                val closeMacro = text.substring(index).indexOf(']') + index
                if (closeMacro > index) {
                    val candidate = text.substring(index, closeMacro + 1)
                    val bytes = macros[candidate]
                    if (bytes != null) {
                        index += candidate.length
                        for (b in bytes) result.add(b.toInt() and 0xFF)
                        continue
                    }
                }
            }

            // check raw escape code \!XX (hex byte)
            if (index < text.length - 4 && text[index] == '\\' && text[index + 1] == '!') {
                val hex = text.substring(index + 2, index + 4)
                val value = Ref(0)
                if (hex.tryParseHex(value)) {
                    result.add(value.value and 0xFF)
                } else {
                    result.add(0)
                }
                index += 4
                continue
            }

            // check newlines
            if (index < text.length - doubleNewline.length) {
                val isNewline = text.startsWith(NEW_LINE, index)
                if (isNewline && nextNewline == NewlineMode.Explicit) {
                    // don't add anything to result
                    // lastNewline still says what the most recent newline was
                    // nextNewline will get reset after the next character
                } else if (isNewline) {
                    if (text.startsWith(doubleNewline, index)) {
                        lastNewLine = NewlineMode.Paragraph
                        nextNewline = NewlineMode.Wrap
                        result.add(0xFB) // paragraph feed
                        index += doubleNewline.length
                        continue
                    } else if (nextNewline == NewlineMode.Wrap) {
                        lastNewLine = NewlineMode.Wrap
                        nextNewline = NewlineMode.Feed
                        result.add(0xFE) // wrap
                        index += NEW_LINE.length
                        continue
                    } else {
                        lastNewLine = NewlineMode.Feed
                        nextNewline = NewlineMode.Feed
                        result.add(0xFA) // feed
                        index += NEW_LINE.length
                        continue
                    }
                }
            }

            // check characters and escape codes
            for (i in 0 until 0x100) {
                if (pcs[i] == null) continue
                var checkCharacter = pcs[i]!!
                if (text.length < index + checkCharacter.length) continue
                var checkInput = text.substring(index, index + checkCharacter.length)
                if (checkCharacter.length > 0 && checkCharacter[0] == '\\' && !validInProgressEscapes.contains(checkInput)) {
                    // escape sequences don't care about case (if no sequences seem to match the current case)
                    checkCharacter = checkCharacter.uppercase()
                    checkInput = checkInput.uppercase()
                }
                if (checkInput != checkCharacter) continue
                if (i != 0xFF || index == text.length - 1) result.add(i) // don't allow adding " to the middle
                index += pcs[i]!!.length - 1
                if ((i == escape || i == dynamicEscape || i == buttonEscape || i == specialCharacterEscape) && text.length > index + 2) {
                    val parsed = Ref(0)
                    if (tryParseByteHex(text.substring(index + 1, index + 3), parsed)) {
                        result.add(parsed.value)
                    }
                    index += 2
                }
                if (i == functionEscape && text.length > index + 2) {
                    val parsed = Ref(0)
                    if (tryParseByteHex(text.substring(index + 1, index + 3), parsed)) {
                        val extraEscapedBytesCount = getLengthForControlCode(parsed.value)
                        result.add(parsed.value)
                        for (j in 1 until extraEscapedBytesCount) {
                            if (text.length > index + 4 && tryParseByteHex(text.substring(index + 3, index + 5), parsed)) {
                                result.add(parsed.value)
                            }
                            index += 2
                        }
                    }
                    index += 2
                }

                if (i == 0xFA || i == 0xFB || i == 0xFE) {
                    // explicit newline
                    nextNewline = NewlineMode.Explicit
                    lastNewLine = when (i) {
                        0xFA -> NewlineMode.Feed
                        0xFB -> NewlineMode.Wrap
                        0xFE -> NewlineMode.Paragraph
                        else -> NewlineMode.None
                    }
                } else if (nextNewline == NewlineMode.Explicit) {
                    // refresh implicit newline
                    nextNewline = if (lastNewLine == NewlineMode.Paragraph) NewlineMode.Wrap else NewlineMode.Feed
                }

                foundMatch = true
                break
            }
            containsBadCharacters.value = containsBadCharacters.value || !foundMatch

            index++ // always increment by one, even if the character was not found.
        }

        // make sure it ends with the 0xFF end-of-string byte
        if (result.size == 0 || result[result.size - 1] != 0xFF) result.add(0xFF)

        return result
    }
    fun readString(data: ByteList, start: Int, allowCharacterRepeates: Boolean, maxLength: Int = Int.MAX_VALUE): Int { /*@DONE PCSString.ReadString/1 cs:447-476*/
        var length = 0
        var recent = data[start]
        var repeatCount = 0
        var spacesCount = 0
        while (start + length < data.count && length <= maxLength) {
            if (data[start + length] == recent) {
                repeatCount++
            } else {
                repeatCount = 1
                recent = data[start + length]
            }
            if (data[start + length] == 0x00) spacesCount++
            if (repeatCount > 3 && !allowCharacterRepeates) return -1 // not a string if it has more than 3 of the same character in a row.
            if (pcs[recent] == null) return -1 // not valid string data
            if (data[start + length] == 0xFF) {
                if (spacesCount * 2 > length + 1 && spacesCount != length) return -1 // over half the string is whitespace. Probably a false string.
                return length + 1 // end of string. Add one extra space for the end-of-stream byte
            }
            if (data[start + length] == escape) length++ // escape character, skip the next byte
            else if (data[start + length] == dynamicEscape) length++
            else if (data[start + length] == buttonEscape) length++
            else if (data[start + length] == specialCharacterEscape) length++
            else if (data[start + length] == functionEscape) {
                length += getLengthForControlCode(data[start + length + 1])
            }
            length++
        }
        return -1
    }
    private const val defaultCharacterWidth: Int = 6
    fun getOverflow(textMacros: Map<String, ByteArray>?, fontWidth: IntArray, input: String, maxWidth: Int): List<TextSegment> { /*@DONE PCSString.GetOverflow/1 cs:479-584*/
        val results = ArrayList<TextSegment>()
        var currentLineWidth = 0
        var text = input
        if (text.startsWith("\"")) text = text.substring(1) // trim leading " at start of string
        var lineNumber = 0
        var lineStart = 0

        var index = 0
        while (index < text.length) {
            val initialIndex = index

            // check macros
            if (text[index] == '[' && textMacros != null) {
                val closeMacro = text.substring(index).indexOf(']') + index
                if (closeMacro > index) {
                    val candidate = text.substring(index, closeMacro + 1)
                    val bytes = textMacros[candidate]
                    if (bytes != null) {
                        index += candidate.length
                        if (candidate.isAny("[player]", "[rival]", "[buffer1]", "[buffer2]", "[buffer3]")) {
                            // guess that the character name is 9 characters long
                            currentLineWidth += defaultCharacterWidth * 9
                        } else {
                            // most macros don't actually make the text longer
                        }

                        continue
                    }
                }
            }

            // check raw escape code \!XX (hex byte)
            if (index < text.length - 4 && text[index] == '\\' && text[index + 1] == '!') {
                // raw hex, unknown length, just guess
                currentLineWidth += defaultCharacterWidth
                index += 4

                continue
            }

            // check newline
            val isNewline = text.startsWith(NEW_LINE, index)
            if (isNewline) {
                currentLineWidth = 0
                lineNumber++
                index += NEW_LINE.length
                lineStart = index
                continue
            }

            // check characters and escape codes
            for (i in 0 until 0x100) {
                if (pcs[i] == null) continue
                var checkCharacter = pcs[i]!!
                if (text.length < index + checkCharacter.length) continue
                var checkInput = text.substring(index, index + checkCharacter.length)
                if (checkCharacter.length > 0 && checkCharacter[0] == '\\' && !validInProgressEscapes.contains(checkInput)) {
                    // escape sequences don't care about case (if no sequences seem to match the current case)
                    checkCharacter = checkCharacter.uppercase()
                    checkInput = checkInput.uppercase()
                }
                if (checkInput != checkCharacter) continue

                index += pcs[i]!!.length - 1
                if (i == 0xFA || i == 0xFB || i == 0xFE) {
                    // line end
                    currentLineWidth = 0
                } else if ((i == escape || i == dynamicEscape || i == buttonEscape || i == specialCharacterEscape) && text.length > index + 2) {
                    val parsed = Ref(0)
                    if (tryParseByteHex(text.substring(index + 1, index + 3), parsed)) {
                        currentLineWidth += 6
                    }
                    index += 2
                } else if (i == functionEscape && text.length > index + 2) {
                    // function escape code don't add any length to the current line
                    val parsed = Ref(0)
                    if (tryParseByteHex(text.substring(index + 1, index + 3), parsed)) {
                        val extraEscapedBytesCount = getLengthForControlCode(parsed.value)
                        for (j in 1 until extraEscapedBytesCount) {
                            index += 2
                        }
                    }
                    index += 2
                } else if (fontWidth.size > i) {
                    currentLineWidth += fontWidth[i]
                } else {
                    // unknown character
                    currentLineWidth += 6
                }

                break
            }

            index++ // always increment by one, even if the character was not found. This lets us skip past newlines and such.
            if (currentLineWidth > maxWidth) {
                var start = initialIndex - lineStart
                if (results.size > 0 && results[results.size - 1].line == lineNumber) {
                    start = results[results.size - 1].start
                    results.removeAt(results.size - 1)
                }
                results.add(TextSegment(lineNumber, start, index - lineStart - start, SegmentType.Warning))
            }
        }

        return results
    }
    private fun findMacro(macrosIndex: List<Map<String, ByteArray>?>, data: ByteList, index: Int): String? { /*@DONE PCSString.FindMacro/1 cs:586-598*/
        if (!index.inRange(0, data.count)) return null
        val macros = macrosIndex[data[index]] ?: return null
        for (kvp in macros) {
            var matches = true
            var i = 0
            while (i < kvp.value.size && matches) {
                matches = data.count > index + i && (kvp.value[i].toInt() and 0xFF) == data[index + i]
                i++
            }
            if (matches) return kvp.key
        }
        return null
    }
    private fun getLengthForControlCode(code: Int): Int { /*@DONE PCSString.GetLengthForControlCode/1 cs:600-604*/
        val length = controlCodeLengths[code]
        if (length != null) return length
        if (code > 0x14) return 1 // single-byte functions : no variables
        return 2 // most functions have a 1 byte code and a 1 byte variable
    }
    fun isEscaped(data: ByteList, index: Int): Boolean { /*@DONE PCSString.IsEscaped/1 cs:606-614*/
        if (index == 0) return false
        if (data[index - 1].isAny(escape, dynamicEscape, buttonEscape, specialCharacterEscape, functionEscape)) return true
        if (index == 1) return false
        for (codeDist in 2..4) {
            if (index >= codeDist && data[index - codeDist] == functionEscape && getLengthForControlCode(data[index - codeDist + 1]) >= codeDist) return true
        }
        return false
    }
    private fun fill(array: Array<String?>, characters: String, startIndex: Int) { /*@DONE PCSString.Fill/1 cs:616-627*/
        var start = startIndex
        if (characters.contains(" ")) {
            for (part in characters.split(' ')) {
                array[start] = part
                start++
            }
        } else {
            for (i in 0 until characters.length) {
                array[startIndex + i] = characters.substring(i, i + 1)
            }
        }
    }
    /*@ADD PCSString#util_6.txt*/
    /** C# `byte.TryParse(text, NumberStyles.HexNumber, ..., out byte)`: hex digits only, value must fit in a byte. */
    private fun tryParseByteHex(text: String, result: Ref<Int>): Boolean {
        val parsed = Ref(0)
        if (!tryParseHexInt(text, parsed) || parsed.value < 0 || parsed.value > 0xFF) return false
        result.value = parsed.value
        return true
    }
    /*@ENDADD PCSString#util_6.txt*/
    /*@END PCSString*/
}
