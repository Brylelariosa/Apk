// Port of Models/Runs/Factory/AsciiRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class AsciiRunContentStrategy : RunStrategy() { // cs:9-46
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE AsciiRunContentStrategy.LengthForNewRun/1 cs:10-13*/
        val length = Ref(0)
        if (!tryParseInt(format!!.substring(5), length)) length.value = 1
        return length.value.limitToRange(1, 1000)
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE AsciiRunContentStrategy.Matches/1 cs:15-15*/
        return run is AsciiRun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE AsciiRunContentStrategy.TryAddFormatAtDestination/1 cs:17-23*/
        val lengthRef = Ref(0)
        if (!tryParseInt(format!!.substring(5), lengthRef)) lengthRef.value = 0
        var length = lengthRef.value
        if (length < 1) return false
        length = length.limitToRange(1, 1000)
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, AsciiRun(owner, destination, length, SortedSpanStatic.one(source)))
        return true
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE AsciiRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:25-30*/
        val lengthRef = Ref(0)
        if (!tryParseInt(format!!.substring(5), lengthRef)) lengthRef.value = 1
        val length = lengthRef.value.limitToRange(1, 1000)
        val newRun = AsciiRun(model, run.value.start, length, run.value.pointerSources)
        run.value = newRun
        model.clearFormat(token, newRun.start, newRun.length)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE AsciiRunContentStrategy.WriteNewRun/1 cs:32-35*/
        val length = Ref(0)
        if (!tryParseInt(format!!.substring(5), length)) length.value = 1
        return AsciiRun(owner, destination, length.value)
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE AsciiRunContentStrategy.TryParseData/1 cs:37-45*/
        val length = Ref(0)
        if (tryParseInt(format!!.substring(5), length)) {
            run.value = AsciiRun(model, dataIndex, length.value)
        } else {
            return ErrorInfo("Ascii runs must include a length.")
        }

        return ErrorInfo.noError
    }
    /*@END AsciiRunContentStrategy*/
}

open class BrailleRunContentStrategy : RunStrategy() { // cs:48-63
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE BrailleRunContentStrategy.LengthForNewRun/1 cs:49-49*/
        throw NotImplementedError()
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE BrailleRunContentStrategy.Matches/1 cs:51-51*/
        throw NotImplementedError()
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE BrailleRunContentStrategy.TryAddFormatAtDestination/1 cs:53-53*/
        throw NotImplementedError()
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE BrailleRunContentStrategy.TryParseData/1 cs:55-58*/
        run.value = BrailleRun(model, dataIndex)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE BrailleRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:60-60*/
        throw NotImplementedError()
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE BrailleRunContentStrategy.WriteNewRun/1 cs:62-62*/
        throw NotImplementedError()
    }
    /*@END BrailleRunContentStrategy*/
}
