package dev.hexmaniac.core.system

// System.Windows.Input.ICommand and the AutoImplement-generated StubCommand (Core/Autos/StubCommand.cs).

/** System.Windows.Input.ICommand */
interface ICommand {
    fun canExecute(parameter: Any?): Boolean
    fun execute(parameter: Any?)
    val canExecuteChanged: Event<EventArgs>
}

/** `command.Execute()` extension from ICommandExtensions: runs the command with a null parameter. */
fun ICommand.execute() = execute(null)

/**
 * A command made of two settable delegates. C#: `new StubCommand { CanExecute = arg => ..., Execute = arg => ... }`,
 * Kotlin: `StubCommand().apply { canExecute = { arg -> ... }; execute = { arg -> ... } }`.
 * A missing `canExecute` delegate means "false" (just like the generated C# stub, which returned default(bool)),
 * so always set it unless you want a disabled command. Use [StubCommand.always] for the common always-enabled case.
 */
class StubCommand : ICommand {
    /** The delegate behind CanExecute. Note: a property and the ICommand method can have the same name in Kotlin. */
    var canExecute: ((Any?) -> Boolean)? = null
    var execute: ((Any?) -> Unit)? = null

    override val canExecuteChanged: Event<EventArgs> = Event()

    override fun canExecute(parameter: Any?): Boolean = canExecute?.invoke(parameter) ?: false

    override fun execute(parameter: Any?) {
        execute?.invoke(parameter)
    }

    /** `RaiseCanExecuteChanged` extension of SystemExtensions. */
    fun raiseCanExecuteChanged() = canExecuteChanged(this, EventArgs.empty)

    companion object {
        /** An always-enabled command that runs [action]. */
        fun always(action: (Any?) -> Unit): StubCommand = StubCommand().also {
            it.canExecute = { true }
            it.execute = action
        }
    }
}

/** Core/Autos/CompositeCommand.cs: runs several commands as one. */
class CompositeCommand(private val commands: List<ICommand>) : ICommand {
    override val canExecuteChanged: Event<EventArgs> = Event()

    init {
        for (c in commands) c.canExecuteChanged += { _, e -> canExecuteChanged(this, e) }
    }

    override fun canExecute(parameter: Any?): Boolean = commands.all { it.canExecute(parameter) }

    override fun execute(parameter: Any?) {
        for (c in commands) c.execute(parameter)
    }
}

/** Utility from ICommandExtensions: `CanAlwaysExecute`. */
object ICommandExtensions {
    fun canAlwaysExecute(@Suppress("UNUSED_PARAMETER") parameter: Any?): Boolean = true
}
