// Port of Models/Runs/MapListRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class MapListRun : BaseRun, ITableRun { // cs:7-51
    override val length: Int
        get() { /*@DONE MapListRun.Length.get cs:12-12*/
            return elementCount * 4
        }
    override val formatString: String
        get() { /*@DONE MapListRun.FormatString.get cs:13-13*/
            return "[" + segmentFormat + "]" + elementCount
        }
    final override var elementCount: Int = 0
        private set
    override val elementLength: Int
        get() { /*@DONE MapListRun.ElementLength.get cs:15-15*/
            return 4
        }
    var model: IDataModel? = null
        private set
    override val elementNames: List<String>? = /*@INITDONE MapListRun.ElementNames cs:17-17*/ ArrayList<String>() /*@ENDINIT*/
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    override val canAppend: Boolean
        get() { /*@DONE MapListRun.CanAppend.get cs:19-19*/
            return false
        }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>?) : super(start, sources) { /*@DONE MapListRun.<init>/1 cs:21-26*/
        this.model = model
        this.elementContent = ArrayRun.parseSegments(segmentFormat, model)
        val first = sources?.firstOrNull()
        val index = if (first != null) (first - (model.getNextRun(first)?.start ?: first)) / 4 else 0
        this.elementCount = if (index >= 0 && index < bpre0_Lengths.size) bpre0_Lengths[index] else 0
    }
    override fun append(token: ModelDelta, length: Int): ITableRun { /*@DONE MapListRun.Append/1 cs:28-30*/
        throw NotImplementedException()
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE MapListRun.AppendTo/1 cs:32-34*/
        throw NotImplementedException()
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE MapListRun.Clear/1 cs:36-38*/
        throw NotImplementedException()
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE MapListRun.CreateDataFormat/1 cs:40-42*/
        return this.createSegmentDataFormat(data, index)
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE MapListRun.Duplicate/1 cs:44-46*/
        return MapListRun(model!!, start, pointerSources)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE MapListRun.Clone/1 cs:48-50*/
        return MapListRun(model!!, start, newPointerSources)
    }
    companion object {
        private val bpre0_Lengths: IntArray = /*@INITDONE MapListRun.BPRE0_Lengths cs:9-9*/ intArrayOf(5, 123, 60, 66, 4, 6, 8, 10, 6, 8, 20, 10, 8, 2, 10, 4, 2, 2, 2, 1, 1, 2, 2, 3, 2, 3, 2, 1, 1, 1, 1, 7, 5, 5, 8, 8, 5, 5, 1, 1, 1, 2, 1) /*@ENDINIT*/
        private val segmentFormat: String = /*@INITAUTO MapListRun.segmentFormat cs:10-10*/ "map<[layout<[width:: height:: s1<> s2<> tiles<[a. b. c. d. tileset<`lzt4`> pal<`ucp4:0123456789ABCDEF`> block<> unknown<> blockend<>]1> s4<> borderwidth. borderheight. unused:]1> events<[e1 e2 e3 e4 ee1<> ee2<> ee3<> ee4<>]1> mapscripts<[type. pointer<>]!00> d<> song: map: label. flash. weather. type. unused: useLabel:]1>" /*@ENDINIT*/
        /*@END MapListRun.Companion*/
    }
    /*@END MapListRun*/
}
