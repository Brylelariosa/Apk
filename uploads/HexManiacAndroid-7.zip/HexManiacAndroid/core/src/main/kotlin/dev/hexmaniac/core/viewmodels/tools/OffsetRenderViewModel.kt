// Port of ViewModels/Tools/OffsetRenderViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class OffsetRenderViewModel : ViewModelCore, IArrayElementViewModel, IPixelViewModel { // cs:10-130
    private lateinit var viewPort: IEditableViewPort
    private lateinit var segment: ArrayRunOffsetRenderSegment
    private var itemAddress: Int = 0
    private var _visible: Boolean = /*@INITAUTO OffsetRenderViewModel.visible cs:15-15*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE OffsetRenderViewModel.Visible.get cs:16-16*/
            return _visible
        }
        set(value) { /*@DONE OffsetRenderViewModel.Visible.set cs:16-16*/
            set(_visible, value, "visible", { _visible = it })
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE OffsetRenderViewModel.Theme.get cs:18-18*/
            return _theme
        }
        set(value) { /*@DONE OffsetRenderViewModel.Theme.set cs:18-18*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE OffsetRenderViewModel.IsInError.get cs:19-19*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE OffsetRenderViewModel.ErrorText.get cs:20-20*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE OffsetRenderViewModel.ZIndex.get cs:21-21*/
            return 0
        }
    var pixelViewModel: IPixelViewModel? = null
        private set
    override val transparent: Short
        get() { /*@DONE OffsetRenderViewModel.Transparent.get cs:27-27*/
            return pixelViewModel?.transparent ?: (-1).toShort()
        }
    override val pixelWidth: Int
        get() { /*@DONE OffsetRenderViewModel.PixelWidth.get cs:28-28*/
            return pixelViewModel?.pixelWidth ?: 0
        }
    override val pixelHeight: Int
        get() { /*@DONE OffsetRenderViewModel.PixelHeight.get cs:29-29*/
            return pixelViewModel?.pixelHeight ?: 0
        }
    override val pixelData: ShortArray
        get() { /*@DONE OffsetRenderViewModel.PixelData.get cs:30-30*/
            return pixelViewModel?.pixelData ?: ShortArray(0)
        }
    override val spriteScale: Double
        get() { /*@DONE OffsetRenderViewModel.SpriteScale.get cs:31-31*/
            return pixelViewModel?.spriteScale ?: 0.0
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    constructor(viewPort: IEditableViewPort, segment: ArrayRunOffsetRenderSegment, itemAddress: Int) { /*@DONE OffsetRenderViewModel.<init>/1 cs:38-63*/
        this.viewPort = viewPort
        val model = viewPort.model!!
        this.segment = segment
        this.itemAddress = itemAddress
        val offsetTable = model.getNextRun(itemAddress) as? ITableRun ?: return
        val segmentOffset = offsetTable.convertByteOffsetToArrayOffset(itemAddress)
        var xOffset = 0
        var yOffset = 0
        if (offsetTable.elementContent.map { field -> field.name }.contains(segment.targetFieldX)) {
            xOffset = offsetTable.readValue(model, segmentOffset.elementIndex, segment.targetFieldX)
        }
        yOffset = parseContent(offsetTable, segment.targetFieldY, itemAddress)

        // find/crop background
        pixelViewModel = segment.renderBackground(model)
        if (pixelViewModel == null) return

        // find/render foreground
        val foregroundTable = model.getTable(segment.foreground)
        val imageAddress = foregroundTable?.readPointer(model, segmentOffset.elementIndex) ?: Pointer.null_
        val foregroundRun = model.getNextRun(imageAddress) as? ISpriteRun ?: return
        val pointerStart = foregroundTable!!.start + segmentOffset.elementIndex * foregroundTable.elementLength
        val paletteRun = foregroundRun.findRelatedPalettes(model, pointerStart, foregroundRun.spriteFormat.paletteHint).firstOrNull()
        val foreground = ReadonlyPixelViewModel.create(model, foregroundRun, paletteRun, true)
        if (foreground != null) pixelViewModel = ReadonlyPixelViewModel.render(pixelViewModel!!, foreground, segment.x + xOffset, segment.y + yOffset)
    }
    fun parseContent(defaultTable: ITableRun, text: String, itemAddress: Int): Int { /*@DONE OffsetRenderViewModel.ParseContent/1 cs:65-87*/
        val parts = text.split("-")
        if (parts.size == 2) {
            return parseContent(defaultTable, parts[0], itemAddress) - parseContent(defaultTable, parts[1], itemAddress)
        }

        val segmentOffset = defaultTable.convertByteOffsetToArrayOffset(itemAddress)

        val slashParts = text.split("/")
        if (slashParts.size == 2) {
            val table = viewPort.model!!.getTable(slashParts[0])
            if (table != null) {
                val tableItemAddress = table.start + table.elementLength * segmentOffset.elementIndex
                return parseContent(table, slashParts[1], tableItemAddress)
            }
        }

        if (defaultTable.elementContent.map { field -> field.name }.contains(text)) {
            return defaultTable.readValue(viewPort.model!!, segmentOffset.elementIndex, text)
        }

        return 0
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE OffsetRenderViewModel.TryCopy/1 cs:89-107*/
        val that = other as? OffsetRenderViewModel ?: return false

        segment = that.segment
        itemAddress = that.itemAddress
        visible = that.visible

        val properties = ArrayList<String>()
        if (transparent != that.transparent) properties.add("transparent")
        if (pixelWidth != that.pixelWidth) properties.add("pixelWidth")
        if (pixelHeight != that.pixelHeight) properties.add("pixelHeight")
        if (pixelData !== that.pixelData) properties.add("pixelData")
        if (spriteScale != that.spriteScale) properties.add("spriteScale")
        pixelViewModel = that.pixelViewModel
        notifyPropertyChanged("pixelViewModel")
        for (p in properties) notifyPropertyChanged(p)

        return true
    }
    fun shiftDelta(x: Int, y: Int) { /*@DONE OffsetRenderViewModel.ShiftDelta/1 cs:109-129*/
        val model = viewPort.model!!
        val offsetTable = model.getNextRun(itemAddress) as? ITableRun ?: return
        val segmentOffset = offsetTable.convertByteOffsetToArrayOffset(itemAddress)

        val editPortionX = segment.targetFieldX.split('+', '-')[0]
        if (offsetTable.elementContent.map { field -> field.name }.contains(editPortionX)) {
            var offset = offsetTable.readValue(model, segmentOffset.elementIndex, editPortionX)
            offset = (offset + x).limitToRange(0, segment.backgroundWidth)
            offsetTable.writeValue(offset, model, viewPort.changeHistory.currentChange, segmentOffset.elementIndex, editPortionX)
        }

        val editPortionY = segment.targetFieldY.split('+', '-')[0]
        if (offsetTable.elementContent.map { field -> field.name }.contains(editPortionY)) {
            var offset = offsetTable.readValue(model, segmentOffset.elementIndex, editPortionY)
            offset = (offset + y).limitToRange(0, segment.backgroundWidth)
            offsetTable.writeValue(offset, model, viewPort.changeHistory.currentChange, segmentOffset.elementIndex, editPortionY)
        }

        dataChanged(this, EventArgs.empty)
    }
    /*@END OffsetRenderViewModel*/
}
