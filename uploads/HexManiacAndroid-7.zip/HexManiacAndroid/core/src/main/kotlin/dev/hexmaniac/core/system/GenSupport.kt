package dev.hexmaniac.core.system

// Support types used by the generated skeleton (see tools/skel/gen.py). Stand-ins for BCL types that the C# core uses.

/** Initializer placeholder for a non-null field whose C# initializer has not been ported yet (yields null at run time). */
@Suppress("UNCHECKED_CAST")
fun <T> portInit(): T = null as T

/**
 * Mixin for classes that implement `IReadOnlyList<T>` in C#. The class supplies `size` (C# `Count`) and `get` (the indexer);
 * everything else of kotlin.collections.List is provided here.
 */
interface ReadOnlyListMixin<T> : List<T> {
    override fun isEmpty(): Boolean = size == 0
    override fun contains(element: T): Boolean = indexOf(element) >= 0
    override fun containsAll(elements: Collection<T>): Boolean = elements.all { contains(it) }
    override fun indexOf(element: T): Int {
        for (i in 0 until size) if (get(i) == element) return i
        return -1
    }
    override fun lastIndexOf(element: T): Int {
        for (i in size - 1 downTo 0) if (get(i) == element) return i
        return -1
    }
    override fun iterator(): Iterator<T> = listIterator(0)
    override fun listIterator(): ListIterator<T> = listIterator(0)
    override fun listIterator(index: Int): ListIterator<T> = ReadOnlyListIterator(this, index)
    override fun subList(fromIndex: Int, toIndex: Int): List<T> {
        val result = ArrayList<T>()
        for (i in fromIndex until toIndex) result.add(get(i))
        return result
    }
}

class ReadOnlyListIterator<T>(private val list: List<T>, private var index: Int) : ListIterator<T> {
    override fun hasNext(): Boolean = index < list.size
    override fun hasPrevious(): Boolean = index > 0
    override fun next(): T {
        if (index >= list.size) throw NoSuchElementException()
        return list[index++]
    }
    override fun nextIndex(): Int = index
    override fun previous(): T {
        if (index <= 0) throw NoSuchElementException()
        return list[--index]
    }
    override fun previousIndex(): Int = index - 1
}

/** System.Dynamic.DynamicObject (the scripting tool is not ported; the overrides stay as plain members). */
open class DynamicObject {
    open fun tryGetMember(binder: GetMemberBinder, result: Ref<Any?>): Boolean = false
    open fun trySetMember(binder: SetMemberBinder, value: Any?): Boolean = false
}

class GetMemberBinder(val name: String)
class SetMemberBinder(val name: String)

/** System.Collections.Generic.IEqualityComparer<T> */
interface IEqualityComparer<T> {
    fun equals(x: T?, y: T?): Boolean
    fun getHashCode(obj: T): Int
}

/** System.Runtime.CompilerServices.INotifyCompletion */
interface INotifyCompletion {
    fun onCompleted(continuation: () -> Unit)
}

/** System.Threading.CancellationToken / CancellationTokenSource */
class CancellationToken(private val source: CancellationTokenSource?) {
    val isCancellationRequested: Boolean get() = source?.isCancellationRequested ?: false

    /** Runs [callback] when the source is cancelled (immediately when it already is). */
    fun register(callback: () -> Unit) {
        source?.register(callback)
    }

    companion object {
        val none: CancellationToken = CancellationToken(null)
    }
}

class CancellationTokenSource {
    @Volatile
    var isCancellationRequested: Boolean = false
        private set
    private var callbacks: MutableList<() -> Unit>? = null
    val token: CancellationToken get() = CancellationToken(this)

    fun cancel() {
        val toRun: List<() -> Unit>?
        synchronized(this) {
            if (isCancellationRequested) return
            isCancellationRequested = true
            toRun = callbacks
            callbacks = null
        }
        toRun?.forEach { it() }
    }

    fun register(callback: () -> Unit) {
        val runNow = synchronized(this) {
            if (isCancellationRequested) {
                true
            } else {
                val list = callbacks ?: ArrayList<() -> Unit>().also { callbacks = it }
                list.add(callback)
                false
            }
        }
        if (runNow) callback()
    }
}

/** Stand-ins for the IronPython hosting types (the scripting tool is not ported). */
class ScriptEngine
class ScriptScope

/** System.ConsoleKey (subset of the names, same spelling). */
enum class ConsoleKey {
    Backspace, Tab, Clear, Enter, Pause, Escape, Spacebar, PageUp, PageDown, End, Home, LeftArrow, UpArrow, RightArrow, DownArrow,
    Select, Print, Execute, PrintScreen, Insert, Delete, Help,
    D0, D1, D2, D3, D4, D5, D6, D7, D8, D9,
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
    NumPad0, NumPad1, NumPad2, NumPad3, NumPad4, NumPad5, NumPad6, NumPad7, NumPad8, NumPad9,
    Multiply, Add, Separator, Subtract, Decimal, Divide,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
}
