// Port of ViewModels/Tools/Interfaces.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

interface IToolViewModel : INotifyPropertyChanged { // cs:8-11
    val name: String
    fun dataForCurrentRunChanged()
    /*@END IToolViewModel*/
}

open class StubTool : IToolViewModel { // cs:13-19
    final override var name: String = ""
        private set
    constructor(name: String) { /*@DONE StubTool.<init>/1 cs:15-15*/
        this.name = name
    }
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override fun dataForCurrentRunChanged() { /*@DONE StubTool.DataForCurrentRunChanged/1 cs:18-18*/
        // a stub tool has no data
    }
    /*@END StubTool*/
}

interface IToolTrayViewModel : ReadOnlyListMixin<IToolViewModel>, INotifyPropertyChanged { // cs:21-48
    var selectedIndex: Int
    var selectedTool: IToolViewModel?
    val hideCommand: ICommand
    val stringToolCommand: ICommand
    val tableToolCommand: ICommand
    val codeToolCommand: ICommand
    val spriteToolCommand: ICommand
    val stringTool: PCSTool?
    val tableTool: TableTool?
    val codeTool: CodeTool?
    val spriteTool: SpriteTool?
    val logTool: LogTool?
    val deferUpdates: IDisposable
    val onError: Event<String>
    val onMessage: Event<String>
    fun schedule(action: () -> Unit)
    fun refreshContent()
    /*@END IToolTrayViewModel*/
}

interface IArrayElementViewModel : ICanSilencePropertyNotifications { // cs:50-59
    val dataChanged: Event<EventArgs>
    val dataSelected: Event<EventArgs>
    var theme: String
    var visible: Boolean
    val isInError: Boolean
    val errorText: String?
    val zIndex: Int
    fun tryCopy(other: IArrayElementViewModel): Boolean
    /*@END IArrayElementViewModel*/
}

interface IMultiEnabledArrayElementViewModel : IArrayElementViewModel { // cs:62-64
    var name: String
    /*@END IMultiEnabledArrayElementViewModel*/
}

open class SplitterArrayElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:66-162
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    private lateinit var viewPort: IViewPort
    private var _sectionName: String = ""
    private var _sectionLink: Int = 0
    private var _showSection: Boolean = false
    private var lastFilter: String = /*@INITAUTO SplitterArrayElementViewModel.lastFilter cs:74-74*/ "" /*@ENDINIT*/
    private var _theme: String = ""
    private lateinit var _followLink: StubCommand
    private lateinit var _collapseAll: StubCommand
    private lateinit var _expandAll: StubCommand
    private lateinit var _toggleVisibility: StubCommand
    override var theme: String
        get() { /*@DONE SplitterArrayElementViewModel.Theme.get cs:77-77*/
            return _theme
        }
        set(value) { /*@DONE SplitterArrayElementViewModel.Theme.set cs:77-77*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE SplitterArrayElementViewModel.IsInError.get cs:78-78*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE SplitterArrayElementViewModel.ErrorText.get cs:79-79*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE SplitterArrayElementViewModel.ZIndex.get cs:80-80*/
            return 0
        }
    var showSection: Boolean
        get() { /*@DONE SplitterArrayElementViewModel.ShowSection.get cs:81-81*/
            return _showSection
        }
        private set(value) { /*@DONE SplitterArrayElementViewModel.ShowSection.set cs:81-81*/
            set(_showSection, value, "showSection", { _showSection = it })
        }
    var sectionName: String
        get() { /*@DONE SplitterArrayElementViewModel.SectionName.get cs:82-82*/
            return _sectionName
        }
        set(value) { /*@DONE SplitterArrayElementViewModel.SectionName.set cs:82-82*/
            set(_sectionName, value, "sectionName", { _sectionName = it })
        }
    var sectionLink: Int
        get() { /*@DONE SplitterArrayElementViewModel.SectionLink.get cs:83-83*/
            return _sectionLink
        }
        set(value) { /*@DONE SplitterArrayElementViewModel.SectionLink.set cs:83-83*/
            set(_sectionLink, value, "sectionLink", { _sectionLink = it })
        }
    val followLink: ICommand
        get() { /*@DONE SplitterArrayElementViewModel.FollowLink.get cs:84-84*/
            if (!::_followLink.isInitialized) _followLink = stubCommand({ viewPort.goto?.execute(sectionLink) })
            return _followLink
        }
    val collapseAll: ICommand
        get() { /*@DONE SplitterArrayElementViewModel.CollapseAll.get cs:85-85*/
            if (!::_collapseAll.isInitialized) _collapseAll = stubCommand({ updateAllVisibility(false) })
            return _collapseAll
        }
    val expandAll: ICommand
        get() { /*@DONE SplitterArrayElementViewModel.ExpandAll.get cs:86-86*/
            if (!::_expandAll.isInitialized) _expandAll = stubCommand({ updateAllVisibility(true) })
            return _expandAll
        }
    val toggleVisibility: ICommand
        get() { /*@DONE SplitterArrayElementViewModel.ToggleVisibility.get cs:87-87*/
            if (!::_toggleVisibility.isInitialized) _toggleVisibility = stubCommand({ visible = !visible })
            return _toggleVisibility
        }
    private var _visible: Boolean = /*@INITAUTO SplitterArrayElementViewModel.visible cs:89-89*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE SplitterArrayElementViewModel.Visible.get cs:90-90*/
            return _visible
        }
        set(value) { /*@DONE SplitterArrayElementViewModel.Visible.set cs:90-90*/
            set(_visible, value, "visible", { _visible = it }, { _ -> updateCollapsed(lastFilter) })
        }
    fun updateCollapsed(filter: String) { /*@DONE SplitterArrayElementViewModel.UpdateCollapsed/1 cs:91-145*/
        var start = false
        var end = false
        val filterMatchesGroup = filter.length == 0 || _sectionName.matchesPartial(filter)
        var lastFieldVisible = filterMatchesGroup
        var anyChildrenVisible = false
        for (child in viewPort.tools!!.tableTool!!.children) {
            if (child === this) start = true
            if (!start) continue
            end = end || (child is SplitterArrayElementViewModel && child !== this)
            if (child is SplitterArrayElementViewModel) continue
            if (child is ButtonArrayElementViewModel) continue
            if (child is IStreamArrayElementViewModel) {
                val streamParent = child.parent
                if (streamParent != null && streamParent.sectionName != sectionName) continue
            } else if (end) {
                continue
            }
            var childVisible = filterMatchesGroup

            if (child is FieldArrayElementViewModel) childVisible = filterMatchesGroup || child.name.matchesPartial(filter)
            if (child is ComboBoxArrayElementViewModel) childVisible = filterMatchesGroup || child.name.matchesPartial(filter)
            if (child is MultiFieldArrayElementViewModel) childVisible = filterMatchesGroup || child.filter(filter)
            if (child is CalculatedElementViewModel) childVisible = filterMatchesGroup || child.name.matchesPartial(filter)
            if (child is IStreamArrayElementViewModel) childVisible = lastFieldVisible || (child is TextStreamElementViewModel && child.content.matchesPartial(filter))
            if (child is BitListArrayElementViewModel) {
                val filterMatchesBitList = child.name.matchesPartial(filter)
                if (!filterMatchesGroup && !filterMatchesBitList) {
                    val filteredChildren = child.filter { bitChild -> bitChild.bitLabel.matchesPartial(filter) }
                    if (filteredChildren.size > 0) {
                        // filter the children
                        for (bit in child) bit.visible = filteredChildren.contains(bit)
                        childVisible = true
                    } else {
                        // unfilter the children
                        for (bit in child) bit.visible = true
                        childVisible = false
                    }
                } else {
                    // unfilter the children
                    for (bit in child) bit.visible = true
                    childVisible = true
                }
            } else if (child is TupleArrayElementViewModel) {
                childVisible = filterMatchesGroup ||
                    child.name.matchesPartial(filter) ||
                    child.children.any { tupleChild -> tupleChild.name.matchesPartial(filter) }
            }

            // using var scope = child.SilencePropertyNotifications();
            child.visible = childVisible && _visible
            lastFieldVisible = childVisible
            anyChildrenVisible = anyChildrenVisible || childVisible
        }
        showSection = anyChildrenVisible || filterMatchesGroup
        lastFilter = filter
    }
    private fun updateAllVisibility(newValue: Boolean) { /*@DONE SplitterArrayElementViewModel.UpdateAllVisibility/1 cs:147-151*/
        for (child in viewPort.tools!!.tableTool!!.children) {
            if (child is SplitterArrayElementViewModel) child.visible = newValue
        }
    }
    constructor(viewPort: IViewPort, sectionName: String, sectionLink: Int) { /*@DONE SplitterArrayElementViewModel.<init>/1 cs:153-153*/
        this.viewPort = viewPort
        this.sectionName = sectionName
        this.sectionLink = sectionLink
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE SplitterArrayElementViewModel.TryCopy/1 cs:155-161*/
        if (other !is SplitterArrayElementViewModel) return false
        sectionName = other.sectionName
        sectionLink = other.sectionLink
        theme = other.theme
        return true
    }
    /*@END SplitterArrayElementViewModel*/
}

interface IStreamArrayElementViewModel : IArrayElementViewModel { // cs:164-180
    val dataMoved: Event<IStreamArrayElementViewModelDataMovedTuple>
    var parent: SplitterArrayElementViewModel?
    val showContent: Boolean
    val usageCount: Int
    val canRepoint: Boolean
    val repoint: ICommand
    val canRepointAll: Boolean
    val repointAll: ICommand
    val canCreateNew: Boolean
    val createNew: ICommand
    /*@END IStreamArrayElementViewModel*/
}

interface IPagedViewModel : IStreamArrayElementViewModel { // cs:182-194
    val showPageControls: Boolean
    val pages: Int
    var currentPage: Int
    val addPage: ICommand
    val deletePage: ICommand
    val canMovePrevious: Boolean
    val canMoveNext: Boolean
    fun movePrevious()
    fun moveNext()
    /*@END IPagedViewModel*/
}

data class IStreamArrayElementViewModelDataMovedTuple(val originalStart: Int, val newStart: Int)
