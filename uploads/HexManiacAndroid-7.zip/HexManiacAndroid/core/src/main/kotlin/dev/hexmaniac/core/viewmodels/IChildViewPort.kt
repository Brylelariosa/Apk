// Port of ViewModels/IChildViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

interface IChildViewPort : IViewPort { // cs:2-6
    var preferredWidth: Int
    val parent: IViewPort?
    fun refreshHeaders()
    /*@END IChildViewPort*/
}
