// Port of ViewModels/Tools/PCSTool.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.visitors.*

open class PCSTool : ViewModelCore, IToolViewModel { // cs:12-349
    private lateinit var viewPort: ViewPort
    private lateinit var model: IDataModel
    private lateinit var history: ChangeHistory<ModelDelta>
    private var runner: IToolTrayViewModel? = null
    private val _checkIsText: StubCommand = /*@INITAUTO PCSTool.checkIsText cs:17-18*/ StubCommand() /*@ENDINIT*/
    private val _search: StubCommand = /*@INITAUTO PCSTool.search cs:17-19*/ StubCommand() /*@ENDINIT*/
    private val _insertText: StubCommand = /*@INITAUTO PCSTool.insertText cs:17-20*/ StubCommand() /*@ENDINIT*/
    private var ignoreExternalUpdates: Boolean = /*@INITAUTO PCSTool.ignoreExternalUpdates cs:24-24*/ false /*@ENDINIT*/
    override val name: String
        get() { /*@DONE PCSTool.Name.get cs:26-26*/
            return "String"
        }
    private var _contentIndex: Int = 0
    var contentIndex: Int
        get() { /*@DONE PCSTool.ContentIndex.get cs:30-30*/
            return _contentIndex
        }
        set(value) { /*@DONE PCSTool.ContentIndex.set cs:31-33*/
            if (tryUpdate(_contentIndex, value, "contentIndex") { _contentIndex = it }) updateSelectionFromTool()
        }
    private var _contentSelectionLength: Int = 0
    var contentSelectionLength: Int
        get() { /*@DONE PCSTool.ContentSelectionLength.get cs:38-38*/
            return _contentSelectionLength
        }
        set(value) { /*@DONE PCSTool.ContentSelectionLength.set cs:39-41*/
            if (tryUpdate(_contentSelectionLength, value, "contentSelectionLength") { _contentSelectionLength = it }) updateSelectionFromTool()
        }
    private var _searchText: String = /*@INITAUTO PCSTool.searchText cs:44-44*/ "" /*@ENDINIT*/
    var searchText: String
        get() { /*@DONE PCSTool.SearchText.get cs:46-46*/
            return _searchText
        }
        set(value) { /*@DONE PCSTool.SearchText.set cs:47-47*/
            tryUpdate(_searchText, value, "searchText") { _searchText = it }
        }
    val checkIsText: ICommand
        get() { /*@DONE PCSTool.CheckIsText.get cs:50-50*/
            return _checkIsText
        }
    val search: ICommand
        get() { /*@DONE PCSTool.Search.get cs:51-51*/
            return _search
        }
    val insertText: ICommand
        get() { /*@DONE PCSTool.InsertText.get cs:52-52*/
            return _insertText
        }
    private var _showMessage: Boolean = /*@INITAUTO PCSTool.showMessage cs:54-54*/ true /*@ENDINIT*/
    var showMessage: Boolean
        get() { /*@DONE PCSTool.ShowMessage.get cs:56-56*/
            return _showMessage
        }
        set(value) { /*@DONE PCSTool.ShowMessage.set cs:57-63*/
            if (tryUpdate(_showMessage, value, "showMessage") { _showMessage = it }) {
                _checkIsText.canExecuteChanged(_checkIsText, EventArgs.empty)
                _insertText.canExecuteChanged(_checkIsText, EventArgs.empty)
                _search.canExecuteChanged(_checkIsText, EventArgs.empty)
            }
        }
    private var _message: String = ""
    var message: String
        get() { /*@DONE PCSTool.Message.get cs:68-68*/
            return _message
        }
        set(value) { /*@DONE PCSTool.Message.set cs:69-69*/
            tryUpdate(_message, value, "message") { _message = it }
        }
    private var _content: String = ""
    var content: String
        get() { /*@DONE PCSTool.Content.get cs:74-74*/
            return _content
        }
        set(value) { /*@DONE PCSTool.Content.set cs:75-82*/
            if (tryUpdate(_content, value, "content") { _content = it }) {
                val run = model.getNextRun(_address) ?: NoInfoRun.nullRun
                if (run.start > _address) return // wrong run, don't adjust
                if (run is IStreamRun) updateRun(run)
                if (run is ArrayRun) updateRun(run)
            }
        }
    private var _address: Int = /*@INITDONE PCSTool.address cs:85-85*/ Pointer.null_ /*@ENDINIT*/
    var address: Int
        get() { /*@DONE PCSTool.Address.get cs:87-87*/
            return _address
        }
        set(value) { /*@DONE PCSTool.Address.set cs:88-93*/
            if (ignoreExternalUpdates) return
            if (tryUpdate(_address, value, "address") { _address = it }) {
                refreshContentAtAddress()
            }
        }
    private var _enabled: Boolean = false
    var enabled: Boolean
        get() { /*@DONE PCSTool.Enabled.get cs:98-98*/
            return _enabled
        }
        private set(value) { /*@DONE PCSTool.Enabled.set cs:99-103*/
            if (tryUpdate(_enabled, value, "enabled") { _enabled = it }) {
                if (!_enabled) tryUpdate(_content, "", "content") { _content = it }
            }
        }
    var gotoOptions: ObservableCollection<ContextItem> = /*@INITDONE PCSTool.GotoOptions cs:106-106*/ ObservableCollection() /*@ENDINIT*/
        private set
    val onError = Event<String>()
    val modelDataChanged = Event<IFormattedRun>()
    val modelDataMoved = Event<PCSToolModelDataMovedTuple>()
    var verticalOffset: Double = 0.0
    constructor(viewPort: ViewPort, history: ChangeHistory<ModelDelta>, runner: IToolTrayViewModel?) { /*@DONE PCSTool.<init>/1 cs:115-166*/
        this.viewPort = viewPort
        this.model = viewPort.model!!
        this.history = history
        this.runner = runner
        _checkIsText.canExecute = { _ -> showMessage }
        _checkIsText.execute = { _ ->
            val startPlaces = model.findPossibleTextStartingPlaces(address, 1)
            val results = model.considerResultsAsTextRuns({ history.currentChange }, startPlaces)
            if (results == 0) {
                onError(this, "Could not discover text at " + _address.toHex(6) + ".")
            } else {
                runner!!.schedule(this::dataForCurrentRunChanged)
                enabled = true
                showMessage = false
                modelDataChanged(this, model.getNextRun(_address)!!)
            }
        }
        _insertText.canExecute = { _ -> showMessage }
        _insertText.execute = insertTextExecute@{ _ ->
            if (_address < 0 || model.count <= _address || model[_address] != 0xFF || (model.getNextRun(_address) ?: NoInfoRun.nullRun).start <= _address) {
                _address = viewPort.convertViewPointToAddress(viewPort.selectionStart)
            }
            if (_address < 0 || model.count <= _address || model[_address] != 0xFF || (model.getNextRun(_address) ?: NoInfoRun.nullRun).start <= _address) {
                onError(this, "Could not insert text at " + _address.toHex(6) + "." + NEW_LINE + "The bytes must be unused (FF).")
                return@insertTextExecute
            }
            val gameCode = model.getGameCode()
            val newRun = PCSRun(model, _address, 1, null)
            history.currentChange.addRun(newRun)
            model.observeAnchorWritten(history.currentChange, "scripts.text." + gameCode + _address.toHex(6), newRun)
            modelDataChanged(this, newRun)
            runner!!.schedule(this::dataForCurrentRunChanged)
            enabled = true
            showMessage = false
        }
        _search.canExecute = { _ -> !showMessage }
        _search.execute = searchExecute@{ _ ->
            val target = _searchText.lowercase()
            if (target.length == 0) return@searchExecute
            val lowerContent = content.lowercase()
            val start = Math.min(content.length - target.length, _contentIndex)

            val from = (start + 1).limitToRange(0, lowerContent.length)
            var index = lowerContent.substring(from).indexOf(target)
            if (index < 0) index = lowerContent.indexOf(target)
            else index += from

            if (index < 0) return@searchExecute
            contentIndex = index
            contentSelectionLength = target.length
        }
    }
    fun getAutocomplete(line: String, lineIndex: Int, characterIndex: Int): List<AutocompleteItem> { /*@DONE PCSTool.GetAutocomplete/1 cs:168-172*/
        val run = model.getNextRun(_address)
        if (run !is IStreamRun) return ArrayList()
        return run.getAutoCompleteOptions(line, lineIndex, characterIndex) ?: ArrayList()
    }
    fun refreshContentAtAddress() { /*@DONE PCSTool.RefreshContentAtAddress/1 cs:174-190*/
        val run = model.getNextRun(_address) ?: NoInfoRun.nullRun
        if ((run is IStreamRun || addressIsTextInTableRun(run, _address)) && run.start <= _address) {
            runner!!.schedule(this::dataForCurrentRunChanged)
            enabled = true
            showMessage = false
            gotoOptions.clear()
            for (option in ContextItemFactory(viewPort).getAnchorSourceItems(_address)) {
                gotoOptions.add(option)
            }
        } else {
            enabled = false
            showMessage = true
            message = _address.toHex(6) + " does not appear to be text."
            gotoOptions.clear()
        }
    }
    override fun dataForCurrentRunChanged() { /*@DONE PCSTool.DataForCurrentRunChanged/1 cs:192-231*/
        val run = model.getNextRun(_address) ?: NoInfoRun.nullRun
        if (run.start <= _address && run is ArrayRun) {
            val offsets = run.convertByteOffsetToArrayOffset(_address)
            val segment = run.elementContent[offsets.segmentIndex]
            if (segment.type == ElementContentType.PCS) {
                val lines = Array<String>(run.elementCount) { "" }
                val textStart = offsets.segmentStart - offsets.elementIndex * run.elementLength // the starting address of the first text element
                for (i in 0 until lines.size) {
                    var newContent = model.textConverter.convert(model, textStart + i * run.elementLength, segment.length)?.trim() ?: ""
                    newContent = removeQuotes(newContent)
                    lines[i] = newContent
                }
                if (lines.size > 0) {
                    val builder = StringBuilder()
                    for (i in 0 until lines.size) {
                        builder.append(lines[i])
                        if (i != lines.size - 1) builder.append(NEW_LINE)
                    }

                    // guard to prevent selection updates due to data changes from other tools/the main view
                    ignoreSelectionUpdates = true
                    StubDisposable { ignoreSelectionUpdates = false }.using {
                        tryUpdate(_content, builder.toString(), "content") { _content = it }
                    }
                }
            }
        } else if (run.start <= _address && run is IStreamRun) {
            ModelCacheScope.createScope(model).using {
                val newContent = run.serializeRun() ?: ""
                ignoreSelectionUpdates = true
                StubDisposable { ignoreSelectionUpdates = false }.using {
                    tryUpdate(_content, newContent, "content") { _content = it }
                }
            }
        } else {
            // this may have been text at some point, but it isn't now.
            enabled = false
        }
    }
    private fun addressIsTextInTableRun(run: IFormattedRun, address: Int): Boolean { /*@DONE PCSTool.AddressIsTextInTableRun/1 cs:233-239*/
        if (run is ITableRun) {
            val offsets = run.convertByteOffsetToArrayOffset(address)
            return run.elementContent[offsets.segmentIndex].type == ElementContentType.PCS
        }
        return false
    }
    private fun removeQuotes(newContent: String): String { /*@DONE PCSTool.RemoveQuotes/1 cs:241-246*/
        var text = newContent
        if (text.length == 0) return text
        text = text.substring(1)
        if (text.endsWith("\"")) text = text.substring(0, text.length - 1)
        return text
    }
    private var ignoreSelectionUpdates: Boolean = false
    private fun updateSelectionFromTool() { /*@DONE PCSTool.UpdateSelectionFromTool/1 cs:253-297*/
        if (ignoreSelectionUpdates) return
        val run = model.getNextRun(address) ?: NoInfoRun.nullRun
        if (run !is ArrayRun && run !is PCSRun && run !is EggMoveRun && run !is PLMRun) return

        // for arrays, the address must be at the start of a string segment within the first element of the array
        if (run is ArrayRun) {
            val offset = run.convertByteOffsetToArrayOffset(address)
            if (run.elementContent[offset.segmentIndex].type != ElementContentType.PCS) return // must be a string
        }

        val text = content
        if (text.length < _contentIndex + _contentSelectionLength) return // transient invalid state
        var selectionStart = _contentIndex
        var selectionLength = _contentSelectionLength

        if (run is PCSRun) {
            selectionLength = Math.max((model.textConverter.convert(text.substring(selectionStart, selectionStart + selectionLength), Ref(false))?.size ?: 0) - 2, 0) // remove 1 byte since 0xFF was added on and 1 byte since the selection should visually match
            selectionStart = (model.textConverter.convert(text.substring(0, selectionStart), Ref(false))?.size ?: 0) - 1 + run.start // remove 1 byte since the 0xFF was added on
        } else if (run is ArrayRun) {
            val offset = run.convertByteOffsetToArrayOffset(address)
            val textStart = offset.segmentStart - offset.elementIndex * run.elementLength // the starting address of the first text element
            val leadingLines = text.substring(0, _contentIndex).split(NEW_LINE)
            selectionStart = textStart + (leadingLines.size - 1) * run.elementLength + leadingLines[leadingLines.size - 1].length

            selectionLength = Math.max(0, selectionLength - 1) // decrease by one since a selection of 0 and selection of 1 have no difference
            val afterLines = text.substring(0, _contentIndex + selectionLength).split(NEW_LINE)
            val selectionEnd = textStart + (afterLines.size - 1) * run.elementLength + afterLines[afterLines.size - 1].length
            selectionLength = selectionEnd - selectionStart
        } else if (run is EggMoveRun || run is PLMRun) { // both of these streams format by putting 2 bytes per line.
            val beforeSelection = text.substring(0, selectionStart)
            val beforeLineCount = (beforeSelection.split(NEW_LINE).size - 1).limitToRange(0, Int.MAX_VALUE)
            val withSelection = text.substring(0, selectionStart + selectionLength)
            val withSelectionLineCount = (withSelection.split(NEW_LINE).size - 1).limitToRange(0, Int.MAX_VALUE)

            selectionStart = run.start + beforeLineCount * 2
            val selectionEnd = run.start + withSelectionLineCount * 2
            selectionLength = selectionEnd - selectionStart
        }

        history.continueCurrentTransaction().using {
            viewPort.selectionStart = viewPort.convertAddressToViewPoint(selectionStart)
            viewPort.selectionEnd = viewPort.convertAddressToViewPoint(selectionStart + selectionLength)
        }
    }
    private fun updateRun(arrayRun: ArrayRun) { /*@DONE PCSTool.UpdateRun/1 cs:299-330*/
        val lines = _content.split(NEW_LINE)
        val arrayByteLength = lines.size * arrayRun.elementLength
        var newRun = model.relocateForExpansion(history.currentChange, arrayRun, arrayByteLength)

        ModelCacheScope.createScope(model).using {
            tryUpdate(_address, _address + newRun.start - arrayRun.start, "address") { _address = it }

            val offsets = newRun.convertByteOffsetToArrayOffset(_address)
            if (arrayRun.start != newRun.start) modelDataMoved(this, PCSToolModelDataMovedTuple(arrayRun.start, newRun.start))
            val segmentLength = newRun.elementContent[offsets.segmentIndex].length
            for (i in 0 until lines.size) {
                val bytes = (model.textConverter.convert(lines[i], Ref(false)) ?: ArrayList()).toMutableList()
                if (bytes.size > segmentLength) bytes[segmentLength - 1] = 0xFF // truncate and always end with an endstring character
                for (j in 0 until segmentLength) {
                    if (j < bytes.size) {
                        history.currentChange.changeData(model, offsets.segmentStart + i * newRun.elementLength + j, bytes[j])
                    } else {
                        history.currentChange.changeData(model, offsets.segmentStart + i * newRun.elementLength + j, 0x00)
                    }
                }
            }

            if (newRun.elementCount != lines.size) {
                newRun = newRun.append(history.currentChange, lines.size - newRun.elementCount)
                model.observeRunWritten(history.currentChange, newRun)
                history.currentChange.addRun(newRun)
            }

            modelDataChanged(this, newRun)
        }
    }
    private fun updateRun(run: IStreamRun) { /*@DONE PCSTool.UpdateRun/2 cs:332-348*/
        ignoreExternalUpdates = true
        ModelCacheScope.createScope(model).using {
            var newRun = run.deserializeRun(_content, history.currentChange, Ref<List<Int>?>(null), Ref<List<Int>?>(null)) // streams in the text tool aren't expected to have parents/children that need updates.
            if (newRun.length != run.length) {
                model.observeRunWritten(history.currentChange, newRun)
                newRun = model.getNextRun(newRun.start) as IStreamRun
                history.currentChange.addRun(newRun)
                if (newRun is EggMoveRun) newRun.updateLimiter(history.currentChange)
            }

            if (run.start != newRun.start) modelDataMoved(this, PCSToolModelDataMovedTuple(run.start, newRun.start))
            modelDataChanged(this, newRun)
            tryUpdate(_address, newRun.start, "address") { _address = it }
            ignoreExternalUpdates = false
        }
    }
    /*@END PCSTool*/
}

data class PCSToolModelDataMovedTuple(val originalLocation: Int, val newLocation: Int)
