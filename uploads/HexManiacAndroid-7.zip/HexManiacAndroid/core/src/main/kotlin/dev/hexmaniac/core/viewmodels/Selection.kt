// Port of ViewModels/Selection.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

typealias GetSelectionSpan = (Point) -> GetSelectionSpanGetSelectionSpanTuple // cs:12-12

open class JumpInfo { // cs:14-22
    var viewStart: Int = 0
        private set
    var selectionStart: Int = 0
        private set
    var tab: ITabContent? = null
        private set
    constructor(viewStart: Int, selectionStart: Int, tab: ITabContent? = null) { /*@DONE JumpInfo.<init>/1 cs:18-21*/
        this.viewStart = viewStart
        this.selectionStart = selectionStart
        this.tab = tab
    }
    /*@END JumpInfo*/
}

data class SelectionTabChangeArgs(val tab: ITabContent?, val isBackArrow: Boolean) { // cs:24-24
    /*@END SelectionTabChangeArgs*/
}

data class SelectionGotoArgs(val text: String?, val container: ViewPort) { // cs:25-25
    /*@END SelectionGotoArgs*/
}

open class Selection : ViewModelCore { // cs:27-525
    private lateinit var model: IDataModel
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var getSpan: GetSelectionSpan
    private val _moveSelectionStart: StubCommand = /*@INITAUTO Selection.moveSelectionStart cs:33-34*/ StubCommand() /*@ENDINIT*/
    private val _moveSelectionEnd: StubCommand = /*@INITAUTO Selection.moveSelectionEnd cs:33-35*/ StubCommand() /*@ENDINIT*/
    private val gotoCommand: StubCommand = /*@INITAUTO Selection.gotoCommand cs:33-36*/ StubCommand() /*@ENDINIT*/
    private val resetAlignmentCommand: StubCommand = /*@INITAUTO Selection.resetAlignmentCommand cs:33-37*/ StubCommand() /*@ENDINIT*/
    private val _forward: StubCommand = /*@INITAUTO Selection.forward cs:33-38*/ StubCommand() /*@ENDINIT*/
    private val backward: StubCommand = /*@INITAUTO Selection.backward cs:33-39*/ StubCommand() /*@ENDINIT*/
    private val backStack: ArrayDeque<JumpInfo> = /*@INITAUTO Selection.backStack cs:43-43*/ ArrayDeque() /*@ENDINIT*/
    private val forwardStack: ArrayDeque<JumpInfo> = /*@INITAUTO Selection.forwardStack cs:43-43*/ ArrayDeque() /*@ENDINIT*/
    private var _preferredWidth: Int = /*@INITDONE Selection.preferredWidth cs:45-45*/ defaultPreferredWidth /*@ENDINIT*/
    private var maxWidth: Int = /*@INITAUTO Selection.maxWidth cs:45-45*/ 4 /*@ENDINIT*/
    private var rawSelectionStart: Point = Point()
    private var _selectionStart: Point = Point()
    private var rawSelectionEnd: Point = Point()
    private var _selectionEnd: Point = Point()
    var selectionStart: Point
        get() { /*@DONE Selection.SelectionStart.get cs:53-53*/
            return _selectionStart
        }
        set(value) { /*@DONE Selection.SelectionStart.set cs:54-71*/
            val index = scroll.viewPointToDataIndex(value)
            val max = if (scroll.isSingleTableMode) scroll.dataLength - 1 else scroll.dataLength
            val target = scroll.dataIndexToViewPoint(index.limitToRange(scroll.dataStart, max))

            if (_selectionStart == target) return

            val targetRef = Ref(target)
            if (!scroll.scrollToPoint(targetRef)) {
                previewSelectionStartChanged(this, _selectionStart)
            }
            val moved = targetRef.value

            rawSelectionStart = moved
            rawSelectionEnd = moved
            val span = getSpan(rawSelectionStart)
            tryUpdate(_selectionStart, span.start, "selectionStart") { _selectionStart = it }
            tryUpdate(_selectionEnd, span.end, "selectionEnd") { _selectionEnd = it }
            updateHeaderSelection()
        }
    var selectionEnd: Point
        get() { /*@DONE Selection.SelectionEnd.get cs:75-75*/
            return _selectionEnd
        }
        set(value) { /*@DONE Selection.SelectionEnd.set cs:76-112*/
            val index = scroll.viewPointToDataIndex(value)
            val max = if (scroll.isSingleTableMode) scroll.dataLength - 1 else scroll.dataLength
            val target = scroll.dataIndexToViewPoint(index.limitToRange(scroll.dataStart, max))

            if (_selectionEnd == target) return

            val targetRef = Ref(target)
            scroll.scrollToPoint(targetRef)
            val moved = targetRef.value

            rawSelectionEnd = moved
            val startIndex = scroll.viewPointToDataIndex(rawSelectionStart)
            val endIndex = scroll.viewPointToDataIndex(rawSelectionEnd)

            updateHeaderSelection()

            // case 1: start/end are the same
            if (startIndex == endIndex) {
                val span = getSpan(rawSelectionStart)
                tryUpdate(_selectionStart, span.start, "selectionStart") { _selectionStart = it }
                tryUpdate(_selectionEnd, span.end, "selectionEnd") { _selectionEnd = it }
                return
            }

            // case 2: start < end
            if (startIndex < endIndex) {
                tryUpdate(_selectionStart, getSpan(rawSelectionStart).start, "selectionStart") { _selectionStart = it }
                tryUpdate(_selectionEnd, getSpan(rawSelectionEnd).end, "selectionEnd") { _selectionEnd = it }
                return
            }

            // case 3: start > end
            if (startIndex > endIndex) {
                tryUpdate(_selectionEnd, getSpan(rawSelectionEnd).start, "selectionEnd") { _selectionEnd = it }
                tryUpdate(_selectionStart, getSpan(rawSelectionStart).end, "selectionStart") { _selectionStart = it }
                return
            }
        }
    private fun updateHeaderSelection() { /*@DONE Selection.UpdateHeaderSelection/1 cs:115-120*/
        val headers = scroll.headers
        for (i in 0 until headers.size) {
            headers[i].isSelected = i == rawSelectionStart.y && i == rawSelectionEnd.y
        }
    }
    var preferredWidth: Int
        get() { /*@DONE Selection.PreferredWidth.get cs:123-123*/
            return _preferredWidth
        }
        set(value) { /*@DONE Selection.PreferredWidth.set cs:124-126*/
            if (tryUpdate(_preferredWidth, value, "preferredWidth") { _preferredWidth = it }) changeWidth(maxWidth)
        }
    private var _autoAdjustDataWidth: Boolean = /*@INITAUTO Selection.autoAdjustDataWidth cs:129-129*/ true /*@ENDINIT*/
    private var _allowMultipleElementsPerLine: Boolean = /*@INITAUTO Selection.allowMultipleElementsPerLine cs:129-129*/ false /*@ENDINIT*/
    var autoAdjustDataWidth: Boolean
        get() { /*@DONE Selection.AutoAdjustDataWidth.get cs:130-130*/
            return _autoAdjustDataWidth
        }
        set(value) { /*@DONE Selection.AutoAdjustDataWidth.set cs:130-130*/
            set(_autoAdjustDataWidth, value, "autoAdjustDataWidth", { _autoAdjustDataWidth = it })
        }
    var allowMultipleElementsPerLine: Boolean
        get() { /*@DONE Selection.AllowMultipleElementsPerLine.get cs:131-131*/
            return _allowMultipleElementsPerLine
        }
        set(value) { /*@DONE Selection.AllowMultipleElementsPerLine.set cs:131-131*/
            set(_allowMultipleElementsPerLine, value, "allowMultipleElementsPerLine", { _allowMultipleElementsPerLine = it })
        }
    val moveSelectionStart: ICommand
        get() { /*@DONE Selection.MoveSelectionStart.get cs:133-133*/
            return _moveSelectionStart
        }
    val moveSelectionEnd: ICommand
        get() { /*@DONE Selection.MoveSelectionEnd.get cs:134-134*/
            return _moveSelectionEnd
        }
    val goto: ICommand?
        get() { /*@DONE Selection.Goto.get cs:135-135*/
            return gotoCommand
        }
    val resetAlignment: ICommand
        get() { /*@DONE Selection.ResetAlignment.get cs:136-136*/
            return resetAlignmentCommand
        }
    val forward: ICommand
        get() { /*@DONE Selection.Forward.get cs:137-137*/
            return _forward
        }
    val back: ICommand
        get() { /*@DONE Selection.Back.get cs:138-138*/
            return backward
        }
    lateinit var scroll: ScrollRegion
        private set
    val requestTabChanged = Event<SelectionTabChangeArgs>()
    val onError = Event<String>()
    val previewSelectionStartChanged = Event<Point>()
    constructor(scrollRegion: ScrollRegion, model: IDataModel, history: ChangeHistory<ModelDelta>, getSpan: GetSelectionSpan? = null) { /*@DONE Selection.<init>/1 cs:152-280*/
        this.model = model
        this.history = history
        this.getSpan = getSpan ?: { p -> getDefaultSelectionSpan(p) }
        scroll = scrollRegion
        scroll.scrollChanged += { _, e -> shiftSelectionFromScroll(e) }
        scroll.headersChanged += { _, _ -> updateHeaderSelection() }

        _moveSelectionStart.canExecute = { _ -> true }
        _moveSelectionStart.execute = { args -> moveSelectionStartExecuted(args as Direction) }
        _moveSelectionEnd.canExecute = { _ -> true }
        _moveSelectionEnd.execute = { args -> moveSelectionEndExecuted(args as Direction) }
        resetAlignmentCommand.canExecute = { _ -> true }
        resetAlignmentCommand.execute = { _ -> gotoAddressAndAlign(scroll.dataIndex, 0x10) }

        gotoCommand.canExecute = { args ->
            var allowed = true
            if (args is String) {
                val str = args.replace(PointerRun.pointerStart.toString(), "").replace(PointerRun.pointerEnd.toString(), "").lowercase()
                if (str == "null") allowed = false
            }
            allowed
        }
        gotoCommand.execute = { args -> gotoExecuted(args) }
        backward.canExecute = { _ -> backStack.size > 0 }
        backward.execute = { _ -> backExecuted() }
        _forward.canExecute = { _ -> forwardStack.size > 0 }
        _forward.execute = { _ -> forwardExecuted() }
    }
    fun isSelected(point: Point): Boolean { /*@DONE Selection.IsSelected/1 cs:282-293*/
        if (point.x < 0 || point.x >= scroll.width) return false

        val startIndex = scroll.viewPointToDataIndex(selectionStart)
        val endIndex = scroll.viewPointToDataIndex(selectionEnd)
        val middle = scroll.viewPointToDataIndex(point)

        val leftEdge = Math.min(startIndex, endIndex)
        val rightEdge = Math.max(startIndex, endIndex)

        return leftEdge <= middle && middle <= rightEdge
    }
    fun changeWidth(newWidth: Int) { /*@DONE Selection.ChangeWidth/1 cs:299-312*/
        maxWidth = newWidth
        val rawStart = scroll.viewPointToDataIndex(rawSelectionStart)
        val rawEnd = scroll.viewPointToDataIndex(rawSelectionEnd)
        val start = scroll.viewPointToDataIndex(_selectionStart)
        val end = scroll.viewPointToDataIndex(_selectionEnd)

        scroll.width = coerceWidth(newWidth)

        rawSelectionStart = scroll.dataIndexToViewPoint(rawStart)
        rawSelectionEnd = scroll.dataIndexToViewPoint(rawEnd)
        _selectionStart = scroll.dataIndexToViewPoint(start)
        _selectionEnd = scroll.dataIndexToViewPoint(end)
    }
    fun gotoAddress(address: Int) { /*@DONE Selection.GotoAddress/1 cs:314-335*/
        if (address >= model.count || address < 0) {
            onError(this, "Address ${address.toHex(2)} is not within the size of the data.")
            return
        }

        var selectionPoint = scroll.viewPointToDataIndex(selectionStart)
        if (selectionPoint < scroll.dataIndex || selectionPoint > scroll.dataIndex + scroll.width * scroll.height) selectionPoint = scroll.dataIndex
        backStack.addLast(JumpInfo(scroll.dataIndex, selectionPoint))
        if (backStack.size == 1) backward.raiseCanExecuteChanged()
        if (forwardStack.size > 0) {
            forwardStack.clear()
            _forward.raiseCanExecuteChanged()
        }
        gotoAddressHelper(address)

        // if we didn't actually move anything, don't put the jump point in the back-stack
        val jump = backStack.last()
        if (scroll.dataIndex == jump.viewStart && scroll.viewPointToDataIndex(selectionStart) == jump.selectionStart) {
            backStack.removeLast()
        }
    }
    fun setJumpBackTab(tab: ITabContent?) { /*@DONE Selection.SetJumpBackTab/1 cs:337-344*/
        backStack.addLast(JumpInfo(-1, -1, tab))
        if (forwardStack.size > 0) {
            forwardStack.clear()
            _forward.raiseCanExecuteChanged()
        }
        if (backStack.size == 1) backward.raiseCanExecuteChanged()
    }
    fun setJumpForwardTab(tab: ITabContent?) { /*@DONE Selection.SetJumpForwardTab/1 cs:346-349*/
        forwardStack.addLast(JumpInfo(-1, -1, tab))
        if (forwardStack.size == 1) _forward.raiseCanExecuteChanged()
    }
    fun setJumpBackPoint(address: Int) { /*@DONE Selection.SetJumpBackPoint/1 cs:351-354*/
        if (backStack.size > 0) backStack.removeLast()
        backStack.addLast(JumpInfo(address, address))
    }
    private fun gotoAddressHelper(address: Int) { /*@DONE Selection.GotoAddressHelper/1 cs:358-363*/
        val destinationRun = model.getNextRun(address) as? ITableRun
        val destinationIsArray = destinationRun != null && destinationRun.start <= address
        val width = if (destinationRun != null && destinationIsArray) destinationRun.elementLength else defaultPreferredWidth
        gotoAddressAndAlign(address, width, if (destinationRun != null && destinationIsArray) destinationRun.start else 0)
    }
    private fun gotoAddressAndAlign(address: Int, preferredWidth: Int, tableStart: Int = 0) { /*@DONE Selection.GotoAddressAndAlign/1 cs:365-401*/
        var address = address
        if (address < scroll.dataStart || scroll.dataLength < address) {
            scroll.clearTableMode()
        }

        previewSelectionStartChanged(this, _selectionStart)
        val startAddress = address
        if (preferredWidth > 1) address -= (address - tableStart) % preferredWidth

        // first, change the scroll to view the actual requested address
        scroll.scrollValue += scroll.dataIndexToViewPoint(startAddress).y

        // then, scroll left/right as needed to align everything
        var lastScroll = Int.MIN_VALUE
        while (scroll.dataIndex < address && scroll.dataIndex != lastScroll) {
            lastScroll = scroll.dataIndex
            scroll.scroll.execute(Direction.Right)
        }
        lastScroll = Int.MIN_VALUE
        while (scroll.dataIndex > address && scroll.dataIndex != lastScroll) {
            lastScroll = scroll.dataIndex
            scroll.scroll.execute(Direction.Left)
        }

        // update the width
        if (_autoAdjustDataWidth) this.preferredWidth = preferredWidth

        // finally, update the selection
        selectionStart = scroll.dataIndexToViewPoint(startAddress)

        val tableRun = model.getNextRun(startAddress) as? ITableRun
        if (tableRun != null && tableRun.start <= startAddress) {
            scroll.setTableMode(tableRun.start, tableRun.length)
        } else {
            scroll.clearTableMode()
        }
    }
    private fun shiftSelectionFromScroll(distance: Int) { /*@DONE Selection.ShiftSelectionFromScroll/1 cs:408-423*/
        var rawStart = scroll.viewPointToDataIndex(rawSelectionStart)
        var rawEnd = scroll.viewPointToDataIndex(rawSelectionEnd)
        var start = scroll.viewPointToDataIndex(_selectionStart)
        var end = scroll.viewPointToDataIndex(_selectionEnd)

        rawStart -= distance
        rawEnd -= distance
        start -= distance
        end -= distance

        rawSelectionStart = scroll.dataIndexToViewPoint(rawStart)
        rawSelectionEnd = scroll.dataIndexToViewPoint(rawEnd)
        _selectionStart = scroll.dataIndexToViewPoint(start)
        _selectionEnd = scroll.dataIndexToViewPoint(end)
    }
    private fun moveSelectionStartExecuted(direction: Direction) { /*@DONE Selection.MoveSelectionStartExecuted/1 cs:425-461*/
        val dif: Point
        if (direction == Direction.PageUp) {
            dif = Point(0, -scroll.height)
        } else if (direction == Direction.PageDown) {
            dif = Point(0, scroll.height)
        } else if (direction == Direction.Home) {
            val currentStart = scroll.viewPointToDataIndex(_selectionStart)
            val currentRun = model.getNextRun(currentStart)
            if (currentRun == null || currentRun.start > currentStart) {
                dif = Point(-_selectionStart.x, 0) // no run -> jump to start of line
            } else {
                val newStart = currentRun.start
                dif = scroll.dataIndexToViewPoint(newStart) - _selectionStart
            }
        } else if (direction == Direction.End) {
            val currentStart = scroll.viewPointToDataIndex(_selectionStart)
            val currentRun = model.getNextRun(currentStart)
            if (currentRun == null || currentRun.start > currentStart) {
                dif = Point(scroll.width - 1 - _selectionStart.x, 0) // no run -> jump to end of line
            } else {
                val newStart = currentRun.start + currentRun.length - 1
                dif = scroll.dataIndexToViewPoint(newStart) - _selectionStart
            }
        } else {
            dif = ScrollRegion.directionToDif[direction]!!
        }

        val span = getSpan(rawSelectionEnd)
        if (dif.x < 0 || dif.y < 0 || direction == Direction.End) {
            // start from the _front_ of selectionEnd
            selectionStart = span.start + dif
        } else {
            // start from the _back_ of selectionEnd
            selectionStart = span.end + dif
        }
    }
    private fun moveSelectionEndExecuted(direction: Direction) { /*@DONE Selection.MoveSelectionEndExecuted/1 cs:463-499*/
        val dif: Point
        if (direction == Direction.PageUp) {
            dif = Point(0, -scroll.height)
        } else if (direction == Direction.PageDown) {
            dif = Point(0, scroll.height)
        } else if (direction == Direction.Home) {
            val currentStart = scroll.viewPointToDataIndex(_selectionEnd)
            val currentRun = model.getNextRun(currentStart)
            if (currentRun == null || currentRun.start > currentStart) {
                dif = Point(-_selectionEnd.x, 0) // no run -> jump to start of line
            } else {
                val newStart = currentRun.start
                dif = scroll.dataIndexToViewPoint(newStart) - _selectionEnd
            }
        } else if (direction == Direction.End) {
            val currentStart = scroll.viewPointToDataIndex(_selectionEnd)
            val currentRun = model.getNextRun(currentStart)
            if (currentRun == null || currentRun.start > currentStart) {
                dif = Point(scroll.width - 1 - _selectionEnd.x, 0) // no run -> jump to end of line
            } else {
                val newStart = currentRun.start + currentRun.length - 1
                dif = scroll.dataIndexToViewPoint(newStart) - _selectionEnd
            }
        } else {
            dif = ScrollRegion.directionToDif[direction]!!
        }

        val span = getSpan(rawSelectionEnd)
        if (dif.x > 0 || dif.y > 0 || direction == Direction.Home) {
            // start from the _back_ of selectionEnd
            selectionEnd = span.end + dif
        } else {
            // start from the _front_ of selectionEnd
            selectionEnd = span.start + dif
        }
    }
    private fun coerceWidth(width: Int): Int { /*@DONE Selection.CoerceWidth/1 cs:501-515*/
        val desiredWidth = _preferredWidth.limitToRange(1, 0x100)
        if (_preferredWidth == -1 || _preferredWidth == width) return width
        if (!_allowMultipleElementsPerLine) return desiredWidth

        if (desiredWidth < width) {
            var multiple = 2
            while (desiredWidth * multiple <= width) multiple++
            return desiredWidth * (multiple - 1)
        }
        val divisors = getDivisors(desiredWidth).reversed()
        val newWidth = divisors.firstOrNull() ?: 0
        if (newWidth < 4) return desiredWidth
        return newWidth
    }
    companion object {
        private const val defaultPreferredWidth: Int = 0x10
        private fun getDefaultSelectionSpan(p: Point): GetSelectionSpanGetSelectionSpanTuple { /*@DONE Selection.GetDefaultSelectionSpan/1 cs:356-356*/
            return GetSelectionSpanGetSelectionSpanTuple(p, p)
        }
        private fun getDivisors(number: Int): Iterable<Int> { /*@DONE Selection.GetDivisors/1 cs:517-524*/
            val result = ArrayList<Int>()
            // only actually allow for divisors if the preferred width is 0x10
            if (number == 16) {
                for (i in 1..number / 2) {
                    if (number % i == 0) result.add(i)
                }
            }
            return result
        }
        /*@END Selection.Companion*/
    }
    /*@ADD Selection#view_2.txt*/
    private fun gotoExecuted(args: Any?) {
        var args = args
        val gotoArgs = args as? SelectionGotoArgs
        if (gotoArgs != null) args = gotoArgs.text
        if (args is Int) args = args.toHex(6)
        var address = (args?.toString() ?: "").trim()
        if (address.startsWith(ViewPort.gotoMarker.toString())) address = address.substring(1)
        if (address.startsWith(PointerRun.pointerStart.toString())) address = address.substring(1)
        if (address.endsWith(PointerRun.pointerEnd.toString())) address = address.substring(0, address.length - 1)
        if (address.startsWith("0x")) address = address.substring(2)
        var offset = 0
        val addParts = address.split("+")
        val subtractParts = address.split("-")
        if (addParts.size == 2) {
            address = addParts[0]
            val parsed = Ref(0)
            tryParseHexInt(addParts[1], parsed)
            offset = parsed.value
        } else if (subtractParts.size == 2) {
            if (address.startsWith("maps.bank")) {
                // map names end with {bank}-{map}. In this case, don't parse the value after the `-` as an offset.
            } else {
                val parsed = Ref(0)
                if (tryParseHexInt(subtractParts[1], parsed)) {
                    address = subtractParts[0]
                    offset = -parsed.value
                }
            }
        }
        ModelCacheScope.createScope(this.model).using {
            var minSize = -1
            if (address.contains("(") && address.contains(")")) {
                val addressParts = address.split('(', ')').filter { it.isNotEmpty() }
                if (addressParts.isNotEmpty()) address = addressParts[0]
                if (addressParts.size == 2) {
                    val parsed = Ref(0)
                    tryParseHexInt(addressParts[1], parsed)
                    minSize = parsed.value
                }
            }
            var anchor = this.model.getAddressFromAnchor(ModelDelta(), -1, address)
            if (anchor == Pointer.null_ && minSize > 0) {
                val newAnchorStart = model.findFreeSpace(this.model.freeSpaceStart, minSize)
                this.model.observeAnchorWritten(history.currentChange, address, NoInfoRun(newAnchorStart))
                gotoAddress(newAnchorStart + offset)
            } else if (anchor != Pointer.null_) {
                gotoAddress(anchor + offset)
            } else {
                val result = Ref(0)
                if (tryParseHexInt(address, result)) {
                    var resultValue = result.value
                    if (resultValue >= BaseModel.pointerOffset) resultValue -= BaseModel.pointerOffset
                    gotoAddress(resultValue + offset)
                } else {
                    address = address.lowercase().trim()
                    val searchText = address
                    val options = model.getExtendedAutocompleteOptions(searchText) ?: emptyList()
                    if (options.size == 1) {
                        anchor = this.model.getAddressFromAnchor(ModelDelta(), -1, options[0])
                        gotoAddress(anchor + offset)
                    } else if (options.size > 1) {
                        val bestMatches = options.filter { option -> option.lowercase().contains(searchText) }
                        if (bestMatches.size > 0) {
                            val shortestMatch = bestMatches.minByOrNull { match -> match.split("/").last().length }!!
                            anchor = this.model.getAddressFromAnchor(ModelDelta(), -1, shortestMatch)
                            if (anchor == Pointer.null_) {
                                val matches = this.model.getMatchedWords(shortestMatch) ?: emptyList()
                                if (matches.size == 1) {
                                    anchor = matches[0]
                                } else if (matches.size > 1 && gotoArgs != null) {
                                    gotoArgs.container.openSearchResultsTab(shortestMatch, matches.map { match -> ViewPortOpenSearchResultsTabShowSelectionTuple(match, match) })
                                    return
                                }
                            }
                        } else {
                            anchor = this.model.getAddressFromAnchor(ModelDelta(), -1, options[0])
                        }
                        gotoAddress(anchor + offset)
                    } else {
                        onError(this, "Unable to goto address '$address'")
                    }
                }
            }
        }
    }

    private fun backExecuted() {
        if (backStack.size == 0) return
        var selectionPoint = scroll.viewPointToDataIndex(selectionStart)
        if (selectionPoint < scroll.dataIndex || selectionPoint > scroll.dataIndex + scroll.width * scroll.height) selectionPoint = scroll.dataIndex
        val backInfo = backStack.removeLast()
        if (backStack.size == 0) backward.raiseCanExecuteChanged()
        if (backInfo.tab != null) {
            requestTabChanged(this, SelectionTabChangeArgs(backInfo.tab, true))
            return
        }
        forwardStack.addLast(JumpInfo(scroll.dataIndex, selectionPoint))
        if (forwardStack.size == 1) _forward.raiseCanExecuteChanged()
        gotoAddressHelper(backInfo.viewStart)
        selectionStart = scroll.dataIndexToViewPoint(backInfo.selectionStart)
    }

    private fun forwardExecuted() {
        if (forwardStack.size == 0) return
        var selectionPoint = scroll.viewPointToDataIndex(selectionStart)
        if (selectionPoint < scroll.dataIndex || selectionPoint > scroll.dataIndex + scroll.width * scroll.height) selectionPoint = scroll.dataIndex
        val forwardInfo = forwardStack.removeLast()
        if (forwardStack.size == 0) _forward.raiseCanExecuteChanged()
        if (forwardInfo.tab != null) {
            requestTabChanged(this, SelectionTabChangeArgs(forwardInfo.tab, false))
            return
        }
        backStack.addLast(JumpInfo(scroll.dataIndex, selectionPoint))
        if (backStack.size == 1) backward.raiseCanExecuteChanged()
        gotoAddressHelper(forwardInfo.viewStart)
        selectionStart = scroll.dataIndexToViewPoint(forwardInfo.selectionStart)
    }
    /*@ENDADD Selection#view_2.txt*/
    /*@END Selection*/
}

data class GetSelectionSpanGetSelectionSpanTuple(val start: Point, val end: Point)
