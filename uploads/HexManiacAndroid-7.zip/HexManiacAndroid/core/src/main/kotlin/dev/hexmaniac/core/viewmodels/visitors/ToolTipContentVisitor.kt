// Port of ViewModels/Visitors/ToolTipContentVisitor.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.images.*

open class ToolTipContentVisitor : IDataFormatVisitor { // cs:14-208
    private lateinit var model: IDataModel
    constructor(model: IDataModel) { /*@DONE ToolTipContentVisitor.<init>/1 cs:17-19*/
        this.model = model
    }
    var content: ObservableCollection<Any> = /*@INITAUTO ToolTipContentVisitor.Content cs:21-21*/ ObservableCollection() /*@ENDINIT*/
        private set
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE ToolTipContentVisitor.Visit/1 cs:23-23*/
        // nothing to show
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE ToolTipContentVisitor.Visit/2 cs:25-25*/
        // nothing to show
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE ToolTipContentVisitor.Visit/3 cs:27-27*/
        // nothing to show
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE ToolTipContentVisitor.Visit/4 cs:29-47*/
        content.add(pointer.destinationAsText)
        val destinationRun = model.getNextRun(pointer.destination) ?: NoInfoRun.nullRun
        val runSpecificContent = buildContentForRun(model, pointer.source, pointer.destination, destinationRun)
        if (runSpecificContent != null) {
            // special case: add images for pointers to OWs
            if (destinationRun is ITableRun && destinationRun.elementCount == 1 && destinationRun.elementContent.any { seg -> seg.name == "sprites" }) {
                val source = destinationRun.start + destinationRun.elementContent.takeWhile { seg -> seg.name != "sprites" }.sumOf { seg -> seg.length }
                val osl = model.getNextRun(model.readPointer(source))
                if (osl is OverworldSpriteListRun) {
                    val spriteRun = model.getNextRun(osl.readPointer(model, 0, 0))
                    if (spriteRun is ISpriteRun) {
                        val pals = spriteRun.findRelatedPalettes(model, source)
                        val image = ReadonlyPixelViewModel.create(model, spriteRun, pals.firstOrNull(), true)
                        if (image != null) content.add(image)
                    }
                }
            }
            content.add(runSpecificContent)
        }
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE ToolTipContentVisitor.Visit/5 cs:83-83*/
        anchor.originalFormat!!.visit(this, data)
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE ToolTipContentVisitor.Visit/6 cs:85-85*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE ToolTipContentVisitor.Visit/7 cs:87-87*/
        decorator.originalFormat!!.visit(this, data)
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE ToolTipContentVisitor.Visit/8 cs:89-89*/
        // nothing to show
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE ToolTipContentVisitor.Visit/9 cs:91-91*/
        // nothing to show
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE ToolTipContentVisitor.Visit/10 cs:93-93*/
        // nothing to show
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE ToolTipContentVisitor.Visit/11 cs:95-95*/
        // nothing to show
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE ToolTipContentVisitor.Visit/12 cs:97-97*/
        // nothing to show
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE ToolTipContentVisitor.Visit/13 cs:99-109*/
        val wordRun = model.getNextRun(integer.source)
        if (wordRun is WordRun) {
            var desiredToolTip = wordRun.sourceArrayName
            if (wordRun.multOffset != 1) desiredToolTip += "*" + wordRun.multOffset
            if (wordRun.valueOffset > 0) desiredToolTip += "+" + wordRun.valueOffset
            if (wordRun.valueOffset < 0) desiredToolTip += wordRun.valueOffset
            val note = wordRun.note
            if (!note.isNullOrEmpty()) desiredToolTip += NEW_LINE + note
            desiredToolTip += NEW_LINE + "Changing one copy of a constant will automatically update all other copies."
            content.add(desiredToolTip)
        }
    }
    override fun visit(integer: IntegerEnum, data: Int) { /*@DONE ToolTipContentVisitor.Visit/14 cs:111-123*/
        content.add(integer.valueNew)

        val containingTable = model.getNextRun(integer.source)
        if (containingTable !is ITableRun) return
        val offset = containingTable.convertByteOffsetToArrayOffset(integer.source)
        val enumValue = model.readMultiByteValue(offset.segmentStart, containingTable.elementContent[offset.segmentIndex].length)
        var segment = containingTable.elementContent[offset.segmentIndex]
        if (segment is ArrayRunRecordSegment) segment = segment.createConcrete(model, integer.source)
        if (segment !is ArrayRunEnumSegment) return
        val parentAddress = model.getAddressFromAnchor(ModelDelta(), -1, segment.enumName)
        val parentArray = model.getNextRun(parentAddress)
        if (parentArray !is ArrayRun) return
        getEnumImage(model, content, enumValue, parentArray)
    }
    override fun visit(integer: IntegerHex, data: Int) { /*@DONE ToolTipContentVisitor.Visit/15 cs:149-149*/
        // nothing to show
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE ToolTipContentVisitor.Visit/16 cs:151-151*/
        // nothing to show
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE ToolTipContentVisitor.Visit/17 cs:153-153*/
        // nothing to show
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE ToolTipContentVisitor.Visit/18 cs:155-155*/
        content.add(item.toString())
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE ToolTipContentVisitor.Visit/19 cs:157-175*/
        ModelCacheScope.createScope(model).using {
            val table = model.getNextRun(array.source) as ITableRun
            val offset = table.convertByteOffsetToArrayOffset(array.source)
            val segment = table.elementContent[offset.segmentIndex] as? ArrayRunBitArraySegment
            val options = segment?.getOptions(model)?.toList()
            if (options != null) {
                for (i in 0 until array.length) {
                    val group = i * 8
                    var j = 0
                    while (j < 8 && group + j < options.size) {
                        val bit = (model[array.source + i] shr j) and 1
                        if (bit != 0) content.add(options[group + j])
                        j++
                    }
                }

                if (content.size == 0) content.add("- None -")
            }
            Unit
        }
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE ToolTipContentVisitor.Visit/20 cs:177-177*/
        content.add(word.name)
    }
    override fun visit(stream: EndStream, data: Int) { /*@DONE ToolTipContentVisitor.Visit/21 cs:179-179*/
        // nothing to show
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE ToolTipContentVisitor.Visit/22 cs:181-187*/
        content.add("This byte marks the start of an LZ compressed data section.")
        content.add("After the identifier byte and the length, compressed data consists of 3 types of tokens:")
        content.add("(1) a 1 byte section header, telling you which of the next 8 tokens are compressed.")
        content.add("(2) A raw uncompressed byte.")
        content.add("(3) A 2-byte token representing anywhere from 3 to 18 compressed bytes.")
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE ToolTipContentVisitor.Visit/23 cs:189-189*/
        // nothing to show
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE ToolTipContentVisitor.Visit/24 cs:191-191*/
        // nothing to show
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE ToolTipContentVisitor.Visit/25 cs:193-193*/
        // nothing to show
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE ToolTipContentVisitor.Visit/26 cs:195-195*/
        // nothing to show
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE ToolTipContentVisitor.Visit/27 cs:197-197*/
        content.add(tuple.toString())
    }
    companion object {
        fun buildContentForRun(model: IDataModel, source: Int, destination: Int, destinationRun: IFormattedRun, preferredPaletteStart: Int = -1, preferredSpritePage: Int = 0): Any? { /*@DONE ToolTipContentVisitor.BuildContentForRun/1 cs:49-81*/
            if (destination != destinationRun.start) return null
            if (destinationRun is ISpriteRun) {
                val sprite = destinationRun
                if (sprite is LzTilemapRun) sprite.findMatchingTileset(model)
                val paletteRuns = sprite.findRelatedPalettes(model, source)
                var paletteRun: IPaletteRun? = paletteRuns.firstOrNull()
                if (preferredPaletteStart >= 0) {
                    paletteRun = paletteRuns.firstOrNull { pRun -> pRun.start == preferredPaletteStart } ?: (model.getNextRun(preferredPaletteStart) as? IPaletteRun)
                }
                var tableIndex = -1
                val tableRun = model.getNextRun(source)
                if (tableRun is ITableRun) tableIndex = tableRun.convertByteOffsetToArrayOffset(source).elementIndex
                val pixels = sprite.getPixels(model, preferredSpritePage, tableIndex)
                if (pixels == null) return null
                val colors: List<Short> = paletteRun?.allColors(model) ?: TileViewModel.createDefaultPalette(Math.pow(2.0, sprite.spriteFormat.bitsPerPixel.toDouble()).toInt()).toList()
                val imageData = SpriteTool.render(pixels, colors, paletteRun?.paletteFormat?.initialBlankPages ?: 0, 0)
                return ReadonlyPixelViewModel(sprite.spriteFormat, imageData, colors[0])
            } else if (destinationRun is IPaletteRun) {
                val colors = destinationRun.getPalette(model, 0) ?: return null
                return ReadonlyPaletteCollection(colors)
            } else if (destinationRun is IStreamRun) {
                var lines = (destinationRun.serializeRun() ?: "").split(NEW_LINE).toMutableList()
                if (lines.size > 20) lines = lines.take(20).toMutableList()
                return ellipsedLines(lines.toTypedArray())
            } else if (destinationRun is ArrayRun) {
                val stream = StringBuilder()
                destinationRun.appendTo(model, stream, destinationRun.start, destinationRun.elementLength * Math.min(20, destinationRun.elementCount), 0)
                return ellipsedLines(stream.toString().splitLines().toList().toTypedArray())
            } else if (destinationRun is BlockmapRun) {
                val canvas = model.currentCacheScope.getImage(destinationRun)
                if (canvas == null) return null
                return ReadonlyPixelViewModel(canvas.pixelWidth, canvas.pixelHeight, canvas.pixelData, canvas.transparent)
            } else {
                return null
            }
        }
        fun getEnumImage(model: IDataModel, enumValue: Int, parentArray: ArrayRun?): IPixelViewModel? { /*@DONE ToolTipContentVisitor.GetEnumImage/1 cs:125-142*/
            if (parentArray == null) return null
            for (array in model.getRelatedArrays(parentArray)) {
                var segOffset = 0
                for (seg in array.elementContent) {
                    val itemIndex = enumValue + array.parentOffset.beginningMargin
                    val source = array.start + array.elementLength * itemIndex + segOffset
                    if (source < 0 || source >= model.count) continue
                    val destination = model.readPointer(array.start + array.elementLength * itemIndex + segOffset)
                    segOffset += seg.length
                    if (seg.type != ElementContentType.Pointer) continue
                    val spriteRun = model.getNextRun(destination)
                    if (spriteRun !is ISpriteRun) continue
                    val paletteRuns = spriteRun.findRelatedPalettes(model, array.start + array.elementLength * itemIndex)
                    return ReadonlyPixelViewModel.create(model, spriteRun, paletteRuns.firstOrNull(), true)
                }
            }
            return null
        }
        fun getEnumImage(model: IDataModel, content: ObservableCollection<Any>, enumValue: Int, parentArray: ArrayRun) { /*@DONE ToolTipContentVisitor.GetEnumImage/2 cs:144-147*/
            val result = getEnumImage(model, enumValue, parentArray)
            if (result != null) content.add(result)
        }
        fun ellipsedLines(lines: Array<String>): String { /*@DONE ToolTipContentVisitor.EllipsedLines/1 cs:199-207*/
            val maxLength = 70

            for (i in 0 until lines.size) {
                if (lines[i].length > maxLength) lines[i] = lines[i].substring(0, maxLength - 3) + "..."
            }

            return lines.joinToString(NEW_LINE)
        }
        /*@END ToolTipContentVisitor.Companion*/
    }
    /*@END ToolTipContentVisitor*/
}
