// Port of ViewModels/Tools/TableGroupViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.map.*

open class ObservableList<T> : ArrayList<T>, INotifyCollectionChanged { // cs:20-27
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    constructor() : super() { /*@DONE ObservableList.<init>/1 cs:23-23*/
        // nothing to do: the list starts empty
    }
    constructor(items: Iterable<T>) : super(items.toList()) { /*@DONE ObservableList.<init>/2 cs:24-24*/
        // nothing to do: the base list is initialized from items
    }
    fun raiseRefresh() { /*@DONE ObservableList.RaiseRefresh/1 cs:26-26*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset))
    }
    /*@END ObservableList*/
}

open class TableGroupViewModel : ViewModelCore { // cs:29-272
    private var _isOpen: Boolean = false
    private var currentMember: Int = 0
    private var _groupName: String = ""
    val displayHeader: Boolean
        get() { /*@DONE TableGroupViewModel.DisplayHeader.get cs:36-36*/
            return _groupName != defaultName
        }
    var groupName: String
        get() { /*@DONE TableGroupViewModel.GroupName.get cs:37-37*/
            return _groupName
        }
        set(value) { /*@DONE TableGroupViewModel.GroupName.set cs:37-37*/
            set(_groupName, value, "groupName", { _groupName = it }, { _ -> notifyPropertyChanged("displayHeader") })
        }
    private lateinit var viewPort: ViewPort
    var members: ObservableCollection<IArrayElementViewModel> = /*@INITDONE TableGroupViewModel.Members cs:41-41*/ ObservableCollection() /*@ENDINIT*/
        private set
    lateinit var forwardModelChanged: (IStreamArrayElementViewModel) -> Unit
    lateinit var forwardModelDataMoved: (IStreamArrayElementViewModel) -> Unit
    constructor(viewPort: ViewPort) { /*@DONE TableGroupViewModel.<init>/1 cs:46-46*/
        groupName = defaultName
        this.viewPort = viewPort
    }
    val isOpen: Boolean
        get() { /*@DONE TableGroupViewModel.IsOpen.get cs:48-48*/
            return _isOpen
        }
    fun open() { /*@DONE TableGroupViewModel.Open/1 cs:50-54*/
        if (_isOpen) return
        currentMember = 0
        _isOpen = true
    }
    private var _useMultiFieldFeature: Boolean = /*@INITAUTO TableGroupViewModel.useMultiFieldFeature cs:56-56*/ false /*@ENDINIT*/
    var useMultiFieldFeature: Boolean
        get() { /*@DONE TableGroupViewModel.UseMultiFieldFeature.get cs:57-57*/
            return _useMultiFieldFeature
        }
        set(value) { /*@DONE TableGroupViewModel.UseMultiFieldFeature.set cs:57-57*/
            set(_useMultiFieldFeature, value, "useMultiFieldFeature", { _useMultiFieldFeature = it })
        }
    private var multiInProgress: MultiFieldArrayElementViewModel? = null
    fun add(child: IArrayElementViewModel?) { /*@DONE TableGroupViewModel.Add/1 cs:61-91*/
        if (child == null) return
        if (_useMultiFieldFeature && child is IMultiEnabledArrayElementViewModel) {
            var inProgress = multiInProgress
            if (inProgress == null) {
                inProgress = MultiFieldArrayElementViewModel(viewPort)
                multiInProgress = inProgress
            }
            inProgress.add(child)
        } else if (currentMember == members.size) {
            val inProgress = multiInProgress
            if (inProgress != null) {
                members.add(inProgress)
                multiInProgress = null
                currentMember++
            }
            members.add(child)
            currentMember++
        } else {
            val inProgress = multiInProgress
            if (inProgress != null) {
                if (members[currentMember].tryCopy(inProgress)) {
                    // no need to copy
                } else {
                    members[currentMember] = inProgress
                }
                multiInProgress = null
                currentMember++
                add(child) // we're adding a non-multi, and now have dealt with the current multi. Recurse so the child can be added using either "full" or "replace" strategy
            } else if (members[currentMember].tryCopy(child)) {
                currentMember += 1 // copied over successfully
            } else {
                // replace existing
                members[currentMember] = child
                currentMember += 1
            }
        }
    }
    fun close() { /*@DONE TableGroupViewModel.Close/1 cs:93-106*/
        if (!_isOpen) return
        val inProgress = multiInProgress
        if (inProgress != null) {
            if (currentMember == members.size) {
                members.add(inProgress)
            } else if (!members[currentMember].tryCopy(inProgress)) {
                members[currentMember] = inProgress
            }
            currentMember += 1
            multiInProgress = null
        }
        while (members.size > currentMember) members.removeAt(members.size - 1)
        _isOpen = false
    }
    fun addChildrenFromTable(viewPort: ViewPort, selection: Selection, table: ITableRun, index: Int, header: SplitterArrayElementViewModel, helperGroup: TableGroupViewModel, splitPortion: Int = -1) { /*@DONE TableGroupViewModel.AddChildrenFromTable/1 cs:108-168*/
        var itemAddress = table.start + table.elementLength * index
        val originalItemAddress = itemAddress
        var currentPartition = 0
        for (itemSegment in table.elementContent) {
            var item: ArrayRunElementSegment = itemSegment
            if (item is ArrayRunRecordSegment) item = item.createConcrete(viewPort.model, table, itemAddress)

            if (itemSegment is ArrayRunSplitterSegment) {
                currentPartition += 1
                continue
            } else if (splitPortion != -1 && splitPortion != currentPartition) {
                itemAddress += item.length
                continue
            }

            var viewModel: IArrayElementViewModel? = null
            if (item.type == ElementContentType.Unknown) viewModel = FieldArrayElementViewModel(viewPort, item.name, itemAddress, item.length, HexFieldStrategy.instance)
            else if (item.type == ElementContentType.PCS) viewModel = FieldArrayElementViewModel(viewPort, item.name, itemAddress, item.length, TextFieldStrategy())
            else if (item.type == ElementContentType.Pointer) viewModel = FieldArrayElementViewModel(viewPort, item.name, itemAddress, item.length, AddressFieldStrategy())
            else if (item.type == ElementContentType.BitArray) viewModel = BitListArrayElementViewModel(viewPort, item.name, itemAddress)
            else if (item.type == ElementContentType.Integer) {
                if (item is ArrayRunEnumSegment) {
                    viewModel = ComboBoxArrayElementViewModel(viewPort, selection, item.name, itemAddress, item.length)
                    val anchor = viewPort.model.getAnchorFromAddress(-1, table.start)
                    val enumSourceTableStart = viewPort.model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, item.enumName)
                    if (anchor.isNotEmpty()) {
                        val dependentArrays = viewPort.model.getDependantArrays(anchor).toList()
                        if (dependentArrays.size == 1 && enumSourceTableStart >= 0 && dependentArrays[0].elementContent[0] is ArrayRunBitArraySegment) {
                            add(viewModel)
                            viewModel = BitListArrayElementViewModel(viewPort, item.name, itemAddress)
                        }
                    }
                } else if (item is ArrayRunTupleSegment) {
                    viewModel = TupleArrayElementViewModel(viewPort, item, itemAddress)
                } else if (item is ArrayRunHexSegment) {
                    viewModel = FieldArrayElementViewModel(viewPort, item.name, itemAddress, item.length, HexFieldStrategy.instance)
                } else if (item is ArrayRunColorSegment) {
                    viewModel = ColorFieldArrayElementViewModel(viewPort, item.name, itemAddress)
                } else if (item is ArrayRunCalculatedSegment) {
                    viewModel = CalculatedElementViewModel(viewPort, item, originalItemAddress)
                } else if (item is ArrayRunPythonButtonSegment) {
                    viewModel = PythonButtonElementViewModel(viewPort, item, originalItemAddress)
                } else if (item is ArrayRunOffsetRenderSegment) {
                    viewModel = OffsetRenderViewModel(viewPort, item, itemAddress)
                } else if (item is ArrayRunSignedSegment) {
                    viewModel = FieldArrayElementViewModel(viewPort, item.name, itemAddress, item.length, SignedFieldStrategy.instance)
                } else {
                    viewModel = FieldArrayElementViewModel(viewPort, item.name, itemAddress, item.length, NumericFieldStrategy())
                }
            } else {
                throw NotImplementedError()
            }
            if (!item.isUnused() && viewModel != null) {
                add(viewModel)
                helperGroup.addChildrenFromPointerSegment(viewPort, itemAddress, item, viewModel, header, 0)
            }
            itemAddress += item.length
        }
        addAdhocSpecialElementsToGroup(viewPort, table)
    }
    private fun addAdhocSpecialElementsToGroup(viewPort: IViewPort, table: ITableRun) { /*@DONE TableGroupViewModel.AddAdhocSpecialElementsToGroup/1 cs:170-188*/
        val nonEmeraldTypes = listOf(
            ElementContentType.Pointer, ElementContentType.Pointer, ElementContentType.Pointer, ElementContentType.Pointer,
            ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer,
            ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer,
            ElementContentType.Integer, ElementContentType.Integer)
        val emeraldTypes = listOf(
            ElementContentType.Pointer, ElementContentType.Pointer, ElementContentType.Pointer, ElementContentType.Pointer,
            ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer,
            ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer, ElementContentType.Integer,
            ElementContentType.Integer)
        if (!viewPort.model!!.isEmerald() && table.elementContent.size == 14 && table.elementCount == 1 && table.elementContent.map { seg -> seg.type } == nonEmeraldTypes) {
            addAdhocMapElementsToGroup(viewPort, table)
        }

        if (viewPort.model!!.isEmerald() && table.elementContent.size == 13 && table.elementCount == 1 && table.elementContent.map { seg -> seg.type } == emeraldTypes) {
            addAdhocMapElementsToGroup(viewPort, table)
        }
    }
    private fun addAdhocMapElementsToGroup(viewPort: IViewPort, table: ITableRun) { /*@DONE TableGroupViewModel.AddAdhocMapElementsToGroup/1 cs:190-211*/
        val model = viewPort.model!!
        val tableSources = table.pointerSources
        if (tableSources == null || tableSources.size != 1) return
        val addressInBankTable = tableSources[0]
        val bankTable = model.getNextRun(addressInBankTable) as? ITableRun
        if (bankTable == null) return
        val bankSources = bankTable.pointerSources
        if (bankSources == null || bankSources.size != 1) return
        val topTable = model.getNextRun(bankSources[0]) as? ITableRun
        if (topTable == null) return
        val bankOffset = topTable.convertByteOffsetToArrayOffset(bankSources[0])
        val mapOffset = bankTable.convertByteOffsetToArrayOffset(addressInBankTable)
        val bank = bankOffset.elementIndex
        val map = mapOffset.elementIndex
        val name = "maps.bank" + bank + BlockMapViewModel.mapIDToText(model, bank, map)
        val matches = model.getMatchingMaps(name)
        if (matches.size != 1) return
        val mapModel = MapModel(ModelArrayElement(model, table.start, 0, { viewPort.changeHistory.currentChange }, table))
        val blockMapStart = mapModel.layout?.blockMap?.start
        val blockmapRun = if (blockMapStart != null) model.getNextRun(blockMapStart) as? BlockmapRun else null
        if (blockmapRun != null) {
            val image = model.currentCacheScope.getImage(blockmapRun) as? CanvasPixelViewModel
            if (image != null) {
                image.spriteScale = 128.0 / Math.max(image.pixelWidth, image.pixelHeight)
                add(SpriteIndicatorElementViewModel(image))
            }
        }
        add(ButtonArrayElementViewModel("Edit Map", { viewPort.goto?.execute(name) }))
    }
    private fun addChildrenFromPointerSegment(viewPort: ViewPort, itemAddress: Int, item: ArrayRunElementSegment, parent: IArrayElementViewModel, header: SplitterArrayElementViewModel, recursionLevel: Int) { /*@DONE TableGroupViewModel.AddChildrenFromPointerSegment/1 cs:213-271*/
        val pointerSegment = item as? ArrayRunPointerSegment
        if (pointerSegment == null) return
        if (pointerSegment.innerFormat == "") return
        val destination = viewPort.model.readPointer(itemAddress)
        var streamRun: IFormattedRun? = null
        if (destination != Pointer.null_) {
            streamRun = viewPort.model.getNextRun(destination)
            if (!pointerSegment.destinationDataMatchesPointerFormat(viewPort.model, NoDataChangeDeltaModel(), itemAddress, destination, null, -1)) streamRun = null
            if (streamRun != null && streamRun.start != destination) {
                // For some reason (possibly because of a run length conflict),
                //    the destination data appears to match the expected type,
                //    but there is no run for it.
                // Go ahead and generate a new temporary run for the data.
                val strategy = viewPort.model.formatRunFactory.getStrategy(pointerSegment.innerFormat)
                val runRef = Ref<IFormattedRun?>(streamRun)
                strategy?.tryParseData(viewPort.model, "", destination, runRef)
                streamRun = runRef.value
            }
        }

        var streamElement: IStreamArrayElementViewModel? = null
        if (streamRun == null || streamRun is IStreamRun || streamRun is ITableRun) streamElement = TextStreamElementViewModel(viewPort, item.name, itemAddress, pointerSegment.innerFormat)
        if (streamRun is ISpriteRun) streamElement = SpriteElementViewModel(viewPort, item.name, streamRun.formatString, streamRun.spriteFormat, itemAddress)
        if (streamRun is IPaletteRun) streamElement = PaletteElementViewModel(viewPort, viewPort.changeHistory, item.name, streamRun.formatString, streamRun.paletteFormat, itemAddress)
        if (streamRun is TrainerPokemonTeamRun) streamElement = TrainerPokemonTeamElementViewModel(viewPort, streamRun, item.name, itemAddress)
        if (streamElement == null) return
        streamElement.parent = header

        val streamAddress = itemAddress
        val myIndex = currentMember
        parent.dataChanged += { _, _ ->
            val closureDestination = viewPort.model.readPointer(streamAddress)
            val run = viewPort.model.getNextRun(closureDestination) as? IStreamRun
            var newStream: IStreamArrayElementViewModel? = null

            if (run == null || run is IStreamRun) newStream = TextStreamElementViewModel(viewPort, item.name, streamAddress, pointerSegment.innerFormat)
            if (run is ISpriteRun) newStream = SpriteElementViewModel(viewPort, item.name, run.formatString, run.spriteFormat, streamAddress)
            if (run is IPaletteRun) newStream = PaletteElementViewModel(viewPort, viewPort.changeHistory, item.name, run.formatString, run.paletteFormat, streamAddress)

            if (newStream != null) {
                forwardModelChanged(newStream)
                forwardModelDataMoved(newStream)
                // using var scope = Members[myIndex].SilencePropertyNotifications();
                if (!members[myIndex].tryCopy(newStream)) members[myIndex] = newStream
            }
        }
        forwardModelDataMoved(streamElement)
        add(streamElement)

        if (streamRun is ITableRun && recursionLevel < 1) {
            var segmentOffset = 0
            for (i in 0 until streamRun.elementContent.size) {
                if (streamRun.elementContent[i] !is ArrayRunPointerSegment) {
                    segmentOffset += streamRun.elementContent[i].length
                    continue
                }
                for (j in 0 until streamRun.elementCount) {
                    val nestedAddress = streamRun.start + segmentOffset + j * streamRun.elementLength
                    addChildrenFromPointerSegment(viewPort, nestedAddress, streamRun.elementContent[i], streamElement, header, recursionLevel + 1)
                }
                segmentOffset += streamRun.elementContent[i].length
            }
        }
    }
    companion object {
        const val defaultName: String = "Other"
        /*@END TableGroupViewModel.Companion*/
    }
    /*@END TableGroupViewModel*/
}
