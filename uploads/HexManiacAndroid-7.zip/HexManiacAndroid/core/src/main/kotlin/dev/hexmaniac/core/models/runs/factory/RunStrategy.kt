// Port of Models/Runs/Factory/RunStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

abstract class RunStrategy { // cs:8-52
    var format: String? = null
    abstract fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int
    abstract fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean
    abstract fun matches(run: IFormattedRun?): Boolean
    abstract fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun
    abstract fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>)
    abstract fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo?
    protected fun getTable(model: IDataModel, pointerAddress: Int): ITableRun? { /*@DONE RunStrategy.GetTable/1 cs:46-46*/
        return model.getNextRun(pointerAddress) as ITableRun?
    }
    protected fun getSegment(table: ITableRun, pointerAddress: Int): ArrayRunPointerSegment { /*@DONE RunStrategy.GetSegment/1 cs:48-51*/
        val offsets = table.convertByteOffsetToArrayOffset(pointerAddress)
        return table.elementContent[offsets.segmentIndex] as ArrayRunPointerSegment
    }
    /*@END RunStrategy*/
}

interface IFormatRunFactory { // cs:54-56
    fun getStrategy(format: String, allowStreamCompressionErrors: Boolean = false): RunStrategy?
    /*@END IFormatRunFactory*/
}

open class FormatRunFactory : IFormatRunFactory { // cs:58-119
    private var showFullIVByteRange: Boolean = false
    constructor(showFullIVByteRange: Boolean) { /*@DONE FormatRunFactory.<init>/1 cs:60-60*/
        this.showFullIVByteRange = showFullIVByteRange
    }
    override fun getStrategy(format: String, allowStreamCompressionErrors: Boolean): RunStrategy? { /*@DONE FormatRunFactory.GetStrategy/1 cs:62-118*/
        val strategy: RunStrategy
        val spriteFormat = Ref(SpriteFormat())
        val paletteFormat = Ref(PaletteFormat())
        val tilesetFormat = Ref(TilesetFormat())
        val lzTilesetFormat = Ref(TilesetFormat())
        val tilemapFormat = Ref(TilemapFormat())
        val tilemapFormat1 = Ref(TilemapFormat())
        val spriteFormat1 = Ref(SpriteFormat())
        val paletteFormat1 = Ref(PaletteFormat())
        if (format == PCSRun.sharedFormatString) {
            strategy = PCSRunContentStrategy()
        } else if (format.startsWith(AsciiRun.sharedFormatString)) {
            strategy = AsciiRunContentStrategy()
        } else if (format == BrailleRun.sharedFormatString) {
            strategy = BrailleRunContentStrategy()
        } else if (format == EggMoveRun.sharedFormatString) {
            strategy = EggRunContentStrategy()
        } else if (format == PIERun.sharedFormatString) {
            strategy = PIERunContentStrategy()
        } else if (format == PLMRun.sharedFormatString) {
            strategy = PLMRunContentStrategy()
        } else if (format == XSERun.sharedFormatString) {
            strategy = XseRunContentStrategy()
        } else if (format == BSERun.sharedFormatString) {
            strategy = BseRunContentStrategy()
        } else if (format == ASERun.sharedFormatString) {
            strategy = AseRunContentStrategy()
        } else if (format == TSERun.sharedFormatString) {
            strategy = TseRunContentStrategy()
        } else if (format.startsWith(OverworldSpriteListRun.sharedFormatString.substring(0, OverworldSpriteListRun.sharedFormatString.length - 1))) {
            strategy = OverworldSpriteListContentStrategy(this, format)
        } else if (format == TrainerPokemonTeamRun.sharedFormatString) {
            strategy = TrainerPokemonTeamRunContentStrategy(showFullIVByteRange)
        } else if (format == MapAnimationTilesRun.sharedFormatString) {
            strategy = MapAnimationTilesStrategy()
        } else if (LzSpriteRun.tryParseSpriteFormat(format, spriteFormat)) {
            if (allowStreamCompressionErrors) spriteFormat.value = SpriteFormat(spriteFormat.value.bitsPerPixel, spriteFormat.value.tileWidth, spriteFormat.value.tileHeight, spriteFormat.value.paletteHint, allowStreamCompressionErrors)
            strategy = LzSpriteRunContentStrategy(spriteFormat.value)
        } else if (LzPaletteRun.tryParsePaletteFormat(format, paletteFormat)) {
            if (allowStreamCompressionErrors) paletteFormat.value = PaletteFormat(paletteFormat.value.bits, paletteFormat.value.pages, paletteFormat.value.initialBlankPages, allowStreamCompressionErrors)
            strategy = LzPaletteRunContentStrategy(paletteFormat.value)
        } else if (TilesetRun.tryParseTilesetFormat(format, tilesetFormat)) {
            strategy = TilesetRunContentStrategy(tilesetFormat.value)
        } else if (LzTilesetRun.tryParseTilesetFormat(format, lzTilesetFormat)) {
            strategy = LzTilesetRunContentStrategy(lzTilesetFormat.value)
        } else if (LzTilemapRun.tryParseTilemapFormat(format, tilemapFormat)) {
            strategy = LzTilemapRunContentStrategy(tilemapFormat.value)
        } else if (TilemapRun.tryParseTilemapFormat(format, tilemapFormat1)) {
            strategy = TilemapRunContentStrategy(tilemapFormat1.value)
        } else if (SpriteRun.tryParseSpriteFormat(format, spriteFormat1)) {
            strategy = SpriteRunContentStrategy(spriteFormat1.value)
        } else if (format == BlockmapRun.sharedFormatString) {
            strategy = BlockmapRunContentStrategy()
        } else if (PaletteRun.tryParsePaletteFormat(format, paletteFormat1)) {
            strategy = PaletteRunContentStrategy(paletteFormat1.value)
        } else if (format.indexOf("[") >= 0 && format.indexOf("[") < format.indexOf("]")) {
            strategy = TableStreamRunContentStrategy()
        } else {
            return null
        }

        strategy.format = format
        return strategy
    }
    /*@END FormatRunFactory*/
}

open class XseRunContentStrategy : RunStrategy() { // cs:121-150
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE XseRunContentStrategy.LengthForNewRun/1 cs:122-122*/
        return 1
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE XseRunContentStrategy.Matches/1 cs:124-124*/
        return run is XSERun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE XseRunContentStrategy.TryAddFormatAtDestination/1 cs:126-134*/
        val newRun = XSERun(destination, SortedSpan(source))
        if (newRun.length < 1) return false
        if (token !is NoDataChangeDeltaModel) {
            owner.clearFormat(token, newRun.start, newRun.length)
            owner.observeRunWritten(token, newRun)
        }
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE XseRunContentStrategy.TryParseData/1 cs:136-139*/
        run.value = XSERun(dataIndex, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE XseRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:141-144*/
        if (run.value is XSERun) return
        run.value = XSERun(run.value.start, run.value.pointerSources)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE XseRunContentStrategy.WriteNewRun/1 cs:146-149*/
        token.changeData(owner, destination, 2)
        return XSERun(destination)
    }
    /*@END XseRunContentStrategy*/
}

open class BseRunContentStrategy : RunStrategy() { // cs:152-181
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE BseRunContentStrategy.LengthForNewRun/1 cs:153-153*/
        return 1
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE BseRunContentStrategy.Matches/1 cs:155-155*/
        return run is BSERun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE BseRunContentStrategy.TryAddFormatAtDestination/1 cs:157-165*/
        val newRun = BSERun(destination, SortedSpan(source))
        if (newRun.length < 1) return false
        if (token !is NoDataChangeDeltaModel) {
            owner.clearFormat(token, newRun.start, newRun.length)
            owner.observeRunWritten(token, newRun)
        }
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE BseRunContentStrategy.TryParseData/1 cs:168-171*/
        run.value = BSERun(dataIndex, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE BseRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:173-175*/
        run.value = BSERun(run.value.start, run.value.pointerSources)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE BseRunContentStrategy.WriteNewRun/1 cs:177-180*/
        token.changeData(owner, destination, 0x3d) // end
        return BSERun(destination, SortedSpanStatic.one(source))
    }
    /*@END BseRunContentStrategy*/
}

open class AseRunContentStrategy : RunStrategy() { // cs:183-212
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE AseRunContentStrategy.LengthForNewRun/1 cs:184-184*/
        return 1
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE AseRunContentStrategy.Matches/1 cs:186-186*/
        return run is ASERun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE AseRunContentStrategy.TryAddFormatAtDestination/1 cs:188-196*/
        val newRun = ASERun(destination, SortedSpan(source))
        if (newRun.length < 1) return false
        if (token !is NoDataChangeDeltaModel) {
            owner.clearFormat(token, newRun.start, newRun.length)
            owner.observeRunWritten(token, newRun)
        }
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE AseRunContentStrategy.TryParseData/1 cs:199-202*/
        run.value = ASERun(dataIndex, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE AseRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:204-206*/
        run.value = ASERun(run.value.start, run.value.pointerSources)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE AseRunContentStrategy.WriteNewRun/1 cs:208-211*/
        token.changeData(owner, destination, 0x8) // end
        return ASERun(destination, SortedSpanStatic.one(source))
    }
    /*@END AseRunContentStrategy*/
}

open class TseRunContentStrategy : RunStrategy() { // cs:214-243
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE TseRunContentStrategy.LengthForNewRun/1 cs:215-215*/
        return 1
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE TseRunContentStrategy.Matches/1 cs:217-217*/
        return run is TSERun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE TseRunContentStrategy.TryAddFormatAtDestination/1 cs:219-227*/
        val newRun = TSERun(destination, SortedSpan(source))
        if (newRun.length < 1) return false
        if (token !is NoDataChangeDeltaModel) {
            owner.clearFormat(token, newRun.start, newRun.length)
            owner.observeRunWritten(token, newRun)
        }
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE TseRunContentStrategy.TryParseData/1 cs:230-233*/
        run.value = TSERun(dataIndex, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE TseRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:235-237*/
        run.value = TSERun(run.value.start, run.value.pointerSources)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE TseRunContentStrategy.WriteNewRun/1 cs:239-242*/
        token.changeData(owner, destination, 0x8) // end
        return TSERun(destination, SortedSpanStatic.one(source))
    }
    /*@END TseRunContentStrategy*/
}
