// Port of Models/IDataModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*

interface IDataModel : ByteList { // cs:15-122
    fun equals(other: IDataModel?): Boolean // IEquatable<IDataModel>.Equals
    val initializationWorkload: Task<Unit>
    val logMessage: Event<String>
    val rawData: ByteArray
    val currentCacheScope: ModelCacheScope
    var referenceCount: Int
    var spartanMode: Boolean
    fun hasChanged(index: Int): Boolean
    val changeCount: Int
    fun resetChanges()
    var freeSpaceStart: Int
    var freeSpaceBuffer: Int
    var nextExportID: Int
    val formatRunFactory: IFormatRunFactory
    val textConverter: ITextConverter
    override operator fun get(index: Int): Int
    operator fun set(index: Int, value: Int)
    val listNames: List<String>
    val arrays: List<ArrayRun>
    fun <T : IFormattedRun> allOfType(type: Class<T>): Iterable<T>?
    val streams: List<IStreamRun>
    val anchors: List<String>
    val gotoShortcuts: List<GotoShortcutModel>
    fun getNextRun(dataIndex: Int): IFormattedRun?
    fun getNextAnchor(dataIndex: Int): IFormattedRun
    fun tryGetUsefulHeader(address: Int, header: Ref<String?>): Boolean
    fun tryGetList(name: String, nameArray: Ref<ValidationList?>): Boolean
    fun isAtEndOfArray(dataIndex: Int, tableRun: Ref<ITableRun?>): Boolean
    fun observeRunWritten(changeToken: ModelDelta, run: IFormattedRun)
    fun observeAnchorWritten(changeToken: ModelDelta, anchorName: String, run: IFormattedRun)
    fun massUpdateFromDelta(runsToRemove: Map<Int, IFormattedRun>, runsToAdd: Map<Int, IFormattedRun>, namesToRemove: Map<Int, String>, namesToAdd: Map<Int, String>, unmappedPointersToRemove: Map<Int, String>, unmappedPointersToAdd: Map<Int, String>, matchedWordsToRemove: Map<Int, String>, matchedWordsToAdd: Map<Int, String>, offsetPointersToRemove: Map<Int, Int>, offsetPointersToAdd: Map<Int, Int>, unmappedConstantsToRemove: Map<String, Int>, unmappedConstantsToAdd: Map<String, Int>, listsToRemove: Map<String, ValidationList>, listsToAdd: Map<String, ValidationList>)
    fun <T : IFormattedRun> relocateForExpansion(changeToken: ModelDelta, run: T, minimumLength: Int): T
    fun <T : IFormattedRun> relocateForExpansion(token: ModelDelta, run: T, currentLength: Int, desiredLength: Int): T
    fun findFreeSpace(start: Int, length: Int): Int
    fun clearAnchor(changeToken: ModelDelta, start: Int, length: Int)
    fun clearFormat(changeToken: ModelDelta, start: Int, length: Int)
    fun clearData(changeToken: ModelDelta, start: Int, length: Int)
    fun clearFormatAndData(changeToken: ModelDelta, start: Int, length: Int)
    fun clearCacheScope()
    fun setList(changeToken: ModelDelta, name: String, list: Iterable<String>?, comments: Map<Int, String>?, hash: String)
    fun updateGotoShortcut(index: Int, shortcut: GotoShortcutModel)
    fun clearPointer(currentChange: ModelDelta, source: Int, destination: Int)
    fun copy(changeToken: () -> ModelDelta, start: Int, length: Int, deep: Boolean = false): String
    fun load(newData: ByteArray, metadata: StoredMetadata?)
    fun expandData(changeToken: ModelDelta, minimumLength: Int)
    fun contractData(changeToken: ModelDelta, maximumLength: Int)
    fun searchForPointersToAnchor(changeToken: ModelDelta, ignoreNoInfoPointers: Boolean, vararg addresses: Int): SortedSpan<Int>
    fun writePointer(changeToken: ModelDelta, address: Int, pointerDestination: Int): Boolean
    fun writeValue(changeToken: ModelDelta, address: Int, value: Int): Boolean
    fun readPointer(address: Int): Int
    fun readValue(address: Int): Int
    fun getScriptLength(run: IScriptStartRun, destinationLengths: MutableMap<Int, Int>): Int
    fun getUnmappedSourcesToAnchor(anchor: String): SortedSpan<Int>
    fun setUnmappedConstant(changeToken: ModelDelta, name: String, value: Int)
    fun tryGetUnmappedConstant(name: String, value: Ref<Int>): Boolean
    fun getAddressFromAnchor(changeToken: ModelDelta?, requestSource: Int, anchor: String): Int
    fun getAnchorFromAddress(requestSource: Int, destination: Int): String
    fun getAutoCompleteAnchorNameOptions(partial: String, maxResults: Int = 30): Iterable<String>?
    fun exportMetadata(references: GameReferenceTables?, metadataInfo: IMetadataInfo): StoredMetadata?
    fun updateArrayPointer(changeToken: ModelDelta, segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, address: Int, destination: Int, writeDestinationFormat: Boolean = true)
    fun considerResultsAsTextRuns(futureChange: () -> ModelDelta, startLocations: List<Int>): Int
    fun getAutoCompleteByteNameOptions(text: String): Iterable<String>?
    fun getMatchedWords(name: String): List<Int>?
    fun getTableGroups(tableName: String): List<TableGroup>?
    fun appendTableGroup(token: ModelDelta, groupName: String, tableNames: List<String>, hash: String?)
    /*@END IDataModel*/
}

open class LimitSet<T> : LinkedHashSet<T> { // cs:124-131
    private var limit: Int = 0
    constructor(limit: Int) { /*@DONE LimitSet.<init>/1 cs:126-126*/
        this.limit = limit
    }
    // skipped method Add: explicit implementation of an interface that is not mapped (ISet<T>)
    /*@ADD LimitSet#models_1.txt*/
    override fun add(element: T): Boolean {
        if (size >= limit) return false
        return super.add(element)
    }
    /*@ENDADD LimitSet#models_1.txt*/
    /*@END LimitSet*/
}

abstract class BaseModel : IDataModel { // cs:133-373
    private val changes: MutableSet<Int> = /*@INITDONE BaseModel.changes cs:136-136*/ LimitSet<Int>(5000) /*@ENDINIT*/
    override var initializationWorkload: Task<Unit> = Task.completedTask
        protected set
    override val logMessage = Event<String>()
    protected fun raiseLogMessage(message: String) { /*@DONE BaseModel.RaiseLogMessage/1 cs:141-141*/
        logMessage.invoke(this, message)
    }
    override var rawData: ByteArray = ByteArray(0)
    private var _currentCacheScope: ModelCacheScope? = null
    override fun clearCacheScope() { /*@DONE BaseModel.ClearCacheScope/1 cs:146-146*/
        _currentCacheScope = null
    }
    override val currentCacheScope: ModelCacheScope
        get() { /*@DONE BaseModel.CurrentCacheScope.get cs:148-155*/
            var instance = _currentCacheScope
            if (instance == null) {
                instance = ModelCacheScope(this)
                _currentCacheScope = instance
            }
            return instance
        }
    override var referenceCount: Int = /*@INITAUTO BaseModel.ReferenceCount cs:158-158*/ 0 /*@ENDINIT*/
    protected constructor(data: ByteArray) { /*@DONE BaseModel.<init>/1 cs:160-166*/
        rawData = data
        var code = data.asByteList().getGameCode()
        if (code.length > 4) code = code.substring(0, 4)
        textConverter = PCSConverter(code, this)
        initializationWorkload = Task.completedTask
    }
    override var freeSpaceStart: Int = 0
    override var freeSpaceBuffer: Int = /*@INITAUTO BaseModel.FreeSpaceBuffer cs:170-170*/ 0x40 /*@ENDINIT*/
    override var nextExportID: Int = 0
    override var formatRunFactory: IFormatRunFactory = /*@INITAUTO BaseModel.FormatRunFactory cs:174-174*/ FormatRunFactory(false) /*@ENDINIT*/
        protected set
    override lateinit var textConverter: ITextConverter
    override val listNames: List<String> = /*@INITAUTO BaseModel.ListNames cs:177-177*/ ArrayList() /*@ENDINIT*/
    override val arrays: List<ArrayRun> = /*@INITAUTO BaseModel.Arrays cs:178-178*/ ArrayList() /*@ENDINIT*/
    override fun <T : IFormattedRun> allOfType(type: Class<T>): Iterable<T>? { /*@DONE BaseModel.All/1 cs:179-179*/
        return emptyList()
    }
    override val streams: List<IStreamRun> = /*@INITAUTO BaseModel.Streams cs:180-180*/ ArrayList() /*@ENDINIT*/
    override val anchors: List<String> = /*@INITAUTO BaseModel.Anchors cs:181-181*/ ArrayList() /*@ENDINIT*/
    private val _gotoShortcuts: MutableList<GotoShortcutModel> = /*@INITDONE BaseModel.gotoShortcuts cs:182-182*/ ArrayList() /*@ENDINIT*/
    override val gotoShortcuts: List<GotoShortcutModel>
        get() { /*@DONE BaseModel.GotoShortcuts.get cs:183-183*/
            return _gotoShortcuts
        }
    override operator fun get(index: Int): Int { /*@DONE BaseModel.this/1.get cs:186-186*/
        return rawData[index].toInt() and 0xFF
    }
    override operator fun set(index: Int, value: Int) { /*@DONE BaseModel.this/1.set cs:187-191*/
        rawData[index] = value.toByte()
        clearCacheScope()
        changes.add(index)
    }
    override var spartanMode: Boolean = false
    override fun hasChanged(index: Int): Boolean { /*@DONE BaseModel.HasChanged/1 cs:196-196*/
        return changes.contains(index)
    }
    override val changeCount: Int
        get() { /*@DONE BaseModel.ChangeCount.get cs:197-197*/
            return changes.size
        }
    override fun resetChanges() { /*@DONE BaseModel.ResetChanges/1 cs:198-198*/
        changes.clear()
    }
    // skipped indexer this: explicit implementation merged with the public member
    override val count: Int
        get() { /*@DONE BaseModel.Count.get cs:202-202*/
            return rawData.size
        }
    abstract override fun clearAnchor(changeToken: ModelDelta, start: Int, length: Int)
    abstract override fun clearFormat(changeToken: ModelDelta, start: Int, length: Int)
    override fun clearData(changeToken: ModelDelta, start: Int, length: Int) { /*@DONE BaseModel.ClearData/1 cs:226-228*/
        for (i in 0 until length) changeToken.changeData(this, start + i, 0xFF)
    }
    abstract override fun clearFormatAndData(changeToken: ModelDelta, originalStart: Int, length: Int)
    override fun setList(changeToken: ModelDelta, name: String, list: Iterable<String>?, comments: Map<Int, String>?, hash: String) { /*@DONE BaseModel.SetList/1 cs:232-232*/
        throw NotImplementedError()
    }
    abstract override fun copy(changeToken: () -> ModelDelta, start: Int, length: Int, deep: Boolean): String
    override fun expandData(changeToken: ModelDelta, minimumIndex: Int) { /*@DONE BaseModel.ExpandData/1 cs:236-244*/
        if (count > minimumIndex) return

        val newData = ByteArray(minimumIndex + 1)
        System.arraycopy(rawData, 0, newData, 0, rawData.size)
        for (i in rawData.size until newData.size) newData[i] = 0xFF.toByte()
        changeToken.setDataLength(this, newData.size)
        rawData = newData
    }
    override fun contractData(changeToken: ModelDelta, maximumIndex: Int) { /*@DONE BaseModel.ContractData/1 cs:246-253*/
        if (count <= maximumIndex + 1) return

        val newData = ByteArray(maximumIndex + 1)
        System.arraycopy(rawData, 0, newData, 0, newData.size)
        changeToken.setDataLength(this, newData.size)
        rawData = newData
    }
    override fun getMatchedWords(name: String): List<Int>? { /*@DONE BaseModel.GetMatchedWords/1 cs:255-255*/
        return ArrayList<Int>()
    }
    override fun getUnmappedSourcesToAnchor(anchor: String): SortedSpan<Int> { /*@DONE BaseModel.GetUnmappedSourcesToAnchor/1 cs:257-257*/
        return SortedSpan.none<Int>()
    }
    override fun setUnmappedConstant(changeToken: ModelDelta, name: String, value: Int) { /*@DONE BaseModel.SetUnmappedConstant/1 cs:259-259*/ }
    override fun tryGetUnmappedConstant(name: String, value: Ref<Int>): Boolean { /*@DONE BaseModel.TryGetUnmappedConstant/1 cs:261-261*/
        value.value = 0
        return false
    }
    abstract override fun getAddressFromAnchor(changeToken: ModelDelta?, requestSource: Int, anchor: String): Int
    abstract override fun getAnchorFromAddress(requestSource: Int, destination: Int): String
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    abstract override fun getNextRun(dataIndex: Int): IFormattedRun?
    abstract override fun getNextAnchor(dataIndex: Int): IFormattedRun
    override fun tryGetUsefulHeader(address: Int, header: Ref<String?>): Boolean { /*@DONE BaseModel.TryGetUsefulHeader/1 cs:273-273*/
        header.value = null
        return false
    }
    override fun tryGetList(name: String, list: Ref<ValidationList?>): Boolean { /*@DONE BaseModel.TryGetList/1 cs:275-275*/
        list.value = null
        return false
    }
    abstract override fun isAtEndOfArray(dataIndex: Int, tableRun: Ref<ITableRun?>): Boolean
    override fun load(newData: ByteArray, metadata: StoredMetadata?) { /*@DONE BaseModel.Load/1 cs:279-282*/
        initializationWorkload.waitSync()
        rawData = newData
    }
    abstract override fun observeAnchorWritten(changeToken: ModelDelta, anchorName: String, run: IFormattedRun)
    abstract override fun observeRunWritten(changeToken: ModelDelta, run: IFormattedRun)
    abstract override fun massUpdateFromDelta(runsToRemove: Map<Int, IFormattedRun>, runsToAdd: Map<Int, IFormattedRun>, namesToRemove: Map<Int, String>, namesToAdd: Map<Int, String>, unmappedPointersToRemove: Map<Int, String>, unmappedPointersToAdd: Map<Int, String>, matchedWordsToRemove: Map<Int, String>, matchedWordsToAdd: Map<Int, String>, offsetPointersToRemove: Map<Int, Int>, offsetPointersToAdd: Map<Int, Int>, unmappedConstantsToRemove: Map<String, Int>, unmappedConstantsToAdd: Map<String, Int>, listsToRemove: Map<String, ValidationList>, listsToAdd: Map<String, ValidationList>)
    abstract override fun <T : IFormattedRun> relocateForExpansion(changeToken: ModelDelta, run: T, minimumLength: Int): T
    abstract override fun <T : IFormattedRun> relocateForExpansion(token: ModelDelta, run: T, currentLength: Int, desiredLength: Int): T
    abstract override fun findFreeSpace(start: Int, length: Int): Int
    abstract override fun searchForPointersToAnchor(changeToken: ModelDelta, ignoreNoInfoPointers: Boolean, vararg addresses: Int): SortedSpan<Int>
    abstract override fun updateArrayPointer(currentChange: ModelDelta, segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, index: Int, fullValue: Int, writeDestinationFormat: Boolean)
    abstract override fun clearPointer(currentChange: ModelDelta, source: Int, destination: Int)
    override fun getScriptLength(run: IScriptStartRun, destinationLengths: MutableMap<Int, Int>): Int { /*@DONE BaseModel.GetScriptLength/1 cs:315-315*/
        return 1
    }
    override fun readValue(index: Int): Int { /*@DONE BaseModel.ReadValue/1 cs:317-317*/
        return (rawData[index].toInt() and 0xFF) or
            ((rawData[index + 1].toInt() and 0xFF) shl 8) or
            ((rawData[index + 2].toInt() and 0xFF) shl 16) or
            ((rawData[index + 3].toInt() and 0xFF) shl 24)
    }
    override fun writeValue(changeToken: ModelDelta, index: Int, word: Int): Boolean { /*@DONE BaseModel.WriteValue/1 cs:319-326*/
        var anyChange = false
        val c0 = changeToken.changeData(this, index + 0, (word shr 0) and 0xFF)
        anyChange = anyChange or c0
        val c1 = changeToken.changeData(this, index + 1, (word shr 8) and 0xFF)
        anyChange = anyChange or c1
        val c2 = changeToken.changeData(this, index + 2, (word shr 16) and 0xFF)
        anyChange = anyChange or c2
        val c3 = changeToken.changeData(this, index + 3, (word shr 24) and 0xFF)
        anyChange = anyChange or c3
        return anyChange
    }
    override fun readPointer(index: Int): Int { /*@DONE BaseModel.ReadPointer/1 cs:328-328*/
        return readValue(index) - pointerOffset
    }
    override fun writePointer(changeToken: ModelDelta, address: Int, pointerDestination: Int): Boolean { /*@DONE BaseModel.WritePointer/1 cs:330-330*/
        return writeValue(changeToken, address, pointerDestination + pointerOffset)
    }
    override fun considerResultsAsTextRuns(futureChange: () -> ModelDelta, startLocations: List<Int>): Int { /*@DONE BaseModel.ConsiderResultsAsTextRuns/1 cs:335-335*/
        return 0
    }
    override fun getAutoCompleteAnchorNameOptions(partial: String, maxResults: Int): Iterable<String>? { /*@DONE BaseModel.GetAutoCompleteAnchorNameOptions/1 cs:337-337*/
        return ArrayList<String>()
    }
    override fun getAutoCompleteByteNameOptions(text: String): Iterable<String>? { /*@DONE BaseModel.GetAutoCompleteByteNameOptions/1 cs:339-339*/
        return ArrayList<String>()
    }
    override fun exportMetadata(references: GameReferenceTables?, metadataInfo: IMetadataInfo): StoredMetadata? { /*@DONE BaseModel.ExportMetadata/1 cs:341-341*/
        return null
    }
    override fun getTableGroups(tableName: String): List<TableGroup>? { /*@DONE BaseModel.GetTableGroups/1 cs:343-343*/
        return null
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    override fun equals(other: IDataModel?): Boolean { /*@DONE BaseModel.Equals/1 cs:347-347*/
        return other === this
    }
    override fun appendTableGroup(token: ModelDelta, groupName: String, tableNames: List<String>, hash: String?) { /*@DONE BaseModel.AppendTableGroup/1 cs:349-349*/ }
    override fun updateGotoShortcut(index: Int, model: GotoShortcutModel) { /*@DONE BaseModel.UpdateGotoShortcut/1 cs:351-351*/
        _gotoShortcuts[index] = model
    }
    fun generateDocumentationLabels(scriptLines: List<IScriptLine>): MutableList<DocLabel> { /*@DONE BaseModel.GenerateDocumentationLabels/1 cs:353-372*/
        // TODO figure out what the labels actually are

        val docs = ArrayList<DocLabel>()
        val page = "https://github.com/haven1433/HexManiacAdvance/blob/master/src/HexManiac.Core/Models/Code/scriptReference.md"
        val gameHash = this.getShortGameCode()

        for (line in scriptLines) {
            if (!line.matchesGame(gameHash)) continue
            val command = line.lineCommand
            docs.add(DocLabel("documentation.scripting.overworld.reference.commands." + command, page + "#" + command.replace(".", "")))
        }

        for (option0 in ModelCacheScope(this).getOptions("specials")) {
            val option: String? = option0
            if (option == null || option.length < 2) continue
            docs.add(DocLabel("documentation.scripting.overworld.reference.specials." + option, page + "#" + option))
        }

        return docs
    }
    companion object {
        const val pointerOffset: Int = 0x08000000
        fun getDefaultMetadatas(vararg codes: String): Iterable<StoredMetadata> { /*@DONE BaseModel.GetDefaultMetadatas/1 cs:204-220*/
            val result = ArrayList<StoredMetadata>()
            if (Resources.exists("resources/default.toml")) {
                val lines = Resources.readAllLines("resources/default.toml")
                val metadata = StoredMetadata(lines.toTypedArray())
                result.add(metadata)
            }

            val files = Resources.getFiles("resources", "default.*.toml")
            for (fileName in files) {
                for (code in codes) {
                    if (!fileName.lowercase().contains("." + code.lowercase() + ".")) continue
                    val lines = Resources.readAllLines(fileName)
                    val metadata = StoredMetadata(lines.toTypedArray())
                    result.add(metadata)
                }
            }
            return result
        }
        /*@END BaseModel.Companion*/
    }
    /*@END BaseModel*/
}

fun ByteList.getShortGameCode(): Int { /*@DONE IDataModelExtensions.GetShortGameCode/1 cs:378-381*/
    if (this.count <= IDataModelExtensions.gameVersionStart) return -1
    return this.readMultiByteValue(IDataModelExtensions.gameCodeStart, 4)
}
fun ByteList.getGameCode(): String { /*@DONE IDataModelExtensions.GetGameCode/1 cs:382-387*/
    if (this.count <= IDataModelExtensions.gameVersionStart) return ""
    val builder = StringBuilder()
    for (i in IDataModelExtensions.gameCodeStart until IDataModelExtensions.gameCodeStart + 4) builder.append(this[i].toChar())
    var code = builder.toString()
    code += this[IDataModelExtensions.gameVersionStart].toString() // should be "0" or "1"
    return code
}
fun ByteList.isFRLG(): Boolean { /*@DONE IDataModelExtensions.IsFRLG/1 cs:388-391*/
    val code = this.getGameCode()
    return code.startsWith("BPR") || code.startsWith("BPG")
}
fun ByteList.isEmerald(): Boolean { /*@DONE IDataModelExtensions.IsEmerald/1 cs:392-392*/
    return this.getGameCode() == "BPEE0"
}
fun ByteList.readMultiByteValue(index: Int, length: Int): Int { /*@DONE IDataModelExtensions.ReadMultiByteValue/1 cs:394-402*/
    var word = 0
    var remaining = length
    while (remaining > 0) {
        word = word shl 8
        word += this[index + remaining - 1]
        remaining--
    }
    return word
}
fun IDataModel.writeMultiByteValue(index: Int, length: Int, tokenFactory: () -> ModelDelta, value: Int): Boolean { /*@DONE IDataModelExtensions.WriteMultiByteValue/1 cs:404-409*/
    val currentValue = this.readMultiByteValue(index, length)
    if (currentValue == value) return false
    return this.writeMultiByteValue(index, length, tokenFactory(), value)
}
fun IDataModel.writeMultiByteValue(index: Int, length: Int, changeToken: ModelDelta, value: Int): Boolean { /*@DONE IDataModelExtensions.WriteMultiByteValue/2 cs:411-419*/
    var anyChange = false
    var remainingValue = value
    for (i in 0 until length) {
        val changed = changeToken.changeData(this, index + i, remainingValue and 0xFF)
        anyChange = anyChange or changed
        remainingValue = remainingValue shr 8
    }
    return anyChange
}
fun IDataModel.tryGetNameArray(anchorName: String, array: Ref<ArrayRun?>): Boolean { /*@DONE IDataModelExtensions.TryGetNameArray/1 cs:424-437*/
    array.value = null

    // anchorName must name an array              enum must be the name of an array that starts with a string
    val address = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchorName)
    if (address == Pointer.null_) return false
    val found = this.getNextRun(address) as? ArrayRun
    array.value = found
    if (found == null) return false

    // the array must contain a text or pointer-to-text element
    for (segment in found.elementContent) {
        if (segment.type == ElementContentType.PCS || (segment is ArrayRunPointerSegment && segment.innerFormat == PCSRun.sharedFormatString)) return true
    }
    return false
}
fun IDataModel.tryGetIndexNames(anchorName: String, names: Ref<List<String>?>): Boolean { /*@DONE IDataModelExtensions.TryGetIndexNames/1 cs:439-474*/
    names.value = null

    // verify that this anchor is an index-array
    var address = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchorName)
    val array = this.getNextRun(address) as? ArrayRun
    if (array == null) return false
    if (array.elementContent.size != 1) return false
    if (array.elementContent[0].type != ElementContentType.Integer) return false

    // verify that the parent is a name-array
    val parentName = array.lengthFromAnchor
    if (parentName == "") return false
    address = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, parentName)
    val parent = this.getNextRun(address) as? ArrayRun
    if (parent == null) return false
    if (parent.elementContent.size != 1) return false
    if (parent.elementContent[0].type != ElementContentType.PCS) return false

    val offset = if (array.formatString.endsWith("-1")) 1 else 0
    val rawOptions = this.getOptions(parentName)

    // create a name array, where the names are rearranged based on the index array
    val result = arrayOfNulls<String>(rawOptions.size)
    for (i in 0 until result.size - offset) {
        val index = this.readMultiByteValue(array.start + array.elementLength * i, array.elementLength)
        if (index < offset) return false
        if (index - offset >= result.size) return false
        if (i + offset >= rawOptions.size || index >= result.size) return false
        result[index] = rawOptions[i + offset]
        if (result[i] == null) result[i] = "?unused?"
    }

    names.value = result.toList() as List<String>
    return true
}
fun IDataModel.tryGetDerivedEnumNames(anchorName: String, names: Ref<List<String>?>): Boolean { /*@DONE IDataModelExtensions.TryGetDerivedEnumNames/1 cs:479-504*/
    names.value = null
    val mainEnumAddress = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchorName)
    val enumArray = this.getNextRun(mainEnumAddress) as? ArrayRun
    if (enumArray == null) return false
    if (enumArray.elementCount < 2) return false
    if (enumArray.elementContent.size != 1) return false
    val mainEnumSegment = enumArray.elementContent[0] as? ArrayRunEnumSegment
    if (mainEnumSegment == null) return false
    val enumSourceAddress = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, mainEnumSegment.enumName)
    val sourceArray = this.getNextRun(enumSourceAddress) as? ArrayRun
    if (sourceArray == null) return false
    val scope = ModelCacheScope.createScope(this)
    try {
        val allNames = sourceArray.elementNames
        if (allNames == null || allNames.size == 0) return false
        val list = ArrayList<String>()

        for (i in 0 until enumArray.elementCount) {
            val enumValue = this.readMultiByteValue(enumArray.start + enumArray.elementLength * i, mainEnumSegment.length)
            if (enumValue >= allNames.size || enumValue < 0) return false
            list.add(allNames[enumValue])
        }

        names.value = list
        return true
    } finally {
        scope.dispose()
    }
}
fun IDataModel.tryGetListEnumNames(anchorName: String, names: Ref<List<String>?>): Boolean { /*@DONE IDataModelExtensions.TryGetListEnumNames/1 cs:509-515*/
    names.value = null
    val array = this.getTable(anchorName) as? ArrayRun
    if (array == null) return false
    val list = Ref<ValidationList?>(null)
    if (!this.tryGetList(array.lengthFromAnchor, list)) return false
    names.value = list.value
    return true
}
fun IDataModel.findPossibleTextStartingPlaces(left: Int, length: Int): MutableList<Int> { /*@DONE IDataModelExtensions.FindPossibleTextStartingPlaces/1 cs:517-549*/
    // part 1: find a previous FF, which is possibly the end of another text
    var start = left
    var remaining = length
    val startPlaces = ArrayList<Int>()
    if (start < 0 || start >= this.count) return startPlaces
    startPlaces.add(start)
    while (start >= 0 && this[start] != 0xFF && PCSString.pcs[this[start]] != null) { start--; remaining++ }
    start++; remaining--

    // part 2: jump forward past any known runs that we're interupting
    while (true) {
        val run = this.getNextRun(start) ?: NoInfoRun.nullRun
        if (run.start >= start) break
        remaining -= start - run.start
        start = run.start + run.length
    }

    // part 3: look for possible starting locations:
    // (1) places that start directly after FF
    // (2) places that start with a NoInfoRun
    while (remaining > 0) {
        startPlaces.add(start)
        val run = this.getNextRun(start) ?: NoInfoRun.nullRun
        if (run is NoInfoRun && run.start < start + remaining) startPlaces.add(run.start)
        if (run !is NoInfoRun && run.start < start + remaining) break
        while (this.count > start && this[start] != 0xFF) { start++; remaining-- }
        start++; remaining--
    }

    // remove duplicates and make sure everything is in order
    startPlaces.sort()
    return ArrayList<Int>(LinkedHashSet<Int>(startPlaces))
}
fun IDataModel.getNewPointerAutocompleteOptions(text: String, selectedIndex: Int): Iterable<AutoCompleteSelectionItem> { /*@DONE IDataModelExtensions.GetNewPointerAutocompleteOptions/1 cs:551-556*/
    var options: Iterable<String> = this.getAutoCompleteAnchorNameOptions(text.substring(1)) ?: ArrayList<String>()
    if (text.startsWith(PointerRun.pointerStart.toString())) options = options.map { option -> "" + PointerRun.pointerStart + option + PointerRun.pointerEnd }
    if (text.startsWith(ViewPort.gotoMarker.toString())) options = options.map { option -> "" + ViewPort.gotoMarker + option + " " }
    return AutoCompleteSelectionItem.generate(options, selectedIndex)
}
fun IDataModel.getNewWordAutocompleteOptions(text: String, selectedIndex: Int): Iterable<AutoCompleteSelectionItem>? { /*@DONE IDataModelExtensions.GetNewWordAutocompleteOptions/1 cs:558-573*/
    var query = text
    var options: Iterable<String>

    if (query.startsWith(".")) {
        query = query.substring(1)
        options = this.getAutoCompleteByteNameOptions(query) ?: ArrayList<String>()
        options = options.map { option -> "." + option + " " }
        return AutoCompleteSelectionItem.generate(options, selectedIndex)
    }

    if (query.length >= 2) query = query.substring(2)
    else return null
    options = this.getAutoCompleteAnchorNameOptions(query) ?: ArrayList<String>()
    options = options.map { option -> "::" + option + " " }
    return AutoCompleteSelectionItem.generate(options, selectedIndex)
}
fun IDataModel.wrapFormat(run: IFormattedRun, format: IDataFormat, dataIndex: Int): IDataFormat { /*@DONE IDataModelExtensions.WrapFormat/1 cs:576-591*/
    val runSources = run.pointerSources
    if (runSources != null && run.start == dataIndex) {
        val name = this.getAnchorFromAddress(-1, run.start)
        return Anchor(format, name, run.formatString, runSources)
    }

    if (run is ArrayRun && run.supportsInnerPointers && (dataIndex - run.start) % run.elementLength == 0) {
        val arrayIndex = (dataIndex - run.start) / run.elementLength
        val innerSources = run.pointerSourcesForInnerElements!![arrayIndex]
        if (innerSources == null || innerSources.size == 0) return format
        val name = this.getAnchorFromAddress(-1, dataIndex)
        return Anchor(format, name, "", innerSources)
    }

    return format
}
fun IDataModel.loadMetadata(metadata: StoredMetadata) { /*@DONE IDataModelExtensions.LoadMetadata/1 cs:593-638*/
    val noChange = NoDataChangeDeltaModel()
    for (list in metadata.lists) {
        val existingList = Ref<ValidationList?>(null)
        if (this.tryGetList(list.name, existingList) && !existingList.value!!.storedHashMatches) {
            // the list has been manually tampered with by the user
            // do not update it
        } else {
            this.setList(noChange, list.name, list.contents as List<String>, list.comments, list.hash ?: "")
        }
    }
    for (anchor in metadata.namedAnchors) PokemonModel.applyAnchor(this, noChange, anchor.address, BaseRun.anchorStart + anchor.name + (anchor.format ?: ""), true)
    for (match in metadata.matchedWords) {
        this.clearFormat(noChange, match.address, match.length)
        this.observeRunWritten(noChange, WordRun(match.address, match.name, match.length, match.addOffset, match.multOffset, match.note))
    }
    for (anchor in ArrayList<String>(this.anchors)) {
        val table = this.getNextRun(this.getAddressFromAnchor(noChange, -1, anchor)) as? ArrayRun
        if (table == null) continue
        // the length may have changed: rewrite the run
        if (metadata.lists.map { list -> list.name }.contains(table.lengthFromAnchor)) {
            val newTable = Ref<ITableRun?>(null)
            if (!ArrayRun.tryParse(this, table.formatString, table.start, table.pointerSources, newTable).hasError) {
                this.observeAnchorWritten(noChange, anchor, newTable.value!!)
            }
        }
    }
    for (pointer in metadata.offsetPointers) {
        if (pointer.address >= 0 && pointer.address < this.count) {
            val existingPointerRun = this.getNextRun(pointer.address)
            if (existingPointerRun is OffsetPointerRun && existingPointerRun.start == pointer.address) {
                // we already have an offset pointer run at this location: don't overwrite it.
            } else {
                this.observeRunWritten(noChange, OffsetPointerRun(pointer.address, pointer.offset))
            }
        }
    }
    val shortcuts = this.gotoShortcuts as MutableList<GotoShortcutModel>
    for (gotoShortcut in metadata.gotoShortcuts) {
        if (shortcuts.any { shortcut -> shortcut.displayText == gotoShortcut.display }) continue
        val tableName = gotoShortcut.anchor.split("/")[0]
        if (shortcuts.any { shortcut -> shortcut.gotoAnchor.split("/")[0] == tableName }) continue
        shortcuts.add(GotoShortcutModel(gotoShortcut.image ?: "", gotoShortcut.anchor, gotoShortcut.display))
    }

    for (group in metadata.tableGroups) {
        this.appendTableGroup(noChange, group.groupName, group.tables, group.hash)
    }
    this.loadMetadataProperties(metadata)
}
fun IDataModel.loadMetadataProperties(metadata: StoredMetadata) { /*@DONE IDataModelExtensions.LoadMetadataProperties/1 cs:640-644*/
    if (metadata.nextExportID > 0) this.nextExportID = metadata.nextExportID
    if (metadata.freeSpaceSearch >= 0) this.freeSpaceStart = minOf(this.count - 1, metadata.freeSpaceSearch)
    if (metadata.freeSpaceBuffer >= 0) this.freeSpaceBuffer = metadata.freeSpaceBuffer
}
fun IDataModel.completeArrayExtension(changeToken: ModelDelta, count: Int, table: Ref<ITableRun?>): ErrorInfo { /*@DONE IDataModelExtensions.CompleteArrayExtension/1 cs:646-699*/
    var current: ITableRun = table.value!!
    val currentArrayName = this.getAnchorFromAddress(-1, current.start)
    if (!current.canAppend) {
        return ErrorInfo("Cannot extend " + currentArrayName + ".")
    }

    var initialTableName = this.getAnchorFromAddress(-1, current.start)
    if (initialTableName == "") initialTableName = this.getNameFromParent(current)
    val visitedNames = ArrayList<String>()
    visitedNames.add(initialTableName)
    val visitedAddress = ArrayList<Int>()
    visitedAddress.add(current.start)

    if (current is ArrayRun) {
        var arrayRun: ArrayRun = current
        while (arrayRun.lengthFromAnchor != "") {
            if (visitedNames.contains(arrayRun.lengthFromAnchor)) {
                // We kept going up the chain of tables but didn't find a top table. table length definitions are circular.
                return ErrorInfo("Could not extend table safely. Table length has a circular dependency involving " + arrayRun.lengthFromAnchor + ".")
            }

            // jump up to the parent table. If the LengthFromAnchor indicates a non-table (such as a named constant), bail
            val address = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, arrayRun.lengthFromAnchor)
            if (address != Pointer.null_) {
                visitedNames.add(arrayRun.lengthFromAnchor)
                visitedAddress.add(address)
                arrayRun = this.getNextRun(address) as ArrayRun
            } else {
                break // this is a top-level table, with length depending on a named constant or list
            }
        }
        current = arrayRun
        table.value = current
    }

    val newTable = IDataModelExtensions.extendTableAndChildren(this, changeToken, current, count)
    for (otherTable in this.tablesWithSameConstantForLength(newTable)) {
        IDataModelExtensions.extendTableAndChildren(this, changeToken, otherTable, count)
    }

    if (newTable.start != current.start && currentArrayName.isEmpty()) {
        table.value = newTable
        return ErrorInfo("Stream was moved. Pointers have been updated.", true)
    }

    val reloaded = this.getNextRun(this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, currentArrayName)) as? ITableRun
    table.value = reloaded
    if (reloaded == null) return ErrorInfo.noError

    val changedNames = ArrayList<String>()
    for (i in 0 until visitedNames.size) {
        val newAddress = this.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, visitedNames[i])
        if (newAddress != visitedAddress[i]) changedNames.add(visitedNames[i])
    }
    if (changedNames.size == 0) return ErrorInfo.noError
    if (changedNames.size == 1) return ErrorInfo(changedNames[0] + " was moved. Pointers have been updated.", true)
    val all = changedNames.joinToString(", ")
    return ErrorInfo("Tables " + all + " were moved. Pointers have been updated.", true)
}
private fun IDataModel.getNameFromParent(table: ITableRun): String { /*@DONE IDataModelExtensions.GetNameFromParent/1 cs:701-717*/
    val tableSources = table.pointerSources
    if (tableSources != null) {
        for (i in 0 until tableSources.size) {
            val source = tableSources[i]
            val parent = this.getNextRun(source) as? ITableRun
            if (parent == null) continue
            val offsets = parent.convertByteOffsetToArrayOffset(source)
            val segmentName = parent.elementContent[offsets.segmentIndex].name
            val parentIndex = offsets.elementIndex
            val parentName = this.getAnchorFromAddress(-1, parent.start)
            if (parentName != null) {
                return parentName + "/" + parentIndex + "/" + segmentName + "/"
            } else {
                return this.getNameFromParent(parent) + parentIndex + "/" + segmentName + "/"
            }
        }
    }

    return table.start.toAddress()
}
fun IDataModel.tablesWithSameConstantForLength(tableRun: ITableRun): Iterable<ITableRun> { /*@DONE IDataModelExtensions.TablesWithSameConstantForLength/1 cs:727-736*/
    val result = ArrayList<ITableRun>()
    if (tableRun !is ArrayRun) return result
    val constants = this.getMatchedWords(tableRun.lengthFromAnchor)
    if (constants == null || constants.size == 0) return result
    for (array in ArrayList<ArrayRun>(this.arrays)) {
        if (tableRun === array || tableRun.start == array.start) continue
        if (array.lengthFromAnchor != tableRun.lengthFromAnchor) continue
        result.add(array)
    }
    return result
}
fun IDataModel.getNextAnchor(name: String): IFormattedRun { /*@DONE IDataModelExtensions.GetNextAnchor/1 cs:738-738*/
    return this.getNextRun(this.getAddressFromAnchor(ModelDelta(), -1, name)) ?: NoInfoRun.nullRun
}
fun IDataModel.getDependantArrays(anchor: String): Iterable<ArrayRun> { /*@DONE IDataModelExtensions.GetDependantArrays/1 cs:744-746*/
    return this.currentCacheScope.getDependantArrays(anchor)
}
inline fun <reified T : IFormattedRun> IDataModel.getPointedChildren(table: ITableRun, elementIndex: Int): Iterable<T> { /*@DONE IDataModelExtensions.GetPointedChildren/1 cs:751-761*/
    val results = ArrayList<T>()
    var segmentOffset = 0
    val elementOffset = table.elementLength * elementIndex
    for (segment in table.elementContent) {
        if (segment is ArrayRunPointerSegment) {
            val destination = this.readPointer(table.start + elementOffset + segmentOffset)
            val result = this.getNextRun(destination)
            if (result is T && result.start == destination) results.add(result)
        }
        segmentOffset += segment.length
    }
    return results
}
fun IDataModel.getEnumArrays(enumName: String): Iterable<ArrayRun> { /*@DONE IDataModelExtensions.GetEnumArrays/1 cs:766-775*/
    val result = ArrayList<ArrayRun>()
    for (array in ArrayList<ArrayRun>(this.arrays)) {
        for (segment in array.elementContent) {
            if (segment !is ArrayRunEnumSegment) continue
            if (segment.enumName != enumName) continue
            result.add(array)
            break
        }
    }
    return result
}
fun IDataModel.findPointer(address: Int): Iterable<Int> { /*@DONE IDataModelExtensions.FindPointer/1 cs:777-782*/
    val low = address and 0xFF
    val mid = (address shr 8) and 0xFF
    val high = (address shr 16) and 0xFF
    return this.find(low, mid, high, 0x08)
}
fun IDataModel.find(vararg search: Int): Iterable<Int> { /*@DONE IDataModelExtensions.Find/1 cs:784-791*/
    val result = ArrayList<Int>()
    val limit = this.count - search.size
    var i = 0
    while (i < limit) {
        var j = 0
        while (j < search.size) {
            if (this[i + j] != search[j]) break
            if (j == search.size - 1) result.add(i)
            j++
        }
        i++
    }
    return result
}
fun IDataModel.thumbFind(search: ByteArray): Iterable<Int> { /*@DONE IDataModelExtensions.ThumbFind/1 cs:796-803*/
    val result = ArrayList<Int>()
    val limit = this.count - search.size
    var i = 0
    while (i < limit) {
        var j = 0
        while (j < search.size) {
            if (this[i + j] != (search[j].toInt() and 0xFF)) break
            if (j == search.size - 1) result.add(i)
            j++
        }
        i += 2
    }
    return result
}
fun IDataModel.search(searchBytes: MutableList<ISearchByte>): Iterable<Int> { /*@DONE IDataModelExtensions.Search/1 cs:805-813*/
    val result = ArrayList<Int>()
    val limit = this.count - searchBytes.size
    var i = 0
    while (i < limit) {
        var j = 0
        while (j < searchBytes.size) {
            if (!searchBytes[j].match(this[i + j])) break
            if (j == searchBytes.size - 1) result.add(i)
            j++
        }
        i++
    }
    searchBytes.clear()
    return result
}
fun IDataModel.findListUsages(searchstring: String): Iterable<IDataModelExtensionsFindListUsagesTuple> { /*@DONE IDataModelExtensions.FindListUsages/1 cs:815-837*/
    val result = ArrayList<IDataModelExtensionsFindListUsagesTuple>()
    val lowerSearch = searchstring.lowercase()
    for (listName in ArrayList<String>(this.listNames)) {
        val elementNamesRef = Ref<ValidationList?>(null)
        if (!this.tryGetList(listName, elementNamesRef)) continue
        val elementNames = elementNamesRef.value!!
        for (i in 0 until elementNames.size) {
            val elementName: String? = elementNames[i]
            if (elementName == null) continue
            if (elementName.lowercase() != lowerSearch) continue
            for (table in ArrayList<ArrayRun>(this.arrays)) {
                for (field in table.elementContent) {
                    if (field !is ArrayRunEnumSegment) continue
                    if (field.enumName.lowercase() != listName) continue
                    var fieldOffset = 0
                    for (seg in table.elementContent) {
                        if (seg === field) break
                        fieldOffset += seg.length
                    }
                    for (j in 0 until table.elementCount) {
                        val start = table.start + j * table.elementLength + fieldOffset
                        val modelValue = this.readMultiByteValue(start, field.length)
                        if (modelValue != i) continue
                        result.add(IDataModelExtensionsFindListUsagesTuple(start, start + field.length - 1))
                    }
                }
            }
        }
    }
    return result
}
fun IDataModel.getOptions(tableName: String): List<String> { /*@DONE IDataModelExtensions.GetOptions/1 cs:839-839*/
    return ModelCacheScope.getCache(this).getOptions(tableName)
}
fun IDataModel.getBitOptions(tableName: String): List<String>? { /*@DONE IDataModelExtensions.GetBitOptions/1 cs:841-841*/
    return ModelCacheScope.getCache(this).getBitOptions(tableName)
}
fun List<String>.tryMatch(text: String, value: Ref<Int>): Boolean { /*@DONE IDataModelExtensions.TryMatch/1 cs:843-843*/
    return ArrayRunEnumSegment.tryMatch(text, this, value)
}
fun IDataModel.getRelatedArrays(table: ArrayRun): Iterable<ArrayRun> { /*@DONE IDataModelExtensions.GetRelatedArrays/1 cs:845-861*/
    val result = ArrayList<ArrayRun>()
    result.add(table) // a table is related to itself
    var basename = this.getAnchorFromAddress(-1, table.start)
    val nameOptions = HashSet<String>()
    nameOptions.add(basename)
    if (!table.lengthFromAnchor.isNullOrEmpty()) {
        basename = table.lengthFromAnchor
        nameOptions.add(basename)
    }
    for (array in ArrayList<ArrayRun>(this.arrays)) {
        if (array === table) continue
        val currentArrayName = this.getAnchorFromAddress(-1, array.start)
        val options = ArrayList<String>()
        options.add(currentArrayName)
        if (!array.lengthFromAnchor.isNullOrEmpty()) options.add(array.lengthFromAnchor)
        if (!options.any { option -> nameOptions.contains(option) }) continue
        result.add(array)
    }
    return result
}
fun IDataModel.insertPointersToRun(token: ModelDelta, run: IFormattedRun) { /*@DONE IDataModelExtensions.InsertPointersToRun/1 cs:863-879*/
    val runSources = run.pointerSources
    if (runSources != null) {
        for (i in 0 until runSources.size) {
            val source = runSources[i]
            val existingRun = this.getNextRun(source) ?: NoInfoRun.nullRun
            if (existingRun.start <= source) continue
            this.observeRunWritten(token, PointerRun(source))
        }
    }

    if (run is ArrayRun && run.supportsInnerPointers) {
        val innerSources = run.pointerSourcesForInnerElements
        if (innerSources != null) {
            for (i in 0 until run.elementCount) {
                val elementSources = innerSources[i]
                for (k in 0 until elementSources.size) {
                    val source = elementSources[k]
                    val existingRun = this.getNextRun(source) ?: NoInfoRun.nullRun
                    if (existingRun.start <= source) continue
                    this.observeRunWritten(token, PointerRun(source))
                }
            }
        }
    }
}
fun IDataModel.setList(token: ModelDelta, name: String, vararg items: String) { /*@DONE IDataModelExtensions.SetList/1 cs:881-881*/
    this.setList(token, name, items.toList(), LinkedHashMap<Int, String>(), "")
}
fun IDataModel.isFreespace(start: Int, length: Int): Boolean { /*@DONE IDataModelExtensions.IsFreespace/1 cs:883-888*/
    for (i in 0 until length) {
        if (this[start + i] != 0xFF) return false
    }
    return true
}
fun IDataModel.cut(token: ModelDelta, start: Int, length: Int): ByteArray { /*@DONE IDataModelExtensions.Cut/1 cs:890-898*/
    val result = ByteArray(length)

    for (i in 0 until length) {
        result[i] = this[start + i].toByte()
        token.changeData(this, start + i, 0xFF)
    }
    return result
}
fun IDataModel.paste(token: ModelDelta, start: Int, data: ByteArray, length: Int) { /*@DONE IDataModelExtensions.Paste/1 cs:900-903*/
    token.changeData(this, start, data.asByteList())
    for (i in data.size until length) token.changeData(this, start + i, 0)
}

object IDataModelExtensions { // cs:375-904
    const val gameCodeStart: Int = 0xAC
    const val gameVersionStart: Int = 0xBC
    fun extendTableAndChildren(model: IDataModel, changeToken: ModelDelta, array: ITableRun, count: Int): ITableRun { /*@DONE IDataModelExtensions.ExtendTableAndChildren/1 cs:719-725*/
        val additionalLength = maxOf(0, array.elementLength * count)
        var newRun = model.relocateForExpansion(changeToken, array, array.length + additionalLength)
        newRun = newRun.append(changeToken, count)
        model.observeRunWritten(changeToken, newRun)
        return newRun
    }
    /*@END IDataModelExtensions*/
}

open class BasicModel : BaseModel { // cs:906-946
    constructor(data: ByteArray) : super(data) { /*@DONE BasicModel.<init>/1 cs:908-908*/ }
    override fun getAddressFromAnchor(changeToken: ModelDelta?, requestSource: Int, anchor: String): Int { /*@DONE BasicModel.GetAddressFromAnchor/1 cs:910-910*/
        return Pointer.null_
    }
    override fun getAnchorFromAddress(requestSource: Int, destination: Int): String { /*@DONE BasicModel.GetAnchorFromAddress/1 cs:911-911*/
        return ""
    }
    override fun getNextRun(dataIndex: Int): IFormattedRun? { /*@DONE BasicModel.GetNextRun/1 cs:912-912*/
        return NoInfoRun.nullRun
    }
    override fun getNextAnchor(dataIndex: Int): IFormattedRun { /*@DONE BasicModel.GetNextAnchor/1 cs:913-913*/
        return NoInfoRun.nullRun
    }
    override fun isAtEndOfArray(dataIndex: Int, tableRun: Ref<ITableRun?>): Boolean { /*@DONE BasicModel.IsAtEndOfArray/1 cs:914-914*/
        tableRun.value = null
        return false
    }
    override fun observeRunWritten(changeToken: ModelDelta, run: IFormattedRun) { /*@DONE BasicModel.ObserveRunWritten/1 cs:915-915*/ }
    override fun observeAnchorWritten(changeToken: ModelDelta, anchorName: String, run: IFormattedRun) { /*@DONE BasicModel.ObserveAnchorWritten/1 cs:916-916*/ }
    override fun massUpdateFromDelta(runsToRemove: Map<Int, IFormattedRun>, runsToAdd: Map<Int, IFormattedRun>, namesToRemove: Map<Int, String>, namesToAdd: Map<Int, String>, unmappedPointersToRemove: Map<Int, String>, unmappedPointersToAdd: Map<Int, String>, matchedWordsToRemove: Map<Int, String>, matchedWordsToAdd: Map<Int, String>, offsetPointersToRemove: Map<Int, Int>, offsetPointersToAdd: Map<Int, Int>, unmappedConstantsToRemove: Map<String, Int>, unmappedConstantsToAdd: Map<String, Int>, listsToRemove: Map<String, ValidationList>, listsToAdd: Map<String, ValidationList>) { /*@DONE BasicModel.MassUpdateFromDelta/1 cs:917-924*/ }
    override fun <T : IFormattedRun> relocateForExpansion(changeToken: ModelDelta, run: T, minimumLength: Int): T { /*@DONE BasicModel.RelocateForExpansion/1 cs:925-925*/
        throw NotImplementedError()
    }
    override fun <T : IFormattedRun> relocateForExpansion(changeToken: ModelDelta, run: T, currentLength: Int, desiredLength: Int): T { /*@DONE BasicModel.RelocateForExpansion/2 cs:926-926*/
        throw NotImplementedError()
    }
    override fun findFreeSpace(start: Int, length: Int): Int { /*@DONE BasicModel.FindFreeSpace/1 cs:927-927*/
        throw NotImplementedError()
    }
    override fun clearAnchor(changeToken: ModelDelta, start: Int, length: Int) { /*@DONE BasicModel.ClearAnchor/1 cs:928-928*/ }
    override fun clearFormat(changeToken: ModelDelta, start: Int, length: Int) { /*@DONE BasicModel.ClearFormat/1 cs:929-929*/ }
    override fun clearFormatAndData(changeToken: ModelDelta, start: Int, length: Int) { /*@DONE BasicModel.ClearFormatAndData/1 cs:930-932*/
        for (i in 0 until length) changeToken.changeData(this, start + i, 0xFF)
    }
    override fun clearPointer(currentChange: ModelDelta, source: Int, destination: Int) { /*@DONE BasicModel.ClearPointer/1 cs:934-934*/
        throw NotImplementedError()
    }
    override fun searchForPointersToAnchor(changeToken: ModelDelta, ignoreNoInfoPointers: Boolean, vararg addresses: Int): SortedSpan<Int> { /*@DONE BasicModel.SearchForPointersToAnchor/1 cs:936-936*/
        throw NotImplementedError()
    }
    override fun updateArrayPointer(changeToken: ModelDelta, segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, address: Int, destination: Int, writeDestinationFormat: Boolean) { /*@DONE BasicModel.UpdateArrayPointer/1 cs:938-940*/
        writePointer(changeToken, address, destination)
    }
    override fun copy(changeToken: () -> ModelDelta, start: Int, length: Int, deep: Boolean): String { /*@DONE BasicModel.Copy/1 cs:942-945*/
        val bytes = ArrayList<String>()
        for (i in start until start + length) bytes.add((rawData[i].toInt() and 0xFF).toHexString())
        return bytes.joinToString(" ")
    }
    /*@END BasicModel*/
}

data class IDataModelExtensionsFindListUsagesTuple(val start: Int, val end: Int)

/*@ADD file:models/IDataModel.kt#models_1.txt*/
/** Kotlin cannot test a generic type at run time, so `model.All<T>()` is a reified extension over [IDataModel.allOfType]. */
inline fun <reified T : IFormattedRun> IDataModel.all(): Iterable<T>? = this.allOfType(T::class.java)
/*@ENDADD file:models/IDataModel.kt#models_1.txt*/
