// Port of ViewModels/Map/Flags.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*

data class BerrySpot(val address: Int, val berryID: Int) { // cs:18-18
    /*@END BerrySpot*/
}

open class FlagContext(val address: Int, val bank: Int, val map: Int) { // cs:20-20
    /*@END FlagContext*/
}

class ObjectFlagContext(address: Int, bank: Int, map: Int, val object_: Int) : FlagContext(address, bank, map) { // cs:21-21
    /*@END ObjectFlagContext*/
}

class ScriptFlagContext(address: Int, bank: Int, map: Int, val script: Int) : FlagContext(address, bank, map) { // cs:22-22
    /*@END ScriptFlagContext*/
}

class SignpostFlagContext(address: Int, bank: Int, map: Int, val signpost: Int) : FlagContext(address, bank, map) { // cs:23-23
    /*@END SignpostFlagContext*/
}

class HeaderFlagContext(address: Int, bank: Int, map: Int, val scriptType: Int) : FlagContext(address, bank, map) { // cs:24-24
    /*@END HeaderFlagContext*/
}

open class Flags { // cs:26-539
    companion object {
        private const val scriptLengthLimit: Int = 0x1000
        private const val scriptCountLimit: Int = 100
        var rs_ThumbVars: MutableSet<Int> = /*@INITDONE Flags.RS_ThumbVars cs:34-38*/ 
            linkedSetOf(
                0x4040, 0x4041, 0x4042, 0x4046, 0x4047, 0x404A, 0x404B, 0x404C, 0x404F,
                0x4054, 0x4097, 0x40C2) /*@ENDINIT*/
        var frlg_ThumbVars: MutableSet<Int> = /*@INITDONE Flags.FRLG_ThumbVars cs:34-47*/ 
            linkedSetOf(
                0x4035, 0x4037, 0x4038, 0x4039, 0x403B, 0x403C, 0x403D, 0x4040,
                0x4042, 0x4043, 0x4044, 0x4045, 0x4046, 0x4047, 0x4048, 0x404C, 0x404D, 0x404E, 0x404F,
                0x40AA, 0x40AB, 0x40AC, 0x40AD, 0x40AE,
                0x40B4, 0x40B5, 0x40B6, 0x40B7, 0x40B8, 0x40B9, 0x40BA, 0x40BB, 0x40BC,
                0x40CF,
                0x40E6, 0x40E7, 0x40E8, 0x40E9, 0x40EA, 0x40EB,
                0x40F1) /*@ENDINIT*/
        var emerald_ThumbVars: MutableSet<Int> = /*@INITDONE Flags.Emerald_ThumbVars cs:34-55*/ 
            linkedSetOf(
                0x4036, 0x4038, 0x403E,
                0x4040, 0x4041, 0x4042, 0x4046, 0x4047, 0x404A, 0x404B, 0x404C, 0x404F,
                0x4097, 0x40C2, 0x40CD,
                0x40D0, 0x40D4, 0x40DD, 0x40DE, 0x40DF,
                0x40E0, 0x40E1, 0x40E2, 0x40E3, 0x40E4, 0x40E6, 0x40E7, 0x40E8, 0x40E9, 0x40EA, 0x40EB, 0x40EC, 0x40EE, 0x40EF,
                0x40F0, 0x40F1, 0x40F5, 0x40F6) /*@ENDINIT*/
        fun getUsedItemFlags(model: IDataModel, parser: ScriptParser): MutableSet<Int> { /*@DONE Flags.GetUsedItemFlags/1 cs:60-89*/
            val usedFlags = LinkedHashSet<Int>()

            var hiddenItemFlagStart = 600
            if (model.isEmerald()) {
                for (i in 0x15C..0x1A9) usedFlags.add(i)        // Emerald Match Call flags
                hiddenItemFlagStart = 500
            } else if (model.isFRLG()) {
                hiddenItemFlagStart = 1000
            }

            // object flags
            for (element in getAllEvents(model, "objects")) {
                if (!element.hasField("flag")) continue
                usedFlags.add(element.getValue("flag"))
            }

            // hidden item flags
            for (element in getAllEvents(model, "signposts")) {
                val signpost = SignpostEventModel(element)
                if (!signpost.isHiddenItem) continue
                usedFlags.add(hiddenItemFlagStart + signpost.hiddenItemFlag)
            }

            for (spot in getAllScriptSpots(model, parser, getAllTopLevelScripts(model), 0x29, 0x2A, 0x2B)) {
                usedFlags.add(model.readMultiByteValue(spot.address + 1, 2))
            }

            return usedFlags
        }
        fun findFlagUsages(model: IDataModel, parser: ScriptParser, flag: Int): MutableSet<FlagsFindFlagUsagesTuple> { /*@DONE Flags.FindFlagUsages/1 cs:92-107*/
            val usages = LinkedHashSet<FlagsFindFlagUsagesTuple>()

            for (element in getAllEvents(model, "objects")) {
                if (element.getValue("flag") == flag) usages.add(FlagsFindFlagUsagesTuple(element.start, element.start + element.length - 1))
            }

            for (spot in getAllScriptSpots(model, parser, getAllTopLevelScripts(model), 0x29, 0x2A, 0x2B)) {
                val address = spot.address
                if (model.readMultiByteValue(address + 1, 2) == flag) {
                    usages.add(FlagsFindFlagUsagesTuple(address, address + spot.line.compiledByteLength(model, address, null) - 1))
                }
            }

            return usages
        }
        fun getUsedVariables(model: IDataModel, parser: ScriptParser): MutableSet<Int> { /*@DONE Flags.GetUsedVariables/1 cs:109-129*/
            val usedVariables = LinkedHashSet<Int>()
            if (model.isFRLG()) {
                usedVariables.addAll(frlg_ThumbVars)
            } else if (model.isEmerald()) {
                usedVariables.addAll(emerald_ThumbVars)
            } else {
                usedVariables.addAll(rs_ThumbVars)
            }

            for (element in getAllEvents(model, "scripts")) {
                if (!element.hasField("trigger")) continue
                usedVariables.add(element.getValue("trigger"))
            }

            for (spot in getAllScriptSpots(model, parser, getAllTopLevelScripts(model), 0x16, 0x17, 0x18, 0x19, 0x1A, 0x21, 0x22, 0x26)) { // setvar, addvar, subvar, copyvar, setorcopyvar, compare, comparevars, special2
                usedVariables.add(model.readMultiByteValue(spot.address + 1, 2))
            }

            return usedVariables
        }
        fun findVarUsages(model: IDataModel, parser: ScriptParser, variable: Int): MutableSet<FlagsFindVarUsagesTuple> { /*@DONE Flags.FindVarUsages/1 cs:131-147*/
            val usages = LinkedHashSet<FlagsFindVarUsagesTuple>()

            for (element in getAllEvents(model, "scripts")) {
                if (!element.hasField("trigger")) continue
                if (element.getValue("trigger") == variable) usages.add(FlagsFindVarUsagesTuple(element.start, element.start + element.length - 1))
            }

            for (spot in getAllScriptSpots(model, parser, getAllTopLevelScripts(model), 0x16, 0x17, 0x18, 0x19, 0x1A, 0x21, 0x22, 0x26)) { // setvar, addvar, subvar, copyvar, setorcopyvar, compare, comparevars, special2
                val address = spot.address
                if (model.readMultiByteValue(address + 1, 2) == variable) {
                    usages.add(FlagsFindVarUsagesTuple(address, address + spot.line.compiledByteLength(model, address, null) - 1))
                }
            }

            return usages
        }
        fun getAllFlagContext(model: IDataModel, parser: ScriptParser): MutableMap<Int, MutableList<FlagContext>> { /*@DONE Flags.GetAllFlagContext/1 cs:158-231*/
            val usedFlags = LinkedHashMap<Int, MutableList<FlagContext>>()
            val filter = intArrayOf(0x29, 0x2A, 0x2B) // setflag, clearflag, checkflag

            fun add(scriptAddress: Int, predicate: (ScriptSpot) -> FlagContext) {
                for (spot in getAllScriptSpots(model, parser, listOf(scriptAddress), *filter)) {
                    val flag = model.readMultiByteValue(spot.address + 1, 2)
                    if (!usedFlags.containsKey(flag)) usedFlags[flag] = ArrayList()
                    usedFlags[flag]!!.add(predicate(spot))
                }
            }

            val banks = AllMapsModel.create(model, null)
            for (bankIndex in 0 until banks.count) {
                val bank = banks[bankIndex]
                if (bank == null) continue
                for (mapIndex in 0 until bank.count) {
                    val map = bank[mapIndex]
                    if (map == null) continue

                    // map header scripts
                    val headerScripts = map.mapScripts
                    if (headerScripts != null) {
                        for (scriptIndex in 0 until headerScripts.size) {
                            val script = headerScripts[scriptIndex]
                            if (script.getValue("type").isAny(2, 4)) {
                                var start = script.getAddress("pointer")
                                if (start >= model.count || start < 0) continue
                                val initialStart = start
                                while (!model.readMultiByteValue(start, 2).isAny(0, 0xFFFF)) {
                                    add(model.readPointer(start + 4)) { spot -> HeaderFlagContext(spot.address, bankIndex, mapIndex, script.getValue("type")) }
                                    start += 8
                                    if (start - initialStart > 100) break // sanity check
                                }
                            } else {
                                add(script.getAddress("pointer")) { spot -> HeaderFlagContext(spot.address, bankIndex, mapIndex, script.getValue("type")) }
                            }
                        }
                    }

                    // objects
                    val objects = map.events.objects ?: ArrayList()
                    for (objectIndex in 0 until objects.size) {
                        val obj = objects[objectIndex]
                        val objFlag = obj.flag
                        if (objFlag != 0) {
                            if (!usedFlags.containsKey(objFlag)) usedFlags[objFlag] = ArrayList()
                            usedFlags[objFlag]!!.add(ObjectFlagContext(obj.element!!.start, bankIndex, mapIndex, objectIndex))
                        }
                        add(obj.scriptAddress) { spot -> ObjectFlagContext(spot.address, bankIndex, mapIndex, objectIndex) }
                    }

                    // scripts
                    val scripts = map.events.scripts
                    for (scriptIndex in 0 until scripts.size) {
                        val script = scripts[scriptIndex]
                        add(script.scriptAddress) { spot -> ScriptFlagContext(spot.address, bankIndex, mapIndex, scriptIndex) }
                    }

                    // signposts
                    val signposts = map.events.signposts
                    for (signpostIndex in 0 until signposts.size) {
                        val signpost = signposts[signpostIndex]
                        if (!signpost.hasScript) continue
                        add(signpost.scriptAddress) { spot -> SignpostFlagContext(spot.address, bankIndex, mapIndex, signpostIndex) }
                    }
                }
            }

            return usedFlags
        }
        fun getBerrySpots(model: IDataModel, parser: ScriptParser): MutableMap<Int, BerrySpot> { /*@DONE Flags.GetBerrySpots/1 cs:233-247*/
            val code = model.getGameCode()
            if (!code.startsWith("AXPE") && !code.startsWith("AXVE") && !code.startsWith("BPEE")) return LinkedHashMap()

            val start = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, "scripts.newgame.setflags")
            if (start < 0 || start >= model.count) return LinkedHashMap()

            val results = LinkedHashMap<Int, BerrySpot>()
            for (spot in getAllScriptSpots(model, parser, listOf(start), 0x8A)) {
                val plantID = model[spot.address + 1]
                val berryID = model[spot.address + 2]
                results[plantID] = BerrySpot(spot.address, berryID - 1)
            }
            return results
        }
        fun getUsedTrainerFlags(model: IDataModel, parser: ScriptParser): MutableSet<Int> { /*@DONE Flags.GetUsedTrainerFlags/1 cs:249-268*/
            val trainerFlags = LinkedHashSet<Int>()

            // check all scripts
            for (spot in getAllScriptSpots(model, parser, getAllTopLevelScripts(model), 0x5C)) {
                val trainerFlag = model.readMultiByteValue(spot.address + 2, 2)
                trainerFlags.add(trainerFlag)
            }

            // check rematch table
            val rematches = model.getTableModel(HardcodeTablesModel.rematchTable)
            if (rematches != null) {
                for (rematch in rematches) {
                    if (!trainerFlags.contains(rematch.getValue("match1"))) continue
                    for (match in listOf("match2", "match3", "match4", "match5", "match6").map { name -> rematch.getValue(name) }) trainerFlags.add(match)
                }
            }

            return trainerFlags
        }
        fun getMinimumLevelForPokemon(model: IDataModel): Map<Int, Int> { /*@DONE Flags.GetMinimumLevelForPokemon/1 cs:272-287*/
            val evolutions = model.getTableModel(HardcodeTablesModel.evolutionTableName)
            val levelMethods = intArrayOf(4, 8, 9, 10, 11, 12, 13, 14)
            val results = LinkedHashMap<Int, Int>()
            if (evolutions == null) return results
            for (evo in evolutions) {
                // method1:evolutionmethods arg1:|s=method1(6=data.items.stats|7=data.items.stats) species1:data.pokemon.names unused1:
                var i = 0
                while (i < evo.length) {
                    val method = model.readMultiByteValue(evo.start + i, 2)
                    if (levelMethods.contains(method)) {
                        val level = model.readMultiByteValue(evo.start + i + 2, 2)
                        val species = model.readMultiByteValue(evo.start + i + 4, 2)
                        results[species] = level
                    }
                    i += 8
                }
            }
            return results
        }
        fun getPokemonDevolutions(model: IDataModel): Map<Int, Int> { /*@DONE Flags.GetPokemonDevolutions/1 cs:292-304*/
            val evolutions = model.getTableModel(HardcodeTablesModel.evolutionTableName)
            val results = LinkedHashMap<Int, Int>()
            if (evolutions == null) return results
            for (evo in evolutions) {
                // method1:evolutionmethods arg1:|s=method1(6=data.items.stats|7=data.items.stats) species1:data.pokemon.names unused1:
                var i = 0
                while (i < evo.length) {
                    val species = model.readMultiByteValue(evo.start + i + 4, 2)
                    results[species] = evo.arrayIndex
                    i += 8
                }
            }
            return results
        }
        fun getPokemonEggMoves(model: IDataModel): Map<Int, List<Int>>? { /*@DONE Flags.GetPokemonEggMoves/1 cs:306-323*/
            val start = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.eggMovesTableName)
            if (start < 0 || start >= model.count) return null
            val eggRun = model.getNextRun(start) as? EggMoveRun ?: return null
            val table = EggTable(model, null, eggRun)
            var currentPokemon = -1
            val results = LinkedHashMap<Int, MutableList<Int>>()
            for (element in table) {
                var value = model.readMultiByteValue(element.address, 2)
                if (element.is_pokemon) {
                    value -= EggMoveRun.magicNumber
                    currentPokemon = value
                } else {
                    results.getOrPut(currentPokemon) { ArrayList() }.add(value)
                }
            }
            return LinkedHashMap<Int, List<Int>>(results)
        }
        fun getPokemonLevelupMoves(model: IDataModel): Map<Int, List<Int>>? { /*@DONE Flags.GetPokemonLevelupMoves/1 cs:325-342*/
            val start = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.levelMovesTableName)
            if (start < 0 || start >= model.count) return null
            val array = model.getNextRun(start) as? ArrayRun ?: return null
            val table = ModelTable(model, array)
            val results = LinkedHashMap<Int, MutableList<Int>>()
            for (element in table) {
                val sub = element.getSubTable("movesFromLevel") ?: continue
                for (move in sub) {
                    if (sub.run.elementContent.size == 1) {
                        results.getOrPut(element.arrayIndex) { ArrayList() }.add(model.readMultiByteValue(move.start, 2) and 0x1FF)
                    } else {
                        val moveIndex = Ref(0)
                        if (move.tryGetValue("move", moveIndex)) results.getOrPut(element.arrayIndex) { ArrayList() }.add(moveIndex.value)
                    }
                }
            }
            return LinkedHashMap<Int, List<Int>>(results)
        }
        fun getPokemonTutorMoves(model: IDataModel): Map<Int, List<Int>>? { /*@DONE Flags.GetPokemonTutorMoves/1 cs:344-361*/
            val start = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.tutorCompatibility)
            if (start < 0 || start >= model.count) return null
            val array = model.getNextRun(start) as? ArrayRun ?: return null
            val table = ModelTable(model, array)
            val options = model.getTableModel(HardcodeTablesModel.moveTutors) ?: return null
            val results = LinkedHashMap<Int, MutableList<Int>>()
            for (element in table) {
                if (!element.hasField("moves")) break
                val move = element.getTuple("moves")
                for (i in 0 until move.fieldCount) {
                    if ((model[element.start + i / 8] and (1 shl (i % 8))) == 0) continue
                    results.getOrPut(element.arrayIndex) { ArrayList() }.add(options[i].getValue(0))
                }
            }
            return LinkedHashMap<Int, List<Int>>(results)
        }
        fun getPokemonTmMoves(model: IDataModel): Map<Int, List<Int>>? { /*@DONE Flags.GetPokemonTmMoves/1 cs:363-380*/
            val start = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.tmCompatibility)
            if (start < 0 || start >= model.count) return null
            val array = model.getNextRun(start) as? ArrayRun ?: return null
            val table = ModelTable(model, array)
            val options = model.getTableModel(HardcodeTablesModel.tmMoves) ?: return null
            val results = LinkedHashMap<Int, MutableList<Int>>()
            for (element in table) {
                if (!element.hasField("moves")) break
                val move = element.getTuple("moves")
                for (i in 0 until move.fieldCount) {
                    if ((model[element.start + i / 8] and (1 shl (i % 8))) == 0) continue
                    results.getOrPut(element.arrayIndex) { ArrayList() }.add(options[i].getValue(0))
                }
            }
            return LinkedHashMap<Int, List<Int>>(results)
        }
        fun getTrainerFlagUsages(model: IDataModel, parser: ScriptParser, flag: Int): MutableSet<Int> { /*@DONE Flags.GetTrainerFlagUsages/1 cs:384-392*/
            val flagUsages = LinkedHashSet<Int>()
            for (spot in getAllScriptSpots(model, parser, getAllTopLevelScripts(model), 0x5C)) {
                val trainerFlag = model.readMultiByteValue(spot.address + 2, 2)
                if (trainerFlag == flag) flagUsages.add(spot.address + 2)
            }
            // TODO need to check the rematch table
            return flagUsages
        }
        fun getTrainerPreference(model: IDataModel, parser: ScriptParser): Map<Int, TrainerPreference> { /*@DONE Flags.GetTrainerPreference/1 cs:394-431*/
            val results = LinkedHashMap<Int, TrainerPreference>()
            val trainers = model.getTableModel(HardcodeTablesModel.trainerTableName) ?: return results

            val classHistogram = LinkedHashMap<Int, LinkedHashMap<Int, Int>>()
            val musicHistogram = LinkedHashMap<Int, LinkedHashMap<Int, Int>>()
            val spriteHistogram = LinkedHashMap<Int, LinkedHashMap<Int, Int>>()

            // for each OW that is a trainer, count up how many times it uses each trainer sprite and music
            // class.data.trainers.classes.names introMusicAndGender.|t|music:::.|female. sprite.graphics.trainers.sprites.front
            for (element in getAllEvents(model, "objects")) {
                if (!element.hasField("graphics")) continue
                val graphics = element.getValue("graphics")
                val desiredClass = classHistogram.getOrPut(graphics) { LinkedHashMap() }
                val desiredMusic = musicHistogram.getOrPut(graphics) { LinkedHashMap() }
                val desiredSprite = spriteHistogram.getOrPut(graphics) { LinkedHashMap() }
                for (spot in getAllScriptSpots(model, parser, listOf(element.getAddress("script")), 0x5C)) {
                    val trainerFlag = model.readMultiByteValue(spot.address + 2, 2)
                    if (trainerFlag >= trainers.size) continue
                    val trainer = trainers[trainerFlag]
                    val pref = TrainerPreference(trainer.getValue("class"), trainer.getValue("introMusicAndGender"), trainer.getValue("sprite"))

                    desiredClass[pref.trainerClass] = (desiredClass[pref.trainerClass] ?: 0) + 1
                    desiredMusic[pref.musicAndGender] = (desiredMusic[pref.musicAndGender] ?: 0) + 1
                    desiredSprite[pref.sprite] = (desiredSprite[pref.sprite] ?: 0) + 1
                }
            }

            for (key in classHistogram.keys) {
                results[key] = TrainerPreference(getKeyWithHighestValue(classHistogram[key]!!), getKeyWithHighestValue(musicHistogram[key]!!), getKeyWithHighestValue(spriteHistogram[key]!!))
            }
            return results
        }
        private fun getKeyWithHighestValue(dict: Map<Int, Int>): Int { /*@DONE Flags.GetKeyWithHighestValue/1 cs:433-440*/
            var bestKey = 0
            var bestValue = -1
            for ((k, v) in dict) {
                if (v > bestValue) {
                    bestKey = k
                    bestValue = v
                }
            }
            return bestKey
        }
        fun getAllScriptSpots(model: IDataModel, parser: ScriptParser, initialAddresses: Iterable<Int>, vararg filter: Int): Iterable<ScriptSpot> { /*@DONE Flags.GetAllScriptSpots/1 cs:442-444*/
            return getAllScriptSpots(model, parser, initialAddresses, true, *filter)
        }
        fun getAllScriptSpots(model: IDataModel, parser: ScriptParser, initialAddresses: Iterable<Int>, includeMacros: Boolean, vararg filter: Int): Iterable<ScriptSpot> { /*@DONE Flags.GetAllScriptSpots/2 cs:446-475*/
            return Iterable {
                iterator {
                    for (scriptStart in initialAddresses) {
                        if (scriptStart < 0 || scriptStart >= model.count) continue
                        val scriptsToCheck = ArrayList<Int>()
                        scriptsToCheck.add(scriptStart)
                        var i = 0
                        while (i < scriptsToCheck.size) {
                            var address = scriptsToCheck[i]
                            var currentScriptLength = 0
                            while (currentScriptLength < scriptLengthLimit) {
                                var line: IScriptLine? = if (includeMacros) parser.getMacro(model, address) else null
                                if (line == null) line = parser.getLine(model, address)
                                if (line == null) break
                                val length = line.compiledByteLength(model, address, null)
                                if (filter.contains(model[address])) yield(ScriptSpot(address, line))

                                var commandOffset = line.lineCode.count
                                for (arg in line.args) {
                                    if (arg.pointerType == ExpectedPointerType.Script) {
                                        val destination = model.readPointer(address + commandOffset)
                                        if (destination >= 0 && destination < model.count && !scriptsToCheck.contains(destination) && scriptsToCheck.size < scriptCountLimit) scriptsToCheck.add(destination)
                                    }
                                    commandOffset += arg.length(model, -1)
                                }

                                if (line.isEndingCommand) break
                                address += length
                                currentScriptLength += length
                            }
                            i++
                        }
                    }
                }
            }
        }
        fun getAllTopLevelScripts(model: IDataModel): MutableSet<Int> { /*@DONE Flags.GetAllTopLevelScripts/1 cs:477-511*/
            val scriptAddresses = LinkedHashSet<Int>()

            for (element in getAllEvents(model, "objects")) scriptAddresses.add(element.getAddress("script"))
            for (element in getAllEvents(model, "scripts")) scriptAddresses.add(element.getAddress("script"))
            for (element in getAllEvents(model, "signposts")) scriptAddresses.add(element.getAddress("arg"))

            // header scripts
            for (bank in AllMapsModel.create(model, null)) {
                for (map in bank) {
                    val scripts = map.mapScripts ?: continue
                    for (script in scripts) {
                        if (script.getValue("type").isAny(2, 4)) {
                            var start = script.getAddress("pointer")
                            var childCount = 0
                            if (start >= model.count || start < 0) continue
                            while (!model.readMultiByteValue(start, 2).isAny(0, 0xFFFF)) {
                                scriptAddresses.add(model.readPointer(start + 4))
                                start += 8
                                childCount += 1
                                if (childCount > 100) break // sanity check
                            }
                        } else {
                            scriptAddresses.add(script.getAddress("pointer"))
                        }
                    }
                }
            }

            return scriptAddresses // takes about <1s
        }
        fun getAllEvents(model: IDataModel, type: String): MutableList<ModelArrayElement> { /*@DONE Flags.GetAllEvents/1 cs:515-538*/
            val elements = ArrayList<ModelArrayElement>()
            val banks = model.getTableModel(HardcodeTablesModel.mapBankTable)
            if (banks == null) return elements
            for (bank in banks) {
                val maps = bank.getSubTable("maps") ?: continue
                for (map in maps) {
                    val mapTable = map.getSubTable("map") ?: continue
                    if (mapTable.size == 0) continue
                    val mapElement = mapTable[0]
                    if (!mapElement.hasField("events")) continue
                    val eventTable = mapElement.getSubTable("events") ?: continue
                    if (eventTable.size == 0) continue
                    val events = eventTable[0]

                    // id. graphics. unused: x:500 y:500 elevation. moveType. range: trainerType: trainerRangeOrBerryID: script<`xse`> flag: unused:
                    val objects = events.getSubTable(type)
                    if (objects != null) elements.addAll(objects)
                }
            }
            return elements
        }
        /*@END Flags.Companion*/
    }
    /*@END Flags*/
}

data class ScriptSpot(val address: Int, val line: IScriptLine) { // cs:541-541
    /*@END ScriptSpot*/
}

data class TrainerPreference(val trainerClass: Int, val musicAndGender: Int, val sprite: Int) { // cs:542-542
    /*@END TrainerPreference*/
}

data class FlagsFindFlagUsagesTuple(val item1: Int, val item2: Int)

data class FlagsFindVarUsagesTuple(val item1: Int, val item2: Int)
