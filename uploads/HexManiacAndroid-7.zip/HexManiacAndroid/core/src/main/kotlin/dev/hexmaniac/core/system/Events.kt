package dev.hexmaniac.core.system

// Kotlin stand-ins for System.EventArgs / EventHandler / INotifyPropertyChanged (see PORTING.md, section "Events").

/** System.EventArgs. `EventArgs.empty` is System.EventArgs.Empty. */
open class EventArgs {
    companion object {
        val empty: EventArgs = EventArgs()
    }
}

/** `EventHandler` (no generic argument) in C#: (sender, EventArgs). */
typealias EventHandler = (Any?, EventArgs) -> Unit

/** `EventHandler<T>` in C#: (sender, T). */
typealias EventHandlerOf<T> = (Any?, T) -> Unit

/**
 * One C# `event`. Declare `val foo = Event<EventArgs>()` for `event EventHandler Foo;` and
 * `val foo = Event<T>()` for `event EventHandler<T> Foo;`.
 *
 * - `x.foo += handler`      (C# `x.Foo += handler`)
 * - `x.foo -= handler`      (C# `x.Foo -= handler`)
 * - `foo(this, args)`       (C# `Foo?.Invoke(this, args)`)
 * - `foo.hasListeners`      (C# `Foo != null`)
 *
 * The handler list is copied before invoking, so handlers may subscribe/unsubscribe while the event is raised.
 */
class Event<T> {
    private var handlers: Array<Any?> = EMPTY

    val hasListeners: Boolean get() = handlers.isNotEmpty()

    operator fun plusAssign(handler: (Any?, T) -> Unit) {
        handlers = handlers + handler
    }

    operator fun minusAssign(handler: (Any?, T) -> Unit) {
        val index = handlers.indexOf(handler)
        if (index < 0) return
        val list = handlers.toMutableList()
        list.removeAt(index)
        handlers = list.toTypedArray()
    }

    @Suppress("UNCHECKED_CAST")
    operator fun invoke(sender: Any?, args: T) {
        val copy = handlers
        for (h in copy) (h as (Any?, T) -> Unit)(sender, args)
    }

    /** C# `a.Foo = b.Foo;` -- replace this event's handler list with the other event's current handlers. */
    fun copyFrom(other: Event<T>) {
        handlers = other.handlers
    }

    fun clear() {
        handlers = EMPTY
    }

    private companion object {
        val EMPTY: Array<Any?> = arrayOfNulls(0)
    }
}

/** `event Action Foo;` -- an event whose handlers take no arguments. Use `foo()` to raise it. */
class ActionEvent {
    private var handlers: Array<Any?> = arrayOfNulls(0)

    val hasListeners: Boolean get() = handlers.isNotEmpty()

    operator fun plusAssign(handler: () -> Unit) {
        handlers = handlers + handler
    }

    operator fun minusAssign(handler: () -> Unit) {
        val index = handlers.indexOf(handler)
        if (index < 0) return
        val list = handlers.toMutableList()
        list.removeAt(index)
        handlers = list.toTypedArray()
    }

    @Suppress("UNCHECKED_CAST")
    operator fun invoke() {
        val copy = handlers
        for (h in copy) (h as () -> Unit)()
    }

    fun clear() {
        handlers = arrayOfNulls(0)
    }
}

/** System.ComponentModel.PropertyChangedEventArgs */
open class PropertyChangedEventArgs(val propertyName: String?) : EventArgs()

/** `PropertyChangedEventHandler` delegate type. */
typealias PropertyChangedEventHandler = (Any?, PropertyChangedEventArgs) -> Unit

/** System.ComponentModel.INotifyPropertyChanged */
interface INotifyPropertyChanged {
    val propertyChanged: Event<PropertyChangedEventArgs>
}

/** Subset of System.Collections.Specialized.NotifyCollectionChangedAction that the app uses. */
enum class NotifyCollectionChangedAction { Add, Remove, Replace, Move, Reset }

/** System.Collections.Specialized.NotifyCollectionChangedEventArgs (only the parts the app reads). */
class NotifyCollectionChangedEventArgs(
    val action: NotifyCollectionChangedAction,
    val newItems: List<Any?>? = null,
    val oldItems: List<Any?>? = null,
    val newStartingIndex: Int = -1,
    val oldStartingIndex: Int = -1,
) : EventArgs()

/** System.Collections.Specialized.INotifyCollectionChanged */
interface INotifyCollectionChanged {
    val collectionChanged: Event<NotifyCollectionChangedEventArgs>
}
