// Port of ViewModels/GotoControlViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.system.ICommandExtensions.canAlwaysExecute

open class GotoShortcutViewModel : ViewModelCore { // cs:16-47
    private lateinit var viewModel: GotoControlViewModel
    private var viewPort: IViewPort? = null
    private var anchor: String = ""
    var displayText: String = ""
        private set
    var image: IPixelViewModel? = null
        private set
    private var _smallMode: Boolean = false
    var smallMode: Boolean
        get() { /*@DONE GotoShortcutViewModel.SmallMode.get cs:27-27*/
            return _smallMode
        }
        set(value) { /*@DONE GotoShortcutViewModel.SmallMode.set cs:28-28*/
            set(_smallMode, value, "smallMode", { _smallMode = it })
        }
    private var _visible: Boolean = /*@INITAUTO GotoShortcutViewModel.visible cs:31-31*/ true /*@ENDINIT*/
    var visible: Boolean
        get() { /*@DONE GotoShortcutViewModel.Visible.get cs:32-32*/
            return _visible
        }
        set(value) { /*@DONE GotoShortcutViewModel.Visible.set cs:32-32*/
            set(_visible, value, "visible", { _visible = it })
        }
    constructor(parent: GotoControlViewModel, viewPort: IViewPort, image: IPixelViewModel?, anchor: String, display: String) { /*@DONE GotoShortcutViewModel.<init>/1 cs:34-40*/
        this.viewModel = parent
        this.viewPort = viewPort
        this.image = image
        this.anchor = anchor
        this.displayText = display
    }
    fun goto() { /*@DONE GotoShortcutViewModel.Goto/1 cs:42-46*/
        viewModel.controlVisible = false
        viewModel.showAll = false
        viewPort?.goto?.execute(anchor)
    }
    /*@END GotoShortcutViewModel*/
}

open class GotoControlViewModel : ViewModelCore { // cs:49-302
    private var viewPort: IEditableViewPort? = null
    private var availableDocs: List<DocLabel> = ArrayList()
    private var withinTextChange: Boolean = /*@INITAUTO GotoControlViewModel.withinTextChange cs:52-52*/ false /*@ENDINIT*/
    private var devMode: Boolean = /*@INITAUTO GotoControlViewModel.devMode cs:52-52*/ false /*@ENDINIT*/
    private var _controlVisible: Boolean = false
    var controlVisible: Boolean
        get() { /*@DONE GotoControlViewModel.ControlVisible.get cs:58-58*/
            return _controlVisible
        }
        set(value) { /*@DONE GotoControlViewModel.ControlVisible.set cs:59-62*/
            if (tryUpdate(_controlVisible, value, "controlVisible") { _controlVisible = it } && value) completionIndex = -1
            if (value) moveFocusToGoto(this, EventArgs.empty)
        }
    private var _loading: Boolean = /*@INITAUTO GotoControlViewModel.loading cs:65-65*/ true /*@ENDINIT*/
    var loading: Boolean
        get() { /*@DONE GotoControlViewModel.Loading.get cs:66-66*/
            return _loading
        }
        set(value) { /*@DONE GotoControlViewModel.Loading.set cs:66-66*/
            set(_loading, value, "loading", { _loading = it })
        }
    private var _text: String = /*@INITAUTO GotoControlViewModel.text cs:68-68*/ "" /*@ENDINIT*/
    var text: String
        get() { /*@DONE GotoControlViewModel.Text.get cs:70-70*/
            return _text
        }
        set(value) { /*@DONE GotoControlViewModel.Text.set cs:71-80*/
            if (viewPort?.model == null) return
            if (tryUpdate(_text, value, "text") { _text = it }) {
                showAll = true
                withinTextChange = true
                StubDisposable { withinTextChange = false }.using {
                    refreshOptions()
                }
            }
        }
    fun refreshOptions() { /*@DONE GotoControlViewModel.RefreshOptions/1 cs:82-84*/
        updatePrefixSelectionsAfterTextChange()
    }
    private var _completionIndex: Int = /*@INITAUTO GotoControlViewModel.completionIndex cs:86-86*/ -1 /*@ENDINIT*/
    var completionIndex: Int
        get() { /*@DONE GotoControlViewModel.CompletionIndex.get cs:88-88*/
            return _completionIndex
        }
        set(value) { /*@DONE GotoControlViewModel.CompletionIndex.set cs:89-93*/
            var newIndex = value
            if (newIndex < -1) newIndex = _autoCompleteOptions.size - 1
            if (newIndex >= _autoCompleteOptions.size) newIndex = -1
            set(_completionIndex, newIndex, "completionIndex", { _completionIndex = it })
        }
    private var _showAutoCompleteOptions: Boolean = false
    var showAutoCompleteOptions: Boolean
        get() { /*@DONE GotoControlViewModel.ShowAutoCompleteOptions.get cs:98-98*/
            return _showAutoCompleteOptions
        }
        set(value) { /*@DONE GotoControlViewModel.ShowAutoCompleteOptions.set cs:99-99*/
            tryUpdate(_showAutoCompleteOptions, value, "showAutoCompleteOptions") { _showAutoCompleteOptions = it }
        }
    private var _autoCompleteOptions: List<AutoCompleteSelectionItem> = /*@INITDONE GotoControlViewModel.autoCompleteOptions cs:102-102*/ ArrayList() /*@ENDINIT*/
    var autoCompleteOptions: List<AutoCompleteSelectionItem>
        get() { /*@DONE GotoControlViewModel.AutoCompleteOptions.get cs:104-104*/
            return _autoCompleteOptions
        }
        private set(value) { /*@DONE GotoControlViewModel.AutoCompleteOptions.set cs:105-105*/
            tryUpdateSequence(_autoCompleteOptions, value, "autoCompleteOptions") { _autoCompleteOptions = it ?: ArrayList() }
        }
    private var _showAll: Boolean = false
    var showAll: Boolean
        get() { /*@DONE GotoControlViewModel.ShowAll.get cs:109-109*/
            return _showAll
        }
        set(value) { /*@DONE GotoControlViewModel.ShowAll.set cs:109-112*/
            set(_showAll, value, "showAll", { _showAll = it }, { _ ->
                if (_showAll) moveFocusToGoto(this, EventArgs.empty)
                updateShortcutSize()
            })
        }
    private fun updateShortcutSize() { /*@DONE GotoControlViewModel.UpdateShortcutSize/1 cs:114-116*/
        for (shortcut in _shortcuts) shortcut.smallMode = false
    }
    private var _allowToggleShowAll: Boolean = /*@INITAUTO GotoControlViewModel.allowToggleShowAll cs:118-118*/ true /*@ENDINIT*/
    var allowToggleShowAll: Boolean
        get() { /*@DONE GotoControlViewModel.AllowToggleShowAll.get cs:119-119*/
            return _allowToggleShowAll
        }
        set(value) { /*@DONE GotoControlViewModel.AllowToggleShowAll.set cs:119-119*/
            set(_allowToggleShowAll, value, "allowToggleShowAll", { _allowToggleShowAll = it })
        }
    lateinit var moveAutoCompleteSelectionUp: ICommand
        private set
    lateinit var moveAutoCompleteSelectionDown: ICommand
        private set
    var goto: ICommand? = null
        private set
    lateinit var showGoto: ICommand
        private set
    val moveFocusToGoto = Event<EventArgs>()
    private var _shortcuts: ObservableCollection<GotoShortcutViewModel> = /*@INITDONE GotoControlViewModel.shortcuts cs:134-134*/ ObservableCollection() /*@ENDINIT*/
    var shortcuts: ObservableCollection<GotoShortcutViewModel>
        get() { /*@DONE GotoControlViewModel.Shortcuts.get cs:136-136*/
            return _shortcuts
        }
        set(value) { /*@DONE GotoControlViewModel.Shortcuts.set cs:137-141*/
            _shortcuts = value
            notifyPropertyChanged("shortcuts")
            updateShortcutSize()
        }
    var prefixSelections: ObservableCollection<GotoLabelSection> = ObservableCollection()
        private set
    constructor(tabContent: ITabContent?, dispatcher: IWorkDispatcher?, docs: List<DocLabel>?, devMode: Boolean) { /*@DONE GotoControlViewModel.<init>/1 cs:146-190*/
        availableDocs = docs ?: ArrayList()
        viewPort = tabContent as? IEditableViewPort
        this.devMode = devMode
        if (tabContent is MapEditorViewModel) viewPort = tabContent.viewPort

        val moveUp = StubCommand()
        moveUp.canExecute = { p -> canAlwaysExecute(p) }
        moveUp.execute = { _ -> completionIndex = completionIndex - 1 }
        moveAutoCompleteSelectionUp = moveUp

        val moveDown = StubCommand()
        moveDown.canExecute = { p -> canAlwaysExecute(p) }
        moveDown.execute = { _ -> completionIndex = completionIndex + 1 }
        moveAutoCompleteSelectionDown = moveDown

        val gotoCommand = StubCommand()
        gotoCommand.canExecute = { _ -> viewPort?.goto != null }
        gotoCommand.execute = { arg ->
            val work: () -> Unit = {
                var currentText = text
                val index = _completionIndex.limitToRange(-1, autoCompleteOptions.size - 1)
                if (index != -1) currentText = autoCompleteOptions[index].completionText
                if (arg is String) currentText = arg
                val editableViewport = viewPort
                if (editableViewport is ViewPort && currentText.startsWith("@") && currentText.contains(" ") && (currentText.contains("^") || currentText.contains("!"))) {
                    // user just put a paste-script into the goto field.
                    // this starts with a meta-input and then contains an anchor definition or another meta command.
                    // Since this is clearly not meant to be a goto, just do it as an Edit instead.
                    editableViewport.edit(currentText + " ")
                } else {
                    viewPort?.goto?.execute(currentText)
                }
                controlVisible = false
                showAutoCompleteOptions = false
            }
            viewPort!!.model!!.initializationWorkload.continueWith { _ ->
                if (dispatcher != null) dispatcher.dispatchWork(work) else work()
            }
            Unit
        }
        goto = gotoCommand

        val showGotoCommand = StubCommand()
        showGotoCommand.canExecute = { arg -> viewPort?.goto != null && (arg is Boolean || arg == null) }
        showGotoCommand.execute = { arg ->
            allowToggleShowAll = false
            controlVisible = (arg as Boolean?) ?: !controlVisible
        }
        showGoto = showGotoCommand

        prefixSelections = ObservableCollection<GotoLabelSection>()
        updatePrefixSelectionsAfterTextChange()
    }
    fun updateDocs(docs: MutableList<DocLabel>) { /*@DONE GotoControlViewModel.UpdateDocs/1 cs:192-194*/
        availableDocs = availableDocs + docs
    }
    private fun updatePrefixSelectionsAfterTextChange() { /*@DONE GotoControlViewModel.UpdatePrefixSelectionsAfterTextChange/1 cs:196-210*/
        val previousSelections = GotoLabelSection.getSectionSelections(prefixSelections).toList()
        prefixSelections.clear()
        val vp = viewPort
        if (vp == null) return
        val model = vp.model
        if (model == null) return
        val section = GotoLabelSection.build(model, text, availableDocs, prefixSelections, vp is ViewPort && vp.hasValidMapper)
        prefixSelections.add(addListeners(section))
        for (i in 0 until previousSelections.size) {
            if (prefixSelections.size <= i) break
            val matchingToken = prefixSelections[i].tokens.firstOrNull { token -> token.content == previousSelections[i] }
            if (matchingToken == null) break
            matchingToken.isSelected = true
        }
        updateTooltips()
        for (sc in _shortcuts) sc.visible = prefixSelections.size == 1
    }
    private fun updatePrefixSelectionsAfterSelectionMade() { /*@DONE GotoControlViewModel.UpdatePrefixSelectionsAfterSelectionMade/1 cs:212-269*/
        val vp = viewPort!!
        val model = vp.model!!
        val currentSelection = GotoLabelSection.getSectionSelections(prefixSelections).joinToString(".")
        var address = Pointer.null_
        val matchedWords = model.getMatchedWords(currentSelection)
        showAll = true
        if (matchedWords != null && matchedWords.size > 0) {
            vp.goto?.execute(currentSelection)
            controlVisible = false
            showAutoCompleteOptions = false
            deselectLastRow()
            return
        }

        val matchedMaps = model.getMatchingMaps(currentSelection)
        if (matchedMaps.size == 1 || matchedMaps.any { map -> map.name == currentSelection }) {
            // if we can add a new section, then don't go to a map
            val newSection = GotoLabelSection.build(model, text, availableDocs, prefixSelections, vp is ViewPort && vp.hasValidMapper)
            if (newSection.tokens.size == 0) {
                vp.goto?.execute(currentSelection)
                controlVisible = false
                showAutoCompleteOptions = false
                deselectLastRow()
                return
            }
        }

        val matchingDoc = availableDocs.firstOrNull { doc -> doc.label == currentSelection }
        if (matchingDoc != null && vp is ViewPort) {
            val newSection = GotoLabelSection.build(model, text, availableDocs, prefixSelections, vp.hasValidMapper)
            if (newSection.tokens.size == 0) {
                openLink(matchingDoc.url)
                controlVisible = false
                showAutoCompleteOptions = false
                deselectLastRow()
                return
            }
        }

        ModelCacheScope.createScope(model).using {
            address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, currentSelection)
        }
        if (address != Pointer.null_ && !withinTextChange) {
            vp.goto?.execute(address)
            controlVisible = false
            showAutoCompleteOptions = false
            deselectLastRow()
        } else if (address != Pointer.null_) {
            // we could go to the address, but this is a text change.
            // The user may try to click the button.
            // Deselect it.
            deselectLastRow()
        } else {
            val newSection = GotoLabelSection.build(model, text, availableDocs, prefixSelections, vp is ViewPort && vp.hasValidMapper)
            prefixSelections.add(addListeners(newSection))
            for (sc in _shortcuts) sc.visible = prefixSelections.size == 1
        }
        updateTooltips()
    }
    private fun openLink(link: String) { /*@DONE GotoControlViewModel.OpenLink/1 cs:271-271*/
        NativeProcess.start(link)
    }
    private fun updateTooltips() { /*@DONE GotoControlViewModel.UpdateTooltips/1 cs:273-284*/
        val vp = viewPort!!
        val model = vp.model!!
        ModelCacheScope.createScope(model).using {
            for (prefix in prefixSelections) {
                val currentSelection = GotoLabelSection.getSectionSelections(prefixSelections.takeWhile { section -> section !== prefix }).joinToString(".")
                for (token in prefix.tokens) {
                    var fullName = token.content
                    if (currentSelection.isNotEmpty()) fullName = currentSelection + "." + token.content
                    token.updateHoverTip(vp, availableDocs, fullName)
                }
            }
        }
    }
    private fun deselectLastRow() { /*@DONE GotoControlViewModel.DeselectLastRow/1 cs:286-289*/
        showAll = true
        for (token in prefixSelections.last().tokens) token.isSelected = false
    }
    private fun addListeners(section: GotoLabelSection): GotoLabelSection { /*@DONE GotoControlViewModel.AddListeners/1 cs:291-301*/
        section.clearLowerRows += { sender, _ ->
            val index = prefixSelections.indexOf(sender as GotoLabelSection)
            while (index >= 0 && prefixSelections.size > index + 1) prefixSelections.removeAt(prefixSelections.size - 1)
            for (sc in _shortcuts) sc.visible = prefixSelections.size == 1
        }
        section.generateLowerRow += { _, _ ->
            updatePrefixSelectionsAfterSelectionMade()
        }
        return section
    }
    /*@END GotoControlViewModel*/
}

fun IDataModel?.getExtendedAutocompleteOptions(text: String): List<String>? { /*@DONE IDataModelExtensions.GetExtendedAutocompleteOptions/1 cs:310-340*/
    val model = this
    var text = text.replace("\u00e9", "e")
    var sanitizedText = text.replace(" ", "")
    val textWithExtension = sanitizedText
    if (sanitizedText.endsWith("~1")) sanitizedText = sanitizedText.substring(0, Math.min(text.length - 2, sanitizedText.length))
    val options = ArrayList<String>()
    model?.getAutoCompleteAnchorNameOptions(sanitizedText, Int.MAX_VALUE)?.let { found -> options.addAll(found) }
    model?.getAutoCompleteByteNameOptions(sanitizedText)?.let { found -> options.addAll(found) }
    text = text.lowercase()
    for (i in 1 until text.length) {
        val isEndOfSection = i == text.length - 1 || !text[i + 1].isLetter()
        val isY = "yY".contains(text[i])
        if (isY && isEndOfSection) {
            val startOfText = text.substring(0, i - 1)
            val endOfText = text.substring(i + 1)
            val pluralResults = (model.getExtendedAutocompleteOptions(startOfText + "ies" + endOfText) ?: emptyList<String>())
                .filter { result -> !options.contains(result) }
                .distinct()
            options.addAll(pluralResults)
        }
    }
    if (!sanitizedText.contains("/") && sanitizedText.length >= 3) {
        val slashed = model?.getAutoCompleteAnchorNameOptions("/" + sanitizedText)
        if (slashed != null) options.addAll(slashed.filter { option -> option.lowercase().replace(" ", "").matchesPartial(sanitizedText.lowercase()) })
    }
    val bestMatches = options.filter { option -> option.lowercase().contains(text) }
    var result: List<String> = (bestMatches + options).distinct()
    if (textWithExtension.endsWith("~1")) {
        // user only wants the first token that matches, for example, TERRY but not TERRY~2
        result = result.filter { option -> !option.contains("~") || option.contains("~1") }
    }
    return result
}
fun IDataModel.getMatchingMaps(text: String): MutableList<MapInfo> { /*@DONE IDataModelExtensions.GetMatchingMaps/1 cs:353-363*/
    if (!IDataModelExtensions.editorReleased) return ArrayList()

    val allMaps = this.currentCacheScope.getAllMaps()
    val results = allMaps.filter { map -> map.name.matchesPartial(text) && map.name.skipCount(text) <= text.length }.toMutableList()
    val lower = text.lowercase()
    for (result in results) {
        if (result.name.lowercase() == lower) return arrayListOf(result)
    }
    return results
}
fun List<DocLabel>.getMatchingDocumentation(text: String): MutableList<DocLabel> { /*@DONE IDataModelExtensions.GetMatchingDocumentation/1 cs:365-367*/
    return this.filter { doc -> doc.label.matchesPartial(text) }.toMutableList()
}

object IDataModelExtensions { // cs:304-368
    val editorReleased: Boolean
        get() { /*@DONE IDataModelExtensions.EditorReleased.get cs:342-342*/
            return mapEditorRelease.value
        }
    private lateinit var mapEditorRelease: Lazy<Boolean>
    init { /*@DONE IDataModelExtensions.<cctor>/1 cs:345-351*/
        mapEditorRelease = lazy {
            val central = java.util.TimeZone.getTimeZone("America/Chicago")
            val release = java.util.Calendar.getInstance(central)
            release.clear()
            release.set(2022, java.util.Calendar.DECEMBER, 25, 12, 0, 0)
            System.currentTimeMillis() >= release.timeInMillis
        }
    }
    /*@END IDataModelExtensions*/
}

open class GotoLabelSection : ViewModelCore { // cs:370-483
    private var _width: Int = 0
    private var _height: Int = 0
    var width: Int
        get() { /*@DONE GotoLabelSection.Width.get cs:373-373*/
            return _width
        }
        set(value) { /*@DONE GotoLabelSection.Width.set cs:373-373*/
            set(_width, value, "width", { _width = it })
        }
    var height: Int
        get() { /*@DONE GotoLabelSection.Height.get cs:374-374*/
            return _height
        }
        set(value) { /*@DONE GotoLabelSection.Height.set cs:374-374*/
            set(_height, value, "height", { _height = it })
        }
    var tokens: ObservableCollection<GotoToken> = ObservableCollection()
        private set
    val generateLowerRow = Event<EventArgs>()
    val clearLowerRows = Event<EventArgs>()
    constructor(allOptions: Iterable<String>, previousSectionSelections: Iterable<String>) { /*@DONE GotoLabelSection.<init>/1 cs:380-405*/
        var prefix = previousSectionSelections.joinToString(".")
        if (prefix.length > 0) prefix += "."
        val thisLevel = LinkedHashSet<String>()

        // display order is alphabetically sorted non-numeric entries, followed by insert-order numeric entries
        val noNumbers = ArrayList<String>()
        val hasNumbers = ArrayList<String>()
        for (option in allOptions) {
            if (option.any { c -> gotoIsNumberChar(c) }) hasNumbers.add(option)
            else noNumbers.add(option)
        }
        for (option in noNumbers.sortedWith(gotoStringComparer) + hasNumbers) {
            if (option.startsWith(prefix)) {
                thisLevel.add(dotSplit(option.substring(prefix.length)))
            }
        }

        this.tokens = GotoToken.generate(thisLevel)
        val count = this.tokens.size
        if (count > maxCategories) {
            this.tokens.clear()
            val overflow = GotoToken()
            overflow.content = "(" + count + " options)"
            overflow.isSelectable = false
            this.tokens.add(overflow)
        }
        initialize()
    }
    private fun dotSplit(content: String): String { /*@DONE GotoLabelSection.DotSplit/1 cs:407-425*/
        val parts = content.split(".")
        var firstPart = parts[0]
        for (i in 1 until parts.size) {
            if (parts[i].length == 0 || parts[i][0] == ' ' || firstPart.count { c -> c == '"' } % 2 != 0) {
                // "Mr. Mime" and similar names with ". " should not be split.
                firstPart += "." + parts[i]
            } else if (firstPart.count { c -> c == '(' } > firstPart.count { c -> c == ')' }) {
                // () pairs should not be split
                firstPart += "." + parts[i]
            } else if (firstPart.length == 1) {
                // signle letters should not be split
                firstPart += "." + parts[i]
            } else {
                break
            }
        }
        return firstPart
    }
    constructor(prefix: String, tokens: MutableList<GotoToken>) { /*@DONE GotoLabelSection.<init>/2 cs:427-436*/
        val sortedTokens = tokens.sortedWith(Comparator { a, b -> gotoStringComparer.compare(a.content, b.content) })
        this.tokens = ObservableCollection<GotoToken>()
        for (token in sortedTokens) {
            val copy = GotoToken()
            copy.content = prefix + "." + token.content
            copy.isSelected = token.isSelected
            copy.isSelectable = token.isSelectable
            this.tokens.add(copy)
        }
        if (sortedTokens.size == 0) {
            val single = GotoToken()
            single.content = prefix
            this.tokens.add(single)
            if (prefix.endsWith(" options)")) this.tokens[0].isSelectable = false
        }
        initialize()
    }
    private fun initialize() { /*@DONE GotoLabelSection.Initialize/1 cs:438-451*/
        _height = Math.floor(Math.sqrt(tokens.size.toDouble())).toInt()
        _width = Math.ceil(tokens.size / _height.toDouble()).toInt()
        for (token in tokens) {
            token.bind("isSelected") { obj, _ ->
                if (!obj.isSelected) {
                    clearLowerRows(this, EventArgs.empty)
                } else {
                    for (t in tokens) t.isSelected = t === token
                    generateLowerRow(this, EventArgs.empty)
                }
            }
        }
    }
    companion object {
        private const val maxCategories: Int = 49
        fun getSectionSelections(sections: Iterable<GotoLabelSection>): Iterable<String> { /*@DONE GotoLabelSection.GetSectionSelections/1 cs:453-459*/
            val result = ArrayList<String>()
            for (section in sections) {
                val selectedToken = section.tokens.firstOrNull { token -> token.isSelected }
                if (selectedToken == null) break
                result.add(selectedToken.content)
            }
            return result
        }
        fun build(model: IDataModel, filter: String, docs: List<DocLabel>, previousSections: Iterable<GotoLabelSection>, includeMatchingMaps: Boolean): GotoLabelSection { /*@DONE GotoLabelSection.Build/1 cs:461-482*/
            return ModelCacheScope.createScope(model).using {
                val allOptions = ArrayList<String>()
                model.getExtendedAutocompleteOptions(filter)?.let { found -> allOptions.addAll(found) }
                allOptions.addAll(model.getMatchingMaps(filter).map { map -> map.name })
                allOptions.addAll(docs.getMatchingDocumentation(filter).map { doc -> doc.label })
                val selections = getSectionSelections(previousSections).toList()

                var newSection = GotoLabelSection(allOptions, selections)
                if (newSection.tokens.size == 1) {
                    newSection.tokens[0].isSelected = true
                    val child = build(model, filter, docs, previousSections + newSection, includeMatchingMaps) // recursion ftw
                    // only do the concatenation if the children are not unreadable long
                    if (child.tokens.all { token -> token.content.length < 20 }) {
                        newSection = GotoLabelSection(newSection.tokens[0].content, child.tokens)
                    } else {
                        newSection.tokens[0].isSelected = false
                    }
                }

                newSection
            }
        }
        /*@END GotoLabelSection.Companion*/
    }
    /*@END GotoLabelSection*/
}

open class GotoToken : ViewModelCore() { // cs:485-556
    private var _isSelected: Boolean = false
    var isSelected: Boolean
        get() { /*@DONE GotoToken.IsSelected.get cs:487-487*/
            return _isSelected
        }
        set(value) { /*@DONE GotoToken.IsSelected.set cs:487-487*/
            set(_isSelected, value, "isSelected", { _isSelected = it })
        }
    private var _isSelectable: Boolean = /*@INITAUTO GotoToken.isSelectable cs:489-489*/ true /*@ENDINIT*/
    var isSelectable: Boolean
        get() { /*@DONE GotoToken.IsSelectable.get cs:490-490*/
            return _isSelectable
        }
        set(value) { /*@DONE GotoToken.IsSelectable.set cs:490-490*/
            set(_isSelectable, value, "isSelectable", { _isSelectable = it })
        }
    private var _content: String = ""
    var content: String
        get() { /*@DONE GotoToken.Content.get cs:493-493*/
            return _content
        }
        set(value) { /*@DONE GotoToken.Content.set cs:493-493*/
            set(_content, value, "content", { _content = it })
        }
    private var _isGoto: Boolean = false
    var isGoto: Boolean
        get() { /*@DONE GotoToken.IsGoto.get cs:496-496*/
            return _isGoto
        }
        set(value) { /*@DONE GotoToken.IsGoto.set cs:496-496*/
            set(_isGoto, value, "isGoto", { _isGoto = it })
        }
    private var _hoverTip: ObservableCollection<Any>? = null
    var hoverTip: ObservableCollection<Any>?
        get() { /*@DONE GotoToken.HoverTip.get cs:500-500*/
            return _hoverTip
        }
        set(value) { /*@DONE GotoToken.HoverTip.set cs:501-501*/
            _hoverTip = value
            notifyPropertyChanged("hoverTip")
        }
    fun updateHoverTip(viewPort: IEditableViewPort, docs: List<DocLabel>, fullName: String) { /*@DONE GotoToken.UpdateHoverTip/1 cs:510-555*/
        val model = viewPort.model!!
        var matchingMaps: List<MapInfo> = ArrayList()
        if (fullName.startsWith("maps.bank") && fullName.contains("-")) matchingMaps = model.getMatchingMaps(fullName)
        val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, fullName)
        val matchingDoc = docs.firstOrNull { doc -> doc.label == fullName }
        if (address != Pointer.null_) {
            isGoto = true
            val run = model.getNextRun(address)
            if (run != null && address == run.start) {
                val hoverContent = ToolTipContentVisitor.buildContentForRun(model, -1, address, run)
                if (hoverContent != null) {
                    val single = ObservableCollection<Any>()
                    single.add(hoverContent)
                    hoverTip = single
                    return
                }
            }
        } else if (matchingMaps.size == 1 && viewPort.mapEditor != null) {
            isGoto = true
            val info = matchingMaps[0]
            var hoverContent: IPixelViewModel? = viewPort.mapEditor!!.getMapPreview(info.group, info.map, null)
            if (hoverContent != null) {
                var scale = 1.0
                if (hoverContent.pixelWidth >= 240 * 4 || hoverContent.pixelHeight >= 160 * 4) {
                    scale = .25
                } else if (hoverContent.pixelWidth >= 240 * 2 || hoverContent.pixelHeight >= 160 * 2) {
                    scale = .5
                }
                if (scale < 1) {
                    val scaled = ReadonlyPixelViewModel(hoverContent.pixelWidth, hoverContent.pixelHeight, hoverContent.pixelData, hoverContent.transparent)
                    scaled.spriteScale = scale
                    hoverContent = scaled
                }
                val single = ObservableCollection<Any>()
                single.add(hoverContent)
                hoverTip = single
                return
            }
        } else if (matchingDoc != null) {
            isGoto = true
            val single = ObservableCollection<Any>()
            single.add("Web Link")
            hoverTip = single
        } else if ((model.getMatchedWords(fullName)?.size ?: 0) > 0) {
            isGoto = true
        } else {
            isGoto = false
        }

        hoverTip = null
    }
    companion object {
        fun generate(content: Iterable<String>): ObservableCollection<GotoToken> { /*@DONE GotoToken.Generate/1 cs:504-508*/
            val collection = ObservableCollection<GotoToken>()
            for (c in content) {
                val token = GotoToken()
                token.content = c
                collection.add(token)
            }
            return collection
        }
        /*@END GotoToken.Companion*/
    }
    /*@END GotoToken*/
}

/*@ADD file:viewmodels/GotoControlViewModel.kt#goto_dex.txt*/
/** .NET's char.IsNumber: decimal digits, letter numbers (roman numerals) and other numbers (fractions, superscripts...). */
internal fun gotoIsNumberChar(c: Char): Boolean {
    val type = Character.getType(c)
    return type == Character.DECIMAL_DIGIT_NUMBER.toInt() || type == Character.LETTER_NUMBER.toInt() || type == Character.OTHER_NUMBER.toInt()
}

/** The default string ordering of C# (culture sensitive), used by OrderBy(text => text). */
private val gotoCollator: java.text.Collator = java.text.Collator.getInstance()
internal val gotoStringComparer: Comparator<String> = Comparator { a, b -> gotoCollator.compare(a, b) }
/*@ENDADD file:viewmodels/GotoControlViewModel.kt#goto_dex.txt*/
