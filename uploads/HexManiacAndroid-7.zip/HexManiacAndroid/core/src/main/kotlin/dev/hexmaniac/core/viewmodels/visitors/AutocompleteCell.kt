// Port of ViewModels/Visitors/AutocompleteCell.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class AutocompleteCell : IDataFormatVisitor { // cs:9-122
    lateinit var model: IDataModel
        private set
    var inputText: String = ""
        private set
    var selectionIndex: Int = 0
        private set
    var result: Iterable<AutoCompleteSelectionItem>? = null
        private set
    constructor(model: IDataModel, input: String, index: Int) { /*@DONE AutocompleteCell.<init>/1 cs:16-16*/
        this.model = model
        this.inputText = input
        this.selectionIndex = index
    }
    private fun visitNormal() { /*@DONE AutocompleteCell.VisitNormal/1 cs:18-26*/
        if (inputText.startsWith(PointerRun.pointerStart.toString())) {
            result = model.getNewPointerAutocompleteOptions(inputText, selectionIndex)
        } else if (inputText.startsWith(ViewPort.gotoMarker.toString())) {
            result = model.getNewPointerAutocompleteOptions(inputText, selectionIndex)
        } else if (inputText.startsWith(":")) {
            result = model.getNewWordAutocompleteOptions(inputText, selectionIndex)
        }
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE AutocompleteCell.Visit/1 cs:28-28*/
        // undefined cells have no autocomplete
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE AutocompleteCell.Visit/2 cs:30-30*/
        visitNormal()
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE AutocompleteCell.Visit/3 cs:32-32*/
        throw NotImplementedException()
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE AutocompleteCell.Visit/4 cs:34-34*/
        visitNormal()
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE AutocompleteCell.Visit/5 cs:36-36*/
        anchor.originalFormat!!.visit(this, data)
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE AutocompleteCell.Visit/6 cs:38-38*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE AutocompleteCell.Visit/7 cs:40-40*/
        decorator.originalFormat!!.visit(this, data)
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE AutocompleteCell.Visit/8 cs:42-42*/
        // no autocomplete for text characters
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE AutocompleteCell.Visit/9 cs:44-44*/
        // no autocomplete
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE AutocompleteCell.Visit/10 cs:46-46*/
        // no autocomplete
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE AutocompleteCell.Visit/11 cs:48-48*/
        // no autocomplete
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE AutocompleteCell.Visit/12 cs:50-50*/
        // no autocomplete
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE AutocompleteCell.Visit/13 cs:52-52*/
        // no autocomplete
    }
    override fun visit(intEnum: IntegerEnum, data: Int) { /*@DONE AutocompleteCell.Visit/14 cs:54-54*/
        generateOptions(intEnum)
    }
    override fun visit(integer: IntegerHex, data: Int) { /*@DONE AutocompleteCell.Visit/15 cs:56-56*/
        // no autocomplete
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE AutocompleteCell.Visit/16 cs:58-58*/
        visitEgg(section)
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE AutocompleteCell.Visit/17 cs:60-60*/
        visitEgg(item)
    }
    private fun visitEgg(eggFormat: IDataFormatInstance) { /*@DONE AutocompleteCell.VisitEgg/1 cs:62-66*/
        val eggRun = model.getNextRun(eggFormat.source) as EggMoveRun
        val allOptions = eggRun.getAutoCompleteOptions()
        result = AutoCompleteSelectionItem.generate(allOptions.filter { option -> option.matchesPartial(inputText) }, selectionIndex)
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE AutocompleteCell.Visit/18 cs:68-83*/
        if (!inputText.contains(" ")) {
            result = AutoCompleteSelectionItem.generate(emptyList<String>(), -1)
            return
        }

        val moveName = inputText.substring(inputText.indexOf(' ')).trim()
        if (moveName.length == 0) {
            result = AutoCompleteSelectionItem.generate(emptyList<String>(), -1)
            return
        }

        val plmRun = model.getNextRun(item.source) as PLMRun
        val allOptions = plmRun.getAutoCompleteOptions(inputText.split(' ')[0])
        result = AutoCompleteSelectionItem.generate(allOptions.filter { option -> option.matchesPartial(moveName) }, selectionIndex)
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE AutocompleteCell.Visit/19 cs:85-85*/
        generateOptions(array)
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE AutocompleteCell.Visit/20 cs:87-87*/
        visitNormal()
    }
    override fun visit(stream: EndStream, data: Int) { /*@DONE AutocompleteCell.Visit/21 cs:89-89*/
        // no autocomplete
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE AutocompleteCell.Visit/22 cs:91-91*/
        // no autocomplete
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE AutocompleteCell.Visit/23 cs:93-93*/
        // no autocomplete
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE AutocompleteCell.Visit/24 cs:95-95*/
        // no autocomplete
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE AutocompleteCell.Visit/25 cs:97-97*/
        // no autocomplete
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE AutocompleteCell.Visit/26 cs:99-99*/
        // no autocomplete
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE AutocompleteCell.Visit/27 cs:101-111*/
        val options = tuple.model!!.getAutocomplete(model, inputText)
        val generated: Iterable<AutoCompleteSelectionItem>
        if (options == null || options.size == 0) {
            generated = ArrayList<AutoCompleteSelectionItem>()
        } else {
            generated = AutoCompleteSelectionItem.generate2(options, selectionIndex)
        }
        result = generated
        for (vm in generated) vm.isFormatComplete = vm.completionText.endsWith(")")
    }
    private fun generateOptions(format: IDataFormatInstance) { /*@DONE AutocompleteCell.GenerateOptions/1 cs:113-121*/
        val arrayRun = model.getNextRun(format.source) as ITableRun
        val offsets = arrayRun.convertByteOffsetToArrayOffset(format.source)
        var contentSegment = arrayRun.elementContent[offsets.segmentIndex]
        if (contentSegment is ArrayRunRecordSegment) contentSegment = contentSegment.createConcrete(model, format.source)
        val segment = contentSegment as IHasOptions
        val allOptions = (segment.getOptions(model) ?: emptyList<String>()).map { option -> option + " " }
        result = AutoCompleteSelectionItem.generate(ArrayRunEnumSegment.getBestOptions(allOptions, inputText, true), -1)
    }
    /*@END AutocompleteCell*/
}
