// Port of Models/Runs/PCSRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class PCSRun : BaseRun, IStreamRun, IAppendToBuilderRun { // cs:10-95
    private lateinit var model: IDataModel
    private var cachedIndex: Int = /*@INITDONE PCSRun.cachedIndex cs:15-15*/ Int.MAX_VALUE /*@ENDINIT*/
    private var cachedFullString: String = ""
    final override var length: Int = 0
        private set
    override val formatString: String
        get() { /*@DONE PCSRun.FormatString.get cs:19-19*/
            return sharedFormatString
        }
    constructor(model: IDataModel, start: Int, length: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE PCSRun.<init>/1 cs:21-21*/
        this.model = model
        this.length = length
    }
    fun equals(run: IFormattedRun): Boolean { /*@DONE PCSRun.Equals/1 cs:23-26*/
        if (run !is PCSRun) return false
        return start == run.start && length == run.length && model === run.model
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE PCSRun.CreateDataFormat/1 cs:28-37*/
        Debug.assert(data === model)

        // only read the full string from the data once per pass.
        // This assumes that we read data starting at the lowest index and working our way up.
        if (index < cachedIndex) cachedFullString = data.textConverter.convert(data, start, length) ?: ""
        cachedIndex = index

        return createPCSFormat(data, start, index, cachedFullString)
    }
    override fun serializeRun(): String? { /*@DONE PCSRun.SerializeRun/1 cs:55-59*/
        var newContent = model.textConverter.convert(model, start, length) ?: "\"\""
        newContent = newContent.substring(1, newContent.length - 1) // remove quotes
        return newContent
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE PCSRun.DeserializeRun/1 cs:61-75*/
        changedRuns.value = ArrayList<Int>()
        val bytes = model.textConverter.convert(content, Ref(false))!!
        val changedAddresses = ArrayList<Int>()
        val newRun = model.relocateForExpansion(token, this, bytes.size)

        // clear out excess bytes that are no longer in use
        if (start == newRun.start) {
            for (i in bytes.size until length) token.changeData(model, start + i, 0xFF)
        }

        if (token.changeData(model, newRun.start, bytes.toByteArrayU().asByteList())) changedAddresses.add(newRun.start)
        changedOffsets.value = changedAddresses
        return PCSRun(model, newRun.start, bytes.size, newRun.pointerSources)
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE PCSRun.GetAutoCompleteOptions/1 cs:77-80*/
        val result = ArrayList<AutocompleteItem>()
        return result
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE PCSRun.Visualizations.get cs:82-82*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    override fun dependsOn(anchorName: String): Boolean { /*@DONE PCSRun.DependsOn/1 cs:84-84*/
        return false
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE PCSRun.Clone/1 cs:86-86*/
        return PCSRun(model, start, length, newPointerSources)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE PCSRun.AppendTo/1 cs:88-88*/
        builder.append(model.textConverter.convert(model, this.start, this.length, includeNewlineCharacters = true) ?: "")
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE PCSRun.Clear/1 cs:90-94*/
        for (i in 0 until length) {
            changeToken.changeData(model, start + i, 0xFF)
        }
    }
    companion object {
        const val stringDelimeter: Char = '\"'
        val sharedFormatString: String = /*@INITDONE PCSRun.SharedFormatString cs:12-12*/ stringDelimeter.toString() + "" + stringDelimeter /*@ENDINIT*/
        fun createPCSFormat(model: IDataModel, start: Int, index: Int, fullString: String): IDataFormat { /*@DONE PCSRun.CreatePCSFormat/1 cs:39-53*/
            val isEscaped = PCSString.isEscaped(model, index)
            if (isEscaped) {
                return EscapedPCS(start, index - start, fullString, model[index])
            } else {
                val pcsCharacters = PCSString.convert(model, index, 1)
                if (pcsCharacters == null) {
                    return ErrorPCS(start, index - start, fullString, model[index])
                }
                var character = pcsCharacters.substring(1) // trim leading "
                if (index == start) character = stringDelimeter.toString() + character // include the opening quotation mark, only for the first character
                val pcs = PCS(start, index - start, fullString, character)
                return pcs
            }
        }
        /*@END PCSRun.Companion*/
    }
    /*@END PCSRun*/
}
