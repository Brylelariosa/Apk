// Port of ViewModels/Tools/CodeBody.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*

open class CodeBody : ViewModelCore { // cs:13-558
    private lateinit var model: IDataModel
    private lateinit var _parser: ScriptParser
    private var investigator: IDataInvestigator? = null
    private var gameHash: Int = 0
    val contentChanged = Event<ExtendedPropertyChangedEventArgs<String>>()
    val requestShowSearchResult = Event<MutableSet<CodeBodyRequestShowSearchResultTuple>>()
    val helpSourceChanged = Event<HelpContext>()
    private var _label: String = ""
    var label: String
        get() { /*@DONE CodeBody.Label.get cs:29-29*/
            return _label
        }
        set(value) { /*@DONE CodeBody.Label.set cs:30-30*/
            tryUpdate(_label, value, "label", { _label = it })
        }
    private var _address: Int = 0
    var address: Int
        get() { /*@DONE CodeBody.Address.get cs:35-35*/
            return _address
        }
        set(value) { /*@DONE CodeBody.Address.set cs:36-36*/
            tryUpdate(_address, value, "address", { _address = it })
        }
    private var _compiledLength: Int = 0
    var compiledLength: Int
        get() { /*@DONE CodeBody.CompiledLength.get cs:41-41*/
            return _compiledLength
        }
        set(value) { /*@DONE CodeBody.CompiledLength.set cs:42-42*/
            tryUpdate(_compiledLength, value, "compiledLength", { _compiledLength = it })
        }
    private var _hasError: Boolean = false
    var hasError: Boolean
        get() { /*@DONE CodeBody.HasError.get cs:46-46*/
            return _hasError
        }
        set(value) { /*@DONE CodeBody.HasError.set cs:46-46*/
            tryUpdate(_hasError, value, "hasError", { _hasError = it })
        }
    private var _errorText: String? = ""
    var errorText: String?
        get() { /*@DONE CodeBody.ErrorText.get cs:49-49*/
            return _errorText
        }
        set(value) { /*@DONE CodeBody.ErrorText.set cs:49-49*/
            tryUpdate(_errorText, value, "errorText", { _errorText = it })
        }
    val parser: ScriptParser
        get() { /*@DONE CodeBody.Parser.get cs:51-51*/
            return _parser
        }
    val canInsertFlag: Boolean
        get() { /*@DONE CodeBody.CanInsertFlag.get cs:56-73*/
            if (investigator == null || model.spartanMode) return false
            val context = splitCurrentLine()
            if (context.contentBoundaryCount != 0) return false

            // only available if the previous character is a space
            if (context.index == 0 || context.line[context.index - 1] != ' ') return false

            // only available if the next parameter is a flag
            val line = _parser.firstMatch(context.line.trim()) ?: return false
            val tokens = ScriptLine.tokenize(context.line.substring(0, context.index))
            if (tokens.size == 0) return false
            val args: List<IScriptArg> = if (line is MacroScriptLine) (line.shortFormArgs ?: line.args) else line.args
            if (args.size < tokens.size) return false
            val currentArg = args[tokens.size - 1]
            return currentArg.name == "flag" && currentArg.type == ArgType.Short && currentArg.enumTableName == "|h"
        }
    val canInsertVar: Boolean
        get() { /*@DONE CodeBody.CanInsertVar.get cs:77-94*/
            if (investigator == null || model.spartanMode) return false
            val context = splitCurrentLine()
            if (context.contentBoundaryCount != 0) return false

            // only available if the previous character is a space
            if (context.index == 0 || context.line[context.index - 1] != ' ') return false

            // only available if the next parameter is a variable
            val line = _parser.firstMatch(context.line.trim()) ?: return false
            val tokens = ScriptLine.tokenize(context.line.substring(0, context.index))
            if (tokens.size == 0) return false
            val args: List<IScriptArg> = if (line is MacroScriptLine) (line.shortFormArgs ?: line.args) else line.args
            if (args.size < tokens.size) return false
            val currentArg = args[tokens.size - 1]
            return currentArg.name == "variable" && currentArg.type == ArgType.Short && currentArg.enumTableName == "scriptvariablealiases"
        }
    fun insertFlag() { /*@DONE CodeBody.InsertFlag/1 cs:97-117*/
        val contentBuilder = StringBuilder(content.substring(0, caretPosition))
        val afterContent = content.substring(caretPosition)
        val flag = investigator?.findNextUnusedFlag() ?: return

        var newContent = "0x" + flag.toHex(4)
        val context = splitCurrentLine()
        val lineContent = context.line.substring(0, context.index) + newContent
        val line = _parser.firstMatch(lineContent.trim())
        if (line != null) {
            if (line.errorCheck(lineContent, Ref<Array<String>?>(null)) != null) newContent += " "
            contentBuilder.append(newContent)

            contentBuilder.append(afterContent)
            val caret = editor.caretIndex
            content = contentBuilder.toString()
            editor.caretIndex = caret + newContent.length
            notifyPropertyChanged("canInsertFlag")
        }
        editor.focusKeyboard()
    }
    fun insertVar() { /*@DONE CodeBody.InsertVar/1 cs:119-139*/
        val contentBuilder = StringBuilder(content.substring(0, caretPosition))
        val afterContent = content.substring(caretPosition)
        val variable = investigator?.findNextUnusedVariable() ?: return

        var newContent = "0x" + variable.toHex(4)
        val context = splitCurrentLine()
        val lineContent = context.line.substring(0, context.index) + newContent
        val line = _parser.firstMatch(lineContent.trim())
        if (line != null) {
            if (line.errorCheck(lineContent, Ref<Array<String>?>(null)) != null) newContent += " "
            contentBuilder.append(newContent)

            contentBuilder.append(afterContent)
            val caret = editor.caretIndex
            content = contentBuilder.toString()
            editor.caretIndex = caret + newContent.length
            notifyPropertyChanged("canInsertVar")
        }
        editor.focusKeyboard()
    }
    fun insertFlagOrVar() { /*@DONE CodeBody.InsertFlagOrVar/1 cs:141-147*/
        if (canInsertFlag) {
            insertFlag()
        } else if (canInsertVar) {
            insertVar()
        }
    }
    val canFindUses: Boolean
        get() { /*@DONE CodeBody.CanFindUses.get cs:153-166*/
            if (caretPosition < 0 || model.spartanMode) return false
            val context = splitCurrentLine()
            if (context.contentBoundaryCount != 0) return false
            var left = context.index
            var right = context.index
            while (left.inRange(1, context.line.length) && context.line[left] != ' ') left--
            while (right < context.line.length && context.line[right] != ' ') right++
            val token = context.line.substring(left, right).trim()
            if (!token.tryParseInt(Ref(0))) return false
            val line = _parser.firstMatch(context.line.trim()) ?: return false
            if (line.args.all { arg -> arg.name != "variable" && arg.name != "flag" }) return false
            return true
        }
    fun findUses() { /*@DONE CodeBody.FindUses/1 cs:169-186*/
        val context = splitCurrentLine()
        if (context.contentBoundaryCount != 0) return
        var left = context.index
        var right = context.index
        while (right < context.line.length && context.line[right] != ' ') right++
        while (left.inRange(0, context.line.length) && context.line[left] != ' ') left--
        val token = context.line.substring(Math.max(left, 0), right).trim()
        val value = Ref(0)
        if (!token.tryParseInt(value)) return
        val line = _parser.firstMatch(context.line.trim())
        if (line == null) return
        if (value.value < 0x4000) {
            val flags = Flags.findFlagUsages(model, _parser, value.value)
            requestShowSearchResult(this, flags.map { f -> CodeBodyRequestShowSearchResultTuple(f.item1, f.item2) }.toMutableSet())
        } else {
            val variables = Flags.findVarUsages(model, _parser, value.value)
            requestShowSearchResult(this, variables.map { v -> CodeBodyRequestShowSearchResultTuple(v.item1, v.item2) }.toMutableSet())
        }
    }
    val canGotoAddress: Boolean
        get() { /*@DONE CodeBody.CanGotoAddress.get cs:189-200*/
            if (caretPosition < 0 || model.spartanMode) return false
            val context = splitCurrentLine()
            if (context.contentBoundaryCount != 0) return false
            var left = context.index
            var right = context.index
            while (left.inRange(1, context.line.length) && context.line[left] != ' ') left--
            while (right < context.line.length && context.line[right] != ' ') right++
            var token = context.line.substring(left, right).trim()
            if (token.startsWith("<")) token = token.substring(1)
            if (token.endsWith(">")) token = token.substring(0, token.length - 1)
            return token.tryParseHex(Ref(0)) || model.getAddressFromAnchor(ModelDelta(), -1, token) != Pointer.null_
        }
    fun gotoAddress() { /*@DONE CodeBody.GotoAddress/1 cs:203-220*/
        if (caretPosition < 0) return
        val context = splitCurrentLine()
        if (context.contentBoundaryCount != 0) return
        var left = context.index
        var right = context.index
        while (left.inRange(1, context.line.length) && context.line[left] != ' ') left--
        while (right < context.line.length && context.line[right] != ' ') right++
        var token = context.line.substring(left, right).trim()
        if (token.startsWith("<")) token = token.substring(1)
        if (token.endsWith(">")) token = token.substring(0, token.length - 1)
        val result = Ref(0)
        if (token.tryParseHex(result)) {
            requestShowSearchResult(this, linkedSetOf(CodeBodyRequestShowSearchResultTuple(result.value, result.value)))
            return
        }
        val address = model.getAddressFromAnchor(ModelDelta(), -1, token)
        if (address == Pointer.null_) return
        requestShowSearchResult(this, linkedSetOf(CodeBodyRequestShowSearchResultTuple(address, address)))
    }
    private fun tryGetSourceInfo(table: Ref<String?>, parsedToken: Ref<String?>): Boolean { /*@DONE CodeBody.TryGetSourceInfo/1 cs:222-257*/
        table.value = null
        parsedToken.value = null
        if (model.spartanMode) return false
        val context = splitCurrentLine()
        val tokens = ScriptLine.tokenize(context.line)
        var token = 0
        var caret = 0
        while (caret < context.index) {
            if (context.line[caret] == ' ') {
                caret++
                continue
            }
            if (token >= tokens.size) return false
            caret += tokens[token].length
            if (caret >= context.index) break
            token++
        }
        if (token == 0) return false
        val line = _parser.firstMatch(context.line.trim()) ?: return false
        if (token >= tokens.size) return false
        parsedToken.value = tokens[token]
        var args: List<IScriptArg> = line.args
        if (line is MacroScriptLine) {
            args = line.shortFormArgs ?: line.args
            token -= 1
        } else if (line is ScriptLine) {
            token -= line.lineCode.count
        }
        if (args.size <= token || token < 0) return false
        table.value = args[token].enumTableName
        val tableName = table.value ?: return false
        val tableRun = model.getTable(tableName)
        if (tableRun == null) return false
        return true
    }
    val canGotoSource: Boolean
        get() { /*@DONE CodeBody.CanGotoSource.get cs:259-259*/
            return tryGetSourceInfo(Ref<String?>(null), Ref<String?>(null))
        }
    fun gotoSource() { /*@DONE CodeBody.GotoSource/1 cs:261-267*/
        val tableName = Ref<String?>(null)
        val token = Ref<String?>(null)
        if (!tryGetSourceInfo(tableName, token)) return
        val table = tableName.value ?: return
        val parsed = token.value ?: return
        val index = Ref(0)
        if (!ArrayRunEnumSegment.tryParse(table, model, parsed, index)) return
        val run = model.getTable(table) ?: return
        val destination = run.start + run.elementLength * index.value
        requestShowSearchResult(this, linkedSetOf(CodeBodyRequestShowSearchResultTuple(destination, destination)))
    }
    private var _findUsesCommand: StubCommand? = null
    private var _gotoSourceCommand: StubCommand? = null
    private var _gotoAddressCommand: StubCommand? = null
    val findUsesCommand: ICommand
        get() { /*@DONE CodeBody.FindUsesCommand.get cs:272-272*/
            return _findUsesCommand ?: stubCommand({ findUses() }, { canFindUses }).also { _findUsesCommand = it }
        }
    val gotoSourceCommand: ICommand
        get() { /*@DONE CodeBody.GotoSourceCommand.get cs:273-273*/
            return _gotoSourceCommand ?: stubCommand({ gotoSource() }, { canGotoSource }).also { _gotoSourceCommand = it }
        }
    val gotoAddressCommand: ICommand
        get() { /*@DONE CodeBody.GotoAddressCommand.get cs:274-274*/
            return _gotoAddressCommand ?: stubCommand({ gotoAddress() }, { canGotoAddress }).also { _gotoAddressCommand = it }
        }
    fun tryInsertAuto(): Boolean { /*@DONE CodeBody.TryInsertAuto/1 cs:280-307*/
        if (model.spartanMode) return false
        val context = splitCurrentLine()
        if (context.contentBoundaryCount != 0) return false
        val tokens = ScriptLine.tokenize(context.line)
        if (context.line.length > context.index + 1) return false
        if (!context.line.endsWith(" ")) return false
        val line = _parser.firstMatch(context.line.trim()) ?: return false
        var args: List<IScriptArg> = line.args
        var token = tokens.size
        if (line is MacroScriptLine) {
            args = line.shortFormArgs ?: line.args
            token -= 1
        } else if (line is ScriptLine) {
            token -= line.lineCode.count
        }
        if (token < 0 || token >= args.size) return false
        if (args[token].type == ArgType.Pointer && args[token].pointerType.isAny(ExpectedPointerType.Mart, ExpectedPointerType.SpriteTemplate, ExpectedPointerType.Text, ExpectedPointerType.Movement, ExpectedPointerType.Decor)) {
            val before = content.substring(0, caretPosition + 1)
            val after = content.substring(caretPosition + 1)
            val guard = scope(ignoreEditorContentUpdates, true, { ignoreEditorContentUpdates = it }) { old -> ignoreEditorContentUpdates = old }
            try {
                editor.content = before + "<auto>" + after
                return true
            } finally {
                guard.dispose()
            }
        }
        return false
    }
    fun tryCompleteCommandToken(): Boolean { /*@DONE CodeBody.TryCompleteCommandToken/1 cs:313-335*/
        if (model.spartanMode) return false
        val context = splitCurrentLine()
        if (context.contentBoundaryCount != 0) return false
        val tokens = ScriptLine.tokenize(context.line)
        if (tokens.size != 1) return false
        if (context.line.length > context.index + 1) return false
        if (!context.line.endsWith(" ")) return false
        val line = _parser.firstMatch(context.line.trim())
        if (line != null) return false

        var candidates: List<IScriptLine> = _parser.partialMatches(tokens[0])
        if (candidates.size == 0) return false
        candidates = ScriptParser.sortOptions(candidates, tokens[0]) { c -> c.lineCommand }.toList()

        val before = content.substring(0, caretPosition - tokens[0].length)
        val after = content.substring(caretPosition)
        val guard = scope(ignoreEditorContentUpdates, true, { ignoreEditorContentUpdates = it }) { old -> ignoreEditorContentUpdates = old }
        try {
            editor.content = before + candidates[0].lineCommand + after
            editor.caretIndex += candidates[0].lineCommand.length - tokens[0].length + 1
            return true
        } finally {
            guard.dispose()
        }
    }
    var caretPosition: Int
        get() { /*@DONE CodeBody.CaretPosition.get cs:340-340*/
            return editor.caretIndex
        }
        set(value) { /*@DONE CodeBody.CaretPosition.set cs:341-352*/
            if (editor.caretIndex == value) return
            editor.caretIndex = value
            val context = splitCurrentLine()

            helpSourceChanged(this, context)

            notifyPropertiesChanged("canInsertFlag", "canInsertVar", "canFindUses", "canGotoSource", "canGotoAddress")
            _findUsesCommand?.raiseCanExecuteChanged()
            _gotoSourceCommand?.raiseCanExecuteChanged()
        }
    private var _selectedText: String = ""
    var selectedText: String
        get() { /*@DONE CodeBody.SelectedText.get cs:357-357*/
            return _selectedText
        }
        set(value) { /*@DONE CodeBody.SelectedText.set cs:358-362*/
            set(_selectedText, value, "selectedText", { _selectedText = it }) { _ ->
                if (!(_selectedText.isEmpty() || _selectedText.contains("\n"))) {
                    val context = splitCurrentLine()
                    helpSourceChanged(this, context.copy(index = context.index + _selectedText.trimEnd().length, isSelection = true))
                }
            }
        }
    fun splitCurrentLine(): HelpContext { /*@DONE CodeBody.SplitCurrentLine/1 cs:365-378*/
        var value = Math.min(caretPosition, content.length)
        val lines = content.split('\r', '\n')
        var contentBoundaryCount = 0
        var contentBoundaryIndex = 0
        var i = 0
        while (value > lines[i].length) {
            if (lines[i].trim() == "{") { contentBoundaryCount += 1; contentBoundaryIndex += 1 }
            if (lines[i].trim() == "}") contentBoundaryCount -= 1
            value -= lines[i].length + 1
            i++
        }
        return HelpContext(lines[i], value, contentBoundaryCount, contentBoundaryIndex - 1)
    }
    private fun splitLine(lineIndex: Int, characterIndex: Int): HelpContext? { /*@DONE CodeBody.SplitLine/1 cs:380-392*/
        val lines = content.split('\n')
        if (!lineIndex.inRange(0, lines.size)) return null
        var contentBoundaryCount = 0
        var contentBoundaryIndex = 0
        for (i in 0 until lineIndex) {
            if (lines[i].trim() == "{") { contentBoundaryCount += 1; contentBoundaryIndex += 1 }
            if (lines[i].trim() == "}") contentBoundaryCount -= 1
        }
        val cleanLine = lines[lineIndex].split('\r').filter { part -> part.isNotEmpty() }
        if (cleanLine.size == 0) return null
        return HelpContext(cleanLine[0], characterIndex, contentBoundaryCount, contentBoundaryIndex - 1)
    }
    var editor: TextEditorViewModel = /*@INITDONE CodeBody.Editor cs:394-394*/ TextEditorViewModel().also { it.preFormatter = CodeTextFormatter() } /*@ENDINIT*/
        private set
    var streamTypes: List<ExpectedPointerType>? = null
    private var ignoreEditorContentUpdates: Boolean = false
    var content: String
        get() { /*@DONE CodeBody.Content.get cs:400-400*/
            return editor.content
        }
        set(value) { /*@DONE CodeBody.Content.set cs:401-412*/
            if (editor.content != value) {
                val guard = scope(ignoreEditorContentUpdates, true, { ignoreEditorContentUpdates = it }) { old -> ignoreEditorContentUpdates = old }
                try {
                    clearErrors()
                    val previousValue = editor.content
                    editor.content = value
                    notifyPropertyChanged("content")
                    contentChanged(this, ExtendedPropertyChangedEventArgs(previousValue, "content"))
                    evaluateTextLength()
                } finally {
                    guard.dispose()
                }
            }
        }
    private var _helpContent: String = ""
    var helpContent: String
        get() { /*@DONE CodeBody.HelpContent.get cs:416-416*/
            return _helpContent
        }
        set(value) { /*@DONE CodeBody.HelpContent.set cs:416-416*/
            tryUpdate(_helpContent, value, "helpContent", { _helpContent = it })
        }
    constructor(model: IDataModel, parser: ScriptParser, investigator: IDataInvestigator?) { /*@DONE CodeBody.<init>/1 cs:418-432*/
        this.model = model
        this._parser = parser
        this.investigator = investigator
        this.gameHash = model.getShortGameCode()
        editor.bind("content") { _, e ->
            if (!ignoreEditorContentUpdates) {
                notifyPropertyChanged("content")
                contentChanged(this, (e as? ExtendedPropertyChangedEventArgs<String>) ?: ExtendedPropertyChangedEventArgs("", "content"))
                evaluateTextLength()
            }
        }
        editor.bind("caretIndex") { _, _ ->
            notifyPropertyChanged("caretPosition")
        }
    }
    fun saveCaret(lengthDelta: Int) { /*@DONE CodeBody.SaveCaret/1 cs:434-434*/
        editor.caretIndex += lengthDelta
    }
    fun clearErrors() { /*@DONE CodeBody.ClearErrors/1 cs:436-440*/
        hasError = false
        errorText = ""
        editor.errorLocations.clear()
    }
    fun evaluateTextLength() { /*@DONE CodeBody.EvaluateTextLength/1 cs:442-450*/
        if (model.spartanMode) return
        for (streamLine in lookForStreamLines()) {
            if (streamLine.type != ExpectedPointerType.Text) continue // 35*6
            for (error in model.textConverter.getOverflow(streamLine.text ?: "", maxEventTextWidth)) {
                editor.errorLocations.add(error.copy(line = error.line + streamLine.lineNumber))
            }
        }
    }
    fun watchForCompileErrors(sender: Any?, e: ScriptErrorInfo) { /*@DONE CodeBody.WatchForCompileErrors/1 cs:452-456*/
        hasError = true
        errorText = e.message
        editor.errorLocations.add(e.segment)
    }
    fun lookForStreamLines(): MutableList<ScriptLineFormatInfo> { /*@DONE CodeBody.LookForStreamLines/1 cs:458-481*/
        val results = ArrayList<ScriptLineFormatInfo>()
        val queue = ArrayList<ExpectedPointerType>()
        val lines = content.splitLines()
        var i = 0
        while (i < lines.size) {
            if (lines[i].trim() == "{") {
                val type = if (queue.size == 0) ExpectedPointerType.Unknown else queue.removeAt(0)
                i += 1
                while (i < lines.size && lines[i].trim() != "}") {
                    results.add(ScriptLineFormatInfo(i, type, lines[i]))
                    i += 1
                    if (lines.size <= i) break
                }
                i++
                continue
            }
            val command = _parser.firstMatch(lines[i])
            if (command == null) {
                i++
                continue
            }
            queue.clear()
            for (arg in command.args) {
                if (arg.type == ArgType.Pointer && !arg.pointerType.isAny(ExpectedPointerType.Script, ExpectedPointerType.Unknown)) queue.add(arg.pointerType)
            }
            i++
        }
        return results
    }
    fun getTokenComplete(line: String, lineIndex: Int, characterIndex: Int): List<AutocompleteItem>? { /*@DONE CodeBody.GetTokenComplete/1 cs:483-557*/
        if (characterIndex < line.length && line[characterIndex] != ' ') return null
        val results = ArrayList<AutocompleteItem>()
        val context = splitLine(lineIndex, characterIndex) ?: return null
        var before = line.substring(0, characterIndex)
        var after = line.substring(characterIndex)
        var tokens = ScriptLine.tokenize(before.trim())

        if (tokens.size == 0) return null

        // if they're 'working on' a new token, add a blank token to the end
        if (before.endsWith(" ")) tokens = tokens + arrayOf("")

        if (context.contentBoundaryCount > 0) {
            // stream content
            val knownStreamTypes = streamTypes
            if (knownStreamTypes == null || !context.contentBoundaryIndex.inRange(0, knownStreamTypes.size)) return null
            val expectedType = knownStreamTypes[context.contentBoundaryIndex]
            if (expectedType == ExpectedPointerType.Mart) {
                val options = _parser.readOptions(model, HardcodeTablesModel.itemsTableName, context.line) ?: ArrayList<String>()
                results.addAll(options.map { op -> AutocompleteItem(op, op) })
            } else if (expectedType == ExpectedPointerType.Movement) {
                val options = _parser.readOptions(model, "movementtypes", context.line) ?: ArrayList<String>()
                results.addAll(options.map { op -> AutocompleteItem(op, op) })
            } else {
                return null
            }
        } else if (tokens.size == 1) {
            // script command
            var candidates: List<IScriptLine> = _parser.partialMatches(tokens[0]).filter { l -> l.matchesGame(gameHash) }
            candidates = candidates.filter { l -> l.lineCommand.matchesPartial(tokens[0]) }
            if (!context.isSelection) {
                for (line1 in candidates) {
                    if (line1.lineCommand == tokens[0] && line1.countShowArgs() == 0) return null // perfect match with no args
                }
            }
            candidates = ScriptParser.sortOptions(candidates, tokens[0]) { c -> c.lineCommand }.toList()
            val length = before.length - tokens[0].length
            if (length >= 0) {
                val beforeStem = before.substring(0, length)
                val afterOriginal = after
                results.addAll(candidates.map { op ->
                    var afterText = afterOriginal
                    if (afterText.isEmpty() && op.args.size + op.lineCode.count > 1) afterText = " " // insert whitespace after
                    AutocompleteItem(op.usage, beforeStem + op.lineCommand + afterText)
                })
            }
        } else {
            // script args
            var candidates: List<IScriptLine> = _parser.partialMatches(tokens[0]).filter { l -> l.matchesGame(gameHash) }
            candidates = candidates.filter { l -> l.lineCommand.equals(tokens[0], ignoreCase = true) }
            var checkToken = 1
            while (candidates.size > 1 && checkToken < tokens.size) {
                val codeValue = Ref(0)
                if (!tokens[checkToken].tryParseHex(codeValue)) break
                val currentCheck = checkToken
                candidates = candidates.filter { l -> l.lineCode.count <= currentCheck || l.lineCode[currentCheck] == codeValue.value }
                checkToken++
            }
            val syntax = candidates.firstOrNull()
            if (syntax != null) {
                var args: List<IScriptArg> = syntax.args.filter { a -> a is ScriptArg }
                if (syntax is MacroScriptLine) args = syntax.shortFormArgs ?: args
                var skipCount = syntax.lineCode.count
                if (skipCount == 0) skipCount = 1 // macros
                if (args.size + skipCount >= tokens.size && tokens.size >= skipCount + 1) {
                    val arg = args[tokens.size - 1 - skipCount]
                    val token = tokens[tokens.size - 1]
                    val options = _parser.readOptions(model, arg.enumTableName, token) ?: return null
                    if (args.size == tokens.size - skipCount && options.any { option -> option == token }) return null // perfect match on last token
                    val beforeStem = before.substring(0, before.length - token.length)
                    var afterText = after
                    if (afterText.isEmpty() && tokens.size - skipCount < args.size) afterText = " " // insert whitespace after
                    val finalAfter = afterText
                    results.addAll(options.map { op -> AutocompleteItem(op, beforeStem + op.split('#').first().trim() + finalAfter) })
                }
            }
        }
        return results
    }
    companion object {
        const val maxEventTextWidth: Int = 214
        /*@END CodeBody.Companion*/
    }
    /*@END CodeBody*/
}

data class ScriptLineFormatInfo(val lineNumber: Int, val type: ExpectedPointerType, val text: String?) { // cs:560-560
    /*@END ScriptLineFormatInfo*/
}

data class CodeBodyRequestShowSearchResultTuple(val item1: Int, val item2: Int)
