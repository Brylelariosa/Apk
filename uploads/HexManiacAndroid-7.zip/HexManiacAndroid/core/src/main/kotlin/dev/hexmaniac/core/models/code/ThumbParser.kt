// Port of Models/Code/ThumbParser.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.code

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class ThumbParser { // cs:12-649
    private val conditionalCodes: MutableList<ConditionCode> = /*@INITAUTO ThumbParser.conditionalCodes cs:13-13*/ ArrayList() /*@ENDINIT*/
    private val instructionTemplates: MutableList<IInstruction> = /*@INITAUTO ThumbParser.instructionTemplates cs:14-14*/ ArrayList() /*@ENDINIT*/
    constructor(singletons: Singletons) { /*@DONE ThumbParser.<init>/1 cs:15-25*/
        conditionalCodes.addAll(singletons.thumbConditionalCodes)
        instructionTemplates.addAll(singletons.thumbInstructionTemplates)
        instructionTemplates.addAll(listOf<IInstruction>(
            ByteInstruction(),
            HalfWordInstruction(),
            WordInstruction(),
            AlignInstruction(),
            SkipInstruction(),
        ))
    }
    private val parseResult: StringBuilder = /*@INITAUTO ThumbParser.parseResult cs:27-27*/ StringBuilder() /*@ENDINIT*/
    private val parsedLines: MutableList<String> = /*@INITAUTO ThumbParser.parsedLines cs:28-28*/ ArrayList() /*@ENDINIT*/
    fun parse(data: IDataModel, start: Int, length: Int): String { /*@DONE ThumbParser.Parse/1 cs:29-121*/
        var start = start
        var length = length
        if (data.count < start + length) return ""
        parseResult.clear()
        parsedLines.clear()
        val initialStart = start
        val interestingAddresses = HashSet<Int>()
        interestingAddresses.add(start)
        val wordLocations = HashSet<Int>()
        val sectionEndLocations = HashSet<Int>()

        // part 1: convert all the instructions and find all interesting addresses
        while (length >= 2) {
            val template = instructionTemplates.firstOrNull { instruction -> instruction.matches(data, start) }
            if (template == null) {
                parsedLines.add(data.readMultiByteValue(start, 2).toHex(4))
                length -= 2
                start += 2
            } else {
                var line = template.disassemble(data, start, conditionalCodes)
                val tokens = line.lowercase().split(' ').filter { token -> token.isNotEmpty() }
                if (line.contains("<") && line.contains(">")) {
                    val content = line.split('<')[1].split('>')[0]
                    var address = data.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, content)
                    var found = address != Pointer.null_
                    if (!found) {
                        val parsed = Ref(0)
                        if (content.tryParseHex(parsed)) {
                            address = parsed.value
                            found = true
                        }
                    }
                    if (found) {
                        interestingAddresses.add(address)
                        if (tokens.size > 1 && tokens[0] == "ldr" && tokens[1].startsWith("r")) {
                            wordLocations.add(address)
                            val value = if (address >= 0 && address + 4 <= data.count) data.readValue(address) else 0
                            var valueText = value.toString()
                            val anchor = data.getAnchorFromAddress(-1, value - BaseModel.pointerOffset)
                            if (anchor.isNotEmpty()) {
                                valueText = "<" + anchor + ">"
                            } else if (value > 20100 || value.inRange(0x4000, 20000)) {
                                valueText = "0x" + value.toHex(8)
                            } else if (value < -10000) {
                                valueText = "0x" + value.toHex(8)
                            }
                            val gap = " ".repeat((30 - line.length).limitToRange(0, 30))
                            line += gap + "@ = " + valueText
                        }
                    }
                }
                parsedLines.addAll(line.split("\n"))
                if (tokens.size > 0 && (tokens[0] == "b" || tokens[0] == "bx")) {
                    sectionEndLocations.add(start)
                }
                if (tokens.size > 1 && tokens[0] == "pop" && tokens.last().endsWith("pc}")) {
                    sectionEndLocations.add(start)
                }
                if (tokens.size > 1 && tokens[0] == "push" && tokens.last().endsWith("lr}")) {
                    interestingAddresses.add(start) // push lr always signifies the start of a function. That makes it worth noting.
                }
                length -= template.byteLength
                start += template.byteLength
            }
        }

        // part 2: insert all interesting addresses
        var address = minOf((interestingAddresses + sectionEndLocations).max(), initialStart + parsedLines.size * 2 - 2)
        while (address >= initialStart) {
            val index = (address - initialStart) / 2
            if (index >= 0 && index < parsedLines.size) {
                // check if it's a word
                if (wordLocations.contains(address)) {
                    val wordValue = if (address >= 0 && address + 4 <= data.count) data.readValue(address) else 0
                    parsedLines[index] = "    .word "
                    val anchor = data.getAnchorFromAddress(-1, wordValue - BaseModel.pointerOffset)
                    if (anchor.isEmpty()) {
                        parsedLines[index] = parsedLines[index] + "0x" + wordValue.toHex(8)
                    } else {
                        parsedLines[index] = parsedLines[index] + "<" + anchor + ">"
                    }
                    if (index < parsedLines.size - 1) parsedLines.removeAt(index + 1)
                    // remove anything in this area after the word until the next address of interest (denoted by starting with no spaces)
                    while (index < parsedLines.size - 1 && parsedLines[index + 1].startsWith(" ")) parsedLines.removeAt(index + 1)
                }

                // check if it's the end of a section
                if (sectionEndLocations.contains(address)) {
                    // remove any code in this area until the next address of interest (denoted by starting with no spaces)
                    while (index < parsedLines.size - 1 && parsedLines[index + 1].startsWith(" ")) parsedLines.removeAt(index + 1)
                }

                // check if it's a blank line
                if (parsedLines[index].isEmpty()) parsedLines.removeAt(index)

                if (interestingAddresses.contains(address)) {
                    parsedLines.add(index, address.toHex(6) + ":")
                }
            }
            address -= 2
        }

        // part 3: aggregate / return
        for (line in parsedLines) parseResult.appendLine(line)
        return parseResult.toString()
    }
    fun canRepoint(data: IDataModel, start: Int, length: Int): Int { /*@DONE ThumbParser.CanRepoint/1 cs:126-150*/
        if (length != 8) return -1
        if (start % 4 != 0) return -1
        val content = parse(data, start, length).trim().splitLines().drop(1) // skip the header line
        if (content.size != 4) return -1

        // can't repoint if the included instructions care about other nearby addresses (load-pc and branch)
        val branchTokens = "bl b beq bne bhs blo bcs bcc bmi bpl bvs bvc bhi bls bge blt bgt ble bal bnv".split(' ')
        if (content.any { line -> branchTokens.any { token -> line.contains(" " + token + " ") } }) return -1
        if (content.any { line -> line.contains(" ldr ") && line.contains(" [pc, ") }) return -1

        // can't repoint if some instructions were not decoded
        if (content.any { line -> line.length == 4 && line.all { c -> ViewPort.allHexCharacters.contains(c) } }) return -1

        // verify that content contains a `mov` instruction
        for (i in 0 until 4) {
            if (content[i].contains("mov ") && content[i].contains(", #")) {
                // verify that the register isn't used by an earlier instruction
                val register = content[i].trim().substring(4).split(",")[0].trim()
                if (content.take(i).any { line -> line.contains(register) }) continue
                val r = Ref(0)
                if (register.length > 1 && tryParseInt(register.substring(1), r)) return r.value
            }
        }

        return -1
    }
    fun repoint(token: ModelDelta, model: IDataModel, start: Int, register: Int): Int { /*@DONE ThumbParser.Repoint/1 cs:152-170*/
        val scratchRegister = "r" + register
        val existingCode = model.rawData.copyOfRange(start, start + 8)
        val newAddress = model.findFreeSpace(0, 20)

        // TODO add optional push if there's no scratch register
        compile(token, model, start, "ldr " + scratchRegister + ", =<" + (newAddress + 1).toHex(6) + ">", "bx " + scratchRegister)

        // TODO add optional pop version if there's no scratch register
        compile(token, model, newAddress, "ldr " + scratchRegister + ", [pc, <" + (newAddress + 0x10).toHex(6) + ">]", "mov lr, " + scratchRegister)

        token.changeData(model, newAddress + 4, existingCode.asByteList())
        compile(token, model, newAddress + 0xC, "bx lr", "nop")
        model.writePointer(token, newAddress + 0x10, start + 9)
        model.observeRunWritten(token, PointerRun(newAddress + 0x10))

        return newAddress
    }
    fun compile(token: ModelDelta, model: IDataModel, start: Int, vararg lines: String): ByteList { /*@DONE ThumbParser.Compile/1 cs:177-192*/
        val initialAnchor = model.getAnchorFromAddress(-1, start)
        val newRuns = Ref<List<IFormattedRun>?>(null)
        val result = compile(model, start, newRuns, *lines)

        // we want to clear the format since pointers may have moved
        // but be careful not to clear any pointers to this routine+1, because of the way bx instructions work
        model.clearFormat(token, start, 1)
        if (result.count > 1) model.clearFormat(token, start + 1, result.count - 1)
        // but we want to keep an initial anchor pointing to this code block if there was one.
        if (initialAnchor.isNotEmpty()) model.observeAnchorWritten(token, initialAnchor, NoInfoRun(start))

        // update the data, and the format
        for (i in 0 until result.count) token.changeData(model, start + i, result[i])
        for (run in (newRuns.value ?: emptyList<IFormattedRun>())) model.observeRunWritten(token, run)
        return result
    }
    fun compile(model: IDataModel, start: Int, newRuns: Ref<List<IFormattedRun>?>, vararg lines: String): ByteList { /*@DONE ThumbParser.Compile/2 cs:197-327*/
        val result = ArrayList<Int>()
        val addedRuns = ArrayList<IFormattedRun>()
        // labels are allowed to be on the same line as code, and code can end with comments.
        // remove excess whitespace/comments and splitting labels from code
        var lines: Array<String> = arrayOf(*lines)
        removeMultilineComments(lines)
        handleEquDirectives(lines)
        lines = macroPass(LabelLibrary(model, null), *lines)     // replace if statements
        lines = lines.flatMap { rawLine ->
            val line = rawLine.lowercase().split('@')[0].trim()
            if (line == "") {
                emptyList<String>()
            } else {
                val parts = line.split(":")
                if (parts.size > 1 && parts[1].length > 0) {
                    listOf(parts[0].trim() + ":", parts[1].trim())
                } else {
                    listOf(line)
                }
            }
        }.toTypedArray()

        // first pass: look for labels
        val skip = SkipInstruction()
        val labels = LinkedHashMap<String, Int>()
        val inlineWords = ArrayDeque<DeferredLoadRegisterToken>()
        var position = start
        for (line in lines) {
            if (line.endsWith(":")) {
                val label = line.substring(0, line.length - 1)
                if (!labels.containsKey(label)) labels[label] = position
            } else {
                position += 2
                if (line.startsWith("bl ")) position += 2   // branch-links are double-wide
                if (line.startsWith(".word")) position += 2 // .word elements are double-wide
                if (line.startsWith(".byte")) position -= 1
                else if (position % 2 != 0) position += 1   // only .bytes are allowed to start on odd offsets
                if (line.startsWith(".word") && position % 4 != 0) {
                    // alignment is off! words have to be 4-byte aligned.
                    position += 2
                    val labelsToFix = labels.keys.filter { key -> labels[key] == position - 6 }
                    for (label in labelsToFix) labels[label] = position - 4
                }
                if (line.startsWith("ldr ") && line.contains("=")) {
                    // We only care about the count during this step. But doing a full compile will keep us from double-counting duplicate words.
                    DeferredLoadRegisterToken.tryCompile(position - 2, line, LabelLibrary(model, labels), inlineWords)
                }
                if (DeferredLoadRegisterToken.isEndOfSection(line) && inlineWords.size > 0) {
                    if (position % 4 != 0) position += 2
                    position += 4 * inlineWords.size
                    inlineWords.clear()
                }
                if (skip.tryAssemble(line, emptyList<ConditionCode>(), 0, LabelLibrary(model, labels), Ref<ByteArray?>(null))) {
                    position -= 2 // not an actual instruction
                }
            }
        }
        // any words that haven't been added yet get added to the end
        if (inlineWords.size > 0) {
            if (position % 4 != 0) position += 2
            position += 4 * inlineWords.size
            inlineWords.clear()
        }

        val labelLibrary = LabelLibrary(model, labels)
        val longBranchTokens = LinkedHashMap<Int, DeferredUniversalBranchLinkToken>()

        for (rawLine in lines) {
            if (rawLine.endsWith(":")) continue   // don't compile labels
            val line = patchInstruction(rawLine)
            var foundMatch = false
            for (instruction in instructionTemplates) {
                val codeRef = Ref<ByteArray?>(null)
                if (!instruction.tryAssemble(line, conditionalCodes, start + result.size, labelLibrary, codeRef)) continue
                val code = codeRef.value ?: ByteArray(0)
                if (line.startsWith("bl ")) {
                    val pointerContent = Ref(line.substring(3).trim())
                    val address = Ref(0)
                    if (Instruction.readPointer(pointerContent, address, labelLibrary)) {
                        if (!DeferredUniversalBranchLinkToken.canBranch(start + result.size, address.value)) {
                            // TODO we can add to an existing deferral token if the address is the same, rather than making a new one
                            address.value -= Pointer.null_
                            var ubl = longBranchTokens[address.value]
                            if (ubl == null) {
                                ubl = DeferredUniversalBranchLinkToken(address.value)
                                longBranchTokens[address.value] = ubl
                            }
                            ubl.instructionAddresses.add(start + result.size)
                        }
                    }
                }
                if (instruction.requiresAlignment && (result.size + start) % 4 != 0) result.addAll(nop)
                if (instruction !is ByteInstruction && result.size % 2 != 0) result.add(0)
                for (b in code) result.add(b.toInt() and 0xFF)
                foundMatch = true
                if (instruction is WordInstruction) {
                    if (code.size > 3 && ((code[3].toInt() and 0xFF) == 0x08 || (code[3].toInt() and 0xFF) == 0x09)) {
                        addedRuns.add(PointerRun(start + result.size - 4))
                    }
                }
                break
            }
            if (!foundMatch) {
                if (DeferredLoadRegisterToken.tryCompile(result.size, line, labelLibrary, inlineWords)) {
                    result.addAll(nop) // we'll come back to this once we know the offset
                } else {
                    result.addAll(nop)
                }
            } else if (DeferredLoadRegisterToken.isEndOfSection(line) && inlineWords.size > 0) {
                if ((result.size + start) % 4 != 0) result.addAll(nop)
                while (inlineWords.size > 0) {
                    val token = inlineWords.removeFirst()
                    result.addAll(listOf(0, 0, 0, 0)) // add space for the new word
                    token.write(start, result, result.size - 4)
                    val highByte = token.wordToLoad shr 24
                    if (highByte == 0x08 || highByte == 0x09) addedRuns.add(PointerRun(start + result.size - 4))
                }
            }
        }
        // any words that haven't been added yet get added to the end
        if (inlineWords.size > 0) {
            if (position % 4 != 0) result.addAll(nop)
            while (inlineWords.size > 0) {
                val token = inlineWords.removeFirst()
                result.addAll(listOf(0, 0, 0, 0)) // add space for the new word
                token.write(start, result, result.size - 4)
            }
        }

        for (token in longBranchTokens.values) {
            while ((start + result.size) % 4 != 0) result.add(0)
            token.write(start + result.size, result)
        }

        newRuns.value = addedRuns
        return result.toByteArrayU().asByteList()
    }
    private fun patchInstruction(line: String): String { /*@DONE ThumbParser.PatchInstruction/1 cs:612-648*/
        var line = line
        // patch `add sp, #-4` to `sub sp, #4`
        if (line.startsWith("add ") && line.contains(" sp, ") && line.contains(" #-")) {
            line = line.replace("add ", "sub ")
            line = line.replace(" #-", " #")
        } else if (line.startsWith("add ") && line.contains(" sp,#-")) {
            line = line.replace("add ", "sub ")
            line = line.replace(" sp,#-", " sp,#")
        }

        // patch `push {lr,list}` or `push {list,lr}` to `push lr, {list}`
        if (line.startsWith("push ") && line.contains("{lr,")) {
            line = line.replace("push ", "push lr, ")
            line = line.replace("{lr,", "{")
        } else if (line.startsWith("push ") && line.contains(",lr}")) {
            line = line.replace("push ", "push lr, ")
            line = line.replace(",lr}", "}")
        }

        // patch `add r0, r1` to `add r0, r0, r1` (+= instruction is only allowed if one of the registers is high)
        val tokens = line.replace(',', ' ').split(' ').filter { token -> token.isNotEmpty() }
        if (tokens.isEmpty()) return line
        if (tokens[0] == "add" && tokens.size == 3 && tokens.drop(1).all { token -> token.startsWith("r") }) {
            val r = tokens.drop(1).map { token ->
                val index = Ref(0)
                if (tryParseInt(token.substring(1), index)) index.value else -1
            }
            if (r.all { i -> i >= 0 && i < 8 }) {
                // we need to patch this one
                line = "add r" + r[0] + ", r" + r[0] + ", r" + r[1]
            }
        } else if (tokens[0] == "sub" && tokens.size == 3 && tokens.drop(1).all { token -> token.startsWith("r") }) {
            val r = tokens.drop(1).map { token ->
                val index = Ref(0)
                if (token.substring(1).tryParseInt(index)) index.value else -1
            }
            if (r.all { i -> i.inRange(0, 8) }) {
                // we need to patch this one
                line = "sub r" + r[0] + ", r" + r[0] + ", r" + r[1]
            }
        }

        return line
    }
    companion object {
        private val nop: Collection<Int> = /*@INITDONE ThumbParser.nop cs:172-172*/ listOf(0, 0) /*@ENDINIT*/
        fun macroPass(labels: LabelLibrary, vararg lines: String): Array<String> { /*@DONE ThumbParser.MacroPass/1 cs:329-471*/
            val ifStack = ArrayDeque<MutableList<Int>>()
            val results = ArrayList<String>()
            for (i in 0 until lines.size) {
                val line = lines[i].split('@')[0].trim().replace(";", "").lowercase()
                if (line.startsWith("if ") && line.endsWith("{")) {
                    val tokens = line.substring(3, line.length - 1).split(' ').filter { token -> token.isNotEmpty() }
                    val branch = if (tokens.size == 3) instructionForComparator(tokens[1]) else null
                    if (tokens.size == 3 && branch != null) {
                        ifStack.addLast(arrayListOf(i + 1))
                        results.add("cmp " + tokens[0] + " " + tokens[2])
                        results.add(branch + " else" + (i + 1))
                    } else {
                        results.add(lines[i])
                    }
                } else if (line == "} else {" && ifStack.size > 0 && ifStack.last().any { scope -> scope > 0 }) {
                    val match = ifStack.removeLast()
                    val scope = match.first { p -> p > 0 }
                    results.add("b close" + scope)
                    results.add("else" + scope + ":")
                    match.remove(scope)
                    match.add(-scope)
                    ifStack.addLast(match)
                } else if (line.startsWith("} else if ") && line.endsWith("{") && ifStack.size > 0 && ifStack.last().any { scope -> scope > 0 }) {
                    val tokens = line.substring(10, line.length - 1).split(' ').filter { token -> token.isNotEmpty() }
                    val branch = if (tokens.size == 3) instructionForComparator(tokens[1]) else null
                    if (tokens.size == 3 && branch != null) {
                        val match = ifStack.removeLast()
                        val scope = match.first { p -> p > 0 }
                        results.add("b close" + scope)
                        results.add("else" + scope + ":")
                        match.remove(scope)
                        match.add(-scope)
                        match.add(i + 1)
                        ifStack.addLast(match)
                        results.add("cmp " + tokens[0] + ", " + tokens[2])
                        results.add(branch + " else" + (i + 1))
                    } else {
                        results.add(lines[i])
                    }
                } else if (line == "}" && ifStack.size > 0) {
                    val match = ifStack.removeLast()
                    val scope = match.firstOrNull { p -> p > 0 } ?: 0
                    if (scope > 0) {
                        results.add("else" + scope + ":")
                        match.remove(scope)
                    }
                    for (m in match) results.add("close" + (-m) + ":")
                    // } else if (line.StartsWith("r") && line.Contains("=")) {
                } else if (line.contains("(") && line.contains(")") && line.indexOf("(") < line.indexOf(")")) { // check for function call
                    var parts = line.split("(")
                    var funcName = parts[0]
                    parts = parts[1].split(")")
                    val args = parts[0]
                    val math = if (parts.size > 1) parts[1] else ""
                    parts = funcName.split("=")
                    var target = "r0"
                    if (parts.size > 1) {
                        target = parts[0].trim()
                        funcName = parts[1]
                    }
                    var j = 0
                    if (funcName.length > 0) {
                        for (arg in args.split(",")) {
                            if (arg.isEmpty()) continue
                            if (arg.trim() != "r" + j) {
                                results.addAll(macroPass(labels, "r" + j + "=" + arg))
                            }
                            j++
                        }
                        results.add("bl <" + funcName + ">")
                        if (math.isNotBlank() || target != "r0") results.addAll(macroPass(labels, target + " = r0 " + math))
                    } else {
                        // no function name, not a macro. Probably a ldr rX, =(a+b) type instruction
                        results.add(line)
                    }
                } else if (line.startsWith("r") && "=[].".all { c -> line.contains(c) }) { // expect rA = table[rB].field
                    var tokens = line.split('=', limit = 2)
                    val rA = tokens[0]
                    if (tokens.size == 2) {
                        tokens = tokens[1].split('[', limit = 2)
                        val table = tokens[0].trim()
                        if (tokens.size == 2) {
                            tokens = tokens[1].split("].", limit = 2)
                            val rB = tokens[0]
                            if (tokens.size == 2) {
                                val field = tokens[1]
                                val tableRun = labels.table(table)
                                if (tableRun == null) {
                                    results.add(lines[i])
                                } else {
                                    val segmentLength = tableRun.elementContent.firstOrNull { seg -> seg.name == field }?.length ?: 4
                                    var loadCommand = "ldr"
                                    if (segmentLength == 2) loadCommand = "ldrh"
                                    if (segmentLength == 1) loadCommand = "ldrb"
                                    var fieldOffset = 0
                                    for (seg in tableRun.elementContent.until { seg -> seg.name == field }) fieldOffset += seg.length
                                    results.add("push {" + rB + "}")
                                    results.add("mov " + rA + ", " + tableRun.elementLength)
                                    results.add("mul " + rA + ", " + rB)
                                    results.add("ldr " + rB + ", =0x" + (tableRun.start + 0x08000000).toHex(8))
                                    results.add("add " + rA + ", " + rB)
                                    results.add("mov " + rB + ", #" + fieldOffset)
                                    results.add(loadCommand + " " + rA + ", [" + rA + ", " + rB + "]")
                                    results.add("pop {" + rB + "}")
                                }
                            }
                        }
                    }
                } else if (line.startsWith("r") && line.contains("=")) {
                    // expect rX = something
                    val tokens = line.split('=', limit = 2).toMutableList()
                    var firstInstruction = "mov"
                    if (tokens.size == 1) {
                        results.add(lines[i])
                    } else {
                        var valueText = tokens[1]
                        if (tokens[0].endsWith("+")) { tokens[0] = tokens[0].dropLast(1); firstInstruction = "add" }
                        if (tokens[0].endsWith("-")) { tokens[0] = tokens[0].dropLast(1); firstInstruction = "sub" }
                        if (tokens[0].endsWith("*")) { tokens[0] = tokens[0].dropLast(1); firstInstruction = "mul" }
                        if (tokens[0].endsWith("&")) { tokens[0] = tokens[0].dropLast(1); firstInstruction = "and" }
                        if (tokens[0].endsWith("^")) { tokens[0] = tokens[0].dropLast(1); firstInstruction = "xor" }
                        if (tokens[0].endsWith("|")) { tokens[0] = tokens[0].dropLast(1); firstInstruction = "orr" }
                        if (tokens[0].endsWith("<<")) { tokens[0] = tokens[0].dropLast(2); firstInstruction = "lsl" }
                        if (tokens[0].endsWith(">>")) { tokens[0] = tokens[0].dropLast(2); firstInstruction = "lsr" }
                        val valueRef = Ref(valueText)
                        val extraInstructions = readMath(tokens[0], valueRef)
                        valueText = valueRef.value.trim()
                        val value = Ref(0)
                        if (valueText.startsWith('<') && valueText.endsWith('>')) {
                            valueText = valueText.substring(1, valueText.length - 1)
                            // might be an address
                            if (valueText.tryParseHex(value)) {
                                value.value -= Pointer.null_
                                valueText = "0x" + value.value.toAddress()
                            } else if (labels.tryResolveLabel(valueText, value)) {
                                valueText = "0x" + (value.value - Pointer.null_).toAddress()
                            }
                        }
                        if (!valueText.tryParseInt(value)) {
                            // might be a register
                            results.add(firstInstruction + " " + tokens[0] + ", " + valueText)
                        } else if (value.value >= 0x100 || value.value < 0) {
                            results.add("ldr " + tokens[0] + ", =" + value.value)
                        } else {
                            results.add(firstInstruction + " " + tokens[0] + ", " + valueText)
                        }
                        while (extraInstructions.size > 0) results.add(extraInstructions.removeLast())
                    }
                } else {
                    results.add(lines[i])
                }
            }
            return results.toTypedArray()
        }
        fun readMath(register: String, expression: Ref<String>): ArrayDeque<String> { /*@DONE ThumbParser.ReadMath/1 cs:473-490*/
            val result = ArrayDeque<String>()
            while (true) {
                val addIndex = expression.value.lastIndexOf("+")
                val subIndex = expression.value.lastIndexOf("-")
                if (addIndex == -1 && subIndex == -1) break
                val last = maxOf(subIndex, addIndex)
                val op = expression.value[last]
                val arg = expression.value.substring(last + 1)
                expression.value = expression.value.substring(0, last)
                if (op == '-') {
                    result.addLast("sub " + register + ", " + arg)
                } else {
                    result.addLast("add " + register + ", " + arg)
                }
            }
            return result
        }
        fun instructionForComparator(comparator: String): String? { /*@DONE ThumbParser.InstructionForComparator/1 cs:492-500*/
            return when (comparator) {
                "<" -> "bge"
                "<=" -> "bgt"
                ">" -> "ble"
                ">=" -> "blt"
                "==" -> "bne"
                "!=" -> "beq"
                else -> null
            }
        }
        fun removeMultilineComments(lines: Array<String>) { /*@DONE ThumbParser.RemoveMultilineComments/1 cs:502-529*/
            var i = 0
            var characterIndex = 0
            var insideComment = false
            while (i < lines.size) {
                if (!insideComment) {
                    val commentStart = lines[i].indexOf("/*")
                    if (commentStart == -1) {
                        i++
                        continue
                    }
                    characterIndex = commentStart + 2
                    insideComment = true
                } else {
                    val commentStart = lines[i].substring(characterIndex).indexOf("*/")
                    if (commentStart == -1) {
                        if (characterIndex > 0) lines[i] = lines[i].substring(0, characterIndex - 2)
                        else lines[i] = ""
                        characterIndex = 0
                        i++
                        continue
                    }
                    if (characterIndex > 0) lines[i] = lines[i].substring(0, characterIndex - 2) + ' ' + lines[i].substring(characterIndex + commentStart + 2)
                    else lines[i] = lines[i].substring(commentStart + 2)
                    insideComment = false
                    characterIndex = 0
                }
            }
        }
        fun handleEquDirectives(lines: Array<String>) { /*@DONE ThumbParser.HandleEquDirectives/1 cs:531-555*/
            val replacers = LinkedHashMap<String, String>()
            for (i in 0 until lines.size) {
                val line = lines[i].trim()
                if (line.startsWith(".equ")) {
                    val content = line.substring(4).trim().split(",")
                    if (content.size == 2) replacers[content[0].trim()] = content[1].trim()
                    lines[i] = ""
                } else {
                    val keys = replacers.keys.toList()
                    var guard = 0
                    var j = 0
                    while (j < keys.size) {
                        if (keys[j].isEmpty() || ++guard > 100000) {
                            j++
                            continue
                        }
                        var index = lines[i].indexOf(keys[j])
                        while (index != -1 && (
                            (index > 0 && lines[i][index - 1].isLetterOrDigit()) ||
                            (index + keys[j].length < line.length - 1 && index + keys[j].length < lines[i].length && lines[i][index + keys[j].length].isLetterOrDigit())
                        )) {
                            index = if (lines[i].substring(index + 1).contains(keys[j])) lines[i].substring(index + 1).indexOf(keys[j]) + index + 1 else -1
                        }
                        if (index == -1) {
                            j++
                            continue
                        }
                        lines[i] = lines[i].substring(0, index) + replacers[keys[j]] + lines[i].substring(index + keys[j].length)
                    }
                }
            }
        }
        fun isThumbSelection(data: IDataModel, start: Int, length: Int): Boolean { /*@DONE ThumbParser.IsThumbSelection/1 cs:557-574*/
            var run: IFormattedRun = data.getNextRun(start) ?: NoInfoRun.nullRun
            if (run.start == start && run is NoInfoRun && data.getAnchorFromAddress(-1, start).isNotEmpty()) {
                // this is fine, but the next run may be a problem
                run = data.getNextRun(start + 1) ?: NoInfoRun.nullRun
            }
            // only pointer formats are allowed
            while (run.start < start + length) {
                if (run !is PointerRun) return false
                run = data.getNextRun(run.start + run.length) ?: NoInfoRun.nullRun
            }
            if (start < 0 || start + length > data.count) return false
            if (start + 1 >= data.count) return false
            if (data[start + 1] != 0xB5) return false
            if (start + length == data.count) return true
            if (start + length + 1 == data.count) return false
            if (data[start + length] == 0xFF && data[start + length + 1] == 0xFF) return true
            return data[start + length + 1] == 0xB5
        }
        fun getSelectionLength(data: ByteList, start: Int): Int { /*@DONE ThumbParser.GetSelectionLength/1 cs:576-589*/
            if (start < 0 || start >= data.count - 1) return -1
            if (data[start + 1] != 0xB5) return -1
            var i = start + 3
            while (i < data.count) {
                if (data[i] == 0xB5) break
                if (data.readMultiByteValue(i - 1, 2) == 0xFFFF) break
                i += 2
            }
            if (i >= data.count) return -1
            val length = i - 1 - start
            if (length > 1000) return -1
            return length
        }
        fun tryWriteUniversalBranchLink(data: IDataModel, token: ModelDelta, start: Int, length: Int): Boolean { /*@DONE ThumbParser.TryWriteUniversalBranchLink/1 cs:591-610*/
            val startRun = data.getNextRun(start)
            if (startRun !is NoInfoRun) return false
            val name = data.getAnchorFromAddress(-1, start)
            if (name.isEmpty()) return false

            // write the UBL code
            val write = "03 B4 01 49 01 91 02 BD".parseHexBytes()
            token.changeData(data, start, write.asByteList())

            // write the pointer to here (with offset), then the format, then clear the anchor, leaving a an offset-pointer to the name
            data.writePointer(token, start + write.size, start + 1)
            data.observeRunWritten(token, OffsetPointerRun(start + write.size, 1))
            data.clearFormat(token, start, 1)

            // clear remaining bytes
            if (length > write.size + 4) data.clearFormat(token, start + write.size + 4, length - write.size - 4)
            for (i in write.size + 4 until length) token.changeData(data, start + i, 0xFF)
            return true
        }
        /*@END ThumbParser.Companion*/
    }
    /*@END ThumbParser*/
}

open class ConditionCode { // cs:651-680
    var code: Int = 0
        private set
    var mnemonic: String = ""
        private set
    private constructor(mnemonic: String, bits: String) { /*@DONE ConditionCode.<init>/1 cs:657-663*/
        this.mnemonic = mnemonic
        if (bits[0] == '1') code += 0x8
        if (bits[1] == '1') code += 0x4
        if (bits[2] == '1') code += 0x2
        if (bits[3] == '1') code += 0x1
    }
    companion object {
        fun tryLoadConditionCode(line: String, ccode: Ref<ConditionCode?>): Boolean { /*@DONE ConditionCode.TryLoadConditionCode/1 cs:665-677*/
            ccode.value = null
            val trimmed = line.split('@')[0].trim()
            val parts = trimmed.split('=').toMutableList()
            if (parts.size != 2) return false
            parts[0] = parts[0].trim()
            if (parts[0].length != 2) return false
            parts[1] = parts[1].trim()
            if (parts[1].length != 4) return false

            ccode.value = ConditionCode(parts[0], parts[1])
            return true
        }
        /*@END ConditionCode.Companion*/
    }
    /*@END ConditionCode*/
}

enum class InstructionArgType(val value: Int) { // cs:682-692
    OpCode(0),
    Register(1),
    Numeric(2),
    HighRegister(3),
    List(4),
    ReverseList(5),
    Condition(6);
    companion object {
        fun fromValue(value: Int): InstructionArgType = entries.first { it.value == value }
    }
    /*@END InstructionArgType*/
}

class InstructionPart { // cs:694-706
    var type: InstructionArgType = InstructionArgType.OpCode
        private set
    var code: Int = 0
        private set
    var length: Int = 0
        private set
    var name: String = ""
        private set
    constructor(type: InstructionArgType, code: Int, length: Int, name: String = "") { /*@DONE InstructionPart.<init>/1 cs:700-705*/
        this.type = type
        this.code = code
        this.length = length
        this.name = name
    }
    constructor()
    override fun equals(other: Any?): Boolean = other is InstructionPart && type == other.type && code == other.code && length == other.length && name == other.name
    override fun hashCode(): Int { var h = 17; h = h * 31 + (type as Any?).hashCode(); h = h * 31 + (code as Any?).hashCode(); h = h * 31 + (length as Any?).hashCode(); h = h * 31 + (name as Any?).hashCode(); return h }
    /*@END InstructionPart*/
}

interface IInstruction { // cs:708-714
    val byteLength: Int
    val requiresAlignment: Boolean
    fun matches(data: IDataModel, index: Int): Boolean
    fun disassemble(data: IDataModel, address: Int, conditionalCodes: List<ConditionCode>): String
    fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, address: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean
    /*@END IInstruction*/
}

open class Instruction : IInstruction { // cs:717-1181
    private val instructionParts: MutableList<InstructionPart> = /*@INITAUTO Instruction.instructionParts cs:718-718*/ ArrayList() /*@ENDINIT*/
    private var template: String = ""
    final override var byteLength: Int = /*@INITAUTO Instruction.ByteLength cs:721-721*/ 2 /*@ENDINIT*/
        private set
    override val requiresAlignment: Boolean
        get() { /*@DONE Instruction.RequiresAlignment.get cs:722-722*/
            return false
        }
    val operator: String
        get() { /*@DONE Instruction.Operator.get cs:724-724*/
            return template.split(" ")[0]
        }
    private constructor(compiled: String, script: String) { /*@DONE Instruction.<init>/1 cs:728-775*/
        val parts = compiled.lowercase().split(' ')
        for (part in parts) {
            if (part.startsWith("0") || part.startsWith("1")) {
                val code = toBits(part)
                instructionParts.add(InstructionPart(InstructionArgType.OpCode, code, part.length))
            } else if (part == "lr") {
                instructionParts.add(InstructionPart(InstructionArgType.Register, 0, 3, part))
            } else if (part.startsWith("r")) {
                instructionParts.add(InstructionPart(InstructionArgType.Register, 0, 3, part))
            } else if (part.startsWith("#")) {
                var code = 0
                if (script.contains("#=pc+#*")) {
                    // Code contains 2 8-bit sections: the number to multiply by, followed by the number to add.
                    // Note that the number to multiply by also gives us a number to mod by.
                    val encoding = script.split("#=pc+#*")[1].split('+')
                    val mult = Ref(0)
                    code = if (tryParseInt(encoding[0], mult) && mult.value >= 0 && mult.value <= 255) mult.value else 0
                    code = code shl 8
                    val add = Ref(0)
                    code = code or (if (encoding.size > 1 && tryParseInt(encoding[1].trim(']'), add) && add.value >= 0 && add.value <= 255) add.value else 0)
                }
                val length = Ref(0)
                if (part.length > 1) tryParseInt(part.substring(1), length)
                instructionParts.add(InstructionPart(InstructionArgType.Numeric, code, length.value))
            } else if (part == "h") {
                instructionParts.add(InstructionPart(InstructionArgType.HighRegister, 0, 1))
            } else if (part == "list") {
                instructionParts.add(InstructionPart(InstructionArgType.List, 0, 8))
            } else if (part == "tsil") {
                instructionParts.add(InstructionPart(InstructionArgType.ReverseList, 0, 8))
            } else if (part == "cond") {
                instructionParts.add(InstructionPart(InstructionArgType.Condition, 0, 4))
            }
        }

        var totalLength = 0
        for (p in instructionParts) totalLength += p.length
        if (totalLength > 16) byteLength = totalLength / 8
        val remainingLength = byteLength * 8 - totalLength
        var i = 0
        while (i < instructionParts.size && remainingLength > 0) {
            if (instructionParts[i].type == InstructionArgType.Numeric) {
                instructionParts[i] = InstructionPart(InstructionArgType.Numeric, instructionParts[i].code, remainingLength)
                totalLength += remainingLength
            }
            i++
        }

        if (totalLength % 16 != 0) throw ArgumentException("There were " + totalLength + " bits in the command, but commands must be a multiple of 16 bits long!")

        template = script.lowercase()
        if (template.startsWith("bl ")) byteLength = 4
    }
    override fun toString(): String { /*@DONE Instruction.ToString/1 cs:806-806*/
        return template
    }
    override fun matches(data: IDataModel, index: Int): Boolean { /*@DONE Instruction.Matches/1 cs:808-819*/
        if (data.count < index + byteLength) return false
        var remainingBits = byteLength * 8
        val assembled = data.readMultiByteValue(index, byteLength)
        for (part in instructionParts) {
            remainingBits -= part.length
            if (part.type != InstructionArgType.OpCode) continue
            val code = grabBits(assembled, remainingBits, part.length)
            if (code != part.code) return false
        }
        return true
    }
    override fun disassemble(data: IDataModel, pcAddress: Int, conditionCodes: List<ConditionCode>): String { /*@DONE Instruction.Disassemble/1 cs:821-861*/
        var instruction = template
        val assembled = data.readMultiByteValue(pcAddress, byteLength)
        val highStack = ArrayList<Boolean>()
        var remainingBits = byteLength * 8
        for (part in instructionParts) {
            remainingBits -= part.length
            var bits = grabBits(assembled, remainingBits, part.length)
            if (part.type == InstructionArgType.HighRegister) {
                highStack.add(bits != 0)
            } else if (part.type == InstructionArgType.List) {
                val listStart = instruction.indexOf("list")
                instruction = instruction.replace("list", serializeRegisterList(bits))
                if (instruction.length > listStart && instruction[listStart] == ',') instruction = instruction.substring(0, listStart) + instruction.substring(listStart + 1).trim()
            } else if (part.type == InstructionArgType.ReverseList) {
                instruction = instruction.replace("tsil", serializeRegisterReverseList(bits))
            } else if (part.type == InstructionArgType.Condition) {
                val suffix = conditionCodes.firstOrNull { code -> code.code == bits }?.mnemonic ?: "??"
                instruction = instruction.replace("{cond}", suffix)
            } else if (part.type == InstructionArgType.Numeric) {
                if (part.code != 0) {
                    instruction = calculatePcRelativeAddress(data, instruction, pcAddress, part, bits)
                } else if (instruction.contains("#=#*")) {
                    val multiplierIndex = instruction.indexOf("#=#*") + 4
                    val multiplier = instruction[multiplierIndex] - '0'
                    instruction = instruction.replace("#=#*" + instruction[multiplierIndex], "#" + (bits * multiplier))
                } else {
                    instruction = instruction.replace("#", "#" + bits)
                }
            } else if (part.type == InstructionArgType.Register) {
                if (highStack.size > 0) {
                    if (highStack.last()) bits += 8
                    highStack.removeAt(highStack.size - 1)
                }
                instruction = instruction.replace(part.name, "r" + bits)
            }
        }

        var i = 2
        while (i < byteLength) {
            instruction += "\n"
            i += 2
        }
        return "    " + instruction
    }
    override fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, codeLocation: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean { /*@DONE Instruction.TryAssemble/1 cs:907-978*/
        var line = line.lowercase().replace('\t', ' ')
        var result = 0
        val bytes = ByteArray(byteLength)
        results.value = bytes
        var thisTemplate = template

        // setup ConditionCode if there is one
        var ccode: ConditionCode? = null
        if (thisTemplate.contains("{cond}")) {
            val condIndex = thisTemplate.indexOf("{cond}")
            if (line.length < condIndex) return false
            if (thisTemplate.substring(0, condIndex) != line.substring(0, condIndex)) return false
            if (condIndex + 2 > line.length) return false
            val condition = line.substring(condIndex, condIndex + 2)
            ccode = conditionCodes.firstOrNull { code -> code.mnemonic == condition }
            if (ccode == null) return false
            val start = thisTemplate.substring(0, condIndex + 6)
            val newStart = line.substring(0, condIndex + 2)
            thisTemplate = thisTemplate.replace(start, newStart)
        }

        // check that the command matches
        val commandToken = line.split(' ')[0]
        if (!thisTemplate.startsWith(commandToken + " ") && thisTemplate != line) return false
        if (commandToken.length > line.length) return false
        line = line.substring(commandToken.length)
        thisTemplate = thisTemplate.substring(commandToken.length)

        val registersValues = java.util.TreeMap<Int, Int>()
        val numeric = Ref(0)
        val list = Ref(0)
        if (!matchLinePartsToTemplateParts(line, thisTemplate, registersValues, labels, numeric, list)) return false

        var remainingBits = byteLength * 8
        val registerListForHighCheck = ArrayList<Int>(registersValues.values)
        val registerListForRegisters = ArrayList<Int>(registersValues.values)
        var firstNumeric = true
        for (part in instructionParts) {
            remainingBits -= part.length
            result = result shl part.length
            if (part.type == InstructionArgType.OpCode) {
                result = result or part.code
            } else if (part.type == InstructionArgType.Condition) {
                result = result or (ccode?.code ?: 0)
            } else if (part.type == InstructionArgType.HighRegister) {
                if ((registerListForHighCheck.lastOrNull() ?: 0) > 7) result = result or 1
                if (registerListForHighCheck.size > 0) registerListForHighCheck.removeAt(registerListForHighCheck.size - 1)
            } else if (part.type == InstructionArgType.Numeric) {
                if (part.code != 0 && firstNumeric) {
                    val mult = (part.code shr 8) and 0xFF
                    val add = part.code and 0xFF
                    if (mult != 0) numeric.value -= codeLocation - codeLocation % mult  // offset based on code starting point
                    numeric.value -= add                                                // offset from bias
                    if (mult != 0) numeric.value /= mult
                    firstNumeric = false
                }
                val mask = (1 shl part.length) - 1
                result = result or ((numeric.value and mask) and 0xFFFF)
                numeric.value = numeric.value shr part.length
            } else if (part.type == InstructionArgType.Register) {
                result = result or (((if (registerListForRegisters.size > 0) registerListForRegisters[0] else 0) and 7) and 0xFFFF)
                if (registerListForRegisters.size > 0) registerListForRegisters.removeAt(0)
            } else if (part.type == InstructionArgType.List) {
                result = result or list.value
            }
        }

        bytes[0] = result.toByte()
        bytes[1] = (result ushr 8).toByte()
        if (bytes.size == 4) {
            bytes[2] = (result ushr 16).toByte()
            bytes[3] = (result ushr 24).toByte()
        }
        return true
    }
    private fun matchLinePartsToTemplateParts(line: String, template: String, registerValues: java.util.TreeMap<Int, Int>, labels: LabelLibrary, numeric: Ref<Int>, list: Ref<Int>): Boolean { /*@DONE Instruction.MatchLinePartsToTemplateParts/1 cs:980-1094*/
        var line = line
        var template = template
        numeric.value = 0
        list.value = 0
        while (line.length > 0 && template.length > 0) {
            // make sure that the basic format matches where it should
            while (template.length > 0 && (template[0] == ' ' || template[0] == ',')) template = template.substring(1)
            while (line.length > 0 && (line[0] == ' ' || line[0] == '!' || line[0] == ',')) line = line.substring(1)
            if (template.length == 0 || line.length == 0) continue
            if (template[0] == '[') {
                if (line[0] != '[') {
                    if (template.startsWith("[pc, ") && template.endsWith("]") && labels.resolveLabel(line) != Pointer.null_) {
                        template = template.substring(5)
                        template = template.substring(0, template.length - 1)
                        continue
                    } else {
                        return false
                    }
                }
                template = template.substring(1)
                line = line.substring(1)
                continue
            }
            if (template[0] == ']') {
                if (line[0] != ']') return false
                template = template.substring(1)
                line = line.substring(1)
                continue
            }

            // read a register
            if (template[0] == 'r') {
                if (line.startsWith("sp")) line = "r13" + line.substring(2)
                if (line.startsWith("lr")) line = "r14" + line.substring(2)
                if (line.startsWith("pc")) line = "r15" + line.substring(2)
                if (line[0] != 'r') return false
                val name = "r" + (if (template.length > 1) template[1].toString() else "")
                val value = Ref(0)
                if (tryParseInt(line.split(',', ']', '!', ' ')[0].substring(1), value)) {
                    if (value.value > 7 && !instructionParts.any { part -> part.type == InstructionArgType.HighRegister }) return false
                    for (index in 0 until instructionParts.size) {
                        val instruction = instructionParts[index]
                        if (instruction.name != name) continue
                        if (registerValues.containsKey(index) && registerValues[index] != value.value) return false
                        registerValues[index] = value.value
                    }
                }
                template = template.substring(minOf(2, template.length))
                val register = "r" + value.value
                if (register.length > line.length) return false
                line = line.substring(register.length)
                continue
            }

            // read a pointer
            if (template.startsWith("#=pc")) {
                val lineRef = Ref(line)
                if (!readPointer(lineRef, numeric, labels)) return false
                line = lineRef.value
                template = template.substring(template.indexOf('+') + 1)
                template = template.substring(template.indexOf('+') + 2)
                continue
            }

            // read a number
            if (template[0] == '#') {
                if (line[0] == '#') line = line.substring(1)
                val numberAsText = line.split(',', ']')[0]
                if (numberAsText.startsWith("0x")) {
                    if (!tryParseHexInt(numberAsText.substring(2), numeric)) return false
                } else {
                    if (!tryParseInt(numberAsText, numeric)) return false
                }
                template = template.substring(1)
                line = line.substring(numberAsText.length)
                if (template.startsWith("=#*")) {
                    val multiplier = template[3] - '0'
                    template = template.substring(4)
                    if (multiplier != 0) numeric.value /= multiplier
                }
                continue
            }

            // read list
            if (template[0] == '{') {
                val templateListLength = template.indexOf("}") + 1
                if (templateListLength == 0) return false
                if (line[0] != '{') return false
                val listEnd = line.indexOf('}')
                if (listEnd == -1) return false
                var serializedList = line.substring(1, listEnd)
                line = line.substring(listEnd + 1)
                if (template.contains("lr}") || template.contains("{lr")) {
                    if (!serializedList.contains("lr")) return false
                    serializedList = serializedList.replace("lr", "")
                } else if (template.contains("pc}") || template.contains("{pc")) {
                    if (!serializedList.contains("pc")) return false
                    serializedList = serializedList.replace("pc", "")
                }
                if (serializedList.contains("lr") || serializedList.contains("pc")) return false
                list.value = parseList(serializedList)
                template = template.substring(templateListLength)
                continue
            }

            // read fixed register
            if (template.length >= 2 && line.length >= 2 && template.substring(0, 2) == line.substring(0, 2)) {
                template = template.substring(2)
                line = line.substring(2)
                continue
            }

            // fail
            return false
        }

        // Completed parsing the line. Should've used the entire template.
        return template.length == 0 && line.length == 0
    }
    companion object {
        fun tryLoadInstruction(line: String, instruction: Ref<Instruction?>): Boolean { /*@DONE Instruction.TryLoadInstruction/1 cs:777-791*/
            instruction.value = null
            val trimmed = line.split('@')[0].trim()
            val parts = trimmed.split('|')
            if (parts.size != 2) return false

            try {
                instruction.value = Instruction(parts[0].trim(), parts[1].trim())
            } catch (e: ArgumentException) {
                return false
            }

            return true
        }
        fun toBits(bits: String): Int { /*@DONE Instruction.ToBits/1 cs:795-797*/
            var result = 0
            for (b in bits) result = result * 2 + (b - '0')
            return result and 0xFFFF
        }
        fun grabBits(value: Int, start: Int, length: Int): Int { /*@DONE Instruction.GrabBits/1 cs:799-804*/
            var v = value ushr start
            val mask = (1 shl length) - 1
            v = v and (mask and 0xFFFF)
            return v and 0xFFFF
        }
        private fun calculatePcRelativeAddress(model: IDataModel, instruction: String, pcAddress: Int, part: InstructionPart, bits: Int): String { /*@DONE Instruction.CalculatePcRelativeAddress/1 cs:863-905*/
            var instruction = instruction
            val mult = grabBits(part.code, 8, 8)
            val add = grabBits(part.code, 0, 8)
            var numeric = bits.toShort().toInt()

            // Add on the sign. Note that ldr (recognized by mult=4, add=4) are unsigned.
            if (mult != 4 || add != 4) {
                numeric = (numeric shl (16 - part.length)).toShort().toInt()
                numeric = numeric shr (16 - part.length) // signed-right-shift carries the sign
            }

            if (instruction.contains("#")) {
                // this is the first # in this instruction.
                val address = pcAddress - (pcAddress % mult) + numeric * mult + add
                val end = if (instruction.endsWith("]")) "]" else ""
                instruction = instruction.split("#=")[0] + "#" + end
                var addressText = model.getAnchorFromAddress(-1, address)
                if (addressText.isEmpty()) addressText = address.toHex(6)
                instruction = instruction.replace("#", "<" + addressText + ">")
            } else {
                // this is an additional # in the same instruction.
                // decode back from the old one
                val content = instruction.split('<')[1].split('>')[0]
                var address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, content)
                if (address == Pointer.null_) {
                    val parsed = Ref(0)
                    tryParseHexInt(content, parsed)
                    address = parsed.value
                }
                address -= pcAddress - (pcAddress % mult) + add
                address /= mult
                address = address and ((1 shl part.length) - 1) // drop the high bits, keep only the data bits. This makes it lose the sign.
                // concat the new numeric
                address += bits shl part.length   // the new numeric is the higher bits
                // shift to get arithmetic sign bits
                address = address shl (32 - part.length * 2)
                address = address shr (32 - part.length * 2)   // since address is a signed int, the right-shift carries 1-bits down if the high bit is set. This is what we want to happen.
                // encode again
                address *= mult
                address += pcAddress - (pcAddress % mult) + add
                var addressText = model.getAnchorFromAddress(-1, address)
                if (addressText.isEmpty()) addressText = address.toHex(6)
                instruction = instruction.split('<')[0] + "<" + addressText + ">" + (instruction + " ").split('>')[1].trim() // extra space / trim let's us get everything after the '>', even if it's empty
            }

            return instruction
        }
        fun readPointer(line: Ref<String>, numeric: Ref<Int>, labels: LabelLibrary): Boolean { /*@DONE Instruction.ReadPointer/1 cs:1096-1112*/
            if (line.value.isNotEmpty() && line.value[0] == '<') line.value = line.value.substring(1)
            var content = line.value
            if (content.contains('>')) content = content.split('>')[0]
            var extraLength = 0
            if (content.startsWith("0x")) {
                content = content.substring(2)
                extraLength += 2
            }
            numeric.value = labels.resolveLabel(content)
            if (numeric.value == Pointer.null_ && !tryParseHexInt(content, numeric)) return false
            if (line.value.length < content.length + extraLength) return false
            if (numeric.value >= 0x08000000) numeric.value -= 0x08000000
            line.value = line.value.substring(content.length + extraLength)
            if (line.value.startsWith(">")) line.value = line.value.substring(1)
            return true
        }
        private fun parseList(list: String): Int { /*@DONE Instruction.ParseList/1 cs:1114-1138*/
            var result = 0
            var start = 0
            while (list.length > start) {
                if (list[start] == ',' || list[start] == ' ') {
                    start++
                    continue
                }
                if (list.length > start + 4 && list[start + 2] == '-') {
                    val subStart = list[start + 1] - '0'
                    val subEnd = list[start + 4] - '0'
                    for (i in subStart..subEnd) result = result or ((1 shl i) and 0xFFFF)
                    start += 5
                    continue
                }
                if (list.length > start + 1) {
                    val index = list[start + 1] - '0'
                    result = result or ((1 shl index) and 0xFFFF)
                    start += 2
                    continue
                }
                return 0
            }
            return result
        }
        fun serializeRegisterList(registerList: Int): String { /*@DONE Instruction.SerializeRegisterList/1 cs:1140-1159*/
            var result = ""
            for (bit in 0 until 8) {
                // only write if the current bit is on
                if ((registerList and (1 shl bit)) == 0) continue
                // if there's no previous bit or the previous bit is off
                if (bit == 0 || (registerList and (1 shl (bit - 1))) == 0) {
                    if (result.length > 0) result += ", "
                    result += "r" + bit
                    if ((registerList and (1 shl (bit + 1))) != 0) result += "-"
                    continue
                }
                // if there is no next bit or the next bit is off
                if (bit == 7 || (registerList and (1 shl (bit + 1))) == 0) {
                    result += "r" + bit
                    continue
                }
            }
            return result
        }
        fun serializeRegisterReverseList(registerList: Int): String { /*@DONE Instruction.SerializeRegisterReverseList/1 cs:1161-1180*/
            var result = ""
            for (bit in 7 downTo 0) {
                // only write if the current bit is on
                if ((registerList and (1 shl bit)) == 0) continue
                // if there's no previous bit or the previous bit is off
                if (bit == 7 || (registerList and (1 shl (bit + 1))) == 0) {
                    if (result.length > 0) result += ", "
                    result += "r" + (7 - bit)
                    if ((registerList and (1 shl (bit - 1))) != 0) result += "-"
                    continue
                }
                // if there is no next bit or the next bit is off
                if (bit == 0 || (registerList and (1 shl (bit - 1))) == 0) {
                    result += "r" + (7 - bit)
                    continue
                }
            }
            return result
        }
        /*@END Instruction.Companion*/
    }
    /*@END Instruction*/
}

open class ByteInstruction : IInstruction { // cs:1183-1199
    override val byteLength: Int
        get() { /*@DONE ByteInstruction.ByteLength.get cs:1184-1184*/
            return 1
        }
    override val requiresAlignment: Boolean
        get() { /*@DONE ByteInstruction.RequiresAlignment.get cs:1185-1185*/
            return false
        }
    override fun disassemble(data: IDataModel, address: Int, conditionalCodes: List<ConditionCode>): String { /*@DONE ByteInstruction.Disassemble/1 cs:1187-1187*/
        throw NotImplementedException()
    }
    override fun matches(data: IDataModel, index: Int): Boolean { /*@DONE ByteInstruction.Matches/1 cs:1189-1189*/
        return false
    }
    override fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, address: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean { /*@DONE ByteInstruction.TryAssemble/1 cs:1191-1198*/
        val text = line.replace(".byte", " ").trim()
        results.value = null
        val result = Ref(0)
        if (!text.tryParseInt(result)) return false
        results.value = byteArrayOf(result.value.toByte())
        return true
    }
    /*@END ByteInstruction*/
}

open class HalfWordInstruction : IInstruction { // cs:1201-1220
    override val byteLength: Int
        get() { /*@DONE HalfWordInstruction.ByteLength.get cs:1202-1202*/
            return 2
        }
    override val requiresAlignment: Boolean
        get() { /*@DONE HalfWordInstruction.RequiresAlignment.get cs:1203-1203*/
            return false
        }
    override fun disassemble(data: IDataModel, address: Int, conditionalCodes: List<ConditionCode>): String { /*@DONE HalfWordInstruction.Disassemble/1 cs:1205-1205*/
        throw NotImplementedException()
    }
    override fun matches(data: IDataModel, index: Int): Boolean { /*@DONE HalfWordInstruction.Matches/1 cs:1207-1207*/
        return false
    }
    override fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, address: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean { /*@DONE HalfWordInstruction.TryAssemble/1 cs:1209-1219*/
        val text = line.replace(".hword", " ").trim()
        results.value = null
        val result = Ref(0)
        if (!text.tryParseInt(result)) return false
        results.value = byteArrayOf(result.value.toByte(), (result.value shr 8).toByte())
        return true
    }
    /*@END HalfWordInstruction*/
}

open class WordInstruction : IInstruction { // cs:1222-1260
    override val byteLength: Int
        get() { /*@DONE WordInstruction.ByteLength.get cs:1223-1223*/
            return 4
        }
    override val requiresAlignment: Boolean
        get() { /*@DONE WordInstruction.RequiresAlignment.get cs:1224-1224*/
            return true
        }
    override fun disassemble(data: IDataModel, address: Int, conditionalCodes: List<ConditionCode>): String { /*@DONE WordInstruction.Disassemble/1 cs:1226-1226*/
        throw NotImplementedException()
    }
    override fun matches(data: IDataModel, index: Int): Boolean { /*@DONE WordInstruction.Matches/1 cs:1228-1228*/
        return false
    }
    override fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, address: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean { /*@DONE WordInstruction.TryAssemble/1 cs:1230-1259*/
        var text = line.replace(".word", " ").trim()
        val result = Ref(0)
        results.value = null
        if (text.startsWith("<") && text.endsWith(">")) {
            text = text.substring(1, text.length - 1)
            result.value = labels.resolveLabel(text)
            if (result.value == Pointer.null_ && !tryParseHexInt(text, result)) return false
            result.value -= Pointer.null_
        } else if (labels.tryResolveValue(text, result)) {
            // Parse successful! Nothing else to do.
        } else {
            if (text.startsWith("0x")) text = text.substring(2)
            var add = 0
            if (text.contains("+")) {
                val parts = text.split("+")
                val addRef = Ref(0)
                if (!tryParseInt(parts[1], addRef)) return false
                add = addRef.value
                text = parts[0]
            }
            if (!tryParseHexInt(text, result)) return false
            result.value += add
        }
        results.value = byteArrayOf(
            result.value.toByte(),
            (result.value shr 8).toByte(),
            (result.value shr 16).toByte(),
            (result.value shr 24).toByte(),
        )
        return true
    }
    /*@END WordInstruction*/
}

open class AlignInstruction : IInstruction { // cs:1262-1276
    override val byteLength: Int
        get() { /*@DONE AlignInstruction.ByteLength.get cs:1263-1263*/
            return 4
        }
    override val requiresAlignment: Boolean
        get() { /*@DONE AlignInstruction.RequiresAlignment.get cs:1264-1264*/
            return true
        }
    override fun disassemble(data: IDataModel, address: Int, conditionalCodes: List<ConditionCode>): String { /*@DONE AlignInstruction.Disassemble/1 cs:1266-1268*/
        throw NotImplementedException()
    }
    override fun matches(data: IDataModel, index: Int): Boolean { /*@DONE AlignInstruction.Matches/1 cs:1270-1270*/
        return false
    }
    override fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, address: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean { /*@DONE AlignInstruction.TryAssemble/1 cs:1272-1275*/
        results.value = ByteArray(0)
        return line.startsWith(".align")
    }
    /*@END AlignInstruction*/
}

open class SkipInstruction : IInstruction { // cs:1281-1298
    override val byteLength: Int
        get() { /*@DONE SkipInstruction.ByteLength.get cs:1282-1282*/
            return 0
        }
    override val requiresAlignment: Boolean
        get() { /*@DONE SkipInstruction.RequiresAlignment.get cs:1283-1283*/
            return false
        }
    override fun disassemble(data: IDataModel, address: Int, conditionalCodes: List<ConditionCode>): String { /*@DONE SkipInstruction.Disassemble/1 cs:1285-1287*/
        throw NotImplementedException()
    }
    override fun matches(data: IDataModel, index: Int): Boolean { /*@DONE SkipInstruction.Matches/1 cs:1289-1289*/
        return false
    }
    override fun tryAssemble(line: String, conditionCodes: List<ConditionCode>, address: Int, labels: LabelLibrary, results: Ref<ByteArray?>): Boolean { /*@DONE SkipInstruction.TryAssemble/1 cs:1291-1297*/
        results.value = ByteArray(0)
        for (start in ".text .thumb .end .thumb_func .global .align".split(' ')) {
            if (line.startsWith(start)) return true
        }
        return false
    }
    /*@END SkipInstruction*/
}

open class DeferredLoadRegisterToken { // cs:1305-1385
    private var instructionAddresses: MutableList<Int> = ArrayList()
    var register: Int = 0
        private set
    var wordToLoad: Int = 0
        private set
    constructor(address: Int, register: Int, word: String, labels: LabelLibrary) { /*@DONE DeferredLoadRegisterToken.<init>/1 cs:1310-1339*/
        var word = word
        if (word.startsWith("=")) word = word.substring(1).trim()
        if (word.startsWith("(")) word = word.substring(1).trim()
        if (word.startsWith("#")) word = word.substring(1).trim()
        if (word.endsWith(")")) word = word.substring(0, word.length - 1).trim()

        var more = 0
        if (word.indexOf("+") > word.indexOf(">")) {
            val parts = word.split("+")
            if (parts.size == 2) {
                val moreRef = Ref(0)
                tryParseInt(parts[1], moreRef)
                more = moreRef.value
            }
            word = parts[0]
        }

        val wordValue = Ref(0)
        if (word.startsWith("<") && word.endsWith(">")) {
            word = word.substring(1, word.length - 1)
            if (!tryParseHexInt(word, wordValue)) {
                wordValue.value = labels.resolveLabel(word)
            }
            wordValue.value += 0x08000000
        } else if (word.startsWith("0x")) {
            tryParseHexInt(word.substring(2), wordValue)
        } else {
            tryParseInt(word, wordValue)
        }

        instructionAddresses = ArrayList<Int>()
        instructionAddresses.add(address)
        this.register = register
        wordToLoad = wordValue.value + more
    }
    fun write(dataStart: Int, data: MutableList<Int>, wordAddress: Int) { /*@DONE DeferredLoadRegisterToken.Write/1 cs:1341-1360*/
        //build instruction
        for (instructionAddress in instructionAddresses) {
            var instructionWord = instructionAddress
            if ((dataStart + instructionWord) % 4 != 0) instructionWord -= 2
            val offset = (wordAddress - instructionWord - 4) / 4
            var instruction = 9 // 0b01001
            instruction = instruction shl 3
            instruction = instruction or register
            instruction = instruction shl 8
            instruction = instruction or offset

            // insert instruction
            data[instructionAddress] = instruction and 0xFF
            data[instructionAddress + 1] = (instruction shr 8) and 0xFF

            // insert word
            for (i in 0 until 4) data[wordAddress + i] = (wordToLoad shr (8 * i)) and 0xFF
        }
    }
    companion object {
        fun isEndOfSection(line: String): Boolean { /*@DONE DeferredLoadRegisterToken.IsEndOfSection/1 cs:1362-1364*/
            return line.startsWith("b ") || line.startsWith("bx ") || (line.startsWith("pop ") && line.contains("pc"))
        }
        fun tryCompile(address: Int, line: String, labels: LabelLibrary, inlineWords: ArrayDeque<DeferredLoadRegisterToken>): Boolean { /*@DONE DeferredLoadRegisterToken.TryCompile/1 cs:1366-1384*/
            var text = line
            if (!text.startsWith("ldr ")) return false
            text = text.substring(4)
            val parts = text.split("=")
            if (parts.size != 2) return false
            val registerText = parts[0].trim(' ', ',')
            if (registerText.length != 2) return false
            if (registerText[0] != 'r') return false
            val register = registerText[1] - '0'
            if (register < 0 || register > 7) return false
            val newToken = DeferredLoadRegisterToken(address, register, parts[1].trim(), labels)
            val existingToken = inlineWords.firstOrNull { token -> token.wordToLoad == newToken.wordToLoad }
            if (existingToken != null) {
                existingToken.instructionAddresses.add(newToken.instructionAddresses[0])
            } else {
                inlineWords.addLast(newToken)
            }
            return true
        }
        /*@END DeferredLoadRegisterToken.Companion*/
    }
    /*@END DeferredLoadRegisterToken*/
}

open class DeferredUniversalBranchLinkToken { // cs:1387-1425
    var instructionAddresses: MutableList<Int> = ArrayList()
        private set
    var branchTarget: Int = 0
        private set
    constructor(target: Int) { /*@DONE DeferredUniversalBranchLinkToken.<init>/1 cs:1391-1394*/
        branchTarget = target
        instructionAddresses = ArrayList<Int>()
    }
    fun write(dataStart: Int, data: MutableList<Int>) { /*@DONE DeferredUniversalBranchLinkToken.Write/1 cs:1396-1413*/
        // update the branch-link commands at the InstructionAddresses to link to here
        for (i in 0 until instructionAddresses.size) {
            val offset = dataStart - instructionAddresses[i]
            val instruction1 = 0xF800 or ((offset - 4) / 2) // 0b11111_00000000000
            val instruction2 = 0xF000                         // 0b11110_00000000000
            data[data.size - offset + 0] = instruction2 and 0xFF
            data[data.size - offset + 1] = (instruction2 shr 8) and 0xFF
            data[data.size - offset + 2] = instruction1 and 0xFF
            data[data.size - offset + 3] = (instruction1 shr 8) and 0xFF
        }

        for (b in "03 B4 01 48 01 90 01 BD".parseHexBytes()) data.add(b.toInt() and 0xFF)
        data.add((branchTarget + 1) and 0xFF)
        data.add((branchTarget shr 8) and 0xFF)
        data.add((branchTarget shr 16) and 0xFF)
        data.add((branchTarget shr 24) and 0xFF)
    }
    companion object {
        fun canBranch(source: Int, destination: Int): Boolean { /*@DONE DeferredUniversalBranchLinkToken.CanBranch/1 cs:1415-1424*/
            val dest = destination - 4
            var diff = dest - source
            diff /= 2

            // can this number be represented in 22 bits?
            // yes, only if the top 10 bits are all the same as the 11th bit (sign bit).
            val sign = diff shr 21
            return sign == -1 || sign == 0
        }
        /*@END DeferredUniversalBranchLinkToken.Companion*/
    }
    /*@END DeferredUniversalBranchLinkToken*/
}
