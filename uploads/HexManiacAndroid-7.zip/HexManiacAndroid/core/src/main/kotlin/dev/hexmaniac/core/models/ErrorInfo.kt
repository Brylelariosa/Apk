// Port of Models/ErrorInfo.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class ErrorInfo { // cs:4-19
    val hasError: Boolean
        get() { /*@DONE ErrorInfo.HasError.get cs:6-6*/
            return !errorMessage.isNullOrEmpty()
        }
    var isWarning: Boolean = false
        private set
    var errorMessage: String? = null
        private set
    constructor(message: String?, isWarningLevel: Boolean = false) { /*@DONE ErrorInfo.<init>/1 cs:9-12*/
        errorMessage = message
        isWarning = isWarningLevel
    }
    fun equals(other: ErrorInfo?): Boolean { /*@DONE ErrorInfo.Equals/1 cs:14-14*/
        return errorMessage == other?.errorMessage && isWarning == other?.isWarning
    }
    override fun equals(obj: Any?): Boolean { /*@DONE ErrorInfo.Equals/2 cs:16-16*/
        return equals(obj as? ErrorInfo)
    }
    override fun hashCode(): Int { /*@DONE ErrorInfo.GetHashCode/1 cs:17-17*/
        return errorMessage?.hashCode() ?: 0
    }
    override fun toString(): String { /*@DONE ErrorInfo.ToString/1 cs:18-18*/
        return errorMessage ?: ""
    }
    companion object {
        var noError: ErrorInfo = /*@INITDONE ErrorInfo.NoError cs:5-5*/ ErrorInfo(null) /*@ENDINIT*/
            private set
        /*@END ErrorInfo.Companion*/
    }
    /*@END ErrorInfo*/
}
