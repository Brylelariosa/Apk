// Port of Core/AutoDictionary.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core

import dev.hexmaniac.core.system.*

open class AutoDictionary<TKey, TValue> : LinkedHashMap<TKey, TValue> { // cs:13-28
    private lateinit var factory: (TKey) -> TValue
    constructor(factory: (TKey) -> TValue) { /*@DONE AutoDictionary.<init>/1 cs:17-17*/
        this.factory = factory
    }
    // skipped indexer this: explicit implementation of an interface that is not mapped (IDictionary<TKey, TValue>)
    override operator fun get(key: TKey): TValue { /*@DONE AutoDictionary.this/2.get cs:25-25*/
        val existing = super.get(key)
        if (existing != null || containsKey(key)) return existing as TValue
        val created = factory(key)
        super.put(key, created)
        return created
    }
    operator fun set(key: TKey, value: TValue) { /*@DONE AutoDictionary.this/2.set cs:26-26*/
        super.put(key, value)
    }
    /*@END AutoDictionary*/
}
