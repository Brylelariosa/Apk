// Port of ViewModels/Tools/FilteringComboOptions.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

open class FilteringComboOptions : ViewModelCore() { // cs:9-146
    private enum class InteractionType(val value: Int) { // cs:10-10
        None(0),
        Text(1),
        DropDown(2),
        Update(3);
        companion object {
            fun fromValue(value: Int): InteractionType = entries.first { it.value == value }
        }
        /*@END FilteringComboOptions.InteractionType*/
    }
    private var interactionType: InteractionType = InteractionType.None
    var allOptions: ObservableCollection<ComboOption>? = null
        private set
    var filteredOptions: ObservableCollection<ComboOption> = /*@INITDONE FilteringComboOptions.FilteredOptions cs:14-14*/ ObservableCollection() /*@ENDINIT*/
        private set
    val canFilter: Boolean
        get() { /*@DONE FilteringComboOptions.CanFilter.get cs:16-16*/
            return allOptions?.all { option -> option.displayAsText } ?: false
        }
    private var _displayText: String = ""
    var displayText: String
        get() { /*@DONE FilteringComboOptions.DisplayText.get cs:21-21*/
            return _displayText
        }
        set(value) { /*@DONE FilteringComboOptions.DisplayText.set cs:22-31*/
            if (interactionType != InteractionType.None) return
            interactionType = InteractionType.Text
            _dropDownIsOpen = true
            _displayText = value
            val everything: List<ComboOption> = allOptions ?: ArrayList<ComboOption>()
            filteredOptions = ObservableCollection(everything.filter { option -> option.text.matchesPartial(_displayText) }.sortedBy { option -> option.text.skipCount(_displayText) })
            _selectedIndex = 0
            notifyPropertiesChanged("filteredOptions", "selectedIndex", "displayText", "dropDownIsOpen", "modelValue")
            interactionType = InteractionType.None
        }
    private var _selectedIndex: Int = 0
    var selectedIndex: Int
        get() { /*@DONE FilteringComboOptions.SelectedIndex.get cs:37-37*/
            return _selectedIndex
        }
        set(value) { /*@DONE FilteringComboOptions.SelectedIndex.set cs:38-49*/
            if (interactionType != InteractionType.None) return
            if (_selectedIndex < 0 || _selectedIndex >= filteredOptions.size) return
            interactionType = InteractionType.DropDown
            _selectedIndex = value
            _dropDownIsOpen = false
            if (!clearFilter()) {
                val everything = allOptions
                if (everything != null && _selectedIndex >= 0 && _selectedIndex < everything.size) _displayText = everything[_selectedIndex].text
                notifyPropertiesChanged("selectedIndex", "displayText", "dropDownIsOpen", "modelValue")
            }
            interactionType = InteractionType.None
        }
    val modelValue: Int
        get() { /*@DONE FilteringComboOptions.ModelValue.get cs:53-56*/
            if (_selectedIndex < 0 || filteredOptions.size <= _selectedIndex) return 0
            return filteredOptions[_selectedIndex].index
        }
    private var _dropDownIsOpen: Boolean = false
    var dropDownIsOpen: Boolean
        get() { /*@DONE FilteringComboOptions.DropDownIsOpen.get cs:62-62*/
            return _dropDownIsOpen
        }
        set(value) { /*@DONE FilteringComboOptions.DropDownIsOpen.set cs:63-73*/
            if (interactionType != InteractionType.None) return
            interactionType = InteractionType.DropDown
            _dropDownIsOpen = value
            if (!value) {
                clearFilter()
            } else {
                notifyPropertyChanged("dropDownIsOpen")
            }
            interactionType = InteractionType.None
        }
    fun update(options: Iterable<ComboOption>, selection: Int) { /*@DONE FilteringComboOptions.Update/1 cs:76-102*/
        if (interactionType != InteractionType.None) return
        interactionType = InteractionType.Update
        var notifyOptions = false

        // warning: this might be a performance sink. It might be faster to replace elements, rather than replacing the full collection.
        val optionList = options.toList()
        var everything = allOptions
        if (everything == null || everything.map { option -> option.text } != optionList.map { option -> option.text }) {
            everything = ObservableCollection(optionList)
            allOptions = everything
            filteredOptions = ObservableCollection(optionList)
            notifyOptions = true
        } else if (_selectedIndex == selection && !_dropDownIsOpen) {
            // no need to notify, nothing changed
            interactionType = InteractionType.None
            return
        }

        _selectedIndex = selection
        if (!_selectedIndex.inRange(0, everything.size)) _selectedIndex = -1
        val notifyDropOpen = !_dropDownIsOpen
        _dropDownIsOpen = false
        _displayText = if (_selectedIndex >= 0) everything[_selectedIndex].text else selection.toString()

        if (notifyOptions) notifyPropertiesChanged("canFilter", "allOptions", "filteredOptions")
        notifyPropertiesChanged("selectedIndex", "displayText", "modelValue")
        if (notifyDropOpen) notifyPropertyChanged("dropDownIsOpen")
        interactionType = InteractionType.None
    }
    fun selectUp() { /*@DONE FilteringComboOptions.SelectUp/1 cs:106-106*/
        selectMove(-1)
    }
    fun selectDown() { /*@DONE FilteringComboOptions.SelectDown/1 cs:108-108*/
        selectMove(1)
    }
    fun selectConfirm() { /*@DONE FilteringComboOptions.SelectConfirm/1 cs:110-117*/
        interactionType = InteractionType.DropDown

        _dropDownIsOpen = false
        clearFilter()

        interactionType = InteractionType.None
    }
    private fun selectMove(direction: Int) { /*@DONE FilteringComboOptions.SelectMove/1 cs:119-133*/
        if (interactionType != InteractionType.None) return
        if (filteredOptions.size == 0) return
        interactionType = InteractionType.DropDown

        _selectedIndex = (_selectedIndex + direction).limitToRange(0, filteredOptions.size - 1)
        notifyPropertyChanged("selectedIndex")
        if (!_dropDownIsOpen) {
            _displayText = filteredOptions[_selectedIndex].text
            notifyPropertyChanged("displayText")
        }
        notifyPropertyChanged("modelValue")

        interactionType = InteractionType.None
    }
    private fun clearFilter(): Boolean { /*@DONE FilteringComboOptions.ClearFilter/1 cs:135-143*/
        val everything = allOptions ?: return false
        var same = filteredOptions.size == everything.size
        if (same) {
            for (i in 0 until everything.size) {
                if (filteredOptions[i] !== everything[i]) { same = false; break }
            }
        }
        if (same) return false
        val selectedOption = if (filteredOptions.size == 0) 0 else filteredOptions[_selectedIndex.limitToRange(0, filteredOptions.size - 1)].index
        filteredOptions = ObservableCollection(everything)
        _selectedIndex = everything.indexOf(everything.first { option -> option.index == selectedOption })
        _displayText = everything[_selectedIndex].text
        notifyPropertiesChanged("filteredOptions", "selectedIndex", "displayText", "dropDownIsOpen", "modelValue")
        return true
    }
    /*@END FilteringComboOptions*/
}
