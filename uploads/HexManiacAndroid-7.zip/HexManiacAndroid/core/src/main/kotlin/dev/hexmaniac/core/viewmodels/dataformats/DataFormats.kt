// Port of ViewModels/DataFormats.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.dataformats

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

interface IDataFormat { // cs:15-17
    fun equals(other: IDataFormat?): Boolean // IEquatable<IDataFormat>.Equals
    fun visit(visitor: IDataFormatVisitor, data: Int)
    /*@END IDataFormat*/
}

interface IDataFormatInstance : IDataFormat { // cs:19-23
    val source: Int
    val position: Int
    val length: Int
    /*@END IDataFormatInstance*/
}

interface IDataFormatStreamInstance : IDataFormat { // cs:25-28
    val source: Int
    val position: Int
    /*@END IDataFormatStreamInstance*/
}

interface IDataFormatVisitor { // cs:30-58
    fun visit(dataFormat: Undefined, data: Int)
    fun visit(dataFormat: None, data: Int)
    fun visit(dataFormat: UnderEdit, data: Int)
    fun visit(pointer: Pointer, data: Int)
    fun visit(anchor: Anchor, data: Int)
    fun visit(decorator: SpriteDecorator, data: Int)
    fun visit(decorator: StreamEndDecorator, data: Int)
    fun visit(pcs: PCS, data: Int)
    fun visit(pcs: EscapedPCS, data: Int)
    fun visit(pcs: ErrorPCS, data: Int)
    fun visit(ascii: Ascii, data: Int)
    fun visit(braille: Braille, data: Int)
    fun visit(integer: Integer, data: Int)
    fun visit(integer: IntegerEnum, data: Int)
    fun visit(integer: IntegerHex, data: Int)
    fun visit(section: EggSection, data: Int)
    fun visit(item: EggItem, data: Int)
    fun visit(item: PlmItem, data: Int)
    fun visit(array: BitArray, data: Int)
    fun visit(word: MatchedWord, data: Int)
    fun visit(stream: EndStream, data: Int)
    fun visit(lz: LzMagicIdentifier, data: Int)
    fun visit(lz: LzGroupHeader, data: Int)
    fun visit(lz: LzCompressed, data: Int)
    fun visit(lz: LzUncompressed, data: Int)
    fun visit(color: UncompressedPaletteColor, data: Int)
    fun visit(tuple: Tuple, data: Int)
    /*@END IDataFormatVisitor*/
}

open class Undefined : IDataFormat { // cs:64-70
    private constructor() { /*@DONE Undefined.<init>/1 cs:66-66*/
        // singleton
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Undefined.Visit/1 cs:68-68*/
        visitor.visit(this, data)
    }
    override fun equals(format: IDataFormat?): Boolean { /*@DONE Undefined.Equals/1 cs:69-69*/
        return format is Undefined
    }
    companion object {
        var instance: Undefined = /*@INITAUTO Undefined.Instance cs:65-65*/ Undefined() /*@ENDINIT*/
            private set
        /*@END Undefined.Companion*/
    }
    /*@END Undefined*/
}

open class None : IDataFormat { // cs:76-86
    var isSearchResult: Boolean = false
        private set
    private constructor() { /*@DONE None.<init>/1 cs:82-82*/
        // singleton
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE None.Visit/1 cs:84-84*/
        visitor.visit(this, data)
    }
    override fun equals(format: IDataFormat?): Boolean { /*@DONE None.Equals/1 cs:85-85*/
        return format is None
    }
    companion object {
        var instance: None = /*@INITDONE None.Instance cs:77-77*/ None().also { it.isSearchResult = false } /*@ENDINIT*/
            private set
        var resultInstance: None = /*@INITDONE None.ResultInstance cs:78-78*/ None().also { it.isSearchResult = true } /*@ENDINIT*/
            private set
        /*@END None.Companion*/
    }
    /*@END None*/
}

open class UnderEdit : IDataFormat { // cs:88-112
    var originalFormat: IDataFormat? = null
        private set
    var currentText: String = ""
        private set
    var editWidth: Int = 0
        private set
    var autocompleteOptions: List<AutoCompleteSelectionItem>? = null
        private set
    constructor(original: IDataFormat?, text: String, editWidth: Int, autocompleteOptions: Iterable<AutoCompleteSelectionItem>?) : this(original, text, editWidth, if (autocompleteOptions != null) LazyList(autocompleteOptions) else null) { /*@DONE UnderEdit.<init>/1 cs:93-94*/
        // delegated to the IReadOnlyList constructor
    }
    constructor(original: IDataFormat?, text: String, editWidth: Int = 1, autocompleteOptions: List<AutoCompleteSelectionItem>? = null) { /*@DONE UnderEdit.<init>/2 cs:95-100*/
        this.originalFormat = original
        this.currentText = text
        this.editWidth = editWidth
        this.autocompleteOptions = autocompleteOptions
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE UnderEdit.Visit/1 cs:102-102*/
        visitor.visit(this, data)
    }
    override fun equals(format: IDataFormat?): Boolean { /*@DONE UnderEdit.Equals/1 cs:103-111*/
        if (format !is UnderEdit) return false
        val that: UnderEdit = format
        val thisOriginal = originalFormat
        if (thisOriginal == null) {
            if (that.originalFormat != null) return false
        } else if (!thisOriginal.equals(that.originalFormat)) {
            return false
        }
        if (editWidth != that.editWidth) return false
        val thisOptions = autocompleteOptions
        val thatOptions = that.autocompleteOptions
        if ((thisOptions != null) != (thatOptions != null)) return false // if only one is null, not equal
        if (thisOptions != null && thatOptions != null) {
            var sequenceEqual = thisOptions.size == thatOptions.size
            var i = 0
            while (sequenceEqual && i < thisOptions.size) {
                if (thisOptions[i] != thatOptions[i]) sequenceEqual = false
                i++
            }
            if (sequenceEqual) return false
        }
        return currentText == that.currentText
    }
    /*@END UnderEdit*/
}

fun IDataFormat.edit(text: String): UnderEdit { /*@DONE UnderEditExtensions.Edit/1 cs:114-122*/
    val format: IDataFormat = this
    if (format is UnderEdit) {
        return UnderEdit(format.originalFormat, format.currentText + text, format.editWidth)
    } else if (format is IDataFormatInstance) {
        return UnderEdit(format, text, format.length)
    }
    return UnderEdit(format, text)
}

object UnderEditExtensions { // cs:113-123
    /*@END UnderEditExtensions*/
}

open class Pointer : IDataFormatInstance { // cs:125-160
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var destination: Int = 0
        private set
    var offsetValue: Int = 0
        private set
    override val length: Int
        get() { /*@DONE Pointer.Length.get cs:131-131*/
            return 4
        }
    var hasError: Boolean = false
        private set
    var destinationName: String = ""
        private set
    val destinationAsText: String
        get() { /*@DONE Pointer.DestinationAsText.get cs:135-142*/
            var destination = destinationName
            if (destination.isEmpty()) destination = this.destination.toHex(6)
            var offset = ""
            if (offsetValue > 0) offset = "+" + offsetValue.toHex(1)
            if (offsetValue < 0) offset = "-" + (-offsetValue).toHex(1)
            return "<" + destination + offset + ">"
        }
    constructor(source: Int, positionInPointer: Int, destination: Int, offset: Int, destinationName: String, hasError: Boolean) { /*@DONE Pointer.<init>/1 cs:145-152*/
        this.source = source
        this.position = positionInPointer
        this.destination = destination
        this.offsetValue = offset
        this.destinationName = destinationName
        this.hasError = hasError
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE Pointer.Equals/1 cs:154-157*/
        if (other !is Pointer) return false
        return other.source == source && other.position == position && other.destination == destination
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Pointer.Visit/1 cs:159-159*/
        visitor.visit(this, data)
    }
    companion object {
        const val null_: Int = -0x08000000
        /*@END Pointer.Companion*/
    }
    /*@END Pointer*/
}

interface IDataFormatDecorator : IDataFormat { // cs:162-164
    val originalFormat: IDataFormat?
    /*@END IDataFormatDecorator*/
}

open class Anchor : IDataFormatDecorator { // cs:166-180
    final override var originalFormat: IDataFormat? = null
        private set
    var name: String = ""
        private set
    var format: String? = null
        private set
    var sources: List<Int> = ArrayList()
        private set
    constructor(original: IDataFormat, name: String, format: String?, sources: List<Int>) { /*@DONE Anchor.<init>/1 cs:172-172*/
        this.originalFormat = original
        this.name = name
        this.format = format
        this.sources = sources
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE Anchor.Equals/1 cs:174-177*/
        if (other !is Anchor) return false
        if (other.name != name || other.format != format) return false
        if (other.sources.size != sources.size) return false
        for (i in 0 until sources.size) {
            if (other.sources[i] != sources[i]) return false
        }
        return other.originalFormat?.equals(originalFormat) == true
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Anchor.Visit/1 cs:179-179*/
        visitor.visit(this, data)
    }
    /*@END Anchor*/
}

open class SpriteDecorator : IDataFormatDecorator { // cs:182-244
    final override var originalFormat: IDataFormat? = null
        private set
    lateinit var pixels: IPixelViewModel
        private set
    var cellWidth: Int = 0
        private set
    var cellHeight: Int = 0
        private set
    constructor(inner: IDataFormat, pixels: IPixelViewModel?, cellWidth: Int = 1, cellHeight: Int = 1) { /*@DONE SpriteDecorator.<init>/1 cs:188-192*/
        this.originalFormat = inner
        this.pixels = pixels ?: ReadonlyPixelViewModel(SpriteFormat(4, cellWidth, cellHeight, ""), ShortArray(0))
        this.cellWidth = cellWidth
        this.cellHeight = cellHeight
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE SpriteDecorator.Equals/1 cs:238-241*/
        if (other !is SpriteDecorator) return false
        return other.originalFormat?.equals(originalFormat) == true && other.cellWidth == cellWidth && other.cellHeight == cellHeight
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE SpriteDecorator.Visit/1 cs:243-243*/
        visitor.visit(this, data)
    }
    companion object {
        fun buildSprite(model: IDataModel, run: BlockmapRun): IPixelViewModel? { /*@DONE SpriteDecorator.BuildSprite/1 cs:194-211*/
            if (!dev.hexmaniac.core.viewmodels.IDataModelExtensions.editorReleased) return null
            val sources = run.pointerSources
            if (sources == null || sources.size == 0) return null
            val primarySource = sources[0]
            val address1 = model.readPointer(primarySource + 4)
            val address2 = model.readPointer(primarySource + 8)
            if (address1 < 0 || address2 < 0) return null
            val blocks1 = BlocksetModel(model, address1)
            val blocks2 = BlocksetModel(model, address2)
            val primaryMax = BlockmapRun.getMaxUsedBlock(model, run.start, run.blockWidth, run.blockHeight, run.primaryBlocks)
            val secondaryMax = BlockmapRun.getMaxUsedBlock(model, run.start, run.blockWidth, run.blockHeight, 1024) - run.primaryBlocks
            val blocks = BlockmapRun.readBlocks(primaryMax, secondaryMax, blocks1, blocks2)
            val blockAttributes = BlockmapRun.readBlockAttributes(primaryMax, secondaryMax, blocks1, blocks2)
            val tiles = BlockmapRun.readTiles(blocks1, blocks2, run.primaryTiles)
            val pals = BlockmapRun.readPalettes(blocks1, blocks2, run.primaryPalettes)
            if (tiles == null || pals == null) return null
            val palettes: Array<List<Short>> = Array(pals.size) { i -> pals[i].toList() }
            val renders = BlockmapRun.calculateBlockRenders(blocks, blockAttributes, tiles, palettes).toList()
            return BlockmapRun.renderMap(model, run.start, run.blockWidth, run.blockHeight, renders)
        }
        fun buildSprite(model: IDataModel, sprite: ISpriteRun?, useTransparency: Boolean = false, scale: Double = 1.0): ReadonlyPixelViewModel? { /*@DONE SpriteDecorator.BuildSprite/2 cs:213-219*/
            if (sprite == null) return null
            if (sprite is ITilemapRun) sprite.findMatchingTileset(model)
            val paletteRuns = sprite.findRelatedPalettes(model)
            val paletteRun = paletteRuns.firstOrNull()
            return buildSprite(model, sprite, paletteRun, useTransparency, scale)
        }
        fun buildSprite(model: IDataModel, sprite: ISpriteRun?, tableElementAddress: Int, useTransparency: Boolean = false, scale: Double = 1.0): ReadonlyPixelViewModel? { /*@DONE SpriteDecorator.BuildSprite/3 cs:221-227*/
            if (sprite == null) return null
            if (sprite is ITilemapRun) sprite.findMatchingTileset(model)
            val paletteRuns = sprite.findRelatedPalettes(model, tableElementAddress)
            val paletteRun = paletteRuns.firstOrNull()
            return buildSprite(model, sprite, paletteRun, useTransparency, scale)
        }
        fun buildSprite(model: IDataModel, sprite: ISpriteRun, paletteRun: IPaletteRun?, useTransparency: Boolean = false, scale: Double = 1.0): ReadonlyPixelViewModel? { /*@DONE SpriteDecorator.BuildSprite/4 cs:229-236*/
            val pixels = sprite.getPixels(model, 0, -1)
            if (pixels == null) return null
            var colors: List<Short> = paletteRun?.allColors(model) ?: TileViewModel.createDefaultPalette(Math.pow(2.0, sprite.spriteFormat.bitsPerPixel.toDouble()).toInt()).toList()
            if (colors.size == 16 && useTransparency) colors = SpriteTool.createPaletteWithUniqueTransparentColor(colors)
            val imageData = SpriteTool.render(pixels, colors, paletteRun?.paletteFormat?.initialBlankPages ?: 0, 0)
            val result = ReadonlyPixelViewModel(sprite.spriteFormat, imageData, if (useTransparency) colors[0] else (-1).toShort())
            result.spriteScale = scale
            return result
        }
        /*@END SpriteDecorator.Companion*/
    }
    /*@END SpriteDecorator*/
}

open class StreamEndDecorator : IDataFormatDecorator { // cs:250-258
    final override var originalFormat: IDataFormat? = null
        private set
    constructor(inner: IDataFormat) { /*@DONE StreamEndDecorator.<init>/1 cs:252-252*/
        this.originalFormat = inner
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE StreamEndDecorator.Equals/1 cs:253-256*/
        if (other !is StreamEndDecorator) return false
        return other.originalFormat?.equals(originalFormat) == true
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE StreamEndDecorator.Visit/1 cs:257-257*/
        visitor.visit(this, data)
    }
    /*@END StreamEndDecorator*/
}

open class PCS : IDataFormatStreamInstance { // cs:260-274
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var fullString: String = ""
        private set
    var thisCharacter: String = ""
        private set
    constructor(source: Int, position: Int, full: String, character: String) { /*@DONE PCS.<init>/1 cs:266-266*/
        this.source = source
        this.position = position
        this.fullString = full
        this.thisCharacter = character
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE PCS.Equals/1 cs:268-271*/
        if (other !is PCS) return false
        return other.source == source && other.position == position && other.fullString == fullString && other.thisCharacter == thisCharacter
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE PCS.Visit/1 cs:273-273*/
        visitor.visit(this, data)
    }
    /*@END PCS*/
}

open class EscapedPCS : IDataFormatStreamInstance { // cs:276-290
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var fullString: String = ""
        private set
    var thisValue: Int = 0
        private set
    constructor(source: Int, position: Int, full: String, value: Int) { /*@DONE EscapedPCS.<init>/1 cs:282-282*/
        this.source = source
        this.position = position
        this.fullString = full
        this.thisValue = value
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE EscapedPCS.Equals/1 cs:284-287*/
        if (other !is EscapedPCS) return false
        return other.source == source && other.position == position && other.fullString == fullString && other.thisValue == thisValue
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE EscapedPCS.Visit/1 cs:289-289*/
        visitor.visit(this, data)
    }
    /*@END EscapedPCS*/
}

open class ErrorPCS : IDataFormatStreamInstance { // cs:292-306
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var fullString: String = ""
        private set
    var thisValue: Int = 0
        private set
    constructor(source: Int, position: Int, full: String, value: Int) { /*@DONE ErrorPCS.<init>/1 cs:298-298*/
        this.source = source
        this.position = position
        this.fullString = full
        this.thisValue = value
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE ErrorPCS.Equals/1 cs:300-303*/
        if (other !is EscapedPCS) return false
        return other.source == source && other.position == position && other.fullString == fullString && other.thisValue == thisValue
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE ErrorPCS.Visit/1 cs:305-305*/
        visitor.visit(this, data)
    }
    /*@END ErrorPCS*/
}

open class Ascii : IDataFormatStreamInstance { // cs:308-321
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var thisCharacter: String = ""
        private set
    constructor(source: Int, position: Int, value: String) { /*@DONE Ascii.<init>/1 cs:313-313*/
        this.source = source
        this.position = position
        this.thisCharacter = value
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE Ascii.Equals/1 cs:315-318*/
        if (other !is Ascii) return false
        return other.source == source && other.position == position && other.thisCharacter == thisCharacter
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Ascii.Visit/1 cs:320-320*/
        visitor.visit(this, data)
    }
    /*@END Ascii*/
}

open class Braille : IDataFormatStreamInstance { // cs:323-336
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var thisCharacter: Char = '\u0000'
        private set
    constructor(source: Int, position: Int, value: Char) { /*@DONE Braille.<init>/1 cs:328-328*/
        this.source = source
        this.position = position
        this.thisCharacter = value
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE Braille.Equals/1 cs:330-333*/
        if (other !is Braille) return false
        return other.source == source && other.position == position && other.thisCharacter == thisCharacter
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Braille.Visit/1 cs:335-335*/
        visitor.visit(this, data)
    }
    /*@END Braille*/
}

open class Integer : IDataFormatInstance { // cs:338-357
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var value: Int = 0
        private set
    final override var length: Int = 0
        private set
    var isUnused: Boolean = false
    constructor(source: Int, position: Int, value: Int, length: Int) { /*@DONE Integer.<init>/1 cs:345-345*/
        this.source = source
        this.position = position
        this.value = value
        this.length = length
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE Integer.Equals/1 cs:347-350*/
        if (other !is Integer) return false
        return source == other.source && position == other.position && value == other.value && length == other.length
    }
    open fun canStartWithCharacter(input: Char): Boolean { /*@DONE Integer.CanStartWithCharacter/1 cs:352-354*/
        return input.isDigit() || input == '-'
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Integer.Visit/1 cs:356-356*/
        visitor.visit(this, data)
    }
    /*@END Integer*/
}

open class IntegerEnum : Integer { // cs:359-388
    var valueNew: String = ""
        private set
    val displayValue: String
        get() { /*@DONE IntegerEnum.DisplayValue.get cs:362-371*/
            var value = valueNew
            if (!value.contains("_")) return value
            var display = value.substring(0, 1)
            while (value.contains("_")) {
                value = value.substring(value.indexOf("_") + 1)
                if (value.length > 0) display += value.substring(0, 1)
            }
            return display
        }
    constructor(source: Int, position: Int, value: String, length: Int) : super(source, position, -1, length) { /*@DONE IntegerEnum.<init>/1 cs:374-374*/
        this.valueNew = value
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE IntegerEnum.Equals/1 cs:376-379*/
        if (other !is IntegerEnum) return false
        return valueNew == other.valueNew && super.equals(other as IDataFormat?)
    }
    override fun canStartWithCharacter(input: Char): Boolean { /*@DONE IntegerEnum.CanStartWithCharacter/1 cs:381-385*/
        return input.isLetterOrDigit() || input == PCSRun.stringDelimeter || "?-".contains(input)
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE IntegerEnum.Visit/1 cs:387-387*/
        visitor.visit(this, data)
    }
    /*@END IntegerEnum*/
}

open class IntegerHex : Integer { // cs:390-406
    constructor(source: Int, position: Int, value: Int, length: Int) : super(source, position, value, length) { /*@DONE IntegerHex.<init>/1 cs:391-391*/
        // the base constructor does all the work
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE IntegerHex.Equals/1 cs:393-396*/
        if (other !is IntegerHex) return false
        return super.equals(other as IDataFormat?)
    }
    override fun canStartWithCharacter(input: Char): Boolean { /*@DONE IntegerHex.CanStartWithCharacter/1 cs:398-398*/
        return ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE IntegerHex.Visit/1 cs:400-400*/
        visitor.visit(this, data)
    }
    override fun toString(): String { /*@DONE IntegerHex.ToString/1 cs:402-405*/
        return value.toHex(length * 2)
    }
    /*@END IntegerHex*/
}

open class Tuple : IDataFormatInstance { // cs:408-429
    private lateinit var dataModel: IDataModel
    var model: ArrayRunTupleSegment? = null
        private set
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    final override var length: Int = 0
        private set
    constructor(dataModel: IDataModel, model: ArrayRunTupleSegment, source: Int, position: Int) { /*@DONE Tuple.<init>/1 cs:419-422*/
        this.dataModel = dataModel
        this.model = model
        this.source = source
        this.position = position
        this.length = model.length
    }
    override fun toString(): String { /*@DONE Tuple.ToString/1 cs:424-424*/
        return model!!.toText(dataModel, source) ?: ""
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE Tuple.Equals/1 cs:426-426*/
        return toString() == other?.toString()
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE Tuple.Visit/1 cs:428-428*/
        visitor.visit(this, data)
    }
    /*@END Tuple*/
}

open class EggSection : IDataFormatInstance { // cs:431-449
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    override val length: Int
        get() { /*@DONE EggSection.Length.get cs:434-434*/
            return 2
        }
    var sectionName: String = ""
        private set
    constructor(source: Int, position: Int, name: String) { /*@DONE EggSection.<init>/1 cs:437-437*/
        this.source = source
        this.position = position
        this.sectionName = name
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE EggSection.Equals/1 cs:439-446*/
        if (other is EggSection) {
            return other.sectionName == sectionName && other.source == source && other.length == length
        }
        return false
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE EggSection.Visit/1 cs:448-448*/
        visitor.visit(this, data)
    }
    /*@END EggSection*/
}

open class EggItem : IDataFormatInstance { // cs:451-467
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var itemName: String = ""
        private set
    override val length: Int
        get() { /*@DONE EggItem.Length.get cs:455-455*/
            return 2
        }
    constructor(source: Int, position: Int, name: String) { /*@DONE EggItem.<init>/1 cs:457-457*/
        this.source = source
        this.position = position
        this.itemName = name
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE EggItem.Equals/1 cs:459-464*/
        if (other is EggItem) {
            return other.itemName == itemName && other.source == source
        }
        return false
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE EggItem.Visit/1 cs:466-466*/
        visitor.visit(this, data)
    }
    /*@END EggItem*/
}

open class PlmItem : IDataFormatInstance { // cs:469-486
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    override val length: Int
        get() { /*@DONE PlmItem.Length.get cs:472-472*/
            return 2
        }
    var level: Int = 0
        private set
    var move: Int = 0
        private set
    var moveName: String = ""
        private set
    override fun toString(): String { /*@DONE PlmItem.ToString/1 cs:476-476*/
        return if (level == 0x7F && move == 0x1FF) EggMoveRun.groupStart + "" + EggMoveRun.groupEnd else "$level $moveName"
    }
    constructor(source: Int, position: Int, level: Int, move: Int, moveName: String) { /*@DONE PlmItem.<init>/1 cs:478-481*/
        this.source = source
        this.position = position
        this.level = level
        this.move = move
        this.moveName = moveName
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE PlmItem.Equals/1 cs:483-483*/
        return toString() == other?.toString()
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE PlmItem.Visit/1 cs:485-485*/
        visitor.visit(this, data)
    }
    /*@END PlmItem*/
}

open class BitArray : IDataFormatInstance { // cs:488-506
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    final override var length: Int = 0
        private set
    var displayValue: String = ""
        private set
    constructor(source: Int, position: Int, length: Int, displayValue: String) { /*@DONE BitArray.<init>/1 cs:496-496*/
        this.source = source
        this.position = position
        this.length = length
        this.displayValue = displayValue
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE BitArray.Equals/1 cs:498-501*/
        if (other !is BitArray) return false
        return source == other.source && position == other.position
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE BitArray.Visit/1 cs:503-505*/
        visitor.visit(this, data)
    }
    companion object {
        val sharedFormatString: String = /*@INITAUTO BitArray.SharedFormatString cs:489-489*/ "|b[]" /*@ENDINIT*/
        /*@END BitArray.Companion*/
    }
    /*@END BitArray*/
}

open class MatchedWord : IDataFormatInstance { // cs:508-524
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    var name: String = ""
        private set
    override val length: Int
        get() { /*@DONE MatchedWord.Length.get cs:512-512*/
            return 4
        }
    constructor(source: Int, position: Int, name: String) { /*@DONE MatchedWord.<init>/1 cs:514-514*/
        this.source = source
        this.position = position
        this.name = name
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE MatchedWord.Equals/1 cs:516-519*/
        if (other !is MatchedWord) return false
        return source == other.source && position == other.position
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE MatchedWord.Visit/1 cs:521-523*/
        visitor.visit(this, data)
    }
    /*@END MatchedWord*/
}

open class EndStream : IDataFormatInstance { // cs:526-539
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    final override var length: Int = 0
        private set
    constructor(source: Int, position: Int, length: Int) { /*@DONE EndStream.<init>/1 cs:531-531*/
        this.source = source
        this.position = position
        this.length = length
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE EndStream.Equals/1 cs:533-536*/
        if (other !is EndStream) return false
        return source == other.source && position == other.position && length == other.length
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE EndStream.Visit/1 cs:538-538*/
        visitor.visit(this, data)
    }
    /*@END EndStream*/
}

open class LzMagicIdentifier : IDataFormatInstance { // cs:541-548
    final override var source: Int = 0
        private set
    override val position: Int
        get() { /*@DONE LzMagicIdentifier.Position.get cs:543-543*/
            return 0
        }
    override val length: Int
        get() { /*@DONE LzMagicIdentifier.Length.get cs:544-544*/
            return 1
        }
    constructor(source: Int) { /*@DONE LzMagicIdentifier.<init>/1 cs:545-545*/
        this.source = source
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE LzMagicIdentifier.Equals/1 cs:546-546*/
        return other is LzMagicIdentifier
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE LzMagicIdentifier.Visit/1 cs:547-547*/
        visitor.visit(this, data)
    }
    /*@END LzMagicIdentifier*/
}

open class LzGroupHeader : IDataFormatInstance { // cs:550-557
    final override var source: Int = 0
        private set
    override val position: Int
        get() { /*@DONE LzGroupHeader.Position.get cs:552-552*/
            return 0
        }
    override val length: Int
        get() { /*@DONE LzGroupHeader.Length.get cs:553-553*/
            return 1
        }
    constructor(source: Int) { /*@DONE LzGroupHeader.<init>/1 cs:554-554*/
        this.source = source
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE LzGroupHeader.Equals/1 cs:555-555*/
        return other is LzMagicIdentifier
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE LzGroupHeader.Visit/1 cs:556-556*/
        visitor.visit(this, data)
    }
    /*@END LzGroupHeader*/
}

open class LzUncompressed : IDataFormatInstance { // cs:559-566
    final override var source: Int = 0
        private set
    override val position: Int
        get() { /*@DONE LzUncompressed.Position.get cs:561-561*/
            return 0
        }
    override val length: Int
        get() { /*@DONE LzUncompressed.Length.get cs:562-562*/
            return 1
        }
    constructor(source: Int) { /*@DONE LzUncompressed.<init>/1 cs:563-563*/
        this.source = source
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE LzUncompressed.Equals/1 cs:564-564*/
        return other is LzMagicIdentifier
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE LzUncompressed.Visit/1 cs:565-565*/
        visitor.visit(this, data)
    }
    /*@END LzUncompressed*/
}

open class LzCompressed : IDataFormatInstance { // cs:568-583
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    override val length: Int
        get() { /*@DONE LzCompressed.Length.get cs:571-571*/
            return 2
        }
    var runLength: Int = 0
        private set
    var runOffset: Int = 0
        private set
    constructor(source: Int, position: Int, runLength: Int, runOffset: Int) { /*@DONE LzCompressed.<init>/1 cs:575-575*/
        this.source = source
        this.position = position
        this.runLength = runLength
        this.runOffset = runOffset
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE LzCompressed.Equals/1 cs:577-580*/
        if (other !is LzCompressed) return false
        return source == other.source && position == other.position && runLength == other.runLength && runOffset == other.runOffset
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE LzCompressed.Visit/1 cs:582-582*/
        visitor.visit(this, data)
    }
    /*@END LzCompressed*/
}

open class UncompressedPaletteColor : IDataFormatInstance { // cs:585-624
    final override var source: Int = 0
        private set
    final override var position: Int = 0
        private set
    override val length: Int
        get() { /*@DONE UncompressedPaletteColor.Length.get cs:588-588*/
            return 2
        }
    var color: Short = 0.toShort()
        private set
    var r: Int = 0
        private set
    var g: Int = 0
        private set
    var b: Int = 0
        private set
    constructor(source: Int, position: Int, color: Short) { /*@DONE UncompressedPaletteColor.<init>/1 cs:595-598*/
        this.source = source
        this.position = position
        this.color = color
        val rgb = toRGB(color)
        this.r = rgb.r
        this.g = rgb.g
        this.b = rgb.b
    }
    override fun equals(other: IDataFormat?): Boolean { /*@DONE UncompressedPaletteColor.Equals/1 cs:616-619*/
        if (other !is UncompressedPaletteColor) return false
        return source == other.source && position == other.position && color == other.color
    }
    override fun visit(visitor: IDataFormatVisitor, data: Int) { /*@DONE UncompressedPaletteColor.Visit/1 cs:621-621*/
        visitor.visit(this, data)
    }
    override fun toString(): String { /*@DONE UncompressedPaletteColor.ToString/1 cs:623-623*/
        return convert(color) ?: ""
    }
    companion object {
        fun convert(color: Short): String? { /*@DONE UncompressedPaletteColor.Convert/1 cs:600-603*/
            val rgb = toRGB(color)
            return "" + rgb.r + ":" + rgb.g + ":" + rgb.b
        }
        fun toRGB(color: Short): UncompressedPaletteColorToRGBTuple { /*@DONE UncompressedPaletteColor.ToRGB/1 cs:605-610*/
            val r = (color.toInt() shr 10) and 0x1F
            val g = (color.toInt() shr 5) and 0x1F
            val b = (color.toInt() shr 0) and 0x1F
            return UncompressedPaletteColorToRGBTuple(r, g, b)
        }
        fun pack(red: Int, green: Int, blue: Int): Short { /*@DONE UncompressedPaletteColor.Pack/1 cs:612-614*/
            return ((red shl 10) or (green shl 5) or blue).toShort()
        }
        /*@END UncompressedPaletteColor.Companion*/
    }
    /*@END UncompressedPaletteColor*/
}

data class UncompressedPaletteColorToRGBTuple(val r: Int, val g: Int, val b: Int)
