// Port of ViewModels/Tools/PaletteElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class PaletteElementViewModel : PagedElementViewModel { // cs:7-76
    private var format: PaletteFormat = PaletteFormat()
    var tableName: String = ""
        private set
    lateinit var colors: PaletteCollection
        private set
    constructor(viewPort: ViewPort, history: ChangeHistory<ModelDelta>, parentName: String, runFormat: String, format: PaletteFormat, itemAddress: Int) : super(viewPort, parentName, runFormat, itemAddress) { /*@DONE PaletteElementViewModel.<init>/1 cs:14-27*/
        this.format = format

        val table = viewPort.model.getNextRun(itemAddress) as ITableRun
        colors = PaletteCollection(viewPort, viewPort.model, history)
        addSilentChild(colors)
        colors.requestPageSet += { sender, page -> handleColorsPageSet(sender, page) }
        colors.paletteRepointed += { sender, address -> handlePaletteRepoint(sender, address) }
        tableName = viewPort.model.getAnchorFromAddress(-1, table.start)
        val destination = model.readPointer(start)
        val paletteRun = viewPort.model.getNextRun(destination) as? IPaletteRun
        pages = paletteRun?.pages ?: 0
        updateColors(start, 0)
    }
    protected override fun tryCopy(other: PagedElementViewModel): Boolean { /*@DONE PaletteElementViewModel.TryCopy/1 cs:34-39*/
        val that = other as? PaletteElementViewModel ?: return false
        format = that.format
        updateColors(other.start, other.currentPage)
        return true
    }
    protected override fun pageChanged() { /*@DONE PaletteElementViewModel.PageChanged/1 cs:41-41*/
        updateColors(start, currentPage)
    }
    fun activate() { /*@DONE PaletteElementViewModel.Activate/1 cs:43-43*/
        // nothing to do
    }
    protected override fun canExecuteAddPage(): Boolean { /*@DONE PaletteElementViewModel.CanExecuteAddPage/1 cs:45-49*/
        val destination = viewPort.model.readPointer(start)
        val run = viewPort.model.getNextRun(destination) as? IPaletteRun
        return run is LzPaletteRun && currentPage == run.pages - 1 && run.findDependentSprites(model).all { sprite -> sprite.pages == run.pages && sprite is LzSpriteRun }
    }
    protected override fun canExecuteDeletePage(): Boolean { /*@DONE PaletteElementViewModel.CanExecuteDeletePage/1 cs:51-55*/
        val destination = viewPort.model.readPointer(start)
        val run = viewPort.model.getNextRun(destination) as? IPaletteRun
        return run is LzPaletteRun && pages > 1 && run.findDependentSprites(model).all { sprite -> sprite.pages == run.pages && sprite is LzSpriteRun }
    }
    private fun updateColors(start: Int, page: Int) { /*@DONE PaletteElementViewModel.UpdateColors/1 cs:57-65*/
        val destination = model.readPointer(start)
        val run = viewPort.model.getNextRun(destination) as? IPaletteRun
        colors.sourcePalettePointer = start
        val palette = run?.getPalette(model, page) ?: TileViewModel.createDefaultPalette(16).toList()
        colors.setContents(palette)
        colors.page = page
        colors.hasMultiplePages = pages > 1
    }
    private fun handleColorsPageSet(sender: Any?, page: Int) { /*@DONE PaletteElementViewModel.HandleColorsPageSet/1 cs:67-73*/
        for (child in viewPort.tools!!.tableTool!!.children) {
            if (child !is IPagedViewModel) continue
            if (child.pages != pages) continue
            child.currentPage = page
        }
    }
    private fun handlePaletteRepoint(sender: Any?, address: Int) { /*@DONE PaletteElementViewModel.HandlePaletteRepoint/1 cs:75-75*/
        viewPort.raiseMessage("Palette moved to " + address.toHex(6) + ". Pointers were updated.")
    }
    /*@END PaletteElementViewModel*/
}
