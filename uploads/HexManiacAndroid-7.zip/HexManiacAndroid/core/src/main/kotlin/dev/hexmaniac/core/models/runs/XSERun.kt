// Port of Models/Runs/XSERun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.dataformats.*

interface IScriptStartRun : IFormattedRun { // cs:4-4
    /*@END IScriptStartRun*/
}

open class XSERun : BaseRun, IScriptStartRun { // cs:6-18
    override val length: Int
        get() { /*@DONE XSERun.Length.get cs:9-9*/
            return 1
        }
    override val formatString: String
        get() { /*@DONE XSERun.FormatString.get cs:11-11*/
            return sharedFormatString
        }
    constructor(start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE XSERun.<init>/1 cs:13-13*/
        // the base constructor does all the work
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE XSERun.CreateDataFormat/1 cs:15-15*/
        return None.instance
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE XSERun.Clone/1 cs:17-17*/
        return XSERun(start, newPointerSources)
    }
    companion object {
        val sharedFormatString: String
            get() { /*@DONE XSERun.SharedFormatString.get cs:7-7*/
                return "`xse`"
            }
        /*@END XSERun.Companion*/
    }
    /*@END XSERun*/
}

open class BSERun : BaseRun, IScriptStartRun { // cs:20-32
    override val length: Int
        get() { /*@DONE BSERun.Length.get cs:23-23*/
            return 1
        }
    override val formatString: String
        get() { /*@DONE BSERun.FormatString.get cs:25-25*/
            return sharedFormatString
        }
    constructor(start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE BSERun.<init>/1 cs:27-27*/
        // the base constructor does all the work
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE BSERun.CreateDataFormat/1 cs:29-29*/
        return None.instance
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE BSERun.Clone/1 cs:31-31*/
        return BSERun(start, newPointerSources)
    }
    companion object {
        val sharedFormatString: String
            get() { /*@DONE BSERun.SharedFormatString.get cs:21-21*/
                return "`bse`"
            }
        /*@END BSERun.Companion*/
    }
    /*@END BSERun*/
}

open class ASERun : BaseRun, IScriptStartRun { // cs:34-46
    override val length: Int
        get() { /*@DONE ASERun.Length.get cs:37-37*/
            return 1
        }
    override val formatString: String
        get() { /*@DONE ASERun.FormatString.get cs:39-39*/
            return sharedFormatString
        }
    constructor(start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE ASERun.<init>/1 cs:41-41*/
        // the base constructor does all the work
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE ASERun.CreateDataFormat/1 cs:43-43*/
        return None.instance
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE ASERun.Clone/1 cs:45-45*/
        return ASERun(start, newPointerSources)
    }
    companion object {
        val sharedFormatString: String
            get() { /*@DONE ASERun.SharedFormatString.get cs:35-35*/
                return "`ase`"
            }
        /*@END ASERun.Companion*/
    }
    /*@END ASERun*/
}

open class TSERun : BaseRun, IScriptStartRun { // cs:48-60
    override val length: Int
        get() { /*@DONE TSERun.Length.get cs:51-51*/
            return 1
        }
    override val formatString: String
        get() { /*@DONE TSERun.FormatString.get cs:53-53*/
            return sharedFormatString
        }
    constructor(start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE TSERun.<init>/1 cs:55-55*/
        // the base constructor does all the work
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE TSERun.CreateDataFormat/1 cs:57-57*/
        return None.instance
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE TSERun.Clone/1 cs:59-59*/
        return TSERun(start, newPointerSources)
    }
    companion object {
        val sharedFormatString: String
            get() { /*@DONE TSERun.SharedFormatString.get cs:49-49*/
                return "`tse`"
            }
        /*@END TSERun.Companion*/
    }
    /*@END TSERun*/
}
