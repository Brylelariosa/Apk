// Port of Models/Runs/Sprites/BlockmapRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.tools.*

open class BlockmapRun : BaseRun, IUpdateFromParentRun, IAppendToBuilderRun { // cs:25-335
    private lateinit var model: IDataModel
    var blockWidth: Int = 0
        private set
    var blockHeight: Int = 0
        private set
    var primaryBlocks: Int = 0
        private set
    var primaryTiles: Int = 0
        private set
    var primaryPalettes: Int = 0
        private set
    override val length: Int
        get() { /*@DONE BlockmapRun.Length.get cs:38-38*/
            return blockWidth * blockHeight * 2
        }
    override val formatString: String
        get() { /*@DONE BlockmapRun.FormatString.get cs:41-41*/
            return sharedFormatString
        }
    override val repointContentShortName: String
        get() { /*@DONE BlockmapRun.RepointContentShortName.get cs:43-43*/
            return "Blocks"
        }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>?, width: Int = -1, height: Int = -1) : super(start, sources) { /*@DONE BlockmapRun.<init>/1 cs:45-65*/
        this.model = model
        var mapWidth = width
        var mapHeight = height
        if (sources != null && sources.size > 0) {
            val primarySource = sources[0]
            val layoutStart = primarySource - 12
            if (mapWidth == -1) mapWidth = model.readValue(layoutStart)
            if (mapHeight == -1) mapHeight = model.readValue(layoutStart + 4)
        }
        blockWidth = mapWidth
        blockHeight = mapHeight
        val code = model.getGameCode()

        if (code.contains("BPR") || code.contains("BPG")) {
            primaryBlocks = 640
            primaryTiles = 640
            primaryPalettes = 7
        } else {
            primaryBlocks = 512
            primaryTiles = 512
            primaryPalettes = 6
        }
    }
    private var lastFormatRequested: Int = /*@INITDONE BlockmapRun.lastFormatRequested cs:171-171*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE BlockmapRun.CreateDataFormat/1 cs:172-190*/
        val basicFormat: IDataFormat
        if (index % 2 == 0) {
            basicFormat = IntegerHex(index, 0, data.readMultiByteValue(index, 2), 2)
        } else {
            basicFormat = IntegerHex(index - 1, 1, data.readMultiByteValue(index - 1, 2), 2)
        }
        if (!createForLeftEdge) return basicFormat
        if (lastFormatRequested < index) {
            lastFormatRequested = index
            return basicFormat
        }

        val sprite = data.currentCacheScope.getImage(this)
        val availableRows = (length - (index - start)) / expectedDisplayWidth
        lastFormatRequested = index
        return SpriteDecorator(basicFormat, sprite, expectedDisplayWidth, availableRows)
    }
    private var backupX: Int = /*@INITAUTO BlockmapRun.backupX cs:192-192*/ 0 /*@ENDINIT*/
    private var backupY: Int = /*@INITAUTO BlockmapRun.backupY cs:192-192*/ 0 /*@ENDINIT*/
    private var backupContent: Array<IntArray>? = null
    fun storeContentBackupForSizeChange() { /*@DONE BlockmapRun.StoreContentBackupForSizeChange/1 cs:194-202*/
        val backup = Array(blockWidth) { IntArray(blockHeight) }
        for (y in 0 until blockHeight) {
            for (x in 0 until blockWidth) {
                backup[x][y] = model.readMultiByteValue(start + (y * blockWidth + x) * 2, 2)
            }
        }
        backupContent = backup
        backupX = 0
        backupY = 0
    }
    fun tryChangeSize(tokenFactory: () -> ModelDelta, direction: MapDirection, amount: Int, borderWidth: Int, borderHeight: Int): BlockmapRun? { /*@DONE BlockmapRun.TryChangeSize/1 cs:204-215*/
        if (amount == 0) return null

        var leftAmount = 0
        var upAmount = 0
        var rightAmount = 0
        var downAmount = 0
        if (direction == MapDirection.Left) leftAmount = amount
        if (direction == MapDirection.Right) rightAmount = amount
        if (direction == MapDirection.Up) upAmount = amount
        if (direction == MapDirection.Down) downAmount = amount
        val result = tryChangeSize(tokenFactory, leftAmount, upAmount, rightAmount, downAmount, borderWidth, borderHeight)
        if (result === this) return null
        return result
    }
    private fun tryChangeSize(tokenFactory: () -> ModelDelta, leftAmount: Int, upAmount: Int, rightAmount: Int, downAmount: Int, borderWidth: Int, borderHeight: Int): BlockmapRun { /*@DONE BlockmapRun.TryChangeSize/2 cs:217-307*/
        if (backupContent == null) storeContentBackupForSizeChange()
        val backup = backupContent!!
        val newWidth = blockWidth + leftAmount + rightAmount
        val newHeight = blockHeight + upAmount + downAmount
        backupX -= leftAmount
        backupY -= upAmount

        // validate that the new width/height combo is reasonable
        if (newWidth * newHeight > blockWidth * blockHeight && !BlockMapViewModel.isMapWithinSizeLimit(newWidth, newHeight)) return this
        if (minOf(minOf(leftAmount, upAmount), minOf(rightAmount, downAmount)) < 0 && (newWidth < 4 || newHeight < 4)) return this

        val data = Array(blockWidth) { IntArray(blockHeight) }
        for (y in 0 until blockHeight) {
            for (x in 0 until blockWidth) {
                data[x][y] = model.readMultiByteValue(start + (y * blockWidth + x) * 2, 2)
            }
        }

        // copy data into new array
        val xOffset = leftAmount
        val yOffset = upAmount
        val newData = Array(newWidth) { IntArray(newHeight) }
        for (y in 0 until blockHeight) {
            if (y + yOffset < 0) continue
            if (y + yOffset >= newHeight) continue
            for (x in 0 until blockWidth) {
                if (x + xOffset < 0) continue
                if (x + xOffset >= newWidth) continue
                newData[x + xOffset][y + yOffset] = data[x][y]
            }
        }

        // fill new rows/columns
        val bWidth = backup.size
        val bHeight = if (backup.isEmpty()) 0 else backup[0].size
        for (y in yOffset - 1 downTo 0) {
            for (x in 0 until newWidth) {
                if ((x + backupX).inRange(0, bWidth) && (y + backupY).inRange(0, bHeight)) newData[x][y] = backup[x + backupX][y + backupY]
                else if (y + borderHeight < newHeight) newData[x][y] = newData[x][y + borderHeight]
                else newData[x][y] = newData[x][y + 1]
            }
        }
        if (yOffset == 0) {
            for (y in blockHeight until newHeight) {
                for (x in 0 until newWidth) {
                    if ((x + backupX).inRange(0, bWidth) && (y + backupY).inRange(0, bHeight)) newData[x][y] = backup[x + backupX][y + backupY]
                    else if (y - borderHeight >= 0) newData[x][y] = newData[x][y - borderHeight]
                    else newData[x][y] = newData[x][y - 1]
                }
            }
        }
        for (x in xOffset - 1 downTo 0) {
            for (y in 0 until newHeight) {
                if ((x + backupX).inRange(0, bWidth) && (y + backupY).inRange(0, bHeight)) newData[x][y] = backup[x + backupX][y + backupY]
                else if (x + borderWidth < newWidth) newData[x][y] = newData[x + borderWidth][y]
                else newData[x][y] = newData[x + 1][y]
            }
        }
        if (xOffset == 0) {
            for (x in blockWidth until newWidth) {
                for (y in 0 until newHeight) {
                    if ((x + backupX).inRange(0, bWidth) && (y + backupY).inRange(0, bHeight)) newData[x][y] = backup[x + backupX][y + backupY]
                    else if (x - borderWidth >= 0) newData[x][y] = newData[x - borderWidth][y]
                    else newData[x][y] = newData[x - 1][y]
                }
            }
        }

        // copy data to model
        val token = tokenFactory()
        val run = model.relocateForExpansion(token, this, newWidth * newHeight * 2)
        for (y in 0 until newHeight) {
            for (x in 0 until newWidth) {
                model.writeMultiByteValue(run.start + (y * newWidth + x) * 2, 2, token, newData[x][y])
            }
        }
        // clear excess
        for (i in newHeight * newWidth until blockWidth * blockHeight) {
            model.writeMultiByteValue(run.start + i * 2, 2, token, -1)
        }

        val primarySource = pointerSources!![0]
        val layoutStart = primarySource - 12
        model.writeValue(token, layoutStart, newWidth)
        model.writeValue(token, layoutStart + 4, newHeight)
        val newRun = BlockmapRun(model, run.start, run.pointerSources, newWidth, newHeight)
        newRun.backupContent = backupContent
        newRun.backupX = backupX
        newRun.backupY = backupY
        model.observeRunWritten(token, newRun)
        return newRun
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE BlockmapRun.Clone/1 cs:309-309*/
        return BlockmapRun(model, start, newPointerSources, blockWidth, blockHeight)
    }
    override fun updateFromParent(token: ModelDelta, parentSegmentChange: Int, pointerSource: Int): IUpdateFromParentRun? { /*@DONE BlockmapRun.UpdateFromParent/1 cs:311-322*/
        // width:: height:: borderblock<> blockmap<`blm`>
        val width = model.readValue(pointerSource - 12)
        val height = model.readValue(pointerSource - 8)
        val dx = width - blockWidth
        val dy = height - blockHeight
        if (dx == 0 && dy == 0) return this
        val layout = ModelArrayElement(model, pointerSource - 12, 0, { token }, null)
        val borderWidth = if (layout.hasField("borderwidth")) layout.getValue("borderwidth") else 2
        val borderHeight = if (layout.hasField("borderheight")) layout.getValue("borderheight") else 2
        return tryChangeSize({ token }, 0, 0, dx, dy, borderWidth, borderHeight)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE BlockmapRun.AppendTo/1 cs:324-330*/
        var i = 0
        while (i < length) {
            val pair = model.readMultiByteValue(start + i, 2)
            builder.append(pair.toHex(4))
            if (i < length) builder.append(" ")
            i += 2
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE BlockmapRun.Clear/1 cs:332-334*/
        var i = 0
        while (i < length) {
            model.writeMultiByteValue(start + i, 2, changeToken, 0)
            i += 2
        }
    }
    companion object {
        private val totalTiles: Int
            get() { /*@DONE BlockmapRun.TotalTiles.get cs:28-28*/
                return 1024
            }
        private val totalPalettes: Int
            get() { /*@DONE BlockmapRun.TotalPalettes.get cs:29-29*/
                return 13
            }
        val sharedFormatString: String
            get() { /*@DONE BlockmapRun.SharedFormatString.get cs:40-40*/
                return "`blm`"
            }
        fun readPalettes(blockModel1: BlocksetModel, blockModel2: BlocksetModel, primaryPalettes: Int): Array<ShortArray>? { /*@DONE BlockmapRun.ReadPalettes/1 cs:67-75*/
            val primary = blockModel1.readPalettes()
            val secondary = blockModel2.readPalettes()
            if (primary == null || secondary == null) return null
            return Array(totalPalettes) { i -> if (i < primaryPalettes) primary[i] else secondary[i] }
        }
        fun writePalettes(token: ModelDelta, blockModel1: BlocksetModel, blockModel2: BlocksetModel, primaryPalettes: Int, palettes: Array<ShortArray>) { /*@DONE BlockmapRun.WritePalettes/1 cs:77-87*/
            val primary = ArrayList<ShortArray>()
            val secondary = ArrayList<ShortArray>()
            for (i in 0 until primaryPalettes) {
                secondary.add(ShortArray(16))
                primary.add(palettes[i])
            }
            for (i in primaryPalettes until totalPalettes) secondary.add(palettes[i])
            blockModel1.writePalettes(primary.toTypedArray(), token)
            blockModel2.writePalettes(secondary.toTypedArray(), token) // TODO only write the secondary palettes, not the filler palettes
        }
        fun readTiles(blockModel1: BlocksetModel, blockModel2: BlocksetModel, primaryTiles: Int): Array<Array<IntArray>?>? { /*@DONE BlockmapRun.ReadTiles/1 cs:89-97*/
            val primary = blockModel1.readTiles()
            val secondary = blockModel2.readTiles()
            if (primary == null || secondary == null) return null
            val result = arrayOfNulls<Array<IntArray>>(totalTiles)
            for (i in 0 until minOf(primaryTiles, primary.size)) result[i] = primary[i]
            for (i in primaryTiles until minOf(totalTiles, secondary.size + primaryTiles)) result[i] = secondary[i - primaryTiles]
            return result
        }
        fun writeTiles(token: ModelDelta, blockModel1: BlocksetModel, blockModel2: BlocksetModel, primaryTiles: Int, tiles: Array<Array<IntArray>>): MutableList<Int> { /*@DONE BlockmapRun.WriteTiles/1 cs:99-107*/
            val primary = ArrayList<Array<IntArray>>()
            val secondary = ArrayList<Array<IntArray>>()
            for (i in 0 until primaryTiles) primary.add(tiles[i])
            for (i in primaryTiles until tiles.size) secondary.add(tiles[i])
            val a = blockModel1.writeTiles(primary.toTypedArray(), token)
            val b = blockModel2.writeTiles(secondary.toTypedArray(), token)
            return arrayListOf(a, b)
        }
        fun readBlocks(maxUsedPrimary: Int, maxUsedSecondary: Int, blockModel1: BlocksetModel, blockModel2: BlocksetModel): Array<ByteArray> { /*@DONE BlockmapRun.ReadBlocks/1 cs:109-117*/
            val primary = blockModel1.readBlocks(maxUsedPrimary)
            val secondary = blockModel2.readBlocks(maxUsedSecondary)
            val result = ArrayList<ByteArray>()
            for (i in 0 until primary.size) result.add(primary[i])
            while (result.size < blockModel1.primaryBlocks) result.add(ByteArray(16))
            for (i in 0 until secondary.size) result.add(secondary[i])
            return result.toTypedArray()
        }
        fun writeBlocks(tokenFactory: () -> ModelDelta, maxUsedPrimary: Int, maxUsedSecondary: Int, blockModel1: BlocksetModel, blockModel2: BlocksetModel, blocks: Array<ByteArray>) { /*@DONE BlockmapRun.WriteBlocks/1 cs:119-126*/
            val primary = ArrayList<ByteArray>()
            val secondary = ArrayList<ByteArray>()
            for (i in 0 until blockModel1.primaryBlocks) primary.add(blocks[i])
            for (i in 0 until blocks.size - blockModel1.primaryBlocks) secondary.add(blocks[i + blockModel1.primaryBlocks])
            blockModel1.writeBlocks(primary.take(maxOf(0, maxUsedPrimary)).toTypedArray(), tokenFactory)
            blockModel2.writeBlocks(secondary.take(maxOf(0, maxUsedSecondary)).toTypedArray(), tokenFactory)
        }
        fun readBlockAttributes(maxUsedPrimary: Int, maxUsedSecondary: Int, blockModel1: BlocksetModel, blockModel2: BlocksetModel): Array<ByteArray> { /*@DONE BlockmapRun.ReadBlockAttributes/1 cs:128-136*/
            val primary = blockModel1.readBlockAttributes(maxUsedPrimary)
            val secondary = blockModel2.readBlockAttributes(maxUsedSecondary)
            val result = ArrayList<ByteArray>()
            for (i in 0 until primary.size) result.add(primary[i])
            while (result.size < blockModel1.primaryBlocks) result.add(ByteArray(blockModel1.bytesPerAttribute))
            for (i in 0 until secondary.size) result.add(secondary[i])
            return result.toTypedArray()
        }
        fun writeBlockAttributes(tokenFactory: () -> ModelDelta, maxUsedPrimary: Int, maxUsedSecondary: Int, blockModel1: BlocksetModel, blockModel2: BlocksetModel, blockAttributes: Array<ByteArray>) { /*@DONE BlockmapRun.WriteBlockAttributes/1 cs:138-145*/
            val primary = ArrayList<ByteArray>()
            val secondary = ArrayList<ByteArray>()
            for (i in 0 until blockModel1.primaryBlocks) primary.add(blockAttributes[i])
            for (i in 0 until blockAttributes.size - blockModel1.primaryBlocks) secondary.add(blockAttributes[i + blockModel1.primaryBlocks])
            blockModel1.writeBlockAttributes(primary.take(maxOf(0, maxUsedPrimary)).toTypedArray(), tokenFactory)
            blockModel2.writeBlockAttributes(secondary.take(maxOf(0, maxUsedSecondary)).toTypedArray(), tokenFactory)
        }
        fun calculateBlockRenders(blocks: Array<ByteArray>, blockAttributes: Array<ByteArray>, tiles: Array<Array<IntArray>?>, palettes: Array<List<Short>>): Iterable<IPixelViewModel> { /*@DONE BlockmapRun.CalculateBlockRenders/1 cs:147-152*/
            val uniquePalettes = Array(palettes.size) { i -> SpriteTool.createPaletteWithUniqueTransparentColor(palettes[i]) }
            val result = ArrayList<IPixelViewModel>()
            for (i in 0 until blocks.size) {
                result.add(BlocksetModel.renderBlock(i, blocks, blockAttributes, tiles, uniquePalettes))
            }
            return result
        }
        fun renderMap(model: ByteList, start: Int, width: Int, height: Int, blocks: List<IPixelViewModel>): CanvasPixelViewModel { /*@DONE BlockmapRun.RenderMap/1 cs:154-164*/
            val canvas = CanvasPixelViewModel(width * 16, height * 16)
            for (y in 0 until height) {
                for (x in 0 until width) {
                    val value = model.readMultiByteValue(start + (y * width + x) * 2, 2) and 0x3FF
                    if (blocks.size <= value) continue
                    canvas.draw(blocks[value], x * 16, y * 16)
                }
            }
            return canvas
        }
        fun getMaxUsedBlock(model: ByteList, start: Int, width: Int, height: Int, maxCheck: Int): Int { /*@DONE BlockmapRun.GetMaxUsedBlock/1 cs:166-169*/
            if (start < 0) return 0
            var max = 0
            for (i in 0 until width * height) {
                val value = (if (start + i * 2 < model.count - 2) model.readMultiByteValue(start + i * 2, 2) else 0) and 0x3FF
                if (maxCheck > value && value > max) max = value
            }
            return max
        }
        /*@END BlockmapRun.Companion*/
    }
    /*@END BlockmapRun*/
}

open class BlocksetModel { // cs:337-667
    private lateinit var model: IDataModel
    private var address: Int = 0
    private var _primaryBlocks: Int = 0
    private var primaryTiles: Int = 0
    private var primaryPalettes: Int = 0
    private var attributeOffset: Int = 0
    val primaryBlocks: Int
        get() { /*@DONE BlocksetModel.PrimaryBlocks.get cs:342-342*/
            return _primaryBlocks
        }
    var bytesPerAttribute: Int = 0
        private set
    val start: Int
        get() { /*@DONE BlocksetModel.Start.get cs:344-344*/
            return address
        }
    constructor(model: IDataModel, address: Int) { /*@DONE BlocksetModel.<init>/1 cs:346-362*/
        this.model = model
        this.address = address
        if (model.isFRLG()) {
            _primaryBlocks = 640
            primaryTiles = 640
            primaryPalettes = 7
            attributeOffset = 20
            bytesPerAttribute = 4
        } else {
            _primaryBlocks = 512
            primaryTiles = 512
            primaryPalettes = 6
            attributeOffset = 16
            bytesPerAttribute = 2
        }
    }
    private fun read(offset: Int): Int { /*@DONE BlocksetModel.Read/1 cs:364-364*/
        return model[address + offset]
    }
    private fun readPointer(offset: Int): Int { /*@DONE BlocksetModel.ReadPointer/1 cs:365-365*/
        return model.readPointer(address + offset)
    }
    val isCompressed: Boolean
        get() { /*@DONE BlocksetModel.IsCompressed.get cs:367-367*/
            return read(0) == 1
        }
    val isSecondary: Boolean
        get() { /*@DONE BlocksetModel.IsSecondary.get cs:368-368*/
            return read(1) == 1
        }
    fun readTiles(): Array<Array<IntArray>>? { /*@DONE BlocksetModel.ReadTiles/1 cs:370-406*/
        if (!isCompressed) return readUncompressedTiles()
        val start = readPointer(4)
        if (start < 0 || start > model.count) return null

        // try to silently replace noinfo run with tileset run
        val existingRun = model.getNextRun(start)
        if (existingRun is NoInfoRun && existingRun.start == start) {
            val formatRun = LzTilesetRun(TilesetFormat(4, null), model, start)
            var conflict = false
            var nextRun: IFormattedRun = model.getNextRun(start + 1) ?: NoInfoRun.nullRun
            while (nextRun.start < formatRun.start + formatRun.length) {
                val probablyFalse =
                    nextRun is PointerRun || // probably false pointer
                    (nextRun is PCSRun && model.getAnchorFromAddress(-1, nextRun.start).isEmpty()) || // probably false text
                    (nextRun is NoInfoRun && (nextRun.pointerSources?.size ?: 0) < 3) // probably false destination
                if (!probablyFalse) {
                    conflict = true
                    break
                }
                nextRun = model.getNextRun(nextRun.start + maxOf(nextRun.length, 1)) ?: NoInfoRun.nullRun
            }
            if (formatRun.length > 1 && !conflict) {
                model.clearFormat(NoTrackChange(), formatRun.start, formatRun.length)
                model.observeRunWritten(NoTrackChange(), formatRun)
            }
        }

        val run = LzTilesetRun(TilesetFormat(4, null), model, start)
        val fullData = run.getPixels(model, 0, 1) ?: return null
        val fullHeight = if (fullData.isEmpty()) 0 else fullData[0].size
        val list = ArrayList<Array<IntArray>>()
        for (i in 0 until fullHeight / 8) {
            val tile = Array(8) { IntArray(8) }
            for (x in 0 until 8) {
                for (y in 0 until 8) {
                    tile[x][y] = fullData[x][y + i * 8]
                }
            }
            list.add(tile)
        }
        return list.toTypedArray()
    }
    fun writeTiles(tiles: Array<Array<IntArray>>, token: ModelDelta): Int { /*@DONE BlocksetModel.WriteTiles/1 cs:408-417*/
        if (!isCompressed) {
            return writeUncompressedTiles(tiles, token)
        }
        // TODO make sure this repoints correctly even when there's no LzRun for the data
        val start = readPointer(4)
        var run = LzTilesetRun(TilesetFormat(4, null), model, start)
        run = run.setPixels(model, token, tiles.asList())
        return run.start
    }
    private fun readUncompressedTiles(): Array<Array<IntArray>> { /*@DONE BlocksetModel.ReadUncompressedTiles/1 cs:419-435*/
        val list = ArrayList<Array<IntArray>>()
        val start = readPointer(4)
        val tileCount = Ref(if (!isSecondary) primaryTiles else 1024 - primaryTiles)
        estimateTileCount(tileCount, start)
        if (start < 0 || start + tileCount.value * 32 > model.count) return list.toTypedArray()
        for (i in 0 until tileCount.value) {
            val tile = Array(8) { IntArray(8) }
            for (y in 0 until 8) {
                for (x in 0 until 4) {
                    tile[x * 2 + 0][y] = model[start + i * 32 + y * 4 + x] and 0xF
                    tile[x * 2 + 1][y] = model[start + i * 32 + y * 4 + x] shr 4
                }
            }
            list.add(tile)
        }
        return list.toTypedArray()
    }
    private fun writeUncompressedTiles(tiles: Array<Array<IntArray>>, token: ModelDelta): Int { /*@DONE BlocksetModel.WriteUncompressedTiles/1 cs:437-450*/
        // TODO this currently doesn't worry about repointing or expansion, but it probably should
        val start = readPointer(4)
        for (i in 0 until tiles.size) {
            for (y in 0 until 8) {
                for (x in 0 until 4) {
                    val low = tiles[i][x * 2 + 0][y]
                    val high = tiles[i][x * 2 + 1][y]
                    token.changeData(model, start + i * 32 + y * 4 + x, ((high shl 4) or low) and 0xFF)
                }
            }
        }
        return start
    }
    fun readPalettes(): Array<ShortArray>? { /*@DONE BlocksetModel.ReadPalettes/1 cs:453-465*/
        val start = readPointer(8)
        if (start < 0 || start >= model.count) return null
        if (start + 16 * 32 > model.count) return null
        val data = Array(16) { ShortArray(16) }
        for (i in 0 until 16) {
            for (j in 0 until 16) {
                val bgr = model.readMultiByteValue(start + i * 32 + j * 2, 2).toShort()
                data[i][j] = PaletteRun.flipColorChannels(bgr)
            }
        }
        return data
    }
    fun writePalettes(palettes: Array<ShortArray>, token: ModelDelta) { /*@DONE BlocksetModel.WritePalettes/1 cs:467-475*/
        val start = readPointer(8)
        for (i in 0 until minOf(16, palettes.size)) {
            for (j in 0 until 16) {
                val bgr = PaletteRun.flipColorChannels(palettes[i][j])
                model.writeMultiByteValue(start + i * 32 + j * 2, 2, token, bgr.toInt())
            }
        }
    }
    fun readBlocks(maxUsedBlock: Int): Array<ByteArray> { /*@DONE BlocksetModel.ReadBlocks/1 cs:477-492*/
        val blockCount = Ref(_primaryBlocks)
        // each block is 16 bytes
        val start = readPointer(12)
        if (isSecondary) blockCount.value = 1024 - blockCount.value
        val attributeStart = readPointer(attributeOffset)
        estimateBlockCount(blockCount, start, attributeStart, maxUsedBlock)
        val data = Array(blockCount.value) { ByteArray(16) }
        for (i in 0 until blockCount.value) {
            for (j in 0 until data[i].size) {
                val index = start + i * data[i].size + j
                data[i][j] = if (index in 0 until model.count) model[index].toByte() else 0
            }
        }
        return data
    }
    fun renderBlockset(scale: Double = 1.0): IPixelViewModel { /*@DONE BlocksetModel.RenderBlockset/1 cs:497-519*/
        val blocks = readBlocks(primaryBlocks)
        val blockAttributes = readBlockAttributes(primaryBlocks)
        val readTiles = readTiles()
        val palettes = readPalettes()
        val rowWidth = BlockMapViewModel.blocksPerRow
        if (readTiles == null || palettes == null) {
            // the original would crash with a NullReferenceException here
            val empty = CanvasPixelViewModel(rowWidth * 16, 16)
            empty.spriteScale = scale
            return empty
        }
        var tiles: Array<Array<IntArray>?> = readTiles.map { tile -> tile as Array<IntArray>? }.toTypedArray()
        if (isSecondary) {
            val fullTiles = arrayOfNulls<Array<IntArray>>(primaryBlocks + tiles.size)
            for (i in 0 until tiles.size) fullTiles[primaryBlocks + i] = tiles[i]
            tiles = fullTiles
        }
        val paletteLists = Array<List<Short>>(palettes.size) { i -> palettes[i].asList() }
        val renders = BlockmapRun.calculateBlockRenders(blocks, blockAttributes, tiles, paletteLists).toList()

        val blockHeight = (renders.size + rowWidth - 1) / rowWidth
        val canvas = CanvasPixelViewModel(rowWidth * 16, blockHeight * 16)
        canvas.spriteScale = scale
        for (i in 0 until renders.size) {
            val x = i % rowWidth
            val y = i / rowWidth
            canvas.draw(renders[i], x * 16, y * 16)
        }

        return canvas
    }
    fun writeBlocks(blocks: Array<ByteArray>, tokenFactory: () -> ModelDelta) { /*@DONE BlocksetModel.WriteBlocks/1 cs:521-530*/
        val start = readPointer(12)
        for (i in 0 until blocks.size) {
            val s = start + i * blocks[i].size
            for (j in 0 until blocks[i].size) {
                val value = blocks[i][j].toInt() and 0xFF
                if (model[s + j] == value) continue
                tokenFactory().changeData(model, s + j, value)
            }
        }
    }
    fun readBlockAttributes(maxUsedBlock: Int): Array<ByteArray> { /*@DONE BlocksetModel.ReadBlockAttributes/1 cs:532-547*/
        val blockCount = Ref(_primaryBlocks)
        val start = readPointer(12)
        if (isSecondary) blockCount.value = 1024 - blockCount.value
        val attributeStart = readPointer(attributeOffset)
        estimateBlockCount(blockCount, start, attributeStart, maxUsedBlock)
        if (!start.inRange(0, model.count) || !attributeStart.inRange(0, model.count)) return Array(0) { ByteArray(0) }
        val data = Array(blockCount.value) { ByteArray(bytesPerAttribute) }
        for (i in 0 until blockCount.value) {
            for (j in 0 until data[i].size) {
                val index = attributeStart + i * data[i].size + j
                data[i][j] = if (index < model.count) model[index].toByte() else 0
            }
        }
        return data
    }
    fun writeBlockAttributes(attributes: Array<ByteArray>, tokenFactory: () -> ModelDelta) { /*@DONE BlocksetModel.WriteBlockAttributes/1 cs:549-558*/
        val attributeStart = readPointer(attributeOffset)
        for (i in 0 until attributes.size) {
            val s = attributeStart + i * attributes[i].size
            for (j in 0 until attributes[i].size) {
                val value = attributes[i][j].toInt() and 0xFF
                if (model[s + j] == value) continue
                tokenFactory().changeData(model, s + j, value)
            }
        }
    }
    private fun estimateBlockCount(blockCount: Ref<Int>, blockStart: Int, attributeStart: Int, maxUsedBlock: Int) { /*@DONE BlocksetModel.EstimateBlockCount/1 cs:611-614*/
        BlocksetModel.estimateBlockCount(model, blockCount, blockStart, attributeStart)
        blockCount.value = maxOf(blockCount.value, maxUsedBlock + 1)
    }
    private fun estimateTileCount(tileCount: Ref<Int>, tileStart: Int) { /*@DONE BlocksetModel.EstimateTileCount/1 cs:627-627*/
        BlocksetModel.estimateTileCount(model, tileCount, tileStart)
    }
    companion object {
        fun renderBlock(i: Int, blocks: Array<ByteArray>, blockAttributes: Array<ByteArray>?, tiles: Array<Array<IntArray>?>, palettes: Array<List<Short>>): IPixelViewModel { /*@DONE BlocksetModel.RenderBlock/1 cs:560-609*/
            val canvas = CanvasPixelViewModel(16, 16)

            var block = blocks[i]

            // bottom layer
            var tile = read(block, 0, tiles, palettes)
            canvas.draw(tile, 0, 0)

            tile = read(block, 1, tiles, palettes)
            canvas.draw(tile, 8, 0)

            tile = read(block, 2, tiles, palettes)
            canvas.draw(tile, 0, 8)

            tile = read(block, 3, tiles, palettes)
            canvas.draw(tile, 8, 8)

            // top layer
            tile = read(block, 4, tiles, palettes)
            canvas.draw(tile, 0, 0)

            tile = read(block, 5, tiles, palettes)
            canvas.draw(tile, 8, 0)

            tile = read(block, 6, tiles, palettes)
            canvas.draw(tile, 0, 8)

            tile = read(block, 7, tiles, palettes)
            canvas.draw(tile, 8, 8)

            if (blockAttributes != null && blockAttributes.size > i) {
                val attribute = TileAttribute.create(blockAttributes[i])
                if (attribute.layer == 3 && blocks.size > i + 1) {
                    block = blocks[i + 1]

                    // triple layer
                    tile = read(block, 8, tiles, palettes)
                    canvas.draw(tile, 0, 0)

                    tile = read(block, 9, tiles, palettes)
                    canvas.draw(tile, 8, 0)

                    tile = read(block, 10, tiles, palettes)
                    canvas.draw(tile, 0, 8)

                    tile = read(block, 11, tiles, palettes)
                    canvas.draw(tile, 8, 8)
                }
            }

            return canvas
        }
        fun estimateBlockCount(model: IDataModel, blockCount: Ref<Int>, blockStart: Int, attributeStart: Int) { /*@DONE BlocksetModel.EstimateBlockCount/2 cs:616-625*/
            val blockLength = 0x10
            var run: IFormattedRun = model.getNextRun(blockStart + 1) ?: NoInfoRun.nullRun
            while (run.start < attributeStart) {
                if (run is NoInfoRun || run is PointerRun) {
                    run = model.getNextRun(run.start + maxOf(run.length, 1)) ?: NoInfoRun.nullRun
                    continue
                }
                break
            }
            blockCount.value = minOf(blockCount.value, (run.start - blockStart) / blockLength)
            if (blockCount.value < 1) blockCount.value = 1
        }
        fun estimateTileCount(model: IDataModel, tileCount: Ref<Int>, tileStart: Int) { /*@DONE BlocksetModel.EstimateTileCount/2 cs:628-645*/
            // each tile is 32 bytes
            val tileLength = 0x20
            var run: IFormattedRun = model.getNextRun(tileStart + 1) ?: NoInfoRun.nullRun
            while (run.start < tileStart + tileCount.value * tileLength) {
                var advance = false
                if (run is PointerRun) {
                    advance = true
                } else if (run is NoInfoRun) {
                    if ((run.start - tileStart) % 0x20 == 0) {
                        // might be a real anchor to unprocessed data, like another tileset
                    } else {
                        advance = true
                    }
                }
                if (!advance) break
                run = model.getNextRun(run.start + maxOf(run.length, 1)) ?: NoInfoRun.nullRun
            }
            tileCount.value = minOf(tileCount.value, (run.start - tileStart) / tileLength)
            if (tileCount.value < 1) tileCount.value = 1
        }
        fun read(block: ByteArray, index: Int, tiles: Array<Array<IntArray>?>, palettes: Array<List<Short>>): IPixelViewModel { /*@DONE BlocksetModel.Read/2 cs:647-666*/
            val data = LzTilemapRun.readTileData(block, index % 8, 2)
            val pal = data.paletteIndex
            val hFlip = data.hFlip
            val vFlip = data.vFlip
            val tile = data.tileIndex

            if (pal >= palettes.size) return ReadonlyPixelViewModel(8, 8, ShortArray(64))

            if (tiles.size < tile) {
                return ReadonlyPixelViewModel(SpriteFormat(4, 1, 1, null), ShortArray(64))
            }

            val tileData = ShortArray(64)
            val tilePixels = if (tiles.size <= tile) null else tiles[tile]
            for (yy in 0 until 8) {
                for (xx in 0 until 8) {
                    val inX = if (hFlip) 7 - xx else xx
                    val inY = if (vFlip) 7 - yy else yy
                    if (tilePixels == null || palettes.size <= pal) tileData[yy * 8 + xx] = 0
                    else tileData[yy * 8 + xx] = palettes[pal][tilePixels[inX][inY]]
                }
            }
            return ReadonlyPixelViewModel(8, 8, tileData, if (index < 4) (-1).toShort() else palettes[pal][0])
        }
        /*@END BlocksetModel.Companion*/
    }
    /*@END BlocksetModel*/
}
