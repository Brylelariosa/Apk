package dev.hexmaniac.core.system

// Small stand-ins for BCL types used throughout the original code base (see PORTING.md).

/** System.IDisposable */
interface IDisposable {
    fun dispose()
}

/** The AutoImplement-generated StubDisposable: `StubDisposable { Dispose = () => ... }`. */
class StubDisposable(var dispose: (() -> Unit)? = null) : IDisposable {
    override fun dispose() {
        dispose?.invoke()
    }
}

/** C# `using (x) { ... }` -- run [block] and dispose [this] afterwards (also when [block] throws). */
inline fun <T : IDisposable?, R> T.using(block: (T) -> R): R {
    try {
        return block(this)
    } finally {
        this?.dispose()
    }
}

/**
 * C# `ref` / `out` parameter and by-reference local. Every non-private method that has `ref`/`out` parameters keeps
 * them as `Ref<T>` parameters. Read and write with `.value`.
 */
class Ref<T>(@JvmField var value: T) {
    override fun toString(): String = value.toString()
}

/** Convenience for `out` parameters whose initial value does not matter: `val x = outRef<Int>(0)`. */
fun <T> outRef(initial: T): Ref<T> = Ref(initial)

/**
 * Read-only random access list of bytes, where every byte is an Int in 0..255.
 * This is `IReadOnlyList<byte>`: implemented by IDataModel and by [asByteList] over a ByteArray.
 */
interface ByteList {
    val count: Int
    operator fun get(index: Int): Int
}

class ByteArrayList(val array: ByteArray) : ByteList {
    override val count: Int get() = array.size
    override operator fun get(index: Int): Int = array[index].toInt() and 0xFF
}

fun ByteArray.asByteList(): ByteList = ByteArrayList(this)

/** `array[index]` of a C# byte[] as an unsigned value 0..255. */
fun ByteArray.getU(index: Int): Int = this[index].toInt() and 0xFF

/** `array[index] = (byte)value` for a C# byte[]. */
fun ByteArray.setU(index: Int, value: Int) {
    this[index] = value.toByte()
}

/** Converts a list of byte values (0..255 as Int) into a ByteArray. */
fun Collection<Int>.toByteArrayU(): ByteArray {
    val result = ByteArray(size)
    var i = 0
    for (v in this) result[i++] = v.toByte()
    return result
}

// --- exceptions: names the C# code throws/catches, mapped onto JVM exceptions ---
typealias ArgumentException = IllegalArgumentException
typealias ArgumentNullException = IllegalArgumentException
typealias ArgumentOutOfRangeException = IndexOutOfBoundsException
typealias InvalidOperationException = IllegalStateException
typealias NotImplementedException = UnsupportedOperationException
typealias NotSupportedException = UnsupportedOperationException
typealias KeyNotFoundException = NoSuchElementException
typealias FormatException = NumberFormatException
typealias IndexOutOfRangeException = IndexOutOfBoundsException
typealias DivideByZeroException = ArithmeticException
typealias IOException = java.io.IOException
typealias FileNotFoundException = java.io.FileNotFoundException

/** System.Diagnostics.Debug. Assertions are off by default; tests may switch them on. */
object Debug {
    @JvmField
    var assertionsEnabled: Boolean = false

    @JvmField
    var onMessage: ((String) -> Unit)? = null

    fun assert(condition: Boolean, message: String? = null) {
        if (!condition && assertionsEnabled) throw IllegalStateException("Debug.Assert failed" + (if (message != null) ": $message" else ""))
    }

    fun fail(message: String? = null): Unit = assert(false, message)

    fun writeLine(message: String?) {
        onMessage?.invoke(message ?: "")
    }
}

/** System.TimeSpan (only what the app needs). */
class TimeSpan(val totalMilliseconds: Double) {
    val totalSeconds: Double get() = totalMilliseconds / 1000.0
    val milliseconds: Int get() = (totalMilliseconds % 1000.0).toInt()
    override fun toString(): String = "${totalSeconds}s"

    companion object {
        val zero = TimeSpan(0.0)
        fun fromMilliseconds(ms: Double) = TimeSpan(ms)
        fun fromSeconds(s: Double) = TimeSpan(s * 1000.0)
    }
}

/** System.Diagnostics.Stopwatch */
class Stopwatch private constructor() {
    private var startNanos: Long = 0L
    private var accumulated: Long = 0L
    var isRunning: Boolean = false
        private set

    fun start() {
        if (isRunning) return
        startNanos = System.nanoTime()
        isRunning = true
    }

    fun stop() {
        if (!isRunning) return
        accumulated += System.nanoTime() - startNanos
        isRunning = false
    }

    fun reset() {
        accumulated = 0L
        isRunning = false
    }

    val elapsedMilliseconds: Long
        get() = (accumulated + if (isRunning) System.nanoTime() - startNanos else 0L) / 1_000_000L

    companion object {
        fun startNew(): Stopwatch = Stopwatch().also { it.start() }
    }
}

/** System.Environment.NewLine */
const val NEW_LINE = "\n"
