// Port of ViewModels/ITabContent.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*

interface ITabContent : INotifyPropertyChanged { // cs:10-55
    val name: String
    val isMetadataOnlyChange: Boolean
    val save: ICommand?
    val saveAs: ICommand
    val exportBackup: ICommand
    val undo: ICommand
    val redo: ICommand
    val copy: ICommand?
    val deepCopy: ICommand
    val clear: ICommand?
    val selectAll: ICommand
    val goto: ICommand?
    val resetAlignment: ICommand
    val back: ICommand
    val forward: ICommand
    val close: ICommand
    val diff: ICommand
    val diffLeft: ICommand
    val diffRight: ICommand
    val onError: Event<String>
    val onMessage: Event<String>
    val clearMessage: Event<EventArgs>
    val closed: Event<EventArgs>
    val requestTabChange: Event<TabChangeRequestedEventArgs>
    val requestDelayedWork: Event<() -> Unit>
    val requestMenuClose: Event<EventArgs>
    val requestDiff: Event<Direction>
    val requestCanDiff: Event<CanDiffEventArgs>
    val requestCanCreatePatch: Event<CanPatchEventArgs>
    val requestCreatePatch: Event<CanPatchEventArgs>
    val requestRefreshGotoShortcuts: Event<EventArgs>
    var spartanMode: Boolean
    val canIpsPatchRight: Boolean
    val canUpsPatchRight: Boolean
    fun ipsPatchRight()
    fun upsPatchRight()
    val canDuplicate: Boolean
    fun duplicate()
    fun refresh()
    fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean
    /*@END ITabContent*/
}

data class TabChangeRequestedEventArgs(val newTab: ITabContent) { // cs:57-59
    var requestAccepted: Boolean = false
    /*@END TabChangeRequestedEventArgs*/
}

interface IRaiseMessageTab : ITabContent { // cs:61-63
    fun raiseMessage(message: String)
    /*@END IRaiseMessageTab*/
}

interface IRaiseErrorTab : ITabContent { // cs:65-67
    fun raiseError(message: String)
    /*@END IRaiseErrorTab*/
}

open class CanDiffEventArgs : EventArgs { // cs:69-73
    var direction: Direction = Direction.Left
        private set
    var result: Boolean = false
    constructor(d: Direction) { /*@DONE CanDiffEventArgs.<init>/1 cs:72-72*/
        direction = d
    }
    /*@END CanDiffEventArgs*/
}

open class CanPatchEventArgs : EventArgs { // cs:75-80
    var direction: Direction = Direction.Left
        private set
    var patchType: PatchType = PatchType.Ips
        private set
    var result: Boolean = false
    constructor(d: Direction, p: PatchType) { /*@DONE CanPatchEventArgs.<init>/1 cs:79-79*/
        direction = d
        patchType = p
    }
    /*@END CanPatchEventArgs*/
}
