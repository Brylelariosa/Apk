// Port of ViewModels/Tools/PythonTool.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class PythonTool : ViewModelCore { // cs:11-137
    private lateinit var engine: Lazy<ScriptEngine>
    private lateinit var scope: Lazy<ScriptScope>
    private lateinit var editor: EditorViewModel
    private lateinit var content: TextEditorViewModel
    private var _resultText: String = ""
    var text: String?
        get() { /*@DONE PythonTool.Text.get cs:18-18*/
            return content.content
        }
        set(value) { /*@DONE PythonTool.Text.set cs:18-18*/
            content.content = value ?: ""
        }
    var resultText: String
        get() { /*@DONE PythonTool.ResultText.get cs:19-19*/
            return _resultText
        }
        set(value) { /*@DONE PythonTool.ResultText.set cs:19-19*/
            set(_resultText, value, "resultText", { _resultText = it })
        }
    val pythonEditor: TextEditorViewModel
        get() { /*@DONE PythonTool.PythonEditor.get cs:20-20*/
            return content
        }
    constructor(editor: EditorViewModel) { /*@DONE PythonTool.<init>/1 cs:22-64*/
        this.editor = editor
        content = setupPythonEditor()
        // IronPython is not available on Android; the engine and scope are inert placeholders.
        engine = lazy { ScriptEngine() }
        scope = lazy { ScriptScope() }
        text = "print('''\n" +
            "   Put python code here.\n" +
            "   'editor' is the EditorViewModel.\n" +
            "   Tables from the current tab\n" +
            "     can be accessed by name.\n" +
            "   For example, try printing:\n" +
            "      data.pokemon.names[1].name\n" +
            "   Or try changing a table using a loop:\n" +
            "\n" +
            "   for mon in data.pokemon.stats:\n" +
            "     mon.hp = 100\n" +
            "''')"
    }
    fun runPython() { /*@DONE PythonTool.RunPython/1 cs:66-69*/
        resultText = runPythonScript(text ?: "").errorMessage ?: "null"
        editor.selectedTab?.refresh()
    }
    fun runPythonScript(code: String): ErrorInfo { /*@DONE PythonTool.RunPythonScript/1 cs:71-92*/
        val tab = editor.selectedTab
        val tabModel = (tab as? IEditableViewPort)?.model
        if (tab is IEditableViewPort && tabModel != null) {
            val anchors = AnchorGroup.getTopLevelAnchorGroups(tabModel, { tab.changeHistory.currentChange })
            for (key in anchors.keys) variables[key] = anchors[key]
        }
        val runner = scriptRunner
            ?: return ErrorInfo("Python scripting is not available in the Android edition of HexManiac Advance.")
        try {
            val result = runner(code, variables)
            var resultText: String? = result?.toString()
            if (result is Iterable<*> && result !is IDataModel) {
                resultText = ""
                for (item in result) {
                    if (resultText!!.length > 0) resultText += NEW_LINE
                    resultText += item.toString()
                }
            }
            if (resultText == null) return ErrorInfo.noError
            return ErrorInfo(resultText, isWarningLevel = true)
        } catch (ex: Exception) {
            return ErrorInfo(ex.message)
        }
    }
    fun hasFunction(name: String): Boolean { /*@DONE PythonTool.HasFunction/1 cs:94-97*/
        val result = runPythonScript("'$name' in globals()")
        return result.isWarning && result.errorMessage == "True"
    }
    fun getComment(functionName: String): String? { /*@DONE PythonTool.GetComment/1 cs:99-102*/
        val result = runPythonScript("$functionName.__doc__")
        return if (result.isWarning) result.errorMessage?.trim() else null
    }
    fun addVariable(name: String, value: Any) { /*@DONE PythonTool.AddVariable/1 cs:104-104*/
        variables[name] = value
    }
    fun printer(text: String) { /*@DONE PythonTool.Printer/1 cs:106-108*/
        editor.fileSystem.showCustomMessageBox(text, false)
    }
    fun close() { /*@DONE PythonTool.Close/1 cs:136-136*/
        editor.showAutomationPanel = false
    }
    companion object {
        fun setupPythonEditor(): TextEditorViewModel { /*@DONE PythonTool.SetupPythonEditor/1 cs:110-134*/
            val editor = TextEditorViewModel()
            editor.keywords.addAll(listOf(
                "for", "while", "in",
                "if", "elif", "else",
                "def", "return", "continue", "break", "yield",
                "class", "lambda",
                "import", "from",
                "try", "except",
                "with", "pass", "as", "is", "not",
                "len", "print", "zip", "range", "open", "round"))
            editor.constants.addAll(listOf("True", "False", "None", "str"))
            editor.lineCommentHeader = "#"
            editor.multiLineCommentHeader = "'''"
            editor.multiLineCommentFooter = "'''"
            editor.preFormatter = PythonTextFormatter()
            return editor
        }
        /*@END PythonTool.Companion*/
    }
    /*@ADD PythonTool#pythontool.txt*/
    /** Variables made available to scripts (editor tables, anchors, ...). */
    val variables: MutableMap<String, Any?> = LinkedHashMap()

    /**
     * Pluggable script runner. IronPython does not exist on Android, so the default is null and every script
     * reports that scripting is unavailable. A host may install a runner that returns the script's result
     * (or throws to report an error).
     */
    var scriptRunner: ((String, Map<String, Any?>) -> Any?)? = null
    /*@ENDADD PythonTool#pythontool.txt*/
    /*@END PythonTool*/
}

open class PythonTextFormatter : ITextPreProcessor { // cs:139-155
    override fun format(content: String): Array<TextFormatting> { /*@DONE PythonTextFormatter.Format/1 cs:140-153*/
        val result = Array(content.length) { TextFormatting.None }
        var inSingleQuoteText = false
        var inDoubleQuoteText = false
        var escaped = false
        for (i in 0 until content.length) {
            val wasInQutoes = inSingleQuoteText || inDoubleQuoteText
            if (!escaped && content[i] == '\'' && !inDoubleQuoteText) inSingleQuoteText = !inSingleQuoteText
            if (!escaped && content[i] == '"' && !inSingleQuoteText) inDoubleQuoteText = !inDoubleQuoteText
            if (wasInQutoes || inSingleQuoteText || inDoubleQuoteText) result[i] = TextFormatting.Text
            escaped = content[i] == '\\' && !escaped
        }
        return result
    }
    override fun findErrors(content: String): Iterable<TextSegment> { /*@DONE PythonTextFormatter.FindErrors/1 cs:154-154*/
        return emptyList()
    }
    /*@END PythonTextFormatter*/
}

data class TableGetter(val editor: EditorViewModel) { // cs:157-173
    operator fun get(name: String): DynamicObject? { /*@DONE TableGetter.this/1.get cs:159-171*/
        val tab = editor.selectedTab
        if (tab is IViewPort) {
            val model = tab.model ?: return null
            val address = model.getAddressFromAnchor(ModelDelta(), -1, name)
            val run = model.getNextRun(address)
            val factory: () -> ModelDelta = { tab.changeHistory.currentChange }
            if (run is EggMoveRun) {
                return EggTable(model, factory, run)
            } else {
                return ModelTable(model, address, factory)
            }
        }
        return null
    }
    /*@END TableGetter*/
}
