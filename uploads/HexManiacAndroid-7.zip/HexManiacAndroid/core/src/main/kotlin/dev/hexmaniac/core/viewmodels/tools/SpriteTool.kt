// Port of ViewModels/Tools/SpriteTool.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.visitors.*

enum class ImageExportMode(val value: Int) { // cs:17-17
    None(0),
    Horizontal(1),
    Vertical(2);
    companion object {
        fun fromValue(value: Int): ImageExportMode = entries.first { it.value == value }
    }
    /*@END ImageExportMode*/
}

open class SpriteTool : ViewModelCore, IToolViewModel, IPixelViewModel { // cs:19-1706
    private var viewPort: ViewPort? = null
    private lateinit var history: ChangeHistory<ModelDelta>
    private var model: IDataModel? = null
    private var _spriteScale: Double = 0.0
    private var spritePages: Int = /*@INITAUTO SpriteTool.spritePages cs:26-26*/ 1 /*@ENDINIT*/
    private var palPages: Int = /*@INITAUTO SpriteTool.palPages cs:26-26*/ 1 /*@ENDINIT*/
    private var _spritePage: Int = /*@INITAUTO SpriteTool.spritePage cs:26-26*/ 0 /*@ENDINIT*/
    private var palPage: Int = /*@INITAUTO SpriteTool.palPage cs:26-26*/ 0 /*@ENDINIT*/
    private var pixels: Array<IntArray>? = null
    private var palette: ShortArray? = null
    private var paletteFormat: PaletteFormat = PaletteFormat()
    override val name: String
        get() { /*@DONE SpriteTool.Name.get cs:31-31*/
            return "Image"
        }
    var spritePage: Int
        get() { /*@DONE SpriteTool.SpritePage.get cs:34-34*/
            return _spritePage
        }
        set(value) { /*@DONE SpriteTool.SpritePage.set cs:35-35*/
            set(_spritePage, value, "spritePage", { _spritePage = it }) { _ -> loadSprite() }
        }
    var palettePage: Int
        get() { /*@DONE SpriteTool.PalettePage.get cs:39-39*/
            return palPage
        }
        set(value) { /*@DONE SpriteTool.PalettePage.set cs:40-40*/
            set(palPage, value, "palettePage", { palPage = it }) { _ -> loadPalette() }
        }
    override var spriteScale: Double
        get() { /*@DONE SpriteTool.SpriteScale.get cs:43-43*/
            return _spriteScale
        }
        set(value) { /*@DONE SpriteTool.SpriteScale.set cs:43-43*/
            tryUpdate(_spriteScale, value, "spriteScale") { _spriteScale = it }
        }
    private var _showNoSpriteAnchorMessage: Boolean = /*@INITAUTO SpriteTool.showNoSpriteAnchorMessage cs:47-47*/ true /*@ENDINIT*/
    var showNoSpriteAnchorMessage: Boolean
        get() { /*@DONE SpriteTool.ShowNoSpriteAnchorMessage.get cs:48-48*/
            return _showNoSpriteAnchorMessage
        }
        set(value) { /*@DONE SpriteTool.ShowNoSpriteAnchorMessage.set cs:48-48*/
            set(_showNoSpriteAnchorMessage, value, "showNoSpriteAnchorMessage", { _showNoSpriteAnchorMessage = it })
        }
    private var _showSpriteProperties: Boolean = /*@INITAUTO SpriteTool.showSpriteProperties cs:50-50*/ false /*@ENDINIT*/
    var showSpriteProperties: Boolean
        get() { /*@DONE SpriteTool.ShowSpriteProperties.get cs:51-51*/
            return _showSpriteProperties
        }
        private set(value) { /*@DONE SpriteTool.ShowSpriteProperties.set cs:51-51*/
            set(_showSpriteProperties, value, "showSpriteProperties", { _showSpriteProperties = it })
        }
    private var _spriteWidthHeight: String? = null
    var spriteWidthHeight: String
        get() { /*@DONE SpriteTool.SpriteWidthHeight.get cs:54-54*/
            return _spriteWidthHeight ?: ""
        }
        set(value) { /*@DONE SpriteTool.SpriteWidthHeight.set cs:54-54*/
            set(_spriteWidthHeight, value, "spriteWidthHeight", { _spriteWidthHeight = it }) { _ -> updateSpriteFormat(false) }
        }
    private var _spriteIs256Color: Boolean = false
    var spriteIs256Color: Boolean
        get() { /*@DONE SpriteTool.SpriteIs256Color.get cs:57-57*/
            return _spriteIs256Color
        }
        set(value) { /*@DONE SpriteTool.SpriteIs256Color.set cs:57-57*/
            set(_spriteIs256Color, value, "spriteIs256Color", { _spriteIs256Color = it }) { _ -> updateSpriteFormat(true) }
        }
    private var _spriteIsTilemap: Boolean = false
    var spriteIsTilemap: Boolean
        get() { /*@DONE SpriteTool.SpriteIsTilemap.get cs:61-61*/
            return _spriteIsTilemap
        }
        set(value) { /*@DONE SpriteTool.SpriteIsTilemap.set cs:61-74*/
            set(_spriteIsTilemap, value, "spriteIsTilemap", { _spriteIsTilemap = it }) { _ ->
                val split = spriteWidthHeight.uppercase().trim().split("X")
                val widthRef = Ref(0)
                val heightRef = Ref(0)
                if (split.size == 2 && tryParseInt(split[0], widthRef) && tryParseInt(split[1], heightRef)) {
                    var width = widthRef.value
                    var height = heightRef.value
                    if (_spriteIsTilemap) {
                        width *= 4
                        height *= 4
                    } else {
                        width = Math.max(1, width / 4)
                        height = Math.max(1, height / 4)
                    }
                    set(_spriteWidthHeight, "" + width + "x" + height, "spriteWidthHeight", { _spriteWidthHeight = it })
                }
                updateSpriteFormat(false)
            }
        }
    private var _spritePaletteHint: String = /*@INITAUTO SpriteTool.spritePaletteHint cs:77-77*/ "" /*@ENDINIT*/
    var spritePaletteHint: String
        get() { /*@DONE SpriteTool.SpritePaletteHint.get cs:78-78*/
            return _spritePaletteHint
        }
        set(value) { /*@DONE SpriteTool.SpritePaletteHint.set cs:78-78*/
            set(_spritePaletteHint, value, "spritePaletteHint", { _spritePaletteHint = it }) { _ -> updateSpriteFormat(false) }
        }
    private fun updateSpriteFormat(read256ColorFlag: Boolean) { /*@DONE SpriteTool.UpdateSpriteFormat/1 cs:80-135*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val existing = model.getNextRun(_spriteAddress) as? ISpriteRun
        var isDefault = false
        val spriteRun: ISpriteRun
        if (existing == null || existing.start != _spriteAddress) {
            spriteRun = SpriteRun(model, _spriteAddress, readDefaultSpriteFormat())
            isDefault = true
        } else {
            spriteRun = existing
        }
        var bits = if (spriteIs256Color) 8 else 4
        if (!read256ColorFlag) bits = spriteRun.spriteFormat.bitsPerPixel

        if (spriteWidthHeight.lowercase().trim() == "tiles") {
            val lzRun = spriteRun as? LZRun
            if (lzRun != null && lzRun.decompressedLength % (8 * bits) == 0) {
                model.observeRunWritten(history.currentChange, LzTilesetRun(TilesetFormat(bits, _spritePaletteHint), model, _spriteAddress))
                viewPort.refresh()
                loadSprite()
            } else {
                val tileSize = bits * 8
                val tileCount = Math.max(1, spriteRun.length / tileSize)
                model.observeRunWritten(history.currentChange, TilesetRun(TilesetFormat(bits, tileCount, -1, _spritePaletteHint), model, _spriteAddress))
                viewPort.refresh()
                loadSprite()
            }
        }

        var split = spriteWidthHeight.uppercase().trim().split("X")
        var availableLength = model.getNextAnchor(spriteRun.start + spriteRun.length).start - spriteRun.start
        val tilesRef = Ref(0)
        if (split.size == 1 && spriteRun !is LZRun && tryParseInt(split[0], tilesRef)) return
        if (split.size != 2) return
        val widthRef = Ref(0)
        val heightRef = Ref(0)
        if (!tryParseInt(split[0], widthRef) || !tryParseInt(split[1], heightRef)) return
        val width = widthRef.value
        val height = heightRef.value

        val newFormat = SpriteFormat(bits, width, height, _spritePaletteHint)

        var desiredUncompressedLength = newFormat.tileWidth * newFormat.tileHeight * 8 * newFormat.bitsPerPixel
        if (_spriteIsTilemap) desiredUncompressedLength /= newFormat.bitsPerPixel * 4
        if (spriteRun is LZRun) availableLength = LZRun.decompress(model, spriteRun.start)?.size ?: 0
        if (availableLength < desiredUncompressedLength) {
            viewPort.raiseError("Need " + desiredUncompressedLength + " bytes, but only " + availableLength + " bytes available.")
        } else if (_spriteIsTilemap && spriteRun is LZRun) {
            split = _spritePaletteHint.split("|")
            val tileset = split[0]
            var tilesetTableMember: String? = null
            if (split.size > 1) tilesetTableMember = split[1]
            val tilemapFormat = TilemapFormat(bits, width, height, tileset, tilesetTableMember)
            model.observeRunWritten(history.currentChange, LzTilemapRun(tilemapFormat, model, spriteRun.start, spriteRun.pointerSources))
            viewPort.refresh()
            loadSprite()
        } else if (_spriteIsTilemap && spriteRun !is LZRun) {
            // uncompressed tilemaps are not currently supported, so just no-op.
        } else {
            if (!isDefault && !newFormat.equals(spriteRun.spriteFormat)) {
                model.observeRunWritten(history.currentChange, spriteRun.duplicate(newFormat))
                viewPort.refresh()
            }
            loadSprite()
        }
    }
    private var _gotoSpriteAddress: StubCommand? = null
    private var _isSprite: StubCommand? = null
    val isSprite: ICommand
        get() { /*@DONE SpriteTool.IsSprite.get cs:138-138*/
            return _isSprite ?: stubCommand({ executeIsSprite() }).also { _isSprite = it }
        }
    val gotoSpriteAddress: ICommand
        get() { /*@DONE SpriteTool.GotoSpriteAddress.get cs:139-139*/
            return _gotoSpriteAddress ?: stubCommand({ executeGotoSpriteAddress() }).also { _gotoSpriteAddress = it }
        }
    private fun executeGotoSpriteAddress() { /*@DONE SpriteTool.ExecuteGotoSpriteAddress/1 cs:140-205*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val run = model.getNextRun(_spriteAddress) ?: NoInfoRun.nullRun
        viewPort.goto?.execute(_spriteAddress)

        if (run is ISpriteRun && run.start == _spriteAddress) { loadSprite(); updateSpriteProperties() }
        if ((run !is NoInfoRun && run !is PCSRun) || run.start != _spriteAddress) return

        val decompressed = LZRun.decompress(model, run.start)
        if (decompressed == null) {
            val nextRun = model.getNextAnchor(_spriteAddress + 1)
            val length = nextRun.start - _spriteAddress
            if (length % 32 != 0) {
                viewPort.raiseError("Could not autodetect an uncompressed sprite at that address.")
                return
            }
            val tileCount = length / 32
            val width = Math.sqrt(tileCount.toDouble()).toInt()
            val height = width
            val newRun = SpriteRun(model, _spriteAddress, SpriteFormat(4, width, height, null))
            if (model.getAnchorFromAddress(-1, _spriteAddress).isNullOrEmpty()) {
                model.observeAnchorWritten(history.currentChange, HardcodeTablesModel.defaultSpriteNamespace + "." + _spriteAddress.toHex(6), newRun)
            } else {
                model.observeRunWritten(history.currentChange, newRun)
            }
        } else {
            var tileCount = decompressed.size / 32
            var isTilemap = false
            if (decompressed.size % 32 != 0) {
                if (decompressed.size % 2 == 0) {
                    // not a sprite, but it is a tileset
                    tileCount = decompressed.size / 2
                    isTilemap = true
                } else {
                    viewPort.raiseError("Could not autodetect a compressed sprite at that address.")
                    return
                }
            }
            var width = Math.sqrt(tileCount.toDouble()).toInt()
            var height = width
            while (isTilemap && width * height != tileCount) { // tilemaps need to use all the existing data space to allow us to give them a name
                if (width * height < tileCount) {
                    width += 1
                } else {
                    height -= 1
                }
                if (height == 1) width = tileCount
            }
            val spriteRun: ISpriteRun
            var newRunName: String
            if (isTilemap) {
                newRunName = HardcodeTablesModel.defaultTilemapNamespace + "." + _spriteAddress.toHex(6)
                spriteRun = LzTilemapRun(TilemapFormat(4, width, height, ""), model, _spriteAddress, run.pointerSources)
            } else {
                newRunName = HardcodeTablesModel.defaultSpriteNamespace + "." + _spriteAddress.toHex(6)
                spriteRun = LzSpriteRun(SpriteFormat(4, width, height, null), model, _spriteAddress, run.pointerSources)
            }
            val existingName = model.getAnchorFromAddress(-1, _spriteAddress)
            if (!existingName.isNullOrEmpty()) newRunName = existingName
            model.clearFormat(history.currentChange, spriteRun.start, spriteRun.length)
            model.observeAnchorWritten(history.currentChange, newRunName, spriteRun)
        }

        viewPort.refresh()
        loadSprite()
        updateSpriteProperties()
    }
    private fun executeIsSprite() { /*@DONE SpriteTool.ExecuteIsSprite/1 cs:206-213*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val initialStart = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        var checkAddress = initialStart
        while ((model.getNextRun(checkAddress) ?: NoInfoRun.nullRun).start > checkAddress && checkAddress > initialStart - 0x20) checkAddress--
        spriteAddress = checkAddress
        executeGotoSpriteAddress()
        viewPort.tools!!.selectedIndex = viewPort.tools!!.indexOf(this)
    }
    fun updateSpriteProperties() { /*@DONE SpriteTool.UpdateSpriteProperties/1 cs:215-245*/
        val model = this.model!!
        val run = model.getNextRun(_spriteAddress) as? ISpriteRun
        if (run != null && run.start == _spriteAddress) {
            val format = run.spriteFormat
            showNoSpriteAnchorMessage = false
            showSpriteProperties = true
            _spriteWidthHeight = format.tileWidth.toString() + "x" + format.tileHeight
            if (run is ITilesetRun) _spriteWidthHeight = "tiles"
            if (run is LzTilemapRun) {
                _spriteIsTilemap = true
                _spritePaletteHint = run.format.matchingTileset + (if (run.format.tilesetTableMember.isNullOrEmpty()) "" else "|" + run.format.tilesetTableMember)
            } else {
                _spriteIsTilemap = false
                _spritePaletteHint = format.paletteHint ?: ""
            }
            _spriteIs256Color = format.bitsPerPixel == 8
            notifyPropertyChanged("spriteWidthHeight")
            notifyPropertyChanged("spriteIs256Color")
            notifyPropertyChanged("spriteIsTilemap")
            notifyPropertyChanged("spritePaletteHint")
            _importPair.raiseCanExecuteChanged()
            _exportPair.raiseCanExecuteChanged()
            (openInImageTab as? StubCommand)?.raiseCanExecuteChanged()
        } else {
            showNoSpriteAnchorMessage = true
            showSpriteProperties = true
            val format = readDefaultSpriteFormat()
            _spriteIsTilemap = false
            _spritePaletteHint = format.paletteHint ?: ""
        }
        notifyPropertyChanged("showSpriteProperties")
    }
    private var _showNoPaletteAnchorMessage: Boolean = /*@INITAUTO SpriteTool.showNoPaletteAnchorMessage cs:251-251*/ true /*@ENDINIT*/
    var showNoPaletteAnchorMessage: Boolean
        get() { /*@DONE SpriteTool.ShowNoPaletteAnchorMessage.get cs:252-252*/
            return _showNoPaletteAnchorMessage
        }
        set(value) { /*@DONE SpriteTool.ShowNoPaletteAnchorMessage.set cs:252-252*/
            set(_showNoPaletteAnchorMessage, value, "showNoPaletteAnchorMessage", { _showNoPaletteAnchorMessage = it })
        }
    val showPaletteProperties: Boolean
        get() { /*@DONE SpriteTool.ShowPaletteProperties.get cs:254-254*/
            return !_showNoPaletteAnchorMessage
        }
    private var _paletteIs256Color: Boolean = false
    var paletteIs256Color: Boolean
        get() { /*@DONE SpriteTool.PaletteIs256Color.get cs:257-257*/
            return _paletteIs256Color
        }
        set(value) { /*@DONE SpriteTool.PaletteIs256Color.set cs:257-257*/
            set(_paletteIs256Color, value, "paletteIs256Color", { _paletteIs256Color = it }) { _ -> updatePaletteFormat() }
        }
    private var _palettePages: String = ""
    var palettePages: String
        get() { /*@DONE SpriteTool.PalettePages.get cs:260-260*/
            return _palettePages
        }
        set(value) { /*@DONE SpriteTool.PalettePages.set cs:260-260*/
            set(_palettePages, value, "palettePages", { _palettePages = it }) { _ -> updatePaletteFormat() }
        }
    private fun updatePaletteFormat() { /*@DONE SpriteTool.UpdatePaletteFormat/1 cs:262-270*/
        val model = this.model!!
        val palRun = model.getNextRun(_paletteAddress) as? IPaletteRun
        if (palRun == null || palRun.start != _paletteAddress) return
        val bits = if (_paletteIs256Color) 8 else 4
        val newFormat = Ref(PaletteFormat())
        if (!PaletteRun.tryParsePaletteFormat(bits.toString() + ":" + _palettePages, newFormat)) return
        model.observeRunWritten(history.currentChange, palRun.duplicate(newFormat.value))
        viewPort!!.refresh()
        loadPalette()
    }
    private var _gotoPaletteAddress: StubCommand? = null
    private var _isPalette: StubCommand? = null
    val isPalette: ICommand
        get() { /*@DONE SpriteTool.IsPalette.get cs:273-273*/
            return _isPalette ?: stubCommand({ executeIsPalette() }).also { _isPalette = it }
        }
    val gotoPaletteAddress: ICommand
        get() { /*@DONE SpriteTool.GotoPaletteAddress.get cs:274-274*/
            return _gotoPaletteAddress ?: stubCommand({ executeGotoPaletteAddress() }).also { _gotoPaletteAddress = it }
        }
    private fun executeGotoPaletteAddress() { /*@DONE SpriteTool.ExecuteGotoPaletteAddress/1 cs:275-315*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val run = model.getNextRun(_paletteAddress) ?: NoInfoRun.nullRun
        viewPort.goto?.execute(_paletteAddress)
        if (run is IPaletteRun && run.start == _paletteAddress) { loadPalette(); updatePaletteProperties() }
        if ((run !is NoInfoRun && run !is PCSRun) || run.start != _paletteAddress) return

        val existingName = model.getAnchorFromAddress(-1, _paletteAddress)
        var newName = HardcodeTablesModel.defaultPaletteNamespace + "." + _paletteAddress.toHex(6)
        if (!existingName.isNullOrEmpty()) newName = existingName
        val decompressed = LZRun.decompress(model, run.start)
        if (decompressed == null) {
            val nextRun = model.getNextAnchor(_paletteAddress + 1)
            val length = nextRun.start - _paletteAddress
            if (length % 32 != 0) {
                viewPort.raiseError("Could not autodetect an uncompressed palette at that address.")
                return
            }
            val pages = Math.min(length / 32, 16)

            for (i in 0 until pages * 16) {
                if (model.readMultiByteValue(run.start + i * 2, 2) >= 0x8000) {
                    viewPort.raiseError("Palette colors only use 15 bits, but the high bit it set at " + (run.start + i * 2 + 1).toHex(6) + ".")
                    return
                }
            }

            model.observeAnchorWritten(history.currentChange, newName, PaletteRun(_paletteAddress, PaletteFormat(4, pages)))
        } else {
            val byteCount = decompressed.size
            if (byteCount % 32 != 0) {
                viewPort.raiseError("Could not autodetect a compressed sprite at that address.")
                return
            }
            val pages = Math.min(byteCount / 32, 16)
            model.observeAnchorWritten(history.currentChange, newName, LzPaletteRun(PaletteFormat(4, pages), model, _paletteAddress))
        }

        viewPort.refresh()
        loadPalette()
        updatePaletteProperties()
    }
    private fun executeIsPalette() { /*@DONE SpriteTool.ExecuteIsPalette/1 cs:316-323*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val initialStart = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        var checkAddress = initialStart
        while ((model.getNextRun(checkAddress) ?: NoInfoRun.nullRun).start > checkAddress && checkAddress > initialStart - 0x20) checkAddress--
        paletteAddress = checkAddress
        executeGotoPaletteAddress()
        viewPort.tools!!.selectedIndex = viewPort.tools!!.indexOf(this)
    }
    private fun updatePaletteProperties() { /*@DONE SpriteTool.UpdatePaletteProperties/1 cs:325-335*/
        val model = this.model!!
        val palRun = model.getNextRun(_paletteAddress) as? IPaletteRun
        if (palRun != null && palRun.start == _paletteAddress) {
            val format = palRun.paletteFormat
            set(_paletteIs256Color, format.bits == 8, "paletteIs256Color", { _paletteIs256Color = it })
            set(_palettePages, PaletteRun.getPalettePages(format), "palettePages", { _palettePages = it })
            showNoPaletteAnchorMessage = false
        } else {
            showNoPaletteAnchorMessage = true
        }
        notifyPropertyChanged("showPaletteProperties")
    }
    val canExportMany: Boolean
        get() { /*@DONE SpriteTool.CanExportMany.get cs:341-341*/
            return hasMultipleSpritePages && exportPair.canExecute(null)
        }
    private var _exportMany: StubCommand? = null
    val exportMany: ICommand
        get() { /*@DONE SpriteTool.ExportMany.get cs:344-344*/
            return _exportMany ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executeExportMany(fs) }, { _ -> canExportMany }).also { _exportMany = it }
        }
    private fun executeExportMany(fs: IFileSystem) { /*@DONE SpriteTool.ExecuteExportMany/1 cs:346-353*/
        val horizontal = VisualOption()
        horizontal.index = 0
        horizontal.option = "Horizontal"
        horizontal.shortDescription = "Left-Right"
        horizontal.description = "Stack the pages from left to right."
        val vertical = VisualOption()
        vertical.index = 1
        vertical.option = "Vertical"
        vertical.shortDescription = "Up-Down"
        vertical.description = "Stack the pages from top to bottom."
        val choice = fs.showOptions("Export Multi-Page Image", "How would you like to arrange the pages?", null, horizontal, vertical)

        executeExportMany(fs, ImageExportMode.fromValue(choice + 1))
    }
    fun executeExportMany(fs: IFileSystem, choice: ImageExportMode) { /*@DONE SpriteTool.ExecuteExportMany/2 cs:355-388*/
        val model = this.model!!
        val manyPixels: Array<IntArray>
        if (choice == ImageExportMode.Horizontal) {
            manyPixels = Array(pixelWidth * spritePages) { IntArray(pixelHeight) }
        } else if (choice == ImageExportMode.Vertical) {
            manyPixels = Array(pixelWidth) { IntArray(pixelHeight * spritePages) }
        } else {
            return
        }

        val spriteRun = model.getNextRun(_spriteAddress) as? ISpriteRun ?: return
        val paletteRun = model.getNextRun(_paletteAddress) as? IPaletteRun ?: return
        val renderPalette = paletteRun.allColors(model) ?: return

        for (i in 0 until spritePages) {
            val xPageOffset = if (choice == ImageExportMode.Horizontal) i * pixelWidth else 0
            val yPageOffset = if (choice == ImageExportMode.Horizontal) 0 else i * pixelHeight
            val pagePixels = spriteRun.getPixels(model, i, -1) ?: continue
            val palOffset = (i % paletteRun.pages) * 16
            for (x in 0 until pixelWidth) {
                for (y in 0 until pixelHeight) {
                    var pixel = pagePixels[x][y] + palOffset
                    pixel = Math.max(0, pixel - (paletteFormat.initialBlankPages shl 4))
                    manyPixels[xPageOffset + x][yPageOffset + y] = pixel
                }
            }
        }

        if (renderPalette.size > 256) {
            val rendered = render(manyPixels, renderPalette, 0, 0)
            fs.saveImage(rendered, manyPixels.size)
        } else {
            fs.saveImage(manyPixels, renderPalette)
        }
    }
    private val _importPair: StubCommand = /*@INITDONE SpriteTool.importPair cs:392-393*/ StubCommand() /*@ENDINIT*/
    private val _exportPair: StubCommand = /*@INITDONE SpriteTool.exportPair cs:392-394*/ StubCommand() /*@ENDINIT*/
    private val prevSpritePage: StubCommand = /*@INITDONE SpriteTool.prevSpritePage cs:392-395*/ StubCommand() /*@ENDINIT*/
    private val _nextSpritePage: StubCommand = /*@INITDONE SpriteTool.nextSpritePage cs:392-396*/ StubCommand() /*@ENDINIT*/
    private val prevPalPage: StubCommand = /*@INITDONE SpriteTool.prevPalPage cs:392-397*/ StubCommand() /*@ENDINIT*/
    private val nextPalPage: StubCommand = /*@INITDONE SpriteTool.nextPalPage cs:392-398*/ StubCommand() /*@ENDINIT*/
    private var _spriteAddress: Int = 0
    var spriteAddress: Int
        get() { /*@DONE SpriteTool.SpriteAddress.get cs:402-402*/
            return _spriteAddress
        }
        set(value) { /*@DONE SpriteTool.SpriteAddress.set cs:403-428*/
            val model = this.model!!
            val run = model.getNextRun(value) as? ISpriteRun
            if (!tryUpdate(_spriteAddress, value, "spriteAddress") { _spriteAddress = it }) {
                if (!runPropertiesChanged(run)) {
                    (openInImageTab as? StubCommand)?.raiseCanExecuteChanged()
                    return
                }
            }

            spriteAddressText = _spriteAddress.toAddress()
            _importPair.raiseCanExecuteChanged()
            _exportPair.raiseCanExecuteChanged()
            (openInImageTab as? StubCommand)?.raiseCanExecuteChanged()

            if (run == null || run.start != _spriteAddress) {
                spritePages = 1
                _spritePage = 0
            } else {
                spritePages = run.pages
                if (_spritePage >= spritePages) _spritePage = 0
                notifyPropertyChanged("hasMultipleSpritePages")
            }
            updateSpriteProperties()
            loadSprite()
            paletteAddress = findMatchingPalette(model, run, _paletteAddress)
        }
    private var _paletteAddress: Int = 0
    var paletteAddress: Int
        get() { /*@DONE SpriteTool.PaletteAddress.get cs:433-433*/
            return _paletteAddress
        }
        set(value) { /*@DONE SpriteTool.PaletteAddress.set cs:434-451*/
            val model = this.model!!
            if (!tryUpdate(_paletteAddress, value, "paletteAddress") { _paletteAddress = it }) return
            paletteAddressText = _paletteAddress.toAddress()
            _importPair.raiseCanExecuteChanged()
            _exportPair.raiseCanExecuteChanged()
            _openInImageTab?.raiseCanExecuteChanged()
            val paletteRun = model.getNextRun(value) as? IPaletteRun
            if (paletteRun == null) {
                palPages = 1
                palPage = 0
            } else {
                palPages = paletteRun.pages
                if (palPage >= palPages) palPage = 0
                notifyPropertyChanged("hasMultiplePalettePages")
            }
            updatePaletteProperties()
            loadPalette()
        }
    private var _spriteAddressText: String = ""
    private var _paletteAddressText: String = ""
    var spriteAddressText: String
        get() { /*@DONE SpriteTool.SpriteAddressText.get cs:484-484*/
            return _spriteAddressText
        }
        set(value) { /*@DONE SpriteTool.SpriteAddressText.set cs:485-493*/
            if (_spriteAddressText == value) return
            val newSpriteAddressText = sanitizeAddressText(value)
            val cleaned = newSpriteAddressText.filter { c -> c != '<' && c != '>' }
            val addressRef = Ref(0)
            val address = if (tryParseHexInt(cleaned, addressRef)) addressRef.value else Pointer.null_
            if (_spriteAddress != address) spriteAddress = address
            _spriteAddressText = newSpriteAddressText
            notifyPropertyChanged("spriteAddressText")
        }
    var paletteAddressText: String
        get() { /*@DONE SpriteTool.PaletteAddressText.get cs:496-496*/
            return _paletteAddressText
        }
        set(value) { /*@DONE SpriteTool.PaletteAddressText.set cs:497-505*/
            if (_paletteAddressText == value) return
            val newPaletteAddressText = sanitizeAddressText(value)
            val cleaned = newPaletteAddressText.filter { c -> c != '<' && c != '>' }
            val addressRef = Ref(0)
            val address = if (tryParseHexInt(cleaned, addressRef)) addressRef.value else Pointer.null_
            if (_paletteAddress != address) paletteAddress = address
            _paletteAddressText = newPaletteAddressText
            notifyPropertyChanged("paletteAddressText")
        }
    val hasMultipleSpritePages: Boolean
        get() { /*@DONE SpriteTool.HasMultipleSpritePages.get cs:508-508*/
            return spritePages > 1
        }
    val hasMultiplePalettePages: Boolean
        get() { /*@DONE SpriteTool.HasMultiplePalettePages.get cs:509-509*/
            return palPages > 1
        }
    val importPair: ICommand
        get() { /*@DONE SpriteTool.ImportPair.get cs:511-511*/
            return _importPair
        }
    val exportPair: ICommand
        get() { /*@DONE SpriteTool.ExportPair.get cs:512-512*/
            return _exportPair
        }
    val previousSpritePage: ICommand
        get() { /*@DONE SpriteTool.PreviousSpritePage.get cs:513-513*/
            return prevSpritePage
        }
    val nextSpritePage: ICommand
        get() { /*@DONE SpriteTool.NextSpritePage.get cs:514-514*/
            return _nextSpritePage
        }
    val previousPalettePage: ICommand
        get() { /*@DONE SpriteTool.PreviousPalettePage.get cs:515-515*/
            return prevPalPage
        }
    val nextPalettePage: ICommand
        get() { /*@DONE SpriteTool.NextPalettePage.get cs:516-516*/
            return nextPalPage
        }
    private var _openInImageTab: StubCommand? = null
    val openInImageTab: ICommand
        get() { /*@DONE SpriteTool.OpenInImageTab.get cs:519-529*/
            return _openInImageTab ?: stubCommand({ viewPort!!.openImageEditorTab(_spriteAddress, _spritePage, palPage) }, { canExecuteOpenInImageTab() }).also { _openInImageTab = it }
        }
    override var pixelWidth: Int = 0
    override var pixelHeight: Int = 0
    override val transparent: Short
        get() { /*@DONE SpriteTool.Transparent.get cs:533-533*/
            return (-1).toShort()
        }
    var paletteWidth: Int = 0
        private set
    var paletteHeight: Int = 0
        private set
    override var pixelData: ShortArray = ShortArray(0)
    lateinit var colors: PaletteCollection
        private set
    val isReadOnly: Boolean
        get() { /*@DONE SpriteTool.IsReadOnly.get cs:541-541*/
            return true
        }
    constructor(viewPort: ViewPort, history: ChangeHistory<ModelDelta>) { /*@DONE SpriteTool.<init>/1 cs:543-580*/
        this.viewPort = viewPort
        this.history = history
        colors = PaletteCollection(viewPort, viewPort.model, history)
        colors.colorsChanged += { _, _ -> loadPalette(); loadSprite() }
        colors.paletteRepointed += { _, newPaletteAddress -> handlePaletteRepoint(newPaletteAddress) }
        model = viewPort.model
        _spriteAddress = Pointer.null_
        _paletteAddress = Pointer.null_

        _importPair.canExecute = { _ -> canExecuteImportPair() }
        _exportPair.canExecute = { _ -> canExecuteExportPair() }
        prevSpritePage.canExecute = { _ -> _spritePage > 0 }
        _nextSpritePage.canExecute = { _ -> _spritePage < spritePages - 1 }
        prevPalPage.canExecute = { _ -> palPage > 0 }
        nextPalPage.canExecute = { _ -> palPage < palPages - 1 }

        _importPair.execute = { arg -> (arg as? IFileSystem)?.let { importSpriteAndPalette(it) } }
        _exportPair.execute = { arg -> (arg as? IFileSystem)?.let { exportSpriteAndPalette(it) } }
        prevSpritePage.execute = { _ -> _spritePage -= 1; loadSprite() }
        _nextSpritePage.execute = { _ -> _spritePage += 1; loadSprite() }
        prevPalPage.execute = { _ -> palPage -= 1; loadPalette() }
        nextPalPage.execute = { _ -> palPage += 1; loadPalette() }

        loadPalette()
    }
    private fun handlePaletteRepoint(address: Int) { /*@DONE SpriteTool.HandlePaletteRepoint/1 cs:582-585*/
        paletteAddress = address
        viewPort!!.raiseMessage("Palette moved to " + address.toHex(6) + ". Pointers were updated.")
    }
    override fun dataForCurrentRunChanged() { /*@DONE SpriteTool.DataForCurrentRunChanged/1 cs:587-592*/
        loadSprite()
        loadPalette()
        updateSpriteProperties()
        updatePaletteProperties()
    }
    fun tryImport(fullPath: String, importType: String): ErrorInfo { /*@DONE SpriteTool.TryImport/1 cs:617-630*/
        val import = ImportType.entries.firstOrNull { it.name.equals(importType, ignoreCase = true) }
            ?: return ErrorInfo("Expected Cautious, Greedy, or Smart, but got " + importType + ".")
        val fileSystem = viewPort!!.mapEditor!!.fileSystem
        try {
            val (image, width) = fileSystem.loadImage(fullPath)
            if (image == null) return ErrorInfo("Unable to load image " + fullPath + ".")
            importSpriteAndPalette(fileSystem, image, width, import)
            return ErrorInfo.noError
        } catch (io: IOException) {
            return ErrorInfo(io.message ?: "")
        }
    }
    fun tryImport(fileSystem: IFileSystem, currentDirectory: String, address: Int, filePath: String, importType: ImportType): ErrorInfo { /*@DONE SpriteTool.TryImport/2 cs:632-643*/
        try {
            val path = Path.combine(currentDirectory, filePath)
            val (image, width) = fileSystem.loadImage(path)
            if (image == null) return ErrorInfo("Unable to load image " + path + ".")
            spriteAddress = address
            importSpriteAndPalette(fileSystem, image, width, importType)
            return ErrorInfo.noError
        } catch (io: IOException) {
            return ErrorInfo(io.message ?: "")
        }
    }
    fun export(fileSystem: IFileSystem, currentDirectory: String, address: Int, filePath: String): ErrorInfo { /*@DONE SpriteTool.Export/1 cs:645-657*/
        val model = this.model!!
        spriteAddress = address
        val spriteRun = model.getNextRun(_spriteAddress) as? ISpriteRun
        val paletteRun = model.getNextRun(_paletteAddress) as? IPaletteRun
        if (spriteRun != null && paletteRun != null && spriteRun.spriteFormat.bitsPerPixel == 4 && (paletteRun.allColors(model)?.size ?: 0) == 16) {
            val spritePixels = spriteRun.getPixels(model, spritePage, -1)
            val paletteColors = paletteRun.getPalette(model, palettePage)
            if (spritePixels != null && paletteColors != null) {
                fileSystem.saveImage(spritePixels, paletteColors, Path.combine(currentDirectory, filePath))
                return ErrorInfo.noError
            }
        }
        return ErrorInfo("Could not export sprite at " + address.toHex(6) + ".")
    }
    private fun readDefaultSpriteFormat(): SpriteFormat { /*@DONE SpriteTool.ReadDefaultSpriteFormat/1 cs:659-665*/
        var widthHeight = _spriteWidthHeight
        if (widthHeight == null || !widthHeight.contains("x")) {
            widthHeight = "4x4"
            _spriteWidthHeight = widthHeight
        }
        val parts = widthHeight.split('x')
        val widthRef = Ref(0)
        val heightRef = Ref(0)
        val width = if (tryParseInt(parts[0], widthRef)) widthRef.value else 4
        val height = if (parts.size < 2 || !tryParseInt(parts[1], heightRef)) 4 else heightRef.value
        return SpriteFormat(4, width, height, null)
    }
    private fun loadSprite() { /*@DONE SpriteTool.LoadSprite/1 cs:667-699*/
        val model = this.model!!
        val existing = model.getNextRun(_spriteAddress) as? ISpriteRun
        val run: ISpriteRun
        if (existing == null || existing.start != _spriteAddress) {
            val format = readDefaultSpriteFormat()
            run = SpriteRun(model, _spriteAddress, format)
            pixels = null
            pixelWidth = 0
            pixelHeight = 0
        } else {
            run = existing
        }
        if (0 <= _spriteAddress && _spriteAddress < model.count) {
            val loaded = run.getPixels(model, _spritePage, -1)
            pixels = loaded
            pixelWidth = loaded?.getLength(0) ?: 0
            pixelHeight = loaded?.getLength(1) ?: 0
        }
        val renderPalette = getRenderPalette(run)
        pixelData = render(pixels, renderPalette, paletteFormat.initialBlankPages, _spritePage)
        notifyPropertyChanged("pixelWidth")
        notifyPropertyChanged("pixelHeight")
        prevSpritePage.raiseCanExecuteChanged()
        _nextSpritePage.raiseCanExecuteChanged()
        notifyPropertyChanged("pixelData")
        notifyPropertyChanged("canExportMany")
        _exportMany?.raiseCanExecuteChanged()

        // update scale
        if (pixelWidth > maxSpriteWidth) {
            spriteScale = .5
        } else if (pixelWidth * 2 < maxSpriteWidth) {
            spriteScale = 2.0
        } else {
            spriteScale = 1.0
        }
    }
    private fun getRenderPalette(sprite: ISpriteRun?): List<Short> { /*@DONE SpriteTool.GetRenderPalette/1 cs:701-716*/
        val model = this.model!!
        val currentPalette: List<Short> = palette?.toList() ?: ArrayList<Short>()
        if (sprite == null) return currentPalette
        if (sprite.spriteFormat.bitsPerPixel == 1) {
            return listOf(0.toShort(), 0x7FFF.toShort())
        }
        if (sprite.spriteFormat.bitsPerPixel == 2) {
            return TileViewModel.createDefaultPalette(4).toList()
        }
        if (sprite.spriteFormat.bitsPerPixel == 8) {
            val paletteRun = model.getNextRun(_paletteAddress) as? IPaletteRun
            if (paletteRun != null) return paletteRun.allColors(model) ?: ArrayList<Short>()
        }
        if (sprite !is LzTilemapRun) return currentPalette
        sprite.findMatchingTileset(model)
        val palRun = model.getNextRun(_paletteAddress) as? IPaletteRun
        if (palRun != null) return palRun.allColors(model) ?: ArrayList<Short>()
        return currentPalette
    }
    private fun loadPalette() { /*@DONE SpriteTool.LoadPalette/1 cs:718-743*/
        val model = this.model
        val run = model?.getNextRun(_paletteAddress) as? IPaletteRun
        val loadedPalette: ShortArray
        if (run == null) {
            loadedPalette = TileViewModel.createDefaultPalette(0x10)
        } else {
            palPages = run.pages
            palPage = Math.min(palPage, palPages - 1)
            loadedPalette = (run.getPalette(model, palPage) ?: ArrayList<Short>()).toShortArray()
            paletteFormat = run.paletteFormat
        }
        palette = loadedPalette

        paletteWidth = Math.sqrt(loadedPalette.size.toDouble()).toInt()
        paletteHeight = Math.ceil(loadedPalette.size.toDouble() / paletteWidth).toInt()
        notifyPropertyChanged("paletteWidth")
        notifyPropertyChanged("paletteHeight")
        prevPalPage.raiseCanExecuteChanged()
        nextPalPage.raiseCanExecuteChanged()

        colors.sourcePalettePointer = run?.pointerSources?.firstOrNull() ?: Pointer.null_
        colors.setContents(loadedPalette.toList())
        colors.page = palPage
        colors.hasMultiplePages = palPages > 1
        pixelData = render(pixels, getRenderPalette(model?.getNextRun(_spriteAddress) as? ISpriteRun), paletteFormat.initialBlankPages, _spritePage)
        notifyPropertyChanged("hasMultiplePalettePages")
        notifyPropertyChanged("pixelData")
    }
    private fun runPropertiesChanged(run: ISpriteRun?): Boolean { /*@DONE SpriteTool.RunPropertiesChanged/1 cs:752-758*/
        if (run == null) return false
        if (run.spriteFormat.tileWidth * 8 != pixelWidth) return true
        if (run.spriteFormat.tileHeight * 8 != pixelHeight) return true
        if (run.pages != spritePages) return true
        return false
    }
    fun importSpriteAndPalette(fileSystem: IFileSystem) { /*@DONE SpriteTool.ImportSpriteAndPalette/1 cs:774-785*/
        val model = this.model!!
        val filename = Ref<String?>(null)
        val loadedPixels = Ref<Array<IntArray>?>(null)
        val loadedPalette = Ref<List<Short>?>(null)
        val paletteRun = model.getNextRun(_paletteAddress) as? IPaletteRun
        if (paletteRun != null && fileSystem.tryLoadIndexedImage(filename, loadedPixels, loadedPalette) && loadedPalette.value!!.size <= paletteRun.pages * 16) {
            importSpriteAndPalette(fileSystem, loadedPixels.value, loadedPalette.value!!)
            return
        }
        if (filename.value == null && paletteRun != null) return // they didn't choose a file... they hit cancel. Don't continue trying to import.

        val (image, width) = fileSystem.loadImage(filename.value)
        importSpriteAndPalette(fileSystem, image, width)
    }
    private fun importSpriteAndPalette(fileSystem: IFileSystem, pixels: Array<IntArray>?, palette: List<Short>, importType: ImportType = ImportType.Unknown) { /*@DONE SpriteTool.ImportSpriteAndPalette/2 cs:787-800*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        if (pixels == null) return
        val spriteRunRef = Ref<ISpriteRun?>(null)
        val paletteRunRef = Ref<IPaletteRun?>(null)
        if (!tryValidate(pixels, palette, spriteRunRef, paletteRunRef)) return
        val spriteRun = spriteRunRef.value ?: return
        val paletteRun = paletteRunRef.value
        val relatedSprites = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
        val relatedPalettes = spriteRun.findRelatedPalettes(model)
        val relatedImageCount = relatedSprites.size * relatedPalettes.size
        if (pixels.getLength(0) == pixelWidth && pixels.getLength(1) == pixelHeight) {
            importSinglePageSpriteAndPalette(fileSystem, pixels, palette, spriteRun, paletteRun, importType)
            viewPort.refresh() // need to refresh in case the model resized during the import
        } else {
            val (image, width) = unindex(pixels, palette)
            importSpriteAndPalette(fileSystem, image, width, importType)
        }
    }
    private fun importSpriteAndPalette(fileSystem: IFileSystem, image: ShortArray?, width: Int, importType: ImportType = ImportType.Unknown) { /*@DONE SpriteTool.ImportSpriteAndPalette/3 cs:802-849*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        if (image == null) return
        val spriteRunRef = Ref<ISpriteRun?>(null)
        val paletteRunRef = Ref<IPaletteRun?>(null)
        if (!tryValidate(image, spriteRunRef, paletteRunRef)) return
        val spriteRun = spriteRunRef.value ?: return
        var paletteRun = paletteRunRef.value
        val height = image.size / width
        var relatedSprites: List<ISpriteRun> = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
        var relatedPalettes: List<IPaletteRun> = spriteRun.findRelatedPalettes(model)
        val relatedImageCount = relatedSprites.size * relatedPalettes.size
        if (width == pixelWidth && height == pixelHeight) {
            importSinglePageSpriteAndPalette(fileSystem, image, spriteRun, paletteRun, importType)
        } else if (width == pixelWidth * spritePages && height == pixelHeight) {
            importWideSpriteAndPalette(fileSystem, image, spriteRun, paletteRun, importType)
        } else if (width == pixelWidth && height == pixelHeight * spritePages) {
            importTallSpriteAndPalette(fileSystem, image, spriteRun, paletteRun, importType)
        } else if (width == pixelWidth * relatedImageCount && height == pixelHeight) {
            val images = splitHorizontally(image, width, relatedImageCount)
            var desiredImportType = ImportType.Greedy
            var i = 0
            while (i < relatedSprites.size) {
                var allowSpriteEdits = true
                var j = 0
                while (j < relatedPalettes.size) {
                    val imageIndex = relatedPalettes.size * i + j
                    val failurePoint = importSinglePageSpriteAndPalette(fileSystem, images[imageIndex], relatedSprites[i], relatedPalettes[j], desiredImportType, allowSpriteEdits)

                    // import may have failed if it's was trying to do a Greedy import with no sprite edits allowed
                    if (failurePoint.x < pixelWidth || failurePoint.y < pixelHeight) {
                        viewPort.raiseError("Failed multi-image import: Image " + i + ", Palette " + j + " didn't match at pixel " + failurePoint + ".")
                    }
                    // still try to do the rest of the import

                    // import may have repointed sprites/palettes: refresh the related sprites/palettes cached locations.
                    val refreshedSprite = model.getNextRun(_spriteAddress) as? ISpriteRun
                    paletteRun = model.getNextRun(_paletteAddress) as? IPaletteRun
                    relatedSprites = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
                    relatedPalettes = refreshedSprite.findRelatedPalettes(model)
                    allowSpriteEdits = false
                    j += 1
                }
                desiredImportType = ImportType.Cautious
                i += 1
            }
        } else {
            var displayWidth = pixelWidth
            var displayHeight = pixelHeight
            if (Math.abs(displayWidth * spritePages - width) < Math.abs(displayWidth - width)) displayWidth *= spritePages
            else if (Math.abs(displayHeight * spritePages - height) < Math.abs(displayHeight - height)) displayHeight *= spritePages
            viewPort.raiseError("The imported width/height (" + width + "/" + height + ") doesn't match the image (" + displayWidth + "/" + displayHeight + ")!")
        }
        viewPort.refresh() // need to refresh in case the model resized during the import
    }
    private fun splitHorizontally(image: ShortArray, width: Int, count: Int): Array<ShortArray> { /*@DONE SpriteTool.SplitHorizontally/1 cs:851-862*/
        val images = Array(count) { ShortArray(image.size / count) }
        val newWidth = width / count
        for (i in 0 until image.size) {
            val j = (i / newWidth) % count
            val y = i / width
            val x = i % newWidth
            images[j][newWidth * y + x] = image[i]
        }
        return images
    }
    private fun getImportType(fileSystem: IFileSystem, dependentPageCount: Int, dependentSprites: List<ISpriteRun>, imageType: String, palette: IPaletteRun, type: ImportType, usablePalettePages: Ref<List<Int>?>): ImportType { /*@DONE SpriteTool.GetImportType/1 cs:875-918*/
        usablePalettePages.value = (0 until palette.pages).toList()
        if (type != ImportType.Unknown) return type
        val palFormat = palette.paletteFormat
        val imageDetails = ArrayList<Any>()
        val detailsLength = Math.min(3, dependentPageCount)
        for (i in 0 until detailsLength) {
            val targetIndex = i * dependentPageCount / detailsLength
            val (dependentIndex, dependentPage) = getTarget(dependentSprites, targetIndex)
            val content = ToolTipContentVisitor.buildContentForRun(model!!, -1, dependentSprites[dependentIndex].start, dependentSprites[dependentIndex], palette.start, dependentPage)
            if (content != null) imageDetails.add(content)
        }

        val palDetails = ArrayList<FlagViewModel>()
        for (i in 0 until palette.pages) {
            val n = i + palFormat.initialBlankPages
            palDetails.add(FlagViewModel("Use palette " + n))
        }

        val allDetails = ArrayList<List<Any>>()
        allDetails.add(imageDetails)
        if (palDetails.size > 1) allDetails.add(palDetails.map { it as Any })

        val smart = VisualOption()
        smart.option = "Smart"
        smart.index = ImportType.Smart.value
        smart.shortDescription = "Fix Incompatibilites Automatically"
        smart.description = "Balance the look of the new image with other images already using this palette."
        val greedy = VisualOption()
        greedy.option = "Greedy"
        greedy.index = ImportType.Greedy.value
        greedy.shortDescription = "Break " + (dependentPageCount - 1) + " other sprite" + (if (dependentPageCount > 2) "s" else "")
        greedy.description = "Ignore other images that use this palette. They'll probably look broken and that's ok."
        val cautious = VisualOption()
        cautious.option = "Cautious"
        cautious.index = ImportType.Cautious.value
        cautious.shortDescription = "Don't change palette"
        cautious.description = "Match the new image to the existing palette as closely as possible."
        val chosenOption = fileSystem.showOptions("Import Sprite",
            "This palette is used by " + dependentPageCount + " " + imageType + ". How do you want to handle the import?",
            allDetails, smart, greedy, cautious)

        usablePalettePages.value = (0 until palDetails.size).filter { i -> palDetails[i].isSet }
        return ImportType.fromValue(chosenOption)
    }
    private fun importSinglePageSpriteAndPalette(fileSystem: IFileSystem, pixels: Array<IntArray>, palette: List<Short>, spriteRun: ISpriteRun, paletteRun: IPaletteRun?, importType: ImportType, allowSpriteEdits: Boolean = true): Point { /*@DONE SpriteTool.ImportSinglePageSpriteAndPalette/1 cs:920-953*/
        val model = this.model!!
        var result = Point(spriteRun.spriteFormat.tileWidth * 8, spriteRun.spriteFormat.tileHeight * 8)

        val dependentSprites = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
        if (dependentSprites.size == 0 || // no sprites are associated with this palette. So just use the currently loaded sprite.
            (dependentSprites.size == 1 && dependentSprites[0].start == spriteRun.start && (spriteRun.pages == 1 || spriteRun.pages == paletteRun!!.pages)) || // 'I am the only sprite' case
            (dependentSprites.size == 1 && dependentSprites[0] is ITilesetRun && spriteRun is ITilemapRun) // 'My tileset is the only sprite' case
        ) {
            // easy case: a single sprite. Sprite uses the palette.
            // there may be other palettes, but we can leave them be.
            writeSpriteAndPalette(spriteRun, paletteRun, pixels, palette, paletteRun?.let { pr -> (0 until pr.pages).toList() })
            loadSprite()
            loadPalette()
            return result
        }

        // there are multiple sprites
        var dependentPageCount = dependentSprites.sumOf { s -> s.pages }
        if (paletteRun!!.pages > 1) dependentPageCount = dependentSprites.size // for multi-page palettes, only count each sprite once.
        var imageType = "images"
        if (dependentSprites.any { ds -> ds is ITilesetRun }) imageType = "tilesets"
        val usablePalPages = Ref<List<Int>?>(null)
        val choice = getImportType(fileSystem, dependentPageCount, dependentSprites, imageType, paletteRun, importType, usablePalPages)

        if (choice != ImportType.Greedy) {
            val (image, width) = unindex(pixels, palette)
            importSinglePageSpriteAndPalette(fileSystem, image, spriteRun, paletteRun, choice, allowSpriteEdits)
        } else {
            result = writeSpriteAndPalette(spriteRun, paletteRun, pixels, palette, usablePalPages.value, !allowSpriteEdits)
            loadSprite()
            loadPalette()
        }

        return result
    }
    private fun importSinglePageSpriteAndPalette(fileSystem: IFileSystem, image: ShortArray, spriteRun: ISpriteRun, paletteRun: IPaletteRun?, importType: ImportType, allowSpriteEdits: Boolean = true): Point { /*@DONE SpriteTool.ImportSinglePageSpriteAndPalette/2 cs:955-990*/
        val model = this.model!!
        var result = Point(spriteRun.spriteFormat.tileWidth * 8, spriteRun.spriteFormat.tileHeight * 8)

        val dependentSprites = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
        if (dependentSprites.size == 0 || // no sprites are associated with this palette. So just use the currently loaded sprite.
            (dependentSprites.size == 1 && dependentSprites[0].start == spriteRun.start && (spriteRun.pages == 1 || spriteRun.pages == paletteRun!!.pages)) || // 'I am the only sprite' case
            (dependentSprites.size == 1 && dependentSprites[0] is ITilesetRun && spriteRun is ITilemapRun) // 'My tileset is the only sprite' case
        ) {
            // easy case: a single sprite. Sprite uses the palette.
            // there may be other palettes, but we can leave them be.
            writeSpriteAndPalette(spriteRun, paletteRun, image, paletteRun?.let { pr -> (0 until pr.pages).toList() })
            loadSprite()
            loadPalette()
            return result
        }

        // there are multiple sprites
        var dependentPageCount = dependentSprites.sumOf { s -> s.pages }
        if (paletteRun!!.pages > 1) dependentPageCount = dependentSprites.size // for multi-page palettes, only count each sprite once.
        var imageType = "images"
        if (dependentSprites.any { ds -> ds is ITilesetRun }) imageType = "tilesets"
        val usablePalPages = Ref<List<Int>?>(null)
        val choice = getImportType(fileSystem, dependentPageCount, dependentSprites, imageType, paletteRun, importType, usablePalPages)

        if (choice == ImportType.Smart) {
            val otherSprites = dependentSprites.filter { s -> s != spriteRun }.toMutableList()
            writeSpriteAndBalancePalette(spriteRun, paletteRun, otherSprites, image, usablePalPages.value!!)
        } else if (choice == ImportType.Greedy) {
            result = writeSpriteAndPalette(spriteRun, paletteRun, image, usablePalPages.value, !allowSpriteEdits)
        } else if (choice == ImportType.Cautious) {
            writeSpriteWithoutPalette(spriteRun, paletteRun, image, usablePalPages.value!!)
        }

        loadSprite()
        loadPalette()
        return result
    }
    private fun importWideSpriteAndPalette(fileSystem: IFileSystem, image: ShortArray, spriteRun: ISpriteRun, paletteRun: IPaletteRun?, importType: ImportType) { /*@DONE SpriteTool.ImportWideSpriteAndPalette/1 cs:992-1033*/
        val model = this.model!!
        val imageForPage = Array(spritePages) { ShortArray(pixelWidth * pixelHeight) }
        for (i in 0 until spritePages) {
            for (y in 0 until pixelHeight) {
                val yStart = y * pixelWidth
                val sourceStart = i * pixelWidth + yStart * spritePages
                image.copyInto(imageForPage[i], yStart, sourceStart, sourceStart + pixelWidth)
            }
        }

        val dependentSprites = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
        if (dependentSprites.size == 0 || // no sprites are associated with this palette. So just use the currently loaded sprite.
            (dependentSprites.size == 1 && dependentSprites[0].start == spriteRun.start) || // 'I am the only sprite' case
            (dependentSprites.size == 1 && dependentSprites[0] is ITilesetRun && spriteRun is ITilemapRun) // 'My tileset is the only sprite' case
        ) {
            // easy case: a single sprite. Sprite uses the palette.
            // there may be other palettes, but we can leave them be.
            writeSpritesAndPalette(spriteRun, paletteRun, imageForPage, paletteRun?.let { pr -> (0 until pr.pages).toList() })
            loadSprite()
            loadPalette()
            return
        }

        // there are multiple sprites
        var dependentPageCount = dependentSprites.sumOf { s -> s.pages }
        if (paletteRun!!.pages > 1) dependentPageCount = dependentSprites.size // for multi-page palettes, only count each sprite once.
        var imageType = "images"
        if (dependentSprites.any { ds -> ds is ITilesetRun }) imageType = "tilesets"
        val usablePalPages = Ref<List<Int>?>(null)
        val choice = getImportType(fileSystem, dependentPageCount, dependentSprites, imageType, paletteRun, importType, usablePalPages)

        if (choice == ImportType.Smart) {
            val otherSprites = dependentSprites.filter { s -> s != spriteRun }.toMutableList()
            writeSpritesAndBalancePalette(spriteRun, paletteRun, otherSprites, imageForPage, usablePalPages.value!!)
        } else if (choice == ImportType.Greedy) {
            writeSpritesAndPalette(spriteRun, paletteRun, imageForPage, usablePalPages.value)
        } else if (choice == ImportType.Cautious) {
            writeSpritesWithoutPalette(spriteRun, paletteRun, imageForPage, usablePalPages.value!!)
        }

        loadSprite()
        loadPalette()
    }
    private fun importTallSpriteAndPalette(fileSystem: IFileSystem, image: ShortArray, spriteRun: ISpriteRun, paletteRun: IPaletteRun?, importType: ImportType) { /*@DONE SpriteTool.ImportTallSpriteAndPalette/1 cs:1035-1073*/
        val model = this.model!!
        val imageForPage = Array(spritePages) { ShortArray(pixelWidth * pixelHeight) }
        for (i in 0 until spritePages) {
            val sourceStart = i * pixelWidth * pixelHeight
            image.copyInto(imageForPage[i], 0, sourceStart, sourceStart + pixelWidth * pixelHeight)
        }

        val dependentSprites = paletteRun?.findDependentSprites(model) ?: ArrayList<ISpriteRun>()
        if (dependentSprites.size == 0 || // no sprites are associated with this palette. So just use the currently loaded sprite.
            (dependentSprites.size == 1 && dependentSprites[0].start == spriteRun.start) || // 'I am the only sprite' case
            (dependentSprites.size == 1 && dependentSprites[0] is ITilesetRun && spriteRun is ITilemapRun) // 'My tileset is the only sprite' case
        ) {
            // easy case: a single sprite. Sprite uses the palette.
            // there may be other palettes, but we can leave them be.
            writeSpritesAndPalette(spriteRun, paletteRun, imageForPage, paletteRun?.let { pr -> (0 until pr.pages).toList() })
            loadSprite()
            loadPalette()
            return
        }

        // there are multiple sprites
        var dependentPageCount = dependentSprites.sumOf { s -> s.pages }
        if (paletteRun!!.pages > 1) dependentPageCount = dependentSprites.size // for multi-page palettes, only count each sprite once.
        var imageType = "images"
        if (dependentSprites.any { ds -> ds is ITilesetRun }) imageType = "tilesets"
        val usablePalPages = Ref<List<Int>?>(null)
        val choice = getImportType(fileSystem, dependentPageCount, dependentSprites, imageType, paletteRun, importType, usablePalPages)

        if (choice == ImportType.Smart) {
            val otherSprites = dependentSprites.filter { s -> s != spriteRun }.toMutableList()
            writeSpritesAndBalancePalette(spriteRun, paletteRun, otherSprites, imageForPage, usablePalPages.value!!)
        } else if (choice == ImportType.Greedy) {
            writeSpritesAndPalette(spriteRun, paletteRun, imageForPage, usablePalPages.value)
        } else if (choice == ImportType.Cautious) {
            writeSpritesWithoutPalette(spriteRun, paletteRun, imageForPage, usablePalPages.value!!)
        }

        loadSprite()
        loadPalette()
    }
    private fun tryValidate(pixels: Array<IntArray>?, palette: List<Short>?, spriteRun: Ref<ISpriteRun?>, paletteRun: Ref<IPaletteRun?>): Boolean { /*@DONE SpriteTool.TryValidate/1 cs:1075-1078*/
        if (!tryValidate(spriteRun, paletteRun)) return false
        return pixels != null && palette != null
    }
    private fun tryValidate(image: ShortArray?, spriteRun: Ref<ISpriteRun?>, paletteRun: Ref<IPaletteRun?>): Boolean { /*@DONE SpriteTool.TryValidate/2 cs:1080-1083*/
        if (!tryValidate(spriteRun, paletteRun)) return false
        return image != null
    }
    private fun tryValidate(spriteRun: Ref<ISpriteRun?>, paletteRun: Ref<IPaletteRun?>): Boolean { /*@DONE SpriteTool.TryValidate/3 cs:1085-1108*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val foundSprite = model.getNextRun(_spriteAddress) as? ISpriteRun
        spriteRun.value = foundSprite
        paletteRun.value = model.getNextRun(_paletteAddress) as? IPaletteRun
        if (foundSprite != null && foundSprite.spriteFormat.bitsPerPixel < 4) paletteRun.value = null

        // check 0: we actually have a sprite/palette to import on top of
        if (foundSprite == null) {
            viewPort.raiseError("The sprite address is not valid!")
            return false
        }

        if (!(foundSprite.spriteFormat.bitsPerPixel == 1 || foundSprite.spriteFormat.bitsPerPixel == 2) && paletteRun.value == null) {
            viewPort.raiseError("The palette address is not valid!")
            return false
        }

        // check 1: we're allowed to import to this sprite
        if (!foundSprite.supportsImport) {
            viewPort.raiseError("This format does not support importing.")
            return false
        }

        return true
    }
    private fun writeSpritesAndPalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun?, images: Array<ShortArray>, usablePalPages: List<Int>?) { /*@DONE SpriteTool.WriteSpritesAndPalette/1 cs:1110-1153*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val tiles = images.map { image -> tilize(image, pixelWidth) }
        val allTiles = tiles.flatMap { tilesForImage -> tilesForImage.asList() }
        val expectedPalettePages = usablePalPages?.size ?: 1
        if (expectedPalettePages == 0 && paletteRun != null) {
            viewPort.raiseError("You must select at least one palette.")
            return
        }

        // figure out the new palettes, using only the usable palettes. Leave the other palettes alone.
        val palettes: Array<List<Short>>? = if (paletteRun == null) null else Array(paletteRun.pages) { i -> paletteRun.getPalette(model, i) ?: ArrayList<Short>() }
        if (palettes != null && usablePalPages != null && usablePalPages.all { upp -> palettes.size > upp }) {
            var newPalettes = usablePalPages.map { i -> palettes[i] }.toTypedArray()
            newPalettes = discoverPalettes(allTiles.toTypedArray(), paletteRun?.paletteFormat?.bits ?: 1, expectedPalettePages, newPalettes)
            for (i in 0 until usablePalPages.size) palettes[usablePalPages[i]] = newPalettes[i]
        }

        var palettePerSprite = false
        if (spriteRun.pages == expectedPalettePages) { // handle the Castform case
            palettePerSprite = true
        }

        var newSprite = spriteRun
        for (page in 0 until images.size) {
            val indexedTiles = Array(tiles[page].size) { i -> index(tiles[page][i], palettes, usablePalPages, spriteRun.spriteFormat.bitsPerPixel, paletteRun?.paletteFormat?.initialBlankPages ?: 0, palPage, palettePerSprite) }
            val sprite = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)
            newSprite = newSprite.setPixels(model, viewPort.currentChange, page, sprite)
            val tilemap = newSprite as? ITilemapRun
            if (tilemap != null) {
                val tileset = model.getNextRun(tilemap.findMatchingTileset(model)) as? ITilesetRun
                if (tileset != null && model.readMultiByteValue(tileset.start + 1, 3) / (tileset.spriteFormat.bitsPerPixel * 8) == 1024) {
                    viewPort.raiseError("Maxed out number of available tiles. Simplify your image.")
                }
            }
        }

        var newPalette: IPaletteRun? = paletteRun
        if (paletteRun != null && palettes != null) {
            var np: IPaletteRun = paletteRun
            if (palettes.size == paletteRun.pages) {
                for (i in 0 until palettes.size) np = np.setPalette(model, viewPort.currentChange, i, palettes[i])
            } else {
                np = np.setPalette(model, viewPort.currentChange, palPage, palettes[0])
            }
            newPalette = np
        }

        explainMoves(spriteRun, newSprite, paletteRun, newPalette)
    }
    private fun writeSpritesAndBalancePalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun, otherSprites: MutableList<ISpriteRun>, images: Array<ShortArray>, usablePalPages: List<Int>) { /*@DONE SpriteTool.WriteSpritesAndBalancePalette/1 cs:1155-1261*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val tiles = images.map { image -> tilize(image, pixelWidth) }
        val allTiles = tiles.flatMap { tilesForImage -> tilesForImage.asList() }.toTypedArray()

        if (usablePalPages.size == 0) {
            viewPort.raiseError("You must select at least one palette.")
            return
        }

        // figure out the new palettes, using only the usable palettes. Leave the other palettes alone.
        val palettes: Array<List<Short>> = Array(paletteRun.pages) { i -> paletteRun.getPalette(model, i) ?: ArrayList<Short>() }
        val initialBlankPages = paletteRun.paletteFormat.initialBlankPages
        val bits = paletteRun.paletteFormat.bits

        // part 1: weigh everything using the current palettes, so we know how much force it should resist
        var weightedPalettes: MutableList<WeightedPalette> = palettes.map { p -> WeightedPalette(p, p.size) }.toMutableList()
        for (spriteSet in otherSprites) {
            var spritesToWeigh: List<ISpriteRun> = listOf(spriteSet)
            if (spriteSet is ITilesetRun) spritesToWeigh = spriteSet.findDependentTilemaps(model)
            for (sprite in spritesToWeigh) {
                if (sprite.pages == paletteRun.pages) {
                    // weigh only the current page
                    val currentPixels = sprite.getPixels(model, palPage, -1)
                    if (currentPixels != null) {
                        weightedPalettes[0] = weightedPalettes[0].merge(WeightedPalette.weigh(currentPixels, palettes[0], palettes[0].size), Ref(0.0))
                    }
                } else {
                    // weigh all pages
                    // we generally expect to either only have one sprite page, and want to weigh every palette it uses...
                    // ... or have one palette page, and want to weight every sprite page that uses it.
                    for (page in 0 until sprite.pages) {
                        val pagePixels = sprite.getPixels(model, page, -1) ?: continue
                        val newWeights = WeightedPalette.weigh(pagePixels, palettes, bits, initialBlankPages)
                        for (j in 0 until weightedPalettes.size) weightedPalettes[j] = weightedPalettes[j].merge(newWeights[j], Ref(0.0))
                    }
                }
            }
        }
        if (spriteRun.pages != paletteRun.pages) {
            for (page in 0 until spriteRun.pages) {
                if (page == _spritePage) continue
                val pagePixels = spriteRun.getPixels(model, page, -1) ?: continue
                val newWeights = WeightedPalette.weigh(pagePixels, palettes, bits, initialBlankPages)
                for (j in 0 until weightedPalettes.size) weightedPalettes[j] = weightedPalettes[j].merge(newWeights[j], Ref(0.0))
            }
        }

        // part 2: build palettes for the new tiles
        var expectedPalettePages = paletteRun.pages
        var palettePerSprite = false
        if (spriteRun.pages == paletteRun.pages) {
            expectedPalettePages = 1 // handle the Castfrom case
            palettePerSprite = true
        }

        var newPalettes: Array<List<Short>> = Array(palettes.size) { i -> palettes[i] }
        var tempPalettes = usablePalPages.map { i -> palettes[i] }.toTypedArray()
        tempPalettes = discoverPalettes(allTiles, bits, palettes.size, tempPalettes)
        for (i in 0 until palettes.size) {
            if (usablePalPages.contains(i)) newPalettes[i] = tempPalettes[usablePalPages.indexOf(i)]
            else newPalettes[i] = palettes[i]
        }
        val allIndexedTiles = Array(allTiles.size) { i -> index(allTiles[i], newPalettes, usablePalPages, spriteRun.spriteFormat.bitsPerPixel, initialBlankPages, palPage, palettePerSprite) }

        var spriteData = detilize(allIndexedTiles, spriteRun.spriteFormat.tileWidth)
        val newWeightedPalettes = WeightedPalette.weigh(spriteData, newPalettes, bits, initialBlankPages)

        // part 3: merge the new desired palettes with the existing palettes
        weightedPalettes = WeightedPalette.mergeLists(weightedPalettes, newWeightedPalettes).toMutableList()
        newPalettes = weightedPalettes.map { wp -> wp.palette }.toTypedArray()

        // part 4: update all the other sprites to use the new palettes
        var otherSpritesMoved = false
        for (spriteSet in otherSprites) {
            var spritesToWeigh: List<ISpriteRun> = listOf(spriteSet)
            if (spriteSet is ITilesetRun) spritesToWeigh = spriteSet.findDependentTilemaps(model)
            for (sprite in spritesToWeigh) {
                if (sprite === spriteRun) continue // don't update the current sprite, we're going to do that later
                if (WeightedPalette.update(model, viewPort.currentChange, sprite, palettes, newPalettes, initialBlankPages).start != sprite.start) otherSpritesMoved = true
            }
        }
        val cachedSpritePages = spriteRun.pages // cache pages in case the sprite moves during the Update operation
        var currentSpriteRun = spriteRun
        if (cachedSpritePages != paletteRun.pages) {
            for (page in 0 until cachedSpritePages) {
                if (page == _spritePage) continue
                currentSpriteRun = WeightedPalette.update(model, viewPort.currentChange, currentSpriteRun, palettes, newPalettes, initialBlankPages, page)
            }
        }

        // part 5: update the current sprite to use the new palette
        for (page in 0 until images.size) {
            val indexedTiles = Array(tiles[page].size) { i -> index(tiles[page][i], newPalettes, usablePalPages, spriteRun.spriteFormat.bitsPerPixel, initialBlankPages, palPage, palettePerSprite) }
            spriteData = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)
            currentSpriteRun = currentSpriteRun.setPixels(model, viewPort.currentChange, page, spriteData)
        }

        // part 6: update the palette
        var newPalette: IPaletteRun = paletteRun
        if (palettes.size == paletteRun.pages) {
            for (i in 0 until palettes.size) newPalette = newPalette.setPalette(model, viewPort.currentChange, i, newPalettes[i])
        } else {
            newPalette = newPalette.setPalette(model, viewPort.currentChange, palPage, palettes[0])
        }

        if (otherSpritesMoved) {
            viewPort.raiseMessage("Other sprites using this palette were moved. Pointers have been updated.")
        }
        explainMoves(spriteRun, currentSpriteRun, paletteRun, newPalette)
    }
    private fun writeSpritesWithoutPalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun?, images: Array<ShortArray>, usablePalPages: List<Int>) { /*@DONE SpriteTool.WriteSpritesWithoutPalette/1 cs:1263-1290*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        if (usablePalPages.size == 0 && paletteRun != null) {
            viewPort.raiseError("You must select at least one palette.")
            return
        }
        val palRun = paletteRun ?: return

        val tiles = images.map { image -> tilize(image, pixelWidth) }

        val palettes: Array<List<Short>>
        if (spriteRun.pages == palRun.pages) {
            palettes = arrayOf(palRun.getPalette(model, palPage) ?: ArrayList<Short>())
        } else {
            palettes = Array(palRun.pages) { i -> palRun.getPalette(model, i) ?: ArrayList<Short>() }
        }

        var newSprite = spriteRun
        for (page in 0 until images.size) {
            val indexedTiles = Array(tiles[page].size) { i -> index(tiles[page][i], palettes, usablePalPages, spriteRun.spriteFormat.bitsPerPixel, palRun.paletteFormat.initialBlankPages, palPage) }
            val sprite = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)

            newSprite = newSprite.setPixels(model, viewPort.currentChange, page, sprite)
        }

        explainMoves(spriteRun, newSprite, palRun, palRun)
    }
    private fun writeSpriteAndPalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun?, pixels: Array<IntArray>, palette: List<Short>, usablePalPages: List<Int>?, noSpriteEdits: Boolean = false): Point { /*@DONE SpriteTool.WriteSpriteAndPalette/1 cs:1292-1313*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        if (noSpriteEdits || spriteRun is ITilemapRun || paletteRun == null || paletteRun.pages != 1) {
            val (image, width) = unindex(pixels, palette)
            return writeSpriteAndPalette(spriteRun, paletteRun, image, usablePalPages, noSpriteEdits)
        }

        val newSprite = spriteRun.setPixels(model, viewPort.currentChange, _spritePage, pixels)
        val newPalette = paletteRun.setPalette(model, viewPort.currentChange, 0, palette)

        explainMoves(spriteRun, newSprite, paletteRun, newPalette)

        if (spriteRun.start != newSprite.start) {
            _spriteAddress = newSprite.start
            notifyPropertyChanged("spriteAddress")
        }
        if (paletteRun.start != newPalette.start) {
            _paletteAddress = newPalette.start
            notifyPropertyChanged("paletteAddress")
        }

        return Point(pixelWidth, pixelHeight)
    }
    private fun writeSpriteAndPalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun?, image: ShortArray, usablePalPages: List<Int>?, noSpriteEdits: Boolean = false): Point { /*@DONE SpriteTool.WriteSpriteAndPalette/2 cs:1315-1385*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        val tiles = tilize(image, pixelWidth)
        var expectedPalettePages = paletteRun?.pages ?: 1
        var palettePerSprite = false
        if (spriteRun.pages == expectedPalettePages && expectedPalettePages > 1) {
            palettePerSprite = true
            expectedPalettePages = 1 // handle the Castform case
        }

        if (expectedPalettePages == 0 && paletteRun != null) {
            viewPort.raiseError("You must select at least one palette.")
            return Point(pixelWidth, pixelHeight)
        }

        // figure out the new palettes, using only the usable palettes. Leave the other palettes alone.
        val palettes: Array<List<Short>>? = if (paletteRun == null) null else Array(paletteRun.pages) { i -> paletteRun.getPalette(model, i) ?: ArrayList<Short>() }
        if (palettes != null) {
            var newPalettes = usablePalPages!!.map { i -> palettes[i] }.toTypedArray()
            val allColors = palettes.flatMap { p -> p }
            if (spriteRun.spriteFormat.bitsPerPixel == 8 && paletteRun!!.paletteFormat.bits == 4 && usablePalPages.size == palettes.size && image.all { c -> allColors.contains(c) }) {
                // this is an 8-bit sprite with a 4-bit palette
                // if the original palette works, then don't change it.
            } else {
                newPalettes = discoverPalettes(tiles, spriteRun.spriteFormat.bitsPerPixel, usablePalPages.size, newPalettes)
                for (i in 0 until usablePalPages.size) palettes[usablePalPages[i]] = newPalettes[i]
            }
        }

        var needWriteSpriteData = true
        var matchPalettes = palettes
        if (spriteRun.pages == 1 && palettes != null && palettes.size > 1) matchPalettes = palettes.take(1).toTypedArray()
        val currentPixels = spriteRun.getPixels(model, _spritePage, -1)
        val problemPixel = if (currentPixels == null) Point(0, 0) else tryReorderPalettesFromMatchingSprite(matchPalettes, image, currentPixels)
        if (problemPixel.x == pixelWidth && problemPixel.y == pixelHeight) {
            // palette is reordered, everything matches up with the original data. No need to write sprite data.
            needWriteSpriteData = false
        } else if (noSpriteEdits) {
            // we were requested to not make sprite edits, return the pixel that prevents us from safely importing this way
            return problemPixel
        }

        val indexedTiles = Array(tiles.size) { i -> index(tiles[i], palettes, usablePalPages, spriteRun.spriteFormat.bitsPerPixel, paletteRun?.paletteFormat?.initialBlankPages ?: 0, palPage, palettePerSprite) }
        val sprite = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)

        val newSprite = if (needWriteSpriteData) spriteRun.setPixels(model, viewPort.currentChange, _spritePage, sprite) else spriteRun
        val tilemap = newSprite as? ITilemapRun
        if (tilemap != null) {
            val tileset = model.getNextRun(tilemap.findMatchingTileset(model)) as? ITilesetRun
            if (tileset != null && model.readMultiByteValue(tileset.start + 1, 3) / (tileset.spriteFormat.bitsPerPixel * 8) == 1024) {
                viewPort.raiseError("Maxed out number of available tiles. Simplify your image.")
            }
        }

        var newPalette: IPaletteRun? = paletteRun
        if (paletteRun != null && palettes != null) {
            var np: IPaletteRun = paletteRun
            if (palettes.size == paletteRun.pages) {
                for (i in 0 until palettes.size) np = np.setPalette(model, viewPort.currentChange, i, palettes[i])
            } else {
                np = np.setPalette(model, viewPort.currentChange, palPage, palettes[0])
            }
            newPalette = np
        }

        explainMoves(spriteRun, newSprite, paletteRun, newPalette)

        if (spriteRun.start != newSprite.start) {
            _spriteAddress = newSprite.start
            notifyPropertyChanged("spriteAddress")
        }
        if (newPalette != null && paletteRun!!.start != newPalette.start) {
            _paletteAddress = newPalette.start
            notifyPropertyChanged("paletteAddress")
        }

        return Point(pixelWidth, pixelHeight)
    }
    private fun writeSpriteWithoutPalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun?, image: ShortArray, usablePalPages: List<Int>) { /*@DONE SpriteTool.WriteSpriteWithoutPalette/1 cs:1387-1409*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        if (usablePalPages.size == 0 && paletteRun != null) {
            viewPort.raiseError("You must select at least one palette.")
            return
        }
        val palRun = paletteRun ?: return

        val tiles = tilize(image, pixelWidth)
        val palettes: Array<List<Short>>
        if (spriteRun.pages == palRun.pages) {
            palettes = arrayOf(palRun.getPalette(model, palPage) ?: ArrayList<Short>())
        } else {
            palettes = Array(palRun.pages) { i -> palRun.getPalette(model, i) ?: ArrayList<Short>() }
        }
        val indexedTiles = Array(tiles.size) { i -> index(tiles[i], palettes, usablePalPages, spriteRun.spriteFormat.bitsPerPixel, palRun.paletteFormat.initialBlankPages, palPage) }
        val sprite = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)

        val newSprite = spriteRun.setPixels(model, viewPort.currentChange, _spritePage, sprite)

        explainMoves(spriteRun, newSprite, palRun, palRun)
    }
    private fun writeSpriteAndBalancePalette(spriteRun: ISpriteRun, paletteRun: IPaletteRun, otherSprites: MutableList<ISpriteRun>, image: ShortArray, usablePalPages: List<Int>) { /*@DONE SpriteTool.WriteSpriteAndBalancePalette/1 cs:1411-1515*/
        val model = this.model!!
        val viewPort = this.viewPort!!
        var usable = usablePalPages
        if (usable.size == 0) {
            viewPort.raiseError("You must select at least one palette.")
            return
        }

        val tiles = tilize(image, pixelWidth)
        var palettes: Array<List<Short>> = Array(paletteRun.pages) { i -> paletteRun.getPalette(model, i) ?: ArrayList<Short>() }
        if (spriteRun.pages == paletteRun.pages) {
            palettes = arrayOf(palettes[palPage])
            usable = listOf(0)
        }
        val initialBlankPages = paletteRun.paletteFormat.initialBlankPages
        val bits = paletteRun.paletteFormat.bits

        // part 1: weigh everything using the current palettes, so we know how much force it should resist
        var weightedPalettes: MutableList<WeightedPalette> = palettes.map { p -> WeightedPalette(p, p.size) }.toMutableList()
        for (spriteSet in otherSprites) {
            var spritesToWeigh: List<ISpriteRun> = listOf(spriteSet)
            if (spriteSet is ITilesetRun) spritesToWeigh = spriteSet.findDependentTilemaps(model)
            for (sprite in spritesToWeigh) {
                if (sprite.pages == paletteRun.pages) {
                    // weigh only the current page
                    val currentPagePixels = sprite.getPixels(model, palPage, -1)
                    if (currentPagePixels != null) {
                        weightedPalettes[0] = weightedPalettes[0].merge(WeightedPalette.weigh(currentPagePixels, palettes[0], palettes[0].size), Ref(0.0))
                    }
                } else {
                    // weigh all pages
                    // we generally expect to either only have one sprite page, and want to weigh every palette it uses...
                    // ... or have one palette page, and want to weight every sprite page that uses it.
                    for (page in 0 until sprite.pages) {
                        val pagePixels = sprite.getPixels(model, page, -1) ?: continue
                        val newWeights = WeightedPalette.weigh(pagePixels, palettes, bits, initialBlankPages)
                        for (j in 0 until weightedPalettes.size) weightedPalettes[j] = weightedPalettes[j].merge(newWeights[j], Ref(0.0))
                    }
                }
            }
        }
        if (spriteRun.pages != paletteRun.pages) {
            for (page in 0 until spriteRun.pages) {
                if (page == _spritePage) continue
                val pagePixels = spriteRun.getPixels(model, page, -1) ?: continue
                val newWeights = WeightedPalette.weigh(pagePixels, palettes, bits, initialBlankPages)
                for (j in 0 until weightedPalettes.size) weightedPalettes[j] = weightedPalettes[j].merge(newWeights[j], Ref(0.0))
            }
        }

        // part 2: build palettes for the new tiles
        var expectedPalettePages = paletteRun.pages
        if (spriteRun.pages == paletteRun.pages) expectedPalettePages = 1 // handle the Castfrom case

        var newPalettes: Array<List<Short>> = Array(palettes.size) { i -> palettes[i] }
        var tempPalettes = usable.map { i -> palettes[i] }.toTypedArray()
        tempPalettes = discoverPalettes(tiles, bits, palettes.size, tempPalettes)
        for (i in 0 until palettes.size) {
            if (usable.contains(i)) newPalettes[i] = tempPalettes[usable.indexOf(i)]
            else newPalettes[i] = palettes[i]
        }

        val currentSpritePixels = spriteRun.getPixels(model, _spritePage, -1)
        if (currentSpritePixels != null) tryReorderPalettesFromMatchingSprite(newPalettes, image, currentSpritePixels)
        val indexedTiles: Array<Array<IntArray>> = Array(tiles.size) { i -> index(tiles[i], newPalettes, usable, spriteRun.spriteFormat.bitsPerPixel, initialBlankPages, palPage) }
        var spriteData = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)
        val newWeightedPalettes = WeightedPalette.weigh(spriteData, newPalettes, bits, initialBlankPages)

        // part 3: merge the new desired palettes with the existing palettes
        weightedPalettes = WeightedPalette.mergeLists(weightedPalettes, newWeightedPalettes).toMutableList()
        newPalettes = Array(weightedPalettes.size) { i -> weightedPalettes[i].palette }

        // part 4: update all the other sprites to use the new palettes
        var otherSpritesMoved = false
        for (spriteSet in otherSprites) {
            var spritesToWeigh: List<ISpriteRun> = listOf(spriteSet)
            if (spriteSet is ITilesetRun) spritesToWeigh = spriteSet.findDependentTilemaps(model)
            for (sprite in spritesToWeigh) {
                if (sprite === spriteRun) continue // don't update the current sprite, we're going to do that later
                if (sprite.pages == paletteRun.pages) {
                    if (WeightedPalette.update(model, viewPort.currentChange, sprite, palettes, newPalettes, initialBlankPages, palPage).start != sprite.start) otherSpritesMoved = true
                } else {
                    if (WeightedPalette.update(model, viewPort.currentChange, sprite, palettes, newPalettes, initialBlankPages).start != sprite.start) otherSpritesMoved = true
                }
            }
        }
        var currentSpriteRun = spriteRun
        if (spriteRun.pages != paletteRun.pages) {
            for (page in 0 until currentSpriteRun.pages) {
                if (page == _spritePage) continue
                currentSpriteRun = WeightedPalette.update(model, viewPort.currentChange, currentSpriteRun, palettes, newPalettes, initialBlankPages, page)
            }
        }

        // part 5: update the current sprite to use the new palette
        for (i in 0 until indexedTiles.size) indexedTiles[i] = index(tiles[i], newPalettes, usable, spriteRun.spriteFormat.bitsPerPixel, initialBlankPages, palPage)
        spriteData = detilize(indexedTiles, spriteRun.spriteFormat.tileWidth)
        currentSpriteRun = currentSpriteRun.setPixels(model, viewPort.currentChange, _spritePage, spriteData)

        // part 6: update the palette
        var newPalette: IPaletteRun = paletteRun
        if (palettes.size == paletteRun.pages) {
            for (i in 0 until palettes.size) newPalette = newPalette.setPalette(model, viewPort.currentChange, i, newPalettes[i])
        } else {
            newPalette = newPalette.setPalette(model, viewPort.currentChange, palPage, newPalettes[0])
        }

        if (otherSpritesMoved) {
            viewPort.raiseMessage("Other sprites using this palette were moved. Pointers have been updated.")
        }
        explainMoves(spriteRun, currentSpriteRun, paletteRun, newPalette)
    }
    private fun explainMoves(originalSprite: ISpriteRun, newSprite: ISpriteRun, originalPalette: IPaletteRun?, newPalette: IPaletteRun?) { /*@DONE SpriteTool.ExplainMoves/1 cs:1588-1604*/
        val viewPort = this.viewPort!!
        val spriteMoved = originalSprite.start != newSprite.start
        val paletteMoved = originalPalette?.start != newPalette?.start

        if (spriteMoved && !paletteMoved) {
            viewPort.goto?.execute(newSprite.start)
            viewPort.raiseMessage("Sprite moved to " + newSprite.start.toHex(6) + ". Pointers have been updated.")
        } else if (paletteMoved && !spriteMoved) {
            viewPort.goto?.execute(newPalette!!.start)
            viewPort.raiseMessage("Palette moved to " + newPalette!!.start.toHex(6) + ". Pointers have been updated.")
        } else if (spriteMoved && paletteMoved) {
            viewPort.goto?.execute(newSprite.start)
            viewPort.raiseMessage("Sprite and palette moved to " + newSprite.start.toHex(6) + " and " + newPalette!!.start.toHex(6) + ".")
        } else {
            viewPort.refresh()
        }
    }
    fun exportSpriteAndPalette(fileSystem: IFileSystem) { /*@DONE SpriteTool.ExportSpriteAndPalette/1 cs:1682-1705*/
        val model = this.model!!
        val spriteRun = model.getNextRun(_spriteAddress) as? ISpriteRun
        val palette = getRenderPalette(spriteRun)
        if (palette.size > 256 || spriteRun == null) {
            fileSystem.saveImage(pixelData, pixelWidth)
            return
        }
        val pixels = spriteRun.getPixels(model, _spritePage, -1)
        if (pixels == null) {
            fileSystem.saveImage(pixelData, pixelWidth)
            return
        }
        if (paletteFormat.initialBlankPages > 0) {
            for (x in 0 until pixels.getLength(0)) {
                for (y in 0 until pixels.getLength(1)) {
                    if (pixels[x][y] >= 16) {
                        pixels[x][y] = Math.max(0, pixels[x][y] - (paletteFormat.initialBlankPages shl 4))
                    }
                }
            }
        }
        try {
            fileSystem.saveImage(pixels, palette)
        } catch (e: Exception) {
            // failed to export - try again using the un-indexed system.
            fileSystem.saveImage(pixelData, pixelWidth)
        }
    }
    companion object {
        const val maxSpriteWidth: Int = 500 - 17
        private val allowableCharacters: CharArray = /*@INITDONE SpriteTool.allowableCharacters cs:454-454*/ "0123456789ABCDEF<>NUL".toCharArray() /*@ENDINIT*/
        private val toLower: CharArray = /*@INITDONE SpriteTool.toLower cs:455-455*/ "NUL".toCharArray() /*@ENDINIT*/
        private fun sanitizeAddressText(address: String): String { /*@DONE SpriteTool.SanitizeAddressText/1 cs:456-481*/
            var text = address
            // allow for +/- on a specific digit of the address. Useful when searching for graphics.
            while (text.contains("+")) {
                val index = text.indexOf("+")
                if (index < 1) break
                val parsedRef = Ref(0)
                if (!tryParseHexInt(text.substring(0, index), parsedRef)) break
                val parsed = parsedRef.value + 1
                text = parsed.toHex(index) + text.substring(index + 1)
            }
            while (text.contains("-")) {
                val index = text.indexOf("-")
                if (index < 1) break
                val parsedRef = Ref(0)
                if (!tryParseHexInt(text.substring(0, index), parsedRef)) break
                var parsed = parsedRef.value - 1
                if (parsed < 0) parsed = 0
                text = parsed.toHex(index) + text.substring(index + 1)
            }

            val characters = text.uppercase().filter { c -> allowableCharacters.contains(c) }.toCharArray()
            for (i in 0 until characters.size) {
                for (c in toLower) {
                    if (characters[i] == c) characters[i] = characters[i] + ('a' - 'A')
                }
            }
            return String(characters)
        }
        fun render(pixels: Array<IntArray>?, palette: List<Short>?, initialBlankPages: Int, palettePage: Int): ShortArray { /*@DONE SpriteTool.Render/1 cs:594-608*/
            if (pixels == null) return ShortArray(0)
            val pal: List<Short> = if (palette == null || palette.size == 0) TileViewModel.createDefaultPalette(16).toList() else palette
            val width = pixels.getLength(0)
            val data = ShortArray(width * pixels.getLength(1))
            val initialPageOffset = initialBlankPages shl 4
            val palettePageOffset = (palettePage shl 4) + initialPageOffset
            for (i in 0 until data.size) {
                var pixel = pixels[i % width][i / width]
                while (pixel < palettePageOffset) pixel += palettePageOffset
                val pixelIntoPalette = Math.max(0, pixel - initialPageOffset)
                data[i] = pal[pixelIntoPalette % pal.size]
            }
            return data
        }
        fun createPaletteWithUniqueTransparentColor(palette: List<Short>): List<Short> { /*@DONE SpriteTool.CreatePaletteWithUniqueTransparentColor/1 cs:610-615*/
            val copy = palette.toMutableList()
            val otherColors = palette.drop(1)
            while (otherColors.contains(copy[0])) copy[0] = ((copy[0] + 1) % 0x8000).toShort()
            return copy
        }
        fun findMatchingPalette(model: IDataModel, spriteRun: ISpriteRun?, defaultAddress: Int): Int { /*@DONE SpriteTool.FindMatchingPalette/1 cs:745-750*/
            val palettes = spriteRun.findRelatedPalettes(model)
            if (palettes.map { run -> run.start }.contains(defaultAddress)) return defaultAddress
            if (palettes.size > 0) return palettes[0].start
            return defaultAddress
        }
        private fun unindex(pixels: Array<IntArray>, palette: List<Short>): Pair<ShortArray, Int> { /*@DONE SpriteTool.Unindex/1 cs:760-772*/
            val width = pixels.getLength(0)
            val height = pixels.getLength(1)
            val image = ShortArray(width * height)
            for (y in 0 until height) {
                for (x in 0 until width) {
                    if (pixels[x][y].inRange(0, palette.size - 1)) {
                        image[y * width + x] = palette[pixels[x][y]]
                    }
                }
            }
            return Pair(image, width)
        }
        fun getTarget(sprites: List<ISpriteRun>, target: Int): SpriteToolGetTargetTuple { /*@DONE SpriteTool.GetTarget/1 cs:864-873*/
            val initialTarget = target
            var remaining = target
            var totalCount = 0
            for (i in 0 until sprites.size) {
                if (sprites[i].pages > remaining) return SpriteToolGetTargetTuple(i, remaining)
                val pages = sprites[i].pages
                remaining -= pages
                totalCount += pages
            }
            throw IndexOutOfBoundsException("Looking for page " + initialTarget + ", but there were only " + totalCount + " available pages among " + sprites.size + " sprites!")
        }
        private fun discoverPalettes(tiles: Array<ShortArray>, bitness: Int, paletteCount: Int, existingPalettes: Array<List<Short>>?): Array<List<Short>> { /*@DONE SpriteTool.DiscoverPalettes/1 cs:1517-1556*/
            if (bitness == 1) return arrayOf(TileViewModel.createDefaultPalette(2).toList())
            if (bitness == 2) return arrayOf(TileViewModel.createDefaultPalette(4).toList())
            val existing: Array<List<Short>> = existingPalettes ?: emptyArray()
            val targetColors = Math.min(Math.pow(2.0, bitness.toDouble()).toInt(), existing.sumOf { pal -> pal.size })

            // special case: we don't need to run palette discovery if the existing palette works
            var allTilesFitExistingPalettes = true
            for (tile in tiles) {
                if (existingPalettes != null && existingPalettes.any { pal -> tile.all { c -> pal.contains(c) } }) continue
                allTilesFitExistingPalettes = false
                break
            }
            if (allTilesFitExistingPalettes && paletteCount == existing.size) return existing

            val palettePageCount = paletteCount
            var count = paletteCount
            if (bitness == 8) count = 1
            val palettes = ArrayList<WeightedPalette>()
            for (i in 0 until count) palettes.add(WeightedPalette.reduce(tiles[i], targetColors))
            for (i in count until tiles.size) {
                val newPalette = WeightedPalette.reduce(tiles[i], targetColors)
                val (a, b) = WeightedPalette.cheapestMerge(palettes, newPalette)
                if (b < count) {
                    palettes[a] = palettes[a].merge(palettes[b], Ref(0.0))
                    palettes[b] = newPalette
                } else {
                    palettes[a] = palettes[a].merge(newPalette, Ref(0.0))
                }
            }

            // if this is an 8-bit image using 16-color palettes, split the resulting colors into arbitrary palettes.
            if (bitness == 8 && palettePageCount > 1) {
                val result = ArrayList<List<Short>>()
                for (i in 0 until palettePageCount) {
                    result.add(palettes[0].palette.drop(16 * i).take(16))
                }
                return result.toTypedArray()
            }

            return Array(palettes.size) { i -> palettes[i].palette }
        }
        fun index(tile: ShortArray, palettes: Array<List<Short>>?, usablePalPages: List<Int>?, bitness: Int, initialPageIndex: Int, palettePage: Int, palettePerSprite: Boolean = false): Array<IntArray> { /*@DONE SpriteTool.Index/1 cs:1558-1586*/
            var cheapestIndex = palettePage
            var pals: Array<List<Short>> = palettes ?: emptyArray()
            var usable: List<Int>? = usablePalPages
            if (bitness == 8 && usable != null && usable.size == pals.size) {
                pals = arrayOf(pals.flatMap { pal -> pal })
                usable = listOf(0)
            } else if (bitness < 4) {
                // no palette: build a default palette
                pals = arrayOf(TileViewModel.createDefaultPalette(bitness * 2).toList())
            }
            var cheapest = if (usable != null && usable.contains(palettePage) && pals.size > palettePage) WeightedPalette.costToUse(tile, pals[palettePage]) else Double.POSITIVE_INFINITY
            for (i in 0 until pals.size) {
                if (cheapest == 0.0) break
                if (usable != null && !usable.contains(i)) continue
                val cost = WeightedPalette.costToUse(tile, pals[i])
                if (cost >= cheapest) continue
                cheapest = cost
                cheapestIndex = i
            }
            val indexed = WeightedPalette.index(tile, pals[cheapestIndex])
            for (x in 0 until indexed.getLength(0)) {
                for (y in 0 until indexed.getLength(1)) {
                    // special case: 256-color sprites are still allowed to use the transparent color
                    if (bitness == 8 && indexed[x][y] == 0) continue
                    if (palettePerSprite) continue // special case: don't add the palette page offset if this is a bank of sprite-palette pairs
                    indexed[x][y] += (initialPageIndex + cheapestIndex) shl 4
                }
            }
            return indexed
        }
        fun tilize(image: ShortArray, width: Int): Array<ShortArray> { /*@DONE SpriteTool.Tilize/1 cs:1606-1626*/
            val height = image.size / width
            if (width % 8 != 0 || height % 8 != 0) throw UnsupportedOperationException("You can only tilize an image if width/height are multiples of 8!")
            val tileWidth = width / 8
            val tileHeight = height / 8
            val result = Array(tileWidth * tileHeight) { ShortArray(64) }
            for (y in 0 until tileHeight) {
                for (x in 0 until tileWidth) {
                    val tileIndex = y * tileWidth + x
                    for (yy in 0 until 8) {
                        for (xx in 0 until 8) {
                            val yIndex = y * 8 + yy
                            val xIndex = x * 8 + xx
                            val index = yIndex * width + xIndex
                            result[tileIndex][yy * 8 + xx] = image[index]
                        }
                    }
                }
            }
            return result
        }
        fun detilize(tiles: Array<Array<IntArray>>, tileWidth: Int): Array<IntArray> { /*@DONE SpriteTool.Detilize/1 cs:1628-1647*/
            val tileHeight = tiles.size / tileWidth
            val result = Array(tileWidth * 8) { IntArray(tiles.size / tileWidth * 8) }

            for (y in 0 until tileHeight) {
                val yStart = y * 8
                for (x in 0 until tileWidth) {
                    val tile = tiles[y * tileWidth + x]
                    val xStart = x * 8
                    for (yy in 0 until 8) {
                        for (xx in 0 until 8) {
                            result[xStart + xx][yStart + yy] = tile[xx][yy]
                        }
                    }
                }
            }

            return result
        }
        fun tryReorderPalettesFromMatchingSprite(palettes: Array<List<Short>>?, image: ShortArray, pixels: Array<IntArray>): Point { /*@DONE SpriteTool.TryReorderPalettesFromMatchingSprite/1 cs:1656-1680*/
            if (palettes == null || palettes.size != 1) return Point(-1, -1)
            if (palettes[0].size > 16) return Point(-1, -1)
            val newPalette = ShortArray(16)
            for (i in 0 until newPalette.size) newPalette[i] = (-1).toShort()

            val width = pixels.getLength(0)
            val height = pixels.getLength(1)
            for (x in 0 until width) {
                for (y in 0 until height) {
                    val currentColor = image[y * width + x]
                    val currentIndex = pixels[x][y] % newPalette.size
                    if (newPalette[currentIndex].toInt() == -1) newPalette[currentIndex] = currentColor
                    if (newPalette[currentIndex] != currentColor) return Point(x, y)
                }
            }

            // if there were any unused indexes, set thier color to black
            for (i in 0 until newPalette.size) {
                if (newPalette[i].toInt() == -1) newPalette[i] = 0.toShort()
            }

            palettes[0] = newPalette.toList()
            return Point(width, height)
        }
        /*@END SpriteTool.Companion*/
    }
    /*@ADD SpriteTool#spritetool_c.txt*/
    private fun canExecuteOpenInImageTab(): Boolean {
        val model = this.model!!
        val spriteRun = model.getNextRun(_spriteAddress) as? ISpriteRun ?: return false
        if (!spriteRun.supportsEdit) return false
        if (spriteRun.start != _spriteAddress) return false
        val sources = spriteRun.pointerSources
        if (sources == null || sources.size == 0) return false
        if (!_exportPair.canExecute(null)) return false
        if (spriteRun.spriteFormat.bitsPerPixel < 4) return true
        val palRun = model.getNextRun(_paletteAddress) as? IPaletteRun ?: return false
        if (palRun.start != _paletteAddress) return false
        val palSources = palRun.pointerSources
        return palSources != null && palSources.size > 0
    }

    private fun canExecuteImportPair(): Boolean {
        if (_spriteAddress < 0) return false
        val spriteRun = model!!.getNextRun(_spriteAddress) as? ISpriteRun ?: return false
        if (spriteRun.spriteFormat.bitsPerPixel < 4) return spriteRun.supportsImport
        if (_paletteAddress < 0) return false
        return spriteRun.supportsImport
    }

    private fun canExecuteExportPair(): Boolean {
        if (_spriteAddress < 0) return false
        val spriteRun = model!!.getNextRun(_spriteAddress) as? ISpriteRun ?: return false
        if (spriteRun.spriteFormat.bitsPerPixel < 4) return true
        if (_paletteAddress < 0) return false
        return true
    }
    /*@ENDADD SpriteTool#spritetool_c.txt*/
    /*@END SpriteTool*/
}

enum class ImportType(val value: Int) { // cs:1708-1713
    Unknown(-1),
    Smart(0),
    Greedy(1),
    Cautious(2);
    companion object {
        fun fromValue(value: Int): ImportType = entries.first { it.value == value }
    }
    /*@END ImportType*/
}

open class FlagViewModel : ViewModelCore { // cs:1715-1722
    private var _name: String = ""
    var name: String
        get() { /*@DONE FlagViewModel.Name.get cs:1717-1717*/
            return _name
        }
        set(value) { /*@DONE FlagViewModel.Name.set cs:1717-1717*/
            tryUpdate(_name, value, "name") { _name = it }
        }
    private var _isSet: Boolean = false
    var isSet: Boolean
        get() { /*@DONE FlagViewModel.IsSet.get cs:1719-1719*/
            return _isSet
        }
        set(value) { /*@DONE FlagViewModel.IsSet.set cs:1719-1719*/
            tryUpdate(_isSet, value, "isSet") { _isSet = it }
        }
    constructor(name: String) { /*@DONE FlagViewModel.<init>/1 cs:1721-1721*/
        this.name = name
        this.isSet = true
    }
    /*@END FlagViewModel*/
}

open class EnumViewModel : ViewModelCore { // cs:1724-1733
    var options: ObservableCollection<String> = /*@INITDONE EnumViewModel.Options cs:1725-1725*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _choice: Int = 0
    var choice: Int
        get() { /*@DONE EnumViewModel.Choice.get cs:1728-1728*/
            return _choice
        }
        set(value) { /*@DONE EnumViewModel.Choice.set cs:1728-1728*/
            tryUpdate(_choice, value, "choice") { _choice = it }
        }
    constructor(vararg options: String) { /*@DONE EnumViewModel.<init>/1 cs:1730-1732*/
        for (option in options) this.options.add(option)
    }
    /*@END EnumViewModel*/
}

open class WeightedPalette { // cs:1735-2016
    var targetLength: Int = 0
        private set
    var weight: List<Int> = ArrayList()
        private set
    var palette: List<Short> = ArrayList()
        private set
    constructor(palette: List<Short>, targetLength: Int) : this(palette, IntArray(palette.size).toList(), targetLength) { /*@DONE WeightedPalette.<init>/1 cs:1740-1740*/
        // the work is done by the delegated constructor
    }
    private constructor(palette: List<Short>, weight: List<Int>, targetLength: Int) { /*@DONE WeightedPalette.<init>/2 cs:1742-1742*/
        this.palette = palette
        this.weight = weight
        this.targetLength = targetLength
    }
    fun merge(other: WeightedPalette, cost: Ref<Double>): WeightedPalette { /*@DONE WeightedPalette.Merge/1 cs:1999-2015*/
        val masses = ArrayList<ColorMass>()
        for (i in 0 until palette.size) masses.add(ColorMass(palette[i], weight[i]))
        for (i in 0 until other.palette.size) {
            var perfectMatchFound = false
            for (j in 0 until masses.size) {
                if (masses[j].resultColor != other.palette[i]) continue
                perfectMatchFound = true
                masses[j] = ColorMass(other.palette[i], other.weight[i] + masses[j].mass)
                break
            }
            if (!perfectMatchFound) {
                masses.add(ColorMass(other.palette[i], other.weight[i]))
            }
        }
        return reduce(masses, targetLength, cost)
    }
    companion object {
        fun weigh(sprite: Array<IntArray>, palette: List<Short>, targetLength: Int): WeightedPalette { /*@DONE WeightedPalette.Weigh/1 cs:1744-1748*/
            val weight = IntArray(targetLength)
            for (column in sprite) {
                for (num in column) weight[num % targetLength]++
            }
            return WeightedPalette(palette, weight.toList(), targetLength)
        }
        fun weigh(sprite: Array<IntArray>, palettes: Array<List<Short>>, bitness: Int, pageOffset: Int): List<WeightedPalette> { /*@DONE WeightedPalette.Weigh/2 cs:1753-1774*/
            val targetLength = Math.pow(2.0, bitness.toDouble()).toInt()
            val weights = Array(palettes.size) { IntArray(targetLength) }

            for (x in 0 until sprite.getLength(0)) {
                for (y in 0 until sprite.getLength(1)) {
                    var index = sprite[x][y] - (pageOffset shl 4)
                    val paletteIndex = (index shr 4) % palettes.size
                    if (index < 0) continue // we don't care about weighing colors from a palette that's out-of-range
                    index -= paletteIndex shl 4
                    if (index >= weights[paletteIndex].size) continue // we don't care about weighing colors from a palette that's out-of-range
                    weights[paletteIndex][index]++
                }
            }

            val results = ArrayList<WeightedPalette>()
            for (i in 0 until palettes.size) {
                results.add(WeightedPalette(palettes[i], weights[i].toList(), targetLength))
            }
            return results
        }
        fun mergeLists(set1: List<WeightedPalette>, set2: List<WeightedPalette>): List<WeightedPalette> { /*@DONE WeightedPalette.MergeLists/1 cs:1779-1796*/
            val result = set1.toMutableList()
            for (palette in set2) {
                val bestCostRef = Ref(0.0)
                var bestMerge = result[0].merge(palette, bestCostRef)
                var bestCost = bestCostRef.value
                var bestIndex = 0
                for (i in 1 until result.size) {
                    if (bestCost == 0.0) break
                    val currentCostRef = Ref(0.0)
                    val currentMerge = result[i].merge(palette, currentCostRef)
                    val currentCost = currentCostRef.value
                    if (currentCost >= bestCost) continue
                    bestCost = currentCost
                    bestMerge = currentMerge
                    bestIndex = i
                }
                result[bestIndex] = bestMerge
            }
            return result
        }
        fun update(model: IDataModel, token: ModelDelta, spriteRun: ISpriteRun, originalPalettes: Array<List<Short>>, newPalettes: Array<List<Short>>, initialPaletteOffset: Int): ISpriteRun { /*@DONE WeightedPalette.Update/1 cs:1798-1803*/
            var run = spriteRun
            var i = 0
            while (i < run.pages) {
                run = update(model, token, run, originalPalettes, newPalettes, initialPaletteOffset, i)
                i++
            }
            return run
        }
        fun update(model: IDataModel, token: ModelDelta, spriteRun: ISpriteRun, originalPalettes: Array<List<Short>>, newPalettes: Array<List<Short>>, initialPaletteOffset: Int, page: Int): ISpriteRun { /*@DONE WeightedPalette.Update/2 cs:1808-1831*/
            var run = spriteRun
            var pixels = run.getPixels(model, page, -1) ?: return run

            if (run is LzTilemapRun) {
                val image = SpriteTool.render(pixels, originalPalettes.flatMap { s -> s }, initialPaletteOffset, page)
                val tiles = SpriteTool.tilize(image, run.spriteFormat.tileWidth * 8)
                val tileBits = run.spriteFormat.bitsPerPixel
                val indexedTiles = Array(tiles.size) { i -> SpriteTool.index(tiles[i], newPalettes, null, tileBits, initialPaletteOffset, 0) }
                pixels = SpriteTool.detilize(indexedTiles, run.spriteFormat.tileWidth)
            } else {
                val indexMapping = createPixelMapping(originalPalettes, newPalettes, initialPaletteOffset)

                for (x in 0 until pixels.getLength(0)) {
                    for (y in 0 until pixels.getLength(1)) {
                        var pixel = pixels[x][y]
                        while (pixel < (initialPaletteOffset shl 4)) pixel += initialPaletteOffset shl 4 // handle tiles mapped to no palette. Map them to the first palette.
                        pixels[x][y] = if (pixel >= indexMapping.size) pixel else (indexMapping[pixel] ?: pixel) // don't remap any pixel that's using an unknown palette
                    }
                }
            }

            run = run.setPixels(model, token, page, pixels)
            return run
        }
        fun createPixelMapping(originalPalettes: Array<List<Short>>, newPalettes: Array<List<Short>>, initialPaletteOffset: Int): MutableMap<Int, Int> { /*@DONE WeightedPalette.CreatePixelMapping/1 cs:1833-1847*/
            val result = LinkedHashMap<Int, Int>()
            for (i in 0 until originalPalettes.size) {
                val originalPaletteGroup = (i + initialPaletteOffset) shl 4
                val originalPalette = originalPalettes[i]
                val newPaletteIndex = targetPalette(newPalettes, originalPalette)
                val newPalette = newPalettes[newPaletteIndex]
                val newPaletteGroup = (newPaletteIndex + initialPaletteOffset) shl 4
                for (j in 0 until originalPalette.size) {
                    val colorIndex = bestMatch(originalPalette[j], newPalette)
                    result[originalPaletteGroup + j] = newPaletteGroup + colorIndex
                }
            }
            return result
        }
        fun targetPalette(options: Array<List<Short>>, oldPalette: List<Short>): Int { /*@DONE WeightedPalette.TargetPalette/1 cs:1849-1863*/
            var bestDistance = Double.POSITIVE_INFINITY
            var bestIndex = -1
            for (i in 0 until options.size) {
                var currentDistance = 0.0
                for (j in 0 until oldPalette.size) {
                    val index = bestMatch(oldPalette[j], options[i])
                    currentDistance += distance(options[i][index], oldPalette[j])
                }
                if (bestDistance <= currentDistance) continue
                bestDistance = currentDistance
                bestIndex = i
            }
            return bestIndex
        }
        fun reduce(rawColors: ShortArray, targetColors: Int): WeightedPalette { /*@DONE WeightedPalette.Reduce/1 cs:1868-1877*/
            val allColors = LinkedHashMap<Short, ColorMass>()
            for (i in 0 until rawColors.size) {
                val color = rawColors[i]
                if (!allColors.containsKey(color)) allColors[color] = ColorMass(color, 0)
                allColors[color] = ColorMass(color, allColors[color]!!.mass + 1)
            }
            val palette = allColors.values.toMutableList()
            return reduce(palette, targetColors, Ref(0.0))
        }
        fun reduce(palette: MutableList<ColorMass>, targetColors: Int, cost: Ref<Double>): WeightedPalette { /*@DONE WeightedPalette.Reduce/2 cs:1882-1896*/
            cost.value = 0.0
            if (palette.size <= targetColors) return WeightedPalette(palette.map { p -> p.resultColor }, palette.map { p -> p.mass }, targetColors)
            while (palette.size > targetColors) {
                val bestCostRef = Ref(0.0)
                val bestPair = cheapestMerge(palette, bestCostRef)
                val combine1 = palette[bestPair.a]
                val combine2 = palette[bestPair.b]
                palette.removeAt(bestPair.b)
                palette[bestPair.a] = combine1 + combine2
                cost.value += bestCostRef.value
            }
            val resultPalette = palette.map { p -> p.resultColor }
            val resultMasses = palette.map { p -> p.mass }
            return WeightedPalette(resultPalette, resultMasses, targetColors)
        }
        fun cheapestMerge(palette: MutableList<ColorMass>, cost: Ref<Double>): WeightedPaletteCheapestMergeTuple { /*@DONE WeightedPalette.CheapestMerge/1 cs:1898-1911*/
            var bestPair = WeightedPaletteCheapestMergeTuple(0, 1)
            var bestCost = Double.POSITIVE_INFINITY
            for (i in 0 until palette.size - 1) {
                for (j in i + 1 until palette.size) {
                    val currentCost = palette[i] * palette[j]
                    if (currentCost >= bestCost) continue
                    bestCost = currentCost
                    bestPair = WeightedPaletteCheapestMergeTuple(i, j)
                }
            }
            cost.value = bestCost
            return bestPair
        }
        fun cheapestMerge(palettes: List<WeightedPalette>, newPalette: WeightedPalette): WeightedPaletteCheapestMergeTuple { /*@DONE WeightedPalette.CheapestMerge/2 cs:1913-1935*/
            if (palettes.size == 1) return WeightedPaletteCheapestMergeTuple(0, 1)

            var bestPair = WeightedPaletteCheapestMergeTuple(0, 0)
            var bestCost = Double.POSITIVE_INFINITY

            for (i in 0 until palettes.size) {
                for (j in i + 1 until palettes.size) {
                    if (bestCost == 0.0) break
                    val currentCostRef = Ref(0.0)
                    palettes[i].merge(palettes[j], currentCostRef)
                    val currentCost = currentCostRef.value
                    if (currentCost >= bestCost) continue
                    bestCost = currentCost
                    bestPair = WeightedPaletteCheapestMergeTuple(i, j)
                }
                if (bestCost == 0.0) break
                val newCostRef = Ref(0.0)
                palettes[i].merge(newPalette, newCostRef)
                val newCost = newCostRef.value
                if (newCost >= bestCost) continue
                bestCost = newCost
                bestPair = WeightedPaletteCheapestMergeTuple(i, palettes.size)
            }

            return bestPair
        }
        fun index(rawColors: ShortArray, palette: List<Short>): Array<IntArray> { /*@DONE WeightedPalette.Index/1 cs:1937-1945*/
            val result = Array(8) { IntArray(8) }
            for (i in 0 until rawColors.size) {
                val x = i % 8
                val y = i / 8
                result[x][y] = bestMatch(rawColors[i], palette)
            }
            return result
        }
        fun costToUse(rawColors: ShortArray, palette: List<Short>): Double { /*@DONE WeightedPalette.CostToUse/1 cs:1947-1967*/
            // only the number of pixels using each color matters here, so count them directly instead of building ColorMass objects
            val counts = LinkedHashMap<Short, Int>()
            for (i in 0 until rawColors.size) {
                val color = rawColors[i]
                counts[color] = (counts[color] ?: 0) + 1
            }

            var total = 0.0
            for (key in counts.keys) {
                var bestDistance = Double.POSITIVE_INFINITY
                for (i in 0 until palette.size) {
                    val currentDistance = distance(key, palette[i])
                    if (currentDistance < bestDistance) bestDistance = currentDistance
                    if (bestDistance == 0.0) break
                }
                total += bestDistance * counts[key]!!
            }

            return total
        }
        fun bestMatch(input: Short, palette: List<Short>): Int { /*@DONE WeightedPalette.BestMatch/1 cs:1969-1981*/
            var bestIndex = 0
            var bestDistance = distance(input, palette[0])
            for (i in 1 until palette.size) {
                if (bestDistance == 0.0) return bestIndex
                val currentDistance = distance(input, palette[i])
                if (bestDistance <= currentDistance) continue
                bestIndex = i
                bestDistance = currentDistance
            }
            return bestIndex
        }
        fun distance(a: Short, b: Short): Double { /*@DONE WeightedPalette.Distance/1 cs:1983-1997*/
            val channel1A = a.toInt() shr 10
            val channel2A = (a.toInt() shr 5) and 0x1F
            val channel3A = a.toInt() and 0x1F

            val channel1B = b.toInt() shr 10
            val channel2B = (b.toInt() shr 5) and 0x1F
            val channel3B = b.toInt() and 0x1F

            val diff1 = channel1A - channel1B
            val diff2 = channel2A - channel2B
            val diff3 = channel3A - channel3B

            return Math.sqrt((diff1 * diff1 + diff2 * diff2 + diff3 * diff3).toDouble())
        }
        /*@END WeightedPalette.Companion*/
    }
    /*@END WeightedPalette*/
}

open class ColorMass { // cs:2018-2081
    var r: Double = 0.0
        private set
    var g: Double = 0.0
        private set
    var b: Double = 0.0
        private set
    var mass: Int = 0
        private set
    private val _originalColors: MutableMap<Short, Int> = /*@INITDONE ColorMass.originalColors cs:2024-2024*/ LinkedHashMap() /*@ENDINIT*/
    val originalColors: Map<Short, Int>
        get() { /*@DONE ColorMass.OriginalColors.get cs:2025-2025*/
            return _originalColors
        }
    val resultColor: Short
        get() { /*@DONE ColorMass.ResultColor.get cs:2027-2027*/
            return combineRGB(r.toInt(), g.toInt(), b.toInt())
        }
    private constructor() { /*@DONE ColorMass.<init>/1 cs:2029-2029*/
        // empty: used by operator plus to build a blank mass
    }
    constructor(color: Short, count: Int) { /*@DONE ColorMass.<init>/2 cs:2030-2034*/
        _originalColors[color] = count
        val rgb = splitRGB(color)
        this.r = rgb.item1.toDouble()
        this.g = rgb.item2.toDouble()
        this.b = rgb.item3.toDouble()
        this.mass = count
    }
    operator fun plus(b: ColorMass): ColorMass { /*@DONE ColorMass.op_Addition/1 cs:2039-2055*/
        val a = this
        if (a.mass == 0) return b
        if (b.mass == 0) return a
        val newMass = a.mass + b.mass
        val result = ColorMass()
        result.mass = newMass
        result.r = (a.r * a.mass + b.r * b.mass) / newMass
        result.g = (a.g * a.mass + b.g * b.mass) / newMass
        result.b = (a.b * a.mass + b.b * b.mass) / newMass
        for (key in a._originalColors.keys) result._originalColors[key] = a._originalColors[key]!!
        for (key in b._originalColors.keys) {
            if (result._originalColors.containsKey(key)) result._originalColors[key] = result._originalColors[key]!! + b._originalColors[key]!!
            else result._originalColors[key] = b._originalColors[key]!!
        }
        return result
    }
    operator fun times(b: ColorMass): Double { /*@DONE ColorMass.op_Multiply/1 cs:2061-2074*/
        val a = this
        if (a.mass == 0 || b.mass == 0) return 0.0
        val dR = a.r - b.r
        val dG = a.g - b.g
        val dB = a.b - b.b
        val distanceSquared = dR * dR + dG * dG + dB * dB

        if (distanceSquared == 0.0) return 0.0 // no distance: merging is free

        // as the masses get farther apart, the force needed to merge them grows
        // as the masses get heavier, the force needed to merge them grows
        val force = a.mass * b.mass * distanceSquared
        return force
    }
    override fun toString(): String { /*@DONE ColorMass.ToString/1 cs:2080-2080*/
        return "" + mass + ", " + r + ":" + g + ":" + b
    }
    companion object {
        fun splitRGB(color: Short): ColorMassSplitRGBTuple { /*@DONE ColorMass.SplitRGB/1 cs:2076-2076*/
            return ColorMassSplitRGBTuple(color.toInt() shr 10, (color.toInt() shr 5) and 0x1F, color.toInt() and 0x1F)
        }
        fun combineRGB(r: Int, g: Int, b: Int): Short { /*@DONE ColorMass.CombineRGB/1 cs:2078-2078*/
            return ((r shl 10) or (g shl 5) or b).toShort()
        }
        /*@END ColorMass.Companion*/
    }
    /*@END ColorMass*/
}

data class SpriteToolGetTargetTuple(val index: Int, val page: Int)

data class WeightedPaletteCheapestMergeTuple(val a: Int, val b: Int)

data class ColorMassSplitRGBTuple(val item1: Int, val item2: Int, val item3: Int)
