// Port of ViewModels/Map/MapHeaderViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.models.runs.sprites.*

open class MapHeaderViewModel : ViewModelCore, INotifyPropertyChanged { // cs:13-220
    private var map: ModelArrayElement? = null
    private lateinit var tokenFactory: () -> ModelDelta
    private lateinit var format: Format
    val weatherOptions: ObservableCollection<String>
        get() { /*@DONE MapHeaderViewModel.WeatherOptions.get cs:64-64*/
            return _weatherOptions
        }
    val caveOptions: ObservableCollection<String>
        get() { /*@DONE MapHeaderViewModel.CaveOptions.get cs:66-66*/
            return _caveOptions
        }
    val battleOptions: ObservableCollection<String>
        get() { /*@DONE MapHeaderViewModel.BattleOptions.get cs:68-68*/
            return _battleOptions
        }
    constructor(element: ModelArrayElement?, format: Format, tokens: () -> ModelDelta) { /*@DONE MapHeaderViewModel.<init>/2 cs:70-83*/
        this.map = element
        this.format = format
        this.tokenFactory = tokens
        if (element == null) return
        val songnames = Ref<ValidationList?>(null)
        if (element.model!!.tryGetList("songnames", songnames)) {
            val names = songnames.value!!
            for (i in 0 until names.size) {
                val entry: String? = names[i]
                musicOptions.add(entry ?: "song_$i")
            }
        }
        val mapTypes = Ref<ValidationList?>(null)
        if (element.model!!.tryGetList("maptypes", mapTypes)) {
            for (name in mapTypes.value!!) mapTypeOptions.add(name)
        }
        refresh()
    }
    fun updateFromModel() { /*@DONE MapHeaderViewModel.UpdateFromModel/1 cs:85-117*/
        if (_primaryIndex == -1 || _secondaryIndex == -1) return // only way this can ever be set is later in this same method (recursion guard)
        val map = this.map
        if (map == null) return
        val layoutTable = map.getSubTable(Format.layout)
        if (layoutTable == null) return
        val layout = layoutTable[0]
        val primaryAddress = layout.getAddress(Format.primaryBlockset)
        val secondaryAddress = layout.getAddress(Format.secondaryBlockset)

        // if this is a no-op, skip
        val primaryItem = format.blocksetCache.primary.firstOrNull { blockset -> blockset.address == primaryAddress }
        val secondaryItem = format.blocksetCache.secondary.firstOrNull { blockset -> blockset.address == secondaryAddress }
        val newPrimary = if (primaryItem == null) -1 else format.blocksetCache.primary.indexOf(primaryItem)
        val newSecondary = if (secondaryItem == null) -1 else format.blocksetCache.secondary.indexOf(secondaryItem)
        if (
            primaryOptions.toList() == format.blocksetCache.primary.toList() &&
            secondaryOptions.toList() == format.blocksetCache.secondary.toList() &&
            _primaryIndex == newPrimary &&
            _secondaryIndex == newSecondary) {
            // already in a good state
            // don't actually notify, since there's no changes
            return
        }

        primaryOptions.clear()
        secondaryOptions.clear()
        for (item in format.blocksetCache.primary) primaryOptions.add(item)
        for (item in format.blocksetCache.secondary) secondaryOptions.add(item)

        // force refresh for primary/secondary index
        _primaryIndex = -1
        _secondaryIndex = -1
        notifyPropertiesChanged("primaryIndex", "secondaryIndex")
        _primaryIndex = newPrimary
        _secondaryIndex = newSecondary
        notifyPropertiesChanged("primaryIndex", "secondaryIndex")
    }
    fun refresh() { /*@DONE MapHeaderViewModel.Refresh/1 cs:119-122*/
        format.refresh()
        updateFromModel()
    }
    var primaryOptions: ObservableCollection<BlocksetOption> = /*@INITDONE MapHeaderViewModel.PrimaryOptions cs:124-124*/ ObservableCollection() /*@ENDINIT*/
        private set
    var secondaryOptions: ObservableCollection<BlocksetOption> = /*@INITDONE MapHeaderViewModel.SecondaryOptions cs:125-125*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _primaryIndex: Int = 0
    private var _secondaryIndex: Int = 0
    var primaryIndex: Int
        get() { /*@DONE MapHeaderViewModel.PrimaryIndex.get cs:128-128*/
            return _primaryIndex
        }
        set(value) { /*@DONE MapHeaderViewModel.PrimaryIndex.set cs:129-134*/
            if (_primaryIndex == value || value == -1) return
            _primaryIndex = value
            updateBlocksets()
            notifyPropertyChanged("primaryIndex")
        }
    var secondaryIndex: Int
        get() { /*@DONE MapHeaderViewModel.SecondaryIndex.get cs:137-137*/
            return _secondaryIndex
        }
        set(value) { /*@DONE MapHeaderViewModel.SecondaryIndex.set cs:138-143*/
            if (_secondaryIndex == value || value == -1) return
            _secondaryIndex = value
            updateBlocksets()
            notifyPropertyChanged("secondaryIndex")
        }
    private fun updateBlocksets() { /*@DONE MapHeaderViewModel.UpdateBlocksets/1 cs:145-152*/
        val layoutElement = MapModel(this.map).layout?.element
        if (layoutElement == null) return
        if (!_primaryIndex.inRange(0, primaryOptions.size)) return
        if (!_secondaryIndex.inRange(0, secondaryOptions.size)) return
        layoutElement.setAddress(Format.primaryBlockset, primaryOptions[_primaryIndex].address)
        layoutElement.setAddress(Format.secondaryBlockset, secondaryOptions[_secondaryIndex].address)
    }
    var music: Int
        get() { /*@DONE MapHeaderViewModel.Music.get cs:155-155*/
            return getValue("music")
        }
        set(value) { /*@DONE MapHeaderViewModel.Music.set cs:155-155*/
            setValue(value, "music")
        }
    var layoutID: Int
        get() { /*@DONE MapHeaderViewModel.LayoutID.get cs:156-156*/
            return getValue("layoutID")
        }
        set(value) { /*@DONE MapHeaderViewModel.LayoutID.set cs:156-156*/
            setValue(value, "layoutID")
        }
    var regionSectionID: Int
        get() { /*@DONE MapHeaderViewModel.RegionSectionID.get cs:157-157*/
            return getValue("regionSectionID")
        }
        set(value) { /*@DONE MapHeaderViewModel.RegionSectionID.set cs:157-157*/
            setValue(value, "regionSectionID")
        }
    var cave: Int
        get() { /*@DONE MapHeaderViewModel.Cave.get cs:158-158*/
            return getValue("cave")
        }
        set(value) { /*@DONE MapHeaderViewModel.Cave.set cs:158-158*/
            setValue(value, "cave")
        }
    var weather: Int
        get() { /*@DONE MapHeaderViewModel.Weather.get cs:159-159*/
            return getValue("weather")
        }
        set(value) { /*@DONE MapHeaderViewModel.Weather.set cs:159-159*/
            setValue(value, "weather")
        }
    var mapType: Int
        get() { /*@DONE MapHeaderViewModel.MapType.get cs:160-160*/
            return getValue("mapType")
        }
        set(value) { /*@DONE MapHeaderViewModel.MapType.set cs:160-160*/
            setValue(value, "mapType")
        }
    var allowBiking: Boolean
        get() { /*@DONE MapHeaderViewModel.AllowBiking.get cs:161-161*/
            return getBool("allowBiking")
        }
        set(value) { /*@DONE MapHeaderViewModel.AllowBiking.set cs:161-161*/
            setBool(value, "allowBiking")
        }
    var allowEscaping: Boolean
        get() { /*@DONE MapHeaderViewModel.AllowEscaping.get cs:162-162*/
            return getBool("allowEscaping")
        }
        set(value) { /*@DONE MapHeaderViewModel.AllowEscaping.set cs:162-162*/
            setBool(value, "allowEscaping")
        }
    var allowRunning: Boolean
        get() { /*@DONE MapHeaderViewModel.AllowRunning.get cs:163-163*/
            return getBool("allowRunning")
        }
        set(value) { /*@DONE MapHeaderViewModel.AllowRunning.set cs:163-163*/
            setBool(value, "allowRunning")
        }
    var showMapName: Boolean
        get() { /*@DONE MapHeaderViewModel.ShowMapName.get cs:164-164*/
            return getBool("showMapName")
        }
        set(value) { /*@DONE MapHeaderViewModel.ShowMapName.set cs:164-164*/
            setBool(value, "showMapName")
        }
    var floorNum: Int
        get() { /*@DONE MapHeaderViewModel.FloorNum.get cs:165-165*/
            return getValue("floorNum")
        }
        set(value) { /*@DONE MapHeaderViewModel.FloorNum.set cs:165-165*/
            setValue(value, "floorNum")
        }
    var battleType: Int
        get() { /*@DONE MapHeaderViewModel.BattleType.get cs:166-166*/
            return getValue("battleType")
        }
        set(value) { /*@DONE MapHeaderViewModel.BattleType.set cs:166-166*/
            setValue(value, "battleType")
        }
    val showFloorNumField: Boolean
        get() { /*@DONE MapHeaderViewModel.ShowFloorNumField.get cs:168-168*/
            return map?.hasField("floorNum") ?: false // FR/LG only
        }
    val showAllowBikingField: Boolean
        get() { /*@DONE MapHeaderViewModel.ShowAllowBikingField.get cs:169-169*/
            val element = map ?: return false
            return element.hasField("allowBiking") || (element.hasField("flags") && element.getTuple("flags").hasField("allowBiking")) // not for R/S
        }
    val hasMusicOptions: Boolean
        get() { /*@DONE MapHeaderViewModel.HasMusicOptions.get cs:171-171*/
            return musicOptions.size > 0
        }
    var musicOptions: ObservableCollection<String> = /*@INITDONE MapHeaderViewModel.MusicOptions cs:172-172*/ ObservableCollection() /*@ENDINIT*/
        private set
    val hasMapTypeOptions: Boolean
        get() { /*@DONE MapHeaderViewModel.HasMapTypeOptions.get cs:174-174*/
            return mapTypeOptions.size > 0
        }
    var mapTypeOptions: ObservableCollection<String> = /*@INITDONE MapHeaderViewModel.MapTypeOptions cs:175-175*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun getValue(name: String? = null): Int { /*@DONE MapHeaderViewModel.GetValue/1 cs:177-181*/
        // (the name is the lowerCamel field name; the C# version derived it from the property name)
        val fieldName = name!!
        val element = map ?: return -1
        if (!element.hasField(fieldName)) return -1
        return element.getValue(fieldName)
    }
    private fun setValue(value: Int, name: String? = null) { /*@DONE MapHeaderViewModel.SetValue/1 cs:184-191*/
        val fieldName = name!!
        if (value == getValue(fieldName)) return
        val current = map ?: return
        map = ModelArrayElement(current.model!!, current.table.start, (current.start - current.table.start) / current.table.elementCount, tokenFactory, current.table)
        map!!.setValue(fieldName, value)
        notifyPropertyChanged(fieldName)
    }
    private fun getBool(name: String? = null): Boolean { /*@DONE MapHeaderViewModel.GetBool/1 cs:193-204*/
        val fieldName = name!!
        val element = map ?: return false
        if (element.hasField(fieldName)) {
            return element.getValue(fieldName) != 0
        } else if (element.hasField("flags")) {
            val tuple = element.getTuple("flags")
            if (!tuple.hasField(fieldName)) return false
            return tuple.getValue(fieldName) != 0
        }

        return false
    }
    private fun setBool(value: Boolean, name: String? = null) { /*@DONE MapHeaderViewModel.SetBool/1 cs:206-219*/
        val fieldName = name!!
        val element = map ?: return
        if (element.hasField(fieldName)) {
            element.setValue(fieldName, if (value) 1 else 0)
            notifyPropertyChanged(fieldName)
        } else if (element.hasField("flags")) {
            val tuple = element.getTuple("flags")
            if (tuple.hasField(fieldName)) {
                tuple.setValue(fieldName, if (value) 1 else 0)
                notifyPropertyChanged(fieldName)
            }
        }
    }
    companion object {
        private val _weatherOptions: ObservableCollection<String> = /*@INITDONE MapHeaderViewModel.weatherOptions cs:19-19*/ ObservableCollection() /*@ENDINIT*/
        private val _caveOptions: ObservableCollection<String> = /*@INITDONE MapHeaderViewModel.caveOptions cs:20-20*/ ObservableCollection() /*@ENDINIT*/
        private val _battleOptions: ObservableCollection<String> = /*@INITDONE MapHeaderViewModel.battleOptions cs:21-21*/ ObservableCollection() /*@ENDINIT*/
        init { /*@DONE MapHeaderViewModel.<cctor>/1 cs:22-62*/
            // weather
            _weatherOptions.add("Indoor")
            _weatherOptions.add("Sunny Clouds")
            _weatherOptions.add("Outdoor")
            _weatherOptions.add("Rain")
            _weatherOptions.add("Snow")
            _weatherOptions.add("Thunderstorm")
            _weatherOptions.add("Fog - Horizontal")
            _weatherOptions.add("Ash")
            _weatherOptions.add("Sandstorm")
            _weatherOptions.add("Fog - Diagonal")
            _weatherOptions.add("Underwater")
            _weatherOptions.add("Shade")
            _weatherOptions.add("Drought")
            _weatherOptions.add("Downpour")
            _weatherOptions.add("Underwater - Bubbles")
            _weatherOptions.add("Alternating Storm")
            _weatherOptions.add("16 - Unused")
            _weatherOptions.add("17 - Unused")
            _weatherOptions.add("18 - Unused")
            _weatherOptions.add("19 - Unused")
            _weatherOptions.add("Cycle - Route 119")
            _weatherOptions.add("Cycle - Route 123")

            // cave
            _caveOptions.add("Normal")
            _caveOptions.add("Flash Usable")
            _caveOptions.add("Flash Not Usable")

            // battle
            _battleOptions.add("Normal")
            _battleOptions.add("Gym")
            _battleOptions.add("Indoor 1 (Magma)")
            _battleOptions.add("Indoor 2 (Aqua)")
            _battleOptions.add("Elite 1")
            _battleOptions.add("Elite 2")
            _battleOptions.add("Elite 3")
            _battleOptions.add("Elite 4")
            _battleOptions.add("Big Red Pok\u00e9 ball")
        }
        /*@END MapHeaderViewModel.Companion*/
    }
    /*@END MapHeaderViewModel*/
}

open class BlocksetOption : ViewModelCore { // cs:222-244
    private var _render: Lazy<IPixelViewModel>? = null
    var model: IDataModel? = null
        private set
    var address: Int = 0
        private set
    var nameHint: String = ""
        private set
    val render: IPixelViewModel?
        get() { /*@DONE BlocksetOption.Render.get cs:227-227*/
            return _render?.value
        }
    val addressText: String
        get() { /*@DONE BlocksetOption.AddressText.get cs:228-228*/
            return address.toAddress() + nameHint
        }
    constructor(model: IDataModel, address: Int) { /*@DONE BlocksetOption.<init>/1 cs:230-243*/
        this.model = model
        this.address = address

        val sources: List<Int> = model.getNextRun(address)?.pointerSources ?: emptyList()
        val layoutRuns = sources.map { source -> model.getNextRun(source) }.distinct()
        val layoutSources = layoutRuns.flatMap { run -> run?.pointerSources ?: emptyList<Int>() }
        val mapRuns = layoutSources.map { source -> model.getNextRun(source) }.filter { run -> run != null && model.getAnchorFromAddress(-1, run.start) != "data.maps.layouts" && run is ITableRun }
        val elements = mapRuns.map { run -> ModelTable(model, run as ITableRun)[0] }.filter { element -> element.hasField("regionSectionID") }
        var hint = elements.map { element -> element.getEnumValue("regionSectionID") }.distinct().sortedWith(String.CASE_INSENSITIVE_ORDER.then(naturalOrder())).firstOrNull() ?: ""
        if (hint != "") hint = " (ex. $hint)"
        this.nameHint = hint

        if (!model.spartanMode) _render = lazy { BlocksetModel(model, address).renderBlockset(0.5) }
    }
    /*@END BlocksetOption*/
}
