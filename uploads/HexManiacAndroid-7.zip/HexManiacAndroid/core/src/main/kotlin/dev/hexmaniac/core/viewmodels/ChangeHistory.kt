// Port of ViewModels/ChangeHistory.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*

interface IChangeToken { // cs:9-13
    val hasDataChange: Boolean
    val hasAnyChange: Boolean
    val onNewChange: Event<EventArgs>
    /*@END IChangeToken*/
}

open class ChangeHistory<T> : ViewModelCore where T : Any, T : IChangeToken { // cs:28-230
    private lateinit var revert: (T) -> T
    private lateinit var _undo: StubCommand
    private lateinit var _redo: StubCommand
    private var maxSize: Int = 0
    private var undoStack: ArrayDeque<T> = /*@INITAUTO ChangeHistory.undoStack cs:32-33*/ ArrayDeque() /*@ENDINIT*/
    private var redoStack: ArrayDeque<T> = /*@INITAUTO ChangeHistory.redoStack cs:32-34*/ ArrayDeque() /*@ENDINIT*/
    private var revertInProgress: Boolean = false
    private var customChangeInProgress: Boolean = false
    private var _currentChange: T? = null
    private var createToken: (() -> T)? = null
    private var undoStackSizeAtSaveTag: Int = 0
    val undo: ICommand
        get() { /*@DONE ChangeHistory.Undo.get cs:41-41*/
            return _undo
        }
    val redo: ICommand
        get() { /*@DONE ChangeHistory.Redo.get cs:42-42*/
            return _redo
        }
    val currentChange: T
        get() { /*@DONE ChangeHistory.CurrentChange.get cs:44-55*/
            verifyRevertNotInProgress("CurrentChange")
            clearRedoStack()

            if (customChangeInProgress) changeCompleted()

            if (_currentChange == null) {
                val factory = createToken
                prepareNewToken(if (factory != null) factory() else (ModelDelta() as T))
            }

            return _currentChange!!
        }
    private fun clearRedoStack() { /*@DONE ChangeHistory.ClearRedoStack/1 cs:58-64*/
        if (redoStack.size > 0) {
            redoStack.clear()
            if (undoStack.size < undoStackSizeAtSaveTag) undoStackSizeAtSaveTag = -1
            _redo.raiseCanExecuteChanged()
        }
    }
    private fun prepareNewToken(token: T) { /*@DONE ChangeHistory.PrepareNewToken/1 cs:66-71*/
        _currentChange = token
        token.onNewChange += currentTokenChangedHandler
        clearRedoStack()
    }
    val isSaved: Boolean
        get() { /*@DONE ChangeHistory.IsSaved.get cs:74-76*/
            val change = _currentChange
            return undoStackSizeAtSaveTag == undoStack.size && (change == null || !change.hasAnyChange)
        }
    val hasDataChange: Boolean
        get() { /*@DONE ChangeHistory.HasDataChange.get cs:80-93*/
            if (isSaved) return false
            val addedElements = undoStack.size - undoStackSizeAtSaveTag
            val undoItems = undoStack.toList() // bottom of the stack first
            val redoItems = redoStack.reversed() // top of the stack first
            if (undoStackSizeAtSaveTag == -1) return true
            for (i in 0 until addedElements) {
                if (undoItems[undoStackSizeAtSaveTag + i].hasDataChange) return true
            }
            for (i in 0 until -addedElements) {
                if (redoItems[redoItems.size - 1 - i].hasDataChange) return true
            }
            return _currentChange?.hasDataChange ?: false
        }
    constructor(revertChange: (T) -> T, maxStackSize: Int = 100, createToken: (() -> T)? = null) { /*@DONE ChangeHistory.<init>/1 cs:96-107*/
        maxSize = maxStackSize
        revert = revertChange
        this.createToken = createToken
        _undo = StubCommand().also {
            it.execute = { _ -> undoExecuted() }
            it.canExecute = { _ -> undoStack.size > 0 || (_currentChange?.hasAnyChange == true) }
        }
        _redo = StubCommand().also {
            it.execute = { _ -> redoExecuted() }
            it.canExecute = { _ -> redoStack.size > 0 }
        }
    }
    fun changeCompleted() { /*@DONE ChangeHistory.ChangeCompleted/1 cs:109-123*/
        if (!continueCurrentTransaction) customChangeInProgress = false
        val change = _currentChange ?: return
        if (!change.hasAnyChange) {
            _currentChange = null
            return
        }
        verifyRevertNotInProgress("ChangeCompleted")
        if (continueCurrentTransaction) return

        undoStack.addLast(change)
        if (undoStack.size > maxSize) {
            // drop the oldest changes
            undoStack = ArrayDeque(undoStack.toList().takeLast(maxSize))
            undoStackSizeAtSaveTag = -1
        }
        change.onNewChange -= currentTokenChangedHandler
        _currentChange = null
    }
    fun insertCustomChange(change: T): T { /*@DONE ChangeHistory.InsertCustomChange/1 cs:131-138*/
        if (continueCurrentTransaction) throw InvalidOperationException("Inserting a change during a CurrentTransactionScope will cause changes to be lost.")
        changeCompleted()
        prepareNewToken(change)
        onCurrentTokenDataChanged(null, null)
        customChangeInProgress = true
        return change
    }
    fun tagAsSaved() { /*@DONE ChangeHistory.TagAsSaved/1 cs:140-146*/
        changeCompleted()
        hasDataChangeCache = false
        if (tryUpdate(undoStackSizeAtSaveTag, undoStack.size, "isSaved") { undoStackSizeAtSaveTag = it }) {
            notifyPropertyChanged("hasDataChange")
        }
    }
    private var continueCurrentTransaction: Boolean = false
    fun continueCurrentTransaction(): IDisposable { /*@DONE ChangeHistory.ContinueCurrentTransaction/1 cs:149-154*/
        if (customChangeInProgress) changeCompleted()
        val previousValue = continueCurrentTransaction
        continueCurrentTransaction = true
        return StubDisposable { continueCurrentTransaction = previousValue }
    }
    private var hasDataChangeCache: Boolean = false
    private fun onCurrentTokenDataChanged(sender: Any?, e: EventArgs?) { /*@DONE ChangeHistory.OnCurrentTokenDataChanged/1 cs:157-166*/
        if (undoStack.size == 0) _undo.raiseCanExecuteChanged()
        val hasChange = hasDataChange
        if (hasChange != hasDataChangeCache) {
            hasDataChangeCache = hasChange
            notifyPropertiesChanged("hasDataChange", "isSaved")
        } else if (!hasChange && _currentChange?.hasAnyChange == true) {
            notifyPropertyChanged("isSaved")
        }
    }
    private fun undoExecuted() { /*@DONE ChangeHistory.UndoExecuted/1 cs:168-186*/
        changeCompleted()
        if (undoStack.size == 0) return
        val previouslyWasSaved = isSaved
        val previouslyHadDataChanged = hasDataChange

        createRevertScope().using {
            val originalChange = undoStack.removeLast()
            if (undoStack.size == 0) _undo.raiseCanExecuteChanged()
            val reverseChange = revert(originalChange)
            redoStack.addLast(reverseChange)
            if (redoStack.size == 1) _redo.raiseCanExecuteChanged()
        }

        if (previouslyWasSaved != isSaved) notifyPropertyChanged("isSaved")
        hasDataChangeCache = hasDataChange
        if (previouslyHadDataChanged != hasDataChangeCache) notifyPropertyChanged("hasDataChange")
    }
    private fun redoExecuted() { /*@DONE ChangeHistory.RedoExecuted/1 cs:188-205*/
        if (redoStack.size == 0) return
        val previouslyWasSaved = isSaved
        val previouslyHadDataChanged = hasDataChange
        verifyRevertNotInProgress("RedoExecuted")

        createRevertScope().using {
            val reverseChange = redoStack.removeLast()
            if (redoStack.size == 0) _redo.raiseCanExecuteChanged()
            val originalChange = revert(reverseChange)
            undoStack.addLast(originalChange)
            if (undoStack.size == 1) _undo.raiseCanExecuteChanged()
        }

        if (previouslyWasSaved != isSaved) notifyPropertyChanged("isSaved")
        hasDataChangeCache = hasDataChange
        if (previouslyHadDataChanged != hasDataChangeCache) notifyPropertyChanged("hasDataChange")
    }
    private fun verifyRevertNotInProgress(caller: String? = null) { /*@DONE ChangeHistory.VerifyRevertNotInProgress/1 cs:207-210*/
        if (!revertInProgress) return
        throw InvalidOperationException("Cannot execute member $caller while a revert is in progress.")
    }
    private fun createRevertScope(): IDisposable { /*@DONE ChangeHistory.CreateRevertScope/1 cs:212-216*/
        revertInProgress = true
        return StubDisposable { revertInProgress = false }
    }
    fun clearHistory(needsSave: Boolean) { /*@DONE ChangeHistory.ClearHistory/1 cs:218-229*/
        verifyRevertNotInProgress("ClearHistory")
        if (!isSaved || needsSave) undoStackSizeAtSaveTag = -1
        undoStack.clear()
        redoStack.clear()
        _currentChange = null

        notifyPropertyChanged("hasDataChange")
        notifyPropertyChanged("isSaved")
        _undo.raiseCanExecuteChanged()
        _redo.raiseCanExecuteChanged()
    }
    /*@ADD ChangeHistory#view_1.txt*/
    private val currentTokenChangedHandler: (Any?, EventArgs) -> Unit = { s, e -> onCurrentTokenDataChanged(s, e) }
    /*@ENDADD ChangeHistory#view_1.txt*/
    /*@END ChangeHistory*/
}
