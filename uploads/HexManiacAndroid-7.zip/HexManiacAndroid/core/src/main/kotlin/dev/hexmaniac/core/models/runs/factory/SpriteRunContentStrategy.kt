// Port of Models/Runs/Factory/SpriteRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class SpriteRunContentStrategy : RunStrategy { // cs:11-71
    private var spriteFormat: SpriteFormat = SpriteFormat()
    constructor(spriteFormat: SpriteFormat) { /*@DONE SpriteRunContentStrategy.<init>/1 cs:13-13*/
        this.spriteFormat = spriteFormat
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE SpriteRunContentStrategy.LengthForNewRun/1 cs:15-15*/
        return spriteFormat.expectedByteLength
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE SpriteRunContentStrategy.TryAddFormatAtDestination/1 cs:16-21*/
        val spriteRun = SpriteRun(owner, destination, spriteFormat, SortedSpan(source))
        // TODO deal with the run being too long?
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, spriteRun)
        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE SpriteRunContentStrategy.Matches/1 cs:22-26*/
        return run is SpriteRun &&
            run.spriteFormat.bitsPerPixel == spriteFormat.bitsPerPixel &&
            run.spriteFormat.tileWidth == spriteFormat.tileWidth &&
            run.spriteFormat.tileHeight == spriteFormat.tileHeight
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE SpriteRunContentStrategy.WriteNewRun/1 cs:27-30*/
        for (i in 0 until spriteFormat.expectedByteLength) token.changeData(owner, destination + i, 0)
        return SpriteRun(owner, destination, spriteFormat)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE SpriteRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:31-37*/
        val runAttempt = SpriteRun(model, run.value.start, spriteFormat, run.value.pointerSources)
        if (runAttempt.length > 0) {
            val merged = runAttempt.mergeAnchor(run.value.pointerSources)
            run.value = merged
            model.clearFormat(token, merged.start, merged.length)
        }
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE SpriteRunContentStrategy.TryParseData/1 cs:38-43*/
        val error = isValid(spriteFormat)
        if (error.hasError) return error
        run.value = SpriteRun(model, dataIndex, spriteFormat, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    companion object {
        fun isValid(format: TilemapFormat): ErrorInfo { /*@DONE SpriteRunContentStrategy.IsValid/1 cs:45-50*/
            if (!format.bitsPerPixel.isAny(1, 2, 4, 8)) {
                return ErrorInfo("Sprite bpp must be 1, 2, 4, or 8.")
            }
            return ErrorInfo.noError
        }
        fun isValid(format: TilesetFormat): ErrorInfo { /*@DONE SpriteRunContentStrategy.IsValid/2 cs:52-60*/
            if (!format.bitsPerPixel.isAny(1, 2, 4, 8)) {
                return ErrorInfo("Sprite bpp must be 1, 2, 4, or 8.")
            }
            if (format.maxTiles == 0 || format.tiles == 0) {
                return ErrorInfo("Tilesets must have at least 1 tile.")
            }
            return ErrorInfo.noError
        }
        fun isValid(format: SpriteFormat): ErrorInfo { /*@DONE SpriteRunContentStrategy.IsValid/3 cs:62-70*/
            if (!format.bitsPerPixel.isAny(1, 2, 4, 8)) {
                return ErrorInfo("Sprite bpp must be 1, 2, 4, or 8.")
            }
            if (format.expectedByteLength <= 0) {
                return ErrorInfo("Sprite width/height must positive.")
            }
            return ErrorInfo.noError
        }
        /*@END SpriteRunContentStrategy.Companion*/
    }
    /*@END SpriteRunContentStrategy*/
}
