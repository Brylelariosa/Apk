// Port of Models/Code/LabelLibrary.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.code

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class LabelLibrary { // cs:8-64
    private lateinit var model: IDataModel
    private var labels: MutableMap<String, Int>? = null
    private var unresolvedLabels: MutableMap<String, MutableList<Int>> = LinkedHashMap()
    var requireCompleteAddresses: Boolean = /*@INITAUTO LabelLibrary.RequireCompleteAddresses cs:12-12*/ true /*@ENDINIT*/
    fun table(table: String): ITableRun? { /*@DONE LabelLibrary.Table/1 cs:13-13*/
        return model.getTable(table)
    }
    constructor(data: IDataModel, additionalLabels: MutableMap<String, Int>?) { /*@DONE LabelLibrary.<init>/1 cs:14-17*/
        this.model = data
        this.labels = additionalLabels
        unresolvedLabels = LinkedHashMap()
    }
    fun resolveLabel(label: String): Int { /*@DONE LabelLibrary.ResolveLabel/1 cs:19-30*/
        var label = label
        var offset = 0
        if (label == "null") return Pointer.null_
        val parts = label.split('+')
        if (parts.size == 2) {
            label = parts[0]
            val parsed = Ref(0)
            offset = if (tryParseHexInt(parts[1], parsed)) parsed.value else 0
        }
        val known = this.labels
        if (known != null) {
            val result = known[label]
            if (result != null) return result + offset
        }
        val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, label)
        if (address == Pointer.null_) return address
        return address + offset
    }
    fun tryResolveLabel(label: String, address: Ref<Int>): Boolean { /*@DONE LabelLibrary.TryResolveLabel/1 cs:32-35*/
        address.value = resolveLabel(label)
        return address.value >= 0
    }
    fun tryResolveValue(title: String, value: Ref<Int>): Boolean { /*@DONE LabelLibrary.TryResolveValue/1 cs:37-39*/
        return model.tryGetUnmappedConstant(title, value)
    }
    fun addUnresolvedLabel(label: String, source: Int) { /*@DONE LabelLibrary.AddUnresolvedLabel/1 cs:41-47*/
        var list = unresolvedLabels[label]
        if (list == null) {
            list = ArrayList()
            unresolvedLabels[label] = list
        }
        if (!list.contains(source)) list.add(source)
    }
    fun resolveUnresolvedLabels(scriptStart: Int, script: MutableList<Int>, endCommand: Int) { /*@DONE LabelLibrary.ResolveUnresolvedLabels/1 cs:49-63*/
        val known = this.labels ?: LinkedHashMap<String, Int>().also { this.labels = it }
        for (label in ArrayList(unresolvedLabels.keys)) {
            val destination = scriptStart + script.size - Pointer.null_
            for (address in unresolvedLabels[label]!!) {
                script[address - scriptStart + 0] = (destination shr 0) and 0xFF
                script[address - scriptStart + 1] = (destination shr 8) and 0xFF
                script[address - scriptStart + 2] = (destination shr 16) and 0xFF
                script[address - scriptStart + 3] = (destination shr 24) and 0xFF
            }
            known[label] = scriptStart + script.size
            script.add(endCommand and 0xFF)
        }
        unresolvedLabels.clear()
        if (known.values.any { it == scriptStart + script.size }) script.add(endCommand and 0xFF)
    }
    /*@END LabelLibrary*/
}

data class DecompileLabelLibrary(val model: IDataModel?, val start: Int, val length: Int) { // cs:66-114
    private val labels: MutableMap<Int, String> = /*@INITDONE DecompileLabelLibrary.labels cs:68-68*/ LinkedHashMap() /*@ENDINIT*/
    private val rawLabels: MutableSet<Int> = /*@INITDONE DecompileLabelLibrary.rawLabels cs:69-69*/ LinkedHashSet() /*@ENDINIT*/
    fun addressToLabel(address: Int, isScriptAddress: Boolean): String { /*@DONE DecompileLabelLibrary.AddressToLabel/1 cs:75-89*/
        var address = address
        if (address == Pointer.null_) return "null"
        if (address < 0) address -= Pointer.null_
        val existing = labels[address]
        if (existing != null) return existing
        val anchor: String? = if (isScriptAddress) model?.getAnchorFromAddress(-1, address) else null
        if (isScriptAddress && anchor != null && anchor.length > 4) {
            labels[address] = anchor
            return anchor
        } else if (isScriptAddress && address.inRange(start, start + length)) {
            val label = sentinel + labels.size
            labels[address] = label
            return label
        }
        rawLabels.add(address)
        return address.toAddress()
    }
    fun finalizeLabels(existingSectionCount: Ref<Int>): Map<String, String> { /*@DONE DecompileLabelLibrary.FinalizeLabels/1 cs:91-103*/
        val matches = labels.keys.filter { labels[it]!!.startsWith(sentinel) }.sorted()
        val results = LinkedHashMap<String, String>()
        for (i in matches.indices) {
            results[labels[matches[i]]!!] = "section" + (existingSectionCount.value + i)
        }
        existingSectionCount.value += matches.size
        return results
    }
    fun finalizeLine(sections: Map<String, String>, line: String): String { /*@DONE DecompileLabelLibrary.FinalizeLine/1 cs:105-111*/
        var line = line
        while (true) {
            val start = line.indexOf(sentinel)
            if (start == -1) return line
            val digits = line.substring(start + sentinel.length).takeWhile { it.isDigit() }
            if (digits.isEmpty()) return line
            val index = digits.toInt()
            val replacement = sections[sentinel + index] ?: return line
            line = line.replace(sentinel + index, replacement)
        }
    }
    val autoLabels: Iterable<Int>
        get() { /*@DONE DecompileLabelLibrary.AutoLabels.get cs:113-113*/
            return rawLabels.filter { it.inRange(start, start + length) }
        }
    companion object {
        private const val sentinel: String = ".sentinel."
        /*@END DecompileLabelLibrary.Companion*/
    }
    /*@END DecompileLabelLibrary*/
}
