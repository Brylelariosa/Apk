// Port of Models/Runs/Sprites/TilemapRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class TilemapRun : BaseRun, ITilemapRun { // cs:8-161
    var model: IDataModel? = null
        private set
    final override var format: TilemapFormat = TilemapFormat()
        private set
    override val bytesPerTile: Int
        get() { /*@DONE TilemapRun.BytesPerTile.get cs:13-13*/
            return 2
        }
    override val supportsImport: Boolean
        get() { /*@DONE TilemapRun.SupportsImport.get cs:16-24*/
            val m = model!!
            val tilesetAddress = m.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
            var tileset = m.getNextRun(tilesetAddress) as? ITilesetRun
            if (tileset == null) {
                if (arrayTilesetAddress == 0) findMatchingTileset(m)
                tileset = m.getNextRun(arrayTilesetAddress) as? ITilesetRun
            }
            return tileset != null
        }
    override val supportsEdit: Boolean
        get() { /*@DONE TilemapRun.SupportsEdit.get cs:27-27*/
            return supportsImport
        }
    final override var spriteFormat: SpriteFormat = SpriteFormat()
        private set
    override val pages: Int
        get() { /*@DONE TilemapRun.Pages.get cs:31-31*/
            return 1
        }
    override val length: Int
        get() { /*@DONE TilemapRun.Length.get cs:33-33*/
            return format.tileWidth * format.tileHeight * bytesPerTile
        }
    override val decompressedLength: Int
        get() { /*@DONE TilemapRun.DecompressedLength.get cs:35-35*/
            return length
        }
    override val formatString: String
        get() { /*@DONE TilemapRun.FormatString.get cs:38-42*/
            var start = "`ucm${format.bitsPerPixel}x${format.tileWidth}x${format.tileHeight}|${format.matchingTileset}"
            if (format.tilesetTableMember != null) start += "|" + format.tilesetTableMember
            return start + '`'
        }
    constructor(model: IDataModel, start: Int, format: TilemapFormat, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE TilemapRun.<init>/1 cs:45-58*/
        this.model = model
        this.format = format

        var hint: String? = null
        val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
        if (address >= 0 && address < model.count) {
            var tileset = model.getNextRun(address) as? ISpriteRun
            if (tileset == null) tileset = model.getNextRun(arrayTilesetAddress) as? ISpriteRun
            if (tileset != null && tileset !is LzTilemapRun) hint = tileset.spriteFormat.paletteHint
        }

        spriteFormat = SpriteFormat(format.bitsPerPixel, format.tileWidth, format.tileHeight, hint)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE TilemapRun.AppendTo/1 cs:67-74*/
        var remaining = length
        var position = start
        while (remaining > 0) {
            builder.append(model[position].toHexString())
            remaining -= 1
            if (remaining > 0) builder.append(" ")
            position += 1
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE TilemapRun.Clear/1 cs:76-78*/
        for (i in 0 until length) changeToken.changeData(model, start + i, 0xFF)
    }
    private var lastFormatRequested: Int = /*@INITDONE TilemapRun.lastFormatRequested cs:80-80*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE TilemapRun.CreateDataFormat/1 cs:81-93*/
        val basicFormat = createDataFormatCore(data, index)
        if (!createForLeftEdge || data.spartanMode) return basicFormat
        if (lastFormatRequested < index) {
            lastFormatRequested = index
            return basicFormat
        }

        val sprite = data.currentCacheScope.getImage(this)
        val availableRows = (length - (index - start)) / expectedDisplayWidth
        lastFormatRequested = index
        return SpriteDecorator(basicFormat, sprite, expectedDisplayWidth, availableRows)
    }
    private fun createDataFormatCore(model: IDataModel, index: Int): IDataFormat { /*@DONE TilemapRun.CreateDataFormatCore/1 cs:94-98*/
        val offset = index - start
        val segStart = start + offset - offset % 2
        return IntegerHex(segStart, offset % 2, this.model!!.readMultiByteValue(segStart, 2), 2)
    }
    override fun duplicate(newFormat: SpriteFormat): ISpriteRun { /*@DONE TilemapRun.Duplicate/1 cs:100-102*/
        throw NotImplementedError()
    }
    private var arrayTilesetAddress: Int = 0
    override fun findMatchingTileset(model: IDataModel): Int { /*@DONE TilemapRun.FindMatchingTileset/1 cs:105-105*/
        return withTilesetAddress { address -> LzTilemapRun.findMatchingTileset(this, model, -1, address) }
    }
    override fun getTilemapData(): ByteArray { /*@DONE TilemapRun.GetTilemapData/1 cs:107-111*/
        val data = ByteArray(format.expectedUncompressedLength)
        val raw = model!!.rawData
        val count = minOf(data.size, raw.size - start)
        if (count > 0) System.arraycopy(raw, start, data, 0, count)
        return data
    }
    override fun getData(): ByteArray { /*@DONE TilemapRun.GetData/1 cs:113-123*/
        val m = model!!
        val tilesetAddress = m.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
        var tileset = m.getNextRun(tilesetAddress) as? ISpriteRun
        if (tileset == null) tileset = m.getNextRun(arrayTilesetAddress) as? ISpriteRun

        if (tileset == null) return ByteArray(format.tileWidth * 8 * format.tileHeight * format.bitsPerPixel)

        val tiles = tileset.getData()

        return LzTilemapRun.getData(getTilemapData(), tiles, format, bytesPerTile)
    }
    override fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>? { /*@DONE TilemapRun.GetPixels/1 cs:125-137*/
        val mapData = getTilemapData()

        val tilesetAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
        var tileset = model.getNextRun(tilesetAddress) as? ISpriteRun
        if (tileset == null) tileset = model.getNextRun(arrayTilesetAddress) as? ISpriteRun

        if (tileset == null) return Array(format.tileWidth * 8) { IntArray(format.tileHeight * 8) } // relax the conditions slightly: if the run we found is an LZSpriteRun, that's close enough, we can use it as a tileset.

        val tiles = tileset.getData()

        return LzTilemapRun.getPixels(mapData, tiles, format, bytesPerTile)
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE TilemapRun.SetPixels/1 cs:139-141*/
        return withTilesetAddress { address -> LzTilemapRun.setPixels(this, model, token, page, pixels, address) { data, delta -> replaceData(data, delta) } }
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun { /*@DONE TilemapRun.SetPixels/2 cs:144-144*/
        throw NotImplementedError()
    }
    override fun replaceData(newRawData: ByteArray, token: ModelDelta): ITilemapRun { /*@DONE TilemapRun.ReplaceData/1 cs:147-155*/
        val m = model!!
        var newRun = m.relocateForExpansion(token, this, newRawData.size)
        for (i in 0 until newRawData.size) token.changeData(m, newRun.start + i, newRawData[i].toInt() and 0xFF)
        for (i in newRawData.size until length) token.changeData(m, newRun.start + i, 0xFF)
        newRun = TilemapRun(m, newRun.start, format, newRun.pointerSources)
        m.observeRunWritten(token, newRun)
        return newRun
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE TilemapRun.Clone/1 cs:157-157*/
        return TilemapRun(model!!, start, format, newPointerSources)
    }
    // skipped method Duplicate: explicit implementation merged with the public member
    override fun duplicate(format: TilemapFormat): TilemapRun { /*@DONE TilemapRun.Duplicate/3 cs:160-160*/
        return TilemapRun(model!!, start, format, pointerSources)
    }
    companion object {
        fun tryParseTilemapFormat(format: String, tilemapFormat: Ref<TilemapFormat>): Boolean { /*@DONE TilemapRun.TryParseTilemapFormat/1 cs:60-65*/
            tilemapFormat.value = TilemapFormat()
            if (!(format.startsWith("`ucm") && format.endsWith("`"))) return false
            val text = format.substring(4, format.length - 1)
            return LzTilemapRun.tryParseGeneralTilemapFormat(text, false, tilemapFormat)
        }
        /*@END TilemapRun.Companion*/
    }
    /*@ADD TilemapRun#runs_12.txt*/
    // C# passes the private field arrayTilesetAddress by ref; emulate with a copy-in/write-back Ref.
    private fun <T> withTilesetAddress(action: (Ref<Int>) -> T): T {
        val address = Ref(arrayTilesetAddress)
        try {
            return action(address)
        } finally {
            arrayTilesetAddress = address.value
        }
    }
    /*@ENDADD TilemapRun#runs_12.txt*/
    /*@END TilemapRun*/
}
