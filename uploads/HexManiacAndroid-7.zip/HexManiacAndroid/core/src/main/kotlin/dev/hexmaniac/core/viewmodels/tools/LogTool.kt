// Port of ViewModels/Tools/LogTool.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

open class LogTool : ViewModelCore(), IToolViewModel { // cs:6-14
    override val name: String
        get() { /*@DONE LogTool.Name.get cs:7-7*/
            return "Logs"
        }
    override fun dataForCurrentRunChanged() { /*@DONE LogTool.DataForCurrentRunChanged/1 cs:8-11*/
        allLogText = logMessages.joinToString(NEW_LINE)
        notifyPropertyChanged("allLogText")
    }
    var logMessages: MutableList<String> = /*@INITDONE LogTool.LogMessages cs:12-12*/ ArrayList() /*@ENDINIT*/
        private set
    var allLogText: String = ""
        private set
    /*@END LogTool*/
}
