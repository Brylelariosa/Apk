// Port of ViewModels/QuickEditItems/MakePokemonExpandable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class MakePokemonExpandable : IQuickEditItem { // cs:8-393
    override val name: String?
        get() { /*@DONE MakePokemonExpandable.Name.get cs:11-11*/
            return "Make Pokemon Expandable"
        }
    override val description: String?
        get() { /*@DONE MakePokemonExpandable.Description.get cs:13-16*/
            return "Make it possible to expand the number of pokemon in the game." + NEW_LINE +
                "Change the game's code to make the Egg/Unown pokemon IDs update as new pokemon are added." + NEW_LINE +
                "Add additional bits for pokedex seen/caught flags for the new pokemon." + NEW_LINE +
                "TODO Update Hall-of-Fame data to allow 16 bits per pokemon." + NEW_LINE
        }
    override val wikiLink: String?
        get() { /*@DONE MakePokemonExpandable.WikiLink.get cs:18-18*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Pokemon-Expansion-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE MakePokemonExpandable.CanRun/1 cs:22-29*/
        if (viewPort !is ViewPort) return false
        val model = viewPort.model
        if (model.getGameCode() != "BPRE0") return false
        val table = model.getTable(HardcodeTablesModel.pokemonNameTable)
        if (table == null || table.elementCount != 412) return false
        if ((model.getMatchedWords(pokemonCountConstant)?.size ?: 0) > 0) return false
        return true
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE MakePokemonExpandable.Run/1 cs:31-60*/
        val viewPort = viewPortInterface as IEditableViewPort
        val token = viewPort.changeHistory.currentChange
        val model = viewPort.model ?: return Task.fromResult(ErrorInfo.noError)
        if (model.getTable(HardcodeTablesModel.pokemonNameTable) == null) return Task.fromResult(ErrorInfo("Could not find the pokemon name table."))
        if (model.getTable(HardcodeTablesModel.dexInfoTableName) == null) return Task.fromResult(ErrorInfo("Could not find the pokedex info table."))

        // increase number of caught/seen flags for pokedex
        val freespace = updatePokedexFlagsCode(viewPort, token)

        // update constants and allow for automatic code updates when the number of pokemon changes
        val pokecount = updateConstants(viewPort, token)
        val loadPokeCountFunctions = addPokemonThumbConstantCode(viewPort, token, pokecount, freespace)
        updatePokemonThumbConstants(viewPort, token, loadPokeCountFunctions)

        // update constant and allow for automatic code updates when the size of the pokedex changes
        val dexCount = model.getTable(HardcodeTablesModel.dexInfoTableName)?.elementCount ?: 0 // TODO this can fail...
        val loadDexCountFunctions = addPokedexThumbConstantCode(viewPort, token, dexCount)
        updatePokedexThumbConstants(viewPort, token, dexCount, loadDexCountFunctions)

        // fix the really stupid table-index switch of PlayCryInternal
        updatePlayCryInternal(viewPort, token)

        updateOriginalTablesToMatchLengthToConstants(viewPort, token)

        // still have 0x98 free at 072108 (UpdatePlayCryInternal)
        // still have 0x20 free at 0549B4 (UpdatePokedexFlagsCode)
        // still have 0x18 free at 104BA4 (UpdatePokedexFlagsCode, AddPokemonThumbConstantCode)

        // TODO still need to update hall-of-fame data

        return Task.fromResult(ErrorInfo.noError)
    }
    private fun updateConstants(viewPort: IEditableViewPort, token: ModelDelta): Int { /*@DONE MakePokemonExpandable.UpdateConstants/1 cs:62-79*/
        val model = viewPort.model ?: return 0
        val pokecount = model.getTable(HardcodeTablesModel.pokemonNameTable)?.elementCount ?: 0 // TODO this can fail...

        val pokeCount0 = intArrayOf(0x168E09, 0x16B2BC) // 2 bytes, equal to number of pokemon
        val pokeCount1 = intArrayOf(0x043240, 0x0CB160, 0x0CB16C, 0x14420C) // 2 bytes, equal to number of pokemon-1
        val pokeCount2 = intArrayOf(0x12EAB0) // 2 bytes, equal to number of pokemon+1

        for (address in pokeCount0) model.writeMultiByteValue(address, 2, token, pokecount)
        for (address in pokeCount1) model.writeMultiByteValue(address, 2, token, pokecount - 1)
        for (address in pokeCount2) model.writeMultiByteValue(address, 2, token, pokecount + 1)

        for (address in pokeCount0) model.observeRunWritten(token, WordRun(address, pokemonCountConstant, 2, 0, 1))
        for (address in pokeCount1) model.observeRunWritten(token, WordRun(address, pokemonCountConstant, 2, -1, 1))
        for (address in pokeCount2) model.observeRunWritten(token, WordRun(address, pokemonCountConstant, 2, 1, 1))

        return pokecount
    }
    private fun addPokemonThumbConstantCode(viewPort: IEditableViewPort, token: ModelDelta, pokecount: Int, freespace: Int): Int { /*@DONE MakePokemonExpandable.AddPokemonThumbConstantCode/1 cs:81-125*/
        val model = viewPort.model ?: return freespace
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")

        val newCode = parser.compile(token, model, freespace,
            "ldr r0, [pc, <pokecount>]", // 0
            "bx  lr",
            "ldr r1, [pc, <pokecount>]", // 4
            "bx  lr",
            "ldr r2, [pc, <pokecount>]", // 8
            "bx  lr",
            "ldr r3, [pc, <pokecount>]", // 12
            "bx  lr",
            "ldr r4, [pc, <pokecount>]", // 16
            "bx  lr",
            "ldr r5, [pc, <pokecount>]", // 20
            "bx  lr",
            "ldr r6, [pc, <pokecount>]", // 24
            "bx  lr",
            "ldr r7, [pc, <pokecount>]", // 28
            "bx  lr",
            "ldr r0, [pc, <pokecountMinusTwo>]", // 32
            "bx  lr",
            "ldr r1, [pc, <pokecountMinusTwoShiftToHighBits>]", // 36
            "bx  lr",
            "ldr r4, [pc, <pokecount>]",                        // 40: r4=pokecount + r0 - 161 : see Menu2_GetMonSpriteAnchorCoord, species = SPECIES_OLD_UNOWN_B + unownLetter - 1
            "add r4, r4, r0",
            "sub r4, 161",
            "bx  lr",
            "pokecount: .word 0",                               // 48
            "pokecountMinusTwo: .word 0",                       // 52
            "pokecountMinusTwoShiftToHighBits: .word 0"         // 56
        )
        token.changeData(model, freespace, newCode)
        val wordOffset = 48

        model.writeMultiByteValue(freespace + wordOffset, 4, token, pokecount)
        model.writeMultiByteValue(freespace + wordOffset + 4, 4, token, pokecount - 2)
        model.writeMultiByteValue(freespace + wordOffset + 8, 4, token, (pokecount - 2) shl 16)

        model.observeRunWritten(token, WordRun(freespace + wordOffset, pokemonCountConstant, 2, 0, 1))
        model.observeRunWritten(token, WordRun(freespace + wordOffset + 4, pokemonCountConstant, 2, -2, 1))
        model.observeRunWritten(token, WordRun(freespace + wordOffset + 10, pokemonCountConstant, 2, -2, 1))

        return freespace
    }
    private fun updatePokemonThumbConstants(viewPort: IEditableViewPort, token: ModelDelta, pokecountFunctionAddress: Int) { /*@DONE MakePokemonExpandable.UpdatePokemonThumbConstants/1 cs:127-167*/
        val model = viewPort.model ?: return
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        fun compile(adr: Int, reg: Int): ByteList = parser.compile(token, model, adr, "bl <" + (pokecountFunctionAddress + reg * 4).toHex(6) + ">")
        val registerUpdates = arrayOf(
            intArrayOf(0x00FFFA, 0x0118D0, 0x02A81A, 0x02CEAC, 0x07FE12, // r0
                       0x0E6590, 0x0A0470, 0x0F31B2, 0x0FBFD6, 0x0DABB4,
                       0x0DAC1A, 0x094A1A, 0x043766, 0x043C42, 0x043E5C,
                       0x0440FE, 0x113EC0, 0x113EE0, 0x05148E, 0x052174,
                       0x05287E, 0x0535D0, 0x04FAA2, 0x04FC5E, 0x04FC8C,
                       0x04FCA2, 0x04FD04, 0x11AC1E, 0x11ADD4, 0x11ADF0,
                       0x11B030, 0x11B19A, 0x074658, 0x074728, 0x074788,
                       0x076BEC, 0x076CC8, 0x011F74, 0x0459CC, 0x00EC94,
                       0x00ED6C, 0x00F0E4, 0x00F1B0, 0x096E72, 0x096F86,
                       0x0970A6, 0x09713E, 0x0971D2, 0x0971FE, 0x040FDA,
                       0x09700A),
            intArrayOf(0x0C839C, 0x0C8756, 0x0C882C, 0x0392CE, 0x0394FC, // r1
                       0x03994C, 0x039BC0, 0x03A234, 0x00D7E4, 0x00D854,
                       0x01196A, 0x013384, 0x013400, 0x01348C, 0x025BF8,
                       0x026DF0, 0x02B9A8, 0x02C9C8, 0x019CA4, 0x019D5A,
                       0x0CAD20, 0x0F23E4, 0x0F2E32, 0x0F32A4, 0x0F32E6,
                       0x040D0C, 0x15EBE0, 0x1193FA, 0x11B11C, 0x074624,
                       0x0746F0, 0x076BD8, 0x076C98, 0x011F3C, 0x096F78),
            intArrayOf(0x026E8E, 0x00ED3E, 0x00F182, 0x096FFC),        // r2
            intArrayOf(0x04FAE6), // r3
            intArrayOf(0x040036, 0x0401A6, 0x12EAA4), // r4
            IntArray(0), // r5
            IntArray(0), // r6
            intArrayOf(0x0A0224) // r7
        )
        for (register in 0 until 8) {
            for (address in registerUpdates[register]) {
                token.changeData(model, address, compile(address, register))
            }
        }

        token.changeData(model, 0x103726, parser.compile(token, model, 0x103726, "bl <" + (pokecountFunctionAddress + 32).toHex(6) + ">")) // pokedex_screen
        token.changeData(model, 0x0BECA2, parser.compile(token, model, 0x0BECA2, "bl <" + (pokecountFunctionAddress + 36).toHex(6) + ">")) // ReadMail
        token.changeData(model, 0x12EAB4, parser.compile(token, model, 0x12EAB4, "bl <" + (pokecountFunctionAddress + 40).toHex(6) + ">")) // Menu2_GetMonSpriteAnchorCoord
    }
    private fun addPokedexThumbConstantCode(viewPort: IEditableViewPort, token: ModelDelta, dexCount: Int): Int { /*@DONE MakePokemonExpandable.AddPokedexThumbConstantCode/1 cs:169-189*/
        val model = viewPort.model ?: return 0
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")

        val insertPoint = 0x157868
        val newCode = parser.compile(token, model, insertPoint,
            "ldr r0, [pc, <dexcount>]", // 0
            "lsl r0, r0, #3",
            "bx  lr",
            "nop",
            "ldr r2, [pc, <dexcount>]", // 8
            "bx  lr",
            "dexcount: .word 0"         // 12
        )
        token.changeData(model, insertPoint, newCode)
        val wordOffset = 12

        model.writeMultiByteValue(insertPoint + wordOffset, 4, token, dexCount)
        model.observeRunWritten(token, WordRun(insertPoint + wordOffset, pokedexCountConstant, 2, 0, 1))

        return insertPoint
    }
    private fun updatePokedexThumbConstants(viewPort: IEditableViewPort, token: ModelDelta, dexCount: Int, dexcountFunctionAddress: Int) { /*@DONE MakePokemonExpandable.UpdatePokedexThumbConstants/1 cs:191-205*/
        val model = viewPort.model ?: return
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        val countMinusOne = intArrayOf(0x088EA4, 0x1037D4, 0x103870, 0x103920, 0x104C28)
        for (address in countMinusOne) {
            model.writeMultiByteValue(address, 2, token, dexCount - 1)
            model.observeRunWritten(token, WordRun(address, pokedexCountConstant, 2, -1, 1))
        }

        fun compile(adr: Int, offset: Int): ByteList = parser.compile(token, model, adr, "bl <" + (dexcountFunctionAddress + offset).toHex(6) + ">")

        // update  1025EC to bl <r0=dex_size*8>
        // update  103534 to bl <r2=dex_size>
        compile(0x1025EC, 0)
        compile(0x103534, 8)
    }
    private fun updatePlayCryInternal(viewPort: IEditableViewPort, token: ModelDelta) { /*@DONE MakePokemonExpandable.UpdatePlayCryInternal/1 cs:211-254*/
        val model = viewPort.model ?: return
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        val scriptStart = 0x0720C2
        val scriptLength = 35 * 2
        val gMPlayPokemonCry = 0x02037ECC
        val speciesToCryId = 0x043304
        val setPokemonCryTone = 0x1DE638
        val script = """
                    sound_PlayCryInternal_After_SetPokemonCryPriority:
                       mov   r0, r7
                       bl    <${speciesToCryId.toHex(6)}>
                       mov   r1, #12
                       mul   r0, r1
                       mov   r1, r9   @ if (v0 == 0) use sound.pokemon.cry.normal. Else use sound.pokemon.cry.growl
                       cmp   r1, #0
                       beq   <use_normal_cry>
                       ldr   r1, [pc, <growl_cry>]
                       b     <next>
                    use_normal_cry:
                       ldr   r1, [pc, <normal_cry>]
                       b     <next>
                       nop
                    growl_cry:  .word <sound.pokemon.cry.growl>
                    normal_cry: .word <sound.pokemon.cry.normal>
                    0720E4:     .word 0x3A98   @ 15000, needed to be right here for earlier in the function.
                    next:
                       add   r0, r0, r1 @ r0 = index into chosen table
                       bl    <${setPokemonCryTone.toHex(6)}>
                       ldr   r1, [pc, <gMPlay_PokemonCry>]
                       str   r0, [r1, #0]
                       add   sp, #4
                       pop   {r3-r5}
                       mov   r8, r3
                       mov   r9, r4
                       mov   r10, r5
                       pop   {r4-r7}
                       pop   {r0}
                       bx    r0
                       nop
                    gMPlay_PokemonCry: .word 0x${gMPlayPokemonCry.toHex(8)}"""
        parser.compile(token, model, 0x0720C2, *script.splitLines())

        // clear 152 bytes after that are no longer needed
        model.clearFormatAndData(token, scriptStart + scriptLength, 152)
    }
    private fun updatePokedexFlagsCode(viewPort: IEditableViewPort, token: ModelDelta): Int { /*@DONE MakePokemonExpandable.UpdatePokedexFlagsCode/1 cs:264-374*/
        val codeClearPokedexFlags = """
        0549AC:
            push {lr}
            bl   <104B2C>
            pop  {pc}
        @ 0x20 bytes free at 0549B4
        """

        val codeSub8104AB0 = """
        @ New sub_8104AB0
        @ old location is 0x028 and 0x05C, 0x034 bytes each for owned and seen
        @ new location is 0xB20 and 0xD20, 0x200 bytes each for owned and seen
        104AB0: @ (u16 nationalDexNo, u8 caseId, bool8 indexIsSpecies)
            push  {r4-r6, lr}
            mov   r5, r1      @ r5 = caseId
            cmp   r2, #0
            beq   <104ABC>
            bl    <043298>  @ SpeciesToNationalPokedexNum
        104ABC:
            sub   r0, r0, #1
            lsr   r4, r0, #3 @ r4 = dexNum/8 (byte offset)
            mov   r1, #7
            and   r0, r1     @ r3 = dexNum%8 (bit offset)
            mov   r6, #1
            lsl   r6, r0     @ r6 = bit to get/set
            mov   r0, #0     @ default return value -> 0
            ldr   r2, [pc, <gSaveBlock2Ptr>]
            ldr   r2, [r2]
            add   r2, r4          @ r2 = byte to get/set within the save block. Still needs the start of the array added (0xB20 or 0xD20)
            cmp   r5, #0
            beq   <case0> @ get seen
            cmp   r5, #1
            beq   <case1> @ get caught
            cmp   r5, #2
            beq   <case2> @ set seen
            cmp   r5, #3
            beq   <case3> @ set caught
            b     <after_switch>
        case0: @ FLAG_GET_SEEN
            mov   r1, #0xD2  @ seen
            lsl   r1, #4
            ldrb  r1, [r2, r1]
            and   r1, r6
            cmp   r1, #0
            beq   <after_switch>
            mov   r0, #1
            b     <after_switch>
        case1: @ FLAG_GET_CAUGHT
            mov   r1, #0xB2  @ caught
            lsl   r1, #4
            ldrb  r1, [r2, r1]
            and   r1, r6
            cmp   r1, #0
            beq   <after_switch>
            mov   r0, #1
            b     <after_switch>
        case2: @ FLAG_SET_SEEN
            mov   r1, #0xD2  @ seen
            lsl   r1, #4
            ldrb  r0, [r2, r1]
            orr   r0, r6
            strb  r0, [r2, r1]
            mov   r0, #0
            b     <after_switch>
        case3: @ FLAG_SET_CAUGHT
            mov   r1, #0xD2  @ seen
            lsl   r1, #4
            ldrb  r0, [r2, r1]
            orr   r0, r6
            strb  r0, [r2, r1]
            mov   r1, #0xB2  @ caught
            lsl   r1, #4
            ldrb  r0, [r2, r1]
            orr   r0, r6
            strb  r0, [r2, r1]
            mov   r0, #0
        after_switch:
            pop   {r4-r6, pc}
        gSaveBlock2Ptr: 0x0300500C
        new_ClearPokedexFlags: @ 104B2C
            push  {r4, r5, lr}
            mov   r4, #80
            ldr   r5, =0x0300500C @ gSaveBlock2Ptr
            ldr   r5, [r5]
            mov   r0, #0xB2
            lsl   r0, #4
            add   r0, r5
            mov   r1, #0
            lsl   r2, r4, #2
            bl    <1E5ED8>   @ memset(gSaveBlock2Ptr->0xB20, 0, 0x200) (caught flags)
            mov   r0, #0xD2
            lsl   r0, #4
            add   r0, r5
            mov   r1, #0
            lsl   r2, r4, #2
            bl    <1E5ED8>   @ memset(gSaveBlock2Ptr->0xD20, 0, 0x200) (seen flags)
            pop   {r4, r5, pc}
        @ 100 spare bytes left
        """

        val model = viewPort.model ?: return 0
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        model.clearFormatAndData(token, 0x0549AC, 0x028)
        model.clearFormatAndData(token, 0x104AB0, 0x10C)
        parser.compile(token, model, 0x0549AC, *codeClearPokedexFlags.splitLines())
        parser.compile(token, model, 0x104AB0, *codeSub8104AB0.splitLines())

        // 0x20 bytes free at 0x0549B4
        // 0x64 bytes free at 0x104B58
        return 0x104B58
    }
    private fun updateOriginalTablesToMatchLengthToConstants(viewPort: IEditableViewPort, token: ModelDelta) { /*@DONE MakePokemonExpandable.UpdateOriginalTablesToMatchLengthToConstants/1 cs:376-379*/
        val model = viewPort.model ?: return
        updateLength(HardcodeTablesModel.pokemonNameTable, pokemonCountConstant, model, token)
        updateLength(HardcodeTablesModel.dexInfoTableName, pokedexCountConstant, model, token)
    }
    private fun updateLength(tableName: String, lengthConstant: String, model: IDataModel, token: ModelDelta) { /*@DONE MakePokemonExpandable.UpdateLength/1 cs:381-390*/
        val table = model.getTable(tableName)
        if (table == null) return
        val originalFromat = table.formatString
        var newFormat = originalFromat.substring(0, originalFromat.lastIndexOf("]") + 1)
        newFormat += lengthConstant
        val newPokedex = Ref<ITableRun?>(null)
        if (!ArrayRun.tryParse(model, newFormat, table.start, table.pointerSources, newPokedex).hasError) {
            val parsed = newPokedex.value
            if (parsed != null) model.observeRunWritten(token, parsed)
        }
    }
    override fun tabChanged() { /*@DONE MakePokemonExpandable.TabChanged/1 cs:392-392*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        private const val pokemonCountConstant: String = "data.pokemon.count"
        private const val pokedexCountConstant: String = "data.pokedex.count"
        /*@END MakePokemonExpandable.Companion*/
    }
    /*@END MakePokemonExpandable*/
}
