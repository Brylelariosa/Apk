// Port of Core/IDelayWorkTimer.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core

import dev.hexmaniac.core.system.*

enum class DelayWorkResult(val value: Int) { // cs:5-5
    WorkScheduled(0),
    WorkScheduledAndPreviousWorkCleared(1);
    companion object {
        fun fromValue(value: Int): DelayWorkResult = entries.first { it.value == value }
    }
    /*@END DelayWorkResult*/
}

interface IDelayWorkTimer { // cs:7-23
    val hasScheduledWork: Boolean
    fun delayCall(delay: TimeSpan, action: () -> Unit): DelayWorkResult
    fun reset()
    /*@END IDelayWorkTimer*/
}
