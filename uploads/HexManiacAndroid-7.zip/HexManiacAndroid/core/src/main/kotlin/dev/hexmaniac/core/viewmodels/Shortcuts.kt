// Port of ViewModels/Shortcuts.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.system.ICommandExtensions.canAlwaysExecute

open class Shortcuts : ViewModelCore { // cs:6-41
    private lateinit var _displayAsEventScript: StubCommand
    private lateinit var _displayAsText: StubCommand
    private lateinit var _displayAsSprite: StubCommand
    private lateinit var _displayAsColorPalette: StubCommand
    lateinit var viewPort: ViewPort
        private set
    val displayAsEventScript: ICommand
        get() { /*@DONE Shortcuts.DisplayAsEventScript.get cs:11-11*/
            if (!::_displayAsEventScript.isInitialized) _displayAsEventScript = stubCommand({ executeDisplayAsEventScript() }, { canExecuteDisplayAs() })
            return _displayAsEventScript
        }
    val displayAsText: ICommand
        get() { /*@DONE Shortcuts.DisplayAsText.get cs:12-12*/
            if (!::_displayAsText.isInitialized) _displayAsText = stubCommand({ executeDisplayAsText() }, { canExecuteDisplayAs() })
            return _displayAsText
        }
    val displayAsSprite: ICommand
        get() { /*@DONE Shortcuts.DisplayAsSprite.get cs:13-13*/
            if (!::_displayAsSprite.isInitialized) _displayAsSprite = stubCommand({ executeDisplayAsSprite() }, { canExecuteDisplayAs() })
            return _displayAsSprite
        }
    val displayAsColorPalette: ICommand
        get() { /*@DONE Shortcuts.DisplayAsColorPalette.get cs:14-14*/
            if (!::_displayAsColorPalette.isInitialized) _displayAsColorPalette = stubCommand({ executeDisplayAsColorPalette() }, { canExecuteDisplayAs() })
            return _displayAsColorPalette
        }
    constructor(viewPort: ViewPort) { /*@DONE Shortcuts.<init>/1 cs:16-16*/
        this.viewPort = viewPort
    }
    private fun canExecuteDisplayAs(): Boolean { /*@DONE Shortcuts.CanExecuteDisplayAs/1 cs:18-22*/
        val spot = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        val nextRun = viewPort.model.getNextRun(spot) ?: NoInfoRun.nullRun
        return nextRun.start > spot || nextRun is NoInfoRun
    }
    private fun executeDisplayAsEventScript() { /*@DONE Shortcuts.ExecuteDisplayAsEventScript/1 cs:24-28*/
        viewPort.tools!!.codeTool!!.isEventScript.execute()
        viewPort.refresh()
        viewPort.updateToolsFromSelection(viewPort.convertViewPointToAddress(viewPort.selectionStart))
    }
    private fun executeDisplayAsText() { /*@DONE Shortcuts.ExecuteDisplayAsText/1 cs:30-32*/
        viewPort.isText.execute()
    }
    private fun executeDisplayAsSprite() { /*@DONE Shortcuts.ExecuteDisplayAsSprite/1 cs:34-36*/
        viewPort.tools!!.spriteTool!!.isSprite.execute()
    }
    private fun executeDisplayAsColorPalette() { /*@DONE Shortcuts.ExecuteDisplayAsColorPalette/1 cs:38-40*/
        viewPort.tools!!.spriteTool!!.isPalette.execute()
    }
    /*@END Shortcuts*/
}
