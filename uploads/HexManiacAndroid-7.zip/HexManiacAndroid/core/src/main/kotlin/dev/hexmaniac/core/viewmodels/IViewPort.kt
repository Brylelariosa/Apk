// Port of ViewModels/IViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*

interface IViewPort : ITabContent, INotifyCollectionChanged { // cs:14-71
    val previewScrollChanged: Event<EventArgs>
    val requestCloseOtherViewports: Event<IDataModel>
    var toolPanelWidth: Double
    val fileName: String
    val fullFileName: String
    var width: Int
    var height: Int
    var autoAdjustDataWidth: Boolean
    var stretchData: Boolean
    var allowMultipleElementsPerLine: Boolean
    var base10Length: Boolean
    var useCustomHeaders: Boolean
    val minimumScroll: Int
    var scrollValue: Int
    val maximumScroll: Int
    val headers: ObservableCollection<RowHeader>?
    val columnHeaders: ObservableCollection<ColumnHeaderRow>
    val dataOffset: Int
    val scroll: ICommand
    val progress: Double
    val updateInProgress: Boolean
    val canFindFreeSpace: Boolean
    var selectedAddress: String
    val selectedBytes: String?
    val anchorText: String
    val anchorTextVisible: Boolean
    var findBytes: ByteArray?
    operator fun get(x: Int, y: Int): HexElement
    val model: IDataModel?
    fun modelFor(point: Point): IDataModel?
    fun isSelected(point: Point): Boolean
    fun isTable(point: Point): Boolean
    fun find(search: String, matchExactCase: Boolean = false): List<IViewPortFindTuple>
    fun findFreeSpace(fileSystem: IFileSystem)
    fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort
    fun followLink(x: Int, y: Int)
    fun expandSelection(x: Int, y: Int)
    fun considerReload(fileSystem: IFileSystem)
    fun findAllSources(x: Int, y: Int)
    val hasTools: Boolean
    val changeHistory: ChangeHistory<ModelDelta>
    val tools: IToolTrayViewModel?
    fun getContextMenuItems(point: Point, fileSystem: IFileSystem?): List<IContextItem>
    /*@END IViewPort*/
}

interface IEditableViewPort : IViewPort, IRaiseMessageTab, IRaiseErrorTab { // cs:73-90
    val initializationWorkload: Task<Unit>
    val mapEditor: MapEditorViewModel?
    var allowSingleTableMode: Boolean
    var isFocused: Boolean
    val selectionStart: Point
    val selectionEnd: Point
    override var anchorText: String
    fun edit(input: String)
    fun edit(input: String, loadingPercentBeforeEdit: Double, loadingPercentAfterEdit: Double): Task<Unit>
    fun edit(key: ConsoleKey)
    fun raiseRequestTabChange(tab: ITabContent)
    fun updateProgress(value: Double): InlineDispatch
    fun clearProgress()
    fun createDuplicate(): IEditableViewPort
    fun openImageEditorTab(address: Int, spritePage: Int, palettePage: Int, preferredTileWidth: Int = -1)
    fun gotoScript(address: Int)
    /*@END IEditableViewPort*/
}
