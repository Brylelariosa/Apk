// Port of ViewModels/HexElement.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class HexElement { // cs:4-12
    var value: Int = 0
        private set
    var edited: Boolean = false
        private set
    var format: IDataFormat? = null
        private set
    constructor(value: Int, edited: Boolean, format: IDataFormat) { /*@DONE HexElement.<init>/1 cs:10-10*/
        this.value = value
        this.edited = edited
        this.format = format
    }
    constructor(source: HexElement, newFormat: IDataFormat) { /*@DONE HexElement.<init>/2 cs:11-11*/
        this.value = source.value
        this.edited = source.edited
        this.format = newFormat
    }
    companion object {
        val undefined: HexElement = /*@INITDONE HexElement.Undefined cs:5-5*/ HexElement(0, false, Undefined.instance) /*@ENDINIT*/
        /*@END HexElement.Companion*/
    }
    /*@END HexElement*/
}
